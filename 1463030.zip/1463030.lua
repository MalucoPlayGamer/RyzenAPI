-- Lua provided by RyzenAPI
-- Game: addappid(1463030)

-- MAIN APPLICATION
addappid(1463030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463031, 1, "cda9726575a21215d4713d9f3eca60ecc7acb2f7b4af96446fb819c9c0cd2875")
