-- Lua provided by RyzenAPI
-- Game: Game: DeathMetal

-- MAIN APPLICATION
addappid(553820)
-- Game: addappid(553820)

-- MAIN APP DEPOTS / PACKAGES
addappid(553821, 1, "86cbac7b6fb170ad488b1748920c540ee5f53793e0e20cb094e0b7f96e7d7b6d")
addappid(553822, 1, "d8244be6be049780bd6ff163d80798b6c1e7915f8299673d4f6e955d70d0d97f")
addappid(553823, 1, "548b51b44e69937a0a07021ad7665ea53f87440e22de31c3a073af20182ef9f1")
