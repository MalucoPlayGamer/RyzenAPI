-- Lua provided by RyzenAPI
-- Game: DeathMetal

-- MAIN APPLICATION
addappid(553820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(553821, 1, "86cbac7b6fb170ad488b1748920c540ee5f53793e0e20cb094e0b7f96e7d7b6d")
addappid(553822, 1, "d8244be6be049780bd6ff163d80798b6c1e7915f8299673d4f6e955d70d0d97f")
addappid(553823, 1, "548b51b44e69937a0a07021ad7665ea53f87440e22de31c3a073af20182ef9f1")

