-- Lua provided by RyzenAPI
-- Game: Game: AppID 864570

-- MAIN APPLICATION
addappid(864570)
-- Game: addappid(864570)

-- MAIN APP DEPOTS / PACKAGES
addappid(864571, 1, "af6996a091f3f5b786936b1753b805106831c91c0c7b5b6264892f4bc748c642")
