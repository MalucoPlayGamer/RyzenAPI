-- Lua provided by RyzenAPI
-- Game: addappid(2091720)

-- MAIN APPLICATION
addappid(2091720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091721, 1, "247f29bceb4333fb3858203eca04094dc01b5dcbf54d2ebd32fdd5c655181290")
