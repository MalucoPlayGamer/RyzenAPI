-- Lua provided by RyzenAPI
-- Game: Nightmare

-- MAIN APPLICATION
addappid(2091720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2091721, 1, "247f29bceb4333fb3858203eca04094dc01b5dcbf54d2ebd32fdd5c655181290")

