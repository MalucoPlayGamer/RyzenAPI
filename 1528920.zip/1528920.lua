-- Lua provided by RyzenAPI
-- Game: Andromeda Zombies Colonies

-- MAIN APPLICATION
addappid(1528920)
-- Game: addappid(1528920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528921, 1, "20ddb032e19d4e47fa8f485dfe565928a3f441afaa1645d98f5f57b984a7f9e2")
