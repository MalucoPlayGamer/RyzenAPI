-- Lua provided by RyzenAPI
-- Game: TaskForce Gamma-13 : An SCP Tale

-- MAIN APPLICATION
addappid(1199770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1199771, 1, "d3a5d5f17c5cb651a388c31a4f57df5f1e181ecd276488a083e5ae845c22ccd1")
addappid(1199772, 1, "2111172d058e2b5dae4ee5975d9704a85e16cf153a7608b0ea0aa7888720b71c")
