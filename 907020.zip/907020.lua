-- Lua provided by RyzenAPI
-- Game: Bomber 95

-- MAIN APPLICATION
addappid(907020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(907021, 1, "9fd296576489f600902d5e4cd76cf436ac7f6aae59e7d89496950d70dcc02979")

