-- Lua provided by RyzenAPI
-- Game: 907020

-- MAIN APPLICATION
addappid(907020)
-- Game: addappid(907020)

-- MAIN APP DEPOTS / PACKAGES
addappid(907021, 1, "9fd296576489f600902d5e4cd76cf436ac7f6aae59e7d89496950d70dcc02979")
