-- Lua provided by SkyAPI 
-- Game: AppID 907020
addappid(907020)
addappid(907021, 1, "9fd296576489f600902d5e4cd76cf436ac7f6aae59e7d89496950d70dcc02979")
