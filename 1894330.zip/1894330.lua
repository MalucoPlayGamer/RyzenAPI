-- Lua provided by RyzenAPI
-- Game: Ketchup and Mayonnaise Demo

-- MAIN APPLICATION
addappid(1894330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894331, 1, "b32baf7d9623cf8d91e645d2312ee274a5f4db698b8fd289da046029f8acf361")
