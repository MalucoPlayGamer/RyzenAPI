-- Lua provided by RyzenAPI
-- Game: 最強宗師

-- MAIN APPLICATION
addappid(3391110)

