-- Lua provided by SkyAPI 
-- Game: Paleon
addappid(1554220)
addappid(1554221, 1, "245f57693d714032de532a3c966835491b2cf9d76e9e2fcdb0ef8a5ce8b1e725")
addappid(1554222, 1, "b3897730e97d6c5f677b798f868dcf222f8c03e092f7ed2fa71cb62d1615c254")
