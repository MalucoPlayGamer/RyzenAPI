-- Lua provided by RyzenAPI
-- Game: Hypergate

-- MAIN APPLICATION
addappid(809530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(809531,0,"c6f781d146cafc2c2caf8f2dd51aeec010dcd0dbf86f8de4aaeaf466621e7cbc")

