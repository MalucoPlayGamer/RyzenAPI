-- Lua provided by RyzenAPI
-- Game: Hypergate

-- MAIN APPLICATION
addappid(809530)

-- MAIN APP DEPOTS / PACKAGES
addappid(809531,0,"c6f781d146cafc2c2caf8f2dd51aeec010dcd0dbf86f8de4aaeaf466621e7cbc")

