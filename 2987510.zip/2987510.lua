-- Lua provided by RyzenAPI
-- Game: Woolly boy and the Circus - Demo

-- MAIN APPLICATION
addappid(2987510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987511, 1, "39cdee50e8a3ef60a0315c2da7f9adbddbffbec7da6a9792e632fc4bce93f672")
