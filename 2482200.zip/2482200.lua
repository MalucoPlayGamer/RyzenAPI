-- Lua provided by RyzenAPI
-- Game: 2482200

-- MAIN APPLICATION
addappid(2482200)
-- Game: addappid(2482200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482201, 1, "00c16b5dc523427fd4495b3e3a32bf41048b44d4e62935bcf0017fc26bc216df")
