-- Lua provided by RyzenAPI
-- Game: Chess!

-- MAIN APPLICATION
addappid(2373460)
-- Game: addappid(2373460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373461, 1, "b069ed9a3563d222c3fdc4c859bdb89daa59702a3fd3cf11f9223377e8e01247")
