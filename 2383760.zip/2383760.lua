-- Lua provided by RyzenAPI
-- Game: Monopoly Madness

-- MAIN APPLICATION
addappid(2383760)
addappid(2392250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383761, 1, "a755490a3dac0fd94bdfe6d70469370bf644f019a462b547f46f021cbcb06e42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2383810)
addappid(2397150)
