-- Lua provided by RyzenAPI
-- Game: addappid(2383760)

-- MAIN APPLICATION
addappid(2383760)
addappid(2392250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383761, 1, "a755490a3dac0fd94bdfe6d70469370bf644f019a462b547f46f021cbcb06e42")
