-- Lua provided by RyzenAPI
-- Game: Mollycoddle Mayhem Demo

-- MAIN APPLICATION
addappid(1969580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969581, 1, "922ff35e104fb794ad99cd02fe28bc5e19fa5e1e0e7573a3dd655e023c0544b3")

