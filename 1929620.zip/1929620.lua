-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1929620)
-- Game: addappid(1929620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929620,0,"e217548637aaa2a1245c0ab4a686e5d23b38dc6e140866a7f618b8b76082f336")
