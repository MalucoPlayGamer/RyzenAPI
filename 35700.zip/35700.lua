-- Lua provided by RyzenAPI
-- Game: Trine Enchanted Edition

-- MAIN APPLICATION
addappid(35700)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(35701, 1, "8821fc91224a9fd6adfbc8e249800fcc1fe09da0c3027de2135b4586d2d0597b")
addappid(35702, 1, "472b5f2018faae2040c349639cd95a387ad8808789aac2f3c759d9eb891c5dd1")
addappid(35703, 1, "3c7b6fbb8261fb8d74c03cb0de74cae206704c8a2ebc9a75ebcdfb1dcb41f965")
