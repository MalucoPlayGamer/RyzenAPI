-- Lua provided by RyzenAPI
-- Game: MINImax Tinyverse

-- MAIN APPLICATION
addappid(914700)
addappid(991520)
addappid(1137280)
addappid(1137281)
addappid(1137282)
addappid(1137283)

-- MAIN APP DEPOTS / PACKAGES
addappid(914701,0,"382f490b9ef30253b64ce8e32515cd24e1ce5f48c856517ab8911c9533c5e645")
addappid(914702,0,"d006e5ac2a0503a5dbf697b4646e15214e57df88eeb4ef62aa3fb4abd5d17d6c")

