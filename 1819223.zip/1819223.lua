-- Lua provided by RyzenAPI
-- Game: Forspoken Digital Mini Artbook

-- MAIN APPLICATION
addappid(1819223)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819223,0,"a34faa659dbf0224fb461f37c6a34009ab93da4423be0f11573278900904d102")

