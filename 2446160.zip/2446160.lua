-- Lua provided by RyzenAPI
-- Game: Destruct Blocks

-- MAIN APPLICATION
addappid(2446160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446161, 1, "32124e699c60cfee908ac26d1de6e3a91c936b19096e960fc752d29b1f2dbad3")
