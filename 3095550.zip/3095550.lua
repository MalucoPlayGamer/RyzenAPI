-- Lua provided by RyzenAPI
-- Game: False Mall

-- MAIN APPLICATION
addappid(3095550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095551, 1, "0a3a8de88fd06ea17fb78a126ff23076701057f92dec91808f588baa3a27fbb1")

