-- Lua provided by RyzenAPI
-- Game: 3095550

-- MAIN APPLICATION
addappid(3095550)
-- Game: addappid(3095550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095551, 1, "0a3a8de88fd06ea17fb78a126ff23076701057f92dec91808f588baa3a27fbb1")
