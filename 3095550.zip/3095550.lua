-- Lua provided by RyzenAPI
-- Game: False Mall

-- MAIN APPLICATION
addappid(3095550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3095551, 1, "0a3a8de88fd06ea17fb78a126ff23076701057f92dec91808f588baa3a27fbb1")

