-- Lua provided by RyzenAPI
-- Game: Dream Rhythm Demo

-- MAIN APPLICATION
addappid(3204190)
-- Game: addappid(3204190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204191, 1, "e4b767d80e31395fa5e08448d3b986ace17ae8d447e613dd38d440d013eeda79")
