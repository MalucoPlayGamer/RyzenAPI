-- Lua provided by RyzenAPI
-- Game: Game: AppID 552080

-- MAIN APPLICATION
addappid(552080)
-- Game: addappid(552080)

-- MAIN APP DEPOTS / PACKAGES
addappid(552081, 1, "31f840aed6524a32bc4a071f538c4e6a51217a011a9fc0e148163728d7436fa2")
