-- Lua provided by SkyAPI 
-- Game: AppID 1122210
addappid(1122210)
addappid(1122211, 1, "499b8329c0f9986951aa4ab7ae576cbf27b2668b38a3992437e66abb999030f9")
addappid(1132990)
addappid(1218650)
