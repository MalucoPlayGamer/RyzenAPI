-- Lua provided by RyzenAPI
-- Game: 1122210

-- MAIN APPLICATION
addappid(1122210)
addappid(1132990)
addappid(1218650)
-- Game: addappid(1122210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122211, 1, "499b8329c0f9986951aa4ab7ae576cbf27b2668b38a3992437e66abb999030f9")
