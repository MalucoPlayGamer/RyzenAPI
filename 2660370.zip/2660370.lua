-- Lua provided by RyzenAPI
-- Game: College Sex - Episode 3

-- MAIN APPLICATION
addappid(2660370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660371, 1, "b94537e298e5f77fd42b19328d5453ec296a2e9ee950c164c22fd882cc6663ca")

