-- Lua provided by RyzenAPI
-- Game: Kaze and the Wild Masks

-- MAIN APPLICATION
addappid(829280)
addappid(1462050)

-- MAIN APP DEPOTS / PACKAGES
addappid(829281,0,"f1458c2007641fea1dea07bcc2c0874e705b2281f0ff82dc7cc3e059fb46f62e")

