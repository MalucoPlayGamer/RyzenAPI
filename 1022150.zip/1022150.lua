-- Lua provided by RyzenAPI
-- Game: Bios Ex

-- MAIN APPLICATION
addappid(1022150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1022151, 1, "c49373d3cd27346ee33585a58c3ad63f2bf37964f7a55cb7d1991634e6e6cd22")

