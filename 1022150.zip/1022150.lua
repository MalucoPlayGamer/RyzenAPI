-- Lua provided by RyzenAPI
-- Game: 1022150

-- MAIN APPLICATION
addappid(1022150)
-- Game: addappid(1022150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022151, 1, "c49373d3cd27346ee33585a58c3ad63f2bf37964f7a55cb7d1991634e6e6cd22")
