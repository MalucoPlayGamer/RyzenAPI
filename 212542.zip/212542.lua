-- Lua provided by RyzenAPI
-- Game: 212542

-- MAIN APPLICATION
addappid(212542)

-- MAIN APP DEPOTS / PACKAGES
addappid(35453,0,"8bcab168d607dabfcbff5ec6b3bace1152717e7ac976b7f893973f4c5269d656")
