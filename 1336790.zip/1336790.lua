-- Lua provided by RyzenAPI
-- Game: Mini Words: Top Games

-- MAIN APPLICATION
addappid(1336790)
-- Game: addappid(1336790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336791, 1, "e2115ec5c0aebf1ddfa5d005683469ee609e5193c8457ec0dbbe1dea2649aaf4")
addappid(1336792, 1, "e1995ea522ef3cba8b0b6c97dd0d052f78d573e98ead6ab2d9fc899f0a16c3d1")
