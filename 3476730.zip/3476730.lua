-- Lua provided by RyzenAPI
-- Game: Killer Chat! - Original Edition

-- MAIN APPLICATION
addappid(3476730)
addappid(3492610)
addappid(3866430)
addappid(3894560)
addappid(4000800)
addappid(4000810)
addappid(4000820)
addappid(4000830)
addappid(4049720)

