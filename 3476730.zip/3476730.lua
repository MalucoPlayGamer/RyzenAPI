-- Lua provided by RyzenAPI
-- Game: Killer Chat! - Original Edition

-- MAIN APPLICATION
addappid(3476730)

