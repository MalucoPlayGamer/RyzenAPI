-- Lua provided by RyzenAPI
-- Game: Game: AppID 885390

-- MAIN APPLICATION
addappid(885390)
-- Game: addappid(885390)

-- MAIN APP DEPOTS / PACKAGES
addappid(885391, 1, "4c2fc559882e7a1efbdeff1e8128901e64c51143e7a81452d0031eaf2c6887e4")
addappid(885392, 1, "d95d05892406d52bcc180c4f604759be236d7e72d6f3b9f729d555bfcb7d688e")
addappid(885393, 1, "6e3c22b1dc858be7c940f23daa884834116eed9fca11c7e5434e28fba9e42974")
