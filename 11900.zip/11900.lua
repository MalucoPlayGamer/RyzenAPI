-- Lua provided by RyzenAPI
-- Game: 11900

-- MAIN APPLICATION
addappid(11900)
-- Game: addappid(11900)

-- MAIN APP DEPOTS / PACKAGES
addappid(11901, 1, "4dbec66410de140e26f0c99391b1f69df00b6909256ab79d0f04b2baf4503aef")
addappid(11911, 1, "eef5f9ed9df2d362979137e229aed9a81bdb83977f3e337437386f012da00b2e")
