-- Lua provided by RyzenAPI
-- Game: Chimeras: Mark of Death Collector's Edition

-- MAIN APPLICATION
addappid(1906670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906671, 1, "e465033fa671f71c4126300c3377d07b83ed2785164f3a7cdbfb955261ccd034")
