-- Lua provided by SkyAPI 
-- Game: AppID 1154420
addappid(1154420)
addappid(1154421, 1, "8a0ffa482fb4e6d478c2e55f86ef83f2873af657d9c5393b235ea2b3226ce25a")
