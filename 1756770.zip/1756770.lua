-- Lua provided by RyzenAPI
-- Game: Little Robo Climber

-- MAIN APPLICATION
addappid(1756770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756772,0,"6bc94da932e5bb9563837dd73cd6d759aedfdd9c1ebcfaf6d85cc01c93577563")
