-- Lua provided by RyzenAPI
-- Game: 2832420

-- MAIN APPLICATION
addappid(2832420)
-- Game: addappid(2832420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832421, 1, "a4308e0d3b0c0de3189d7825932116b2d41b55193ef8f403dcf62995ec8d2a09")
