-- Lua provided by SkyAPI 
-- Game: AppID 1544670
addappid(1544670)
addappid(1544671, 1, "6be119d4191cf2e1d47371b265ac5be22e0cd9487543d900a48af9cf3ee2f60c")
