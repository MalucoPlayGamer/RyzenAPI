-- Lua provided by RyzenAPI
-- Game: Russian Hentai 2

-- MAIN APPLICATION
addappid(1544670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544671, 1, "6be119d4191cf2e1d47371b265ac5be22e0cd9487543d900a48af9cf3ee2f60c")
