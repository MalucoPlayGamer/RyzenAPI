-- Lua provided by RyzenAPI
-- Game: 492280

-- MAIN APPLICATION
addappid(492280)
-- Game: addappid(492280)

-- MAIN APP DEPOTS / PACKAGES
addappid(492281, 1, "6b2b53fc59b2af4e6bfdac7ea9066c3104dc39d40ba16c166c4474ca28adc173")
addappid(492282, 1, "6902efe9dcf975ad6da8d71476577157022bf7f3abe26f7280f33d310023b973")
addappid(492283, 1, "382b8fb6f93fa42c0e85df824a534cfaf6a60f564f133cb5af3f2af8f079cfdb")
addappid(492285, 1, "c0ddf8607f78b46c07aba97d60b8068b51f927c9d000023312b9df124e59dfbe")
