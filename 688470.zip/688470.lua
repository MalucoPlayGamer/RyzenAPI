-- Lua provided by RyzenAPI 
-- Game: Han Xiongnu Wars
addappid(688470)
addappid(688471, 1, "804c4d458415eb1c9b58282ef719d83020877d7232484abaea05b26319ded1c3")
