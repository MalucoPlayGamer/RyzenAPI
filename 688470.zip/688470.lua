-- Lua provided by RyzenAPI
-- Game: Han Xiongnu Wars

-- MAIN APPLICATION
addappid(688470)

-- MAIN APP DEPOTS / PACKAGES
addappid(688471, 1, "804c4d458415eb1c9b58282ef719d83020877d7232484abaea05b26319ded1c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
