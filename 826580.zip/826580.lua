-- Lua provided by RyzenAPI
-- Game: Mervin and the Wicked Station

-- MAIN APPLICATION
addappid(826580)

-- MAIN APP DEPOTS / PACKAGES
addappid(826581, 1, "aceae04ef06ba36c102ae9cc893cdc47a8421acc0642c0f070710023f22f437a")

