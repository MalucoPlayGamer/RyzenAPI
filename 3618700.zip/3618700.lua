-- Lua provided by RyzenAPI
-- Game: Cats Visiting Historical Times

-- MAIN APPLICATION
addappid(3618700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618701, 1, "4adf0a11e6b1375ea2d7cbd4d92f4f7e20f4c2d1cd3ef3d88e3f22a24c2d25cc")

