-- Lua provided by RyzenAPI
-- Game: addappid(1554690)

-- MAIN APPLICATION
addappid(1554690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554690,0,"bd354b82558b7b8edf774134a8f91e4b10494edb006a22d0be0c44e4b0c2c122")
