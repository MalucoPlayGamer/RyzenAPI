-- Lua provided by SkyAPI 
-- Game: Flying High Demo
addappid(3002760)
addappid(3002761, 1, "5bf1bd3acf2683d31e84ecb14c74b22354779a1e0b3010d7432f1a1f0c7a21d1")
