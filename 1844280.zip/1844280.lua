-- Lua provided by RyzenAPI
-- Game: Game: My Lovely Girls

-- MAIN APPLICATION
addappid(1844280)
-- Game: addappid(1844280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844281, 1, "21a0ad1974455e300b9b1a005ea842e5d87e3eb13c9c2a9305b9a5fa194edd3a")
