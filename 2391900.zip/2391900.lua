-- Lua provided by RyzenAPI
-- Game: Game: Champion Shift

-- MAIN APPLICATION
addappid(2391900)
-- Game: addappid(2391900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391901, 1, "1b29abf3573354c14729557d412dd919780486b14686d95d617938862e9dbda3")
