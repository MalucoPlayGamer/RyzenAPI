-- Lua provided by RyzenAPI
-- Game: Tip of the Tongue

-- MAIN APPLICATION
addappid(2543610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543611, 1, "91478c4655d17d92b009982fbdf06768c46c144d6676875d018b4f6360f32a1f")

