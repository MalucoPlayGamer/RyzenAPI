-- Lua provided by RyzenAPI
-- Game: Tip of the Tongue

-- MAIN APPLICATION
addappid(2543610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2543611, 1, "91478c4655d17d92b009982fbdf06768c46c144d6676875d018b4f6360f32a1f")

