-- Lua provided by RyzenAPI
-- Game: Steam Engine Simulator

-- MAIN APPLICATION
addappid(2381620)
addappid(2601380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381621, 1, "7eb495ba37538d095801d63d0c36d139aa9af827c4b5475587787f52c57ab68f")

