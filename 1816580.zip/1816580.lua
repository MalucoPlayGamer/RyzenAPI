-- Lua provided by RyzenAPI
-- Game: Happy’s Humble Burger Farm: Rock the Warehouse (OST)

-- MAIN APPLICATION
addappid(1816580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816581, 1, "0c143949a26cac9435028499589d1452e4c7644b30eb9f368284434e8a07e789")

