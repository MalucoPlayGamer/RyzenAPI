-- Lua provided by RyzenAPI
-- Game: addappid(2717590)

-- MAIN APPLICATION
addappid(2717590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717594,0,"0453cd1d46dec00cc5a014f20ab38a72d5f8a0c3a5ff6140469d7b8ba28792a3")
