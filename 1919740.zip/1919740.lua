-- Lua provided by RyzenAPI
-- Game: Silent Love

-- MAIN APPLICATION
addappid(1919740)
addappid(2105950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919741, 1, "4fef9c337a9e02bcc1a3df3b4dcd61ea797aaa40078152e88b642aab498ad80f")

