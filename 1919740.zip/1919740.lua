-- Lua provided by SkyAPI 
-- Game: Silent Love
addappid(1919740)
addappid(1919741, 1, "4fef9c337a9e02bcc1a3df3b4dcd61ea797aaa40078152e88b642aab498ad80f")
