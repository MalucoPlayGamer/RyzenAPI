-- Lua provided by RyzenAPI
-- Game: 2424820

-- MAIN APPLICATION
addappid(2424820)
-- Game: addappid(2424820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424821, 1, "e9229bb08bad482f16c770623616798fc9af1148ce48125bbc7521cdf4a720e0")
