-- Lua provided by RyzenAPI
-- Game: The Adventures of LinShanHai - Chapter5:Three Trees

-- MAIN APPLICATION
addappid(2424820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424821, 1, "e9229bb08bad482f16c770623616798fc9af1148ce48125bbc7521cdf4a720e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
