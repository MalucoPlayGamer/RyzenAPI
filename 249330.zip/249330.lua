-- Lua provided by RyzenAPI 
-- Game: AppID 249330
addappid(249330)
addappid(249331, 1, "e6baa4e62e490b11a303c8b8f8a7245b59f3b452c2156a5c29b432b89570085a")
addappid(403820)
