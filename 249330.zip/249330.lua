-- Lua provided by RyzenAPI
-- Game: Unholy Heights

-- MAIN APPLICATION
addappid(249330)
addappid(403820)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(249331, 1, "e6baa4e62e490b11a303c8b8f8a7245b59f3b452c2156a5c29b432b89570085a")

