-- Lua provided by RyzenAPI
-- Game: 1474860

-- MAIN APPLICATION
addappid(1474860)
-- Game: addappid(1474860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474861, 1, "7856e9cd5daa816f4df54a1cd8107ad980fcb2e07bfb06a72b6a7be24b5e9860")
