-- Lua provided by RyzenAPI
-- Game: addappid(1031320)

-- MAIN APPLICATION
addappid(1031320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031321, 1, "87f082c644e064406790aea9f73b3df3f1b9a3aa076468894b91b72db9a98cb6")
