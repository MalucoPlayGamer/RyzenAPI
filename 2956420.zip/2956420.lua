-- Lua provided by RyzenAPI
-- Game: It Happened At Night

-- MAIN APPLICATION
addappid(2956420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956421, 1, "c83764adb95ce7afceeb25bf025ba1d3ddd4fede5584e3b62c9991a58f9e10f7")

