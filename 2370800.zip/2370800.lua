-- Lua provided by RyzenAPI
-- Game: addappid(2370800)

-- MAIN APPLICATION
addappid(2370800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370801, 1, "8de0fedcceb802d5f6f69b2243337c4cac42172dfb27668429db1df236c8ad84")
