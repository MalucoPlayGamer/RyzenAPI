-- Lua provided by RyzenAPI
-- Game: 999550

-- MAIN APPLICATION
addappid(999550)

-- MAIN APP DEPOTS / PACKAGES
addappid(999550,0,"bff3cdde9a90c03e51e093175ad1bc02997a73ba43d2f125be14ad659b8d8a10")

