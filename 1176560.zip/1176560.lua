-- Lua provided by RyzenAPI
-- Game: The Orphan A Tale of An Errant Ghost - Hidden Object Game

-- MAIN APPLICATION
addappid(1176560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176561, 1, "8f2dd092f34ee3772d2c6230177af09ba765441cbdf6e118f75642e3f4246907")

