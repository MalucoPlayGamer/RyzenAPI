-- Lua provided by RyzenAPI
-- Game: Game: Helping the Hotties

-- MAIN APPLICATION
addappid(1590730)
-- Game: addappid(1590730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590731, 1, "5876dec4dc90e99b6600a54de468412c430f52b56b4e9c87002341f95ee73151")
addappid(2233070, 0, "4e0a66b4f47be971a467e0fd3bee92686a6f4b9e891d97ed841689b9c12705b4")
addappid(2483780, 0, "95e496427ddf406ca5a911325e67d646ef7b65e5257eb16457ef010b87b96fdc")
