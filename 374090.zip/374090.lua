-- Lua provided by RyzenAPI
-- Game: 374090

-- MAIN APPLICATION
addappid(374090)
-- Game: addappid(374090)

-- MAIN APP DEPOTS / PACKAGES
addappid(374091, 1, "0c8e96a85bc6a502751c3350fc129147e1e342dbc318e53c78a36b0dbe3023c1")
