-- Lua provided by RyzenAPI
-- Game: Meditation VR

-- MAIN APPLICATION
addappid(1301850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1301851, 1, "868d7c3880822d13988cf4c2ca1d863e513e473fe99e7ce03fb00582765a0afc")

