-- Lua provided by RyzenAPI
-- Game: Meditation VR

-- MAIN APPLICATION
addappid(1301850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301851, 1, "868d7c3880822d13988cf4c2ca1d863e513e473fe99e7ce03fb00582765a0afc")
