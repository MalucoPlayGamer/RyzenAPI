-- Lua provided by SkyAPI 
-- Game: Starship Rubicon
addappid(372030)
addappid(372031, 1, "77976ca28a72b6cdbd138967600b3ffcf23a188adac9708a2e8a1ea9e05b626d")
addappid(372032, 1, "2f183056eef84fb3406b78ba2976e975bf1fec2158289a577a47f9c6c7a42967")
addappid(372033, 1, "2a094b8e00baad44f4e1d9b1fd1a598837813519c3ead5ac3af2237b9e8f7a87")
addappid(372034, 1, "8bc7bf70ec78ab86d9b064e6578eac3fc0c919a0468c8843d6d698b20bdcd6e8")
