-- Lua provided by RyzenAPI
-- Game: paradise of desire Soundtrack

-- MAIN APPLICATION
addappid(2323030)
-- Game: addappid(2323030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323031, 1, "c11e1802e23a53890a8fe6e00ab70ed48161449656d091a297a08c4cb62516e3")
