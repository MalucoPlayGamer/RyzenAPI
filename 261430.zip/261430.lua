-- Lua provided by RyzenAPI
-- Game: AION Free-to-Play

-- MAIN APPLICATION
addappid(261430)
addappid(424580)
addappid(425190)
addappid(425200)
addappid(641010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(261431, 1, "b4881734fd685a3d71fa2fc21b70cc902788538c31ac14c5cb512de22a718c74")
addappid(261432, 1, "a21de6ab27b3685ad43c695d971e7ddef3311da2b7f8a7de1bb4de9b6ca35656")
addappid(261433, 1, "ee63e7e1347983cd990398397933680d0026d315b78abd293b41237bde034e02")
addappid(261434, 1, "a784919de0b847777679f1774a515547456e54ba7844015e461686a1acd350e6")

