-- Lua provided by RyzenAPI
-- Game: PNGTuber Plus

-- MAIN APPLICATION
addappid(2596880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596881, 1, "2f1a5eee458ff1750d9626098b0acc53a17f93fa9d95b2b9ec3b2bc3e69ab382")

