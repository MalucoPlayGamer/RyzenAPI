-- Lua provided by RyzenAPI
-- Game: Dominator Idle

-- MAIN APPLICATION
addappid(2219690)
-- Game: addappid(2219690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219691, 1, "688ba64d6848d02d2338ee632084d672d985909faf62c2bca95569e76c974c4c")
