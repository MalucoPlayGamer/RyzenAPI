-- Lua provided by RyzenAPI
-- Game: Star Trek: Infinite

-- MAIN APPLICATION
addappid(1622900)
addappid(2596090)
addappid(2620820)
addappid(2651890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1622901, 1, "cc25bcc3d22998bad6712331e5c6608e9a02121a956f0afa8706b8852c5694b3")
addappid(1622902, 1, "a1cc400e51a0e4be633a82c78b506880222c68c066f6917896be9e05aab250d0")
addappid(2620810, 0, "247df62cbe4f5838ca8b1cc00ef78fbe9b94f7a0c2c8a43f653b8487497f9a0d")

