-- Lua provided by RyzenAPI
-- Game: addappid(1693990)

-- MAIN APPLICATION
addappid(1693990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693991, 1, "72910fd7517c7bbc31cbb609184e82ac4e3ba3201f765af7aff1f3e6e4d66621")
