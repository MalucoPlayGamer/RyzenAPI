-- Lua provided by RyzenAPI
-- Game: World War: Rome - Free Strategy Game

-- MAIN APPLICATION
addappid(2685070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685071, 1, "9fdef893e81bae96bd36cf413d5a2e9fffc315f066adf0512e10f1fb42826df1")
