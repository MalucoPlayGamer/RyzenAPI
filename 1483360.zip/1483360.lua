-- Lua provided by RyzenAPI
-- Game: VR Library: Beyond Reading

-- MAIN APPLICATION
addappid(1483360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483361, 1, "ffedc2af37ddf60fdc0f7c479d8ce9af4e46d826a8e71bb6912b00c5ba6e15cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
