-- Lua provided by RyzenAPI
-- Game: VR Library: Beyond Reading

-- MAIN APPLICATION
addappid(1483360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483361, 1, "ffedc2af37ddf60fdc0f7c479d8ce9af4e46d826a8e71bb6912b00c5ba6e15cc")
