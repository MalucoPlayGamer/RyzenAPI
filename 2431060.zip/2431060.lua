-- Lua provided by RyzenAPI
-- Game: Game: Toxic Crusaders Demo

-- MAIN APPLICATION
addappid(2431060)
-- Game: addappid(2431060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431061, 1, "fd3f2537f062abb5c6dd9ebfd6117df332b58cf35bbd3c90f58d5ace9134272b")
