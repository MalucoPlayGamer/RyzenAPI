-- Lua provided by RyzenAPI
-- Game: addappid(941480)

-- MAIN APPLICATION
addappid(941480)

-- MAIN APP DEPOTS / PACKAGES
addappid(941481, 1, "9a907e52e43d37687faeacf3a9c9220de1e5daab869d86e38e215a2a06360137")
