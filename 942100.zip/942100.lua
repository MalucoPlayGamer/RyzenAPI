-- Lua provided by RyzenAPI
-- Game: Game: Tomboys Need Love Too! Soundtrack

-- MAIN APPLICATION
addappid(942100)
-- Game: addappid(942100)

-- MAIN APP DEPOTS / PACKAGES
addappid(942101, 1, "0037cf2db7c6899a059f6e8623417acd5e2d9f7fe9bd13009df40cc16872b895")
addappid(942102, 1, "df3a7a8116b44ad39b52387fac77f65e36f0f2e9063db238946093a03c1d51ee")
