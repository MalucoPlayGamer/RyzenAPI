-- Lua provided by RyzenAPI
-- Game: Star Wars Outlaws

-- MAIN APPLICATION
addappid(2842040)
addappid(3112310)
addappid(3261290)
addappid(3261340)
addappid(3271140) -- Star Wars Outlaws - Season Pass
addappid(3271150)
addappid(3271160) -- Star Wars Outlaws - Ultimate Pack
addappid(3271170)
addappid(3271180) -- Star Wars Outlaws - Forrest Commando
addappid(3271190)
addappid(3271200) -- Star Wars Outlaws - Hunters Legacy
addappid(3271210)
addappid(3271230) -- Star Wars Outlaws - Cartel Ronin
addappid(3271240)
addappid(3271460)
addappid(3394020)
addappid(3515960)
addappid(3541410)
addappid(3702240) -- Star Wars Outlaws - Naboo Nobility Bundle
addappid(3702250)
addappid(3702260) -- Star Wars Outlaws - Desert Nomad Bundle
addappid(3702270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2842041, 1, "bed1b2aedb9b823e084bde3a15663caf8f50feaadd104bba0c7e474540a11f43")
addappid(2842042, 1, "110e9180cab6db688b21cc6f16820d8197b333d0c1d88b66da81d43753a9c786")
addappid(2842043, 1, "2d98d4345bb461b3ee9574d5e4f00cf62e968042031e7d7361b3d15d09282788")
addappid(2842045, 1, "845fbe248a74375c3dda44984552af44018332d3b7f355dce4d1c833727e0a42")
addappid(3271130, 0, "cd4259d93979d9d480227cf581dbb3855b238747fa76988d8c94da591300669e")
addappid(3541390, 0, "a2c323e9b71ce1d184500fedc2ddaf67f9f96af0f57324757cb7f9949f71944a")

