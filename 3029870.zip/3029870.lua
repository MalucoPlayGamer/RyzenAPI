-- Lua provided by RyzenAPI
-- Game: 3029870

-- MAIN APPLICATION
addappid(3029870)
-- Game: addappid(3029870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029877,0,"4706e0c3ecbbe0b6144e0f33881ac34a9e9c644b946a48534e215ba88b0c8f5c")
