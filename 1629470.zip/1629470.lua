-- Lua provided by RyzenAPI
-- Game: Project Grove: Prologue

-- MAIN APPLICATION
addappid(1629470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629471, 1, "fa4589dd6352194a5895c10b72b0b073c5826b0f4ad6a5cfa43c0400959fe74b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
