-- Lua provided by RyzenAPI
-- Game: addappid(1629470)

-- MAIN APPLICATION
addappid(1629470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629471, 1, "fa4589dd6352194a5895c10b72b0b073c5826b0f4ad6a5cfa43c0400959fe74b")
