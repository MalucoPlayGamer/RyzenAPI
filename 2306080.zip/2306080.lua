-- Lua provided by RyzenAPI
-- Game: 2306080

-- MAIN APPLICATION
addappid(2306080)
-- Game: addappid(2306080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306081, 1, "eeabc71067b624350d764c762c37f6d93de59ff94c670c2d58673438d19a565a")
