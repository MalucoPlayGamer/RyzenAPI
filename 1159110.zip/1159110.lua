-- Lua provided by RyzenAPI
-- Game: Aeon's End - Soundtrack

-- MAIN APPLICATION
addappid(1159110)
-- Game: addappid(1159110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159110,0,"23b41191b701ea553568a7123861c0cb1741c1029fb19e71c0b3c22235e393c4")
