-- Lua provided by RyzenAPI
-- Game: Game: Klang 2

-- MAIN APPLICATION
addappid(1111600)
-- Game: addappid(1111600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111601, 1, "3976e097e43e0d4600de94ef285626dd743904133e9e44620d8890a9c63bb417")
