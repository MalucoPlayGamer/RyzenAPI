-- Lua provided by SkyAPI 
-- Game: Kalzoon
addappid(2206690)
addappid(2206691, 1, "a7e8eec91e49abc02ea73c6056ad01a42f3dd3395497fe06df1240103fe6475e")
