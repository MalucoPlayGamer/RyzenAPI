-- Lua provided by RyzenAPI
-- Game: Kalzoon

-- MAIN APPLICATION
addappid(2206690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206691, 1, "a7e8eec91e49abc02ea73c6056ad01a42f3dd3395497fe06df1240103fe6475e")

