-- Lua provided by RyzenAPI
-- Game: Chlorofell

-- MAIN APPLICATION
addappid(3476180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3476181, 1, "f3fe17a4f43784295f26499a187d94d30b804df7a361ddb2934388d91e2342fd")
