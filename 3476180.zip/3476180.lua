-- Lua provided by RyzenAPI
-- Game: Chlorofell

-- MAIN APPLICATION
addappid(3476180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3476181, 1, "f3fe17a4f43784295f26499a187d94d30b804df7a361ddb2934388d91e2342fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
