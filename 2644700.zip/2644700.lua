-- Lua provided by RyzenAPI
-- Game: addappid(2644700)

-- MAIN APPLICATION
addappid(2644700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644701, 1, "a21a5096493f58a97aa26b5e121b78f9a637d57eb2cb8af14623e1eb3dd3c992")
