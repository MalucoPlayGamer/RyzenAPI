-- Lua provided by RyzenAPI
-- Game: Noir Mafia Simulator: 1960s American Crime

-- MAIN APPLICATION
addappid(4457110)

-- MAIN APP DEPOTS / PACKAGES
addappid(4457111,0,"4ffa3b5e68024a4ac3b394c8f6ad0356e1aceaaf96c9c2a9ad5e4680f42377b1")

