-- Lua provided by RyzenAPI
-- Game: ESCAPE FROM BOYKISSER

-- MAIN APPLICATION
addappid(2708280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708281, 1, "a9d2ff9cb02a90e64fda772adb7810588d98c52ed0f5d473495b4c97d13be57a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
