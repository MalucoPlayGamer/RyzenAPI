-- Lua provided by RyzenAPI
-- Game: 2708280

-- MAIN APPLICATION
addappid(2708280)
-- Game: addappid(2708280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708281, 1, "a9d2ff9cb02a90e64fda772adb7810588d98c52ed0f5d473495b4c97d13be57a")
