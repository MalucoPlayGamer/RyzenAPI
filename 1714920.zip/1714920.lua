-- Lua provided by RyzenAPI
-- Game: Charon's Staircase

-- MAIN APPLICATION
addappid(1714920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714921, 1, "5b153342529a705023324fd48e350cf88dc033d14581cfc767ad04d562587b7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2218490)
