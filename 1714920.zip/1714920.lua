-- Lua provided by RyzenAPI 
-- Game: Charon's Staircase
addappid(1714920)
addappid(1714921, 1, "5b153342529a705023324fd48e350cf88dc033d14581cfc767ad04d562587b7c")
