-- Lua provided by RyzenAPI
-- Game: Arma Reforger Soundtrack

-- MAIN APPLICATION
addappid(1982980)
-- Game: addappid(1982980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982981, 1, "fb9b19f4018873d6112446a8991e8911cd8d4452a8c7bd27f4251b07638e89d5")
addappid(1982982, 1, "305012a57de8f65ba31415383f9ef1e29a6e6abcee5d86bcf04cac01b927906e")
