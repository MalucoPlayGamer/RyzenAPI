-- Lua provided by RyzenAPI
-- Game: addappid(1912101)

-- MAIN APPLICATION
addappid(1912101)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912101,0,"79c779ff3d674eed9bffcebd09dcc9aad8f8a21111e58d14886c7ff31db21def")
