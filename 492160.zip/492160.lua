-- Lua provided by RyzenAPI
-- Game: 3D Pool

-- MAIN APPLICATION
addappid(492160)
-- Game: addappid(492160)

-- MAIN APP DEPOTS / PACKAGES
addappid(492161, 1, "0c341636264020710be56dba1f0a36e53bf19d2d3fba79df64ed7ffc66fb4c91")
