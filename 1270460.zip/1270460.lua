-- Lua provided by RyzenAPI
-- Game: 1270460

-- MAIN APPLICATION
addappid(1270460)
-- Game: addappid(1270460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270461, 1, "ff5d06fc071d865fe68f0be5f5405fd1bb486c14d17a57a6915b8bb3541369a9")
