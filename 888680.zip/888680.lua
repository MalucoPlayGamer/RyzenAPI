-- Lua provided by RyzenAPI
-- Game: 888680

-- MAIN APPLICATION
addappid(888680)
-- Game: addappid(888680)

-- MAIN APP DEPOTS / PACKAGES
addappid(888681, 1, "d4e91323927227086d2e441bf497aeaf334e64b20045abb40621fa48836d2b31")
