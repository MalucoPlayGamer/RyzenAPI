-- Lua provided by SkyAPI 
-- Game: Warp Factor
addappid(1254200)
addappid(1254201, 1, "e98e374bfbd3d6258c8f27dd74a7fd9f110dca52030c531239dbc0c1b2b7a6c1")
