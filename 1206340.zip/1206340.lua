-- Lua provided by RyzenAPI
-- Game: Hades Original Soundtrack

-- MAIN APPLICATION
addappid(1206340)
-- Game: addappid(1206340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206341, 1, "d0cbd567d11fca873af7c65482965f6ef164ad4b58b208408ba7a05e61ee49a6")
