-- Lua provided by RyzenAPI
-- Game: addappid(301170)

-- MAIN APPLICATION
addappid(301170)

-- MAIN APP DEPOTS / PACKAGES
addappid(301171, 1, "f0a3b76190ab74d76a4778b22e7a331cd0309f0d7dbe689c716f74fc34095580")
