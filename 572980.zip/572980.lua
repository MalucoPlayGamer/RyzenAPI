-- Lua provided by RyzenAPI
-- Game: Star Dust: The Book of Earth (VR)

-- MAIN APPLICATION
addappid(572980)

-- MAIN APP DEPOTS / PACKAGES
addappid(572981, 1, "c2903dc0c6449d50e670cbd82c21f7aa7639ffc320aa4fa316f8123e80c9528e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
