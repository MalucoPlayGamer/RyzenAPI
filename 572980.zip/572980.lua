-- Lua provided by RyzenAPI
-- Game: Star Dust: The Book of Earth (VR)

-- MAIN APPLICATION
addappid(572980)
-- Game: addappid(572980)

-- MAIN APP DEPOTS / PACKAGES
addappid(572981, 1, "c2903dc0c6449d50e670cbd82c21f7aa7639ffc320aa4fa316f8123e80c9528e")
