-- Lua provided by RyzenAPI 
-- Game: Bridge of Dawn
addappid(1750410)
addappid(1750411, 1, "a005f56c16c982b3e00c852b4583684c1f90d03e629c0716b794676633f6bbbd")
