-- Lua provided by RyzenAPI
-- Game: 1169880

-- MAIN APPLICATION
addappid(1169880)
-- Game: addappid(1169880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169881, 1, "c64f9641d6e556b8c9548b6686704aeeee745fc33bb1aac6969cb5d57ffb9853")
