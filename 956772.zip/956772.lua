-- Lua provided by RyzenAPI
-- Game: Sima Shi - Officer Ticket / 司馬師使用券

-- MAIN APPLICATION
addappid(956772)

-- MAIN APP DEPOTS / PACKAGES
addappid(956772,0,"eae3cfcd478a45cd8627e48c0a251831c00def73d7b6afcbc5fcf3791e39a697")
