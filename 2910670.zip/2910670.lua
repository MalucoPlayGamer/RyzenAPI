-- Lua provided by RyzenAPI
-- Game: 2910670

-- MAIN APPLICATION
addappid(2910670)
-- Game: addappid(2910670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910671, 1, "468de3990e06c48e8d7d71dc4e28c757a8ca653857ffe768333ccfd7b3e59367")
