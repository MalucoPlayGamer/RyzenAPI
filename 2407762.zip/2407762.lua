-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2407762)
-- Game: addappid(2407762)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407762,0,"af20c422ac0922542cd78077667cb8c907df510e2180842c58a067107198ac68")
