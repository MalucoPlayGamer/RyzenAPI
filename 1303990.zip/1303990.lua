-- Lua provided by SkyAPI 
-- Game: Mini Motor Racing X
addappid(1303990)
addappid(1303991, 1, "16ecdc1e1721324eded6b839bdcf271f188ce64158da4db892858b4db29ccdb5")
