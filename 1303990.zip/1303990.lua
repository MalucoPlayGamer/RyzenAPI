-- Lua provided by RyzenAPI
-- Game: Mini Motor Racing X

-- MAIN APPLICATION
addappid(1303990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303991, 1, "16ecdc1e1721324eded6b839bdcf271f188ce64158da4db892858b4db29ccdb5")
