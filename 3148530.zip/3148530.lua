-- Lua provided by SkyAPI 
-- Game: AppID 3148530
addappid(3148530)
addappid(3148531, 1, "d54d46611142c743ec965905f06684a28cff3ccfc052714ec67a3b07cf27e704")
