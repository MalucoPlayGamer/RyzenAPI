-- Lua provided by RyzenAPI
-- Game: addappid(2512090)

-- MAIN APPLICATION
addappid(2512090)
addappid(2679510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512091, 1, "2b55fc8e622845147ab6ab2b7fd553eef02ef0fd383be1c49b5fe9acea2f95b9")
addappid(2512093, 1, "0a23c0a99732f66a1317934a2ae2cbfb0b2b89550f9828d80fd63007a0fb80f9")
