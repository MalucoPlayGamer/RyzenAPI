-- Lua provided by RyzenAPI
-- Game: NARAKA: BLADEPOINT

-- MAIN APPLICATION
addappid(1203220)
addappid(1637170)
addappid(1643990)
addappid(2593020)
addappid(2701570)
addappid(2731960)
addappid(2731970)
addappid(2731980)
addappid(2732000)
addappid(2732010)
addappid(3371820)
addappid(3371830)
addappid(3588860)
addappid(3610450)
addappid(3610460)
addappid(3610470)
addappid(3610480)
addappid(3610490)
addappid(3659600)
addappid(3659610)
addappid(3659650)
addappid(3659670)
addappid(3659680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203221,0,"788b93ea9ea92552d334bdb7fa9caf5f21f98dded4a670c54926bf0a2bd1d74f")
addappid(1203222,0,"7548566bef2e67e87b06999b07ae2db2d4e45b0c1738fb1734c4035bcd065cb5")
addappid(1637171,0,"63589232719b9b6c05930000563883180320b57145ea3cc62d9ed5d31341c8ef")

