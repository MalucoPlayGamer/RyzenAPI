-- Lua provided by RyzenAPI
-- Game: addappid(1203220)

-- MAIN APPLICATION
addappid(1203220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203221, 1, "788b93ea9ea92552d334bdb7fa9caf5f21f98dded4a670c54926bf0a2bd1d74f")
