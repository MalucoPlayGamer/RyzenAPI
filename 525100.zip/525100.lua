-- Lua provided by RyzenAPI
-- Game: SLIVER.tv

-- MAIN APPLICATION
addappid(525100)

-- MAIN APP DEPOTS / PACKAGES
addappid(525101, 1, "62cecdaf737358ccc3459acb7df924e8b5a7f91cec7c3143efb20123ea132484")
