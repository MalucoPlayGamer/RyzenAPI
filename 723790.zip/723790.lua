-- Lua provided by RyzenAPI
-- Game: The Pirate: Plague of the Dead

-- MAIN APPLICATION
addappid(723790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(723791, 1, "913168fbb46bd053b3aed00a6d98bf076138280bccef26529488501ed57c66b2")
addappid(723792, 1, "cf6683487bc235bdf1366f3c48b139fcea9117eff83f67fc3a0ea56b3e327005")
addappid(723793, 1, "e8cac7a950cc23eb14f941692485b394609d27cbf42c33d40ded472a5561b63e")
