-- Lua provided by RyzenAPI
-- Game: Game: Chroma Lab

-- MAIN APPLICATION
addappid(587470)
-- Game: addappid(587470)

-- MAIN APP DEPOTS / PACKAGES
addappid(587471, 1, "b6e3d69d5c0951f6ef2aa9ac0d469179066021882d975f2cca0934e17d940e78")
