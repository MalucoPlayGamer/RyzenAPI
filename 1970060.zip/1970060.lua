-- Lua provided by RyzenAPI
-- Game: Tomboy Adventure

-- MAIN APPLICATION
addappid(1970060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970061, 1, "b47dccabaa73d190cb551bb9051e9c2b7060b9ede7a27e274a9f3606e0b5f022")
