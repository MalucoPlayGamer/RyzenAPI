-- Lua provided by RyzenAPI 
-- Game: Tomboy Adventure
addappid(1970060)
addappid(1970061, 1, "b47dccabaa73d190cb551bb9051e9c2b7060b9ede7a27e274a9f3606e0b5f022")
