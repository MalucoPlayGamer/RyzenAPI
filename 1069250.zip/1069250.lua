-- Lua provided by RyzenAPI
-- Game: Eslander

-- MAIN APPLICATION
addappid(1069250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1069251, 1, "6bcfa70ba9b005366b9a4fa5f3eeb314a59422f4b0a77bdc988917f212211b54")

