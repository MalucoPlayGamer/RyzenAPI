-- Lua provided by RyzenAPI
-- Game: Game: AppID 1069250

-- MAIN APPLICATION
addappid(1069250)
-- Game: addappid(1069250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069251, 1, "6bcfa70ba9b005366b9a4fa5f3eeb314a59422f4b0a77bdc988917f212211b54")
