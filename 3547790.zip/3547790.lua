-- Lua provided by RyzenAPI
-- Game: My Wife

-- MAIN APPLICATION
addappid(3547790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3547791, 1, "fdca45e5e4ad9e268edfc1e290cd7842c859dac626b2aa9cfa1bb53d7705614a")
