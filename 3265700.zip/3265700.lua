-- Lua provided by RyzenAPI
-- Game: Vampire Crawlers

-- MAIN APPLICATION
addappid(4564300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265700, 1, "20f9ef13db9be4cd2b66262d177c6107c74912a164f5c1e519d194e090bc57e6")
addappid(3265701, 1, "1e7525ea73ba61b029745bf11a16c0f88090e25fd8a3841cf7c06879636857f8") -- (windows,linux)
addappid(3265702, 1, "2753b9f6a521270a2c776ff684a32c6bfef84ab95fa241f60c2392c13776032b") -- (macos)
addappid(4564301, 1, "68a61d5b00871c3221e0b8e27714dce7ce0890a71de1466912720b7fbc151d7d")
addappid(4564302, 1, "021931fab702f97f685bc174bbdcdbedb1737f00cc992cdeb3adfdb004b894bf")

