-- Lua provided by SkyAPI 
-- Game: DJMAX RESPECT V - V EXTENSION V Original Soundtrack
addappid(2681830)
addappid(2681831, 1, "9367b80dfec7be8733351fb4a199c44bb3a23f3c812aea1a160ac9e56dd3cd9f")
addappid(2681832, 1, "3f276992b7d7a57e6d4ab6b5ea81a36f919806798368cfe32a0e68cd7e236c8e")
