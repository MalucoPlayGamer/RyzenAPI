-- Lua provided by RyzenAPI
-- Game: 2066130

-- MAIN APPLICATION
addappid(2066130)
-- Game: addappid(2066130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066131, 1, "572083557ef8d4b889f7e638dc5e5ebe95eef501d68b5d21f2906c64ca76b386")
