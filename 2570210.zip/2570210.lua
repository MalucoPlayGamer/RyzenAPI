-- Lua provided by RyzenAPI
-- Game: Eden Crafters

-- MAIN APPLICATION
addappid(2570210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2570211, 1, "a6d9fd6c7cb73b8737246837d4b5446f3af752492a3a7adec43c60b3c590ca34")

