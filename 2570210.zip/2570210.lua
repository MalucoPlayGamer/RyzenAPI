-- Lua provided by RyzenAPI
-- Game: Eden Crafters

-- MAIN APPLICATION
addappid(2570210)
-- Game: addappid(2570210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570211, 1, "a6d9fd6c7cb73b8737246837d4b5446f3af752492a3a7adec43c60b3c590ca34")
