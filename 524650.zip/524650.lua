-- Lua provided by RyzenAPI
-- Game: addappid(524650)

-- MAIN APPLICATION
addappid(524650)

-- MAIN APP DEPOTS / PACKAGES
addappid(524654,0,"16eefc7c08b290c564fea966f7fc2ba0ce4c4cc2ce28f2776d08966934795ae2")
addappid(524655,0,"9ab59e8dcef050423d868e2c9fc21d598acdee5aa484a6aacc44be221d5e4755")
addappid(524656,0,"920fe1af74f5d9edd871ec6da72849ceb1e8492f4a7bcafcee6dd99223256cfa")
