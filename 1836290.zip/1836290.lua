-- Lua provided by RyzenAPI
-- Game: addappid(1836290)

-- MAIN APPLICATION
addappid(1836290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836291, 1, "1dc3958dcfac58b28c065b409dcc9e7e7c681cff6ed00b9b09d4c8fb7c483bee")
