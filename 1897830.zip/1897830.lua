-- Lua provided by SkyAPI 
-- Game: Sex Diary - Double Trouble Teacher
addappid(1897830)
addappid(1897831, 1, "3d5a2c5b3d0d3bdd8c03ae2e7d18bb0bb76607d0a305f894fb9aaaaac5d25eb5")
