-- Lua provided by RyzenAPI
-- Game: Game: Sunday Gold

-- MAIN APPLICATION
addappid(1969440)
-- Game: addappid(1969440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969441, 1, "3d3854ad783ef775f94954558445d885fe14a80465c151ddf38dcda92276fda9")
