-- Lua provided by RyzenAPI
-- Game: addappid(3416150)

-- MAIN APPLICATION
addappid(3416150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416151, 1, "891ca21ea4640eef0bcd4d12705b4cf7d482af0d1f67f12df9d023b45a91db91")
