-- Lua provided by RyzenAPI
-- Game: Seed of the Dead: Sweet Home

-- MAIN APPLICATION
addappid(1566390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1566391, 1, "5903c7ae493cd5f1c18b10794a90ca4aac94973bdd75cc92c94abb11d88ec4f0")
addappid(2452270, 0, "de98419d69bd6fcb0603958d0ed38592693a6277bc986be886c3beb5ed63db20")

