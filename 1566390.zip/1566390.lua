-- Lua provided by RyzenAPI
-- Game: Seed of the Dead: Sweet Home

-- MAIN APPLICATION
addappid(1566390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566391, 1, "5903c7ae493cd5f1c18b10794a90ca4aac94973bdd75cc92c94abb11d88ec4f0")
addappid(2452270, 0, "de98419d69bd6fcb0603958d0ed38592693a6277bc986be886c3beb5ed63db20")
