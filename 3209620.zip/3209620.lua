-- Lua provided by RyzenAPI
-- Game: The Ethereal Dream

-- MAIN APPLICATION
addappid(3209620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209621, 1, "d64ba3118290919ce397e3e051d34e105f67cd15bd57339bdf01d8998c226ce2")

