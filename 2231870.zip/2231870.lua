-- Lua provided by RyzenAPI
-- Game: Persha and the Magic Labyrinth -Arabian Nyaights-

-- MAIN APPLICATION
addappid(2231870)
addappid(2305540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231871, 1, "d26b778b16544466d625912a19f9045b1b5d94f2c07f7525c0d00ce208fd9a6b")

