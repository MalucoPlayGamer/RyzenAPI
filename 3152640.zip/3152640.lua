-- Lua provided by RyzenAPI 
-- Game: AppID 3152640
addappid(3152640)
addappid(3152641, 1, "fdbd4ba32cf17c305093992f8f81c62241d70389eab0d89822d10d2a746973d2")
