-- Lua provided by RyzenAPI
-- Game: Game: The Corruption Within

-- MAIN APPLICATION
addappid(1395400)
-- Game: addappid(1395400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395401, 1, "d9a1f1f2d8af6dd00bd295fcad54842713504dc892fe4c274270e6c9b0fafdd5")
