-- Lua provided by RyzenAPI
-- Game: 2442410

-- MAIN APPLICATION
addappid(2442410)
-- Game: addappid(2442410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442411, 1, "aa7c1ceb827fc6c0ab562c94f3c597b72668e12af60bf45a92c8462d70810054")
