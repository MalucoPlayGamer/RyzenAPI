-- Lua provided by RyzenAPI 
-- Game: Te Encontré
addappid(1808080)
addappid(1808081, 1, "d1b5889bea08a5da73c6c5657dcee075bab7cb766909e995a15abcacef65fa98")
