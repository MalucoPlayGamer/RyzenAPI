-- Lua provided by RyzenAPI
-- Game: Shadow Warrior Classic Redux

-- MAIN APPLICATION
addappid(225160)

-- MAIN APP DEPOTS / PACKAGES
addappid(225161, 1, "6b711e915571ffb0e5fcc0f915629d94fa98bc2cc8464baa055621cf6190417a")
addappid(225162, 1, "d1b5da837d4adbb976cac6c0aed0e90000094a10e365983bf37f3d2e54d8c7e8")
addappid(225163, 1, "6f92ea51f09e80e21dde00a98baa99167653e899dc0b33bfddf38120fb385320")
addappid(225164, 1, "48d72880996e43f80c9fc1a640eb148d0ab5fd0eb990ebc011cd7fe521240976")
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
