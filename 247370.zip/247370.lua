-- Lua provided by RyzenAPI
-- Game: Mutant Mudds Deluxe

-- MAIN APPLICATION
addappid(247370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(247371, 1, "c783dc30384b8abb5d03f0864239abde72bab0f6189432daf6cc71748932a1f5")

