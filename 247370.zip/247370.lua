-- Lua provided by RyzenAPI
-- Game: Game: Mutant Mudds Deluxe

-- MAIN APPLICATION
addappid(247370)
-- Game: addappid(247370)

-- MAIN APP DEPOTS / PACKAGES
addappid(247371, 1, "c783dc30384b8abb5d03f0864239abde72bab0f6189432daf6cc71748932a1f5")
