-- Lua provided by RyzenAPI 
-- Game: Mutant Mudds Deluxe
addappid(247370)
addappid(247371, 1, "c783dc30384b8abb5d03f0864239abde72bab0f6189432daf6cc71748932a1f5")
