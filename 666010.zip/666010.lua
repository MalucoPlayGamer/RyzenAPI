-- Lua provided by RyzenAPI
-- Game: AppID 666010

-- MAIN APPLICATION
addappid(666010)

-- MAIN APP DEPOTS / PACKAGES
addappid(666011, 1, "17e69241f7b3aed3a932d326d13ec76d54043c829e9992d9e4062afe8c762623")
addappid(666012, 1, "64615015352855dad7801741a0b68d27b64dc8d9cd608e5c71408bd92ef3502c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
