-- Lua provided by RyzenAPI
-- Game: addappid(2635110)

-- MAIN APPLICATION
addappid(2635110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635111, 1, "5f8958a5dd9319806040b123b0bee59c5439a6c2e8c0e5689d2f33c74b9e5dda")
