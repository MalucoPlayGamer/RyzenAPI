-- Lua provided by SkyAPI 
-- Game: I WANT TO DIE
addappid(2635110)
addappid(2635111, 1, "5f8958a5dd9319806040b123b0bee59c5439a6c2e8c0e5689d2f33c74b9e5dda")
