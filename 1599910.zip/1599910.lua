-- Lua provided by RyzenAPI
-- Game: Space Worthy

-- MAIN APPLICATION
addappid(1599910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1599911, 1, "1ced71d02275cd9218a7c03e51844a8bb77abab4f8975c529595f658e84aca9c")

