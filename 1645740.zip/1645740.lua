-- Lua provided by RyzenAPI
-- Game: [ECHOSTASIS] Demo

-- MAIN APPLICATION
addappid(1645740)
-- Game: addappid(1645740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645741, 1, "7acccfc331d6a7fab724453f61e95d1f40cbe71220ab5dbf8acd601cd45326a3")
