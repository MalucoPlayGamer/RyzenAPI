-- Lua provided by RyzenAPI 
-- Game: The Unknown Demo
addappid(2671660)
addappid(2671661, 1, "e3c6c823c2207b0c878e907eb41c70706e501f10484599a5e2e9e2a81981d885")
