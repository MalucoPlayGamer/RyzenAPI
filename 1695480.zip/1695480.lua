-- Lua provided by RyzenAPI
-- Game: 1695480

-- MAIN APPLICATION
addappid(1695480)
-- Game: addappid(1695480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695481, 1, "b59d77851c0b57bda28b3977e63742c51f5210f3a531a51f3e85a5453fd6063b")
addappid(1695482, 1, "010108daeecbae2e2bf6f47471a54dfd9a983df8a66d2ab1f8b3ce20a0fc0623")
