-- Lua provided by RyzenAPI
-- Game: Game: AppID 430290

-- MAIN APPLICATION
addappid(430290)
-- Game: addappid(430290)

-- MAIN APP DEPOTS / PACKAGES
addappid(430291, 1, "8a7d788e0e82cae141d95051f9380b714a1566c8d545374d5551f65eeca53b07")
