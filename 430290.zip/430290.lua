-- Lua provided by RyzenAPI
-- Game: AppID 430290

-- MAIN APPLICATION
addappid(430290)

-- MAIN APP DEPOTS / PACKAGES
addappid(430291, 1, "8a7d788e0e82cae141d95051f9380b714a1566c8d545374d5551f65eeca53b07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
