-- Lua provided by RyzenAPI
-- Game: 2875610

-- MAIN APPLICATION
addappid(2875610)
-- Game: addappid(2875610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875611, 1, "639beb8000cf0f91a72c541607879687e6f4dfc8821d5a01d3edfd3ceeebcf89")
