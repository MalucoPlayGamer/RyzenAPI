-- Lua provided by RyzenAPI
-- Game: Numba Deluxe

-- MAIN APPLICATION
addappid(301700)

-- MAIN APP DEPOTS / PACKAGES
addappid(301701, 1, "65e31663c65eb850a91aabd7fb2d4f10f2f85b6bb68e3fe455d994aa97eef24f")
