-- Lua provided by RyzenAPI
-- Game: Numba Deluxe

-- MAIN APPLICATION
addappid(301700)

-- MAIN APP DEPOTS / PACKAGES
addappid(301701, 1, "65e31663c65eb850a91aabd7fb2d4f10f2f85b6bb68e3fe455d994aa97eef24f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
