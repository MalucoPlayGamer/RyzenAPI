-- Lua provided by RyzenAPI
-- Game: Hacker Series

-- MAIN APPLICATION
addappid(536510)

-- MAIN APP DEPOTS / PACKAGES
addappid(536511, 1, "5481827476942e9a4bfbe24f7ca8e5d780a590ba504b81d9f621e6245e723091")
