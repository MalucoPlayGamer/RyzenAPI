-- Lua provided by RyzenAPI
-- Game: Spaceship Trucker

-- MAIN APPLICATION
addappid(671120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(671121, 1, "cc4d5e53f0f4e1f88f4c9390bac9d46a8e2717ae04471ef5179397c84d6294fe")
