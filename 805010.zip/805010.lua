-- Lua provided by RyzenAPI
-- Game: Fierce Tales: Feline Sight Collector's Edition

-- MAIN APPLICATION
addappid(805010)

-- MAIN APP DEPOTS / PACKAGES
addappid(805011,0,"122dab4ba6cc4e19d8bf425f9e8a8bb208d67292eac84988ece1a40e0bca7e83")

