-- Lua provided by RyzenAPI
-- Game: Kingdom Wars 4 - Dead Rising

-- MAIN APPLICATION
addappid(1377570)
-- Game: addappid(1377570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377570,0,"e15ee34e787764d58dfaadd7f9b72ff487bef2b374676cbb9a856e7f206d924d")
