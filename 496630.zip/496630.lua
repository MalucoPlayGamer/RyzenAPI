-- Lua provided by RyzenAPI
-- Game: Empty Horizons

-- MAIN APPLICATION
addappid(496630)
-- Game: addappid(496630)

-- MAIN APP DEPOTS / PACKAGES
addappid(496631, 1, "8d730c47369621e8307f2139d0669f181f2270685f2b28cfdb8e3c5b506a068b")
