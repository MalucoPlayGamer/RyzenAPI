-- Lua provided by RyzenAPI
-- Game: Game: Command & Conquer™ Tiberian Sun™ and Firestorm™

-- MAIN APPLICATION
addappid(2229880)
-- Game: addappid(2229880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229881, 1, "dfc5c85c7364067d2212d5acc81bf086099f528afe1e117a27cc1d08392679e8")
addappid(2229882, 1, "bef10d4e11921cb3fe06929ee4230398407ebb12c95cadda3c6a861ab63549ac")
addappid(2229883, 1, "62223571e4df5555398c6ea1e074270fc48cd5408b81a4762caf2e7d7e24b9a0")
addappid(2229884, 1, "a7086d4091c08171a87e1e97c9634afa98bd66b218b7e18a7b0e87c9fd4b7a13")
addappid(2229885, 1, "1cc7d508a2f9ce1cdbaa42565d5f4ac35b12587ae36eebd492edac35d590f56e")
