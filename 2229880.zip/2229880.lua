-- Lua provided by RyzenAPI
-- Game: Command & Conquer™ Tiberian Sun™ and Firestorm™

-- MAIN APPLICATION
addappid(2229880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229881, 1, "dfc5c85c7364067d2212d5acc81bf086099f528afe1e117a27cc1d08392679e8")
addappid(2229882, 1, "bef10d4e11921cb3fe06929ee4230398407ebb12c95cadda3c6a861ab63549ac")
addappid(2229883, 1, "62223571e4df5555398c6ea1e074270fc48cd5408b81a4762caf2e7d7e24b9a0")
addappid(2229884, 1, "a7086d4091c08171a87e1e97c9634afa98bd66b218b7e18a7b0e87c9fd4b7a13")
addappid(2229885, 1, "1cc7d508a2f9ce1cdbaa42565d5f4ac35b12587ae36eebd492edac35d590f56e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
