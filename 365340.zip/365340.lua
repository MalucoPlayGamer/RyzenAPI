-- Lua provided by RyzenAPI
-- Game: Game: AppID 365340

-- MAIN APPLICATION
addappid(365340)
-- Game: addappid(365340)

-- MAIN APP DEPOTS / PACKAGES
addappid(365341, 1, "bfe8b5449a38e4b63c1d9c97d52b130ef27773b6020345e309665a0063f7be3f")
