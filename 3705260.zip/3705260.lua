-- Lua provided by RyzenAPI
-- Game: Sanitism

-- MAIN APPLICATION
addappid(3705260)
-- Game: addappid(3705260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3705261, 1, "99a17c9db53638490a7b042d34aa9aeb9c9d98940328d456e407e9fb65598707")
