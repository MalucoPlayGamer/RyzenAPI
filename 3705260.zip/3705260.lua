-- Lua provided by RyzenAPI 
-- Game: Sanitism
addappid(3705260)
addappid(3705261, 1, "99a17c9db53638490a7b042d34aa9aeb9c9d98940328d456e407e9fb65598707")
