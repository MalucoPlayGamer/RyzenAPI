-- Lua provided by RyzenAPI
-- Game: The Thing: Tower Defense

-- MAIN APPLICATION
addappid(549670)

-- MAIN APP DEPOTS / PACKAGES
addappid(549671, 1, "f2cafd19543d92c686f95ed7ca0abfe628afa2c23f6be364a3d1c2a9b78994cf")
