-- Lua provided by RyzenAPI
-- Game: FFFL: Brutalball Manager

-- MAIN APPLICATION
addappid(2393810)
addappid(2393850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393811, 1, "0f462cc0740f4d8e91d6cd9875340175328382d150b7f0d8bf67ab674336a304")
