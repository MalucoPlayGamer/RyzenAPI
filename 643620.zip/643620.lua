-- Lua provided by RyzenAPI
-- Game: Night Trap - 25th Anniversary Edition

-- MAIN APPLICATION
addappid(643620)

-- MAIN APP DEPOTS / PACKAGES
addappid(643621, 1, "d36422190d383886d5f1905ad4c71608d95fbd46d278b478053ad10a18ae8980")
