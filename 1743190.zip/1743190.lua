-- Lua provided by SkyAPI 
-- Game: AppID 1743190
addappid(1743190)
addappid(1743191, 1, "9e47503c119ca84d56c5f7315667042ccac8912f31ffdb1fa5401c87eb23e06d")
