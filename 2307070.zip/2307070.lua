-- Lua provided by RyzenAPI
-- Game: 2307070

-- MAIN APPLICATION
addappid(2307070)
-- Game: addappid(2307070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307071, 1, "888772df93e77d66636ce5fd460e65889eab273b9fdf9d5b70a553a4e5219be2")
