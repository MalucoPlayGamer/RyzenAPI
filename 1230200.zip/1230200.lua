-- Lua provided by RyzenAPI
-- Game: Pendula Swing - The Complete Journey

-- MAIN APPLICATION
addappid(1230200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230201, 1, "13489910291b825f3dfcbaf89db94465a5627114b649fd7de4c484914101b9f9")
addappid(1230202, 1, "600a7b3f4003a99305c8ba663da78532ee6bded91333ba52c8585f2c023f5590")

