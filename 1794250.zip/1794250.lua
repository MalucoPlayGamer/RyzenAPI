-- Lua provided by RyzenAPI
-- Game: After Dark VR

-- MAIN APPLICATION
addappid(1794250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794251, 1, "a1c97945e4b216b4591cb35245950dbc06eba6dbb90eb2f9f65ca12d26ac255d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
