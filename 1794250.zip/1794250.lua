-- Lua provided by RyzenAPI
-- Game: After Dark VR

-- MAIN APPLICATION
addappid(1794250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794251, 1, "a1c97945e4b216b4591cb35245950dbc06eba6dbb90eb2f9f65ca12d26ac255d")

