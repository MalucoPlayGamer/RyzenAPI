-- Lua provided by RyzenAPI 
-- Game: Koihime Enbu
addappid(452420)
addappid(452421, 1, "8fdb68b900c18791dff0d87e81df552fc68edbd681a72690341548368a40824f")
