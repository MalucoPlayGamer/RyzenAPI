-- Lua provided by RyzenAPI
-- Game: Koihime Enbu

-- MAIN APPLICATION
addappid(452420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(452421, 1, "8fdb68b900c18791dff0d87e81df552fc68edbd681a72690341548368a40824f")

