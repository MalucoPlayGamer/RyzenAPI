-- Lua provided by SkyAPI 
-- Game: Survive till 100 years old
addappid(3430570)
addappid(3430571, 1, "21406f4bbd4510b47b6459c0939f93ce751edde63b602b3147db0cf4b6d986a9")
