-- Lua provided by RyzenAPI
-- Game: AppID 393930

-- MAIN APPLICATION
addappid(393930)
addappid(504350)

-- MAIN APP DEPOTS / PACKAGES
addappid(393931, 1, "9763fb64599c6bea8a24d17fa3d43083f3f6c18d4dba236c77e9021be26fb3aa")
addappid(393932, 1, "173fcad899732ed61f71e34c6f42b02060255a545be9c2eb85d00b8ff9630ac2")

