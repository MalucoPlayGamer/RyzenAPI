-- Lua provided by RyzenAPI
-- Game: RoShamBo Arena

-- MAIN APPLICATION
addappid(393930)
addappid(504350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(393931, 1, "9763fb64599c6bea8a24d17fa3d43083f3f6c18d4dba236c77e9021be26fb3aa")
addappid(393932, 1, "173fcad899732ed61f71e34c6f42b02060255a545be9c2eb85d00b8ff9630ac2")
