-- Lua provided by RyzenAPI
-- Game: Secrets of Magic: The Book of Spells

-- MAIN APPLICATION
addappid(453780)
-- Game: addappid(453780)

-- MAIN APP DEPOTS / PACKAGES
addappid(453781, 1, "01cbe5d7b2f3890207752d90e28aa331bf27bf0ae2be8781c1259fe48177424e")
