-- Lua provided by RyzenAPI
-- Game: Space Legends: At the Edge of the Universe

-- MAIN APPLICATION
addappid(328880)

-- MAIN APP DEPOTS / PACKAGES
addappid(328881, 1, "9abc5a58c01524cdc1fe8aad31342e640085fe46520b43c9fe180b37b2b5d6bf")
addappid(328882, 1, "3ccc75d984ce20ec49abe18af7ab1d545808fd8e81cf68d7ca4cc401454093df")
addappid(328883, 1, "7858820568cb7111beaf2c72a51f3cb4225a8247004a202cfa505e85df9ccb18")
addappid(328884, 1, "69f00ae948d0e6d333513da2e3a06823cd2e104f3e1312535a953a7efd57296a")
addappid(328885, 1, "be94a829a6eb99408ad6d60f1e40b86ddce8de26dedec99382c85637d72bea28")
addappid(328886, 1, "8fdf78db4ab6a54d81213eed083a3133288f7fd8efaae80d785fc42a9136caf7")
addappid(328887, 1, "e320f86acc5ab442b4dbe99231126aaa86991dca5a732d7a4ef466950b67a521")
addappid(328888, 1, "d7fee38222740d6fcae5780f60c969a1abcba39bc5662dacb19c8c7ae12f2ac9")
addappid(328889, 1, "d992bf7dcef8bc740c77eb9c6195f790550f9bdf9fdef59a502bffef43dfc79a")
addappid(426880, 0, "b43dd8cb4b213f348cfaf3a5b24abb500d2746c35bc5747fcecd659b2b9b4ceb")
addappid(426881, 0, "1a1d0ba802168d529c59c428722c6d0077e2f33b20cdd78fa0f13a320961f5e9")

