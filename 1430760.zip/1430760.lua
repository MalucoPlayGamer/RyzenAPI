-- Lua provided by RyzenAPI
-- Game: Aquarist

-- MAIN APPLICATION
addappid(1430760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430761, 1, "63fed22ae0423ecd4bfea90e201fc98d953636578f824bbb610442283ad1b8cd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2802320)
addappid(3073590)
addappid(3591780)
addappid(3930920)
addappid(3930930)
addappid(4329150)
