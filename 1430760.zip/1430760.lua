-- Lua provided by RyzenAPI
-- Game: addappid(1430760)

-- MAIN APPLICATION
addappid(1430760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430761, 1, "63fed22ae0423ecd4bfea90e201fc98d953636578f824bbb610442283ad1b8cd")
