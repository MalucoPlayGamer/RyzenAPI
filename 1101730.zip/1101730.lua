-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 It's a Night Magic R18 patch

-- MAIN APPLICATION
addappid(1101730)
-- Game: addappid(1101730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101731, 1, "96972e98cd038870d7758f97379e7f8cba5669d1cf4e3b699579830cf8df8f97")
