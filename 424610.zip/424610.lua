-- Lua provided by RyzenAPI
-- Game: Peasant Knight

-- MAIN APPLICATION
addappid(424610)
-- Game: addappid(424610)

-- MAIN APP DEPOTS / PACKAGES
addappid(424611, 1, "8f83ec733afc9e69b9568a18cfcf856bf35ff8967e543931fe2a78fe5ccc30b8")
