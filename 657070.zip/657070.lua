-- Lua provided by RyzenAPI
-- Game: Dream Hills: Captured Magic

-- MAIN APPLICATION
addappid(657070)

-- MAIN APP DEPOTS / PACKAGES
addappid(657071, 1, "9d2b8c11ec8a9188c218de5234236a1bc10663101c772421e92e17fb83725ea9")
addappid(657072, 1, "006b53ea0e33d0074a5878184bb38d187beb4a6695cdc51438d51bc2d6a5311f")

