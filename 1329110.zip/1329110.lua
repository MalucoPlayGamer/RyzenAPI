-- Lua provided by RyzenAPI
-- Game: 2ECONDS TO STΔRLIVHT: Forever My Diamond

-- MAIN APPLICATION
addappid(1329110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329111, 1, "cd01ce5ee435ee97bcea61759209517e7ccf0848ec8373b1357b183a2a2c33a4")
