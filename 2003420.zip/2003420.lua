-- Lua provided by RyzenAPI
-- Game: Bonk'd Audio Visualizer

-- MAIN APPLICATION
addappid(2003420)
-- Game: addappid(2003420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003422,0,"8483470ec712238d6f06d9b4cf9427f3ee5f9ca2d986f8a519d06879f9180c08")
