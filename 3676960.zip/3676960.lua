-- Lua provided by RyzenAPI
-- Game: THE LAST TRAIN: Baquedano

-- MAIN APPLICATION
addappid(3676960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3676961, 1, "dbe396514ce3fc8be3577f1f52fa9aaafae776560598070c625c0c4878fae30a")

