-- Lua provided by RyzenAPI
-- Game: Next Reign: Kingdom

-- MAIN APP DEPOTS / PACKAGES
addappid(4536900, 1, "51243bea325323663c65b16ffa72ac64d2119de1c204f999419c69c2218863ff") -- Next Reign: Kingdom
addappid(4536901, 1, "c09ed23046ea3e833aa46f3627333e402f8d32716b7e552996cd28e855672843") -- Depot 4536901
addappid(4536902, 1, "a90ea491f393fe14859e7ec5d5070a1e6808d921ac80b3cc80fd30c9f6c45aaf") -- Depot 4536902
