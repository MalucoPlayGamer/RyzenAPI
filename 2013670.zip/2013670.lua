-- Lua provided by RyzenAPI
-- Game: 2013670

-- MAIN APPLICATION
addappid(2013670)
-- Game: addappid(2013670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013671, 1, "c6f34836363b502a25c119a25a5052acdb9271ff9189a5cebc503ea898754c72")
