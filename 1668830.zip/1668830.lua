-- Lua provided by RyzenAPI
-- Game: addappid(1668830)

-- MAIN APPLICATION
addappid(1668830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668831, 1, "3a60897e5ab8ac2ae105d9e642b3899ab94c38887bdfd0c91703c837d6764319")
