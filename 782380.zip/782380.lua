-- Lua provided by RyzenAPI
-- Game: Mirage of Dragon

-- MAIN APPLICATION
addappid(782380)
-- Game: addappid(782380)

-- MAIN APP DEPOTS / PACKAGES
addappid(782381, 1, "157e9ccd9fb14d4ec9d93cd147bda45d55c31d341b85b49224b389d82453b107")
