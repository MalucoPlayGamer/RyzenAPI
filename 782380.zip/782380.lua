-- Lua provided by RyzenAPI
-- Game: Mirage of Dragon

-- MAIN APPLICATION
addappid(782380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(782381, 1, "157e9ccd9fb14d4ec9d93cd147bda45d55c31d341b85b49224b389d82453b107")

