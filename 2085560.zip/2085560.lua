-- Lua provided by RyzenAPI
-- Game: Game: Stick It to the Stickman Demo

-- MAIN APPLICATION
addappid(2085560)
-- Game: addappid(2085560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085561, 1, "66211f90e459f24728be928681c9853bc7e2204c55d11914640d907862261754")
