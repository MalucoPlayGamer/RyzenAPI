-- Lua provided by RyzenAPI
-- Game: Game: LOCKDOWN Protocol

-- MAIN APPLICATION
addappid(2780980)
-- Game: addappid(2780980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780981, 1, "b810b1ec8feac6ecba5f581a91d6cc4f32d3e7e37668fa911a7890c98941b508")
