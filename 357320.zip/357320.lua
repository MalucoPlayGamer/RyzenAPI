-- Lua provided by RyzenAPI
-- Game: 357320

-- MAIN APPLICATION
addappid(357320)
-- Game: addappid(357320)

-- MAIN APP DEPOTS / PACKAGES
addappid(357321, 1, "f25636bd595cb39dff567ee860c6ae86bade1e07c76240b0afa0479dc0f7cf8e")
