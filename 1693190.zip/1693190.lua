-- Lua provided by RyzenAPI
-- Game: Cursed House

-- MAIN APPLICATION
addappid(1693190)
-- Game: addappid(1693190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693191, 1, "22fc6420ca2df0e51445987f0f757c5b1204f5047b9541a7dedf5ea0e07c7af0")
