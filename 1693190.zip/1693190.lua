-- Lua provided by SkyAPI 
-- Game: Cursed House
addappid(1693190)
addappid(1693191, 1, "22fc6420ca2df0e51445987f0f757c5b1204f5047b9541a7dedf5ea0e07c7af0")
