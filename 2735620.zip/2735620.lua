-- Lua provided by RyzenAPI
-- Game: BoardLand

-- MAIN APPLICATION
addappid(2735620)
-- Game: addappid(2735620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735621, 1, "b0e2f84eb91841f3c407781bc06a6110d8a619d261e20228808f7e8e5880528e")
