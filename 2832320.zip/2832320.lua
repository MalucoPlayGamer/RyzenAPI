-- Lua provided by RyzenAPI
-- Game: PC Tycoon 2

-- MAIN APPLICATION
addappid(2832320)
-- Game: addappid(2832320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832321, 1, "f219ff5b8e4985f415fd2aabfb66adcc6b48e977110493d4c261f07a9762ab14")
