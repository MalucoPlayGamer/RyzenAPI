-- Lua provided by RyzenAPI
-- Game: 1098770

-- MAIN APPLICATION
addappid(1098770)
-- Game: addappid(1098770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098775,0,"73e00d89b64ff22dcb811b4235062cc94838ade87dd7bd88f825ed17e09584ce")
