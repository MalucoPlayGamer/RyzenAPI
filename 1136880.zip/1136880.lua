-- Lua provided by RyzenAPI
-- Game: addappid(1136880)

-- MAIN APPLICATION
addappid(1136880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136881, 1, "47135bf8413cbaa604fe87daa0f84eba8ea09570511ac56e4faaa1e567ad6a3e")
