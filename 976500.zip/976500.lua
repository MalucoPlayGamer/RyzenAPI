-- Lua provided by RyzenAPI
-- Game: Venineth

-- MAIN APPLICATION
addappid(976500)

-- MAIN APP DEPOTS / PACKAGES
addappid(976501, 1, "799aa91ca03e0b53b6c121e633cfe0e5356d82926ea55343c340cf83378dd317")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
