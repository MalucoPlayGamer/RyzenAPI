-- Lua provided by RyzenAPI
-- Game: addappid(976500)

-- MAIN APPLICATION
addappid(976500)

-- MAIN APP DEPOTS / PACKAGES
addappid(976501, 1, "799aa91ca03e0b53b6c121e633cfe0e5356d82926ea55343c340cf83378dd317")
