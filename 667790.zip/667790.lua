-- Lua provided by RyzenAPI
-- Game: Downbreak

-- MAIN APPLICATION
addappid(667790)

-- MAIN APP DEPOTS / PACKAGES
addappid(667791, 1, "bc60d3d809e8ecd434acdab99f04a8e4a296c907ddef7e37a5d39c1509fa7ba8")

