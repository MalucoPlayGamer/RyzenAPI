-- Lua provided by RyzenAPI
-- Game: Slabs

-- MAIN APPLICATION
addappid(880590)

-- MAIN APP DEPOTS / PACKAGES
addappid(880591, 1, "cee3d8afb492e438f1ddab131e6c1905b7ca39aa0d7925841ce7a33fef23bc71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
