-- Lua provided by RyzenAPI
-- Game: Game: Slabs

-- MAIN APPLICATION
addappid(880590)
-- Game: addappid(880590)

-- MAIN APP DEPOTS / PACKAGES
addappid(880591, 1, "cee3d8afb492e438f1ddab131e6c1905b7ca39aa0d7925841ce7a33fef23bc71")
