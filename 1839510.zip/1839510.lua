-- Lua provided by RyzenAPI
-- Game: 1839510

-- MAIN APPLICATION
addappid(1839510)
-- Game: addappid(1839510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839511, 1, "966a5a106d0f3e0deb1501fc1f1966be766d156594f20980d485ceb7c88efdea")
