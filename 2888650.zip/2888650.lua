-- Lua provided by RyzenAPI
-- Game: 2888650

-- MAIN APPLICATION
addappid(2888650)
addappid(3074400)
-- Game: addappid(2888650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888651, 1, "7590ec8ead4a284966bc6f74f4e420955472111af3966d0beadd0da54e42a2e4")
