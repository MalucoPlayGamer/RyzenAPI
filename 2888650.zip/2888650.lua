-- Lua provided by RyzenAPI
-- Game: Fleeting Iris: Alansya Chronicles Ren'Py Edition

-- MAIN APPLICATION
addappid(2888650)
addappid(3074400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888651, 1, "7590ec8ead4a284966bc6f74f4e420955472111af3966d0beadd0da54e42a2e4")
