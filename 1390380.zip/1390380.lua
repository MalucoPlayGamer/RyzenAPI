-- Lua provided by RyzenAPI
-- Game: Wolf's Gang

-- MAIN APPLICATION
addappid(1390380)
-- Game: addappid(1390380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390381, 1, "0d60e67d57d4aba6c8f8a14f1e2a395048a7acd8e46d91702994f026e43f2ede")
addappid(1390382, 1, "b9d51d3d0da16bf9b87f18a81b0127557465c6132bb82e4189309675dc4075c1")
