-- Lua provided by RyzenAPI
-- Game: Game: Maiden Cops

-- MAIN APPLICATION
addappid(2012670)
-- Game: addappid(2012670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012671, 1, "c51437f0c1931e49461c9d7ec42780358d391cc7520d7b034a152898fdbcff5a")
