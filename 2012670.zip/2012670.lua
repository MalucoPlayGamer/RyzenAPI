-- Lua provided by RyzenAPI
-- Game: Maiden Cops

-- MAIN APPLICATION
addappid(2012670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012671, 1, "c51437f0c1931e49461c9d7ec42780358d391cc7520d7b034a152898fdbcff5a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3125210)
