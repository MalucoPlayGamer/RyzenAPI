-- Lua provided by RyzenAPI
-- Game: Haydee 3

-- MAIN APPLICATION
addappid(3508770)
-- Game: addappid(3508770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3508771, 1, "5ae074648692e776045b21f542a0a3ac50e755f5d7406ca958131f34b319286b")
