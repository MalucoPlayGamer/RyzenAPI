-- Lua provided by RyzenAPI
-- Game: Game: AppID 1081900

-- MAIN APPLICATION
addappid(1081900)
addappid(1132040)
-- Game: addappid(1081900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081901, 1, "149d37d4a55ce4eef26f3fac8855d06a218ad20bf619efea00aa4899ef34777c")
