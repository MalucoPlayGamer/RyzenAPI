-- Lua provided by RyzenAPI
-- Game: Platonically Mauled by a Magic Cougar

-- MAIN APPLICATION
addappid(2171420)
-- Game: addappid(2171420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171421, 1, "974166addbc750b5aa80fd34837eef029216377d733a7e93d470276017cb43a6")
