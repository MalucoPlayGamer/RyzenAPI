-- Lua provided by RyzenAPI
-- Game: Into the Restless Ruins Soundtrack

-- MAIN APPLICATION
addappid(3726270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3726271, 1, "7a7262fc68c6e6d225e86a54bb83bb3bb2afacb901b4e987291fe7ac3c6a6f0c")
