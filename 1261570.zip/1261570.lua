-- Lua provided by RyzenAPI
-- Game: Motion Of The Heart

-- MAIN APPLICATION
addappid(1261570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261571, 1, "1a6d0a2655c5cf64cb94957aef37eab13b78ccbd251617b0a00b5d55233b2c83")
addappid(1261572, 1, "4c158997d6721a968135f49cc5b3650be3a1d3633d37ced0d3f268d79c1553cd")
