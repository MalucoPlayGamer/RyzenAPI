-- Lua provided by RyzenAPI
-- Game: Kawaii Hentai Sexy Girls

-- MAIN APPLICATION
addappid(2063340)
-- Game: addappid(2063340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063341, 1, "548e12aebc1fdc807c899da4520935f70c34ebd047446d3aeaeaf176a832c7c0")
