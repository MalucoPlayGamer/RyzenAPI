-- Lua provided by RyzenAPI
-- Game: Russian Horror

-- MAIN APPLICATION
addappid(839260)
-- Game: addappid(839260)

-- MAIN APP DEPOTS / PACKAGES
addappid(839261, 1, "85aae243a6f456529fa915756588b7a6c755d4971d49ebb5a7b65df5656df181")
