-- Lua provided by RyzenAPI
-- Game: addappid(751630)

-- MAIN APPLICATION
addappid(751630)

-- MAIN APP DEPOTS / PACKAGES
addappid(751631, 1, "f7e2c8c1e9d88d764149c7d608cce95d61dab718eb6e7838810899e2114d928d")
addappid(1819470, 0, "3b00f97af901ce916dfe839e5d602b198bd6fdbb1934d5ed1ba4c46c5a11e7d9")
