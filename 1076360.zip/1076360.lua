-- Lua provided by SkyAPI 
-- Game: Square Weapons Dungeon
addappid(1076360)
addappid(1076361, 1, "a7b9dc998fdf7fccfee1013f9d01ff5b74c952c1678c6fc3e6abb62605d75701")
