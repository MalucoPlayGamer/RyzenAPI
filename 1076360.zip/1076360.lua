-- Lua provided by RyzenAPI
-- Game: addappid(1076360)

-- MAIN APPLICATION
addappid(1076360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076361, 1, "a7b9dc998fdf7fccfee1013f9d01ff5b74c952c1678c6fc3e6abb62605d75701")
