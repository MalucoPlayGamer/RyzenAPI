-- Lua provided by RyzenAPI
-- Game: Square Weapons Dungeon

-- MAIN APPLICATION
addappid(1076360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076361, 1, "a7b9dc998fdf7fccfee1013f9d01ff5b74c952c1678c6fc3e6abb62605d75701")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
