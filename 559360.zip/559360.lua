-- Lua provided by RyzenAPI
-- Game: Brocat: the B Game

-- MAIN APPLICATION
addappid(559360)

-- MAIN APP DEPOTS / PACKAGES
addappid(559362,0,"f9b1b2b2cd1e4fd170d21ef30d2b7a81327c878d4d80c5b3adf79e55fb507673")

