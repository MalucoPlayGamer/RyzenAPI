-- Lua provided by RyzenAPI
-- Game: Day Zero

-- MAIN APPLICATION
addappid(3441130)
-- Game: addappid(3441130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441131, 1, "0a7d49b19bd7a9e124f03340b0ce733b260c239239024b5fe5a2bdd78946bbdd")
addappid(3441132, 1, "7033e210c3fe2d1986d7f7f7e403f1a24ef34f217717beca1bf99d0d576793e0")
