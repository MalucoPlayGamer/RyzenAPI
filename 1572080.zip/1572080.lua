-- Lua provided by RyzenAPI
-- Game: Home Wind

-- MAIN APPLICATION
addappid(1572080)
