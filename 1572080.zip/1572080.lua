-- Lua provided by RyzenAPI
-- Game: Home Wind

-- MAIN APPLICATION
addappid(1572080)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1950480)
