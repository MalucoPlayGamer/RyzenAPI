-- Lua provided by RyzenAPI
-- Game: Block Buster Demo

-- MAIN APPLICATION
addappid(2576590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576591, 1, "8b9fa18e8435298f2399f32f19d4c51fcc8a56837b4baed4a95544c7b0d0b2a2")
