-- Lua provided by RyzenAPI
-- Game: 1410860

-- MAIN APPLICATION
addappid(1410860)
-- Game: addappid(1410860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410861, 1, "549e988bc83db144f9d8da58d81f230a8be1aab159dcfa4349d0cb0f3f0f79c2")
