-- Lua provided by RyzenAPI
-- Game: Puzzle Box Palace

-- MAIN APPLICATION
addappid(1410860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1410861, 1, "549e988bc83db144f9d8da58d81f230a8be1aab159dcfa4349d0cb0f3f0f79c2")

