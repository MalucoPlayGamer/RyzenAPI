-- Lua provided by RyzenAPI
-- Game: つぐのひ Demo

-- MAIN APPLICATION
addappid(1642700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642703,0,"0e40f8b0799bf0b2594e7343439f2db42b4db6491553da1764adffd1fe870b9e")

