-- Lua provided by RyzenAPI
-- Game: Game: Tour de France 2020

-- MAIN APPLICATION
addappid(1287590)
-- Game: addappid(1287590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287591, 1, "cf08335782a389167cd3b125a1887c05807c04a0874250fffed85c0e4675e0df")
