-- Lua provided by RyzenAPI
-- Game: Tour de France 2020

-- MAIN APPLICATION
addappid(1287590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1287591, 1, "cf08335782a389167cd3b125a1887c05807c04a0874250fffed85c0e4675e0df")

