-- Lua provided by RyzenAPI
-- Game: 捕鱼王国Fishing Kingdom

-- MAIN APPLICATION
addappid(1937220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937221, 1, "7c8fdd6bcba544b590ea7dbea5c8a2e3db8e82cfbcad18c9f04081327396e2b7")

