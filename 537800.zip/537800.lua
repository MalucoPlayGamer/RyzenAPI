-- Lua provided by RyzenAPI
-- Game: AppID 537800

-- MAIN APPLICATION
addappid(537800)

-- MAIN APP DEPOTS / PACKAGES
addappid(537801, 1, "b886b1f09750754e2557f067a236074f59d2f12e7338d854abf398d57151ec90")
addappid(537802, 1, "a2e253fda052ccc336afd6ac60050355f04741b8512afc63d9b5c19eaf1bb35e")
addappid(537803, 1, "f4937e9aefcd52c0370100fc4187659f832e787a5252df2d7d880aeec3328fa2")
addappid(537804, 1, "93ffd82f9d740a624ffa3b621d03c73f17afc41bdcd7ed541841cd3d2291a22a")
addappid(537805, 1, "d3950e270cc437e38ce53075e527638ee19e7808fdc0df47fd0cc5c5ede76a6c")
addappid(728930, 0, "82d6a06cc329b57e68d4805deb78c1ba282d4010329f9c0853533c8aa067119b")
addappid(754680, 0, "6fff535ad700ec545e9004058f502492d6822fbea3d61dfb903b9f0a4d4f5947")
addappid(756070, 0, "acb8e6c452aa6ad79afd208761ade5f93dcd7f3fdd5dae44538092c07feef2c6")
addappid(756071, 0, "02327b7ebb3cb37aaa10ca08ba5c92b25859817eafcdac9dc4c4f8c19b034888")
addappid(756080, 0, "2f0ed524a3ec19725bd5392ee368155a145e09d9c313d47bd5fa497055c3de6e")
addappid(759600, 0, "cf7fd2197183f4d2450bd10d8187fd03fd5bbc71b3356f76eaf49db49e98b4c6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(765960)
