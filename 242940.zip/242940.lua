-- Lua provided by RyzenAPI
-- Game: AppID 242940

-- MAIN APPLICATION
addappid(242940)

-- MAIN APP DEPOTS / PACKAGES
addappid(242941, 1, "006cdc444d45523c73f536a146529ff06812409575609077d4e04b9d34ad40ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
