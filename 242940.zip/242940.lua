-- Lua provided by RyzenAPI
-- Game: Game: AppID 242940

-- MAIN APPLICATION
addappid(242940)
-- Game: addappid(242940)

-- MAIN APP DEPOTS / PACKAGES
addappid(242941, 1, "006cdc444d45523c73f536a146529ff06812409575609077d4e04b9d34ad40ad")
