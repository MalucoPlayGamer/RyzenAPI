-- Lua provided by SkyAPI 
-- Game: Forestation
addappid(752300)
addappid(752301, 1, "3570411123168c919ecafa381fdb40ff95884739ed089ca1e62131f4f5d9c3fb")
addappid(752302, 1, "874a41358734d78cae31100e2976baedd87e5204c1823017d94d426ef9f63779")
