-- Lua provided by RyzenAPI 
-- Game: Layers of Fear Soundtrack
addappid(2402240)
addappid(2402241, 1, "184f0dc0e4738b26f3a09295373f7829a03afddb77c4e023f02d7f80308bc2b3")
addappid(2402242, 1, "ea738e9ffe59247fd2a6a270de423e975a3f4b659ced7d2684e0b13dbd8a6034")
