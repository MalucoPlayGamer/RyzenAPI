-- Lua provided by RyzenAPI
-- Game: Village Heroes Demo

-- MAIN APPLICATION
addappid(2772150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772151, 1, "633e995a2181e42bac8380604a9cb8e9b49881474f8edc4000f230e9b0317c4d")

