-- Lua provided by RyzenAPI
-- Game: Park Ranger Simulator

-- MAIN APPLICATION
addappid(2622690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622691,0,"6df904c6940541874196bd81f37871dc73ebcca9035232cc47ca1c615a3b2788")

