-- Lua provided by RyzenAPI
-- Game: Fences 4

-- MAIN APPLICATION
addappid(1815630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815631, 1, "02a8e8b546a41c9fd49512a441923758a2b1593055c1231e4e631e92d1770448")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1852560)
