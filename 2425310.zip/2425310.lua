-- Lua provided by RyzenAPI
-- Game: Sweet Hut

-- MAIN APPLICATION
addappid(2425310)
-- Game: addappid(2425310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425311, 1, "323d1415ce9bbe148498b7fde181ea81f5e0e2f411b1a07b8e303325387dee97")
