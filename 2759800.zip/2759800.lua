-- Lua provided by RyzenAPI
-- Game: Game: 忘川游RiverLife

-- MAIN APPLICATION
addappid(2759800)
-- Game: addappid(2759800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759801, 1, "045be896ff1412a3d6e2bd7d228d006a5b05a7e05313709b2345e5949d870729")
