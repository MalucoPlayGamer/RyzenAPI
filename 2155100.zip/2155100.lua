-- Lua provided by RyzenAPI
-- Game: Hazard Horizon

-- MAIN APPLICATION
addappid(2155100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155101, 1, "afef43af5a2eb9943865be25883f3c56071357e548a1065051a3da13556ba4ec")

