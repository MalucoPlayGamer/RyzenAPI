-- Lua provided by RyzenAPI 
-- Game: Rise & Muse
addappid(2522920)
addappid(2522921, 1, "7249efdcd262f72995596a52bd0c07142eeb0714b16b802fd463342c803e775a")
