-- Lua provided by SkyAPI 
-- Game: Hungry Fish
addappid(1683720)
addappid(1683721, 1, "706f52bb9661791db16b7e7ad7c616d40669bf892082ce7b3e3ba29171172d66")
