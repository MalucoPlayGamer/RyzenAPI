-- Lua provided by RyzenAPI
-- Game: Hentai Furry 3

-- MAIN APPLICATION
addappid(2113660)
addappid(2129650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113661, 1, "04c532514d74abc8ab9c1caffc8337b4f1d8ac9127b5795e6f6d7e0d425ccf4d")

