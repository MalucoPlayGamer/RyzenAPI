-- Lua provided by RyzenAPI
-- Game: Game: AppID 2809320

-- MAIN APPLICATION
addappid(2809320)
-- Game: addappid(2809320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809321, 1, "6dcc91ab4630891fed7999b4e0616684af6c010c0abac65848ea032af0639cfc")
