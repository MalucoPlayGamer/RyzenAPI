-- Lua provided by RyzenAPI
-- Game: Game: AppID 1427700

-- MAIN APPLICATION
addappid(1427700)
-- Game: addappid(1427700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427701, 1, "9162fd6dfe1e50392a2ead805b0f0bac7ff7573113049da54e4640acfa91fd62")
