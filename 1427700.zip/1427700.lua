-- Lua provided by RyzenAPI
-- Game: AppID 1427700

-- MAIN APPLICATION
addappid(1427700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427701, 1, "9162fd6dfe1e50392a2ead805b0f0bac7ff7573113049da54e4640acfa91fd62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1567750)
addappid(1569020)
addappid(1569030)
addappid(1569050)
addappid(1569060)
addappid(1583430)
addappid(1696690)
