-- Lua provided by RyzenAPI
-- Game: Game: AppID 1106080

-- MAIN APPLICATION
addappid(1106080)
addappid(1147920)
-- Game: addappid(1106080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106081, 1, "6aa1f739b0f068de667897a9ab3d27f5b9f35776fbdfb7a333a96c77d72222ce")
addappid(1106082, 1, "7095289329ad631d1c448b3f8215d18a3d010da980c341cd6c9caff41dc8336c")
