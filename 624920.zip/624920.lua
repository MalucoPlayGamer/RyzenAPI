-- Lua provided by RyzenAPI
-- Game: addappid(624920)

-- MAIN APPLICATION
addappid(624920)

-- MAIN APP DEPOTS / PACKAGES
addappid(624921, 1, "01e2903fbe2667770d169d77671a4a947dc5d0e65d33b2ae4f528f9ca1cd20ec")
