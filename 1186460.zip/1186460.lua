-- Lua provided by RyzenAPI
-- Game: addappid(1186460)

-- MAIN APPLICATION
addappid(1186460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186461, 1, "963416416dca99212d0f39a45b58fb82dfa1ff5c48231cbdb63bbbac9d49db9e")
