-- Lua provided by RyzenAPI
-- Game: Songs of Wuxia

-- MAIN APPLICATION
addappid(1186460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186461, 1, "963416416dca99212d0f39a45b58fb82dfa1ff5c48231cbdb63bbbac9d49db9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
