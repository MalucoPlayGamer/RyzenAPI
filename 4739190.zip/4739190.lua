-- Lua provided by RyzenAPI
-- Game: Oharion

-- MAIN APPLICATION
addappid(4739190)
