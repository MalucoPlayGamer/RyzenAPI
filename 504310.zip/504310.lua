-- Lua provided by RyzenAPI
-- Game: AppID 504310

-- MAIN APPLICATION
addappid(504310)
addappid(591040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(504311, 1, "1d4183c9f80264ac0ed8713b6508f9d3f3f0b3d3153d43aed0af74128dbb17f3")

