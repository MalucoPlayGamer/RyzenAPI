-- Lua provided by RyzenAPI
-- Game: Game: AppID 504310

-- MAIN APPLICATION
addappid(504310)
addappid(591040)
-- Game: addappid(504310)

-- MAIN APP DEPOTS / PACKAGES
addappid(504311, 1, "1d4183c9f80264ac0ed8713b6508f9d3f3f0b3d3153d43aed0af74128dbb17f3")
