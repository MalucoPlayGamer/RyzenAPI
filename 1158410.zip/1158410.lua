-- Lua provided by SkyAPI 
-- Game: AppID 1158410
addappid(1158410)
addappid(1158411, 1, "a4c0ffee8984472f152f317e0cdeb5450bd7b9587a62cd9f3a733e1b9b25693c")
