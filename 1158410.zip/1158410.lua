-- Lua provided by RyzenAPI
-- Game: AppID 1158410

-- MAIN APPLICATION
addappid(1158410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158411, 1, "a4c0ffee8984472f152f317e0cdeb5450bd7b9587a62cd9f3a733e1b9b25693c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
