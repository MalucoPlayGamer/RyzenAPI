-- Lua provided by RyzenAPI
-- Game: Tank Battle Heroes: Esports War

-- MAIN APPLICATION
addappid(1063990)
-- Game: addappid(1063990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063991, 1, "1827763bf32c503c35d1529764b70bf922148902408cd8610d05fd25f082369b")
addappid(1063992, 1, "9a43bca673a0e2984be00b87c7b036f06c053c684aeaab87d1ec702727600010")
