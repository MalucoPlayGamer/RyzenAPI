-- Lua provided by RyzenAPI
-- Game: Fantasy Empires

-- MAIN APPLICATION
addappid(2350530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350531, 1, "f7681aed2936c694a0f61f0f97d691a6b21ff84a802a82af0d3a71c4197b8a21")
addappid(2350532, 1, "06c2fac572078a38252824d430577fe17db5443bb2259708b5ebb4aabb0ea3f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
