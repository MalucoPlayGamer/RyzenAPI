-- Lua provided by RyzenAPI 
-- Game: Hidden Legacy: Dark Heirloom Collector's Edition
addappid(3620060)
addappid(3620061, 1, "0cbe85745790eb3d19aa2a007d1983db40bb1e8ea2db0afe624583707b38b053")
addappid(3765150, 0, "f5155324c6e215470818e67e5fdcc21f577e71b6480018d1f18a49e2ec5f8ce6")
