-- Lua provided by RyzenAPI
-- Game: Lost Horizon 2

-- MAIN APPLICATION
addappid(228990)
addappid(395560)
addappid(395561)

-- MAIN APP DEPOTS / PACKAGES
addappid(395562,0,"2da15a3601b42ca333a7f17950f260236173d35cd02e6c563f5eec88e4ec6bd6")
addappid(395563,0,"6315a87ea94738d09c1317dbcab363fef9e500b08a5479b943694ebc3d4df6ca")

