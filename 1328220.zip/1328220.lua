-- Lua provided by RyzenAPI
-- Game: addappid(1328220)

-- MAIN APPLICATION
addappid(1328220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328221, 1, "46ab0778da9059144905d708fd64882d04dabef2949c84ec17e2723cadc9031a")
