-- Lua provided by RyzenAPI
-- Game: CHALICE

-- MAIN APPLICATION
addappid(1328220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328221, 1, "46ab0778da9059144905d708fd64882d04dabef2949c84ec17e2723cadc9031a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
