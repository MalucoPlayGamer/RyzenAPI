-- Lua provided by RyzenAPI
-- Game: 1805210

-- MAIN APPLICATION
addappid(1805210)
-- Game: addappid(1805210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805211, 1, "da541ca85e3bd366f73a5dd020fee5ceaf21176edc6348db0505df91291b62bb")
