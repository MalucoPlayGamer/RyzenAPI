-- Lua provided by RyzenAPI 
-- Game: Solaris Rift
addappid(1805210)
addappid(1805211, 1, "da541ca85e3bd366f73a5dd020fee5ceaf21176edc6348db0505df91291b62bb")
