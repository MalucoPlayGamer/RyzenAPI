-- Lua provided by RyzenAPI
-- Game: Solaris Rift

-- MAIN APPLICATION
addappid(1805210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805211, 1, "da541ca85e3bd366f73a5dd020fee5ceaf21176edc6348db0505df91291b62bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
