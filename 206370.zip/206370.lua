-- Lua provided by RyzenAPI 
-- Game: Tales From Space: Mutant Blobs Attack
addappid(206370)
addappid(206371, 1, "824a0c6d42d8eae64464423538675b6b3be53df89004545163af1245a6c5287f")
addappid(206372, 1, "68e3a9e1a374e60fd6461181ab347fd191e0dcf291f7d133cd1d62100dbba964")
addappid(206373, 1, "f807042bca455fe2c1b967f174f5317bfd5a7877010bf79ee8d1927b20370f39")
