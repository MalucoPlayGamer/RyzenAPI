-- Lua provided by RyzenAPI
-- Game: 2067570

-- MAIN APPLICATION
addappid(2067570)
-- Game: addappid(2067570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067571, 1, "1ef12218cd92a4e64faeb265f58ab62991fd3cf20448fce133f2b628f93c144f")
