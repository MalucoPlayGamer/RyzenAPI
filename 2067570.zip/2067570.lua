-- Lua provided by RyzenAPI
-- Game: Egghead Gumpty

-- MAIN APPLICATION
addappid(2067570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067571, 1, "1ef12218cd92a4e64faeb265f58ab62991fd3cf20448fce133f2b628f93c144f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
