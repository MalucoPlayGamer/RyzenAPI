-- Lua provided by RyzenAPI
-- Game: Game: Vending Dokan!: Kozy Kiosk

-- MAIN APPLICATION
addappid(2729820)
-- Game: addappid(2729820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729821, 1, "e83b8c23c429c67b8e5ab50445864db481598c87bcc7fd11a875c7bf24a722da")
