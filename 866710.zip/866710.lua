-- Lua provided by RyzenAPI
-- Game: Shiver: The Lily's Requiem Collector's Edition

-- MAIN APPLICATION
addappid(866710)

-- MAIN APP DEPOTS / PACKAGES
addappid(866711, 1, "2240c4c23b60ddf01743c041f64f9d260beacca89ba9431e539d287197056ff1")
