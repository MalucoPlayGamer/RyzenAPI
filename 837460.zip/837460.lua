-- Lua provided by RyzenAPI
-- Game: Batbarian: Testament of the Primordials

-- MAIN APPLICATION
addappid(837460)

-- MAIN APP DEPOTS / PACKAGES
addappid(837461, 1, "31604419cb623099cd2b262eaacd059b5c2be7f7c9c380045057a9c7035f55f3")

