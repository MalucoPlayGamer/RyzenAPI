-- Lua provided by RyzenAPI
-- Game: Game: Soda Drinker Pro

-- MAIN APPLICATION
addappid(347720)
-- Game: addappid(347720)

-- MAIN APP DEPOTS / PACKAGES
addappid(347721, 1, "0ac4096504b31ee41a2b0c17c89b3095773802b8e0cbc98c2425ec65f499a82c")
addappid(347722, 1, "792fcb36e02365ef112199f864cfff05290617607de84d5edd94ba04c24fd39c")
addappid(576210, 0, "f46663129e48b30177a872d2bffac5347e87ace2b390142b87450eed0492a1af")
