-- Lua provided by RyzenAPI
-- Game: 1643060

-- MAIN APPLICATION
addappid(1643060)
-- Game: addappid(1643060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643062,0,"345a7f0fdcf49f061a991a9daa13c0f8f3a52d16572c972c6b18afb65c59d22e")
