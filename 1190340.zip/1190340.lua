-- Lua provided by RyzenAPI
-- Game: AppID 1190340

-- MAIN APPLICATION
addappid(1190340)
addappid(4091040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1190341, 1, "f9ce5fb307b7c7f3f589de478283051e153ca914b9b73f59c61a065b730b5aea")

