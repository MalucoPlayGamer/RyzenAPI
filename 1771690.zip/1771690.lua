-- Lua provided by SkyAPI 
-- Game: AppID 1771690
addappid(1771690)
addappid(1771691, 1, "1e21ba6168816d085fb9026dcfb953a0eed4e8c83d4423c18778855e939b3916")
