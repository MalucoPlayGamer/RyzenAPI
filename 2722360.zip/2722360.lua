-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Safe House

-- MAIN APPLICATION
addappid(2722360)
-- Game: addappid(2722360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722361, 1, "7371a0b6256a3c6a3f8603499d4fe50bfe029c2bf81b1cb553fc4bdf5ead94bb")
