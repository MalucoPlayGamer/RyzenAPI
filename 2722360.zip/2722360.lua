-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Safe House

-- MAIN APPLICATION
addappid(2722360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722361, 1, "7371a0b6256a3c6a3f8603499d4fe50bfe029c2bf81b1cb553fc4bdf5ead94bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
