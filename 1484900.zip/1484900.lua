-- Lua provided by RyzenAPI
-- Game: Game: Hoa

-- MAIN APPLICATION
addappid(1484900)
-- Game: addappid(1484900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484901, 1, "91090b36088707306283140ffef3e58c7e9ad81cd65b211fbb693523edb254d4")
addappid(1484902, 1, "3be91aa5494dee776b420e5254a9d4f08a7759952734cdb92f68804dde445bc0")
