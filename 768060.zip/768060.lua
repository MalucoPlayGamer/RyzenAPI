-- Lua provided by RyzenAPI
-- Game: The Warrior Of Treasures

-- MAIN APPLICATION
addappid(768060)

-- MAIN APP DEPOTS / PACKAGES
addappid(768061, 1, "8991aefca747c56bf307e9b03fb8f7f3c25f7296c76ea924240467704234433c")

