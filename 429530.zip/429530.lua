-- Lua provided by RyzenAPI
-- Game: Falcon 4.0

-- MAIN APPLICATION
addappid(429530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229007,0,"eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d")
addappid(429532,0,"5c17b90b128ad5462b8b3fe7eb91e49ff3b413c5e7c47277042c9d04f286877f")
