-- Lua provided by RyzenAPI
-- Game: Sneak Thief

-- MAIN APPLICATION
addappid(508550)
-- Game: addappid(508550)

-- MAIN APP DEPOTS / PACKAGES
addappid(508551, 1, "2701a32a64bde8a4310e1f7117d65995b67cfb264cbe2e489ca3ac56e99b02f2")
