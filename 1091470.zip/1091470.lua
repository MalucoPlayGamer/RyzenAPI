-- Lua provided by RyzenAPI
-- Game: addappid(1091470)

-- MAIN APPLICATION
addappid(1091470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091471, 1, "e5c633f9da079fd25f045001474db322cc678498f123f2df7e375e63ec2b71f7")
