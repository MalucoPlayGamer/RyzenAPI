-- Lua provided by RyzenAPI
-- Game: Jigsaw Frame: Hot Anime

-- MAIN APPLICATION
addappid(1694110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694111, 1, "83df1b36e2710a0066958f7a6c4142467485014be8f219848c9b2de675e19945")

