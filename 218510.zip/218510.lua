-- Lua provided by RyzenAPI
-- Game: AppID 218510

-- MAIN APPLICATION
addappid(218510)

-- MAIN APP DEPOTS / PACKAGES
addappid(218511, 1, "8a6efa65777d946e866372829db58e06c1cb04d252015f4e0220478a70f0b37c")
addappid(218512, 1, "d8ef1ca42a3318c4598e710083af4463d2d0f461be1029d5eec606e6cc4757c8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3106850)
