-- Lua provided by RyzenAPI 
-- Game: Man Without Clothes Runner
addappid(3628000)
addappid(3628001, 1, "e2cd748d4067a1159165d875b283200a0486c02d96f1004202c90c47b302c724")
