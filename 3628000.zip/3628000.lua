-- Lua provided by RyzenAPI
-- Game: Man Without Clothes Runner

-- MAIN APPLICATION
addappid(3628000)
-- Game: addappid(3628000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3628001, 1, "e2cd748d4067a1159165d875b283200a0486c02d96f1004202c90c47b302c724")
