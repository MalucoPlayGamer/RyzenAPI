-- Lua provided by RyzenAPI
-- Game: 3487170

-- MAIN APPLICATION
addappid(3487170)
-- Game: addappid(3487170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487171, 1, "5caf1d0df08dcec568b2af1e936bd6de7882b8e2c306612ba5501ff8ef804eb6")
