-- Lua provided by RyzenAPI
-- Game: addappid(484830)

-- MAIN APPLICATION
addappid(484830)

-- MAIN APP DEPOTS / PACKAGES
addappid(484831, 1, "66440c7d5d395c78c29d0f77a43bc6ad2a075a36cf8588f17118db6fa151f86d")
addappid(484832, 1, "7a23e2fe7f531ed72efde840e75c0d5a010af8ea8362d7a476b54eb27bd8dea7")
addappid(484833, 1, "fe14279ef620226434e9b4df2dfd43f4b424ab35585e1c859fb19de7e88734af")
