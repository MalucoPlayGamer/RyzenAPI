-- Lua provided by RyzenAPI
-- Game: addappid(376780)

-- MAIN APPLICATION
addappid(376780)

-- MAIN APP DEPOTS / PACKAGES
addappid(376781, 1, "a2f25decfba55cddf44ea6ed901c2e6ac5247ceacd75f9364c9201cf2fc59d98")
