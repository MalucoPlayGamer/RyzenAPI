-- Lua provided by RyzenAPI
-- Game: AppID 588650

-- MAIN APPLICATION
addappid(588650)
addappid(1046440)
addappid(1046440) -- Dead Cells Rise of the Giant
addappid(1204130)
addappid(1204130) -- Dead Cells The Bad Seed
addappid(1451460)
addappid(1451460) -- Dead Cells Fatal Falls
addappid(1580050)
addappid(1580050) -- Dead Cells The Queen and the Sea
addappid(2101430)
addappid(2101430) -- Dead Cells Return to Castlevania

-- MAIN APP DEPOTS / PACKAGES
addappid(588650,0,"9dd9ead18fafa93ccb47172cd88174b9348e9fde0db0b6ca4a36283844111f6f")
addappid(588651,0,"b1571411c76b5560172122534e5f36b33665aa1ae5337216fb74816b8c06a9cb")
addappid(588651, 1, "b1571411c76b5560172122534e5f36b33665aa1ae5337216fb74816b8c06a9cb")
addappid(588652,0,"98f088e6b86104bf373ec16bf0eddfc7f5228918b7e4c1dddae39f4ab26b0dd3")
addappid(588652, 1, "98f088e6b86104bf373ec16bf0eddfc7f5228918b7e4c1dddae39f4ab26b0dd3")
addappid(588653,0,"2336789903ae91cb11227bcf1b373363713f81c832eac5a009f4a34f0dfbf340")
addappid(588653, 1, "2336789903ae91cb11227bcf1b373363713f81c832eac5a009f4a34f0dfbf340")
addappid(588654,0,"d3869ea6e5650f8be36180bcfab511f05b89d33279c4fbcdcb636c53335585ad")
addappid(588654, 1, "d3869ea6e5650f8be36180bcfab511f05b89d33279c4fbcdcb636c53335585ad")

