-- Lua provided by RyzenAPI 
-- Game: Happy Quest
addappid(1418160)
addappid(1418161, 1, "d3c5bd1a514816e87bbbfc4d3ed1c56b0e6b67b0069438508ed3c8b41e6a05d8")
addappid(1447440)
