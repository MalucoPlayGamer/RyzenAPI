-- Lua provided by RyzenAPI
-- Game: Alicia Griffith – Lakeside Murder

-- MAIN APPLICATION
addappid(569380)

-- MAIN APP DEPOTS / PACKAGES
addappid(569381, 1, "0a903cfda7735978ee8a9cd61faf26119d79cbf383a1ceaeec26d39b19a10bfa")
