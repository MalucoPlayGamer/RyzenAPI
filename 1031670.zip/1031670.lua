-- Lua provided by RyzenAPI
-- Game: addappid(1031670)

-- MAIN APPLICATION
addappid(1031670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031671, 1, "bcdee206eba74080a223e41953c3aefc65a86e4a5b989c0736ffb76f79e93928")
