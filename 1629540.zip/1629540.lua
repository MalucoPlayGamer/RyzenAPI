-- Lua provided by RyzenAPI
-- Game: Game: Spark the Electric Jester 3 Demo

-- MAIN APPLICATION
addappid(1629540)
-- Game: addappid(1629540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629541, 1, "e08148e9dd4463f4d65901d98291d6e23ba3bbe275a892a8339ab04012a97cc9")
