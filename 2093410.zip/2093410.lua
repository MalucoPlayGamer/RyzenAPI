-- Lua provided by RyzenAPI
-- Game: Supreme Ruler 2030

-- MAIN APPLICATION
addappid(2093410)
addappid(2648350)
addappid(2878240)
addappid(2878250)
addappid(3592470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2093411, 1, "7e018bfc03085dc2017cc87ba2fab9dbe5960c906e62588ac5b44b2301a9cb8f")
addappid(2702500, 0, "e57e2ba3ce81269f58dab499f4cea75a58be0f6eed31a169d3a41061130e72bb")

