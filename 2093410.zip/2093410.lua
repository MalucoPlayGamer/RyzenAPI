-- Lua provided by RyzenAPI 
-- Game: AppID 2093410
addappid(2093410)
addappid(2093411, 1, "7e018bfc03085dc2017cc87ba2fab9dbe5960c906e62588ac5b44b2301a9cb8f")
addappid(2702500, 0, "e57e2ba3ce81269f58dab499f4cea75a58be0f6eed31a169d3a41061130e72bb")
