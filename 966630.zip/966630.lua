-- Lua provided by RyzenAPI
-- Game: AppID 966630

-- MAIN APPLICATION
addappid(966630)
-- Game: addappid(966630)

-- MAIN APP DEPOTS / PACKAGES
addappid(966631, 1, "c3860281ba20da9dfa7c6cf6ec07030a4fcda0603e91ad387ad2387f86c4f25c")
