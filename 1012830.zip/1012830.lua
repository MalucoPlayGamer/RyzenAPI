-- Lua provided by RyzenAPI
-- Game: 1012830

-- MAIN APPLICATION
addappid(1012830)
-- Game: addappid(1012830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012831, 1, "e0c71fe006a8d7e41c044adff20878b5d542a75d57e29886492cbb80acb956a3")
