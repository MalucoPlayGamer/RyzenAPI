-- Lua provided by RyzenAPI
-- Game: 246880

-- MAIN APPLICATION
addappid(246880)
-- Game: addappid(246880)

-- MAIN APP DEPOTS / PACKAGES
addappid(246881, 1, "58dffed21be2ee46885908e515608a32f53d07a72396aee0f285525119d1360f")
