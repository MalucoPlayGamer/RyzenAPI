-- Lua provided by RyzenAPI
-- Game: 1101660

-- MAIN APPLICATION
addappid(1101660)
-- Game: addappid(1101660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101661, 1, "8127f39ca05b71e51a61324bc583daf0da9cf00562dd7b21f5cb917f42e38d38")
