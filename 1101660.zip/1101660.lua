-- Lua provided by SkyAPI 
-- Game: Cooking Trip: Back on the road
addappid(1101660)
addappid(1101661, 1, "8127f39ca05b71e51a61324bc583daf0da9cf00562dd7b21f5cb917f42e38d38")
