-- Lua provided by RyzenAPI
-- Game: Game: AppID 1108750

-- MAIN APPLICATION
addappid(1108750)
-- Game: addappid(1108750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108751, 1, "f287e0221f9a552d3e9c902d3318360d8c52a11c52515b4d4a4c4bc06bfa9a3b")
