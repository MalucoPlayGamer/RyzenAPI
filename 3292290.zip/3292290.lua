-- Lua provided by RyzenAPI
-- Game: Game: FatSheep Crisis II

-- MAIN APPLICATION
addappid(3292290)
-- Game: addappid(3292290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3292291, 1, "c6faa233bc5227b212cbff36941e01a03b758da4a2ca8802b7881b1337704b77")
