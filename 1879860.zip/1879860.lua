-- Lua provided by RyzenAPI
-- Game: Fractured Worlds

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1879860, 1, "21d6e1312b92bb36f8f2c8b709a12ac99c21b1b3e5cf73d055387366da6b7686") -- Fractured Worlds
addappid(1879861, 1, "e04c240a019502cfb7810a7c29594118df128773cd12660728a66916395fa7af") -- Depot 1879861

