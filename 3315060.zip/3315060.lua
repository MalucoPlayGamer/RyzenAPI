-- 3315060's Lua and Manifest Created by Hubcap Manifest
-- Ledgerbound
-- Created: August 15, 2026 at 14:14:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3315060, 1, "d5e49c697cd65bb1930d108a22d2643062e0beba8f3b765b4629c289b5a10069") -- Ledgerbound
-- MAIN APP DEPOTS
addappid(3315061, 1, "2ea477b23987fbab57b7f1dfd57e9fa5f75a6c9b9bbab0b8ba74a2ab9d0a1ef4") -- Depot 3315061
setManifestid(3315061, "1500433072665081932", 10516605413)
addappid(3315062, 1, "f0f24fdc123b5dfee8f14ce1f9373fd1ac080d6a8957c5adf258fc90cda0d64d") -- Depot 3315062
setManifestid(3315062, "6330684506050596375", 10509528978)
-- DLCS WITH DEDICATED DEPOTS
-- Ledgerbound - Deluxe Supporter Edition (AppID: 5030720)
addappid(5030720)
addappid(5030720, 1, "fbabf1403906008b53faa853664d768fc1b82b3a1aba08390cbed2e8fc4d78a2") -- Ledgerbound - Deluxe Supporter Edition - Depot 5030720
setManifestid(5030720, "7745733450140907929", 2301351112)