-- Lua provided by RyzenAPI
-- Game: Ledgerbound

-- MAIN APPLICATION
addappid(5030720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315060, 1, "d5e49c697cd65bb1930d108a22d2643062e0beba8f3b765b4629c289b5a10069") -- Ledgerbound
addappid(3315061, 1, "2ea477b23987fbab57b7f1dfd57e9fa5f75a6c9b9bbab0b8ba74a2ab9d0a1ef4") -- Depot 3315061
addappid(3315062, 1, "f0f24fdc123b5dfee8f14ce1f9373fd1ac080d6a8957c5adf258fc90cda0d64d") -- Depot 3315062
addappid(5030720, 1, "fbabf1403906008b53faa853664d768fc1b82b3a1aba08390cbed2e8fc4d78a2") -- Ledgerbound - Deluxe Supporter Edition - Depot 5030720

