-- Lua provided by RyzenAPI
-- Game: 2093150

-- MAIN APPLICATION
addappid(2093150)
-- Game: addappid(2093150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093151, 1, "36e1ee1cfbd2d11354186f8623eb07883bbb38b4858c78e7ed269afb233bccff")
