-- Lua provided by RyzenAPI
-- Game: Party Bots

-- MAIN APPLICATION
addappid(1859860)
