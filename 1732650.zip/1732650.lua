-- Lua provided by SkyAPI 
-- Game: AppID 1732650
addappid(1732650)
addappid(1732651, 1, "b2fd6535306e8c61c596ddd51837ca9d23e76992d7ec960600a0e9fded51e635")
