-- Lua provided by RyzenAPI
-- Game: Fighting Robots

-- MAIN APPLICATION
addappid(1732650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732651, 1, "b2fd6535306e8c61c596ddd51837ca9d23e76992d7ec960600a0e9fded51e635")
