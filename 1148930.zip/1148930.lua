-- Lua provided by RyzenAPI
-- Game: addappid(1148930)

-- MAIN APPLICATION
addappid(1148930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148931, 1, "49fca75fded6b700eb133bf552b4c08f3f3628756cb52682e4cb8971116c06f0")
