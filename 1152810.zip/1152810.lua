-- Lua provided by RyzenAPI
-- Game: Game: AppID 1152810

-- MAIN APPLICATION
addappid(1152810)
-- Game: addappid(1152810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152811, 1, "296be38fd2342139fc6fa0f90f5abd0d8cfb3fd38380895decc01a67773e45e7")
