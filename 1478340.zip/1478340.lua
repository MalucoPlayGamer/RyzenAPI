-- Lua provided by RyzenAPI 
-- Game: Turbo Sliders Unlimited
addappid(1478340)
addappid(1478341, 1, "44c8a125afbf4624870971239d01205da6f032cfb83ba94a3ff12c264929f750")
