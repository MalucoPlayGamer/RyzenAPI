-- Lua provided by RyzenAPI
-- Game: Turbo Sliders Unlimited

-- MAIN APPLICATION
addappid(1478340)
addappid(1479240)
addappid(1479241)
addappid(1479242)
addappid(1479243)
addappid(1887650)
addappid(1887651)
addappid(1887652)
addappid(1887653)
addappid(1887654)
addappid(1887655)
addappid(1887656)
addappid(1887657)
addappid(1887658)
addappid(2270480)
addappid(2270481)
addappid(2270482)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478340,0,"306a474d67744ad105af53270dc72a5950787ccae0e5e715916a8ef69491e895")
addappid(1478341,0,"44c8a125afbf4624870971239d01205da6f032cfb83ba94a3ff12c264929f750")

