-- Lua provided by RyzenAPI
-- Game: Turbo Sliders Unlimited

-- MAIN APPLICATION
addappid(1478340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478341, 1, "44c8a125afbf4624870971239d01205da6f032cfb83ba94a3ff12c264929f750")

