-- Lua provided by RyzenAPI
-- Game: Elves Castle and Secrets

-- MAIN APPLICATION
addappid(2236800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236801, 1, "828477b5853d76ea49e9784368e6c02e7ed107a72e1552473ad4bed23a8d6954")

