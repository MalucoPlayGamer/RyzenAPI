-- Lua provided by RyzenAPI
-- Game: Rogue Fist Demo

-- MAIN APPLICATION
addappid(2887000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522161,0,"86c6f18e2326032d254e0847ed344e49d280c0e1e813411317c393c6ce2f1e36")

