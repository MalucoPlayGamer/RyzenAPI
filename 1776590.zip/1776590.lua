-- Lua provided by RyzenAPI
-- Game: Dark Gravity: Prologue

-- MAIN APPLICATION
addappid(1776590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776591, 1, "7ac97534642fdea448bcd61395e162195ed172ef6be13ddee58935972f1702a0")
