-- Lua provided by RyzenAPI
-- Game: Dark Gravity: Prologue

-- MAIN APPLICATION
addappid(1776590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776591, 1, "7ac97534642fdea448bcd61395e162195ed172ef6be13ddee58935972f1702a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
