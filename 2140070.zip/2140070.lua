-- Lua provided by RyzenAPI
-- Game: Game: Sinner 97: Prologue

-- MAIN APPLICATION
addappid(2140070)
-- Game: addappid(2140070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140071, 1, "5f40d13d93f16a8d0f44c55277093614569cb1a5a9b7a8b8addd165bf67c7bce")
