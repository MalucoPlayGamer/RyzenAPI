-- Lua provided by RyzenAPI 
-- Game: Chill Town
addappid(1940200)
addappid(1940201, 1, "b2fae96ac3c63f77884db54389bdc70035d58f6a2d03cdddf92bc3d8ba509aa2")
