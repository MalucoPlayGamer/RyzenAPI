-- Lua provided by RyzenAPI
-- Game: AppID 938270

-- MAIN APPLICATION
addappid(938270)

-- MAIN APP DEPOTS / PACKAGES
addappid(938271, 1, "d842cf8cbd498b8fd2784779812e4e8b714a787b9a4efbf76b602bb7349edd0a")
addappid(938272, 1, "7a3f9d14f4903f51dc02e6c8ca13fbd7a0926e61ec2328a8adea54a6526c9ec0")
addappid(1044160, 0, "8c20455375316ba95ebb770d22cc52f274a4e96c55a3a699bbad0b732852225b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
