-- Lua provided by RyzenAPI
-- Game: addappid(938270)

-- MAIN APPLICATION
addappid(938270)

-- MAIN APP DEPOTS / PACKAGES
addappid(938271, 1, "d842cf8cbd498b8fd2784779812e4e8b714a787b9a4efbf76b602bb7349edd0a")
addappid(938272, 1, "7a3f9d14f4903f51dc02e6c8ca13fbd7a0926e61ec2328a8adea54a6526c9ec0")
addappid(1044160, 0, "8c20455375316ba95ebb770d22cc52f274a4e96c55a3a699bbad0b732852225b")
