-- Lua provided by RyzenAPI
-- Game: Jrago II Guardians of Eden Soundtrack

-- MAIN APPLICATION
addappid(2953460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2953462,0,"62fdb58f8ac0e8b320f6f6669bbae5f080f7c690ff3317271edb44629f5d5b18")

