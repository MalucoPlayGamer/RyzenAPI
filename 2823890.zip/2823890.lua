-- Lua provided by RyzenAPI
-- Game: 2823890

-- MAIN APPLICATION
addappid(2823890)
addappid(3233380)
-- Game: addappid(2823890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823891, 1, "ddce5c76bbe95ebbf33fa279d0ecbff6bc7dda09d8e6a62e191162606265e694")
