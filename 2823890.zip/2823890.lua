-- Lua provided by RyzenAPI
-- Game: Center Station Simulator

-- MAIN APPLICATION
addappid(2823890)
addappid(3233380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823891, 1, "ddce5c76bbe95ebbf33fa279d0ecbff6bc7dda09d8e6a62e191162606265e694")
