-- Lua provided by RyzenAPI
-- Game: Creepy Tale 3: Ingrid Penance Soundtrack

-- MAIN APPLICATION
addappid(2310120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310121, 1, "90fe46cc4712cffa16e450d1178d23064a4127f34bbf7c19652b684334d42099")
