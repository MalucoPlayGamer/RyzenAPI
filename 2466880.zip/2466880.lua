-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Farming

-- MAIN APPLICATION
addappid(2466880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466881, 1, "8e9529457bae8cbe5df4fdf637e3b10bd447cfbf97188b5155498676876b7901")
