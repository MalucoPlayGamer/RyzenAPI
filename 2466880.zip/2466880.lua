-- Lua provided by SkyAPI 
-- Game: 3D PUZZLE - Farming
addappid(2466880)
addappid(2466881, 1, "8e9529457bae8cbe5df4fdf637e3b10bd447cfbf97188b5155498676876b7901")
