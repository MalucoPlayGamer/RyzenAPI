-- Lua provided by RyzenAPI
-- Game: Game: Kawaii Girls Soundtrack

-- MAIN APPLICATION
addappid(1716010)
-- Game: addappid(1716010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716011, 1, "ca62a64c4917b94fcd1c6a121e0b335ef6ab61db34be10a07703f9e0ae5ad163")
