-- Lua provided by RyzenAPI
-- Game: Divine Omen

-- MAIN APPLICATION
addappid(2997900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997901,0,"4d8c851477fb78d7f7472588e5df3800333a4c4122a8ce42c1960babafaadafc")

