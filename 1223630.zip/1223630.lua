-- Lua provided by RyzenAPI
-- Game: TWDSS: Digital Audio Bonus

-- MAIN APPLICATION
addappid(1223630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223630,0,"815001725c619c2217d8a0c4e295fbe1342ca6c745cf0f382a5fd023af710eac")

