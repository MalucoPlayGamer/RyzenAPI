-- Lua provided by RyzenAPI
-- Game: Puzzle & Maze

-- MAIN APPLICATION
addappid(1633400)
-- Game: addappid(1633400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633401, 1, "adf6a8b4561bb647f82862cf1a0ce29b8569ce812ad63dfffa84d2f62c6d25ce")
