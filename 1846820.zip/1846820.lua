-- Lua provided by RyzenAPI
-- Game: Age of Empires IV Content Editor

-- MAIN APPLICATION
addappid(1846820)
-- Game: addappid(1846820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846821, 1, "e8b55d161ce71164dd88eab08cea80d892d8d7a48ec6d2fffcded3a9366d9602")
