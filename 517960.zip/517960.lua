-- Lua provided by RyzenAPI
-- Game: Crate Punks

-- MAIN APPLICATION
addappid(517960)
-- Game: addappid(517960)

-- MAIN APP DEPOTS / PACKAGES
addappid(517961, 1, "d2f12a0e4bd82927edcec6e3a719c38b8cd4b031026f4faf4424e33df0581b64")
addappid(517963, 1, "38b645e9bafb587ea513583ef8607d4536f274ff1ffc11f7c85e2e0f8f2154d2")
addappid(517964, 1, "b57dc2727aa3dabe55f4dcc37dee411aebeda7c8415d10d8588740bf9510fc39")
