-- Lua provided by RyzenAPI
-- Game: Your Daddy

-- MAIN APPLICATION
addappid(4551520)
addappid(4551620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4551521,0,"50908bcd31ff0ba8f230397139b677eb198b205e8e3bee8fb86e15018ccb2560")

