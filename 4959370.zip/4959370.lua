-- Lua provided by RyzenAPI
-- Game: Star Surge

-- MAIN APPLICATION
addappid(4959370) -- Star Surge

-- MAIN APP DEPOTS / PACKAGES
addappid(4959371, 1, "3e5268f3d33ed406f301edfce9530f1ffc3b1de146fe5a47cbf84c49bfc74f88") -- Depot 4959371
