-- Lua provided by RyzenAPI
-- Game: Polyarmory: High Calibre Love

-- MAIN APPLICATION
addappid(4220820)

