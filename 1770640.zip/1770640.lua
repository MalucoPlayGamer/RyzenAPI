-- Lua provided by SkyAPI 
-- Game: Death's Gambit: Afterlife Soundtrack
addappid(1770640)
addappid(1770641, 1, "e5b3449b8e390aba4d9fdbb44bda67b77fcfab5000750ebf4ed0d56b0ecc717b")
addappid(1770643, 1, "267a94ff8641a1d34c12c5ce6f948a160f824126ab9c2eaae4f391b2949a18dd")
