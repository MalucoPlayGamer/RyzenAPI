-- Lua provided by RyzenAPI
-- Game: Acceleration of SUGURI X-Edition HD

-- MAIN APPLICATION
addappid(265170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(265171, 1, "969582208b85e6647d82bcb8d3a438fdf3df491c5b7884eb5241c5980693b85b")

