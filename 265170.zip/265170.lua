-- Lua provided by RyzenAPI
-- Game: addappid(265170)

-- MAIN APPLICATION
addappid(265170)

-- MAIN APP DEPOTS / PACKAGES
addappid(265171, 1, "969582208b85e6647d82bcb8d3a438fdf3df491c5b7884eb5241c5980693b85b")
