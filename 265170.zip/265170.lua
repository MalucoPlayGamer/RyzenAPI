-- Lua provided by SkyAPI 
-- Game: Acceleration of SUGURI X-Edition HD
addappid(265170)
addappid(265171, 1, "969582208b85e6647d82bcb8d3a438fdf3df491c5b7884eb5241c5980693b85b")
