-- Lua provided by RyzenAPI
-- Game: AppID 276460

-- MAIN APPLICATION
addappid(276460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(276461, 1, "051d1f518486dc065b26eafffc71cd6d6dba251262d075f55c6b58219650f6bd")
addappid(276462, 1, "d57b72de73af4c4e5131a293ec20f2cb4c1a2e1bf24b048a55d5075a779d61a4")
addappid(276463, 1, "d0912d6a7807d18bdd7b390d5aa6bdb8b5800a22592d625f2fbeea26556b8341")

