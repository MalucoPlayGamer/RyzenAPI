-- Lua provided by RyzenAPI
-- Game: VRMark

-- MAIN APPLICATION
addappid(464170)

-- MAIN APP DEPOTS / PACKAGES
addappid(464171, 1, "a4b995e55ca0d7e39d72c5d10dcec1267af6282a3ac056d357ee190d4701ad8c")
addappid(464172, 1, "d2c85495386ebddbd7131f17eaeb0b0852c85910f3b86b92c58340a04b294d43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
