-- Lua provided by RyzenAPI
-- Game: 464170

-- MAIN APPLICATION
addappid(464170)
-- Game: addappid(464170)

-- MAIN APP DEPOTS / PACKAGES
addappid(464171, 1, "a4b995e55ca0d7e39d72c5d10dcec1267af6282a3ac056d357ee190d4701ad8c")
addappid(464172, 1, "d2c85495386ebddbd7131f17eaeb0b0852c85910f3b86b92c58340a04b294d43")
