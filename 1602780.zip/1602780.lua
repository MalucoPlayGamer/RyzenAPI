-- Lua provided by RyzenAPI
-- Game: Icarus Demo

-- MAIN APPLICATION
addappid(1602780)
-- Game: addappid(1602780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602781, 1, "55d36e8ba6af5ec617f15106afda1af318c2bba8abc3533631175d14b3e2d8d0")
