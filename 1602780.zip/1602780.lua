-- Lua provided by SkyAPI 
-- Game: Icarus Demo
addappid(1602780)
addappid(1602781, 1, "55d36e8ba6af5ec617f15106afda1af318c2bba8abc3533631175d14b3e2d8d0")
