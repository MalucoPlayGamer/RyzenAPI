-- Lua provided by RyzenAPI
-- Game: Anime Artist

-- MAIN APPLICATION
addappid(1101270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101271, 1, "95c40845f2b9fb84202f467e52ea3eaad3645c1d6cff6ded68a13ec85437ac02")
addappid(1127410, 0, "f4b4831135481a8106b9f940a0dd1d17a5761feb3bdc952de26e4c80ada9ef0b")
addappid(1127411, 0, "6289c338579ecdfa44a68b89698716eaa0fcfea0d525258bb546a1c967f3b085")
addappid(1127412, 0, "657e339a0ccb47dfe6e33c1d3a9b123e763648fda0ba3cbc9bccd6bd0a16bce0")
addappid(1128070, 0, "3965f3b2d626f80b867c8a46053bd6745e19fddd621e1ebdffee4ec36e99eaa0")
addappid(1149840, 0, "5228a85a1e48d77cfda287ff1a54dbaab94870f2a693d52d2785421bf7673645")
addappid(1207450, 0, "97f3a835688265471c9809f7e0c1a46681f5b90ac95e9b3023f600ea0f4996c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
