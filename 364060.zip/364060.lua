-- Lua provided by RyzenAPI
-- Game: Capsule Force

-- MAIN APPLICATION
addappid(364060)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(364061, 1, "55d5988bf61e6431218ac3337bd7eedb86a40f820b8d95d3289c22220ba6ee09")
addappid(364062, 1, "d1a0f0ea58d17c4b0cedac8ce6d6312f45d5cab3c30c01f755479928508ed9f2")
addappid(364063, 1, "c8b197d58191271ddffd29ae3c30cf2affdde266a696e6b39e2fef3b8f79d09e")

