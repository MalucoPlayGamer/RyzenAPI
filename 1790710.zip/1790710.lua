-- Lua provided by RyzenAPI
-- Game: addappid(1790710)

-- MAIN APPLICATION
addappid(1790710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790711, 1, "6ef4d7f1ed52d8b23e734ed67b95de2c061ddaf33ff4af0960c60edba80b54a8")
