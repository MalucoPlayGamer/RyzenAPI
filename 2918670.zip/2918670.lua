-- Lua provided by RyzenAPI
-- Game: 2918670

-- MAIN APPLICATION
addappid(2918670)
-- Game: addappid(2918670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918672,0,"bf9375dbf5e4539f8037e8595b6f4ab86d56317a3490f8f9f6dac2689d938e96")
