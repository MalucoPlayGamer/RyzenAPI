-- Lua provided by RyzenAPI 
-- Game: AppID 781810
addappid(781810)
addappid(781811, 1, "6f2edb2f7711a519d503085f70b1692afc61f7c22c79bd2b64030b40d42d9861")
addappid(889430, 0, "b966d1f4ecd5db496c3dc1782ad054dd35447b042b31fad6acc58f9579bb3559")
