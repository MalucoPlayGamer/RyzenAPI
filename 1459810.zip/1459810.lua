-- Lua provided by RyzenAPI
-- Game: 1459810

-- MAIN APPLICATION
addappid(1459810)
-- Game: addappid(1459810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459811, 1, "4c8a0989cf6d22e94dd4557ca8828d6bddffd0dee865932d712c7001928c0858")
