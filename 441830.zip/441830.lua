-- Lua provided by RyzenAPI
-- Game: AppID 441830

-- MAIN APPLICATION
addappid(441830)
addappid(501770)
addappid(501780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(441831, 1, "6988f2389a442305a32cd353593837b14ae608b590d3407289a8060b8ac0c75b")
addappid(501040, 0, "2246fafc79b08f13a4632cb379251efe14a35dee4bec9b7eecdff8ba50a7bfb8")

