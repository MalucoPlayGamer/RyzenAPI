-- Lua provided by RyzenAPI
-- Game: My Digital Diary

-- MAIN APPLICATION
addappid(4902040) -- My Digital Diary

-- MAIN APP DEPOTS / PACKAGES
addappid(4902041, 1, "306d22017fab3d8e3e411a6eb85940ef90da729e4e052520943339c5cde5bc8d") -- Depot 4902041

