-- 4902040's Lua and Manifest Created by Hubcap Manifest
-- My Digital Diary
-- Created: August 01, 2026 at 09:13:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4902040) -- My Digital Diary
-- MAIN APP DEPOTS
addappid(4902041, 1, "306d22017fab3d8e3e411a6eb85940ef90da729e4e052520943339c5cde5bc8d") -- Depot 4902041
setManifestid(4902041, "546648784783709002", 349288005)