-- Lua provided by RyzenAPI
-- Game: Blacksad: Under the Skin

-- MAIN APPLICATION
addappid(1003890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1003891, 1, "08864a449ba7f972995a5ccee45e85056d3feeaf97122380167efe0260631ecb")
addappid(1003892, 1, "267878109be2b1410a1b3ae8a9f22833d3625349fc5bb1f5c505a558567131c8")

