-- Lua provided by RyzenAPI
-- Game: Isekai Harem Quest: Love, Blades, and Power

-- MAIN APPLICATION
addappid(3516700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516701, 1, "02a8bc0cdf5d67a84b3b5a0b8f8734e0a42ccd25fee6fa27f79e614205894b8c")

