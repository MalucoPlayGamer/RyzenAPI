-- Lua provided by RyzenAPI
-- Game: Dragonheir: Silent Gods

-- MAIN APPLICATION
addappid(2203070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203071, 1, "f0b4478e230d75d0b02cd094823aee1854ba8661515eb6913ad859a46ab43ad7")
