-- Lua provided by RyzenAPI
-- Game: Game: The Rangers In The South

-- MAIN APPLICATION
addappid(3074110)
-- Game: addappid(3074110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074111, 1, "979451bc4e8c9a6b5839063c8eb1be1aec69c166335fda4221c86886f9bac99e")
