-- Lua provided by RyzenAPI
-- Game: Game: 虚衝 - Kyosho

-- MAIN APPLICATION
addappid(3235530)
-- Game: addappid(3235530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235531, 1, "8ec4bb05aca79e7efd48df6e6422ab3c995258507aca1b13a5033e5c4dad57bd")
