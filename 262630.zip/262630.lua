-- Lua provided by RyzenAPI
-- Game: 262630

-- MAIN APPLICATION
addappid(262630)
-- Game: addappid(262630)

-- MAIN APP DEPOTS / PACKAGES
addappid(262631, 1, "7e7b4d4d7260d9001988d00f7f89b16bb6ac3355723ceef93f5cf3314476b854")
