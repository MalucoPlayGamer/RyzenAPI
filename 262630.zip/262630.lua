-- Lua provided by SkyAPI 
-- Game: AppID 262630
addappid(262630)
addappid(262631, 1, "7e7b4d4d7260d9001988d00f7f89b16bb6ac3355723ceef93f5cf3314476b854")
