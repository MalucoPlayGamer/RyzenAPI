-- Lua provided by RyzenAPI
-- Game: addappid(1285430)

-- MAIN APPLICATION
addappid(1285430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285433,0,"05a3477ba09bea0109b964c6e39c4fdcbaf2ee9053ea1aa26eee34a4380358fc")
