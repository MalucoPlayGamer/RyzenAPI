-- Lua provided by RyzenAPI
-- Game: Hard Chip

-- MAIN APPLICATION
addappid(2844290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844291, 1, "1379b9884d664079f91bd8978edb0237b091e9a721bb8c2d727857d20c6c318e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
