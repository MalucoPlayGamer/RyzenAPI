-- Lua provided by RyzenAPI
-- Game: Game: Hard Chip

-- MAIN APPLICATION
addappid(2844290)
-- Game: addappid(2844290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844291, 1, "1379b9884d664079f91bd8978edb0237b091e9a721bb8c2d727857d20c6c318e")
