-- Lua provided by RyzenAPI 
-- Game: Gevaudan
addappid(636520)
addappid(636521, 1, "c3ae3e87cd07f4ac2df677ab159d4e92da655fb2f5ce76164a37198b105c05ad")
