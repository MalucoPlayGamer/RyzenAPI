-- Lua provided by RyzenAPI
-- Game: Uncharted Waters Online - Steam

-- MAIN APPLICATION
addappid(890400)

-- MAIN APP DEPOTS / PACKAGES
addappid(890401, 1, "519cadd69c338340c92dadbb483cbf481e50439845cf7e1cddd0ed33e81e03ab")

