-- Lua provided by RyzenAPI
-- Game: Civil War: 1861

-- MAIN APPLICATION
addappid(540230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(540231, 1, "4a9f10f4982adaaafb8e57b4f00be939f342a6bc599184280d6dd5885a66df8a")
addappid(540232, 1, "2f309c2f207fe37957541d8abbe72ddc53f41abac222fd2197d24b972767c85d")

