-- Lua provided by RyzenAPI
-- Game: Civil War: 1861

-- MAIN APPLICATION
addappid(540230)

-- MAIN APP DEPOTS / PACKAGES
addappid(540231, 1, "4a9f10f4982adaaafb8e57b4f00be939f342a6bc599184280d6dd5885a66df8a")
addappid(540232, 1, "2f309c2f207fe37957541d8abbe72ddc53f41abac222fd2197d24b972767c85d")

