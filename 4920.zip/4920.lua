-- Lua provided by RyzenAPI
-- Game: Natural Selection 2

-- MAIN APPLICATION
addappid(4920)
addappid(228985)
addappid(228988)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4921, 1, "404f43c145bf0ec8650c4029a9e125acc0933fe51a4a9c668f39c83af1f3fb62")
addappid(4923, 1, "038b6f4bc96c145c756ba5538ec1b4530b176e7d89cf0b548a1ad34086a01264")
addappid(4924, 1, "08398ae541fbc2a3c5fb297c3b17a0abe37e881e8c23241737b75622731f95f3")
addappid(4932, 1, "c164a40033ef981edbda8b32a66dc6a28cc325483db8b20dad4eea323f624487")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4930)
addappid(4931)
addappid(250890)
addappid(250891)
addappid(250892)
addappid(250893)
addappid(274150)
addappid(280760)
addappid(280761)
addappid(280762)
addappid(280763)
addappid(296360)
addappid(310100)
addappid(333230)
addappid(441480)
addappid(471240)
addappid(494080)
addappid(740650)
addappid(740660)
addappid(870920)
addappid(926020)
addappid(1183100)
addappid(1183101)
addappid(1183102)
