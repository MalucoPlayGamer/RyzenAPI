-- Lua provided by RyzenAPI
-- Game: 869590

-- MAIN APPLICATION
addappid(869590)
-- Game: addappid(869590)

-- MAIN APP DEPOTS / PACKAGES
addappid(869591, 1, "d5e7126f668ec15da92a158a614b264b25816651a4ef67e8e2190558d7dca185")
