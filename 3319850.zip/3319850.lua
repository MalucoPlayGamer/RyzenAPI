-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3319850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319850,0,"95133ff39c5da8ae0536933d236bb7eab7c1df24a6fedc606bcf5d0867c1a016")
addtoken(3319850,10944105112804011624)

