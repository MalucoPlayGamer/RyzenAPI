-- Lua provided by RyzenAPI
-- Game: 1582700

-- MAIN APPLICATION
addappid(1582700)
-- Game: addappid(1582700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582701, 1, "92d92e0a3bd69c0e1cd09fe1a08e48810b727c005194e85e634585bfb9b9ab5f")
