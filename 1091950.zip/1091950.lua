-- Lua provided by RyzenAPI
-- Game: Naughty Girl

-- MAIN APPLICATION
addappid(1091950)
-- Game: addappid(1091950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091951, 1, "05f4650b00a1412d19a5c9af170364aa39115ba2452b44c1b6d6fa48cd0685b0")
addappid(1102530, 0, "e95c8dc9e4fd6679bc25a83b2c6be909e6f3ab2407f0885ddff907c9ba46be8d")
addappid(1102540, 0, "d5c944e655be2d3b0147d6943e82e302a5afafc386cae17aac5f1c7a9e3da8c8")
