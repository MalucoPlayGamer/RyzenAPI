-- Lua provided by RyzenAPI
-- Game: Poly Fire

-- MAIN APPLICATION
addappid(3255600)
-- Game: addappid(3255600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255601, 1, "e921bce89f70456a6cfedd6559e1aee6639d4ab9537f6beedd44338e168403aa")
