-- Lua provided by RyzenAPI
-- Game: Poly Fire

-- MAIN APPLICATION
addappid(3255600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255601, 1, "e921bce89f70456a6cfedd6559e1aee6639d4ab9537f6beedd44338e168403aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
