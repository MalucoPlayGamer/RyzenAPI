-- Lua provided by RyzenAPI
-- Game: Immersion Chess

-- MAIN APPLICATION
addappid(631660)

-- MAIN APP DEPOTS / PACKAGES
addappid(631661, 1, "d08d0ea9dad37bd7729e347ed510467f2d39c21e76107b8cfd04ce86f7b0119b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
