-- Lua provided by RyzenAPI
-- Game: Immersion Chess

-- MAIN APPLICATION
addappid(631660)

-- MAIN APP DEPOTS / PACKAGES
addappid(631661, 1, "d08d0ea9dad37bd7729e347ed510467f2d39c21e76107b8cfd04ce86f7b0119b")

