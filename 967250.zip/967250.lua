-- Lua provided by RyzenAPI
-- Game: Game: DOKA 2 KISHKI EDITION

-- MAIN APPLICATION
addappid(967250)
-- Game: addappid(967250)

-- MAIN APP DEPOTS / PACKAGES
addappid(967251, 1, "6102b60b40f3935d5524b25df10e352999e5c8b00053af77bfedd22e98e0db00")
addappid(979700, 0, "31e9cfb82269e7e6dd06a7af1b611c9fc624ca3ca7026e96d500f2cf51fd0dcb")
