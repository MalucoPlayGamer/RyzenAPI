-- Lua provided by RyzenAPI
-- Game: DOKA 2 KISHKI EDITION

-- MAIN APPLICATION
addappid(967250)

-- MAIN APP DEPOTS / PACKAGES
addappid(967251, 1, "6102b60b40f3935d5524b25df10e352999e5c8b00053af77bfedd22e98e0db00")
addappid(979700, 0, "31e9cfb82269e7e6dd06a7af1b611c9fc624ca3ca7026e96d500f2cf51fd0dcb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
