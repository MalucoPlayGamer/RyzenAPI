-- Lua provided by RyzenAPI
-- Game: The Radiants

-- MAIN APPLICATION
addappid(1566070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566071,0,"c2d73a87cebed9391b056e6bd75bcc04e27f26ae9a5bb1f049cb1775545ad2e0")

