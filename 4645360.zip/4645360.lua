-- 4645360's Lua and Manifest Created by Hubcap Manifest
-- Titanic Escape Simulator™
-- Created: August 24, 2026 at 10:01:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4645360) -- Titanic Escape Simulator™
-- MAIN APP DEPOTS
addappid(4645361, 1, "baa38b848f608543042944f5c56078461fb29743afba6947ec8bb2499ea9da6d") -- Depot 4645361
setManifestid(4645361, "312570818304438299", 11160846402)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)