-- Lua provided by RyzenAPI 
-- Game: AppID 2025620
addappid(2025620)
addappid(2025621, 1, "305bf8a9d76d3a2dd2c70046cd7db5e2713f8095c12443d3dd722d39ba66b51b")
