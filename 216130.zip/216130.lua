-- Lua provided by RyzenAPI
-- Game: Game: Gemini Wars

-- MAIN APPLICATION
addappid(216130)
-- Game: addappid(216130)

-- MAIN APP DEPOTS / PACKAGES
addappid(216131, 1, "0065801447d6c6e6ddc4247ad0cdbf3fe24f45f86ea477dff76a233f1e4bed0b")
addappid(216132, 1, "e07454cb978ea4a113d6712263a65b0980be88c06fac7302b649cf28e5778a96")
addappid(216133, 1, "1c7391c95bbcde199a4456b4b7352c2539bd4080bc7d0fc274b3aa274b881950")
addappid(216134, 1, "1f9e80da3ee2522745832adfcc910fa254e2281b2084829da2d25e9069a6651f")
