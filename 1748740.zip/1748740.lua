-- Lua provided by RyzenAPI
-- Game: Game: Evolution: Moon Warfare

-- MAIN APPLICATION
addappid(1748740)
-- Game: addappid(1748740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748741, 1, "4b933d333ee285ed95a5bc7d53a9cb8a639d66f670adcc770d2df7ab1fd8aee3")
