-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(689950)

-- MAIN APP DEPOTS / PACKAGES
addappid(689950,0,"174fc08cf5479cae59e5b78702ae24b0dcf9d314ff8612bdac4b2d02df3bb751")
