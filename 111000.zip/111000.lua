-- Lua provided by RyzenAPI
-- Game: The Clockwork Man

-- MAIN APPLICATION
addappid(111000)
-- Game: addappid(111000)

-- MAIN APP DEPOTS / PACKAGES
addappid(111001, 1, "5a5b92f1930d5f3ff984150b6af7ad5e547eef4d692e070bf1b46ccda54259b2")
