-- Lua provided by RyzenAPI
-- Game: Patched world

-- MAIN APPLICATION
addappid(1228630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228631, 1, "c4b6d7f6b1fc5bee4e35ee2501db9acd211c336c073e56d44940d9e404060a0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
