-- Lua provided by RyzenAPI
-- Game: Patched world

-- MAIN APPLICATION
addappid(1228630)
-- Game: addappid(1228630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228631, 1, "c4b6d7f6b1fc5bee4e35ee2501db9acd211c336c073e56d44940d9e404060a0f")
