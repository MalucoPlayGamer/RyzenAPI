-- Lua provided by RyzenAPI
-- Game: Game: AppID 833410

-- MAIN APPLICATION
addappid(833410)
-- Game: addappid(833410)

-- MAIN APP DEPOTS / PACKAGES
addappid(833411, 1, "1996ae31d4d52fdb203b33432b4f0aed1446ddb9b8de775747107a579f7a62c8")
