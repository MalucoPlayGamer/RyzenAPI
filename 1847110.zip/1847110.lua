-- Lua provided by RyzenAPI
-- Game: Satan's puzzle 666

-- MAIN APPLICATION
addappid(1847110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847111, 1, "bb988b0e37cd4d3d8386e43d8bc137f0ce965e3ad9a428e0ef838844ab330c34")

