-- Lua provided by RyzenAPI
-- Game: 527760

-- MAIN APPLICATION
addappid(527760)
-- Game: addappid(527760)

-- MAIN APP DEPOTS / PACKAGES
addappid(527761, 1, "7c4a0129907d21b6a4f36f1854d6f3eaea123a1882b3b143db11e17fb44e1e9b")
addappid(528290, 0, "ebf12f59f9c5b8d204c30f95764dd3cd3d6c2ce029c6f2436a18eaafc31ad066")
