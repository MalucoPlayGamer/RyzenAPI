-- Lua provided by RyzenAPI
-- Game: Block Legend DX

-- MAIN APPLICATION
addappid(345640)

-- MAIN APP DEPOTS / PACKAGES
addappid(345641, 1, "38fa0e37433be81d2de296b9c559f8a816eebcb26f33cd959d919a6a4c785d17")
addappid(345642, 1, "2073268905da8c8b2daad69014809de1efce6a09b3fd2d0d7523a305e6739154")
