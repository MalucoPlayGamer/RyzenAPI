-- Lua provided by RyzenAPI
-- Game: 打工吧！天使酱 - 原画集&表情包

-- MAIN APPLICATION
addappid(2095550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095550,0,"3838070bf9ca6795c8e44d9bce36e98642116f650ff20509d6d074eeaf190654")

