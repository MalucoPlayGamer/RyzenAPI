-- Lua provided by RyzenAPI
-- Game: AppID 205730

-- MAIN APPLICATION
addappid(205730)

-- MAIN APP DEPOTS / PACKAGES
addappid(205731, 1, "27c2d822d03edf37865a1a6af3e37ff4a5a712b45ec29f93157c38e9a07daf8a")
addappid(205732, 1, "99626206d0847be0d3661f38003fcfac029dd83eb326ac42bd5bcd35942ef181")
addappid(205733, 1, "0c8e06c16f1ce28cad468dd513a574f4ccbd6406a4588788c803217b47b5617d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
