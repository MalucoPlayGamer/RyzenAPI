-- Lua provided by RyzenAPI
-- Game: Team Principal: A Racing Manager

-- MAIN APPLICATION
addappid(4340600)

-- MAIN APP DEPOTS / PACKAGES
addappid(4340602,0,"b12ec82a7934b9819c8b28f36f1b677991b1e34ca443bd57c7acf891da79d99d")

