-- Lua provided by RyzenAPI
-- Game: Game: It's Hasegawa-san!?

-- MAIN APPLICATION
addappid(1896010)
-- Game: addappid(1896010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896011, 1, "a46eb460fd9974d247c5f550771b39ed7872a181b10ffd52444a23c6eb569277")
