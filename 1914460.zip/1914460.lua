-- Lua provided by RyzenAPI
-- Game: Ancient Medieval Empire

-- MAIN APPLICATION
addappid(1914460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914461, 1, "a902cc1935fdd9e434e6a43ee794732cc9c1f9cccb9bd1212fa396c1a0441e9a")

