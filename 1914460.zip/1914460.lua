-- Lua provided by RyzenAPI 
-- Game: Ancient Medieval Empire
addappid(1914460)
addappid(1914461, 1, "a902cc1935fdd9e434e6a43ee794732cc9c1f9cccb9bd1212fa396c1a0441e9a")
