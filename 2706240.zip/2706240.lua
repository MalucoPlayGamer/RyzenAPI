-- Lua provided by RyzenAPI
-- Game: Game: Ooga Demo

-- MAIN APPLICATION
addappid(2706240)
-- Game: addappid(2706240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706241, 1, "f0a5682b010d5da4a81bc9da97c9ee9335b4848ec4da705f705cf384a7cfc5aa")
