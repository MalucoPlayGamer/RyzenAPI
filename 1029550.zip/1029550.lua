-- Lua provided by RyzenAPI 
-- Game: AppID 1029550
addappid(1029550)
addappid(1029551, 1, "be8027e5929e7be5b64a639da0cc132be37d336da6b6b34796a25fe258a09e75")
