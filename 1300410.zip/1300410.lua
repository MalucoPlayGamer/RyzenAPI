-- Lua provided by RyzenAPI
-- Game: AppID 1300410

-- MAIN APPLICATION
addappid(1300410)
-- Game: addappid(1300410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300411, 1, "1a940a608c812d4e3f071144e0cd612dede7cd5b59c70d9e62664518a8f64bf8")
addappid(1300412, 1, "40da6c3f81db6ca24327152598fb6a3332a0e2ab09b2f5c5a50cbd449eec9460")
