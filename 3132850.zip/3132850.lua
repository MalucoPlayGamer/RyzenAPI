-- Lua provided by RyzenAPI
-- Game: HARK THE GHOUL Demo

-- MAIN APPLICATION
addappid(3132850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132851, 1, "4846c27fc16475d9f13f8c5cc8fda7eb7c2e44a89fa872a5cf15ce764fd80ff8")

