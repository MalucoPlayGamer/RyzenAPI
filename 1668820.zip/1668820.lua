-- Lua provided by RyzenAPI 
-- Game: Horses and Girls
addappid(1668820)
addappid(1668821, 1, "2efb9930f2f69f4e5c23dff3fa71f0f20c9b303a5a9de0ced97419cba2a0cb5e")
