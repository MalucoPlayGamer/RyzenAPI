-- Lua provided by RyzenAPI 
-- Game: Farewell North
addappid(1432850)
addappid(1432851, 1, "ed97dd956630dbb7c87a032bb0bd021686e4c55717d9b52284b2eca220d60eef")
