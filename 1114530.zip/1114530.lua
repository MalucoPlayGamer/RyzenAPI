-- Lua provided by RyzenAPI
-- Game: TTV3

-- MAIN APPLICATION
addappid(1114530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1114531, 1, "360fd11926baece792d6ad7ae980ec01f772ebd53a7e762f275b479ee462430c")

