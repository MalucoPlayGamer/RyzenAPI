-- Lua provided by RyzenAPI
-- Game: AppID 1114530

-- MAIN APPLICATION
addappid(1114530)
-- Game: addappid(1114530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114531, 1, "360fd11926baece792d6ad7ae980ec01f772ebd53a7e762f275b479ee462430c")
