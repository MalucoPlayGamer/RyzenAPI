-- Lua provided by RyzenAPI
-- Game: Wild Blue Skies

-- MAIN APPLICATION
addappid(1921490) -- Wild Blue Skies

-- MAIN APP DEPOTS / PACKAGES
addappid(1921491, 1, "fa9731c470e6384d128d5847b038b59fb76b9ea5288ae9584b9861a1ebfd88c4") -- Depot 1921491

