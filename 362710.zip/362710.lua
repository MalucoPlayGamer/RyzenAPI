-- Lua provided by RyzenAPI 
-- Game: fault milestone two Demo
addappid(362710)
addappid(362711, 1, "84e77fc80b1053fd9c04da6dec7e252c1b523bc2a31c1c36572f64802a709f74")
