-- Lua provided by RyzenAPI
-- Game: AppID 3279180

-- MAIN APPLICATION
addappid(3279180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279181, 1, "92add3320ceadac763ed8b490fbb5bfaf5e02e39de2ce1de0b4fd162eb26e4dd")

