-- Lua provided by RyzenAPI
-- Game: Game: AppID 1267070

-- MAIN APPLICATION
addappid(1267070)
-- Game: addappid(1267070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267071, 1, "6fc92b4457a5ca04f24d3720b81edbc5af4c12ce567db40edcbacc41714e0d61")
