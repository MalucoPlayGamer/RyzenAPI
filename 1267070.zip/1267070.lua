-- Lua provided by SkyAPI 
-- Game: AppID 1267070
addappid(1267070)
addappid(1267071, 1, "6fc92b4457a5ca04f24d3720b81edbc5af4c12ce567db40edcbacc41714e0d61")
