-- Lua provided by RyzenAPI
-- Game: addappid(1918920)

-- MAIN APPLICATION
addappid(1918920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918921, 1, "c3bf46bdf1bdda617240bfccb24e593fbee99493e54f84698cc4210ead405d5e")
