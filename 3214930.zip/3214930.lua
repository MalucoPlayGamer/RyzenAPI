-- Lua provided by RyzenAPI
-- Game: addappid(3214930)

-- MAIN APPLICATION
addappid(3214930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214931, 1, "187b76b1cc6f2cf168c4f9f99c3f230678b7541f36e387f4ecbbaa30176c7454")
