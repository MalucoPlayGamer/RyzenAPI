-- Lua provided by RyzenAPI
-- Game: Game: AppID 1279450

-- MAIN APPLICATION
addappid(1279450)
-- Game: addappid(1279450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279451, 1, "814cb3b9037f2180e617bb067fa8764f78e494a5ecb9e3e2e38da5b4d978b377")
