-- Lua provided by RyzenAPI
-- Game: Kao the Kangaroo - Oh! Well

-- MAIN APPLICATION
addappid(2052963)
-- Game: addappid(2052963)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052963,0,"b212351a65bf2217fc4cafbc65c5cee8868e2654d7b6bf23e18440cc02c78300")
