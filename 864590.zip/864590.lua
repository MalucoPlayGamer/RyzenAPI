-- Lua provided by RyzenAPI
-- Game: AppID 864590

-- MAIN APPLICATION
addappid(864590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(864591, 1, "b2a817acd023a9f9d3bbb6d3c3c0c152bda9dfb76645318815fdef5e471c4a2b")

