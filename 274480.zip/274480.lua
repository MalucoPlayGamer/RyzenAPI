-- Lua provided by SkyAPI 
-- Game: Drox Operative
addappid(274480)
addappid(274481, 1, "af3fc0825e9faae7eddc02d16d035540b93997ed531e188a0f28f7068e50b647")
addappid(274482, 1, "ad38f6ac1e5f87aa2fc4601fb4ac0d5e4eb605068740ec79e913ed7bd9650960")
addappid(274483, 1, "54f92f87278dffe0036de50b2a08c2987a8bb2e7618dd2746e55a64b2385dba8")
addappid(274484, 1, "9f613beaaf6ced8be1e14ee3eb67758ac3d5b179a5c3f28f20fa5eded0c7138d")
addappid(282280, 0, "1368cb7084046fe2ab3f10bd53d5be1cffb1e93f46f1a3cc484ed2dafc555596")
