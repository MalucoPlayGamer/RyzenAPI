-- Lua provided by RyzenAPI 
-- Game: Gunman And The Witch
addappid(1195220)
addappid(1195221, 1, "74e0ccc6b05fde32b24c13de00c4930d8c30531356d07032ad7f476f7198eda1")
