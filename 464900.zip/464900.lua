-- Lua provided by RyzenAPI
-- Game: Pitfall Planet

-- MAIN APPLICATION
addappid(464900)
-- Game: addappid(464900)

-- MAIN APP DEPOTS / PACKAGES
addappid(464901, 1, "c3740ea223892b14c04492c865225664744ae1e4b135a79379cf1b12673d74b1")
