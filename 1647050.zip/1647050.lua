-- Lua provided by RyzenAPI
-- Game: Arcade Boy

-- MAIN APPLICATION
addappid(1647050)
-- Game: addappid(1647050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647051, 1, "420f9cdc770b2a11b3c2214f3e23d78ecaf6b70cc2351edf39cc284592e3fcc9")
