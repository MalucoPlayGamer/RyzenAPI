-- Lua provided by RyzenAPI
-- Game: Arcade Boy

-- MAIN APPLICATION
addappid(1647050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1647051, 1, "420f9cdc770b2a11b3c2214f3e23d78ecaf6b70cc2351edf39cc284592e3fcc9")

