-- Lua provided by RyzenAPI 
-- Game: Cryptmaster Demo
addappid(2389670)
addappid(2389671, 1, "16868d857f44745a59cf920c9800324f432474486402ccf73829a70e3dbc3663")
