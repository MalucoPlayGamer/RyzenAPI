-- Lua provided by RyzenAPI
-- Game: Absence

-- MAIN APPLICATION
addappid(440470)
-- Game: addappid(440470)

-- MAIN APP DEPOTS / PACKAGES
addappid(440471, 1, "5fb37d64ccca0fa3b3d7b36a6aaf6a5df5b951f169f7a86a69d0522d927c5ab6")
