-- Lua provided by RyzenAPI
-- Game: AppID 1623660

-- MAIN APPLICATION
addappid(1623660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623661, 1, "1041c3b158f316ee0590805796ae98ddb308f7468e1ce6de0ed1df161c879141")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
