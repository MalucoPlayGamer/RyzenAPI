-- Lua provided by RyzenAPI
-- Game: addappid(1623660)

-- MAIN APPLICATION
addappid(1623660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623661, 1, "1041c3b158f316ee0590805796ae98ddb308f7468e1ce6de0ed1df161c879141")
