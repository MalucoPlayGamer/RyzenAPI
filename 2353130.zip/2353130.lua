-- Lua provided by RyzenAPI
-- Game: 2353130

-- MAIN APPLICATION
addappid(2353130)
-- Game: addappid(2353130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353131, 1, "7e4b6bb2bbafaba3b15c2dffe0b0ab2a381513ec1624010a0df7ae5cedfdc9db")
