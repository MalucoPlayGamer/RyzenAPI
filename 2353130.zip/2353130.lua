-- Lua provided by SkyAPI 
-- Game: 刻印战记2：七圣英雄
addappid(2353130)
addappid(2353131, 1, "7e4b6bb2bbafaba3b15c2dffe0b0ab2a381513ec1624010a0df7ae5cedfdc9db")
