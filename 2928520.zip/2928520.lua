-- Lua provided by RyzenAPI
-- Game: Recycling Center Simulator

-- MAIN APPLICATION
addappid(2928520)
addappid(4028400)
-- Game: addappid(2928520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928521, 1, "f3fb7b155bce959749003944da502d37f6173818bd73c9f372a32bafbea24f02")
