-- Lua provided by RyzenAPI
-- Game: addappid(619310)

-- MAIN APPLICATION
addappid(619310)

-- MAIN APP DEPOTS / PACKAGES
addappid(619311, 1, "5a309ef4154a266b6b2f0495f0863e37da9278b0b70fb4a1fb97b016405f21a1")
