-- Lua provided by RyzenAPI
-- Game: AppID 619310

-- MAIN APPLICATION
addappid(619310)

-- MAIN APP DEPOTS / PACKAGES
addappid(619311, 1, "5a309ef4154a266b6b2f0495f0863e37da9278b0b70fb4a1fb97b016405f21a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
