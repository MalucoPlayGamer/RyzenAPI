-- Lua provided by RyzenAPI 
-- Game: AppID 2512190
addappid(2512190)
addappid(2512191, 1, "5fa08366cebcb308e92199f75d953a0ac687452259bc3bead9a8f11514636db4")
