-- Lua provided by RyzenAPI
-- Game: Magic Pussy: Chapter 2

-- MAIN APPLICATION
addappid(2512190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512191, 1, "5fa08366cebcb308e92199f75d953a0ac687452259bc3bead9a8f11514636db4")

