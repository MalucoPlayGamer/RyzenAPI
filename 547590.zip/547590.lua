-- Lua provided by SkyAPI 
-- Game: AppID 547590
addappid(547590)
addappid(547591, 1, "744935e34c3034ec13c3c89df8c12245348601b737dfdbeebd7c1c3a9c942cc8")
