-- Lua provided by RyzenAPI
-- Game: Find Your Words

-- MAIN APPLICATION
addappid(2971960)

