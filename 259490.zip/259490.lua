-- Lua provided by RyzenAPI 
-- Game: AppID 259490
addappid(259490)
addappid(259491, 1, "ce18de5399dab689d66065ee76882350bbbd74a9a5b2a910a3137e420be4c80d")
addappid(259492, 1, "fc5dc20fe33900794961283e8bd94a2800904d0e8c64cd3542d5c22eb82b8622")
