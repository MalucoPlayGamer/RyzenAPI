-- Lua provided by RyzenAPI
-- Game: Fallout 3 - Soundtrack

-- MAIN APPLICATION
addappid(461150)
-- Game: addappid(461150)

-- MAIN APP DEPOTS / PACKAGES
addappid(461150,0,"a4f8cbdd8bf43bc36b880710ff9bdafd378d3686cf8fa7f6ef277f39bbc3caed")
