-- Lua provided by RyzenAPI
-- Game: Rugby League 26

-- MAIN APPLICATION
addappid(3468660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468661, 1, "8e72fac4278c479e7b5b06bf3d8d37f88bfb4eafa37267e95aa41749b085fe4b")

