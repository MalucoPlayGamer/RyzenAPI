-- Lua provided by RyzenAPI
-- Game: Faerie Solitaire

-- MAIN APPLICATION
addappid(38600)

-- MAIN APP DEPOTS / PACKAGES
addappid(38601, 1, "f107203e6b238b8e24ac407e0e6ee40525c92996387a500ba0e2351ebbcabb0d")
addappid(38602, 1, "5912011febd37fbe11661b99f89be17dcfd62f0b434c4724d39c6facf1536acb")
addappid(38603, 1, "335e1e97c3c94a12961c586d78f017d44d5975fb4245e2e9ff71bb9ee90970aa")
