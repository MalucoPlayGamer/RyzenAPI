-- Lua provided by RyzenAPI
-- Game: Game: Robolife2 - Nova Duty

-- MAIN APPLICATION
addappid(1777390)
-- Game: addappid(1777390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777391, 1, "1e8d1498a3a66626ed40273e9e78bf2abccb999576944f0c7919e111eff4bd8d")
