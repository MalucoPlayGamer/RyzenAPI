-- Lua provided by SkyAPI 
-- Game: AppID 527240
addappid(527240)
addappid(527241, 1, "46e7d09f9645aaee071734c45dd3887f09d1f0b63b305290bc59525a00ad6c58")
