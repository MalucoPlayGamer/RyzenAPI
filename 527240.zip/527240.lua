-- Lua provided by RyzenAPI
-- Game: Geology Business

-- MAIN APPLICATION
addappid(527240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(527241, 1, "46e7d09f9645aaee071734c45dd3887f09d1f0b63b305290bc59525a00ad6c58")
