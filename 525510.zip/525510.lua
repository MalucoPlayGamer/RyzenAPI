-- Lua provided by RyzenAPI
-- Game: 525510

-- MAIN APPLICATION
addappid(525510)
-- Game: addappid(525510)

-- MAIN APP DEPOTS / PACKAGES
addappid(525512,0,"bf4bc2a7d03327bcb1bc2e7889348c38818eb196785c6f684bdba8c986fa366e")
addappid(525513,0,"69f77227ffbf3c0b3cfeacc62b69818e74849f267d4a503bd08850c15951eb60")
