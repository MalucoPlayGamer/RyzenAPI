-- Lua provided by RyzenAPI
-- Game: Pizza Apocalypse

-- MAIN APPLICATION
addappid(1706710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706711, 1, "03afd324801a87e7baf330e461dd883495387937f4b09c8aec3fd5c59ef1083b")
