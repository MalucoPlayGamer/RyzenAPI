-- Lua provided by RyzenAPI
-- Game: 2355080

-- MAIN APPLICATION
addappid(2355080)
-- Game: addappid(2355080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355081, 1, "e3e6e1fde91cc1e890b6873911a38d5840f62293ef9005391efae5f8e8080a85")
