-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2646600)
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(2646602,0,"e1009850cb0a4d8f2c8aa91d072bf3fbdc7367baef753e4c83c681b1de525b1d")
addappid(2646601)