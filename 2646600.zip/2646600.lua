-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(2646600)
addappid(2646601)
-- Game: addappid(2646600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646602,0,"e1009850cb0a4d8f2c8aa91d072bf3fbdc7367baef753e4c83c681b1de525b1d")
