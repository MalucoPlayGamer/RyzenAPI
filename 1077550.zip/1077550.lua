-- Lua provided by RyzenAPI
-- Game: 1077550

-- MAIN APPLICATION
addappid(1077550)
-- Game: addappid(1077550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077551, 1, "7858f8fdbea4772aaf7f6ca9b71fffbd20afd5f298c28bd0303579186618afd9")
