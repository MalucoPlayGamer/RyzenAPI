-- Lua provided by RyzenAPI
-- Game: Game: Is It Wrong to Try to Pick Up Girls in a Dungeon? Infinite Combate

-- MAIN APPLICATION
addappid(1187940)
-- Game: addappid(1187940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187941, 1, "7fff58f5d9b053749934fa69548c9b045a6c2609b51ca0b4c6850f8cdf0fb4eb")
