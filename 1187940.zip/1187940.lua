-- Lua provided by RyzenAPI
-- Game: Is It Wrong to Try to Pick Up Girls in a Dungeon? Infinite Combate

-- MAIN APPLICATION
addappid(1187940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1187941, 1, "7fff58f5d9b053749934fa69548c9b045a6c2609b51ca0b4c6850f8cdf0fb4eb")

