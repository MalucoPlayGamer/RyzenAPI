-- Lua provided by RyzenAPI
-- Game: Hentai vs Evil: Back 4 Waifus

-- MAIN APPLICATION
addappid(1408260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1408261, 1, "89f4b00450507b7d8ef88b3426737758edd3256182ac10209249b2e31809ccfa")

