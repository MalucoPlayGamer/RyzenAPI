-- Lua provided by RyzenAPI 
-- Game: AppID 1408260
addappid(1408260)
addappid(1408261, 1, "89f4b00450507b7d8ef88b3426737758edd3256182ac10209249b2e31809ccfa")
