-- Lua provided by RyzenAPI
-- Game: 511380

-- MAIN APPLICATION
addappid(511380)
-- Game: addappid(511380)

-- MAIN APP DEPOTS / PACKAGES
addappid(511381, 1, "1b65a39e788bc9143f4663ef6f87d072b3cb2c5eb73473a48e43cd2cd244bdf3")
