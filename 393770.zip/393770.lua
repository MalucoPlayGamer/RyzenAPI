-- Lua provided by RyzenAPI
-- Game: addappid(393770)

-- MAIN APPLICATION
addappid(393770)

-- MAIN APP DEPOTS / PACKAGES
addappid(393771, 1, "7ec923b1cc3c51c8feb0bb988a5cf92c35cb1584bc02583dd170049127c761c1")
