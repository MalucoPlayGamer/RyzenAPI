-- Lua provided by RyzenAPI
-- Game: Benji Challenges

-- MAIN APPLICATION
addappid(393770)

-- MAIN APP DEPOTS / PACKAGES
addappid(393771, 1, "7ec923b1cc3c51c8feb0bb988a5cf92c35cb1584bc02583dd170049127c761c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
