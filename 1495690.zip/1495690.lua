-- Lua provided by RyzenAPI
-- Game: Game: AppID 1495690

-- MAIN APPLICATION
addappid(1495690)
-- Game: addappid(1495690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495691, 1, "3f5464890d7678a3c19fc4353e84e0c987609e403b44f1f06d207111ccd5c6ce")
