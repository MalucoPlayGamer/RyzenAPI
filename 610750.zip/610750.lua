-- Lua provided by RyzenAPI
-- Game: AppID 610750

-- MAIN APPLICATION
addappid(610750)

-- MAIN APP DEPOTS / PACKAGES
addappid(610751, 1, "d8b35150d52e3862ce37fc67aadcb1fb15fdb4c213973ecf4ee80cc2e595567b")

