-- Lua provided by RyzenAPI
-- Game: Quest: Escape Room 2

-- MAIN APPLICATION
addappid(1464910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464911, 1, "406e202b24f4e66cd823dac27bb3fd3e7694acb5e1f0262a068655f6793bd9dd")

