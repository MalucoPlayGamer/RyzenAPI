-- Lua provided by RyzenAPI
-- Game: Magic Borderless

-- MAIN APPLICATION
addappid(1022230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022231, 1, "0cb12a745d788fe018c5b348b2b4feaeef10797245c3652d345138b9a63f02ba")

