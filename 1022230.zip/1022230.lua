-- Lua provided by RyzenAPI
-- Game: Magic Borderless

-- MAIN APPLICATION
addappid(1022230)
addappid(1024090)
addappid(1050610)
addappid(1050611)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1022231, 1, "0cb12a745d788fe018c5b348b2b4feaeef10797245c3652d345138b9a63f02ba")

