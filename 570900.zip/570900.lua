-- Lua provided by RyzenAPI
-- Game: addappid(570900)

-- MAIN APPLICATION
addappid(570900)

-- MAIN APP DEPOTS / PACKAGES
addappid(570901, 1, "6159bf64826d3d8c7f1a2c9d9a0ac12e7947be864fd6162ce4ad1b782b946137")
