-- Lua provided by RyzenAPI
-- Game: PHAT PHROG

-- MAIN APPLICATION
addappid(545570)

-- MAIN APP DEPOTS / PACKAGES
addappid(545571, 1, "b1a1948ee7122877d49381507776d4d629ffef4ff557f95259fde55a65d5a2b4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(546140)
addappid(1303150)
addappid(1304590)
addappid(1304591)
addappid(1345560)
addappid(1346060)
addappid(1349520)
addappid(1349521)
addappid(1349522)
addappid(1349523)
addappid(1351600)
addappid(1351601)
addappid(1351602)
addappid(1351603)
addappid(1351604)
addappid(1352170)
addappid(1352171)
addappid(1352172)
addappid(1352173)
