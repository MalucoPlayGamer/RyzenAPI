-- Lua provided by RyzenAPI
-- Game: PHAT PHROG

-- MAIN APPLICATION
addappid(545570)
-- Game: addappid(545570)

-- MAIN APP DEPOTS / PACKAGES
addappid(545571, 1, "b1a1948ee7122877d49381507776d4d629ffef4ff557f95259fde55a65d5a2b4")
