-- Lua provided by RyzenAPI
-- Game: Wicce

-- MAIN APPLICATION
addappid(465130)

-- MAIN APP DEPOTS / PACKAGES
addappid(465131, 1, "73d6ab71354f779a2e981e60f0ffe6cbff4c65b390f245604daf3f3f4ac60668")
