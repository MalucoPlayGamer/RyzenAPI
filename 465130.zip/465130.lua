-- Lua provided by RyzenAPI
-- Game: Wicce

-- MAIN APPLICATION
addappid(465130)

-- MAIN APP DEPOTS / PACKAGES
addappid(465131, 1, "73d6ab71354f779a2e981e60f0ffe6cbff4c65b390f245604daf3f3f4ac60668")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
