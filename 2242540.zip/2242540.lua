-- Lua provided by RyzenAPI
-- Game: 2242540

-- MAIN APPLICATION
addappid(2242540)
-- Game: addappid(2242540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242541, 1, "2b9fc449c17f04965d11da19eff10cdbe5ae18787299b39a839de971cab1b781")
