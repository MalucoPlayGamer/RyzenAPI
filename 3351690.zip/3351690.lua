-- Lua provided by RyzenAPI
-- Game: Gauntlet

-- MAIN APPLICATION
addappid(3351690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351691, 1, "1f9d6ef3a7aeb70f405858b0647198f5cc6da3334e6ab371fed877c604d476a2")
