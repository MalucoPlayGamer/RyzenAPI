-- Lua provided by SkyAPI 
-- Game: Alien Shepherd
addappid(1808820)
addappid(1808821, 1, "b89b082f9dd200abbcd873e7e333b9fcb13f003ec5ccd2a008189fa3294134b4")
