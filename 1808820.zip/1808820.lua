-- Lua provided by RyzenAPI
-- Game: 1808820

-- MAIN APPLICATION
addappid(1808820)
-- Game: addappid(1808820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808821, 1, "b89b082f9dd200abbcd873e7e333b9fcb13f003ec5ccd2a008189fa3294134b4")
