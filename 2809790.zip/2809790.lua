-- Lua provided by RyzenAPI
-- Game: 2809790

-- MAIN APPLICATION
addappid(2809790)
-- Game: addappid(2809790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809791, 1, "2bc492b75b7f7e3010c3270e1bf15398f66db138d4d09e25f520acfed391e4ae")
