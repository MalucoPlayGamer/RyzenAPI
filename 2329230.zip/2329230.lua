-- Lua provided by RyzenAPI
-- Game: addappid(2329230)

-- MAIN APPLICATION
addappid(2329230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2329231, 1, "4cc1574040211f69ba2ac3ed6251b0adcf0a08db632cead5ee48b878696afe87")
addappid(2329232, 1, "6c99092f0196ddc90817f52f442f72fdca2f6bbcb4cb00b022e51c4cb05958e5")
