-- Lua provided by RyzenAPI
-- Game: Dungeon Redemption

-- MAIN APPLICATION
addappid(1999970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999971, 1, "19b55ded71b22402b99a84ddc459823414b8a2f339bdd6674720e02752102d35")

