-- Lua provided by RyzenAPI
-- Game: AppID 714050

-- MAIN APPLICATION
addappid(714050)

-- MAIN APP DEPOTS / PACKAGES
addappid(714051, 1, "fe9a33f7ceb1fd34b2b04c5276ec8430955ecaddeb6a46819891fffade869a05")

