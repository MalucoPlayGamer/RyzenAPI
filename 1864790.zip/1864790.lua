-- Lua provided by RyzenAPI
-- Game: addappid(1864790)

-- MAIN APPLICATION
addappid(1864790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864792,0,"a5ef05678ea41158e3f086a52fb9f10b04c1d34115053c24d8d2e53a38dcdd05")
