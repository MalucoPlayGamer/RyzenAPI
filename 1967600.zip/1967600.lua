-- Lua provided by RyzenAPI
-- Game: Sker Ritual Demo

-- MAIN APPLICATION
addappid(1967600)
-- Game: addappid(1967600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967601, 1, "98094a8823b796a9f0a05b0e43dde94ecfad8c560559de1de7667a0fb1abcd8f")
