-- Lua provided by RyzenAPI
-- Game: The Romance of the Three Kingdoms: Legend of Shu Han

-- MAIN APPLICATION
addappid(1557690)
-- Game: addappid(1557690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557691, 1, "0adf55d7e47a96107531c2ba76585bface8b944da3b947a9a3476708f9c73e7d")
