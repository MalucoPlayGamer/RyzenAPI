-- Lua provided by RyzenAPI 
-- Game: AppID 3084260
addappid(3084260)
addappid(3084261, 1, "30de38a7e6d36bfc6744f2410d44d88b677d525ec40f25d8eee660fcd130a4eb")
