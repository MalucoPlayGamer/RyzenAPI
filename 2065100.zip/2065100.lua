-- Lua provided by RyzenAPI
-- Game: The Empanada Protocol

-- MAIN APPLICATION
addappid(2065100)
-- Game: addappid(2065100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065101, 1, "bb072e288fec41d7adb6ad6d2855c45f4c24a24be34a5af70167c9065fa2b1ee")
addappid(2065102, 1, "94fa316775bd91f3db900159c577b4b2211063d40659058c499344dca473311d")
