-- Lua provided by RyzenAPI
-- Game: LEILA Demo

-- MAIN APPLICATION
addappid(2576910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576911, 1, "25af7d0a18fb6e7e17ba8fe1339cf1054c619ba3c34ba83dce4776d3c6658697")
