-- Lua provided by RyzenAPI
-- Game: Game: MMA Simulator

-- MAIN APPLICATION
addappid(913820)
-- Game: addappid(913820)

-- MAIN APP DEPOTS / PACKAGES
addappid(913821, 1, "e6fab7e8d0a4afdb5a94b0adb87f6e787378093999805daf98bd9fbaa03156ed")
