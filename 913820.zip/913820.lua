-- Lua provided by RyzenAPI 
-- Game: MMA Simulator
addappid(913820)
addappid(913821, 1, "e6fab7e8d0a4afdb5a94b0adb87f6e787378093999805daf98bd9fbaa03156ed")
