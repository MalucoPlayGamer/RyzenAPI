-- Lua provided by RyzenAPI
-- Game: 2180800

-- MAIN APPLICATION
addappid(2180800)
addappid(2180804)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180802,0,"7070b67db561d96c6bb787db380b12bc3ff50bbd12ca681cab3c490d5e46acee")
