-- Lua provided by RyzenAPI
-- Game: addappid(3056960)

-- MAIN APPLICATION
addappid(3056960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056961, 1, "2d5cafdb6d0a958b2bfce8ba57b5431b3bf0b318bd078ebd60983bb0e3e64f28")
