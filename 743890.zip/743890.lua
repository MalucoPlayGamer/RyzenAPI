-- Lua provided by RyzenAPI
-- Game: AppID 743890

-- MAIN APPLICATION
addappid(743890)

-- MAIN APP DEPOTS / PACKAGES
addappid(743891, 1, "aa7be958260862cf85f39eddd672463ecb9c606ec8bd342b786363ecd049651f")

