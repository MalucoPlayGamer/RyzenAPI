-- Lua provided by RyzenAPI
-- Game: Mega Man X Legacy Collection

-- MAIN APPLICATION
addappid(743890)
addappid(861800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743891, 1, "aa7be958260862cf85f39eddd672463ecb9c606ec8bd342b786363ecd049651f")

