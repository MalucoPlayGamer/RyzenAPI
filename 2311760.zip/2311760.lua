-- Lua provided by RyzenAPI
-- Game: addappid(2311760)

-- MAIN APPLICATION
addappid(2311760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311761, 1, "0bb2c925fd7b775417934fa71aef2fdf6a4d2e75b538cef7519e5c495595a96c")
