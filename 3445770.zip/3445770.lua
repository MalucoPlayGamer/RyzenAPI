-- Lua provided by RyzenAPI
-- Game: Angry Video Game Nerd 8-bit Demo

-- MAIN APPLICATION
addappid(3445770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445771, 1, "c43b055cd65bdfbaf6404fa0e9709d9f6f6c6ad8794cc124ee32a4d47cc38c20")

