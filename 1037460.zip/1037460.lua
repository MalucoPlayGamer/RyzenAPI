-- Lua provided by RyzenAPI 
-- Game: DEEP 8
addappid(1037460)
addappid(1037461, 1, "2fc90804f272c4e00666eed718a2b0379ae35f08981661dbba06ce25ee9d2cc3")
