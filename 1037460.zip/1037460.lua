-- Lua provided by RyzenAPI
-- Game: 1037460

-- MAIN APPLICATION
addappid(1037460)
-- Game: addappid(1037460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037461, 1, "2fc90804f272c4e00666eed718a2b0379ae35f08981661dbba06ce25ee9d2cc3")
