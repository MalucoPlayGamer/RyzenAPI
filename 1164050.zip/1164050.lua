-- Lua provided by RyzenAPI 
-- Game: When The Past Was Around
addappid(1164050)
addappid(1164051, 1, "8cb5572e4abefe4e7cbf21d36e023240cc04a8bea7f96e26c2909074261463ab")
addappid(1164052, 1, "c79cbf8a120e4826e46fc5115a801cdf3e677b1899cfa35875472a7f0a14006d")
addappid(1413240, 0, "d6826d3672ef5e4cbcb8e04434597f2d8f85baa08022c52596bbf7937146b037")
