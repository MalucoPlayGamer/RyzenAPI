-- Lua provided by RyzenAPI
-- Game: Space Empires V

-- MAIN APPLICATION
addappid(1690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691, 1, "903130c9981909cd6656d6c96cbff706ae2b474563a62096016aa56f93e2402b")
