-- Lua provided by RyzenAPI
-- Game: 1853880

-- MAIN APPLICATION
addappid(1853880)
-- Game: addappid(1853880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853881, 1, "5c53394cc9a71be03bdea445ea4d6d24c017b915534c0eec6711439dd40fd18d")
