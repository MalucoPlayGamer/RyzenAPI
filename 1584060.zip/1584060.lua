-- Lua provided by RyzenAPI
-- Game: 1584060

-- MAIN APPLICATION
addappid(1584060)
-- Game: addappid(1584060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584061, 1, "5d29a62bee3400eabbec66ec605bc2c7e4f63ebf6eb649ce382867695e8f6a64")
