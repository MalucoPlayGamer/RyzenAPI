-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(227322)
addappid(228240)
-- Game: addappid(228240)

-- MAIN APP DEPOTS / PACKAGES
addappid(227321,0,"9837ab5ce5d429aca8a7e0fd9971edaecf1827e626eb4997fe31ed3ccdaf5dc4")
