-- Lua provided by RyzenAPI
-- Game: addappid(578690)

-- MAIN APPLICATION
addappid(578690)

-- MAIN APP DEPOTS / PACKAGES
addappid(578691, 1, "7f4c7cb78195b0f90facc597f2eb185e500987557e837eb984da6168ab605764")
