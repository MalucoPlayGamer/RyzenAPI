-- Lua provided by RyzenAPI
-- Game: addappid(640850)

-- MAIN APPLICATION
addappid(640850)
addappid(640851)

-- MAIN APP DEPOTS / PACKAGES
addappid(640852,0,"49a4bfeb8154d4621f81fe3954d27e51b3d41efde8e0043bf1adffbb402fb7a1")
