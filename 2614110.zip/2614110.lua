-- Lua provided by RyzenAPI 
-- Game: AppID 2614110
addappid(2614110)
addappid(2614111, 1, "57d74d80600550ae2797aabe0ee067739732582514ab5f20ed12228699e34f24")
