-- Lua provided by RyzenAPI
-- Game: 2023240

-- MAIN APPLICATION
addappid(2023240)
-- Game: addappid(2023240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023241, 1, "d29f933b244a1b2f20b984dc0832d89e7cb93868c346f249ce569234e48f4fae")
