-- 2824880's Lua and Manifest Created by Hubcap Manifest
-- SHRIMP GAME: OVERKRILL
-- Created: August 27, 2026 at 13:29:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2824880) -- SHRIMP GAME: OVERKRILL
-- MAIN APP DEPOTS
addappid(2824881, 1, "a4d4aa4670246799396621627c61187b4c33d94f5eba4fe339430dfb13d2d87c") -- Depot 2824881
setManifestid(2824881, "7029922082394709361", 1172076608)