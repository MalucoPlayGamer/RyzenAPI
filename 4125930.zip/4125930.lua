-- Lua provided by RyzenAPI
-- Game: Punishing: Gray Raven

-- MAIN APPLICATION
addappid(4125930)
