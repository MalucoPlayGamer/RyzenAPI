-- Lua provided by RyzenAPI
-- Game: Brainrot Royale

-- MAIN APPLICATION
addappid(878000)

-- MAIN APP DEPOTS / PACKAGES
addappid(878001,0,"5b2f402ab690f24504818535aa467a140e6918e2b059f91740d5dbe2e2245f45")

