-- Lua provided by RyzenAPI
-- Game: Game: RECORD_DrowsyVortex

-- MAIN APPLICATION
addappid(3169000)
-- Game: addappid(3169000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169001, 1, "6253a59a1bd332772971778a747dd69def88e66d713c5f6e219e76725d5c6f0c")
