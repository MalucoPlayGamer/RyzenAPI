-- Lua provided by RyzenAPI
-- Game: Market Empire Simulator

-- MAIN APPLICATION
addappid(3163840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163843,0,"1b9093dbd681ad60160e331f0ec19559bcc3406df4d914d2d3fdd7bd6d15fa91")
