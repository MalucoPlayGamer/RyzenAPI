-- Lua provided by RyzenAPI
-- Game: Return to Kurgansk

-- MAIN APPLICATION
addappid(1785930)
-- Game: addappid(1785930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785931, 1, "2f98ee897360d85dc68fef8d0ac10aef2e03a311cd1dd3af3710e0d0c53008fa")
