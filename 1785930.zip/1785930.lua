-- Lua provided by SkyAPI 
-- Game: Return to Kurgansk
addappid(1785930)
addappid(1785931, 1, "2f98ee897360d85dc68fef8d0ac10aef2e03a311cd1dd3af3710e0d0c53008fa")
