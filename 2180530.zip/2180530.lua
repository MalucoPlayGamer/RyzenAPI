-- Lua provided by RyzenAPI
-- Game: 2180530

-- MAIN APPLICATION
addappid(2180530)
-- Game: addappid(2180530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180531, 1, "30cd92402cacf0a95a8249919505ce44a776890365773f88ceae6c1adbe9d6de")
