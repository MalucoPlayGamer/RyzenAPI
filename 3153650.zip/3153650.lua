-- Lua provided by RyzenAPI
-- Game: Game: Seedsow Lullaby Demo

-- MAIN APPLICATION
addappid(3153650)
-- Game: addappid(3153650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3153651, 1, "f1f811430f6a2929ee5c128f709d82f01c8d684c0725d9b109a0f2246eeebe09")
