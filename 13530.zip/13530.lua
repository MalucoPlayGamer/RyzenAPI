-- Lua provided by RyzenAPI
-- Game: AppID 13530

-- MAIN APPLICATION
addappid(13530)
-- Game: addappid(13530)

-- MAIN APP DEPOTS / PACKAGES
addappid(13531, 1, "b1cd415ec5ed2a5e3db610e95efcf4e56a87c35a68c849d426ba5a4d983548d0")
addappid(13532, 1, "fdc54ccb51553cc6fad5190cec9065d4886f6811aceac12e1dcff030d401a99f")
addappid(13533, 1, "e44d840e9863ebac4258d1e10b809343dfc8ea7b3308af224607535113603902")
addappid(13534, 1, "2450493833e46bc4e51f19874adc888c8d2ce06f3bdab671cf66cdf9d31b7e84")
addappid(13535, 1, "a3f2c783a615efb6a83797d359a0a3d62dd26f609ab9bd90b22fa554d16b89da")
addappid(13536, 1, "88303f7bd09d7ccbe9d219183ecb9d0302758f5073ff5c8e9bc1d6c21b97b1a6")
