-- Lua provided by RyzenAPI
-- Game: addappid(875550)

-- MAIN APPLICATION
addappid(875550)

-- MAIN APP DEPOTS / PACKAGES
addappid(875551, 1, "fd732cd88ae91e5436e2d94c4c81eced6e51f4c06f23ed83af34528dd8f98c00")
