-- Lua provided by RyzenAPI
-- Game: 风与鸟 - 剧情扩展包

-- MAIN APPLICATION
addappid(2774600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774600,0,"c7d2aad391e773a76cffe001fb7585803567c7a981424648369d0ff3da06704c")

