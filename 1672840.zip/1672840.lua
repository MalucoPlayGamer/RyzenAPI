-- Lua provided by RyzenAPI
-- Game: 1672840

-- MAIN APPLICATION
addappid(1672840)
-- Game: addappid(1672840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672841, 1, "68beb2346fbde5290d714de3cdab0ffdb1220ed81839402cef00801788d6c220")
