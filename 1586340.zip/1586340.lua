-- Lua provided by RyzenAPI
-- Game: A New Leaf: Memories

-- MAIN APPLICATION
addappid(1586340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586341, 1, "363c6afb9abd8a11846e639cc5014523ff1748ed9ba5ae601e13f78c917445dc")
