-- Lua provided by RyzenAPI
-- Game: Foot Serve

-- MAIN APPLICATION
addappid(2753570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753571, 1, "a0eecf1035f91f778d931a7b03d84b9228e91b5e6b4748cf0fdfcca97f7ee0f8")
