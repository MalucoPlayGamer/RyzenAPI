-- Lua provided by RyzenAPI
-- Game: Game: The Secret of Darkwoods

-- MAIN APPLICATION
addappid(2271590)
-- Game: addappid(2271590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271591, 1, "fc62ae209cc8a79cdb950a2e366405f4e2001e57d777911fb5a6523d956b2179")
addappid(2271592, 1, "a37484df7fd4982effe8241695d20f25376c8f6efc8295a576894a6d78b6deca")
addappid(2271593, 1, "bfd97b7eb15012cd73e4aa4a943095178003622714c7c9aa86f13c4054279087")
