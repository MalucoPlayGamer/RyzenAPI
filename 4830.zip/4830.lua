-- Lua provided by RyzenAPI
-- Game: S.T.A.L.K.E.R.: Shadow of Chernobyl

-- MAIN APPLICATION
addappid(4830)

-- MAIN APP DEPOTS / PACKAGES
addappid(4831, 1, "c94b1bf8f5e098722e15191d43d4ae4dacdd803b84add0641ffdb021d8c065a3")
addappid(4832, 1, "6dd3db6cdbe089dfa8500554b66ba438c09e170ef060f13c89fa313a558e75a3")
addappid(4833, 1, "f98fa998f1a2b2ca69ad1d6184ca6fcd3d83d8ddfabc15b937330cbedfdf840a")
addappid(4834, 1, "22d6a658d382e015653439533aac9549a0daad73f2797383f9a8925e412ddbc0")

