-- Lua provided by RyzenAPI
-- Game: Christmas Mosaic Puzzle

-- MAIN APPLICATION
addappid(1495090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495091, 1, "f45c3b7def14acc9ecf97bcf05651bd339e933f1b6b5bb6e8ef7ff5ca449b117")
addappid(1495092, 1, "1007c443280431a97c66d99cf58ade53dad7c876452324a11b6aecdc1753e84b")
addappid(1495093, 1, "86bafc7af54ef29374b6592577a08ba863183b44776b409d0e550c0cb7cab571")
addappid(1495094, 1, "2ea9d353569cfaf6eb486f67b4241cbb271a3635643b5495fb159ab011dabb8c")

