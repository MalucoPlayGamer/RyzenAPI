-- Lua provided by RyzenAPI 
-- Game: Sorry. (Entschuldigung) ~ A Psychological Horror Visual Novel
addappid(570350)
addappid(570351, 1, "a60d18702e745d0d58027b2e0f2af18cca7405f1bafef29a1e9ec6f2ce76792b")
