-- Lua provided by RyzenAPI
-- Game: Game: AppID 776670

-- MAIN APPLICATION
addappid(776670)
-- Game: addappid(776670)

-- MAIN APP DEPOTS / PACKAGES
addappid(776671, 1, "05a0eb9f42bddd1dbf56f63b3f60220805a766968f59012aa9b9dae9a2fe8f66")
addappid(787630, 0, "01c24f4e3dda46519c5f15ffd030f4d44a202f851d892f5d138b9a675f0b342f")
