-- Lua provided by RyzenAPI
-- Game: Light in the dark

-- MAIN APPLICATION
addappid(669600)

-- MAIN APP DEPOTS / PACKAGES
addappid(669601,0,"585ebfe0fd741135e7d81f2a1fce5dfb9f8dbd24dad62f401973ae8c9b58414a")

