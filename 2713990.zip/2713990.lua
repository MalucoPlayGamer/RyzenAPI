-- Lua provided by RyzenAPI
-- Game: addappid(2713990)

-- MAIN APPLICATION
addappid(2713990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713991, 1, "dd1503f6d676f18f76c5014ec707acad123fa094e312f3c88d403dfbe3ec0b77")
