-- Lua provided by RyzenAPI
-- Game: Sanctum 2: Original Soundtrack

-- MAIN APPLICATION
addappid(335370)

-- MAIN APP DEPOTS / PACKAGES
addappid(335370,0,"66abba66a1983b5ed7f8fe7eeb4f90a759bca756f04ec9341fae369f4f067f6e")
