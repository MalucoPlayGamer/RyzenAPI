-- Lua provided by RyzenAPI
-- Game: Game: Arkanoid - Eternal Battle : Battle Royale F2P Edition

-- MAIN APPLICATION
addappid(2535820)
-- Game: addappid(2535820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535821, 1, "2e4e7675f25939228806fa209df34c7c73d5573eedb8f2c698ba2d0f9c9686e1")
