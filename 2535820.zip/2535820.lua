-- Lua provided by SkyAPI 
-- Game: Arkanoid - Eternal Battle : Battle Royale F2P Edition
addappid(2535820)
addappid(2535821, 1, "2e4e7675f25939228806fa209df34c7c73d5573eedb8f2c698ba2d0f9c9686e1")
