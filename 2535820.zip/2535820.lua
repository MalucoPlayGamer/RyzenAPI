-- Lua provided by RyzenAPI
-- Game: Arkanoid - Eternal Battle : Battle Royale F2P Edition

-- MAIN APPLICATION
addappid(2535820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2535821, 1, "2e4e7675f25939228806fa209df34c7c73d5573eedb8f2c698ba2d0f9c9686e1")

