-- Lua provided by RyzenAPI
-- Game: Game: Trails

-- MAIN APPLICATION
addappid(3605120)
-- Game: addappid(3605120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3605121, 1, "0d0838710fdf1b4eaf0f38202ad31bc2f7aa60391cb7c37e531e4004381d589c")
