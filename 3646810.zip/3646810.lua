-- Lua provided by RyzenAPI
-- Game: Game: AppID 3646810

-- MAIN APPLICATION
addappid(3646810)
-- Game: addappid(3646810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3646811, 1, "3099d8680b09f32189111de429ee29fe9142a448df2ef5f76b43c8e3a768e27f")
