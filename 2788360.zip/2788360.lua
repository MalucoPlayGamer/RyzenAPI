-- Lua provided by SkyAPI 
-- Game: カルトに厳しいギャル-CULT VS GAL-
addappid(2788360)
addappid(2788361, 1, "185e779a1d22672aded3c068b418314a423999600341d87ce276ecd9c91a9fc9")
