-- Lua provided by RyzenAPI
-- Game: Unholy Soundtrack

-- MAIN APPLICATION
addappid(2515720)
-- Game: addappid(2515720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515721, 1, "2f4b975652908306c96aa9c5b68e091ad22a977552b912bc6c92f4bb37db020e")
