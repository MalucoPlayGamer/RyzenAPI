-- Lua provided by RyzenAPI
-- Game: Tank Squad Demo

-- MAIN APPLICATION
addappid(2622470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622471, 1, "4b91ee6f45b3ad44ed7cc7d209f310955c1e905c0eae323dbc4b5a9a3daa8dd7")
