-- Lua provided by RyzenAPI
-- Game: Koltera

-- MAIN APPLICATION
addappid(2233750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233751, 1, "8a0a6aefe8076025e122fb91c92ee20472c14a4195f6734c6dec95c3ce91fe79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
