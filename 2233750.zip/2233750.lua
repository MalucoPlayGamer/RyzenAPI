-- Lua provided by RyzenAPI 
-- Game: Koltera
addappid(2233750)
addappid(2233751, 1, "8a0a6aefe8076025e122fb91c92ee20472c14a4195f6734c6dec95c3ce91fe79")
