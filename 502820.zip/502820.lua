-- Lua provided by RyzenAPI
-- Game: Batman™: Arkham VR

-- MAIN APPLICATION
addappid(502820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(502821, 1, "44875eeeedbd724d166300e14b3986b6341b9fcad84c2bb04977513d83255eb2")

