-- Lua provided by RyzenAPI
-- Game: Batman™: Arkham VR

-- MAIN APPLICATION
addappid(502820)

-- MAIN APP DEPOTS / PACKAGES
addappid(502821, 1, "44875eeeedbd724d166300e14b3986b6341b9fcad84c2bb04977513d83255eb2")

