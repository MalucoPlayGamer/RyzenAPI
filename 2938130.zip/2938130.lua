-- Lua provided by RyzenAPI
-- Game: addappid(2938130)

-- MAIN APPLICATION
addappid(2938130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938131, 1, "b319241cd057c91709a0d4d594db27ed5718e8b19b5ba5a476f9c7fb35e26d1c")
