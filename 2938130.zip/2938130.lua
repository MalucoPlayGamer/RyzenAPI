-- Lua provided by SkyAPI 
-- Game: Netherworld Covenant Demo
addappid(2938130)
addappid(2938131, 1, "b319241cd057c91709a0d4d594db27ed5718e8b19b5ba5a476f9c7fb35e26d1c")
