-- Lua provided by RyzenAPI
-- Game: addappid(1504630)

-- MAIN APPLICATION
addappid(1504630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504631, 1, "bf422c1a9f91fabcb790d38ad72ccabebd48e829443635a8dee3c9cb9b7248d9")
