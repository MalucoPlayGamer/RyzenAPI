-- Lua provided by RyzenAPI
-- Game: Supreme League of Patriots - Episode 2: Patriot Frames

-- MAIN APPLICATION
addappid(336710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(336711, 1, "84831e949315409c30411bf34e21c507c5bc1a52b4ab5db6993f8fde9d0cfbff")
addappid(336712, 1, "a529d1138384ac9fc8e0c22e4e58b8c8ed8c5816a0ce93e14a78cfb3c194ef2d")
addappid(336713, 1, "33176a3566b854b07781615792d3ebf9af90428c0dd52973d37e153dcb9857b6")
addappid(336714, 1, "e53e355f07ba87b73214ae5beb6cdcd99e1bbf137356c90358212ce4ca31dd75")

