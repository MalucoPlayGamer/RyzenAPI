-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy Side-View Animated Battlers

-- MAIN APPLICATION
addappid(1523000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523000,0,"228220c511e43f013c6c520b09a5ceef55d5a55254333e6925757c669c2dd3c7")

