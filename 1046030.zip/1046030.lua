-- Lua provided by RyzenAPI
-- Game: 1046030

-- MAIN APPLICATION
addappid(1046030)
-- Game: addappid(1046030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046031, 1, "33c4649d448f898a1faa5d0e7a66071e5346618ddb5a4e1b92f58ad6ed6dcd2a")
addappid(1046032, 1, "d433fcce48745cb3039159d83eab31ff390f1c10eb4282563ca6ea6f7361514b")
addappid(1046033, 1, "0efc1f99591ae0d0caa7e51fb74e78a63cfb5e362dfadaad35b20ca34d38007b")
addappid(1046034, 1, "790a354ca8d16ce8e7df524e7e4ed74647a03bc7ebe5d537732a2a7ad67a3c35")
addappid(1046035, 1, "a5b56c8af584d3060abf18de9ffde1822acc411f6e542e1de83cf3904bbe9750")
