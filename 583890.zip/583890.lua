-- Lua provided by RyzenAPI 
-- Game: Balthazar's Dream
addappid(583890)
addappid(583891, 1, "1ef492f0e647d9e4a372eb1fc2e6ff5107f8fe0f1e1fd7ccdec88ac59eb3f5c2")
addappid(647920)
