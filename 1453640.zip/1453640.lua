-- Lua provided by RyzenAPI
-- Game: Valthirian Arc: Hero School Story 2

-- MAIN APPLICATION
addappid(1453640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453641, 1, "8a27632c87e6711791ad747cd0e25a638dc2022e071b576186db533353384179")
