-- Lua provided by RyzenAPI 
-- Game: AppID 1453640
addappid(1453640)
addappid(1453641, 1, "8a27632c87e6711791ad747cd0e25a638dc2022e071b576186db533353384179")
