-- Lua provided by RyzenAPI
-- Game: JK Girl Samurai - AOI no mon

-- MAIN APPLICATION
addappid(3642110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642112,0,"664468061b178da97e9e46183dfaf43537bf2730f00302838ed74015fc1a2b62")
