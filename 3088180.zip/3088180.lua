-- Lua provided by RyzenAPI
-- Game: Waffle Cone Willie

-- MAIN APPLICATION
addappid(3088180)
-- Game: addappid(3088180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088181, 1, "99015bafd561801327eb801d2a9c9fbf112cc3b563a8f55c23201130d13f7710")
