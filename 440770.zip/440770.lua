-- Lua provided by RyzenAPI
-- Game: Drawn Story

-- MAIN APPLICATION
addappid(440770)

-- MAIN APP DEPOTS / PACKAGES
addappid(440771, 1, "691cac3164e4a50292822dfa7d493e733e2f80f2b835463f461888381e864b48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
