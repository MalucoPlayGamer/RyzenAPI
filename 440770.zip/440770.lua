-- Lua provided by RyzenAPI
-- Game: Game: Drawn Story

-- MAIN APPLICATION
addappid(440770)
-- Game: addappid(440770)

-- MAIN APP DEPOTS / PACKAGES
addappid(440771, 1, "691cac3164e4a50292822dfa7d493e733e2f80f2b835463f461888381e864b48")
