-- Lua provided by RyzenAPI
-- Game: addappid(1066940)

-- MAIN APPLICATION
addappid(1066940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066941, 1, "676f8ab66f5a5add4d72a86f6ef658b05fa9c2274168dc4e8e90950f8917f9cd")
