-- Lua provided by RyzenAPI
-- Game: Game: Psycho Train

-- MAIN APPLICATION
addappid(1096950)
-- Game: addappid(1096950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096951, 1, "8c1e2a7a341fdc1dff11e980d97f5ff9e3bd70421cb827932569a3d1de325290")
addappid(1096958, 1, "3a8d3e0694fcc07516a11b831d95e1e112e8833e7b809d05a27be69770bbf269")
