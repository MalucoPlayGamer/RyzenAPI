-- Lua provided by RyzenAPI
-- Game: addappid(2785150)

-- MAIN APPLICATION
addappid(2785150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785151, 1, "dca6eca059cc743781c39184c24af0e38ad8fbed03b2cc0b872e2fecd266b824")
