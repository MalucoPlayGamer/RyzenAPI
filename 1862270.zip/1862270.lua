-- Lua provided by RyzenAPI
-- Game: addappid(1862270)

-- MAIN APPLICATION
addappid(1862270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862271, 1, "0c25dfdcd01b4e9ecbaaf703031f130be5f07b90db9210155a98e23b4abbe33b")
