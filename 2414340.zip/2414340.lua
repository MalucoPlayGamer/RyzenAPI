-- Lua provided by RyzenAPI
-- Game: Game: Star General

-- MAIN APPLICATION
addappid(2414340)
-- Game: addappid(2414340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414341, 1, "68792cbe655ac0e830d6ae1b17695455b30200549c9f080f0ca45e8fb47b8799")
addappid(2414342, 1, "eb5d2d7473036ab5a5445cecad4bea48030970d13a0b2813d7768c04c6f55a7d")
addappid(2414344, 1, "8e59691c18524bcfa9fdf340da71f2493917b13b370339c42a82cce86093cb2e")
