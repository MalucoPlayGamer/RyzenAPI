-- Lua provided by RyzenAPI 
-- Game: AppID 1440780
addappid(1440780)
addappid(1440781, 1, "94fe438f11bd382b39fee5ff300850f53f093675b5077fdfaa947bd02c484d2f")
