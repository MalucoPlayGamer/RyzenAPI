-- Lua provided by RyzenAPI
-- Game: Outpost L5

-- MAIN APPLICATION
addappid(656330)

-- MAIN APP DEPOTS / PACKAGES
addappid(656331, 1, "08fb5c6f4ad44b8a673fd91f250b59df8ce23b8d6732e860bd221fae2bef7edb")
