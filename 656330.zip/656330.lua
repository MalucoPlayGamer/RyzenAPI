-- Lua provided by RyzenAPI 
-- Game: AppID 656330
addappid(656330)
addappid(656331, 1, "08fb5c6f4ad44b8a673fd91f250b59df8ce23b8d6732e860bd221fae2bef7edb")
