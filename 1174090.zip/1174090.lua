-- Lua provided by RyzenAPI
-- Game: Game: AppID 1174090

-- MAIN APPLICATION
addappid(1174090)
-- Game: addappid(1174090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174091, 1, "6a66e6397aec3397b819a721ee26fbe232c377d4b5f7d15ef7d49ed77da24749")
