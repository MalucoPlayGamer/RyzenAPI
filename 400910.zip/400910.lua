-- Lua provided by RyzenAPI
-- Game: Rabi-Ribi

-- MAIN APPLICATION
addappid(400910)

-- MAIN APP DEPOTS / PACKAGES
addappid(400911, 1, "d5442369b26a2c4c6b13984a064bd8b1ca89336b804bebe92189fe72e66cea68")
addappid(431621, 0, "23a49f9660b01a4f9500e9c2f1e2e35a148e5a10642c572315aca83260289b3c")
addappid(532021, 0, "fa17363ffa4709c98a5cdc650321c774c1527a7186691626a239e3533d257f46")
addappid(547660, 0, "a83ba95625d716927463dac7a4c55db8da9fa0958a0ecaee0291ff965baff991")
addappid(1015050, 0, "7ff3a2bd304b34e74ef6136255693e20bb3b77088ce5be7273a8082bcb4775bb")
addappid(1528990, 0, "5bcac1286e75ae97bc2b0ccd67bf33f7a186c7df32ca893ec14ab52ba611e08f")
addappid(2265110, 0, "cb5c08e27cf90cd2c78ae1d27f2bc6208d8cb073ddc06b405c2506de859c2b90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
