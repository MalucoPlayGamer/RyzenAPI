-- Lua provided by RyzenAPI
-- Game: addappid(1582650)

-- MAIN APPLICATION
addappid(1582650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582651, 1, "419f9adaf16540ae360fc0bad35397458eefb5fa98ad7051de87780ca12f2283")
