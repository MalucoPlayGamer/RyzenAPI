-- Lua provided by RyzenAPI 
-- Game: Caravan SandWitch
addappid(1582650)
addappid(1582651, 1, "419f9adaf16540ae360fc0bad35397458eefb5fa98ad7051de87780ca12f2283")
