-- Lua provided by RyzenAPI
-- Game: Caravan SandWitch

-- MAIN APPLICATION
addappid(1582650)
addappid(3142110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1582651, 1, "419f9adaf16540ae360fc0bad35397458eefb5fa98ad7051de87780ca12f2283")

