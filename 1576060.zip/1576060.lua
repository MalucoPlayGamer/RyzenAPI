-- Lua provided by RyzenAPI
-- Game: Suspects: Mystery Mansion

-- MAIN APPLICATION
addappid(1576060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576061, 1, "eec1dd372548067e82ecc95e4f8758f98df9413a900a76a0b7f221a937e6efd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
