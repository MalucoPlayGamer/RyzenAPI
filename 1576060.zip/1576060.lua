-- Lua provided by RyzenAPI
-- Game: 1576060

-- MAIN APPLICATION
addappid(1576060)
-- Game: addappid(1576060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576061, 1, "eec1dd372548067e82ecc95e4f8758f98df9413a900a76a0b7f221a937e6efd3")
