-- Lua provided by RyzenAPI
-- Game: AppID 333650

-- MAIN APPLICATION
addappid(333650)

-- MAIN APP DEPOTS / PACKAGES
addappid(333651, 1, "4ac782134c985cfc23de3c87034ff05e5b35de04d02da9bc84e4d3db5a2d3ea0")
