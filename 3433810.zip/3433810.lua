-- Lua provided by RyzenAPI
-- Game: 咸鱼殿下 / My journey

-- MAIN APPLICATION
addappid(3433810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3433811, 1, "97951ad4076d5b305779257c1e4521d5d0a4d099ad35ac5723e57c9fa05c971a")

