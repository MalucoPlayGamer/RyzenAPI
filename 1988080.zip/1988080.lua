-- Lua provided by RyzenAPI
-- Game: addappid(1988080)

-- MAIN APPLICATION
addappid(1988080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988081, 1, "2f2d89c33d219070189ed82828687c2c29119ce4ddfec37ab6db6a3fde7f6b3f")
