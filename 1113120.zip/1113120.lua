-- Lua provided by RyzenAPI 
-- Game: IXION
addappid(1113120)
addappid(1113121, 1, "fa3f3b4a6b929572b908f7a0558a4055471173f4ca30ac3a068c4e0a89096414")
addappid(2115950, 0, "9f890ff771b770c3b90cfff818b2597ae05d9a74f59b518bd95ec854ad2a2ae5")
