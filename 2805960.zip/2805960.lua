-- Lua provided by RyzenAPI
-- Game: BUMPER BALLS

-- MAIN APPLICATION
addappid(2805960)
-- Game: addappid(2805960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805961, 1, "a5c4a34e6db5ee94ce07321e246db6639e7087f4d0fea844a56a7eee3e96bdcc")
