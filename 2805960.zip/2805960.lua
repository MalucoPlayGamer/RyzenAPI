-- Lua provided by RyzenAPI
-- Game: BUMPER BALLS

-- MAIN APPLICATION
addappid(2805960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805961, 1, "a5c4a34e6db5ee94ce07321e246db6639e7087f4d0fea844a56a7eee3e96bdcc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
