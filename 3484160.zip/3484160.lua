-- Lua provided by RyzenAPI
-- Game: Not Monday Cafe Demo

-- MAIN APPLICATION
addappid(3484160)
-- Game: addappid(3484160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484161, 1, "caa55ba840b8137501df74e84cbe5e411e142d595e514c07fca040838a62e4d5")
