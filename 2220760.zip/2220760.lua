-- Lua provided by RyzenAPI
-- Game: 2220760

-- MAIN APPLICATION
addappid(2220760)
-- Game: addappid(2220760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220761, 1, "0a104cc53310a8f5edaebd2a8eac1d2cba464732eba5941ec45d71d728dc740b")
