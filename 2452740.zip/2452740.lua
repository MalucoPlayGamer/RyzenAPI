-- Lua provided by RyzenAPI
-- Game: To Be A King - Volume 1 Demo

-- MAIN APPLICATION
addappid(2452740)
-- Game: addappid(2452740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452741, 1, "426c7a353513f47e2f8e535cabe754383540ed05b05d601d4faefcb4c680307b")
