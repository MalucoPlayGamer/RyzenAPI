-- Lua provided by RyzenAPI
-- Game: addappid(299070)

-- MAIN APPLICATION
addappid(299070)

-- MAIN APP DEPOTS / PACKAGES
addappid(299071, 1, "3234c7ff8976f349dc95824716846df6e64ea6ca476918cbdd56e6ee92847dc2")
