-- Lua provided by RyzenAPI 
-- Game: AppID 263400
addappid(263400)
addappid(263401, 1, "279cc645aca9a948e4c0a8fd036b78feeb3d509df26e40c5d663bd8bc52e6596")
