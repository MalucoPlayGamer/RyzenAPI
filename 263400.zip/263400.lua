-- Lua provided by RyzenAPI
-- Game: War of the Human Tanks

-- MAIN APPLICATION
addappid(263400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(263401, 1, "279cc645aca9a948e4c0a8fd036b78feeb3d509df26e40c5d663bd8bc52e6596")

