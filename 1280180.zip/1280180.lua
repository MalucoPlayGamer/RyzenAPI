-- Lua provided by RyzenAPI
-- Game: AppID 1280180

-- MAIN APPLICATION
addappid(1280180)
-- Game: addappid(1280180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280181, 1, "7e5630e62a9eb353b91f3d1b22da07d0e79ed395400300ca986eac61a05cd61b")
