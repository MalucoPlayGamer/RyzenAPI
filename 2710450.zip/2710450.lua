-- Lua provided by RyzenAPI
-- Game: addappid(2710450)

-- MAIN APPLICATION
addappid(2710450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710451, 1, "9a1b152ab45142e6304bb714acb098dbb8a941cd48908fa8324c0c085eed344f")
