-- Lua provided by RyzenAPI
-- Game: Game: Fear the Spotlight Demo

-- MAIN APPLICATION
addappid(1960390)
-- Game: addappid(1960390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960391, 1, "8f2311556cdd36438885139234875b2cc6846f02a3d740f0d9081d4a79fc9c48")
