-- Lua provided by RyzenAPI
-- Game: My Party Is Grinding

-- MAIN APPLICATION
addappid(4952980) -- My Party Is Grinding
addappid(5089790) -- My Party Is Grinding - Supporter Pack
addappid(5089800) -- My Party Is Grinding - Automation Pack
addappid(5089810) -- My Party Is Grinding - Stash Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4952981, 1, "c6312fc3a4f655c37a2d4d520a3f0341d23784aa32dbdc9437f855be76f24f2d") -- Depot 4952981
addappid(4952982, 1, "30a6172c942536d56d9747a3422d5c36e330290a8036484ae54f9cc8cf56c40b") -- Depot 4952982

