-- 4952980's Lua and Manifest Created by Hubcap Manifest
-- My Party Is Grinding
-- Created: August 27, 2026 at 10:02:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(4952980) -- My Party Is Grinding
-- MAIN APP DEPOTS
addappid(4952981, 1, "c6312fc3a4f655c37a2d4d520a3f0341d23784aa32dbdc9437f855be76f24f2d") -- Depot 4952981
setManifestid(4952981, "6492713734675960091", 339447819)
addappid(4952982, 1, "30a6172c942536d56d9747a3422d5c36e330290a8036484ae54f9cc8cf56c40b") -- Depot 4952982
setManifestid(4952982, "1926220690876244800", 355491355)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5089790) -- My Party Is Grinding - Supporter Pack
addappid(5089800) -- My Party Is Grinding - Automation Pack
addappid(5089810) -- My Party Is Grinding - Stash Pack