-- Lua provided by RyzenAPI
-- Game: KOLOBOK

-- MAIN APPLICATION
addappid(757170)
-- Game: addappid(757170)

-- MAIN APP DEPOTS / PACKAGES
addappid(757171, 1, "839d650282af84f45b547098ae5e9ab9337b703fd76b88b54e6b043a1d216b14")
