-- Lua provided by RyzenAPI
-- Game: Red Crucible Tanks

-- MAIN APPLICATION
addappid(2279580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279581, 1, "2cf89d3abca1998d595aa7c21e0a2c8c2fb3dfa9e71dc0d3e736c3401e212609")
addappid(2279582, 1, "4a8850e32f10e59083b00869fe1ccf7e94aca07d060c1d7d56ed1bd0dd7c16fb")
addappid(2279583, 1, "30414b63fb366255b2415a6404b454286ddf5267e0fd0dca2668311e55c43c89")

