-- Lua provided by RyzenAPI
-- Game: 2203170

-- MAIN APPLICATION
addappid(2203170)
-- Game: addappid(2203170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203171, 1, "1253a8a1c780924dbd2895323050cef9340f8613a80b0ac40de1dfa0c04f9441")
