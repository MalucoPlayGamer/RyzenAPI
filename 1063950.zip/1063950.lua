-- Lua provided by RyzenAPI
-- Game: Game: SUPER RECOILFIGHT

-- MAIN APPLICATION
addappid(1063950)
addappid(1066340)
-- Game: addappid(1063950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063951, 1, "25e3264cea2e6a75d33ec36dacd1c88b276493d7f44be984453e90bf8eff5f75")
