-- Lua provided by RyzenAPI
-- Game: addappid(3439530)

-- MAIN APPLICATION
addappid(3439530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439531, 1, "f73be1a6eb07b6c1502ff857c768168760d5d9dd45022c87ed03ba06a661d143")
