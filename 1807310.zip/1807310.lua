-- Lua provided by RyzenAPI 
-- Game: Wild Pussies
addappid(1807310)
addappid(1807311, 1, "bea67f13102e82f75fcc3fd0ac026fda2c241e9df98d1cb9c8983d15b42e236a")
