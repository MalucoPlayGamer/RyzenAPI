-- Lua provided by SkyAPI 
-- Game: SNUG
addappid(2988410)
addappid(2988411, 1, "a8b8b88825575721bf7cbc6384e15d6793288ac9c948a63632301834e4a890c2")
