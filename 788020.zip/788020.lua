-- Lua provided by RyzenAPI
-- Game: Critical Gravity

-- MAIN APPLICATION
addappid(788020)

-- MAIN APP DEPOTS / PACKAGES
addappid(788021,0,"f4ddff122007cb6fd5202029e65a0fae59c1fcaff314431ee80f4b8790dad86f")

