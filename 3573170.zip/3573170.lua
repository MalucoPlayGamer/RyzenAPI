-- Lua provided by RyzenAPI
-- Game: Survive the Fall - Original Soundtrack

-- MAIN APPLICATION
addappid(3573170)
-- Game: addappid(3573170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573171, 1, "4475a05f6a729fd9bcc4610effc32a5f09b21747cd3b52e1cf8171c838118653")
addappid(3573172, 1, "c34ba3cb78196358d69451d87865bdb78212751de6d97853d829140aa7cb197e")
