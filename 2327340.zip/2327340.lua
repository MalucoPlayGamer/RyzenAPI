-- Lua provided by RyzenAPI
-- Game: 2327340

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2327340)
addappid(2327341)
-- Game: addappid(2327340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327342,0,"19ca1317d805dd5704c85ccd2e4da6e64ce34bf6da413d45b05c6caff21f24a4")
