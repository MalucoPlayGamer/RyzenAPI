-- Lua provided by RyzenAPI
-- Game: 946000

-- MAIN APPLICATION
addappid(946000)
-- Game: addappid(946000)

-- MAIN APP DEPOTS / PACKAGES
addappid(946001, 1, "6299350caaf1a3043d301d9b056481f26378148700efd4d39a1053fb2b6cc038")
