-- Lua provided by RyzenAPI
-- Game: Epic Adventures: Cursed Onboard

-- MAIN APPLICATION
addappid(1056080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056081, 1, "22fe5e1a07fe6776836e0c2497928294af6e0e2dfcd924334607c26d2da55604")
addappid(1056082, 1, "cb586a256478524392376145b8dd137bff4d81d1c5bfa4ddf5e6c3d82020502e")
addappid(1056083, 1, "f8adb15553f4cf35dfd92ecb10b9cf4d08a33d2f511e6ec535c385be89b30ba9")
