-- Lua provided by RyzenAPI
-- Game: Bunny Bounce

-- MAIN APPLICATION
addappid(446610)

-- MAIN APP DEPOTS / PACKAGES
addappid(446611, 1, "ef2410c5c6951b876105144d5662f4b00bb2c475bf133cb0a75000d763309a7f")

