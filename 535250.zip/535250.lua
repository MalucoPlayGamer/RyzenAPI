-- Lua provided by RyzenAPI
-- Game: Game: AppID 535250

-- MAIN APPLICATION
addappid(535250)
-- Game: addappid(535250)

-- MAIN APP DEPOTS / PACKAGES
addappid(535251, 1, "4a63455bc3f1e2dd117efd34c656d93f658a6309df6a73d3fa9452c0c65d8792")
