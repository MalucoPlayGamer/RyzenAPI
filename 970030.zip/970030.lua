-- Lua provided by SkyAPI 
-- Game: Gems of Magic: Lost Family
addappid(970030)
addappid(970031, 1, "063dcffa4846d34d28ecd233aa795ec7bae4d0bde9ade6d18a4f64e0f340e3ca")
