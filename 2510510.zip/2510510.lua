-- Lua provided by RyzenAPI
-- Game: Commander: Zombie Wars

-- MAIN APPLICATION
addappid(2510510)
-- Game: addappid(2510510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510511, 1, "d84d34e774dab455ebfec6d82591f25c60b95ceb45095166a4ad40131c51aa77")
