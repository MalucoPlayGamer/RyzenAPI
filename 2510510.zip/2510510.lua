-- Lua provided by RyzenAPI 
-- Game: Commander: Zombie Wars
addappid(2510510)
addappid(2510511, 1, "d84d34e774dab455ebfec6d82591f25c60b95ceb45095166a4ad40131c51aa77")
