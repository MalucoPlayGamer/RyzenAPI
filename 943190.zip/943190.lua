-- Lua provided by RyzenAPI
-- Game: AppID 943190

-- MAIN APPLICATION
addappid(943190)

-- MAIN APP DEPOTS / PACKAGES
addappid(943191, 1, "d37c963ab2569b657aa1ce732951b58659ac2cd51ffb480f41e804b1f2d54e5e")

