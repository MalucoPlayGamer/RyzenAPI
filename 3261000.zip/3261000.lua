-- Lua provided by RyzenAPI
-- Game: Game: AppID 3261000

-- MAIN APPLICATION
addappid(3261000)
-- Game: addappid(3261000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261001, 1, "f5d5fac9ea6e000c6f2aa30a69f81f15d1db30c4ddaf4c3ed064b2e0e7d50a01")
