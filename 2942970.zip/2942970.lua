-- Lua provided by RyzenAPI
-- Game: Game: Exiler Playtest

-- MAIN APPLICATION
addappid(2942970)
-- Game: addappid(2942970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942971, 1, "41e0407117a2686e42c580b89cf00167a7d8b49f9a075f39c6d6c82098397133")
