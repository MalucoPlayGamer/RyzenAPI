-- Lua provided by RyzenAPI 
-- Game: Exiler Playtest
addappid(2942970)
addappid(2942971, 1, "41e0407117a2686e42c580b89cf00167a7d8b49f9a075f39c6d6c82098397133")
