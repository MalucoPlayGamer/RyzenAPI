-- Lua provided by RyzenAPI
-- Game: Fida Puti Samurai

-- MAIN APPLICATION
addappid(1534340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534341, 1, "1a3b2d3914505a32f0ade9b93f0bde095532a7999cf12ac80066cab8406fc4c8")

