-- Lua provided by SkyAPI 
-- Game: heaven and hell
addappid(2662200)
addappid(2662201, 1, "d3b6b875fcba1bbaabc785e56c62622cdeec069313c8e7568727d39c51bb3d32")
