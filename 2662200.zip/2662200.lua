-- Lua provided by RyzenAPI
-- Game: Game: heaven and hell

-- MAIN APPLICATION
addappid(2662200)
-- Game: addappid(2662200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662201, 1, "d3b6b875fcba1bbaabc785e56c62622cdeec069313c8e7568727d39c51bb3d32")
