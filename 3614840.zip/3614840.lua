-- Lua provided by RyzenAPI
-- Game: ZDSimulator - ChS7 Locomotive

-- MAIN APPLICATION
addappid(3614840)
-- Game: addappid(3614840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614840,0,"5082bd2dc021de5849f2768e5654b73ae9d861191d3ee19188607a467729848f")
