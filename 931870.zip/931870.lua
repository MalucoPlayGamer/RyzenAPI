-- Lua provided by RyzenAPI
-- Game: addappid(931870)

-- MAIN APPLICATION
addappid(931870)

-- MAIN APP DEPOTS / PACKAGES
addappid(931871, 1, "9a003841e6140dc48403eddbe8603bc3e6d4e67fd4bca53b6e237451a67669fb")
