-- Lua provided by RyzenAPI
-- Game: Game: It's Hard Being A Dog

-- MAIN APPLICATION
addappid(1966910)
-- Game: addappid(1966910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966911, 1, "c7e6a6d1f344bd980c3ca419e9685279551d0f0192c7673a1f5a5f5c41c878ea")
