-- Lua provided by SkyAPI 
-- Game: It's Hard Being A Dog
addappid(1966910)
addappid(1966911, 1, "c7e6a6d1f344bd980c3ca419e9685279551d0f0192c7673a1f5a5f5c41c878ea")
