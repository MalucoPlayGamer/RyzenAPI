-- Lua provided by SkyAPI 
-- Game: AppID 2606950
addappid(2606950)
addappid(2606951, 1, "676053672575eccedd8fe23786204850fb76301e671a18ab9d64298416a0a9f7")
