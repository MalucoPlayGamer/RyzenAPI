-- Lua provided by RyzenAPI
-- Game: addappid(1301840)

-- MAIN APPLICATION
addappid(1301840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301841, 1, "3ae1c40d6cfd58242442aa4434081ef4f6d359f8dfbb7889060806813453edf4")
