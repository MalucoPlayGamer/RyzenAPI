-- Lua provided by RyzenAPI
-- Game: Steelborn

-- MAIN APPLICATION
addappid(1786930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786931, 1, "69a7bb6b5bac0676aa12c40fd7c91f650f8912ecdfe3ea66dba0f82d4c4ee19d")
