-- Lua provided by RyzenAPI 
-- Game: Toilet Chronicles
addappid(1946550)
addappid(1946551, 1, "902669332361615d69899c1cc9e97a10b0a0c43491205cd2ed671b48bced4a81")
addappid(2202610)
