-- Lua provided by RyzenAPI
-- Game: Toilet Chronicles

-- MAIN APPLICATION
addappid(1946550)
addappid(2202610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1946551, 1, "902669332361615d69899c1cc9e97a10b0a0c43491205cd2ed671b48bced4a81")

