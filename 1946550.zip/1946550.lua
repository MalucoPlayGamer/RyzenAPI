-- Lua provided by RyzenAPI
-- Game: 1946550

-- MAIN APPLICATION
addappid(1946550)
addappid(2202610)
-- Game: addappid(1946550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946551, 1, "902669332361615d69899c1cc9e97a10b0a0c43491205cd2ed671b48bced4a81")
