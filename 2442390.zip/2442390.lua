-- Lua provided by RyzenAPI
-- Game: Escape from the Room of the Serving Doll

-- MAIN APPLICATION
addappid(2442390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442391, 1, "0dfba7487de41146d47820a31273e6f1523d1131711dc75849c1521a75bbdf6e")
