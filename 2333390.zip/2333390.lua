-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2023

-- MAIN APPLICATION
addappid(2333390)
-- Game: addappid(2333390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333391, 1, "b305bdf400938d33384d8d116ea027b6c4880e697ff3c366aef07a702d01ca7a")
