-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2023

-- MAIN APPLICATION
addappid(2333390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2333391, 1, "b305bdf400938d33384d8d116ea027b6c4880e697ff3c366aef07a702d01ca7a")

