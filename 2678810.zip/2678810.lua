-- Lua provided by SkyAPI 
-- Game: Heat Death: Survival Train Demo
addappid(2678810)
addappid(2678811, 1, "94c48613e5fa51387cd9155045983ccd9dedab304a64f588d8d10a5cb0312826")
