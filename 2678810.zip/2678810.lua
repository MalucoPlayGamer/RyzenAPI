-- Lua provided by RyzenAPI
-- Game: addappid(2678810)

-- MAIN APPLICATION
addappid(2678810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678811, 1, "94c48613e5fa51387cd9155045983ccd9dedab304a64f588d8d10a5cb0312826")
