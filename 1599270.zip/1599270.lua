-- Lua provided by RyzenAPI
-- Game: addappid(1599270)

-- MAIN APPLICATION
addappid(1599270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599271, 1, "97386e1105cbc2991ce4846d7aeb4c65ed78608f828e99031a75e8e3b4e6545a")
