-- Lua provided by RyzenAPI
-- Game: Game: MIMESIS

-- MAIN APPLICATION
addappid(2827200)
-- Game: addappid(2827200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827201, 1, "016eb6cc0350a518395d00970f93f8381c6ca25e40f75b822439a64d2b550d9f")
