-- Lua provided by RyzenAPI 
-- Game: MIMESIS
addappid(2827200)
addappid(2827201, 1, "016eb6cc0350a518395d00970f93f8381c6ca25e40f75b822439a64d2b550d9f")
