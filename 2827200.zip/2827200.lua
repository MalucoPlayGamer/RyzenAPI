-- Lua provided by RyzenAPI
-- Game: MIMESIS

-- MAIN APPLICATION
addappid(2827200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827201, 1, "016eb6cc0350a518395d00970f93f8381c6ca25e40f75b822439a64d2b550d9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
