-- Lua provided by RyzenAPI 
-- Game: AppID 2110580
addappid(2110580)
addappid(2110581, 1, "07bfa1e65e29cbccd57f8a7399d43bcd5e4455f894e24c647d201a7da8e74287")
addappid(2110583, 1, "b53ca112271137e494fa567fe0f65b30acbb96a6d1aae94dc67bfc84ef9ddf96")
