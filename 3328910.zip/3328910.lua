-- Lua provided by RyzenAPI
-- Game: MySims™ Kingdom

-- MAIN APPLICATION
addappid(3328910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3328911, 1, "f743d18d5456e4dadb18fba78a9cdbc4120f9b44b3397bf58405ce4d59ae05c1")

