-- Lua provided by RyzenAPI
-- Game: 3328910

-- MAIN APPLICATION
addappid(3328910)
-- Game: addappid(3328910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328911, 1, "f743d18d5456e4dadb18fba78a9cdbc4120f9b44b3397bf58405ce4d59ae05c1")
