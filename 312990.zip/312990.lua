-- Lua provided by RyzenAPI
-- Game: The Expendabros

-- MAIN APPLICATION
addappid(312990)

