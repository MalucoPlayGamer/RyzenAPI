-- Lua provided by RyzenAPI
-- Game: 1197840

-- MAIN APPLICATION
addappid(1197840)
-- Game: addappid(1197840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197841, 1, "047c5f40be6c425c04e80c0f3e0cf58a2bf5cc329a0a9ac301ae04a94c8010f7")
