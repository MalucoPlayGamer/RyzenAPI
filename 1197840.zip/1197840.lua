-- Lua provided by RyzenAPI
-- Game: The incredible friends

-- MAIN APPLICATION
addappid(1197840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1197841, 1, "047c5f40be6c425c04e80c0f3e0cf58a2bf5cc329a0a9ac301ae04a94c8010f7")

