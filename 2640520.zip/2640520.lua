-- Lua provided by RyzenAPI
-- Game: Cat Warrior

-- MAIN APPLICATION
addappid(2640520)
-- Game: addappid(2640520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640521, 1, "bc79330e57e3b0e6daebae93bf24a46ca3715585c58e0d34328385cd32ac5567")
