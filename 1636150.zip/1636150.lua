-- Lua provided by RyzenAPI
-- Game: Heavyarms Assemble: WWII

-- MAIN APPLICATION
addappid(1636150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636151, 1, "5ddfb811bf7a459f96b41be0012af8416dd57e238673d6cbc987379b3bc7e667")

