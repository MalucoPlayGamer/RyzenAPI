-- Lua provided by RyzenAPI
-- Game: 2744050

-- MAIN APPLICATION
addappid(2744050)
-- Game: addappid(2744050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744050,0,"bc72920eacff6d82dae14ecb5d72a42f4ecbba95f5aab7db874e4cea87e8801e")
