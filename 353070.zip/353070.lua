-- Lua provided by RyzenAPI
-- Game: Ghost Encounters: Deadwood - Collector's Edition

-- MAIN APPLICATION
addappid(353070)

-- MAIN APP DEPOTS / PACKAGES
addappid(353071, 1, "a4e4c77d08eec1f414a452fc05672353bb35a76e035d94bf7c9bc73b22422032")

