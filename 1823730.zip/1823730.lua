-- Lua provided by RyzenAPI
-- Game: Alephant

-- MAIN APPLICATION
addappid(1823730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823731, 1, "39305bf2bb009044c22cbd587e045c5296ff90edcf4fdce730a5c66788f37a7a")

