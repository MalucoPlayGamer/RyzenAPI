-- Lua provided by SkyAPI 
-- Game: Alephant
addappid(1823730)
addappid(1823731, 1, "39305bf2bb009044c22cbd587e045c5296ff90edcf4fdce730a5c66788f37a7a")
