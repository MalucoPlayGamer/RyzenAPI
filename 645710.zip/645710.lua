-- Lua provided by RyzenAPI
-- Game: 645710

-- MAIN APPLICATION
addappid(645710)
-- Game: addappid(645710)

-- MAIN APP DEPOTS / PACKAGES
addappid(645711, 1, "618f8b69632df6a2030a92b8f1dd9fb74547950f49818553da635ef56c25f303")
