-- Lua provided by RyzenAPI
-- Game: Vampire Legends: The True Story of Kisilova

-- MAIN APPLICATION
addappid(414660)

-- MAIN APP DEPOTS / PACKAGES
addappid(414661, 1, "28d3fd5be4dfb76352eb9220bb3ee13ec9a8ee8dd57f07887f9ff27f1c01899c")
