-- Lua provided by RyzenAPI
-- Game: Vengeance: Lost Love

-- MAIN APPLICATION
addappid(665510)
-- Game: addappid(665510)

-- MAIN APP DEPOTS / PACKAGES
addappid(665511, 1, "475ec17334c20d753962cc50044e8f867988800cfff1c7462d91b084fcd63932")
