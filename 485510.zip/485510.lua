-- Lua provided by RyzenAPI
-- Game: Nioh: Complete Edition

-- MAIN APPLICATION
addappid(485510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(485511, 1, "eebe92a206180d4e31103c85ffa51ad98d44f2be4b697bbeaf237b4657c589c0")
addappid(485512, 1, "eb4221176ff254f8b9987132654da11623fda14bcbd0782398d1a4baf1ec0eea")
addappid(485513, 1, "6a157f276514bf77af6aee407eacfab5b423e8b8592238722985697cf2306545")

