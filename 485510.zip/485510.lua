-- Lua provided by RyzenAPI
-- Game: Nioh: Complete Edition

-- MAIN APPLICATION
addappid(485510)

-- MAIN APP DEPOTS / PACKAGES
addappid(485511, 1, "eebe92a206180d4e31103c85ffa51ad98d44f2be4b697bbeaf237b4657c589c0")
addappid(485512, 1, "eb4221176ff254f8b9987132654da11623fda14bcbd0782398d1a4baf1ec0eea")
addappid(485513, 1, "6a157f276514bf77af6aee407eacfab5b423e8b8592238722985697cf2306545")

