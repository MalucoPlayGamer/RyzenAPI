-- Lua provided by RyzenAPI
-- Game: AppID 1568270

-- MAIN APPLICATION
addappid(1568270)
-- Game: addappid(1568270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568271, 1, "e518bd3f1095ba713143c5ed6452cd918cda6d3e2493ffaf1a6607fd07a702ea")
