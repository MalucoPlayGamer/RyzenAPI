-- Lua provided by RyzenAPI
-- Game: KUUKIYOMI 3: Consider It More and More!! - Father to Son

-- MAIN APPLICATION
addappid(1647250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647251, 1, "b409fc9a4b15ccc0d564d993de1942281abf8cc8d58d9827c2501f6287675bc8")
