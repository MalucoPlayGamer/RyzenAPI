-- Lua provided by RyzenAPI
-- Game: Game: Aurora Dusk: Steam Age

-- MAIN APPLICATION
addappid(397160)
-- Game: addappid(397160)

-- MAIN APP DEPOTS / PACKAGES
addappid(397161, 1, "686818f8048fe11751450b55b953d465936e2ed662374f183d5cdd0c3f5a7e69")
