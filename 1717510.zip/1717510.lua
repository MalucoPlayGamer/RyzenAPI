-- Lua provided by RyzenAPI
-- Game: addappid(1717510)

-- MAIN APPLICATION
addappid(1717510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717511, 1, "f4afb94471b903f05638027de887dcbb7cede67cb164bb856ae92c90b0d79280")
