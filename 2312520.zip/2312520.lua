-- Lua provided by RyzenAPI
-- Game: Everholm

-- MAIN APPLICATION
addappid(2312520)
-- Game: addappid(2312520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312521, 1, "2a14f67a943e532e9b9823337407ef6bc13e31d557f095c70b8b84e2b414658e")
