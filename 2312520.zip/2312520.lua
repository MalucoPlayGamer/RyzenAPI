-- Lua provided by SkyAPI 
-- Game: Everholm
addappid(2312520)
addappid(2312521, 1, "2a14f67a943e532e9b9823337407ef6bc13e31d557f095c70b8b84e2b414658e")
