-- Lua provided by RyzenAPI 
-- Game: Hoverflow
addappid(1280060)
addappid(1280061, 1, "d71a27d0e292c081b4f329f51fb488da3d47a59fd1808b9b451ea36d88798186")
