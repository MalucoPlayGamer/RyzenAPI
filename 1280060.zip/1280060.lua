-- Lua provided by RyzenAPI
-- Game: Hoverflow

-- MAIN APPLICATION
addappid(1280060)
-- Game: addappid(1280060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280061, 1, "d71a27d0e292c081b4f329f51fb488da3d47a59fd1808b9b451ea36d88798186")
