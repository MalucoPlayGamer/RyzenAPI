-- Lua provided by RyzenAPI
-- Game: 1918300

-- MAIN APPLICATION
addappid(1918300)
-- Game: addappid(1918300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918301, 1, "585fd421e53baf5077d242ce7ce62d78efb3b7d09eecfff1ccb6cd16d03c7f81")
