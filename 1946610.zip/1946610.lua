-- Lua provided by RyzenAPI
-- Game: Soul Street

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1946610)
addappid(1946611)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946612,0,"690585ff21ae95767811afb52204d463d5a056b5f4112fd3d0b38722331a9806")
