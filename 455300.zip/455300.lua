-- Lua provided by RyzenAPI
-- Game: Deuterium Wars

-- MAIN APPLICATION
addappid(455300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(455301, 1, "2a1d9885d3b102bc72406f151f2199b9aea8e86290218def6cac6fbe433877ac")

