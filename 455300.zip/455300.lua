-- Lua provided by RyzenAPI
-- Game: Deuterium Wars

-- MAIN APPLICATION
addappid(455300)
-- Game: addappid(455300)

-- MAIN APP DEPOTS / PACKAGES
addappid(455301, 1, "2a1d9885d3b102bc72406f151f2199b9aea8e86290218def6cac6fbe433877ac")
