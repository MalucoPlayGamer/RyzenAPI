-- Lua provided by RyzenAPI 
-- Game: reaktron
addappid(1029640)
addappid(1029641, 1, "c2f301566420c8e3070c250c79709db639c5b16fe6cba79ed32b6740afe21a72")
