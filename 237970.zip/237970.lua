-- Lua provided by RyzenAPI
-- Game: Game: Memento Mori 2

-- MAIN APPLICATION
addappid(237970)
-- Game: addappid(237970)

-- MAIN APP DEPOTS / PACKAGES
addappid(237971, 1, "af67fda7a31bd84c3dc05d762525fb7f9f6a38c3c73d0a950a0d3f028899564d")
addappid(237972, 1, "56917d67c5b10983508dfd977d1a1cb246e745f9524179fca16730db87082add")
addappid(237973, 1, "4e55534d9d40a34f199148ee273cd2fa81f7ecdc9bec5847a6aba89172d397bd")
addappid(237974, 1, "379b4ced43abd30cb0f18ee8d1c687d8294f112a1e00bc7f215383a7b83fdf0a")
addappid(237975, 1, "b708aa6bd09c5dde37317587966cc09f8eb29cafcd95fc081632e85c8aa6c664")
