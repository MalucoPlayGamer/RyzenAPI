-- Lua provided by RyzenAPI
-- Game: Memento Mori 2

-- MAIN APPLICATION
addappid(237970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(237971, 1, "af67fda7a31bd84c3dc05d762525fb7f9f6a38c3c73d0a950a0d3f028899564d")
addappid(237972, 1, "56917d67c5b10983508dfd977d1a1cb246e745f9524179fca16730db87082add")
addappid(237973, 1, "4e55534d9d40a34f199148ee273cd2fa81f7ecdc9bec5847a6aba89172d397bd")
addappid(237974, 1, "379b4ced43abd30cb0f18ee8d1c687d8294f112a1e00bc7f215383a7b83fdf0a")
addappid(237975, 1, "b708aa6bd09c5dde37317587966cc09f8eb29cafcd95fc081632e85c8aa6c664")

