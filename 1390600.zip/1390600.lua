-- Lua provided by RyzenAPI
-- Game: Shachibato! President, It's Time for Battle! Maju Wars

-- MAIN APPLICATION
addappid(1390600)
addappid(1556450)
addappid(1556451)
addappid(1567660)
addappid(1567661)
addappid(1567662)
addappid(1567663)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390601, 1, "2c17f474bae89b06fa086422be9302f1260a8cc61169f83761940461817edf9c")
addappid(1418730, 0, "d683c8b8d954c93fa4dcb798e8aa07c7dca3ca22f02ffdfae3a1c997cea1adb9")
