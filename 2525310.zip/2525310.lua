-- Lua provided by RyzenAPI
-- Game: Drop Duchy

-- MAIN APPLICATION
addappid(2525310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525311, 1, "4f575923f1b939467dae8a961bf95e3c380dd3594554f5f67b1c64fe7edd3409")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3839960)
addappid(4091080)
