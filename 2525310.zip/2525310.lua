-- Lua provided by RyzenAPI
-- Game: Drop Duchy

-- MAIN APPLICATION
addappid(2525310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525311, 1, "4f575923f1b939467dae8a961bf95e3c380dd3594554f5f67b1c64fe7edd3409")

