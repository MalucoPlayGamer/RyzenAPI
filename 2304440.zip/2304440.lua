-- Lua provided by RyzenAPI
-- Game: addappid(2304440)

-- MAIN APPLICATION
addappid(2304440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304441, 1, "6ad33af8b266cd33eacae0927862156dd6229b96898d5a907c7c3e616f27017c")
