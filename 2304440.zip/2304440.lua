-- Lua provided by RyzenAPI
-- Game: Creatures of Ava

-- MAIN APPLICATION
addappid(2304440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304441, 1, "6ad33af8b266cd33eacae0927862156dd6229b96898d5a907c7c3e616f27017c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
