-- Lua provided by RyzenAPI
-- Game: OrbusVR Demo

-- MAIN APPLICATION
addappid(1090890)
addappid(1090891)
addappid(1090892)

-- MAIN APP DEPOTS / PACKAGES
addappid(746931,0,"29e028b4b28a39737487f1e97e2c91ea8c74cdbaf8e8928b39a1b226fed7c6c3")

