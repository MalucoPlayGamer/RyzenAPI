-- Lua provided by RyzenAPI
-- Game: Game: Dreamscaper: Prologue

-- MAIN APPLICATION
addappid(1253950)
-- Game: addappid(1253950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253951, 1, "201699d45c3a11509989e27cdef91e5d1678d9b131f6c580b40ce3325d627807")
