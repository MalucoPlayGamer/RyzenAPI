-- Lua provided by RyzenAPI
-- Game: Slenderman Demo

-- MAIN APPLICATION
addappid(1657410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657411, 1, "d02fcaf42b7cd10b3e0b02f33734ea2d3f7436decb2cc8031e8d070f0839ff66")
