-- Lua provided by RyzenAPI
-- Game: 2424650

-- MAIN APPLICATION
addappid(2424650)
-- Game: addappid(2424650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424651, 1, "f388c155a09fdda1a7554de346724013cb5556a900269efe56983a71aadb550c")
