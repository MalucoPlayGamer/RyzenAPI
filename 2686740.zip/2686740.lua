-- Lua provided by RyzenAPI
-- Game: Divergence

-- MAIN APPLICATION
addappid(2686740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686741, 1, "ec9a87f3d78263485d4a2cfcd1a9d31f9536158d1080ec4435d68241333aaa9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
