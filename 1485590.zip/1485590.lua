-- Lua provided by RyzenAPI
-- Game: Game: ENDLESS Dungeon™ - Definitive Edition

-- MAIN APPLICATION
addappid(1485590)
-- Game: addappid(1485590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485591, 1, "c4f7fff9f8616f14e9aef0093499179b54b9b3c8f805174bd7c141e67b18a5e3")
addappid(1485592, 1, "6ce1de72d5608aea5c8f9514083cab242d9895afc87c212442e20eb1cfda3a80")
