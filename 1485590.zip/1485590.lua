-- Lua provided by RyzenAPI
-- Game: ENDLESS Dungeon™ - Definitive Edition

-- MAIN APPLICATION
addappid(1485590)
addappid(2229660)
addappid(2229661)
addappid(2620920)
addappid(2741170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1485591, 1, "c4f7fff9f8616f14e9aef0093499179b54b9b3c8f805174bd7c141e67b18a5e3")
addappid(1485592, 1, "6ce1de72d5608aea5c8f9514083cab242d9895afc87c212442e20eb1cfda3a80")

