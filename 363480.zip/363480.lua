-- Lua provided by RyzenAPI
-- Game: Game: AppID 363480

-- MAIN APPLICATION
addappid(363480)
-- Game: addappid(363480)

-- MAIN APP DEPOTS / PACKAGES
addappid(363481, 1, "3fce002ed697785ca5469d11865661176c11a16552ab27bde7336615e3a0792f")
