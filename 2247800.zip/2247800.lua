-- Lua provided by RyzenAPI
-- Game: Touch Me

-- MAIN APPLICATION
addappid(2247800)
-- Game: addappid(2247800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247801, 1, "fc5771b3aee336924425b3cd06f92406d70b09805da945eb0459501475d15533")
