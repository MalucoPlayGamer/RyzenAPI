-- Lua provided by RyzenAPI
-- Game: 七夜怪谈 - 都市校园禁锢传说

-- MAIN APPLICATION
addappid(932070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(932071, 1, "8a28ed9b9c3382deaa02dc8e9bb721cec364a28f36ab7f8c271d561f75b03c15")

