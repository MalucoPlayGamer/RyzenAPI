-- Lua provided by RyzenAPI
-- Game: Dracula's Library

-- MAIN APPLICATION
addappid(656310)

-- MAIN APP DEPOTS / PACKAGES
addappid(656311, 1, "bdb6fa5c6846fe41f282b978edf61bcc409a3c925851fcf78436186db430077c")
