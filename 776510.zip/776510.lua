-- Lua provided by RyzenAPI
-- Game: 富豪密码

-- MAIN APPLICATION
addappid(776510)

-- MAIN APP DEPOTS / PACKAGES
addappid(776511,0,"fba36cb53b82803a6e26b644e143695c6acc44b6cf7a930bc1c619bf61b8ed5c")

