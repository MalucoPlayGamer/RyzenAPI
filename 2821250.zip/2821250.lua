-- Lua provided by RyzenAPI
-- Game: Game: AppID 2821250

-- MAIN APPLICATION
addappid(2821250)
-- Game: addappid(2821250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821251, 1, "bc48984220c7ab6d083282ee8482bb3e12f404648876d6c056cfaec40cbe6d99")
