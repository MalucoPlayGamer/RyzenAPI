-- Lua provided by RyzenAPI
-- Game: Void Islands

-- MAIN APPLICATION
addappid(2821250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2821251, 1, "bc48984220c7ab6d083282ee8482bb3e12f404648876d6c056cfaec40cbe6d99")
