-- Lua provided by RyzenAPI
-- Game: Who Wants To Be A Millionaire? - US Movies 70s DLC Pack

-- MAIN APPLICATION
addappid(2635160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635160,0,"faa654207bada26e8685359ee1c00cacec0a2d89505d69816bd1b88114ff65ba")

