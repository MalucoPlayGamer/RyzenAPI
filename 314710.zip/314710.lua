-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(229004)
addappid(314710)
addappid(314711)
addappid(325270)
addappid(325440)
addappid(401324)
-- Game: addappid(314710)

-- MAIN APP DEPOTS / PACKAGES
addappid(314712,0,"bd8712e8627f0ac08ecc49df42481566c5481d7f9d3e0d8e818aca03ab51c01f")
addappid(314713,0,"87e167598b53bd6eca93b8da03eeb56e20e14b6ee1d8e28f8a4d04b6aadcd8d8")
addappid(314714,0,"11b030b219a6d87eb3af8e848f7f4f6efcb28c632352cdc0fa3fa317e2e357d0")
addappid(314715,0,"55dd9e5f7b59dd06e38ce0b701be41432e8ef677b9c5c52e9b30512d277d1f45")
addappid(314716,0,"610c274bb176d5c94ea6c1a8b44cfae51927e7a6dbe2442ebaa33ed624d54d08")
addappid(314717,0,"80120265711f59b8b8cca1a59b19d4b9d81c025eef01e520dfdad44a4f005100")
addappid(314718,0,"8e0668b7aef46a008491a268539bf35bbba1db40618987cd806702594d04b8d1")
addappid(314719,0,"19a6685ca1ae2a3f7a7c131c34bab173182c2a286e2375906ace2d35ff35fe1b")
addappid(325271,0,"76d92c8a292e6c7d05cd5bb4c7eafb23d1a54e8df2f4fbbbb685f1ce1d8aa34e")
addappid(325272,0,"2e7f8c6009a2e492d56dcfc3942befba4716edb8a3433df9b1c77c2ef0fe6603")
addappid(325273,0,"3d46f7dd5463c1556362d45e341604f9e1b46f895bb89519fe050f2a202c3941")
addappid(325274,0,"47c4e267e2d088fb6de000170c5f8029025eaeeb93f1007a1dddf6cd0f5f5610")
addappid(364220,0,"87e5847cd00b2a716e6948302e539f9af20b491be4901e23c35da7dc29bca72e")
addappid(401320,0,"54d568d46844ad75f1535db7fc7b8d28da602cf079c19cbe1fe0af3b7f089f2f")
