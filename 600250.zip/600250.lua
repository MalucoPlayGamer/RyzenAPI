-- Lua provided by RyzenAPI
-- Game: Art of Guile

-- MAIN APPLICATION
addappid(600250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(600251, 1, "5aaf93daea9b2ce65457823407e4cf4e034af55dcc19186aa0e24c407edb0538")

