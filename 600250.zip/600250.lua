-- Lua provided by RyzenAPI 
-- Game: AppID 600250
addappid(600250)
addappid(600251, 1, "5aaf93daea9b2ce65457823407e4cf4e034af55dcc19186aa0e24c407edb0538")
