-- Lua provided by RyzenAPI
-- Game: 600250

-- MAIN APPLICATION
addappid(600250)
-- Game: addappid(600250)

-- MAIN APP DEPOTS / PACKAGES
addappid(600251, 1, "5aaf93daea9b2ce65457823407e4cf4e034af55dcc19186aa0e24c407edb0538")
