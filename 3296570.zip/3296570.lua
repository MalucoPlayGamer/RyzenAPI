-- Lua provided by SkyAPI 
-- Game: Phoenix Nirvana Rebirth
addappid(3296570)
addappid(3296571, 1, "bd8cfd050656cf894ec5f5219f83b616e000366091f5b31c3d6c82f7328c0b02")
