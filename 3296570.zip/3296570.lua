-- Lua provided by RyzenAPI
-- Game: Phoenix Nirvana Rebirth

-- MAIN APPLICATION
addappid(3296570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296571, 1, "bd8cfd050656cf894ec5f5219f83b616e000366091f5b31c3d6c82f7328c0b02")
