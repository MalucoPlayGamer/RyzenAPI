-- Lua provided by RyzenAPI
-- Game: Companion

-- MAIN APPLICATION
addappid(545340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(545341, 1, "7a2515cc1f3085f11b13d680ca0f48e8c36f4a58b2f880b9b1d22011a6e62f39")
addappid(545342, 1, "a23c4266998e073631d29bc4ddb0ab01fe33882c8ff86e577047577898ddce8f")

