-- Lua provided by RyzenAPI
-- Game: Game: AppID 545340

-- MAIN APPLICATION
addappid(545340)
-- Game: addappid(545340)

-- MAIN APP DEPOTS / PACKAGES
addappid(545341, 1, "7a2515cc1f3085f11b13d680ca0f48e8c36f4a58b2f880b9b1d22011a6e62f39")
addappid(545342, 1, "a23c4266998e073631d29bc4ddb0ab01fe33882c8ff86e577047577898ddce8f")
