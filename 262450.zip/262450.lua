-- Lua provided by RyzenAPI
-- Game: Dead Man's Draw

-- MAIN APPLICATION
addappid(262450)

-- MAIN APP DEPOTS / PACKAGES
addappid(262451, 1, "3b5d016383cce8895d1edfb2db1376135f3294ad9fca90b474dcd12300a8324d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
