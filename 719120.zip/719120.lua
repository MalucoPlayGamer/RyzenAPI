-- Lua provided by RyzenAPI
-- Game: 719120

-- MAIN APPLICATION
addappid(719120)
-- Game: addappid(719120)

-- MAIN APP DEPOTS / PACKAGES
addappid(719121, 1, "fb3897b23b03de3275ee04fe94a250021edde5fd80688e26e2e222c99b42ed51")
