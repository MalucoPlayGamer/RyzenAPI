-- Lua provided by RyzenAPI
-- Game: Banana Drama

-- MAIN APPLICATION
addappid(2000150)
addappid(2198180)
addappid(2198181)
addappid(2198182)
addappid(2689270)
addappid(2689280)
addappid(2689290)
addappid(2689300)
addappid(2689310)
addappid(2689320)
addappid(2689330)
addappid(2689340)
addappid(2689350)
addappid(2689360)
addappid(2689390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2000152,0,"f2bbf62cca6672a887ebc4878bb882cafea81ae51f25a9fe5fb6dfa66c9f7087")
addappid(2000153,0,"66e5ca9a0830235b545f07059f32fac5c073d5db305553c894c2179e379bf415")
addappid(2000154,0,"58ea726dbf594f9e48295b36316abae4b2b6fe227e32575ea85531d0b1f56dab")

