-- Lua provided by RyzenAPI
-- Game: GUNDAM EVOLUTION

-- MAIN APPLICATION
addappid(1816670)
-- Game: addappid(1816670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816671, 1, "ba7a7641a0b4ac79e6d3ceadcf62c37dc24ad260901acd9030b3ab82a1203034")
