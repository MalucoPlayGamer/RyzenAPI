-- Lua provided by RyzenAPI
-- Game: GUNDAM EVOLUTION

-- MAIN APPLICATION
addappid(1816670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1816671, 1, "ba7a7641a0b4ac79e6d3ceadcf62c37dc24ad260901acd9030b3ab82a1203034")

