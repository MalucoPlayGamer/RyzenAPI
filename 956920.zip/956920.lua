-- Lua provided by RyzenAPI
-- Game: 956920

-- MAIN APPLICATION
addappid(956920)
-- Game: addappid(956920)

-- MAIN APP DEPOTS / PACKAGES
addappid(956920,0,"f59453acfad5aa76634f50769015c8ba155af3d9887a244a3cb2cc593e912057")
