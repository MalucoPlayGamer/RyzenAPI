-- Lua provided by RyzenAPI
-- Game: Skully Pinball

-- MAIN APPLICATION
addappid(1059190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059191, 1, "ee520a764591735e9217f0ba4f67f228517636ba527f8c362d8e2e0b53a0a0f7")
