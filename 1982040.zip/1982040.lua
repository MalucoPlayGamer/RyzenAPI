-- Lua provided by RyzenAPI
-- Game: Shotgun King: The Final Checkmate Demo

-- MAIN APPLICATION
addappid(1982040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982041, 1, "a236ece45aa26907d1f0db5509873529d5ffe3159df84cf74190aed54d677dd0")

