-- Lua provided by RyzenAPI
-- Game: Juno: New Origins

-- MAIN APPLICATION
addappid(870200)
-- Game: addappid(870200)

-- MAIN APP DEPOTS / PACKAGES
addappid(870202,0,"771488143ecdbb8bd872ba508c7dd85ad8426bc71622534bb4809e19c792e0a8")
addappid(870203,0,"7f06dc4cf861c8f2475bb3311ed2c5654a085aa45efe62ec85671bbd1db13ef9")
