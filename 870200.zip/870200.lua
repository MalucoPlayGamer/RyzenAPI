-- Lua provided by RyzenAPI
-- Game: Juno: New Origins

-- MAIN APPLICATION
addappid(870200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(870202,0,"771488143ecdbb8bd872ba508c7dd85ad8426bc71622534bb4809e19c792e0a8")
addappid(870203,0,"7f06dc4cf861c8f2475bb3311ed2c5654a085aa45efe62ec85671bbd1db13ef9")

