-- Lua provided by RyzenAPI
-- Game: addappid(3772730)

-- MAIN APPLICATION
addappid(3772730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772731, 1, "c7087182cce3103be0d8aac80e4857599dd194f9896d222c71e2a67dd91f6ba8")
