-- Lua provided by RyzenAPI 
-- Game: This sect accepts female disciples only
addappid(3772730)
addappid(3772731, 1, "c7087182cce3103be0d8aac80e4857599dd194f9896d222c71e2a67dd91f6ba8")
