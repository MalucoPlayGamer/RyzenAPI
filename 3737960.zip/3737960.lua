-- Lua provided by RyzenAPI
-- Game: Planets Ambrosia

-- MAIN APPLICATION
addappid(3737960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737961, 1, "4790a899355cf6b649fb7c1aca6fca4b49eff05f0617ff3519e6fb3932332b72")

