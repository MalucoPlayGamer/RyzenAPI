-- Lua provided by RyzenAPI
-- Game: 416630

-- MAIN APPLICATION
addappid(416630)
-- Game: addappid(416630)

-- MAIN APP DEPOTS / PACKAGES
addappid(416631, 1, "7361ffa483ad2794b999f07bfae75dbe0c3c03d29b6a4c3bbd6c0e791432bcf6")
addappid(416632, 1, "a7929bb993b3764e41825e78631abd8dbcde34cde3bc73fc6b3f00b326c0aa6b")
addappid(416633, 1, "6137895680bae7a43d5bd6b1b8d9f6570b1a647bd299b99554ee2e74c741b184")
addappid(420250, 0, "cd2507344bf066956075768c1352d2fedcc355a576dd5d76fc6e1f94d5b4af14")
