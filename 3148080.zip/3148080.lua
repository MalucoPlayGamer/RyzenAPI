-- Lua provided by RyzenAPI
-- Game: Summon The DUDES!

-- MAIN APPLICATION
addappid(3148080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148082,0,"3419b7106b15766f592a12ec7a66b298da112af8589e0b1cdb21fa3ab1473603")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
