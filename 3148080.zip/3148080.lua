-- Lua provided by RyzenAPI
-- Game: Summon The DUDES!

-- MAIN APPLICATION
addappid(3148080)
-- Game: addappid(3148080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148082,0,"3419b7106b15766f592a12ec7a66b298da112af8589e0b1cdb21fa3ab1473603")
