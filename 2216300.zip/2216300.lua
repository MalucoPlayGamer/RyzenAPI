-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Chuo Line Rapid Service (Takao to  Tokyo) E233-0 series

-- MAIN APPLICATION
addappid(2216300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216302,0,"8c3c5e9ee828da6b6076296c6b1ed57f6ceff26173ae436aa5345b236849c856")
addappid(2216303,0,"909d79a907da64e8083bba51702b844e14dfe4d9cc89ab174259ab072c372936")
