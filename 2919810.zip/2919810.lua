-- Lua provided by RyzenAPI
-- Game: Knightly Passions (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2919810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919811, 1, "d9a8b44b6900ba0730065914ef821c348613d9b4d8712bb09076c8241dcc83f5")
