-- Lua provided by RyzenAPI
-- Game: MetaWare High School (Demo)

-- MAIN APPLICATION
addappid(1194740)

