-- Lua provided by RyzenAPI 
-- Game: Mother Simulator
addappid(802730)
addappid(802731, 1, "3f82306c6b07cf4b84fccdb1bb7d95b2b1f0904b89f77bd909538c72dc04e51b")
