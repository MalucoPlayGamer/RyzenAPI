-- Lua provided by RyzenAPI
-- Game: Game: AppID 208110

-- MAIN APPLICATION
addappid(208110)
-- Game: addappid(208110)

-- MAIN APP DEPOTS / PACKAGES
addappid(208111, 1, "a693c9fb9f8b66af6489ff0d1ab3f3e6d9003f19b25bb2791ab8aa345b8c823a")
addappid(208112, 1, "4202d0f82aaab80a98ef4edd2d7d0a3e733e49710235dc005aa81642b7bf67d2")
