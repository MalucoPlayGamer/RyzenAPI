-- Lua provided by RyzenAPI
-- Game: Game: Creo God Simulator

-- MAIN APPLICATION
addappid(1028730)
-- Game: addappid(1028730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028731, 1, "c01214c5beaafde05af6fe5850490d0db205eaaf65206d715a5897dab54f55f5")
