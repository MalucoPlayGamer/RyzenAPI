-- Lua provided by RyzenAPI 
-- Game: AppID 644670
addappid(644670)
addappid(644671, 1, "582e5a971fed68d7881cb1e1cc5648dfa47bc8d501d62bbbdeab82a4de26c770")
