-- Lua provided by RyzenAPI
-- Game: Kaodi Soundtrack

-- MAIN APPLICATION
addappid(3688280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688281, 1, "9ba9fa41597125a2a19382cc8df44cd29834bf6726e27f4721a5f214f32ddc83")
addappid(3688282, 1, "375a484518b334547d8b5b8b048b5c7b6273cea013a69ec1536e4e159dfd1dda")

