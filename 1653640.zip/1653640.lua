-- Lua provided by RyzenAPI
-- Game: Tank Fantastic

-- MAIN APPLICATION
addappid(1653640)
-- Game: addappid(1653640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653641, 1, "3047cb56d47c1ca5094f115277e2b065c414f37fa486323a327e5f15b3af2f5e")
