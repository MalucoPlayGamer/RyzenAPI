-- Lua provided by RyzenAPI
-- Game: Tank Fantastic

-- MAIN APPLICATION
addappid(1653640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1653641, 1, "3047cb56d47c1ca5094f115277e2b065c414f37fa486323a327e5f15b3af2f5e")

