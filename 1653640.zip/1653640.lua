-- Lua provided by SkyAPI 
-- Game: Tank Fantastic
addappid(1653640)
addappid(1653641, 1, "3047cb56d47c1ca5094f115277e2b065c414f37fa486323a327e5f15b3af2f5e")
