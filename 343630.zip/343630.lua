-- Lua provided by RyzenAPI
-- Game: AppID 343630

-- MAIN APPLICATION
addappid(343630)
addappid(346540)
addappid(346541)
addappid(346542)

-- MAIN APP DEPOTS / PACKAGES
addappid(343631, 1, "7e0a95069d6c7b1e06c0ffb73094138cd87d480bd709dce9b6459ac19a148304")

