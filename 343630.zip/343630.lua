-- Lua provided by RyzenAPI
-- Game: CroNix

-- MAIN APPLICATION
addappid(343630)
addappid(346540)
addappid(346541)
addappid(346542)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(343631, 1, "7e0a95069d6c7b1e06c0ffb73094138cd87d480bd709dce9b6459ac19a148304")

