-- Lua provided by RyzenAPI
-- Game: addappid(3361180)

-- MAIN APPLICATION
addappid(3361180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361181, 1, "a829c7c07664f364139617a132afc0de1cb2daf439ddc75636e32a2702d5240b")
