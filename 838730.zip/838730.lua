-- Lua provided by RyzenAPI
-- Game: Grim Tales: The Stone Queen Collector's Edition

-- MAIN APPLICATION
addappid(838730)

-- MAIN APP DEPOTS / PACKAGES
addappid(838731, 1, "2a5a890171620a1530933b8272b92db5aaddacb7dd4cd16a43bc765e88ff97c3")
