-- Lua provided by RyzenAPI 
-- Game: AppID 838730
addappid(838730)
addappid(838731, 1, "2a5a890171620a1530933b8272b92db5aaddacb7dd4cd16a43bc765e88ff97c3")
