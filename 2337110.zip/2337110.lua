-- Lua provided by RyzenAPI
-- Game: 2337110

-- MAIN APPLICATION
addappid(2337110)
-- Game: addappid(2337110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337111, 1, "762fedce8a6080103cc6dbf6f50b053a80e0c95e05c1b68b36b7b47444ed9ce2")
