-- Lua provided by RyzenAPI
-- Game: Universe For Sale

-- MAIN APPLICATION
addappid(1627840)
-- Game: addappid(1627840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627841, 1, "8a232bb2af51327d604a9e378cf5e2da991ec9bdcb464f35de967ab98ba55f5b")
addappid(1627842, 1, "6308dc6c54f3773651969a6960bb1245a71bd0fbab175820c857264de3ad6983")
addappid(1627843, 1, "eb022c28824393e9f652ecef9bc85f9a6b06910e96c358475f3185698afc313f")
