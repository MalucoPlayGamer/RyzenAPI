-- Lua provided by RyzenAPI
-- Game: addappid(963950)

-- MAIN APPLICATION
addappid(963950)

-- MAIN APP DEPOTS / PACKAGES
addappid(963952,0,"996604ba0a2d386f311cd379731fd0ff9ddedb2729cd0be3ff3be4aab98709d4")
