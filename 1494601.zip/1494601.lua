-- Lua provided by RyzenAPI
-- Game: addappid(1494601)

-- MAIN APPLICATION
addappid(1494601)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494601,0,"be1c6101f1d58ba96090fa74c43ea75c063edeb1db18980246980df8dffd6b12")
