-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2020 Effects - Pixel Age Pack

-- MAIN APPLICATION
addappid(1253752)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253752,0,"412df0f038cc7c11030d60617438f65be133d554c3d023507c7b12d059e6ba08")
