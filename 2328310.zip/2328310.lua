-- Lua provided by RyzenAPI
-- Game: CUSTOM MECH WARS

-- MAIN APPLICATION
addappid(2328310)
addappid(2584900)
addappid(2584910)
addappid(2584920)
addappid(2584930)
addappid(2584940)
addappid(2584950)
addappid(2584960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328311, 1, "bb7037c9c8ad7dd0b3b609714b75753a8cde8b6d8a37187851caeb5b84382413")

