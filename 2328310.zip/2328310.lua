-- Lua provided by RyzenAPI 
-- Game: CUSTOM MECH WARS
addappid(2328310)
addappid(2328311, 1, "bb7037c9c8ad7dd0b3b609714b75753a8cde8b6d8a37187851caeb5b84382413")
