-- Lua provided by SkyAPI 
-- Game: Bagel Love Story
addappid(2798600)
addappid(2798601, 1, "17bfb48f2fa910ff8e5a5f442ec086ad8c5de88b7fb024794541052c94e4db70")
addappid(2909340, 0, "18016997950f78add1c80e59819ae27feb664a3019ffa0f9f8efc1d4b729347c")
