-- Lua provided by RyzenAPI
-- Game: Orbos

-- MAIN APPLICATION
addappid(801910)

-- MAIN APP DEPOTS / PACKAGES
addappid(801911, 1, "4c3095b2413bed5e5e2b992fada8b6807405e3a7785115735cbfce6002c1113c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
