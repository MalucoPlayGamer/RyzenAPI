-- Lua provided by RyzenAPI
-- Game: Orbos

-- MAIN APPLICATION
addappid(801910)

-- MAIN APP DEPOTS / PACKAGES
addappid(801911, 1, "4c3095b2413bed5e5e2b992fada8b6807405e3a7785115735cbfce6002c1113c")
