-- Lua provided by RyzenAPI
-- Game: 1173630

-- MAIN APPLICATION
addappid(1173630)
addappid(1461330)
addappid(1514530)
-- Game: addappid(1173630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173631, 1, "d2e53e671784c74eeaeb8b1b481c3b4f678e2aeda0ae214cae761c6724f05e85")
