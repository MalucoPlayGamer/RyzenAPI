-- Lua provided by RyzenAPI
-- Game: Moeras

-- MAIN APPLICATION
addappid(1135070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135071, 1, "2837b9348859bd5f0cbfa762f8057d30944fffc44747d85dba693ebc29fdbf2f")
addappid(1135072, 1, "66c9d702ede73033679cdab5081bbb6718e67586d4cd1eda5f58521ddfa8cf81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
