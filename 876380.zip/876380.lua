-- Lua provided by RyzenAPI 
-- Game: Underwater hunting
addappid(876380)
addappid(876381, 1, "ff47e2b4fe737970b7d2704c067c6421cbdc60f98f720aba04537f7d7a4da4a8")
addappid(899640, 0, "22310e86cdfc457d3fb6887be88a48eabb658244aaedb41edb3c2ca17206537a")
addappid(899650, 0, "b770f99b6ea34cb6198b33d4318d6e26b6ddb7ea64d3178e61895cb343a2dc7d")
