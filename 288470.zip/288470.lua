-- Lua provided by RyzenAPI
-- Game: Game: Fable Anniversary

-- MAIN APPLICATION
addappid(288470)
-- Game: addappid(288470)

-- MAIN APP DEPOTS / PACKAGES
addappid(288471, 1, "5795bc052b2a0d53947c274a5da3926e6ba122feed6400c5f833e323177dfea9")
addappid(319120, 0, "0584d850aa452f1020491d01f0981832d8525f47eadf9561a3d3ae45932f9eba")
