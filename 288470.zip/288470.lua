-- Lua provided by RyzenAPI
-- Game: Fable Anniversary

-- MAIN APPLICATION
addappid(288470)

-- MAIN APP DEPOTS / PACKAGES
addappid(288471, 1, "5795bc052b2a0d53947c274a5da3926e6ba122feed6400c5f833e323177dfea9")
addappid(319120, 0, "0584d850aa452f1020491d01f0981832d8525f47eadf9561a3d3ae45932f9eba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(315150)
addappid(315151)
