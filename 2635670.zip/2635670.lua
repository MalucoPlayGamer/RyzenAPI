-- Lua provided by RyzenAPI
-- Game: 2635670

-- MAIN APPLICATION
addappid(2635670)
-- Game: addappid(2635670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635671, 1, "2fe44f8637e282154326f76edde8a0a69098a99fdfacc3dee46929a5599a1f16")
