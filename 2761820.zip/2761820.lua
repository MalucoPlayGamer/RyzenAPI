-- Lua provided by RyzenAPI
-- Game: Highway Drifter: Hajwala Simulator

-- MAIN APPLICATION
addappid(2761820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761821,0,"d26924018a44e7b3545d58b3ce01a5e006ce58a2318c846aa780d6668f1f64ed")

