-- Lua provided by RyzenAPI
-- Game: Witch's Apocalyptic Journey

-- MAIN APPLICATION
addappid(3709430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709430,0,"9d2b2ec02188e7e422edde0af56263fbe05cbe43e15ec1e4a0781072ce17a706")
addappid(3709431,0,"e88ec217d9ee952c847d1283a0fbcd4ea26d774711fad25dfbd830f23e7ae00e")
addappid(3709432,0,"745c31b23e57bbcd47182d04f44b2715389fae03f3f8d3635c138a49fd2b72b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
