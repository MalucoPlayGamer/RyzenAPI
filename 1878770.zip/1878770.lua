-- Lua provided by RyzenAPI
-- Game: ASCIILL

-- MAIN APPLICATION
addappid(1878770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878771, 1, "bde20f90a9e20deff894ac06245fe8159bd377dc071a069eee7da2f0f21f11c5")
