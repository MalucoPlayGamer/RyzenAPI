-- Lua provided by RyzenAPI
-- Game: addappid(2462090)

-- MAIN APPLICATION
addappid(2462090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462091, 1, "870a8024c3fd970d39f67220f17e94764c425b938ab24b07fe782751ec08bfea")
