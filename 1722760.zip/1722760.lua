-- Lua provided by RyzenAPI
-- Game: 1722760

-- MAIN APPLICATION
addappid(1722760)
-- Game: addappid(1722760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722761, 1, "1250d0ac5438ef7333eb6d3d3b57bfb5a84c5bf242c698140037ff071c1c5344")
