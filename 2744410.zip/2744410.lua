-- Lua provided by RyzenAPI
-- Game: Game: Law of Dispute

-- MAIN APPLICATION
addappid(2744410)
-- Game: addappid(2744410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744411, 1, "97dc15e0079732c113efa1094e13c320f7db80ff6526f58826a623d7f1fa5618")
