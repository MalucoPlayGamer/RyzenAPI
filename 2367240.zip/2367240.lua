-- Lua provided by RyzenAPI
-- Game: Pricia Defense - R18 DLC

-- MAIN APPLICATION
addappid(2367240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367242,0,"2e12436a80d1a69dfcf3ea4ad2e984875b01d4849cc4ad003d8ff65011657666")
