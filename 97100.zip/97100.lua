-- Lua provided by RyzenAPI
-- Game: Section 8®: Prejudice™

-- MAIN APPLICATION
addappid(97100)
-- Game: addappid(97100)

-- MAIN APP DEPOTS / PACKAGES
addappid(97101, 1, "8a07f9ff385df81d5652a4e86fd1de6cbdea9471477602ab145358229ba137da")
addappid(97102, 1, "790b66ba583adbe33aa691704c71465e48d90a19dddc91dee749ca16383d0023")
addappid(97103, 1, "fad9bbed17335325cda2031599769bf9347ffdf831a7a208b527dfe1233fc208")
addappid(97104, 1, "d75cb3ba381f4723875f78e51b525c2a49978b626376265df5f50d8beeabb771")
addappid(97105, 1, "1dcb6588016117d51ced9ef12bfc40e78f67d1aef12f02521095981c1852aca2")
