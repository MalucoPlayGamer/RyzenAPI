-- Lua provided by RyzenAPI
-- Game: Slay the Alice Demo

-- MAIN APPLICATION
addappid(3129800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129801, 1, "2f41de187d599bf9bd1799aac1310ffb5c2e0a01fb94806af70d1238aa4b637d")

