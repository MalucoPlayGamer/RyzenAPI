-- Lua provided by RyzenAPI
-- Game: Tempest Tower

-- MAIN APPLICATION
addappid(3123800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123801, 1, "d4d07961d30d611a21bbf1f251a1a767510bf612179f9babf07d25da543f4c46")
