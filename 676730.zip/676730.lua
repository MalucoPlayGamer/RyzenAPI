-- Lua provided by RyzenAPI
-- Game: Behind The Door

-- MAIN APPLICATION
addappid(676730)

-- MAIN APP DEPOTS / PACKAGES
addappid(676731,0,"41befabd7152924e6a0b3cb55bb75410097f927a43124cfb72b2c961da2a944a")
addappid(676732,0,"89d2bea7fa0de518733a9a50f80e0e212afc3792bf5e638d7f530e7509a99a44")

