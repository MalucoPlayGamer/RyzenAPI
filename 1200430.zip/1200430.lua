-- Lua provided by RyzenAPI
-- Game: Game: Sick Way

-- MAIN APPLICATION
addappid(1200430)
-- Game: addappid(1200430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200431, 1, "90d0e96ecdca3791edd63e2dfe7ff1d44ea37ee173c1d27c7b62dbe78b03860f")
