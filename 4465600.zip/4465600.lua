-- 4465600's Lua and Manifest Created by Hubcap Manifest
-- Bowling Alley Simulator
-- Created: July 14, 2026 at 20:38:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4465600) -- Bowling Alley Simulator
-- MAIN APP DEPOTS
addappid(4465601, 1, "d1893f4fd66a63308d918ae6c2e4ec20d631641cd374c660336363957eda84ca") -- Depot 4465601
setManifestid(4465601, "8018295512423883717", 2112852469)
addappid(4465602, 1, "f9a63f1257ccb7e01af35d85fc8aa60000ab5a2f2b37ae1a563f48cbbf3b9489") -- Depot 4465602
setManifestid(4465602, "4349778626287540050", 2225425645)
addappid(4465603, 1, "55e84b2de3068d2ea3e7527c100e686edcea7e484ab632b869a7da34f3391b43") -- Depot 4465603
setManifestid(4465603, "4794091842996917277", 2168176152)