-- Lua provided by RyzenAPI
-- Game: Bowling Alley Simulator

-- MAIN APPLICATION
addappid(4465600) -- Bowling Alley Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4465601, 1, "d1893f4fd66a63308d918ae6c2e4ec20d631641cd374c660336363957eda84ca") -- Depot 4465601
addappid(4465602, 1, "f9a63f1257ccb7e01af35d85fc8aa60000ab5a2f2b37ae1a563f48cbbf3b9489") -- Depot 4465602
addappid(4465603, 1, "55e84b2de3068d2ea3e7527c100e686edcea7e484ab632b869a7da34f3391b43") -- Depot 4465603
