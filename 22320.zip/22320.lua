-- Lua provided by RyzenAPI
-- Game: The Elder Scrolls III: Morrowind

-- MAIN APPLICATION
addappid(22320)

-- MAIN APP DEPOTS / PACKAGES
addappid(22321, 1, "429f9853ef0352eae5c000042863c2418d021152eb8bdaa1f0b5790bf24fe818")
addappid(22322, 1, "cf02c461f89a0bec48f9ceee9a51d7206477f39421ac58e9c5900e5d982bb46e")
addappid(22323, 1, "f7f63eb2c805e69d0a4823a694a6bea06215dc997bb4531144461249cff8c69c")
addappid(451410, 0, "67e3cebb44f09bba15f13ebdf92f45b6081fc8a9a9d8774faa91897c6633d58e")
