-- Lua provided by SkyAPI 
-- Game: ANDOR Ladies
addappid(1711490)
addappid(1711491, 1, "5de201041be87184d1ec859db61e484f38c751b92c0b02c550f5d24bc7c7c12a")
