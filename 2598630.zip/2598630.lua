-- Lua provided by SkyAPI 
-- Game: The Dragonhood
addappid(2598630)
addappid(2598631, 1, "ea8a0e5026e57ad95e942a9889ea3f49351e3ed2751881fb5cf0d6462cb4e949")
