-- Lua provided by RyzenAPI
-- Game: The Dragonhood

-- MAIN APPLICATION
addappid(2598630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598631, 1, "ea8a0e5026e57ad95e942a9889ea3f49351e3ed2751881fb5cf0d6462cb4e949")
