-- Lua provided by RyzenAPI
-- Game: AppID 3515270

-- MAIN APPLICATION
addappid(3515270)
-- Game: addappid(3515270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515271, 1, "eac28c168df39975d0cd85f28e76ffdd01510a8000d8fcab076b1f0e93563e04")
