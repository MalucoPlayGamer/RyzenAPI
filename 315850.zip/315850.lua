-- Lua provided by RyzenAPI
-- Game: Amazing Princess Sarah

-- MAIN APPLICATION
addappid(315850)

-- MAIN APP DEPOTS / PACKAGES
addappid(315851, 1, "f1a1423b8eec38e8faa8b766eda256c7d1a7a2d3af09c650127356b6f06938c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
