-- Lua provided by RyzenAPI
-- Game: 315850

-- MAIN APPLICATION
addappid(315850)
-- Game: addappid(315850)

-- MAIN APP DEPOTS / PACKAGES
addappid(315851, 1, "f1a1423b8eec38e8faa8b766eda256c7d1a7a2d3af09c650127356b6f06938c8")
