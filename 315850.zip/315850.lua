-- Lua provided by RyzenAPI 
-- Game: Amazing Princess Sarah
addappid(315850)
addappid(315851, 1, "f1a1423b8eec38e8faa8b766eda256c7d1a7a2d3af09c650127356b6f06938c8")
