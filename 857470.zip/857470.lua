-- Lua provided by SkyAPI 
-- Game: NEKOKORO
addappid(857470)
addappid(857471, 1, "05a6e6a5b5300066e0dba0a18a2f370a42d5ee01223b8aba972cb994d2e17a57")
