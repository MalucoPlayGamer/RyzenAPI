-- Lua provided by RyzenAPI
-- Game: METAL SLUG 3 Soundtrack

-- MAIN APPLICATION
addappid(1921810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921811, 1, "3ac31f4bf999369fb078738e00d2378dacf43dd6fc4f74e75b3c72fff51a00de")
addappid(1921812, 1, "4016d1bef9c07e8b77b0a5526d725d092ebeccc9f9fdf3af3723876f73e4e936")
