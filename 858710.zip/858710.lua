-- Lua provided by RyzenAPI
-- Game: Game: AppID 858710

-- MAIN APPLICATION
addappid(858710)
-- Game: addappid(858710)

-- MAIN APP DEPOTS / PACKAGES
addappid(858711, 1, "6dbdcba5ecd774a6c4df7638c0f2baa8ecbbe9a888ab4725d55a1b7293c77372")
addappid(858712, 1, "70c88a235658930327b215f07b5ab29ed7ad02ad3b666d8c222bdfb7d9cb12a0")
addappid(858713, 1, "d8e5e7ac7dd3923f3024f04c98cba52f7b6b47a1a2c271247cbe664cd672c559")
