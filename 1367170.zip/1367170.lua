-- Lua provided by RyzenAPI
-- Game: Planet's Edge

-- MAIN APPLICATION
addappid(1367170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367171, 1, "3f727896193fb0bda7dc83f34ac81f103ccc5fe1ebbad62cf536c7e3633ffd72")
addappid(1367172, 1, "4973ba27bc63f49be612b408f5d8d82e58ebe1854278b89d5216a4a453fb5d8c")
