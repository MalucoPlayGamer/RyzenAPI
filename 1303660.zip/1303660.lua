-- Lua provided by RyzenAPI
-- Game: 1303660

-- MAIN APPLICATION
addappid(1303660)
addappid(1464580)
-- Game: addappid(1303660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303661, 1, "fa273910cb80a38ebc14d8f643d43e1c8a81bab48221c9a2f41e558795f22e93")
