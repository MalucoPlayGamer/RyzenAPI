-- Lua provided by RyzenAPI
-- Game: Irotoridori No Sekai HD - The Colorful World

-- MAIN APPLICATION
addappid(2591380)
-- Game: addappid(2591380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591381, 1, "d3da60ee023e29b7d36e06cbf4acd5df4372c076a6d02a095d4cd37cf561d52b")
