-- Lua provided by RyzenAPI
-- Game: Game: SENGOKU Princess ～天下統一は姫武将と共に～

-- MAIN APPLICATION
addappid(2050820)
-- Game: addappid(2050820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050821, 1, "b93850494017946c434edb6a1ab5442fda7d850ea25d0549e168a80f86271a61")
