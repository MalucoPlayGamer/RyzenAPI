-- Lua provided by RyzenAPI
-- Game: Game: Healthy Plane

-- MAIN APPLICATION
addappid(2157630)
-- Game: addappid(2157630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157631, 1, "9dfc49a11f85890a755bc0217d4af1feb875965c46bf8d2c1df407494c039d8d")
