-- Lua provided by SkyAPI 
-- Game: Healthy Plane
addappid(2157630)
addappid(2157631, 1, "9dfc49a11f85890a755bc0217d4af1feb875965c46bf8d2c1df407494c039d8d")
