-- Lua provided by RyzenAPI
-- Game: Itadaki Smash

-- MAIN APPLICATION
addappid(1520510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520511, 1, "ce315eaed3fc9bc9520567d84066d73e3cdb1b48a8f25e2e90511567040551f9")
