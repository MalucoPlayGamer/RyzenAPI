-- Lua provided by RyzenAPI
-- Game: Game: 看不见的爱

-- MAIN APPLICATION
addappid(1121980)
-- Game: addappid(1121980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121981, 1, "ad825e380bd2b5bdb2b03add66f563143acfe869b1cdff54e36173e698488533")
