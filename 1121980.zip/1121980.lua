-- Lua provided by RyzenAPI 
-- Game: 看不见的爱
addappid(1121980)
addappid(1121981, 1, "ad825e380bd2b5bdb2b03add66f563143acfe869b1cdff54e36173e698488533")
