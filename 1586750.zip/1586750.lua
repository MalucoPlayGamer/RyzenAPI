-- Lua provided by RyzenAPI 
-- Game: Two Strikes
addappid(1586750)
addappid(1586751, 1, "c8746e133c18d53252ee1009a0e468b215ec0073471690622bccd499a6c524a4")
