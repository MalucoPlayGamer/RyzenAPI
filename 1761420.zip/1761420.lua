-- Lua provided by RyzenAPI
-- Game: Game: Without Pain

-- MAIN APPLICATION
addappid(1761420)
-- Game: addappid(1761420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761421, 1, "cd692a791041b60bfe0b3b7139aa58055412719124548f76b748100903508126")
