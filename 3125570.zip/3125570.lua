-- Lua provided by RyzenAPI
-- Game: 3125570

-- MAIN APPLICATION
addappid(3125570)
-- Game: addappid(3125570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125571, 1, "f0120aa244caeddda39251c1ccd4717bdc1a74eda70dad620f8fae943119cc18")
