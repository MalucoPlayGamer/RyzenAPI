-- Lua provided by RyzenAPI
-- Game: 封神榜2023

-- MAIN APPLICATION
addappid(2581570)
-- Game: addappid(2581570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581571, 1, "23414c7a9081c1bb06db559ccc551b7eff2fc7594144e3618dbb0e161b0e4fff")
