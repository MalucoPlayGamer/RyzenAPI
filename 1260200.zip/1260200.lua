-- Lua provided by RyzenAPI
-- Game: 1260200

-- MAIN APPLICATION
addappid(1260200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260200,0,"e1c4c774c5b100f846a26eb3dcf0a98b37cb25dc559ce0303aa41f19736cccb3")

