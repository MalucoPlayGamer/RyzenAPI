-- Lua provided by RyzenAPI
-- Game: Game: Overstep

-- MAIN APPLICATION
addappid(1008580)
-- Game: addappid(1008580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008581, 1, "bf78a25fc545c9189b4e9f118a702957b3728a98c9ae112c89615ab6c537881c")
