-- Lua provided by RyzenAPI
-- Game: Overstep

-- MAIN APPLICATION
addappid(1008580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1008581, 1, "bf78a25fc545c9189b4e9f118a702957b3728a98c9ae112c89615ab6c537881c")

