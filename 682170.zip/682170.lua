-- Lua provided by RyzenAPI
-- Game: 682170

-- MAIN APPLICATION
addappid(682170)
-- Game: addappid(682170)

-- MAIN APP DEPOTS / PACKAGES
addappid(682171, 1, "7866ebd0daf9cffca90e07e932bd4afb0b36fbeac2252ee38d998ab4ee8a8abf")
