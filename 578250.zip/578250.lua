-- Lua provided by RyzenAPI
-- Game: Invention

-- MAIN APPLICATION
addappid(578250)

-- MAIN APP DEPOTS / PACKAGES
addappid(578251, 1, "b619d2e87964005e74c1ff52bede51c718fb944c998c964de091ae95f52d1934")

