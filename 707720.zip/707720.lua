-- Lua provided by RyzenAPI
-- Game: Ragna Maya

-- MAIN APPLICATION
addappid(707720)

-- MAIN APP DEPOTS / PACKAGES
addappid(707721, 1, "24e7b07406ed462fc18dcc0cc1b2611fbe700b5cbcd7dc7036c92547c88d5fd8")

