-- Lua provided by RyzenAPI
-- Game: addappid(1331240)

-- MAIN APPLICATION
addappid(1331240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331241, 1, "fc94915403167849eec839df6b8e714d51e484b436e8cf80a89da80ef882b977")
