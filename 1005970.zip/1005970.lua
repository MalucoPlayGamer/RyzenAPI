-- Lua provided by RyzenAPI
-- Game: iVRy Driver for SteamVR DEMO (PSVR Lite Edition)

-- MAIN APPLICATION
addappid(1005970)
-- Game: addappid(1005970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005973,0,"d31395a182361bf1c83d2df7f61661f967c0e0f8bbbd1a40281919f8d32ddd26")
