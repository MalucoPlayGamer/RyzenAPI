-- Lua provided by RyzenAPI
-- Game: Staff Runner

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2655660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655663,0,"64105254100f6cc6a96fd8b41c7d31e13bd3c2eee5fac4bbeb38b1890c775cbf")
addappid(2655664,0,"4d016a1b9cd8ee6dc7030f4b8affcee73a9df35bf1266e1ca3410ce5a36decaa")

