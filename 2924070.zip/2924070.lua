-- Lua provided by RyzenAPI
-- Game: MAOUISHO:~ La Dolce Vita with Another World's Demon Lord~  Demo

-- MAIN APPLICATION
addappid(2924070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924073,0,"7b7b530cef20a6d322bcc3626629c818ead442f6744fb928efff28af7b48c630")
addappid(2924074,0,"55393f35f78da0ae19a36f255f206d3a7028cc8e8a1f5f813e7d0cda6d830a13")

