-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(940820)
-- Game: addappid(940820)

-- MAIN APP DEPOTS / PACKAGES
addappid(940820,0,"f739f69b55d5d01569f2e43fbef282fa40b9d18c125741ad54263123d15c2610")
