-- Lua provided by RyzenAPI
-- Game: Inglorious Pirate

-- MAIN APPLICATION
addappid(1219450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219451, 1, "a30e82fc285ebe788e9023e40d46c2e0162d256db84d02749a97dcb7f8349a0b")

