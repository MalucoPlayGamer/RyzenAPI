-- Lua provided by RyzenAPI
-- Game: Victory Heat Rally: Shakedown Demo

-- MAIN APPLICATION
addappid(1739050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739051, 1, "c84848b752f51d849fe67d30bb8d41ac88942bded3d76fec61c12636d8ddd5dc")
