-- Lua provided by RyzenAPI
-- Game: Dark Light

-- MAIN APPLICATION
addappid(1134520)
addappid(2603730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134521, 1, "11391d6482909bac0cb52af9d1bd677fac8137aa3aacebd7e2f8e7bba0a34dce")
addappid(1134522, 1, "f794a13a94068ed8d7f7e31c4c8b59a29999532242322aba6a069e745c470746")

