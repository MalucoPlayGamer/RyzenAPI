-- Lua provided by SkyAPI 
-- Game: AppID 37030
addappid(37030)
addappid(37031, 1, "0457bfb4175b4b0c3a05f8f652af3cafe9e58efe0fe7be0ac11032494076d8de")
