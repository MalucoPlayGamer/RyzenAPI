-- Lua provided by RyzenAPI
-- Game: Game: Heroes of Hammerwatch II

-- MAIN APPLICATION
addappid(619820)
-- Game: addappid(619820)

-- MAIN APP DEPOTS / PACKAGES
addappid(619821, 1, "3266293cec2a56c2754e577f3f533ba7e681e97da2db3fa591f092a028da1872")
addappid(619822, 1, "ee2be5a06add482c4b080f444406417e33dd3a711c9685e84bc6c387dbc02e25")
