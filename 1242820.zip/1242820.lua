-- Lua provided by RyzenAPI
-- Game: AppID 1242820

-- MAIN APPLICATION
addappid(1242820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242821, 1, "342ae3f013c785b387bbd7fd0c5965d19937a6fdbacd39ea8e26d30916861120")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1253020)
addappid(1253830)
