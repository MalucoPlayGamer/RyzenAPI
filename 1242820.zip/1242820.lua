-- Lua provided by RyzenAPI
-- Game: GirLand

-- MAIN APPLICATION
addappid(1242820)
addappid(1253020)
addappid(1253830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242821, 1, "342ae3f013c785b387bbd7fd0c5965d19937a6fdbacd39ea8e26d30916861120")
