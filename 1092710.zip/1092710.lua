-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Alpha 1

-- MAIN APPLICATION
addappid(1092710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092711, 1, "5a447c5bc21a35c496dd818694c926716a872438fc825c68b9f65015998ecde9")

