-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Alpha 1

-- MAIN APPLICATION
addappid(1092710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092711, 1, "5a447c5bc21a35c496dd818694c926716a872438fc825c68b9f65015998ecde9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
