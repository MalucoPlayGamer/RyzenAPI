-- Lua provided by RyzenAPI
-- Game: 1442010

-- MAIN APPLICATION
addappid(1442010)
-- Game: addappid(1442010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442010,0,"c45ab5aebafedf266b02dbb6e2ebef4438bf05b0d5f60d6a9bf2813a946a03b3")
