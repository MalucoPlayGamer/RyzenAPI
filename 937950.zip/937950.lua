-- Lua provided by RyzenAPI
-- Game: addappid(937950)

-- MAIN APPLICATION
addappid(937950)

-- MAIN APP DEPOTS / PACKAGES
addappid(937951, 1, "a179694e4fa13fbbbf512da0abb5a456b9841129445857b1ca97a2ddd92c2c6e")
