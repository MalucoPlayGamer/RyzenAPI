-- Lua provided by SkyAPI 
-- Game: AppID 696260
addappid(696260)
addappid(696261, 1, "67a0270fd098a22c84ff0a09f80f67c2011fee49edc7011faeaac50f05213f33")
addappid(696262, 1, "ea8f7d5cb21f9bbff9ba29da1f87e61bee0f93822acad275669199903f7b8298")
