-- Lua provided by RyzenAPI
-- Game: NASCAR '15 Victory Edition Demo

-- MAIN APPLICATION
addappid(228982)
addappid(228983)
addappid(228990)
addappid(348350)
addappid(348351)

-- MAIN APP DEPOTS / PACKAGES
addappid(345891,0,"e0b9b131238d4bfa0be4b4afdf98673713ed38205872322467afcc749ecca875")

