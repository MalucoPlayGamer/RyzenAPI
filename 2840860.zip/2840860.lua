-- Lua provided by SkyAPI 
-- Game: Bloom Thrice
addappid(2840860)
addappid(2840861, 1, "9bc99283ea638da7c5feb2799ad92b532aab96aa87dc3546c46543fad63133bb")
