-- Lua provided by RyzenAPI
-- Game: Bloom Thrice

-- MAIN APPLICATION
addappid(2840860)
-- Game: addappid(2840860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840861, 1, "9bc99283ea638da7c5feb2799ad92b532aab96aa87dc3546c46543fad63133bb")
