-- Lua provided by RyzenAPI
-- Game: addappid(3005610)

-- MAIN APPLICATION
addappid(3005610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005611, 1, "beeae485104ece806adfa6dd859088f4a8551d8971a12dcee4fd0dc79fd72447")
