-- Lua provided by RyzenAPI
-- Game: 2366850

-- MAIN APPLICATION
addappid(2366850)
-- Game: addappid(2366850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366851, 1, "dc56068ba70fcc724d4383eb7160871db6dc98b9b8d99c4216a28c3e07099f18")
