-- Lua provided by RyzenAPI 
-- Game: The Market of Light
addappid(1691400)
addappid(1691401, 1, "94fa773b7370bfa3b04bb4aeeedba4a3c5cfeb5aaffbea05b7a2c170d6d5c02d")
