-- Lua provided by RyzenAPI
-- Game: ArchWilio

-- MAIN APPLICATION
addappid(2923930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2923931, 1, "691a36f9d4dc6af81aed461105659397b73522dbc2a57058c713ee762173e054")

