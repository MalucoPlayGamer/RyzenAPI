-- Lua provided by RyzenAPI
-- Game: ArchWilio

-- MAIN APPLICATION
addappid(2923930)
-- Game: addappid(2923930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923931, 1, "691a36f9d4dc6af81aed461105659397b73522dbc2a57058c713ee762173e054")
