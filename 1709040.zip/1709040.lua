-- Lua provided by RyzenAPI
-- Game: 1709040

-- MAIN APPLICATION
addappid(1709040)
-- Game: addappid(1709040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709041, 1, "8076455a9ae2cfc12943ca7c69ac95ef01823c999168f8536fd7155f8a8bc9cb")
