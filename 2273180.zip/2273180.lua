-- Lua provided by RyzenAPI
-- Game: 鏖战三国

-- MAIN APPLICATION
addappid(2273180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(2273181, 1, "917b734b07520d336baf45e31fdc14479d13ddbb8479a2523f9525955d92822c")

