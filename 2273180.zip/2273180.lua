-- Lua provided by RyzenAPI
-- Game: Game: 鏖战三国

-- MAIN APPLICATION
addappid(2273180)
-- Game: addappid(2273180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273181, 1, "917b734b07520d336baf45e31fdc14479d13ddbb8479a2523f9525955d92822c")
