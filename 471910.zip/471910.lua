-- Lua provided by RyzenAPI
-- Game: AppID 471910

-- MAIN APPLICATION
addappid(471910)
addappid(630820)
-- Game: addappid(471910)

-- MAIN APP DEPOTS / PACKAGES
addappid(471911, 1, "4edb37dd570a0f4cfb89ce093f69de9d66650c715ab01f00af0ced34e1162888")
