-- Lua provided by RyzenAPI
-- Game: Penimorta

-- MAIN APPLICATION
addappid(1408100)
-- Game: addappid(1408100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408101, 1, "d6d801da572a73174c5c64c125d2d746455730aa2378dd91c011aa1d85b14b5f")
addappid(1408102, 1, "284f66282773caa3ba9dd58af045bd5cdcac36a2316c20c948580533706f04bb")
addappid(1408103, 1, "addee058b3ee7d70ea77995ada7590477bb7540be67511ef609572a97acfd326")
