-- Lua provided by RyzenAPI
-- Game: Sex Coach: Hot Yoga - Prologue

-- MAIN APPLICATION
addappid(2756830)
-- Game: addappid(2756830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756831, 1, "d4825a4af98de81a7e5aeb9eeb584c8fb333ebe5242c1813efcc1cf07f471d69")
