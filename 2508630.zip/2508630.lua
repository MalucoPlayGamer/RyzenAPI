-- Lua provided by RyzenAPI
-- Game: Space Girls

-- MAIN APPLICATION
addappid(2508630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508631, 1, "c905d2696e0a0fe78e821d3669a29a23b5b9eab6756dd4ef201d8b14c0256c59")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2616530)
