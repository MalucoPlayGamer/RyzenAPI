-- Lua provided by SkyAPI 
-- Game: AppID 2562550
addappid(2562550)
addappid(2562551, 1, "8ddabd031f9a4f8f613c48705dd932a9f96ff1152c78466322998e173abfa286")
addappid(2562552, 1, "ab96344d7a24e37bc4aec5e81723490ca0b9cf7671dcafa201eb9df04b8473b2")
