-- Lua provided by RyzenAPI
-- Game: Game: Wizard Prison

-- MAIN APPLICATION
addappid(948460)
-- Game: addappid(948460)

-- MAIN APP DEPOTS / PACKAGES
addappid(948461, 1, "e985cfac672e0c88bc355e0cf4b370199e6b5d5b00634f55132ca6461551539b")
