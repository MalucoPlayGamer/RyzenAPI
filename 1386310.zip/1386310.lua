-- Lua provided by SkyAPI 
-- Game: Airplane Racer 2021
addappid(1386310)
addappid(1386311, 1, "c60554ad1c3d5d028df70058ddb1793c7b0c40472a97bb3ef18466e102549b95")
