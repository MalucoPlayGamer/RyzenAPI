-- Lua provided by RyzenAPI
-- Game: Sphere - Flying Cities

-- MAIN APPLICATION
addappid(1273220)
-- Game: addappid(1273220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273221, 1, "f2aa4de19a6a5e455d0c10c0b74e7aa61c92142c3cef4bb3d3850353396d11c3")
addappid(1273222, 1, "fc99214da2749ec43a7c9e70a2262fa1cdf490e2d9ca8e75e16351734802e254")
addappid(1773940, 0, "674e75e2675fb3c9e1cacc7ec4eecdbd74742313e7f18bf8ab75925567cbeb23")
