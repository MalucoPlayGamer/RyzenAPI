-- Lua provided by RyzenAPI
-- Game: Love Colors: Paint with Friends

-- MAIN APPLICATION
addappid(1561060)
-- Game: addappid(1561060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561061, 1, "24e6586f8762f75747d7f60d261a8c5b743bc4cdf1e3282f5fedab28a213a6a7")
