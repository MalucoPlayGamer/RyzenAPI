-- Lua provided by RyzenAPI
-- Game: Love Colors: Paint with Friends

-- MAIN APPLICATION
addappid(1561060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561061, 1, "24e6586f8762f75747d7f60d261a8c5b743bc4cdf1e3282f5fedab28a213a6a7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1569300)
addappid(1569301)
addappid(1569304)
addappid(1946730)
addappid(1946731)
