-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Sun Shangxiang "Knight Costume" / 孫尚香「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019984)
-- Game: addappid(1019984)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019984,0,"71cc2cca2e915ef997fc6208616e1581beb973660553b8f940cf73bf9d136ee7")
