-- Lua provided by RyzenAPI
-- Game: JungleKnight

-- MAIN APPLICATION
addappid(1431770)
addappid(1440250)
-- Game: addappid(1431770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431771, 1, "05a6c2f7a46b31efa1d4417e345c46abc1687c01ada5591f895be0547f8912d4")
