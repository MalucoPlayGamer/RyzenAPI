-- Lua provided by RyzenAPI
-- Game: AppID 758980

-- MAIN APPLICATION
addappid(758980)
-- Game: addappid(758980)

-- MAIN APP DEPOTS / PACKAGES
addappid(758981, 1, "31a89b7f928b33a225536c6daed9f5b26b6611c09d79d4ab416ee049f5ee2814")
addappid(758982, 1, "15ac203503bbd6dea9b0afca2cbafaec9419543bcfbbe16f0912dd53a50b459d")
