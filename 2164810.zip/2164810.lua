-- Lua provided by RyzenAPI
-- Game: XYZ

-- MAIN APPLICATION
addappid(2164810)
-- Game: addappid(2164810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164811, 1, "7c8b70d3bffda610d4e4a64fc731e0e1e77cefc0edd34c3efeeee2c05edc5414")
