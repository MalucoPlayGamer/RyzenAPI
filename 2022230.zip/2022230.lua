-- Lua provided by RyzenAPI
-- Game: Game: Yomi 2

-- MAIN APPLICATION
addappid(2022230)
addappid(2801300)
-- Game: addappid(2022230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022231, 1, "3a087f4dae1221a5505e229e96108eae01d24f4e0c56e9d506e3d8ce788414b3")
