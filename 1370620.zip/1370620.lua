-- Lua provided by RyzenAPI
-- Game: Zodiac Girls

-- MAIN APPLICATION
addappid(1370620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370621, 1, "c79542921325dfecba698dea564baf1c72d99833cae6d19998bf0aba733b0029")
