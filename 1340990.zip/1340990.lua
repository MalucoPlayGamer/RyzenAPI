-- Lua provided by RyzenAPI
-- Game: Rise of the Ronin

-- MAIN APPLICATION
addappid(1340990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340991, 1, "6fdac6ccd9ebadf5c61e1c34ec225a8bc687cab591d28cc5ade262e9a65ae393")
addappid(1340992, 1, "7c7e86cec8a1f874213799a3eb2db858af7a8e28c72d7792330cc7b28f580793")
addappid(1340993, 1, "50234d9ac0cda0a23d385d3c086560656cc037de4dcb3d743e960f416ed5c69d")
addappid(1340994, 1, "747729b8ffcd2e18673252e55284cc050dbecbff88ab7ef91b69cd71d941084f")
addappid(1340995, 1, "e57b64d9b5f9e584a87a9832529c0e1f901f699e690b4b5637fec2b2e1fbf2aa")
addappid(1340996, 1, "2aca517d8dece95e0cbfce99e8e6b937dd56dee06fc84b510bcfe0fa09538d9d")
addappid(1340997, 1, "37138487eef65143ea189a388085037e84de8519cef8b35cf5486474b5df15d4")
addappid(1340998, 1, "7e685022588dcde7a3b5ee6627e0a250e8641a8bbd123bf7377b2e9e990c42fe")
addappid(1340999, 1, "bb4b2b9bca194610993a7f32ee52f074460b0d0b54fb37099580e2d512e35728")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3355660)
