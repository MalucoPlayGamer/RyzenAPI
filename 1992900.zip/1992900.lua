-- Lua provided by RyzenAPI
-- Game: Game: AppID 1992900

-- MAIN APPLICATION
addappid(1992900)
-- Game: addappid(1992900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992901, 1, "00e01fe29a371dbbf09ed89e63a551a6ed32e49bb7f1c2cb7335a3a92c1dcec9")
