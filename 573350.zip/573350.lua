-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(573350)

-- MAIN APP DEPOTS / PACKAGES
addappid(573350,0,"3224256c0ee945c5558c62535afa805507c54a00d1aa7663a4bab5caa1d9facb")

