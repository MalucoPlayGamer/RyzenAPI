-- Lua provided by RyzenAPI
-- Game: Markus Ritter - The Lost Family

-- MAIN APPLICATION
addappid(1644310)
-- Game: addappid(1644310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644311, 1, "ac6c21de30c986578fa8a7384e109e921fdb80f5dbb489669f1b0a85ca8305da")
addappid(1644312, 1, "9a007cbc2cde9e438705d83df576f0fc06ba0c04c418ebde5126dc373cfaad6b")
