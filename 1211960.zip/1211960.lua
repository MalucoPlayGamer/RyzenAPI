-- Lua provided by RyzenAPI 
-- Game: Food Girls - Bubbles' Drink Stand
addappid(1211960)
addappid(1211961, 1, "6599490f5c8d3e78f5275b1ffe8f3435d1f4e7af0f80aa9e2736b134d0638be8")
