-- Lua provided by RyzenAPI 
-- Game: NoRoY
addappid(1781500)
addappid(1781501, 1, "1c2fb47b06df65dc3b860e06d038dd3ae37071887751b4855b1aea4ba24bcf51")
