-- Lua provided by RyzenAPI
-- Game: NoRoY

-- MAIN APPLICATION
addappid(1781500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781501, 1, "1c2fb47b06df65dc3b860e06d038dd3ae37071887751b4855b1aea4ba24bcf51")
