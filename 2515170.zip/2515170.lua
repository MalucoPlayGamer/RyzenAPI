-- Lua provided by RyzenAPI
-- Game: Tavern Talk Demo

-- MAIN APPLICATION
addappid(2515170)
-- Game: addappid(2515170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515171, 1, "76bb426ab0937f849af37656432b1c3d3130d90a6dac44b26cb1d0e792d8025a")
