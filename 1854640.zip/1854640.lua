-- Lua provided by RyzenAPI
-- Game: Post-Apo Builder Demo

-- MAIN APPLICATION
addappid(1854640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854641, 1, "e849a4eac479fbe33539dbe8010828581ad322ab61ba464527067df2fcb5b06e")

