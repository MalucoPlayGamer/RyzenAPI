-- Lua provided by RyzenAPI
-- Game: addappid(2081230)

-- MAIN APPLICATION
addappid(2081230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081231, 1, "c27161a1d0ab3e7b35c3d9082fa0105e3b94c61c3dad0f20a118d8f4c231feef")
