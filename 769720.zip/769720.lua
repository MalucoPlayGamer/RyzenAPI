-- Lua provided by RyzenAPI
-- Game: Island of Deception

-- MAIN APPLICATION
addappid(769720)

-- MAIN APP DEPOTS / PACKAGES
addappid(769721, 1, "0c4130a7e64c1d025fb58d10c6b6285ff85fbc2b2c95c0c64ae18a05bad65e62")
