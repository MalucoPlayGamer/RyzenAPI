-- Lua provided by RyzenAPI
-- Game: Anime City

-- MAIN APPLICATION
addappid(2215410)
-- Game: addappid(2215410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215411, 1, "b090727fcb6bb092c00b7bc369fb46591475f68e015203840045f0838429c1e8")
