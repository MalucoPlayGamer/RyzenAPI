-- Lua provided by RyzenAPI
-- Game: Game: AppID 1058650

-- MAIN APPLICATION
addappid(1058650)
-- Game: addappid(1058650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058651, 1, "d57213f778b8eb41050e34ddb415d21d0d745a0288e6897e4f6eda04b6f358e8")
