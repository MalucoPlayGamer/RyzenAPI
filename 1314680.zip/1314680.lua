-- Lua provided by RyzenAPI
-- Game: Defensive Attacks

-- MAIN APPLICATION
addappid(1314680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314682,0,"a309657ffe3591e7f249cbf63570a98d14d37a640067d0824f2050ee99767a47")
