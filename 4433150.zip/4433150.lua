-- 4433150's Lua and Manifest Created by Hubcap Manifest
-- Idle Realms: The Eternal Spire
-- Created: June 26, 2026 at 06:24:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4433150) -- Idle Realms: The Eternal Spire
-- MAIN APP DEPOTS
addappid(4433151, 1, "e5bf7befbba29123fd13a44f1e64a07ce29e1505ab114f90d7a92585a6e93145") -- Depot 4433151
setManifestid(4433151, "9065094826481368507", 391515743)