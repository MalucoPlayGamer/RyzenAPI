-- Lua provided by RyzenAPI
-- Game: 1719630

-- MAIN APPLICATION
addappid(1719630)
-- Game: addappid(1719630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719631, 1, "b3b305cfe74b6a07b2d177a2fab0e416f8533d305ae878eb6b6bb728d52ad296")
