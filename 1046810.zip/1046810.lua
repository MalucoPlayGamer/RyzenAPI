-- Lua provided by RyzenAPI
-- Game: Hyperstacks Demo

-- MAIN APPLICATION
addappid(1046810)
-- Game: addappid(1046810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046811, 1, "d660d18e023b51b2bdd6b5e40b79dbebd91bbf1c7a5b38779796f225846b70c3")
