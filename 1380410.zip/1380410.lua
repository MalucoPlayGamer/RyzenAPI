-- Lua provided by RyzenAPI
-- Game: 1380410

-- MAIN APPLICATION
addappid(1380410)
-- Game: addappid(1380410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380411, 1, "967db68f67f40d3fedc4387f68ab16ee9af8fb74955d0a023e43cd7462a3b55d")
