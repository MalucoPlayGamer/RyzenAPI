-- Lua provided by RyzenAPI
-- Game: Game: AppID 2492260

-- MAIN APPLICATION
addappid(2492260)
-- Game: addappid(2492260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492261, 1, "5c030c62985b8de4849915cf76956578ccdf93396cc7539b5d241ff642607fab")
