-- Lua provided by RyzenAPI
-- Game: Hell's Gate - Slide Puzzle

-- MAIN APPLICATION
addappid(1561880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561881, 1, "ba2c5e7931737cd97cfab31a3dc52830838461a7d3e85b57957128ab25659352")
