-- Lua provided by RyzenAPI
-- Game: Game: AppID 1029470

-- MAIN APPLICATION
addappid(1029470)
-- Game: addappid(1029470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029471, 1, "9aa7d60f76a500e8d6dd4818300834bc0d313a25d2491870fa15230bde55e307")
