-- Lua provided by RyzenAPI
-- Game: Angry Farm

-- MAIN APPLICATION
addappid(1029470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1029471, 1, "9aa7d60f76a500e8d6dd4818300834bc0d313a25d2491870fa15230bde55e307")
