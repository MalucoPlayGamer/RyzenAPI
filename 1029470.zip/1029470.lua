-- Lua provided by RyzenAPI 
-- Game: AppID 1029470
addappid(1029470)
addappid(1029471, 1, "9aa7d60f76a500e8d6dd4818300834bc0d313a25d2491870fa15230bde55e307")
