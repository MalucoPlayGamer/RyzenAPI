-- Lua provided by RyzenAPI
-- Game: AppID 1164010

-- MAIN APPLICATION
addappid(1164010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164011, 1, "79b12f756a1088428ce436e2fdad5fb718800920bfebe1de58db10b8d16c5026")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
