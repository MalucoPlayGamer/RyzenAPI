-- Lua provided by RyzenAPI
-- Game: Game: AppID 1164010

-- MAIN APPLICATION
addappid(1164010)
-- Game: addappid(1164010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164011, 1, "79b12f756a1088428ce436e2fdad5fb718800920bfebe1de58db10b8d16c5026")
