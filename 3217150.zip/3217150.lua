-- Lua provided by RyzenAPI
-- Game: Japanese Psycho

-- MAIN APPLICATION
addappid(3217150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3217151, 1, "6085470cc525b3b40aaa9bf075dbf18e272194539d6a383785a24cca8cfdf3d0")

