-- Lua provided by RyzenAPI
-- Game: Game: Vietnam War Platoon Demo

-- MAIN APPLICATION
addappid(1392950)
-- Game: addappid(1392950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392951, 1, "172694687aa09d7486c8a9abe599b8805e9b2ba6956be0d0bd2a3e7af6165096")
