-- Lua provided by RyzenAPI
-- Game: 1106860

-- MAIN APPLICATION
addappid(1106860)
-- Game: addappid(1106860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106861, 1, "e6d0bb39fc6c297eaf42f40caa2374bd2f16604a4161acc97cc27fda96bcb88a")
addappid(1106862, 1, "a9bb3ca35d23433f9f37c790de57d3ad1d09adef607bdbc8ca6f68cb4ef423e2")
