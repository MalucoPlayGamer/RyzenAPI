-- Lua provided by RyzenAPI
-- Game: M.A.C.E.

-- MAIN APPLICATION
addappid(555280)

-- MAIN APP DEPOTS / PACKAGES
addappid(555281, 1, "3332fd97b4996134c78adb0d70ac2bc57358e7a7f65802fc4a517c1a4ac6fbaf")
