-- Lua provided by RyzenAPI
-- Game: 1213320

-- MAIN APPLICATION
addappid(1213320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213320,0,"26b2a3c4af16c16dd46915a0d3ab4d2fed06dab58352d94ccd23b229af691f75")
