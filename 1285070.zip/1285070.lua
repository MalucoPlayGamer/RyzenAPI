-- Lua provided by RyzenAPI
-- Game: Bad Run - Turbo Edition

-- MAIN APPLICATION
addappid(1285070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285072,0,"f3fd89f376d74425f99fb40c5006a095fbc72e59546d1641473040e16f6b1192")
addappid(1285073,0,"b2552d494aafeaf3a1f131ebc28685a569ffa884d21f69032aafdb212a651fc4")
addappid(1285076,0,"8284dbc45640e52ac0c470c2bc4f864a0c46a1db4e45c9f798a27043c3aa4933")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
