-- Lua provided by RyzenAPI
-- Game: Masterplan Tycoon

-- MAIN APPLICATION
addappid(1644500)
-- Game: addappid(1644500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644501, 1, "0d31ee13f45f3b293549a0ed9ad1733dba3d4b76d9b3e4e5a1639a16dc7693fa")
addappid(1644502, 1, "ea617cf00f1e3054e94ab7438472e15c1e92483b2c861a3aadff9e1fef031d48")
addappid(1644503, 1, "1dd243543456cbfe105c011d8863bb1718ff4b13062185dacce56445fc489348")
