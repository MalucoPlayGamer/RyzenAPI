-- Lua provided by RyzenAPI
-- Game: Adapt or Perish

-- MAIN APPLICATION
addappid(870730)

-- MAIN APP DEPOTS / PACKAGES
addappid(870731, 1, "253c74f048c02baacad634000be8f67e4669aef6a03aba8208317d1d0956a6c4")
addappid(870732, 1, "6ee988909ab382c869671abf5d99b3e9cb706eb52931e3b7de346b204f14b568")

