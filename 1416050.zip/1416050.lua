-- Lua provided by RyzenAPI
-- Game: addappid(1416050)

-- MAIN APPLICATION
addappid(1416050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416052,0,"e08c8ef3509406337f1cca1b38b73c68fcadc8f88db5600f4c9e521c3e13fd80")
