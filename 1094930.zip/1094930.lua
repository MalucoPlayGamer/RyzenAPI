-- Lua provided by RyzenAPI
-- Game: Ninja Girl and the Mysterious Army of Urban Legend Monsters! ~Hunt of the Headless Horseman~

-- MAIN APPLICATION
addappid(1094930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094931, 1, "a6a2258d50424802a7c11f92224cf976e3b1f63c0b3498cebc5184a264c3fa61")

