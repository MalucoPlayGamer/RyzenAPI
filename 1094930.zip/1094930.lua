-- Lua provided by RyzenAPI
-- Game: addappid(1094930)

-- MAIN APPLICATION
addappid(1094930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094931, 1, "a6a2258d50424802a7c11f92224cf976e3b1f63c0b3498cebc5184a264c3fa61")
