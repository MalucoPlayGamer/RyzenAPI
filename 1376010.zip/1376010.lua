-- Lua provided by RyzenAPI
-- Game: addappid(1376010)

-- MAIN APPLICATION
addappid(1376010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376011, 1, "7ecdd0e767a6c510fdf7c6c6279bb1cba0285ec7e85eb3daf9acbe9df7371a92")
