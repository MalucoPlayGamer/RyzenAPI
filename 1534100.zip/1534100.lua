-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1534100)
addappid(1534101)
-- Game: addappid(1534100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534100,0,"a68da8cab9aa73059da1f27a70dc3367f5359e094bae927032a5c3c228465bd3")
