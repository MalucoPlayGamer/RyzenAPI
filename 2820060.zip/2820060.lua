-- Lua provided by RyzenAPI
-- Game: Preface: Undiscovered World

-- MAIN APPLICATION
addappid(2820060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820061, 1, "07c2e104d589fbf7424703bd7b0aaacd59ebf09384957eb7b951b3bb84b5f252")

