-- Lua provided by RyzenAPI
-- Game: Preface: Undiscovered World

-- MAIN APPLICATION
addappid(2820060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820061, 1, "07c2e104d589fbf7424703bd7b0aaacd59ebf09384957eb7b951b3bb84b5f252")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
