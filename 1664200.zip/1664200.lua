-- Lua provided by RyzenAPI
-- Game: Duelists of Eden

-- MAIN APPLICATION
addappid(1664200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664201, 1, "7434874be8446c990f6cd305ad2632218a35fdc9f3325eee46f962875f7554ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
