-- Lua provided by RyzenAPI
-- Game: Flashover MegaSector

-- MAIN APPLICATION
addappid(1197380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197381, 1, "7206bc0c31f0c66b24a50fcb055265ddcec3e53e4fe49bbd02f80a12decaf89e")

