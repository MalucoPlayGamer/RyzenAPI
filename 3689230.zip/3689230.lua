-- Lua provided by RyzenAPI
-- Game: RimWorld - Odyssey Soundtrack

-- MAIN APPLICATION
addappid(3689230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689232,0,"d2065f031bd1063e01ca219492a7d5f8b260e7a1226642e6b01d1b2deef236a4")
addappid(3689233,0,"543d8b2ff4a6035f1d57db63a8c6720ff5c6c1312e3762f46d7177a1d3cef7b0")
