-- Lua provided by RyzenAPI
-- Game: Qbike: Cyberpunk Motorcycles Demo

-- MAIN APPLICATION
addappid(653150)

-- MAIN APP DEPOTS / PACKAGES
addappid(653151, 1, "e7eaf86339a3dad0c0afe84899dfe402c567623849cca7d02e7e4f26d40f4e05")
