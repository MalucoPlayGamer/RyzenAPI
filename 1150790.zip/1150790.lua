-- Lua provided by RyzenAPI
-- Game: Game: AppID 1150790

-- MAIN APPLICATION
addappid(1150790)
-- Game: addappid(1150790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150791, 1, "a38b9d3d967461bf75c1f663d8f711dec858a84a831f38968c2dcf3facf41666")
