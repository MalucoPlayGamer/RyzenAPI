-- Lua provided by RyzenAPI
-- Game: Hentai Tales: C-D Girls

-- MAIN APPLICATION
addappid(3561560)
-- Game: addappid(3561560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561561, 1, "e2de701abdd7834be75417741ca5ec426218bf90213d618be007434d84c718c7")
