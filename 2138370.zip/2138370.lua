-- Lua provided by RyzenAPI
-- Game: No King No Kingdom - Soul Reaper

-- MAIN APPLICATION
addappid(2138370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138370,0,"93d95f0c970407b4d0661e7db332083184d641ce06087df36c71295d548cfd26")

