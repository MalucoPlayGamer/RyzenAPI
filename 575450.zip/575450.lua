-- Lua provided by RyzenAPI
-- Game: Graceful Explosion Machine

-- MAIN APPLICATION
addappid(575450)

-- MAIN APP DEPOTS / PACKAGES
addappid(575451,0,"d92a963a944f4a7ff708935bf87f1afdf28bee5d3e17e97571ed96574b4e216e")

