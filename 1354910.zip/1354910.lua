-- Lua provided by RyzenAPI
-- Game: Game: AppID 1354910

-- MAIN APPLICATION
addappid(1354910)
-- Game: addappid(1354910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354911, 1, "9c4dcc59ded7d3340461f4cc7a19cff6fe24312e23123271bec0697fc4141708")
addappid(2211350, 0, "2e09884ab191eaaa9123d19f744e756fe5ba3e1531424279435f52b4fcfdc098")
addappid(2624900, 0, "68fa09f0efc8ee86d155cbbb3e3cb6f3399aef7127cb0ee4bf3836039eb44711")
addappid(2766000, 0, "91bb0e801bc3bd5eb72b9ef526e4a4e66797c6813a16ddff029ae2a62a8e4cc3")
addappid(3280160, 0, "2290806051013357c66bdd2fe6c1f4d70cacd924fbb7b6fdae7b05bdcf0bd59c")
