-- Lua provided by RyzenAPI 
-- Game: AppID 385830
addappid(385830)
addappid(385831, 1, "f14af985d220746dc2019a386d0d04435bbaf8159016e44a8eda5d706cf37ee1")
addappid(385832, 1, "6d99718e7bcb24cf009a43379efd1ba24e1dd7173008e156163240bf8795b41f")
