-- Lua provided by RyzenAPI
-- Game: 100 Aliens Cats

-- MAIN APPLICATION
addappid(2845270)
addappid(3032290)
addappid(3032300)

