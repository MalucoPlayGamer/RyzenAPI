-- Lua provided by RyzenAPI
-- Game: 100 Aliens Cats

-- MAIN APPLICATION
addappid(2845270)

