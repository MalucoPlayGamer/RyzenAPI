-- Lua provided by RyzenAPI
-- Game: Loot Hero DX - Original Soundtrack

-- MAIN APPLICATION
addappid(385670)

-- MAIN APP DEPOTS / PACKAGES
addappid(385670,0,"693399382e1ab2c178b868b5f6d9874be84d15b623a0006438daa7a0b961f094")

