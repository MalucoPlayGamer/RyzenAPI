-- Lua provided by RyzenAPI
-- Game: Ori and the Blind Forest: Definitive Edition

-- MAIN APPLICATION
addappid(387290)

-- MAIN APP DEPOTS / PACKAGES
addappid(387291, 1, "e3379e56401649f05bf54aa6ef2b7e61b9603a14484529d84daa9f07ba0b24c5")

