-- Lua provided by RyzenAPI
-- Game: ColorCube

-- MAIN APPLICATION
addappid(2066920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2066921, 1, "fe25f39c03b5c5c400d47f85fdbbb68f4821287bb2542e3a45e6cae544c9e6b8")
addappid(2066922, 1, "d9ce05487ea609d17d94ed16e99218ee4bc9dc1fdf73a28f0257849669ab19bd")
addappid(2066923, 1, "0f03073c942dd647d252e67ad8fca5c6f8b26425885ffa4c58b4ebc0ca6b0f42")

