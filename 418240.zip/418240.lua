-- Lua provided by RyzenAPI
-- Game: Shadow Tactics: Blades of the Shogun

-- MAIN APPLICATION
addappid(418240)

-- MAIN APP DEPOTS / PACKAGES
addappid(418241, 1, "bc6e3364822ad085b434526e174c29109f24727a8124482bb3ea51079df05c88")
addappid(418242, 1, "b5152de5ee2a33021c0a6c7a574cbe85cb917620b0b36417949a109b6b13ce52")
addappid(418243, 1, "b06c4cbd46046e40525aa7dd67eaef2c9b90cb9f7a0cbd937b17bc59129bb7ef")
addappid(571410, 0, "48d1c280167cf7b6ecafbd8948ed10a9adc6916df70c86ce2b269388b2d83a5b")
