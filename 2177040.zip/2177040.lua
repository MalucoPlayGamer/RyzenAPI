-- Lua provided by RyzenAPI
-- Game: Temple of Kasthet

-- MAIN APPLICATION
addappid(2177040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177041, 1, "e014865e53f170cf61159f00586fc931edc828c7954dfd455ea11efb5e321bf4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
