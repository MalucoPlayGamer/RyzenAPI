-- Lua provided by RyzenAPI
-- Game: Temple of Kasthet

-- MAIN APPLICATION
addappid(2177040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177041, 1, "e014865e53f170cf61159f00586fc931edc828c7954dfd455ea11efb5e321bf4")

