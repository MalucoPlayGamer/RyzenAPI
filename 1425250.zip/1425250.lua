-- Lua provided by RyzenAPI
-- Game: addappid(1425250)

-- MAIN APPLICATION
addappid(1425250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425251, 1, "71fc6a888384d5a49544ba32c1e6788fd33c4a9a0c3c770d4cc7947104e7d3be")
