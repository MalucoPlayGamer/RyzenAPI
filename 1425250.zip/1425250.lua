-- Lua provided by RyzenAPI
-- Game: Gravity Field

-- MAIN APPLICATION
addappid(1425250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425251, 1, "71fc6a888384d5a49544ba32c1e6788fd33c4a9a0c3c770d4cc7947104e7d3be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
