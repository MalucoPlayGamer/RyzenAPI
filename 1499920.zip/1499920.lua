-- Lua provided by RyzenAPI
-- Game: Pixel Piano

-- MAIN APPLICATION
addappid(1499920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499921, 1, "06ec161a45a0ed8202b4567e08118af4d7bc9241ce9e5b7e41a27bc6d7951d3f")
