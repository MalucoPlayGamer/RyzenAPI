-- Lua provided by RyzenAPI
-- Game: Figure Skating Legends

-- MAIN APPLICATION
addappid(3357130)
addappid(5076040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3357131, 1, "d71e71173fe98c896b91995c6d8965d9b6370f71471bd9af83f404aabe2123e6")

