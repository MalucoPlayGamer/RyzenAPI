-- Lua provided by RyzenAPI
-- Game: 3Cushion Masters

-- MAIN APPLICATION
addappid(1657880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657882,0,"96a239b8851d13bd4c44842a37ae0c8820c3ce53c0e12d38e66ec0d45609fc74")

