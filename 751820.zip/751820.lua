-- Lua provided by RyzenAPI
-- Game: Game: Black Future '88

-- MAIN APPLICATION
addappid(751820)
-- Game: addappid(751820)

-- MAIN APP DEPOTS / PACKAGES
addappid(751821, 1, "6cc425a5651ebdca7d291aa983ac42c85e02cc66335c2483b65ae9ed28a08af4")
addappid(1195600, 0, "d417367f6d95fbbbb589f15377f32a95f61505e6b1b2329dfd139df85035518a")
