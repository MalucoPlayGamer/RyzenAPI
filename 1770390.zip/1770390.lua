-- Lua provided by RyzenAPI 
-- Game: Bound by Love
addappid(1770390)
addappid(1770391, 1, "a81fbfae6d3e2b28a74fa8a5d21521ee19c315365354abe6acc15d4c44fdfe94")
addappid(1770392, 1, "5a6b522169b08aedbbbef1cee107ea5cf0dbafb0c1e529918c1a03fa1838e46d")
addappid(1770393, 1, "a87f28c2d6f14efe452467bce5ecc23e1356f52b94ffe787432e4828ebf63bcb")
