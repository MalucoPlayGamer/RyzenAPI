-- Lua provided by RyzenAPI 
-- Game: 决奕Duel
addappid(1433460)
addappid(1433461, 1, "d8460ca36aff09dda1c4318466fdff01c2bf563b7709495735b077e0b93dd23a")
