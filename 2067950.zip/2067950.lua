-- Lua provided by RyzenAPI 
-- Game: Nash Racing 3: Drifter
addappid(2067950)
addappid(2067951, 1, "b076525a9b5a4f836e13c0eb66819d6113831a608db3394f028ddce9f03317b9")
