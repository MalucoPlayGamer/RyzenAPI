-- Lua provided by RyzenAPI
-- Game: My Furry Dragon - 18+ Adult Only Patch 🐾

-- MAIN APPLICATION
addappid(1820970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820970,0,"37c588de28c1e588e7ffd8fdf7389a8ad7500c53014ec9da41c9b7378cff75d4")

