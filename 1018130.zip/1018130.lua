-- Lua provided by SkyAPI 
-- Game: AppID 1018130
addappid(1018130)
addappid(1018131, 1, "3d807fec10c026b5eb69a453116df0a35fba5625196991c4bff1eed57772b2c7")
