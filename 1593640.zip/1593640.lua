-- Lua provided by RyzenAPI
-- Game: AppID 1593640

-- MAIN APPLICATION
addappid(1593640)
-- Game: addappid(1593640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593641, 1, "172dd74ccfc617885a2dbd6d207225caab8bbd94c240a178ceae848898018b7c")
