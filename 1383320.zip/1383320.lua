-- Lua provided by RyzenAPI
-- Game: addappid(1383320)

-- MAIN APPLICATION
addappid(1383320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383321, 1, "e5cbaf2d90ddbe5640aebf23a65e8d856fb510797d0ac63ae5fd66502cefac0c")
