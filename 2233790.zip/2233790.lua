-- Lua provided by RyzenAPI
-- Game: Game: Legendary Creatures 2

-- MAIN APPLICATION
addappid(2233790)
-- Game: addappid(2233790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233791, 1, "a73f04117f2d65e7bc48afb32614780ad2e92c0f1f3379d842e86941ff613947")
