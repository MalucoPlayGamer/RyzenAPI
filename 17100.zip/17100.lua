-- Lua provided by RyzenAPI
-- Game: Children of the Nile: Enhanced Edition

-- MAIN APPLICATION
addappid(17100)

-- MAIN APP DEPOTS / PACKAGES
addappid(17101, 1, "804974cd13666e5367b37c960e2c252e0c956587eaeec4fabd1ac0ca0a7e09c1")
addappid(17102, 1, "b14a3da2ba3b6ec0a9b231295f81cfcac450e026cbc95ecf29ce77d17a677fb9")
addappid(17103, 1, "73725601e73af78b51eea4cfd81ed80e96aa8b9a1a565fe786720e5cd1eb9ef0")
addappid(17104, 1, "f5104da6f5d11780c6ff3fe9bd41707c9be5558f26554a6447fdd345b01e615b")
addappid(17105, 1, "d0f708f47265c82b8f36d35ceab87343ab51d06c7534027f1a33c8f1ea23e604")
addappid(17106, 1, "95efaf755b9ec0e8eba2bfa7919d5c4a41c9c3446aef9d3751b9efbd5be3c127")
