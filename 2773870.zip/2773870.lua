-- Lua provided by RyzenAPI
-- Game: Game: FREAKHUNTER

-- MAIN APPLICATION
addappid(2773870)
-- Game: addappid(2773870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773871, 1, "d29c8dc7505f4c334592e1336821035b797e7b14f09ccd6f3ec6c94c2c552c9d")
