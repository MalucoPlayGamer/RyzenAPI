-- Lua provided by RyzenAPI
-- Game: AppID 2653200

-- MAIN APPLICATION
addappid(2653200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653201, 1, "da1db9e05668a1f0561da029cf11f512b9e03da1ad5224b8bf9ba66ff43def5d")

