-- Lua provided by RyzenAPI
-- Game: Game: Project DeepWeb: Original Soundtrack

-- MAIN APPLICATION
addappid(1251660)
-- Game: addappid(1251660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251661, 1, "b319f4bcb8e3e5e03323c2bb6f6a5140793224918af80caa96c2febd2f012d92")
