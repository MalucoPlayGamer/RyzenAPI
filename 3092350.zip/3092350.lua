-- Lua provided by RyzenAPI
-- Game: Aerial Cleaner Demo

-- MAIN APPLICATION
addappid(3092350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092351, 1, "1b81ce35e18971502930d38a950c955ff2853e69ec758c52f09983e46485739e")

