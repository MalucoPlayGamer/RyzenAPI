-- Lua provided by SkyAPI 
-- Game: Celestian Tales: Realms Beyond
addappid(684700)
addappid(684701, 1, "4fcd80e3e793c68381b04926560bf4dd02cc7b0f025e72e1b71b01d601f9a5ea")
