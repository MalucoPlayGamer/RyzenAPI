-- Lua provided by SkyAPI 
-- Game: AppID 663060
addappid(663060)
addappid(663061, 1, "098cec661fa0cf3e1999fdb34c7197aed3b1b10ad23e58aa4da3660d49db30fe")
