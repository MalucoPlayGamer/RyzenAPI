-- Lua provided by RyzenAPI
-- Game: addappid(663060)

-- MAIN APPLICATION
addappid(663060)

-- MAIN APP DEPOTS / PACKAGES
addappid(663061, 1, "098cec661fa0cf3e1999fdb34c7197aed3b1b10ad23e58aa4da3660d49db30fe")
