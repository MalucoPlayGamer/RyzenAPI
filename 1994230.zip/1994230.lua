-- Lua provided by RyzenAPI
-- Game: Almost Home Now

-- MAIN APPLICATION
addappid(1994230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994231, 1, "bfcd8db9d61f90067cdbcb6b85f55f79783d0a376faa6557e8bf9caab1de8302")
addappid(1994232, 1, "d18db78f32f7c3f3308cc910d22f5b1cbfc9d0b1284fa195be3182c84e19d5c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
