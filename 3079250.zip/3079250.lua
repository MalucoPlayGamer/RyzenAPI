-- Lua provided by RyzenAPI
-- Game: Captain Blood Demo

-- MAIN APPLICATION
addappid(3079250)
-- Game: addappid(3079250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079251, 1, "8e67ba9b8827a6dd80dbdd9a68f6f106d8ead78847c3512ea2b76ca11a4ce3f9")
