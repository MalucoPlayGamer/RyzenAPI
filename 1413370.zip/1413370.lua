-- Lua provided by RyzenAPI
-- Game: Power to the People

-- MAIN APPLICATION
addappid(1413370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413371, 1, "2c681a141435ca1dc47a21866bbac2debeab4a72456a57e402673d312d5fbe0d")

