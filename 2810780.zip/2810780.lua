-- Lua provided by RyzenAPI
-- Game: Forsaken Frontiers

-- MAIN APPLICATION
addappid(2810780)
-- Game: addappid(2810780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810781, 1, "5c491e275fbeb58082e8e36b6f5b5dbb5e1195ad33b2eb9b09cdfebfa878055d")
