-- Lua provided by RyzenAPI
-- Game: Leaf's Odyssey

-- MAIN APPLICATION
addappid(2880750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880751,0,"ae8386e383ec76ca2838b86bc23025db3d08518d34aad1a5209f1de50fb2dc11")
