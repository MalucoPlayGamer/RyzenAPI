-- Lua provided by RyzenAPI
-- Game: Game: AppID 1077410

-- MAIN APPLICATION
addappid(1077410)
-- Game: addappid(1077410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077411, 1, "d419d202f572ed89e84f4ca500e63a39d08749758d5856a32887148faf8fd219")
