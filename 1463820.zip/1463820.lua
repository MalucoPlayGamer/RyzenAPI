-- Lua provided by RyzenAPI
-- Game: Zball VI

-- MAIN APPLICATION
addappid(1463820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463821, 1, "6d6b0667a31adcf20aa18e56526326c2b89fb23a88e4b2e415b527a6a4d2204c")

