-- Lua provided by RyzenAPI
-- Game: addappid(2022470)

-- MAIN APPLICATION
addappid(2022470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022471, 1, "cc5f26e46ff51b01e2abe364cca51d3f8b096d16b8e3d8c90af4fb6c8c3e74d7")
