-- Lua provided by RyzenAPI
-- Game: Game: AppID 817120

-- MAIN APPLICATION
addappid(817120)
-- Game: addappid(817120)

-- MAIN APP DEPOTS / PACKAGES
addappid(817121, 1, "a6bc43a1d2821320121051f8944199f9a72894d3f768a1d04a62ff83ac31f3fe")
