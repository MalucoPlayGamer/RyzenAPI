-- Lua provided by RyzenAPI
-- Game: addappid(767560)

-- MAIN APPLICATION
addappid(767560)

-- MAIN APP DEPOTS / PACKAGES
addappid(767561, 1, "bb79a2cf61943a54f704be20c5f046d14b12de3456b3ee9e374b384d6f69868c")
