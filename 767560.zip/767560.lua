-- Lua provided by RyzenAPI
-- Game: War Robots

-- MAIN APPLICATION
addappid(767560)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(767561, 1, "bb79a2cf61943a54f704be20c5f046d14b12de3456b3ee9e374b384d6f69868c")

