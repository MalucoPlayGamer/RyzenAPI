-- Lua provided by RyzenAPI
-- Game: 1830780

-- MAIN APPLICATION
addappid(1830780)
-- Game: addappid(1830780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830781, 1, "40a3c68a844974a7828431bfbd5e95e95a87887654bc3dfeadd635245b9618ca")
