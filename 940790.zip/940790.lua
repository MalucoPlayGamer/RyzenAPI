-- Lua provided by RyzenAPI 
-- Game: AppID 940790
addappid(940790)
addappid(940791, 1, "7d3c23afef87ea5efd446ab0869de0a11141f265329f2e00bd53fd4104c9544c")
addappid(940794, 1, "8e2402498597d3993028fd1a58a6f24b4a1106d2b23b9d3aa3b0192b24f3973c")
