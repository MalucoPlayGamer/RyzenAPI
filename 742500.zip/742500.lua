-- Lua provided by RyzenAPI
-- Game: Nonogram - Master's Legacy

-- MAIN APPLICATION
addappid(742500)
