-- Lua provided by RyzenAPI
-- Game: Nonogram - Master's Legacy

-- MAIN APPLICATION
addappid(742500)
addappid(957760)
addappid(957761)
addappid(957762)

