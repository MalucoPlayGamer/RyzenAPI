-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 10

-- MAIN APPLICATION
addappid(2216830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216831, 1, "7746df12b2bd4b831d8cb37e93f32255bd4f7eb1f5cf7120cda16756f44665c6")
addappid(2216832, 1, "3930e7ee91cb86c07d98b372bf5c7cd2c25f4410ff8c0d03af1b32ad71b7ea0e")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
