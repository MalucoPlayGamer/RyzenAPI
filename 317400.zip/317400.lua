-- Lua provided by RyzenAPI
-- Game: Portal Stories: Mel

-- MAIN APPLICATION
addappid(317400)
-- Game: addappid(317400)

-- MAIN APP DEPOTS / PACKAGES
addappid(317401, 1, "6eb241df0f12ab55e23c9953fe3d0bb2a02e5c3cd8d4dfa66b83a8a52bc4c323")
addappid(317402, 1, "c6de4e5fb768e8335bf40d39f6fbeb73ae55413d8c76c621ca4b8da46dd215ec")
addappid(317403, 1, "bbdb81eac96c2357a8e47fd919ec25e19c8b7c35264d1ac35f85165b9d02d811")
addappid(317404, 1, "fddd56c07bc0626b092f56c8c3112382469f0b49e7ff782c3ede06e3bde1bd4e")
addappid(317405, 1, "ceb59b564b1256b88199f5fcf1abd8c3166259fdde0acbf2b4882127de3fc24b")
