-- Lua provided by RyzenAPI
-- Game: Dive The Depths

-- MAIN APPLICATION
addappid(2751120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751121, 1, "bafc96481750cd869a372984adf2fb42c5efab8ba21b3e5b677068f2e270712b")

