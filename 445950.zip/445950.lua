-- Lua provided by RyzenAPI 
-- Game: Asher
addappid(445950)
addappid(445951, 1, "a2f3e071d3353d6991d897e811864fbacdfd8aad5b4cb0a7a78e55cdaa871c17")
