-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2129770)
-- Game: addappid(2129770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129770,0,"29f114cd1c9ede4ce7eb10579c52a45cc506c4c7e685955d063ed1da0ab6172c")
