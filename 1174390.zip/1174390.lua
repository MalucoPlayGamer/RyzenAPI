-- Lua provided by RyzenAPI
-- Game: ANNIE:Last Hope

-- MAIN APPLICATION
addappid(1174390)
-- Game: addappid(1174390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174391, 1, "86b21b32156d251857600edbc4a8d93934a027bdd2e6c7e1684c9941d5173c1f")
