-- Lua provided by RyzenAPI
-- Game: Wordle - Deutsche

-- MAIN APPLICATION
addappid(1532570)
-- Game: addappid(1532570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532570,0,"0e45babfbcecc34680ca41530a4560ecd6404ded90dfd005162d8529d3521463")
