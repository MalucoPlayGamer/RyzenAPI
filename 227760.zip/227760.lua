-- Lua provided by SkyAPI 
-- Game: March of the Eagles
addappid(227760)
addappid(227761, 1, "bdf4349c262683f4d4069ab443d6b4bfbbf3ffb151ac36b107e1399c6b2caced")
addappid(228983)
addappid(228990)
addappid(229001)
addappid(254290, 0, "eabbdc0779e473de9ff33707284158974209d980c74831ccc9f92bdea5b4f75e")
addappid(254291, 0, "b0c8ccfa299c11fae943089c8ebfa5bac1853278cc34d29ce7d04e41ed48aed4")
