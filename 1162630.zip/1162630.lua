-- Lua provided by RyzenAPI 
-- Game: Solitaire Call of Honor
addappid(1162630)
addappid(1162631, 1, "6c7be5ad9ebdd22419d26dfa11543415f219a8f1924b29dd1af35233b0573250")
addappid(1162637, 1, "33bedf3f27f464724b967282d3f0b7a47b6a1307bf513da4d976f8d779574726")
