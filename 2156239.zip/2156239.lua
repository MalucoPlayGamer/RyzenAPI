-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - "Far East Travelers" Costume Set

-- MAIN APPLICATION
addappid(2156239)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156239,0,"093e023a0da9e4078a0570794a04fd5c9cb9ac23e0d57a0dfdc128588c2f924b")

