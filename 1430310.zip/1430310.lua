-- Lua provided by RyzenAPI
-- Game: NetGunner

-- MAIN APPLICATION
addappid(1430310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1430311, 1, "654bca0c20c7b0d9135726b656b805cc1f8a09de42f18b2454382a256105f25f")

