-- Lua provided by SkyAPI 
-- Game: NetGunner
addappid(1430310)
addappid(1430311, 1, "654bca0c20c7b0d9135726b656b805cc1f8a09de42f18b2454382a256105f25f")
