-- Lua provided by RyzenAPI
-- Game: Gori: Cuddly Carnage - Neon Neko Skin Pack

-- MAIN APPLICATION
addappid(3035200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035200,0,"484d0739d9ad890e1380ea5efcd32fe49a3339f4844f61baac1cd53f05069253")

