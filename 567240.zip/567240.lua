-- Lua provided by RyzenAPI
-- Game: Drawn™: Trail of Shadows Collector's Edition

-- MAIN APPLICATION
addappid(567240)

-- MAIN APP DEPOTS / PACKAGES
addappid(567241, 1, "47530ec95d8ef9a5a723f479d42081443290e5680fe3cad00194d3addcee28a6")
