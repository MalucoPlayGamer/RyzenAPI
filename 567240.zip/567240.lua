-- Lua provided by RyzenAPI 
-- Game: AppID 567240
addappid(567240)
addappid(567241, 1, "47530ec95d8ef9a5a723f479d42081443290e5680fe3cad00194d3addcee28a6")
