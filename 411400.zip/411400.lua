-- Lua provided by RyzenAPI
-- Game: Sora no Kakera - Sora Original Soundtrack

-- MAIN APPLICATION
addappid(411400)

-- MAIN APP DEPOTS / PACKAGES
addappid(411400,0,"44b5f73a59e9a97e2f466f0739711f9905f8615ac7d9a95127d92ecea4d87091")

