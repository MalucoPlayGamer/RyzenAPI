-- Lua provided by RyzenAPI
-- Game: Game: Hundreds of Mysteries:Wendy's Home2

-- MAIN APPLICATION
addappid(1579800)
-- Game: addappid(1579800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579801, 1, "8eccb9994425fa45f8ec016a0487c87fb3997d63ca02e741bd73f7025aefe829")
