-- Lua provided by RyzenAPI
-- Game: Hundreds of Mysteries:Wendy's Home2

-- MAIN APPLICATION
addappid(1579800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579801, 1, "8eccb9994425fa45f8ec016a0487c87fb3997d63ca02e741bd73f7025aefe829")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
