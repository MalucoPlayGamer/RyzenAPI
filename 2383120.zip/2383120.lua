-- Lua provided by RyzenAPI
-- Game: Garten of Banban 4

-- MAIN APPLICATION
addappid(2383120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2383121, 1, "e5ce386f54709b7e33215805a1b22a97032b067c23133059ccbbd37d7dae1463")

