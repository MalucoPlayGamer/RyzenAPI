-- Lua provided by RyzenAPI
-- Game: Garten of Banban 4

-- MAIN APPLICATION
addappid(2383120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383121, 1, "e5ce386f54709b7e33215805a1b22a97032b067c23133059ccbbd37d7dae1463")
