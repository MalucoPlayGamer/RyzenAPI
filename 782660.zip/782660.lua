-- Lua provided by RyzenAPI
-- Game: Game: Modern Tanks: War Tank Games

-- MAIN APPLICATION
addappid(782660)
-- Game: addappid(782660)

-- MAIN APP DEPOTS / PACKAGES
addappid(782661, 1, "3645c420a6fa94dfcf347c93d047c0a830a55f930e961e0afd1672334d68e9a5")
addappid(782662, 1, "808e9267b50636b9ac5397cf077731f1b6983e77ab368ab4bc55030eb6785046")
addappid(782663, 1, "6114dc99b12024f10d827f8398adc06cf15a5958a3310c7ef02651f7d33a2100")
