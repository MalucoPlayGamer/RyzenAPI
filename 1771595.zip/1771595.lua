-- Lua provided by RyzenAPI
-- Game: FUSER™ - Megan Thee Stallion - "Savage"

-- MAIN APPLICATION
addappid(1771595)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771595,0,"e4433e4b0dd2156045607435c08eccb1e979b1c4324dde61a7018f4564ed3876")

