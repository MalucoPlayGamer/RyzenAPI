-- 1222540's Lua and Manifest Created by Hubcap Manifest
-- Gastova: The Witches of Arkana
-- Created: July 07, 2026 at 00:14:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1222540, 1, "81a11cd354c9ce3bcf9f8ea1162215277a6027387f971e07c548c22198300e07") -- Gastova: The Witches of Arkana
-- MAIN APP DEPOTS
addappid(1222541, 1, "bdc361f5338dd6f74035061895f7be30da9a303d9b7f91b763d5359da1def501") -- Depot 1222541
setManifestid(1222541, "7713102936733009337", 4153076819)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2224100) -- Gastova The Witches of Arkana - Festive Witch Costume