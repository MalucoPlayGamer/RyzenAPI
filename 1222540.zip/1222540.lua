-- Lua provided by RyzenAPI
-- Game: Gastova: The Witches of Arkana

-- MAIN APPLICATION
addappid(2224100) -- Gastova The Witches of Arkana - Festive Witch Costume

-- MAIN APP DEPOTS / PACKAGES
addappid(1222540, 1, "81a11cd354c9ce3bcf9f8ea1162215277a6027387f971e07c548c22198300e07") -- Gastova: The Witches of Arkana
addappid(1222541, 1, "bdc361f5338dd6f74035061895f7be30da9a303d9b7f91b763d5359da1def501") -- Depot 1222541

