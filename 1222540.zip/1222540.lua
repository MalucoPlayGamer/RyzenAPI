-- Lua provided by RyzenAPI
-- Game: addappid(1222540)

-- MAIN APPLICATION
addappid(1222540)
addappid(2224100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222541, 1, "bdc361f5338dd6f74035061895f7be30da9a303d9b7f91b763d5359da1def501")
