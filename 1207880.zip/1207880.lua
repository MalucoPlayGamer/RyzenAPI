-- Lua provided by RyzenAPI
-- Game: Nasty Rogue

-- MAIN APPLICATION
addappid(1207880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207881, 1, "356ea029af090481e2d71acdb0904ede3787cb34b9924df237fc545e72810f79")
