-- Lua provided by RyzenAPI
-- Game: Game: AppID 2658570

-- MAIN APPLICATION
addappid(2658570)
-- Game: addappid(2658570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658571, 1, "319b1fa9b70c3fe8702db717ce428b44aaab0e739b566edaee410a2f0c476816")
