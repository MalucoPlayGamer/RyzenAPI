-- Lua provided by SkyAPI 
-- Game: AppID 511820
addappid(511820)
addappid(511821, 1, "5cf7477b6b3808d12b344651810ce5b7e388fc02ce18afa68a62dcbdd2b1c023")
addappid(511822, 1, "32aeb7fd82b14937073c08dbf4f7bf2103beeff1787fea3f74b0d8899f0f3d44")
addappid(511823, 1, "e8a884a0fe506cea15cf01a33efea6ccfaa3c91503c0658b785c909d00d1ba8a")
addappid(511824, 1, "400069beb158a6bdd8bed40c43ff8d98dc8135d4a2553d5bdd4a988373c44cee")
