-- Lua provided by RyzenAPI
-- Game: The Mors

-- MAIN APPLICATION
addappid(378240)
-- Game: addappid(378240)

-- MAIN APP DEPOTS / PACKAGES
addappid(378241, 1, "0a0711dab14c20ee698bcc19d1602cda866c98fd4df63098b5f2051bd87dc412")
