-- Lua provided by RyzenAPI
-- Game: AppID 736930

-- MAIN APPLICATION
addappid(736930)

-- MAIN APP DEPOTS / PACKAGES
addappid(736931, 1, "9ffab4509aad03c34fc419a84cacf355c0f8688057e766a8ddc70f0ef2bcac75")
