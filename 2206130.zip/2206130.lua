-- Lua provided by RyzenAPI
-- Game: Tomb 盜墓

-- MAIN APPLICATION
addappid(2206130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206131, 1, "181f0eb16378ead181cb84428c53326ad71029c55f97777fa87cb4f7eae54030")

