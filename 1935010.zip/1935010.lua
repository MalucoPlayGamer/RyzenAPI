-- Lua provided by RyzenAPI
-- Game: 修仙立志传 demo

-- MAIN APPLICATION
addappid(1935010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935011, 1, "5f069e1c1cc557d3b688153ac137dadecb6e15292e46060d6cd4f84b5e887575")
