-- Lua provided by RyzenAPI
-- Game: SUMMER VACATION

-- MAIN APPLICATION
addappid(658360)
-- Game: addappid(658360)

-- MAIN APP DEPOTS / PACKAGES
addappid(658361, 1, "1f0deec5b051eff7afcf85d2b351e078805e1a291585d1f26bc704851cbf8ea0")
