-- Lua provided by RyzenAPI 
-- Game: SUMMER VACATION
addappid(658360)
addappid(658361, 1, "1f0deec5b051eff7afcf85d2b351e078805e1a291585d1f26bc704851cbf8ea0")
