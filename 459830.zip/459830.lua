-- Lua provided by RyzenAPI
-- Game: AppID 459830

-- MAIN APPLICATION
addappid(459830)

-- MAIN APP DEPOTS / PACKAGES
addappid(459831, 1, "7ed13ab22d574191bf8fd2f560cf9bc3ac12ef70f7d26821be4349bff82dd2cf")
