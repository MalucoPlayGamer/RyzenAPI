-- Lua provided by RyzenAPI
-- Game: AppID 459830

-- MAIN APPLICATION
addappid(459830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(459831, 1, "7ed13ab22d574191bf8fd2f560cf9bc3ac12ef70f7d26821be4349bff82dd2cf")

