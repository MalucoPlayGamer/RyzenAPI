-- Lua provided by RyzenAPI
-- Game: o jogo

-- MAIN APPLICATION
addappid(1771300) -- o jogo
addappid(3118100) -- Kingdom Come: Deliverance II The Lion's Crest
addappid(3118110) -- Kingdom Come: Deliverance II Gallant Huntsman's Kit		
addappid(3118120) -- Kingdom Come: Deliverance II Shields of Seasons Passing		
addappid(3119920) -- Kingdom Come: Deliverance II Expansion Pass		
addappid(3368600) -- Kingdom Come: Deliverance II Brushes with Death		
addappid(3368610) -- Kingdom Come: Deliverance II Legacy of the Forge		

-- MAIN APP DEPOTS / PACKAGES
addappid(1771302,0,"41bc41c39ce79db318e98b533bab1fe71bfd294c4e8c90f90e4f8efa5fcc2a91")
addappid(1771303,0,"397ab2e5c59bbb75f716c30dba3374be8af7ff49a2fc45c621e0bc23bafbd5f3")
addappid(1771305,0,"66d5a42e0171363eac9b79352c78401952d616880979d26967c385d2d7a88368")
addappid(1771306,0,"120aed0e767afa1ac85539240704d613b82c13473fcd7136d3cea555a784783e")
addappid(1771307,0,"8d47328b0b82d9b9ba25bfb199c69ea2dd005954298bd2aff2b448321569b727")
addappid(1771308,0,"b457fdf0e78f3465b9ccbfed5f8ecbb85f22428ba321534ee0df4a0d08754d02")
addappid(1771309,0,"1f8b55f9f4ac27eac8ffa310ca46163ee5aaad0937438035274a30b78de4e81a")
addappid(3118101,0,"69d3aecd16754fea50cf46182e56be5d29647e571e45c1dd1ef3294b966d0ee4")
