-- Lua provided by RyzenAPI
-- Game: Game: Hotel R'n'R

-- MAIN APPLICATION
addappid(1011290)
-- Game: addappid(1011290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011291, 1, "8318d1a044abfc1b8d9784ae66d50ac0c3f57ac1ae4f5d3c04dba2b0f90215d6")
