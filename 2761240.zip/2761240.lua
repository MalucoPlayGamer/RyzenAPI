-- Lua provided by RyzenAPI 
-- Game: Presidents Tower Defense
addappid(2761240)
addappid(2761241, 1, "7e05da6c51c7c26862abf1bb5110aaf7157354bbecf5234e864f20208117aac4")
