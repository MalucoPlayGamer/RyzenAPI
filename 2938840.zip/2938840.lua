-- Lua provided by RyzenAPI
-- Game: The Trials 2

-- MAIN APPLICATION
addappid(2938840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938841, 1, "229843cece7a85db788e327d22bb64990aee90d8e6481ead524dc24714477f4a")

