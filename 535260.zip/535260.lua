-- Lua provided by RyzenAPI
-- Game: Save Home

-- MAIN APPLICATION
addappid(535260)

-- MAIN APP DEPOTS / PACKAGES
addappid(535261, 1, "3f9a528212327c26c92266391d2a446c9fc9bc29c80364aadc286244b5ed8184")
