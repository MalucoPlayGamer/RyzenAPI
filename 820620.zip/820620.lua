-- Lua provided by RyzenAPI
-- Game: 820620

-- MAIN APPLICATION
addappid(820620)
addappid(907910)
-- Game: addappid(820620)

-- MAIN APP DEPOTS / PACKAGES
addappid(820621, 1, "3d105e216c8465607e245e05afc8123647d44b5859834ad8bf33d5197934a63f")
