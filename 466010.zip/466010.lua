-- Lua provided by RyzenAPI
-- Game: 466010

-- MAIN APPLICATION
addappid(466010)
-- Game: addappid(466010)

-- MAIN APP DEPOTS / PACKAGES
addappid(466011, 1, "3a662fb24b5f68d36eed71623d8b709920fc5af5f15e22485d4a289ee45866f1")
