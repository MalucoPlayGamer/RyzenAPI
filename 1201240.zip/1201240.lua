-- Lua provided by RyzenAPI
-- Game: Game: AppID 1201240

-- MAIN APPLICATION
addappid(1201240)
-- Game: addappid(1201240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201241, 1, "85566eaa31209ac31dde217a058f58e810356a8df255c9a7c4c8b31749858248")
