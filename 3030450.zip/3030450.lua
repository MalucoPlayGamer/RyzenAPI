-- Lua provided by SkyAPI 
-- Game: TRIP Demo
addappid(3030450)
addappid(3030451, 1, "542c6247bc48e4a77d6bc9a3b9b14ee8ee6623c275c5c3823c22c9c9d4997b0c")
