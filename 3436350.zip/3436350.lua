-- Lua provided by RyzenAPI
-- Game: Naked Interrogation Simulator

-- MAIN APPLICATION
addappid(3436350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3436351, 1, "f49c0a2507ef9d1a2eee120fd4c36ed1723d7e2abdc4122a99cc6b576c93a44d") -- Depot 3436351

