-- Lua provided by RyzenAPI
-- Game: Beta City

-- MAIN APPLICATION
addappid(3723050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723051,0,"7007ca701b5a52e41f1cfcfdfe03a1d2e996d1f4859c4a612c5835843f0db181")

