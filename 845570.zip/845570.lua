-- Lua provided by RyzenAPI
-- Game: Super Punchman

-- MAIN APPLICATION
addappid(845570)

-- MAIN APP DEPOTS / PACKAGES
addappid(845571, 1, "ca7b29ce06d55b5e61baa5bd68b873b4f20e9b21a106a8ed79c9e1d6adb7d5c8")
addappid(845572, 1, "0f147a7a6dbb660f2b6540e63ddd30467c92cd6897708f8c0b34d086fef77224")
addappid(845573, 1, "2a30bc42414b589c830b0f78fe4f9347c61bf1365e302b83b015a6d1430387aa")

