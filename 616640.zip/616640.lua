-- Lua provided by RyzenAPI
-- Game: B-12

-- MAIN APPLICATION
addappid(616640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(616641, 1, "e3356e87af4e79a06cab4edcaac5e09c80f38b5a40eab601b62754dc055bceb6")

