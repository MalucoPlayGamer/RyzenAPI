-- Lua provided by SkyAPI 
-- Game: B-12
addappid(616640)
addappid(616641, 1, "e3356e87af4e79a06cab4edcaac5e09c80f38b5a40eab601b62754dc055bceb6")
