-- Lua provided by RyzenAPI
-- Game: Game: B-12

-- MAIN APPLICATION
addappid(616640)
-- Game: addappid(616640)

-- MAIN APP DEPOTS / PACKAGES
addappid(616641, 1, "e3356e87af4e79a06cab4edcaac5e09c80f38b5a40eab601b62754dc055bceb6")
