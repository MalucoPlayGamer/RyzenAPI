-- Lua provided by RyzenAPI
-- Game: AppID 3642660

-- MAIN APPLICATION
addappid(3642660)
-- Game: addappid(3642660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642661, 1, "4e2739abdeb536043a485a41acae223171275afc10be59a1ac0ffa0331053cd5")
