-- Lua provided by RyzenAPI
-- Game: Fear the Timeloop - Prologue

-- MAIN APPLICATION
addappid(3642660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3642661, 1, "4e2739abdeb536043a485a41acae223171275afc10be59a1ac0ffa0331053cd5")

