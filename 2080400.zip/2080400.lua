-- Lua provided by RyzenAPI
-- Game: Asterigos Demo

-- MAIN APPLICATION
addappid(2080400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080401, 1, "27122f81aa7a2062a1c680305fa698a5e80eac1489123df54e840b580e4bcf00")

