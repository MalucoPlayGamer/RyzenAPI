-- Lua provided by RyzenAPI
-- Game: Task Force Elite

-- MAIN APPLICATION
addappid(1148810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148811, 1, "c4afd75d1718585ae25a3e8dea9be5c2552c1a1e1fdfc5f54735d37aded07033")

