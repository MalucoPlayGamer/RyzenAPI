-- Lua provided by SkyAPI 
-- Game: Task Force Elite
addappid(1148810)
addappid(1148811, 1, "c4afd75d1718585ae25a3e8dea9be5c2552c1a1e1fdfc5f54735d37aded07033")
