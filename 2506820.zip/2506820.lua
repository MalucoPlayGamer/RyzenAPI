-- Lua provided by RyzenAPI
-- Game: Demonsomnia

-- MAIN APPLICATION
addappid(2506820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506821, 1, "2f2daf07139bc44cbeff503028757514b2f4a12af0ef010cfddbbbb9342b7a7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
