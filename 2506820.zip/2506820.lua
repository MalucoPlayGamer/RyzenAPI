-- Lua provided by RyzenAPI
-- Game: 2506820

-- MAIN APPLICATION
addappid(2506820)
-- Game: addappid(2506820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506821, 1, "2f2daf07139bc44cbeff503028757514b2f4a12af0ef010cfddbbbb9342b7a7c")
