-- Lua provided by RyzenAPI
-- Game: Orange Cast: Sci-Fi Space Action Game

-- MAIN APPLICATION
addappid(1194050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194052,0,"07604b8cced739bfc651a5618ee06fd6877a65960ed0f9eb5ccef29b0463e17c")

