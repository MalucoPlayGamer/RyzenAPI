-- Lua provided by RyzenAPI
-- Game: 1194050

-- MAIN APPLICATION
addappid(1194050)
-- Game: addappid(1194050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194052,0,"07604b8cced739bfc651a5618ee06fd6877a65960ed0f9eb5ccef29b0463e17c")
