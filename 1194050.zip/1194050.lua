-- Lua provided by RyzenAPI
-- Game: Orange Cast: Sci-Fi Space Action Game

-- MAIN APPLICATION
addappid(1194050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194052,0,"07604b8cced739bfc651a5618ee06fd6877a65960ed0f9eb5ccef29b0463e17c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
