-- Lua provided by RyzenAPI
-- Game: Recursive Ruin Demo

-- MAIN APPLICATION
addappid(1872560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872561, 1, "609040264f1358bcca9f69069ed8da0d51b688b25e3a43427b7f176c5f17ce6c")

