-- Lua provided by RyzenAPI
-- Game: 1754440

-- MAIN APPLICATION
addappid(1754440)
-- Game: addappid(1754440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754441, 1, "3702368aceaf38355d3e73c3a72c5eba22688ebea79cd4250ae0e29c708d6e0f")
