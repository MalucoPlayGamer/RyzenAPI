-- Lua provided by RyzenAPI
-- Game: Teeto Demo

-- MAIN APPLICATION
addappid(2953830)
-- Game: addappid(2953830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2953831, 1, "b77605bf35b78a04c08e6c1ffb2b6a346f9259370774e0141c37b24041756bb5")
