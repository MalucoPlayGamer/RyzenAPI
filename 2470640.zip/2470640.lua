-- Lua provided by RyzenAPI
-- Game: Just Xiangqi Demo

-- MAIN APPLICATION
addappid(2470640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470641, 1, "f4ca43e00aa257b863d1f52aa6ad55f70afa33b5dafa937c7cb9f0c096ad8cd6")

