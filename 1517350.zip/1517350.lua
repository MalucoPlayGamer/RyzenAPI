-- Lua provided by RyzenAPI
-- Game: Hidden Memory - Neko's Life

-- MAIN APPLICATION
addappid(1517350)
addappid(1556330)
-- Game: addappid(1517350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517351, 1, "9a459e8b49f8791421bcfc3ae079afbe5c869a3d425363f6387c77dbf7e064cd")
