-- Lua provided by RyzenAPI
-- Game: El Dorado: The Golden City Builder

-- MAIN APPLICATION
addappid(1451470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451471, 1, "290c3aadb074debca467a37342cc0a2cda582f653ad5f3b8932ef442452038eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
