-- Lua provided by RyzenAPI
-- Game: addappid(1451470)

-- MAIN APPLICATION
addappid(1451470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451471, 1, "290c3aadb074debca467a37342cc0a2cda582f653ad5f3b8932ef442452038eb")
