-- Lua provided by RyzenAPI
-- Game: Kogarashi

-- MAIN APPLICATION
addappid(2010170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2010171, 1, "eabc855bb135fc9f5c22f90e3a416b5a0c59188e0af0da58faf8686fcf395aed")

