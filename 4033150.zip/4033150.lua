-- Lua provided by RyzenAPI
-- Game: Moka Love Relive♪

-- MAIN APPLICATION
addappid(4033150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4033151,0,"fe31ea59809a1f1ee69c84de51b8b8d8a291bc222b12293b98407991fa4e30bf")

