-- Lua provided by RyzenAPI
-- Game: VHS Collection: Goodnight Me

-- MAIN APPLICATION
addappid(3162060)
-- Game: addappid(3162060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162061, 1, "ba4a1dc596737701b736f625ced93c50c8d54d091a7d6c3112c31e62ab687988")
