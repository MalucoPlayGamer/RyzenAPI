-- Lua provided by RyzenAPI
-- Game: We Went Back

-- MAIN APPLICATION
addappid(1218250)
-- Game: addappid(1218250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218251, 1, "e85b84f21cd18fedf4964ba9850ce11d2cdcf7d45e313f02a4e5b35547ea5b49")
