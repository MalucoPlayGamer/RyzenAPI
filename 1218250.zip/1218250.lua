-- Lua provided by RyzenAPI 
-- Game: We Went Back
addappid(1218250)
addappid(1218251, 1, "e85b84f21cd18fedf4964ba9850ce11d2cdcf7d45e313f02a4e5b35547ea5b49")
