-- Lua provided by RyzenAPI
-- Game: Star Wars: Droid Repair Bay

-- MAIN APPLICATION
addappid(726910)

-- MAIN APP DEPOTS / PACKAGES
addappid(726912,0,"c358cca76728591d8407ea6d3e8287086ce27d70864a2a23ece0552bc57e2227")

