-- Lua provided by RyzenAPI
-- Game: addappid(942430)

-- MAIN APPLICATION
addappid(942430)

-- MAIN APP DEPOTS / PACKAGES
addappid(942431, 1, "4aac3051231cfa7ecb44eb142469b0953945fad8ff68be89cd26476d11d379a1")
