-- Lua provided by RyzenAPI
-- Game: Pluralys Playtest

-- MAIN APPLICATION
addappid(3493020)
-- Game: addappid(3493020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3493021, 1, "ca52c012739324869dbb62833d6cc9016d5164bdf05ddbc3b228d30e9e718acc")
addappid(3493022, 1, "248133bad9170ea1945105ceac3144a456ff3be4e113835b09be018fc08224e9")
