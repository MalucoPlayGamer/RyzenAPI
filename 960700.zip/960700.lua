-- Lua provided by SkyAPI 
-- Game: AppID 960700
addappid(960700)
addappid(960701, 1, "9068cca44588ca102283824c3857a6a270cf190e579d661ae389624b27b316e1")
