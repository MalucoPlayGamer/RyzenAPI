-- Lua provided by RyzenAPI
-- Game: Game: The Scorchfarer

-- MAIN APPLICATION
addappid(1617580)
addappid(3078750)
-- Game: addappid(1617580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617581, 1, "68352b37a86705e89202ff2360a00fb3dc9a09e64e74cf2b2398aaaceec42f85")
