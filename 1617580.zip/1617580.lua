-- Lua provided by RyzenAPI
-- Game: The Scorchfarer

-- MAIN APPLICATION
addappid(1617580)
addappid(3078750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617581, 1, "68352b37a86705e89202ff2360a00fb3dc9a09e64e74cf2b2398aaaceec42f85")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1959290)
