-- Lua provided by RyzenAPI
-- Game: 3162540

-- MAIN APPLICATION
addappid(3162540)
-- Game: addappid(3162540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162541, 1, "06f488a1af71f6abbb4d342f3ee0781d49f35b050326cbf0c575181b7ab79869")
