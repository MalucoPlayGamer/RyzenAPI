-- Lua provided by RyzenAPI
-- Game: 2167840

-- MAIN APPLICATION
addappid(2167840)
-- Game: addappid(2167840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167841, 1, "f8d0a75403c4fcda50bc3fb73f4570fd734251929b2ad791b375ac6f52ab8c97")
