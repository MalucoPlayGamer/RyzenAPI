-- Lua provided by RyzenAPI
-- Game: The Last Plague: Blight

-- MAIN APPLICATION
addappid(1564600)
-- Game: addappid(1564600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564602,0,"1da35cc535878c4b14d381335faeb900987cb61ad57e9db8c3a649ed028c722c")
