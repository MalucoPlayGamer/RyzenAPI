-- Lua provided by RyzenAPI
-- Game: Game: AppID 878570

-- MAIN APPLICATION
addappid(878570)
-- Game: addappid(878570)

-- MAIN APP DEPOTS / PACKAGES
addappid(878571, 1, "582bcdf2ebe3a6d821b167f3c0af35e2ee6fc163f944e605dadfb3c04885e2af")
