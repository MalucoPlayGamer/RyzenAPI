-- Lua provided by RyzenAPI
-- Game: addappid(2526380)

-- MAIN APPLICATION
addappid(2526380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526381, 1, "7a98b3fe6647f782a34d95e43d2742ce77442a744e56273385fadb74832ddbc4")
