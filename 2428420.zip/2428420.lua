-- Lua provided by RyzenAPI
-- Game: Game: Umbraclaw

-- MAIN APPLICATION
addappid(2428420)
-- Game: addappid(2428420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428421, 1, "e4d8889b4407f1f7047b22017062396bfae8465f6bd0fb1f3d64fa2d2dc4d3f9")
