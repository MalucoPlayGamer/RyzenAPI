-- Lua provided by RyzenAPI
-- Game: 1660430

-- MAIN APPLICATION
addappid(1660430)
-- Game: addappid(1660430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660431, 1, "6f4c45ec8f3cb6155d1573f2fb82fab6d1b47c36c888e04d961d2313df19490f")
