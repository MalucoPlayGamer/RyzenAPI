-- Lua provided by RyzenAPI
-- Game: Game: Lost Between the Lines

-- MAIN APPLICATION
addappid(2175490)
-- Game: addappid(2175490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175491, 1, "6fb88349d36efcbd0fc2d15ce385ecc919aa85be1be3f02876ccc7021888845e")
