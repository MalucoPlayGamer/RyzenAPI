-- Lua provided by RyzenAPI
-- Game: Apex Ascent

-- MAIN APPLICATION
addappid(3720670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720671, 1, "44ffa07200f9d96952cbdeb3dd7a3857d746d4d8f0225368260e1caa962d6145")

