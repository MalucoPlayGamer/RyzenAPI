-- Lua provided by RyzenAPI
-- Game: Tour de France 2025

-- MAIN APPLICATION
addappid(2511320)
addappid(3481250)
addappid(3481260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2511321, 1, "84c2bbcc1b6d67b4578837cd1f0de82a11df5d39dc81c4fb85fdf10a0d532955")

