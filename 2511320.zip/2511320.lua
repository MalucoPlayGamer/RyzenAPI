-- Lua provided by RyzenAPI
-- Game: addappid(2511320)

-- MAIN APPLICATION
addappid(2511320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511321, 1, "84c2bbcc1b6d67b4578837cd1f0de82a11df5d39dc81c4fb85fdf10a0d532955")
