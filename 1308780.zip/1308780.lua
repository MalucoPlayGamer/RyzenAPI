-- Lua provided by RyzenAPI
-- Game: The Medic

-- MAIN APPLICATION
addappid(1308780)
-- Game: addappid(1308780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308781, 1, "6763570251c876c2f320fddbd00511955802b7849d4877b281f19301b5daaa2d")
