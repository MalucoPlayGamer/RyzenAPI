-- Lua provided by RyzenAPI
-- Game: Star Haul Tycoon

-- MAIN APPLICATION
addappid(3568280) -- Star Haul Tycoon

-- MAIN APP DEPOTS / PACKAGES
addappid(3568281, 1, "5e5fafbf7578c424a83bb4620dbc1ecc7cd31ac40dc03befaf289d72ee051e7b") -- Depot 3568281
addappid(3568282, 1, "aaf74dbf25ee1d6b0faa1c818ed1bc5bdb0d0cf713de8ad5691a0bbe06d6d556") -- Depot 3568282
addappid(3568283, 1, "863be28d4d6a9efd13e04d83592f6f9330036602bf53efdaa734f1d851eb9a7e") -- Depot 3568283

