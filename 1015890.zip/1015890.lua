-- Lua provided by RyzenAPI 
-- Game: TASOMACHI: Behind the Twilight
addappid(1015890)
addappid(1015891, 1, "c6ed3387da7eb1382bcdd1a37ffd58238f97c3c39b7effbbbbb661f6a348bc4c")
