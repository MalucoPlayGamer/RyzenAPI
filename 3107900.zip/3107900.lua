-- Lua provided by RyzenAPI
-- Game: Game: Liminalcore

-- MAIN APPLICATION
addappid(3107900)
-- Game: addappid(3107900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107901, 1, "e0723f8c9636b7d5f93aec64c72a517a59620110fc343891aa0e6f1ae5c1d7fa")
