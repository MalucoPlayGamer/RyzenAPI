-- Lua provided by RyzenAPI
-- Game: Liminalcore

-- MAIN APPLICATION
addappid(3107900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107901, 1, "e0723f8c9636b7d5f93aec64c72a517a59620110fc343891aa0e6f1ae5c1d7fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
