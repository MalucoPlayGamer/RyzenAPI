-- Lua provided by RyzenAPI 
-- Game: NEKO-NIN exHeart SPIN!
addappid(2995390)
addappid(2995391, 1, "174d087b65d14a03946c97300fcc8efe3b0af8d09e9bf2afe55f2a72b18ebfe0")
addappid(3111540, 0, "23c4eee936e0cb691a2873d4f94a3643e26ce500425d1af16a1db08c9b69254f")
