-- Lua provided by RyzenAPI
-- Game: FUSER™ - Disclosure ft. Sam Smith - "Latch"

-- MAIN APPLICATION
addappid(1588963)
-- Game: addappid(1588963)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588963,0,"069573a3627cf8c8bf79a50c8040195cd2192851320a574921e5f310cf5f82b6")
