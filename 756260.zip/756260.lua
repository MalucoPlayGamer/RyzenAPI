-- Lua provided by SkyAPI 
-- Game: Kingdom Defense
addappid(756260)
addappid(756261, 1, "e0b1296e68e2393debc0dd3b585da15b55ed71a7b2c88383a080988c89519d1e")
addappid(756262, 1, "43a6fee407257e4e80e800ecdd231dfd313ab1d4bd6dd7313f6be85be1411476")
addappid(756263, 1, "2c640e553ce6365e464009d934ed48fba9510cc0415ca47f56e9c1eb35bbe159")
