-- Lua provided by RyzenAPI
-- Game: MARVEL Puzzle Quest

-- MAIN APPLICATION
addappid(234330)
-- Game: addappid(234330)

-- MAIN APP DEPOTS / PACKAGES
addappid(234331, 1, "aa9b7126d3542d957b7283d01b2e78bd79885efe608f9dd560a4078992e8d7c9")
