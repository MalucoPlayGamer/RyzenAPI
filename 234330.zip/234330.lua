-- Lua provided by RyzenAPI
-- Game: MARVEL Puzzle Quest

-- MAIN APPLICATION
addappid(234330)

-- MAIN APP DEPOTS / PACKAGES
addappid(234331, 1, "aa9b7126d3542d957b7283d01b2e78bd79885efe608f9dd560a4078992e8d7c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(265130)
addappid(265131)
addappid(265132)
addappid(1450690)
