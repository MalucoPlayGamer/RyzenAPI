-- Lua provided by RyzenAPI
-- Game: 3385370

-- MAIN APPLICATION
addappid(3385370)
-- Game: addappid(3385370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385371, 1, "2d56e4408892643e0fa5d463e4da28628df9877ddb33e890d8d89d95ad673b39")
