-- Lua provided by SkyAPI 
-- Game: Maze Mice
addappid(3385370)
addappid(3385371, 1, "2d56e4408892643e0fa5d463e4da28628df9877ddb33e890d8d89d95ad673b39")
