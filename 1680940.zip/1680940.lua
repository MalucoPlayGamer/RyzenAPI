-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Wizards Pack (8 Elements)

-- MAIN APPLICATION
addappid(1680940)
-- Game: addappid(1680940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680940,0,"a8c5d03e9a4b1d63dae15c459148cbc7910bf5a60090698f26bdc8cb54bc4f2b")
