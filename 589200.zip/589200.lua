-- Lua provided by RyzenAPI
-- Game: Dreadhalls

-- MAIN APPLICATION
addappid(589200)
-- Game: addappid(589200)

-- MAIN APP DEPOTS / PACKAGES
addappid(589201, 1, "35d56212bd2308034e8b936567d38a216b5179605b2b5b6e0977c353c73c8919")
