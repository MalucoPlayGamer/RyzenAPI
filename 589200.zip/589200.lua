-- Lua provided by SkyAPI 
-- Game: Dreadhalls
addappid(589200)
addappid(589201, 1, "35d56212bd2308034e8b936567d38a216b5179605b2b5b6e0977c353c73c8919")
