-- Lua provided by RyzenAPI
-- Game: 2273550

-- MAIN APPLICATION
addappid(2273550)
-- Game: addappid(2273550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273551, 1, "53fec8b25ef213705891526e31b789cefc6b3f03ccf5e23fb52b6fb2d15cf63d")
