-- Lua provided by RyzenAPI 
-- Game: Postmouse
addappid(2273550)
addappid(2273551, 1, "53fec8b25ef213705891526e31b789cefc6b3f03ccf5e23fb52b6fb2d15cf63d")
