-- Lua provided by RyzenAPI
-- Game: The War Enders: First Strike

-- MAIN APPLICATION
addappid(1555800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555801, 1, "c3c1a57e2d4a9aab14b28a92d89e523aad712c3e2b3a203e6d28e841442b8de7")

