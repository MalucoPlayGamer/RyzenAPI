-- Lua provided by RyzenAPI
-- Game: Dreadnought

-- MAIN APPLICATION
addappid(835860)
addappid(916771)
addappid(916772)
addappid(931980)
addappid(949110)
addappid(1384810)
addappid(1741750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(835861,0,"544817a95cf708f26dcef7ad2f1eb843ea4e14b94847c9e15726ea90b820fea6")
addappid(858300,0,"cd2f16184a9bffb7bea1213ba1926aa2157f33c0a7a6e88b4d45c187b505dda8")
addappid(931800,0,"96a03619fdd4f985eab464cc115d84984a542f7592b46e269ad1cdbc7b3dc284")

