-- Lua provided by RyzenAPI
-- Game: Dreadnought

-- MAIN APPLICATION
addappid(835860)
addappid(916771)
addappid(916772)
addappid(931980)
addappid(949110)
addappid(1384810)
addappid(1741750)

-- MAIN APP DEPOTS / PACKAGES
addappid(835861,0,"544817a95cf708f26dcef7ad2f1eb843ea4e14b94847c9e15726ea90b820fea6")
addappid(858300,0,"cd2f16184a9bffb7bea1213ba1926aa2157f33c0a7a6e88b4d45c187b505dda8")
addappid(931800,0,"96a03619fdd4f985eab464cc115d84984a542f7592b46e269ad1cdbc7b3dc284")

