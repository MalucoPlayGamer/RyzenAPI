-- Lua provided by RyzenAPI
-- Game: Game: Dreadnought

-- MAIN APPLICATION
addappid(835860)
addappid(916770)
-- Game: addappid(835860)

-- MAIN APP DEPOTS / PACKAGES
addappid(835861, 1, "544817a95cf708f26dcef7ad2f1eb843ea4e14b94847c9e15726ea90b820fea6")
