-- Lua provided by RyzenAPI
-- Game: Postal 2 Editor

-- MAIN APPLICATION
addappid(298860)
-- Game: addappid(298860)

-- MAIN APP DEPOTS / PACKAGES
addappid(298861, 1, "619b5f579189300bbb5d1a05547bd645fc4852df6eed3ae860a1144a415ca99c")
addappid(298862, 1, "0bbf6019ee00ed850fd115981806bc5ea049276688c9f59af17de038220d2ddc")
