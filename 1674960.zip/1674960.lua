-- Lua provided by RyzenAPI
-- Game: addappid(1674960)

-- MAIN APPLICATION
addappid(1674960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674961, 1, "a0972a676eb229af1d74206819e7e79c1af181e7503f9cb08e357a49e463d33a")
