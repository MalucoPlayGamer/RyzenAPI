-- Lua provided by SkyAPI 
-- Game: Marble Parkour 2: Roll and roll
addappid(1674960)
addappid(1674961, 1, "a0972a676eb229af1d74206819e7e79c1af181e7503f9cb08e357a49e463d33a")
