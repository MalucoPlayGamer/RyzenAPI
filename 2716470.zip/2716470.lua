-- Lua provided by RyzenAPI
-- Game: 垃圾桶军团 Demo（V1.5）

-- MAIN APPLICATION
addappid(2716470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716472,0,"eddc8bbaa06d499ea823c01fdba025846d35676bc77b2efe70d7e60277ad603f")

