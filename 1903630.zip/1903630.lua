-- Lua provided by RyzenAPI
-- Game: Evasion from Hell

-- MAIN APPLICATION
addappid(1903630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903631, 1, "f26452d480207c382dc11d4e8ef75814fb6266aa67c1ada096917b2ce353e247")
