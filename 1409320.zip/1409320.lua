-- Lua provided by RyzenAPI
-- Game: 1409320

-- MAIN APPLICATION
addappid(1409320)
-- Game: addappid(1409320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409321, 1, "29fe31c9365d985de268ae3aab695a4f5eefe86a26b27c7ed73f71d737fb3295")
