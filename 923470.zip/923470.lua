-- Lua provided by RyzenAPI
-- Game: Game: AppID 923470

-- MAIN APPLICATION
addappid(923470)
-- Game: addappid(923470)

-- MAIN APP DEPOTS / PACKAGES
addappid(923471, 1, "0ba9e7aec2f61c70bef550761d27cdf016ee1f5893261b7457d87f367d3d5128")
addappid(923472, 1, "9c6f8c05427d6e43752201d6d98f90785933f6c2b1174d0233ffdd69f5dfef68")
addappid(923473, 1, "5b59f8c4bbc3bbd0ee02ba0c3c8cc6858d7a1957090f47d9d7bf6417b0c1cd08")
