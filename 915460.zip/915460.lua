-- Lua provided by RyzenAPI
-- Game: Game: AppID 915460

-- MAIN APPLICATION
addappid(915460)
-- Game: addappid(915460)

-- MAIN APP DEPOTS / PACKAGES
addappid(915461, 1, "92e6ad578343d29a60615b5360fc72d1ccf797045aa48d3eaf41656fad023fd8")
