-- Lua provided by RyzenAPI
-- Game: My Lovely Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1859530)
-- Game: addappid(1859530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859530,0,"e7965e80d41cc7022544f2664808b245bb94079797fd8157086618e8b76af6ef")
