-- Lua provided by RyzenAPI 
-- Game: Kizuyami | 刻闇
addappid(2602820)
addappid(2602821, 1, "7c4c6c601e0112d24ad6735ef593e2c157e42cf410f5c2def80e35b5a448a233")
