-- Lua provided by RyzenAPI
-- Game: Penko Vox: Japanese

-- MAIN APPLICATION
addappid(4836870) -- Penko Vox: Japanese

-- MAIN APP DEPOTS / PACKAGES
addappid(4836871, 1, "df3d18bf581f03ad46ef4926d2765a2fdd45e4c06e08116ea8930c5c1a123517") -- Depot 4836871
addappid(4836872, 1, "fb97c2c3fb7b8d598c8ecb52882fd14e51e357b01b7dc43dabf64017f054617b") -- Depot 4836872
addappid(4836873, 1, "61de8c8b34ecfbc7c2b2c1c9d90998baa103e877df0f28c43125934941f7cec4") -- Depot 4836873

