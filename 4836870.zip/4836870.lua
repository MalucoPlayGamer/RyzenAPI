-- 4836870's Lua and Manifest Created by Hubcap Manifest
-- Penko Vox: Japanese
-- Created: August 11, 2026 at 00:21:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4836870) -- Penko Vox: Japanese
-- MAIN APP DEPOTS
addappid(4836871, 1, "df3d18bf581f03ad46ef4926d2765a2fdd45e4c06e08116ea8930c5c1a123517") -- Depot 4836871
setManifestid(4836871, "6582841182023018006", 9272109222)
addappid(4836872, 1, "fb97c2c3fb7b8d598c8ecb52882fd14e51e357b01b7dc43dabf64017f054617b") -- Depot 4836872
setManifestid(4836872, "2815691978512480766", 7542924409)
addappid(4836873, 1, "61de8c8b34ecfbc7c2b2c1c9d90998baa103e877df0f28c43125934941f7cec4") -- Depot 4836873
setManifestid(4836873, "8336618612579349672", 9098013279)