-- Lua provided by RyzenAPI
-- Game: Game: The Admin

-- MAIN APPLICATION
addappid(420300)
-- Game: addappid(420300)

-- MAIN APP DEPOTS / PACKAGES
addappid(420301, 1, "99cf4913309b1c2aae247c4e65f5509352f563c43dbf14f4f52ae5669b3b757b")
