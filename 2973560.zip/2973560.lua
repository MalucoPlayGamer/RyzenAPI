-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Old Sea Port

-- MAIN APPLICATION
addappid(2973560)
-- Game: addappid(2973560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973561, 1, "9b1732c3a565311041a17f035b420b8e80b23ff1675b39f937e0df4bcb15a448")
