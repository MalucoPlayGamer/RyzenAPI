-- Lua provided by RyzenAPI
-- Game: Tame It!

-- MAIN APPLICATION
addappid(1706850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706851, 1, "6f02ea6969134d9269de444bdd9e5cb52f84b68fae22989ba19c71430cd23ae8")
addappid(2219341, 0, "8b7a8b569235b5be0dc9e653775a7ca1f538203c2601fb63282b146be11daea8")
addappid(2219342, 0, "481ebdb4e3a47b9e14cbc5a9a8b0f6365a1acd3a70724655879f32e99580e6f7")
addappid(2219343, 0, "4f16c0312743f368f623a997384591bbfa582ec84c3cb43954acce47f2d62adb")
addappid(2219344, 0, "4d6fe4a58e61c45be99a0696d5dc947e3a84af0c2cbe2a52466c553685e81b90")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2219340)
