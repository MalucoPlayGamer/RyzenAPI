-- Lua provided by SkyAPI 
-- Game: AppID 3431020
addappid(3431020)
addappid(3431021, 1, "50b2d897efdb8330677ca03483871cd1d67e04f7ef04f01d688e8903c5ad68f9")
