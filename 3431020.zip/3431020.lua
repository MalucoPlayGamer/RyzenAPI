-- Lua provided by RyzenAPI
-- Game: AppID 3431020

-- MAIN APPLICATION
addappid(3431020)
-- Game: addappid(3431020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431021, 1, "50b2d897efdb8330677ca03483871cd1d67e04f7ef04f01d688e8903c5ad68f9")
