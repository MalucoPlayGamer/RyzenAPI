-- Lua provided by RyzenAPI 
-- Game: AppID 1450530
addappid(1450530)
addappid(1450531, 1, "3ccd0a509e34c41f52b6e18a6d25a22f32a7fa1a9ebd44b265bb8a1941b099cb")
