-- Lua provided by RyzenAPI
-- Game: Easy Delivery Co.

-- MAIN APPLICATION
addappid(3293010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293011, 1, "8e652df7f7f499154c4db62e26560d348c9528c9a516d8095f23c33eaf858b27")
