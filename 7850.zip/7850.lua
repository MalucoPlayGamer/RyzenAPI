-- Lua provided by RyzenAPI
-- Game: Cryostasis

-- MAIN APPLICATION
addappid(7850)

-- MAIN APP DEPOTS / PACKAGES
addappid(7851, 1, "efcf31a6153f49cbf3c5ce5cb2222db16c3963faa1f9122c0056970f6446e0ae")
addappid(7852, 1, "975ef910dc28c98e46fd7703985ccaae74995e6ab15beed93370913ed11c13c2")
addappid(7853, 1, "de5d3a83a1a91067b21263a21140d6307630f928c0f6627645ad8741a606f7ad")
addappid(7854, 1, "4bdd15cce601fff15c3eaa4fc1a7a9973042720c62593d93c4f828bafea7a486")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
