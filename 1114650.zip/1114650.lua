-- Lua provided by RyzenAPI
-- Game: HorrorVale

-- MAIN APPLICATION
addappid(1114650)
addappid(2296570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114651, 1, "19a378b08873116810523251679ac173b91342f9ae359a9d0f7ad0cb0bb1213c")
