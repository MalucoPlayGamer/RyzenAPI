-- Lua provided by RyzenAPI
-- Game: AppID 1114650

-- MAIN APPLICATION
addappid(1114650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114651, 1, "19a378b08873116810523251679ac173b91342f9ae359a9d0f7ad0cb0bb1213c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2296570)
