-- Lua provided by RyzenAPI
-- Game: Game: Miami Paradise

-- MAIN APPLICATION
addappid(3403720)
-- Game: addappid(3403720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403721, 1, "6c1ce460f6b39d75e726be60d804420b3464e7f1a5c30f25406a5caeae1eda4f")
