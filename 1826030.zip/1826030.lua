-- Lua provided by RyzenAPI
-- Game: Dark Reflections - Shiori no Kotoha

-- MAIN APPLICATION
addappid(1826030)
-- Game: addappid(1826030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826031, 1, "26b05283f5b34de65296321ffc8feb312259a6b7d65c346dae8ceebe6b9cf7c7")
