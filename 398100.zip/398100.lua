-- Lua provided by RyzenAPI 
-- Game: AppID 398100
addappid(398100)
addappid(398101, 1, "68ae777ed991f1e207d14b5d90c289c9e75e56beda3a14b091934669f31869b4")
