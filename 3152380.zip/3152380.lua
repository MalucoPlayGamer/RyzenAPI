-- Lua provided by RyzenAPI
-- Game: Prison Notes

-- MAIN APPLICATION
addappid(3152380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152381, 1, "a2867c93e2c283ead7041835ba9510d51eaa29238833818d17b73c1eb2418f38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
