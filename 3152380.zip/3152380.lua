-- Lua provided by RyzenAPI
-- Game: Prison Notes

-- MAIN APPLICATION
addappid(3152380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152381, 1, "a2867c93e2c283ead7041835ba9510d51eaa29238833818d17b73c1eb2418f38")
