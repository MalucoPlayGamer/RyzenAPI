-- Lua provided by RyzenAPI
-- Game: 虚国：元灵召唤 Virtual country: Yuan fairy summon

-- MAIN APPLICATION
addappid(1861670)
-- Game: addappid(1861670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861671, 1, "3c50729137b894c0f640465ce38d18279efc2b42d3314f57881b212e6aa9906b")
