-- Lua provided by RyzenAPI
-- Game: addappid(2597580)

-- MAIN APPLICATION
addappid(2597580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597581, 1, "8602daf05989f80eb6e821ee7dc2c33d90dd42eb824bddcc2c25835b55fd32c7")
