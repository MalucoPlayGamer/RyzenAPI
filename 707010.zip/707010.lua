-- Lua provided by RyzenAPI 
-- Game: Will To Live Online
addappid(707010)
addappid(707011, 1, "85557593bc9091ff25ca78d7ac5ecdd5df713724f58ee9a7e02384fe1b6630ba")
addappid(975280)
