-- Lua provided by RyzenAPI
-- Game: addappid(707010)

-- MAIN APPLICATION
addappid(707010)
addappid(975280)

-- MAIN APP DEPOTS / PACKAGES
addappid(707011, 1, "85557593bc9091ff25ca78d7ac5ecdd5df713724f58ee9a7e02384fe1b6630ba")
