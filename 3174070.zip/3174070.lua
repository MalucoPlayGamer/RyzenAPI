-- Lua provided by RyzenAPI
-- Game: Texas Hold'em Poker: Pokerist

-- MAIN APPLICATION
addappid(3174070)

