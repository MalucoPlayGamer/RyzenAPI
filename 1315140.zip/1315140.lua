-- Lua provided by RyzenAPI
-- Game: 1315140

-- MAIN APPLICATION
addappid(1315140)
-- Game: addappid(1315140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315141, 1, "f61373e1b4ec79bc481ac76d975c715ee9203566b22e2c845dc01aafad32d866")
addappid(1315142, 1, "d6c71fb386c967dbf8cdfbaa4aeddf75aa84cd12bc840330d346d04012787005")
