-- Lua provided by RyzenAPI
-- Game: Game: The lost adventure

-- MAIN APPLICATION
addappid(2439660)
-- Game: addappid(2439660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439661, 1, "a76ebf2e0e421da0b7bd899b6a91351168503222e9c90717093afca1e4d1466f")
