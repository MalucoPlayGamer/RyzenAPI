-- Lua provided by RyzenAPI
-- Game: Breathe Peace World

-- MAIN APPLICATION
addappid(968310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(968311, 1, "3b82dcb667d7a435b43a3f3c444dd58598a531ec7f0b4fa6dac4e7a238b8ad49")

