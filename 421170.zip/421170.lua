-- Lua provided by RyzenAPI
-- Game: Indivisible

-- MAIN APPLICATION
addappid(421170)
addappid(1092310)
addappid(1155020)
addappid(1233840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(421171, 1, "c18ef0ee39cd592788df40d18c8c9bceb0cae8c3badf42b491e515c94c5d32d1")
addappid(421172, 1, "57228b3c152312bd8205ab7ba5af0ff71d676582527a370011eb977ce2d10df6")
addappid(421173, 1, "09cb764380ff5b3722ebd27bccf0e9c8cf3f9babc61f7378936a3ca70284fa66")
addappid(421174, 1, "ba7603d2b9f49fadc4d68a6be67da9d191fc847c46e6a6ebfb30274be99d408d")
addappid(421175, 1, "8e2fdad1e5820a9620da4dd97c20fd61b61516620f0dd77e716efe9195898492")
addappid(421176, 1, "e372a4dd0ade4a5437ea55f471ba6b00a345fa276051274d4e47f858dda04d27")
addappid(1172420, 0, "5983e67967f27ce109c189ba07ed95095e026cd3ef09c6bf3898fbfb331bdc53")
