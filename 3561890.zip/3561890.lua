-- Lua provided by SkyAPI 
-- Game: Yokai Landlord: Monster Mystery! Soundtrack
addappid(3561890)
addappid(3561891, 1, "3f0abe2c170620fff34c954adb08c57c656f93b9e6be9ce06a56b89fa7a67c46")
