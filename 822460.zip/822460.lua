-- Lua provided by RyzenAPI
-- Game: Game: AppID 822460

-- MAIN APPLICATION
addappid(822460)
-- Game: addappid(822460)

-- MAIN APP DEPOTS / PACKAGES
addappid(822461, 1, "0a1f4e465999df89f81f00afdc4304217c104a3f16a337de64a29a401d5e4630")
