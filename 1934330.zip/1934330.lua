-- Lua provided by RyzenAPI 
-- Game: Joshua's Legs
addappid(1934330)
addappid(1934331, 1, "b526fa66501fede286a9462e43d66aceebf8f8380cafe6138d9605d5891f8fcd")
