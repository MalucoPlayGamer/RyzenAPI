-- Lua provided by RyzenAPI
-- Game: Armored Battle Crew [World War 1] - Tank Warfare and Crew Management Simulator

-- MAIN APPLICATION
addappid(814740)
addappid(1091160)

-- MAIN APP DEPOTS / PACKAGES
addappid(814741, 1, "401bc18d61dadc140cd4e4d3fd58c98bc5f399540c6cc0b5bdd5a731b5b2c7c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
