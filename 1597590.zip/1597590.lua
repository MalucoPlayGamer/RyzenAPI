-- Lua provided by RyzenAPI
-- Game: Super Magbot Demo

-- MAIN APPLICATION
addappid(1597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597591, 1, "354de8db7085455ab0040c7067e6d98d8ce5e538d2b622e07bff21d3546e6ec6")
