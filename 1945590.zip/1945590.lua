-- Lua provided by RyzenAPI
-- Game: addappid(1945590)

-- MAIN APPLICATION
addappid(1945590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945591, 1, "faecaf7c0cbd9466067dba4ad4da227c84cdd86723e1deaa561827efffda7ca3")
