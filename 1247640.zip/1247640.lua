-- Lua provided by RyzenAPI
-- Game: addappid(1247640)

-- MAIN APPLICATION
addappid(1247640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247641, 1, "4d4933ed85bd07fa35035cfa6745bb506af8e1f139ef3d1ba19563723adf2d8f")
