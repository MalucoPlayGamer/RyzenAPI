-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Raven is streaming

-- Main AppID
addappid(4674730) -- Hentai Clicker: Raven is streaming

-- Main Depots
addappid(4674731, 1, "1737ab45525656d0ead99e961bc7cedb79eeafd2182728b6e41289f240b7bdcd") -- (windows)
-- setManifestid(4674731, "4935020708105959368", 161211502)

-- Missing Depots (We don't have the keys yet lol): 4674732, 4674733
