-- Lua provided by RyzenAPI
-- Game: 小虎传：大菠萝深渊 Diablo The Abyss

-- MAIN APPLICATION
addappid(1945230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945231, 1, "3e78ef9e28f3d6188988a37c9db08ea246bd0e06b2be84e0349aed5422f30c54")

