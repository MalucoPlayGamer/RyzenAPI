-- Lua provided by RyzenAPI
-- Game: 子夜之章:历史的终局～MidNights of Desperado～

-- MAIN APPLICATION
addappid(1209770)
-- Game: addappid(1209770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209771, 1, "07109ceee6a8c6b6cec3fe8daa7b16d7a1bfa05e99e3069f216ea8e6b11e9891")
addappid(1209772, 1, "47029d23f553719503a9395e150b3b903eeafeef32005ca433044cf433bd2644")
addappid(1697711, 0, "51be9a343700b699b11e282c39c248ffd277d36fc5f5d26fbcea87d272ebdbbb")
