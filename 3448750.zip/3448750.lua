-- Lua provided by SkyAPI 
-- Game: Frog Jump
addappid(3448750)
addappid(3448751, 1, "f8ad03a6d1c9f2a75f37d1665ed24a81cd12d0ca0e4d32fdc2113c9b60207de7")
