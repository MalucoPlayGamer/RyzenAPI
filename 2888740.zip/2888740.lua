-- Lua provided by RyzenAPI
-- Game: Ubermensch

-- MAIN APPLICATION
addappid(2888740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888741, 1, "a613620373aa1d44942eec0bbc6bc587a5d42fb768b452e865549bee846dbd5a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
