-- Lua provided by RyzenAPI
-- Game: God Of Gamblers

-- MAIN APPLICATION
addappid(2091550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091551, 1, "b6863c86e01e38ffc8fd3e4370e9f503e3bff12fdb0f78a2e9c34cf679566419")
