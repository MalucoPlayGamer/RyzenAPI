-- Lua provided by RyzenAPI
-- Game: Project of Cooling the Earth Demo

-- MAIN APPLICATION
addappid(2946080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946081, 1, "fa2c00a603fb62bbc42f44a2c95a19f4964c383c614fb72a86b36f878de88c47")
