-- Lua provided by SkyAPI 
-- Game: Hood Warfare
addappid(2274510)
addappid(2274511, 1, "34fd2760d1b8005e4a52cd24ec674b6482bc4d2ce36faba7e158f61ccf40dcb8")
