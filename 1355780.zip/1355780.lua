-- Lua provided by SkyAPI 
-- Game: AppID 1355780
addappid(1355780)
addappid(1355781, 1, "ec915a14282e4b071a0f2e21b320ac70b5f4d0aea3165ec6b6175a644fb05a34")
