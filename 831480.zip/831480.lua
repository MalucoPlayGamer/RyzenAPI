-- Lua provided by RyzenAPI
-- Game: Game: AppID 831480

-- MAIN APPLICATION
addappid(831480)
-- Game: addappid(831480)

-- MAIN APP DEPOTS / PACKAGES
addappid(831481, 1, "f2e9329ead9903ad2b413d3a65805780776abc0470934b7000c971f7ea59a88a")
