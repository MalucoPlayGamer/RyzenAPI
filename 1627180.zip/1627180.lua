-- Lua provided by RyzenAPI
-- Game: 1627180

-- MAIN APPLICATION
addappid(1627180)
-- Game: addappid(1627180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627181, 1, "d832e81d6083cb6f56db46a43e98f87ca7f61a9f657d47c20eeb8e8b1be2607b")
