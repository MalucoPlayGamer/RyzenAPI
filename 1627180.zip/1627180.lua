-- Lua provided by RyzenAPI
-- Game: Operation Insanity

-- MAIN APPLICATION
addappid(1627180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1627181, 1, "d832e81d6083cb6f56db46a43e98f87ca7f61a9f657d47c20eeb8e8b1be2607b")

