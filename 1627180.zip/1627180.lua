-- Lua provided by RyzenAPI 
-- Game: AppID 1627180
addappid(1627180)
addappid(1627181, 1, "d832e81d6083cb6f56db46a43e98f87ca7f61a9f657d47c20eeb8e8b1be2607b")
