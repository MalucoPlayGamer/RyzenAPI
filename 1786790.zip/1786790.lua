-- Lua provided by RyzenAPI
-- Game: Magical Girl Celesphonia

-- MAIN APPLICATION
addappid(1786790)
-- Game: addappid(1786790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786791, 1, "79653d61e87d3f733ec7273ea4efcd0e16a1cc36adf01917ead5a96ba3eb1a78")
addappid(1786792, 1, "645a031f716157475cabad4b564b2f14c7eca13542f1bdfab17bd87988f9ac4c")
addappid(1786793, 1, "7546a25c6642a0ca33fb91a86690ed53ce8b9907dc127b5c921b5e7c5c5f6f77")
addappid(2203950, 0, "f5e2d062f2911908147776f591f2fdcce6749241fff5f34c184c33ed7a4497fd")
addappid(2862000, 0, "e65511f4d3d6c3413ff11e3ef222e1103316d8bff635ecc0627227c656b1534a")
