-- Lua provided by SkyAPI 
-- Game: NeveRossa Remaster
addappid(3141020)
addappid(3141021, 1, "cfc680b2dd53a4e87242a6e224f9677fff1bd3129fb966a9356a50e6dcd97fdc")
addappid(3181620, 0, "44fcc2eae9fa44ebb734555b8738223d66f6630d0f315af519ca44b000d7d409")
