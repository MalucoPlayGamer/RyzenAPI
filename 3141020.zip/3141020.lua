-- Lua provided by RyzenAPI
-- Game: Game: NeveRossa Remaster

-- MAIN APPLICATION
addappid(3141020)
-- Game: addappid(3141020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141021, 1, "cfc680b2dd53a4e87242a6e224f9677fff1bd3129fb966a9356a50e6dcd97fdc")
addappid(3181620, 0, "44fcc2eae9fa44ebb734555b8738223d66f6630d0f315af519ca44b000d7d409")
