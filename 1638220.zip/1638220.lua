-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: The Scar of Sky

-- MAIN APPLICATION
addappid(1638220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1638221, 1, "789cec88a29b77b03d138f61a18dc3e643ac3c8cc8aec881743f65a0aec798b3")
addappid(1638222, 1, "921821613d48887e3fa67c833757886e2624d9b8a734af21f43f2d788768765d")
addappid(1638223, 1, "d6dc73d7360c19e460a034459cb18e35587e7a64b367191a4ec39823cfef0d3d")

