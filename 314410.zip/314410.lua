-- Lua provided by RyzenAPI
-- Game: Rampage Knights

-- MAIN APPLICATION
addappid(314410)
-- Game: addappid(314410)

-- MAIN APP DEPOTS / PACKAGES
addappid(314411, 1, "d305bc4b3a6679bac07990d21932bfb8d9adb3437dd92bfa2bbdb8433ca6a13b")
addappid(314412, 1, "ab0b76862bbc51612e67ff4de6fd995134ead1ba726ffc895c8d6dacae595026")
