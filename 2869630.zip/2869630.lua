-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2869630)
addappid(2869639)
-- Game: addappid(2869630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869630,0,"98765abb8b8434942d9613e819d5ccefc2d72c608ba13e650ac9e06906709e5e")
