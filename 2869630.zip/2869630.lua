-- Lua provided by RyzenAPI
-- Game: addappid(2869630)

-- MAIN APPLICATION
addappid(2869630)
addappid(2869639)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869630,0,"98765abb8b8434942d9613e819d5ccefc2d72c608ba13e650ac9e06906709e5e")
