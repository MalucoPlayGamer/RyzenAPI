-- Lua provided by RyzenAPI
-- Game: setManifestid(2379732,"3369759390615806300")

-- MAIN APPLICATION
addappid(2379730)
-- Game: addappid(2379730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379732,0,"ca96e8e711b9b8683b06749f9cedb48fbdb8e0afcde0d0778b81838fb48d7476")
