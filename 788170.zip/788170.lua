-- Lua provided by RyzenAPI
-- Game: Game: AppID 788170

-- MAIN APPLICATION
addappid(788170)
-- Game: addappid(788170)

-- MAIN APP DEPOTS / PACKAGES
addappid(788171, 1, "79069bc45ea0c56ecc3a68bcae3ca50234df68006389e0b5980c3193fa77377f")
