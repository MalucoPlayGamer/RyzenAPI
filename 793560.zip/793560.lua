-- Lua provided by RyzenAPI
-- Game: Game: Warfare 1944

-- MAIN APPLICATION
addappid(793560)
-- Game: addappid(793560)

-- MAIN APP DEPOTS / PACKAGES
addappid(793561, 1, "7213e8de74e08ef2ca6afaad5fad8cb6ac5ac0cae8f151baf05d2c93c4794fff")
