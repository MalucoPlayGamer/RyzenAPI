-- Lua provided by RyzenAPI
-- Game: Game: Smalles

-- MAIN APPLICATION
addappid(1704760)
-- Game: addappid(1704760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704761, 1, "d0564b5c3c40f4d3502341f57eaea8ce6268cef0aad00f7d29263c816d60fc2e")
addappid(1709140, 0, "b08dfba198cfeebb8fdb33829ffcb3a581f81bbcf9f7127b8347ecb4afe2c09c")
