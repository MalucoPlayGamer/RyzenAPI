-- Lua provided by RyzenAPI
-- Game: Game: ANTONBLAST

-- MAIN APPLICATION
addappid(1887400)
-- Game: addappid(1887400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887401, 1, "45bc1461e14ddd35a713fc71483727d019f558488091b54ef249bf00dba5a16b")
