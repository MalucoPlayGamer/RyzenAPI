-- Lua provided by RyzenAPI 
-- Game: ANTONBLAST
addappid(1887400)
addappid(1887401, 1, "45bc1461e14ddd35a713fc71483727d019f558488091b54ef249bf00dba5a16b")
