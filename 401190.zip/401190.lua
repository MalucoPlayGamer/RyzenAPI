-- Lua provided by RyzenAPI
-- Game: Dinosaur Hunt

-- MAIN APPLICATION
addappid(401190)
addappid(408100)
addappid(408101)
addappid(408102)
addappid(431190)
addappid(431191)
addappid(434940)
addappid(434941)
addappid(434942)
addappid(434943)
addappid(434944)

-- MAIN APP DEPOTS / PACKAGES
addappid(401191, 1, "71085de82167247e4d16ca54141ca6d03c58bb14aa1105350da56ef511aa225f")
addappid(401192, 1, "18d0ef2cfbf546fe6ca97d0b61d5f77cfd3940d8fba702dfa4dafc28c42454e1")
addappid(401193, 1, "461c35d0efaca67a45a76d75e8e476dc00d13ab734a1f975952683b166413090")
addappid(401194, 1, "74df86e94eff89d2694920131bb67baf31d14e5abb2f41dfc025245a80c6ab34")

