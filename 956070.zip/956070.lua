-- Lua provided by RyzenAPI
-- Game: addappid(956070)

-- MAIN APPLICATION
addappid(956070)

-- MAIN APP DEPOTS / PACKAGES
addappid(956070,0,"590f707fcd044e807b0da26e86ad9c89985a523de27afb091b17d2b68e1bb597")
