-- Lua provided by RyzenAPI 
-- Game: Numeric Demon Cat
addappid(1511310)
addappid(1511311, 1, "6aead61411f5c71f3d523dfcd63f72f25c991bf9fba8a2e5bfc4171752abf657")
