-- Lua provided by RyzenAPI
-- Game: 2546110

-- MAIN APPLICATION
addappid(2546110)
-- Game: addappid(2546110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546111, 1, "c5c7fc7d85e7c33d1f85a8baab271a0250cb611f63ef824cd9497e229d66ccfa")
