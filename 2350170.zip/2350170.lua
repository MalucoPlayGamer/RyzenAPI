-- Lua provided by RyzenAPI
-- Game: 2350170

-- MAIN APPLICATION
addappid(2350170)
-- Game: addappid(2350170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350171, 1, "58b72ecf31c471d2d319dd0014daf9bd243bcc894af02c64dedb3888a6c0e91f")
