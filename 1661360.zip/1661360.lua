-- Lua provided by RyzenAPI
-- Game: Leman

-- MAIN APPLICATION
addappid(1661360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661361, 1, "82b151050da383fd7436376254bca6d42ae9c33638b40fdd7d065637b2b0dcae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
