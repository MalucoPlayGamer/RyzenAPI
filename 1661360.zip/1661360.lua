-- Lua provided by RyzenAPI
-- Game: Game: Leman

-- MAIN APPLICATION
addappid(1661360)
-- Game: addappid(1661360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661361, 1, "82b151050da383fd7436376254bca6d42ae9c33638b40fdd7d065637b2b0dcae")
