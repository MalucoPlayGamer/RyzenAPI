-- Lua provided by RyzenAPI 
-- Game: The Dweller
addappid(463930)
addappid(463931, 1, "f1191c2ab8cdbae2e02ae2487c7c358ccab05323214ac6e05909cdee26ee97d7")
addappid(463932, 1, "3a655da134c8cc1df5d99a384d64a7c4b2d8585ac35f6bcc351a206640d66747")
