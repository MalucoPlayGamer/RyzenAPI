-- Lua provided by RyzenAPI
-- Game: addappid(41300)

-- MAIN APPLICATION
addappid(41300)

-- MAIN APP DEPOTS / PACKAGES
addappid(41301, 1, "1df24e8ce9f36be241fff78973c985ad563fac1d7d05e3c30fced6f4beb37c11")
addappid(41302, 1, "9e030d19c2323fe6627c401340fa634deb40440a71bbbe1ece4f7d466c6f7414")
addappid(41303, 1, "c4cbb8a4d8b308fe43487564febc07c969d327701ebb93242b1a935dd70fce3b")
addappid(41304, 1, "361cfccb765dc2740e054bb02e21c8647b099da0d06a60765ca41a68113d7730")
addappid(41305, 1, "c6eb1064c2eafa79df0209d87d0d4403317096f241e5ccae9d52ceb0dec35510")
