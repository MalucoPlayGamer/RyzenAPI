-- Lua provided by RyzenAPI
-- Game: DLC Scenario Pack: What If… Series

-- MAIN APPLICATION
addappid(1951090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951091, 1, "178de01082fa866e64c43315604d9c705cdf6a74d9753a5878b0ba75c2304158")

