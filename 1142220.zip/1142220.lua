-- Lua provided by RyzenAPI
-- Game: Beat Aim - Rhythm FPS Trainer

-- MAIN APPLICATION
addappid(1142220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142221, 1, "23a1202b5a6f3e071cd2037db76ed80dc890cb59370c0456581737a7b3f93ee9")

