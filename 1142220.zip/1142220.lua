-- Lua provided by RyzenAPI
-- Game: Beat Aim - Rhythm FPS Trainer

-- MAIN APPLICATION
addappid(1142220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1142221, 1, "23a1202b5a6f3e071cd2037db76ed80dc890cb59370c0456581737a7b3f93ee9")

