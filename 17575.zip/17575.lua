-- Lua provided by RyzenAPI
-- Game: 17575

-- MAIN APPLICATION
addappid(17575)
-- Game: addappid(17575)

-- MAIN APP DEPOTS / PACKAGES
addappid(331030,0,"1121242e93efe28bafb82c09a585d7fcf6c33ae4d0fd68cb1768c9aa633c7011")
addappid(331031,0,"42d6ea5ae4b3982c978777ab61e314c6d9909b65273504df31ce7be79ee052a4")
addappid(331032,0,"4fac1c5299c123045bfb8ce3605ca71de8ab0d103b119bb15e09fcc8e4f2338b")
