-- Lua provided by RyzenAPI
-- Game: addappid(1475890)

-- MAIN APPLICATION
addappid(1475890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475891, 1, "e92229b4093c6d6be4e02dd8b68627980607a1488dc14ca5289cc24e17f2c1b2")
