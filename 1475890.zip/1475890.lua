-- Lua provided by SkyAPI 
-- Game: Mandinga - A Tale of Banzo
addappid(1475890)
addappid(1475891, 1, "e92229b4093c6d6be4e02dd8b68627980607a1488dc14ca5289cc24e17f2c1b2")
