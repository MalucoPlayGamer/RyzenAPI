-- Lua provided by RyzenAPI
-- Game: Batman: Arkham Asylum Game of the Year Edition

-- MAIN APPLICATION
addappid(35010)

-- MAIN APP DEPOTS / PACKAGES
addappid(35011, 1, "a723ed2af4854a86bd4897810a320e11e53c56ec45a1e80fab92c1669e103aca")
addappid(35012, 1, "1fbdc1c8a533085e5cd373b280863f9114246b190e7ad3278120cb0c80a6a62d")
addappid(35013, 1, "75063bfba31b77a5d5ba4b3cb41c46a810bafd7e2d7ffdf06ed88cc1656db764")
addappid(35014, 1, "d14008d95cb23b305aad6b3d4bc9bef7f43edf43cb4ca7e564951adad30e1d58")
addappid(35015, 1, "6d434183f50671058b10a05ec50a351b1a929995847b4af2fe536a7ea22778d7")
