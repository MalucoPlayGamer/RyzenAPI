-- Lua provided by RyzenAPI
-- Game: Dodgeball Simulator VR

-- MAIN APPLICATION
addappid(975390)

-- MAIN APP DEPOTS / PACKAGES
addappid(975391, 1, "9571b2d9fa5415002975600dc9c8ad5296e09be39bfe1def1b8c1296b6182b26")
