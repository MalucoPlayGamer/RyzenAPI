-- Lua provided by RyzenAPI
-- Game: Epic Battle Fantasy 5

-- MAIN APPLICATION
addappid(432350)

-- MAIN APP DEPOTS / PACKAGES
addappid(432351, 1, "5afc1a8464216e86a3a540b743bf8619ffdd1cbbebc0f8b1e92157316c5431b2")

