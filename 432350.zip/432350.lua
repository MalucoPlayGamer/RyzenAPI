-- Lua provided by RyzenAPI
-- Game: addappid(432350)

-- MAIN APPLICATION
addappid(432350)

-- MAIN APP DEPOTS / PACKAGES
addappid(432351, 1, "5afc1a8464216e86a3a540b743bf8619ffdd1cbbebc0f8b1e92157316c5431b2")
