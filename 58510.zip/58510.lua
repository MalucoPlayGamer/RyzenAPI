-- Lua provided by RyzenAPI
-- Game: addappid(58510)

-- MAIN APPLICATION
addappid(58510)

-- MAIN APP DEPOTS / PACKAGES
addappid(231141,0,"815a9b328b48efbc031cdd6d88c29717db907810096f3715ed38bf44e62f3424")
