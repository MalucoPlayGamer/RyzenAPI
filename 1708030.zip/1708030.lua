-- Lua provided by RyzenAPI
-- Game: SpaceSeals

-- MAIN APPLICATION
addappid(1708030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708031, 1, "29a560ec6b4884befd609002a9ad4534bb282f3f31de543a775914db9511f050")
