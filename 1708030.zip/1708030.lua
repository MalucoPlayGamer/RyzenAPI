-- Lua provided by RyzenAPI
-- Game: SpaceSeals

-- MAIN APPLICATION
addappid(1708030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708031, 1, "29a560ec6b4884befd609002a9ad4534bb282f3f31de543a775914db9511f050")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
