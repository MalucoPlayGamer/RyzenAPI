-- Lua provided by RyzenAPI
-- Game: Game: Portal

-- MAIN APPLICATION
addappid(400)
-- Game: addappid(400)

-- MAIN APP DEPOTS / PACKAGES
addappid(401, 1, "3ed55d26ffdf7f6c5e228ec60127ddc1712f341cfb082cadb9cebbd0f64d0d7d")
addappid(402, 1, "1d9699c90f13a7549a97e5935b9eb152502aa664ce6944a56573c5f9a5c6d2f1")
addappid(403, 1, "1349997dfe5e13cb91d43d7076e499e92da34710020fb4d3d58c385e5092c837")
addappid(404, 1, "552f270a24f114f8eb9ccaad3502d0f30f8950c67fcb62b2752f1ae5bd9eb2e1")
addappid(405, 1, "a727634c8c0d6f750077fb397fb5d4848b1a31f7cefcb0e3295bbbed05af1b6a")
addappid(406, 1, "3bfe4846e06d664c531bb61e2f35737653d9099497522b38fd15a355acd5339c")
addappid(407, 1, "e9eafe69caa4384a1b69193f12c7f4dbbe65a71a76e178b988260524b2a4c3ba")
addappid(408, 1, "a6254ee5cef5797432b6ae404018d028c955596cbfa5ff3fece97a9cd6534d1b")
addappid(409, 1, "28cf5b133c63b6f5f1fab9d376b3ce35c7dd327505459288ae8d772a262c48f4")
addappid(410, 1, "6bb84a4ff29b21f5f3e52a121c1293ad75c92ba8ad0b050fa691a9c15164a5e9")
