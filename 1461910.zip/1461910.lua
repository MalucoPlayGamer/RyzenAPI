-- Lua provided by SkyAPI 
-- Game: Rogue Command
addappid(1461910)
addappid(1461911, 1, "5b635c96f61959d88cc4b8ae99f6c35834a8948fe2528ea1974756c863d7b882")
