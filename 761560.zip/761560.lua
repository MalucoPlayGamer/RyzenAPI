-- Lua provided by RyzenAPI
-- Game: APEX Tournament Demo

-- MAIN APPLICATION
addappid(761560)

-- MAIN APP DEPOTS / PACKAGES
addappid(761561, 1, "70bb563a1f5723b6121549bb7998c62e9b3cb7f804aa714e32b4262a04b06910")

