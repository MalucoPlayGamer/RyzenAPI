-- Lua provided by RyzenAPI
-- Game: Game: Terminus: Zombie Survivors - Soundtrack

-- MAIN APPLICATION
addappid(2992690)
-- Game: addappid(2992690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992691, 1, "dcba2a06ce1cce09435f7ef576e2a59a04215da85a8c3f695798191d717651ba")
addappid(2992692, 1, "a461368f95433fd2798a809923ca731f7b90e52977c3a54c11452f4f6164dda7")
