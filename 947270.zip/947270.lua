-- Lua provided by RyzenAPI
-- Game: Game: The 'I Love Money' Show

-- MAIN APPLICATION
addappid(947270)
-- Game: addappid(947270)

-- MAIN APP DEPOTS / PACKAGES
addappid(947271, 1, "468a5c41e27b95e75c9ff7427c107c61ff1a5bb903cb5ca016511c344b0e564e")
addappid(947272, 1, "516e17e8379df9c15c940410ad6075448be957fc15f2194bffd22d375ca364d2")
