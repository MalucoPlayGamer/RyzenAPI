-- Lua provided by RyzenAPI
-- Game: AppID 2587700

-- MAIN APPLICATION
addappid(2587700)
-- Game: addappid(2587700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587701, 1, "092a28f675c2a747bbc37c072c534120baffcf46937a4faeb3bd3c212f79fe46")
