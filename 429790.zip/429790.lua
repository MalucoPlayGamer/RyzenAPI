-- Lua provided by RyzenAPI
-- Game: addappid(429790)

-- MAIN APPLICATION
addappid(429790)

-- MAIN APP DEPOTS / PACKAGES
addappid(429793,0,"2c01ec0519f46a6ded38f695e2e7e11bf25c49024f286d544fb1f558ee8c3b0c")
addappid(429794,0,"3aaf0ffb2ac079602ef6c769dfd06cd416949b6f47a155c38298c379d14a7abd")
