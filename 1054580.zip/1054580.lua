-- Lua provided by RyzenAPI
-- Game: Easy Cat Timer

-- MAIN APPLICATION
addappid(1054580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054581, 1, "13ffaa0d07c9a665efc81b19e4af90de2c61547c28baf436f74cf6c3eeab98e9")
