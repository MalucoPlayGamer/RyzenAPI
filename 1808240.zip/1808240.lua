-- Lua provided by RyzenAPI
-- Game: Naughty Waifu

-- MAIN APPLICATION
addappid(1808240)
-- Game: addappid(1808240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808241, 1, "e4b102419e089ae2bba28439c556f16d88252f93807ff7c380271fea7297a3ba")
