-- Lua provided by RyzenAPI
-- Game: Naughty Waifu

-- MAIN APPLICATION
addappid(1808240)
addappid(3742180)
addappid(3742190)
addappid(3742200)
addappid(3742210)
addappid(3742220)
addappid(3742230)
addappid(3742240)
addappid(3742250)
addappid(3742260)
addappid(3742270)
addappid(3742280)
addappid(3742290)
addappid(3742300)
addappid(3742310)
addappid(3742320)
addappid(3742330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808241, 1, "e4b102419e089ae2bba28439c556f16d88252f93807ff7c380271fea7297a3ba")

