-- Lua provided by RyzenAPI
-- Game: WRC 6 FIA World Rally Championship

-- MAIN APPLICATION
addappid(458770)

-- MAIN APP DEPOTS / PACKAGES
addappid(458771, 1, "98497e050f445b61e899a6f618ef75a6384f5485eb3a9b5909739dca9387b2cb")
addappid(538080, 0, "fefe5598c34182378d6e310ae31806c64b080a081d7cd766ac73c1a0e7cbe8d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(526640)
