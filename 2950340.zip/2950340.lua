-- Lua provided by SkyAPI 
-- Game: LEGO® Harry Potter™ Collection
addappid(2950340)
addappid(2950341, 1, "dcdb19d1120bba8ee9b69aa8c6a40418bbc2a6891de96b469a2df6b700da7f13")
