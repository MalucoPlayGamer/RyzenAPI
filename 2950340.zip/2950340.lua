-- Lua provided by RyzenAPI
-- Game: LEGO® Harry Potter™ Collection

-- MAIN APPLICATION
addappid(2950340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2950341, 1, "dcdb19d1120bba8ee9b69aa8c6a40418bbc2a6891de96b469a2df6b700da7f13")

