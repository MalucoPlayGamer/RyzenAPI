-- Lua provided by RyzenAPI 
-- Game: AppID 1067450
addappid(1067450)
addappid(1067451, 1, "a16c18cd191f5ed8c42f2cb20e9e919e2e32ae01f625740461a340df5b92c0a7")
