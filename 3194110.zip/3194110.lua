-- Lua provided by RyzenAPI
-- Game: Doujin Fever!! Night Assault!

-- MAIN APPLICATION
addappid(3194110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194111, 1, "28f8fa8fc5b91d12d6f9fa294320c4b7242ce632f3ba6f95fad317606c8d1a0e")

