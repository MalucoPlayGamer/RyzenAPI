-- Lua provided by RyzenAPI 
-- Game: AppID 1050130
addappid(1050130)
addappid(1050131, 1, "e384e37ec4d5d2da5c6470ccb173e023ebf7af399a8810bf98be9dfbc96fe943")
