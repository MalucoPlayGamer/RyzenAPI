-- Lua provided by RyzenAPI
-- Game: Game: Uchikano - Living With My Lovers

-- MAIN APPLICATION
addappid(2395630)
-- Game: addappid(2395630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395631, 1, "869ea73dc6ca9c0e9db2817ef410ef20c448f7ee8441054b51ee869d92199fa9")
