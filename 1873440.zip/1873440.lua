-- Lua provided by RyzenAPI 
-- Game: I Am Two People
addappid(1873440)
addappid(1873441, 1, "8ea4fe66f3479a334a2e9ad24543c878d4879eafdbc85d330529f360c125cc17")
