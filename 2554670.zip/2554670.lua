-- Lua provided by RyzenAPI
-- Game: Stormshot

-- MAIN APPLICATION
addappid(2554670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554671, 1, "dd88db4375a92c09236f9642c8ebe6395f7e34f5c6e7641e643d6b85c832c3db")
