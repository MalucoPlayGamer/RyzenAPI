-- Lua provided by RyzenAPI
-- Game: 1857740

-- MAIN APPLICATION
addappid(1857740)
-- Game: addappid(1857740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857741, 1, "1b6b6376286e53470ca940fd111f876f883e516565d137e2f6a449ee0efdfae8")
