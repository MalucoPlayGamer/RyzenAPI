-- Lua provided by RyzenAPI
-- Game: 鸡械绿洲 Playtest

-- MAIN APPLICATION
addappid(2867740)
-- Game: addappid(2867740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867741, 1, "d8d7ff70e050ed38f989ed5d6adba8af4683af39d80ea8dfad5c31a1d63d6621")
