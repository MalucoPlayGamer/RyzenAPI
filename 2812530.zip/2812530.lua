-- Lua provided by RyzenAPI
-- Game: 2812530

-- MAIN APPLICATION
addappid(2812530)
-- Game: addappid(2812530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812531, 1, "4db1a41cd3f0309ba1a1058a79d03c9632336c5f11c3d0eaad83acab2975ce5a")
