-- Lua provided by RyzenAPI
-- Game: 2018820

-- MAIN APPLICATION
addappid(2018820)
-- Game: addappid(2018820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018821, 1, "cfb1f0c83aaf81aba177326f76d777907cc4ebfa66d2037c8af16a5c040b746e")
