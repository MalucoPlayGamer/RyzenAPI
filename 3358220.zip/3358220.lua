-- Lua provided by RyzenAPI
-- Game: OAsys - Speedbots Tournament

-- MAIN APPLICATION
addappid(3358220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3358221, 1, "99aeb46909aeda36d430941504fe45440e3de7db8db98d423a062c1e46591744")

