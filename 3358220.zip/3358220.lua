-- Lua provided by RyzenAPI
-- Game: OAsys - Speedbots Tournament

-- MAIN APPLICATION
addappid(3358220)
-- Game: addappid(3358220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358221, 1, "99aeb46909aeda36d430941504fe45440e3de7db8db98d423a062c1e46591744")
