-- Lua provided by SkyAPI 
-- Game: AppID 398830
addappid(398830)
addappid(398831, 1, "7cd9b1f9159b7b1a27e96deabafd22d1926e8b7b2f9395d975b913a599e8065b")
addappid(398832, 1, "776d7bdf9c447b400aed917147e2798cb5771e590b8187d9e1f7d9b7b29dc8de")
addappid(398833, 1, "652d6b23caf75938d2e2b7dc4dcfc8a1d8d3bba62070dbea78b3eeea23808067")
