-- Lua provided by RyzenAPI
-- Game: Dead Bits

-- MAIN APPLICATION
addappid(303390)

-- MAIN APP DEPOTS / PACKAGES
addappid(303391, 1, "dea0f8237f99e56a30f2d3930b70c42832d2d68eec86018e16dac053c4aaa62c")
addappid(303392, 1, "7d27178a806198c6b29abaa46436dbc8a84a84d6dc3781bc4a2d9dfe0c6093b8")
addappid(306160, 0, "aec0d75411e9f9752d754686cbd76b80d06ddea25801c97cf9da9bff36ee090c")
