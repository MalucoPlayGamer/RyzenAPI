-- Lua provided by RyzenAPI
-- Game: Octopus Goulash Demo

-- MAIN APPLICATION
addappid(3215470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215471, 1, "2b7d9a2f41b76ba0ef927242f9dabaa7365b6cee569e7da5b682607f1971886d")

