-- Lua provided by RyzenAPI 
-- Game: AppID 3215470
addappid(3215470)
addappid(3215471, 1, "2b7d9a2f41b76ba0ef927242f9dabaa7365b6cee569e7da5b682607f1971886d")
