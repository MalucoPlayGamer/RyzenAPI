-- Lua provided by SkyAPI 
-- Game: AppID 743580
addappid(743580)
addappid(743581, 1, "c060ab2220907674c8e1d9419a536bb3d52336fac1b1b5471edc049855336254")
