-- Lua provided by RyzenAPI
-- Game: AppID 743580

-- MAIN APPLICATION
addappid(743580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743581, 1, "c060ab2220907674c8e1d9419a536bb3d52336fac1b1b5471edc049855336254")

