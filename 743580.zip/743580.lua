-- Lua provided by RyzenAPI
-- Game: Game: AppID 743580

-- MAIN APPLICATION
addappid(743580)
-- Game: addappid(743580)

-- MAIN APP DEPOTS / PACKAGES
addappid(743581, 1, "c060ab2220907674c8e1d9419a536bb3d52336fac1b1b5471edc049855336254")
