-- Lua provided by RyzenAPI
-- Game: 2467410

-- MAIN APPLICATION
addappid(2467410)
-- Game: addappid(2467410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467411, 1, "f9dccd02cb5ce35eb3bfc16f1a17848fbbce9af4a0ffec9b2f5cf4d92767a9d3")
