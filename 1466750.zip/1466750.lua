-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1466750)
addappid(1466751)
addappid(1466752)
-- Game: addappid(1466750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762640,0,"0b7e3d2d40ecdfa7bd413f40127ef7651da3d1ce1d4ca2550d254d623cd66427")
