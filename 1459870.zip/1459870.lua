-- Lua provided by RyzenAPI
-- Game: 1459870

-- MAIN APPLICATION
addappid(1459870)
-- Game: addappid(1459870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459871, 1, "3bdcf19f20fc6d6407496fba67c757b80dcbe52a6f9983b1cd0a08357e1bde7e")
addappid(1459872, 1, "2320de827ceec27a43c7a1d5bc2cf5853982b7005d4fbc38df66f452485cb351")
