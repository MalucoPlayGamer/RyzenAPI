-- Lua provided by RyzenAPI
-- Game: King Pins

-- MAIN APPLICATION
addappid(1459870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459871, 1, "3bdcf19f20fc6d6407496fba67c757b80dcbe52a6f9983b1cd0a08357e1bde7e")
addappid(1459872, 1, "2320de827ceec27a43c7a1d5bc2cf5853982b7005d4fbc38df66f452485cb351")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
