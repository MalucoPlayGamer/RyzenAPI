-- Lua provided by RyzenAPI
-- Game: AI LIMIT

-- MAIN APPLICATION
addappid(2407270)
-- Game: addappid(2407270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407271, 1, "7fbec0c07311645df5048184f930dab908082e6a96be2f0814a3159eaa8de5a6")
