-- Lua provided by RyzenAPI
-- Game: Sex and Zombies

-- MAIN APPLICATION
addappid(2068230)
-- Game: addappid(2068230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068232,0,"a4668a4d0735967c31d93969d26f1070d703e7003058a8172c9b9b16794f79a0")
