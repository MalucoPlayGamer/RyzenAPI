-- Lua provided by RyzenAPI
-- Game: Witchaven II: Blood Vengeance

-- MAIN APPLICATION
addappid(1655430)
-- Game: addappid(1655430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655431, 1, "b62ebd249c8ec3ecb807a53ce1f3d4a77bc30513c908c1ac10295436bd790bcb")
