-- Lua provided by RyzenAPI
-- Game: addappid(2399730)

-- MAIN APPLICATION
addappid(2399730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399731, 1, "66cda9db2dc9bdde03391ee1cc314e13e0dbb8e06d08220bac453cf3012e97e5")
