-- Lua provided by RyzenAPI
-- Game: AppID 107600

-- MAIN APPLICATION
addappid(107600)

-- MAIN APP DEPOTS / PACKAGES
addappid(107601, 1, "873d6866f6c021c7f22d5b3c7d4305f1dc0744e08855c0167c53b249c6b6d0ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(232990)
