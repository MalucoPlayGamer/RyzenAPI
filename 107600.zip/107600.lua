-- Lua provided by RyzenAPI
-- Game: addappid(107600)

-- MAIN APPLICATION
addappid(107600)

-- MAIN APP DEPOTS / PACKAGES
addappid(107601, 1, "873d6866f6c021c7f22d5b3c7d4305f1dc0744e08855c0167c53b249c6b6d0ab")
