-- Lua provided by RyzenAPI
-- Game: AppID 985810

-- MAIN APPLICATION
addappid(985810)

-- MAIN APP DEPOTS / PACKAGES
addappid(985811, 1, "6111bbf3bb4f0d09da16fb01371c5c9357c24486eb64467729691a65d2a4bb9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
