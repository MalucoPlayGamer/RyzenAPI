-- Lua provided by RyzenAPI
-- Game: AppID 985810

-- MAIN APPLICATION
addappid(985810)
-- Game: addappid(985810)

-- MAIN APP DEPOTS / PACKAGES
addappid(985811, 1, "6111bbf3bb4f0d09da16fb01371c5c9357c24486eb64467729691a65d2a4bb9b")
