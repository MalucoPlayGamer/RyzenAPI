-- Lua provided by SkyAPI 
-- Game: Hero of the Kingdom II
addappid(346560)
addappid(346561, 1, "6f71e2a54e367d2324fedf1db05a22dc4f3d32642b3356597d083e90feed5146")
addappid(346562, 1, "eacbe713a43332047686ab669b3f8a7597926cc9cab54795dd541e1f77e6af2a")
addappid(346563, 1, "853bbe8847a729530199c1fc861d3df26ced573f10df5366ff28f9de0df0e0b6")
addappid(346564, 1, "b176817f4ee355a54a755d2fe2996ad78a9f06ee20d506d45c946e81f3d422c7")
