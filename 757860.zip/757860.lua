-- Lua provided by RyzenAPI
-- Game: Elbub

-- MAIN APPLICATION
addappid(757860)

-- MAIN APP DEPOTS / PACKAGES
addappid(757861, 1, "e3dd886d4b3f1ab140eb74c6a269d7058bbe12f4828e9855006fa6c017411d1f")
