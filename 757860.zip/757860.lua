-- Lua provided by RyzenAPI
-- Game: Elbub

-- MAIN APPLICATION
addappid(757860)

-- MAIN APP DEPOTS / PACKAGES
addappid(757861, 1, "e3dd886d4b3f1ab140eb74c6a269d7058bbe12f4828e9855006fa6c017411d1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
