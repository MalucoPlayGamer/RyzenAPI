-- Lua provided by RyzenAPI
-- Game: addappid(337070)

-- MAIN APPLICATION
addappid(229004)
addappid(337070)
addappid(337071)
addappid(337073)
addappid(337074)

-- MAIN APP DEPOTS / PACKAGES
addappid(337072,0,"e82a26b3a9166721d70afc797b393fa5e771e551dda3290c89da20a614480fca")
