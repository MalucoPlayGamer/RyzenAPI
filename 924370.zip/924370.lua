-- Lua provided by RyzenAPI 
-- Game: AppID 924370
addappid(924370)
addappid(924371, 1, "2d13fd29401e133684df102f9fa13fd5efd0f0370b0b1933c83525040c148bd1")
addappid(924372, 1, "fdc125bbee505ceabd5b72250447b58a1e36730821ee56c37bfa71e08ea51901")
addappid(962120, 0, "124c47704b4f2dcedf18cd070f62e45b3125a6b15a3f1e2ff5ea898ad0f79d6b")
