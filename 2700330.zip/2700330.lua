-- Lua provided by RyzenAPI
-- Game: Dungeonborne Demo

-- MAIN APPLICATION
addappid(228983)
addappid(228989)
addappid(228990)
addappid(2700330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700332,0,"48edebacc91502934a382c0c2bc9dc6a175017c136a7d351b21f29cddb82722b")

