-- Lua provided by RyzenAPI 
-- Game: Pygmalion
addappid(2234960)
addappid(2234961, 1, "4372946a9483a166fcb5b99deb00f4680d07e1c922d7e2817f99a0e7276c0ea6")
