-- Lua provided by RyzenAPI
-- Game: 1022503

-- MAIN APPLICATION
addappid(1022503)
-- Game: addappid(1022503)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022503,0,"37da81c869a28ae17524fec02c127da9cf3f0b08c0f2fa577b736ae964bb3b62")
