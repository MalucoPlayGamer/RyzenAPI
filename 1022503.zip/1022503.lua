-- Lua provided by RyzenAPI
-- Game: DFF NT: Away Uniform Appearance Set for Jecht

-- MAIN APPLICATION
addappid(1022503)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022503,0,"37da81c869a28ae17524fec02c127da9cf3f0b08c0f2fa577b736ae964bb3b62")

