-- Lua provided by RyzenAPI
-- Game: Legacy: Steel & Sorcery Playtest

-- MAIN APPLICATION
addappid(2890530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890531, 1, "2968ff1582889315c35158e34a88c486acba6b3c2fad5a82c95e9a626a7517bd")

