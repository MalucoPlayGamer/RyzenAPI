-- Lua provided by RyzenAPI
-- Game: With You

-- MAIN APPLICATION
addappid(1860570)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1862800)
