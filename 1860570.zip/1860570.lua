-- Lua provided by RyzenAPI
-- Game: With You

-- MAIN APPLICATION
addappid(1860570)
addappid(1862800)

