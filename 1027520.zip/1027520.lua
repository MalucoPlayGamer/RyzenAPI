-- Lua provided by RyzenAPI
-- Game: Hentai Waifu Vol.1

-- MAIN APPLICATION
addappid(1027520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027521, 1, "c5950ca705cc953af9085daf9fe4e87f9741dc59b35cd28afa0ef27b330422e1")
addappid(1036770, 0, "35b9abb1dfe83c441479d2d1bbd3c15e66407c45ccb6243c36c6bac2dfe55b77")
addappid(1036771, 0, "ff2e09b019eb9e83895f459787277623fd6438aa879dc5e65c7b39ed5f2c9dde")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
