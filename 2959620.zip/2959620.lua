-- Lua provided by SkyAPI 
-- Game: AppID 2959620
addappid(2959620)
addappid(2959621, 1, "027ee09e6b463550f397955c7f4390100a34f67ec458fd9ea06f0ee53331cc61")
