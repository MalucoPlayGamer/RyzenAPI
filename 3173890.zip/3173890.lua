-- Lua provided by RyzenAPI
-- Game: 3173890

-- MAIN APPLICATION
addappid(3173890)
addappid(3232020)
-- Game: addappid(3173890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173891, 1, "b1b0dca7170ade96885117a42fb8cd65a82b965146f10583c9bf5622002843dc")
