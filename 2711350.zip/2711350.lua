-- Lua provided by RyzenAPI
-- Game: 2711350

-- MAIN APPLICATION
addappid(2711350)
-- Game: addappid(2711350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711351, 1, "ead0ba6330c4c04020afb24698ad3a772a5fe60fce741e8246c93fcd6f1fc826")
addappid(2711352, 1, "061b80953d2454aab4b2b27bbca7d88be9c811aa0791fae9013a37c8fe3fabca")
