-- Lua provided by RyzenAPI
-- Game: FUCK STALIN

-- MAIN APPLICATION
addappid(2711350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2711351, 1, "ead0ba6330c4c04020afb24698ad3a772a5fe60fce741e8246c93fcd6f1fc826")
addappid(2711352, 1, "061b80953d2454aab4b2b27bbca7d88be9c811aa0791fae9013a37c8fe3fabca")

