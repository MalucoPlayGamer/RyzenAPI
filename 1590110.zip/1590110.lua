-- Lua provided by RyzenAPI
-- Game: Game: eteeConnect

-- MAIN APPLICATION
addappid(1590110)
-- Game: addappid(1590110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590111, 1, "9b197545d3e7a0d3d1255ff81660c5be036a611eadfce5b802c49e0d57cd9cd7")
addappid(1590112, 1, "e20f152526d2c781ceee594b4dea9fd2efb9e82586735d2176246e45df95bde5")
