-- Lua provided by SkyAPI 
-- Game: AppID 1451490
addappid(1451490)
addappid(1451491, 1, "82044b0a31caa1cfb336c6a6d6255220f4aefa2e744df742d51c63d376c9491f")
