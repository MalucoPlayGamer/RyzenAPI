-- Lua provided by RyzenAPI
-- Game: Faircroft's Antiques: The Heir of Glen Kinnoch

-- MAIN APPLICATION
addappid(1550380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550381, 1, "bc053fcc49333d6eed630edb6e9d7ba50f26190ed819a535d53910d3fbed0b77")
