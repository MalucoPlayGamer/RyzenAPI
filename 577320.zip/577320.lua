-- Lua provided by RyzenAPI
-- Game: Quantic Pinball

-- MAIN APPLICATION
addappid(577320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(577321, 1, "60c7a59b1c1f82e9d9607f8f3d6551ed54ea41fb71410bf7451cb37b3364c6e0")

