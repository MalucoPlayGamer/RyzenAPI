-- Lua provided by RyzenAPI
-- Game: 577320

-- MAIN APPLICATION
addappid(577320)
-- Game: addappid(577320)

-- MAIN APP DEPOTS / PACKAGES
addappid(577321, 1, "60c7a59b1c1f82e9d9607f8f3d6551ed54ea41fb71410bf7451cb37b3364c6e0")
