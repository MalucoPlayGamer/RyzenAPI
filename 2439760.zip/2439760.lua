-- Lua provided by RyzenAPI
-- Game: 要来点百合吗 Love Yuri

-- MAIN APPLICATION
addappid(2439760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439761, 1, "e2b05f84a7751bcba6fddee18cb207ccc206256e961db5aff320a4389373978d")
addappid(2439762, 1, "91786e44e70d4a16f370fdc2c6e994563fefb087824391ae60a39c2cd3bea14d")
addappid(2439763, 1, "c11863036baca6369ecca9f0448af216d490c3093e335a99039e70dda37ad878")

