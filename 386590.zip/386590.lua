-- Lua provided by RyzenAPI
-- Game: Game: Novus Inceptio

-- MAIN APPLICATION
addappid(386590)
-- Game: addappid(386590)

-- MAIN APP DEPOTS / PACKAGES
addappid(386591, 1, "417983ea40339fc00056a67f05b464ce7fb2d5b4f73764da096eefb4ea6b7513")
addappid(425270, 0, "85d931271b89c7da8ce706716b5e4bd080812ca7c4580e627fa1799f23f04403")
