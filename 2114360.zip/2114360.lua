-- Lua provided by RyzenAPI
-- Game: Maze Blaze

-- MAIN APPLICATION
addappid(2114360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114361, 1, "3cde248f885f5b42730a64b2e5dcaeb6cedfdb99db83fab29f5b6fc32e2fc3dd")
