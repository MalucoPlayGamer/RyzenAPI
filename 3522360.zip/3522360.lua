-- Lua provided by RyzenAPI
-- Game: WARSHIFT 2

-- MAIN APPLICATION
addappid(3522360) -- WARSHIFT 2

-- MAIN APP DEPOTS / PACKAGES
addappid(3522361, 1, "ca2a9213270ea7601b864b4b8eb21911af9fd39fc33b1a7b07d5c9cc04cafe4a") -- Depot 3522361

