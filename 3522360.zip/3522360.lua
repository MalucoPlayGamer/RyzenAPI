-- 3522360's Lua and Manifest Created by Hubcap Manifest
-- WARSHIFT 2
-- Created: August 01, 2026 at 08:38:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3522360) -- WARSHIFT 2
-- MAIN APP DEPOTS
addappid(3522361, 1, "ca2a9213270ea7601b864b4b8eb21911af9fd39fc33b1a7b07d5c9cc04cafe4a") -- Depot 3522361
setManifestid(3522361, "3152642484010303935", 8962590592)