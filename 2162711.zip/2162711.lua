-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2162711)
-- Game: addappid(2162711)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162711,0,"d6142a486110fb9b075cf468d88491dfbe91110a73ca2659887e3b45bc78e50b")
