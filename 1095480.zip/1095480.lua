-- Lua provided by RyzenAPI
-- Game: Operation Valor

-- MAIN APPLICATION
addappid(1095480)
addappid(2634660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1095481, 1, "8847d7bbdb5c3bdae67c0c3fe93d2d1c1c89ac7e1542d0febcaea7b5f5a80885")

