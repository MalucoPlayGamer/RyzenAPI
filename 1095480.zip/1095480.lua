-- Lua provided by RyzenAPI
-- Game: Operation Valor

-- MAIN APPLICATION
addappid(1095480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095481, 1, "8847d7bbdb5c3bdae67c0c3fe93d2d1c1c89ac7e1542d0febcaea7b5f5a80885")
