-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID Δ: SNAKE EATER

-- MAIN APPLICATION
addappid(2417610)
addappid(2881290)
addappid(3364840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2417611, 1, "9a9b7b9956ecfecde761c3ec639b3c9efcc0e38d3b11a153d66014a015a8004d")

