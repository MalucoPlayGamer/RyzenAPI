-- Lua provided by RyzenAPI
-- Game: Game: METAL GEAR SOLID Δ: SNAKE EATER

-- MAIN APPLICATION
addappid(2417610)
addappid(3364840)
-- Game: addappid(2417610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417611, 1, "9a9b7b9956ecfecde761c3ec639b3c9efcc0e38d3b11a153d66014a015a8004d")
