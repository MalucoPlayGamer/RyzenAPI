-- Lua provided by RyzenAPI
-- Game: 2185350

-- MAIN APPLICATION
addappid(2185350)
-- Game: addappid(2185350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185350,0,"61b9c02cdb73230465d0c0bc8c7464cb3d3a1c7c153c2273698f8e39f6651ae4")
