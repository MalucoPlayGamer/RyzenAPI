-- Lua provided by RyzenAPI
-- Game: 2772390

-- MAIN APPLICATION
addappid(2772390)
-- Game: addappid(2772390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772391, 1, "0bbfe92c11f95b4325fe90f80547ba3d9408fd6ffd23cdde11aefdf5685e1e13")
