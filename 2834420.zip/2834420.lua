-- Lua provided by RyzenAPI
-- Game: Dead Faces Demo "A Fractured Mind"

-- MAIN APPLICATION
addappid(2834420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834421, 1, "56f06fc60329066b640ee13481fbb1c422bbd3cd6aa11dd91501505ebc66964e")

