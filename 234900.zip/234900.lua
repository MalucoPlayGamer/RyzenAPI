-- Lua provided by RyzenAPI
-- Game: Game: Anodyne

-- MAIN APPLICATION
addappid(234900)
-- Game: addappid(234900)

-- MAIN APP DEPOTS / PACKAGES
addappid(234901, 1, "eb7cfab30c6ce64f0ecf257a807cc6f7977ff59750df2b813779e523f7654ea2")
addappid(234902, 1, "385f0b8cd815b2eeb0a8b16a0fdf564d6198e4db6ca9d34f4332a9ae0eeef654")
addappid(234903, 1, "3d31e5fc233db99d19cc2b74b991e265ec4b70440930a387fbc7aa0b08e33dee")
