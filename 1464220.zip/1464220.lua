-- Lua provided by RyzenAPI
-- Game: Netherguild

-- MAIN APPLICATION
addappid(1464220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464221, 1, "d7c23e22b95524e315ee85e78f604c16b28a0ec9c841e3802f926b9538a03802")

