-- Lua provided by RyzenAPI
-- Game: No1Left

-- MAIN APPLICATION
addappid(409580)
-- Game: addappid(409580)

-- MAIN APP DEPOTS / PACKAGES
addappid(409581, 1, "6186568b1b17a79b65b1120274347d3f16c4118c98916af2c85eec69570896e0")
