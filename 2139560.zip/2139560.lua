-- Lua provided by RyzenAPI
-- Game: 2139560

-- MAIN APPLICATION
addappid(2139560)
-- Game: addappid(2139560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139561, 1, "8e966a9ccc1cced316136b879c3836fa91675b869b970a76faaf63ebc5668f6a")
