-- Lua provided by RyzenAPI
-- Game: The Dungeon Of Naheulbeuk: The Amulet Of Chaos

-- MAIN APPLICATION
addappid(970830)
addappid(1403630)
addappid(1491140)
addappid(1633910)
addappid(1655780)
addappid(1928750)

-- MAIN APP DEPOTS / PACKAGES
addappid(970831,0,"5083e322624b9b8097da5663a29dd2fc88e71c4c6a58acf354ff5678e032f3d1")
addappid(970832,0,"3bce2808b8be17649c020d0419623ff3ab49569cdc4eb6614406ef3a3cc8b22f")
addappid(1403630,0,"2957f4623bd3d0c26ec41d56c0e21856bcc8c16bac6185870a164b40a3a28f7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
