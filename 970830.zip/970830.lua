-- Lua provided by RyzenAPI 
-- Game: The Dungeon Of Naheulbeuk: The Amulet Of Chaos
addappid(970830)
addappid(970831, 1, "5083e322624b9b8097da5663a29dd2fc88e71c4c6a58acf354ff5678e032f3d1")
addappid(970832, 1, "3bce2808b8be17649c020d0419623ff3ab49569cdc4eb6614406ef3a3cc8b22f")
addappid(1403630, 0, "2957f4623bd3d0c26ec41d56c0e21856bcc8c16bac6185870a164b40a3a28f7f")
