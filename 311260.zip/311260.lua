-- Lua provided by RyzenAPI
-- Game: The Guild 3

-- MAIN APPLICATION
addappid(311260)

-- MAIN APP DEPOTS / PACKAGES
addappid(311261, 1, "a8d4b9a551d2e5ad7517f040e5048d92bd66197e507737de0a7060f2e6b2b530")
