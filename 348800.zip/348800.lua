-- Lua provided by RyzenAPI
-- Game: Chester One

-- MAIN APPLICATION
addappid(348800)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(348801, 1, "e5ff965f9c153b62a928e98d9405506d116e17b86acdde5c988703da51e2970e")
