-- Lua provided by RyzenAPI
-- Game: addappid(348800)

-- MAIN APPLICATION
addappid(348800)

-- MAIN APP DEPOTS / PACKAGES
addappid(348801, 1, "e5ff965f9c153b62a928e98d9405506d116e17b86acdde5c988703da51e2970e")
