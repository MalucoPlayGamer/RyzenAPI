-- Lua provided by RyzenAPI 
-- Game: Synthetic Hazard
addappid(1440470)
addappid(1440471, 1, "3a751c6c57cc7a0989e3d7fcb7899defa81fafe9244b4f3aec0efc838d556acb")
