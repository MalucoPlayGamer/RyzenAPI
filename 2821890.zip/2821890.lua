-- Lua provided by RyzenAPI
-- Game: PegIdle

-- MAIN APPLICATION
addappid(2821890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821891, 1, "db00b506319e239cce561a811fb1143c1760b5c4af5d871836d3d2d5d2ebbf42")

