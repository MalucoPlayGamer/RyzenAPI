-- Lua provided by RyzenAPI
-- Game: Soda Girls

-- MAIN APPLICATION
addappid(519080)

-- MAIN APP DEPOTS / PACKAGES
addappid(519081, 1, "3a4d8360c70775dbaa8f74610eb905f78b6b92eb3bfd0cfa96dec3bd8b3f1b5c")
addappid(519082, 1, "099e6115f3e3e936fc6ad1d069d82cf90021b8f02407989b777dcb10568d7607")
addappid(519085, 1, "9e1591dd7ad063d59d63616f5f00543f70c4b55dd448cf59afa330b0a16eb5f7")

