-- Lua provided by RyzenAPI
-- Game: Misericorde: Volume One

-- MAIN APPLICATION
addappid(1708110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708113,0,"ed69767ee508c177cfd2d7a6b7d5f7d00ab45bdd2ef503a52138874f6d708228")

