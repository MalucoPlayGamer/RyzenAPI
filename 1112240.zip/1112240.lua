-- Lua provided by RyzenAPI
-- Game: AppID 1112240

-- MAIN APPLICATION
addappid(1112240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112241, 1, "01cf48edd85a8acf2da9f06ea5ad922f5227699b1f863bff00e8f08ff671898e")

