-- Lua provided by RyzenAPI
-- Game: 376490

-- MAIN APPLICATION
addappid(376490)
-- Game: addappid(376490)

-- MAIN APP DEPOTS / PACKAGES
addappid(376491, 1, "c6f88570be53ef43daa5033ef5553dbf7f8728b7449f6aa2a88c62c0d306cf13")
