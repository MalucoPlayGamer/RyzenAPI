-- Lua provided by RyzenAPI
-- Game: Game: Kyvir: Rebirth

-- MAIN APPLICATION
addappid(1520270)
-- Game: addappid(1520270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520271, 1, "24b2d2b2103b46f5453b6ef2913385da32db3ceb0785b1fbb3518c0836e22d66")
addappid(1520272, 1, "099c72ee12efaf6c5bfff2b0cb82a12a1d477428bb55b7c1639fcb4773316f3d")
addappid(1520273, 1, "0c408e419b597d2f70248b98825158468fde4e377366cd653034d0094af5d0a8")
