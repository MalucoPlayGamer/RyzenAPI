-- Lua provided by RyzenAPI
-- Game: addappid(1181150)

-- MAIN APPLICATION
addappid(1181150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181152,0,"98b1ea08821b48ca61fa6337da28b41c826e3a3f854a4d2b04adc5d635edd480")
