-- Generated with Luie @ https://lua.tools/
-- 1768400 - Archetype Arcadia
-- Generated 2026-07-30 17:08:33 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(1768400)

-- Main Depots
addappid(1768401, 1, "c4938990abc28a97aceddba7a470c6e225ec0c87f58c5c435d84a1f2d268f25e")
setManifestid(1768401, "1492432277725523795", 5089873532)
