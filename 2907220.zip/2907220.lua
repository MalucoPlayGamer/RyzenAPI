-- Lua provided by SkyAPI 
-- Game: AppID 2907220
addappid(2907220)
addappid(2907221, 1, "3ed5fea8497f8d23d9c59107df6304fcf67e5d323691e1a00451a81101362007")
addappid(2907222, 1, "e386e1bcbbc3b2eb04f122bf791ac6a63bd6b5e39e0ac037235f2925992d37a7")
