-- Lua provided by SkyAPI 
-- Game: AppID 1175150
addappid(1175150)
addappid(1175151, 1, "d747a1f73d7dafefbe93f1fdf8ba9e81d06722bd9522b978298332758e9f3678")
addappid(1175154, 1, "834f957a7e87e7cec8667921e54c11063db3a1e0da9e5ce1a27e22039087e876")
