-- Lua provided by RyzenAPI
-- Game: AppID 474220

-- MAIN APPLICATION
addappid(474220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(474221, 1, "af89aa8b7cfef6eb5f73cc7cd4bc1b4f1045c4cf6820b499450c914e0edb8d3a")

