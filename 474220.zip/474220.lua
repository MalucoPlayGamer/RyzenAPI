-- Lua provided by RyzenAPI
-- Game: 474220

-- MAIN APPLICATION
addappid(474220)
-- Game: addappid(474220)

-- MAIN APP DEPOTS / PACKAGES
addappid(474221, 1, "af89aa8b7cfef6eb5f73cc7cd4bc1b4f1045c4cf6820b499450c914e0edb8d3a")
