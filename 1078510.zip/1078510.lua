-- Lua provided by RyzenAPI
-- Game: Alluris

-- MAIN APPLICATION
addappid(1078510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078511, 1, "c7fe6c4fd1ef9289961461d0564095053e417e6be2b2b2a18a17ff1fc3dc9e35")

