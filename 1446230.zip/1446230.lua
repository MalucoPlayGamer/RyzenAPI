-- Lua provided by SkyAPI 
-- Game: Chasing Tail
addappid(1446230)
addappid(1446231, 1, "5f1d4cf666064d2ed6b977f6b1143ecbc1c6696b083b352cb99911b30e1fb497")
