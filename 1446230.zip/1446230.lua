-- Lua provided by RyzenAPI
-- Game: Chasing Tail

-- MAIN APPLICATION
addappid(1446230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446231, 1, "5f1d4cf666064d2ed6b977f6b1143ecbc1c6696b083b352cb99911b30e1fb497")
