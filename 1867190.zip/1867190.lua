-- Lua provided by RyzenAPI
-- Game: Wordle 5

-- MAIN APPLICATION
addappid(1867190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867191, 1, "cc4a1a8957d68985849093842694972822a6fed89d9932a7603ebbdfaba7d60c")
