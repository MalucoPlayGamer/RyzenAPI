-- Lua provided by RyzenAPI
-- Game: 热血大唐

-- MAIN APPLICATION
addappid(2718730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718731, 1, "d5c7583bf768f839222684a9e730132130d8d454d6c8c4502970f5ba482857d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
