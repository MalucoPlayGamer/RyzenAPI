-- Lua provided by RyzenAPI
-- Game: Game: 热血大唐

-- MAIN APPLICATION
addappid(2718730)
-- Game: addappid(2718730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718731, 1, "d5c7583bf768f839222684a9e730132130d8d454d6c8c4502970f5ba482857d8")
