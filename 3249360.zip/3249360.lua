-- Lua provided by RyzenAPI
-- Game: Math Dash

-- MAIN APPLICATION
addappid(3249360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249361, 1, "90246e42ecdd594dcd4cd87592e08438c1f95077b73d76c7c1785337a03023db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
