-- Lua provided by RyzenAPI
-- Game: Math Dash

-- MAIN APPLICATION
addappid(3249360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249361, 1, "90246e42ecdd594dcd4cd87592e08438c1f95077b73d76c7c1785337a03023db")
