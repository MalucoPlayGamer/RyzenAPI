-- Lua provided by RyzenAPI 
-- Game: Hover The Edge
addappid(1822130)
addappid(1822131, 1, "575900be7f4a5ce7ade066a7c2ba02b6e60b5cefd048e13e9ec5321cec3d8be1")
