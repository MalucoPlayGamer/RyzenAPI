-- Lua provided by RyzenAPI
-- Game: 1822130

-- MAIN APPLICATION
addappid(1822130)
-- Game: addappid(1822130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822131, 1, "575900be7f4a5ce7ade066a7c2ba02b6e60b5cefd048e13e9ec5321cec3d8be1")
