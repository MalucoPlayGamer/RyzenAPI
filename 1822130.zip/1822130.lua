-- Lua provided by RyzenAPI
-- Game: Hover The Edge

-- MAIN APPLICATION
addappid(1822130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822131, 1, "575900be7f4a5ce7ade066a7c2ba02b6e60b5cefd048e13e9ec5321cec3d8be1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
