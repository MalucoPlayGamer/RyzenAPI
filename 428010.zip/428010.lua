-- Lua provided by RyzenAPI
-- Game: Pony Island - Soundtrack

-- MAIN APPLICATION
addappid(428010)

-- MAIN APP DEPOTS / PACKAGES
addappid(428010,0,"5e84018c049ec4469792725fea17efa1d9677b654f0b1aa13f5b82747b988f56")
