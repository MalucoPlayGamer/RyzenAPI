-- Lua provided by RyzenAPI
-- Game: addappid(1158390)

-- MAIN APPLICATION
addappid(1158390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158391, 1, "0bd19ea9050bb74272ef80a99be61ee1061a80cf3a5612b19224d665ef0a0793")
