-- Lua provided by RyzenAPI
-- Game: Game: AppID 562450

-- MAIN APPLICATION
addappid(562450)
-- Game: addappid(562450)

-- MAIN APP DEPOTS / PACKAGES
addappid(562451, 1, "abec4368d452434dda16b20606839e2953c932686453e35a118c1651f1b82b42")
