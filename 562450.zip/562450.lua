-- Lua provided by SkyAPI 
-- Game: AppID 562450
addappid(562450)
addappid(562451, 1, "abec4368d452434dda16b20606839e2953c932686453e35a118c1651f1b82b42")
