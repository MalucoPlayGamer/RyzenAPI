-- Lua provided by RyzenAPI
-- Game: Game: Abandoned Void

-- MAIN APPLICATION
addappid(2420450)
-- Game: addappid(2420450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420451, 1, "d4b6b14b850e2f20ffb1fba3c873a19e8ce05b4fbf94a0cb8d6f643bfcc8e4e7")
