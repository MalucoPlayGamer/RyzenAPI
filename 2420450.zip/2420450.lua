-- Lua provided by RyzenAPI
-- Game: Abandoned Void

-- MAIN APPLICATION
addappid(2420450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420451, 1, "d4b6b14b850e2f20ffb1fba3c873a19e8ce05b4fbf94a0cb8d6f643bfcc8e4e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
