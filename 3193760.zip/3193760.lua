-- Lua provided by RyzenAPI
-- Game: Mecha Force VR

-- MAIN APPLICATION
addappid(3193760)
-- Game: addappid(3193760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193761, 1, "5036a9ca323ab0c24425be42f5494c2ec2b13f7bcb8438a91a9f0222bdd310bc")
