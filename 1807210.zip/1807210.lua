-- Lua provided by RyzenAPI
-- Game: Game: AppID 1807210

-- MAIN APPLICATION
addappid(1807210)
-- Game: addappid(1807210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807211, 1, "f088c854cc8c670d2505d6dec71062f6b8f8bb23004e5393a76862c02e3aa14f")
