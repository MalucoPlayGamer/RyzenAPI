-- Lua provided by RyzenAPI
-- Game: Stray Souls

-- MAIN APPLICATION
addappid(1807210)
addappid(2633770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1807211, 1, "f088c854cc8c670d2505d6dec71062f6b8f8bb23004e5393a76862c02e3aa14f")
