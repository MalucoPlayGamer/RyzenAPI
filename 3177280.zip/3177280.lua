-- Lua provided by SkyAPI 
-- Game: Restaurant Owner: A Restaurant Simulator
addappid(3177280)
addappid(3177281, 1, "6c9133f012064d1f85a533bb0131a64ccbe4eb14146efffd74e6d9344e3aa52d")
