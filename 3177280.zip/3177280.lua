-- Lua provided by RyzenAPI
-- Game: 3177280

-- MAIN APPLICATION
addappid(3177280)
-- Game: addappid(3177280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177281, 1, "6c9133f012064d1f85a533bb0131a64ccbe4eb14146efffd74e6d9344e3aa52d")
