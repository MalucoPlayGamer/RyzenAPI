-- Lua provided by RyzenAPI
-- Game: AppID 1301970

-- MAIN APPLICATION
addappid(1301970)
-- Game: addappid(1301970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301971, 1, "a871780280218c83a1d5a4e67e84c81cf0c1cffc16d84c2b24236c84d41afd73")
