-- Lua provided by RyzenAPI
-- Game: addappid(1836120)

-- MAIN APPLICATION
addappid(1836120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836121, 1, "f849496b103435e0bed13166cc8469f528bcc0415aec9c5ec338bdc5be48d44f")
