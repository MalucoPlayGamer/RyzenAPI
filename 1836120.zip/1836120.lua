-- Lua provided by RyzenAPI
-- Game: QUICKERFLAK

-- MAIN APPLICATION
addappid(1836120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1836121, 1, "f849496b103435e0bed13166cc8469f528bcc0415aec9c5ec338bdc5be48d44f")

