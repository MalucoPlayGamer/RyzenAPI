-- Lua provided by RyzenAPI
-- Game: BioBot Guide: SexySync

-- MAIN APPLICATION
addappid(4087770) -- BioBot Guide: SexySync
addappid(4937530)
addappid(5051270)
addappid(5051280)
addappid(5051290)
-- addappid(4937510) -- BioBotGuide - Chara Pack I (unreleased)
-- addappid(4937520) -- BioBotGuide - Chara Pack II (unreleased)

-- MAIN APP DEPOTS / PACKAGES
addappid(4087771, 1, "71e7311717ce783622f1847537116434eb0d069f87c81b3e290a6bccc165a250") -- Depot 4087771

