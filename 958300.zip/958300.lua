-- Lua provided by RyzenAPI
-- Game: 958300

-- MAIN APPLICATION
addappid(958300)
-- Game: addappid(958300)

-- MAIN APP DEPOTS / PACKAGES
addappid(958301, 1, "bfef5c183ba68925e51b6cd66d48944bcf8670e0b06a05da4f3eb62b7aa83cdb")
