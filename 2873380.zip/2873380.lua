-- Lua provided by RyzenAPI
-- Game: Chaotic Conflicts

-- MAIN APPLICATION
addappid(2873380)
-- Game: addappid(2873380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873381, 1, "80bffd0aaf4696327fbb83f456b99767e6dff997d79b50bf99a276f9ed918c2c")
