-- 1983620's Lua and Manifest Created by Hubcap Manifest
-- Infinitevania
-- Created: July 25, 2026 at 06:04:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1983620, 1, "4ce3f6450809f344c83eb0ef7c04716e0748ad484165c41b1fe919c2a4d0a288") -- Infinitevania
-- MAIN APP DEPOTS
addappid(1983621, 1, "7c6d0fc99a8ab1a451f34f0c5e78a765bd61837588f85a2274c260c4cefda3ba") -- Depot 1983621
setManifestid(1983621, "1268406520585621933", 2810226567)