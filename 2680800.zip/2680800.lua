-- Lua provided by RyzenAPI
-- Game: addappid(2680800)

-- MAIN APPLICATION
addappid(2680800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680801, 1, "9e59248d6be7761221839cd9bfbcab2a75405fc5aaeaeb08024e87aa16d72cfa")
