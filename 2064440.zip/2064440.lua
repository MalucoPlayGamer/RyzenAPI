-- Lua provided by RyzenAPI
-- Game: DORAEMON STORY OF SEASONS: Friends of the Great Kingdom Digital Soundtrack

-- MAIN APPLICATION
addappid(2064440)
-- Game: addappid(2064440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064441, 1, "25d9e3b93c490e10c0e0db47a5b9098975a5076137d56149a1990640685cfa67")
