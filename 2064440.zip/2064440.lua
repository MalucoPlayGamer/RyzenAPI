-- Lua provided by SkyAPI 
-- Game: DORAEMON STORY OF SEASONS: Friends of the Great Kingdom Digital Soundtrack
addappid(2064440)
addappid(2064441, 1, "25d9e3b93c490e10c0e0db47a5b9098975a5076137d56149a1990640685cfa67")
