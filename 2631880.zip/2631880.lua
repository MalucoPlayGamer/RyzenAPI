-- Lua provided by RyzenAPI
-- Game: Don't Be Afraid 2

-- MAIN APPLICATION
addappid(2631880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631881, 1, "17b0315433bac1bbd20f7646628acd3d1846f2dd26aaeab0453dd7262cc54fab")

