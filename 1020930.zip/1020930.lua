-- Lua provided by RyzenAPI
-- Game: 1020930

-- MAIN APPLICATION
addappid(1020930)
-- Game: addappid(1020930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020931, 1, "99cacdb98524b3a68738ad15a8b099680b1afe234e3a5814a1158465fab1cbe0")
