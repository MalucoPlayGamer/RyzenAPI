-- Lua provided by RyzenAPI
-- Game: Balloon Blast

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1294720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294722,0,"6abd4ceffecd671ef81024b3a3206b446a2e878f0c5d0eb3a307a77297d689ee")

