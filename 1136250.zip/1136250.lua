-- Lua provided by RyzenAPI
-- Game: Forep Man

-- MAIN APPLICATION
addappid(1136250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136251, 1, "c6d0476ef86c307cd598974c215acfa3872813347387477758ee1e6b534a47df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
