-- Lua provided by RyzenAPI
-- Game: AppID 1036120

-- MAIN APPLICATION
addappid(1036120)
-- Game: addappid(1036120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036121, 1, "cc73bf5687484b054156d350182de714cc0f63b9571f1f04d3a3b507c48fac0b")
