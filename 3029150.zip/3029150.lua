-- Lua provided by RyzenAPI 
-- Game: Rift of the NecroDancer Demo
addappid(3029150)
addappid(3029151, 1, "62f1ff31425c8d54acf72bd13bd80f8c5bd405ec2e1c176b249d1058edd7ec75")
