-- Lua provided by RyzenAPI
-- Game: AppID 624910

-- MAIN APPLICATION
addappid(624910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(624911, 1, "64bb80d9e250544ec2b0dd4019bad0e8c417d47013a73b8414cebf77945e255a")

