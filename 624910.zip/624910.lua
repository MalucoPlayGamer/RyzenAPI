-- Lua provided by SkyAPI 
-- Game: AppID 624910
addappid(624910)
addappid(624911, 1, "64bb80d9e250544ec2b0dd4019bad0e8c417d47013a73b8414cebf77945e255a")
