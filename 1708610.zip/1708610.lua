-- Lua provided by RyzenAPI
-- Game: Pretty Girls Breakout!

-- MAIN APPLICATION
addappid(1708610)
-- Game: addappid(1708610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708611, 1, "ba097317a1283a3421bbb70594a9b2427eb6e4e523101b1382a1d6e94e4a57eb")
