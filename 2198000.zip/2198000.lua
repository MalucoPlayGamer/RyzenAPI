-- Lua provided by RyzenAPI
-- Game: addappid(2198000)

-- MAIN APPLICATION
addappid(2198000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198001, 1, "7229b2751fa29163641dd7653bec56b89d197ad0076a451c67afe0f931ac3e0b")
