-- Lua provided by RyzenAPI
-- Game: AppID 338550

-- MAIN APPLICATION
addappid(338550)

-- MAIN APP DEPOTS / PACKAGES
addappid(338551, 1, "fe4b167dde49b12ceda8790ca1f6894faa4875f2cefd28f686fdc381c292b2e1")
