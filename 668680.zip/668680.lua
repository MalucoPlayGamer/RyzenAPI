-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(229020)
addappid(668680)
-- Game: addappid(668680)

-- MAIN APP DEPOTS / PACKAGES
addappid(668682,0,"c63faa9f029bb03004de50b487613003362bba1e977bc417880d8c19afbe7e8c")
