-- Lua provided by RyzenAPI
-- Game: Start11

-- MAIN APPLICATION
addappid(1811010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811011, 1, "c8dcfd7e48dcf5c9b60a0fd67d100b876c5662f1660017c2261ab120b01b8510")
