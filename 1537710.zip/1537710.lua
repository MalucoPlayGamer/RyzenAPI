-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: Little Hope - Friend's Pass

-- MAIN APPLICATION
addappid(1537710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1537711, 1, "5ed5d4e4aa8999d451fb5f7a639deb8d092f18dd46e96a5d9e80deee0286244a")

