-- Lua provided by RyzenAPI
-- Game: AppID 1537710

-- MAIN APPLICATION
addappid(1537710)
-- Game: addappid(1537710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537711, 1, "5ed5d4e4aa8999d451fb5f7a639deb8d092f18dd46e96a5d9e80deee0286244a")
