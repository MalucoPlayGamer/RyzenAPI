-- Lua provided by RyzenAPI
-- Game: addappid(3088750)

-- MAIN APPLICATION
addappid(3088750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088751, 1, "226efb72ae4bab7d9f3f88c0b938b8b6999dd114ecf30263bb71284e92f93f53")
