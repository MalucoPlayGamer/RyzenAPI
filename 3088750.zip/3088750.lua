-- Lua provided by RyzenAPI
-- Game: Albert's Ark Idle

-- MAIN APPLICATION
addappid(3088750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(3088751, 1, "226efb72ae4bab7d9f3f88c0b938b8b6999dd114ecf30263bb71284e92f93f53")

