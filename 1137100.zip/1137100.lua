-- Lua provided by RyzenAPI
-- Game: Twice Reborn: a vampire visual novel

-- MAIN APPLICATION
addappid(1137100)
addappid(2080550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137101, 1, "137dafcea93f98f8a097e4249e945e56f269965641fcb0463f4d7d1b365895e4")

