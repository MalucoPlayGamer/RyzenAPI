-- Lua provided by RyzenAPI
-- Game: AppID 1137100

-- MAIN APPLICATION
addappid(1137100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137101, 1, "137dafcea93f98f8a097e4249e945e56f269965641fcb0463f4d7d1b365895e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2080550)
