-- Lua provided by RyzenAPI 
-- Game: Before Exit: Supermarket
addappid(2983730)
addappid(2983731, 1, "ee2b9cd6f0fa0865ea31b15ae33e22915af46b68cea496c713c8ef5d29c68104")
