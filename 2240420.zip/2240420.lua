-- Lua provided by RyzenAPI
-- Game: Polterguys: Possession Party Demo

-- MAIN APPLICATION
addappid(2240420)
-- Game: addappid(2240420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240421, 1, "0bfa6221672b4c9cb253d6d4a3bf6069ba6594ed57d1f3a3020e7a3801b2a5b2")
