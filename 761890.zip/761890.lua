-- Lua provided by RyzenAPI
-- Game: AppID 761890

-- MAIN APPLICATION
addappid(761890)

-- MAIN APP DEPOTS / PACKAGES
addappid(761891, 1, "297a0e22aaa5d838277dba6e41e82a90cdcb3f406bc6d93ca39a2f2162f1b9d1")
addappid(761892, 1, "7a972341f3c292c06602f26eed648f0ba35a75c43fe061d7d2e9a9b330688086")
addappid(761893, 1, "41b1c12143621dde6157548023a4d729bc1d2338b827b767bbe2a49c34dd1ea2")
addappid(761894, 1, "3a1dba4e8fd50b4f61efeb96ccb9bf25908bc1d11969dae1a29b3668265a3c4a")
addappid(761895, 1, "86fa8ae9aff14190df9603536e83afc8f02b4ce730398f726ccdfc4b7b1d4657")
addappid(761896, 1, "b17f224819d7e45e4b15dd9fde243c5acbcdbe6ff4c972bfbaf760cf1bf6a0d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(790923)
addappid(790924)
