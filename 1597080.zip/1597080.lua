-- Lua provided by RyzenAPI
-- Game: Killer Bean

-- MAIN APPLICATION
addappid(1597080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597081, 1, "cb2b9d73732faa89a876112cece3ee2200b2dc0c9db34b1d79c294def039f7fe")

