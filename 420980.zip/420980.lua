-- Lua provided by RyzenAPI
-- Game: Army Gals

-- MAIN APPLICATION
addappid(420980)
addappid(494260)

-- MAIN APP DEPOTS / PACKAGES
addappid(420981, 1, "6200883b50f664a096de9c14aff8907fbc24ac972809f07f3b27257ac7063933")
addappid(552650, 0, "58ccf0054d4c71307ca1bbed3ecd76edd8634c8f7f0a9d9b1e486a68f5b6eeb8")
addappid(552651, 0, "5757173d7d6d7ec2a8bab93503fa808b65ec9b57ec9a233132fa89de668906fd")
addappid(552652, 0, "d6f3e98d57df702ec1eab287ab8ed31fa8706deba46af42fe2eddd585b9c079d")
addappid(552653, 0, "bfb50d7357660680e67a8942f4a90fb783bbfa40c9916a15510923ee84b7705d")
