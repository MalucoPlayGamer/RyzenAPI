-- Lua provided by RyzenAPI
-- Game: Buttons Up! 2

-- MAIN APPLICATION
addappid(4708040) -- Buttons Up! 2

-- MAIN APP DEPOTS / PACKAGES
addappid(4708041, 1, "d5ac40886fe435a4158e15ae8721098639becbf3a74fc004b5aa0831787d9037") -- Depot 4708041
addappid(4708042, 1, "00bfd8a812dd6d8c1cbd18628fcfc58b96daf3c622212fb9668bc0969556504e") -- Depot 4708042
addappid(4708043, 1, "7fa5c651d28d796d84821a9610dab811523fe8e7fcbd30a724876d6646b00ee4") -- Depot 4708043

