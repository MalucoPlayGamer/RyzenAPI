-- Lua provided by RyzenAPI
-- Game: Alan's Automaton Workshop

-- MAIN APPLICATION
addappid(1289990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289991, 1, "5a4c90935f63054ad076a85ef165fef0f31d2464952f8837a68d1fb09e5064b6")

