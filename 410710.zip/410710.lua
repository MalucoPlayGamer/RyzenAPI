-- Lua provided by RyzenAPI
-- Game: 410710

-- MAIN APPLICATION
addappid(410710)
addappid(1364550)
-- Game: addappid(410710)

-- MAIN APP DEPOTS / PACKAGES
addappid(410711, 1, "366e2a5a2116895d93fd7c7c2f77a6d125fe5b9e34acad65e9f9f497521c4d12")
addappid(410712, 1, "f025932a6e27bfa5bc70f7acefcc516f97de2941e5304b2a70cd39996d681730")
addappid(1364440, 0, "9af4b814cbfa243f05c4b7eebd1c967ee96748752d4b3eb6c489e49c6edb4314")
