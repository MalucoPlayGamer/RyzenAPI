-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REMAKE INTERGRADE

-- MAIN APPLICATION
addappid(1462040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462041, 1, "4e299a23f9a767cbb2ea9a71d2fd2334b46e66904c51f2478e1b54994e7d33a9")
addappid(1462042, 1, "ac6881e562951d6369653f3e05bfbb32cb022208f25a950fd31e5045afe31498")
addappid(1462043, 1, "85dd87a3f14448b8659faa0acf1ec19c4213ea1096601adec258a00910b31cbb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
