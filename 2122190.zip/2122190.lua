-- Lua provided by RyzenAPI
-- Game: addappid(2122190)

-- MAIN APPLICATION
addappid(2122190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122192,0,"f4984230d5e55fe68e181d3f12df58e09845fdeac6116593157999a3e25e8ddf")
