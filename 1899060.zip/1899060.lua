-- Lua provided by SkyAPI 
-- Game: Pocket Mirror ~ GoldenerTraum
addappid(1899060)
addappid(1899061, 1, "030c9f637fe11abc1a8a13a6b1914824121f11b52e3fc7cfd134b372a6fc8bd4")
addappid(1899063, 1, "83c1d30b6ad29af0986517a00158d83fcd9307bc36d722292a428865b61778c1")
