-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Jouin High School Uniform (7), Battle BGM & Battle Jingle Set

-- MAIN APPLICATION
addappid(2924450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924450,0,"465e853c2d357a47955eb08ad98b3937f3107d290fade3a96de4439bf7222200")

