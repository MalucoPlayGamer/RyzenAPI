-- Lua provided by RyzenAPI
-- Game: Game: QT

-- MAIN APPLICATION
addappid(1182830)
-- Game: addappid(1182830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182831, 1, "cad0b1f1308b2840c8a3a7ba77e155d924d51a857e7952a0c9e29b27073211bf")
