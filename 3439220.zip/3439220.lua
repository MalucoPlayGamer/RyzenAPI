-- Lua provided by RyzenAPI
-- Game: Game: Trials of Innocence OST

-- MAIN APPLICATION
addappid(3439220)
-- Game: addappid(3439220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439221, 1, "1092c378a6580c3b7091463f0698a38b200174f9933b3452aae2518642482f45")
