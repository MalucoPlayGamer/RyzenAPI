-- Lua provided by RyzenAPI
-- Game: Lucy Dreaming

-- MAIN APPLICATION
addappid(1532710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532712,0,"9d0520c1b02e6085255437e42f5c03db708d10646669deeb9be2011e3c5b2707")

