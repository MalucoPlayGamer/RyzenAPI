-- Lua provided by RyzenAPI
-- Game: Game: RagBrawl

-- MAIN APPLICATION
addappid(2300280)
-- Game: addappid(2300280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300281, 1, "5f76da1f0bcac5696ca9b7c1abb343292cc4647b6a250b229da7c2ce5ce8daa6")
