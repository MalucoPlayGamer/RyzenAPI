-- Lua provided by RyzenAPI 
-- Game: Flower girl 2
addappid(1860860)
addappid(1860861, 1, "fa22774a9d0baeb0835562cc5e81a83b31895b24390bb91990cb91e68cf001d2")
addappid(2026550)
addappid(2026560, 0, "496c293603cf2024ec63f37569a3ef7370532af029584be370c5228e67ce2216")
