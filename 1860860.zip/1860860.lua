-- Lua provided by RyzenAPI
-- Game: Flower girl 2

-- MAIN APPLICATION
addappid(1860860)
addappid(2026550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860861, 1, "fa22774a9d0baeb0835562cc5e81a83b31895b24390bb91990cb91e68cf001d2")
addappid(2026560, 0, "496c293603cf2024ec63f37569a3ef7370532af029584be370c5228e67ce2216")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
