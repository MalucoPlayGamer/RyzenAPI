-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: The Devil In Me - Friend's Pass

-- MAIN APPLICATION
addappid(2285890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2285891, 1, "24b5bdd3937840f43270c8c888996d234871d5214a78a5e674358fcdbf804132")

