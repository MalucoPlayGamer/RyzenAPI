-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: The Devil In Me - Friend's Pass

-- MAIN APPLICATION
addappid(2285890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285891, 1, "24b5bdd3937840f43270c8c888996d234871d5214a78a5e674358fcdbf804132")

