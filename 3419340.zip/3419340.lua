-- Lua provided by RyzenAPI
-- Game: Virtua Fighter 5 R.E.V.O. World Stage - Pre-Production Artbook

-- MAIN APPLICATION
addappid(3419340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419340,0,"4b3635250f8302c53596898e27b028d2c0f4a1a05b4c29578ce06a634e9a1663")

