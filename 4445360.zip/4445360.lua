-- 4445360's Lua and Manifest Created by Hubcap Manifest
-- Grand Vegas Casino
-- Created: August 17, 2026 at 14:31:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4445360) -- Grand Vegas Casino
-- MAIN APP DEPOTS
addappid(4445361, 1, "e1c4fad3fa0dcd071e07194fe8c1de9b9949ab413838729dfc8fda4dcd6c1c77") -- Depot 4445361
setManifestid(4445361, "4821025087017095203", 151166093)