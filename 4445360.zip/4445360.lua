-- Lua provided by RyzenAPI
-- Game: Grand Vegas Casino

-- MAIN APPLICATION
addappid(4445360) -- Grand Vegas Casino

-- MAIN APP DEPOTS / PACKAGES
addappid(4445361, 1, "e1c4fad3fa0dcd071e07194fe8c1de9b9949ab413838729dfc8fda4dcd6c1c77") -- Depot 4445361

