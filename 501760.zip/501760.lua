-- Lua provided by RyzenAPI
-- Game: 501760

-- MAIN APPLICATION
addappid(501760)
-- Game: addappid(501760)

-- MAIN APP DEPOTS / PACKAGES
addappid(501761, 1, "55d609e1e0f72f6d09650c43e58c264b10dbfb77909ecc8b5cc40bb17c19aeea")
