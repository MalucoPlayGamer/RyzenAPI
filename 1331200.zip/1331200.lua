-- Lua provided by RyzenAPI
-- Game: Backfire

-- MAIN APPLICATION
addappid(1331200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331201, 1, "90d1bf123ffa49f305322abf23dc39081400243582fde4c13b0251d290fe65d2")

