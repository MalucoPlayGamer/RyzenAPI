-- Lua provided by RyzenAPI
-- Game: Z-Exemplar

-- MAIN APPLICATION
addappid(434750)
-- Game: addappid(434750)

-- MAIN APP DEPOTS / PACKAGES
addappid(434751, 1, "901cc7acaa84b04181694f060fa6ac5d5d099e6f02a998a2f8f4e00406dacacd")
addappid(434753, 1, "d71f31753134528440b2a53dea043b0fc034b7857eae346df42edc7b5d1e8181")
addappid(434755, 1, "70557cce07a1a2e6149039a6372f84e23e183e50d221ed2ff5991f44bacfc816")
