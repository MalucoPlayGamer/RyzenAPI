-- Lua provided by RyzenAPI
-- Game: Sharks and Minnows

-- MAIN APPLICATION
addappid(3446200)
-- Game: addappid(3446200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446201, 1, "cfbf694f31ee8e4a28819ae123115bf23ade614b426f3c0a92c477cc32bcba85")
