-- Lua provided by RyzenAPI
-- Game: Tricking 0

-- MAIN APPLICATION
addappid(1925560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925561, 1, "ee11deffff5e5fb42ecffbb8b2aa8c0ca6b6180ff1ef3801dc136236a8634bd7")
addappid(1925562, 1, "b75ca5d26ffe6c7132c38aa90be25f416dfecb0c6cac9acc50085b83d3809211")
addappid(1925563, 1, "e8e739f2df47d38ee3cc7c62f79916154b05dc7a12d6823050eeedf9db280416")
addappid(1925564, 1, "22ec762d0461a18544ef152da9cd0a136fd3e10ff97acf9bb509ce377cb081b4")

