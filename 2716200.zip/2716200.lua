-- Lua provided by RyzenAPI 
-- Game: VECTOR ZONE
addappid(2716200)
addappid(2716201, 1, "8fce22d2c9c78971c3b913f7a38770b510ad7259d8804d42221244d3892f028b")
