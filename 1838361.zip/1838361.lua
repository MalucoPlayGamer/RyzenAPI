-- Lua provided by RyzenAPI
-- Game: デラックス版特典

-- MAIN APPLICATION
addappid(1838361)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838361,0,"513885326156f6b05cb0e84aa92ba76680210f2b7b01416630ef4b489616bf85")

