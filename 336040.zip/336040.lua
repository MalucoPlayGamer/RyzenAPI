-- Lua provided by RyzenAPI
-- Game: Combat Monsters

-- MAIN APPLICATION
addappid(336040)

-- MAIN APP DEPOTS / PACKAGES
addappid(336041, 1, "8297e9fcfd50457679d2191340e497f3d1d5e80f44624e8b4753a7162f2f291b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
