-- Lua provided by RyzenAPI
-- Game: 439930

-- MAIN APPLICATION
addappid(439930)
-- Game: addappid(439930)

-- MAIN APP DEPOTS / PACKAGES
addappid(439931, 1, "be7823d42c022e75257e9fbe9bc0b135cb9057b941d1a3d5d5d04938ab389f5f")
addappid(439932, 1, "c310b3263aaab345c37987f4a5c958a22cfcdae6da5408c58524b7123800f9d9")
