-- Lua provided by RyzenAPI
-- Game: 870820

-- MAIN APPLICATION
addappid(870820)
-- Game: addappid(870820)

-- MAIN APP DEPOTS / PACKAGES
addappid(870821, 1, "8b865a30412fe6593994d22eaa310421c1b6cdb0d640ca0bffed1fcf0736fada")
addappid(870822, 1, "cb94c87805d87e9a23c1ddbdd9e863ada6829247b22db4677b3456d0867e8f89")
addappid(870823, 1, "012271e9fee73e6cfb4576a782c19b7e55a22e8a9d86e39d690a2f6cf3ac833f")
addappid(870824, 1, "e9fa1624ba29830f0dafa61115458f47dc014a6d7a5eec4a93ca29ba7ab56d98")
addappid(870825, 1, "486f6771ed8ac42a9101482ea6b274fbb5adb55c5cc8d775f3458afb06788dc6")
