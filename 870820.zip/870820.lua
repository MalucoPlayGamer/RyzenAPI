-- Lua provided by RyzenAPI
-- Game: AppID 870820

-- MAIN APPLICATION
addappid(870820)

-- MAIN APP DEPOTS / PACKAGES
addappid(870821, 1, "8b865a30412fe6593994d22eaa310421c1b6cdb0d640ca0bffed1fcf0736fada")
addappid(870822, 1, "cb94c87805d87e9a23c1ddbdd9e863ada6829247b22db4677b3456d0867e8f89")
addappid(870823, 1, "012271e9fee73e6cfb4576a782c19b7e55a22e8a9d86e39d690a2f6cf3ac833f")
addappid(870824, 1, "e9fa1624ba29830f0dafa61115458f47dc014a6d7a5eec4a93ca29ba7ab56d98")
addappid(870825, 1, "486f6771ed8ac42a9101482ea6b274fbb5adb55c5cc8d775f3458afb06788dc6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
