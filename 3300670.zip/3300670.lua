-- Lua provided by RyzenAPI
-- Game: Game: Elevator 25

-- MAIN APPLICATION
addappid(3300670)
-- Game: addappid(3300670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300671, 1, "5d516b4c1f40c716b7f41b6701aee692a6537259f34dfb60d6b4fc1251529736")
