-- Lua provided by RyzenAPI 
-- Game: BloodPit: Skelton II
addappid(2077910)
addappid(2077911, 1, "7d4d3c8b9253d52e157fd703efbb1a2c6c6e4636cc90295775ac7aa8bf225582")
