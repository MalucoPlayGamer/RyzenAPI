-- Lua provided by RyzenAPI
-- Game: BloodPit: Skelton II

-- MAIN APPLICATION
addappid(2077910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077911, 1, "7d4d3c8b9253d52e157fd703efbb1a2c6c6e4636cc90295775ac7aa8bf225582")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
