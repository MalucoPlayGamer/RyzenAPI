-- Lua provided by RyzenAPI
-- Game: addappid(215360)

-- MAIN APPLICATION
addappid(215360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251,0,"948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92")
addappid(1254,0,"b3c37dce88bf0a0c729934617c3c50af30f9671b31dd95baeb88e338a5fa84a0")
