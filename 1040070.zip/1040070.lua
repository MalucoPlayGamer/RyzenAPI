-- Lua provided by RyzenAPI
-- Game: Game: Merchant of the Skies

-- MAIN APPLICATION
addappid(1040070)
-- Game: addappid(1040070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040071, 1, "f342a24dd5fd52c848aa64fa7c7b430d54473e356153a0e0ad343096996a4da9")
addappid(1040072, 1, "d91630b7289677b723b91af048b21ef59563989d455e44487739612fad8f4c4c")
addappid(1040073, 1, "1d97a97b09a8ad98f63df68d823505b42dab276e91486adf3e7a783a1a6def78")
addappid(1040075, 1, "83b0614c08a03bc3d7828e9d4fec4f6ff14d1c09c40b11b7c35ef56e4bd847d4")
