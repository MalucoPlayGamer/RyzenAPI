-- Lua provided by RyzenAPI
-- Game: 1249880

-- MAIN APPLICATION
addappid(1249880)
-- Game: addappid(1249880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249881, 1, "3f855dd2140d71dd030f0d85bbeaf682d53355c2c6a4263fbe19b5e9900772fe")
