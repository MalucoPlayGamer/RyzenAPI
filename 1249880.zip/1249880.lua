-- Lua provided by RyzenAPI
-- Game: Tiny Bunny: Prologue

-- MAIN APPLICATION
addappid(1249880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1249881, 1, "3f855dd2140d71dd030f0d85bbeaf682d53355c2c6a4263fbe19b5e9900772fe")
