-- Lua provided by RyzenAPI
-- Game: Death Crown

-- MAIN APPLICATION
addappid(814530)
addappid(1231850)
addappid(1312820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(814531,0,"76a970e820bd33607a47add3e56d9ebe66a937f4fec79f4184573972ee998457")
addappid(814532,0,"e15c60807c7b78f3bf683f4304446d23fd6addfeb61359754f43a2c68dcf6189")
addappid(814533,0,"62c226583b06623d4c170ff0e42b3484c3d96f6e9ff0b9a5bb1a98c515a3db2b")

