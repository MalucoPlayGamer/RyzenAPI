-- Lua provided by RyzenAPI
-- Game: 814530

-- MAIN APPLICATION
addappid(814530)
-- Game: addappid(814530)

-- MAIN APP DEPOTS / PACKAGES
addappid(814531, 1, "76a970e820bd33607a47add3e56d9ebe66a937f4fec79f4184573972ee998457")
