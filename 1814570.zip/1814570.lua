-- Lua provided by RyzenAPI
-- Game: 1814570

-- MAIN APPLICATION
addappid(1814570)
-- Game: addappid(1814570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814571, 1, "692ab0a2c37856ebbf9fe571c18c27b110c4b266edc5b584a212f5909f7d64e1")
