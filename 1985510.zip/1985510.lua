-- Lua provided by RyzenAPI
-- Game: Ukraine War Stories

-- MAIN APPLICATION
addappid(1985510)
-- Game: addappid(1985510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985511, 1, "bf1a3f7c6e81e7a4e1b05bb778c34f306413c3894243c29141fc75e3d5375144")
