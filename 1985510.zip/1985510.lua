-- Lua provided by RyzenAPI
-- Game: Ukraine War Stories

-- MAIN APPLICATION
addappid(1985510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985511, 1, "bf1a3f7c6e81e7a4e1b05bb778c34f306413c3894243c29141fc75e3d5375144")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
