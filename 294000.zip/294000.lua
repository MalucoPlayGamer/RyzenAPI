-- Lua provided by RyzenAPI
-- Game: Knight Squad

-- MAIN APPLICATION
addappid(294000)
addappid(414780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(294001, 1, "f34b579b60aa45d613c339f2d659ec698993742674238b4d11522f151382e7cc")
addappid(294002, 1, "70453574e5b1918b0729bafafc6c8848ef0302efbed6df6161ef21064ec347e9")
addappid(294003, 1, "e9526633a8ee432c7436595ebbeb27582dbd7feccbb90b44010fc11dbcdfc30c")

