-- Lua provided by RyzenAPI
-- Game: addappid(234160)

-- MAIN APPLICATION
addappid(234160)

-- MAIN APP DEPOTS / PACKAGES
addappid(234161, 1, "5e8ecdbb9b68855e67402e564b80e0bdd29976615f972af59624ed4fa12bd00d")
