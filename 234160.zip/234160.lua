-- Lua provided by RyzenAPI
-- Game: Strike Suit Infinity

-- MAIN APPLICATION
addappid(234160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(234161, 1, "5e8ecdbb9b68855e67402e564b80e0bdd29976615f972af59624ed4fa12bd00d")

