-- Lua provided by SkyAPI 
-- Game: AppID 768130
addappid(768130)
addappid(768131, 1, "98908ef113fc5f94ff9f2300b3a34dfc20e13037cc697a46eef94caeb1ce402a")
