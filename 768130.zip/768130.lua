-- Lua provided by RyzenAPI
-- Game: Aiso

-- MAIN APPLICATION
addappid(768130)

-- MAIN APP DEPOTS / PACKAGES
addappid(768131, 1, "98908ef113fc5f94ff9f2300b3a34dfc20e13037cc697a46eef94caeb1ce402a")
