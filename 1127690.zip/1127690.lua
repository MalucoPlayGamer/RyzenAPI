-- Lua provided by RyzenAPI
-- Game: Winter Magic Factory

-- MAIN APPLICATION
addappid(1127690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127691, 1, "15a065335d91de0f27ef5fcf21e1a31fdb3aef3fd38c5384b8371108b8a25d79")
addappid(1127692, 1, "12f3b2cc68b8dbb50cd06d09a2cb3e181fd6e36988c3b42e80d18d3da65f04d5")
addappid(1127693, 1, "4123ced5fb558d1a164332cba6b7ee817d3d4d80302f8742b3b27fc2b1e53bbf")
