-- Lua provided by RyzenAPI
-- Game: Barrett Foster : Prologue

-- MAIN APPLICATION
addappid(2341420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341421, 1, "12ee5367ae67e937adfd3094e47f5752fb3dc2cc7bca16a39950e6ce6ba7b59a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
