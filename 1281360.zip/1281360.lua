-- Lua provided by RyzenAPI
-- Game: addappid(1281360)

-- MAIN APPLICATION
addappid(1281360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281361, 1, "ee1b2fc2a7a314bc4c2599ad3f64b8ab79131fd0a3fccf25d4ba5d67a0ede5ee")
