-- Lua provided by RyzenAPI
-- Game: AppID 915880

-- MAIN APPLICATION
addappid(915880)
-- Game: addappid(915880)

-- MAIN APP DEPOTS / PACKAGES
addappid(915881, 1, "ccbfbfc18491f6d99bf79a03b75733deaf644e33c46bb3356da70b7f1d8d440f")
