-- Lua provided by RyzenAPI
-- Game: The Center - ARK Expansion Map

-- MAIN APPLICATION
addappid(473850)
-- Game: addappid(473850)

-- MAIN APP DEPOTS / PACKAGES
addappid(473851, 1, "99fb597107882942ca94e2038215f03f8707d57b059460ec6bde8265bf020733")
