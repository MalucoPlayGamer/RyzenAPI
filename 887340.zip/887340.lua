-- Lua provided by RyzenAPI
-- Game: Game: Owl Watch

-- MAIN APPLICATION
addappid(887340)
-- Game: addappid(887340)

-- MAIN APP DEPOTS / PACKAGES
addappid(887341, 1, "dd022872c77a644d1dc518733b36bb7e4b554eff26d5d329bac2395e78435f32")
