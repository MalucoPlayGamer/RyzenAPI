-- Lua provided by RyzenAPI
-- Game: 391070

-- MAIN APPLICATION
addappid(391070)
-- Game: addappid(391070)

-- MAIN APP DEPOTS / PACKAGES
addappid(391071, 1, "96926c88ed6d5650148003a7afdc37594e9c9ce03e37231a0cff47b592a52a9b")
