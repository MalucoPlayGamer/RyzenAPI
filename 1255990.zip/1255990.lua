-- Lua provided by RyzenAPI
-- Game: We should talk.

-- MAIN APPLICATION
addappid(1255990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255991, 1, "aff72539f409456df2b4bbc140f3573665ae42c9bcba88559281fbc732f11dd6")
