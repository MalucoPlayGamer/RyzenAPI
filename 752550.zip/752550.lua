-- Lua provided by RyzenAPI 
-- Game: Ripped Pants at Work
addappid(752550)
addappid(752551, 1, "befcf4a927018e74d8394988bfe609595356f2ae85bdcd508917b1f7ff251a5e")
addappid(752552, 1, "fea5ed3bee86061ca6b4dc97c2aeee457d34dd005059fe0e108741d4cc880338")
