-- Lua provided by SkyAPI 
-- Game: Space Contact
addappid(3311180)
addappid(3311181, 1, "cd4c67920154286cca3715bbac39d3622093e81883235b25e40e74a52f268296")
