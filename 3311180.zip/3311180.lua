-- Lua provided by RyzenAPI
-- Game: Game: Space Contact

-- MAIN APPLICATION
addappid(3311180)
-- Game: addappid(3311180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311181, 1, "cd4c67920154286cca3715bbac39d3622093e81883235b25e40e74a52f268296")
