-- Lua provided by RyzenAPI
-- Game: Galactic Lander

-- MAIN APPLICATION
addappid(913600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(913601, 1, "36c3991eba1a9bb8966cb7b980e26bcfc110ffbb828bce796e62a6b203e02523")
