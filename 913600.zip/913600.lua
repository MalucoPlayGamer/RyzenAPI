-- Lua provided by RyzenAPI
-- Game: 913600

-- MAIN APPLICATION
addappid(913600)
-- Game: addappid(913600)

-- MAIN APP DEPOTS / PACKAGES
addappid(913601, 1, "36c3991eba1a9bb8966cb7b980e26bcfc110ffbb828bce796e62a6b203e02523")
