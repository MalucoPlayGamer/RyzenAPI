-- Lua provided by RyzenAPI
-- Game: Game: Portal 2: Confinement

-- MAIN APPLICATION
addappid(2716490)
-- Game: addappid(2716490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716491, 1, "a0b6e97ddbfe8fa75b86cb4a3955c558a8ee4c044d780f991c00d4597c85fb68")
