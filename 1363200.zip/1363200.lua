-- Lua provided by RyzenAPI
-- Game: 1363200

-- MAIN APPLICATION
addappid(1363200)
-- Game: addappid(1363200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363201, 1, "f83c739bdbf641b8b1a33b061adc502818d2558a8c696e5a6e81cdbb444151f1")
