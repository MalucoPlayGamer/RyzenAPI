-- Lua provided by SkyAPI 
-- Game: AppID 1363200
addappid(1363200)
addappid(1363201, 1, "f83c739bdbf641b8b1a33b061adc502818d2558a8c696e5a6e81cdbb444151f1")
