-- Lua provided by RyzenAPI
-- Game: 2600040

-- MAIN APPLICATION
addappid(2600040)
-- Game: addappid(2600040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600041, 1, "4d82cad1323449cd0bfb91c6743aaae09ead64af07f7e1d99d145f8f0cafc98d")
