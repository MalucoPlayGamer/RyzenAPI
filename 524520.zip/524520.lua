-- Lua provided by RyzenAPI
-- Game: 524520

-- MAIN APPLICATION
addappid(524520)
-- Game: addappid(524520)

-- MAIN APP DEPOTS / PACKAGES
addappid(524521, 1, "70318c6cee4221e3257e717e8a2c8eb5eff273df3c3400104d11725353a95455")
