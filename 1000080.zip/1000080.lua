-- 1000080's Lua and Manifest Created by Hubcap Manifest
-- Zengeon
-- Created: March 16, 2026 at 13:17:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1000080, 1, "aca9158b9e0bd3a558473e44b28fb8215c70ffbd61c8f8dabbcb2678d5536534") -- Zengeon
-- MAIN APP DEPOTS
addappid(1000081, 1, "8a403cc12be901bcc6b958cc0fb1e3eead597e17fac347e68c1fa77500023a85") -- 神明在上 Global
setManifestid(1000081, "8103406791774249296", 928335729)
addappid(1000082, 1, "6c66a89d1e5ee120e1216b96db010cfd1af75f1b1c41b70f4a2a5cfce900fae8") -- 神明在上Zengeon Mac
setManifestid(1000082, "7111198692116798018", 946771703)
-- DLCS WITH DEDICATED DEPOTS
-- Zengeon-Grab your Summer Memory (swimwear 1) (AppID: 1153360)
addappid(1153360)
addappid(1153361, 1, "257f88e14607bc1fa5fb1fe340340be9851470a123858521db0bfe50e182eb52") -- Zengeon-Grab your Summer Memory (swimwear 1) - Zengeon-Grab your Summer Memory (swimwear #1) PC
setManifestid(1153361, "1993781458675268801", 0)
addappid(1153362, 1, "ea506661409a1f16633e9dc37150ab29a8a13a5a285d02049435784af6eb7525") -- Zengeon-Grab your Summer Memory (swimwear 1) - Zengeon-Grab your Summer Memory (swimwear #1) MAC
setManifestid(1153362, "5564533707358672435", 0)
-- Zengeon-Grab your Summer Memory (swimwear 2) (AppID: 1159380)
addappid(1159380)
addappid(1159381, 1, "02670d61d7f1c8842d8fa9af55c10764a2c0ebbd32e678984e47ed9a1b6b3381") -- Zengeon-Grab your Summer Memory (swimwear 2) - Zengeon-Grab your Summer Memory (swimwear #2) 个 Depot
setManifestid(1159381, "2303195034901352050", 0)
addappid(1159382, 1, "166ecb03d83b294fe35a621874d541e97806b792b9bb1c52ef55b530a00caa98") -- Zengeon-Grab your Summer Memory (swimwear 2) - Zengeon-Grab your Summer Memory (swimwear #2) 个 Depot
setManifestid(1159382, "3333383614087885460", 0)
-- Zengeon-Grab your Summer Memory (swimwear 3) (AppID: 1163180)
addappid(1163180)
addappid(1163181, 1, "548b2dbd6ccecbf29b09e18f821d7ac96f646d5a04a27afd4a9676fe3c6a326b") -- Zengeon-Grab your Summer Memory (swimwear 3) - Zengeon-Grab your Summer Memory (swimwear #3) 个 Depot
setManifestid(1163181, "2274249042043138820", 0)
addappid(1163182, 1, "17648ea755173978fd86fff1f4b01327425a3a794fa8b8099a77d1d361f0afcf") -- Zengeon-Grab your Summer Memory (swimwear 3) - Zengeon-Grab your Summer Memory (swimwear #3) 个 Depot
setManifestid(1163182, "3024793466099520277", 0)
-- Zengeon-Grab your Summer Memory (swimwear 4) (AppID: 1166500)
addappid(1166500)
addappid(1166501, 1, "47dc9ded8c95f097478afeaf8ca274e3f96b4d0d2166d9a86bbdaa0a782d9cf8") -- Zengeon-Grab your Summer Memory (swimwear 4) - Zengeon-Grab your Summer Memory (swimwear #4) 个 Depot
setManifestid(1166501, "908507670258212136", 0)
addappid(1166502, 1, "a8e99bd36a261846ed545cd3ca12f275ae30da4214b31ec8930437bfeb9dd548") -- Zengeon-Grab your Summer Memory (swimwear 4) - Zengeon-Grab your Summer Memory (swimwear #4) 个 Depot
setManifestid(1166502, "4926828066326099800", 0)
-- Zengeon-Grab your Summer Memory (swimwear 5) (AppID: 1169220)
addappid(1169220)
addappid(1169221, 1, "b6c26d3516ecfb60acab9158a0637e9e2b49b33aebd7208a8da9035607f75dc0") -- Zengeon-Grab your Summer Memory (swimwear 5) - Zengeon-Grab your Summer Memory (swimwear #5) 个 Depot
setManifestid(1169221, "3682062368358805658", 0)
addappid(1169222, 1, "ce674e2cffbad6e12082fde3f59f472f66d27ff249dff3c5a6011d4264200007") -- Zengeon-Grab your Summer Memory (swimwear 5) - Zengeon-Grab your Summer Memory (swimwear #5) 个 Depot
setManifestid(1169222, "5023997460750322562", 0)