-- Lua provided by RyzenAPI
-- Game: Lovecraft's Untold Stories

-- MAIN APPLICATION
addappid(871420)

-- MAIN APP DEPOTS / PACKAGES
addappid(871421, 1, "c522caa427f25e57d7e652d1baab52c0423ea80444f4884aa70a5d09ed87312b")
addappid(871422, 1, "a3014bf8b6f1f4cd5aab0d384a068024f7de117bc15f89bfb5e15ff0bec8b52f")
addappid(1061960, 0, "33fe47f67a4b2772f75760655a3ec60023437552ae85f7b05145d009755efd3f")
addappid(1081920, 0, "52a52b78d0addca9325e323afb549b9400cc87d62aa62cc613e6dd29edfbc00d")

