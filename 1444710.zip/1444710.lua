-- Lua provided by RyzenAPI
-- Game: Game: FireJumpers Inferno

-- MAIN APPLICATION
addappid(1444710)
addappid(2117040)
-- Game: addappid(1444710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444711, 1, "9fd357577d062d1fa0b714ea2b9e381a8d1d7da5baf3a695d3cd7147e8934757")
addappid(1444712, 1, "2fcfb8f2bab1aa0ac4dab9a91dce36656ef1a5de03380b37b01cbbafcce04d0b")
