-- Lua provided by RyzenAPI
-- Game: Unreal Tournament 2004: Editor's Choice Edition

-- MAIN APPLICATION
addappid(13230)
-- Game: addappid(13230)

-- MAIN APP DEPOTS / PACKAGES
addappid(13231, 1, "aed52a1927d9c42a51cb88b2c9697a25e6ad0e7fcda80b638d1c4103fe0a7c93")
addappid(13232, 1, "b9a8adf124027aeaeb877da49a3a667d0fa86f0ee5270af8dbc9285b7e0dd8d6")
addappid(13233, 1, "8545af1423d404d73390582b347774458222b2fc1de3ecbeecd7ba30cd1e67b8")
addappid(13234, 1, "460c1ed25601e06d4261483a508a0c57c1b9ecf9183f6e3db2fb5f3aa490ed92")
