-- Lua provided by RyzenAPI
-- Game: 1118430

-- MAIN APPLICATION
addappid(1118430)
-- Game: addappid(1118430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118430,0,"0628bb0c9bfbd42807299cd2daddf9d573f782d9ffa0a757db423a1fe1c503c0")
