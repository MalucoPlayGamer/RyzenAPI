-- Lua provided by RyzenAPI
-- Game: 557190

-- MAIN APPLICATION
addappid(557190)
-- Game: addappid(557190)

-- MAIN APP DEPOTS / PACKAGES
addappid(557191, 1, "9cc27ba78661e1663ae5a9ed6a034314cc654b3d79c9edf0267198d2b3e185e0")
