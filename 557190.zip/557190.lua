-- Lua provided by RyzenAPI
-- Game: BuildMoreCubes

-- MAIN APPLICATION
addappid(557190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(557191, 1, "9cc27ba78661e1663ae5a9ed6a034314cc654b3d79c9edf0267198d2b3e185e0")

