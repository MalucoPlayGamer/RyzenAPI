-- Lua provided by RyzenAPI
-- Game: 2543370

-- MAIN APPLICATION
addappid(2543370)
addappid(2689900)
-- Game: addappid(2543370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543371, 1, "9d0c70ba9f59cdeabcdcf85ce0bdf753641d5bf4ba8facb1c7dd157526595349")
