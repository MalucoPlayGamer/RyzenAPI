-- Lua provided by SkyAPI 
-- Game: HoneyCome come come party
addappid(2543370)
addappid(2543371, 1, "9d0c70ba9f59cdeabcdcf85ce0bdf753641d5bf4ba8facb1c7dd157526595349")
addappid(2689900)
