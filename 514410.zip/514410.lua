-- Lua provided by RyzenAPI
-- Game: Game: AppID 514410

-- MAIN APPLICATION
addappid(514410)
-- Game: addappid(514410)

-- MAIN APP DEPOTS / PACKAGES
addappid(514411, 1, "6caa7543223527f2a6baaf7396f9242f0cc2ad864909631599b181b01b9b2def")
addappid(514412, 1, "a3e95285a7c5cd419b0fc5fafc7ec433cefeb8fcb473cb40862fe6983ef1b3f3")
addappid(568700, 0, "977156e2318d9c0953da2df840cbe4161ee194fbc8b178011ab713f7e7b9f66d")
