-- Lua provided by RyzenAPI
-- Game: Fortress 2 BLUE（疯狂坦克）

-- MAIN APPLICATION
addappid(3152590)

