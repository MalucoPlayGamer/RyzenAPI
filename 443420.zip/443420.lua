-- Lua provided by RyzenAPI
-- Game: Artificial Defense

-- MAIN APPLICATION
addappid(443420)

-- MAIN APP DEPOTS / PACKAGES
addappid(443421, 1, "6a8deb4477bfc4b46324a1227dcdf48980f3a2a57d70a9063d93f5769be751c1")
