-- Lua provided by RyzenAPI
-- Game: Game: Cosmobreeder Yiffai

-- MAIN APPLICATION
addappid(3548000)
-- Game: addappid(3548000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3548001, 1, "b9175d7e9841efc53486b18a4b00aa4e1da6df634be4b3bac4b33e5e2df8bd4b")
