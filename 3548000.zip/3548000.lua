-- Lua provided by RyzenAPI 
-- Game: Cosmobreeder Yiffai
addappid(3548000)
addappid(3548001, 1, "b9175d7e9841efc53486b18a4b00aa4e1da6df634be4b3bac4b33e5e2df8bd4b")
