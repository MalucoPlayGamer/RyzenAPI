-- Lua provided by RyzenAPI
-- Game: Loveland Demo

-- MAIN APPLICATION
addappid(1542940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542941, 1, "60d928cd8ca22720281e7c60ba6fb4c4af3f0a995018b21a959282d750a48e9f")

