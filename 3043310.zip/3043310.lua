-- Lua provided by RyzenAPI
-- Game: Alchemist Shop Simulator

-- MAIN APPLICATION
addappid(3043310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043311, 1, "f6412042f2a4afef996e8f4c9a1309bfd1ff98844455722011c021c84e2fa004")
