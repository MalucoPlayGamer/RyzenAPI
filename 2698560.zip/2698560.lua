-- Lua provided by RyzenAPI
-- Game: Game: Hotel in the Dark

-- MAIN APPLICATION
addappid(2698560)
-- Game: addappid(2698560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698561, 1, "67ead9ff0558637c2762d33f43e989a776e4beffe37def62200657a160784861")
