-- Lua provided by RyzenAPI
-- Game: Go-Go Town!

-- MAIN APPLICATION
addappid(2195120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195121, 1, "94d3a57270a0d1f85e33c7108de0457196cf7b7fd4ee7c45b233972ba6d3b962")

