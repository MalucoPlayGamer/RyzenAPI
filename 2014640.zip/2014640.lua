-- Lua provided by RyzenAPI
-- Game: Game: The Many Pieces of Mr. Coo Demo

-- MAIN APPLICATION
addappid(2014640)
-- Game: addappid(2014640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014641, 1, "36634187d1d770d2738181f16c847e6459a4a7f8bde5d23d23e470d9b8245eba")
