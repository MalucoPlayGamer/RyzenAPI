-- Lua provided by RyzenAPI
-- Game: Game: Iggy's Zombie A-Pug-Alypse

-- MAIN APPLICATION
addappid(671560)
-- Game: addappid(671560)

-- MAIN APP DEPOTS / PACKAGES
addappid(671561, 1, "128e5529043b978b35ed33163b437206a8ece56653ead6690984092641a6b83c")
