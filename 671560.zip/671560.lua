-- Lua provided by SkyAPI 
-- Game: Iggy's Zombie A-Pug-Alypse
addappid(671560)
addappid(671561, 1, "128e5529043b978b35ed33163b437206a8ece56653ead6690984092641a6b83c")
