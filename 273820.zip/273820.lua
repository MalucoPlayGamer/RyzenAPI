-- Lua provided by RyzenAPI
-- Game: Mining & Tunneling Simulator

-- MAIN APPLICATION
addappid(273820)

-- MAIN APP DEPOTS / PACKAGES
addappid(273821, 1, "bee3a65d6fd5448fa24641e1d46457a77f36277cae22fc9e8197b2aa5477adf1")
addappid(273822, 1, "29bf1fa5b0bcd1c7ba27aeae17feeb467641bee64a7330eba44e9ffb4bd60420")
addappid(273823, 1, "707bb0c32b332328d4ebf6643a928ee095691b7949f8a38dbc491acb72703f5d")
addappid(273824, 1, "2fa9dc66c8e8262068a9f1bf591ffa531ca839508241332dd430a04fdad17678")
addappid(273825, 1, "e4b1988f642700d7d4ea8e659016ec411a9f2073a78c58659af194f377cbabbf")
addappid(273826, 1, "bc456147d3f9a141471cb973bf2d59e5bdb19cd2cee324065811659bb024d05f")
addappid(273827, 1, "fce61f920db7d3b28abd8133df1ac885ecdc053521d0f3515bf33b5d12bd7b65")
