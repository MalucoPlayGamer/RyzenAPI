-- Lua provided by RyzenAPI
-- Game: Vamp Night

-- MAIN APPLICATION
addappid(1507740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507741, 1, "26926488e294921090eeb1ad83e9e3dd247c0137fe74827bb43ade46e1e5ed51")

