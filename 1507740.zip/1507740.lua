-- Lua provided by RyzenAPI 
-- Game: AppID 1507740
addappid(1507740)
addappid(1507741, 1, "26926488e294921090eeb1ad83e9e3dd247c0137fe74827bb43ade46e1e5ed51")
