-- Lua provided by RyzenAPI
-- Game: Malediction

-- MAIN APPLICATION
addappid(1206930)
-- Game: addappid(1206930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206931, 1, "2b9979a30f03f5b4ebfc2b9cfe53e3d41a5cb27ecec6b02d762c3d0e4217f75e")
