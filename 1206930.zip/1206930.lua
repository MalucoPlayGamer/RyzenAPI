-- Lua provided by RyzenAPI
-- Game: Malediction

-- MAIN APPLICATION
addappid(1206930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206931, 1, "2b9979a30f03f5b4ebfc2b9cfe53e3d41a5cb27ecec6b02d762c3d0e4217f75e")

