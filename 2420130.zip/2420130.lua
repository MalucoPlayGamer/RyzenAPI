-- Lua provided by RyzenAPI
-- Game: AppID 2420130

-- MAIN APPLICATION
addappid(2420130)
-- Game: addappid(2420130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420131, 1, "c678d0d5ed19b18fb3cbed61912bedb5a3f93a5d101849c9e198ddfa589b34a6")
