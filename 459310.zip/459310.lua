-- Lua provided by RyzenAPI
-- Game: The Hero Project: Redemption Season

-- MAIN APPLICATION
addappid(459310)
-- Game: addappid(459310)

-- MAIN APP DEPOTS / PACKAGES
addappid(459311, 1, "df2e736414db157b6dddf1c1a3168a27e61edb9a4b4d7abe5000993270adcac9")
