-- Lua provided by RyzenAPI
-- Game: Game: Run, Kitty! - A Furry Gay Visual Novel

-- MAIN APPLICATION
addappid(1630630)
-- Game: addappid(1630630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630631, 1, "2f8bf10ed567591948872f36e2d01db80412d7f458b6a9e654da07746d309cc7")
