-- Lua provided by RyzenAPI
-- Game: Feline Shenanigans

-- MAIN APPLICATION
addappid(2686480)
-- Game: addappid(2686480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686481, 1, "6e2eb409fc9a3d487f50d8a9c0b18222c2462219a40e1b7d222cd5fe99c0e163")
