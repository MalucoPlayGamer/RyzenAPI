-- Lua provided by RyzenAPI
-- Game: addappid(1636345)

-- MAIN APPLICATION
addappid(1636345)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636345,0,"d389ff4a24fb1157eb1b9d5fe9279dcd2c1c9cd67f720c1069243f57b38d9ba7")
