-- Lua provided by RyzenAPI
-- Game: 幸存者联盟

-- MAIN APPLICATION
addappid(3150150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150151, 1, "fbcc47c0f34c66e1c8c22187a38bd21712ce79c920c3b8efb22a03bfc600205f")
