-- Lua provided by RyzenAPI
-- Game: The Chronos Event Demo

-- MAIN APPLICATION
addappid(2832480)
-- Game: addappid(2832480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832481, 1, "7ed6823038e36996b9237cfb37e6f74926dae515930a64aa8e9fbd613cf92e5d")
