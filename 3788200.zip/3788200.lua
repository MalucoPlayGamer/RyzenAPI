-- Lua provided by SkyAPI 
-- Game: Spearfishing Simulator
addappid(3788200)
addappid(3788201, 1, "2531490b60dfb5a9ac4e133e899f6e386471d22479008f9da3efcee87e8ae5f8")
