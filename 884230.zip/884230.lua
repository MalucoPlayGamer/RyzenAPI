-- Lua provided by RyzenAPI
-- Game: AppID 884230

-- MAIN APPLICATION
addappid(884230)

-- MAIN APP DEPOTS / PACKAGES
addappid(884231, 1, "899344b9f2b86a42d7abfdb7bcb893d530c8ad14b59636c2c5dd529f4da040f0")

