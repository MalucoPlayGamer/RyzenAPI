-- Lua provided by RyzenAPI
-- Game: 2406360

-- MAIN APPLICATION
addappid(2406360)
-- Game: addappid(2406360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406363,0,"b3f1baaf7a2014c658358f09f2cb02e88f3c7fdc2f0c10e139040f3a7a53dab5")
