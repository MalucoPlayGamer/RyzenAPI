-- Lua provided by RyzenAPI
-- Game: Beat Saber: Billie Eilish - 'Oxytocin'

-- MAIN APPLICATION
addappid(1753527)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753527,0,"9130fde7ed1f29c3c8bc7730df1bf0538b30c1ca5b30cf06f35ed0fb28017d1a")

