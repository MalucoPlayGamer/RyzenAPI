-- Lua provided by RyzenAPI
-- Game: Game: AppID 645360

-- MAIN APPLICATION
addappid(645360)
-- Game: addappid(645360)

-- MAIN APP DEPOTS / PACKAGES
addappid(645361, 1, "781d924fa21d43adf0b6f0101f8d851a899c3ac7c78fa5e5b4878702b3b029e3")
addappid(918410, 0, "bb6265fbc0c8abdb2400f45e81f52a9f617e5bd58e36adc473c94199e299a5f4")
