-- Lua provided by RyzenAPI
-- Game: addappid(1739610)

-- MAIN APPLICATION
addappid(1739610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739611, 1, "7d2706a7313d3188981d7eddb52e752f6a334725acad3bed1e0ad1620377dae1")
