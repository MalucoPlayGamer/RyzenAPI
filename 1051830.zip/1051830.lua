-- Lua provided by RyzenAPI
-- Game: House of Evil 2

-- MAIN APPLICATION
addappid(1051830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1051831, 1, "f71a7d55e3989ae10181df134d26607a1f3e2cc28186c3a3fe5e0a807a4a7c67")

