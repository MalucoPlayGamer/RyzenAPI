-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: 185 series

-- MAIN APPLICATION
addappid(3532910)
-- Game: addappid(3532910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3532911, 1, "dcf9dd15aab3eeacc76357b260fa7995b0873a767b75bc6e95353bf37802f911")
