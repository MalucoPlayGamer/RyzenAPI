-- Lua provided by RyzenAPI
-- Game: 3493610

-- MAIN APPLICATION
addappid(3493610)
-- Game: addappid(3493610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3493612,0,"ffcdc7843d7e0c7ddd79832692f711bf05050b1beb7088437d6d535c90dbbb1a")
