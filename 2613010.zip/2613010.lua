-- Lua provided by RyzenAPI
-- Game: Transpile Girl Rescue Operation!

-- MAIN APPLICATION
addappid(2613010)
-- Game: addappid(2613010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613011, 1, "22f4812197ab3a7adaacf69a70e4d858eb85a8ee72387268e57be04daaf01a4e")
