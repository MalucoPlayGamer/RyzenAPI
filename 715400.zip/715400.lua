-- Lua provided by RyzenAPI
-- Game: 715400

-- MAIN APPLICATION
addappid(715400)
-- Game: addappid(715400)

-- MAIN APP DEPOTS / PACKAGES
addappid(715401, 1, "137ac76cbbb80df9e88bf9287ca2973bd41e26ac5793c5d2aaffd8290b899438")
