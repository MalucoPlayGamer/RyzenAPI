-- Lua provided by RyzenAPI
-- Game: Frozen Flame

-- MAIN APPLICATION
addappid(715400)
addappid(2221290)
addappid(2221300)
addappid(2221310)
addappid(2221320)
addappid(2221330)
addappid(2221340)
addappid(2221360)
addappid(2358760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(715401, 1, "137ac76cbbb80df9e88bf9287ca2973bd41e26ac5793c5d2aaffd8290b899438")

