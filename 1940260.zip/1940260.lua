-- Lua provided by RyzenAPI
-- Game: One Btn Bosses Demo

-- MAIN APPLICATION
addappid(1940260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940261, 1, "594e2a9215e16dc29a2ae1ff3ea3b9af278e6f55870245312681f65c099905ed")

