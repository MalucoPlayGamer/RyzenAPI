-- Lua provided by RyzenAPI
-- Game: Desktop Dungeons: Rewind

-- MAIN APPLICATION
addappid(1976950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976951, 1, "1041e494078aa552868d49a5425f0e5daa7f08d0ee901c5c0859f575f5530f5f")
