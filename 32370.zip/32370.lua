-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Knights of the Old Republic™

-- MAIN APPLICATION
addappid(32370)
-- Game: addappid(32370)

-- MAIN APP DEPOTS / PACKAGES
addappid(32371, 1, "cced321512d7ba493f3456b8f00d89dca60e11a105d2700dc28d6bb3532d3d47")
addappid(32372, 1, "3a1dca5f9405393cee1f8106cbc259ce3aa9fad6522717cbd127d6a0f284d813")
addappid(32373, 1, "15dcc1817bc817bfa7e07813bb747e27729370a041dbaac7a6f8cdeb2d7929f0")
addappid(32374, 1, "ea2e4e4c4ad18c492eae2798752e179e7f512086dbfdf4802bf13340440a4382")
addappid(32375, 1, "457b2a8315237e72009133b61dc9fc72677e9f7feee3ed081831ed49aaa7f23b")
addappid(32376, 1, "5b2c0fc577deced0593cdc750a01dc3e549ef72ec579f37c938bd0e5a203a32f")
addappid(32377, 1, "21a6407753a28c8c51b1691d09a1ba48a16c3834bc7022b33045018b5eb533c0")
