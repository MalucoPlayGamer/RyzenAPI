-- Lua provided by RyzenAPI
-- Game: USAC: Code Breach

-- MAIN APPLICATION
addappid(1886070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886071, 1, "a3e0096f903eacf2452191768bc041d807f1aca658fb86fc8516af090c304bd3")
