-- Lua provided by RyzenAPI
-- Game: AppID 1513580

-- MAIN APPLICATION
addappid(1513580)
addappid(1860920)
-- Game: addappid(1513580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513581, 1, "f2c27d9ae9cda474d78dfb2d6b20e4a8804a8a386704ba67650637cb5558d76a")
