-- Lua provided by RyzenAPI
-- Game: AppID 1513580

-- MAIN APPLICATION
addappid(1513580)
addappid(1860920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513581, 1, "f2c27d9ae9cda474d78dfb2d6b20e4a8804a8a386704ba67650637cb5558d76a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
