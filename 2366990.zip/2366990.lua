-- Lua provided by RyzenAPI
-- Game: addappid(2366990)

-- MAIN APPLICATION
addappid(2366990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366991, 1, "b787a31eedad42a32a5cddc65ab367d974b99fefc433da9862199ee15c2f5a36")
