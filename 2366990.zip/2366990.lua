-- Lua provided by RyzenAPI
-- Game: Hentai Senpai: Sukebe Nekomimi no Yoru

-- MAIN APPLICATION
addappid(2366990)
addappid(2392300)
addappid(2392301)
addappid(2392302)
addappid(2392303)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366991, 1, "b787a31eedad42a32a5cddc65ab367d974b99fefc433da9862199ee15c2f5a36")

