-- Lua provided by RyzenAPI
-- Game: AppID 290140

-- MAIN APPLICATION
addappid(290140)

-- MAIN APP DEPOTS / PACKAGES
addappid(290141, 1, "36b5445bbf9dd8fab8c5b4a53cd32bc4e82389e18e1e37d7235e4a8ae80f418c")
