-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade — Parliament of Knives

-- MAIN APPLICATION
addappid(1266100)
addappid(2120360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266101, 1, "a0cd0015ed443f9177cd5ec45a29fb2aa768cf8e08e2cedc3d5a87ced039fa6d")
