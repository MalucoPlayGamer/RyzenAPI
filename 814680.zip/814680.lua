-- Lua provided by RyzenAPI
-- Game: Unbound: Worlds Apart

-- MAIN APPLICATION
addappid(814680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(814681, 1, "7eb4614e63a0c052f3521b88197155b371d867e9686c51a8a629d63759e02b8d")
addappid(814682, 1, "8876e51fccf1e8606700ec4ddf3a14370afc3eea34d933ec2ed3f0d5a1a3b69f")
addappid(814683, 1, "d32b263762f08f82950675aca5d17efe899b90e46a3c276b4e5fe8d08c5e2530")
