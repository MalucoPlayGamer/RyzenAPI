-- Lua provided by RyzenAPI
-- Game: SEX Instructor Yoga Vice City

-- MAIN APPLICATION
addappid(1578240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578241, 1, "243fa7463dc567b93e3ff44565487328f4a3841d1ab53378541af8532dd20c7c")

