-- Lua provided by RyzenAPI
-- Game: Good Luck

-- MAIN APPLICATION
addappid(3657240) -- Good Luck

-- MAIN APP DEPOTS / PACKAGES
addappid(3657242, 1, "2c936cf3aa94d7341e6ac817f4b0d3c76616f504fed82cc2b278813b52944771")

