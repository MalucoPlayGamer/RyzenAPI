-- Lua provided by RyzenAPI
-- Game: KURSK

-- MAIN APPLICATION
addappid(860620)
addappid(860621)
addappid(860622)
addappid(860623)
addappid(978351)

-- MAIN APP DEPOTS / PACKAGES
addappid(975080,0,"e24e218d3403c9d7d1e32a1077723a5acf44ae3913af1ef05a60a060826f4b15")
addappid(975081,0,"8b846c71ae18f0fad159dcca379143f0bba8b514b8823be65f1feada1939b2d2")
addappid(975082,0,"24ab2832a1472d1d35b391d42035d0128bcaf4aba6f9b2e4cc1f69e2b6b45d2a")
addappid(978350,0,"558aa2ecc8bc29b697617bbaf33a50909a445ee5802e451df2a169e703c9ac49")
