-- Lua provided by RyzenAPI
-- Game: 3 Stars of Destiny

-- MAIN APPLICATION
addappid(278530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(278531, 1, "92399f28cf6e6867e5d8aa96ca95e4408f45fb0c3568707acbe454b23646fe50")
addappid(366730, 0, "6fd742e554ce36031b312bb1ab2508e3788add1fa6bb86b817cf874783a2e55b")