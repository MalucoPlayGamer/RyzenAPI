-- Lua provided by RyzenAPI
-- Game: 1413360

-- MAIN APPLICATION
addappid(1413360)
-- Game: addappid(1413360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413361, 1, "a0143b0edeb3c99916028fb607b3e1e65c794b4e3b8bffd0382a8bf46fcfee33")
