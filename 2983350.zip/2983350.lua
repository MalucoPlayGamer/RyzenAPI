-- Lua provided by RyzenAPI
-- Game: planetarian: Snow Globe

-- MAIN APPLICATION
addappid(2983350)
-- Game: addappid(2983350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983351, 1, "7670b3b739a093fce638fb065ab0df0c3c89ed96462a864b6fe4eebcff6bfc17")
