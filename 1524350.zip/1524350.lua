-- Lua provided by RyzenAPI
-- Game: addappid(1524350)

-- MAIN APPLICATION
addappid(1524350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524351, 1, "9126f8a2cff42ea667bf59615cc239504f8397ff819608f70522e525efb55e4e")
