-- Lua provided by RyzenAPI
-- Game: addappid(22340)

-- MAIN APPLICATION
addappid(22340)

-- MAIN APP DEPOTS / PACKAGES
addappid(22341, 1, "d9e5b7e17d8059871b6ca318ae173d89c2e178b53301fab0747e0b3f1348f7f2")
