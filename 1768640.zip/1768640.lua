-- Lua provided by SkyAPI 
-- Game: Leap of Faith
addappid(1768640)
addappid(1768641, 1, "32c7e4fedfb5f47531275a7006066018ad1a54200fea90417155b8d5893c96c4")
addappid(2122800, 0, "45638ded6849bcdbf869d86af3292cb92a17f9495b0778e7d6c18000ac2d8ae5")
