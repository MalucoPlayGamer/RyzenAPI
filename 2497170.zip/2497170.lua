-- Lua provided by RyzenAPI
-- Game: Laura of Reigetsu

-- MAIN APPLICATION
addappid(2497170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497172,0,"070cd52e17810b8dc3c63d0d3e5e0671c150d711955663abcdf65281eda3ca9d")
addappid(2497173,0,"b2b97e0bbf2a2cf2f51a5dc7523c89ec24e7229d55dadfa5134e102e935e3b1f")
