-- Lua provided by RyzenAPI
-- Game: Child Of Ault

-- MAIN APPLICATION
addappid(566270)

-- MAIN APP DEPOTS / PACKAGES
addappid(566271,0,"f6aefe750438407d81986cc3d9e4d2f3fb2c4c0c8acc470f7586636a814e0db3")

