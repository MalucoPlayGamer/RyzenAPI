-- Lua provided by RyzenAPI
-- Game: Game: Rotten Flesh - Cosmic Horror Survival Game

-- MAIN APPLICATION
addappid(2657600)
-- Game: addappid(2657600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657601, 1, "3c4daeafc9acbe09091fa87a6c714b8618a2844965b838cd43e9ee4a0f91976d")
