-- Lua provided by RyzenAPI
-- Game: Afelhem

-- MAIN APPLICATION
addappid(848890)

-- MAIN APP DEPOTS / PACKAGES
addappid(848891, 1, "508dccdbe11e379298365a392b102128b0c8bd13f19e6d09f59fe336e902120b")
