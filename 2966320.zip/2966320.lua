-- Lua provided by RyzenAPI
-- Game: 2966320

-- MAIN APPLICATION
addappid(2966320)
addappid(4391920)
addappid(4395490)
addappid(4424260)
addappid(4460980)
addappid(4621220)
-- Game: addappid(2966320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966321, 1, "ce86c628c5c525587d2aea36d5a745c980584e22eca6389d8bfd7a63c0db1c4c")
