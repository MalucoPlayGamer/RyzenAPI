-- Lua provided by RyzenAPI
-- Game: Ice Age: Scrat's Nutty Adventure

-- MAIN APPLICATION
addappid(751060)

-- MAIN APP DEPOTS / PACKAGES
addappid(751061, 1, "17d8493448d430d74652fed214e70edcf4c2b03dae9585d7486076c99f9236dd")
