-- Lua provided by RyzenAPI
-- Game: Headspun

-- MAIN APPLICATION
addappid(808770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(808771,0,"b549acd01115d10dc2c3b26bc49cb4b8e734ddedfe5e925d04faa52abfa2d8d2")
addappid(808773,0,"edf63ef03076d328d22e217da82c883a5d52bb57d4d6ac43a5682518489b1be6")

