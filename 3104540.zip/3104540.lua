-- Lua provided by RyzenAPI
-- Game: 3104540

-- MAIN APPLICATION
addappid(3104540)
-- Game: addappid(3104540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104541, 1, "c8ff53b0bfd016ae637f3a3b6753a4e2be959a7fb0155d9c064692482ea54350")
