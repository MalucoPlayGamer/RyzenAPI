-- Lua provided by RyzenAPI
-- Game: SNAP SNAP

-- MAIN APPLICATION
addappid(3104540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104541, 1, "c8ff53b0bfd016ae637f3a3b6753a4e2be959a7fb0155d9c064692482ea54350")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
