-- Lua provided by RyzenAPI
-- Game: Game: Devil Slayer - Raksasi 2 Playtest

-- MAIN APPLICATION
addappid(3464750)
-- Game: addappid(3464750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464751, 1, "c527bc6ab5b7b9bf32a15a47638fc65236d84b20ec73a9d4b59a934e5364b815")
