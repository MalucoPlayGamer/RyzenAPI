-- Lua provided by RyzenAPI
-- Game: SHINOBI: Art of Vengeance

-- MAIN APPLICATION
addappid(2361770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361771,0,"6077dc2b1a88a7ae7a34470113e609a77bfc721374f4b17e20abc2f975ad2d85")
addappid(3381241,0,"a8471adc3c0b8d999f3576f04318b08df5a03609a11bf628534753443d469cdf")
addappid(3381250,0,"155147f9c285079d0c8de3a293bb7e0ebc4c5e59763e5eb6f6ddb5a14c37df25")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3381210)
addappid(3381220)
addappid(3381230)
addappid(3381240)
addappid(3381260)
