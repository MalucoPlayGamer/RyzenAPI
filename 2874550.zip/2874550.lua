-- Lua provided by RyzenAPI
-- Game: Bones Beneath

-- MAIN APPLICATION
addappid(2874550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2874551, 1, "e3d3fd5caa55a45b16fae0640b1685f136f85dd43e309f08ad1b552795fecf8d")

