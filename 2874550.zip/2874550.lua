-- Lua provided by RyzenAPI
-- Game: Bones Beneath

-- MAIN APPLICATION
addappid(2874550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874551, 1, "e3d3fd5caa55a45b16fae0640b1685f136f85dd43e309f08ad1b552795fecf8d")
