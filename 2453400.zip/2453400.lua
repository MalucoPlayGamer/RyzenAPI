-- Lua provided by RyzenAPI
-- Game: Ru Lin Wai Shi Fan Jin

-- MAIN APPLICATION
addappid(2453400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453401, 1, "5c67ede318606465540470fa6e1af3f52e19aa9995da0ce129c8b7c19d6b6fa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
