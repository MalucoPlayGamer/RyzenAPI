-- Lua provided by SkyAPI 
-- Game: Ru Lin Wai Shi Fan Jin
addappid(2453400)
addappid(2453401, 1, "5c67ede318606465540470fa6e1af3f52e19aa9995da0ce129c8b7c19d6b6fa0")
