-- Lua provided by RyzenAPI
-- Game: Ru Lin Wai Shi Fan Jin

-- MAIN APPLICATION
addappid(2453400)
-- Game: addappid(2453400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453401, 1, "5c67ede318606465540470fa6e1af3f52e19aa9995da0ce129c8b7c19d6b6fa0")
