-- Lua provided by RyzenAPI
-- Game: addappid(2602380)

-- MAIN APPLICATION
addappid(2602380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602381, 1, "3d5229f87eefe4d9a77d473282767e726dced5f0942d7a23494abaaaa89b6846")
