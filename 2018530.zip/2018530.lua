-- Lua provided by RyzenAPI
-- Game: Fanatic Zeal

-- MAIN APPLICATION
addappid(2018530)
-- Game: addappid(2018530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018531, 1, "fbf57ead24f1dc8981517aced6cc841479c50c44c9543a51a558b6a9d55c7c7c")
