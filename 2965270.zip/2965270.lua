-- Lua provided by RyzenAPI
-- Game: A Fox Tale Demo

-- MAIN APPLICATION
addappid(2965270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965271, 1, "306e209d4615c383750b3f9697af74fddecfa8f9ee88532317cb8e0bef48d16e")
