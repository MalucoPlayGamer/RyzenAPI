-- Lua provided by RyzenAPI
-- Game: MolEconomy

-- MAIN APPLICATION
addappid(3672270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672271, 1, "8588c735170e97bbc1b92fe4d60b95309ed15d6cc3680c743aa80eff4257d8dc")
