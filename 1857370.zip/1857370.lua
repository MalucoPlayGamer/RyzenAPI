-- Lua provided by RyzenAPI
-- Game: LEZ

-- MAIN APPLICATION
addappid(1857370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857371, 1, "6744150fdd52174cc6e074833485e3892e4c207292d35606dd224e6edbd9ef0f")
addappid(1857372, 1, "4e414969245b828925343640f06f662355bba15fb70a7ce40a90323f731ce000")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2364710)
