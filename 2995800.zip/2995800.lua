-- Lua provided by SkyAPI 
-- Game: RevoiceLive
addappid(2995800)
addappid(2995801, 1, "d5439ebae871ce9c89bff5f64596a455928581b63dd70f63b5723bfccbdc092b")
addappid(2995803, 1, "d6d3857c0b9ef3f09c0d63fa2b327d3b507f4ee6bf27c05ae3a302d259f6a54d")
