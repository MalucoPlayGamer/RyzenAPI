-- Lua provided by RyzenAPI
-- Game: Victorian Mysteries: The Yellow Room

-- MAIN APPLICATION
addappid(1108190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108191, 1, "e0073ad5ad146a35c0dfd47497e6a476e306529e4505f98c0081bd996ab4ff4f")
addappid(1108192, 1, "06784365b0777f3e57eec212324ccb67a9b6d76aa9795b2b321e222077bfbc7d")
addappid(1108193, 1, "8e01e5edb184bf58d7da2a0a426ca32f3ae37b87f230b5946bb45a2300f89732")
