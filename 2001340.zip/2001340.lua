-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel 2

-- MAIN APPLICATION
addappid(2082370)
addappid(2457990) -- Fuga Melodies of Steel 2 - Tail Concerto Costume Pack
addappid(2458000) -- Fuga Melodies of Steel 2 - Season Pass
addappid(2525670) -- Fuga Melodies of Steel 2 - Steampunk Costume Pack
addappid(2533490) -- Fuga Melodies of Steel 2 - Animal Costume Pack
addappid(2922110) -- Fuga Melodies of Steel 2 - Tail Concerto Sound Pack
addappid(3014300)
addappid(3132540)
addappid(3132550)
addappid(3298980)
addappid(3534970)
addappid(3653140)
addappid(3653150)
addappid(3653160)
addappid(3653170)
addappid(4070840)
addappid(4189440)
addappid(4283700)
addappid(4520460)
addappid(4520680)
addappid(4520690)
-- addappid(2001342) -- Depot 2001342 (empty depot)
-- addappid(2001343) -- Depot 2001343 (empty depot)
-- addappid(2001344) -- Depot 2001344 (empty depot)
-- addappid(2001347) -- Depot 2001347 (empty depot)
-- addappid(2001348) -- Depot 2001348 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2001340, 1, "053a95f41c17eb057dccc4a44623759419d39fda2a7ae0d41108500d8a654f94") -- Fuga: Melodies of Steel 2
addappid(2001341, 1, "a3eed706af860ca6badcea021697204628ef454677796100251d8f23d47010c8") -- Depot 2001341
addappid(2001345, 1, "150a44854022aa3cb2733063fc7e5f22222c1b47b4c0dd7fca9a1344f9ad3c87") -- Depot 2001345
addappid(2001346, 1, "d609f118bc275b23f5f2bdd5519d0d6e2f55feb4b9d12103bd69c4b2bbb3cfb6") -- Depot 2001346
addappid(2082371, 1, "caa116bf5bf6128e0001138e2c108b9a360db59eb87edf48ca098387a3903c41") -- Fuga Melodies of Steel 2 - Deluxe Edition Upgrade Pack - Depot 2082371
addappid(3014301, 1, "ccd6de2a7c3dd941677d788f07eed14c68ff2af3675cac8ae04967c4a909f733") -- Fuga Melodies of Steel 2 Little Tail Bronx Archives - Depot 3014301
addappid(3132541, 1, "cd3e495999f321353088138a8cf9e06764182c642ce8ad1bc3036e2c9e99cc40") -- Fuga Melodies of Steel (Manga) Vol. 1 - Depot 3132541
addappid(3132551, 1, "573806fe65665803727a1872efeeeb66f4966b7a77b46cba60dd5a4437b19c4f") -- Fuga Melodies of Steel (Manga) Vol. 2 - Depot 3132551
addappid(3298981, 1, "f4bff5d8db72ca88ee88630cc4dd2cc277ef4c629de0eda53c27285b49f2bb65") -- Fuga Melodies of Steel (Manga) Vol. 3 - Depot 3298981
addappid(3534971, 1, "cfe8e0f436a18dac235b8b908a6fc7106e761ebb735f3ae485da9045b84c8a17") -- Fuga Melodies of Steel (Manga) Vol. 4 - Depot 3534971
addappid(3653141, 1, "d1f30148f08a5d0a053e514090397b3f2d6cf150cd3f3432af9749e79b0d61ef") -- Fuga Melodies of Steel (Manga) Vol. 5 - Depot 3653141
addappid(3653151, 1, "2b01ed61ec162e818153997b8406bd8e0ae77f47f6c534e50a240d7735caa801") -- Fuga Melodies of Steel (Manga) Vol. 6 - Depot 3653151
addappid(3653161, 1, "e34b429d1aa57fd1b8013a5c5b605c31bc150d40cf19193460e6464458125336") -- Fuga Melodies of Steel (Manga) Vol. 7 - Depot 3653161
addappid(3653171, 1, "32b610765e08c7add83b68fb885c07af092a343ced1e4d33b0fa27cf9beb90df") -- Fuga Melodies of Steel (Manga) Vol. 8 - Depot 3653171
addappid(4070841, 1, "c03dad3817afeb8de16a181dec589b162cb3f8c72cc0d15894ea315ed374cb17") -- Fuga Melodies of Steel (Manga) Vol. 9 - Depot 4070841
addappid(4189441, 1, "e29bc72136bdfd1d50965f5fcb54a38d79cf81bca145b6bec1b4aaaf8b747db5") -- Fuga Melodies of Steel (Manga) Vol. 10 - Depot 4189441
addappid(4283701, 1, "0e369c72d3d168f981e3a1cf35df322fb7a0aa9f254f7325092a5202d071d526") -- Fuga Melodies of Steel (Manga) Vol. 11 - Depot 4283701
addappid(4520461, 1, "8dce908b5c6f558f93a2edf4ab08d3aa5695d906d6e368aadb7be7e47292a6cb") -- Fuga Melodies of Steel (Manga) Vol. 12 - Depot 4520461
addappid(4520681, 1, "c49db3ef2e146bcbc2d621a00cd32f785a16d86c2e6da578f61a994f2e931351") -- Fuga Melodies of Steel Part One Hax Arc - Depot 4520681
addappid(4520691, 1, "96785937382be5673347a80ca51ce6459ac4305f1552122ce29edd7dcf53dfaa") -- Fuga Melodies of Steel Part Two Jihl Arc - Depot 4520691

