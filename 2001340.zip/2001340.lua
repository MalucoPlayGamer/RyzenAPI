-- Lua provided by RyzenAPI 
-- Game: Fuga: Melodies of Steel 2
addappid(2001340)
addappid(2001341, 1, "a3eed706af860ca6badcea021697204628ef454677796100251d8f23d47010c8")
addappid(2001345, 1, "150a44854022aa3cb2733063fc7e5f22222c1b47b4c0dd7fca9a1344f9ad3c87")
addappid(2001346, 1, "d609f118bc275b23f5f2bdd5519d0d6e2f55feb4b9d12103bd69c4b2bbb3cfb6")
