-- 2001340's Lua and Manifest Created by Hubcap Manifest
-- Fuga: Melodies of Steel 2
-- Created: August 16, 2026 at 07:27:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 21
-- Total DLCs: 21
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2001340, 1, "053a95f41c17eb057dccc4a44623759419d39fda2a7ae0d41108500d8a654f94") -- Fuga: Melodies of Steel 2
-- MAIN APP DEPOTS
addappid(2001341, 1, "a3eed706af860ca6badcea021697204628ef454677796100251d8f23d47010c8") -- Depot 2001341
setManifestid(2001341, "611332935983898456", 4991036251)
addappid(2001345, 1, "150a44854022aa3cb2733063fc7e5f22222c1b47b4c0dd7fca9a1344f9ad3c87") -- Depot 2001345
setManifestid(2001345, "5215011444449763475", 0)
addappid(2001346, 1, "d609f118bc275b23f5f2bdd5519d0d6e2f55feb4b9d12103bd69c4b2bbb3cfb6") -- Depot 2001346
setManifestid(2001346, "577429841654460915", 0)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Fuga Melodies of Steel 2 - Deluxe Edition Upgrade Pack (AppID: 2082370)
addappid(2082370)
addappid(2082371, 1, "caa116bf5bf6128e0001138e2c108b9a360db59eb87edf48ca098387a3903c41") -- Fuga Melodies of Steel 2 - Deluxe Edition Upgrade Pack - Depot 2082371
setManifestid(2082371, "8822065810503819419", 157351851)
-- Fuga Melodies of Steel 2 Little Tail Bronx Archives (AppID: 3014300)
addappid(3014300)
addappid(3014301, 1, "ccd6de2a7c3dd941677d788f07eed14c68ff2af3675cac8ae04967c4a909f733") -- Fuga Melodies of Steel 2 Little Tail Bronx Archives - Depot 3014301
setManifestid(3014301, "5049232068563724105", 175778481)
-- Fuga Melodies of Steel (Manga) Vol. 1 (AppID: 3132540)
addappid(3132540)
addappid(3132541, 1, "cd3e495999f321353088138a8cf9e06764182c642ce8ad1bc3036e2c9e99cc40") -- Fuga Melodies of Steel (Manga) Vol. 1 - Depot 3132541
setManifestid(3132541, "781185304898532365", 126489486)
-- Fuga Melodies of Steel (Manga) Vol. 2 (AppID: 3132550)
addappid(3132550)
addappid(3132551, 1, "573806fe65665803727a1872efeeeb66f4966b7a77b46cba60dd5a4437b19c4f") -- Fuga Melodies of Steel (Manga) Vol. 2 - Depot 3132551
setManifestid(3132551, "5610468213920079328", 106058811)
-- Fuga Melodies of Steel (Manga) Vol. 3 (AppID: 3298980)
addappid(3298980)
addappid(3298981, 1, "f4bff5d8db72ca88ee88630cc4dd2cc277ef4c629de0eda53c27285b49f2bb65") -- Fuga Melodies of Steel (Manga) Vol. 3 - Depot 3298981
setManifestid(3298981, "5762983711266895275", 105146975)
-- Fuga Melodies of Steel (Manga) Vol. 4 (AppID: 3534970)
addappid(3534970)
addappid(3534971, 1, "cfe8e0f436a18dac235b8b908a6fc7106e761ebb735f3ae485da9045b84c8a17") -- Fuga Melodies of Steel (Manga) Vol. 4 - Depot 3534971
setManifestid(3534971, "1063243828129682131", 95827593)
-- Fuga Melodies of Steel (Manga) Vol. 5 (AppID: 3653140)
addappid(3653140)
addappid(3653141, 1, "d1f30148f08a5d0a053e514090397b3f2d6cf150cd3f3432af9749e79b0d61ef") -- Fuga Melodies of Steel (Manga) Vol. 5 - Depot 3653141
setManifestid(3653141, "5150928761378359964", 90494805)
-- Fuga Melodies of Steel (Manga) Vol. 6 (AppID: 3653150)
addappid(3653150)
addappid(3653151, 1, "2b01ed61ec162e818153997b8406bd8e0ae77f47f6c534e50a240d7735caa801") -- Fuga Melodies of Steel (Manga) Vol. 6 - Depot 3653151
setManifestid(3653151, "932228527902186722", 99713223)
-- Fuga Melodies of Steel (Manga) Vol. 7 (AppID: 3653160)
addappid(3653160)
addappid(3653161, 1, "e34b429d1aa57fd1b8013a5c5b605c31bc150d40cf19193460e6464458125336") -- Fuga Melodies of Steel (Manga) Vol. 7 - Depot 3653161
setManifestid(3653161, "3354608735768425267", 140309152)
-- Fuga Melodies of Steel (Manga) Vol. 8 (AppID: 3653170)
addappid(3653170)
addappid(3653171, 1, "32b610765e08c7add83b68fb885c07af092a343ced1e4d33b0fa27cf9beb90df") -- Fuga Melodies of Steel (Manga) Vol. 8 - Depot 3653171
setManifestid(3653171, "7240858994533658790", 142541726)
-- Fuga Melodies of Steel (Manga) Vol. 9 (AppID: 4070840)
addappid(4070840)
addappid(4070841, 1, "c03dad3817afeb8de16a181dec589b162cb3f8c72cc0d15894ea315ed374cb17") -- Fuga Melodies of Steel (Manga) Vol. 9 - Depot 4070841
setManifestid(4070841, "5615806128582899288", 120624226)
-- Fuga Melodies of Steel (Manga) Vol. 10 (AppID: 4189440)
addappid(4189440)
addappid(4189441, 1, "e29bc72136bdfd1d50965f5fcb54a38d79cf81bca145b6bec1b4aaaf8b747db5") -- Fuga Melodies of Steel (Manga) Vol. 10 - Depot 4189441
setManifestid(4189441, "648547879846443826", 122203615)
-- Fuga Melodies of Steel (Manga) Vol. 11 (AppID: 4283700)
addappid(4283700)
addappid(4283701, 1, "0e369c72d3d168f981e3a1cf35df322fb7a0aa9f254f7325092a5202d071d526") -- Fuga Melodies of Steel (Manga) Vol. 11 - Depot 4283701
setManifestid(4283701, "9012951354877700531", 108716571)
-- Fuga Melodies of Steel (Manga) Vol. 12 (AppID: 4520460)
addappid(4520460)
addappid(4520461, 1, "8dce908b5c6f558f93a2edf4ab08d3aa5695d906d6e368aadb7be7e47292a6cb") -- Fuga Melodies of Steel (Manga) Vol. 12 - Depot 4520461
setManifestid(4520461, "5729509809534751053", 96803644)
-- Fuga Melodies of Steel Part One Hax Arc (AppID: 4520680)
addappid(4520680)
addappid(4520681, 1, "c49db3ef2e146bcbc2d621a00cd32f785a16d86c2e6da578f61a994f2e931351") -- Fuga Melodies of Steel Part One Hax Arc - Depot 4520681
setManifestid(4520681, "5545327512327373629", 374666082)
-- Fuga Melodies of Steel Part Two Jihl Arc (AppID: 4520690)
addappid(4520690)
addappid(4520691, 1, "96785937382be5673347a80ca51ce6459ac4305f1552122ce29edd7dcf53dfaa") -- Fuga Melodies of Steel Part Two Jihl Arc - Depot 4520691
setManifestid(4520691, "6083309311929063837", 422386579)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2457990) -- Fuga Melodies of Steel 2 - Tail Concerto Costume Pack
addappid(2458000) -- Fuga Melodies of Steel 2 - Season Pass
addappid(2525670) -- Fuga Melodies of Steel 2 - Steampunk Costume Pack
addappid(2533490) -- Fuga Melodies of Steel 2 - Animal Costume Pack
addappid(2922110) -- Fuga Melodies of Steel 2 - Tail Concerto Sound Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2001342) -- Depot 2001342 (empty depot)
-- addappid(2001343) -- Depot 2001343 (empty depot)
-- addappid(2001344) -- Depot 2001344 (empty depot)
-- addappid(2001347) -- Depot 2001347 (empty depot)
-- addappid(2001348) -- Depot 2001348 (empty depot)