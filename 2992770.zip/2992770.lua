-- Lua provided by RyzenAPI
-- Game: Skeleton Messy Demo

-- MAIN APPLICATION
addappid(2992770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992771, 1, "18c470f46c1e3b2bde1bfb5bed5d0ea1fda6ebe523445a9e8c312b6db95cbfbd")

