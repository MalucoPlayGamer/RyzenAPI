-- Lua provided by RyzenAPI 
-- Game: Cardboard Chronicles
addappid(2807290)
addappid(2807291, 1, "52d422e9d3f114f2728ed98f419baef2462d636b8cf0bed90f1d797c97cf1cd8")
