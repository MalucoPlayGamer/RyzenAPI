-- Lua provided by RyzenAPI
-- Game: Cardboard Chronicles

-- MAIN APPLICATION
addappid(2807290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2807291, 1, "52d422e9d3f114f2728ed98f419baef2462d636b8cf0bed90f1d797c97cf1cd8")

