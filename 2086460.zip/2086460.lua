-- Lua provided by RyzenAPI 
-- Game: Idle Factory
addappid(2086460)
addappid(2086461, 1, "cfdf1f7c9ad5863c18f7d9702fa20bde844014a58860138fbeb49e936ef81871")
