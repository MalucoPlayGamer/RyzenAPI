-- Lua provided by RyzenAPI
-- Game: Dark Devotion

-- MAIN APPLICATION
addappid(718590)
-- Game: addappid(718590)

-- MAIN APP DEPOTS / PACKAGES
addappid(718599,0,"4469a0c985275abd6b5a8966baf0d3cf7801505c441848a4d06dc728d2ea57d9")
