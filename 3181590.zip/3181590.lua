-- Lua provided by RyzenAPI
-- Game: addappid(3181590)

-- MAIN APPLICATION
addappid(3181590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181590,0,"88e81b37f695e06ce5fc17a56c4dd72a25172908b29ff8ba9543c35cd1f494ae")
