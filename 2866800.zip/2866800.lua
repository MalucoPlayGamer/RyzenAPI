-- Lua provided by RyzenAPI
-- Game: Mental State. Game One

-- MAIN APPLICATION
addappid(2866800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866801, 1, "b05757fd419fe2f522a674c71768b1fd548b741ddefabea8d0a434f2637a0160")

