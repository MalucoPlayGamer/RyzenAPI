-- Lua provided by RyzenAPI
-- Game: Chance at Life

-- MAIN APPLICATION
addappid(2000540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2000541, 1, "a2575afa6a1bc1475383f0c640bc63290ce1d31f266233c32e3ce9c5217d6f66")

