-- Lua provided by RyzenAPI
-- Game: Chance at Life

-- MAIN APPLICATION
addappid(2000540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000541, 1, "a2575afa6a1bc1475383f0c640bc63290ce1d31f266233c32e3ce9c5217d6f66")

