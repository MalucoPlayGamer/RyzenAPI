-- Lua provided by RyzenAPI
-- Game: Beat Saber - Britney Spears x Will.I.AM - Scream and Shout (Will.I.AM)

-- MAIN APPLICATION
addappid(3181570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181570,0,"6500895d30a9017f105483e3293b4494bd68f6b0a30c39f752401132aedaa5fa")
