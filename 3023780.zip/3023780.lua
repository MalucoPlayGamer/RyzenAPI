-- Lua provided by RyzenAPI
-- Game: NO-SKIN Demo

-- MAIN APPLICATION
addappid(3023780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023781, 1, "c68a47d833230f748fc4e85ad0f477c10f1aadf42d37d4461bd8d56c91eafe09")
