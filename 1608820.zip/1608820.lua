-- Lua provided by SkyAPI 
-- Game: OGgolf
addappid(1608820)
addappid(1608821, 1, "4cbac3187c7c4e5d139ca88abf2bbacb47bd90f0a1ccba46db7d0fd29b5f8ac2")
