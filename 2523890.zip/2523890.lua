-- Lua provided by RyzenAPI
-- Game: Whispers of the Eyeless

-- MAIN APPLICATION
addappid(2523890)
addappid(4332100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2523891, 1, "83437f3f5e700f8dd152ae2dfc17434c2db28d04783993d736d5e4baed4a33e4")

