-- Lua provided by SkyAPI 
-- Game: Whispers of the Eyeless
addappid(2523890)
addappid(2523891, 1, "83437f3f5e700f8dd152ae2dfc17434c2db28d04783993d736d5e4baed4a33e4")
