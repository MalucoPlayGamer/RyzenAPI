-- Lua provided by RyzenAPI
-- Game: 2523890

-- MAIN APPLICATION
addappid(2523890)
-- Game: addappid(2523890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523891, 1, "83437f3f5e700f8dd152ae2dfc17434c2db28d04783993d736d5e4baed4a33e4")
