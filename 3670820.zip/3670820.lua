-- Lua provided by RyzenAPI
-- Game: Restore

-- MAIN APPLICATION
addappid(3670820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3670821,0,"447d0d9fbd4a3a27fd0768196b6fce5bd81a61f34291676fa0848247c2d7d9da")

