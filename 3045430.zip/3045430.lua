-- Lua provided by RyzenAPI
-- Game: Game: 装甲红锋 Playtest

-- MAIN APPLICATION
addappid(3045430)
-- Game: addappid(3045430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3045431, 1, "921a900f083ce10155e970faae1765011f609987242ef36e91646130dfe2139c")
