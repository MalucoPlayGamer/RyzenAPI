-- Lua provided by RyzenAPI
-- Game: 2089110

-- MAIN APPLICATION
addappid(2089110)
-- Game: addappid(2089110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089111, 1, "a9f247840068583e1200742d37ff3aa78bb33c4ad3a85b6d6a0f8062e7f75c10")
