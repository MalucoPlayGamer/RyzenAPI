-- Lua provided by RyzenAPI
-- Game: HOTEL GREENWOOD

-- MAIN APPLICATION
addappid(2089110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2089111, 1, "a9f247840068583e1200742d37ff3aa78bb33c4ad3a85b6d6a0f8062e7f75c10")

