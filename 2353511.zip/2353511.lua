-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2353511)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418070,0,"9a46ff4127b070013ea0189940cec49551f33a7e20b2c6b612565be0502a5a78")
addappid(2418071,0,"294731a01d179f2db60818570da445503017dd973ac474291fbc855e20502be3")
