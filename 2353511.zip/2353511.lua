-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2353511)
addappid(2418070,0,"9a46ff4127b070013ea0189940cec49551f33a7e20b2c6b612565be0502a5a78")
-- setManifestid(2418070,"3463837528970200612")
addappid(2418071,0,"294731a01d179f2db60818570da445503017dd973ac474291fbc855e20502be3")
-- setManifestid(2418071,"3577794892998287564")