-- Lua provided by RyzenAPI
-- Game: addappid(911950)

-- MAIN APPLICATION
addappid(911950)

-- MAIN APP DEPOTS / PACKAGES
addappid(911951, 1, "6a73cc5bd3d6477eba3e8acdf6e95842d057725c3e8d87459271b513af4fcd02")
