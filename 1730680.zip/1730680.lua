-- Lua provided by RyzenAPI
-- Game: Klonoa Phantasy Reverie Series

-- MAIN APPLICATION
addappid(1730680)
addappid(1930760)
addappid(1930761)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730681, 1, "3467fb3a81e7b40eea95d0cf726bb8491dcd4b2b141aa1e7e19747775103b12b")
addappid(1913570, 1, "673da2bf877cd5f706e51603bb5a618116f035371d0c9b15777ca4284e1e3600")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2006810)
