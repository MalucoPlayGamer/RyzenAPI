-- Lua provided by RyzenAPI
-- Game: Klonoa Phantasy Reverie Series

-- MAIN APPLICATION
addappid(1730680)
addappid(1930760)
addappid(1930761)
-- Game: addappid(1730680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730681, 1, "3467fb3a81e7b40eea95d0cf726bb8491dcd4b2b141aa1e7e19747775103b12b")
addappid(1913570, 1, "673da2bf877cd5f706e51603bb5a618116f035371d0c9b15777ca4284e1e3600")
