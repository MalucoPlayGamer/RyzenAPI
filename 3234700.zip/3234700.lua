-- Lua provided by RyzenAPI
-- Game: Game: Break Siege

-- MAIN APPLICATION
addappid(3234700)
-- Game: addappid(3234700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234701, 1, "6df023d134893521f2bc184f1263815fc10a66a5e1f94d12e18fcd95c16007dd")
