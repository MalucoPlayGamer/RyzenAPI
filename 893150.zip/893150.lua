-- Lua provided by RyzenAPI 
-- Game: Fury Strike
addappid(893150)
addappid(893151, 1, "bc5e325a27c06515d43f8b3f717873298dd620a166e53d46648dc838156190d8")
