-- Lua provided by RyzenAPI
-- Game: Game: Fury Strike

-- MAIN APPLICATION
addappid(893150)
-- Game: addappid(893150)

-- MAIN APP DEPOTS / PACKAGES
addappid(893151, 1, "bc5e325a27c06515d43f8b3f717873298dd620a166e53d46648dc838156190d8")
