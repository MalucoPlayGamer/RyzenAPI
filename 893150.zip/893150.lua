-- Lua provided by RyzenAPI
-- Game: Fury Strike

-- MAIN APPLICATION
addappid(893150)

-- MAIN APP DEPOTS / PACKAGES
addappid(893151, 1, "bc5e325a27c06515d43f8b3f717873298dd620a166e53d46648dc838156190d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
