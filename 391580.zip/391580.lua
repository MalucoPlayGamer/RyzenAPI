-- Lua provided by RyzenAPI
-- Game: 391580

-- MAIN APPLICATION
addappid(391580)
-- Game: addappid(391580)

-- MAIN APP DEPOTS / PACKAGES
addappid(391581, 1, "b4661f0154feb738764936044ff55b919658e5b67ec1959050aca96ad52d51e2")
addappid(391582, 1, "081b5807bc790cb1be0d245a97d5d71969cde185e33b3d1d3ff3bd20a3bab69d")
