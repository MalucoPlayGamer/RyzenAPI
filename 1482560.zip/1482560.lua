-- Lua provided by RyzenAPI 
-- Game: Dungeon Munchies Original Soundtrack Vol.1
addappid(1482560)
addappid(1482561, 1, "9f659b6c61eab54be10b4fef1ba15af63b8a091152f05d0033ee7184fc0a9051")
