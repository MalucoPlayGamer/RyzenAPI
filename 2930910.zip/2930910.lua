-- Lua provided by RyzenAPI
-- Game: 2930910

-- MAIN APPLICATION
addappid(2930910)
-- Game: addappid(2930910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930911, 1, "8340225bf00fd9084d549dbfa469c1068474a2d83af74135ab3793cec6eec8ec")
