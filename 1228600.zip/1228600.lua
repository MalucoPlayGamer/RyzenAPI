-- 1228600's Lua and Manifest Created by Hubcap Manifest
-- Blankspace
-- Created: August 09, 2026 at 00:20:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1228600, 1, "89c9d64c03409c4d2638e294238545d1bd324b2e47986bdbe83be83f68345247") -- Blankspace
-- MAIN APP DEPOTS
addappid(1228601, 1, "0ec3a96ff6eac3c89b0363bf09a586db7e8e87840bb04e32b92b359a1f978120") -- Blankspace Content
setManifestid(1228601, "2370995372423775075", 558893847)
-- DLCS WITH DEDICATED DEPOTS
-- Blankspace - Digital Artbook (AppID: 1736940)
addappid(1736940)
addappid(1736940, 1, "d6c44401384314c2ce12261c850997268b1f9b9f1e8a4cd81b27a3867d060c00") -- Blankspace - Digital Artbook - Blankspace - Digital Artbook (+Wallpaper Pack) (1736940) Depot
setManifestid(1736940, "6079334212832786819", 69740062)
-- Blankspace - Additional Text Patch (18) (AppID: 1736950)
addappid(1736950)
addappid(1736950, 1, "f745eae225332fac67ee8e36ffd87fe3253a282a950437b856aabe2ec0fb1b1a") -- Blankspace - Additional Text Patch (18) - Blankspace - Additional Text Patch (18+) (1736950) Depot
setManifestid(1736950, "6708947437779940491", 2202657)