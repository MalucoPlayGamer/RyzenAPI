-- Lua provided by RyzenAPI
-- Game: Blankspace

-- MAIN APPLICATION
addappid(1736940)
addappid(1736950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228600, 1, "89c9d64c03409c4d2638e294238545d1bd324b2e47986bdbe83be83f68345247") -- Blankspace
addappid(1228601, 1, "0ec3a96ff6eac3c89b0363bf09a586db7e8e87840bb04e32b92b359a1f978120") -- Blankspace Content
addappid(1736940, 1, "d6c44401384314c2ce12261c850997268b1f9b9f1e8a4cd81b27a3867d060c00") -- Blankspace - Digital Artbook - Blankspace - Digital Artbook (+Wallpaper Pack) (1736940) Depot
addappid(1736950, 1, "f745eae225332fac67ee8e36ffd87fe3253a282a950437b856aabe2ec0fb1b1a") -- Blankspace - Additional Text Patch (18) - Blankspace - Additional Text Patch (18+) (1736950) Depot

