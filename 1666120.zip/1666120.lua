-- Lua provided by RyzenAPI
-- Game: addappid(1666120)

-- MAIN APPLICATION
addappid(1666120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666121, 1, "f7aff230c484ba71384fb12775f1070d23a31ff4ebb12e140100afc53c74df03")
