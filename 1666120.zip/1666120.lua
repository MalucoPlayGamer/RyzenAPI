-- Lua provided by SkyAPI 
-- Game: AppID 1666120
addappid(1666120)
addappid(1666121, 1, "f7aff230c484ba71384fb12775f1070d23a31ff4ebb12e140100afc53c74df03")
