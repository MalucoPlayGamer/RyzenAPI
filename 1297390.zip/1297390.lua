-- Lua provided by RyzenAPI 
-- Game: AppID 1297390
addappid(1297390)
addappid(1297391, 1, "0f31041a095d2ebb445aa47e004ad016b6f515b60b8e6195ce2d3e5b85a1476a")
