-- Lua provided by RyzenAPI
-- Game: Strange Telephone

-- MAIN APPLICATION
addappid(705290)

-- MAIN APP DEPOTS / PACKAGES
addappid(705291, 1, "96eb130f5570cfa62c1109b4f5c9bb589e022f89fa016de136d267dffc6eb67d")
addappid(705292, 1, "383bb8bac542209ab2e9551bb82c9360dd5c97ff1e8ffd2fa3e5096b23cffbc9")
