-- Lua provided by RyzenAPI
-- Game: 3183690

-- MAIN APPLICATION
addappid(3183690)
-- Game: addappid(3183690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183690,0,"a20a6866fb9b7bebb9e297212f2a4d4341aa34337498e5af1ef109000406ad65")
