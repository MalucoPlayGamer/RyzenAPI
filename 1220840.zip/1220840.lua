-- Lua provided by RyzenAPI
-- Game: 1220840

-- MAIN APPLICATION
addappid(1220840)
-- Game: addappid(1220840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220841, 1, "ef66866d11e6b3186a9e0ce7ababa181e97149742fc73c7b5c132d8207e34f89")
