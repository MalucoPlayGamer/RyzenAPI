-- Lua provided by SkyAPI 
-- Game: An English Haunting
addappid(2474030)
addappid(2474031, 1, "7afe54c547485f788175df84a14aa9959a5a637fcbc0e86301cf550270a0384a")
