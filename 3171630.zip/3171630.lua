-- Lua provided by RyzenAPI
-- Game: Witch's Dungeon

-- MAIN APPLICATION
addappid(3171630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171631, 1, "de061bb5cc63d88e03762671dc7021105d7f54aaf42713b1ddc895616c9aa703")

