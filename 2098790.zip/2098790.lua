-- Lua provided by RyzenAPI
-- Game: 群侠传，启动！

-- MAIN APPLICATION
addappid(2098790)
