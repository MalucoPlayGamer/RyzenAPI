-- Lua provided by RyzenAPI
-- Game: 群侠传，启动！

-- MAIN APPLICATION
addappid(2098790)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2298200)
