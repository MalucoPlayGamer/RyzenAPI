-- Lua provided by RyzenAPI
-- Game: ReEarth

-- MAIN APPLICATION
addappid(3034560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034562,0,"51593b4111fd7b04f2a5353d2b0d8cf82c811bfbcf8272890ecccf41a096ad96")
