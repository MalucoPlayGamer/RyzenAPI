-- Lua provided by RyzenAPI
-- Game: Where Christmas Elves 圣诞精灵在哪里

-- MAIN APPLICATION
addappid(2685200)
-- Game: addappid(2685200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685201, 1, "661490bd98fd92ebcd0c202b02e25e1177edb09c743ca1ff42273d33ca3cf7e0")
