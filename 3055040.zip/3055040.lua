-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Feelgood Funk Radio

-- MAIN APPLICATION
addappid(3055040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3055040,0,"3b44a007515e566327cfc4ed209b8c71ffe4789a4a12fe3659caae3bf23440d3")

