-- Lua provided by RyzenAPI
-- Game: 2248120

-- MAIN APPLICATION
addappid(2248120)
-- Game: addappid(2248120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248122,0,"39de9dfd269168f0bac53e5b56bcc6a8619dc8fc157f167e4d48e3f4ff81a5da")
addappid(2248123,0,"9c240a515625bc33fa3e106e206b2f905e5cae1dfcb14183960a014edbd349da")
addappid(2248124,0,"419b891eba614c754f3dc2b5bfab0bd83ba8a00b0f556bbf43c980e8045e3380")
