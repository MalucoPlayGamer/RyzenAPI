-- Lua provided by RyzenAPI
-- Game: AppID 587100

-- MAIN APPLICATION
addappid(587100)

-- MAIN APP DEPOTS / PACKAGES
addappid(587101, 1, "9de8695feb70f6643738e8a2798b8eca53b08bd4b7df327efb4408a55ad6b9d2")
