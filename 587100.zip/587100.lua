-- Lua provided by RyzenAPI
-- Game: Ys SEVEN

-- MAIN APPLICATION
addappid(587100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(587101, 1, "9de8695feb70f6643738e8a2798b8eca53b08bd4b7df327efb4408a55ad6b9d2")
