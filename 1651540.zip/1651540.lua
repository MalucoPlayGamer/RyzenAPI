-- Lua provided by SkyAPI 
-- Game: Memories with my Kitten
addappid(1651540)
addappid(1651541, 1, "27197720a169f1de9b1e65b94c4a31764a8bf0bae41b6054e91e8d6985a1174b")
