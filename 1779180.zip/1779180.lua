-- Lua provided by RyzenAPI
-- Game: addappid(1779180)

-- MAIN APPLICATION
addappid(1779180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779181, 1, "af22ec04e86b5f4e9c17e87bb1d9143bb5141af7be571bfcb9c7dec8c6ab3baf")
