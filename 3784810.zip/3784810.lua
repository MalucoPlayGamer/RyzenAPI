-- Lua provided by RyzenAPI
-- Game: Last Presence

-- MAIN APPLICATION
addappid(3784810)
-- Game: addappid(3784810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3784811, 1, "da7a1aeb2685a280d9a97cc530f2120c3816b22a94c1f75e8f29cf00aff801cd")
