-- Lua provided by RyzenAPI
-- Game: That Time I Got Abducted by KYONYUU ALIENS

-- MAIN APPLICATION
addappid(2840940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840941,0,"74f88f113e8ba99a1a1e766aa1ca5f17b73ca430f42cc819fac058b0cafd0603")

