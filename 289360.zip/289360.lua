-- Lua provided by RyzenAPI
-- Game: Game: AppID 289360

-- MAIN APPLICATION
addappid(289360)
-- Game: addappid(289360)

-- MAIN APP DEPOTS / PACKAGES
addappid(289361, 1, "b721a11d9015ff988e4ffc98d0dcfad7160984b015dd2fcd436c53b85ea56db6")
addappid(289362, 1, "6b50d361c7858991b7421041dfc35bd06144eff422213c9ab36afa3512ca1ad4")
addappid(289363, 1, "bc4d11d4f283e6db17c5c7b4c9329a9da3423062cad49551eb3381b49788c9a7")
