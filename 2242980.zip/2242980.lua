-- Lua provided by RyzenAPI
-- Game: 2242980

-- MAIN APPLICATION
addappid(2242980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242982,0,"815752ef963dcf20b2c67083b44cfcb7acc684267a4feb71b3adf9df7425a5da")
