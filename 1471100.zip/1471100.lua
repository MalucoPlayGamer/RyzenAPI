-- Lua provided by RyzenAPI
-- Game: AppID 1471100

-- MAIN APPLICATION
addappid(1471100)
-- Game: addappid(1471100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471101, 1, "1f553735d3cac92ff9b01fe8ed1234116328968e852d69fc543f9fcca0fc6c21")
