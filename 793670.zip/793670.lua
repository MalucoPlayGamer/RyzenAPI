-- Lua provided by RyzenAPI
-- Game: The Wastes

-- MAIN APPLICATION
addappid(793670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(793671,0,"2058b05c459952d6c7ef442b11ca6f6206081ecf622da19210f91e44c4fc6d1b")
addappid(793672,0,"2057dd00a5ee7e73ad8cade5df9f0e470104ea5e63fc10f93e833fa9b5a23aca")

