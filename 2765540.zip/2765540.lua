-- Lua provided by RyzenAPI
-- Game: addappid(2765540)

-- MAIN APPLICATION
addappid(2765540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765541, 1, "304cfd484eda9dd4be1412e8a0b8cbce9301a62ba96ac66d8fa25f66d271a898")
