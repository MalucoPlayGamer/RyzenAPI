-- Lua provided by RyzenAPI
-- Game: addappid(1509370)

-- MAIN APPLICATION
addappid(1509370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509371, 1, "b5f09d6c3d9c08cd8645e53f5b6911d9d323cf35af8cccaa211e7ddf3f7c4b31")
