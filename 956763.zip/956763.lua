-- Lua provided by RyzenAPI
-- Game: Zhang Jiao - Officer Ticket / 張角使用券

-- MAIN APPLICATION
addappid(956763)

-- MAIN APP DEPOTS / PACKAGES
addappid(956763,0,"c18484f94f36d1ddb78ec8073ae1a3f5b504ea6c1e94f09670a239de601a7e22")
