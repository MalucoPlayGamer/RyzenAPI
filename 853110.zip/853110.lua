-- Lua provided by RyzenAPI
-- Game: Viki Spotter: Sports

-- MAIN APPLICATION
addappid(853110)

-- MAIN APP DEPOTS / PACKAGES
addappid(853111, 1, "717c26a88e9d3cbf28120b7933f09742013f19add7f9495403ff9a93991a95b3")
