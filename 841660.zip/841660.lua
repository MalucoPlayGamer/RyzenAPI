-- Lua provided by RyzenAPI
-- Game: The Treehouse Man

-- MAIN APPLICATION
addappid(841660)
-- Game: addappid(841660)

-- MAIN APP DEPOTS / PACKAGES
addappid(841661, 1, "707146d25058bd73a82cb50ffb7805b5cd8c220cf93f3bb1dcd6f90988d762f0")
addappid(855660, 0, "26433d9cbc8b296dfbfa1400ce473f5d0a151e9d4109c9ebdbb25983db69d649")
