-- Lua provided by SkyAPI 
-- Game: Otaku's Adventure - The World Just Keeps Turning
addappid(1610220)
addappid(1610221, 1, "e97141bec1645aa289e31241959f706a3fc1e2f32d0de37bfe9ee63a150d9843")
addappid(1610222, 1, "7e1326258b468e508ba95a907dbab19a82e66231aa8344aab788c432eb53ba25")
addappid(1610224, 1, "e322b11d6a7562b82ece0b3128a2b02ffc930c24da7abb1c1c1297633adab1f1")
addappid(1610225, 1, "8e0e02873bc9c86fc17e783cd5af840144fb88acfc3e371fa2a06f7ad8ac1b8e")
addappid(1610226, 1, "09752b6730d84ab769b50b5917d7445b575553432eea6a5fba2d5a34ac452fd5")
addappid(1610227, 1, "ffaafa4edab7ecfb51c14e99936edf9423ee31f98be8b2b54529e7fb34ef8e61")
