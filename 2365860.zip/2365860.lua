-- Lua provided by RyzenAPI
-- Game: 2365860

-- MAIN APPLICATION
addappid(2365860)
-- Game: addappid(2365860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365861, 1, "7fbd38a3b5443861c2e95b1288252a848bd3ef9e373a46a52ee5093b72de8605")
