-- Lua provided by RyzenAPI 
-- Game: Breeding Village
addappid(1061490)
addappid(1061491, 1, "67dce914b79299e5f14f4efb42f11e5bb105d18ca5d743067f360760a7cffc65")
