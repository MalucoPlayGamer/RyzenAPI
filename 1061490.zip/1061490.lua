-- Lua provided by RyzenAPI
-- Game: addappid(1061490)

-- MAIN APPLICATION
addappid(1061490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061491, 1, "67dce914b79299e5f14f4efb42f11e5bb105d18ca5d743067f360760a7cffc65")
