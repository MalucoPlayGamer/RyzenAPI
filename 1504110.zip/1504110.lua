-- Lua provided by RyzenAPI
-- Game: Game: Grandiose

-- MAIN APPLICATION
addappid(1504110)
-- Game: addappid(1504110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504111, 1, "6ac35e2dfe47839e7575ee4d9527c90eeb33c2cd8876cad7551073587bfb362f")
