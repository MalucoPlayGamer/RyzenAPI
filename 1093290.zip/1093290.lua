-- Lua provided by SkyAPI 
-- Game: AppID 1093290
addappid(1093290)
addappid(1093291, 1, "0cf3c627280f11d35b5111a5daf1698a1f43e52f205c493fae63edcc8b859235")
addappid(1093292, 1, "1bfbeaf4ef8cf41345c537fee04bf37d4690a9ab60a5eb069cb383ace996f436")
