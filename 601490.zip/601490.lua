-- Lua provided by RyzenAPI
-- Game: Passengers: Awakening

-- MAIN APPLICATION
addappid(601490)

-- MAIN APP DEPOTS / PACKAGES
addappid(601491,0,"a5469b3e08f33e67bbf57c02b309c04f4cad583d79cf605fe57913f4464332a4")

