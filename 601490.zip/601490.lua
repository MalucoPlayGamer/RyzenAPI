-- Lua provided by RyzenAPI
-- Game: Passengers: Awakening

-- MAIN APPLICATION
addappid(601490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(601491,0,"a5469b3e08f33e67bbf57c02b309c04f4cad583d79cf605fe57913f4464332a4")

