-- Lua provided by RyzenAPI
-- Game: The Other: Rosie's Road of Love

-- MAIN APPLICATION
addappid(1509790)
addappid(1565930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509791, 1, "78b6cf2adcd5fdaff59352e91553bd7685dfb6fa66d96d85f28e5560c3b27499")

