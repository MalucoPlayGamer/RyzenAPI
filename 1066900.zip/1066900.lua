-- Lua provided by RyzenAPI
-- Game: qomp

-- MAIN APPLICATION
addappid(1066900)
addappid(1066902)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066904,0,"2d50dc443bdaa895713598781b4539c1122c21a2644c7373e01aa45eeae0357f")

