-- Lua provided by RyzenAPI
-- Game: Prismatic Maze

-- MAIN APPLICATION
addappid(1045300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045301, 1, "dbe2bdc0844514ce457f43bd78b426c167f07b68558848109659f387d435df33")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
