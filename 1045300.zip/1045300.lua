-- Lua provided by RyzenAPI
-- Game: Prismatic Maze

-- MAIN APPLICATION
addappid(1045300)
-- Game: addappid(1045300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045301, 1, "dbe2bdc0844514ce457f43bd78b426c167f07b68558848109659f387d435df33")
