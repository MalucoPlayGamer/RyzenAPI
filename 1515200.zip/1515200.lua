-- Lua provided by RyzenAPI
-- Game: Mission in Snowdriftland

-- MAIN APPLICATION
addappid(1515200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515201, 1, "da1aff41e5dc354e9d956adb05562d2cf21918dbda8a2820656720a1a4e57368")
