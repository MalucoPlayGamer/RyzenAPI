-- Lua provided by RyzenAPI
-- Game: Castlevania Dominus Collection

-- MAIN APPLICATION
addappid(2369900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369901, 1, "e043f7821044b91504ba4cf8b9a6b474a717bc0c1eb891da95b5d5b3edd95969")
