-- Lua provided by RyzenAPI
-- Game: Apex Heroines -Night Princess 黑夜公主

-- MAIN APPLICATION
addappid(2742400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742400,0,"f4b5bfc07d919ee9c1ccc3019d6bc6503884aedfe8f4efc97897da4d78db518e")

