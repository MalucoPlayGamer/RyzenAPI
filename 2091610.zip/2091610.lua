-- Lua provided by RyzenAPI
-- Game: MIDIToKey

-- MAIN APPLICATION
addappid(2091610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091611, 1, "bb47a7ea2b46d60b214661a7876896222c9cb8f70f11143183e90db9a11afc7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
