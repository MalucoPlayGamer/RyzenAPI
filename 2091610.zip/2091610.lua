-- Lua provided by RyzenAPI
-- Game: 2091610

-- MAIN APPLICATION
addappid(2091610)
-- Game: addappid(2091610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091611, 1, "bb47a7ea2b46d60b214661a7876896222c9cb8f70f11143183e90db9a11afc7c")
