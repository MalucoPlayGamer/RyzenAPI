-- Lua provided by SkyAPI 
-- Game: 回门 Way Back Home 原声集
addappid(1539850)
addappid(1539851, 1, "e8fe1d63d15cd0a794d0b91697c297df4e3861315905bb42399275e87331edac")
