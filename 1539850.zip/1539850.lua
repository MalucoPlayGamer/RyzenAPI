-- Lua provided by RyzenAPI
-- Game: 回门 Way Back Home 原声集

-- MAIN APPLICATION
addappid(1539850)
-- Game: addappid(1539850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539851, 1, "e8fe1d63d15cd0a794d0b91697c297df4e3861315905bb42399275e87331edac")
