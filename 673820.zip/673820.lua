-- Lua provided by RyzenAPI 
-- Game: Master of ABC
addappid(673820)
addappid(673821, 1, "b4768837bcc900940a13c694f06b8177970ea9b847766ed02dcb0fd4916e12af")
