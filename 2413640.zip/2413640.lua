-- Lua provided by RyzenAPI 
-- Game: Countless Army
addappid(2413640)
addappid(2413641, 1, "13272ef1eea4acee00e712f6d1bb363766785f7ccf47b1aac67d0cc4e414a656")
