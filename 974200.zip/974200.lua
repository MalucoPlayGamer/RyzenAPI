-- Lua provided by SkyAPI 
-- Game: AppID 974200
addappid(974200)
addappid(974201, 1, "5a0115978040fba4d2837780be03a50f6e2f7f7b000663ecea5fdd345bac6d0c")
