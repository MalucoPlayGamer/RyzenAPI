-- Lua provided by RyzenAPI
-- Game: AppID 974200

-- MAIN APPLICATION
addappid(974200)

-- MAIN APP DEPOTS / PACKAGES
addappid(974201, 1, "5a0115978040fba4d2837780be03a50f6e2f7f7b000663ecea5fdd345bac6d0c")

