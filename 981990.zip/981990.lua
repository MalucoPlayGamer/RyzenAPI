-- Lua provided by RyzenAPI
-- Game: Don't Shoot Rabbit / 不要射中兔子

-- MAIN APPLICATION
addappid(981990)

-- MAIN APP DEPOTS / PACKAGES
addappid(981991, 1, "127a8144d218801652b74b0613c73a4f137426836b4bf66d85f84ce583eb0428")

