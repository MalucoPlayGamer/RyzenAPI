-- Lua provided by RyzenAPI
-- Game: Z.O.N.A Project X VR

-- MAIN APPLICATION
addappid(2142450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142451, 1, "ea78067971d1bf38d128300f3044e07505d61ba0ef1efb08d6267a02b6efc4b5")

