-- Lua provided by SkyAPI 
-- Game: AppID 2924630
addappid(2924630)
addappid(2924631, 1, "8cb4efa6886b5344c43b9245a3282e97a327a4a9b9a3e3798e5e5f8850e53830")
