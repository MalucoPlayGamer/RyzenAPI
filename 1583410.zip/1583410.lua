-- Lua provided by RyzenAPI 
-- Game: Hamster
addappid(1583410)
addappid(1583411, 1, "e5fec61f731338dfbadec53ce6928f138e5d35d554eeee0f94e7498ce2517eab")
