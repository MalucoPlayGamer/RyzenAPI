-- Lua provided by RyzenAPI
-- Game: addappid(1172510)

-- MAIN APPLICATION
addappid(1172510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172511, 1, "48d4e06b959a629f24f43a03fe46639ff66f00ebc074fef07b7762d10c75c3b2")
