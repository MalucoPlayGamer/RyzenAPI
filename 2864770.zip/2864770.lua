-- Lua provided by RyzenAPI
-- Game: BrokenLore: FOLLOW Demo

-- MAIN APPLICATION
addappid(2864770)
-- Game: addappid(2864770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864771, 1, "0d45e19d798d64ea35f1de178ab59745831ad0e796a41bf0fa4ee7607b3387cf")
