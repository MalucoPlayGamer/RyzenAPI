-- Lua provided by RyzenAPI
-- Game: Art of Solitaire

-- MAIN APPLICATION
addappid(3690460)

