-- Lua provided by RyzenAPI
-- Game: The Settlers 7: Paths to a Kingdom

-- MAIN APPLICATION
addappid(48120)
addappid(48124)
addappid(48127)
addappid(48128)
addappid(48131)
addappid(48132)
addappid(48136)
addappid(48137)
addappid(48138)
addappid(48140)

-- MAIN APP DEPOTS / PACKAGES
addappid(48121, 1, "1f113dc5ef6651210ad93b5353cde7faf8b3c32f028904e664d0b1c7ef439304")
addappid(48122, 1, "4fddbc8e9b448a7a17bc99a4221bf99755d4c65db5bfdf4552d02bfa7e56c090")
addappid(48123, 1, "1d1a529f80f2ff1df4f48920e34d71cfe944515cbf65cce9f233b53877f8c63c")
addappid(48125, 1, "73fbaefaaff112d9bb388e33308c9be8a900d4aa272e0dd6048f038c43f47b22")
addappid(48126, 1, "591a1fcb95869d31717d4ea8581175a6b6e64bb65502118b4a49a6fa19a8103c")
addappid(48133, 1, "b14142af91bed16be5c55c0b1550b36e80bd2732abf6e68f08f4d41e10836b57")
addappid(48134, 1, "8907725d9ca36482730df9fe6b81343a6a82bd48284156618d56d045c86cc7ef")
addappid(48135, 1, "2b5ffa490f6c9c4b41fcc5430affd48bb945fe0e501502a0d0bd786fa1ebd641")

