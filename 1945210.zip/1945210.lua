-- Lua provided by RyzenAPI
-- Game: 1945210

-- MAIN APPLICATION
addappid(1945210)
-- Game: addappid(1945210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945210,0,"e09aa97defb1e1266c3c7843f3321f5778bdd78dff8d727bba59618130f966a4")
