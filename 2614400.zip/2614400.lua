-- Lua provided by RyzenAPI
-- Game: addappid(2614400)

-- MAIN APPLICATION
addappid(2614400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614401, 1, "518e72c0a4f5c54f8fcc023f62fba631065fc60301c4e144469237ad212aa565")
