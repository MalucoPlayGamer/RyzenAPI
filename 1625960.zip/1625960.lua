-- Lua provided by RyzenAPI
-- Game: Loverowind

-- MAIN APPLICATION
addappid(1625960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625961, 1, "064155b9452c7fb9569076d1579267ad319a9315dff59cec0d2eebf52668a3e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
