-- Lua provided by RyzenAPI 
-- Game: Loverowind
addappid(1625960)
addappid(1625961, 1, "064155b9452c7fb9569076d1579267ad319a9315dff59cec0d2eebf52668a3e6")
