-- Lua provided by RyzenAPI
-- Game: Pleasure Kingdom

-- MAIN APPLICATION
addappid(1882700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882701, 1, "4f8d32c32074ed5f161399ef2d53a762490d012df19e8fc630103a53f6897fcc")

