-- Lua provided by SkyAPI 
-- Game: Halo 2 Mod Tools - MCC
addappid(1613450)
addappid(1613451, 1, "3d957c88f27a9645c06c3647c964275e0638da0eacd973b375a19292d8d600cf")
