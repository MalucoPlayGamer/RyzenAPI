-- Lua provided by RyzenAPI
-- Game: Stick Infinite Kingdom

-- MAIN APPLICATION
addappid(2997460)
-- Game: addappid(2997460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997461, 1, "8dde465fd7bcbd6cce07336e0c991736f29847ea03f0969d517ed98880a3a69b")
