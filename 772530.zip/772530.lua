-- Lua provided by RyzenAPI
-- Game: 772530

-- MAIN APPLICATION
addappid(772530)
-- Game: addappid(772530)

-- MAIN APP DEPOTS / PACKAGES
addappid(772531, 1, "0b774dbca1bc9c135c176affd65e44768b8b2578a2f4a5f3fd04645b89a37be4")
