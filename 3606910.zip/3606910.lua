-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Isekai Uncle Reversal 2

-- MAIN APPLICATION
addappid(3606910)
-- Game: addappid(3606910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606911, 1, "e66b026209b27da56ad74fed070a3c045401d301ae887052006926c7318a9871")
