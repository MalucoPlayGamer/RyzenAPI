-- Lua provided by RyzenAPI
-- Game: addappid(1846020)

-- MAIN APPLICATION
addappid(1846020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846021, 1, "94ff746d1c5a5957b99be853b1f813268d38fb41f41cf452827335cab2eb41bc")
