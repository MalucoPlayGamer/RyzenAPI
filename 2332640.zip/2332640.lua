-- Lua provided by RyzenAPI 
-- Game: 神灵石之劫 Tales of Spark Demo
addappid(2332640)
addappid(2332641, 1, "0e034b0790b8655cfe51dc1bcd2a15b4077a86b6587e6c81e9e1f63a3038563a")
