-- Lua provided by SkyAPI 
-- Game: Brood
addappid(1039080)
addappid(1039081, 1, "56556054ce05408a1b8d69e53bdb1755e2316f8afb4ffc18d9d7afe39a28816f")
