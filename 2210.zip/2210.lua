-- Lua provided by RyzenAPI
-- Game: Quake 4

-- MAIN APPLICATION
addappid(2210)
-- Game: addappid(2210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211, 1, "c0ea2de8b8c964e7b5fb07ed0089d53011ab654fc5141ac2f64ffe6f752411bf")
addappid(2212, 1, "e9b4982b396efbd138c393f781e0085c7e28c0a7a4ac1650d2d2ad239a7c1f6e")
addappid(2213, 1, "a1d1ebe63154436f66a516711db317866ee003268d0129f3c46305d275292647")
addappid(2214, 1, "8ebd07aabf98052072d61ecb94a83cd295baac00fe26a1d1bda426912030594f")
addappid(2215, 1, "8bb7d4fe56aeaa5de6e0a97016385d050eb9cb9f20e7c0ae8d4e3460eabad147")
addappid(2216, 1, "025be308b1cab3190f06032f5178a9d0e184abd2fe14480b47dc45922e285ebe")
