-- Lua provided by RyzenAPI
-- Game: Bonds Of Ecstasy

-- MAIN APPLICATION
addappid(3300620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300621, 1, "43a6cfb269492201bb41dfa008bd06a9eec32e3e1caeb9c1854affce14a01498")

