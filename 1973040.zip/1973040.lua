-- Lua provided by RyzenAPI
-- Game: Hunt for Junk

-- MAIN APPLICATION
addappid(1973040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973041, 1, "e287c699f181ccf052fb5d06e84e076545762f97f6eb069eb76899b824bf4ab7")
