-- Lua provided by RyzenAPI
-- Game: Terrifier: The ARTcade Game

-- MAIN APPLICATION
addappid(3130400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130401, 1, "887b2d85ce512027dce01b6f326df10bf5cf24142226e743fe6d186c8b4011ab")

