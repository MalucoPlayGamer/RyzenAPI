-- Lua provided by RyzenAPI
-- Game: addappid(1662140)

-- MAIN APPLICATION
addappid(1662140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662141, 1, "87c4db28bf6c1759ac7a4fda04d313aa463a09e6ca61f8443c6b91968ab4dd6b")
