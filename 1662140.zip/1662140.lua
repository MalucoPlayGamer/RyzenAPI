-- Lua provided by SkyAPI 
-- Game: Real estate tycoon
addappid(1662140)
addappid(1662141, 1, "87c4db28bf6c1759ac7a4fda04d313aa463a09e6ca61f8443c6b91968ab4dd6b")
