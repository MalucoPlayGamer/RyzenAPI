-- Lua provided by RyzenAPI
-- Game: Wordeous

-- MAIN APPLICATION
addappid(1441430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441431, 1, "a2d7dfc6477920d8041cd3835915a54d090cc266c54fcdb2b835c3d5124a4598")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1476070)
addappid(1501680)
addappid(1501681)
addappid(1535730)
addappid(1600860)
