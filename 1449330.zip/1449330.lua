-- Lua provided by RyzenAPI
-- Game: DRINK BAR MAID -REGRESSION-

-- MAIN APPLICATION
addappid(1449330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449331, 1, "ebb59ab7d79dda6561bd2f43ed2e93d2e2694c3df77bcce9dd1e1fb253274fe0")

