-- Lua provided by RyzenAPI
-- Game: 1581950

-- MAIN APPLICATION
addappid(1581950)
-- Game: addappid(1581950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581951, 1, "fb072d94e6e9d1ebd0c620b9be6402e6dde5e257d83777b11087502acc53a730")
