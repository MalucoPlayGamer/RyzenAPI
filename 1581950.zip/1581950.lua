-- Lua provided by RyzenAPI 
-- Game: Buriedbornes2 - Dungeon RPG -
addappid(1581950)
addappid(1581951, 1, "fb072d94e6e9d1ebd0c620b9be6402e6dde5e257d83777b11087502acc53a730")
