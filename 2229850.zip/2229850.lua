-- Lua provided by RyzenAPI
-- Game: Command & Conquer Red Alert™ 2 and Yuri’s Revenge™

-- MAIN APPLICATION
addappid(2229850)
-- Game: addappid(2229850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229851, 1, "2cb1c174f12c44bec71bc796c767aef1b47a5a476b79292a7bb41af3b03cd511")
addappid(2229852, 1, "ba66f3a0933b3cfd878d8340e59dbaec8359a68b0a525207879f5fe6161a5340")
addappid(2229853, 1, "2b1ab0ac6f851ca3821881bcf715dd376c8625dc5514c6f0f7b1abd3cd3a7eef")
addappid(2229854, 1, "961ba56200f2d06dc6abaf473928366f54ed4aaf2ed7abf48d93c19a2857d6af")
addappid(2229855, 1, "96abb4a7dc16cf7f80ab5df7f89cfa8f5e3fab2255b77e6f54b55236fde7e125")
addappid(2229856, 1, "e9d8e9953162e17f2a7f6e780c6cfaa05f80099046b39782568763dac32543c1")
