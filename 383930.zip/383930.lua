-- Lua provided by RyzenAPI
-- Game: Doorways: Holy Mountains of Flesh

-- MAIN APPLICATION
addappid(383930)
-- Game: addappid(383930)

-- MAIN APP DEPOTS / PACKAGES
addappid(383931, 1, "bba5ec346055a573b6e2aa71fc4af50fc361303e552b3ba2608e85f5ab28bf3b")
addappid(383932, 1, "35725582c35eb7ac0c348efd89d7ac59e212e8314ed3d460c8ceb1aaebfc00f5")
addappid(383933, 1, "2e0dde9e7f8cee3738717402d819152ba2656178be3250d75cda49dc13f6bbf7")
