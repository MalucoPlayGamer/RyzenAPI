-- Lua provided by SkyAPI 
-- Game: Rusty Dudes Demo
addappid(3233850)
addappid(3233851, 1, "e0a7ffb9ba3b7ea672a7269016aeea750df28d43f64c7acdfa3106948f673f2f")
