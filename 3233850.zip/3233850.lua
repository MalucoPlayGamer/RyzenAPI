-- Lua provided by RyzenAPI
-- Game: addappid(3233850)

-- MAIN APPLICATION
addappid(3233850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233851, 1, "e0a7ffb9ba3b7ea672a7269016aeea750df28d43f64c7acdfa3106948f673f2f")
