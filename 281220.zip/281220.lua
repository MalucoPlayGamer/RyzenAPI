-- Lua provided by SkyAPI 
-- Game: BloodRayne Betrayal (Legacy)
addappid(281220)
addappid(281221, 1, "bd050576d6da0bbb4290ec5bcee5c40938ef80a59043795ba0d64fad9b8454fe")
