-- Lua provided by RyzenAPI
-- Game: AppID 1154790

-- MAIN APPLICATION
addappid(1154790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154791, 1, "e40934640b1d1f7307070e36d011f2cf6f667e2747c4b06307857eee1677beab")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1341320)
