-- Lua provided by RyzenAPI
-- Game: Bosca Ceoil: The Blue Album

-- MAIN APPLICATION
addappid(3570850)
addappid(3617610)
-- Game: addappid(3570850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3570851, 1, "7b7c05ccc30672e672cd9b22daff4ca0fde0e89f850123ef652e93fc14eaaeac")
addappid(3570852, 1, "130a40a611dceed4aca1b52d12a2563aea8fe94bc0dcc8c495ca780e59703e3d")
addappid(3570853, 1, "28a19fee9cd9365c1118b67bce09a6483b98457fa694f9251dfe7e6b5d320bbb")
addappid(3570854, 1, "dfe38cc0f86128bef52e079aca944be11d37c976c06611378c4e88d451e2e4cb")
