-- Lua provided by RyzenAPI
-- Game: 2808420

-- MAIN APPLICATION
addappid(2808420)
-- Game: addappid(2808420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808421, 1, "55a55c77ef1b81abbc62175ec0df4537e22c15e3c62e3a08b28d3af2a0d7ef3d")
addappid(2808422, 1, "4813bb0d4373c67ab9e087a9fc69f32ca805445e6fbef13bd6220d20a7505bff")
