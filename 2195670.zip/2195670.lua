-- Lua provided by RyzenAPI
-- Game: Epic Princess

-- MAIN APPLICATION
addappid(2195670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195671, 1, "88a0194b28a76dda9954122bcdc7cdde125c4bba405712f2ecc54036c7f3538e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
