-- Lua provided by RyzenAPI
-- Game: Epic Princess

-- MAIN APPLICATION
addappid(2195670)
-- Game: addappid(2195670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195671, 1, "88a0194b28a76dda9954122bcdc7cdde125c4bba405712f2ecc54036c7f3538e")
