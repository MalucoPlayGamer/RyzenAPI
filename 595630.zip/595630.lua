-- Lua provided by RyzenAPI
-- Game: Game: Neon8

-- MAIN APPLICATION
addappid(595630)
-- Game: addappid(595630)

-- MAIN APP DEPOTS / PACKAGES
addappid(595631, 1, "c941e2d7c537fb6da8fb14f5d21b7800fe85c717495ea637f9bde7026a9dae12")
