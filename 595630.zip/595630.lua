-- Lua provided by SkyAPI 
-- Game: Neon8
addappid(595630)
addappid(595631, 1, "c941e2d7c537fb6da8fb14f5d21b7800fe85c717495ea637f9bde7026a9dae12")
