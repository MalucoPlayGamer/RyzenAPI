-- Lua provided by RyzenAPI
-- Game: 1326000

-- MAIN APPLICATION
addappid(1326000)
-- Game: addappid(1326000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326001, 1, "e422b780a30fc05ea85a2b5640a66415763167d1de278912fab6acceb87b6f55")
