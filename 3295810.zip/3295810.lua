-- Lua provided by RyzenAPI
-- Game: Remote Reaper: FPV Combat Drone Simulator

-- MAIN APPLICATION
addappid(3295810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295811, 1, "4a8df46aa3941b6d0ec45d942dd64737d7285738346853b18cb8da07266f0358")

