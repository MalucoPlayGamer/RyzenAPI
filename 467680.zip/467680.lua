-- Lua provided by RyzenAPI
-- Game: 467680

-- MAIN APPLICATION
addappid(467680)
addappid(589140)
addappid(589141)
addappid(589142)
addappid(741030)
-- Game: addappid(467680)

-- MAIN APP DEPOTS / PACKAGES
addappid(467681, 1, "df041decac3a4e89a45e8098653c0cfdec6a6e38c7c3ed6d3d2c8f618a63b9f5")
