-- Lua provided by RyzenAPI 
-- Game: Real Drift Multiplayer 2
addappid(2588230)
addappid(2588231, 1, "fa94870660ed0e03b912ae7655117884741de0919ff1ed2dd4f1080f30ee849c")
