-- Lua provided by RyzenAPI
-- Game: The Breeding: The Fog

-- MAIN APPLICATION
addappid(744440)

-- MAIN APP DEPOTS / PACKAGES
addappid(744441, 1, "c447885a03032e6df4a24b33d436ed33065c90b6a388dfdfd7c6f76e9b6793c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
