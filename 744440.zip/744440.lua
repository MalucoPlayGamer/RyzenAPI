-- Lua provided by RyzenAPI
-- Game: The Breeding: The Fog

-- MAIN APPLICATION
addappid(744440)
-- Game: addappid(744440)

-- MAIN APP DEPOTS / PACKAGES
addappid(744441, 1, "c447885a03032e6df4a24b33d436ed33065c90b6a388dfdfd7c6f76e9b6793c4")
