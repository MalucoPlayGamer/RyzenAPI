-- Lua provided by RyzenAPI
-- Game: Base Craft: Desolate Survival

-- MAIN APPLICATION
addappid(1923920)
-- Game: addappid(1923920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923921, 1, "e07972f41baabe16a54113ea7f24ad78f24cae5750692273ed78914e86262801")
