-- Lua provided by RyzenAPI
-- Game: Base Craft: Desolate Survival

-- MAIN APPLICATION
addappid(1923920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923921, 1, "e07972f41baabe16a54113ea7f24ad78f24cae5750692273ed78914e86262801")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
