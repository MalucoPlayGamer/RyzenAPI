-- Lua provided by RyzenAPI
-- Game: 3244390

-- MAIN APPLICATION
addappid(3244390)
-- Game: addappid(3244390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244391, 1, "2cb7860ff07dd0f72d4f3a106120319dce5edaeee09efa894dba64da5a674b1b")
