-- Lua provided by RyzenAPI
-- Game: Battle Tanks: World War II

-- MAIN APPLICATION
addappid(782670)

-- MAIN APP DEPOTS / PACKAGES
addappid(782671, 1, "3595f660446b54a160102bc6a7d41811564b75ab690df1de231d1977a9638d97")
addappid(782672, 1, "8e5aa3b7f3ebae083b958d731df32bb8eb7bbd6bc950e7cbb05bfb3e2ad92767")
addappid(782673, 1, "174897a7cc001dcc107364929c0bc7d30b4ddc1656126149f8a5baacc5326174")

