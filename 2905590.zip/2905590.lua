-- Lua provided by RyzenAPI
-- Game: AppID 2905590

-- MAIN APPLICATION
addappid(2905590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905591, 1, "81a667558c35d2e0458efd13f1874c039a7e6cff197b20d204fe1fdffc13fdf1")
