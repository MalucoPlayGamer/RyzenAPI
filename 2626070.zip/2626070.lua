-- Lua provided by RyzenAPI
-- Game: Fire Fly ( 萤火 )

-- MAIN APPLICATION
addappid(2626070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2626071,0,"ca0a84d2363194f987113e9e808fefdae17a30d8942a08393a4e6b24940321ea")

