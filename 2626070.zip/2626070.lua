-- Lua provided by RyzenAPI
-- Game: Fire Fly ( 萤火 )

-- MAIN APPLICATION
addappid(2626070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626071,0,"ca0a84d2363194f987113e9e808fefdae17a30d8942a08393a4e6b24940321ea")

