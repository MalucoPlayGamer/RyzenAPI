-- Lua provided by RyzenAPI 
-- Game: Frog Climbers
addappid(485120)
addappid(485121, 1, "6181439df4e8ae8acce67d8788353064daf75d3d4978c82d90147d13a5afdcc1")
