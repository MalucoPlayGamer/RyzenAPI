-- Lua provided by RyzenAPI
-- Game: Frog Climbers

-- MAIN APPLICATION
addappid(485120)

-- MAIN APP DEPOTS / PACKAGES
addappid(485121, 1, "6181439df4e8ae8acce67d8788353064daf75d3d4978c82d90147d13a5afdcc1")
