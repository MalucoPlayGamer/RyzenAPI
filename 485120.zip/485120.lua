-- Lua provided by RyzenAPI
-- Game: Frog Climbers

-- MAIN APPLICATION
addappid(485120)

-- MAIN APP DEPOTS / PACKAGES
addappid(485121, 1, "6181439df4e8ae8acce67d8788353064daf75d3d4978c82d90147d13a5afdcc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
