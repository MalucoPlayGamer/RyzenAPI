-- Lua provided by RyzenAPI
-- Game: AppID 1704060

-- MAIN APPLICATION
addappid(1704060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704061, 1, "557e69bd1da948ed030c42f296fc23bdef55f9562abead3c7f1f22b1cc9fb94d")

