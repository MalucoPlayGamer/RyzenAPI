-- Lua provided by RyzenAPI
-- Game: The Spirit of the Samurai

-- MAIN APPLICATION
addappid(1507120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507121, 1, "02425c220df8a52475ce5a7368882a4cd1e42d4d9771a30300f50bc3f464e2dd")

