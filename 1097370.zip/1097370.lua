-- Lua provided by RyzenAPI 
-- Game: AppID 1097370
addappid(1097370)
addappid(1097371, 1, "ebbd318c18cf0cb59b16e9a854d0bd962807978682eb9a865ddb8ae9c87321b7")
