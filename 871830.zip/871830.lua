-- Lua provided by RyzenAPI
-- Game: Game: AppID 871830

-- MAIN APPLICATION
addappid(871830)
-- Game: addappid(871830)

-- MAIN APP DEPOTS / PACKAGES
addappid(871831, 1, "43b15e3e5e8bddefe1de134f7d9b2ecee875741ca4bf45819fd5f887586a3511")
