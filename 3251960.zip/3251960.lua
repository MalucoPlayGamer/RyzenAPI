-- Lua provided by SkyAPI 
-- Game: AppID 3251960
addappid(3251960)
addappid(3251961, 1, "15b37c3f5a949348d4462dff8667c84164460e739d1147f3c1102f657132e8ca")
