-- Lua provided by RyzenAPI
-- Game: Scavland

-- MAIN APPLICATION
addappid(3373500) -- Scavland

-- MAIN APP DEPOTS / PACKAGES
addappid(3373501, 1, "8488688d3e01807890f7561cb55e3b254ceabf782ac4b747ef9ca4511bb499a4") -- Depot 3373501
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
