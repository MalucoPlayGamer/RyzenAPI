-- Lua provided by RyzenAPI
-- Game: HardPunch: Sex Plague

-- MAIN APPLICATION
addappid(1434900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434901, 1, "fb9de5d354cca276768d6e7eab5536227b9cacdee36398d027549d32059d7069")
