-- Lua provided by RyzenAPI
-- Game: VR-NISSAGE 3 - John Wentz Art Exhibition

-- MAIN APPLICATION
addappid(1322740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1322741, 1, "e218d5366e85d7606cd77e3d723dcee83e8d4100fe4c76dbe7fd8e2c409fe1fb")

