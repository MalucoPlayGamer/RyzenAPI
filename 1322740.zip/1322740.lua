-- Lua provided by RyzenAPI
-- Game: Game: VR-NISSAGE 3 - John Wentz Art Exhibition

-- MAIN APPLICATION
addappid(1322740)
-- Game: addappid(1322740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322741, 1, "e218d5366e85d7606cd77e3d723dcee83e8d4100fe4c76dbe7fd8e2c409fe1fb")
