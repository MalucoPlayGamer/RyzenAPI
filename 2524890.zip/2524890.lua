-- Lua provided by RyzenAPI
-- Game: Pixel Gun 3D: PC Edition

-- MAIN APPLICATION
addappid(2524890)
addappid(2856270)
addappid(2869430)
addappid(2869440)
addappid(2869450)
addappid(2869460)
addappid(3052680)
addappid(3052690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524891, 1, "9c8e3b0008ff9820676f003335e6b0ddbb91575deb83d2b0a7d2ca2951fb4f19")
addappid(2524892, 1, "44f34786ccd312373d404f29d6eb78dde856c3b0603e3cae2d75cfa659dab73e")

