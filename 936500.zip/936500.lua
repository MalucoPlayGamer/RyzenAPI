-- Lua provided by RyzenAPI
-- Game: Game: Transport INC

-- MAIN APPLICATION
addappid(936500)
-- Game: addappid(936500)

-- MAIN APP DEPOTS / PACKAGES
addappid(936501, 1, "22c96c584a469b17af29671d366fd2526c965c1cf5d4251c33fc5f8472b59945")
addappid(936502, 1, "466b912510a00635afd7b6bafeb05c4c6543e69b637b0d18fd480a3e00fcae17")
