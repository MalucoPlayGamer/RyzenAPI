-- Lua provided by RyzenAPI
-- Game: Game: AppID 1129120

-- MAIN APPLICATION
addappid(1129120)
-- Game: addappid(1129120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129121, 1, "f8537cc9602cdca3a88e87e55d95b97ad6a6d38a03955ca1dfbc2a55d5e4b587")
