-- Lua provided by RyzenAPI
-- Game: 264220

-- MAIN APPLICATION
addappid(264220)
-- Game: addappid(264220)

-- MAIN APP DEPOTS / PACKAGES
addappid(264221, 1, "9c7108e02f1d1a6b67a52397c8dabb04842294cbb75b607967953db805c19d8b")
