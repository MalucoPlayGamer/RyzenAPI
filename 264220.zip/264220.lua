-- Lua provided by SkyAPI 
-- Game: Mr. Bree+
addappid(264220)
addappid(264221, 1, "9c7108e02f1d1a6b67a52397c8dabb04842294cbb75b607967953db805c19d8b")
