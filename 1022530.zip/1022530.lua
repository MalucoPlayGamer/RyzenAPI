-- Lua provided by RyzenAPI
-- Game: SUBARACITY

-- MAIN APPLICATION
addappid(1022530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022531, 1, "e0aaa2fee532ab62b2b3c5ffe3429c2758ad4cd104b024497affeda16c9a780c")

