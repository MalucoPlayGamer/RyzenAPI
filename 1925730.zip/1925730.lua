-- Lua provided by RyzenAPI
-- Game: Block Breaker

-- MAIN APPLICATION
addappid(1925730)
-- Game: addappid(1925730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925731, 1, "13b43152f067248e7cee4199497676a3416eabf261abba5cb51cfb6837207507")
