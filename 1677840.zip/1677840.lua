-- Lua provided by RyzenAPI
-- Game: Color Your World

-- MAIN APPLICATION
addappid(1677840)
-- Game: addappid(1677840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677841, 1, "a874d21caa476b626ed89cb8fa4677ff824b5d978648417afd0de7b5eb9c0b18")
