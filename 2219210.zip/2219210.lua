-- Lua provided by RyzenAPI
-- Game: 贪婪大地 Playtest

-- MAIN APPLICATION
addappid(2219210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219211, 1, "015c681ee982bd2eab3d5e3d61a2e98ae73c7fa584583a5e19724d4fb5e77c12")
