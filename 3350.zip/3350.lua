-- Lua provided by RyzenAPI
-- Game: Bejeweled Deluxe

-- MAIN APPLICATION
addappid(3350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351, 1, "a1ed3a81378167ff85df65b61643df1615d4b8368fc5a2b6b202357740e8e6ed")
