-- Lua provided by RyzenAPI
-- Game: Lofi Cozy Room

-- MAIN APPLICATION
addappid(4621450) -- Lofi Cozy Room

-- MAIN APP DEPOTS / PACKAGES
addappid(4621451, 1, "52fce50080ac505205ffaacd1b2557e29b59ea41d675ae97d9aebc0a09e5f32a") -- Depot 4621451

