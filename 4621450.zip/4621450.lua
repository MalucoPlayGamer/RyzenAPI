-- 4621450's Lua and Manifest Created by Hubcap Manifest
-- Lofi Cozy Room
-- Created: August 01, 2026 at 00:01:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4621450) -- Lofi Cozy Room
-- MAIN APP DEPOTS
addappid(4621451, 1, "52fce50080ac505205ffaacd1b2557e29b59ea41d675ae97d9aebc0a09e5f32a") -- Depot 4621451
setManifestid(4621451, "5744047859870694153", 1630424519)