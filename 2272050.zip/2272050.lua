-- Lua provided by RyzenAPI
-- Game: Fairy Biography3 : Obsession

-- MAIN APPLICATION
addappid(2272050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272051, 1, "61cf755d071062e0674fe1f22593b626b19086b82a3a8a9297814f2e72af9ab1")
addappid(2277570, 0, "b438f7a0ca3c3edee6c7ce2985545b183183b5e48276393927f7d90c51b754f8")

