-- Lua provided by RyzenAPI 
-- Game: Puzzler World 2
addappid(200130)
addappid(200131, 1, "95693f0fa380ed9d701ccef842ca244b4c33d1636dd00e0d9f72212a4cf5b8bd")
