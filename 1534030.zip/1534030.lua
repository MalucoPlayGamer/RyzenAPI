-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1534030)
-- Game: addappid(1534030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534030,0,"21da67a301a8a3db2779984222db95301c2ecf7b22bafa0528edac3a2f93e4e0")
