-- Lua provided by RyzenAPI
-- Game: Game: Past Fate

-- MAIN APPLICATION
addappid(1028510)
-- Game: addappid(1028510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028511, 1, "58a9c338e0c75397e64530180a967a536d1a8de929efb507b716a525a291e41f")
