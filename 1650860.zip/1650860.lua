-- Lua provided by RyzenAPI
-- Game: Chambers of Devious Design

-- MAIN APPLICATION
addappid(1650860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650861, 1, "b14b41d55d0ec55528e5296ea4d7880670f0d58dcdbdbfb160e76d462ff2efcd")
