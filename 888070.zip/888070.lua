-- Lua provided by RyzenAPI
-- Game: Game: Railroad Tracks

-- MAIN APPLICATION
addappid(888070)
-- Game: addappid(888070)

-- MAIN APP DEPOTS / PACKAGES
addappid(888071, 1, "833474235b5135d4a5d70de4a8c60170b8fa3e79583ad462c40b9065338ded6e")
