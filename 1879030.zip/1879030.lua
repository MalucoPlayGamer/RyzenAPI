-- Lua provided by RyzenAPI
-- Game: Return the Backrooms

-- MAIN APPLICATION
addappid(1879030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879031, 1, "be46c6124a28512789c8171bbf8bb00b5cc3112194120b41b0516f6da5fd5ae0")
