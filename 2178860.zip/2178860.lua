-- Lua provided by RyzenAPI
-- Game: Game: Building our Futature

-- MAIN APPLICATION
addappid(2178860)
-- Game: addappid(2178860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178861, 1, "01044cb1ce915e8fd1a8eb361dc6a7f8f2d8513ea703faaa5a5bfeafd56984d4")
