-- Lua provided by RyzenAPI
-- Game: AppID 1820240

-- MAIN APPLICATION
addappid(1820240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820241, 1, "890e41ca68c97de2697e4e7abd92d322704276d92acc4a06e12d1aa9ee7f9dac")
