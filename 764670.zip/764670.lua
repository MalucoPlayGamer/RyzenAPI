-- Lua provided by RyzenAPI
-- Game: Sea Dogs

-- MAIN APPLICATION
addappid(764670)

-- MAIN APP DEPOTS / PACKAGES
addappid(764671,0,"649f5e41acf7ca4e6997f876be8172f91c498176aa92b198df1d4baf63739980")
addappid(764672,0,"9acd0316d6ff4f01e72b0f397dadb3707416dce8a101ec870a4f1189d8435b60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
