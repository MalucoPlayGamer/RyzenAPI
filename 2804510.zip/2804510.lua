-- Lua provided by RyzenAPI
-- Game: addappid(2804510)

-- MAIN APPLICATION
addappid(2804510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804511, 1, "56f96df0083f4a5df472f862a7d457b0e2a6b295e0c128184caf71f427eb4303")
