-- Lua provided by RyzenAPI
-- Game: Dead Event

-- MAIN APPLICATION
addappid(1333490)
-- Game: addappid(1333490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333491, 1, "797276079b0b09de2a45378f66e3437e22c25bda26496034da39159c1f0c2475")
