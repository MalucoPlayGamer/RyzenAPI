-- Lua provided by RyzenAPI
-- Game: KingComing

-- MAIN APPLICATION
addappid(3641850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3641851, 1, "fceaa54a379a67325513c97ea383640a80a7e1b3bffa9e20e4e57a98597bf2ac")
