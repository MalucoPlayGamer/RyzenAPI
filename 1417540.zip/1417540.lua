-- Lua provided by RyzenAPI
-- Game: Gravity Block

-- MAIN APPLICATION
addappid(1417540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417541, 1, "14e7880e26749586e9f47f11a13be1d326a1832ee7bd3ec0743ad15a85397fe4")
