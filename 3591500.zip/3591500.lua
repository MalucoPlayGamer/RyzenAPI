-- Lua provided by RyzenAPI
-- Game: No-good Streamer Mirai-chan! (Now accepting lewd comments)

-- MAIN APPLICATION
addappid(3591500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3591501, 1, "197083501fa52b6fdd95c22e6d4ab4e0764708512d0724c4ceaa62731469704d")
addappid(3591502, 1, "5681aa3b3e2a9170556439292585bf05656bf1a95c4158e5877f456dc3b1932f")
addappid(3591503, 1, "0940ea43809c1aa64707740bd8512973fb91d1d96b87760b1aa71c0e764d7b73")
