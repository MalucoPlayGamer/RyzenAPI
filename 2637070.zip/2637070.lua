-- Lua provided by RyzenAPI
-- Game: addappid(2637070)

-- MAIN APPLICATION
addappid(2637070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637071, 1, "0f6991cf277e81d9f71b651e4e56c3a98f9b61391fac3bd276845bbfe09cf741")
