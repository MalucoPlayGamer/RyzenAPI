-- Lua provided by RyzenAPI
-- Game: Crawling Lab

-- MAIN APPLICATION
addappid(2637070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637071, 1, "0f6991cf277e81d9f71b651e4e56c3a98f9b61391fac3bd276845bbfe09cf741")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
