-- Lua provided by RyzenAPI
-- Game: addappid(1851680)

-- MAIN APPLICATION
addappid(1851680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851681, 1, "2564b4fd7f4486ae43a70f9eaa38417553e40342ccb11d947f12a542cbb11a51")
