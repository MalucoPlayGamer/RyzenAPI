-- Lua provided by RyzenAPI
-- Game: Game: Ghost Janitors Demo

-- MAIN APPLICATION
addappid(2880880)
-- Game: addappid(2880880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880881, 1, "223674a9f9f7d2d883e430eaaf3a03438ffcf6c22088921c8b82083b54e79368")
