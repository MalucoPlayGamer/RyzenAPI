-- Lua provided by RyzenAPI
-- Game: Backrooms: The Incident

-- MAIN APPLICATION
addappid(4720830) -- Backrooms: The Incident

-- MAIN APP DEPOTS / PACKAGES
addappid(4720831, 1, "15eb3f73ebbf798f5c5f2e1400cc0aa3dd4af2c30cdf61eb1be849b8583a0912") -- Depot 4720831

