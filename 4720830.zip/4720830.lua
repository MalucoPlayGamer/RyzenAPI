-- 4720830's Lua and Manifest Created by Hubcap Manifest
-- Backrooms: The Incident
-- Created: August 12, 2026 at 22:56:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4720830) -- Backrooms: The Incident
-- MAIN APP DEPOTS
addappid(4720831, 1, "15eb3f73ebbf798f5c5f2e1400cc0aa3dd4af2c30cdf61eb1be849b8583a0912") -- Depot 4720831
setManifestid(4720831, "6976017308014331372", 3100059513)