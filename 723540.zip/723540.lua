-- Lua provided by RyzenAPI
-- Game: 魔光

-- MAIN APPLICATION
addappid(723540)

-- MAIN APP DEPOTS / PACKAGES
addappid(723541, 1, "ac5af733c629569b507f0860990b6d57ebe87dd9bc53e240d260a0821ab18edd")

