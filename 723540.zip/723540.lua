-- Lua provided by RyzenAPI
-- Game: 魔光

-- MAIN APPLICATION
addappid(723540)

-- MAIN APP DEPOTS / PACKAGES
addappid(723541, 1, "ac5af733c629569b507f0860990b6d57ebe87dd9bc53e240d260a0821ab18edd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
