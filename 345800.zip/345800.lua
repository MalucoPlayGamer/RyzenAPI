-- Lua provided by RyzenAPI
-- Game: Game: AppID 345800

-- MAIN APPLICATION
addappid(345800)
-- Game: addappid(345800)

-- MAIN APP DEPOTS / PACKAGES
addappid(345801, 1, "0465a0167dbb5eaa48e0ba784df7c02d3ffccf8f9514f4c5798dae1988ede93a")
