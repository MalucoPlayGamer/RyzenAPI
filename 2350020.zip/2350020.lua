-- Lua provided by RyzenAPI
-- Game: Start Over

-- MAIN APPLICATION
addappid(2350020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350021, 1, "179ddff63691fe5ea7d4edecb2212eb273d67f773d3e33c9e84fdeed3bd2157a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
