-- Lua provided by RyzenAPI 
-- Game: Start Over
addappid(2350020)
addappid(2350021, 1, "179ddff63691fe5ea7d4edecb2212eb273d67f773d3e33c9e84fdeed3bd2157a")
