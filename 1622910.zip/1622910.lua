-- Lua provided by RyzenAPI
-- Game: addappid(1622910)

-- MAIN APPLICATION
addappid(1622910)
addappid(3465690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622911, 1, "b826831ce8370fa43a4d194c301e6617bb1f1b05648b374a4a8896a6556dfbb2")
