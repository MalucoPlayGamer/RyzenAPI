-- Lua provided by RyzenAPI
-- Game: Shashingo: Learn Japanese with Photography

-- MAIN APPLICATION
addappid(1632490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632491, 1, "f67f17999240ddd63123856692f5911adb7ba0e5736260647bd33a52435d6ed3")
addappid(2392860, 0, "5acb0af525b78f8a7fdfa63d36cfa64dcb2c2b712572f50a5b85a4820906d12a")

