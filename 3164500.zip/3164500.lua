-- Lua provided by RyzenAPI
-- Game: Schedule I

-- MAIN APPLICATION
addappid(3164500)
-- Game: addappid(3164500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164501, 1, "81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4")
