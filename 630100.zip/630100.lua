-- Lua provided by RyzenAPI
-- Game: 630100

-- MAIN APPLICATION
addappid(630100)
-- Game: addappid(630100)

-- MAIN APP DEPOTS / PACKAGES
addappid(630101, 1, "b149dc704f8e92fe1a91e0d2199e23d12e4dd116e7007ec6fa4747f05dd45c25")
