-- Lua provided by RyzenAPI
-- Game: AppID 741450

-- MAIN APPLICATION
addappid(741450)

-- MAIN APP DEPOTS / PACKAGES
addappid(741451, 1, "b8336e1dbc9c9fbbabf49172c9fb30c23e4fbacb91773bc0107d875831e5b240")
