-- Lua provided by RyzenAPI
-- Game: Nightfall

-- MAIN APPLICATION
addappid(1458420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458421, 1, "4e13853763dab7f98e0d3ac67af5e0590bf44ccb7e7b804b8c9afe451146eaa2")
