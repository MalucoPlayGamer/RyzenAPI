-- Lua provided by RyzenAPI
-- Game: Carnivore Land

-- MAIN APPLICATION
addappid(397860)
-- Game: addappid(397860)

-- MAIN APP DEPOTS / PACKAGES
addappid(397861, 1, "e4ebf2b193b2ce8d08a847c12d22bc156e81024352f1e471973b5d51c39f058d")
