-- Lua provided by RyzenAPI
-- Game: Prison Simulator Prologue

-- MAIN APPLICATION
addappid(1431610)
-- Game: addappid(1431610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431611, 1, "ab9cf3dd8c91121722616f043cedaf0818d16b182724e0186d729a80bc7bdfaf")
