-- Lua provided by RyzenAPI 
-- Game: Prison Simulator Prologue
addappid(1431610)
addappid(1431611, 1, "ab9cf3dd8c91121722616f043cedaf0818d16b182724e0186d729a80bc7bdfaf")
