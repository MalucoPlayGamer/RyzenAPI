-- Lua provided by RyzenAPI
-- Game: DriveWave

-- MAIN APPLICATION
addappid(3942610)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3963460)
