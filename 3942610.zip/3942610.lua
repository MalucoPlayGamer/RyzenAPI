-- Lua provided by RyzenAPI
-- Game: DriveWave

-- MAIN APPLICATION
addappid(3942610)
addappid(3963460)

