-- Lua provided by RyzenAPI
-- Game: 1527870

-- MAIN APPLICATION
addappid(1527870)
-- Game: addappid(1527870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527871, 1, "ff2262159a95c54200bd1b87a30ea5371e533b7527b67a324a21621dee15d4ec")
