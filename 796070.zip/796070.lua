-- Lua provided by RyzenAPI
-- Game: addappid(796070)

-- MAIN APPLICATION
addappid(796070)

-- MAIN APP DEPOTS / PACKAGES
addappid(796071, 1, "05241ed6ff7ce4a0cb853089cdd2d5856e1f078b3d7d9d702939f1ed651c3796")
