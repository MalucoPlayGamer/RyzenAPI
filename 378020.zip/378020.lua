-- Lua provided by RyzenAPI
-- Game: 378020

-- MAIN APPLICATION
addappid(378020)
-- Game: addappid(378020)

-- MAIN APP DEPOTS / PACKAGES
addappid(378021, 1, "413c3340be662faa94f74fff8b38e95a0d7de490c1678c898821fb6cdb451801")
