-- Lua provided by RyzenAPI 
-- Game: Ashi: Lake of Light
addappid(819040)
addappid(819041, 1, "5a588ea246facfd954c78946aaa2674b7ef55c7acdfe464839998b10015ea175")
