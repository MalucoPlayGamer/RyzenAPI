-- Lua provided by SkyAPI 
-- Game: Lunavania
addappid(2770460)
addappid(2770461, 1, "be35ac65accd70d2e44e754a534eb3e3874fd495ed433f235564b172feee3a6b")
