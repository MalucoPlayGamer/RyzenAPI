-- Lua provided by RyzenAPI
-- Game: Bloody Boobs

-- MAIN APPLICATION
addappid(545250)

-- MAIN APP DEPOTS / PACKAGES
addappid(545251, 1, "60140f82c163d3f6840b3da2495a4b551a45fa27a10c5315525bd1c83c951796")

