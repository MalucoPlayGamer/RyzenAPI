-- Lua provided by RyzenAPI
-- Game: Sunrider Academy

-- MAIN APPLICATION
addappid(340730)

-- MAIN APP DEPOTS / PACKAGES
addappid(340731, 1, "a8514c0c66d6e948d64a83b67737bb7f0add7d28050919fe59fb5cfaa9f87974")
