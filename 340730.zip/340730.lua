-- Lua provided by SkyAPI 
-- Game: Sunrider Academy
addappid(340730)
addappid(340731, 1, "a8514c0c66d6e948d64a83b67737bb7f0add7d28050919fe59fb5cfaa9f87974")
