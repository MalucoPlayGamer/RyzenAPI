-- Lua provided by RyzenAPI
-- Game: Minit Fun Racer

-- MAIN APPLICATION
addappid(1503530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503531, 1, "ecd32f19940c78be5d6424f592a567ce1969966b801a0eaa351e22710f083bde")
