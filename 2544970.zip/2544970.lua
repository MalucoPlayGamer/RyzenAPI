-- Lua provided by RyzenAPI
-- Game: Fireside Demo

-- MAIN APPLICATION
addappid(2544970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544971, 1, "cd8868b92ace2a372b5447b8cedf560492415043e4379162121bc23a30a1c4ca")
