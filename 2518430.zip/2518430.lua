-- Lua provided by RyzenAPI
-- Game: The Backrooms : Last Expedition

-- MAIN APPLICATION
addappid(2518430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518431, 1, "9e251f0629640d988e0424ce23cb2970c403f2af6ca572003082736c9ca145c6")
