-- Lua provided by SkyAPI 
-- Game: BallRoll
addappid(1815730)
addappid(1815731, 1, "f524725d7f33f56f5dae595591bcbcf91a6fa9cd0ee327593898bc2310bd0599")
