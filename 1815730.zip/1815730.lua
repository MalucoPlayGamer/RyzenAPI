-- Lua provided by RyzenAPI
-- Game: 1815730

-- MAIN APPLICATION
addappid(1815730)
-- Game: addappid(1815730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815731, 1, "f524725d7f33f56f5dae595591bcbcf91a6fa9cd0ee327593898bc2310bd0599")
