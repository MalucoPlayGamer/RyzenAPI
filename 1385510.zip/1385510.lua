-- Lua provided by RyzenAPI
-- Game: Testapp2020

-- MAIN APPLICATION
addappid(1385510)
addappid(1416100)
addappid(1416101)
addappid(1416102)
addappid(1416103)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385511, 1, "2b06c9413c00a2dd93782c8ee4c5cd1d4877eaf05144a8ad78d4ed8761e6c386")
addappid(1385512, 1, "3e2ac3eb65af4cbdeabc75a111c89e3fe166efc1da416a9dd991aed867a67ce9")
addappid(1385513, 1, "afb6b7c5c2f203531cfb35a35ee9e41faa0ae01c12ca51f25a3c6ca7faca9034")
addappid(1385514, 1, "b0df123552cefa566d1fbfc3ebad64d3cf75eafae85f919c08a19d7609840ded")
addappid(1385515, 1, "9ab351c6b776f4802f913e92ae07390f9c1debdc7357c9fbac9f9174c1643734")
addappid(1385516, 1, "a448522fb599c12a41347eca124288d1108ccec33b32bc9a5afa770b24bd8a50")
addappid(1385517, 1, "ec6e0de589b4a7cabfcf30dbeecc8513474b20d45398589c90e6246bf9f455cd")

