-- Lua provided by RyzenAPI
-- Game: People Playground

-- MAIN APPLICATION
addappid(1118200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1118201, 1, "d99e7ccbd86c7d168a651c52fc54891a1b5ad40ee46627fd11bd2b4ab6bfb8d8")
addappid(1118202, 1, "a4e87225a2ee63931a6b945691d1c12696020bbc45de5e21d46ae158c8672b32")

