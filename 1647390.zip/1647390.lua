-- Lua provided by RyzenAPI 
-- Game: Dexter Stardust : Adventures in Outer Space
addappid(1647390)
addappid(1647391, 1, "b5bf9a1019c5396c1f26e35334e27ea3b78f23b968e011597e8b130247af0a98")
