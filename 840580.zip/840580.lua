-- Lua provided by RyzenAPI
-- Game: AppID 840580

-- MAIN APPLICATION
addappid(840580)
-- Game: addappid(840580)

-- MAIN APP DEPOTS / PACKAGES
addappid(840581, 1, "d91aadc4597483e6a7a6afde9041e9dd3eec90b0db1f125c3923e097b8186438")
