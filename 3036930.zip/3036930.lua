-- Lua provided by RyzenAPI
-- Game: Game: Luminaria: Dark Echoes Demo

-- MAIN APPLICATION
addappid(3036930)
-- Game: addappid(3036930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036931, 1, "350f7f39ba805bce2d2a131a965c24df9212898e5f99e0db0f743904d9959126")
