-- Lua provided by RyzenAPI 
-- Game: Donuts'n'Justice
addappid(527470)
addappid(527471, 1, "fb6bd1dc33103fec5c41fa5e2a1c21596336f94e76989a36daa02eb5afeff41f")
