-- Lua provided by RyzenAPI
-- Game: Game: AppID 843730

-- MAIN APPLICATION
addappid(843730)
-- Game: addappid(843730)

-- MAIN APP DEPOTS / PACKAGES
addappid(843731, 1, "e40c0da2b407e048ea7f51b3c4563c93b27405a99c9ddfa1f9d5388d3a5f02d2")
