-- Lua provided by RyzenAPI
-- Game: An Architect's Adventure

-- MAIN APPLICATION
addappid(1747510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747511, 1, "d81e98b5c171468c482dbf4fd8050d8ac205115e9199d1fb83e9f8ee712a2db4")
