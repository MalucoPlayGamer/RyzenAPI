-- Lua provided by RyzenAPI 
-- Game: Garden Story
addappid(1062140)
addappid(1062141, 1, "b301e899749836707814c005f7c945233c2a73310567e2608034a21f25eadab9")
addappid(1062142, 1, "b2721633df5c52df5a140507ac13fcfe1f37ada3e0e13321b96b67f283ade1f2")
