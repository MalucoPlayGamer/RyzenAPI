-- Lua provided by RyzenAPI
-- Game: Construction Machines Simulator 2016

-- MAIN APPLICATION
addappid(355330)

-- MAIN APP DEPOTS / PACKAGES
addappid(355331, 1, "4c15519ba82eacbac3af39b69d3cc49d7d97e48ba12ed9fc85b93d240604911c")
addappid(355332, 1, "b1429d2008aaad56bbe9574dee36da3f6835e81e47165d3abbcf4cc45e1c1235")

