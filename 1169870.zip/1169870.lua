-- Lua provided by SkyAPI 
-- Game: AppID 1169870
addappid(1169870)
addappid(1169871, 1, "d1dc99312aaab36189fe309f2beda690d0ef7eb39bc5189fc7f1492493b269ae")
