-- Lua provided by RyzenAPI
-- Game: 1169870

-- MAIN APPLICATION
addappid(1169870)
-- Game: addappid(1169870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169871, 1, "d1dc99312aaab36189fe309f2beda690d0ef7eb39bc5189fc7f1492493b269ae")
