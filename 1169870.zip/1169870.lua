-- Lua provided by RyzenAPI
-- Game: AppID 1169870

-- MAIN APPLICATION
addappid(1169870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1169871, 1, "d1dc99312aaab36189fe309f2beda690d0ef7eb39bc5189fc7f1492493b269ae")

