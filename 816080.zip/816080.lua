-- Lua provided by RyzenAPI
-- Game: Ultimate Select Hero / 究极勇者的选择传说

-- MAIN APPLICATION
addappid(816080)

-- MAIN APP DEPOTS / PACKAGES
addappid(816081, 1, "658e5953da8b4d51cc17986ad9d0dcc83794339f4558e8f54544a2af30979562")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
