-- Lua provided by RyzenAPI
-- Game: 816080

-- MAIN APPLICATION
addappid(816080)
-- Game: addappid(816080)

-- MAIN APP DEPOTS / PACKAGES
addappid(816081, 1, "658e5953da8b4d51cc17986ad9d0dcc83794339f4558e8f54544a2af30979562")
