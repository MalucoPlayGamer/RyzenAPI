-- Lua provided by RyzenAPI
-- Game: AppID 2086730

-- MAIN APPLICATION
addappid(2086730)
-- Game: addappid(2086730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086731, 1, "4dfdf416f47be6e104d438b634553df55479bc3db38feac1c18301929e183af5")
