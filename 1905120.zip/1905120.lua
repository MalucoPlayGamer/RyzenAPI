-- Lua provided by RyzenAPI
-- Game: addappid(1905120)

-- MAIN APPLICATION
addappid(1905120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905121, 1, "29d7a2552b483dad5beb9689af09f3deaa921c71bee90d5b4773c1033292df94")
