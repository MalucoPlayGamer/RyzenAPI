-- Lua provided by RyzenAPI
-- Game: Game: Black Jacket

-- MAIN APPLICATION
addappid(3100370)
addappid(4635860)
-- Game: addappid(3100370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100371, 1, "6f520af8fe511bdc08ff85343a4c6976c94bea0213dd877ab716758d5813cb2b")
