-- Lua provided by RyzenAPI
-- Game: orbit.industries

-- MAIN APPLICATION
addappid(1668130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668131, 1, "fe74d847709e412d8f09e09da7b1ec231b124a62c6454a6ad21a0aa2aa277cbe")
addappid(1668132, 1, "c378d563d1bc601bd6867bdf3ac8f256deeab889d104b7d826e323bc6046bd22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
