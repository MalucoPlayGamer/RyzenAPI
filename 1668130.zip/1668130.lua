-- Lua provided by RyzenAPI
-- Game: addappid(1668130)

-- MAIN APPLICATION
addappid(1668130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668131, 1, "fe74d847709e412d8f09e09da7b1ec231b124a62c6454a6ad21a0aa2aa277cbe")
addappid(1668132, 1, "c378d563d1bc601bd6867bdf3ac8f256deeab889d104b7d826e323bc6046bd22")
