-- Lua provided by RyzenAPI
-- Game: Who Is The Red Queen?

-- MAIN APPLICATION
addappid(1930440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930441, 1, "2b2d8a8d59cc7d03e86dfa94abadee66a44b17011246e56a3391a72754e8c5cf")
