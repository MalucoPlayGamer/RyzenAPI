-- Lua provided by RyzenAPI
-- Game: Eldritch Survivors

-- MAIN APPLICATION
addappid(3246830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246831,0,"b5aee4e3ee64c16abfc6b1299e0fec6999c9708747894b95bfe0bfaafdf45486")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
