-- Lua provided by RyzenAPI
-- Game: Eldritch Survivors

-- MAIN APPLICATION
addappid(3246830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246831,0,"b5aee4e3ee64c16abfc6b1299e0fec6999c9708747894b95bfe0bfaafdf45486")

