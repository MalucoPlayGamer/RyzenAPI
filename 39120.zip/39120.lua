-- Lua provided by RyzenAPI 
-- Game: RIFT
addappid(39120)
addappid(39121, 1, "3b5443c77d7ccbd460128063ae212d171603ea062ee94d6cebb37bacfe586340")
addappid(222963, 0, "f0ac32bfb29aeab1cea04e5285569bc5527112997ad4efaf35845da22f15844d")
addappid(222964, 0, "f72249b646b05ff1856ff2eaadecf8ffdd116c2149e86ee789d23c6403796982")
addappid(845241, 0, "9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")
