-- Lua provided by RyzenAPI
-- Game: VRog

-- MAIN APPLICATION
addappid(589380)

-- MAIN APP DEPOTS / PACKAGES
addappid(589381, 1, "db02e9f6273d54c88d8ba01879a4452ee4d50e51f3b93a5ae55743444f56b33a")

