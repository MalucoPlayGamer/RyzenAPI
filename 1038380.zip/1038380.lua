-- Lua provided by RyzenAPI
-- Game: addappid(1038380)

-- MAIN APPLICATION
addappid(1038380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038381, 1, "4151f151171c361c06dee890b02675290ffd0e6e0728fc3dcfab25f07d33e53d")
