-- Lua provided by RyzenAPI
-- Game: AppID 316320

-- MAIN APPLICATION
addappid(316320)

-- MAIN APP DEPOTS / PACKAGES
addappid(316321, 1, "3c4f2b6f03456d76602e55ec77fd7fbcb1bfb862e126da9c625f74dc46504e86")
addappid(316322, 1, "32b9a143771222b327f3fc1fec20f3623dba152daed92ff785e8d2f38d5eaf05")
addappid(316323, 1, "069370123aa315caaaf291c0af367b86b22ebca014bdcac7fc58865d98ca7db4")
addappid(316324, 1, "1ce882a8adfd590481ce43759c27d7c1d86e90b05b25baf6acedda4e43a94e56")
addappid(316325, 1, "a6884934cf10213a699424a407d34fe2e33c1659b8961b6e45ceae484fb74a00")
addappid(316326, 1, "f848381fb18a69ddbf2b930cb5cbe8993e4a4fd6c650e92b02a9faac2c5406cc")
addappid(316327, 1, "a1834d7ced5eb0bdc0af649456c0c4ee1785de4d1a08b6ede41e2c101ad2cfdd")
addappid(316328, 1, "d02c80a665e906bee4724dab0147e5b3231f969c49fb41bf096590e5655f3d40")
addappid(316329, 1, "7df985663ac51834c567a92bb67e8c4dc74e9a6e9ee5ea482283675f8be8ba87")
addappid(316330, 1, "8fd0402e59036367ee9689f103a231439cf1c6e449290d14da7e12e582ef64c3")
addappid(316331, 1, "d835cad35be9bab354e483cc4a1136bfd77f3d2c076be88ee226733b7abc22a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
