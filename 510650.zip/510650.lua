-- Lua provided by RyzenAPI
-- Game: addappid(510650)

-- MAIN APPLICATION
addappid(510650)
addappid(709300)

-- MAIN APP DEPOTS / PACKAGES
addappid(510651, 1, "c8f8d3067242b6309bceddeb9294a0cd017c607f195c48144afe4f8bc064bac0")
