-- Lua provided by RyzenAPI
-- Game: Citrouille: Sweet Witches

-- MAIN APPLICATION
addappid(833270)

-- MAIN APP DEPOTS / PACKAGES
addappid(833271, 1, "331f2915b97a9cd8d170a1a9c0809772b2ad1de76de31ef38ed071ebf58e142b")
addappid(833272, 1, "e9a3a69d3562936f317ea9c76b71b90f318c53421e1ba071c43ef022329f3d10")
addappid(833273, 1, "023c13751901db85f33a7e7f75df7c9571a944b6411f3d8f319d1d582fab219c")

