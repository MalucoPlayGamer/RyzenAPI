-- Lua provided by RyzenAPI
-- Game: MYRNEscapes

-- MAIN APPLICATION
addappid(1984070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1984071, 1, "31ebf996b68827c932cc259b3117d83547b14cce8e265b73392db7b914e1643f")

