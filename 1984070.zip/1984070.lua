-- Lua provided by RyzenAPI
-- Game: Game: MYRNEscapes

-- MAIN APPLICATION
addappid(1984070)
-- Game: addappid(1984070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984071, 1, "31ebf996b68827c932cc259b3117d83547b14cce8e265b73392db7b914e1643f")
