-- Lua provided by RyzenAPI
-- Game: addappid(1591940)

-- MAIN APPLICATION
addappid(1591940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591941, 1, "b770d38698cbe4942234e15b92f92d83bc4f23a5aa74d350bb5982f1ac828118")
