-- Lua provided by RyzenAPI
-- Game: Moss: The Forgotten Relic 

-- MAIN APPLICATION
addappid(3914860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3914861,0,"ee3869a7b86bd4d780a45ca23577849e3c1931b9262f30174950d52c630927d2")

