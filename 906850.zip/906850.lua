-- Lua provided by RyzenAPI
-- Game: Again?

-- MAIN APPLICATION
addappid(906850)

-- MAIN APP DEPOTS / PACKAGES
addappid(906851, 1, "5ebd0cae9eb203d85db8753171bc6ac5e13c854891e6ccc17588e793cabadcc4")

