-- Lua provided by RyzenAPI
-- Game: Game: AppID 1017180

-- MAIN APPLICATION
addappid(1017180)
-- Game: addappid(1017180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017181, 1, "244a982ca42ee3d2f9489b8debf008732bea45f9a499101041e26bd0dccfa4ed")
addappid(1017182, 1, "7efbc11f6c4f97523abaf2aac374158ac23c3348938680d9f7c88632889446e9")
