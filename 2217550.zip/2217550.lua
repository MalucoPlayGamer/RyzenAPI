-- Lua provided by RyzenAPI
-- Game: Wizard's Wheel 2

-- MAIN APPLICATION
addappid(2217550)
