-- Lua provided by RyzenAPI
-- Game: AppID 211070

-- MAIN APPLICATION
addappid(211070)

-- MAIN APP DEPOTS / PACKAGES
addappid(211071, 1, "2239d5f58149164c432af304a1b7b000d6bc284bbe4a12156e7a1121b24bdd7c")
addappid(211072, 1, "e81ad875a893538ba978c932db539a139de6a7a8739c2b1f652307272649ae41")
addappid(211073, 1, "634ddbc481146af1d9f6b51be92992567b556975a1a3c342c31878c0f90501d4")
addappid(211074, 1, "8dca82e9328f3d43cfc6c92bb3c0a2e191223e06d4c2f42ad16d5d6f574e7a61")
addappid(211075, 1, "ba58be75de764f6c0bf6d12914be3866843f4d5aa01ef4ef4aef50e9bacaf74f")
addappid(211076, 1, "ad51fd36b46bbf9a303fde7cc949e59d515b7cd88daa7cc4357816e509e43948")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(510150)
