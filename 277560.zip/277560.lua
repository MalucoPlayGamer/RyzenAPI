-- Lua provided by RyzenAPI
-- Game: Game: AppID 277560

-- MAIN APPLICATION
addappid(277560)
-- Game: addappid(277560)

-- MAIN APP DEPOTS / PACKAGES
addappid(277561, 1, "d9fc5191ff0d2a3df4556f62d92891ac2aef244c9114e2f2f1ada50cb6dd9fb5")
addappid(277562, 1, "89b883450f5d7c7a168f3fc824e6928e33eacf0050b8e6fe71f720f20c9c8b28")
addappid(277563, 1, "5e2981545062908f24da9f5f10a6de9035ea525a0393981c291b3eed7f161c40")
