-- Lua provided by RyzenAPI
-- Game: AppID 614830

-- MAIN APPLICATION
addappid(614830)

-- MAIN APP DEPOTS / PACKAGES
addappid(614831, 1, "6edf1baaf876b771b272796efd82a96a36faddc74e8a6e221cf984b2f6283b20")
