-- Lua provided by RyzenAPI
-- Game: addappid(3155320)

-- MAIN APPLICATION
addappid(3155320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155321, 1, "d246b452ebdd21502bc17e1f3ac133196216abd56b040d017b3904eec78c56c6")
