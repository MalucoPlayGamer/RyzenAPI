-- Lua provided by RyzenAPI
-- Game: Psi Project: Legacy

-- MAIN APPLICATION
addappid(753990)
-- Game: addappid(753990)

-- MAIN APP DEPOTS / PACKAGES
addappid(753991, 1, "96da9d82badee579105681e4f962951009c6889443fdca7148f05c8f62056782")
