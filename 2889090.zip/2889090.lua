-- Lua provided by RyzenAPI
-- Game: Game: Timeline 拯救存档 试用版

-- MAIN APPLICATION
addappid(2889090)
-- Game: addappid(2889090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889091, 1, "43f822556a326a5c091ea72b9cf66a81476e10ba91a851bcbea1aeaf59095623")
