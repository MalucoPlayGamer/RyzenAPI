-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2838300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838300,0,"5834bcfc536a610c610c34d46a7b37d880b2a898347f5bf525680fb541bf0f6c")
