-- Lua provided by RyzenAPI
-- Game: Space Struck Run

-- MAIN APPLICATION
addappid(994650)
-- Game: addappid(994650)

-- MAIN APP DEPOTS / PACKAGES
addappid(994651, 1, "29d413e3dbd4984512687f9908294991c6767796c94025cc8139d567c4d68260")
addappid(994652, 1, "6cf84bffd419f7d9b3ab24f7da32ebe4d075a0d9cca2626d4f0859e1251ec632")
addappid(994653, 1, "66f4bafa55f7c837ff40249161a7ddc86ae1a91b69e1e2d81dd90c0b867ea008")
