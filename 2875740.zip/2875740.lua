-- Lua provided by RyzenAPI
-- Game: Anime Girl Puzzles

-- MAIN APPLICATION
addappid(2875740)
addappid(2911900)
addappid(2911910)
addappid(2911920)
addappid(2911930)
addappid(2911940)
addappid(2911950)
addappid(2911960)
addappid(2911970)
addappid(2911980)
addappid(2911990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875741, 1, "1afdbd813a83cb434dea1a7989e192bee8a9ab135aa547213156aacd687f5e3b")

