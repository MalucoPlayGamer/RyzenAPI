-- Lua provided by RyzenAPI
-- Game: addappid(2875740)

-- MAIN APPLICATION
addappid(2875740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875741, 1, "1afdbd813a83cb434dea1a7989e192bee8a9ab135aa547213156aacd687f5e3b")
