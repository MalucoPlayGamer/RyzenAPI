-- Lua provided by RyzenAPI
-- Game: Game: AppID 1271780

-- MAIN APPLICATION
addappid(1271780)
-- Game: addappid(1271780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271781, 1, "1731533ee0035e721ee0ba1de760c9217e2d5328b5e79d8d168484a39ac9aa73")
addappid(1271782, 1, "b2fb1ea1a1a1153a057a558e8daf9829bcca45e579f33266f9fdb254d9c92114")
