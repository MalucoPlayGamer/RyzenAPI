-- Lua provided by RyzenAPI
-- Game: AppID 268910

-- MAIN APPLICATION
addappid(268910)
addappid(704710)
addappid(2072990)

-- MAIN APP DEPOTS / PACKAGES
addappid(268911, 1, "5f5e2d0105e9fcfbd0c7151658efd92af0181865fe434192f8e2c5d24d4940da")
addappid(268912, 1, "6378a6f3808fd925e8fdc2cd115d7b60f1908a6dff6b5f6c1fb0af7f392db1e4")
addappid(1117850, 0, "c40d10dcd40756563a4956777e0bb4333e48d34c00e2836edd3d5fdbc0eba095")
addappid(1117851, 0, "1d08dafb023ed4a43d3def619d54ace53b3b4bced035e744da83b4449f26cac7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
