-- Lua provided by RyzenAPI
-- Game: 459010

-- MAIN APPLICATION
addappid(459010)
-- Game: addappid(459010)

-- MAIN APP DEPOTS / PACKAGES
addappid(459011, 1, "1be058494c8df4756bdc762c1083d45b38ce1a84fc5ae9e33db7c791bd219eb0")
