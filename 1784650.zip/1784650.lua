-- Lua provided by RyzenAPI
-- Game: addappid(1784650)

-- MAIN APPLICATION
addappid(1784650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784651, 1, "0a80d2f6b653d6c83507d525abea3d76a2631d6ccf5cdb3dfcca47b71a722b28")
