-- Lua provided by RyzenAPI
-- Game: Two Point Campus Soundtrack

-- MAIN APPLICATION
addappid(2312070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312073,0,"06f13fd3463f025602478eff60da526b5595f51a7ef6d58917b57a743c71da4d")
addappid(2312074,0,"2e48b53ba066a31783869dbe417f2e771738215dcb4b79e18ebe3b6e750d2ff1")

