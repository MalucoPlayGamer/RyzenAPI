-- Lua provided by RyzenAPI
-- Game: addappid(926240)

-- MAIN APPLICATION
addappid(926240)

-- MAIN APP DEPOTS / PACKAGES
addappid(926241, 1, "8fe8668ee2fbe4a0adf8b9818d5c2deab0ea49a62c4f0809e35284a0874a30af")
