-- Lua provided by RyzenAPI
-- Game: PsyBurst

-- MAIN APPLICATION
addappid(926240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(926241, 1, "8fe8668ee2fbe4a0adf8b9818d5c2deab0ea49a62c4f0809e35284a0874a30af")
