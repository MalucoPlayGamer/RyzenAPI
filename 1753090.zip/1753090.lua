-- Lua provided by RyzenAPI
-- Game: 1753090

-- MAIN APPLICATION
addappid(1753090)
-- Game: addappid(1753090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753091, 1, "1ac5951bf999c65a9eefa5c0ae1e23d007ab6ce42e29927752f45870bc3b4096")
