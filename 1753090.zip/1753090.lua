-- Lua provided by RyzenAPI 
-- Game: CYBERDAD
addappid(1753090)
addappid(1753091, 1, "1ac5951bf999c65a9eefa5c0ae1e23d007ab6ce42e29927752f45870bc3b4096")
