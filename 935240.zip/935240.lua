-- Lua provided by RyzenAPI
-- Game: AppID 935240

-- MAIN APPLICATION
addappid(935240)

-- MAIN APP DEPOTS / PACKAGES
addappid(935241, 1, "d0d73f64b408e0c2d042c5caa3b4e2b4aa9450c01e0f2c0ae8eaab5e56c59a18")

