-- Lua provided by RyzenAPI
-- Game: 9-nine-:Episode 1

-- MAIN APPLICATION
addappid(976390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(976391, 1, "37b5f0619388e40375eee4141c2f096479ef6cf656e9ffe6b6c14d17acad8535")

