-- Lua provided by RyzenAPI
-- Game: 976390

-- MAIN APPLICATION
addappid(976390)
-- Game: addappid(976390)

-- MAIN APP DEPOTS / PACKAGES
addappid(976391, 1, "37b5f0619388e40375eee4141c2f096479ef6cf656e9ffe6b6c14d17acad8535")
