-- Lua provided by RyzenAPI
-- Game: AtmaSphere

-- MAIN APPLICATION
addappid(753660)
-- Game: addappid(753660)

-- MAIN APP DEPOTS / PACKAGES
addappid(753661, 1, "371dbb7981fdf8a538232857630a24b482c5d4651588b7b1d363264253a5955a")
