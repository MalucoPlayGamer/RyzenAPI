-- Lua provided by RyzenAPI
-- Game: addappid(2391120)

-- MAIN APPLICATION
addappid(2391120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391121, 1, "8658d21dac36195e368f8348bb95eda46b6cac489065521f43db21ca3f0515d4")
