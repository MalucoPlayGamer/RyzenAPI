-- Lua provided by SkyAPI 
-- Game: Reconnecting
addappid(2418940)
addappid(2418941, 1, "165dd88691df93e9a8551e67d2fd6c89ac14f98747e36bbe4bd6a8c808e649fc")
