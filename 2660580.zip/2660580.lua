-- Lua provided by RyzenAPI 
-- Game: AppID 2660580
addappid(2660580)
addappid(2660581, 1, "23615304531d1b5ec04db35e30640209b095d75800b02db21a5faf750160927e")
addappid(2660582, 1, "7329d761e8ffce8584c159d7a3d4dde3d8ae4dcdac2ca21844e085955e87d89e")
