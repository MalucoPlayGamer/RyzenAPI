-- Lua provided by RyzenAPI
-- Game: Total Extreme Wrestling 2010

-- MAIN APPLICATION
addappid(344810)

-- MAIN APP DEPOTS / PACKAGES
addappid(344811, 1, "4cd566d9cb52c400a10bb280d282fa54b037ba33007e5054516613b131ce1064")
