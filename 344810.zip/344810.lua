-- Lua provided by RyzenAPI 
-- Game: Total Extreme Wrestling 2010
addappid(344810)
addappid(344811, 1, "4cd566d9cb52c400a10bb280d282fa54b037ba33007e5054516613b131ce1064")
