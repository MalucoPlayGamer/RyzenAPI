-- Lua provided by SkyAPI 
-- Game: Desert Special Forces
addappid(2805640)
addappid(2805641, 1, "c8ce46319e2c5d59a594d218b927a1382e1465384b530600e35546a372732b1c")
