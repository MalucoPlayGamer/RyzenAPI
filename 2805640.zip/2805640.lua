-- Lua provided by RyzenAPI
-- Game: Desert Special Forces

-- MAIN APPLICATION
addappid(2805640)
-- Game: addappid(2805640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805641, 1, "c8ce46319e2c5d59a594d218b927a1382e1465384b530600e35546a372732b1c")
