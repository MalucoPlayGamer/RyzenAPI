-- Lua provided by RyzenAPI
-- Game: addappid(3269890)

-- MAIN APPLICATION
addappid(3269890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269891, 1, "891abdec5c4e072e83a2a584e10c8c34e8273a7bc07690790c0bfba9145a6356")
