-- Lua provided by RyzenAPI 
-- Game: Blagmoz
addappid(2614970)
addappid(2614971, 1, "c0ee375fa5e59da9c8ffe30a451e8723080e0c3279b67af87db3df77c3980cf3")
addappid(2614972, 1, "75df2e1dc59d07a281aa8285f0ce4b96cba70c20f48da5db99578b98ecc97d92")
