-- Lua provided by RyzenAPI
-- Game: 1844790

-- MAIN APPLICATION
addappid(1844790)
-- Game: addappid(1844790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844792,0,"0263de36b044eab8c20b177192df0bbea6e73f7f9f4fa5e37c2516490b0c10f9")
