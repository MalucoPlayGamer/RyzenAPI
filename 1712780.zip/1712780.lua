-- Lua provided by RyzenAPI
-- Game: 1712780

-- MAIN APPLICATION
addappid(1712780)
-- Game: addappid(1712780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712780,0,"8fc8502abb5ccbf82b9b092734559815310f2e992309e60530dbc3eff419b29f")
