-- Lua provided by RyzenAPI
-- Game: AppID 719320

-- MAIN APPLICATION
addappid(719320)
-- Game: addappid(719320)

-- MAIN APP DEPOTS / PACKAGES
addappid(719321, 1, "8b80fb8e18d414332eb3741fde2fc25925f7dd7efa260ccb753e9464881bae8c")
