-- Lua provided by RyzenAPI
-- Game: Fat Dude Simulator

-- MAIN APPLICATION
addappid(1063890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063891, 1, "6a8c42b1af5d1544d632f05c278340e40aa9863b3d243f80a1c9fe46ca91f4b7")

