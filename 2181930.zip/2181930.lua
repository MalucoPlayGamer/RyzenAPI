-- Lua provided by RyzenAPI
-- Game: AppID 2181930

-- MAIN APPLICATION
addappid(2181930)
-- Game: addappid(2181930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181931, 1, "855fed2de6c56315ee1e987c549bad7917ae168dc87c075ef656e185eae595b1")
addappid(2181932, 1, "92d1eef57f9c612d61e18278a3d7e9f8b3073f322e282b5aa2e7cb751f46891c")
