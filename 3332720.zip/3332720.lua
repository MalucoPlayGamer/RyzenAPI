-- Lua provided by RyzenAPI
-- Game: addappid(3332720)

-- MAIN APPLICATION
addappid(3332720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332721, 1, "2a3a5f29bfcaa76dcd65f24a240dafc072984f49fb38bd9a1fa733caa2d29330")
