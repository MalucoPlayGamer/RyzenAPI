-- Lua provided by RyzenAPI
-- Game: Tidalis

-- MAIN APPLICATION
addappid(40420)
-- Game: addappid(40420)

-- MAIN APP DEPOTS / PACKAGES
addappid(40421, 1, "1f2ff5943f9e239b6b7c8a088e3fb5759a9b2eefca97b6c417a0924654f58224")
addappid(40422, 1, "50c894aeab4fcfba1d135fdb00af32860e54eba450cf82268b0c870480c42c83")
addappid(40423, 1, "07ed95b56d6f8797fcdc2983ee681b6abc33d2dfaa4b200f6bcd80705502891f")
addappid(40424, 1, "f14b254958f286e74183451c459b2009cca90a58b2a6d353d2d5ddb64b4cb9cd")
addappid(40425, 1, "f475cacad2de769ed11542c2424a7af65e80923a4da9dd02459fec3927b15ee3")
