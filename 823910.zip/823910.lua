-- Lua provided by RyzenAPI 
-- Game: Last Evil
addappid(823910)
addappid(823911, 1, "fa4684f2da9b44e9e35cc1d1bf15e244ce94e458ee62e9c724d6d10096260e38")
