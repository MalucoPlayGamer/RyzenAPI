-- Lua provided by RyzenAPI
-- Game: Fae Farm - Official Soundtrack

-- MAIN APPLICATION
addappid(2468260)
-- Game: addappid(2468260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468261, 1, "9aee5b18f7cc6edd7f9a2ae26689c0e1d0faad3894db3d5a027869ba4e282a0f")
