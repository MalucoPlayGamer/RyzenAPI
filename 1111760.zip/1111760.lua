-- Lua provided by RyzenAPI
-- Game: World of Guns: VR

-- MAIN APPLICATION
addappid(1115140) -- World of Guns VR Guns Full Access
addappid(1115150) -- World of Guns VR 4 Cars Pack
addappid(1115160) -- World of Guns VR 5 Skeletons Pack
addappid(1115170) -- World of Guns VR Starter Pack
addappid(1115180) -- World of Guns VR World War II Pack
addappid(1115190) -- World of Guns VR Spec Ops Pack
addappid(1115200) -- World of Guns VR Sniper Rifles Pack 1
addappid(1115210) -- World of Guns VR U.S.A. Guns Pack 1
addappid(1115220) -- World of Guns VR USSR Guns Pack 1
addappid(1115230) -- World of Guns VR World War I Pack1
addappid(1115240) -- World of Guns VR Aircraft Guns
addappid(1115250) -- World of Guns VR Revolver Pack 1
addappid(1115260) -- World of Guns VR World War II Pack 2
addappid(1115270) -- World of Guns VR Pistols Pack 1
addappid(1115280) -- World of Guns VR Pistols Pack 2
addappid(1115290) -- World of Guns VR Hunting Pack 1
addappid(1115300) -- World of Guns VR Shotguns Pack 1
addappid(1115310) -- World of Guns VR SMG Pack 1
addappid(1115320) -- World of Guns VR Assault Rifles Pack 1
addappid(1115330) -- World of Guns VR Bolt Action Rifles Pack 1
addappid(1115340) -- World of Guns VR XIX Century Pack 1
addappid(1115350) -- World of Guns VR Suppressed Guns Pack 1
addappid(1115360) -- World of Guns VR Texture Pack 1
addappid(1115370) -- World of Guns VR Texture Pack 2

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(1111760, 1, "4e977f1557ca980702e2a8cae0363f0316c86ef5365f328a5017d1f19a87353d") -- World of Guns: VR
addappid(1111761, 1, "09359752d730e2e2aa387fa2390919e48df2d477ce3c313230e8a717238123ba") -- World of Guns: VR Content

