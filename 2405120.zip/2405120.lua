-- Lua provided by RyzenAPI
-- Game: Pillars

-- MAIN APPLICATION
addappid(2405120)
-- Game: addappid(2405120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405121, 1, "df3596a31a9a1e7e472a475406de0d8de54f7bd6be5c47fd2011960c66819c47")
