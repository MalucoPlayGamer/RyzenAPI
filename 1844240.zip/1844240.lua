-- Lua provided by RyzenAPI
-- Game: Dinosaur Park – Primeval Zoo

-- MAIN APPLICATION
addappid(1844240)
-- Game: addappid(1844240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844241, 1, "12f71a342376a84e7be322155c9624be68d2933b8f14008f85b4cc29d04b6b8d")
