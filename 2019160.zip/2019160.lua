-- Lua provided by RyzenAPI
-- Game: Game: Capcom Arcade 2nd Stadium: Mini-Album Track 1 - SONSON - Main Theme

-- MAIN APPLICATION
addappid(2019160)
-- Game: addappid(2019160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019161, 1, "058928683634192fb35bda4fd7bc17e696651149391ab97863d1abca9f2dc3af")
addappid(2019162, 1, "4cc7667c1547e5b930e56844cb45622917f8297205014d1a91dcde4f3b013e48")
addappid(2019163, 1, "a672c9c0d3fa7d23db27c0456492797856294cd5880750033f8b5fbe88ff6411")
addappid(2019164, 1, "3ce4a43ae620ba5091fa2cd4cc1e7effd120be60cebbef1be8938a3cd89a5cc9")
addappid(2019165, 1, "747bb0dcb81532209b4533aa9f6a88998d15102a4941d2af1d9b0705fafc67fe")
addappid(2019166, 1, "d5a1b38e517e868721cd18b410e082d04150a5125115a2e8c2f009fd0ba32bf0")
