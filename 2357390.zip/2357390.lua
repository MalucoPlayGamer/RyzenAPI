-- Lua provided by RyzenAPI
-- Game: Game: AppID 2357390

-- MAIN APPLICATION
addappid(2357390)
-- Game: addappid(2357390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357391, 1, "a7c8e3e575e3d41a9fe3fdd89621b5d5a5cf8f41142f476b812fc50ec70e653a")
