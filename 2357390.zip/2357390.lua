-- Lua provided by RyzenAPI 
-- Game: AppID 2357390
addappid(2357390)
addappid(2357391, 1, "a7c8e3e575e3d41a9fe3fdd89621b5d5a5cf8f41142f476b812fc50ec70e653a")
