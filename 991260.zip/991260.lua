-- Lua provided by RyzenAPI
-- Game: Borderlands 2 VR

-- MAIN APPLICATION
addappid(991260)

-- MAIN APP DEPOTS / PACKAGES
addappid(991261, 1, "a3dfffbc00e24551b2cff222f4736d383a960a1957e5afd4e69b287cfc6b5400")
addappid(991262, 1, "57ce37728eaf3997849c2ae529c6ead9c222df09124cc9b9329d024cee2f6261")
addappid(991263, 1, "11ec3c62a62929b4027a35b2c385326fa9d36916cf986980bfb21530c866aaef")
addappid(991267, 1, "a0d234a92ff2917f195800c3ce65e8a34b87d1cd68ae58b3eee5a9c3796cc139")
addappid(1046900, 0, "55d0f7a80b7f1a01e0b40c604a4e5a810430edb01c3f12997fc50fe44769605f")
addappid(1046901, 1, "2f5b88d9270432a6bfe8270e0337d0085df2084cc48f866d50a0f7a25618be0d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
