-- Lua provided by RyzenAPI 
-- Game: THE LONGING - Soundtrack
addappid(1275730)
addappid(1275731, 1, "af100b738db43523a59572f64d4089008cb54013472124f39bf2316c0db4bb46")
addappid(1275732, 1, "8a26fdde46c7da30b5df2682001f7af7f48258a36bd3856791fa3a7f155b6da4")
