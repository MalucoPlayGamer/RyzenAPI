-- Lua provided by RyzenAPI
-- Game: Feudal Baron: King's Land

-- MAIN APPLICATION
addappid(1674530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674531, 1, "20da52a8a988d79a4692faee4c493c0f62a2bcf63beb7b6f0fed6495fcad60ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
