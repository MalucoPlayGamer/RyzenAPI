-- Lua provided by RyzenAPI 
-- Game: Feudal Baron: King's Land
addappid(1674530)
addappid(1674531, 1, "20da52a8a988d79a4692faee4c493c0f62a2bcf63beb7b6f0fed6495fcad60ff")
