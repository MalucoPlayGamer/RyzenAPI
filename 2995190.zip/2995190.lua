-- Lua provided by RyzenAPI
-- Game: addappid(2995190)

-- MAIN APPLICATION
addappid(2995190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995192,0,"14ee18fc79b433347412a2856bfe2f845d86d6f4c2fab9952a02c6b7f4f2bdcf")
