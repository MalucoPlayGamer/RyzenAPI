-- Lua provided by RyzenAPI
-- Game: Starblast: Retro Wars

-- MAIN APPLICATION
addappid(1770350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770352,0,"5999b8aea98d73f7912911e8ff06205657da5eab993ad34df5f2717e33925739")

