-- Lua provided by RyzenAPI
-- Game: AppID 1153510

-- MAIN APPLICATION
addappid(1153510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153511, 1, "d43e183172b70e89de60de9176bc74b0f0191493c9ee392d27e514f6715516c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
