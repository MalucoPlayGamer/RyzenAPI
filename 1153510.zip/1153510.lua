-- Lua provided by RyzenAPI
-- Game: Game: AppID 1153510

-- MAIN APPLICATION
addappid(1153510)
-- Game: addappid(1153510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153511, 1, "d43e183172b70e89de60de9176bc74b0f0191493c9ee392d27e514f6715516c4")
