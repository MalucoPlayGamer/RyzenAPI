-- Lua provided by RyzenAPI 
-- Game: Inbetween Land
addappid(345540)
addappid(345541, 1, "dfbdcf5665943c4ddd4fedacf772d10f1e11513f9e39f76d4ef0e971bef7defd")
