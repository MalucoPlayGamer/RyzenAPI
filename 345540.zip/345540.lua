-- Lua provided by RyzenAPI
-- Game: addappid(345540)

-- MAIN APPLICATION
addappid(345540)

-- MAIN APP DEPOTS / PACKAGES
addappid(345541, 1, "dfbdcf5665943c4ddd4fedacf772d10f1e11513f9e39f76d4ef0e971bef7defd")
