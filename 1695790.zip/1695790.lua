-- Lua provided by RyzenAPI
-- Game: Halo 2 Anniversary MP Mod Tools - MCC

-- MAIN APPLICATION
addappid(1695790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695799,0,"ba4f97c5d21e4af0bbda24ad0636b7baf24acb454ef0800abf25dc63af6b3527")

