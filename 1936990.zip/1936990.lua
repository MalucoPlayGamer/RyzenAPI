-- Lua provided by RyzenAPI
-- Game: FROGUE

-- MAIN APPLICATION
addappid(1936990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936991, 1, "fd723b54513cbf7e0ef18f393eae0c66a91b2fb2f88877f447366128baacba21")
