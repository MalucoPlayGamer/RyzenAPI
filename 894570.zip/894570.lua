-- Lua provided by RyzenAPI
-- Game: 894570

-- MAIN APPLICATION
addappid(228988)
addappid(894570)
addappid(894571)
addappid(894572)
addappid(894574)

-- MAIN APP DEPOTS / PACKAGES
addappid(894573,0,"37442c0e0a1f938d87dd0ec865e45739096878b1d0427d25bf630a193e6bb8b4")
