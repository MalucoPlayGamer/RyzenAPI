-- Lua provided by RyzenAPI 
-- Game: GROSS
addappid(1647420)
addappid(1647421, 1, "804c4cebef1bc65203cfa341358b375cd50d2d966cae7fa6c11ad9bf1c378dc2")
