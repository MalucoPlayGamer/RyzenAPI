-- Lua provided by RyzenAPI
-- Game: AppID 1304310

-- MAIN APPLICATION
addappid(1304310)
-- Game: addappid(1304310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304311, 1, "2c79f4dde1112688e43cd1b41333bc949f4dd41a8a2b83fe76675e657e275a61")
