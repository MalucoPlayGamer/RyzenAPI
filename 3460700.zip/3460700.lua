-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! Deathtrap Soundtrack

-- MAIN APPLICATION
addappid(3460700)
-- Game: addappid(3460700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460701, 1, "4669c5b11263f0277a6cb2f752220857a52337e66dbb077de31edc46798a3ab0")
addappid(3460702, 1, "9cb5bc80edfa8f8ca0fbaef52cbe8d4c4b0b734c5865d2fb84fc968086443c95")
