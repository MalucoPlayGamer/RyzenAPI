-- Lua provided by RyzenAPI
-- Game: 3304980

-- MAIN APPLICATION
addappid(3304980)
-- Game: addappid(3304980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304981, 1, "b4e0cadf7bf7a5d8b2634b7f2c8ee85bb0712d145152695907d660dffc63e811")
