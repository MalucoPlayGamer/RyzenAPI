-- Lua provided by RyzenAPI
-- Game: The Duchess Curse

-- MAIN APPLICATION
addappid(3304980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3304981, 1, "b4e0cadf7bf7a5d8b2634b7f2c8ee85bb0712d145152695907d660dffc63e811")

