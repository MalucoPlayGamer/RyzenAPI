-- Lua provided by RyzenAPI
-- Game: Game: AppID 214320

-- MAIN APPLICATION
addappid(214320)
-- Game: addappid(214320)

-- MAIN APP DEPOTS / PACKAGES
addappid(214321, 1, "e65b2d9a144047a5742e2953ae80b3e7da4683b72d5944d853a5628f4a57e3df")
