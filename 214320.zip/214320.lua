-- Lua provided by RyzenAPI
-- Game: Dollar Dash

-- MAIN APPLICATION
addappid(214320) -- Dollar Dash
addappid(214330) -- Dollar Dash DLC1 More Ways to Win
addappid(214331) -- Dollar Dash DLC2 Robbers Tool-Kit
addappid(214332) -- Dollar Dash DLC3 Winter Pack
addappid(221890) -- Dollar Dash DLC 3

-- MAIN APP DEPOTS / PACKAGES
addappid(214321, 1, "e65b2d9a144047a5742e2953ae80b3e7da4683b72d5944d853a5628f4a57e3df") -- Dollar Dash Content
addtoken(214332, "17022041679279468590")
