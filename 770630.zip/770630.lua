-- Lua provided by RyzenAPI
-- Game: addappid(770630)

-- MAIN APPLICATION
addappid(770630)

-- MAIN APP DEPOTS / PACKAGES
addappid(770631, 1, "ebb49e093b020e1854be10bcc4a5c8dadb77c2d5aada8b6fdb7e9475626e675f")
