-- Lua provided by RyzenAPI
-- Game: AppID 770630

-- MAIN APPLICATION
addappid(770630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(770631, 1, "ebb49e093b020e1854be10bcc4a5c8dadb77c2d5aada8b6fdb7e9475626e675f")

