-- Lua provided by RyzenAPI
-- Game: The Pyraplex

-- MAIN APPLICATION
addappid(2101280)
-- Game: addappid(2101280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101281, 1, "ef48318093942e2e1179ab0b60d8c9dc1dccd34c2059ecc093bd8c62c6f50272")
