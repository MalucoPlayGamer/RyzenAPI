-- Lua provided by RyzenAPI
-- Game: 2455340

-- MAIN APPLICATION
addappid(2455340)
-- Game: addappid(2455340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455341, 1, "bd953fe00a357e6f55f90ad6662844faac0e09cf3b136b5a882dfd65d9a83c85")
