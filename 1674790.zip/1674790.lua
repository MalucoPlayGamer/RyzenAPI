-- Lua provided by RyzenAPI
-- Game: addappid(1674790)

-- MAIN APPLICATION
addappid(1674790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674790,0,"15c673c3d2434f1e425404fa41f8ff61084aac80947f4d43e7eba11bd393b84e")
