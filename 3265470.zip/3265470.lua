-- Lua provided by RyzenAPI
-- Game: 108 Silly Ways to Die Demo

-- MAIN APPLICATION
addappid(3265470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265471, 1, "8325feca35e41e3acaed851cc4e41daf73663f18f9ad02b7cb5efc5366ebeb64")