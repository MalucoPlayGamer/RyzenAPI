-- Lua provided by RyzenAPI
-- Game: Fate Chapter 2 : The Beginning

-- MAIN APPLICATION
addappid(1687200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687201, 1, "ee7726a1fb0ce417e99edd50ba3d9e3987e4cc16962c10bd3dde8398353888bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
