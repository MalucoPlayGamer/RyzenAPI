-- Lua provided by RyzenAPI
-- Game: Down the Rabbit Hole

-- MAIN APPLICATION
addappid(1215270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215271, 1, "8dded2ec9788fb3f4150a4a7102877958b18323d8c77b08b39ff7f657420dbea")
addappid(1215272, 1, "c52504050dee5edb6dcabe2f2a1bb50828723baa885790d3263e3c4c25e22c3e")

