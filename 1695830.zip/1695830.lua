-- Lua provided by RyzenAPI
-- Game: AppID 1695830

-- MAIN APPLICATION
addappid(1695830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1695831, 1, "d1c928327ca3ee9b74a853ef2af83aa2825a74f9af579767ea087b5923114654")

