-- Lua provided by RyzenAPI
-- Game: 1695830

-- MAIN APPLICATION
addappid(1695830)
-- Game: addappid(1695830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695831, 1, "d1c928327ca3ee9b74a853ef2af83aa2825a74f9af579767ea087b5923114654")
