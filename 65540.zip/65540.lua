-- Lua provided by RyzenAPI
-- Game: Gothic 1

-- MAIN APPLICATION
addappid(65540)

-- MAIN APP DEPOTS / PACKAGES
addappid(65541, 1, "7569e0909584de1e0db77538c82cb0be2eca4b476e6d484b9e0d24055ec88af8")
addappid(65542, 1, "3df1fe9782f10456b452128397eab6c2e3ce53df2c2d51a367e30c6c2fe13161")
addappid(65543, 1, "6a4d1034795726b807230679c053583dc38e79eb7526ef86f1c936456c4ef80c")
addappid(65544, 1, "602698246a6351405525e26d201ab220f101d2dda1aa3d7447e91822e7b67efb")
addappid(65545, 1, "0bf739d9f0bcde1e419c2e08f20e197b87f3ff5e845eb1d7d9e93eb7c16313a1")
addappid(65546, 1, "21fbcba7ddf44f3912ead36acefdffd4a0251b4d73db379f3a3fbbf69b6d5726")
addappid(65547, 1, "beb6c4c62e06e6d3f61db2895bb883f0f9448653b5052af158186e3a9d5171a4")
addappid(65548, 1, "23665019b75bacb6bdb90dbf5a8e517ca087392f9a0ceccfa524444a031ec12e")
addappid(65549, 1, "64ddccaab63d34bd3fc0f17be96157d2e93de57d114c2fcb5049f809d0ac76c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
