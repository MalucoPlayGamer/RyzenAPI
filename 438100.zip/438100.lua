-- Lua provided by RyzenAPI
-- Game: Game: AppID 438100

-- MAIN APPLICATION
addappid(438100)
-- Game: addappid(438100)

-- MAIN APP DEPOTS / PACKAGES
addappid(438101, 1, "3479e8ef2bdeedf17313e5cd206d1eab607bc61385b6fe88bc499ea004033f70")
