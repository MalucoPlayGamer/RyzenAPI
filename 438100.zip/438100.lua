-- Lua provided by RyzenAPI
-- Game: VRChat

-- MAIN APPLICATION
addappid(438100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(438101, 1, "3479e8ef2bdeedf17313e5cd206d1eab607bc61385b6fe88bc499ea004033f70")

