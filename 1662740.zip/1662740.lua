-- Lua provided by SkyAPI 
-- Game: [marked for removal]
addappid(1662740)
addappid(1662741, 1, "fd3c776c17ea67069e2dd66e73b01fc8550d0ea03836a9177300f549881ee05c")
addappid(1662742, 1, "809525bc4d205dd59dedfb2c1bb41deb187cfc2735d11e79e5624761f4060f88")
addappid(1662743, 1, "1cbc8c34b086ad376e3c6ad1096c05e4cc8d595776aed0b70fd624b0c4589e52")
