-- Lua provided by RyzenAPI
-- Game: 1020210

-- MAIN APPLICATION
addappid(1020210)
-- Game: addappid(1020210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020211, 1, "dc4f0b37455b6ce1b023e923ad33666b29b330f293c6aa5f36091cdd7122b3b7")
