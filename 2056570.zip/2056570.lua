-- Lua provided by RyzenAPI
-- Game: Junkyard War

-- MAIN APPLICATION
addappid(2056570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056571, 1, "d27484cfcb5f88530ce6d6f6717c41d146fde4e72dc1cf2c1040cbfe56bb986f")

