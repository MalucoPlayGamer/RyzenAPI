-- Lua provided by RyzenAPI
-- Game: Junkyard War

-- MAIN APPLICATION
addappid(2056570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056571, 1, "d27484cfcb5f88530ce6d6f6717c41d146fde4e72dc1cf2c1040cbfe56bb986f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
