-- Lua provided by RyzenAPI
-- Game: [Nightmare Files] Clap Clap

-- MAIN APPLICATION
addappid(2933290)

