-- Lua provided by RyzenAPI
-- Game: Niwa - Japanese Garden Simulator

-- MAIN APPLICATION
addappid(2643210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643211, 1, "c8f2e37a3cbef6acf8879d394264bf512b93e6f15abdf3f41b4841dcee5c5319")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
