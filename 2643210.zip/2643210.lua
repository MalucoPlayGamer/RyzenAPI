-- Lua provided by RyzenAPI 
-- Game: Niwa - Japanese Garden Simulator
addappid(2643210)
addappid(2643211, 1, "c8f2e37a3cbef6acf8879d394264bf512b93e6f15abdf3f41b4841dcee5c5319")
