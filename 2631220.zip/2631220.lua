-- Lua provided by RyzenAPI 
-- Game: Six Sides of Obscurity
addappid(2631220)
addappid(2631221, 1, "6666ec7cf1a7afe28ecbc7b18a880a25c24aeed9dcb47f8390012f5e618e2f3e")
