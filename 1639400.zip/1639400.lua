-- Lua provided by RyzenAPI
-- Game: Game: 少女首領の推理領域 -黄金島の密約-

-- MAIN APPLICATION
addappid(1639400)
-- Game: addappid(1639400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639401, 1, "d2826e42aeae5ca746a7afadc6adfba6c21700c63e2237d23e67c9329691dedc")
