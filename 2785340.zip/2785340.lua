-- Lua provided by RyzenAPI
-- Game: Kingdom, Dungeon, and Hero Demo

-- MAIN APPLICATION
addappid(2785340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785341, 1, "2dd4e195ddb50281100c719ef407df201cfd3d74da25f36973516f5d011ea704")
