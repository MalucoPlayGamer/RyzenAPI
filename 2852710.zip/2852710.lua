-- Lua provided by RyzenAPI
-- Game: My love with the GirlsGroup

-- MAIN APPLICATION
addappid(2852710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852711, 1, "084d1bce3ccf0cc2c9c64455680b58e08554ece673cc8d082c1857e4e75b28a2")
addappid(2852712, 1, "0729d3d7831849ae20139e5c903f538af6d855a3f6e1f7b7981bfc7308958b6a")
