-- Lua provided by RyzenAPI
-- Game: addappid(552060)

-- MAIN APPLICATION
addappid(552060)

-- MAIN APP DEPOTS / PACKAGES
addappid(552061, 1, "02986351f1f09d4ab0e64518c2dcfa9f9f534f5fd421f6cb5f11eab5c9782373")
