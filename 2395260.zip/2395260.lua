-- Lua provided by RyzenAPI
-- Game: Midnight Shift

-- MAIN APPLICATION
addappid(2395260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395261, 1, "29c2b2e9bb5e0f1fdf802c71052622c6907ff977f461f3768eb8ccfe402fea24")
