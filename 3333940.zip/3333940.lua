-- Lua provided by RyzenAPI
-- Game: Game: AppID 3333940

-- MAIN APPLICATION
addappid(3333940)
-- Game: addappid(3333940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333941, 1, "802fc64ee7e41627fbe805346ca29103b080f735f6a95996b345d4d48148e4b3")
