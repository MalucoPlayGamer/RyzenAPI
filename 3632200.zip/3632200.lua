-- Lua provided by RyzenAPI
-- Game: Game: Naughty MILF casting: Porn Star VR

-- MAIN APPLICATION
addappid(3632200)
-- Game: addappid(3632200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3632201, 1, "b1a28909aeb6a59c60a30448352b42492faa0a9d12adb4811174b90bf60020a6")
