-- Lua provided by RyzenAPI
-- Game: Late photographer 5

-- MAIN APPLICATION
addappid(1990550)
addappid(1991770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990551, 1, "559c28a9ac8d54a51b56d684109252caa18cb908e3c724e87ec6a229bcc965a2")
addappid(1992960, 0, "b4db3f27da113254e243c374b5c0f8177eba8e86960912560bdc1ed87bf0a3b3")
