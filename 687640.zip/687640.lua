-- Lua provided by RyzenAPI
-- Game: Game: Infinity Assassin (VR)

-- MAIN APPLICATION
addappid(687640)
-- Game: addappid(687640)

-- MAIN APP DEPOTS / PACKAGES
addappid(687641, 1, "448b9a6c84150f91df459305625c0c0228148f3b04a0d67c53d19de9be4b1a79")
