-- Lua provided by RyzenAPI
-- Game: Infinity Assassin (VR)

-- MAIN APPLICATION
addappid(687640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(687641, 1, "448b9a6c84150f91df459305625c0c0228148f3b04a0d67c53d19de9be4b1a79")

