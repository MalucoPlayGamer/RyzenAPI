-- Lua provided by RyzenAPI
-- Game: AppID 1663440

-- MAIN APPLICATION
addappid(1663440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663441, 1, "00ae3f06f2830d99a0c32e9f3b7f9a6c23e99bbfe03cdedfeab1594e028357e5")
