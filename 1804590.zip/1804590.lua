-- Lua provided by RyzenAPI
-- Game: addappid(1804590)

-- MAIN APPLICATION
addappid(1804590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804591, 1, "d3d11af69c065ef9055aa843901b0c83a9956d500d48222df8c339bf63fc58ae")
