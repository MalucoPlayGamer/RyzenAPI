-- Lua provided by SkyAPI 
-- Game: Fae Farm Demo
addappid(2783750)
addappid(2783751, 1, "128852c75bb6af9cb71446f3a2e622c58375130bb04da46cf75309c6399f03d8")
