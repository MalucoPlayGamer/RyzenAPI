-- Lua provided by RyzenAPI
-- Game: Fae Farm Demo

-- MAIN APPLICATION
addappid(2783750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783751, 1, "128852c75bb6af9cb71446f3a2e622c58375130bb04da46cf75309c6399f03d8")
