-- Lua provided by RyzenAPI
-- Game: AppID 557260

-- MAIN APPLICATION
addappid(557260)
-- Game: addappid(557260)

-- MAIN APP DEPOTS / PACKAGES
addappid(557261, 1, "60953ff97063354c5bbeee4d092b7eb124d1019d4f6a1d98b8cee417720d34c4")
