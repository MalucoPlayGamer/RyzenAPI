-- Lua provided by RyzenAPI
-- Game: 2501690

-- MAIN APPLICATION
addappid(2501690)
-- Game: addappid(2501690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501691, 1, "0fc3e146dc315b045f3eb1ff913069ab33f6a1f02ffa99be8bce49ddc89d38e6")
