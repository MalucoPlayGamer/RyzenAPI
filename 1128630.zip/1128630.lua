-- Lua provided by RyzenAPI
-- Game: Cross Country Express

-- MAIN APPLICATION
addappid(1128630)
-- Game: addappid(1128630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128631, 1, "991143c6fd1db498cea81fc5a0a31c61bb691080c838eb80caceb3426fb171ea")
