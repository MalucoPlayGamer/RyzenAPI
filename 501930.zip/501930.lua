-- Lua provided by RyzenAPI
-- Game: Game: Sig.NULL

-- MAIN APPLICATION
addappid(501930)
-- Game: addappid(501930)

-- MAIN APP DEPOTS / PACKAGES
addappid(501931, 1, "427781ec58b18cc3e0905cf5f4c03d634b919e43b7b768d45aff8a586e7ab170")
