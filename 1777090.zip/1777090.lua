-- Lua provided by RyzenAPI
-- Game: Halloween Stories: Horror Movie Collector's Edition

-- MAIN APPLICATION
addappid(1777090)
-- Game: addappid(1777090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777091, 1, "8e4fc6001fcdea3f5161bfe656f9257fbd7ac2efba734731b981570bc451c746")
