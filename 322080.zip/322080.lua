-- Lua provided by RyzenAPI
-- Game: Disorder

-- MAIN APPLICATION
addappid(322080)
addappid(409740)
-- Game: addappid(322080)

-- MAIN APP DEPOTS / PACKAGES
addappid(322081, 1, "d843081a00f5b72a51d43c5606d89f81a180ee18cb016b60dab94b032533e72e")
addappid(322082, 1, "16c78f545c6f9e6f79fdd9f4c6f736a5178263f13303949097c4ee2a9f257be9")
