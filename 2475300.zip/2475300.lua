-- Lua provided by RyzenAPI
-- Game: Carmen Sandiego

-- MAIN APPLICATION
addappid(2475300)
addappid(3311640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475301, 1, "f473cf38e3fd909e56fc7299424141d710b4d6bac319dabc2933aed73bba21ac")
