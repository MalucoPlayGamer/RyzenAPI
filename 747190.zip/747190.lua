-- Lua provided by RyzenAPI
-- Game: addappid(747190)

-- MAIN APPLICATION
addappid(747190)

-- MAIN APP DEPOTS / PACKAGES
addappid(747191, 1, "5a893a4f91f694e833e791b8c3b10a4cbe02fb9f1581d3b7cd78b1d922d8ecc5")
