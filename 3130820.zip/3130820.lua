-- Lua provided by RyzenAPI
-- Game: AppID 3130820

-- MAIN APPLICATION
addappid(3130820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130821, 1, "7f9b34b78ce34182e5cdba18ccc8c827b837f5a694b4411e8baa03a9cd7015af")
