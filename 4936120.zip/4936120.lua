-- Lua provided by RyzenAPI
-- Game: Necromancer Idle: The Endless Drain

-- MAIN APPLICATION
addappid(4936120) -- Necromancer Idle: The Endless Drain

-- MAIN APP DEPOTS / PACKAGES
addappid(4936121, 1, "e41ea85daa2fffd24f91e24d627a3ede7a1fbaca863a74742da1571d12efcd5d") -- Depot 4936121
addappid(4936122, 1, "0a3cfd1672317df8931c61f480cfe3ba6637e526d0ddc9ba599e577c32bed5ad") -- Depot 4936122

