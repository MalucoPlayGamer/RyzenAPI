-- Lua provided by RyzenAPI
-- Game: 3070460

-- MAIN APPLICATION
addappid(3070460)
-- Game: addappid(3070460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070461, 1, "5eaf39ff5038faca091aa6e5f76f75ee015ce66ef57bd59efc0a6c869e2bd966")
