-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: JustAsia - OBBI - Bahrain Intl Airport & City

-- MAIN APPLICATION
addappid(1203541)
-- Game: addappid(1203541)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203541,0,"f5b9c4520e28c39a633f68594fe7ee9e3fa076ddb8781d74d37d37f79523004a")
