-- Lua provided by RyzenAPI
-- Game: 2936410

-- MAIN APPLICATION
addappid(2936410)
-- Game: addappid(2936410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936411, 1, "c7d33e1cfccdabdd1e38d272526597e82db73a2a758a5b42cc1449c4ef908339")
addappid(2936413, 1, "f3ebff5e78d66ed1a37975ce68d59cf1f698ed02064fb37578ef71f31ceee844")
addappid(2936414, 1, "e93a27ac80177c32f6d7149f3d47e7f6d46ea9df4da410acd4626902501d3ec4")
addappid(2936415, 1, "ca4e274c199cb402c90a629a6cc4b4deee30d29e21769ad1957d9d6e2163c3ec")
