-- Lua provided by RyzenAPI
-- Game: FlyKnight

-- MAIN APPLICATION
addappid(3108510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108511, 1, "be53921572a1059b702c1eba9cb4b0432b7abc632123699f9384ece6d5e2b34b")

