-- Lua provided by RyzenAPI
-- Game: Greed Corp

-- MAIN APPLICATION
addappid(48950)

-- MAIN APP DEPOTS / PACKAGES
addappid(48952,0,"c422d10ba95233623758be4adac302a5f47f0ddfe59f212e6c767765a4a19a43")

