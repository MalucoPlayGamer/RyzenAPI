-- Lua provided by RyzenAPI
-- Game: Game: Deiland: Pocket Planet

-- MAIN APPLICATION
addappid(1623700)
-- Game: addappid(1623700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623701, 1, "75a05030b3e908288ee229596ab32dc5834d01aeddff7da05f81c82649b9dd39")
