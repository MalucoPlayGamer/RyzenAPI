-- Lua provided by RyzenAPI
-- Game: 100 hidden frogs

-- MAIN APPLICATION
addappid(1806840)
