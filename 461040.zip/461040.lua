-- Lua provided by RyzenAPI
-- Game: PICO PARK:Classic Edition

-- MAIN APPLICATION
addappid(461040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(461041, 1, "2ecb32a6b2ed2963e60c65e7b1bd545ecb881ae66e65df04684c15a3c54a0645")
