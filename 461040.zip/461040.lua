-- Lua provided by SkyAPI 
-- Game: AppID 461040
addappid(461040)
addappid(461041, 1, "2ecb32a6b2ed2963e60c65e7b1bd545ecb881ae66e65df04684c15a3c54a0645")
