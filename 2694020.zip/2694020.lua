-- Lua provided by RyzenAPI
-- Game: Starbreed

-- MAIN APPLICATION
addappid(2694020) -- Starbreed
-- addappid(4932900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694021, 1, "2b96fc752a81ae0beabc903d287d5211cc913e5334276a526ad32d30af530837") -- Depot 2694021
addappid(2694022, 1, "3fa69f80061adf89519d3f12fd13f71a0ce3c7d5d7d2655317abf96bc577e190") -- Depot 2694022

