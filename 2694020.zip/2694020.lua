-- 2694020's Lua and Manifest Created by Hubcap Manifest
-- Starbreed
-- Created: August 05, 2026 at 14:12:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2694020) -- Starbreed
-- MAIN APP DEPOTS
addappid(2694021, 1, "2b96fc752a81ae0beabc903d287d5211cc913e5334276a526ad32d30af530837") -- Depot 2694021
setManifestid(2694021, "5033343549712278310", 3515057346)
addappid(2694022, 1, "3fa69f80061adf89519d3f12fd13f71a0ce3c7d5d7d2655317abf96bc577e190") -- Depot 2694022
setManifestid(2694022, "3334767537935615514", 3526525896)
-- DLCS WITH DEDICATED DEPOTS
-- Starbreed Artbook (AppID: 4932900)
addappid(4932900)
addappid(4932901, 1, "7ce232e3f6d37a75e4367ec88da59457a3872d7df2ada4b944bbf36983833d97") -- Starbreed Artbook - Depot 4932901
setManifestid(4932901, "5024143624947058430", 148806828)