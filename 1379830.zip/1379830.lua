-- Lua provided by RyzenAPI
-- Game: Cyber Crush 2069

-- MAIN APPLICATION
addappid(1379830)
addappid(1442210)
-- Game: addappid(1379830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379831, 1, "afe1d64057d4621d6a1facca5f9945f522cee0ad51ccaa20db93a80615ff1239")
