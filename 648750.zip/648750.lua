-- Lua provided by RyzenAPI
-- Game: addappid(648750)

-- MAIN APPLICATION
addappid(648750)

-- MAIN APP DEPOTS / PACKAGES
addappid(648752,0,"adb484eaa59a19b7d23d9408e2fe0dc41ad346d3221c7f501557e251a541c6e2")
