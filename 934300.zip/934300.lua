-- Lua provided by RyzenAPI
-- Game: The Caligula Effect: Overdose - Digital Art Book

-- MAIN APPLICATION
addappid(934300)

-- MAIN APP DEPOTS / PACKAGES
addappid(934300,0,"a09eed7a69428985ee9ffde0ce9cac18d32a2c7b73fd14184f2d5a92cf9e7dce")

