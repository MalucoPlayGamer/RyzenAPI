-- Lua provided by RyzenAPI
-- Game: Trine 4: The Nightmare Prince

-- MAIN APPLICATION
addappid(690640)
addappid(1113990)
addappid(1444560)
addappid(1504370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(690641, 1, "42a0d2c4b4508e91a808d579233e2f5cac28bd41a8610b36809a2ed73090cbd4")
addappid(1504371, 1, "25cd6a286dbc5bda444a8a9d3a68226ab661ade835f83e57cf04c6f3a751c783")
