-- Lua provided by RyzenAPI
-- Game: Game: AppID 690640

-- MAIN APPLICATION
addappid(690640)
addappid(1113990)
addappid(1444560)
-- Game: addappid(690640)

-- MAIN APP DEPOTS / PACKAGES
addappid(690641, 1, "42a0d2c4b4508e91a808d579233e2f5cac28bd41a8610b36809a2ed73090cbd4")
addappid(1504371, 1, "25cd6a286dbc5bda444a8a9d3a68226ab661ade835f83e57cf04c6f3a751c783")
