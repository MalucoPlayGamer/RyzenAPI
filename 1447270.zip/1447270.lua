-- Lua provided by RyzenAPI
-- Game: Game: Woodland Empire Demo

-- MAIN APPLICATION
addappid(1447270)
-- Game: addappid(1447270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447271, 1, "5d348705b3e2c58a22b9451468ea5855bd640249d93b70f26f7fd1116cea9218")
