-- Lua provided by RyzenAPI
-- Game: Game: hololive ERROR

-- MAIN APPLICATION
addappid(2062550)
-- Game: addappid(2062550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062551, 1, "c2153771dd7da401513ec78e43ed2465345071864cc0ee35771dfd9824ed1064")
