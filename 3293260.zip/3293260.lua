-- Lua provided by SkyAPI 
-- Game: AppID 3293260
addappid(3293260)
addappid(3293261, 1, "2ae10ca475da07718687c9d3078d27cd93464eb539d53ed314d60fc261929fd7")
