-- Lua provided by RyzenAPI
-- Game: 3293260

-- MAIN APPLICATION
addappid(3293260)
-- Game: addappid(3293260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293261, 1, "2ae10ca475da07718687c9d3078d27cd93464eb539d53ed314d60fc261929fd7")
