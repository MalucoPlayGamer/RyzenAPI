-- Lua provided by RyzenAPI 
-- Game: Elsword
addappid(237310)
addappid(237311, 1, "dbf5ed23a0dc276193e06728915647e08ab8fcddb1e6ff4777ac5b5113550501")
addappid(237312, 1, "2aba55b75f92345d9c0d89700839ea28559592670e56455aeaa76fb536ef401e")
addappid(237313, 1, "4eff99b650a38da94b13aa8a47cbccda30a77df64b82ef22efeacd1767778a62")
