-- Lua provided by RyzenAPI
-- Game: Elsword

-- MAIN APPLICATION
addappid(237310)

-- MAIN APP DEPOTS / PACKAGES
addappid(237311, 1, "dbf5ed23a0dc276193e06728915647e08ab8fcddb1e6ff4777ac5b5113550501")
addappid(237312, 1, "2aba55b75f92345d9c0d89700839ea28559592670e56455aeaa76fb536ef401e")
addappid(237313, 1, "4eff99b650a38da94b13aa8a47cbccda30a77df64b82ef22efeacd1767778a62")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(257280)
addappid(257281)
addappid(304490)
addappid(304491)
addappid(308340)
addappid(308341)
addappid(357060)
addappid(357660)
addappid(383310)
addappid(414480)
addappid(632610)
addappid(632611)
