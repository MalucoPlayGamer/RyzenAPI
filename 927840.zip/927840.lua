-- Lua provided by RyzenAPI
-- Game: 927840

-- MAIN APPLICATION
addappid(927840)
-- Game: addappid(927840)

-- MAIN APP DEPOTS / PACKAGES
addappid(927841, 1, "75afa4752695f7b33de11d167f0a142b1a70bc1a99ae35ae2ed37311bd9328e5")
