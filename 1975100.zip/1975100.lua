-- Lua provided by RyzenAPI
-- Game: Playback Trauma®: In Sickness

-- MAIN APPLICATION
addappid(1975100)
addappid(1975103)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975102,0,"12ee0c6c02fb8905d9445600a0f703e1c86d43e1d59cb8acd8f6aed6810c45b8")

