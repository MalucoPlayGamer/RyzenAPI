-- Lua provided by RyzenAPI
-- Game: addappid(892393)

-- MAIN APPLICATION
addappid(892393)

-- MAIN APP DEPOTS / PACKAGES
addappid(892393,0,"ed546f4dca38a532e2f8991a3243dabe0c5a6309b60b472a1cbbdedc2759c67e")
