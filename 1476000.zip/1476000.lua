-- Lua provided by RyzenAPI
-- Game: Game: Wreak The Havoc

-- MAIN APPLICATION
addappid(1476000)
-- Game: addappid(1476000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476001, 1, "57c03955e5f620ca27f896621cbdb7435f2f6e25e5818c5160d127750469d6a8")
