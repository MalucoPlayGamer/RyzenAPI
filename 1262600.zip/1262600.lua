-- Lua provided by RyzenAPI
-- Game: Need for Speed™ Rivals

-- MAIN APPLICATION
addappid(1262600)
addappid(1282190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262601, 1, "06ad2d6af7ede873e68355884ecfc017ab0a1c0c4029cda7950623515b32fe43")
addappid(1262602, 1, "11f43873d388e719105033741cb25dd721a7ad7b8246f2c37710d06ad23ab9c6")
addappid(1262603, 1, "7c2dc457b408455021bb4c19cbf2c66be8ee8bfcd7bc019f0fbce9e1fd16e0fe")
addappid(1262604, 1, "dc183b8fc12757cf155d31fa6e827806b7fa66f09e922868101a7125fbda8963")
addappid(1262605, 1, "6a2f9425a20e0175eab12ce8fefd9ffd7334c0e9c3844291f3c116276cc8ad72")
addappid(1262606, 1, "86ec3c036ee077d83abe015feea6de3776a9f9179a53e781d7efdf0a6607a61f")
addappid(1262607, 1, "87cca7c9e9998273df73a105dd3ba81a4a60979607ec0eeaedb720b9f99a00c2")
addappid(1262608, 1, "6c7061cc550ac6ceb0e81413062f861ed7c5746450b3224c5f2b24ddac9c52e8")
addappid(1262609, 1, "193e74821efb9f2a1ef30cf2d17ae451fcfa27bf357a19019f0ec12279d68e9f")
addappid(1282191, 1, "527d7dc9f4990c970f340a424115383f1fb74d6fc4d6651cd0eab5eca4a03628")
addappid(1282192, 1, "e7a83a1c4e34ee59b42030c557b0320f23130cfdc26a4c8450e2814acb9b8fce")
addappid(1282193, 1, "9d2162574361aa8a1c5bf66ff4e8754755cd78924666f3495fc800721c7c98c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1285330)
addappid(1285332)
addappid(1285333)
addappid(1285334)
addappid(1285335)
addappid(1285336)
addappid(1285337)
addappid(1285338)
addappid(1285339)
addappid(1285340)
addappid(1285341)
addappid(1285342)
addappid(1285343)
addappid(1285344)
