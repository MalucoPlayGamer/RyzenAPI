-- Lua provided by RyzenAPI
-- Game: Little Learning Machines

-- MAIN APPLICATION
addappid(1993710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993711, 1, "3a1a26c75717dd78b4c3c3bfca79e9a34dc00680b915669cdc90567868019dee")
addappid(1993712, 1, "a62b68b6db6d630d1ce763666330d36f8b9934114a7a81601c58086e78a75fd1")
