-- Lua provided by RyzenAPI
-- Game: addappid(995430)

-- MAIN APPLICATION
addappid(995430)
addappid(995431)

-- MAIN APP DEPOTS / PACKAGES
addappid(995432,0,"fc6a1ffd138922f2c152dd23cacf248f5008bb725d73792cf84a45c4a4a46045")
