-- Lua provided by RyzenAPI
-- Game: Game: Pight Demo

-- MAIN APPLICATION
addappid(2779090)
-- Game: addappid(2779090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779091, 1, "3e540636236d36fe86a0ba57f970db54694f806ca550c146e40d3e244cc8c58e")
