-- Lua provided by RyzenAPI
-- Game: Protect your planet

-- MAIN APPLICATION
addappid(730280)

-- MAIN APP DEPOTS / PACKAGES
addappid(730281, 1, "38dd66093e000dee74b1bc01cc04c53f2eaaaacfa8902b58c29a8e0bbf494def")
