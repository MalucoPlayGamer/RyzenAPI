-- Lua provided by RyzenAPI
-- Game: Ninja Outbreak

-- MAIN APPLICATION
addappid(453880)
-- Game: addappid(453880)

-- MAIN APP DEPOTS / PACKAGES
addappid(453881, 1, "b275bc7d8b6a51da38f572fadf83506a169d9be209081745a759db9723ffbe18")
addappid(453882, 1, "3466ffce27c6a5813d781bca9c423eb6674f283c9d7f30b32fd0ec496dae9090")
