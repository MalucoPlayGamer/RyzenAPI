-- Lua provided by RyzenAPI
-- Game: At the Summit of Mount Rojerya

-- MAIN APPLICATION
addappid(3753360)
-- Game: addappid(3753360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3753361, 1, "64194ea3ebd58fa667dfcf92172106ca77df19730badeeaad3be1a36764dd2cc")
