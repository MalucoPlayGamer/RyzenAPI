-- Lua provided by RyzenAPI
-- Game: The Bureau: XCOM Declassified

-- MAIN APPLICATION
addappid(65930)
addappid(228983)
addappid(228990)
addappid(229002)
addappid(229031)

-- MAIN APP DEPOTS / PACKAGES
addappid(65932,0,"d53cfed33a4a50c102b6c025da21f720775398b9d81984c4a603f8513fb2fa17")
addappid(65933,0,"364dbc62e94ec2f5646929ea358548bbf3b1494bb69876443c3a6e88da2c7767")
addappid(65934,0,"20772ddce14538241a1ab7e716f6c2b6431ce9d5970fdc66ecca0e860c63ce4f")
addappid(65935,0,"f597133b41598718c7a61d7b6fd65c39bb5850dd7542087faaacd234cb4e2c4b")
addappid(65936,0,"74563df1485db50708835bf478c3851ab417e0b9113b666002db3900b2c01349")
addappid(65937,0,"b9476726726aa5db658ee9cdea3b84c7cfd63aa924a01bd76b0a8fd224200484")
addappid(65938,0,"5e8c75f47846d841d6a0611cc7f811b6c78396b8120d9e211422ae1743042732")
addappid(66000,0,"0c64ff45fc5c394c84dc16a835deed0fd9c7d5427394435aa49aa7b76b9b93d9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(66001)
addappid(66002)
addappid(66003)
