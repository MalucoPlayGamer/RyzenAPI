-- Lua provided by RyzenAPI
-- Game: Midnight Survivors: Prologue

-- MAIN APPLICATION
addappid(2706570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706571, 1, "1167b7218a31d30de944e708c6653ec6072b2b3f3f003b4a780b404118a9048d")

