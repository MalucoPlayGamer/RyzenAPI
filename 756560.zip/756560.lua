-- Lua provided by RyzenAPI
-- Game: addappid(756560)

-- MAIN APPLICATION
addappid(756560)

-- MAIN APP DEPOTS / PACKAGES
addappid(756561, 1, "add08a493ff42ddb17eb44e692ad4565804512276c4e57203422d8f3925e77dc")
