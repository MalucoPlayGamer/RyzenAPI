-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles: Mutants in Manhattan

-- MAIN APPLICATION
addappid(338400)
addappid(395280)

-- MAIN APP DEPOTS / PACKAGES
addappid(338401, 1, "e485fd9f818cc0ca2db7820caf4e362a131720f04c6a75000fcb5f50274b17c6")
addappid(338402, 1, "e15104988d5ed448828ea3b9360205a1d600c71a22b230816c16b7d35375e505")
addappid(395281, 0, "085fb2b2f7da1df61c421525e1ffeb9b3703d2079f8a0b078d2ca4fd522a7b0d")
