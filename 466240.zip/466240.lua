-- Lua provided by RyzenAPI
-- Game: 466240

-- MAIN APPLICATION
addappid(466240)
-- Game: addappid(466240)

-- MAIN APP DEPOTS / PACKAGES
addappid(466241, 1, "ed74d1229d8ba721bc6c8d516b67ab68359002ba6161d5b4b6f9235869488039")
