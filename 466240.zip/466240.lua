-- Lua provided by RyzenAPI
-- Game: Deceit

-- MAIN APPLICATION
addappid(466240)
addappid(672840)
addappid(968390)
addappid(1587640)
addappid(1943210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(466241, 1, "ed74d1229d8ba721bc6c8d516b67ab68359002ba6161d5b4b6f9235869488039")
