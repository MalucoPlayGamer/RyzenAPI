-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin House Builder Pack

-- MAIN APPLICATION
addappid(2401981)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401981,0,"99ef17b79ca622fd05666e99cd8f33929f44c5af317610129b50833f22d2c0aa")
