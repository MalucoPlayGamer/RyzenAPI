-- Lua provided by RyzenAPI
-- Game: 1902850

-- MAIN APPLICATION
addappid(1902850)
-- Game: addappid(1902850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902851, 1, "37d28a0c949df7a3c8bc65f0c0f9062402cd761b503215317f7bdb3d0d8d5432")
