-- Lua provided by RyzenAPI
-- Game: AppID 1853780

-- MAIN APPLICATION
addappid(1853780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853781, 1, "efb1f9642022d3a4a8745f889dc821f85f41f483f0b6f315ec043c3ce7580202")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1874040)
addappid(2025980)
addappid(2292530)
addappid(3658400)
addappid(3658410)
addappid(3658420)
addappid(3658430)
addappid(3658440)
addappid(3658450)
