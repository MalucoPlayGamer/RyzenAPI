-- Lua provided by RyzenAPI
-- Game: addappid(2767460)

-- MAIN APPLICATION
addappid(2767460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622782,0,"dcd7b56d008ea66693e577eca77dc5f350d1231e233658395cbe1197b9bde658")
