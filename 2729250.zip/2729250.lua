-- Lua provided by RyzenAPI
-- Game: addappid(2729250)

-- MAIN APPLICATION
addappid(2729250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729251, 1, "a47c3089c92e3b29f291cdf4a8f2dec9f2d847ce6ae15c9fd0801e27589fa2e0")
