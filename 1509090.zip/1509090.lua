-- Lua provided by RyzenAPI
-- Game: Seek Girl Ⅷ

-- MAIN APPLICATION
addappid(1509090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1509091, 1, "1da379b649f60b094d55e5f9ce415ce29e772a70cc3dbb8cfcdd9184cb46d6eb")

