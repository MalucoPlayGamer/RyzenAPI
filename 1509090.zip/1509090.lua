-- Lua provided by RyzenAPI
-- Game: addappid(1509090)

-- MAIN APPLICATION
addappid(1509090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509091, 1, "1da379b649f60b094d55e5f9ce415ce29e772a70cc3dbb8cfcdd9184cb46d6eb")
