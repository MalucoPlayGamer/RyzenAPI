-- Lua provided by RyzenAPI
-- Game: addappid(1588870)

-- MAIN APPLICATION
addappid(1588870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588871, 1, "880724563e0915c83e4eeda81048cb53de7c422027f8fea4a63f1981964e5fe5")
