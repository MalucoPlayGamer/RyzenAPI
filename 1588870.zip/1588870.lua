-- Lua provided by RyzenAPI 
-- Game: iBLiS
addappid(1588870)
addappid(1588871, 1, "880724563e0915c83e4eeda81048cb53de7c422027f8fea4a63f1981964e5fe5")
