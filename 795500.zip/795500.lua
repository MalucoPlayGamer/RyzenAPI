-- Lua provided by RyzenAPI
-- Game: Harmless Skeleton

-- MAIN APPLICATION
addappid(795500)

-- MAIN APP DEPOTS / PACKAGES
addappid(795501, 1, "3c72a90c09348a237fcf1f2b92ff08701958f142b5b7fb010e009d57dcbb20d9")

