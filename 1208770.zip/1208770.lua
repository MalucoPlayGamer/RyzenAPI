-- Lua provided by RyzenAPI
-- Game: Game: Saber Fight VR

-- MAIN APPLICATION
addappid(1208770)
-- Game: addappid(1208770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208771, 1, "0e75531056d61c91d028f9b7422049057983b3f2c5ad11d4905eb8c7cd6bfc49")
