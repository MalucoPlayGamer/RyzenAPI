-- Lua provided by RyzenAPI 
-- Game: Platonic
addappid(1737760)
addappid(1737761, 1, "f84cde5f1455fd3755f6a9a8cca92e0ab1f77aede8a15f6f10aa8f232696b983")
