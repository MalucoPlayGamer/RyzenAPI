-- Lua provided by RyzenAPI
-- Game: Ultra Void

-- MAIN APPLICATION
addappid(2589050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589051,0,"bb1a7de8e0ccb4386a93b139f54f3fc4bac39edd9d3a1e3673e7e90c46504ccd")

