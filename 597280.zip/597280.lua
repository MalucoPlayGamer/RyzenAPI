-- Lua provided by RyzenAPI
-- Game: Witch Hunters: Stolen Beauty Collector's Edition

-- MAIN APPLICATION
addappid(597280)

-- MAIN APP DEPOTS / PACKAGES
addappid(597281,0,"cb7ba7e4956fd450776739596a9d3e2abd6e2205e328eb54a86d71bd58143da6")

