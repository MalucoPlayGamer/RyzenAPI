-- Lua provided by RyzenAPI
-- Game: addappid(1733110)

-- MAIN APPLICATION
addappid(1733110)
addappid(2885390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733111, 1, "2aefb5610aff8c017b461ec4f3da8d7a17a426b0d4ab6bf30df2bd99c391e208")
addappid(1733112, 1, "c8a5dfd8f65bf5c949c255c8fca8b013076e98f57ade13f59f7109a416664253")
