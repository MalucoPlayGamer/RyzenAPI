-- Lua provided by RyzenAPI
-- Game: addappid(1818310)

-- MAIN APPLICATION
addappid(1818310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818310,0,"dd3e63abe447fa1c00840eaa627f7b864843e0e7c4021ed87b7e689d37dff9d7")
