-- Lua provided by RyzenAPI
-- Game: 2214840

-- MAIN APPLICATION
addappid(2214840)
-- Game: addappid(2214840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214841, 1, "2794d21d1e827eacfa41bd5e2f73dc2cdffd6c79412204bf2104347c06f6f6ed")
