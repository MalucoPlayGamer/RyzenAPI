-- Lua provided by RyzenAPI
-- Game: 1883840

-- MAIN APPLICATION
addappid(1883840)
-- Game: addappid(1883840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883841, 1, "e6b9e470fd8346ad35ca676c6b3dda2db172a994309288f25511360053fcee1e")
