-- Lua provided by RyzenAPI
-- Game: Dark Hunting Ground

-- MAIN APPLICATION
addappid(2494810)
addappid(4538990)
addappid(4549580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494811, 1, "c9271a6ce186c8fc02dead2d0dd037292ac29ec10f10246b1e617431d52e2537")

