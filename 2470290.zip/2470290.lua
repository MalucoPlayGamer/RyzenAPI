-- Lua provided by RyzenAPI
-- Game: Brick Exorcist

-- MAIN APPLICATION
addappid(2470290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470291, 1, "aa02d6c1411537615dee0ce923ceb3486ea067b418c17ed317a386ab18506d3d")
