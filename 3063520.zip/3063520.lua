-- Lua provided by RyzenAPI 
-- Game: AppID 3063520
addappid(3063520)
addappid(3063521, 1, "d06cfd37a509592c6f54599bdedc319e4933a4f15391d5024ec96b63285ac30d")
addappid(3063522, 1, "cf7dec6f9c5422aa5ffa041a00bb3a1a6a2142165ae72de7d7d12922f17d3ac6")
