-- Lua provided by RyzenAPI
-- Game: Game: Futanari College - Episode 1 [18+] 🍓 🤓

-- MAIN APPLICATION
addappid(2696200)
-- Game: addappid(2696200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696201, 1, "0c667319cccaebe0ec20221df1ab1d99adedf178d488ff8354b7b46dae03622b")
