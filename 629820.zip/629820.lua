-- Lua provided by RyzenAPI
-- Game: 629820

-- MAIN APPLICATION
addappid(629820)
addappid(1611940)
-- Game: addappid(629820)

-- MAIN APP DEPOTS / PACKAGES
addappid(629821, 1, "177cc05630810840243d069011bd1956c1e0180b4d4d9eeb1c3be213e95dd167")
