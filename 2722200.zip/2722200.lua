-- Lua provided by RyzenAPI
-- Game: Sugar,sugar,sugarcoat

-- MAIN APPLICATION
addappid(2722200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722201, 1, "00c2336df2e74ad4c182c26c9e06b21b78da067926324f76ce2ac5814426287f")

