-- Lua provided by RyzenAPI
-- Game: addappid(297470)

-- MAIN APPLICATION
addappid(297470)

-- MAIN APP DEPOTS / PACKAGES
addappid(297471, 1, "5ad5770ec59542c8b6f6090f4547fa0bdc30e83dc0827cd517d7e0e043e52082")
