-- Lua provided by RyzenAPI
-- Game: Xsyon - Prelude

-- MAIN APPLICATION
addappid(297470)

-- MAIN APP DEPOTS / PACKAGES
addappid(297471, 1, "5ad5770ec59542c8b6f6090f4547fa0bdc30e83dc0827cd517d7e0e043e52082")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
