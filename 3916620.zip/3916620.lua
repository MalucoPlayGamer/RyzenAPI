-- Lua provided by RyzenAPI
-- Game: Idle Pixel Fantasy

-- MAIN APPLICATION
addappid(3916620)
