-- Lua provided by RyzenAPI
-- Game: Idle Pixel Fantasy

-- MAIN APPLICATION
addappid(3916620)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3916630)
addappid(3916640)
addappid(3916650)
addappid(4022060)
addappid(4061930)
addappid(4063730)
addappid(4090620)
addappid(4963940)
