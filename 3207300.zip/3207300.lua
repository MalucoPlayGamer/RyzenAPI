-- Lua provided by RyzenAPI
-- Game: addappid(3207300)

-- MAIN APPLICATION
addappid(3207300)
addappid(4078070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207301, 1, "cd723cc3c8b3cacba2d56e22b5ace0ee974d035085b2569b1c6cccf3c91c1c6c")
