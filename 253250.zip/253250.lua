-- Lua provided by RyzenAPI 
-- Game: Stonehearth
addappid(253250)
addappid(253251, 1, "bf0ada72328a5a01651a02ca317046fdf28a2c5ba702245214b346ddc951a88e")
addappid(253252, 1, "6962b77c04f2f4e710ab08cfa7eba04f4521d3f8f649c4965de1c804ce31b78d")
addappid(1003430, 0, "f1fda2ab65b70e5277ffa79e1293c3c4b8d69ac25c5b51427f7859907463f47c")
