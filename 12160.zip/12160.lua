-- Lua provided by RyzenAPI
-- Game: 12160

-- MAIN APPLICATION
addappid(12160)
-- Game: addappid(12160)

-- MAIN APP DEPOTS / PACKAGES
addappid(12161, 1, "e89229bdaf85f526520c196dd6816d04102a73a4ad3bf4c91998e54529ff7c2f")
