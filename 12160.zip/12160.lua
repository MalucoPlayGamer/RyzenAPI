-- Lua provided by SkyAPI 
-- Game: Midnight Club 2
addappid(12160)
addappid(12161, 1, "e89229bdaf85f526520c196dd6816d04102a73a4ad3bf4c91998e54529ff7c2f")
