-- Lua provided by RyzenAPI
-- Game: Elsinore

-- MAIN APPLICATION
addappid(512890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(512891, 1, "161fd883d5358badf3d10ab3411714bf4586be524703b54c865f9716186844be")
