-- Lua provided by RyzenAPI
-- Game: Game: AppID 512890

-- MAIN APPLICATION
addappid(512890)
-- Game: addappid(512890)

-- MAIN APP DEPOTS / PACKAGES
addappid(512891, 1, "161fd883d5358badf3d10ab3411714bf4586be524703b54c865f9716186844be")
