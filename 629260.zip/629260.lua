-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(629260)
-- Game: addappid(629260)

-- MAIN APP DEPOTS / PACKAGES
addappid(629262,0,"f8932261b89b06c1c3a3d25f7cb1e41f376c23d7b299fd3c454c465586c38198")
