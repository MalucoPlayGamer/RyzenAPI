-- 5015570's Lua and Manifest Created by Hubcap Manifest
-- Lumber Tycoon Island
-- Created: August 24, 2026 at 15:07:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5015570) -- Lumber Tycoon Island
-- MAIN APP DEPOTS
addappid(5015571, 1, "f0508a8a3d0a2eadedc0acb233cf171b2632dcf1e119055bb7c89edd62e04fdb") -- Depot 5015571
setManifestid(5015571, "5464724266424974230", 293218559)