-- Lua provided by RyzenAPI
-- Game: Lumber Tycoon Island

-- MAIN APPLICATION
addappid(5015570) -- Lumber Tycoon Island

-- MAIN APP DEPOTS / PACKAGES
addappid(5015571, 1, "f0508a8a3d0a2eadedc0acb233cf171b2632dcf1e119055bb7c89edd62e04fdb") -- Depot 5015571

