-- Lua provided by RyzenAPI
-- Game: BAN: The Prologue of GUCHA GUCHA

-- MAIN APPLICATION
addappid(2987540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987541, 1, "e5d4bb54e2baecf7da09db915f2640c2b332a90424da8f6d0feb14f659958496")

