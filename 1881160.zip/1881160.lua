-- Lua provided by RyzenAPI
-- Game: addappid(1881160)

-- MAIN APPLICATION
addappid(1881160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881161, 1, "9ddbfce93449478242fb08caeac412fed54223667cd97e161e02074c9fdee4b4")
