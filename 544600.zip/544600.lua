-- Lua provided by RyzenAPI
-- Game: Delicious - Emily's Christmas Carol

-- MAIN APPLICATION
addappid(544600)

-- MAIN APP DEPOTS / PACKAGES
addappid(544601, 1, "44b053b7fef1061bafcd9a1afdb163bd2d01be097fce98e7d7c9957f9672aa09")
addappid(554360, 0, "ef25f1258fe1551240a5ec1b46f363fd56f745c7e6c63cc6dd906cc4ad9bece9")
