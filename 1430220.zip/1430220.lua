-- Lua provided by RyzenAPI
-- Game: Game: BIOMORPH

-- MAIN APPLICATION
addappid(1430220)
-- Game: addappid(1430220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430221, 1, "741e4d6d777d69310452c5ebcca9eb68a88ff5b35f4b4998079af839d4f6f2f9")
