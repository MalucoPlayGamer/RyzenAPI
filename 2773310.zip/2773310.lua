-- Lua provided by SkyAPI 
-- Game: Dating Simulator 2025 Demo
addappid(2773310)
addappid(2773311, 1, "ea4555193d0b570f979f67f2d1007bfd9d4c1bdf92e5c51d98eb68ad10407b26")
