-- Lua provided by RyzenAPI
-- Game: Heroine Anthem Zero 2

-- MAIN APPLICATION
addappid(787850)
addappid(960210)
addappid(1019220)
addappid(1036020)
addappid(1036021)
addappid(1036022)
addappid(1038040)

-- MAIN APP DEPOTS / PACKAGES
addappid(787851,0,"944101793c6daada7db84031a37d763944da21e1c590e3241d2d678fac88d537")
addappid(787852,0,"adbb807bdd5f415f979c01eac1c5141b5953becf16d72bee61772845db219c30")
addappid(1038040,0,"56dae01fa93abc7d043e42eba8ebe4344cc4f7c05cae10cc149e73e106399e28")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
