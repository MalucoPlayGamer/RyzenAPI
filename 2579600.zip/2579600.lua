-- Lua provided by RyzenAPI
-- Game: Game: unparalleled

-- MAIN APPLICATION
addappid(2579600)
-- Game: addappid(2579600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579601, 1, "81fbf7a62287f2cd6f169560cefaacc6d899336dd118a368860562211a55d16b")
