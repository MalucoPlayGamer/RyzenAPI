-- Lua provided by RyzenAPI
-- Game: addappid(2391740)

-- MAIN APPLICATION
addappid(2391740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391741, 1, "d210bde1d13dbc8b6e527c94e5c378076a5cc685b33d8773f1a799db4a4fc8c4")
