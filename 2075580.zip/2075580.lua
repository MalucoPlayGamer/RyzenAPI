-- Lua provided by RyzenAPI
-- Game: Under A New Sun

-- MAIN APPLICATION
addappid(2075580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2075581, 1, "4e2907c1b708f00bfe4a2e01a8a13d8ea62b619cf5a3cd06f69163c60956464e")

