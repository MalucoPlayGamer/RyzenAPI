-- Lua provided by RyzenAPI
-- Game: 咒印链接 Playtest

-- MAIN APPLICATION
addappid(2675350)
-- Game: addappid(2675350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675351, 1, "774b402b6f027a48f32faaec90758e066968193d045ab4b5771f313e7400ce75")
