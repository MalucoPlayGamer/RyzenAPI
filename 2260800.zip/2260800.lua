-- Lua provided by RyzenAPI
-- Game: Game: nothing_matters

-- MAIN APPLICATION
addappid(2260800)
-- Game: addappid(2260800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260801, 1, "d649c5559132f906b1325d95f38d6b09f69d9da2cd96de3ad31cad0bd18c41a5")
