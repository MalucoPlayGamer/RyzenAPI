-- Lua provided by RyzenAPI
-- Game: Game: AppID 2091000

-- MAIN APPLICATION
addappid(2091000)
-- Game: addappid(2091000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091001, 1, "4f15521123caaa4b5092bff2a1cf03912f71d7443e1e4027e2ba9295b6ffdbde")
