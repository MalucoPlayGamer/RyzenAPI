-- Lua provided by RyzenAPI
-- Game: addappid(1340600)

-- MAIN APPLICATION
addappid(1340600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340601, 1, "21254ea95d073fb79cfae3c1272a814ff8eee9cd050f313b4829688dae725133")
