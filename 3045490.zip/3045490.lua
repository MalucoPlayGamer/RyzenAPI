-- Lua provided by RyzenAPI
-- Game: 前哨站3 Playtest

-- MAIN APPLICATION
addappid(3045490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3045491, 1, "958e4396704a99f6327fe628be323f3708b435ed0385d50b1be08c551492af50")

