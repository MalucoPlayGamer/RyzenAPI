-- Lua provided by RyzenAPI
-- Game: Game: Canon - Legend of the New Gods

-- MAIN APPLICATION
addappid(1257920)
-- Game: addappid(1257920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257921, 1, "ca147c646d4bbfb34777221bcece0d1b93a89708b3620ffc908088777697c842")
