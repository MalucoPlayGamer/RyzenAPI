-- Lua provided by RyzenAPI
-- Game: Spaceship Commander

-- MAIN APPLICATION
addappid(833180)

-- MAIN APP DEPOTS / PACKAGES
addappid(833181, 1, "668df6d050f3502039060331ef27e6b5c1e478c98a6be075f69ee17e9254278f")
