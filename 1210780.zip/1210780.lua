-- Lua provided by RyzenAPI
-- Game: Flatspace

-- MAIN APPLICATION
addappid(1210780)
addappid(2977720)
addappid(2977730)
addappid(2977740)
addappid(3524920)
addappid(4184600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1210781, 1, "f12a2e60d9a7acd42719bdd258ae3330d1d67859f949c4ea31a7c347153301b1")

