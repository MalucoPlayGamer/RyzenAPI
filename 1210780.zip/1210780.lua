-- Lua provided by SkyAPI 
-- Game: AppID 1210780
addappid(1210780)
addappid(1210781, 1, "f12a2e60d9a7acd42719bdd258ae3330d1d67859f949c4ea31a7c347153301b1")
addappid(2977720)
addappid(2977730)
addappid(2977740)
addappid(3524920)
