-- Lua provided by RyzenAPI
-- Game: AppID 1210780

-- MAIN APPLICATION
addappid(1210780)
addappid(2977720)
addappid(2977730)
addappid(2977740)
addappid(3524920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210781, 1, "f12a2e60d9a7acd42719bdd258ae3330d1d67859f949c4ea31a7c347153301b1")

