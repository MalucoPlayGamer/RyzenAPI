-- Lua provided by RyzenAPI
-- Game: TangramsVR

-- MAIN APPLICATION
addappid(700940)

-- MAIN APP DEPOTS / PACKAGES
addappid(700941, 1, "b8d36938fbc279a5f75064692eecb480f789763d059fcb29758967beb500e3d3")
