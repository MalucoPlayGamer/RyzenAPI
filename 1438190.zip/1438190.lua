-- Lua provided by RyzenAPI
-- Game: SHUT IN

-- MAIN APPLICATION
addappid(1438190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438191, 1, "2d7cfa2d1a32ff2a631773afe3175db6df22a58a093eb09908b5fbefae72a530")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
