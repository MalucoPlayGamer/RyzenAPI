-- Lua provided by RyzenAPI
-- Game: SHUT IN

-- MAIN APPLICATION
addappid(1438190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438191, 1, "2d7cfa2d1a32ff2a631773afe3175db6df22a58a093eb09908b5fbefae72a530")

