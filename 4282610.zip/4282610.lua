-- Lua provided by RyzenAPI
-- Game: Fantasy Ore Shop

-- MAIN APPLICATION
addappid(4282610) -- Fantasy Ore Shop

-- MAIN APP DEPOTS / PACKAGES
addappid(4282611, 1, "837620b37bbd410e21874610bb06e2cf815e21f3ab66791369865682f8b4d83f") -- Depot 4282611

