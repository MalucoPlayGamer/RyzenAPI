-- 4282610's Lua and Manifest Created by Hubcap Manifest
-- Fantasy Ore Shop
-- Created: August 24, 2026 at 11:00:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4282610) -- Fantasy Ore Shop
-- MAIN APP DEPOTS
addappid(4282611, 1, "837620b37bbd410e21874610bb06e2cf815e21f3ab66791369865682f8b4d83f") -- Depot 4282611
setManifestid(4282611, "9122946956693345476", 2168567254)