-- Lua provided by RyzenAPI
-- Game: Typical Nightmare

-- MAIN APPLICATION
addappid(822650)

-- MAIN APP DEPOTS / PACKAGES
addappid(822651,0,"dd33130b78fc1c2234f324f7be7b8dab4a1ee2a3174848492961a20bff4ff35a")

