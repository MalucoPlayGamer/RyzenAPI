-- Lua provided by RyzenAPI
-- Game: Howl of Iron

-- MAIN APPLICATION
addappid(2235790)
-- Game: addappid(2235790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235791, 1, "f1268ef211d35ce25856c2bc00017323b69348588ce66f442e7e89f6387c0122")
