-- Lua provided by RyzenAPI
-- Game: Game: Ultimate General: Gettysburg

-- MAIN APPLICATION
addappid(306660)
-- Game: addappid(306660)

-- MAIN APP DEPOTS / PACKAGES
addappid(306661, 1, "9c3481d081175c84e8dc298312197f8f877d284d5532711a06841a1e77521696")
addappid(306662, 1, "5e040946be05e931bbf940d03aa4e33fb6fa52f76659c065fe6531bb7b20c534")
addappid(306664, 1, "87d38b3b7e1657766b7b4ddba07113bb2daab827a163152865f327b9c3bcb46b")
