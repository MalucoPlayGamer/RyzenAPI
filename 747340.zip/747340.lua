-- Lua provided by RyzenAPI 
-- Game: Unforgiving - A Northern Hymn
addappid(747340)
addappid(747341, 1, "c04d94cbe0c5e2fd39a731488aa1b20f606c10836b1443929a8729cc38339a67")
addappid(747342, 1, "93c951133a35858aa52a13955abb4a87e64b03567c685e5030f1d5d180477c5c")
addappid(795650, 0, "0205534d228ca94fab57c3ac957a469fbff57048834be1c1d57c826729fb4be9")
