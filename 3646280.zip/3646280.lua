-- Lua provided by RyzenAPI
-- Game: World Alone: Dreampools

-- MAIN APPLICATION
addappid(3646280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3646281, 1, "ba9e30dba90e587331fb2f746b6d827fecef5455a0450c7955b811f9522ec0e5")
