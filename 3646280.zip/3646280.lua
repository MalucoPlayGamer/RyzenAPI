-- Lua provided by RyzenAPI
-- Game: World Alone: Dreampools

-- MAIN APPLICATION
addappid(3646280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3646281, 1, "ba9e30dba90e587331fb2f746b6d827fecef5455a0450c7955b811f9522ec0e5")

