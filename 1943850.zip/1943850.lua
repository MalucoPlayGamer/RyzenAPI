-- Lua provided by RyzenAPI
-- Game: Indecent Details - Find the Difference

-- MAIN APPLICATION
addappid(1943850)
addappid(1957140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943851, 1, "23679166a187dfd354377f86ddfaf254199bda0c6c73ef9db1a086a929995ad1")

