-- Lua provided by RyzenAPI
-- Game: addappid(2409430)

-- MAIN APPLICATION
addappid(2409430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409431, 1, "ba262d5e8aaf688c757adb9aae96d85ab53c9018697bfc74c389061666b1a114")
