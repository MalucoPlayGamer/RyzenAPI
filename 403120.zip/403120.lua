-- Lua provided by RyzenAPI
-- Game: THE GAME OF LIFE

-- MAIN APPLICATION
addappid(403120)

-- MAIN APP DEPOTS / PACKAGES
addappid(403121, 1, "bfd601d0b0984cb045e9f3c3e4417ccf4e89aecc7f98fcb86f4556d8fb61ed43")
