-- Lua provided by RyzenAPI 
-- Game: Walhall
addappid(781800)
addappid(781801, 1, "c404a4a5b0867bdd89f518e8e9d4211e155c14c1c7ab407d0ae66968d40c3935")
