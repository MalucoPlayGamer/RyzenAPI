-- Lua provided by RyzenAPI
-- Game: 781800

-- MAIN APPLICATION
addappid(781800)
-- Game: addappid(781800)

-- MAIN APP DEPOTS / PACKAGES
addappid(781801, 1, "c404a4a5b0867bdd89f518e8e9d4211e155c14c1c7ab407d0ae66968d40c3935")
