-- Lua provided by RyzenAPI
-- Game: Game: Astray

-- MAIN APPLICATION
addappid(329200)
-- Game: addappid(329200)

-- MAIN APP DEPOTS / PACKAGES
addappid(329201, 1, "21cd17c94eb12011a173647110038c54ab91cdc5624760a323ff4cafbaeb7e12")
