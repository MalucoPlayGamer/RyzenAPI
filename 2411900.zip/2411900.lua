-- Lua provided by RyzenAPI
-- Game: Little Kitty, Big City - Customizer Demo

-- MAIN APPLICATION
addappid(2411900)
-- Game: addappid(2411900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411901, 1, "f76f375085695245c834d4e5df67e3fbb899d099bb629f8607ed05e8c69e116d")
