-- Lua provided by RyzenAPI
-- Game: The Cloud Bazaar Demo

-- MAIN APPLICATION
addappid(2231470)
-- Game: addappid(2231470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231471, 1, "5750663528e915c605c846419d0a3a89216be9d2162da3874e9a3fd657aaed22")
