-- Lua provided by RyzenAPI
-- Game: Game: AppID 1176540

-- MAIN APPLICATION
addappid(1176540)
-- Game: addappid(1176540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176541, 1, "f2dec6a8df5566099cdf0bd7dac909d8b56715a76406a4f87712afacce7bb806")
