-- Lua provided by RyzenAPI
-- Game: addappid(448980)

-- MAIN APPLICATION
addappid(448980)

-- MAIN APP DEPOTS / PACKAGES
addappid(448981, 1, "793dda00b04bf93a7a49c0b84b1cb9a13d896728796cecc7a2bc75a4def90bd7")
