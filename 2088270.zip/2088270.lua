-- Lua provided by RyzenAPI
-- Game: My Sticker Book

-- MAIN APPLICATION
addappid(2088270)

