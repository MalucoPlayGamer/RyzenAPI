-- Lua provided by RyzenAPI
-- Game: Rotwood

-- MAIN APPLICATION
addappid(2015270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2015271, 1, "52e97957aab04bacd50fec8149cc4c447b6cfdf455482b37ab728cb7d14779fe")

