-- Lua provided by RyzenAPI 
-- Game: AppID 1983680
addappid(1983680)
addappid(1983681, 1, "6b1044f1eefada643faf3541dc0610647599a104a0f5ac51b986b0f02312f2d6")
