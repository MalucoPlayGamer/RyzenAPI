-- Lua provided by RyzenAPI
-- Game: Game: AppID 1983680

-- MAIN APPLICATION
addappid(1983680)
-- Game: addappid(1983680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983681, 1, "6b1044f1eefada643faf3541dc0610647599a104a0f5ac51b986b0f02312f2d6")
