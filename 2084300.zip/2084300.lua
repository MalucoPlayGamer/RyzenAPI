-- Lua provided by SkyAPI 
-- Game: Schism
addappid(2084300)
addappid(2084301, 1, "b4ba35d3a9cd18c6d426a592f909ab0587c4f2cd7f8e4617b1c2e5d7ad1f3435")
