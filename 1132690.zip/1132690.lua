-- Lua provided by RyzenAPI
-- Game: Knights of Messiah

-- MAIN APPLICATION
addappid(1132690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132691, 1, "0431048b88fc0ed9ba3be52d6bb26ee9208252cfff7427472a884578792f04c8")
addappid(1132692, 1, "ce8466b14ddd5167b81a4dcb67f7afa32c83d7b1f73b93eef7a15aa77b1b62f3")
addappid(1132693, 1, "3b8d9b304541464ca748dc2e54da35dbd6e7e43612a5ef0d2d903759c5831b66")
