-- Lua provided by RyzenAPI
-- Game: Champions of Anteria

-- MAIN APPLICATION
addappid(374520)
addappid(490350)
addappid(501520)
addappid(501521)
addappid(511210)
addappid(516060)
addappid(520560)
addappid(520561)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(374521, 1, "2899ca07eb506e37bfaef414cbbe1f86f229169e1b9ca6e8c0b5e0d853430c19")
addappid(374522, 1, "bcd671c2ab345feb8750199c46fccb654701c0858cb7b8fbb8d721f5423bc994")
addappid(374529, 1, "1b1046350a8a07a4a26857640ee51738811f4d97ef6bdfe25afb984f932bfb50")
addappid(455410, 0, "ad6d674b7b7de2b14d8c87dbbaa9181b8f2b9d153a89e887ef3a10d4d9eb57a1")
addappid(455411, 0, "d502a98f25629853a78eae00b2dd264704b09928a25e15a3cb195d148d9a8b0e")
addappid(455412, 0, "0c2e686e0ab21cb8fb17f0e7728ee85fe78caeb283c81565c445b94902160bb4")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

