-- Lua provided by RyzenAPI
-- Game: 2665040

-- MAIN APPLICATION
addappid(2665040)
-- Game: addappid(2665040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665041, 1, "d3d5ffb7fa7df18e4029139983fc8d3e589bb7f7671246c51e2fd6bdd43193d9")
