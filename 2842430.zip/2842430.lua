-- Lua provided by RyzenAPI 
-- Game: AppID 2842430
addappid(2842430)
addappid(2842431, 1, "32e34328a586075917b30adc7ddc91bcca16136a302196ef1676a2a0eb15770e")
