-- Lua provided by RyzenAPI
-- Game: Bouncy Goat Climb

-- MAIN APPLICATION
addappid(1541220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541221, 1, "c2435782750536894a54afe79f42d55d97c7a1a6f30667bfb922018eae013736")

