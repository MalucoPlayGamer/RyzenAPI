-- 2878390's Lua and Manifest Created by Hubcap Manifest
-- Conjurers
-- Created: August 15, 2026 at 03:15:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2878390, 1, "da9a4ccd84a880cb8d2f4d46453dd701441fa213757f96b3035fcf4ee8245748") -- Conjurers
-- MAIN APP DEPOTS
addappid(2878391, 1, "7fb07250041ba225e67637b3be3c2187b51f3ffaab64eb7aceb57c997d962a2b") -- Depot 2878391
setManifestid(2878391, "3428957471345726739", 324608773)