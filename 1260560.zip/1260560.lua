-- Lua provided by RyzenAPI
-- Game: AppID 1260560

-- MAIN APPLICATION
addappid(1260560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260561, 1, "1712bf7352817ecc19b49eaed6319cb5b3dbe402ddabf70899476dc0ab2b8086")

