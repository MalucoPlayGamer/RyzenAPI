-- Lua provided by RyzenAPI
-- Game: AppID 2395380

-- MAIN APPLICATION
addappid(2395380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395381, 1, "6047f06b76a0aeed63cd313d5ea8d36d0aaf114e73ffa5b2356eeef149dd506a")
