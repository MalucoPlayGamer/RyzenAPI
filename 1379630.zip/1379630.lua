-- Lua provided by RyzenAPI
-- Game: AppID 1379630

-- MAIN APPLICATION
addappid(1379630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379631, 1, "9f4f2e92b359375599df34a6b6b476a0b35b85a1aa28017a2c0f6e329b69e067")
addappid(1379633, 1, "a3cf098e90f877587c0a715f55c08aa0093399084762ada84d814ff360cf65d3")
addappid(1379634, 1, "96e34c27674839adf11c4cdeae218dcedcf23e5a3933fabe7aaa69a0439059c2")
addappid(1379635, 1, "dbd9d382cfae061210972e95f2cc6964c6247be4413997d88b39f827dd906adc")
addappid(1379636, 1, "a4e427c3bdc93d3410b2097401f660152c2a22c56311a5af2a7e6314f63ae87e")
addappid(1379637, 1, "a4e81fe33c9148cb7ab4c4b12e975af8cd66d68bd31ca2639a801fe68a40e9f0")
addappid(2180820, 0, "6b3dc0dcc54ae87b20e07ddbac01b268507e7c12253aa970f9d06318d27675dd")
addappid(2189060, 0, "10e138b4703ea87b89d7c91fb9f6d72f329c51088954e194a347caf04350111f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1508910)
addappid(2993200)
addappid(4509610)
