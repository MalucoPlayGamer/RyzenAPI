-- Lua provided by RyzenAPI
-- Game: 778400

-- MAIN APPLICATION
addappid(778400)
-- Game: addappid(778400)

-- MAIN APP DEPOTS / PACKAGES
addappid(778401, 1, "89de994ad629d4d6aa3f31abe5737417ace75005efc8df6db08d1183fa9dcf5c")
