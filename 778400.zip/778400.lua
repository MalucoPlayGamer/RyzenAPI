-- Lua provided by RyzenAPI
-- Game: Corpse Party: Sweet Sachiko's Hysteric Birthday Bash

-- MAIN APPLICATION
addappid(778400)

-- MAIN APP DEPOTS / PACKAGES
addappid(778401, 1, "89de994ad629d4d6aa3f31abe5737417ace75005efc8df6db08d1183fa9dcf5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
