-- Lua provided by RyzenAPI
-- Game: Galaxy Girls

-- MAIN APPLICATION
addappid(560250)

-- MAIN APP DEPOTS / PACKAGES
addappid(560251, 1, "582e366365c3215e1dc53e18a015a11a9c6159fa1a0cc1fd379e9588e3ef49a9")
