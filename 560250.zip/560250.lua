-- Lua provided by RyzenAPI
-- Game: Galaxy Girls

-- MAIN APPLICATION
addappid(560250)
addappid(576610)
addappid(576611)
addappid(576612)
addappid(576613)
addappid(576614)
addappid(576615)
addappid(576616)
addappid(576617)
addappid(708180)

-- MAIN APP DEPOTS / PACKAGES
addappid(560251, 1, "582e366365c3215e1dc53e18a015a11a9c6159fa1a0cc1fd379e9588e3ef49a9")

