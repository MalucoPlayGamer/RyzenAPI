-- Lua provided by RyzenAPI 
-- Game: My Lovely Empress
addappid(2052990)
addappid(2052991, 1, "a8ff6c158dd0236827c774f59bd07fe26a91c75339392c9916b2362d3cd1365a")
