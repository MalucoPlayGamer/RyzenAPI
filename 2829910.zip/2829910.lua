-- Lua provided by RyzenAPI
-- Game: addappid(2829910)

-- MAIN APPLICATION
addappid(2829910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829911, 1, "90d76e9dedc2623d66cb9878c4f7333a9dd2f3fabcbff8f857ba809c6dd1acc4")
