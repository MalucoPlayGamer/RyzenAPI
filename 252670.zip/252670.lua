-- Lua provided by RyzenAPI
-- Game: Nihilumbra

-- MAIN APPLICATION
addappid(252670)

-- MAIN APP DEPOTS / PACKAGES
addappid(252671, 1, "93451a1f2412b47c53fa08c48a59504367abff6c63fcde0f4bfbdfe55041e488")
addappid(252672, 1, "b2302c865f6ba39c7c9c6bb8a9368a226f5301a44d84175bb4c06aa3ec1f8537")
addappid(252673, 1, "5d39a029dae78978f0590127ec7b008ee01f662165e43db09a8ea363110d7405")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
