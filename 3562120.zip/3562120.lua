-- Lua provided by RyzenAPI
-- Game: Magical Princess

-- MAIN APPLICATION
addappid(3562120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3562121,0,"ee547d3b84ed23ce194cad216a55f4fddebd7d676bb84f7a3bee62cdd0c8907c")

