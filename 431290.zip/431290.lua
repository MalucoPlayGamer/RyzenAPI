-- Lua provided by RyzenAPI
-- Game: addappid(431290)

-- MAIN APPLICATION
addappid(431290)

-- MAIN APP DEPOTS / PACKAGES
addappid(431291, 1, "02f5307465dfd690183071fde1cdd058153dd217d622c619863322e8dfd4e36d")
