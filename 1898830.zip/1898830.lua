-- Lua provided by RyzenAPI
-- Game: addappid(1898830)

-- MAIN APPLICATION
addappid(1898830)
addappid(1943350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898831, 1, "7ac7f151065d9e7c66c7bac622e5733f6ae3cce3511bf5a41c031bf38a36f338")
