-- Lua provided by RyzenAPI 
-- Game: AppID 698980
addappid(698980)
addappid(698981, 1, "cc53203965f9e0259626eb7d79017af3d22cf9c15a70d901edaa7fa7195a27a9")
