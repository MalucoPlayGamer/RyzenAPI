-- Lua provided by RyzenAPI
-- Game: Game: Car Parking

-- MAIN APPLICATION
addappid(2202880)
addappid(2209950)
-- Game: addappid(2202880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202881, 1, "c861987226246891b9a888eb917a10557c14b65fb0eb55b92d1b3495f9dc1d64")
