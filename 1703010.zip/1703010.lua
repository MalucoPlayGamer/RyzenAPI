-- Lua provided by RyzenAPI
-- Game: 1703010

-- MAIN APPLICATION
addappid(1703010)
-- Game: addappid(1703010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703011, 1, "9cba746ddd6e563716f7d07880835f7521dd5269230236ac6e19fa16c2efbf17")
