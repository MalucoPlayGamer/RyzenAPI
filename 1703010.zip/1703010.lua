-- Lua provided by RyzenAPI 
-- Game: Burning Brick Breaker
addappid(1703010)
addappid(1703011, 1, "9cba746ddd6e563716f7d07880835f7521dd5269230236ac6e19fa16c2efbf17")
