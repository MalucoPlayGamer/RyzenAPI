-- Lua provided by RyzenAPI
-- Game: Game: POG 7

-- MAIN APPLICATION
addappid(1890200)
-- Game: addappid(1890200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890201, 1, "25207534fa0f7b2a56f27b7938eaf5c833bc3569febf5075c684faa7483850d0")
