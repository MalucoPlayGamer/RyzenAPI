-- Lua provided by RyzenAPI
-- Game: Game: The Adventures of Capitano Navarro

-- MAIN APPLICATION
addappid(671810)
-- Game: addappid(671810)

-- MAIN APP DEPOTS / PACKAGES
addappid(671811, 1, "374611248a27baab8796b504bc1904c906e33959ff2601ec821e03cdf7f90775")
addappid(671812, 1, "bfe5c3db6d73fdbaf7375574b622cb316b8e18dd9a9929467cb8ecf093941735")
addappid(671813, 1, "64168cd5ec4138f8c4ebafbcafa8c0f4788697e86a9d955770acdb73fc4605a5")
