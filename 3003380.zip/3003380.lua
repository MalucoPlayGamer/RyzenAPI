-- Lua provided by RyzenAPI
-- Game: FROM ASHES, BLOOM: Support the dev!

-- MAIN APPLICATION
addappid(3003380)
-- Game: addappid(3003380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003380,0,"6bdda343e9e13290d23f61ce035a3bad783c8e7591e06fdec4a5b840ef270b35")
