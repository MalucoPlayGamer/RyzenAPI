-- Lua provided by SkyAPI 
-- Game: AppID 2939870
addappid(2939870)
addappid(2939871, 1, "945b84f6f6fe45721204be2474115b61fffabb90989b84783f60af24eaf7f934")
