-- Lua provided by RyzenAPI
-- Game: Stifled - Echolocation Horror Mystery

-- MAIN APPLICATION
addappid(514830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(514831, 1, "97dbc978bd44868a307bd3263e3ba47c524608169bc544b2f9f7458b2e0560e6")
addappid(514832, 1, "e0778801cdbea1c487aaadec6b120953697a051da9e00f644a80256d57085848")

