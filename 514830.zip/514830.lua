-- Lua provided by RyzenAPI
-- Game: Stifled - Echolocation Horror Mystery

-- MAIN APPLICATION
addappid(514830)

-- MAIN APP DEPOTS / PACKAGES
addappid(514831, 1, "97dbc978bd44868a307bd3263e3ba47c524608169bc544b2f9f7458b2e0560e6")
addappid(514832, 1, "e0778801cdbea1c487aaadec6b120953697a051da9e00f644a80256d57085848")

