-- Lua provided by RyzenAPI
-- Game: AppID 55280

-- MAIN APPLICATION
addappid(55280)
-- Game: addappid(55280)

-- MAIN APP DEPOTS / PACKAGES
addappid(55281, 1, "c38387e2cc8bafea77f960b04d766a217c08098002caa5bb6e9d4efe7a67085e")
