-- Lua provided by RyzenAPI
-- Game: 2274860

-- MAIN APPLICATION
addappid(2274860)
-- Game: addappid(2274860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274861, 1, "53dbcf4ab895989a8fdf4f0086e6ccdbde434ae430fabc750a01336fe4b8f1c1")
