-- Lua provided by RyzenAPI
-- Game: E.Y.E - Dedicated Server

-- MAIN APPLICATION
addappid(91720)

-- MAIN APP DEPOTS / PACKAGES
addappid(91702,0,"41955555da2997d3627c741085ef6d5bbfde1b95138cb52dd3bc6119c9fe0fa8")

