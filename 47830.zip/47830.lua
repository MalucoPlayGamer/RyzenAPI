-- Lua provided by RyzenAPI
-- Game: Medal of Honor(TM) Multiplayer

-- MAIN APPLICATION
addappid(47830)

-- MAIN APP DEPOTS / PACKAGES
addappid(47831, 1, "25afaf0aa4f61af4252587bf60c20165d050c502701e27bae50043fdfce6f5dc")
addappid(47833, 1, "ab9753cfd708897c90a7ab03a91555aec5858d59ddee9e04d7035044d1700df1")
addappid(47834, 1, "b6509f4e154c8e3fc83ab9332f3445b609e6636378a631d3488a6a9dbaf14ccb")
addappid(47835, 1, "9234d7f43bcdb6ac8eb76d1e2b4fb495e37f4d49476c731b027f6f6f19e1eff3")
addappid(47836, 1, "261423c70d0c3fdd0d72866c0d5eb4297650dbb0eaf69e1d2657ded636f9eba9")
addappid(47838, 1, "a12e849827fea99d400590e016e25f83b2ab796687bbb70f2e9b563da18a5c4d")
addappid(47839, 1, "16d350e7534d81c9ff4d23bc157e82c8bf03994ecc329ce50bdfc6bfdbfb5f59")
addappid(47840, 1, "01a741d7be85d93c507a99d4e7cfa1be536025a50164f650e734c3118ef99ec6")
addappid(47841, 1, "daf5bd535484cfa1042218ecf8cdf45408c38498cbc45dfe2926a0cf4c7dcd4b")
