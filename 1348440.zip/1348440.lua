-- Lua provided by RyzenAPI
-- Game: AppID 1348440

-- MAIN APPLICATION
addappid(1348440)
-- Game: addappid(1348440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348441, 1, "3657f357aa8c892c94e07509c78724c2bcf36b19cd4c257fb7a0ded012b8a1f2")
