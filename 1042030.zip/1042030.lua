-- Lua provided by RyzenAPI 
-- Game: Nyasha Winter
addappid(1042030)
addappid(1042031, 1, "5d304353d2601ffb7b98b57c52566b9760f3ca1584198a95cf5170e0e8416ea2")
