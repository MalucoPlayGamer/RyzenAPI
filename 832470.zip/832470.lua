-- Lua provided by SkyAPI 
-- Game: Season Up
addappid(832470)
addappid(832471, 1, "2cc5fe50784adbf0e07ed3a956c95981055db4b6653263ec00f27a38659d8aed")
