-- Lua provided by RyzenAPI
-- Game: Season Up

-- MAIN APPLICATION
addappid(832470)

-- MAIN APP DEPOTS / PACKAGES
addappid(832471, 1, "2cc5fe50784adbf0e07ed3a956c95981055db4b6653263ec00f27a38659d8aed")
