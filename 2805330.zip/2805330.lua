-- Lua provided by RyzenAPI
-- Game: Aim Sex

-- MAIN APPLICATION
addappid(2805330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805331, 1, "79940457c5953d07f04d4820cc3b1756b778efd9fadeedda6fea87c2f9e57d45")

