-- Lua provided by RyzenAPI
-- Game: Ember Kingdom

-- MAIN APPLICATION
addappid(5065170) -- Ember Kingdom

-- MAIN APP DEPOTS / PACKAGES
addappid(5065171, 1, "9dcadcdedaa1c030b78dbc19774be0c4825f1046e6a629f99d506e49eb598383") -- Depot 5065171
