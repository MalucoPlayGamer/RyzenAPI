-- Lua provided by RyzenAPI
-- Game: Realities - glückauf!

-- MAIN APPLICATION
addappid(837160)
-- Game: addappid(837160)

-- MAIN APP DEPOTS / PACKAGES
addappid(837160,0,"950e9029661109f5868e01b3897cfe355d066b578689d57910bc25bde0246f16")
