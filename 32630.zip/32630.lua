-- Lua provided by RyzenAPI
-- Game: 32630

-- MAIN APPLICATION
addappid(32630)
-- Game: addappid(32630)

-- MAIN APP DEPOTS / PACKAGES
addappid(32631, 1, "dcf31e6cf10674e9e2a2d80bbc7df7ad63c4804af6889c21211403a4839df170")
