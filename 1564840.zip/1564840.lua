-- Lua provided by RyzenAPI
-- Game: 1564840

-- MAIN APPLICATION
addappid(1564840)
-- Game: addappid(1564840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564841, 1, "551efc3eae3ef8b21f62feac63bce428b5218822a6149b96061989d51f1f0472")
