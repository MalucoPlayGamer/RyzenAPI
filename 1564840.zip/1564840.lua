-- Lua provided by RyzenAPI
-- Game: Dreams Of Adventure

-- MAIN APPLICATION
addappid(1564840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1564841, 1, "551efc3eae3ef8b21f62feac63bce428b5218822a6149b96061989d51f1f0472")

