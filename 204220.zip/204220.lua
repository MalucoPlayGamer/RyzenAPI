-- Lua provided by RyzenAPI
-- Game: Snapshot

-- MAIN APPLICATION
addappid(204220)

-- MAIN APP DEPOTS / PACKAGES
addappid(204221, 1, "47d544d948be9491de9f4364464eafb0d8e457390c8781bdc2149db8a483a3f2")
addappid(204222, 1, "14843404c1be71613aba4ebe245554e786864f1ba9ddbca4961ae9d7686a1c6b")
addappid(219380, 0, "749880ecf32a1cf88ffb7ebae2b179c5421f958b7b29fe0bf79d17ce4a0c4ac6")
addappid(219381, 1, "bf20591f390af7a3750ccda9faf310c227eb05a9a07c4715f734b51d46955dfc")
