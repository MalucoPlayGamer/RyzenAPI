-- Lua provided by RyzenAPI
-- Game: Anomaly 2 Soundtrack

-- MAIN APPLICATION
addappid(237780)
addappid(237781)

-- MAIN APP DEPOTS / PACKAGES
addappid(237780,0,"66dd269af7bfaab1f62695b2176c8bd538339bfc927ac93ad66be4703676615e")

