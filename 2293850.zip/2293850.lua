-- Lua provided by SkyAPI 
-- Game: Hole Dweller
addappid(2293850)
addappid(2293851, 1, "f9e679dca57cb24f70292b1dae8927e8e131a584308446c21aaa09f2ee27330a")
