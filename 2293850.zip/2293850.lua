-- Lua provided by RyzenAPI
-- Game: addappid(2293850)

-- MAIN APPLICATION
addappid(2293850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293851, 1, "f9e679dca57cb24f70292b1dae8927e8e131a584308446c21aaa09f2ee27330a")
