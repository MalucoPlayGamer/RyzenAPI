-- Lua provided by RyzenAPI
-- Game: Hole Dweller

-- MAIN APPLICATION
addappid(2293850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2293851, 1, "f9e679dca57cb24f70292b1dae8927e8e131a584308446c21aaa09f2ee27330a")

