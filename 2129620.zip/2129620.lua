-- Lua provided by RyzenAPI
-- Game: Pixel Cup Soccer - Ultimate Edition Demo

-- MAIN APPLICATION
addappid(2129620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129621, 1, "797395b074293d754fc8a8008888bbc51fdd23b078f8395b65f0fc3115ec57d0")

