-- Lua provided by RyzenAPI
-- Game: 3495780

-- MAIN APPLICATION
addappid(3495780)
-- Game: addappid(3495780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495780,0,"fcda5130bdc8a1086dd591a1cd69aecdb9005062db06fb55351d51d0e840ad81")
