-- Lua provided by RyzenAPI
-- Game: Game: Mystery Case Files: Huntsville™

-- MAIN APPLICATION
addappid(50960)
-- Game: addappid(50960)

-- MAIN APP DEPOTS / PACKAGES
addappid(50961, 1, "80196ed85f406f73126f17e6a9be4db2510a2bb798a0b6fd0c818dec167a9a7e")
