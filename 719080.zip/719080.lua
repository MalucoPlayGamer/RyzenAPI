-- Lua provided by SkyAPI 
-- Game: AppID 719080
addappid(719080)
addappid(719081, 1, "c5b421ccc400524ccdaf14cada799aac870fd97f0353df86ce283e6c21837bc0")
addappid(719083, 1, "ff2a2af3496352bee497c74a6a3ec84beda4cfbf2c90338fc17edee9d5912dff")
addappid(719084, 1, "4eabc7cab674ccb8d05284b34858694512ccd476033ff9942a424c3dcd972452")
