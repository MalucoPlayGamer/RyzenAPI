-- Lua provided by RyzenAPI
-- Game: Biomass

-- MAIN APPLICATION
addappid(1138960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138961, 1, "002a462003fe3bba3afcc247bcb33ca46ecf2d8048d5c781a356a0257633a6c3")
addappid(1138962, 1, "0c33d49bf42b01b4242ac82ba1e3a0cbc2852ba4d32403d5b27abd66c64ed360")
