-- Lua provided by RyzenAPI
-- Game: Game: The Sorceress

-- MAIN APPLICATION
addappid(579330)
-- Game: addappid(579330)

-- MAIN APP DEPOTS / PACKAGES
addappid(579331, 1, "88bb67263bc2da6f2725fda063ba1baacb4eb6b41c94d8cd293b9a99cc3e9ba3")
