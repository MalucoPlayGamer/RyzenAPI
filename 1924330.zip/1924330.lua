-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1924330)
-- Game: addappid(1924330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924330,0,"3223533790dfc3368576c4b4f4c53998d35e5b61fc0c3cff51f4eb68415beef0")
