-- Lua provided by RyzenAPI
-- Game: Tails of Iron 2: Whiskers of Winter - Prologue

-- MAIN APPLICATION
addappid(2848790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848791, 1, "b98b071e8a42f19f68f612accfa4e18c361d0444104148664d50cb02a3e13ce0")
