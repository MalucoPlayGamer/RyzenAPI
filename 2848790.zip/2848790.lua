-- Lua provided by RyzenAPI 
-- Game: AppID 2848790
addappid(2848790)
addappid(2848791, 1, "b98b071e8a42f19f68f612accfa4e18c361d0444104148664d50cb02a3e13ce0")
