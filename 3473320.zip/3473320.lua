-- Lua provided by RyzenAPI
-- Game: 3473320

-- MAIN APPLICATION
addappid(3473320)
-- Game: addappid(3473320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473321, 1, "ec3195272706a04d6bc51d55c466c17f46bd14eb0659111ed953d902f7df8b35")
