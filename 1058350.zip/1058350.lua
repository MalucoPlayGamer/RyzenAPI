-- Lua provided by RyzenAPI
-- Game: addappid(1058350)

-- MAIN APPLICATION
addappid(1058350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058351, 1, "d3ec2cf9d6ada6d4fb779d086bc309ba292c3f733855661a36222a8488594c9c")
