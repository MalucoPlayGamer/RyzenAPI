-- Lua provided by RyzenAPI
-- Game: Toy Keeper

-- MAIN APPLICATION
addappid(4867330)

-- MAIN APP DEPOTS / PACKAGES
addappid(4867331,0,"3a323b32c598df0251a0bb34f03265d2b272f52a30d8db78ee67110094ca0a0a")

