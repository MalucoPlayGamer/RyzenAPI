-- Lua provided by RyzenAPI
-- Game: 3176020

-- MAIN APPLICATION
addappid(3176020)
-- Game: addappid(3176020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176021, 1, "7da1c947d20a8d1b12b1626c59fa14a093d94e3e0383a06a7583ad3d1407d20b")
