-- Lua provided by RyzenAPI
-- Game: A Journey Through Valhalla

-- MAIN APPLICATION
addappid(763550)

-- MAIN APP DEPOTS / PACKAGES
addappid(763551,0,"7667fcf3df95a11928a857717519b3ed2984a714984f25872bc0163af5e021fa")

