-- Lua provided by RyzenAPI
-- Game: A Journey Through Valhalla

-- MAIN APPLICATION
addappid(763550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(763551,0,"7667fcf3df95a11928a857717519b3ed2984a714984f25872bc0163af5e021fa")

