-- Lua provided by RyzenAPI
-- Game: Game: AppID 2153440

-- MAIN APPLICATION
addappid(2153440)
-- Game: addappid(2153440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153441, 1, "965399baa6688b34f487c92aa99ba35a69e432515d937d7d56b315a96ab24073")
