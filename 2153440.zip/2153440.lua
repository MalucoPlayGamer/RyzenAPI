-- Lua provided by SkyAPI 
-- Game: AppID 2153440
addappid(2153440)
addappid(2153441, 1, "965399baa6688b34f487c92aa99ba35a69e432515d937d7d56b315a96ab24073")
