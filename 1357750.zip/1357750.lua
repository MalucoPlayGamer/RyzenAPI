-- Lua provided by RyzenAPI 
-- Game: Box Factory
addappid(1357750)
addappid(1357751, 1, "dec0e97102c3da4c22a38eadde7fbe5483517809cb202578396531b282fa38aa")
