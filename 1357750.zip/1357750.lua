-- Lua provided by RyzenAPI
-- Game: Game: Box Factory

-- MAIN APPLICATION
addappid(1357750)
-- Game: addappid(1357750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357751, 1, "dec0e97102c3da4c22a38eadde7fbe5483517809cb202578396531b282fa38aa")
