-- Lua provided by RyzenAPI
-- Game: Game: Blade-Shift Rage

-- MAIN APPLICATION
addappid(2123450)
-- Game: addappid(2123450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123451, 1, "d2b19f604153dc81c739794f596ac2adede06319cc9776dd913cc404817b8493")
