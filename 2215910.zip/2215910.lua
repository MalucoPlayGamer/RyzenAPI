-- Lua provided by RyzenAPI
-- Game: MetaBall - Multiplayer Basketball

-- MAIN APPLICATION
addappid(2215910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215911, 1, "7b27bb57f5459a63548fc50071ed86a6746e9691227de3677a843ce6976bbaf2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2582830)
addappid(2582840)
addappid(2853900)
addappid(2853910)
addappid(2853920)
addappid(2920310)
addappid(3009670)
addappid(3048460)
addappid(3048470)
addappid(3196250)
addappid(3264770)
addappid(3324510)
addappid(3384080)
addappid(3472940)
addappid(3527440)
addappid(3622270)
addappid(3745220)
addappid(3873030)
