-- Lua provided by RyzenAPI
-- Game: MetaBall - Multiplayer Basketball

-- MAIN APPLICATION
addappid(2215910)
-- Game: addappid(2215910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215911, 1, "7b27bb57f5459a63548fc50071ed86a6746e9691227de3677a843ce6976bbaf2")
