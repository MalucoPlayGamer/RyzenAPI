-- Lua provided by SkyAPI 
-- Game: Before Meteor: FINAL FANTASY XIV Original Soundtrack
addappid(3372220)
addappid(3372221, 1, "be64eda4f2dc8f9b44b54e3bf49be5687cbf0079ff96b70b985c1045551c460f")
