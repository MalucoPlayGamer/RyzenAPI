-- Lua provided by RyzenAPI
-- Game: Game: Syrian Warfare: Battlefields

-- MAIN APPLICATION
addappid(938490)
-- Game: addappid(938490)

-- MAIN APP DEPOTS / PACKAGES
addappid(938491, 1, "48e8cff2f0a3f4caa671cd0ad4e4cfc3f4316fb72209e6bd144a8ca835300ac7")
addappid(938492, 1, "b5134e140f209cbb73e0237b5a781e2d209ec484ba399adccd5c34c186b7c57b")
addappid(938493, 1, "eac69f2e302df963e12dd445ec6ecd4186cefe4767f9a275eaf0ba6c46bda994")
addappid(938494, 1, "c9865333d006430a6e61d772ba5ec1a20276915faa89d9b881394a46e6069b9a")
addappid(938495, 1, "413c975b996cca76a18dda6aa216bfc6322272d94d1b01c3a2737caeafe00840")
