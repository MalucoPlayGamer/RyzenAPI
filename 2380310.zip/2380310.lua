-- Lua provided by RyzenAPI
-- Game: Living Cell

-- MAIN APPLICATION
addappid(2380310)
-- Game: addappid(2380310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380311, 1, "cad31d7ee36d89608222e1cb60ac982068a768c93b51a132ffa27b09183d32fa")
