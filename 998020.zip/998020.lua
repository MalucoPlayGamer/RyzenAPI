-- Lua provided by RyzenAPI
-- Game: AppID 998020

-- MAIN APPLICATION
addappid(998020)

-- MAIN APP DEPOTS / PACKAGES
addappid(998021, 1, "f699ba47318635b1278dd8ee97022a91dc3a883a8a74dc4fca71cc6d745e1e63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
