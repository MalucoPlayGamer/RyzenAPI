-- Lua provided by SkyAPI 
-- Game: AppID 998020
addappid(998020)
addappid(998021, 1, "f699ba47318635b1278dd8ee97022a91dc3a883a8a74dc4fca71cc6d745e1e63")
