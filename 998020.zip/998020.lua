-- Lua provided by RyzenAPI
-- Game: AppID 998020

-- MAIN APPLICATION
addappid(998020)

-- MAIN APP DEPOTS / PACKAGES
addappid(998021, 1, "f699ba47318635b1278dd8ee97022a91dc3a883a8a74dc4fca71cc6d745e1e63")

