-- Lua provided by RyzenAPI
-- Game: 635060

-- MAIN APPLICATION
addappid(635060)
-- Game: addappid(635060)

-- MAIN APP DEPOTS / PACKAGES
addappid(635061, 1, "04496738b0590bbdf23ddddfdd5083ffef66cc0596cab0aaf2ca3f3aa1315e1f")
