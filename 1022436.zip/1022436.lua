-- Lua provided by RyzenAPI
-- Game: 1022436

-- MAIN APPLICATION
addappid(1022436)
-- Game: addappid(1022436)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022436,0,"6133ff2d76fc7ca0f45be76f32cc37fde71d9edc9236fe23b136ad4cf21c1db2")
