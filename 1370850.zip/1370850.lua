-- Lua provided by RyzenAPI
-- Game: Elasto Mania II

-- MAIN APPLICATION
addappid(1370850)
-- Game: addappid(1370850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370851, 1, "b3b0d01fbd0691c6fd698c1562fa0d9f2407f485bb0f9cd53deec06ad7fcc120")
