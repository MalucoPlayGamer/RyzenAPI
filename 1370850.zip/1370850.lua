-- Lua provided by RyzenAPI
-- Game: Elasto Mania II

-- MAIN APPLICATION
addappid(1370850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370851, 1, "b3b0d01fbd0691c6fd698c1562fa0d9f2407f485bb0f9cd53deec06ad7fcc120")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
