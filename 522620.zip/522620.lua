-- Lua provided by RyzenAPI
-- Game: Lost Castle: Official Soundtrack

-- MAIN APPLICATION
addappid(522620)

-- MAIN APP DEPOTS / PACKAGES
addappid(522620,0,"e48af5bd85a456ed972c60600ca9b598f1c1bad449e4451938bfc839c716d297")

