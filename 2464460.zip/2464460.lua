-- Lua provided by RyzenAPI
-- Game: Game: Portal Fantasy

-- MAIN APPLICATION
addappid(2464460)
addappid(3618180)
-- Game: addappid(2464460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464461, 1, "8178ef97c27d0a52cbe414ab214b384daf80ff66e19bd9609b24ea43f0964af6")
