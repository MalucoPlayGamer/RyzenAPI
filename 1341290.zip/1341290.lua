-- Lua provided by RyzenAPI
-- Game: We Were Here Forever

-- MAIN APPLICATION
addappid(1341290)
-- Game: addappid(1341290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341291, 1, "6919442117752f5bbe379976ac0d512006cf51b75a6ce2ffa4ebc9cbaaa90d09")
addappid(1986350, 0, "eb6b5158e244920df606c86053c725afdd5560565beb83f6d9afaf7877951e92")
