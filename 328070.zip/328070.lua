-- Lua provided by RyzenAPI
-- Game: addappid(328070)

-- MAIN APPLICATION
addappid(328070)

-- MAIN APP DEPOTS / PACKAGES
addappid(328071, 1, "a7d739010e487de785fb834923350bdaa142ba11f12e3505ced2bcec59b7abc7")
