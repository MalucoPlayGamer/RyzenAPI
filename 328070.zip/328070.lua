-- Lua provided by RyzenAPI
-- Game: Reflex Arena

-- MAIN APPLICATION
addappid(328070)

-- MAIN APP DEPOTS / PACKAGES
addappid(328071, 1, "a7d739010e487de785fb834923350bdaa142ba11f12e3505ced2bcec59b7abc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
