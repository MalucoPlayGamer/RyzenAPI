-- Lua provided by RyzenAPI
-- Game: Olaguna Chronicles

-- MAIN APPLICATION
addappid(985650)

-- MAIN APP DEPOTS / PACKAGES
addappid(985651, 1, "be4a35f0f3409fba531c78e0fa765661c40d24cb009bd844f57399307dc96757")

