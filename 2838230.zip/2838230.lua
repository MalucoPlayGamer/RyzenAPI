-- Lua provided by RyzenAPI
-- Game: addappid(2838230)

-- MAIN APPLICATION
addappid(2838230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838230,0,"c68f7dc20691b6ea2293964acabe4f4d535cfe9f1d850389ffe05e800c7e2140")
