-- Lua provided by RyzenAPI
-- Game: Tuition Academia

-- MAIN APPLICATION
addappid(1880710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880711, 1, "5b249513562bf3ab57fe1a55672de7310d051e9c0c75680606229c68e5707f49")

