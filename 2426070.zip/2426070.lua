-- Lua provided by RyzenAPI
-- Game: 2426070

-- MAIN APPLICATION
addappid(2426070)
-- Game: addappid(2426070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426071, 1, "44879dc7e9d9dd0b154ee71edfa46d2f658da5658e730a085305813da95f330f")
