-- Lua provided by RyzenAPI
-- Game: addappid(508890)

-- MAIN APPLICATION
addappid(508890)

-- MAIN APP DEPOTS / PACKAGES
addappid(508891, 1, "bb2f2d4102626c8ec81ff7bffaed8b96ea7c60acfcc893e28cfbd94296c554bf")
