-- Lua provided by RyzenAPI
-- Game: A War of a Madman's Making

-- MAIN APPLICATION
addappid(1985710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985711, 1, "c46e5ae21f5094d512e82051907a7fceef31c7b851d14f3eb28108dc7aed5319")
