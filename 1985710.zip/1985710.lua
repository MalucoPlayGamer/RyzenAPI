-- Lua provided by RyzenAPI
-- Game: 1985710

-- MAIN APPLICATION
addappid(1985710)
-- Game: addappid(1985710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985711, 1, "c46e5ae21f5094d512e82051907a7fceef31c7b851d14f3eb28108dc7aed5319")
