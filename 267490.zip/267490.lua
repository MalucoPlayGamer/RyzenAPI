-- Lua provided by RyzenAPI
-- Game: Batman™: Arkham Origins Blackgate - Deluxe Edition

-- MAIN APPLICATION
addappid(267490)

-- MAIN APP DEPOTS / PACKAGES
addappid(267491, 1, "e52240acea700d02909d4f96f9b64d05b808152723a4a4487a212a013e6bc1d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
