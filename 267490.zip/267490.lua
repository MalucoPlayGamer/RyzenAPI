-- Lua provided by RyzenAPI 
-- Game: Batman™: Arkham Origins Blackgate - Deluxe Edition
addappid(267490)
addappid(267491, 1, "e52240acea700d02909d4f96f9b64d05b808152723a4a4487a212a013e6bc1d6")
