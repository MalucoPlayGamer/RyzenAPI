-- Lua provided by RyzenAPI
-- Game: addappid(2089250)

-- MAIN APPLICATION
addappid(2089250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089251, 1, "ece6b636ba50cb03de2a98a945cbb761e67d4dd21f7fc203ae1bd90b918dcbc1")
