-- Lua provided by RyzenAPI
-- Game: Badiya

-- MAIN APPLICATION
addappid(545050)

-- MAIN APP DEPOTS / PACKAGES
addappid(545051, 1, "8efe3e64cdd6caae36755cb650aec91eb297647377e438fc87e7e697308b331e")
