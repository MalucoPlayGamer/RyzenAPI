-- Lua provided by RyzenAPI
-- Game: Pizza Possum Demo

-- MAIN APPLICATION
addappid(2339810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339811, 1, "17f677ebb5d4a4ddbdf905b1dbb538f6d950e70f7179a3271de00342048320e3")
