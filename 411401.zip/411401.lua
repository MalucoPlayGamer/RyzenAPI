-- Lua provided by RyzenAPI
-- Game: 411401

-- MAIN APPLICATION
addappid(411401)
-- Game: addappid(411401)

-- MAIN APP DEPOTS / PACKAGES
addappid(411401,0,"04588f8d71be80d43109b7c0e787e49b668196bc0bad2e0e319c56330a0629ae")
