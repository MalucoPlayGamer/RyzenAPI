-- Lua provided by RyzenAPI
-- Game: The Adventures of HILLS

-- MAIN APPLICATION
addappid(2859100)
addappid(4829960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859101,0,"7fa574bb1980a40f65d0021ecc45ef99a0d3dd45aadf8bb5334ce12bc1c1d73b")
addappid(4829961,0,"4970b62f0f721269c9d3fd2d54ccaf1ca5e3b2eb3ace1facb9941c44ed13c0a3")

