-- Lua provided by RyzenAPI
-- Game: Diaper Quest 2055

-- MAIN APPLICATION
addappid(976830)
-- Game: addappid(976830)

-- MAIN APP DEPOTS / PACKAGES
addappid(976831, 1, "4cefc90ff06f69327f475878b9ead66873bbcd09e70dc1a94d1b8185dff162a1")
