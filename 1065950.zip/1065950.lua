-- Lua provided by RyzenAPI
-- Game: 1065950

-- MAIN APPLICATION
addappid(1065950)
-- Game: addappid(1065950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065951, 1, "fbe0122651450df352bd04a16bbacff6d742750be9c8178f62e2bbd3752aa916")
addappid(1065952, 1, "11c07245dc6bb7cfaf86c59eec1fa021e0c914080811ddeaba0e5c40d2bfc942")
addappid(1065953, 1, "53a5eb8450f18316663fff7687664c798b95bb1cfb06fea68bf071cb2bec5e5a")
