-- Lua provided by RyzenAPI
-- Game: Vaporwave Road VR

-- MAIN APPLICATION
addappid(1302510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302511, 1, "23b8aeed9271df322d0f6334481ea52a76bab3d954cb6958b22ff6ebdde875b8")
