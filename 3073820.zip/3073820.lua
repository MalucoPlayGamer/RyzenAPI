-- Lua provided by RyzenAPI
-- Game: Game: AppID 3073820

-- MAIN APPLICATION
addappid(3073820)
-- Game: addappid(3073820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073821, 1, "5995fafb61495cf4f0d3e7346e839e24c67699a8d0532177da37fba3177078ee")
