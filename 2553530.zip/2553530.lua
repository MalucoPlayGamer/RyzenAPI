-- Lua provided by RyzenAPI
-- Game: Super Spy Raccoon

-- MAIN APPLICATION
addappid(2553530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553531,0,"94eb96fdf8b62bd5e91a62efe8cc56458b60a27337fad33253c169562a194493")

