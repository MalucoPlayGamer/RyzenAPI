-- Lua provided by RyzenAPI
-- Game: Jessica's Plight

-- MAIN APPLICATION
addappid(3084750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084751, 1, "dc7c19406b3ec8560468628619e0f99a68ce771472e5216d9ca02aac8b5a6929")

