-- Lua provided by RyzenAPI
-- Game: One Person Story

-- MAIN APPLICATION
addappid(863430)

-- MAIN APP DEPOTS / PACKAGES
addappid(863431, 1, "079e54efaba42f202497852771ee88aa760a21c06698db9b621f945aa69ecd4b")
