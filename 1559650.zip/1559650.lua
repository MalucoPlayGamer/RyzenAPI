-- Lua provided by RyzenAPI
-- Game: 許願ReadyGo!

-- MAIN APPLICATION
addappid(1559650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559651, 1, "9d191fb89d79b8401e093b36783648f9cf9f8bc93335986ecbfbabb86afbb057")
