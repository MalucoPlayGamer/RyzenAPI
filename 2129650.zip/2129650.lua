-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2129650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129650,0,"1f8b309cefde8d8cff652af92442625e8ba110ea5e32262b8ee070efa9050e26")
