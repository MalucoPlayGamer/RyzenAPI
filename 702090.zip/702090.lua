-- Lua provided by RyzenAPI
-- Game: AppID 702090

-- MAIN APPLICATION
addappid(702090)
-- Game: addappid(702090)

-- MAIN APP DEPOTS / PACKAGES
addappid(702091, 1, "93b72bebc9eed7ce3e2ed8838f5eb476d8869c011a6bc96e5074d8fdc3db6e69")
addappid(702840, 0, "15b83b9a1db2a12b9cfc8d9f8d72814497d3d1949d18e6125c6466922f4d8f1b")
