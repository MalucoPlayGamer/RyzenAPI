-- Lua provided by RyzenAPI
-- Game: MotoGP™23

-- MAIN APPLICATION
addappid(2100160)
addappid(2312180)
addappid(2312200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2100161, 1, "563fa8605d09fdc45d932bcfdb5232513c26893dc2628ce77234bb3df8abc41c")

