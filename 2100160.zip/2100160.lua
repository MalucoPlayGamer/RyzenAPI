-- Lua provided by RyzenAPI
-- Game: MotoGP™23

-- MAIN APPLICATION
addappid(2100160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100161, 1, "563fa8605d09fdc45d932bcfdb5232513c26893dc2628ce77234bb3df8abc41c")

