-- Lua provided by RyzenAPI
-- Game: Shatter EVERYTHING

-- MAIN APPLICATION
addappid(791140)

-- MAIN APP DEPOTS / PACKAGES
addappid(791141, 1, "da6dbaa879aa38a13867d38e469dd9d8e8fbbcd0ae05fd2b4a9b11d77155a738")

