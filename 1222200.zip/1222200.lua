-- Lua provided by RyzenAPI
-- Game: UldreVoid

-- MAIN APPLICATION
addappid(1222200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222201, 1, "9dd67f2de9f079eff98630daf05dba8e9f975cffbe5385e01f2b004ed1e88cd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
