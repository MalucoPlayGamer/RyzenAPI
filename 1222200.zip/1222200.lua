-- Lua provided by SkyAPI 
-- Game: UldreVoid
addappid(1222200)
addappid(1222201, 1, "9dd67f2de9f079eff98630daf05dba8e9f975cffbe5385e01f2b004ed1e88cd7")
