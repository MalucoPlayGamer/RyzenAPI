-- Lua provided by RyzenAPI
-- Game: UldreVoid

-- MAIN APPLICATION
addappid(1222200)
-- Game: addappid(1222200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222201, 1, "9dd67f2de9f079eff98630daf05dba8e9f975cffbe5385e01f2b004ed1e88cd7")
