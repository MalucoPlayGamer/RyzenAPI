-- Lua provided by SkyAPI 
-- Game: Holdfast: Nations At War - Loyalist Upgrade
addappid(1243770)
addappid(1243771, 1, "889f1fb0c89f83e6b5940bd922810c574affb5f838d6cd81d85a1f3fcf6b25cb")
