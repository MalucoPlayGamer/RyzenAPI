-- Lua provided by RyzenAPI
-- Game: Omega Pilot

-- MAIN APPLICATION
addappid(1933050)
-- Game: addappid(1933050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933051, 1, "7ea5514f3e0b4be00c4a4c365239e6a59c95221b4393a127218dd20625589219")
