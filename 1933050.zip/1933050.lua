-- Lua provided by SkyAPI 
-- Game: Omega Pilot
addappid(1933050)
addappid(1933051, 1, "7ea5514f3e0b4be00c4a4c365239e6a59c95221b4393a127218dd20625589219")
