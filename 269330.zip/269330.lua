-- Lua provided by SkyAPI 
-- Game: Chronology
addappid(269330)
addappid(269331, 1, "bad73a4698ed474ae5c2721c7fb660ca8cf626035ba9d9380552e1959371bbb8")
