-- Lua provided by RyzenAPI
-- Game: addappid(1920480)

-- MAIN APPLICATION
addappid(1920480)
addappid(2787870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920481, 1, "4dea88c426d346744fcba6cbeb2b911ff4fc46c41cb1fd7ef7e6c1867b4449ea")
