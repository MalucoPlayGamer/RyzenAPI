-- Lua provided by RyzenAPI
-- Game: 2333820

-- MAIN APPLICATION
addappid(2333820)
-- Game: addappid(2333820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333825,0,"d9cb0c86ab40a7536b9e052135e6058c509eb221c07af17eebe3ce0d2fc7cba7")
