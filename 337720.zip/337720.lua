-- Lua provided by RyzenAPI
-- Game: 337720

-- MAIN APPLICATION
addappid(337720)
-- Game: addappid(337720)

-- MAIN APP DEPOTS / PACKAGES
addappid(337721, 1, "557e8d8decaa30886300b2ee51916da34f31c584e18e6f6e8c23db25b2d51b93")
