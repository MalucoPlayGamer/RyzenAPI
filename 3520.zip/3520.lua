-- Lua provided by RyzenAPI
-- Game: addappid(3520)

-- MAIN APPLICATION
addappid(3520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3521, 1, "ca44177face1d2966d4ae33e6a0dc1f34aa7294a59a53830f3294b88098c9874")
