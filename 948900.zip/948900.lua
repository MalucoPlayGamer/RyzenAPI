-- Lua provided by RyzenAPI
-- Game: AppID 948900

-- MAIN APPLICATION
addappid(948900)
-- Game: addappid(948900)

-- MAIN APP DEPOTS / PACKAGES
addappid(948901, 1, "8e85cf3cc83f91b4c04097dbd522e350f231cda756e865775c685091b5317569")
