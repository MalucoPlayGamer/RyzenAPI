-- Lua provided by SkyAPI 
-- Game: NewTaskbar
addappid(1653760)
addappid(1653761, 1, "f208c2ac8f1c5d0c63f19e18dd530c00caaa2d658218c961633a5f1826d0a5fa")
