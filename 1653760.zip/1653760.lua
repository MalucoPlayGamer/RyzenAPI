-- Lua provided by RyzenAPI
-- Game: NewTaskbar

-- MAIN APPLICATION
addappid(1653760)
-- Game: addappid(1653760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653761, 1, "f208c2ac8f1c5d0c63f19e18dd530c00caaa2d658218c961633a5f1826d0a5fa")
