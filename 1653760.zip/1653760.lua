-- Lua provided by RyzenAPI
-- Game: NewTaskbar

-- MAIN APPLICATION
addappid(1653760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653761, 1, "f208c2ac8f1c5d0c63f19e18dd530c00caaa2d658218c961633a5f1826d0a5fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
