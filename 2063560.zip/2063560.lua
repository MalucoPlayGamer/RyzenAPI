-- Lua provided by SkyAPI 
-- Game: Space Route
addappid(2063560)
addappid(2063561, 1, "0048b4e4428d4f2405358e3e2977e9af813cc5577327753efe0c01388b3f6f02")
