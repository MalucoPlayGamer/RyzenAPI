-- Lua provided by RyzenAPI
-- Game: Game: Space Route

-- MAIN APPLICATION
addappid(2063560)
-- Game: addappid(2063560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063561, 1, "0048b4e4428d4f2405358e3e2977e9af813cc5577327753efe0c01388b3f6f02")
