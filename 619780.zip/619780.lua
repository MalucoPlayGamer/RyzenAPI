-- Lua provided by RyzenAPI
-- Game: The Swords of Ditto: Mormo's Curse

-- MAIN APPLICATION
addappid(619780)

-- MAIN APP DEPOTS / PACKAGES
addappid(619781, 1, "65f53cee46e2bfb7449f06a650af2732f029dc6a508491d0456bca74ec8797b1")
addappid(619782, 1, "454007ce559dc915434fed97ad8e71b097d7676b8e520895d16b1948cc8354d6")
addappid(619783, 1, "72734cc4caf64e8324190b999ef4c3b27b7d4a5f43233adacabbdde9d6ecff48")
addappid(846860, 0, "141714a2aa6beaf310958f185e3231d76981beb2130d85a9f23c31d56bc9e975")
