-- Lua provided by RyzenAPI
-- Game: The Farmer Was Replaced

-- MAIN APPLICATION
addappid(2060160)
addappid(4521700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060162,0,"18be2e81f67839803b107115cde05b35e14fc9b9bb4b71bb9f21a79503cda2b6")

