-- Lua provided by RyzenAPI
-- Game: AppID 3264000

-- MAIN APPLICATION
addappid(3264000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264001, 1, "a8c432ccb816fc3de0bc92575d1db6f80653cb2551426f4f16d5efd5fca07caa")
