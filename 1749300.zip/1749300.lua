-- Lua provided by RyzenAPI
-- Game: Tails & Titties Hot Spring

-- MAIN APPLICATION
addappid(1749300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749301, 1, "a3eb9e757d0cf0d2ffbddfc8a0506951d694a566b90add0f956646552ea439a4")
addappid(1749302, 1, "81608487a39ab013f0796fbf43a1aa61f1f4d8ec16c749d4354119d01c7dafd4")
