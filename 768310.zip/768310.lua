-- Lua provided by RyzenAPI
-- Game: 768310

-- MAIN APPLICATION
addappid(768310)
-- Game: addappid(768310)

-- MAIN APP DEPOTS / PACKAGES
addappid(768311, 1, "38790c93832bf9a505fbe3fc474034ede02ebfd44bda0e0513c07ff6ac519408")
