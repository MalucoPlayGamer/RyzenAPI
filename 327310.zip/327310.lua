-- Lua provided by RyzenAPI
-- Game: The Marvellous Miss Take

-- MAIN APPLICATION
addappid(327310)

-- MAIN APP DEPOTS / PACKAGES
addappid(327311, 1, "bab96fc08d07da35567298d0f01dfd6714d6dc8303828585dd3884eb2ce708dc")
addappid(327312, 1, "6d49e6592a2b802547234a00448412230729217a911feeccdaeaf8cf3aceda0f")
