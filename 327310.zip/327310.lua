-- Lua provided by RyzenAPI
-- Game: The Marvellous Miss Take

-- MAIN APPLICATION
addappid(327310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(327311, 1, "bab96fc08d07da35567298d0f01dfd6714d6dc8303828585dd3884eb2ce708dc")
addappid(327312, 1, "6d49e6592a2b802547234a00448412230729217a911feeccdaeaf8cf3aceda0f")

