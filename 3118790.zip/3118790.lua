-- Lua provided by RyzenAPI
-- Game: addappid(3118790)

-- MAIN APPLICATION
addappid(3118790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118791, 1, "44d5a453036bf2f73adf8e0a3ff6bd1f62061bef829c3584f635e2d452ec9044")
