-- Lua provided by RyzenAPI 
-- Game: Caldera
addappid(2791950)
addappid(2791951, 1, "9185232db92d948d2afa10039fe366b8605b32944880225920df454ce95d2ec3")
