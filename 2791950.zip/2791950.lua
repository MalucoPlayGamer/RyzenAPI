-- Lua provided by RyzenAPI
-- Game: Caldera

-- MAIN APPLICATION
addappid(2791950)
-- Game: addappid(2791950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791951, 1, "9185232db92d948d2afa10039fe366b8605b32944880225920df454ce95d2ec3")
