-- Lua provided by RyzenAPI
-- Game: addappid(720670)

-- MAIN APPLICATION
addappid(720670)

-- MAIN APP DEPOTS / PACKAGES
addappid(720671, 1, "3b7e2fa8590f1f4bb3f9601dff003b84b69947a54be92f9d99c0d3dd39fd0342")
