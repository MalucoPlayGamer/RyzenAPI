-- Lua provided by RyzenAPI
-- Game: Déjà Drift

-- MAIN APPLICATION
addappid(1914390)
-- Game: addappid(1914390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914391, 1, "0c55a03d74cc84ae3f630f2c6ea3de476916e01be6e304d55d4261edaebcec2d")
addappid(1914392, 1, "3efa03774419330ce9176f52002fabdccbaeff984600099f6bf20ee5dcc81344")
addappid(1914393, 1, "76733f6ee774a0e28a35f709410a57cce22d6d615843803b727774a1ee15d438")
