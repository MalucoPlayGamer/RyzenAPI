-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(798540)

-- MAIN APP DEPOTS / PACKAGES
addappid(798540,0,"f2d0fbc465f9f5de6aa4123106369dccde6e646f37497de93c9bd1ace5a8f1fb")

