-- Lua provided by RyzenAPI
-- Game: Game: Magicite

-- MAIN APPLICATION
addappid(268750)
-- Game: addappid(268750)

-- MAIN APP DEPOTS / PACKAGES
addappid(268751, 1, "f4253e929a24e9070dc0c62d8187c393cc46066be4d85b9f69d9fcbf358e8ed6")
addappid(268752, 1, "f835697e556701451e089396c4377894108f84e5904b1da8b8a20c8f02f7fa93")
addappid(268753, 1, "5b802d0c6184afb3a6b06cf03a9382c59fe28f5f37e132a6dffd5f0c38e7ede8")
