-- Lua provided by RyzenAPI
-- Game: No Players Online Demo

-- MAIN APPLICATION
addappid(2856520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856521, 1, "36ecd4d744862d788a5760b6a12af9697648c94223dea349b5d8c6d26f95824e")
