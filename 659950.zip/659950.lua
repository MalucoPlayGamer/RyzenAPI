-- Lua provided by RyzenAPI
-- Game: Travel Riddles: Trip To Italy

-- MAIN APPLICATION
addappid(659950)

-- MAIN APP DEPOTS / PACKAGES
addappid(659951, 1, "982df32f45b1575fbc1115c33aa2e3582c75fdceae4c08a429159366be29da4a")
