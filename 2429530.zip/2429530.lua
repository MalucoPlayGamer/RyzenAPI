-- Lua provided by RyzenAPI
-- Game: Crystal Tower Defense

-- MAIN APPLICATION
addappid(2429530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429531, 1, "6a588967df461cc7325566b01a98a15411aa4153f32715f1f9bced03ee06f4f6")

