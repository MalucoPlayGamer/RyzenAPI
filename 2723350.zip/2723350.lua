-- Lua provided by RyzenAPI
-- Game: 2723350

-- MAIN APPLICATION
addappid(2723350)
-- Game: addappid(2723350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723350,0,"9b846348fb05acb31ccfa1b6afc5bbabf5ad71ed597bbea368435c0e115cf666")
