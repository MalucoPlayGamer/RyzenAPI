-- Lua provided by SkyAPI 
-- Game: AppID 828590
addappid(828590)
addappid(828591, 1, "3f1c80252d39d9330ec8895f29f5e11260fc46025d803437c628e2e9bcff21e1")
