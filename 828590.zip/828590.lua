-- Lua provided by RyzenAPI
-- Game: Super Weekend Mode

-- MAIN APPLICATION
addappid(828590)

-- MAIN APP DEPOTS / PACKAGES
addappid(828591, 1, "3f1c80252d39d9330ec8895f29f5e11260fc46025d803437c628e2e9bcff21e1")

