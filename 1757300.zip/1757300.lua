-- Lua provided by RyzenAPI
-- Game: Jump Space

-- MAIN APPLICATION
addappid(1757300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757302,0,"477c69a9e90f67fcdc258a5d81db1350720e1320f906c219baf52338bef271cd")

