-- Lua provided by RyzenAPI
-- Game: Jump Space

-- MAIN APPLICATION
addappid(1757300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757302,0,"477c69a9e90f67fcdc258a5d81db1350720e1320f906c219baf52338bef271cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4028440)
