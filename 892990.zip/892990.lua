-- Lua provided by RyzenAPI
-- Game: Sable's Grimoire: A Dragon's Treasure

-- MAIN APPLICATION
addappid(892990)

-- MAIN APP DEPOTS / PACKAGES
addappid(892991,0,"c47234f264fdfc3dab001bd9e7d5010ac6f7e01e2d8da717e43146bbc43f2a6a")
addappid(892996,0,"d4db4c966785c9a40e8d60952512e4dfe8376a381dc68e7ed5fef4986c46fd20")
addappid(1055710,0,"1d0f1d7f1f0bd2cdbee44dd70f4703f8410e8d397750d514af0eb3566e1352b7")

