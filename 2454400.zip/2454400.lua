-- Lua provided by RyzenAPI
-- Game: Cyber Combat Playtest

-- MAIN APPLICATION
addappid(2454400)
-- Game: addappid(2454400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454401, 1, "16eaf02fc48b20e93bf8a4e496e893ab121e0cabd289a86a0b07c21e8e1cebc9")
