-- Lua provided by RyzenAPI 
-- Game: Cyber Combat Playtest
addappid(2454400)
addappid(2454401, 1, "16eaf02fc48b20e93bf8a4e496e893ab121e0cabd289a86a0b07c21e8e1cebc9")
