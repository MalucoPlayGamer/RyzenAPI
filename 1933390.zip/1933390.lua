-- Lua provided by RyzenAPI
-- Game: Rain World: Downpour

-- MAIN APPLICATION
addappid(1933390)
-- Game: addappid(1933390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933390,0,"cf34e0fb21789d7fd65c827a966d574e2fbd1e6b0cb47f81322256690ad70532")
