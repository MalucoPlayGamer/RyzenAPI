-- Lua provided by RyzenAPI
-- Game: BABYLON'S FALL

-- MAIN APPLICATION
addappid(889750)
addappid(1822650)
addappid(1824000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(889751, 1, "c8c07ecdd6b3cfadef79ad6d5a0d8b9e4c89730a64c31c0c33e350a19aa0c99e")

