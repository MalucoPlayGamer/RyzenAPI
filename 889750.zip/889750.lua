-- Lua provided by RyzenAPI
-- Game: BABYLON'S FALL

-- MAIN APPLICATION
addappid(889750)
addappid(1822650)
addappid(1824000)
-- Game: addappid(889750)

-- MAIN APP DEPOTS / PACKAGES
addappid(889751, 1, "c8c07ecdd6b3cfadef79ad6d5a0d8b9e4c89730a64c31c0c33e350a19aa0c99e")
