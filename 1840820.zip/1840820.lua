-- Lua provided by RyzenAPI
-- Game: Hammer of Virtue

-- MAIN APPLICATION
addappid(1840820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840821, 1, "6b443f18e3d92c1c03842abc210cde23e139f293908ceab6ac7ad3ad73296d6e")

