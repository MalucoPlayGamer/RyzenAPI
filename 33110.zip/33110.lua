-- Lua provided by RyzenAPI
-- Game: Alien Shooter: Revisited

-- MAIN APPLICATION
addappid(33110)

-- MAIN APP DEPOTS / PACKAGES
addappid(33111, 1, "8f8ad3106c44aa26ddbd97d639d469be33a03cea509b8f0c93f79afeff3cd05f")
addappid(33112, 1, "2f51b0302fe46952587cc9625a4e01518bed9e5a2a9e22fa0b328ffc9958b38c")
