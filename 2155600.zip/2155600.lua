-- Lua provided by RyzenAPI
-- Game: SEX Apocalypse 3D

-- MAIN APPLICATION
addappid(2155600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155601, 1, "4674bfcfd0a368868bdfb3a42bf62595c490b4d119df5f8fbb2389a90e59236a")

