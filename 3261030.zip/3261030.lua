-- Lua provided by RyzenAPI
-- Game: 3261030

-- MAIN APPLICATION
addappid(3261030)
-- Game: addappid(3261030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261031, 1, "c71cade10116dbe71b89b65e6c6033123b6effdffa4478bf68d6b3fa100c7cc4")
