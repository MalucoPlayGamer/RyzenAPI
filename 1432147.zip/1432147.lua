-- Lua provided by RyzenAPI
-- Game: FUSER™ - DJ Snake, J. Balvin & Tyga - "Loco Contigo"

-- MAIN APPLICATION
addappid(1432147)
-- Game: addappid(1432147)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432147,0,"f303ba5449a27ccb9a4880381288f232a87701550d721837b8fc2ca924c7febc")
