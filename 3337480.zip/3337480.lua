-- Lua provided by RyzenAPI
-- Game: Game: Waifu Simulator: Horem Edition

-- MAIN APPLICATION
addappid(3337480)
-- Game: addappid(3337480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337481, 1, "febdcae01e96bffa353f524a75303695563764ba776a9f3e61d5495b88eba9ac")
