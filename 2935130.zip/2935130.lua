-- 2935130's Lua and Manifest Created by Hubcap Manifest
-- Dice of Arcana
-- Created: August 27, 2026 at 05:42:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2935130) -- Dice of Arcana
addtoken(2935130, "12987529972511886269")
-- MAIN APP DEPOTS
addappid(2935131, 1, "417a60ba091cc4e3f79c7d60eee0edd04b22b484f675ad0720f904a6cc91db7e") -- Depot 2935131
setManifestid(2935131, "2358287142499857029", 11514858896)