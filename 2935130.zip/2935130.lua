-- Lua provided by RyzenAPI
-- Game: Dice of Arcana

-- MAIN APPLICATION
addappid(2935130) -- Dice of Arcana

-- MAIN APP DEPOTS / PACKAGES
addappid(2935131, 1, "417a60ba091cc4e3f79c7d60eee0edd04b22b484f675ad0720f904a6cc91db7e") -- Depot 2935131
addtoken(2935130, "12987529972511886269")

