-- Lua provided by RyzenAPI
-- Game: 516010

-- MAIN APPLICATION
addappid(516010)
-- Game: addappid(516010)

-- MAIN APP DEPOTS / PACKAGES
addappid(516011, 1, "80ac76b68b9f91c94671d884c778762750bbcb0c21d622dac3117b40e1caf7c9")
