-- Lua provided by RyzenAPI
-- Game: Game: Haven Park

-- MAIN APPLICATION
addappid(1549550)
-- Game: addappid(1549550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549551, 1, "4f8181a7f55a9822e426d03d114149e52cb7118446c8c6fe98d6d2711158257d")
addappid(1549552, 1, "eb78f1f82abc6e81ac165c0e3077cca7dee995e8b1d13ad3334dff23ff05ac6d")
addappid(1549553, 1, "0c735409c79816cbf39a84967cb7cf14a47c39e99d819712a1c3cd239125ff85")
