-- Lua provided by RyzenAPI
-- Game: 1747690

-- MAIN APPLICATION
addappid(1747690)
-- Game: addappid(1747690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747691, 1, "69933882389b9fec453bd6bec159c6c140b06a1467e40f84c3060df17aa1b277")
