-- Lua provided by RyzenAPI
-- Game: AppID 495990

-- MAIN APPLICATION
addappid(495990)

-- MAIN APP DEPOTS / PACKAGES
addappid(495991, 1, "e3794583cc59c8c759e9d518ff3a9307ce0559fe180aca960326de0f466cc0ae")
addappid(501750, 0, "4066092f7817d9c4c39f53cdf9ce80e72094dafedee63ea59c04dec6fb98bb93")
addappid(580210, 0, "a232fe261c07cd818218abe986a28cec419af6add0749e587dd81c52cacf6a01")
addappid(1233310, 0, "6cabbcbefc237548fd9c93568179563f7e40d8b7253f691d97d085fd6421d2d1")
addappid(1233320, 0, "704e87fd8894cc5a5b61c7caac5cad0adbbbc351514c695916b1912b83a58714")
addappid(2075980, 0, "37e2ef7bb27ebb1f14c77a080ed18e2b9491fb046df361da6073ebb045935316")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
