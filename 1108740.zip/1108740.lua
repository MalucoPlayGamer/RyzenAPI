-- Lua provided by RyzenAPI
-- Game: Stick Em Up

-- MAIN APPLICATION
addappid(1108740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108741, 1, "175b6c15c1d071805fa8bfa408b0fbb0cc5e2f58c09b80da968ff760a0b17245")
