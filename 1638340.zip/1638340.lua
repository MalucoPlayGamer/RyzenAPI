-- Lua provided by RyzenAPI
-- Game: 1638340

-- MAIN APPLICATION
addappid(1638340)
-- Game: addappid(1638340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638341, 1, "c88cb203c91a7548335c85fe1bd67e7df913e02e8a04663a760fd265ab003021")
