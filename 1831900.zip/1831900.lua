-- Lua provided by RyzenAPI
-- Game: UE5 Shooter Game

-- MAIN APPLICATION
addappid(1831900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831901, 1, "61dd30e57b5fe06f7ce12b27f9d21593796ec8cc2e28bf4e0c66106288e73fc4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
