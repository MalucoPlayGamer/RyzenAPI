-- Lua provided by RyzenAPI 
-- Game: UE5 Shooter Game
addappid(1831900)
addappid(1831901, 1, "61dd30e57b5fe06f7ce12b27f9d21593796ec8cc2e28bf4e0c66106288e73fc4")
