-- Lua provided by RyzenAPI
-- Game: 858880

-- MAIN APPLICATION
addappid(858880)
-- Game: addappid(858880)

-- MAIN APP DEPOTS / PACKAGES
addappid(858881, 1, "b2588f6eaa869fffd0a53af701af7a64701f6f2b41219b795cbe2ed4c14a3fd6")
addappid(858884, 1, "385f3e2d8783153de15c2e3db930feb601a89a7adf0fef16c2892d7d6f15f9a4")
addappid(858886, 1, "d3985c748a399949600feef69d4af545da98b0f5b45e1f8aac387137d8e8ca41")
