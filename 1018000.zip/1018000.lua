-- Lua provided by RyzenAPI
-- Game: Arcade Classics Anniversary Collection

-- MAIN APPLICATION
addappid(1018000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018001, 1, "ee18da7549d90b36537b0c9ffe3f69ff7b4d71ef114c5596ed01edadb4894184")

