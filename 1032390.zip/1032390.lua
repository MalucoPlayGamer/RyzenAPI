-- Lua provided by RyzenAPI
-- Game: Eastshade Original Soundtrack

-- MAIN APPLICATION
addappid(1032390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032390,0,"5f4ddb73714618273257b588798a90ced697a4e21831a21789a671ca53ccf838")

