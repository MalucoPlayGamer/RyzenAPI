-- Lua provided by RyzenAPI
-- Game: Cliff Empire

-- MAIN APPLICATION
addappid(809140)

-- MAIN APP DEPOTS / PACKAGES
addappid(809141, 1, "346879f2be8e1a23573d0efd74fdae779a11ec685f5d6b5cd7ed809dd9591de5")
addappid(809142, 1, "3f2b754520df9e5cba15c7fd0fa71d796e845cd812d7eaa07d75ceed183fcd01")
