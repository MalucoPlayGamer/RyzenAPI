-- Lua provided by RyzenAPI
-- Game: Vampires!

-- MAIN APPLICATION
addappid(713050)

-- MAIN APP DEPOTS / PACKAGES
addappid(713051, 1, "0a86c10a465d12e382f79f67679a3399ba3a632eae6fcefdf22e0c5d2b988642")

