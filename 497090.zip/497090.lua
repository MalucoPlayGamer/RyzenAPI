-- Lua provided by RyzenAPI
-- Game: addappid(497090)

-- MAIN APPLICATION
addappid(497090)

-- MAIN APP DEPOTS / PACKAGES
addappid(497091, 1, "14e8208501948fd23936bf8dae541e710d2776fda6b1f883277a88be151d32a0")
