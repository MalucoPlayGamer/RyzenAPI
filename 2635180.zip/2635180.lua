-- Lua provided by RyzenAPI
-- Game: addappid(2635180)

-- MAIN APPLICATION
addappid(2635180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635180,0,"4e5fc21cb5c553d89c8a7e2ab1b89b8ec43ac51279d537b3deff98f46a439763")
