-- Lua provided by RyzenAPI
-- Game: Peppy's Adventure

-- MAIN APPLICATION
addappid(1588910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1588911, 1, "dde4228e576965fd2b377af0e4b68246f07118f1e5f73fa0f2c68c78b88e53f9")
addappid(1588912, 1, "3b0a2b0f79f1c6fcf8880c2b7d928e47de1ead7191677ccd40a901fc7d1f7dc6")
addappid(1588913, 1, "bee62c7e709e7d5f6426a6d19c46e816b025b61e0604b74860940398797b7721")

