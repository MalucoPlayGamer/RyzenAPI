-- Lua provided by RyzenAPI
-- Game: Reign of Guilds

-- MAIN APPLICATION
addappid(716350)

-- MAIN APP DEPOTS / PACKAGES
addappid(716351, 1, "900749c5f46586cd9c823732b9e377672e55bc0f53bf3f49e37d31f0d19bb713")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2587000)
addappid(2611870)
addappid(2611880)
addappid(3223340)
addappid(3223490)
