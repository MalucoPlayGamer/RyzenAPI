-- Lua provided by RyzenAPI
-- Game: AppID 1232080

-- MAIN APPLICATION
addappid(1232080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232081, 1, "0736dfc32d8d3c4eb3be29e0f0e5d0c1c00b800627e460427e21c3db1ebaf35a")
addappid(1232082, 1, "ce3e9ed44bdc74eb693f55a218730b1f77bcb1fac9150e634a2e0822c4f7a0a2")

