-- Lua provided by RyzenAPI
-- Game: Zoey: My Hentai Sex Doll

-- MAIN APPLICATION
addappid(1716170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716171, 1, "1dd4f58a4443ba289d01dbe06d1f6c8807164c577cd812c69751e60b16cf08d0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2138950)
addappid(2138951)
addappid(2138952)
addappid(2195420)
