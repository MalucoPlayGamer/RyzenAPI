-- Lua provided by RyzenAPI
-- Game: addappid(1716170)

-- MAIN APPLICATION
addappid(1716170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716171, 1, "1dd4f58a4443ba289d01dbe06d1f6c8807164c577cd812c69751e60b16cf08d0")
