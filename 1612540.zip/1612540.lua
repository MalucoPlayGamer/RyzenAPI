-- Lua provided by RyzenAPI
-- Game: addappid(1612540)

-- MAIN APPLICATION
addappid(1612540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612541, 1, "a22441ae0429b03ffc5ca53039fe9795945d6ac471e076316b5adb81fae75202")
