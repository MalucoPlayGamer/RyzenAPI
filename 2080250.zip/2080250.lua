-- Lua provided by RyzenAPI
-- Game: Tower of Chaos

-- MAIN APPLICATION
addappid(2080250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080251, 1, "9ebf27a2c8c00c47217abfe6b524895d6ea1b7cc9188656da32d19c91d2ba0c5")

