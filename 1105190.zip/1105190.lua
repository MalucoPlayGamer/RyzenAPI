-- Lua provided by RyzenAPI
-- Game: 1105190

-- MAIN APPLICATION
addappid(1105190)
-- Game: addappid(1105190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105190,0,"d4c9dfcff23c5d7a924ba1f63ea9966d6da6ca6d1ca808f283e6b9a3fdbf0dad")
