-- Lua provided by SkyAPI 
-- Game: Hero Guider
addappid(3083520)
addappid(3083521, 1, "59728b09f2d90f2d5dc5f2bc7694f861df22a95078ac1c6f2752790bdf4392fb")
