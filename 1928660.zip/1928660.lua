-- Lua provided by RyzenAPI
-- Game: SNOT

-- MAIN APPLICATION
addappid(1928660)
-- Game: addappid(1928660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928661, 1, "ceda9c0f31bdd7d363b719982b935866d2e19803968cb076486660b9036c456e")
