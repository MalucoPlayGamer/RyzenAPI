-- Lua provided by RyzenAPI
-- Game: SNOT

-- MAIN APPLICATION
addappid(1928660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1928661, 1, "ceda9c0f31bdd7d363b719982b935866d2e19803968cb076486660b9036c456e")

