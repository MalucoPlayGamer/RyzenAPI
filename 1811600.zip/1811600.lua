-- Lua provided by RyzenAPI
-- Game: addappid(1811600)

-- MAIN APPLICATION
addappid(1811600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811601, 1, "c8756ec9abdb4ee5f5ead8af843ceddad3644d0d47ab3a677c4df766a20eff92")
addappid(1811605, 1, "dcc6667074f793012ef946f91343bfec0bc2d0c25c911e8985bfd509f4529b79")
