-- Lua provided by SkyAPI 
-- Game: AppID 1662020
addappid(1662020)
addappid(1662021, 1, "491a00f624f7445268dbc4c3c6cf99b8ced0f464c46a2b298d146b4804c99a70")
