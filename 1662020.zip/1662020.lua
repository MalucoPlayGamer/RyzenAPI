-- Lua provided by RyzenAPI
-- Game: AppID 1662020

-- MAIN APPLICATION
addappid(1662020)
-- Game: addappid(1662020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662021, 1, "491a00f624f7445268dbc4c3c6cf99b8ced0f464c46a2b298d146b4804c99a70")
