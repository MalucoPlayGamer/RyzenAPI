-- Lua provided by SkyAPI 
-- Game: Paint Drying Simulator
addappid(1630590)
addappid(1630591, 1, "3c3fc623f8a1b727083c4ecf00d24d6375cbcce4094019a20e75ebcc3fef9797")
