-- Lua provided by RyzenAPI
-- Game: Paint Drying Simulator

-- MAIN APPLICATION
addappid(1630590)
-- Game: addappid(1630590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630591, 1, "3c3fc623f8a1b727083c4ecf00d24d6375cbcce4094019a20e75ebcc3fef9797")
