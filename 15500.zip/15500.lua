-- Lua provided by RyzenAPI
-- Game: The Wonderful End of the World

-- MAIN APPLICATION
addappid(15500)

-- MAIN APP DEPOTS / PACKAGES
addappid(15501, 1, "8573b8ecc0e1a61bad9d889967ef5e8df0a3f6053f90125ff1f8df44b974dfd0")
addappid(98014, 0, "4b29f31f28e329dd77748b5eeca7f4fdc79d8e0a3ace9b67c15b48fe66cc9838")

