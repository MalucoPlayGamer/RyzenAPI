-- Lua provided by RyzenAPI
-- Game: WHO IS AWESOME

-- MAIN APPLICATION
addappid(1123030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123031, 1, "7a831183dce67d62306c50fd9e64b3115a8eb81d3b2392f455960832ff963518")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
