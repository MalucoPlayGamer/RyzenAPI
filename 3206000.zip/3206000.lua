-- Lua provided by RyzenAPI
-- Game: Pieter Both Village Demo

-- MAIN APPLICATION
addappid(3206000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206001, 1, "7f5d08b1f5a145f3ebc8a2966ed36edc6a873c6881fa58ba475c88099b8a2a71")
