-- Lua provided by RyzenAPI
-- Game: Hello Charlotte Demo

-- MAIN APPLICATION
addappid(557800)

-- MAIN APP DEPOTS / PACKAGES
addappid(557802,0,"880f76c2ed123190dbbf00f0b14fabe79ded0efce518c6527a9557ba42795c16")
