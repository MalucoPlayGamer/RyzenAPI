-- Lua provided by RyzenAPI
-- Game: Paladin

-- MAIN APPLICATION
addappid(548220)

-- MAIN APP DEPOTS / PACKAGES
addappid(548221,0,"eb5023521ea4a1dd08a33a42a2efb15d1d563f68f1ba43300c97ef5ef0f15540")

