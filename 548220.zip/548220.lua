-- Lua provided by RyzenAPI
-- Game: Paladin

-- MAIN APPLICATION
addappid(548220)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(548221,0,"eb5023521ea4a1dd08a33a42a2efb15d1d563f68f1ba43300c97ef5ef0f15540")

