-- Lua provided by RyzenAPI
-- Game: Asunder

-- MAIN APPLICATION
addappid(2213290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213291,0,"0d6245d55c98ba4f6ad78abd971ce86ca1f041c0c93546617fbabc1839520509")

