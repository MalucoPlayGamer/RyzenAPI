-- Lua provided by RyzenAPI
-- Game: The Orion Suns

-- MAIN APPLICATION
addappid(787570)

-- MAIN APP DEPOTS / PACKAGES
addappid(787571, 1, "39360b9391c00dd65ceb01377367df2782f907e1c8dbea34e308c343ac3eac3e")

