-- Lua provided by RyzenAPI
-- Game: Hentai tentacle bicycle race

-- MAIN APPLICATION
addappid(952880)

-- MAIN APP DEPOTS / PACKAGES
addappid(952881, 1, "c98826dee16e3e70e03052f634ae16eab05b0bd69ef1f933da4cc5a18849ffbe")

