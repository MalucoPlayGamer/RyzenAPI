-- Lua provided by RyzenAPI
-- Game: Journey to Incrementalia

-- MAIN APPLICATION
addappid(3147430)
-- Game: addappid(3147430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147431, 1, "4aab435ba111207f062739efb410a414d38f11e0e1910a84df1ac5e2b682d325")
