-- Lua provided by SkyAPI 
-- Game: Journey to Incrementalia
addappid(3147430)
addappid(3147431, 1, "4aab435ba111207f062739efb410a414d38f11e0e1910a84df1ac5e2b682d325")
