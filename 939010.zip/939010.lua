-- Lua provided by RyzenAPI
-- Game: addappid(939010)

-- MAIN APPLICATION
addappid(939010)

-- MAIN APP DEPOTS / PACKAGES
addappid(939011, 1, "072f4cf39f9841484b880139b5825b18f4c2acf9eb43df6e2a8d345b53351a28")
