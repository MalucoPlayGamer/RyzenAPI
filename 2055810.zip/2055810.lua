-- Lua provided by RyzenAPI
-- Game: Game: So to Speak Demo

-- MAIN APPLICATION
addappid(2055810)
-- Game: addappid(2055810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055811, 1, "7214e1640e19f238f56061232374533e37fd12cd08a030970d2305ce98cb8348")
