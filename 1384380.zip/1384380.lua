-- Lua provided by RyzenAPI
-- Game: KUUKIYOMI 2: Consider It More! - New Era

-- MAIN APPLICATION
addappid(1384380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384381, 1, "858835b53bcfa4ea40d7c7aeb31436f42598e9443937abc554afb3fb80826efb")
