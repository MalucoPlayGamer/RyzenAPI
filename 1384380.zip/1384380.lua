-- Lua provided by RyzenAPI
-- Game: 1384380

-- MAIN APPLICATION
addappid(1384380)
-- Game: addappid(1384380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384381, 1, "858835b53bcfa4ea40d7c7aeb31436f42598e9443937abc554afb3fb80826efb")
