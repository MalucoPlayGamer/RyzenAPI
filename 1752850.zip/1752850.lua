-- Lua provided by RyzenAPI
-- Game: Game: Find Match Icons

-- MAIN APPLICATION
addappid(1752850)
-- Game: addappid(1752850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752851, 1, "0f907006b4fc0ccb5f7fbf7ad272c7dcffc30145e4465bd19ea47ca4e7cfeb93")
