-- Lua provided by RyzenAPI
-- Game: Game: 3079 - Block Action RPG

-- MAIN APPLICATION
addappid(259620)
-- Game: addappid(259620)

-- MAIN APP DEPOTS / PACKAGES
addappid(259621, 1, "3ebb5f263aa0c07dfc9fab6bf8da77cdd1b2f41aaaf29cb02f220766825f65da")
addappid(259622, 1, "8707a9584cba9c847607ccdcafd694626b522afad89e4c03ea7b180522c8d7a7")
addappid(259623, 1, "9113c213faaadaaeba7e783544ba326ff0fc17d77a6dbcbdbfd506e01ced6932")
