-- Lua provided by RyzenAPI
-- Game: Otome * Domain

-- MAIN APPLICATION
addappid(2153330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153331, 1, "1f8e7f2333a6e4f2c7e2c46b7245a34d8abc246da5800ababc486cef342c5b23")

