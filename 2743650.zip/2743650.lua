-- Lua provided by RyzenAPI
-- Game: 镖行天下

-- MAIN APPLICATION
addappid(2743650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743651, 1, "e01b9fc63af5dc47c71f0d6f4ae0e2f2b848995886fe8603f2c32bf733376bad")
