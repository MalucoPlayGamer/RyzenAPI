-- Lua provided by RyzenAPI
-- Game: Love And Order

-- MAIN APPLICATION
addappid(350490)

-- MAIN APP DEPOTS / PACKAGES
addappid(350491, 1, "6c9ed419685f31e5511eef1cd78d0808595793f006748162e092339c092afa0d")
