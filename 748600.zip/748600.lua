-- Lua provided by RyzenAPI
-- Game: Game: AppID 748600

-- MAIN APPLICATION
addappid(748600)
-- Game: addappid(748600)

-- MAIN APP DEPOTS / PACKAGES
addappid(748601, 1, "4fd365c1512f3cb82b8ec385f5008dc848c53f4174cdb762a367b689d7dd3530")
