-- Lua provided by RyzenAPI
-- Game: Ghostory

-- MAIN APPLICATION
addappid(568460)
-- Game: addappid(568460)

-- MAIN APP DEPOTS / PACKAGES
addappid(568461, 1, "2e12c20b753c0467bddac582a31b907ee965c059cfe12f7ebf77e260063296f7")
