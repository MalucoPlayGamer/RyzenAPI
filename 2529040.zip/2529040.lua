-- Lua provided by RyzenAPI
-- Game: addappid(2529040)

-- MAIN APPLICATION
addappid(2529040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529041, 1, "a152a3baada151ab2a63ae82140314c081ba8ffc30f8a4bf8c425d9f31c7cc98")
