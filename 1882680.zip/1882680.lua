-- Lua provided by RyzenAPI
-- Game: 1882680

-- MAIN APPLICATION
addappid(1882680)
-- Game: addappid(1882680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882681, 1, "0fa4c42b0bfc8f8208e4ce4ca611e49a108c2c9c0887187aad775e1feb2656d0")
