-- Lua provided by RyzenAPI 
-- Game: AppID 1292790
addappid(1292790)
addappid(1292791, 1, "e64e9d080f175366017a103a61b56232636d9b24c0c97265eb612921171532b9")
