-- Lua provided by RyzenAPI
-- Game: AppID 324240

-- MAIN APPLICATION
addappid(324240)

-- MAIN APP DEPOTS / PACKAGES
addappid(324241, 1, "0aa84ef171fff67b66d2f8e805529569e2f3445780d0a796f3dc01b8563acaa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
