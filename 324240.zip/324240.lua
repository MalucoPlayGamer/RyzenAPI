-- Lua provided by RyzenAPI
-- Game: addappid(324240)

-- MAIN APPLICATION
addappid(324240)

-- MAIN APP DEPOTS / PACKAGES
addappid(324241, 1, "0aa84ef171fff67b66d2f8e805529569e2f3445780d0a796f3dc01b8563acaa0")
