-- Lua provided by RyzenAPI
-- Game: addappid(3795080)

-- MAIN APPLICATION
addappid(3795080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795081, 1, "3d338f7f776fd05927c24291fab5d26a1efeefb363201e395b14f1990a38b9ca")
