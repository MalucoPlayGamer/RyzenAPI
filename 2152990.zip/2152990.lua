-- Lua provided by RyzenAPI
-- Game: Dinogen Online

-- MAIN APPLICATION
addappid(2152990)
-- Game: addappid(2152990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152991, 1, "82f91a7ca270606777971550131cd4ea145a8b5f5b9268ce294c88a17d474169")
