-- Lua provided by RyzenAPI
-- Game: AppID 553760

-- MAIN APPLICATION
addappid(553760)

-- MAIN APP DEPOTS / PACKAGES
addappid(553761, 1, "3c79eab398332437a6800a472589261d3fdd4e6e8fdba2f414f56bda4083e2ae")

