-- Lua provided by RyzenAPI
-- Game: Einlanzer

-- MAIN APPLICATION
addappid(553760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(553761, 1, "3c79eab398332437a6800a472589261d3fdd4e6e8fdba2f414f56bda4083e2ae")

