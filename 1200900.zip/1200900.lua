-- Lua provided by RyzenAPI
-- Game: Game: Crypto: Against All Odds - Tower Defense

-- MAIN APPLICATION
addappid(1200900)
-- Game: addappid(1200900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200901, 1, "19b0e3e825f071658d53ee57b030418daf2c1bf5cd39610f8d1a8d05ee3b7d03")
