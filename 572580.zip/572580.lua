-- Lua provided by RyzenAPI
-- Game: Incredible Dracula II: The Last Call Collector's Edition

-- MAIN APPLICATION
addappid(572580)

-- MAIN APP DEPOTS / PACKAGES
addappid(572581, 1, "9f221ef5da3ba278633e483835151d53475aa83a8e832fac5dc9f3f530d6e421")

