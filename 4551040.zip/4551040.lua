-- Lua provided by RyzenAPI
-- Game: Animal Company

-- MAIN APPLICATION
addappid(4551040)

-- MAIN APP DEPOTS / PACKAGES
addappid(4551041,0,"b8edcd3660c7d817012735983ba2d3fa12efa52aa3c066d0ee04627679373b96")

