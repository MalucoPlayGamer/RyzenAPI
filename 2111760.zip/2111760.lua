-- Lua provided by RyzenAPI 
-- Game: PARADISE CLEANING - pregnant ogre -
addappid(2111760)
addappid(2111761, 1, "aae36e61f1381e415e57db1a52b7909f11af88c461e2f2bb5f3db46e0df0d0ac")
