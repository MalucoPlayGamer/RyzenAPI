-- Lua provided by RyzenAPI
-- Game: addappid(2111760)

-- MAIN APPLICATION
addappid(2111760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111761, 1, "aae36e61f1381e415e57db1a52b7909f11af88c461e2f2bb5f3db46e0df0d0ac")
