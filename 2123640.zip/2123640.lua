-- Lua provided by RyzenAPI
-- Game: Hollowbody

-- MAIN APPLICATION
addappid(2123640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123641, 1, "cd95e2d279a5f19b799660720b650fd9db4b26c546f0503e6dbe56674a3ff94d")
