-- Lua provided by RyzenAPI
-- Game: Honey Milf

-- MAIN APPLICATION
addappid(1750070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750071, 1, "c90f15b75af11770a05e4c7b614a31cc9653574fe044d628b5442b823b016ff7")
