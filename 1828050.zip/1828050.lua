-- Lua provided by RyzenAPI
-- Game: Dream/strung - Blossoming Love Demo

-- MAIN APPLICATION
addappid(1828050)
-- Game: addappid(1828050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828051, 1, "4588fe0ac279f346a265090d007bcfaf84bedad47e942768151b31a79a7b61b8")
