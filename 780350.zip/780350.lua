-- Lua provided by RyzenAPI
-- Game: Game: Unruly Heroes

-- MAIN APPLICATION
addappid(780350)
-- Game: addappid(780350)

-- MAIN APP DEPOTS / PACKAGES
addappid(780351, 1, "c857f55911a12daf25b8f121bb1af4157c9f2c79ad28bb37f755968c9b7620a8")
addappid(780352, 1, "435c9f9bb62db83000b76f253d351aa510af3573a1783e89933fce851f7868a2")
