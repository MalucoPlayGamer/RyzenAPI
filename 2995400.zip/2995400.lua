-- Lua provided by RyzenAPI 
-- Game: AppID 2995400
addappid(2995400)
addappid(2995401, 1, "f91994590456d15619e7c1f453621b4ec6d4b64e88ee1ac3dcf76f14d08011ab")
