-- Lua provided by RyzenAPI
-- Game: Zhou Tai - Officer Ticket / 周泰使用券

-- MAIN APPLICATION
addappid(956736)

-- MAIN APP DEPOTS / PACKAGES
addappid(956736,0,"2b0f1edbe2baa5c9211292f0eb41f4798a7ba0187d9c8098af9f6b93894aee63")
