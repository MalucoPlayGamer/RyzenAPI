-- Lua provided by RyzenAPI
-- Game: Game: AppID 3359420

-- MAIN APPLICATION
addappid(3359420)
-- Game: addappid(3359420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359421, 1, "27b7ef1976b2a43037951a3c6e14c94447f700c94525c4c51d280977b42afd0a")
