-- Lua provided by RyzenAPI 
-- Game: AppID 3359420
addappid(3359420)
addappid(3359421, 1, "27b7ef1976b2a43037951a3c6e14c94447f700c94525c4c51d280977b42afd0a")
