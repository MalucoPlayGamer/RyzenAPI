-- Lua provided by RyzenAPI
-- Game: Game: AppID 3179270

-- MAIN APPLICATION
addappid(3179270)
-- Game: addappid(3179270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179271, 1, "c59737429fa452216529bc6a6e5201d710ed3cb549a93048786fcace8be06051")
