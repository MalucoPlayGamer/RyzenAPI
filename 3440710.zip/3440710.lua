-- Lua provided by RyzenAPI
-- Game: Dreamtopia

-- MAIN APPLICATION
addappid(3440710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440711, 1, "d1ecbfa2494882983e95d9e0d162b25bd58f03bcc4069f4aa0bf2588048b0045")
