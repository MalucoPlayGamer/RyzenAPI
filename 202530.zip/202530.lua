-- Lua provided by RyzenAPI
-- Game: Game: Sonic the Hedgehog 4 - Episode I

-- MAIN APPLICATION
addappid(202530)
-- Game: addappid(202530)

-- MAIN APP DEPOTS / PACKAGES
addappid(202531, 1, "f989f78a481ccbaf4832ac57f576f93fcd283ab5e77bbedc713fe7fb5c82cab0")
