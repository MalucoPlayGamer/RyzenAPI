-- Lua provided by RyzenAPI
-- Game: addappid(2638560)

-- MAIN APPLICATION
addappid(2638560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638561, 1, "f0fcb277caeac4df05b154149667a45ac064ebc4cf5ee5eb394f1bf36e40e77d")
addappid(3292860, 0, "274f28ccaba743b804db693e544e7da180fd554f51d64dec4b8829e206ffc64b")
