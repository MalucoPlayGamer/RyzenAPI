-- Lua provided by RyzenAPI
-- Game: Viscerafest

-- MAIN APPLICATION
addappid(1406780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406781, 1, "5d6a63a6f28fba76593e1294277d3050de422e670b56eaa85cdd4a875067e176")
addappid(1406782, 1, "69be68ff900f83fad19f01cd40c26e79fd601c5d26e5a8990778b6af02ab0d30")
addappid(1406783, 1, "36c52a9aeb81afe419f0f73c30025375ab3ba469c8408e865c60823948654931")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
