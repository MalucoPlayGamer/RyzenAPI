-- Lua provided by RyzenAPI
-- Game: Barbershop Simulator VR

-- MAIN APPLICATION
addappid(2109850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2109852,0,"d2f741d7399c233806473b9e2c35e12cd853a668aefee3096fc9329f62261211")

