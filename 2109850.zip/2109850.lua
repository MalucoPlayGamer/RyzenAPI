-- Lua provided by RyzenAPI
-- Game: Barbershop Simulator VR

-- MAIN APPLICATION
addappid(2109850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109852,0,"d2f741d7399c233806473b9e2c35e12cd853a668aefee3096fc9329f62261211")
