-- Lua provided by RyzenAPI
-- Game: Shoot 'm Up

-- MAIN APPLICATION
addappid(657170)

-- MAIN APP DEPOTS / PACKAGES
addappid(657171,0,"76f945d289a657b774a31b3cd337f50a3328987934a69797d46acef7c6e09f91")
addappid(657172,0,"0ac13af65b7f982f377f54b1db57f9d833a8971f1cee8d70721805004f5120cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
