-- Lua provided by SkyAPI 
-- Game: Gold Drill
addappid(2084820)
addappid(2084821, 1, "bfeca721fa033410a992e678cd3c5db01f4ab9ea2a373f7c61694373d1e8b4f1")
