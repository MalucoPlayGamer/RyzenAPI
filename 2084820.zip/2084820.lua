-- Lua provided by RyzenAPI
-- Game: Gold Drill

-- MAIN APPLICATION
addappid(2084820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084821, 1, "bfeca721fa033410a992e678cd3c5db01f4ab9ea2a373f7c61694373d1e8b4f1")
