-- Lua provided by RyzenAPI
-- Game: PARADISE CLEANING - ヴァリアントヴァース -

-- MAIN APPLICATION
addappid(3058830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058831, 1, "59476dc45e070bac7d69723972f9fa2f0df924cfd7357ff1027faf999fd7ef81")

