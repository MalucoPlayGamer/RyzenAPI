-- Lua provided by RyzenAPI
-- Game: 1732840

-- MAIN APPLICATION
addappid(1732840)
-- Game: addappid(1732840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732841, 1, "cde4cefa4cd65f30bda72a4bf2e450e12de3c3a879f0bcf95d145d39fc320108")
