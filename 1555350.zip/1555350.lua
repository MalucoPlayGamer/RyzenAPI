-- Lua provided by RyzenAPI
-- Game: 1555350

-- MAIN APPLICATION
addappid(1555350)
-- Game: addappid(1555350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555351, 1, "dcdcc6d0231af9c8fbdf3c1b662802c99bbcba47800791c498b7957ed181431c")
