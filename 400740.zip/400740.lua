-- Lua provided by RyzenAPI
-- Game: 400740

-- MAIN APPLICATION
addappid(400740)
-- Game: addappid(400740)

-- MAIN APP DEPOTS / PACKAGES
addappid(400741, 1, "82cf8d087ae143c16888b4d9a9c21e684dfb8699217d445e6c7c203474cca226")
