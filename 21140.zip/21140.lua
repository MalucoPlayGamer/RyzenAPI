-- Lua provided by RyzenAPI
-- Game: AppID 21140

-- MAIN APPLICATION
addappid(21140)
-- Game: addappid(21140)

-- MAIN APP DEPOTS / PACKAGES
addappid(21141, 1, "effec061c3db68634a00f52bcb3804478ba7774587ab56c8c977687881ad81ab")
