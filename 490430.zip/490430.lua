-- Lua provided by RyzenAPI
-- Game: Game: Octamari Rescue

-- MAIN APPLICATION
addappid(490430)
-- Game: addappid(490430)

-- MAIN APP DEPOTS / PACKAGES
addappid(490431, 1, "5a46640c979657cdc637418f3105afe14f413188b59c7efef1a0c8b8324c8724")
addappid(490432, 1, "9d93851a878e935e9e83ba8f40692433e78102f311048c6ad74600f7b22ae93a")
