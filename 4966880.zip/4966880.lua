-- 4966880's Lua and Manifest Created by Hubcap Manifest
-- Octavia’s Alienzzle
-- Created: August 11, 2026 at 23:25:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4966880) -- Octavia’s Alienzzle
-- MAIN APP DEPOTS
addappid(4966881, 1, "8988355b7298e069a1cfb5a5f1aa5a3bbcbab247c564492af791e60e18f30c73") -- Depot 4966881
setManifestid(4966881, "5551679336210303695", 755932075)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)