-- Lua provided by RyzenAPI
-- Game: Julian & Friends

-- MAIN APPLICATION
addappid(3147190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147191, 1, "0b13661beafd7ba0dd3178076e0622f12f0a7e98f7d0618059e4e7661bf042f1")

