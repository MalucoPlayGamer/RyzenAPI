-- Lua provided by RyzenAPI
-- Game: addappid(1231840)

-- MAIN APPLICATION
addappid(1231840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231841, 1, "451c7a71fd257dc883fa867bcb5c5de992e49839f3d2d182c10581920c6d11cb")
