-- Lua provided by RyzenAPI
-- Game: Hope is in 23

-- MAIN APPLICATION
addappid(724950)

-- MAIN APP DEPOTS / PACKAGES
addappid(724951,0,"59fe6a3edcc6aac004c37a70c1cbb3c4979405271a75a0b06ac5ce2c833095ea")

