-- Lua provided by RyzenAPI
-- Game: Soccer Manager 2026

-- MAIN APPLICATION
addappid(3217240)
