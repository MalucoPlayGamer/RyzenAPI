-- Lua provided by RyzenAPI
-- Game: 2497610

-- MAIN APPLICATION
addappid(2497610)
-- Game: addappid(2497610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497611, 1, "9701200e1ebf8eb0cf2dcc6cda21b533009d978df231717e7e42ca721bb32836")
