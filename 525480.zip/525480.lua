-- Lua provided by RyzenAPI
-- Game: 525480

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(525480)
-- Game: addappid(525480)

-- MAIN APP DEPOTS / PACKAGES
addappid(525482,0,"96354b403d605c3829020a575b91208dfdd4a440fa66b7927b69bb57599780e3")
