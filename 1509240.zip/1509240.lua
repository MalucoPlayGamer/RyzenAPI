-- Lua provided by RyzenAPI
-- Game: addappid(1509240)

-- MAIN APPLICATION
addappid(1509240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509240,0,"cb02be21c197e4d266998a0dd3a7fc1bf20a5b3884e061d745283d5a858ebe29")
