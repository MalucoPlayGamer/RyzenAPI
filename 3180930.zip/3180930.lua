-- Lua provided by RyzenAPI
-- Game: Komadori Inn Demo

-- MAIN APPLICATION
addappid(3180930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180931, 1, "19685ed190e3f64f27da36d164a5520a4528e61d545e4554bac600a351466881")

