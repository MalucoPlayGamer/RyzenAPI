-- Lua provided by RyzenAPI
-- Game: addappid(1633900)

-- MAIN APPLICATION
addappid(1633900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633902,0,"d04ce3ce0da83fcbf78f1343e7680cab710ee2929192c3295473dc4f2a663c9a")
