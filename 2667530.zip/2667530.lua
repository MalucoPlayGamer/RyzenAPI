-- Lua provided by SkyAPI 
-- Game: AppID 2667530
addappid(2667530)
addappid(2667531, 1, "f26327373dc730650236557572f4103262db3deada2daf30b817b3c286a63609")
