-- Lua provided by RyzenAPI
-- Game: 466260

-- MAIN APPLICATION
addappid(466260)
-- Game: addappid(466260)

-- MAIN APP DEPOTS / PACKAGES
addappid(466261, 1, "915510b9c0ab3fa15eff63347e640611e8f69cefe2f9a540206839d2a0eafafe")
