-- Lua provided by RyzenAPI
-- Game: Hydrofoil Generation

-- MAIN APPLICATION
addappid(1448820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1448821, 1, "3a757b46e71b1e59a743d1e615a3547624b7b2dcf52ec1db5d5be9e81e600101")

