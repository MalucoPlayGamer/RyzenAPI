-- Lua provided by RyzenAPI
-- Game: 1448820

-- MAIN APPLICATION
addappid(1448820)
-- Game: addappid(1448820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448821, 1, "3a757b46e71b1e59a743d1e615a3547624b7b2dcf52ec1db5d5be9e81e600101")
