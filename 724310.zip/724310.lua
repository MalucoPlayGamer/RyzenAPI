-- Lua provided by RyzenAPI
-- Game: Kawanakajima no Kassen

-- MAIN APPLICATION
addappid(724310)

-- MAIN APP DEPOTS / PACKAGES
addappid(724311,0,"a9e5132c5db0f197446c1dbe58f19fccd5fc0d925fef818f40ab603371f825cf")

