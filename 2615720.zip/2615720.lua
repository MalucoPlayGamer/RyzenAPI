-- Lua provided by RyzenAPI
-- Game: AppID 2615720

-- MAIN APPLICATION
addappid(2615720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615721, 1, "3d16f8b2ffd186d9ab0f876296de70fd57cd6e16718e1b790a38aa11b4fdd723")
