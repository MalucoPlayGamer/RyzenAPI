-- Lua provided by RyzenAPI
-- Game: addappid(615400)

-- MAIN APPLICATION
addappid(615400)

-- MAIN APP DEPOTS / PACKAGES
addappid(615401, 1, "3227076d52a1dd0cea5e7a41f77e0ec69f26fa169b2338c2d09a03fafa3b4a54")
