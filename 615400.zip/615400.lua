-- Lua provided by RyzenAPI
-- Game: Make It Rain: Love of Money

-- MAIN APPLICATION
addappid(615400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(615401, 1, "3227076d52a1dd0cea5e7a41f77e0ec69f26fa169b2338c2d09a03fafa3b4a54")

