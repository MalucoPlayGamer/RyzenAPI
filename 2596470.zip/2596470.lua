-- Lua provided by RyzenAPI
-- Game: Ultrazone

-- MAIN APPLICATION
addappid(2596470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596471, 1, "687942b14de6abe1b8b0b1f14c74c21fc8f7206a320cc52ada6be662d87856b4")

