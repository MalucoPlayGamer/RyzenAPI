-- Lua provided by RyzenAPI
-- Game: addappid(2900)

-- MAIN APPLICATION
addappid(2900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901, 1, "1a3c15f9caf69370d23dcc3f3bcd2992ad5a3f6d379788752193cfdd03aa3434")
