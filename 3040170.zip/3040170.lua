-- Lua provided by RyzenAPI
-- Game: 3040170

-- MAIN APPLICATION
addappid(3040170)
-- Game: addappid(3040170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040171, 1, "ed860d978363fecd3be9bfe747dba050ecfd547babee8bedc36c656807388080")
