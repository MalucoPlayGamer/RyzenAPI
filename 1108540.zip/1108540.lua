-- Lua provided by SkyAPI 
-- Game: AppID 1108540
addappid(1108540)
addappid(1108541, 1, "31df55647ec10f7b1ccde0e65560f03d4a8f1f391219bf93fb3da2855a700ddd")
