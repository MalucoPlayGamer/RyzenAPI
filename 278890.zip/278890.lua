-- Lua provided by SkyAPI 
-- Game: Angvik
addappid(278890)
addappid(278891, 1, "f5de7e793c260bc21a70fcff5ebccbc2d4fa0e6260fc45386505d44bdc59b0e0")
addappid(278892, 1, "9eeff70a3104dca5022369b2891aafab79739f1d55b758cbb30e33ef340cca3b")
