-- Lua provided by RyzenAPI
-- Game: Angvik

-- MAIN APPLICATION
addappid(278890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(278891, 1, "f5de7e793c260bc21a70fcff5ebccbc2d4fa0e6260fc45386505d44bdc59b0e0")
addappid(278892, 1, "9eeff70a3104dca5022369b2891aafab79739f1d55b758cbb30e33ef340cca3b")

