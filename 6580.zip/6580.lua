-- Lua provided by RyzenAPI
-- Game: Lost Planet Demo

-- MAIN APPLICATION
addappid(6580)

-- MAIN APP DEPOTS / PACKAGES
addappid(6581, 1, "0e7cca4e54a0954661f36fa689aa2e546382d0d6d683a01a24258ff4a910be81")
