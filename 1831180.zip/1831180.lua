-- Lua provided by RyzenAPI
-- Game: addappid(1831180)

-- MAIN APPLICATION
addappid(1831180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831183,0,"21666c05a5b8093f157e0cb6ca6de88932d63f2652ade6d7ff865ad794ff1b6f")
