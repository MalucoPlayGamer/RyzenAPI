-- Lua provided by RyzenAPI
-- Game: 18Hell:Lost Demo

-- MAIN APPLICATION
addappid(2815190)
-- Game: addappid(2815190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815191, 1, "d39618fb8834e4caba9011901651052526d6ffadde7f507fb1153796123ddf88")
