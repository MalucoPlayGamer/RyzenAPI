-- Lua provided by SkyAPI 
-- Game: 18Hell:Lost Demo
addappid(2815190)
addappid(2815191, 1, "d39618fb8834e4caba9011901651052526d6ffadde7f507fb1153796123ddf88")
