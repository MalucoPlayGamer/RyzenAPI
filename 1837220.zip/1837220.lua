-- Lua provided by RyzenAPI
-- Game: addappid(1837220)

-- MAIN APPLICATION
addappid(1837220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837222,0,"c83011c2edec5e2fb1ef66934264aae56dd758b85b01e585cff126d860c0255d")
