-- Lua provided by RyzenAPI
-- Game: addappid(493980)

-- MAIN APPLICATION
addappid(493980)

-- MAIN APP DEPOTS / PACKAGES
addappid(493981, 1, "c72d822f53b08528fd1046f6755cc05be2fce6f69c99aaa0fdecb4cef3348ab9")
