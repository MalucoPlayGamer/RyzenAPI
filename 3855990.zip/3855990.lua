-- Lua provided by RyzenAPI
-- Game: Secrets of Salem: The Phantom Cab Collector's Edition

-- MAIN APPLICATION
addappid(3855990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3855991,0,"88688011b6196374f9c5d54eb0f92a1e68a01970d1ec36e9bd4abe2c73ed2d94")
addappid(3856310,0,"71a69bfd40e10970a4b3fb6bdbf2ada88851b27dbaefcd4c899b6a87f1eeae43")

