-- Lua provided by RyzenAPI
-- Game: Namariel Legends: Iron Lord Premium Edition

-- MAIN APPLICATION
addappid(302730)

-- MAIN APP DEPOTS / PACKAGES
addappid(302731, 1, "a793e48da0fe26e40c9d757384e20f1f65a958d1d61aae21ef7d4eaf64f02094")
addappid(302732, 1, "475b449a3a5afaf43cd16480618f546ef3d655f57b9d1c959182640d890c4db1")
addappid(302733, 1, "9f71711c8227dd59391728c7ac758b1d8f79fe187be606375b1933b42f37b668")
