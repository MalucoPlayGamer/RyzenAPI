-- Lua provided by RyzenAPI
-- Game: Game: AppID 2432660

-- MAIN APPLICATION
addappid(2432660)
-- Game: addappid(2432660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432661, 1, "c117259af446b3f6cfe8f38007b8bf612bcf832b737c95f393ef4895c14378c3")
