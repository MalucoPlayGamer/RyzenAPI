-- Lua provided by RyzenAPI
-- Game: Superbrothers: Sword & Sworcery EP - Soundtrack

-- MAIN APPLICATION
addappid(204075)

-- MAIN APP DEPOTS / PACKAGES
addappid(204075,0,"730be2d6757b81cc8f4de75b111894b4544a78883b154e31c91e255749a2692c")

