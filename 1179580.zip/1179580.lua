-- Lua provided by RyzenAPI
-- Game: Kaku Ancient Seal

-- MAIN APPLICATION
addappid(1179580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1179581, 1, "25bfa1d6d3edb9d1e31516745901555734cec90b16ef7f90644748fc08d3c45d")
addappid(1179583, 1, "7482a4a80ffc3b74077a4eda855e3d3c28226d587daee3307b582c1889df8bb4")
addappid(2987590, 0, "2d772ceb4a91f072b19ea1ae0ea489020a0af6e6828cef0e68994db2cb714fb8")
