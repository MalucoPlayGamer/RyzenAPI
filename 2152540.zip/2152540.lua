-- Lua provided by RyzenAPI
-- Game: 2152540

-- MAIN APPLICATION
addappid(2152540)
-- Game: addappid(2152540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152541, 1, "ad3c50af4537e35f10451e24a9752724ffcf7660bc900a4b98db05d7cfebcad5")
