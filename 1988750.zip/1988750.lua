-- Lua provided by RyzenAPI
-- Game: Project Crypt

-- MAIN APPLICATION
addappid(1988750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988751, 1, "e8c1505065638788eb6dae890dd10f1bad87482dfccd97b947a9286d53dc1183")
addappid(1988920, 0, "41e0d7caea311f9dde65109acc2e1d34c8cfa4ea82a8b82b9e4ada999ea8c09f")
