-- Lua provided by RyzenAPI
-- Game: Immortal Tales of Rebirth Demo

-- MAIN APPLICATION
addappid(2185620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185621, 1, "91e959b9c715051e404992047b0188e42a306b07d5b9d4db94a772dc3c11127e")
