-- Lua provided by RyzenAPI
-- Game: 3772400

-- MAIN APPLICATION
addappid(3772400)
-- Game: addappid(3772400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772403,0,"fab6d8cd92267f318cac0020ea5cdad7c02c1bf16cc4735715fb458e74726728")
