-- Lua provided by RyzenAPI
-- Game: Resonance Tales: Alone

-- MAIN APPLICATION
addappid(3772400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772403,0,"fab6d8cd92267f318cac0020ea5cdad7c02c1bf16cc4735715fb458e74726728")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
