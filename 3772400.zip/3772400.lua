-- Lua provided by RyzenAPI
-- Game: Resonance Tales: Alone

-- MAIN APPLICATION
addappid(3772400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772403,0,"fab6d8cd92267f318cac0020ea5cdad7c02c1bf16cc4735715fb458e74726728")
