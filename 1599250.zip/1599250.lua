-- Lua provided by RyzenAPI
-- Game: 1599250

-- MAIN APPLICATION
addappid(1599250)
-- Game: addappid(1599250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599251, 1, "bd98fc9ebcb7b9d6a075540cd7731fb179af448e87280b7eafc7c8d7a74cedbf")
