-- Lua provided by RyzenAPI
-- Game: AppID 258590

-- MAIN APPLICATION
addappid(258590)
-- Game: addappid(258590)

-- MAIN APP DEPOTS / PACKAGES
addappid(258591, 1, "1912a19b1a104b0e60bbf0232536b46aac05937defaa904ec9d0eaa12af275c5")
