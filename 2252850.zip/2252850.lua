-- Lua provided by RyzenAPI
-- Game: Game: IN THE BUILDING: CATS 3

-- MAIN APPLICATION
addappid(2252850)
-- Game: addappid(2252850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252851, 1, "018a1c33c6619029c2a6acd022f49287f9569db06f7d8b379b849d8abf061d9e")
