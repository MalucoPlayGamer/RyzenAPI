-- Lua provided by RyzenAPI 
-- Game: IN THE BUILDING: CATS 3
addappid(2252850)
addappid(2252851, 1, "018a1c33c6619029c2a6acd022f49287f9569db06f7d8b379b849d8abf061d9e")
