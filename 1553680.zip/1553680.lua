-- Lua provided by RyzenAPI
-- Game: Park Walk

-- MAIN APPLICATION
addappid(1553680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553681, 1, "75eb9db7ea5a5ba86fdd30b0a63a58e6bef4bb63f6112a13743a92e8aabf8266")

