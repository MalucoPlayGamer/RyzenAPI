-- Lua provided by RyzenAPI
-- Game: 2129220

-- MAIN APPLICATION
addappid(2129220)
-- Game: addappid(2129220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129221, 1, "2eccd19a3dc81eeda837865c0ed5bb9c9519a1c3b689a1c497f56c2e8283f8cf")
