-- Lua provided by RyzenAPI 
-- Game: Zoo Simulator
addappid(2129220)
addappid(2129221, 1, "2eccd19a3dc81eeda837865c0ed5bb9c9519a1c3b689a1c497f56c2e8283f8cf")
