-- Lua provided by RyzenAPI
-- Game: addappid(1448280)

-- MAIN APPLICATION
addappid(1448280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448280,0,"498343bfe0628fad872e65fae818cb3ecce9410c6d99b2122aba0b1d7425aa91")
