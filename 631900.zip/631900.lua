-- Lua provided by RyzenAPI
-- Game: Game: AppID 631900

-- MAIN APPLICATION
addappid(631900)
-- Game: addappid(631900)

-- MAIN APP DEPOTS / PACKAGES
addappid(631901, 1, "80f176a7cf341b79e80939a84800ab5ce3c4c668cc4e6cfd7f61a9e9883acae5")
