-- Lua provided by RyzenAPI
-- Game: AppID 631900

-- MAIN APPLICATION
addappid(631900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(631901, 1, "80f176a7cf341b79e80939a84800ab5ce3c4c668cc4e6cfd7f61a9e9883acae5")

