-- Lua provided by RyzenAPI 
-- Game: DrumBeats VR Demo
addappid(2151930)
addappid(2151931, 1, "f3b3706d50f7f2d7793780837baff1347dc8d830f120d2d4495d4abe528dc636")
