-- Lua provided by RyzenAPI
-- Game: AppID 363650

-- MAIN APPLICATION
addappid(363650)

-- MAIN APP DEPOTS / PACKAGES
addappid(363651, 1, "685e52bf7d8f8e621a83fc36ec5b782aaf1f84884ed9c55bebe74576f222f112")
addappid(363652, 1, "cea283c7d264276f7f110ecf8da1e4ea7f99c022b4bd42c16199bde7545fc401")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
