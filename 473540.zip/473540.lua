-- Lua provided by RyzenAPI
-- Game: Raise Your Own Clone

-- MAIN APPLICATION
addappid(473540)
addappid(473541)
addappid(473542)
addappid(473543)
addappid(473545)
-- Game: addappid(473540)

-- MAIN APP DEPOTS / PACKAGES
addappid(473544,0,"c76fb950ad7b4051ef7a6c7afe327f2da630d02252779e8a0694518c7ebedd77")
