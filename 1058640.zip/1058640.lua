-- Lua provided by RyzenAPI
-- Game: RED HOT VENGEANCE

-- MAIN APPLICATION
addappid(1058640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058641, 1, "12716c15bd614e2018fe764fea4f45628d5e6600dac5ff6762f49a984828ba95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
