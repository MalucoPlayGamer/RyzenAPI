-- Lua provided by RyzenAPI
-- Game: 1058640

-- MAIN APPLICATION
addappid(1058640)
-- Game: addappid(1058640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058641, 1, "12716c15bd614e2018fe764fea4f45628d5e6600dac5ff6762f49a984828ba95")
