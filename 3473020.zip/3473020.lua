-- Lua provided by RyzenAPI
-- Game: I'd Lowkey Simp for that Bussin Femboy at Work

-- MAIN APPLICATION
addappid(3473020)
-- Game: addappid(3473020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473021, 1, "6437dc0758b5aa22477bed53e80ed52b57c1863a14c8016d8b6f1442c00b126c")
