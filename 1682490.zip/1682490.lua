-- Lua provided by RyzenAPI
-- Game: Slender Threads: Prologue

-- MAIN APPLICATION
addappid(1682490)
