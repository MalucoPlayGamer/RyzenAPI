-- Lua provided by RyzenAPI
-- Game: SuperJumpWorld Rage

-- MAIN APPLICATION
addappid(2233040)
-- Game: addappid(2233040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233041, 1, "69e5c535172ef3df5f06fef308871db309c242871e6d8421eafe66494095e296")
