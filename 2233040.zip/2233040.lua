-- Lua provided by RyzenAPI 
-- Game: SuperJumpWorld Rage
addappid(2233040)
addappid(2233041, 1, "69e5c535172ef3df5f06fef308871db309c242871e6d8421eafe66494095e296")
