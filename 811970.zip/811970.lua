-- Lua provided by RyzenAPI
-- Game: Super Dream Dasher

-- MAIN APPLICATION
addappid(811970)

-- MAIN APP DEPOTS / PACKAGES
addappid(811971,0,"f37949672cd54fa42c3c75454138ac27dbf20fc5df3c046028e9a5fe1ebf2dd4")

