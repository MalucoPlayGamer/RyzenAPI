-- Lua provided by RyzenAPI
-- Game: DFF NT: Benevolent Maiden Appearance Set for Terra Branford

-- MAIN APPLICATION
addappid(1022494)
-- Game: addappid(1022494)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022494,0,"bcef6de57b5e7ddb4f6c8b7fb91dab9aed381cbe24297d52dfbcb1e42980ab51")
