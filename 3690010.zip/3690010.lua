-- Lua provided by RyzenAPI
-- Game: AppID 3690010

-- MAIN APPLICATION
addappid(3690010)
-- Game: addappid(3690010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690011, 1, "431713e84982bf2b2b2d0481c3679d3f610c02a2dbaa57b5164eac6647edc3fe")
