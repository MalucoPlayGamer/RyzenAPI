-- Lua provided by RyzenAPI
-- Game: 791180

-- MAIN APPLICATION
addappid(791180)
addappid(791181)
addappid(791183)
-- Game: addappid(791180)

-- MAIN APP DEPOTS / PACKAGES
addappid(791182,0,"b11ac30059e791d0ae407292a3c4d4f6eeb759b11580b793eed383b855f1500f")
