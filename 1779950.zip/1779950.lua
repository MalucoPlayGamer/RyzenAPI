-- Lua provided by RyzenAPI
-- Game: Goo Keeper

-- MAIN APPLICATION
addappid(1779950)
-- Game: addappid(1779950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779951, 1, "33912194b354be0048fed53e7250669f7739d413c0368824a07e5b011fabc02b")
