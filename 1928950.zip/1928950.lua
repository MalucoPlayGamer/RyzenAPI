-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1928950)
-- Game: addappid(1928950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928950,0,"9463899a00aa612dedd7236a4c87fdc795728cb10bddf943c5044e312d2c3c8e")
