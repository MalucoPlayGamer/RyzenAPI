-- Lua provided by RyzenAPI
-- Game: Game: AppID 707850

-- MAIN APPLICATION
addappid(707850)
-- Game: addappid(707850)

-- MAIN APP DEPOTS / PACKAGES
addappid(707851, 1, "973b85f607dbfdebbdc29f1975639b8e56461dfe30f0f14792857e04a53d988a")
