-- Lua provided by RyzenAPI
-- Game: Flash Party

-- MAIN APPLICATION
addappid(1799370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799371, 1, "e5d9710a680494b04f81085230bc800e95c08c26fd39bf49f7fc156cbd422a92")

