-- Lua provided by RyzenAPI
-- Game: Flash Party

-- MAIN APPLICATION
addappid(1799370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799371, 1, "e5d9710a680494b04f81085230bc800e95c08c26fd39bf49f7fc156cbd422a92")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2339190)
addappid(2339191)
addappid(2878880)
