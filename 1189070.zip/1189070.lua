-- Lua provided by RyzenAPI
-- Game: Game: Slimy Sextet

-- MAIN APPLICATION
addappid(1189070)
-- Game: addappid(1189070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189071, 1, "e3f4958fcb4fe4726da56dcfd41ab9d92ccaf993361aaeced1109c403270f2ae")
addappid(1189072, 1, "79df5f616a072426ab7449159796a2b1b2533e8060f11f8249181cf4dd7a25a0")
addappid(1189073, 1, "a45b30013a3e0fe285cb0126b899eda6b7b9569d9a22a644666e7519168c65e1")
