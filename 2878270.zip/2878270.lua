-- Lua provided by RyzenAPI
-- Game: Metal: Hellsinger VR

-- MAIN APPLICATION
addappid(2878270)
-- Game: addappid(2878270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878271, 1, "5fdfe573d4c6acbff70be0e896edaf541a7518c79aeed9288f26bf7ab375ae65")
