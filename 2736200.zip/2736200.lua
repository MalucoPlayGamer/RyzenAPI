-- Lua provided by RyzenAPI
-- Game: Moon Rider

-- MAIN APPLICATION
addappid(2736200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2736201, 1, "df7e0ea6d421c4273b26fcf1ed1ee1ed7c3a0e7bed671c5c1ff96c3f37c39b1b")

