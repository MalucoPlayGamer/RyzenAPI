-- Lua provided by RyzenAPI
-- Game: Moon Rider

-- MAIN APPLICATION
addappid(2736200)
-- Game: addappid(2736200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736201, 1, "df7e0ea6d421c4273b26fcf1ed1ee1ed7c3a0e7bed671c5c1ff96c3f37c39b1b")
