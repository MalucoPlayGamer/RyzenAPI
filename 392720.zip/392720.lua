-- Lua provided by RyzenAPI
-- Game: Game: Daily Espada

-- MAIN APPLICATION
addappid(392720)
-- Game: addappid(392720)

-- MAIN APP DEPOTS / PACKAGES
addappid(392721, 1, "ca76950b5fefd1fe75ac93568050ab1c2249245e0806af68ec490f73610663b0")
