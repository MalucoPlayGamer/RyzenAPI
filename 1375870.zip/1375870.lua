-- Lua provided by RyzenAPI
-- Game: 川建国同志想连任

-- MAIN APPLICATION
addappid(1375870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375871, 1, "896295cf8e0845d2097d36bad92e970ae6429b02cf7e7cfebb5f064c961753b6")
