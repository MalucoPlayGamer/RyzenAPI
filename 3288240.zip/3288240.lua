-- Lua provided by SkyAPI 
-- Game: AppID 3288240
addappid(3288240)
addappid(3288241, 1, "2d876d66af67f3e60c9cce32502c8f4e2e36728813d3dfb62996a9c753fbe8c6")
