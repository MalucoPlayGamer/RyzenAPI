-- Lua provided by RyzenAPI
-- Game: 3288240

-- MAIN APPLICATION
addappid(3288240)
-- Game: addappid(3288240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288241, 1, "2d876d66af67f3e60c9cce32502c8f4e2e36728813d3dfb62996a9c753fbe8c6")
