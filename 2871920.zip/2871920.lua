-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2871920)
-- Game: addappid(2871920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871922,0,"169a91ee181c3434d41a020929eb43057344ed701dcc3760ba8eb0be27849466")
