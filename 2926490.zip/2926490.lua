-- Lua provided by SkyAPI 
-- Game: AppID 2926490
addappid(2926490)
addappid(2926491, 1, "65bb97e3fa6c2a04769e4ed262162442c158d0c9fe1096de0fe051f1c7158a73")
