-- Lua provided by RyzenAPI
-- Game: Balls of Steel

-- MAIN APPLICATION
addappid(2050260)
-- Game: addappid(2050260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050261, 1, "478f9b42793dffda5caef092960c4bf38eae95107e9a35bba1d8cac259ab3592")
