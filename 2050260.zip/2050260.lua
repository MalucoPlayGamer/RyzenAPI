-- Lua provided by RyzenAPI
-- Game: Balls of Steel

-- MAIN APPLICATION
addappid(2050260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2050261, 1, "478f9b42793dffda5caef092960c4bf38eae95107e9a35bba1d8cac259ab3592")

