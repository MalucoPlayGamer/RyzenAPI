-- Lua provided by SkyAPI 
-- Game: 101 Cats in Shenzhen
addappid(3582780)
addappid(3582781, 1, "b7d6966360f754186ef58a2e0c9e0af17825be6a8cb067404bd21a493ea022f6")
