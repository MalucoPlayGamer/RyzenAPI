-- Lua provided by RyzenAPI 
-- Game: Alien Gladiator
addappid(2061270)
addappid(2061271, 1, "e10a0d73cb981575d0f33031e7af69b399b22d1c5b35d0f3286781875ab1b3b0")
