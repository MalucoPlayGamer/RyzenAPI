-- Lua provided by RyzenAPI
-- Game: Toing's Pops

-- MAIN APPLICATION
addappid(2349760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349761, 1, "242f9f0fd1a836680aee53a0063f423931a232a3f23e6271e2819b6f6d90028a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
