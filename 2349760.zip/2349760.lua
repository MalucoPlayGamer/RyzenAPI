-- Lua provided by RyzenAPI
-- Game: Game: Toing's Pops

-- MAIN APPLICATION
addappid(2349760)
-- Game: addappid(2349760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349761, 1, "242f9f0fd1a836680aee53a0063f423931a232a3f23e6271e2819b6f6d90028a")
