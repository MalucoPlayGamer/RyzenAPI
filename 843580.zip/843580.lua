-- Lua provided by RyzenAPI 
-- Game: DotLine
addappid(843580)
addappid(843581, 1, "dfa5e2f18e3e2a01ed4a96acada370c7f93edb5b82149b330e5702efe0c42b76")
addappid(843584, 1, "c5221659c4cec8eebc3ad75f370a3cc54f6e51b6e3e39faf91377941aba8d7c7")
