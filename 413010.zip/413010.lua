-- Lua provided by RyzenAPI
-- Game: addappid(413010)

-- MAIN APPLICATION
addappid(413010)

-- MAIN APP DEPOTS / PACKAGES
addappid(413011, 1, "9a52d05549beecb0d6bb8ef8eea8c868fc72238a21320dd034f91db05cbde614")
