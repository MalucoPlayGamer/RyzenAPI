-- Lua provided by RyzenAPI 
-- Game: AppID 941460
addappid(941460)
addappid(941461, 1, "b0d0698bc15a83cab9fc71594a209515ae28c498aa7bb7fc0adc69adee219d8e")
addappid(941462, 1, "e252486cfcecfda173f7951b9bcc40f6089025ee745ff0d63302425863b04bf1")
addappid(941463, 1, "37ba5ad4fd87107b0094639a47dbeb9b4fa86eac62e3d7a2e226bcf0d76dff2e")
