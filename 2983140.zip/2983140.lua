-- Lua provided by RyzenAPI
-- Game: Game: Trials of Innocence

-- MAIN APPLICATION
addappid(2983140)
-- Game: addappid(2983140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983141, 1, "e5c1c6fcbc504b4de16dc3c37c6992c4d18c6333676321a396808c3d27682714")
