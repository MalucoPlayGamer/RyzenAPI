-- Lua provided by RyzenAPI
-- Game: Now I Am There

-- MAIN APPLICATION
addappid(1112370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112371, 1, "99b9b87294533018d6dbc2eba924fdc264e4623924a0773ee292a6ea3f734986")
