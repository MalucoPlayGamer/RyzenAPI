-- Lua provided by SkyAPI 
-- Game: Xargon Remake Ep.3
addappid(2447530)
addappid(2447531, 1, "ffc7ece858b6fcf52a7f30ac1b29aa05c2caf6861b977e0268c1e0904dc766ea")
