-- Lua provided by RyzenAPI
-- Game: addappid(2447530)

-- MAIN APPLICATION
addappid(2447530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447531, 1, "ffc7ece858b6fcf52a7f30ac1b29aa05c2caf6861b977e0268c1e0904dc766ea")
