-- Lua provided by SkyAPI 
-- Game: AppID 1847640
addappid(1847640)
addappid(1847641, 1, "f12fb682e945e88c6d05ef3067b8f5875eec3ab79f5ca5720292a92956df9f4f")
