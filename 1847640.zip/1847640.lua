-- Lua provided by RyzenAPI
-- Game: addappid(1847640)

-- MAIN APPLICATION
addappid(1847640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847641, 1, "f12fb682e945e88c6d05ef3067b8f5875eec3ab79f5ca5720292a92956df9f4f")
