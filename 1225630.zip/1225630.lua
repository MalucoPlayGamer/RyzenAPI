-- Lua provided by RyzenAPI
-- Game: AppID 1225630

-- MAIN APPLICATION
addappid(1225630)
-- Game: addappid(1225630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225631, 1, "531db317fb194e7f3930bbda36af0249032589cd0049350e9c2170fb6c254d1f")
addappid(1225632, 1, "c3e47cba163c0bb912a95f57fc3783dc564a9c5fd42cc00d9666780f14ff1adb")
