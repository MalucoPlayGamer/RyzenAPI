-- Lua provided by RyzenAPI
-- Game: Game: Sir Fallen

-- MAIN APPLICATION
addappid(2880990)
-- Game: addappid(2880990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880991, 1, "97e55fe68ea874ee212396012632c9e06689767f12edd773117c80d5dac2363d")
