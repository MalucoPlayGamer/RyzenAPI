-- Lua provided by SkyAPI 
-- Game: Boris and the Dark Survival
addappid(1236990)
addappid(1236991, 1, "243ffcce0fc7f09aa201a1876503a74ad534666bc12b3a0572c8f4ca88e32afc")
addappid(1236992, 1, "49b3e55cb2bf421f2b1c86e4a9244c2b9d43b99085f371ce60cfb0d7898950fd")
addappid(1236993, 1, "9a7a054e2110835d8625025661ec1b5f409e0c0f161cfdb4a7c4d6f22819054a")
