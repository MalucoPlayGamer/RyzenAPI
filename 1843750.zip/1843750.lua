-- Lua provided by RyzenAPI
-- Game: Sphere Game Epic

-- MAIN APPLICATION
addappid(1843750)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1843751, 1, "afc729888ba167060c7733615dad923cdfe2c921a7318d132059329e564432c5")

