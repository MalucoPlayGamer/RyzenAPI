-- Lua provided by RyzenAPI
-- Game: Sphere Game Epic

-- MAIN APPLICATION
addappid(1843750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843751, 1, "afc729888ba167060c7733615dad923cdfe2c921a7318d132059329e564432c5")
