-- Lua provided by RyzenAPI
-- Game: 2560490

-- MAIN APPLICATION
addappid(2560490)
-- Game: addappid(2560490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560491, 1, "e7654f3286926baab5357d0032334de75c05ad7445351aa685ad4dd8c18af751")
