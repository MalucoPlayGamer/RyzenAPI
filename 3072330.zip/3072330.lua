-- Lua provided by RyzenAPI
-- Game: Game: Board Wars - Trick Or Treat Playtest

-- MAIN APPLICATION
addappid(3072330)
-- Game: addappid(3072330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072331, 1, "5bac3e4df9dddfba7bbeee94d04a1c0244a094a20d30ce372f13f057cc5e0673")
