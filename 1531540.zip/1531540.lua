-- Lua provided by RyzenAPI
-- Game: Distant Worlds 2

-- MAIN APPLICATION
addappid(1531540)
addappid(3350550)
addappid(3989670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1531541, 1, "9b9fa09921729c938191534f1f6e81de525e236fc054ac17d94d244e17325066")
addappid(1531542, 1, "d3ad118ab7b59fa205beffca68585bc8c56dc8067fe634d8fffa302ac704fc2b")
addappid(2140010, 0, "9816b2e90deea55cab853826a6be8d3cdbe88dbc77fc7fd4a36b0eec139a8407")
addappid(2409480, 0, "6ad516f28fe48285424f2de097c3132bb5b8610db316d7ff542aebbe200c9b6c")
addappid(2926560, 0, "feb295904155c907424456a59ee15bedd5586368f9067c88ab1fa8ea45fc3415")

