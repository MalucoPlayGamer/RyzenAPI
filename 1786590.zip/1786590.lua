-- Lua provided by RyzenAPI
-- Game: Game: Elisa Dragon Hunter

-- MAIN APPLICATION
addappid(1786590)
-- Game: addappid(1786590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786591, 1, "9aa3435e491e8f19402d24ec51d3ef71be97defbfaad6a38d11eb4bab924a5f6")
