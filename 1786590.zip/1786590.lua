-- Lua provided by RyzenAPI
-- Game: Elisa Dragon Hunter

-- MAIN APPLICATION
addappid(1786590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786591, 1, "9aa3435e491e8f19402d24ec51d3ef71be97defbfaad6a38d11eb4bab924a5f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
