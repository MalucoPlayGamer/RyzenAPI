-- Lua provided by RyzenAPI
-- Game: AColony

-- MAIN APPLICATION
addappid(1200570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200571, 1, "f0d6a4fd975b453d490b910f6306aee2c28cba84dd1617859ad6762e6f032fbc")
