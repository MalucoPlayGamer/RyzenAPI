-- Lua provided by RyzenAPI
-- Game: Game: Hentai Casual Slider 3

-- MAIN APPLICATION
addappid(2324340)
-- Game: addappid(2324340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324341, 1, "5ffacb427c99fe0b7b49407a115b9c90cced44c1483aa5da03323d032f6bb033")
