-- Lua provided by SkyAPI 
-- Game: diorama
addappid(2887460)
addappid(2887461, 1, "e7863edafadc599269ec41947d8cd680d98bb986bd402249383ba5ffc80e708b")
