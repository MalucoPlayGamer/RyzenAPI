-- Lua provided by RyzenAPI
-- Game: 624070

-- MAIN APPLICATION
addappid(624070)
-- Game: addappid(624070)

-- MAIN APP DEPOTS / PACKAGES
addappid(624071, 1, "9243827d86b8c4f6967833bf0cbc8c4bafaca2f14c039a9a3dca97cdf276af1c")
