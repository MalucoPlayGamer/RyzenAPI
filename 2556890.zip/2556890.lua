-- Lua provided by RyzenAPI
-- Game: AppID 2556890

-- MAIN APPLICATION
addappid(2556890)
-- Game: addappid(2556890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556891, 1, "ac1985a39fde4ee439ae862ac8032ce72044d706b4406eb226a24d3abd8932d9")
