-- Lua provided by RyzenAPI
-- Game: How 2 Escape

-- MAIN APPLICATION
addappid(2264140)
-- Game: addappid(2264140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264141, 1, "3db62778fc59189fb1123648e3ef5869bd29438a0e7064cc150a14d9126775f7")
