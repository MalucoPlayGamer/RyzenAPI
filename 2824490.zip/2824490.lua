-- Lua provided by RyzenAPI
-- Game: He is Coming

-- MAIN APPLICATION
addappid(2824490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824491, 1, "45177edbe7628464050348bfcda5ce52d6fbdb93077801632ef6f85821601920")

