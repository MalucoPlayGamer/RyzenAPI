-- Lua provided by RyzenAPI
-- Game: Black Sails

-- MAIN APPLICATION
addappid(373240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(373241, 1, "b1a41680cc96dfdb9f0bc39ad493f0ee1b753b217d0ed3b486d8f1ef4c42d11a")
addappid(373242, 1, "7a0e6475f6d9856c02a30a5c3d8053a1a72cca78586b949dc92bb3d806b68c07")
addappid(373243, 1, "ecf7cd7c683d1bb1ceb55aa8474ce49496d6aa7039926200af4de2a35f079682")
