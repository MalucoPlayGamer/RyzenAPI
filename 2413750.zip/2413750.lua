-- Lua provided by SkyAPI 
-- Game: AppID 2413750
addappid(2413750)
addappid(2413751, 1, "b0f155c2c42a45bd84127489d503a490c7e7271a7ab5f645a8cff55a5f893227")
