-- Lua provided by RyzenAPI
-- Game: Game: Alien

-- MAIN APPLICATION
addappid(2203780)
-- Game: addappid(2203780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203781, 1, "e845b9067f449b83656ecde2e033ad4f82d339393fbba6ac0b48675b942ad65d")
