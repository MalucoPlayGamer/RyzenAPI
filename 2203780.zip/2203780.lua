-- Lua provided by RyzenAPI 
-- Game: Alien
addappid(2203780)
addappid(2203781, 1, "e845b9067f449b83656ecde2e033ad4f82d339393fbba6ac0b48675b942ad65d")
