-- Lua provided by RyzenAPI
-- Game: Game: Hikki Girls

-- MAIN APPLICATION
addappid(2114710)
-- Game: addappid(2114710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114711, 1, "f86e0d5a48e8cc6853ab5f1df85d4f97339f8e79a1e4e7832e707966848d36af")
