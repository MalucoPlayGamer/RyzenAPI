-- Lua provided by RyzenAPI
-- Game: Shinehill Demo

-- MAIN APPLICATION
addappid(2581150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581151, 1, "2cd859e5c9aeb42e74e3d20691090c6dd0d897a37f2e31a90930fc927dbbd0c4")

