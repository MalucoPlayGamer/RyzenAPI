-- Lua provided by RyzenAPI
-- Game: addappid(2997750)

-- MAIN APPLICATION
addappid(2997750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997751, 1, "9088f833e16c57da9a19e2603a4af6bc66883681fa1b4aed22839e2e6343b68d")
