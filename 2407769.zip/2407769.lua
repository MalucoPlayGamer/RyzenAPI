-- Lua provided by RyzenAPI
-- Game: 2407769

-- MAIN APPLICATION
addappid(2407769)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407769,0,"5085deacdd4aa455744ebfb3a6060a8a8650dedbe0f5e98d1ec3060c8d1a76d3")
