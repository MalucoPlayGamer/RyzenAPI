-- Lua provided by RyzenAPI
-- Game: Game: Succumate

-- MAIN APPLICATION
addappid(1278390)
-- Game: addappid(1278390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278391, 1, "c73cf811ce87ba1ffda9def10319a086324aa5b3a109cca8d663ca91ab825370")
addappid(1278392, 1, "f9728bc156eea5f8fb6576df3ead43c7b9c517b3812c2954481f0c57fb382295")
addappid(1278393, 1, "c1c84d0ce637c7f3c1da4b9d712d46ce6539b2c1bbaa491f915cab28724ac330")
