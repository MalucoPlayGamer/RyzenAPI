-- Lua provided by RyzenAPI
-- Game: Game: AppID 1289060

-- MAIN APPLICATION
addappid(1289060)
-- Game: addappid(1289060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289061, 1, "bc124817e1dc8c88a0a14223c98c480aa5908fd4b1028118b32ff4c0a7778954")
