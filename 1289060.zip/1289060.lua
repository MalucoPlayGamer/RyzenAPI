-- Lua provided by RyzenAPI
-- Game: No One But You

-- MAIN APPLICATION
addappid(1289060)
addappid(5047030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289061, 1, "bc124817e1dc8c88a0a14223c98c480aa5908fd4b1028118b32ff4c0a7778954")

