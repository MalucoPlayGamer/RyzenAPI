-- Lua provided by RyzenAPI
-- Game: Gangs of Sherwood Demo

-- MAIN APPLICATION
addappid(2581440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581441, 1, "10e0ca1184d0e3f36a01d4ab618b6b704248f9207960bb71b2abde05a462e152")
