-- Lua provided by RyzenAPI
-- Game: Game: AppID 2581440

-- MAIN APPLICATION
addappid(2581440)
-- Game: addappid(2581440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581441, 1, "10e0ca1184d0e3f36a01d4ab618b6b704248f9207960bb71b2abde05a462e152")
