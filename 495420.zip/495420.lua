-- Lua provided by RyzenAPI
-- Game: State of Decay 2: Juggernaut Edition

-- MAIN APPLICATION
addappid(495420)

-- MAIN APP DEPOTS / PACKAGES
addappid(495422,0,"82873486e64ba05260f583a4a80f88755f1a2422e37db46396fca015a35e966d")
addappid(495423,0,"ae5ec7c2bc2d211ef82c94e26d5fb9ac2e75be1d90fd5d3cf9bcaee2d5159a53")
