-- Lua provided by RyzenAPI
-- Game: War Of Castles Demo

-- MAIN APPLICATION
addappid(2832120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832121, 1, "3e263ad6562b7920a665b625fe7b837834949d927349881f8b220102afcfc53f")
