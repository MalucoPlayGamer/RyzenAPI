-- Lua provided by RyzenAPI
-- Game: Twin Hawk

-- MAIN APPLICATION
addappid(2023020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023021, 1, "8280217bab827786f27af187dca8080e28d69b0384fcb8b7bd0d0d634a5fb470")
