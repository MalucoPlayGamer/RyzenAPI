-- Lua provided by SkyAPI 
-- Game: Amerzone - The Explorer's Legacy
addappid(2429190)
addappid(2429191, 1, "795c6e2f938e195ef9d62a34c064f1df89b670d9d7c101d9680d270950684e80")
addappid(3544420, 0, "3065376e6093078763c1f0d8844e0466a9fa1a1cf4d876dd2ec96657c88e9107")
