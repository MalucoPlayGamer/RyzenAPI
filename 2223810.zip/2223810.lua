-- Lua provided by RyzenAPI
-- Game: Hedgewars

-- MAIN APPLICATION
addappid(2223810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223811, 1, "9af4cb8336b815e6e72c08be43aca2ab39bc14cd9dee34672419ed9d8bd6a945")
addappid(2223812, 1, "631bdd4dca54fbee605be8a8e61c25bedd9848b7455d75f96f50b635a639584c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
