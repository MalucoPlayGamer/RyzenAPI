-- Lua provided by RyzenAPI
-- Game: Triple Take

-- MAIN APPLICATION
addappid(1734250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734251, 1, "7a7aeb5aff7cf0280a43b324875489a849c11f5dd9e2b7130318d82e44875b47")

