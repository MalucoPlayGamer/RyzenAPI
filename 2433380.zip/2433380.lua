-- Lua provided by RyzenAPI
-- Game: 2433380

-- MAIN APPLICATION
addappid(2433380)
-- Game: addappid(2433380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433381, 1, "15a4d89ad3ecc1cd7364d0fb2a9b4b129f88bdd8e79753682219612273a97394")
