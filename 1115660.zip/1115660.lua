-- Lua provided by RyzenAPI
-- Game: 1115660

-- MAIN APPLICATION
addappid(1115660)
-- Game: addappid(1115660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115661, 1, "f29e490e2f975f66fcc86dc6e78d92bb09e3c285b3d4c9573e923f30b903f5f6")
