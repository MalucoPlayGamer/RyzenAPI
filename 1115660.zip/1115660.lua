-- Lua provided by RyzenAPI
-- Game: Apollo 11 VR HD: First Steps

-- MAIN APPLICATION
addappid(1115660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1115661, 1, "f29e490e2f975f66fcc86dc6e78d92bb09e3c285b3d4c9573e923f30b903f5f6")
