-- Lua provided by SkyAPI 
-- Game: AppID 1115660
addappid(1115660)
addappid(1115661, 1, "f29e490e2f975f66fcc86dc6e78d92bb09e3c285b3d4c9573e923f30b903f5f6")
