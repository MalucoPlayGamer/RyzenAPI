-- Lua provided by RyzenAPI
-- Game: ROCK

-- MAIN APPLICATION
addappid(515900)
-- Game: addappid(515900)

-- MAIN APP DEPOTS / PACKAGES
addappid(515901, 1, "7b5404d397def794566dcd8829e246e96c7b030539ab90d1cc3084ba682cefc6")
