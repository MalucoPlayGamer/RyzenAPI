-- Lua provided by RyzenAPI 
-- Game: Alice Trapped Beyond Wonderland
addappid(1710250)
addappid(1710251, 1, "895ead5336701e1d895727d021ed6c16ec28140e5101d43bf24fad902aaac1fa")
