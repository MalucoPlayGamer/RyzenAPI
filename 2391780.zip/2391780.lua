-- Lua provided by RyzenAPI
-- Game: Hime's Blossom

-- MAIN APPLICATION
addappid(2391780)
addappid(2418330)
-- Game: addappid(2391780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391781, 1, "f6b91ce3df8f14b075e84b3440e737df3991de17cc7e067b9e26ae331389b212")
