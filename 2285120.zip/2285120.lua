-- Lua provided by RyzenAPI
-- Game: Hentai Hasshaku

-- MAIN APPLICATION
addappid(2285120)
-- Game: addappid(2285120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285121, 1, "dd78fd353e2ad52c678a5a0a3d816d6f025a5d986c877e02186b866c68059bba")
addappid(2285122, 1, "e4ccb47a71cf83c39cde6312ef37dd7932e13d5b8f643d535c7e6b810f3c9c5b")
addappid(2285123, 1, "ffeead06faa7b0bb4388b34bf7d36f4ab76fde6226a119f2009cb8be07dd6441")
