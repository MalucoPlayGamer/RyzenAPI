-- Lua provided by RyzenAPI
-- Game: Minecraft Dungeons Ultimate Edition Digital Artwork

-- MAIN APPLICATION
addappid(1726570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726570,0,"0e89af5042b93fdac6bf07b8155a9addf8bc19a556fed00a326ece6e7c9e7a14")

