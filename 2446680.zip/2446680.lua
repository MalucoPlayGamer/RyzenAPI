-- Lua provided by RyzenAPI
-- Game: Drive Me to Hell

-- MAIN APPLICATION
addappid(2446680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446681, 1, "b944cface5238d50b658c633fded5839cad0cf1981fcdfe38702ca98fb8063b0")
