-- Lua provided by RyzenAPI
-- Game: Game: Australian trip

-- MAIN APPLICATION
addappid(757870)
-- Game: addappid(757870)

-- MAIN APP DEPOTS / PACKAGES
addappid(757871, 1, "19812b28f9bc33219b73665b08c92ec73a5603a9c81064323df39e2ef6cf23a6")
addappid(774111, 0, "0d7bb7bbc273bf765cf96aff74c4597bad88f647922c570473260e5c73f7d055")
