-- Lua provided by RyzenAPI
-- Game: Brick Breaker with Risa

-- MAIN APPLICATION
addappid(910420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(910421, 1, "18b5b841be2690f51bf50e33e3dc884986ed541e28ea4be5dee64ecfe32161c6")

