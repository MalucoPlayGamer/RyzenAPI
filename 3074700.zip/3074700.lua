-- Lua provided by SkyAPI 
-- Game: The Lewd Deal (Full Version)
addappid(3074700)
addappid(3074701, 1, "7457ac22d932970cca6421f678500b938437250fe2b2c7f8ddfc26099a02bbf7")
