-- Lua provided by RyzenAPI
-- Game: The Lewd Deal (Full Version)

-- MAIN APPLICATION
addappid(3074700)
-- Game: addappid(3074700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074701, 1, "7457ac22d932970cca6421f678500b938437250fe2b2c7f8ddfc26099a02bbf7")
