-- Lua provided by RyzenAPI
-- Game: AppID 1326330

-- MAIN APPLICATION
addappid(1326330)
-- Game: addappid(1326330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326331, 1, "f32a2a1444b718eefaa00c025a749505ef94f3620b38836df66bea547ed96d4c")
