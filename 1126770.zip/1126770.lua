-- Lua provided by RyzenAPI
-- Game: My Bones Remastered

-- MAIN APPLICATION
addappid(1126770)
-- Game: addappid(1126770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126771, 1, "eaafcad80fc5d7562ad2e935442d6235830c2467dce78e1b0093b1648ca9736d")
