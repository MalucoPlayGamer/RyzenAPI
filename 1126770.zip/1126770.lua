-- Lua provided by RyzenAPI
-- Game: My Bones Remastered

-- MAIN APPLICATION
addappid(1126770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1126771, 1, "eaafcad80fc5d7562ad2e935442d6235830c2467dce78e1b0093b1648ca9736d")

