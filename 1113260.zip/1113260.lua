-- Lua provided by RyzenAPI
-- Game: Clea Demo

-- MAIN APPLICATION
addappid(1113260)
-- Game: addappid(1113260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113261, 1, "71af92cf749cd2b0a97c2fbc95f606e0c257a44404e1a65bfaa218493bc69b7e")
