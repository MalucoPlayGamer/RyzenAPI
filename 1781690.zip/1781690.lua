-- Lua provided by RyzenAPI
-- Game: Doki Doki Literature Club Plus! Soundtrack

-- MAIN APPLICATION
addappid(1781690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781691, 1, "66b646de1c36199da253abf3d61776aaf1ba10ae2dc4585bc4efd2a6b0841f84")
addappid(1781692, 1, "2b1596f76779b59423938902dc4e12697469fcff02457a50620e66f771bbbf8a")

