-- Lua provided by RyzenAPI
-- Game: Nightmare Flight

-- MAIN APPLICATION
addappid(3252610)
-- Game: addappid(3252610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252611, 1, "e5445535020128a215ebd7a00dfba300865341ef5df9a44b0892a43055262c06")
