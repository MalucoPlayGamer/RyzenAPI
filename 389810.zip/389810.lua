-- Lua provided by SkyAPI 
-- Game: Rubber and Lead
addappid(389810)
addappid(389811, 1, "b3831cb8034d55113a2009b81fa191df03b91f222e99dc2767491fc1f95e7284")
