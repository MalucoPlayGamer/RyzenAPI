-- Lua provided by RyzenAPI
-- Game: 389810

-- MAIN APPLICATION
addappid(389810)
-- Game: addappid(389810)

-- MAIN APP DEPOTS / PACKAGES
addappid(389811, 1, "b3831cb8034d55113a2009b81fa191df03b91f222e99dc2767491fc1f95e7284")
