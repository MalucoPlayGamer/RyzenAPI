-- Lua provided by RyzenAPI
-- Game: Arthur and his companions

-- MAIN APPLICATION
addappid(3128840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128841, 1, "dd389f301481196022542fbc51caa8a5e227fe5494036b09ba7b48749661d3e1")
