-- Lua provided by RyzenAPI
-- Game: Hentai Match Fantasy Stories

-- MAIN APPLICATION
addappid(1196750)
addappid(1204100)
addappid(1209590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196751, 1, "54735d7f2eba3833a070a3c57135123ab6aad6530ff65c3c80e95270796bbaf5")

