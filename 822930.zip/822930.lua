-- Lua provided by RyzenAPI 
-- Game: Wolf Tails
addappid(822930)
addappid(822931, 1, "64e4b8c57c4cdac75d01965c2737718ad8e4e3965c9fc096fb61a3c8cd10c5fa")
addappid(943850, 0, "3520061771aea987b335ccf11b2afadf9862d50a9156c9dbc69ef4547bd0ccf3")
