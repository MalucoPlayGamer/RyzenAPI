-- Lua provided by RyzenAPI
-- Game: Hacker Evolution - 2019 HD remaster

-- MAIN APPLICATION
addappid(1153990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153991, 1, "54e527d38d2d0043c666a704651faa2cab1409a18461491c67a3f9f9df643769")

