-- Lua provided by RyzenAPI
-- Game: addappid(486780)

-- MAIN APPLICATION
addappid(486780)

-- MAIN APP DEPOTS / PACKAGES
addappid(486781, 1, "73e99b5d11e909a339f64ea7fd62c87a0b548350315c8f5be3903ab98d0b9323")
