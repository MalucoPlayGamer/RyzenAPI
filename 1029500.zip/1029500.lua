-- Lua provided by RyzenAPI
-- Game: Created: August 15, 2026 at 21:37:33 EDT

-- MAIN APPLICATION
addappid(1060270) -- -
addappid(1062570)
addappid(1206750)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
addappid(1029500, 1, "b6de10dd1d40d20ce078fc63bc8aa79686c7e6a5351056774d91a061ff789699") -- 中华三国志
addappid(1029501, 1, "1bcf5cc35a653ddd8bc273549f36d8f1ad9e9410cb0ec49fb0c0eb9b96458c7b") -- 中华三国志 Content
addappid(1062571, 1, "6895423af57040b7d15f6d4b9b654602942d7a6b32442209c2177229307a6618") -- - - Depot 1062571
addappid(1206751, 1, "4f982c54da4a17cc811b02283613f03a3697940ecbcaf0037cde47c91c869daa") -- -DP - Depot 1206751

