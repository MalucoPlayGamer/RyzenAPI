-- Lua provided by RyzenAPI
-- Game: 中华三国志 the Three Kingdoms of China

-- MAIN APPLICATION
addappid(1029500)
-- Game: addappid(1029500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029501, 1, "1bcf5cc35a653ddd8bc273549f36d8f1ad9e9410cb0ec49fb0c0eb9b96458c7b")
