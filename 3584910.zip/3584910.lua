-- Lua provided by RyzenAPI
-- Game: AppID 3584910

-- MAIN APPLICATION
addappid(3584910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584911, 1, "66e8d4fd5eb44b78aed45686d8bc0a7d519f7055a9556f6dd2260a4eae0bef51")

