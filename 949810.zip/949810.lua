-- Lua provided by RyzenAPI
-- Game: Go Cabbies!GB

-- MAIN APPLICATION
addappid(949810)

-- MAIN APP DEPOTS / PACKAGES
addappid(949811, 1, "4e89a9152cf419c7c16345c49bf7324bd0806615b6400e5c1a81f750b9490ad5")
