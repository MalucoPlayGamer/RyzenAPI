-- Lua provided by SkyAPI 
-- Game: A Story of a Band
addappid(856450)
addappid(856451, 1, "040777ae389eb9589102f6a8dde14a22b90031e844272b74fea80a6e2560cb2e")
