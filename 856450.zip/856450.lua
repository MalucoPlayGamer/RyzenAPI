-- Lua provided by RyzenAPI
-- Game: A Story of a Band

-- MAIN APPLICATION
addappid(856450)
-- Game: addappid(856450)

-- MAIN APP DEPOTS / PACKAGES
addappid(856451, 1, "040777ae389eb9589102f6a8dde14a22b90031e844272b74fea80a6e2560cb2e")
