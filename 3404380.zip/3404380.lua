-- Lua provided by RyzenAPI
-- Game: 3404380

-- MAIN APPLICATION
addappid(3404380)
-- Game: addappid(3404380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404382,0,"818485af983e18f1c080cf76dc693e2870c44ea432fe723b155dde4a57f45cda")
