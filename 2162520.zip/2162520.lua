-- Lua provided by RyzenAPI 
-- Game: Emilia's PLAYROOM
addappid(2162520)
addappid(2162521, 1, "0a141907d91fdc5b1ee3bc62509f6449c39a4d5b79964c7af88d8b617557249d")
