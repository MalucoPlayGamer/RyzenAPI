-- Lua provided by RyzenAPI
-- Game: NoLimits 2 Roller Coaster Simulation Demo

-- MAIN APPLICATION
addappid(319260)
-- Game: addappid(319260)

-- MAIN APP DEPOTS / PACKAGES
addappid(319261, 1, "230e10ac59160c7eb6a48559a2d3dfeff762286b159f481d39af4033e6e6153f")
addappid(319262, 1, "5266366b21c25abb6122b798e85ebc43df799883a6ef8e89dd9aba575ecd3d2d")
