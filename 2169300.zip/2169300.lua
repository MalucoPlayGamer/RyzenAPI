-- Lua provided by RyzenAPI
-- Game: 2169300

-- MAIN APPLICATION
addappid(2169300)
-- Game: addappid(2169300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169301, 1, "873d4b3be583c92ca4a54b069ce491d5a6fce18fc285e2c086e14db0d724a454")
