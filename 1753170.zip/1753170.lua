-- Lua provided by RyzenAPI 
-- Game: DKLS
addappid(1753170)
addappid(1753171, 1, "a2120ab43f01e4741f0c9ee4c0fb72c98262640dbbe2e0ef56b94f72f067125a")
