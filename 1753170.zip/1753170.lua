-- Lua provided by RyzenAPI
-- Game: DKLS

-- MAIN APPLICATION
addappid(1753170)
-- Game: addappid(1753170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753171, 1, "a2120ab43f01e4741f0c9ee4c0fb72c98262640dbbe2e0ef56b94f72f067125a")
