-- Lua provided by SkyAPI 
-- Game: AppID 627690
addappid(627690)
addappid(627691, 1, "9b04a90eb1fc2e60c89a05c355d782cdcbf603d230049f2680ba62a0e31568a1")
addappid(627692, 1, "60b015ccb209fe46a46a5f629b7aa1383928eb6aad0d3eb7e23d6e94684452f6")
