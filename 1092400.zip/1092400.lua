-- Lua provided by RyzenAPI
-- Game: AppID 1092400

-- MAIN APPLICATION
addappid(1092400)
-- Game: addappid(1092400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092401, 1, "bbb6799cb0c47c8bdaa611f2d59186b8e784fe0d2c7e78f946a4aad7fed57bf0")
