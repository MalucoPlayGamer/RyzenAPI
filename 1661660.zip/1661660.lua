-- Lua provided by RyzenAPI
-- Game: 1661660

-- MAIN APPLICATION
addappid(1661660)
-- Game: addappid(1661660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661661, 1, "437143636aab1db4eada577001f7967e9c3df7661971a12d25270fe428b167bc")
