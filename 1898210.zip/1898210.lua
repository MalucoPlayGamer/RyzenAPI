-- Lua provided by RyzenAPI 
-- Game: Eros Fantasy
addappid(1898210)
addappid(1898211, 1, "3c0ff465d076b14a7bbbd9b515f36204c899288f9243af21a7a59e4d7349e41d")
