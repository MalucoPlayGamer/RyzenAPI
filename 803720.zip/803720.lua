-- Lua provided by RyzenAPI 
-- Game: War Theatre
addappid(803720)
addappid(803721, 1, "ec258167860f9b7688554c4310317d7f41e2713778aab5ddcbf1756423ed25fb")
addappid(803722, 1, "c1165f25976fcfda59e4cefe4a18338bf38c0c16bbd11852ed1caf65095f651e")
