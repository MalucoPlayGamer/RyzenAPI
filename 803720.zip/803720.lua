-- Lua provided by RyzenAPI
-- Game: War Theatre

-- MAIN APPLICATION
addappid(803720)

-- MAIN APP DEPOTS / PACKAGES
addappid(803721, 1, "ec258167860f9b7688554c4310317d7f41e2713778aab5ddcbf1756423ed25fb")
addappid(803722, 1, "c1165f25976fcfda59e4cefe4a18338bf38c0c16bbd11852ed1caf65095f651e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
