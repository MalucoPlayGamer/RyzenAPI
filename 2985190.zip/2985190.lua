-- Lua provided by RyzenAPI
-- Game: 2985190

-- MAIN APPLICATION
addappid(2985190)
-- Game: addappid(2985190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985191, 1, "d79c19a012c1c8da0c075f1757804edd570b0866bbf68c02736eeb5f38c85cf4")
