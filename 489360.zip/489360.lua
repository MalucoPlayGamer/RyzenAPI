-- Lua provided by RyzenAPI
-- Game: CASE: Animatronics

-- MAIN APPLICATION
addappid(489360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(489361, 1, "8c12c65982d7d6ce564df1f99211d272dabb34f9bcdcbd24c7de5dbf01a18c29")
addappid(489362, 1, "2e908236f5546ccd20b64332b5f49c12056cca89d848f7b9a54cd06cc4dae3b2")
addappid(489364, 1, "567dbc741a523706b7c68ed74226bdf0eab16789540f63f1731109b8d99a9d36")
addappid(489365, 1, "6a8d415e5a1d804e9a1855978f7a58db9e53b332440cd364da835c229449b1fe")
addappid(489366, 1, "cc61585909f3303f40ac6ad4ae8ef886412dfa05653602f4b7368f7310264634")

