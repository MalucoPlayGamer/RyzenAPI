-- Lua provided by RyzenAPI
-- Game: Cherry Tree High I! My! Girls!

-- MAIN APPLICATION
addappid(333220)
-- Game: addappid(333220)

-- MAIN APP DEPOTS / PACKAGES
addappid(333221, 1, "7631c67ac0ec97f27159307ed37002eda4513346021a7e22437a24a40fbc3684")
