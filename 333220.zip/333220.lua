-- Lua provided by RyzenAPI 
-- Game: Cherry Tree High I! My! Girls!
addappid(333220)
addappid(333221, 1, "7631c67ac0ec97f27159307ed37002eda4513346021a7e22437a24a40fbc3684")
