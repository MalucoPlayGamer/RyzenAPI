-- Lua provided by RyzenAPI
-- Game: addappid(2747610)

-- MAIN APPLICATION
addappid(2747610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747611, 1, "e2fb2f666bb2f4751de5c67d12420a13e7ea7d3ddd0feaf49390054ec9c4c49b")
