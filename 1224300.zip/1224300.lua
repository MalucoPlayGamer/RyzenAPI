-- Lua provided by RyzenAPI
-- Game: addappid(1224300)

-- MAIN APPLICATION
addappid(1224300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224301, 1, "54b9cdcc84dc202171c2d1b70952fac16699dcb792a769defaa9bf98b231d079")
