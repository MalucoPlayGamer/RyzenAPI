-- Lua provided by RyzenAPI
-- Game: Apartment Story

-- MAIN APPLICATION
addappid(3069870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069871, 1, "bbce455ce6bc471a73d563ed6d2b2f8386340b8207afdd02cd6a6b031d9c9ff7")

