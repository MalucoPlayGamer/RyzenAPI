-- Lua provided by RyzenAPI
-- Game: Apartment Story

-- MAIN APPLICATION
addappid(3069870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3069871, 1, "bbce455ce6bc471a73d563ed6d2b2f8386340b8207afdd02cd6a6b031d9c9ff7")

