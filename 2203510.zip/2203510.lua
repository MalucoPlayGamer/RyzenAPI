-- Lua provided by RyzenAPI
-- Game: Kung Fu School

-- MAIN APPLICATION
addappid(2203510)
-- Game: addappid(2203510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203511, 1, "675e778af9d38c7483b671c7dd732d7023fda955411781ce2d8dc1a8cb94002a")
