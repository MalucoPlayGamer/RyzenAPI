-- Lua provided by RyzenAPI
-- Game: addappid(2685040)

-- MAIN APPLICATION
addappid(2685040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685041, 1, "e892fcb84ce8feccaea2f6d43996737496bca1c8ba4e1b3be7912dec181dab00")
