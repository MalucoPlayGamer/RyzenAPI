-- Lua provided by RyzenAPI
-- Game: Turbo Overkill

-- MAIN APPLICATION
addappid(1328350)
addappid(4038230)
addappid(4038350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328351, 1, "8e7760ee0bd1834f2a2c1caebe0df6cb68d95b39db83171f57d85fc4708bc14b")

