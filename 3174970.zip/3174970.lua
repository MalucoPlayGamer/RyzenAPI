-- Lua provided by RyzenAPI
-- Game: 3174970

-- MAIN APPLICATION
addappid(3174970)
-- Game: addappid(3174970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174971, 1, "122f342a1aafa4f671fa8db470856b2d0a47c8c07961d68cfa67d9c3ec5918cc")
