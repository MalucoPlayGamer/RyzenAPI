-- Lua provided by RyzenAPI
-- Game: My Universe - Puppies & Kittens

-- MAIN APPLICATION
addappid(1674840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674841, 1, "62185dede18a6434dc6ed0f0796edad054748f356cbc0e6d93705bd21e2b3ff6")
