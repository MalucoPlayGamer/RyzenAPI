-- Lua provided by RyzenAPI
-- Game: 1419440

-- MAIN APPLICATION
addappid(1419440)
-- Game: addappid(1419440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419441, 1, "7c3f619e3fc1ee6aa2d4a27441c02926bd8014d63db633305163793d17a8bd28")
