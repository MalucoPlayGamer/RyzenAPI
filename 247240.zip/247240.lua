-- Lua provided by RyzenAPI
-- Game: Volgarr the Viking

-- MAIN APPLICATION
addappid(247240)

-- MAIN APP DEPOTS / PACKAGES
addappid(247241, 1, "fb77f00415dbd332d7a59dac2cf5b4067ff866135914e4b56030a8551f5e26df")
addappid(247242, 1, "952274a5ca546703bf7db93669fae33cbdee4c1b946f2a3d2b0b24613b4d5a7b")
addappid(247243, 1, "23e764999f22b0a0d89b3ab43ebf51f7ce69e974a98080541b3f4cbc60906f84")

