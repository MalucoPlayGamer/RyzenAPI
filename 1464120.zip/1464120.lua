-- Lua provided by RyzenAPI
-- Game: Game: 600Seconds ~The Deep Church~

-- MAIN APPLICATION
addappid(1464120)
-- Game: addappid(1464120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464121, 1, "860c63cdafc90e04a0e31fe1434354be873a35172c6bd520d95e5a6394a3b367")
