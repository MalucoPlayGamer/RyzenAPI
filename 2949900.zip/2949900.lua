-- Lua provided by RyzenAPI
-- Game: Nordic Ashes Soundtrack

-- MAIN APPLICATION
addappid(2949900)
-- Game: addappid(2949900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949901, 1, "57016de10e4ffd3b261596bf97b2b102f0590c6909df48177edb5ee9553cd76a")
addappid(2949902, 1, "b815f30b5b02a4c4a13c73a2bbbadd143264e89300d44cef0d0f1314aa6000a4")
