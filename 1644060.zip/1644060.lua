-- Lua provided by RyzenAPI
-- Game: COGEN: Sword of Rewind - Additional Story ＆ Playable Character: Akasha / COGEN: 大鳥こはくと刻の剣 - 追加シナリオ＆プレイ可能キャラクター：アーカーシャ編

-- MAIN APPLICATION
addappid(1644060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644060,0,"72eb6690996dbc4562c1479880ccc1c46c6f91275c62da1415b608751043b6a7")

