-- Lua provided by SkyAPI 
-- Game: Victory Heat Rally
addappid(1594060)
addappid(1594061, 1, "5fa5935e31a28b6dd0f198acb116c6710ff0d0a26979ce0601cad633b073b1e7")
