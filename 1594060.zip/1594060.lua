-- Lua provided by RyzenAPI
-- Game: Game: Victory Heat Rally

-- MAIN APPLICATION
addappid(1594060)
-- Game: addappid(1594060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594061, 1, "5fa5935e31a28b6dd0f198acb116c6710ff0d0a26979ce0601cad633b073b1e7")
