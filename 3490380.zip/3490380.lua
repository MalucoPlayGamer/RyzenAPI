-- Lua provided by RyzenAPI
-- Game: Electro Bop Boxing League Soundtrack

-- MAIN APPLICATION
addappid(3490380)
-- Game: addappid(3490380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3490381, 1, "ce133426d00732f511697b285d1aaf5dc883c8c6d240deea8ed00852279ad477")
