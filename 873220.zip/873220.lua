-- Lua provided by RyzenAPI
-- Game: Game: AppID 873220

-- MAIN APPLICATION
addappid(873220)
-- Game: addappid(873220)

-- MAIN APP DEPOTS / PACKAGES
addappid(873221, 1, "9e61b6de9b022e8273e4a849074a538fb3cfaeec42cb1ca86041b9e155700983")
