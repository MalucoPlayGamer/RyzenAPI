-- Lua provided by RyzenAPI
-- Game: addappid(265000)

-- MAIN APPLICATION
addappid(265000)
addappid(453600)

-- MAIN APP DEPOTS / PACKAGES
addappid(265001, 1, "4fe7b1655e6a93fcb3623b5f1b8581bc8d301ca105ed4050acfe8834e19cf6d1")
addappid(265002, 1, "5acda75bba2b62098eca6da1bc48636e4355ce59c17384207adc1a2e5c60d8e3")
addappid(265003, 1, "b68fc540f34e80e425bb0430af0922f0cab87e91f5d61221dead8c19508a870e")
addappid(265007, 1, "24bc2189cfeb5b6326ae431c6e03cde96ce07a6edd9dbb1bcf2c583530b2bbf1")
addappid(453562, 0, "20dd16ffdbbe0c4e79f29333c9482c7877dfb7b58b8ac77bcac11147287ec44e")
addappid(453563, 0, "085e90e73b951b2953e55e45dbf28c3f749d3986a5cb935b0bc45d9698b22949")
