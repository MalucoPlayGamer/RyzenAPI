-- Lua provided by RyzenAPI
-- Game: FORCED SHOWDOWN

-- MAIN APPLICATION
addappid(453561) -- FORCED SHOWDOWN - Squire of Ice
addappid(453562)
addappid(453563)
addappid(453600)
addappid(454960) -- FORCED SHOWDOWN - Deluxe Edition Content
addappid(455070) -- FORCED SHOWDOWN - Deluxe Companion Skins
addappid(492750) -- FORCED SHOWDOWN - Drone Invasion
addappid(502830) -- FORCED SHOWDOWN - Supreme Skin Pack
-- addappid(265005) -- Depot 265005 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(265000, 1, "15db083d7de803cf0335325d25e7367ae2685f044171d51f87d2e4ee273e2c7f") -- FORCED SHOWDOWN
addappid(265001, 1, "4fe7b1655e6a93fcb3623b5f1b8581bc8d301ca105ed4050acfe8834e19cf6d1") -- forced2_windows_content
addappid(265002, 1, "5acda75bba2b62098eca6da1bc48636e4355ce59c17384207adc1a2e5c60d8e3") -- forced2_osx_content
addappid(265003, 1, "b68fc540f34e80e425bb0430af0922f0cab87e91f5d61221dead8c19508a870e") -- forced2_linux_content
addappid(265007, 1, "24bc2189cfeb5b6326ae431c6e03cde96ce07a6edd9dbb1bcf2c583530b2bbf1") -- FORCED_SHOWDOWN_windows_x64
addappid(453562, 1, "20dd16ffdbbe0c4e79f29333c9482c7877dfb7b58b8ac77bcac11147287ec44e") -- FORCED SHOWDOWN - High Res Card Art - FORCED SHOWDOWN - High Res Card Art (453562) Depot
addappid(453563, 1, "085e90e73b951b2953e55e45dbf28c3f749d3986a5cb935b0bc45d9698b22949") -- FORCED SHOWDOWN - The Media Pack - FORCED SHOWDOWN - The Media Pack (453563) Depot
addappid(453600, 1, "ed3ae082d587f35b90b024602bea3b85cf9d6e40009d23c3a0ae03a840d410bf") -- FORCED SHOWDOWN - Subscriber Benefits - FORCED SHOWDOWN - Subscriber Benefits (453600) Depot
addtoken(453561, "14507524897935943185")
addtoken(453562, "5324282670729658536")
addtoken(453563, "7209188332972229247")
addtoken(453600, "11275678775594433070")
addtoken(455070, "3066100495895716835")

