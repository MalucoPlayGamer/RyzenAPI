-- Lua provided by RyzenAPI
-- Game: Angelic Wishes

-- MAIN APPLICATION
addappid(2188920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188921, 1, "a66141a6cfe484c48349f2c2480fd3d0d00bae5cb1d245a205684c7271621b69")

