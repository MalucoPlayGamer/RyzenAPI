-- Lua provided by SkyAPI 
-- Game: AppID 2188920
addappid(2188920)
addappid(2188921, 1, "a66141a6cfe484c48349f2c2480fd3d0d00bae5cb1d245a205684c7271621b69")
