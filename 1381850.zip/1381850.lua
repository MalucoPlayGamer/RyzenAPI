-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Fight for Freedom

-- MAIN APPLICATION
addappid(1381850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381851, 1, "cb3066925db393bafe7c72e042a7c9b78473ada747ed3798ff4cba6e9bd3bde2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
