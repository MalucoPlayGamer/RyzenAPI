-- Lua provided by RyzenAPI
-- Game: Game: Strategic Mind: Fight for Freedom

-- MAIN APPLICATION
addappid(1381850)
-- Game: addappid(1381850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381851, 1, "cb3066925db393bafe7c72e042a7c9b78473ada747ed3798ff4cba6e9bd3bde2")
