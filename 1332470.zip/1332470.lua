-- Lua provided by RyzenAPI
-- Game: AppID 1332470

-- MAIN APPLICATION
addappid(1332470)
-- Game: addappid(1332470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332471, 1, "a7fbaa17953591bfab10582898b9fe25b86ca8efc67372b01b36bd99d16ca6b4")
