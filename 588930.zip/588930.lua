-- Lua provided by RyzenAPI
-- Game: Game: King 'n Knight

-- MAIN APPLICATION
addappid(588930)
-- Game: addappid(588930)

-- MAIN APP DEPOTS / PACKAGES
addappid(588931, 1, "63639beead0c31cfdb130496059475e2b7061ef9d3f07096ab45bc682612bc31")
