-- Lua provided by RyzenAPI
-- Game: King 'n Knight

-- MAIN APPLICATION
addappid(588930)

-- MAIN APP DEPOTS / PACKAGES
addappid(588931, 1, "63639beead0c31cfdb130496059475e2b7061ef9d3f07096ab45bc682612bc31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
