-- Lua provided by RyzenAPI 
-- Game: AppID 675210
addappid(675210)
addappid(675211, 1, "fca2e9002e1922558642824846cefba8c80b54dd8c48c81c4c58a828e1e70b99")
