-- Lua provided by RyzenAPI
-- Game: addappid(487030)

-- MAIN APPLICATION
addappid(487030)

-- MAIN APP DEPOTS / PACKAGES
addappid(487031, 1, "544a2ee29516006e53af2d4bda60d1118240092eeb4ebc1146093481b0e7b508")
addappid(487032, 1, "12ac3b9037c7fc89c515fd78bc7a1b1bb7a1c6c1571f8753acce425ccbc02fb5")
