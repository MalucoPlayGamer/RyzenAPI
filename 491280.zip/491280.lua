-- Lua provided by RyzenAPI
-- Game: Drift Horizon Online

-- MAIN APPLICATION
addappid(491280)
-- Game: addappid(491280)

-- MAIN APP DEPOTS / PACKAGES
addappid(491281, 1, "6d09472870b83a351e0498260ceb5a7bf9e410fb95d91465b0e54c9606bf506d")
