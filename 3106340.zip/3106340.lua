-- Lua provided by RyzenAPI
-- Game: Aquarium at August 32nd

-- MAIN APPLICATION
addappid(3106340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106341, 1, "949f78f69f0e8dbe6c5746f3644eed1b22c8fdc13c138a674261cea764a2f713")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
