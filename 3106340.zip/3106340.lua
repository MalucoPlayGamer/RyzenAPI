-- Lua provided by RyzenAPI
-- Game: 3106340

-- MAIN APPLICATION
addappid(3106340)
-- Game: addappid(3106340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106341, 1, "949f78f69f0e8dbe6c5746f3644eed1b22c8fdc13c138a674261cea764a2f713")
