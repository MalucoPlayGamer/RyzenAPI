-- Lua provided by RyzenAPI
-- Game: 1693260

-- MAIN APPLICATION
addappid(1693260)
addappid(1693261)
addappid(1693262)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693263,0,"f27dc3ce69bdabc6747f8a9a0800e87b6a7d5439638a028706e5dcbaea748c0d")

