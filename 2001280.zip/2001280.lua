-- Lua provided by RyzenAPI
-- Game: The Last City

-- MAIN APPLICATION
addappid(2001280)
-- Game: addappid(2001280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001281, 1, "a1776c6afc8804a4ec4e0adb5d52ece86b11149bd9c907fbad02ce316c53d10b")
