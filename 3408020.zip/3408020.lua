-- Lua provided by SkyAPI 
-- Game: Succubus Forest
addappid(3408020)
addappid(3408021, 1, "06b203b03761769ea4747b17e56bb3c7fdee7ebb845c7097f5ca02824cd8a738")
addappid(3408022, 1, "ca07380d8b7779783d27129ff779aab8a6fe8ba9c2a61126f52ecdbda3c7067b")
addappid(3408023, 1, "8af839c1d8a7ec14cd075409a3f8d93b4206d4e4f09bcef4602696dda8f1526b")
