-- Lua provided by RyzenAPI
-- Game: addappid(486430)

-- MAIN APPLICATION
addappid(486430)

-- MAIN APP DEPOTS / PACKAGES
addappid(486431, 1, "7136b5fd93044c2006db8cead21f5dc66c420940c84d8de7974ecc413c626b90")
