-- Lua provided by RyzenAPI
-- Game: Sphoxie

-- MAIN APPLICATION
addappid(486430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(486431, 1, "7136b5fd93044c2006db8cead21f5dc66c420940c84d8de7974ecc413c626b90")
