-- Lua provided by RyzenAPI
-- Game: 18 Wheels of Steel: Across America

-- MAIN APPLICATION
addappid(514160)

-- MAIN APP DEPOTS / PACKAGES
addappid(514161, 1, "d3eca39975c6fc02d9a6a366e8c4f95cd1fa07f15ca26275346ac82bfb4e65c3")

