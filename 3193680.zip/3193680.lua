-- Lua provided by RyzenAPI
-- Game: Out of Hand: Deluxe

-- MAIN APPLICATION
addappid(3193680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193681, 1, "bfb854fc0291e84ee8e405a92d9251cf4729dab70982a6efc5d0d5e540006c61")
