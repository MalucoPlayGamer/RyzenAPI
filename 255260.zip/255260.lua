-- Lua provided by RyzenAPI
-- Game: AppID 255260

-- MAIN APPLICATION
addappid(255260)

-- MAIN APP DEPOTS / PACKAGES
addappid(255261, 1, "1864d5e8abc2b05bb362f9217425e01985e74d8f692d5d32314dcb3e254c8192")
addappid(255262, 1, "8fe443f881d78b03bbe2166ff2eb84db19e33efe9c330eb6ae0a955e4fe769cb")
addappid(255263, 1, "9d2c720fa4a9af5a35f5baba95c6e553934947a7f9dac44978efbed86358ad22")
addappid(255264, 1, "5d07c9c894f2306684e23c53d07b8cef941ab05a7e1ff3e71abc51f9e8910d3d")
addappid(255265, 1, "bd01026dd8767a5339a99fe554b20b0c6ea8e14ec3d824c921e0ed9eb8b1aef0")
addappid(255266, 1, "773b7d2390047cfda523765e3f8577be81d8023343e0ed090938693b94629442")
addappid(255267, 1, "00ce9aaee6452ec9a6eed03e5984b881217066ef7853063b83fad4f82e68ae5b")
addappid(255268, 1, "d8c2e5d591272f145efca6f406a1126aa2bcfb43106fde2b4a8dc1a42486fe73")
addappid(255269, 1, "af9eac02130dd9241cdab7780d22cdeb86e9835feba4b841632a43ba7f96023e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
