-- Lua provided by RyzenAPI
-- Game: AppID 363090

-- MAIN APPLICATION
addappid(363090)

-- MAIN APP DEPOTS / PACKAGES
addappid(363091, 1, "9fccdb6d4b1ed41a470941ba6f28ed11be24a31568ed80cb7fd8d079529b34e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(381730)
addappid(381731)
