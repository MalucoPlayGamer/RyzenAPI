-- Lua provided by RyzenAPI
-- Game: AppID 363090

-- MAIN APPLICATION
addappid(363090)
-- Game: addappid(363090)

-- MAIN APP DEPOTS / PACKAGES
addappid(363091, 1, "9fccdb6d4b1ed41a470941ba6f28ed11be24a31568ed80cb7fd8d079529b34e7")
