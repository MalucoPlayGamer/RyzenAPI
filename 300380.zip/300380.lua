-- Lua provided by RyzenAPI
-- Game: Road Redemption

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228990)
addappid(229000)
addappid(229001)
addappid(229002)
addappid(229003)
addappid(229004)
addappid(300380)

-- MAIN APP DEPOTS / PACKAGES
addappid(300382,0,"d6fa1b92e0b5716e57b04973493c4974423db7e7b84981965be53fc2638ca620")
addappid(300385,0,"93af33495aa32c25253d66705a23f1951c26fa64b175cc1008bcc45383edb333")
addappid(300386,0,"0cccbda95beae17dc8a69a846c3c4b30ff5c1c905e63a99f7df3d52b09e4c946")
addappid(300387,0,"99ccddb494b1509668cdcc23d5253331454e46dfdc64ca4652c09d1666103ae7")
addappid(725880,0,"4782b6fe6bafc37455e4e121ebaa8b9d038db5796df8434d12fb12e1e1b67733")
addappid(727050,0,"5c08a0fcfd1620810543e1c6f254f63b333e1f4639964b268e442a95c5ace094")
addappid(727440,0,"8e9373e3ab2b5de40a00dd5853abea47b0042d97720258a0f3e16004d964d437")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1180010)
