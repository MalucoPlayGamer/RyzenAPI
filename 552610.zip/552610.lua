-- Lua provided by RyzenAPI
-- Game: Ninja Smasher!

-- MAIN APPLICATION
addappid(552610)

-- MAIN APP DEPOTS / PACKAGES
addappid(552611,0,"54fa641e0e4e8375df6230f6bb28880a79cd229d2f55fde8ad8ee166fc0afb48")

