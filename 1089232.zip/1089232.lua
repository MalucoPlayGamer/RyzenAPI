-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Easy String Skipping Exercise 2

-- MAIN APPLICATION
addappid(1089232)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089232,0,"7de36b844df40403b36402dd80c9b024b2942aa2be05720d75b56f7fd8b42656")

