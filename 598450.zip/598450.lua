-- Lua provided by RyzenAPI
-- Game: Slice, Dice & Rice

-- MAIN APPLICATION
addappid(598450)

-- MAIN APP DEPOTS / PACKAGES
addappid(598451, 1, "af688c9f6d6f1be7c5572c17090ac4c9b20a317a0476eeba7c2bf7a64de7b0fd")
addappid(598452, 1, "773d67d51d0c475e303994f9e7cf5a44a6dd3709b5538c91f405c7c0df96b4f1")
addappid(598453, 1, "2efee4ce2476350bb74d70a6b604e37c5b6deb90ea45257004af0cf7d9f36556")
addappid(598454, 1, "b351f8c44f7fb0def6b1573d6bcec29baf9995b61f81e29b40f63ee840a70819")
addappid(598455, 1, "d190885b77efdfe1c7a609829e1fed406ebd94aacdfc1e42059b526e269e219d")
addappid(598456, 1, "75808a0ba27e33f7cfe3cbb58766498cac033ce22f1a844b3bd81f896a1709bf")

