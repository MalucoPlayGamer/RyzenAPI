-- Lua provided by RyzenAPI
-- Game: Game: AppID 517240

-- MAIN APPLICATION
addappid(517240)
-- Game: addappid(517240)

-- MAIN APP DEPOTS / PACKAGES
addappid(517241, 1, "8c32203b2d20dcd9fb201d94d320a2dfe0215b50e3d77f0d456c66a2d2f72a99")
