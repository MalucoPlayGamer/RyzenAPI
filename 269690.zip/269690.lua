-- Lua provided by RyzenAPI
-- Game: Game: RymdResa

-- MAIN APPLICATION
addappid(269690)
addappid(379730)
-- Game: addappid(269690)

-- MAIN APP DEPOTS / PACKAGES
addappid(269691, 1, "b04a702d034895629c52ecfe8326b7e0efaa042298a34f65ba4db6f4b56c58ea")
addappid(269693, 1, "3a96f4ecafd6d4293216a32ac4a12d35c4a4ff188408cc81fc1c7eb33ef70db6")
addappid(269694, 1, "dfcedcc1269e22cba19a3a9c65a43b09b99ae736e4622168e6f2380172bef7f2")
