-- Lua provided by RyzenAPI
-- Game: Chinese Brush Simulator

-- MAIN APPLICATION
addappid(1222160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1222161, 1, "279cc7960a5d0ebe0459a3adaaabda5649084e9b96421f88a7eba93b2c3eb5c7")

