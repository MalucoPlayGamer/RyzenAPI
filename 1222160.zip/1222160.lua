-- Lua provided by RyzenAPI
-- Game: Chinese Brush Simulator

-- MAIN APPLICATION
addappid(1222160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222161, 1, "279cc7960a5d0ebe0459a3adaaabda5649084e9b96421f88a7eba93b2c3eb5c7")

