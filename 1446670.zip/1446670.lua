-- Lua provided by RyzenAPI
-- Game: Tin Tandem

-- MAIN APPLICATION
addappid(1446670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446672,0,"b3550a785e14e59bc9d547538e9d0bead32dce460f6674b0cb0f246f5a85af87")
addappid(1446673,0,"29d56653bcdac85a4a5bf3c6c8ad83b5c5eb66849beeb295254c4ebf627c1398")

