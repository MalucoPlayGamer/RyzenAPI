-- 1620970's Lua and Manifest Created by Hubcap Manifest
-- Blue Rabbit
-- Created: July 30, 2026 at 14:20:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1620970, 1, "0f14c298fbb3b336aa205cbd88334f24fbffaebe4fdb30abf6f146b5c92b2a43") -- Blue Rabbit
-- MAIN APP DEPOTS
addappid(1620971, 1, "0226b23faa5f7b9e6571f654be82f1ec93f0003ea8125498994f352cce16f5aa") -- Depot 1620971
setManifestid(1620971, "1143455085371850932", 77117855)
addappid(1620972, 1, "71fee1add65693fa919126e6424d0c787020e11ce8846894ca49b1a2fbfa76fc") -- Depot 1620972
setManifestid(1620972, "8296756866267494422", 78644332)