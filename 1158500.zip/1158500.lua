-- Lua provided by RyzenAPI 
-- Game: AppID 1158500
addappid(1158500)
addappid(1158501, 1, "32367ab513753314e461abe5b36bbdf1b3113e4a2856ecee0cff31709af91004")
