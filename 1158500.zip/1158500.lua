-- Lua provided by RyzenAPI
-- Game: 1158500

-- MAIN APPLICATION
addappid(1158500)
-- Game: addappid(1158500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158501, 1, "32367ab513753314e461abe5b36bbdf1b3113e4a2856ecee0cff31709af91004")
