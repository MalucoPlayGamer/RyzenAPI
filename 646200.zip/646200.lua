-- Lua provided by RyzenAPI
-- Game: Dead Effect 2 VR

-- MAIN APPLICATION
addappid(646200)

-- MAIN APP DEPOTS / PACKAGES
addappid(646201, 1, "6825bc7f327da316990728e05610a1b14e56142227d5ce21d695d4652ad8df56")

