-- Lua provided by RyzenAPI
-- Game: Jennifer's Fragments

-- MAIN APPLICATION
addappid(2608570)
-- Game: addappid(2608570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608571, 1, "1b5a632b595d8de062ef21cb28969315468d14277d86f87f37a8669c73bf8e2f")
