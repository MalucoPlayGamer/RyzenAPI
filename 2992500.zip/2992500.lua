-- Lua provided by RyzenAPI 
-- Game: Coin Factory
addappid(2992500)
addappid(2992501, 1, "1865f60cdf6edd6825d81e7d2b3c37b8c8e898a7344e644031e32d1202f2b2be")
addappid(2992502, 1, "19082cb052a3081ebbd5e13a5719209755f216c795eb3b4ad84b1811e990f390")
