-- Lua provided by RyzenAPI
-- Game: addappid(2244160)

-- MAIN APPLICATION
addappid(2244160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244161, 1, "e346494639940fbbc878e5e8eb27b865de713ad996572afcf123eaf0be19c21b")
