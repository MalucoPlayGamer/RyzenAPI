-- Lua provided by RyzenAPI
-- Game: MONARK

-- MAIN APPLICATION
addappid(1539620)
addappid(1836010)
addappid(1836011)
addappid(1836012)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1539621, 1, "e52eefdc4e7adf9895e5e9f12a6f27683e117f3212bd2a1284416e825e7f9c6e")
addappid(1851860, 0, "0c8aa49a5e5185194f4098029155a456a7da11e22c840dae328be608939b48c2")
addappid(1851861, 0, "d70363602a2e9ed8d7b7751c22449be0d39d3b59bb7d7ec2072dc148755fb04a")
addappid(1888710, 0, "b767bf527b260c9eb6329205c1c9468905221f60e7acdf8bda8e64bdca045f9a")

