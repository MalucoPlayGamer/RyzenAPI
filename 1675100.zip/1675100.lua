-- Lua provided by SkyAPI 
-- Game: AppID 1675100
addappid(1675100)
addappid(1675101, 1, "cdf1fffc61a3646e4cbeafb2be0616d1440bb3dcd6b5e35d5417bc3929326adf")
