-- Lua provided by RyzenAPI
-- Game: Game: AppID 1675100

-- MAIN APPLICATION
addappid(1675100)
-- Game: addappid(1675100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675101, 1, "cdf1fffc61a3646e4cbeafb2be0616d1440bb3dcd6b5e35d5417bc3929326adf")
