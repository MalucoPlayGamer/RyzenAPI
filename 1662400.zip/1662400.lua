-- Lua provided by RyzenAPI
-- Game: The Forgotten City Soundtrack

-- MAIN APPLICATION
addappid(1662400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662401, 1, "34efa269911aa1e31f0da24c422e4e5ef7e2842785030dd495d78566c9dea920")
addappid(1662402, 1, "0d1de7b85b3fcdd2274c22ba9e207366a689d7d765e640cb35bc077ec5c5ee53")

