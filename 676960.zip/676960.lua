-- Lua provided by RyzenAPI
-- Game: setManifestid(676962,"8384733506633707487")

-- MAIN APPLICATION
addappid(676960)
-- Game: addappid(676960)

-- MAIN APP DEPOTS / PACKAGES
addappid(676962,0,"9f502123bd4eb820d6534cacb4a02ae5066b57f55e2e1fbbd060f87557c7dd3f")
