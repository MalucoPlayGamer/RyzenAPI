-- Lua provided by SkyAPI 
-- Game: Not A Thief Simulator
addappid(2233720)
addappid(2233721, 1, "c42ca45ad755bef9e9602c487afcf3246852f3535f608eb899791bfa6960bfab")
