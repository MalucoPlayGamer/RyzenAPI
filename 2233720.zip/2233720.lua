-- Lua provided by RyzenAPI
-- Game: Game: Not A Thief Simulator

-- MAIN APPLICATION
addappid(2233720)
-- Game: addappid(2233720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233721, 1, "c42ca45ad755bef9e9602c487afcf3246852f3535f608eb899791bfa6960bfab")
