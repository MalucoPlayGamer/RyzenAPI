-- Lua provided by RyzenAPI
-- Game: 2114370

-- MAIN APPLICATION
addappid(2114370)
-- Game: addappid(2114370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114371, 1, "89d1bd65935f8a55eeffaf367f64048cfade264d8a8f433cb8f0f9d352234b3c")
