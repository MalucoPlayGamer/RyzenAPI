-- Lua provided by SkyAPI 
-- Game: AppID 2114370
addappid(2114370)
addappid(2114371, 1, "89d1bd65935f8a55eeffaf367f64048cfade264d8a8f433cb8f0f9d352234b3c")
