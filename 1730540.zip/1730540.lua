-- Lua provided by RyzenAPI
-- Game: addappid(1730540)

-- MAIN APPLICATION
addappid(1730540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730542,0,"4c35b56de476cd3cf12f67f8b26000c2e91b826302a7a966b7cc658cfe07dcd0")
addappid(1730543,0,"1981df1fd5490cb16ba47584a04a4aee9c28a2bd95fa1af3f8570269a6cbed88")
