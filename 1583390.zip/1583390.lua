-- Lua provided by RyzenAPI
-- Game: Meat Beating: No More Horny

-- MAIN APPLICATION
addappid(1583390)
addappid(4333970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583391, 1, "c0737af744e63b9b0bc57ce7dd38bce676e1225c524fc1b2fce568cac9aff29d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
