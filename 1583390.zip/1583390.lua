-- Lua provided by RyzenAPI
-- Game: Meat Beating: No More Horny

-- MAIN APPLICATION
addappid(1583390)
addappid(4333970)
-- Game: addappid(1583390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583391, 1, "c0737af744e63b9b0bc57ce7dd38bce676e1225c524fc1b2fce568cac9aff29d")
