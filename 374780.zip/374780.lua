-- Lua provided by RyzenAPI 
-- Game: Positron
addappid(374780)
addappid(374781, 1, "59f7e1b94fda23e11b84ac4cccdb0b3f14af30165ad7e10d065e97b8d5dce896")
