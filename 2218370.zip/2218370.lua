-- Lua provided by RyzenAPI
-- Game: 2218370

-- MAIN APPLICATION
addappid(2218370)
-- Game: addappid(2218370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218371, 1, "1f3aeb316f33910da19dbd81abd4ca4525e3ebb60d5f1aa06ea6ce7635fad0ae")
