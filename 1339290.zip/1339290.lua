-- Lua provided by RyzenAPI
-- Game: ZONEX

-- MAIN APPLICATION
addappid(1339290)
-- Game: addappid(1339290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339291, 1, "d192778cfdc0647e52932e06decd3ac2efccb83f7c47fc280d715d22e401a53e")
