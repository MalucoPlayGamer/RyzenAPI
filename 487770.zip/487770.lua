-- Lua provided by RyzenAPI
-- Game: Game: Hoops VR

-- MAIN APPLICATION
addappid(487770)
-- Game: addappid(487770)

-- MAIN APP DEPOTS / PACKAGES
addappid(487771, 1, "3eddaf0ce784769271b26a1f83487233a8cb68e15222ed6ebd44f16b0c4c5042")
