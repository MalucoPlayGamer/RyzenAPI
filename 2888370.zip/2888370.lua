-- Lua provided by SkyAPI 
-- Game: Cybersex: Lust Story
addappid(2888370)
addappid(2888371, 1, "9617c670ef15f434df835f43dd5cdba2f9ccf5ac2ad021d16dd50fce7a0c9e7b")
