-- Lua provided by RyzenAPI
-- Game: Cybersex: Lust Story

-- MAIN APPLICATION
addappid(2888370)
-- Game: addappid(2888370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888371, 1, "9617c670ef15f434df835f43dd5cdba2f9ccf5ac2ad021d16dd50fce7a0c9e7b")
