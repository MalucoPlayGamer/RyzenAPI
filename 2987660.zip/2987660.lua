-- Lua provided by RyzenAPI
-- Game: CYBERCUM 2069

-- MAIN APPLICATION
addappid(2987660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987661, 1, "06bbcf2821bfcf38ac34f0950cba53e00a9edbbea127292572bcb10b06b60d94")
