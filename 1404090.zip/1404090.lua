-- Lua provided by RyzenAPI
-- Game: Trivia Tricks

-- MAIN APPLICATION
addappid(1404090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404091, 1, "36c2c48f1f620334b5145190429e07af09cd2cf5a2596de9214db7178eb0e8ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
