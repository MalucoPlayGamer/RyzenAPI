-- Lua provided by RyzenAPI
-- Game: addappid(1404090)

-- MAIN APPLICATION
addappid(1404090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404091, 1, "36c2c48f1f620334b5145190429e07af09cd2cf5a2596de9214db7178eb0e8ce")
