-- Lua provided by RyzenAPI
-- Game: addappid(3158380)

-- MAIN APPLICATION
addappid(3158380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158382,0,"1af119ce32c3b400f8aeee749011e4f75f49b8dc1f4e6d68a455b80163948c24")
addappid(3158383,0,"fa83fcbb5ca20e838bb51bec59b739701f15d5d953e6fb2deec5d71612bcedaf")
addappid(3158384,0,"3c9cfa7bce3ecdf138a6800e7939de8882759601da49fe220de356e33a889cd8")
