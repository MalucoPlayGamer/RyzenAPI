-- Lua provided by SkyAPI 
-- Game: Panzermadels: Tank Dating Simulator
addappid(379980)
addappid(379981, 1, "139c3fa0b5a52a00c008ea5fbd361d7859903c628cace4afd67ddaa97b178e02")
addappid(379982, 1, "ada95a02036fbc950f19489718d757af8cd15290f7091a57435cfba6e942d297")
