-- Lua provided by RyzenAPI
-- Game: 385870

-- MAIN APPLICATION
addappid(385870)
-- Game: addappid(385870)

-- MAIN APP DEPOTS / PACKAGES
addappid(385870,0,"4afa95fa9decffe2a701c5b82f6fa8fc796b6b7f190096ab8b020259f517a4b3")
