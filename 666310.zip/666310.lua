-- Lua provided by RyzenAPI
-- Game: 666310

-- MAIN APPLICATION
addappid(666310)
-- Game: addappid(666310)

-- MAIN APP DEPOTS / PACKAGES
addappid(666311, 1, "321be4da946dad05fd6c79cdcd65e5635ed9bbe6d148dd0db0fba0484896673f")
