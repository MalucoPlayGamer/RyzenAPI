-- Lua provided by SkyAPI 
-- Game: Imperivm RTC - HD Edition "Great Battles of Rome"
addappid(752580)
addappid(752581, 1, "6c6333055c4114808869c59534e4f4daa5d6b100c6158896bbc14e65eef57e9d")
addappid(752582, 1, "d76ac99763281a08ce8e7965662765bb668d461fcc29fd575ac189abba735734")
