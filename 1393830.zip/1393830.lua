-- Lua provided by RyzenAPI
-- Game: 1393830

-- MAIN APPLICATION
addappid(1393830)
-- Game: addappid(1393830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393831, 1, "e9014ef040318b99fda2c59ed683631c1da65f218d137bdb86f51ae2716d5840")
