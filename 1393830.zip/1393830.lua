-- Lua provided by SkyAPI 
-- Game: INFLUXIS
addappid(1393830)
addappid(1393831, 1, "e9014ef040318b99fda2c59ed683631c1da65f218d137bdb86f51ae2716d5840")
