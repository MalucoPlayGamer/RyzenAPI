-- Lua provided by RyzenAPI
-- Game: INFLUXIS

-- MAIN APPLICATION
addappid(1393830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393831, 1, "e9014ef040318b99fda2c59ed683631c1da65f218d137bdb86f51ae2716d5840")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
