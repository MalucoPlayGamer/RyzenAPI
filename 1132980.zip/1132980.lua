-- Lua provided by RyzenAPI
-- Game: There Is No Light

-- MAIN APPLICATION
addappid(1132980)
addappid(2147610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132981, 1, "a07ab7652e5666039dd734678fc82e9a84c5272f20deb1b2e0335c1fa0b6a4ec")
addappid(2141260, 0, "fb6f1e8548fa77acf24e08eb86f2d8e219c0bf1557509817317ae853c440f426")
