-- Lua provided by RyzenAPI
-- Game: Metaart

-- MAIN APPLICATION
addappid(2385390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385391, 1, "1b9f056098963d9de37c2f49ef83fdfbd44defe90de69614aaf95f0c9cd290c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
