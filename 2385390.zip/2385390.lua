-- Lua provided by RyzenAPI
-- Game: Metaart

-- MAIN APPLICATION
addappid(2385390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385391, 1, "1b9f056098963d9de37c2f49ef83fdfbd44defe90de69614aaf95f0c9cd290c3")
