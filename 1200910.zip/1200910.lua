-- Lua provided by RyzenAPI
-- Game: 1200910

-- MAIN APPLICATION
addappid(1200910)
addappid(1201970)
-- Game: addappid(1200910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200911, 1, "50439ff69584e2cda7aba474a4918d0c359c311efdc24dbdda962fcd688238df")
