-- Lua provided by RyzenAPI
-- Game: 671310

-- MAIN APPLICATION
addappid(671310)
-- Game: addappid(671310)

-- MAIN APP DEPOTS / PACKAGES
addappid(671312,0,"04617df72126c43dfdaae15cc4a71f0e36f8c81eb97ff68bc45697acb909af3b")
