-- Lua provided by RyzenAPI
-- Game: Quad Hopping

-- MAIN APPLICATION
addappid(694490)

-- MAIN APP DEPOTS / PACKAGES
addappid(694491,0,"ba125ce3f517b1c9604472d4968fccc7cc4ca769fccf4f0af165884ea2414f54")

