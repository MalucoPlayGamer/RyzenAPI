-- Lua provided by RyzenAPI
-- Game: addappid(2159060)

-- MAIN APPLICATION
addappid(2159060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159061, 1, "6ecd9be65306dd3fe5bd953904bff68e2c7ffe7b657ee29ce745aef7df2c2892")
