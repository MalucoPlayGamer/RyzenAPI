-- Lua provided by RyzenAPI
-- Game: 锈翅 逃离我的家乡 Without Wings

-- MAIN APPLICATION
addappid(2985750)
-- Game: addappid(2985750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985751, 1, "7c00763378da65f4550e9fa3552df652204be7b3d5e775921018e3c1ad2c7168")
