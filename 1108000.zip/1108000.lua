-- Lua provided by RyzenAPI
-- Game: Game: Children of Silentown

-- MAIN APPLICATION
addappid(1108000)
-- Game: addappid(1108000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108001, 1, "12d79aa3ef2cf69240f9fa58adfaa4998e9516761dc536a491406eb3e809f85b")
addappid(1108002, 1, "49b7ced8e4d9de168794fc71e5951c00ba81ab2872be4510b0e880ef51c33c5f")
addappid(1108003, 1, "cb528879723409f9012ccf5c3881a3ba7473214f37068cb8de73dfed1e5521cd")
addappid(2213230, 0, "895b3166bb074f290ba8b76719e58bee422c573cdaf490e60f34276a9cb24a24")
