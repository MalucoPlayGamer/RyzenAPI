-- Lua provided by RyzenAPI
-- Game: Children of Silentown

-- MAIN APPLICATION
addappid(1108000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108001, 1, "12d79aa3ef2cf69240f9fa58adfaa4998e9516761dc536a491406eb3e809f85b")
addappid(1108002, 1, "49b7ced8e4d9de168794fc71e5951c00ba81ab2872be4510b0e880ef51c33c5f")
addappid(1108003, 1, "cb528879723409f9012ccf5c3881a3ba7473214f37068cb8de73dfed1e5521cd")
addappid(2213230, 0, "895b3166bb074f290ba8b76719e58bee422c573cdaf490e60f34276a9cb24a24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
