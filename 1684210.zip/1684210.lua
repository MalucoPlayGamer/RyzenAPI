-- Lua provided by RyzenAPI
-- Game: Horror Villa 恐怖撤锁

-- MAIN APPLICATION
addappid(1684210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1684211, 1, "2d82445e3b65e7b6bcb7369cfdf674d269a7d889c41dc3dcd1810373d166b678")

