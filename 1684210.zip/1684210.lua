-- Lua provided by RyzenAPI
-- Game: addappid(1684210)

-- MAIN APPLICATION
addappid(1684210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684211, 1, "2d82445e3b65e7b6bcb7369cfdf674d269a7d889c41dc3dcd1810373d166b678")
