-- Lua provided by SkyAPI 
-- Game: Paws Trail
addappid(2726930)
addappid(2726931, 1, "9b3787c711533b27dc542019e9dd0936c48f4dfe2984d3a5a968a07ea5264617")
