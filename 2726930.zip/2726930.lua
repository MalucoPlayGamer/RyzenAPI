-- Lua provided by RyzenAPI
-- Game: Game: Paws Trail

-- MAIN APPLICATION
addappid(2726930)
-- Game: addappid(2726930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726931, 1, "9b3787c711533b27dc542019e9dd0936c48f4dfe2984d3a5a968a07ea5264617")
