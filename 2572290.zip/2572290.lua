-- Lua provided by RyzenAPI
-- Game: YOHANE THE PARHELION -BLAZE in the DEEPBLUE- Demo

-- MAIN APPLICATION
addappid(2572290)
-- Game: addappid(2572290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572291, 1, "6856c0db5bcfaf1153de052cfcf8664fb6e92606beecc03aed76bd6d0453d1f9")
