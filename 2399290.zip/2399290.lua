-- Lua provided by RyzenAPI
-- Game: Tales from Candleforth Demo

-- MAIN APPLICATION
addappid(2399290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399291, 1, "0393e2f1c70046565f230694e8bc614f554e4c768b84a3e9675d492f8123514f")
