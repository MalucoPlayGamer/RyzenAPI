-- Lua provided by RyzenAPI
-- Game: Brickfest

-- MAIN APPLICATION
addappid(845940)

-- MAIN APP DEPOTS / PACKAGES
addappid(845942,0,"a39e88ad6bdb282a7e1ad076458953527bafd917c8ae4bb3c52522e6ca4301f2")

