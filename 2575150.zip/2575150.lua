-- Lua provided by RyzenAPI
-- Game: 2575150

-- MAIN APPLICATION
addappid(2575150)
-- Game: addappid(2575150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575151, 1, "1fefeead358b0b5e44995bde2d89db00f1de926f15faeb6435b798bcc35978fe")
