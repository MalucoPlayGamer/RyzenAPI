-- Lua provided by RyzenAPI
-- Game: 1376690

-- MAIN APPLICATION
addappid(1376690)
-- Game: addappid(1376690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376691, 1, "34872acbb28fd410df739a8920755bf90db2c2a590baabae7c3dca1a456b23c1")
