-- Lua provided by RyzenAPI
-- Game: Spire of Glory

-- MAIN APPLICATION
addappid(2220810)
-- Game: addappid(2220810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220811, 1, "2b7e59ca8f0f6cbf788b300f7f19a56177e446e16750899080899b13c034a2e3")
