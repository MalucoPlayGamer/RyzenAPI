-- Lua provided by RyzenAPI
-- Game: AppID 1203650

-- MAIN APPLICATION
addappid(1203650)
-- Game: addappid(1203650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203651, 1, "1485f32146cab64acfcd7324850987cc8dabdf2490934ec7b6bcf72c35a12d64")
