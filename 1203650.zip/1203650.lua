-- Lua provided by RyzenAPI
-- Game: Blood Metal

-- MAIN APPLICATION
addappid(1203650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1203651, 1, "1485f32146cab64acfcd7324850987cc8dabdf2490934ec7b6bcf72c35a12d64")

