-- Lua provided by SkyAPI 
-- Game: Frontline Grunt Playtest
addappid(2073350)
addappid(2073351, 1, "bd9afdf00575a0a04a4812ead73d9a540afdf0fce2a6b11a260dd8bfbddf83cd")
addappid(2073352, 1, "e931819df964b5fc123acfb66d1786f2e6be305edd50487054add6c706a66fbc")
addappid(2073353, 1, "5e8e2842a6721ee35837880c204e6e65002cfaf1e8f58183256e8574dd5d5d6c")
