-- Lua provided by RyzenAPI
-- Game: My intimate love with the devil king

-- MAIN APPLICATION
addappid(1988090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988091, 1, "436b436542388b59113d9e31103d5195174105212aaf5bdd45e9788f2169eea3")
