-- Lua provided by RyzenAPI
-- Game: Crowd Smashers

-- MAIN APPLICATION
addappid(606670)

-- MAIN APP DEPOTS / PACKAGES
addappid(606671,0,"2fe3606ba95d6547013d174692ab89171d9b16065908aefcecafe12f54c3f5a3")

