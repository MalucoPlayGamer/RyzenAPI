-- Lua provided by RyzenAPI
-- Game: Queen of Tower Defense

-- MAIN APPLICATION
addappid(1692900)
-- Game: addappid(1692900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692901, 1, "07b04bdf335d9cbd52226c4d25e3489f12b3c6b128a3692932978d6429789b8a")
