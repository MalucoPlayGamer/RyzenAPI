-- Lua provided by RyzenAPI
-- Game: Neversong

-- MAIN APPLICATION
addappid(733210)
addappid(733211)
addappid(1317970)

-- MAIN APP DEPOTS / PACKAGES
addappid(733212,0,"65d53a2c5558a6d3db985246b35bca4151f321601073f0991c4c70c2d0f40c8f")
addappid(733213,0,"04faf1b29aa4d268fd3dd1a8e59a0d0210b2bc9fdcef1960c1a5682729a2ba51")
