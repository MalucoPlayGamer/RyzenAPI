-- Lua provided by RyzenAPI
-- Game: 军团战棋Legion War

-- MAIN APPLICATION
addappid(975270)
addappid(1681201)

-- MAIN APP DEPOTS / PACKAGES
addappid(975271, 1, "bfceb441fc0553710d51a37ca17f0abf31cebfd67fd874fdfee28bd5f913c40a")
