-- Lua provided by RyzenAPI
-- Game: addappid(508690)

-- MAIN APPLICATION
addappid(508690)

-- MAIN APP DEPOTS / PACKAGES
addappid(508691, 1, "30d446b824916169961844f80a4768f64ded0dd570da46e95d98b71cfcab07e9")
