-- Lua provided by RyzenAPI 
-- Game: Connect the Dots
addappid(1777650)
addappid(1777651, 1, "5514918feec4e8d2dad4ab48ad4d15b4ec95170823198097c7ab6f64194006a8")
