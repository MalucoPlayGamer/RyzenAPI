-- Lua provided by RyzenAPI
-- Game: addappid(662230)

-- MAIN APPLICATION
addappid(662230)

-- MAIN APP DEPOTS / PACKAGES
addappid(662231, 1, "eead6d669c1ed3ca7fba5ef3e9a6335174f237b716f9f5942927e0351e36ff72")
