-- Lua provided by RyzenAPI
-- Game: Trendpoker 3D: Texas Hold'em Poker

-- MAIN APPLICATION
addappid(662230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(662231, 1, "eead6d669c1ed3ca7fba5ef3e9a6335174f237b716f9f5942927e0351e36ff72")

