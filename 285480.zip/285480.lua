-- Lua provided by RyzenAPI
-- Game: Game: The Entente Gold

-- MAIN APPLICATION
addappid(285480)
-- Game: addappid(285480)

-- MAIN APP DEPOTS / PACKAGES
addappid(285481, 1, "b4f120dbb4e224ee137226d65f4528356413e872c8872c9ad88f3b46239c8266")
