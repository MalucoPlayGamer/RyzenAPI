-- Lua provided by RyzenAPI
-- Game: Legend of Mortal

-- MAIN APPLICATION
addappid(1859910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859911, 1, "015b5360486d0725e48b73d3393cd31c90b11b916f093b088bd1e64b6b59d262")

