-- Lua provided by RyzenAPI
-- Game: 3354710

-- MAIN APPLICATION
addappid(3354710)
-- Game: addappid(3354710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354710,0,"9cb792947a664eabd8d88efd302030a1caa5790bbf11c17d39f2c7631357fd6a")
