-- Lua provided by RyzenAPI
-- Game: 谜语女孩

-- MAIN APPLICATION
addappid(1648470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648471, 1, "8cbefdffbb7388920ca8a719b6feb502c3f9934920aa1984e23748580b2ed9fc")

