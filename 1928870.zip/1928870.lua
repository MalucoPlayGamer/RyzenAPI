-- Lua provided by RyzenAPI
-- Game: addappid(1928870)

-- MAIN APPLICATION
addappid(1928870)
addappid(2187940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928871, 1, "77e4ff98428ea4b5db197ad78037b2c0b2ab66399777fa157d1bc84e99fdb289")
