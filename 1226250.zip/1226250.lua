-- Lua provided by RyzenAPI
-- Game: Synthesis: Mind, Body, and Soul

-- MAIN APPLICATION
addappid(1226250)
-- Game: addappid(1226250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226251, 1, "b724e11b55cea607a53eea31cf8a3255259147c1b0e3cc9709d4b2d470d0bca3")
