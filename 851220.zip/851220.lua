-- Lua provided by RyzenAPI
-- Game: addappid(851220)

-- MAIN APPLICATION
addappid(851220)

-- MAIN APP DEPOTS / PACKAGES
addappid(851221, 1, "83d24d91bf1babfd1448f9051d914f47fbc9374401ce3a5580f78cffbbcdc252")
