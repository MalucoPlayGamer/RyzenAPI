-- Lua provided by RyzenAPI
-- Game: Secret Cats - St. Patrick

-- MAIN APPLICATION
addappid(3564530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564531, 1, "99da279f876e0fa406ca39bb7eaf1554421a58e2e25404fb3e648801ae1b4ed4")
addappid(3564538, 1, "e27b9786fc953d4cded1015056bda62aeefbc3dfca007c96b59302bc62523593")

