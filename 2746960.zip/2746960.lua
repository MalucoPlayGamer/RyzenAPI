-- Lua provided by RyzenAPI
-- Game: 凌晨4点不觉间

-- MAIN APPLICATION
addappid(2746960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746961, 1, "26486343ebb0d1ea34c2faf9e3f4b2b5ace5313ac7df5ae3fce9ce7c6d3a91a2")
