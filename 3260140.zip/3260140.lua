-- Lua provided by RyzenAPI
-- Game: 流亡黯道2

-- MAIN APPLICATION
addappid(3260140)
addappid(3404560)
addappid(3404570)
addappid(3404580)
addappid(4756880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260141, 1, "9b8db92cf6eb16c5861dbf0d6ce892faa64c766863f8986de49e7061a68d8b10")
addappid(3260142, 1, "0c5da4ceb6532858498ee91be025a79cd393471bf0b360286967118026338166")

