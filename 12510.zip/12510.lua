-- Lua provided by RyzenAPI 
-- Game: Prison Tycoon 3™: Lockdown
addappid(12510)
addappid(12511, 1, "3fd6ad5caf13aaa8686faff9cc460aae7d0a4bd35d5eb62d2a88688f27fefa1e")
