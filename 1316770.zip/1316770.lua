-- Lua provided by RyzenAPI
-- Game: Sol 705

-- MAIN APPLICATION
addappid(1316770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316771, 1, "0f85e249aa61ed447663d56c4eef960e7ef729d03bdbfaf7fac1ca004cb582b9")
