-- Lua provided by RyzenAPI
-- Game: DFF NT: Zanmato, Garland's 4th Weapon

-- MAIN APPLICATION
addappid(1022401)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022401,0,"a26f0c64d8680eed67cd7df8613d3fb11e47e70b1c1f8fe1a399c74d88f980f4")
