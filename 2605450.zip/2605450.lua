-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Overbearing and preppy girl maid GP-01

-- MAIN APPLICATION
addappid(2605450)
-- Game: addappid(2605450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605451, 1, "d7b2447fb59899687426362157f12586efefc94840179dd6e9526912db17d721")
