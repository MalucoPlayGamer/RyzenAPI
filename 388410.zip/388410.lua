-- Lua provided by RyzenAPI
-- Game: Darksiders II Deathinitive Edition

-- MAIN APPLICATION
addappid(388410)

-- MAIN APP DEPOTS / PACKAGES
addappid(388411, 1, "9897f0901ac852825579c6d178453f4bb46a33e9449a17e6e3d58d2af487df50")
addappid(388412, 1, "225c05c3336f76d730f2dba3a62f4886d48515f619bb3369d73ada74fbd97215")
addappid(388413, 1, "96753de70babfa27928c6bc9b20584f56764ff7fb15b388e866532550e5fefe6")
addappid(388414, 1, "6b13b8d677006140213686d243503d84bdf2aa6a7c55f61b60932d45c8dcff5b")
addappid(388415, 1, "986eed9aaefbef56f9d98c1f02339c22220af75f16c0a70d9bb2860e80421a6a")
addappid(388416, 1, "3d28361fbec3540cf2861863b0c7f3593243fb4658b1b0762fceb44bf8335743")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
