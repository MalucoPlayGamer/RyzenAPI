-- 1016960's Lua and Manifest Created by Hubcap Manifest
-- Super Neptunia RPG
-- Created: September 30, 2025 at 21:00:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 15
-- Total DLCs: 13
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1016960) -- Super Neptunia RPG
-- MAIN APP DEPOTS
addappid(1016961, 1, "4093dedb74bb125ba67f325e6e2aa6b0b6544581c352cc477502eaf65849107b") -- Super Neptunia RPG Content
setManifestid(1016961, "8393918503563648305", 5079885293)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Super Neptunia RPG Deluxe Pack (AppID: 1055680)
addappid(1055680)
addappid(1055680, 1, "9cd29082be60d5046f0839ff938f43b4f13a5fb5c57ed40a76ff4123d2f47380") -- Super Neptunia RPG Deluxe Pack - Dépôt : Super Neptunia RPG Deluxe Pack (1055680)
setManifestid(1055680, "7072647446843450019", 464902231)
-- Super Neptunia RPG - Dengeki Bracelet Set (AppID: 1082571)
addappid(1082571)
addappid(1082571, 1, "53d7b1ccc729b942b6d7ed3765a12b682fb34933c3ceebc7cf343258cac12e69") -- Super Neptunia RPG - Dengeki Bracelet Set - Super Neptunia RPG - Dengeki Bracelet Set (1082571) Depot
setManifestid(1082571, "1601951055039986066", 651)
-- Super Neptunia RPG - Dengeki Accessory Set (AppID: 1082572)
addappid(1082572)
addappid(1082572, 1, "35648604de1563019752e06d0320c6304df9569eb899cfd649d8d0903572344f") -- Super Neptunia RPG - Dengeki Accessory Set - Super Neptunia RPG - Dengeki Accessory Set (1082572) Depot
setManifestid(1082572, "1750393728845578405", 641)
-- Super Neptunia RPG - Famitsu Weapon Set (AppID: 1082573)
addappid(1082573)
addappid(1082573, 1, "6ab8a0745e9cfc16582f0d2d0d8ccd1a86cc9e1dd7bea2cac3e4d915701a1fae") -- Super Neptunia RPG - Famitsu Weapon Set - Super Neptunia RPG - Famitsu Weapon Set (1082573) Depot
setManifestid(1082573, "218254475579945159", 641)
-- Super Neptunia RPG - Enchanted Weapon Set (AppID: 1082574)
addappid(1082574)
addappid(1082574, 1, "aac7d6f44db4fe05f99a89ffe152a1c0a032516f6f630e66077484a77417323c") -- Super Neptunia RPG - Enchanted Weapon Set - Super Neptunia RPG - Enchanted Weapon Set (1082574) Depot
setManifestid(1082574, "313281961533159764", 636)
-- Super Neptunia RPG - [Cosplay Series] Equipment Set (AppID: 1082575)
addappid(1082575)
addappid(1082575, 1, "463ca78dc06506845265250dd2fbd4ad75d5839cf6956d66768c46dc106e7ff9") -- Super Neptunia RPG - [Cosplay Series] Equipment Set - Super Neptunia RPG - [Cosplay Series] Equipment Set (1082575) Depot
setManifestid(1082575, "1983670965577338296", 1727)
-- Super Neptunia RPG - [Foreign Series] Equipment Set (AppID: 1082576)
addappid(1082576)
addappid(1082576, 1, "d3040ba96141ccd5a617e71f2430346a4bd9ddab4541deae096a0f70cb3655b5") -- Super Neptunia RPG - [Foreign Series] Equipment Set - Super Neptunia RPG - [Foreign Series] Equipment Set (1082576) Depot
setManifestid(1082576, "6442356311478488365", 1727)
-- Super Neptunia RPG - [Traditional Series] Equipment Set (AppID: 1082577)
addappid(1082577)
addappid(1082577, 1, "d9ea30a9049b146e0c9bd49b43b91f77d552bd783c67ee0912f507fcc08ce657") -- Super Neptunia RPG - [Traditional Series] Equipment Set - Super Neptunia RPG - [Traditional Series] Equipment Set (1082577) Depot
setManifestid(1082577, "2375797286636862253", 1727)
-- Super Neptunia RPG - [Enchanted Series] Equipment Set (AppID: 1082578)
addappid(1082578)
addappid(1082578, 1, "df5d952b9f1416138c0fe696b4c93a75a3b364ea2c2608159f7213a4159e6817") -- Super Neptunia RPG - [Enchanted Series] Equipment Set - Super Neptunia RPG - [Enchanted Series] Equipment Set (1082578) Depot
setManifestid(1082578, "1036466205771342407", 1187)
-- Super Neptunia RPG - Additional Party Members Set (AppID: 1082579)
addappid(1082579)
addappid(1082579, 1, "9058c06b77623ce865be47529f995ade3336797e1d03b0d06297dc33c22fdacb") -- Super Neptunia RPG - Additional Party Members Set - Super Neptunia RPG - Additional Party Members Set (1082579) Depot
setManifestid(1082579, "5240824931579014062", 2454)
-- Super Neptunia RPG - Animal Ears and Tails Set (AppID: 1082580)
addappid(1082580)
addappid(1082580, 1, "cce3dad2f093b41f6bbf9d7641ec8f9557b6279923c19ff3fa6f24ff3091431d") -- Super Neptunia RPG - Animal Ears and Tails Set - Super Neptunia RPG - Animal Ears and Tails Set (1082580) Depot
setManifestid(1082580, "2345406119007396276", 493)
-- Super Neptunia RPG - Swimsuit Set (AppID: 1082581)
addappid(1082581)
addappid(1082581, 1, "39c208d49e50491262d81326cf8f391bbe411a5afd3a9467f686361e5f5dc812") -- Super Neptunia RPG - Swimsuit Set - Super Neptunia RPG - Swimsuit Set (1082581) Depot
setManifestid(1082581, "8258661492553642674", 24573442)
-- Super Neptunia RPG - Sentai Set (AppID: 1082582)
addappid(1082582)
addappid(1082582, 1, "aee6b8bcc07b5066f4a203a02cb17de5fd42c80a3a6d271e24e0836eced707e0") -- Super Neptunia RPG - Sentai Set - Super Neptunia RPG - Sentai Set (1082582) Depot
setManifestid(1082582, "8677659425312486067", 41203535)