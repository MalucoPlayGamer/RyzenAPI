-- Lua provided by RyzenAPI
-- Game: Game: Astro Lords: Oort Cloud

-- MAIN APPLICATION
addappid(372190)
-- Game: addappid(372190)

-- MAIN APP DEPOTS / PACKAGES
addappid(372191, 1, "33f99a2416840b2980184a07c5d0167d2fcdbbf7b63570600b73e8e3c4a0d5fc")
