-- Lua provided by RyzenAPI
-- Game: Astro Lords: Oort Cloud

-- MAIN APPLICATION
addappid(372190)

-- MAIN APP DEPOTS / PACKAGES
addappid(372191, 1, "33f99a2416840b2980184a07c5d0167d2fcdbbf7b63570600b73e8e3c4a0d5fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
