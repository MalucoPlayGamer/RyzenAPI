-- Lua provided by SkyAPI 
-- Game: Astro Lords: Oort Cloud
addappid(372190)
addappid(372191, 1, "33f99a2416840b2980184a07c5d0167d2fcdbbf7b63570600b73e8e3c4a0d5fc")
