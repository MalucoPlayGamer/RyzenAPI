-- Lua provided by RyzenAPI
-- Game: Sudd City Adventures

-- MAIN APPLICATION
addappid(1238970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238971, 1, "16d1d0865abde4bac80d135ff2d3bdd1ce2704b51f182c80f04926520220076c")

