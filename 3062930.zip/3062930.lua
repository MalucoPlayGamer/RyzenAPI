-- Lua provided by RyzenAPI
-- Game: addappid(3062930)

-- MAIN APPLICATION
addappid(3062930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062931, 1, "a4239dc3cc7db880d7f670cca3e1ef5d0d51fb20dc18b95577354eac0665a104")
