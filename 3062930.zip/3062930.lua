-- Lua provided by RyzenAPI
-- Game: Unplagued

-- MAIN APPLICATION
addappid(3062930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3062931, 1, "a4239dc3cc7db880d7f670cca3e1ef5d0d51fb20dc18b95577354eac0665a104")

