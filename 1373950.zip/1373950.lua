-- Lua provided by RyzenAPI
-- Game: The Divine Speaker

-- MAIN APPLICATION
addappid(1373950)
-- Game: addappid(1373950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373951, 1, "b9eba4da91a17c75b7830fc6e2b1cf371d7ba05487884f8fd06eb139312fe47d")
addappid(1374250, 0, "20287ae0cb7f8e7ef95299c3645a736813e0bf1cbdf3c802a60e6caf2ca4a478")
addappid(1953040, 0, "950d860e808fca907ac227e8304284897d795dfbc3701b06da5da440cd6c4415")
