-- Lua provided by RyzenAPI
-- Game: Golden Warden Demo

-- MAIN APPLICATION
addappid(3192430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192431, 1, "35431c9e9437ddbd081ba48028376e0f5fe532a20c43329906d75f52f5c74871")
