-- Lua provided by RyzenAPI
-- Game: addappid(3213790)

-- MAIN APPLICATION
addappid(3213790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213791, 1, "68d3d35d14733d62c1beec3bab1123df0fbe6e56e0a5c4be8d390d9c6ae531df")
