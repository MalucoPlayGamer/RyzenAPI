-- Lua provided by RyzenAPI
-- Game: Spellcrafter

-- MAIN APPLICATION
addappid(315680)

-- MAIN APP DEPOTS / PACKAGES
addappid(315681, 1, "721a7a4fee175e0cb10247e8367df20ae744c05ca11f64bdb06852aa77ec4d04")
