-- Lua provided by RyzenAPI
-- Game: AppID 999660

-- MAIN APPLICATION
addappid(999660)

-- MAIN APP DEPOTS / PACKAGES
addappid(999661, 1, "2411dc4d6ee6c0c67fa07e46d407a770aa697adf4b9f833eb422da45982a5f4e")
