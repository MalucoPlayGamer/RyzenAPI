-- Lua provided by RyzenAPI
-- Game: addappid(1895410)

-- MAIN APPLICATION
addappid(1895410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895411, 1, "ab45d78b8be770a9d966e54b55fdec7ed98a0a11fb3f608bbecb05fccc82cb73")
