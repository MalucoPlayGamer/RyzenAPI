-- Lua provided by RyzenAPI
-- Game: addappid(1537430)

-- MAIN APPLICATION
addappid(1537430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537431, 1, "fcdc0445f05a90f94364a2f305fc0bf1363f19b96efcf6da6ef90dc884ec5476")
