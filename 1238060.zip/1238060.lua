-- Lua provided by RyzenAPI
-- Game: AppID 1238060

-- MAIN APPLICATION
addappid(1238060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238061, 1, "09ee2451425a5148724b2d2101bdaf9cb434f1aa4d393e4c76e7d1daae29a63c")
addappid(1238062, 1, "e5de2dcf02fadbfbfe2b4c057d776ae5d30a06d7c621c1d18eb9e00667f1c8db")
addappid(1238063, 1, "c625f82d02df1fe0b09f24c595c173889060c6c0911ead730e2314a87c63d2b8")
addappid(1238064, 1, "237e8e595a92b5a3148088c9a47677a50a10cb72b649a770dac35dcdd46fceb8")
addappid(1238065, 1, "5cbf968b1ab64672dad8de9949bf114ecfcca11788193d656467420c9b82171e")
addappid(1238066, 1, "512d341fe2989fceecca7e3585636e2391edcc1bf4001dadd67672e3bf759e24")
addappid(1238067, 1, "8084d68b25aed60a6912763f873cea7fb871a8eb9022e6b55aae2d423932dfc9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1238070)
addappid(1303190)
addappid(1303191)
addappid(1303192)
addappid(1303193)
addappid(1303194)
addappid(1303195)
addappid(1303196)
addappid(1303197)
addappid(1303198)
addappid(1303199)
addappid(1303200)
addappid(1303201)
