-- Lua provided by RyzenAPI
-- Game: 794540

-- MAIN APPLICATION
addappid(794540)
addappid(794544)

-- MAIN APP DEPOTS / PACKAGES
addappid(794542,0,"1fac0330fbe6f88bdae0cecd91255419a9fb5f82b13da42e067f25a680421d9e")
addappid(794543,0,"5674adef25570b7d884f223a670ab8220288b05dd34cbc60de381bb83ace470e")
