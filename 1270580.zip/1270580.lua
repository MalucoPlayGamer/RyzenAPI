-- Lua provided by RyzenAPI
-- Game: Mind Over Magic

-- MAIN APPLICATION
addappid(1270580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270581, 1, "67890182f6c150a904481b542ff399526709e363f448cb001c6cb02fbf8cfe70")

