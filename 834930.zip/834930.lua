-- Lua provided by RyzenAPI 
-- Game: AppID 834930
addappid(834930)
addappid(834931, 1, "a3cd12c802606863db90a47fb118b9980ba800ff5bd6c1321e553229a217bf8d")
