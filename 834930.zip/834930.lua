-- Lua provided by RyzenAPI
-- Game: Bishi and the Alien Slime Invasion!

-- MAIN APPLICATION
addappid(834930)

-- MAIN APP DEPOTS / PACKAGES
addappid(834931, 1, "a3cd12c802606863db90a47fb118b9980ba800ff5bd6c1321e553229a217bf8d")
