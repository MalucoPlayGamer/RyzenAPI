-- 3929330's Lua and Manifest Created by Hubcap Manifest
-- Relief
-- Created: June 23, 2026 at 00:51:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3929330) -- Relief
-- MAIN APP DEPOTS
addappid(3929331, 1, "17ded237a6fb72f1fbc3a819e4a05690e49ca77c2f2bdc585ba578ffcd7056e5") -- Depot 3929331
-- setManifestid(3929331, "8761668630906811708", 3226905283)