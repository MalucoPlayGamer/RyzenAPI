-- Lua provided by RyzenAPI
-- Game: AppID 987150

-- MAIN APPLICATION
addappid(987150)

-- MAIN APP DEPOTS / PACKAGES
addappid(987151, 1, "236a406fa5009d0b4f60fdd07cb27384bd7b19cb3718e9e300cb9bd675d97f09")

