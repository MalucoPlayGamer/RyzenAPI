-- Lua provided by RyzenAPI
-- Game: Azure Saga: Pathfinder

-- MAIN APPLICATION
addappid(672590)

-- MAIN APP DEPOTS / PACKAGES
addappid(672591, 1, "6d0dd4932855233a0ae146a4bfd6d8887f6f3e7525e29aab380da3768880cd9c")
addappid(672592, 1, "50678f7f346a64a030ebf752f635741affff1f8d2a67c1b8f22041709d5a8f4f")
addappid(672593, 1, "c2e068c347a6717d82907bf46987bd4cc3d9f7bfd93734c5d9bf53234037b10a")
addappid(672594, 1, "4101ea1ee2f6daacb1eef835ee3fa4401cfed9e2536bba04b555250f16f11bed")
addappid(672595, 1, "87de8e354b2528215cf39d9a31be8cf530ba479302b22220f4e971d6ec6188ee")
addappid(672596, 1, "a22dcce36e34b1c06f0d118739a72a6ced7bd15e197116d548cb31f7805f774d")
addappid(672597, 1, "102e843dc7db4e2c779f657216e9c9418c05d612c5c72f9d112b60787e34d48d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(699000)
addappid(782770)
addappid(783030)
addappid(783040)
