-- Lua provided by RyzenAPI
-- Game: Game: AppID 1079340

-- MAIN APPLICATION
addappid(1079340)
-- Game: addappid(1079340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079341, 1, "0d257c7c278aac683791db4bfc28c25f68a20742b938f5798155a78acfc1e8d1")
