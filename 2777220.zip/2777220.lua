-- Lua provided by RyzenAPI
-- Game: 2777220

-- MAIN APPLICATION
addappid(2777220)
-- Game: addappid(2777220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777221, 1, "9cfab5cea698139b133db1decad53c94cbc9624098866aa9863da26855b6fa8e")
