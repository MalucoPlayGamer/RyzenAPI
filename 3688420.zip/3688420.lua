-- Lua provided by SkyAPI 
-- Game: Brainrot: Animal Quizzes
addappid(3688420)
addappid(3688421, 1, "b2973a072c7c4463672129fff3d2b5e1c7b3c84d20c4ad5d22652659c0372ab4")
