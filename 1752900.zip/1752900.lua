-- Lua provided by RyzenAPI
-- Game: Old Content Pack - The Durka: You will (not) die

-- MAIN APPLICATION
addappid(1752900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752900,0,"7785226278abcffd3b55457d45d10cba6e998eb040c114909678bcc6ce254846")
