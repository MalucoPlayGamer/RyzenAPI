-- Lua provided by RyzenAPI
-- Game: Miner: Dig Deep

-- MAIN APPLICATION
addappid(1441790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441791, 1, "01a26bd7d51ffdc0736e1ec37eed5ae5f248166f677aace0c5cfe9cbb190e181")
