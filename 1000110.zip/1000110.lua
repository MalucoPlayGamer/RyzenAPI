-- Lua provided by RyzenAPI
-- Game: Game: Jumping Master(跳跳大咖)

-- MAIN APPLICATION
addappid(1000110)
-- Game: addappid(1000110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000111, 1, "1d089a895aa6ec701181e774630d4805bf7e787214e52717983fab0eec59d5f6")
