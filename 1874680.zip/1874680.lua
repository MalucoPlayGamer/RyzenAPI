-- Lua provided by RyzenAPI 
-- Game: Tower Words
addappid(1874680)
addappid(1874681, 1, "908a6d5bd5f9a26abaa4a4fce648189fe2b9ea241e48996ebdbec204a172bc61")
addappid(1874683, 1, "56104705e0629aa436585467a6a7e895ecf85d3063b869c91aae6a15786956de")
