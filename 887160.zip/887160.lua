-- Lua provided by RyzenAPI
-- Game: Game: The Sunny Day 晴天

-- MAIN APPLICATION
addappid(887160)
-- Game: addappid(887160)

-- MAIN APP DEPOTS / PACKAGES
addappid(887161, 1, "9a1d2fd5c0da80f486875952465781d4e1a1aa354f9ad09c348450d2d72eb185")
