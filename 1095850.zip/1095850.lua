-- Lua provided by RyzenAPI
-- Game: 1001 Jigsaw. 6 Magic Elements

-- MAIN APPLICATION
addappid(1095850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095851, 1, "11339908b04eb7d83d9387e5b3c38351fe8a9459284d7e28033840f442c3b548")

