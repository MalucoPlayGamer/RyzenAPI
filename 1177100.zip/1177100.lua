-- Lua provided by RyzenAPI
-- Game: 末法时代

-- MAIN APPLICATION
addappid(1177100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177101, 1, "acbf0135a597aac55752930e6f4ca81fd3ee5c738118a3c0b98b36ca524aa73b")

