-- Lua provided by RyzenAPI
-- Game: Game: Faith of Fate

-- MAIN APPLICATION
addappid(1095750)
-- Game: addappid(1095750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095751, 1, "fdc0e78a39dcb8c669cd424e4bf87c5041248f8bd914bf5f17f59a258121b7fa")
