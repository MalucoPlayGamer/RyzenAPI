-- Lua provided by RyzenAPI
-- Game: Game: Last Report

-- MAIN APPLICATION
addappid(3209480)
-- Game: addappid(3209480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209481, 1, "cd783437d27e2a39f961592e9b07cea05662d93e0799c248158afdbd8b1fb1d8")
