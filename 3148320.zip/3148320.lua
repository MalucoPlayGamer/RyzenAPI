-- Lua provided by RyzenAPI
-- Game: Let's Café Demo

-- MAIN APPLICATION
addappid(3148320)
-- Game: addappid(3148320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148321, 1, "c6fa9f329c872ea98c3eb71f49fc0c09069f9c7bbe8fe24841f653030c4df2b2")
