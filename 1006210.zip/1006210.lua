-- Lua provided by RyzenAPI
-- Game: A Front Too Far: Normandy - Deluxe Pass

-- MAIN APPLICATION
addappid(1006210)
-- Game: addappid(1006210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006210,0,"b47f2ec0e81790a6205f0a30b4d69f431dd83daf4ef046215f00be59e28ecac2")
