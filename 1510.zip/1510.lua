-- Lua provided by RyzenAPI
-- Game: Uplink

-- MAIN APPLICATION
addappid(1510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511, 1, "76f497fa363b401fb30ffd3cd93fbd2d89bf923c8a7be2fdf30ed4ddbb736953")
addappid(1512, 1, "934051dc86160e5568077f60afbec5e194a78b7f4905acbe2251f305856c2053")
addappid(1513, 1, "456dd677f029f2a0ce6165ca8df0bb59b0dcdd1cbd95176373398224f18d01d2")
