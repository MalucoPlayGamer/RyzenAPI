-- Lua provided by RyzenAPI
-- Game: Glazed Mirror : Myriad Cards

-- MAIN APPLICATION
addappid(3810920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3810921, 1, "5103057f6abf458f98f016ee2341a5c8f3ae7aee961fe7224d7427c791fc8791")

