-- Lua provided by RyzenAPI
-- Game: Glazed Mirror : Myriad Cards

-- MAIN APPLICATION
addappid(3810920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3810921, 1, "5103057f6abf458f98f016ee2341a5c8f3ae7aee961fe7224d7427c791fc8791")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
