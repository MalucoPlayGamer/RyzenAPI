-- Lua provided by RyzenAPI
-- Game: Sakura Hime

-- MAIN APPLICATION
addappid(1732740)
-- Game: addappid(1732740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732741, 1, "882a2f7e5e0604fd2848ed8459f6889fb4d91a19288b10abb196b1e4db6dbf2b")
addappid(1777420, 0, "99700144749cb71563e59d1365a08f98b71a361fca07bd3d30c266773e1fa325")
