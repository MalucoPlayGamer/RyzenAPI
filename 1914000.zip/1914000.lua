-- Lua provided by RyzenAPI
-- Game: Sweet Car Wash

-- MAIN APPLICATION
addappid(1914000)
-- Game: addappid(1914000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914001, 1, "742a99cc3f987e639ff03dd49f689d1e16127141272bc2619c6fc5b20bb47909")
