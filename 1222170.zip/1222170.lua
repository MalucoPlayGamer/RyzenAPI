-- Lua provided by RyzenAPI
-- Game: Cutish

-- MAIN APPLICATION
addappid(1222170)
-- Game: addappid(1222170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222171, 1, "ec9484e11b6310aef9f63599f3c53668941d3d2443533f95814398d896b2b9a6")
