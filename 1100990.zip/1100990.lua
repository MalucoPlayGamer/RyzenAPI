-- Lua provided by SkyAPI 
-- Game: AppID 1100990
addappid(1100990)
addappid(1100991, 1, "69f99e6fabb2960fe0df5b6923e0eab32bb388925a069afe327c6fa649413315")
