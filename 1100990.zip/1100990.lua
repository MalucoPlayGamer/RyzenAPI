-- Lua provided by RyzenAPI
-- Game: addappid(1100990)

-- MAIN APPLICATION
addappid(1100990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100991, 1, "69f99e6fabb2960fe0df5b6923e0eab32bb388925a069afe327c6fa649413315")
