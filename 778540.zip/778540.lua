-- Lua provided by RyzenAPI
-- Game: Big Blue - Memory

-- MAIN APPLICATION
addappid(778540)
-- Game: addappid(778540)

-- MAIN APP DEPOTS / PACKAGES
addappid(778542,0,"666022f3afda8da4836d3bc747c3943158df8f3a865620000114af183b61ae94")
