-- Lua provided by RyzenAPI
-- Game: Game: Adult Puzzles - Fantasy Ladies

-- MAIN APPLICATION
addappid(1789060)
-- Game: addappid(1789060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789061, 1, "336ed1308e51f08868430b78ae144790ab20a5e4db91832c27cdb52bcf5a2033")
addappid(1792180, 0, "2cc0186246bea42b4d3685a3d20d7f054d81e518875f4a93f6adc3a14b0bde6f")
