-- Lua provided by RyzenAPI
-- Game: Deadfall Tropics

-- MAIN APPLICATION
addappid(842770)

-- MAIN APP DEPOTS / PACKAGES
addappid(842771,0,"7d25fe43edb4f9d157263f8dc8e26c0b0aac42c9c8262f5710181604619ffcce")

