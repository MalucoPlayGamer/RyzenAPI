-- Lua provided by RyzenAPI
-- Game: Jigsaw Pieces - Sweet Times

-- MAIN APPLICATION
addappid(1523680)
-- Game: addappid(1523680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523681, 1, "807356724559b36d743755d00df19da75757b50b34e77701ee9bbe9af3271260")
