-- Lua provided by RyzenAPI 
-- Game: AppID 1523680
addappid(1523680)
addappid(1523681, 1, "807356724559b36d743755d00df19da75757b50b34e77701ee9bbe9af3271260")
