-- Lua provided by SkyAPI 
-- Game: AppID 541450
addappid(541450)
addappid(541451, 1, "d07f42af532f92a5200d13598dfb74d902318c589395ef27f88753453e1a3c56")
addappid(548820, 0, "64e17dbeb4ada2fb9288260071ecfc6c8115556b96e80e77a39ecf855465dc9e")
