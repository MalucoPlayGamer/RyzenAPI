-- Lua provided by RyzenAPI
-- Game: Operation Abyss: New Tokyo Legacy

-- MAIN APPLICATION
addappid(541450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(541451, 1, "d07f42af532f92a5200d13598dfb74d902318c589395ef27f88753453e1a3c56")
addappid(548820, 0, "64e17dbeb4ada2fb9288260071ecfc6c8115556b96e80e77a39ecf855465dc9e")
