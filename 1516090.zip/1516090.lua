-- Lua provided by RyzenAPI
-- Game: AppID 1516090

-- MAIN APPLICATION
addappid(1516090)
-- Game: addappid(1516090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516091, 1, "7bf95e4f0d7b97af3ef63facbda38539e817e7b3dd6e4a44d776c5ed878c6d1f")
