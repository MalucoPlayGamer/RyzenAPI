-- Lua provided by RyzenAPI
-- Game: Wolfenstein: The Old Blood German Edition

-- MAIN APPLICATION
addappid(354830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(354831, 1, "f26ef2afdec67f4de28d3a7c5548ab97561c0614c1cb1cff1c1fe1d27098fe96")
addappid(354832, 1, "a8c108079177480c69c620f7fd0c121672592294b961d680c42034340378a1db")
addappid(354833, 1, "2613683f6f21a560345fca6f9b03fcede863b3248aa3fa5659322d3896484e18")
addappid(354834, 1, "a3a70d1d34bf9dadd0b4abfc94ac0a94f576789ed24055efac96dc39382d7ddb")
addappid(354835, 1, "b0de508d036d33cbbf05af8ff8bd224ec154069b87546be45af07fcc0d0f26fc")
addappid(354836, 1, "7892e02e6885eaae2c381d67cc75aace27a0f305a370d31d8f18616b9fd9d891")

