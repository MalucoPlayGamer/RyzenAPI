-- Lua provided by RyzenAPI
-- Game: 1376960

-- MAIN APPLICATION
addappid(1376960)
-- Game: addappid(1376960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376966,0,"ab83a8abbf103864f6b32a5b03a70d7c1ccbe21cc60df48b9fe085d7f26f225d")
