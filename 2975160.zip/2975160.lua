-- Lua provided by RyzenAPI
-- Game: Rose and Cross

-- MAIN APPLICATION
addappid(2975160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975161, 1, "7d2dd5aa164c6e37b8b84aea04706f6b9dd43737d8911aff4482d654fd09511c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
