-- Lua provided by RyzenAPI
-- Game: Rose and Cross

-- MAIN APPLICATION
addappid(2975160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975161, 1, "7d2dd5aa164c6e37b8b84aea04706f6b9dd43737d8911aff4482d654fd09511c")
