-- Lua provided by RyzenAPI 
-- Game: Myst of Guatemala
addappid(3094220)
addappid(3094221, 1, "67bbc78d518385d6bab23e835ff35366cebef777a342e2e78a24790dd1c4120f")
