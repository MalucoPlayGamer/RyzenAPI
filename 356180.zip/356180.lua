-- Lua provided by RyzenAPI
-- Game: AppID 356180

-- MAIN APPLICATION
addappid(356180)

-- MAIN APP DEPOTS / PACKAGES
addappid(356181, 1, "a82b2960d0d8a77bad5155b6cada05715e3981833a245784f19c942148b8a121")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
