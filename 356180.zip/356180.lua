-- Lua provided by RyzenAPI 
-- Game: AppID 356180
addappid(356180)
addappid(356181, 1, "a82b2960d0d8a77bad5155b6cada05715e3981833a245784f19c942148b8a121")
