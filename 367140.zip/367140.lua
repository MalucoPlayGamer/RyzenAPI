-- Lua provided by RyzenAPI
-- Game: Wish Project

-- MAIN APPLICATION
addappid(367140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(367141, 1, "26c017139f5ac45f729cb84483d4a3efe3482bc9d4fb33e11aab545218609cfb")
addappid(367142, 1, "d221f77c1e577f12ae7c62b14a4d8b0be4710a5652738a2e969fa0e3cb58edd0")

