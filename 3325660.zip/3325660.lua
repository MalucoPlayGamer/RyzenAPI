-- Lua provided by RyzenAPI
-- Game: AlibAi

-- MAIN APPLICATION
addappid(3325660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325661, 1, "ac424ce21fe274daab593804380068e12c46324dd9af5a6ce412d21ba18f62c4")

