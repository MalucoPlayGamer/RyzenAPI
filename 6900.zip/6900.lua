-- Lua provided by RyzenAPI
-- Game: Hitman: Codename 47

-- MAIN APPLICATION
addappid(6900)
-- Game: addappid(6900)

-- MAIN APP DEPOTS / PACKAGES
addappid(6901, 1, "d25399049135c7c3bdea21733a0829eb22589226194a174261d90eb16f249872")
