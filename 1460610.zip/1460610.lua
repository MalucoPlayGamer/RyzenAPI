-- Lua provided by RyzenAPI
-- Game: hocus 2

-- MAIN APPLICATION
addappid(1460610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460611, 1, "032afa8c36e6448a200c3c765298d5a21177746c28e8c6bc46b3f32b29a4c8f1")

