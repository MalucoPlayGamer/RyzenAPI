-- Lua provided by RyzenAPI
-- Game: Draw & Guess

-- MAIN APPLICATION
addappid(1483870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1483871, 1, "3e39df44a18dd1013bc7a6a9fcb645852308303acb9901fca0686753cd371508")
addappid(1483872, 1, "6b21827b939f59ad3d9eda1d3059d61b71712e7d456d0d3a97fbb37956ee87c6")
addappid(1483873, 1, "42b18e61776276b0d3cd1bbb0ddde9c35284f6cdc57a88fd55c8f20cd3d78660")
