-- Lua provided by RyzenAPI
-- Game: Overlay Translator

-- MAIN APPLICATION
addappid(4864520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4864521,0,"035b6d92706d811e67938972fd933adcb92e569213c861296238ac4da324681c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5088730)
