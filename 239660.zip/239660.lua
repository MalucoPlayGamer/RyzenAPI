-- Lua provided by RyzenAPI
-- Game: Soldier Front 2

-- MAIN APPLICATION
addappid(239660)

-- MAIN APP DEPOTS / PACKAGES
addappid(239661, 1, "89ee18e3236eae95fbb1a23691ad5a4e1f5848e51fe1c521bc895416e0276158")

