-- Lua provided by SkyAPI 
-- Game: AppID 909150
addappid(909150)
addappid(909151, 1, "1f155b1e6e1af9814a37b3924c434486031de5583aaf01c1ef2e53a1db306184")
addappid(909152, 1, "d6e81b812908fd883b9338aba6467bca27b346e912cf19dd962986164dc4a7ee")
