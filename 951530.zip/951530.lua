-- Lua provided by RyzenAPI
-- Game: Alien Shooter - Last Hope

-- MAIN APPLICATION
addappid(951530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(951531, 1, "97adef70c3b686f7d5ea008ffa9b47e4bd270079cb6e22ad33306f8f4c623cb7")
addappid(951533, 1, "5774837a45730d5140eb8cf0c5f5a712544cce2eaf428e3b8eb4b9039cf5badc")

