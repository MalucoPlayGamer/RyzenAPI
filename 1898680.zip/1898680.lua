-- Lua provided by RyzenAPI
-- Game: Game: Shadow Era

-- MAIN APPLICATION
addappid(1898680)
-- Game: addappid(1898680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898681, 1, "c231757dcb361d29fb4d198c42a5be921f8bfe30b506a3f9cdcccbc95e4c09b6")
