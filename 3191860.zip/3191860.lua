-- Lua provided by RyzenAPI
-- Game: 3191860

-- MAIN APPLICATION
addappid(3191860)
-- Game: addappid(3191860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191861, 1, "72eaa995a9af09ffafe7d8c2e8537e1d1cbe56d90ca94ae759475f60666fcd4d")
