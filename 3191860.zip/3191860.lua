-- Lua provided by RyzenAPI
-- Game: Cult -Vein-

-- MAIN APPLICATION
addappid(3191860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3191861, 1, "72eaa995a9af09ffafe7d8c2e8537e1d1cbe56d90ca94ae759475f60666fcd4d")

