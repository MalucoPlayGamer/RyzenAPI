-- Lua provided by RyzenAPI
-- Game: addappid(2717780)

-- MAIN APPLICATION
addappid(2717780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717782,0,"9e0288637fee211ac5e2687354fcb666eefd367c90d036fc1b6a754ceb6a43fc")
