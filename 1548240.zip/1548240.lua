-- Lua provided by RyzenAPI
-- Game: Game: Therais Book

-- MAIN APPLICATION
addappid(1548240)
-- Game: addappid(1548240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548241, 1, "4cc49bd6f0b856b561e2e8798620986e80068be47a4024cb964c794d36d8a46f")
addappid(1548242, 1, "e22e60642f34952b070acd3312e8dd86d00139f5b9c64ed652d7762d75b3d216")
