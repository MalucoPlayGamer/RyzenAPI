-- Lua provided by RyzenAPI
-- Game: AppID 2774580

-- MAIN APPLICATION
addappid(2774580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774581, 1, "a95f1a5b0efa0da4a03ca28d6a8bb4e4dd6aa6172b7849bae4fae95bb5ddc5db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
