-- Lua provided by RyzenAPI
-- Game: addappid(2774580)

-- MAIN APPLICATION
addappid(2774580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774581, 1, "a95f1a5b0efa0da4a03ca28d6a8bb4e4dd6aa6172b7849bae4fae95bb5ddc5db")
