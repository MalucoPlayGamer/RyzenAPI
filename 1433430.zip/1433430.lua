-- Lua provided by RyzenAPI 
-- Game: AppID 1433430
addappid(1433430)
addappid(1433431, 1, "e6e702dc285c43b8b540aa99c02936c4c95aafa609d8625f4a4e26291b9b9959")
