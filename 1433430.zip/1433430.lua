-- Lua provided by RyzenAPI
-- Game: 1433430

-- MAIN APPLICATION
addappid(1433430)
-- Game: addappid(1433430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433431, 1, "e6e702dc285c43b8b540aa99c02936c4c95aafa609d8625f4a4e26291b9b9959")
