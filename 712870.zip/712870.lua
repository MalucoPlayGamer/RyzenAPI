-- Lua provided by RyzenAPI
-- Game: Vectorium

-- MAIN APPLICATION
addappid(712870)
addappid(712920)

-- MAIN APP DEPOTS / PACKAGES
addappid(712871, 1, "16b06e082e3c7acaac2cb40ca8dd37c2b72688f8057a2606dc0ff519e17b0292")

