-- Lua provided by RyzenAPI
-- Game: CUCKOLD SIMULATOR: Covid-19 Mask

-- MAIN APPLICATION
addappid(1618840)
-- Game: addappid(1618840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618840,0,"fc1dac009d8e69b291ca531ff6cc4bf7ed02b82026ca2f6ad45602e8665fecfd")
