-- Lua provided by RyzenAPI 
-- Game: Super Idol
addappid(1529990)
addappid(1529991, 1, "74e3094018de4704a22dfd5c8604136c0d5be31dc8cc352a5eccd238870ed84d")
