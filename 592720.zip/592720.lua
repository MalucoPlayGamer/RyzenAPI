-- Lua provided by RyzenAPI
-- Game: Paulo's Wing

-- MAIN APPLICATION
addappid(592720)

-- MAIN APP DEPOTS / PACKAGES
addappid(592721,0,"872a7633b2aebcc9dce36ef78adefd8bfa1c65b1718f7c8a9d8ef00fd26c195f")

