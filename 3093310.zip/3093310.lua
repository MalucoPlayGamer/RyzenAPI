-- Lua provided by RyzenAPI
-- Game: AppID 3093310

-- MAIN APPLICATION
addappid(3093310)
-- Game: addappid(3093310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093311, 1, "7f3521f2a0b36a6640747a11ea3a6e779f4739653d4f4606bdfddeee3d9e923a")
