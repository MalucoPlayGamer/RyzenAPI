-- Lua provided by RyzenAPI
-- Game: Precept

-- MAIN APPLICATION
addappid(3115520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3115521, 1, "c66d1c18d17614ea7ec7c589173eb37e938e9a9798d1c1c1fde55af8c41f2a7d")

