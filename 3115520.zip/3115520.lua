-- Lua provided by RyzenAPI
-- Game: 3115520

-- MAIN APPLICATION
addappid(3115520)
-- Game: addappid(3115520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115521, 1, "c66d1c18d17614ea7ec7c589173eb37e938e9a9798d1c1c1fde55af8c41f2a7d")
