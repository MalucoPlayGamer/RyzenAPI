-- Lua provided by RyzenAPI 
-- Game: Precept
addappid(3115520)
addappid(3115521, 1, "c66d1c18d17614ea7ec7c589173eb37e938e9a9798d1c1c1fde55af8c41f2a7d")
