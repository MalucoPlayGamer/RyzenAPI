-- Lua provided by RyzenAPI
-- Game: 1179080

-- MAIN APPLICATION
addappid(1179080)
-- Game: addappid(1179080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179081, 1, "40122caea18839e74b2f926cd9480cd510cb2c2e9134d51acb5774cec3f751c6")
