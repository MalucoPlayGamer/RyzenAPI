-- Lua provided by RyzenAPI
-- Game: addappid(1515280)

-- MAIN APPLICATION
addappid(1515280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515281, 1, "f71ceced7715ba7b67c8fc44260109dbf2e64ddb66956a61ebd980f1035ce45d")
