-- Lua provided by RyzenAPI
-- Game: addappid(973740)

-- MAIN APPLICATION
addappid(973740)

-- MAIN APP DEPOTS / PACKAGES
addappid(973744,0,"ed32db1a70aa32523032c4d8e0318da8957b6c1b97b3b5904c34d2f75cfc9423")
