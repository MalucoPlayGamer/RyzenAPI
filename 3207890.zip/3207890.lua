-- Lua provided by RyzenAPI
-- Game: Lusty Mother

-- MAIN APPLICATION
addappid(3207890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207891, 1, "00c43ae65c45cb86af4d94e72198e058517d444d0e9afa30a98febcca0b525ec")
