-- Lua provided by RyzenAPI
-- Game: RetroArch - Picodrive

-- MAIN APPLICATION
addappid(1227460)
-- Game: addappid(1227460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227460,0,"5a449c0295033e1c133eac5aa404ec4add2078cf59d23eeb0583e24e370beede")
addappid(1789940,0,"35a2ccb96713b040a63124ce90da4f4cb62e28ab8a2f6556a001e4a31d2f858e")
addappid(1789941,0,"7f4c1173f6192f88670c898cbb5bf52aa67bc8a02ef0f77d555ba0c44dcbd4d9")
