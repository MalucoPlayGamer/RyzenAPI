-- Lua provided by RyzenAPI
-- Game: Space Rescue

-- MAIN APPLICATION
addappid(2018030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018031, 1, "97fd1878bca9f6f9bb2be511e66a1c5bd8a2b5bc12c3f18d2f599be6daeb1d5b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
