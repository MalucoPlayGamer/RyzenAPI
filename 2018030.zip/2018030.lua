-- Lua provided by RyzenAPI
-- Game: 2018030

-- MAIN APPLICATION
addappid(2018030)
-- Game: addappid(2018030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018031, 1, "97fd1878bca9f6f9bb2be511e66a1c5bd8a2b5bc12c3f18d2f599be6daeb1d5b")
