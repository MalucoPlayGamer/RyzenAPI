-- Lua provided by RyzenAPI 
-- Game: PRINCESS IN AIRINESS
addappid(1688250)
addappid(1688251, 1, "82be8ed5f3b6a70678d34e0937fce07c86ddae5fa44b37e37b5bbcbec8e85006")
