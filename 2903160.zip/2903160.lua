-- Lua provided by RyzenAPI
-- Game: 2903160

-- MAIN APPLICATION
addappid(2903160)
-- Game: addappid(2903160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903161, 1, "6c3d015357b1037838a051aa9686cd45df27b8d754feda56fe9f6775b3fb3d4c")
