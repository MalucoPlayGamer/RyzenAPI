-- Lua provided by RyzenAPI
-- Game: 2161470

-- MAIN APPLICATION
addappid(2161470)
-- Game: addappid(2161470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161471, 1, "54c4954e0fa515b1d42f2ed52136f32848b0273189cb2751cf67fbb1928d1b8c")
