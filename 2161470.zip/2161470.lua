-- Lua provided by SkyAPI 
-- Game: AppID 2161470
addappid(2161470)
addappid(2161471, 1, "54c4954e0fa515b1d42f2ed52136f32848b0273189cb2751cf67fbb1928d1b8c")
