-- Lua provided by RyzenAPI
-- Game: addappid(4261980) 

-- MAIN APP DEPOTS / PACKAGES
addappid(4261982, 1, "e0effba89bed9fd9e71b66eaa80e87a9a23850fdc47d36df355d72a023d4453e") -- Depot 4261982
