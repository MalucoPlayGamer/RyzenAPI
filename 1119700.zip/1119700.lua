-- Lua provided by RyzenAPI
-- Game: As Far As The Eye

-- MAIN APPLICATION
addappid(1119700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119701, 1, "2bc5bfb9449150f2b5a57bc5eda980b0d5899247d1ace46eff1b18e626af6eac")
addappid(1119702, 1, "e5b4dd25310dc4bd409063375a597b40b7b44e097246e10d0e17b8abb62022d9")
addappid(1119703, 1, "b77dcbabe9a3e7116ac8a45fd67d7da89d2d5e6eb8f00eb0420722228a3f16e6")
addappid(1359670, 0, "d1a99458d33b55da7205e7ac1ebfd2413f150fccc2e39967c50e879e7f07f583")

