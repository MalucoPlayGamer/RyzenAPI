-- Lua provided by RyzenAPI
-- Game: Moccasin

-- MAIN APPLICATION
addappid(593290)

-- MAIN APP DEPOTS / PACKAGES
addappid(593291, 1, "439f7e09434fd00edbd06e35c2c0e0d7583328f8e506485f6278eb3c51a7d128")
