-- Lua provided by RyzenAPI
-- Game: BEAMS

-- MAIN APPLICATION
addappid(2710420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710421, 1, "fa13904b76319626e8c3861de721cec7347157b033a57dd71cda7a49a6abc2a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
