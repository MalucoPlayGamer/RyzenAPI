-- Lua provided by RyzenAPI
-- Game: Game: BEAMS

-- MAIN APPLICATION
addappid(2710420)
-- Game: addappid(2710420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710421, 1, "fa13904b76319626e8c3861de721cec7347157b033a57dd71cda7a49a6abc2a6")
