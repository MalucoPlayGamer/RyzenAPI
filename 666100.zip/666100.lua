-- Lua provided by RyzenAPI
-- Game: Shooty Fruity

-- MAIN APPLICATION
addappid(666100)

-- MAIN APP DEPOTS / PACKAGES
addappid(666101, 1, "1317bce7881c9b09ed9483a363ed21cbeb12789d45564e45d69f532e54524cd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(748350)
