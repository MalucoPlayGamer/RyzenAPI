-- Lua provided by RyzenAPI 
-- Game: Shooty Fruity
addappid(666100)
addappid(666101, 1, "1317bce7881c9b09ed9483a363ed21cbeb12789d45564e45d69f532e54524cd3")
