-- Lua provided by RyzenAPI
-- Game: 1501110

-- MAIN APPLICATION
addappid(1501110)
-- Game: addappid(1501110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501111, 1, "824c9fd72c8b91d42518300fe94b53a01697c2cbbca58ced6d44171900cc950b")
