-- Lua provided by RyzenAPI
-- Game: Slay Together: Fantasy MMORPG

-- MAIN APPLICATION
addappid(228990)
addappid(892510)
addappid(1033920)

-- MAIN APP DEPOTS / PACKAGES
addappid(892512,0,"c3a4573e7cc93fa1c91946534ad9496c1b293a52f3fd79e14ebcdd62a88a6329")
