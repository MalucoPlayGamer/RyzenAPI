-- Lua provided by RyzenAPI
-- Game: Slippingcers

-- MAIN APPLICATION
addappid(853490)

-- MAIN APP DEPOTS / PACKAGES
addappid(853491, 1, "345af4a6f82cf9121fca325ad619cbddcfbd1fc6748b0774bff04f5c272c40f9")

