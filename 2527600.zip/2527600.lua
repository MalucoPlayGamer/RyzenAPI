-- Lua provided by RyzenAPI
-- Game: The Detective Reaper Invites

-- MAIN APPLICATION
addappid(2527600)
-- Game: addappid(2527600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527601, 1, "bab73ddd85e1779bfd4bb4587794ebd969217391d2c8b9be53d7954ff32a9955")
