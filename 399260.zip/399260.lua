-- Lua provided by RyzenAPI
-- Game: addappid(399260)

-- MAIN APPLICATION
addappid(399260)

-- MAIN APP DEPOTS / PACKAGES
addappid(399261, 1, "d19a76f0d4311838616af9529f86a0ef0264984ff4df13d6ca3cfb288481b0a6")
