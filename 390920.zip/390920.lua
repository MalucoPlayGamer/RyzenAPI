-- Lua provided by RyzenAPI
-- Game: Game: Army of Pixels

-- MAIN APPLICATION
addappid(390920)
-- Game: addappid(390920)

-- MAIN APP DEPOTS / PACKAGES
addappid(390921, 1, "541e48a469c2f2048d9e66469754ac7dcb6ec94227892f294a901d5089367178")
