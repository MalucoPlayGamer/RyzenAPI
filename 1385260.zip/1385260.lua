-- Lua provided by RyzenAPI
-- Game: If It Please the Court

-- MAIN APPLICATION
addappid(1385260)
-- Game: addappid(1385260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385261, 1, "a6c09b7b72e470211b90da5760f2100932df094cf111982cfe581168bb44b312")
