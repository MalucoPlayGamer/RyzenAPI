-- Lua provided by RyzenAPI
-- Game: Undead Tide: Light's Defense

-- MAIN APPLICATION
addappid(4508060)

-- MAIN APP DEPOTS / PACKAGES
addappid(4508061,0,"ab0a1e2bd0ed040b88ac4a60f7d33ea2b524c808bb6fe51081a1909baf34b789")

