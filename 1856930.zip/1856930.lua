-- Lua provided by RyzenAPI
-- Game: Wayward Harbor

-- MAIN APPLICATION
addappid(1856930)
-- Game: addappid(1856930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856931, 1, "523e3649e8743b984ec899b23cbe38e339ededae5a0211f8a457d6a07ebacfba")
