-- Lua provided by RyzenAPI
-- Game: Medusa VR

-- MAIN APPLICATION
addappid(2378970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378971, 1, "b0069dcff73c788ee515befb3f10efb86807672435677f5d4e723aa5f871b10b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
