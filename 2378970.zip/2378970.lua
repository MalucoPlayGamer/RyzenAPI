-- Lua provided by SkyAPI 
-- Game: Medusa VR
addappid(2378970)
addappid(2378971, 1, "b0069dcff73c788ee515befb3f10efb86807672435677f5d4e723aa5f871b10b")
