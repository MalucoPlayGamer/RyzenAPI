-- Lua provided by RyzenAPI 
-- Game: Ages of Conflict: World War Simulator
addappid(2186320)
addappid(2186321, 1, "c3f143d2587cb629ea479074604fa279ddbf9b1b654bbacdf26111978762fd8d")
addappid(2186322, 1, "c6740902498c6b982ae6f5e0d1ef0e68dbcb5c065b607bf43faf1afd65c224b3")
addappid(2186323, 1, "d798409011943ef8e4fb463c19c3a47d12b6a2dc8cc69633f37ecf930d11640e")
