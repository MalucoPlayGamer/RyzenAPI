-- Lua provided by RyzenAPI
-- Game: Symphony of War: The Nephilim Saga

-- MAIN APPLICATION
addappid(1488200)
addappid(1999620)
addappid(2432430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488201, 1, "cb108864285e7a1c1b19d7f44f9eecd18b88b0d304f6f8caa93e55dca7e54588")

