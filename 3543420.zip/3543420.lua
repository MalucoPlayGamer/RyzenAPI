-- Lua provided by RyzenAPI
-- Game: addappid(3543420)

-- MAIN APPLICATION
addappid(3543420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543421, 1, "7e4c11088aa3afd1cb500006b652778df544171b13ad9396e9b81a8c5fd9b95d")
