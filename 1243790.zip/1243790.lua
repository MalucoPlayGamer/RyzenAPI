-- Lua provided by RyzenAPI
-- Game: 1243790

-- MAIN APPLICATION
addappid(1243790)
-- Game: addappid(1243790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243791, 1, "b13ac522edee95666a22dbf57304d400bd6d67716eace56138e940242465bbe1")
