-- Lua provided by RyzenAPI 
-- Game: Heart Star
addappid(1243790)
addappid(1243791, 1, "b13ac522edee95666a22dbf57304d400bd6d67716eace56138e940242465bbe1")
