-- Lua provided by RyzenAPI
-- Game: addappid(1894100)

-- MAIN APPLICATION
addappid(1894100)
addappid(1894101)
addappid(1894102)
addappid(1894103)
addappid(1894104)
addappid(1894105)
addappid(1894106)
addappid(1894108)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894107,0,"837c377fbb65e1dc775bcec92620f862277617fc72590da31b3104b83b558d73")
