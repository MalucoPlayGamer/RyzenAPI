-- Lua provided by RyzenAPI
-- Game: Conquer: Napoleonic Wars

-- MAIN APPLICATION
addappid(2162610)
-- Game: addappid(2162610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162611, 1, "2e8d903d1493506000962aff4df8e9d09a2586fff46c4eeca746bc299c38ffb8")
