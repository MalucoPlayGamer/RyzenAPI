-- Lua provided by RyzenAPI
-- Game: CosPuzzle

-- MAIN APPLICATION
addappid(1022280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022281, 1, "38d4642df294d709c6dd1d40cfebca1eebd4c1b37d7770f7f29c7c7ae5e6ae49")
