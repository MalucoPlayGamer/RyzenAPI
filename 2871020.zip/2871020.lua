-- Lua provided by RyzenAPI
-- Game: addappid(2871020)

-- MAIN APPLICATION
addappid(2871020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871021, 1, "985222929343d388c8a4a6e6cb7e212efb47523c547c2e5980cf80ac11fdafcd")
