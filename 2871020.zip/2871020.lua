-- Lua provided by SkyAPI 
-- Game: AppID 2871020
addappid(2871020)
addappid(2871021, 1, "985222929343d388c8a4a6e6cb7e212efb47523c547c2e5980cf80ac11fdafcd")
