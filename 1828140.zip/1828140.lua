-- Lua provided by RyzenAPI
-- Game: addappid(1828140)

-- MAIN APPLICATION
addappid(1828140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828141, 1, "7098f398c0a560d1cee30e55588c45bdd4bdbf88b46ed438407a3427ba46497f")
