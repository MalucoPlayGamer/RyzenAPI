-- Lua provided by RyzenAPI
-- Game: 末世天醒

-- MAIN APPLICATION
addappid(1828140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828141, 1, "7098f398c0a560d1cee30e55588c45bdd4bdbf88b46ed438407a3427ba46497f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
