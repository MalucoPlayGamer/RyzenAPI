-- Lua provided by RyzenAPI 
-- Game: The Van Game
addappid(2081860)
addappid(2081861, 1, "adb2b9e53b0e4598a3729fcf2beeddb8da02747ebe134070d14b1e32fa7f7671")
