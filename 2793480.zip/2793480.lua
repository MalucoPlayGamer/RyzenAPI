-- Lua provided by RyzenAPI
-- Game: 修真九要

-- MAIN APPLICATION
addappid(2793480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793481, 1, "5a60c1a15e254981b115dfedf723a4722aa074d600a809ab62cf6663d5cc7ac9")
