-- Lua provided by RyzenAPI
-- Game: Game: The Evil Sect

-- MAIN APPLICATION
addappid(2879580)
-- Game: addappid(2879580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879581, 1, "1c2fb7b024e58c4c18e9fc0c996169438e8c08336d9c70aac05523b0b2974134")
