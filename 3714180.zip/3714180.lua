-- Lua provided by RyzenAPI
-- Game: Cropia

-- MAIN APPLICATION
addappid(3714180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714181,0,"026f6906c3eb970c3fd12690008c6cd560f2cc7757a44ba793b01da5875ac6fc")

