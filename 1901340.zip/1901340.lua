-- Lua provided by RyzenAPI
-- Game: Game: AppID 1901340

-- MAIN APPLICATION
addappid(1901340)
-- Game: addappid(1901340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901341, 1, "eefb68d350df3a18025b0af91489d7ab9d3f167f1ee654450ae0ca9a566ef32b")
addappid(1912240, 0, "ee4080dc2dafc43790b5256cb152a03c88893cfb9d89314e600158477b80416a")
