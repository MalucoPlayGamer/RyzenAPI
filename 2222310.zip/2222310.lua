-- Lua provided by RyzenAPI
-- Game: 2222310

-- MAIN APPLICATION
addappid(2222310)
-- Game: addappid(2222310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222311, 1, "6eaf9fb7ffe32a60d5b0dea1beb75a714cab7e5ca8ef6d7b53e61272208b57a5")
