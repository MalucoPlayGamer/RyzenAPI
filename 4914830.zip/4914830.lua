-- Lua provided by RyzenAPI
-- Game: Toy Shop Tidy Up

-- MAIN APPLICATION
addappid(4914830) -- Toy Shop Tidy Up

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4914831, 1, "6b44b57453155927f2b1cf9f56bf7669169a7a88d067d2683873aacbb1b1849f") -- Depot 4914831

