-- Lua provided by RyzenAPI
-- Game: 1231100

-- MAIN APPLICATION
addappid(1231100)
-- Game: addappid(1231100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231101, 1, "582eab938b7dd44d185c7dfe8003abb0a9653d1fec767de9896ed6d0a558b96c")
