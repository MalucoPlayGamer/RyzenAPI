-- Lua provided by RyzenAPI
-- Game: AppID 1594570

-- MAIN APPLICATION
addappid(1594570)
-- Game: addappid(1594570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594571, 1, "5b70e43c150cd4b6bb90c3c8b45a12051b14628b8f6cb50818f1cbc995c1b1f9")
