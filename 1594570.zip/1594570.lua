-- Lua provided by RyzenAPI
-- Game: AppID 1594570

-- MAIN APPLICATION
addappid(1594570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1594571, 1, "5b70e43c150cd4b6bb90c3c8b45a12051b14628b8f6cb50818f1cbc995c1b1f9")

