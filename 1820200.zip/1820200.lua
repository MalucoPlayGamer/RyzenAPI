-- Lua provided by RyzenAPI
-- Game: Panzer Knights - Sherman & Pershing

-- MAIN APPLICATION
addappid(1820200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820201, 1, "975c0f6344b5721a55503a63d1825f018c9838258e11668a88381a84deabb8cf")
