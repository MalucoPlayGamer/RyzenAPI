-- Lua provided by RyzenAPI 
-- Game: NUKITASHI
addappid(2399220)
addappid(2399221, 1, "f18c3a74fed166b18837f108c3965836402874d288ee4cf23ebcd520dae50049")
