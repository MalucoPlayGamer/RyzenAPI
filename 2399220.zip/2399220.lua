-- Lua provided by RyzenAPI
-- Game: addappid(2399220)

-- MAIN APPLICATION
addappid(2399220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399221, 1, "f18c3a74fed166b18837f108c3965836402874d288ee4cf23ebcd520dae50049")
