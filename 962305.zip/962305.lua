-- Lua provided by RyzenAPI
-- Game: addappid(962305)

-- MAIN APPLICATION
addappid(962305)

-- MAIN APP DEPOTS / PACKAGES
addappid(962305,0,"b0e60987c2d0bb79a10dee7b8add758ec6af78b8eed0c3852aad8b1c7bd813bf")
