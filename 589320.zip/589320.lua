-- Lua provided by RyzenAPI
-- Game: AppID 589320

-- MAIN APPLICATION
addappid(589320)

-- MAIN APP DEPOTS / PACKAGES
addappid(589321, 1, "fa647c305f10ec9e86f5f6860d19b18deb350834dba2a38c572806d03ebda760")

