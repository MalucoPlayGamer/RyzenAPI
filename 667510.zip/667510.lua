-- Lua provided by RyzenAPI
-- Game: The Elmian Warrior

-- MAIN APPLICATION
addappid(667510)

-- MAIN APP DEPOTS / PACKAGES
addappid(667511, 1, "3237b48f717ae8e1edfb020e656560bf5cf312116b2aeb9e59997d38bd5e69dd")
