-- Lua provided by RyzenAPI
-- Game: Quadroids

-- MAIN APPLICATION
addappid(2419690)
-- Game: addappid(2419690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419691, 1, "f54ebfd4939590a2d59b14fc35c9c8e0331d53a747ede090b994d61ee8345172")
