-- Lua provided by RyzenAPI
-- Game: The Bad, The Worse & Djanky

-- MAIN APPLICATION
addappid(1174450)
-- Game: addappid(1174450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174451, 1, "58ab87828291f37c656a163324a303f991f1e559db197f676b70a0697cb92b88")
