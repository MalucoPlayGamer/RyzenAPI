-- Lua provided by RyzenAPI 
-- Game: The Bad, The Worse & Djanky
addappid(1174450)
addappid(1174451, 1, "58ab87828291f37c656a163324a303f991f1e559db197f676b70a0697cb92b88")
