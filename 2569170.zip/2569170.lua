-- Lua provided by RyzenAPI
-- Game: Widow in the Endless Labyrinth

-- MAIN APPLICATION
addappid(2569170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569171, 1, "cd5c3b74c8e2190b60abe41eae05d939b71066c3b908b89152b30109f18c0091")
addappid(2612980, 0, "93e39b173a6efd367a5de0055e62abddd1305f423b82fc12989ca2911fae17e4")

