-- Lua provided by RyzenAPI
-- Game: Lewd Puzzle [18+]

-- MAIN APPLICATION
addappid(2421800)
-- Game: addappid(2421800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421801, 1, "df25388e41c75368825113592f09a44302a807706318acfd12890300dc7c25ef")
