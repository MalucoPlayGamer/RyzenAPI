-- Lua provided by RyzenAPI
-- Game: addappid(2415240)

-- MAIN APPLICATION
addappid(2415240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415241, 1, "f7d8d7b0ad0b8fce15a9046ef28733d83235d9de201bd5e4a5c132283547c822")
