-- Lua provided by RyzenAPI
-- Game: addappid(2976800)

-- MAIN APPLICATION
addappid(2976800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976801, 1, "d8d1080a3d767672633408d342c5ca048ad1ec0ad151dfa74489fe89408e350d")
