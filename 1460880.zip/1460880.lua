-- Lua provided by RyzenAPI
-- Game: addappid(1460880)

-- MAIN APPLICATION
addappid(1460880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460880,0,"e43a29fdda9d1826121293d940337ae3f49e51ae93659076ec64e41be7bab4c4")
