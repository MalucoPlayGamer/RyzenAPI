-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1460880)
addappid(1460880,0,"e43a29fdda9d1826121293d940337ae3f49e51ae93659076ec64e41be7bab4c4")
-- setManifestid(1460880,"2603334178467724816")