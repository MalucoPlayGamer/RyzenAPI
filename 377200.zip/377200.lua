-- Lua provided by RyzenAPI
-- Game: Daemon Detective Gaiden

-- MAIN APPLICATION
addappid(377200)

-- MAIN APP DEPOTS / PACKAGES
addappid(377201, 1, "180aa3390e913770ec3401c85437afe018b507fdbcfed3e2c437ae8b0bae832f")
