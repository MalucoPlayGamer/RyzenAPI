-- Lua provided by RyzenAPI
-- Game: addappid(1559660)

-- MAIN APPLICATION
addappid(1559660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559661, 1, "e299d5dd2f10d085acfb36e56f65d2bbbd8c131843c6e9fe3ca198a18c7d0bba")
