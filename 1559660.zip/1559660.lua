-- Lua provided by RyzenAPI 
-- Game: Trap Arena
addappid(1559660)
addappid(1559661, 1, "e299d5dd2f10d085acfb36e56f65d2bbbd8c131843c6e9fe3ca198a18c7d0bba")
