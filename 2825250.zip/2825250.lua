-- Lua provided by RyzenAPI
-- Game: 3秒ばなな

-- MAIN APPLICATION
addappid(2825250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825251, 1, "2e73c467c3c15f58e5450030ce439bd7946d6067081cd96de78d2d63b6c8a04f")

