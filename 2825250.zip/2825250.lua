-- Lua provided by SkyAPI 
-- Game: 3秒ばなな
addappid(2825250)
addappid(2825251, 1, "2e73c467c3c15f58e5450030ce439bd7946d6067081cd96de78d2d63b6c8a04f")
