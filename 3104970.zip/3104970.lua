-- Lua provided by RyzenAPI
-- Game: Backyard Baseball '01

-- MAIN APPLICATION
addappid(3104970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104971, 1, "756d390df697e201eab2f90d0f9ed46dd7f9cbde188e0be0eb31f3b437639e7a")
