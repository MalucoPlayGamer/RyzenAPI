-- Lua provided by RyzenAPI
-- Game: Backyard Baseball '01

-- MAIN APPLICATION
addappid(3104970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3104971, 1, "756d390df697e201eab2f90d0f9ed46dd7f9cbde188e0be0eb31f3b437639e7a")

