-- Lua provided by RyzenAPI
-- Game: AppID 974470

-- MAIN APPLICATION
addappid(974470)
-- Game: addappid(974470)

-- MAIN APP DEPOTS / PACKAGES
addappid(974471, 1, "88636ab34566c6eea4f9fed87bb8b0b95275a5528b6be838b98a2189ca4df06e")
