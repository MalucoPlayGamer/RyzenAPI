-- Lua provided by RyzenAPI
-- Game: 2461170

-- MAIN APPLICATION
addappid(2461170)
-- Game: addappid(2461170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461170,0,"97bf7665a2688bc03c94feeb63cc7f69a498e59f853b7c860779f814ae4db942")
