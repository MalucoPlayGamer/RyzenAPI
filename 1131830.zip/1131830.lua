-- Lua provided by RyzenAPI
-- Game: Game: AppID 1131830

-- MAIN APPLICATION
addappid(1131830)
-- Game: addappid(1131830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131831, 1, "b83c736b864f65f5095a86500ec025b31bb0299577bd682608a0b8fc219bf5aa")
