-- Lua provided by RyzenAPI
-- Game: Succubus Farm

-- MAIN APPLICATION
addappid(1455220)
-- Game: addappid(1455220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455221, 1, "e144c8d739dc9ae6388f3cfc7ff576d1e4c9e931814b835d60e0dae4dcd3f524")
addappid(1455222, 1, "077466bf4c9bcd3901d4074a501c5420fe6734dd1d9c6c53882ae67839cac7cd")
addappid(1455223, 1, "fc29c03db3a2f0345435498ea5d8ace6462a4f975591739ea2831976e27616a0")
