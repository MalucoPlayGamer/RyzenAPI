-- Lua provided by RyzenAPI
-- Game: 1629480

-- MAIN APPLICATION
addappid(1629480)
-- Game: addappid(1629480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629481, 1, "ef3d8cabe1cc647e3bb89c34c503cc9288ae681e810e484391696ad2ca8d119a")
