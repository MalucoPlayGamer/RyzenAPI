-- Lua provided by RyzenAPI
-- Game: addappid(2176460)

-- MAIN APPLICATION
addappid(2176460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176461, 1, "ceb60d6af3d9914bdedb4de73b94c4937e242a6021837ad9631e933af75df574")
