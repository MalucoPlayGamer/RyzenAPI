-- Lua provided by RyzenAPI
-- Game: Winning Love by Daylight [Ep 1+2]

-- MAIN APPLICATION
addappid(1799180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799181, 1, "fd07da54ee0765909df5526b2228b99628b4ed57e6899ce04337dc27ff623800")
