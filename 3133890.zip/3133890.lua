-- Lua provided by RyzenAPI
-- Game: Game: Mind Her Manor Demo

-- MAIN APPLICATION
addappid(3133890)
-- Game: addappid(3133890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133891, 1, "3345807d63d381ab7749f0ed9ecf9c409f8770c5af634c4e8835f7cfa7d80aa4")
