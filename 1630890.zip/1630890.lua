-- Lua provided by RyzenAPI 
-- Game: Rift Adventure
addappid(1630890)
addappid(1630891, 1, "389568249129fc7334c4aa9317fb767fa96a527ad6716eb62e00b1d82733f6b3")
