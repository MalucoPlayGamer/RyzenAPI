-- Lua provided by RyzenAPI
-- Game: Rift Adventure

-- MAIN APPLICATION
addappid(1630890)
-- Game: addappid(1630890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630891, 1, "389568249129fc7334c4aa9317fb767fa96a527ad6716eb62e00b1d82733f6b3")
