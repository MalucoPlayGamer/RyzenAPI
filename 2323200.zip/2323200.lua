-- Lua provided by RyzenAPI
-- Game: AppID 2323200

-- MAIN APPLICATION
addappid(2323200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323201, 1, "e1564da70e976dbc8a04814a64a271c3cc239ff0accc09e9d99e4d1a7e5ce414")
addappid(2323202, 1, "ad47d6d5826241d104c3d6c3e08c3f5f056251e9ef8fa749ad7d71cbc5d409ae")
addappid(2323203, 1, "a167b581ec3d432844319d8629d7d85fec2948a306d7e8e6245d203aeadb7417")
addappid(2323204, 1, "77ac3cbe77abda723416c278e373a229033d2f56741ab4d7f0e1908d0003881c")
addappid(2337210, 0, "aacb5bdb2c830ecfaeac020dcc7c6effd1945086a9441c1f365ce745222e74b0")
addappid(2337211, 0, "30f56f18f5395cfcffc3342fe8bb9c9562de729dea3b3e89a0dc7f9c7f62cf6b")
addappid(2337212, 0, "1f1725672e521e00c2bae64a8250d86f7d89dff0070380a506fcf0b193fced82")
addappid(2337213, 0, "6bab93b40b5f575c0ced193dda5cc41a7ab9dcc2355000aafccffe1d47b0586f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
