-- Lua provided by RyzenAPI
-- Game: Game: AppID 2779430

-- MAIN APPLICATION
addappid(2779430)
-- Game: addappid(2779430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779431, 1, "44ff240c8e40c30c8ad783a4c20a31fbbc2459999b74f786751226561775af35")
