-- Lua provided by RyzenAPI
-- Game: Daycare Descent

-- MAIN APPLICATION
addappid(2429260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429261, 1, "7dd88a26a66f4318801f1e546316ad9a1850c2948565b1baa473b9d6a40c62ea")
