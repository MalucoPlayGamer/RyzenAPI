-- Lua provided by RyzenAPI
-- Game: addappid(1831980)

-- MAIN APPLICATION
addappid(1831980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831981, 1, "2bbcbfb9158d8bbf8ab52734570d4c4321b35e4ca39151f8d60ba95f7e6ba449")
