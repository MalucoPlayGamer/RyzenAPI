-- Lua provided by RyzenAPI
-- Game: Game: Orwell: Keeping an Eye On You

-- MAIN APPLICATION
addappid(491950)
-- Game: addappid(491950)

-- MAIN APP DEPOTS / PACKAGES
addappid(491951, 1, "1f4ab188d37923aebe9f69765dddc56457cea51d81c4800676217680819900a3")
addappid(491952, 1, "3bd3e4d55278317a2e43905a165d9de014c0ce02ef6c0b463e1c834e7fc30673")
addappid(491953, 1, "7d3317a7e9583f049f2f4859acb565494534bc06bca4e206330dfe428d2a9de5")
