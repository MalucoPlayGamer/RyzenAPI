-- Lua provided by RyzenAPI
-- Game: Panama Canal Clash

-- MAIN APPLICATION
addappid(2106040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106042,0,"4dcee5fa83b98e55fc82572c3650d5525dfd93ab232a7e70a452cd0508e2755d")

