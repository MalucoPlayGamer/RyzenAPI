-- Lua provided by RyzenAPI
-- Game: addappid(1070910)

-- MAIN APPLICATION
addappid(1070910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070911, 1, "037dc7b70b3b2638becaae26914d75dbc674242a7f4988e2730bae47413e5ed9")
