-- Lua provided by RyzenAPI
-- Game: Rival Stars Horse Racing: VR Edition

-- MAIN APPLICATION
addappid(2937440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937441, 1, "20c894dfba60cfd7bb335b46b4a5a1de4ddd0e70f3ac9bc738505105d5bf49bd")
