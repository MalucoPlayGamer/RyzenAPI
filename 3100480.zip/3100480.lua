-- Lua provided by RyzenAPI
-- Game: addappid(3100480)

-- MAIN APPLICATION
addappid(3100480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100481, 1, "03c944587c8542dc7adce98f2b779e99b93f3713b5c9ccd4faa11b4d76a7e1d8")
