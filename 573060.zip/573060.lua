-- Lua provided by RyzenAPI
-- Game: AppID 573060

-- MAIN APPLICATION
addappid(573060)

-- MAIN APP DEPOTS / PACKAGES
addappid(573061, 1, "e8acf40447a7fb106e9ee5f59f28688d15cd5b1bb22fe511fa01c202b580f7cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(621560)
addappid(635750)
addappid(635751)
addappid(635761)
addappid(635762)
addappid(638810)
addappid(661890)
addappid(662010)
