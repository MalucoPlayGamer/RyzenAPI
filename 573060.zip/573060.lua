-- Lua provided by RyzenAPI
-- Game: Game: AppID 573060

-- MAIN APPLICATION
addappid(573060)
-- Game: addappid(573060)

-- MAIN APP DEPOTS / PACKAGES
addappid(573061, 1, "e8acf40447a7fb106e9ee5f59f28688d15cd5b1bb22fe511fa01c202b580f7cb")
