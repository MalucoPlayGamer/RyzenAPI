-- Lua provided by SkyAPI 
-- Game: Test of Fear | 肝試しの夜に
addappid(3718080)
addappid(3718081, 1, "b27e7d37ddfffc8894a3d0d1f1c324519b000d032888da9f4e38cd770365369e")
