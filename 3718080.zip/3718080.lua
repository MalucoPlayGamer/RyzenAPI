-- Lua provided by RyzenAPI
-- Game: Test of Fear | 肝試しの夜に

-- MAIN APPLICATION
addappid(3718080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3718081, 1, "b27e7d37ddfffc8894a3d0d1f1c324519b000d032888da9f4e38cd770365369e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
