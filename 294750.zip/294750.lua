-- Lua provided by RyzenAPI
-- Game: AppID 294750

-- MAIN APPLICATION
addappid(294750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294751, 1, "f8aa3f3b59ee10898309da3229cabefdbe671b8e03d08f071bc5760383f6bbc7")
addappid(294752, 1, "d4a90217969673c248c3f1aef8ca2d0ab5c30e222a001ec32d36aa8a52053a8e")
addappid(294753, 1, "a1096a5b529ef36b1915cc2f8c62bbecb8862cd99e4f1b55db5f5fed59615b0b")
addappid(294754, 1, "1637130914a3b190fbd25cad1f1c8359d269f3904f673cb3f5a2081d75f9ca94")

