-- Lua provided by SkyAPI 
-- Game: AppID 1259870
addappid(1259870)
addappid(1259871, 1, "141991cf36ff19ee48940f94f97bf98eb35457d32d0e1109f63604c080ea1d2e")
