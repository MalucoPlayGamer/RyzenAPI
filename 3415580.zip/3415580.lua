-- Lua provided by RyzenAPI
-- Game: Death Ring: Second Impact

-- MAIN APPLICATION
addappid(3415580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415581, 1, "e5ce809817aa13012ec22793cafe8d2d4b1d1fb7306e8a4b0c32e4e8dde66b89")
