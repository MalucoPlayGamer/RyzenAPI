-- Lua provided by RyzenAPI
-- Game: Bogos Binted?

-- MAIN APPLICATION
addappid(3588490)
addappid(4365770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588491,0,"3c3f550a80f99598128bf46b669e3322b7e035b2670e33b808f331478c4102be")

