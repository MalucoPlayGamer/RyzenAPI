-- Lua provided by RyzenAPI
-- Game: Bogos Binted?

-- MAIN APPLICATION
addappid(3588490)
addappid(4365770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588491,0,"3c3f550a80f99598128bf46b669e3322b7e035b2670e33b808f331478c4102be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
