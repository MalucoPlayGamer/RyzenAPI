-- Lua provided by RyzenAPI
-- Game: Orbit - Playing with Gravity

-- MAIN APPLICATION
addappid(552120)

-- MAIN APP DEPOTS / PACKAGES
addappid(552121,0,"edecf4a373a101fbe3940197e6977eb0419ae273a9d3906c92fa01487cb99970")

