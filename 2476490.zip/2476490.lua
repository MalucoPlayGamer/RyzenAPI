-- Lua provided by RyzenAPI
-- Game: Isekai Rondo

-- MAIN APPLICATION
addappid(2476490) -- Isekai Rondo
addappid(2483610) -- Experience x3 - Isekai Rondo
addappid(2483611) -- Damage x2 - Isekai Rondo
addappid(2483612) -- No Skill Cost - Isekai Rondo

-- MAIN APP DEPOTS / PACKAGES
addappid(2476491, 1, "5deba1f6179a303b6779809bdbd54aa74622a666cf78e1e8eda9b3e0d5dfca74") -- Depot 2476491
