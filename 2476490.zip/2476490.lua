-- Lua provided by RyzenAPI
-- Game: 2476490

-- MAIN APPLICATION
addappid(2476490)
-- Game: addappid(2476490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476491, 1, "5deba1f6179a303b6779809bdbd54aa74622a666cf78e1e8eda9b3e0d5dfca74")
