-- Lua provided by RyzenAPI
-- Game: Hentai BodySuit

-- MAIN APPLICATION
addappid(2184610)
-- Game: addappid(2184610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184611, 1, "94a7801a240b41a96e247b24143f45773e121f6d8c30824d7c73b98c319c1b8f")
