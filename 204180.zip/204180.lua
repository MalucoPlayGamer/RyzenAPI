-- Lua provided by RyzenAPI
-- Game: Game: Waveform

-- MAIN APPLICATION
addappid(204180)
-- Game: addappid(204180)

-- MAIN APP DEPOTS / PACKAGES
addappid(204181, 1, "2b3ac0972e3233276f39482f50b0cbf069c29584d9eae267792489bfcbd8fea7")
addappid(204183, 1, "e90cb50e68c88bf9e46f0baf5fb2c71501693af06dc6c30dfa12f0a6845e525c")
addappid(204184, 1, "eedded2b6031f23b9611d8564fd4ee1c71456c57babedb63e8b83d3790f24439")
addappid(204186, 1, "2fc2657c585c9bdd494fb8b8970d8a27f738091d6595485839210ebcbb6c1032")
