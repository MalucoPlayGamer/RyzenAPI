-- Lua provided by RyzenAPI
-- Game: 1932070

-- MAIN APPLICATION
addappid(1932070)
-- Game: addappid(1932070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932077,0,"bd1cbe0c31bdd83158661ac828b5937d94ba5870dc28c0b323686bfdb6eb044b")
