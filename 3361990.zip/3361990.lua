-- Lua provided by RyzenAPI
-- Game: Broken Sword - Shadow of the Templars (1996)

-- MAIN APPLICATION
addappid(3361990)
-- Game: addappid(3361990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361990,0,"635dd28ae84033c5f23b8c4ad49a416916650d2e2df2539903d392c1434f6c54")
addappid(3361995,0,"a64af92ba09c486f3be1a810329f35240a2db0ae8c996ebabd666ef8e32487d7")
