-- Lua provided by RyzenAPI
-- Game: addappid(23130)

-- MAIN APPLICATION
addappid(23130)

-- MAIN APP DEPOTS / PACKAGES
addappid(23133,0,"7734b09278f72cce1898a3c0436a4e1cc5efff0c920a12ffd6f48554a8e31eb0")
