-- Lua provided by RyzenAPI
-- Game: Blade Fury

-- MAIN APPLICATION
addappid(2371410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371411, 1, "d6501512625eb02044aa5830725307d879dd15fb2d1d7ed267a14055e1bde465")

