-- Lua provided by RyzenAPI
-- Game: VR Harem Sex ~Fucking the All Girls Around Me~

-- MAIN APPLICATION
addappid(2701390)
addappid(2910870)
addappid(2910880)
addappid(2910890)
addappid(2910910)
addappid(2910920)
addappid(3272840)
addappid(3620090)
addappid(3620100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701391, 1, "f681ba15ee399d8336bd556fb44f7aa9494bb088d1067b77d3a7f8c4de92d745")

