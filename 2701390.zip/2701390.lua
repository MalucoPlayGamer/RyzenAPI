-- Lua provided by RyzenAPI
-- Game: addappid(2701390)

-- MAIN APPLICATION
addappid(2701390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701391, 1, "f681ba15ee399d8336bd556fb44f7aa9494bb088d1067b77d3a7f8c4de92d745")
