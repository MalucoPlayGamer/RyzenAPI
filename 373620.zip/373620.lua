-- Lua provided by RyzenAPI
-- Game: 373620

-- MAIN APPLICATION
addappid(373620)
-- Game: addappid(373620)

-- MAIN APP DEPOTS / PACKAGES
addappid(373621, 1, "257af0cc6c5d9e79017ba4a66f4b43e92fae080e29fd137d89db07edd74d14f1")
