-- Lua provided by RyzenAPI
-- Game: Game: Automation - Original Soundtrack

-- MAIN APPLICATION
addappid(1238660)
-- Game: addappid(1238660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238661, 1, "9ca572c453a843fe845bdca42393bc6d65d9e6e8298f9703984b07c92a5b043a")
