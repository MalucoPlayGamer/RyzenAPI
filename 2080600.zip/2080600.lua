-- Lua provided by RyzenAPI
-- Game: addappid(2080600)

-- MAIN APPLICATION
addappid(2080600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080601, 1, "0ca1dbcfaac0a490b428e61d5c2bcf721f188a54ed54047b6dc3f9e5ac0e36f9")
