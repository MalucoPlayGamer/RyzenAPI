-- Lua provided by RyzenAPI
-- Game: addappid(854110)

-- MAIN APPLICATION
addappid(854110)

-- MAIN APP DEPOTS / PACKAGES
addappid(854111, 1, "36f93afd9c5d8f2f52a13b5aac02312586c6ee8f6c22bb20d75a1ee19896e358")
