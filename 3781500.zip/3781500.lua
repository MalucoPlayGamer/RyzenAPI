-- Lua provided by RyzenAPI
-- Game: La Galerie des Toilettes

-- MAIN APPLICATION
addappid(3781500)
-- Game: addappid(3781500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781501, 1, "beb5f4c2a98b4204ffd767a200c919a67b7f206ea402ee520c707b1d095cc8f1")
