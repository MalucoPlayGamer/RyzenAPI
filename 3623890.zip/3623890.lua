-- Lua provided by RyzenAPI
-- Game: 3623890

-- MAIN APPLICATION
addappid(3623890)
-- Game: addappid(3623890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623891, 1, "388bd8e06660dfbe5b7b3eeade2b715c42c333e387dbbdc9133712135a9acc45")
