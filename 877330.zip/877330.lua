-- Lua provided by RyzenAPI
-- Game: addappid(877330)

-- MAIN APPLICATION
addappid(877330)
addappid(1338270)

-- MAIN APP DEPOTS / PACKAGES
addappid(877331, 1, "ac3dacb15e28cb75e1e408d42f164c4bf1f9060d034d49e7d3848a958ee68ac8")
