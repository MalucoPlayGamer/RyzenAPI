-- Lua provided by RyzenAPI
-- Game: Mushroom Card RPG

-- MAIN APPLICATION
addappid(2122550)
-- Game: addappid(2122550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122551, 1, "438e6e2208cc250b2254e017bf88640460f8a261d855dc9dc0e64e5491574769")
