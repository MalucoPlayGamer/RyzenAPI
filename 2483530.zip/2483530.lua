-- Lua provided by RyzenAPI
-- Game: AppID 2483530

-- MAIN APPLICATION
addappid(2483530)
-- Game: addappid(2483530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483531, 1, "b4e9eb928bc5028fc512260a82c8ab49a118bf720defe15c3bb5ae251887d323")
