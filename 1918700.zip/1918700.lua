-- Lua provided by RyzenAPI
-- Game: Artistic Girl 1

-- MAIN APPLICATION
addappid(1918700)
-- Game: addappid(1918700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918701, 1, "86c42761024c44108716627fc307f65b63f09381aaebf38069536f641b771aaa")
