-- 4128760's Lua and Manifest Created by Hubcap Manifest
-- Dwarven Forge
-- Created: August 14, 2026 at 06:09:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4128760, 1, "39a5d8be5c89442513174d803c56168209cfe844835fb275ebd69860454f2456") -- Dwarven Forge
-- MAIN APP DEPOTS
addappid(4128761, 1, "08c79b964656fdf852d0fcc07b911a9ea80379d1674794e6516447f945f7304c") -- Depot 4128761
setManifestid(4128761, "5939412716259585159", 151131112)