-- Lua provided by RyzenAPI
-- Game: Out of the Park Baseball 25

-- MAIN APPLICATION
addappid(2384620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384621, 1, "178abf9842b79b49c41f4600c85eaa21740cdf636176517056b999d00c0d37de")
addappid(2384624, 1, "013d02f16d083ce56ca7b263619958fb8460991c8b521935276c56874a23b3de")
addappid(2384625, 1, "681863b7028c9d343bada14c6176fadc84ae8a3fd766a72265b50bb438e189ab")
addappid(2384626, 1, "ac968160a5db7d7daf554c3e7ab251b7cf2ed8b91380aed32de3885d7084bf68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
