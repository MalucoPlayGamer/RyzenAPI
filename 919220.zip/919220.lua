-- Lua provided by RyzenAPI
-- Game: Destiny or Fate

-- MAIN APPLICATION
addappid(919220)
-- Game: addappid(919220)

-- MAIN APP DEPOTS / PACKAGES
addappid(919221, 1, "edc97b9dd493f06d54b362c548b5f1719992c2d3ba471c21d4c443b647349962")
addappid(919222, 1, "76d2eced82289088caef36057b2685485e3ce802564ac69ea2f24c1aa4bc03ff")
addappid(919223, 1, "6a5562fc666aa4314c570a0c8a70b72fa181c6a16d1027e455a96385b0407d70")
