-- Lua provided by RyzenAPI
-- Game: Game: AppID 1445670

-- MAIN APPLICATION
addappid(1445670)
-- Game: addappid(1445670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445671, 1, "e8cebd4b0220e5748ab1a53437dcc650da40468b586daf91d1b81c43d97dd2c7")
