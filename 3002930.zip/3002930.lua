-- Lua provided by RyzenAPI
-- Game: 心动满屋

-- MAIN APPLICATION
addappid(3002930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002931, 1, "681c6023c9a396ad42fde6c2c0b2de9cd8bcdec5fa734fd98a56049de288d84d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
