-- Lua provided by RyzenAPI
-- Game: Game: 心动满屋

-- MAIN APPLICATION
addappid(3002930)
-- Game: addappid(3002930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002931, 1, "681c6023c9a396ad42fde6c2c0b2de9cd8bcdec5fa734fd98a56049de288d84d")
