-- Lua provided by RyzenAPI
-- Game: Game: Love Menu

-- MAIN APPLICATION
addappid(2262370)
-- Game: addappid(2262370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262371, 1, "7769ac147df02f5f646fa15fea4de5bb3702dea65b125c51ac53f07e8d17ced8")
