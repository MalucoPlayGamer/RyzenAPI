-- Lua provided by RyzenAPI
-- Game: Retro Arcade Shop Simulator

-- MAIN APPLICATION
addappid(4010900) -- Retro Arcade Shop Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4010901, 1, "65e710dcf56bf498b324840cadac9010c9692cdcea31e6c7fe5ac7dc9aa11618") -- Depot 4010901
