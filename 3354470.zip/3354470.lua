-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "Blackened"

-- MAIN APPLICATION
addappid(3354470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354470,0,"312cb5a2dd8a91b7394a9646291bfd93d77815834d0f578b6f5be33df6c3e0ad")
