-- Lua provided by RyzenAPI
-- Game: Voltage

-- MAIN APPLICATION
addappid(798710)

-- MAIN APP DEPOTS / PACKAGES
addappid(798711, 1, "8d609108d5bcbe97a53967c1e1da3c83aa8ddd3632317cd78ae06cd872a5fea9")

