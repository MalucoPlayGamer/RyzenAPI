-- Lua provided by RyzenAPI
-- Game: Voltage

-- MAIN APPLICATION
addappid(798710)
addappid(869230)
addappid(1004480)
addappid(1105030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(798711, 1, "8d609108d5bcbe97a53967c1e1da3c83aa8ddd3632317cd78ae06cd872a5fea9")

