-- Lua provided by RyzenAPI
-- Game: Fallen Young Wife~Netorare H without telling her husband~

-- MAIN APPLICATION
addappid(2717310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717311, 1, "bbc3b77d41e72f8e14be5a3fa08c3236e81740527aa35ca68f80020b330a9294")
addappid(2717312, 1, "06122fc99fe897e20197dd5d1a19fcc97f77fc741b0e3fcd7e16bea3d713c1e2")
addappid(2717313, 1, "f5219a905ec1171edb4d39b6416134c9a06b0b7936347e2f1f3c0a5da5c20918")
addappid(2717314, 1, "714047a9078baa2464e3de4732d971321579d00c49b0bce110ee12d6b9ea861c")
