-- Lua provided by RyzenAPI
-- Game: addappid(1607340)

-- MAIN APPLICATION
addappid(1607340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607341, 1, "b90c56095babf2deb9d24da49467155a33c83396ca7e5797cc50395f3b78578f")
