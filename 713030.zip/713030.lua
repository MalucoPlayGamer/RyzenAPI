-- Lua provided by RyzenAPI
-- Game: addappid(713030)

-- MAIN APPLICATION
addappid(713030)

-- MAIN APP DEPOTS / PACKAGES
addappid(713031, 1, "7a90a25469d04075fc9e40d2c4c0f18ec8b1801f472393c3cbcc8303cbcaf4d5")
