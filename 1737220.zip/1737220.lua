-- Lua provided by SkyAPI 
-- Game: Myriads: Renaissance
addappid(1737220)
addappid(1737221, 1, "d04963d9bfe84ca7be103fd68def860613603ac391ea26767d44b1f99cfe40c4")
