-- Lua provided by RyzenAPI
-- Game: Myriads: Renaissance

-- MAIN APPLICATION
addappid(1737220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737221, 1, "d04963d9bfe84ca7be103fd68def860613603ac391ea26767d44b1f99cfe40c4")

