-- Lua provided by RyzenAPI
-- Game: Labrys

-- MAIN APPLICATION
addappid(2330210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330211, 1, "f00e87cef5fb2c8397a579e2aefb5f8ee6a8058b332974ef53aedd446fa41fe7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
