-- Lua provided by RyzenAPI
-- Game: addappid(2330210)

-- MAIN APPLICATION
addappid(2330210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330211, 1, "f00e87cef5fb2c8397a579e2aefb5f8ee6a8058b332974ef53aedd446fa41fe7")
