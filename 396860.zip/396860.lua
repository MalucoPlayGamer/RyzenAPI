-- Lua provided by RyzenAPI
-- Game: addappid(396860)

-- MAIN APPLICATION
addappid(396860)

-- MAIN APP DEPOTS / PACKAGES
addappid(396861, 1, "c89255e14cd2f2160da82478494aed33d9a8a48f8e7dbadf8b76283728c827bb")
addappid(397490, 0, "0bc8f2215944e2c8e79b0963936891f1bcadff96a16dcfb0d1effb55552439e4")
