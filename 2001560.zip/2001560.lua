-- Lua provided by RyzenAPI 
-- Game: AppID 2001560
addappid(2001560)
addappid(2001561, 1, "d18a9b1413b8626831837eafd15fc6503255dddb00bfe373abe762fc34266ab1")
