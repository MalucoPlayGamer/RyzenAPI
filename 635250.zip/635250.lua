-- Lua provided by RyzenAPI
-- Game: addappid(635250)

-- MAIN APPLICATION
addappid(635250)

-- MAIN APP DEPOTS / PACKAGES
addappid(635251, 1, "e87dd2907332eedf19a5e4a99fd897dc3e51f66e6d7e54f08006b3e59aece810")
addappid(708900, 0, "7b721541dedaa0511610fe54f662df773e02a73c63105ae17bb0ed27069bcfcb")
addappid(1216890, 0, "afc3f0541c97106f280ddd3fa8a3298c0a811901b068d2f608ec5c6e66e155e0")
