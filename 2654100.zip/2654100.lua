-- Lua provided by RyzenAPI
-- Game: Decimate Drive Demo

-- MAIN APPLICATION
addappid(2654100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654101, 1, "44fab792ea17c5a9bcbeebd2a9fab3e2816ebde076bd60719520ccec7eb84595")
