-- Lua provided by RyzenAPI
-- Game: 2206830

-- MAIN APPLICATION
addappid(2206830)
-- Game: addappid(2206830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206831, 1, "6d7e718b8ded4722517493fce5b7687920cb01ab598cd1fe370885fae76f457e")
