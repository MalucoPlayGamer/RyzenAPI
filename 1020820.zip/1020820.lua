-- Lua provided by RyzenAPI
-- Game: AppID 1020820

-- MAIN APPLICATION
addappid(1020820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020821, 1, "3c95afa36b2638303c2e9e651a2bb0628ac1f95bf277f9f2481000b738a32a57")
addappid(1020822, 1, "938438e9128ba37ad0d631287d91aaf69482e7cbf3edae6994b52c1bcee6b380")
addappid(1020823, 1, "505fce6ccdcaf4a31659422880e24ac873b7e1dbfed9e9de8f41db7eb5aba44a")
addappid(1020824, 1, "eabe6375956b6d7c4574f220b5460622abff48146d4a37b293ee7df958c9331d")
addappid(1020825, 1, "28ea9942c50256b289352187aaddfc3815858c3a3595a0308f392f55fc770c65")
addappid(1020826, 1, "11fb8b87138b44c4681197fd02d1d40969efaab14fb72015ebe73ba16b61680b")
addappid(1116160, 0, "bfb352e46d9b6945211fd0b5ac2939c93545ad3f1026bdb69ecb4aec03bd121f")
addappid(1123950, 0, "6c8560d792a085c4886cb64c148cb1c4f91e5e9f19c7de9c40c1347fe1a67283")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1069450)
