-- Lua provided by RyzenAPI
-- Game: Game: Epic Chef

-- MAIN APPLICATION
addappid(1312960)
-- Game: addappid(1312960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312961, 1, "e9fba8719ab264d2b6fc738bd203fb7143aca4e84b388e0041b0771cc5f6bca1")
