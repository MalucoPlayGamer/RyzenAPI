-- Lua provided by SkyAPI 
-- Game: AppID 1093750
addappid(1093750)
addappid(1093751, 1, "200f1238d967ef7c41e0b5808ff31e58bd2a55147b04467685dac51a7fd7e46b")
