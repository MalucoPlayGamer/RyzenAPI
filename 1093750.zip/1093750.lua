-- Lua provided by RyzenAPI
-- Game: AppID 1093750

-- MAIN APPLICATION
addappid(1093750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1093751, 1, "200f1238d967ef7c41e0b5808ff31e58bd2a55147b04467685dac51a7fd7e46b")

