-- Lua provided by RyzenAPI
-- Game: 1093750

-- MAIN APPLICATION
addappid(1093750)
-- Game: addappid(1093750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093751, 1, "200f1238d967ef7c41e0b5808ff31e58bd2a55147b04467685dac51a7fd7e46b")
