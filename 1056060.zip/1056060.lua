-- Lua provided by RyzenAPI
-- Game: Eon

-- MAIN APPLICATION
addappid(1056060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056061, 1, "8a266c0815077132bdf4e63de651cd7be2cb1510179b3aa16e04a363275daf2a")
