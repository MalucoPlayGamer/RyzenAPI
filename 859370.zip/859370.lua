-- Lua provided by SkyAPI 
-- Game: in My MIND.
addappid(859370)
addappid(859371, 1, "8178f4908658239af9857fc1cf7bee4835fa156318513c2b4c83597da4a7c95d")
addappid(859372, 1, "18302935df5fcf0e53d68d4751250413979af30c442ca4060e1b65bbf9c2aa01")
