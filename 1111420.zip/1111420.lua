-- Lua provided by RyzenAPI
-- Game: Infinite Skyline Superflight

-- MAIN APPLICATION
addappid(1111420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111421, 1, "0a7875368690f2158594e429fd44953402da788798bc01bf595d52fa1a4c03ab")

