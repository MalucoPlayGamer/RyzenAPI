-- Lua provided by RyzenAPI
-- Game: Flat Trip

-- MAIN APPLICATION
addappid(918740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(918741, 1, "57b1246a15af14fea2c770b2ca3370af1a9baf62be9b7d018dad9ccc23c1c1ca")
addappid(938430, 0, "5f63fc5f84572c96419ea815adbc86d2172c99254262b1d6c5d3d6c276cc2493")

