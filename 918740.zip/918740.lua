-- Lua provided by RyzenAPI
-- Game: 918740

-- MAIN APPLICATION
addappid(918740)
-- Game: addappid(918740)

-- MAIN APP DEPOTS / PACKAGES
addappid(918741, 1, "57b1246a15af14fea2c770b2ca3370af1a9baf62be9b7d018dad9ccc23c1c1ca")
addappid(938430, 0, "5f63fc5f84572c96419ea815adbc86d2172c99254262b1d6c5d3d6c276cc2493")
