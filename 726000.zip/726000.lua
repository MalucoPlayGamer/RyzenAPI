-- Lua provided by RyzenAPI
-- Game: AppID 726000

-- MAIN APPLICATION
addappid(726000)

-- MAIN APP DEPOTS / PACKAGES
addappid(726001, 1, "3bf0157ba38dcf5822c04e5d3f68dd27dadbf3dc3810810b466a61f4303721ca")
