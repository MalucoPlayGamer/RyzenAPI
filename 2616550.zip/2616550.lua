-- Lua provided by RyzenAPI
-- Game: Rescue The Prisoner

-- MAIN APPLICATION
addappid(2616550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616551, 1, "094ba44783eed11c052973049fe77d5a6203a5f25839ce1115b124355d5c7de0")
