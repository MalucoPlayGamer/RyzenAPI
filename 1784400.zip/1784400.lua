-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - 90s Retro Sounds - Story

-- MAIN APPLICATION
addappid(1784400)
-- Game: addappid(1784400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784400,0,"8c1a4c0e909e6a20365dda1f1ca8b617827068f8ea43fdca7582680765181daf")
