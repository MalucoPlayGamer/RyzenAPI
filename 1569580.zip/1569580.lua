-- Lua provided by RyzenAPI
-- Game: Game: Blue Prince

-- MAIN APPLICATION
addappid(1569580)
-- Game: addappid(1569580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569581, 1, "31965c819c33220b429da9fb8d633a2620f3b2b9e5f7ad47380878b719d85861")
