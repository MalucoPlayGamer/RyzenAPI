-- Lua provided by RyzenAPI 
-- Game: Blue Prince
addappid(1569580)
addappid(1569581, 1, "31965c819c33220b429da9fb8d633a2620f3b2b9e5f7ad47380878b719d85861")
