-- Lua provided by RyzenAPI
-- Game: Game: Alchemist: The Potion Monger

-- MAIN APPLICATION
addappid(2094370)
-- Game: addappid(2094370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094371, 1, "32403ac2f7702c8ca7e82f2d959a791cb1d5157fc5bbeb2ccb3e2d1e035f96d5")
