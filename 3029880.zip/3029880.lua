-- Lua provided by RyzenAPI
-- Game: addappid(3029880)

-- MAIN APPLICATION
addappid(3029880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029881, 1, "fdf54637a14e1dee6ae33def3aa7a414f4d9f0c0a0873035ce2a704a9fe8a0a6")
