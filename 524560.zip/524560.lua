-- Lua provided by RyzenAPI
-- Game: 524560

-- MAIN APPLICATION
addappid(524560)
-- Game: addappid(524560)

-- MAIN APP DEPOTS / PACKAGES
addappid(524561, 1, "781495808a13effef516c99f242251461870b4e2a929ff55bc15c55a1703a7d7")
