-- Lua provided by RyzenAPI
-- Game: addappid(1291050)

-- MAIN APPLICATION
addappid(1291050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291051, 1, "7e7adcaf04c01eb4072476da3ed5ef646f204b51b37c3e35e83b180aac5421fe")
