-- Lua provided by RyzenAPI
-- Game: Blend_IT

-- MAIN APPLICATION
addappid(3322380)
-- Game: addappid(3322380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322381, 1, "3dc1ffa53f986ced2e3c0de16512b44aa811f01b3d184f820f8043a0e1f24a16")
