-- Lua provided by RyzenAPI
-- Game: Game: Tower Factory

-- MAIN APPLICATION
addappid(2707490)
-- Game: addappid(2707490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707491, 1, "b436e56de3040764d467377c6c20eb7f879fea5110126e5d11a6ca4562a511d5")
