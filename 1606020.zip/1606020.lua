-- Lua provided by RyzenAPI
-- Game: addappid(1606020)

-- MAIN APPLICATION
addappid(1606020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606021, 1, "97caba819d496fbc382164070b91055c7aa8c37a36fa8c1902c40e8bb6e318d6")
