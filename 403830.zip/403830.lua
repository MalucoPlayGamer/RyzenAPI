-- Lua provided by RyzenAPI 
-- Game: AppID 403830
addappid(403830)
addappid(403831, 1, "9e579fc7284333bacabd1a4af5a116438dd05e7e8c2e95bddc78fd3f647913ab")
