-- Lua provided by RyzenAPI
-- Game: ComicKingdom

-- MAIN APPLICATION
addappid(3423550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423551, 1, "413d2b25270176a26c0db1179cadc4954a7437bc162e2f530b0cdd2de8ba026c")
