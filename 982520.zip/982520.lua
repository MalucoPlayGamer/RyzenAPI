-- Lua provided by RyzenAPI
-- Game: Movavi Photo Editor

-- MAIN APPLICATION
addappid(982520)

-- MAIN APP DEPOTS / PACKAGES
addappid(982521, 1, "c3dc1e1cea19a398b563da33289f16623c242377d42f63ef659328f846304a8a")

