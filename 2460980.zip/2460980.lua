-- Lua provided by RyzenAPI
-- Game: 2460980

-- MAIN APPLICATION
addappid(2460980)
-- Game: addappid(2460980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460981, 1, "93e9eadd6ae198bb5767d62b42c64d79eb52303902573111edde12b4e7a72297")
