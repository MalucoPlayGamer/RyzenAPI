-- Lua provided by RyzenAPI 
-- Game: RETNE
addappid(622380)
addappid(622381, 1, "e28b82f5bfd3158bd3cf80476b5550b605192ac2888c082abe487b858884dc37")
