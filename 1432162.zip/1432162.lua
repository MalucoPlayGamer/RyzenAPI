-- Lua provided by RyzenAPI
-- Game: FUSER™ - Topic with A7S - "Breaking Me"

-- MAIN APPLICATION
addappid(1432162)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432162,0,"42be48a1bfc2f8c156e557ab82898cbb0bbb884bb1b92ceb1e95065850f41e2c")

