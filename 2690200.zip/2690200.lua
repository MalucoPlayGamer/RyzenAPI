-- Lua provided by RyzenAPI
-- Game: Game: LEVEL UP YOUR BODY Demo

-- MAIN APPLICATION
addappid(2690200)
-- Game: addappid(2690200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690201, 1, "bb67949991b5cf437d114dc74a148a55b3a546ad61e9f643d29f39f6709246f9")
