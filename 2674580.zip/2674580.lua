-- Lua provided by RyzenAPI
-- Game: Game: Hitler My Friend

-- MAIN APPLICATION
addappid(2674580)
-- Game: addappid(2674580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674581, 1, "ccc169237303080fa113a8a6498235a54fe813d6988b53fb64ee3690b7bf2f89")
