-- Lua provided by RyzenAPI
-- Game: Midnight Calling: Anabel Collector's Edition

-- MAIN APPLICATION
addappid(614650)

-- MAIN APP DEPOTS / PACKAGES
addappid(614651,0,"460910aeb9587a72b1b8fb347d76e60d52c2d213754034c1eba60ea615f46d73")

