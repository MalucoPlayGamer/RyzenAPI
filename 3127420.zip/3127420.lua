-- Lua provided by RyzenAPI
-- Game: Hooked! Demo

-- MAIN APPLICATION
addappid(3127420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127422,0,"7e6d1316403998c9c9a261bfbf75eddd0f046e7f41a8b3b4de1397502bf653a4")
