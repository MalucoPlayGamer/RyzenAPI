-- Lua provided by RyzenAPI
-- Game: addappid(633320)

-- MAIN APPLICATION
addappid(633320)

-- MAIN APP DEPOTS / PACKAGES
addappid(633321, 1, "208feb295db6221ffd14c6f2f14299b2da6b216efc506e0eae2f74b0555e2438")
