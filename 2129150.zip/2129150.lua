-- Lua provided by RyzenAPI
-- Game: Horror Tale 1: Kidnapper

-- MAIN APPLICATION
addappid(2129150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129151, 1, "bfa855e25116a7e48ed1d6744e15f8bb551c0e5cdde28fcde402ed3fdb4c5785")
