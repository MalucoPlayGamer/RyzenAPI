-- Lua provided by RyzenAPI
-- Game: 1631420

-- MAIN APPLICATION
addappid(1631420)
-- Game: addappid(1631420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631421, 1, "0fbf825a361b698f2b10c9a4a59187c2a84d293f8c99f29dfd2bc6d3f152cd2b")
