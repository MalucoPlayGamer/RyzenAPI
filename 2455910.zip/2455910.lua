-- Lua provided by RyzenAPI
-- Game: MILFs of Sunville - Extra content

-- MAIN APPLICATION
addappid(2455910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455912,0,"59928656e703785e89d2056bfa59fdc28355ae12e227446d1d48f7594c257360")

