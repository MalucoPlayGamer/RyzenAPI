-- Lua provided by RyzenAPI
-- Game: Game: Eyes Over Us

-- MAIN APPLICATION
addappid(1819660)
-- Game: addappid(1819660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819661, 1, "5974d8bbecdf71b3c5c3bd9711f76e208fd1205ec06072acb9269914050aa172")
