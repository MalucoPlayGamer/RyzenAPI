-- Lua provided by RyzenAPI
-- Game: Sands of Aura

-- MAIN APPLICATION
addappid(1119840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1119841, 1, "a17d327a99bda521c972c8d234326e467d80d17e2f321d5378812db0ce59dcbb")
