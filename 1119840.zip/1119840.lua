-- Lua provided by RyzenAPI
-- Game: AppID 1119840

-- MAIN APPLICATION
addappid(1119840)
-- Game: addappid(1119840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119841, 1, "a17d327a99bda521c972c8d234326e467d80d17e2f321d5378812db0ce59dcbb")
