-- Lua provided by RyzenAPI
-- Game: Sebastien Loeb Rally EVO Demo

-- MAIN APPLICATION
addappid(435520)

-- MAIN APP DEPOTS / PACKAGES
addappid(435521, 1, "b714a335e9ec688a0fa29065b677d385b7e22b1d7795438263986a7a23cc6fc4")

