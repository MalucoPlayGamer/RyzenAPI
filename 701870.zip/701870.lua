-- Lua provided by RyzenAPI 
-- Game: Swarm Queen
addappid(701870)
addappid(701871, 1, "f045a4bc017e74fea10eb513f58085693367fb0e0f37214238095a14943a45b6")
