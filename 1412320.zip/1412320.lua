-- Lua provided by RyzenAPI
-- Game: 我的公司996 Demo

-- MAIN APPLICATION
addappid(1412320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412321, 1, "98217faf1030238f5ee478f74b812c4e25dbc27bb1211df87196c6f97fd45255")
