-- Lua provided by RyzenAPI
-- Game: addappid(1901910)

-- MAIN APPLICATION
addappid(1901910)
addappid(2994890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901911, 1, "86db273f69c876d1318163115fcff97672cbed1f40af56f8b17858ec61353e95")
