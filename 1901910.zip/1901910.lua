-- Lua provided by RyzenAPI
-- Game: Ultimate General: American Revolution

-- MAIN APPLICATION
addappid(1901910)
addappid(2994890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901911, 1, "86db273f69c876d1318163115fcff97672cbed1f40af56f8b17858ec61353e95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
