-- Lua provided by RyzenAPI
-- Game: 1212750

-- MAIN APPLICATION
addappid(1212750)
-- Game: addappid(1212750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212751, 1, "f9f2e1afafc72b480542a5fd6ffce86f741da367e042ebdad6639073a01dd8c0")
