-- Lua provided by RyzenAPI
-- Game: AppID 563750

-- MAIN APPLICATION
addappid(563750)

-- MAIN APP DEPOTS / PACKAGES
addappid(563751, 1, "4e12adad28c99dcc018ff64ad701326bbc24b1f16a79a7775b5ef3c6a12501d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
