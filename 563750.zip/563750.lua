-- Lua provided by RyzenAPI
-- Game: addappid(563750)

-- MAIN APPLICATION
addappid(563750)

-- MAIN APP DEPOTS / PACKAGES
addappid(563751, 1, "4e12adad28c99dcc018ff64ad701326bbc24b1f16a79a7775b5ef3c6a12501d7")
