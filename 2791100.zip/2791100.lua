-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2791100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791100,0,"2a3437e1e75880812d6836420d39450fa6a965142dfbf0fe5b1ec7936b5e0f70")

