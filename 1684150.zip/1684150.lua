-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1684150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684150,0,"896f434cab6397085e36b894da023e274e25768d89e9e1e633474a532dc4525c")
