-- Lua provided by RyzenAPI
-- Game: AeroChopper

-- MAIN APPLICATION
addappid(832510)

-- MAIN APP DEPOTS / PACKAGES
addappid(832511, 1, "702f17ebd0e3c09b120caeefa1018f3615cba9d08017e43c94b5a9747418c664")
