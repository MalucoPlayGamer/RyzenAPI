-- Lua provided by RyzenAPI 
-- Game: AppID 1472560
addappid(1472560)
addappid(1472561, 1, "6bef5b77e8fda2a7ee82a253648668dbdeb304d2b57d6c9f5f790febfc8b0b11")
addappid(1472562, 1, "ab88c1a0f08d5f7e531be35e21571389a263b7427179af0c36a5034ff00563e6")
