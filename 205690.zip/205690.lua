-- Lua provided by RyzenAPI
-- Game: addappid(205690)

-- MAIN APPLICATION
addappid(205690)
addappid(228983)

-- MAIN APP DEPOTS / PACKAGES
addappid(205691, 1, "9c29ab4b91acaa64fbcb74fbf4ebe183dd34ff2befff547ddf456b860a434042")
addappid(205692, 1, "491135aa9e2d1de0ab53df0523ccf1b6eed62e81843e43d2b40d918866cabc0d")
