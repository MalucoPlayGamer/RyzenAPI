-- Lua provided by RyzenAPI
-- Game: addappid(672970)

-- MAIN APPLICATION
addappid(672970)

-- MAIN APP DEPOTS / PACKAGES
addappid(672972,0,"92b6fd5b65296cdc817315425caf189b4e94e93456c088e5af87e930f09eda75")
