-- Lua provided by RyzenAPI
-- Game: Confabulation

-- MAIN APPLICATION
addappid(2246400)
-- Game: addappid(2246400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246401, 1, "a0c7f16e2aba38ec14c6e7238e874e8f0df507d87d506199b9d213bb3aa14ffd")
