-- 2404880's Lua and Manifest Created by Hubcap Manifest
-- Car Dealer Simulator
-- Created: July 27, 2026 at 17:21:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2404880) -- Car Dealer Simulator
-- MAIN APP DEPOTS
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f") -- Depot 2404881
setManifestid(2404881, "4855849329422549936", 17739417577)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Car Dealer Simulator - Up 2 You DLC (AppID: 4046960)
addappid(4046960)
addappid(4046960, 1, "11fd991d7512eb7d72d0d55e65c4b6e7a1851e35949cce2081ece003c2fb9e33") -- Car Dealer Simulator - Up 2 You DLC - Depot 4046960
setManifestid(4046960, "4951122096097830826", 974336511)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2404882) -- Depot 2404882 (empty depot)