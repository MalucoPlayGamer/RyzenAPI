-- Lua provided by SkyAPI 
-- Game: Car Dealer Simulator
addappid(2404880)
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f")
addappid(4046960)
