-- Lua provided by RyzenAPI
-- Game: Game: Car Dealer Simulator

-- MAIN APPLICATION
addappid(2404880)
addappid(4046960)
-- Game: addappid(2404880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f")
