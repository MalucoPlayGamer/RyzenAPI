-- Lua provided by RyzenAPI
-- Game: Car Dealer Simulator

-- MAIN APPLICATION
addappid(2404880) -- Car Dealer Simulator
addappid(4046960)
-- addappid(2404882) -- Depot 2404882 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f") -- Depot 2404881
addappid(4046960, 1, "11fd991d7512eb7d72d0d55e65c4b6e7a1851e35949cce2081ece003c2fb9e33") -- Car Dealer Simulator - Up 2 You DLC - Depot 4046960

