-- Lua provided by RyzenAPI
-- Game: Placebo Effect

-- MAIN APPLICATION
addappid(629550)

-- MAIN APP DEPOTS / PACKAGES
addappid(629551, 1, "7951b455cd3e079f489ea466bc266c743d9478292553ac79d390d43821670d2c")
