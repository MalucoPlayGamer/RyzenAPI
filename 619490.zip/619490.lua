-- Lua provided by RyzenAPI
-- Game: 619490

-- MAIN APPLICATION
addappid(619490)
addappid(619491)
addappid(619492)
-- Game: addappid(619490)

-- MAIN APP DEPOTS / PACKAGES
addappid(619493,0,"ebf573f76b66fc52bbc53eff403bf33d7cc8a2dc550a8c504422eed517eadf89")
