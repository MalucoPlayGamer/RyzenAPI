-- Lua provided by RyzenAPI
-- Game: addappid(736110)

-- MAIN APPLICATION
addappid(736110)

-- MAIN APP DEPOTS / PACKAGES
addappid(736111, 1, "17f75e5abd2eae377c72e7c48d0fe618ea4f588ac4f647748bcaf6617066ba04")
