-- Lua provided by RyzenAPI 
-- Game: Deep Sorrow
addappid(736110)
addappid(736111, 1, "17f75e5abd2eae377c72e7c48d0fe618ea4f588ac4f647748bcaf6617066ba04")
