-- Lua provided by RyzenAPI
-- Game: 412310

-- MAIN APPLICATION
addappid(412310)
addappid(412311)
-- Game: addappid(412310)

-- MAIN APP DEPOTS / PACKAGES
addappid(412312,0,"1f99d6887d6fe6a42133ccd02832e4d554416b67de24692df0f1fd55d62fdfb5")
addappid(412313,0,"ffeed942ee92c2d6df89bdeb67d0ba7f21e8f616f7d88693b890e3c4cfe9924d")
