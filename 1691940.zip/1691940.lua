-- Lua provided by RyzenAPI
-- Game: 1691940

-- MAIN APPLICATION
addappid(1691940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691940,0,"22a660ab68d73dedad6c1f236d44288ab8be4da08971ee9ffc6849ffeee7e343")
