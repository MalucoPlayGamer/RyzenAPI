-- Lua provided by RyzenAPI
-- Game: Deep Sea Fish: Hidden World

-- MAIN APPLICATION
addappid(4710400)
addappid(4859760)

-- MAIN APP DEPOTS / PACKAGES
addappid(4710401,0,"8cd699c8594d5cd1ede7133f82837f4857733fba7a558e0043d8ceefda3571ff")

