-- Lua provided by RyzenAPI
-- Game: AppID 1085520

-- MAIN APPLICATION
addappid(1085520)
-- Game: addappid(1085520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085521, 1, "5d53a66f698a1ca8f2aaa71e791612522e0138850bac6ae7b018a6677525f0db")
