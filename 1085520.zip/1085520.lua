-- Lua provided by RyzenAPI
-- Game: AppID 1085520

-- MAIN APPLICATION
addappid(1085520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1085521, 1, "5d53a66f698a1ca8f2aaa71e791612522e0138850bac6ae7b018a6677525f0db")

