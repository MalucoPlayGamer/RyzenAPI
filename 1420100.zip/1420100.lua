-- Lua provided by RyzenAPI
-- Game: Skate Forever

-- MAIN APPLICATION
addappid(1420100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420101, 1, "dea6677487378dd54e695fcbdca1a25597559813776b1f92f1ca27aafac987a6")

