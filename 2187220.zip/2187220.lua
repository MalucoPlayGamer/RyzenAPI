-- Lua provided by RyzenAPI
-- Game: Game: Apollo Justice: Ace Attorney Trilogy

-- MAIN APPLICATION
addappid(2187220)
-- Game: addappid(2187220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187221, 1, "d9865c4fe54425b3fd8b8bb95b5f3b1d87e4c6c02a3ff6777ae43f9c480ac365")
