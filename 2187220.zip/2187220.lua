-- Lua provided by RyzenAPI
-- Game: Apollo Justice: Ace Attorney Trilogy

-- MAIN APPLICATION
addappid(2187220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187221, 1, "d9865c4fe54425b3fd8b8bb95b5f3b1d87e4c6c02a3ff6777ae43f9c480ac365")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
