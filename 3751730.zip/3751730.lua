-- Lua provided by RyzenAPI
-- Game: Loan Shark

-- MAIN APPLICATION
addappid(3751730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751731, 1, "47cd110d658fbbf8e22df9092734c6639b0a6d395cc9f643b056bcb5663d7e14")

