-- Lua provided by SkyAPI 
-- Game: AppID 365110
addappid(365110)
addappid(365111, 1, "d54e42f9e60ef0773df1a28982e0dd960d973f6c08dea51bce31cb478b966a54")
