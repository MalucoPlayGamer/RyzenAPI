-- Lua provided by RyzenAPI
-- Game: AppID 365110

-- MAIN APPLICATION
addappid(365110)
-- Game: addappid(365110)

-- MAIN APP DEPOTS / PACKAGES
addappid(365111, 1, "d54e42f9e60ef0773df1a28982e0dd960d973f6c08dea51bce31cb478b966a54")
