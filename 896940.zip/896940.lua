-- Lua provided by RyzenAPI 
-- Game: Switcher
addappid(896940)
addappid(896941, 1, "19c50f509d7054bd008fcb96a451cde19e664083c5eb763eb33a7d36c7815e02")
