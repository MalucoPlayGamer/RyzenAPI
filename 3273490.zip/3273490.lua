-- Lua provided by RyzenAPI
-- Game: 3273490

-- MAIN APPLICATION
addappid(3273490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273490,0,"bd2ee0c4b65cfa695db6f47c24a2c7c2a508e1a1df69be2478180e3b138cb2af")
