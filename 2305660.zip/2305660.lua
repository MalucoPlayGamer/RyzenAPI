-- Lua provided by RyzenAPI
-- Game: addappid(2305660)

-- MAIN APPLICATION
addappid(2305660)
addappid(2305661)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305662,0,"fd3834626fe0fb254f567e19c07831ea4684b5b1dc4360fdd0fd76a99491acd5")
