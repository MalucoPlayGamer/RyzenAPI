-- Lua provided by SkyAPI 
-- Game: Baby Redemption
addappid(1029040)
addappid(1029041, 1, "8a47a3ada58f721dceaa6f2020603f3f6a18989cd878b23fd24ff3317642df31")
