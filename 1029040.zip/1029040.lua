-- Lua provided by RyzenAPI
-- Game: Baby Redemption

-- MAIN APPLICATION
addappid(1029040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029041, 1, "8a47a3ada58f721dceaa6f2020603f3f6a18989cd878b23fd24ff3317642df31")
