-- Lua provided by RyzenAPI
-- Game: AppID 774861

-- MAIN APPLICATION
addappid(774861)
-- Game: addappid(774861)

-- MAIN APP DEPOTS / PACKAGES
addappid(774862, 1, "7ebe2b518f78af33401d895c196fda07bfe8c06f605f600560d4ea5698eb6fa7")
