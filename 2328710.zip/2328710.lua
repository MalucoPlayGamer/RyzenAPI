-- Lua provided by RyzenAPI
-- Game: Genesis of a Small God

-- MAIN APPLICATION
addappid(2328710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328711, 1, "ac362388937a91d48e3add61595866f7b6bb75e45a6236d26d34827e9f3ef732")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
