-- Lua provided by SkyAPI 
-- Game: Genesis of a Small God
addappid(2328710)
addappid(2328711, 1, "ac362388937a91d48e3add61595866f7b6bb75e45a6236d26d34827e9f3ef732")
