-- Lua provided by RyzenAPI
-- Game: Game: SILT

-- MAIN APPLICATION
addappid(1325890)
-- Game: addappid(1325890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325891, 1, "3e9ae73b41ab1ac368773e2d91041f3db6b16707574f4e561ae7aa7c032cc130")
