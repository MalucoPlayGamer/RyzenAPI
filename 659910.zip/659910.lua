-- Lua provided by RyzenAPI
-- Game: Loptice

-- MAIN APPLICATION
addappid(659910)

-- MAIN APP DEPOTS / PACKAGES
addappid(659911,0,"2f7160373265456feaaed606cfcc3a89d57947ca9d5055044de63bcef003dfef")

