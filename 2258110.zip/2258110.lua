-- Lua provided by RyzenAPI
-- Game: Sphere Game Legendary

-- MAIN APPLICATION
addappid(2258110)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2258111, 1, "02f4f93ed51d972b2e215f06226196d66a12deeace1824472be89014b63e3fb4")

