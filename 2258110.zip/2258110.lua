-- Lua provided by RyzenAPI
-- Game: Game: Sphere Game Legendary

-- MAIN APPLICATION
addappid(2258110)
-- Game: addappid(2258110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258111, 1, "02f4f93ed51d972b2e215f06226196d66a12deeace1824472be89014b63e3fb4")
