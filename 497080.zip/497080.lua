-- Lua provided by SkyAPI 
-- Game: Construct: Escape the System
addappid(497080)
addappid(497081, 1, "f508464195757507a3e369b8558d8467b682d5ae8cd45a6eff22e6c598c65af3")
addappid(497082, 1, "41d2b7a4d8c64a88069ddaf844f33dd66b6a9366f830719fc04b4f5fe1e4f749")
addappid(497083, 1, "9129a8c0328e6b7a7aaf13eca4b40081ec8d735564c233e24d0f4e5be0ccfa26")
