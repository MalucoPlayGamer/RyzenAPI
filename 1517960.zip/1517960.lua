-- Lua provided by SkyAPI 
-- Game: Rebirth:Beware of Mr.Wang
addappid(1517960)
addappid(1517961, 1, "88b603a7ec975fc86c50e8191631adbb54d2c555d9c925d002951efb27882ab0")
addappid(1761550, 0, "71fb70da9c5bdf4e0fae5f4d93afb2d847b89ed437b0006ec25679adfce05778")
