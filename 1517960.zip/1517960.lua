-- Lua provided by RyzenAPI
-- Game: Rebirth:Beware of Mr.Wang

-- MAIN APPLICATION
addappid(1517960)
-- Game: addappid(1517960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517961, 1, "88b603a7ec975fc86c50e8191631adbb54d2c555d9c925d002951efb27882ab0")
addappid(1761550, 0, "71fb70da9c5bdf4e0fae5f4d93afb2d847b89ed437b0006ec25679adfce05778")
