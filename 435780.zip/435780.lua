-- Lua provided by RyzenAPI
-- Game: VIOLET: Space Mission

-- MAIN APPLICATION
addappid(435780)

-- MAIN APP DEPOTS / PACKAGES
addappid(435782,0,"ee8cd914ec1e7a6167921d6ec123fc7dcc27cb8c1f63a96ab583ce0c3f0086b0")
addappid(435783,0,"190d5ccbb1241cc9e403589431c50074f6b0cc462a923aa054078761aea2760f")

