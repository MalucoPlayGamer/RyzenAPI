-- Lua provided by RyzenAPI
-- Game: Game: GoatPunks

-- MAIN APPLICATION
addappid(425450)
-- Game: addappid(425450)

-- MAIN APP DEPOTS / PACKAGES
addappid(425451, 1, "9578762ef7cc36fdbbeabdd4b58008e26e11845e60404e9226af912e5f6bce86")
addappid(425452, 1, "ce9795a387c52d3e9b9e868ccaeba304f90b680398b746c18bb3d6fde73eb6d6")
addappid(425453, 1, "5f217eea9bc44529fd4c9ba28987d9fb89c0b16fcffbf3721f56e2bc3d44503b")
