-- Lua provided by RyzenAPI
-- Game: CatffeeTime Demo

-- MAIN APPLICATION
addappid(2990260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990261, 1, "6ce4efa4fbe56f2c1de34b700abd588f0ff9f61b41334f91e789fe2f765f1d84")

