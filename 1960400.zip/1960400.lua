-- Lua provided by SkyAPI 
-- Game: SokoChess
addappid(1960400)
addappid(1960401, 1, "87b26f1b4a12ff38b8a2ea2ef2cb408caa5d3abc90b1d78acdfac7a6b42e5795")
