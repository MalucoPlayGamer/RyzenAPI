-- Lua provided by RyzenAPI
-- Game: 763010

-- MAIN APPLICATION
addappid(763010)
-- Game: addappid(763010)

-- MAIN APP DEPOTS / PACKAGES
addappid(763011, 1, "2afc942d08e73e409f7f3de16d15bd2e8d9d784c090f48151b742c2ef52e55a2")
