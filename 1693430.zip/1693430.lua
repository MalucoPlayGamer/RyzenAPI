-- Lua provided by RyzenAPI
-- Game: 1693430

-- MAIN APPLICATION
addappid(1693430)
-- Game: addappid(1693430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693431, 1, "81a7dc1270a259832c29ade2c26e14dcddd0fd215bbd8bd50c3b16ed936ec545")
