-- Lua provided by RyzenAPI
-- Game: addappid(773640)

-- MAIN APPLICATION
addappid(773640)

-- MAIN APP DEPOTS / PACKAGES
addappid(773641, 1, "d37a49913c6aac749e8045d67a23fdc03883bc2c9321fee7b4f68df70002716c")
