-- Lua provided by RyzenAPI
-- Game: AppID 572000

-- MAIN APPLICATION
addappid(572000)
-- Game: addappid(572000)

-- MAIN APP DEPOTS / PACKAGES
addappid(572001, 1, "adbb4ce4d3564079e6ba23229958a017a2b08db511410e31054bb8f1294216f9")
