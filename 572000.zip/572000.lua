-- Lua provided by RyzenAPI
-- Game: AppID 572000

-- MAIN APPLICATION
addappid(572000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(572001, 1, "adbb4ce4d3564079e6ba23229958a017a2b08db511410e31054bb8f1294216f9")

