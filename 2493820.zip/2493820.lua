-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Soldier Character Pack 2

-- MAIN APPLICATION
addappid(2493820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493820,0,"feb03f85fd92a349312a01ce2afd329a897978395913fd3db0871adfc6225d9e")

