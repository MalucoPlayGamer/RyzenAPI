-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.7 Minagoroshi

-- MAIN APPLICATION
addappid(1034940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1034941, 1, "74bda6f65f39df148bf5fb16cc0f1a4fac86f17d7c5ae90efef6f9a5241b7888")
