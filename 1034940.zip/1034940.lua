-- Lua provided by RyzenAPI
-- Game: addappid(1034940)

-- MAIN APPLICATION
addappid(1034940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034941, 1, "74bda6f65f39df148bf5fb16cc0f1a4fac86f17d7c5ae90efef6f9a5241b7888")
