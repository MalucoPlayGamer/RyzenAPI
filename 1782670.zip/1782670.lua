-- Lua provided by RyzenAPI
-- Game: Tru Or Die

-- MAIN APPLICATION
addappid(1782670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782671, 1, "061f27cb4f8bb5cc779722dbee9796bbc842a16374b028ace436ce44835506f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
