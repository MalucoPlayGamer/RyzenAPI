-- Lua provided by RyzenAPI
-- Game: Tru Or Die

-- MAIN APPLICATION
addappid(1782670)
-- Game: addappid(1782670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782671, 1, "061f27cb4f8bb5cc779722dbee9796bbc842a16374b028ace436ce44835506f5")
