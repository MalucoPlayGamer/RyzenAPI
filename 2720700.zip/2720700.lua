-- Lua provided by RyzenAPI
-- Game: Karos Classic

-- MAIN APPLICATION
addappid(2720700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720701, 1, "6fc2ff9aa25dfeac0f344b356a022e8b00a3f313b30ef4b8228cdf25dc29b025")

