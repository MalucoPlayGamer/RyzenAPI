-- Lua provided by RyzenAPI
-- Game: Apartament 1406: Horror Demo

-- MAIN APPLICATION
addappid(2419910)
-- Game: addappid(2419910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419911, 1, "e58a0c1d0b0c45095cae16c99098d5cc212ec343f1a44cbd65d306f7367dfb77")
