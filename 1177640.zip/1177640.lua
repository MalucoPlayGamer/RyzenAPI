-- Lua provided by RyzenAPI
-- Game: AppID 1177640

-- MAIN APPLICATION
addappid(1177640)
-- Game: addappid(1177640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177641, 1, "11af98e88a6ac2efc41cad0bf6d58c6d3b759776b00d093f29e1245b937e5165")
addappid(1177642, 1, "10daf458ab57227a1b66a0c153905aa2d8ad5fdc48527665d7877ff474cff771")
addappid(1177643, 1, "092887d33465f38b0e932a8d06a9fdadfccdef8a045bc1edc1986eaa10ca4847")
addappid(1177644, 1, "b296fb3ad93788bdc80d23fd48e0584759bdbf62dc563375f0a61efd3cf2bebe")
