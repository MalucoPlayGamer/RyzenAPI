-- Lua provided by RyzenAPI
-- Game: ROCKETRON

-- MAIN APPLICATION
addappid(1177640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1177641, 1, "11af98e88a6ac2efc41cad0bf6d58c6d3b759776b00d093f29e1245b937e5165")
addappid(1177642, 1, "10daf458ab57227a1b66a0c153905aa2d8ad5fdc48527665d7877ff474cff771")
addappid(1177643, 1, "092887d33465f38b0e932a8d06a9fdadfccdef8a045bc1edc1986eaa10ca4847")
addappid(1177644, 1, "b296fb3ad93788bdc80d23fd48e0584759bdbf62dc563375f0a61efd3cf2bebe")
