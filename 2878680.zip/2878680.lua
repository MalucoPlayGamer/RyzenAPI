-- Lua provided by RyzenAPI
-- Game: 2878680

-- MAIN APPLICATION
addappid(2878680)
-- Game: addappid(2878680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878681, 1, "ed7284142e9be927fb1a44bdfcf489ac123fcaf831277762236dac766be8d383")
