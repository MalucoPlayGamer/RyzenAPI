-- Lua provided by SkyAPI 
-- Game: DarkStorm
addappid(2748470)
addappid(2748471, 1, "fb01306f63637b0cfa4942f0ae62784256f0c1f70b29cf97922fe8b44e3d8033")
