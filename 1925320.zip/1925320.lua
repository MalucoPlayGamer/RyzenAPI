-- Lua provided by RyzenAPI
-- Game: addappid(1925320)

-- MAIN APPLICATION
addappid(1925320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925321, 1, "297a610ed5dbe44976351b6f2f85b038d6700d02db1ea0c15a08dbea3d137b70")
