-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Mansion Heist

-- MAIN APPLICATION
addappid(1925320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1925321, 1, "297a610ed5dbe44976351b6f2f85b038d6700d02db1ea0c15a08dbea3d137b70")

