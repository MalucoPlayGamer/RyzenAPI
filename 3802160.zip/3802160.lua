-- Lua provided by RyzenAPI
-- Game: Meow Moments: Music Festival

-- MAIN APPLICATION
addappid(3802160)
-- Game: addappid(3802160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3802161, 1, "42f895199f2571553afeef8faca325b90a545fbb596d50ace13530bc1a94af57")
