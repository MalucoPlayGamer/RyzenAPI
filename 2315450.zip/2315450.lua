-- Lua provided by RyzenAPI
-- Game: Game: Street of Secrets

-- MAIN APPLICATION
addappid(2315450)
-- Game: addappid(2315450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315451, 1, "1ee8a519d180191192c801a4d615c023331ea64c85f305be40ac7bf6f33e9057")
