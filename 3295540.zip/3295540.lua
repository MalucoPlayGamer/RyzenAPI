-- Lua provided by RyzenAPI
-- Game: Rogue Waters Demo

-- MAIN APPLICATION
addappid(3295540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295541, 1, "e07e0d237a6b208045af470142db7aa2e49439c71623179ac3791a03eeb7e2f2")

