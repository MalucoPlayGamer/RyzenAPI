-- Lua provided by SkyAPI 
-- Game: AppID 457320
addappid(457320)
addappid(457321, 1, "e0ad285c6496e074a5e6a5fa97c00bf385982f4cb3dd7e9bb8d70d1485735415")
