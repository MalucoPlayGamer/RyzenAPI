-- Lua provided by RyzenAPI
-- Game: Suna

-- MAIN APPLICATION
addappid(803920)

-- MAIN APP DEPOTS / PACKAGES
addappid(803921, 1, "32f416f17cfaff7b5452c550e2c49d1955d8e9860a139bff6eae2938c1adf84a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
