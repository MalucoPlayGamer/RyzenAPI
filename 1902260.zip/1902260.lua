-- Lua provided by RyzenAPI
-- Game: addappid(1902260)

-- MAIN APPLICATION
addappid(1902260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902261, 1, "66a5d1eecd63b0cce55343762e5a8acd41d4506dfe45ba5eff372457f703a414")
