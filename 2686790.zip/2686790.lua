-- Lua provided by RyzenAPI
-- Game: Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.14「螺旋の棺殺人事件」

-- MAIN APPLICATION
addappid(2686790)
-- Game: addappid(2686790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686791, 1, "000c8861e26872a680aa9bebf6e7e252740885da71741d138120145b1e69a9e8")
