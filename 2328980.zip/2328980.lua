-- Lua provided by RyzenAPI
-- Game: Dude Simulator 5

-- MAIN APPLICATION
addappid(2328980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328981, 1, "31f08ee589b660ab199a751795e773e674a7a42cc2f66db476c0a1bebf0491b9")

