-- Lua provided by RyzenAPI
-- Game: Vox Populi: Spain 2023

-- MAIN APPLICATION
addappid(2471480)
-- Game: addappid(2471480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471481, 1, "90d62120227a53899e7ff0065064b2537a92c1ab2c239182e0074467503ee9d7")
