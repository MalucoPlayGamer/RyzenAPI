-- Lua provided by RyzenAPI
-- Game: Game: Road Dogs

-- MAIN APPLICATION
addappid(622470)
-- Game: addappid(622470)

-- MAIN APP DEPOTS / PACKAGES
addappid(622471, 1, "432aa8365fff7dfe7b6be26d6d554dd2e95ceb43f8743ee59c9a8f0858277479")
addappid(622472, 1, "d94731e62e6b89606d6ec59644a283f087e3cefb62369ddbbefbcbf6e1b490c2")
addappid(622473, 1, "61251bd0d59580b6e7f74ea3e649a4680aa728ef89767e2b85e7a9605bcfb434")
