-- Lua provided by RyzenAPI
-- Game: addappid(2383870)

-- MAIN APPLICATION
addappid(2383870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383872,0,"d9c914a9e5a92d07f316cd273d6d76c72d2e44b6de95a4bec7a202ee02faca73")
