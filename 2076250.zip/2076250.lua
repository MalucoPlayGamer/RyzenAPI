-- Lua provided by RyzenAPI
-- Game: 2076250

-- MAIN APPLICATION
addappid(2076250)
-- Game: addappid(2076250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076251, 1, "68497c89f0319a3a8ec6a46efb74a41ab7bbabf600b5352e1706dff3ead6a86a")
