-- Lua provided by SkyAPI 
-- Game: Sunday Gold: Prologue
addappid(2076250)
addappid(2076251, 1, "68497c89f0319a3a8ec6a46efb74a41ab7bbabf600b5352e1706dff3ead6a86a")
