-- Lua provided by RyzenAPI
-- Game: Mother Machine

-- MAIN APPLICATION
addappid(1555980)
addappid(3357220)
addappid(3357240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555981, 1, "af26c56a40d4adfa8da15282c080280dc0d9b9b6cb9e16decd832f14bd83d3a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
