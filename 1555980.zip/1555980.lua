-- Lua provided by RyzenAPI
-- Game: Game: Mother Machine

-- MAIN APPLICATION
addappid(1555980)
addappid(3357220)
addappid(3357240)
-- Game: addappid(1555980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555981, 1, "af26c56a40d4adfa8da15282c080280dc0d9b9b6cb9e16decd832f14bd83d3a0")
