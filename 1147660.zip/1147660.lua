-- Lua provided by RyzenAPI
-- Game: ArcheAge: Unchained

-- MAIN APPLICATION
addappid(229004)
addappid(1147660)
addappid(1167280)
addappid(1167290)
addappid(1323240)
addappid(1323241)
addappid(1323242)
addappid(1327840)
addappid(1327841)
addappid(1327842)
addappid(1574960)
addappid(1574961)
addappid(1574962)
addappid(1826870)
addappid(1826871)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229004,0,"56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0")
addappid(1147661,0,"29b659e2cc802b74aea0f1999b2d347475ff80b19473366577286fc529d941b6")

