-- Lua provided by RyzenAPI
-- Game: Game: Prison Simulator Soundtrack

-- MAIN APPLICATION
addappid(3481810)
-- Game: addappid(3481810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481811, 1, "9843938bec4c809af02d639b7f719d74475f994ac5ea1b56c7c6397a6cc3c4ba")
