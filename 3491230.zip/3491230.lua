-- Lua provided by RyzenAPI
-- Game: Monster Girls and the Mysterious Adventure Remastered Edition

-- MAIN APPLICATION
addappid(3491230)
-- Game: addappid(3491230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491231, 1, "94ea08de4830399e2e476fad6a57cc42988b803ef8ac8b3b28f0cd12d344d414")
