-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Samurai Warriors Pack 2

-- MAIN APPLICATION
addappid(933526)

-- MAIN APP DEPOTS / PACKAGES
addappid(933526,0,"471242730a02af1ac613743a9be91950f71299fd53f5ff3bc8e423f351029fdc")

