-- Lua provided by RyzenAPI
-- Game: 3133860

-- MAIN APPLICATION
addappid(3133860)
-- Game: addappid(3133860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133862,0,"e9ba6354f820020e9abcf51dc4139e01301ae1dd1a3ea45fe261f9a09d8f937e")
addappid(3133863,0,"992126c8af4f9bca32464d0460da8af4dcf19b4966cd2c739b5a0e2fbb257925")
