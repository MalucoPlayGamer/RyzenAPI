-- Lua provided by RyzenAPI
-- Game: Game: Anamnesia - part 1: am i my body?

-- MAIN APPLICATION
addappid(2799320)
-- Game: addappid(2799320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799321, 1, "8f9af2db81a052f3dca4af48558234852eb1ffa2fc893a37984e27ada5346085")
addappid(2799322, 1, "501347f4182089565f16b9189a5ad2d77ff96ae9bf21d2f94aa96edbab45f104")
