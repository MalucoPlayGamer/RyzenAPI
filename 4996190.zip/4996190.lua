-- Lua provided by RyzenAPI
-- Game: Package chaos

-- MAIN APP DEPOTS / PACKAGES
addappid(4996190, 1, "b176f7a94dd374a551dfe8c12377b78e896b59f1c7b8169a617728998e769b1c") -- Package chaos
addappid(4996191, 1, "eb2035e161fab67dc4b9b618c44af156a9d6258fdb0e833ef0b9f59cc8788d8e") -- Depot 4996191
addappid(4996192, 1, "3705a53dd032a023b91d4aad87aab1a3fe75a182636c79680d719d14d50e5b8f") -- Depot 4996192

