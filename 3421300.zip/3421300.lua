-- Lua provided by RyzenAPI
-- Game: Lyca

-- MAIN APPLICATION
addappid(3421300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421301, 1, "df4a00244c156b8240c69b5ffc7e623d16d6785e53db1c36fc8749c0cd81bcd8")
