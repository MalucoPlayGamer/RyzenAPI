-- Lua provided by RyzenAPI
-- Game: 3312830

-- MAIN APPLICATION
addappid(3312830)
-- Game: addappid(3312830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312831, 1, "5c096f2de2d6616981a66129151cbf320d46fafb51eead3693ab1c963696a304")
