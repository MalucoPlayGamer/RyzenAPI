-- Lua provided by RyzenAPI
-- Game: Game: AppID 837610

-- MAIN APPLICATION
addappid(837610)
-- Game: addappid(837610)

-- MAIN APP DEPOTS / PACKAGES
addappid(837611, 1, "dd060cb46fb2642427216c2d03f70486155e90fc309465a06211cd767683e5b3")
