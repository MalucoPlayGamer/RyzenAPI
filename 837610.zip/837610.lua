-- Lua provided by RyzenAPI
-- Game: Mary Skelter: Nightmares

-- MAIN APPLICATION
addappid(837610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(837611, 1, "dd060cb46fb2642427216c2d03f70486155e90fc309465a06211cd767683e5b3")

