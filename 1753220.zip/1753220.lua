-- Lua provided by RyzenAPI
-- Game: addappid(1753220)

-- MAIN APPLICATION
addappid(1753220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753221, 1, "c99f6cf688364c152bc6b4120eacce863b1fb3b6ed3dfc81b418500aeb78ea88")
