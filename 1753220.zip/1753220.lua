-- Lua provided by RyzenAPI
-- Game: ANIME TETRIS

-- MAIN APPLICATION
addappid(1753220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753221, 1, "c99f6cf688364c152bc6b4120eacce863b1fb3b6ed3dfc81b418500aeb78ea88")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1799880)
addappid(1853860)
