-- Lua provided by RyzenAPI
-- Game: Chef

-- MAIN APPLICATION
addappid(886900)
addappid(1617870)
addappid(2057810)
addappid(2375390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(886901,0,"0b6fd34defc26d8d74d5460729a95fda85ceb98c8aef21176b1c5f6ed97df757")
addappid(1617871,0,"68c4afa157147910a41ee8778af66e9f9372848395b0df2035df58f94f03483e")
addappid(2057812,0,"88a5874ae682fd9ad13de6caeb924de1253a0b7515fb5e844d15d6351f84fa59")
addappid(2375391,0,"fc85f37c868ce55d912137f78c7f45227e34180b9aa6fe450970a80e4e646519")

