-- Lua provided by RyzenAPI
-- Game: 886900

-- MAIN APPLICATION
addappid(886900)
-- Game: addappid(886900)

-- MAIN APP DEPOTS / PACKAGES
addappid(886901, 1, "0b6fd34defc26d8d74d5460729a95fda85ceb98c8aef21176b1c5f6ed97df757")
