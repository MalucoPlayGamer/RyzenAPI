-- Lua provided by RyzenAPI
-- Game: 3168890

-- MAIN APPLICATION
addappid(3168890)
-- Game: addappid(3168890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168891, 1, "b471a77d18cd837e492ebedafe2b130f2d8bba25b558b1797f7768e8da4bb8ec")
