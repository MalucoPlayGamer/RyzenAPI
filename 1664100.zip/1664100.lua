-- Lua provided by RyzenAPI
-- Game: Game: FIGHT BOTS

-- MAIN APPLICATION
addappid(1664100)
-- Game: addappid(1664100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664101, 1, "1c6275382bd8e0a7be648266e41be34d0d821b2c6a5060397eada2ca04db945d")
