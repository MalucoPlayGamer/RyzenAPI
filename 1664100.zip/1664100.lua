-- Lua provided by RyzenAPI
-- Game: FIGHT BOTS

-- MAIN APPLICATION
addappid(1664100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664101, 1, "1c6275382bd8e0a7be648266e41be34d0d821b2c6a5060397eada2ca04db945d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
