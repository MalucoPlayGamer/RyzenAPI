-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1390420)
addappid(1390421)
addappid(1390424)
addappid(1390425)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390423,0,"e971b0c3cff2cf341fe43b0fe6628eca63f9ce3947891b6eb741b1a558116426")

