-- Lua provided by RyzenAPI
-- Game: Slave Master: The Game

-- MAIN APPLICATION
addappid(890470)

-- MAIN APP DEPOTS / PACKAGES
addappid(890471, 1, "7c38aa3aba25d11da9b16f43a1e6a28c7b698b36d53edb8d6c54b6c93bff302b")
