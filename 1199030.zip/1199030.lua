-- Lua provided by RyzenAPI
-- Game: Tainted Grail

-- MAIN APPLICATION
addappid(1199030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199031, 1, "a4802550dc67bfabc76bff3e1227266520e2f763370eabfb6262b75d11e8d65d")
addappid(1199032, 1, "8bc434f47c340259c407f1d998bc6c94c5f8eb5295ed001dde782067ffecc115")
