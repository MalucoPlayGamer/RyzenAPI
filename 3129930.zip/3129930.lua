-- Lua provided by RyzenAPI
-- Game: Nonentity Galaxy

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3129930, 1, "995ff938a9160f76c986bcdf05e05b02d0cbaa95a5f2683b52498f07084f2a90") -- Nonentity Galaxy
addappid(3129931, 1, "7b99778d12ff53b238b572d34c82833d1a6d55334cb68184857fea3db6212bb6") -- Depot 3129931

