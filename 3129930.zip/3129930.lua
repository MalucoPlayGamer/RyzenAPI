-- 3129930's Lua and Manifest Created by Hubcap Manifest
-- Nonentity Galaxy
-- Created: August 13, 2026 at 11:02:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3129930, 1, "995ff938a9160f76c986bcdf05e05b02d0cbaa95a5f2683b52498f07084f2a90") -- Nonentity Galaxy
-- MAIN APP DEPOTS
addappid(3129931, 1, "7b99778d12ff53b238b572d34c82833d1a6d55334cb68184857fea3db6212bb6") -- Depot 3129931
setManifestid(3129931, "539271966776224694", 814329890)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)