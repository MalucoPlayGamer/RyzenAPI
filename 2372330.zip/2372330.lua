-- Lua provided by RyzenAPI
-- Game: 2372330

-- MAIN APPLICATION
addappid(2372330)
-- Game: addappid(2372330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372331, 1, "07f41754bba0b990ab7cb40d3b98264155d8095234b71eed3a3e2fca7dbf3462")
