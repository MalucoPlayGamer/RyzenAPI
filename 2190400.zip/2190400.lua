-- Lua provided by RyzenAPI
-- Game: Toads of the Bayou

-- MAIN APPLICATION
addappid(2190400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190401, 1, "1dd56a97de51422898e54c8c6c7454c19dac2a32c4bae4efcb53ce0792c681f2")
