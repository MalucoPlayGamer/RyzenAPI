-- Lua provided by RyzenAPI
-- Game: Wasteland Kitchen

-- MAIN APPLICATION
addappid(3195920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3195921, 1, "72330205fab7c578f95888adcd147a6cd47f00240e3d9e00912948c05de13ec5")

