-- Lua provided by SkyAPI 
-- Game: Wasteland Kitchen
addappid(3195920)
addappid(3195921, 1, "72330205fab7c578f95888adcd147a6cd47f00240e3d9e00912948c05de13ec5")
