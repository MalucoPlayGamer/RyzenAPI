-- Lua provided by RyzenAPI
-- Game: addappid(3195920)

-- MAIN APPLICATION
addappid(3195920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195921, 1, "72330205fab7c578f95888adcd147a6cd47f00240e3d9e00912948c05de13ec5")
