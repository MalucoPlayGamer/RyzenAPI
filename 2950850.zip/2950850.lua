-- Lua provided by RyzenAPI
-- Game: Dark Daemon

-- MAIN APPLICATION
addappid(2950850)
addappid(2952890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950851, 1, "ce77724c691b1b213e6e2bc3f0cf40f2a7f91018a8a53f8d9dbde6a5300dc43e")
