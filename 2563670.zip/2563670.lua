-- Lua provided by RyzenAPI
-- Game: Game: INTO EVIL Demo

-- MAIN APPLICATION
addappid(2563670)
-- Game: addappid(2563670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563671, 1, "89bb468ce698642c5ee8e8236ef64c425ee3218dbf63a2ae64737bf1cc7901a3")
