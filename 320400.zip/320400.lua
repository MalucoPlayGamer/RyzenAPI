-- Lua provided by RyzenAPI
-- Game: Game: Magnifico

-- MAIN APPLICATION
addappid(320400)
-- Game: addappid(320400)

-- MAIN APP DEPOTS / PACKAGES
addappid(320401, 1, "ba38bd867b5517390c033c56a7a81f09d0a540c983e814611ef454b37d734d52")
addappid(320402, 1, "8d7184f6f51966f40f1ee174122a7ca5eb4c97d318f413bcea442613a9bb1edc")
addappid(320403, 1, "1250d0922b2158bd8e79cdb1237a99048e298684ef7d7aee874d65a45730cb2b")
