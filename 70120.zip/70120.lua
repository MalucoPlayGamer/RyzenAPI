-- Lua provided by RyzenAPI
-- Game: Hacker Evolution Duality

-- MAIN APPLICATION
addappid(70120)
addappid(211992)
addappid(211994)
addappid(241950)
addappid(241951)
addappid(259220)
addappid(261070)

-- MAIN APP DEPOTS / PACKAGES
addappid(70121, 1, "84c3b10d605d704bba938a9857065fb689705f37e176bdcf2962a5117cad90f2")
addappid(70122, 1, "efab5fc8c5522318f1561cd7f2236380645ecdcbe774bdfa80ab9f60cfd13f4a")
addappid(70123, 1, "0f51d44b663907e7c871e378f35cbafc8bda1e2589110ce1b000a61f3b08fdf3")
addappid(211990, 0, "7af11ea2ad90f0f2bfd4939cc8b7848919b6f6806433f7d1953b83d0fe2fb480")
addappid(211991, 0, "1b086a442fb5cbac1b54b01e0eb7be10413f79d439d23d49f0f3cc0e3cc2bfba")
