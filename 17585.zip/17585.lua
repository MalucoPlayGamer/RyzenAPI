-- Lua provided by RyzenAPI
-- Game: Dystopia Dedicated Server

-- MAIN APPLICATION
addappid(17585)

-- MAIN APP DEPOTS / PACKAGES
addappid(17581,0,"06dbb53f43c234945eb426efbe5cfc606cd18fdb4cc34444a17a9b17c077188f")
addappid(806640,0,"620c97e3292800765ceb9c1b98f434232ffd4961f20e9ab380ef23469b559624")
addappid(806641,0,"ae5a7b8cc61015389a65e272db9e1ddefbbc71378ec987869857036d75a738fb")

