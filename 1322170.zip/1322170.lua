-- Lua provided by RyzenAPI
-- Game: 1322170

-- MAIN APPLICATION
addappid(1322170)
-- Game: addappid(1322170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322171, 1, "e660d066972c905028019b0a3a33fe8a133286f884bc1dc78796bc48ca8bba51")
