-- Lua provided by RyzenAPI
-- Game: The Drawstring Dungeon

-- MAIN APPLICATION
addappid(3709000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709001, 1, "f88f710a9534428c3ba10cd5aec23c41c69a4a24760fff14b4ccfe856fcd5c07")
