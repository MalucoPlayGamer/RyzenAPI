-- Lua provided by RyzenAPI
-- Game: Slime 3K: Rise Against Despot Demo

-- MAIN APPLICATION
addappid(2464710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464711, 1, "8e574c85fc2d98eba36b32940ded87ff9a8f23a9787462383006800fb22e0a01")

