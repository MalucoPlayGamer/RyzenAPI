-- Lua provided by RyzenAPI
-- Game: Trials of The Illuminati: Animated Christmas Time Jigsaws

-- MAIN APPLICATION
addappid(709770)

-- MAIN APP DEPOTS / PACKAGES
addappid(709771, 1, "41cb6bb1974cdc8103b62105208cba7cdbb2dec27eaa35b732348e87e16e9ce2")
