-- Lua provided by RyzenAPI
-- Game: AppID 524010

-- MAIN APPLICATION
addappid(524010)

-- MAIN APP DEPOTS / PACKAGES
addappid(524011, 1, "447d6ea72db4269929a5fb4be7f4499684fdd85a75bd48c54a7b6fb7300aa28f")
