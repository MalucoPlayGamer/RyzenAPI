-- Lua provided by RyzenAPI
-- Game: Mayan Prophecies: Cursed Island Collector's Edition

-- MAIN APPLICATION
addappid(678430)

-- MAIN APP DEPOTS / PACKAGES
addappid(678431,0,"eb471aa798584a7cf2a6b569fca0388bfbd0047e1ce9c7e2d9b188416caa7965")

