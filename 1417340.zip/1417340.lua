-- Lua provided by SkyAPI 
-- Game: Werewolf Online
addappid(1417340)
addappid(1417341, 1, "20bd9b4e351b6cadfd995bcd05ceb05e7705df732efad5257b48b35b831cd1d1")
