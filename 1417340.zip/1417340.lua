-- Lua provided by RyzenAPI
-- Game: Werewolf Online

-- MAIN APPLICATION
addappid(1417340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417341, 1, "20bd9b4e351b6cadfd995bcd05ceb05e7705df732efad5257b48b35b831cd1d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
