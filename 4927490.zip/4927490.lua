-- Lua provided by RyzenAPI
-- Game: Cleaning Up The Puzzle Gallery

-- MAIN APPLICATION
addappid(4927490)

-- MAIN APP DEPOTS / PACKAGES
addappid(4927491,0,"0a9c18b5a6327e0308e30ea86b76789f462d4fa7c14774be318f2ab4c0165f51")

