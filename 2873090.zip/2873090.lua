-- Lua provided by RyzenAPI
-- Game: 2873090

-- MAIN APPLICATION
addappid(2873090)
-- Game: addappid(2873090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873091, 1, "577e3dad410cbd0b7880a6737812d796371db379f600c60f42db0a2fa31c7a9f")
