-- Lua provided by RyzenAPI
-- Game: Fortress Forever Dedicated Server

-- MAIN APPLICATION
addappid(329710)

-- MAIN APP DEPOTS / PACKAGES
addappid(329711, 1, "91f6b6685c5c7d79cc1e5f5b256836bda788c63876d5730bc1e8985e228752bf")
addappid(329712, 1, "620026db584dd569950de2e22d5e85fcc8e031872e2e245dbc30cb56952257da")
addappid(329713, 1, "f99d6c637429b890c0d0e95d7156a716ac344363ab681137cfaec947c4d7c655")
