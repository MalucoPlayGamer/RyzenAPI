-- Lua provided by RyzenAPI
-- Game: 2114320

-- MAIN APPLICATION
addappid(2114320)
addappid(2115410)
-- Game: addappid(2114320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114321, 1, "7f08484b06d78580d08129a11307f3279880a52b9c44d813e8c84efabe5b52e4")
