-- Lua provided by SkyAPI 
-- Game: AppID 2786270
addappid(2786270)
addappid(2786271, 1, "c15a1bce084a2e885b65a78c4f4823eb5d634f600f7af0f0ba002bf9d7ebabbb")
