-- Lua provided by RyzenAPI
-- Game: POLE Demo

-- MAIN APPLICATION
addappid(1647230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647231, 1, "9e93d4284ea3d6eb4d68b62e972aaca9bddc6844039c039d63298a7d28e73864")

