-- Lua provided by RyzenAPI
-- Game: Tennis World Tour 2

-- MAIN APPLICATION
addappid(1223910)
addappid(1361310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223911, 1, "d5ece3518f689b8191f80becfcf798737843e59e3a901cab0d77da254bcdf7a2")
addappid(1361311, 0, "d09dd1fd6c6e7a8831f825748f6abe27625891c5a0ad7de678d83d6cce49a19c")
addappid(1397340, 0, "8e8edf1c409213bc93c4ea511a01350d049a1e1e4366cb86b36d9625546dd358")
addappid(1455640, 0, "cda4a48aeb3877b278ad2ceefb584ce28d3c72dd52ffc2be3f00f00d6a54f97b")
addappid(1455641, 0, "c7b8d788cc71f2cc288d49f0e39cfea04a8098555eb41fb19f7f6240f88bc49e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1397480)
