-- Lua provided by RyzenAPI
-- Game: Shantae and the Seven Sirens

-- MAIN APPLICATION
addappid(1191630)
-- Game: addappid(1191630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191631, 1, "e198d4224f70aff84c4c83f267f507140ebc23db88219823abbf299053996dc5")
