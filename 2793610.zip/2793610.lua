-- Lua provided by RyzenAPI
-- Game: Minami Lane Original Soundtrack

-- MAIN APPLICATION
addappid(2793610)
-- Game: addappid(2793610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793611, 1, "1354565e08fcd3fbbcae17885bee786f034e45a5017adfc068a067f915f466f2")
