-- Lua provided by SkyAPI 
-- Game: Minami Lane Original Soundtrack
addappid(2793610)
addappid(2793611, 1, "1354565e08fcd3fbbcae17885bee786f034e45a5017adfc068a067f915f466f2")
