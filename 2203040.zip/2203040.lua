-- Lua provided by RyzenAPI
-- Game: マーダーミステリーパラドクス このひと夏の十五年

-- MAIN APPLICATION
addappid(2203040)
-- Game: addappid(2203040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203042,0,"5f177d47de9acbbbc99485a5223e63e6e5c25009ab31fa77349d0bd2db248388")
