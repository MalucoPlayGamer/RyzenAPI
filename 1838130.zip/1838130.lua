-- Lua provided by RyzenAPI 
-- Game: Hellscape
addappid(1838130)
addappid(1838131, 1, "ea9c281754bb444497325a49ad3da3c4ae1a2f09eb92d3bfae0d651cd8969117")
