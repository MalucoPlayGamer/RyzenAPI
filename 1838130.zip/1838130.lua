-- Lua provided by RyzenAPI
-- Game: addappid(1838130)

-- MAIN APPLICATION
addappid(1838130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838131, 1, "ea9c281754bb444497325a49ad3da3c4ae1a2f09eb92d3bfae0d651cd8969117")
