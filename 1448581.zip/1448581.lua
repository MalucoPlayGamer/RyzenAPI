-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1448581)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448581,0,"59879d6dc21641efafd1096b1ccbda7a82af8842238c8d7003abd67098f8df57")

