-- Lua provided by RyzenAPI
-- Game: addappid(1448581)

-- MAIN APPLICATION
addappid(1448581)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448581,0,"59879d6dc21641efafd1096b1ccbda7a82af8842238c8d7003abd67098f8df57")
