-- Lua provided by RyzenAPI
-- Game: addappid(800830)

-- MAIN APPLICATION
addappid(800830)

-- MAIN APP DEPOTS / PACKAGES
addappid(800831, 1, "c55cd87fa5b413cb6876b0f6b351d4a23895b437f4db6c81874ead1c8260d61f")
