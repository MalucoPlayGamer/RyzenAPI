-- Lua provided by RyzenAPI
-- Game: 1497700

-- MAIN APPLICATION
addappid(1497700)
-- Game: addappid(1497700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497701, 1, "5386198049208eb1a6f57156118cb5ec8b88c92157a47fef9b32d5ee1bac9a96")
