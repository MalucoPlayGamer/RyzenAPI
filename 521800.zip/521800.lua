-- Lua provided by RyzenAPI
-- Game: Command Ops 2 Core Game

-- MAIN APPLICATION
addappid(521800)

-- MAIN APP DEPOTS / PACKAGES
addappid(521801, 1, "eab59522c06717084c545fff6fe112b82854a95b47d37a03aa6c3b76d94bf9c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(524170)
addappid(524171)
addappid(524172)
addappid(524173)
addappid(524174)
addappid(524175)
addappid(524176)
addappid(590810)
