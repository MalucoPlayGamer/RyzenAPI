-- Lua provided by RyzenAPI
-- Game: Command Ops 2 Core Game

-- MAIN APPLICATION
addappid(521800)

-- MAIN APP DEPOTS / PACKAGES
addappid(521801, 1, "eab59522c06717084c545fff6fe112b82854a95b47d37a03aa6c3b76d94bf9c0")

