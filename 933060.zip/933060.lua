-- Lua provided by RyzenAPI
-- Game: AppID 933060

-- MAIN APPLICATION
addappid(933060)

-- MAIN APP DEPOTS / PACKAGES
addappid(933061, 1, "a21fe1bb03230a05689b2d58bd82b9bb2b7c0b89c55e3d517cc189b57e0f8cef")
addappid(933100, 0, "8d25e0afae158605f4613b21d6471e9b2bb5810e80053eb7e6d900076655395f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
