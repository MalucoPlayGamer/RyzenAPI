-- Lua provided by RyzenAPI
-- Game: AppID 933060

-- MAIN APPLICATION
addappid(933060)
-- Game: addappid(933060)

-- MAIN APP DEPOTS / PACKAGES
addappid(933061, 1, "a21fe1bb03230a05689b2d58bd82b9bb2b7c0b89c55e3d517cc189b57e0f8cef")
addappid(933100, 0, "8d25e0afae158605f4613b21d6471e9b2bb5810e80053eb7e6d900076655395f")
