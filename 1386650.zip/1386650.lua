-- Lua provided by RyzenAPI
-- Game: ZCREW

-- MAIN APPLICATION
addappid(1386650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386651, 1, "b540cbf66467eba74ba780aa95616794e5e1c392dae08ee2ef8bff592c3da647")
addappid(2341940, 0, "ce8449ce79194d4965217b21d0c5c1a6e060cb582e00f4f7c56542dfa388ff5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
