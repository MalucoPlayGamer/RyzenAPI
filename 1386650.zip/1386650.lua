-- Lua provided by RyzenAPI 
-- Game: ZCREW
addappid(1386650)
addappid(1386651, 1, "b540cbf66467eba74ba780aa95616794e5e1c392dae08ee2ef8bff592c3da647")
addappid(2341940, 0, "ce8449ce79194d4965217b21d0c5c1a6e060cb582e00f4f7c56542dfa388ff5f")
