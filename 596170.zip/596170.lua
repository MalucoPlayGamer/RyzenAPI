-- Lua provided by RyzenAPI
-- Game: Magazine Editor

-- MAIN APPLICATION
addappid(596170)

-- MAIN APP DEPOTS / PACKAGES
addappid(596171, 1, "8508c44307a8c11bdbbfd4bc7ea7f858eb69a5096b95cba170679a3d8a305d7b")
