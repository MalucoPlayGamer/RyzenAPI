-- Lua provided by RyzenAPI
-- Game: Stellar Odyssey

-- MAIN APPLICATION
addappid(4629900)
