-- Lua provided by RyzenAPI 
-- Game: Celestial
addappid(1194910)
addappid(1194911, 1, "89defc13abc5c6261f4ace8d41bb5c82d0f2aa0ab09707e58ab099f97938d46f")
