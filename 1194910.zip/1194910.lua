-- Lua provided by RyzenAPI
-- Game: Celestial

-- MAIN APPLICATION
addappid(1194910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194911, 1, "89defc13abc5c6261f4ace8d41bb5c82d0f2aa0ab09707e58ab099f97938d46f")
