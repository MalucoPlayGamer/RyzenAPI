-- Lua provided by RyzenAPI
-- Game: 2449820

-- MAIN APPLICATION
addappid(2449820)
-- Game: addappid(2449820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449824,0,"4ab4b46ca4c7d22f69dd930f580258532a3d02201a0cf1afee6bb506ce17f3e2")
