-- Lua provided by RyzenAPI
-- Game: 1009711

-- MAIN APPLICATION
addappid(1009711)
-- Game: addappid(1009711)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009711,0,"db65636e389507230ef9746e4cf4d38d9604d628fa19a9d7db9d8cada864122e")
