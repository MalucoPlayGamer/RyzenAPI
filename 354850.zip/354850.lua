-- Lua provided by RyzenAPI
-- Game: Why So Evil 2: Dystopia

-- MAIN APPLICATION
addappid(354850)

-- MAIN APP DEPOTS / PACKAGES
addappid(354851, 1, "7be8ad76c44ee57987e69d1eba5b4b1271c20e6d233f3dab3aede20a053fc99d")

