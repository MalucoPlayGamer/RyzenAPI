-- Lua provided by RyzenAPI
-- Game: 2651760

-- MAIN APPLICATION
addappid(2651760)
-- Game: addappid(2651760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651761, 1, "8537fe29cd4e0ea9230dd8765a6287f30fac3e3bb5c93781aa08042746616e75")
