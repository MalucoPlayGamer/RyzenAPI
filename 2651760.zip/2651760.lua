-- Lua provided by SkyAPI 
-- Game: Dangerous Arena
addappid(2651760)
addappid(2651761, 1, "8537fe29cd4e0ea9230dd8765a6287f30fac3e3bb5c93781aa08042746616e75")
