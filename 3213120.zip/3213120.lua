-- Lua provided by RyzenAPI
-- Game: Machinefall

-- MAIN APPLICATION
addappid(3213120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213121,0,"1e1f75386bd23cd3eba2c5e0d29d0ba8e655c4829e121663aa034b011ba185ae")

