-- Lua provided by RyzenAPI
-- Game: addappid(1532380)

-- MAIN APPLICATION
addappid(1532380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532381, 1, "16e9fe5afcec0680f9202e00fac743b962bffc4a0830eebb2394cc03c67f3867")
