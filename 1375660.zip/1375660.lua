-- Lua provided by RyzenAPI
-- Game: AppID 1375660

-- MAIN APPLICATION
addappid(1375660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375661, 1, "c8ca92b7c1d3ca7d539d6c1faae3da813e34c67ce8419a4858cf9cc2b502d582")
