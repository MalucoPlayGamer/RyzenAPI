-- Lua provided by RyzenAPI
-- Game: 風色幻想5:赤月戰爭

-- MAIN APPLICATION
addappid(2020520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020521, 1, "140df98641ad2677b96cc8d2066e2765bf98a0aebd0867d08338322b68e4483b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
