-- Lua provided by RyzenAPI
-- Game: Game: 風色幻想5:赤月戰爭

-- MAIN APPLICATION
addappid(2020520)
-- Game: addappid(2020520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020521, 1, "140df98641ad2677b96cc8d2066e2765bf98a0aebd0867d08338322b68e4483b")
