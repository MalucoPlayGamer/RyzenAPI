-- Lua provided by RyzenAPI 
-- Game: DEMONS
addappid(1805570)
addappid(1805571, 1, "67bf2b91b4986ea18b621a4dd8bfef72b02dcfd92260c55bbe0de85d8a01790c")
