-- Lua provided by RyzenAPI
-- Game: 1683200

-- MAIN APPLICATION
addappid(1683200)
-- Game: addappid(1683200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683201, 1, "6e76fa96149a0fca407546bbd2f851f314f1695b9e02309c49b4826a970fe6c2")
