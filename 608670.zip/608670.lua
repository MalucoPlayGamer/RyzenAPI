-- Lua provided by RyzenAPI
-- Game: addappid(608670)

-- MAIN APPLICATION
addappid(608670)

-- MAIN APP DEPOTS / PACKAGES
addappid(608671, 1, "76f4f2576e9955afb9591278b04d971c85cf7ea2bd406ba19cfce2be9d50b1ac")
