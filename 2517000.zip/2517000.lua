-- Lua provided by RyzenAPI
-- Game: Game: BYLE

-- MAIN APPLICATION
addappid(2517000)
-- Game: addappid(2517000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517001, 1, "8e26c4f8b40a7bdec248065190a20f498eef06d72299dea918b3d613f4b04ea6")
