-- Lua provided by RyzenAPI 
-- Game: BYLE
addappid(2517000)
addappid(2517001, 1, "8e26c4f8b40a7bdec248065190a20f498eef06d72299dea918b3d613f4b04ea6")
