-- Lua provided by RyzenAPI
-- Game: TheFighters Online

-- MAIN APPLICATION
addappid(2010340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010341, 1, "7d1e9ed866fbe87a77959d1f64c51655da31ab443d2ddd331d5ee3070c9596a2")

