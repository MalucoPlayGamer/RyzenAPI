-- Lua provided by RyzenAPI 
-- Game: Barbarian Souls
addappid(769110)
addappid(769111, 1, "755711ce38e3d886e30b5871ced72855ac966bd6c9900cb82b244754e7c1bf76")
