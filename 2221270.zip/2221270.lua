-- Lua provided by RyzenAPI
-- Game: 2221270

-- MAIN APPLICATION
addappid(2221270)
-- Game: addappid(2221270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221271, 1, "b3e657d2704028f2c569b0ee261932fae5cd2978dabb86bb25191e362ccc0616")
