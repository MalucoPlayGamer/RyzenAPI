-- Lua provided by RyzenAPI
-- Game: AppID 1313050

-- MAIN APPLICATION
addappid(1313050)
addappid(1324240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313051, 1, "8edca1bff5c88ea710c42ebffecc50d7c025a81e09669bab95758cc141b4388d")

