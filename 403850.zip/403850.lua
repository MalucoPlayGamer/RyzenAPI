-- Lua provided by RyzenAPI 
-- Game: AppID 403850
addappid(403850)
addappid(403851, 1, "3ecb6a424c22ab9e4427708a134ece58cd473fb061b3d33ffe45c96adf5212e8")
addappid(403852, 1, "72bfbbf23e0de857dcced028f00349a90e1f99652dd2a854bedbb9b0dc1737c2")
addappid(403853, 1, "346c281337768cc97460d1c712f29e18a3e405d20323be2e08411ff2bfc15668")
