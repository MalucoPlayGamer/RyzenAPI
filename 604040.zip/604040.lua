-- Lua provided by RyzenAPI
-- Game: Game: Legion Tale

-- MAIN APPLICATION
addappid(604040)
-- Game: addappid(604040)

-- MAIN APP DEPOTS / PACKAGES
addappid(604041, 1, "08d7084f1364bda8b88d121a83146b27250adffc4224d134b104f28295376375")
