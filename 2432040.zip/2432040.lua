-- Lua provided by SkyAPI 
-- Game: NejicomiSimulator TMA02
addappid(2432040)
addappid(2432041, 1, "6fd5fe18b06aeec912f746e80798a55e62d86ff4cc32966de2d85b47aebfd5a4")
