-- Lua provided by RyzenAPI
-- Game: NejicomiSimulator TMA02

-- MAIN APPLICATION
addappid(2432040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432041, 1, "6fd5fe18b06aeec912f746e80798a55e62d86ff4cc32966de2d85b47aebfd5a4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2432050)
addappid(3109790)
