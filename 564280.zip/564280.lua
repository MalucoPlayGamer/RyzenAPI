-- Lua provided by RyzenAPI
-- Game: 564280

-- MAIN APPLICATION
addappid(564280)
addappid(564281)
-- Game: addappid(564280)

-- MAIN APP DEPOTS / PACKAGES
addappid(564282,0,"8186e7fa9b3bbceca79d692c93c6f799f804c16068126c15b155847e009d9390")
