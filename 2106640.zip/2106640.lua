-- Lua provided by RyzenAPI
-- Game: 代号：装甲时代

-- MAIN APPLICATION
addappid(2106640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2106641, 1, "8700da182d9b157f99a4f8ff6f2c6c065475e6a5fc45bb89a03969754528cc3f")

