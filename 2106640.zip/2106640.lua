-- Lua provided by RyzenAPI
-- Game: Game: 代号：装甲时代

-- MAIN APPLICATION
addappid(2106640)
-- Game: addappid(2106640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106641, 1, "8700da182d9b157f99a4f8ff6f2c6c065475e6a5fc45bb89a03969754528cc3f")
