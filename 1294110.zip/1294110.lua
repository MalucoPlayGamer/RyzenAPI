-- Lua provided by SkyAPI 
-- Game: AppID 1294110
addappid(1294110)
addappid(1294111, 1, "814372dc016cffe2f12779c09c2ee6a754081b5cf22c6c5686e12653cd3ab4a6")
addappid(1294113, 1, "15b69965e7ee45f4912af21887cafa0caa7b551dc4ca627162870c598a84188a")
