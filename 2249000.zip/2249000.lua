-- Lua provided by RyzenAPI
-- Game: 2249000

-- MAIN APPLICATION
addappid(2249000)
-- Game: addappid(2249000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249001, 1, "c9a98cf29998e12a31c0187b8b946c87e2785b168ca2d537bcab0030715f8b97")
