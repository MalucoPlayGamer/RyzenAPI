-- Lua provided by RyzenAPI
-- Game: addappid(568910)

-- MAIN APPLICATION
addappid(568910)

-- MAIN APP DEPOTS / PACKAGES
addappid(568911, 1, "7018eb37df66ed2e5836db3950038a6ffc190b214169127dc8768f2fbbac86bd")
