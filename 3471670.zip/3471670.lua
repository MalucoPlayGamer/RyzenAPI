-- Lua provided by RyzenAPI
-- Game: The Flayed Man

-- MAIN APPLICATION
addappid(3471670)
addappid(3471690)
-- Game: addappid(3471670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471671, 1, "8697f6f14b029a82b5f1236e143ecf97fb0460e20baac08700953ef5d35cd8d3")
