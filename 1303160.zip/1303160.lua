-- Lua provided by RyzenAPI
-- Game: Dig Bombers

-- MAIN APPLICATION
addappid(1303160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1303161, 1, "95c8ef2a272b20bfbdca860e98b6bc2ac4dcb2adb3d5882507ef95bc57e689ab")

