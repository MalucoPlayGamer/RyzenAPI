-- Lua provided by RyzenAPI
-- Game: 1303160

-- MAIN APPLICATION
addappid(1303160)
-- Game: addappid(1303160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303161, 1, "95c8ef2a272b20bfbdca860e98b6bc2ac4dcb2adb3d5882507ef95bc57e689ab")
