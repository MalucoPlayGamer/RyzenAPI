-- Lua provided by RyzenAPI
-- Game: WastePunk Demo

-- MAIN APPLICATION
addappid(3248440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248441, 1, "2183fb6b7fbb74e8ab17434ec6b6ee366300203bc10d7c818b15d9da6d0f8e20")
