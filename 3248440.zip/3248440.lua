-- Lua provided by RyzenAPI 
-- Game: AppID 3248440
addappid(3248440)
addappid(3248441, 1, "2183fb6b7fbb74e8ab17434ec6b6ee366300203bc10d7c818b15d9da6d0f8e20")
