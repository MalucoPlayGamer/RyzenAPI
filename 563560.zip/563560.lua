-- Lua provided by RyzenAPI
-- Game: Alien Swarm: Reactive Drop

-- MAIN APPLICATION
addappid(563560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(563561, 1, "fa5311e8473824241c7cb8ad6a5f5125b25d3f2ecfa963a7c880303106e9d469")
addappid(563562, 1, "185b68d4e971f70783541e98d1bbf47f48585fec0b3e45ecde0a29b48eb247a9")

