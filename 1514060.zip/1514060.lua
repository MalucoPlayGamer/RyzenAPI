-- Lua provided by RyzenAPI 
-- Game: EscalationVR_Demo
addappid(1514060)
addappid(1514061, 1, "74119021214c781d5f5e6232cd0048f95cb1bdf0b70986a832b05bde2a693c96")
