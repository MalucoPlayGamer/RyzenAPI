-- Lua provided by RyzenAPI
-- Game: Game: Nadir: A Grimdark Deckbuilder

-- MAIN APPLICATION
addappid(1535100)
-- Game: addappid(1535100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535101, 1, "84b5eac03034f6235b835eabb8dd9e1f1023f29d6722c5cfd1a649b04b04dc0b")
