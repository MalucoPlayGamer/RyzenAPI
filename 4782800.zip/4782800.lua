-- 4782800's Lua and Manifest Created by Hubcap Manifest
-- OPEN GUARD
-- Created: August 16, 2026 at 07:41:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4782800) -- OPEN GUARD
-- MAIN APP DEPOTS
addappid(4782801, 1, "fc1d93a1e98419f00c598e9e056795956b50ab6b6dc5effee56a95cd84a11ec9") -- Depot 4782801
setManifestid(4782801, "7313053959437476124", 764263748)