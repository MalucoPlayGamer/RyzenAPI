-- Lua provided by RyzenAPI
-- Game: Astrometica: Prologue

-- MAIN APPLICATION
addappid(2904320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2904321, 1, "633f93e881fd169a582b9f63411473e70df84f529ab69b8377d8b36a5f7c8fa7")

