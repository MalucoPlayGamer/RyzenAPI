-- Lua provided by RyzenAPI
-- Game: Astrometica: Prologue

-- MAIN APPLICATION
addappid(2904320)
-- Game: addappid(2904320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904321, 1, "633f93e881fd169a582b9f63411473e70df84f529ab69b8377d8b36a5f7c8fa7")
