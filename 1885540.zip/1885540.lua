-- Lua provided by RyzenAPI
-- Game: Game: SEARCH ALL - CATS

-- MAIN APPLICATION
addappid(1885540)
-- Game: addappid(1885540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885541, 1, "1c6a60641059a710bc09ba620ed2061b2a883d960cfc802c2349a3c5035eacf3")
