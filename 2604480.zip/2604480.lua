-- Lua provided by RyzenAPI
-- Game: City Transport Simulator®

-- MAIN APPLICATION
addappid(2604480)
addappid(3028650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604481, 1, "f90984d0922ee373e6a38ccc5dd98001fbf35a3abc8e101f8e6ebd27f9b53ee0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3100390)
addappid(3323410)
addappid(3323420)
addappid(3323430)
addappid(3592100)
addappid(3592110)
addappid(3711620)
addappid(3721360)
addappid(3864830)
addappid(3864840)
addappid(4132300)
