-- Lua provided by RyzenAPI 
-- Game: AppID 2635850
addappid(2635850)
addappid(2635851, 1, "e639b48520d141d5f4672765380a5a7e7161f3021098e9945566f5c56ccc7e11")
