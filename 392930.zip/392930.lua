-- Lua provided by RyzenAPI
-- Game: Game: A Sirius Game

-- MAIN APPLICATION
addappid(392930)
-- Game: addappid(392930)

-- MAIN APP DEPOTS / PACKAGES
addappid(392931, 1, "b2c82ca79014dd128b4a6f11dc8f64aafdcccfdd4aaef1e6007d3e8c020925fd")
