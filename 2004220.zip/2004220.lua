-- Lua provided by RyzenAPI
-- Game: 2004220

-- MAIN APPLICATION
addappid(2004220)
-- Game: addappid(2004220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004222,0,"b1cb14234c80db07a818a54618d9a07c09474b154bf4db06bf7356f00bfb0ca4")
