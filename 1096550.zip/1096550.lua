-- Lua provided by RyzenAPI
-- Game: Desktop Magic Engine

-- MAIN APPLICATION
addappid(1096550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096551, 1, "1b205d4d13f527bf953207c14bae7e03cba734ee980f371d9f3aa23b01b33436")
