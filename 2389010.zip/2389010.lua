-- Lua provided by RyzenAPI
-- Game: Elementcore Revelations: Journey Prologue

-- MAIN APPLICATION
addappid(2389010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389011, 1, "c2b835798e6a849214ff178c650d6e4e3802e27641e68b3aebe93c6fdfaa1553")

