-- Lua provided by RyzenAPI
-- Game: Mallow & The Street of the Fallen

-- MAIN APP DEPOTS / PACKAGES
addappid(4050550, 1, "8659349621a8e7669cc791c0fcbe8500ba2e9b2d7756db187f4affa451a590bc") -- Mallow & The Street of the Fallen
addappid(4050551, 1, "e5431adf0d469bec0ec91083b25006cb2995c42100d14094abe2753c254a1682") -- Depot 4050551
addappid(4050552, 1, "e251d1f22b8b12b8a6cefa3f0da2f31edd5e30d23d2db87e24ecbc0c9422d702") -- Depot 4050552

