-- 4050550's Lua and Manifest Created by Hubcap Manifest
-- Mallow & The Street of the Fallen
-- Created: August 13, 2026 at 11:15:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4050550, 1, "8659349621a8e7669cc791c0fcbe8500ba2e9b2d7756db187f4affa451a590bc") -- Mallow & The Street of the Fallen
-- MAIN APP DEPOTS
addappid(4050551, 1, "e5431adf0d469bec0ec91083b25006cb2995c42100d14094abe2753c254a1682") -- Depot 4050551
setManifestid(4050551, "964086287970500695", 472744209)
addappid(4050552, 1, "e251d1f22b8b12b8a6cefa3f0da2f31edd5e30d23d2db87e24ecbc0c9422d702") -- Depot 4050552
setManifestid(4050552, "1253257412027165023", 446805376)