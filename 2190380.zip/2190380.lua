-- Lua provided by RyzenAPI
-- Game: addappid(2190380)

-- MAIN APPLICATION
addappid(2190380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190381, 1, "208322bdaaa56447adb217898edf39b9f9c010ca0fa882a12251316ef4db6c80")
