-- Lua provided by RyzenAPI
-- Game: Rabi-Ribi - Original Soundtrack

-- MAIN APPLICATION
addappid(431620)

-- MAIN APP DEPOTS / PACKAGES
addappid(431622,0,"e9128dc3ffebfd8c85fa6856c089eb1a4b0bc3da43f6ac5395dd748dd3a0ec26")
addappid(431623,0,"724172c6492c34eae4ccd344dae16e270fdc2e0d8be4376a82fb822359feb88d")

