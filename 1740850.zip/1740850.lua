-- Lua provided by RyzenAPI
-- Game: Game: 角斗士学院（Gladiator School）

-- MAIN APPLICATION
addappid(1740850)
-- Game: addappid(1740850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740851, 1, "999c9956896bd796876635ed882cf18b3ad5179270ff2c436659b99cce6cf9a1")
