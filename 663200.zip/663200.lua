-- Lua provided by RyzenAPI
-- Game: Rift Coaster HD Remastered VR

-- MAIN APPLICATION
addappid(663200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(663201, 1, "91f629cd399c3bad1e00538f10bf9447d86aee226e3d33c425cf3ff2c713d33c")

