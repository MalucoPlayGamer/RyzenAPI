-- Lua provided by RyzenAPI
-- Game: 663200

-- MAIN APPLICATION
addappid(663200)
-- Game: addappid(663200)

-- MAIN APP DEPOTS / PACKAGES
addappid(663201, 1, "91f629cd399c3bad1e00538f10bf9447d86aee226e3d33c425cf3ff2c713d33c")
