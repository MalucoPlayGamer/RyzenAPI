-- Lua provided by RyzenAPI
-- Game: VR Chair Games

-- MAIN APPLICATION
addappid(605110)

-- MAIN APP DEPOTS / PACKAGES
addappid(605111, 1, "771e02d44927ad88bb7a7dac5d0e078ff7eab406b3f2982c0a7bc7a583baf56a")
