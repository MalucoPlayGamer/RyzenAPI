-- Lua provided by RyzenAPI 
-- Game: Chushpan Simulator 2
addappid(3024830)
addappid(3024831, 1, "6515f85aa697a4b8643a8f7e44979c68516da4ef2d497c1db7a3e8524219662d")
