-- Lua provided by RyzenAPI
-- Game: The Renovator: Origins

-- MAIN APPLICATION
addappid(1917550)
-- Game: addappid(1917550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917551, 1, "bbd0aebf560a55d8360256a1d40fee1557f0716a7fb40311f16e6d7004e964d9")
