-- Lua provided by RyzenAPI
-- Game: Yet Another Hard Game

-- MAIN APPLICATION
addappid(1559070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559071, 1, "433eab58f00e4f1c31e15b5ffcebfbfab62eb0f43e097d34ce6fff3c3fafd933")

