-- Lua provided by RyzenAPI
-- Game: Yet Another Hard Game

-- MAIN APPLICATION
addappid(1559070)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1559071, 1, "433eab58f00e4f1c31e15b5ffcebfbfab62eb0f43e097d34ce6fff3c3fafd933")

