-- Lua provided by RyzenAPI
-- Game: The Plucky Squire Soundtrack

-- MAIN APPLICATION
addappid(2485260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485261, 1, "dfce03ff0ddb55b1cbd4ab89dd7d6a50f52f7252ca3c68e4dd92c8ebf4153e62")
addappid(2485262, 1, "f1a3813409332edb6b23df992699f0054de5609c0b66dd7d84d8d5351714d3b3")
