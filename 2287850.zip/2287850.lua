-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2287850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287853,0,"220010f6eb533cf1db7eae1e553fa1edd75d4bb844743f077de3e1bdbbeb37c1")

