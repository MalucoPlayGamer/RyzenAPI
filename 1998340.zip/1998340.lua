-- Lua provided by RyzenAPI
-- Game: Labyrinth of Galleria: The Moon Society

-- MAIN APPLICATION
addappid(1998340)
-- Game: addappid(1998340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998341, 1, "301b85f154aff82db1493854a2e7b84de9976324f36068f54719f20392104cb2")
