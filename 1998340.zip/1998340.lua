-- Lua provided by RyzenAPI
-- Game: Labyrinth of Galleria: The Moon Society

-- MAIN APPLICATION
addappid(1998340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998341, 1, "301b85f154aff82db1493854a2e7b84de9976324f36068f54719f20392104cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2141440)
addappid(2253220)
