-- Lua provided by RyzenAPI
-- Game: Game: KARDS - The WW2 Card Game

-- MAIN APPLICATION
addappid(544810)
-- Game: addappid(544810)

-- MAIN APP DEPOTS / PACKAGES
addappid(544811, 1, "5e4ae85b0dbdd225d6da1cd10dc861b4836c0e907f2e685fe99ce8a50ccba6a9")
