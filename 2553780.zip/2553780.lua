-- Lua provided by RyzenAPI
-- Game: addappid(2553780)

-- MAIN APPLICATION
addappid(2553780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553781, 1, "fa03c4a98af3cb24e02d0585434dcf5c222799fa633e8a86bef2ac33d80c1cc2")
