-- Lua provided by RyzenAPI
-- Game: Game: AppID 1706240

-- MAIN APPLICATION
addappid(1706240)
-- Game: addappid(1706240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706241, 1, "89ab8c9ac993b4192584701e73b4f18389eaceb4ac2383351857c02e530c73d2")
