-- Lua provided by SkyAPI 
-- Game: AppID 1706240
addappid(1706240)
addappid(1706241, 1, "89ab8c9ac993b4192584701e73b4f18389eaceb4ac2383351857c02e530c73d2")
