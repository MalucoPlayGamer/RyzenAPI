-- Lua provided by RyzenAPI
-- Game: AppID 1706240

-- MAIN APPLICATION
addappid(1706240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706241, 1, "89ab8c9ac993b4192584701e73b4f18389eaceb4ac2383351857c02e530c73d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
