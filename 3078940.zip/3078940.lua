-- Lua provided by RyzenAPI 
-- Game: CHAIRS Soundtrack
addappid(3078940)
addappid(3078941, 1, "cabad07f5e52269e262d5059581233fbc17214290dfe5114b9e176a5e1c5a621")
addappid(3078942, 1, "177e4f5729f58fe3b2e45425b7636278e69a790b8cf7710791718bd8ee8f541e")
