-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Fractured Daydream DEMO

-- MAIN APPLICATION
addappid(3319640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319641, 1, "f07a8ad1f84e28d1263ab17aab71192966dbb37225c4cd711cb3e1c8c55d046c")

