-- Lua provided by RyzenAPI
-- Game: AppID 3169830

-- MAIN APPLICATION
addappid(3169830)
-- Game: addappid(3169830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169831, 1, "a8251b342bcd17c7c72d37f112d02f2eea5b9f5166f46aa3c43cc48e74c70136")
