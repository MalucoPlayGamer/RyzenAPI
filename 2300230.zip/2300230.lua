-- Lua provided by RyzenAPI
-- Game: addappid(2300230)

-- MAIN APPLICATION
addappid(2300230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300231, 1, "381a09ded1a5dd416d4c4b38d744d6220d455426876d2f90471363bddf70a27d")
