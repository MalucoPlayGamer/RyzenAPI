-- Lua provided by RyzenAPI
-- Game: Game: Blood Crawler

-- MAIN APPLICATION
addappid(2564070)
-- Game: addappid(2564070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564071, 1, "c525ac21889c7f34ad9318e309b770cf6eb332b044f55ae8ecca863befc6aaf1")
addappid(2564072, 1, "e4c5e6085c147cd2ea211df9675fba8229b981775ee8665ef2b6b6f08059831f")
addappid(2564073, 1, "bcf9be3d2580e9087a4fa968bcfbb148f09ef38c8b59013929973f7845a5acb3")
