-- Lua provided by RyzenAPI
-- Game: 1991520

-- MAIN APPLICATION
addappid(1991520)
-- Game: addappid(1991520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991521, 1, "8fffa8dde1dfdcdd3ce67477b954fb5847be9fd195ad2cd0294b044c5540c833")
