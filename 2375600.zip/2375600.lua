-- Lua provided by RyzenAPI
-- Game: addappid(2375600)

-- MAIN APPLICATION
addappid(2375600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375601, 1, "2ea97083102aa2724c02980ce4c9d8d52ff8de4a881c0703cf4a82ea438521e7")
