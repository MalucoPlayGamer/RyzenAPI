-- Lua provided by RyzenAPI
-- Game: Game: Guardian

-- MAIN APPLICATION
addappid(676850)
-- Game: addappid(676850)

-- MAIN APP DEPOTS / PACKAGES
addappid(676851, 1, "e0d4a84f14825db3b4e607db37506912f240fda481b2defb8f95fd367b498f23")
addappid(676852, 1, "7a4b75b6e50a20036546b2c5ee24cda414d70e149e0fc6bb3dc6e1f96886d2b8")
addappid(676854, 1, "8f7ec37a9742c7769cb70df8dce78c18e7515332ef4020b3e47cab8dc2ab5078")
addappid(676855, 1, "186b3c77109864de95f9e301113436d8dd26e70dfb485f4627e9871d60cbd039")
