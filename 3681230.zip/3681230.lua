-- Lua provided by RyzenAPI
-- Game: Observe

-- MAIN APPLICATION
addappid(3681230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681231,0,"b5c4dc3c5356c6837ead8da91296ebd3b8f1ae10bf36ca4200ee40ebb8c29f41")

