-- Lua provided by RyzenAPI
-- Game: Observe

-- MAIN APPLICATION
addappid(3681230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3681231,0,"b5c4dc3c5356c6837ead8da91296ebd3b8f1ae10bf36ca4200ee40ebb8c29f41")

