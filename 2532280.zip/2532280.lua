-- Lua provided by RyzenAPI
-- Game: 命定奇谭 Demo

-- MAIN APPLICATION
addappid(2532280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532281, 1, "065b4742c76452cdef688259aa5d7ed74bec948bdd63ed1d153f4672206a7789")
