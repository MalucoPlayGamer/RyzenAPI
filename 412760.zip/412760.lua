-- Lua provided by RyzenAPI
-- Game: Revolve

-- MAIN APPLICATION
addappid(412760)
addappid(495620)

-- MAIN APP DEPOTS / PACKAGES
addappid(412761, 1, "4ebe9f0dc5c0152c7cab1a8c2a41ea2ae4cf0192213e17ec28d75e3f77a74876")

