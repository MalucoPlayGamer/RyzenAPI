-- Lua provided by RyzenAPI
-- Game: Strawberry Vinegar

-- MAIN APPLICATION
addappid(407340)
-- Game: addappid(407340)

-- MAIN APP DEPOTS / PACKAGES
addappid(407341, 1, "c3b8fac604473da599d7d153685e18e21df7cdb6448fa0e575298b7941b8edb9")
