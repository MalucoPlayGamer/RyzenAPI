-- 4235410's Lua and Manifest Created by Hubcap Manifest
-- Future Knight
-- Created: August 14, 2026 at 00:44:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4235410) -- Future Knight
-- MAIN APP DEPOTS
addappid(4235411, 1, "07935a5e63ff8e00760974d69ac9ac9bea217c96ae93549af71643f5062abefc") -- Depot 4235411
setManifestid(4235411, "5073152241512169235", 3540038555)