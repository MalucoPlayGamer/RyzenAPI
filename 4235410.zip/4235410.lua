-- Lua provided by RyzenAPI
-- Game: Future Knight

-- MAIN APPLICATION
addappid(4235410) -- Future Knight

-- MAIN APP DEPOTS / PACKAGES
addappid(4235411, 1, "07935a5e63ff8e00760974d69ac9ac9bea217c96ae93549af71643f5062abefc") -- Depot 4235411

