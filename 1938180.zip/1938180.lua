-- Lua provided by RyzenAPI
-- Game: Game: AppID 1938180

-- MAIN APPLICATION
addappid(1938180)
-- Game: addappid(1938180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938181, 1, "b11d3230c66030e0bf945bfcdb0a58acd05c96410d6dc2632083b4afc4bb15e2")
