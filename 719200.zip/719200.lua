-- Lua provided by RyzenAPI 
-- Game: AppID 719200
addappid(719200)
addappid(719201, 1, "3f4078214f36bdafa7ad5c9709e55606be8ca7de1e5a72731da1551d8a13f9ee")
addappid(719202, 1, "57df4c46af84a9297a729d2545f94621786f50a13d782248d5de363377d77048")
