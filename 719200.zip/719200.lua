-- Lua provided by RyzenAPI
-- Game: AppID 719200

-- MAIN APPLICATION
addappid(719200)

-- MAIN APP DEPOTS / PACKAGES
addappid(719201, 1, "3f4078214f36bdafa7ad5c9709e55606be8ca7de1e5a72731da1551d8a13f9ee")
addappid(719202, 1, "57df4c46af84a9297a729d2545f94621786f50a13d782248d5de363377d77048")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
