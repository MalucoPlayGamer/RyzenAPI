-- Lua provided by RyzenAPI
-- Game: EreaDrone

-- MAIN APPLICATION
addappid(1301060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1301061, 1, "81715e4a82cae3fe43237e9956d7bc7930e5fb4cdf61155424f612e1f96ce607")
