-- Lua provided by RyzenAPI
-- Game: Game: AppID 1301060

-- MAIN APPLICATION
addappid(1301060)
-- Game: addappid(1301060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301061, 1, "81715e4a82cae3fe43237e9956d7bc7930e5fb4cdf61155424f612e1f96ce607")
