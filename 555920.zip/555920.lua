-- Lua provided by RyzenAPI
-- Game: AppID 555920

-- MAIN APPLICATION
addappid(555920)

-- MAIN APP DEPOTS / PACKAGES
addappid(555921, 1, "cd2d72645afbfcfc3de52a63a71255f52f9a3090539efa0ce26945cd75e164fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
