-- Lua provided by RyzenAPI
-- Game: AppID 555920

-- MAIN APPLICATION
addappid(555920)

-- MAIN APP DEPOTS / PACKAGES
addappid(555921, 1, "cd2d72645afbfcfc3de52a63a71255f52f9a3090539efa0ce26945cd75e164fd")
