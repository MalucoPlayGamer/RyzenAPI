-- Lua provided by RyzenAPI
-- Game: Black plane

-- MAIN APPLICATION
addappid(2811280)
-- Game: addappid(2811280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811281, 1, "665ea977a62f8c8b7261f53535dd521844f4784540ca7f50062543b364a0745f")
