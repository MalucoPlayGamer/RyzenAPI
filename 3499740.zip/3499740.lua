-- Lua provided by RyzenAPI
-- Game: Gunsmith Simulator - Fabryka Broni DLC

-- MAIN APPLICATION
addappid(3499740)
-- Game: addappid(3499740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499740,0,"63a9d9fe6089d6fbce2643a0960797b4771b2f47bc22d24e96e0fa1702495095")
