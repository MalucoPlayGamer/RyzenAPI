-- Lua provided by RyzenAPI
-- Game: Vitality Girl

-- MAIN APPLICATION
addappid(1611270)
addappid(1614170)
addappid(1614171)
addappid(1614172)
addappid(1614173)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611271, 1, "82f73262f49be092be4dc3cd51e0ca19d3cb8e3487c0bc2ec82c1893a6e78767")

