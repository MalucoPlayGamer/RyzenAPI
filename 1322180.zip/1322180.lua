-- Lua provided by RyzenAPI
-- Game: DriftZ

-- MAIN APPLICATION
addappid(1322180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322181, 1, "d211d2dbdb88c47621c210ad1976926d58cddff93d6987952bf6001ea344b8b1")
