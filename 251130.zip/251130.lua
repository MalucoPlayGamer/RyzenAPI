-- Lua provided by RyzenAPI
-- Game: AppID 251130

-- MAIN APPLICATION
addappid(251130)
-- Game: addappid(251130)

-- MAIN APP DEPOTS / PACKAGES
addappid(251131, 1, "892cd242a12aa38e788f3d345a617ac421ada30d4ce3c019b10df74db1664f8c")
