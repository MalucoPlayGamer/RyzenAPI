-- Lua provided by RyzenAPI
-- Game: Chroma Squad

-- MAIN APPLICATION
addappid(251130)
addappid(363800)
addappid(363801)
addappid(363802)
addappid(810600)

-- MAIN APP DEPOTS / PACKAGES
addappid(251131, 1, "892cd242a12aa38e788f3d345a617ac421ada30d4ce3c019b10df74db1664f8c")
