-- Lua provided by RyzenAPI
-- Game: Rally Arcade Classics

-- MAIN APPLICATION
addappid(2837580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837581, 1, "4f37dcd252adb9a3243c0605ec189c34b2988ea39176039d9eb76e8a9da4209c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
