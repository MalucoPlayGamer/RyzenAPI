-- Lua provided by SkyAPI 
-- Game: Rally Arcade Classics
addappid(2837580)
addappid(2837581, 1, "4f37dcd252adb9a3243c0605ec189c34b2988ea39176039d9eb76e8a9da4209c")
