-- Lua provided by RyzenAPI
-- Game: Game: Sector 404

-- MAIN APPLICATION
addappid(3431930)
-- Game: addappid(3431930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431931, 1, "1e3c44da743d96635cbfbd6f0d46e6c2459a9f725a2adf386b34551b9476baa0")
