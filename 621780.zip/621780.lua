-- Lua provided by RyzenAPI
-- Game: Virtually Impossible

-- MAIN APPLICATION
addappid(621780)

-- MAIN APP DEPOTS / PACKAGES
addappid(621781,0,"c0b7672a0654d27d4e0d8383a68961a77d62cf710485b8d77f6b161273cc9487")

