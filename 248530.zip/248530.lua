-- Lua provided by RyzenAPI
-- Game: Depth Hunter 2: Deep Dive

-- MAIN APPLICATION
addappid(248530)

-- MAIN APP DEPOTS / PACKAGES
addappid(248531, 1, "bb6a1dce1d26d38e65ee143d89ee324805ee8aed647ceed128cbd0b68620c67c")
addappid(321510, 0, "e7dc6823e46ff04fd4746998a59ad4c32de1b0fe28bb038cddc5e45e829e2fbe")
addappid(331300, 0, "bbfd7ec6fc40d0ef771c2ebdca7f91c179863b24d65766d4d427b19d44f32b48")
addappid(361880, 0, "86c80f41212a60ef12b5cda8b3a118e628cd378bdc1845e30fed4de8cfdab8e6")
