-- Lua provided by RyzenAPI
-- Game: Game: Ninja Ming: Novice Area

-- MAIN APPLICATION
addappid(1504140)
-- Game: addappid(1504140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504141, 1, "3d8f8427a68323968aac609a94bf3191e94c0a37d4fd28c346ef064b0caf01d5")
