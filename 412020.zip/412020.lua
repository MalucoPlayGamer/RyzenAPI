-- Lua provided by RyzenAPI
-- Game: Metro Exodus

-- MAIN APPLICATION
addappid(412020)
addappid(924220)

-- MAIN APP DEPOTS / PACKAGES
addappid(412021, 1, "f06003bf9aba2630c97f3f84b80f14067b0df94fb9bfabadcbaea93e1ae4c6f7")
addappid(412022, 1, "fdaa0cc6fe8207b1742e3d1fe9b0c62fc848da589cba441eef409d816d6aa775")
addappid(412023, 1, "2d1188fda4fe6c142425d0a9c34f0e6353e5b09eaf0f9967995ecc2948af10f8")
addappid(412024, 1, "45161252e073acc402c8cb3c9227484c10aa4f205f1e709294d2c220f6241ded")
addappid(889920, 0, "0c8376c99ff46438fef56701e400b882822dd57b5d292398e222228f628849a6")
addappid(889921, 0, "ba6a1b0ca33f2370d28d58adc6b53ed79d5fb88d1931130c96ecf95df0530ae2")
addappid(889922, 0, "8bed7c94e8395e6a090d72ce60b7048ef9995126be4d7c04896c25ed74382608")
addappid(889923, 0, "2853b589418e3e2cdbe78e9e851ac23e54a9f14bef73641a0309f59f4d4f37d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
