-- Lua provided by RyzenAPI
-- Game: Chrono CCG

-- MAIN APPLICATION
addappid(4221310)
