-- Lua provided by SkyAPI 
-- Game: Dream Rhythm
addappid(3115500)
addappid(3115501, 1, "85837d885afd917e836f20a5bed8822bfb9438e8babeb30e6dff1fc24174ddc0")
