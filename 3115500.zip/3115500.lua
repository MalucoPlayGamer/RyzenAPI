-- Lua provided by RyzenAPI
-- Game: Game: Dream Rhythm

-- MAIN APPLICATION
addappid(3115500)
-- Game: addappid(3115500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115501, 1, "85837d885afd917e836f20a5bed8822bfb9438e8babeb30e6dff1fc24174ddc0")
