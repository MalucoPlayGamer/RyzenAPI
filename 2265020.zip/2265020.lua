-- Lua provided by RyzenAPI
-- Game: Dark Desire Mute 1

-- MAIN APPLICATION
addappid(2265020)
-- Game: addappid(2265020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265021, 1, "efb1e60a27aef54c316621dad192cea20a2471db509ea014f5d58c6a831fe951")
