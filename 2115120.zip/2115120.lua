-- Lua provided by RyzenAPI
-- Game: Pedal to the Metal

-- MAIN APPLICATION
addappid(2115120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2115121, 1, "c4a45ad447a7b3dfb46d801f3d6387949ec0e355217b317df73865a8d8acc2e1")

