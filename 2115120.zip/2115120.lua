-- Lua provided by RyzenAPI
-- Game: 2115120

-- MAIN APPLICATION
addappid(2115120)
-- Game: addappid(2115120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115121, 1, "c4a45ad447a7b3dfb46d801f3d6387949ec0e355217b317df73865a8d8acc2e1")
