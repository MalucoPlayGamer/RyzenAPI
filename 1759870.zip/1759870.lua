-- Lua provided by RyzenAPI
-- Game: The Repair House

-- MAIN APPLICATION
addappid(1759870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759871, 1, "ee3e21ade19caa7bca67650081915922af9fc3f92e4305e5764765dff391d018")
