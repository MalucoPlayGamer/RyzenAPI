-- Lua provided by RyzenAPI
-- Game: addappid(1200870)

-- MAIN APPLICATION
addappid(1200870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200871, 1, "50e2bbad6edad9418afde43f9dae44aa97f40a9466766b200a5f04a508202232")
