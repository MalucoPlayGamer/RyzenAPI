-- Lua provided by RyzenAPI
-- Game: AppID 645630

-- MAIN APPLICATION
addappid(645630)

-- MAIN APP DEPOTS / PACKAGES
addappid(645631, 1, "73f7f7288bbb1a2ad499ae870ac6bf3174c5e13651f4ff7299c711e9e3458c5b")
addappid(645632, 1, "c8056b5b3d56a5cef604f29196951d34b791229da6270e256cc72169298b334b")
addappid(645633, 1, "becf4ef2055c5c50ca14090f22413e8072cc46870cc031d9c8071f393573754c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(672270)
addappid(672271)
addappid(710430)
addappid(717490)
addappid(754920)
addappid(754921)
addappid(754922)
addappid(754923)
addappid(783150)
addappid(799950)
addappid(868280)
addappid(947930)
addappid(987050)
addappid(1019540)
addappid(1125210)
addappid(1215050)
addappid(1265620)
addappid(1710610)
addappid(1851590)
addappid(1851591)
addappid(1966190)
