-- Lua provided by RyzenAPI
-- Game: Game: Horny Villa

-- MAIN APPLICATION
addappid(2903690)
-- Game: addappid(2903690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903691, 1, "de70048cccd6cf0c67f3f8907f6073dd0c5bbff72e1733ed341d6af4c0be4a09")
