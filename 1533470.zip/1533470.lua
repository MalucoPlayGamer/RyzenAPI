-- Lua provided by RyzenAPI
-- Game: addappid(1533470)

-- MAIN APPLICATION
addappid(1533470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533471, 1, "6a1c215a4b81d0d85b58b0d9a4a7c991d2a0296f245ee014e93bc0089e8c6686")
