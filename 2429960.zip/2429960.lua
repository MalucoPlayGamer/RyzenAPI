-- Lua provided by RyzenAPI
-- Game: Forwards

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2429960)
-- Game: addappid(2429960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429962,0,"94d4e9130d1406bcfefad605fa87aca4b9f3d202b3dcfeb65379f98c98799e15")
