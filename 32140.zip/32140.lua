-- Lua provided by RyzenAPI 
-- Game: Midnight Mysteries
addappid(32140)
addappid(32141, 1, "989032f4533bf0efebf2a61b29561ddd4e59a8994aeffefcd6456c774967bbe1")
