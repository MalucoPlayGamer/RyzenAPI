-- Lua provided by RyzenAPI
-- Game: Game: Midnight Mysteries

-- MAIN APPLICATION
addappid(32140)
-- Game: addappid(32140)

-- MAIN APP DEPOTS / PACKAGES
addappid(32141, 1, "989032f4533bf0efebf2a61b29561ddd4e59a8994aeffefcd6456c774967bbe1")
