-- Lua provided by RyzenAPI
-- Game: Horror Night

-- MAIN APPLICATION
addappid(1721350)
addappid(1991540)
addappid(2097420)
addappid(2097440)
addappid(2100670)
addappid(2181200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1721351, 1, "7a20cddfe04675e8fc95ab4e9061e1fbceec6ed8f039d842a68a234f6241f1e3")

