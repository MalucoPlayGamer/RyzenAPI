-- Lua provided by RyzenAPI
-- Game: Horror Night

-- MAIN APPLICATION
addappid(1721350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721351, 1, "7a20cddfe04675e8fc95ab4e9061e1fbceec6ed8f039d842a68a234f6241f1e3")

