-- 4135380's Lua and Manifest Created by Hubcap Manifest
-- Wink Out
-- Created: July 26, 2026 at 12:38:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4135380, 1, "bf4783e40aea3915e444412af749a5b91f1e339657852c3a113f1405673fde25") -- Wink Out
-- MAIN APP DEPOTS
addappid(4135381, 1, "8d8cfaf0044c6ecc25085f445e10a043d36c53c49232fee42d51ea619364e1f5") -- Depot 4135381
setManifestid(4135381, "3494159949673046278", 1275662850)