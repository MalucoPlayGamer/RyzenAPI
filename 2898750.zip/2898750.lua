-- Lua provided by RyzenAPI 
-- Game: BobasQuest
addappid(2898750)
addappid(2898751, 1, "35d298e3c83a603280d2646e414d129eda50e058ba07980ffca6c7632a11ee15")
