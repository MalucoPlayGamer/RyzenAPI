-- Lua provided by RyzenAPI
-- Game: BobasQuest

-- MAIN APPLICATION
addappid(2898750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898751, 1, "35d298e3c83a603280d2646e414d129eda50e058ba07980ffca6c7632a11ee15")
