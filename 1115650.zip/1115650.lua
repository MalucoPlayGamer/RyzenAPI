-- Lua provided by RyzenAPI
-- Game: 1115650

-- MAIN APPLICATION
addappid(1115650)
-- Game: addappid(1115650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115651, 1, "7ae51993e327c19a961dddd02a539cfa340bc92d8b36bd1c6bda88d8256e7524")
