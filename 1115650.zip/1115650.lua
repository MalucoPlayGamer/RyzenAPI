-- Lua provided by SkyAPI 
-- Game: AppID 1115650
addappid(1115650)
addappid(1115651, 1, "7ae51993e327c19a961dddd02a539cfa340bc92d8b36bd1c6bda88d8256e7524")
