-- Lua provided by RyzenAPI
-- Game: NTR Massage & Betrayal

-- MAIN APPLICATION
addappid(3772880)
-- Game: addappid(3772880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772882,0,"1a179401330f46b3b327e16659d4021415627b1af7907364e986d25daa4076a2")
