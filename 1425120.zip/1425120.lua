-- Lua provided by RyzenAPI
-- Game: Clutter Evolution: Beyond Xtreme

-- MAIN APPLICATION
addappid(1425120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425121, 1, "d8bb62474cf3caf3e07981015de3ddb115e33193c744b59df9593a907f4ce6f9")

