-- Lua provided by RyzenAPI
-- Game: Pursuer

-- MAIN APPLICATION
addappid(1013660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013661, 1, "cb4282efe9526bee4c8f933dacc6ee7ee504e8f341fae46fc9e0501f05881ae2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
