-- Lua provided by RyzenAPI
-- Game: 1013660

-- MAIN APPLICATION
addappid(1013660)
-- Game: addappid(1013660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013661, 1, "cb4282efe9526bee4c8f933dacc6ee7ee504e8f341fae46fc9e0501f05881ae2")
