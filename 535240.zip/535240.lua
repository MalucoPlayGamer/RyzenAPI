-- Lua provided by RyzenAPI
-- Game: Landmine Larry

-- MAIN APPLICATION
addappid(535240)

-- MAIN APP DEPOTS / PACKAGES
addappid(535241,0,"3e2f5696da2cf9d53ff4ba9e9857b7239a01a87a23890700db6cd713e65b3b01")

