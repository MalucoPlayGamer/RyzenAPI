-- Lua provided by RyzenAPI 
-- Game: AppID 344630
addappid(344630)
addappid(344631, 1, "843fdc8e96a24661972f7bba75f590d11bdfc273adf879663aea488af4ffeafd")
