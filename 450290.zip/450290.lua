-- Lua provided by RyzenAPI
-- Game: Game: Assault on Arnhem

-- MAIN APPLICATION
addappid(450290)
-- Game: addappid(450290)

-- MAIN APP DEPOTS / PACKAGES
addappid(450291, 1, "6c6cd4ce00bb9b4a6b6daeb25134801ed7b970c9ad97603e48c8cea0f12af0f3")
