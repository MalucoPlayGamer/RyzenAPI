-- Lua provided by SkyAPI 
-- Game: Assault on Arnhem
addappid(450290)
addappid(450291, 1, "6c6cd4ce00bb9b4a6b6daeb25134801ed7b970c9ad97603e48c8cea0f12af0f3")
