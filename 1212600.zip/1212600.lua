-- Lua provided by RyzenAPI
-- Game: Budo War Girl:maid of desire

-- MAIN APPLICATION
addappid(1212600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212601, 1, "361ac9f19cb246f06b278797776b4289516f349a2a8666997998dce50d113f51")

