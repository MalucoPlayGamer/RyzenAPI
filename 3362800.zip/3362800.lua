-- Lua provided by RyzenAPI
-- Game: Project Neon

-- MAIN APP DEPOTS / PACKAGES
addappid(3362800, 1, "8c9f173723f6759e783b9323adeb4afac76ec10529ae00ffc6162d72af269126") -- Project Neon
addappid(3362802, 1, "67ddd59b783884f602f3fb7fc5822590c4414246c8e4368f835b9addce4bb1a4") -- Depot 3362802
addappid(3362803, 1, "a61bb2505c96a5b4aab645e554b3436e9d8acbb9587fe8bd3fd931c48c8b9953") -- Depot 3362803
addappid(3362804, 1, "2e8e7f412c27e1c4fe4f283fc780493ad8f4bfd6ec4603d5679f26f387ca3c36") -- Depot 3362804

