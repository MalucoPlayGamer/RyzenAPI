-- 2700990's Lua and Manifest Created by Hubcap Manifest
-- Rogue Piñatas: VRmageddon
-- Created: July 28, 2026 at 11:33:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2700990) -- Rogue Piñatas: VRmageddon
-- MAIN APP DEPOTS
addappid(2700991, 1, "f5d36db0c6659206fdc09cf50253db75972977dfc86b8d52d11f8012a4e18352") -- Depot 2700991
setManifestid(2700991, "6352768459842950121", 2115386284)