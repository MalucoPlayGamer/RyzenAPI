-- Lua provided by RyzenAPI
-- Game: Aotenjo: Infinite Hands

-- MAIN APPLICATION
addappid(3066570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3066571, 1, "3a0d81046c1bd184184fde7c181a9e705d2a78580deef1c427be4392d9e5558f")
