-- Lua provided by RyzenAPI
-- Game: Foul Play

-- MAIN APPLICATION
addappid(244810)

-- MAIN APP DEPOTS / PACKAGES
addappid(244811, 1, "2df4f4990eb02cb301f5929046c8740a041d0546b632d7b9ee0761b6139c02c7")
addappid(244812, 1, "ac4eb4c3c715dae8995a5f091d3942b4c2f9cd38543a965ef2076f1e63362828")
addappid(244813, 1, "46b3ff187959b4b87761e8ecdd45f396b67a6b1034a90ad45e912d926bd962b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
