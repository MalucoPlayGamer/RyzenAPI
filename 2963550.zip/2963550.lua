-- Lua provided by RyzenAPI
-- Game: Game of Fate: Chasing Through Time

-- MAIN APPLICATION
addappid(2963550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963552,0,"9806244e6731e75985e09bf1923f1be479cfecf397369c7541d0445150e9ea05")
addappid(2963553,0,"c64b2b62154a9e7ac6f32b3bff9bedc1e32f8c6186e743a6125a389ffef50843")

