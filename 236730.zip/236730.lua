-- Lua provided by RyzenAPI
-- Game: Anomaly 2

-- MAIN APPLICATION
addappid(236730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(236731, 1, "c32209eafcb06ed627834bfbc91b499f975a62bedceac5f23c2538473726eb3a")
addappid(236732, 1, "1ebae66663757bd8e1f5a2185ada5bd648267626f028b7a3fafc382aba3d38eb")
addappid(236733, 1, "a7630c4822c5c0fdbe61388b58408ecb7e80841b342061a17384de0aef9e7429")
addappid(236734, 1, "ecca2ebbebd0d519dfc3f34879689520c1be0e52cc8486979801062cf4d4f13e")

