-- Lua provided by RyzenAPI 
-- Game: Gift
addappid(2322900)
addappid(2322901, 1, "6e22e1aafbc2e531d90759a0ef2f516f08460b3a4b000cc29c4d8ba69f5aaaab")
