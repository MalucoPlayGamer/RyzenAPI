-- Lua provided by RyzenAPI
-- Game: Wet Dog Corp

-- MAIN APPLICATION
addappid(1033960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1033961, 1, "48dbd18eaa43c47fad4605aa7ee9dd63bd475a0c3403e091d6e9108b30885cf6")

