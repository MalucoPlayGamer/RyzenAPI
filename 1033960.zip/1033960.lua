-- Lua provided by RyzenAPI
-- Game: 1033960

-- MAIN APPLICATION
addappid(1033960)
-- Game: addappid(1033960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033961, 1, "48dbd18eaa43c47fad4605aa7ee9dd63bd475a0c3403e091d6e9108b30885cf6")
