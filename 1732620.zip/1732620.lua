-- Lua provided by RyzenAPI 
-- Game: Tame It! Demo
addappid(1732620)
addappid(1732621, 1, "d71e69fa93f97741173692c2c8893f5ed764cde68f6a021ed125d84d08b653d0")
