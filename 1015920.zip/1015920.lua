-- Lua provided by SkyAPI 
-- Game: Ynglet
addappid(1015920)
addappid(1015921, 1, "370975654d7b6069facebf2c99223e97e5aae541755f2e3b7b3bc1f60832cd0e")
addappid(1015922, 1, "2f2be174157d6bcb74d029e34aab4c41b0d7a5016d4910504090cbea182cf861")
