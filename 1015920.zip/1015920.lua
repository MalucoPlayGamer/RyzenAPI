-- Lua provided by RyzenAPI
-- Game: Ynglet

-- MAIN APPLICATION
addappid(1015920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015921, 1, "370975654d7b6069facebf2c99223e97e5aae541755f2e3b7b3bc1f60832cd0e")
addappid(1015922, 1, "2f2be174157d6bcb74d029e34aab4c41b0d7a5016d4910504090cbea182cf861")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
