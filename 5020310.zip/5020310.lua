-- Lua provided by RyzenAPI
-- Game: Dub Together

-- MAIN APP DEPOTS / PACKAGES
addappid(5020310, 1, "197987c22c72289c7864f63ed323534c10c2c5eb85f9e6c11e9d7f7cc2219645")
addappid(5020311, 1, "05c7d6a73b5822cf18dba1c5e689d1f3cf7133b89b337c4b6ee5d6fbebd406e7")
