-- Lua provided by RyzenAPI
-- Game: 863400

-- MAIN APPLICATION
addappid(863400)
-- Game: addappid(863400)

-- MAIN APP DEPOTS / PACKAGES
addappid(863402,0,"e323d76d2a4f90da6a574fa410ade700a27b29ce44786603c4959c974091946a")
