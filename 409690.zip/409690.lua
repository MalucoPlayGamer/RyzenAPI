-- Lua provided by RyzenAPI
-- Game: Pink Heaven

-- MAIN APPLICATION
addappid(409690)

-- MAIN APP DEPOTS / PACKAGES
addappid(409691, 1, "44a6987df7ad2f6cd95f9df34801683f7b1da0d220b0107a5d330afcd9719494")
addappid(409692, 1, "263c13b52662090accdec2fdbe6d64381a8a598ff11668d8d10ce312bdc052da")
