-- Lua provided by RyzenAPI
-- Game: Pink Heaven

-- MAIN APPLICATION
addappid(409690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409691, 1, "44a6987df7ad2f6cd95f9df34801683f7b1da0d220b0107a5d330afcd9719494")
addappid(409692, 1, "263c13b52662090accdec2fdbe6d64381a8a598ff11668d8d10ce312bdc052da")

