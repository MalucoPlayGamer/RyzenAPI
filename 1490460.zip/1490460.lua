-- Lua provided by RyzenAPI
-- Game: 1490460

-- MAIN APPLICATION
addappid(1490460)
-- Game: addappid(1490460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490461, 1, "38e7e8ec5d0adf8c67fa976da95e989317e09c9b8146b692050122ff1f1917ef")
