-- Lua provided by SkyAPI 
-- Game: Hero of the Kingdom: The Lost Tales 3
addappid(3340810)
addappid(3340811, 1, "0e42e8c660d00fe7dbccd97f38c1ba5b7b54dd1c2950ab2dd19c573a4dd75d7c")
addappid(3340812, 1, "1869de18d16e42bd67d798196dac85c31ca606aab719d5e1b05ef14fde5a0564")
