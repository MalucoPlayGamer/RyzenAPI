-- Lua provided by RyzenAPI
-- Game: Game: Hero of Not Our Time

-- MAIN APPLICATION
addappid(1409730)
-- Game: addappid(1409730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409731, 1, "e78eb6eae99330829f667f0594f4e036b94cb87870de7ca6df50eb7f49828dc0")
