-- Lua provided by RyzenAPI
-- Game: addappid(1496590)

-- MAIN APPLICATION
addappid(1496590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496591, 1, "1f61ec6f4b3df4704e9d01ee719ee6c0ac3e81e5c4ef2fe2d4c63c4045f1677b")
