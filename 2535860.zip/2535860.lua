-- Lua provided by RyzenAPI
-- Game: 2535860

-- MAIN APPLICATION
addappid(2535860)
-- Game: addappid(2535860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535861, 1, "035f3b2ed2daff3fbd25cf824616e5bb4a004be4851d768c6682fc8f060c79b9")
