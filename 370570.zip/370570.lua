-- Lua provided by RyzenAPI
-- Game: Color Assembler

-- MAIN APPLICATION
addappid(370570)
-- Game: addappid(370570)

-- MAIN APP DEPOTS / PACKAGES
addappid(370571, 1, "3e140628286e24803f2f5f365cdc330f376b1bde67917349754a988326ab14a1")
