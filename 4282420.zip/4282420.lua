-- Lua provided by RyzenAPI
-- Game: Anomaly 404

-- MAIN APPLICATION
addappid(4282420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4282421,0,"e9f2711645bcf01d16dec4504032fc1f09a35d66eb39531daba4805f572f1258")

