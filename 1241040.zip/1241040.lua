-- Lua provided by RyzenAPI
-- Game: Deep Despair

-- MAIN APPLICATION
addappid(1241040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241041, 1, "8f578f4eede85b6086ce4f4ff77bc8d244efdbdca38969bd36392c4940baae43")
