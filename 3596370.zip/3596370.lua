-- Lua provided by SkyAPI 
-- Game: Bearly Escape
addappid(3596370)
addappid(3596371, 1, "aef848ca683bd872dd3f7cdf81b45fa14cd4591fcf62c9104c82480af93e389d")
