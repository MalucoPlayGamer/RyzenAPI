-- Lua provided by RyzenAPI
-- Game: NEKOPARA Vol. 4

-- MAIN APPLICATION
addappid(1406990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1406991, 1, "3a788925e3104dac2a37bd06c1889d4de6ed05d62e672b9f9283f07fd45e3f4c")

