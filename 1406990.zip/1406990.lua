-- Lua provided by RyzenAPI
-- Game: Game: NEKOPARA Vol. 4

-- MAIN APPLICATION
addappid(1406990)
-- Game: addappid(1406990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406991, 1, "3a788925e3104dac2a37bd06c1889d4de6ed05d62e672b9f9283f07fd45e3f4c")
