-- Lua provided by RyzenAPI
-- Game: 1406040

-- MAIN APPLICATION
addappid(1406040)
addappid(1406041)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406042,0,"62cda6f0da50a2e250e8c2909d5bd099dd2fe01ee09c7f046fe2382ddd8916e5")
