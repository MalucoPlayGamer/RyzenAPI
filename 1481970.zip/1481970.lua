-- Lua provided by RyzenAPI
-- Game: Drugs and Crime Idle

-- MAIN APPLICATION
addappid(1481970)
-- Game: addappid(1481970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481971, 1, "92b6f29c08845be3263130bc58f5c4b4ca86e3b9692b105079db135a36aa798c")
