-- Lua provided by RyzenAPI
-- Game: Drugs and Crime Idle

-- MAIN APPLICATION
addappid(1481970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481971, 1, "92b6f29c08845be3263130bc58f5c4b4ca86e3b9692b105079db135a36aa798c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1497960)
addappid(1581570)
