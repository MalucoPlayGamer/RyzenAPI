-- Lua provided by RyzenAPI
-- Game: Witch of Mystery Tower

-- MAIN APPLICATION
addappid(1587290)
-- Game: addappid(1587290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587291, 1, "5f0345992f7c3872df56931323405a81ac3ecfbca78fe1f3a01bd01d877e9ec1")
