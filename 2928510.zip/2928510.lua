-- Lua provided by RyzenAPI
-- Game: Interior Designer Demo

-- MAIN APPLICATION
addappid(2928510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928511, 1, "42d2a1de4c5b175996bfdd24ccb396ea9aab744294ae4715eb09d997b411bc82")
