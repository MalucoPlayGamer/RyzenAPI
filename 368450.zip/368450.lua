-- Lua provided by RyzenAPI
-- Game: Game: Rememoried

-- MAIN APPLICATION
addappid(368450)
-- Game: addappid(368450)

-- MAIN APP DEPOTS / PACKAGES
addappid(368451, 1, "10db67018f1a69aa4a9b4832ea700f48466eae097551e040a2f7884b7d1efeac")
addappid(368452, 1, "93da593016b90134c8be283603f649f1c02f3e2d0f28e691bc37393126d30b65")
addappid(368453, 1, "b8626dcaad6d26513682b34cc040e5ed93a0828094ecbd60bc3f55da22d57a59")
