-- 2431080's Lua and Manifest Created by Hubcap Manifest
-- Blood Dungeon
-- Created: August 25, 2026 at 13:14:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2431080, 1, "b3e215373312641b39fd5ef060df59fb68565a77a209f704c72659741ea56dc8") -- Blood Dungeon
-- MAIN APP DEPOTS
addappid(2431081, 1, "fb7b21faa7c8f33d480383f6200d6ebae5239c30d74b9ab44b91662c23f513e9") -- Depot 2431081
setManifestid(2431081, "5276516059476547001", 169690361)
addappid(2431082, 1, "565d4cb4a2b5c117a815a5a26f17a7a58f33068db805113ba958a675b2998618") -- Depot 2431082
setManifestid(2431082, "642016113876278905", 214522097)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)