-- Lua provided by RyzenAPI
-- Game: Blood Dungeon

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(2431080, 1, "b3e215373312641b39fd5ef060df59fb68565a77a209f704c72659741ea56dc8") -- Blood Dungeon
addappid(2431081, 1, "fb7b21faa7c8f33d480383f6200d6ebae5239c30d74b9ab44b91662c23f513e9") -- Depot 2431081
addappid(2431082, 1, "565d4cb4a2b5c117a815a5a26f17a7a58f33068db805113ba958a675b2998618") -- Depot 2431082

