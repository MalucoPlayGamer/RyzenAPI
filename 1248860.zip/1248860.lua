-- Lua provided by RyzenAPI
-- Game: Cuyo

-- MAIN APPLICATION
addappid(1248860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248861, 1, "9bf7befcd8c0302ea2926108eb01a012089bd06642e667db3627d78d31e24b70")
