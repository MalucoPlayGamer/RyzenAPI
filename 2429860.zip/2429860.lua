-- Lua provided by RyzenAPI
-- Game: Game: Living With Sister: Monochrome Fantasy

-- MAIN APPLICATION
addappid(2429860)
-- Game: addappid(2429860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429861, 1, "591782e366a2be7556b05c52c3ebab70bf328172f2277b1fea48b311ac3c8423")
addappid(2429862, 1, "ca36c8d20f6726a752664b377430a930b5579b93916c6a88a475a62391f53425")
addappid(2429863, 1, "90981bee3efdee85d4251d950a4becc37d8433d2e1f0228a8022ae3f4416dc23")
addappid(3155140, 0, "f3c0f43ae4dded6a1c15adbb6cb81d456e280cb4a13c34cf33281784c91f7792")
