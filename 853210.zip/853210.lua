-- Lua provided by RyzenAPI
-- Game: Gopnik Simulator

-- MAIN APPLICATION
addappid(853210)
-- Game: addappid(853210)

-- MAIN APP DEPOTS / PACKAGES
addappid(853211, 1, "adae5f88f9ea2d1ea5904629a26838cce4859af07617efb5a44b66f156f872c9")
addappid(863410, 0, "70fa67f50d54320905f075a16bd4560f45a127ac4c8024561eb8433a00a72ac8")
