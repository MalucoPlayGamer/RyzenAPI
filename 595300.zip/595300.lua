-- Lua provided by RyzenAPI
-- Game: Game: VR2: Vacate 2 Rooms (Virtual Reality Escape)

-- MAIN APPLICATION
addappid(595300)
-- Game: addappid(595300)

-- MAIN APP DEPOTS / PACKAGES
addappid(595301, 1, "06a55c2e6dd42e2fc0747c3d20d113e2ab6a3b741ef3e8e448a4b62683dde4f2")
