-- Lua provided by RyzenAPI
-- Game: Game: Metroplex Zero OST

-- MAIN APPLICATION
addappid(2490780)
-- Game: addappid(2490780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490781, 1, "a07ec4a9b0adaa7b533defeea9123e731d8d8fa27beb569403448e6809fc29a7")
