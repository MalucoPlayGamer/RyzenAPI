-- Lua provided by RyzenAPI 
-- Game: Fishy
addappid(1147750)
addappid(1147751, 1, "42c20adf7d5ac65a124b4290e722cf8e949867a066e2c69a5f3e6939bc03fbbf")
