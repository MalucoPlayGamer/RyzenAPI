-- Lua provided by RyzenAPI
-- Game: Fishy

-- MAIN APPLICATION
addappid(1147750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1147751, 1, "42c20adf7d5ac65a124b4290e722cf8e949867a066e2c69a5f3e6939bc03fbbf")

