-- Lua provided by RyzenAPI
-- Game: Door Kickers: Action Squad Artbook

-- MAIN APPLICATION
addappid(1286400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286400,0,"5b8af095f5b118953eed88d2fbde46207eb5bd40e6eceaeda170d7416224ff25")
