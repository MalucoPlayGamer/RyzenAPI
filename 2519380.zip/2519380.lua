-- Lua provided by RyzenAPI
-- Game: Hentai Devil

-- MAIN APPLICATION
addappid(2519380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519381, 1, "7662af215b1a7b5025becd9ff5bee1515ee857724a29f1437a6d79d678771358")

