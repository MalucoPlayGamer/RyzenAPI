-- Lua provided by RyzenAPI
-- Game: 981430

-- MAIN APPLICATION
addappid(981430)
-- Game: addappid(981430)

-- MAIN APP DEPOTS / PACKAGES
addappid(981431, 1, "f60c5f2079299e20a4a654e1637be4799eea0c3b7cd6a67007eb22e1383a2632")
