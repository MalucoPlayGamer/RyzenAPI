-- Lua provided by RyzenAPI
-- Game: AppID 659500

-- MAIN APPLICATION
addappid(659500)
-- Game: addappid(659500)

-- MAIN APP DEPOTS / PACKAGES
addappid(659501, 1, "73911a1ad02283043694a22715e265ffdd8d39989b9987b8f1bdd19e5ba8f5df")
