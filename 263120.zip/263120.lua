-- Lua provided by SkyAPI 
-- Game: Ludwig
addappid(263120)
addappid(263121, 1, "3266392261946d29de55905e7b70806070220103b64b7529748b860d0e305fdf")
