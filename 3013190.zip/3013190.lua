-- Lua provided by RyzenAPI 
-- Game: MIGLORN
addappid(3013190)
addappid(3013191, 1, "b19441a170b39a7352c74ea8205449a8ed1f2b78e981bb89c6d828157c2b46b3")
