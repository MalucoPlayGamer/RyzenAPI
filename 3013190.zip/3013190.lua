-- Lua provided by RyzenAPI
-- Game: MIGLORN

-- MAIN APPLICATION
addappid(3013190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013191, 1, "b19441a170b39a7352c74ea8205449a8ed1f2b78e981bb89c6d828157c2b46b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
