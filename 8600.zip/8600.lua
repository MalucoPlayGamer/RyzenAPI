-- Lua provided by RyzenAPI
-- Game: Game: RACE 07

-- MAIN APPLICATION
addappid(8600)
-- Game: addappid(8600)

-- MAIN APP DEPOTS / PACKAGES
addappid(8601, 1, "fd988e7496d1ad29e9c6184247db971604fb1182d9d2f4a63f8cbe9bb771cd52")
addappid(8602, 1, "258bbc1baa7e13399d9f1714e14dc28fc56e7afe8105e799b8ffd2d86955a047")
addappid(8612, 1, "df35601d90fac72df2e233e7205f493e312bacdbc634dd0e99f818191197ca03")
addappid(8619, 1, "e2a0fe22927b05d5d4a6b3720432e3e7826f976481b37e963c9d6da5268306a5")
