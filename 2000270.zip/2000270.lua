-- Lua provided by RyzenAPI
-- Game: Dual Universe

-- MAIN APPLICATION
addappid(2000270)
-- Game: addappid(2000270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000271, 1, "7fef8099bb5e23c5d3858f700b2436628176289e85257a44685003a3164a2c11")
