-- Lua provided by RyzenAPI
-- Game: Pop's

-- MAIN APPLICATION
addappid(1693010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693011, 1, "d058b7a34b951e504162f57ab6490aabaed14b7411777b2314a55a93499da27b")

