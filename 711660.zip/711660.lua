-- Lua provided by SkyAPI 
-- Game: CHUCHEL
addappid(711660)
addappid(711661, 1, "f145d70830b86e665e99db50e6d14c892b301885b2920cd4c5dec1436595bd45")
addappid(711662, 1, "01ab8f7000da853a92679eb55afd7950d2d70d2f076122361b4dbc60d33196d8")
