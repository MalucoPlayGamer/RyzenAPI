-- Lua provided by RyzenAPI
-- Game: Sparky Marky: Episode 2

-- MAIN APPLICATION
addappid(2418290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418291, 1, "805ead5d29a90eef5db4da5d338b47776294db2be2fd4904ba9be66950acef29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
