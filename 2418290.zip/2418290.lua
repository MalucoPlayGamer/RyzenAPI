-- Lua provided by RyzenAPI
-- Game: 2418290

-- MAIN APPLICATION
addappid(2418290)
-- Game: addappid(2418290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418291, 1, "805ead5d29a90eef5db4da5d338b47776294db2be2fd4904ba9be66950acef29")
