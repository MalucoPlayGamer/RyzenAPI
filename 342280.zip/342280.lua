-- Lua provided by RyzenAPI
-- Game: Manyland

-- MAIN APPLICATION
addappid(342280)
-- Game: addappid(342280)

-- MAIN APP DEPOTS / PACKAGES
addappid(342281, 1, "be5f8d4b809d940ad294cd9807f6ced9d00be7ea4b23ea42118c8d948602f3a7")
