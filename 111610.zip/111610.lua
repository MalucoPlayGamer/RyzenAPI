-- Lua provided by RyzenAPI
-- Game: Serious Sam Double D Demo

-- MAIN APPLICATION
addappid(111610)

-- MAIN APP DEPOTS / PACKAGES
addappid(111611, 1, "d9d3639e8d32df28f8780eabc3cb4fcaa05b1dd770857be87437d9350c49e991")
