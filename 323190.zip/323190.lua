-- Lua provided by RyzenAPI
-- Game: Frostpunk

-- MAIN APPLICATION
addappid(323190)

-- MAIN APP DEPOTS / PACKAGES
addappid(323192,0,"a020b20dfff0ee9d478284bcdc73aece3d604e9f969c5a1180b548e7cf19f4c8")
addappid(323193,0,"0ca8f4cb0e93c4fa8b72f4a1c53c7ac952c8b2c4e01bc8514be065739979752e")
addappid(323195,0,"13126647b06df8f1190548232d76a9b5441d742ed1761bb6b184de96cbf68060")
addappid(323197,0,"9b76a91076802cfb56787d5da2d1cafd6cbdcb0ce202b094d549c11cbb6824a6")
addappid(323198,0,"84a0aff2af6cdb25e6a8829d71f979a5c21435831c9f2f9f7268e42e9c8f44d9")
addappid(323199,0,"6cf0d7a2685c284d7a08899f7af5c5ed4a8f9d583f1ee6bec4956566a6a7becd")
addappid(323200,0,"dcd30784ffc0b9f20f14e91fa738de904efa3cd2d960bb2c48de433eb214b514")
addappid(323201,0,"855b23606147b4556219f8c616464b74ae3b4d5564e641b7097ef1eace2dd2fa")
addappid(1103840,0,"39b9683bdb41757636fa51bf8e2227345d0017eebbd39ef24e6e7d9158276bee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1125020)
addappid(1146960)
addappid(1147010)
