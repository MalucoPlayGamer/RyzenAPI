-- Lua provided by SkyAPI 
-- Game: Toree 3D
addappid(1554840)
addappid(1554841, 1, "6f39da6526d9d3d96e827e334f7464e1d067ae945b6e5467583562a202966714")
