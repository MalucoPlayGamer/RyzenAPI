-- Lua provided by RyzenAPI
-- Game: Game: Toree 3D

-- MAIN APPLICATION
addappid(1554840)
-- Game: addappid(1554840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554841, 1, "6f39da6526d9d3d96e827e334f7464e1d067ae945b6e5467583562a202966714")
