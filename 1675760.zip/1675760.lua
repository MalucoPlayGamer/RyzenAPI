-- Lua provided by RyzenAPI
-- Game: AppID 1675760

-- MAIN APPLICATION
addappid(1675760)
-- Game: addappid(1675760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675761, 1, "1e619af3534ffd7d5fba780191b6c7f4d8a4ed483c2bca47253b1c29a8184944")
