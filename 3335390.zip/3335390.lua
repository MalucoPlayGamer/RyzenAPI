-- Lua provided by RyzenAPI
-- Game: Game: Sexbot Lab

-- MAIN APPLICATION
addappid(3335390)
-- Game: addappid(3335390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335391, 1, "86796f8d9a5c441c5418280519a7d55cd5669a57e7f940ea9d0e9a2c64fd8b20")
