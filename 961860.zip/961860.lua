-- Lua provided by RyzenAPI
-- Game: addappid(961860)

-- MAIN APPLICATION
addappid(961860)

-- MAIN APP DEPOTS / PACKAGES
addappid(961861, 1, "dc41ad4cd5a807c7fde62440ea149dd6d903a572023ba5f34f5fa88d035c6293")
