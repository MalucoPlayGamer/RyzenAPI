-- Lua provided by RyzenAPI
-- Game: addappid(2629610)

-- MAIN APPLICATION
addappid(2629610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629611, 1, "f173da7e02f74b4093bb913e8cef91f821dc95e5d030eef4a280eeee08c6a909")
