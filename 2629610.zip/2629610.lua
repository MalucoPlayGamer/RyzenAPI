-- Lua provided by SkyAPI 
-- Game: Maze Maverick
addappid(2629610)
addappid(2629611, 1, "f173da7e02f74b4093bb913e8cef91f821dc95e5d030eef4a280eeee08c6a909")
