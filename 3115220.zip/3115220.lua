-- Lua provided by RyzenAPI
-- Game: Town to City

-- MAIN APPLICATION
addappid(3115220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115221, 1, "2bee0d6f4424d4ab2e390fe00b111e2c779f83a34f8a9fd16984e6edba09f8be")

