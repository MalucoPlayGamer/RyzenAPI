-- Lua provided by SkyAPI 
-- Game: LAB.AR
addappid(2262320)
addappid(2262321, 1, "afd7b8ca6da71dbdace04f97fc87adb9bc9a644be6793dbe894e156cfff1bb9f")
