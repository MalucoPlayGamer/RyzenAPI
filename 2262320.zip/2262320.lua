-- Lua provided by RyzenAPI
-- Game: addappid(2262320)

-- MAIN APPLICATION
addappid(2262320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262321, 1, "afd7b8ca6da71dbdace04f97fc87adb9bc9a644be6793dbe894e156cfff1bb9f")
