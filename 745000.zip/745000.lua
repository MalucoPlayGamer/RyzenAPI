-- Lua provided by RyzenAPI
-- Game: Card Crawl

-- MAIN APPLICATION
addappid(745000)
addappid(745001)

-- MAIN APP DEPOTS / PACKAGES
addappid(745002,0,"3b71f613b9c93636ff6070acabebf336054f57a3e969879cdbadb198ca76a098")
