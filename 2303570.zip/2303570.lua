-- Lua provided by RyzenAPI
-- Game: Crazy Clown

-- MAIN APPLICATION
addappid(2303570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303571, 1, "bdd8dcb115039a742c580a0741dc9f5a07d0384edb38647cfacf407d13ef4614")

