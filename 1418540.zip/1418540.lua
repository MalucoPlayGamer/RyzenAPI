-- Lua provided by RyzenAPI
-- Game: SEARCH PARTY: Director's Cut

-- MAIN APPLICATION
addappid(1418540)
-- Game: addappid(1418540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418541, 1, "91dcdb12bd1ea2113f00f8a0069f30859e7a10ad80cc2459ad63f0ef789fa734")
