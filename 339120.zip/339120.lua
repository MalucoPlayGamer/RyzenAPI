-- Lua provided by RyzenAPI
-- Game: Fork Parker's Holiday Profit Hike

-- MAIN APPLICATION
addappid(339120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(339121, 1, "dfee1e3496b65e310cf1e9edffc82746a26f1e873e70e40d8ee7fffcebbf1467")
addappid(339122, 1, "84ed7b709937ef876e2128235103453d31e35a971a33c85579155badc398b86d")

