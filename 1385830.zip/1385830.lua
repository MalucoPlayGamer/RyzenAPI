-- Lua provided by SkyAPI 
-- Game: MagicalGirl Mimi
addappid(1385830)
addappid(1385831, 1, "318f6336696eea5105b857bf1d1d6a854388b56067fefaed5e2ffd11deaebb4f")
