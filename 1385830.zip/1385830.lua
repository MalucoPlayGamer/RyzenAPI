-- Lua provided by RyzenAPI
-- Game: 1385830

-- MAIN APPLICATION
addappid(1385830)
-- Game: addappid(1385830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385831, 1, "318f6336696eea5105b857bf1d1d6a854388b56067fefaed5e2ffd11deaebb4f")
