-- Lua provided by RyzenAPI
-- Game: COSPLAY LOVE! : Enchanted princess

-- MAIN APPLICATION
addappid(1770820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770821, 1, "5b3d043c3159343dc0834ed809578b35d88313eca0b881cab9edc47af9d30d43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
