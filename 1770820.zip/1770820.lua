-- Lua provided by RyzenAPI
-- Game: COSPLAY LOVE! : Enchanted princess

-- MAIN APPLICATION
addappid(1770820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770821, 1, "5b3d043c3159343dc0834ed809578b35d88313eca0b881cab9edc47af9d30d43")

