-- Lua provided by RyzenAPI
-- Game: addappid(3798520)

-- MAIN APPLICATION
addappid(3798520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3798521, 1, "610c56e9624c44f92557b87fb4e520c207726b68c03a8e5d5a9b13ebf1fc1e77")
