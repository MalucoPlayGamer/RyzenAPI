-- Lua provided by RyzenAPI 
-- Game: Thirsty Suitors
addappid(1617220)
addappid(1617221, 1, "a28a3f7f4cbc6ac9a4f37757e21dee3555ec285c03ca0bc4a9c8990c40463690")
