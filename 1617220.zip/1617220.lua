-- Lua provided by RyzenAPI
-- Game: addappid(1617220)

-- MAIN APPLICATION
addappid(1617220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617221, 1, "a28a3f7f4cbc6ac9a4f37757e21dee3555ec285c03ca0bc4a9c8990c40463690")
