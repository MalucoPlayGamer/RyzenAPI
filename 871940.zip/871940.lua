-- Lua provided by RyzenAPI 
-- Game: BrawlQuest
addappid(871940)
addappid(871941, 1, "ceb5ef144456e6f2653d88697166d99f66bffe1b4fcad3bc37a69f7f352e57d0")
