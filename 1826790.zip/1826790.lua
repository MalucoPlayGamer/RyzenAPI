-- Lua provided by RyzenAPI
-- Game: Blood Nova Demo

-- MAIN APPLICATION
addappid(1826790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826791, 1, "04cec141f88e78c690006181caf680a65652c22b4d29908a98e456b1b635ee99")

