-- Lua provided by RyzenAPI
-- Game: F1® Manager 2024

-- MAIN APPLICATION
addappid(2591280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591281, 1, "e371e0b7a49da6cdcd910edd1f1f9f7eaa93de33884db50e3778ec73f34800b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2934780)
addappid(2934790)
addappid(3205030)
addappid(3205040)
