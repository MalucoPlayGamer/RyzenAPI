-- Lua provided by RyzenAPI
-- Game: 2591280

-- MAIN APPLICATION
addappid(2591280)
-- Game: addappid(2591280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591281, 1, "e371e0b7a49da6cdcd910edd1f1f9f7eaa93de33884db50e3778ec73f34800b2")
