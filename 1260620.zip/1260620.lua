-- Lua provided by RyzenAPI
-- Game: Hentai Fantasy

-- MAIN APPLICATION
addappid(1260620)
addappid(1260621)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260622,0,"7407e1a01fe0ae21fb7ff7c7b3a9f6b74e130c1d6c2d62061b529e662e452971")

