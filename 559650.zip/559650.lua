-- Lua provided by RyzenAPI
-- Game: 559650

-- MAIN APPLICATION
addappid(559650)
-- Game: addappid(559650)

-- MAIN APP DEPOTS / PACKAGES
addappid(559651, 1, "a7187005733a13b0010375c98d113e6ad44bb945f73e3f9d582dc81f88a520ec")
