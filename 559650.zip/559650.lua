-- Lua provided by RyzenAPI
-- Game: Witch It

-- MAIN APPLICATION
addappid(559650)
addappid(639750)
addappid(645870)
addappid(3212440)
addappid(3212450)
addappid(3212460)
addappid(3212470)
addappid(3311600)
addappid(3365350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(559651, 1, "a7187005733a13b0010375c98d113e6ad44bb945f73e3f9d582dc81f88a520ec")
