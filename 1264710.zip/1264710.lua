-- Lua provided by RyzenAPI
-- Game: AppID 1264710

-- MAIN APPLICATION
addappid(1264710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264711, 1, "4a897a7db879588d36357b800d783e7ed104f944548cdcaedce7945bd26ed272")
addappid(2225950, 0, "54dfaaea9941c9f9631ced6bb006da2c4e7e9612fbe5e6a0fedabfb00d292bd5")
addappid(2257530, 0, "dd9800ead2d38720ca309e39d471a398b33689153461a43b79ac131f24ff9231")
addappid(2945780, 0, "67303b9cdca0ca902343f4e43f633c4174ded09b0d2aa16e9e1f9c4aa2239821")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4190270)
addappid(4190290)
