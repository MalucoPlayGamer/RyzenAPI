-- Lua provided by RyzenAPI
-- Game: Mega Man 11

-- MAIN APPLICATION
addappid(742300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(742301, 1, "ec5fcfee2030231a6c7994967b36b24d8b3ecd1194310c1acc0a984b3a404787")
addappid(861200, 0, "82a79626f8c6bf28e07682a92a8effaab043b7aa9396f87d7ecb63ebff5f3fbc")

