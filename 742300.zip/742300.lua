-- Lua provided by RyzenAPI
-- Game: addappid(742300)

-- MAIN APPLICATION
addappid(742300)

-- MAIN APP DEPOTS / PACKAGES
addappid(742301, 1, "ec5fcfee2030231a6c7994967b36b24d8b3ecd1194310c1acc0a984b3a404787")
addappid(861200, 0, "82a79626f8c6bf28e07682a92a8effaab043b7aa9396f87d7ecb63ebff5f3fbc")
