-- Lua provided by RyzenAPI
-- Game: FUSER™ - Daryl Hall & John Oates - "Maneater"

-- MAIN APPLICATION
addappid(1598246)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598246,0,"2a94ecdbbc55c0d512289cd328c16ecd3b08166a8bc5b584965de891ad37cf7a")

