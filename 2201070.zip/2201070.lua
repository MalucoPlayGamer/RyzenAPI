-- Lua provided by RyzenAPI
-- Game: Phylakterion

-- MAIN APPLICATION
addappid(2201070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201071, 1, "643c0461b0c48ef0c6e9d97e9722863ceda566c568080382415a4d44773df574")

