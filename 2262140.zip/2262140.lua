-- Lua provided by RyzenAPI
-- Game: addappid(2262140)

-- MAIN APPLICATION
addappid(2262140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262141, 1, "eb3e99e57e214a0c61c511a3e0399afded22b4afc567ea786975280f1d27e274")
