-- Lua provided by RyzenAPI
-- Game: Game: Parkour Game

-- MAIN APPLICATION
addappid(1554960)
-- Game: addappid(1554960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554961, 1, "4267f0dcc973b35ab94d3493e0eaceb5e38e947b7e4b84a45791acfd1eb6db66")
