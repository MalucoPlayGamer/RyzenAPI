-- Lua provided by RyzenAPI 
-- Game: Parkour Game
addappid(1554960)
addappid(1554961, 1, "4267f0dcc973b35ab94d3493e0eaceb5e38e947b7e4b84a45791acfd1eb6db66")
