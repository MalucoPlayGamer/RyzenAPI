-- Lua provided by RyzenAPI 
-- Game: Space Station Invader VR
addappid(1178480)
addappid(1178481, 1, "300c902e4f4581011f29dca3c646ed5abe146b72a3f61829338df41f23be2ae3")
