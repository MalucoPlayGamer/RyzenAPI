-- Lua provided by RyzenAPI
-- Game: Space Station Invader VR

-- MAIN APPLICATION
addappid(1178480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1178481, 1, "300c902e4f4581011f29dca3c646ed5abe146b72a3f61829338df41f23be2ae3")

