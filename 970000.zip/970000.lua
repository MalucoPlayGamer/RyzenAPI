-- Lua provided by RyzenAPI
-- Game: Puzzles for smart: Horses

-- MAIN APPLICATION
addappid(970000)

-- MAIN APP DEPOTS / PACKAGES
addappid(970001, 1, "55d867ef899126b4c55eb939ba532c2143c9f6ddcd253900aa47ae24f6d58fec")
