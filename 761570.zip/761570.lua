-- Lua provided by RyzenAPI
-- Game: Beard & Axe

-- MAIN APPLICATION
addappid(761570)

-- MAIN APP DEPOTS / PACKAGES
addappid(761571,0,"7cb6c60fc2a46578cc0ee2c21f686f5192605d8a844dcd5c6bd8594f0a5b43be")

