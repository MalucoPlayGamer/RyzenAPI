-- Lua provided by RyzenAPI
-- Game: 1161490

-- MAIN APPLICATION
addappid(1161490)
addappid(1176700)
-- Game: addappid(1161490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161491, 1, "4cb6b10470f48d200134fdef9687805d97b7aabdbab2b7a6d3c27c87ab1f3cab")
