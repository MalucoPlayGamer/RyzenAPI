-- Lua provided by RyzenAPI
-- Game: AppID 879050

-- MAIN APPLICATION
addappid(879050)
-- Game: addappid(879050)

-- MAIN APP DEPOTS / PACKAGES
addappid(879051, 1, "5f94a36e71a1bd9ff1c5846717cf3b32d96a188b5c7be649a178eddadf35f79c")
addappid(879053, 1, "01534808f525cf8b636fe7d0abd84961ee8ae9f23c733788f3c685847273f20b")
