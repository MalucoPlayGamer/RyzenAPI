-- Lua provided by RyzenAPI
-- Game: AppID 3304790

-- MAIN APPLICATION
addappid(3304790)
-- Game: addappid(3304790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304791, 1, "2b1674e05536539ed029043efc24acff2d6c96fbad65ca6da5473839b4c4b9fb")
