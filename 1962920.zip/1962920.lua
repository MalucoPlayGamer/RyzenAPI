-- Lua provided by RyzenAPI
-- Game: Kemono Friends Cellien May Cry

-- MAIN APPLICATION
addappid(1962920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1962921, 1, "fa4013a99543b2620aa01a80be6d7ca28083986070699717a651e40403eef682")
addappid(1962922, 1, "60c024ccb41d2490d935181c6cde9f0d02f5ddb11f81d7bbf4281dc8317e8272")
addappid(1962923, 1, "b594f25688aa77156925364198cb823f79eb4bb0ae77040b8056282f0e391e2d")

