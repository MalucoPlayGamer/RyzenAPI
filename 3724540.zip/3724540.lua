-- Lua provided by RyzenAPI
-- Game: Owl Bounce

-- MAIN APPLICATION
addappid(3724540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724541, 1, "32b028d69cab1d800e6b19ac71333bfce9bb4e71084c50f760c6c30c2eff5a2c")

