-- Lua provided by RyzenAPI
-- Game: Cantata

-- MAIN APPLICATION
addappid(690370)

-- MAIN APP DEPOTS / PACKAGES
addappid(690371, 1, "43cc4e0fefd92d5cea85b58662e60e1fe5d924cc8ce40d92fad2be0e91b6cf98")

