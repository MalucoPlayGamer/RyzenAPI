-- Lua provided by RyzenAPI
-- Game: 1646180

-- MAIN APPLICATION
addappid(1646180)
addappid(2510700)
-- Game: addappid(1646180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646181, 1, "492abb7ffb72d10126a3b633f3b9a0652f810b97c01fd53ea8d41eb328cb7e3f")
