-- Lua provided by RyzenAPI
-- Game: Game: Deep Rock Galactic - Original Soundtrack Volume I + II

-- MAIN APPLICATION
addappid(802640)
-- Game: addappid(802640)

-- MAIN APP DEPOTS / PACKAGES
addappid(802641, 1, "4a25bdb0198768cfc3277d4892ad41f45d19762c101711c73f7fd229b60e1df2")
addappid(802642, 1, "d448c4f4a1f48362382656c111c5dc7e5f18a01b98d86d4dc9f821781d563ba5")
addappid(802643, 1, "3f7c047aaeda45352662542387c5b0c6012529258d3a4ee7bfb72da9395b55f8")
addappid(802644, 1, "fb00dd61b77af7a766e93dec241b8d04576c0e1768cff0677448d00e965ce75a")
