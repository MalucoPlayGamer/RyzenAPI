-- Lua provided by SkyAPI 
-- Game: Goetia
addappid(421740)
addappid(421741, 1, "a5e2103b119321fd8dce1f81d47b576aefee18b8199381e8dffe46681c5a8801")
addappid(421742, 1, "f41468ccdd603eab75a669e1ef59960e5c1fdf8dbb6d19eb31999621626eedc4")
addappid(421743, 1, "88c905b2b7fd62d4a11bb7885ef812d5d0ba6f9609c4d84113fb456302dc59bd")
