-- Lua provided by RyzenAPI
-- Game: Project Werewulf

-- MAIN APPLICATION
addappid(2343900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2343901, 1, "d6e9c4301a0a996edf1723a1b92a7b04e1869b11928726496af4af41b22299ac")

