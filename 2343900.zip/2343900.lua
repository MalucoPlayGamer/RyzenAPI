-- Lua provided by RyzenAPI
-- Game: Project Werewulf

-- MAIN APPLICATION
addappid(2343900)
-- Game: addappid(2343900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343901, 1, "d6e9c4301a0a996edf1723a1b92a7b04e1869b11928726496af4af41b22299ac")
