-- Lua provided by RyzenAPI
-- Game: The First Berserker: Khazan

-- MAIN APPLICATION
addappid(2680010)
addappid(3265140)
addappid(3265150)
addappid(3265160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680011,0,"fe9a3ee6a263260b75cf97d27ffc4eeda8c9eebc8019bdc57c247a546f450077")

