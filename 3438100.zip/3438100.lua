-- Lua provided by SkyAPI 
-- Game: Lustful Fingers
addappid(3438100)
addappid(3438101, 1, "60e75554fa2fb58d3bad057a033f2a0216759f8dd43b0aa908c4706b91b66095")
