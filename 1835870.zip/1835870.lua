-- Lua provided by RyzenAPI
-- Game: The Black Cat Magician

-- MAIN APPLICATION
addappid(1835870)
addappid(1835871)
addappid(1835873)
addappid(1835874)
addappid(1835875)
addappid(1835876)
addappid(1835877)
addappid(1835879)
-- Game: addappid(1835870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835872,0,"1c95dff1e2dc746d68d7d19ae4563d88f89b7484ae38e31a985388e1ea928e16")
addappid(1835878,0,"e998908726c4910f06e34c05c9cea5b976f21466ae10453a88eb01aad6b8d604")
