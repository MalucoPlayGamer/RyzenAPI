-- Lua provided by RyzenAPI
-- Game: Port Royale 3

-- MAIN APPLICATION
addappid(205610)
addappid(215970)
addappid(215971)
addappid(215972)

-- MAIN APP DEPOTS / PACKAGES
addappid(205611, 1, "fce2e1c6978c7b56c759a52560797a75b5ac5e4afb58dd1851c318ec3240f8d7")
addappid(205612, 1, "04c0f0ea9d0f72a59c832a1fb3d4641e1218e1be5d13c85cabb83f84de8d0149")
addappid(205613, 1, "cb12c407069a6ccd4acbd10cf41a92d7653e7dac80c4ce1623adf9fcf48e1fd0")
addappid(205614, 1, "a6aa9abdac7af81ca43f8101829b41ea3df04b56ab3a1d1e0de1b011638ecbb4")
addappid(205615, 1, "aee997aa95e851eea19598566796f5916317f8c62c7b6a0d0cbd9610e1082189")
addappid(205616, 1, "85607f4afac42768ca367175ad5b4fa82d42347b847c31c5bd8602b27a71e8d5")
addappid(205617, 1, "bdce209ab4d9d8f7224a7f24b8a033a2634bef74697b2e86a8b3d29da84ccd46")
addappid(205618, 1, "85f722bd0bdacbf413d1c40c48832997113941132bda7243d8c22cf5e76e1705")

