-- Lua provided by RyzenAPI
-- Game: Savant - Ascent REMIX

-- MAIN APPLICATION
addappid(2279330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279331, 1, "feca51314c2cfa3ab458cdd15c234be2d9348ac8ad9dc747d680b398472056eb")
addappid(2279332, 1, "f36667141ff65cbf8b9a751bddedc95742e7162d5eef43aa2e402c2efff2c836")
