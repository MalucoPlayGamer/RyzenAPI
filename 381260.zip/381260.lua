-- Lua provided by RyzenAPI
-- Game: addappid(381260)

-- MAIN APPLICATION
addappid(381260)

-- MAIN APP DEPOTS / PACKAGES
addappid(381261, 1, "2261ae01a635e1dab9a057394babf6c1060e57a3d216bf149a66f644abc5579c")
