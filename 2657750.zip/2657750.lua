-- Lua provided by RyzenAPI
-- Game: Art is dead

-- MAIN APPLICATION
addappid(2657750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2657751, 1, "72be67e556235024183394847dca14287b0ed1461946142d09dbf891b41253f2")
addappid(2657752, 1, "d810b81a27db73fd1d28d3ada4011ef25f139fea35555f8acb1c499f934830c4")

