-- Lua provided by RyzenAPI
-- Game: 2244510

-- MAIN APPLICATION
addappid(2244510)
-- Game: addappid(2244510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244511, 1, "38deae40f38d52bc0f6356e5a83448433a7c54d4ecb980518abfb19b7085d708")
