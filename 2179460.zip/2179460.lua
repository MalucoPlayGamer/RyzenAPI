-- Lua provided by RyzenAPI
-- Game: addappid(2179460)

-- MAIN APPLICATION
addappid(2179460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179461, 1, "f3edfb43f74e7d231e22a49b4b1f2da963bccdcd2a98a446567e355c238b4bd9")
