-- Lua provided by RyzenAPI
-- Game: Breakneck City

-- MAIN APPLICATION
addappid(1210340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210341, 1, "840a51cc41a4c3cd489b731015793e4ae7c8d47fe9c711579535b7e29268877b")

