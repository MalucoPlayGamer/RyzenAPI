-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Dooo - “Guitar Solos with Dooo #2 - Ascend”

-- MAIN APPLICATION
addappid(1089238)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089238,0,"f5c3d833ec5898f082ca2434d9c56f4c02fbbba078bef8eeb9e1279518888cc4")

