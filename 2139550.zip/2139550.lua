-- Lua provided by RyzenAPI
-- Game: AppID 2139550

-- MAIN APPLICATION
addappid(2139550)
-- Game: addappid(2139550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139551, 1, "7a5419c2311492a5b52f6c4de05437f5cfc7bb4ac50bf397ae15fd92983c0bc0")
