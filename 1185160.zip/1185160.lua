-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Inunaki Tunnel | 犬鳴トンネル

-- MAIN APPLICATION
addappid(1185160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185161, 1, "98384b4e59f2b0ac92e774182750741b0192d520c99684d87e28feae073993a7")

