-- Lua provided by RyzenAPI
-- Game: addappid(2279550)

-- MAIN APPLICATION
addappid(2279550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279551, 1, "56a31c94c954946b7b2e86413cab2e0d4d830cddf76e39b5b1c9a560eb171a49")
