-- Lua provided by RyzenAPI
-- Game: Between

-- MAIN APPLICATION
addappid(2279550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279551, 1, "56a31c94c954946b7b2e86413cab2e0d4d830cddf76e39b5b1c9a560eb171a49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
