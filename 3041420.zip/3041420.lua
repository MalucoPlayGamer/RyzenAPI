-- Lua provided by RyzenAPI
-- Game: Speed Factor

-- MAIN APPLICATION
addappid(3041420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041421,0,"04a792e2cf95bda779864334752114df9f17eabd02e3f9cf86a3858295bbd6b9")

