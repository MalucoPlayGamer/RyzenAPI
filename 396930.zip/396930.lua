-- Lua provided by RyzenAPI
-- Game: Tidal Affair: Before The Storm

-- MAIN APPLICATION
addappid(396930)

-- MAIN APP DEPOTS / PACKAGES
addappid(396931, 1, "228128644e0bada5891f986ffe467c7157ec9596abb5dc332c55e500ebb91378")
addappid(422280, 0, "9243758d4b53f8320c1a50b6d347f2f8df86fc0fa317d441d26825f25592ac97")

