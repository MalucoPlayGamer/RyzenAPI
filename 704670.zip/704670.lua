-- Lua provided by RyzenAPI
-- Game: Inexplicable Geeks: Dawn of Just Us

-- MAIN APPLICATION
addappid(704670)

-- MAIN APP DEPOTS / PACKAGES
addappid(704671, 1, "4404b4643941470b66605f9c01b41a2c2c983cf76423bc55adf2a5588eb74df3")
addappid(711950, 0, "7565148b3a44cebc7ba0bc1381ec273e834db2e5847e06c6f6bf70a738782deb")
addappid(836370, 0, "074a2baa7d873d0bea099c66ebad5af7bf002d3a871fa764d657ff86871502fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(731970)
addappid(836570)
