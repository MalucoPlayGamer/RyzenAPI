-- Lua provided by RyzenAPI
-- Game: Game: NEKOPARA - Catboys Paradise

-- MAIN APPLICATION
addappid(1593310)
-- Game: addappid(1593310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593311, 1, "8067cc60dfce07100a6113590a51078b72ca6c85962bd888cf4c7df5aef66e51")
