-- Lua provided by RyzenAPI 
-- Game: Kunado Chronicles
addappid(1934910)
addappid(1934911, 1, "2440fafc5b8a4dadb056e49d83a079e93b4ac5476c9982dbca21b50ad8cc5a6e")
