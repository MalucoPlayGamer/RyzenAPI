-- Lua provided by RyzenAPI
-- Game: 1934910

-- MAIN APPLICATION
addappid(1934910)
-- Game: addappid(1934910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934911, 1, "2440fafc5b8a4dadb056e49d83a079e93b4ac5476c9982dbca21b50ad8cc5a6e")
