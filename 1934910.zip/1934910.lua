-- Lua provided by RyzenAPI
-- Game: Kunado Chronicles

-- MAIN APPLICATION
addappid(1934910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1934911, 1, "2440fafc5b8a4dadb056e49d83a079e93b4ac5476c9982dbca21b50ad8cc5a6e")

