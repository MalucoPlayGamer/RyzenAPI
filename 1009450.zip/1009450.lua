-- Lua provided by RyzenAPI
-- Game: addappid(1009450)

-- MAIN APPLICATION
addappid(1009450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009451, 1, "8d37254f0cfa45913457bc911f43c48e5b9f46f2bed18015540feed1284e8dad")
