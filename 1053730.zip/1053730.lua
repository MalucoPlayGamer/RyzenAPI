-- Lua provided by RyzenAPI
-- Game: 1053730

-- MAIN APPLICATION
addappid(1053730)
-- Game: addappid(1053730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053731, 1, "e8d8f82be96c314269ce0deea1e5fb2a3ed2d5835282d8a07335c6788abe9fdf")
