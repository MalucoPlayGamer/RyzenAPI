-- Lua provided by RyzenAPI
-- Game: Deep Inside

-- MAIN APPLICATION
addappid(2968020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968021, 1, "80b16f281e0f91fef21e68f77d07d25d900e7be9a4f51d2f66ac67a87ce48804")

