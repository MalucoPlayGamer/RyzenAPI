-- Lua provided by RyzenAPI
-- Game: Game: Zekertune

-- MAIN APPLICATION
addappid(3822960)
-- Game: addappid(3822960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3822961, 1, "435adaa5bd02866c57f48b171a4189efd678a16e721dfbdf8da8fad2c1acee98")
