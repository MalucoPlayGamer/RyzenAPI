-- Lua provided by RyzenAPI
-- Game: Motor Strike: Racing Rampage

-- MAIN APPLICATION
addappid(777460)

-- MAIN APP DEPOTS / PACKAGES
addappid(777461,0,"edd5c6bb81994fea9bf3537c918df3188c537d7b340020124f0abf970bd1f499")

