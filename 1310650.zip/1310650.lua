-- Lua provided by RyzenAPI
-- Game: Hedera

-- MAIN APPLICATION
addappid(1310650)
-- Game: addappid(1310650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310651, 1, "6de7e4a33d267d948a98ad359fd6cdf9fb9db4e5b8ab39ea7e15f2b6efc6afb5")
