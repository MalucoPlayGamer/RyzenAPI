-- Lua provided by RyzenAPI 
-- Game: Hedera
addappid(1310650)
addappid(1310651, 1, "6de7e4a33d267d948a98ad359fd6cdf9fb9db4e5b8ab39ea7e15f2b6efc6afb5")
