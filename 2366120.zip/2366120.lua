-- Lua provided by RyzenAPI
-- Game: 2366120

-- MAIN APPLICATION
addappid(2366120)
-- Game: addappid(2366120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366121, 1, "e78c0dee7aeb116172f0e91be25a75385e7f5eff36398b3072d4d7ca9a6ef827")
