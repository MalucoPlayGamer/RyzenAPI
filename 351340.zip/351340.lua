-- Lua provided by SkyAPI 
-- Game: Belladonna
addappid(351340)
addappid(351341, 1, "4e8f450298fbc220fadd5cb3295464c3006881056b2ebdf330d8bbb6e102ec9f")
