-- Lua provided by RyzenAPI
-- Game: Belladonna

-- MAIN APPLICATION
addappid(351340)
-- Game: addappid(351340)

-- MAIN APP DEPOTS / PACKAGES
addappid(351341, 1, "4e8f450298fbc220fadd5cb3295464c3006881056b2ebdf330d8bbb6e102ec9f")
