-- Lua provided by RyzenAPI
-- Game: Game: Route8

-- MAIN APPLICATION
addappid(2889460)
-- Game: addappid(2889460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889461, 1, "7239b43daa963cf84b95d0a507e0cc36b772424933de03e5229ab98329a55a88")
