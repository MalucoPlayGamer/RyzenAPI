-- Lua provided by RyzenAPI
-- Game: Line of War

-- MAIN APPLICATION
addappid(1599210)
-- Game: addappid(1599210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599211, 1, "dcdb4bc2408fe50aa31a0db1e31501f160a795ab9a80cc3aec97b0ab43b655bb")
