-- Lua provided by RyzenAPI 
-- Game: Line of War
addappid(1599210)
addappid(1599211, 1, "dcdb4bc2408fe50aa31a0db1e31501f160a795ab9a80cc3aec97b0ab43b655bb")
