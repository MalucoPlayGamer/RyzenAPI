-- Lua provided by RyzenAPI
-- Game: Phantom sense VR

-- MAIN APPLICATION
addappid(1645670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645671, 1, "66aa7a31404f1823a05e50518ff8c7e865318f8a877542f2e79a40317e6b0b78")

