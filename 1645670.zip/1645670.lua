-- Lua provided by SkyAPI 
-- Game: Phantom sense VR
addappid(1645670)
addappid(1645671, 1, "66aa7a31404f1823a05e50518ff8c7e865318f8a877542f2e79a40317e6b0b78")
