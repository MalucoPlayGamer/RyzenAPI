-- Lua provided by RyzenAPI
-- Game: Sweet Story Bunny Club - 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1286000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286000,0,"6573d50ec70c5c4f0d4e959374534c01ae5d9d83125b9f32c2e7e81c69575e64")
addtoken(1286000,16852685066222127846)

