-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1959160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959160,0,"cd6988912a916a40825f0f199e84f917b392f3a1304f8def8eabef2ed0edb445")
