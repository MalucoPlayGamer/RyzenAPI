-- Lua provided by RyzenAPI
-- Game: GUILTY GEAR 2 -OVERTURE-

-- MAIN APPLICATION
addappid(437000)

-- MAIN APP DEPOTS / PACKAGES
addappid(437001, 1, "1c4f8b447c821246338c60d797bf6743349922a65a863552128d83f241f38352")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
