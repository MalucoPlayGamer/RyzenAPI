-- Lua provided by RyzenAPI
-- Game: Tank Zombie Smasher

-- MAIN APPLICATION
addappid(1682610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682611, 1, "090ad184e5d6b6f2f7f3e6fcf4548b74fb84c99fa549e3d905b89c90013d2672")
