-- Lua provided by RyzenAPI 
-- Game: Bondage Girl
addappid(1186260)
addappid(1186261, 1, "a898ff4644e75115bce059030293b707181506584ef7f8ce1b9fa66c7e8b7dab")
