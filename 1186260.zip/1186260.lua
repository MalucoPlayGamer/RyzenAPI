-- Lua provided by RyzenAPI
-- Game: Game: Bondage Girl

-- MAIN APPLICATION
addappid(1186260)
-- Game: addappid(1186260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186261, 1, "a898ff4644e75115bce059030293b707181506584ef7f8ce1b9fa66c7e8b7dab")
