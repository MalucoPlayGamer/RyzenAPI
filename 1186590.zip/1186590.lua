-- Lua provided by RyzenAPI
-- Game: Unnamed Adventure/无名之旅

-- MAIN APPLICATION
addappid(1186590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186591, 1, "5ef6df5df2beb7737f939b76f27b2c443add8188669c003dc652a453d08789a6")

