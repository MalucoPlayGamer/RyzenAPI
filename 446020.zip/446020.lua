-- Lua provided by RyzenAPI
-- Game: Jalopy

-- MAIN APPLICATION
addappid(446020)
-- Game: addappid(446020)

-- MAIN APP DEPOTS / PACKAGES
addappid(446021, 1, "7d7864f97436c7cc540c6df4feae0ebc216d4f2238b2f6f8b416b911971a37f7")
