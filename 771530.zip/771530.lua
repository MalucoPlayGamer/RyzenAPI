-- Lua provided by RyzenAPI
-- Game: Take That

-- MAIN APPLICATION
addappid(771530)
addappid(771531)
addappid(771532)
addappid(771533)

-- MAIN APP DEPOTS / PACKAGES
addappid(771534,0,"368d1a92312c69559fc7d06b8ef9e47a8efbba734f528386cf04bffc9d53a839")
addappid(1118400,0,"a15f1371c3720c52e7f2e0322ce35653361b8164f25b22ceb398f0eb65a8b8c6")

