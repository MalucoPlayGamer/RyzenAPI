-- Lua provided by RyzenAPI
-- Game: addappid(307640)

-- MAIN APPLICATION
addappid(307640)

-- MAIN APP DEPOTS / PACKAGES
addappid(307641, 1, "4c10e7a218abbbbfcd7d519d3cfd4e48dba9ff769eded9b4942c574610404c59")
addappid(307642, 1, "ddaf4bf042375d13ba43df8217362e417f60a7666b892a93a2bad4bd18b836c2")
