-- Lua provided by RyzenAPI
-- Game: 494340

-- MAIN APPLICATION
addappid(494340)
-- Game: addappid(494340)

-- MAIN APP DEPOTS / PACKAGES
addappid(494341, 1, "4d042d52dab533c49fd1184d32ceed9c75003947079c278e209e4a0101e51ff9")
