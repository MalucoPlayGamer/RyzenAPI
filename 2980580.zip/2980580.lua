-- Lua provided by RyzenAPI
-- Game: ASTRODRIFTER

-- MAIN APPLICATION
addappid(2980580)
-- Game: addappid(2980580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980581, 1, "e3a7ad5527372b96b14b6cfbbb473461715e9434d7ebf470666d5df3331d3ce7")
