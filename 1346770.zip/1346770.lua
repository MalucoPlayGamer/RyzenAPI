-- Lua provided by RyzenAPI
-- Game: Game: AppID 1346770

-- MAIN APPLICATION
addappid(1346770)
-- Game: addappid(1346770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346771, 1, "142726382393ce1177147da37ef4c1e611309494173d39162f2f3cafd6eaa85a")
