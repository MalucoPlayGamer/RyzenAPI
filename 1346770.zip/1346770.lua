-- Lua provided by RyzenAPI 
-- Game: AppID 1346770
addappid(1346770)
addappid(1346771, 1, "142726382393ce1177147da37ef4c1e611309494173d39162f2f3cafd6eaa85a")
