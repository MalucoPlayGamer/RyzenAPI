-- Lua provided by RyzenAPI
-- Game: Haunted Hotel: Lonely Dream

-- MAIN APPLICATION
addappid(786040)

-- MAIN APP DEPOTS / PACKAGES
addappid(786041,0,"7af1e82d6aaf293ffefd637baa07b5f5be003af2ddb47ef9127976743f301d6b")

