-- Lua provided by RyzenAPI
-- Game: 1470970

-- MAIN APPLICATION
addappid(1470970)
-- Game: addappid(1470970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470971, 1, "33f4abcb704abac0dd912bec8db3cde3ab70d5101b7e6e139de3ff696a4c47b7")
