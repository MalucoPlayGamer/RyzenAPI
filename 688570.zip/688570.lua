-- Lua provided by RyzenAPI
-- Game: addappid(688570)

-- MAIN APPLICATION
addappid(688570)

-- MAIN APP DEPOTS / PACKAGES
addappid(688571, 1, "4b3eacf0477ee8f7ba4a25216f65d4b356f21a7888a6b076c0cb6969623908a6")
