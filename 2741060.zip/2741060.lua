-- Lua provided by RyzenAPI
-- Game: Vampires and Afternoon Tea

-- MAIN APPLICATION
addappid(2741060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741061, 1, "da1e88e7c59cd317605c1f0e43dc50d1c2b077e2acf6a50342f2270d8a271424")
addappid(2741062, 1, "eff8630eb6326c80e141a72771e909212ad5ccf61eb4474a6f6aab02a308a398")
