-- Lua provided by RyzenAPI 
-- Game: Radiant Victorias ASMR Series - Cindy
addappid(2996410)
addappid(2996411, 1, "fde2d27362143b8dea6b618833053a6d81fa7d400cb54b7f85f760f32e240df4")
