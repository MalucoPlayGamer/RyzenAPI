-- Lua provided by RyzenAPI
-- Game: Your Girls

-- MAIN APPLICATION
addappid(3409980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409981, 1, "0bcc2db745ba45e756e94bb7d3bc8c949b2598e72b2f9a0174c451a10abc9158")
