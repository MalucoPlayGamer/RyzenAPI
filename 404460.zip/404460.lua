-- Lua provided by RyzenAPI
-- Game: Melter Man

-- MAIN APPLICATION
addappid(404460)

-- MAIN APP DEPOTS / PACKAGES
addappid(404461, 1, "7b572dd748a1c225aaebe85dab44f665d07e695f48c5ddbadaf2fa0f4d549ad5")

