-- Lua provided by RyzenAPI
-- Game: Card Shark Demo

-- MAIN APPLICATION
addappid(1838940)
-- Game: addappid(1838940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838941, 1, "25222883a55bbeb45fb4d9233ef9db18e4ea906762c82553656df16ebe3ca136")
