-- Lua provided by RyzenAPI
-- Game: setManifestid(523672,"2397266681253789435")

-- MAIN APPLICATION
addappid(523670)
-- Game: addappid(523670)

-- MAIN APP DEPOTS / PACKAGES
addappid(523672,0,"d884a80f3a7ef8ffa2537cccb3bcc3fa8ea37f1c8a37f5d2a3a354481e7df0e0")
