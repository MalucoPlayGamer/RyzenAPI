-- Lua provided by RyzenAPI
-- Game: Game: AppID 555050

-- MAIN APPLICATION
addappid(555050)
-- Game: addappid(555050)

-- MAIN APP DEPOTS / PACKAGES
addappid(555051, 1, "c3066676d37ac282348007d83cf95bbb8a18c06e252e2bff06ab45839fc50301")
