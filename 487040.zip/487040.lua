-- Lua provided by RyzenAPI
-- Game: 487040

-- MAIN APPLICATION
addappid(487040)
addappid(487041)
addappid(487042)
addappid(487043)
addappid(619800)
addappid(619802)
addappid(619803)
addappid(619804)
addappid(619805)
addappid(619807)
addappid(619808)
addappid(619809)

-- MAIN APP DEPOTS / PACKAGES
addappid(487044,0,"093bf41444bf1a351455c5e40bd5e90ad89e87ec47df8ed120a9c496f72cc79e")
addappid(619801,0,"a8c9f15499d62183236b16e732c0065a82ae114bab5f8be09d9c08df147489ba")
addappid(619806,0,"bdb5696e42bd2baef2ed2d9615a0d9f857abdb816b6446d5bf556419379f7874")

