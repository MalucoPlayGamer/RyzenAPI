-- Lua provided by RyzenAPI
-- Game: Zhurong - Officer Ticket / 祝融使用券

-- MAIN APPLICATION
addappid(956892)

-- MAIN APP DEPOTS / PACKAGES
addappid(956892,0,"05c202350aee5bab39c3123a393a61e3ee59bb9c6dd98952d0d63d3cecd2b89a")

