-- Lua provided by RyzenAPI
-- Game: The Disappearing of Gensokyo: Patchouli Character Pack

-- MAIN APPLICATION
addappid(778530)

-- MAIN APP DEPOTS / PACKAGES
addappid(778530,0,"c897d1e3610d20152eda488d9a468c51099641d637219afe12d474eb747e7876")
