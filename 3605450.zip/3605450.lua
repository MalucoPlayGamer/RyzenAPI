-- Lua provided by RyzenAPI 
-- Game: DIRTY TEACHERS
addappid(3605450)
addappid(3605451, 1, "5c4e8380f8335d4594fe6211a2131902aa2d9212c82b3be56f5cd6bd468870c5")
