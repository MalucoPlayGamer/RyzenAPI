-- Lua provided by RyzenAPI
-- Game: 2067810

-- MAIN APPLICATION
addappid(2067810)
-- Game: addappid(2067810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067811, 1, "01bc581f68b3acc0904b132c3fc8f396a20347a17e9ca5ada89f2611d4111bef")
