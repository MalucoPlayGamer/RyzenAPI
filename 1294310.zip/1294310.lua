-- Lua provided by SkyAPI 
-- Game: AppID 1294310
addappid(1294310)
addappid(1294311, 1, "1244580273bf5949d0af40c9a61d99965169982847dff719617d55aff8390d50")
