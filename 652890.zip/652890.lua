-- Lua provided by RyzenAPI
-- Game: Vanguard Knights

-- MAIN APPLICATION
addappid(652890)

-- MAIN APP DEPOTS / PACKAGES
addappid(652891, 1, "e03bbe7d9118e7ac5e59a6b864ba5c8b7cb41ba3a6489c8931f231c4bcae2c8d")

