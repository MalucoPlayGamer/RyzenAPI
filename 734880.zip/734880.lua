-- Lua provided by RyzenAPI
-- Game: addappid(734880)

-- MAIN APPLICATION
addappid(734880)

-- MAIN APP DEPOTS / PACKAGES
addappid(734881, 1, "37ef90088ef35afd9cd3f03a47192b6dd8cd9e75817ef770ae6265305dd30ec6")
addappid(734882, 1, "26caef43e1437a1d33dff2a910bb47abc99eb7d624dc065e97c10b42db59922f")
