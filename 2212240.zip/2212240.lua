-- Lua provided by RyzenAPI
-- Game: 2212240

-- MAIN APPLICATION
addappid(2212240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212240,0,"df9f96b1f3ac5721d4a62b46a97df8a80dcf91aaabe55d8b7275b48bda93df7b")
