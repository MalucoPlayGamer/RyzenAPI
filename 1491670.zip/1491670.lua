-- Lua provided by RyzenAPI
-- Game: addappid(1491670)

-- MAIN APPLICATION
addappid(1491670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491671, 1, "09dc31cd91dfdb17e84c1a025f2cbb38913889fac35ab621a1edb11e6eb66f6d")
