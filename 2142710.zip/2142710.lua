-- Lua provided by RyzenAPI
-- Game: Emi - New Beginning

-- MAIN APPLICATION
addappid(2142710)
addappid(2142711)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142712,0,"5332dadd8d2723de19362fffb600c871b621b44fef9196d5643b3f03467d5e79")
