-- Lua provided by RyzenAPI
-- Game: Chuzzle Deluxe

-- MAIN APPLICATION
addappid(3310)
-- Game: addappid(3310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311, 1, "a43fb836c6313a0cc6158ffc959f55c733141be9f6d4d16f3c5a5ed935ddbebd")
addappid(3313, 1, "14c2b9e345b44d5aff4a5d8e30cf288e53253307b45319b312608a8f1374c734")
addappid(3314, 1, "532167b35dd2cbb1c6a8be473b3c6199070d11b5021088cefb9240762d2c847e")
addappid(3315, 1, "26b1afc709df677c817da72e9ce0c32c324fb8e984a92861486037860898b224")
addappid(3316, 1, "b3a868a92b506b38e3a5c8b200fa4fa3ae32967c38a3e62a0fa83d9a6abd5cb6")
addappid(3317, 1, "fd582a6f8e7c3ba7736f0e6add9c965b151b72fffd0dfba1fa354088953aaa54")
