-- Lua provided by RyzenAPI
-- Game: Holy Shot

-- MAIN APPLICATION
addappid(3040180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040183,0,"0c5dfdc358345278b6c5b6f291720900f8a98eee9cd88f6793e3ac66399cb512")

