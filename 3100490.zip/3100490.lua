-- Lua provided by RyzenAPI
-- Game: Ink Reverie Demo

-- MAIN APPLICATION
addappid(3100490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100491, 1, "0fd200467bcd295239c67c697503cf1554c5cf3f2d08efa635ecd69e1aefff7c")

