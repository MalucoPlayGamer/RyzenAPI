-- Lua provided by RyzenAPI
-- Game: AppID 221790

-- MAIN APPLICATION
addappid(221790)

-- MAIN APP DEPOTS / PACKAGES
addappid(221791, 1, "7a283b8bd36381dd6e5362c429575e6489f7af0f58605864056612799ad0ee3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(236551)
addappid(236552)
addappid(236553)
addappid(236554)
addappid(236555)
addappid(236556)
addappid(236557)
addappid(236558)
