-- Lua provided by RyzenAPI
-- Game: Game: AppID 221790

-- MAIN APPLICATION
addappid(221790)
-- Game: addappid(221790)

-- MAIN APP DEPOTS / PACKAGES
addappid(221791, 1, "7a283b8bd36381dd6e5362c429575e6489f7af0f58605864056612799ad0ee3e")
