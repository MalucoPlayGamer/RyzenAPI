-- Lua provided by RyzenAPI
-- Game: Game: Tavern of Gods

-- MAIN APPLICATION
addappid(1418020)
-- Game: addappid(1418020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418021, 1, "fbc1d05beb07f12a149b36b956877843b70286bf89bfe4bc3541eb58e1f41a24")
