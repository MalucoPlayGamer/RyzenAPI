-- Lua provided by SkyAPI 
-- Game: Tavern of Gods
addappid(1418020)
addappid(1418021, 1, "fbc1d05beb07f12a149b36b956877843b70286bf89bfe4bc3541eb58e1f41a24")
