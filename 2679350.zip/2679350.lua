-- Lua provided by RyzenAPI
-- Game: Game: Japanese MILF

-- MAIN APPLICATION
addappid(2679350)
-- Game: addappid(2679350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679351, 1, "9fe3a3b1ec7584a6b1420e2ad3e7371bbe939c3d43485a2a6db58fe04a87ff33")
