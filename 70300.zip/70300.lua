-- Lua provided by RyzenAPI
-- Game: 70300

-- MAIN APPLICATION
addappid(70300)
-- Game: addappid(70300)

-- MAIN APP DEPOTS / PACKAGES
addappid(70301, 1, "b2e6e5f765dd9f1aacc5f5aeb9e1cd0f460ef6b2784b776ad1156d95dfd02deb")
addappid(70302, 1, "8b631aacc07b2b550f0cd075356e90c60780823c181cc4e1842a00e08c2b2d65")
addappid(70303, 1, "773b5bbc45e104fb921e4666d76dbfb78bdca3e8d3fb74409fbaacc26b349934")
