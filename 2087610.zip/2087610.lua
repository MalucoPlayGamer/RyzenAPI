-- Lua provided by RyzenAPI
-- Game: 2087610

-- MAIN APPLICATION
addappid(2087610)
-- Game: addappid(2087610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087611, 1, "7d01c8c3020af1f78a9c0b2ed6a0f354cdfcbd930edf339edd9fe55d3e91ff50")
