-- Lua provided by RyzenAPI
-- Game: Evil Spirits

-- MAIN APPLICATION
addappid(690580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(690581,0,"bd359a6e84256f658d33e3aa60eda76576ff79efb2ff3e14513a4bcd4287bb84")

