-- Lua provided by RyzenAPI
-- Game: Evil Spirits

-- MAIN APPLICATION
addappid(690580)

-- MAIN APP DEPOTS / PACKAGES
addappid(690581,0,"bd359a6e84256f658d33e3aa60eda76576ff79efb2ff3e14513a4bcd4287bb84")

