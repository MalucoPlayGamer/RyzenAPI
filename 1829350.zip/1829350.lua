-- Lua provided by RyzenAPI
-- Game: AppID 1829350

-- MAIN APPLICATION
addappid(1829350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829351, 1, "03c97dab5de9e8cccdb80284bcf475762c8efe14288bfabc1d5bf09b36ba9550")
