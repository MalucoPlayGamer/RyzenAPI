-- Lua provided by RyzenAPI
-- Game: TerraScape

-- MAIN APPLICATION
addappid(2290000)
addappid(3868750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290001, 1, "3cf35d14bf13777748547142d001d9010de60946610bcdb524db81acc663069f")

