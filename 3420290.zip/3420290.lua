-- Lua provided by RyzenAPI
-- Game: Look Down

-- MAIN APPLICATION
addappid(3420290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3420291, 1, "ef6197cdd426248de72f957f370834ebbcc60c04ac493140468c00cc1a1624cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
