-- Lua provided by RyzenAPI
-- Game: Look Down

-- MAIN APPLICATION
addappid(3420290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3420291, 1, "ef6197cdd426248de72f957f370834ebbcc60c04ac493140468c00cc1a1624cf")
