-- Lua provided by RyzenAPI
-- Game: Cat Fred Evil Pet

-- MAIN APPLICATION
addappid(2611040)
-- Game: addappid(2611040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611041, 1, "d5803ce516d53366fc299f0470600570959bbf650b858ba303591ff3e15a70aa")
