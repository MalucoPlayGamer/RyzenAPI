-- Lua provided by RyzenAPI
-- Game: addappid(1879910)

-- MAIN APPLICATION
addappid(1879910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879911, 1, "ad55770742dddf8d7ea8cb560a096006f5058d5ca5f5dae08d84ecf712483bfa")
