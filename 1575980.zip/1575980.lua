-- Lua provided by RyzenAPI
-- Game: Game: UsoNatsu ~The Summer Romance Bloomed From A Lie~

-- MAIN APPLICATION
addappid(1575980)
-- Game: addappid(1575980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575981, 1, "35767e18c7b6cbb8f6d72e624b6159fddbfa02476e45fa57931c36f0eff77813")
