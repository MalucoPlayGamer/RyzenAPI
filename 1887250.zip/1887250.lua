-- Lua provided by RyzenAPI
-- Game: addappid(1887250)

-- MAIN APPLICATION
addappid(1887250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887251, 1, "2471a461ab24bdea5b9fdb98fafc96db90481f3d87733a569eaf38654d2819da")
