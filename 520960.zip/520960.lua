-- Lua provided by RyzenAPI
-- Game: AppID 520960

-- MAIN APPLICATION
addappid(520960)
-- Game: addappid(520960)

-- MAIN APP DEPOTS / PACKAGES
addappid(520961, 1, "46afb24c6886f875e580d5cc9bd1e5ad2284545c12ab4b596800b2b0d4318115")
