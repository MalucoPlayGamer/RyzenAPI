-- Lua provided by RyzenAPI
-- Game: Game: AppID 785790

-- MAIN APPLICATION
addappid(785790)
-- Game: addappid(785790)

-- MAIN APP DEPOTS / PACKAGES
addappid(785791, 1, "90d9930e8ba20789717d8c3380395f583a8bd0104bb8413f4b16718a94a6df14")
addappid(785792, 1, "a8191af9edba612fdfe6c34ae6fad74fb9662b485ab462c4f2a8f7b637159626")
addappid(785793, 1, "4a4afc5378f1f55a55fb0ec4cf356645236541838ee8b1e3df67ae2bef27ed2e")
