-- Lua provided by RyzenAPI
-- Game: AppID 448570

-- MAIN APPLICATION
addappid(448570)
addappid(468360)
addappid(581750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(448571, 1, "ae0726c28bf3f27ef9e03667477b22d331f61c0fccfbd72dea2cecec6ad2139e")

