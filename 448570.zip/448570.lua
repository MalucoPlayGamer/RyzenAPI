-- Lua provided by RyzenAPI
-- Game: AppID 448570

-- MAIN APPLICATION
addappid(448570)
-- Game: addappid(448570)

-- MAIN APP DEPOTS / PACKAGES
addappid(448571, 1, "ae0726c28bf3f27ef9e03667477b22d331f61c0fccfbd72dea2cecec6ad2139e")
