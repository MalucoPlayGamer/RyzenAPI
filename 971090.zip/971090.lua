-- Lua provided by RyzenAPI
-- Game: Hidden Object: Home Makeover

-- MAIN APPLICATION
addappid(971090)

-- MAIN APP DEPOTS / PACKAGES
addappid(971091, 1, "254e20539b6706f0a49f4c0949c14848d23d20667ea93bcfd813308376ed43a1")

