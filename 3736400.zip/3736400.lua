-- Lua provided by RyzenAPI
-- Game: SkillWarz

-- MAIN APPLICATION
addappid(3736400) -- SkillWarz

-- MAIN APP DEPOTS / PACKAGES
addappid(3736401, 1, "0136ef95e171dc285a4e12c1a3d2eeb35e3edd760f69f1065c98bf540862e81b") -- Depot 3736401
addappid(3736402, 1, "2ed9d58f18806aeae472f4688c0e9e2796c6b24bdf60deb3af035a04d2394b29") -- Depot 3736402

