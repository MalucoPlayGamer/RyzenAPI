-- 3736400's Lua and Manifest Created by Hubcap Manifest
-- SkillWarz
-- Created: August 03, 2026 at 12:18:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3736400) -- SkillWarz
-- MAIN APP DEPOTS
addappid(3736401, 1, "0136ef95e171dc285a4e12c1a3d2eeb35e3edd760f69f1065c98bf540862e81b") -- Depot 3736401
setManifestid(3736401, "8448574554692610009", 4983942843)
addappid(3736402, 1, "2ed9d58f18806aeae472f4688c0e9e2796c6b24bdf60deb3af035a04d2394b29") -- Depot 3736402
setManifestid(3736402, "5035384869499626251", 5371011991)