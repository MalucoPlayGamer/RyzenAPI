-- Lua provided by RyzenAPI 
-- Game: 酒馆战争
addappid(3177210)
addappid(3177211, 1, "96ee1ab092711cf27dd40b3a0d72489a4213c2631cb19a178970b201321740e0")
