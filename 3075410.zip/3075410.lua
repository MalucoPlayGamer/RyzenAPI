-- 3075410's Lua and Manifest Created by Hubcap Manifest
-- Hand of Fate: Hordes
-- Created: July 22, 2026 at 06:39:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3075410) -- Hand of Fate: Hordes
-- MAIN APP DEPOTS
addappid(3075412, 1, "1c0143276ef25446195818c3d0e08d0dc1bc033184211daec297ff412f328fc7") -- Depot 3075412
setManifestid(3075412, "7467936097957973656", 3798108702)
addappid(3075411, 1, "54b34e36bd41955ccd9304a3641ce8607541a9057d492bd0b19a0537294a14da") -- Depot 3075411
setManifestid(3075411, "180347174895715623", 3749235692)
addappid(3075413, 1, "e884fe27041cf88f7a632a30261880db8c1038654fd147c637048896e5c6cfa0") -- Depot 3075413
setManifestid(3075413, "2973688090128972281", 8389018809)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4953230) -- Hand of Fate Hordes - Supporter Pack