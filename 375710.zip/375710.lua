-- Lua provided by RyzenAPI
-- Game: The Adventures of Mr. Bobley

-- MAIN APPLICATION
addappid(375710)

-- MAIN APP DEPOTS / PACKAGES
addappid(375711, 1, "8e5b45ad85d3f95ef89c249f6aebf5f4949e6aafb7a850b5fcd63ce3f49abab0")
addappid(375712, 1, "cd60d7a0e760c9eb378bae28653b8a4b89b31916f5a18339cb709b52b0136e81")
addappid(375713, 1, "ebd90e07916c5d058e74fdff96f6df485b084af35d77d16cd9dbfe1108a8652b")
