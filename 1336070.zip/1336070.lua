-- Lua provided by RyzenAPI 
-- Game: Ynglet: Prologue
addappid(1336070)
addappid(1336071, 1, "cb11c7e9bae47ede3be714ed3e2fe8ff60d3bdfaef4ad0159666edd6e8981dd0")
addappid(1336072, 1, "5c1cfccb792cae625f9e618154d74d6a9a59ee767adf6e6912762aa167c3c9a3")
