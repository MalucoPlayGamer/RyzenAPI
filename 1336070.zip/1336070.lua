-- Lua provided by RyzenAPI
-- Game: Ynglet: Prologue

-- MAIN APPLICATION
addappid(1336070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336071, 1, "cb11c7e9bae47ede3be714ed3e2fe8ff60d3bdfaef4ad0159666edd6e8981dd0")
addappid(1336072, 1, "5c1cfccb792cae625f9e618154d74d6a9a59ee767adf6e6912762aa167c3c9a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
