-- Lua provided by RyzenAPI
-- Game: 1057430

-- MAIN APPLICATION
addappid(1057430)
addappid(1064970)
-- Game: addappid(1057430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057431, 1, "669c8121eef7318955ed424228dca6e5b3ca29272bf834292371bb0158e071e9")
