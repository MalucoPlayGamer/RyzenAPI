-- Lua provided by RyzenAPI
-- Game: Geometry May. I swear it's a nice free game

-- MAIN APPLICATION
addappid(1057430)
addappid(1064970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057431, 1, "669c8121eef7318955ed424228dca6e5b3ca29272bf834292371bb0158e071e9")
