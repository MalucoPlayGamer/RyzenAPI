-- Lua provided by RyzenAPI
-- Game: Hello Engineer: Scrap Machines Constructor

-- MAIN APPLICATION
addappid(1856190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856191, 1, "3f0abf4ea2aa71baa107b5ccc1d5e59a18178aa27362a4874cd7644e75d7f319")
