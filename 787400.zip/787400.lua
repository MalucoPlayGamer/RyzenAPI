-- Lua provided by RyzenAPI
-- Game: Fantasy Versus

-- MAIN APPLICATION
addappid(787400)
addappid(863740)
addappid(863741)

-- MAIN APP DEPOTS / PACKAGES
addappid(787401, 1, "74c03c9bd9223fc3eeab68a26db4703d78f068f507b9f88007285c9f2abb2be7")
