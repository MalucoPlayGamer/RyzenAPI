-- Lua provided by RyzenAPI
-- Game: Alien Kingdom

-- MAIN APPLICATION
addappid(1104960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104961, 1, "2c0114b9d87153007a71fdbac03718f1b3f9d9e3f74ca1b0d6670d62a990da36")
