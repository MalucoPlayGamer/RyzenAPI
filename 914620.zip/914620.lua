-- Lua provided by SkyAPI 
-- Game: AppID 914620
addappid(914620)
addappid(914621, 1, "3de6377dcc0c7e93bb1fdd7a9b8b9f13d72ab35f016e283d585b3a595f8b6367")
