-- Lua provided by RyzenAPI
-- Game: Game: Kármán line: the edge of war

-- MAIN APPLICATION
addappid(1331120)
-- Game: addappid(1331120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331121, 1, "77a82f3996d423444841a873e196b7fd44847da95ebfab046737721962702ecd")
