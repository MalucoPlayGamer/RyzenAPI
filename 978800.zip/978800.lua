-- Lua provided by RyzenAPI
-- Game: Rolling Bird

-- MAIN APPLICATION
addappid(978800)
addappid(999960)

-- MAIN APP DEPOTS / PACKAGES
addappid(978801,0,"4ad6dda8bc0a7d864896825c5dccd9d91c27cccf8621df974ab81561d49ac7be")
addappid(978802,0,"85979cf7d86727b7d02f2c4c6825e38d8ba8739039e839fb26e78df98a28fdda")

