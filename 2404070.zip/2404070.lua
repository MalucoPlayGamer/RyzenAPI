-- Lua provided by RyzenAPI
-- Game: Death's Toll

-- MAIN APPLICATION
addappid(2404070)
-- Game: addappid(2404070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404071, 1, "a6bdb034c25759de8cb442d35b47ebe0e371ab71936e6eaa8e0167fa326995df")
