-- Lua provided by RyzenAPI
-- Game: 1122563

-- MAIN APPLICATION
addappid(1122563)
-- Game: addappid(1122563)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122563,0,"89bc76d799d37405ba6dd835d124a9a9f4f6b2578bf7c89b57fa3ed524b98fd5")
