-- Lua provided by RyzenAPI
-- Game: AppID 838700

-- MAIN APPLICATION
addappid(838700)
-- Game: addappid(838700)

-- MAIN APP DEPOTS / PACKAGES
addappid(838701, 1, "2be092003341cabf76d8a49d1a638f185782ebcf00908bc7e246d2e86823dd5b")
