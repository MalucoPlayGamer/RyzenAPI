-- Lua provided by RyzenAPI
-- Game: DemonStar

-- MAIN APPLICATION
addappid(2577180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577181, 1, "b9b92f037262e478008d9c652e5e05fa1ab5c24b51f4ecd5e88954dd31ed0ee5")

