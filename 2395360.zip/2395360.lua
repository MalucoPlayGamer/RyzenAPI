-- Lua provided by RyzenAPI
-- Game: Slime Knight

-- MAIN APPLICATION
addappid(2395360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395361, 1, "c4e13c33de0499d63d9fb23b88b6deaf50d49e70b4dc1952b5e44661ae6d5eb8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
