-- Lua provided by RyzenAPI
-- Game: End's Beginning Demo

-- MAIN APPLICATION
addappid(3091220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091221, 1, "a7d67e177302357be3387b87d7322c79cc9313e2f1bfc498795027ae2cf870c4")
