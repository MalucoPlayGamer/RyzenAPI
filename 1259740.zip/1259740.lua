-- Lua provided by RyzenAPI
-- Game: Escape Dungeon

-- MAIN APPLICATION
addappid(1259740)
-- Game: addappid(1259740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259741, 1, "5f22ce39399a905e6ff6a916965fa5bd795f09294a405864d5468fd11f3c77f8")
addappid(1259742, 1, "f23e008024d3409b2d5c58775fb1bf86568df4684f0a81950c20de8438e4af8a")
