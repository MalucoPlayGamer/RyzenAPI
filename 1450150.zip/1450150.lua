-- Lua provided by RyzenAPI
-- Game: addappid(1450150)

-- MAIN APPLICATION
addappid(1450150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450151, 1, "6b99e225f7e382c15d47df1e4e7e06f96acafdc26e8e9aae24ccb1e46bc11b32")
