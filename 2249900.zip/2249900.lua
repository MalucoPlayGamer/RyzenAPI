-- Lua provided by RyzenAPI
-- Game: Robin Morningwood Adventure - Behind the scenes

-- MAIN APPLICATION
addappid(2249900)
-- Game: addappid(2249900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249901, 1, "1b57171cd9de5c95ec206640f39d23dcfd49e244e1419f89272a7715fd08dbeb")
