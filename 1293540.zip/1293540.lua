-- Lua provided by RyzenAPI
-- Game: 1293540

-- MAIN APPLICATION
addappid(1293540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293542,0,"8605af7e39c3f0d2cb3a00a1f5570a68ee4fbc4ae741f84346e08dfa159eec34")

