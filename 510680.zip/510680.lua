-- Lua provided by RyzenAPI
-- Game: AppID 510680

-- MAIN APPLICATION
addappid(510680)

-- MAIN APP DEPOTS / PACKAGES
addappid(510681, 1, "54f211f8fa01852e2e60c489f1d917fa50a7c940899e6f9323a245d54b196935")
addappid(510682, 1, "9361a56bd33f2e81b35f1c0ff10c657026f15f5da4a95eadf184fd11d16a1992")
addappid(839110, 0, "b17b8c331aa529e03731f129c89b5eb508de874fdcc0331d83f74c7e650913fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
