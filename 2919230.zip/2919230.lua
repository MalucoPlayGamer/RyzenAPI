-- Lua provided by RyzenAPI
-- Game: 2919230

-- MAIN APPLICATION
addappid(2919230)
-- Game: addappid(2919230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919231, 1, "597489366f85ed216ad85e00d1e1261cda11efca7495bc6721907e10be6798c7")
