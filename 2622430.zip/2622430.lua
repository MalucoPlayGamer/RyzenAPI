-- Lua provided by RyzenAPI
-- Game: DayZ Soundtrack

-- MAIN APPLICATION
addappid(2622430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622433,0,"7b0a27612392e7244d80d1ce5457b571d3d86249f5f314236e79eea00ca30ac9")
addappid(2622434,0,"62ba8c772b68a0d3e45dd9eee2853313de43a24dce3dadf9a7ffef6b3c76161d")

