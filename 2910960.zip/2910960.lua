-- Lua provided by RyzenAPI
-- Game: 2910960

-- MAIN APPLICATION
addappid(2910960)
-- Game: addappid(2910960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910961, 1, "8d7451c45f3ea3dde2df56723f3e62de3acf617c926a56eafa98231e9814a27e")
