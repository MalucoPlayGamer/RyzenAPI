-- Lua provided by RyzenAPI
-- Game: Poly Puzzle: Primates

-- MAIN APPLICATION
addappid(2078160)
-- Game: addappid(2078160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078161, 1, "00fe8cb24ef7b7fc6abdb9f73b209f611e9102536d6ce0da13f9c5e8b76bc410")
