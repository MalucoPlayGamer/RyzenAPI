-- Lua provided by RyzenAPI
-- Game: Dusk Diver 酉閃町

-- MAIN APPLICATION
addappid(228987)
addappid(228990)
addappid(911220)

-- MAIN APP DEPOTS / PACKAGES
addappid(911223,0,"fbe7931e52b91746c65969190b0a2c3d12d3834ccbcedc3cd7cb5c818e28a810")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1036112)
addappid(1036114)
addappid(1036116)
addappid(1036117)
