-- Lua provided by RyzenAPI
-- Game: 2017 VR

-- MAIN APPLICATION
addappid(575600)
-- Game: addappid(575600)

-- MAIN APP DEPOTS / PACKAGES
addappid(575601, 1, "72ad57147bcd94c2f006006dc7b7e583d5509849645018be45cad938aa7c1814")
