-- Lua provided by RyzenAPI
-- Game: addappid(575600)

-- MAIN APPLICATION
addappid(575600)

-- MAIN APP DEPOTS / PACKAGES
addappid(575601, 1, "72ad57147bcd94c2f006006dc7b7e583d5509849645018be45cad938aa7c1814")
