-- Lua provided by RyzenAPI
-- Game: Game: Superscout Demo

-- MAIN APPLICATION
addappid(2999200)
-- Game: addappid(2999200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999201, 1, "3ccfca714e3c4940792c01b1af9275f52c104e9d0a6b0d63142ee7849d087351")
addappid(2999202, 1, "3ac654ebb1f9dc92f03763f2b6213baf8ce1ee1e2a21e2999150e7fd3b2df6ce")
addappid(2999203, 1, "7a8d7fdbbbf0e5d008d37c238ca21232ffc557788b82dfd38e27e2c0be09d1a4")
addappid(2999204, 1, "008a12c0562b4f9a21e0c984b640101416710204c19ae89d0ef8af46b3ee8500")
addappid(2999205, 1, "b883b37e87fd69abedb0cdf6e252b7f62f399f97dfb94acf98b89114c79546dd")
