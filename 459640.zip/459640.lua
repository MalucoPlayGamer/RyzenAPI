-- Lua provided by RyzenAPI
-- Game: You... and who else?

-- MAIN APPLICATION
addappid(459640)
addappid(1087850)
addappid(1142110)

-- MAIN APP DEPOTS / PACKAGES
addappid(459641, 1, "71d7f63ae099cbc3cdc0f26419455b1a03085315e55e49e151d77f23bf7abaf2")
