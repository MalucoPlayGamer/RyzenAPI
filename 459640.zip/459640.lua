-- Lua provided by RyzenAPI
-- Game: 459640

-- MAIN APPLICATION
addappid(459640)
-- Game: addappid(459640)

-- MAIN APP DEPOTS / PACKAGES
addappid(459641, 1, "71d7f63ae099cbc3cdc0f26419455b1a03085315e55e49e151d77f23bf7abaf2")
