-- Lua provided by RyzenAPI
-- Game: The Penguin IQ Test Demo

-- MAIN APPLICATION
addappid(1743160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504221,0,"ba8d4b8b1c8821b60875d3bc7b72722f5e3f2bd95388f109453c207a46518fd7")

