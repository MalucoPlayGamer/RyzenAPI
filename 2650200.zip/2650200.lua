-- Lua provided by RyzenAPI
-- Game: Game: Blamcon Shooting Gallery

-- MAIN APPLICATION
addappid(2650200)
-- Game: addappid(2650200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650201, 1, "f7a32e628e148e2dea7d08e9de7937a69a1902349d9842eb2f2bd7c7b2cdcdd8")
