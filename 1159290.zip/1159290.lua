-- Lua provided by RyzenAPI
-- Game: addappid(1159290)

-- MAIN APPLICATION
addappid(1159290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159291, 1, "76e3cc8dd03421623d2c8f64513c49d675e0eea185c1bf6795bf9263c8f93535")
