-- Lua provided by RyzenAPI
-- Game: Kio's Adventure

-- MAIN APPLICATION
addappid(612070)

-- MAIN APP DEPOTS / PACKAGES
addappid(612071, 1, "435d0f64ccf8183abaafb139d21cadcfea01c3ea0938a7f34bd1396109a40993")
addappid(612072, 1, "807e3052447f76d1adc4d364b22b162c01a14b2656bb409056e75da44904e323")
addappid(612073, 1, "68e6cccc058fcbd67a20e1badf7f35e57d27534e11c6b6db00e0189c0af82c11")
