-- Lua provided by RyzenAPI
-- Game: Tree It

-- MAIN APPLICATION
addappid(2386460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2386461, 1, "bfc1315dcc70ecef1d84e94be657d38a0f3a3f43feadb34f39fe3b3b915ada5a")

