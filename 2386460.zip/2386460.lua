-- Lua provided by RyzenAPI
-- Game: Game: Tree It

-- MAIN APPLICATION
addappid(2386460)
-- Game: addappid(2386460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386461, 1, "bfc1315dcc70ecef1d84e94be657d38a0f3a3f43feadb34f39fe3b3b915ada5a")
