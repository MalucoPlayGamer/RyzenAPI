-- Lua provided by SkyAPI 
-- Game: Tree It
addappid(2386460)
addappid(2386461, 1, "bfc1315dcc70ecef1d84e94be657d38a0f3a3f43feadb34f39fe3b3b915ada5a")
