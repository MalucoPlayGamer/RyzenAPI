-- Lua provided by SkyAPI 
-- Game: 夏日花火 Demo
addappid(1943320)
addappid(1943321, 1, "e5a5a5b5ee2a86139f78857f39cf74365e048317f01227e017cc4bc68ad2916d")
