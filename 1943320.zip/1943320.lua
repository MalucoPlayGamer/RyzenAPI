-- Lua provided by RyzenAPI
-- Game: 1943320

-- MAIN APPLICATION
addappid(1943320)
-- Game: addappid(1943320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943321, 1, "e5a5a5b5ee2a86139f78857f39cf74365e048317f01227e017cc4bc68ad2916d")
