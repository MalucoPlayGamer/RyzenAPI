-- Lua provided by RyzenAPI
-- Game: AppID 3391750

-- MAIN APPLICATION
addappid(3391750)
-- Game: addappid(3391750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391751, 1, "8b4c6e62bec7d55bd334cbbf5cbb2df1369ecf54c4282618ca6ce93c4fc1290e")
