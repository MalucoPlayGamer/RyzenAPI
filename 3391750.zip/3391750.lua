-- Lua provided by RyzenAPI
-- Game: THE EXPERIMENT: 49

-- MAIN APPLICATION
addappid(3391750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3391751, 1, "8b4c6e62bec7d55bd334cbbf5cbb2df1369ecf54c4282618ca6ce93c4fc1290e")

