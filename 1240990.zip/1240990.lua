-- Lua provided by RyzenAPI
-- Game: The Coma 2: Vicious Sisters DLC - Mina - Gamer Girl Skin

-- MAIN APPLICATION
addappid(1240990)
-- Game: addappid(1240990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240991, 1, "a27a566f3424c7bb478657cef4afdd506a81aae3a03a7db80bba1dfd608ecd29")
