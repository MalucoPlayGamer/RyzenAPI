-- Lua provided by SkyAPI 
-- Game: AppID 362300
addappid(362300)
addappid(362301, 1, "61c27c1cf1ff368923cc6ed1cc60980293cd59b3cab2fc86742e241e2a6b5a7d")
