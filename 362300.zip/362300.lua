-- Lua provided by RyzenAPI
-- Game: Game: AppID 362300

-- MAIN APPLICATION
addappid(362300)
-- Game: addappid(362300)

-- MAIN APP DEPOTS / PACKAGES
addappid(362301, 1, "61c27c1cf1ff368923cc6ed1cc60980293cd59b3cab2fc86742e241e2a6b5a7d")
