-- Lua provided by RyzenAPI
-- Game: Game Store Simulator

-- MAIN APPLICATION
addappid(2598930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598932,0,"06e58a1cfa8959a0b23a7bc3c7598a1076ca51b9abef8a1a5688db46eecf7919")
