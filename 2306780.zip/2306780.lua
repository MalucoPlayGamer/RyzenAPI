-- Lua provided by RyzenAPI
-- Game: Spellshot

-- MAIN APPLICATION
addappid(2306780)
-- Game: addappid(2306780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306781, 1, "dae8e3689f0b47fdf6b949856b42413912653a3d95567e8ac67cba5bf383a487")
