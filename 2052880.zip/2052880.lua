-- Lua provided by RyzenAPI
-- Game: Unoffensible Demo

-- MAIN APPLICATION
addappid(2052880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052881, 1, "c3528c33837c9c5c566440283f4b7c389c2d93f61e3c30705fe40e30b1fc106f")
