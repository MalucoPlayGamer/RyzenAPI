-- Lua provided by RyzenAPI
-- Game: 335350

-- MAIN APPLICATION
addappid(335350)
addappid(335351)

-- MAIN APP DEPOTS / PACKAGES
addappid(335350,0,"a605035ead2a4ed13a7c611aeee3c48bc1d8cb66ab73f9e698f0ea6c10516612")

