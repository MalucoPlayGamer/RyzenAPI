-- Lua provided by RyzenAPI
-- Game: MO:Astray Original Soundtrack

-- MAIN APPLICATION
addappid(1171380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171380,0,"11952682392d4b3553cac5d532211496ac0aa66e669226c4345688b0144176b3")

