-- Lua provided by RyzenAPI
-- Game: Game: AppID 2824150

-- MAIN APPLICATION
addappid(2824150)
-- Game: addappid(2824150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824151, 1, "98679d3ff914e617d1402234578055da34cf24b26c05d7514738bf1fdb38cf10")
