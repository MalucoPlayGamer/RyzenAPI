-- Lua provided by RyzenAPI
-- Game: The Hotel

-- MAIN APPLICATION
addappid(2134970)
-- Game: addappid(2134970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134971, 1, "d5b28c8a038fbd14c99df726dfd034f1f7f9ceb4de862b75c384639179ac4133")
