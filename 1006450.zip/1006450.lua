-- Lua provided by RyzenAPI 
-- Game: AppID 1006450
addappid(1006450)
addappid(1006451, 1, "4553571c939e52da1a67eb7d133961d6e711c95a7f15056e18f3bfda1756dfb1")
