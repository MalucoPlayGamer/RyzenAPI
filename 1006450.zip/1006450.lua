-- Lua provided by RyzenAPI
-- Game: Eric The Unready

-- MAIN APPLICATION
addappid(1006450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006451, 1, "4553571c939e52da1a67eb7d133961d6e711c95a7f15056e18f3bfda1756dfb1")

