-- Lua provided by RyzenAPI
-- Game: 主公請躺好

-- MAIN APPLICATION
addappid(4639770)

