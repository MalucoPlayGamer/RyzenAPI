-- Lua provided by RyzenAPI
-- Game: Immortal Family

-- MAIN APPLICATION
addappid(2013240)
addappid(2013243)
addappid(2013244)
-- Game: addappid(2013240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013242,0,"78c4c4307942d5dc5c8c85609dd998b930de2039cd178e39c41b321564eba810")
