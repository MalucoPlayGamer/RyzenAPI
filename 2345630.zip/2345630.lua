-- Lua provided by RyzenAPI
-- Game: The Gap

-- MAIN APPLICATION
addappid(2345630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345635,0,"bcf57bf077aeacc109a1d9532869ad3ea499ad385bc059504eacb989b078686c")
