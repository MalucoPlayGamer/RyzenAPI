-- Lua provided by RyzenAPI
-- Game: The Antidote

-- MAIN APPLICATION
addappid(1026080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026081, 1, "8507c8ae85990e70dcbf96d2633e51ea12e57505bed9faff3ecb05d8e1a67856")

