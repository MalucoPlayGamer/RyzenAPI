-- Lua provided by RyzenAPI
-- Game: Game: Where Birds 鸟儿在哪里

-- MAIN APPLICATION
addappid(994270)
-- Game: addappid(994270)

-- MAIN APP DEPOTS / PACKAGES
addappid(994271, 1, "41abdd2971d54e6b0cff94f47836c7f7023c3673355980ea3f8e78754491219a")
