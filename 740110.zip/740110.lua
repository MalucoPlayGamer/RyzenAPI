-- Lua provided by RyzenAPI
-- Game: addappid(740110)

-- MAIN APPLICATION
addappid(740110)

-- MAIN APP DEPOTS / PACKAGES
addappid(740111, 1, "50e3f839809a54afffeb9ac7b58015217cefc618dc3bceb502a1112a79081fe4")
