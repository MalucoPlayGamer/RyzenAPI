-- Lua provided by RyzenAPI
-- Game: Quixzel Rush: Tooth Protector

-- MAIN APPLICATION
addappid(942560)

-- MAIN APP DEPOTS / PACKAGES
addappid(942561, 1, "a1075a6b429595e6ca1c71175e2cd54500333b7b177830dc3c6515287962b1fb")

