-- Lua provided by RyzenAPI
-- Game: Infinite Seek and Find

-- MAIN APPLICATION
addappid(2511440)
-- Game: addappid(2511440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511441, 1, "1de73551d8ec5b327466baabccfde89046cfd9526f9c427cd33a6208091c2442")
