-- Lua provided by RyzenAPI
-- Game: addappid(2084720)

-- MAIN APPLICATION
addappid(2084720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084721, 1, "1f10d1c46f06b219072ca11152cf6f2e1f8d1e5d43ca232c78fe80a543a9aeac")
