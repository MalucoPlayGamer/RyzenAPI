-- Lua provided by RyzenAPI
-- Game: Everest Truck Simulator

-- MAIN APPLICATION
addappid(2139690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139691, 1, "3b9fbce6b5b7558f675150a12f0c8030cc60bf17324f5c977d6f3577224f424c")
