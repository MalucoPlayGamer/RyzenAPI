-- Lua provided by RyzenAPI
-- Game: Shooter's Island

-- MAIN APPLICATION
addappid(1819770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819771, 1, "2a500693ad6f6df9b2837e02789a97a3b13e5bb437b20be3efbd45e7f8f83692")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
