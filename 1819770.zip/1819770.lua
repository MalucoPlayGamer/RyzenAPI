-- Lua provided by RyzenAPI
-- Game: Shooter's Island

-- MAIN APPLICATION
addappid(1819770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819771, 1, "2a500693ad6f6df9b2837e02789a97a3b13e5bb437b20be3efbd45e7f8f83692")
