-- Lua provided by RyzenAPI
-- Game: 100 Christmas Cats

-- MAIN APPLICATION
addappid(2687190)
addappid(2692090)
addappid(2692100)
addappid(2692110)
addappid(2692120)
addappid(2692130)
addappid(2692140)
addappid(2692150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687191, 1, "16f6b815ebcac62da42b90accfb022f17e47148eea39258cbf7039f99ceb928a")