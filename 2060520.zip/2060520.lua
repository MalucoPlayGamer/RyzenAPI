-- Lua provided by RyzenAPI
-- Game: AppID 2060520

-- MAIN APPLICATION
addappid(2060520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060521, 1, "4f66790e6e68bf981f65207d212b1ad90f38d6841f1d0a70b625888ca49ff46e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
