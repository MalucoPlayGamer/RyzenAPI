-- Lua provided by RyzenAPI
-- Game: Game: AppID 2060520

-- MAIN APPLICATION
addappid(2060520)
-- Game: addappid(2060520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060521, 1, "4f66790e6e68bf981f65207d212b1ad90f38d6841f1d0a70b625888ca49ff46e")
