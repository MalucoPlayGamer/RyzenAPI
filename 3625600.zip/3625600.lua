-- Lua provided by RyzenAPI
-- Game: Game: The Magnificent Scoundrels

-- MAIN APPLICATION
addappid(3625600)
-- Game: addappid(3625600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3625601, 1, "a80e9cc58abd1c5a3b159a1882642265216aed0480f1067b011e1a5b3c94a194")
