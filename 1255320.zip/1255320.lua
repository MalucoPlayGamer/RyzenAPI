-- Lua provided by RyzenAPI
-- Game: Strip Card Duel

-- MAIN APPLICATION
addappid(1255320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255321, 1, "5e8e61b9e863977aa61d49ea6d8e449c0a6e2327a5f80815fec1ea50cf5c71cc")

