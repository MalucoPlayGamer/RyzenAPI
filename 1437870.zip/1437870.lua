-- Lua provided by RyzenAPI
-- Game: Heroes of the Three Kingdoms 6

-- MAIN APPLICATION
addappid(1437870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437871, 1, "081692bfb8df8ae6cf2e69e4c081c1482025721f5e9769c3c16b4236cf6c03a5")
addappid(1437872, 1, "89dfb518d96b4ce7ed8cfec081c4d7bae52a6f246452dc425b659f6c37fd1129")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
