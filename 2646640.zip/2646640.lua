-- Lua provided by RyzenAPI
-- Game: Lost Chapter -With You-

-- MAIN APPLICATION
addappid(2646640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646641, 1, "15833ce558facb5ab734d163578623653f87c6829d0ef7cba492550c086bc475")

