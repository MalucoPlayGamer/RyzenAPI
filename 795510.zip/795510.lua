-- Lua provided by SkyAPI 
-- Game: AppID 795510
addappid(795510)
addappid(795511, 1, "ef2a2250d288312f80a7e45694d19863377c2a145039bb3ec1cedbe63d7b0929")
addappid(1603560, 0, "d9c1a26df682afc4b19953bb2cd4f56dd2032e44572c50bacf48b9457810823a")
