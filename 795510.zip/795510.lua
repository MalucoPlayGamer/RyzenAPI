-- Lua provided by RyzenAPI
-- Game: AppID 795510

-- MAIN APPLICATION
addappid(795510)

-- MAIN APP DEPOTS / PACKAGES
addappid(795511, 1, "ef2a2250d288312f80a7e45694d19863377c2a145039bb3ec1cedbe63d7b0929")
addappid(1603560, 0, "d9c1a26df682afc4b19953bb2cd4f56dd2032e44572c50bacf48b9457810823a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
