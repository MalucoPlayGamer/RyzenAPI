-- Lua provided by RyzenAPI
-- Game: 3220800

-- MAIN APPLICATION
addappid(3220800)
-- Game: addappid(3220800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220802,0,"e92db1229fd0399f7b1e2e9318a63fa81259382b91dba3f8ff52c232f0f618c6")
