-- Lua provided by RyzenAPI
-- Game: 400200

-- MAIN APPLICATION
addappid(400200)
-- Game: addappid(400200)

-- MAIN APP DEPOTS / PACKAGES
addappid(400201, 1, "df022c2a2a6ca83a97072866515f90bfa21dcb4bc3f40391b874d6919b22840e")
addappid(400202, 1, "225af8a4beb45faeaba59aed99a1b13d706bd9196039512bc9c173568469d4a6")
addappid(400203, 1, "5bbcb925a4a40e45affd95884ac7bddaf36da517d1a921b9f6c37b083cd05df5")
addappid(400204, 1, "96c2b1840092f16f04edce45b00262104d742e7d7211acdf50d503efed00287d")
addappid(400205, 1, "c7da3f9d4c8d69dc6b33c31f0d3bd795604fd668d9ce72aabb93783d02aab7b6")
addappid(400206, 1, "c358202dab1349dce39b89eb9658e2b734ae9f94d866f557fb0f4f0ede5d1b85")
