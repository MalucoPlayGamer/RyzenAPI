-- Lua provided by RyzenAPI
-- Game: Game: Desktop Kitten Girl

-- MAIN APPLICATION
addappid(3449850)
-- Game: addappid(3449850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449851, 1, "3d36eeb9cea7c107304e908d5021dbe98471d6ecadb6972491f3d71b371c79f5")
