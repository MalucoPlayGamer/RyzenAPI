-- Lua provided by RyzenAPI 
-- Game: AppID 1371470
addappid(1371470)
addappid(1371471, 1, "9b826a8f5e0f629101aa685981cfa2b61e7078c251a355885245381fb992746f")
