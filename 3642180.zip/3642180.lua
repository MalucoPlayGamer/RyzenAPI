-- Lua provided by RyzenAPI
-- Game: Game: Cultivation Magic World

-- MAIN APPLICATION
addappid(3642180)
-- Game: addappid(3642180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642181, 1, "31fa4fc571596e5434281616e0ff5d3514b2d092324d3091b795b6051037eb2d")
