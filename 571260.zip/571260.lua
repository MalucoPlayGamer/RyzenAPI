-- Lua provided by RyzenAPI
-- Game: addappid(571260)

-- MAIN APPLICATION
addappid(571260)

-- MAIN APP DEPOTS / PACKAGES
addappid(571261, 1, "457e4521ec8293fcea5ce3c49d3793c9871ebffaea2088be5114fefe807be81f")
addappid(571263, 1, "1f6447e3daf3057072b1ee1dc7d3c3a3a5596d3dd89bf4f29d8d863bfd996f1c")
addappid(571264, 1, "1b6a174f702f7fdfb5ddd6ff37f9d6388fb7c12405a76bc6d904c031601b1130")
