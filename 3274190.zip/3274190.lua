-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Bossfight - "Endgame"

-- MAIN APPLICATION
addappid(3274190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274190,0,"3c440bc5248697139c0264ab2a571d30f006d917777e1d24911dfb03a5731931")

