-- Lua provided by RyzenAPI
-- Game: addappid(1002800)

-- MAIN APPLICATION
addappid(1002800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002801, 1, "afdee6b474262495caa484bd2593f9013bc8469dde67b4e7570d6e857a891d62")
