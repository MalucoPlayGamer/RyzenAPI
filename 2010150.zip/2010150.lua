-- Lua provided by RyzenAPI
-- Game: Blast Off Far Away

-- MAIN APPLICATION
addappid(2010150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010151, 1, "ec85f15309a3c0420852598257aa6cfaaf879835e5109e2ca4138e100329bf86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
