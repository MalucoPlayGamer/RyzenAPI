-- Lua provided by RyzenAPI
-- Game: Blast Off Far Away

-- MAIN APPLICATION
addappid(2010150)
-- Game: addappid(2010150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010151, 1, "ec85f15309a3c0420852598257aa6cfaaf879835e5109e2ca4138e100329bf86")
