-- Lua provided by RyzenAPI
-- Game: Abyssal Zone

-- MAIN APPLICATION
addappid(537380)

-- MAIN APP DEPOTS / PACKAGES
addappid(537382,0,"17986576df540a3126ec51184d2a6aa1476101ee0cd003033daf00baaf04bdcf")

