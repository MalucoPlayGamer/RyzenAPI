-- Lua provided by RyzenAPI
-- Game: addappid(319510)

-- MAIN APPLICATION
addappid(319510)

-- MAIN APP DEPOTS / PACKAGES
addappid(319511, 1, "1c9bdb805e961c88bff8090d7a3047fc4932948393b4a0d0939cc84ccbe542c4")
