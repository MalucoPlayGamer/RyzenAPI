-- Lua provided by RyzenAPI
-- Game: 1892620

-- MAIN APPLICATION
addappid(1892620)
-- Game: addappid(1892620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892621, 1, "54426f43e845d89664f0635a9dc2e81d9d52d637fd0965ea3d3ccab61096e5f8")
