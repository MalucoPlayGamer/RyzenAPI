-- Lua provided by SkyAPI 
-- Game: CEO
addappid(1892620)
addappid(1892621, 1, "54426f43e845d89664f0635a9dc2e81d9d52d637fd0965ea3d3ccab61096e5f8")
