-- Lua provided by RyzenAPI
-- Game: Game: Cosmos

-- MAIN APPLICATION
addappid(1209570)
-- Game: addappid(1209570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209571, 1, "6007ca1abe8d08f382995caabc3e19b58900aeb1433c5f8b8c80e3845c590135")
