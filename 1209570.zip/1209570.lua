-- Lua provided by RyzenAPI
-- Game: Cosmos

-- MAIN APPLICATION
addappid(1209570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1209571, 1, "6007ca1abe8d08f382995caabc3e19b58900aeb1433c5f8b8c80e3845c590135")

