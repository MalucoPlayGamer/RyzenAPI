-- Lua provided by RyzenAPI
-- Game: Unclean Water

-- MAIN APPLICATION
addappid(4328400)
addappid(4830520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4328401,0,"829302585b55e491c2a06914cf255fd0d71c3dd3b1a0a88186fcf59ff688f71b")
addappid(4830521,0,"fa2f234fd6ad0001d94cdf0b503dd078575d63c6aeabcdf682e8425f1b71f188")

