-- Lua provided by RyzenAPI
-- Game: Unclean Water

-- MAIN APPLICATION
addappid(4328400)
addappid(4830520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4328401,0,"829302585b55e491c2a06914cf255fd0d71c3dd3b1a0a88186fcf59ff688f71b")
addappid(4830521,0,"fa2f234fd6ad0001d94cdf0b503dd078575d63c6aeabcdf682e8425f1b71f188")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
