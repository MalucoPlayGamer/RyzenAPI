-- Lua provided by RyzenAPI 
-- Game: Bankrupt Heroines 2
addappid(1641860)
addappid(1641861, 1, "2feced95c6cf8a3591912067b8a7ce0fa874fd0ac090f62547e4a6bf1454de61")
addappid(1861140)
