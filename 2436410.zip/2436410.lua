-- Lua provided by RyzenAPI
-- Game: Asfalia: Panic at the Mansion

-- MAIN APPLICATION
addappid(2436410)
-- Game: addappid(2436410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436411, 1, "9d48d510e5756091af1456844506129ad9d06519ce39afdc46ea0dac17cf9e80")
