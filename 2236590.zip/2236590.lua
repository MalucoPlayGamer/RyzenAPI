-- Lua provided by RyzenAPI
-- Game: Psionic Awake

-- MAIN APPLICATION
addappid(2236590)
-- Game: addappid(2236590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236591, 1, "59cf90fddc4a9617c9500127016065447536f681ee9a8bd78aefaa2c390a9db2")
