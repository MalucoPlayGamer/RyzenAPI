-- Lua provided by RyzenAPI
-- Game: Industry Giant 4.0 Demo

-- MAIN APPLICATION
addappid(2913720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913721, 1, "4d5a76cacd77a0758944d66b1c458c09045912b412d34ef33cd25a85b9cf8d46")
