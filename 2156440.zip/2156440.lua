-- Lua provided by RyzenAPI
-- Game: addappid(2156440)

-- MAIN APPLICATION
addappid(2156440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156441, 1, "f601a4cf8ff962ad3ee4b3ed19777f4eec6fe4764ab0e00d50e8b4cf0806d971")
