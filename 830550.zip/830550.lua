-- Lua provided by RyzenAPI
-- Game: 830550

-- MAIN APPLICATION
addappid(830550)
-- Game: addappid(830550)

-- MAIN APP DEPOTS / PACKAGES
addappid(830551, 1, "afe4d49ac8e9d48688cff7d3b256dd934f54b001de24d511527ace744bdfa1ab")
