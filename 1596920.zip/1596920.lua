-- Lua provided by RyzenAPI
-- Game: Play Me

-- MAIN APPLICATION
addappid(1596920)
-- Game: addappid(1596920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596921, 1, "3f552a389fc9d2662999def551af171629f31b4ecb2d431a931564cb4c51e066")
