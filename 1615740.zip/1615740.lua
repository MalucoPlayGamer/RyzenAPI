-- Lua provided by RyzenAPI
-- Game: Machina Blade

-- MAIN APPLICATION
addappid(1615740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615741, 1, "7272ae98c419486768d52b7faa754559d848b51cd718b171fe6a8bb4f9b86230")

