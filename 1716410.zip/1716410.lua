-- Lua provided by SkyAPI 
-- Game: Leaf Blower Revolution - Idle Game Soundtrack
addappid(1716410)
addappid(1716411, 1, "aada1f011c66c342961aa1e298a47a3299783053dff12dab7778f641c29a7f7e")
