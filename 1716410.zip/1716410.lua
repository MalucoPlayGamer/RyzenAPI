-- Lua provided by RyzenAPI
-- Game: Leaf Blower Revolution - Idle Game Soundtrack

-- MAIN APPLICATION
addappid(1716410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716411, 1, "aada1f011c66c342961aa1e298a47a3299783053dff12dab7778f641c29a7f7e")
