-- Lua provided by RyzenAPI 
-- Game: Indemon Tales
addappid(2426020)
addappid(2426021, 1, "bbb4130ba5af31269757e2a3ec0b87f75564c0f2300683b21226e4f2075d677d")
addappid(2426022, 1, "c589634e2132f4b8c130362d84141b9eecc6da69bfcd24a8a2ed80eccfa073e0")
addappid(2426023, 1, "5510aa934183736831280d66a34db3f6223dcda4205ab2de9add0568b8bc5b42")
