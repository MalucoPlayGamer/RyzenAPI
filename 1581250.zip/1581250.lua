-- Lua provided by RyzenAPI
-- Game: 1581250

-- MAIN APPLICATION
addappid(1581250)
-- Game: addappid(1581250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581251, 1, "abc5aa0880775499054d048622c94e5d113def0b0f3e10e26365f13acb7ca973")
