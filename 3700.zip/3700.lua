-- Lua provided by RyzenAPI
-- Game: Game: Sniper Elite

-- MAIN APPLICATION
addappid(3700)
-- Game: addappid(3700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3701, 1, "535f4cba404b22f5ce7fc6ed687cf022eb4de1e640f964e4d35fa2e473cae76e")
addappid(3702, 1, "d464e59e6ed97b394f7537dbe28658a9539b1d21c8df6a9b868f6e3bacb11925")
addappid(3703, 1, "888172488b9aa7a1191f9dcc485885003b94be3711d70922e950efc597cae8d5")
addappid(3704, 1, "8d368f66c59e361b008cd6872b00fa1d04d8664ec5009239a856a9ecba5c477b")
addappid(3705, 1, "a72c60f05cada2a1944bb6cb4cd89f1cc925945f10268b98248905db9f17aca0")
addappid(3706, 1, "dce1c067de526e2cd9584f97694b817cd48af7efea15739c61988430c46a8ae3")
addappid(3707, 1, "d6c068fa51718456573ce0e6aa65f8d3033ce628cc7e07e63c2bd5ade255b96a")
