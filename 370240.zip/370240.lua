-- Lua provided by RyzenAPI 
-- Game: AppID 370240
addappid(370240)
addappid(370241, 1, "2834e0599f82797bd1af42488a12abeb892bd2d3e9a8ce684fd601e6e56c1cab")
