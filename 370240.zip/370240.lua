-- Lua provided by RyzenAPI
-- Game: NBA 2K16

-- MAIN APPLICATION
addappid(370240)
addappid(386720)
addappid(386721)
addappid(486710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(370241, 1, "2834e0599f82797bd1af42488a12abeb892bd2d3e9a8ce684fd601e6e56c1cab")

