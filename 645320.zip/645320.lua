-- Lua provided by RyzenAPI
-- Game: SCARF

-- MAIN APPLICATION
addappid(645320)

-- MAIN APP DEPOTS / PACKAGES
addappid(645321, 1, "89e6b2a2745e11dea439171d1523bd56f7c6a104a187ff1ca4ab761a4b735dcd")
