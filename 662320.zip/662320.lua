-- Lua provided by RyzenAPI
-- Game: addappid(662320)

-- MAIN APPLICATION
addappid(662320)
addappid(758910)

-- MAIN APP DEPOTS / PACKAGES
addappid(662321, 1, "e989ad8fed45237f00706d94aabc0fdfff0173960081bef53ab5d018321e42b9")
