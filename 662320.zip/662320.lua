-- Lua provided by RyzenAPI
-- Game: METRO CONFLICT: THE ORIGIN

-- MAIN APPLICATION
addappid(662320)
addappid(758910)
addappid(773971)
addappid(779530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(662321, 1, "e989ad8fed45237f00706d94aabc0fdfff0173960081bef53ab5d018321e42b9")

