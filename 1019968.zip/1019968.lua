-- Lua provided by RyzenAPI
-- Game: 1019968

-- MAIN APPLICATION
addappid(1019968)
-- Game: addappid(1019968)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019968,0,"941c9368a2eb3f6ec0ea8bb558847f580b16e24cbee51768461a96b77b66895c")
