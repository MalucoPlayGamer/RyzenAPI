-- Lua provided by RyzenAPI
-- Game: Into the Radius - Supporter Pack

-- MAIN APPLICATION
addappid(2229750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229750,0,"a30351996d59b5ec4c792ed85a391f154765052502c708728911ed3a2d5ad206")

