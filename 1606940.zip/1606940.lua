-- Lua provided by RyzenAPI
-- Game: addappid(1606940)

-- MAIN APPLICATION
addappid(1606940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606942,0,"b4ab3d16db5cc0752bc7450c9308304a516a82bcc912741725ffba445b0d6db7")
