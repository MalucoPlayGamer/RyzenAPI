-- Lua provided by RyzenAPI
-- Game: Runaway, The Dream of The Turtle

-- MAIN APPLICATION
addappid(7220)

-- MAIN APP DEPOTS / PACKAGES
addappid(7226,0,"08b04a0df765e2c514eb95729e9d5e79e8dcf6df089422a6a8dc5ef81954b11a")
addappid(7227,0,"1aa6342004267966847c4fd35631c02c83f155b02f8c3efd2a0f59ad93d9a6cb")
addappid(7228,0,"9281ff6e7cdddcc24553786854878ffee2485282fdf6e6c3c47653c4d7363c11")
