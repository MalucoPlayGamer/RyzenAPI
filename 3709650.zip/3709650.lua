-- Lua provided by RyzenAPI
-- Game: Game: The Love's Ordeal

-- MAIN APPLICATION
addappid(3709650)
-- Game: addappid(3709650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709651, 1, "c594788bd01ce7c13f459d4db3667ec01117680e02406483dd4ded311db09945")
addappid(3709652, 1, "b11678f8c0396a4f942844f98dbb9a37f62abf00c29c7c0266daba90bf0d96c7")
addappid(3709653, 1, "86a7803b7522f7e399f72aae6d14b3f8204781f4b7f92fd22b1c17242a7f1fd0")
addappid(3709654, 1, "50f0799aa01ea05a0a74895138e230b94f48b1bd55de7ed97f1e8e52c2c5cbb1")
