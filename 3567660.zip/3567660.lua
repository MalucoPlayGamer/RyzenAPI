-- Lua provided by RyzenAPI
-- Game: Game: Funfair Billionaire

-- MAIN APPLICATION
addappid(3567660)
-- Game: addappid(3567660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3567661, 1, "6447bf0f938fb7907d54a49967929ee526e7da133ac6054e78222ddcd5406a37")
