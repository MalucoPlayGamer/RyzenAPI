-- Lua provided by RyzenAPI
-- Game: Game: AppID 765650

-- MAIN APPLICATION
addappid(765650)
-- Game: addappid(765650)

-- MAIN APP DEPOTS / PACKAGES
addappid(765651, 1, "a48e2f797c61fe1a83bc27485c1292afe5a5deb811fbc39a4f45a5e653a47c8e")
