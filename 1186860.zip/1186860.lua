-- Lua provided by RyzenAPI
-- Game: Game: AppID 1186860

-- MAIN APPLICATION
addappid(1186860)
-- Game: addappid(1186860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186861, 1, "3ccb28e304edd0ead286d31b829521df83e00deb2c1c3aa5a69f85ebe458ba1e")
