-- Lua provided by RyzenAPI
-- Game: 反现实症候群γ - Counterrealstic Syndrome γ

-- MAIN APPLICATION
addappid(1186860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1186861, 1, "3ccb28e304edd0ead286d31b829521df83e00deb2c1c3aa5a69f85ebe458ba1e")

