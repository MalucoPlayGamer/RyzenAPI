-- Lua provided by RyzenAPI
-- Game: Cosplay Cumdump: Doing it Doujin Style

-- MAIN APPLICATION
addappid(2956310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956311, 1, "62e5a0f7f6e4e351bcfc8a76c43400ff656d0e5d317c471b96d2c5739876d364")
addappid(2956312, 1, "b1e812f50599e23c56e3d07f86cc8ca64a5109d8ac6417d6f08132b360c35805")
