-- Lua provided by RyzenAPI
-- Game: 574120

-- MAIN APPLICATION
addappid(574120)
-- Game: addappid(574120)

-- MAIN APP DEPOTS / PACKAGES
addappid(574122,0,"64ac17e0e8e060dbd03628945f48a391daae298a9ce24165dd45197403a04e11")
