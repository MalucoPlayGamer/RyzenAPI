-- Lua provided by RyzenAPI
-- Game: Симулятор Сидения у Подъезда: Online

-- MAIN APPLICATION
addappid(1216640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216640,0,"e33f0c68a04c922d487470fc31e9941bb5e7b40a8b34796ae8aa6e8786f3a283")

