-- 4208140's Lua and Manifest Created by Hubcap Manifest
-- Defender of the Crown: The Legend Returns
-- Created: August 13, 2026 at 10:29:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4208140) -- Defender of the Crown: The Legend Returns
-- MAIN APP DEPOTS
addappid(4208141, 1, "da5643bdc78c5b4a31bbf5c1d593ac91b6156e245f03b928460fb0589a73f351") -- Depot 4208141
setManifestid(4208141, "1646216619570594309", 926936466)