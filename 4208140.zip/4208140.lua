-- Lua provided by RyzenAPI
-- Game: Defender of the Crown: The Legend Returns

-- MAIN APPLICATION
addappid(4208140) -- Defender of the Crown: The Legend Returns

-- MAIN APP DEPOTS / PACKAGES
addappid(4208141, 1, "da5643bdc78c5b4a31bbf5c1d593ac91b6156e245f03b928460fb0589a73f351") -- Depot 4208141

