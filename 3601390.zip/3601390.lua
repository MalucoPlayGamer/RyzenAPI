-- Lua provided by RyzenAPI
-- Game: addappid(3601390)

-- MAIN APPLICATION
addappid(3601390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601390,0,"64ba32802db186b2061a124acd28e1c105394eaee551f5249aa0bdba82704e39")
