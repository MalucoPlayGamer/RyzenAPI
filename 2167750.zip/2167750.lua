-- Lua provided by RyzenAPI
-- Game: The Demon Within Me

-- MAIN APPLICATION
addappid(2167750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2167751, 1, "db46350c96d34da3d0f707f86ea9e326bff51d0138dbadec802bbc1fa390946f")

