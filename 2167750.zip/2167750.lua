-- Lua provided by RyzenAPI
-- Game: The Demon Within Me

-- MAIN APPLICATION
addappid(2167750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167751, 1, "db46350c96d34da3d0f707f86ea9e326bff51d0138dbadec802bbc1fa390946f")
