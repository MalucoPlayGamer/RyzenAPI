-- Lua provided by RyzenAPI
-- Game: Summer For You - Exciting Animations Pack

-- MAIN APPLICATION
addappid(3213520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213520,0,"bbf16c6c8f2052b8ba69d170e174f43908b23184bd5bcc7a826c8dd38b7f43e6")

