-- Lua provided by SkyAPI 
-- Game: AppID 1373510
addappid(1373510)
addappid(1373511, 1, "1656da2f40de519eabcff0dc39322978f16a1c017214f1c89c068cabec08f63f")
addappid(1373512, 1, "9b5167dea57d9d726e026caac17eeb3cd11b383b9488efee075c7a0f4b6e537f")
