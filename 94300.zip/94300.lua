-- Lua provided by RyzenAPI
-- Game: Game: The Dream Machine: Chapter 1 & 2

-- MAIN APPLICATION
addappid(94300)
addappid(228988)
-- Game: addappid(94300)

-- MAIN APP DEPOTS / PACKAGES
addappid(94301, 1, "611224ca3044804065c0b9a7ca5d424e027857f8687038244b88f5fbbaea9143")
addappid(94302, 1, "023206ddbd64f73a9a8e1c4bb2c1f889c1b87949fe7fa10c5898367d35c0f4d5")
addappid(94303, 1, "3c7de5c76540bbba37ff14cc26c9d95e2ec8999e1ff1a1039197d48bce419468")
addappid(94304, 1, "3a8baefc9827cbd2f540d21f094299b515ac25c3e06241730ed11a8ddde35a79")
addappid(330260, 0, "172a9f19ac36ee56e75f200664fb1627ca55b70ed4c9b2421cc60f51ad7140eb")
addappid(461900, 0, "c6821405c172a08da6108962716809c6eafacd09ee7251bb5091aa61828ca3bd")
