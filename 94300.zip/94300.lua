-- Lua provided by RyzenAPI
-- Game: The Dream Machine

-- MAIN APPLICATION
addappid(93305)
addappid(94300)

-- MAIN APP DEPOTS / PACKAGES
addappid(94301,0,"611224ca3044804065c0b9a7ca5d424e027857f8687038244b88f5fbbaea9143")
addappid(94302,0,"023206ddbd64f73a9a8e1c4bb2c1f889c1b87949fe7fa10c5898367d35c0f4d5")
addappid(94303,0,"3c7de5c76540bbba37ff14cc26c9d95e2ec8999e1ff1a1039197d48bce419468")
addappid(94304,0,"3a8baefc9827cbd2f540d21f094299b515ac25c3e06241730ed11a8ddde35a79")
addappid(330260,0,"172a9f19ac36ee56e75f200664fb1627ca55b70ed4c9b2421cc60f51ad7140eb")
addappid(461900,0,"c6821405c172a08da6108962716809c6eafacd09ee7251bb5091aa61828ca3bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
