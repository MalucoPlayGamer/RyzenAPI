-- Lua provided by RyzenAPI
-- Game: Malyshka

-- MAIN APPLICATION
addappid(1684440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684441, 1, "c028e20a1d7e17fa34eb04b605db7a6337b720cbcda0c5942aae4ebebe74d8a9")

