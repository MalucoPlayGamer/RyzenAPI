-- Lua provided by RyzenAPI
-- Game: Game: Out Of The Shelter

-- MAIN APPLICATION
addappid(1557100)
-- Game: addappid(1557100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557101, 1, "8977609907e3debe5a5168fc9180b6495d6532c6e56db01d5103e9ab1d6f34ef")
