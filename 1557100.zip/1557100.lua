-- Lua provided by RyzenAPI
-- Game: Out Of The Shelter

-- MAIN APPLICATION
addappid(1557100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557101, 1, "8977609907e3debe5a5168fc9180b6495d6532c6e56db01d5103e9ab1d6f34ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
