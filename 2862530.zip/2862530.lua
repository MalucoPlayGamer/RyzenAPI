-- Lua provided by SkyAPI 
-- Game: Uberich: Advent Sinners Demo
addappid(2862530)
addappid(2862531, 1, "c3a57066b260b3b1ef6825aaf03c45370df0fd218373cb595e5994e9c1f93630")
addappid(2862533, 1, "487ad00a2b6dd32c9f33a23864ad57d62e55eab7dd894bb91cf80828dcfc0932")
