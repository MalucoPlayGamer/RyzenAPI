-- Lua provided by RyzenAPI
-- Game: 2022生存指南 2022 SURVIVAL GUIDE

-- MAIN APPLICATION
addappid(2196390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2196392,0,"bd404c1250803386045cc21bcbc77adddf45df84313d6d200263c2b7c4195136")
