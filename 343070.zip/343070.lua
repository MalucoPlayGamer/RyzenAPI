-- Lua provided by RyzenAPI
-- Game: 343070

-- MAIN APPLICATION
addappid(228984)
addappid(228990)
addappid(343070)
addappid(343071)
addappid(343074)
addappid(343076)
addappid(343077)
addappid(343078)

-- MAIN APP DEPOTS / PACKAGES
addappid(343072,0,"235ab9941a1965668cf7d8563bd092df3a3b291e7adab702a4ece12dd03fb5a1")
addappid(343073,0,"c325085eed33860a88f7c28df6b14ac83ae5d35f5698731693d93e62abc402b1")
addappid(343075,0,"0f89fa5dd0fbf59a5ce8755c6c542839f0f70d8a4940d5678338be82228a9edf")
