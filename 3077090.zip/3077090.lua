-- Lua provided by RyzenAPI
-- Game: addappid(3077090)

-- MAIN APPLICATION
addappid(3077090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077091, 1, "4e0ada64ff8b079e2be726b245d30cfe4970b605daea17f18707e1292ede9b7b")
