-- Lua provided by RyzenAPI
-- Game: Game: Heliopedia

-- MAIN APPLICATION
addappid(1740070)
-- Game: addappid(1740070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740071, 1, "b2357250c6db98ac0564bec8ec86daf0f04bff0a895456850e3f056127ffb9ec")
addappid(1740072, 1, "4369d1dc6dbd348f425537e8d5dff98fd64568e4c5140914223bdbc4826f9270")
