-- Lua provided by RyzenAPI
-- Game: F-1 drive

-- MAIN APPLICATION
addappid(369620)

-- MAIN APP DEPOTS / PACKAGES
addappid(369621, 1, "6bd1c2b98ad8f068f93fec86cd5ff62281972eb838edd9786ded20469d520eb1")
addappid(369622, 1, "e4da5f9a925d54b7fd0fae04595fb132da5e8ef729b443af788f638496e5a03e")
addappid(369625, 1, "3a632c7606f5cd9b6fa0e15cffd0c8a890e1a9c9913967f348311849c0221eea")
addappid(369627, 1, "9b85d9dc526f4e04787b46150be86f5910e2bc3cf6e9b1b408a63a1ec6e8a9fd")

