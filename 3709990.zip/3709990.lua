-- 3709990's Lua and Manifest Created by Hubcap Manifest
-- The tale of Bullet Knight
-- Created: August 10, 2026 at 14:56:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3709990) -- The tale of Bullet Knight
-- MAIN APP DEPOTS
addappid(3709991, 1, "6d68b71eaa70e3d94258ed10fbace633c90b502f207d2914196673820d29c0f3") -- Depot 3709991
setManifestid(3709991, "3416781798479149252", 814424442)