-- Lua provided by RyzenAPI
-- Game: The tale of Bullet Knight

-- MAIN APPLICATION
addappid(3709990) -- The tale of Bullet Knight

-- MAIN APP DEPOTS / PACKAGES
addappid(3709991, 1, "6d68b71eaa70e3d94258ed10fbace633c90b502f207d2914196673820d29c0f3") -- Depot 3709991

