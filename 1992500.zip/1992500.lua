-- Lua provided by RyzenAPI
-- Game: The Life of Arthur

-- MAIN APPLICATION
addappid(1992500)
-- Game: addappid(1992500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992501, 1, "99c04dafc361b7ee203648ecb4bbfaddf06c738ecd888d6637b299608e20bb3c")
