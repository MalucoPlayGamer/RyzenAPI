-- Lua provided by RyzenAPI
-- Game: 1816690

-- MAIN APPLICATION
addappid(1816690)
-- Game: addappid(1816690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816691, 1, "81417412c24a13b2a18d29e2cbf1a65cd75a6b819b469ba603f0ef8ce3915b5d")
