-- Lua provided by RyzenAPI
-- Game: Мафия Онлайн

-- MAIN APPLICATION
addappid(1906220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906221, 1, "2e75c15e72106add33c5f25d268157f478e648695a503bea2c5dc99601cd980c")
addappid(1906222, 1, "70fc8f3603e5cf199ffa3555d72c2367617ae89fa48561543747fb94f7c9aadb")

