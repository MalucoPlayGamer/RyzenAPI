-- Lua provided by RyzenAPI
-- Game: addappid(400380)

-- MAIN APPLICATION
addappid(400380)

-- MAIN APP DEPOTS / PACKAGES
addappid(400381, 1, "8206d6d485a3dca2fd48479019d8cd9a036851990739b11f979c5990a0ebf25e")
