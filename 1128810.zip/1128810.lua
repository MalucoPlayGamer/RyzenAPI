-- Lua provided by RyzenAPI
-- Game: AppID 1128810

-- MAIN APPLICATION
addappid(1128810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128811, 1, "9ccb2ca7005a41c1f75d8ac291405a92f2b86bc6c67d12bfe10c8c6e716cf703")
addappid(1128812, 1, "b107ccc3cf02948a0bf5a3424f9c0d1fdc08f1ec98b432f48ec5c810a48f0d86")

