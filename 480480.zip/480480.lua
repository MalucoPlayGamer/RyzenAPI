-- Lua provided by RyzenAPI
-- Game: Slash or Die

-- MAIN APPLICATION
addappid(480480)

-- MAIN APP DEPOTS / PACKAGES
addappid(480481, 1, "23d70df99f154d2c77b705c468ab174fac98942a8c1f909d9838a964042b9ef4")

