-- Lua provided by RyzenAPI
-- Game: addappid(1191820)

-- MAIN APPLICATION
addappid(1191820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191821, 1, "80d57dca9229ddc4324a18bb8cf8d90ec2b243c93d9b5a76be2d9bbd6b9df18c")
