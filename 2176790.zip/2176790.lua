-- Lua provided by SkyAPI 
-- Game: Furry Arena [18+]
addappid(2176790)
addappid(2176791, 1, "ddf154048b9a336f02af0bc7c1da7affc1f29a718a2adbac07879e588e8b91e4")
