-- Lua provided by RyzenAPI
-- Game: Vexius

-- MAIN APPLICATION
addappid(757190)

-- MAIN APP DEPOTS / PACKAGES
addappid(757191,0,"08e080bf167239bb5b3554108d1d31951fc2ac95bebadc11caca843e42aa639a")

