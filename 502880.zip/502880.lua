-- Lua provided by RyzenAPI
-- Game: Game: AppID 502880

-- MAIN APPLICATION
addappid(502880)
-- Game: addappid(502880)

-- MAIN APP DEPOTS / PACKAGES
addappid(502881, 1, "fe129894e7eb149f8132f2101bad15cce3a25f10aae207df97c5f387298fc7a0")
