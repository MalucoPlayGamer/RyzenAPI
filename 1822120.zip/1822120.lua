-- Lua provided by RyzenAPI
-- Game: Game: Life and Sex in Men's Сollege - Season 1 💕🔞

-- MAIN APPLICATION
addappid(1822120)
-- Game: addappid(1822120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822121, 1, "bd96fd89afd5496aeb0da997cee9953435052dc8dabe32bdc42ed75e2e69acfa")
