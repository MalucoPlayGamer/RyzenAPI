-- Lua provided by RyzenAPI
-- Game: Industrial Trouble

-- MAIN APPLICATION
addappid(1949780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949781, 1, "16e25458759932512679e2c2268ff55a1b894953968bc3ce376034e38b671a9a")

