-- Lua provided by RyzenAPI 
-- Game: AppID 1949780
addappid(1949780)
addappid(1949781, 1, "16e25458759932512679e2c2268ff55a1b894953968bc3ce376034e38b671a9a")
