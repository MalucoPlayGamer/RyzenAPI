-- Lua provided by RyzenAPI 
-- Game: Commandos 3: Destination Berlin
addappid(6840)
addappid(6841, 1, "8a28df1773996831e4279f14a94fb2115a6960ea2170a1f3cce5085680806951")
addappid(6842, 1, "3d3c0133c71319b01d5aa52a87562c6221b4315b076dbc95ec7b0be34cb2a866")
