-- Lua provided by RyzenAPI
-- Game: Bear Football

-- MAIN APPLICATION
addappid(674570)

-- MAIN APP DEPOTS / PACKAGES
addappid(674571, 1, "8b3cb1988abb91b6f15c481313bc1cfd6108c89bc584b58443c6159200ee8399")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
