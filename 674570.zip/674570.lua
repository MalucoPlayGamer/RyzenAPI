-- Lua provided by RyzenAPI 
-- Game: Bear Football
addappid(674570)
addappid(674571, 1, "8b3cb1988abb91b6f15c481313bc1cfd6108c89bc584b58443c6159200ee8399")
