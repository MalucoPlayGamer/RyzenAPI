-- Lua provided by RyzenAPI 
-- Game: The King of Creation
addappid(2655490)
addappid(2655491, 1, "e0f2f624a015c12a4e7763c0a2ab07ad17b2391bddff6e417cf46f0f8fba8de7")
