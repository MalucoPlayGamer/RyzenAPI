-- Lua provided by RyzenAPI 
-- Game: VRSailing by BeTomorrow
addappid(579050)
addappid(579051, 1, "c6e47a058ab8419eff068e1574c178ab3667ad698a4fa9fa3c00fbd056987234")
