-- Lua provided by RyzenAPI
-- Game: VRSailing by BeTomorrow

-- MAIN APPLICATION
addappid(579050)

-- MAIN APP DEPOTS / PACKAGES
addappid(579051, 1, "c6e47a058ab8419eff068e1574c178ab3667ad698a4fa9fa3c00fbd056987234")
