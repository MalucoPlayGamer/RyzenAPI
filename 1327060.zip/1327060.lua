-- Lua provided by RyzenAPI
-- Game: Selatria Demo

-- MAIN APPLICATION
addappid(1327060)
-- Game: addappid(1327060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327061, 1, "defb26bea3c7371a0018d16ad288871ac67e2974b0e39737268a45430d7adab9")
