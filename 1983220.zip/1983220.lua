-- Lua provided by RyzenAPI
-- Game: addappid(1983220)

-- MAIN APPLICATION
addappid(1983220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983221, 1, "88e6e701ee0361e8de509461f96a050abab2e00671402d937acd8f0d4ed82988")
