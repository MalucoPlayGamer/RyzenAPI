-- 411090's Lua and Manifest Created by Hubcap Manifest
-- Witness the Dark - Episode 1 - Bloody Burger
-- Created: August 11, 2026 at 11:37:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(411090) -- Witness the Dark - Episode 1 - Bloody Burger
-- MAIN APP DEPOTS
addappid(411091, 1, "abe42f53744eaa8e38d20454b9820409174a41e7a3e48c1cf00f0f4e3cb42222") -- Depot 411091
setManifestid(411091, "901202702035158728", 8168994020)