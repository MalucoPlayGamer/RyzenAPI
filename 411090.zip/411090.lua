-- Lua provided by RyzenAPI
-- Game: Witness the Dark - Episode 1 - Bloody Burger

-- MAIN APPLICATION
addappid(411090) -- Witness the Dark - Episode 1 - Bloody Burger

-- MAIN APP DEPOTS / PACKAGES
addappid(411091, 1, "abe42f53744eaa8e38d20454b9820409174a41e7a3e48c1cf00f0f4e3cb42222") -- Depot 411091

