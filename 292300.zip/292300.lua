-- Lua provided by RyzenAPI
-- Game: addappid(292300)

-- MAIN APPLICATION
addappid(292300)

-- MAIN APP DEPOTS / PACKAGES
addappid(292301, 1, "2f2c54154f786393d76ce5a01d8f61d123dd39392ecd9d6dc6d15a6d95b603b7")
addappid(292304, 1, "32e7ebd4a3ceec744c8e1e033d30d3cfd36cfd42b32acedced752c2162c23c99")
addappid(292305, 1, "0dfa8437f3ee16305fca51c248ad597a73125391f1aa4c430a6559706c41758f")
