-- Lua provided by RyzenAPI
-- Game: 433450

-- MAIN APPLICATION
addappid(433450)
-- Game: addappid(433450)

-- MAIN APP DEPOTS / PACKAGES
addappid(433451, 1, "cb749d173efaa03d3582807e2f93d0c26ed5659bdae6d3cdd0d49caace11dbef")
