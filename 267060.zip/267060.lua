-- Lua provided by RyzenAPI
-- Game: Gravity Badgers

-- MAIN APPLICATION
addappid(267060)

-- MAIN APP DEPOTS / PACKAGES
addappid(267061, 1, "1db269864ce8916548ef2f3e81f250fa421ad48f57ea7618df02c56312fcccb8")
addappid(267062, 1, "68e7900151fbda88a6a7d9c1f965b3f259c638556f595577b843e597cc92b535")
addappid(267063, 1, "8b8db6a910bb435eb37c407cf770c6d33391991d2029a6c8ce3a31f9d5bd07cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
