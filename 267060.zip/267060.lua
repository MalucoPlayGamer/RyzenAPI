-- Lua provided by RyzenAPI 
-- Game: Gravity Badgers
addappid(267060)
addappid(267061, 1, "1db269864ce8916548ef2f3e81f250fa421ad48f57ea7618df02c56312fcccb8")
addappid(267062, 1, "68e7900151fbda88a6a7d9c1f965b3f259c638556f595577b843e597cc92b535")
addappid(267063, 1, "8b8db6a910bb435eb37c407cf770c6d33391991d2029a6c8ce3a31f9d5bd07cb")
