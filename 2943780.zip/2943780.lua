-- Lua provided by RyzenAPI
-- Game: Chamber Survival

-- MAIN APPLICATION
addappid(2943780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943781, 1, "eaf2f5fc7ef8dd9a3a60fbaea7cee4175af783f9b2cff278383ea7d95cc7f5ef")

