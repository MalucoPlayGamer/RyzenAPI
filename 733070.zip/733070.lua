-- Lua provided by RyzenAPI
-- Game: Sudoku Universe

-- MAIN APPLICATION
addappid(733070)
addappid(809690)
addappid(817670)

-- MAIN APP DEPOTS / PACKAGES
addappid(733071, 1, "7cae77467d04de3653f68771a77e7449eae5c053102076c6cdd63521e8849f70")
addappid(733072, 1, "627eb1517993b1b0798e1a9d2dad40b87fe2325b1c5c358d6201b9e710cd1c4b")
addappid(733073, 1, "c79275facddb149eca9d65ca6cf748de80210541d02c4925609ef5dc3013cf4b")
