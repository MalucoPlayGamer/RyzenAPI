-- Lua provided by RyzenAPI
-- Game: Game: K37-D

-- MAIN APPLICATION
addappid(1193200)
-- Game: addappid(1193200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193201, 1, "a2151098ebc38eb4a857debe2ec7030b479092dc161ea3a8362fdedc71cbe922")
