-- Lua provided by RyzenAPI
-- Game: The Arcslinger

-- MAIN APPLICATION
addappid(381550)
-- Game: addappid(381550)

-- MAIN APP DEPOTS / PACKAGES
addappid(381551, 1, "cab2449cc237b3ac953d08f9afebb1523293dfc3024213783297080020705180")
