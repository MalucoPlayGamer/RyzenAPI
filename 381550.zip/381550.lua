-- Lua provided by RyzenAPI
-- Game: The Arcslinger

-- MAIN APPLICATION
addappid(381550)

-- MAIN APP DEPOTS / PACKAGES
addappid(381551, 1, "cab2449cc237b3ac953d08f9afebb1523293dfc3024213783297080020705180")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
