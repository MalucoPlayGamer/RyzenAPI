-- Lua provided by RyzenAPI
-- Game: Geneforge 5: Overthrow

-- MAIN APPLICATION
addappid(201010)

-- MAIN APP DEPOTS / PACKAGES
addappid(201011, 1, "f07b0044fc9cea7cd8d909c45ea6ff8fc65173d282971d0418bd152769d06066")

