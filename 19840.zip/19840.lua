-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Rainbow Six 3: Athena Sword

-- MAIN APPLICATION
addappid(19840)

-- MAIN APP DEPOTS / PACKAGES
addappid(19831,0,"db5e6f12fe170796a3a071c138e7b3de235d4b53e6858186d74b6d91d11f9699")
addappid(19832,0,"34d929c2f591a985554bbf5513c40b75e0f1d4689d917aeb73451caa1528133d")

