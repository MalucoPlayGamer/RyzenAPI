-- Lua provided by RyzenAPI
-- Game: Gear Gauntlet

-- MAIN APPLICATION
addappid(486890)

-- MAIN APP DEPOTS / PACKAGES
addappid(486891, 1, "1224367ceeff380871d451ecb190ffa89152bf2bd08667138a0f407de10e99c1")
addappid(486892, 1, "ba09524b562ccf07d3b4c8223744228043f6a7deb6525855ff0a10b2d5c3e6f7")

