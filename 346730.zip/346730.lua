-- Lua provided by RyzenAPI
-- Game: AppID 346730

-- MAIN APPLICATION
addappid(346730)

-- MAIN APP DEPOTS / PACKAGES
addappid(346731, 1, "1e9beb6ec270ddfd3073415a9c8a703f7dbbdefc8c7dfdeff8956658ebab5ff3")
addappid(346733, 1, "78c5e4ca3785d078aed574d80b11500e0953c301611bbab02d152201caf0e872")
addappid(346734, 1, "09ab10aa271306073f75ecf324928e44b25204625f1c37a0e407657a69fba1cc")
addappid(346735, 1, "7405d7eb332b4d6dce9d7f59146f42f55f0264a076bca55c9833bb0263e369d2")
addappid(419951, 0, "5c0422e1c2c99a4348bc0fa1e7627ba2f9bf2986e3142a3d6f0375ac406b9a14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
