-- Lua provided by RyzenAPI
-- Game: GraalOnline Era

-- MAIN APPLICATION
addappid(2358050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2358051, 1, "58406ec2f265c7276875ec729abf858dcd236ac164b35137e3b1ccf3848dd374")
addappid(2358052, 1, "90ed616dd0a5425fcf961e20c0caadbde39941c0206de59d0847e5aa264da6f1")
addappid(2358053, 1, "349f9ddabbab311726252741adb8052ab3aa3042105b3488a6171f95a9ca293b")

