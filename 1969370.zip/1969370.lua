-- Lua provided by RyzenAPI
-- Game: 1969370

-- MAIN APPLICATION
addappid(1969370)
addappid(3689940)
-- Game: addappid(1969370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969373,0,"a4fb49e17e4db8d1b592634bb51833f4e15f19d7e205e083d1e4203d88da29bd")
