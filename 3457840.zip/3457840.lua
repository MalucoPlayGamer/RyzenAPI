-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KTUS Airport

-- MAIN APPLICATION
addappid(3457840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3457840,0,"4348b0d910e4acdf3c55b9b1e7088c4ba9455e4c73ab3cfc4ba8fa7d2592ea4f")

