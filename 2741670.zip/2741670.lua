-- Lua provided by RyzenAPI
-- Game: addappid(2741670)

-- MAIN APPLICATION
addappid(2741670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741671, 1, "0c2a1034c0132a3ae98db90aa368aa46b42ba1a47f7bdc726bbe43ffd8062715")
