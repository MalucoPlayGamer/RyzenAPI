-- Lua provided by RyzenAPI
-- Game: addappid(2589840)

-- MAIN APPLICATION
addappid(2589840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589841, 1, "04d0907a92db9c97355d8226fce9710d0b3c16fb0a385cfcc43d214b66f2b011")
