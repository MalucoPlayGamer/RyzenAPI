-- Lua provided by RyzenAPI
-- Game: Rustler's Soundtrack

-- MAIN APPLICATION
addappid(1512150)
-- Game: addappid(1512150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512151, 1, "5975285a176d128c5b4f696819b2b9cf11c3177c63d942cba03e0360221150b2")
