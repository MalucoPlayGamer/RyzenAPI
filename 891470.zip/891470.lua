-- Lua provided by RyzenAPI
-- Game: Falling Blocks

-- MAIN APPLICATION
addappid(891470)
addappid(891550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(891471,0,"c74e27f45608c4170c18b1b14fd4789e803f2d1e87b792f634701e157490e74c")
addappid(891551,0,"887e6f61163f08f574452f40096b6aff1f583b06b7498203433a963898243819")

