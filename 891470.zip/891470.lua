-- Lua provided by RyzenAPI
-- Game: Game: AppID 891470

-- MAIN APPLICATION
addappid(891470)
-- Game: addappid(891470)

-- MAIN APP DEPOTS / PACKAGES
addappid(891471, 1, "c74e27f45608c4170c18b1b14fd4789e803f2d1e87b792f634701e157490e74c")
