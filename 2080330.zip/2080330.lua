-- Lua provided by RyzenAPI 
-- Game: Foretales - Soundtrack
addappid(2080330)
addappid(2080331, 1, "0415ed4814f4e61e83e4d8dc3f9fb543323e84ad7df30de98c607f9eba752cb9")
addappid(2080332, 1, "d9353ec1a7211d9cfb56f94f42d14aff250a99a28a01751d3f96da3d0c23080c")
