-- Lua provided by RyzenAPI
-- Game: Lycanthorn II - Rain of Beasts

-- MAIN APPLICATION
addappid(1546440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546441, 1, "e167658013c85dd390ad8aff3a3ba11bcd70ea31434883d4bc68f1b89762c341")
addappid(1546442, 1, "c89fd01f50752606d5c5c25a4a5b5848974c7e743864ba4bdc804fc7a909a94f")
