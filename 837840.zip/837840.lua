-- Lua provided by RyzenAPI
-- Game: addappid(837840)

-- MAIN APPLICATION
addappid(837840)

-- MAIN APP DEPOTS / PACKAGES
addappid(837840,0,"d218784aa380a3e4dbb1178fb25a13d9d2918c9e79917485b62eb3b1bda0fd25")
