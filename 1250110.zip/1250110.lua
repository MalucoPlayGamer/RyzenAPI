-- Lua provided by RyzenAPI
-- Game: 1250110

-- MAIN APPLICATION
addappid(1250110)
-- Game: addappid(1250110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250111, 1, "23c29171d4fd7f7c3446c72804fc4b879af95a08fd59b69b170b8a49aa695dd7")
