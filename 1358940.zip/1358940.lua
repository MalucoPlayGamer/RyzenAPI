-- Lua provided by RyzenAPI
-- Game: Stormblades Remastered

-- MAIN APPLICATION
addappid(1358940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358941, 1, "d59eb28fec268bd7ea857ad39a730727a142fbdfff198eff81d4d67f2ef3f070")

