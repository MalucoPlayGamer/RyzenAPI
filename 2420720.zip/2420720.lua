-- Lua provided by RyzenAPI
-- Game: The Dead Await Demo

-- MAIN APPLICATION
addappid(2420720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420721, 1, "cf0d65aec06a33391ff322a1aa0765f7caa1ed10b9f769d53d8e6a71693071c2")

