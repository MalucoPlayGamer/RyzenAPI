-- Lua provided by RyzenAPI 
-- Game: AppID 2420720
addappid(2420720)
addappid(2420721, 1, "cf0d65aec06a33391ff322a1aa0765f7caa1ed10b9f769d53d8e6a71693071c2")
