-- Lua provided by RyzenAPI
-- Game: Game: Hard Truck Apocalypse / Ex Machina

-- MAIN APPLICATION
addappid(285500)
-- Game: addappid(285500)

-- MAIN APP DEPOTS / PACKAGES
addappid(285501, 1, "9765f7c10962f747b79788d4937985f59e63ae383776bcf7038a47040585cbf8")
