-- Lua provided by RyzenAPI
-- Game: Hard Truck Apocalypse / Ex Machina

-- MAIN APPLICATION
addappid(285500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(285501, 1, "9765f7c10962f747b79788d4937985f59e63ae383776bcf7038a47040585cbf8")

