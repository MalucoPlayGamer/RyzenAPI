-- Lua provided by RyzenAPI
-- Game: AppID 586130

-- MAIN APPLICATION
addappid(586130)

-- MAIN APP DEPOTS / PACKAGES
addappid(586131, 1, "6e3332c1873904d4ccb809fe2b7843c462af8be952848aaa318f93a0e94fdbc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
