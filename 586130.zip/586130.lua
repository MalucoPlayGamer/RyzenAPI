-- Lua provided by RyzenAPI
-- Game: AppID 586130

-- MAIN APPLICATION
addappid(586130)
-- Game: addappid(586130)

-- MAIN APP DEPOTS / PACKAGES
addappid(586131, 1, "6e3332c1873904d4ccb809fe2b7843c462af8be952848aaa318f93a0e94fdbc7")
