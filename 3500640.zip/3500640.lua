-- Lua provided by RyzenAPI
-- Game: Arithmetic

-- MAIN APPLICATION
addappid(3500640)
-- Game: addappid(3500640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500642,0,"9a8c9c60fc9fbc8c1c0805e74aa243f0400a55e8fcad3ed786bea072b7613680")
addappid(3500643,0,"d0f24eec3a222aa3553314c2ad529835c3ec74540c8c5e2ef1339c79c51608d3")
