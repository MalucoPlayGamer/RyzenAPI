-- Lua provided by RyzenAPI
-- Game: addappid(2878570)

-- MAIN APPLICATION
addappid(2878570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878571, 1, "3dffcb9208bb675757b0dbadf4a3c365839076a2374f9b7697e41b5b30babf4d")
