-- Lua provided by RyzenAPI 
-- Game: AppID 2878570
addappid(2878570)
addappid(2878571, 1, "3dffcb9208bb675757b0dbadf4a3c365839076a2374f9b7697e41b5b30babf4d")
