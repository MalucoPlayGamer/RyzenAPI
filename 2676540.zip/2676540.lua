-- Lua provided by RyzenAPI
-- Game: Brush Burial

-- MAIN APPLICATION
addappid(2676540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676541, 1, "2f93afe0fee3200444c0f270e45957d0fb066120ae5d77c78f378c226ec94266")

