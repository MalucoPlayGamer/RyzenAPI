-- Lua provided by RyzenAPI
-- Game: Scrapworks Simulator

-- MAIN APPLICATION
addappid(3318580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318581, 1, "face9a0541bd6e849b1fbb4bb72195c5468870c225c2c11267ecbcf9e141bc29")
