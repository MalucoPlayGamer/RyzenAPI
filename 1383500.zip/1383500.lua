-- Lua provided by RyzenAPI
-- Game: 客栈江湖-Vagabond Inn

-- MAIN APPLICATION
addappid(1383500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383501, 1, "45e7be44d13472f2997679871d164649c0416c2afd1e90250afdb91835085fbf")

