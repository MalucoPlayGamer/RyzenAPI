-- Lua provided by RyzenAPI 
-- Game: AppID 1383500
addappid(1383500)
addappid(1383501, 1, "45e7be44d13472f2997679871d164649c0416c2afd1e90250afdb91835085fbf")
