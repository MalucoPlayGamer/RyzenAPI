-- Lua provided by RyzenAPI
-- Game: Game: Magic Potion Millionaire

-- MAIN APPLICATION
addappid(1461630)
-- Game: addappid(1461630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461631, 1, "f2efd841822bb6f1c661e4f9f06e53de43bb904bf682597134773c23ddab37b5")
