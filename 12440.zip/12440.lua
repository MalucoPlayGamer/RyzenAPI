-- Lua provided by RyzenAPI 
-- Game: AppID 12440
addappid(12440)
addappid(12441, 1, "72626067d0f9abc7997e111f2bf3dd113fa406101f36363e47f5ea5515ab790e")
