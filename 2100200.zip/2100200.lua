-- Lua provided by RyzenAPI
-- Game: Game: Idle Zombies Clicker

-- MAIN APPLICATION
addappid(2100200)
-- Game: addappid(2100200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100201, 1, "52cde4d8a4a2abe84ce16eeaf266b774e0d20425cfab197d978565b872e8c6d6")
