-- Lua provided by RyzenAPI
-- Game: Injured by space

-- MAIN APPLICATION
addappid(804940)

-- MAIN APP DEPOTS / PACKAGES
addappid(804941, 1, "6e228180966e89c82870a2696630ca82532601f11559fdecda5e04c593828843")

