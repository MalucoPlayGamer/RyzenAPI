-- Lua provided by RyzenAPI 
-- Game: DESKTOP MONKEY
addappid(1773330)
addappid(1773331, 1, "dd00a43b8604c9c964090ca7012c5b599ebb85a1d86ec38ffdacb3c54c834e5e")
