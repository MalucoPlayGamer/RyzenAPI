-- Lua provided by RyzenAPI
-- Game: 1448840

-- MAIN APPLICATION
addappid(1448840)
-- Game: addappid(1448840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448841, 1, "4c3c3f68416c5f427ddda5f0af4b2387fb4f5ce51acfc5db2b8667f743fd3066")
