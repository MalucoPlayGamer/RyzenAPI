-- Lua provided by RyzenAPI
-- Game: Pertinence

-- MAIN APPLICATION
addappid(455110)

-- MAIN APP DEPOTS / PACKAGES
addappid(455111, 1, "45fd18ae65410d13eb376c821cad0aee2d615f0572b7a3ec723a485a441f23f7")
addappid(456410, 0, "aa3d2e23f33631343c82439eaf1fc214097f206113ee5c39cb4747e07528e3d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
