-- Lua provided by RyzenAPI
-- Game: Game: Pertinence

-- MAIN APPLICATION
addappid(455110)
-- Game: addappid(455110)

-- MAIN APP DEPOTS / PACKAGES
addappid(455111, 1, "45fd18ae65410d13eb376c821cad0aee2d615f0572b7a3ec723a485a441f23f7")
addappid(456410, 0, "aa3d2e23f33631343c82439eaf1fc214097f206113ee5c39cb4747e07528e3d1")
