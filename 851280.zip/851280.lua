-- Lua provided by RyzenAPI
-- Game: 851280

-- MAIN APPLICATION
addappid(851280)
addappid(1256800)
-- Game: addappid(851280)

-- MAIN APP DEPOTS / PACKAGES
addappid(851281, 1, "4c9d3d92d3c4bddf4e9bfc354c4b7851b2242d3a7e9dfd65773bfb7c6097495a")
