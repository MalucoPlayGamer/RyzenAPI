-- Lua provided by RyzenAPI
-- Game: F1® Manager 2022

-- MAIN APPLICATION
addappid(1708520)
-- Game: addappid(1708520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708521, 1, "cfe691d2a98318144412d25c85741599738732ab007a32803fe9a6f449e689ed")
