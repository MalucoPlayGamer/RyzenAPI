-- Lua provided by SkyAPI 
-- Game: F1® Manager 2022
addappid(1708520)
addappid(1708521, 1, "cfe691d2a98318144412d25c85741599738732ab007a32803fe9a6f449e689ed")
