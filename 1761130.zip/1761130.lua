-- Lua provided by RyzenAPI
-- Game: addappid(1761130)

-- MAIN APPLICATION
addappid(1761130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761131, 1, "129d610712ef5fbd515adc6906e3d22e85a0efd638dca0883eb764db87485c88")
