-- Lua provided by RyzenAPI
-- Game: 1202820

-- MAIN APPLICATION
addappid(1202820)
-- Game: addappid(1202820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202821, 1, "df10c849e778670d09bc2edad3fb43c28532e68535c0d3fda0d49b2b688ebfb1")
