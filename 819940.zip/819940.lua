-- Lua provided by RyzenAPI
-- Game: Rum Ram

-- MAIN APPLICATION
addappid(819940)
-- Game: addappid(819940)

-- MAIN APP DEPOTS / PACKAGES
addappid(819941, 1, "430d014e0d140c44506a601372bd298083a832c757e687988dc9437852136ee4")
