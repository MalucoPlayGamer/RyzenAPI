-- Lua provided by RyzenAPI
-- Game: Green Army Men - Dedicated Server

-- MAIN APPLICATION
addappid(1075820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075820,0,"738ef6b9103dd605e5ea997e19aa9b1381006b8209caa662c1228d60bea10d4b")

