-- Lua provided by RyzenAPI
-- Game: Havoc Runner

-- MAIN APPLICATION
addappid(552480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552481,0,"51effac2264344f6a5e180cc72f4cdc9639260ca1c8754e42fabc74311ee8ddb")

