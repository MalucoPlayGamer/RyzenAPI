-- Lua provided by RyzenAPI
-- Game: Havoc Runner

-- MAIN APPLICATION
addappid(552480)

-- MAIN APP DEPOTS / PACKAGES
addappid(552481,0,"51effac2264344f6a5e180cc72f4cdc9639260ca1c8754e42fabc74311ee8ddb")

