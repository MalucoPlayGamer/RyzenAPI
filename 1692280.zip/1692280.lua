-- Lua provided by RyzenAPI
-- Game: 1692280

-- MAIN APPLICATION
addappid(1692280)
-- Game: addappid(1692280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692281, 1, "ffc2736625ff653f617837451506bdfdeacd0ca903db0f188bc81d78636d8533")
