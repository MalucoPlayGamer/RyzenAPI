-- Lua provided by RyzenAPI
-- Game: Miskal

-- MAIN APPLICATION
addappid(2233300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233301, 1, "41de6e93369710f9d74be6a9ec734497acf0d28823c9dc645e418800fc2c0644")

