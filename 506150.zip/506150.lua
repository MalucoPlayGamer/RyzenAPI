-- Lua provided by RyzenAPI
-- Game: Dragon Bros

-- MAIN APPLICATION
addappid(506150)

-- MAIN APP DEPOTS / PACKAGES
addappid(506154,0,"68cc809821ca56e2c424d0dd55578d3e54e799485cbfdbbce04420512a67fb07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(529550)
