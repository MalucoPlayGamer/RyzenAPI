-- Lua provided by RyzenAPI
-- Game: setManifestid(506154,"950384585835950559")

-- MAIN APPLICATION
addappid(506150)
-- Game: addappid(506150)

-- MAIN APP DEPOTS / PACKAGES
addappid(506154,0,"68cc809821ca56e2c424d0dd55578d3e54e799485cbfdbbce04420512a67fb07")
