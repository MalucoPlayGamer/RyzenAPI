-- Lua provided by RyzenAPI
-- Game: addappid(506150)

-- MAIN APPLICATION
addappid(506150)

-- MAIN APP DEPOTS / PACKAGES
addappid(506154,0,"68cc809821ca56e2c424d0dd55578d3e54e799485cbfdbbce04420512a67fb07")
