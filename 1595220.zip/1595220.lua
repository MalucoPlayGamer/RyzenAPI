-- Lua provided by SkyAPI 
-- Game: EstradaBus HD Demo
addappid(1595220)
addappid(1595221, 1, "51b25572eef955a986791fc6d388fea9c185f78a49649d11e666ff472a89fbf2")
