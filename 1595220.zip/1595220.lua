-- Lua provided by RyzenAPI
-- Game: EstradaBus HD Demo

-- MAIN APPLICATION
addappid(1595220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595221, 1, "51b25572eef955a986791fc6d388fea9c185f78a49649d11e666ff472a89fbf2")

