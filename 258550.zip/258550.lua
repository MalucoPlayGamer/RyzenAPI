-- Lua provided by RyzenAPI
-- Game: addappid(258550)

-- MAIN APPLICATION
addappid(258550)

-- MAIN APP DEPOTS / PACKAGES
addappid(258551, 1, "09842c1c5e07c75ea20524cfab90a25efd8c3a1e02e5dec51ea09f5f7d64d16d")
addappid(258552, 1, "bf4ffd7abd1e0668dfb7eeda4085ae5358385bd7fa4a73f4c0f3e7474c3cfb54")
addappid(258554, 1, "e080d61fac7bc9db9c82396949d62c52b0780ed8a07fc3cf27fb3d05a49ebfb2")
