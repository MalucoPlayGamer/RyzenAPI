-- Lua provided by RyzenAPI
-- Game: Floor is Water

-- MAIN APPLICATION
addappid(1877160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877161, 1, "066aa2dfaba10bc4b378b23f33e99597504e04647106324af25d9992c98bad6b")

