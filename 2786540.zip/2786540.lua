-- Lua provided by RyzenAPI
-- Game: addappid(2786540)

-- MAIN APPLICATION
addappid(2786540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786541, 1, "c779283aa3b7d4d33fa89e4066cdea5ebd903f37d18c160f88e70697ee89df66")
addappid(2786543, 1, "0383a6ec16fcb217ab91157c27085420f328d16df3df4be71a9bcfcd40ea5df2")
