-- Lua provided by RyzenAPI
-- Game: Fiesta Online NA

-- MAIN APPLICATION
addappid(300970)

-- MAIN APP DEPOTS / PACKAGES
addappid(300971, 1, "c74bec115e81735a516fa3d899ce13e84ebddffa773927e41578590dbd35a6aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5071960)
addappid(5071970)
addappid(5071980)
addappid(5071990)
addappid(5072000)
addappid(5072010)
addappid(5072020)
