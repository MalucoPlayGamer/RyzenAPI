-- Lua provided by RyzenAPI
-- Game: 300970

-- MAIN APPLICATION
addappid(300970)
-- Game: addappid(300970)

-- MAIN APP DEPOTS / PACKAGES
addappid(300971, 1, "c74bec115e81735a516fa3d899ce13e84ebddffa773927e41578590dbd35a6aa")
