-- Lua provided by RyzenAPI
-- Game: Devil's Tower

-- MAIN APPLICATION
addappid(3811580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3811581,0,"8f3cbfd55af4a62839eb62014da2849e6653b6c001833c6132cf98629a2a1aec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
