-- Lua provided by RyzenAPI
-- Game: Navy Strike

-- MAIN APPLICATION
addappid(1644810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644811, 1, "712d1f1114c66e33a901b3ec82a97a121654b13dc22c7647d1eb9eb512785461")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
