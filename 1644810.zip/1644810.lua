-- Lua provided by RyzenAPI
-- Game: Navy Strike

-- MAIN APPLICATION
addappid(1644810)
-- Game: addappid(1644810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644811, 1, "712d1f1114c66e33a901b3ec82a97a121654b13dc22c7647d1eb9eb512785461")
