-- Lua provided by RyzenAPI 
-- Game: Navy Strike
addappid(1644810)
addappid(1644811, 1, "712d1f1114c66e33a901b3ec82a97a121654b13dc22c7647d1eb9eb512785461")
