-- Lua provided by RyzenAPI 
-- Game: AppID 354060
addappid(354060)
addappid(354061, 1, "c1811c77d3445ab53c90d654679efabe128cc6acf20f5652e96dc4661138f110")
