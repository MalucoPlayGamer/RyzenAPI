-- Lua provided by RyzenAPI
-- Game: addappid(354060)

-- MAIN APPLICATION
addappid(354060)

-- MAIN APP DEPOTS / PACKAGES
addappid(354061, 1, "c1811c77d3445ab53c90d654679efabe128cc6acf20f5652e96dc4661138f110")
