-- Lua provided by RyzenAPI
-- Game: AppID 710130

-- MAIN APPLICATION
addappid(710130)
-- Game: addappid(710130)

-- MAIN APP DEPOTS / PACKAGES
addappid(710131, 1, "3439aa851a12a1de3d8829cc5e75f09669955799e9f34f051eeb3ecfefe443c9")
addappid(710132, 1, "e65c75dcc4f2df1ec1ac2af35fc5eb72f15b19e6d861f10662f9a6b0cb17f3d8")
