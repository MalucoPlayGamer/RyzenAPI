-- Lua provided by RyzenAPI
-- Game: AppID 710130

-- MAIN APPLICATION
addappid(710130)
addappid(723430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(710131, 1, "3439aa851a12a1de3d8829cc5e75f09669955799e9f34f051eeb3ecfefe443c9")
addappid(710132, 1, "e65c75dcc4f2df1ec1ac2af35fc5eb72f15b19e6d861f10662f9a6b0cb17f3d8")

