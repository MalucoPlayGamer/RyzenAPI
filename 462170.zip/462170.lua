-- Lua provided by RyzenAPI
-- Game: 8-Bit Armies - Soundtrack

-- MAIN APPLICATION
addappid(462170)

-- MAIN APP DEPOTS / PACKAGES
addappid(462171, 1, "c1b5d3e4679fc74a482d3858f33ec47041955714034b0078f19ed3e8b264eae5")

