-- Lua provided by RyzenAPI
-- Game: Bad Mojo Redux

-- MAIN APPLICATION
addappid(255960)

-- MAIN APP DEPOTS / PACKAGES
addappid(255961, 1, "232071883de26b0a87ea5972043c315edcbc2c5ce93cc141afc7adf1604a143b")
addappid(255962, 1, "59dc585d247672c0fe87abb9c98d1eec7f7eb26fbfc2568bd828fdde4efb99ba")

