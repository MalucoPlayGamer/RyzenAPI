-- Lua provided by SkyAPI 
-- Game: Chroma
addappid(3317740)
addappid(3317741, 1, "126e3abf3c4bb66b96441689e2631503e259f88bddfd518e5f7cc76ca7af945c")
