-- Lua provided by RyzenAPI 
-- Game: AppID 2962580
addappid(2962580)
addappid(2962581, 1, "64db91cc2064f5f62ff7971b6fc6baf8c94214b0e1b1617379182bf125917885")
