-- Lua provided by RyzenAPI
-- Game: AppID 331580

-- MAIN APPLICATION
addappid(331580)

-- MAIN APP DEPOTS / PACKAGES
addappid(331581, 1, "12fcb42f76b86b85f61e8a7acb0795ed0e4e41f616cda57d9409d7f28e276f47")

