-- Lua provided by RyzenAPI
-- Game: AppID 331580

-- MAIN APPLICATION
addappid(331580)
addappid(333680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(331581, 1, "12fcb42f76b86b85f61e8a7acb0795ed0e4e41f616cda57d9409d7f28e276f47")

