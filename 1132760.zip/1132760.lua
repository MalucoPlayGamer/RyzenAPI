-- Lua provided by RyzenAPI
-- Game: Game: Dwerve

-- MAIN APPLICATION
addappid(1132760)
-- Game: addappid(1132760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132761, 1, "24be484eec15129b698c5ead024658c0bdced8d88f97319e6aebc0afa8b7ae9c")
addappid(1132762, 1, "46dcac0876505d4aea9aa7cc9aabb3dafa80ba62bc7b4f92bf4390d293e7762c")
addappid(1132763, 1, "5be6096e6c9a34964c0ceee4e59508af7747a3b1bde8d26bf23c168c13aee264")
addappid(1132764, 1, "2a1ff6264c483dd6fc0e96d7075a30174b71a7f4755ec1be0064a7ac707acb17")
