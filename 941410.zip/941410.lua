-- Lua provided by RyzenAPI
-- Game: Game: AppID 941410

-- MAIN APPLICATION
addappid(941410)
-- Game: addappid(941410)

-- MAIN APP DEPOTS / PACKAGES
addappid(941411, 1, "0d1901e1494a91e24bce5226cd62ba73557dca5022c186cfaa1149e241c1779e")
