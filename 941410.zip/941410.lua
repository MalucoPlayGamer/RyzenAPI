-- Lua provided by RyzenAPI 
-- Game: AppID 941410
addappid(941410)
addappid(941411, 1, "0d1901e1494a91e24bce5226cd62ba73557dca5022c186cfaa1149e241c1779e")
