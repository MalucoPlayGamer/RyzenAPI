-- Lua provided by RyzenAPI
-- Game: AppID 941410

-- MAIN APPLICATION
addappid(941410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(941411, 1, "0d1901e1494a91e24bce5226cd62ba73557dca5022c186cfaa1149e241c1779e")

