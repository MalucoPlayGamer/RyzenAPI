-- Lua provided by RyzenAPI
-- Game: Forest of Evil

-- MAIN APPLICATION
addappid(1064620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064621, 1, "f9ec2970087959c376f754aa4723d2c787349ea9db6e2581e173d67737eb2ada")

