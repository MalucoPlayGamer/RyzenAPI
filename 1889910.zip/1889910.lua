-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1889910)
addappid(872571,0,"b630f275f4eb04dc2116f99164b75b38c517b50d3a4f2006543e24cc19301e11")
-- setManifestid(872571,"8744522999403841596")