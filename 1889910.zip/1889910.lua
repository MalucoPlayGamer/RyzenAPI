-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1889910)
-- Game: addappid(1889910)

-- MAIN APP DEPOTS / PACKAGES
addappid(872571,0,"b630f275f4eb04dc2116f99164b75b38c517b50d3a4f2006543e24cc19301e11")
