-- Lua provided by RyzenAPI
-- Game: TEN - Ten Rooms, Ten Seconds

-- MAIN APPLICATION
addappid(1798740)
-- Game: addappid(1798740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798741, 1, "0f27fb7bd1bd4e7f2eb233a3ad83b306b5db9b19f7f3a158f82d181ac17d6174")
