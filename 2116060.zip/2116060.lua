-- Lua provided by RyzenAPI
-- Game: Epic Auto Towers

-- MAIN APPLICATION
addappid(2116060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116061, 1, "0995db5b2ceaa327d82c17e85fcb5e8bf580ad66dc0cfe8de39e0ac225bc97fa")

