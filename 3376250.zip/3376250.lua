-- Lua provided by RyzenAPI
-- Game: Game: Nine-Ball Roulette

-- MAIN APPLICATION
addappid(3376250)
-- Game: addappid(3376250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376251, 1, "b8e4a7ce69ae5aef69562f43522ae837dd6bb3b36efb3a3d923d874afa21397d")
