-- Lua provided by SkyAPI 
-- Game: My Lovely Daughter: ReBorn
addappid(2998360)
addappid(2998361, 1, "1fb5afa09a8b1b64ab7d7cb7b86051b30c1f9afa89d1eea8796234d8b1aa4521")
addappid(2998362, 1, "671aea3d9607320d6f44c711afa7e39c85dc2f25dbdf4eb5bd17673d1e597f51")
addappid(2998363, 1, "a6ca9d751a0cc7ae96fac94737e01b10f2d33330fdd9586e5170460b4fb09bba")
