-- Lua provided by SkyAPI 
-- Game: Kill It With Fire VR
addappid(1905220)
addappid(1905221, 1, "2742ad9062108779b7681029ad06892db86f8f00d6d7343cf7ff278a7de560e1")
