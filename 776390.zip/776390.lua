-- Lua provided by RyzenAPI
-- Game: Game: Outbreak in Space VR - Free

-- MAIN APPLICATION
addappid(776390)
-- Game: addappid(776390)

-- MAIN APP DEPOTS / PACKAGES
addappid(776391, 1, "9643fb60a43ffeff3b309dc2bba59d189247572163c64991d654636397416c4c")
