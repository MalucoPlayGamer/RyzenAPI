-- Lua provided by RyzenAPI
-- Game: USA 2020

-- MAIN APPLICATION
addappid(859700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(859701, 1, "5f94c6b8e719a14177d7e3a765db78ccc1a2cb441fb041e35ea0b2677a5d25e5")

