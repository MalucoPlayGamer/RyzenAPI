-- Lua provided by RyzenAPI
-- Game: addappid(860690)

-- MAIN APPLICATION
addappid(860690)

-- MAIN APP DEPOTS / PACKAGES
addappid(860690,0,"8980ef33ed93c60cddec85c69340d6458adfc3f899f7c0565181693343fda865")
