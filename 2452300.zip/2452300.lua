-- Lua provided by RyzenAPI
-- Game: Game: Restaurant Simulator 2023

-- MAIN APPLICATION
addappid(2452300)
-- Game: addappid(2452300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452301, 1, "9f29750b2da51c4790cbe71986c6154f3c15214a206dec645c6476bf7c2e5adc")
