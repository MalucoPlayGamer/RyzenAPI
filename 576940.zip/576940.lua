-- Lua provided by RyzenAPI
-- Game: Hunt For Gods

-- MAIN APPLICATION
addappid(576940)

-- MAIN APP DEPOTS / PACKAGES
addappid(576941, 1, "4c575bef39e3aed99ed3b556d9e115d69539c1be01598f251e45055155fbbf99")
