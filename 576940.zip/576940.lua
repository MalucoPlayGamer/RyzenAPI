-- Lua provided by SkyAPI 
-- Game: Hunt For Gods
addappid(576940)
addappid(576941, 1, "4c575bef39e3aed99ed3b556d9e115d69539c1be01598f251e45055155fbbf99")
