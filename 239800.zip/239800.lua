-- Lua provided by RyzenAPI
-- Game: Game: Bleed

-- MAIN APPLICATION
addappid(239800)
-- Game: addappid(239800)

-- MAIN APP DEPOTS / PACKAGES
addappid(239801, 1, "ed30703ba9e1d8d2991de0897581d7c321b4342a4fd7b1dbe777b9ca1f446f75")
addappid(239802, 1, "12b17dd792ce8d7c3b5ccd9b9e25e43c9962b3cb9049a8845ff57b61f083e19a")
addappid(239803, 1, "25447a4f4e1de6ae47c5bf9f2437121833417443d416a696984937df0aa47ce6")
