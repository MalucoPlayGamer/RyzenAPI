-- Lua provided by RyzenAPI
-- Game: Bleed

-- MAIN APPLICATION
addappid(239800)

-- MAIN APP DEPOTS / PACKAGES
addappid(239801, 1, "ed30703ba9e1d8d2991de0897581d7c321b4342a4fd7b1dbe777b9ca1f446f75")
addappid(239802, 1, "12b17dd792ce8d7c3b5ccd9b9e25e43c9962b3cb9049a8845ff57b61f083e19a")
addappid(239803, 1, "25447a4f4e1de6ae47c5bf9f2437121833417443d416a696984937df0aa47ce6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
