-- Lua provided by RyzenAPI
-- Game: addappid(805820)

-- MAIN APPLICATION
addappid(805820)
addappid(822180)

-- MAIN APP DEPOTS / PACKAGES
addappid(805821, 1, "4e1fbd09d7b763ecea9d0e12c57a2fbed8ef2725c1a80c7e3752e40ef02df59f")
