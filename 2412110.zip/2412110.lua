-- 2412110's Lua and Manifest Created by Hubcap Manifest
-- Rogue Labyrinth
-- Created: May 06, 2026 at 15:21:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2412110, 1, "4a8873afd79a0ab43e1dd5a75341328fb66631efd414a80cda133bb4da674f50") -- Rogue Labyrinth
-- MAIN APP DEPOTS
addappid(2412111, 1, "474b91203838a5b6c3c871d7479d0a355789a1f63e8af273609a3e3537710992") -- Depot 2412111
--setManifestid(2412111, "7328885127610738776", 373229133)
addappid(2412112, 1, "ee58f83dfcf1971399f4b6fbe11e397d144ccd6e9af6ed02db5494b2aad03c4d") -- Depot 2412112
--setManifestid(2412112, "6729833889566492750", 398978238)
addappid(2412113, 1, "e51c7f7db7f27d7dac747808f0d23a8a52a408f3cf2eaeacdd6bd818359eefdb") -- Depot 2412113
--setManifestid(2412113, "3858791286844860647", 464285035)