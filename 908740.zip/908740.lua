-- Lua provided by RyzenAPI
-- Game: VALHALL: Harbinger

-- MAIN APPLICATION
addappid(908740)

-- MAIN APP DEPOTS / PACKAGES
addappid(908741, 1, "6a4ef14a9a771dec545a2dce729836be397b17132eaf6af86be9584cec9d93ed")
