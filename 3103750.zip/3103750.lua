-- Lua provided by RyzenAPI
-- Game: PENGUIN HOTEL -Chapter 1-

-- MAIN APPLICATION
addappid(3103750)
-- Game: addappid(3103750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103751, 1, "6d36866671110f9fbd62e58a61c1a8768ac4ac36d2f06e53d923372869fa93a0")
