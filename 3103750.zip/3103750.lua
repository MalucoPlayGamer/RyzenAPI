-- Lua provided by RyzenAPI
-- Game: PENGUIN HOTEL -Chapter 1-

-- MAIN APPLICATION
addappid(3103750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103751, 1, "6d36866671110f9fbd62e58a61c1a8768ac4ac36d2f06e53d923372869fa93a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
