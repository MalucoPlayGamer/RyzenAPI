-- Lua provided by RyzenAPI
-- Game: Blightseed

-- MAIN APPLICATION
addappid(3946360) -- Blightseed

-- MAIN APP DEPOTS / PACKAGES
addappid(3946361, 1, "344bc23a02227be4bb8f7ed7b829f46201e8ce4c7e6c6a87fee7b931c3609b5a") -- Depot 3946361

