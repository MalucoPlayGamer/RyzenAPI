-- Lua provided by RyzenAPI
-- Game: Captain Starshot

-- MAIN APPLICATION
addappid(1037410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037411, 1, "f2460a71f65fcd6e80c95b1b21377c7f4a95affc769ebd8f5851958322689ef5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1110820)
