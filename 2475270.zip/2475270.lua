-- Lua provided by RyzenAPI
-- Game: Goddess detective 2

-- MAIN APPLICATION
addappid(2475270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475271, 1, "eddb5a9fbfe5b02d5c06f078204b8cf3e24ab5249043695f0305be394eba55a3")

