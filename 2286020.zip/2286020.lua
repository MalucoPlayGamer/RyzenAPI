-- Lua provided by RyzenAPI
-- Game: The Pyramid Of Bones

-- MAIN APPLICATION
addappid(2286020)
-- Game: addappid(2286020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286021, 1, "5e3c1921b53ca621bb2dd9fb35aa0172b47ac5eb49968d45f155f776ca531b39")
