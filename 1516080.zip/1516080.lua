-- Lua provided by RyzenAPI
-- Game: 1516080

-- MAIN APPLICATION
addappid(1516080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516083,0,"aa7782751c17ac369cd7a58f82ea3916e3d3c42ebb8d5c1e07da539cf410dd7f")

