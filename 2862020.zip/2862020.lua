-- Lua provided by RyzenAPI
-- Game: Game: Let's Park Bus Edition

-- MAIN APPLICATION
addappid(2862020)
-- Game: addappid(2862020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862021, 1, "8b605854b4d48826a493382125c96cd7671208a1c6f221cb6528d45615f2ca20")
