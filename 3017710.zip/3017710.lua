-- Lua provided by RyzenAPI
-- Game: 3017710

-- MAIN APPLICATION
addappid(3017710)
-- Game: addappid(3017710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017711, 1, "bcbfc5468c10cb0d8a46e3e4bf7234eb9184bd3c06778a07f6f0c322fd56f0d4")
