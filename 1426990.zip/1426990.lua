-- Lua provided by RyzenAPI
-- Game: Game: Anime - Space Sniper

-- MAIN APPLICATION
addappid(1426990)
-- Game: addappid(1426990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426991, 1, "1610e57565495574560ee39f33c24643738eb012d8b11b6c6903e300a296d7c5")
