-- Lua provided by RyzenAPI 
-- Game: Anime - Space Sniper
addappid(1426990)
addappid(1426991, 1, "1610e57565495574560ee39f33c24643738eb012d8b11b6c6903e300a296d7c5")
