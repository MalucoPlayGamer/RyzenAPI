-- Lua provided by RyzenAPI
-- Game: Game: Kinky Fight Club

-- MAIN APPLICATION
addappid(1237530)
-- Game: addappid(1237530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237531, 1, "5a9271cb791741e2b6ee651b6db27f56170da558d759d624b4085371017685fe")
