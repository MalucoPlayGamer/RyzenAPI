-- Lua provided by RyzenAPI 
-- Game: Kinky Fight Club
addappid(1237530)
addappid(1237531, 1, "5a9271cb791741e2b6ee651b6db27f56170da558d759d624b4085371017685fe")
