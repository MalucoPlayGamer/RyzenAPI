-- Lua provided by RyzenAPI
-- Game: Ammo Pigs: Armed and Delicious

-- MAIN APPLICATION
addappid(877480)

-- MAIN APP DEPOTS / PACKAGES
addappid(877481,0,"237da41d8d5d50bc0e835c0d13fb7fadec7490b5ca318ec2ac73eb0551ffeb58")

