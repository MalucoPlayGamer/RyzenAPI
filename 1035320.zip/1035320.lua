-- Lua provided by RyzenAPI
-- Game: addappid(1035320)

-- MAIN APPLICATION
addappid(1035320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035321, 1, "be62478ea02f3ca850f8323d18723ea8c21215ce36ab97f3bafd18374b5c94a2")
