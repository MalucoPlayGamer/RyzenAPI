-- Lua provided by RyzenAPI
-- Game: Game: 富甲天下3

-- MAIN APPLICATION
addappid(2258590)
-- Game: addappid(2258590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258591, 1, "974c607d527f07a2c82bd1c544fb743c5698d98900fd91637daaff99a1f11213")
