-- Lua provided by RyzenAPI
-- Game: Idle magic herb

-- MAIN APPLICATION
addappid(2123030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123031, 1, "9865d7e63c50191f7ebbe0bfeea6871f149b68fe262ddd5e59764538ef476d9c")
