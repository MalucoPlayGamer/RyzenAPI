-- Lua provided by RyzenAPI
-- Game: Trump Searching Vigaro

-- MAIN APPLICATION
addappid(3561820)
-- Game: addappid(3561820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561821, 1, "8fe5abe8f3d5c980611bc95af62d03ee0baf5f8761a2da3440275ec4f0e48898")
