-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST® XI: Echoes of an Elusive Age™ - Digital Edition of Light

-- MAIN APPLICATION
addappid(742120)

-- MAIN APP DEPOTS / PACKAGES
addappid(742121, 1, "3d347e3e1e6dd1c1e429317128682f3fb815fe544dd92aae06d621e06b90fc34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(867270)
addappid(871910)
addappid(892340)
