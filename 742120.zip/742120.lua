-- Lua provided by RyzenAPI
-- Game: addappid(742120)

-- MAIN APPLICATION
addappid(742120)

-- MAIN APP DEPOTS / PACKAGES
addappid(742121, 1, "3d347e3e1e6dd1c1e429317128682f3fb815fe544dd92aae06d621e06b90fc34")
