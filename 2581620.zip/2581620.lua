-- Lua provided by RyzenAPI
-- Game: 2581620

-- MAIN APPLICATION
addappid(2581620)
-- Game: addappid(2581620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581621, 1, "bdb48536db059b4bdebefec2cf7bd4e49f6406ca129463ff05fd8212808eccdf")
