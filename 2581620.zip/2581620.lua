-- Lua provided by SkyAPI 
-- Game: Rawisland
addappid(2581620)
addappid(2581621, 1, "bdb48536db059b4bdebefec2cf7bd4e49f6406ca129463ff05fd8212808eccdf")
