-- Lua provided by RyzenAPI
-- Game: 2087940

-- MAIN APPLICATION
addappid(2087940)
-- Game: addappid(2087940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087941, 1, "31fb1d917c1bced0aaa4504d1a97d54b3a6058a70fc2435ede57658e7a8b97a9")
