-- Lua provided by RyzenAPI
-- Game: Game: Pickup Point Simulator

-- MAIN APPLICATION
addappid(2316030)
-- Game: addappid(2316030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316031, 1, "758579f53006a13750577f7712503dc6398e61d1b4449de56afc76f3ddd375f7")
