-- Lua provided by RyzenAPI
-- Game: Pickup Point Simulator

-- MAIN APPLICATION
addappid(2316030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316031, 1, "758579f53006a13750577f7712503dc6398e61d1b4449de56afc76f3ddd375f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
