-- Lua provided by RyzenAPI 
-- Game: Pickup Point Simulator
addappid(2316030)
addappid(2316031, 1, "758579f53006a13750577f7712503dc6398e61d1b4449de56afc76f3ddd375f7")
