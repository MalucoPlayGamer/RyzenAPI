-- Lua provided by RyzenAPI
-- Game: Game: Summoner Apprentice

-- MAIN APPLICATION
addappid(1450240)
-- Game: addappid(1450240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450241, 1, "9dcb8991dd61afa1103e11efac9656ab702be351bbf20ee51a985a79ff4f589a")
