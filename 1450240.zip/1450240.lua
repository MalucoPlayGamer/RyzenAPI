-- Lua provided by RyzenAPI 
-- Game: Summoner Apprentice
addappid(1450240)
addappid(1450241, 1, "9dcb8991dd61afa1103e11efac9656ab702be351bbf20ee51a985a79ff4f589a")
