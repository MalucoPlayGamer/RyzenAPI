-- Lua provided by RyzenAPI
-- Game: AppID 1241160

-- MAIN APPLICATION
addappid(1241160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241161, 1, "36fbb15fee465f00d0c81bfee80e60dff8ec5fb278eceb54073225e84c78940f")

