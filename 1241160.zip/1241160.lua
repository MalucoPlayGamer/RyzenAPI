-- Lua provided by RyzenAPI
-- Game: AppID 1241160

-- MAIN APPLICATION
addappid(1241160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241161, 1, "36fbb15fee465f00d0c81bfee80e60dff8ec5fb278eceb54073225e84c78940f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
