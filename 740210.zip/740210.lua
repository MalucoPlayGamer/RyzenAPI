-- Lua provided by RyzenAPI
-- Game: AppID 740210

-- MAIN APPLICATION
addappid(740210)
-- Game: addappid(740210)

-- MAIN APP DEPOTS / PACKAGES
addappid(740211, 1, "c4586a8a33fa1b54b86f412a2a56314d9c3458e2735e901d27befc2c431cd6f1")
