-- Lua provided by SkyAPI 
-- Game: Chess Knight 2
addappid(526880)
addappid(526881, 1, "d23c41dc5b9c213302fda3abaf60f7fcc93fb9a0aae8f970e3863747d6070127")
