-- Lua provided by RyzenAPI
-- Game: 526880

-- MAIN APPLICATION
addappid(526880)
-- Game: addappid(526880)

-- MAIN APP DEPOTS / PACKAGES
addappid(526881, 1, "d23c41dc5b9c213302fda3abaf60f7fcc93fb9a0aae8f970e3863747d6070127")
