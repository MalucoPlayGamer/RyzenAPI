-- Lua provided by RyzenAPI
-- Game: Vox Populi: Europa 2024

-- MAIN APPLICATION
addappid(2842880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842881, 1, "37d85451358983bc917f6caee4c46c1effb3398348bd057458cf2f95481907f9")

