-- Lua provided by SkyAPI 
-- Game: AppID 3527750
addappid(3527750)
addappid(3527751, 1, "68cccec0ec591c10aac6096dcaa2867dfbaee2805139603f763dbd10b83cba85")
