-- Lua provided by RyzenAPI
-- Game: Game: AppID 2237550

-- MAIN APPLICATION
addappid(2237550)
-- Game: addappid(2237550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237551, 1, "cb26b7713a55ee053340262144172f6762391d0ab1edb68995d2b1ea7fc02d28")
