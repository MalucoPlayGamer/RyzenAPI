-- Lua provided by RyzenAPI
-- Game: Tile Cities

-- MAIN APPLICATION
addappid(1957990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1957991, 1, "23025eaf6a038dce8d181dd1387f9edadfab72412ff30a3bcf485260bc20db82")

