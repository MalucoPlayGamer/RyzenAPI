-- Lua provided by RyzenAPI
-- Game: Tile Cities

-- MAIN APPLICATION
addappid(1957990)
-- Game: addappid(1957990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957991, 1, "23025eaf6a038dce8d181dd1387f9edadfab72412ff30a3bcf485260bc20db82")
