-- Lua provided by RyzenAPI
-- Game: Imitating Zombies

-- MAIN APPLICATION
addappid(1798310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798311, 1, "479bd4cb3f45aac7d1eba5f9ba04055c4b9e9237ad7ab4c2ec1141939dcb6dd4")

