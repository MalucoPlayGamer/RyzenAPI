-- Lua provided by RyzenAPI
-- Game: addappid(2102480)

-- MAIN APPLICATION
addappid(2102480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102481, 1, "d67c66f5d134ba4633067de6426be4ab08bf59767fa1c531984457b5fb94564d")
