-- Lua provided by RyzenAPI
-- Game: Game: Concealed

-- MAIN APPLICATION
addappid(2027960)
-- Game: addappid(2027960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027961, 1, "1200033f6920ebb04a8ade128a5df3806b66d5185fbc0f1ff6b089cd970697da")
