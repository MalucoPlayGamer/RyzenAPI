-- Lua provided by RyzenAPI
-- Game: Bowling at the Lake

-- MAIN APPLICATION
addappid(566150)

-- MAIN APP DEPOTS / PACKAGES
addappid(566151, 1, "24fba60c124ba1e08814f226c88379b5095c119a92fe621b57e2f69fbb796371")
