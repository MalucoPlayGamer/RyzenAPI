-- Lua provided by RyzenAPI 
-- Game: AppID 341780
addappid(341780)
addappid(341781, 1, "b2065041b78d853e6780c27cae88fec923b682c8c1f7c88ffdc3165a4737763d")
