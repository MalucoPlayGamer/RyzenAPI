-- Lua provided by RyzenAPI
-- Game: Grim Facade: A Wealth of Betrayal Collector's Edition

-- MAIN APPLICATION
addappid(786080)

-- MAIN APP DEPOTS / PACKAGES
addappid(786081,0,"ea4f782ff39fa8180c9bc7e60163a3a3f0d8764dbda0106635d14b679705afce")

