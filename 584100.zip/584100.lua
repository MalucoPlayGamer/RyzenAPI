-- Lua provided by RyzenAPI 
-- Game: Mad Digger
addappid(584100)
addappid(584101, 1, "f26ceb8a742ed2debe332ceffe547a72dab5880d497c2d2ec59f653c30141859")
addappid(946750, 0, "55d35a483cf1b09665d7ac7490720122294b065e1cfbd404588c3646a24051f1")
