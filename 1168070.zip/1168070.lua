-- Lua provided by RyzenAPI
-- Game: Game: Mystery Solitaire The Arkham Spirits

-- MAIN APPLICATION
addappid(1168070)
-- Game: addappid(1168070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168071, 1, "1c5af31072d2985299c56b05a6c14274a57df53fcaa3bc910f5ef5810e594dd0")
addappid(1168074, 1, "810aa957a52262b171c926f5a8ae1287c6bbd3a5e018ffe4eb6bcd8b4e315951")
