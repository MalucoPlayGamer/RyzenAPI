-- Lua provided by RyzenAPI
-- Game: 1791680

-- MAIN APPLICATION
addappid(1791680)
-- Game: addappid(1791680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791681, 1, "860b4dae60f233ca10d12dd7f6473da8f67d4d10ce829c4ffddfdb3fb357a195")
