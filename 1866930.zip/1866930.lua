-- Lua provided by RyzenAPI
-- Game: Game: Coffee Talk Episode 2: Hibiscus & Butterfly Demo

-- MAIN APPLICATION
addappid(1866930)
-- Game: addappid(1866930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866931, 1, "7cb6c8ffa08b9c2369664ee3ac4f51642a6d3666f871bebb96742f0001357c4d")
