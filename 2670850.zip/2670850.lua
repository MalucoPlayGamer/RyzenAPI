-- Lua provided by RyzenAPI
-- Game: Train Valley World Demo

-- MAIN APPLICATION
addappid(2670850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670851, 1, "cbce42dca5e3de4b47104db328a98674716f9207adc3808d0e14969322d0872e")

