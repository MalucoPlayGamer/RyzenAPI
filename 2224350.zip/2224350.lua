-- Lua provided by RyzenAPI
-- Game: Celebrity Simulator

-- MAIN APPLICATION
addappid(2224350)
-- Game: addappid(2224350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224351, 1, "b1a26323ae6701a492ad58c60ab552a1dd97920ab59db2954b49eaaeb8ee7813")
