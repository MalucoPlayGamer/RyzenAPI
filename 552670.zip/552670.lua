-- Lua provided by RyzenAPI
-- Game: Rite of Passage: The Perfect Show Collector's Edition

-- MAIN APPLICATION
addappid(552670)

-- MAIN APP DEPOTS / PACKAGES
addappid(552671,0,"cb77abc013959a3cc8d3d0a0186c7e74b2712e39895289ad4e260fbee604cb65")

