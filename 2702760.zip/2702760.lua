-- Lua provided by RyzenAPI
-- Game: 2702760

-- MAIN APPLICATION
addappid(2702760)
-- Game: addappid(2702760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702761, 1, "8f9d52b19a3c80e5fc5fd36211a8e36cef76bd9612964c77a1d26030d178c28e")
