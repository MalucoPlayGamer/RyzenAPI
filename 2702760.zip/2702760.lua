-- Lua provided by RyzenAPI 
-- Game: Blood Engine
addappid(2702760)
addappid(2702761, 1, "8f9d52b19a3c80e5fc5fd36211a8e36cef76bd9612964c77a1d26030d178c28e")
