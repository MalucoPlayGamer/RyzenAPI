-- Lua provided by RyzenAPI
-- Game: AppID 562520

-- MAIN APPLICATION
addappid(562520)
-- Game: addappid(562520)

-- MAIN APP DEPOTS / PACKAGES
addappid(562521, 1, "402a60d73aa5d499ed40b8eeb5ff2403ac9b422259ac776df099a4c3f7a6361b")
