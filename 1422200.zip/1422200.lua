-- Lua provided by SkyAPI 
-- Game: Rev
addappid(1422200)
addappid(1422201, 1, "4deb606f7e110e472244bbb5956534b1ae1b2a16881148c508e58f55c3043346")
