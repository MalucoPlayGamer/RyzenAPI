-- Lua provided by RyzenAPI
-- Game: Rev

-- MAIN APPLICATION
addappid(1422200)
-- Game: addappid(1422200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422201, 1, "4deb606f7e110e472244bbb5956534b1ae1b2a16881148c508e58f55c3043346")
