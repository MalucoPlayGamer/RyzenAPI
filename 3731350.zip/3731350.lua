-- Lua provided by RyzenAPI 
-- Game: MEMOLOGY: ESCAPE OF MEMES
addappid(3731350)
addappid(3731351, 1, "2f3ed0b3dc70b9712a09384ff24395429ce6cb924e3808de0eeb89308e072a26")
