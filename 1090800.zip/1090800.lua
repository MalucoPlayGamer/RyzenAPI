-- Lua provided by RyzenAPI
-- Game: addappid(1090800)

-- MAIN APPLICATION
addappid(1090800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090801, 1, "c30398c205a6bed53c2cdea75568dfe0ecd264947ae91c5cef9f1493989d76ed")
