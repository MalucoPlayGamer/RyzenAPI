-- Lua provided by RyzenAPI
-- Game: AppID 1090800

-- MAIN APPLICATION
addappid(1090800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090801, 1, "c30398c205a6bed53c2cdea75568dfe0ecd264947ae91c5cef9f1493989d76ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
