-- Lua provided by RyzenAPI
-- Game: Neverwinter Nights: Premium Adventures Official Soundtrack

-- MAIN APPLICATION
addappid(738711)
-- Game: addappid(738711)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238610,0,"3a9d1830d1eec9692d5983b2017cf2034b6a11c9d1ebbfb681d96ac6303bd886")
