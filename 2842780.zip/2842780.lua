-- Lua provided by SkyAPI 
-- Game: Moses & Plato - Last Train to Clawville Demo
addappid(2842780)
addappid(2842781, 1, "0e9e1bd4430449f78d27ae766662788008eed366ae0f678bec20f7eccbf9285c")
