-- Lua provided by RyzenAPI
-- Game: 2842780

-- MAIN APPLICATION
addappid(2842780)
-- Game: addappid(2842780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842781, 1, "0e9e1bd4430449f78d27ae766662788008eed366ae0f678bec20f7eccbf9285c")
