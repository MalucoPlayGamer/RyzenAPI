-- Lua provided by RyzenAPI
-- Game: Viking Brothers 4

-- MAIN APPLICATION
addappid(836560)

-- MAIN APP DEPOTS / PACKAGES
addappid(836561, 1, "2ac16479f9707eadd3e3a4c53779bf03804195b7be60f55f871ccc0acec3743a")

