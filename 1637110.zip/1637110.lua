-- Lua provided by RyzenAPI
-- Game: MoneyFalls Coin Pusher Simulator

-- MAIN APPLICATION
addappid(1637110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637111, 1, "6475abfdddb078fbec7c9ba1d122d15caeb858b57c9c2dc04d882a5698029331")

