-- Lua provided by RyzenAPI
-- Game: addappid(3356790)

-- MAIN APPLICATION
addappid(3356790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356791, 1, "80554c66b4b33ada3fea50de7fccf1d1006aa3f2d99ba9a7c98a9ad380aacbcb")
