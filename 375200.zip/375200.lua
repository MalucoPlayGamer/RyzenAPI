-- Lua provided by RyzenAPI
-- Game: Game: Sakura Fantasy

-- MAIN APPLICATION
addappid(375200)
-- Game: addappid(375200)

-- MAIN APP DEPOTS / PACKAGES
addappid(375201, 1, "3f246d98fb9879b25a980d7d509b058c23776fe563fa36e137c9ae79e6339e30")
