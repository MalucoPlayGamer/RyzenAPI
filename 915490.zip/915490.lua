-- Lua provided by RyzenAPI
-- Game: Frontline Zed

-- MAIN APPLICATION
addappid(915490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(915491, 1, "7b54dcd752f80584864146512855d777ce1418a615b685dc7e4b1032b3504974")

