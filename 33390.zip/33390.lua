-- Lua provided by RyzenAPI
-- Game: addappid(33390)

-- MAIN APPLICATION
addappid(33390)

-- MAIN APP DEPOTS / PACKAGES
addappid(33391, 1, "55997f7d81dad9f438117aea0a2cd356a826b645ed0eb05d8efd5bf2e8c5d8cd")
