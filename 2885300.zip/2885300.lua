-- Lua provided by RyzenAPI
-- Game: Headquarters: World War II Soundtrack

-- MAIN APPLICATION
addappid(2885300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885301, 1, "8cd6c3cbbf85b1862106acea365460a4000b19738321f243b3b35d8c171937e3")
addappid(2885302, 1, "5b20c9916cda55b04976bd43f29f4c50212f9ff248105cfafcc1c6e78c0eadde")
