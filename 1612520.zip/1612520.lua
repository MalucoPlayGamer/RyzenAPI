-- Lua provided by RyzenAPI
-- Game: SmallZ

-- MAIN APPLICATION
addappid(1612520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612521, 1, "543c33a63f083ef53024b17d372c4d8faa8dd62fb106036900a5dc00ca038247")
addappid(1612522, 1, "b0422af726bcaa9199717831641f7e18965f0e23c5512ba2b3808bd350f6b0cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
