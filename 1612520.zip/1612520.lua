-- Lua provided by RyzenAPI 
-- Game: SmallZ
addappid(1612520)
addappid(1612521, 1, "543c33a63f083ef53024b17d372c4d8faa8dd62fb106036900a5dc00ca038247")
addappid(1612522, 1, "b0422af726bcaa9199717831641f7e18965f0e23c5512ba2b3808bd350f6b0cd")
