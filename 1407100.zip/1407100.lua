-- Lua provided by RyzenAPI
-- Game: [TDA00] Muv-Luv Unlimited: THE DAY AFTER - Episode 00 REMASTERED

-- MAIN APPLICATION
addappid(1407100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407101, 1, "12fab602806a1cd184a5202972d46e7b538b63cddf7071d6580b40dbe2180bdd")

