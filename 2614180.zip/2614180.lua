-- Lua provided by RyzenAPI
-- Game: 2614180

-- MAIN APPLICATION
addappid(2614180)
-- Game: addappid(2614180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614180,0,"a62e656c473e0e5c97285401aad423fabd3ed205d431e1a445cb594642e64bc6")
