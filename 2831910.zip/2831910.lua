-- Lua provided by RyzenAPI
-- Game: addappid(2831910)

-- MAIN APPLICATION
addappid(2831910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831911, 1, "4a1e01f16cc19c6733c81f52ea09dae9c6c59990dba9c518cebaf15cb0bc8818")
