-- Lua provided by SkyAPI 
-- Game: Ethereal Enigma
addappid(1069760)
addappid(1069761, 1, "9838039e05d436c7e1cc890285b510df36ba5d9b8968f10dc0815d66705d7877")
