-- Lua provided by RyzenAPI
-- Game: Prominence Poker

-- MAIN APPLICATION
addappid(384180)
-- Game: addappid(384180)

-- MAIN APP DEPOTS / PACKAGES
addappid(384181, 1, "de98b127ccb99c6a13287c8411df28274cce5f4e187ec160d2295457d7de675a")
