-- Lua provided by RyzenAPI
-- Game: Movavi Picverse - Photo Editing Software

-- MAIN APPLICATION
addappid(1403800)
-- Game: addappid(1403800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403801, 1, "6b21ba1db35f67f3de5439731babbb7644363faf29e8f3961aef8d989eec02c2")
