-- Lua provided by RyzenAPI
-- Game: From Space - Original Soundtrack

-- MAIN APPLICATION
addappid(2116960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116961, 1, "b6c877d0823639cdb789162ffe5b26d74fa7b63e0019a7145fde9003dd254845")
addappid(2116962, 1, "85086ca244fda5389cdaba4e8f293331d362828d40f7efb1e22de19a7cb349b2")

