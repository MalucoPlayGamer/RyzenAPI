-- Lua provided by RyzenAPI
-- Game: AppID 697750

-- MAIN APPLICATION
addappid(697750)
-- Game: addappid(697750)

-- MAIN APP DEPOTS / PACKAGES
addappid(697751, 1, "222ce92657049b06d589074ab0e7b0711ed3c4b7f3b556dca396837dc9628946")
