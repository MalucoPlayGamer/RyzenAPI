-- Lua provided by RyzenAPI
-- Game: BALL x PIT

-- MAIN APPLICATION
addappid(2062430)
-- Game: addappid(2062430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062431, 1, "5d28ee4226eb2240f32250a615d7cdf1e5beebec25073151597d734fc48d547c")
