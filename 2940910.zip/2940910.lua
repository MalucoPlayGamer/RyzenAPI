-- Lua provided by RyzenAPI
-- Game: addappid(2940910)

-- MAIN APPLICATION
addappid(2940910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940912,0,"a1df5fd02ad22357cf64026dcd99ecb5486bcc80c6fad846e3f1f8f8cc4eddad")
