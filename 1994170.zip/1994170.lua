-- Lua provided by RyzenAPI
-- Game: Game: Constantine

-- MAIN APPLICATION
addappid(1994170)
-- Game: addappid(1994170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994171, 1, "41d3571f7abd7b2cb89ee7edd3b7296e0987b24ead15206251a4276427cdc378")
