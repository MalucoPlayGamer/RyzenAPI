-- Lua provided by RyzenAPI
-- Game: AppID 445230

-- MAIN APPLICATION
addappid(445230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(445231, 1, "5b2e3e182b671e1cb70d1f10c494e80b381cf4c24614b3cb771489f1e4d99cc5")
addappid(445232, 1, "e51939221a01ca71f23bed844a7659d99a5d144a46b40c1da4a7d5307d1851ee")

