-- Lua provided by SkyAPI 
-- Game: Eternal Destiny
addappid(377880)
addappid(377881, 1, "2844a00935a9dbe24bd197db27143f62d2ec30c075f9f0bf31c47e9149281eae")
