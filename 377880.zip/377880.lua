-- Lua provided by RyzenAPI
-- Game: 377880

-- MAIN APPLICATION
addappid(377880)
-- Game: addappid(377880)

-- MAIN APP DEPOTS / PACKAGES
addappid(377881, 1, "2844a00935a9dbe24bd197db27143f62d2ec30c075f9f0bf31c47e9149281eae")
