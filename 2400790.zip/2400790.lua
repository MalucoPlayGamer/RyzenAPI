-- Lua provided by RyzenAPI
-- Game: AppID 2400790

-- MAIN APPLICATION
addappid(2400790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400791, 1, "4fe3b2b84d601520c61cb3d56e00d86bc27daae0b7a70da1fbcd798478610c6a")

