-- Lua provided by RyzenAPI
-- Game: addappid(2314211)

-- MAIN APPLICATION
addappid(2314211)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314211,0,"db3ba13aeb08c580831ddae67b40c2e92853f73a5e8f88b8a196d1a9d0703959")
