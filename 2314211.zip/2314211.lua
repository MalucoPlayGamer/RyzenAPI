-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2314211)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314211,0,"db3ba13aeb08c580831ddae67b40c2e92853f73a5e8f88b8a196d1a9d0703959")

