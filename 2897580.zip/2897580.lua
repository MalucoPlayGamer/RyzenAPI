-- Lua provided by RyzenAPI
-- Game: Idle Hero TD - Tower Defense RPG

-- MAIN APPLICATION
addappid(2897580)

