-- Lua provided by RyzenAPI
-- Game: Game: Let's Build a Zoo Soundtrack

-- MAIN APPLICATION
addappid(1801930)
-- Game: addappid(1801930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801931, 1, "cebe34da932a6601f2369f547ac4ea70a85e60f5c127662d865edb838240dfd9")
addappid(1801932, 1, "ea09675c09564219e1e6bd5e5d6e3d2e6a0c19f5d7b69c1404755009078dd2af")
