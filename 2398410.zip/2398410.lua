-- Lua provided by SkyAPI 
-- Game: Hyper Hentai Sexy Sensei
addappid(2398410)
addappid(2398411, 1, "5c072405841f33125d66daedd85b0dd4f466f323efdc1f4e7e557a41577aa510")
