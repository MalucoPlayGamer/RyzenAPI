-- Lua provided by RyzenAPI
-- Game: Game: Hyper Hentai Sexy Sensei

-- MAIN APPLICATION
addappid(2398410)
-- Game: addappid(2398410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398411, 1, "5c072405841f33125d66daedd85b0dd4f466f323efdc1f4e7e557a41577aa510")
