-- Lua provided by RyzenAPI
-- Game: The Wall Mustn't Fall

-- MAIN APPLICATION
addappid(2139440)
-- Game: addappid(2139440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139441, 1, "519712b170f18488e74919e18b8ff8d4c6e78c2bf40f34790ab9cdcdb9616ec5")
