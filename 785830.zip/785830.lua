-- Lua provided by RyzenAPI
-- Game: Adonis

-- MAIN APPLICATION
addappid(785830)

-- MAIN APP DEPOTS / PACKAGES
addappid(785831,0,"f89ea83dcac54716dcceef50a203fcaa9dfb10720e6edb5aced67d3a8e2ca271")

