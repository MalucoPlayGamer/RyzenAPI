-- Lua provided by RyzenAPI
-- Game: addappid(337880)

-- MAIN APPLICATION
addappid(337880)

-- MAIN APP DEPOTS / PACKAGES
addappid(337882,0,"d27057b6664e89d4abad48272c1709a40997cf1ad8b6c254871ee46f3affa815")
