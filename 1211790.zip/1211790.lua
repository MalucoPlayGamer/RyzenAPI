-- Lua provided by RyzenAPI
-- Game: Bad Girl

-- MAIN APPLICATION
addappid(1211790)
-- Game: addappid(1211790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211791, 1, "ffbab3391ab6333d181ba30979d09657972275c4650c0c260bb8d046799efd46")
