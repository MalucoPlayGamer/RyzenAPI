-- Lua provided by RyzenAPI
-- Game: Bad Girl

-- MAIN APPLICATION
addappid(1211790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1211791, 1, "ffbab3391ab6333d181ba30979d09657972275c4650c0c260bb8d046799efd46")

