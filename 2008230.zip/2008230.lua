-- Lua provided by RyzenAPI
-- Game: AppID 2008230

-- MAIN APPLICATION
addappid(2008230)
-- Game: addappid(2008230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008231, 1, "a9a6dc2a2187cf2dc8585bded7000fe73fdc61da23993f070140929fcf77b3df")
