-- Lua provided by RyzenAPI
-- Game: Walkerman

-- MAIN APPLICATION
addappid(387100)
-- Game: addappid(387100)

-- MAIN APP DEPOTS / PACKAGES
addappid(387102,0,"eb274dcef31221886e541643ee4e0e6abd8bccbfc57122673b29d4fa3c9357b9")
addappid(437360,0,"6316538e8cea532af44ed648190705411cda02674b4fab47c3c372f23c53f4bf")
