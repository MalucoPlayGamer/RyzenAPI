-- Lua provided by RyzenAPI
-- Game: Discord Bot Builder

-- MAIN APPLICATION
addappid(1119570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1119571, 1, "ccfe1ed90bc1639c0d6a17e3f847da573ec8e623fa98aa32c1e3035961a29582")

