-- Lua provided by RyzenAPI
-- Game: AppID 622950

-- MAIN APPLICATION
addappid(622950)
-- Game: addappid(622950)

-- MAIN APP DEPOTS / PACKAGES
addappid(622951, 1, "b71feae3e6e2a29bbb1ba781acf128cb427723aed16154f67bc83d073118d1b6")
