-- Lua provided by RyzenAPI
-- Game: Transit King Tycoon

-- MAIN APPLICATION
addappid(3811420)

