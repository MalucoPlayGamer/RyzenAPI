-- Lua provided by RyzenAPI
-- Game: Uriel's Chasm

-- MAIN APPLICATION
addappid(292630)

-- MAIN APP DEPOTS / PACKAGES
addappid(292631, 1, "e9c647e40212aba24bd877f0d4c05f69a1da17e6816b3616eba4447f5b8a3418")
