-- Lua provided by RyzenAPI
-- Game: Ember Knights

-- MAIN APPLICATION
addappid(2948140) -- Ember Knights - Wrath of the Architect

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(1135230, 1, "b0c6604202e7ce05440fbcdcf804b20084088d4ea89617589334d563012db949") -- Ember Knights
addappid(1135231, 1, "011afcb4ff95536d7fd9806e3c2b9b08d9dd0f69a69bd7b92076966562010938") -- Depot 1135231
addappid(1135232, 1, "4fb873edabfbd3320be661283c46fdc9dd7d5f9cc7d942b53790673083fe1b66") -- Depot 1135232
addappid(1135233, 1, "4d1fcf06977e3d03c39fb17cba2a677245bff774d0d225bf0835cd6a88e79171") -- Depot 1135233

