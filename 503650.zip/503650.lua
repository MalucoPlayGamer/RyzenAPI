-- Lua provided by RyzenAPI
-- Game: Fenimore Fillmore: The Westerner

-- MAIN APPLICATION
addappid(503650)

-- MAIN APP DEPOTS / PACKAGES
addappid(503651, 1, "206ab5c3e6ffa2c5be3a5b83e04a323b4803dec4972abce3c0bad02446c849c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
