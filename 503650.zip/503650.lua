-- Lua provided by RyzenAPI
-- Game: 503650

-- MAIN APPLICATION
addappid(503650)
-- Game: addappid(503650)

-- MAIN APP DEPOTS / PACKAGES
addappid(503651, 1, "206ab5c3e6ffa2c5be3a5b83e04a323b4803dec4972abce3c0bad02446c849c5")
