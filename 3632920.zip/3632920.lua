-- Lua provided by RyzenAPI
-- Game: addappid(3632920)

-- MAIN APPLICATION
addappid(3632920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3632920,0,"2425f5d8f1b396e2e8237a68bc7e15d6fdd0456d013c9032c600d0c6abaf7b8c")
