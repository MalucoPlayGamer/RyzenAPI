-- Lua provided by RyzenAPI
-- Game: World Racing 2 - Champion Edition

-- MAIN APPLICATION
addappid(1301010)
addappid(3463480)
-- Game: addappid(1301010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301011, 1, "60b681610300fafb0b5af61d04d61e01c2436241c7958e9d1e04a3870d9bb8a7")
