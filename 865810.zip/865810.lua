-- Lua provided by RyzenAPI
-- Game: Waifu Fight Dango Style

-- MAIN APPLICATION
addappid(865810)

-- MAIN APP DEPOTS / PACKAGES
addappid(865811, 1, "c334f57c8946950265ce5151f60c7f23c2ee6e7f339f245bd055a8455d34c45c")
addappid(865812, 1, "1b4de9a07b6d6bf2dddd0a11f5025950764518ab44aa6350880a35ce0b3059f4")

