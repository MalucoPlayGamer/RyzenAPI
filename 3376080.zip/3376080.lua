-- Lua provided by RyzenAPI
-- Game: The Leviathan's fantasy

-- MAIN APPLICATION
addappid(3376080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376081, 1, "3fe0ea7d856c0431a2fd1ce4605b7d8f379c45fa41d47f17c4a8a3ceac051d67")

