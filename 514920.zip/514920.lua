-- Lua provided by RyzenAPI
-- Game: AppID 514920

-- MAIN APPLICATION
addappid(514920)

-- MAIN APP DEPOTS / PACKAGES
addappid(514921, 1, "19bc90ba2525e2cb62faade74b28257ae40332981d42fa012b3beb811c9cc36b")

