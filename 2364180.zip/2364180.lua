-- Lua provided by RyzenAPI
-- Game: The Merry Fairy

-- MAIN APPLICATION
addappid(2364180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364181, 1, "3d3b0895e00e1b4e91daa3ffb9a4ffa1e431dd4bf6040d233ea86d3f431df3c6")

