-- Lua provided by RyzenAPI
-- Game: addappid(388680)

-- MAIN APPLICATION
addappid(388680)

-- MAIN APP DEPOTS / PACKAGES
addappid(388682,0,"866de58b2f83032cd4dc28d5169e3ab1768c3c2b35ca75c83f047e13496336c1")
