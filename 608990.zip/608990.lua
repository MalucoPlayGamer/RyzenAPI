-- Lua provided by RyzenAPI
-- Game: The Archotek Project

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228987)
addappid(228990)
addappid(229006)
addappid(229020)
addappid(229033)
addappid(608990)
addappid(608991)

-- MAIN APP DEPOTS / PACKAGES
addappid(608992,0,"219ba2730764fbca45d13906be2c23ece4fef4977c256bbe7dbc23011a9aab25")
addappid(608993,0,"704800ece01ec26cf25dd5ce5ee1b907a50f65b587eda6cb408df930398e8008")
addappid(608994,0,"3690c13d0c8eccd0d682d1217abed56d5a80b443eebbbd8a3364da81df6731c0")
