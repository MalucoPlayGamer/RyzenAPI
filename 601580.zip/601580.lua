-- Lua provided by RyzenAPI
-- Game: AppID 601580

-- MAIN APPLICATION
addappid(601580)
-- Game: addappid(601580)

-- MAIN APP DEPOTS / PACKAGES
addappid(601581, 1, "44478bd250a1e5ef28b892ac153026774ef196ddb5eca3def84312c37831a642")
