-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1461200)
addappid(1461202)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461203,0,"285be3b43c91b7db43c3f5bfc4702ee1bbd306ed23f987369c42e8bf2326a00e")

