-- Lua provided by RyzenAPI
-- Game: Blood Poker

-- MAIN APPLICATION
addappid(2904800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904801, 1, "f7c5f6eb2f687d88c5a419e1bae65014dc9afeeda4507295a3ab05d4e7815083")

