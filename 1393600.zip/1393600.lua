-- Lua provided by RyzenAPI
-- Game: AppID 1393600

-- MAIN APPLICATION
addappid(1393600)
-- Game: addappid(1393600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393601, 1, "5b54e5bcd1d142744e6ffe9885406d5d50844e5cecd8c8b9a6c024d8bfa08287")
