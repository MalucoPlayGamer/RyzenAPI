-- Lua provided by SkyAPI 
-- Game: Office Affairs
addappid(2420520)
addappid(2420521, 1, "766b8a56720427469cb934e1a8a07cfe87b5954f8101a8548a4d01aaf629f4cd")
