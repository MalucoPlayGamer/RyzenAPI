-- Lua provided by RyzenAPI
-- Game: Dialtown: Roger's Route DLC

-- MAIN APPLICATION
addappid(3170530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170530,0,"6a1123c60803bfe95574212a31bcda387be7239cade130576a238bae896f22ef")

