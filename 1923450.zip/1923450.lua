-- Lua provided by RyzenAPI 
-- Game: Building destruction
addappid(1923450)
addappid(1923451, 1, "0a59f41eae649ea663b8bea1fc4b24ad3b680a836092878cfa649ad7215ba1bc")
