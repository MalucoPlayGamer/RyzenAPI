-- Lua provided by RyzenAPI
-- Game: Building destruction

-- MAIN APPLICATION
addappid(1923450)
-- Game: addappid(1923450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923451, 1, "0a59f41eae649ea663b8bea1fc4b24ad3b680a836092878cfa649ad7215ba1bc")
