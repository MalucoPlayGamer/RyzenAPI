-- Lua provided by RyzenAPI
-- Game: Hot Guns: International Missions

-- MAIN APPLICATION
addappid(2119550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119551, 1, "515eae8c7c2ddec95b55fa33a155779292715068918342f1951697a96424823c")

