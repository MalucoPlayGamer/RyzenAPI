-- Lua provided by RyzenAPI
-- Game: The Neverland of the Mountain and Sea

-- MAIN APPLICATION
addappid(1261220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261221, 1, "1f8fe8b95d94044f2786221da0cccf43154444ae695184ae85ce0b07b70ee1a1")

