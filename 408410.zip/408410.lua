-- Lua provided by RyzenAPI
-- Game: X-Morph: Defense

-- MAIN APPLICATION
addappid(408410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(408411, 1, "fa3df2d2b3c6cd1fd696bd4d51acb7a899378945976eb7b25b2c23152807b6a1")
addappid(800340, 0, "b303c2dee0457e8c87a66e5ee7427fa0db727eaf771ab6aaebfea51831e4ffd8")
addappid(800341, 0, "7585d207207c06803ab92c918484d2ca28d58558b2a4dfc0009fcce2d203a4c6")
addappid(800342, 0, "cd3decdd9d4e5dfa92b3c07ba9126446b543a0e5441158e57fc485c3cb318205")

