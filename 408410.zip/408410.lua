-- Lua provided by RyzenAPI
-- Game: X-Morph: Defense

-- MAIN APPLICATION
addappid(408410)

-- MAIN APP DEPOTS / PACKAGES
addappid(408411, 1, "fa3df2d2b3c6cd1fd696bd4d51acb7a899378945976eb7b25b2c23152807b6a1")
addappid(800340, 0, "b303c2dee0457e8c87a66e5ee7427fa0db727eaf771ab6aaebfea51831e4ffd8")
addappid(800341, 0, "7585d207207c06803ab92c918484d2ca28d58558b2a4dfc0009fcce2d203a4c6")
addappid(800342, 0, "cd3decdd9d4e5dfa92b3c07ba9126446b543a0e5441158e57fc485c3cb318205")
