-- Lua provided by RyzenAPI
-- Game: 2321430

-- MAIN APPLICATION
addappid(2321430)
-- Game: addappid(2321430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321431, 1, "5bb800500b019aa3e7cf3a7362ae3e8561340180ce8a388d462fe7d5ab69e67f")
