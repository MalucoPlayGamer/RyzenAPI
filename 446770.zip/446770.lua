-- Lua provided by RyzenAPI
-- Game: Game: AppID 446770

-- MAIN APPLICATION
addappid(446770)
-- Game: addappid(446770)

-- MAIN APP DEPOTS / PACKAGES
addappid(446771, 1, "fb83502de065b878debd7ab0956abdd2bf2d34ce06b0db1762e62f1661d2817c")
