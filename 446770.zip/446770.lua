-- Lua provided by RyzenAPI
-- Game: Skeet: VR Target Shooting

-- MAIN APPLICATION
addappid(446770)
addappid(567420)
addappid(567421)
addappid(567422)

-- MAIN APP DEPOTS / PACKAGES
addappid(446771, 1, "fb83502de065b878debd7ab0956abdd2bf2d34ce06b0db1762e62f1661d2817c")

