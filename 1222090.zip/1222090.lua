-- Lua provided by RyzenAPI
-- Game: Nevaeh

-- MAIN APPLICATION
addappid(1222090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1222091, 1, "7e4f5a4567a2ba87f87ea6cb571c9000cfa7717322d038b9ea7ad38ddab8f666")

