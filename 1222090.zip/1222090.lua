-- Lua provided by RyzenAPI
-- Game: addappid(1222090)

-- MAIN APPLICATION
addappid(1222090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222091, 1, "7e4f5a4567a2ba87f87ea6cb571c9000cfa7717322d038b9ea7ad38ddab8f666")
