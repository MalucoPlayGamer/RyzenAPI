-- Lua provided by RyzenAPI
-- Game: addappid(1249800)

-- MAIN APPLICATION
addappid(1249800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249801, 1, "13e26712e971d002805e693d3e3ca5dccdd2f74afeb7991155a0b060fa3e10a0")
