-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword VII

-- MAIN APPLICATION
addappid(1249800)
addappid(1430590)
addappid(1463060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1249801, 1, "13e26712e971d002805e693d3e3ca5dccdd2f74afeb7991155a0b060fa3e10a0")

