-- Lua provided by RyzenAPI
-- Game: 眼傀公司（EyePuppet Campany）

-- MAIN APPLICATION
addappid(3344790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344791, 1, "97b262a79892bae96718a20b8dbbb815414ee598ac2278c81a30bbea9e0e2076")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
