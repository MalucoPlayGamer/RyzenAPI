-- Lua provided by RyzenAPI
-- Game: Mice Tea

-- MAIN APP DEPOTS / PACKAGES
addappid(2108950, 1, "36a3c4da05155001235610b62bc16a25d591e7afc5cbbe8e276f0966a4a734ac")
addappid(2108951, 1, "7e4e4497da412777c9c9f692cef4fa4ad801c226840cf0366cd626afef539413")

