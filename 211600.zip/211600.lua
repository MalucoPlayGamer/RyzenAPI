-- Lua provided by SkyAPI 
-- Game: Thief Gold (1999)
addappid(211600)
addappid(211601, 1, "8b20160d6813a2590689f9dbdbccbd3e03fb49d81028fa0738552608bdd5490f")
