-- Lua provided by RyzenAPI
-- Game: 211600

-- MAIN APPLICATION
addappid(211600)
-- Game: addappid(211600)

-- MAIN APP DEPOTS / PACKAGES
addappid(211601, 1, "8b20160d6813a2590689f9dbdbccbd3e03fb49d81028fa0738552608bdd5490f")
