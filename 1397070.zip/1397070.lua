-- Lua provided by RyzenAPI
-- Game: addappid(1397070)

-- MAIN APPLICATION
addappid(1397070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397071, 1, "bab02cf932ff98895b0cbd2cb149345263c8613b32c603d1d11101f3cf5faaf7")
