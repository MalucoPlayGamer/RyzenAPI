-- Lua provided by RyzenAPI
-- Game: addappid(507440)

-- MAIN APPLICATION
addappid(507440)
addappid(541810)
addappid(541940)

-- MAIN APP DEPOTS / PACKAGES
addappid(507441, 1, "b19866dd93472010abc8142e946bbe8d7f1c585cf1e10f72b744abf66b51206f")
