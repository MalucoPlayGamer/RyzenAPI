-- Lua provided by RyzenAPI
-- Game: 1814630

-- MAIN APPLICATION
addappid(1814630)
-- Game: addappid(1814630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814631, 1, "52f9d55c588e97ce483c8fc55e2219e840991b65bdb120dd2692462fbe13557e")
