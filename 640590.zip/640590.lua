-- Lua provided by RyzenAPI
-- Game: The LEGO® NINJAGO® Movie Video Game

-- MAIN APPLICATION
addappid(640590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(640591, 1, "70268affa8eab320c96d84bda04044dd40519c38d0ea0be60c426ae759303b80")

