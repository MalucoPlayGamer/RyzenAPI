-- Lua provided by RyzenAPI
-- Game: addappid(640590)

-- MAIN APPLICATION
addappid(640590)

-- MAIN APP DEPOTS / PACKAGES
addappid(640591, 1, "70268affa8eab320c96d84bda04044dd40519c38d0ea0be60c426ae759303b80")
