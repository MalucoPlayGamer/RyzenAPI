-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Saint Croix XP

-- MAIN APPLICATION
addappid(2427061)
-- Game: addappid(2427061)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427061,0,"98e2b9c19f040cb486d202578e41847249e1f82b546ccba650d752e75baa4d8d")
