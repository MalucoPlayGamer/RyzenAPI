-- Lua provided by RyzenAPI
-- Game: 1369030

-- MAIN APPLICATION
addappid(1369030)
-- Game: addappid(1369030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369031, 1, "c146f31c1e0c15b5727a0ec1c5b0dd642c0cd5d0ab447ad8a7ee35adc15763e1")
