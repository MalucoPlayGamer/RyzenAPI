-- Lua provided by RyzenAPI 
-- Game: 校园恋物语|Love in School
addappid(899940)
addappid(899941, 1, "5dfebe46ca8f6ea39ade4a0c7f4ee40521ffc32551d9bd717b182a4c72db8d5a")
addappid(899942, 1, "bacb8d9fa418462b56df9c48071bc0eb0e22bd53b715f8e54bfb6f939fa7eb81")
addappid(911860)
addappid(911861)
