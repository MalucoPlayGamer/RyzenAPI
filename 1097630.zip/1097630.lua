-- Lua provided by RyzenAPI
-- Game: 1097630

-- MAIN APPLICATION
addappid(1097630)
-- Game: addappid(1097630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097631, 1, "5d3292e3f9bb424f58e8933f285a44f370a46fef91e9be8e6783f6d14a639d6b")
