-- Lua provided by RyzenAPI
-- Game: 1023270

-- MAIN APPLICATION
addappid(1023270)
-- Game: addappid(1023270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023271, 1, "b64a3626d1b5ac31a697ac03481c8a0fbac5a4c4ea6db022ca01a9ad6ff341c7")
