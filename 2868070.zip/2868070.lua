-- Lua provided by RyzenAPI
-- Game: addappid(2868070)

-- MAIN APPLICATION
addappid(2868070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868071, 1, "f67c0920d2c69e2fd826fb71d6c0e933f7595e4ff7ab02cebcee583a8d0fc9fb")
