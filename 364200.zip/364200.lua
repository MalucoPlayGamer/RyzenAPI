-- Lua provided by RyzenAPI
-- Game: Farabel

-- MAIN APPLICATION
addappid(364200)

-- MAIN APP DEPOTS / PACKAGES
addappid(364201, 1, "b3837bf48e3605a9fe0c7bffc32685ee4dd66a77f1901c3300076b7751be08b6")
addappid(364202, 1, "834cd49acd679fc12fd6ee22094f88811e2192bae6f65046142df9f52afb0a2a")
addappid(364203, 1, "f2f7c41af78a3fd4f8a7b5fd77ab5d3188b7cab025b83fe086b52900396ee35e")

