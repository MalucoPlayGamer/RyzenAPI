-- Lua provided by RyzenAPI
-- Game: AppID 1168170

-- MAIN APPLICATION
addappid(1168170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168171, 1, "2a569fbb4ff5d927c3290fe31fcbb2156881135a291c7512961c252be4443726")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1179950)
