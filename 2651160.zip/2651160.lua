-- Lua provided by RyzenAPI
-- Game: 2651160

-- MAIN APPLICATION
addappid(2651160)
-- Game: addappid(2651160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651161, 1, "01db91f78bba40f4dc2673880c026f4b930061354cbe5c6793b3a5e72045ce30")
