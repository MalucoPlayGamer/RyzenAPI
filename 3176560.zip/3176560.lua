-- Lua provided by RyzenAPI
-- Game: [Southern Fjords] Newspaper Day

-- MAIN APPLICATION
addappid(3176560)
-- Game: addappid(3176560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176561, 1, "0aba2ded7570c7f70f7aa53d094684390d690d8e0a658081a2953c9aad6e5798")
