-- Lua provided by RyzenAPI
-- Game: 2142240

-- MAIN APPLICATION
addappid(2142240)
-- Game: addappid(2142240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142241, 1, "741bcac75e1b3eec208edd8827aca0a32927ffb53a7fa499792845230358ca61")
