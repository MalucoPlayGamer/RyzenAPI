-- Lua provided by RyzenAPI
-- Game: V.A Proxy Demo

-- MAIN APPLICATION
addappid(2064920)
-- Game: addappid(2064920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064921, 1, "8f90f7878dd0de32f9eccbc251c1441cbad6a237e3158639548ff9d68dd7b9fe")
