-- Lua provided by RyzenAPI
-- Game: BattleCubes: Arena

-- MAIN APPLICATION
addappid(1036330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036331, 1, "de913addd2a7eda95a5c9f0e29422667e943498d68e7180c857578fd2ae4c04f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
