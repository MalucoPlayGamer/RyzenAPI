-- Lua provided by RyzenAPI
-- Game: 1036330

-- MAIN APPLICATION
addappid(1036330)
-- Game: addappid(1036330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036331, 1, "de913addd2a7eda95a5c9f0e29422667e943498d68e7180c857578fd2ae4c04f")
