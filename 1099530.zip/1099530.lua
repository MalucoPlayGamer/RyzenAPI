-- Lua provided by RyzenAPI 
-- Game: HENTAI EXOTICA
addappid(1099530)
addappid(1099531, 1, "63a38845b06a25a8d343c73b160755d8f43bb969f983a844760d0c4fb9272938")
