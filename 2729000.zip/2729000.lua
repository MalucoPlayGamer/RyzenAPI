-- Lua provided by RyzenAPI
-- Game: Game: Cats and Seek: Dino Park

-- MAIN APPLICATION
addappid(2729000)
-- Game: addappid(2729000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729001, 1, "82abba26be62ca76ddd83d3ef4a6b0b77ec4cee08a1bee3faae1032ce41224cb")
