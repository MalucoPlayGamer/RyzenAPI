-- Lua provided by RyzenAPI
-- Game: Firelight Fantasy: Phoenix Crew

-- MAIN APPLICATION
addappid(1595000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595001, 1, "055fc639d09b1f137bcfccec5a8fec3c44581c401ecaa16ccc9d4602270e9f3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
