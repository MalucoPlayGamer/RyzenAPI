-- Lua provided by RyzenAPI
-- Game: Firelight Fantasy: Phoenix Crew

-- MAIN APPLICATION
addappid(1595000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595001, 1, "055fc639d09b1f137bcfccec5a8fec3c44581c401ecaa16ccc9d4602270e9f3d")
