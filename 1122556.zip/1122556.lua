-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Intermediate String Skipping Exercise 2

-- MAIN APPLICATION
addappid(1122556)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122556,0,"f4006c9949670336e846e774916a28134df35a48bff24311bb11001bbbe88d50")

