-- Lua provided by RyzenAPI 
-- Game: Mutrix
addappid(2433760)
addappid(2433761, 1, "d23bc2f8686af4c7ba8ff8100bfd6217e91ece0389276df66fb3ae41821931c4")
