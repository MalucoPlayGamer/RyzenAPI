-- Lua provided by RyzenAPI
-- Game: Approaching Blocks

-- MAIN APPLICATION
addappid(467390)
-- Game: addappid(467390)

-- MAIN APP DEPOTS / PACKAGES
addappid(467391, 1, "d335da020ce6e03327c8d499c24fec72265a415d4df5ebbfa8fc854e299a797b")
addappid(467392, 1, "91655b4778574a822c3d623a019ec8f5160c689c9280f79a2465035eddc2374a")
addappid(467393, 1, "c1a4ca57e2344f61e34b8667c1c01e580ebdc0ef17e6bfce9aaad8f2b0f7bc52")
