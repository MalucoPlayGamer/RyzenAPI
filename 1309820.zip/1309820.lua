-- Lua provided by RyzenAPI
-- Game: Remains

-- MAIN APPLICATION
addappid(1309820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309821, 1, "32d6e62e0343bd888f0bffcbb0c9e5960d38db6ed8f3258b1b8ccd3ff13d497d")
