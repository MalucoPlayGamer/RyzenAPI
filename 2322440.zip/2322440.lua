-- Lua provided by RyzenAPI
-- Game: 2322440

-- MAIN APPLICATION
addappid(2322440)
-- Game: addappid(2322440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322441, 1, "f0bd7d0406eb4eacc6c1f59f7eda02d3c336a79d276daead606ba6833017e15a")
