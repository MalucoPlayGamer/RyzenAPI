-- Lua provided by RyzenAPI
-- Game: 2606240

-- MAIN APPLICATION
addappid(2606240)
-- Game: addappid(2606240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606241, 1, "78a22cd15c36f33efe2ab49b05384852730c9d07ac37a00d756d847a364ecfe9")
