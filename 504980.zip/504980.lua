-- Lua provided by RyzenAPI
-- Game: AppID 504980

-- MAIN APPLICATION
addappid(504980)
-- Game: addappid(504980)

-- MAIN APP DEPOTS / PACKAGES
addappid(504981, 1, "b1b8252edaec29ac68103ea2476f6bc0d7369807959148efb10f7e7c2beac091")
