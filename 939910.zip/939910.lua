-- Lua provided by RyzenAPI
-- Game: 939910

-- MAIN APPLICATION
addappid(939910)

-- MAIN APP DEPOTS / PACKAGES
addappid(939914,0,"efc28dfe5d0e362911e05737e043645eab52e8c8a0aa3230e3ee6abc2e5d32a3")

