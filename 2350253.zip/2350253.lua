-- Lua provided by RyzenAPI
-- Game: addappid(2350253)

-- MAIN APPLICATION
addappid(2350253)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350253,0,"df4e6d49e629bf92cd84d8d399cb3320bba38bfc2ebd025c450ea1a4aecd616f")
