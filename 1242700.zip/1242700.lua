-- Lua provided by RyzenAPI
-- Game: addappid(1242700)

-- MAIN APPLICATION
addappid(1242700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242701, 1, "72a254679c0d4e10374f05691c8835ff3a4c98ed478d22bb1a0ef149adda9423")
