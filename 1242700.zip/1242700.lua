-- Lua provided by RyzenAPI
-- Game: 墲人之境-无人之境

-- MAIN APPLICATION
addappid(1242700)
addappid(1280390)
addappid(1284060)
addappid(1289920)
addappid(1307720)
addappid(1484190)
addappid(1501170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242701, 1, "72a254679c0d4e10374f05691c8835ff3a4c98ed478d22bb1a0ef149adda9423")

