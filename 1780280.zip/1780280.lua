-- Lua provided by RyzenAPI
-- Game: Game: Find The Murderer

-- MAIN APPLICATION
addappid(1780280)
-- Game: addappid(1780280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780281, 1, "273e3a249001dcd99857b4c879fa30ea111d086d8d3a6a26eec69f096f6a375f")
