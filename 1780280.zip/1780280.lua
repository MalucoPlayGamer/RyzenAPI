-- Lua provided by RyzenAPI
-- Game: Find The Murderer

-- MAIN APPLICATION
addappid(1780280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780281, 1, "273e3a249001dcd99857b4c879fa30ea111d086d8d3a6a26eec69f096f6a375f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
