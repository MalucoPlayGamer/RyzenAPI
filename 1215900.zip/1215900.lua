-- Lua provided by RyzenAPI
-- Game: Game: The mysterious Case of Dr. Jekyll and Mr. Hyde

-- MAIN APPLICATION
addappid(1215900)
-- Game: addappid(1215900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215901, 1, "ac3d0e9efbd7393301953f8cc542548b8e229a8c19b8bd31bd4747e39db72120")
