-- Lua provided by SkyAPI 
-- Game: AppID 1126120
addappid(1126120)
addappid(1126121, 1, "dff3d4f6923b4c3caf4c54525ac00c582b5555fcb24f8bf6fb4977337dce6929")
addappid(1126122, 1, "4f83cfdc277c9af366ddb983ca8860c0f0b3af8665367abc0e3b0dce975189e9")
addappid(1126123, 1, "c24ce6006466cc40ad31c2dd6680ad5f169f6f90a7c5c5c27fbc4da74b22d57c")
