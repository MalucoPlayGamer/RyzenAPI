-- Lua provided by RyzenAPI
-- Game: I'm Truely a Good Guy!

-- MAIN APPLICATION
addappid(3461300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461301, 1, "a54b964a09e27defc2a0040fe84f386c51df62e45e0e9c2f3ae76c6aa350492c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
