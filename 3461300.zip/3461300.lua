-- Lua provided by RyzenAPI
-- Game: 3461300

-- MAIN APPLICATION
addappid(3461300)
-- Game: addappid(3461300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461301, 1, "a54b964a09e27defc2a0040fe84f386c51df62e45e0e9c2f3ae76c6aa350492c")
