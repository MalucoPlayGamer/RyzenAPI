-- Lua provided by SkyAPI 
-- Game: Shadow Saboteur
addappid(2385980)
addappid(2385981, 1, "e0a407a5ec931233cf0b92b687a630c6c9255035580efc9017b54ce554504e60")
