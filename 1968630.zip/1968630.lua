-- Lua provided by RyzenAPI
-- Game: Stories from the Outbreak

-- MAIN APPLICATION
addappid(1968630)
-- Game: addappid(1968630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968631, 1, "c1cd1f7988b91da7b058975e486dbea32d58bc0260b7c2f6b96f2976595f798e")
