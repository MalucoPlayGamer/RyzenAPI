-- Lua provided by RyzenAPI
-- Game: addappid(1145120)

-- MAIN APPLICATION
addappid(1145120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145121, 1, "95abf8bce3dd82c4d691091f158461c39317e90926795470652097ddcdbedc80")
