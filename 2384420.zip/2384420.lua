-- Lua provided by RyzenAPI
-- Game: Fairy Fencer F: Refrain Chord - Deluxe Pack

-- MAIN APPLICATION
addappid(2384420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384420,0,"a09ce19ad624c77dbb1dba89c47debf57c361f59b09c35a82bceda7d70ce4ce1")

