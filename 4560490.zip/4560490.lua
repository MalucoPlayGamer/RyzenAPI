-- Lua provided by RyzenAPI
-- Game: Game: REWIND

-- MAIN APPLICATION
addappid(4560490)
-- Game: addappid(4560490)

-- MAIN APP DEPOTS / PACKAGES
addappid(4560491, 1, "e4903202eceb6c355bb7fc461345c111d888809b420a923ff87c28f9f77a82fa")
