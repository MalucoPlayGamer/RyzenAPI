-- Lua provided by RyzenAPI
-- Game: REWIND

-- MAIN APPLICATION
addappid(4560490)

-- MAIN APP DEPOTS / PACKAGES
addappid(4560491, 1, "e4903202eceb6c355bb7fc461345c111d888809b420a923ff87c28f9f77a82fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
