-- Lua provided by RyzenAPI
-- Game: Game: The Exit 8 VR

-- MAIN APPLICATION
addappid(3193770)
-- Game: addappid(3193770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193771, 1, "9a81515bbf87c0b6d6a551e822aacac22ff6d693c60fde583cd314c448308986")
