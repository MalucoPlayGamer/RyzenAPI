-- Lua provided by RyzenAPI
-- Game: AppID 978180

-- MAIN APPLICATION
addappid(978180)

-- MAIN APP DEPOTS / PACKAGES
addappid(978181, 1, "01e52ddabcf80a35fbf40a658109b3dfa5b1e32204ca1fc1c00c26d239d5ddce")

