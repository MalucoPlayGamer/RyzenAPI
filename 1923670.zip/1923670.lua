-- Lua provided by SkyAPI 
-- Game: Venture Towns
addappid(1923670)
addappid(1923671, 1, "6b1ea2468887a5ddb2d297887d2c5dc5f5073b75d7b43d24815d53f824e0d255")
