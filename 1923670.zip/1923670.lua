-- Lua provided by RyzenAPI
-- Game: Venture Towns

-- MAIN APPLICATION
addappid(1923670)
-- Game: addappid(1923670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923671, 1, "6b1ea2468887a5ddb2d297887d2c5dc5f5073b75d7b43d24815d53f824e0d255")
