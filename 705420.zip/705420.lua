-- Lua provided by RyzenAPI
-- Game: AppID 705420

-- MAIN APPLICATION
addappid(705420)
-- Game: addappid(705420)

-- MAIN APP DEPOTS / PACKAGES
addappid(705421, 1, "ecd0799bbbd6e2ae601d9a24ebf97ca38749e136e4e582fc29a3f82afe70deb2")
