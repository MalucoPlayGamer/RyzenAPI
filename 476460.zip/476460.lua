-- Lua provided by RyzenAPI
-- Game: Picross Touch

-- MAIN APPLICATION
addappid(476460)

-- MAIN APP DEPOTS / PACKAGES
addappid(476461, 1, "5a18a58500fc7875814c058d3665b5ac19d4c1561bdad3725351a8edc0c380bd")
addappid(476462, 1, "b4008d2cdcbc1af410dfaf6b6c2f092cdb9df0d8515f96953cb564edeb67dfa6")
addappid(476463, 1, "1e35a89ed3c3b597a7b3089817ba3bcce6ad53269cc9fd8db86a9171e438d0fc")

