-- Lua provided by RyzenAPI
-- Game: addappid(1467240)

-- MAIN APPLICATION
addappid(1467240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467241, 1, "06e8a63d1be6cd69a48060f5fbb726df3de8c6353bdbc03dbe60dea8b1ebc16b")
