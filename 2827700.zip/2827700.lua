-- Lua provided by RyzenAPI
-- Game: Nocturnal - Artbook

-- MAIN APPLICATION
addappid(2827700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827700,0,"6c4c9cd7756e0001c2e84168bd39c91dc4fbb2c6519cb5b318c1aa3a4817e13a")
