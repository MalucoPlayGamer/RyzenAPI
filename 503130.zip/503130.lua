-- Lua provided by RyzenAPI
-- Game: Red is Dead

-- MAIN APPLICATION
addappid(503130)

-- MAIN APP DEPOTS / PACKAGES
addappid(503131, 1, "bf8c204673692e4271a2ef291d24eb7049bf787b3c3a308d3b3e162c135784d4")

