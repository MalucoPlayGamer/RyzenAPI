-- Lua provided by RyzenAPI
-- Game: 1229000

-- MAIN APPLICATION
addappid(1229000)
-- Game: addappid(1229000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229001, 1, "fb3ad2b94dab5fbca0c4138ddc7f7c531039ad5960887c80f64810b3f1d9cf80")
