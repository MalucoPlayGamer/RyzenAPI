-- Lua provided by RyzenAPI
-- Game: 魔女黏糊笔记

-- MAIN APPLICATION
addappid(3265880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265881, 1, "5442d183f1b414a3db233b65eb81db39f211b0c98d6afe14f4af1e5c95acdde2")
