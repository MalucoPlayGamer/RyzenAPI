-- Lua provided by RyzenAPI
-- Game: AppID 1177820

-- MAIN APPLICATION
addappid(1177820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177821, 1, "35061ad61f9c9109c8e77e1ca4bb92ec75e0573f7dfc989a8b8c3171cc8170ef")
addappid(1177822, 1, "53eff87530e946833c7ae5c6ebf7dcc3fd0d2ea68e55b122f876ef7e8b5443cc")

