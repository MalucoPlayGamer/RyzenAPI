-- Lua provided by RyzenAPI
-- Game: Mushroom Jump! Miracle

-- MAIN APPLICATION
addappid(3300580)
-- Game: addappid(3300580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300581, 1, "dcf26b53a1f2fcf141d73d62b01dba0fdb9872c33f62535cc5bb12c9596ca876")
