-- Lua provided by RyzenAPI
-- Game: addappid(2508610)

-- MAIN APPLICATION
addappid(2508610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508611, 1, "1d7297744677ccbf7b61e6e872acbcbf623dd3858c396dcbef7b24bcb34ee0f1")
