-- Lua provided by RyzenAPI 
-- Game: Anzeigen Simulator
addappid(2884210)
addappid(2884211, 1, "0434fa438dd0097fcba5abe5a2dd245d172fa40eae5720f1e597a519faa291e2")
