-- Lua provided by RyzenAPI
-- Game: 2884210

-- MAIN APPLICATION
addappid(2884210)
-- Game: addappid(2884210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884211, 1, "0434fa438dd0097fcba5abe5a2dd245d172fa40eae5720f1e597a519faa291e2")
