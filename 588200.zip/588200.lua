-- Lua provided by RyzenAPI
-- Game: addappid(588200)

-- MAIN APPLICATION
addappid(588200)

-- MAIN APP DEPOTS / PACKAGES
addappid(588202,0,"d127026c6b324d653079ceafc8a884d485faccbdbdff82d60f383371b8edb2e9")
