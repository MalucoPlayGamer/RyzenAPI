-- Lua provided by RyzenAPI
-- Game: Game: AppID 795790

-- MAIN APPLICATION
addappid(795790)
-- Game: addappid(795790)

-- MAIN APP DEPOTS / PACKAGES
addappid(795791, 1, "c218dab07190f089795cbad3fdf65c22f45ebb3d39c4c94714a0ced7b7845f92")
addappid(795792, 1, "0cd17c9aa7c2a9831de72a8655d2c75686e3dfaea46d28a6ea65e90b8badf30e")
addappid(795793, 1, "71005194de70000716805c20608dfd287858dad2ca93886e9a942154283e8e6d")
