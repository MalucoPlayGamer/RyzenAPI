-- Lua provided by SkyAPI 
-- Game: AppID 526760
addappid(526760)
addappid(526761, 1, "5ff5fbb4017f26a450506090a40386f01670915b53882165b976b41f1a571996")
