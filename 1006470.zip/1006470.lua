-- Lua provided by RyzenAPI
-- Game: The Legacy of Music

-- MAIN APPLICATION
addappid(1006470)
-- Game: addappid(1006470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006471, 1, "7d2503dacb18c782809d318e3aaae26d7896b8d5216eb32124e4068954e2b059")
