-- Lua provided by RyzenAPI
-- Game: The Legacy of Music

-- MAIN APPLICATION
addappid(1006470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1006471, 1, "7d2503dacb18c782809d318e3aaae26d7896b8d5216eb32124e4068954e2b059")
