-- Lua provided by RyzenAPI
-- Game: 1246710

-- MAIN APPLICATION
addappid(1246710)
-- Game: addappid(1246710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246711, 1, "dd28976c50fdfd5fa45ff002fccd88cda7c0f2af60678c3c07e32520ed68bf87")
