-- Lua provided by RyzenAPI
-- Game: BDSM: Big Drunk Satanic Massacre Demo

-- MAIN APPLICATION
addappid(1209860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209861, 1, "841828297d492f6901c0e2bc3e8d95012e6ec06b61960c0a5885888574045877")
