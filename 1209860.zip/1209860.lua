-- Lua provided by RyzenAPI 
-- Game: AppID 1209860
addappid(1209860)
addappid(1209861, 1, "841828297d492f6901c0e2bc3e8d95012e6ec06b61960c0a5885888574045877")
