-- Lua provided by RyzenAPI
-- Game: The Most Lecherous

-- MAIN APPLICATION
addappid(2351610)
-- Game: addappid(2351610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351611, 1, "af24994edb23da6278253e71a5a0f552da0c43071130de7b0c021e73533db43a")
