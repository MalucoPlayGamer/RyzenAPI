-- Lua provided by SkyAPI 
-- Game: The Most Lecherous
addappid(2351610)
addappid(2351611, 1, "af24994edb23da6278253e71a5a0f552da0c43071130de7b0c021e73533db43a")
