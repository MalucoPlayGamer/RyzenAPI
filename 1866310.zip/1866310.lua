-- Lua provided by RyzenAPI
-- Game: addappid(1866310)

-- MAIN APPLICATION
addappid(1866310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866311, 1, "f35c5a1634a79e09e285e9f817f2c5308bf179470ece1dfe92dd302b8c76d6a2")
