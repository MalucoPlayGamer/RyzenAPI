-- Lua provided by SkyAPI 
-- Game: Click Quest 3D 2: Plus
addappid(1866310)
addappid(1866311, 1, "f35c5a1634a79e09e285e9f817f2c5308bf179470ece1dfe92dd302b8c76d6a2")
