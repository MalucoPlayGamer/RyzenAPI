-- Lua provided by RyzenAPI
-- Game: Oscura: Lost Light

-- MAIN APPLICATION
addappid(320520)
addappid(320521)
addappid(320523)

-- MAIN APP DEPOTS / PACKAGES
addappid(320522,0,"4d4ae9b1adcf9ec770cd0660a8c8b80f5310b101df4c23c39a373c6e5c7c3560")

