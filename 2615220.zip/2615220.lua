-- Lua provided by SkyAPI 
-- Game: AppID 2615220
addappid(2615220)
addappid(2615221, 1, "00731fcf3c8f217401d00b87782c4f9f52fc946a0707473d35a0d012dd896058")
