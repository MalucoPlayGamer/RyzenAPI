-- Lua provided by RyzenAPI
-- Game: TRANSFORMERS: Galactic Trials

-- MAIN APPLICATION
addappid(2324210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324211, 1, "c0bed8734f96ce4bcfd1328eb7a2308237cd452f4e864cf0e951d5756b29279a")
