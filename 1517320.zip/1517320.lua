-- Lua provided by RyzenAPI
-- Game: 1000 Shards

-- MAIN APPLICATION
addappid(1517320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517321, 1, "bc99f08e014a3f8f9ee541864b4dcae18f6790ba665caa450e36cd5ed4a84981")
