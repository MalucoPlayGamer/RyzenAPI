-- 4051900's Lua and Manifest Created by Hubcap Manifest
-- Fish to Cats: Catch & Feed
-- Created: July 23, 2026 at 02:37:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4051900) -- Fish to Cats: Catch & Feed
addtoken(4051900, "14339734064624783654")
-- MAIN APP DEPOTS
addappid(4051901, 1, "f5badd1b76e10fe35ffdaf307048de57d454bd11fb2e053c06f83cc5a3af9955") -- Depot 4051901
setManifestid(4051901, "7473973177767191164", 276934047)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4650510) -- Fish to Cats Supporter Pack