-- Lua provided by RyzenAPI
-- Game: 867490

-- MAIN APPLICATION
addappid(867490)
-- Game: addappid(867490)

-- MAIN APP DEPOTS / PACKAGES
addappid(867491, 1, "fa2c512a9e1326d63ceb51ad3b45206d79edd2ef55daaa6f854220b545e6485b")
