-- Lua provided by RyzenAPI
-- Game: Game: AppID 2159950

-- MAIN APPLICATION
addappid(2159950)
-- Game: addappid(2159950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159951, 1, "26324df69d153483ef8d126942f70e55ea4d5e0e5e683f0387ffa46417048ca2")
