-- Lua provided by RyzenAPI
-- Game: Cold Blooded

-- MAIN APPLICATION
addappid(3089570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089571, 1, "a928aca9ebb8f3aa3df99a7d4e0f75aa90617b2c58cd6e5e0c5cd7c1424cc4bd")

