-- Lua provided by RyzenAPI
-- Game: VR GAME-Brick of War

-- MAIN APPLICATION
addappid(832530)

-- MAIN APP DEPOTS / PACKAGES
addappid(832531,0,"aed521e50417d146431cefc918f052fc4e31d5a9f10785aaa4cf2872437670e5")

