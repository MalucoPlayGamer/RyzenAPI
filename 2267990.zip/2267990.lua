-- Lua provided by RyzenAPI
-- Game: Simulator Z

-- MAIN APPLICATION
addappid(2267990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267991, 1, "8eecec6aadce343843a9deafc8d8a856054acf6342c4b8b77dd5300d3a731676")

