-- Lua provided by RyzenAPI
-- Game: WOLF IN THE CITY Demo

-- MAIN APPLICATION
addappid(2629510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629511, 1, "03c0eb247d96e5ba6b5fb943fd9eebf0bd04ca3732c88c3e392a0811691ce388")

