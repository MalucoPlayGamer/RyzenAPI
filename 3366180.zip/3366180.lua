-- Lua provided by RyzenAPI
-- Game: Rogue Loops Demo

-- MAIN APPLICATION
addappid(3366180)
-- Game: addappid(3366180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3366181, 1, "cb4681a981cb92775ea8e411320ff88d3d5f0f3a47237703086735667f6aa0f6")
