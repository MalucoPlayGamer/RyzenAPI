-- Lua provided by RyzenAPI
-- Game: 291450

-- MAIN APPLICATION
addappid(291450)
addappid(314400)
-- Game: addappid(291450)

-- MAIN APP DEPOTS / PACKAGES
addappid(291451, 1, "290cf2f02a189eafd8188cf9fe37a14f113efac99746477ec0f1b92c95be9992")
