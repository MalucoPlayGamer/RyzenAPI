-- Lua provided by RyzenAPI
-- Game: Facehand Demo

-- MAIN APPLICATION
addappid(2625610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625611, 1, "8b9391e7b9f14f3fdd1bb56b4928d8e4ac5d8f963d69df528dbfc958cd197484")

