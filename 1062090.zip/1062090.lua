-- Lua provided by RyzenAPI
-- Game: Timberborn

-- MAIN APPLICATION
addappid(1062090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1062091, 1, "e6291a6d488f1366425014f5742483a513e8771437644a531111ffc9e9674be4")
addappid(1062092, 1, "07decf196b134aeb2362a7dcdf1ebce51004f759e44961e838189f59f9943267")
