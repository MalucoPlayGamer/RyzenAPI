-- Lua provided by RyzenAPI
-- Game: 1667730

-- MAIN APPLICATION
addappid(1667730)
-- Game: addappid(1667730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667731, 1, "97620070d876158d7058d9843c7ea152ee5e120d2cf5c44ffa04b1fcbeaea48f")
