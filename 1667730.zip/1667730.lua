-- Lua provided by RyzenAPI
-- Game: Forgotten Journey

-- MAIN APPLICATION
addappid(1667730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667731, 1, "97620070d876158d7058d9843c7ea152ee5e120d2cf5c44ffa04b1fcbeaea48f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
