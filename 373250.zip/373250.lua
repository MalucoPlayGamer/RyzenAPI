-- Lua provided by RyzenAPI
-- Game: 373250

-- MAIN APPLICATION
addappid(371192)
addappid(373250)
addappid(373251)
addappid(373252)

-- MAIN APP DEPOTS / PACKAGES
addappid(371191,0,"eb1bdcc5b2239581d3f7adf29fabbcaaf7e1bf98187b871d1dae03d4bddba0fd")

