-- Lua provided by RyzenAPI
-- Game: AppID 1093850

-- MAIN APPLICATION
addappid(1093850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1093851, 1, "7aaf3f405d66dbc589141d7b2e9c0b8970c0a691ffedad219a06405531ca514b")

