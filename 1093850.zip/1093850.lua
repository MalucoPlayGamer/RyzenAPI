-- Lua provided by RyzenAPI
-- Game: addappid(1093850)

-- MAIN APPLICATION
addappid(1093850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093851, 1, "7aaf3f405d66dbc589141d7b2e9c0b8970c0a691ffedad219a06405531ca514b")
