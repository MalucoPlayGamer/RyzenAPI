-- Lua provided by RyzenAPI
-- Game: The Desolate Hope

-- MAIN APPLICATION
addappid(298180)

-- MAIN APP DEPOTS / PACKAGES
addappid(298181, 1, "58faa6b150680bda9617df55b64dc02c78eb17d3067dd97a7521a26659732dcf")

