-- Lua provided by SkyAPI 
-- Game: Pastel Putter
addappid(2147340)
addappid(2147341, 1, "04e401981df6a4ae18c33b3383f1b1ff5d5d24b3c8a2cfe09818723734208fdb")
