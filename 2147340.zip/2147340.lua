-- Lua provided by RyzenAPI
-- Game: 2147340

-- MAIN APPLICATION
addappid(2147340)
-- Game: addappid(2147340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147341, 1, "04e401981df6a4ae18c33b3383f1b1ff5d5d24b3c8a2cfe09818723734208fdb")
