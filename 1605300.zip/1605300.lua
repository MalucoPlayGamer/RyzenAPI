-- Lua provided by RyzenAPI
-- Game: setManifestid(1605303,"7102636043304734134")

-- MAIN APPLICATION
addappid(1605300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605303,0,"0682baa836465fd2bea0a0c1e2c934cb79c1ed9bfce1e611124fee72506dc08a")

