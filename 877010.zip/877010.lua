-- Lua provided by SkyAPI 
-- Game: Beyond Contact
addappid(877010)
addappid(877011, 1, "03f4a29edec22f126ddc3f53235cddba3986110a7b94ef043e7fddd5f7fe6c9e")
