-- Lua provided by RyzenAPI
-- Game: Beyond Contact

-- MAIN APPLICATION
addappid(877010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(877011, 1, "03f4a29edec22f126ddc3f53235cddba3986110a7b94ef043e7fddd5f7fe6c9e")

