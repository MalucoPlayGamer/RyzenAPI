-- Lua provided by RyzenAPI
-- Game: addappid(877010)

-- MAIN APPLICATION
addappid(877010)

-- MAIN APP DEPOTS / PACKAGES
addappid(877011, 1, "03f4a29edec22f126ddc3f53235cddba3986110a7b94ef043e7fddd5f7fe6c9e")
