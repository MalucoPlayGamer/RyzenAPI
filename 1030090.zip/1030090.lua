-- Lua provided by RyzenAPI
-- Game: Legend of GBC Tycoon GBC土豪金传说

-- MAIN APPLICATION
addappid(1030090)
-- Game: addappid(1030090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030091, 1, "c6df11baf4f464ae31873f13fc030ae89b9a857f615938ca5defe2c722e50545")
addappid(1030093, 1, "1bd32b6cab1a8328b93d55d2de92d858d6a9b9e0388639ea84bbcb60ce6c1d6d")
