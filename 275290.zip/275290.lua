-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Operation Star

-- MAIN APPLICATION
addappid(275290)
addappid(296450)
addappid(305360)
addappid(313280)
addappid(313281)
addappid(326390)
addappid(326391)
addappid(336850)
addappid(336851)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(275291, 1, "fd1fbff8ecba9e1055e084e4973aaf3151f02d6caaadeacb5aa50942b7ddeb81")

