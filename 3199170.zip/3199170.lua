-- Lua provided by RyzenAPI
-- Game: Blood Strike

-- MAIN APPLICATION
addappid(3199170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199171, 1, "8b52af6f371454a54fb4e3d5c39efa5455f8cb76240ee5c2733fc96633a7186c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
