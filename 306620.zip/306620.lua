-- Lua provided by RyzenAPI
-- Game: Game: Frontline : Road to Moscow

-- MAIN APPLICATION
addappid(306620)
-- Game: addappid(306620)

-- MAIN APP DEPOTS / PACKAGES
addappid(306621, 1, "632b743febff7802846d3f27e2b3a6d44566d832b72f886c32de1ed555fc0c6e")
