-- Lua provided by RyzenAPI 
-- Game: Frontline : Road to Moscow
addappid(306620)
addappid(306621, 1, "632b743febff7802846d3f27e2b3a6d44566d832b72f886c32de1ed555fc0c6e")
