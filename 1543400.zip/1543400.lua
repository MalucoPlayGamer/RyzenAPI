-- Lua provided by RyzenAPI
-- Game: AppID 1543400

-- MAIN APPLICATION
addappid(1543400)
-- Game: addappid(1543400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543401, 1, "7b673a37426b48f7972238d193c65c136c357ba8ccbbef3001168dcd855c9f93")
