-- Lua provided by RyzenAPI
-- Game: addappid(1685570)

-- MAIN APPLICATION
addappid(1685570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685571, 1, "d7b791c9a884d91c4d7d6cff273a0c4afaea32597608dc661b2754ec5e923225")
