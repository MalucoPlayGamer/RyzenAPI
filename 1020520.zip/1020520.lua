-- Lua provided by RyzenAPI
-- Game: Hellink

-- MAIN APPLICATION
addappid(1020520)
-- Game: addappid(1020520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020522,0,"042d1072c84127fcb6bdb94e006d3210d6a63ca07109f8c07a28a703ddf6f6ce")
addappid(1020523,0,"891cd40cbe4abbeb28da9b112f6709553e4066c51dcdbc484a7a146aaf5971b6")
addappid(1020524,0,"b1f04f57f8804612d09f4fddbf03519e3ea868cd23463c9d2bf6298e7df2df53")
