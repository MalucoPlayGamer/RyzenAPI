-- Lua provided by RyzenAPI
-- Game: Bitcoin VS Brain - Soundtrack

-- MAIN APPLICATION
addappid(817730)

-- MAIN APP DEPOTS / PACKAGES
addappid(817730,0,"a59abb27876510d2e2faa3bda6eb176a6303863de1551943dd5ba92745ff25da")
