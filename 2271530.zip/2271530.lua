-- Lua provided by RyzenAPI
-- Game: AppID 2271530

-- MAIN APPLICATION
addappid(2271530)
-- Game: addappid(2271530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271531, 1, "4c56386ff74bc9da7000799d1dab22b9614f3e53f0f1998a81832d37bde99e86")
