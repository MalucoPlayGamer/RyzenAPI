-- Lua provided by RyzenAPI
-- Game: Furry Cyberfucker II

-- MAIN APPLICATION
addappid(2004490)
-- Game: addappid(2004490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004491, 1, "6e59547cea6d53839a0639b144f693a1b17b64a2621a9fa86d73f5749440a519")
