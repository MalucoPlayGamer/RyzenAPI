-- Lua provided by RyzenAPI
-- Game: SteamWorld Build Demo

-- MAIN APPLICATION
addappid(2239090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239091, 1, "5f36c55d496c3da411e0cfdcba46c3fcf8f1e9feac3a85a77e55f8012182c29e")

