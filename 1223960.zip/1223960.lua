-- Lua provided by RyzenAPI
-- Game: Dark Devotion Soundtrack

-- MAIN APPLICATION
addappid(1223960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223961, 1, "cab5c169e58df6e5543df580a52b34a77b27faaa9c1c8ec854134daa4566ad9a")
addappid(1223962, 1, "9bcb897a473ea0a05395051a61b144ade90456f50fff6c2a59db22f2e9bc3dec")
