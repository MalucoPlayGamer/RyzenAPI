-- Lua provided by RyzenAPI
-- Game: Bambino Rally 3

-- MAIN APPLICATION
addappid(469550)
-- Game: addappid(469550)

-- MAIN APP DEPOTS / PACKAGES
addappid(469551, 1, "6bda6afc4a6f1ff01014031eedefd0ee2519ff796465c7cf4350d7fe1dd1c962")
