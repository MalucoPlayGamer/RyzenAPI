-- Lua provided by RyzenAPI
-- Game: Game: Start Heart Thief | 出发吧！偷心盗贼 | 出撃 ルビー | 出擊 偷心盜賊

-- MAIN APPLICATION
addappid(1283110)
-- Game: addappid(1283110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283111, 1, "c605c12a62707220a8ae18e233a52cffa551da610916b7180b2444f259f831fd")
