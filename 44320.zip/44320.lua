-- Lua provided by RyzenAPI
-- Game: DiRT 3

-- MAIN APPLICATION
addappid(44320)

-- MAIN APP DEPOTS / PACKAGES
addappid(44321, 1, "ae346ce5f4c23a8542157bc7626c9823db6728bc33f5ac2d6a051c0179c01e1d")

