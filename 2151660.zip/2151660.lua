-- Lua provided by RyzenAPI
-- Game: The Waterflame Brothers

-- MAIN APPLICATION
addappid(2151660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2151661, 1, "bfd35ceb446c054457223f9892de13b4c731d100bc5d4b97b8ad21afeebfb9c4")

