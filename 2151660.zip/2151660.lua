-- Lua provided by RyzenAPI
-- Game: addappid(2151660)

-- MAIN APPLICATION
addappid(2151660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151661, 1, "bfd35ceb446c054457223f9892de13b4c731d100bc5d4b97b8ad21afeebfb9c4")
