-- Lua provided by RyzenAPI
-- Game: 3191050

-- MAIN APPLICATION
addappid(3191050)
-- Game: addappid(3191050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191051, 1, "e97a6611a86761cb9413ca9d1e9acc72aa8505f58000f6082f159bae7b92b1fc")
