-- Lua provided by RyzenAPI
-- Game: Game: Number 217721

-- MAIN APPLICATION
addappid(2156960)
-- Game: addappid(2156960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156961, 1, "67c2a0cffd2b9cc6405495c22ef881e97dc778c8a5c8af86bc7aa4f82138d4c5")
