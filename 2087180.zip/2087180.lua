-- Lua provided by RyzenAPI
-- Game: 2087180

-- MAIN APPLICATION
addappid(2087180)
-- Game: addappid(2087180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087181, 1, "4d0e34fab595a537f67b7b92cc481d44c24cae1d72f15d39d286b5103d310f3b")
