-- Lua provided by SkyAPI 
-- Game: The 4th Wall
addappid(3383190)
addappid(3383191, 1, "0f2475988ffdf29bccfc2386c08a887c1791cf4cc3543abe9e46e01aa4b1c5c3")
