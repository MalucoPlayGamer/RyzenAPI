-- Lua provided by RyzenAPI
-- Game: 1759460

-- MAIN APPLICATION
addappid(1759460)
-- Game: addappid(1759460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759461, 1, "6c229a6e7456aba1c13acf28701cebdaa271857bb0bcb8b481c96cfdfe842803")
