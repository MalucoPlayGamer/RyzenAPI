-- Lua provided by SkyAPI 
-- Game: The House Where They Dwell
addappid(1759460)
addappid(1759461, 1, "6c229a6e7456aba1c13acf28701cebdaa271857bb0bcb8b481c96cfdfe842803")
