-- Lua provided by RyzenAPI
-- Game: Insurgence - Chains of Renegade

-- MAIN APPLICATION
addappid(912930)
-- Game: addappid(912930)

-- MAIN APP DEPOTS / PACKAGES
addappid(912931, 1, "ea1810476b2526cadabb35c37da586e524aad0452893830feccf42fa82a84ae1")
