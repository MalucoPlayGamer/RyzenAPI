-- Lua provided by RyzenAPI
-- Game: AppID 564750

-- MAIN APPLICATION
addappid(564750)

-- MAIN APP DEPOTS / PACKAGES
addappid(564751, 1, "f94d3d29787dbaa7f12c722f4dd3e25282a96bfd7b3b518847e824ba91c23c7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1157950)
