-- Lua provided by RyzenAPI
-- Game: 564750

-- MAIN APPLICATION
addappid(564750)
-- Game: addappid(564750)

-- MAIN APP DEPOTS / PACKAGES
addappid(564751, 1, "f94d3d29787dbaa7f12c722f4dd3e25282a96bfd7b3b518847e824ba91c23c7d")
