-- Lua provided by RyzenAPI
-- Game: Call me Hero Demo

-- MAIN APPLICATION
addappid(3044470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044471, 1, "a7b7014eff3f577281086aef3e5a989f65a57fa73dc6fb7a8378ded172c77b2a")

