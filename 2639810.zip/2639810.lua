-- Lua provided by RyzenAPI
-- Game: Rumble Club

-- MAIN APPLICATION
addappid(2639810)
addappid(2923410)
addappid(2925900)
addappid(2925910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639811,0,"b237cb5325ee3becd1a967ad1f0aff1ec20876a5269be45d2c4ecf067eb3cfde")
addappid(2639812,0,"c32e288c1f23ebe7c9b9558f3e3bad9c534dab518005b7607afe1b1f438a096f")

