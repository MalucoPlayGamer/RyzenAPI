-- Lua provided by RyzenAPI
-- Game: Earthfall Soundtrack

-- MAIN APPLICATION
addappid(578340)

-- MAIN APP DEPOTS / PACKAGES
addappid(578341, 1, "f6f16cfea92c1ba9f375b5a5812332c5c2a31000956e17079663976668263480")
