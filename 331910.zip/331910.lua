-- Lua provided by SkyAPI 
-- Game: AppID 331910
addappid(331910)
addappid(331911, 1, "a41be4c88eabe80989f2e8b736cda72ce53874234b57537adb51499088ccca78")
addappid(331912, 1, "8048f970a0b97a5ed3cbbb40558d2af4edf39de8dce5b71a6352f3c701c76997")
