-- Lua provided by RyzenAPI
-- Game: SOS

-- MAIN APPLICATION
addappid(619080)
addappid(784710)
addappid(784730)
addappid(784750)
addappid(784760)
addappid(784770)
addappid(784780)
addappid(784790)
addappid(784800)
addappid(784810)
addappid(784820)
addappid(811650)
addappid(811660)
addappid(811670)
addappid(812320)

-- MAIN APP DEPOTS / PACKAGES
addappid(619081,0,"5c017cd997dc54ab85fa3e0425c9fed11f08ded293f1ad43f8f932b68fb0a0e5")

