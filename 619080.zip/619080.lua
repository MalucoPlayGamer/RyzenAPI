-- Lua provided by RyzenAPI
-- Game: SOS

-- MAIN APPLICATION
addappid(619080)
addappid(784710)
addappid(784730)
addappid(784750)
addappid(784760)
addappid(784770)
addappid(784780)
addappid(784790)
addappid(784800)
addappid(784810)
addappid(784820)
addappid(811650)
addappid(811660)
addappid(811670)
addappid(812320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(619081,0,"5c017cd997dc54ab85fa3e0425c9fed11f08ded293f1ad43f8f932b68fb0a0e5")

