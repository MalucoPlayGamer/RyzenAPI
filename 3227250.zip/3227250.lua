-- Lua provided by RyzenAPI
-- Game: 生嚿叉燒好過生你 Demo

-- MAIN APPLICATION
addappid(3227250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227251, 1, "252a6008c812fdc60904be79973b459d9bde761254e04d6db6c7442f65553ac0")

