-- Lua provided by RyzenAPI
-- Game: Bobbi Adventure

-- MAIN APPLICATION
addappid(1970560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970561, 1, "928f993bdc62e7549849dad19299b51db78915f871e962cc074365d468acd43e")
