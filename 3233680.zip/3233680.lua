-- Lua provided by RyzenAPI
-- Game: Lightracer: For Judge Demo

-- MAIN APPLICATION
addappid(3233680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233681, 1, "4eb06b0a17c38cbaa2e85c92bb67c5512df81d78c42d3daae6d56ec17b5a87f9")

