-- Lua provided by RyzenAPI
-- Game: Game: AppID 1723130

-- MAIN APPLICATION
addappid(1723130)
-- Game: addappid(1723130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723131, 1, "2bee75c264ddf902afe98887a50664f2d0cbab749c0c814fbbe551015332666c")
addappid(1723132, 1, "a9626b45e4e96ccd14798c6a9ba82d78a2532ba94f10cce23a4372e7f78e874b")
