-- Lua provided by RyzenAPI
-- Game: Hidden SciFi City Top-Down 3D

-- MAIN APPLICATION
addappid(2506870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506871, 1, "d0eefcf83d922692c9169d18cc8fafd6a42f520e24a34e6138fff83aba6777b6")

