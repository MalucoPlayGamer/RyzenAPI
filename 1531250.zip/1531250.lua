-- Lua provided by RyzenAPI
-- Game: Defend the Rook

-- MAIN APPLICATION
addappid(1531250)
addappid(1783640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531251, 1, "c1d8eebe216478396c59da4805e18176193dc2f5c2166727030a7a7733a4183c")

