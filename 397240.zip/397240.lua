-- Lua provided by RyzenAPI
-- Game: Troubles Land

-- MAIN APPLICATION
addappid(397240)

-- MAIN APP DEPOTS / PACKAGES
addappid(397241, 1, "e8001f3f879134603c761d9dc7d5acb8f23173c829ced8e6c8ad2ab5a019282d")

