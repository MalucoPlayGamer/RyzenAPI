-- Lua provided by RyzenAPI
-- Game: DOOM + DOOM II

-- MAIN APPLICATION
addappid(2280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281, 1, "59d59862ea40c92ef01e270e60c349de893eee7a55a089cb6ef63b68e8935075")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

