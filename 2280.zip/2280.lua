-- Lua provided by RyzenAPI
-- Game: Game: DOOM + DOOM II

-- MAIN APPLICATION
addappid(2280)
-- Game: addappid(2280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281, 1, "59d59862ea40c92ef01e270e60c349de893eee7a55a089cb6ef63b68e8935075")
