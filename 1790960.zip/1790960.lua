-- Lua provided by RyzenAPI
-- Game: Escape from the Village

-- MAIN APPLICATION
addappid(1790960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790961, 1, "4221c712e529358c096ad5a1628c671a5b4ba03250f94346a65183e637fadca7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
