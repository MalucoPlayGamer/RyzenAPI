-- Lua provided by RyzenAPI
-- Game: addappid(1165100)

-- MAIN APPLICATION
addappid(1165100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165101, 1, "e606e5ea097757a5c501bd730aefe421ed58f257faec71db3d6ef4e4d2c15c52")
addappid(1165104, 1, "7e56a6fcbaec69a81d83af3a3d0ce6b3193170f9718f08f578d70cc9dbc1080b")
