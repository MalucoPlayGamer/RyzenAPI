-- Lua provided by RyzenAPI
-- Game: Street Fighting Simulator

-- MAIN APPLICATION
addappid(2835060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835061, 1, "b48283cd996f55c670b20a342606b80370ee870a9a90e81b1bf988b9cc561b5e")

