-- Lua provided by RyzenAPI
-- Game: AppID 1455840

-- MAIN APPLICATION
addappid(1455840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455841, 1, "3e4b34c8fbc5bd37cbb53c5620a4a9dbab88e85274ffda1494d2a0ffa246d3fa")
addappid(1455842, 1, "33aa0d0ed605848dcdb9a205b18f4a27f8bed87d81b2d6c316b378a8c0ea223e")

