-- Lua provided by RyzenAPI
-- Game: BEAT ARENA

-- MAIN APPLICATION
addappid(1647200)
-- Game: addappid(1647200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647201, 1, "02dec23cbf16a1ebd9bad2e0d8bc4853a5b12100b54036eaff2878ed23809e82")
