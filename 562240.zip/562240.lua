-- Lua provided by RyzenAPI
-- Game: The Spirit Underneath

-- MAIN APPLICATION
addappid(562240)

-- MAIN APP DEPOTS / PACKAGES
addappid(562241, 1, "cbdf55b4dccaad47d3b75b5753b5ac93d60a77443cf03d7163b731be05a23082")

