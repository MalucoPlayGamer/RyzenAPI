-- Lua provided by RyzenAPI
-- Game: The Spirit Underneath

-- MAIN APPLICATION
addappid(562240)

-- MAIN APP DEPOTS / PACKAGES
addappid(562241, 1, "cbdf55b4dccaad47d3b75b5753b5ac93d60a77443cf03d7163b731be05a23082")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
