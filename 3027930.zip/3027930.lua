-- Lua provided by RyzenAPI
-- Game: Karate Survivor

-- MAIN APPLICATION
addappid(3027930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027931, 1, "8e0e6b6161e8fa9b95807af1d66e3d1a4c5b35968ce2aa06d664329931df0cef")
