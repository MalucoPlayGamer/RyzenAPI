-- Lua provided by RyzenAPI
-- Game: Game: AppID 709920

-- MAIN APPLICATION
addappid(709920)
-- Game: addappid(709920)

-- MAIN APP DEPOTS / PACKAGES
addappid(709921, 1, "18cd35dcf808cb25c40f3e1e2b894e87ed236cffef8283753e7f3e8e30f694b4")
