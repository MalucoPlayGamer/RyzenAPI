-- Lua provided by RyzenAPI
-- Game: 1338840

-- MAIN APPLICATION
addappid(1338840)
-- Game: addappid(1338840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338841, 1, "4b208e16d6e6b9b4ff78077a5e5c2af17ba3ac4610608b908559886e6759cbaf")
