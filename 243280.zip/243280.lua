-- Lua provided by RyzenAPI
-- Game: Game: Poöf

-- MAIN APPLICATION
addappid(243280)
addappid(273680)
-- Game: addappid(243280)

-- MAIN APP DEPOTS / PACKAGES
addappid(243281, 1, "7c277d10c9f08e2c33a80dfd8064eb0b3be6898c7de2a7133ec1248721f6fa55")
