-- Lua provided by RyzenAPI
-- Game: 274170

-- MAIN APPLICATION
addappid(274170)
-- Game: addappid(274170)

-- MAIN APP DEPOTS / PACKAGES
addappid(274172,0,"f948ce6d03348d1d575fafacccfca66afa47bd65418e34665d0b21ff85b5f00d")
addappid(274173,0,"679aae395a3a5daa27d209ba716f1cedc31b9547c7220e45e83b5836659c516e")
addappid(274174,0,"d1457cd83d22f30c48dfd29c06349b6485c37bea55a586477ae24e4586aba25f")
addappid(274175,0,"466a79aa40bcdf719c80346e55dd7ed30cd4245fa47f82d5c5394affe5adc0ba")
