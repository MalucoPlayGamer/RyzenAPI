-- Lua provided by RyzenAPI 
-- Game: AppID 449830
addappid(449830)
addappid(449831, 1, "2dc539f48c05bf8996f5ea0579285aa30627a457f67846c894cb02fd1ae664ee")
addappid(449832, 1, "40995c9c212381f10d8e13315119921d763b66489c6799daffcfbd1d0922b6cf")
addappid(489500)
