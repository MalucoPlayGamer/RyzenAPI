-- Lua provided by SkyAPI 
-- Game: Plebby Quest: The Crusades OST
addappid(1266770)
addappid(1266771, 1, "835c93eb4f054f96bd9b4d2051309c4a3d24f74348443ed5ab0558f57144e1ef")
addappid(1266772, 1, "e805768abbd2071d2275b9aebe06d690a4049f0cc055b37f259dea8e972dcc12")
