-- Lua provided by RyzenAPI
-- Game: addappid(746970)

-- MAIN APPLICATION
addappid(746970)

-- MAIN APP DEPOTS / PACKAGES
addappid(746971, 1, "02ffcb9b51c420228a75a089335b41934f6844f4ba966e660e3ea308dfeeaa44")
