-- 4217690's Lua and Manifest Created by Hubcap Manifest
-- Uncanny Tales: The Watcher
-- Created: August 05, 2026 at 13:39:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4217690) -- Uncanny Tales: The Watcher
-- MAIN APP DEPOTS
addappid(4217691, 1, "695926d23f6d42dacff53733b4f721621f562445dd6f188587fb296f99f49ca0") -- Depot 4217691
setManifestid(4217691, "8559593050285137952", 6195653110)