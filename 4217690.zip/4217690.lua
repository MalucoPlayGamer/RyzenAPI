-- Lua provided by RyzenAPI
-- Game: Uncanny Tales: The Watcher

-- MAIN APPLICATION
addappid(4217690) -- Uncanny Tales: The Watcher

-- MAIN APP DEPOTS / PACKAGES
addappid(4217691, 1, "695926d23f6d42dacff53733b4f721621f562445dd6f188587fb296f99f49ca0") -- Depot 4217691

