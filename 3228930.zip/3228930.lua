-- Lua provided by SkyAPI 
-- Game: Short NTR Stories
addappid(3228930)
addappid(3228931, 1, "4b5f0cfd0495116b4e2f1116f192e508e7d5af50f8714dd8bcea43d3b181c240")
