-- Lua provided by RyzenAPI
-- Game: Hyper Online: Avatar VTuber Studio

-- MAIN APPLICATION
addappid(2828790)
addappid(3718280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2828791, 1, "aebd61c48ce4554964f6a899e4b1e8b4b29dcdcfe5d28cba6e80a1c4186fc550")

