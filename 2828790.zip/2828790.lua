-- Lua provided by RyzenAPI
-- Game: addappid(2828790)

-- MAIN APPLICATION
addappid(2828790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828791, 1, "aebd61c48ce4554964f6a899e4b1e8b4b29dcdcfe5d28cba6e80a1c4186fc550")
