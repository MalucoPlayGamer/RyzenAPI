-- Lua provided by RyzenAPI
-- Game: Game: AppID 2262510

-- MAIN APPLICATION
addappid(2262510)
-- Game: addappid(2262510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262511, 1, "944c58f55d9836427f1b122d174dd51f6e018e55be3da596ed72df44a63b4b30")
addappid(2262512, 1, "192ebfee30a7da93b407e6920b027a9f9bf58c7c4861f61f570c6f1766ace48e")
