-- Lua provided by RyzenAPI
-- Game: AppID 2489370

-- MAIN APPLICATION
addappid(2489370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489371, 1, "07439ce27234ce4b1bee7552beedb48cf7a558c05d3570ccf27f9d4408a4ab2f")
