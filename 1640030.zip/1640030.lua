-- Lua provided by RyzenAPI
-- Game: Adventures With a Girl

-- MAIN APPLICATION
addappid(1640030)
-- Game: addappid(1640030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640031, 1, "2701a7dc3b1e576533eee3db52cf4860f45fbde6cea3600d370689b9924f11da")
