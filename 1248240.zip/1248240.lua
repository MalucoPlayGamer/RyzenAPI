-- Lua provided by RyzenAPI
-- Game: addappid(1248240)

-- MAIN APPLICATION
addappid(1248240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248241, 1, "223215cbce8f42df222f8668407d1c96e8021601dd82c0cc047ab94ae296a6cb")
