-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Digital Deluxe Edition Bonus

-- MAIN APPLICATION
addappid(1634694)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634694,0,"d344e5a5f3ccdadcb90e45a1505e9f3a00232f1b1e8b12c19abea4933bb7beab")

