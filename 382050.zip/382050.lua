-- Lua provided by RyzenAPI
-- Game: AppID 382050

-- MAIN APPLICATION
addappid(382050)

-- MAIN APP DEPOTS / PACKAGES
addappid(382051, 1, "07d5c2b43d299e05f9a9c6040232aa1b3f942d42b73cce0abb2f8834d8085425")
addappid(382053, 1, "56a4b0e568131a789b5523aa011fc64af449c3eae78b0efc882cc08ff665629a")
addappid(382054, 1, "c6ced4f3d554d91cf117434ce5a93c79230737ff7febbc7dbb1e637deb33c731")
addappid(477890, 0, "18b3ad53f15eb131e015a728c6797438c1d3624df52e7d5293b1aebf2e59571e")
addappid(549750, 0, "ccfbd23023a1846baf28789a1c994a609489d08b2f765ba9e73eae6edeb773ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
