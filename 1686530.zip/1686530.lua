-- Lua provided by RyzenAPI 
-- Game: Project: Vaccine A
addappid(1686530)
addappid(1686531, 1, "2bc138c62e145a78d3e403c53022d7c1e449b1375d2c45f0e3fd2f4f450c0e07")
