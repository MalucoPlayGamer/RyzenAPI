-- Lua provided by RyzenAPI
-- Game: Upgradia

-- MAIN APPLICATION
addappid(4774800) -- Upgradia

-- MAIN APP DEPOTS / PACKAGES
addappid(4774801, 1, "fd9092c41e465352d3b3e59bc5baf795516af9413629816a95873a7f035f8e8e") -- Depot 4774801

