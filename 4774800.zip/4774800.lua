-- 4774800's Lua and Manifest Created by Hubcap Manifest
-- Upgradia
-- Created: August 05, 2026 at 13:40:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4774800) -- Upgradia
-- MAIN APP DEPOTS
addappid(4774801, 1, "fd9092c41e465352d3b3e59bc5baf795516af9413629816a95873a7f035f8e8e") -- Depot 4774801
setManifestid(4774801, "8371127795199153461", 1338701097)