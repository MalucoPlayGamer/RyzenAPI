-- Lua provided by RyzenAPI
-- Game: 1672500

-- MAIN APPLICATION
addappid(1672500)
-- Game: addappid(1672500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672501, 1, "9f2f74d11338105456bfb27b568e86d4db1b13ce938fcc6272f334a7d042be53")
