-- Lua provided by RyzenAPI
-- Game: GUNDAM BREAKER 4

-- MAIN APPLICATION
addappid(1672500)
addappid(2884320)
addappid(2884330)
addappid(2884340)
addappid(2884350)
addappid(2884360)
addappid(2884370)
addappid(2884380)
addappid(2884390)
addappid(2884400)
addappid(2884410)
addappid(2884420)
addappid(2884430)
addappid(2884440)
addappid(2884450)
addappid(2884460)
addappid(3085970)
addappid(3085980)
addappid(3498520)
addappid(3498530)
addappid(3498540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1672501, 1, "9f2f74d11338105456bfb27b568e86d4db1b13ce938fcc6272f334a7d042be53")

