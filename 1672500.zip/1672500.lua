-- Lua provided by SkyAPI 
-- Game: GUNDAM BREAKER 4
addappid(1672500)
addappid(1672501, 1, "9f2f74d11338105456bfb27b568e86d4db1b13ce938fcc6272f334a7d042be53")
