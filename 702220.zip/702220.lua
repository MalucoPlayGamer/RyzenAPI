-- Lua provided by RyzenAPI
-- Game: Touch My Spinner

-- MAIN APPLICATION
addappid(702220)

-- MAIN APP DEPOTS / PACKAGES
addappid(702221,0,"54e4f550779ea3786f4a0a5b503147a2b0055e1c0372903733fdbf35f6ae2431")

