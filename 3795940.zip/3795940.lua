-- Lua provided by RyzenAPI
-- Game: 3795940

-- MAIN APPLICATION
addappid(3795940)
-- Game: addappid(3795940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795941, 1, "697ff8af8a0a0637bb56b2b88f7d6079f0349f77805c86c9ffd7fceedaeda293")
addappid(3795942, 1, "cb643c6579646b4cbc382b981170b057d8bde4d798425cae55ca23ff7bfd38e7")
