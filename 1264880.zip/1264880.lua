-- Lua provided by RyzenAPI
-- Game: Watcher Chronicles

-- MAIN APPLICATION
addappid(1264880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264881, 1, "8b526b5eed5009e98290fb610d5214dce96c367db63ba7c2fcffe1da21cfc1f3")

