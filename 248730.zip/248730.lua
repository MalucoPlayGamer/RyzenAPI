-- Lua provided by RyzenAPI
-- Game: A Walk in the Dark

-- MAIN APPLICATION
addappid(248730)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(248731, 1, "0394f2faf95a99c4390dcc140a22c5eb403a94ce37c0ada0f3ad6cc1bc8c2eaf")

