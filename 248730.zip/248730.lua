-- Lua provided by RyzenAPI
-- Game: A Walk in the Dark

-- MAIN APPLICATION
addappid(248730)

-- MAIN APP DEPOTS / PACKAGES
addappid(248731, 1, "0394f2faf95a99c4390dcc140a22c5eb403a94ce37c0ada0f3ad6cc1bc8c2eaf")

