-- Lua provided by RyzenAPI
-- Game: addappid(1906160)

-- MAIN APPLICATION
addappid(1906160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906161, 1, "cdaab60aae0d1d550d63053e74a8c5e919d81ab5c6a53ad16a10dd7815e74744")
