-- Lua provided by RyzenAPI
-- Game: HYBRIS - Pulse of Ruin

-- MAIN APPLICATION
addappid(778800)

-- MAIN APP DEPOTS / PACKAGES
addappid(778801,0,"7e0cbd4e2c972cbf814649a74677b35a31cf611713453216e033dac1ccab6952")

