-- Lua provided by RyzenAPI
-- Game: Crimson Sword Saga: The Peloran Wars

-- MAIN APPLICATION
addappid(497560)
-- Game: addappid(497560)

-- MAIN APP DEPOTS / PACKAGES
addappid(497569,0,"b43cc7a8fb032711064cf1dac5ed280cde0753abcef6d7017e8a3cee80580d83")
