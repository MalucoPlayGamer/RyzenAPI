-- Lua provided by RyzenAPI
-- Game: Forest Ranger Simulator

-- MAIN APPLICATION
addappid(1185780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185781, 1, "47478b628c2300c2b8d42b61f5f5e73dd2ef4c9f5308ab3be30cfc9af417a736")

