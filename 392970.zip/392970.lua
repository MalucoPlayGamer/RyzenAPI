-- Lua provided by RyzenAPI
-- Game: New York Mysteries: High Voltage

-- MAIN APPLICATION
addappid(392970)

-- MAIN APP DEPOTS / PACKAGES
addappid(392971, 1, "aa599fb4c5cf15f320b16c0954a44bdb55fb0891ecfbd6facc03f9ec89cb5d76")
addappid(392972, 1, "2736f601561ee843f1729445e7b1f5d5789d8842ec65b8af0d367e2ef345a241")
addappid(392973, 1, "5023d46dc1ed4f84cb8bde82adca8e83583e65b2262aae701ec7e381d1993463")
addappid(392974, 1, "bc563ce381a642bd4a1092034521d66f724622968a7c4e93836c7d97fc52efc5")
