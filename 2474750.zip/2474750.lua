-- Lua provided by RyzenAPI
-- Game: addappid(2474750)

-- MAIN APPLICATION
addappid(2474750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474751, 1, "cb97d565f663372feaa425d45ef0119a795dc57358b63746de6441d7b6ee9dea")
