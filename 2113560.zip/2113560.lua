-- Lua provided by SkyAPI 
-- Game: An Architect's Adventure Demo
addappid(2113560)
addappid(2113561, 1, "bf82d447acf4beee18196bdcc215195d918a7895b0573f438bc9363e3916dd5a")
