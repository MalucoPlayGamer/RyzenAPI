-- Lua provided by RyzenAPI
-- Game: An Architect's Adventure Demo

-- MAIN APPLICATION
addappid(2113560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113561, 1, "bf82d447acf4beee18196bdcc215195d918a7895b0573f438bc9363e3916dd5a")
