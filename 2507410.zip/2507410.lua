-- Lua provided by RyzenAPI
-- Game: Black Friday

-- MAIN APPLICATION
addappid(2507410)
-- Game: addappid(2507410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507414,0,"026c68495c83dde7b2b623b7a09e97e0f4d753baa9b9f07790d6798f707bbe27")
