-- Lua provided by RyzenAPI
-- Game: 我的恋爱逃生攻略 Love to Live Demo

-- MAIN APPLICATION
addappid(3389270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389271, 1, "861e9969d210ebdc2350f8f433f4def43d077bac508bd6d72e878412226a4ac4")
