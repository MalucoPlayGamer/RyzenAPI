-- Lua provided by RyzenAPI
-- Game: From The Grave

-- MAIN APPLICATION
addappid(1340910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1340911, 1, "1e18f93c3e7dccc912ac6561e7854f08e1c37aa72f138b93cc3adbea749d356d")

