-- Lua provided by RyzenAPI
-- Game: Game: From The Grave

-- MAIN APPLICATION
addappid(1340910)
-- Game: addappid(1340910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340911, 1, "1e18f93c3e7dccc912ac6561e7854f08e1c37aa72f138b93cc3adbea749d356d")
