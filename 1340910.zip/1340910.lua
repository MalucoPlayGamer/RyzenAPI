-- Lua provided by SkyAPI 
-- Game: From The Grave
addappid(1340910)
addappid(1340911, 1, "1e18f93c3e7dccc912ac6561e7854f08e1c37aa72f138b93cc3adbea749d356d")
