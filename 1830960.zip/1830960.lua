-- Lua provided by RyzenAPI
-- Game: addappid(1830960)

-- MAIN APPLICATION
addappid(1830960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830961, 1, "cdae1daf96a020fd17011000dcfb1fbc316667507ab605fcb20376bffa9d1fa6")
