-- Lua provided by RyzenAPI
-- Game: Red Algorithm

-- MAIN APPLICATION
addappid(1637910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637913,0,"63061a321a54c7699589e7c0cc05253f6a70fd87f8ca52b6730b5023a1b5033a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1638580)
addappid(1638581)
addappid(1638582)
addappid(1708890)
addappid(1761830)
addappid(1785170)
addappid(1935760)
