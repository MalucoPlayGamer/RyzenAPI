-- Lua provided by RyzenAPI
-- Game: Red Algorithm

-- MAIN APPLICATION
addappid(1637910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637913,0,"63061a321a54c7699589e7c0cc05253f6a70fd87f8ca52b6730b5023a1b5033a")
