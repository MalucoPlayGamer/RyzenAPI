-- Lua provided by RyzenAPI
-- Game: 760800

-- MAIN APPLICATION
addappid(760800)
-- Game: addappid(760800)

-- MAIN APP DEPOTS / PACKAGES
addappid(760801, 1, "9e802e3fb210f20d01ca0ef153fecece0f4ed367459204b06b6e3a7a6fa2d5d6")
