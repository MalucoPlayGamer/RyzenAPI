-- Lua provided by RyzenAPI
-- Game: Real-Time Assist Replay Time　～1 minute until closing～

-- MAIN APPLICATION
addappid(2310720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310721, 1, "363a942304fd96ba304b6a49903b55a7c06582b25a498c08a942a63569d2fc30")
