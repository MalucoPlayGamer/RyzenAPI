-- Lua provided by RyzenAPI
-- Game: Game: THE UNCLEARNESS

-- MAIN APPLICATION
addappid(1102720)
-- Game: addappid(1102720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102721, 1, "527d67a78614a5811a3fadb2642a0831b7bfac6f8054f6d4974e9aceb2dcbf3b")
