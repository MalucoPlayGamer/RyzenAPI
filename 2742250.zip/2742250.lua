-- Lua provided by RyzenAPI
-- Game: 锦鱼图

-- MAIN APPLICATION
addappid(2742250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742251, 1, "4f77b5698dd041d82d735706fc9eb515593fffa506cb2839815bec6d57cbbf4b")
