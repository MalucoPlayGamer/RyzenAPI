-- Lua provided by RyzenAPI
-- Game: Lefka 空垣 Demo

-- MAIN APPLICATION
addappid(2538680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538681, 1, "5a47903f9091e8ffe27c8125a9e880ca806e00888c75a4ceb2de1c42b2bbfd8b")
