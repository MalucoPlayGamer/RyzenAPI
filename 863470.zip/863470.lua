-- Lua provided by SkyAPI 
-- Game: AppID 863470
addappid(863470)
addappid(863471, 1, "6ab74abb40926de2caa2b6c9f8c1ba0e79bb23c573fc9dbfa98d6a8f13f0f4f6")
