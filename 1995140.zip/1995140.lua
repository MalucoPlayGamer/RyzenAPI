-- Lua provided by SkyAPI 
-- Game: AppID 1995140
addappid(1995140)
addappid(1995141, 1, "b94f8fb052ebd7d150e7dfda288eb9502e4bc3fd02bbf4e3294fff2904e3461f")
addappid(1995143, 1, "55b14dd10eeb4b78dfe796bffa4ac317371a1fdebac0a62237cd3fb536c6bbd9")
