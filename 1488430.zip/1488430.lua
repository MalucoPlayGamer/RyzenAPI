-- Lua provided by SkyAPI 
-- Game: Fueled Up
addappid(1488430)
addappid(1488431, 1, "2f93d0d224d26e9d409cea71d30cca11f35d65ac5ad5a313abba211fbf116893")
