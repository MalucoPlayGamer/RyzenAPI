-- Lua provided by RyzenAPI
-- Game: 758870

-- MAIN APPLICATION
addappid(758870)
-- Game: addappid(758870)

-- MAIN APP DEPOTS / PACKAGES
addappid(758871, 1, "dedbab1dec00f6d2fbb6eb1db52380e18cc9d3592d02d358dabd5a01495f09f1")
