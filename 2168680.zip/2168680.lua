-- Lua provided by RyzenAPI
-- Game: Nuclear Option

-- MAIN APPLICATION
addappid(2168680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168681, 1, "b4bbb514bb5576382bea279cb1eab6977bfccd957b53ad9db9ab5d85c34606c5")

