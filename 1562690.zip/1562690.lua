-- Lua provided by RyzenAPI
-- Game: addappid(1562690)

-- MAIN APPLICATION
addappid(1562690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562691, 1, "1752d1993f3de371df36865cf79aaec7f95906a46bd1f8d3e7947784f17ec5eb")
addappid(1562692, 1, "c4041d43abfa3c1c6c155abbb417d48b7feb938a551f7341f95a60f5092a4ad4")
addappid(1562693, 1, "50e13595bb74521c87b78497a5bebf56d1c592eed9b91990a1ecfdcc55073e46")
addappid(1562694, 1, "774b9f0e812ad9fcab59123eaab2da8ecb366c9b2cdd4ccabe4f0d0d1f438840")
