-- Lua provided by RyzenAPI
-- Game: 所谓侠客 So-called Hero

-- MAIN APPLICATION
addappid(1116080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116081, 1, "0d997cf515e97f18e08f0fcd232c1a799f5d6001a5490493005fd1b53b347d69")

