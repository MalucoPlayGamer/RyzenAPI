-- Lua provided by RyzenAPI
-- Game: Shuriken

-- MAIN APPLICATION
addappid(1713860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713861, 1, "87c2532fef0871a44e724b8e005ec2b4086521a9ef7cd6c67ac23a7c4ebaa663")

