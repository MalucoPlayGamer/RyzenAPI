-- Lua provided by RyzenAPI
-- Game: The Pillage

-- MAIN APPLICATION
addappid(715210)

-- MAIN APP DEPOTS / PACKAGES
addappid(715211,0,"5ba873d823a226f946c04e17c659923feb3d702495c8edce9a866aa612495460")
addappid(715212,0,"845cbe33c9cd6c952b6c2fb83a9a71908e7431f4fc3a167b6cb629e3453a7d70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
