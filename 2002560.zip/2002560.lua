-- Lua provided by RyzenAPI
-- Game: Tales From Hoia Baciu Forest

-- MAIN APPLICATION
addappid(2002560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002561, 1, "5429de6f4a5c20f3affe178a77bcb093ff80a63c52e61f310d5f6749487b6cd4")
