-- Lua provided by RyzenAPI
-- Game: Tales From Hoia Baciu Forest

-- MAIN APPLICATION
addappid(2002560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2002561, 1, "5429de6f4a5c20f3affe178a77bcb093ff80a63c52e61f310d5f6749487b6cd4")

