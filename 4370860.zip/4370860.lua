-- Lua provided by RyzenAPI
-- Game: Black Plague

-- MAIN APPLICATION
addappid(4370860)

-- MAIN APP DEPOTS / PACKAGES
addappid(4370861,0,"4c8ab2ba70181bdc8cd4ba92742acfb5ed642f1908a51fb876edd9ff9b6a5c81")

