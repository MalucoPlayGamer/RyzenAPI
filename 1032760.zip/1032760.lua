-- Lua provided by RyzenAPI
-- Game: Phoenix Wright: Ace Attorney Trilogy - Turnabout Tunes

-- MAIN APPLICATION
addappid(1032760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032761, 1, "31e5103081f6718fb15d5632a83a541b24e13599f8c4e18ccb5235300d4f6cf7")
addappid(1032762, 1, "7ba072ffb7c2d7d67aedfb29bddbedf50f9e0bc270ad1b7a63a731a0e7a6f90e")
addappid(1032763, 1, "bd6adedebee07a136b08d92685afdbdf9eede76f6390fb639c6e2ba8dd2d8de7")
addappid(1032764, 1, "7648bb2342ab3fae12c46a51184d2e4d625f5c13dab7666cb48605a04618d591")
addappid(1032765, 1, "026d9df7afaaf5c1d36f42934a843b9329e9d01f17148febd5728268a013c6a0")
addappid(1032766, 1, "011f13d9b8fa09c316b4808e7391ef1508ae14dc8fb2519d1f01bb56f652a792")

