-- Lua provided by RyzenAPI
-- Game: 1183580

-- MAIN APPLICATION
addappid(1183580)
-- Game: addappid(1183580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183581, 1, "da4438193a42eb9518e493253624c38b77b83c6313a318cec9bfd4a0b7166bc1")
