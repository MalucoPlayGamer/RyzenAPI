-- Lua provided by RyzenAPI
-- Game: Harvest Hustlers

-- MAIN APPLICATION
addappid(2934630)
-- Game: addappid(2934630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934631, 1, "7366b1bc858df96064d2740d1cbe4c055625e3699f2e7b437b0fb47a75196936")
