-- Lua provided by RyzenAPI
-- Game: Rogue Ascent VR

-- MAIN APPLICATION
addappid(2968390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968391, 1, "09ee1d4169d46f5edf523eb0c8a10018136dce6f4e7b89290da69e3f1d91a14c")

