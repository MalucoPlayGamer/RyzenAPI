-- Lua provided by RyzenAPI
-- Game: DreadStar

-- MAIN APPLICATION
addappid(710220)

-- MAIN APP DEPOTS / PACKAGES
addappid(710221,0,"f5e43506ae4a525513972b71016fe1de08ebc0d35fe6b1bb44e74fbdfdf7bb3d")
addappid(710228,0,"301a6773677357ef3ec7f4a2ffe09ec3a7b51985ac31d247bcf9c677ee8850b7")

