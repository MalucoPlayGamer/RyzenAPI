-- Lua provided by RyzenAPI
-- Game: Mercury: Cascade into Madness

-- MAIN APPLICATION
addappid(661120)

-- MAIN APP DEPOTS / PACKAGES
addappid(661121, 1, "ac1fb3502cc13b03af9bbf9b6861b35eba5a2ea918c11b3c2c7531c5c836d4cb")

