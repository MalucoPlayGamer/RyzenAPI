-- Lua provided by RyzenAPI
-- Game: addappid(3772440)

-- MAIN APPLICATION
addappid(3772440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772441, 1, "97f5594771fd63c1f83543438e01ae49fad77bbcea66ccb5446e6ec642320123")
