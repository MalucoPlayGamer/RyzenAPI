-- Lua provided by SkyAPI 
-- Game: Only Jump On Pogo
addappid(3772440)
addappid(3772441, 1, "97f5594771fd63c1f83543438e01ae49fad77bbcea66ccb5446e6ec642320123")
