-- Lua provided by RyzenAPI
-- Game: 1952540

-- MAIN APPLICATION
addappid(1952540)
-- Game: addappid(1952540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952541, 1, "f40b2d0992432c41b00b90000130c94e8ca4962e36bd36864d2cb16dbc5dcb70")
