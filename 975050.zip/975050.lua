-- Lua provided by RyzenAPI
-- Game: 975050

-- MAIN APPLICATION
addappid(975050)
-- Game: addappid(975050)

-- MAIN APP DEPOTS / PACKAGES
addappid(975051, 1, "f183156c7a7227351dd62c39f9d6ca8931ee6415afee862505c60bc64d9a1f2e")
