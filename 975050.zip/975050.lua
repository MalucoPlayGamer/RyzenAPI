-- Lua provided by RyzenAPI
-- Game: Orphan of the Petal

-- MAIN APPLICATION
addappid(975050)
addappid(1006820)
addappid(1006821)
addappid(1006822)
addappid(1006840)

-- MAIN APP DEPOTS / PACKAGES
addappid(975051,0,"f183156c7a7227351dd62c39f9d6ca8931ee6415afee862505c60bc64d9a1f2e")

