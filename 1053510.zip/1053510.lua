-- Lua provided by RyzenAPI 
-- Game: Super Technos World: River City & Technos Arcade Classics
addappid(1053510)
addappid(1053511, 1, "b30544b18b0a83614f44e7ef07afcea2048ffd36644939e3cf20bd6aedf57e45")
