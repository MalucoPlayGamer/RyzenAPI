-- Lua provided by RyzenAPI
-- Game: Super Technos World: River City & Technos Arcade Classics

-- MAIN APPLICATION
addappid(1053510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1053511, 1, "b30544b18b0a83614f44e7ef07afcea2048ffd36644939e3cf20bd6aedf57e45")

