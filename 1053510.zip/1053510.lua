-- Lua provided by RyzenAPI
-- Game: Game: Super Technos World: River City & Technos Arcade Classics

-- MAIN APPLICATION
addappid(1053510)
-- Game: addappid(1053510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053511, 1, "b30544b18b0a83614f44e7ef07afcea2048ffd36644939e3cf20bd6aedf57e45")
