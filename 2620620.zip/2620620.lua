-- Lua provided by RyzenAPI
-- Game: Station to Station Soundtrack

-- MAIN APPLICATION
addappid(2620620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620621, 1, "0ad3aaad618934157977cd1f01989bd2f75cdd40936a6a51b3561c90739c043b")
addappid(2620622, 1, "080fa29968a2e4ffa82dd6aff8a951ebd04ab4d22e380da6a1356489dbbb0aba")

