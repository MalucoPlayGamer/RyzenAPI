-- Lua provided by RyzenAPI
-- Game: Camellia Train

-- MAIN APPLICATION
addappid(1714660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714661, 1, "61c36686d4636662e07ef707a76f2a2c6a0d6e87ec999aa8adc21e949f3ec6c5")
