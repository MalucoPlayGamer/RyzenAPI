-- Lua provided by RyzenAPI
-- Game: Game: Air Dash

-- MAIN APPLICATION
addappid(755140)
-- Game: addappid(755140)

-- MAIN APP DEPOTS / PACKAGES
addappid(755141, 1, "85bc72f272e69366db74ebd942533d8a73b06706a0870070b7ffca68540cc966")
