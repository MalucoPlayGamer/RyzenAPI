-- Lua provided by RyzenAPI 
-- Game: Air Dash
addappid(755140)
addappid(755141, 1, "85bc72f272e69366db74ebd942533d8a73b06706a0870070b7ffca68540cc966")
