-- Lua provided by RyzenAPI
-- Game: Air Dash

-- MAIN APPLICATION
addappid(755140)

-- MAIN APP DEPOTS / PACKAGES
addappid(755141, 1, "85bc72f272e69366db74ebd942533d8a73b06706a0870070b7ffca68540cc966")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
