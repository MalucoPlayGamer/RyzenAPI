-- Lua provided by RyzenAPI
-- Game: addappid(2528150)

-- MAIN APPLICATION
addappid(2528150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2528151, 1, "7dfdfa736dbe68c2b2ae632fa103442dc56ac4f37c3319cea98bfbc466a53633")
