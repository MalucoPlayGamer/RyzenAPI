-- Lua provided by SkyAPI 
-- Game: Trans-Siberian Railway Simulator Demo
addappid(2528150)
addappid(2528151, 1, "7dfdfa736dbe68c2b2ae632fa103442dc56ac4f37c3319cea98bfbc466a53633")
