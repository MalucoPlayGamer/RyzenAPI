-- Lua provided by RyzenAPI
-- Game: 434140

-- MAIN APPLICATION
addappid(434140)
-- Game: addappid(434140)

-- MAIN APP DEPOTS / PACKAGES
addappid(434141, 1, "641cba1ccd27e7b0c4277cf0777843c92258b8656253957b486cfa399d0de4e9")
