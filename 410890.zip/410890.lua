-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.2 Watanagashi

-- MAIN APPLICATION
addappid(410890)

-- MAIN APP DEPOTS / PACKAGES
addappid(410891, 1, "b445e5f84842421c5fc764729b6cc86f0ef5d048dd010c021298fcfa56f505a2")
addappid(410892, 1, "dd4f857c528da04bfb83c3a04cd160fcd173553953d26af0af4aeb9f0fa05bbf")
addappid(410893, 1, "87a24efe6ba41b6406c7ea53121bb95bde74e8906de388f629daed76e45b4ed9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
