-- Lua provided by RyzenAPI
-- Game: 目盲/Blind

-- MAIN APPLICATION
addappid(2130540)
-- Game: addappid(2130540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130541, 1, "2c40c28d55ff5226c833d7bd469afc7b7e9ade8a1d8a7b9cd784e6d671e51a80")
addappid(2425050, 0, "defad77c12c47cf70f3e346b642f70c4a607e8feccb80508049e6e9a42996dac")
