-- Lua provided by RyzenAPI
-- Game: NORCO Act One Demo

-- MAIN APPLICATION
addappid(1601150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601151, 1, "c3c39cf7f52c1694086b5b55a6b1fb1e6a287cda05beb9c8d06d55df51f5ed0c")
