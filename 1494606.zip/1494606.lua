-- Lua provided by RyzenAPI
-- Game: FUSER™ - Dua Lipa & BLACKPINK - "Kiss and Make Up"

-- MAIN APPLICATION
addappid(1494606)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494606,0,"ce850c76be4d262827bc69cee3bd5f2a90678320353c3125de0ab6f64091c6f0")

