-- Lua provided by RyzenAPI
-- Game: articy:draft 3 FREE

-- MAIN APPLICATION
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229002)
addappid(1016220)

-- MAIN APP DEPOTS / PACKAGES
addappid(570091,0,"829b154056f761d8f4ff66ded72266e71a5b873214f36f412f7192d938a7feac")

