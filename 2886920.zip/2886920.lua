-- Lua provided by RyzenAPI
-- Game: Bud Masters - Peace Edition

-- MAIN APPLICATION
addappid(2886920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886921, 1, "acfcccc4942e95f286f552f0e47fef3d3a5c146d0a8e597274780bc386ae2e74")
