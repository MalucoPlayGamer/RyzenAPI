-- Lua provided by RyzenAPI
-- Game: Bud Masters - Peace Edition

-- MAIN APPLICATION
addappid(2886920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886921, 1, "acfcccc4942e95f286f552f0e47fef3d3a5c146d0a8e597274780bc386ae2e74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
