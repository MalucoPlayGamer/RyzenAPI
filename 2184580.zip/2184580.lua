-- Lua provided by RyzenAPI
-- Game: Memories Off6 T-wave

-- MAIN APPLICATION
addappid(2184580)
-- Game: addappid(2184580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184581, 1, "cd2afeec14c9bdd6d12fbccb4d3a3b0f3e5c1a2c4102f6e8225c1afb7860f9b3")
