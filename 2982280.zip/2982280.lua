-- Lua provided by RyzenAPI
-- Game: Oblin Party Demo

-- MAIN APPLICATION
addappid(2982280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982281, 1, "fbd0d2b407aa57f303e5ea07eecce52c52ddb1858827d0fda658db1506cd03c3")
