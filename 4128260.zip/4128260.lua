-- Lua provided by RyzenAPI
-- Game: Highguard

-- MAIN APPLICATION
addappid(4128260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4128261, 1, "31e52dc369fc0cea8cf9470868562f4ca19f402919e0d48af25dc5468fc34382")

