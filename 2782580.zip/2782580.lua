-- Lua provided by SkyAPI 
-- Game: War Lords 战争领主
addappid(2782580)
addappid(2782581, 1, "5b2e6662c56a54b4943dab377e6bb8fa9692d380114aca8199d5b60ad2ad1f7c")
