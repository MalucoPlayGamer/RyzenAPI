-- Lua provided by RyzenAPI
-- Game: Hunter of Antiques

-- MAIN APPLICATION
addappid(745060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(745061, 1, "55be8d549551a989dd7210d1665ebed74071b0176131c774868b2420d59f6121")
