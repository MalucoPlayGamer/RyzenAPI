-- Lua provided by RyzenAPI
-- Game: Neon Apex: Beyond the Limit

-- MAIN APPLICATION
addappid(3039250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039251, 1, "04d5fb89e3a0c94bc61cae42157be43a8bddb84b8bf1fc01cc32ccc0db008558")

