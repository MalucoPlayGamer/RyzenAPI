-- Lua provided by RyzenAPI
-- Game: しんせいかつ

-- MAIN APPLICATION
addappid(2863070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863071, 1, "bc435e42a4509be9b18b443fd0fc9a144f220dd0fcb540fbbc7108312d417c3f")
