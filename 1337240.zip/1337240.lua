-- Lua provided by RyzenAPI
-- Game: Gripper: Prologue

-- MAIN APPLICATION
addappid(1337240)
-- Game: addappid(1337240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337241, 1, "6d35e6927f48a1efc63ae34a5462e8bab8d3276b7417e54716293337aafc1782")
