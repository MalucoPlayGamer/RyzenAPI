-- Lua provided by RyzenAPI 
-- Game: A Sceptic's Guide to Magic
addappid(1074520)
addappid(1074521, 1, "dcb61386353eac76ae0d47ae00605f7b89710774bf39dcd254b3eded05e6547a")
