-- Lua provided by RyzenAPI
-- Game: AppID 561340

-- MAIN APPLICATION
addappid(561340)
-- Game: addappid(561340)

-- MAIN APP DEPOTS / PACKAGES
addappid(561341, 1, "8de82763e75c4586dc113b333d7d899d7548cb89f6879d09702effd7f857a83d")
