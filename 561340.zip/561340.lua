-- Lua provided by RyzenAPI
-- Game: AppID 561340

-- MAIN APPLICATION
addappid(561340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(561341, 1, "8de82763e75c4586dc113b333d7d899d7548cb89f6879d09702effd7f857a83d")

