-- Lua provided by RyzenAPI
-- Game: WAIFU IMPACT 2

-- MAIN APPLICATION
addappid(2989870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989871, 1, "50fcce3732e1403e2225e1e2c2ffba0fc3ef325f88a87c1a6502e61835b4d6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
