-- Lua provided by RyzenAPI
-- Game: 2989870

-- MAIN APPLICATION
addappid(2989870)
-- Game: addappid(2989870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989871, 1, "50fcce3732e1403e2225e1e2c2ffba0fc3ef325f88a87c1a6502e61835b4d6f5")
