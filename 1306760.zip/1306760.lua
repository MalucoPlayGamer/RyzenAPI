-- Lua provided by RyzenAPI
-- Game: 1306760

-- MAIN APPLICATION
addappid(1306760)
-- Game: addappid(1306760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306761, 1, "7e6a2db454b6386a027771a1b352c213f179312e72ffd490925c9d9ccfb676e0")
