-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Orochi Pack 2

-- MAIN APPLICATION
addappid(933557)
-- Game: addappid(933557)

-- MAIN APP DEPOTS / PACKAGES
addappid(933557,0,"f6efbcabc090c269f2dc0aa6bf46320b363bea3e31d9c9e496cbdeb6210b0557")
