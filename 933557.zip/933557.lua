-- Lua provided by RyzenAPI
-- Game: 933557

-- MAIN APPLICATION
addappid(933557)
-- Game: addappid(933557)

-- MAIN APP DEPOTS / PACKAGES
addappid(933557,0,"f6efbcabc090c269f2dc0aa6bf46320b363bea3e31d9c9e496cbdeb6210b0557")
