-- Lua provided by RyzenAPI
-- Game: 1568690

-- MAIN APPLICATION
addappid(1568690)
-- Game: addappid(1568690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568691, 1, "b1b03fdc922eb4095941956618aee0d6f26bf154443bece893f19f90e3b29e5f")
