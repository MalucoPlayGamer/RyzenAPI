-- Lua provided by RyzenAPI
-- Game: 混沌小队（CHAOS SQUAD）

-- MAIN APPLICATION
addappid(1660890)
-- Game: addappid(1660890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660891, 1, "5e3fa43b8fe592be46d086ee88a7383059e437a80b06f0f290f799150037a329")
