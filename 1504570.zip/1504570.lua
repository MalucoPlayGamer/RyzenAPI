-- Lua provided by RyzenAPI
-- Game: Game: Cultivation Tales

-- MAIN APPLICATION
addappid(1504570)
-- Game: addappid(1504570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504571, 1, "73df5decdd32e6c1b9ac3e2e7ecd5e1d252faa8b8f83639e807a4fabd31da425")
