-- Lua provided by RyzenAPI
-- Game: 557700

-- MAIN APPLICATION
addappid(557700)
-- Game: addappid(557700)

-- MAIN APP DEPOTS / PACKAGES
addappid(557701, 1, "843a29e3cc3f1f8215be00304ac6e5a0fcae6e1180825f50771be378038e54d8")
