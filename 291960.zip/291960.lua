-- Lua provided by SkyAPI 
-- Game: AppID 291960
addappid(291960)
addappid(291961, 1, "49a0b7515ddeb24544664b4aaab0a60327e7a248d526803c0d4523b151ac59a7")
addappid(321730, 0, "b0e0c5d93964b04b8ef486c578e13106d03172fef85963c9eb86fdeb47035b73")
