-- Lua provided by RyzenAPI
-- Game: AppID 291960

-- MAIN APPLICATION
addappid(291960)

-- MAIN APP DEPOTS / PACKAGES
addappid(291961, 1, "49a0b7515ddeb24544664b4aaab0a60327e7a248d526803c0d4523b151ac59a7")
addappid(321730, 0, "b0e0c5d93964b04b8ef486c578e13106d03172fef85963c9eb86fdeb47035b73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
