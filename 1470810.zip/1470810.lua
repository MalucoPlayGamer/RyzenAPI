-- Lua provided by RyzenAPI
-- Game: Plushy Store Tidy Up

-- MAIN APPLICATION
addappid(1470810) -- Plushy Store Tidy Up

-- MAIN APP DEPOTS / PACKAGES
addappid(1470812, 1, "972be910110990c8e522e4bb6f0c024e80536eb8ab1505a2ab32519f27e383f3") -- Depot 1470812
