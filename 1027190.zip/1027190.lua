-- Lua provided by RyzenAPI
-- Game: Hot Squat 2: New Glory

-- MAIN APPLICATION
addappid(1027190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1027191, 1, "9e1b52b8746845a451b153689c6bce74843bce9ea648011056fa6334427a629f")

