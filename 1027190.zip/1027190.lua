-- Lua provided by RyzenAPI 
-- Game: Hot Squat 2: New Glory
addappid(1027190)
addappid(1027191, 1, "9e1b52b8746845a451b153689c6bce74843bce9ea648011056fa6334427a629f")
