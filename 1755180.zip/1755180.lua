-- Lua provided by RyzenAPI
-- Game: 1755180

-- MAIN APPLICATION
addappid(1755180)
-- Game: addappid(1755180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755181, 1, "26105d4043facf808aa3584c67ad8530c7d274fa6ea834ba37b64676ef3966ea")
