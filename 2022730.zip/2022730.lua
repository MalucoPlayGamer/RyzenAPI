-- Lua provided by RyzenAPI
-- Game: addappid(2022730)

-- MAIN APPLICATION
addappid(2022730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022731, 1, "e0e428f8175956b1089ad2e4b5cb5e1c5ebf527dd06fb59d665822dad98345ff")
