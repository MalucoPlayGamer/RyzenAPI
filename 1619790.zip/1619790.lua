-- Lua provided by RyzenAPI
-- Game: 1619790

-- MAIN APPLICATION
addappid(1619790)
-- Game: addappid(1619790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619791, 1, "135ccb40c2f0391658c7fb4bb84ddf7052f96f34213fcb4471d99164ab58e4d5")
