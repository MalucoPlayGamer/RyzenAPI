-- Lua provided by RyzenAPI
-- Game: Delicious - Emily's Home Sweet Home

-- MAIN APPLICATION
addappid(561000)
-- Game: addappid(561000)

-- MAIN APP DEPOTS / PACKAGES
addappid(561001, 1, "a56e26484f65c16e9a6e0fc09425b51c32b4ced67a038a39e96dfe4ebabdd7fa")
