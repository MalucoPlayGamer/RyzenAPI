-- Lua provided by RyzenAPI
-- Game: 1450490

-- MAIN APPLICATION
addappid(1450490)
-- Game: addappid(1450490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450491, 1, "398e6cc3843229bd05cd9b056c8a96bef661fe0fa0e13267ad6b9021ffd18c95")
