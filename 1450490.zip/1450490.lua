-- Lua provided by SkyAPI 
-- Game: AppID 1450490
addappid(1450490)
addappid(1450491, 1, "398e6cc3843229bd05cd9b056c8a96bef661fe0fa0e13267ad6b9021ffd18c95")
