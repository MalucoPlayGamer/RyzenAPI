-- Lua provided by RyzenAPI
-- Game: Tennis Fighters

-- MAIN APPLICATION
addappid(994180)
-- Game: addappid(994180)

-- MAIN APP DEPOTS / PACKAGES
addappid(994181, 1, "7f5b30800cfdf52071fd32af30833d43e2d7b81f1c784eba34a6583a3e416f3c")
