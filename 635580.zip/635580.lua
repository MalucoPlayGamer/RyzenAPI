-- Lua provided by RyzenAPI
-- Game: addappid(635580)

-- MAIN APPLICATION
addappid(635580)
addappid(635581)

-- MAIN APP DEPOTS / PACKAGES
addappid(635580,0,"847a1937ea9e218845ad856f3c86b35e7186d9da500c59e01c4a36142057aefe")
