-- Lua provided by RyzenAPI
-- Game: SiNiSistar Lite Version

-- MAIN APPLICATION
addappid(1794780)
-- Game: addappid(1794780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794781, 1, "d6847462d7e1d7ea3d4f219a80dd1651a0ebe690a87b0821486c2343b9ef2c39")
addappid(1794782, 1, "3445a240b060691b1edad27bd8446a7457e8271ae02f7b5ba7c613c0e184de92")
