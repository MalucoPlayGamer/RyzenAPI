-- Lua provided by RyzenAPI
-- Game: AppID 1047010

-- MAIN APPLICATION
addappid(1047010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047011, 1, "36983f0d11c7505f4c520c328d11e8cbda09aa0955f521581919a255f45610f7")
addappid(1956360, 0, "075dfd303d573642dfdbf86e3e77173c65d970d2af36830732df4ab1aeed3b40")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2360910)
