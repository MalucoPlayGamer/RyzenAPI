-- Lua provided by RyzenAPI 
-- Game: Date with Foxgirl
addappid(2413720)
addappid(2413721, 1, "ac0f89c772ef9f4742aaf34baba7e48232de2aa19f004047151e46fa9603160e")
addappid(2425120)
