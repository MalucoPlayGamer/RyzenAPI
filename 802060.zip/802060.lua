-- Lua provided by RyzenAPI
-- Game: Spencer

-- MAIN APPLICATION
addappid(802060)

-- MAIN APP DEPOTS / PACKAGES
addappid(802061,0,"24c208f20f422fcd1cbe70b1ff499d91b5266153e382932c4763c2c71a091a82")

