-- Lua provided by RyzenAPI 
-- Game: Taora : Survival Demo
addappid(2308300)
addappid(2308301, 1, "005239addffaf057020e955bf40158567fa598dae45f239d3145959a53dee207")
