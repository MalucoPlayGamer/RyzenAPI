-- Lua provided by RyzenAPI
-- Game: Game: Taora : Survival Demo

-- MAIN APPLICATION
addappid(2308300)
-- Game: addappid(2308300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308301, 1, "005239addffaf057020e955bf40158567fa598dae45f239d3145959a53dee207")
