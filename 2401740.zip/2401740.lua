-- Lua provided by RyzenAPI
-- Game: ​Shattered Lands (破碎之地)

-- MAIN APPLICATION
addappid(2401740)
-- Game: addappid(2401740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401741, 1, "50dcac11cd99132bd0f1e125dd9f8755ba11c185ae17f07efcf34b1812e5cc8e")
