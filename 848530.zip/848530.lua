-- Lua provided by RyzenAPI
-- Game: Cyberemo 2007

-- MAIN APPLICATION
addappid(848530)

-- MAIN APP DEPOTS / PACKAGES
addappid(848531, 1, "4c4f2480296623e7d2826aeb39be7f3d56c8876c70b2500fa61fe6cfbf05de5d")

