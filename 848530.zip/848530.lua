-- Lua provided by RyzenAPI
-- Game: Cyberemo 2007

-- MAIN APPLICATION
addappid(848530)
addappid(1262610)

-- MAIN APP DEPOTS / PACKAGES
addappid(848531,0,"4c4f2480296623e7d2826aeb39be7f3d56c8876c70b2500fa61fe6cfbf05de5d")
addappid(1262610,0,"a90f4d1ebbc1729ef4895bc2fc3f813ed8171c9cb1a4d162da328c7a205dc677")

