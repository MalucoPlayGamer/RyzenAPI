-- Lua provided by RyzenAPI
-- Game: addappid(3102090)

-- MAIN APPLICATION
addappid(3102090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102091, 1, "70eefc64bbadda1bc41b9541719f7d3707416cb559c774dbe1a39c456aaf8c2d")
