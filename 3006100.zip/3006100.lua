-- Lua provided by RyzenAPI
-- Game: Night Project

-- MAIN APPLICATION
addappid(3006100)
addappid(3250490)
addappid(3250500)
addappid(3250510)
addappid(3250520)
addappid(3250550)
addappid(3921570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3006101, 1, "55b37f13572958df26b9168cbdb2cb68d7c450514c459a90f0931bacaf4a2b87")

