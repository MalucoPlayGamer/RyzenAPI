-- Lua provided by SkyAPI 
-- Game: Night Project
addappid(3006100)
addappid(3006101, 1, "55b37f13572958df26b9168cbdb2cb68d7c450514c459a90f0931bacaf4a2b87")
