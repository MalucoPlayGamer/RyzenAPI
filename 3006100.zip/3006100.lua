-- Lua provided by RyzenAPI
-- Game: Night Project

-- MAIN APPLICATION
addappid(3006100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006101, 1, "55b37f13572958df26b9168cbdb2cb68d7c450514c459a90f0931bacaf4a2b87")
