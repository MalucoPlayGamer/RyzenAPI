-- Lua provided by RyzenAPI
-- Game: Vomitoreum

-- MAIN APPLICATION
addappid(1549750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549751, 1, "d8185c8c554536bb56d605f481c11bdb101c8a3e73b077af54e2ff057eb617bc")

