-- 4514600's Lua and Manifest Created by Hubcap Manifest
-- Yokai Legends
-- Created: August 21, 2026 at 23:59:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4514600) -- Yokai Legends
-- MAIN APP DEPOTS
addappid(4514601, 1, "e668d8856824f479b406cd09c090a3c808df0e2f7596bd64507080275cf1d257") -- Depot 4514601
setManifestid(4514601, "6248275523611273967", 2512350268)