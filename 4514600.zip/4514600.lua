-- Lua provided by RyzenAPI
-- Game: Yokai Legends

-- MAIN APPLICATION
addappid(4514600) -- Yokai Legends

-- MAIN APP DEPOTS / PACKAGES
addappid(4514601, 1, "e668d8856824f479b406cd09c090a3c808df0e2f7596bd64507080275cf1d257") -- Depot 4514601

