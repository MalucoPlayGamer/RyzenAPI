-- Lua provided by RyzenAPI
-- Game: natsuno-kanata - beyond the summer

-- MAIN APPLICATION
addappid(1684660)
