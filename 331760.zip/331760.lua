-- Lua provided by RyzenAPI
-- Game: addappid(331760)

-- MAIN APPLICATION
addappid(331760)

-- MAIN APP DEPOTS / PACKAGES
addappid(331761, 1, "be1d0fa0d6891229e05615d13cbd00afd1e5caea7b29877ed8952bd03d52508d")
addappid(331762, 1, "5827849812a18cac83cb272799d8d9df8edac1dcfeb5b2ae15390d7f881172f8")
addappid(331763, 1, "689a2fcedc82b3057a1ba583030c07d5970779d92acacab42e06daaca5d8359a")
addappid(331764, 1, "894a1450f25e9f07f38906dfa4eadedaba0f2350c53be8ec6ac459ae2dc55720")
addappid(331765, 1, "5ea42db83300b3a791ffcc4b028f15f0a50e45f533b61e94da8786e4abe27b74")
