-- Lua provided by RyzenAPI
-- Game: Our Secret Below

-- MAIN APPLICATION
addappid(1061920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061921, 1, "b663d2ed2a5bfd30b4398dcc8e7dba3ffbdf9bb0e11096ea8b604d7251f2adbd")
