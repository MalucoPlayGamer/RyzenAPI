-- Lua provided by RyzenAPI
-- Game: AppID 904320

-- MAIN APPLICATION
addappid(904320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(904321, 1, "067fc5a16b39cb67d82e6695e2323b5b317fd54eee1426e19075a6da3f788ffc")
addappid(994710, 0, "6cd09d3f22859be3238c7c82f012ab8482e07a00bc557d430a0a69791bf0ac76")

