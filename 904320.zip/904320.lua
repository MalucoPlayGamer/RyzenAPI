-- Lua provided by RyzenAPI
-- Game: AppID 904320

-- MAIN APPLICATION
addappid(904320)
-- Game: addappid(904320)

-- MAIN APP DEPOTS / PACKAGES
addappid(904321, 1, "067fc5a16b39cb67d82e6695e2323b5b317fd54eee1426e19075a6da3f788ffc")
addappid(994710, 0, "6cd09d3f22859be3238c7c82f012ab8482e07a00bc557d430a0a69791bf0ac76")
