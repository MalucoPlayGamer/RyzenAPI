-- Lua provided by RyzenAPI
-- Game: The Beast and the Princess

-- MAIN APPLICATION
addappid(3216640)
-- Game: addappid(3216640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216641, 1, "b3f855f6e4ef3c6c9dffadea05699a0b10c52af9fb00ad08908b801f97967243")
