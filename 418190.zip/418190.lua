-- Lua provided by RyzenAPI
-- Game: Helen's Mysterious Castle

-- MAIN APPLICATION
addappid(418190)
addappid(418191)

-- MAIN APP DEPOTS / PACKAGES
addappid(418192,0,"2481254d64b31e47d5875275fd5d46a56ed98b908b85471869ddfa6ca94f6dcf")
addappid(418193,0,"562128d97cca3223040b093d2e5d4cb9d9304abf424853c2ed247a69c0b90083")

