-- Lua provided by RyzenAPI
-- Game: Zombie Derby 2

-- MAIN APPLICATION
addappid(762590)
-- Game: addappid(762590)

-- MAIN APP DEPOTS / PACKAGES
addappid(762591, 1, "06ca54d33e236b366b9b69892e5d92f1571c335c92b94fe682e1139cb876128e")
