-- Lua provided by RyzenAPI
-- Game: Game: A Flicker of Light

-- MAIN APPLICATION
addappid(1851910)
-- Game: addappid(1851910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851911, 1, "bfd8d56213121a5cbeb6a5c3a3a82b33d438117fe52633b919292a61e1105d34")
