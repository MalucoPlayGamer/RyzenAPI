-- Lua provided by RyzenAPI 
-- Game: AppID 1007980
addappid(1007980)
addappid(1007981, 1, "a196f5c49be0d610ef76d7581315cea956251b258e070f0ac32c002d87be5498")
