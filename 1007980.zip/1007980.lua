-- Lua provided by RyzenAPI
-- Game: Game: AppID 1007980

-- MAIN APPLICATION
addappid(1007980)
-- Game: addappid(1007980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007981, 1, "a196f5c49be0d610ef76d7581315cea956251b258e070f0ac32c002d87be5498")
