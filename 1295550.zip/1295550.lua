-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST XI S: Echoes of an Elusive Age - Definitive Edition DEMO

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1295550)
addappid(1295551)
addappid(1295552)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295553,0,"4582983303ad49e346f733ef0527921addce07b202561484ff8fd8dcb249f3b7")

