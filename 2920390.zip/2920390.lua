-- Lua provided by RyzenAPI
-- Game: addappid(2920390)

-- MAIN APPLICATION
addappid(2920390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920391, 1, "a74f1680bf0e2ab6e920c412b15893bc71d8d406fbf9a288c79caa602abec7c5")
