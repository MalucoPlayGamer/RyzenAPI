-- Lua provided by RyzenAPI
-- Game: Presidents vs Zombies

-- MAIN APPLICATION
addappid(1252160)
-- Game: addappid(1252160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252169,0,"38878c89200a3edfe4736d4e26289b0ac49480445abbc8fd993bf2d2b5229a57")
