-- Lua provided by RyzenAPI
-- Game: addappid(1669820)

-- MAIN APPLICATION
addappid(1669820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669821, 1, "4d94ba0498bd8f8b7f181a7ecdc78364ab18a33b0a96d709f90cd03eab335075")
