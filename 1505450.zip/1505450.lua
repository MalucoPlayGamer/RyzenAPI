-- Lua provided by RyzenAPI
-- Game: Oscar & Gems: Puzzle Quest

-- MAIN APPLICATION
addappid(1505450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505451, 1, "b1a05d4c7bce1232fce04583fb0d0caee6bdd1ca3a8f94e004c4a7408ee21679")

