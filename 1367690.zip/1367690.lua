-- Lua provided by RyzenAPI
-- Game: Tony Stewart's All-American Racing

-- MAIN APPLICATION
addappid(1367690)
-- Game: addappid(1367690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367691, 1, "59a347fe3173059e00391fe65254117bd85446a9179b284c3078f6a69dc47688")
addappid(1445180, 0, "fa2816cf3fd98490fec9234e24284a551c1980012fd0d4f7130ee58b5a6c4aa4")
addappid(1457050, 0, "f9f1966b4d2d5639751f4ba75b762ab5619cec03c20598e3249b1b420fd1739f")
addappid(1457051, 0, "e0cd4393df98ba0acdc3c0e99da41e383cdf367873a4ab06b1d53f1ad9c502c1")
addappid(1457052, 0, "e3d11485787543da85f353456b7d990b6ce2f6f2ad88b898e9a58b59b0c6d29d")
addappid(1457053, 0, "eddbc5ef9ab3138ccc7bcea742ba04c95d9de2637f0eb2ee4aa30a16ab97bcd8")
