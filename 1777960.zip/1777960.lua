-- Lua provided by RyzenAPI
-- Game: addappid(1777960)

-- MAIN APPLICATION
addappid(1777960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777961, 1, "e23e8786dcc4f209fd1bbb67ad70aef46fa9e73ed176341bcb1ee1704ad86292")
