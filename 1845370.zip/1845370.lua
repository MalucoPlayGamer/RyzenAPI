-- Lua provided by SkyAPI 
-- Game: Dungeonball
addappid(1845370)
addappid(1845371, 1, "32957acc349bd5088426add50283f3a484084c8f1aacdd423a192fb42d80a76a")
