-- Lua provided by RyzenAPI
-- Game: Aisu Paradise

-- MAIN APPLICATION
addappid(1081780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081781, 1, "caeff5438b653c3d32b557677f0dc537a4df77c2fbaaacf11d0fba4fb85aaca8")

