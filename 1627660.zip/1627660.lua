-- Lua provided by RyzenAPI
-- Game: A Clever Label

-- MAIN APPLICATION
addappid(1627660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627661, 1, "30b65c0a153c32ef4da63d18701c236d8bb40a01e5d2ea1310eb459994131dad")

