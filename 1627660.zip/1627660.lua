-- Lua provided by RyzenAPI
-- Game: A Clever Label

-- MAIN APPLICATION
addappid(1627660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1627661, 1, "30b65c0a153c32ef4da63d18701c236d8bb40a01e5d2ea1310eb459994131dad")

