-- Lua provided by RyzenAPI
-- Game: addappid(581470)

-- MAIN APPLICATION
addappid(581470)

-- MAIN APP DEPOTS / PACKAGES
addappid(581471, 1, "21ae4e4cd37f1362e1cca0ee3a623b87e3d29816669a66e5000fa2a91f8c76eb")
