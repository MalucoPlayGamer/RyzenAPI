-- Lua provided by RyzenAPI
-- Game: AppID 374630

-- MAIN APPLICATION
addappid(374630)

-- MAIN APP DEPOTS / PACKAGES
addappid(374631, 1, "101b393b02b060e4b5a43c7e099224228b723391516c86e3490300d30662030a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
