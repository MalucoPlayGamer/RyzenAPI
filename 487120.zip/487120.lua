-- Lua provided by RyzenAPI
-- Game: Citadel: Forged With Fire

-- MAIN APPLICATION
addappid(487120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(487121, 1, "4c501a8893cb40344da30e292f34450808cb2863d4b616b21b1261811cede857")
