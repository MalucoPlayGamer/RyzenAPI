-- Lua provided by RyzenAPI
-- Game: 1913620

-- MAIN APPLICATION
addappid(1913620)
-- Game: addappid(1913620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913621, 1, "0cfd8d439500081e3970ec7f4f5b22befc24ebf910cb7b138d7441cf8777a3a2")
