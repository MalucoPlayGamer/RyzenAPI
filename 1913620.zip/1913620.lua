-- Lua provided by RyzenAPI
-- Game: Puzzle Bobble™2X/BUST-A-MOVE™2 Arcade Edition & Puzzle Bobble™3/BUST-A-MOVE™3 S-Tribute

-- MAIN APPLICATION
addappid(1913620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913621, 1, "0cfd8d439500081e3970ec7f4f5b22befc24ebf910cb7b138d7441cf8777a3a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
