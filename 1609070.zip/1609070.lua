-- Lua provided by RyzenAPI
-- Game: Calluna

-- MAIN APPLICATION
addappid(1609070)
-- Game: addappid(1609070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609071, 1, "99bc0e7174cc37aeb4e9c5f6604ad815cbacef9fd5debb5924bde5ab335c79e3")
