-- Lua provided by RyzenAPI
-- Game: Calluna

-- MAIN APPLICATION
addappid(1609070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609071, 1, "99bc0e7174cc37aeb4e9c5f6604ad815cbacef9fd5debb5924bde5ab335c79e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
