-- Lua provided by RyzenAPI
-- Game: 3051180

-- MAIN APPLICATION
addappid(3051180)
-- Game: addappid(3051180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051181, 1, "e41ebd32042682c5323ed7cd47b53c9dd06a95bb0b744b8309b7ed3616710718")
