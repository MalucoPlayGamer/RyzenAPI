-- Lua provided by SkyAPI 
-- Game: The Man in the Fields
addappid(3051180)
addappid(3051181, 1, "e41ebd32042682c5323ed7cd47b53c9dd06a95bb0b744b8309b7ed3616710718")
