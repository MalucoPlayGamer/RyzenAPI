-- Lua provided by RyzenAPI
-- Game: Only Up 2

-- MAIN APPLICATION
addappid(2653170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653171, 1, "579af93a9d306f200989f2668898d6c2eae91cc5a72891a741194e4c31593bf4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
