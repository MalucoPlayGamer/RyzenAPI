-- Lua provided by RyzenAPI
-- Game: Game: Only Up 2

-- MAIN APPLICATION
addappid(2653170)
-- Game: addappid(2653170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653171, 1, "579af93a9d306f200989f2668898d6c2eae91cc5a72891a741194e4c31593bf4")
