-- Lua provided by RyzenAPI
-- Game: AppID 2591660

-- MAIN APPLICATION
addappid(2591660)
-- Game: addappid(2591660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591661, 1, "34f9e0afc27b77af4264190fda9a4c7df26038afd1175249327c796e0e1aca3c")
