-- Lua provided by RyzenAPI
-- Game: Latex Dungeon

-- MAIN APPLICATION
addappid(1622780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622781, 1, "93c09adb726866a02fed3573147871079e5027e35a918b7db87244dd893ca758")
addappid(1622782, 1, "3b542665c7fecb3075903fd92e0637254ad120cdd5ec076abd40eefd3918e173")
addappid(1622783, 1, "5b4daeab6ffaaa0a8dc0cea0444e3a4f9e11be6f3187db3b784d592e55251afe")
