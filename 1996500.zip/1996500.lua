-- Lua provided by RyzenAPI
-- Game: The Purge Dilemma

-- MAIN APPLICATION
addappid(1996500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996501, 1, "c4dd454bd16c0a302a78da9b5d761ac6f57ed50261b888425e26059eedaf47c2")
