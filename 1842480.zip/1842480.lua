-- Lua provided by RyzenAPI
-- Game: addappid(1842480)

-- MAIN APPLICATION
addappid(1842480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842481, 1, "dd9c23b4b013986aef79261decdc20400a49388a9dee7e6cfdd27405603ac494")
