-- Lua provided by RyzenAPI
-- Game: Hit Tank PRO

-- MAIN APPLICATION
addappid(423760)

-- MAIN APP DEPOTS / PACKAGES
addappid(423761, 1, "222e71bd9c4b9bf61b9ab613add83ae9ab39fc890afb3619c95dd1a8c491c761")
