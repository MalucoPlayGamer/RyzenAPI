-- Lua provided by RyzenAPI
-- Game: AppID 3675450

-- MAIN APPLICATION
addappid(3675450)
-- Game: addappid(3675450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3675451, 1, "9a3a157a248674ab3d82f27e72748ce6b5c2fc2d01b6969df75c893403e1f528")
