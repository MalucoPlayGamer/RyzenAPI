-- Lua provided by RyzenAPI 
-- Game: Der Geistermeister
addappid(2560620)
addappid(2560621, 1, "27858760d5539a8530033606a8559ec131225f12c3fb946b7af00e371db98b2e")
