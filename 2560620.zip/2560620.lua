-- Lua provided by RyzenAPI
-- Game: Der Geistermeister

-- MAIN APPLICATION
addappid(2560620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2560621, 1, "27858760d5539a8530033606a8559ec131225f12c3fb946b7af00e371db98b2e")

