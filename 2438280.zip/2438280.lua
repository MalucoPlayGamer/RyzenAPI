-- Lua provided by RyzenAPI
-- Game: Sea of Survivors Demo

-- MAIN APPLICATION
addappid(2438280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438281, 1, "6fde159d5648fdb3e27a47c2332ccc2c65e32321d0f24ff62332be90ef46c8a5")

