-- Lua provided by RyzenAPI
-- Game: Game: Sydney's World

-- MAIN APPLICATION
addappid(362160)
-- Game: addappid(362160)

-- MAIN APP DEPOTS / PACKAGES
addappid(362161, 1, "f23caa949a5f0ff9378a5304221847ed9a4e7a83e5ff519fdfe0901fb433944c")
