-- Lua provided by RyzenAPI
-- Game: 1598230

-- MAIN APPLICATION
addappid(1598230)
addappid(4179300)
-- Game: addappid(1598230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598231, 1, "f7759ab7595d3c7e6d6f4665b515e43036aa27eef8264326078f1c0acd94cb55")
