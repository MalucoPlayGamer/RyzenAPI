-- Lua provided by RyzenAPI
-- Game: KILLER INN

-- MAIN APPLICATION
addappid(1598230)
addappid(4179300)
addappid(4794360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598231,0,"f7759ab7595d3c7e6d6f4665b515e43036aa27eef8264326078f1c0acd94cb55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
