-- Lua provided by RyzenAPI
-- Game: Last Will

-- MAIN APPLICATION
addappid(453720)

-- MAIN APP DEPOTS / PACKAGES
addappid(453721, 1, "85ebd6d3552e2312b18389c7de7a9cb81925f779a58797583f24e4c70e8c2106")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
