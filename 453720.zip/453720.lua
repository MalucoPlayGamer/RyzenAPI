-- Lua provided by RyzenAPI
-- Game: 453720

-- MAIN APPLICATION
addappid(453720)
-- Game: addappid(453720)

-- MAIN APP DEPOTS / PACKAGES
addappid(453721, 1, "85ebd6d3552e2312b18389c7de7a9cb81925f779a58797583f24e4c70e8c2106")
