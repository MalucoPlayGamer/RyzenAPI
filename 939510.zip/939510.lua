-- Lua provided by SkyAPI 
-- Game: Pandemic Express - Zombie Escape
addappid(939510)
addappid(939511, 1, "095a6be2c44dadf7362466b4d7265f17fb2e2c9d52a29b02a1fb69ae980fb939")
