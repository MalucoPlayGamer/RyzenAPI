-- Lua provided by RyzenAPI
-- Game: Pandemic Express - Zombie Escape

-- MAIN APPLICATION
addappid(939510)

-- MAIN APP DEPOTS / PACKAGES
addappid(939511, 1, "095a6be2c44dadf7362466b4d7265f17fb2e2c9d52a29b02a1fb69ae980fb939")
