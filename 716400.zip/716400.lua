-- Lua provided by RyzenAPI
-- Game: 716400

-- MAIN APPLICATION
addappid(716400)
-- Game: addappid(716400)

-- MAIN APP DEPOTS / PACKAGES
addappid(716401, 1, "d72c34ec1711953718e96f841695ecd2af141e82fbee1d5453cb2bb25d707dd4")
