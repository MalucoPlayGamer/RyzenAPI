-- Lua provided by RyzenAPI
-- Game: 诛天记

-- MAIN APPLICATION
addappid(1675590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675591, 1, "c6811359721d15ee8f89f4279c5d63c875f03d2e74644c1b65a67c4a6c5bef35")
