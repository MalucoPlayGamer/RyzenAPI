-- Lua provided by RyzenAPI 
-- Game: AppID 1675590
addappid(1675590)
addappid(1675591, 1, "c6811359721d15ee8f89f4279c5d63c875f03d2e74644c1b65a67c4a6c5bef35")
