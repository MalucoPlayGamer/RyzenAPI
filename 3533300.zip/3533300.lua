-- Lua provided by SkyAPI 
-- Game: AppID 3533300
addappid(3533300)
addappid(3533301, 1, "6b989fbf68a04cf00f85f809ba90dbc7060a4b23b6d75d538c3c4765687b4320")
addappid(3533302, 1, "e643e22cc9a5bb827cf4b46b304a175fffddbda390f6738871705f25964ae487")
