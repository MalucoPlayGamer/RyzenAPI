-- Lua provided by RyzenAPI
-- Game: AppID 2959440

-- MAIN APPLICATION
addappid(2959440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959441, 1, "85dff4ccc546ca6d4e39ab5209e807ce8a3d269e0c9bc3bb380fff6ecc6aa0e4")
