-- Lua provided by RyzenAPI
-- Game: Launch Director

-- MAIN APPLICATION
addappid(2444890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444891, 1, "4c4b28cd81e7f219e6020a0945b08ad6a7a747f8484c0f985503776a4219d6e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
