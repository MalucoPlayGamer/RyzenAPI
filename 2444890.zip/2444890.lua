-- Lua provided by RyzenAPI
-- Game: Launch Director

-- MAIN APPLICATION
addappid(2444890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444891, 1, "4c4b28cd81e7f219e6020a0945b08ad6a7a747f8484c0f985503776a4219d6e5")

