-- Lua provided by RyzenAPI
-- Game: 1734070

-- MAIN APPLICATION
addappid(1734070)
-- Game: addappid(1734070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734071, 1, "15d8af2106ca1aa26fbc0da3b60ff929e41fc7e3f238652bededb36705700d0a")
