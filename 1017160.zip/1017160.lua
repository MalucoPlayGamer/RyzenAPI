-- Lua provided by RyzenAPI
-- Game: Game: AppID 1017160

-- MAIN APPLICATION
addappid(1017160)
-- Game: addappid(1017160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017161, 1, "25339859d396b7eb16206b0bba410ae533dc302316fc9431a3a3475d02eaf593")
addappid(1761590, 0, "37bbaf03dd241d9e3b690aa7a52434a79fa6b002ca69ccf99842ee6c8c9e0007")
