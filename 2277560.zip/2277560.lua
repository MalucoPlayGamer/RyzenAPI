-- Lua provided by RyzenAPI
-- Game: WUCHANG: Fallen Feathers

-- MAIN APPLICATION
addappid(2277560)
addappid(3653760)
addappid(3653770)
addappid(3653780)
addappid(3653790)
addappid(3758190)
-- Game: addappid(2277560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277561, 1, "6db3af8b5be3def24c758a005feb7fa0f65750716392328e2f14321340adb273")
