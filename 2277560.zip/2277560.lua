-- Lua provided by RyzenAPI
-- Game: WUCHANG: Fallen Feathers

-- MAIN APPLICATION
addappid(2277560)
addappid(3653760)
addappid(3653770)
addappid(3653780)
addappid(3653790)
addappid(3758190)
addappid(3986030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2277561, 1, "6db3af8b5be3def24c758a005feb7fa0f65750716392328e2f14321340adb273")

