-- Lua provided by RyzenAPI
-- Game: Game: BEAT AIMER! Demo

-- MAIN APPLICATION
addappid(2146890)
-- Game: addappid(2146890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146891, 1, "1b69fd3c188311a500099bfcbd0aff07a51a6278c37dae4ae6571ac2d2da73aa")
