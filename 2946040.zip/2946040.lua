-- Lua provided by RyzenAPI
-- Game: Jade Guardian

-- MAIN APPLICATION
addappid(2946040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946041, 1, "682e4fc8bbc243888b1daffeab38f03a28ffb8e7872cfbad767f50c761f0eb36")
