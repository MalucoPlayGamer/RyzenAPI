-- Lua provided by RyzenAPI
-- Game: Windforge

-- MAIN APPLICATION
addappid(266170)
-- Game: addappid(266170)

-- MAIN APP DEPOTS / PACKAGES
addappid(266171, 1, "d7e28d2046bd523fe3362f5c6d4450753daa2b0bb9d9d68f9fe0f95187d1a877")
