-- Lua provided by RyzenAPI
-- Game: Game: Hatsuyuki Sakura

-- MAIN APPLICATION
addappid(3171460)
-- Game: addappid(3171460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171461, 1, "06f3fb6f36c37950fc4b799d34278264560ea98204d6d18f311671a90e89a5d9")
