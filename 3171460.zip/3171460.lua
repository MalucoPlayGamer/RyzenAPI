-- Lua provided by RyzenAPI
-- Game: Hatsuyuki Sakura

-- MAIN APPLICATION
addappid(3171460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3171461, 1, "06f3fb6f36c37950fc4b799d34278264560ea98204d6d18f311671a90e89a5d9")

