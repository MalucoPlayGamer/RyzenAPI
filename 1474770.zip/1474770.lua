-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Spirit of Liberty

-- MAIN APPLICATION
addappid(1474770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1474771, 1, "93de0f57dee56bbd0b6f507ad7d7b46067398d32d48f933aeb8a399a944955e3")

