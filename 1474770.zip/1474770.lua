-- Lua provided by RyzenAPI
-- Game: 1474770

-- MAIN APPLICATION
addappid(1474770)
-- Game: addappid(1474770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474771, 1, "93de0f57dee56bbd0b6f507ad7d7b46067398d32d48f933aeb8a399a944955e3")
