-- Lua provided by RyzenAPI
-- Game: Game: Defense of the Sodomites

-- MAIN APPLICATION
addappid(3067330)
-- Game: addappid(3067330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3067331, 1, "6967f0c3c53d0b5f43a3d4549e122f5e690fb7f3a533c1512b9e943890091bc6")
