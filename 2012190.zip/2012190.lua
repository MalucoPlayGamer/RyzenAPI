-- Lua provided by RyzenAPI
-- Game: KAISERPUNK

-- MAIN APPLICATION
addappid(2012190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012191, 1, "d563cc1e972880af6c0ef3a7d0074401446803137170f7d69b35db1a59764936")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3587380)
