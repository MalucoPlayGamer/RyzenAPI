-- Lua provided by RyzenAPI
-- Game: Please Knock on My Door

-- MAIN APPLICATION
addappid(613450)

-- MAIN APP DEPOTS / PACKAGES
addappid(613451, 1, "9ca917e41df0c7f168508b87650c106c1d9ff3b65dcc638dc33588ea691da986")
addappid(629680, 0, "29a6421ee04782b61b69b8537cacf044b9f8162cd03192d2904475bd99f2c9b1")

