-- Lua provided by RyzenAPI
-- Game: AppID 777130

-- MAIN APPLICATION
addappid(777130)

-- MAIN APP DEPOTS / PACKAGES
addappid(777131, 1, "050b3fce05f050ff4d9ea7319b6e4210e89173946da7ce8bac867472fc425f85")
addappid(777132, 1, "13793856cffc9df68f4ce12b794c00505ea84056406a1248cbd452dc7f3348f3")
addappid(777133, 1, "6bdf225849878dc62ff8b8ddede7efa4e33d1bcc8a52518dd8cb911ff874312e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1223580)
addappid(2587610)
addappid(4820730)
