-- Lua provided by RyzenAPI
-- Game: 2217210

-- MAIN APPLICATION
addappid(2217210)
-- Game: addappid(2217210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217211, 1, "9bac3164f51d456dc69958a7fe5afd585fab5a2416537fea305472dea29c310a")
