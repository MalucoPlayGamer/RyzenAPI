-- Lua provided by RyzenAPI 
-- Game: Hentai Nurse
addappid(2217210)
addappid(2217211, 1, "9bac3164f51d456dc69958a7fe5afd585fab5a2416537fea305472dea29c310a")
