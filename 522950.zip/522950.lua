-- Lua provided by RyzenAPI
-- Game: Mayhem ZX

-- MAIN APPLICATION
addappid(522950)
-- Game: addappid(522950)

-- MAIN APP DEPOTS / PACKAGES
addappid(522951, 1, "8e4ae963185a3ae3a0ded98d1de12077e46ae4e0bde0894b3af69fd3711a86db")
