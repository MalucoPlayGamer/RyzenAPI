-- Lua provided by RyzenAPI
-- Game: Game: Victory: The Age of Racing

-- MAIN APPLICATION
addappid(264120)
-- Game: addappid(264120)

-- MAIN APP DEPOTS / PACKAGES
addappid(264121, 1, "6f88e6a79512fb7ca617ce561f53fd43120c3cafecb26c23dfd7f767fe1ed212")
