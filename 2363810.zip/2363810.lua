-- Lua provided by RyzenAPI
-- Game: Long Truck Simulator

-- MAIN APPLICATION
addappid(2363810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363811, 1, "b6db654179d6ebe5ea1ea5766ea9070a1605c73a5aed99168c88c2f2bfc830b7")
