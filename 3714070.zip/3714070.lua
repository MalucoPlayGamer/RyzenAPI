-- Lua provided by RyzenAPI
-- Game: Remember

-- MAIN APPLICATION
addappid(3714070)
-- Game: addappid(3714070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714072,0,"1aca7a735f990182aafa0d53b13611417bb90dfc5dc9fe72d990f25bf15ed484")
