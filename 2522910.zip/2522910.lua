-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2522910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522910,0,"b03244034508e3ea3fd43eb2d8878aaea19d6244e7ef432f380b27475506449f")
