-- Lua provided by RyzenAPI
-- Game: Tank Battle: 1945

-- MAIN APPLICATION
addappid(540250)

-- MAIN APP DEPOTS / PACKAGES
addappid(540251, 1, "df3ceaf496a3e1ff0c5c0b10591f9df8ae6278309c0748bd4d77571c66393758")
addappid(540252, 1, "10197e2586254a08356192cc2e5c5a2d2077b74ec9c17431a6613abd49ccc49b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
