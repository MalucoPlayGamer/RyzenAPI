-- Lua provided by RyzenAPI
-- Game: Burning Skies Arcade

-- MAIN APPLICATION
addappid(2290190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290191, 1, "cc295f1e4e4ff5c9fb3f35a930bf39e8ee1cf0466e2bc5f9592f37b07600d56f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2964490)
addappid(3024030)
addappid(3028710)
