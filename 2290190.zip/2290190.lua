-- Lua provided by RyzenAPI
-- Game: 2290190

-- MAIN APPLICATION
addappid(2290190)
-- Game: addappid(2290190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290191, 1, "cc295f1e4e4ff5c9fb3f35a930bf39e8ee1cf0466e2bc5f9592f37b07600d56f")
