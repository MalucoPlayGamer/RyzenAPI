-- Lua provided by RyzenAPI
-- Game: AGNI

-- MAIN APPLICATION
addappid(1822340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1822341, 1, "aab5a9033a7f4c7872a457b6a0455e6dba1aafd8b73f01735f9b65072cde438a")

