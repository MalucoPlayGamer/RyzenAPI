-- Lua provided by RyzenAPI
-- Game: Myriad Tower Defense

-- MAIN APPLICATION
addappid(1186170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186171, 1, "4a5f22efd4cd04a585619b03db296fe2512f4c6e3b6156c2c8fb47fa1d8086bf")

