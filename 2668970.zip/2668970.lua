-- Lua provided by RyzenAPI
-- Game: AppID 2668970

-- MAIN APPLICATION
addappid(2668970)
-- Game: addappid(2668970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668971, 1, "c3efee8e155526c53d795d216d9d2540056def17ddd21012fd3cb0ba34b84821")
