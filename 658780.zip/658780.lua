-- Lua provided by RyzenAPI
-- Game: addappid(658780)

-- MAIN APPLICATION
addappid(658780)

-- MAIN APP DEPOTS / PACKAGES
addappid(658781, 1, "034778463baf480bb5d4a28858c227cec177f212fe0610f60aeb56fee05e9800")
