-- Lua provided by RyzenAPI
-- Game: Deadly Night - No Escape

-- MAIN APPLICATION
addappid(1177850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177851, 1, "15c87de3628035b51417f26d5072977dbc36aad15d4585cb7379a5c86a75c522")
