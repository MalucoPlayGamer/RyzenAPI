-- Lua provided by RyzenAPI 
-- Game: AppID 694990
addappid(694990)
addappid(694991, 1, "e9d93647c9e6f676b18d99eecf653a9ed90fbd2b451f34e1c4d5ffc4b2af0ef8")
