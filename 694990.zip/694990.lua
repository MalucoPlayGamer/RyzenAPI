-- Lua provided by RyzenAPI
-- Game: Goblin and Coins II

-- MAIN APPLICATION
addappid(694990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(694991, 1, "e9d93647c9e6f676b18d99eecf653a9ed90fbd2b451f34e1c4d5ffc4b2af0ef8")

