-- Lua provided by RyzenAPI
-- Game: addappid(694990)

-- MAIN APPLICATION
addappid(694990)

-- MAIN APP DEPOTS / PACKAGES
addappid(694991, 1, "e9d93647c9e6f676b18d99eecf653a9ed90fbd2b451f34e1c4d5ffc4b2af0ef8")
