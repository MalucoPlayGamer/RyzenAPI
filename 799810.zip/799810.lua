-- Lua provided by RyzenAPI
-- Game: Returner 77

-- MAIN APPLICATION
addappid(799810)

-- MAIN APP DEPOTS / PACKAGES
addappid(799811,0,"7c4dce102393799865e23a1a3e759abde4a24e30dffb1d8cfcebe5e2e7621edb")
addappid(799813,0,"fff7f7cbf8de7421cd6d668abd9c8698bea43e100983c8683b293a015aba2986")

