-- Lua provided by RyzenAPI
-- Game: Girls' Frontline

-- MAIN APPLICATION
addappid(3887700)

