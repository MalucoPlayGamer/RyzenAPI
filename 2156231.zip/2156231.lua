-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - "Back to Summer" Costume Set

-- MAIN APPLICATION
addappid(2156231)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156231,0,"dae7259e161b7d1e0bfa3edadc759033b07e4b59c552c7b8564ea293da3d51fd")

