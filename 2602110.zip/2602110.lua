-- Lua provided by RyzenAPI 
-- Game: Noah's Descent into Madness
addappid(2602110)
addappid(2602111, 1, "2cac93d8fc0fdf0842070b72c20eb4c68368471b6aae963e60f380440c07e57b")
