-- Lua provided by RyzenAPI
-- Game: Sewer Side

-- MAIN APPLICATION
addappid(4862560) -- Sewer Side

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4862561, 1, "97d0e57ef0729ea2436e0aaf56525bba3a8c64633e27b7ab4feede8990fd4be3") -- Depot 4862561

