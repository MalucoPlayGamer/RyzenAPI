-- 4862560's Lua and Manifest Created by Hubcap Manifest
-- Sewer Side
-- Created: August 15, 2026 at 00:10:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4862560) -- Sewer Side
-- MAIN APP DEPOTS
addappid(4862561, 1, "97d0e57ef0729ea2436e0aaf56525bba3a8c64633e27b7ab4feede8990fd4be3") -- Depot 4862561
setManifestid(4862561, "567148452551356334", 7703753252)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)