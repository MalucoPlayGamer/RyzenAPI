-- Lua provided by RyzenAPI
-- Game: Open Sorcery

-- MAIN APPLICATION
addappid(585180)

-- MAIN APP DEPOTS / PACKAGES
addappid(585181,0,"5fd91efdc914ebaeb79b3eaa38c7f8580a95799d1bcf43bb2b70a5ddf4e07842")
addappid(585182,0,"156241a1459433c247ac5af2384872eaac5f663a3c8850f227d5ffe4be4817aa")
addappid(585183,0,"11296c425a17a71430ad340120b305f4ce3623917c250025e30fd29be311cd24")
addappid(585184,0,"d94ab78ea98c4806f011688d5a94029d97d78ee90797a38c3a4710170b36227b")
addappid(585185,0,"df1746049f0bd16e412ac5512ed488c42c2b1c1cfdde723ad4401b6eb9e87dbe")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(694390)
