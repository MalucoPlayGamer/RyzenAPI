-- Lua provided by RyzenAPI
-- Game: addappid(1526090)

-- MAIN APPLICATION
addappid(1526090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526091, 1, "06ca766c1ec5eb6fccdc5bca075fc470a630b59216651f6b20e553e68d79e485")
