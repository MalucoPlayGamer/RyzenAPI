-- Lua provided by SkyAPI 
-- Game: Rising Noracam
addappid(1526090)
addappid(1526091, 1, "06ca766c1ec5eb6fccdc5bca075fc470a630b59216651f6b20e553e68d79e485")
