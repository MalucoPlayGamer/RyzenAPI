-- Lua provided by RyzenAPI
-- Game: Game: Lilly and Sasha: Curse of the Immortals

-- MAIN APPLICATION
addappid(364270)
-- Game: addappid(364270)

-- MAIN APP DEPOTS / PACKAGES
addappid(364271, 1, "8907f9c6bbd3cf37b4d96c289382d9a09dabbd47c9a474c4a4606ccd2e6c0ffe")
