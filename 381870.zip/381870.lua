-- Lua provided by RyzenAPI
-- Game: 381870

-- MAIN APPLICATION
addappid(381870)
-- Game: addappid(381870)

-- MAIN APP DEPOTS / PACKAGES
addappid(381871, 1, "e267195aa7153d57bc8c2f591b3da2d1732cf515bbcb58e856644841563b7da8")
