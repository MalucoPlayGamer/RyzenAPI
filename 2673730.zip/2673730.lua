-- Lua provided by RyzenAPI
-- Game: Game: A ARMY BASE

-- MAIN APPLICATION
addappid(2673730)
addappid(2673740)
-- Game: addappid(2673730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673731, 1, "c125a947cf528f4e0555dec603d19e8d749e53e969b2c3d79400129902ea491d")
