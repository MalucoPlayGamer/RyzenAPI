-- Lua provided by RyzenAPI 
-- Game: AppID 549810
addappid(549810)
addappid(549811, 1, "6824ce770b5a9b331a4ff0e6bd4a2c2115080d5923429309e9540d65a442ae93")
addappid(549812, 1, "43543f4b60b45c029e1204ca78f7edfb41a13d26de20d971ce9794ad3da3bd88")
addappid(576350)
addappid(576351)
