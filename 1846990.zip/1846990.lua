-- Lua provided by RyzenAPI
-- Game: Honored

-- MAIN APPLICATION
addappid(1846990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1846991, 1, "b8cce0d77a6f5a6194950adb8e9b262a531f7b6904eb32de42298b60f14c9544")

