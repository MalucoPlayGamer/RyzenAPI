-- Lua provided by SkyAPI 
-- Game: Honored
addappid(1846990)
addappid(1846991, 1, "b8cce0d77a6f5a6194950adb8e9b262a531f7b6904eb32de42298b60f14c9544")
