-- Lua provided by RyzenAPI
-- Game: addappid(3343770)

-- MAIN APPLICATION
addappid(3343770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343771, 1, "fb8bba1ded9a299dff09df95e8629bd2a2b8391862452de0f870150347e16d22")
