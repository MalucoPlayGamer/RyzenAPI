-- Lua provided by RyzenAPI 
-- Game: Silent Hunter® III
addappid(15210)
addappid(15211, 1, "aec872aaa2937dbfc87aaf4d7c7eaf41c39032e2f589a83437b77b2aa99fa1bc")
