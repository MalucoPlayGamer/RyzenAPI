-- Lua provided by RyzenAPI
-- Game: 15210

-- MAIN APPLICATION
addappid(15210)
-- Game: addappid(15210)

-- MAIN APP DEPOTS / PACKAGES
addappid(15211, 1, "aec872aaa2937dbfc87aaf4d7c7eaf41c39032e2f589a83437b77b2aa99fa1bc")
