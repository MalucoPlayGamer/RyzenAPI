-- Lua provided by RyzenAPI
-- Game: 01-【非必须品】逝3+逝外50元充值

-- MAIN APPLICATION
addappid(1110630)
-- Game: addappid(1110630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110630,0,"ba36707107aa14dcda458c7c6ca79c91d4116ce9cd78e2f1613b636ea8e943a7")
