-- Lua provided by RyzenAPI
-- Game: Game: A Very Merry Nightmare

-- MAIN APPLICATION
addappid(3419950)
-- Game: addappid(3419950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419951, 1, "ae513748db593e54c947c06439ffb186f82522115b8a76d117b59e9f79b8450d")
