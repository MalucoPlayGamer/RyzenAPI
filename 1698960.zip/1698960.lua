-- Lua provided by RyzenAPI
-- Game: Project Kat - Paper Lily Prologue

-- MAIN APPLICATION
addappid(1698960)

