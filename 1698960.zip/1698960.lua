-- Lua provided by RyzenAPI
-- Game: Project Kat - Paper Lily Prologue

-- MAIN APPLICATION
addappid(1698960)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2319990)
