-- Lua provided by RyzenAPI
-- Game: Parkur 44 Demo

-- MAIN APPLICATION
addappid(1669520)
-- Game: addappid(1669520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669521, 1, "83c8436734c8648147a0282a6d54a4246e99d6ddb0d6f65da192463a3d789eac")
