-- Lua provided by SkyAPI 
-- Game: Parkur 44 Demo
addappid(1669520)
addappid(1669521, 1, "83c8436734c8648147a0282a6d54a4246e99d6ddb0d6f65da192463a3d789eac")
