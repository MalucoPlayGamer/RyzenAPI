-- Lua provided by RyzenAPI
-- Game: addappid(3454200)

-- MAIN APPLICATION
addappid(3454200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454201, 1, "d3585408ffa0e1b8e25ac678737212547b2bac729e03dfb8f10f4c842cfb345f")
