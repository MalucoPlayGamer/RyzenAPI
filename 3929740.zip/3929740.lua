-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Splinter Cell: Pandora Tomorrow

-- MAIN APPLICATION
addappid(4103010) -- DLC 4103010

-- MAIN APP DEPOTS / PACKAGES
addappid(3929740, 1, "559ddc9cf6d215f19595a692925d497adb2bfefea272b59aa894965652fa0cb2")
addappid(3929741, 1, "b2c87c8501ea6789d1e9e8a0f45da5cacdd90b685f0da3d710485e82945d1b57") -- (windows)
addappid(3929742, 1, "2892178fb39e7761dc3e49ac7d3bb6f7bc0f8309ca2543aaf578f7de29cfb95e") -- English (windows)
addappid(3929743, 1, "7b7c06a30aedb97951ba922fa00ee3ad58c6a03a15608b0c058a80fb1d52b778") -- French (windows)
addappid(3929744, 1, "b8138faa0fbf89fe1ff1d717986d305b462dca6d2e0f69eecbf41cbf4b11e3ed") -- Spanish (windows)
addappid(3929745, 1, "eff0a6451e562e1e47889ea7a32209e4a2dfc91b959097b3b62ff544af8e49a9") -- German (windows)
addappid(3929746, 1, "db711b7327d3da24fef76d194f8843f7b01359a552d1378e6fa018b234c8bc05") -- Italian (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
