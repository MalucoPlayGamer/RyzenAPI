-- Lua provided by RyzenAPI
-- Game: Outshine

-- MAIN APPLICATION
addappid(1288410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288412,0,"8e93de9550733121cd06c68c17220b700006a764d0f09d597c66addf4fb90e83")

