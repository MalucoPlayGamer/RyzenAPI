-- Lua provided by RyzenAPI
-- Game: AppID 1316560

-- MAIN APPLICATION
addappid(1316560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316561, 1, "d38d5e226bb3b24ed6b221131543747b7a67d99ac8cb7e6f43c3312071ecc6cb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1545980)
