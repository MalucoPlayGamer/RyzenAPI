-- Lua provided by RyzenAPI
-- Game: Otaku's Rage: Waifu Strikes Back

-- MAIN APPLICATION
addappid(1316560)
addappid(1545980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316561, 1, "d38d5e226bb3b24ed6b221131543747b7a67d99ac8cb7e6f43c3312071ecc6cb")
