-- 3976560's Lua and Manifest Created by Hubcap Manifest
-- Stellara Vanguard
-- Created: August 17, 2026 at 14:21:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3976560) -- Stellara Vanguard
-- MAIN APP DEPOTS
addappid(3976561, 1, "1abb8e3f7fd0f418b228a4825d24c1223a0c7c4f26c9d272b2118b2440371df7") -- Depot 3976561
setManifestid(3976561, "2350228479678445105", 27069573)