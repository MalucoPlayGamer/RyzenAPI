-- Lua provided by RyzenAPI
-- Game: Stellara Vanguard

-- MAIN APPLICATION
addappid(3976560) -- Stellara Vanguard

-- MAIN APP DEPOTS / PACKAGES
addappid(3976561, 1, "1abb8e3f7fd0f418b228a4825d24c1223a0c7c4f26c9d272b2118b2440371df7") -- Depot 3976561

