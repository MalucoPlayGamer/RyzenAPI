-- Lua provided by RyzenAPI
-- Game: U.F.O - Unfortunately Fortunate Organisms

-- MAIN APPLICATION
addappid(586320)

-- MAIN APP DEPOTS / PACKAGES
addappid(586321, 1, "393b4a87201e0a30b9b8625cf25f902f5a65e96edfdcb2b530416056a757a0dc")
addappid(586322, 1, "14c8cc0f95cc387a9a35ba1b217c5bb82b0e018d70aaeddd7b3b613cb2c80210")
addappid(586323, 1, "aafb94b94a96a6250087e295d8429a78cf24f63db5312ae332e2ea73d489bb88")
