-- Lua provided by RyzenAPI
-- Game: AppID 413480

-- MAIN APPLICATION
addappid(413480)

-- MAIN APP DEPOTS / PACKAGES
addappid(413481, 1, "684948fd81daa2f177d7b0e5ef5dada889f56e7b982063c0a58c7d824b41f284")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
