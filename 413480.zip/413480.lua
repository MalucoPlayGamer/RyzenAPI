-- Lua provided by RyzenAPI
-- Game: addappid(413480)

-- MAIN APPLICATION
addappid(413480)

-- MAIN APP DEPOTS / PACKAGES
addappid(413481, 1, "684948fd81daa2f177d7b0e5ef5dada889f56e7b982063c0a58c7d824b41f284")
