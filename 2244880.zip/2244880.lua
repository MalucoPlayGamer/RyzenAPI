-- Lua provided by RyzenAPI
-- Game: Fantasy Jigsaw Puzzles

-- MAIN APPLICATION
addappid(2244880)

