-- Lua provided by RyzenAPI
-- Game: Fantasy Jigsaw Puzzles

-- MAIN APPLICATION
addappid(2244880)
addappid(2246690)
addappid(2246691)
addappid(2255340)
addappid(2281640)
addappid(2281641)
addappid(2285900)
addappid(2301840)
addappid(2301841)
addappid(2301842)
addappid(2894030)
addappid(2894040)
addappid(2894050)
addappid(2894060)

