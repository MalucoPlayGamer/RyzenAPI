-- Lua provided by RyzenAPI
-- Game: War Girl Demo

-- MAIN APPLICATION
addappid(1323680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323681, 1, "e693a33e55d7bcadaa9ed24b770a1f4e9c06c9af420d2d79112c6127fa2cdd5c")

