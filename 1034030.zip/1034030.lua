-- Lua provided by SkyAPI 
-- Game: AppID 1034030
addappid(1034030)
addappid(1034031, 1, "cf1178f4ac3757632157a710ea4098941570557a1eb7a6b3ba2d19b93939ad5d")
