-- Lua provided by RyzenAPI
-- Game: AppID 1034030

-- MAIN APPLICATION
addappid(1034030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034031, 1, "cf1178f4ac3757632157a710ea4098941570557a1eb7a6b3ba2d19b93939ad5d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
