-- Lua provided by RyzenAPI
-- Game: Game: AppID 1034030

-- MAIN APPLICATION
addappid(1034030)
-- Game: addappid(1034030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034031, 1, "cf1178f4ac3757632157a710ea4098941570557a1eb7a6b3ba2d19b93939ad5d")
