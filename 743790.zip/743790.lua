-- Lua provided by RyzenAPI
-- Game: Battle Chef Brigade - Soundtrack

-- MAIN APPLICATION
addappid(743790)

-- MAIN APP DEPOTS / PACKAGES
addappid(743790,0,"f336413784469f8ca7e7d482e09c239d21243f96d2585bcda8d761c9a60b9a72")
