-- Lua provided by RyzenAPI
-- Game: City Z

-- MAIN APPLICATION
addappid(2245750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245751, 1, "aefe6ee0797aed461360b8886f49fffedce9cc37c373f8d81ed0627805b5a702")
