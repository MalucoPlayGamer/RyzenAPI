-- Lua provided by RyzenAPI
-- Game: 938000

-- MAIN APPLICATION
addappid(938000)
-- Game: addappid(938000)

-- MAIN APP DEPOTS / PACKAGES
addappid(938001, 1, "fd448180cd05083002ee7c9a0d803df32bc3a09fa6b3f6faf41b0bda94317a75")
