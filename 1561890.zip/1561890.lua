-- Lua provided by RyzenAPI 
-- Game: Recursive Ruin
addappid(1561890)
addappid(1561891, 1, "a7003e26de988ab5fe4a3b27aec62146f731b4e776495c415d3392bff34cc3ea")
