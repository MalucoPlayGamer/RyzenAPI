-- Lua provided by RyzenAPI
-- Game: Recursive Ruin

-- MAIN APPLICATION
addappid(1561890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1561891, 1, "a7003e26de988ab5fe4a3b27aec62146f731b4e776495c415d3392bff34cc3ea")

