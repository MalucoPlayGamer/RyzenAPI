-- Lua provided by RyzenAPI
-- Game: addappid(603060)

-- MAIN APPLICATION
addappid(603060)

-- MAIN APP DEPOTS / PACKAGES
addappid(603061, 1, "e6318ab9ba2d02016b10df3dcbf86d260f4d419f5c735eb41843c74ed2b16d5f")
addappid(603062, 1, "2174e9a4fce25cf962ca1aeb4a35a2cbdb0e74b4d25029d415350ff9b442598f")
addappid(603063, 1, "6b670385f73db055f545946ea479e11bce9d16f8b98dfa0240ea6710fd91eebc")
