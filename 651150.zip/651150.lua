-- Lua provided by SkyAPI 
-- Game: Quantum League
addappid(651150)
addappid(651151, 1, "3ab7b1a1f384fc3ac5a27ff627725e5d8c0e2c837ab350c9677430d00d37a919")
