-- Lua provided by RyzenAPI
-- Game: Quantum League

-- MAIN APPLICATION
addappid(651150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(651151, 1, "3ab7b1a1f384fc3ac5a27ff627725e5d8c0e2c837ab350c9677430d00d37a919")

