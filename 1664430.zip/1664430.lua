-- Lua provided by RyzenAPI
-- Game: Game: AppID 1664430

-- MAIN APPLICATION
addappid(1664430)
-- Game: addappid(1664430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664431, 1, "28847d75a16b00f7894ada77055a00fe14472e212321d90d2c56f4b7cb68486d")
