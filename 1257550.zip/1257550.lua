-- Lua provided by RyzenAPI
-- Game: Game: Mercenary Skirmish

-- MAIN APPLICATION
addappid(1257550)
-- Game: addappid(1257550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257551, 1, "e1a76cd6f4a61f77de42418083051112466f471dc0072e0e3f3848d74d12db8d")
