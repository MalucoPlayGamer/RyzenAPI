-- Lua provided by RyzenAPI
-- Game: Human Farm : Investigation :

-- MAIN APPLICATION
addappid(3953160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3953162, 1, "09bf58da01f4a536434ec0a447e1ea79c200109bdf20c754c4916afe31b4a656") -- English (windows)

