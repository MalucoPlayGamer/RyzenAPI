-- Generated with Luie @ https://lua.tools/
-- 3953160 - Human Farm : Investigation :
-- Generated 2026-08-22 23:51:54 UTC
-- # Depots (Total/DLC/Shared): 4/0/0

-- Main AppID
addappid(3953160)

-- Main Depots
addappid(3953162, 1, "09bf58da01f4a536434ec0a447e1ea79c200109bdf20c754c4916afe31b4a656") -- English (windows)
setManifestid(3953162, "294571912678865610", 1017093374)

-- Missing Depots (We don't have the keys yet lol): 3953161, 3953163, 3953164
