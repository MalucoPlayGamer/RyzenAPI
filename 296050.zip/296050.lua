-- Lua provided by RyzenAPI 
-- Game: Battlepaths
addappid(296050)
addappid(296051, 1, "0605bff36d42b0d64a6dce6c53ea1e845805150b0e07ce3906411e2a960e2e1f")
addappid(296052, 1, "0697c31ea1cdc3c6bab51b791c90431232032e8526933c4d275b7a37d56bcf35")
addappid(322480, 0, "f86b646daa57a2ed679ea46bf1d5546196cbd53e70e44978d633cab8bd4498da")
