-- Lua provided by RyzenAPI
-- Game: Hatsune Miku Logic Paint S+

-- MAIN APPLICATION
addappid(3446190)
addappid(4039650)
addappid(4459270)
addappid(4740380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446191, 1, "031d694c3f67367d65509263e3da402e85fc81986f659310cdd983b0ce26a2fd")

