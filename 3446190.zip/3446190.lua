-- Lua provided by RyzenAPI
-- Game: Game: AppID 3446190

-- MAIN APPLICATION
addappid(3446190)
-- Game: addappid(3446190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446191, 1, "031d694c3f67367d65509263e3da402e85fc81986f659310cdd983b0ce26a2fd")
