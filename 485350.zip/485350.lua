-- Lua provided by RyzenAPI
-- Game: addappid(485350)

-- MAIN APPLICATION
addappid(485350)

-- MAIN APP DEPOTS / PACKAGES
addappid(485351, 1, "47bcac8e89045a95c0fb0de6cae9cda382584af46d5ed4d8df1ca084129af560")
addappid(485352, 1, "bcec476b9dc582b68294c11d2d710b90028825a6eb31bd2ede84e1625200bcec")
addappid(485353, 1, "98d42106ca291faf4f31d3add48f49bc8e3bc78f93efadab820ca0206493aed8")
addappid(485354, 1, "12d4a3161ed6c818dcf939d5a9722eb74a5960441984cdb01b88b7bdc65f84de")
addappid(485355, 1, "e933d75f997d6eac28828fb5a0935bb615baeca1681190b92a7ba86414af1e02")
addappid(512670, 0, "345354b5e8d17db6c22a0df956aea0ed38d6a3b9a4b5c36189b8cbe2f2f78547")
