-- Lua provided by RyzenAPI
-- Game: Game: MILF Conditioning

-- MAIN APPLICATION
addappid(1924680)
-- Game: addappid(1924680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924681, 1, "0d0b4560e42f523b6a3b3411a51bf0eda747c9963aaa8e65a9bde440a4f9536f")
