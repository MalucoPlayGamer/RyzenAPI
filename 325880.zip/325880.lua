-- Lua provided by RyzenAPI
-- Game: addappid(325880)

-- MAIN APPLICATION
addappid(325880)

-- MAIN APP DEPOTS / PACKAGES
addappid(325881, 1, "f7d8669a772c9d718dc79363d5d0554cb22cb2f6574980c9e749d2f6c0fc5da5")
