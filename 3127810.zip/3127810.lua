-- Lua provided by RyzenAPI
-- Game: Game: AppID 3127810

-- MAIN APPLICATION
addappid(3127810)
-- Game: addappid(3127810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127811, 1, "df5c735331771c60cd8bf97f60d27f4074a3688c752fa282ed52bbed41c4d477")
