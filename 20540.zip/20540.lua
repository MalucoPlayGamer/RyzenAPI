-- Lua provided by RyzenAPI 
-- Game: AppID 20540
addappid(20540)
addappid(20541, 1, "4e0f797f17530a0edd9c6567fc08ef28a5f43692f937d4ce5d159f9fd887d44d")
addappid(20542, 1, "b7eb0fd3eefe55d98287b5a11eae866f5ef4094bc046467b3836726f8b1c9cce")
addappid(20543, 1, "3cf00b17817d7a6c1cfeb8dc2b111871c9a2550b53c4faff5908ab04854f0624")
addappid(20544, 1, "a1b29a325a89ea10e5e6983edbc7b3489d2a0c23bf88713df34133c4f9aadeff")
addappid(20545, 1, "beab3b7e9ad5cffcf81d31e648077ff02b08bb2b5a1647ccb497444ed5b1adac")
