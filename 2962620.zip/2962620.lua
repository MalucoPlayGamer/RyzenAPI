-- Lua provided by RyzenAPI
-- Game: Sift Heads Legendary Pack

-- MAIN APPLICATION
addappid(2962620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962621, 1, "39449b1d13b254ca6817995fe37acab9071109fb740ef5a95da41cd8dee1099d")
