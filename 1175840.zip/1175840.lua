-- Lua provided by RyzenAPI
-- Game: Whateverland

-- MAIN APPLICATION
addappid(1175840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175841, 1, "9248fd66b18bc688ac612d1c0587d108595ed05245ba21381ce830fe996292f1")
