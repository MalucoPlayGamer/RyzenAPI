-- Lua provided by RyzenAPI
-- Game: Origin Unknown

-- MAIN APPLICATION
addappid(2323570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2323571, 1, "fa4c321a41827e9cfcac48eb51ceff1ba44ac2b3d4521bafddc3c4dfd8c5b19d")

