-- Lua provided by RyzenAPI
-- Game: Origin Unknown

-- MAIN APPLICATION
addappid(2323570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323571, 1, "fa4c321a41827e9cfcac48eb51ceff1ba44ac2b3d4521bafddc3c4dfd8c5b19d")

