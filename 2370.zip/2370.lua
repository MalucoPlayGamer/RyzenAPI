-- Lua provided by RyzenAPI
-- Game: addappid(2370)

-- MAIN APPLICATION
addappid(2370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371, 1, "2293c8f2afa3c42e383edb637edf711fa5755dfeb04314c1a77120598db01cfd")
