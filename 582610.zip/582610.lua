-- Lua provided by RyzenAPI
-- Game: Z-End

-- MAIN APPLICATION
addappid(582610)

-- MAIN APP DEPOTS / PACKAGES
addappid(582611, 1, "41e4dddbed24ff085e8cf56d5a83d628393e320505cf3d47dc0db5436d39b40d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
