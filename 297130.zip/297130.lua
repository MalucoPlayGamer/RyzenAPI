-- Lua provided by RyzenAPI
-- Game: addappid(297130)

-- MAIN APPLICATION
addappid(297130)

-- MAIN APP DEPOTS / PACKAGES
addappid(297131, 1, "5d1865babbb56bdb4503798013b29ef045c5f9ca6c11b3887bb2f9db65dcc3ad")
addappid(297132, 1, "76b3a34ee344c915955cdf055423323f209aa1f8d8b3f84dbd2df57cf2fa69cf")
addappid(297133, 1, "a7ab653d6ada970b4312a1cc3867bb52e434773b8a11e3cf40239bf7c1cc425b")
