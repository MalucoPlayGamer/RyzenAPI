-- Lua provided by RyzenAPI
-- Game: Swipecart

-- MAIN APPLICATION
addappid(295930)

-- MAIN APP DEPOTS / PACKAGES
addappid(295931, 1, "662ba5c2c2b1d0de8246a220980ac32824ec8a3908f81fb8745e308c060a32e1")

