-- Lua provided by RyzenAPI
-- Game: addappid(3101230)

-- MAIN APPLICATION
addappid(3101230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101231, 1, "9bd13e044af52db77039e2397c0db6bcd73af4ca72ca81a2e574a7e1bc5c9747")
addappid(3275340, 0, "6a4a01028a95aa8dffea3b6027edb86e7192ac70e9c6c44d6207483fa3bc9792")
