-- Lua provided by RyzenAPI
-- Game: Dating Simulator

-- MAIN APPLICATION
addappid(1709080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709081, 1, "e6825b0dbe7436afc97f8281e1db718cbcde585fd54576b6e83eb69a4f1a941c")
