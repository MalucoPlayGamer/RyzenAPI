-- Lua provided by RyzenAPI
-- Game: addappid(469720)

-- MAIN APPLICATION
addappid(469720)
addappid(1091060)

-- MAIN APP DEPOTS / PACKAGES
addappid(469721, 1, "182e9a14710c9b3fd2ffee93c0f70693d514f27ee5a067f5bc924ec0487444cc")
