-- Lua provided by RyzenAPI
-- Game: Periapsis: Gravity Slingshot

-- MAIN APPLICATION
addappid(4520400) -- Periapsis: Gravity Slingshot
addappid(4520620) -- Periapsis Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4520401, 1, "643419dffa7cf6f51ba9d62efdaad3ef298ab36dc04e47c257cfc51285933866") -- Depot 4520401
addappid(4520402, 1, "34e7552bea4a72dcf7eec53533b07e130872e2ce03464c84919fbfce13a3f3d5") -- Depot 4520402

