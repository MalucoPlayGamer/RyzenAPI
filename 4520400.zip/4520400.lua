-- 4520400's Lua and Manifest Created by Hubcap Manifest
-- Periapsis: Gravity Slingshot
-- Created: August 07, 2026 at 23:04:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4520400) -- Periapsis: Gravity Slingshot
-- MAIN APP DEPOTS
addappid(4520401, 1, "643419dffa7cf6f51ba9d62efdaad3ef298ab36dc04e47c257cfc51285933866") -- Depot 4520401
setManifestid(4520401, "5687936527234963720", 2162475384)
addappid(4520402, 1, "34e7552bea4a72dcf7eec53533b07e130872e2ce03464c84919fbfce13a3f3d5") -- Depot 4520402
setManifestid(4520402, "2866892684344628046", 2321538577)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4520620) -- Periapsis Supporter Pack