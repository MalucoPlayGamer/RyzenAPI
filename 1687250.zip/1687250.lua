-- Lua provided by RyzenAPI
-- Game: ARIA: Genesis

-- MAIN APPLICATION
addappid(1687250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687251, 1, "6403c78c6542adffb5e5b40886c340dea73e120264b19fdcd908dbe5a85ca7c8")
