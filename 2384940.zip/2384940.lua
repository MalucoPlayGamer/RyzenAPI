-- Lua provided by RyzenAPI
-- Game: 2384940

-- MAIN APPLICATION
addappid(2384940)
-- Game: addappid(2384940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384941, 1, "43e031d3e796eae84500e85e16ee7e822b72fca7410b1d97960a239138e96ae5")
