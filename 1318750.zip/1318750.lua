-- Lua provided by RyzenAPI
-- Game: 18 Wheels of Steel: Hard Truck

-- MAIN APPLICATION
addappid(1318750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1318751, 1, "df6771e452ebcb50400b51850583f662a55b19e3527391621ed5ec482691774b")
