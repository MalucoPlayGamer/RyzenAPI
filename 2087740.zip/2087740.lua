-- Lua provided by RyzenAPI
-- Game: Game: Capcom Arcade 2nd Stadium: Mini-Album Track 8 - A.K.A Magic Sword - Road to the Tower (Round 1)

-- MAIN APPLICATION
addappid(2087740)
-- Game: addappid(2087740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087741, 1, "4c4513e06d6284766cfec28bb54fcd7e7159b70d641b0d0fae4c7d64d1f15ca0")
addappid(2087742, 1, "ad235c7c6d5be366719f624c5d58704320464e646c1a8b1845816a5e55bd7e8e")
addappid(2087743, 1, "ba6bd29d16ebfbad81d947348b95f0799ee116b7b2d1a1782f8ae1e8c853b66f")
addappid(2087744, 1, "0e9e8da4877be620d4cdd3989e4e22806bae068397aa492f89d28e718f1fefe4")
addappid(2087745, 1, "86ce9631b71c8ad3da3a290658ba6d3060ce716377ae00d7aaed6e193ed12d44")
addappid(2087746, 1, "8bbb14df480f1bb9620b8bde9500b1f032869fb246e5a54b73d1e2d4e09b6c5f")
