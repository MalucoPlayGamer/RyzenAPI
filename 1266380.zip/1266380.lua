-- Lua provided by RyzenAPI 
-- Game: AppID 1266380
addappid(1266380)
addappid(1266381, 1, "344cf598841c45fd214dc65399c994aef28378983df61957d0e7448862b6352c")
