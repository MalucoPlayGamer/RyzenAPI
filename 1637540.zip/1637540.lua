-- Lua provided by RyzenAPI
-- Game: The Village

-- MAIN APPLICATION
addappid(1637540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637541, 1, "dd6867355d3e348520b83e52dbc2baf6799626fcfa980d8d20437bfb7ea8a7ed")

