-- Lua provided by RyzenAPI
-- Game: Miazma or the Devil's Stone

-- MAIN APPLICATION
addappid(774141)

-- MAIN APP DEPOTS / PACKAGES
addappid(774142, 1, "0fc548d307c53a57ab0cf63d5fcc8be1e6d083b0d3d477e78f95ea472dccf67c")
