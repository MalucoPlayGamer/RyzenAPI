-- Lua provided by RyzenAPI
-- Game: addappid(763930)

-- MAIN APPLICATION
addappid(763930)

-- MAIN APP DEPOTS / PACKAGES
addappid(763931, 1, "b9d3b4af15552efc1ebcd87343aa8aa210b0ea9d84e475faf7f88f9b9dc3a8b4")
