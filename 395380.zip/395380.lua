-- Lua provided by RyzenAPI
-- Game: Game: ANKI

-- MAIN APPLICATION
addappid(395380)
-- Game: addappid(395380)

-- MAIN APP DEPOTS / PACKAGES
addappid(395381, 1, "f003e0005b560d49850519265a29f54e8610485dc4932deebd947840779a6a7a")
