-- Lua provided by RyzenAPI 
-- Game: ANKI
addappid(395380)
addappid(395381, 1, "f003e0005b560d49850519265a29f54e8610485dc4932deebd947840779a6a7a")
