-- Lua provided by RyzenAPI
-- Game: Wizarre

-- MAIN APPLICATION
addappid(2614360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614361, 1, "aa58b4ce21630f778c0baf3db63aba242a2f11026ab96200e71abd89ef1b8ff2")
