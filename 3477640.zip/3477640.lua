-- Lua provided by RyzenAPI
-- Game: Rowdy Rascals Demo

-- MAIN APPLICATION
addappid(3477640)
-- Game: addappid(3477640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477641, 1, "8f1f28708d3700d6188e64de4d8f27c36546dd59fae8071c47f5f5832903e108")
