-- Lua provided by RyzenAPI
-- Game: Stormgate

-- MAIN APPLICATION
addappid(2012510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012511, 1, "50377f4e0ebc8c49d0f5f557620f904411b78fbab190a3d88e50c8cc3a346d10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2804060)
addappid(2804070)
addappid(2804080)
addappid(3909130)
addappid(3940550)
