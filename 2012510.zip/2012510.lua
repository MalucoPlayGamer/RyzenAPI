-- Lua provided by RyzenAPI
-- Game: Stormgate

-- MAIN APPLICATION
addappid(2012510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012511, 1, "50377f4e0ebc8c49d0f5f557620f904411b78fbab190a3d88e50c8cc3a346d10")

