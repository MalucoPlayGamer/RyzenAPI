-- Lua provided by RyzenAPI
-- Game: The Rule of Land: Pioneers

-- MAIN APPLICATION
addappid(1248800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248801, 1, "7ba6a754fd7e4d2cf1a9fa76d69909f997a204aa5fad9eb381fddfc6c087f956")

