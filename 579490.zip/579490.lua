-- Lua provided by RyzenAPI
-- Game: RUSH: A Disney • PIXAR Adventure

-- MAIN APPLICATION
addappid(579490)

-- MAIN APP DEPOTS / PACKAGES
addappid(579491, 1, "c89817fe29e662554faff8f563ad10868c31cb1add60c6aa960179ca6a032256")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
