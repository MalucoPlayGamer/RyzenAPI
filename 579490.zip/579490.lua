-- Lua provided by RyzenAPI
-- Game: 579490

-- MAIN APPLICATION
addappid(579490)
-- Game: addappid(579490)

-- MAIN APP DEPOTS / PACKAGES
addappid(579491, 1, "c89817fe29e662554faff8f563ad10868c31cb1add60c6aa960179ca6a032256")
