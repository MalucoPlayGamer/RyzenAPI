-- Lua provided by RyzenAPI
-- Game: Zompiercer

-- MAIN APPLICATION
addappid(1262460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262461, 1, "ef1bd3bf92e13f3c71eac98361ba5162c312de1b0049a4bae51ff402524cbd99")

