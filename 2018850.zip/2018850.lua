-- Lua provided by RyzenAPI
-- Game: Game: Fire Truck Simulator

-- MAIN APPLICATION
addappid(2018850)
-- Game: addappid(2018850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018851, 1, "522d8fae9a17dd2775ceeda289a604138ce9606438735a812a61b9585b612e54")
