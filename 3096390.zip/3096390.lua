-- Lua provided by RyzenAPI
-- Game: SanGuos3

-- MAIN APPLICATION
addappid(3096390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096391, 1, "b9c684c59f03fcd29c30a56c66f1a54b6e4fac91fa2e31b5e9b98189dc2e39d5")
