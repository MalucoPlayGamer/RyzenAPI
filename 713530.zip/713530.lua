-- Lua provided by RyzenAPI
-- Game: ARMORED KITTEN

-- MAIN APPLICATION
addappid(713530)

-- MAIN APP DEPOTS / PACKAGES
addappid(713531, 1, "dfe2f140fb62d3b31ff974a99e000665b2d585e20dbd298cfba245eeac1732cf")
