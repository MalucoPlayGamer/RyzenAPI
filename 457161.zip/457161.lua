-- Lua provided by RyzenAPI
-- Game: Rocket League: Official Game Soundtrack, Vol. 2

-- MAIN APPLICATION
addappid(457161)

-- MAIN APP DEPOTS / PACKAGES
addappid(457161,0,"abd9ed0d2c905ee4f2ad47042f06bf963060e76db1a16d0a5a263c085a5b624e")
