-- Lua provided by RyzenAPI
-- Game: BlazeRush

-- MAIN APPLICATION
addappid(302710)
addappid(2934580)

-- MAIN APP DEPOTS / PACKAGES
addappid(302711, 1, "6bfc23663c95cb76be822f390402673c479ec96572aea3c5feff75e7894bf64e")
addappid(302712, 1, "3a3f3687ddd5a769a007fc1532e6a5f51866522b9b72551bda684028c563def4")
addappid(302713, 1, "87b81d62b5884c6f1230e2935866f67717784e879392a9b078515d4648f9e68b")
addappid(302714, 1, "19966858096a369057d12d8ad69fe0ac227ce1e6cef58781b37cdc573d42d671")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
