-- Lua provided by RyzenAPI
-- Game: Caromble!

-- MAIN APPLICATION
addappid(347660)

-- MAIN APP DEPOTS / PACKAGES
addappid(347661, 1, "e35efb593fe8201889d3bf8ecd9c44c6d354d1cdcd0f01b0cc97a086869e2c41")
addappid(347662, 1, "3d7c299b9a20ed6ded251a93ed747d100548411a3422eb1429d2ae12e801a77d")
addappid(347663, 1, "895723492c4a63af647d4abcf841f62ac0c9a82d9126aefec68bea5fa6813f9d")
addappid(347664, 1, "4fa76d407e4aa3fddc64e5bc8b3d86134c3a161666e7091de1e7d3253e0197ba")
