-- Lua provided by RyzenAPI
-- Game: Caromble!

-- MAIN APPLICATION
addappid(347660)

-- MAIN APP DEPOTS / PACKAGES
addappid(347661, 1, "e35efb593fe8201889d3bf8ecd9c44c6d354d1cdcd0f01b0cc97a086869e2c41")
addappid(347662, 1, "3d7c299b9a20ed6ded251a93ed747d100548411a3422eb1429d2ae12e801a77d")
addappid(347663, 1, "895723492c4a63af647d4abcf841f62ac0c9a82d9126aefec68bea5fa6813f9d")
addappid(347664, 1, "4fa76d407e4aa3fddc64e5bc8b3d86134c3a161666e7091de1e7d3253e0197ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
