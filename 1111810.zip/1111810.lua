-- Lua provided by SkyAPI 
-- Game: Sex Simulator
addappid(1111810)
addappid(1111811, 1, "a755856f37bfa0a1a9c1a3839b5ac8d8559ec8d2cc7a44f010d4a426bdb2c2ef")
