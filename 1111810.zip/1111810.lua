-- Lua provided by RyzenAPI
-- Game: Sex Simulator

-- MAIN APPLICATION
addappid(1111810)
-- Game: addappid(1111810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111811, 1, "a755856f37bfa0a1a9c1a3839b5ac8d8559ec8d2cc7a44f010d4a426bdb2c2ef")
