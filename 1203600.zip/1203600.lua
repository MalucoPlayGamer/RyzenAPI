-- Lua provided by RyzenAPI
-- Game: Zombie Slayers

-- MAIN APPLICATION
addappid(1203600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203601, 1, "6ee8c14096458dd3e879539f784e9db40d8005104b4efbee940fcd19049b8cd9")
