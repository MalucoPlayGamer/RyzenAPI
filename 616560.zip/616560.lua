-- Lua provided by RyzenAPI
-- Game: Ultimate Epic Battle Simulator

-- MAIN APPLICATION
addappid(616560)

-- MAIN APP DEPOTS / PACKAGES
addappid(616561, 1, "72bedf52e7a3e7e090b6cb6b1e9b27dfaf0b9677dfceaadaed4446f8be4ac28c")
