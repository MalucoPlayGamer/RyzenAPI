-- Lua provided by RyzenAPI
-- Game: Game: Shad'O

-- MAIN APPLICATION
addappid(215770)
-- Game: addappid(215770)

-- MAIN APP DEPOTS / PACKAGES
addappid(215771, 1, "60338ea1955f6901b34c7a8b1e01274bf818cd8a15f62c78f5daf5249d77a4eb")
addappid(215772, 0, "156893b20c99426087e93c05f82dfc3636357cb629a7a86ed701acd13457fb3b")
