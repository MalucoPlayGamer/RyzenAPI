-- Lua provided by RyzenAPI
-- Game: Game: AppID 509850

-- MAIN APPLICATION
addappid(509850)
-- Game: addappid(509850)

-- MAIN APP DEPOTS / PACKAGES
addappid(509851, 1, "60708df6667a46759b1126bebfa5c4a060898aeef88c810fc59efd8e3dc96a65")
addappid(542300, 0, "83dc3ac1c5111b3f8b428368a48ba7d5db644f0b8ef822480f8f26b7f05b09c5")
addappid(548070, 0, "09c972c9c185f3ad14a636990e78480cb4fa2f985988cfc0e490f681a396d4dd")
