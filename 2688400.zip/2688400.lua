-- Lua provided by RyzenAPI
-- Game: You Draw, I Guess

-- MAIN APPLICATION
addappid(2688400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688401, 1, "365e273fb164cd1c5486265f0faedbfdf7509cd225f056ebaaff07cfd50faf1a")

