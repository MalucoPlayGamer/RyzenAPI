-- Lua provided by RyzenAPI
-- Game: Game: ViruZ

-- MAIN APPLICATION
addappid(1553650)
-- Game: addappid(1553650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553651, 1, "c066d9f98241626c33a590014d43135f2c2b0e3a258e8f004102574bdd797ccb")
