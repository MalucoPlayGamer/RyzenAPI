-- Lua provided by SkyAPI 
-- Game: ViruZ
addappid(1553650)
addappid(1553651, 1, "c066d9f98241626c33a590014d43135f2c2b0e3a258e8f004102574bdd797ccb")
