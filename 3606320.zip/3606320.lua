-- Lua provided by RyzenAPI
-- Game: Feign - Deluxe Pack

-- MAIN APPLICATION
addappid(3606320)
-- Game: addappid(3606320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606320,0,"390826f306966ed2b9155a50c7dc5cd9c33fc32234ca00216a853fa4fd89b12f")
