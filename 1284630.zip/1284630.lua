-- Lua provided by RyzenAPI 
-- Game: AppID 1284630
addappid(1284630)
addappid(1284631, 1, "e543b72ddfc697550486e7eaf08e6588c28ba87032e67c24bf97d53d20f2cf22")
