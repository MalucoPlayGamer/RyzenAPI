-- Lua provided by RyzenAPI
-- Game: 送小鸡回家 sendchickenhome

-- MAIN APPLICATION
addappid(1284630)
-- Game: addappid(1284630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284631, 1, "e543b72ddfc697550486e7eaf08e6588c28ba87032e67c24bf97d53d20f2cf22")
