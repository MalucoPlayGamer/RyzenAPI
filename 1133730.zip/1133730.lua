-- Lua provided by RyzenAPI
-- Game: Second Galaxy

-- MAIN APPLICATION
addappid(1133730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1133731, 1, "122f66baf2d59853ef22f33728949e3dd23a2c0db2c5904ecd670c65d250602e")
