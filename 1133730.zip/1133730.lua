-- Lua provided by RyzenAPI 
-- Game: AppID 1133730
addappid(1133730)
addappid(1133731, 1, "122f66baf2d59853ef22f33728949e3dd23a2c0db2c5904ecd670c65d250602e")
