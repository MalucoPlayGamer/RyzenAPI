-- Lua provided by RyzenAPI
-- Game: Milling machine simulator Demo

-- MAIN APPLICATION
addappid(2949800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949801, 1, "398122efefd28825d94142d5927ba9e73429a27b3c39512b3053c872ce82bbca")
