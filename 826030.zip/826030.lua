-- Lua provided by RyzenAPI
-- Game: Game: BrainPower

-- MAIN APPLICATION
addappid(826030)
-- Game: addappid(826030)

-- MAIN APP DEPOTS / PACKAGES
addappid(826031, 1, "ebec638cce7bfd53ab28504cf3ba152981a949205301c4df19e10b79acbfd905")
addappid(826032, 1, "0f81d3340222dea79f5467403b67b2f4a70fa21c5b93fac9220210b74e8802a3")
addappid(826033, 1, "b0b774d104c67c61c425d02ece3b589994600f4ad0156a45ab70c0ae759993b7")
addappid(826034, 1, "16e891e842c049c090feeabdb1fedc7245e02f294ecf5c9aec1b81d3497a7081")
