-- Lua provided by RyzenAPI
-- Game: addappid(1762270)

-- MAIN APPLICATION
addappid(1762270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762271, 1, "6a5346f037de97c677bab3bb11ccb9fd6be4762072931de3434ce31c2c977d6b")
