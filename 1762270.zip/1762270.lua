-- Lua provided by RyzenAPI 
-- Game: Obama Boss Fight
addappid(1762270)
addappid(1762271, 1, "6a5346f037de97c677bab3bb11ccb9fd6be4762072931de3434ce31c2c977d6b")
