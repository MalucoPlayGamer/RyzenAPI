-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Adventure

-- MAIN APPLICATION
addappid(1949880)
addappid(2077980)
-- Game: addappid(1949880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949881, 1, "b1ba20b985513e1394697e848edae6f30edee89fb0ad1969a5ec76b9c71f1d22")
