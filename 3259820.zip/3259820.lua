-- Lua provided by RyzenAPI
-- Game: Alice's World Demo

-- MAIN APPLICATION
addappid(3259820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259821, 1, "b507966f06d52a4a501908ed16f7abdc87305dc68d9ce6ccb525f68c6771e890")
