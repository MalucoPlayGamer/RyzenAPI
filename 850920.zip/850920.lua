-- Lua provided by RyzenAPI
-- Game: Hypersonic Speed Girl / 超速少女

-- MAIN APPLICATION
addappid(850920)

-- MAIN APP DEPOTS / PACKAGES
addappid(850921,0,"aadfb16f2f1f73522783096bcc1b80994bf5d7ea924b68194e8bd08afd449f59")

