-- Lua provided by RyzenAPI
-- Game: SpaceMerc

-- MAIN APPLICATION
addappid(662610)

-- MAIN APP DEPOTS / PACKAGES
addappid(662611, 1, "ce552edc85f7635872ac099b9fc6d7088506700b682f5e332dd5a997a24f0fe3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
