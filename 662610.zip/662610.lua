-- Lua provided by RyzenAPI
-- Game: Game: SpaceMerc

-- MAIN APPLICATION
addappid(662610)
-- Game: addappid(662610)

-- MAIN APP DEPOTS / PACKAGES
addappid(662611, 1, "ce552edc85f7635872ac099b9fc6d7088506700b682f5e332dd5a997a24f0fe3")
