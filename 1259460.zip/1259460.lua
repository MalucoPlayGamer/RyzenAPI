-- Lua provided by RyzenAPI
-- Game: Game: AppID 1259460

-- MAIN APPLICATION
addappid(1259460)
-- Game: addappid(1259460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259461, 1, "b09573a738317ff0241ece0d420906dc45e4e1bc5da064a9161e42064321425a")
