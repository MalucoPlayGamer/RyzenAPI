-- Lua provided by RyzenAPI
-- Game: AppID 1259460

-- MAIN APPLICATION
addappid(1259460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259461, 1, "b09573a738317ff0241ece0d420906dc45e4e1bc5da064a9161e42064321425a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
