-- Lua provided by RyzenAPI
-- Game: Becoming Homeless: A Human Experience

-- MAIN APPLICATION
addappid(738100)

-- MAIN APP DEPOTS / PACKAGES
addappid(738101, 1, "dc6a1d45940e1873ba1815281f382746e7c7d8ad156b3ca8887432cd3014ee40")
