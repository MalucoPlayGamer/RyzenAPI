-- Lua provided by RyzenAPI
-- Game: addappid(1341531)

-- MAIN APPLICATION
addappid(1341531)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341531,0,"fdcc86c14d24619f24cff8bfba8ae84f57a357e4395e1a61d9e066664ba2a894")
