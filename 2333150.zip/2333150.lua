-- Lua provided by RyzenAPI
-- Game: Windswept Demo

-- MAIN APPLICATION
addappid(2333150)
-- Game: addappid(2333150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333151, 1, "1fbc38ba3df1f04f20e1f156b29508e9a35c901d2a2e04c03bf96c7e4ae20098")
