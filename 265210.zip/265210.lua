-- Lua provided by RyzenAPI
-- Game: 265210

-- MAIN APPLICATION
addappid(265210)
-- Game: addappid(265210)

-- MAIN APP DEPOTS / PACKAGES
addappid(265211, 1, "4fde4f2140be8113adf2a822574ad28dd4b5b617aeef089f2cc385c1d80219cf")
