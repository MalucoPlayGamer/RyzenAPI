-- Lua provided by RyzenAPI
-- Game: AppID 265210

-- MAIN APPLICATION
addappid(265210)

-- MAIN APP DEPOTS / PACKAGES
addappid(265211, 1, "4fde4f2140be8113adf2a822574ad28dd4b5b617aeef089f2cc385c1d80219cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
