-- Lua provided by RyzenAPI
-- Game: Platform Challenge

-- MAIN APPLICATION
addappid(830360)

-- MAIN APP DEPOTS / PACKAGES
addappid(830361,0,"53143180d2429a95d4a8b774a46230ddcd9f3eca647bcd26b07f2c24df1194de")

