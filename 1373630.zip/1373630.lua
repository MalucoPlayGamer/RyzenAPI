-- Lua provided by RyzenAPI
-- Game: 1373630

-- MAIN APPLICATION
addappid(1373630)
-- Game: addappid(1373630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373631, 1, "1c3d3d4c41bed4b607395eaed8e222249892662dc61aef7ec1cdec353f1f4aa9")
addappid(1373633, 1, "9574b22799bdd55eb673ffacf693dab8d4b04c66fe72e79fba92867ea6bc32e9")
