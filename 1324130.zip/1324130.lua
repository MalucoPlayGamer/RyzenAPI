-- Lua provided by RyzenAPI
-- Game: Game: Stranded: Alien Dawn

-- MAIN APPLICATION
addappid(1324130)
addappid(2123700)
addappid(2123701)
addappid(2123702)
addappid(2123703)
addappid(2123704)
addappid(2123705)
addappid(2123706)
addappid(2123708)
-- Game: addappid(1324130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324131, 1, "e9f2512dfd0963c3f27faf9a72be8a5872a3b80d66db2e5715ff16cdc6c4f4af")
addappid(1324132, 1, "f7770c35579f729c14e0f74c44189fa60b47dd357f81de7467ed6de3890017d2")
addappid(2104870, 0, "318b8fa6a758f4a92005093dbf28a7579b9e2fcae409f76cce8ca5275ba921ab")
addappid(2123707, 0, "b88ecffbb11e6b43a672131e71d1435ad0e2a7ead7d9870d570e00423d694aff")
