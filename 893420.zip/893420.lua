-- Lua provided by RyzenAPI
-- Game: Harvested

-- MAIN APPLICATION
addappid(893420)
-- Game: addappid(893420)

-- MAIN APP DEPOTS / PACKAGES
addappid(893421, 1, "95c2597939a029974181f54d3c5bdb64a1821fcb7a9c4279bbd0e83e6767f845")
