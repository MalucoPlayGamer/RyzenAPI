-- Lua provided by RyzenAPI
-- Game: Harvested

-- MAIN APPLICATION
addappid(893420)

-- MAIN APP DEPOTS / PACKAGES
addappid(893421, 1, "95c2597939a029974181f54d3c5bdb64a1821fcb7a9c4279bbd0e83e6767f845")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
