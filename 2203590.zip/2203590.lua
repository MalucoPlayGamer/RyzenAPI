-- Lua provided by SkyAPI 
-- Game: Tune in to the show Part 1
addappid(2203590)
addappid(2203591, 1, "9d2d1c92519bdb9d343fa842f0fbfb033dc04ccfab3921cd6afc07a8cf536d8f")
addappid(4221370)
