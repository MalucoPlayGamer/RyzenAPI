-- Lua provided by RyzenAPI
-- Game: Grapple Force Rena Demo

-- MAIN APPLICATION
addappid(798620)

-- MAIN APP DEPOTS / PACKAGES
addappid(798622,0,"f96b1e394b734fe36567e8a4dceb96d45413894692dc37e1eddd898539c3e0bf")
