-- Lua provided by RyzenAPI
-- Game: Game: Station 17

-- MAIN APPLICATION
addappid(1712490)
-- Game: addappid(1712490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712491, 1, "c633488a0c8780e2e9f534c62d845103fdde19ec825831798b138776d13f7f07")
