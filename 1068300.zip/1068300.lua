-- Lua provided by RyzenAPI
-- Game: Logitech VR Ink Driver

-- MAIN APPLICATION
addappid(1068300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068301, 1, "d9345d21f68b7bd598d9d38190977f040e799da6cc11a1298df4ef823660bf40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
