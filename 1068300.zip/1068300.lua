-- Lua provided by RyzenAPI
-- Game: 1068300

-- MAIN APPLICATION
addappid(1068300)
-- Game: addappid(1068300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068301, 1, "d9345d21f68b7bd598d9d38190977f040e799da6cc11a1298df4ef823660bf40")
