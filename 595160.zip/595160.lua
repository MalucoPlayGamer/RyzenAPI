-- Lua provided by RyzenAPI
-- Game: My Boyfriend – He loves me, he loves me not

-- MAIN APPLICATION
addappid(595160)

-- MAIN APP DEPOTS / PACKAGES
addappid(595161,0,"f0ef070a19315746d0278b1a5238f024120bb122b8deac2350d330b239c4668e")

