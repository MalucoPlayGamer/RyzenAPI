-- Lua provided by RyzenAPI
-- Game: 2666350

-- MAIN APPLICATION
addappid(2666350)
-- Game: addappid(2666350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666351, 1, "38e6fb312f2e140382c60aea628a3095fd0398aa6adc70fc5ee856ea2bf854ad")
