-- Lua provided by RyzenAPI 
-- Game: Very Scary Backrooms Game
addappid(2666350)
addappid(2666351, 1, "38e6fb312f2e140382c60aea628a3095fd0398aa6adc70fc5ee856ea2bf854ad")
