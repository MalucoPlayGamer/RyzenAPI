-- Lua provided by RyzenAPI
-- Game: Solar Raiders Demo

-- MAIN APPLICATION
addappid(2379270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379271, 1, "1709bf1d472e18112cd795c214b23108a36c592e08db2d6641dafe6ae8b803f5")
