-- Lua provided by RyzenAPI
-- Game: 1546950

-- MAIN APPLICATION
addappid(1546950)
-- Game: addappid(1546950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546951, 1, "e2f78051325b959afac53e1a1273bc24b5332b4157f60dc3a56f58d96a75b1fe")
