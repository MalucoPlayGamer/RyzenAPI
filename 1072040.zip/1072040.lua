-- Lua provided by RyzenAPI
-- Game: Panzer Corps 2

-- MAIN APPLICATION
addappid(1072040)
addappid(1233360)
addappid(1275430)
addappid(1351260)
addappid(1351261)
addappid(1438150)
addappid(1526010)
addappid(1652450)
addappid(1688110)
addappid(1938820)
addappid(2130950)
addappid(2393020)
addappid(2393021)
addappid(2711250)
addappid(3023770)
addappid(3167270)
addappid(3508950)
addappid(3714230)
addappid(4093750)
addappid(4193350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072040,0,"099127c0769b81e60bda0a6a17bd4c507de3012e4d1e917a244402a509475dcf")
addappid(1072041,0,"de3fa40c340b3cb190b613e2b7a7bca726ddf02e1f4bae16c791690ee024b6d1")
addappid(1072042,0,"e27db59a9366a37f00f6ce0299a1a410c1d76dd9853d3237ffb91d4868c66b61")
addappid(1072043,0,"522b0f0ead27b98349b6d52271b3842f2a97b8ee361186054d2191d8400657a9")

