-- Lua provided by RyzenAPI
-- Game: Game: Panzer Corps 2

-- MAIN APPLICATION
addappid(1072040)
-- Game: addappid(1072040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072041, 1, "de3fa40c340b3cb190b613e2b7a7bca726ddf02e1f4bae16c791690ee024b6d1")
addappid(1072042, 1, "e27db59a9366a37f00f6ce0299a1a410c1d76dd9853d3237ffb91d4868c66b61")
addappid(1072043, 1, "522b0f0ead27b98349b6d52271b3842f2a97b8ee361186054d2191d8400657a9")
