-- Lua provided by RyzenAPI
-- Game: 1913420

-- MAIN APPLICATION
addappid(1913420)
addappid(2426760)
-- Game: addappid(1913420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913421, 1, "248fbb2b6d0615e765768d8d17fcdbba3307e14d81cafae28ab896d0f40b466d")
