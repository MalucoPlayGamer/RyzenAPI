-- Lua provided by SkyAPI 
-- Game: Survival: Lost Way
addappid(1343520)
addappid(1343521, 1, "41b56e462b5d9930420348b1171c9e3140d2d4d5517a4fed9a4fdf06ae4444de")
