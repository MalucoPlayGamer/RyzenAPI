-- Lua provided by RyzenAPI
-- Game: Survival: Lost Way

-- MAIN APPLICATION
addappid(1343520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343521, 1, "41b56e462b5d9930420348b1171c9e3140d2d4d5517a4fed9a4fdf06ae4444de")

