-- Lua provided by RyzenAPI
-- Game: Survival: Lost Way

-- MAIN APPLICATION
addappid(1343520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343521, 1, "41b56e462b5d9930420348b1171c9e3140d2d4d5517a4fed9a4fdf06ae4444de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
