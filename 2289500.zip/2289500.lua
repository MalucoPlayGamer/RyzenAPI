-- Lua provided by RyzenAPI
-- Game: FirstResponderVR

-- MAIN APPLICATION
addappid(2289500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2289501, 1, "7b2cbeb769b5ae6b25cec13072e7e31cff3003dc1b33af6d00f1bb4c369c854b")

