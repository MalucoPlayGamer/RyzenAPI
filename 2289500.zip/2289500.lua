-- Lua provided by RyzenAPI
-- Game: FirstResponderVR

-- MAIN APPLICATION
addappid(2289500)
-- Game: addappid(2289500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289501, 1, "7b2cbeb769b5ae6b25cec13072e7e31cff3003dc1b33af6d00f1bb4c369c854b")
