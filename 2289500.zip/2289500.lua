-- Lua provided by SkyAPI 
-- Game: FirstResponderVR
addappid(2289500)
addappid(2289501, 1, "7b2cbeb769b5ae6b25cec13072e7e31cff3003dc1b33af6d00f1bb4c369c854b")
