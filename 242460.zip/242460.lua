-- Lua provided by RyzenAPI
-- Game: Football Manager 2014 Editor

-- MAIN APPLICATION
addappid(242460)

-- MAIN APP DEPOTS / PACKAGES
addappid(242461, 1, "d7f05385b41838da941f2701a664a263e8aae2a9c3fe643b1b11781ddb3eafa3")

