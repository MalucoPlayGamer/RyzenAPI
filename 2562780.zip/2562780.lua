-- Lua provided by RyzenAPI
-- Game: Game: The Last Exterminator Demo

-- MAIN APPLICATION
addappid(2562780)
-- Game: addappid(2562780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562781, 1, "e689f5f046e8a62942773831f052791722864c64541a381e36126764324d258a")
