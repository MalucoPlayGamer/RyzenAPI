-- Lua provided by RyzenAPI
-- Game: Socrates Jones: Pro Philosopher

-- MAIN APPLICATION
addappid(2120060)
