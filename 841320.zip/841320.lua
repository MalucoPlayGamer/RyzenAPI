-- Lua provided by RyzenAPI
-- Game: Whitevale Defender

-- MAIN APPLICATION
addappid(841320)

-- MAIN APP DEPOTS / PACKAGES
addappid(841321, 1, "1843bb1e40ca3a7f9e2e016b9bfb322d2de47b7dacdac68cbd49e821643d6979")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
