-- Lua provided by RyzenAPI
-- Game: Whitevale Defender

-- MAIN APPLICATION
addappid(841320)

-- MAIN APP DEPOTS / PACKAGES
addappid(841321, 1, "1843bb1e40ca3a7f9e2e016b9bfb322d2de47b7dacdac68cbd49e821643d6979")

