-- Lua provided by RyzenAPI
-- Game: 2843440

-- MAIN APPLICATION
addappid(2843440)
-- Game: addappid(2843440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843440,0,"ca584d29491f9e204fdb36f032e831b0465da423f9b28ff05e7ec4c74a93b5bd")
