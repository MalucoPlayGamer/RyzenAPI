-- Lua provided by RyzenAPI
-- Game: Gentle Officer

-- MAIN APPLICATION
addappid(3048650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048651, 1, "c99298c0bc4667d0b899c4d32d90dad5223277e42c657d1513d41d369d8ec90c")

