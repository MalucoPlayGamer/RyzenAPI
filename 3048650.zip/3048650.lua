-- Lua provided by RyzenAPI
-- Game: Gentle Officer

-- MAIN APPLICATION
addappid(3048650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3048651, 1, "c99298c0bc4667d0b899c4d32d90dad5223277e42c657d1513d41d369d8ec90c")

