-- Lua provided by RyzenAPI
-- Game: 1455630

-- MAIN APPLICATION
addappid(1455630)
-- Game: addappid(1455630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455631, 1, "abceb8a2d0d156ca09ae0b6fab621ed2925a0df70f83cea6efc75cf380108e72")
