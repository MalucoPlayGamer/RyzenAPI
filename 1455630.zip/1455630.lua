-- Lua provided by RyzenAPI
-- Game: THE GAME OF LIFE 2

-- MAIN APPLICATION
addappid(1455630)
addappid(1461050)
addappid(1465430)
addappid(1465431)
addappid(1465432)
addappid(1544410)
addappid(1627910)
addappid(1803670)
addappid(2065660)
addappid(2218810)
addappid(2485880)
addappid(2695460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455631, 1, "abceb8a2d0d156ca09ae0b6fab621ed2925a0df70f83cea6efc75cf380108e72")

