-- Lua provided by RyzenAPI
-- Game: Game: AppID 413150

-- MAIN APPLICATION
addappid(413150)
-- Game: addappid(413150)

-- MAIN APP DEPOTS / PACKAGES
addappid(413151, 1, "ff71699a17787b798d901cb27398556eb69a498b690b4392b2ffedcacc1019ff")
addappid(413152, 1, "c65e7919242bdcb29efd9551af381e9b6f5d828ac7382cec83f1d8459aaf3fdf")
addappid(413153, 1, "d1e04015717ef68e43064bd29a027c3309b47bd156d0494c7d4dff56a971e3c7")
