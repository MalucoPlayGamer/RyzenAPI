-- Lua provided by RyzenAPI
-- Game: School Days

-- MAIN APPLICATION
addappid(1991040)
-- Game: addappid(1991040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991041, 1, "db44c404057a2295a7c0d1dcfcba71f1a9486672998b2012d88d9d1a6edc72b9")
