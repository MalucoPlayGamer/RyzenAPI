-- Lua provided by SkyAPI 
-- Game: AppID 652340
addappid(652340)
addappid(652341, 1, "c2049c27ccb3d3a164f9e2a0815e4b57f22f373db2f10e7df79671d95ec12d68")
addappid(652342, 1, "9626507ee41ce170933885519949304a3a68aa0e5ac74e6ffaa6ce9e056b7530")
