-- Lua provided by SkyAPI 
-- Game: BigChick
addappid(1406000)
addappid(1406001, 1, "6c11fd5ea1666ddbf5a8222aac7df8d36a52ece24b909bd70ee25c43f3bc992f")
