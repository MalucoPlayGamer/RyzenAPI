-- Lua provided by RyzenAPI
-- Game: Yuuna and the Haunted Hot Springs The Thrilling Steamy Maze Kiwami

-- MAIN APPLICATION
addappid(2436340)
-- Game: addappid(2436340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436341, 1, "c9ac9275e0558f89db33d0cec4998c7118d36f061c38ce72aeb6c3115fb45230")
