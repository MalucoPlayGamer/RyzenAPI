-- Lua provided by RyzenAPI
-- Game: Workplace Rhapsody

-- MAIN APPLICATION
addappid(1585570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585573,0,"29038942ae49d4f5c18bc0fff5e98ed2c2d7cd6973c3c295810c945a5b16bf63")
addappid(1786890,0,"52d81f14e1c04fb24bbf1c3f1bf9381cd8b5ce6c88514719f199a7a4a2c0dcf3")
addappid(1927070,0,"7878baf265539306af69347234776d4a6af76e0b3a922bb91d0c41ed12c2e7bb")

