-- Lua provided by RyzenAPI
-- Game: AppID 224320

-- MAIN APPLICATION
addappid(224320)

-- MAIN APP DEPOTS / PACKAGES
addappid(224321, 1, "824cc973bfe312e9eea9397cbcf4a9a93618fb6f7e16db42b1e3b4be3352cb6c")
