-- Lua provided by RyzenAPI
-- Game: addappid(2312050)

-- MAIN APPLICATION
addappid(2312050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312051, 1, "dadf0f4dd748c75be705c3a1a8e28bb91f611a5624602cff860cd560a90e4dbe")
