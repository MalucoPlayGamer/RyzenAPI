-- Lua provided by RyzenAPI
-- Game: Button Button Up!

-- MAIN APPLICATION
addappid(623320)

-- MAIN APP DEPOTS / PACKAGES
addappid(623321, 1, "76c25879c4d43b06be3f63465e4fea8ac4ee26892cf83cf7d1d1a0879a4e73bd")
addappid(1086040, 0, "a212fc4527558fd7fd30220e9cf1cbf955fac10d8d408cbd339508ee7863d335")

