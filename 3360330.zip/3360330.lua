-- Lua provided by RyzenAPI
-- Game: addappid(3360330)

-- MAIN APPLICATION
addappid(3360330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360331, 1, "7aa22b55ae0df2e625e7d388859772581a0ef03ac09387b43def9194f8dbca44")
