-- Lua provided by RyzenAPI
-- Game: 灵魂重生 Reborn the Soul

-- MAIN APPLICATION
addappid(3360330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360331, 1, "7aa22b55ae0df2e625e7d388859772581a0ef03ac09387b43def9194f8dbca44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
