-- Lua provided by RyzenAPI
-- Game: addappid(2860950)

-- MAIN APPLICATION
addappid(2860950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860951, 1, "036ccbd25aa768b32d1e1e863c267761c3f081a727e2dea3e879d1858ee0c766")
