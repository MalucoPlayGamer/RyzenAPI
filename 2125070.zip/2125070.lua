-- Lua provided by RyzenAPI
-- Game: 孤胆惊魂3:起源 Fear3:Origins

-- MAIN APPLICATION
addappid(2125070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125071, 1, "560f9cdd009c1d6df1024e8ad7b1d0a19200a6e0b5f6dcdd075b95454f0dac10")
