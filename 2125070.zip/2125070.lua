-- Lua provided by SkyAPI 
-- Game: AppID 2125070
addappid(2125070)
addappid(2125071, 1, "560f9cdd009c1d6df1024e8ad7b1d0a19200a6e0b5f6dcdd075b95454f0dac10")
