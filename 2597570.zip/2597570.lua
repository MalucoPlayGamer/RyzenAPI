-- Lua provided by RyzenAPI 
-- Game: Chasmal Fear
addappid(2597570)
addappid(2597571, 1, "b9f381593cfa3f952c80a190fb2e8a0bfa5282440f28c61ae9785de043a0fb03")
addappid(2597572, 1, "0c2abd77b04d896abf9c65158b34f454b6c03378562ca3fd4ebb681922565a8f")
