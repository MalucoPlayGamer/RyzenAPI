-- Lua provided by RyzenAPI
-- Game: Chasmal Fear

-- MAIN APPLICATION
addappid(2597570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2597571, 1, "b9f381593cfa3f952c80a190fb2e8a0bfa5282440f28c61ae9785de043a0fb03")
addappid(2597572, 1, "0c2abd77b04d896abf9c65158b34f454b6c03378562ca3fd4ebb681922565a8f")

