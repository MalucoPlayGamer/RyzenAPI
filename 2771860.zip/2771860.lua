-- Lua provided by RyzenAPI 
-- Game: Save Giant Girl from monsters
addappid(2771860)
addappid(2771861, 1, "eb017a7f6d165b75915c052dc8f19ac299a3b43cdce79f7e8060a56e1c323093")
