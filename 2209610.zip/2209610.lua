-- Lua provided by RyzenAPI
-- Game: Aviator: Air Combat

-- MAIN APPLICATION
addappid(2209610)
-- Game: addappid(2209610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209611, 1, "776a85553ae32946670c274466a42838c50ff4e70097397f292afef996d463da")
