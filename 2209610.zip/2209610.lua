-- Lua provided by SkyAPI 
-- Game: Aviator: Air Combat
addappid(2209610)
addappid(2209611, 1, "776a85553ae32946670c274466a42838c50ff4e70097397f292afef996d463da")
