-- Lua provided by RyzenAPI
-- Game: addappid(2330960)

-- MAIN APPLICATION
addappid(2330960)
addappid(3412930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330961, 1, "f2ceb0fe0733383936355e24c5e9a338327938e1af82e75e900338045eca6e6d")
