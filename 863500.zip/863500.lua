-- Lua provided by RyzenAPI
-- Game: Game: All Quiet in the Trenches

-- MAIN APPLICATION
addappid(863500)
-- Game: addappid(863500)

-- MAIN APP DEPOTS / PACKAGES
addappid(863501, 1, "25b55250f262957eb98f9d2b3f846bf7d735554779e62004470d1801de20c30b")
