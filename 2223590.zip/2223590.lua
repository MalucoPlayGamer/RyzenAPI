-- Lua provided by SkyAPI 
-- Game: 2112TD: Tower Defense Survival
addappid(2223590)
addappid(2223591, 1, "efa1200af25ee22d502771066831d4436e15b312a06bb56618f3d7f4c54f21cc")
