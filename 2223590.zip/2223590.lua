-- Lua provided by RyzenAPI
-- Game: 2112TD: Tower Defense Survival

-- MAIN APPLICATION
addappid(2223590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2223591, 1, "efa1200af25ee22d502771066831d4436e15b312a06bb56618f3d7f4c54f21cc")

