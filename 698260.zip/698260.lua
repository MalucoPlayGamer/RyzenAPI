-- Lua provided by RyzenAPI
-- Game: Game: Star Shelter

-- MAIN APPLICATION
addappid(698260)
-- Game: addappid(698260)

-- MAIN APP DEPOTS / PACKAGES
addappid(698261, 1, "0009e451d5e3294afd6e1161c9ed5cfb6b15c6bba6f584a22c6e40ccf3aaf4cb")
