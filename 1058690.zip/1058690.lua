-- Lua provided by RyzenAPI
-- Game: Signs of the Sojourner

-- MAIN APPLICATION
addappid(1058690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058691, 1, "eb1286664c0b0647d67a49a737bfb7d6951d0b30c772a306a4c4eac3d81cc3dc")
addappid(1058692, 1, "4d40ddf23c5684b6b9af70a40f5e383bbcbdb4cacc01ea6a62d5540c4d1fa2de")

