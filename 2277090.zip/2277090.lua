-- Lua provided by RyzenAPI
-- Game: addappid(2277090)

-- MAIN APPLICATION
addappid(2277090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277091, 1, "4ba9c2038eafdc96aca0289a17244f4ae5347b09c1f9359c9beca3d3a11d716f")
