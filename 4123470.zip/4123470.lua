-- Lua provided by RyzenAPI
-- Game: Dysnamic

-- MAIN APPLICATION
addappid(4123470) -- Dysnamic

-- MAIN APP DEPOTS / PACKAGES
addappid(4123471, 1, "0e42e99cd559406e53b37c29166a685a5f23207005f0d9ff68b3b121e9e7896f") -- Depot 4123471

