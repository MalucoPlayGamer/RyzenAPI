-- 4123470's Lua and Manifest Created by Hubcap Manifest
-- Dysnamic
-- Created: August 11, 2026 at 12:25:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4123470) -- Dysnamic
-- MAIN APP DEPOTS
addappid(4123471, 1, "0e42e99cd559406e53b37c29166a685a5f23207005f0d9ff68b3b121e9e7896f") -- Depot 4123471
setManifestid(4123471, "8454792252259862948", 439553698)