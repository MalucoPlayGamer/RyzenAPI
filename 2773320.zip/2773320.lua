-- Lua provided by RyzenAPI
-- Game: Race of Life - Act 1 Demo

-- MAIN APPLICATION
addappid(2773320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773321, 1, "fe7f4f2d7c578c2a4f616b93838c22438b5b1967c1d1f7179858588e650625c0")
