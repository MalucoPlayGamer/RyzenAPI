-- Lua provided by RyzenAPI
-- Game: Demons Killers

-- MAIN APPLICATION
addappid(4255720)

-- MAIN APP DEPOTS / PACKAGES
addappid(4255721, 1, "535e76508182b8c767c7a72dff92cd6869a0a1f137277e91304d7b63242b3df8")
