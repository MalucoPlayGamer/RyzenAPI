-- Lua provided by RyzenAPI
-- Game: Rebornia

-- MAIN APPLICATION
addappid(2882700)
-- Game: addappid(2882700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882708,0,"56a21c5cb0ccb5482c4fe309a091452738b9a9ff525641bb17827e77dc6ad015")
addappid(2882709,0,"260841ebd3c8d39a2c4a311a57b07f85c7a3ce8681511faf5c5bd894ce194d00")
