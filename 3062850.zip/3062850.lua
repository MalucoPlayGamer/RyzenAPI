-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - More Trees

-- MAIN APPLICATION
addappid(3062850)
-- Game: addappid(3062850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062850,0,"833a3d44c88cd919ba67bfac4ed9173128a43b3368187437fb0097fcda5573c0")
