-- Lua provided by RyzenAPI 
-- Game: Ethel
addappid(2852930)
addappid(2852931, 1, "a6d4351fa4621c713c20c1c27621c935b98c179b8190f0bd900bfa50ae6b4464")
