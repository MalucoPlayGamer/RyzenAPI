-- Lua provided by RyzenAPI
-- Game: Game: Ethel

-- MAIN APPLICATION
addappid(2852930)
-- Game: addappid(2852930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852931, 1, "a6d4351fa4621c713c20c1c27621c935b98c179b8190f0bd900bfa50ae6b4464")
