-- Lua provided by RyzenAPI
-- Game: 4Line

-- MAIN APPLICATION
addappid(1432880)
-- Game: addappid(1432880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432881, 1, "c521da51c9c10c1990728cb534714334812cf7e0566f876da0b4dd6f15043298")
