-- Lua provided by RyzenAPI
-- Game: addappid(1659090)

-- MAIN APPLICATION
addappid(1659090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659091, 1, "214585f811b4457a928b7c8888ad914c00ae2378d2b2ebd66887ecf6654bfcef")
