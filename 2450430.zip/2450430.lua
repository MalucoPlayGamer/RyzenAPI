-- Lua provided by RyzenAPI 
-- Game: 探しものは、夏ですか。
addappid(2450430)
addappid(2450431, 1, "6cae457c459aa8b3166977f9add866872f7469b2366854a20b325c8660a118fc")
