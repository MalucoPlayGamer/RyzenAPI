-- Lua provided by RyzenAPI
-- Game: Game: 探しものは、夏ですか。

-- MAIN APPLICATION
addappid(2450430)
-- Game: addappid(2450430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450431, 1, "6cae457c459aa8b3166977f9add866872f7469b2366854a20b325c8660a118fc")
