-- Lua provided by RyzenAPI 
-- Game: Palia
addappid(2707930)
addappid(2707931, 1, "8dcbc3190b4df9e486fd1898b13fdbbd8549da218b0719a813b3f6d771a8e6f3")
