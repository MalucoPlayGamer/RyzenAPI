-- Lua provided by RyzenAPI
-- Game: 2707930

-- MAIN APPLICATION
addappid(2707930)
-- Game: addappid(2707930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707931, 1, "8dcbc3190b4df9e486fd1898b13fdbbd8549da218b0719a813b3f6d771a8e6f3")
