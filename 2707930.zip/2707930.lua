-- 2707930's Lua and Manifest Created by Hubcap Manifest
-- Palia
-- Created: July 29, 2026 at 12:55:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2707930, 1, "d9b8cefe2f074729ed5d8ea0f5e812a87a8c06922ffb278670150a9da1cbd980") -- Palia
-- MAIN APP DEPOTS
addappid(2707931, 1, "8dcbc3190b4df9e486fd1898b13fdbbd8549da218b0719a813b3f6d771a8e6f3") -- Depot 2707931
setManifestid(2707931, "8171661216948808424", 22315929253)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3708940) -- Palia - Founders Pack
addappid(3720190) -- Palia - Starter Pack
addappid(4465220) -- Palia - Highlands Supporter Pack
addappid(4465230) -- Palia - Royal Highlands Supporter Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3708940) -- Depot 3708940 (empty depot)
-- addappid(3720190) -- Depot 3720190 (empty depot)