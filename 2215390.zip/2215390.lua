-- Lua provided by RyzenAPI
-- Game: Five Nights at Freddy's: Secret of the Mimic

-- MAIN APPLICATION
addappid(2215390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215391, 1, "d87a5534a048a1a7a81c896212cff7fa105e3104a74914bf1473552d72347211")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
