-- Lua provided by RyzenAPI
-- Game: Game: Five Nights at Freddy's: Secret of the Mimic

-- MAIN APPLICATION
addappid(2215390)
-- Game: addappid(2215390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215391, 1, "d87a5534a048a1a7a81c896212cff7fa105e3104a74914bf1473552d72347211")
