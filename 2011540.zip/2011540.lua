-- Lua provided by RyzenAPI
-- Game: 2011540

-- MAIN APPLICATION
addappid(2011540)
-- Game: addappid(2011540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011541, 1, "668e7ddd44ad36f0d90cc11132c11c220da400e665e59f8611cc93604c81db28")
