-- Lua provided by RyzenAPI
-- Game: Blendy 2 Dolls Factory

-- MAIN APPLICATION
addappid(1231040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231041, 1, "5669a9ef239d06149f8ffc1b491fd385034f31c36507214f07417222f333dddc")
