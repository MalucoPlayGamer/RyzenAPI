-- Lua provided by RyzenAPI
-- Game: 3389000

-- MAIN APPLICATION
addappid(3389000)
-- Game: addappid(3389000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389001, 1, "41ea0a1a1c56d322d25ea8ff2ab36e33c45718460b8f45e0b5c3bbdd61455591")
