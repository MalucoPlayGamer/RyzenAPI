-- Lua provided by RyzenAPI
-- Game: Try To Survive

-- MAIN APPLICATION
addappid(1051250)
-- Game: addappid(1051250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051251, 1, "26482090d0987edd8625977fc3a5ae2631d16d463b54c39311d8d13defe92b7b")
