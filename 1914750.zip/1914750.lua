-- Lua provided by RyzenAPI
-- Game: Game: Resist

-- MAIN APPLICATION
addappid(1914750)
-- Game: addappid(1914750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914751, 1, "693cb7e20872d4a03e75623db1cf2b8e8f2f25f97def5535833bf69dc804f1d8")
