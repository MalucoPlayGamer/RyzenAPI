-- Lua provided by SkyAPI 
-- Game: Resist
addappid(1914750)
addappid(1914751, 1, "693cb7e20872d4a03e75623db1cf2b8e8f2f25f97def5535833bf69dc804f1d8")
