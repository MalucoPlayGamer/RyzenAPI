-- Lua provided by SkyAPI 
-- Game: 101 Cats in London
addappid(3452020)
addappid(3452021, 1, "27c6d44d231de7c991fdc0031ea7f27721db095e6d839c635adde2f5fed3e312")
