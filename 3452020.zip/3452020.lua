-- Lua provided by RyzenAPI
-- Game: 101 Cats in London

-- MAIN APPLICATION
addappid(3452020)
-- Game: addappid(3452020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452021, 1, "27c6d44d231de7c991fdc0031ea7f27721db095e6d839c635adde2f5fed3e312")
