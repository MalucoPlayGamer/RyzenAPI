-- Lua provided by RyzenAPI
-- Game: Block Block Block

-- MAIN APPLICATION
addappid(3375490) -- Block Block Block

-- MAIN APP DEPOTS / PACKAGES
addappid(3375491, 1, "1f60c034eb42cd68266bed48e4b743b44c2bc3362dcc2df270710edbcf02d675") -- Depot 3375491
addtoken(3375490, "12343057855297602616")

