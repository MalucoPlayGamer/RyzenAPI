-- 3375490's Lua and Manifest Created by Hubcap Manifest
-- Block Block Block
-- Created: August 05, 2026 at 22:36:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3375490) -- Block Block Block
addtoken(3375490, "12343057855297602616")
-- MAIN APP DEPOTS
addappid(3375491, 1, "1f60c034eb42cd68266bed48e4b743b44c2bc3362dcc2df270710edbcf02d675") -- Depot 3375491
setManifestid(3375491, "7049145714141671759", 651571446)