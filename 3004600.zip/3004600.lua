-- Lua provided by RyzenAPI
-- Game: addappid(3004600)

-- MAIN APPLICATION
addappid(3004600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004601, 1, "cfaa3de04456b52ed3cd1ee2f28ebc501413aead8f2e9e91f68ccb591ccc4f88")
