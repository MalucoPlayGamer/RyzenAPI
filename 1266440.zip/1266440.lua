-- Lua provided by RyzenAPI
-- Game: Disarmed

-- MAIN APPLICATION
addappid(1266440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1266441, 1, "6363b43471502bae9650ef9da73a8747dbf58e108f2d2537e158ce7fff01b970")

