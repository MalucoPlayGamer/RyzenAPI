-- Lua provided by RyzenAPI
-- Game: Disarmed

-- MAIN APPLICATION
addappid(1266440)
-- Game: addappid(1266440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266441, 1, "6363b43471502bae9650ef9da73a8747dbf58e108f2d2537e158ce7fff01b970")
