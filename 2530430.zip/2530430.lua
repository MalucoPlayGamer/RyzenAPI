-- Lua provided by RyzenAPI
-- Game: Terror At Oakheart

-- MAIN APPLICATION
addappid(2530430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2530431, 1, "945f0a62071335f5e8241613967e950cca97102f53edc1c8360ccfb0dbee10d4")

