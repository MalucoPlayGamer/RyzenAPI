-- Lua provided by RyzenAPI
-- Game: addappid(2530430)

-- MAIN APPLICATION
addappid(2530430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530431, 1, "945f0a62071335f5e8241613967e950cca97102f53edc1c8360ccfb0dbee10d4")
