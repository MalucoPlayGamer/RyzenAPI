-- Lua provided by SkyAPI 
-- Game: Ralph's party RPG
addappid(1977230)
addappid(1977231, 1, "845742de83b1b59f340fad806d2ae1ae2f3a834629e640080a98ed5c2ec5f797")
