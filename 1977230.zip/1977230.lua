-- Lua provided by RyzenAPI
-- Game: Ralph's party RPG

-- MAIN APPLICATION
addappid(1977230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1977231, 1, "845742de83b1b59f340fad806d2ae1ae2f3a834629e640080a98ed5c2ec5f797")

