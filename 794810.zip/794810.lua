-- Lua provided by RyzenAPI
-- Game: AppID 794810

-- MAIN APPLICATION
addappid(794810)
-- Game: addappid(794810)

-- MAIN APP DEPOTS / PACKAGES
addappid(794811, 1, "fa09d90cf08cb37b292aa95d4608ececf3dd5084adc8c3ad310a9a43a2ecc904")
