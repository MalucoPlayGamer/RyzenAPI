-- Lua provided by RyzenAPI
-- Game: Teared

-- MAIN APPLICATION
addappid(2782490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782491, 1, "08d1b6d12433b7043206e82caa7b0b35ccce856537ae918fa7caaa06da354e7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
