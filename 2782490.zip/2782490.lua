-- Lua provided by RyzenAPI
-- Game: Teared

-- MAIN APPLICATION
addappid(2782490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782491, 1, "08d1b6d12433b7043206e82caa7b0b35ccce856537ae918fa7caaa06da354e7e")

