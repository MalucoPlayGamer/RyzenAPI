-- Lua provided by RyzenAPI
-- Game: addappid(2633730)

-- MAIN APPLICATION
addappid(2633730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633731, 1, "9bd402b65c7a3a6864da96d710b5bf48febb8829b5d83bf47ef1071482593588")
