-- Lua provided by RyzenAPI
-- Game: Lost On The Island

-- MAIN APPLICATION
addappid(949520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(949521, 1, "3614c1bcec1e34c1b197d08143f07603d18b542267a9ea64efc12cf2038f0c8e")

