-- Lua provided by RyzenAPI
-- Game: Game: AppID 949520

-- MAIN APPLICATION
addappid(949520)
-- Game: addappid(949520)

-- MAIN APP DEPOTS / PACKAGES
addappid(949521, 1, "3614c1bcec1e34c1b197d08143f07603d18b542267a9ea64efc12cf2038f0c8e")
