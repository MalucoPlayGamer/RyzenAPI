-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Sonaria

-- MAIN APPLICATION
addappid(713320)

-- MAIN APP DEPOTS / PACKAGES
addappid(713321, 1, "f38a5861b81b400c3512a9a318b385c6690cfadd5062b22125ce71f1abd8e446")
addappid(713322, 1, "bf36f1a0c521874284b291306e3e48f9bc0615f7e0d2c77bf7808dd12c672801")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
