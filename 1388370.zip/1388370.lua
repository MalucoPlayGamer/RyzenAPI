-- Lua provided by SkyAPI 
-- Game: Heroic Armored Company
addappid(1388370)
addappid(1388371, 1, "89672d5dcb4e01993c7b97110a6e9705cfd80a23494345acca13994a31ae407f")
