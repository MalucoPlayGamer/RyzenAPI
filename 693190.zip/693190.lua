-- Lua provided by SkyAPI 
-- Game: Survival driver 2: Heavy vehicles
addappid(693190)
addappid(693191, 1, "af44da9929ec859a62f14ea4a2c5a9dd0717b83053829ac3f82edb3a5cde7bc1")
