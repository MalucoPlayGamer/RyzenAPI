-- Lua provided by RyzenAPI
-- Game: Survival driver 2: Heavy vehicles

-- MAIN APPLICATION
addappid(693190)

-- MAIN APP DEPOTS / PACKAGES
addappid(693191, 1, "af44da9929ec859a62f14ea4a2c5a9dd0717b83053829ac3f82edb3a5cde7bc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
