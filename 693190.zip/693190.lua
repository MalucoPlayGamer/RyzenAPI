-- Lua provided by RyzenAPI
-- Game: addappid(693190)

-- MAIN APPLICATION
addappid(693190)

-- MAIN APP DEPOTS / PACKAGES
addappid(693191, 1, "af44da9929ec859a62f14ea4a2c5a9dd0717b83053829ac3f82edb3a5cde7bc1")
