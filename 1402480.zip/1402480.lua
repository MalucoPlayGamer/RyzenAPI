-- Lua provided by RyzenAPI
-- Game: 1402480

-- MAIN APPLICATION
addappid(1402480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402482,0,"fa0ee1e4e4066c5cfe77245a593169087339d8cf516dececec2731caddf129d7")

