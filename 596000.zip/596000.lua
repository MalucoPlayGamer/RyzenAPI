-- Lua provided by RyzenAPI
-- Game: The Shattering

-- MAIN APPLICATION
addappid(596000)
addappid(1542030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(596001, 1, "95345fc05938ad65e77d6216a8fa0ab01f854711e32e6c5f0596dab134ee203a")

