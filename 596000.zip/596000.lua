-- Lua provided by RyzenAPI
-- Game: Game: The Shattering

-- MAIN APPLICATION
addappid(596000)
-- Game: addappid(596000)

-- MAIN APP DEPOTS / PACKAGES
addappid(596001, 1, "95345fc05938ad65e77d6216a8fa0ab01f854711e32e6c5f0596dab134ee203a")
