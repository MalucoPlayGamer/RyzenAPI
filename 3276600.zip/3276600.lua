-- Lua provided by RyzenAPI
-- Game: Hirai Nya

-- MAIN APPLICATION
addappid(3276600)
addappid(3441270)
-- Game: addappid(3276600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276601, 1, "15c8ad512e8da32b52331de640f87db6e17714c6ebd8de6bfdb07c4f14bd4206")
