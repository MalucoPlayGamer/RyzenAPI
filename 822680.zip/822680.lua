-- Lua provided by RyzenAPI
-- Game: Eternal Man: Jump

-- MAIN APPLICATION
addappid(822680)

-- MAIN APP DEPOTS / PACKAGES
addappid(822681, 1, "dd381ffe31f751a6e9182bec0846b35686458245a794c68d9714a0205c500b47")

