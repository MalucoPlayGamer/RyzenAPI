-- Lua provided by RyzenAPI
-- Game: Abandoned

-- MAIN APPLICATION
addappid(975030)
-- Game: addappid(975030)

-- MAIN APP DEPOTS / PACKAGES
addappid(975031, 1, "ff18cbe400dbca87ca5710d0d5ae5aa059f90be641c5a0d2c8e58242f4aaf973")
