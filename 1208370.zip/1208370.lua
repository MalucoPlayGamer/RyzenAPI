-- Lua provided by RyzenAPI
-- Game: DUMB Infernal

-- MAIN APPLICATION
addappid(1208370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208371, 1, "e1565b03f2726fe9b5a423af6320a590e40c8bf59a204ffe4e15c71627bf0546")

