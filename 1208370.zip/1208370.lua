-- Lua provided by RyzenAPI
-- Game: DUMB Infernal

-- MAIN APPLICATION
addappid(1208370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1208371, 1, "e1565b03f2726fe9b5a423af6320a590e40c8bf59a204ffe4e15c71627bf0546")

