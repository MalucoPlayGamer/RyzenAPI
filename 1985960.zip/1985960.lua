-- Lua provided by RyzenAPI
-- Game: Game: Ogu and the Secret Forest

-- MAIN APPLICATION
addappid(1985960)
-- Game: addappid(1985960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985961, 1, "9295648b834fb14f8200b8a435f43c9ca23e2a7a60939650b97062841f5beb8d")
