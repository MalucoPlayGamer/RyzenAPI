-- Lua provided by RyzenAPI
-- Game: Forest spiders

-- MAIN APPLICATION
addappid(1156570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156571, 1, "79dfc70523d609e693e9929a87abd08506d81d786f47f2425080fde2b06b7842")
