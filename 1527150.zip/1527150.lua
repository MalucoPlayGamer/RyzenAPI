-- Lua provided by RyzenAPI
-- Game: addappid(1527150)

-- MAIN APPLICATION
addappid(1527150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527151, 1, "4ece1f16d882f9e862e22afd5b9239beecc02ee81124d42a9684007a11318c16")
