-- Lua provided by RyzenAPI
-- Game: AppID 1389880

-- MAIN APPLICATION
addappid(1389880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389881, 1, "b984be70cca8e549557642a91ff399b6803d7ac3ac313ed29ba918ecdecf53fc")

