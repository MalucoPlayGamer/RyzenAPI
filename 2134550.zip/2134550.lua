-- Lua provided by RyzenAPI
-- Game: Game: AppID 2134550

-- MAIN APPLICATION
addappid(2134550)
-- Game: addappid(2134550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134551, 1, "f71d72c628acb1904e6c882f5e930e10f82d32b42fb5e3b8f0de8c835662925d")
