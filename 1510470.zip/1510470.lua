-- Lua provided by RyzenAPI
-- Game: AppID 1510470

-- MAIN APPLICATION
addappid(1510470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510471, 1, "0bb30ec8f576b16ea4561122794f756c64cce0961c7693080efd6328fafed6fe")
addappid(1510472, 1, "b1035a7e2a25fbbee369022bdec8ad1c05500971c927aa5ff2fe9ebaafa20094")
addappid(1510473, 1, "6ba272104df4e010f3c3f7e488774b88d7ed365cbf6986959158480954d8843e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3309740)
