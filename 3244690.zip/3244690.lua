-- Lua provided by RyzenAPI
-- Game: Game: Save Scream and Run

-- MAIN APPLICATION
addappid(3244690)
-- Game: addappid(3244690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244691, 1, "5da0dc94060bcca76df044bacb734434799f2f13cdff5d9df375f6e9571933df")
