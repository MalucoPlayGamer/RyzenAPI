-- Lua provided by RyzenAPI 
-- Game: AppID 444740
addappid(444740)
addappid(444741, 1, "4cdd7277b6318d6dee5e8f08df17a978d136d562f08bb74663f8588e753a5657")
