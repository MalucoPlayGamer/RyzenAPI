-- Lua provided by RyzenAPI
-- Game: Until Dawn™

-- MAIN APPLICATION
addappid(2172010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2172011, 1, "b8955754339fd50012ea607b7095692a80fdcb5b93df0e9dd837dfa5c6e3aabf")
addappid(2172012, 1, "3dee1125193274da66e531b4c674f7787d08405c3f39309b0f72d9fe96d6ba74")

