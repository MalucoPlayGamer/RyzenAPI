-- Lua provided by RyzenAPI
-- Game: Rental

-- MAIN APPLICATION
addappid(2796550)
addappid(2849860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796551, 1, "834eeac639b1eb2abff111998f58a2034d393a0bd30542ffda451f04333c4f9a")

