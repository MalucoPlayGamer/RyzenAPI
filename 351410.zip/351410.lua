-- Lua provided by RyzenAPI
-- Game: Clean'Em Up

-- MAIN APPLICATION
addappid(351410)
-- Game: addappid(351410)

-- MAIN APP DEPOTS / PACKAGES
addappid(351411, 1, "a600e8757b44f75175c547286d3485ebd62af3ccaff91628b6b34a275e76c20c")
