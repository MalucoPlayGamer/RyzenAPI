-- Lua provided by SkyAPI 
-- Game: Super Ultra Monster Smash!
addappid(678060)
addappid(678061, 1, "08ccce8c9d20be1141480ee35769156b6edfae1ca2e5b42cdc4b760d14b3d52c")
