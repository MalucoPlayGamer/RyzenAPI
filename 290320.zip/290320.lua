-- Lua provided by RyzenAPI
-- Game: AppID 290320

-- MAIN APPLICATION
addappid(290320)

-- MAIN APP DEPOTS / PACKAGES
addappid(290321, 1, "c699448948f89ebeb97848f092ecc680da43191169d239427a89ee6e37984246")
addappid(290322, 1, "8b6933f4294e970624120d27beb682cbdc446ab7455519432f635359331697e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
