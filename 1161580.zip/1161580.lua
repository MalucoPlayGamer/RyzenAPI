-- Lua provided by RyzenAPI
-- Game: Hardspace: Shipbreaker

-- MAIN APPLICATION
addappid(1161580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161581, 1, "2d753dcdc7e9077164ce6c33c4a9c29694b86e69e0069398a1a35ca6ddaed884")
addappid(2237360, 0, "24f7ab0d9de7a637b04c76ac2336e27c243588cf0fd54eeff134292e430e06e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
