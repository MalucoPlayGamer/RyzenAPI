-- Lua provided by RyzenAPI
-- Game: Espirito Delusion

-- MAIN APPLICATION
addappid(3560420)
-- Game: addappid(3560420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3560421, 1, "ea7d0edb1edb0e57e99f1eaadec1633a64e831ca597bbabf93ea44e08dc10f06")
