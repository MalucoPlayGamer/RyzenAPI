-- Lua provided by RyzenAPI
-- Game: Espirito Delusion

-- MAIN APPLICATION
addappid(3560420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3560421, 1, "ea7d0edb1edb0e57e99f1eaadec1633a64e831ca597bbabf93ea44e08dc10f06")

