-- Lua provided by RyzenAPI
-- Game: Warface

-- MAIN APPLICATION
addappid(3889960)

