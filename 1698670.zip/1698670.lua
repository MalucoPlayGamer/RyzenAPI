-- Lua provided by RyzenAPI
-- Game: addappid(1698670)

-- MAIN APPLICATION
addappid(1698670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698671, 1, "065deaf7035a1e2fd2f68264ede8b058fb582b3ef637c81b92e5e467ce45f0c0")
