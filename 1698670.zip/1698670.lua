-- Lua provided by SkyAPI 
-- Game: Daggan
addappid(1698670)
addappid(1698671, 1, "065deaf7035a1e2fd2f68264ede8b058fb582b3ef637c81b92e5e467ce45f0c0")
