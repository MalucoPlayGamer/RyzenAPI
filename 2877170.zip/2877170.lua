-- Lua provided by RyzenAPI
-- Game: TouHou Makuka Sai ~ Fantastic Danmaku Festival Part III

-- MAIN APPLICATION
addappid(2877170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877171,0,"562a5ac022d1850dc11e9450b66655f5663eadfd47eebee40a4ade02ff49a06e")

