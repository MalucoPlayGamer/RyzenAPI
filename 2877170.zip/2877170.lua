-- Lua provided by RyzenAPI
-- Game: TouHou Makuka Sai ~ Fantastic Danmaku Festival Part III

-- MAIN APPLICATION
addappid(2877170)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2877171,0,"562a5ac022d1850dc11e9450b66655f5663eadfd47eebee40a4ade02ff49a06e")

