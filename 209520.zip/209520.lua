-- Lua provided by RyzenAPI
-- Game: Game: Mini Motor Racing EVO

-- MAIN APPLICATION
addappid(209520)
-- Game: addappid(209520)

-- MAIN APP DEPOTS / PACKAGES
addappid(209521, 1, "22f2ff277eeefc500a6d7181b321656a82138baae5262ae639f9ba2e059b0308")
