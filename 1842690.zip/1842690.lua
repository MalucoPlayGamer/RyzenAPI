-- Lua provided by RyzenAPI
-- Game: Station Manager

-- MAIN APPLICATION
addappid(1842690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842691, 1, "186238213a18cf3c78208976bdb5b653eb49108c28043e262be6b377cc5cff87")
