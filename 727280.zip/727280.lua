-- Lua provided by RyzenAPI
-- Game: AppID 727280

-- MAIN APPLICATION
addappid(727280)

-- MAIN APP DEPOTS / PACKAGES
addappid(727281, 1, "8acbdede8150ed12c08f8e09ebe5c43fbf1638a23f53bcccf984418f70e6d87d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
