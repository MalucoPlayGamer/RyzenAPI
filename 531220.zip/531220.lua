-- Lua provided by RyzenAPI
-- Game: Game: Splasher Demo

-- MAIN APPLICATION
addappid(531220)
-- Game: addappid(531220)

-- MAIN APP DEPOTS / PACKAGES
addappid(531221, 1, "06ef5daabdb6b1db9f839accb671aef356b7ee90f33cbaa0a9a0df60e42d40c1")
