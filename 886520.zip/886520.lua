-- Lua provided by RyzenAPI
-- Game: HopeLine

-- MAIN APPLICATION
addappid(886520)

-- MAIN APP DEPOTS / PACKAGES
addappid(886521, 1, "159a4f30022bcf15dba2606fa8cdff7a3acc0515450dba049b2aa35c97221fd1")

