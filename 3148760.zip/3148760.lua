-- Lua provided by RyzenAPI
-- Game: 3148760

-- MAIN APPLICATION
addappid(3148760)
-- Game: addappid(3148760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148761, 1, "6ca14ba76941ddd7b4452b91e082c3bc15947fca4e70d243cbdf88e5c57c4ba3")
