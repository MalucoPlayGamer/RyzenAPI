-- Lua provided by RyzenAPI
-- Game: GreedFall: The Dying World

-- MAIN APPLICATION
addappid(1997660)
addappid(4066020)
addappid(4066030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997661, 1, "e9c32558a9b3073d7a33535e53f219071acd9c48e1180848a5a41324fb1f2707")
addappid(4235650, 0, "948a3a95adb53c5b777284978f2903764b606ea8e4842ebd6759e5ed6883f97b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
