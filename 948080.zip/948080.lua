-- Lua provided by RyzenAPI
-- Game: Lights Out

-- MAIN APPLICATION
addappid(948080)

-- MAIN APP DEPOTS / PACKAGES
addappid(948081, 1, "223e6af7a019f91919e97e7da599370c575f7ef6d519ef24e79073f6c43db836")

