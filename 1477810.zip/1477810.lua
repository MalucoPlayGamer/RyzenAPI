-- Lua provided by RyzenAPI
-- Game: 1477810

-- MAIN APPLICATION
addappid(1477810)
-- Game: addappid(1477810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477811, 1, "8acef614beb01a64522565b1a05fa7eb1f000ed6fa3bf68139ead0ff0cb53f64")
