-- Lua provided by RyzenAPI
-- Game: Game: Education

-- MAIN APPLICATION
addappid(1261880)
-- Game: addappid(1261880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261881, 1, "7f389b64bfc88f9659b87d49582efb94764036695b6d06882b72f75243db538b")
