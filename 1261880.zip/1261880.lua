-- Lua provided by RyzenAPI
-- Game: Education

-- MAIN APPLICATION
addappid(1261880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261881, 1, "7f389b64bfc88f9659b87d49582efb94764036695b6d06882b72f75243db538b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
