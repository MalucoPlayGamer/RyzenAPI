-- Lua provided by SkyAPI 
-- Game: Education
addappid(1261880)
addappid(1261881, 1, "7f389b64bfc88f9659b87d49582efb94764036695b6d06882b72f75243db538b")
