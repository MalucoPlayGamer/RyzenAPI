-- Lua provided by RyzenAPI
-- Game: 1173690

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1173690)
addappid(1173691)
-- Game: addappid(1173690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173692,0,"15e8c50fe829ad43fdc1abcb9c4a8f78dd9b28502d227631532ff74755072038")
addtoken(1173690,2728506824098305207)
