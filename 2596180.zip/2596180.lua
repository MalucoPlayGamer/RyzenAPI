-- Lua provided by RyzenAPI
-- Game: Jolly Putt - Mini Golf & Arcade Demo

-- MAIN APPLICATION
addappid(2596180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596181, 1, "f9f7420085c880d55f4a9461f416590d7f4b243b33e9a45f4e3b77be262248fb")
