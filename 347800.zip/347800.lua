-- Lua provided by RyzenAPI
-- Game: Game: AppID 347800

-- MAIN APPLICATION
addappid(347800)
-- Game: addappid(347800)

-- MAIN APP DEPOTS / PACKAGES
addappid(347801, 1, "05ee61d02a4083b4baec88ad7f867938f914091806d07b83ca51dfb5e833cd86")
