-- Lua provided by RyzenAPI
-- Game: P·O·L·L·E·N

-- MAIN APPLICATION
addappid(393750)
-- Game: addappid(393750)

-- MAIN APP DEPOTS / PACKAGES
addappid(393751, 1, "b75aeffcd37f88b29b67787dfdc9788f794e544e5553eea2ba1ca3664a3137cd")
