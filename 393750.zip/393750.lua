-- Lua provided by RyzenAPI
-- Game: P·O·L·L·E·N

-- MAIN APPLICATION
addappid(393750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(393751, 1, "b75aeffcd37f88b29b67787dfdc9788f794e544e5553eea2ba1ca3664a3137cd")

