-- Lua provided by RyzenAPI
-- Game: Zodiac - Hellish Memory

-- MAIN APPLICATION
addappid(1298410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1298411, 1, "6003e3d22aece6ea4f7131d768147a3eb7dfdf29642653bac6f22781c0c9f6c6")

