-- Lua provided by RyzenAPI 
-- Game: AppID 1298410
addappid(1298410)
addappid(1298411, 1, "6003e3d22aece6ea4f7131d768147a3eb7dfdf29642653bac6f22781c0c9f6c6")
