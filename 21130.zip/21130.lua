-- Lua provided by RyzenAPI
-- Game: 21130

-- MAIN APPLICATION
addappid(21130)
addappid(228981)
addappid(228990)
-- Game: addappid(21130)

-- MAIN APP DEPOTS / PACKAGES
addappid(21131, 1, "3ea7510f6573780b2f0ea3a52aaf43c95183f877283383b9af7e65a2699c2f1f")
