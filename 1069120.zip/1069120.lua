-- Lua provided by RyzenAPI 
-- Game: AppID 1069120
addappid(1069120)
addappid(1069121, 1, "f63773487a328e46fd05ad32b267c049a759147b70d74edd377c47bba71f2a9f")
