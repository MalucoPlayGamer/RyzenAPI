-- Lua provided by RyzenAPI
-- Game: 1069120

-- MAIN APPLICATION
addappid(1069120)
-- Game: addappid(1069120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069121, 1, "f63773487a328e46fd05ad32b267c049a759147b70d74edd377c47bba71f2a9f")
