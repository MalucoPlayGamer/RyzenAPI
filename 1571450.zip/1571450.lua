-- Lua provided by SkyAPI 
-- Game: Bear Haven Nights 2
addappid(1571450)
addappid(1571451, 1, "f227c266c795a788d3fe2c0e96a9d2db047da04b0b00ee70e9a245fd46ff070e")
