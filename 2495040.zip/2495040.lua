-- Lua provided by SkyAPI 
-- Game: Electation
addappid(2495040)
addappid(2495041, 1, "afd2310801669a0e048f80e47cf3511ce8510ec8101c2a6fd3d1703277e60658")
