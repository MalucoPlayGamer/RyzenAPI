-- Lua provided by RyzenAPI
-- Game: Game: Electation

-- MAIN APPLICATION
addappid(2495040)
-- Game: addappid(2495040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495041, 1, "afd2310801669a0e048f80e47cf3511ce8510ec8101c2a6fd3d1703277e60658")
