-- Lua provided by RyzenAPI
-- Game: 643390

-- MAIN APPLICATION
addappid(643390)

-- MAIN APP DEPOTS / PACKAGES
addappid(643390,0,"9dac7ecfa0bcef7ccfd67c064f273521e81526139cae51bc15d17c93997dd06d")
