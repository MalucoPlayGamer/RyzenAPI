-- Lua provided by RyzenAPI 
-- Game: POG 8
addappid(2063240)
addappid(2063241, 1, "742fec0784ced2333a3ac8173408ca52ef36184c41ac5f0e8bc89ab3d86c1b35")
