-- Lua provided by RyzenAPI
-- Game: 2063240

-- MAIN APPLICATION
addappid(2063240)
-- Game: addappid(2063240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063241, 1, "742fec0784ced2333a3ac8173408ca52ef36184c41ac5f0e8bc89ab3d86c1b35")
