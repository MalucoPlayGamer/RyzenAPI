-- Lua provided by RyzenAPI
-- Game: Ariel’s Daily Grind

-- MAIN APPLICATION
addappid(1933670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933671, 1, "dceb885aa88b490ca0dd6dd95a46167539ac50f08f4a1ce5063399c73706b423")
addappid(1933672, 1, "a3306302abefdf6201c35436a0a6a8aabdc0f64d0902ddfbabd3ef901fd4247d")
addappid(1933673, 1, "e9436f9272eb90f7141dc597dc79a15bde3a0dc49fdf31fb82d70e7abc2d67ad")
