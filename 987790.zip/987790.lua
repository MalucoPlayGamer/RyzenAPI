-- Lua provided by RyzenAPI
-- Game: AppID 987790

-- MAIN APPLICATION
addappid(987790)
addappid(988740)
-- Game: addappid(987790)

-- MAIN APP DEPOTS / PACKAGES
addappid(987791, 1, "a475667c1aa2e25ec57dca8bbcfe25b1d49021459ba7052519a21ba92902f79a")
