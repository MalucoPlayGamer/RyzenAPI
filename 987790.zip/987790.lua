-- Lua provided by RyzenAPI
-- Game: Call Of Pixel: Close Quarters

-- MAIN APPLICATION
addappid(987790)
addappid(988740)
addappid(1044660)
addappid(1044661)
addappid(1044662)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(987791, 1, "a475667c1aa2e25ec57dca8bbcfe25b1d49021459ba7052519a21ba92902f79a")
