-- Lua provided by RyzenAPI
-- Game: addappid(1022362)

-- MAIN APPLICATION
addappid(1022362)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022362,0,"fca2438cada9fa9d7c5af0bea5c62183fae901bb1cb04b2288f6b346ac7e8583")
