-- Lua provided by SkyAPI 
-- Game: The Secret Fake Ring
addappid(3750660)
addappid(3750661, 1, "17eb5f3163d0283a496bd11d6d38e69e43030c17196c39cbec141012982a671e")
