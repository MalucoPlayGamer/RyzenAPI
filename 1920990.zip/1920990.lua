-- Lua provided by RyzenAPI
-- Game: U-ena Character Song Collection

-- MAIN APPLICATION
addappid(1920990)
addappid(1920991)
addappid(1920992)
addappid(1920995)
addappid(1920996)
addappid(1920997)
addappid(1920998)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920993,0,"0ccb8413bfa8266b782088691c5ef937254cf6a94eb13656e6071132e6a13886")
addappid(1920994,0,"1bfa5ad11f63a1a633e16e1a017848f2a7902e48546f358407efcd728f944336")

