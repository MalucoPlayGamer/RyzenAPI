-- Lua provided by RyzenAPI
-- Game: Lana and the Milking Table

-- MAIN APPLICATION
addappid(2303410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303411, 1, "946d9a4b4f157daa2516da7c00ffd4c99d57700a0c1c7a67a60bd220a9094268")

