-- Lua provided by RyzenAPI
-- Game: Game: Hot Tentacles Shooter

-- MAIN APPLICATION
addappid(1942080)
-- Game: addappid(1942080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942081, 1, "a2ad9279d52a34313daa3380a055e7e400b9735ae4096a0ce19fded2fe82448c")
