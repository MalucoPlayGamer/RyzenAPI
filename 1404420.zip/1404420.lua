-- Lua provided by RyzenAPI
-- Game: MECHBLAZE Demo

-- MAIN APPLICATION
addappid(1404420)
-- Game: addappid(1404420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404421, 1, "5068ebf285ca7b6b42f32fc45b912aa8f5826de93b8e439c4857957c67d6b834")
addappid(1404423, 1, "8899ba100dccc197ab13c81b5ab322fc0953e4bb63987fd7f34cde83bcd119ab")
