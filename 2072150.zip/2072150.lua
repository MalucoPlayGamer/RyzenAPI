-- Lua provided by RyzenAPI
-- Game: Game: Kairobotica

-- MAIN APPLICATION
addappid(2072150)
-- Game: addappid(2072150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072151, 1, "1eda0fccd34956935ffda982478361b2d06f0dd7cd18107f27412419b41aa4a5")
