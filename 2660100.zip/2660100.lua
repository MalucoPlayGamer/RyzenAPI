-- Lua provided by RyzenAPI
-- Game: Cake Game

-- MAIN APPLICATION
addappid(2660100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2660101, 1, "dc9c06914db9487f787a709466f5d39096c7abe5bcb568c35649b5f4736e0ad6")
addappid(2660103, 1, "a2ff0c15f76ffbb844b16f5c18c3cfc979e65f61c9194be6af19cc7e16924613")

