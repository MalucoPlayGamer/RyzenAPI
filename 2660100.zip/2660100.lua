-- Lua provided by RyzenAPI
-- Game: Game: Cake Game

-- MAIN APPLICATION
addappid(2660100)
-- Game: addappid(2660100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660101, 1, "dc9c06914db9487f787a709466f5d39096c7abe5bcb568c35649b5f4736e0ad6")
addappid(2660103, 1, "a2ff0c15f76ffbb844b16f5c18c3cfc979e65f61c9194be6af19cc7e16924613")
