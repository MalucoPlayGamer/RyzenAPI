-- Lua provided by RyzenAPI
-- Game: WWII Tanks: Forgotten Battles

-- MAIN APPLICATION
addappid(2126500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126501, 1, "aab753b652b7ceb60b16e544c4f089ad827ff01296da87a4803507df60730ba5")
