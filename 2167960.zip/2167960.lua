-- Lua provided by RyzenAPI
-- Game: Buy a Croquette!

-- MAIN APPLICATION
addappid(2167960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167961, 1, "78200fa30dedb302ff83b7f427483b788bed995009b59303c2ca729d05d83309")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2616280)
addappid(2888970)
