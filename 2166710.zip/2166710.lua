-- Lua provided by RyzenAPI
-- Game: Game: Fabric Of Reality

-- MAIN APPLICATION
addappid(2166710)
-- Game: addappid(2166710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166711, 1, "28a00be9c911dcf28aafaedfb91e7203fdb86d747ccc93417e24ebb817ff7e8c")
