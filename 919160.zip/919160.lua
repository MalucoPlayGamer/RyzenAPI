-- Lua provided by RyzenAPI
-- Game: 919160

-- MAIN APPLICATION
addappid(919160)
-- Game: addappid(919160)

-- MAIN APP DEPOTS / PACKAGES
addappid(919161, 1, "59e01e99048ed2d1ddfe711a813b352c57cfca98b1e0b1e352c1e6ab8c1567e7")
