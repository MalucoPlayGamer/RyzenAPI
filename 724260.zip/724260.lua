-- Lua provided by RyzenAPI 
-- Game: Princess Maker Go!Go! Princess
addappid(724260)
addappid(724261, 1, "11b5c302a1d22b4ef13f53c5a96384ec83114ac523e4294cca0a3c5b5a118139")
