-- Lua provided by RyzenAPI
-- Game: 724260

-- MAIN APPLICATION
addappid(724260)
-- Game: addappid(724260)

-- MAIN APP DEPOTS / PACKAGES
addappid(724261, 1, "11b5c302a1d22b4ef13f53c5a96384ec83114ac523e4294cca0a3c5b5a118139")
