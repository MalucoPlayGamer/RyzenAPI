-- Lua provided by RyzenAPI
-- Game: NightShift

-- MAIN APPLICATION
addappid(1484340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484344,0,"16699ac67cbe7998c71d91d9e8724482bd0291aee89207a45ec5679df4d1dec9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
