-- Lua provided by RyzenAPI
-- Game: NightShift

-- MAIN APPLICATION
addappid(1484340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484344,0,"16699ac67cbe7998c71d91d9e8724482bd0291aee89207a45ec5679df4d1dec9")
