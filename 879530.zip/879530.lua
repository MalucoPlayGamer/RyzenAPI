-- Lua provided by RyzenAPI
-- Game: Thunderbowl

-- MAIN APPLICATION
addappid(879530)

-- MAIN APP DEPOTS / PACKAGES
addappid(879531,0,"3b1fe1d18bf9958218798ef7e33ef3b295d1a6ed9b7766691ac304ee3824590a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
