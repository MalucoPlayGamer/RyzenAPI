-- Lua provided by RyzenAPI
-- Game: The Underground Watcher/地下监察员

-- MAIN APPLICATION
addappid(1059090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059091, 1, "985ea3e314b7799a5309575daa6f42783b1ff6930c4691241dde3c6369d7387b")

