-- Lua provided by RyzenAPI 
-- Game: AppID 217790
addappid(217790)
addappid(217791, 1, "942dafc1da2054aa371226cec3a5414cb15d69f7a5c979e01c4f00fd0cf228e6")
