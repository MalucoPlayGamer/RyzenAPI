-- Lua provided by RyzenAPI
-- Game: Game: AppID 2066960

-- MAIN APPLICATION
addappid(2066960)
-- Game: addappid(2066960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066961, 1, "96b33d872551fc70353655a29aa4d6211d3c9ec6373a6b9249600c988dee965b")
