-- Lua provided by RyzenAPI
-- Game: 717760

-- MAIN APPLICATION
addappid(717760)
-- Game: addappid(717760)

-- MAIN APP DEPOTS / PACKAGES
addappid(717761, 1, "2eace4d69aacd0fb3e93aea4b718906214bf539ba43e9beced03287ef7e80a85")
