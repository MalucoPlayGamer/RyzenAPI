-- Lua provided by RyzenAPI
-- Game: Catch the Thief, If you can!

-- MAIN APPLICATION
addappid(717760)

-- MAIN APP DEPOTS / PACKAGES
addappid(717761, 1, "2eace4d69aacd0fb3e93aea4b718906214bf539ba43e9beced03287ef7e80a85")
