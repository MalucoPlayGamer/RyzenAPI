-- Lua provided by RyzenAPI
-- Game: Game: Eufloria HD

-- MAIN APPLICATION
addappid(221180)
-- Game: addappid(221180)

-- MAIN APP DEPOTS / PACKAGES
addappid(221181, 1, "7e31bdf78eda08ea4277b1e2c80f8baca85e06d525dffb0e9b0ca03a67f2ecc9")
addappid(221182, 1, "cb2aa9bbd49ae96dc21f3ee90b0ae27eb4182b9cf90b946081d09c4e2820e29b")
addappid(221183, 1, "be9dd5b2b99d724a47a5501473d308c1a51ba9b7bae5c312d81328bdcaf08069")
addappid(327040, 0, "14b048a6a4a96fbcb07310038ff56a41e36116fb890d44d46eeca9446a9b7376")
