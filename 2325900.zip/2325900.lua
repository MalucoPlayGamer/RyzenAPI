-- Lua provided by RyzenAPI
-- Game: addappid(2325900)

-- MAIN APPLICATION
addappid(2325900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325901, 1, "6634839fc21d17e4478c9e3e9b98be9e07a7d7d290b9011a38d12b0d7f1b1316")
