-- Lua provided by RyzenAPI
-- Game: Company of Crime

-- MAIN APPLICATION
addappid(1229420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229421, 1, "0265d72cc2564a6ecbada65c3d649cd154aeeafaeae972110e3f1ffa7aba5954")
addappid(1229422, 1, "7ce13a17e33b90efb8f8689ed63554ffe1a235e1b9b3d537defc5a4405becbe3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
