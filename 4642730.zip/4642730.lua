-- Lua provided by RyzenAPI
-- Game: Optical Shop Simulator

-- MAIN APPLICATION
addappid(4642730) -- Optical Shop Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4642731, 1, "bea941704f831069eaa34578d7c47830e82750c3c7d5117c46595d9142b6598b") -- Depot 4642731

