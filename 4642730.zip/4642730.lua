-- 4642730's Lua and Manifest Created by Hubcap Manifest
-- Optical Shop Simulator
-- Created: June 16, 2026 at 04:25:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4642730) -- Optical Shop Simulator
-- MAIN APP DEPOTS
addappid(4642731, 1, "bea941704f831069eaa34578d7c47830e82750c3c7d5117c46595d9142b6598b") -- Depot 4642731
-- setManifestid(4642731, "4403729424555100993", 1953923141)