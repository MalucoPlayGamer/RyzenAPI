-- Lua provided by SkyAPI 
-- Game: The Damathos Clan
addappid(1532680)
addappid(1532681, 1, "643714b0fa229e75d8b33070c3446b17e31732b22bb2d0df8504b336b03b492d")
addappid(1551380)
