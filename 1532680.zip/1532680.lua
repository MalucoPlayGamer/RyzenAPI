-- Lua provided by RyzenAPI
-- Game: The Damathos Clan

-- MAIN APPLICATION
addappid(1532680)
addappid(1551380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532681, 1, "643714b0fa229e75d8b33070c3446b17e31732b22bb2d0df8504b336b03b492d")

