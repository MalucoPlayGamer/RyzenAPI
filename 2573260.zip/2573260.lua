-- Lua provided by SkyAPI 
-- Game: 古代风流传
addappid(2573260)
addappid(2573261, 1, "ea798115c16ae370252c9044badb90199076d754899c9ec79c67a9c393ae8cad")
addappid(2770260, 0, "db3817fab80a08a17640fb4e73ac849c3ae1eb1e299f4b7b60c1c3368033609a")
