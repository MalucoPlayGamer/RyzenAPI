-- Lua provided by RyzenAPI 
-- Game: Project Dark
addappid(2323280)
addappid(2323281, 1, "d7aeec551c31c3d24d5aa7dee17499c573368c79f5508c14a4df45f610c2f132")
