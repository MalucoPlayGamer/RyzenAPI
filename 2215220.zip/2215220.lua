-- Lua provided by RyzenAPI
-- Game: Game: Jewel Match Winter Wonderland 2 Collector's Edition

-- MAIN APPLICATION
addappid(2215220)
-- Game: addappid(2215220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215221, 1, "300b313ead07074f7e153508080060277afd32f7665be326e6f1d76d0de7aa37")
