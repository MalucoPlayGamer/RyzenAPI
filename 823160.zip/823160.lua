-- Lua provided by RyzenAPI 
-- Game: Knife Hit Dash
addappid(823160)
addappid(823161, 1, "955aa05b6512884a60c974af7c1c2826cda9b8e01d42246afe43edc816be9cc4")
