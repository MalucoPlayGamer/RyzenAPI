-- Lua provided by RyzenAPI
-- Game: 1025330

-- MAIN APPLICATION
addappid(1025330)
-- Game: addappid(1025330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025331, 1, "37023c1c8e072d651f6c998bb169ce11ab65039af449aaea4105abae7f31b505")
