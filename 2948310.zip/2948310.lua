-- Lua provided by RyzenAPI
-- Game: The House of Da Vinci VR

-- MAIN APPLICATION
addappid(2948310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948312,0,"47ebaf168c8e72cd7fce30286c6d2dcfb572fdb3b18b93bd119046aec5c21c47")

