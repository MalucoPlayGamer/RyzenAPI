-- Lua provided by RyzenAPI
-- Game: 机械之围Mechanical Besiege

-- MAIN APPLICATION
addappid(2784360)
-- Game: addappid(2784360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784361, 1, "88316899b20fb9132df7e94412be57dd9a415257f448fe680191aa413f848045")
