-- Lua provided by RyzenAPI
-- Game: Trends

-- MAIN APPLICATION
addappid(944730)
-- Game: addappid(944730)

-- MAIN APP DEPOTS / PACKAGES
addappid(944732,0,"d16500d7e49931146b3d9ef06aff133b4a27792bdd3c26caf5142e6b07d6b9d5")
addappid(944733,0,"233d72c27772b306fc1a1dd71082037f5161df952e19818b65e85d9fd29276ec")
addappid(944734,0,"04eeefbf4097d1dd726b64d2cb1838f2cd1fc077dc34d6e6ca03a5cce1285aae")
