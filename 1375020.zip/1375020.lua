-- Lua provided by RyzenAPI
-- Game: addappid(1375020)

-- MAIN APPLICATION
addappid(1375020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375021, 1, "c872adca418ab2f0c6150194cfad29c0674f8e208b017afb6e4f2fc66a57ad1e")
