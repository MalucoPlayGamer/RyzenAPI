-- Lua provided by RyzenAPI
-- Game: LUFTRAUSERS

-- MAIN APPLICATION
addappid(233150)

-- MAIN APP DEPOTS / PACKAGES
addappid(233151, 1, "71a463960fcc3226fbb7c5a78f07be72773fb568a995aa9a797e0640fc54bb5a")
addappid(233152, 1, "9c76439e9e63c26523ccbad1f027159813509134735adfc647675fa27ec97abe")
addappid(233153, 1, "b3518ab2f6d8fbcb3ff303a3ac3b508c69aac429626f5802fcd2f8897bb1d309")
addappid(233154, 1, "86cefe2b13fb8ca8f4b42eb7c1c775cbd116e7b91213566921711a4698d9a8cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
