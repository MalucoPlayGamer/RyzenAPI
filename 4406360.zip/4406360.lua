-- Lua provided by RyzenAPI
-- Game: The Abandoned House in Yeongdeok

-- MAIN APPLICATION
addappid(4406360) -- The Abandoned House in Yeongdeok

-- MAIN APP DEPOTS / PACKAGES
addappid(4406361, 1, "89a11b9f1f5b1647cd6aca712403ae4c8f70eb44db37adbd196ca43d06cab9da") -- Depot 4406361
