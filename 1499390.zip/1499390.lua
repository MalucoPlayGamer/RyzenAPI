-- Lua provided by RyzenAPI
-- Game: 1499390

-- MAIN APPLICATION
addappid(1499390)
-- Game: addappid(1499390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499390,0,"711858e6359a5135caae92896fa7b14d7d77e48d66af5b4721fd4f948f2a7e8e")
