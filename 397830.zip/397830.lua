-- Lua provided by RyzenAPI
-- Game: 397830

-- MAIN APPLICATION
addappid(397830)
-- Game: addappid(397830)

-- MAIN APP DEPOTS / PACKAGES
addappid(397831, 1, "2ecc87d99150eae38f25b070112e7700c17013020346f9acf969b1fc41f219fe")
