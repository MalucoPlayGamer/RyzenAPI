-- Lua provided by RyzenAPI
-- Game: Kiloton

-- MAIN APPLICATION
addappid(3488900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3488901, 1, "a5c263d7b2484145c3bca4a347c1165d5fcad6608d07b095384134d0ee19f028")
