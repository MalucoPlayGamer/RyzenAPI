-- Lua provided by RyzenAPI 
-- Game: Evil Hazard
addappid(403440)
addappid(403441, 1, "91098b3397002884b27687be99376fdbcddbad17445f53d6b2c9c13f9a08f767")
