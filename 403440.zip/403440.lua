-- Lua provided by RyzenAPI
-- Game: Evil Hazard

-- MAIN APPLICATION
addappid(403440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(403441, 1, "91098b3397002884b27687be99376fdbcddbad17445f53d6b2c9c13f9a08f767")

