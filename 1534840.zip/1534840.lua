-- Lua provided by RyzenAPI
-- Game: Hyper Light Breaker

-- MAIN APPLICATION
addappid(1534840)
-- Game: addappid(1534840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534841, 1, "faf4cabdfd4a2697de90722f8b1f942bf0f46e34b1bc28021eebb2a0c642e612")
