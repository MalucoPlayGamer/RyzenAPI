-- Lua provided by RyzenAPI
-- Game: Game: SUMMERHOUSE

-- MAIN APPLICATION
addappid(2533960)
-- Game: addappid(2533960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533961, 1, "f86e334e3dd48c9c37a0aa065ced6c304c57c4da46262cd98915d5115b97403a")
addappid(2533962, 1, "1a1904ae6cb48aa7f73c63d14f9f0758c262c8e0d35b7b402d381e259a9eb5ee")
