-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2227400)
addappid(2227404)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227403,0,"662278a84d72beaa124d127df050f9896f36cd1f64c35f11542dee5ad6212b2c")
