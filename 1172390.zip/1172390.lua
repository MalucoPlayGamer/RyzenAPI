-- Lua provided by RyzenAPI
-- Game: Game: AppID 1172390

-- MAIN APPLICATION
addappid(1172390)
-- Game: addappid(1172390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172391, 1, "a7a2af03b812848b1aaa4523a14c95cecf6b3f9d3b1b92253cdef2209a3bb8ad")
