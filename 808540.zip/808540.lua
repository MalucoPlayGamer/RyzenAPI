-- Lua provided by RyzenAPI
-- Game: GATARI: Sand on Teeth

-- MAIN APPLICATION
addappid(808540)

-- MAIN APP DEPOTS / PACKAGES
addappid(808541, 1, "1bf14073cf28da6fa207de90e0ff037ef3e68e199ad4813d252fa4c59742dad4")
