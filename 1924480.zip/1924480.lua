-- Lua provided by RyzenAPI
-- Game: College Kings 2 - Episode 1

-- MAIN APPLICATION
addappid(1924480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924481, 1, "ff635112056ca80dc0760a59372d872768946344dc5d10a5e63676f081245cf7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1929620)
addappid(2100540)
addappid(2141200)
addappid(2141201)
addappid(2164670)
addappid(2267960)
addappid(2725540)
addappid(3126690)
addappid(3780980)
