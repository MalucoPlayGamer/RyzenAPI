-- Lua provided by RyzenAPI
-- Game: setManifestid(1191513,"3908578498125658289")

-- MAIN APPLICATION
addappid(1191510)
-- Game: addappid(1191510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191513,0,"c93ac8e1a26eb7f575f4b35f1019a91ee353dc88a861a0dd91443ef2f2c1f43f")
