-- Lua provided by RyzenAPI
-- Game: PixHunter

-- MAIN APPLICATION
addappid(1191510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191513,0,"c93ac8e1a26eb7f575f4b35f1019a91ee353dc88a861a0dd91443ef2f2c1f43f")

