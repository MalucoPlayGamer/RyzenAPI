-- Lua provided by RyzenAPI
-- Game: NejicomiSimulator: Tayuyu's Audio Drama 01 -Busty waitresses serve you in a quiet maid café-

-- MAIN APPLICATION
addappid(2899570)
-- Game: addappid(2899570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899571, 1, "dff8c64bf7cc4b3983cfd5302ab549d5f094c94366f84cb665a1e9126b05a557")
addappid(2899572, 1, "6cadb961c4ab12fe0d20e8bab8ce1bc49c4cec14ebbf1753d2851cf937f41871")
