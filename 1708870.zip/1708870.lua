-- Lua provided by RyzenAPI
-- Game: 第七号列车 - Train No. 7

-- MAIN APPLICATION
addappid(1708870)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1742150)
