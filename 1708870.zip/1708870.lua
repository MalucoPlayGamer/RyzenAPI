-- Lua provided by RyzenAPI
-- Game: 第七号列车 - Train No. 7

-- MAIN APPLICATION
addappid(1708870)

