-- Lua provided by RyzenAPI
-- Game: Game: Find Out

-- MAIN APPLICATION
addappid(444410)
-- Game: addappid(444410)

-- MAIN APP DEPOTS / PACKAGES
addappid(444411, 1, "2c47d33d40ceb7708ffd5509cff1bca79e3c3276084b88140914a7b56680b555")
