-- Lua provided by RyzenAPI
-- Game: EmoteLab

-- MAIN APPLICATION
addappid(4301100)

-- MAIN APP DEPOTS / PACKAGES
addappid(4301100,0,"dab9ca3fab0fe8de28715a735732a6f267eeb9e4c1dc89a16404cd903a46dbf2")
addappid(4301101,0,"105a374546721c601f011470a3d2a6ee8770ae45adacf103ac0013a15bfd95fc")

