-- Lua provided by RyzenAPI
-- Game: EmoteLab

-- MAIN APPLICATION
addappid(4301100)
-- Game: addappid(4301100)

-- MAIN APP DEPOTS / PACKAGES
addappid(4301101, 1, "105a374546721c601f011470a3d2a6ee8770ae45adacf103ac0013a15bfd95fc")
