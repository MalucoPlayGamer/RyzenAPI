-- Lua provided by RyzenAPI
-- Game: addappid(2690860)

-- MAIN APPLICATION
addappid(2690860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690861, 1, "cecabbb760bfba3e1264f1d780b025148ccf5711d8d88b4fb9cb071788d569a7")
