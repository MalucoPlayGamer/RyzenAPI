-- Lua provided by RyzenAPI
-- Game: Game: The Unseen Fears: Ominous Talent Collector's Edition

-- MAIN APPLICATION
addappid(1228860)
-- Game: addappid(1228860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228861, 1, "ed2c3499a8e12b5379a9b74d6c9aa92854cfaf3fd2a5320418a6b827a3da2986")
