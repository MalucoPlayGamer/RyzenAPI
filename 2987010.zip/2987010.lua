-- Lua provided by RyzenAPI
-- Game: addappid(2987010)

-- MAIN APPLICATION
addappid(2987010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987011, 1, "14f5b36677a60565a0355674ffcca0e1edbc572a021cfeb9fdaebedee46a8f2a")
