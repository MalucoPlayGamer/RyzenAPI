-- Lua provided by RyzenAPI
-- Game: setManifestid(1451882,"2481731833832737962")

-- MAIN APPLICATION
addappid(1451880)
-- Game: addappid(1451880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451882,0,"5d1880193c8b37770d932bfa2e674b55cdf90beedfeae29b4ac183e79a76671d")
