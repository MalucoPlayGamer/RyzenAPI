-- Lua provided by RyzenAPI
-- Game: addappid(1451880)

-- MAIN APPLICATION
addappid(1451880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451882,0,"5d1880193c8b37770d932bfa2e674b55cdf90beedfeae29b4ac183e79a76671d")
