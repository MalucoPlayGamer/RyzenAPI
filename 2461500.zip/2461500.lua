-- Lua provided by RyzenAPI
-- Game: addappid(2461500)

-- MAIN APPLICATION
addappid(2461500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461501, 1, "31e20230c57a6787381e0111a2b49d3c8278f7af2f0a93b89a6ff35c91dfed0d")
