-- Lua provided by RyzenAPI
-- Game: addappid(3272530)

-- MAIN APPLICATION
addappid(3272530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272531, 1, "07cfe6ffe16bcc0caaad67dbf05c9d9e074b011bbb3ef0ab84b5f7dab2f2e813")
