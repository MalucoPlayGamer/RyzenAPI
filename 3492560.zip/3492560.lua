-- Lua provided by RyzenAPI
-- Game: addappid(3492560)

-- MAIN APPLICATION
addappid(3492560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492561, 1, "23073fadc9627bdc5a797a78e1d3dcc519eef1b99cc1afc82beea77bfa67e058")
