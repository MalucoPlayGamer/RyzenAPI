-- Lua provided by RyzenAPI
-- Game: 1425010

-- MAIN APPLICATION
addappid(1425010)
-- Game: addappid(1425010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425011, 1, "87fee11312d6afbcd30710c026be7125cc08ff8b5c917cf8e1a20817a64f3ec6")
