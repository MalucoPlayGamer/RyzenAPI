-- Lua provided by RyzenAPI
-- Game: Pool Slide Story

-- MAIN APPLICATION
addappid(1933980)
-- Game: addappid(1933980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933981, 1, "1d21a510a967e983fbd257e622cc6e56d897f52adba93ae9d58b6e26c5510222")
