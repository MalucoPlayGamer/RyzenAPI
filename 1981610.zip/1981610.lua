-- Lua provided by RyzenAPI
-- Game: Wanted: Dead

-- MAIN APPLICATION
addappid(1981610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1981611, 1, "971d000cf3b857bf1088d03afb8fb9722e61691687b5eca11f2444d52f7b0230")
addappid(1981612, 1, "26ecb7650c060f90017a65afb157318e37ceb0b10ea70110a3fcf5bacc5e08bd")

