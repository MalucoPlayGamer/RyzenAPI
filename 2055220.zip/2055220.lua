-- Lua provided by RyzenAPI 
-- Game: Desktop Girlfriend
addappid(2055220)
addappid(2055221, 1, "043cfe5b63197afa01d1d54c59d2f2a27c6e15c42d1385bd1fa7a1b9427e72b7")
addappid(2115450, 0, "2c75fb98306cbc87115aa1b41830a8e8541a0973f5256d0706f6acd98a7cbeaf")
