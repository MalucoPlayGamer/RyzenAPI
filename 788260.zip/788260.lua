-- Lua provided by RyzenAPI
-- Game: Game: Rules Of Survival

-- MAIN APPLICATION
addappid(788260)
-- Game: addappid(788260)

-- MAIN APP DEPOTS / PACKAGES
addappid(788261, 1, "f33bca6ee7dbf73dac3a15d2c405b6c0deda2c8df4b6a07410f65319b166ffb1")
