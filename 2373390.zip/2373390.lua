-- Lua provided by RyzenAPI
-- Game: Game: VVAV ONE

-- MAIN APPLICATION
addappid(2373390)
-- Game: addappid(2373390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373391, 1, "fbaef81328c242719c00620b181156e5312427c7b37164ee4e2c741275f1d90a")
