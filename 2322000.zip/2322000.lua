-- Lua provided by RyzenAPI
-- Game: Sugar Shack Demo

-- MAIN APPLICATION
addappid(2322000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322001, 1, "96a8b3c7cb6c5471399cb5f86c5c20a614e84699e7d9443786d959eea4713ad1")
