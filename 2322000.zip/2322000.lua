-- Lua provided by RyzenAPI 
-- Game: AppID 2322000
addappid(2322000)
addappid(2322001, 1, "96a8b3c7cb6c5471399cb5f86c5c20a614e84699e7d9443786d959eea4713ad1")
