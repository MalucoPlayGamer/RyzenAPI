-- Lua provided by RyzenAPI
-- Game: addappid(333870)

-- MAIN APPLICATION
addappid(333870)

-- MAIN APP DEPOTS / PACKAGES
addappid(333871, 1, "25fa40380f6f43dee951bb605000a9e8b3aee90cf110b211b9e427be3437c5ab")
