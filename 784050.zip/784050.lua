-- Lua provided by RyzenAPI
-- Game: 784050

-- MAIN APPLICATION
addappid(784050)
-- Game: addappid(784050)

-- MAIN APP DEPOTS / PACKAGES
addappid(784051, 1, "e83a10f2678ae45d878bd7de989c1f663bdcdea7d285c6ea92aa44a78e3c4a4b")
