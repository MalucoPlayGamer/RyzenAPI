-- Lua provided by RyzenAPI
-- Game: Game: The Elf Maiden

-- MAIN APPLICATION
addappid(1989230)
-- Game: addappid(1989230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989231, 1, "c0b3cd1925f6622963d9c145a129a84195c918244b883fad0082f9a19d603430")
