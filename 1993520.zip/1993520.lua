-- Lua provided by RyzenAPI
-- Game: Seasons

-- MAIN APPLICATION
addappid(1993520)
-- Game: addappid(1993520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993521, 1, "77b52573b0f0f3f25f5f141e1b3a54f8876749088bca88e90664582fe8d7150e")
