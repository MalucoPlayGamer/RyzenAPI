-- Lua provided by RyzenAPI
-- Game: 噬元之主

-- MAIN APPLICATION
addappid(868320)

-- MAIN APP DEPOTS / PACKAGES
addappid(868321, 1, "7b5e04e49033c65c8599bdc1df5006ef2494dd333a14b23f37d9c03bd00ee166")

