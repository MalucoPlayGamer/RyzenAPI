-- 4297110's Lua and Manifest Created by Hubcap Manifest
-- Hopping Out
-- Created: August 05, 2026 at 22:44:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4297110) -- Hopping Out
-- MAIN APP DEPOTS
addappid(4297111, 1, "b8c76bdc9d3f5b4aa6fb6c3ed430a09c7f015c9509c3586907e0a6d2bf7d4e43") -- Depot 4297111
setManifestid(4297111, "7198353567924706273", 264992646)