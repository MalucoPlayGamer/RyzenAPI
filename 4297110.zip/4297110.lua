-- Lua provided by RyzenAPI
-- Game: Hopping Out

-- MAIN APPLICATION
addappid(4297110) -- Hopping Out

-- MAIN APP DEPOTS / PACKAGES
addappid(4297111, 1, "b8c76bdc9d3f5b4aa6fb6c3ed430a09c7f015c9509c3586907e0a6d2bf7d4e43") -- Depot 4297111

