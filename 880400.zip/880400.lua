-- Lua provided by RyzenAPI
-- Game: 880400

-- MAIN APPLICATION
addappid(880400)
-- Game: addappid(880400)

-- MAIN APP DEPOTS / PACKAGES
addappid(880401, 1, "9d983aac7e110b0d6a9145a96f86d216014758505e2f9fb58083522c8ee17472")
addappid(898190, 0, "29a42ab81b3c7c4beebf3323ad33deba0acc1e81297609ce3652a197af9dcd63")
