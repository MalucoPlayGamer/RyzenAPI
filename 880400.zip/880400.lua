-- Lua provided by RyzenAPI
-- Game: Lingering Fragrance

-- MAIN APPLICATION
addappid(880400)

-- MAIN APP DEPOTS / PACKAGES
addappid(880401, 1, "9d983aac7e110b0d6a9145a96f86d216014758505e2f9fb58083522c8ee17472")
addappid(898190, 0, "29a42ab81b3c7c4beebf3323ad33deba0acc1e81297609ce3652a197af9dcd63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
