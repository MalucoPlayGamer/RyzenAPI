-- Lua provided by RyzenAPI
-- Game: AppID 897290

-- MAIN APPLICATION
addappid(897290)
-- Game: addappid(897290)

-- MAIN APP DEPOTS / PACKAGES
addappid(897291, 1, "53b7c0568cb2e13e85b0322fbfcea1e1e9cd50230fd5fece4ffc8a8067d58203")
