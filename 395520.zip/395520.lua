-- Lua provided by RyzenAPI
-- Game: Missing Translation

-- MAIN APPLICATION
addappid(395520)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(395530)
