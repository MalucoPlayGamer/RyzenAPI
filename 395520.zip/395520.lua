-- Lua provided by RyzenAPI
-- Game: Missing Translation

-- MAIN APPLICATION
addappid(395520)
