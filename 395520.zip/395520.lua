-- Lua provided by RyzenAPI
-- Game: Missing Translation

-- MAIN APPLICATION
addappid(395520)
addappid(395530)

