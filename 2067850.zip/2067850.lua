-- Lua provided by RyzenAPI
-- Game: Drakensang Online

-- MAIN APPLICATION
addappid(2067850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067851, 1, "4c5cb75d0ab002bb46a982c30466b126dadd60647532272e372b2a7e21d76541")

