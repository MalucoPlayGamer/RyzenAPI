-- Lua provided by RyzenAPI
-- Game: 2384730

-- MAIN APPLICATION
addappid(2384730)
-- Game: addappid(2384730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384732,0,"b2d1cccdc286021b1329be0374318889746aea5760d749ee71e991857e24abfe")
