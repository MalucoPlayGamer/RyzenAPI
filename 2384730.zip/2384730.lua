-- Lua provided by RyzenAPI
-- Game: Beyond the Ice Palace 2

-- MAIN APPLICATION
addappid(2384730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384732,0,"b2d1cccdc286021b1329be0374318889746aea5760d749ee71e991857e24abfe")
