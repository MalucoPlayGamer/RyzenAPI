-- Lua provided by RyzenAPI
-- Game: NEKOPARA Vol. 0

-- MAIN APPLICATION
addappid(385800)

-- MAIN APP DEPOTS / PACKAGES
addappid(385801, 1, "5dd3b7827073de8f0ae56600bfc3c5bd21048b189bb2b7187df8f9e43d0f3d2e")
addappid(1088330, 0, "03026fc24573c714164577f75b1804481a04d8966f927be759f494d06141a8cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
