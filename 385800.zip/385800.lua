-- Lua provided by RyzenAPI 
-- Game: NEKOPARA Vol. 0
addappid(385800)
addappid(385801, 1, "5dd3b7827073de8f0ae56600bfc3c5bd21048b189bb2b7187df8f9e43d0f3d2e")
addappid(1088330, 0, "03026fc24573c714164577f75b1804481a04d8966f927be759f494d06141a8cc")
