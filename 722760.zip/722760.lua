-- Lua provided by RyzenAPI
-- Game: AppID 722760

-- MAIN APPLICATION
addappid(722760)

-- MAIN APP DEPOTS / PACKAGES
addappid(722761, 1, "aa07e989bce0248edb93dd936bff9047bff36da64b570a061a632af1edfb2456")
addappid(722762, 1, "48b5fb1a7cced1b97f775966eabaf3b8f990f8066d4bf38cf83ed8bf743cb245")
addappid(722763, 1, "5ac28e50fcb1881d9985f48fec945f49c75531a6bc3e839fccbd998d91fee0cd")
addappid(722770, 1, "f4ef46ded67f2e97f815a62e6aadfa74a10b7cecb4f6cb4cbe1c8f1733f82d21")
addappid(831920, 0, "03cff94f4f2d5e377d6fac42f2c4a2164708a0e51214430679295bf7a798a4d9")
