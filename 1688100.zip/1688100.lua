-- Lua provided by RyzenAPI
-- Game: Cat Museum

-- MAIN APPLICATION
addappid(1688100)
-- Game: addappid(1688100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688101, 1, "7fd078321337504291eb3f65a8a2303d2a325d3a11320f2e559f9a576808318d")
