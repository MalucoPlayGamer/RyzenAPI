-- Lua provided by SkyAPI 
-- Game: Cat Museum
addappid(1688100)
addappid(1688101, 1, "7fd078321337504291eb3f65a8a2303d2a325d3a11320f2e559f9a576808318d")
