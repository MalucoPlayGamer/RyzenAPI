-- Lua provided by RyzenAPI
-- Game: addappid(691190)

-- MAIN APPLICATION
addappid(691190)

-- MAIN APP DEPOTS / PACKAGES
addappid(691191, 1, "075ffc79c19b7c25b0a910fd426fcf39faa4a53aa27c9693cd46897dcb00ba8e")
