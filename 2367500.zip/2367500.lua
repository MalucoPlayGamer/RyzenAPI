-- Lua provided by RyzenAPI
-- Game: Chrono Crystal

-- MAIN APPLICATION
addappid(2367500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367501, 1, "9a67f88a48504e6c2e85c0ae14625cc53823f2ca01004dafe1e07315c0abd56b")
