-- Lua provided by RyzenAPI 
-- Game: POPOPOSAN
addappid(3429500)
addappid(3429501, 1, "e6ee7d178ddecb91af7d3b2815bbfd5e8e32f5c5a006631d0c3f04db164a60d0")
addappid(3429502, 1, "e8a78ac62ecbb99983535338a3d879b0714007ffee9880a0fb49357fb7e962d5")
addappid(3429503, 1, "62993e941616adc1650563a005fc781a7df5476c347f9598a2d1f96888e8ef9b")
