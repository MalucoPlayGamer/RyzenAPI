-- Lua provided by RyzenAPI
-- Game: Spellfield

-- MAIN APPLICATION
addappid(2404020)
-- Game: addappid(2404020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404021, 1, "ec9a01cb9123c87e7aa99b91465d3f9d392eb6bad451306b4ba27dd096d88f55")
