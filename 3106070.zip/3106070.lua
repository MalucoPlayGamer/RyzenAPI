-- Lua provided by RyzenAPI
-- Game: How Can a Joker Like Me Play Cards with a Beautiful Girl

-- MAIN APPLICATION
addappid(3106070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106071, 1, "18851477cbae1aa5d9239e931372973fed03b55b8257c79b0293b1d4c1a92246")

