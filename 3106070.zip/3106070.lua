-- Lua provided by RyzenAPI
-- Game: How Can a Joker Like Me Play Cards with a Beautiful Girl

-- MAIN APPLICATION
addappid(3106070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106071, 1, "18851477cbae1aa5d9239e931372973fed03b55b8257c79b0293b1d4c1a92246")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
