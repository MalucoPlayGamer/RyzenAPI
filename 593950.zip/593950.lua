-- Lua provided by SkyAPI 
-- Game: AppID 593950
addappid(593950)
addappid(593951, 1, "006485c2624f5ba0541c6fb86e1f5d3f1482800cd919d4e1243b2f31d3417251")
