-- Lua provided by RyzenAPI
-- Game: 世阳教你学防灾

-- MAIN APPLICATION
addappid(593950)

-- MAIN APP DEPOTS / PACKAGES
addappid(593951, 1, "006485c2624f5ba0541c6fb86e1f5d3f1482800cd919d4e1243b2f31d3417251")

