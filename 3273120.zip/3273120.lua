-- Lua provided by RyzenAPI
-- Game: addappid(3273120)

-- MAIN APPLICATION
addappid(3273120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273121, 1, "9f4709c536ea13c1e4781f0fc2f754b8e20302197cf83bed49dc801bf015e45f")
