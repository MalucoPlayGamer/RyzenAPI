-- Lua provided by RyzenAPI
-- Game: RUNE II: Decapitation Edition

-- MAIN APPLICATION
addappid(821290)
addappid(963310)
addappid(963311)
addappid(963312)
addappid(974540)

-- MAIN APP DEPOTS / PACKAGES
addappid(821291, 1, "f39cf76a23549196321695f55c3ddf17bf6f7f57d17d8f2f2cc85d956c2be057")

