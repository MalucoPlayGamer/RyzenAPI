-- Lua provided by RyzenAPI
-- Game: RUNE II: Decapitation Edition

-- MAIN APPLICATION
addappid(821290)
addappid(963311)
addappid(963312)
addappid(1466760)
addappid(1468670)
addappid(1468672)
addappid(1468673)
addappid(1484870)

-- MAIN APP DEPOTS / PACKAGES
addappid(821291,0,"f39cf76a23549196321695f55c3ddf17bf6f7f57d17d8f2f2cc85d956c2be057")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
