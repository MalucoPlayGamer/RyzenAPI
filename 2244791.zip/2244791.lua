-- Lua provided by RyzenAPI
-- Game: Rune Factory 3 Special - Another Episode Pack

-- MAIN APPLICATION
addappid(2244791)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244791,0,"204df8a9b9b31009bc1d54852230cb8164a0193595524898faf2859f540fa2a7")

