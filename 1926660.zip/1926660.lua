-- Lua provided by RyzenAPI
-- Game: addappid(1926660)

-- MAIN APPLICATION
addappid(1926660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926661, 1, "06732ef27ebdcc4150eb5dce38f77cb2ceeea7a17cfaf534f2b84e39352d3234")
