-- Lua provided by RyzenAPI
-- Game: Somber

-- MAIN APPLICATION
addappid(1311710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311712,0,"85b458760e1fe040150c8a62396479f4e09be59411afd9e55dc101be51a4ce71")

