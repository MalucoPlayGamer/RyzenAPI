-- Lua provided by RyzenAPI
-- Game: Game: AppID 1975600

-- MAIN APPLICATION
addappid(1975600)
-- Game: addappid(1975600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975601, 1, "21e421918b3c20c713f50ee8a27369f195c324f21610ac5d03a223c87fec726a")
