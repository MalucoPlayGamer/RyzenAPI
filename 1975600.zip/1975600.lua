-- Lua provided by SkyAPI 
-- Game: AppID 1975600
addappid(1975600)
addappid(1975601, 1, "21e421918b3c20c713f50ee8a27369f195c324f21610ac5d03a223c87fec726a")
