-- Lua provided by SkyAPI 
-- Game: Super Sunny Island
addappid(1581830)
addappid(1581831, 1, "da55df1e86c204782a7333e46ef3fa5840312ea35b0d86f99d3e1878a1fd528e")
