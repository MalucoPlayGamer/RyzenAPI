-- Lua provided by RyzenAPI
-- Game: 1581830

-- MAIN APPLICATION
addappid(1581830)
-- Game: addappid(1581830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581831, 1, "da55df1e86c204782a7333e46ef3fa5840312ea35b0d86f99d3e1878a1fd528e")
