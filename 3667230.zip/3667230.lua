-- Lua provided by RyzenAPI
-- Game: addappid(3667230)

-- MAIN APPLICATION
addappid(3667230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3667231, 1, "cc435ceb16e5e33c19898ce4f20e26601982c0760011b37d74bdbcf1f15d90d1")
