-- Lua provided by RyzenAPI
-- Game: The Last Dream: Developer's Edition

-- MAIN APPLICATION
addappid(395860)

-- MAIN APP DEPOTS / PACKAGES
addappid(395861, 1, "582306fa940da9e8347e940c09943f572a5a7386dd10406471a69d5401c6b6c1")
