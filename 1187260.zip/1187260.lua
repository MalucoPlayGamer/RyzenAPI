-- Lua provided by RyzenAPI
-- Game: White Wings ホワイトウィングス Artbook

-- MAIN APPLICATION
addappid(1187260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187260,0,"f5db2c7b7d272b3c9929c3876b1656416d34eba68065950bd3563f506b744400")

