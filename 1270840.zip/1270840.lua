-- Lua provided by RyzenAPI
-- Game: New King

-- MAIN APPLICATION
addappid(1270840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270841, 1, "de7e8f77ba7fb9fbdc40094be238c013dcd86742f6932010481f0ffb9c4294a0")

