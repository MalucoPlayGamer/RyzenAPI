-- Lua provided by RyzenAPI
-- Game: addappid(1649740)

-- MAIN APPLICATION
addappid(1649740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649741, 1, "9aa81e881a1f9e0f7c4545ef09e8a6d413d032e4f857022df0b69155c212fbce")
