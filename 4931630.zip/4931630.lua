-- 4931630's Lua and Manifest Created by Hubcap Manifest
-- Château Pluie: The New Cellar Keeper
-- Created: August 07, 2026 at 22:56:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4931630) -- Château Pluie: The New Cellar Keeper
-- MAIN APP DEPOTS
addappid(4931631, 1, "97d4afa78b7cbb889ac585d584c17bdf29f8b4c179edb30ccf5ab311d1aad1e9") -- Depot 4931631
setManifestid(4931631, "2732046228421415972", 2693200785)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)