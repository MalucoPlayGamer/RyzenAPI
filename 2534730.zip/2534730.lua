-- Lua provided by RyzenAPI
-- Game: CRYMACHINA - "Eden Database" Art Book

-- MAIN APPLICATION
addappid(2534730)
-- Game: addappid(2534730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534730,0,"0134ac28c146223336ac2e9204f237911b5e78a6554c79a190b480d712d73b76")
