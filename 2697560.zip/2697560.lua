-- Lua provided by RyzenAPI
-- Game: addappid(2697560)

-- MAIN APPLICATION
addappid(2697560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697561, 1, "c7119846f65dbdecd322641a0be846285ffccad8f2091c91bf241661478efd59")
addappid(2697562, 1, "c3d99f0f7d28f92c6529a27946777e65821ef2587d1cdfc59e47c87cb68fedeb")
