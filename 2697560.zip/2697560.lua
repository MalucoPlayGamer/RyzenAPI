-- Lua provided by RyzenAPI
-- Game: Mojika - Truth Rears Its Ugly Head

-- MAIN APPLICATION
addappid(2697560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697561, 1, "c7119846f65dbdecd322641a0be846285ffccad8f2091c91bf241661478efd59")
addappid(2697562, 1, "c3d99f0f7d28f92c6529a27946777e65821ef2587d1cdfc59e47c87cb68fedeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
