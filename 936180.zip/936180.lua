-- Lua provided by RyzenAPI
-- Game: addappid(936180)

-- MAIN APPLICATION
addappid(936180)

-- MAIN APP DEPOTS / PACKAGES
addappid(936181, 1, "4b3485e0eee8016bb86206834a8a6f414b490b70a2ff75f89bd2655b35984a52")
