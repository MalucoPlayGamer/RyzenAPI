-- Lua provided by RyzenAPI
-- Game: Atelier Totori ~The Adventurer of Arland~ DX

-- MAIN APPLICATION
addappid(936180)

-- MAIN APP DEPOTS / PACKAGES
addappid(936181, 1, "4b3485e0eee8016bb86206834a8a6f414b490b70a2ff75f89bd2655b35984a52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
