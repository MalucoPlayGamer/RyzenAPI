-- Lua provided by RyzenAPI 
-- Game: Samson
addappid(3634520)
addappid(3634521, 1, "2b2dd4cc3b87b9bb23562b460165aa44365a3d32cb7eb75081c38048e36382df")
addappid(3634522, 1, "53d49f2257c96df0765ec675b69b9dddd47da7763f5d708a13bd0cafb21006d7")
