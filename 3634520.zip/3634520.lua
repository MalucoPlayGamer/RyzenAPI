-- Lua provided by RyzenAPI
-- Game: Samson

-- MAIN APPLICATION
addappid(3634520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3634521, 1, "2b2dd4cc3b87b9bb23562b460165aa44365a3d32cb7eb75081c38048e36382df")
addappid(3634522, 1, "53d49f2257c96df0765ec675b69b9dddd47da7763f5d708a13bd0cafb21006d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4540000)
