-- Lua provided by RyzenAPI
-- Game: First Strike

-- MAIN APPLICATION
addappid(587000)

-- MAIN APP DEPOTS / PACKAGES
addappid(587002,0,"7ee45dce36052242f76323376022937e4af8a9b5ca1f99535c27b0c8ad849736")
addappid(587003,0,"705c8d67bec2b566ae68c540de5db21741b6e9b003a8aaa64808051b9f9077bc")
addappid(639701,0,"ee615d3e172a29a4db54b1ce343d6269d64d6622d076945ca6ccf58dedf6ea7e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2331550)
