-- Lua provided by SkyAPI 
-- Game: Chained Soundtrack
addappid(1623980)
addappid(1623981, 1, "e08ebba58d9de79bf9fa1ed4bbad05079d22d283c91752e074c1be2cb1a86215")
