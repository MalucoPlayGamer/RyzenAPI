-- Lua provided by RyzenAPI
-- Game: Game: Chained Soundtrack

-- MAIN APPLICATION
addappid(1623980)
-- Game: addappid(1623980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623981, 1, "e08ebba58d9de79bf9fa1ed4bbad05079d22d283c91752e074c1be2cb1a86215")
