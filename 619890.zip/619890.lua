-- Lua provided by RyzenAPI 
-- Game: Evil Glitch
addappid(619890)
addappid(619891, 1, "33e10515cdf9a1eb484b8fda2ee78dc8c4289067beed0555b0c444e55c4ca6bc")
addappid(619892, 1, "6d2f6b8cb3c65ccb898320d710fa8c213832ca4e00846ba1e8dd6ce0e18e530f")
