-- Lua provided by RyzenAPI
-- Game: NEEDY STREAMER OVERLOAD

-- MAIN APPLICATION
addappid(1451940)
-- Game: addappid(1451940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451941, 1, "967b200b8aed6ddab6c2134ef6bf8b65f149bbdc44af97fcf76723b76c450b38")
addappid(1451942, 1, "058fdb113770acdb9ebefce88ec695ed4313b21192b1db914656acdc13e2741f")
