-- Lua provided by RyzenAPI
-- Game: Game: Eternum EX

-- MAIN APPLICATION
addappid(597900)
-- Game: addappid(597900)

-- MAIN APP DEPOTS / PACKAGES
addappid(597901, 1, "3aed6258a829f9c272a21be2c32a1223783aa1c744d05f9f30f626428e8909d1")
