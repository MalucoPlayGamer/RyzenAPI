-- Lua provided by RyzenAPI
-- Game: Married Life With A Lamia

-- MAIN APPLICATION
addappid(2670550)
-- Game: addappid(2670550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670551, 1, "8a421cbe5efb781270881b98c4b74e845dec2dbdbae3ed81bffe3968d2c59bc5")
