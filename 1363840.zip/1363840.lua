-- Lua provided by SkyAPI 
-- Game: Saviors of Sapphire Wings / Stranger of Sword City Revisited
addappid(1363840)
addappid(1363841, 1, "008d4e91e475e6a198dd41326fc06e04f58cc400d075868bbbc67d5e9ec097c3")
addappid(1518520, 0, "9f8a57b7e3537ee40958ddaa18fc44d4a6033a05ea46726abb05a2d6b4c654cd")
