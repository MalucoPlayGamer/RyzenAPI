-- Lua provided by RyzenAPI
-- Game: addappid(2972890)

-- MAIN APPLICATION
addappid(2972890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972891, 1, "b2bfbf94c00b2ee85a3846a53b8feb6af864baa08d377a37eb425d09f73d4737")
