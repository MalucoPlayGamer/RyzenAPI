-- Lua provided by RyzenAPI
-- Game: Water Womb World

-- MAIN APPLICATION
addappid(4014680)

