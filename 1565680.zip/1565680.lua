-- Lua provided by SkyAPI 
-- Game: The Dark Prophecy
addappid(1565680)
addappid(1565681, 1, "bbec0b2f96b56e568388a23687fc59c5d3f0d60f7c54e892516aeae5ded0859b")
