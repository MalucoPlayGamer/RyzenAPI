-- Lua provided by RyzenAPI
-- Game: 1565680

-- MAIN APPLICATION
addappid(1565680)
-- Game: addappid(1565680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565681, 1, "bbec0b2f96b56e568388a23687fc59c5d3f0d60f7c54e892516aeae5ded0859b")
