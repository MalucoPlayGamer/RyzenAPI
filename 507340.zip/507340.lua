-- Lua provided by RyzenAPI
-- Game: Strike Squadron: Caracará

-- MAIN APPLICATION
addappid(507340)

-- MAIN APP DEPOTS / PACKAGES
addappid(507341, 1, "cd735e5933ad797f29f58afb3460550bda6f6aea9ed5019dff3f2049324022f8")

