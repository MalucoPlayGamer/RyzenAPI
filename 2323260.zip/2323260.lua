-- Lua provided by RyzenAPI
-- Game: Odyssée numérique

-- MAIN APPLICATION
addappid(2323260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323261, 1, "e1754ed18267694384daf0176c0379f4b1eec02b028b761100d453c7380d247c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
