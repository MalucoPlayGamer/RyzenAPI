-- Lua provided by RyzenAPI
-- Game: Odyssée numérique

-- MAIN APPLICATION
addappid(2323260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323261, 1, "e1754ed18267694384daf0176c0379f4b1eec02b028b761100d453c7380d247c")

