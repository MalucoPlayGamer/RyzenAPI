-- Lua provided by RyzenAPI
-- Game: Game: Heart vs HP

-- MAIN APPLICATION
addappid(2339160)
-- Game: addappid(2339160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339161, 1, "cf6a9abf5ec223999d35584bb04197e120881637d3d05d2ca6c917a90c67c163")
