-- Lua provided by RyzenAPI
-- Game: addappid(2175570)

-- MAIN APPLICATION
addappid(2175570)
addappid(3667710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175571, 1, "4823eef3af39d20115f2fa676ed5b48183d5d23ef4ec32280a0531c79feb199c")
