-- Lua provided by SkyAPI 
-- Game: EternaMine
addappid(2175570)
addappid(2175571, 1, "4823eef3af39d20115f2fa676ed5b48183d5d23ef4ec32280a0531c79feb199c")
addappid(3667710)
