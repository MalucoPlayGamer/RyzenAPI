-- Lua provided by RyzenAPI
-- Game: Impact Winter

-- MAIN APPLICATION
addappid(468000)
addappid(640810)

-- MAIN APP DEPOTS / PACKAGES
addappid(468001, 1, "eda6c6d68b7598bc4fcb1434ff4f977aff1bc31e7dcddbad5bd3d11c5854de83")
