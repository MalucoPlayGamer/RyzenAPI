-- Lua provided by RyzenAPI
-- Game: addappid(4562150)

-- MAIN APPLICATION
addappid(4562150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4562151, 1, "9e54f7239c73b9bed8ed23e4f2aa3f39e91e23fd8fa9c8d1b0b2456918cc7e4a")
