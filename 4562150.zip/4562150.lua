-- 4562150's Lua and Manifest Created by Hubcap Manifest
-- How To Grow a Black Hole
-- Created: June 24, 2026 at 12:17:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4562150) -- How To Grow a Black Hole
-- MAIN APP DEPOTS
addappid(4562151, 1, "9e54f7239c73b9bed8ed23e4f2aa3f39e91e23fd8fa9c8d1b0b2456918cc7e4a") -- Depot 4562151
setManifestid(4562151, "861193171654081491", 536031586)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4562152) -- Depot 4562152 (empty depot)