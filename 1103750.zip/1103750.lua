-- Lua provided by RyzenAPI
-- Game: addappid(1103750)

-- MAIN APPLICATION
addappid(1103750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103750,0,"f30724dd9a18335e167f41aaa21bad8a222251f80a049d8858acd97ec7523a7b")
