-- Lua provided by RyzenAPI
-- Game: 風色幻想6:冒險奏鳴

-- MAIN APPLICATION
addappid(2020530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020531, 1, "48569a3e06819e16ac9d88888c4cc8ece72d0dbdba75635302c9861d3dfb688a")

