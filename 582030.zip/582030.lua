-- Lua provided by RyzenAPI
-- Game: Oblivion Tesseract VR

-- MAIN APPLICATION
addappid(582030)
-- Game: addappid(582030)

-- MAIN APP DEPOTS / PACKAGES
addappid(582031, 1, "3f6f5df7f1cd4ea9dcdc7c2a525252ce22774122b1274e7b26f283da5d5f28ec")
