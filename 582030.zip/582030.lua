-- Lua provided by RyzenAPI
-- Game: Oblivion Tesseract VR

-- MAIN APPLICATION
addappid(582030)

-- MAIN APP DEPOTS / PACKAGES
addappid(582031, 1, "3f6f5df7f1cd4ea9dcdc7c2a525252ce22774122b1274e7b26f283da5d5f28ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
