-- Lua provided by RyzenAPI
-- Game: Awakening: The Skyward Castle Collector's Edition

-- MAIN APPLICATION
addappid(815540)

-- MAIN APP DEPOTS / PACKAGES
addappid(815541,0,"c7d752003f8214d9a3869bcfddf022c27c50f7a222931caf2a24d6b3501a989a")

