-- Lua provided by RyzenAPI
-- Game: RiMS Racing

-- MAIN APPLICATION
addappid(1346010)
addappid(1628250)
addappid(1628251)
addappid(1628252)
addappid(1628253)
addappid(1628254)
addappid(1628255)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1346011, 1, "04806cc0417a0c2443576428da243b68c27e8fa5916b55e245390060c72ed9dc")

