-- Lua provided by RyzenAPI
-- Game: 2636000

-- MAIN APPLICATION
addappid(2636000)
-- Game: addappid(2636000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636001, 1, "175d3f32c7592f8b6863123ce1eee8703a1496a7496ee758d41e28cc0e891ad0")
