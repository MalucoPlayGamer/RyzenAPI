-- Lua provided by RyzenAPI
-- Game: Tobla - Divine Path

-- MAIN APPLICATION
addappid(2717750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717751, 1, "ad233a4805ee6e7ecc9cf3a8c4f67a42a169f6622b19ed9820edfa0273d4ab2f")
