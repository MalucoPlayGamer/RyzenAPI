-- Lua provided by RyzenAPI
-- Game: Asylum Nightmares

-- MAIN APPLICATION
addappid(2719920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719921, 1, "37cfe0c6f0cc48a817594b85ab1ea44100c579edc71a1200f954bc5cea353428")
