-- Lua provided by RyzenAPI
-- Game: Mimicry

-- MAIN APPLICATION
addappid(1804170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804171, 1, "32ec26fa58bf833319faa48806099cfff9c9e5606aef188ed57fb068abdc0449")
