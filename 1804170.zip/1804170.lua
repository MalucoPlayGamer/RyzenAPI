-- Lua provided by SkyAPI 
-- Game: Mimicry
addappid(1804170)
addappid(1804171, 1, "32ec26fa58bf833319faa48806099cfff9c9e5606aef188ed57fb068abdc0449")
