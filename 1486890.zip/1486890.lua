-- Lua provided by RyzenAPI
-- Game: Slide Mini

-- MAIN APPLICATION
addappid(1486890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486891, 1, "ae5041a32c4f8aaecf46192871dd36fb480c9a2b8e5e5af8ebf539211dfcb2fa")
addappid(1486892, 1, "bb67bf056002c66c304a0625c5711f298696dd1772fbb8e8e17b596233fac0ad")
addappid(1486893, 1, "44292f77667b110bae2b92e25eb8438b54e37bac4a1d2d9b983db02c7b4cfef9")
