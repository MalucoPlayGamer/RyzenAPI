-- Lua provided by RyzenAPI
-- Game: addappid(2140510)

-- MAIN APPLICATION
addappid(2140510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140511, 1, "20c9fc3dc36f93269a4c09e4c633de6e0ea3ed9ee70dd8d0a79f36aa3e717a61")
addappid(2140512, 1, "6ed8186270a34e436f0fee136a3c2da06a7334c569e3f82aaf8d8b9d37f24cec")
