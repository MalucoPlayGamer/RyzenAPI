-- Lua provided by RyzenAPI
-- Game: addappid(1772310)

-- MAIN APPLICATION
addappid(1772310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772312,0,"fc33cd8f5363403dbb224b5bfcf2e1c88dbda0530731e69febad8c005d22cc7e")
