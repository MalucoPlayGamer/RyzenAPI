-- Lua provided by RyzenAPI
-- Game: 1189460

-- MAIN APPLICATION
addappid(1189460)
-- Game: addappid(1189460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189461, 1, "f51529a4cf9659f9eae2957d383cd0224ff928d6fcd587a7ab26524cd0009ce3")
