-- Lua provided by RyzenAPI
-- Game: Don't Look Back

-- MAIN APPLICATION
addappid(3241480)
-- Game: addappid(3241480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241486,0,"83faf272024769bfc00146e59a29fd0359be10a77b05fad5bb76e50ea67e3b98")
