-- Lua provided by RyzenAPI
-- Game: Game: RogueClick

-- MAIN APPLICATION
addappid(1908900)
-- Game: addappid(1908900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908901, 1, "606cac17d9062e172aa4ff40b4cc13281154cde9d1a98d65967127709a3e95bf")
