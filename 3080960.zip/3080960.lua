-- Lua provided by RyzenAPI
-- Game: Game: Unlucky Chicken

-- MAIN APPLICATION
addappid(3080960)
-- Game: addappid(3080960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080961, 1, "eeec7292406c55396d676347b32f634105c5cca2b031f05b0548c96f48903051")
