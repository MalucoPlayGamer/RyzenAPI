-- Lua provided by RyzenAPI 
-- Game: The Thin Silence
addappid(314630)
addappid(314631, 1, "63b306fc45d0e65b649a5bc69cb73d3191ae88ac890ffa5296f7a62128bd8996")
addappid(314632, 1, "1a1574b1c6c69656215634709dfa51cae6e77eba5ded8258507495ebc441f2a3")
