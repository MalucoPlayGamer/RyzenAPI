-- Lua provided by RyzenAPI
-- Game: Hackers in Battlefield

-- MAIN APPLICATION
addappid(1821440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821441, 1, "dfc139c8ec73279ea55d92f5a4e226916aa49480095bf3b1de69a5fa9d079a87")
