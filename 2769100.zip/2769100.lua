-- Lua provided by RyzenAPI
-- Game: Visiting Shrine at Night | 夜間参拝

-- MAIN APPLICATION
addappid(2769100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769101, 1, "ec80cdcacfc959655919968822bd34f0bc1f419e57c7158305fedf378c7caa81")
