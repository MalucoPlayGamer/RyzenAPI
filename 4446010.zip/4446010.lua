-- 4446010's Lua and Manifest Created by Hubcap Manifest
-- The First Million
-- Created: June 24, 2026 at 14:46:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4446010, 1, "05270e48aed76e9f6a3e04b6c4b5f987b4408b46b77f820da40f48d8946fc67c") -- The First Million
-- MAIN APP DEPOTS
addappid(4446011, 1, "cc1936689058f1b2ea065c8ba1890a50f65cdcea1e2441142f448881b46b87cf") -- Depot 4446011
-- setManifestid(4446011, "943610377820461735", 177875164)
addappid(4446012, 1, "e25af58ae9de7bf87e335d4fa30c2510164899e6c78f487039e828a9bfe6e624") -- Depot 4446012
-- setManifestid(4446012, "2839356076780579654", 259989568)
addappid(4446013, 1, "ab0cefc62a770dbfc90b5c19b6063c3c75576bb51d7dd91e372ff25ea3357c64") -- Depot 4446013
-- setManifestid(4446013, "4461887779874676006", 144893964)