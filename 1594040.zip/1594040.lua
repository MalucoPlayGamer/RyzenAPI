-- Lua provided by RyzenAPI
-- Game: Game: Wreckreation

-- MAIN APPLICATION
addappid(1594040)
-- Game: addappid(1594040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594041, 1, "087f7afba241d83af08955b0c7caec2a209a483aec68960ae2831fc9894972a8")
