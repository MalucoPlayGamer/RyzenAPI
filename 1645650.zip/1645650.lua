-- Lua provided by RyzenAPI
-- Game: 1645650

-- MAIN APPLICATION
addappid(1645650)
-- Game: addappid(1645650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645651, 1, "c89a0888f86f6fc0641e2221d83c76eb6bf361860eec5f784d6eca931e29e2f7")
