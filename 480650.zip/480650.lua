-- Lua provided by RyzenAPI
-- Game: AppID 480650

-- MAIN APPLICATION
addappid(480650)
addappid(523500)
addappid(523501)
addappid(523502)
addappid(523503)
addappid(523504)
addappid(523505)
addappid(523506)
addappid(523507)
addappid(523508)
addappid(523510)
addappid(523511)
addappid(523521)
addappid(523530)
addappid(523531)
addappid(523532)
addappid(523533)
addappid(523534)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(480651, 1, "24f9d13d533bd088de202a601d87530447c72939455d9685d3b80b4344716902")

