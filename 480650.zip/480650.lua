-- Lua provided by RyzenAPI 
-- Game: AppID 480650
addappid(480650)
addappid(480651, 1, "24f9d13d533bd088de202a601d87530447c72939455d9685d3b80b4344716902")
