-- Lua provided by RyzenAPI
-- Game: Game: 1883 Science & Mediumship Demo

-- MAIN APPLICATION
addappid(2121300)
-- Game: addappid(2121300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121301, 1, "30873d3586dd3cbe89fbc47a1f2f2f28f2259f99ecf484f8eab2ce1e2da9cdf8")
