-- Lua provided by RyzenAPI
-- Game: Game: Badlands Racer

-- MAIN APPLICATION
addappid(1752500)
-- Game: addappid(1752500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752501, 1, "141fb562c10203a005125040f81c97cd512a65038f47c66ed532631f39e91c94")
