-- Lua provided by RyzenAPI 
-- Game: Badlands Racer
addappid(1752500)
addappid(1752501, 1, "141fb562c10203a005125040f81c97cd512a65038f47c66ed532631f39e91c94")
