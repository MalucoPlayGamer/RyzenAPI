-- Lua provided by RyzenAPI
-- Game: Medieval Dynasty

-- MAIN APPLICATION
addappid(1129580)
addappid(3774330)
addappid(4159030)
addappid(4754550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129581,0,"1046c854c37b8fbffc2463ed255b11644eb113572b68ab4d509a5e09a9f47098")
addappid(1418980,0,"4725ba16d1f74610293041fa477eedfb35cad844c9c064efb54a7ff031a89e3d")
addappid(1766020,0,"ca76a7535ac3f0665611290b40894720e2d8ddcfbae6330301f0bf49cef0c64b")
addappid(1766021,0,"e63723c50d9ecdb7093d2f318c5ce1418817e4fc2148706bba820c94f83de162")
addappid(1766022,0,"42d607c1515fec47b5c19b04778c4c52bbfe10cac2d0acb459d0f61a02eebacf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4997500)
