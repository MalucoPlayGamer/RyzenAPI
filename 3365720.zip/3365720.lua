-- Lua provided by RyzenAPI
-- Game: 3365720

-- MAIN APPLICATION
addappid(3365720)
-- Game: addappid(3365720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365721, 1, "91d4ed48b8802da5f83faf3c8e54fddc9dd929091360042274db72941b625835")
