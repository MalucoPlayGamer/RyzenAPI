-- Lua provided by RyzenAPI
-- Game: Game: 9-nine-:Episode 2

-- MAIN APPLICATION
addappid(1033420)
-- Game: addappid(1033420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033421, 1, "91b6082f09c47c7787190765545ededa4d322bc17fd1232000559c647d296d36")
