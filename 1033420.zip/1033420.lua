-- Lua provided by RyzenAPI
-- Game: 9-nine-:Episode 2

-- MAIN APPLICATION
addappid(1033420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1033421, 1, "91b6082f09c47c7787190765545ededa4d322bc17fd1232000559c647d296d36")