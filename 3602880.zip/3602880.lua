-- Lua provided by RyzenAPI
-- Game: Game: Dark Mine

-- MAIN APPLICATION
addappid(3602880)
-- Game: addappid(3602880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602881, 1, "b2e8cf17217b31906c050439da42dd182dda85b293e01f1c455f760390422361")
