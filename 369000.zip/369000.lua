-- Lua provided by RyzenAPI
-- Game: Pongo

-- MAIN APPLICATION
addappid(369000)

-- MAIN APP DEPOTS / PACKAGES
addappid(369001, 1, "552a77d2664fe3f4501cb1566f06bb50e4caa1824874b61f26283a545dbdab4f")

