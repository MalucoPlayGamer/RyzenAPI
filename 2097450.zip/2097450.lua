-- Lua provided by RyzenAPI
-- Game: The Top Soundtrack

-- MAIN APPLICATION
addappid(2097450)
-- Game: addappid(2097450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097451, 1, "d0075a634614464d43b3d33ab5bc1102b0105c052ebbcf864a9213fcedea900a")
addappid(2097452, 1, "63de81c0c8cbf3eeaf2c58dce60c967624a7e7a69892f11c4ef3df291baab663")
