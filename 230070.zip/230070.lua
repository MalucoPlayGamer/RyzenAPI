-- Lua provided by RyzenAPI
-- Game: The Age of Decadence

-- MAIN APPLICATION
addappid(230070)
-- Game: addappid(230070)

-- MAIN APP DEPOTS / PACKAGES
addappid(230072,0,"7f31399710c6a1539a58226cf2d5d14e880d3ef7c7c38b203c2dc4328270d571")
