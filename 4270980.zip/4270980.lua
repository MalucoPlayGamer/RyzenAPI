-- 4270980's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Celestia is streaming
-- Created: June 18, 2026 at 05:24:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4270980) -- Hentai Clicker: Celestia is streaming
-- MAIN APP DEPOTS
addappid(4270981, 1, "fca1101e81b83ee7042ee7db7c15db2c08f48b72d4ce65968a2473fc328287a4") -- Depot 4270981
setManifestid(4270981, "4951669075014789572", 166209723)