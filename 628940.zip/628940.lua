-- Lua provided by RyzenAPI
-- Game: LIZ: Before the Plague

-- MAIN APPLICATION
addappid(628940)

-- MAIN APP DEPOTS / PACKAGES
addappid(628941,0,"723f60c80d2c61faa62b8421c1c9b4313a790b70619eeca38ceadcf5b7a68f6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
