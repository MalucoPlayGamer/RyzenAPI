-- Lua provided by RyzenAPI
-- Game: Pakicetus

-- MAIN APPLICATION
addappid(1105240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105241, 1, "80e253470a743acaffc6d6a433b815ca7162bfbe8ba9232c29782fde3c8578ca")
