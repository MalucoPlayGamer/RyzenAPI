-- Lua provided by RyzenAPI
-- Game: Lost Lands: Dark Overlord

-- MAIN APPLICATION
addappid(377450)

-- MAIN APP DEPOTS / PACKAGES
addappid(377451, 1, "ceaea3756eb483fb78e6e8ad98f41ff84dec179fc9909af8ce43c1368905c082")

