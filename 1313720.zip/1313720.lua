-- Lua provided by RyzenAPI
-- Game: Kaiju Fishing Demo

-- MAIN APPLICATION
addappid(1313720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313721, 1, "aa149bf64d726f848d912f0b85bf77bfefbe34bc207d85c0869a3d889a368fcb")
