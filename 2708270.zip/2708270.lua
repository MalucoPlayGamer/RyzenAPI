-- Lua provided by RyzenAPI
-- Game: addappid(2708270)

-- MAIN APPLICATION
addappid(2708270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708271, 1, "e1f378ae8314a24acddee3db476c8a318798e569b401d698b47f86444c8b9da8")
