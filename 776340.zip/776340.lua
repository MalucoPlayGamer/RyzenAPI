-- Lua provided by SkyAPI 
-- Game: Gay World
addappid(776340)
addappid(776341, 1, "fc01a1ee7152856260506f9edce00848634d54c4b7577e3aca6a82c9b7e90d53")
addappid(778210, 0, "0060e810c286f6d2b2fbab6540b0e9988b18212dbaf2328a215c062e5bcce9a9")
