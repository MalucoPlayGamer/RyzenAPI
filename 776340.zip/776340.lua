-- Lua provided by RyzenAPI
-- Game: 776340

-- MAIN APPLICATION
addappid(776340)
-- Game: addappid(776340)

-- MAIN APP DEPOTS / PACKAGES
addappid(776341, 1, "fc01a1ee7152856260506f9edce00848634d54c4b7577e3aca6a82c9b7e90d53")
addappid(778210, 0, "0060e810c286f6d2b2fbab6540b0e9988b18212dbaf2328a215c062e5bcce9a9")
