-- Lua provided by RyzenAPI
-- Game: City of Dusk

-- MAIN APPLICATION
addappid(2389890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389891, 1, "5acfad0c9592a0579e2131ca0cfe3f85b4f14f6aa91c82c18f5b1690787683e4")

