-- Lua provided by RyzenAPI
-- Game: addappid(1950570)

-- MAIN APPLICATION
addappid(1950570)
addappid(2268931)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950571, 1, "7381f62d2de5b2221d8c54d1feecba6092b5ace26fa97bc661f69c02110c95ce")
addappid(1950572, 1, "0689cfc9ef5f549f462c3d2e4ee1de548ae6d097d13815f14a21a3eb746e1e4f")
addappid(1950573, 1, "84b2d8ce6b07db36ff57de1efac0556840a44edbdacd46f5f11c5e84e358f06b")
addappid(2268930, 0, "6e3f649ae407856c2eef647490bc338edfbdf6785f11aecfe7a1152c726c270b")
