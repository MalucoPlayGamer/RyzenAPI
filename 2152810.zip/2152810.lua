-- Lua provided by RyzenAPI
-- Game: Forge Industry

-- MAIN APPLICATION
addappid(2152810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152811, 1, "068101e185b00b2138183c34d7775540b020a8e7d4718fa4c8c1cdde6842678e")
addappid(2152813, 1, "30309f98fed10dacf9b691c5e4cd3add4451c0b168cfee4c41154529a28bf504")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
