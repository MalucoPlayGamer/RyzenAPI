-- Lua provided by RyzenAPI
-- Game: DEEP FOG

-- MAIN APPLICATION
addappid(1857650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857651, 1, "94da035a2aa91c76eb295b8c9ac5dd6d0898668ba2af3e5b1a54ef46e9f44880")
