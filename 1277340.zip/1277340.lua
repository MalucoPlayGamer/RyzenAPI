-- Lua provided by RyzenAPI
-- Game: Sunset fighter

-- MAIN APPLICATION
addappid(1277340)
-- Game: addappid(1277340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277341, 1, "99e93619b3822b835c7141125276ab8900d51ce5751812a944d4d3860428094e")
