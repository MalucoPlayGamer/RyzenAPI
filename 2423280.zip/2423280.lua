-- Lua provided by RyzenAPI
-- Game: Pirates: Rogue's Fortune

-- MAIN APPLICATION
addappid(2423280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423281,0,"5ee47077d1c06e717f2a4323f18de8194979dd5493fadc2ca7e66df81dcdde9a")

