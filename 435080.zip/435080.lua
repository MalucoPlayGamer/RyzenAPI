-- Lua provided by RyzenAPI
-- Game: Game: Philia : the Sequel to Elansar

-- MAIN APPLICATION
addappid(435080)
-- Game: addappid(435080)

-- MAIN APP DEPOTS / PACKAGES
addappid(435081, 1, "ac31d249cb85494de5c6e916194ffff7a7024ef93ca1f459418ad98abff105c2")
