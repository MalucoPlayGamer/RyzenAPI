-- Lua provided by RyzenAPI
-- Game: addappid(435080)

-- MAIN APPLICATION
addappid(435080)

-- MAIN APP DEPOTS / PACKAGES
addappid(435081, 1, "ac31d249cb85494de5c6e916194ffff7a7024ef93ca1f459418ad98abff105c2")
