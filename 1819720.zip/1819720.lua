-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Heroine Character Generator 3 for MZ

-- MAIN APPLICATION
addappid(1819720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819720,0,"398017adec60cb71d53d2cfec3888396242c83b9f56db8d5c7013465fd302295")
