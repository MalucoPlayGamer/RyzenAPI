-- Lua provided by RyzenAPI
-- Game: 2311310

-- MAIN APPLICATION
addappid(2311310)
-- Game: addappid(2311310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311311, 1, "21f1219804f160123537b776abcabdec412b35a378f159cbbdc3a436b9e36eed")
