-- Lua provided by RyzenAPI 
-- Game: XBattleCarsPVP
addappid(2311310)
addappid(2311311, 1, "21f1219804f160123537b776abcabdec412b35a378f159cbbdc3a436b9e36eed")
