-- Lua provided by RyzenAPI
-- Game: Ame no Marginal -Rain Marginal- - Original Soundtrack

-- MAIN APPLICATION
addappid(386760)
-- Game: addappid(386760)

-- MAIN APP DEPOTS / PACKAGES
addappid(386760,0,"9f23872b3fb11fff0cdc453d88d1bc2c1f554cf26a4064dea7c9b2cc8ad9cfb0")
