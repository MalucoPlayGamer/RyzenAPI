-- 1463920's Lua and Manifest Created by Hubcap Manifest
-- hexceed
-- Created: August 16, 2026 at 01:08:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 41
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1463920, 1, "08ceca3a04067dc3df520ebc11549746cb9712ead23d2b4db020e8fdb3fc8ddf") -- hexceed
-- MAIN APP DEPOTS
addappid(1463921, 1, "ffb7dd65beabbb169a91263e3b86f8bcace3b627e428356cb83773fd705845e6") -- hexceed Windows 32
setManifestid(1463921, "2675114658811531194", 1657881269)
addappid(1463922, 1, "e08f12c10ad9d21ecdc6fe77d7077bea54ff3de2c91a238189607f402790a111") -- hexceed Windows 64
setManifestid(1463922, "3232210272656694987", 1671474456)
addappid(1463923, 1, "56a10dd847c0d901eb800ea8d38b77849477c8a3ad8ac1ee646ff46577fca65d") -- hexceed Mac 64
setManifestid(1463923, "3787262824352571274", 1691751741)
addappid(1463924, 1, "63fb7c42d632029e96e91471b45d0235c803f00112c05152677348c4a58e1ec6") -- Depot 1463924
setManifestid(1463924, "626544472932058094", 1707398288)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1494330) -- hexceed - Stella Pack
addappid(1494331) -- hexceed - Animo Pack
addappid(1494332) -- hexceed - Iter Pack
addappid(1494333) -- hexceed - Clavis Pack
addappid(1494334) -- hexceed - Cessabit Pack
addappid(1494335) -- hexceed - Inventa Pack
addappid(1494336) -- hexceed - Exsupero Pack
addappid(1494337) -- hexceed - Progressum Pack
addappid(1494338) -- hexceed - Illumina Pack
addappid(1494339) -- hexceed - Casus Pack
addappid(1494350) -- hexceed - Effugium Pack
addappid(1494351) -- hexceed - Rimor Pack
addappid(1494352) -- hexceed - Year 1 Pass
addappid(1903230) -- hexceed - Year 2 Pass
addappid(1903231) -- hexceed - Incipiam Pack
addappid(1903232) -- hexceed - Insulam Pack
addappid(1903233) -- hexceed - Cogitare Pack
addappid(1903234) -- hexceed - Novus Pack
addappid(1903235) -- hexceed - Paenultima Pack
addappid(1903236) -- hexceed - Finis Pack
addappid(2294500) -- hexceed - Aqua Pack
addappid(2294501) -- hexceed - Ignis Pack
addappid(2294502) -- hexceed - Terra Pack
addappid(2294503) -- hexceed - Ventus Pack
addappid(2294504) -- hexceed - Metallicum Pack
addappid(2294505) -- hexceed - Glacialis Pack
addappid(2294520) -- hexceed - Year 3 Pass
addappid(2767660) -- hexceed - Year 4 Pass
addappid(2767670) -- hexceed - Rubrum Pack
addappid(2767680) -- hexceed - Flavum Pack
addappid(2767690) -- hexceed - Viridis Pack
addappid(2767700) -- hexceed - Caeruleum Pack
addappid(2767710) -- hexceed - Fuscus Pack
addappid(2767720) -- hexceed - Violaceum Pack
addappid(3517390) -- hexceed - Aquila Pack
addappid(3517400) -- hexceed - Centaurus Pack
addappid(3517410) -- hexceed - Capricornus Pack
addappid(3517420) -- hexceed - Cetus Pack
addappid(3517430) -- hexceed - Sirius Pack
addappid(3517440) -- hexceed - Alphard Pack
addappid(3517540) -- hexceed - Year 5 Pass