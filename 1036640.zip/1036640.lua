-- Lua provided by RyzenAPI
-- Game: AppID 1036640

-- MAIN APPLICATION
addappid(1036640)
-- Game: addappid(1036640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036641, 1, "64815a8bd36127e977b7959101e3fd9352c237cf06e86ddae2e669ac714d52e9")
