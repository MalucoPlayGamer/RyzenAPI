-- 1036640's Lua and Manifest Created by Hubcap Manifest
-- RPG Developer Bakin
-- Created: August 03, 2026 at 00:28:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 119
-- Total DLCs: 116 (5 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1036640, 1, "940971cdec07b5b8c365d69f84a6fe6c1ecdd53f3bfd00fb81a6b6b2ae19ec5d") -- RPG Developer Bakin
-- MAIN APP DEPOTS
addappid(1036641, 1, "64815a8bd36127e977b7959101e3fd9352c237cf06e86ddae2e669ac714d52e9") -- Depot 1036641
setManifestid(1036641, "6997626662163393720", 9715362035)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITH DEDICATED DEPOTS
-- RPG Developer Bakin Nature Resource Pack Vol.1 (AppID: 1946480)
addappid(1946480)
addappid(1946480, 1, "91c3859672653e211b75bea572644c7724934333f6c1c5fb50a86668be704998") -- RPG Developer Bakin Nature Resource Pack Vol.1 - Depot 1946480
setManifestid(1946480, "4074153645587785469", 112395359)
-- RPG Developer Bakin Castle Pack Vol.1 (AppID: 1952420)
addappid(1952420)
addappid(1952420, 1, "62d98be7050b39dd1796470282a38f5581c0f52203c90d8f29e6bf081a518b7d") -- RPG Developer Bakin Castle Pack Vol.1 - Depot 1952420
setManifestid(1952420, "3834257735668001830", 327384473)
-- RPG Developer Bakin House Pack Vol.1 (AppID: 1952421)
addappid(1952421)
addappid(1952421, 1, "f694302c6176811522b1520c24f13cc349e32a6f40800530542cda9d6b743874") -- RPG Developer Bakin House Pack Vol.1 - Depot 1952421
setManifestid(1952421, "2229702169694830739", 146903210)
-- RPG Developer Bakin Demons Castle Pack Vol.1 (AppID: 1952422)
addappid(1952422)
addtoken(1952422, "11137677242205882779")
addappid(1952422, 1, "488cfcd5e539b861eb7eb4fce90856a0bb1fbd8c43d6d8793aef3bfca4e42fe8") -- RPG Developer Bakin Demons Castle Pack Vol.1 - Depot 1952422
setManifestid(1952422, "250848956845132237", 46407972)
-- RPG Developer Bakin Furnitures  Ornaments Pack Vol.1 (AppID: 1952423)
addappid(1952423)
addappid(1952423, 1, "f79edd5fccb7690faec4e3fd24d1376815a98c4fad69efb2c7006f8d9fcf6a6f") -- RPG Developer Bakin Furnitures  Ornaments Pack Vol.1 - Depot 1952423
setManifestid(1952423, "5702829389732384289", 581864389)
-- RPG Developer Bakin Furnitures  Ornaments Pack Vol.2 (AppID: 1952424)
addappid(1952424)
addappid(1952424, 1, "edbeb4e449aaa88857855ae58083839668e672b746955cb58999dd7c5581cb55") -- RPG Developer Bakin Furnitures  Ornaments Pack Vol.2 - Depot 1952424
setManifestid(1952424, "8018968535025753184", 203273370)
-- RPG Developer Bakin Landmark Pack Vol.1 (AppID: 1952426)
addappid(1952426)
addappid(1952426, 1, "65b79bf6c3a724d576770cd5973b8ad6254717f6c60ece4900671e3b45fa7049") -- RPG Developer Bakin Landmark Pack Vol.1 - Depot 1952426
setManifestid(1952426, "4545789681214052014", 152625779)
-- RPG Developer Bakin ModemCity Pack (AppID: 1952427)
addappid(1952427)
addappid(1952427, 1, "2bb9d7df4844ed25eafaeb55833485a8039f5c9dd1f407d8480bbceec646541f") -- RPG Developer Bakin ModemCity Pack - Depot 1952427
setManifestid(1952427, "1343906369720468192", 319841446)
-- RPG Developer Bakin Nature Pack Vol.2 (AppID: 1952428)
addappid(1952428)
addappid(1952428, 1, "da27d4056487c01695e4883ada8d7b2558654b746b05f425f774889e204e66d6") -- RPG Developer Bakin Nature Pack Vol.2 - Depot 1952428
setManifestid(1952428, "4593651535699519809", 257986302)
-- RPG Developer Bakin Outdoor Building Pack Vol.1 (AppID: 1952429)
addappid(1952429)
addappid(1952429, 1, "9be883c9e6d5f4cdb9a07060045f15c2d61da916419eb3951f5443578b5a3c27") -- RPG Developer Bakin Outdoor Building Pack Vol.1 - Depot 1952429
setManifestid(1952429, "4289495226880697525", 294454472)
-- RPG Developer Bakin Ruins Pack Vol.1 (AppID: 1952430)
addappid(1952430)
addappid(1952430, 1, "2043bc5052db81584345e74a02e935207d0e63f4f10a4e53ad9ae18bf9d2d719") -- RPG Developer Bakin Ruins Pack Vol.1 - Depot 1952430
setManifestid(1952430, "3793332422439324468", 87554624)
-- RPG Developer Bakin Ruins Pack Vol.2 (AppID: 1952431)
addappid(1952431)
addappid(1952431, 1, "e7efb37a23156172bc206e4c115756348277cbd148ece1150bc483e375004686") -- RPG Developer Bakin Ruins Pack Vol.2 - Depot 1952431
setManifestid(1952431, "220663479743862816", 42825185)
-- RPG Developer Bakin Iconography 3 (AppID: 1952432)
addappid(1952432)
addappid(1952432, 1, "103a2c6dfe920ae699318b9a020e0b3acfc55b4669e7595b0d4b4ccd8a2481fb") -- RPG Developer Bakin Iconography 3 - Depot 1952432
setManifestid(1952432, "7963012047350165512", 11705560)
-- RPG Developer Bakin Sound Pack Vol. (AppID: 1952433)
addappid(1952433)
addappid(1952433, 1, "d0b0dc7dc46d356f9a0ce235debd8af347bae94af79eb73ddd3bb2c99c7b6b2e") -- RPG Developer Bakin Sound Pack Vol. - Depot 1952433
setManifestid(1952433, "4651564861583994413", 0)
-- RPG Developer Bakin Effect Pack Vol.1 (AppID: 1952434)
addappid(1952434)
addappid(1952434, 1, "eb4abebf632f295c5ccc8357ee369f631b4cf914f10da4b62554ae806bf91756") -- RPG Developer Bakin Effect Pack Vol.1 - Depot 1952434
setManifestid(1952434, "4572971307543850741", 0)
-- RPG Developer Bakin EVFX Stoneforge (AppID: 1952435)
addappid(1952435)
addappid(1952435, 1, "fbcc099fec487d17b02aa790361c735a5b61a8aa65e814a6536224b3a8b08ba1") -- RPG Developer Bakin EVFX Stoneforge - Depot 1952435
setManifestid(1952435, "592775680584172752", 28381042)
-- RPG Developer Bakin Ancient Pack (AppID: 1952436)
addappid(1952436)
addappid(1952436, 1, "a8f9f880a2e2a846db7e2acdf197cc935ec30a794eb510225f31f6bf7de69ccf") -- RPG Developer Bakin Ancient Pack - Depot 1952436
setManifestid(1952436, "967687771536233663", 58436178)
-- RPG Developer Bakin Western Pack (AppID: 1952437)
addappid(1952437)
addappid(1952437, 1, "8a6af6194584ad446ad2a40683ce384a6f8aaf54fcbd60be1906b8971bf1fc07") -- RPG Developer Bakin Western Pack - Depot 1952437
setManifestid(1952437, "8563015680339266765", 350652555)
-- RPG Developer Bakin 3D Monster Pack Vol.1 (AppID: 2133190)
addappid(2133190)
addappid(2133190, 1, "9f392c626ebacf0ec8e8c2cb45ef6cf9b834def9872ad1fd648af426da4d30cd") -- RPG Developer Bakin 3D Monster Pack Vol.1 - Depot 2133190
setManifestid(2133190, "6515896370101426661", 344166796)
-- RPG Developer Bakin Smile Objects Vol.1 (AppID: 2339440)
addappid(2339440)
addappid(2339440, 1, "b70296b6916dbca93dfa649be7729cc4f97e6798e6bf86b64068fabea05f08cd") -- RPG Developer Bakin Smile Objects Vol.1 - Depot 2339440
setManifestid(2339440, "183447937648914804", 320322310)
-- RPG Developer Bakin Glowing Crystal Pack (AppID: 2401980)
addappid(2401980)
addappid(2401980, 1, "71a6f89d1bd176c466fbbf1c2e96a97339a04ced16b60cbaa1caf11263c8d998") -- RPG Developer Bakin Glowing Crystal Pack - Depot 2401980
setManifestid(2401980, "1905332021175417971", 8609253)
-- RPG Developer Bakin House Builder Pack (AppID: 2401981)
addappid(2401981)
addappid(2401981, 1, "99ef17b79ca622fd05666e99cd8f33929f44c5af317610129b50833f22d2c0aa") -- RPG Developer Bakin House Builder Pack - Depot 2401981
setManifestid(2401981, "2527478734943849603", 183031851)
-- RPG Developer Bakin Wooden Platform Pack (AppID: 2401982)
addappid(2401982)
addappid(2401982, 1, "d177fa888f8727da0014b9175396b9fd55fd81582e0459e66cedf2e3ea390f80") -- RPG Developer Bakin Wooden Platform Pack - Depot 2401982
setManifestid(2401982, "5801480805863666515", 22092710)
-- RPG Developer Bakin Forest Pack Vol.1 (AppID: 2641940)
addappid(2641940)
addappid(2641940, 1, "144251bdcf0ea5ad21af924e1f6673e80d652161a9f4bf301aceef9c752f9aee") -- RPG Developer Bakin Forest Pack Vol.1 - Depot 2641940
setManifestid(2641940, "329541151649705188", 125821048)
-- RPG Developer Bakin Terica Terrain Pack Vol.1 (AppID: 2641950)
addappid(2641950)
addappid(2641950, 1, "7dd8cfaa8fe8b94eb01d0167b5b9c8883a429f0d4bf05f1e98466772b630dd9c") -- RPG Developer Bakin Terica Terrain Pack Vol.1 - Depot 2641950
setManifestid(2641950, "2354327081854815749", 12993811)
-- RPG Developer Bakin Glowing Icon Pack (AppID: 2644800)
addappid(2644800)
addappid(2644800, 1, "8f6f0446a326477558724fd0fdb6b38f07d4d1ccdc2dbc707b1b522f401c720d") -- RPG Developer Bakin Glowing Icon Pack - Depot 2644800
setManifestid(2644800, "956341436745622332", 421180301)
-- RPG Developer Bakin Mountain Village Pack (AppID: 2715320)
addappid(2715320)
addappid(2715320, 1, "1cdfa640f718ce55ff2b75d6131b80452f695f4736b360f92c7a5f0c1c826116") -- RPG Developer Bakin Mountain Village Pack - Depot 2715320
setManifestid(2715320, "4681480178037371227", 191961805)
-- RPG Developer Bakin Dungeon Kit Pack (AppID: 2715330)
addappid(2715330)
addappid(2715330, 1, "88866cc62cc46f2f3a99af621d7832bb159624290628206aa55d1f9dba5819c0") -- RPG Developer Bakin Dungeon Kit Pack - Depot 2715330
setManifestid(2715330, "3959394596146237046", 120846205)
-- RPG Developer Bakin Smile Objects Vol.2 (AppID: 2715340)
addappid(2715340)
addappid(2715340, 1, "be6e552c3de6ae837ec8d57603f51a19bc364155031d2e6e8355d185fba3c832") -- RPG Developer Bakin Smile Objects Vol.2 - Depot 2715340
setManifestid(2715340, "7609889368911751188", 120447924)
-- RPG Developer Bakin Ultra Building Pack (AppID: 2726620)
addappid(2726620)
addappid(2726620, 1, "9de8096e700bef31c447380f70ab03492b4de08d9a6c9d0e9fdb39b9ff035bdb") -- RPG Developer Bakin Ultra Building Pack - Depot 2726620
setManifestid(2726620, "2885362337997248032", 392209322)
-- RPG Developer Bakin Layout Data Sci-Fi (AppID: 2928530)
addappid(2928530)
addappid(2928530, 1, "7238f821aaf164b1527667af6db34ae95e2fb85e38b50e1f01fb111da07a3e1f") -- RPG Developer Bakin Layout Data Sci-Fi - Depot 2928530
setManifestid(2928530, "4321774435784564392", 37725346)
-- RPG Developer Bakin Layout Data Classy (AppID: 2928550)
addappid(2928550)
addappid(2928550, 1, "56ba3609a2447308ca20623f4eb5f304cd427b310d004a0ecc507501fd1ffdad") -- RPG Developer Bakin Layout Data Classy - Depot 2928550
setManifestid(2928550, "3327119345995650966", 15912859)
-- RPG Developer Bakin Layout Data Comic (AppID: 2928560)
addappid(2928560)
addappid(2928560, 1, "bbf115b23fcadf411100fd4eaaa9a3a0a4d56c7a8f68a207d36330120954e0a3") -- RPG Developer Bakin Layout Data Comic - Depot 2928560
setManifestid(2928560, "8870852574919552992", 13372048)
-- RPG Developer Bakin PixelScapes Forest Pack (AppID: 2996360)
addappid(2996360)
addappid(2996360, 1, "bc479e510075416892a729b74f8b0619305b49899d6d0d155b8091947652a9a2") -- RPG Developer Bakin PixelScapes Forest Pack - Depot 2996360
setManifestid(2996360, "850159684735177173", 64086324)
-- RPG Developer Bakin Charming Chinese Townscape Pack (AppID: 3046970)
addappid(3046970)
addappid(3046970, 1, "6a81bf583075244cea46ebbcc2a90815fc2f23724c08f6ddb6c9d18fec34272a") -- RPG Developer Bakin Charming Chinese Townscape Pack - Depot 3046970
setManifestid(3046970, "2588586647629727343", 885409991)
-- RPG Developer Bakin Ancient Ruins Music Pack (AppID: 3078660)
addappid(3078660)
addappid(3078660, 1, "ebfb8ce1be18fd8e3c34a1d472d9c35af2982609a56bf45157ebedd0595189f1") -- RPG Developer Bakin Ancient Ruins Music Pack - Depot 3078660
setManifestid(3078660, "5891140545663105954", 63643229)
-- RPG Developer Bakin Modern Item Icons (AppID: 3106130)
addappid(3106130)
addappid(3106130, 1, "9cd415591db7db64da7559abc913a06ca7ffd73d89228557e285c7b8a6b443ca") -- RPG Developer Bakin Modern Item Icons - Depot 3106130
setManifestid(3106130, "7331008218069654487", 4539471)
-- RPG Developer Bakin PixelScapes Town Pack (AppID: 3118940)
addappid(3118940)
addappid(3118940, 1, "a9d980b0a805d10fa773b2f923a8f501f763b17799a4df0f8187ea3b78c4c08a") -- RPG Developer Bakin PixelScapes Town Pack - Depot 3118940
setManifestid(3118940, "5571860479359872727", 65317693)
-- RPG Developer Bakin Battle Fx Variations (AppID: 3150340)
addappid(3150340)
addappid(3150340, 1, "ab6edf3d6059865aaef5a87837be11cb7bd49d24480fbf5f55ff68e0351b39be") -- RPG Developer Bakin Battle Fx Variations - Depot 3150340
setManifestid(3150340, "584451032197238743", 656147932)
-- RPG Developer Bakin SCI-FI City Pack (AppID: 3150350)
addappid(3150350)
addappid(3150350, 1, "6a230fc11c9925fed6da42d675b012a9ab88b69b1c174b90e6b592a8b9d85055") -- RPG Developer Bakin SCI-FI City Pack - Depot 3150350
setManifestid(3150350, "5582032407122212409", 179957990)
-- RPG Developer Bakin Abandoned Sewer (AppID: 3150360)
addappid(3150360)
addappid(3150360, 1, "26bb28dff5b0c208a973ad22ba5af7ad952714d4a6e5985dda3f76ffb06984ea") -- RPG Developer Bakin Abandoned Sewer - Depot 3150360
setManifestid(3150360, "1382688723392140708", 377739127)
-- RPG Developer Bakin Wooden Fort (AppID: 3150370)
addappid(3150370)
addappid(3150370, 1, "a7d048a97a14445d1ec854d35f2007e8364e479400e8a1005451512e830b03e9") -- RPG Developer Bakin Wooden Fort - Depot 3150370
setManifestid(3150370, "4139866515756611024", 71277094)
-- RPG Developer Bakin SMILE Characters DX Vol.1 (AppID: 3224360)
addappid(3224360)
addappid(3224360, 1, "b224cb3176f377f06cbcbbfa671530c03d3bef9e218297b61596cfdfefa251d3") -- RPG Developer Bakin SMILE Characters DX Vol.1 - Depot 3224360
setManifestid(3224360, "7530305680007661157", 365456081)
-- RPG Developer Bakin Ultimate Modular Swords (AppID: 3224370)
addappid(3224370)
addappid(3224370, 1, "292ec224bb1c77b09a47112414b0af6e79ba4476ea39355ec18b77dfca4d600b") -- RPG Developer Bakin Ultimate Modular Swords - Depot 3224370
setManifestid(3224370, "354765079640185027", 471432441)
-- RPG Developer Bakin Desert Town Pack (AppID: 3285270)
addappid(3285270)
addappid(3285270, 1, "102f85070655f348caaf659643d016b0108dbee398c024e9a5ef503194c48cf2") -- RPG Developer Bakin Desert Town Pack - Depot 3285270
setManifestid(3285270, "1960173714707393469", 674067643)
-- RPG Developer Bakin Leafy Lodge (AppID: 3345070)
addappid(3345070)
addappid(3345070, 1, "6c051aad81c8962d9209dd76c72cb7602db8783f9badda50f86af6233d6f502f") -- RPG Developer Bakin Leafy Lodge - Depot 3345070
setManifestid(3345070, "6294789319899078601", 941663789)
-- RPG Developer Bakin Modern Hospital Pack (AppID: 3345080)
addappid(3345080)
addappid(3345080, 1, "4963ac48442d221bbe3fa50177773070e6dfd77bbea99297e32b40e96ed0b238") -- RPG Developer Bakin Modern Hospital Pack - Depot 3345080
setManifestid(3345080, "6990941635998834765", 318739502)
-- RPG Developer Bakin PixelScapes Castle Pack (AppID: 3345090)
addappid(3345090)
addappid(3345090, 1, "a5069f3daab1e2b3c8b7860276383ee595918cec1061e4b7b2acc9f998d25a4f") -- RPG Developer Bakin PixelScapes Castle Pack - Depot 3345090
setManifestid(3345090, "1430578278988488092", 31823707)
-- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.1 (AppID: 3389090)
addappid(3389090)
addappid(3389090, 1, "314a1c11b79cac2f8d92b101ab4bf235d212683366f81b1b236e774bdbefedab") -- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.1 - Depot 3389090
setManifestid(3389090, "7543932994936494539", 78933355)
-- RPG Developer Bakin Modular Cemetery (AppID: 3510800)
addappid(3510800)
addappid(3510800, 1, "583083dee24bba9159aa3b6ba35fa804a9b661fe4f7a176f8860767b4f46cb9c") -- RPG Developer Bakin Modular Cemetery - Depot 3510800
setManifestid(3510800, "6330331745905440826", 350659660)
-- RPG Developer Bakin City Assets (AppID: 3510810)
addappid(3510810)
addappid(3510810, 1, "35c0b9e0fb63beea335314705a4b9296a03f712d2371745228e955dfcf8d6e70") -- RPG Developer Bakin City Assets - Depot 3510810
setManifestid(3510810, "6087989853863674826", 181144575)
-- RPG Developer Bakin Aztec Temple (AppID: 3545820)
addappid(3545820)
addappid(3545820, 1, "5fbbb668b89a423de79c966606884379d81a07031af1d4f25aec2d60be83a912") -- RPG Developer Bakin Aztec Temple - Depot 3545820
setManifestid(3545820, "2603990176579570738", 444347646)
-- RPG Developer Bakin Primitive Village (AppID: 3545830)
addappid(3545830)
addappid(3545830, 1, "1babd9c13f366c85d90130f3c8e3c1ac2ae9a58af604abd86608f6df798e27c3") -- RPG Developer Bakin Primitive Village - Depot 3545830
setManifestid(3545830, "1861697260329061637", 663091913)
-- RPG Developer Bakin Modular Medieval Signs (AppID: 3545840)
addappid(3545840)
addappid(3545840, 1, "5761af71f7ed17552629027b8ff6d92850f28f64815f9dbbd8682c1d61bb6ef6") -- RPG Developer Bakin Modular Medieval Signs - Depot 3545840
setManifestid(3545840, "702233179183697553", 502333530)
-- RPG Developer Bakin SMILE Characters DX Vol.2 (AppID: 3545860)
addappid(3545860)
addappid(3545860, 1, "0485f00bde7b6f6d850bd50cb07e62056a5fbe33cf681c9362c2c30ff084b430") -- RPG Developer Bakin SMILE Characters DX Vol.2 - Depot 3545860
setManifestid(3545860, "4978986663042429109", 245375179)
-- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.2 (AppID: 3545870)
addappid(3545870)
addappid(3545870, 1, "97ea321bf7b993e1e16e505f9eab56dc15ef486c547fad9bb84e9e575bbf0c8e") -- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.2 - Depot 3545870
setManifestid(3545870, "3176279889794482508", 253545850)
-- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.1 (AppID: 3611660)
addappid(3611660)
addappid(3611660, 1, "0673919eb1c778112ff1cc3a9bef4e21268c28028f7e0047edd3e6c391781c7d") -- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.1 - Depot 3611660
setManifestid(3611660, "707974971391894723", 46287503)
-- RPG Developer Bakin PixelScapes Desert Pack (AppID: 3611680)
addappid(3611680)
addappid(3611680, 1, "4d1497e74e4190d3b2e8b558b2f09aa6e2f53a4a9ae5ceff788e1764e0da154d") -- RPG Developer Bakin PixelScapes Desert Pack - Depot 3611680
setManifestid(3611680, "6193689992272914207", 20994243)
-- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.3 (AppID: 3611690)
addappid(3611690)
addappid(3611690, 1, "8488eeba4048e692d3d395d48ded70958d23117ab05e02d2515924251d3fcee0") -- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.3 - Depot 3611690
setManifestid(3611690, "2299832686937523378", 78887923)
-- RPG Developer Bakin Floating Islands (AppID: 3675970)
addappid(3675970)
addappid(3675970, 1, "5283ad991b16b4eda65e6fe4959e80bb5503d97d81ee46e11947e59844db0f3a") -- RPG Developer Bakin Floating Islands - Depot 3675970
setManifestid(3675970, "4170841039250184069", 7478830407)
-- RPG Developer Bakin PixelScapes Winter Pack (AppID: 3743010)
addappid(3743010)
addappid(3743010, 1, "e1c8fcc43fd4d4eb258c1d9d3b9f775c5fed447bb3723df951b96890e81fc062") -- RPG Developer Bakin PixelScapes Winter Pack - Depot 3743010
setManifestid(3743010, "815624779260681877", 57721967)
-- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.1 (AppID: 3743020)
addappid(3743020)
addappid(3743020, 1, "efec499d29b047690a8ee2b9394d7d14c81e9037521c8a0eea721be8cf0698b8") -- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.1 - Depot 3743020
setManifestid(3743020, "7839435974282276235", 41072066)
-- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.4 (AppID: 3748420)
addappid(3748420)
addappid(3748420, 1, "2ee123da7412bd5882fb797c37b0db8fc9edc7b807970937f267b8f21e4b3d35") -- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.4 - Depot 3748420
setManifestid(3748420, "7552320543041169080", 85033517)
-- RPG Developer Bakin House Builder Pack Asian Style (AppID: 3792080)
addappid(3792080)
addappid(3792080, 1, "ffe8c12b539e2db108c259cef6fd8ce299aceb346eae123b333e2f1e1e497afe") -- RPG Developer Bakin House Builder Pack Asian Style - Depot 3792080
setManifestid(3792080, "862159880588486144", 303890443)
-- RPG Developer Bakin Ultra Building Victorian Style (AppID: 3792090)
addappid(3792090)
addappid(3792090, 1, "f2a4f6c5edb9cca07265d8788b328e2526b63ae7eadfb8a6581cb243c6d7765b") -- RPG Developer Bakin Ultra Building Victorian Style - Depot 3792090
setManifestid(3792090, "7292099697626985031", 1002057487)
-- RPG Developer Bakin Classic RPG Music Pack (AppID: 3792100)
addappid(3792100)
addappid(3792100, 1, "f36b9cde80edb6d6e4a35d4aa08a4804eeab9a8db438554190be0beaa0a35ab9") -- RPG Developer Bakin Classic RPG Music Pack - Depot 3792100
setManifestid(3792100, "6423690799603655014", 170728055)
-- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.2 (AppID: 3853510)
addappid(3853510)
addappid(3853510, 1, "3561235d812084da8538b6f70e8858af5bbfa54470c50dbeacdbcc0c3085a20c") -- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.2 - Depot 3853510
setManifestid(3853510, "6189974817235579081", 40492460)
-- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.5 (AppID: 3853520)
addappid(3853520)
addappid(3853520, 1, "dc4a5f768bd7dee22f262b268f3d129771ff1d569e8d7e1b533b4b8d273c6e70") -- RPG Developer Bakin Mokemo Factory MONSTER PIXEL PACK Vol.5 - Depot 3853520
setManifestid(3853520, "4293959080680991572", 80002012)
-- RPG Developer Bakin Previous BasicSet (AppID: 3891720)
addappid(3891720)
addappid(3891720, 1, "e5a66e2e291180ba1167c5a0aa0158fbbf502172e378323b1b5f8e2517c30fae") -- RPG Developer Bakin Previous BasicSet - Depot 3891720
setManifestid(3891720, "6351069278390288443", 845563546)
-- RPG Developer Bakin Localization Toolkit (AppID: 3920860)
addappid(3920860)
addappid(3920860, 1, "d03d28d248caabb1442703436428cf218cd26b6d17110d47a3e56721c6885987") -- RPG Developer Bakin Localization Toolkit - Depot 3920860
setManifestid(3920860, "8640280577478235383", 1399360)
-- RPG Developer Bakin Crafting System (AppID: 3921180)
addappid(3921180)
addappid(3921180, 1, "7543168e8f88c607bf700c90cd6d894994af64f792799e2823e201325cf6ae61") -- RPG Developer Bakin Crafting System - Depot 3921180
setManifestid(3921180, "3655152326807099434", 1002447076)
-- RPG Developer Bakin Modular Fence (AppID: 3921190)
addappid(3921190)
addappid(3921190, 1, "c775e9e8e2825ddf4f8107973761eff4e5ebb5cf2ad7419ec94cdf95bd85f528") -- RPG Developer Bakin Modular Fence - Depot 3921190
setManifestid(3921190, "8962380215047873278", 164726901)
-- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.2 (AppID: 4007350)
addappid(4007350)
addappid(4007350, 1, "69bc5c7ccd17013571cb5bce898e1c939fe4aeb89b420d79718ff16ed2f1e2bd") -- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.2 - Depot 4007350
setManifestid(4007350, "2273785723559638127", 41798964)
-- RPG Developer Bakin PixelScapes Modern Suburban Pack (AppID: 4007360)
addappid(4007360)
addappid(4007360, 1, "96423328918aef0d86bc4c512b3b052e306ce6ce400f114125dbd59ec5d08f04") -- RPG Developer Bakin PixelScapes Modern Suburban Pack - Depot 4007360
setManifestid(4007360, "6037582867109453309", 12117226)
-- RPG Developer Bakin Clean City Kit (AppID: 4093410)
addappid(4093410)
addappid(4093410, 1, "ccd3f77217e8bfc42397a01b5dce6b4c24f1fa2aa4f6166fc2c32f2e56e358eb") -- RPG Developer Bakin Clean City Kit - Depot 4093410
setManifestid(4093410, "6080122372662236234", 107383678)
-- RPG Developer Bakin Smile Objects Vol.3 (AppID: 4093420)
addappid(4093420)
addappid(4093420, 1, "43fe984ee76d0dc514b7ba84670591d3cf189e42dbbe551105f6024b7cc443d8") -- RPG Developer Bakin Smile Objects Vol.3 - Depot 4093420
setManifestid(4093420, "960183248641964664", 241455438)
-- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.3 (AppID: 4164080)
addappid(4164080)
addappid(4164080, 1, "4d86a45ac80153247ade9ae59c5eaad74182f99ea0864452f075b56f15b14aed") -- RPG Developer Bakin Vibrato NPC PIXEL PACK Vol.3 - Depot 4164080
setManifestid(4164080, "1742772480072362932", 42670024)
-- RPG Developer Bakin Talking Sounds (AppID: 4164100)
addappid(4164100)
addappid(4164100, 1, "66b19b79902d1fc099364d62e87f60df7750e41f87ab4be8b5d707ac204f1107") -- RPG Developer Bakin Talking Sounds - Depot 4164100
setManifestid(4164100, "6132635999662824997", 236874056)
-- RPG Developer Bakin Retro Tiny Dungeon (AppID: 4179130)
addappid(4179130)
addappid(4179130, 1, "babf26a26c01b2b6ec37c04b5d9ea9fc960ae107f1a6c2021682417a306688d3") -- RPG Developer Bakin Retro Tiny Dungeon - Depot 4179130
setManifestid(4179130, "8837418501378764045", 98701991)
-- RPG Developer Bakin EVFX Sanctuary (AppID: 4198860)
addappid(4198860)
addappid(4198860, 1, "76acdd6d7c34fa0866409950614b5ee196f8473ddad82f674c2d68da57380fd9") -- RPG Developer Bakin EVFX Sanctuary - Depot 4198860
setManifestid(4198860, "448460221525403628", 8258482)
-- RPG Developer Bakin EVFX Shoot (AppID: 4198870)
addappid(4198870)
addappid(4198870, 1, "31f2eb36ba1573531ee6e7a94aeffea10607da0275bfd195906bc44b7afc5e9c") -- RPG Developer Bakin EVFX Shoot - Depot 4198870
setManifestid(4198870, "28952617609815895", 8744506)
-- RPG Developer Bakin EVFX Pierce (AppID: 4198880)
addappid(4198880)
addappid(4198880, 1, "32d2bf8038c02d744bf9799fd71f7814bb4250cc1bc3d865507ac150e37acca4") -- RPG Developer Bakin EVFX Pierce - Depot 4198880
setManifestid(4198880, "6207172713506519949", 14934995)
-- RPG Developer Bakin Iconography 1 (AppID: 4198890)
addappid(4198890)
addappid(4198890, 1, "4321dbf46c77d52ed073e464f0312456eca980aa0c05332a49ca169f167da88f") -- RPG Developer Bakin Iconography 1 - Depot 4198890
setManifestid(4198890, "9038368425604118991", 12058109)
-- RPG Developer Bakin Sea Islands (AppID: 4281840)
addappid(4281840)
addappid(4281840, 1, "14c8db7e7fb93a6bfaa1c6a0c416a4a1e05ee7b663ffa80bbedc40e7a7ffdb40") -- RPG Developer Bakin Sea Islands - Depot 4281840
setManifestid(4281840, "5641926708276334954", 787705215)
-- RPG Developer Bakin PixelScapes Modern Interior Pack (AppID: 4330390)
addappid(4330390)
addappid(4330390, 1, "85244c886c55cb08a6f54d335cc660b9b254fcee808edd082eb2133dc5b8d751") -- RPG Developer Bakin PixelScapes Modern Interior Pack - Depot 4330390
setManifestid(4330390, "532028077357166974", 7236414)
-- RPG Developer Bakin BGM PackTENKAI (AppID: 4330400)
addappid(4330400)
addappid(4330400, 1, "cc81a990d8cf0cbb59b846ce9fb4e5ec4e382d34285c95a15d233a5755edb5d7") -- RPG Developer Bakin BGM PackTENKAI - Depot 4330400
setManifestid(4330400, "4776894492247980377", 92921346)
-- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.3 (AppID: 4371630)
addappid(4371630)
addappid(4371630, 1, "cd665a9966b8581b2fa0b32e78b69f63ac7cead37ef4ca1b82fa234f897c98b8") -- RPG Developer Bakin Vibrato HERO PIXEL PACK Vol.3 - Depot 4371630
setManifestid(4371630, "2018561243894982054", 48500728)
-- RPG Developer Bakin EVFX Slash (AppID: 4375810)
addappid(4375810)
addappid(4375810, 1, "dd417e243bfa883bd7b43e6b47b8b764b40f41f13301dd06df0105c56b9adbb9") -- RPG Developer Bakin EVFX Slash - Depot 4375810
setManifestid(4375810, "4887340852512968870", 10012279)
-- RPG Developer Bakin EVFX Strike (AppID: 4375820)
addappid(4375820)
addappid(4375820, 1, "1199c113d76528964e635acfe6b21f220ddf68f87a843f54bf5cca79f1e6e9a4") -- RPG Developer Bakin EVFX Strike - Depot 4375820
setManifestid(4375820, "2955485641412772403", 8024046)
-- RPG Developer Bakin EVFX Blast (AppID: 4375830)
addappid(4375830)
addappid(4375830, 1, "163b5a17c2641b8102bd1a0dc18f779e84c663d132efe408f6cab99ee9ae7016") -- RPG Developer Bakin EVFX Blast - Depot 4375830
setManifestid(4375830, "8777557083068957700", 14250308)
-- RPG Developer Bakin Iconography 2 (AppID: 4375840)
addappid(4375840)
addappid(4375840, 1, "e117c6b092e846c27b5c549c5016c93f7330ab140fef45a59a4ab719dbd63ba2") -- RPG Developer Bakin Iconography 2 - Depot 4375840
setManifestid(4375840, "8841281219978458301", 11831884)
-- RPG Developer Bakin Dead Trees (AppID: 4442080)
addappid(4442080)
addappid(4442080, 1, "4fe3bbd3c83c3cc32dfb2debb6d4e2f098aa6c2fc599ddca65e33403fe5b9b1e") -- RPG Developer Bakin Dead Trees - Depot 4442080
setManifestid(4442080, "3350550401042791371", 287674933)
-- RPG Developer Bakin Stylized Rocks (AppID: 4442090)
addappid(4442090)
addappid(4442090, 1, "db441468d1903b7037fd3ad8e84a4ff1317b1e98b38c68a9cac24975800f4d71") -- RPG Developer Bakin Stylized Rocks - Depot 4442090
setManifestid(4442090, "1231391023913982891", 489631314)
-- RPG Developer Bakin Stylized Monoliths (AppID: 4442100)
addappid(4442100)
addappid(4442100, 1, "fab336c2895914617115e9ef62f34be612e0f6b7095bd35d099fde266f93d4a5") -- RPG Developer Bakin Stylized Monoliths - Depot 4442100
setManifestid(4442100, "1013701482244372949", 225753563)
-- RPG Developer Bakin EVFX Frostforge (AppID: 4489720)
addappid(4489720)
addappid(4489720, 1, "51921b70aa6b7315fc4eb141c49754ba00c22ef398e249fa87d58cf751ded6e7") -- RPG Developer Bakin EVFX Frostforge - Depot 4489720
setManifestid(4489720, "8633834785941082012", 15591112)
-- RPG Developer Bakin EVFX Sparkforge (AppID: 4489730)
addappid(4489730)
addappid(4489730, 1, "2f9e991edfd3944f5f0ad5566286cd62802260be96ba4eb76db96922bbef9ac9") -- RPG Developer Bakin EVFX Sparkforge - Depot 4489730
setManifestid(4489730, "1792518469927350358", 22390319)
-- RPG Developer Bakin EVFX Stormforge (AppID: 4489740)
addappid(4489740)
addappid(4489740, 1, "b2dbd6225ef3e832967198f11786659e05a3b0a54bee895c36c6c4c3cb55100a") -- RPG Developer Bakin EVFX Stormforge - Depot 4489740
setManifestid(4489740, "6993076428094905537", 16079197)
-- RPG Developer Bakin EVFX Floodforge (AppID: 4552290)
addappid(4552290)
addappid(4552290, 1, "52179b48026202b0d99695bd25de89a9f3da3c2d8b17866ab5080eea0c192480") -- RPG Developer Bakin EVFX Floodforge - Depot 4552290
setManifestid(4552290, "8116086753987272567", 34221751)
-- RPG Developer Bakin EVFX Blazeforge (AppID: 4552300)
addappid(4552300)
addappid(4552300, 1, "ba4cab0666484975f9bc39cda96c6717cd5604e5ac98ab1acf0c1ace3e566a84") -- RPG Developer Bakin EVFX Blazeforge - Depot 4552300
setManifestid(4552300, "8084711935561375136", 30728300)
-- RPG Developer Bakin EVFX Shadeforge (AppID: 4552310)
addappid(4552310)
addappid(4552310, 1, "fd96e407b04be40a78f3616bc95aafdca0527dda2fe55598607d649336f92580") -- RPG Developer Bakin EVFX Shadeforge - Depot 4552310
setManifestid(4552310, "1364326114969889277", 22393225)
-- RPG Developer Bakin EVFX Shineforge (AppID: 4552320)
addappid(4552320)
addappid(4552320, 1, "91662c6763061007f578970afd64e455516aeac5569ec808aff7b66ab29e8a50") -- RPG Developer Bakin EVFX Shineforge - Depot 4552320
setManifestid(4552320, "3581361254156023066", 14377887)
-- RPG Developer Bakin Iconography 4 (AppID: 4552330)
addappid(4552330)
addappid(4552330, 1, "952a71c03ea79ce7236bc2180ba3e5481638092dce83d03c22ca5b028609b2ae") -- RPG Developer Bakin Iconography 4 - Depot 4552330
setManifestid(4552330, "864491623150440921", 11914514)
-- RPG Developer Bakin Ultra Building Asian Style (AppID: 4553680)
addappid(4553680)
addappid(4553680, 1, "6e06a5ef693fee5dd24dcda9b2bf674509f48e314a63aac40cc56a826fe6a336") -- RPG Developer Bakin Ultra Building Asian Style - Depot 4553680
setManifestid(4553680, "594282488093936375", 378681686)
-- RPG Developer Bakin BGM Pack 8-bit Odyssey (AppID: 4659570)
addappid(4659570)
addappid(4659570, 1, "2f59e97d1b720e2fecda923e1866ee6e7a972df4f3e36893afedadf5a580f61f") -- RPG Developer Bakin BGM Pack 8-bit Odyssey - Depot 4659570
setManifestid(4659570, "6719164765937282251", 122902111)
-- RPG Developer Bakin EVFX Astroforge (AppID: 4691900)
addappid(4691900)
addappid(4691900, 1, "6a469dd9bfe3e93946b4b7e6f98305eb5aaf2e84797dc68fe61b491669d049a0") -- RPG Developer Bakin EVFX Astroforge - Depot 4691900
setManifestid(4691900, "791440581528081923", 33767787)
-- RPG Developer Bakin EVFX Bloomforge (AppID: 4691910)
addappid(4691910)
addappid(4691910, 1, "5654ff8e850bd82e11143e2d54c0d988fa1b3956a212bd03c437deb86d5fd2d1") -- RPG Developer Bakin EVFX Bloomforge - Depot 4691910
setManifestid(4691910, "3674741021279105857", 18514755)
-- RPG Developer Bakin EVFX Charmforge (AppID: 4691920)
addappid(4691920)
addappid(4691920, 1, "0a5906d0679d4af4ba35fdea7fb34566fcffff3aabbce3eb80f693adc57b14e6") -- RPG Developer Bakin EVFX Charmforge - Depot 4691920
setManifestid(4691920, "1086621748840493086", 21853698)
-- RPG Developer Bakin EVFX Soundforge (AppID: 4691930)
addappid(4691930)
addappid(4691930, 1, "cd8539b6499d6f7c97f35ced49931d05caeaac7c145acc35725f5d105972b1a4") -- RPG Developer Bakin EVFX Soundforge - Depot 4691930
setManifestid(4691930, "3962851409030712001", 19459523)
-- RPG Developer Bakin Iconography 5 (AppID: 4691940)
addappid(4691940)
addappid(4691940, 1, "6fdcdde362274fad2d13d7910a1b9a39c20ed3cd057adb69a5447b8c74b4a289") -- RPG Developer Bakin Iconography 5 - Depot 4691940
setManifestid(4691940, "2988346648365446197", 11765410)
-- RPG Developer Bakin Live2D Toolkit (AppID: 4753800)
addappid(4753800)
addappid(4753800, 1, "fd2fe4548ce159cb6555b72b263212b9c7c0c8d888f39525de6f67b0db163bc3") -- RPG Developer Bakin Live2D Toolkit - Depot 4753800
setManifestid(4753800, "8340715133343034744", 107862785)
-- RPG Developer Bakin Mokemo Factory Furry Monster Pack Vol.01 (AppID: 4763030)
addappid(4763030)
addappid(4763030, 1, "81d9c48a36d7333f58d069e5eed20064c96673dbec5e60af52a16ff30df69b09") -- RPG Developer Bakin Mokemo Factory Furry Monster Pack Vol.01 - Depot 4763030
setManifestid(4763030, "8685902609262221951", 996508443)
-- RPG Developer Bakin EVFX Bloodforge (AppID: 4786740)
addappid(4786740)
addappid(4786740, 1, "47569176f77f5e5e3b12c4e03785e5232d00f98ba26bf5fce82274e3f07e4bcf") -- RPG Developer Bakin EVFX Bloodforge - Depot 4786740
setManifestid(4786740, "1738004426348133495", 25770336)
-- RPG Developer Bakin EVFX Cyberforge (AppID: 4786760)
addappid(4786760)
addappid(4786760, 1, "0ecfa5ac68dc19b25ed4a0f3e340ac137cb7097a68a9cae4566d5c4edf913847") -- RPG Developer Bakin EVFX Cyberforge - Depot 4786760
setManifestid(4786760, "5934059177648395031", 19302071)
-- RPG Developer Bakin EVFX Dreadforge (AppID: 4786770)
addappid(4786770)
addappid(4786770, 1, "1425d34415dc5e438d5307e78fbfff3ba2593f3990c5a22e5c9c2d071911463c") -- RPG Developer Bakin EVFX Dreadforge - Depot 4786770
setManifestid(4786770, "5866194499808150799", 29256862)
-- RPG Developer Bakin EVFX Epochforge (AppID: 4786780)
addappid(4786780)
addappid(4786780, 1, "a469a23d036bc0c3bec70d45e27d9a342ccdb7efa8b8b69b1f34c6cf5ba0f2c6") -- RPG Developer Bakin EVFX Epochforge - Depot 4786780
setManifestid(4786780, "1403068447999539850", 23945457)
-- RPG Developer Bakin Iconography 6 (AppID: 4786790)
addappid(4786790)
addappid(4786790, 1, "64552ed7724560b14227047193f9b32bc5512074053f1c4961d61c7fb7b10fad") -- RPG Developer Bakin Iconography 6 - Depot 4786790
setManifestid(4786790, "2596161615655277726", 12149857)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- RPG Developer Bakin SMILE Characters DX Vol.3 (AppID: 4918910) - missing depot keys
-- addappid(4918910)
-- RPG Developer Bakin SGB Heroic Pixel Chr001 (AppID: 4918930) - missing depot keys
-- addappid(4918930)
-- RPG Developer Bakin SGB Heroic Pixel Chr002 (AppID: 4918940) - missing depot keys
-- addappid(4918940)
-- RPG Developer Bakin SGB Heroic Pixel Chr011 (AppID: 4918950) - missing depot keys
-- addappid(4918950)
-- RPG Developer Bakin SGB Heroic Pixel Chr012 (AppID: 4918960) - missing depot keys
-- addappid(4918960)