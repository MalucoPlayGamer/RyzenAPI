-- Lua provided by RyzenAPI
-- Game: MadCowBalls2

-- MAIN APPLICATION
addappid(1077680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077681, 1, "b39e681572e8dd16720d19970fe1d2c3b6c31abc64741165a30a68d9886ca3aa")
