-- Lua provided by SkyAPI 
-- Game: AppID 1077680
addappid(1077680)
addappid(1077681, 1, "b39e681572e8dd16720d19970fe1d2c3b6c31abc64741165a30a68d9886ca3aa")
