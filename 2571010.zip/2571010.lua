-- Lua provided by RyzenAPI
-- Game: 2571010

-- MAIN APPLICATION
addappid(2571010)
-- Game: addappid(2571010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571011, 1, "be93dd3036875358bb371ba972c67da0e9170cb760181b6accecff420db1967f")
