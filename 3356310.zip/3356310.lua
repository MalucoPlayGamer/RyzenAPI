-- Lua provided by RyzenAPI
-- Game: 3356310

-- MAIN APPLICATION
addappid(3356310)
-- Game: addappid(3356310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356311, 1, "ce88a6fd48d800d44ab6fb18aaa6c6f930efec10bf1b9c9626d09ed0b8776663")
