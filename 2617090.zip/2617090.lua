-- Lua provided by RyzenAPI
-- Game: Fowl Damage

-- MAIN APPLICATION
addappid(2617090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617091, 1, "1fd7a8fb031898d34b68cd154f05b093ca754b568e3ac7e5e9c9575cb485804d")
