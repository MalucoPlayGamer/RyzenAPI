-- Lua provided by RyzenAPI
-- Game: Fictorum

-- MAIN APPLICATION
addappid(503620)

-- MAIN APP DEPOTS / PACKAGES
addappid(503621, 1, "a5e969507978752e87f81baea91ccad061058ac114478fdeff067a99e6d936ab")
