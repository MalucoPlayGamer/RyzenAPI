-- Lua provided by RyzenAPI
-- Game: Fictorum

-- MAIN APPLICATION
addappid(503620)

-- MAIN APP DEPOTS / PACKAGES
addappid(503621, 1, "a5e969507978752e87f81baea91ccad061058ac114478fdeff067a99e6d936ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
