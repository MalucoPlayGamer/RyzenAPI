-- Lua provided by RyzenAPI
-- Game: addappid(2428790)

-- MAIN APPLICATION
addappid(2428790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428791, 1, "a8cb50ba55a28b6269a9fc093f3991bd899812112a957344e52b52db3d3e3b6a")
