-- Lua provided by RyzenAPI
-- Game: addappid(61520)

-- MAIN APPLICATION
addappid(61520)

-- MAIN APP DEPOTS / PACKAGES
addappid(61521, 1, "2c8a676dc64dd02828b82d9d48e583b01ab664b0ddab638137bb60c31a250dea")
