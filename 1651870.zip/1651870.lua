-- Lua provided by RyzenAPI
-- Game: Nighthunt

-- MAIN APPLICATION
addappid(1651870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651871, 1, "00e70a1ee3077d99f16143bd3230d20e0ff5dd6884f91252a8ebfd96dd134a40")

