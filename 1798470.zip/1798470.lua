-- Lua provided by RyzenAPI
-- Game: 1798470

-- MAIN APPLICATION
addappid(1798470)
-- Game: addappid(1798470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798471, 1, "7bd98347da284976cae47fd8fef4979e4f395634eb0670b75ab716dc182cb66c")
