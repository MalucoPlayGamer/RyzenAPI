-- Lua provided by SkyAPI 
-- Game: Love Tavern
addappid(1354230)
addappid(1354231, 1, "c2b04b2b62e2de8b09e24c7a617c5644599c023c70fc2ede9edf60d861771cf5")
addappid(1380590)
