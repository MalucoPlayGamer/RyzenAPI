-- Lua provided by RyzenAPI
-- Game: Game: Love Tavern

-- MAIN APPLICATION
addappid(1354230)
addappid(1380590)
-- Game: addappid(1354230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354231, 1, "c2b04b2b62e2de8b09e24c7a617c5644599c023c70fc2ede9edf60d861771cf5")
