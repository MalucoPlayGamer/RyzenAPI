-- Lua provided by RyzenAPI
-- Game: Game: AppID 2990410

-- MAIN APPLICATION
addappid(2990410)
-- Game: addappid(2990410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990411, 1, "e00786e8ddfbb5bf769067c331207a91981a2c459ef308f144040a13f69519fb")
