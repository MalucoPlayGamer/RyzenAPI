-- Lua provided by RyzenAPI
-- Game: 都给我下地狱 Demo

-- MAIN APPLICATION
addappid(2990410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990411, 1, "e00786e8ddfbb5bf769067c331207a91981a2c459ef308f144040a13f69519fb")
