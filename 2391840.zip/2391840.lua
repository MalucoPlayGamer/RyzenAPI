-- Lua provided by RyzenAPI
-- Game: Game: NejicomiSimulator TMA01

-- MAIN APPLICATION
addappid(2391840)
-- Game: addappid(2391840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391841, 1, "3d8686206e4915319f0c67a0509fc419791520e722e6bfee22211d41c727ef54")
