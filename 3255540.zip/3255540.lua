-- Lua provided by RyzenAPI
-- Game: These Darker Tides

-- MAIN APPLICATION
addappid(3255540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3255541, 1, "a951e4cb34d6b60d5aed268c82a7ba313fa908fa6d3d9823150d65d5764b8aeb")

