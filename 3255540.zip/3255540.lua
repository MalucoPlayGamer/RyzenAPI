-- Lua provided by RyzenAPI
-- Game: addappid(3255540)

-- MAIN APPLICATION
addappid(3255540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255541, 1, "a951e4cb34d6b60d5aed268c82a7ba313fa908fa6d3d9823150d65d5764b8aeb")
