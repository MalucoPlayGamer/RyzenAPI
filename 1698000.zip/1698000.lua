-- Lua provided by SkyAPI 
-- Game: Smash MAGA! Trump Zombie Apocalypse: Twilight of Empire
addappid(1698000)
addappid(1698001, 1, "49eb76eb17aab31c259ba65beca1339821b822a8b5018c57e33f1bbbdd898964")
addappid(1698002, 1, "f4b2b62148e83576f7179ccd31cddb00929cb7c90c1d2a9a13ba20319acb1dbd")
addappid(1698003, 1, "a765bcc7190f9b5650cf09f5e7c76945cf57cfe6da5ab5bfa3e79812d59678de")
