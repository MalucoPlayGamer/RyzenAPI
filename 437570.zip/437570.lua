-- Lua provided by RyzenAPI
-- Game: 437570

-- MAIN APPLICATION
addappid(437570)
-- Game: addappid(437570)

-- MAIN APP DEPOTS / PACKAGES
addappid(437571, 1, "74289b7f9336ad3a455a221cf3715e45aa22d3e8b7c4b2f6cbb98fa5b60f96fd")
addappid(437572, 1, "28ae6a9830fb0535e7d30e7bb33319d61dbcd96eb3bdc7df4c076d782c44449b")
addappid(437573, 1, "f40db96cfeff5945f302456626cb8b8a4b990ee7757d835f72563e48e8d8fdd0")
