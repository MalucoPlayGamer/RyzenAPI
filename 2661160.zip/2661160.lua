-- Lua provided by RyzenAPI
-- Game: Game: Goober Dash

-- MAIN APPLICATION
addappid(2661160)
-- Game: addappid(2661160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661161, 1, "024f0539c59df6043d77adfed596969e3ecca65035d5ae220a5450abb8a8741c")
addappid(2661162, 1, "aec96cfd0bf62791add96afcc23f88b2df33c5a04002349c297d66c108120cf9")
addappid(2661163, 1, "dcfa8a45d8c2b8504eb0d38581509ec39430936b7b432d3059a3d1c7b77c470a")
addappid(2661164, 1, "cfa690087dcbb6ba2dd5b9b2475a863368575161791d01e2f47b17530ed39e0d")
