-- Lua provided by RyzenAPI
-- Game: I Am The Registered Environmental Engineer Demo

-- MAIN APPLICATION
addappid(3137610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137611, 1, "44a8f604053bbd6e96f1c9fb64718d3dd0623a1e7540e18170d149120fc252f6")
