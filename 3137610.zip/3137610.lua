-- Lua provided by SkyAPI 
-- Game: I Am The Registered Environmental Engineer Demo
addappid(3137610)
addappid(3137611, 1, "44a8f604053bbd6e96f1c9fb64718d3dd0623a1e7540e18170d149120fc252f6")
