-- Lua provided by RyzenAPI
-- Game: Data mining 5

-- MAIN APPLICATION
addappid(1012860)
-- Game: addappid(1012860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012861, 1, "c2cff0b3a989d08a22656e19cabb76cfaaac736c3767c99ce9f23210c37818cb")
