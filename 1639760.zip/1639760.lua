-- Lua provided by RyzenAPI
-- Game: 1639760

-- MAIN APPLICATION
addappid(1639760)
-- Game: addappid(1639760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639761, 1, "9ac9a09f54841891ef35d07ab287b2263ef72f9fffe7e58e89c32e61663b487d")
addappid(1639762, 1, "da93da1edea4d87dad079e57647ccddbb6db2f1fd797d969982ea635efd7713c")
addappid(1639763, 1, "61656d5954a728cdf22350c42aaf6a3b76b702a4313013406ed72b8750c94622")
addappid(1639764, 1, "bf093fb04a05cdaef1bde3041d3e22dbb486cd3826a1ccae16ada70d1a345ca6")
