-- Lua provided by RyzenAPI
-- Game: ARMA: Cold War Assault

-- MAIN APPLICATION
addappid(65790)

-- MAIN APP DEPOTS / PACKAGES
addappid(65791, 1, "4875303350f459c37a78d1edc36d9de1dd33f0bf39c8fd5f67f392c2e7eedc1a")
