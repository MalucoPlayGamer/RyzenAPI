-- Lua provided by SkyAPI 
-- Game: ARMA: Cold War Assault
addappid(65790)
addappid(65791, 1, "4875303350f459c37a78d1edc36d9de1dd33f0bf39c8fd5f67f392c2e7eedc1a")
