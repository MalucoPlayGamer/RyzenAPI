-- Lua provided by RyzenAPI
-- Game: Dig Island

-- MAIN APPLICATION
addappid(3919360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3919361,0,"0b0499fdff07763dee353142db7f07cdb996abc16513ee7d72da6808d5a9f80b")

