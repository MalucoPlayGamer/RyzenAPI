-- Lua provided by RyzenAPI
-- Game: Dig Island

-- MAIN APPLICATION
addappid(3919360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3919361,0,"0b0499fdff07763dee353142db7f07cdb996abc16513ee7d72da6808d5a9f80b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
