-- Lua provided by RyzenAPI
-- Game: Archer's Adventure

-- MAIN APPLICATION
addappid(1720650)
-- Game: addappid(1720650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720651, 1, "312eb0daecf3870b836a68f9825aa09c82214820f4244ab319e1af839646ca51")
