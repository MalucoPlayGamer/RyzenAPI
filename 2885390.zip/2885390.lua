-- Lua provided by RyzenAPI
-- Game: 2885390

-- MAIN APPLICATION
addappid(2885390)
-- Game: addappid(2885390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885390,0,"f576d68dd367d474b2cab70ca21aa4b1ea75eacc3fbf41c70eb2913bb1c8541d")
