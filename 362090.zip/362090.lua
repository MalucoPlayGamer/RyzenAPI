-- Lua provided by RyzenAPI
-- Game: AppID 362090

-- MAIN APPLICATION
addappid(362090)
addappid(372550)
-- Game: addappid(362090)

-- MAIN APP DEPOTS / PACKAGES
addappid(362091, 1, "3c47fff8819eeb83ef20e448f751d639a1aca6497ad00e8aa57fc10514f83a4f")
addappid(362092, 1, "4ad138b7a717c454253882ca556370ff0c4d098b4bb52880c984856f56e17651")
addappid(362093, 1, "a4e31e1e1da2df27225c11eeb3d567dee2bdbaddb877f060f6561cd00137d9c6")
