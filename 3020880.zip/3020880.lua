-- Lua provided by RyzenAPI
-- Game: addappid(3020880)

-- MAIN APPLICATION
addappid(3020880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020881, 1, "f4696de159a06ef272a40d8ccd393ca326fc8bbac1730487ae5819aae027c666")
