-- Lua provided by RyzenAPI
-- Game: 776650

-- MAIN APPLICATION
addappid(776650)
-- Game: addappid(776650)

-- MAIN APP DEPOTS / PACKAGES
addappid(776651, 1, "e326de95bb93613b267293c06ee2711f06c9da21e725182f05b20937f6c117b4")
