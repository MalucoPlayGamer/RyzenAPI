-- Lua provided by RyzenAPI
-- Game: Half-Life: Source

-- MAIN APPLICATION
addappid(280)
addappid(326870)
-- Game: addappid(280)

-- MAIN APP DEPOTS / PACKAGES
addappid(281, 1, "fc30f594e6afe8487bb794a771fc34b1a57b4e66bb495f0cf4d456561b8b9abe")
addappid(282, 1, "dc83354067289e4d5636d1a38e2b309871157dd7c7fc8e56f40306488e70728f")
addappid(283, 1, "c419d701f6291a1f598b9021771ce751ca2a773e9f31fc9f4bb1323999d7fce2")
addappid(284, 1, "027cacd3021de8d0406734a8360fee4919592477b60ec853a3b812e4f92475a1")
addappid(285, 1, "a0dcee1657fd358ed677d9d6dac8f9b5956ac8e1f5b95945e4ce57b07f81f60d")
addappid(286, 1, "dd70a5f74670d3ee171a181ce631a0cd4956050ea795c98f3dc95d6c082ff8db")
addappid(287, 1, "3fe2f72d6f313fe8c890b188d5f82ea6702a8dd248e1b0329e69ed47b3a7d507")
addappid(288, 1, "51d5efccf499a967259f2228e20766b8c272d0b5ac115c1da2d6a36f12344c94")
