-- Lua provided by RyzenAPI
-- Game: 1875830

-- MAIN APPLICATION
addappid(1875830)
addappid(2106500)
addappid(2107720)
addappid(2107721)
addappid(2107722)
addappid(2107723)
addappid(2107724)
addappid(2107725)
-- Game: addappid(1875830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875831, 1, "ecd77d383bad5fdeb0b12f95bc0116b54f500cc13db04b25ee0e630b1cab32d8")
