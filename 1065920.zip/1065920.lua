-- Lua provided by RyzenAPI
-- Game: 1065920

-- MAIN APPLICATION
addappid(1065920)
-- Game: addappid(1065920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065921, 1, "bb19e16098aeb130603092f11928a4371c1dba937c9e98f436efdfd9c7afb5e1")
