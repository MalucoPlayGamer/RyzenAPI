-- Lua provided by RyzenAPI
-- Game: DoomAI

-- MAIN APPLICATION
addappid(1065920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1065921, 1, "bb19e16098aeb130603092f11928a4371c1dba937c9e98f436efdfd9c7afb5e1")
