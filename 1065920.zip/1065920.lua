-- Lua provided by RyzenAPI 
-- Game: AppID 1065920
addappid(1065920)
addappid(1065921, 1, "bb19e16098aeb130603092f11928a4371c1dba937c9e98f436efdfd9c7afb5e1")
