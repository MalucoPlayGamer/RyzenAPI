-- Lua provided by RyzenAPI
-- Game: Game: Tetris® Effect: Connected

-- MAIN APPLICATION
addappid(1003590)
-- Game: addappid(1003590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003591, 1, "99b924e52d47af4370ef8c397f6e2c53178b23c304560199bd8e2db4220c35f2")
addappid(1723660, 0, "0999f814c44b12525a2676534b835e6957538f9d9e221e50386ab04d77827e86")
