-- Lua provided by RyzenAPI
-- Game: Tetris® Effect: Connected

-- MAIN APPLICATION
addappid(1003590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1003591, 1, "99b924e52d47af4370ef8c397f6e2c53178b23c304560199bd8e2db4220c35f2")
addappid(1723660, 0, "0999f814c44b12525a2676534b835e6957538f9d9e221e50386ab04d77827e86")

