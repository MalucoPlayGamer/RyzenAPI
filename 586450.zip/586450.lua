-- Lua provided by SkyAPI 
-- Game: AppID 586450
addappid(586450)
addappid(586451, 1, "92deeb9c1ca1f248b803e5efca53e8ba99280725d246a1646d26a6e9dd6ec473")
