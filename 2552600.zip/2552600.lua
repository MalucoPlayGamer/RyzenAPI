-- Lua provided by RyzenAPI
-- Game: Muscle Ninja VR

-- MAIN APPLICATION
addappid(2552600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552601, 1, "34cfcbf313853d2bd426fe130bb5e4cb7dffc1e849a8055b46660fd75a9683aa")

