-- Lua provided by RyzenAPI
-- Game: 339290

-- MAIN APPLICATION
addappid(339290)
-- Game: addappid(339290)

-- MAIN APP DEPOTS / PACKAGES
addappid(339291, 1, "ba02c544dbdcd0cb0c3c0e8f2a4f2f00c83855b7e3df41e4b88734244ac65fb5")
