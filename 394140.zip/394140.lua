-- Lua provided by RyzenAPI
-- Game: Sound Shift

-- MAIN APPLICATION
addappid(394140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(394141, 1, "e62b01561c714bc4d4f26ffa59cea7333df436d409bea05614b3ad9c946da2b5")

