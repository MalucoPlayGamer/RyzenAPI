-- Lua provided by RyzenAPI
-- Game: 394140

-- MAIN APPLICATION
addappid(394140)
-- Game: addappid(394140)

-- MAIN APP DEPOTS / PACKAGES
addappid(394141, 1, "e62b01561c714bc4d4f26ffa59cea7333df436d409bea05614b3ad9c946da2b5")
