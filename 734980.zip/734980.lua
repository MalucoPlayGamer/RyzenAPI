-- Lua provided by RyzenAPI 
-- Game: Prosperity
addappid(734980)
addappid(734981, 1, "ce5d5396a1c359fc4875189a4e27f1cc02df37a5fd7536ad4b211a2b1c5601c6")
addappid(734982, 1, "5164248b2b26868201c836340c285c8cd705406ccae8b8dc523b7c34b97be8cc")
