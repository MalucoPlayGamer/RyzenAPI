-- Lua provided by RyzenAPI
-- Game: 2551780

-- MAIN APPLICATION
addappid(2551780)
addappid(2679330)
-- Game: addappid(2551780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551781, 1, "1ebcd509d738ae4647a9cebd1be634e65336f3633d3b987da97c24bec76095af")
