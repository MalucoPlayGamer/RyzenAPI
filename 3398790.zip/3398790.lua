-- Lua provided by RyzenAPI
-- Game: addappid(3398790)

-- MAIN APPLICATION
addappid(3398790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398791, 1, "0802da0872a6770ab23706a6e488b9507bc395fe02e86e41bbbfcec1f7de3a39")
