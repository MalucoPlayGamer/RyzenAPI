-- Lua provided by RyzenAPI
-- Game: Hunters Inc

-- MAIN APPLICATION
addappid(2937090)
addappid(3845540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2937091, 1, "8a1b2ac1588429ffed3a68592aa3ac6a65578f869686b62c0cc821b52b5f9dba")

