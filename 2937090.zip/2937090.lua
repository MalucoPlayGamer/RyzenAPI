-- Lua provided by RyzenAPI
-- Game: Hunters Inc

-- MAIN APPLICATION
addappid(2937090)
addappid(3845540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937091, 1, "8a1b2ac1588429ffed3a68592aa3ac6a65578f869686b62c0cc821b52b5f9dba")
