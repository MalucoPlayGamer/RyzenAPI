-- Lua provided by RyzenAPI
-- Game: Game: Wijita: City of Makers Demo

-- MAIN APPLICATION
addappid(2858460)
-- Game: addappid(2858460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858461, 1, "2cf1ca0ed6c2d014d5f31b425851122577cbfaf40ceb6d5566055920abc02948")
