-- Lua provided by RyzenAPI
-- Game: addappid(2858460)

-- MAIN APPLICATION
addappid(2858460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858461, 1, "2cf1ca0ed6c2d014d5f31b425851122577cbfaf40ceb6d5566055920abc02948")
