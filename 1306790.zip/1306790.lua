-- Lua provided by RyzenAPI
-- Game: Putin kills: Coronavirus

-- MAIN APPLICATION
addappid(1306790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306791, 1, "57062f482e8a37d3cbb7681980dcca1793e137ea889694cf6a37973296eb13de")
