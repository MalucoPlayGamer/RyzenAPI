-- Lua provided by SkyAPI 
-- Game: AppID 1306790
addappid(1306790)
addappid(1306791, 1, "57062f482e8a37d3cbb7681980dcca1793e137ea889694cf6a37973296eb13de")
