-- Lua provided by RyzenAPI
-- Game: 風色幻想SP:封神之刻

-- MAIN APPLICATION
addappid(2020540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2020541, 1, "cad2a10cdaccf10725c59278d3309d3ddcd5f7b1d0a9876ec9c828dd94ca055d")
addappid(2020542, 1, "4d788c2e6e719f23b92c5c76e9c38aca83144b4253ca5f87ba4c3b603667de76")

