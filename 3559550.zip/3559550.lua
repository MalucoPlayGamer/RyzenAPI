-- Lua provided by RyzenAPI
-- Game: AppID 3559550

-- MAIN APPLICATION
addappid(3559550)
-- Game: addappid(3559550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3559551, 1, "fba2a756b0339bbbd261f3606456d6b76a408fc8f1431eca7303c87478e474ef")
