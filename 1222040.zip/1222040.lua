-- Lua provided by RyzenAPI
-- Game: Offroad Mania

-- MAIN APPLICATION
addappid(1222040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222041, 1, "5c59b27be9d77e02f0df158c0141ae19e50143e8af7f71811287278f2154fd14")

