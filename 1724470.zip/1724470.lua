-- Lua provided by RyzenAPI
-- Game: Game: Valkyrie: Journey To Midgard

-- MAIN APPLICATION
addappid(1724470)
-- Game: addappid(1724470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724471, 1, "1ff117800d147e76902001780fad563475421ee388a823a8ad25bf195554e88a")
