-- Lua provided by RyzenAPI
-- Game: Sea Balloon

-- MAIN APPLICATION
addappid(3516600)
-- Game: addappid(3516600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516601, 1, "7abcc569381b526c0b321f1c4f79a9600e69df1ccf2ce04a60cbb3da43243fe2")
