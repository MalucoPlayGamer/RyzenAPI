-- Lua provided by SkyAPI 
-- Game: Sea Balloon
addappid(3516600)
addappid(3516601, 1, "7abcc569381b526c0b321f1c4f79a9600e69df1ccf2ce04a60cbb3da43243fe2")
