-- Lua provided by RyzenAPI
-- Game: Animation for Clip maker

-- MAIN APPLICATION
addappid(1674690)
-- Game: addappid(1674690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674691, 1, "c302b03c1546415043c6c7b334aa4967bef799696ad0fbad653be672feb38bb1")
