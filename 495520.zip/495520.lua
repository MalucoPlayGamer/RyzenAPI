-- Lua provided by RyzenAPI
-- Game: Game: Ping Pong League

-- MAIN APPLICATION
addappid(495520)
-- Game: addappid(495520)

-- MAIN APP DEPOTS / PACKAGES
addappid(495521, 1, "4b864544aa0104e689d699de6fe482e956fd8cf513b092be4ba5991945b23ac5")
