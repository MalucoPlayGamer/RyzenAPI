-- Lua provided by RyzenAPI
-- Game: Game: Dreadful

-- MAIN APPLICATION
addappid(527880)
-- Game: addappid(527880)

-- MAIN APP DEPOTS / PACKAGES
addappid(527881, 1, "77832ef1a2ef914c652e6f4d7f1dceabeab6b5d6b0c425b8c5807a7f67b3439d")
