-- Lua provided by RyzenAPI
-- Game: Game: AppID 24860

-- MAIN APPLICATION
addappid(24860)
-- Game: addappid(24860)

-- MAIN APP DEPOTS / PACKAGES
addappid(24861, 1, "bc14f3793b1bfee249478af1f1d4bb85cb97cd3d74de972eaef57cfa8f9d7d13")
addappid(24862, 1, "b5dc053d10129208689e3dd62e4e09d4b72115132cf8561942463e41a9284910")
addappid(24863, 1, "3efeecb05118553e7a13cbb1ba6fed01d413bcefe7465cf346db4c00b7d7ac04")
addappid(24864, 1, "3ff3b343ae5a6a92e7d29e5e04374e2c70ac0069999576669e0ab09401844cfe")
addappid(24865, 1, "825f6f72f4943923dd99c8a77d75adb3c29c3b4b213ef6d8b79be695aebb1e4b")
addappid(24866, 1, "b677ecb7de7f5a67afe3aa00582f5620f675f276cc2052e827e9a8241665ddb5")
addappid(24867, 1, "4c2dfba605c4f3b3fc621588b315113fe6a81fd3d82c6311d8c662ce17eda334")
addappid(24869, 1, "44bb65adcfedcf65e678e96183cd4352d989fbf352010faf6b90037aca05357e")
