-- Lua provided by RyzenAPI
-- Game: HELLGATE: London

-- MAIN APPLICATION
addappid(939520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(939521, 1, "34937eb8cf3adfaa70161d9ed569145b90f8dd53dd571ac6fd85f0777a67f3f1")

