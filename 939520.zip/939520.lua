-- Lua provided by RyzenAPI
-- Game: 939520

-- MAIN APPLICATION
addappid(939520)
-- Game: addappid(939520)

-- MAIN APP DEPOTS / PACKAGES
addappid(939521, 1, "34937eb8cf3adfaa70161d9ed569145b90f8dd53dd571ac6fd85f0777a67f3f1")
