-- Lua provided by RyzenAPI
-- Game: addappid(363510)

-- MAIN APPLICATION
addappid(363510)

-- MAIN APP DEPOTS / PACKAGES
addappid(363511, 1, "3a43e88f2228fbf89b755a219af3f8a3ee8904d2567d32b5f8ed464f05af505d")
addappid(401490, 0, "38dd10a4b08f31d9a1d8896e90bdf6a6396dcedbf0fd8b483d47dacff4dbd11c")
addappid(415730, 0, "1eb06a44fe8e66341f925e9e939b9e4c01b249b153af01337a567dd611b576f9")
