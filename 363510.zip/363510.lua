-- Lua provided by RyzenAPI
-- Game: STAR-BOX: RPG Adventures in Space!

-- MAIN APPLICATION
addappid(363510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(363511, 1, "3a43e88f2228fbf89b755a219af3f8a3ee8904d2567d32b5f8ed464f05af505d")
addappid(401490, 0, "38dd10a4b08f31d9a1d8896e90bdf6a6396dcedbf0fd8b483d47dacff4dbd11c")
addappid(415730, 0, "1eb06a44fe8e66341f925e9e939b9e4c01b249b153af01337a567dd611b576f9")

