-- Lua provided by RyzenAPI
-- Game: Gooba Ball

-- MAIN APPLICATION
addappid(2878140)
