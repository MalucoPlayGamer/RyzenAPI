-- Lua provided by RyzenAPI
-- Game: Mirai's Midnight Stream

-- MAIN APPLICATION
addappid(3241760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241761, 1, "877ea4fd65b7150aa3944c78c3840696cec669b06fee87e9965fa6665daaff1a")
