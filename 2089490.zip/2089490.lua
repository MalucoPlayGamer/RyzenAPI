-- Lua provided by RyzenAPI
-- Game: Game: 雛ちゃんブレイカー2ndBreak

-- MAIN APPLICATION
addappid(2089490)
-- Game: addappid(2089490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089491, 1, "a782280882517c76b59740fecc185cff00136db7f4643f271a1ed61457e7190f")
