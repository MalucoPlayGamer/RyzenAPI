-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2090260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090260,0,"00f325a7445cafa145f5f0217f76c01650e4a671120e5528de5160ac1597a018")
