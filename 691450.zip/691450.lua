-- Lua provided by RyzenAPI 
-- Game: Misao - 2024 HD Remaster
addappid(691450)
addappid(691451, 1, "04aafd50f53e1eef0d6a4d24044acf18459466f5f43a9e5edc9edefe8549ae9e")
addappid(691452, 1, "a2a9ecef7a90d4dcb52abf5711470fc73168f3b55117e0f11ee628ed6faa5491")
addappid(691453, 1, "87e46d736e03a947c4bce19b6ef34ad7c4c8db6167a179fe4ce1d44032905d3b")
addappid(691454, 1, "ffad8d5d9d7075e248e1b26da5d5c7c534f63e064faaa2faf9ca406219d8fc5d")
addappid(691455, 1, "100afb9d9c267f64eacb8752fd1e209ed6f8879030e6efd46c1dd797cb42e006")
