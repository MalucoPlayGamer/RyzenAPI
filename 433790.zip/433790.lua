-- Lua provided by SkyAPI 
-- Game: AppID 433790
addappid(433790)
addappid(433791, 1, "deccec502db5de3d48f6f83ac63d829d1a888dc915f99af0d61e3c481863cdad")
