-- Lua provided by RyzenAPI
-- Game: Game: AppID 433790

-- MAIN APPLICATION
addappid(433790)
-- Game: addappid(433790)

-- MAIN APP DEPOTS / PACKAGES
addappid(433791, 1, "deccec502db5de3d48f6f83ac63d829d1a888dc915f99af0d61e3c481863cdad")
