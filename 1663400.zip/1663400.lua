-- Lua provided by RyzenAPI
-- Game: Reigns Beyond

-- MAIN APPLICATION
addappid(1663400)
-- Game: addappid(1663400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663401, 1, "af4ae82987db199bcc35730e7ede092951b900a77d61e4445667ee8ab4603ebe")
