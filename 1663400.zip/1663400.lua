-- Lua provided by RyzenAPI
-- Game: Reigns Beyond

-- MAIN APPLICATION
addappid(1663400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1663401, 1, "af4ae82987db199bcc35730e7ede092951b900a77d61e4445667ee8ab4603ebe")

