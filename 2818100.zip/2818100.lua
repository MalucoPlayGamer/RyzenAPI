-- Lua provided by RyzenAPI
-- Game: AppID 2818100

-- MAIN APPLICATION
addappid(2818100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818101, 1, "9ef0fc2d1bfc7cb6d3b6e5fcdf8dda6db5493a74417864ca5bb07b39f25b9b6f")
