-- Lua provided by RyzenAPI
-- Game: AppID 2721130

-- MAIN APPLICATION
addappid(2721130)
-- Game: addappid(2721130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721131, 1, "e285e1aa943e6b8baa0d66a8344c113ac6c8b0ccabcb7a1b1b0a86165ce115f1")
