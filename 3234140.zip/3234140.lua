-- Lua provided by RyzenAPI
-- Game: 3234140

-- MAIN APPLICATION
addappid(3234140)
-- Game: addappid(3234140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234141, 1, "cd9608abe2fac4d4d2b69b6971f65ed13c2af425bda6fa2d548681b5e679caa6")
