-- Lua provided by RyzenAPI
-- Game: ARMS DOLL

-- MAIN APPLICATION
addappid(1877800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1877801, 1, "75ec51033ce28b2a7c16f7dd8b0caed277aedcc64d76d6ec43ef5bf10af37806")

