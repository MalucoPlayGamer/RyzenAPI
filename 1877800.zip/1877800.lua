-- Lua provided by RyzenAPI
-- Game: ARMS DOLL

-- MAIN APPLICATION
addappid(1877800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877801, 1, "75ec51033ce28b2a7c16f7dd8b0caed277aedcc64d76d6ec43ef5bf10af37806")
