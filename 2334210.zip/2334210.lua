-- Lua provided by RyzenAPI
-- Game: No.BreakBrick

-- MAIN APPLICATION
addappid(2334210)
addappid(2348130)
-- Game: addappid(2334210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334211, 1, "edb24dc1a4037b7918dbd9d5d90ff78aa212034d9747c47cea4b0b6da8b5c727")
