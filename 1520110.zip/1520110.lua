-- Lua provided by RyzenAPI 
-- Game: Etched Memories Demo
addappid(1520110)
addappid(1520111, 1, "ed04332bbc32d21b828d425b46567ce07f9beed207dc2be2efa0c274b3647a9a")
