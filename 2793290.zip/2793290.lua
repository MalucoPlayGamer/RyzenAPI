-- Lua provided by RyzenAPI
-- Game: Game: LipTrip ~My Boss Is My Heat Suppressant?!~

-- MAIN APPLICATION
addappid(2793290)
-- Game: addappid(2793290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793291, 1, "dfd53da07fb089cf04049b50afc67031f6dc69d38164174b148ae7623bfc0bac")
