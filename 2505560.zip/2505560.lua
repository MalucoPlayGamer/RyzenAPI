-- Lua provided by RyzenAPI
-- Game: Game: Horny Recruiter

-- MAIN APPLICATION
addappid(2505560)
-- Game: addappid(2505560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505561, 1, "0703f8505d822a1f077d8fac7055b02f16ae7538c2a791412d80b5cc32c1780d")
