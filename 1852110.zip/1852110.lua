-- Lua provided by RyzenAPI
-- Game: AppID 1852110

-- MAIN APPLICATION
addappid(1852110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852111, 1, "53c2e55fd301f36a9af9e57cfef6e56b8e2b024a752d07e7dbc05323aab5ead9")

