-- Lua provided by RyzenAPI
-- Game: Beat Saber: Billie Eilish - 'Happier Than Ever'

-- MAIN APPLICATION
addappid(1753524)
-- Game: addappid(1753524)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753524,0,"92f99ec2601ec78586e791cc1ca2c08500d548405190aac2429fa2343f2f5400")
