-- Lua provided by RyzenAPI
-- Game: Pirate Souls

-- MAIN APPLICATION
addappid(1929990)
-- Game: addappid(1929990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929991, 1, "e8398845afff8f21e15d83e56a128f1694a634f45be26d70709920ed0f2071e0")
addappid(1929992, 1, "7a96d8189a5b03a2de945ffe2efe10601aa768c95b4ab123ecd1e2ec42242d00")
addappid(1929993, 1, "a702ee43f311395d2d8aef741fefa51c35a878061286c0ba6fc147204c131fd7")
addappid(1929994, 1, "f03a95fce3530cbf84b6c0ecbb9d1d6a059ce02fa0f3f7e53dc725ea08f97bf1")
