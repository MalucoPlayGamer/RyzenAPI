-- Lua provided by RyzenAPI
-- Game: My Furry Neighbour 🐾

-- MAIN APPLICATION
addappid(1705520)
addappid(1705910)
-- Game: addappid(1705520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705521, 1, "02c5f962bc05792aa03d366d562711b57da1cd43340ae302dabda793934b5965")
addappid(1705522, 1, "92a23db58fa4bee65310d59614047c73673b804188f8162a74bc2785f317aea2")
