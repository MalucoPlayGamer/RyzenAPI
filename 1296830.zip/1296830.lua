-- Lua provided by RyzenAPI
-- Game: 暖雪 Warm Snow

-- MAIN APPLICATION
addappid(1296830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296831, 1, "cf5d2cd621a67cb4a476d6390fe2d9e4506dcc772b691c35acc5bcc6c4a7e976")
addappid(1296832, 1, "d5aa12207c07cf9f8ba98b9e6fdc9b08c0883ff5f80e0da3d720c6bdd2cb5c43")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2147220)
addappid(2612950)
addappid(2936000)
