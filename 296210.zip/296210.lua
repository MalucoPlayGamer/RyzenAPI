-- Lua provided by RyzenAPI
-- Game: Brigade E5: New Jagged Union

-- MAIN APPLICATION
addappid(296210)

-- MAIN APP DEPOTS / PACKAGES
addappid(296211, 1, "87517ae38667e2a324c163cb35250239b9ba69e334c2fe814d7711a77747a9e4")
addappid(296212, 1, "b3e36678a881b3462404b7e0705b0c74a845a5cf477eb706b2badde23695593b")
addappid(296213, 1, "8328cd5f78c933176ceb763f1c528ee26888e1cf3c99b4b12d33e29c78bc48c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
