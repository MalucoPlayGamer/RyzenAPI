-- Lua provided by RyzenAPI
-- Game: addappid(1473270)

-- MAIN APPLICATION
addappid(1473270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473271, 1, "57b9795cef0cef163719f4f3795bb2220f53b5d1331d7b3f24a85ff62e786f0b")
