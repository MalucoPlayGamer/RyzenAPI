-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Add-on Vol.3: Train Tileset

-- MAIN APPLICATION
addappid(1350940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350940,0,"f664f3c3289f9d1fee5759af952d02339981ee1270e5f1c39d97a02b8d086452")

