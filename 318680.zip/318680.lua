-- Lua provided by RyzenAPI
-- Game: History in Letters - The Eternal Alchemist

-- MAIN APPLICATION
addappid(318680)

-- MAIN APP DEPOTS / PACKAGES
addappid(318681, 1, "d19475a926b27c871cace0fe7691e476ffc96b54058d048abf75accb49583ec6")
addappid(318682, 1, "848843bea4cddff308f49e8fb0d6e1a1355f2b88244bacfcf6b69145933833b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
