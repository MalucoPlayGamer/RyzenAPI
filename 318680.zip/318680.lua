-- Lua provided by RyzenAPI
-- Game: addappid(318680)

-- MAIN APPLICATION
addappid(318680)

-- MAIN APP DEPOTS / PACKAGES
addappid(318681, 1, "d19475a926b27c871cace0fe7691e476ffc96b54058d048abf75accb49583ec6")
addappid(318682, 1, "848843bea4cddff308f49e8fb0d6e1a1355f2b88244bacfcf6b69145933833b2")
