-- Lua provided by RyzenAPI
-- Game: Game: Nomori: Prologue

-- MAIN APPLICATION
addappid(2092190)
-- Game: addappid(2092190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092191, 1, "e7e558e021f8033728d84a95c0868e3106757e5bd916286d66a4767aef0ad1bf")
