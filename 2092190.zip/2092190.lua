-- Lua provided by RyzenAPI 
-- Game: Nomori: Prologue
addappid(2092190)
addappid(2092191, 1, "e7e558e021f8033728d84a95c0868e3106757e5bd916286d66a4767aef0ad1bf")
