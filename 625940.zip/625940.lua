-- Lua provided by RyzenAPI
-- Game: Tomato Jones 2

-- MAIN APPLICATION
addappid(625940)

-- MAIN APP DEPOTS / PACKAGES
addappid(625941, 1, "608a47af138435ce325cc2903d1fab57e89004f47c97319a5a1a3025b44df29e")
addappid(625942, 1, "73141dee364b0fb4e77293896e578bf9397220a5115e40eb65a8a3972f0656d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
