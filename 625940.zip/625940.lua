-- Lua provided by SkyAPI 
-- Game: Tomato Jones 2
addappid(625940)
addappid(625941, 1, "608a47af138435ce325cc2903d1fab57e89004f47c97319a5a1a3025b44df29e")
addappid(625942, 1, "73141dee364b0fb4e77293896e578bf9397220a5115e40eb65a8a3972f0656d7")
