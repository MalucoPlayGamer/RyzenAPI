-- Lua provided by RyzenAPI 
-- Game: AppID 687490
addappid(687490)
addappid(687491, 1, "672ef965e52297e6ccfaa5abfc54e2c7ed5b630980abe2f7c43c2a874731dabb")
