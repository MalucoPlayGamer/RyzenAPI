-- Lua provided by RyzenAPI
-- Game: addappid(897640)

-- MAIN APPLICATION
addappid(897640)

-- MAIN APP DEPOTS / PACKAGES
addappid(897641, 1, "e083e0ddea0eec77b5976eedbcc1aa09f4217ab78ff10f8e32b6272d8408ef69")
