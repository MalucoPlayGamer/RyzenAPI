-- Lua provided by RyzenAPI
-- Game: Gun Crazy

-- MAIN APPLICATION
addappid(897640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(897641, 1, "e083e0ddea0eec77b5976eedbcc1aa09f4217ab78ff10f8e32b6272d8408ef69")

