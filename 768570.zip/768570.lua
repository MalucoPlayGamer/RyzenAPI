-- Lua provided by RyzenAPI
-- Game: Uncanny Islands

-- MAIN APPLICATION
addappid(768570)

-- MAIN APP DEPOTS / PACKAGES
addappid(768571,0,"723c8e233ca86cec843eb4cb0a9d2501f7968ca45eae28572a9a27275c2b51be")

