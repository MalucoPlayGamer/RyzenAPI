-- Lua provided by RyzenAPI
-- Game: The Nameless: Slay Dragon

-- MAIN APPLICATION
addappid(2410170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410171, 1, "b2c348c79213cb3f8a467a50b3d2df85044ce7c7fd532c4d28c99ab68de446ef")
