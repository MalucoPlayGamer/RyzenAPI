-- Lua provided by RyzenAPI 
-- Game: AppID 1700450
addappid(1700450)
addappid(1700451, 1, "ee9430bcc8b7558adee5b469914c9ed3ed955fc008cb2a3ccd0f17ba33c82067")
