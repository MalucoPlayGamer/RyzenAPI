-- Lua provided by RyzenAPI
-- Game: Hello Kitty and Sanrio Friends Racing

-- MAIN APPLICATION
addappid(370600)

-- MAIN APP DEPOTS / PACKAGES
addappid(370601, 1, "3ff9c5595b257c3304717e6a2ce11f636ee9d464ba24feff05249851a6039159")
