-- Lua provided by RyzenAPI
-- Game: 1200310

-- MAIN APPLICATION
addappid(1200310)
-- Game: addappid(1200310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200311, 1, "f4a99c7899acdb687b8dcbd61190c79d8a8b0a2695041dc795822b551b9bc136")
