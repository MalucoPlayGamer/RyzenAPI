-- Lua provided by RyzenAPI
-- Game: Raider Kid and the Ruby Chest

-- MAIN APPLICATION
addappid(1085040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085041,0,"a8d2d6e02230a8fe24ef46400ece2ae1f90ce0a75fe7113148515a39eacc4556")

