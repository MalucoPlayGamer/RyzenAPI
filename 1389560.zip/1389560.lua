-- Lua provided by RyzenAPI
-- Game: Paint Girl

-- MAIN APPLICATION
addappid(1389560)
-- Game: addappid(1389560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389561, 1, "b13219e74eae2fa8ef8ced03d6fed34bfc8062606dabe3ea458fbf8f6b4e3cc7")
addappid(1409580, 0, "00ad19dfee9f55a416604da45bbaebd9cb6477fca78411ebd741c1cd7b944c1d")
addappid(1497020, 0, "07f620708633c3f2adf5f4c3b966cb74bf33a067ec207a92e5ad76d8933f4b85")
