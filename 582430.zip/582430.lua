-- Lua provided by RyzenAPI
-- Game: Jumping Tank

-- MAIN APPLICATION
addappid(582430)

-- MAIN APP DEPOTS / PACKAGES
addappid(582431, 1, "738da34d9f7b8325643c6ccce5ec204c08c8fc953676f93638504bab8abf571d")
