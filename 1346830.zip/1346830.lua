-- Lua provided by RyzenAPI
-- Game: Game: I Saw Black Clouds

-- MAIN APPLICATION
addappid(1346830)
-- Game: addappid(1346830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346831, 1, "5943fa72a2581c713dc0ba02ebe2c29f212b8c2c5a41ee1b91a9ba68e7fc7a78")
addappid(1346832, 1, "fcef7df58e851528e2572ca2babc0509b3fc689b16ac300e9ab82afd06f804d4")
addappid(1346833, 1, "4d24b9b246473c5b902973c2ba39907fe701a0c32c327c6ca3115ee7c634ab28")
addappid(1346834, 1, "0e919eb1a22e38d5703224b884cd4cf31c4a156d6792390f3e6ebe45ece5072f")
