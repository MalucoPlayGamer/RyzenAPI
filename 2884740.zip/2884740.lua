-- Lua provided by RyzenAPI
-- Game: 轉生打怪學英文(六) (Adventure and study English in a fantasy world VI)

-- MAIN APPLICATION
addappid(2884740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884741, 1, "5b84932e47a975f133e06b2b9df0e97485d8d103c0e0d7a1c941616a255dc649")
addappid(2884742, 1, "1705375210806968a3bda5e4f3989fb58cc44dcf05528ef9ea3a0a5d43d7ba72")
