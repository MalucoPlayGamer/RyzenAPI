-- Lua provided by RyzenAPI
-- Game: AppID 805880

-- MAIN APPLICATION
addappid(805880)
-- Game: addappid(805880)

-- MAIN APP DEPOTS / PACKAGES
addappid(805881, 1, "b97f523473008180cc0a0ac4fcfcce49618adbf8f85341d64f34252b89ea4fae")
