-- Lua provided by RyzenAPI
-- Game: Game: My Slow Life with the Princess Knight and Her Devoted Handmaiden

-- MAIN APPLICATION
addappid(1934900)
-- Game: addappid(1934900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934901, 1, "e92ec2b83d5c05879a1f355f165313346c74463f3593414e0e701af2a78957f8")
