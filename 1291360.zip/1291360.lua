-- Lua provided by RyzenAPI
-- Game: 1291360

-- MAIN APPLICATION
addappid(1291360)
-- Game: addappid(1291360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291362,0,"60bc819d1b9eee91bbbd11b0af72de0499bb26749776577b702647763321ffd1")
