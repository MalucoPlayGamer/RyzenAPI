-- Lua provided by RyzenAPI
-- Game: Southern Princesses

-- MAIN APPLICATION
addappid(2098950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098951, 1, "10f8f391df7757f7755c21a6d475e2f036d5ab4638375ec56ce13119a2c138be")
