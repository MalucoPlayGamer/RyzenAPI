-- Lua provided by RyzenAPI 
-- Game: Operator's Soundtrack
addappid(1299630)
addappid(1299631, 1, "bac1e63646f84137d1f98ad6b28d9c1a7c7366ffd8b68ae88409a699b4beef33")
addappid(1299632, 1, "a36d590b31f734c3a37f910662797e2a4ee2283ddfe350d0fe1b758e46a10e2a")
