-- Lua provided by RyzenAPI
-- Game: addappid(1813150)

-- MAIN APPLICATION
addappid(1813150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813151, 1, "60faf45ea320c29cedf3d5d155f24ed717da8767f354d6970cd9136b967afaa9")
