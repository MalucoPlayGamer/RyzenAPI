-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3132890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132894,0,"d52542e0130a0075cf6f28b6fffc0eec5e83517092e94e581ca614397b48865a")
