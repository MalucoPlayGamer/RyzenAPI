-- Lua provided by RyzenAPI
-- Game: CLASSIC TANKS 2020

-- MAIN APPLICATION
addappid(1393610)
-- Game: addappid(1393610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393611, 1, "abc82f3709d68cb6f82725a8bcedcf968544b97346058a886cbbdca69f4e561b")
