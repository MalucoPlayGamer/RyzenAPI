-- Lua provided by RyzenAPI
-- Game: Great Adventure in the World of Sky

-- MAIN APPLICATION
addappid(1035690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035692,0,"a219c32c226b52e872b35423776a4ea6689097a5a43032faa67a3db03f74554f")
addappid(1035693,0,"ef5cab23e459965bd2edd6c5ecb7f94ddae67bd8ce5c2f3096b4b832c516229e")

