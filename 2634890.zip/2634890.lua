-- Lua provided by RyzenAPI
-- Game: MARVEL vs. CAPCOM Fighting Collection: Arcade Classics

-- MAIN APPLICATION
addappid(2634890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634891, 1, "4c7a817aabbebeea28ec8bb1971e5e91a388c7b617485eb2cf399d782c4124eb")

