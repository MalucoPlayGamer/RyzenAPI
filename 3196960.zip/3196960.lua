-- Lua provided by SkyAPI 
-- Game: AppID 3196960
addappid(3196960)
addappid(3196961, 1, "7f125c52f61aaf79853681af9c56e199c1b523f47fbc4b0ced953100561ba124")
