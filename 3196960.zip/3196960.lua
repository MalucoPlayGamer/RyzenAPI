-- Lua provided by RyzenAPI
-- Game: 3196960

-- MAIN APPLICATION
addappid(3196960)
-- Game: addappid(3196960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196961, 1, "7f125c52f61aaf79853681af9c56e199c1b523f47fbc4b0ced953100561ba124")
