-- Lua provided by RyzenAPI
-- Game: 2819070

-- MAIN APPLICATION
addappid(2819070)
-- Game: addappid(2819070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819071, 1, "c8a785b27f9afbff8af8b8f2872f91e4435b011a4e75e6a297549dc56b33345c")
