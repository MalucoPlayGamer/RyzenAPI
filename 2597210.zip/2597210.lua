-- Lua provided by RyzenAPI
-- Game: Game: Welcome teacher

-- MAIN APPLICATION
addappid(2597210)
-- Game: addappid(2597210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597211, 1, "6049994a3c9e804ac3e139fbdaf78be86e647b71fcb8730c441b82065280427c")
