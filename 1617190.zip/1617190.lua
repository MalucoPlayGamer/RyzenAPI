-- Lua provided by RyzenAPI
-- Game: ArmaCulture

-- MAIN APPLICATION
addappid(1617190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617191, 1, "f38f716b562e6aaf8879281e05daf317bd2a362644e82217b0dd51d8da2df5c0")
