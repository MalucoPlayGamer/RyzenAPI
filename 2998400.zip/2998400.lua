-- Lua provided by SkyAPI 
-- Game: AppID 2998400
addappid(2998400)
addappid(2998401, 1, "75637f5dadafb27b62da8920884aa45457100cee00f0a2824916a03e403bb662")
