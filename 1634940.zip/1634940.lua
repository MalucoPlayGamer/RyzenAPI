-- Lua provided by RyzenAPI
-- Game: The Altered Lands

-- MAIN APPLICATION
addappid(1634940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634941, 1, "d99c084c9fea68ad536ed9b40ef4302d15e3385e94869c5f0081b45e54788fc3")

