-- Lua provided by RyzenAPI
-- Game: addappid(1625230)

-- MAIN APPLICATION
addappid(1625230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625231, 1, "743df9aa1e69df67e01d2d8d14a5f9d110265eb9896b39c752ccc30fb83f421a")
