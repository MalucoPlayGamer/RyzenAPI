-- Lua provided by RyzenAPI
-- Game: Flying Soul

-- MAIN APPLICATION
addappid(909270)

-- MAIN APP DEPOTS / PACKAGES
addappid(909271, 1, "009ae9c14371a8955757744b998dad985fabc4b8e2282d2b859ef4367917e89c")
