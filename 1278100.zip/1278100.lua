-- Lua provided by RyzenAPI 
-- Game: Stabby Cats
addappid(1278100)
addappid(1278101, 1, "671e64510ab120b8e536dcb397350b6e0b9c39ceda5f550bce726fd0ddd41ddc")
