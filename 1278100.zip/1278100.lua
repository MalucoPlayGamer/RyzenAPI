-- Lua provided by RyzenAPI
-- Game: Stabby Cats

-- MAIN APPLICATION
addappid(1278100)
-- Game: addappid(1278100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278101, 1, "671e64510ab120b8e536dcb397350b6e0b9c39ceda5f550bce726fd0ddd41ddc")
