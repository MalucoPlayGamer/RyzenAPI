-- Lua provided by RyzenAPI
-- Game: Capes

-- MAIN APPLICATION
addappid(2081080)
addappid(2348010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081081, 1, "3c7002768413bc02aacc1891d990d3c6fa273759aa14046e79354d7b85019d03")
addappid(2081082, 1, "1df105e1632e8d7e1c2fd4604d3608934ae33cd7df6589b0c97972d4d761ea3c")
addappid(2081083, 1, "561bcf6a0392b2ff69dabb7adca4d32a2ec823dea81248a6db9272891f847274")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
