-- Lua provided by RyzenAPI
-- Game: Game: Capes

-- MAIN APPLICATION
addappid(2081080)
addappid(2348010)
-- Game: addappid(2081080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081081, 1, "3c7002768413bc02aacc1891d990d3c6fa273759aa14046e79354d7b85019d03")
addappid(2081082, 1, "1df105e1632e8d7e1c2fd4604d3608934ae33cd7df6589b0c97972d4d761ea3c")
addappid(2081083, 1, "561bcf6a0392b2ff69dabb7adca4d32a2ec823dea81248a6db9272891f847274")
