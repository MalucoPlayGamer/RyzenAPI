-- Lua provided by RyzenAPI
-- Game: addappid(2878340)

-- MAIN APPLICATION
addappid(2878340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878341, 1, "3b46c26c33af43b313c9886716a233e86c7c546ecea4173af5219e6f256ff5c1")
