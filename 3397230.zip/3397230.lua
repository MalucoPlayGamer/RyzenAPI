-- Lua provided by RyzenAPI
-- Game: Kitten Food Alley

-- MAIN APPLICATION
addappid(3397230)
-- Game: addappid(3397230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397231, 1, "3babcabdd7efcbe4b26cfe0246779f45880930d74680e8fc6872d2818700893c")
