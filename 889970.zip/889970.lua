-- Lua provided by RyzenAPI
-- Game: Game: AppID 889970

-- MAIN APPLICATION
addappid(889970)
-- Game: addappid(889970)

-- MAIN APP DEPOTS / PACKAGES
addappid(889971, 1, "84856fa2545e6adb580491a1d4cbaeb461f1147e5eda11cf63bf0fb68bc02b18")
