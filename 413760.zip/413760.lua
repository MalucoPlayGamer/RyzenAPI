-- Lua provided by RyzenAPI
-- Game: addappid(413760)

-- MAIN APPLICATION
addappid(413760)

-- MAIN APP DEPOTS / PACKAGES
addappid(413761, 1, "4ec3698d7805f7d2a1686353a3f641e2e67f860aed824cc2f47a7de0efc72f40")
