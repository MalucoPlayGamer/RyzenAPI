-- Lua provided by RyzenAPI
-- Game: Aierlon

-- MAIN APPLICATION
addappid(1962980)
-- Game: addappid(1962980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962981, 1, "23d0bb11e1f5c273e92fb006770cdeaa345d9b16ac8c8d034529e6da7b53b68b")
