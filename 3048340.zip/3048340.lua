-- Lua provided by RyzenAPI
-- Game: Mr. Goofer’s Mini Game Arcade Party!

-- MAIN APPLICATION
addappid(3048340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048341, 1, "2913acb9895d29f512dc9c14ddb52353435e2692745dd53dd93fc6acd340e9cb")
