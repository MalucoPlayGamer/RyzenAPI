-- Lua provided by RyzenAPI
-- Game: A Priest Walks Into a Graveyard

-- MAIN APPLICATION
addappid(2403020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403021, 1, "7889066cf1ae16974b3a1e506ea677f0f2af68538925d0d187172feb68effffb")
