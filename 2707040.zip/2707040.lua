-- Lua provided by RyzenAPI
-- Game: KRAMPEN

-- MAIN APPLICATION
addappid(2707040)
addappid(3372370)
-- Game: addappid(2707040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707041, 1, "e1b0e5b1f5a1ba85ff8768b54bae3e3892fd8984e96f83582b944a94d300a63c")
