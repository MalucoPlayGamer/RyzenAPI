-- Lua provided by RyzenAPI 
-- Game: 仙路争锋-GM畅玩版
addappid(2428510)
addappid(2428511, 1, "47f1f99326e8ad37abcdba20e18b2e0fa120642e4b9bf0036dd31c099352f8cc")
