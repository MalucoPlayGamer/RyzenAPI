-- Lua provided by RyzenAPI
-- Game: Game: 仙路争锋-GM畅玩版

-- MAIN APPLICATION
addappid(2428510)
-- Game: addappid(2428510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428511, 1, "47f1f99326e8ad37abcdba20e18b2e0fa120642e4b9bf0036dd31c099352f8cc")
