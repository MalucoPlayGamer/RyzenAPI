-- Lua provided by RyzenAPI
-- Game: Rewind 99

-- MAIN APPLICATION
addappid(3977290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3977291,0,"a0a04cce0dc83823f5bfc54bb6b21d21724a949c32ac26d5dc035a9fc6c6e5aa")

