-- Lua provided by RyzenAPI
-- Game: addappid(1169690)

-- MAIN APPLICATION
addappid(1169690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169691, 1, "70d982531c4d1acc2b939e8eed0060b419ff4ec4df17d6fb32eb5ec4e40af298")
