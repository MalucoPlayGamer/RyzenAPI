-- Lua provided by RyzenAPI
-- Game: 3266210

-- MAIN APPLICATION
addappid(3266210)
-- Game: addappid(3266210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266211, 1, "09c9a2a97d5ac0cc261b1f79a44cf64e9a051f43589ed757d1e0b9ab655df608")
