-- Lua provided by RyzenAPI
-- Game: Ginger

-- MAIN APPLICATION
addappid(3418910)
-- Game: addappid(3418910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418911, 1, "1d2bbaae3cdc455a086bc5e4bdf54fa6fdd94cb6f5853032360f7b3885467392")
