-- Lua provided by RyzenAPI
-- Game: addappid(1347800)

-- MAIN APPLICATION
addappid(1347800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347801, 1, "02a1679c56e228f82b69222ea9ebe231ddcf2438b918dce0443bd55b49c14baf")
addappid(1347802, 1, "b9df9f7631a351adaece21ad0b5bec451493f55cd0b95e908816784fcfb9f345")
