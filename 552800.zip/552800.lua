-- Lua provided by RyzenAPI
-- Game: Swingin Swiggins

-- MAIN APPLICATION
addappid(552800)
addappid(629920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552801, 1, "50a9846c8a9e0f0503acd5bd3c6fb91b4f8a533e62612d175f972bfda4dff620")
