-- Lua provided by RyzenAPI
-- Game: 552800

-- MAIN APPLICATION
addappid(552800)
addappid(629920)
-- Game: addappid(552800)

-- MAIN APP DEPOTS / PACKAGES
addappid(552801, 1, "50a9846c8a9e0f0503acd5bd3c6fb91b4f8a533e62612d175f972bfda4dff620")
