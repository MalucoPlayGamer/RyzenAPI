-- Lua provided by RyzenAPI
-- Game: Xecute

-- MAIN APPLICATION
addappid(1218930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1218931, 1, "2e36d6554e9ba981aeeef1b93148198af63b4e43d76e8f79320551bac8ce05fb")
