-- Lua provided by RyzenAPI
-- Game: AppID 420760

-- MAIN APPLICATION
addappid(420760)
addappid(2484310)
addappid(2951230)
addappid(2951240)
addappid(2951250)
addappid(2951260)
addappid(2951270)
addappid(2951280)
addappid(2951570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(420761, 1, "3e52320e921a3add7eaaea129ffca9f57d63648685c00d1fc9cac283db59f24c")

