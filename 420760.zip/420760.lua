-- Lua provided by RyzenAPI
-- Game: addappid(420760)

-- MAIN APPLICATION
addappid(420760)

-- MAIN APP DEPOTS / PACKAGES
addappid(420761, 1, "3e52320e921a3add7eaaea129ffca9f57d63648685c00d1fc9cac283db59f24c")
