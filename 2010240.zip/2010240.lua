-- Lua provided by RyzenAPI
-- Game: FOG - Fear Of Going

-- MAIN APPLICATION
addappid(2010240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2010241, 1, "4cede5aed6337d3efb05cdb2bc41287fc9b78a442b3999645f4ea74af232377f")

