-- Lua provided by RyzenAPI
-- Game: FOG - Fear Of Going

-- MAIN APPLICATION
addappid(2010240)
-- Game: addappid(2010240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010241, 1, "4cede5aed6337d3efb05cdb2bc41287fc9b78a442b3999645f4ea74af232377f")
