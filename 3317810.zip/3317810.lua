-- Lua provided by RyzenAPI
-- Game: addappid(3317810)

-- MAIN APPLICATION
addappid(3317810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317811, 1, "2864d168c068fb51c814e235b41081b2c745cc097858cf9b35bdc808cf7ffa90")
