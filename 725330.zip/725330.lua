-- Lua provided by RyzenAPI
-- Game: 725330

-- MAIN APPLICATION
addappid(725330)
-- Game: addappid(725330)

-- MAIN APP DEPOTS / PACKAGES
addappid(725332,0,"4e0f4d63ebc8d9246ab161ea6a3e0eaaffcd55af53a943a0444df25372cafe02")
