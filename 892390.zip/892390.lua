-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(892390)
addappid(892390,0,"358e1929492d8b81c62dcaf388a8f40a3124be3f182d30df64d59e0cf17613c2")
-- setManifestid(892390,"4836483747092836281")