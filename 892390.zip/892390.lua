-- Lua provided by RyzenAPI
-- Game: addappid(892390)

-- MAIN APPLICATION
addappid(892390)

-- MAIN APP DEPOTS / PACKAGES
addappid(892390,0,"358e1929492d8b81c62dcaf388a8f40a3124be3f182d30df64d59e0cf17613c2")
