-- Lua provided by RyzenAPI 
-- Game: AMEDAMA
addappid(2411980)
addappid(2411981, 1, "64f1a6502da77ca8d617053aea8ed815f9145f63b731729372628826a52c0710")
