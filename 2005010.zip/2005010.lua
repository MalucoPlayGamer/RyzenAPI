-- Lua provided by RyzenAPI
-- Game: addappid(2005010)

-- MAIN APPLICATION
addappid(2005010)
addappid(2668290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005011, 1, "a0d26058a3aee26facb0319102648ee8172819bfba6358f4f375b89dd4070d36")
