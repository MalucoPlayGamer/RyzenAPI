-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Boltgun

-- MAIN APPLICATION
addappid(2005010)
addappid(2668290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2005011, 1, "a0d26058a3aee26facb0319102648ee8172819bfba6358f4f375b89dd4070d36")

