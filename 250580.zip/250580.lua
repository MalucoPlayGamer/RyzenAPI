-- Lua provided by RyzenAPI
-- Game: Paranautical Activity: Deluxe Atonement Edition

-- MAIN APPLICATION
addappid(250580)
addappid(250581)
-- Game: addappid(250580)

-- MAIN APP DEPOTS / PACKAGES
addappid(250582,0,"1d15d15805e74527db46891e008c5560e66c6fbf53ca0a41d1e95448af3e75a9")
addappid(250583,0,"ee40e0ed2f0b74d2f167f3095fa339003e2113cadbba9f68a9edd22e767b42a0")
addappid(250584,0,"3336fdbc479061880cbaf746220e41381e3e15d9a91aebeafc2c2972798410c2")
