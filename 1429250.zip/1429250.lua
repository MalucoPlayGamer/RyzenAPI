-- Lua provided by RyzenAPI
-- Game: Mech Engineer Demo

-- MAIN APPLICATION
addappid(1429250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429251, 1, "4b17e63349108d6712dfc205ed6d130e7e8e417e2e2505436878d1e5d02d70bb")
