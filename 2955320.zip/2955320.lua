-- Lua provided by RyzenAPI
-- Game: Horse Runner DX

-- MAIN APPLICATION
addappid(2955320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955321, 1, "6a38e39f98ceb54cff1b80dd071ccf60cfa130674be90d7068ef3d5f2eeeddf8")

