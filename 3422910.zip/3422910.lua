-- Lua provided by RyzenAPI
-- Game: addappid(3422910)

-- MAIN APPLICATION
addappid(3422910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422911, 1, "dc743340f0b56732d25a1ebd01283266964301bb89d933adbf27f8a95a43a3bc")
