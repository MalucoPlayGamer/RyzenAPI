-- Lua provided by RyzenAPI
-- Game: Gary the Gull

-- MAIN APPLICATION
addappid(456920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(456921, 1, "f51c5ba0c39a1e27988eb3ad2cef5fdeb6b6afad06eea4962086ed41c29e75d6")

