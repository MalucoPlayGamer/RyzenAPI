-- Lua provided by SkyAPI 
-- Game: Gary the Gull
addappid(456920)
addappid(456921, 1, "f51c5ba0c39a1e27988eb3ad2cef5fdeb6b6afad06eea4962086ed41c29e75d6")
