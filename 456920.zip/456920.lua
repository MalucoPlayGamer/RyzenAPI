-- Lua provided by RyzenAPI
-- Game: 456920

-- MAIN APPLICATION
addappid(456920)
-- Game: addappid(456920)

-- MAIN APP DEPOTS / PACKAGES
addappid(456921, 1, "f51c5ba0c39a1e27988eb3ad2cef5fdeb6b6afad06eea4962086ed41c29e75d6")
