-- Lua provided by RyzenAPI
-- Game: Game: 鬼谷八荒 Soundtrack

-- MAIN APPLICATION
addappid(1536810)
-- Game: addappid(1536810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536811, 1, "bf3164a85aaeb30ee465259766421af6d24cbe525d3ac405943888c56e3a7e98")
