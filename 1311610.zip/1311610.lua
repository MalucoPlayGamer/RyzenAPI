-- Lua provided by RyzenAPI
-- Game: Game: AppID 1311610

-- MAIN APPLICATION
addappid(1311610)
-- Game: addappid(1311610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311611, 1, "24fd59043eb4ffc59d897ad53d53d31ee7522faea8950a893d746d790d753c23")
