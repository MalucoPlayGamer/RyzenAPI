-- Lua provided by RyzenAPI 
-- Game: AppID 1311610
addappid(1311610)
addappid(1311611, 1, "24fd59043eb4ffc59d897ad53d53d31ee7522faea8950a893d746d790d753c23")
