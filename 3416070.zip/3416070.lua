-- Lua provided by RyzenAPI
-- Game: 3416070

-- MAIN APPLICATION
addappid(3416070)
-- Game: addappid(3416070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416071, 1, "dd9c9acd29a60cf2cd7bf22e51433362f2e97ba5fdadfa5734087bd224683daf")
