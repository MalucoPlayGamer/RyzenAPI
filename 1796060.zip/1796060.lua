-- Lua provided by RyzenAPI
-- Game: addappid(1796060)

-- MAIN APPLICATION
addappid(1796060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796061, 1, "1379c8ccd210f9bc49b86d5f9962fb1465028e2535614e83037d7fb5cc0f7a88")
