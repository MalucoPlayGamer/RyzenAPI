-- Lua provided by SkyAPI 
-- Game: Granny Kick Neighbor
addappid(1301290)
addappid(1301291, 1, "5fcd5cedcd3108a1ec6bb895ffa3a8ab7dbfc290c5f1f625a567688123db751e")
