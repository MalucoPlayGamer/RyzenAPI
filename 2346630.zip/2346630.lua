-- Lua provided by RyzenAPI
-- Game: Tainted Grail: The Fall of Avalon Demo

-- MAIN APPLICATION
addappid(2346630)
-- Game: addappid(2346630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346631, 1, "24631cf8ae4d5fef843556cb627fee44458687ae56247687b3fcd814a353e39f")
