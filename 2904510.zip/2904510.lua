-- Lua provided by RyzenAPI 
-- Game: Mr. Scientist
addappid(2904510)
addappid(2904511, 1, "bd960ebe73a4b1471bc71241353f292d593d5783558f8e3ad6672391ec419b1a")
