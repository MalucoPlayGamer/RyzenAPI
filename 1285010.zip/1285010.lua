-- Lua provided by RyzenAPI
-- Game: Game: Cyber Protocol

-- MAIN APPLICATION
addappid(1285010)
-- Game: addappid(1285010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285011, 1, "00172ed17adf3c49539e6076ce5d6bee4654032e8937d6e08a94559981401748")
