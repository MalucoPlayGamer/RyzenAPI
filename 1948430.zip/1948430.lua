-- Lua provided by RyzenAPI
-- Game: 1948430

-- MAIN APPLICATION
addappid(1948430)
addappid(3448720)
-- Game: addappid(1948430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948431, 1, "09b446fcded597191bc5f0a11da457d6b98a766270eaac0536b45b38fe217562")
addappid(1948434, 1, "a58df3bfad725c68606404abb64d9b36cf4b7b37746b8044849d5d44b1daee42")
