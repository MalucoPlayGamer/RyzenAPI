-- Lua provided by RyzenAPI
-- Game: Planet S

-- MAIN APPLICATION
addappid(1948430)
addappid(3448720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948431, 1, "09b446fcded597191bc5f0a11da457d6b98a766270eaac0536b45b38fe217562")
addappid(1948434, 1, "a58df3bfad725c68606404abb64d9b36cf4b7b37746b8044849d5d44b1daee42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
