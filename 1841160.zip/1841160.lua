-- Lua provided by RyzenAPI
-- Game: Amata

-- MAIN APP DEPOTS / PACKAGES
addappid(1841160, 1, "64dcb6afa65e9a53af58d5573902435dd70a9ff64ffb6ed96df5b2ccfdca92b6") -- Amata
addappid(1841161, 1, "6e06293c30eb5141d3b561d32dcb8bb041ff17c34e482f95559a9212447f94c6") -- Depot 1841161
addappid(1841163, 1, "6a51cfbb3c528976ce9829f48e1d404261e526e1ba3640d1a34a42d562684738") -- Depot 1841163

