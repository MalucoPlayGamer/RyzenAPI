-- Lua provided by RyzenAPI
-- Game: AppID 958480

-- MAIN APPLICATION
addappid(958480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(958481, 1, "c8d02a3f078c34721d045d369fb9c3885645666b815e0e9e957b73cfe9d9ef82")

