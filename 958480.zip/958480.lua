-- Lua provided by SkyAPI 
-- Game: AppID 958480
addappid(958480)
addappid(958481, 1, "c8d02a3f078c34721d045d369fb9c3885645666b815e0e9e957b73cfe9d9ef82")
