-- Lua provided by RyzenAPI
-- Game: 958480

-- MAIN APPLICATION
addappid(958480)
-- Game: addappid(958480)

-- MAIN APP DEPOTS / PACKAGES
addappid(958481, 1, "c8d02a3f078c34721d045d369fb9c3885645666b815e0e9e957b73cfe9d9ef82")
