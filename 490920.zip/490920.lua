-- Lua provided by RyzenAPI 
-- Game: AppID 490920
addappid(490920)
addappid(490921, 1, "fd84ad7c8a736640c34b2fefb4fe716b0de05ed1ae9af6955c2e59354e61545c")
