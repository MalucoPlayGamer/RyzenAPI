-- Lua provided by RyzenAPI
-- Game: 490920

-- MAIN APPLICATION
addappid(490920)
-- Game: addappid(490920)

-- MAIN APP DEPOTS / PACKAGES
addappid(490921, 1, "fd84ad7c8a736640c34b2fefb4fe716b0de05ed1ae9af6955c2e59354e61545c")
