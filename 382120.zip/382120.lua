-- Lua provided by RyzenAPI
-- Game: 382120

-- MAIN APPLICATION
addappid(382120)
-- Game: addappid(382120)

-- MAIN APP DEPOTS / PACKAGES
addappid(382121, 1, "b61015bfc2373b3b74faf6219deefb2e34f67a8bad04fcb84b0fa0ac5128e0af")
addappid(382122, 1, "91831ef448b68db95c89d2a7ac15a2eca4bdc2789621b16c539bf58f5ca420a7")
addappid(382123, 1, "a10b6f08b72ad2389966a78946bf0c0c26928fe80c56e415b923159f69169f2c")
