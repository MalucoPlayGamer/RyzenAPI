-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1263500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263500,0,"8a95294a1436ebb20060b2a414a76d3d74256ca078ff9139756abfe6a6e1df61")

