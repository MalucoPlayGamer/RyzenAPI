-- Lua provided by RyzenAPI
-- Game: Mahjong Solitaire

-- MAIN APPLICATION
addappid(5058070) -- Mahjong Solitaire
-- addappid(5058071) -- Depot 5058071 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(5058072, 1, "37cd15588369ed45edf834f5ca3ac3e110efefd5c3bff08bf025e9a37814eda3") -- Depot 5058072
addappid(5058073, 1, "4ec764f78ebb987e4d33313e532c2d0274f8a018c7649cb8dbfeec0d2b765b5d") -- Depot 5058073

