-- 5058070's Lua and Manifest Created by Hubcap Manifest
-- Mahjong Solitaire
-- Created: August 26, 2026 at 23:42:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5058070) -- Mahjong Solitaire
-- MAIN APP DEPOTS
addappid(5058072, 1, "37cd15588369ed45edf834f5ca3ac3e110efefd5c3bff08bf025e9a37814eda3") -- Depot 5058072
setManifestid(5058072, "8254775832413118720", 72872162)
addappid(5058073, 1, "4ec764f78ebb987e4d33313e532c2d0274f8a018c7649cb8dbfeec0d2b765b5d") -- Depot 5058073
setManifestid(5058073, "3194377106013452251", 34817405)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(5058071) -- Depot 5058071 (empty depot)