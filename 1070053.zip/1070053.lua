-- Lua provided by RyzenAPI
-- Game: addappid(1070053)

-- MAIN APPLICATION
addappid(1070053)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070053,0,"c3e3ea09caa4fd97446c4f9642c5e659f7d89f251555b35d49c97d105e5496a3")
