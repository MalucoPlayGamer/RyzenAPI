-- Lua provided by RyzenAPI
-- Game: Pirates Girls  - Artbook 18+

-- MAIN APPLICATION
addappid(1342720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342720,0,"e252115ae2e939305896c73381f6ba3fd8f2708916a86fa605520b39cfd33743")

