-- Lua provided by RyzenAPI
-- Game: Hell Architect - Artbook

-- MAIN APPLICATION
addappid(1819360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819360,0,"55d0b4fbb90606fa777eda00c31f0bb54c8e160267481d98f013d4ca2728c7f0")
