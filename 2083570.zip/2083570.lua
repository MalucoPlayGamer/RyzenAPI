-- Lua provided by RyzenAPI 
-- Game: AppID 2083570
addappid(2083570)
addappid(2083571, 1, "2b95508fbcab947a74431eeb0093e567a150638f485a5c3df59d34df662addf1")
