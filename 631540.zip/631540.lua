-- Lua provided by RyzenAPI
-- Game: Community Inc

-- MAIN APPLICATION
addappid(631540)

-- MAIN APP DEPOTS / PACKAGES
addappid(631541,0,"4cccade93657751601307bca0ddea7cdb60da3422a52e009d1792e830233af97")
addappid(631542,0,"fea16e93dbc00a3d047fa4ea4739b4018045d33de3bfc5a18254526618e81af7")

