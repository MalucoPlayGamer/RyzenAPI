-- Lua provided by RyzenAPI
-- Game: addappid(393000)

-- MAIN APPLICATION
addappid(393000)

-- MAIN APP DEPOTS / PACKAGES
addappid(393001, 1, "20d1a5e6dfe856bac2bcf8fa0a880b856959b46529beac5ffed26eb166cc08a0")
