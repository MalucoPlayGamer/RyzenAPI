-- Lua provided by RyzenAPI
-- Game: AppID 516750

-- MAIN APPLICATION
addappid(516750)

-- MAIN APP DEPOTS / PACKAGES
addappid(516751, 1, "47b5c22aa9f52cb8b5d2fe2d9db70ed709bbc88a4ba4cf24bfab8f594141ff72")
