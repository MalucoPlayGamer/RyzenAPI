-- Lua provided by RyzenAPI
-- Game: Game: AppID 950180

-- MAIN APPLICATION
addappid(950180)
-- Game: addappid(950180)

-- MAIN APP DEPOTS / PACKAGES
addappid(950181, 1, "db62d822304a45b384cef60ad1b2a868cfc47aa18b8ff8fd0430521ad6ebfcbc")
