-- Lua provided by RyzenAPI
-- Game: NOeSIS01_诉说谎言记忆物语

-- MAIN APPLICATION
addappid(1246020)
