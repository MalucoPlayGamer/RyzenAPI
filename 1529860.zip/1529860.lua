-- Lua provided by RyzenAPI
-- Game: Ulna Online

-- MAIN APPLICATION
addappid(1529860)
-- Game: addappid(1529860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529861, 1, "afa24f4bdb417aabb791d6298fc1c6e372ae504bd2663a64bd9f40e83d093643")
addappid(1529863, 1, "34c9a39dfa910325272b9bae935346c3ecdb444d87973a41eb4fd6a68852d572")
