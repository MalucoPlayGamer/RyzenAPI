-- Lua provided by RyzenAPI
-- Game: addappid(914900)

-- MAIN APPLICATION
addappid(914900)

-- MAIN APP DEPOTS / PACKAGES
addappid(914901, 1, "8437cffcfae151cd0a25499b456e6115cef269755f91c5ffd80bd296c51571c9")
addappid(914902, 1, "d529946a3ae5496acb22b469d1636eeaf4a6ca799dcc64bae57d825feb1d2bac")
