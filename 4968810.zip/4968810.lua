-- Lua provided by RyzenAPI
-- Game: Velocrash

-- MAIN APPLICATION
addappid(4968810) -- Velocrash

-- MAIN APP DEPOTS / PACKAGES
addappid(4968811, 1, "8487d7f6011fd74c3663392bd45059a56b47bec4092fbd72755978bddab36234") -- Depot 4968811

