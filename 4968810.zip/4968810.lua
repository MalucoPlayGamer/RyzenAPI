-- 4968810's Lua and Manifest Created by Hubcap Manifest
-- Velocrash
-- Created: August 09, 2026 at 22:17:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4968810) -- Velocrash
-- MAIN APP DEPOTS
addappid(4968811, 1, "8487d7f6011fd74c3663392bd45059a56b47bec4092fbd72755978bddab36234") -- Depot 4968811
setManifestid(4968811, "4945178902890150720", 235297660)