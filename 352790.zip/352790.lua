-- Lua provided by RyzenAPI
-- Game: AppID 352790

-- MAIN APPLICATION
addappid(352790)

-- MAIN APP DEPOTS / PACKAGES
addappid(352791, 1, "5f6cd4e196cb636e9c010c45d7a67037b0f331fca1b30edf7826c2062d97f249")
addappid(433710, 0, "db5f5a74308e7ea9810afa6af05cc95cf16bab0e76addab1191ed7ff13d1123c")

