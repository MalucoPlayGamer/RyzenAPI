-- Lua provided by RyzenAPI
-- Game: Beastrun

-- MAIN APPLICATION
addappid(1669050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669051, 1, "96f516f4187ba7a62736d5593d7430ca5128e03352f5bae2564330c6c942d9fe")
addappid(1669052, 1, "366e93fa692e701d62781e7fc037d4ba84dbfd2cd49046b4fda89b2d8a5413d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
