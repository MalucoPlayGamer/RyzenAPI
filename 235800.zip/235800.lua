-- Lua provided by RyzenAPI
-- Game: Audiosurf 2

-- MAIN APPLICATION
addappid(235800)
-- Game: addappid(235800)

-- MAIN APP DEPOTS / PACKAGES
addappid(235801, 1, "2d50d6aa3194baaf82029539e52dcba19be9cd784457740a156748749860ca8c")
addappid(235802, 1, "3a5ff766dc1b47d716f2be150d7cb296a9c1cc74690cbb3b5d7b9044735e4485")
addappid(235803, 1, "00df363c99c0bb0618d92340f5d43ecf733390ad15c0ddc82c1d9b453e553351")
