-- Lua provided by RyzenAPI
-- Game: Audiosurf 2

-- MAIN APPLICATION
addappid(235800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(235801, 1, "2d50d6aa3194baaf82029539e52dcba19be9cd784457740a156748749860ca8c")
addappid(235802, 1, "3a5ff766dc1b47d716f2be150d7cb296a9c1cc74690cbb3b5d7b9044735e4485")
addappid(235803, 1, "00df363c99c0bb0618d92340f5d43ecf733390ad15c0ddc82c1d9b453e553351")

