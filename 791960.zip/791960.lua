-- Lua provided by RyzenAPI
-- Game: addappid(791960)

-- MAIN APPLICATION
addappid(791960)

-- MAIN APP DEPOTS / PACKAGES
addappid(791961, 1, "9a28908972e8a3747a276691af262205e6be3f25e6566cb2fe87b6f5f8ec907e")
