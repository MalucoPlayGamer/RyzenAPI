-- Lua provided by RyzenAPI
-- Game: Lewd Life with my Doggy Wife

-- MAIN APPLICATION
addappid(1991480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991481, 1, "b22af03c24c62a847c39ec79235d75ced624cf4f20d3b646ea5cdc4bf369180c")
