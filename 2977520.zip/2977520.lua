-- Lua provided by RyzenAPI 
-- Game: Big Helmet Heroes Demo
addappid(2977520)
addappid(2977521, 1, "9aa296f8f00d78996eeb6c2e211570a9ccf1a8f6f378a65f2d8d97129b4a74fc")
