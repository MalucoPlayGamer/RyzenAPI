-- Lua provided by RyzenAPI
-- Game: 2977520

-- MAIN APPLICATION
addappid(2977520)
-- Game: addappid(2977520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977521, 1, "9aa296f8f00d78996eeb6c2e211570a9ccf1a8f6f378a65f2d8d97129b4a74fc")
