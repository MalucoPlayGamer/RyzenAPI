-- Lua provided by RyzenAPI 
-- Game: Dickland: Tower Defense
addappid(2394110)
addappid(2394111, 1, "472de12618d6bd0c73504acb5810ecb931f93b7f00fb6043e56ad2f068cb6f6f")
