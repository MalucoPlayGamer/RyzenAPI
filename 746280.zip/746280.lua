-- Lua provided by RyzenAPI
-- Game: addappid(746280)

-- MAIN APPLICATION
addappid(746280)

-- MAIN APP DEPOTS / PACKAGES
addappid(746281, 1, "4a8c606d185e63b8b7f4cf94a400dd8b2ac57aad47b8fcd614a25af929c52790")
