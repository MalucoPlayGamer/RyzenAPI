-- Lua provided by RyzenAPI
-- Game: 318350

-- MAIN APPLICATION
addappid(318350)
-- Game: addappid(318350)

-- MAIN APP DEPOTS / PACKAGES
addappid(318351, 1, "154c375affc4f4c9ab1e1b8eac8d1f9e6296fffd9d1b65fb7432cc98c6e3138b")
addappid(318352, 1, "0a2a4fcef3e117d8d56506f8d6314017b538eb4552b526bb8695c474f2338d34")
