-- Lua provided by RyzenAPI
-- Game: Disney Fairies: Tinker Bell's Adventure

-- MAIN APPLICATION
addappid(318350)

-- MAIN APP DEPOTS / PACKAGES
addappid(318351, 1, "154c375affc4f4c9ab1e1b8eac8d1f9e6296fffd9d1b65fb7432cc98c6e3138b")
addappid(318352, 1, "0a2a4fcef3e117d8d56506f8d6314017b538eb4552b526bb8695c474f2338d34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
