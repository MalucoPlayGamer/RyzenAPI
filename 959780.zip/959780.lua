-- Lua provided by RyzenAPI
-- Game: addappid(959780)

-- MAIN APPLICATION
addappid(959780)
addappid(959781)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006,0,"9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")
