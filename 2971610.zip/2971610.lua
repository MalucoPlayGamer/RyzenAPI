-- Lua provided by RyzenAPI 
-- Game: HOLE
addappid(2971610)
addappid(2971611, 1, "bda4eb90b24a22450e4c9d653dc76a921d76d75528de7dbd5e0b6acaf1d7250a")
