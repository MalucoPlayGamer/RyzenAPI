-- Lua provided by RyzenAPI
-- Game: Neon Abyss Soundtrack

-- MAIN APPLICATION
addappid(1396440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396441, 1, "117477c3cdfe74fe97c600fb19a1a736e64aeb0d95eadba67c7b20abba417dba")
addappid(1396442, 1, "4033ce53a1d5e26afdb1fb0191c8aadbb8314a61fb64c04ae684cac19307466c")
