-- Lua provided by RyzenAPI
-- Game: I Am Alive

-- MAIN APPLICATION
addappid(214250)

-- MAIN APP DEPOTS / PACKAGES
addappid(214251, 1, "8317371c102c9d90a5143cb349b5efd9c2ff61c540e8f7dedded2e44e8df29f4")
