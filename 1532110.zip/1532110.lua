-- Lua provided by RyzenAPI
-- Game: Curatours

-- MAIN APPLICATION
addappid(1532110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532111, 1, "7a8493fe2d664174b707b1a151a5b6443acdb1d64d6f698da8fb8943a01b81ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
