-- Lua provided by RyzenAPI
-- Game: Scary Maze

-- MAIN APPLICATION
addappid(854550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(854552,0,"6d1be496d6cfbfa56c6a29cca1ecf517d574ef0e14b64cb429f6d3567d81bc2d")

