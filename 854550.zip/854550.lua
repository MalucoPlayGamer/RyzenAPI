-- Lua provided by RyzenAPI
-- Game: 854550

-- MAIN APPLICATION
addappid(854550)

-- MAIN APP DEPOTS / PACKAGES
addappid(854552,0,"6d1be496d6cfbfa56c6a29cca1ecf517d574ef0e14b64cb429f6d3567d81bc2d")

