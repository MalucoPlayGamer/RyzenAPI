-- Lua provided by SkyAPI 
-- Game: AppID 545990
addappid(545990)
addappid(545991, 1, "1c4ec3706eaa96f45397e533ec1dca197b30721bf8b30cb8bece576705e57dc9")
