-- Lua provided by RyzenAPI
-- Game: The Fog

-- MAIN APPLICATION
addappid(739030)

-- MAIN APP DEPOTS / PACKAGES
addappid(739031,0,"7549d77fa9866b7e49e67cd1bdaf8fde60eadc31add72d9b03953aa744f1cc12")

