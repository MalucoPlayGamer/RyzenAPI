-- Lua provided by RyzenAPI
-- Game: Game: Lonely Girls Who Crave Your Touch

-- MAIN APPLICATION
addappid(3666630)
-- Game: addappid(3666630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666631, 1, "d9134a4d5c968ad81c7668d4dcc4f3989bc6b46bd1655931466398eccffe5451")
