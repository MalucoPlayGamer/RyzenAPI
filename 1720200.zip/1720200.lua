-- Lua provided by RyzenAPI
-- Game: Any Fish

-- MAIN APPLICATION
addappid(1720200)
-- Game: addappid(1720200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720201, 1, "ed0cebfc57d222fa2007b899c4abd90b95951b290e662be4ea598f03989546f7")
