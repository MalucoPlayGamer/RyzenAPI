-- Lua provided by RyzenAPI
-- Game: Game: Clean the Sea!

-- MAIN APPLICATION
addappid(2232320)
-- Game: addappid(2232320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232321, 1, "6109897f79f12fd57f072f4f1f5ce201630e9252ddce1fe0326064a231f1b548")
