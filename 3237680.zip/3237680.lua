-- Lua provided by RyzenAPI
-- Game: Game: SEX Sport College 💦🏅

-- MAIN APPLICATION
addappid(3237680)
-- Game: addappid(3237680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237681, 1, "33ce77d4073ee2d0974d7bd1037016477e12864bc37b8ad84249bd5044f02a60")
