-- Lua provided by SkyAPI 
-- Game: Sunset Devils Demo
addappid(3032700)
addappid(3032701, 1, "b3743ca42d84347d98c78af1b571f2119ab1172c7dee3f7e26f4ff6304c51b2a")
