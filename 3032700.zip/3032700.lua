-- Lua provided by RyzenAPI
-- Game: Sunset Devils Demo

-- MAIN APPLICATION
addappid(3032700)
-- Game: addappid(3032700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032701, 1, "b3743ca42d84347d98c78af1b571f2119ab1172c7dee3f7e26f4ff6304c51b2a")
