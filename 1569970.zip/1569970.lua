-- Lua provided by RyzenAPI
-- Game: Fireball Wizard

-- MAIN APPLICATION
addappid(1569970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569971, 1, "35fd96c81db52a4516b7db1c3f8e9cc2abde0a2ed0e3c7619e40e389f20c3bb2")

