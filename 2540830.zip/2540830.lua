-- Lua provided by RyzenAPI
-- Game: AppID 2540830

-- MAIN APPLICATION
addappid(2540830)
-- Game: addappid(2540830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540831, 1, "fe2267550fbb1a91ed826679ce8b4fa119bc0edac0a5fd06321cde2d70425044")
