-- Lua provided by RyzenAPI
-- Game: Q.U.B.E. 2 Original Soundtrack

-- MAIN APPLICATION
addappid(822093)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238700,0,"9c32c16daf7d3f671ef77cf0d5661aaca35ae39f7ef53742e4d1fe3c4c14d5da")
addappid(1238701,0,"71d1b489f4f61961e83191091bb918999dd3b31c57e500bce40ab581140f9e78")
