-- Lua provided by RyzenAPI
-- Game: Helpless

-- MAIN APPLICATION
addappid(2290490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290491, 1, "a81db896cd2e1122f17cdea9e35088200a22e76a16e2d05ef96b88c61664d50b")
