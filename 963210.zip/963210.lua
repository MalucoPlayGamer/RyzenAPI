-- Lua provided by RyzenAPI
-- Game: Another Sight - Hodge's Journey

-- MAIN APPLICATION
addappid(963210)

-- MAIN APP DEPOTS / PACKAGES
addappid(963211, 1, "95040f846d9b06cbe26b3643ed4efdc0a0fef73ff1899b6ef4edd384dea52759")

