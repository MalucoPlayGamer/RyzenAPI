-- Lua provided by RyzenAPI
-- Game: Another Sight - Hodge's Journey

-- MAIN APPLICATION
addappid(963210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(963211, 1, "95040f846d9b06cbe26b3643ed4efdc0a0fef73ff1899b6ef4edd384dea52759")

