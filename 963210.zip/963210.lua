-- Lua provided by SkyAPI 
-- Game: Another Sight - Hodge's Journey
addappid(963210)
addappid(963211, 1, "95040f846d9b06cbe26b3643ed4efdc0a0fef73ff1899b6ef4edd384dea52759")
