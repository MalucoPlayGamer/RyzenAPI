-- Lua provided by RyzenAPI
-- Game: addappid(1330630)

-- MAIN APPLICATION
addappid(1330630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330631, 1, "8e48a92432acece1aa6b3aa84a822886084e48eddb501f7ac7ca8a47f9526fbd")
