-- Lua provided by RyzenAPI
-- Game: City Bus Manager - South America

-- MAIN APPLICATION
addappid(1901840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901841, 1, "a10c157c1f142002a7af0d0249e1e5c9047e299503f199de5d6e4f6d6521b68b")
