-- Lua provided by RyzenAPI
-- Game: addappid(1231690)

-- MAIN APPLICATION
addappid(1231690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231690,0,"484366106eceb9ee1e09ff7e6294729cbfaa9f5acc58f9face07a8659b2bc4cc")
