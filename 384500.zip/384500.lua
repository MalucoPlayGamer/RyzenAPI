-- Lua provided by RyzenAPI
-- Game: Zombie Party

-- MAIN APPLICATION
addappid(384500)

-- MAIN APP DEPOTS / PACKAGES
addappid(384501, 1, "2910af6620c60054d9ff2ae2034585cb95701fc77afd6bcfe551d6752ed98c45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
