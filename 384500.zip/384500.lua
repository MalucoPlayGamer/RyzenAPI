-- Lua provided by RyzenAPI
-- Game: addappid(384500)

-- MAIN APPLICATION
addappid(384500)

-- MAIN APP DEPOTS / PACKAGES
addappid(384501, 1, "2910af6620c60054d9ff2ae2034585cb95701fc77afd6bcfe551d6752ed98c45")
