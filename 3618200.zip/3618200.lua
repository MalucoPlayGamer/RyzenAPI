-- Lua provided by SkyAPI 
-- Game: Gun Center Simulator
addappid(3618200)
addappid(3618201, 1, "5b8e7e9589229dda19724f5f2e055d318e6ee80f6a8cca728698801eb89628fd")
