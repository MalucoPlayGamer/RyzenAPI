-- Lua provided by RyzenAPI
-- Game: Gun Center Simulator

-- MAIN APPLICATION
addappid(3618200)
-- Game: addappid(3618200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618201, 1, "5b8e7e9589229dda19724f5f2e055d318e6ee80f6a8cca728698801eb89628fd")
