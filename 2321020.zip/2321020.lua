-- Lua provided by RyzenAPI
-- Game: 2321020

-- MAIN APPLICATION
addappid(2321020)
-- Game: addappid(2321020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321022,0,"1a894ed918ee8e4f19270dc4e9a1639d25dcce06832cc40b40a3be9716ce21b1")
