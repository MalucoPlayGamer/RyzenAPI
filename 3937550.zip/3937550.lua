-- Lua provided by RyzenAPI
-- Game: Yakuza Kiwami 3 & Dark Ties

-- MAIN APPLICATION
addappid(3937550)
addappid(3948230)
addappid(3948240)
addappid(3948250)
addappid(3948260)
addappid(3948270)
addappid(3948280)
addappid(3957290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3937551, 1, "ce44bd72b4308b8793812099f3fc2005dbdd1cf8465b7dd7391cae39a7512801")

