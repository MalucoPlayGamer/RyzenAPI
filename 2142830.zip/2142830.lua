-- Lua provided by RyzenAPI
-- Game: the hardest game in the universe 2-DLC 1

-- MAIN APPLICATION
addappid(2142830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142830,0,"9927f646809f6ed352b463c5e41690ee0a2751a94d00fdfd789f14d394e63d1d")
