-- Lua provided by RyzenAPI
-- Game: addappid(840710)

-- MAIN APPLICATION
addappid(840710)

-- MAIN APP DEPOTS / PACKAGES
addappid(840711, 1, "feffe71bcb9c320354351497cebd911dbbf99ab041749f6343e3841d7a4a9915")
