-- Lua provided by RyzenAPI
-- Game: Ghost of Tokyo

-- MAIN APPLICATION
addappid(4620930)

-- MAIN APP DEPOTS / PACKAGES
addappid(4620931,0,"06978ae0a33ba11984816885d91fc7a73ddc56ad542de5a17c4bd261d6c4c7b6")

