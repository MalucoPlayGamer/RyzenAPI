-- Lua provided by RyzenAPI
-- Game: Game: Tainted Fate

-- MAIN APPLICATION
addappid(858250)
-- Game: addappid(858250)

-- MAIN APP DEPOTS / PACKAGES
addappid(858251, 1, "5394e3ff135c976ae78e1cefcae02686ea4547153a48d4ba120ee53d35f56966")
