-- Lua provided by RyzenAPI
-- Game: Space Bandit

-- MAIN APPLICATION
addappid(228988)
addappid(1435470)
addappid(1435471)
addappid(1435473)
-- Game: addappid(1435470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435472,0,"170d5aa176a9aa340ae39a939804eea95ac48477767b2e67281ed59fc409e7a4")
