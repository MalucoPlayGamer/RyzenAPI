-- Lua provided by RyzenAPI
-- Game: 703680

-- MAIN APPLICATION
addappid(703680)
-- Game: addappid(703680)

-- MAIN APP DEPOTS / PACKAGES
addappid(703682,0,"1a7c4022ef90a1b0eed2fd8ec2311a9f219d173a1e7838b2825fa44a096ecb5e")
