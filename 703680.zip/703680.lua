-- Lua provided by RyzenAPI
-- Game: Cursed Deal

-- MAIN APPLICATION
addappid(703680)

-- MAIN APP DEPOTS / PACKAGES
addappid(703682,0,"1a7c4022ef90a1b0eed2fd8ec2311a9f219d173a1e7838b2825fa44a096ecb5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
