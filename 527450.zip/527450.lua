-- Lua provided by RyzenAPI
-- Game: Cockroach Simulator

-- MAIN APPLICATION
addappid(527450)

-- MAIN APP DEPOTS / PACKAGES
addappid(527451, 1, "5ba52ef653b6e42da1de630c7c9ba549c6bc3a2ff607681f3fdb504b40575628")
addappid(527452, 1, "61eaba5a893092d894477cd002ed515241ee3d76e3f8d55cc40d79232e302331")
addappid(527453, 1, "892099b24241c4bb5b6655c14c117820e8b9e333918e0410bca1cc3edcf82bfe")
