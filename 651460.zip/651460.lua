-- Lua provided by RyzenAPI
-- Game: AppID 651460

-- MAIN APPLICATION
addappid(651460)

-- MAIN APP DEPOTS / PACKAGES
addappid(651461, 1, "b4cc18d68b911ade73b1c3f3164f17dde995fa54033f23a97ef300f3ed34990e")
