-- Lua provided by RyzenAPI
-- Game: addappid(2517130)

-- MAIN APPLICATION
addappid(2517130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517131, 1, "d64c99ddc3de3bb5710076edaa2cc4f0bc1738549f028afc257098bf5e68edfe")
