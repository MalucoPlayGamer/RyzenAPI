-- 1862950's Lua and Manifest Created by Hubcap Manifest
-- Captain Soda
-- Created: July 08, 2026 at 06:08:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1862950, 1, "f7689fc75a6337b3cec5ab766404b44e63c7dd86a31ef4e396a12796f57635a4") -- Captain Soda
-- MAIN APP DEPOTS
addappid(1862951, 1, "699246be8db5cc41a4e3914c378c9814fb8411a8ee2ecb2dd58fe8f8723517a2") -- Depot 1862951
setManifestid(1862951, "3705650003379722518", 409976017)