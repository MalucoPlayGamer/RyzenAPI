-- Lua provided by RyzenAPI
-- Game: Rune Gate: Retribution

-- MAIN APPLICATION
addappid(2731350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731351, 1, "3e78d65cdc56439763fb2f80d7856d6f0af5360fa8e4e50ef88d09223015e5b9")

