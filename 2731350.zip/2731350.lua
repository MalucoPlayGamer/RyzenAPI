-- Lua provided by RyzenAPI
-- Game: Rune Gate: Retribution

-- MAIN APPLICATION
addappid(2731350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731351, 1, "3e78d65cdc56439763fb2f80d7856d6f0af5360fa8e4e50ef88d09223015e5b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
