-- Lua provided by RyzenAPI
-- Game: Vacation Cafe Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3196440, 1, "db8582bec3de5a2ab164d5da2294dfa552c5b120ce7288248fb5da27d2c9483c") -- Vacation Cafe Simulator
addappid(3196441, 1, "f924bc49d5f16180c0f9f708f08c9d029740e06dbb64c286fcbf695821d24bbc") -- Depot 3196441
addappid(3196442, 1, "4a05fd5c5dca86676061eedc686b32bb993e8fa72a62ed265971f72dd6b38107") -- Depot 3196442

