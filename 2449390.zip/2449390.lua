-- Lua provided by RyzenAPI
-- Game: AppID 2449390

-- MAIN APPLICATION
addappid(2449390)
-- Game: addappid(2449390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449391, 1, "854fae2a1f2aad34fd294066444564241272a6ced86b0b13c334acea82c61421")
