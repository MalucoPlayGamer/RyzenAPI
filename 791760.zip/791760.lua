-- Lua provided by RyzenAPI
-- Game: addappid(791760)

-- MAIN APPLICATION
addappid(791760)

-- MAIN APP DEPOTS / PACKAGES
addappid(791761, 1, "f2d67d9b4f32f6b22c57a8471817f8d5189037c091005b6a7bcd5c85fc14a325")
