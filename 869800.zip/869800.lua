-- Lua provided by RyzenAPI
-- Game: 869800

-- MAIN APPLICATION
addappid(869800)
-- Game: addappid(869800)

-- MAIN APP DEPOTS / PACKAGES
addappid(869801, 1, "71bc3128623fe247a3b8da5af1ab924c84f4bb8c747826f1c46f09d0b4c0acbe")
addappid(869802, 1, "606803f2663e9e2211ad2661c7553afcc8f5cbf4042df1a2c9bd604167dde1c5")
addappid(869803, 1, "08a6a3fef962cec197d0e37016f893011d0bc498706c64eddc487ce693442f65")
