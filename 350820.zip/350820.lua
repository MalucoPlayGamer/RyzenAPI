-- Lua provided by RyzenAPI
-- Game: AppID 350820

-- MAIN APPLICATION
addappid(350820)

-- MAIN APP DEPOTS / PACKAGES
addappid(350821, 1, "8b0751bb8c6d8585235cda1494c4a04dcdd6e9b77bccac6a47fce01e27e2f764")
