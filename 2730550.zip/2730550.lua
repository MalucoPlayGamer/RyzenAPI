-- Lua provided by RyzenAPI
-- Game: Bartending Master

-- MAIN APPLICATION
addappid(2730550)
-- Game: addappid(2730550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730551, 1, "f6fc12db41bacdf908f9a19137028831624ce0eca9684218eebf2cd5b14c5d9e")
