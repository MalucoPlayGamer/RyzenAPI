-- Lua provided by RyzenAPI
-- Game: Hookah Haze

-- MAIN APPLICATION
addappid(2470300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470301, 1, "a7872872c156d69ba77a8005eaf9974f9a5917f2b68d33fd1aad07b93d827730")
