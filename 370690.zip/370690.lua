-- Lua provided by RyzenAPI
-- Game: addappid(370690)

-- MAIN APPLICATION
addappid(370690)
addappid(1064550)

-- MAIN APP DEPOTS / PACKAGES
addappid(370691, 1, "605991a1c95ad643092e3d67c1c60c72a9ef77b41121a957a69ff3cbc52f5862")
