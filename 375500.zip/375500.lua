-- Lua provided by RyzenAPI
-- Game: Game: The Deep Paths: Labyrinth Of Andokost

-- MAIN APPLICATION
addappid(375500)
-- Game: addappid(375500)

-- MAIN APP DEPOTS / PACKAGES
addappid(375501, 1, "b3e6238f6e817e700c5c409e05c6000a1a1a95c107548c215f5aeaab4722a797")
