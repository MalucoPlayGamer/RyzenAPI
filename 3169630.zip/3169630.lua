-- Lua provided by RyzenAPI
-- Game: 3169630

-- MAIN APPLICATION
addappid(3169630)
-- Game: addappid(3169630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169631, 1, "519d92a6089c32a47fca3d6abcac34651fd40ec6de329980c4012ecd7727223c")
