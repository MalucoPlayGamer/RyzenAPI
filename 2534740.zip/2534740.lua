-- Lua provided by RyzenAPI
-- Game: CRYMACHINA - Mini Art Book

-- MAIN APPLICATION
addappid(2534740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534740,0,"cbc93cc87ef774e89a09e8c0ed75287166c28ddb914c274ee2c6a4c83d02281a")

