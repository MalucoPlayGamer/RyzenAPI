-- Lua provided by SkyAPI 
-- Game: AppID 1315680
addappid(1315680)
addappid(1315681, 1, "0b5d6dc99f24d258cd9b94bd16d4afc241fa139531539fe10c51460bccd31a31")
addappid(1315682, 1, "6471de146b92ea1f163d0fe29b82bc589dd8307063a8299be8ac57fbfb4eaa8b")
