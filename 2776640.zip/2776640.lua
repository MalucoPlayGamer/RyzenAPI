-- Lua provided by RyzenAPI
-- Game: addappid(2776640)

-- MAIN APPLICATION
addappid(2776640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776641, 1, "88a11bdd7aa568f72d1a0571229f88d770db9dd8ce435c0d78e4b27662d4e567")
