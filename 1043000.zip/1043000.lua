-- Lua provided by RyzenAPI
-- Game: Game: Zen Chess: Mate in Four

-- MAIN APPLICATION
addappid(1043000)
-- Game: addappid(1043000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043001, 1, "10bbb4cf8b000745ee1d9a46ae2f489f0cb4e73be93b9809aa23eec40e5a78fd")
