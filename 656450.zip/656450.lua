-- Lua provided by RyzenAPI 
-- Game: Alien Hallway 2
addappid(656450)
addappid(656451, 1, "e6c53351bd4b43aaf34ff1675adee2e4d565177f01bbc66bb7855108dc3f3937")
addappid(656452, 1, "c94177bd76f324514a871623d35612ff3cd426e8fd41cdd77f2cff6bbc8641bd")
