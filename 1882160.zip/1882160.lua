-- Lua provided by RyzenAPI
-- Game: Game: AppID 1882160

-- MAIN APPLICATION
addappid(1882160)
-- Game: addappid(1882160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882161, 1, "e0e3dbc015d005de21be36399578f4c76bf62632c88d94a0ea80944363666342")
