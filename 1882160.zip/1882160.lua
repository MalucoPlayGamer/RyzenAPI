-- Lua provided by RyzenAPI
-- Game: 山海皆可平

-- MAIN APPLICATION
addappid(1882160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1882161, 1, "e0e3dbc015d005de21be36399578f4c76bf62632c88d94a0ea80944363666342")
