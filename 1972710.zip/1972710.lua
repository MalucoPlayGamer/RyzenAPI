-- Lua provided by RyzenAPI
-- Game: 1972710

-- MAIN APPLICATION
addappid(1972710)
addappid(2100180)
-- Game: addappid(1972710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972711, 1, "77e192ae47a5a48fb6afd4a608af1e55f4da1e30c31a9dc1738b8439eaeab368")
addappid(1972712, 1, "d4e5077e66b22b4f3c17054162038802734eaa3e89c8ba5edf7854138370f6d0")
