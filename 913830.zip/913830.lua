-- Lua provided by RyzenAPI
-- Game: Slime Age: Parody MMORPG Clicker

-- MAIN APPLICATION
addappid(913830)

-- MAIN APP DEPOTS / PACKAGES
addappid(913831, 1, "1f74a6b902384998be6883dde926f9b34e0ff945fb620139d3a3b382adcf66a1")

