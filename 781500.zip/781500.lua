-- Lua provided by RyzenAPI
-- Game: addappid(781500)

-- MAIN APPLICATION
addappid(781500)

-- MAIN APP DEPOTS / PACKAGES
addappid(781501, 1, "976ed5aa7e6d81d0acf299b534c372b0052af44c5f13464fc5e72008af5c535e")
