-- Lua provided by SkyAPI 
-- Game: AppID 781500
addappid(781500)
addappid(781501, 1, "976ed5aa7e6d81d0acf299b534c372b0052af44c5f13464fc5e72008af5c535e")
