-- Lua provided by RyzenAPI
-- Game: EDENS ZERO - Accessory "Dragon Wings"

-- MAIN APPLICATION
addappid(3345420)
-- Game: addappid(3345420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345420,0,"2200753bbc8b717820588bd1c244b34fb2b89d699f3645a2192b0ee7d71f6a0e")
