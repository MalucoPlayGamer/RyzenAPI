-- Lua provided by RyzenAPI
-- Game: 2089520

-- MAIN APPLICATION
addappid(2089520)
-- Game: addappid(2089520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089521, 1, "e402ae06e826000029a04b6eb9c69186ebdea7357679a53d3a6a7982dda4c107")
