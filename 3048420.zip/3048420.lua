-- Lua provided by RyzenAPI
-- Game: Set Yourself on Fire

-- MAIN APPLICATION
addappid(3048420)

