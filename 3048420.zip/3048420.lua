-- Lua provided by RyzenAPI
-- Game: Set Yourself on Fire

-- MAIN APPLICATION
addappid(3048420)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3805380)
