-- Lua provided by RyzenAPI
-- Game: Lands Of The Lost

-- MAIN APPLICATION
addappid(868600)

-- MAIN APP DEPOTS / PACKAGES
addappid(868601, 1, "6b9fdd60d282230297eb47346644bff168da4995a8c81a573aab6f9f895e5f65")
