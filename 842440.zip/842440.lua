-- Lua provided by RyzenAPI
-- Game: addappid(842440)

-- MAIN APPLICATION
addappid(842440)

-- MAIN APP DEPOTS / PACKAGES
addappid(842441, 1, "7c86acbfbb74cd4586b835fb5cc06630d53e579a6666741f635d80030b6b204a")
