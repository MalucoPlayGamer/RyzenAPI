-- Lua provided by RyzenAPI
-- Game: addappid(2439230)

-- MAIN APPLICATION
addappid(2439230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439231, 1, "064f9be460c6c5505422c0899c55a1b02d7be725252ad3e25e2680f7785b7dff")
