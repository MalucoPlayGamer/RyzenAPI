-- Lua provided by RyzenAPI
-- Game: addappid(536770)

-- MAIN APPLICATION
addappid(536770)

-- MAIN APP DEPOTS / PACKAGES
addappid(536771, 1, "bf381baf652fe150afb5314aa8b299422df1df7f2757a1dfdbeb6b90f31a8a99")
