-- Lua provided by RyzenAPI
-- Game: Girl Survivors

-- MAIN APPLICATION
addappid(2355000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355001, 1, "4fcc137e491938dec879cfee51be33cfbb99e5de18c1ffe7133db0dbdbde3da3")

