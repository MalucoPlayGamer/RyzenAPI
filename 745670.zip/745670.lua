-- Lua provided by RyzenAPI
-- Game: AppID 745670

-- MAIN APPLICATION
addappid(745670)

-- MAIN APP DEPOTS / PACKAGES
addappid(745671, 1, "bffedd0867bb1d9d0b99fc53b47f3129d1233fb6bb623144aeabe4978f8fe423")
addappid(745672, 1, "d33e098f539eeb6037c9ee3ffcf778ce5d1041b19dead3e7f7fe76a3a64e6eba")
addappid(745673, 1, "6ec3cadff81c1fded71a68f6a99cc8cb60bde7db2e015e06d6f472863f4c3169")

