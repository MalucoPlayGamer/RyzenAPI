-- Lua provided by RyzenAPI
-- Game: AppID 496350

-- MAIN APPLICATION
addappid(496350)

-- MAIN APP DEPOTS / PACKAGES
addappid(496351, 1, "c63957efa744bd21dcd2dba09a57a3853f934cbc85e6fa8462bdb71c6a81da41")
