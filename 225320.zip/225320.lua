-- Lua provided by RyzenAPI
-- Game: Tomb Raider III (1998)

-- MAIN APPLICATION
addappid(225320)

-- MAIN APP DEPOTS / PACKAGES
addappid(225321, 1, "25b5e72a53b801a5586e423fb9b910f861f118729349118fa181a82bdcff68e3")

