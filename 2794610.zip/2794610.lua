-- Lua provided by RyzenAPI
-- Game: 2794610

-- MAIN APPLICATION
addappid(2794610)
-- Game: addappid(2794610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794611, 1, "1120adfc90aa4e57c0416d48ba2ee87859c6760a82bce5bc393f742d808e3c04")
