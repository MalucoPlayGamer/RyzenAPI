-- Lua provided by RyzenAPI
-- Game: Game: Automobiels and the Eisenhower Hiway System the Game

-- MAIN APPLICATION
addappid(944610)
-- Game: addappid(944610)

-- MAIN APP DEPOTS / PACKAGES
addappid(944611, 1, "58e64fe6bc0d300447bd2dced3b44a14c0a6f8fc3886f56f4126017e2d5c4215")
