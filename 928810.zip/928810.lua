-- Lua provided by RyzenAPI
-- Game: addappid(928810)

-- MAIN APPLICATION
addappid(928810)

-- MAIN APP DEPOTS / PACKAGES
addappid(928811, 1, "c209e56f89b76de5b11a06eb8418bb7a9c2e1c7eafe38c8afc1748551863f446")
