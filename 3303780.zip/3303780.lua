-- Lua provided by RyzenAPI
-- Game: Game: CODE Bunny

-- MAIN APPLICATION
addappid(3303780)
-- Game: addappid(3303780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3303781, 1, "5bf6208804688dc7b3d367d798124909b5086b0fd1d557e61170c437d446d301")
