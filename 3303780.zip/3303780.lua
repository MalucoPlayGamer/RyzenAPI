-- Lua provided by RyzenAPI 
-- Game: CODE Bunny
addappid(3303780)
addappid(3303781, 1, "5bf6208804688dc7b3d367d798124909b5086b0fd1d557e61170c437d446d301")
