-- Lua provided by RyzenAPI
-- Game: Street Sense

-- MAIN APPLICATION
addappid(1806550)
-- Game: addappid(1806550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806551, 1, "35d68cd978921efbe2ee5dd070cbd9c22d2d02efd4cac930cd906ba49161ebeb")
