-- Lua provided by RyzenAPI
-- Game: Game: AppID 1142700

-- MAIN APPLICATION
addappid(1142700)
-- Game: addappid(1142700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142701, 1, "cecfa8de55bca6fc9b12085f1b3019a090241657e8663d0392872378432df624")
