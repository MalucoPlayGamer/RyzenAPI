-- Lua provided by RyzenAPI
-- Game: 2252550

-- MAIN APPLICATION
addappid(2252550)
-- Game: addappid(2252550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252551, 1, "eee6455e65082be6ff91acf2a41b81ed0146eb9a6be27d853f28e406f6b8f1cb")
