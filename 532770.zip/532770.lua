-- Lua provided by RyzenAPI
-- Game: Time Leap Paradise SUPER LIVE!

-- MAIN APPLICATION
addappid(532770)
addappid(551790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(532771, 1, "2a9e5e89072ac1683700a5953bde4bdd30ce29e2ddbff0b87ca07c1dd7884d2d")

