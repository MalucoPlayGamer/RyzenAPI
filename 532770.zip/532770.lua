-- Lua provided by RyzenAPI
-- Game: Time Leap Paradise SUPER LIVE!

-- MAIN APPLICATION
addappid(532770)
addappid(551790)
-- Game: addappid(532770)

-- MAIN APP DEPOTS / PACKAGES
addappid(532771, 1, "2a9e5e89072ac1683700a5953bde4bdd30ce29e2ddbff0b87ca07c1dd7884d2d")
