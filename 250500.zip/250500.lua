-- Lua provided by RyzenAPI
-- Game: Super Amazing Wagon Adventure

-- MAIN APPLICATION
addappid(250500)

-- MAIN APP DEPOTS / PACKAGES
addappid(250501, 1, "6631ca7b61d4b131c4710ddc225b36f5f5b51b759135c5ab0fdb69386861a7d7")

