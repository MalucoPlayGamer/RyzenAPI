-- Lua provided by SkyAPI 
-- Game: Skating Rink Story
addappid(3601190)
addappid(3601191, 1, "811578cf0f699654332b0dad4fcea2790ee64c5da2a033069ed601e865f54cc2")
