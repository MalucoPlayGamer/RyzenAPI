-- Lua provided by RyzenAPI
-- Game: Game: The Night Guard

-- MAIN APPLICATION
addappid(2908360)
-- Game: addappid(2908360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908361, 1, "81d25fdd31edc00c7259da2ba1e960b4bbea4842efa9978247e6cedb6012bc40")
