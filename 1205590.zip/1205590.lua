-- Lua provided by RyzenAPI
-- Game: 1205590

-- MAIN APPLICATION
addappid(1205590)
-- Game: addappid(1205590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205591, 1, "deb7bc6206bbf95498fcb093fd41f875ab8fbb1264a2de11c84dd1b026eeeb04")
