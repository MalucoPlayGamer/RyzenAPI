-- Lua provided by RyzenAPI
-- Game: addappid(888760)

-- MAIN APPLICATION
addappid(888760)

-- MAIN APP DEPOTS / PACKAGES
addappid(888761, 1, "258fa112cd5a0cd33010b6301ee7a35751b314817acdf67d07c456ec1dcc4bac")
