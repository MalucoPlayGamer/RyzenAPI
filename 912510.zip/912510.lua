-- Lua provided by RyzenAPI
-- Game: Oh Ship Arena

-- MAIN APPLICATION
addappid(912510)
-- Game: addappid(912510)

-- MAIN APP DEPOTS / PACKAGES
addappid(912511, 1, "7f5e2afee1ce83de88929690d7b9900e734ba4409f577a770b76e92ff39277b5")
