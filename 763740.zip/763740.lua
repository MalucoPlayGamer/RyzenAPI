-- Lua provided by RyzenAPI
-- Game: addappid(763740)

-- MAIN APPLICATION
addappid(763740)

-- MAIN APP DEPOTS / PACKAGES
addappid(763741, 1, "14b0a31d01abf4720c4cebe0c995ae3d521f481d23c37308a16174f6ebabf410")
