-- Lua provided by RyzenAPI
-- Game: Game: AppID 2817510

-- MAIN APPLICATION
addappid(2817510)
-- Game: addappid(2817510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817511, 1, "5930d344f1eb84dcbdc3a10cd30b8509f5e3bf579fbdf37c85539bc5af2cb987")
