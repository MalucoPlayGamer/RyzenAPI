-- Lua provided by RyzenAPI
-- Game: Game: My Dream Sport Dating Simulator

-- MAIN APPLICATION
addappid(1521490)
-- Game: addappid(1521490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521491, 1, "d51403b3a04c77e268b3a9ffeb654f6c3f4ead1bc43757483c4ab0e4d22683dd")
