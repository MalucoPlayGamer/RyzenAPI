-- Lua provided by RyzenAPI
-- Game: Simple VR Video Player

-- MAIN APPLICATION
addappid(500500)
-- Game: addappid(500500)

-- MAIN APP DEPOTS / PACKAGES
addappid(500501, 1, "4ac17c125eef508944604fc7b398a153fd072043d20790f282def206d54dee81")
