-- Lua provided by RyzenAPI
-- Game: Simple VR Video Player

-- MAIN APPLICATION
addappid(500500)

-- MAIN APP DEPOTS / PACKAGES
addappid(500501, 1, "4ac17c125eef508944604fc7b398a153fd072043d20790f282def206d54dee81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
