-- Lua provided by RyzenAPI
-- Game: Disney Infinity 1.0: Gold Edition

-- MAIN APPLICATION
addappid(541640)

-- MAIN APP DEPOTS / PACKAGES
addappid(541641, 1, "fa2efda45de22bd87d22fe19b13381bd98095bd62f2d0fee9780e0fd56119f78")
