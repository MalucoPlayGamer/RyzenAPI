-- Lua provided by RyzenAPI
-- Game: 2201390

-- MAIN APPLICATION
addappid(2201390)
-- Game: addappid(2201390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201391, 1, "06c6d7f609691dd64fe34f64e87569decbab86478c1651eb0c2ce3e0d6a8d573")
