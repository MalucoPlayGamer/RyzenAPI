-- Lua provided by RyzenAPI 
-- Game: Palladise Island：Legendary Space
addappid(2201390)
addappid(2201391, 1, "06c6d7f609691dd64fe34f64e87569decbab86478c1651eb0c2ce3e0d6a8d573")
