-- Lua provided by RyzenAPI
-- Game: Memories Off

-- MAIN APPLICATION
addappid(675610)

-- MAIN APP DEPOTS / PACKAGES
addappid(675611, 1, "487a6c675ebe0eeba4549a838be23950d402337c9ad63b759a914727686442a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
