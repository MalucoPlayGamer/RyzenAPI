-- Lua provided by RyzenAPI
-- Game: Memories Off

-- MAIN APPLICATION
addappid(675610)
-- Game: addappid(675610)

-- MAIN APP DEPOTS / PACKAGES
addappid(675611, 1, "487a6c675ebe0eeba4549a838be23950d402337c9ad63b759a914727686442a0")
