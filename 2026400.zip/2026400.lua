-- Lua provided by RyzenAPI
-- Game: Heavy Hearts Demo

-- MAIN APPLICATION
addappid(2026400)
-- Game: addappid(2026400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026401, 1, "d4cce55567b025f702efc7e15e0e7b9d491cc6cd562a818a48013ab5d073b49c")
