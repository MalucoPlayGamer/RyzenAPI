-- Lua provided by RyzenAPI
-- Game: SOVL: Fantasy Warfare

-- MAIN APPLICATION
addappid(1870300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870301, 1, "bf490f0cc51b55f40f81878a7bf7f250a31a0adf39bb3c76ac06b82a9c9fad86")
addappid(1870302, 1, "333736498f35cc5e583dc48ecba8f769403fec828e64c3897e1b6b4558861259")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2716130)
addappid(2728980)
addappid(2811290)
addappid(2893890)
addappid(2893900)
addappid(3091380)
addappid(3230100)
addappid(4001630)
addappid(4372230)
