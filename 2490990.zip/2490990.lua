-- Lua provided by RyzenAPI
-- Game: Game: Visions of Mana

-- MAIN APPLICATION
addappid(2490990)
-- Game: addappid(2490990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490991, 1, "976f5204ec9850c4707672971bdcd84efeadc86cb0d62e3b76743a465fbbdee7")
