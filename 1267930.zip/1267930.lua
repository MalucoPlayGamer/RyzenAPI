-- Lua provided by RyzenAPI
-- Game: Deadly Dozen: Pacific Theater

-- MAIN APPLICATION
addappid(1267930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267931, 1, "9b36e346a7b111c6ebba9c8649ce1327652cc37e09f339e9fde426010c9a3be8")
