-- Lua provided by RyzenAPI
-- Game: Deadly Dozen: Pacific Theater

-- MAIN APPLICATION
addappid(1267930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1267931, 1, "9b36e346a7b111c6ebba9c8649ce1327652cc37e09f339e9fde426010c9a3be8")

