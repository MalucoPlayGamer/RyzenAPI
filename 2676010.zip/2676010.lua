-- Lua provided by RyzenAPI
-- Game: Love Relaxation

-- MAIN APPLICATION
addappid(2676010)
-- Game: addappid(2676010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676011, 1, "608fb8ef7d59fdb6418aeb453122e7a63dbc493f671052fcdf719e1000f639d9")
