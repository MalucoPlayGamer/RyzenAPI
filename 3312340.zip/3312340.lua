-- Lua provided by RyzenAPI
-- Game: 风之歌

-- MAIN APPLICATION
addappid(3312340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312341, 1, "200d81dd84c4cbfa43097ceae1e41f42cbcaa01acaad6edaa210994c701b38d8")
