-- Lua provided by RyzenAPI
-- Game: addappid(1397310)

-- MAIN APPLICATION
addappid(1397310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397312,0,"731a96637d1051abd888d024f2e9ce2c466bfe69370686eba71d229c77c3ff8a")
