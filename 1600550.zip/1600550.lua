-- Lua provided by RyzenAPI
-- Game: Imaginaria

-- MAIN APPLICATION
addappid(1600550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600552,0,"b6e66d0501fdf3cfbe53fdef03b76a8de313f857380ff16c92008fb7706dc82a")
