-- Lua provided by RyzenAPI
-- Game: Rugby League Team Manager 3

-- MAIN APPLICATION
addappid(1154080)
addappid(1154081)
addappid(1154082)
addappid(1154083)
addappid(1154084)
addappid(1418262)
addappid(1418264)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418261,0,"e965ef08d794a2f2b148d974c6bb5c74109cab6fbc1858b71a7f69f3abb454d0")
addappid(1418263,0,"54fb9bccedc0ffe47a00da6c91df9c24e3d372a8932e50fbc204b5f1510cdc0e")

