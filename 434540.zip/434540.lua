-- Lua provided by RyzenAPI
-- Game: Secret of the Pendulum

-- MAIN APPLICATION
addappid(434540)

-- MAIN APP DEPOTS / PACKAGES
addappid(434541, 1, "f564bb625a4dd50baa4746b221fa6995680813f772f370f54c98586d549bc882")

