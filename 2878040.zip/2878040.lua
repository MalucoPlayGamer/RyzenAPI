-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2878040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878042,0,"bcc84f594b412c101ee53b492304d09816ad6a041976751d2c648b8d8c371da0")
