-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2878040)
addappid(2878042,0,"bcc84f594b412c101ee53b492304d09816ad6a041976751d2c648b8d8c371da0")
-- setManifestid(2878042,"200626368624181567")