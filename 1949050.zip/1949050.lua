-- Lua provided by RyzenAPI
-- Game: Curley Laboratory

-- MAIN APPLICATION
addappid(1949050)
-- Game: addappid(1949050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949051, 1, "546e8c0dbaba01642a64c640e49c1452a902e3c94c0ec09c3244381cda9eca5f")
