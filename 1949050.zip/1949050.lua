-- Lua provided by RyzenAPI
-- Game: Curley Laboratory

-- MAIN APPLICATION
addappid(1949050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1949051, 1, "546e8c0dbaba01642a64c640e49c1452a902e3c94c0ec09c3244381cda9eca5f")

