-- Lua provided by SkyAPI 
-- Game: Baby Steps
addappid(1281040)
addappid(1281041, 1, "d37691bb2e37d230f91be36619ead39c2689998218a88fcc2863168e6714a8fa")
addappid(1281042, 1, "053c7e21b7936b8331deb11bbc9ae5a3b3c6df28b450220009cd8bfc91a5173b")
