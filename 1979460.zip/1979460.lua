-- Lua provided by RyzenAPI
-- Game: Game: Sinister Night

-- MAIN APPLICATION
addappid(1979460)
-- Game: addappid(1979460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979461, 1, "c874f50c5fc658f3abd95df328c6f000b1c507d9538205a09a3cfc89cd82368f")
