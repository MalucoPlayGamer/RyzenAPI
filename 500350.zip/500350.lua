-- Lua provided by RyzenAPI
-- Game: Game: AppID 500350

-- MAIN APPLICATION
addappid(500350)
-- Game: addappid(500350)

-- MAIN APP DEPOTS / PACKAGES
addappid(500351, 1, "b9623eb610649e50dd6c44e49de5154ba4f5e9dba20631ffa2d8297682592563")
