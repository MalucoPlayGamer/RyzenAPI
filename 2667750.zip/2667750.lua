-- Lua provided by RyzenAPI
-- Game: Hungry Cats 饥饿的猫

-- MAIN APPLICATION
addappid(2667750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2667751, 1, "5c3b37a3331cdadad4f4394b34404c1d94b0f330be976594b6844a6ce070fb9f")

