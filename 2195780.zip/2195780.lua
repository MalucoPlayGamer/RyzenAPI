-- Lua provided by RyzenAPI
-- Game: Class of Heroes: Anniversary Edition

-- MAIN APPLICATION
addappid(2195780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195781, 1, "7aacbcbdab233828ad5e8e482a0d33a58e5cdacf22158e1ad15f9a5d56b07df0")
