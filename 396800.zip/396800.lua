-- Lua provided by RyzenAPI 
-- Game: 12 Labours of Hercules IV: Mother Nature (Platinum Edition)
addappid(396800)
addappid(396801, 1, "1d945bd20fc6b1937a080d8d1000332d6970c3db2c65d00a2973979240b0cb13")
addappid(396802, 1, "8335c1b6c577809baff4d7f9b15727a106e2880a0166492ef377e1d11a36b452")
addappid(396803, 1, "a124a07190c9d2e1e87ba385fb42f848153960ab72eecc2f761ede18a85e4d25")
