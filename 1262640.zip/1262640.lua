-- Lua provided by RyzenAPI
-- Game: Brittany Home Alone

-- MAIN APPLICATION
addappid(1262640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262641, 1, "4022f6a7d0206fdda55da5d47b343c737c5069fa970633a0a6ff6f161dbd5987")

