-- Lua provided by RyzenAPI
-- Game: Medieval Machines Builder - First Siege

-- MAIN APPLICATION
addappid(2669550)
-- Game: addappid(2669550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669551, 1, "d4ec603e5db39bed40818bde019fe1092cdfad0e40d9859c321098d6c6cfcfe7")
