-- Lua provided by RyzenAPI
-- Game: addappid(1557230)

-- MAIN APPLICATION
addappid(1557230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557231, 1, "4bd54fc58f85a7f449f48df073b855f185819bc15ff695a492c54c25413b1d42")
