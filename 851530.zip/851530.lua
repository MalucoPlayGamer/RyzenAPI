-- Lua provided by RyzenAPI
-- Game: Mini-Dead

-- MAIN APPLICATION
addappid(851530)
addappid(1199310)

-- MAIN APP DEPOTS / PACKAGES
addappid(851531, 1, "3956a1fbc9f95ee2f89eb98995c2c5e03bc6a193f3aa842b0b7926113c3985d3")
