-- Lua provided by RyzenAPI
-- Game: Mini-Dead

-- MAIN APPLICATION
addappid(851530)
addappid(1199310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(851531, 1, "3956a1fbc9f95ee2f89eb98995c2c5e03bc6a193f3aa842b0b7926113c3985d3")

