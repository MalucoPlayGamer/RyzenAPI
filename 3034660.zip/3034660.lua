-- Lua provided by RyzenAPI
-- Game: Dunebound Tactics

-- MAIN APPLICATION
addappid(3034660) -- Dunebound Tactics

-- MAIN APP DEPOTS / PACKAGES
addappid(3034661, 1, "1c434d8ca83ca66555cc53e46e1dbad77249240c3df735da27f4fd08f0c3956d") -- Depot 3034661
addtoken(3034660, "6333543378647707142")

