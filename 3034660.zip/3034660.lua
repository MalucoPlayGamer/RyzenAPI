-- 3034660's Lua and Manifest Created by Hubcap Manifest
-- Dunebound Tactics
-- Created: August 27, 2026 at 05:43:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3034660) -- Dunebound Tactics
addtoken(3034660, "6333543378647707142")
-- MAIN APP DEPOTS
addappid(3034661, 1, "1c434d8ca83ca66555cc53e46e1dbad77249240c3df735da27f4fd08f0c3956d") -- Depot 3034661
setManifestid(3034661, "4854828249439429734", 2298719823)