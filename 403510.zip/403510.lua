-- Lua provided by RyzenAPI
-- Game: Game: Fairy Tale Mysteries 2: The Beanstalk

-- MAIN APPLICATION
addappid(403510)
-- Game: addappid(403510)

-- MAIN APP DEPOTS / PACKAGES
addappid(403511, 1, "f3d429b4f03b1d6f5fc8e0e1bb1fc04d482c32fb88904328921bb7bc9e8463dd")
addappid(403512, 1, "013c6d90081ea20f22a25446aeab24b902939673cad24b9d64b52b17174d1fe6")
addappid(403513, 1, "7e0a9d753d92029e4c0a024542556daaa6fa3df22be8e2d20ed3e39a7175f945")
