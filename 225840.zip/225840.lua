-- Lua provided by RyzenAPI 
-- Game: Sven Co-op
addappid(225840)
addappid(225841, 1, "7133900a5945d998a51a8aa7b2dfa67595ef2f253d2506d99d546127bd8edb5b")
addappid(225842, 1, "33b6cec737899168b296ac5ee6fb22ab781fb72c1425bc03db45d8b26dbb2d40")
addappid(225843, 1, "b04f8448e721b441d21efdc18acdd4b05d46aeb621d4a08ae574a0f4de721158")
addappid(228983)
addappid(228988)
addappid(229001)
