-- Lua provided by RyzenAPI
-- Game: Lonesome Village

-- MAIN APPLICATION
addappid(1418360)
addappid(2341850)
addappid(2341851)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418361, 1, "c86e88e4418b6ec1ca6a322baf33684ad39e1d903e427c1e31b58e8058224c9e")
