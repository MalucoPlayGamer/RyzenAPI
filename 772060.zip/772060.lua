-- Lua provided by RyzenAPI
-- Game: Harvester of Dreams : Episode 1

-- MAIN APPLICATION
addappid(772060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(772061, 1, "4ff3ca3e6be3211cb663708c2550e2ca552a2fcdf3e95894167c9657af8fa202")
addappid(772062, 1, "dac6e90c6b7548799062bb21916959e8bf131e630f07b0b3bb2d8d6be3096048")
addappid(772064, 1, "34ab38e68ffb714bc279639a202bba15764bf3bff559a25d759eb69cb089fcbd")

