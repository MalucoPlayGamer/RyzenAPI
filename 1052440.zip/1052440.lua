-- Lua provided by RyzenAPI
-- Game: Croixleur Sigma - Deluxe Edition

-- MAIN APPLICATION
addappid(1052440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052441, 1, "5d247585300b10e4c18872b3a6fa69431982cf613dd167cd6a97c012747eacf4")
addappid(1052442, 1, "7313cebb9915470b539bc2d8170d472208af7476e72689107aa0c4ae259d30db")

