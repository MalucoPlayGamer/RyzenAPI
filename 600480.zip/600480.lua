-- Lua provided by RyzenAPI
-- Game: Megaquarium

-- MAIN APPLICATION
addappid(1315300)
addappid(1339440)
addappid(2574770)
addappid(4307900)

-- MAIN APP DEPOTS / PACKAGES
addappid(600480, 1, "ecc6b41bdeb4e4750d99ed0a67bad0e6ee68e0bfa41f5a5eab9563dffc2d6692") -- Megaquarium
addappid(600481, 1, "cfec171ac99a86936c242a0fa19e37eace19a84cd5d2adff51dfed55d536c887") -- Megaquarium Windows
addappid(600482, 1, "de6cd192497b107abc961735ad795d6ab801be336d49fbd8e850be38f3a37a68") -- Megaquarium OSX
addappid(600483, 1, "2c10070b28746d958ef7f141176814d8e9724c158aab74bc23993894cfbdba2f") -- Megaquarium Linux
addappid(1315300, 1, "c7101cdd4aa87fcffedfc82154c10b373197ce77ea253a1ede12aa95868afc1c") -- Megaquarium Freshwater Frenzy - Deluxe Expansion - Megaquarium: Freshwater Frenzy - Deluxe Expansion - Windows and Linux
addappid(1315301, 1, "cde5c9af5cfc8204eeff3d0ba6f31d90ff0de5eab8420b017e9eea4f6ad287c3") -- Megaquarium Freshwater Frenzy - Deluxe Expansion - Megaquarium: Freshwater Frenzy - Deluxe Expansion - OSX
addappid(1339440, 1, "5e2ed81c6f44576b240163391010fe5c238a7df570c264ce1ac6f010d58516a3") -- Megaquarium Architects Collection - Megaquarium: Architect's Collection - Windows and Linux
addappid(1339441, 1, "7b37506ab5cb37aa33b6acfa3692464608e692d8d4b4c16f62b6b2999dd842aa") -- Megaquarium Architects Collection - Megaquarium: Architect's Collection - OSX
addappid(2574770, 1, "fd3ff0ea5de3d0bcddc083fd79c4c1868155712529c44cbc4a5908e297fc7ee9") -- Megaquarium Deep Freeze - Deluxe Expansion - Depot 2574770
addappid(2574771, 1, "67042f8811371fa904ac888eb4c2557917be7ecdfa3c1705dc20ec93227630df") -- Megaquarium Deep Freeze - Deluxe Expansion - Depot 2574771
addappid(4307900, 1, "655bbf9e57e554bfa8b68760ddc8ac0b05e9e5f66c15b208ace65a1495653916") -- Megaquarium Invertebrilliant Collection - Depot 4307900

