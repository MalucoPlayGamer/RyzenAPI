-- Lua provided by RyzenAPI
-- Game: 3286270

-- MAIN APPLICATION
addappid(3286270)
-- Game: addappid(3286270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286271, 1, "0f5f82e0de67d1173d3098085fb174136fd18a3b4a7d608ac4eab50102dfa24f")
