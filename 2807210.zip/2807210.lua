-- Lua provided by RyzenAPI
-- Game: Robo Cats

-- MAIN APPLICATION
addappid(2807210)
