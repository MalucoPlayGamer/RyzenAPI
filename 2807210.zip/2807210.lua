-- Lua provided by RyzenAPI
-- Game: Robo Cats

-- MAIN APPLICATION
addappid(2807210)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2859210)
addappid(2859320)
