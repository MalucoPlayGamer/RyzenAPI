-- Lua provided by RyzenAPI
-- Game: Robo Cats

-- MAIN APPLICATION
addappid(2807210)
addappid(2859210)
addappid(2859320)

