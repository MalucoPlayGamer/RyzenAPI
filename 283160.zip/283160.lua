-- Lua provided by SkyAPI 
-- Game: House of the Dying Sun
addappid(283160)
addappid(283161, 1, "461d3794711b56ff24fdbe2072f2f08671f64d760e86538d1fdee8f8ab3b3c6d")
