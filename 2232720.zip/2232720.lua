-- Lua provided by RyzenAPI
-- Game: 2232720

-- MAIN APPLICATION
addappid(2232720)
-- Game: addappid(2232720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232721, 1, "4b73246bbe6e8cba5bf104cf11738e2dcb599fe89cd425a2f8c87bfe0a185c09")
