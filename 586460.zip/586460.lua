-- Lua provided by RyzenAPI
-- Game: Greyhound Manager 2 Rebooted

-- MAIN APPLICATION
addappid(586460)

-- MAIN APP DEPOTS / PACKAGES
addappid(586461, 1, "22403e5bc6d2297283d69e9a2a8bdf27d85d8a02b337af46d870325a0324f459")

