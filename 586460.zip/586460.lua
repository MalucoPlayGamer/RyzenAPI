-- Lua provided by RyzenAPI
-- Game: 586460

-- MAIN APPLICATION
addappid(586460)
-- Game: addappid(586460)

-- MAIN APP DEPOTS / PACKAGES
addappid(586461, 1, "22403e5bc6d2297283d69e9a2a8bdf27d85d8a02b337af46d870325a0324f459")
