-- Lua provided by RyzenAPI
-- Game: Greyhound Manager 2 Rebooted

-- MAIN APPLICATION
addappid(586460)

-- MAIN APP DEPOTS / PACKAGES
addappid(586461, 1, "22403e5bc6d2297283d69e9a2a8bdf27d85d8a02b337af46d870325a0324f459")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
