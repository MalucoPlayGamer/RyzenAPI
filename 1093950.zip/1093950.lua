-- Lua provided by RyzenAPI
-- Game: 1093950

-- MAIN APPLICATION
addappid(1093950)
-- Game: addappid(1093950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093951, 1, "32e85ffd035726cb9d4daea7a028d8c192996520bc23060bdc3a341a9351e351")
