-- Lua provided by RyzenAPI
-- Game: Draft of Darkness Soundtrack

-- MAIN APPLICATION
addappid(2633130)
-- Game: addappid(2633130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633131, 1, "f0666b5ab05d4759b7668d85740add11c531adb182d9943bda28f9013a4ff4f2")
