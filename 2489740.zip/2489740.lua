-- Lua provided by RyzenAPI
-- Game: Sleepy Time Jack: Digital Talking Body Pillow Demo

-- MAIN APPLICATION
addappid(2489740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489743,0,"a4f2797029f1619b644d494d2d07bcead8017ba45e6748547b6b857b29349f02")
