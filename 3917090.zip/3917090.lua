-- Lua provided by RyzenAPI
-- Game: Assetto Corsa Rally

-- MAIN APPLICATION
addappid(3917090) -- Assetto Corsa Rally

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(3917093, 1, "895ccaabbb11bef3c79056dd0b38b0af79b02c722780e801b29493ef248ea713") -- Depot 3917093

