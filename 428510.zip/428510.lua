-- Lua provided by RyzenAPI
-- Game: addappid(428510)

-- MAIN APPLICATION
addappid(428510)

-- MAIN APP DEPOTS / PACKAGES
addappid(428511, 1, "ba3bb041e841f9cf74e13d2b2fa3b2213e56df17cb4a5eeff9be962ef5566a72")
