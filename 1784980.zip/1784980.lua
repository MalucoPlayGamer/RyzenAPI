-- Lua provided by RyzenAPI
-- Game: Limita Luminii

-- MAIN APPLICATION
addappid(1784980)
-- Game: addappid(1784980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784981, 1, "c1be4773f199ede03d16b5ca82ab948d539d74b62aa9ad6c99394a29feee9be4")
