-- Lua provided by RyzenAPI
-- Game: Limita Luminii

-- MAIN APPLICATION
addappid(1784980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784981, 1, "c1be4773f199ede03d16b5ca82ab948d539d74b62aa9ad6c99394a29feee9be4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
