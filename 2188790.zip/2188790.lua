-- Lua provided by RyzenAPI
-- Game: addappid(2188790)

-- MAIN APPLICATION
addappid(2188790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188792,0,"8ff65e5df6d8a652db41fa4edc6402e0b1183f3d6b4f20ca7b483ab6dc847fde")
