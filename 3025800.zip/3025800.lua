-- Lua provided by RyzenAPI
-- Game: 3025800

-- MAIN APPLICATION
addappid(3025800)
-- Game: addappid(3025800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025801, 1, "5e56826263fa337ee9425a5ce78fe923f7d7c14d3542c74fbe95c3b987bd7e60")
