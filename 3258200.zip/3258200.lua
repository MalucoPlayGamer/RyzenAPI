-- Lua provided by RyzenAPI
-- Game: Conquest Dark Demo

-- MAIN APPLICATION
addappid(3258200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258201, 1, "2088902fe3d981c4d96dc6a8c096fb256862caf60abc1cc6e7a310f75fbc074c")
