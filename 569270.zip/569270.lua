-- Lua provided by RyzenAPI
-- Game: Sable Maze: Sullivan River Collector's Edition

-- MAIN APPLICATION
addappid(569270)

-- MAIN APP DEPOTS / PACKAGES
addappid(569271,0,"a68a400e28c6983e01fbb3636d78f8bb1aaa30ab41d3f2b16c9e6589acf5587f")

