-- Lua provided by RyzenAPI
-- Game: UWAR

-- MAIN APPLICATION
addappid(3301070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3301071, 1, "65e146c21ec3ce8a6acf22a37071f6983a630a8c2c5cd0231cfb7c5bd016760d")

