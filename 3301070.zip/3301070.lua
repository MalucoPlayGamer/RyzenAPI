-- Lua provided by RyzenAPI
-- Game: Game: UWAR

-- MAIN APPLICATION
addappid(3301070)
-- Game: addappid(3301070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301071, 1, "65e146c21ec3ce8a6acf22a37071f6983a630a8c2c5cd0231cfb7c5bd016760d")
