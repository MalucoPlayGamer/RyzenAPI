-- Lua provided by RyzenAPI
-- Game: addappid(1310970)

-- MAIN APPLICATION
addappid(1310970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310971, 1, "971e5bcce8fd45e66f5c2fb22e178c64170a6cbcb6dd7b917102ea02796a2a36")
