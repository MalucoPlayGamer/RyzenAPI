-- Lua provided by RyzenAPI
-- Game: addappid(732360)

-- MAIN APPLICATION
addappid(732360)

-- MAIN APP DEPOTS / PACKAGES
addappid(732361, 1, "ac24c114450283ba662fda085479c0f64520ac41c425aa2b82b282efd72289f1")
