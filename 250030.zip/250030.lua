-- Lua provided by RyzenAPI
-- Game: Game: Lilly Looking Through

-- MAIN APPLICATION
addappid(250030)
-- Game: addappid(250030)

-- MAIN APP DEPOTS / PACKAGES
addappid(250031, 1, "0f6a7ba736e1167ff8063e268ad891ae12e2784676f7e780443a17d791a6fce3")
addappid(250032, 1, "a49c1950eb02bfadf5f83789360c722a2af1c422eb251a35f904fab0576deb7f")
