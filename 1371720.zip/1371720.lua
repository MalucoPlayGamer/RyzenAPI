-- Lua provided by RyzenAPI 
-- Game: Card Shark
addappid(1371720)
addappid(1371721, 1, "2abe767b0569e8a29786d234153036ff3d52f0b725bfdab2c69b43ea75d6fe93")
addappid(1371722, 1, "e49418b3ea704fb3b1b257eb37ac73a14272a18584a624def06ff239423fc859")
addappid(1371723, 1, "c79752ff01df9f4a3acf0aae46b1676384ec552a9a45a85a359f2bd6340d5e6f")
