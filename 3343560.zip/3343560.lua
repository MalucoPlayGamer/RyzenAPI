-- Lua provided by RyzenAPI
-- Game: addappid(3343560)

-- MAIN APPLICATION
addappid(3343560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343561, 1, "fd15434c7b60a7d4a2782aaf4f12bbe6cc847d6ef3cefbf2b104fadd6ede2710")
