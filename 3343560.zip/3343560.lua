-- Lua provided by RyzenAPI
-- Game: 异界炮艇（Otherworldly Air Gunship）

-- MAIN APPLICATION
addappid(3343560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3343561, 1, "fd15434c7b60a7d4a2782aaf4f12bbe6cc847d6ef3cefbf2b104fadd6ede2710")
