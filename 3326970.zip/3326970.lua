-- Lua provided by RyzenAPI 
-- Game: Lustful Victor
addappid(3326970)
addappid(3326971, 1, "7f738cf99d45c1291750c76c19e6f0d64ecde00ba6cd374d85ae2e8ad4a2412c")
