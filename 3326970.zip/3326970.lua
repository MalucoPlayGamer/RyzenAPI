-- Lua provided by RyzenAPI
-- Game: Lustful Victor

-- MAIN APPLICATION
addappid(3326970)
-- Game: addappid(3326970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326971, 1, "7f738cf99d45c1291750c76c19e6f0d64ecde00ba6cd374d85ae2e8ad4a2412c")
