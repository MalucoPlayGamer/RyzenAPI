-- Lua provided by RyzenAPI
-- Game: Game: AppID 3155880

-- MAIN APPLICATION
addappid(3155880)
-- Game: addappid(3155880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155881, 1, "6532d5964534ae762a852425fceae48fff12a8584a302de3079ca6cf7aee868a")
