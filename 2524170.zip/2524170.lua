-- Lua provided by RyzenAPI
-- Game: Chaotic Pursuit

-- MAIN APPLICATION
addappid(2524170)
-- Game: addappid(2524170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524171, 1, "8498354ed99f802d924fe5a744a71dc199ff5cad3069a44740aaf96e2cfd9cef")
