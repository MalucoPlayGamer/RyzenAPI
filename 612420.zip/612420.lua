-- Lua provided by RyzenAPI
-- Game: Vikings - Wolves of Midgard Demo

-- MAIN APPLICATION
addappid(404599)
addappid(501551)
addappid(612420)
addappid(612421)

-- MAIN APP DEPOTS / PACKAGES
addappid(404592,0,"7c8fe2133bd641c652ad9790af7fe07d3ea7ec9aa95b70b3eaa02678404138ef")
addappid(404593,0,"10e24709f6ea9a4af717f1af249838ddce939f3797d80613eb86534100230dc8")
addappid(404594,0,"d07ff0a91cb0d2fa3c4d38b619ef5e5219eb149a7a2b7eba7b9e09bff629af25")
addappid(404595,0,"48bc6405f6f1d3e8baf3c60a715164b74279b97f2c1fa6a66ecbdb86ecc39ae6")
addappid(404596,0,"71b9a95d2f2dc6ea7d674e4fb9dcfdd2d5453f30013576385579da8a9a53d3da")
addappid(404597,0,"3cd9534d0557795dbe5705ebd619a17363e67c1adfc78d4e1934c399c256363f")
addappid(404598,0,"385cad7ba1c948f1f21c421d442735caf5a6c369a092b1068d372983e3c42a08")
addappid(501552,0,"80b3ec4a91f0921c2a0ebbee74718a570448d8ef75c48c6303bf2616bc0ef4ba")

