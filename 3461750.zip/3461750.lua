-- Lua provided by SkyAPI 
-- Game: Where's my kitty
addappid(3461750)
addappid(3461751, 1, "8253f77f76e2d5d65a79783c25847c20a81e009e455ac191e9b1dab395ebddb5")
