-- Lua provided by RyzenAPI
-- Game: Raise Your Tribe

-- MAIN APPLICATION
addappid(1908530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908531,0,"a593cfe876aee9c14382be017076ad6081ccb9d4ae41ba29ae0635f3eee42fdf")

