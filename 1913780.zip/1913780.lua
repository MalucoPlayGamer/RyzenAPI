-- Lua provided by RyzenAPI
-- Game: addappid(1913780)

-- MAIN APPLICATION
addappid(1913780)
addappid(2438030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913781, 1, "e5fa798a6129441eeb1393af6bc9bb3d02dc9062714eca22ce489344ba8d54e5")
