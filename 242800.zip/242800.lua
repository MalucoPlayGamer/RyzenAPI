-- Lua provided by RyzenAPI
-- Game: Day One : Garry's Incident

-- MAIN APPLICATION
addappid(242800)

-- MAIN APP DEPOTS / PACKAGES
addappid(242801, 1, "0d79eb3d7fcdd93bb2095fcf6acc111bbf2e2ce806731a16201b6e5140948ff3")
