-- Lua provided by RyzenAPI
-- Game: Head Worms

-- MAIN APPLICATION
addappid(1473930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473931, 1, "f11f2ef29a577058ce6d1525f51b82376efb47f2ba004ba2af2f9ab6e8e5a8c4")
