-- Lua provided by RyzenAPI
-- Game: Game: AppID 1278350

-- MAIN APPLICATION
addappid(1278350)
-- Game: addappid(1278350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278351, 1, "92e4afe5e40365e27385c1966b048ae21947786f0dcdaca49697357220e78a0d")
