-- Lua provided by RyzenAPI
-- Game: 2924050

-- MAIN APPLICATION
addappid(2924050)
-- Game: addappid(2924050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924051, 1, "8a62cbec218c7159ed981fadd5a5fb99665b0cc06c6d6e9c24fe0c8f2ae03c42")
