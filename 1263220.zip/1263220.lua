-- Lua provided by RyzenAPI 
-- Game: AppID 1263220
addappid(1263220)
addappid(1263221, 1, "eb0d280da84c71f09f1985976b4112bcdb972f2c395230ad4395c62e4953c334")
