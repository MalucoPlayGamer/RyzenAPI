-- Lua provided by SkyAPI 
-- Game: Louma
addappid(2583760)
addappid(2583761, 1, "40a1af7ab8d56945262b8f3ffb36d953c31da1294470d30f56f5492339ec6914")
