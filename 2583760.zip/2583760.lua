-- Lua provided by RyzenAPI
-- Game: Game: Louma

-- MAIN APPLICATION
addappid(2583760)
-- Game: addappid(2583760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583761, 1, "40a1af7ab8d56945262b8f3ffb36d953c31da1294470d30f56f5492339ec6914")
