-- Lua provided by RyzenAPI
-- Game: 東方輝針城 〜 Double Dealing Character

-- MAIN APPLICATION
addappid(1043240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1043241, 1, "c0a48134a7d1e921cc843298b39c1dcc19c76954dc589473aa0e27a39339649f")
