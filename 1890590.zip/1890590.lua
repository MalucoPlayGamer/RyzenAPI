-- Lua provided by SkyAPI 
-- Game: SUPER NANARU
addappid(1890590)
addappid(1890591, 1, "420bfd426573403948635016d6753fcc8140cb0d65cc99d1302c2c6b619a3a02")
