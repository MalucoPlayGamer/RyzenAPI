-- Lua provided by RyzenAPI
-- Game: addappid(656220)

-- MAIN APPLICATION
addappid(656220)

-- MAIN APP DEPOTS / PACKAGES
addappid(656221, 1, "71daebbe97b868a98b710f5f2e549b3c7230e3a7f1bb355d913364b7fb9bac7d")
