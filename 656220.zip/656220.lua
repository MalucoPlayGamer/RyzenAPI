-- Lua provided by RyzenAPI
-- Game: AppID 656220

-- MAIN APPLICATION
addappid(656220)

-- MAIN APP DEPOTS / PACKAGES
addappid(656221, 1, "71daebbe97b868a98b710f5f2e549b3c7230e3a7f1bb355d913364b7fb9bac7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
