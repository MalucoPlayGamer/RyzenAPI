-- Lua provided by RyzenAPI
-- Game: 214510

-- MAIN APPLICATION
addappid(214510)
-- Game: addappid(214510)

-- MAIN APP DEPOTS / PACKAGES
addappid(214511, 1, "b350edf474fc7c130bad45e320962c01c7199096257f9a90bbb82ca8fd4addbf")
