-- Lua provided by SkyAPI 
-- Game: AppID 1541780
addappid(1541780)
addappid(1541781, 1, "e42ec2717765d55d7663f046064f350ddf83bad2c46d8f834904fa39da7cca30")
addappid(1541783, 1, "8f6fbccef070f9e830b9a55bd76270c1b906726b4187169a8de06b4fda5ce333")
