-- Lua provided by RyzenAPI
-- Game: setManifestid(2573642,"1661303098876980072")

-- MAIN APPLICATION
addappid(2573640)
-- Game: addappid(2573640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573642,0,"7ab638a69c20d62a91e38a55f7fcdffa1e8436b22b9b318a223d70d66e36b6a3")
