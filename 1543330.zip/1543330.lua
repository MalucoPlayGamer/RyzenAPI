-- Lua provided by RyzenAPI
-- Game: 揭谛/GATE

-- MAIN APPLICATION
addappid(1543330)
-- Game: addappid(1543330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543331, 1, "3382943c41ccedd66edda0437224999c93767973110998b8d96f766e81fac122")
