-- Lua provided by RyzenAPI
-- Game: Game: Garenburg Woods Original Soundtrack

-- MAIN APPLICATION
addappid(1763680)
-- Game: addappid(1763680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763681, 1, "0328c2345d65cdb156440784527ec3a61311b225f1922ddda3dd2355c799b9b4")
addappid(1763682, 1, "b3ccc45092cf6c20ef1082ad330b5941d907600a2fb3cea385383deab799d0d6")
