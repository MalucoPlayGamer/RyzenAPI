-- Lua provided by RyzenAPI
-- Game: Cahors Sunset

-- MAIN APPLICATION
addappid(341700)

-- MAIN APP DEPOTS / PACKAGES
addappid(341701, 1, "eb1d7263f913c197865eae202a4dddd3aca2dc178156cfd6727d1c599c683ac5")
