-- Lua provided by RyzenAPI
-- Game: AppID 341700

-- MAIN APPLICATION
addappid(341700)
-- Game: addappid(341700)

-- MAIN APP DEPOTS / PACKAGES
addappid(341701, 1, "eb1d7263f913c197865eae202a4dddd3aca2dc178156cfd6727d1c599c683ac5")
