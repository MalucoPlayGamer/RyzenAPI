-- Lua provided by RyzenAPI
-- Game: addappid(1671670)

-- MAIN APPLICATION
addappid(1671670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671671, 1, "93d26ad4d7fe280279de81f670146bd2fd3b228668e07c21322e1fce5da261dc")
