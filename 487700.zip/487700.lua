-- Lua provided by RyzenAPI
-- Game: Conan the mighty pig

-- MAIN APPLICATION
addappid(487700)

-- MAIN APP DEPOTS / PACKAGES
addappid(487701, 1, "3cca2f0514cbfb6e7fdfccd750116fcf6e57f23ba3a967c93ee257b37871e3ec")

