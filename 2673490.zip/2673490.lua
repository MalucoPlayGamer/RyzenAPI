-- Lua provided by RyzenAPI
-- Game: addappid(2673490)

-- MAIN APPLICATION
addappid(2673490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673491, 1, "0f94cdc3a4df3601fa1b9bcb22b9b9afc4b10750c9367ed30a3793d78beaceae")
