-- Lua provided by SkyAPI 
-- Game: The rebirth of Kingdom Lo
addappid(2345110)
addappid(2345111, 1, "8fc591f4af6840d36df53f320b8a2f9fd1e9463cac44c088535940566d985164")
addappid(2345112, 1, "1833a653aa9848b32c77ef186961151c94b7cda0d83afb2c0755fea7a420f8b0")
