-- Lua provided by RyzenAPI
-- Game: Game: Headshot Roulette

-- MAIN APPLICATION
addappid(3445070)
-- Game: addappid(3445070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445071, 1, "d588c0a044f51222fd4a4a82dc411903ca884797ef088f2e738e3769f25593e4")
