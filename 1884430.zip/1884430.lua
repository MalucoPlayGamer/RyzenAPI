-- Lua provided by RyzenAPI
-- Game: addappid(1884430)

-- MAIN APPLICATION
addappid(1884430)
addappid(1904920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884431, 1, "1da2f62aebf57079977d249f8f8e9c544313f1978e315cbcdafab9f67be768da")
