-- Lua provided by RyzenAPI
-- Game: Case Opener Guns

-- MAIN APPLICATION
addappid(976720)

-- MAIN APP DEPOTS / PACKAGES
addappid(976721, 1, "1586fc42bfa96a34cf8f6168ec8179a71db2c63068799f28290a3a39b4e304de")

