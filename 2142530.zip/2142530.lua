-- Lua provided by RyzenAPI
-- Game: MITTIN: Clean Flat Surfaces

-- MAIN APPLICATION
addappid(2142530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142531, 1, "b6a2a4adc8ab385a799abcfff9f59e80d5615eaae1517becc2bb6ce2e96d22d0")

