-- Lua provided by RyzenAPI
-- Game: MITTIN: Clean Flat Surfaces

-- MAIN APPLICATION
addappid(2142530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2142531, 1, "b6a2a4adc8ab385a799abcfff9f59e80d5615eaae1517becc2bb6ce2e96d22d0")

