-- Lua provided by RyzenAPI
-- Game: 1530130

-- MAIN APPLICATION
addappid(1530130)
-- Game: addappid(1530130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530132,0,"95b02c3a40f572887ba27441cdb7e6f71d23df5c2e0fa150b01513dba7c3ea2c")
