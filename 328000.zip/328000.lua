-- Lua provided by RyzenAPI
-- Game: Dragon Fantasy: The Black Tome of Ice

-- MAIN APPLICATION
addappid(328000)

-- MAIN APP DEPOTS / PACKAGES
addappid(328001, 1, "1cc223ab32fba498621e04a831e3b9e39e4fbb868089c506407df314ca7efbd7")
addappid(328002, 1, "527f85bf75dd18916ed9dc1dd13c88fbdfd1e615b26371433594c5c76f281477")
addappid(328003, 1, "d71889918c672356b3136a0357e9dd9b58bf0327b6b4fc9551cc68ec42ed5437")
