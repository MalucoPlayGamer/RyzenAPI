-- Lua provided by RyzenAPI
-- Game: Game: AppID 348620

-- MAIN APPLICATION
addappid(348620)
addappid(356440)
addappid(356441)
addappid(1094800)
addappid(1094801)
-- Game: addappid(348620)

-- MAIN APP DEPOTS / PACKAGES
addappid(348621, 1, "043a9095543978d6842dbf91c3e6e25e38aee9a9affb72b56b80b7135f10ea6c")
addappid(348622, 1, "2e2640f56f066c525976d646cba8d76fea6a5f3fde75e5f731b24efcd57e70f4")
