-- Lua provided by RyzenAPI
-- Game: Beacon

-- MAIN APPLICATION
addappid(856610)

-- MAIN APP DEPOTS / PACKAGES
addappid(856611, 1, "565716777873134c914f1a5c9ea24ecbbd812729b8e403adf6dffdb21e1414c9")
