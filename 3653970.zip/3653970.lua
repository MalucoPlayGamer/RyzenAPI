-- Lua provided by RyzenAPI
-- Game: Starlight Squad

-- MAIN APPLICATION
addappid(3653970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653971, 1, "694c8306075b35fdbfde3642937b8335659c9a302b32d7754bf4e9b8fae8dce3")

