-- Lua provided by RyzenAPI
-- Game: The Hunting God

-- MAIN APPLICATION
addappid(679190)

-- MAIN APP DEPOTS / PACKAGES
addappid(679191, 1, "211bb92c8bf0f0d22954beb092e6f6fcbf287f5999fe4bc06b2e15d345d899f0")
