-- Lua provided by RyzenAPI
-- Game: Storms II

-- MAIN APPLICATION
addappid(1731470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731471, 1, "6cd3b2bbd9e74d311b1d4375c42c6d7540b9227e5c2ec50dcfefc18efe3596bb")
