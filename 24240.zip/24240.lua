-- Lua provided by RyzenAPI
-- Game: Game: PAYDAY™ The Heist

-- MAIN APPLICATION
addappid(24240)
-- Game: addappid(24240)

-- MAIN APP DEPOTS / PACKAGES
addappid(24241, 1, "a602a31a94e7553b0b0a533ad02c5c1f2e84da1129754b46bc821d21f04520a6")
addappid(24242, 1, "1e11b3e02fd9958654467f0c4eda4d8e688d48e11f01ea44b6ce09287379e272")
addappid(24243, 1, "774b5a5f4d57d8f8b9d664bee7e07688f2240a93e9cd6a49a89e027ba59f6c8f")
addappid(24244, 1, "4d70891f8353ee87ab44382c74faaae8ab29c1d0fcdebcc74b0574a1c54c021c")
addappid(24245, 1, "eaca6d5ad9527186f73dffc20a5ad80636d5ef96098a6f0ff334cf48b06cb550")
addappid(24246, 1, "6622b2db642dbba02f767cf4ac9ad5b0d26744c53cf7e38f40e24386ae4e4db9")
addappid(207816, 0, "622cef2b5e416fb0c2b9ce205c28a38ea0c2e226d356b410046f2c6fd22d2e3d")
