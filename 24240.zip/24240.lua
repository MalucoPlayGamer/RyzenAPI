-- Lua provided by RyzenAPI
-- Game: PAYDAY™ The Heist

-- MAIN APPLICATION
addappid(24240)
addappid(207810)
addappid(207811)
addappid(207812)
addappid(207813)
addappid(207814)
addappid(207815)

-- MAIN APP DEPOTS / PACKAGES
addappid(24241, 1, "a602a31a94e7553b0b0a533ad02c5c1f2e84da1129754b46bc821d21f04520a6")
addappid(24242, 1, "1e11b3e02fd9958654467f0c4eda4d8e688d48e11f01ea44b6ce09287379e272")
addappid(24243, 1, "774b5a5f4d57d8f8b9d664bee7e07688f2240a93e9cd6a49a89e027ba59f6c8f")
addappid(24244, 1, "4d70891f8353ee87ab44382c74faaae8ab29c1d0fcdebcc74b0574a1c54c021c")
addappid(24245, 1, "eaca6d5ad9527186f73dffc20a5ad80636d5ef96098a6f0ff334cf48b06cb550")
addappid(24246, 1, "6622b2db642dbba02f767cf4ac9ad5b0d26744c53cf7e38f40e24386ae4e4db9")
addappid(207816, 0, "622cef2b5e416fb0c2b9ce205c28a38ea0c2e226d356b410046f2c6fd22d2e3d")
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)

