-- Lua provided by RyzenAPI
-- Game: 1088670

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1088670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088672,0,"11569b5619af2065d8c7db236adda444b9a8d8df6e3134ca8ad12ac915a2dca0")
