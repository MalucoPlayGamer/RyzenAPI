-- Lua provided by RyzenAPI
-- Game: The Ramen Sensei

-- MAIN APPLICATION
addappid(1918540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918541, 1, "11b06e31bd2ce947dbc2d943d6e973ae90926e7bed06a687ab4580d7396b42e2")
