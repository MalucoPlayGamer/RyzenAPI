-- Lua provided by RyzenAPI
-- Game: AppID 661590

-- MAIN APPLICATION
addappid(661590)

-- MAIN APP DEPOTS / PACKAGES
addappid(661591, 1, "8f0433ab9dec56c78de49ae8a8338ee46ad23ca627c7083a2c22dea5ad88cc90")

