-- Lua provided by RyzenAPI
-- Game: Game: 3D Controller Overlay

-- MAIN APPLICATION
addappid(1951950)
-- Game: addappid(1951950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951951, 1, "0de9f1d7703dece32e06f930e2a162d5f5c6b6f25958b873db33f5c6d45ee782")
