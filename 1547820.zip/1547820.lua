-- Lua provided by RyzenAPI
-- Game: Game: TOP TRUCK DRIVER

-- MAIN APPLICATION
addappid(1547820)
-- Game: addappid(1547820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547821, 1, "95d71f663c0471c53fc4ba5aa53e7acbbb57447651f91d79dd02b3445609968b")
