-- Lua provided by RyzenAPI
-- Game: World War Zero

-- MAIN APPLICATION
addappid(1103800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103801, 1, "73203e8a2ed7bf9e96f8a684577100c0bd0f2f97ed0f01672d7d709c58344998")
