-- Lua provided by RyzenAPI
-- Game: 2692300

-- MAIN APPLICATION
addappid(2692300)
-- Game: addappid(2692300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692301, 1, "ba0627fe7d41e311184506a3b68c14192b82a48bc0ea934f20b26e55bc4b7ef2")
