-- Lua provided by RyzenAPI
-- Game: End of Realm Legends

-- MAIN APPLICATION
addappid(2724660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724661, 1, "ae4d04fa13b48163311373a5b08580d51ed00725e56974e34b36f086ca252efb")

