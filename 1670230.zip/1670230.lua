-- Lua provided by RyzenAPI 
-- Game: 文字三国
addappid(1670230)
addappid(1670231, 1, "289a537b0e91071a33e6556fc376b1d37fd75707250001225ca957ef8ae131a9")
