-- Lua provided by RyzenAPI
-- Game: Game: 文字三国

-- MAIN APPLICATION
addappid(1670230)
-- Game: addappid(1670230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670231, 1, "289a537b0e91071a33e6556fc376b1d37fd75707250001225ca957ef8ae131a9")
