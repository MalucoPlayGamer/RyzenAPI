-- Lua provided by RyzenAPI
-- Game: Supermarket Bash

-- MAIN APPLICATION
addappid(2477280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477288,0,"b7f0372c5424a86ca0cb1e09baaec22b77baed282c0b56b50d15aa8fcd25dd34")

