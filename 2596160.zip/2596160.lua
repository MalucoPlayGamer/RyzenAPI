-- Lua provided by RyzenAPI
-- Game: addappid(2596160)

-- MAIN APPLICATION
addappid(2596160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596161, 1, "b483002ba3a8c495b2804bea2e7860aecda26350682ee39c5dd10bbb752e7d16")
