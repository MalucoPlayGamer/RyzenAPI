-- Lua provided by SkyAPI 
-- Game: DarkEnd
addappid(292370)
addappid(292371, 1, "46141206b4aa838f1134e85462afc89f88141638012de2170a6c8e0342b57bea")
