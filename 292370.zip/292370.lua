-- Lua provided by RyzenAPI
-- Game: DarkEnd

-- MAIN APPLICATION
addappid(292370)
-- Game: addappid(292370)

-- MAIN APP DEPOTS / PACKAGES
addappid(292371, 1, "46141206b4aa838f1134e85462afc89f88141638012de2170a6c8e0342b57bea")
