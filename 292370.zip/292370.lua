-- Lua provided by RyzenAPI
-- Game: DarkEnd

-- MAIN APPLICATION
addappid(292370)

-- MAIN APP DEPOTS / PACKAGES
addappid(292371, 1, "46141206b4aa838f1134e85462afc89f88141638012de2170a6c8e0342b57bea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
