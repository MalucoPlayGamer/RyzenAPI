-- Lua provided by RyzenAPI
-- Game: addappid(3734730)

-- MAIN APPLICATION
addappid(3734730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3734730,0,"2b2ea532bbec038cb97389340ca1d3320faf03f3a941f5dbb949b11893b2ce28")
