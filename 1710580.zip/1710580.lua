-- Lua provided by RyzenAPI
-- Game: MotoGP™22

-- MAIN APPLICATION
addappid(1710580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710581, 1, "f6e8c38bef29f5559860475cbb0db2c258a195c4a4673cc63f0b2830b696027a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1876100)
addappid(1876110)
