-- Lua provided by RyzenAPI
-- Game: Game: MotoGP™22

-- MAIN APPLICATION
addappid(1710580)
-- Game: addappid(1710580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710581, 1, "f6e8c38bef29f5559860475cbb0db2c258a195c4a4673cc63f0b2830b696027a")
