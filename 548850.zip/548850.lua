-- Lua provided by RyzenAPI
-- Game: 548850

-- MAIN APPLICATION
addappid(548850)
-- Game: addappid(548850)

-- MAIN APP DEPOTS / PACKAGES
addappid(548851, 1, "e79c9606cc0b4fd84fc71518e528b468f0a5bf2ca955da07591a8a59f38b4642")
