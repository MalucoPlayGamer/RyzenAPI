-- Lua provided by RyzenAPI
-- Game: Commander Keen

-- MAIN APPLICATION
addappid(9180)

-- MAIN APP DEPOTS / PACKAGES
addappid(9181, 1, "8165b38d55b9476044ed2e1776bbc2c2d7824a3dbea672ce5279da46253b7005")
