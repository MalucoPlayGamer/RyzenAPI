-- Lua provided by RyzenAPI 
-- Game: The Longest Road on Earth
addappid(1295790)
addappid(1295791, 1, "03b2bc1a6063ce701a5107c3f4f8f914e736cd95ba77f66581c24676034d4d84")
addappid(1623740, 0, "366f95ae34c1fcfe01dd909691e227cbbf872c96b4b41bcfac9e3e884454cf14")
addappid(1634510, 0, "49507baaa76d08b553ca395897fe09ce8761e7938879a57c291d1f5b5cd0b2a0")
