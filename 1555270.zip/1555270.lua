-- Lua provided by RyzenAPI
-- Game: AppID 1555270

-- MAIN APPLICATION
addappid(1555270)
-- Game: addappid(1555270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555271, 1, "d00bc0bafc3ee7cee0c8fe72412a01e879c1b61503d16935ca22f41aafa5ee53")
