-- Lua provided by RyzenAPI
-- Game: AppID 858360

-- MAIN APPLICATION
addappid(858360)

-- MAIN APP DEPOTS / PACKAGES
addappid(858361, 1, "d725d31fb84e94c13b04c2d6c4a8e477e6fbb19268a49f920ce4032ddbe2e16c")
