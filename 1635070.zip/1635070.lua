-- Lua provided by RyzenAPI
-- Game: Motesolo : Original Sountrack

-- MAIN APPLICATION
addappid(1635070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635071, 1, "456ef9e4293f7c95f0cedff33669256df2da68f6c0a55aa5c2a16eb2b3534c59")
addappid(1635072, 1, "1898266fb5733b393bbd6e12e045cc6425cff892eb53dc3ce3104debdb75837e")
