-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Regicide

-- MAIN APPLICATION
addappid(322910)

-- MAIN APP DEPOTS / PACKAGES
addappid(322911,0,"649aa1e6bfd34973ae33f260f27e294cc01a99764373e8a932cd9b6e8451f2ce")

