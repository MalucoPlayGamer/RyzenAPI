-- Lua provided by RyzenAPI
-- Game: 1825720

-- MAIN APPLICATION
addappid(1825720)
-- Game: addappid(1825720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825721, 1, "d99d04f0c93c38392092a14fb530bdc2fdbb350c1bb406e6903c6a16b3ab8006")
