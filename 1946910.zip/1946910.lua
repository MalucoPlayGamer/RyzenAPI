-- Lua provided by RyzenAPI
-- Game: 1946910

-- MAIN APPLICATION
addappid(1946910)
-- Game: addappid(1946910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946911, 1, "76b53776ace9a258e9716df33c1434d6592c289da36f7c14d42a98858aaea465")
