-- Lua provided by RyzenAPI
-- Game: Keep Keepers

-- MAIN APPLICATION
addappid(2354330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2354331, 1, "db03d29f1134721ea3255554cdd1a3845c31edb2305f0107597fae087a68c70b")

