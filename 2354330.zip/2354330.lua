-- Lua provided by RyzenAPI
-- Game: 2354330

-- MAIN APPLICATION
addappid(2354330)
-- Game: addappid(2354330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354331, 1, "db03d29f1134721ea3255554cdd1a3845c31edb2305f0107597fae087a68c70b")
