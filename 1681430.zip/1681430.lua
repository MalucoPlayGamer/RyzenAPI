-- Lua provided by RyzenAPI
-- Game: addappid(1681430)

-- MAIN APPLICATION
addappid(1681430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681431, 1, "9df4746c06e6c3240fdbbb7fafdc7ee3d4461387c34371ffcf2a5db0ac571b27")
