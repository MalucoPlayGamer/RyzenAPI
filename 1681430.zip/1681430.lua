-- Lua provided by RyzenAPI
-- Game: RoboCop: Rogue City

-- MAIN APPLICATION
addappid(1681430)
addappid(2436840)
addappid(2436841)
addappid(2436842)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1681431, 1, "9df4746c06e6c3240fdbbb7fafdc7ee3d4461387c34371ffcf2a5db0ac571b27")

