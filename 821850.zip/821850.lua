-- Lua provided by RyzenAPI
-- Game: OldFactory

-- MAIN APPLICATION
addappid(821850)

-- MAIN APP DEPOTS / PACKAGES
addappid(821851, 1, "ee55ff78f74481a63ab555afe26ec69c0f0a7d49504708098eda454295e2bff1")

