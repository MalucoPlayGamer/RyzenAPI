-- Lua provided by RyzenAPI
-- Game: Acaratus

-- MAIN APPLICATION
addappid(376410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(376411, 1, "2a9d017540944b9581852dec1db374cecb751303ea3ccc716231767ccf497436")
addappid(376412, 1, "7b601d5dcb7414e4a3be4784ce1b88d90454caeeaf3ce8db45398d0e54a98629")
addappid(449080, 0, "a6e4597dbf97c04631c612121aad4f09fb508b91cd03e186a4d9cc4959883d5e")
