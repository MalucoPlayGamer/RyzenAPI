-- Lua provided by RyzenAPI
-- Game: AppID 1365760

-- MAIN APPLICATION
addappid(1365760)
-- Game: addappid(1365760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365761, 1, "8660d16c840a123c540bdc5075ec9bd6436ad57f156aadb39222aa016fb3db6d")
addappid(1365762, 1, "6e6c4e3f0a29a2676e61e91549ae9ce04d2bd3782da105ba912fc5c5a5cc3f9e")
addappid(1365763, 1, "ed29abf79966a3b79df3b325f318d6a8c7ea99cf064251d1664b3ccfb4746733")
