-- Lua provided by RyzenAPI
-- Game: DFF NT: Golden Sword / Omnirod / Kiku-ichimonji, O. Knight's 4th Weap.

-- MAIN APPLICATION
addappid(1022411)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022411,0,"5b1ab6078c9289d50d9ba8a49b0bca9a7f25406de4d1a03f9abb19585ad98a5e")

