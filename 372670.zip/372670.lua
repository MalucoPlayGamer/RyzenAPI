-- Lua provided by RyzenAPI
-- Game: 372670

-- MAIN APPLICATION
addappid(372670)
-- Game: addappid(372670)

-- MAIN APP DEPOTS / PACKAGES
addappid(372671, 1, "305f79aed15b835de079524b7244ca31bdba6af3b81b94e8183e18200af1406a")
