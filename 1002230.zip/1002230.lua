-- Lua provided by RyzenAPI
-- Game: AppID 1002230

-- MAIN APPLICATION
addappid(1002230)
-- Game: addappid(1002230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002231, 1, "2fcb3245ce734176719313e1286ed8bc64b1a98d31bf77afcc8798eef1496499")
addappid(1002232, 1, "3eacc38ae3dc3b62b1029363da3f71238186da142629bb469ccefa6244fac0d0")
