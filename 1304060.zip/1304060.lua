-- Lua provided by RyzenAPI
-- Game: 1304060

-- MAIN APPLICATION
addappid(1304060)
-- Game: addappid(1304060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304061, 1, "95afbe406cdb0620e293567de1e4276f5b90667176d2c7d96ee6ece452d210da")
addappid(1305410, 0, "f4e8cfce47761da18c8413f6f9093708660bcd9aa8fcca44b7fcf53058a17b6e")
