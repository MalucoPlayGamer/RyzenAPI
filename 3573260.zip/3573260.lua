-- Lua provided by RyzenAPI
-- Game: Lucky Hero Wanted

-- MAIN APPLICATION
addappid(3573260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573261, 1, "e55f3ac5309304b6c78add4f3abb655f31a2e10ddbb5590d0591d280fa4d7d32")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
