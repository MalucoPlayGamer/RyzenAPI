-- Lua provided by RyzenAPI
-- Game: Lucky Hero Wanted

-- MAIN APPLICATION
addappid(3573260)
-- Game: addappid(3573260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573261, 1, "e55f3ac5309304b6c78add4f3abb655f31a2e10ddbb5590d0591d280fa4d7d32")
