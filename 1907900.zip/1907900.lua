-- Lua provided by RyzenAPI
-- Game: Halftime Heroes

-- MAIN APPLICATION
addappid(1907900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907901, 1, "b5cca373dcca4b59a84eb5fe9194f1fe03369f5b8338c79ebc7818eb0644b6ec")
