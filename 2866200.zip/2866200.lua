-- Lua provided by RyzenAPI
-- Game: Game: SYMMETRIC;VISION Demo

-- MAIN APPLICATION
addappid(2866200)
-- Game: addappid(2866200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866201, 1, "4bb5fa46fd4f48044c80910c10da60daf4accc49934b28d63d1fa7da30d25906")
