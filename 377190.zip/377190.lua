-- Lua provided by RyzenAPI
-- Game: addappid(377190)

-- MAIN APPLICATION
addappid(377190)

-- MAIN APP DEPOTS / PACKAGES
addappid(377191, 1, "8e7f415c7c67f704735325f16f28e83e3aa96ddf37966c60c15072cc2215cdb9")
