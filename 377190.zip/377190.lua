-- Lua provided by RyzenAPI
-- Game: Pale Echoes

-- MAIN APPLICATION
addappid(377190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(377191, 1, "8e7f415c7c67f704735325f16f28e83e3aa96ddf37966c60c15072cc2215cdb9")

