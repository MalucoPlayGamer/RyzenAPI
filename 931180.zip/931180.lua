-- Lua provided by RyzenAPI
-- Game: Conan Exiles - Public Beta Client

-- MAIN APPLICATION
addappid(931180)

-- MAIN APP DEPOTS / PACKAGES
addappid(931181, 1, "148be429147b66017ae568eff3a28fe80d384e6ea1a6e48d2ec0cc6711e6ffd2")
addappid(931182, 1, "80f7f1f6004dc0278bdeb3d0cc5cd1a191127c0668f5e02325e1769fe4f29c40")
addappid(931183, 1, "e25c2382fde91bd8cfe90d79598b8fec9b3de056d030df03a576a64a0e155e93")

