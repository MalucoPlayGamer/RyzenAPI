-- Lua provided by RyzenAPI
-- Game: Game: The Miskatonic

-- MAIN APPLICATION
addappid(870290)
-- Game: addappid(870290)

-- MAIN APP DEPOTS / PACKAGES
addappid(870291, 1, "784fa89dcbde66c1a08f5a2dacbcaef45167476c1a41b4d1077941cb7f20020b")
