-- Lua provided by RyzenAPI
-- Game: The Hurt in Secret

-- MAIN APPLICATION
addappid(1591910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591912,0,"cbb5edbb1ca17541ea2a3c89be533d55b014ef84c52372b1c9f5e77e508690fc")
addappid(1591913,0,"b59f0fc775cdb0119e15e82e6654300b63d080b17279ecd42713045d4ae467f5")

