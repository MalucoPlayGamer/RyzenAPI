-- Lua provided by RyzenAPI
-- Game: Abathor - Atlantis Landing

-- MAIN APPLICATION
addappid(2358610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358611, 1, "2714c4ef15a3df67cf2d74637d9ffd03c44ad812ce629eea48d585f7b1f3faa2")

