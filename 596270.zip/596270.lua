-- Lua provided by RyzenAPI
-- Game: Tales of Terror: Crimson Dawn

-- MAIN APPLICATION
addappid(596270)

-- MAIN APP DEPOTS / PACKAGES
addappid(596271,0,"8ebed5b83a4a6280b036f07e7fa82ecb5321a97f407f27b4a12c93219b0e5ab4")

