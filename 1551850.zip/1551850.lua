-- Lua provided by RyzenAPI
-- Game: AppID 1551850

-- MAIN APPLICATION
addappid(1551850)
-- Game: addappid(1551850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551851, 1, "e8b21ed30722b6033d2e0ecbd83bd37a0f69572a15dfcb0dd134dfd7753ffb79")
