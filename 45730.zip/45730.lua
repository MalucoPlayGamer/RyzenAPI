-- Lua provided by RyzenAPI
-- Game: Dark Void Zero

-- MAIN APPLICATION
addappid(45730)

-- MAIN APP DEPOTS / PACKAGES
addappid(45731, 1, "6c4066ab584629c6e5563143463c81d76ace9df08ceb7bd3f1f2e541195d22e5")
