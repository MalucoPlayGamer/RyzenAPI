-- Lua provided by RyzenAPI
-- Game: Inventioneers

-- MAIN APPLICATION
addappid(395580)

-- MAIN APP DEPOTS / PACKAGES
addappid(395582,0,"2385a4fb310cd4eb3021fdd62212d1e02e2bf7570fdf69962361ed8ecc47a106")
