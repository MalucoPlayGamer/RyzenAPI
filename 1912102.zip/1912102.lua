-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Okurikara"

-- MAIN APPLICATION
addappid(1912102)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912102,0,"8c6b1b1ec44287a450b09cc2194a3b963d19c2a3a56ab6de3979aa2b38e9e9b4")
