-- Lua provided by RyzenAPI
-- Game: Titanium Raiders

-- MAIN APPLICATION
addappid(3441820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441821, 1, "39b2abb1d66275f8894d40a426a9de59642f06e155235efa8abc3d6e8b17d4ab")
