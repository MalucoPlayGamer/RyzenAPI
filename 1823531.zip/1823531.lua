-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Japanese Modern Cityscape Tileset

-- MAIN APPLICATION
addappid(1823531)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823531,0,"fe2d4766c903c4c729b44bfb46336ac4262cb61aeb1622ee3bd0fdec94362231")
