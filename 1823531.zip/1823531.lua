-- Lua provided by RyzenAPI
-- Game: 1823531

-- MAIN APPLICATION
addappid(1823531)
-- Game: addappid(1823531)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823531,0,"fe2d4766c903c4c729b44bfb46336ac4262cb61aeb1622ee3bd0fdec94362231")
