-- Lua provided by RyzenAPI
-- Game: addappid(2994880)

-- MAIN APPLICATION
addappid(2994880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994881, 1, "269168fb3208f320727ee51fd74cecea578840ab62eedc110732134d09e9f29f")
