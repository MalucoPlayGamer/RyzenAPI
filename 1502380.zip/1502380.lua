-- Lua provided by RyzenAPI
-- Game: AppID 1502380

-- MAIN APPLICATION
addappid(1502380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502381, 1, "3bfd5befbbd54133f5993ff7301a88613a5c52275a04a0729e3b8f6366d1a432")
addappid(1502382, 1, "64fd7546bf3da78165d94275f48ce5e6e98c7c5306215b3b7963a262d3063aa2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1502390)
