-- Lua provided by SkyAPI 
-- Game: Bounty Hunter: Space Detective
addappid(827270)
addappid(827271, 1, "f9eb799896298e3b60e6a1c6f30d93e30db1c7d258c77639dd9da9bc93077ca7")
