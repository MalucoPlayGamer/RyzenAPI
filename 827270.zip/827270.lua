-- Lua provided by RyzenAPI
-- Game: Bounty Hunter: Space Detective

-- MAIN APPLICATION
addappid(827270)
addappid(1405210)
addappid(1405211)
addappid(1405212)
addappid(1405213)
addappid(1405214)
addappid(1405215)
addappid(1405216)
addappid(1405217)
addappid(1405218)
addappid(1405219)

-- MAIN APP DEPOTS / PACKAGES
addappid(827271,0,"f9eb799896298e3b60e6a1c6f30d93e30db1c7d258c77639dd9da9bc93077ca7")

