-- Lua provided by RyzenAPI
-- Game: Game: Bounty Hunter: Space Detective

-- MAIN APPLICATION
addappid(827270)
-- Game: addappid(827270)

-- MAIN APP DEPOTS / PACKAGES
addappid(827271, 1, "f9eb799896298e3b60e6a1c6f30d93e30db1c7d258c77639dd9da9bc93077ca7")
