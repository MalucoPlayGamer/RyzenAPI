-- Lua provided by RyzenAPI
-- Game: DEPLOYMENT

-- MAIN APPLICATION
addappid(755980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(755981, 1, "d52554f5bc1717a5d6838fbd1426b2d5ced9f2f46e1258d8f411eafaf43dd2d5")

