-- Lua provided by RyzenAPI
-- Game: DEPLOYMENT

-- MAIN APPLICATION
addappid(755980)

-- MAIN APP DEPOTS / PACKAGES
addappid(755981, 1, "d52554f5bc1717a5d6838fbd1426b2d5ced9f2f46e1258d8f411eafaf43dd2d5")
