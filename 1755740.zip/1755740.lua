-- Lua provided by RyzenAPI
-- Game: addappid(1755740)

-- MAIN APPLICATION
addappid(1755740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755741, 1, "16efcda00d4c8b6547aea3859302f7ad2894d73063ee5fcaaf34fc8769d346c2")
