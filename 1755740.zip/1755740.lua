-- Lua provided by SkyAPI 
-- Game: 侵入：源代码
addappid(1755740)
addappid(1755741, 1, "16efcda00d4c8b6547aea3859302f7ad2894d73063ee5fcaaf34fc8769d346c2")
