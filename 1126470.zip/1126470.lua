-- Lua provided by RyzenAPI
-- Game: AppID 1126470

-- MAIN APPLICATION
addappid(1126470)
-- Game: addappid(1126470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126471, 1, "33db0f00b2b5ffcc2f8fa4a6c60e3709f017abe50193ccf3aa9e0b03cff61d46")
