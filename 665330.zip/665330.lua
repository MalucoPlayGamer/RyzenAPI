-- Lua provided by RyzenAPI
-- Game: Game: Wrestling Revolution 3D

-- MAIN APPLICATION
addappid(665330)
-- Game: addappid(665330)

-- MAIN APP DEPOTS / PACKAGES
addappid(665331, 1, "982d822012616b6d0b4d6a9b00d80cde5d4bcd241a24609093c23930755c20ff")
