-- Lua provided by RyzenAPI
-- Game: Touhou Shinreibyou ~ Ten Desires.

-- MAIN APPLICATION
addappid(1043230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043231, 1, "d7289c7ab12efb7ba36f6c5473ff0b480eadb59ddd5814e893ff0d977652bf67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
