-- Lua provided by RyzenAPI
-- Game: Touhou Shinreibyou ~ Ten Desires.

-- MAIN APPLICATION
addappid(1043230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043231, 1, "d7289c7ab12efb7ba36f6c5473ff0b480eadb59ddd5814e893ff0d977652bf67")
