-- Lua provided by RyzenAPI
-- Game: addappid(1988810)

-- MAIN APPLICATION
addappid(1988810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988812,0,"5d998dcfd74a55bb61618f591e34652ba760f5935dec8c06a463c83c18deee30")
