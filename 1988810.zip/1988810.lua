-- Lua provided by RyzenAPI
-- Game: BCI VR Horror Attraction: The Mad Trail

-- MAIN APPLICATION
addappid(1988810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988812,0,"5d998dcfd74a55bb61618f591e34652ba760f5935dec8c06a463c83c18deee30")

