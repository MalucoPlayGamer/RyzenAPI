-- Lua provided by RyzenAPI
-- Game: 2820430

-- MAIN APPLICATION
addappid(2820430)
-- Game: addappid(2820430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820431, 1, "59fc48db5f9775f7596cf6a53c9a5e6aa0aa6f63a0f3ee885161d13509c53f3b")
