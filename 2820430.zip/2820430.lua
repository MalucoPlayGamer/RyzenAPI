-- Lua provided by SkyAPI 
-- Game: AppID 2820430
addappid(2820430)
addappid(2820431, 1, "59fc48db5f9775f7596cf6a53c9a5e6aa0aa6f63a0f3ee885161d13509c53f3b")
