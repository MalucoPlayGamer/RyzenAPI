-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Incest Family - Episode 2

-- MAIN APPLICATION
addappid(3484130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484131, 1, "bc5d4a115cc36d9da71367a2c3b45ce107423250b2be56af81a08eb23edef2ed")
