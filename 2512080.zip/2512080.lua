-- Lua provided by RyzenAPI
-- Game: Game: DDI Rally Championship

-- MAIN APPLICATION
addappid(2512080)
-- Game: addappid(2512080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512081, 1, "5d51e71a943bcca30baef6bbb5d9cf3aee7aa16907d447481305100f7e739bbf")
