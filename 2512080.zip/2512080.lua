-- Lua provided by SkyAPI 
-- Game: DDI Rally Championship
addappid(2512080)
addappid(2512081, 1, "5d51e71a943bcca30baef6bbb5d9cf3aee7aa16907d447481305100f7e739bbf")
