-- Lua provided by RyzenAPI
-- Game: 2994790

-- MAIN APPLICATION
addappid(2994790)
-- Game: addappid(2994790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994791, 1, "5c060538a93c66aebe2e3b0e02eb8cddde3bebcdccee9dcc7017794cadcc0046")
