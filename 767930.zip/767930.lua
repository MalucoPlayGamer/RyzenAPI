-- Lua provided by RyzenAPI
-- Game: AppID 767930

-- MAIN APPLICATION
addappid(767930)

-- MAIN APP DEPOTS / PACKAGES
addappid(767931, 1, "cabe9f2a15d79da0de3969c5cf2014fb1ab888cd15f5cf0e8eb3a1cd45aee15a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
