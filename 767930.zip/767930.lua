-- Lua provided by RyzenAPI
-- Game: 767930

-- MAIN APPLICATION
addappid(767930)
-- Game: addappid(767930)

-- MAIN APP DEPOTS / PACKAGES
addappid(767931, 1, "cabe9f2a15d79da0de3969c5cf2014fb1ab888cd15f5cf0e8eb3a1cd45aee15a")
