-- Lua provided by RyzenAPI
-- Game: addappid(2003370)

-- MAIN APPLICATION
addappid(2003370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003371, 1, "e7e5915b960ea66d9ac4f7f3f1ba6e6aebaee552313c50036b0730ee9848cdf7")
