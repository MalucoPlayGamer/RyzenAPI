-- Lua provided by RyzenAPI
-- Game: Match Village

-- MAIN APPLICATION
addappid(2003370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003371, 1, "e7e5915b960ea66d9ac4f7f3f1ba6e6aebaee552313c50036b0730ee9848cdf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
