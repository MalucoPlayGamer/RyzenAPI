-- Lua provided by RyzenAPI
-- Game: Game: Neko Dating Sim

-- MAIN APPLICATION
addappid(2191020)
-- Game: addappid(2191020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191021, 1, "3627ffba6c4ffcf92904ab4401f8918c9f7a9ef0a085a260de6d28370858aa00")
