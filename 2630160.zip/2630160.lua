-- Lua provided by RyzenAPI
-- Game: Game: VR SecretRoom

-- MAIN APPLICATION
addappid(2630160)
-- Game: addappid(2630160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630161, 1, "deaa22a5652faae8a90dc8dff1fe78883ddfd547bf79ed144681d645a18e34a0")
