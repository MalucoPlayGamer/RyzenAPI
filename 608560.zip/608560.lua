-- Lua provided by RyzenAPI
-- Game: addappid(608560)

-- MAIN APPLICATION
addappid(608560)

-- MAIN APP DEPOTS / PACKAGES
addappid(608561, 1, "f56273c9127be4f51e778eb5afa1f11ee729ff1b489057270ca931d931a07394")
