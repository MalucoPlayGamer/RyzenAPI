-- Lua provided by RyzenAPI
-- Game: 40710

-- MAIN APPLICATION
addappid(40710)
-- Game: addappid(40710)

-- MAIN APP DEPOTS / PACKAGES
addappid(40711, 1, "62117092bc783a2776a35f491ab04dd476ca98899993691a90c625e0a8bdc565")
