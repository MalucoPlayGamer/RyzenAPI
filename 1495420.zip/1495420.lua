-- Lua provided by RyzenAPI
-- Game: Dragon Creek

-- MAIN APPLICATION
addappid(1495420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495421, 1, "3692aa81241b48cb970cb654005aad4e162e461b12636a32940aff5c16392571")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
