-- Lua provided by RyzenAPI
-- Game: Dragon Creek

-- MAIN APPLICATION
addappid(1495420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495421, 1, "3692aa81241b48cb970cb654005aad4e162e461b12636a32940aff5c16392571")

