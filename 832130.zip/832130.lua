-- Lua provided by RyzenAPI
-- Game: AppID 832130

-- MAIN APPLICATION
addappid(832130)

-- MAIN APP DEPOTS / PACKAGES
addappid(832131, 1, "d3f212f59b3b1175ea54a0a586653f9009d544bf3fccb47a2decfd29970aa8df")
addappid(832132, 1, "6f3744e2e8709cd0c6e61b337f48c420826e1f6d4449cb5ebfc01ae413db53a2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(925410)
