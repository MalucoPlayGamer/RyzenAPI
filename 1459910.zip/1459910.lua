-- Lua provided by RyzenAPI
-- Game: Isolomus

-- MAIN APPLICATION
addappid(1459910)
-- Game: addappid(1459910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459911, 1, "3247ec888ce47f6720518f84e185a7f38b2e91e7d83754b506e60c04198b4396")
addappid(1459912, 1, "af4908665f0d589d8f8711f0fa7e26fc65baad0c5ab385d6f8e914919b739e3e")
addappid(1459913, 1, "ed7ea8abdf1f2288a3dd2fa33b27648416c30b273d364d9924f0a2bb7d4bf1fa")
