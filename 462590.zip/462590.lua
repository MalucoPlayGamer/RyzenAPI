-- Lua provided by RyzenAPI
-- Game: Game: Taekwondo Grand Prix

-- MAIN APPLICATION
addappid(462590)
-- Game: addappid(462590)

-- MAIN APP DEPOTS / PACKAGES
addappid(462591, 1, "beeda4cbd3fe7ad0cd4023f50ceffa9d9b740e565863980282cfce58d53f9f63")
