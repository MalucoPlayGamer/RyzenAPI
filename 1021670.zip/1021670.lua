-- Lua provided by RyzenAPI
-- Game: addappid(1021670)

-- MAIN APPLICATION
addappid(1021670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021671, 1, "70986b5c5635c515d5f020b13f7defadf450698e26ed18ad8616c56bf9ee6131")
