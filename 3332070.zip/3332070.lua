-- Lua provided by RyzenAPI 
-- Game: Dark Fantasy Godhood
addappid(3332070)
addappid(3332071, 1, "7453509549d26be4acd78d2322911079f100e81b334c17dcdb0b8f20e47d5b44")
