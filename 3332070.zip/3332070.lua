-- Lua provided by RyzenAPI
-- Game: Game: Dark Fantasy Godhood

-- MAIN APPLICATION
addappid(3332070)
-- Game: addappid(3332070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332071, 1, "7453509549d26be4acd78d2322911079f100e81b334c17dcdb0b8f20e47d5b44")
