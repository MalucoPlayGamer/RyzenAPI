-- Lua provided by RyzenAPI
-- Game: Nono's magic general shop

-- MAIN APPLICATION
addappid(882670)

-- MAIN APP DEPOTS / PACKAGES
addappid(882671,0,"8796720ea22ead0bf7830e49b2b0213206d7e49594937d0f5bf75c1d0b3969df")
addappid(882672,0,"e80261ef5fb1f3ed93cd2c813d8febe07cf3d91265ad7c183d55c8661986dd48")
addappid(882674,0,"4d3552d3c41ef2bf118fd6ef0117ac0430093ccec9de171edd27477bf8bb95de")
addappid(951350,0,"95bd1667f643614bcd178b519cb9f49b45c85519d7dc075258162fde6be6591e")

