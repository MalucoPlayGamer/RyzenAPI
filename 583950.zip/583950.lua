-- Lua provided by RyzenAPI
-- Game: Artifact

-- MAIN APPLICATION
addappid(583950)

-- MAIN APP DEPOTS / PACKAGES
addappid(583951, 1, "44cf11603f949972e31fe24cdc5401bfffa9d026aa074047a58abcf21b0137e2")
addappid(583952, 1, "f5288e34429d58c20857f5c98f021d69901f532a2c6652c90252fade8aaa9dc3")
addappid(583953, 1, "3ebea02adc253e26ed3fece95b5c139a93d71e2a1eed86d6f58c6901c62c55b9")
addappid(583954, 1, "acab588cedafd18c0baf446724887fa20585b9f8dd70c775706f68cf92ab9cd1")
addappid(583955, 1, "13f2e922bb34ea5ad84265bad66b7ca2c15471dc59cc3df721f225d8b47f3baf")
addappid(583956, 1, "eceaba800b84b7c58d254c17e8e0e41214b04703fd84236d90df4d8ef6be4474")
