-- Lua provided by RyzenAPI
-- Game: Believr Pro Wrestling

-- MAIN APPLICATION
addappid(4174130)

-- MAIN APP DEPOTS / PACKAGES
addappid(4174131,0,"bc8a213005b0644e05614075a61299ebfe7c5a9859b2d92025e83c9f6353ebe5")

