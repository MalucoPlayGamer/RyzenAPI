-- Lua provided by RyzenAPI 
-- Game: Touhou: Lost Branch of Legend
addappid(1140150)
addappid(1140151, 1, "50615b31d57243ccab3116b85ab46fe01d860584a3a8ede2bde1362d2d581cc1")
addappid(1140152, 1, "c946bb7206279356b9b1a03620110ce4f354d253b4664f59f1f00da7e61b79ee")
