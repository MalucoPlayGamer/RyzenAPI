-- Lua provided by RyzenAPI
-- Game: Solys Playtest

-- MAIN APPLICATION
addappid(1692440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692441, 1, "72ce63b12fb130d8736f9c7c30628ba57e986244609ec6c692686cbf3cca3454")
