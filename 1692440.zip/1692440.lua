-- Lua provided by RyzenAPI 
-- Game: Solys Playtest
addappid(1692440)
addappid(1692441, 1, "72ce63b12fb130d8736f9c7c30628ba57e986244609ec6c692686cbf3cca3454")
