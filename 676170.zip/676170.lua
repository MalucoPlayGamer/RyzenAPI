-- Lua provided by RyzenAPI
-- Game: Ungrounded: Ripple Unleashed VR

-- MAIN APPLICATION
addappid(676170)

-- MAIN APP DEPOTS / PACKAGES
addappid(676171, 1, "900eb779ec359186bf241b687284c48be392892f6a58f8c5aa12ad35d1a922bc")

