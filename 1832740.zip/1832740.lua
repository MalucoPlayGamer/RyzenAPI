-- Lua provided by RyzenAPI
-- Game: Erophone:Re

-- MAIN APPLICATION
addappid(1832740)
-- Game: addappid(1832740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832741, 1, "b2c9133f2d1656b538e57486ea7ca57b6358b15649c1ac6793fd62bd4af2ca55")
