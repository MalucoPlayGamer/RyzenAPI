-- Lua provided by RyzenAPI
-- Game: The Dummy Experiment

-- MAIN APPLICATION
addappid(770460)

-- MAIN APP DEPOTS / PACKAGES
addappid(770465,0,"12ec224ce1988c228daecc6cb5d54d526812f3fc261e2a8bb7825862c4fb18d3")
addappid(770466,0,"3f3a498462f8e8641c3d00540e954c1b15ea63440578ce6f807cb7b03f168965")
addappid(770467,0,"29fd67b8db727a290d03c3ffc63406421d2d3d2d43416fcadfaf1c64c7c2c396")
addappid(770468,0,"faed08eb438af1e7f80b5cafced55317759095cafea319acc67c43da3f5ccced")

