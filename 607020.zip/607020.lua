-- Lua provided by RyzenAPI
-- Game: addappid(607020)

-- MAIN APPLICATION
addappid(607020)

-- MAIN APP DEPOTS / PACKAGES
addappid(607021, 1, "ecb366b4eb67d6f121b72d4848ab684321cd6eca3b4d61ca8e13e92580035adf")
