-- Lua provided by RyzenAPI
-- Game: Skeleton Troubles

-- MAIN APPLICATION
addappid(1730030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730031, 1, "66cd61e080131b12a077c36b0436599783f624b9b869948aa5636822af6d64cc")

