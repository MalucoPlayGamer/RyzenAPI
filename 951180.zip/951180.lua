-- Lua provided by RyzenAPI
-- Game: addappid(951180)

-- MAIN APPLICATION
addappid(951180)
addappid(990880)

-- MAIN APP DEPOTS / PACKAGES
addappid(951181, 1, "15a2b5a8227ca9d46d550d295b8538ee4481812a8ebf317fe332744d4cc30051")
