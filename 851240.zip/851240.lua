-- Lua provided by RyzenAPI
-- Game: Journey To Valhalla

-- MAIN APPLICATION
addappid(851240)

-- MAIN APP DEPOTS / PACKAGES
addappid(851241,0,"0e4be215f6aa48fdfd1ff4e9a0e048677d0ab30d83bdbb27a4387148e7165808")

