-- Lua provided by RyzenAPI
-- Game: Game: The Heart of Influencer

-- MAIN APPLICATION
addappid(3562530)
-- Game: addappid(3562530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3562531, 1, "d482b3a57c0ee88ebad19f82c9786d6e6b9b3e9cda42465c9949afd5517b9fdb")
addappid(3562532, 1, "f8ac6abfeedac6ccfed3633fd00b5566f99d59959800c6601c1db04728508d8d")
addappid(3562533, 1, "9b152945f6b5bf942e87860556df53d10a40d6a24c30881553571171cd5fd4e5")
addappid(3562534, 1, "c73113d412c0a05e421d5430ecc9bc25254e1cd6f513fe95ba0939680cddd533")
