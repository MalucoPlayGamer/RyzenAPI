-- Lua provided by SkyAPI 
-- Game: SaGa Emerald Beyond Demo
addappid(2760480)
addappid(2760481, 1, "77fa3d517afaac306ced9f17e48f744b8add37168ad3b0f4cb11235aeaddd670")
