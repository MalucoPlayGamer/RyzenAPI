-- Lua provided by RyzenAPI
-- Game: Game: SaGa Emerald Beyond Demo

-- MAIN APPLICATION
addappid(2760480)
-- Game: addappid(2760480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760481, 1, "77fa3d517afaac306ced9f17e48f744b8add37168ad3b0f4cb11235aeaddd670")
