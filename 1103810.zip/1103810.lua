-- Lua provided by RyzenAPI
-- Game: Game: My Happy Girls

-- MAIN APPLICATION
addappid(1103810)
-- Game: addappid(1103810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103811, 1, "b0f806a0209f4f5d8ba4f90af8181d5509aaf128a57a956749bcf88a890f8cad")
