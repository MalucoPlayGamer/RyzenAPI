-- Lua provided by RyzenAPI
-- Game: addappid(470090)

-- MAIN APPLICATION
addappid(470090)

-- MAIN APP DEPOTS / PACKAGES
addappid(470091, 1, "dc70a273fdc18cfa694fd86be64423bfe7b393cb71780868abde2c6aaaf9151f")
