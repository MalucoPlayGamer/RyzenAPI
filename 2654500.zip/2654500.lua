-- Lua provided by RyzenAPI
-- Game: 2654500

-- MAIN APPLICATION
addappid(2654500)
-- Game: addappid(2654500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654501, 1, "4be65253c9ee537eb38bbb5c2dbd77f653a4e794c522d91a25ce6baa22f5f43b")
addappid(2654502, 1, "db4f8a1305634bf0e6b4420cdff50442786963d6d48996c42be26bbbd9de5245")
