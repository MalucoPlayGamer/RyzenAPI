-- Lua provided by RyzenAPI
-- Game: Spellpowder: Uprising

-- MAIN APPLICATION
addappid(1775320)
-- Game: addappid(1775320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775321, 1, "1b6a99eb8165e4d7ba459314f7b842ecce5c1b3b930c0f6447d83abb9a661362")
