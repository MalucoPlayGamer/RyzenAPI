-- Lua provided by RyzenAPI
-- Game: 625370

-- MAIN APPLICATION
addappid(625370)
-- Game: addappid(625370)

-- MAIN APP DEPOTS / PACKAGES
addappid(625371, 1, "556165eacf3bed85a906c0d926ad48aafa970bff014cd5becf0c8ed260dda040")
