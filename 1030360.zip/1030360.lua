-- Lua provided by RyzenAPI
-- Game: Midnight Evil

-- MAIN APPLICATION
addappid(1030360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030361, 1, "2644d0f33765bb2f42a9e1abfecae2cd393b1362a40b9e683da951b75d992545")

