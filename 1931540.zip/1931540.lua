-- Lua provided by RyzenAPI
-- Game: addappid(1931540)

-- MAIN APPLICATION
addappid(1931540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931541, 1, "359c2be95a7fbc435c7492eb4699d1b7421015adf0012036cb4a571fca819dc4")
addappid(1931542, 1, "d55f6c1c3d320bedfafce3e74619aada2bd343ec8abe8d69b867f42a9560b892")
