-- Lua provided by RyzenAPI
-- Game: Super Lovely Planet

-- MAIN APPLICATION
addappid(588540)
-- Game: addappid(588540)

-- MAIN APP DEPOTS / PACKAGES
addappid(588541, 1, "2dd497deee3f96c2fd06ae883a7d77526d57adfabc388230648aef620f093946")
