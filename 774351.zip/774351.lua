-- Lua provided by RyzenAPI
-- Game: Game: AppID 774351

-- MAIN APPLICATION
addappid(774351)
-- Game: addappid(774351)

-- MAIN APP DEPOTS / PACKAGES
addappid(774352, 1, "b98d29ff7152dbeca46a70a720b1691443985468c8dea9a7ed5ce5163ba485af")
