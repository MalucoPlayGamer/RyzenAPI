-- Lua provided by RyzenAPI
-- Game: AppID 820630

-- MAIN APPLICATION
addappid(820630)
-- Game: addappid(820630)

-- MAIN APP DEPOTS / PACKAGES
addappid(820631, 1, "00d6ce478f0900edcaa81b3538aff08bcf28c5d6178f4030420e531c65b26902")
