-- Lua provided by RyzenAPI
-- Game: Metal Wolf Chaos XD

-- MAIN APPLICATION
addappid(820630)
addappid(1111140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(820631, 1, "00d6ce478f0900edcaa81b3538aff08bcf28c5d6178f4030420e531c65b26902")

