-- Lua provided by RyzenAPI
-- Game: A Little to the Left

-- MAIN APPLICATION
addappid(1629520)
-- Game: addappid(1629520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629522,0,"75a26ba53fafd90934403fcc6435f5fe6e11f468f51fb71e0b5bc857da2d7d27")
addappid(1629523,0,"7f486534cadce796e4a8f6002a3c4439f28bf578140a469499f5727a65a78eed")
