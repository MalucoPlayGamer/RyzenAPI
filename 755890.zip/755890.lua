-- Lua provided by RyzenAPI
-- Game: Game: AppID 755890

-- MAIN APPLICATION
addappid(755890)
-- Game: addappid(755890)

-- MAIN APP DEPOTS / PACKAGES
addappid(755891, 1, "847e0e08e360923ea945cbe6826d6d8776bd78beaf3c3b2610f498563eba1b34")
addappid(755892, 1, "8198ffb49faac6a9735840e84713c6f56999a5bbef5988c57aaf436ddc74f293")
addappid(755893, 1, "f558487a965f598bbc70be532ddc74fce2ca2ef1306495cb877b33415d55a32d")
