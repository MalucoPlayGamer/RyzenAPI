-- 5021880's Lua and Manifest Created by Hubcap Manifest
-- Alice in Wonderland: The Crown of Wishes
-- Created: August 19, 2026 at 13:50:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(5021880) -- Alice in Wonderland: The Crown of Wishes
-- MAIN APP DEPOTS
addappid(5021881, 1, "da8e1ad456af5f615b5b5871a8344752521effd4401dececdb4fecce9b3d70e0") -- Depot 5021881
setManifestid(5021881, "6808256436996237401", 459489218)
-- DLCS WITH DEDICATED DEPOTS
-- Alice in Wonderland The Crown of Wishes - Supporter Pack (AppID: 5111000)
addappid(5111000)
addappid(5111000, 1, "080b3d597a8fd5f288fa808bf39ad7ef20df5cca44f609cc7d399f25974f0d26") -- Alice in Wonderland The Crown of Wishes - Supporter Pack - Depot 5111000
setManifestid(5111000, "1552804645449948257", 192905986)