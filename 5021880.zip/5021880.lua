-- Lua provided by RyzenAPI
-- Game: Alice in Wonderland: The Crown of Wishes

-- MAIN APPLICATION
addappid(5021880) -- Alice in Wonderland: The Crown of Wishes
addappid(5111000)

-- MAIN APP DEPOTS / PACKAGES
addappid(5021881, 1, "da8e1ad456af5f615b5b5871a8344752521effd4401dececdb4fecce9b3d70e0") -- Depot 5021881
addappid(5111000, 1, "080b3d597a8fd5f288fa808bf39ad7ef20df5cca44f609cc7d399f25974f0d26") -- Alice in Wonderland The Crown of Wishes - Supporter Pack - Depot 5111000

