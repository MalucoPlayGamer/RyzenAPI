-- Lua provided by RyzenAPI
-- Game: 310390

-- MAIN APPLICATION
addappid(310390)
-- Game: addappid(310390)

-- MAIN APP DEPOTS / PACKAGES
addappid(310391, 1, "014784b52d0f00e93f03369829cc9a41b0af22b0ff8c84071978eeac3d992bcf")
