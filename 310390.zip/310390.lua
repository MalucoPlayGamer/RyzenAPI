-- Lua provided by RyzenAPI
-- Game: AppID 310390

-- MAIN APPLICATION
addappid(310390)

-- MAIN APP DEPOTS / PACKAGES
addappid(310391, 1, "014784b52d0f00e93f03369829cc9a41b0af22b0ff8c84071978eeac3d992bcf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
