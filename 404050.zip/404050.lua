-- Lua provided by RyzenAPI
-- Game: 404050

-- MAIN APPLICATION
addappid(404050)
-- Game: addappid(404050)

-- MAIN APP DEPOTS / PACKAGES
addappid(404051, 1, "5b3a48f9a80fc5be9695c5a81aee186f4f5160f1b07c98721fe905c53d80d6b7")
addappid(404052, 1, "4f35ef0c3b9d74b5ea8a355cded9f0fe691ccd557525c25b982c8c97e69b2b67")
