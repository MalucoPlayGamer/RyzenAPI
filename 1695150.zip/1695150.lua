-- Lua provided by SkyAPI 
-- Game: 末路希冀
addappid(1695150)
addappid(1695151, 1, "2a9430dfd0d4b5798506204999e745615b26239d06c69e5a58218d44db3943b2")
