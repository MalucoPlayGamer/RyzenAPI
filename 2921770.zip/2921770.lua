-- Lua provided by RyzenAPI
-- Game: addappid(2921770)

-- MAIN APPLICATION
addappid(2921770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921771, 1, "6310d7e201b30742ae7e885ae883d752ebca771a901220b0e1e5f0460915ee6a")
