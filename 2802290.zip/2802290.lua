-- Lua provided by RyzenAPI
-- Game: Sandtrix

-- MAIN APPLICATION
addappid(2802290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802292,0,"0cf06d67d24c56b70507ca4ac762ec058b062d651715cf7b2f25c103cc0e43ae")

