-- Lua provided by RyzenAPI
-- Game: 1988210

-- MAIN APPLICATION
addappid(1988210)
-- Game: addappid(1988210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988211, 1, "a23e72092582c415eac0857f47b4d5dba57ecee66d0c4918c1d0b17291222b66")
