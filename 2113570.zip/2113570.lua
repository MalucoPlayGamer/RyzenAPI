-- Lua provided by RyzenAPI 
-- Game: Ascend: Reborn
addappid(2113570)
addappid(2113571, 1, "95ede74fbd08a2b6f69fed077a905d432802953410f617f9171519acee1d8844")
