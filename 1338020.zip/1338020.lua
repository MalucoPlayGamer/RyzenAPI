-- Lua provided by RyzenAPI
-- Game: 1338020

-- MAIN APPLICATION
addappid(1338020)
-- Game: addappid(1338020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338021, 1, "ad38aaae449595adec81d569e9bcc4ad40cfb829b0b613835782fee2b5d1f3dd")
