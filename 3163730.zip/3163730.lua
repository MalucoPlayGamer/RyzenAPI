-- Lua provided by RyzenAPI
-- Game: Trapped: Family Vacation

-- MAIN APPLICATION
addappid(3163730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163731, 1, "001578334cdffdb15f726fb99d2f52d01421da85d33bd62dc8d6046611347a22")
