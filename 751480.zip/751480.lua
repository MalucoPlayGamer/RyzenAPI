-- Lua provided by RyzenAPI
-- Game: Game: AppID 751480

-- MAIN APPLICATION
addappid(751480)
-- Game: addappid(751480)

-- MAIN APP DEPOTS / PACKAGES
addappid(751481, 1, "cf998dca1c2c1ad4975d594b00e3012f632a4aa01d2416d1411463c4ded71b67")
