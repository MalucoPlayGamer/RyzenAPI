-- Lua provided by RyzenAPI
-- Game: Game: Second Wave

-- MAIN APPLICATION
addappid(2337510)
-- Game: addappid(2337510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337511, 1, "986f1b904c88533bffe8f6b140e739cbaa852cbb3b2fefede2ed30e079b24fec")
