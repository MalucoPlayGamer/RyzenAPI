-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Machine Head - “Davidian”

-- MAIN APPLICATION
addappid(1122564)
-- Game: addappid(1122564)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122564,0,"64c03db2a5ba8f1cfcd37158d75ec2e344f67d784e08eec9a2903a9f7a7e80c3")
