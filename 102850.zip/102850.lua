-- Lua provided by SkyAPI 
-- Game: AppID 102850
addappid(102850)
addappid(102851, 1, "005f4f1daf0304c7962779cf854f75c1decda386917099b70b1d21f2c8b94ddc")
