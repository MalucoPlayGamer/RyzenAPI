-- Lua provided by RyzenAPI
-- Game: The End: Inari's Quest

-- MAIN APPLICATION
addappid(893070)

-- MAIN APP DEPOTS / PACKAGES
addappid(893071, 1, "98f8b1f1add2bda88d1b70de9d94ecb4eb95702c3e06923e933c778db7a9237a")

