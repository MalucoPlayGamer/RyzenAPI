-- Lua provided by RyzenAPI
-- Game: 1072290

-- MAIN APPLICATION
addappid(1072290)
-- Game: addappid(1072290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072291, 1, "4d10ab480a6f2f9ead188f0d465d9231e61fd7e26796bd175416afc0d2f3eab8")
