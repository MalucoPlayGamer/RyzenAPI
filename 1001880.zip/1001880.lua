-- Lua provided by RyzenAPI
-- Game: aMAZE Valentine

-- MAIN APPLICATION
addappid(1001880)
-- Game: addappid(1001880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001881, 1, "6d2a3ca283a556e2718b23d2b5cc4198049182677b784cfb5bc03c79bab74c10")
