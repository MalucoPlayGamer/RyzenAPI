-- Lua provided by RyzenAPI
-- Game: Game: Life is Strange 2 Demo

-- MAIN APPLICATION
addappid(1210810)
-- Game: addappid(1210810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210811, 1, "d9a0ce110aecfda3b79eccc24fbd1fe44d26be1aaa959e775c6f854633085d64")
