-- Lua provided by RyzenAPI
-- Game: Agricultural Simulator 2012: Deluxe Edition

-- MAIN APPLICATION
addappid(273790)

-- MAIN APP DEPOTS / PACKAGES
addappid(273791, 1, "eb3cdd3bbe5018616213a903c6d8aab36a19adfda3322c2e020f0f47f9ccf330")
addappid(273792, 1, "39956010d4e166e7543d11542c39f89ba2b16729a8806ecbf3621b396762413e")
addappid(273793, 1, "ac733c3d3d31b21e9c9b569287b819094913caf2e88dd7b069c48eefd887c014")
addappid(273794, 1, "8edc0a9850c441bb958bab0618062aef21a704e2f4b9cbbba661689793a03292")
addappid(273795, 1, "64e84462132da611533123e1b7a1828f0277e88ac7dff41cae856a3f54db84dd")
addappid(273796, 1, "b76acd937be21a3b775263720d2fff84424124ff4576040ecdce8b9b25e1f0ed")
addappid(273797, 1, "c4d605320a8c05d6bbc2b815c54187c17328fcabf201aeb5d57b642cd4244fea")
addappid(273798, 1, "a5e155658d19bf1342c089370ec3e7a58efe5fcb929ff1ae0345b9c241f80139")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
