-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1184101)
addappid(1184101,0,"b52ef3acbf311eafeb96bb282f85bd1bc170cd2db8a1fec24b59816a56c6e6cc")
-- setManifestid(1184101,"1260645792645170586")