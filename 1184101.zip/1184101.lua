-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1184101)
-- Game: addappid(1184101)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184101,0,"b52ef3acbf311eafeb96bb282f85bd1bc170cd2db8a1fec24b59816a56c6e6cc")
