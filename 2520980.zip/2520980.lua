-- Lua provided by RyzenAPI
-- Game: 2520980

-- MAIN APPLICATION
addappid(2520980)
-- Game: addappid(2520980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520981, 1, "e502052e13acb17a87ff482c9181188fd01341317502ee1a1bfd0cc6a60c9fe7")
