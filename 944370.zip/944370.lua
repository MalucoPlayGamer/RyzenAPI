-- Lua provided by RyzenAPI
-- Game: Game: AppID 944370

-- MAIN APPLICATION
addappid(944370)
-- Game: addappid(944370)

-- MAIN APP DEPOTS / PACKAGES
addappid(944371, 1, "05abd15ca816e295c37ac52bcbf635df79c97d6150645e8292925e2650ebd099")
