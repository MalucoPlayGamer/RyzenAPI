-- Lua provided by RyzenAPI
-- Game: Star Pixie

-- MAIN APPLICATION
addappid(1640780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640781, 1, "7d9522706b7a849f112c2ec2b7b7bdf48474cafbf6d9055945e349403ecab594")
