-- Lua provided by RyzenAPI
-- Game: Game: Split Brain

-- MAIN APPLICATION
addappid(3156640)
-- Game: addappid(3156640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156641, 1, "4d2a736692832b5c26486da735a09dbfa2ada6cf9d549277dcaeb9553017027c")
