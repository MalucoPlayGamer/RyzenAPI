-- Lua provided by RyzenAPI
-- Game: Game: Unspoken

-- MAIN APPLICATION
addappid(2846290)
-- Game: addappid(2846290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846291, 1, "3b6089658a4300ded7def75bba0bd6d6bd77f1b4b188203ed59822d29efd7f73")
