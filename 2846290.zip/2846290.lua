-- Lua provided by RyzenAPI 
-- Game: Unspoken
addappid(2846290)
addappid(2846291, 1, "3b6089658a4300ded7def75bba0bd6d6bd77f1b4b188203ed59822d29efd7f73")
