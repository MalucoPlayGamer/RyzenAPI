-- Lua provided by RyzenAPI
-- Game: Game: Survivor World

-- MAIN APPLICATION
addappid(2999090)
-- Game: addappid(2999090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999091, 1, "792809abad754a42907116ed6ecbd1d00f1d8b4ae16b85d88cabb182228f4f8c")
