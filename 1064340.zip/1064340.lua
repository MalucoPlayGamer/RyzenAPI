-- Lua provided by RyzenAPI
-- Game: addappid(1064340)

-- MAIN APPLICATION
addappid(1064340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064341, 1, "5a343fe4aeadaf2d03af52d1dcc9d18afc1d844fab559a52ee0d26178bac8ecd")
