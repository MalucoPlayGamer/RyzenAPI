-- Lua provided by RyzenAPI
-- Game: AppID 3365050

-- MAIN APPLICATION
addappid(3365050)
addappid(3782470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3365051, 1, "5f0ac27fa68bdbbb717f526d76c9a8c440ae3cfd217b65f183fa281d0b1cdf85")

