-- Lua provided by RyzenAPI
-- Game: Hypno Idols: Greatest Tits

-- MAIN APPLICATION
addappid(3115060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115061, 1, "6199195d827ba8221fea9e5991489ec2b0f4ce8c7e4f8ca315e62c3adca2f8dd")
addappid(3115062, 1, "338832907a6d20d4de0e0210df64a5ba3010a2cf0b95970f6282686c47400d9a")
