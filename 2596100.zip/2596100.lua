-- Lua provided by RyzenAPI
-- Game: Lycans

-- MAIN APPLICATION
addappid(2596100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596101, 1, "bc1bee17d0254ec3185187f0b8108926af606ee8b33a40a398d634c6ce5f5c2d")

