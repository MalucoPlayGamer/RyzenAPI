-- Lua provided by RyzenAPI
-- Game: Viscera Cleanup Detail - Soundtrack

-- MAIN APPLICATION
addappid(386860)

-- MAIN APP DEPOTS / PACKAGES
addappid(386861, 1, "7226631be857f8554e3e33263291dab4d1f1efd6ada1ab688ab0bad2d92ab3ec")

