-- Lua provided by RyzenAPI
-- Game: Singled Out

-- MAIN APPLICATION
addappid(1144150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144151, 1, "35df5da39933eb4d56ad127819fd1ebedf87e8d068505f121ea69a04d5081a20")

