-- Lua provided by RyzenAPI
-- Game: 第五件遗留物

-- MAIN APPLICATION
addappid(1461680)
addappid(1461880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1461681, 1, "64cef6764ff8c685e45696a280e058391f417178a9619d19acb6ddea6f386e05")

