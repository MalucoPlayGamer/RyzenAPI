-- Lua provided by RyzenAPI
-- Game: addappid(1461680)

-- MAIN APPLICATION
addappid(1461680)
addappid(1461880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461681, 1, "64cef6764ff8c685e45696a280e058391f417178a9619d19acb6ddea6f386e05")
