-- Lua provided by RyzenAPI
-- Game: Ship of Fools Demo

-- MAIN APPLICATION
addappid(2129640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129641, 1, "93732320f4ead1109175956ae8f36bfef27798758bf0e75cafb1b62b935fbb5a")
