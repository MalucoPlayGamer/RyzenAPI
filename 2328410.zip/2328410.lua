-- Lua provided by RyzenAPI
-- Game: addappid(2328410)

-- MAIN APPLICATION
addappid(2328410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328411, 1, "ea70033462f44a262e1b5554992dbb04ea343cad3ad70e35f8cc16ec8726b875")
