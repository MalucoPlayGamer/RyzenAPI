-- Lua provided by RyzenAPI
-- Game: The Scuttle

-- MAIN APPLICATION
addappid(1024080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1024081, 1, "506fa8462777f3a3ca14d0a1b4f676202d44b658913e52bc11174f75033240c0")

