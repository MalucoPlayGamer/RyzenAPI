-- Lua provided by RyzenAPI
-- Game: The Scuttle

-- MAIN APPLICATION
addappid(1024080)
-- Game: addappid(1024080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024081, 1, "506fa8462777f3a3ca14d0a1b4f676202d44b658913e52bc11174f75033240c0")
