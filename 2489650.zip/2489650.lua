-- Lua provided by RyzenAPI
-- Game: Game: PRIPRI

-- MAIN APPLICATION
addappid(2489650)
-- Game: addappid(2489650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489651, 1, "dc479d652742ffa1d3df7cc2a3c0366025f3fb6ef2f34fa5de8c1f16608ba295")
addappid(2489654, 1, "43bfaa36c81d69f2d81f70783188c76dec247e93c16676c063c83c2ca8e39864")
