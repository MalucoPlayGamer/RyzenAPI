-- Lua provided by RyzenAPI
-- Game: Demonlore

-- MAIN APPLICATION
addappid(1588340)
-- Game: addappid(1588340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588341, 1, "e9f1cf1a84a5873cf8939d10850d04b63e907fe608135479cb179e8b0573eccb")
