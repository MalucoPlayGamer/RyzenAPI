-- Lua provided by RyzenAPI
-- Game: AppID 1488020

-- MAIN APPLICATION
addappid(1488020)
-- Game: addappid(1488020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488021, 1, "57e8a0003b99a1947612f5b36a607bcc082cc6a16557579cfc4c4f43367fcf7c")
