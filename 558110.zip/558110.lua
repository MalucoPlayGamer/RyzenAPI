-- Lua provided by RyzenAPI
-- Game: Odyssey - The Invention of Science

-- MAIN APPLICATION
addappid(558110)

-- MAIN APP DEPOTS / PACKAGES
addappid(558111, 1, "3afb072bb1074c8ac525bd4fc1800772865ea799298c0ae719e1e6d6e6651b5e")
