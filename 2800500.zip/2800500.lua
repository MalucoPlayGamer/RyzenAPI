-- Lua provided by RyzenAPI
-- Game: Game: AppID 2800500

-- MAIN APPLICATION
addappid(2800500)
-- Game: addappid(2800500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800501, 1, "07d084268995bbfabaf0cb5aab577da47ceb25406ffdd8ed3d5dddda98b2354e")
