-- Lua provided by RyzenAPI
-- Game: Blacklist Mafia

-- MAIN APPLICATION
addappid(2800500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800501, 1, "07d084268995bbfabaf0cb5aab577da47ceb25406ffdd8ed3d5dddda98b2354e")
