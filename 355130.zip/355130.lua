-- Lua provided by RyzenAPI
-- Game: MotoGP™15

-- MAIN APPLICATION
addappid(355130)
addappid(374810)

-- MAIN APP DEPOTS / PACKAGES
addappid(355131, 1, "60980e22be18695c625fdb913b6b8793f80ce03edf187fae77613e6eaea83bb6")
addappid(373200, 0, "1fe1d11d5866b8053a25361b2e05420ce842181dc8b3952244613c89aefd27fa")
addappid(374800, 0, "953388ab9040e9efbd973543cd199cd2375b209fbba62d43d003088ec050304d")
addappid(392420, 0, "c13832cb25af135196c2019e9ad29a5a7301817cc67895be3f079ef01121a6e8")
addappid(392430, 0, "002af7e2f598fb1cd84a6317157241e1f395c4b1a70063e255037fa797515088")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
