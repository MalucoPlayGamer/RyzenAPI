-- Lua provided by RyzenAPI
-- Game: AppID 342450

-- MAIN APPLICATION
addappid(342450)

-- MAIN APP DEPOTS / PACKAGES
addappid(342451, 1, "e1894ec1d744c6533bfe6f7dcecda6aecd6230ae3fda255fcb9835df6187bc39")
addappid(342452, 1, "39a4bc15575d463c306c4ef16549d413e6a85d72fb6c369ffd9718a88bc02cea")
addappid(342453, 1, "0faab0d46bd6ab5b90b7327bd055f72289a4de9e3ecc4f016409803cec81e1c6")
addappid(342454, 1, "1214fc84d7f8cac5a8b3df9bc7c95bca65dc7d76ecc54b2f803657844eec4fa6")
addappid(342455, 1, "3408925820287931d0ebd5b22b9ed9d20029bef519581928dd530aa27d039fe1")
addappid(342456, 1, "28dfbad3e763dcdf19ca32f151fe83a5cb0b8784e724f04eaa8ea399a821a875")

