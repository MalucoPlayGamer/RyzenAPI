-- Lua provided by RyzenAPI 
-- Game: AppID 3127970
addappid(3127970)
addappid(3127971, 1, "034bee9d630e503023bf22b014c63a77f306dc07588aa669cd33ead5a9f70f81")
