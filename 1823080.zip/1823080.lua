-- Lua provided by RyzenAPI 
-- Game: Dark Invasion VR: Doomsday
addappid(1823080)
addappid(1823081, 1, "36ef654644634ca0e8209d02b0a3833a5c47a845fe74fe931ab4fd0cde276f44")
