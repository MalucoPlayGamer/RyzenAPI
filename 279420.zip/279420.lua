-- Lua provided by RyzenAPI
-- Game: Game: Gardens Inc. – From Rakes to Riches

-- MAIN APPLICATION
addappid(279420)
-- Game: addappid(279420)

-- MAIN APP DEPOTS / PACKAGES
addappid(279421, 1, "b45437354e6394ecb96655976eecc82e924950de19cfebc3da9107777fbcb392")
addappid(279422, 1, "388df60683a72d34db1dff31070fd352d99dc9268e3322e8a64530d99c40809f")
addappid(279423, 1, "e425c7a610cab1b8548d37e0580df72bdb92257c9371f9a919814c58abe51f3c")
addappid(279424, 1, "a2f1e58d2c232ad4e03e1a59e87745fcd456a06dea5e175785908b8f4c2eb536")
