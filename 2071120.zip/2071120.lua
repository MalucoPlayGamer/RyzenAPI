-- Lua provided by RyzenAPI
-- Game: addappid(2071120)

-- MAIN APPLICATION
addappid(2071120)
addappid(2520790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071121, 1, "c8ddda661bcc192790827310b46b7c51606d7c38ca2026a6eb511c0224de6078")
