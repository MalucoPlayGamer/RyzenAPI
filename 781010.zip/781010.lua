-- Lua provided by RyzenAPI
-- Game: The Disappearing of Gensokyo: Kogasa, Iku Character Pack

-- MAIN APPLICATION
addappid(781010)

-- MAIN APP DEPOTS / PACKAGES
addappid(781010,0,"4af47316fe3dce775c81b953dbf43c37cd6724d5cf946fa5817df0c7134bcbc5")

