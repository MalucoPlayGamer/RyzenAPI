-- Lua provided by SkyAPI 
-- Game: Pacific Storm Allies
addappid(11260)
addappid(11261, 1, "3ee6c214258ebc3f9b150060c8f562edea2f234562e357ff510181837bc0cdc6")
addappid(11262, 1, "f6791866c6305c2d37f52ae50641111bf789757e1a5cc24c96fe8d5b1300a7ca")
addappid(11263, 1, "e55485cc094b97ad78d172e5b5a70c678a2a6c657cdc85da338c17610c2b25e3")
