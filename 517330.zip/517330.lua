-- Lua provided by RyzenAPI
-- Game: Stellar Interface

-- MAIN APPLICATION
addappid(517330)
addappid(750150)
addappid(750151)

-- MAIN APP DEPOTS / PACKAGES
addappid(517331, 1, "2b5497176484a52f97c377e09236078fe470dfd9dae4051152e657abca0e2669")
addappid(777450, 0, "d8b164c3ad2a404576db303995aef28cb31e25fcf10ed69c41d591fd66d2dd9a")

