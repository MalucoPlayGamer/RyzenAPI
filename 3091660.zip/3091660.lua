-- Lua provided by RyzenAPI
-- Game: THROUGH

-- MAIN APPLICATION
addappid(3091660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091661, 1, "bfa162c1aab35d608135e1ce4ce24ef3738d8ad85ac5cb0b20391e25f75cfe00")

