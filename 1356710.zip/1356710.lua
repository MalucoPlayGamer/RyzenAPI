-- Lua provided by RyzenAPI
-- Game: My Creampie Heaven

-- MAIN APPLICATION
addappid(1356710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356711, 1, "f8620c73a3a924acc1b32a7a51a4ccdb2d44ca361110c4aead1706c6ec101c66")

