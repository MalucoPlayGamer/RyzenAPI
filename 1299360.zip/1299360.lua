-- Lua provided by RyzenAPI
-- Game: Mighty Goose

-- MAIN APPLICATION
addappid(1299360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299361, 1, "ceb18d12e7cb9a34b06e387a69ea822778755935157897637c66f58e671c229b")
addappid(1299362, 1, "fed834b69d44f9bb1310d4103b16f20743a42c45c645cc1d9e82b2d46098f5d0")
addappid(1299363, 1, "9118511d91fa92341a5529c12167d36b0221394a6be495ea558acda9df7ca3b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
