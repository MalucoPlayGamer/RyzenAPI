-- Lua provided by RyzenAPI
-- Game: Forts - Soundtrack

-- MAIN APPLICATION
addappid(627370)

-- MAIN APP DEPOTS / PACKAGES
addappid(627371, 1, "8cbba92f1627740d198e01eecac8deaf76bf6bbed90493cf2ce6324ec69ae2b0")
