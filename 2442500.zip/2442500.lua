-- Lua provided by RyzenAPI
-- Game: 2442500

-- MAIN APPLICATION
addappid(2442500)
-- Game: addappid(2442500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442501, 1, "5dc0e39e08976f4f2167a1fe549bb0cfa64ce11427d333177e1bc797052faaec")
