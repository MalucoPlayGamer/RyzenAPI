-- Lua provided by RyzenAPI
-- Game: Scavenger

-- MAIN APPLICATION
addappid(2329980)
-- Game: addappid(2329980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2329981, 1, "baab950bcb395fb980cc2c33e5273db4c7a734566611b5dea6441c9cb702e063")
