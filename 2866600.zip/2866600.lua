-- Lua provided by RyzenAPI
-- Game: Game: Project13: Nightwatch

-- MAIN APPLICATION
addappid(2866600)
addappid(2963820)
-- Game: addappid(2866600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866601, 1, "b2aaf873e1624f06875c78e39ebcfe09e9add95856faa928bc5964d145959408")
