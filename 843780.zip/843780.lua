-- Lua provided by RyzenAPI
-- Game: Game: City Builder

-- MAIN APPLICATION
addappid(843780)
-- Game: addappid(843780)

-- MAIN APP DEPOTS / PACKAGES
addappid(843781, 1, "3c4ba4e7cb9dc939eff39586e769b7a766ebced02c05bfbb1c384849321a4b36")
