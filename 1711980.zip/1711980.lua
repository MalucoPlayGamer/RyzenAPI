-- Lua provided by RyzenAPI 
-- Game: AppID 1711980
addappid(1711980)
addappid(1711981, 1, "61498af9202ce6345108534721cd80af9f475c010059ee770a8e2e9f1a5634f6")
