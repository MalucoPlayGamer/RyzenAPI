-- Lua provided by RyzenAPI
-- Game: Tennis Manager 25

-- MAIN APPLICATION
addappid(3549220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549221, 1, "160dae45b34c12ba41e25a4ba0940b0d7203c755e61eaf21c4f6f16509430245")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
