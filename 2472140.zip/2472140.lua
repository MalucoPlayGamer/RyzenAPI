-- Lua provided by RyzenAPI
-- Game: ALL Chess

-- MAIN APPLICATION
addappid(2472140)
-- Game: addappid(2472140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472141, 1, "8ce49a3a97608217533a6c1cf0527a6a56a9f6a312158474feab5f548d171c3b")
