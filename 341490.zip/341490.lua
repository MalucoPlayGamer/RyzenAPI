-- Lua provided by RyzenAPI
-- Game: Undead Legions II

-- MAIN APPLICATION
addappid(341490)

-- MAIN APP DEPOTS / PACKAGES
addappid(341491, 1, "3ad1c42e51eb7a97ae60a860ee65e8dbd304cc932a211c222feb230b874fb60a")

