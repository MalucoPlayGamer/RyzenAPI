-- Lua provided by RyzenAPI
-- Game: AppID 1879280

-- MAIN APPLICATION
addappid(1879280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879281, 1, "c889cad06eeca16bb990d460a36186b12e66278f3845b81fed25b37bb6e6edf7")
