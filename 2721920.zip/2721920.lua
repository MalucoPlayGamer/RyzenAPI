-- Lua provided by SkyAPI 
-- Game: 剑舞
addappid(2721920)
addappid(2721921, 1, "87f66cbbe90e2004877ffe6168b955760069f5591d9350d8dac5e2af9031e47e")
