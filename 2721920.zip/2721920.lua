-- Lua provided by RyzenAPI
-- Game: Game: 剑舞

-- MAIN APPLICATION
addappid(2721920)
-- Game: addappid(2721920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721921, 1, "87f66cbbe90e2004877ffe6168b955760069f5591d9350d8dac5e2af9031e47e")
