-- Lua provided by RyzenAPI
-- Game: VR Furballs - Demolition

-- MAIN APPLICATION
addappid(704470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(704471, 1, "b5759aaa5e6bf74a807bf49fe435144411fbf4f2a6dfe1c6f65e9dbb9a331c66")
