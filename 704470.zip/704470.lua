-- Lua provided by RyzenAPI
-- Game: AppID 704470

-- MAIN APPLICATION
addappid(704470)

-- MAIN APP DEPOTS / PACKAGES
addappid(704471, 1, "b5759aaa5e6bf74a807bf49fe435144411fbf4f2a6dfe1c6f65e9dbb9a331c66")

