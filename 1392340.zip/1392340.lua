-- Lua provided by RyzenAPI
-- Game: Shop Tycoon: Prepare your wallet

-- MAIN APPLICATION
addappid(1392340)
-- Game: addappid(1392340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392341, 1, "120e4fb9641a21222da49e29bfe24a1809ceeb44ef80c460a9d7055d0b4d4adc")
addappid(1392342, 1, "ba542b8cfc9d1820a60a168376eb3da9aa6fb13b44f6035030a96e5ea4e922aa")
addappid(1392343, 1, "57582fae8078b9b7925c728cb221161ad39e7679e804cd3f323b80f5423edc75")
addappid(1392344, 1, "61333486baeb10fe0ca92623e21d1b2bc476383acda9ee1f6e5421091cb72fb4")
addappid(1392345, 1, "b85195fc0310da0bbe4b4447126eb73357c58e383aa05b56d6609dc9bc7459c7")
