-- Lua provided by RyzenAPI
-- Game: Game: Dystopika

-- MAIN APPLICATION
addappid(2379910)
addappid(3859970)
-- Game: addappid(2379910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379911, 1, "af33669168d4e2e2406d6e054fc821e31c1b4a4ce64046448bd1a1c19dd6a7e1")
