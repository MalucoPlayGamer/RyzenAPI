-- Lua provided by RyzenAPI
-- Game: Hex of Steel

-- MAIN APPLICATION
addappid(1240630)
-- Game: addappid(1240630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240632,0,"145e8828b6475849ba8e8f88369db6e0cbf10956ed3cee4faa53506fea3b4ab3")
