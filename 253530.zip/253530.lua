-- Lua provided by RyzenAPI
-- Game: Fortress Forever

-- MAIN APPLICATION
addappid(253530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(253531, 1, "d64e06d35da487acad1c766551ad9b0edfcc3c9edf3e4e178605e73271ec0ca4")
addappid(253540, 1, "5be915a666a803a20540bdc4f0d0054f29daeafd104f76c76c5cfbd690bc5646")
addappid(253541, 1, "7b653d2c63184f96538663ec65b33de33a05d4d52090681983dd0e0accc50ab6")
addappid(253542, 1, "521b0c27f3c45b399016235756a5261ed7f9dbe81f517239576d0c9dffb9cdad")
addappid(253543, 1, "2e327633d43f86e1f0ff67d7f66e69da7611b349dec0aacca2dbbb25f5c3694c")
