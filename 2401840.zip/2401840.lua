-- Lua provided by RyzenAPI
-- Game: Game: AppID 2401840

-- MAIN APPLICATION
addappid(2401840)
-- Game: addappid(2401840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401841, 1, "a97d5426116e5cfa074b87cde9622bbffa3608029557206c8dda5a919ca62efa")
