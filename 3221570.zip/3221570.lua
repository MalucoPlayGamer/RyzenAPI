-- Lua provided by RyzenAPI
-- Game: Fruity Rogue

-- MAIN APPLICATION
addappid(3221570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221571, 1, "37469522cd2925dcdb625ebc692ecda8a4feeef545212ac051ea38000adf6482")

