-- Lua provided by RyzenAPI
-- Game: Who Stole My Sheep?

-- MAIN APPLICATION
addappid(2008600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008601, 1, "f61b310ec709dcd6c1cda5c37b71ea308a14c493a45558bfc35926d6cf412635")
