-- Lua provided by RyzenAPI
-- Game: Yume Nikki

-- MAIN APPLICATION
addappid(650700)

-- MAIN APP DEPOTS / PACKAGES
addappid(650702,0,"f924dd669189e67637b1c6a5063d474f90f4b9c8b78799ed45e3c05537c3206e")
addappid(650703,0,"a6bae1b261377525d487d7c35b625bdea2dc66af5e3b2b6affa91eb6e87568e4")

