-- Lua provided by RyzenAPI
-- Game: Atlas Architect

-- MAIN APPLICATION
addappid(1459500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459501, 1, "0f7203c5e061336cf091fb53688cfd6b9852453c72d41287ff7a0902640b6c45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
