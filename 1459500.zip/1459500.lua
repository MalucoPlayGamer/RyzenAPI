-- Lua provided by RyzenAPI
-- Game: Game: Atlas Architect

-- MAIN APPLICATION
addappid(1459500)
-- Game: addappid(1459500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459501, 1, "0f7203c5e061336cf091fb53688cfd6b9852453c72d41287ff7a0902640b6c45")
