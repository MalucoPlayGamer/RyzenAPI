-- Lua provided by RyzenAPI
-- Game: The Witcher 3 REDkit

-- MAIN APPLICATION
addappid(2684660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684661, 1, "c70c3fc8785c9d7fd2a491dea855bd211e933de6e059695504ea8bd6d96be4c4")
addappid(2684662, 1, "772c9d3b799ec2f18531a15ccc7ed0317dceff975e20d23607651d09d69e4b93")

