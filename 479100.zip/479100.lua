-- Lua provided by RyzenAPI
-- Game: Music Wars Empire

-- MAIN APPLICATION
addappid(479100)

-- MAIN APP DEPOTS / PACKAGES
addappid(479102,0,"53813e6cb2665a10fb09b21b9af66a9809595dc3ca3d1207882ec3fa7beb5489")

