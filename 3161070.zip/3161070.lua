-- Lua provided by RyzenAPI
-- Game: AppID 3161070

-- MAIN APPLICATION
addappid(3161070)
-- Game: addappid(3161070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161071, 1, "ba4f4a784c5d48302fca88ea9c107c12c0b4168e9a139a8dd0b2923d8a41ec5b")
