-- Lua provided by RyzenAPI
-- Game: Further Still: Survivors

-- MAIN APPLICATION
addappid(2076810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076811, 1, "1c5668ad56c1c4295aad3d95dfe0a35b526f9546ac192ba41e1c37e239683502")
