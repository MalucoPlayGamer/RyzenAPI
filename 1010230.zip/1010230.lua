-- Lua provided by RyzenAPI
-- Game: Bleep Bloop

-- MAIN APPLICATION
addappid(1010230)
-- Game: addappid(1010230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010231, 1, "e6bda1c405643af245386cbbeba20c2b62f373f3c7a29896ca2f8e61dcbf2386")
