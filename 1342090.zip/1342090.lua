-- Lua provided by SkyAPI 
-- Game: PRIMITIVE HEARTS
addappid(1342090)
addappid(1342091, 1, "af2b2ba33de949d19bf9aa14e694a0415195e277f18107c3d8dc82a923341d6e")
addappid(1342092, 1, "b20634d9b94f18c4203b4f0e4a3875ba6fb8d14350e6caa5fe7db0f8a81c00b4")
addappid(1342093, 1, "b654225b23c452a624e8729eec8b1caf0496e8aa984361af39a41b02cad84de8")
