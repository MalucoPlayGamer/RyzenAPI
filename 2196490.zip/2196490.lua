-- Lua provided by RyzenAPI
-- Game: Game: AppID 2196490

-- MAIN APPLICATION
addappid(2196490)
-- Game: addappid(2196490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196491, 1, "2657190b1b793cc08a3fa2502db93e2df41722412f6d6661b131d56cc6b51acb")
