-- Lua provided by RyzenAPI
-- Game: Drug Dealer Simulator Demo

-- MAIN APPLICATION
addappid(1239190)
-- Game: addappid(1239190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239191, 1, "a8fe45499a0373608e10f5ae7452c6527ceebe8b2b6eef299b7e8b217954894b")
