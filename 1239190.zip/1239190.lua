-- Lua provided by SkyAPI 
-- Game: Drug Dealer Simulator Demo
addappid(1239190)
addappid(1239191, 1, "a8fe45499a0373608e10f5ae7452c6527ceebe8b2b6eef299b7e8b217954894b")
