-- Lua provided by RyzenAPI
-- Game: AppID 575750

-- MAIN APPLICATION
addappid(575750)

-- MAIN APP DEPOTS / PACKAGES
addappid(575751, 1, "830d50e76d2b36b8271701a9ac1eb6fd9220302faef87e82b4acb792bb0c0598")

