-- Lua provided by RyzenAPI
-- Game: Minesweeper Collector 2

-- MAIN APPLICATION
addappid(2671210)
-- Game: addappid(2671210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671211, 1, "6148852bff576995c650cfb291d86caef5a23bd1d05d54f0ff957639b93cc1a6")
