-- Lua provided by RyzenAPI
-- Game: 我在地球修仙有系统 Demo

-- MAIN APPLICATION
addappid(2137980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137981, 1, "6d9383d0d22a8e832ea3dd70f1d9fe4fd5461540233656b744f0f2a5eba90afc")

