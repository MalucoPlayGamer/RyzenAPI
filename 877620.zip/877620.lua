-- Lua provided by RyzenAPI
-- Game: addappid(877620)

-- MAIN APPLICATION
addappid(877620)

-- MAIN APP DEPOTS / PACKAGES
addappid(877621, 1, "9aebfbce314584af6e967104be1d5060284feca4baef886010adc9c4a983b4fc")
