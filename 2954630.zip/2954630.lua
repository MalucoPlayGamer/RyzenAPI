-- Lua provided by RyzenAPI
-- Game: addappid(2954630)

-- MAIN APPLICATION
addappid(2954630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954631, 1, "a8608c04c5a0d8516e98bc174b5b85f88c2787bd1df982d7bafad793674a3acd")
