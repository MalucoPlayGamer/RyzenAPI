-- Lua provided by RyzenAPI
-- Game: Sera Dion: Survivor

-- MAIN APPLICATION
addappid(3243970)
-- Game: addappid(3243970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243971, 1, "acee49a89b9ce0d6c7dbc2cc714ce66895c0df30f818c66b25a8243422a9f12d")
