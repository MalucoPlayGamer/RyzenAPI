-- Lua provided by RyzenAPI
-- Game: Sera Dion: Survivor

-- MAIN APPLICATION
addappid(3243970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3243971, 1, "acee49a89b9ce0d6c7dbc2cc714ce66895c0df30f818c66b25a8243422a9f12d")

