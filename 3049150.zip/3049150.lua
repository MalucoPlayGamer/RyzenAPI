-- Lua provided by RyzenAPI
-- Game: 3049150

-- MAIN APPLICATION
addappid(3049150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049153,0,"2e6289d4eef978fdf07525165460ff7fc6e5ae263bebf4e1fa3d6c91a98e029a")

