-- Lua provided by RyzenAPI 
-- Game: AppID 421730
addappid(421730)
addappid(421731, 1, "f429c262538175168597068442487db98496c22f55b1772f3845dd41ed133905")
