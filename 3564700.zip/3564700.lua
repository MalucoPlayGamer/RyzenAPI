-- Lua provided by RyzenAPI
-- Game: 3564700

-- MAIN APPLICATION
addappid(3564700)
-- Game: addappid(3564700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564701, 1, "9e251245bb31d9a8f97fe130c948383a5be5d42f486fc2d0f11737098cf8d786")
