-- Lua provided by RyzenAPI
-- Game: Futanari Affairs 🍆

-- MAIN APPLICATION
addappid(3625610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3625611, 1, "b551b9b3bbec617ef0fb6015289b9dad2e0cebb23e61f451aa75662a2f3242c7")
