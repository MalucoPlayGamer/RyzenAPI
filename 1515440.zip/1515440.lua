-- Lua provided by RyzenAPI
-- Game: Game: Olija Soundtrack

-- MAIN APPLICATION
addappid(1515440)
-- Game: addappid(1515440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515441, 1, "28a3a57423e4146c2578453a1b5f312fd6fe1c9e41654ba4137d02666c7d3737")
