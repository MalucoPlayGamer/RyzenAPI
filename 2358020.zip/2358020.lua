-- Lua provided by RyzenAPI
-- Game: addappid(2358020)

-- MAIN APPLICATION
addappid(2358020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358021, 1, "605d10a1a6c110fc21d63e8e00adb3821c2035713f801efd15ceae435c625ce0")
