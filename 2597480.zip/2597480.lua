-- Lua provided by RyzenAPI
-- Game: Bardic: Quest for Love

-- MAIN APPLICATION
addappid(2597480)
addappid(2837650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597481, 1, "af32872c3bf6a08ea3965468f88e46eb12d1573b884314644bfe01afac530580")
