-- Lua provided by RyzenAPI
-- Game: addappid(1963060)

-- MAIN APPLICATION
addappid(1963060)
addappid(2325300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963061, 1, "d76929b4d956d6bfefe769a2104e894302d9fac66f3729458d158a08d5a9e682")
