-- Lua provided by RyzenAPI
-- Game: addappid(2152610)

-- MAIN APPLICATION
addappid(2152610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152611, 1, "36b78c5b56814ce5c2e7244482e239e522f10f22cb84d5a3d3449f0ee284c7e7")
