-- Lua provided by RyzenAPI
-- Game: Dandy: Or a Brief Glimpse Into the Life of the Candy Alchemist

-- MAIN APPLICATION
addappid(381610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(381611, 1, "3280616577bc07465512b8e95e3f7dbe5bc53c9ed3c8021f8d702c6019d1f599")
addappid(390060, 0, "b5146ff67e46982adcf6815d32d4db83599370a4d9591dc2f2a11787237d4143")

