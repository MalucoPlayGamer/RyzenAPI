-- Lua provided by SkyAPI 
-- Game: Dandy: Or a Brief Glimpse Into the Life of the Candy Alchemist
addappid(381610)
addappid(381611, 1, "3280616577bc07465512b8e95e3f7dbe5bc53c9ed3c8021f8d702c6019d1f599")
addappid(390060, 0, "b5146ff67e46982adcf6815d32d4db83599370a4d9591dc2f2a11787237d4143")
