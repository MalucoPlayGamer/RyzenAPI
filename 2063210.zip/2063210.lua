-- Lua provided by SkyAPI 
-- Game: AppID 2063210
addappid(2063210)
addappid(2063211, 1, "62ef0e7abfebd348ad3f544c11990780f9db8f3bbc2a1c679bdceffff2c0910a")
