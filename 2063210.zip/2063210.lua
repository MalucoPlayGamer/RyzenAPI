-- Lua provided by RyzenAPI
-- Game: AppID 2063210

-- MAIN APPLICATION
addappid(2063210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063211, 1, "62ef0e7abfebd348ad3f544c11990780f9db8f3bbc2a1c679bdceffff2c0910a")
