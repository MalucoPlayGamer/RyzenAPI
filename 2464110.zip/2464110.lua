-- Lua provided by RyzenAPI
-- Game: addappid(2464110)

-- MAIN APPLICATION
addappid(2464110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464110,0,"3b667b2daec7461c5f85d83ce5a4060d14d527c4d0c7b9955dc0a30d87a2231c")
