-- Lua provided by RyzenAPI
-- Game: Putinoids VS Navalnyats - Путиноиды Против Навальнят

-- MAIN APPLICATION
addappid(857020)

-- MAIN APP DEPOTS / PACKAGES
addappid(857021, 1, "2372fcb5efd80b8f885681dadf250bfc1e8f6c21d780a4388cda504c55db1a08")
addappid(858290, 0, "df268c207495c35d3f42cecec118b69beb0b6d250a00f86c5af1a246e4390036")

