-- Lua provided by RyzenAPI
-- Game: Game: AppID 990260

-- MAIN APPLICATION
addappid(990260)
-- Game: addappid(990260)

-- MAIN APP DEPOTS / PACKAGES
addappid(990261, 1, "2a1e109aa8f18d8d989c42c41232b0f70d707797347d3d9093275ac94c055f21")
