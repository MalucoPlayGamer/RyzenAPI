-- Lua provided by RyzenAPI 
-- Game: Bernie’s Nightmare
addappid(894390)
addappid(894391, 1, "5d00c2a0c438565d08cba8191926cc1cb146b4a84ae92b64e92390ee38d021ac")
