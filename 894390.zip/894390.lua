-- Lua provided by RyzenAPI
-- Game: Bernie’s Nightmare

-- MAIN APPLICATION
addappid(894390)
-- Game: addappid(894390)

-- MAIN APP DEPOTS / PACKAGES
addappid(894391, 1, "5d00c2a0c438565d08cba8191926cc1cb146b4a84ae92b64e92390ee38d021ac")
