-- Lua provided by RyzenAPI
-- Game: Battlemaster

-- MAIN APPLICATION
addappid(708590)

-- MAIN APP DEPOTS / PACKAGES
addappid(708591,0,"7a866be7bb44880329cfe8f38c9f1b22ffab6af5225112f8c6f370b5e36a8334")

