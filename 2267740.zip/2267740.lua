-- Lua provided by RyzenAPI
-- Game: 山海灵妖录

-- MAIN APPLICATION
addappid(2267740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267741, 1, "3695d7d7b4d6a0b40578230c2ab9c5d0301e9ba1c153b063678e53e76cfabec6")
