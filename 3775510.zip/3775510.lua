-- Lua provided by RyzenAPI
-- Game: Duckoleon

-- MAIN APPLICATION
addappid(3775510)
