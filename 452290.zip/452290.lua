-- Lua provided by RyzenAPI
-- Game: Rage Soundtrack

-- MAIN APPLICATION
addappid(452290)

-- MAIN APP DEPOTS / PACKAGES
addappid(452290,0,"0a01c7677b15a391f3ff388a75d8d45ee44e48739bbd10466e33677e5f39891b")

