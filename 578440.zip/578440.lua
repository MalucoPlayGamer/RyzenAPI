-- Lua provided by SkyAPI 
-- Game: 冒险村传说（Tales of Legends）
addappid(578440)
addappid(578441, 1, "f296b94100d1ff36cefc5219c0b0b38dc6e0aa6d2cc44d9de78cc46bd1082df2")
addappid(578442, 1, "dfc07870c16254d7dbae2bd3e234c13ff69073bf5a9b36a92ed00d72142185e1")
addappid(578443, 1, "9048107c67789b22a26b568948313e20a3987df2491d843dbb15809a156882b6")
