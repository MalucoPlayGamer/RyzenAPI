-- Lua provided by RyzenAPI
-- Game: Street Hero

-- MAIN APPLICATION
addappid(1274820)
-- Game: addappid(1274820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274821, 1, "2db22fce55aa5382b24b5617854a11ceef7896c9c731b35b4ae30a0c4183902e")
