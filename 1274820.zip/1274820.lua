-- Lua provided by SkyAPI 
-- Game: Street Hero
addappid(1274820)
addappid(1274821, 1, "2db22fce55aa5382b24b5617854a11ceef7896c9c731b35b4ae30a0c4183902e")
