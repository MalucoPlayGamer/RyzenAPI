-- Lua provided by RyzenAPI
-- Game: Diner Dash:® Hometown Hero™

-- MAIN APPLICATION
addappid(37240)

-- MAIN APP DEPOTS / PACKAGES
addappid(37241, 1, "69ae4ddced095c0ef93663bccb3966bc91628a6bb94d2d05ab0cda1a17ca0a3f")
