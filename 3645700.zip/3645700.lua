-- Lua provided by RyzenAPI
-- Game: What Happened to Lily?

-- MAIN APPLICATION
addappid(3645700)
-- Game: addappid(3645700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645701, 1, "1e65d733ce97e22bf423d0c5a492fad8f65c7ca9d2af186096d82963bff8939b")
