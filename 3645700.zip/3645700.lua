-- Lua provided by RyzenAPI
-- Game: What Happened to Lily?

-- MAIN APPLICATION
addappid(3645700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645701, 1, "1e65d733ce97e22bf423d0c5a492fad8f65c7ca9d2af186096d82963bff8939b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
