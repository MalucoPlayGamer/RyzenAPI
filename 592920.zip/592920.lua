-- Lua provided by RyzenAPI
-- Game: addappid(592920)

-- MAIN APPLICATION
addappid(592920)

-- MAIN APP DEPOTS / PACKAGES
addappid(592921, 1, "33e6df063ebb0b5fd72b5554d4e539c772ffbe894fb25263e4145e908c6b9640")
