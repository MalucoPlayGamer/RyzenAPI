-- Lua provided by RyzenAPI
-- Game: addappid(1329590)

-- MAIN APPLICATION
addappid(1329590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329590,0,"24084a5e225c890ec4216fd4be7a0d735a9c3de9cea5b335c7c40968a70927c6")
