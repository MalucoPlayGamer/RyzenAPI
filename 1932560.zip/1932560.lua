-- Lua provided by RyzenAPI
-- Game: 1932560

-- MAIN APPLICATION
addappid(1932560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932562,0,"466e9528ec36cdce26c8c1d837e589b26effa9d9ac08e0cca79d7d14c982e77e")
