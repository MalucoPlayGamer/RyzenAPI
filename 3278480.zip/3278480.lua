-- Lua provided by RyzenAPI
-- Game: Game: What a Shitty Job

-- MAIN APPLICATION
addappid(3278480)
-- Game: addappid(3278480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278481, 1, "13ddd42a7207f4891f82966867b31df96c67c66caa2d6b733c4425086c57ddc1")
