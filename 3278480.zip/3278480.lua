-- Lua provided by RyzenAPI
-- Game: What a Shitty Job

-- MAIN APPLICATION
addappid(3278480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3278481, 1, "13ddd42a7207f4891f82966867b31df96c67c66caa2d6b733c4425086c57ddc1")

