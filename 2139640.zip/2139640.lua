-- Lua provided by RyzenAPI
-- Game: 2139640

-- MAIN APPLICATION
addappid(2139640)
-- Game: addappid(2139640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139641, 1, "4268f60b4ebfbe055ef2b7a3809e5a6df1add04d6f6ac660025e0ba55e1e4281")
