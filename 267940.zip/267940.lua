-- Lua provided by RyzenAPI
-- Game: addappid(267940)

-- MAIN APPLICATION
addappid(267940)

-- MAIN APP DEPOTS / PACKAGES
addappid(267941, 1, "73981e6907cbbcd54ddd6b1f1f7288df73904413ecf2e9e375e7bf470cf7631b")
