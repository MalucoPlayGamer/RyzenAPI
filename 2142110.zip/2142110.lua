-- Lua provided by SkyAPI 
-- Game: VR Rock Climbing
addappid(2142110)
addappid(2142111, 1, "7ddf20d72c4cc6183ccb68387a1f4b01815f2d9e3960a9c8a8bd923169c8688b")
