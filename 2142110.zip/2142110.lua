-- Lua provided by RyzenAPI
-- Game: VR Rock Climbing

-- MAIN APPLICATION
addappid(2142110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142111, 1, "7ddf20d72c4cc6183ccb68387a1f4b01815f2d9e3960a9c8a8bd923169c8688b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
