-- Lua provided by RyzenAPI
-- Game: VR Rock Climbing

-- MAIN APPLICATION
addappid(2142110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142111, 1, "7ddf20d72c4cc6183ccb68387a1f4b01815f2d9e3960a9c8a8bd923169c8688b")

