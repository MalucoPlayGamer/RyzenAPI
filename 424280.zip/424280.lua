-- Lua provided by RyzenAPI
-- Game: 424280

-- MAIN APPLICATION
addappid(424280)
addappid(826650)
-- Game: addappid(424280)

-- MAIN APP DEPOTS / PACKAGES
addappid(424281, 1, "0179f2537d1050e6c5e90067c4392ff3eeb55a7868c260567d322d57c5d0b65c")
addappid(424282, 1, "d422a4d1ea55b03843a61a668c86fdc4d5bba0b62059da5a8b9b952a452ee0fd")
addappid(424283, 1, "6d37044d73eb2a1d32b20cfc7ff981e28b009767d5db630d0750cd291b9d71bf")
