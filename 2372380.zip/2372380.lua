-- Lua provided by RyzenAPI
-- Game: Game: AppID 2372380

-- MAIN APPLICATION
addappid(2372380)
-- Game: addappid(2372380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372381, 1, "57aafd52ce67b87658e811d737f35b531e7714278deb35d901e5d9ab86ed8b75")
addappid(2430420, 0, "ad2b8460168eb81b71c9dd70fe0dbe85c4b16e5bf14556920220d757a41ef327")
