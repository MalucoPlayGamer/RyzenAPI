-- Lua provided by RyzenAPI
-- Game: addappid(483960)

-- MAIN APPLICATION
addappid(483960)

-- MAIN APP DEPOTS / PACKAGES
addappid(483961, 1, "0e75bb45da21ee1bcd2c8d5be618304bd6ca4813d062b7ab14466499c35043ab")
