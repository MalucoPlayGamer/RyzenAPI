-- Lua provided by RyzenAPI 
-- Game: Invaders Tower Defense Online
addappid(2826540)
addappid(2826541, 1, "1d2f7f6b8816784972ce9e6f9591ea38e2f6a804294927d141c8c440ef82c965")
