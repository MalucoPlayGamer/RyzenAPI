-- Lua provided by RyzenAPI
-- Game: Invaders Tower Defense Online

-- MAIN APPLICATION
addappid(2826540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2826541, 1, "1d2f7f6b8816784972ce9e6f9591ea38e2f6a804294927d141c8c440ef82c965")

