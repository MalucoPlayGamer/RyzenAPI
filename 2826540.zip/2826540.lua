-- Lua provided by RyzenAPI
-- Game: Game: Invaders Tower Defense Online

-- MAIN APPLICATION
addappid(2826540)
-- Game: addappid(2826540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826541, 1, "1d2f7f6b8816784972ce9e6f9591ea38e2f6a804294927d141c8c440ef82c965")
