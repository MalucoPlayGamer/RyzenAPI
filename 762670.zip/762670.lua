-- Lua provided by RyzenAPI
-- Game: Astro Joust

-- MAIN APPLICATION
addappid(762670)

-- MAIN APP DEPOTS / PACKAGES
addappid(762671, 1, "d9d4b9ea4dc866a08c89aa81cf0b53f45884a5cbcbfd0b4709fd2f1c51484bdd")
