-- Lua provided by RyzenAPI
-- Game: Candy Blast

-- MAIN APPLICATION
addappid(474050)

-- MAIN APP DEPOTS / PACKAGES
addappid(474051, 1, "ae1024843971378c13b5706e144b363cb3249217988c2f6c0dda3404a0d8e81e")
