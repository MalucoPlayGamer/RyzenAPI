-- Lua provided by RyzenAPI
-- Game: Skel Dungeon Demo

-- MAIN APPLICATION
addappid(3173770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173771, 1, "aa84ee42d3b83d608fb89752c72e7e4f5f57ccc3636a4c8040fa9b95a0bc3674")
