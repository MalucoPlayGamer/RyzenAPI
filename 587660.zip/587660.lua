-- Lua provided by RyzenAPI
-- Game: Leaving Lyndow Original Soundtrack

-- MAIN APPLICATION
addappid(587660)

-- MAIN APP DEPOTS / PACKAGES
addappid(587660,0,"b58ba3e7cf8b279ec474e46e74c82ce7b24e74b889819218e921c0489fc84c74")

