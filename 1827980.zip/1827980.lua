-- Lua provided by RyzenAPI
-- Game: Idle Spiral

-- MAIN APPLICATION
addappid(1827980)
addappid(1935190)
addappid(1935210)
addappid(1935211)
addappid(1969890)
addappid(2018160)
addappid(2609010)
addappid(2673680)
addappid(2757040)
addappid(2798570)
addappid(2879010)
addappid(3045480)
addappid(5155410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827981, 1, "12fdbaa81e87b2ba832cc444ba006307f5a40623bd53f8e70ead9f41b0827243")

