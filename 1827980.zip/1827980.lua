-- Lua provided by RyzenAPI
-- Game: Idle Spiral

-- MAIN APPLICATION
addappid(1827980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827981, 1, "12fdbaa81e87b2ba832cc444ba006307f5a40623bd53f8e70ead9f41b0827243")
