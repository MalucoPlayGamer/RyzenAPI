-- Lua provided by RyzenAPI 
-- Game: Idle Spiral
addappid(1827980)
addappid(1827981, 1, "12fdbaa81e87b2ba832cc444ba006307f5a40623bd53f8e70ead9f41b0827243")
