-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Message in a Haunted Mansion

-- MAIN APPLICATION
addappid(615770)

-- MAIN APP DEPOTS / PACKAGES
addappid(615771, 1, "4cacc2c6c5df7a40bed09c29152d0577f68f3460bc91e7fa3c6fd6f5b946e4a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
