-- Lua provided by RyzenAPI
-- Game: addappid(615770)

-- MAIN APPLICATION
addappid(615770)

-- MAIN APP DEPOTS / PACKAGES
addappid(615771, 1, "4cacc2c6c5df7a40bed09c29152d0577f68f3460bc91e7fa3c6fd6f5b946e4a3")
