-- Lua provided by RyzenAPI
-- Game: Mana Gloom

-- MAIN APPLICATION
addappid(1453660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453661, 1, "2fb0972c7c71af1339c2d0e2b5210987cc6fde3553c72b182dd5baca5e36898d")

