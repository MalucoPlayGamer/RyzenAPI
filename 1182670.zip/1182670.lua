-- Lua provided by RyzenAPI
-- Game: AppID 1182670

-- MAIN APPLICATION
addappid(1182670)
-- Game: addappid(1182670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182671, 1, "2d533ee13edf42c60ee7a07402aa0fbd79082977a0820f82d5489664ee70c126")
