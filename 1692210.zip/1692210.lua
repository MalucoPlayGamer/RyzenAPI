-- Lua provided by RyzenAPI
-- Game: Trump Loves Russia

-- MAIN APPLICATION
addappid(1692210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1692211, 1, "792329d5ab00c0cfe731e339d2c392081b54db61aa67e505eef9d6b0a44524bf")

