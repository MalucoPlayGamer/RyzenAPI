-- Lua provided by RyzenAPI
-- Game: 1692210

-- MAIN APPLICATION
addappid(1692210)
-- Game: addappid(1692210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692211, 1, "792329d5ab00c0cfe731e339d2c392081b54db61aa67e505eef9d6b0a44524bf")
