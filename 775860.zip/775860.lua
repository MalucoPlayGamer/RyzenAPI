-- Lua provided by RyzenAPI
-- Game: Midnightland

-- MAIN APPLICATION
addappid(775860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(775861, 1, "d2adab5c0402fe5900dd72042fc0083ef8dd3cf37f99c98c66ea696f1d77bbc5")

