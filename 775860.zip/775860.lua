-- Lua provided by RyzenAPI
-- Game: AppID 775860

-- MAIN APPLICATION
addappid(775860)

-- MAIN APP DEPOTS / PACKAGES
addappid(775861, 1, "d2adab5c0402fe5900dd72042fc0083ef8dd3cf37f99c98c66ea696f1d77bbc5")

