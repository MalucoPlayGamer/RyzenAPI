-- Lua provided by RyzenAPI
-- Game: Game: AppID 1027820

-- MAIN APPLICATION
addappid(1027820)
-- Game: addappid(1027820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027821, 1, "e0041d8e846b6baabf2214988f78dbc49a631d0e2b3c3447fdde44faf39376ce")
