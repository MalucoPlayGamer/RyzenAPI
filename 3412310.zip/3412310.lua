-- Lua provided by RyzenAPI
-- Game: Aeternum Grand Plaza

-- MAIN APPLICATION
addappid(3412310)
-- Game: addappid(3412310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3412311, 1, "f389e67ab03c16c370a2cecc5cce44b5ee3233faeb4ff7aa945c2f3080e3a471")
