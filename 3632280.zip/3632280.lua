-- Lua provided by RyzenAPI
-- Game: AppID 3632280

-- MAIN APPLICATION
addappid(3632280)
-- Game: addappid(3632280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3632281, 1, "9486b855d432fe76937df553f2cfbf02de9fb621390d22c649454588bee295be")
