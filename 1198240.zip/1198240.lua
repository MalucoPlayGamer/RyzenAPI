-- Lua provided by RyzenAPI
-- Game: Danger City

-- MAIN APPLICATION
addappid(1198240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198242,0,"afc8a5d6339fd1eaa479cb910216ab5c66b0b032b4784f4804f7981aec5e2993")

