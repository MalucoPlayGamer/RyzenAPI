-- Lua provided by RyzenAPI
-- Game: Danger City

-- MAIN APPLICATION
addappid(1198240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198242,0,"afc8a5d6339fd1eaa479cb910216ab5c66b0b032b4784f4804f7981aec5e2993")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
