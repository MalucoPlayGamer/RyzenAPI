-- Lua provided by RyzenAPI
-- Game: Crime Shop Simulator: A Prison Boss Game

-- MAIN APPLICATION
addappid(2973830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973831, 1, "121a06c3d642b69345f6880ee9ee860dabbbf2783bd9fef529f10b9b62bfca9a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3751870)
addappid(3859360)
addappid(3859370)
addappid(3876280)
addappid(3876290)
addappid(3876320)
addappid(3876330)
addappid(3876340)
addappid(3876350)
addappid(3876360)
addappid(3876370)
addappid(3990130)
addappid(3990140)
addappid(3998130)
addappid(4025570)
addappid(4025580)
addappid(4058170)
addappid(4058180)
addappid(4094610)
addappid(4094630)
addappid(4094650)
addappid(4140840)
addappid(4200010)
addappid(4251340)
addappid(4263230)
addappid(4316250)
addappid(4316260)
addappid(4377650)
addappid(4377660)
addappid(4377670)
addappid(4377680)
