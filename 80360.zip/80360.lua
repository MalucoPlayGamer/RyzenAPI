-- Lua provided by RyzenAPI
-- Game: Blackwell Deception

-- MAIN APPLICATION
addappid(80360)
-- Game: addappid(80360)

-- MAIN APP DEPOTS / PACKAGES
addappid(80361, 1, "db0b8ca6e0d934118674c0febdd6bf5bd9e268285e9779a41a8f6a70463d77e3")
addappid(80362, 1, "07494fccb25aadce24eebb29e42b8e014c38b62ac2293f723b3dc4f38933e629")
addappid(80363, 1, "b4d0c88c95e72c22c09751958329268d58e0667ec6c11a1a8900bc22b23642c9")
addappid(2058290, 0, "0993d93602e1aad492173713b8f4f888d358d785dbda6f80878acfe71218eca7")
