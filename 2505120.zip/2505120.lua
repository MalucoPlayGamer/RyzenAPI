-- Lua provided by RyzenAPI
-- Game: Game: Plant Therapy

-- MAIN APPLICATION
addappid(2505120)
-- Game: addappid(2505120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505121, 1, "e5389e0f807dda0b689c597afc445ac3714b678b0b91566dbf7d55796c3d03e4")
addappid(2505122, 1, "52e0182bf691b244fbcb38e539624bde1804e51e7cd3ddc87b773768cc32ddf8")
