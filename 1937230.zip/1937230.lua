-- Lua provided by RyzenAPI
-- Game: Shatter Remastered Deluxe

-- MAIN APPLICATION
addappid(1937230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937231, 1, "d46e62fdda3cd0ba2ac410d9a4d9c4644ce6d7607ae9458e181382920b611340")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
