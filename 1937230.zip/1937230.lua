-- Lua provided by RyzenAPI
-- Game: Shatter Remastered Deluxe

-- MAIN APPLICATION
addappid(1937230)
-- Game: addappid(1937230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937231, 1, "d46e62fdda3cd0ba2ac410d9a4d9c4644ce6d7607ae9458e181382920b611340")
