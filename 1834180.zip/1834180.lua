-- Lua provided by RyzenAPI
-- Game: addappid(1834180)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1834180)
addappid(1834181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819242,0,"ec129fa0ec3545a4d90ed66cf6b57532b7bb564b45eba8a716e386c8ae621415")
addappid(1819243,0,"d79e15ca511544a00dcaf8c77f595fb5d0871984ab70aede178d6f56afc8858e")
