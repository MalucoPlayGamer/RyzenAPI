-- Lua provided by RyzenAPI
-- Game: Game: Cool Lady

-- MAIN APPLICATION
addappid(2507890)
-- Game: addappid(2507890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507891, 1, "71f5ddbade2111722dd89dda3d7e597935de41d6623b80d090a00bdde0b2355c")
