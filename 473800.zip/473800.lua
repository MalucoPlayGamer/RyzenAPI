-- Lua provided by RyzenAPI
-- Game: Game: AppID 473800

-- MAIN APPLICATION
addappid(473800)
-- Game: addappid(473800)

-- MAIN APP DEPOTS / PACKAGES
addappid(473801, 1, "ac98b9eb62f667490a255eb1941c18cd1b547d2a1fa0060d244c41076c228411")
