-- Lua provided by RyzenAPI
-- Game: 1865680

-- MAIN APPLICATION
addappid(1865680)
-- Game: addappid(1865680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865681, 1, "595ba44a57509f93ea1bba8f944f6e8e0f5d37ca24efc85bb8ee8ca02eeb59c0")
