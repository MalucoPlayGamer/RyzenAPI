-- Lua provided by RyzenAPI
-- Game: Dark Past Darker Future

-- MAIN APPLICATION
addappid(2473750)
-- Game: addappid(2473750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473751, 1, "071de635a501ceb66ed2f8047b1a6a0aefc6665f30a20c22ba3f70ed0341cdb8")
