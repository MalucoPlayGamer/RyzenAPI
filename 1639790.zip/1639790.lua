-- Lua provided by RyzenAPI
-- Game: Game: Northern Journey

-- MAIN APPLICATION
addappid(1639790)
-- Game: addappid(1639790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639791, 1, "97ed18f6885cfdb936911b4c194d6db7cdb2b4c1db61008f4c1f97cfff1798ee")
