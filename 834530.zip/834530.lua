-- Lua provided by RyzenAPI
-- Game: AppID 834530

-- MAIN APPLICATION
addappid(834530)

-- MAIN APP DEPOTS / PACKAGES
addappid(834531, 1, "64ebec3e0178f27e5d27d7cc4c91382ce5653dca2966989a8ee26574a83383d5")
addappid(834532, 1, "00ac0f337bbd03f1d6b4e25cbe12b68f9567b85b234bd69822a7cb22cfecb100")
addappid(834533, 1, "84c25831d0a0900169b6bd7540ec8ecb569e08ec283a37391d404c60a798d0c9")
addappid(834535, 1, "f9e85ff7b9d2d862bc853c14bc4e7e6773efdcdfd9028d7a196296a4926a63e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
