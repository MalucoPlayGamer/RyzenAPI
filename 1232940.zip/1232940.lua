-- Lua provided by RyzenAPI
-- Game: 1232940

-- MAIN APPLICATION
addappid(1232940)
-- Game: addappid(1232940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232941, 1, "270a178beca10146eeef4d1e780848ae09c9ac71fa974d539cf97378b8f945f2")
