-- Lua provided by RyzenAPI
-- Game: You Have to Play This Game

-- MAIN APPLICATION
addappid(1699320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699321, 1, "348a511fc9e4e597822facce545c8490db54b571adac20dad31e795b1826e0d7")

