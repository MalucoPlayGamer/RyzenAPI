-- Lua provided by RyzenAPI
-- Game: 1267860

-- MAIN APPLICATION
addappid(1267860)
-- Game: addappid(1267860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267861, 1, "b53dc7630c590a65f5ef7e57c42ab22deb6c066ccc0dc75463b146c1ca4c119c")
