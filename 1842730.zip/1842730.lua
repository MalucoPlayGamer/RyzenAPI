-- Lua provided by RyzenAPI
-- Game: Game: Nightmare: The Lunatic

-- MAIN APPLICATION
addappid(1842730)
-- Game: addappid(1842730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842731, 1, "2b5312ac42632fa61eddd3477e78096e265524b833b770c98ec1a0b77e6664e8")
