-- Lua provided by RyzenAPI
-- Game: Girls' civilization 2

-- MAIN APPLICATION
addappid(1354690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354691, 1, "f4dd185176f159df38bdb93f7dfb345aa9c73c6cacfc2eb7c80729c18de8733e")
