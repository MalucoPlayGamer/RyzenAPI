-- Lua provided by RyzenAPI
-- Game: Call of Girls

-- MAIN APPLICATION
addappid(4128590)

