-- Lua provided by RyzenAPI
-- Game: Game: Silent Slayer: Vault of the Vampire

-- MAIN APPLICATION
addappid(2923260)
-- Game: addappid(2923260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923261, 1, "c93960dc1c0490745da5dbc9a8c229852f68962e5ac0740aebf6bcac296faee2")
