-- Lua provided by SkyAPI 
-- Game: Silent Slayer: Vault of the Vampire
addappid(2923260)
addappid(2923261, 1, "c93960dc1c0490745da5dbc9a8c229852f68962e5ac0740aebf6bcac296faee2")
