-- Lua provided by RyzenAPI
-- Game: Dust & Neon

-- MAIN APPLICATION
addappid(1296450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296452,0,"fb14c30ed0fd40c5fb9bc73655d211672ddf5c859892e92a842ab8abfecbd3e2")
