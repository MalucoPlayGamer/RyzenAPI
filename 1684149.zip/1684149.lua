-- Lua provided by RyzenAPI
-- Game: addappid(1684149)

-- MAIN APPLICATION
addappid(1684149)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684149,0,"77aeba6f581723b36f199c2f84cf68952c6f03fa1e85b836d2206c2a8be06c05")
