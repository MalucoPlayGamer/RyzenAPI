-- Lua provided by RyzenAPI
-- Game: Quaver

-- MAIN APPLICATION
addappid(980610)

-- MAIN APP DEPOTS / PACKAGES
addappid(980611, 1, "418d82ef5ebf260ca48ddd96c01c1367ea2537b6367673b191ed585e25bb13c9")
addappid(980612, 1, "495de73db17a910672e29996fb7c6aee64bfd7429cfb3a516faffc490749fca6")
addappid(980613, 1, "a93064f352649bfe89c511446784777b7d1e33651c7c7233ecc9ceb882ec803a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
