-- Lua provided by RyzenAPI
-- Game: Quaver

-- MAIN APPLICATION
addappid(980610)
-- Game: addappid(980610)

-- MAIN APP DEPOTS / PACKAGES
addappid(980611, 1, "418d82ef5ebf260ca48ddd96c01c1367ea2537b6367673b191ed585e25bb13c9")
addappid(980612, 1, "495de73db17a910672e29996fb7c6aee64bfd7429cfb3a516faffc490749fca6")
addappid(980613, 1, "a93064f352649bfe89c511446784777b7d1e33651c7c7233ecc9ceb882ec803a")
