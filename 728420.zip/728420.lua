-- Lua provided by RyzenAPI
-- Game: addappid(728420)

-- MAIN APPLICATION
addappid(728420)

-- MAIN APP DEPOTS / PACKAGES
addappid(728421, 1, "2a43a8f3e5ee9a4965d9b5f6d747963eb64ef574ca047cff71233c80279adc3e")
