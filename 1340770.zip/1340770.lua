-- Lua provided by RyzenAPI
-- Game: Game: Artifacts

-- MAIN APPLICATION
addappid(1340770)
-- Game: addappid(1340770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340771, 1, "065dd851b701ea27608a70cd0de402e6322bd9aec84ee9cab6e9f5cc912df52c")
