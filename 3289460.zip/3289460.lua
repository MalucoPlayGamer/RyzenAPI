-- Lua provided by RyzenAPI
-- Game: 3289460

-- MAIN APPLICATION
addappid(3289460)
-- Game: addappid(3289460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289461, 1, "c626b1489cd125f9024b2e801e5bfd478c101fa6874e3dd14c824bdb91afc877")
