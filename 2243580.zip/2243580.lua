-- Lua provided by RyzenAPI
-- Game: Food Fight: Culinary Combat

-- MAIN APPLICATION
addappid(2243580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243581, 1, "f87f62d422dda4e118b87ef21ca9b6786df9912bdc021f6605d4b3c514269084")
