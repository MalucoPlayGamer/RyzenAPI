-- Lua provided by RyzenAPI
-- Game: addappid(498050)

-- MAIN APPLICATION
addappid(498050)

-- MAIN APP DEPOTS / PACKAGES
addappid(498051, 1, "83d03a486a50b06e49ba8d75e5e27bb042caf31706add0cf292aacdef389c6d6")
