-- Lua provided by RyzenAPI
-- Game: 2437950

-- MAIN APPLICATION
addappid(2437950)
-- Game: addappid(2437950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437951, 1, "e5dc72ead6173e5446c07c92fed3323dacc61320161d7eab1580f2763a7b5e4a")
