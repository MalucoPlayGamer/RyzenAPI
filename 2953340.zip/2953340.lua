-- Lua provided by RyzenAPI
-- Game: Eye Of The Summoner

-- MAIN APPLICATION
addappid(2953340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2953341, 1, "2e4dfce3b542a2e1a0f870e14d9e1cc8fac5bb50f5f25d690262e03f9eb12da4")

