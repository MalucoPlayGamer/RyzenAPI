-- Lua provided by RyzenAPI
-- Game: Rubber Ducky and the Rainbow Gun

-- MAIN APPLICATION
addappid(416550)
addappid(420810)
addappid(436710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(416551, 1, "e486cb5fd68017ca7d4a16edd0f31a10fdb85f240b9432621ccfa3200be8e2a5")

