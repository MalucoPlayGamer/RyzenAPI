-- Lua provided by RyzenAPI
-- Game: Game: Rubber Ducky and the Rainbow Gun

-- MAIN APPLICATION
addappid(416550)
addappid(420810)
-- Game: addappid(416550)

-- MAIN APP DEPOTS / PACKAGES
addappid(416551, 1, "e486cb5fd68017ca7d4a16edd0f31a10fdb85f240b9432621ccfa3200be8e2a5")
