-- Lua provided by RyzenAPI
-- Game: DFF NT: Terra Branford Starter Pack

-- MAIN APPLICATION
addappid(1022446)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022446,0,"1700f3d071229dd592f4663fbb6879bde0f1c73b43d59d86b5b0c8bc04a21aa4")
