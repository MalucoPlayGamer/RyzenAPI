-- Lua provided by RyzenAPI 
-- Game: Swarm Simulator: Evolution
addappid(914320)
addappid(914321, 1, "6086fd7c3c4367df41a2a90e48d100e778590b32642c498d90a234ba1228d0bb")
addappid(914322, 1, "f5169668651a4325634efb645c42c68055bd01ea120765792884a4ad11576f41")
