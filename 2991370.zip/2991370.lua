-- Lua provided by RyzenAPI
-- Game: 佛兰德斯的狗 A Dog of Flanders Demo

-- MAIN APPLICATION
addappid(2991370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991371, 1, "27ecbe23f4043341d31e4660772c367410e89e717f9648444e7e5b91c744860a")
