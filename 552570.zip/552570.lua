-- Lua provided by RyzenAPI
-- Game: The New Queen

-- MAIN APPLICATION
addappid(552570)
-- Game: addappid(552570)

-- MAIN APP DEPOTS / PACKAGES
addappid(552571, 1, "948a06342040b5254fdb70b9e4df20b0c57a0b562fc514a4d51015dded330727")
