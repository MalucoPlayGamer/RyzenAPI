-- Lua provided by SkyAPI 
-- Game: The New Queen
addappid(552570)
addappid(552571, 1, "948a06342040b5254fdb70b9e4df20b0c57a0b562fc514a4d51015dded330727")
