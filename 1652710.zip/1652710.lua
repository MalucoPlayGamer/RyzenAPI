-- Lua provided by RyzenAPI
-- Game: 1652710

-- MAIN APPLICATION
addappid(1652710)
-- Game: addappid(1652710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652711, 1, "9c237c610de71fdc73379e70a116afdef402bd9e8dfeaa926b99722dc788d7d6")
