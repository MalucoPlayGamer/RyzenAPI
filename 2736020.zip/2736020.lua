-- Lua provided by RyzenAPI
-- Game: Fuck You Witch

-- MAIN APPLICATION
addappid(2736020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736021, 1, "3f8343ed6fe767d7d0390f44d78480a9b9b52a5f128000a87d3b0941fefe194b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
