-- Lua provided by RyzenAPI
-- Game: Meowingtons Simulator

-- MAIN APPLICATION
addappid(2766880)
-- Game: addappid(2766880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766881, 1, "b524e10d87897f889c694fca8bef892ebb2f7533bffe2231bca22cf1b3efba06")
