-- Lua provided by RyzenAPI
-- Game: Meowingtons Simulator

-- MAIN APPLICATION
addappid(2766880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2766881, 1, "b524e10d87897f889c694fca8bef892ebb2f7533bffe2231bca22cf1b3efba06")

