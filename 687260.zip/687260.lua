-- Lua provided by RyzenAPI
-- Game: addappid(687260)

-- MAIN APPLICATION
addappid(687260)

-- MAIN APP DEPOTS / PACKAGES
addappid(687261, 1, "ff3d2dd1487a9a94db6c10c283d9c82bbfcb85ab86ebdcaf6029554dc15e9b65")
addappid(706580, 0, "bf33e464ecafd0c8879a80e4859ba079ca57b6d241fdbfb83eec69cd0a3ed7bd")
