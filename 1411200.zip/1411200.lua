-- Lua provided by RyzenAPI
-- Game: addappid(1411200)

-- MAIN APPLICATION
addappid(1411200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411201, 1, "f5883390ff4c0278c324e4caf7c8b06b5122c81e86b32dfe6ef11c1f38ee90ef")
