-- Lua provided by RyzenAPI
-- Game: AppID 621810

-- MAIN APPLICATION
addappid(621810)
-- Game: addappid(621810)

-- MAIN APP DEPOTS / PACKAGES
addappid(621811, 1, "e83b4872e07a4b30f084575c3258b362909465a11e456c22caa4453d582eecfe")
