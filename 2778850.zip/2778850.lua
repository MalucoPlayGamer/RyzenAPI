-- Lua provided by RyzenAPI
-- Game: One Iced Latte With Your Breast Milk, Please!

-- MAIN APPLICATION
addappid(2778850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778851, 1, "da263295f5971d0856e89a87add4868f0da3e9b9ce3d178d226bdfb7347daee5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3815950)
addappid(3840520)
