-- Lua provided by SkyAPI 
-- Game: AppID 1358440
addappid(1358440)
addappid(1358441, 1, "e17f8f504f66a217fdd036742753c529f9fff4b97cfaf102242ddffc210866fc")
addappid(1358442, 1, "f5b3c5fb22f50c9be8d7acb995a527c5e2fc663a161eb373d5d384c0ea52c063")
