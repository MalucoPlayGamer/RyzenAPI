-- Lua provided by SkyAPI 
-- Game: Recon Quest
addappid(2684120)
addappid(2684121, 1, "1d4a73040d5462b8412f7571f00cf6552a38c8c9cacd015d49f1960dcba0886a")
