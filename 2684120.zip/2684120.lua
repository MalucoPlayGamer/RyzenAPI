-- Lua provided by RyzenAPI
-- Game: 2684120

-- MAIN APPLICATION
addappid(2684120)
-- Game: addappid(2684120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684121, 1, "1d4a73040d5462b8412f7571f00cf6552a38c8c9cacd015d49f1960dcba0886a")
