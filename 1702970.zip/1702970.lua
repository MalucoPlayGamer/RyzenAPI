-- Lua provided by RyzenAPI
-- Game: Kibbi Keeper

-- MAIN APPLICATION
addappid(1702970)
addappid(1811110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702971, 1, "a6a49a33147294d64b5e0aa74fbafb1d7799aa77ef0557f8d9dc6ee2cb0e1734")
addappid(1702972, 1, "2da7a80a6f519cca752ba1499e041ec3ef60e2aae92103524d2e539aaeefb7be")
