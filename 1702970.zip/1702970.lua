-- Lua provided by RyzenAPI
-- Game: Kibbi Keeper

-- MAIN APPLICATION
addappid(1702970)
addappid(1811110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702971, 1, "a6a49a33147294d64b5e0aa74fbafb1d7799aa77ef0557f8d9dc6ee2cb0e1734")
addappid(1702972, 1, "2da7a80a6f519cca752ba1499e041ec3ef60e2aae92103524d2e539aaeefb7be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
