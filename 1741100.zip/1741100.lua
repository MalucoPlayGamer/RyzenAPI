-- Lua provided by RyzenAPI
-- Game: AppID 1741100

-- MAIN APPLICATION
addappid(1741100)
-- Game: addappid(1741100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741101, 1, "19815b52497e30db552136be350de41fdcad1339b6c3d68fdcfa7254fc2d8103")
