-- Lua provided by SkyAPI 
-- Game: Chasing Sunsets
addappid(1783110)
addappid(1783111, 1, "9b79373b2eaee7f471d1120d7576c79379eb063eb22134c4687f813cd0b2d874")
