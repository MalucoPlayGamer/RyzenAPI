-- Lua provided by RyzenAPI
-- Game: 2499820

-- MAIN APPLICATION
addappid(2499820)
-- Game: addappid(2499820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499821, 1, "e931ffc2e8f8d2fffa2d1b4a5cdc0ec85fc3fcd8e99ac0284fb5c7eaf3e3707c")
