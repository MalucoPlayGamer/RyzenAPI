-- Lua provided by RyzenAPI
-- Game: HoneyHoneyHoney!

-- MAIN APPLICATION
addappid(1709590)
-- Game: addappid(1709590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709591, 1, "950490869252efe3826c2f1289abe6b8a87fdd4ef6dd369fc4ec539fc288fecf")
