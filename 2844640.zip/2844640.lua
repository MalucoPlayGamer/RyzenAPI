-- Lua provided by RyzenAPI
-- Game: addappid(2844640)

-- MAIN APPLICATION
addappid(2844640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844640,0,"63d1ea26cbe949dd050bce4dc27adfdbab44a753c6b5beed044c41e401159e84")
