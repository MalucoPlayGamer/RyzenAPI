-- Lua provided by RyzenAPI
-- Game: The Braves

-- MAIN APPLICATION
addappid(2479830)
