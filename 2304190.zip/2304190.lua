-- Lua provided by RyzenAPI
-- Game: Deep Death Dungeon Darkness

-- MAIN APPLICATION
addappid(2304190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304191, 1, "34371aae79298d916b5fc535fed1263201e77a824653f48eeac61579d88160e2")

