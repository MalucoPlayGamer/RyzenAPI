-- Lua provided by RyzenAPI
-- Game: Game: AppID 887060

-- MAIN APPLICATION
addappid(887060)
-- Game: addappid(887060)

-- MAIN APP DEPOTS / PACKAGES
addappid(887061, 1, "619d82d4d552e56df7ec931498c5935025845cb20227c8697d88e448afbb2034")
