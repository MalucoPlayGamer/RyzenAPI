-- Lua provided by RyzenAPI
-- Game: One Night Two Crazies

-- MAIN APPLICATION
addappid(509290)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(509291, 1, "9e366cbdb4f56494c95dc0044450b5059e7786a5222526a3f6555bd1d0a01d82")

