-- Lua provided by RyzenAPI
-- Game: 509290

-- MAIN APPLICATION
addappid(509290)
-- Game: addappid(509290)

-- MAIN APP DEPOTS / PACKAGES
addappid(509291, 1, "9e366cbdb4f56494c95dc0044450b5059e7786a5222526a3f6555bd1d0a01d82")
