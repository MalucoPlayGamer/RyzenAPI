-- Lua provided by RyzenAPI
-- Game: Robo Puzzle Smash

-- MAIN APPLICATION
addappid(792850)

-- MAIN APP DEPOTS / PACKAGES
addappid(792851,0,"4f0a0d939b95d7a6be60280d974bbc7110309abe729bda67dc89d9478e591d80")

