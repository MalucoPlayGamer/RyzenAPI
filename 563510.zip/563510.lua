-- Lua provided by RyzenAPI
-- Game: Game: AppID 563510

-- MAIN APPLICATION
addappid(563510)
-- Game: addappid(563510)

-- MAIN APP DEPOTS / PACKAGES
addappid(563511, 1, "b4cf3e21c70ce01e6c69decf20fdf1c1f44025ebcf9703125e07084385952c2f")
