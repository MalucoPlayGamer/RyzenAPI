-- Lua provided by RyzenAPI
-- Game: addappid(1693480)

-- MAIN APPLICATION
addappid(1693480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693481, 1, "7381efcb0021340459ca1db1a8dd3ee369cf660c73f67abe9c4e2995dc14f78e")
