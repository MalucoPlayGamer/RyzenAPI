-- Lua provided by RyzenAPI
-- Game: addappid(1119770)

-- MAIN APPLICATION
addappid(1119770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119771, 1, "6ab20ccd523089d46b014bd1d1dbceb4f5fa6ea9eca72e7af773d4ebe7d6499d")
