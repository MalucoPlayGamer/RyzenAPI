-- Lua provided by RyzenAPI
-- Game: Game: Bang Bang Fruit 3

-- MAIN APPLICATION
addappid(905350)
-- Game: addappid(905350)

-- MAIN APP DEPOTS / PACKAGES
addappid(905351, 1, "e3491794f8b3bcce581500889db7bb0ea79b87587d12979b643f6984b98a1f60")
