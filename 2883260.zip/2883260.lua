-- Lua provided by RyzenAPI
-- Game: AppID 2883260

-- MAIN APPLICATION
addappid(2883260)
-- Game: addappid(2883260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883261, 1, "f9b2914e5e1f16a2c22b74ea3024d88b136fa887cfcefd7ac2637af4c59d1a04")
