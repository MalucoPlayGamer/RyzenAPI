-- Lua provided by RyzenAPI
-- Game: Imperia Online

-- MAIN APPLICATION
addappid(424780)

-- MAIN APP DEPOTS / PACKAGES
addappid(424781, 1, "3456d6774f57423d0f4a60e725afb6d3c2cf2d42145f7723f2d254a2d82e5e31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
