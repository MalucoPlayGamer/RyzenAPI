-- Lua provided by RyzenAPI
-- Game: Imperia Online

-- MAIN APPLICATION
addappid(424780)

-- MAIN APP DEPOTS / PACKAGES
addappid(424781, 1, "3456d6774f57423d0f4a60e725afb6d3c2cf2d42145f7723f2d254a2d82e5e31")
