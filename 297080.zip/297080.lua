-- Lua provided by RyzenAPI
-- Game: Navpoint

-- MAIN APPLICATION
addappid(297080)

-- MAIN APP DEPOTS / PACKAGES
addappid(297081, 1, "3ee0b320b37628ad85f1dc07fe633ba884092271552c06f5d7bc565a40938e59")
