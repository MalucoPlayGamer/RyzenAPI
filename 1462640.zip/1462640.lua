-- Lua provided by RyzenAPI
-- Game: 1462640

-- MAIN APPLICATION
addappid(1462640)
addappid(1507920)
-- Game: addappid(1462640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462641, 1, "77c475d08f67a09d9da32cac186d938774a0a42117ccb348ca7acbb4157e103e")
