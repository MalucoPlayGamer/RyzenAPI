-- Lua provided by RyzenAPI
-- Game: Alien world Millionaire

-- MAIN APPLICATION
addappid(1462640)
addappid(1507920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462641, 1, "77c475d08f67a09d9da32cac186d938774a0a42117ccb348ca7acbb4157e103e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
