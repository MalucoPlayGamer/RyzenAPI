-- Lua provided by RyzenAPI
-- Game: addappid(2786570)

-- MAIN APPLICATION
addappid(2786570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786571, 1, "b445f8fcc99101aaa8d020e65a52e76948854ce06123fc3f51aa5e378c4dd64e")
