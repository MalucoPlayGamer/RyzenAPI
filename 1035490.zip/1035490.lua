-- Lua provided by RyzenAPI
-- Game: Game: EURGAVA™: Tomb of Senza

-- MAIN APPLICATION
addappid(1035490)
-- Game: addappid(1035490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035491, 1, "59b598b506a18a51759584e31682b13817c06f9d7e4094a742386998fc68a406")
