-- Lua provided by RyzenAPI
-- Game: Super Goribei

-- MAIN APPLICATION
addappid(789510)
-- Game: addappid(789510)

-- MAIN APP DEPOTS / PACKAGES
addappid(789511, 1, "d4240bc98d264243246538589efe42f41a1822a7212873a9f2fe73a61b818397")
