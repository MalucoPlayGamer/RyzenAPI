-- Lua provided by RyzenAPI
-- Game: Super Goribei

-- MAIN APPLICATION
addappid(789510)

-- MAIN APP DEPOTS / PACKAGES
addappid(789511, 1, "d4240bc98d264243246538589efe42f41a1822a7212873a9f2fe73a61b818397")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
