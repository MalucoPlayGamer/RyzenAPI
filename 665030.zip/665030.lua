-- Lua provided by RyzenAPI
-- Game: Zeran's Folly

-- MAIN APPLICATION
addappid(665030)
addappid(665970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(665031, 1, "157c22d581a03d55a39526b741968395f37e3be8ee794c8ed9ec6c546d15467e")
