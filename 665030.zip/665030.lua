-- Lua provided by RyzenAPI
-- Game: Game: AppID 665030

-- MAIN APPLICATION
addappid(665030)
addappid(665970)
-- Game: addappid(665030)

-- MAIN APP DEPOTS / PACKAGES
addappid(665031, 1, "157c22d581a03d55a39526b741968395f37e3be8ee794c8ed9ec6c546d15467e")
