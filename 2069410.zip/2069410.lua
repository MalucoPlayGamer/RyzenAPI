-- Lua provided by RyzenAPI
-- Game: addappid(2069410)

-- MAIN APPLICATION
addappid(2069410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069411, 1, "4e124d2cf577b414217166175786be454d88f7d9f6143de8b39eeadc0d4a8070")
