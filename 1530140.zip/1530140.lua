-- Lua provided by RyzenAPI
-- Game: addappid(1530140)

-- MAIN APPLICATION
addappid(1530140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530142,0,"efb0b5fa6f2d15256985bcb2ab409655b6756ac97ceebb435e223b3c87e5f861")
