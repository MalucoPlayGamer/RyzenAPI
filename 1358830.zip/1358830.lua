-- Lua provided by RyzenAPI
-- Game: Operator

-- MAIN APPLICATION
addappid(1358830)
-- Game: addappid(1358830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358831, 1, "e7128a8ecb7716cee76e76c63598851dd57883210e59a8af94a78528f8cf9930")
