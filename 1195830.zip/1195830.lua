-- Lua provided by RyzenAPI
-- Game: Created: July 03, 2026 at 13:38:58 EDT

-- MAIN APPLICATION
addappid(1196050)
addappid(1196060)
addappid(1196061)
addappid(1511443)
addappid(1511444)
addappid(1511445)
-- addappid(1195832) -- Depot 1195832 (empty depot)
-- addappid(1195833) -- Depot 1195833 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(1195830, 1, "1371995cf55ef7c809009f620f8444729141f13ba5f5ae22a251106d6018c860") -- 副作用之瞳 (Tlicolity Eyes)
addappid(1195831, 1, "e41b83baafb1a8aac9d209da7eccc81ed35764b60807c93ca378808d68318561") -- 副作用之瞳 (Tlicolity Eyes) Windows
addappid(1195834, 1, "384348353119d0bf69b3d8e89ca2811a89605dc68db83616709d4b91d0183491") -- 繁体中文语言包
addappid(1196050, 1, "44b0e7dc11ed591ccdd86aeb69f5e07ccf33888d0ca4c096da635f701ef65c35") --  -  - 副作用之瞳 - 第一卷 Depot
addappid(1196060, 1, "37678ee119faa924a2caa41e6c9780a594b223e419c0974cbfda122771a7f852") --  -  - 副作用之瞳 - 第二卷 Depot
addappid(1196061, 1, "58f91cb951ce7caf6f9036b7af56966e6546fbca7489b002ca5fd763597824e9") --  -  - 副作用之瞳 - 第三卷 Depot
addappid(1511443, 1, "e80f9cccc007c3154e50e7a7a8a5f664ebb88ccd75cdca46849230213680efe6") --    - Depot 1511443
addappid(1511444, 1, "336543be66ec8d2d2f734d3531e4d995cd39fef510c2bdc1592e516672f6dc94") --    - Depot 1511444
addappid(1511445, 1, "1d7760758ee00f67ee6c025e83966ad8688a298a77c77ac3727c3c5c1ddb237f") --    - Depot 1511445

