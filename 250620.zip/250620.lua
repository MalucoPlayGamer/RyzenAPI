-- Lua provided by RyzenAPI
-- Game: Among the Sleep - Enhanced Edition

-- MAIN APPLICATION
addappid(250620)
-- Game: addappid(250620)

-- MAIN APP DEPOTS / PACKAGES
addappid(250621, 1, "99f23e5a4e6a5b3bf98fb1887ad157255fa2fb65dce470d44881af234b9bd03c")
addappid(250622, 1, "467fd89330af4dbee884a07e04b8c4ddf127e4857daf99d9f1170991407da41c")
addappid(250623, 1, "043d7e9a5b3e0c8bfad4cdce8e1546130cbc954cb40534860708e30a5078cb62")
