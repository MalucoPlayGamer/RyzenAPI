-- Lua provided by RyzenAPI
-- Game: Hero of the Galactic Core

-- MAIN APPLICATION
addappid(659790)
-- Game: addappid(659790)

-- MAIN APP DEPOTS / PACKAGES
addappid(659791, 1, "1f9dee050ce7ebd5e32d9eb9af854f3b86cc82817941151e8915c46f0e3a06e2")
