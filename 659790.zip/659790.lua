-- Lua provided by SkyAPI 
-- Game: Hero of the Galactic Core
addappid(659790)
addappid(659791, 1, "1f9dee050ce7ebd5e32d9eb9af854f3b86cc82817941151e8915c46f0e3a06e2")
