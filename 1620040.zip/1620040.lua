-- Lua provided by RyzenAPI
-- Game: Nickelodeon Kart Racers 3: Slime Speedway

-- MAIN APPLICATION
addappid(1620040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620041, 1, "07eee0b2749bf114f34b7b7d7526a2f0cf9d63ce67defe221c1b110c41005aaa")
addappid(1938920, 0, "d102acc589c8fb53c4cd64f7521dd3e880a013f39afd70494b20ca203b190221")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
