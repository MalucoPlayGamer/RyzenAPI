-- Lua provided by RyzenAPI
-- Game: Game: AppID 779360

-- MAIN APPLICATION
addappid(779360)
-- Game: addappid(779360)

-- MAIN APP DEPOTS / PACKAGES
addappid(779361, 1, "d05fc9c9109244aaeb21fac764c91707c733094c1719ce70905716f0e96b14ce")
