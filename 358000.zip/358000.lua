-- Lua provided by RyzenAPI
-- Game: The Curse of Nordic Cove

-- MAIN APPLICATION
addappid(358000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(358001, 1, "b19bc9e1c06853f3f5fd6e56be4b9ffe4ccd8b7d8dc2aa013d7225e12785c180")

