-- Lua provided by RyzenAPI
-- Game: 358000

-- MAIN APPLICATION
addappid(358000)
-- Game: addappid(358000)

-- MAIN APP DEPOTS / PACKAGES
addappid(358001, 1, "b19bc9e1c06853f3f5fd6e56be4b9ffe4ccd8b7d8dc2aa013d7225e12785c180")
