-- Lua provided by SkyAPI 
-- Game: AppID 358000
addappid(358000)
addappid(358001, 1, "b19bc9e1c06853f3f5fd6e56be4b9ffe4ccd8b7d8dc2aa013d7225e12785c180")
