-- Lua provided by RyzenAPI
-- Game: Simplex Mundi

-- MAIN APPLICATION
addappid(912250)
-- Game: addappid(912250)

-- MAIN APP DEPOTS / PACKAGES
addappid(912251, 1, "6e46f48e0190d0ed3d14355080757291a15f67503483e5dec09f898942e475e8")
