-- Lua provided by RyzenAPI
-- Game: Pirate Code

-- MAIN APPLICATION
addappid(370120)
addappid(1318890)

-- MAIN APP DEPOTS / PACKAGES
addappid(370121, 1, "b4683c6dec89e376e4a86f069e3fd9715459b7093399dacb3e1b18ad51ca1675")
