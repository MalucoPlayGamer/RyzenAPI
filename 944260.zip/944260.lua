-- Lua provided by RyzenAPI
-- Game: GG Puzzler

-- MAIN APPLICATION
addappid(944260)
addappid(1090320)

-- MAIN APP DEPOTS / PACKAGES
addappid(944261, 1, "529dcec182ec48842a6786a4867f30cd322f00233d24fb465c479fda59697b05")

