-- Lua provided by RyzenAPI
-- Game: Cleopatra Fortune™ S-Tribute

-- MAIN APPLICATION
addappid(1913690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913691, 1, "9c72b50b30abd11e17e4e1e144cfaf24817cefa305518498aae4b3aab0a2442a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
