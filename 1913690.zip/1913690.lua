-- Lua provided by RyzenAPI
-- Game: Cleopatra Fortune™ S-Tribute

-- MAIN APPLICATION
addappid(1913690)
-- Game: addappid(1913690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913691, 1, "9c72b50b30abd11e17e4e1e144cfaf24817cefa305518498aae4b3aab0a2442a")
