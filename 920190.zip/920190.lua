-- Lua provided by RyzenAPI
-- Game: Greetings

-- MAIN APPLICATION
addappid(920190)

-- MAIN APP DEPOTS / PACKAGES
addappid(920191, 1, "80788992f21b35b5ab356cd3f41ef56c593338eb9fb9e728e0290416c6304fa6")
