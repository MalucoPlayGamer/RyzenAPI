-- Lua provided by RyzenAPI
-- Game: BeatPunk! Demo

-- MAIN APPLICATION
addappid(2302710)
-- Game: addappid(2302710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302711, 1, "019ca0035b744666a89ba9770c4e337a6306c57cc6a4ee951148e0246bd3c0ca")
