-- Lua provided by SkyAPI 
-- Game: Go Mecha Ball
addappid(2008510)
addappid(2008511, 1, "7604be3f1fa927ce9d29de68bb03a30149e5a6f96b512f49e2ca3bfe889c9b21")
