-- Lua provided by RyzenAPI
-- Game: addappid(2008510)

-- MAIN APPLICATION
addappid(2008510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008511, 1, "7604be3f1fa927ce9d29de68bb03a30149e5a6f96b512f49e2ca3bfe889c9b21")
