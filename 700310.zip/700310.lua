-- Lua provided by RyzenAPI
-- Game: Game: Music Racer 2000

-- MAIN APPLICATION
addappid(700310)
-- Game: addappid(700310)

-- MAIN APP DEPOTS / PACKAGES
addappid(700311, 1, "701f81aa57cc0a1ecabac280b74f871582f3187f30db749e44dc42c0cad07918")
