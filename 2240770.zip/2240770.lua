-- Lua provided by RyzenAPI
-- Game: One Lonely Outpost Demo

-- MAIN APPLICATION
addappid(2240770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240771, 1, "d2225d3b38bb0b7bd493b3879ee57bfc1b238788327e7fd86e9bdb1b06f7802d")
