-- Lua provided by RyzenAPI
-- Game: Children of the Nile: Alexandria

-- MAIN APPLICATION
addappid(17120)

-- MAIN APP DEPOTS / PACKAGES
addappid(17121, 1, "e4a82d2fc4ae1d790387a3c9947bbb3b114e43a7e9a215bc7f040c046ee9b090")
addappid(17122, 1, "0edca9b616f8736a8a7f028878dfa184a269c8ad8e8d1b522e93bdc7dba43991")
addappid(17123, 1, "e77d4a519ac4e8b8d3e4732ccb4140160f50806f0d548889372326714386fcf4")
addappid(17124, 1, "edde9ec580bb62db698d2801afbc864f5f13638bfbcd1a44072857dd4d5d1604")
addappid(17125, 1, "2f39c3add54f7a614ba0c99e14b3adfed3170045b25b3862da752ce11a66ea09")
addappid(17126, 1, "7426be8a90bbe3688b3fec76a327263b3bacd347ead30933d0a6efebd8fb590b")

