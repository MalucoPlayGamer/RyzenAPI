-- Lua provided by RyzenAPI
-- Game: Game: Super Daryl Deluxe

-- MAIN APPLICATION
addappid(361230)
addappid(828300)
-- Game: addappid(361230)

-- MAIN APP DEPOTS / PACKAGES
addappid(361231, 1, "70fa2bc57b678ebda9d1a073ed8afb4a2d46d053236e707481e40798585d4491")
