-- Lua provided by RyzenAPI
-- Game: Super Daryl Deluxe

-- MAIN APPLICATION
addappid(361230)
addappid(828300)

-- MAIN APP DEPOTS / PACKAGES
addappid(361231, 1, "70fa2bc57b678ebda9d1a073ed8afb4a2d46d053236e707481e40798585d4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
