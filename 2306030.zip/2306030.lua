-- Lua provided by RyzenAPI
-- Game: EBOLA VILLAGE

-- MAIN APPLICATION
addappid(2306030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306031, 1, "b717b1927d90220e4e426ec6f87854f67e2b94fa99b29aafbab8568e0eacb1db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
