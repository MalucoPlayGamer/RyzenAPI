-- Lua provided by RyzenAPI
-- Game: addappid(2306030)

-- MAIN APPLICATION
addappid(2306030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306031, 1, "b717b1927d90220e4e426ec6f87854f67e2b94fa99b29aafbab8568e0eacb1db")
