-- Lua provided by RyzenAPI
-- Game: Echobreaker

-- MAIN APPLICATION
addappid(4383700) -- Echobreaker

-- MAIN APP DEPOTS / PACKAGES
addappid(4383701, 1, "8275c377b2abe289875ae7cdba821bc80a8ea51fee500f142a4c83e68abc3d40") -- Depot 4383701

