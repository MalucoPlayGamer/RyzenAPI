-- 4383700's Lua and Manifest Created by Hubcap Manifest
-- Echobreaker
-- Created: August 06, 2026 at 13:50:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4383700) -- Echobreaker
-- MAIN APP DEPOTS
addappid(4383701, 1, "8275c377b2abe289875ae7cdba821bc80a8ea51fee500f142a4c83e68abc3d40") -- Depot 4383701
setManifestid(4383701, "5264275657417428629", 377204491)