-- Lua provided by RyzenAPI
-- Game: Game: AppID 489570

-- MAIN APPLICATION
addappid(489570)
-- Game: addappid(489570)

-- MAIN APP DEPOTS / PACKAGES
addappid(489571, 1, "5f2942875aa4a27048b7755b077ac90b13bc177a9c27260a69ebbe4e53980f76")
