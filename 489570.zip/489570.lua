-- Lua provided by RyzenAPI
-- Game: Antisphere

-- MAIN APPLICATION
addappid(489570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(489571, 1, "5f2942875aa4a27048b7755b077ac90b13bc177a9c27260a69ebbe4e53980f76")

