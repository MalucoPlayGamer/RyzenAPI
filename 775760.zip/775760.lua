-- Lua provided by RyzenAPI
-- Game: addappid(775760)

-- MAIN APPLICATION
addappid(775760)

-- MAIN APP DEPOTS / PACKAGES
addappid(775761, 1, "f63df48ad6ed92e3d2901f659093fa390e219dff94d7d69e86bdf325a4e0e2bd")
