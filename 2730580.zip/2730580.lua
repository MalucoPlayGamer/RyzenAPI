-- Lua provided by RyzenAPI
-- Game: MagicGirls★Shooting!!

-- MAIN APPLICATION
addappid(2730580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730581, 1, "e160822152c91d5d5fe91a51ed740283ba57ca1be202dc39ea69632ea602cdfe")

