-- Lua provided by RyzenAPI
-- Game: Bloons TD5

-- MAIN APPLICATION
addappid(306020)

-- MAIN APP DEPOTS / PACKAGES
addappid(306022,0,"af6c510d8e872e7e27afbd7c4326c200a1554a35edd96c37f8be3643a6abfc2f")
addappid(306023,0,"72b93511214ea34f78eb60c4015f585a1552a4ebc2e399138300e93afde703c7")

