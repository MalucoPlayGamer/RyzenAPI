-- Lua provided by RyzenAPI
-- Game: Bloons TD5

-- MAIN APPLICATION
addappid(306020)
addappid(691480)
addappid(691490)
addappid(691500)
addappid(691510)
addappid(692150)
addappid(692151)
addappid(692152)
addappid(692153)
addappid(820220)
addappid(820230)
addappid(820231)
addappid(820232)
addappid(949780)
addappid(2191990)
addappid(2191991)
addappid(2191992)
addappid(2191993)
addappid(2191994)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(306022,0,"af6c510d8e872e7e27afbd7c4326c200a1554a35edd96c37f8be3643a6abfc2f")
addappid(306023,0,"72b93511214ea34f78eb60c4015f585a1552a4ebc2e399138300e93afde703c7")

