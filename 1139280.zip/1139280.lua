-- Lua provided by RyzenAPI
-- Game: The Big Con

-- MAIN APPLICATION
addappid(1139280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139281, 1, "bea2e0a8d51dec0346ddb29aef2e8516336a1bbdc93ab08864c240ac926a5d54")
