-- Lua provided by RyzenAPI
-- Game: Game: Saturn Quest: R. U. N. E. 3000

-- MAIN APPLICATION
addappid(2170760)
-- Game: addappid(2170760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170761, 1, "c3c0bdeb7244eb0f54ed183b78c31de2c3074b011bbbb0c8214d0d2d7ca3bcc9")
