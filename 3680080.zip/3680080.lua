-- Lua provided by RyzenAPI 
-- Game: AI PAINTER: Painting Simulator
addappid(3680080)
addappid(3680081, 1, "efe5f9bb8d466c794bd780bac8c413f8b48584b06ae2b322466506fd628f945f")
