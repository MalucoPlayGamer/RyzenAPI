-- Lua provided by RyzenAPI
-- Game: 1946940

-- MAIN APPLICATION
addappid(1946940)
-- Game: addappid(1946940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946940,0,"e0ce221d03b8cd6506f746983bb3efc9c5da87a34230bf7ac17ababdeb6ceaef")
