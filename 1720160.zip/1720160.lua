-- Lua provided by RyzenAPI
-- Game: 旅者 Travelers

-- MAIN APPLICATION
addappid(1720160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720161, 1, "a06a1883b2463d6d04845f5bdc4752dbf23dab34d75f2f031693e53d20fbf065")
