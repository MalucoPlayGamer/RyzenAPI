-- Lua provided by RyzenAPI
-- Game: 1853790

-- MAIN APPLICATION
addappid(1853790)
-- Game: addappid(1853790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853791, 1, "d3783fd9f22f9850863f4fcbec006a7ea01478ff3bda0e5faa3dd53fbfa90aee")
