-- Lua provided by RyzenAPI
-- Game: PlayM2M Limited Access

-- MAIN APPLICATION
addappid(2570190)
-- Game: addappid(2570190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570191, 1, "c4b9978891aba6bd9768523db089d285d4856e2dd3e8b68c732fe9a619f85980")
