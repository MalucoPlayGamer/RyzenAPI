-- Lua provided by RyzenAPI 
-- Game: Castle Morihisa
addappid(1608040)
addappid(1608041, 1, "c9877a8e62c335e5d958a756d674106abe5556dc04da4cbfd3944b0e0cf72807")
addappid(2003680, 0, "491d189a245a85c406ee71ff46b421542688d34fa12c680da2d0613b8652d8f2")
