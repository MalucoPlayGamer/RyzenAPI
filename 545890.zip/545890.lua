-- Lua provided by RyzenAPI
-- Game: Game: Breaking Wheel

-- MAIN APPLICATION
addappid(545890)
-- Game: addappid(545890)

-- MAIN APP DEPOTS / PACKAGES
addappid(545891, 1, "9d810b3de2441f5bfdb3dd2ca3a37bb21c522ba94cfb228b80cdc155573731b2")
