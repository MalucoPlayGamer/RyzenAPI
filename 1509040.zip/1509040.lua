-- Lua provided by RyzenAPI
-- Game: Lonely Catgirl is the Purrfect Pussy

-- MAIN APPLICATION
addappid(1509040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509041, 1, "869b592ffebed11174276c447cf6305b052916c2ee048460984be7726d034755")
