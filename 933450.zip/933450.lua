-- Lua provided by RyzenAPI
-- Game: Wenjia

-- MAIN APPLICATION
addappid(933450)
addappid(983271)

-- MAIN APP DEPOTS / PACKAGES
addappid(933451, 1, "b445a2b180bb9ef40c1ed6209dfe7efa3b7f2d93b4d24f52348ce36f25a5d6c4")
addappid(983270, 0, "5373d9e52537f9867f3434f7326a38cdd4499a077e82c5271b79af97e8ebc37a")

