-- Lua provided by RyzenAPI
-- Game: 709720

-- MAIN APPLICATION
addappid(709720)
-- Game: addappid(709720)

-- MAIN APP DEPOTS / PACKAGES
addappid(709721, 1, "3af5404795f4d112b84da657bf57638985e5985a0862bd0da5e52a8c3485feeb")
