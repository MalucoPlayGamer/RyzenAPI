-- Lua provided by RyzenAPI
-- Game: 1831560

-- MAIN APPLICATION
addappid(1831560)
-- Game: addappid(1831560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831561, 1, "0cfd7019ef7615816e3a006c611e4b54babb7c97abcc92d142672f82fa41cf66")
