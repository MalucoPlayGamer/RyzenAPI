-- Lua provided by SkyAPI 
-- Game: Sprite Hunter
addappid(1831560)
addappid(1831561, 1, "0cfd7019ef7615816e3a006c611e4b54babb7c97abcc92d142672f82fa41cf66")
