-- Lua provided by RyzenAPI
-- Game: 603130

-- MAIN APPLICATION
addappid(603130)
addappid(603131)

-- MAIN APP DEPOTS / PACKAGES
addappid(603132,0,"96906ac923a9ed3427dd547fadcfc7564ba333ee44814f74df16f79fbe53d072")
