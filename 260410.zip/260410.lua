-- Lua provided by RyzenAPI
-- Game: Get Off My Lawn!

-- MAIN APPLICATION
addappid(260410)
-- Game: addappid(260410)

-- MAIN APP DEPOTS / PACKAGES
addappid(260411, 1, "b804bd964aaaf84990e9f825d655c95d973007993e5fe4c3cd6d68fdd1229256")
addappid(260412, 1, "7188006047bf1c6d207da047cd9bf7cffc0a385e4203b3288eae21f87ff16ddd")
