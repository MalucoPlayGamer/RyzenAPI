-- Lua provided by RyzenAPI
-- Game: Pocket Mini Golf 2

-- MAIN APPLICATION
addappid(2285980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285981, 1, "8ff14613665ae327290a7184316ecafc32b3e53248f217c72fb1ea54ccb97954")
