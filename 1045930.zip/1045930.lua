-- Lua provided by RyzenAPI
-- Game: addappid(1045930)

-- MAIN APPLICATION
addappid(1045930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045931, 1, "ce6b684f5ccc4e425cda0ed566a2292f8d7fbc45a49e89f11c3993e9ae9ada42")
