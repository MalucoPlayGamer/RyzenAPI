-- Lua provided by RyzenAPI
-- Game: Divenia

-- MAIN APPLICATION
addappid(950260)
-- Game: addappid(950260)

-- MAIN APP DEPOTS / PACKAGES
addappid(950262,0,"5f4476568630ca7b72161956d5194ef03b1964a41a7f794bb4329e8f7737e715")
