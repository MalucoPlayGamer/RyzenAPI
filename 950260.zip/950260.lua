-- Lua provided by RyzenAPI
-- Game: Divenia

-- MAIN APPLICATION
addappid(950260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(950262,0,"5f4476568630ca7b72161956d5194ef03b1964a41a7f794bb4329e8f7737e715")

