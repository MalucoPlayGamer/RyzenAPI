-- Lua provided by SkyAPI 
-- Game: Change
addappid(765640)
addappid(765641, 1, "e8730aa61cab043ab3c051b8235f5947b4089b0eb511cb580ddcf036e28188c9")
addappid(797050, 0, "fa62de300f5b5f032fccd1af31285844e8aa098c5bbe84f7473c2fd98ab7c525")
