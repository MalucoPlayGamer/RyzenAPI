-- Lua provided by RyzenAPI
-- Game: SIMULATTE - Coffee Shop Simulator

-- MAIN APPLICATION
addappid(1859640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1859641, 1, "82ee10e82bafbda7a72d0d1fd18761b05ec99837d363c70f189be5423b05c38d")

