-- Lua provided by RyzenAPI
-- Game: SIMULATTE - Coffee Shop Simulator

-- MAIN APPLICATION
addappid(1859640)
-- Game: addappid(1859640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859641, 1, "82ee10e82bafbda7a72d0d1fd18761b05ec99837d363c70f189be5423b05c38d")
