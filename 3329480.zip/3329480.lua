-- Lua provided by RyzenAPI
-- Game: addappid(3329480)

-- MAIN APPLICATION
addappid(3329480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329481, 1, "d95f0953949b7a479e71f2dc681ac5fa21e94d3d3ca28228dfdb5da6fe16820d")
