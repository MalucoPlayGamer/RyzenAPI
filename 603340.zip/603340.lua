-- Lua provided by RyzenAPI
-- Game: addappid(603340)

-- MAIN APPLICATION
addappid(603340)

-- MAIN APP DEPOTS / PACKAGES
addappid(603341, 1, "2478d5f3fa0c9c9540a3f18acbf67f91f1cce66bb37ecc1948b94f8bd52f80c5")
