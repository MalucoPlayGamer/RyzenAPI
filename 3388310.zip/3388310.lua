-- Lua provided by RyzenAPI
-- Game: The Scouring Playtest

-- MAIN APPLICATION
addappid(3388310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388311, 1, "855597ff319ee3abc860ad3fab93128e2d9e6f1b39ae4ed5ec33da7eb02b4ff6")

