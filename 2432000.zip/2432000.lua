-- Lua provided by RyzenAPI
-- Game: Game: Inside the Labs

-- MAIN APPLICATION
addappid(2432000)
-- Game: addappid(2432000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432001, 1, "8ce2fb839191aba193a6ee10513e8245ac4e08140822990268167ef78cd1cdd4")
