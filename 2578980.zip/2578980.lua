-- Lua provided by RyzenAPI
-- Game: Whispers of an Elven Captor

-- MAIN APPLICATION
addappid(2578980)
-- Game: addappid(2578980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578981, 1, "ea8e0d5f8d8a0f7a01fbb96c174df564b3a38c72a95855264f807cb7073df110")
