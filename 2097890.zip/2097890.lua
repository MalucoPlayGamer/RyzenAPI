-- Lua provided by RyzenAPI
-- Game: addappid(2097890)

-- MAIN APPLICATION
addappid(2097890)
addappid(2534270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097891, 1, "6081aecf20f8042d2de5cb4fb1eb5bad2ab38ca50655dec7bca0b38ab62226dd")
