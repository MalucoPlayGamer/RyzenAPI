-- Lua provided by RyzenAPI
-- Game: Skull Island: Rise of Kong

-- MAIN APPLICATION
addappid(2097890)
addappid(2534270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2097891, 1, "6081aecf20f8042d2de5cb4fb1eb5bad2ab38ca50655dec7bca0b38ab62226dd")

