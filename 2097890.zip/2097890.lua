-- Lua provided by RyzenAPI 
-- Game: Skull Island: Rise of Kong
addappid(2097890)
addappid(2097891, 1, "6081aecf20f8042d2de5cb4fb1eb5bad2ab38ca50655dec7bca0b38ab62226dd")
addappid(2534270)
