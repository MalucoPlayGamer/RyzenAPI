-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 女神転生外伝 新約ラストバイブルIII 夢幻の英雄

-- MAIN APPLICATION
addappid(2194300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194301, 1, "ecbecb194674d286e49848ecad06280b371a5573ace2fa44bc0869ac0ba14a77")

