-- Lua provided by RyzenAPI
-- Game: 2194300

-- MAIN APPLICATION
addappid(2194300)
-- Game: addappid(2194300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194301, 1, "ecbecb194674d286e49848ecad06280b371a5573ace2fa44bc0869ac0ba14a77")
