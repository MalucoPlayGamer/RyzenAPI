-- Lua provided by RyzenAPI
-- Game: Shaq Fu: A Legend Reborn

-- MAIN APPLICATION
addappid(496040)

-- MAIN APP DEPOTS / PACKAGES
addappid(496042,0,"ff1c1bfbf84ea5b89ed041aed1cd1a2f1907152a6f934f1f255a3d587aa6b2fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(646810)
