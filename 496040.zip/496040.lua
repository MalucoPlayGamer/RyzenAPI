-- Lua provided by RyzenAPI
-- Game: Shaq Fu: A Legend Reborn

-- MAIN APPLICATION
addappid(496040)

-- MAIN APP DEPOTS / PACKAGES
addappid(496042,0,"ff1c1bfbf84ea5b89ed041aed1cd1a2f1907152a6f934f1f255a3d587aa6b2fa")
