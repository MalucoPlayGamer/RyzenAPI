-- Lua provided by RyzenAPI
-- Game: Starri

-- MAIN APPLICATION
addappid(1940410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940411, 1, "9b8e637a79b05d4e54c8110ac2e616d78b821790597d08f8502e655a65077fad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
