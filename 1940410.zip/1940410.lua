-- Lua provided by RyzenAPI
-- Game: Game: Starri

-- MAIN APPLICATION
addappid(1940410)
-- Game: addappid(1940410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940411, 1, "9b8e637a79b05d4e54c8110ac2e616d78b821790597d08f8502e655a65077fad")
