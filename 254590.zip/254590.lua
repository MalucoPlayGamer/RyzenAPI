-- Lua provided by RyzenAPI
-- Game: Theme Park Studio

-- MAIN APPLICATION
addappid(254590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254591, 1, "381413a2bac99ed69a12eee9ec4a04582e760e0441907247fe3e53b33026847f")
addappid(254592, 1, "a0c6bf76bd21341b6199222ee480220c36a1630ec2c1b2a65eff08f914ec01a9")

