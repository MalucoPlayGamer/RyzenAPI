-- Lua provided by RyzenAPI
-- Game: Game: AppID 2775030

-- MAIN APPLICATION
addappid(2775030)
-- Game: addappid(2775030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775031, 1, "ac94d063e7b7f76f2645a016aabf6a154419efbd91e9196b75c9581806e85f9f")
