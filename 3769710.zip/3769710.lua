-- Lua provided by RyzenAPI
-- Game: The Masquerade

-- MAIN APPLICATION
addappid(3769710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3769711, 1, "038bc9c3d873ba1c7ae1aa6bbc2d3fd7a30fbf69857317239af7d47a9c47f40c")
