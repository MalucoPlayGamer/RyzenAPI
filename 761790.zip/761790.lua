-- Lua provided by RyzenAPI
-- Game: addappid(761790)

-- MAIN APPLICATION
addappid(761790)

-- MAIN APP DEPOTS / PACKAGES
addappid(761791, 1, "640def16056726e0aeffdd836748775eddaeba5eadc3e6f7ba8637c5cf5dff8b")
