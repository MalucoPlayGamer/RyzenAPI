-- Lua provided by RyzenAPI
-- Game: AppID 1363080

-- MAIN APPLICATION
addappid(1363080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1363081, 1, "28763f0001125b10d1d269c0655d8d3f9e6a7678dd9fed0af3f4a37701443e70")
addappid(2932660, 0, "1adba25f4fa5ce03145e033f1f027e5d411e8db2042fbad6317352153d507bfe")

