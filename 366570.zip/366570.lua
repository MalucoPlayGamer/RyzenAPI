-- Lua provided by RyzenAPI
-- Game: CastleAbra

-- MAIN APPLICATION
addappid(366570)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(366571, 1, "8b10505167cb02ae4ebbe437c38fee611ffdb24b955019d81b1ce5438adb60fd")

