-- Lua provided by RyzenAPI
-- Game: CastleAbra

-- MAIN APPLICATION
addappid(366570)

-- MAIN APP DEPOTS / PACKAGES
addappid(366571, 1, "8b10505167cb02ae4ebbe437c38fee611ffdb24b955019d81b1ce5438adb60fd")

