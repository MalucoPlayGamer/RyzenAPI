-- Lua provided by RyzenAPI
-- Game: AppID 2237040

-- MAIN APPLICATION
addappid(2237040)
-- Game: addappid(2237040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237041, 1, "138a4b95be4de5ba4ef0458ec506de47cd520e7268c2aaa56ac139af3ee4ed57")
