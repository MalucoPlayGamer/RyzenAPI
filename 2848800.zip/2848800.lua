-- Lua provided by RyzenAPI 
-- Game: Pup Champs
addappid(2848800)
addappid(2848801, 1, "ab7af0ad044e10a112c22e0d0a8a8531c00840ffd9e724e2b061b9c313084a34")
