-- Lua provided by RyzenAPI
-- Game: Game: AppID 332380

-- MAIN APPLICATION
addappid(332380)
addappid(485940)
-- Game: addappid(332380)

-- MAIN APP DEPOTS / PACKAGES
addappid(332381, 1, "6e7b5e51b185e32c7f4aa99dc7b567a3adf7e7073b45d42a6c7c5754fdac7026")
addappid(362950, 0, "150a6123dd49c29f4c46b12cd3f96caa6b23f48c159002ea41986469d9f4476a")
addappid(372280, 0, "3e2669cba25860f403c445764b5ac0b140b68c966a71b9b7609a72b6acc7e31a")
