-- Lua provided by SkyAPI 
-- Game: Star Shift Rebellion Soundtrack
addappid(2820050)
addappid(2820051, 1, "780b46824de0463961a0b1a6531f677f1cb66d14e78e957f7efc18f9490efc50")
