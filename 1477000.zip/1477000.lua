-- Lua provided by RyzenAPI
-- Game: Starship Turd Nugget: Too Cool For Stool

-- MAIN APPLICATION
addappid(1477000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1477003,0,"680c1bca4b05bd3903980106a1a933850c57f9790f59d05b4bc8b0eff6364320")

