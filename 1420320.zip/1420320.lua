-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Kanji Sudoku

-- MAIN APPLICATION
addappid(1420320)
-- Game: addappid(1420320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420321, 1, "5203a7ad73aa4d82428606e04c53a82148f505963a1de1226a3e38728735b223")
