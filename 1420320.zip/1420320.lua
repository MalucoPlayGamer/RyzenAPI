-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Kanji Sudoku

-- MAIN APPLICATION
addappid(1420320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1420321, 1, "5203a7ad73aa4d82428606e04c53a82148f505963a1de1226a3e38728735b223")

