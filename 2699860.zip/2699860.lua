-- Lua provided by RyzenAPI
-- Game: Yog-Sothoth's Yard - Official Picture Package

-- MAIN APPLICATION
addappid(2699860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699861, 1, "dc1387bdccecdee9d31a56f610f064b897eb03cabae90dccc9f14674211bd8fc")

