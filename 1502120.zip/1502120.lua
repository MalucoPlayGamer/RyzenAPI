-- Lua provided by RyzenAPI
-- Game: 疯狂炮炮捕鱼

-- MAIN APPLICATION
addappid(1502120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502122,0,"9976bcd86746cb70b46ae4e6fc2cac80432e7e5c55e4c532d97e8b9fc17dd3c8")
addtoken(1502120,7402660407823676780)

