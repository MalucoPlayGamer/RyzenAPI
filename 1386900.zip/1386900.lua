-- Lua provided by RyzenAPI
-- Game: Observer: System Redux

-- MAIN APPLICATION
addappid(1386900)
addappid(1396070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1386901, 1, "5d105f7b3b3220b1f700e1781be55447e3e30adedfc1698593d0ceb3b31e86e2")

