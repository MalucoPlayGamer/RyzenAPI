-- Lua provided by RyzenAPI
-- Game: Observer: System Redux

-- MAIN APPLICATION
addappid(1386900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386901, 1, "5d105f7b3b3220b1f700e1781be55447e3e30adedfc1698593d0ceb3b31e86e2")

