-- Lua provided by RyzenAPI
-- Game: Night Stroll Demo

-- MAIN APPLICATION
addappid(2514990)
-- Game: addappid(2514990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514992,0,"02a076f77316fb873ad9e4d8c3b52e7c7be62f9bb3043ddd7af23e405ce1ed5d")
addappid(2514993,0,"90fbf53aa6d1fdb411ffd548d00bcc7f286308aa88dc2993da25270ccb4ec44e")
addappid(2514994,0,"d7c176340ea04cbc8f4a1c624e6f011a96091d1ae43ad8c3e35dd0488e43cf56")
