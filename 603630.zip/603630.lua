-- Lua provided by RyzenAPI
-- Game: Game: AppID 603630

-- MAIN APPLICATION
addappid(603630)
-- Game: addappid(603630)

-- MAIN APP DEPOTS / PACKAGES
addappid(603631, 1, "b84d1b64d7ac2172fab3e90c2e17fe2ae12e88fc365304ad3196080d8edc8f6f")
