-- Lua provided by RyzenAPI
-- Game: Revenge Quest

-- MAIN APPLICATION
addappid(569130)

-- MAIN APP DEPOTS / PACKAGES
addappid(569131,0,"2981454faaaedce14179d344aa0a833cb603672a04695eb2cbc13dc7d1c9afb5")
addappid(569132,0,"ba2ff5fe68ebcdae4abee098659badf405e56f867cf536743e2c1fc7a4bc7a41")
addappid(569133,0,"0ae0dddea03b3d40345f6809b69612692e0220ae21e405db2d09a6995a21581d")

