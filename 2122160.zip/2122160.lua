-- Lua provided by RyzenAPI
-- Game: addappid(2122160)

-- MAIN APPLICATION
addappid(2122160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122160,0,"ff589ad77ada8969fd65402fc3cc9b52ac6e48fe16db534206b7017a9012d0ab")
