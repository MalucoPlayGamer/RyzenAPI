-- Lua provided by RyzenAPI
-- Game: 966370

-- MAIN APPLICATION
addappid(966370)
-- Game: addappid(966370)

-- MAIN APP DEPOTS / PACKAGES
addappid(966371, 1, "cba47235534dcec717a096ca1675825ad640f1a931af0f7c58a49b5d7a3d8aca")
