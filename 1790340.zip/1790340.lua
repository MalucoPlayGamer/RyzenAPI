-- Lua provided by RyzenAPI
-- Game: KUUKIYOMI: Consider It! ONLINE

-- MAIN APPLICATION
addappid(1790340)
-- Game: addappid(1790340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790341, 1, "d7b2d7534fc80b98f0e676e0503c44291d56ad6b048d7ec777511142ed4a7317")
