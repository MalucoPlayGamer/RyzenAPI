-- Lua provided by RyzenAPI
-- Game: Game: AppID 729580

-- MAIN APPLICATION
addappid(729580)
-- Game: addappid(729580)

-- MAIN APP DEPOTS / PACKAGES
addappid(729581, 1, "1cd043dce9377a1d2ed03acbc83afeed7dbea29a2e323049aa369c09a0736409")
