-- Lua provided by RyzenAPI
-- Game: Malzbie's Pinball Collection

-- MAIN APPLICATION
addappid(729580)
addappid(729600)
addappid(729620)
addappid(757920)
addappid(799090)
addappid(854230)
addappid(912850)
addappid(989680)
addappid(1040320)
addappid(1040350)

-- MAIN APP DEPOTS / PACKAGES
addappid(729581, 1, "1cd043dce9377a1d2ed03acbc83afeed7dbea29a2e323049aa369c09a0736409")
