-- Lua provided by RyzenAPI
-- Game: Squirrel Stapler

-- MAIN APPLICATION
addappid(2535830)
-- Game: addappid(2535830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535831, 1, "e84e32d735a12a291dd0612aab36e5a3eab6de0f0559ef47ebcf6c19feca58a4")
