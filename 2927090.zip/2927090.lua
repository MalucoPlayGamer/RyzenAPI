-- Lua provided by RyzenAPI 
-- Game: AppID 2927090
addappid(2927090)
addappid(2927091, 1, "7da69a3fac8164a90301a9039f69fb8236e91557d0e610098fe7baf368929dfe")
