-- Lua provided by RyzenAPI
-- Game: addappid(2927090)

-- MAIN APPLICATION
addappid(2927090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927091, 1, "7da69a3fac8164a90301a9039f69fb8236e91557d0e610098fe7baf368929dfe")
