-- Lua provided by RyzenAPI
-- Game: 1878850

-- MAIN APPLICATION
addappid(1878850)
-- Game: addappid(1878850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878852,0,"8ceca183bed532e8db70d3fee5d3d5fd52721fc9b94bc2828c7ea884ad2897b1")
