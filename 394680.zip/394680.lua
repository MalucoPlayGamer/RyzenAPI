-- Lua provided by RyzenAPI
-- Game: Mountain Crime: Requital

-- MAIN APPLICATION
addappid(394680)
addappid(394860)
addappid(394862)
addappid(394863)

-- MAIN APP DEPOTS / PACKAGES
addappid(394681, 1, "7215d3b52f4b764ca5262862f623887e5a2ed84d533eacf18a4002758212bfcd")
addappid(394861, 0, "336d3ecd1431f140b5cf020a6e0799b8ae570dac5bdebb450aa646ec7d8859d6")
addappid(394864, 0, "454e4b8ff574b5380e7feca20dfe721a67ea42fd4b581442726d9fa24e9460f8")

