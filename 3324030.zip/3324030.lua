-- Lua provided by RyzenAPI
-- Game: Game: 爱坤新手教程

-- MAIN APPLICATION
addappid(3324030)
-- Game: addappid(3324030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324031, 1, "23e042635f8f7c814201e1557f6f0982b5ac7b6a582746595d3b69e498741b81")
