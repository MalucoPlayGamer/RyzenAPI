-- Lua provided by RyzenAPI
-- Game: addappid(1490590)

-- MAIN APPLICATION
addappid(1490590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490595,0,"a827b67f1382505489379e4ab4bce7d738eddb7a2b63ffb5f5362541029cd8e4")
