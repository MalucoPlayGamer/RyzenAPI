-- Lua provided by RyzenAPI
-- Game: Have a Nice Death

-- MAIN APPLICATION
addappid(1740720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1740721, 1, "3d157af207a2219654574f372c41161daf4b1ca850b8a6967669c14a31dc302a")
addappid(2368520, 0, "84710e64a350b57f4d613117406856f8c14bcd42724b5c693e7833b0ea838631")
