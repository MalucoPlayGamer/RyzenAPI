-- Lua provided by RyzenAPI
-- Game: 1950990

-- MAIN APPLICATION
addappid(1950990)
-- Game: addappid(1950990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950991, 1, "b1f9049f2056e439545a8320efe6705b03f31bc8eb7edc8a545724e9dcac0009")
