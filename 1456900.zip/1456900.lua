-- Lua provided by RyzenAPI
-- Game: Labyrinth

-- MAIN APPLICATION
addappid(1456900)
-- Game: addappid(1456900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456901, 1, "2f1f53e65789876dde4abf88acb18c99ab33a27a36e4a147a255feb6bcb56147")
