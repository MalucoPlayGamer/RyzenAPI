-- Lua provided by RyzenAPI
-- Game: addappid(1878580)

-- MAIN APPLICATION
addappid(1878580)
addappid(1878581)
addappid(1878583)
addappid(1878584)
addappid(1878586)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878582,0,"f66b94f90ba81fd91b22cdc7d9a70ec408dc257af874caafae1c35683805b095")
