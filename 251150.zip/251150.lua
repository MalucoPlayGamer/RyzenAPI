-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails in the Sky

-- MAIN APPLICATION
addappid(251150)

-- MAIN APP DEPOTS / PACKAGES
addappid(251151, 1, "d3199057bf8105926a20079128863995cc7b73c3dd89cc2f808d92033f19f71d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
