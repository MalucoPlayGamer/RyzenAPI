-- Lua provided by RyzenAPI
-- Game: addappid(829590)

-- MAIN APPLICATION
addappid(829590)

-- MAIN APP DEPOTS / PACKAGES
addappid(829591, 1, "5a3688082c17e1eeb38542df01cc984d5d3e1ad294135bc3cb1109c34d321c96")
addappid(1178321, 0, "b87fb51f621665ab1ac25cb6d95844e72f59fbf1de4308a09fb63b40c5ea6e5e")
