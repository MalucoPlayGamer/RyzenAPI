-- Lua provided by RyzenAPI
-- Game: CryoFall

-- MAIN APPLICATION
addappid(829590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(829591, 1, "5a3688082c17e1eeb38542df01cc984d5d3e1ad294135bc3cb1109c34d321c96")
addappid(1178321, 0, "b87fb51f621665ab1ac25cb6d95844e72f59fbf1de4308a09fb63b40c5ea6e5e")

