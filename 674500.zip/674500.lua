-- Lua provided by RyzenAPI
-- Game: 674500

-- MAIN APPLICATION
addappid(674500)
-- Game: addappid(674500)

-- MAIN APP DEPOTS / PACKAGES
addappid(674501, 1, "320e7338972dc073f73a5ca52100db5c7a603fbbf2adc69aad696c938add913c")
addappid(1397490, 0, "544e7c288671abef6a6c5a3fcc9017bf565f0529662eb1d513dcdde8624d24d7")
