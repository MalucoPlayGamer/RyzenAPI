-- Lua provided by RyzenAPI
-- Game: AppID 796860

-- MAIN APPLICATION
addappid(796860)
-- Game: addappid(796860)

-- MAIN APP DEPOTS / PACKAGES
addappid(796861, 1, "ce659f6e1472cdb535fbd76d3d186080e51e793bdd551e4f6ac48596e6f060f9")
