-- Lua provided by SkyAPI 
-- Game: AppID 796860
addappid(796860)
addappid(796861, 1, "ce659f6e1472cdb535fbd76d3d186080e51e793bdd551e4f6ac48596e6f060f9")
