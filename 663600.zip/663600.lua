-- Lua provided by RyzenAPI
-- Game: Game: Genie

-- MAIN APPLICATION
addappid(663600)
-- Game: addappid(663600)

-- MAIN APP DEPOTS / PACKAGES
addappid(663601, 1, "28f18ad049213a33916f95134f03eb119de56c950947ba13d9076525bcf832b7")
