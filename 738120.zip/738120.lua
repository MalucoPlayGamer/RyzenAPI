-- Lua provided by RyzenAPI
-- Game: Game: AppID 738120

-- MAIN APPLICATION
addappid(738120)
-- Game: addappid(738120)

-- MAIN APP DEPOTS / PACKAGES
addappid(738121, 1, "23f9c21cc96303acfc43f94776963b71a531dac6e05536a6c011c0f8a3732d1d")
