-- Lua provided by RyzenAPI
-- Game: Game: Women's Prison

-- MAIN APPLICATION
addappid(2085410)
-- Game: addappid(2085410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085411, 1, "fa7000c23d973fad9934b66ec64b732e1db0357b5f9b9b2ef6808e6eb88affa6")
