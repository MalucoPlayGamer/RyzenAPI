-- Lua provided by RyzenAPI
-- Game: 1337890

-- MAIN APPLICATION
addappid(1337890)
-- Game: addappid(1337890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337891, 1, "40fb1cf6aa4fb344641076e3fd89a29ef31558be28e5a74ee5e540038eeaeb58")
