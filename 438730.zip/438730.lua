-- Lua provided by SkyAPI 
-- Game: Poly Towns
addappid(438730)
addappid(438731, 1, "f1138f34e003b13f21ce81aa5fd3f1ff4f3999f465e55703f8978f01c05b2fd0")
