-- Lua provided by RyzenAPI
-- Game: Game: Poly Towns

-- MAIN APPLICATION
addappid(438730)
-- Game: addappid(438730)

-- MAIN APP DEPOTS / PACKAGES
addappid(438731, 1, "f1138f34e003b13f21ce81aa5fd3f1ff4f3999f465e55703f8978f01c05b2fd0")
