-- Lua provided by RyzenAPI
-- Game: Together in Forgotten Lands

-- MAIN APPLICATION
addappid(3424990) -- Together in Forgotten Lands

-- MAIN APP DEPOTS / PACKAGES
addappid(3424991, 1, "5efd158781dec28df0963d3ba258a59eea208a01fe286f80fe08c3268e0a2b37") -- Depot 3424991

