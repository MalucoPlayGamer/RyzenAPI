-- 3424990's Lua and Manifest Created by Hubcap Manifest
-- Together in Forgotten Lands
-- Created: August 07, 2026 at 22:56:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3424990) -- Together in Forgotten Lands
-- MAIN APP DEPOTS
addappid(3424991, 1, "5efd158781dec28df0963d3ba258a59eea208a01fe286f80fe08c3268e0a2b37") -- Depot 3424991
setManifestid(3424991, "5985976907299931697", 7290801873)