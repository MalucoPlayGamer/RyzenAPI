-- Lua provided by RyzenAPI
-- Game: AppID 250680

-- MAIN APPLICATION
addappid(250680)

-- MAIN APP DEPOTS / PACKAGES
addappid(250681, 1, "320c8519ca67181883eaa2100900b792fc814a6680d219c223706aed80629ae9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
