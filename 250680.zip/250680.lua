-- Lua provided by RyzenAPI
-- Game: Game: AppID 250680

-- MAIN APPLICATION
addappid(250680)
-- Game: addappid(250680)

-- MAIN APP DEPOTS / PACKAGES
addappid(250681, 1, "320c8519ca67181883eaa2100900b792fc814a6680d219c223706aed80629ae9")
