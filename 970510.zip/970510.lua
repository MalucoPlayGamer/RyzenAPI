-- Lua provided by RyzenAPI
-- Game: AppID 970510

-- MAIN APPLICATION
addappid(970510)
-- Game: addappid(970510)

-- MAIN APP DEPOTS / PACKAGES
addappid(970511, 1, "c438bc8e08599b2d9b79556f692ab0790ed37e932e4efed138f8d1c86728f203")
