-- Lua provided by RyzenAPI
-- Game: Dead Island: Epidemic

-- MAIN APPLICATION
addappid(222900)
addappid(297911)

-- MAIN APP DEPOTS / PACKAGES
addappid(222901, 1, "3df5d26e21e9a3758e7ddcfa7ac42751c610e72c7477ad9140ca148e1f1ba20c")

