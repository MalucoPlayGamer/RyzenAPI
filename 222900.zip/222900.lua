-- Lua provided by RyzenAPI
-- Game: Dead Island: Epidemic

-- MAIN APPLICATION
addappid(222900)
addappid(297911)

-- MAIN APP DEPOTS / PACKAGES
addappid(222901, 1, "3df5d26e21e9a3758e7ddcfa7ac42751c610e72c7477ad9140ca148e1f1ba20c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(278700)
addappid(278701)
addappid(279100)
addappid(297910)
addappid(328802)
addappid(328803)
addappid(328804)
