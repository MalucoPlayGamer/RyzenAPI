-- Lua provided by SkyAPI 
-- Game: Living With Sister: Monochrome Fantasy - Expansion DLC
addappid(3062990)
addappid(3062991, 1, "c5ef48bd281fd9fa2a0f58271afb10e00623bdfe534a874521370383625a7175")
addappid(3062992, 1, "4cb983f7e363330d3da27cbe4fc083119cc928a0777f22fe93b61e294aae5412")
addappid(3062993, 1, "0a73d390eb7dca3a0177c8764144284b272fd58349bfb7b4ff1e4f55552d3cd8")
