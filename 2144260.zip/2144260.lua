-- Lua provided by RyzenAPI
-- Game: Game: Mobius’ Radio Waves

-- MAIN APPLICATION
addappid(2144260)
-- Game: addappid(2144260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144261, 1, "fd22ab011b91541aae1a351dbe35f6a2ef0c0abb65ef171375e2cab525b0449f")
