-- Lua provided by RyzenAPI
-- Game: 3470

-- MAIN APPLICATION
addappid(3470)
-- Game: addappid(3470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471, 1, "a8a0272d95cd1762c0553dabeeffe117b729cca65707d94f7aea9c0898eb60d7")
