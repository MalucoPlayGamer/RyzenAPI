-- Lua provided by RyzenAPI
-- Game: Hidden Shapes Animals - Jigsaw Puzzle Game

-- MAIN APPLICATION
addappid(1450310)
addappid(1599310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450311, 1, "9a020821eb8e8aee6ced2637c58e3c14962a069bd49f614ec484c68ff425d599")
