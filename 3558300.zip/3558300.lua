-- Lua provided by RyzenAPI
-- Game: addappid(3558300)

-- MAIN APPLICATION
addappid(3558300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558301, 1, "582b092dae4f5ec6d477ccddd06fdbf2c93dc8775375d68bbb68664ef2ad8b6a")
