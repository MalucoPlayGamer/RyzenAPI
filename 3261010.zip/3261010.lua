-- Lua provided by RyzenAPI
-- Game: East Trade Tycoon: Inheritance

-- MAIN APPLICATION
addappid(3261010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261011, 1, "8f8a5594624db1c37364fca6d784679c899df8c89df990fd4da88738234d6530")
