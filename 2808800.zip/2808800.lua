-- Lua provided by RyzenAPI
-- Game: 2808800

-- MAIN APPLICATION
addappid(2808800)
-- Game: addappid(2808800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808803,0,"fba900b0b2dd78ee162e15e95d93c97e6cccc1bbe87f8b1a68f9ca51bc3c318e")
