-- Lua provided by RyzenAPI
-- Game: addappid(2302460)

-- MAIN APPLICATION
addappid(2302460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302461, 1, "8dd20493318695fcea2490dae69e7e979eaaa75697542b85f0164cee82cc4260")
