-- Lua provided by RyzenAPI
-- Game: AppID 3159870

-- MAIN APPLICATION
addappid(3159870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159871, 1, "f387e2cbe87387bdf3e345447f7cb3f288a4a03103c0bd2c4af697ec2f3b1fb5")

