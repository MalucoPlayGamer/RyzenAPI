-- Lua provided by RyzenAPI
-- Game: Welcome to Hanwell

-- MAIN APPLICATION
addappid(611750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(611751, 1, "c6969ec92cae197b5572164d8da094a8cb3962c26568bcd68458b31d49eb0127")

