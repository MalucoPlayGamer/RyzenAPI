-- Lua provided by RyzenAPI
-- Game: 611750

-- MAIN APPLICATION
addappid(611750)
-- Game: addappid(611750)

-- MAIN APP DEPOTS / PACKAGES
addappid(611751, 1, "c6969ec92cae197b5572164d8da094a8cb3962c26568bcd68458b31d49eb0127")
