-- Lua provided by RyzenAPI
-- Game: Red Wings: American Aces

-- MAIN APPLICATION
addappid(1654680)
addappid(1744090)
addappid(1744091)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654681, 1, "56e4aacc141c91d6014b524ef3a0ec51520eb86f286059bd7d58ed8bbb6c4187")

