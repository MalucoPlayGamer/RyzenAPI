-- Lua provided by RyzenAPI
-- Game: addappid(1808490)

-- MAIN APPLICATION
addappid(1808490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808491, 1, "3e0a8be50689723c69f1a28f4b3e289836e285e3f34c040aa73d4940b838e8ec")
