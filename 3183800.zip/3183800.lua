-- Lua provided by RyzenAPI
-- Game: Game: Math in Space

-- MAIN APPLICATION
addappid(3183800)
-- Game: addappid(3183800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183801, 1, "195b6bdb73f0a15334e3622e628547a6650a22a1960b14d396ffd357eb82c719")
