-- Lua provided by RyzenAPI
-- Game: 3167820

-- MAIN APPLICATION
addappid(3167820)
-- Game: addappid(3167820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167821, 1, "7f621197be7caba0a57d5405368e55851c7ae367b80b91f0fe55c4aaaec6e28a")
