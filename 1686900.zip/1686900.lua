-- Lua provided by RyzenAPI
-- Game: AppID 1686900

-- MAIN APPLICATION
addappid(1686900)
-- Game: addappid(1686900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686901, 1, "cd048bb1a1a2be08d19364f9fa08e0d28563b3c971498ee896cc26671761967f")
