-- Lua provided by RyzenAPI
-- Game: 767100

-- MAIN APPLICATION
addappid(767100)
-- Game: addappid(767100)

-- MAIN APP DEPOTS / PACKAGES
addappid(767101, 1, "38c56afac43ce09a44f11ec7d7d7b801f22fd63228d318f30146faf594ecba82")
