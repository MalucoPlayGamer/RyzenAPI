-- Lua provided by RyzenAPI
-- Game: 2290010

-- MAIN APPLICATION
addappid(2290010)
-- Game: addappid(2290010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290011, 1, "e7696d567719b903e7afe6ec067a9d63a84b18361ff46f471f268edda32fa059")
