-- Lua provided by RyzenAPI
-- Game: Beyond the Wall

-- MAIN APPLICATION
addappid(2290010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290011, 1, "e7696d567719b903e7afe6ec067a9d63a84b18361ff46f471f268edda32fa059")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
