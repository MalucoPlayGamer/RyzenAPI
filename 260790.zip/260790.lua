-- Lua provided by RyzenAPI
-- Game: Game: 1001 Spikes

-- MAIN APPLICATION
addappid(260790)
-- Game: addappid(260790)

-- MAIN APP DEPOTS / PACKAGES
addappid(260791, 1, "63755527e56285d3e7264e05f17a06551854ce0ff1e0fc88ebba1d3e008d1c4c")
addappid(260792, 1, "69cc52eb8aa54a5a56b0524f047549c3cd2dda7e5e1b21790db8921f2a5bafa7")
addappid(260793, 1, "05dec127bb0e3b38610052718a893c9837e757259ae4d80228a11ae527929ea6")
