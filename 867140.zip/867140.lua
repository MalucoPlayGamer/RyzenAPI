-- Lua provided by RyzenAPI
-- Game: Game: AppID 867140

-- MAIN APPLICATION
addappid(867140)
-- Game: addappid(867140)

-- MAIN APP DEPOTS / PACKAGES
addappid(867141, 1, "4e1e684e1b1279b2e20c223e0d4560311fd04b279060e1155a5b56b99a004b57")
