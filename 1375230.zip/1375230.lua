-- Lua provided by RyzenAPI
-- Game: Longevity Party

-- MAIN APPLICATION
addappid(1375230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1375231, 1, "b5eb40021001838180c367eba23eaecd2b496535357413e19bf7baa4bab8ca12")

