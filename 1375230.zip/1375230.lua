-- Lua provided by RyzenAPI
-- Game: Longevity Party

-- MAIN APPLICATION
addappid(1375230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375231, 1, "b5eb40021001838180c367eba23eaecd2b496535357413e19bf7baa4bab8ca12")
