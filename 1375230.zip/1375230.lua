-- Lua provided by SkyAPI 
-- Game: Longevity Party
addappid(1375230)
addappid(1375231, 1, "b5eb40021001838180c367eba23eaecd2b496535357413e19bf7baa4bab8ca12")
