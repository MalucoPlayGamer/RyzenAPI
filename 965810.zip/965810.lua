-- Lua provided by RyzenAPI
-- Game: 965810

-- MAIN APPLICATION
addappid(965810)
-- Game: addappid(965810)

-- MAIN APP DEPOTS / PACKAGES
addappid(965811, 1, "6e208d5e4e670f7eab56635f18203f18665e4cc48e69e3191576f3677d8b415f")
