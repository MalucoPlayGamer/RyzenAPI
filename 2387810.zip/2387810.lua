-- Lua provided by RyzenAPI
-- Game: Mommy Simulator

-- MAIN APPLICATION
addappid(2387810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387811, 1, "66ac67ea5569f29ec23b65fdcf8b33b75e241d8c68b8b41dc7eb3cba9086391d")

