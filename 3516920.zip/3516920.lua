-- Lua provided by RyzenAPI
-- Game: Game: Happy Treasure King

-- MAIN APPLICATION
addappid(3516920)
-- Game: addappid(3516920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516921, 1, "0b4a8fa2d71ca8691863e4b1917feb07c3e3fa777d8aa75cf123c8a667603f47")
