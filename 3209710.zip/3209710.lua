-- Lua provided by RyzenAPI 
-- Game: Curtain Call Demo
addappid(3209710)
addappid(3209711, 1, "0f4107d655c1741d850b8f786ee52bcf21dc6ea4c1fe8065ea375f958a444f27")
