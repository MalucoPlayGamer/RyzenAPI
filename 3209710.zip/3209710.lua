-- Lua provided by RyzenAPI
-- Game: Game: Curtain Call Demo

-- MAIN APPLICATION
addappid(3209710)
-- Game: addappid(3209710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209711, 1, "0f4107d655c1741d850b8f786ee52bcf21dc6ea4c1fe8065ea375f958a444f27")
