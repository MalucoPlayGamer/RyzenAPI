-- Lua provided by RyzenAPI
-- Game: 350780

-- MAIN APPLICATION
addappid(350780)
-- Game: addappid(350780)

-- MAIN APP DEPOTS / PACKAGES
addappid(350781, 1, "a114db95d1085e7b1b3cdbaf61cbfb61beb60fd55025f16b5cbd1a6b1bb575c1")
