-- Lua provided by RyzenAPI
-- Game: Agarta

-- MAIN APPLICATION
addappid(1696670)
-- Game: addappid(1696670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696671, 1, "f0c5187586932aab4ceff218f71689d18bfffe527714f3fa2f7393cf7a7c410b")
