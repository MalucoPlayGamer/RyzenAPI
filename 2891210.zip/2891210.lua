-- Lua provided by RyzenAPI
-- Game: addappid(2891210)

-- MAIN APPLICATION
addappid(2891210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891211, 1, "a10036b2fbe8017687f7711f0694f926f09cd6b15f3da25b6f4c4fc1dcc4fc8e")
