-- Lua provided by RyzenAPI
-- Game: addappid(1831050)

-- MAIN APPLICATION
addappid(1831050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831051, 1, "8acb956313b90ec9d71e8f7a6c009d2f3d42a0c9ac0133a11ff7134acb7060da")
