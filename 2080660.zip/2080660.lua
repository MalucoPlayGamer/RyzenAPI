-- Lua provided by RyzenAPI
-- Game: addappid(2080660)

-- MAIN APPLICATION
addappid(2080660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080661, 1, "abe54730e31f9ebf55b9097770fbd9b5e1c5310f37ec76069ac34b4872684b67")
