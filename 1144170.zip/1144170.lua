-- Lua provided by RyzenAPI
-- Game: 1144170

-- MAIN APPLICATION
addappid(1144170)
-- Game: addappid(1144170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144171, 1, "cc916ff0dd902d534a7db44cb4e44fb9189c93f57496a0fe04993386cad07fe8")
addappid(1144172, 1, "7866450ebf86c6494e65decf81db813d50767e11011ce68bd17a1e9889efbf66")
