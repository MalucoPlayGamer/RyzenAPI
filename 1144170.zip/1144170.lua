-- 1144170's Lua and Manifest Created by Hubcap Manifest
-- Warhammer: Chaos & Conquest
-- Created: August 15, 2026 at 22:21:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1144170, 1, "5227e08c4c42aaed0affe665407b42c61fd17225c71355b9270970a471243d24") -- Warhammer: Chaos & Conquest
-- MAIN APP DEPOTS
addappid(1144171, 1, "cc916ff0dd902d534a7db44cb4e44fb9189c93f57496a0fe04993386cad07fe8") -- Warhammer: Chaos & Conquest PC
setManifestid(1144171, "2833253314635604688", 358271224)
addappid(1144172, 1, "7866450ebf86c6494e65decf81db813d50767e11011ce68bd17a1e9889efbf66") -- Warhammer: Chaos & Conquest Mac
setManifestid(1144172, "2303467266057434404", 719874996)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1170930) -- Warhammer Chaos  Conquest - Skullhunter Warlord Bundle
addtoken(1170930, "8720024612632592971")
addappid(1262740) -- Warhammer Chaos  Conquest - Tzeentch Warlord Bundle
addappid(1262741) -- Warhammer Chaos  Conquest - Khorne Warlords Bundle
addappid(1262742) -- Warhammer Chaos  Conquest - Skull Throne Bundle
addappid(1262743) -- Warhammer Chaos  Conquest - Starter Bundle
addappid(1289590) -- Legendary Khorne - White Dwarf Promotion