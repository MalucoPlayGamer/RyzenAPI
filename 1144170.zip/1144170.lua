-- Lua provided by RyzenAPI
-- Game: Warhammer: Chaos & Conquest

-- MAIN APPLICATION
addappid(1170930) -- Warhammer Chaos  Conquest - Skullhunter Warlord Bundle
addappid(1262740) -- Warhammer Chaos  Conquest - Tzeentch Warlord Bundle
addappid(1262741) -- Warhammer Chaos  Conquest - Khorne Warlords Bundle
addappid(1262742) -- Warhammer Chaos  Conquest - Skull Throne Bundle
addappid(1262743) -- Warhammer Chaos  Conquest - Starter Bundle
addappid(1289590) -- Legendary Khorne - White Dwarf Promotion

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(1144170, 1, "5227e08c4c42aaed0affe665407b42c61fd17225c71355b9270970a471243d24") -- Warhammer: Chaos & Conquest
addappid(1144171, 1, "cc916ff0dd902d534a7db44cb4e44fb9189c93f57496a0fe04993386cad07fe8") -- Warhammer: Chaos & Conquest PC
addappid(1144172, 1, "7866450ebf86c6494e65decf81db813d50767e11011ce68bd17a1e9889efbf66") -- Warhammer: Chaos & Conquest Mac
addtoken(1170930, "8720024612632592971")

