-- Lua provided by RyzenAPI
-- Game: Marble World

-- MAIN APPLICATION
addappid(1491340)
addappid(2223290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1491341, 1, "736d3a0eaa9d8c95d2f8792ecea4c729007e6983f6011d3f83d742707bdef70c")

