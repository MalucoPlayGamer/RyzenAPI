-- Lua provided by RyzenAPI
-- Game: Marble World

-- MAIN APPLICATION
addappid(1491340)
addappid(2223290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491341, 1, "736d3a0eaa9d8c95d2f8792ecea4c729007e6983f6011d3f83d742707bdef70c")

