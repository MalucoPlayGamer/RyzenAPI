-- Lua provided by RyzenAPI
-- Game: addappid(575690)

-- MAIN APPLICATION
addappid(575690)

-- MAIN APP DEPOTS / PACKAGES
addappid(575691, 1, "3c49e1ecb3f982bfc8128e68902632affac603cd3b530b023b9279d2df668287")
addappid(575692, 1, "3aecc0d4dc3ed8325d81d2d95a0f0d32f375362afbf2557cd31f94deab81f425")
