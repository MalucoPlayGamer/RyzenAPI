-- Lua provided by RyzenAPI
-- Game: Spycraft: The Great Game

-- MAIN APPLICATION
addappid(569220)

-- MAIN APP DEPOTS / PACKAGES
addappid(569221, 1, "ff4038fece9d30213377b08970a87d355254dc9f26cd912a549fa5f3c3d99c8d")
