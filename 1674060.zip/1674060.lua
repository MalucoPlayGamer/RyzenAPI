-- Lua provided by RyzenAPI
-- Game: Game: AppID 1674060

-- MAIN APPLICATION
addappid(1674060)
-- Game: addappid(1674060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674061, 1, "a9d6f241a5a82690ba1604dd5c52a6acf9df253b0198de4f13647e853ce93ca6")
