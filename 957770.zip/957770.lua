-- Lua provided by RyzenAPI
-- Game: WarpThrough

-- MAIN APPLICATION
addappid(957770)

-- MAIN APP DEPOTS / PACKAGES
addappid(957771, 1, "f3e0b703d3c1c9b09b299c7022186c510379463d5e38b1c55fc75436c2eba820")

