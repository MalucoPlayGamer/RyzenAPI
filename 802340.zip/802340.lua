-- Lua provided by RyzenAPI
-- Game: Archery Kings VR

-- MAIN APPLICATION
addappid(802340)

-- MAIN APP DEPOTS / PACKAGES
addappid(802341,0,"80684fa80ed0974b19f13a5615576abcb24d55f94d860f7cd03e82e23d3bb43f")

