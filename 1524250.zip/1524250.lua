-- Lua provided by RyzenAPI
-- Game: addappid(1524250)

-- MAIN APPLICATION
addappid(1524250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524251, 1, "9fc0d1144a61e7f988cb2dbf1055bce407b82c89229873201f79294fc061bad5")
