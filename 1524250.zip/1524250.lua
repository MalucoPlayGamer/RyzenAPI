-- Lua provided by RyzenAPI
-- Game: Survivor Dieland

-- MAIN APPLICATION
addappid(1524250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1524251, 1, "9fc0d1144a61e7f988cb2dbf1055bce407b82c89229873201f79294fc061bad5")

