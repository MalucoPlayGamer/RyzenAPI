-- Lua provided by RyzenAPI
-- Game: addappid(1791880)

-- MAIN APPLICATION
addappid(1791880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791881, 1, "77b89f28cd7ca1258a25269cb37d28fa83c38b6cc35f8a365c6e6d9cd5f6f280")
