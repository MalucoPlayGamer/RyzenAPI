-- Lua provided by RyzenAPI
-- Game: 3434930

-- MAIN APPLICATION
addappid(3434930)
-- Game: addappid(3434930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434931, 1, "8a38866e72b8d21f628123015ed44c99b53ace65ea4fcd0c7eafc70b386c5368")
