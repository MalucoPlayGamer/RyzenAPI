-- Lua provided by RyzenAPI
-- Game: 898350

-- MAIN APPLICATION
addappid(898350)
-- Game: addappid(898350)

-- MAIN APP DEPOTS / PACKAGES
addappid(898351, 1, "b42ca137d5c94d60e6747aa460aef54bd4c4bb8a29503350d64498f45a2cea18")
