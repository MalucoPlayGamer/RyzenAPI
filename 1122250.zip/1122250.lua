-- Lua provided by SkyAPI 
-- Game: THE FATE OF THE BULLY
addappid(1122250)
addappid(1122251, 1, "1b7ce3f9814146a1d4d3291eac081f3a51bacd2ee8f16f31f7114913d0b94d9b")
