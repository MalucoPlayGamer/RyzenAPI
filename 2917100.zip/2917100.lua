-- Lua provided by RyzenAPI
-- Game: AI探案集

-- MAIN APPLICATION
addappid(2917100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917101, 1, "8360e3880b64d9df72e05ecd5efaf1f220b4042df7957f8030ee7cc59145f3a3")
