-- Lua provided by RyzenAPI
-- Game: Hana's Campus Life

-- MAIN APPLICATION
addappid(1506930) -- Hana's Campus Life

-- MAIN APP DEPOTS / PACKAGES
addappid(1506931, 1, "8709064823ce8981699d456d6909bd440ab8796653f1a20292a4a6e60648824a") -- Depot 1506931

