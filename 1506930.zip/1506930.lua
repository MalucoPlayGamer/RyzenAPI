-- 1506930's Lua and Manifest Created by Hubcap Manifest
-- Hana's Campus Life
-- Created: August 03, 2026 at 22:41:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1506930) -- Hana's Campus Life
-- MAIN APP DEPOTS
addappid(1506931, 1, "8709064823ce8981699d456d6909bd440ab8796653f1a20292a4a6e60648824a") -- Depot 1506931
setManifestid(1506931, "3811245493668147443", 2710624205)