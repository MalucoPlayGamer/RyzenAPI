-- Lua provided by RyzenAPI
-- Game: 416350

-- MAIN APPLICATION
addappid(416350)
addappid(416351)
addappid(416353)
-- Game: addappid(416350)

-- MAIN APP DEPOTS / PACKAGES
addappid(416352,0,"edb9a8f15e5706f8ce69ed0b3d6ca347c76043429606fbc4d0f5df1ad3474861")
