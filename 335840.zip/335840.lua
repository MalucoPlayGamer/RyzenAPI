-- Lua provided by RyzenAPI
-- Game: Game: Goats on a Bridge

-- MAIN APPLICATION
addappid(335840)
-- Game: addappid(335840)

-- MAIN APP DEPOTS / PACKAGES
addappid(335841, 1, "e893cb5073341a2ff2a71ea8da97698661460168426906845dcde68851c2f83b")
addappid(349080, 0, "548031032ac55e4459aec91c8a21ab538549f9c6b71f529fa32b1cc460fe28dc")
