-- Lua provided by RyzenAPI
-- Game: AppID 1135060

-- MAIN APPLICATION
addappid(1135060)
-- Game: addappid(1135060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135061, 1, "93aba8fecf183083426e39aa00ce9cee213a3041255dd38f0ef24c71a4127f8e")
addappid(1135062, 1, "4d95c405b543fdb694ce16e5c1f0ab7f508b586a38d70c509a4d05596cdd1eb8")
