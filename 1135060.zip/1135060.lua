-- Lua provided by RyzenAPI
-- Game: Sokpop S01: King of the Sandcastle

-- MAIN APPLICATION
addappid(1135060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135061, 1, "93aba8fecf183083426e39aa00ce9cee213a3041255dd38f0ef24c71a4127f8e")
addappid(1135062, 1, "4d95c405b543fdb694ce16e5c1f0ab7f508b586a38d70c509a4d05596cdd1eb8")

