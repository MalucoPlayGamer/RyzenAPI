-- Lua provided by RyzenAPI
-- Game: SUPERHOT

-- MAIN APPLICATION
addappid(322500)

-- MAIN APP DEPOTS / PACKAGES
addappid(322501, 1, "d03db515479e54b594f98bcebca8c47627b0290928af9712a9929119f203d541")
addappid(322502, 1, "78a91342c79f05459baf6ee12e712b7738c786d2c0c97ae1cdd1722bc98ee763")
addappid(322503, 1, "9629b89103c3f9dfa467b53b6980207793790e0a0a48386cb9404ddd443ae0f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
