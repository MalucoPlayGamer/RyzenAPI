-- Lua provided by RyzenAPI
-- Game: Eryi's Action

-- MAIN APPLICATION
addappid(261700)

-- MAIN APP DEPOTS / PACKAGES
addappid(261701, 1, "7f6e26895102a8a1980260ecea9bd6cb2a14c6c254d93d44a823d4acca1c8909")
addappid(261702, 1, "c1abbb9a54245eab105454b536a5816719e435c82b647eec48cea274c4c65173")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
