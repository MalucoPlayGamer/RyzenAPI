-- Lua provided by RyzenAPI
-- Game: Game: Eryi's Action

-- MAIN APPLICATION
addappid(261700)
-- Game: addappid(261700)

-- MAIN APP DEPOTS / PACKAGES
addappid(261701, 1, "7f6e26895102a8a1980260ecea9bd6cb2a14c6c254d93d44a823d4acca1c8909")
addappid(261702, 1, "c1abbb9a54245eab105454b536a5816719e435c82b647eec48cea274c4c65173")
