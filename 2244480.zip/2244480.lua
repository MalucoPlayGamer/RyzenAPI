-- Lua provided by RyzenAPI 
-- Game: REMEDIUM: Sentinels
addappid(2244480)
addappid(2244481, 1, "1a34cc06be4514f464de7e542cf278832a521923c24551961a4487c3e121b025")
addappid(2244482, 1, "e239bc295952e8693f3de434ebc9ec5fdd4fbbb651d20068c79984e18465e601")
