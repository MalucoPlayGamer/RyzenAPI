-- Lua provided by RyzenAPI
-- Game: REMEDIUM: Sentinels

-- MAIN APPLICATION
addappid(2244480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2244481, 1, "1a34cc06be4514f464de7e542cf278832a521923c24551961a4487c3e121b025")
addappid(2244482, 1, "e239bc295952e8693f3de434ebc9ec5fdd4fbbb651d20068c79984e18465e601")

