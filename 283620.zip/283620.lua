-- Lua provided by RyzenAPI
-- Game: Game: AppID 283620

-- MAIN APPLICATION
addappid(283620)
-- Game: addappid(283620)

-- MAIN APP DEPOTS / PACKAGES
addappid(283621, 1, "5d45eec636b1631750e17070756aa199d43714f59a6a19b4eb011f164d434344")
addappid(283622, 1, "0ebf992fda940109b52a53ebabd02b0e567f49ffea4028e6fefa69ab6e56387f")
addappid(283623, 1, "c8ca0ef9399601f9fd4ead7dfa58abc9c50283c1b9bf27882722e9a5a7e4242d")
