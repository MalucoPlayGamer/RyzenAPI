-- Lua provided by RyzenAPI
-- Game: Game: Magic Sword for Kamonegi-go

-- MAIN APPLICATION
addappid(1270230)
-- Game: addappid(1270230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270231, 1, "f879316f0554c4aee71accc843d52f41a05a0a58895b626dfe3cbf11ee6fee44")
