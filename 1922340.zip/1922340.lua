-- Lua provided by SkyAPI 
-- Game: CRASH TEST IDIOT
addappid(1922340)
addappid(1922341, 1, "2e346934606be539911b694bf28bb9b34c08a3d8bb0d4d55354b9ca13932a76c")
