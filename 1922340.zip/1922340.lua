-- Lua provided by RyzenAPI
-- Game: CRASH TEST IDIOT

-- MAIN APPLICATION
addappid(1922340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1922341, 1, "2e346934606be539911b694bf28bb9b34c08a3d8bb0d4d55354b9ca13932a76c")

