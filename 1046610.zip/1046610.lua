-- Lua provided by RyzenAPI 
-- Game: foreverloops BEATS
addappid(1046610)
addappid(1046611, 1, "44ded0ff68b849e825b3cb0e1331dded3b8a870d470bf80536552698bb520a24")
