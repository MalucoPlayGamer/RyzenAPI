-- Lua provided by RyzenAPI
-- Game: foreverloops BEATS

-- MAIN APPLICATION
addappid(1046610)
-- Game: addappid(1046610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046611, 1, "44ded0ff68b849e825b3cb0e1331dded3b8a870d470bf80536552698bb520a24")
