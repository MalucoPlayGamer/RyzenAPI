-- Lua provided by RyzenAPI 
-- Game: Half Sword Tech Demo
addappid(2642680)
addappid(2642681, 1, "730e6f8f0beb385c1a1ed0596d231bd8fc5ebbcbf87c2c7ba445ff008662dc05")
