-- Lua provided by RyzenAPI
-- Game: Car Demolition Clicker

-- MAIN APPLICATION
addappid(705740)

-- MAIN APP DEPOTS / PACKAGES
addappid(705741, 1, "82e0705f87fa38f327870a5b944347347ad25c09e012cbe052f441bedb1acb90")
