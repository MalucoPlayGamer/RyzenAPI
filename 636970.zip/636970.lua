-- Lua provided by SkyAPI 
-- Game: AppID 636970
addappid(636970)
addappid(636971, 1, "2f6f788eb64f9a3152ad7f6d74d95c8695d68905d5fea90263ff951a754141f4")
