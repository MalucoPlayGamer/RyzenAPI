-- Lua provided by RyzenAPI
-- Game: Queen's Tales: Sins of the Past Collector's Edition

-- MAIN APPLICATION
addappid(770870)

-- MAIN APP DEPOTS / PACKAGES
addappid(770871,0,"c07f64e93570f011397be31f8f34a9aef4f141a0cf4e0e420383d9b0c107f269")

