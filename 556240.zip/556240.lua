-- Lua provided by RyzenAPI
-- Game: 556240

-- MAIN APPLICATION
addappid(556240)
-- Game: addappid(556240)

-- MAIN APP DEPOTS / PACKAGES
addappid(556241, 1, "6dda186ad4a39bfd47a5cc0f2bf66913b17be9926ba52fe6d27c4aaffd661c4a")
