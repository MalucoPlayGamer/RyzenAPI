-- Lua provided by RyzenAPI
-- Game: AppID 1010940

-- MAIN APPLICATION
addappid(1010940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010941, 1, "db8f2f8ec8798f74d2a13df05f41b69faf3247b262472ea47b3060c6dbc7fa67")
