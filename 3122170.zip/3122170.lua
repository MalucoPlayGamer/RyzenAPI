-- Lua provided by RyzenAPI
-- Game: Dream Cage

-- MAIN APPLICATION
addappid(3122170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122171, 1, "66fb3be6d84a24b5e8946bb9e96ae61cf32ac55f474eb506b537d34fb81af796")

