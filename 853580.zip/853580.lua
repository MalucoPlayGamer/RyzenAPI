-- Lua provided by RyzenAPI
-- Game: Lost

-- MAIN APPLICATION
addappid(853580)

-- MAIN APP DEPOTS / PACKAGES
addappid(853581, 1, "ca531c674811041d0eedfe872d9e6aaa194a004c408887e4afc71a775615c08d")

