-- Lua provided by RyzenAPI
-- Game: addappid(3382820)

-- MAIN APPLICATION
addappid(3382820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382821, 1, "16fde692455202f44c62f4491544ab88d38ec2653d259424acfe8de8a2c5789d")
