-- Lua provided by RyzenAPI
-- Game: Game: AppID 2267620

-- MAIN APPLICATION
addappid(2267620)
-- Game: addappid(2267620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267621, 1, "6d52cbc3a1704fdb9d02f5d658239178b127c094e013294a0de0b243caf5fe02")
