-- Lua provided by RyzenAPI
-- Game: Game: 12 is Better Than 6

-- MAIN APPLICATION
addappid(410110)
addappid(450820)
-- Game: addappid(410110)

-- MAIN APP DEPOTS / PACKAGES
addappid(410111, 1, "1a3d27168d3940fa042064bdf6b2ef270bfda7541717eaa00bc6e6a008ee2e0b")
addappid(410112, 1, "d9b81b167ad2582212ce886f0bd4a94ae98c67cefa855a3ce31bfd578b965014")
addappid(410113, 1, "ffe14e8b5bec76829b05bd2e259906a37c1ecffeffde6cc42ef8402703b47bca")
addappid(450830, 0, "31848f9751155309eee3b0e193ba670688f2734ee6e750fcf7e9c1d02c4a0613")
