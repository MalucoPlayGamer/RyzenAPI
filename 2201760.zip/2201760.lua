-- Lua provided by RyzenAPI
-- Game: Super Dark Deception Demo

-- MAIN APPLICATION
addappid(2201760)
-- Game: addappid(2201760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201763,0,"00872e3915a3946a30063e7aea9c9719b263ca5090743c39c023b8e046eb1554")
