-- Lua provided by RyzenAPI
-- Game: Cataplexy

-- MAIN APPLICATION
addappid(1563150)
-- Game: addappid(1563150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563151, 1, "ea429c550b3359aaef1dbc19399b73f7a883f27462ba12d1b4ac1e4832ba2d66")
