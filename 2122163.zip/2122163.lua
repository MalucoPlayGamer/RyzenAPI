-- Lua provided by RyzenAPI
-- Game: 2122163

-- MAIN APPLICATION
addappid(2122163)
-- Game: addappid(2122163)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122163,0,"f106017ef14c0be0bd0287b22765008ec2dedb7a30e6e26a786cd59e710a7e2d")
