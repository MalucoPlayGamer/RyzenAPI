-- Lua provided by RyzenAPI
-- Game: Game: AppID 2890060

-- MAIN APPLICATION
addappid(2890060)
-- Game: addappid(2890060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890061, 1, "c2340547f02f59eb6d635c3dd77a95b8387b4fc3ce916beb6f95afa47946f58c")
