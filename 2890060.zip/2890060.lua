-- Lua provided by RyzenAPI
-- Game: Midnight Mayhem

-- MAIN APPLICATION
addappid(2890060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2890061, 1, "c2340547f02f59eb6d635c3dd77a95b8387b4fc3ce916beb6f95afa47946f58c")

