-- Lua provided by RyzenAPI
-- Game: Cosplay Maker

-- MAIN APPLICATION
addappid(299090)

-- MAIN APP DEPOTS / PACKAGES
addappid(299091, 1, "564ab8f2ceaeac942375ec2bd964abc6a5f8a6b36e1a1b7d6e2ffe6e748cb616")
addappid(299092, 1, "276cb56fb180e4bb8f193989301618c4c329384fe7c2756d611058b94e3b820d")
addappid(299093, 1, "1207e89f0a7e7d01dab05b792b5bdce3e809cc08d77336dad95c05d5266fc2fe")
