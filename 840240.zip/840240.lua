-- Lua provided by SkyAPI 
-- Game: AppID 840240
addappid(840240)
addappid(840241, 1, "beafb418b0aaf9eaf8ff142de33cdb4b295488fcf13d0080cca3c001fc6ab66c")
