-- Lua provided by RyzenAPI
-- Game: Mosaic: Game of Gods II

-- MAIN APPLICATION
addappid(840240)

-- MAIN APP DEPOTS / PACKAGES
addappid(840241, 1, "beafb418b0aaf9eaf8ff142de33cdb4b295488fcf13d0080cca3c001fc6ab66c")

