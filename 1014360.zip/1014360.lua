-- Lua provided by RyzenAPI
-- Game: 1014360

-- MAIN APPLICATION
addappid(1014360)
-- Game: addappid(1014360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014361, 1, "45e61e05fffc7ea80b37f33731009d7bb24be82190db28358a61298d68443d7c")
