-- Lua provided by RyzenAPI
-- Game: Sunken

-- MAIN APPLICATION
addappid(405960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(405961, 1, "addc13ddb81914d575ede72f6eee05f30f164a07eaa461a3ca72b30dd776c4dd")
addappid(405962, 1, "65162c5efb7861f3581cbef22ac865688b633cf887ee1235dc1cad9ac5820f36")

