-- Lua provided by RyzenAPI
-- Game: 405960

-- MAIN APPLICATION
addappid(405960)
-- Game: addappid(405960)

-- MAIN APP DEPOTS / PACKAGES
addappid(405961, 1, "addc13ddb81914d575ede72f6eee05f30f164a07eaa461a3ca72b30dd776c4dd")
addappid(405962, 1, "65162c5efb7861f3581cbef22ac865688b633cf887ee1235dc1cad9ac5820f36")
