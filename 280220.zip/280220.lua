-- Lua provided by RyzenAPI
-- Game: Creeper World 3: Arc Eternal

-- MAIN APPLICATION
addappid(280220)

-- MAIN APP DEPOTS / PACKAGES
addappid(280221, 1, "fb7df66a56f70ba2b2ede78d3ab0081dd9b61103066c8cacc91c084943b70d0b")
addappid(280222, 1, "4d38d3d41f1c8492ff0b086876bb94bc8f4c3645abf17c6794a0e9d5f71d05d5")
addappid(280223, 1, "1f0ca9939e0ab46e596fde4074a4e29426c93e918046920cd4626a90dd047086")

