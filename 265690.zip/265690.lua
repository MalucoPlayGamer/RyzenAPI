-- Lua provided by RyzenAPI
-- Game: 265690

-- MAIN APPLICATION
addappid(265690)
-- Game: addappid(265690)

-- MAIN APP DEPOTS / PACKAGES
addappid(265691, 1, "5501a7af5ca7ccad434b0d18fdf60e84b57e45b4f9e2f41e06726d30a86e5d51")
