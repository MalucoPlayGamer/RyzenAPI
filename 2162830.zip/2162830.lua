-- Lua provided by RyzenAPI
-- Game: Game: Sailing Era Demo

-- MAIN APPLICATION
addappid(2162830)
-- Game: addappid(2162830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162831, 1, "258860d5b35ff2f23ca1a921323761ec23291d7deb0282b31bc91faf0b2622d8")
