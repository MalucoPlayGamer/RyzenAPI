-- Lua provided by RyzenAPI
-- Game: A Juggler's Tale

-- MAIN APPLICATION
addappid(1252830)
addappid(1752450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1252831, 1, "5b0e0127a4c740ce3945f315868eb76d3fa4202361ff13d602dce2b1bb5ca173")

