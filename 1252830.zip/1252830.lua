-- Lua provided by RyzenAPI
-- Game: A Juggler's Tale

-- MAIN APPLICATION
addappid(1252830)
addappid(1752450)
-- Game: addappid(1252830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252831, 1, "5b0e0127a4c740ce3945f315868eb76d3fa4202361ff13d602dce2b1bb5ca173")
