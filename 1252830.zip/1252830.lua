-- Lua provided by SkyAPI 
-- Game: A Juggler's Tale
addappid(1252830)
addappid(1252831, 1, "5b0e0127a4c740ce3945f315868eb76d3fa4202361ff13d602dce2b1bb5ca173")
addappid(1752450)
