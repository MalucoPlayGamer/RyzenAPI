-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 女神異聞録ペルソナ 異空の塔編

-- MAIN APPLICATION
addappid(2541170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541171, 1, "2250401bde8d31713c2d76f1980118414db4fb3a4dd03abcc5cf50695f864e68")

