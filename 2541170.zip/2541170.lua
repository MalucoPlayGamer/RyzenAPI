-- Lua provided by RyzenAPI
-- Game: 2541170

-- MAIN APPLICATION
addappid(2541170)
-- Game: addappid(2541170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541171, 1, "2250401bde8d31713c2d76f1980118414db4fb3a4dd03abcc5cf50695f864e68")
