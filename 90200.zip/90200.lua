-- Lua provided by SkyAPI 
-- Game: AppID 90200
addappid(90200)
addappid(90201, 1, "0c6e4158048eb1c7e4c53efa8c648378ff7e090e950d313a860e0dd15e2a8930")
addappid(90202, 1, "44fe250cb6e370721f5c48e8c0ad509bdfb56ca819cdbb8c4efa6e28273d1ae0")
addappid(90207, 1, "ed9a7756fb751a60199db28bae328afff7e65a2e699a61d1fcea645ffb862f0a")
addappid(90208, 1, "ccaed6694771fc6bfbd3df1844a5139a9cec17446aae603dc305ddf7e1d4b07f")
addappid(90209, 1, "1e0b87e5e6af3faf2de4d12202f9f007efe41e4ead8dcefa900f417118bffb5b")
addappid(90210, 1, "be0692a498164b3e57540cc5265d99d34ed469aa1545b093fc45dbaea64bad20")
