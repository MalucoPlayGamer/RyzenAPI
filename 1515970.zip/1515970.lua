-- Lua provided by RyzenAPI
-- Game: Spin & Roll

-- MAIN APPLICATION
addappid(1515970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515971, 1, "2368f1600c009cf037a22a2d29ce59f8185df43b34a25873412a99b9b5afea2a")
