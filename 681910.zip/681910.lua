-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(681910)
addappid(681911)
addappid(681913)

-- MAIN APP DEPOTS / PACKAGES
addappid(681912,0,"8c4424af46b2c3f6aa0f217aa1b04d380e8cf14f9f9603327b091e0caf64b016")
addtoken(681910,4909062370661810500)
