-- Lua provided by RyzenAPI
-- Game: DJMAX RESPECT V - V EXTENSION IV Original Soundtrack

-- MAIN APPLICATION
addappid(2307480)
-- Game: addappid(2307480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307481, 1, "e3b5ce5a5e1ff155f9d356f6c9ef4ddc9e719dfae3aacf28f26c8fa693a1457f")
addappid(2307482, 1, "7c9b6cfb9813e2e04c97917553bc6d3388c11956490fe011cc1233cb406196e4")
