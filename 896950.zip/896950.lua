-- Lua provided by RyzenAPI
-- Game: 896950

-- MAIN APPLICATION
addappid(896950)
-- Game: addappid(896950)

-- MAIN APP DEPOTS / PACKAGES
addappid(896951, 1, "8876b7c9d3dc237a3763c90708ba29ffbbc4e9dba49a6e599182f3b7fcca5a7f")
