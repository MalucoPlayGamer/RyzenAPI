-- Lua provided by RyzenAPI
-- Game: AppID 896950

-- MAIN APPLICATION
addappid(896950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(896951, 1, "8876b7c9d3dc237a3763c90708ba29ffbbc4e9dba49a6e599182f3b7fcca5a7f")

