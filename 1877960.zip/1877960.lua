-- Lua provided by RyzenAPI
-- Game: Trimps

-- MAIN APPLICATION
addappid(1877960)

