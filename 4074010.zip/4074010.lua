-- Lua provided by RyzenAPI
-- Game: Dig, Dig, Die

-- MAIN APP DEPOTS / PACKAGES
addappid(4074010) -- Dig, Dig, Die
addappid(4074011, 1, "caa2d8a39c0a24d7a9003774076047b62d23ed989c7529ab25e930b9a76a847c") -- Depot 4074011

