-- 4074010's Lua and Manifest Created by Hubcap Manifest
-- Dig, Dig, Die
-- Created: August 06, 2026 at 10:55:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4074010) -- Dig, Dig, Die
-- MAIN APP DEPOTS
addappid(4074011, 1, "caa2d8a39c0a24d7a9003774076047b62d23ed989c7529ab25e930b9a76a847c") -- Depot 4074011
setManifestid(4074011, "6947018748051375432", 2635862816)