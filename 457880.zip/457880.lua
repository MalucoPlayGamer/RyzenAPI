-- Lua provided by RyzenAPI
-- Game: 457880

-- MAIN APPLICATION
addappid(457880)
-- Game: addappid(457880)

-- MAIN APP DEPOTS / PACKAGES
addappid(457881, 1, "ae79e894a4bc1813524b5d3335522ed6f85304583380bfde8b1ba0dedf46e2cd")
