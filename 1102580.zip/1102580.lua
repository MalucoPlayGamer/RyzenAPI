-- Lua provided by RyzenAPI 
-- Game: Traffix
addappid(1102580)
addappid(1102581, 1, "f199adc9a312e2a34130009e962632584c4f987dac296cbc2d436c10856fd465")
addappid(1102582, 1, "86770f8ce903e25ec065081ad02b395257a2417772d9e70b7c7d23a2e0e4be13")
