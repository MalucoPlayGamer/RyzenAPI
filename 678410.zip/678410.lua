-- Lua provided by RyzenAPI
-- Game: 678410

-- MAIN APPLICATION
addappid(678410)
-- Game: addappid(678410)

-- MAIN APP DEPOTS / PACKAGES
addappid(678411, 1, "e44a75c89b4c8c15c313fcbfc218a9ec99be0b79d79d91fe7f30a35333e0dc4a")
