-- Lua provided by RyzenAPI
-- Game: Happy Digger Go-Go

-- MAIN APPLICATION
addappid(4875420) -- Happy Digger Go-Go

-- MAIN APP DEPOTS / PACKAGES
addappid(4875421, 1, "77a579201153ab269a4117eec6aa9b374b938a0b7c012d665c3230b345cc1200") -- Depot 4875421

