-- 4875420's Lua and Manifest Created by Hubcap Manifest
-- Happy Digger Go-Go
-- Created: August 01, 2026 at 09:13:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4875420) -- Happy Digger Go-Go
-- MAIN APP DEPOTS
addappid(4875421, 1, "77a579201153ab269a4117eec6aa9b374b938a0b7c012d665c3230b345cc1200") -- Depot 4875421
setManifestid(4875421, "6026031264143832661", 152244768)