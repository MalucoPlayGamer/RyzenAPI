-- Lua provided by RyzenAPI
-- Game: VR HENTAI DATE

-- MAIN APPLICATION
addappid(1526230)
-- Game: addappid(1526230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526231, 1, "8780d5a4f3732005999ffdfa14d78325f34b23f40530aac8c74cfff0ed954ab3")
