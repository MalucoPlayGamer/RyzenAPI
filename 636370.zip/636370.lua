-- Lua provided by SkyAPI 
-- Game: The Sun Never Sets
addappid(636370)
addappid(636371, 1, "f4be72738121c7693606cbe73845b731b823959700360aa3716487a3ae5cc1d8")
