-- Lua provided by RyzenAPI
-- Game: The Sun Never Sets

-- MAIN APPLICATION
addappid(636370)
-- Game: addappid(636370)

-- MAIN APP DEPOTS / PACKAGES
addappid(636371, 1, "f4be72738121c7693606cbe73845b731b823959700360aa3716487a3ae5cc1d8")
