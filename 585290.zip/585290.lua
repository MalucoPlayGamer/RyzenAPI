-- Lua provided by RyzenAPI
-- Game: Lifeline

-- MAIN APPLICATION
addappid(585290)
-- Game: addappid(585290)

-- MAIN APP DEPOTS / PACKAGES
addappid(585291, 1, "65f3703c6326f8e25a86fd2e39305076bedbef5f1d3a7d9f7f3453057f8cac42")
