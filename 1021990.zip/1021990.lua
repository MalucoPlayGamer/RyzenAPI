-- Lua provided by RyzenAPI
-- Game: 1021990

-- MAIN APPLICATION
addappid(1021990)
-- Game: addappid(1021990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021991, 1, "688abf484e5f8f91c248a5f304102530fb35a71eeeaff6b78c410772c1eec05a")
