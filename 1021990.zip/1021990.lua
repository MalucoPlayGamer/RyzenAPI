-- Lua provided by SkyAPI 
-- Game: AppID 1021990
addappid(1021990)
addappid(1021991, 1, "688abf484e5f8f91c248a5f304102530fb35a71eeeaff6b78c410772c1eec05a")
