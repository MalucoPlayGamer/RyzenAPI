-- Lua provided by SkyAPI 
-- Game: LOST ORBIT: Terminal Velocity
addappid(372320)
addappid(372321, 1, "8df83808e0f0565f7fff1e6380be9eeb4c68089971c06a7a169cb2efd533a2d9")
addappid(372322, 1, "bed7e2ebf922690a0682fa21d0129ca6f55bbadc67c6464f4aa2742300ab476b")
addappid(372323, 1, "53900613db7fd96a8b09f9ae84a362bcd13f9a350ecb62cd8694b271952c7bef")
addappid(372324, 1, "f97a69671587b165389cdc6b479fb3a405f9c1da1b3f0e32d337b29e732432cc")
