-- Lua provided by RyzenAPI
-- Game: Game: Hentai Sera

-- MAIN APPLICATION
addappid(2311290)
-- Game: addappid(2311290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311291, 1, "c5fbfef235ea17bcc49129d33e7a95b51ee9a5722fd025e74d2952a12d5e8d51")
