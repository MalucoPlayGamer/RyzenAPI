-- Lua provided by RyzenAPI
-- Game: Acid Planet

-- MAIN APPLICATION
addappid(2641530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641531, 1, "8e851a2abd8dec84cce86ef102891152e11461d58a3a655c12dd179f3dd500b5")
