-- Lua provided by RyzenAPI
-- Game: addappid(545750)

-- MAIN APPLICATION
addappid(545750)

-- MAIN APP DEPOTS / PACKAGES
addappid(545751, 1, "42ad10195bb00ebb9c0720b8d571a46607b47d7db084002392f1bce8efc111be")
addappid(545752, 1, "a7d3525a012d80127bd22edb0674d9b1ab24f0e21aa15c91843cc89d74a7c089")
