-- Lua provided by RyzenAPI
-- Game: Behind The Screen 螢幕判官 

-- MAIN APPLICATION
addappid(821560)

-- MAIN APP DEPOTS / PACKAGES
addappid(821561,0,"f5277a3f372969e1bc4acb2151e83f91898cfb43d95dbe963c5ce242326096c3")
addappid(821562,0,"bae0147ee07d87ab05f09408e74f7af680f57008140aac9ca7030685cc2810da")
addappid(821563,0,"e58ed3d54a1b869ed883ffd70e1e77b30655d86a774bf122138eea453202fb64")
addappid(821564,0,"864d2528ad83d6f94e510f3c3cee45027b15ab6467602a95e76bc2ae390b12bc")
addappid(821565,0,"0e4b9d3cca2667897d2e396800ef08c6c50ca904e98dbbbd0eea913aa0efdfe9")
addappid(821566,0,"20704b0cbd35e6c2c4ab00a0cb78042290ed63ee9a1ef6492150fedc6874fb8f")
addappid(839861,0,"5ac402a2f2334d05381a6e9812036b0056375f135992ffe1a98b3b05d75e0d16")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(839860)
