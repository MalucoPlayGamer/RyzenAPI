-- Lua provided by RyzenAPI
-- Game: AppID 225760

-- MAIN APPLICATION
addappid(225760)

-- MAIN APP DEPOTS / PACKAGES
addappid(225761, 1, "3a5dcc35994f3fa818442fb2b3bf0e2daac5ee85200bcadd9df95b5753080140")
