-- Lua provided by RyzenAPI
-- Game: 1048873

-- MAIN APPLICATION
addappid(1048873)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048873,0,"39ed428d0f2ccc1e32aa9af86f989939b975641c89bf579fbede5a38ffad1bf5")
