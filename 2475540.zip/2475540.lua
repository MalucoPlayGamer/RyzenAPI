-- Lua provided by RyzenAPI
-- Game: Dekamara Demo

-- MAIN APPLICATION
addappid(2475540)
-- Game: addappid(2475540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475541, 1, "8c40bb4db3421e8ac7cfefdb48a491a4a45187f4c5372933bf91baecd1f1e67e")
