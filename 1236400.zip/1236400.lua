-- Lua provided by RyzenAPI
-- Game: Hentai hentai

-- MAIN APPLICATION
addappid(1236400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236402,0,"a3686f946e97f19ebd33cd1f531e87f2487c2508c122cae80ad449b146c9b4da")

