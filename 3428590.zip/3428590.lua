-- Lua provided by RyzenAPI
-- Game: Fish-Click Squad! Demo

-- MAIN APPLICATION
addappid(3428590)
-- Game: addappid(3428590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428591, 1, "7b17c66dc880a980d46067462f01edf3cee6b85326c121030c5855597f6dd778")
