-- Lua provided by RyzenAPI
-- Game: Sweet F. Cake - Man's Club Package

-- MAIN APPLICATION
addappid(1302040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302040,0,"826a248ef85b7d97ef20b00d56e640d8095f8f44dab33bdb885011aded4e6f0a")
