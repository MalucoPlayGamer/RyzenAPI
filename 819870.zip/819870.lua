-- Lua provided by RyzenAPI
-- Game: addappid(819870)

-- MAIN APPLICATION
addappid(819870)
addappid(852800)

-- MAIN APP DEPOTS / PACKAGES
addappid(819871, 1, "bdb42dc49b57d718ac06c58e7d3f1d3c0c34e32d091bc0bb805beca56c05bad9")
