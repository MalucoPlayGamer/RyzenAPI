-- Lua provided by RyzenAPI
-- Game: Game: 7 Days in Dream 光尘

-- MAIN APPLICATION
addappid(819870)
addappid(852800)
-- Game: addappid(819870)

-- MAIN APP DEPOTS / PACKAGES
addappid(819871, 1, "bdb42dc49b57d718ac06c58e7d3f1d3c0c34e32d091bc0bb805beca56c05bad9")
