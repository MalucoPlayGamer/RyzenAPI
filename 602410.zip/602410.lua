-- Lua provided by RyzenAPI
-- Game: XCOM 2 War of the Chosen Development Tools

-- MAIN APPLICATION
addappid(602410)

-- MAIN APP DEPOTS / PACKAGES
addappid(602411, 1, "4b09e2657133969581889b13454b8dca07fd36c90034325e661fcd6e44b53990")
addappid(602412, 1, "d2ede6557b73173f699e7b010bce9a78721d94e39d3a80c4474c5606bcac3146")

