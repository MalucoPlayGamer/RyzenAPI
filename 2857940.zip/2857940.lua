-- Lua provided by RyzenAPI
-- Game: Acorn Cop

-- MAIN APPLICATION
addappid(2857940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857941, 1, "ada030e7e367c79ed105bd057434a6304e46b6ae2367a649c9dd9f0985960a06")
addappid(2857942, 1, "cf66a3ab3fdfe767ec8306f02ba5bdece938a9f3cfd09a07c79a1f1bea26e0e5")

