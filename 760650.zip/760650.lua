-- Lua provided by RyzenAPI
-- Game: Hammerting

-- MAIN APPLICATION
addappid(760650)

-- MAIN APP DEPOTS / PACKAGES
addappid(760651, 1, "40d4391e50b9bdb0dd4e73e6c064866642f9b208d44fdd63f6003d8c0b43feee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
