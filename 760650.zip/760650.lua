-- Lua provided by RyzenAPI
-- Game: Hammerting

-- MAIN APPLICATION
addappid(760650)
-- Game: addappid(760650)

-- MAIN APP DEPOTS / PACKAGES
addappid(760651, 1, "40d4391e50b9bdb0dd4e73e6c064866642f9b208d44fdd63f6003d8c0b43feee")
