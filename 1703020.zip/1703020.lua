-- Lua provided by RyzenAPI
-- Game: Game: SpaceKraft!

-- MAIN APPLICATION
addappid(1703020)
-- Game: addappid(1703020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703021, 1, "0d516cd5cbf102de9ba78d2a45a9d0c8a529d921a3baf5d608ad3e2b4a35dc72")
