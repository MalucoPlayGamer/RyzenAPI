-- Lua provided by RyzenAPI
-- Game: This War of Mine Original Soundtrack

-- MAIN APPLICATION
addappid(354350)

-- MAIN APP DEPOTS / PACKAGES
addappid(354350,0,"f9a13515dd2a3f85d0b34e737cf79724289ce9dff89458c7d5456219314bea18")

