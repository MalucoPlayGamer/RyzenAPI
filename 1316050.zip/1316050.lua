-- Lua provided by RyzenAPI
-- Game: Rainy City: Pandemic

-- MAIN APPLICATION
addappid(1316050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316051, 1, "2636da6a9d9bc4320f425f1299250784a4b1e5595da34bfd0810c3f5c76c2e94")

