-- Lua provided by RyzenAPI
-- Game: Game: AppID 389350

-- MAIN APPLICATION
addappid(389350)
-- Game: addappid(389350)

-- MAIN APP DEPOTS / PACKAGES
addappid(389351, 1, "581feb04afb017ea1ddbd0e7eb12d7d209d81fa74784aa06caa51d7fa4e6c148")
