-- Lua provided by RyzenAPI
-- Game: addappid(1462810)

-- MAIN APPLICATION
addappid(1462810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462811, 1, "4d32d8e4437fd7b8a78ade88d36e020a1b25551ae1bd3da6768dcb764cf661c1")
