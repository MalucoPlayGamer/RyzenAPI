-- Lua provided by RyzenAPI 
-- Game: WRC 10 FIA World Rally Championship
addappid(1462810)
addappid(1462811, 1, "4d32d8e4437fd7b8a78ade88d36e020a1b25551ae1bd3da6768dcb764cf661c1")
