-- Lua provided by RyzenAPI
-- Game: Pirate101

-- MAIN APPLICATION
addappid(620620)
addappid(4014380)

-- MAIN APP DEPOTS / PACKAGES
addappid(620621, 1, "3d9913e435e9b6cba806afd3ef71b3cb14019f2a6892651aa2d3d69ee3ef5789")

