-- Lua provided by SkyAPI 
-- Game: AppID 620620
addappid(620620)
addappid(620621, 1, "3d9913e435e9b6cba806afd3ef71b3cb14019f2a6892651aa2d3d69ee3ef5789")
