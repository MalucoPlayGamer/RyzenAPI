-- Lua provided by RyzenAPI
-- Game: Burning Knight

-- MAIN APPLICATION
addappid(851150)

-- MAIN APP DEPOTS / PACKAGES
addappid(851151,0,"ba3545f1382f5c8468f3fd1ab49531460f39a8ced5cfcb65b032f63e4e49d75b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
