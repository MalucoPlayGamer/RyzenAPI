-- Lua provided by RyzenAPI
-- Game: Burning Knight

-- MAIN APPLICATION
addappid(851150)

-- MAIN APP DEPOTS / PACKAGES
addappid(851151,0,"ba3545f1382f5c8468f3fd1ab49531460f39a8ced5cfcb65b032f63e4e49d75b")

