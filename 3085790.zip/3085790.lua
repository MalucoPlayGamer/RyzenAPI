-- Lua provided by RyzenAPI
-- Game: addappid(3085790)

-- MAIN APPLICATION
addappid(3085790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085791, 1, "a5d786083b7dcbe2ef8f7924d3b8f15890a6b51989f2398a49b6b009aba69ab0")
