-- Lua provided by RyzenAPI 
-- Game: Curse of the Deadwood
addappid(362670)
addappid(362671, 1, "1b51d7c78b93cda535f7bcb7d25c63fe6cd1758e1eedbfcef19320a842c55dc9")
