-- Lua provided by RyzenAPI
-- Game: Dungeon Mercenaries

-- MAIN APPLICATION
addappid(2928090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928091, 1, "7dc7bc8a50ec46bfdce15cfd6ae326a78d7ace4cba420e509a5527000257ba5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
