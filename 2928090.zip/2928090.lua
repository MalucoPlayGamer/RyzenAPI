-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Mercenaries

-- MAIN APPLICATION
addappid(2928090)
-- Game: addappid(2928090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928091, 1, "7dc7bc8a50ec46bfdce15cfd6ae326a78d7ace4cba420e509a5527000257ba5e")
