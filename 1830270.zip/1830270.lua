-- Lua provided by RyzenAPI
-- Game: Vanildo's Journey

-- MAIN APPLICATION
addappid(1830270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830271, 1, "30acb8ad6ff4caffbb0aaa626050284fa1c2b6ccc973c8c33aabee3fc0b4bae6")
addappid(1830272, 1, "a2daa4f5c54510fcbd058aa0c6f9259a91d767233c79b43d4c7489179c326f37")
addappid(1830274, 1, "35b8caf4e19d9dfcfe08df63c26fc2cca79f425f037db754ba9d068bc1bb5572")
addappid(1830276, 1, "2c8bd4c49c4e97f610cf27784fe48e8ed36f2eabbdfb089c747ad4a3638da666")

