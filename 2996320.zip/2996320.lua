-- Lua provided by RyzenAPI 
-- Game: X Run 3
addappid(2996320)
addappid(2996321, 1, "1fd2f0132316aa85371f0c17c9358b2957194cba2d27b5b5040e7f34bb0d97c8")
