-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Stalkers Playtest

-- MAIN APPLICATION
addappid(2691730)
-- Game: addappid(2691730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691731, 1, "f80801c0c1df4c811dede9d89930c07131f3fde2d68ef1dd0ae2c9070d37b89e")
