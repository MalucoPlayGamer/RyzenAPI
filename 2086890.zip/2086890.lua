-- Lua provided by SkyAPI 
-- Game: AppID 2086890
addappid(2086890)
addappid(2086891, 1, "79c11b32f035d3cf38ac16d233372e9f83b3566e7456927e22ac2786494a6531")
