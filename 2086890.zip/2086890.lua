-- Lua provided by RyzenAPI
-- Game: Connect the Dots 3D

-- MAIN APPLICATION
addappid(2086890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086891, 1, "79c11b32f035d3cf38ac16d233372e9f83b3566e7456927e22ac2786494a6531")
