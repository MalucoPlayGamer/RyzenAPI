-- Lua provided by RyzenAPI
-- Game: Game: AppID 2615730

-- MAIN APPLICATION
addappid(2615730)
-- Game: addappid(2615730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615731, 1, "0896e9955b6bdab8dcbe509657ddf21671de7d0009d8202d6d715b393293b2b6")
