-- Lua provided by RyzenAPI
-- Game: 500550

-- MAIN APPLICATION
addappid(500550)
-- Game: addappid(500550)

-- MAIN APP DEPOTS / PACKAGES
addappid(500551, 1, "32e0ca330c16d1a4268fb114b19d678b595ae96e88edc6910b9fb4091493063d")
