-- Lua provided by RyzenAPI
-- Game: 2979780

-- MAIN APPLICATION
addappid(2979780)
-- Game: addappid(2979780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2979782,0,"7d2cbfab930ee29c49681382e8d9f9b0e3dfede208a8ee1d865ec138d0ee4c7d")
