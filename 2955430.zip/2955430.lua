-- Lua provided by RyzenAPI
-- Game: 2955430

-- MAIN APPLICATION
addappid(2955430)
-- Game: addappid(2955430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955431, 1, "df1c3c5eb6a7e1cbfe09b24999ea79f9b542a38ea409e7baf9fe819c4e6edaa2")
