-- Lua provided by RyzenAPI 
-- Game: AppID 2955430
addappid(2955430)
addappid(2955431, 1, "df1c3c5eb6a7e1cbfe09b24999ea79f9b542a38ea409e7baf9fe819c4e6edaa2")
