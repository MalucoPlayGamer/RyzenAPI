-- Lua provided by RyzenAPI
-- Game: City of Rott: Streets of Rott

-- MAIN APPLICATION
addappid(580880)

-- MAIN APP DEPOTS / PACKAGES
addappid(580882,0,"d515a6face61283749673d470312e0776ffb337b3dc550f723d4d410cbdd2358")
