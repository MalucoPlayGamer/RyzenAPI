-- Lua provided by SkyAPI 
-- Game: Summer Clover -Soundtrack-
addappid(3001960)
addappid(3001961, 1, "e794a246ff35fb6b99dc0dce3025925d15e817a8acaa44394b9ee959ccf83e5e")
addappid(3001962, 1, "caa95e4c765a12ffc0ca126f4dd95e3a93d7c2d31cad2e0d0c1baebd7ba3e5a4")
