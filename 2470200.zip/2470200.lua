-- Lua provided by RyzenAPI
-- Game: Game: Tales of Spark: Probation

-- MAIN APPLICATION
addappid(2470200)
-- Game: addappid(2470200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470201, 1, "2e0cd1364137c92311adf1955df163e710e994757ea5a991f94f2a9d1fd9d2e5")
