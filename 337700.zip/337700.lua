-- Lua provided by RyzenAPI
-- Game: addappid(337700)

-- MAIN APPLICATION
addappid(337700)

-- MAIN APP DEPOTS / PACKAGES
addappid(337702,0,"6ad25f635d40b3bf39171e3e1d737fceb8de011d018523e81e600d97992d0640")
