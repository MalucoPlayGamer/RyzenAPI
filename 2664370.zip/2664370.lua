-- Lua provided by RyzenAPI
-- Game: 2664370

-- MAIN APPLICATION
addappid(2664370)
-- Game: addappid(2664370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664371, 1, "86b1afd5f2dc17a592e667c33cb9998ea16c0597776ffc0790a6b288666ccd78")
