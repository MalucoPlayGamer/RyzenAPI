-- Lua provided by RyzenAPI
-- Game: Lelie Navigation!

-- MAIN APPLICATION
addappid(1279260)
-- Game: addappid(1279260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279261, 1, "dec8016fbf89f7dc29531632d4098841918edfd818a9845c98e5a509074662c3")
addappid(1279262, 1, "c0d2518ccdf268a397d58497d19433147e02dd8513743e9db98759232a7c12dd")
