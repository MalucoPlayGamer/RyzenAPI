-- Lua provided by RyzenAPI
-- Game: AppID 1668460

-- MAIN APPLICATION
addappid(1668460)
-- Game: addappid(1668460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668461, 1, "d6d5304013b62728ae1fbd0d4eaa2c94e2a106952bd9d5309177d97e5141ab5a")
