-- Lua provided by RyzenAPI
-- Game: Gap Storm

-- MAIN APPLICATION
addappid(4868140) -- Gap Storm

-- MAIN APP DEPOTS / PACKAGES
addappid(4868141, 1, "5fabe5170dcf4f212bdcc2233729a83a1eafd597a92f58fa492ed0cd16466d8a") -- Depot 4868141
addappid(4868142, 1, "76eb7740ef840d66801675622b1aa9ee82d16323b7a85ff2dfc370b453cbd6fb") -- Depot 4868142

