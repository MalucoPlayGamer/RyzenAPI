-- Lua provided by RyzenAPI 
-- Game: Barbotine
addappid(2845840)
addappid(2845841, 1, "64078da43b5b9a7e53fcdc10fc0d4c42164f2753d1684994b31bb5bdf63814bd")
