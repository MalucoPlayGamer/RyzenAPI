-- Lua provided by RyzenAPI
-- Game: Crash Time - Undercover

-- MAIN APPLICATION
addappid(1687700)
-- Game: addappid(1687700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687701, 1, "7dfc6e66c35d2335dcbd9ae42ee943b3bd58614d378b8fbab501b5831c5f3fc6")
