-- Lua provided by RyzenAPI
-- Game: Redemption: Eternal Quest

-- MAIN APPLICATION
addappid(390880)

-- MAIN APP DEPOTS / PACKAGES
addappid(390881, 1, "3d72017e83401400cb0e796dcb5da62c11490d60eb57f00592f3a8f396894b50")
