-- Lua provided by RyzenAPI
-- Game: 417980

-- MAIN APPLICATION
addappid(417980)
-- Game: addappid(417980)

-- MAIN APP DEPOTS / PACKAGES
addappid(417981, 1, "7d486d92ea823ea4dabcf8fa0959d255a6ab21cfc6d7f70b092dd22a21d065aa")
