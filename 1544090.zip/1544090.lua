-- Lua provided by RyzenAPI
-- Game: 冒险的路上总在为爱鼓掌 Adventure road

-- MAIN APPLICATION
addappid(1544090)
-- Game: addappid(1544090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544091, 1, "9bd80de18eece5f1752fab44d33f057f3e7f10e780dd31f4d92079fec643b917")
addappid(1544092, 1, "995c7aafad85b920e858e009e74ca853cad3ab0160e0b5469f61895cfd2075bc")
addappid(1544093, 1, "d2efce0b27082974f90db6d6489a1ddb481d1f0be0507aecaf48779ef9dc5285")
addappid(1544095, 1, "9d3dba75c31eea4e7bdb08615c89ecef794ae8259f38e390901b20be661264ac")
