-- Lua provided by RyzenAPI
-- Game: 1290

-- MAIN APPLICATION
addappid(1290)
-- Game: addappid(1290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291, 1, "7c4a5055dd1b27cad7360b9172a473af3a4c0c8f8b12ce9b0070b8e66936d6ba")
