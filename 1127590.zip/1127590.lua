-- Lua provided by RyzenAPI
-- Game: Game: AppID 1127590

-- MAIN APPLICATION
addappid(1127590)
-- Game: addappid(1127590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127591, 1, "1ae357182560fc067dc851f1963b7db10521f6b5cb763ed200985e3f3d1b9410")
