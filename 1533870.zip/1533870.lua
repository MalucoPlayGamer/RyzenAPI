-- Lua provided by RyzenAPI
-- Game: Atrius Star

-- MAIN APPLICATION
addappid(1533870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533871, 1, "ad6810ce70790645310e10b7294ac24a2e87d2bbbcfcf11ee7ce5d75c41314cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
