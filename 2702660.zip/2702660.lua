-- Lua provided by RyzenAPI
-- Game: 2702660

-- MAIN APPLICATION
addappid(2702660)
-- Game: addappid(2702660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702661, 1, "5f7bc87e4522999bc30f5b28589ce7b0b9fd7827d3d85f777f4734b5d6578ac4")
