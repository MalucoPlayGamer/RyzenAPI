-- Lua provided by RyzenAPI
-- Game: AppID 430170

-- MAIN APPLICATION
addappid(430170)
addappid(430370)

-- MAIN APP DEPOTS / PACKAGES
addappid(430171, 1, "877acbaf8eecf2692f3156c2561ffa3bc416965a6a01e99a9714cc4fb9f522c9")
