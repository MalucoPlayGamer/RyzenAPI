-- Lua provided by RyzenAPI
-- Game: Game: ACROBATIC CAR

-- MAIN APPLICATION
addappid(1602330)
-- Game: addappid(1602330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602331, 1, "fd5c8958ae1747552ed8b46917f75fb5abe698a32d16ed950e57330ec33dddbf")
