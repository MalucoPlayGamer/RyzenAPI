-- Lua provided by RyzenAPI
-- Game: addappid(2625630)

-- MAIN APPLICATION
addappid(2625630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625631, 1, "4d7c6efdb932c0db9c114da3e52beb3b525f1540144353f91c2ca26a1423fcf2")
