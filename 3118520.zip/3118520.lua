-- Lua provided by RyzenAPI
-- Game: Game: AppID 3118520

-- MAIN APPLICATION
addappid(3118520)
-- Game: addappid(3118520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118521, 1, "883632752634dbb5b7f83e594192dc3915a2fbec057bfe7e94ce666f5873563a")
