-- Lua provided by RyzenAPI
-- Game: Another Hope

-- MAIN APPLICATION
addappid(3118520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3118521, 1, "883632752634dbb5b7f83e594192dc3915a2fbec057bfe7e94ce666f5873563a")

