-- Lua provided by RyzenAPI
-- Game: 8880

-- MAIN APPLICATION
addappid(8880)
-- Game: addappid(8880)

-- MAIN APP DEPOTS / PACKAGES
addappid(8881, 1, "5a07296b85a2ec74b499f303a2139a146874afe470ffd646e00614e8d75fab15")
