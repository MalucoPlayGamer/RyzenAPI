-- Lua provided by RyzenAPI
-- Game: Game: Star Fire: Eternal Cycle Playtest

-- MAIN APPLICATION
addappid(3334420)
-- Game: addappid(3334420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334421, 1, "3cd19321ba70ce31e0a707be3267baa2d9da9fd31aaa93d78cd05d36650f2646")
