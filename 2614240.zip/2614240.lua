-- Lua provided by RyzenAPI
-- Game: 2614240

-- MAIN APPLICATION
addappid(2614240)
-- Game: addappid(2614240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614241, 1, "efe82c0a58f61223fee63bcdda4f4feaaa4ec9ca55320ff012beec8bb63cdc63")
