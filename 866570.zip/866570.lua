-- Lua provided by RyzenAPI
-- Game: System Shock 2: 25th Anniversary Remaster

-- MAIN APPLICATION
addappid(866570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(866571, 1, "6edbf9ce4219fe61908e9f984131b5bd33fd5760f1f6e23ad0383ff69c505822")
addappid(866572, 1, "a74158ba1f081c90349945bc4cbf9589273301419df7cf49118a2f45003396eb")

