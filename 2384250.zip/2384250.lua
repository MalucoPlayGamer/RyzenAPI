-- Lua provided by RyzenAPI
-- Game: Mystic Blast

-- MAIN APPLICATION
addappid(2384250)
-- Game: addappid(2384250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384251, 1, "60672db4b96d6da8f9245f746c0568a3f16e59eb1efe3d60976928c9c92dc7fb")
