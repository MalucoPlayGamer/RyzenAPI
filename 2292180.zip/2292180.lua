-- Lua provided by RyzenAPI
-- Game: addappid(2292180)

-- MAIN APPLICATION
addappid(2292180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292182,0,"49738fe0e5a2cd159d84cf9b31a6ccbedb1ceac95931e4dd3b0e39528427b521")
