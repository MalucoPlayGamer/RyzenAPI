-- Lua provided by RyzenAPI
-- Game: 100 hidden eternals

-- MAIN APPLICATION
addappid(1480120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480121, 1, "1a4a92ad5c6657378e41f2931c3026bc2fbe679af0e40dedc4d3c3e630012d72")