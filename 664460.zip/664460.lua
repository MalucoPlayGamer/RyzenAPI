-- Lua provided by RyzenAPI
-- Game: Ultimate Summer

-- MAIN APPLICATION
addappid(664460)

-- MAIN APP DEPOTS / PACKAGES
addappid(664461,0,"689d17dbd12eae4b92bb1bfe245f267034e58060851985500c2d0892fcce566a")

