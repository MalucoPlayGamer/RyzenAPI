-- Lua provided by RyzenAPI
-- Game: Cellar Keeper

-- MAIN APPLICATION
addappid(4935510) -- Cellar Keeper

-- MAIN APP DEPOTS / PACKAGES
addappid(4935511, 1, "af021b487d377a7f01808ef44c074f24b3cb156767bb49718e986f5ec528daf2") -- Depot 4935511

