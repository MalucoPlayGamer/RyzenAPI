-- 4935510's Lua and Manifest Created by Hubcap Manifest
-- Cellar Keeper
-- Created: August 06, 2026 at 23:43:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4935510) -- Cellar Keeper
-- MAIN APP DEPOTS
addappid(4935511, 1, "af021b487d377a7f01808ef44c074f24b3cb156767bb49718e986f5ec528daf2") -- Depot 4935511
setManifestid(4935511, "375075678765961052", 686525307)