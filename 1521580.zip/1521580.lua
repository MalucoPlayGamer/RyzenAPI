-- Lua provided by RyzenAPI
-- Game: addappid(1521580)

-- MAIN APPLICATION
addappid(1521580)
addappid(2661580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521581, 1, "4e6182d3021db3ba34b32c18a8fc41f1ea6b19103d0d64f00d70cf98876b76b2")
