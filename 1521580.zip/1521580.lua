-- Lua provided by RyzenAPI
-- Game: Perfect Heist 2

-- MAIN APPLICATION
addappid(1521580)
addappid(2661580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521581, 1, "4e6182d3021db3ba34b32c18a8fc41f1ea6b19103d0d64f00d70cf98876b76b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
