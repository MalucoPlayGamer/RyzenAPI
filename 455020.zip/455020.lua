-- Lua provided by SkyAPI 
-- Game: Jackpot Poker by PokerStars
addappid(455020)
addappid(455021, 1, "401d73815630004fe724c3dae4fc204b0cd4f695c5f688577870abf77c102a60")
