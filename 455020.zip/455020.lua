-- Lua provided by RyzenAPI
-- Game: 455020

-- MAIN APPLICATION
addappid(455020)
-- Game: addappid(455020)

-- MAIN APP DEPOTS / PACKAGES
addappid(455021, 1, "401d73815630004fe724c3dae4fc204b0cd4f695c5f688577870abf77c102a60")
