-- Lua provided by RyzenAPI
-- Game: 1133110

-- MAIN APPLICATION
addappid(1133110)
-- Game: addappid(1133110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133111, 1, "87ff8f13dade02518d19effd1d8965885129f7f4179e817f4487ffd0b07c8304")
