-- Lua provided by RyzenAPI
-- Game: Snake Force

-- MAIN APPLICATION
addappid(1806040)

