-- Lua provided by RyzenAPI
-- Game: AppID 819070

-- MAIN APPLICATION
addappid(819070)

-- MAIN APP DEPOTS / PACKAGES
addappid(819071, 1, "25f9bc3177288abca4e06bfadfe83aadfafae13546bec970dfe86abfb215c7a0")

