-- Lua provided by SkyAPI 
-- Game: Hokko Life
addappid(824000)
addappid(824001, 1, "48315205e431ead0b727fce6f9a409d2589754d8b9c424f2497122dddbc65bea")
