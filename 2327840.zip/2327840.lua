-- Lua provided by RyzenAPI
-- Game: GHOST HUNTER

-- MAIN APPLICATION
addappid(2327840)
-- Game: addappid(2327840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327841, 1, "d451b26adf7c5ddd761261c6f8dd83cc30f0920d4b3cabb2a6974f6e839e1f8d")
