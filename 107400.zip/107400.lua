-- Lua provided by RyzenAPI
-- Game: Arma 2: Free

-- MAIN APPLICATION
addappid(107400)

-- MAIN APP DEPOTS / PACKAGES
addappid(107401, 1, "ed3646997c610af43daced27142ac4b4ce7379c823398b93f101fb3f252e0946")

