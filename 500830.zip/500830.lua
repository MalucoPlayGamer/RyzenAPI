-- Lua provided by RyzenAPI
-- Game: 500830

-- MAIN APPLICATION
addappid(500830)
-- Game: addappid(500830)

-- MAIN APP DEPOTS / PACKAGES
addappid(500831, 1, "715a7c85bd0d2ada8ee2aa2cbed1daf7bbcaf6f27deb335740507d67f0807153")
