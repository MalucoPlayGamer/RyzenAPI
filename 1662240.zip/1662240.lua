-- Lua provided by RyzenAPI
-- Game: 天下为棋 Demo

-- MAIN APPLICATION
addappid(1662240)
-- Game: addappid(1662240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662241, 1, "c5d65385d66c5e8469dbb57c86bc0837b4d78bc777dcd1ec13b5c044294aa8be")
