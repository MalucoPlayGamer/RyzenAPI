-- Lua provided by RyzenAPI
-- Game: AppID 371520

-- MAIN APPLICATION
addappid(371520)
addappid(758390)

-- MAIN APP DEPOTS / PACKAGES
addappid(371521, 1, "6fb16e3183aba79e601339248eb4732d79efe77f853f278f6461c20f87ec235e")
addappid(371522, 1, "0ddaf93962e6e2817bf547aa66e06fd032bbef93f611f97fbafa67c2f31ad264")
addappid(371523, 1, "239e811bb7d1cf7aad2be997d12a4914c0300bf6395f1e19573e3cc4c604a9cd")
addappid(371525, 1, "9df322a35a698e25396723467a18a185e47dac769e55f5c96f4e4e5e123833f4")
addappid(371526, 1, "02986e7b361e209c39587312a630507dc87f18b446987e0bcede617d9c71f0a0")
addappid(394090, 0, "b8ce98bebeae355480b22b80232625e4c5272dc33854c1e72b94fcd08f53509d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(429960)
