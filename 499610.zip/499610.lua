-- Lua provided by RyzenAPI
-- Game: Copter and Sky

-- MAIN APPLICATION
addappid(499610)

-- MAIN APP DEPOTS / PACKAGES
addappid(499611, 1, "5aa67628971dc0d9e3d609271cc9e7c4f2c7363732c4d0fdca5578608757186c")

