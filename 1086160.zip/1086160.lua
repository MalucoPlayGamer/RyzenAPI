-- Lua provided by RyzenAPI
-- Game: Space War: Infinity

-- MAIN APPLICATION
addappid(1086160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086161, 1, "47a980fec768d166acaeb076f0527b7b67e0a466ea8803cbeb65616183ece976")
