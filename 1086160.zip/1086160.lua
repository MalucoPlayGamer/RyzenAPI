-- Lua provided by RyzenAPI
-- Game: Space War: Infinity

-- MAIN APPLICATION
addappid(1086160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086161, 1, "47a980fec768d166acaeb076f0527b7b67e0a466ea8803cbeb65616183ece976")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
