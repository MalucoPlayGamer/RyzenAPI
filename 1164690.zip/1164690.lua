-- Lua provided by SkyAPI 
-- Game: AppID 1164690
addappid(1164690)
addappid(1164691, 1, "ee4441f3fcea1c042f8a5fe66e6d2071ba6aa4c369cdc7a98b0d1e2c6cb850b8")
