-- Lua provided by RyzenAPI
-- Game: Wigmund

-- MAIN APPLICATION
addappid(1164690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1164691, 1, "ee4441f3fcea1c042f8a5fe66e6d2071ba6aa4c369cdc7a98b0d1e2c6cb850b8")
