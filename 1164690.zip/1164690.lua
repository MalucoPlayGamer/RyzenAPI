-- Lua provided by RyzenAPI
-- Game: Game: AppID 1164690

-- MAIN APPLICATION
addappid(1164690)
-- Game: addappid(1164690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164691, 1, "ee4441f3fcea1c042f8a5fe66e6d2071ba6aa4c369cdc7a98b0d1e2c6cb850b8")
