-- Lua provided by RyzenAPI
-- Game: 678440

-- MAIN APPLICATION
addappid(678440)
-- Game: addappid(678440)

-- MAIN APP DEPOTS / PACKAGES
addappid(678441, 1, "5b83dfd6cb810e87020d50af8fa68051eb3c29669e0efca5f61be5bc639fdb6c")
