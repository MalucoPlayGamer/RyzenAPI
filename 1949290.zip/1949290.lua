-- Lua provided by RyzenAPI
-- Game: Welcome, Get Out!

-- MAIN APPLICATION
addappid(1949290)
-- Game: addappid(1949290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949291, 1, "2434d587ae6c34c49f6d039e52c62b27a8b340da6c968bb65186dd02d1d59f56")
addappid(1949293, 1, "e3b7343a2147dc216616947ad512ec6a664896e6485239cae54ad51d2eba55e8")
