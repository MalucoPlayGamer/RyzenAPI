-- Lua provided by RyzenAPI
-- Game: Music Visualizer Engine PC Live Wallpaper

-- MAIN APPLICATION
addappid(1204920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204921, 1, "fa56dd08a2baa87a52132f10d6a6f93cf84f3532de39b58690697568b828586e")

