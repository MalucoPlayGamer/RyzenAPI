-- Lua provided by RyzenAPI
-- Game: addappid(1268280)

-- MAIN APPLICATION
addappid(1268280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268281, 1, "4478afc401b95f574e67639b241b051d2d2a2ad1b210ec2738333a5b0fd0eb81")
