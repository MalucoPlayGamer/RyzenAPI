-- Lua provided by RyzenAPI
-- Game: PRO ERA

-- MAIN APPLICATION
addappid(2165690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165691, 1, "37af4b718feb9b6c16d91a8beff07f345598a1429ef2fc9e65072e66b2dd1f60")

