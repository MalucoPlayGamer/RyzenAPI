-- Lua provided by RyzenAPI
-- Game: Trickery&Strategy

-- MAIN APPLICATION
addappid(1544250)
-- Game: addappid(1544250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544251, 1, "73dbe3724d1b2abe39bf9a046416c0894e24d64bf84624fc7bf04e69ad6ef08d")
