-- Lua provided by RyzenAPI
-- Game: Police Sentri 2

-- MAIN APPLICATION
addappid(1697620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697621, 1, "781a64b3f5a78bbf3905bf53f9abbcaad45dbfb7e9a74d25d950765e1b75c7db")

