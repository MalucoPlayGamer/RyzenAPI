-- Lua provided by RyzenAPI
-- Game: addappid(731870)

-- MAIN APPLICATION
addappid(731870)

-- MAIN APP DEPOTS / PACKAGES
addappid(731871, 1, "b9d078b8392d4184c53f3b4bfdde932f5bfae3594ac66a0961726440cd8ddd0b")
