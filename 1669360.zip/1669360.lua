-- Lua provided by SkyAPI 
-- Game: Socialism Simulator
addappid(1669360)
addappid(1669361, 1, "2143421a047243745b8c1af492373d0006e56769bf8ef80b674b2d5325c3a646")
