-- Lua provided by SkyAPI 
-- Game: Pixel Studio - pixel art editor
addappid(1204050)
addappid(1204051, 1, "f41ffdc84d465a6bc7dc041e12ed95f1d0e2829bbad76f9a7131f09996733baf")
addappid(1204052, 1, "c1347fb7c3550b3487da44fa049a60642b17325f0d2a3b7de3ad186f72312c7d")
addappid(1204053, 1, "5fbe0a5b2cee1a069a3beeaba2945c45b913162858bb8432809d2cb1bf6371c7")
