-- Lua provided by RyzenAPI
-- Game: Game: Chicken Invaders 5

-- MAIN APPLICATION
addappid(353090)
-- Game: addappid(353090)

-- MAIN APP DEPOTS / PACKAGES
addappid(353091, 1, "8d7e17c1c3018f6ae66a02edf5ef50d4246b7a003f1df9afa2ed5b6fd1ab2316")
addappid(353092, 1, "e69faaf6513625c4b98e8a92d24a455813dc87fcc90e5c4e95d8dedd5012cf0b")
addappid(353093, 1, "f81e3c5b6a10aa529adb8fd41d7aa082a124aea6eaef0cb5c04bf974e61fb8a8")
addappid(353094, 1, "897cdd73ae7e473c995b12363cef7c91fa73d41864d44e4e608ed2b7ae052a42")
addappid(353095, 1, "a52feaa2812022c2ef122e6ef34bda28851c9140fc08b86b6cfbba0dee440bb0")
addappid(353098, 1, "858c400ec2c57d125525bc779ddc20b5d7a046e9024d0078c5c46d0ee7179d7b")
addappid(402990, 0, "d3e5e02d287533c466412dac411ffec06fd78b5ea4eeec057a28e76e9310541c")
addappid(402992, 0, "ce7214eb5242ee90272d1c6a4035699c685b313e964ceff10c23aae0dbf11468")
addappid(402993, 0, "ba056b6734cd656b28a8bf8b466f7b0ac24eade53283449e39f2ed5941cc4805")
addappid(543610, 0, "e977b5920c732ea90bf938fccd1f4a811516d8431e8112c48791c8ab75cc05fd")
