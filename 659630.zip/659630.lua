-- Lua provided by RyzenAPI
-- Game: Game: Tiny Toyfare

-- MAIN APPLICATION
addappid(659630)
-- Game: addappid(659630)

-- MAIN APP DEPOTS / PACKAGES
addappid(659631, 1, "6096481039fe959da40b84eed85b822ddfab78cffea20ba79449792fb088c3ee")
