-- Lua provided by RyzenAPI
-- Game: Vampirem

-- MAIN APPLICATION
addappid(1302570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1302571, 1, "2731bf0e61e2d8fe389c1bff0b5d0e4f4d9aa11b77ed96d23147fd9d8a559c3d")

