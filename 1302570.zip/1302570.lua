-- Lua provided by SkyAPI 
-- Game: Vampirem
addappid(1302570)
addappid(1302571, 1, "2731bf0e61e2d8fe389c1bff0b5d0e4f4d9aa11b77ed96d23147fd9d8a559c3d")
