-- Lua provided by RyzenAPI
-- Game: addappid(3074790)

-- MAIN APPLICATION
addappid(3074790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074791, 1, "23989b60e936764da373a828577bae206e2f184b0c750a137d05eb7b1e0ae9cc")
