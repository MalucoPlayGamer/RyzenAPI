-- Lua provided by RyzenAPI
-- Game: Kate: Collateral Damage

-- MAIN APPLICATION
addappid(1623000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623001, 1, "e367e1f4c1010df9354f93e18dc5927dff5893ca8fa725bcd58151de7151144f")

