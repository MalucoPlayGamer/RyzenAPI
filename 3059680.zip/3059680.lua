-- Lua provided by SkyAPI 
-- Game: Sticky Clicker Soundtrack
addappid(3059680)
addappid(3059681, 1, "4b3ec02250778f374401189ab298e23045244941a3bb5dc8bf6d1fe8262e643e")
