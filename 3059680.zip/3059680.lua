-- Lua provided by RyzenAPI
-- Game: Game: Sticky Clicker Soundtrack

-- MAIN APPLICATION
addappid(3059680)
-- Game: addappid(3059680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059681, 1, "4b3ec02250778f374401189ab298e23045244941a3bb5dc8bf6d1fe8262e643e")
