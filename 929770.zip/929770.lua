-- Lua provided by RyzenAPI
-- Game: Epic roll

-- MAIN APPLICATION
addappid(929770)

-- MAIN APP DEPOTS / PACKAGES
addappid(929771, 1, "245d7b7dece82b0db9b2657471afd3160facba3c979de10d14e4c26950cffffc")
