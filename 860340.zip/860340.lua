-- Lua provided by RyzenAPI
-- Game: AppID 860340

-- MAIN APPLICATION
addappid(860340)

-- MAIN APP DEPOTS / PACKAGES
addappid(860341, 1, "726a4817a69e9e2e9dd3258e3d5d5396f05afcbffe0f944266b0914b8db7ac03")

