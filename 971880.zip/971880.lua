-- Lua provided by RyzenAPI
-- Game: AppID 971880

-- MAIN APPLICATION
addappid(971880)

-- MAIN APP DEPOTS / PACKAGES
addappid(971881, 1, "dcf4ba1ffe43c18c9570fa308629de5858115289371e4701ba103a31eae9d205")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
