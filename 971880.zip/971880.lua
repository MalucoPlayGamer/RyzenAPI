-- Lua provided by RyzenAPI
-- Game: addappid(971880)

-- MAIN APPLICATION
addappid(971880)

-- MAIN APP DEPOTS / PACKAGES
addappid(971881, 1, "dcf4ba1ffe43c18c9570fa308629de5858115289371e4701ba103a31eae9d205")
