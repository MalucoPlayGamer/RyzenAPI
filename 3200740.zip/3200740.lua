-- Lua provided by RyzenAPI
-- Game: 3200740

-- MAIN APPLICATION
addappid(3200740)
-- Game: addappid(3200740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200741, 1, "c4baf83e5245926f9d25998e797ccb431c7a5a5f851ae81931bb93dc0c401af7")
