-- Lua provided by RyzenAPI
-- Game: Heart of a Bird in a Cage (draft version)

-- MAIN APPLICATION
addappid(3195050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195051, 1, "2bd5c32bb7aab96645bed7c6e14c080d6167d8d0541cf2fefe33e9828d74719a")
