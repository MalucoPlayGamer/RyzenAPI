-- Lua provided by RyzenAPI
-- Game: addappid(2363730)

-- MAIN APPLICATION
addappid(2363730)
addappid(3375010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363731, 1, "e4a20ed45bed9ba3018d129f0c3211b82e749f468627006cdda73877a3ddce96")
