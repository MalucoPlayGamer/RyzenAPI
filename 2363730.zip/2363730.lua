-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Questionable Side Stories

-- MAIN APPLICATION
addappid(2363730)
addappid(3375010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363731, 1, "e4a20ed45bed9ba3018d129f0c3211b82e749f468627006cdda73877a3ddce96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
