-- Lua provided by RyzenAPI 
-- Game: FUSER Demo
addappid(1497570)
addappid(1497571, 1, "b3f3c9b6f5cb48a9fe6367720c4fd1fe3632ef3c61559c4ae501484b675f5449")
