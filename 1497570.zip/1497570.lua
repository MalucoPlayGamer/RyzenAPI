-- Lua provided by RyzenAPI
-- Game: Game: FUSER Demo

-- MAIN APPLICATION
addappid(1497570)
-- Game: addappid(1497570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497571, 1, "b3f3c9b6f5cb48a9fe6367720c4fd1fe3632ef3c61559c4ae501484b675f5449")
