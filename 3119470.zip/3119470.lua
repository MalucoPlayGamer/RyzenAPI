-- Lua provided by RyzenAPI
-- Game: 3119470

-- MAIN APPLICATION
addappid(3119470)
-- Game: addappid(3119470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119471, 1, "48d2d7017ff63064c1dd77d4348d960668a460714f7542a0ef7a8efcdbd732ae")
