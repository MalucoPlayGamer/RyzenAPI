-- Lua provided by SkyAPI 
-- Game: A Healer Only Lives Twice
addappid(453300)
addappid(453301, 1, "417c14bfc565acc586a4482d55bdfa909a88b0e4a9e8fc2edcaa50dd774b7d6c")
