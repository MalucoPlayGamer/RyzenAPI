-- Lua provided by RyzenAPI
-- Game: A Healer Only Lives Twice

-- MAIN APPLICATION
addappid(453300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(453301, 1, "417c14bfc565acc586a4482d55bdfa909a88b0e4a9e8fc2edcaa50dd774b7d6c")

