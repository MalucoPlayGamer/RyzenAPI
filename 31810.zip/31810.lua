-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Last Train to Blue Moon Canyon

-- MAIN APPLICATION
addappid(31810)

-- MAIN APP DEPOTS / PACKAGES
addappid(31811, 1, "075e3149e410b7e265814dd6ce4b62fbe7d882223d7b91213ea571d2bbffd406")
