-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in Vienna

-- MAIN APPLICATION
addappid(3454210)
-- Game: addappid(3454210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454211, 1, "f0045f6b48e4754a85ae79b14f8f5676ce59628826df9c100cf25a4b3a55bdbe")
