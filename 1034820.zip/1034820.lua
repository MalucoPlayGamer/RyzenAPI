-- Lua provided by RyzenAPI
-- Game: Puss in Boots: Fear Not Hooman

-- MAIN APPLICATION
addappid(1034820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034821, 1, "d2909cf3a92de7ba33789f0c9dbfed3fa935160f1a80f222c38ee402d6aa8c1a")

