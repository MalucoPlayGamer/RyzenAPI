-- Lua provided by RyzenAPI
-- Game: Sphere Complex

-- MAIN APPLICATION
addappid(550600)
-- Game: addappid(550600)

-- MAIN APP DEPOTS / PACKAGES
addappid(550601, 1, "090cb978f03f257601b713e867335485d0a8537ff351df354574592683f31dd7")
