-- Lua provided by RyzenAPI
-- Game: Goofy Gorillas

-- MAIN APPLICATION
addappid(2627570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2627571, 1, "125b851a17b3e404a6f3fbd2f22f13f21b53842c1e0bddbff9dced085fee0b1b")

