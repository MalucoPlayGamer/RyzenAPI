-- Lua provided by RyzenAPI
-- Game: addappid(2627570)

-- MAIN APPLICATION
addappid(2627570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627571, 1, "125b851a17b3e404a6f3fbd2f22f13f21b53842c1e0bddbff9dced085fee0b1b")
