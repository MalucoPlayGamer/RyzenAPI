-- Lua provided by RyzenAPI
-- Game: Heroes of Valor

-- MAIN APPLICATION
addappid(2504090)
addappid(3775520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504091, 1, "3e50f191606a08b40ed175d4fb830793ffbaf59700dd5b001a41f9e94bc94742")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
