-- Lua provided by RyzenAPI
-- Game: addappid(2504090)

-- MAIN APPLICATION
addappid(2504090)
addappid(3775520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504091, 1, "3e50f191606a08b40ed175d4fb830793ffbaf59700dd5b001a41f9e94bc94742")
