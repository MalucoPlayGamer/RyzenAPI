-- Lua provided by RyzenAPI
-- Game: 永夜镇EternalNightTown

-- MAIN APPLICATION
addappid(3406640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3406641, 1, "1352f9c407608ecfcbea2c3f16bfc7f51b784f4cefa27ca487b49edfe7421f5e")
