-- Lua provided by RyzenAPI
-- Game: AppID 808420

-- MAIN APPLICATION
addappid(808420)

-- MAIN APP DEPOTS / PACKAGES
addappid(808421, 1, "c7876458bd469ecd55cf18ff7a587ef82909729837a694fc4ca53b26e200bf2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
