-- Lua provided by RyzenAPI
-- Game: 808420

-- MAIN APPLICATION
addappid(808420)
-- Game: addappid(808420)

-- MAIN APP DEPOTS / PACKAGES
addappid(808421, 1, "c7876458bd469ecd55cf18ff7a587ef82909729837a694fc4ca53b26e200bf2e")
