-- Lua provided by RyzenAPI 
-- Game: AppID 808420
addappid(808420)
addappid(808421, 1, "c7876458bd469ecd55cf18ff7a587ef82909729837a694fc4ca53b26e200bf2e")
