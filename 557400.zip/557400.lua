-- Lua provided by RyzenAPI
-- Game: Midas Gold Plus - Idle Clicker

-- MAIN APPLICATION
addappid(557400)
