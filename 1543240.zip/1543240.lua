-- Lua provided by RyzenAPI
-- Game: Gigapocalypse

-- MAIN APPLICATION
addappid(1543240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543241, 1, "3ba7ea04460b9490d836b1c97ac6a327ca925e6c7721c82be0a051799f789897")

