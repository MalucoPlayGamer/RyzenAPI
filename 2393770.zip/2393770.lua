-- Lua provided by RyzenAPI
-- Game: addappid(2393770)

-- MAIN APPLICATION
addappid(2393770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393773,0,"ad01288cadb9a2886d0dcb744762bed6134fdb9c16dd7b13c99c9dcabf9bec83")
