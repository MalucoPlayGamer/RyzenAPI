-- Lua provided by SkyAPI 
-- Game: Trash of the Titans
addappid(2450400)
addappid(2450401, 1, "26746a8b70e55aec4453d1f65b98a324351487df2910713826a0ca791806db92")
