-- Lua provided by RyzenAPI
-- Game: Trash of the Titans

-- MAIN APPLICATION
addappid(2450400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450401, 1, "26746a8b70e55aec4453d1f65b98a324351487df2910713826a0ca791806db92")

