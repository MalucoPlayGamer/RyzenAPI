-- Lua provided by RyzenAPI 
-- Game: MINUS ZERO
addappid(430300)
addappid(430301, 1, "907a756a59c9c9f8c38b05d504133b89bdbce0e01e98db8944f4e7e521ffe97a")
