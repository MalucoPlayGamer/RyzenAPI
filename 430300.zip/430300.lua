-- Lua provided by RyzenAPI
-- Game: Game: MINUS ZERO

-- MAIN APPLICATION
addappid(430300)
-- Game: addappid(430300)

-- MAIN APP DEPOTS / PACKAGES
addappid(430301, 1, "907a756a59c9c9f8c38b05d504133b89bdbce0e01e98db8944f4e7e521ffe97a")
