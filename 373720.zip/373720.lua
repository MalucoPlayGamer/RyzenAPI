-- Lua provided by RyzenAPI
-- Game: AppID 373720

-- MAIN APPLICATION
addappid(373720)

-- MAIN APP DEPOTS / PACKAGES
addappid(373721, 1, "5169e98646e2eeeb693de0a4618f0845a371e7d629dd2c7c1b5cb8ef0302ae6a")
addappid(373724, 1, "34c057b1fe0f3421a9ffdde785fc7aa8ad94822c6d8c9620dca9e21bf7499da0")
addappid(373725, 1, "122f4bdf370ce0bb1885231c4823e24021181e896a46ef4bf8eedef86913830b")
addappid(373726, 1, "16556af8916d17c68d66d29b8666727d43ea2cbaaca5b93d8452a7cb1977faac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
