-- Lua provided by SkyAPI 
-- Game: Silence Channel
addappid(1408860)
addappid(1408861, 1, "757b952566c055f6bbaa0d4139d92910a47fafe486eb2597fe2b0ee9246495b0")
