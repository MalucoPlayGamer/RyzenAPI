-- Lua provided by RyzenAPI
-- Game: Silence Channel

-- MAIN APPLICATION
addappid(1408860)
-- Game: addappid(1408860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408861, 1, "757b952566c055f6bbaa0d4139d92910a47fafe486eb2597fe2b0ee9246495b0")
