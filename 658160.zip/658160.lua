-- Lua provided by RyzenAPI
-- Game: ClickRaid

-- MAIN APPLICATION
addappid(658160)

-- MAIN APP DEPOTS / PACKAGES
addappid(658161, 1, "30e85dc01b8857acb9faf437bd7d02cacc960f964dcb745cf8df67efbeb26357")
addappid(658163, 1, "6d4d2c501c7feae0f2a006a0602d2c14086116df1c7a0674de200641d5d97743")
addappid(658164, 1, "c7d018a42a9234db303d8d140a618191870c357e2ae98d028ce1cff34a6d40c9")
addappid(658165, 1, "83a7e52621364044d8c06408bbb166f674121b2ed4dff92b7db42813c7d8b22c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(658910)
addappid(738870)
addappid(757280)
addappid(804310)
