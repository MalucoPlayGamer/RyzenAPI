-- Lua provided by RyzenAPI
-- Game: Game: A Valley Without Wind

-- MAIN APPLICATION
addappid(209330)
-- Game: addappid(209330)

-- MAIN APP DEPOTS / PACKAGES
addappid(209331, 1, "c11e20ad969a9f6e3d77022ce5a6a88c6936c4cf3851efdf2c62c466c93987e3")
addappid(209332, 1, "5f1e2aab527de075bacbbc13f7613df3b959cfa2127861f47a81fb8b4bc64d47")
addappid(209333, 1, "17c5ea8284132842bce8d35486abbf15cd998ca24c2af21812e148624d5f9848")
addappid(209334, 1, "7ce5b7b9513764c516303492cd73838003610e3d50f225c797feb9cfef0cb4b8")
addappid(209335, 1, "92b132056996f47e0cfee50c55901265f9c6f3395698f9b6b6bbbed6e2654d2b")
