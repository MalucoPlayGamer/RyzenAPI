-- Lua provided by RyzenAPI
-- Game: 996900

-- MAIN APPLICATION
addappid(996900)

-- MAIN APP DEPOTS / PACKAGES
addappid(996900,0,"2716deed79129df5357012950da9ad71cffd2d17c7b3bf12e0fe622aacd7995d")

