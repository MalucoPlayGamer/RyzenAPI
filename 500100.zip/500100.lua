-- Lua provided by RyzenAPI
-- Game: Game: AppID 500100

-- MAIN APPLICATION
addappid(500100)
-- Game: addappid(500100)

-- MAIN APP DEPOTS / PACKAGES
addappid(500101, 1, "919ffcbe6ea49b92f59d9c660fc3e9226b5079b8b567e6c3112552fc19d718bb")
