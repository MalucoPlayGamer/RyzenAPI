-- Lua provided by RyzenAPI
-- Game: addappid(1481960)

-- MAIN APPLICATION
addappid(1481960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481961, 1, "f5c6a5537d98a438b21f073abbb76043ea8027eace6e777c0545bae0eb683015")
