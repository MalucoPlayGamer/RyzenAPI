-- Lua provided by RyzenAPI
-- Game: Sumotori Dreams Classic Demo

-- MAIN APPLICATION
addappid(1614720)
-- Game: addappid(1614720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614721, 1, "8b9c43f675542bf33df5d5d20e305b18ce02418cc6a6c7bb1087059257ce888a")
