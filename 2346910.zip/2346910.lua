-- Lua provided by RyzenAPI
-- Game: Boba Tea Shop Simulator Demo

-- MAIN APPLICATION
addappid(2346910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346911, 1, "224e918450f56911944181563319e63f1b5d0211c8ab00ac46bf0e0b788e4448")

