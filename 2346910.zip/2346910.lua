-- Lua provided by RyzenAPI 
-- Game: AppID 2346910
addappid(2346910)
addappid(2346911, 1, "224e918450f56911944181563319e63f1b5d0211c8ab00ac46bf0e0b788e4448")
