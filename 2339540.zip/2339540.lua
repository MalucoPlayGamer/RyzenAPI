-- Lua provided by RyzenAPI
-- Game: AppID 2339540

-- MAIN APPLICATION
addappid(2339540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339541, 1, "91eea8847bd3d4b8b737710978ae90843dfca0de01a3fb874fdbcec157a3e231")

