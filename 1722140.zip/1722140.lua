-- Lua provided by RyzenAPI
-- Game: Hop Step Sing! Happy People

-- MAIN APPLICATION
addappid(1722140)
-- Game: addappid(1722140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722141, 1, "20790240718503c4041062920766319d934c29227b971a8cdb8b7ca2a496859c")
