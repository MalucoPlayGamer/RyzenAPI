-- Lua provided by RyzenAPI
-- Game: Yet Another Pushing Puzzler

-- MAIN APPLICATION
addappid(853410)

-- MAIN APP DEPOTS / PACKAGES
addappid(853411, 1, "0f77cf92433d97a7c8cff07906e88bfac3e700c535824f44bbeeeb1bcf8fb79c")

