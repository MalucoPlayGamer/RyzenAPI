-- Lua provided by RyzenAPI
-- Game: 2442100

-- MAIN APPLICATION
addappid(2442100)
-- Game: addappid(2442100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442101, 1, "abe1e8a6ecc7b22c729bd76b120570aab30c20ef0db01495b7d51b926663c584")
