-- Lua provided by RyzenAPI
-- Game: Only Climb: Better Together

-- MAIN APPLICATION
addappid(2500750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500751, 1, "c82e047e2c2bbce9406fdf9320df389fec982147d49a445fbc8be31f10217ceb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
