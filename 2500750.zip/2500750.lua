-- Lua provided by RyzenAPI
-- Game: Only Climb: Better Together

-- MAIN APPLICATION
addappid(2500750)
-- Game: addappid(2500750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500751, 1, "c82e047e2c2bbce9406fdf9320df389fec982147d49a445fbc8be31f10217ceb")
