-- Lua provided by RyzenAPI
-- Game: Faulty Apprentice: Palm Tree Paradise (4th DLC)

-- MAIN APPLICATION
addappid(1393040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393041, 1, "8b8067e0a2ac87f2de1da96e6cb913ce354eeeb76772183174072dbc709b13ed")

