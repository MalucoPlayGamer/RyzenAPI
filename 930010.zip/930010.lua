-- Lua provided by RyzenAPI
-- Game: Wallpaper Builder

-- MAIN APPLICATION
addappid(930010)

-- MAIN APP DEPOTS / PACKAGES
addappid(930011, 1, "e63fbba431a493768cf7212700f9ddebf5d43e05a9ca539bead687edbcf858c8")
