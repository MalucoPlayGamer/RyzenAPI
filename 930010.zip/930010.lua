-- Lua provided by RyzenAPI
-- Game: Wallpaper Builder

-- MAIN APPLICATION
addappid(930010)

-- MAIN APP DEPOTS / PACKAGES
addappid(930011, 1, "e63fbba431a493768cf7212700f9ddebf5d43e05a9ca539bead687edbcf858c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
