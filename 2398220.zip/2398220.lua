-- Lua provided by RyzenAPI
-- Game: The Hero's Way

-- MAIN APPLICATION
addappid(2398220)
-- Game: addappid(2398220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398221, 1, "999b637880d76f6b52f3792a834db4eb6a5b106300906684d8633496e3972d75")
