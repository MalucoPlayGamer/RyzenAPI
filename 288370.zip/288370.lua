-- Lua provided by RyzenAPI
-- Game: Strike Suit Zero: Director's Cut

-- MAIN APPLICATION
addappid(288370)
addappid(301800)

-- MAIN APP DEPOTS / PACKAGES
addappid(288371, 1, "41fc913f368930800e0925cf5dd3d99e60fc19579aacf34ae57fce4bc2684f0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
