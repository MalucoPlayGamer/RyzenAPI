-- Lua provided by RyzenAPI
-- Game: Strike Suit Zero: Director's Cut

-- MAIN APPLICATION
addappid(288370)
addappid(301800)
-- Game: addappid(288370)

-- MAIN APP DEPOTS / PACKAGES
addappid(288371, 1, "41fc913f368930800e0925cf5dd3d99e60fc19579aacf34ae57fce4bc2684f0a")
