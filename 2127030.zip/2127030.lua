-- Lua provided by RyzenAPI
-- Game: Date or Destiny : Kiss or Miss

-- MAIN APPLICATION
addappid(2127030)
-- Game: addappid(2127030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127031, 1, "f93b6c72709abf9fbb675c9702f5a15a13248103754cb247394c4678302ecc29")
