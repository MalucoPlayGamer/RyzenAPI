-- Lua provided by RyzenAPI
-- Game: Gunvolt Chronicles: Luminous Avenger iX 2

-- MAIN APPLICATION
addappid(1733880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733881, 1, "3f969b66c0fe69c2a218f40d59921e1fd1204e7de05d4b066c8053518a17c28a")
addappid(1851220, 0, "8edbe1c95ddb03800574da99d29a8398c394c0bb34c19553821e5b22f6c0aff5")
addappid(1867680, 0, "38c1317ecc581ffa8b09996fa22ef53185775d5e143484771ee3f9218c6854e8")
addappid(1867690, 0, "d1b8965abd9613344479143ca4776cff25d76a1363687911bce514cf69c1449d")
addappid(1867700, 0, "6b7b39c1846e1a509015a8bddac18c0d7f64049f2da6ee815bb028e998a270ca")
addappid(1867710, 0, "b886195626b236713fe04721d9e0a40b5116f145cebc41e89821dc9236f628ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
