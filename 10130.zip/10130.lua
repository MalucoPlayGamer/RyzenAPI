-- Lua provided by RyzenAPI
-- Game: 10130

-- MAIN APPLICATION
addappid(10130)
-- Game: addappid(10130)

-- MAIN APP DEPOTS / PACKAGES
addappid(10131, 1, "507c6110c58879eb65845e99402af13ae037cd77a9fd60b400106b53df732a88")
