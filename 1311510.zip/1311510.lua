-- Lua provided by RyzenAPI
-- Game: 1311510

-- MAIN APPLICATION
addappid(1311510)
-- Game: addappid(1311510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311511, 1, "875c5144e0e8e2ad45dd4075f94c9b15a7315ab1f0d162dbd8d4c443b4dddca8")
