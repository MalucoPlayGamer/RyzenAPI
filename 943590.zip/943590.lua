-- Lua provided by RyzenAPI
-- Game: addappid(943590)

-- MAIN APPLICATION
addappid(943590)

-- MAIN APP DEPOTS / PACKAGES
addappid(943592,0,"6c0f0ad9a9ef9dd6b0dcd798c6d04d0ebe76f3cc75086cea908f6ea14581c51a")
addappid(943593,0,"5a78f9113770e2eb143792f8cb00bc650bd14f6a5945cb121a9317a64e8b0ff8")
