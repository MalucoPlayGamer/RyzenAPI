-- Lua provided by RyzenAPI
-- Game: Game: Wolfstride

-- MAIN APPLICATION
addappid(1331210)
-- Game: addappid(1331210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331211, 1, "b2ab2bb03a678788aa257d6f530531c16e4765edc5ecb6b6d01388a3ad5c913c")
addappid(1833760, 0, "e92e0dd096474687edb262463213dd85fb8187cd1a66941c5d26980858074f8d")
