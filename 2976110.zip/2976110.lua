-- Lua provided by RyzenAPI
-- Game: Separated

-- MAIN APPLICATION
addappid(2976110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976111,0,"b0ea25aaac395790c55774083c8e85035609dabc044636263e3211424225b8f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
