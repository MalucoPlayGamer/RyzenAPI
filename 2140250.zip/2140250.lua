-- Lua provided by RyzenAPI
-- Game: Kena: Bridge of Spirits Soundtrack

-- MAIN APPLICATION
addappid(2140250)
-- Game: addappid(2140250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140251, 1, "a169a6c2bfdd785fbef4058e63cf2231895411dbb93168d090b5089ffedad410")
addappid(2140252, 1, "89f36e7c622c073c746c841c9597ba538b5f2e9c0a1e1d7b9eab3d29482b687a")
