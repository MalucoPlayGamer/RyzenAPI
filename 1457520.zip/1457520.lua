-- Lua provided by RyzenAPI
-- Game: 1457520

-- MAIN APPLICATION
addappid(1457520)
-- Game: addappid(1457520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457521, 1, "3dedeba0a02c748648f7a0e7104a8c7260f2c40d3a3005298c09bf22e98d4ed0")
