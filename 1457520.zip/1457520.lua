-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Zero no Kiseki Kai

-- MAIN APPLICATION
addappid(1457520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457521, 1, "3dedeba0a02c748648f7a0e7104a8c7260f2c40d3a3005298c09bf22e98d4ed0")

