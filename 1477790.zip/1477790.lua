-- Lua provided by RyzenAPI
-- Game: Luna's Fishing Garden

-- MAIN APPLICATION
addappid(1477790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477791, 1, "bc75b216858adddd7935c4908fbb8d8dc8ec768fdd039de185e02621b14edaed")
