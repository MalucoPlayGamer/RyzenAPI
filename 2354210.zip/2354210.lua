-- Lua provided by SkyAPI 
-- Game: AppID 2354210
addappid(2354210)
addappid(2354211, 1, "f0dd4c190a584eb95bef98be2b1471d26ea96a89d5bd509468d032b1e3dc5916")
