-- Lua provided by RyzenAPI
-- Game: Rise of Gun Demo

-- MAIN APPLICATION
addappid(2354210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354211, 1, "f0dd4c190a584eb95bef98be2b1471d26ea96a89d5bd509468d032b1e3dc5916")

