-- Lua provided by RyzenAPI
-- Game: Metro Exodus Enhanced Edition

-- MAIN APPLICATION
addappid(1449560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449561, 1, "0bceeea8048e48e451693146c33f2ea54932dfe36ae0f6ccce505d07e1d7930a")
addappid(1449562, 1, "70f09a9fb7115c8689a965227487211709491ca9d0c923c0c95f4685db9c5884")
addappid(1557620, 0, "ef30d0b772922e812c05280f281c6f59bf38aff30b9b0d2980a62b7c7c083d29")
addappid(1557621, 0, "e2cb897ffc11660b24b70ca22aeaa58efa2c3e9f6efb47e637ed43d24fa7feff")
