-- Lua provided by RyzenAPI 
-- Game: Citizens: Far Lands
addappid(1646120)
addappid(1646121, 1, "8ce132db2d751ca200fcf62cfb5a92c803bb6bd1aba18d5270ea40a9f30dd9a1")
