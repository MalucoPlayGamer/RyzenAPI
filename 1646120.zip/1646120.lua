-- Lua provided by RyzenAPI
-- Game: Citizens: Far Lands

-- MAIN APPLICATION
addappid(1646120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1646121, 1, "8ce132db2d751ca200fcf62cfb5a92c803bb6bd1aba18d5270ea40a9f30dd9a1")

