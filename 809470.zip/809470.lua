-- Lua provided by RyzenAPI
-- Game: Survivor Island

-- MAIN APPLICATION
addappid(809470)
-- Game: addappid(809470)

-- MAIN APP DEPOTS / PACKAGES
addappid(809471, 1, "ea7e779e9ca91434dc065659763cfc99d1bd5682142ca970daaee3ccc993449f")
