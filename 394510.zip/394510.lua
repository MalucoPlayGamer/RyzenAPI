-- Lua provided by RyzenAPI
-- Game: AppID 394510

-- MAIN APPLICATION
addappid(394510)

-- MAIN APP DEPOTS / PACKAGES
addappid(394511, 1, "9354a50886239c53583780315103fac2c9ca6d9e6c4b80ec921a1b49c653e51a")
addappid(394512, 1, "1094ae83b6e8a79e54aa77393680801204d7ab74e4556a08b6ced06933afdb68")
addappid(394513, 1, "1760bb243e446b5591684d821d4bfd318c8ba76d0af39f454786e7bfe01f3e9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(395230)
addappid(395231)
addappid(395232)
addappid(395233)
addappid(395234)
addappid(395235)
addappid(395236)
addappid(395237)
addappid(395238)
addappid(395239)
addappid(396170)
addappid(396171)
addappid(396172)
addappid(396173)
addappid(542760)
addappid(542761)
addappid(1329700)
addappid(1329701)
addappid(1329702)
addappid(1329703)
addappid(1329704)
addappid(1329705)
addappid(1329706)
addappid(1329707)
addappid(1329708)
