-- Lua provided by RyzenAPI
-- Game: Mount & Blade II: Bannerlord

-- MAIN APPLICATION
addappid(2194520)
addappid(2240110)
addappid(2927200)
addappid(4456490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(261550, 1, "979c4a097d819ee61862a7ad898e1a20dea3708a8dcbeaaa00a54c4975c1b107")
addappid(261551, 1, "16a71c423df683e98af58e40c60a6fc8087dc360f977a73c7d138e8d26b99062") -- (windows, 64-bit)
addappid(261552, 1, "b6cfe4c61b9f19a7399a290c50b3dc18052f63b095401ffb3aa8286277597365") -- (windows, 64-bit)
addappid(2194521, 1, "37b0e0ec7e17d59a6134c8537144e8a03d3b659627a6f8cb219f6318c5daef66")
addappid(2194523, 1, "3ca163dc7ae2e8b921eaf3da66b9d60d253a7e031689202dbb830ff20511c4c2")
addappid(2240111, 1, "172d8d7fb867c14dfe3251829c334dd13bd3fa452eca4f34a3c583ed9928efea") -- (windows, 64-bit)
addappid(2927200, 1, "27f86f83a59f156011599d935b8f3f25a5472b9030cd56a2a91aa0597f939512") -- (windows, 64-bit)
addappid(4456490, 1, "77bd4b511a0c5823331372155f4cc406df167f9a3181fe3cbfec32d41b5183ed") -- (windows, 64-bit)

