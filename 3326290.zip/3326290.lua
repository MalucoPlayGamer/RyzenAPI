-- Lua provided by RyzenAPI
-- Game: Internet Cafe Simulator 2025

-- MAIN APPLICATION
addappid(3326290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326291, 1, "154f4a71cfa03300a41ba6388ec89e71f34135736d26024465d1f551e804ea9f")
