-- Lua provided by RyzenAPI
-- Game: Game: Phantom Fury

-- MAIN APPLICATION
addappid(1733240)
-- Game: addappid(1733240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733241, 1, "3cfe77c0a8458712950b1f1eb9485e8846e4b1aa4410171c47bdc02eb0c03096")
