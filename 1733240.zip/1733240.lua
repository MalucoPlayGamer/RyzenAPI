-- Lua provided by RyzenAPI
-- Game: Phantom Fury

-- MAIN APPLICATION
addappid(1733240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733241, 1, "3cfe77c0a8458712950b1f1eb9485e8846e4b1aa4410171c47bdc02eb0c03096")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2934670)
