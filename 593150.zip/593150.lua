-- Lua provided by RyzenAPI
-- Game: Game: AppID 593150

-- MAIN APPLICATION
addappid(593150)
-- Game: addappid(593150)

-- MAIN APP DEPOTS / PACKAGES
addappid(593151, 1, "b4ee0611fdd059f6a536960846241bc2622e51d5008c36dd5dab63506661a200")
