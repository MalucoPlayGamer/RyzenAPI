-- Lua provided by RyzenAPI
-- Game: 958210

-- MAIN APPLICATION
addappid(958210)
-- Game: addappid(958210)

-- MAIN APP DEPOTS / PACKAGES
addappid(958211, 1, "8f0711f9419e2c44d92f768ac91ce4dcffca34ce30f39fb070ebbdcf27fdd002")
