-- Lua provided by RyzenAPI
-- Game: addappid(1693980)

-- MAIN APPLICATION
addappid(1693980)
addappid(2164210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693981, 1, "9738ac7c4b941978165b403d5785d6c8c331366f7feb30c0b276401fd71f4ccb")
