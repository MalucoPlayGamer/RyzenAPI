-- Lua provided by RyzenAPI
-- Game: Dead Space

-- MAIN APPLICATION
addappid(1693980)
addappid(2164210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693981, 1, "9738ac7c4b941978165b403d5785d6c8c331366f7feb30c0b276401fd71f4ccb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
