-- Lua provided by RyzenAPI
-- Game: Boom Buddy

-- MAIN APPLICATION
addappid(3630310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3630311, 1, "76077dbe7b37758d8919b7f72ee9f2b51e247bba21f73c1416a63a02a8257eb0")
