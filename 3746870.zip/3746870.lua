-- Lua provided by RyzenAPI
-- Game: 本草计划·桌面实验室

-- MAIN APPLICATION
addappid(3746870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3746871, 1, "4e708c1488d3010f45bba7502d9990aa572192aa27a59c0e031286d73e2e9603")
