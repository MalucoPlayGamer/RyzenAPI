-- Lua provided by RyzenAPI
-- Game: Strikers Club

-- MAIN APPLICATION
addappid(1952920)
