-- Lua provided by RyzenAPI
-- Game: addappid(3586100)

-- MAIN APPLICATION
addappid(3586100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586101, 1, "b9bc7797c0b239a0f5a6e8f05b71e27546944899e9a89db67ee3b5bdf5a6da38")
addappid(3586103, 1, "823cdf96fb9eeaed94674a47fe10dbbac49be1283cc27f5e61b0e6e3bc306b1c")
