-- Lua provided by RyzenAPI
-- Game: addappid(2505700)

-- MAIN APPLICATION
addappid(2505700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505701, 1, "f7d73eb07ea21b9f6accfbd1f95bda607aa911864b87ad5edb09de6edc5373ee")
