-- Lua provided by RyzenAPI
-- Game: 2937100

-- MAIN APPLICATION
addappid(2937100)
-- Game: addappid(2937100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937101, 1, "03dbcf32f6256fc4c7a9b3326f36b9978f18413dce6dacd71583acc467075b8d")
