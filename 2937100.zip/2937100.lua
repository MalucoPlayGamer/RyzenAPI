-- Lua provided by SkyAPI 
-- Game: Saiko no sutoka no shiki Demo
addappid(2937100)
addappid(2937101, 1, "03dbcf32f6256fc4c7a9b3326f36b9978f18413dce6dacd71583acc467075b8d")
