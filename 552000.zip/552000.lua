-- Lua provided by RyzenAPI
-- Game: Blowhards

-- MAIN APPLICATION
addappid(552000)

-- MAIN APP DEPOTS / PACKAGES
addappid(552001,0,"e134d6b2b72481318ef45edd3bcf2ada7a3937240df46b4c64a2801297342829")

