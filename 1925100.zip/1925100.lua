-- Lua provided by RyzenAPI
-- Game: illumizzle: Finding the lost light

-- MAIN APPLICATION
addappid(1925100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925101, 1, "b6c69a6489290564624c7a93873ef2f96ca3ba3b385495699f7d90c9a9d56e4e")

