-- Lua provided by RyzenAPI
-- Game: Game: Out of Ammo: Death Drive

-- MAIN APPLICATION
addappid(569630)
-- Game: addappid(569630)

-- MAIN APP DEPOTS / PACKAGES
addappid(569631, 1, "480b0b758a3a71361bec475787169cdb84a9e064333c3b47863d2f84c9241abf")
