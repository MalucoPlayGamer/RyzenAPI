-- Lua provided by RyzenAPI
-- Game: 908840

-- MAIN APPLICATION
addappid(908840)
-- Game: addappid(908840)

-- MAIN APP DEPOTS / PACKAGES
addappid(908841, 1, "c3281f8fb4e7245a1aee07847c93afff55672fbbcc1851c9d59cd2963174f185")
