-- Lua provided by RyzenAPI 
-- Game: Thunder Wolves
addappid(232970)
addappid(232971, 1, "a96712d03eeb9b91da31834884884c96c9602822e77f9c9ab2e780fcdbbf4415")
