-- Lua provided by RyzenAPI
-- Game: Thunder Wolves

-- MAIN APPLICATION
addappid(232970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(232971, 1, "a96712d03eeb9b91da31834884884c96c9602822e77f9c9ab2e780fcdbbf4415")

