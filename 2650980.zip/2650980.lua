-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2650980)
-- Game: addappid(2650980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650980,0,"1f88343852ba3ccaba88efce48884614d8e1fc3e5a50cf3fe5db6bf6503457e4")
