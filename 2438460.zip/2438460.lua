-- Lua provided by RyzenAPI
-- Game: Evil Robots

-- MAIN APPLICATION
addappid(2438460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438461, 1, "10b1f26f76a87ae63d52b3c009b0680b9878cf38f0284c97acc5125c6856c44d")
addappid(2438463, 1, "a635f0fa1a3493beb0435a69a381914a41c9db15adf7fef9f72447876509293c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
