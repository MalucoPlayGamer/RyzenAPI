-- Lua provided by SkyAPI 
-- Game: Evil Robots
addappid(2438460)
addappid(2438461, 1, "10b1f26f76a87ae63d52b3c009b0680b9878cf38f0284c97acc5125c6856c44d")
addappid(2438463, 1, "a635f0fa1a3493beb0435a69a381914a41c9db15adf7fef9f72447876509293c")
