-- Lua provided by RyzenAPI
-- Game: 3103700

-- MAIN APPLICATION
addappid(3103700)
-- Game: addappid(3103700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103701, 1, "36c1fefeb6d82dc90ed9ef555d0bebc756b524b5c1b5c0f949fd814573b8436b")
