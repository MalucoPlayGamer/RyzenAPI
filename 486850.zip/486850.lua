-- Lua provided by RyzenAPI
-- Game: AppID 486850

-- MAIN APPLICATION
addappid(486850)

-- MAIN APP DEPOTS / PACKAGES
addappid(486851, 1, "a3a0bc80e1059fdb854e661bddf255283b450ee5a3a9fa3a4f063187b9ffa9f9")
