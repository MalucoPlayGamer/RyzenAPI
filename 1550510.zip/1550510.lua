-- Lua provided by SkyAPI 
-- Game: Creepy Tale 2
addappid(1550510)
addappid(1550511, 1, "19638293ad90a5fbaffc56f4304f3d12cac644eef471c4fbd1667a070ec8daf5")
addappid(1550512, 1, "7ae446b3d0d8dbc6e330872d894da9f27749f8b3137a112cacd810733f0e7a6e")
addappid(1550513, 1, "f413c4277cebe2f4860a61685ccd4c749403bbc619b713fb36eb1bd912cb00ad")
