-- Lua provided by RyzenAPI
-- Game: GUNVOLT RECORDS Cychronicle Demo

-- MAIN APPLICATION
addappid(2720450)
-- Game: addappid(2720450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720451, 1, "12e5ec6f104d89241ba377e8974126b35be5292d0fa86a6c7827aa9a419c8e12")
