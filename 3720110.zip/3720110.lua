-- Lua provided by RyzenAPI
-- Game: Game: PULLBACK RACERS

-- MAIN APPLICATION
addappid(3720110)
-- Game: addappid(3720110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720111, 1, "4560febbcaedea7f9fdbcc677977d235d938f0482a0bb0e2f35fd11cd2f962d8")
