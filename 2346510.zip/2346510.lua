-- Lua provided by RyzenAPI
-- Game: Rainbowcore Hypernova

-- MAIN APPLICATION
addappid(2346510)
-- Game: addappid(2346510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346511, 1, "1a06726d02fa8d45a70529e18732fe1004fbf605066ce8c3429724f2cada6881")
