-- Lua provided by RyzenAPI
-- Game: Kindred Spirits on the Roof Original Soundtrack

-- MAIN APPLICATION
addappid(958870)

-- MAIN APP DEPOTS / PACKAGES
addappid(958871, 1, "634b85b471db77a5b42b8926fdef28d60edba3434b881dea1a9b732d8895b963")

