-- Lua provided by RyzenAPI
-- Game: AppID 1245610

-- MAIN APPLICATION
addappid(1245610)
addappid(1564820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1245611, 1, "8f0d1e782ef92d26a8c2566869d3dc9f394383cb37347bde60d823145d74b23b")

