-- Lua provided by RyzenAPI
-- Game: AppID 1245610

-- MAIN APPLICATION
addappid(1245610)
-- Game: addappid(1245610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245611, 1, "8f0d1e782ef92d26a8c2566869d3dc9f394383cb37347bde60d823145d74b23b")
