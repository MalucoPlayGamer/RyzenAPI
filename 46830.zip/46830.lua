-- Lua provided by RyzenAPI
-- Game: addappid(46830)

-- MAIN APPLICATION
addappid(46830)

-- MAIN APP DEPOTS / PACKAGES
addappid(46831, 1, "ed6c2fdacd6b57ef7faa0eb9581fb883c7b9a6f1aeb45b7ca33cfdb96029a03c")
