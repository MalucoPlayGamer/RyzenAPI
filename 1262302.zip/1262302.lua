-- Lua provided by RyzenAPI
-- Game: 1262302

-- MAIN APPLICATION
addappid(1262302)
-- Game: addappid(1262302)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262302,0,"f80e47c042cbb3f9ed8045a8cf9b41cbfe92f755bb2afa9998316574f3e4d0db")
