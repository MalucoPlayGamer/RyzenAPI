-- Lua provided by RyzenAPI
-- Game: Game: AppID 538710

-- MAIN APPLICATION
addappid(538710)
-- Game: addappid(538710)

-- MAIN APP DEPOTS / PACKAGES
addappid(538711, 1, "f078bdba19713439c042064588c6b05bbdcaeee2b47f9e941b91518d68ae8b66")
