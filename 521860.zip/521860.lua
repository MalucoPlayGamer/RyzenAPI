-- Lua provided by RyzenAPI
-- Game: 521860

-- MAIN APPLICATION
addappid(521860)
-- Game: addappid(521860)

-- MAIN APP DEPOTS / PACKAGES
addappid(521861, 1, "bf8ace1b72b9dedbb4103106546dd9b680fddeec03541ef2b927692fd5f6ba6f")
