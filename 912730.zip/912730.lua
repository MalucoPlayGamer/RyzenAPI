-- Lua provided by RyzenAPI
-- Game: AppID 912730

-- MAIN APPLICATION
addappid(912730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(912731, 1, "9eab5659096a2ef1c9c9d1f7489625b1b49a5173c4ac7dca7b42803c89036ca5")

