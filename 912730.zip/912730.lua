-- Lua provided by RyzenAPI
-- Game: AppID 912730

-- MAIN APPLICATION
addappid(912730)
-- Game: addappid(912730)

-- MAIN APP DEPOTS / PACKAGES
addappid(912731, 1, "9eab5659096a2ef1c9c9d1f7489625b1b49a5173c4ac7dca7b42803c89036ca5")
