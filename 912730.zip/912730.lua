-- Lua provided by RyzenAPI 
-- Game: AppID 912730
addappid(912730)
addappid(912731, 1, "9eab5659096a2ef1c9c9d1f7489625b1b49a5173c4ac7dca7b42803c89036ca5")
