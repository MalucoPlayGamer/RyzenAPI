-- Lua provided by RyzenAPI
-- Game: Frozen State

-- MAIN APPLICATION
addappid(270270)
-- Game: addappid(270270)

-- MAIN APP DEPOTS / PACKAGES
addappid(270271, 1, "2e1ac86260329d1b614fdab3aedc7f944dfa4d31239ebd0c0da764ba6c775ba1")
addappid(270272, 1, "19d5d44cb03107cfd7b45ac5f8b071d5997fa2bb997d232e8f29b61594eb079f")
addappid(270273, 1, "23bb2760481720a90d3c5e563c22bdab74d11ee8d8f906cb5b71f83b0be83ced")
addappid(270274, 1, "1ec1f2bb823384ec58acaff4ba4ba70dc964ef9ca26d7e8461a688149543dab4")
addappid(270275, 1, "5653765d983fcc978069f1e6d646d1dfced217f79233704edb97abbf1d252c2a")
addappid(270276, 1, "20cecee7d3bb3cff1285a0dec1c219459bd5ec1f5a57761d898d8754bca027f7")
