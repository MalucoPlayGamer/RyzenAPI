-- Lua provided by RyzenAPI
-- Game: Sonic Frontiers

-- MAIN APPLICATION
addappid(1237320)
addappid(2079300)
addappid(2079301)
addappid(2089730)
addappid(2089733)
addappid(2089840)
addappid(2093240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1237321, 1, "9c57e01f36d7bf7a77b07678b08a0e690d785dfbcd9a421ae1fc2157741b5ccd")

