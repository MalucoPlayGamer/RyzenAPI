-- Lua provided by RyzenAPI
-- Game: Game: AppID 1237320

-- MAIN APPLICATION
addappid(1237320)
-- Game: addappid(1237320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237321, 1, "9c57e01f36d7bf7a77b07678b08a0e690d785dfbcd9a421ae1fc2157741b5ccd")
