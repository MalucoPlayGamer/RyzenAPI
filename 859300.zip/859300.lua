-- Lua provided by RyzenAPI
-- Game: Game: Hakoniwa Explorer Plus - Original Soundtrack

-- MAIN APPLICATION
addappid(859300)
-- Game: addappid(859300)

-- MAIN APP DEPOTS / PACKAGES
addappid(859301, 1, "333d1a86b8b0cbb32e5053cb83d00c49f60884e151904e730ca6d1bd38d0b917")
