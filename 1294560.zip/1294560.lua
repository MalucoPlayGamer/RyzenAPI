-- Lua provided by RyzenAPI 
-- Game: AppID 1294560
addappid(1294560)
addappid(1294561, 1, "c45d8bd325022591878013633ba6c6d8404867d27a4eef0a30ff29ce4dfaa01e")
addappid(1294562, 1, "8d59a0ad4296352ce883f2a1fd498b520e57fd361f328ec24d3d43ff1d136652")
