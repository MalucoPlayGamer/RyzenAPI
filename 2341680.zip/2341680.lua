-- Lua provided by SkyAPI 
-- Game: Live with Mary
addappid(2341680)
addappid(2341681, 1, "61a16393ca9fb57bb9b11055ea8afa39cbb6e4427e6486e7fe410edb2ccdd741")
