-- Lua provided by RyzenAPI
-- Game: AppID 3652230

-- MAIN APPLICATION
addappid(3652230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3652231, 1, "691865d4aaeaa706510cf0c7483d0a394347fe54c0c0f64ca03fb332db7eca15")

