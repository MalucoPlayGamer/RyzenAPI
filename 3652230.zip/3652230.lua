-- Lua provided by RyzenAPI
-- Game: Game: AppID 3652230

-- MAIN APPLICATION
addappid(3652230)
-- Game: addappid(3652230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652231, 1, "691865d4aaeaa706510cf0c7483d0a394347fe54c0c0f64ca03fb332db7eca15")
