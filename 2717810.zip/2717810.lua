-- Lua provided by RyzenAPI 
-- Game: Void Wizard
addappid(2717810)
addappid(2717811, 1, "0906bac0fa19813613a57abad8dc9eec6b3dbfa0e39dae4014de1059a3fc86de")
