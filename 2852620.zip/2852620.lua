-- Lua provided by RyzenAPI
-- Game: New Warfare

-- MAIN APPLICATION
addappid(2852620)
-- Game: addappid(2852620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852621, 1, "6547207023a3ddb8f2a2057f0f2781ba35701376b5608e95e642923550100c50")
