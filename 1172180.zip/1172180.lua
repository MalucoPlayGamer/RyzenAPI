-- Lua provided by RyzenAPI
-- Game: Game: Cosplay Club

-- MAIN APPLICATION
addappid(1172180)
-- Game: addappid(1172180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172181, 1, "bb3b6448e3f4938d46ce9253f18c8a58721b6dbf3934642932491e3258b111d9")
