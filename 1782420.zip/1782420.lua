-- Lua provided by RyzenAPI
-- Game: Tales from The Dancing Moon

-- MAIN APPLICATION
addappid(1782420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782421, 1, "f15ddfbdcc5ae7259e05262e1e33f20c14eee0114e095ee775ed833977a89f06")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
