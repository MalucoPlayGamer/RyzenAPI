-- Lua provided by RyzenAPI 
-- Game: Tales from The Dancing Moon
addappid(1782420)
addappid(1782421, 1, "f15ddfbdcc5ae7259e05262e1e33f20c14eee0114e095ee775ed833977a89f06")
