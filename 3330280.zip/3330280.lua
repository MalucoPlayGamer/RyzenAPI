-- Lua provided by RyzenAPI
-- Game: Game: Free Solitaire

-- MAIN APPLICATION
addappid(3330280)
-- Game: addappid(3330280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330281, 1, "df13d23417629d917d49521cea93510868fffec978838f86ca2e76521bd80ea3")
addappid(3330282, 1, "0e6bd3e3aebd507936cf2c33a403be4f2f31c745ca7e09abb1d4f15c15118c36")
addappid(3330283, 1, "df77de1bb8a6ae9800d8f06b6ba60ccd28127606083146ea638ad9a36bce27eb")
