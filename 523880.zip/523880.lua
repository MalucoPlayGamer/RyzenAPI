-- Lua provided by RyzenAPI
-- Game: peakvox Escape Virus HD

-- MAIN APPLICATION
addappid(523880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(523881, 1, "3d284dfa81c7d7b4955caa88f195be70ec09666d3d95b2cc1a6b514c66277d15")

