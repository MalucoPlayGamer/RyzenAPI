-- Lua provided by RyzenAPI
-- Game: peakvox Escape Virus HD

-- MAIN APPLICATION
addappid(523880)
-- Game: addappid(523880)

-- MAIN APP DEPOTS / PACKAGES
addappid(523881, 1, "3d284dfa81c7d7b4955caa88f195be70ec09666d3d95b2cc1a6b514c66277d15")
