-- Lua provided by RyzenAPI
-- Game: ACE - Arena: Cyber Evolution

-- MAIN APPLICATION
addappid(285580)
addappid(287620)
addappid(316130)
addappid(316131)
addappid(318270)
addappid(318271)
addappid(318272)
addappid(318280)
addappid(318281)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(285581, 1, "aff694b71cf1a1abcc750509f6c8d212b583e692f62d47cb9570c3f657151e40")

