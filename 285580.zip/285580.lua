-- Lua provided by RyzenAPI
-- Game: Game: ACE - Arena: Cyber Evolution

-- MAIN APPLICATION
addappid(285580)
-- Game: addappid(285580)

-- MAIN APP DEPOTS / PACKAGES
addappid(285581, 1, "aff694b71cf1a1abcc750509f6c8d212b583e692f62d47cb9570c3f657151e40")
