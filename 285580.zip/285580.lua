-- Lua provided by RyzenAPI 
-- Game: ACE - Arena: Cyber Evolution
addappid(285580)
addappid(285581, 1, "aff694b71cf1a1abcc750509f6c8d212b583e692f62d47cb9570c3f657151e40")
