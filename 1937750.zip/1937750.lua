-- Lua provided by RyzenAPI
-- Game: 1937750

-- MAIN APPLICATION
addappid(1937750)
-- Game: addappid(1937750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937751, 1, "ae80328ee766bed075f6f0efb11ee7c94a9acecf3c3e217898884e9b7edc9a80")
addappid(1937752, 1, "aef329723e3421138b114c447f28baeddcce28511532e7a2e67a720067427109")
