-- Lua provided by RyzenAPI
-- Game: Guns of Infinity

-- MAIN APPLICATION
addappid(446330)

-- MAIN APP DEPOTS / PACKAGES
addappid(446331, 1, "b5b62e0503871a76efa1ba88281533c7068d05c5142b052c0e05b457ddff8b84")

