-- Lua provided by RyzenAPI
-- Game: 15300

-- MAIN APPLICATION
addappid(15300)
-- Game: addappid(15300)

-- MAIN APP DEPOTS / PACKAGES
addappid(15301, 1, "92b2da80ef447bbbaa42b8639427e44852bf9b6517ef8e184c7343783cdcb029")
