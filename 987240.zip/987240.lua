-- Lua provided by RyzenAPI
-- Game: Game: AppID 987240

-- MAIN APPLICATION
addappid(987240)
-- Game: addappid(987240)

-- MAIN APP DEPOTS / PACKAGES
addappid(987241, 1, "ec1c94d41d36d3f4149802fb8509f911a7b2089ba93f6bb738f8cc604c6c6472")
