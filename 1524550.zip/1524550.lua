-- Lua provided by RyzenAPI
-- Game: addappid(1524550)

-- MAIN APPLICATION
addappid(1524550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524551, 1, "c1332289434b873433b6d78900112e191e2fceea3c2bbea6ae4bc3e1157c4a68")
