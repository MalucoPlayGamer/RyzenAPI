-- Lua provided by RyzenAPI
-- Game: Stranded Deep Original Soundtrack

-- MAIN APPLICATION
addappid(1492970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492971, 1, "fece933a7ee67d2fc16dee71caa84f3b9e7871f87a057977c9900c546cf9d413")
addappid(1492973, 1, "27ec43fff9a5f1c78f5dd79dfb8f5d6dc6b19ace6b7df3713ecc1bc0c6dce9a5")

