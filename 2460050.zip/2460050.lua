-- Lua provided by RyzenAPI
-- Game: Gate of Souls

-- MAIN APPLICATION
addappid(2460050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460051, 1, "67debf040350a7ed7eb77a6aa4920fe31e91b561e3bdf6aa148d2744c969b03a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
