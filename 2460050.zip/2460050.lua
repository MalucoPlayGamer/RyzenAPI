-- Lua provided by RyzenAPI 
-- Game: Gate of Souls
addappid(2460050)
addappid(2460051, 1, "67debf040350a7ed7eb77a6aa4920fe31e91b561e3bdf6aa148d2744c969b03a")
