-- Lua provided by RyzenAPI 
-- Game: Tavern Legends
addappid(3160880)
addappid(3160881, 1, "6a96cffc30e829cee3ae5dda8f8e35f3cdee7790db274fb4f0cc733760086395")
