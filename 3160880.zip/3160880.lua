-- Lua provided by RyzenAPI
-- Game: Game: Tavern Legends

-- MAIN APPLICATION
addappid(3160880)
-- Game: addappid(3160880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160881, 1, "6a96cffc30e829cee3ae5dda8f8e35f3cdee7790db274fb4f0cc733760086395")
