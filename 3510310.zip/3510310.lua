-- Lua provided by SkyAPI 
-- Game: Flat 9
addappid(3510310)
addappid(3510311, 1, "87803bbe7c6902018fef00bf9ebf46e74b345a88233341929d8cdc92af9b8a88")
