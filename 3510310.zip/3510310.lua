-- Lua provided by RyzenAPI
-- Game: Game: Flat 9

-- MAIN APPLICATION
addappid(3510310)
-- Game: addappid(3510310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3510311, 1, "87803bbe7c6902018fef00bf9ebf46e74b345a88233341929d8cdc92af9b8a88")
