-- Lua provided by RyzenAPI
-- Game: Flat 9

-- MAIN APPLICATION
addappid(3510310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3510311, 1, "87803bbe7c6902018fef00bf9ebf46e74b345a88233341929d8cdc92af9b8a88")

