-- Lua provided by RyzenAPI
-- Game: 衔尾：龙之铃 Demo

-- MAIN APPLICATION
addappid(2125960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125962,0,"b15c0bc038e332afb882040cb7f49132f325df339d1781cd9d5c843557c0007a")

