-- Lua provided by RyzenAPI
-- Game: addappid(1983180)

-- MAIN APPLICATION
addappid(1983180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983181, 1, "d8200311d3c26230f83e31f88af69535e144cd70add563b22cb67c584ba2f0b2")
