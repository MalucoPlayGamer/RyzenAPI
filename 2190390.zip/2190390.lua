-- Lua provided by RyzenAPI 
-- Game: Ocean Is Home : Island Life Simulator
addappid(2190390)
addappid(2190391, 1, "ef4fff07cfbf4dc54e44e50bd83397101a926eae20cb7c60e868df215293021f")
