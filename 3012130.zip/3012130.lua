-- Lua provided by RyzenAPI
-- Game: addappid(3012130)

-- MAIN APPLICATION
addappid(3012130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012131, 1, "5ffccc9fede4773532f7cf7db599b12181f96b449f8c38b0ee0affd9f19e3647")
