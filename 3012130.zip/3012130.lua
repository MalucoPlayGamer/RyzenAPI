-- Lua provided by RyzenAPI 
-- Game: Phantom of the Twilight
addappid(3012130)
addappid(3012131, 1, "5ffccc9fede4773532f7cf7db599b12181f96b449f8c38b0ee0affd9f19e3647")
