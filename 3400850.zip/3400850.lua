-- Lua provided by RyzenAPI
-- Game: Calyx Demo

-- MAIN APPLICATION
addappid(3400850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400851, 1, "770e4695fac47f6f8f803be6ffcd3d2ed80dbe95b03197fade486a9dff1fbaf3")
