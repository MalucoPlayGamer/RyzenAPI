-- Lua provided by RyzenAPI
-- Game: The Bridge Curse Road to Salvation Demo

-- MAIN APPLICATION
addappid(1836100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836101, 1, "9098247ddab7b860e05fc7a653f6184d5c7aedaebaac1656275e009dc64258ac")

