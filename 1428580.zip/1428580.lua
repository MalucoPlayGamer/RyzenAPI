-- Lua provided by RyzenAPI
-- Game: 1428580

-- MAIN APPLICATION
addappid(1428580)
-- Game: addappid(1428580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428581, 1, "aa10e99bd915d4bde850c383e8896d1662d7aaf8540f3ad00c5189a67e20cca3")
