-- Lua provided by SkyAPI 
-- Game: Quiet Valley
addappid(1428580)
addappid(1428581, 1, "aa10e99bd915d4bde850c383e8896d1662d7aaf8540f3ad00c5189a67e20cca3")
