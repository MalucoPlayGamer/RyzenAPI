-- Lua provided by RyzenAPI
-- Game: Game: Fears to Fathom - Carson House

-- MAIN APPLICATION
addappid(2120900)
-- Game: addappid(2120900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120901, 1, "b060afd33253ced6be83479f4afbcaf0e174a108c185c3ce5c6c106e0aaaabc3")
