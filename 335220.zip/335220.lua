-- Lua provided by RyzenAPI
-- Game: Game: But to Paint a Universe

-- MAIN APPLICATION
addappid(335220)
-- Game: addappid(335220)

-- MAIN APP DEPOTS / PACKAGES
addappid(335221, 1, "a213848aca34306cba50055f016d1ba18b991098421e73296f6bd9499b70bff0")
addappid(450780, 0, "f0e6f34073d21cde56a70c876760d0f2e468ebca0c46da3331799d18196f17ff")
