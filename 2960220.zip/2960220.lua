-- Lua provided by RyzenAPI
-- Game: Prop Haunt

-- MAIN APPLICATION
addappid(2960220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960221,0,"6c250825712931861fcba6bb10df86b3d3e9238bcd66ea47b64bc5b926acbaf8")

