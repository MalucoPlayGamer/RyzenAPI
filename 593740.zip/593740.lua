-- Lua provided by SkyAPI 
-- Game: AppID 593740
addappid(593740)
addappid(593741, 1, "722f8078792bc263e822977057f2c8d760000b3389c469f16534a9ade90f8665")
