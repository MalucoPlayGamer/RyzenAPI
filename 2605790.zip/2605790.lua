-- Lua provided by RyzenAPI
-- Game: Deep Rock Galactic: Rogue Core

-- MAIN APPLICATION
addappid(2605790)
addappid(4216130)
addappid(4813580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605791,0,"7308ffc34728d2db852dc47175323866ad2e9ba1d12f6fba302c8f768bc7bce2")

