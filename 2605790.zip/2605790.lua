-- Lua provided by RyzenAPI
-- Game: Deep Rock Galactic: Rogue Core

-- MAIN APPLICATION
addappid(2605790)
addappid(4216130)
addappid(4813580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605791,0,"7308ffc34728d2db852dc47175323866ad2e9ba1d12f6fba302c8f768bc7bce2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
