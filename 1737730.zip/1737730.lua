-- Lua provided by RyzenAPI
-- Game: addappid(1737730)

-- MAIN APPLICATION
addappid(1737730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737731, 1, "d1c3b7edd4c70870837bc618162574bae93be50c6ca35b34fe76d50b6ba1cf06")
addappid(1759000, 0, "40a5c52afed6e58a85fc32bf896442a95c6146d40dfef2b28a6d58720fa398e5")
