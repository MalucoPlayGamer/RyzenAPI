-- Lua provided by RyzenAPI
-- Game: Mr. Parkour 3

-- MAIN APPLICATION
addappid(1456920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456921, 1, "1f0694a4aea5b532fceff540b1be98b84764d0745ae4c60a5f465b1c2c6076a9")
