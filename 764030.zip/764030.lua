-- Lua provided by RyzenAPI
-- Game: Realm Revolutions

-- MAIN APPLICATION
addappid(764030)
-- Game: addappid(764030)

-- MAIN APP DEPOTS / PACKAGES
addappid(764031, 1, "946d5af4a42e0a63b2a7f4256c208b1dbc006409fb71851c55b822b49d707556")
