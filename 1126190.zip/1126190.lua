-- Lua provided by RyzenAPI
-- Game: Game: Disney Classic Games: Aladdin and The Lion King

-- MAIN APPLICATION
addappid(1126190)
-- Game: addappid(1126190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126191, 1, "1c5c17f3e2877739eb04f6ca529e9601d5bcf467c49519f4ad673fbe37fcac49")
addappid(1636800, 0, "17ce5d37d7f8399c548d9b656c51d19dbe399da626d58a12e40277a952bc3357")
