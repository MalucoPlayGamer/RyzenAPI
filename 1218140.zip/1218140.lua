-- Lua provided by RyzenAPI
-- Game: Game: AppID 1218140

-- MAIN APPLICATION
addappid(1218140)
-- Game: addappid(1218140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218141, 1, "e8ed6666b6c23534c420634095bd3bcb1a74a19f192db40e3a36dd829c934214")
