-- Lua provided by SkyAPI 
-- Game: The Longest Journey
addappid(6310)
addappid(6311, 1, "be74703051c8af7612bbf4c2aad65a551d528415272aa81c0c8bec2fd38c8eff")
