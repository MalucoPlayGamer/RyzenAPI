-- Lua provided by RyzenAPI
-- Game: The Longest Journey

-- MAIN APPLICATION
addappid(6310)

-- MAIN APP DEPOTS / PACKAGES
addappid(6311, 1, "be74703051c8af7612bbf4c2aad65a551d528415272aa81c0c8bec2fd38c8eff")

