-- Lua provided by RyzenAPI
-- Game: 267360

-- MAIN APPLICATION
addappid(267360)
-- Game: addappid(267360)

-- MAIN APP DEPOTS / PACKAGES
addappid(267361, 1, "7f22703ca0b4ee1a3ad81fa3bd3b1accc572b868070e6e2b7d73a66ac70c8211")
