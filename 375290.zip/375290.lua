-- Lua provided by RyzenAPI
-- Game: Superstatic

-- MAIN APPLICATION
addappid(375290)
-- Game: addappid(375290)

-- MAIN APP DEPOTS / PACKAGES
addappid(375291, 1, "7ef989a3a83e86a72655777bd7aa8d4b682c7330fa15800684f33ea894d43e39")
