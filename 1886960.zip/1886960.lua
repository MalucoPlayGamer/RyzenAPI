-- Lua provided by RyzenAPI
-- Game: Game: I HUMAN MACHINE

-- MAIN APPLICATION
addappid(1886960)
-- Game: addappid(1886960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886961, 1, "1be003497653deeb991a9dbdae03d73c243d15cb73b06ea8732eda9b64550928")
