-- Lua provided by RyzenAPI
-- Game: 1100910

-- MAIN APPLICATION
addappid(1100910)
-- Game: addappid(1100910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100911, 1, "760aeecde28db6521c27b4d765166beed7b2a4bad578c13d86366ccd6825e128")
addappid(3726170, 0, "2312b64239d8c91ba9e907e314a92ce207a3bf0cd225f05ec36af06b5c90b418")
