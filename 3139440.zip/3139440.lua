-- Lua provided by RyzenAPI
-- Game: GunZ: The Duel

-- MAIN APPLICATION
addappid(3139440)

