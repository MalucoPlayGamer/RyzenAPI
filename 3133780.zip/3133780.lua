-- Lua provided by RyzenAPI
-- Game: Dawn of Defiance - Supporter Pack Upgrade

-- MAIN APPLICATION
addappid(3133780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133780,0,"a57f68c721271f5c0efa6464a1b48557ec1f3cb953f6f20b34fccc2494ba0116")
