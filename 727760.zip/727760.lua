-- Lua provided by RyzenAPI
-- Game: Game: AppID 727760

-- MAIN APPLICATION
addappid(727760)
-- Game: addappid(727760)

-- MAIN APP DEPOTS / PACKAGES
addappid(727761, 1, "3b97e3f7dd04c73cf463b2ba77a9486021f16038d18ad840b2014dee086b5d80")
