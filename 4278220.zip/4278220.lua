-- 4278220's Lua and Manifest Created by Hubcap Manifest
-- Runic Curse Remastered
-- Created: August 22, 2026 at 13:56:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4278220) -- Runic Curse Remastered
-- MAIN APP DEPOTS
addappid(4278221, 1, "b98a616eb4a1401db68b0c84ae7345a105b82409428b24f23de444a8bbc7ac2b") -- Depot 4278221
setManifestid(4278221, "4628880317323904269", 1143333860)