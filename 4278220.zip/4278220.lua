-- Lua provided by RyzenAPI
-- Game: Runic Curse Remastered

-- MAIN APPLICATION
addappid(4278220) -- Runic Curse Remastered

-- MAIN APP DEPOTS / PACKAGES
addappid(4278221, 1, "b98a616eb4a1401db68b0c84ae7345a105b82409428b24f23de444a8bbc7ac2b") -- Depot 4278221

