-- Lua provided by RyzenAPI 
-- Game: BumpUpGhostBuster
addappid(2240100)
addappid(2240101, 1, "d3d4eac5675ecac0647a0ed1c681fff758f77d0750079e2e175cfe674ce9871c")
