-- Lua provided by RyzenAPI
-- Game: addappid(1186220)

-- MAIN APPLICATION
addappid(1186220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186221, 1, "7c068ec329b72f24ecdeb4a30de4d9e903f206415bdf7bd8ff3cefa5acea9d96")
