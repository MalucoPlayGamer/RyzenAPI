-- Lua provided by RyzenAPI
-- Game: AppID 1186220

-- MAIN APPLICATION
addappid(1186220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1186221, 1, "7c068ec329b72f24ecdeb4a30de4d9e903f206415bdf7bd8ff3cefa5acea9d96")

