-- Lua provided by RyzenAPI
-- Game: Criminal Attraction Demo

-- MAIN APPLICATION
addappid(2869550)
-- Game: addappid(2869550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869551, 1, "860df8c6367704f62ae0d2ffdf1e782b29eec8d614226970000a2756b5c7d1f2")
