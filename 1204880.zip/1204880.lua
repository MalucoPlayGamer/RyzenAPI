-- Lua provided by RyzenAPI
-- Game: Game: AppID 1204880

-- MAIN APPLICATION
addappid(1204880)
-- Game: addappid(1204880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204881, 1, "31a8118cb374962f82f9dd738224d288be2f966cd657f32eb05869950bc3df05")
