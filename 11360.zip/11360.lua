-- Lua provided by RyzenAPI 
-- Game: Chains
addappid(11360)
addappid(11361, 1, "18cc6353f8e85abbd21d78f15bc75d0be8aeb810331f86e3883e1785a1c6e695")
addappid(11362, 1, "1824488ea29fad0368c5497bca5264d5d4faad4a018efea0194e4816b85c1271")
