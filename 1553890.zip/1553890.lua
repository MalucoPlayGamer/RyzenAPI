-- Lua provided by RyzenAPI
-- Game: Lewd Girls, Leave Me Alone! I Just Want to Play Video Games and Watch Anime! ~ Hentai Edition

-- MAIN APPLICATION
addappid(1553890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553891, 1, "fd9577bb5fefb0b2c6ab1ea6e6654307b54a4f30b8c6a454bd9f410597765345")
