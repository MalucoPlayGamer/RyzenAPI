-- Lua provided by RyzenAPI
-- Game: addappid(745010)

-- MAIN APPLICATION
addappid(745010)

-- MAIN APP DEPOTS / PACKAGES
addappid(745010,0,"15f4a713adcf0664757ce7a79dbdfc242f5ed637483ca536c8d217b3b821abfc")
addappid(745014,0,"c65646f9e809bbcdfa1e408eb82d82c093e0483a5921899a5c2bebfc60e2821e")
