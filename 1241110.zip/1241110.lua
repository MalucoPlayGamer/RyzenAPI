-- Lua provided by RyzenAPI
-- Game: addappid(1241110)

-- MAIN APPLICATION
addappid(1241110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241112,0,"f855f424b7a743185eba9440aefde7472fd779f3d56021064ef7273445adcb8a")
