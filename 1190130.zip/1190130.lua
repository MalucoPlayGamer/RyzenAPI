-- Lua provided by RyzenAPI 
-- Game: AppID 1190130
addappid(1190130)
addappid(1190131, 1, "45762472550bc416e068aaa75dad380697a4ee1481941ca6c2b384396df9db1f")
