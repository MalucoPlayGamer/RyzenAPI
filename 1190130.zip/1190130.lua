-- Lua provided by RyzenAPI
-- Game: Game: AppID 1190130

-- MAIN APPLICATION
addappid(1190130)
-- Game: addappid(1190130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190131, 1, "45762472550bc416e068aaa75dad380697a4ee1481941ca6c2b384396df9db1f")
