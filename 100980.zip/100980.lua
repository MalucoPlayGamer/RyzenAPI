-- 100980's Lua and Manifest Created by Hubcap Manifest
-- 3DCoat
-- Created: September 30, 2025 at 17:13:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(100980) -- 3DCoat
-- MAIN APP DEPOTS
addappid(100981, 1, "4f2ebcb8bb684858f2d7a7036441c771af7bcb36e86df0ed7605aea79b25a6b7") -- 3Dcoat Content
setManifestid(100981, "8903642233002788730", 3154798440)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(219210) -- 3D Coat Consumer License
addappid(219211) -- 3D Coat Professional License
addappid(219212) -- 3D Coat Professional License
addappid(219213) -- 3D Coat V4 Basic License
addappid(219214) -- 3D Coat V4 Professional License