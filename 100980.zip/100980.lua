-- Lua provided by RyzenAPI
-- Game: 3DCoat

-- MAIN APPLICATION
addappid(100980) -- 3DCoat
addappid(219210) -- 3D Coat Consumer License
addappid(219211) -- 3D Coat Professional License
addappid(219212) -- 3D Coat Professional License
addappid(219213) -- 3D Coat V4 Basic License
addappid(219214) -- 3D Coat V4 Professional License

-- MAIN APP DEPOTS / PACKAGES
addappid(100981, 1, "4f2ebcb8bb684858f2d7a7036441c771af7bcb36e86df0ed7605aea79b25a6b7") -- 3Dcoat Content
