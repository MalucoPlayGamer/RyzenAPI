-- Lua provided by RyzenAPI
-- Game: 3DCoat 4.9

-- MAIN APPLICATION
addappid(100980)

-- MAIN APP DEPOTS / PACKAGES
addappid(100981, 1, "4f2ebcb8bb684858f2d7a7036441c771af7bcb36e86df0ed7605aea79b25a6b7")

