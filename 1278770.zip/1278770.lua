-- Lua provided by RyzenAPI
-- Game: Sweet Story Bunny Club

-- MAIN APPLICATION
addappid(1278770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278771, 1, "c953e48f398bdd107a1b8b89d950ec8be582df7e99612dab2a7175689179d6b8")
addappid(1286000, 0, "6573d50ec70c5c4f0d4e959374534c01ae5d9d83125b9f32c2e7e81c69575e64")
