-- Lua provided by RyzenAPI
-- Game: Russian SuperHero Dead Ivan

-- MAIN APPLICATION
addappid(527770)

-- MAIN APP DEPOTS / PACKAGES
addappid(527771, 1, "283197513035f466afeb0952d3a34d0a012e2b4b45e9c1bb4f694a7b96a59bfc")

