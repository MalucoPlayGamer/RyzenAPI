-- Lua provided by RyzenAPI
-- Game: Villa Escape Demo

-- MAIN APPLICATION
addappid(3022240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022241, 1, "3164cd66df9dac291874037322743c10c5d2d5c3ae15d7216f197dd1f687b350")

