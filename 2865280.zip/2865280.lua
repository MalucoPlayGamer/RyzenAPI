-- Lua provided by RyzenAPI
-- Game: KILL KNIGHT Demo

-- MAIN APPLICATION
addappid(2865280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865281, 1, "2c12dc95e2f6c0f44cc556dad2a9abeab063655ba13dc53864fbd0ebcda0fb09")
