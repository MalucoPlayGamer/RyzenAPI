-- Lua provided by RyzenAPI
-- Game: DRONES AND RUINS

-- MAIN APPLICATION
addappid(782650)

-- MAIN APP DEPOTS / PACKAGES
addappid(782651,0,"b26de33743125f8731a068c7352281d65c563ca538508e2f71ee0ca8242a8bf2")
addappid(782652,0,"ebd26eb1f5567f11a2ec13a3c14ab31daf87ef7e58690c939ef63e7913c04ecf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
