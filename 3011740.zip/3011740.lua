-- Lua provided by SkyAPI 
-- Game: Border Dungeon 边境地牢
addappid(3011740)
addappid(3011741, 1, "814b6ae7aa0b891a9719091114694fbac70aa18c3f5fc8535a16921c70c57da6")
