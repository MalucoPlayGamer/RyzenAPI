-- Lua provided by RyzenAPI
-- Game: DRAGON BALL GEKISHIN SQUADRA

-- MAIN APPLICATION
addappid(2072560)

