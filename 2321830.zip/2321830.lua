-- Lua provided by SkyAPI 
-- Game: AppID 2321830
addappid(2321830)
addappid(2321831, 1, "8a5595d0c83acd3e400e76fc960367b261c1c3b5a88bc53a6fc93cb425918989")
