-- Lua provided by RyzenAPI
-- Game: Warbanners

-- MAIN APPLICATION
addappid(650440)
addappid(650441)
addappid(650443)
-- Game: addappid(650440)

-- MAIN APP DEPOTS / PACKAGES
addappid(650442,0,"ae5e1c76ccd91170a498a451fcb26e39f6fcf74c06c018a8932bc9f552741a6f")
