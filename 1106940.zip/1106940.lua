-- Lua provided by RyzenAPI
-- Game: AppID 1106940

-- MAIN APPLICATION
addappid(1106940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106941, 1, "a8c82ce75ea6aeb4da53bd2407a5c92d95beaf2bd9f16834be4e1c9962e23dad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
