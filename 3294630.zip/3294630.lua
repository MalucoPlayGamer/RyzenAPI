-- Lua provided by RyzenAPI
-- Game: addappid(3294630)

-- MAIN APPLICATION
addappid(3294630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294631, 1, "bae17913ba1b92736a15c90428e10ad5d2b8e262defb11dd76307547f63dbdd7")
