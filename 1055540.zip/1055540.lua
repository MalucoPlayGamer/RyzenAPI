-- Lua provided by RyzenAPI
-- Game: A Short Hike

-- MAIN APPLICATION
addappid(1055540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055541, 1, "357f3583b508bf2b30b0ef89c3473521718cbc8b93c0c54310a4c47c8d15bdf2")
addappid(1055542, 1, "bf61fb6ad4ff0581ec0c16d2c5682ad3440abd78d64bd9d78f541b8c58049d1e")
addappid(1055543, 1, "f18ee22cbd474dc50d6ca97b6661b3d912dd2d6157eedefa3e8ae2efdb30c65e")

