-- Lua provided by RyzenAPI
-- Game: Game: AppID 1073640

-- MAIN APPLICATION
addappid(1073640)
-- Game: addappid(1073640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073641, 1, "7e4207816c10265499480b29808b1bbac0948afdefba2779ad8fd9f52c6ad40d")
