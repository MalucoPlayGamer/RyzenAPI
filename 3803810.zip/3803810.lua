-- Lua provided by RyzenAPI
-- Game: Game: 游戏世界小冒险

-- MAIN APPLICATION
addappid(3803810)
-- Game: addappid(3803810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3803811, 1, "16950c19120d31da6129f6f1d8cf22b33b0211d9502bb213f934914a18631a62")
