-- Lua provided by RyzenAPI
-- Game: addappid(2432430)

-- MAIN APPLICATION
addappid(2432430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432430,0,"1208c30807177a5cc4fbf47f7fe8e3b94b6bc9e20c72fee1dabd5059ca3e70c6")
