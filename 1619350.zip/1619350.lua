-- Lua provided by RyzenAPI
-- Game: addappid(1619350)

-- MAIN APPLICATION
addappid(1619350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619351, 1, "ec84908313d382b46b5c37689bff590d941d97fda5cccfc4625d2aff41db8f32")
