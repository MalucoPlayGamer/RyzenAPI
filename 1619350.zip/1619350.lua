-- Lua provided by RyzenAPI
-- Game: DeepStates [VR]

-- MAIN APPLICATION
addappid(1619350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1619351, 1, "ec84908313d382b46b5c37689bff590d941d97fda5cccfc4625d2aff41db8f32")

