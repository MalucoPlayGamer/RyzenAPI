-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Milano Malpensa

-- MAIN APPLICATION
addappid(2259160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259160,0,"20f25289ec5ac85d719f2e54c06a274c57cd20203137089481245def88b44ed3")

