-- Lua provided by RyzenAPI
-- Game: Game: AppID 1205670

-- MAIN APPLICATION
addappid(1205670)
-- Game: addappid(1205670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205671, 1, "1c4e59031046a1a644a70cd5dbc4881a2b3342a3137d26198d517b38262b96ff")
