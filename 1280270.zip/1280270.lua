-- Lua provided by RyzenAPI
-- Game: addappid(1280270)

-- MAIN APPLICATION
addappid(1280270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280271, 1, "114bca183f7a1a5a6b3d3e27bbb9f92df1bd4a0c70f673a36ff1ce16bc3e5a4c")
