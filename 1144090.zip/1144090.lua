-- Lua provided by RyzenAPI
-- Game: 1144090

-- MAIN APPLICATION
addappid(1144090)
-- Game: addappid(1144090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144091, 1, "25e9f6ad2251c2d004b825ddf04a51d3646f4b5895ec55b3fce67c52f108d795")
