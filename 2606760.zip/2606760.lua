-- Lua provided by RyzenAPI
-- Game: Doodle Harmony

-- MAIN APPLICATION
addappid(2606760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606762,0,"b744e82b2fb55fc18f9c3ed8d3d477520877e75722023db35a9cd56ddfbad603")
