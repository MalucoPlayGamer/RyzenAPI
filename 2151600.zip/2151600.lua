-- Lua provided by RyzenAPI
-- Game: addappid(2151600)

-- MAIN APPLICATION
addappid(2151600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151601, 1, "6609a241dabd3124e525230d8c7937a737ec200e8ff94b148c55d5da333ca1aa")
