-- Lua provided by RyzenAPI
-- Game: Zombie Bar Simulator

-- MAIN APPLICATION
addappid(1418430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418431, 1, "c0dc46eea799ceb4bef80e17dc56071b7ff446a0151a091386f631cc6aacd6f5")

