-- Lua provided by RyzenAPI
-- Game: Zombie Bar Simulator

-- MAIN APPLICATION
addappid(1418430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418431, 1, "c0dc46eea799ceb4bef80e17dc56071b7ff446a0151a091386f631cc6aacd6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
