-- Lua provided by SkyAPI 
-- Game: Sexy Furry
addappid(1896840)
addappid(1896841, 1, "55e4fe548dae0c35ff210629c7d8dc9e1605deebae320c8d62a0ec6a737e223f")
