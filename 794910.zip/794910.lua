-- Lua provided by RyzenAPI
-- Game: Necroarmy

-- MAIN APPLICATION
addappid(794910)

-- MAIN APP DEPOTS / PACKAGES
addappid(794911, 1, "bd4f7ebed5b9a1f2f4d7ad03f05e92f2f7b70c17ad4921cd3ff59bc803a61caa")
