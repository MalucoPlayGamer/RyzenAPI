-- Lua provided by RyzenAPI 
-- Game: Urayama
addappid(2939550)
addappid(2939551, 1, "fc899ac8e575031689655e3a465ea103a741a031b08935cb3014d1da2ca47e1c")
