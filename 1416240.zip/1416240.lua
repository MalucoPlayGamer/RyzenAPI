-- Lua provided by RyzenAPI
-- Game: 夜永 Eternal Love

-- MAIN APPLICATION
addappid(1416240)
-- Game: addappid(1416240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416241, 1, "91328f3beffd3f2d636dac6025dcfd6951aa03c120a3219fa783ba73cc730cd5")
addappid(1416242, 1, "2a3615cc9814677923945872eb57b2c096a3c440fb3350ae8d97ff6f8a9a9990")
