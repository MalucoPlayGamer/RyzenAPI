-- Lua provided by RyzenAPI
-- Game: Cum Clicker

-- MAIN APPLICATION
addappid(2545830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2545831, 1, "648ada6741efa6fcae91fa7a702ad4e68e16686d09c69da7c79983d0bbc3eb46")

