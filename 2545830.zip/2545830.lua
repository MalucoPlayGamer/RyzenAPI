-- Lua provided by RyzenAPI
-- Game: Cum Clicker

-- MAIN APPLICATION
addappid(2545830)
-- Game: addappid(2545830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545831, 1, "648ada6741efa6fcae91fa7a702ad4e68e16686d09c69da7c79983d0bbc3eb46")
