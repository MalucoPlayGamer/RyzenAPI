-- Lua provided by RyzenAPI
-- Game: Android Simulator Demo

-- MAIN APPLICATION
addappid(1971550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971551, 1, "ee66c49db077ee7f86318ff959a0355119810c25dd5138395243d88c0111fad9")
