-- Lua provided by RyzenAPI
-- Game: Game: La Rana

-- MAIN APPLICATION
addappid(934860)
-- Game: addappid(934860)

-- MAIN APP DEPOTS / PACKAGES
addappid(934861, 1, "8aafbd58c73ccffb5e71d86df9275b87cb3f4ff0b458c16cf72a3274e30bdaba")
