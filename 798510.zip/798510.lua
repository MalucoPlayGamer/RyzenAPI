-- Generated with Luie @ https://lua.tools/
-- 798510 - SUPER DRAGON BALL HEROES WORLD MISSION
-- Generated 2026-08-23 07:00:16 UTC
-- # Depots (Total/DLC/Shared): 6/2/2

-- Main AppID
addappid(798510, 1, "be2f535d16afc547675efefb7f901732ac0214c1edbc80cd567beada390d3461")

-- Main Depots
addappid(798511, 1, "8dd055489dac13c70144379554966d6f3eec606a8f89d3cd223a0d10d1f88598")
setManifestid(798511, "6746379969074908139", 3479672672)
addappid(798512, 1, "66c03c3034312885feee1b1a7d15c0e77fa1f4312bc22490c1375246452d5914")
setManifestid(798512, "5234313693834590661", 32784245)

-- DLC's (no depot keys required)
addappid(1011180) -- SUPER DRAGON BALL HEROES WORLD MISSION - Power-Up Pack

-- DLC's (with depot keys)
-- DLC 1018150 (AppID: 1018150)
addappid(1018150)
addappid(1018150, 1, "c2fd3660411e42171e2fe5e18682c61b10dd683cf8b36c1032f9c925330850d4")
setManifestid(1018150, "2325386072930785147", 17596576)
-- DLC 1018151 (AppID: 1018151)
addappid(1018151)
addappid(1018151, 1, "6606306d9eb4c9fafa9fa153ec0e83abd7037cacc1ac962f1ffe0780ece9ef6d")
setManifestid(1018151, "5112559561575317915", 14256288)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
