-- Lua provided by RyzenAPI
-- Game: Race

-- MAIN APPLICATION
addappid(768800)

-- MAIN APP DEPOTS / PACKAGES
addappid(768801, 1, "6d264b2b6354ca14404b44e8f0b9a6398230235cc206c253d7fb6508ab6f615c")

