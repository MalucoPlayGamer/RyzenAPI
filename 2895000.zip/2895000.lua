-- Lua provided by RyzenAPI
-- Game: Game: AppID 2895000

-- MAIN APPLICATION
addappid(2895000)
-- Game: addappid(2895000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895001, 1, "602ffeaad5999b5527490aff6b55ceeadd7985cd1d7eee010bfc2413836183a6")
