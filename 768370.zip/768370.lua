-- Lua provided by RyzenAPI
-- Game: AppID 768370

-- MAIN APPLICATION
addappid(768370)

-- MAIN APP DEPOTS / PACKAGES
addappid(768371, 1, "5f016fc01f9acbf76529e782159a8e306967d01d5770dc1754c950b7ba413bb9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
