-- Lua provided by RyzenAPI
-- Game: 768370

-- MAIN APPLICATION
addappid(768370)
-- Game: addappid(768370)

-- MAIN APP DEPOTS / PACKAGES
addappid(768371, 1, "5f016fc01f9acbf76529e782159a8e306967d01d5770dc1754c950b7ba413bb9")
