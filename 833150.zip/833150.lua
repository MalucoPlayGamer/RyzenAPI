-- Lua provided by RyzenAPI
-- Game: Game: Hungry Fish Evolution

-- MAIN APPLICATION
addappid(833150)
-- Game: addappid(833150)

-- MAIN APP DEPOTS / PACKAGES
addappid(833151, 1, "0361eb263d0d8fbc7186df2f267659b3cae6e3326dd6544e1f270ab86bab4f64")
