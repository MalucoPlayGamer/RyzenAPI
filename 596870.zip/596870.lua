-- Lua provided by RyzenAPI
-- Game: AppID 596870

-- MAIN APPLICATION
addappid(596870)
-- Game: addappid(596870)

-- MAIN APP DEPOTS / PACKAGES
addappid(596871, 1, "14380b3fc03b562fa144f4ae8c0a1b7586769ef95d86750f8569e151c8c92c20")
