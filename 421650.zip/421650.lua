-- Lua provided by RyzenAPI
-- Game: Game: AppID 421650

-- MAIN APPLICATION
addappid(421650)
-- Game: addappid(421650)

-- MAIN APP DEPOTS / PACKAGES
addappid(421651, 1, "687c687c9382e4653b4fe4c102eb4619771d775924cecd808e54eb51c61b57f5")
