-- Lua provided by RyzenAPI
-- Game: AppID 421650

-- MAIN APPLICATION
addappid(421650)

-- MAIN APP DEPOTS / PACKAGES
addappid(421651, 1, "687c687c9382e4653b4fe4c102eb4619771d775924cecd808e54eb51c61b57f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(996540)
addappid(996541)
addappid(996570)
addappid(1033870)
