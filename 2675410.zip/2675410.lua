-- Lua provided by RyzenAPI
-- Game: Dino Dino – Playful Paleontology

-- MAIN APPLICATION
addappid(2675410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675411, 1, "ca97d5cb89a10eb59b955c23ede3d003022b19ccecba1904d09ba95c436f3340")
