-- Lua provided by RyzenAPI
-- Game: Game: The Dungeon Of Naheulbeuk: The Amulet Of Chaos Soundtrack

-- MAIN APPLICATION
addappid(1403620)
-- Game: addappid(1403620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403621, 1, "7abb0aa929d8ae1ad5e327c3210f0545b351a6bf2738bd4e96c4d64d7bbc9896")
