-- Lua provided by RyzenAPI
-- Game: 2558750

-- MAIN APPLICATION
addappid(2558750)
-- Game: addappid(2558750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558751, 1, "f12ef3cdbab07ba3cae7790104c5de62bfde055f596b993a592764b51801792f")
