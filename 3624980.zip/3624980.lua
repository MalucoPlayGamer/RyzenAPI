-- Lua provided by RyzenAPI
-- Game: 3624980

-- MAIN APPLICATION
addappid(3624980)
-- Game: addappid(3624980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624980,0,"c8bf85edf32973ec85e17b6d89469e94ebac8cbd41418c069294cc800b10d6f9")
