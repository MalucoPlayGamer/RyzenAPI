-- Lua provided by RyzenAPI
-- Game: Lass ich Sliden

-- MAIN APPLICATION
addappid(2813960)
addappid(2826761)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813961, 1, "1ec076d818d9bd18c5c6f39d20239c39de1562e18a497daeb34052993c3f76a7")
