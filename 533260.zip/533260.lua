-- Lua provided by RyzenAPI
-- Game: Behold!

-- MAIN APPLICATION
addappid(533260)

-- MAIN APP DEPOTS / PACKAGES
addappid(533261,0,"2499d2683cc737506b347a6ac2b36e064e68acb182e138cda9ea6a607120f6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
