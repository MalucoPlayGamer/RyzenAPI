-- Lua provided by RyzenAPI
-- Game: Behold!

-- MAIN APPLICATION
addappid(533260)

-- MAIN APP DEPOTS / PACKAGES
addappid(533261,0,"2499d2683cc737506b347a6ac2b36e064e68acb182e138cda9ea6a607120f6f5")

