-- Lua provided by RyzenAPI
-- Game: 2916260

-- MAIN APPLICATION
addappid(2916260)
-- Game: addappid(2916260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916261, 1, "f494cfff5a20a6806296839f6408ff5a6df38fd24583893f71ee1ea94d0b99b3")
