-- Lua provided by RyzenAPI
-- Game: AppID 359900

-- MAIN APPLICATION
addappid(359900)

-- MAIN APP DEPOTS / PACKAGES
addappid(359901, 1, "a40f26c9eff41ab979be9faab72b5a432de616cc9810e668bd2748f89615a399")
addappid(359902, 1, "1d9aa6e2b2a833d5b24653b6e025ba6b4296429d36d72dced30260aa618442fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
