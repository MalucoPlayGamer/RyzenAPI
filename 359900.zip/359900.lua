-- Lua provided by RyzenAPI
-- Game: addappid(359900)

-- MAIN APPLICATION
addappid(359900)

-- MAIN APP DEPOTS / PACKAGES
addappid(359901, 1, "a40f26c9eff41ab979be9faab72b5a432de616cc9810e668bd2748f89615a399")
addappid(359902, 1, "1d9aa6e2b2a833d5b24653b6e025ba6b4296429d36d72dced30260aa618442fb")
