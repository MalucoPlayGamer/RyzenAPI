-- Lua provided by SkyAPI 
-- Game: Odium to the Core
addappid(795570)
addappid(795571, 1, "70c9473143e38012b0ef23bc894e1e2f386db6b3830bd22a2f093046c4a9eea9")
addappid(795572, 1, "f063ac3403f2d3f707c1228736a7e56d67594eaf18184daffda3b6bf0d5f0c4b")
addappid(795573, 1, "82ead0778fe134ffb856db8143fa879b10019bd71bcef1643f38db72dc7648a6")
