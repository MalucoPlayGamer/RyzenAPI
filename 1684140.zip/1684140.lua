-- Lua provided by RyzenAPI
-- Game: 1684140

-- MAIN APPLICATION
addappid(1684140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684140,0,"b068bce1aaa88996e490e46d025b8ba2abfffda883194fd420bd29d98ac5d53d")

