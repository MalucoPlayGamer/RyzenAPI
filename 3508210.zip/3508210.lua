-- Lua provided by RyzenAPI
-- Game: Game: AppID 3508210

-- MAIN APPLICATION
addappid(3508210)
-- Game: addappid(3508210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3508211, 1, "0544d7879dc4dc5cbacdbe5548f989211127df9d8f45e206b021bf26923f2ef9")
