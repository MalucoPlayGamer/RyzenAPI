-- Lua provided by SkyAPI 
-- Game: AppID 3508210
addappid(3508210)
addappid(3508211, 1, "0544d7879dc4dc5cbacdbe5548f989211127df9d8f45e206b021bf26923f2ef9")
