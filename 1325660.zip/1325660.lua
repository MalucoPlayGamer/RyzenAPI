-- Lua provided by RyzenAPI
-- Game: Rebots Demo

-- MAIN APPLICATION
addappid(1325660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325663,0,"fd60cd3b40c986af34f20c8210ab9789e1c430ebae65f39dafc7c1b88f8f5f26")

