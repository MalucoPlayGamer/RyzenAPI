-- Lua provided by RyzenAPI
-- Game: SPY-der PIG

-- MAIN APPLICATION
addappid(2802110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802111, 1, "d12d019d0745ff795e079f0339adc29da8f1c7fa925826ce47773a1f2e0594ca")
