-- Lua provided by RyzenAPI
-- Game: Tank Guards

-- MAIN APPLICATION
addappid(1679770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679771, 1, "a1807de08cb414ff1bb2f6672f5fb2234092433f41902ad21aee0cfd978928c4")
