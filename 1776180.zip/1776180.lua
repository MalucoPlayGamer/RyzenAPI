-- Lua provided by RyzenAPI
-- Game: Game: Fate Seeker II OST

-- MAIN APPLICATION
addappid(1776180)
-- Game: addappid(1776180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776181, 1, "fa013fbf14e92bde624f4efcbf2bc4c41594756264d47c3c89de843f7add71bc")
addappid(1776182, 1, "0dd60fa01c1f2870fb3ea74eada7df0cad42fa79253bf7d98bae5634aaf81866")
