-- 4180990's Lua and Manifest Created by Hubcap Manifest
-- Jenny the Witch
-- Created: July 26, 2026 at 06:01:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4180990, 1, "fb83e6ffa86193482b0120b5344b9d44451c3eed9e484b928da690feb1a26288") -- Jenny the Witch
-- MAIN APP DEPOTS
addappid(4180991, 1, "f3b35727092610ae49a37bc5f3f28591bf2433aef57b3bcbae2a69ba32cf81ba") -- Depot 4180991
setManifestid(4180991, "7474949868334111368", 581248700)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4180992) -- Depot 4180992 (empty depot)