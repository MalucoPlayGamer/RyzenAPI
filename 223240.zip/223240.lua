-- Lua provided by RyzenAPI
-- Game: Red Orchestra Windows Dedicated Server

-- MAIN APPLICATION
addappid(223240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201,0,"d3de5443d18a2f1c50dbe0e92674d93eb680a8dcfc3f531bb99e12895e5312c4")
addappid(1203,0,"f98b3600d57d523e6ad28238b527a2c61050805bb122d13fc0b9c3a400004ac7")

