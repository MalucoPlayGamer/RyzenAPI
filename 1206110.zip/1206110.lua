-- Lua provided by SkyAPI 
-- Game: Frontline: The Great Patriotic War
addappid(1206110)
addappid(1206111, 1, "7f4971a615f2c98dd133e9c3f8e204829acfd83b1e60ce62f0368f4bb18afc33")
