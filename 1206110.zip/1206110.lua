-- Lua provided by RyzenAPI
-- Game: 1206110

-- MAIN APPLICATION
addappid(1206110)
-- Game: addappid(1206110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206111, 1, "7f4971a615f2c98dd133e9c3f8e204829acfd83b1e60ce62f0368f4bb18afc33")
