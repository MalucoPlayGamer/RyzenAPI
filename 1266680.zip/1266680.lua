-- Lua provided by RyzenAPI
-- Game: 1266680

-- MAIN APPLICATION
addappid(1266680)
-- Game: addappid(1266680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266681, 1, "ccdd02da6e945de84742d22fdb9e2353d52e75ec9ba89ff0443fb31321cc259d")
