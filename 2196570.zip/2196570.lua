-- Lua provided by RyzenAPI
-- Game: Escape!!

-- MAIN APPLICATION
addappid(2196570)
addappid(2204610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196571, 1, "b73a9ed49d409d3ef1f71c3b447debfed4cb04ebce21ad9c82e98109ac906212")
