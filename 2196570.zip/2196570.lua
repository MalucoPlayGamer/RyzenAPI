-- Lua provided by RyzenAPI
-- Game: Escape!!

-- MAIN APPLICATION
addappid(2196570)
addappid(2204610)
addappid(2392410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2196571, 1, "b73a9ed49d409d3ef1f71c3b447debfed4cb04ebce21ad9c82e98109ac906212")

