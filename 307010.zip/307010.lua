-- Lua provided by RyzenAPI
-- Game: Northmark: Hour of the Wolf

-- MAIN APPLICATION
addappid(307010)

-- MAIN APP DEPOTS / PACKAGES
addappid(307011, 1, "96c01e0184fb0f9d296d939e4e808f840d9e82e9a5aed2d478e7bc1da6fb67f1")
addappid(307012, 1, "dc9093aeb66606fcf8b759d157c4615543bfb25c939f4d40578018851f6505e7")

