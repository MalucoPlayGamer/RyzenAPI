-- Lua provided by RyzenAPI
-- Game: 1989560

-- MAIN APPLICATION
addappid(1989560)
addappid(1989561)
addappid(1989562)
addappid(1989564)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989563,0,"dee4f472b11297fb11721e833642e31abe91b7076c3e333b8f29294d112cdd1d")

