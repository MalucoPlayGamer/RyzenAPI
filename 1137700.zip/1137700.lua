-- Lua provided by RyzenAPI 
-- Game: AAW Wrestle Lab
addappid(1137700)
addappid(1137701, 1, "22248e0dfca873646e5d43155144d7da7c8f26d3e57ae27b76ec293fb6a0bc37")
