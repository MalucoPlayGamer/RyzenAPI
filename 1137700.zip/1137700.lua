-- Lua provided by RyzenAPI
-- Game: AAW Wrestle Lab

-- MAIN APPLICATION
addappid(1137700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1137701, 1, "22248e0dfca873646e5d43155144d7da7c8f26d3e57ae27b76ec293fb6a0bc37")

