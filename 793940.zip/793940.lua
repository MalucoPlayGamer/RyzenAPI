-- Lua provided by RyzenAPI
-- Game: MOAI V: Collector’s Edition

-- MAIN APPLICATION
addappid(793940)

-- MAIN APP DEPOTS / PACKAGES
addappid(793941,0,"a55492e3796e105f6a3acfac5425558fc6ccfc38f13d611806893c81c24e8bf7")

