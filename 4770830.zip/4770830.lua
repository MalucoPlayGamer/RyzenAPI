-- Lua provided by RyzenAPI
-- Game: 三國鼎立Online Remastered

-- MAIN APPLICATION
addappid(4770830)

