-- Lua provided by RyzenAPI
-- Game: Beached

-- MAIN APPLICATION
addappid(652560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(652561, 1, "fa2d2e70ffdc5deebb0e7001698edac402643fe94c5f4b3cf8ad9d3e253eab94")

