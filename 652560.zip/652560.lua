-- Lua provided by RyzenAPI
-- Game: addappid(652560)

-- MAIN APPLICATION
addappid(652560)

-- MAIN APP DEPOTS / PACKAGES
addappid(652561, 1, "fa2d2e70ffdc5deebb0e7001698edac402643fe94c5f4b3cf8ad9d3e253eab94")
