-- Lua provided by RyzenAPI
-- Game: 1890070

-- MAIN APPLICATION
addappid(1890070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890070,0,"6b1c506bfa709ba9128664b4beea4a6b32cfb4b9f5f1985ad5af0f51dc6d7938")
