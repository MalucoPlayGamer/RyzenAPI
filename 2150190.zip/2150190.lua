-- Lua provided by RyzenAPI
-- Game: Game: Go Fight Fantastic (Demo)

-- MAIN APPLICATION
addappid(2150190)
-- Game: addappid(2150190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150191, 1, "7eb49807108a5c013b894263b111fc20329f688a30332689971248a278048e6c")
