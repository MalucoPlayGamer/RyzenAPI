-- Lua provided by RyzenAPI
-- Game: Atlas Rogues

-- MAIN APPLICATION
addappid(1449540)
addappid(1449541)
addappid(1449542)

-- MAIN APP DEPOTS / PACKAGES
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")

