-- Lua provided by RyzenAPI
-- Game: Zahalia: The Knights of Galiveth

-- MAIN APPLICATION
addappid(562290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(562291, 1, "6dc9769f379f3a1a1759922a6b0cb88d38dd836cd9f1e53330013d47081b2115")

