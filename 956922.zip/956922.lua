-- Lua provided by RyzenAPI
-- Game: Lu Su - Officer Ticket / 魯粛使用券

-- MAIN APPLICATION
addappid(956922)
-- Game: addappid(956922)

-- MAIN APP DEPOTS / PACKAGES
addappid(956922,0,"2a4447f2601ad0c9871496d5bca896c9a78c13af1c6508a90f60c4bac5e8f926")
