-- Lua provided by RyzenAPI 
-- Game: Miss Neko 3
addappid(2022180)
addappid(2022181, 1, "e7755415ebd0db6ce32cf98a031b165649a50c3c636056109c886a479e48b501")
addappid(2200370)
