-- Lua provided by RyzenAPI
-- Game: House Flipper - Workshop Exporter

-- MAIN APPLICATION
addappid(1471280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471281, 1, "468b2672d11750e1c5d0dc1f6e143c0c4ee1518659e25f0ab7e4142116f224ed")
