-- Lua provided by RyzenAPI 
-- Game: Diablo II: Resurrected – Infernal Edition
addappid(2536520)
addappid(2536521, 1, "6ae0dd2e9f10f50302bd6fdaf0da8f6e724e970e56d35bbc5a2d3047969cf0ea")
addappid(2536522, 1, "2ac8c20f9db336d670c6221c832758c6fc05a8cc16eea81805efed379bc9f60f")
