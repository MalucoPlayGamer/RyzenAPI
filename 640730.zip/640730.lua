-- Lua provided by RyzenAPI
-- Game: 640730

-- MAIN APPLICATION
addappid(640730)
-- Game: addappid(640730)

-- MAIN APP DEPOTS / PACKAGES
addappid(640731, 1, "28f393cbbeb203a81fd8684ecd8d2e50d020dd0119426ecccbeb52aaf5c32e81")
