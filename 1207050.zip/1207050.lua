-- Lua provided by RyzenAPI
-- Game: 1207050

-- MAIN APPLICATION
addappid(1207050)
-- Game: addappid(1207050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207051, 1, "45d31abb1521372c05b64b1a7e66f6e200ac05ae5a4840e036835f5dadabd166")
