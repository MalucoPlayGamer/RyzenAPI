-- Lua provided by RyzenAPI
-- Game: Game: AppID 2833530

-- MAIN APPLICATION
addappid(2833530)
-- Game: addappid(2833530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833531, 1, "7fe348d4fc1c1dc740d76a3002366ea2bed4767d84340e515874162059ae911d")
