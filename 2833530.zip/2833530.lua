-- Lua provided by RyzenAPI
-- Game: Tavern Keeper 🍻 Demo

-- MAIN APPLICATION
addappid(2833530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833531, 1, "7fe348d4fc1c1dc740d76a3002366ea2bed4767d84340e515874162059ae911d")

