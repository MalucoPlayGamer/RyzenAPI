-- Lua provided by RyzenAPI
-- Game: City of Ghosts Soundtrack

-- MAIN APPLICATION
addappid(1643930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643932,0,"9de923dae4ef3a951b8a160353deb7a2f8d2e47f495958836150eb929e5be395")
addappid(1643933,0,"0721d60acc267d847413c003d4452c476c6ae6c206d3e4d3f63cedf27ed48dfe")

