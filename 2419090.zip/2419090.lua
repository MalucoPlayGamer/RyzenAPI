-- Lua provided by RyzenAPI
-- Game: STAR WARS™: Bounty Hunter™

-- MAIN APPLICATION
addappid(2419090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419091, 1, "cafbfcc5232c7e18cbf7e75b2c33cc21e47b6db41fd4df6bb34c1ee8b6319d9c")
addappid(2419092, 1, "3d946f45e71d0aad26ae4de134c78583732e4b4fb2e0e8b434a4a6dec2d85d2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
