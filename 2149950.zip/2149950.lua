-- Lua provided by RyzenAPI
-- Game: addappid(2149950)

-- MAIN APPLICATION
addappid(2149950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149951, 1, "b170c3b7ae822bac18f87b4821e70bf1fad9395319f55020f81bfbfc939aedf6")
