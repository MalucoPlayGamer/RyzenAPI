-- Lua provided by RyzenAPI
-- Game: Transformative Summer: Life with a TS Companion

-- MAIN APPLICATION
addappid(2891040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891041, 1, "14ca9e740f91742818ed3cac056fb4fa5b8a28265929260e7c2522cfdbe5681b")
addappid(2891042, 1, "5b051332b344abc745bfd8fc4bdb5d0dfc47b4d366583b317622a72557fd4d35")
addappid(2891043, 1, "7bcfdb78875703dc094a46470655957ca2861096b15cb6aeadf148a1d64bafc8")
addappid(2891044, 1, "e2915da8b96880bd2da48f0531da6338f743a243e49a1bf88fc3ec972c5944b1")
