-- Lua provided by RyzenAPI
-- Game: Game: Wizardry 6: Bane of the Cosmic Forge

-- MAIN APPLICATION
addappid(245410)
-- Game: addappid(245410)

-- MAIN APP DEPOTS / PACKAGES
addappid(245411, 1, "e16993e4a7466e7e63a936c5d6e9989f46820c0caa2e4faa0558bb0ed692cbc3")
addappid(245412, 1, "bc4d735717a799c13d5c51ef434dfc5930e6204b746c19c03ba211d01573c567")
addappid(245413, 1, "446b16f71aef5d69d67d2f12be2d86c4ed9dd9a1090c28f009e38ac2b4bdc7e5")
addappid(245414, 1, "597fd4e81c0d74125d108d7f65d26968d4da3bb229de5f085cf42dfcb5edeaf5")
addappid(245415, 1, "c7ed8910fe9db865b13135078a64eafff9f5729d0aead0f5344f28bef7bab546")
addappid(245416, 1, "27776195e1ed1a20625f0f51774d28a92d453f091e62f423a81c2e1c388b3452")
addappid(245417, 1, "7e5b8ff1d2829fbd5356d7f031d170446ac86a774f80391bafa30a706050f785")
