-- 4736830's Lua and Manifest Created by Hubcap Manifest
-- S.O.L School Of Labyrinth
-- Created: August 13, 2026 at 04:06:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4736830) -- S.O.L School Of Labyrinth
-- MAIN APP DEPOTS
addappid(4736831, 1, "56fa15ebfc757c078d116b90fd0edb8256f0d6b7e75f0fcb8f42b5114666bee4") -- Depot 4736831
setManifestid(4736831, "4980613420959253379", 345192759)