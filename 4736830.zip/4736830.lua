-- Lua provided by RyzenAPI
-- Game: S.O.L School Of Labyrinth

-- MAIN APPLICATION
addappid(4736830) -- S.O.L School Of Labyrinth

-- MAIN APP DEPOTS / PACKAGES
addappid(4736831, 1, "56fa15ebfc757c078d116b90fd0edb8256f0d6b7e75f0fcb8f42b5114666bee4") -- Depot 4736831

