-- Lua provided by RyzenAPI
-- Game: HOW WE KNOW WE'RE ALIVE

-- MAIN APPLICATION
addappid(2216040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249828,0,"7ec9eafa57c435e04ffcc2355c5047c02f18c36e38984a1454e671cbd357e724")
addappid(2249829,0,"d9a563f6eb49a853042705b37a6d8a58a95c14d4373bd593f2fdb6a1eba52080")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2249820)
