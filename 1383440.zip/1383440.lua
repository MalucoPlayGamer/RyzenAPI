-- Lua provided by RyzenAPI
-- Game: Game: AppID 1383440

-- MAIN APPLICATION
addappid(1383440)
-- Game: addappid(1383440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383441, 1, "baef44f1b389e5e98d4a806ad327c0a7846cafc4bdfc5373bd559ff74cd720fb")
