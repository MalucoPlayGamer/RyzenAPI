-- Lua provided by RyzenAPI
-- Game: Game: Rock Star Life Simulator: Prologue

-- MAIN APPLICATION
addappid(2601600)
-- Game: addappid(2601600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601601, 1, "15dfec7ac7b5491c5478909141560b6ba46ee59b5112ceb4aaeff46385e18caf")
