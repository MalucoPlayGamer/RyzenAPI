-- Lua provided by RyzenAPI
-- Game: Ovulation!!DivineFist! Demo

-- MAIN APPLICATION
addappid(1189940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189941, 1, "bc0185ea00982245b753be62dd025b698ccc979fd8dbb65e50e459969d658262")

