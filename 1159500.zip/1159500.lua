-- Lua provided by RyzenAPI
-- Game: Ghost Files 2: Memory of a Crime

-- MAIN APPLICATION
addappid(1159500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159501, 1, "9701433a9181159411fb9776ad1205c46a57a8062e3dbc22a3cb552f38ff6c73")
