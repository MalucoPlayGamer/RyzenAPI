-- Lua provided by RyzenAPI
-- Game: Don't Bleed

-- MAIN APPLICATION
addappid(723810)

-- MAIN APP DEPOTS / PACKAGES
addappid(723811,0,"cc09a7d999ba9c0d1c84ad921d6e095933da61b3306abf019abe9a8bc95e005e")

