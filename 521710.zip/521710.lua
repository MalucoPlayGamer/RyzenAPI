-- Lua provided by RyzenAPI
-- Game: 521710

-- MAIN APPLICATION
addappid(521710)
-- Game: addappid(521710)

-- MAIN APP DEPOTS / PACKAGES
addappid(521711, 1, "2f36aa83c106e2be3a532903e8c5098ba63a8c4e475af273fef975b47ec4bca1")
