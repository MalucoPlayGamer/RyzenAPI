-- Lua provided by SkyAPI 
-- Game: Romance of the Three Kingdoms III
addappid(521710)
addappid(521711, 1, "2f36aa83c106e2be3a532903e8c5098ba63a8c4e475af273fef975b47ec4bca1")
