-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms III

-- MAIN APPLICATION
addappid(521710)

-- MAIN APP DEPOTS / PACKAGES
addappid(521711, 1, "2f36aa83c106e2be3a532903e8c5098ba63a8c4e475af273fef975b47ec4bca1")
