-- Lua provided by RyzenAPI
-- Game: Game: AppID 1040000

-- MAIN APPLICATION
addappid(1040000)
-- Game: addappid(1040000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040001, 1, "4f56c4d763c35cc58b23083b8133bf0438f78555c4a4af6fe5c379225143b40d")
