-- Lua provided by RyzenAPI
-- Game: Furry Boss 💼

-- MAIN APPLICATION
addappid(2089060)
addappid(2091440)
-- Game: addappid(2089060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089061, 1, "80a1224a2ac96b4e0d6f4e30d9164f465b4da1e8d355fc0c9f7f7a3b777a0066")
addappid(2089062, 1, "a532c93a333236a31fe683d4b7e10e9794693f844b06b9923ae952424d11b5ea")
