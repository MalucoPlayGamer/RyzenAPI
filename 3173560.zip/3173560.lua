-- Lua provided by RyzenAPI
-- Game: Anomalous Coffee Machine

-- MAIN APPLICATION
addappid(3173560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173561, 1, "9cf5d3ea5288b1451038e7e924d155b3dae10b231ef5a02b19828ea14f86c7b8")
