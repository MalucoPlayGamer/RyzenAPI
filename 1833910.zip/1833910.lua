-- Lua provided by RyzenAPI
-- Game: addappid(1833910)

-- MAIN APPLICATION
addappid(1833910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833911, 1, "81ef7fc4b7a2564c8a519c2bd8bde76b6aff024f06ebb9e577050c78fc06eb53")
