-- Lua provided by RyzenAPI
-- Game: Leave No One Behind: Ia Drang

-- MAIN APPLICATION
addappid(1635350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635351, 1, "33352aa72fb3f3fbb8034ad70da9e00a4bb827996a810ee2cd085c4f41b93411")

