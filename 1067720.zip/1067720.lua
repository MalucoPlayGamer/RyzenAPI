-- Lua provided by RyzenAPI
-- Game: AppID 1067720

-- MAIN APPLICATION
addappid(1067720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1067721, 1, "05a57f2322bf3b336a349a955fef23b74d525cf5ac5d1c107bbe0f0ac611abc1")
addappid(1113510, 0, "a9861ace051ebec1bc45a76d22b70492a95361632c8438f4b573dbed386349b7")

