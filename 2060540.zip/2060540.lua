-- Lua provided by RyzenAPI
-- Game: Game: AppID 2060540

-- MAIN APPLICATION
addappid(2060540)
-- Game: addappid(2060540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060541, 1, "24220a8257ac0d75dbf1dad195a5ec813460f5a1fc782f280acc1296196c87b2")
