-- Lua provided by RyzenAPI
-- Game: Game: WyVRn: Dragon Flight VR

-- MAIN APPLICATION
addappid(500090)
-- Game: addappid(500090)

-- MAIN APP DEPOTS / PACKAGES
addappid(500091, 1, "a3552e8a18dee97be533bd7e05804806cab85312a4df74b00c0bf9ee5c994047")
