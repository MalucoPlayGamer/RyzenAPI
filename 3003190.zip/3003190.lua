-- Lua provided by RyzenAPI
-- Game: 3003190

-- MAIN APPLICATION
addappid(3003190)
-- Game: addappid(3003190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003191, 1, "fca01cb7f2bd427f80f6ff7ddb272527eabd1adc99e8b9b401c0cbacc56d46ad")
