-- Lua provided by RyzenAPI
-- Game: Desta: The Memories Between

-- MAIN APPLICATION
addappid(2009650)
addappid(2366570)
-- Game: addappid(2009650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009651, 1, "17ecbf5baa48ad112d7cdd80b679c2653bdc40163eb6fe64748faaa9fbe32c73")
