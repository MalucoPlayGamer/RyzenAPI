-- Lua provided by RyzenAPI
-- Game: Natsuki Chronicles

-- MAIN APPLICATION
addappid(1175190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175191, 1, "ab985b84529e75e25aa6f68c2abde709631d70157676a79162cd47eadb7f5a03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
