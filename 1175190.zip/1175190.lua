-- Lua provided by RyzenAPI
-- Game: Natsuki Chronicles

-- MAIN APPLICATION
addappid(1175190)
-- Game: addappid(1175190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175191, 1, "ab985b84529e75e25aa6f68c2abde709631d70157676a79162cd47eadb7f5a03")
