-- Lua provided by RyzenAPI
-- Game: Combat Arms: Reloaded

-- MAIN APPLICATION
addappid(905640)

-- MAIN APP DEPOTS / PACKAGES
addappid(905641, 1, "c511e0c24982b92751d28b6f258e73f6d9b67e82de3d04f477a0e0197791fcb3")
