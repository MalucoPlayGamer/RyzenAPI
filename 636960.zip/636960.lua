-- Lua provided by RyzenAPI 
-- Game: AppID 636960
addappid(636960)
addappid(636961, 1, "5fe7f51a1b0cd35b5df658e3226849530b8db72288967143bc96e33d93b9665a")
