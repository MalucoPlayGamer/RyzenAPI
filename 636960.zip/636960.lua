-- Lua provided by RyzenAPI
-- Game: Wo Yao Da  我要大

-- MAIN APPLICATION
addappid(636960)
-- Game: addappid(636960)

-- MAIN APP DEPOTS / PACKAGES
addappid(636961, 1, "5fe7f51a1b0cd35b5df658e3226849530b8db72288967143bc96e33d93b9665a")
