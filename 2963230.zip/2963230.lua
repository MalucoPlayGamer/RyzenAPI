-- Lua provided by RyzenAPI
-- Game: addappid(2963230)

-- MAIN APPLICATION
addappid(2963230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963231, 1, "0a85897111f938ecd23925e5c3f5a9b9aee10db3867e3a8bf919360978f5dbab")
