-- Lua provided by RyzenAPI
-- Game: Frogun Official Artbook & Manual

-- MAIN APPLICATION
addappid(2071750)
-- Game: addappid(2071750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071750,0,"4f31aa381d8ba2908356a89ab98116e7168e16f9f2859c50fc88573fece2736b")
