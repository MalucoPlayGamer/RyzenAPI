-- Lua provided by SkyAPI 
-- Game: Magical Battle Cry
addappid(895110)
addappid(895111, 1, "6bac365af3f5b38d795b82c536f6b23418534053eed74ffbe41b84b9f9fef3b5")
