-- Lua provided by RyzenAPI
-- Game: Game: AppID 1837780

-- MAIN APPLICATION
addappid(1837780)
-- Game: addappid(1837780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837781, 1, "e6ba4ff4113b824f0dcfb190cc781bab20967c97b317989278dd88a01c0ed75a")
