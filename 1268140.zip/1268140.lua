-- Lua provided by RyzenAPI
-- Game: Lair Land Story

-- MAIN APPLICATION
addappid(1268140)
addappid(1487490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268141, 1, "e6d575da08bd0313dec8ff4345ce262b197c6796687926fac20d1ae4908b7599")

