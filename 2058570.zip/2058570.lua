-- Lua provided by RyzenAPI
-- Game: Rift Wizard 2

-- MAIN APPLICATION
addappid(2058570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058571, 1, "21bd211a1cb4704be16350381cf96407c28ea02f4af0e78fa1f3bb3b65727c79")

