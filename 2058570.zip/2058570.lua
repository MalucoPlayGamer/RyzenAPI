-- Lua provided by RyzenAPI
-- Game: addappid(2058570)

-- MAIN APPLICATION
addappid(2058570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058571, 1, "21bd211a1cb4704be16350381cf96407c28ea02f4af0e78fa1f3bb3b65727c79")
