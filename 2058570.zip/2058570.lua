-- Lua provided by RyzenAPI
-- Game: Rift Wizard 2

-- MAIN APPLICATION
addappid(2058570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058571, 1, "21bd211a1cb4704be16350381cf96407c28ea02f4af0e78fa1f3bb3b65727c79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
