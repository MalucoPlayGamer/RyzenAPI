-- Lua provided by RyzenAPI
-- Game: Game: Pogo Girlfriend 👧🏼

-- MAIN APPLICATION
addappid(2318880)
-- Game: addappid(2318880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318881, 1, "8f856a8bbc563edc989bfe7c88a2af24eea4756f55b190ed0fc8fcd7bbbb5981")
