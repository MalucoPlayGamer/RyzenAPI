-- Lua provided by RyzenAPI
-- Game: addappid(1119380)

-- MAIN APPLICATION
addappid(1119380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119381, 1, "7d7cb8d9a84f5c2dba3e44ec2c9e296058acb706ce64827fb6db81170de31f81")
