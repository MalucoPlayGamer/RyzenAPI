-- Lua provided by RyzenAPI
-- Game: Baldur's Gate: Dark Alliance II

-- MAIN APPLICATION
addappid(1889930)
-- Game: addappid(1889930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889931, 1, "c271a57d12525930ad8de02c5de1699b688dd35e1558bf77d95c147389ec6ba3")
