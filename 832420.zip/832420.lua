-- Lua provided by RyzenAPI
-- Game: 832420

-- MAIN APPLICATION
addappid(832420)
-- Game: addappid(832420)

-- MAIN APP DEPOTS / PACKAGES
addappid(832421, 1, "6803ed858a7484b41282ba57e7a331a7e34b3e8c005a2941dcaacb34e65279db")
