-- Lua provided by RyzenAPI
-- Game: Hentai Girl in Space

-- MAIN APPLICATION
addappid(981910)

-- MAIN APP DEPOTS / PACKAGES
addappid(981911, 1, "00cecb7fb26466ae02c6b125e8d629661d4c7d835f4debeb932747bc3190b1fa")

