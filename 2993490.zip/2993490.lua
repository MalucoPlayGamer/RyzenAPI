-- Lua provided by RyzenAPI
-- Game: Reflect Demo

-- MAIN APPLICATION
addappid(2993490)
-- Game: addappid(2993490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993491, 1, "1fcf5ec2c1ba2b97f1ba4aa5de4613723a0b8d2fa6dfdf499ebb52ab414a8374")
