-- Lua provided by RyzenAPI
-- Game: addappid(2927940)

-- MAIN APPLICATION
addappid(2927940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927941, 1, "6de29a4b400efb2d78c3f43c192b8477da17b68a2e908025fcd113babcbd6174")
