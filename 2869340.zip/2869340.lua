-- Lua provided by RyzenAPI 
-- Game: AppID 2869340
addappid(2869340)
addappid(2869341, 1, "7664fbbea7238c65b733beeefc1253b5fda8ce657b2386d689870dd62fe8ea3d")
