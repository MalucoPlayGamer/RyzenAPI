-- Lua provided by RyzenAPI
-- Game: Game: Dark Night

-- MAIN APPLICATION
addappid(434150)
-- Game: addappid(434150)

-- MAIN APP DEPOTS / PACKAGES
addappid(434151, 1, "a341fe3491e94427d360c8dd807998ae472a496669054a2855d286a994f4580e")
