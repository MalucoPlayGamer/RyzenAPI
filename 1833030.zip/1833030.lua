-- Lua provided by RyzenAPI
-- Game: AppID 1833030

-- MAIN APPLICATION
addappid(1833030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833031, 1, "23eb1bbab1b78534a8c99abc8dbfba265ffba9cb2ce0f6f3ac6412c6efaabec7")
