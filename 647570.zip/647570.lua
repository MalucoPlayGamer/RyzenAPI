-- Lua provided by RyzenAPI
-- Game: addappid(647570)

-- MAIN APPLICATION
addappid(647570)

-- MAIN APP DEPOTS / PACKAGES
addappid(647572,0,"ae264ce91bce90f00fac619013f3ba0097ba2b4fbccef725098f0eaf98d6e6c3")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
