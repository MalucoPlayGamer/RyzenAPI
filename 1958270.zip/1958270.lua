-- Lua provided by RyzenAPI
-- Game: Strip 'Em II: Facka's Game

-- MAIN APPLICATION
addappid(1958270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958271, 1, "1e0fa4f435ac8add0843d3f69af029bd51a378ddf201bc0f5663e4781ea3bbda")
