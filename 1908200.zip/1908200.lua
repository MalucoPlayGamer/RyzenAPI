-- Lua provided by RyzenAPI
-- Game: VHS PLATFORM: 2D

-- MAIN APPLICATION
addappid(1908200)
-- Game: addappid(1908200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908201, 1, "9135bfe6afa86b83403d5b760e1ae2c24399f5b3b03ed758f0ea3f16ff28a792")
