-- Lua provided by RyzenAPI
-- Game: 2025: Mosaic Retrospective

-- MAIN APPLICATION
addappid(4266120)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4487440)
