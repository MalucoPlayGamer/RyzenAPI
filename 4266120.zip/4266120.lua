-- Lua provided by RyzenAPI
-- Game: 2025: Mosaic Retrospective

-- MAIN APPLICATION
addappid(4266120)

