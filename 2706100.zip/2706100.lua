-- Lua provided by RyzenAPI
-- Game: Castle Capture Topkapi Demo

-- MAIN APPLICATION
addappid(2706100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706101, 1, "3befe460ab41ef4a1f81fbb408ce846392f82ba4bbcc78080e180269be772ea0")

