-- Lua provided by SkyAPI 
-- Game: Explosive Madness
addappid(2598660)
addappid(2598661, 1, "3dfa195e27bdf39c72799eda314f69b68ee9223d4d1b2ccf88d0522d05c6bca0")
