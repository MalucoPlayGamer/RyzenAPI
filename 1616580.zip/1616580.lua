-- Lua provided by RyzenAPI 
-- Game: Ninja Frog
addappid(1616580)
addappid(1616581, 1, "17f21459f231071e44c158ea0324f656445537a8d90a64d56b4744228a0dc4c7")
