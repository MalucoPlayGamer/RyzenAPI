-- Lua provided by RyzenAPI
-- Game: Game: Ninja Frog

-- MAIN APPLICATION
addappid(1616580)
-- Game: addappid(1616580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616581, 1, "17f21459f231071e44c158ea0324f656445537a8d90a64d56b4744228a0dc4c7")
