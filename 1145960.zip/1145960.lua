-- Lua provided by RyzenAPI
-- Game: 1145960

-- MAIN APPLICATION
addappid(1145960)
-- Game: addappid(1145960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145961, 1, "eb19d9c4303dc47b702196c458ac3167859199c53d1d786fe696bd9a8bd273cd")
addappid(1145962, 1, "8072e8d1c1af7a5c7d5b3d4cd0909ee665c8b9d632f8e16df3b62690e2eb17c0")
