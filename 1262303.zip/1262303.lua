-- Lua provided by RyzenAPI
-- Game: AUDICA - Party Bois - "Girls Be Dancing "

-- MAIN APPLICATION
addappid(1262303)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262303,0,"5618ac0a92fb780d5122561f9e808091dfe183300ecb303070062cc63e199a83")

