-- Lua provided by RyzenAPI 
-- Game: AppID 1161460
addappid(1161460)
addappid(1161461, 1, "714e36ee849bc54db5cc3f15043316f398d767b2229256494c8702a2de40b363")
addappid(1161462, 1, "40c42cbafe606f34b017c05d90838fa0dadc99a5efc4ba405ee6962f1561a987")
