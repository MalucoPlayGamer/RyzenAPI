-- Lua provided by RyzenAPI 
-- Game: Aethyr Demo
addappid(2053500)
addappid(2053501, 1, "dbea030990d4db725aa979e673d4970f7065f645fd7af20176e787f5d9757562")
