-- Lua provided by RyzenAPI
-- Game: Game: Aethyr Demo

-- MAIN APPLICATION
addappid(2053500)
-- Game: addappid(2053500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053501, 1, "dbea030990d4db725aa979e673d4970f7065f645fd7af20176e787f5d9757562")
