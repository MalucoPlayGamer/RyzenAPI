-- Lua provided by RyzenAPI
-- Game: addappid(1899300)

-- MAIN APPLICATION
addappid(1899300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899301, 1, "4143450837131dd1d6b52ce8eb91d17939dc7bf481622ceb1861a5ed6e9c7995")
