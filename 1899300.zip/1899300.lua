-- Lua provided by RyzenAPI
-- Game: Combat Complex

-- MAIN APPLICATION
addappid(1899300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1899301, 1, "4143450837131dd1d6b52ce8eb91d17939dc7bf481622ceb1861a5ed6e9c7995")

