-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms XI with Power Up Kit

-- MAIN APPLICATION
addappid(628070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(628071, 1, "8dc6b735d02d38ee6622843378ed3b020e7b215b0a686a6e11e2ea53b898f7ac")
addappid(628072, 1, "b3abca25c927403a9625b28878837092bea054c7fbdf652d740de7eb0a32d5ac")

