-- Lua provided by RyzenAPI 
-- Game: The Parasites Demo
addappid(2101540)
addappid(2101541, 1, "2fefd03c9246a18ccbe93c68980386491c1d8ae5110bf6c025aa4c6833a1b484")
