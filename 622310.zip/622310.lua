-- Lua provided by RyzenAPI
-- Game: Amigo VR

-- MAIN APPLICATION
addappid(622310)
-- Game: addappid(622310)

-- MAIN APP DEPOTS / PACKAGES
addappid(622311, 1, "edbb164ca5fa7dd6082cff31eeacb314a13c60248439eff78d6486dd586ef008")
