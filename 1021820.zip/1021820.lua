-- Lua provided by SkyAPI 
-- Game: AppID 1021820
addappid(1021820)
addappid(1021821, 1, "d608c42a03688e72a14c0becc0c28500cebe97d2109dc30c389690b69cfaab21")
