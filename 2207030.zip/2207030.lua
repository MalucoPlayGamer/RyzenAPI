-- Lua provided by SkyAPI 
-- Game: 下山的试炼之江湖遗失录 A test before Jianghu
addappid(2207030)
addappid(2207031, 1, "f5b82f2f0528f3002ed39a751ae1f089c49a366834ba854e31672a3164d784ac")
addappid(2207032, 1, "a4e8c1a97ce38b5e865a115686de94a3de6bdd7a5774bbeff9d3091b36735912")
