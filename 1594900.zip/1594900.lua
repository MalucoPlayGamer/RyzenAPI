-- Lua provided by RyzenAPI
-- Game: addappid(1594900)

-- MAIN APPLICATION
addappid(1594900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594901, 1, "af7ea7db14eb830223f96e63fb01bba7a71bb092af7e5cb8fc329e83e4cf74eb")
