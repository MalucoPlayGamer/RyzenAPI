-- Lua provided by RyzenAPI
-- Game: FoE Remains

-- MAIN APPLICATION
addappid(3908900)

