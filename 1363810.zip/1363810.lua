-- Lua provided by RyzenAPI 
-- Game: Astra
addappid(1363810)
addappid(1363811, 1, "39db9ee8906ecc359ef56a41dc835e9e7b3b2293db76cdc8f5e7b9ce7a5ac0b2")
