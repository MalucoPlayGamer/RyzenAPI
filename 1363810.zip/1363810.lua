-- Lua provided by RyzenAPI
-- Game: Astra

-- MAIN APPLICATION
addappid(1363810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1363811, 1, "39db9ee8906ecc359ef56a41dc835e9e7b3b2293db76cdc8f5e7b9ce7a5ac0b2")

