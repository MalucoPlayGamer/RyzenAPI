-- Lua provided by RyzenAPI
-- Game: Merging Cubes

-- MAIN APPLICATION
addappid(2363460)
-- Game: addappid(2363460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363461, 1, "a8ea5efb23562a874c0c5fccab423b7ba88876891e42384ab5c737d6c6f2bf88")
