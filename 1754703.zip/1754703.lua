-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Atelier Series Legacy BGM Pack

-- MAIN APPLICATION
addappid(1754703)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754703,0,"d3e7799d9a68e156608d74aa0ef6049e36dd0df1308c016b0dc15f90f59298e7")

