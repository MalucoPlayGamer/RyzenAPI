-- Lua provided by RyzenAPI 
-- Game: AppID 1485120
addappid(1485120)
addappid(1485121, 1, "b428c3dbdf41b1824084136690848ca248101493a9719a9478f8b5b0ae0f9eeb")
