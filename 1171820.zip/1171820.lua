-- Lua provided by RyzenAPI
-- Game: Creme de la Creme

-- MAIN APPLICATION
addappid(1171820)
addappid(2324710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171821, 1, "07b20297417956101a790f3b8d6579333f331c52cf307c554c7979d6f0a603fc")
