-- Lua provided by RyzenAPI
-- Game: Game: Armchair Commander

-- MAIN APPLICATION
addappid(2598940)
-- Game: addappid(2598940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598941, 1, "bb26403d3b87649687ea44e5d8996eac0e4d65271cb9c24aac9e242e1283c1f1")
