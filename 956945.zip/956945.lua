-- Lua provided by RyzenAPI
-- Game: 956945

-- MAIN APPLICATION
addappid(956945)

-- MAIN APP DEPOTS / PACKAGES
addappid(956945,0,"8e4f21b3472163cbd37cd362eba71138fd02e580dbc6fcc67ef3808502c50acf")

