-- Lua provided by RyzenAPI
-- Game: 1824990

-- MAIN APPLICATION
addappid(1824990)
-- Game: addappid(1824990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824991, 1, "d60ee1e3db62e6efb667fffc2f53aaa58a06f9fc25b4aa23c729db5d4e7075d3")
