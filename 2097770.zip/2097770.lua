-- Lua provided by RyzenAPI
-- Game: Slave Princess Finne, why did she sell out her own kingdom?

-- MAIN APPLICATION
addappid(2097770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097771, 1, "21bac1ae9305a50948688faa69659cf8603c9581fb9c725e1d5494d5203d9bf0")
addappid(2097772, 1, "757b828cc9eb75a25f7f23575090d8362b7bae797d470b747d46d2b7810ec018")
addappid(2097773, 1, "25e9fc0dad86978fdbc6944348e0cba11378f922baa30a79b77352049a357168")
