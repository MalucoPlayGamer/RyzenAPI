-- Lua provided by RyzenAPI
-- Game: addappid(2987180)

-- MAIN APPLICATION
addappid(2987180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987181, 1, "8107c4e9b305a44b207af39fc730f46329192fd7cd6d1a962baeffb253cd5ed8")
