-- Lua provided by RyzenAPI
-- Game: ACTION GAME MAKER

-- MAIN APPLICATION
addappid(2987180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987181, 1, "8107c4e9b305a44b207af39fc730f46329192fd7cd6d1a962baeffb253cd5ed8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3739220)
addappid(4559270)
addappid(4790560)
addappid(4838760)
addappid(4910950)
addappid(4910960)
addappid(4961610)
addappid(4961630)
addappid(4961640)
addappid(4961650)
addappid(4961670)
addappid(5035610)
addappid(5035620)
addappid(5098900)
addappid(5098910)
