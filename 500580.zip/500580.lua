-- Lua provided by RyzenAPI
-- Game: Game: AppID 500580

-- MAIN APPLICATION
addappid(500580)
-- Game: addappid(500580)

-- MAIN APP DEPOTS / PACKAGES
addappid(500581, 1, "c3cebe151b3d74c6ec81ab050f83fdc02c66aff42b614add9f55f9d33f48bfe9")
