-- Lua provided by RyzenAPI
-- Game: Olorun: Theocracy

-- MAIN APPLICATION
addappid(692780)

-- MAIN APP DEPOTS / PACKAGES
addappid(692781,0,"a054cfb0e7695087cd4db413ce63898bf5ff727f4168f02ec285f3c547e94b36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
