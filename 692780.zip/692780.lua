-- Lua provided by RyzenAPI
-- Game: Olorun: Theocracy

-- MAIN APPLICATION
addappid(692780)

-- MAIN APP DEPOTS / PACKAGES
addappid(692781,0,"a054cfb0e7695087cd4db413ce63898bf5ff727f4168f02ec285f3c547e94b36")

