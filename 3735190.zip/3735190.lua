-- Lua provided by RyzenAPI
-- Game: Anime Dream Match: Dogs

-- MAIN APPLICATION
addappid(3735190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3735191, 1, "1c8aad26c75cc075fb17c118b8580b74f8de03a3af5e7c24c98fc8386e2b1422")
