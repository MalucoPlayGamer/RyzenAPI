-- Lua provided by RyzenAPI
-- Game: Spinshot Party Demo

-- MAIN APPLICATION
addappid(2845750)
-- Game: addappid(2845750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845751, 1, "2b4071b410eed58ec25ee746addcada89cfc922c406a9402863ddd377815b27f")
