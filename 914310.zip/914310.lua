-- Lua provided by RyzenAPI
-- Game: Copy Kitty OST

-- MAIN APPLICATION
addappid(914310)
-- Game: addappid(914310)

-- MAIN APP DEPOTS / PACKAGES
addappid(914310,0,"476034bdcd0af47cc5eb21beb89bc0c929580661278cf1ebfd214aa8f59c7745")
