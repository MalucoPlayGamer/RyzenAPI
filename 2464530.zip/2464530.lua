-- Lua provided by RyzenAPI
-- Game: VOIN

-- MAIN APPLICATION
addappid(2464530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464531, 1, "97e330a8fab2c3c5b986850ae289c9fb852bad4b6a15f04d0695d62cb23a218d")
