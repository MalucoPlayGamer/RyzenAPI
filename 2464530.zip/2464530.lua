-- Lua provided by RyzenAPI
-- Game: VOIN

-- MAIN APPLICATION
addappid(2464530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2464531, 1, "97e330a8fab2c3c5b986850ae289c9fb852bad4b6a15f04d0695d62cb23a218d")

