-- Lua provided by RyzenAPI
-- Game: Game: ETERNAL BLOOD

-- MAIN APPLICATION
addappid(1218940)
-- Game: addappid(1218940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218941, 1, "113cabca68ac50aa4bbe4b2b7fff13427f7761d1ca17fd36865652b6a7a8a3b4")
