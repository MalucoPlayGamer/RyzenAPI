-- Lua provided by RyzenAPI
-- Game: ETERNAL BLOOD

-- MAIN APPLICATION
addappid(1218940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218941, 1, "113cabca68ac50aa4bbe4b2b7fff13427f7761d1ca17fd36865652b6a7a8a3b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
