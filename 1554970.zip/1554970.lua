-- Lua provided by RyzenAPI
-- Game: Game: Rogue Spirit

-- MAIN APPLICATION
addappid(1554970)
-- Game: addappid(1554970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554971, 1, "232dedd0f0bb7a1f21c2b821da815453b9721d0978c7be8eb050f739c7832c90")
