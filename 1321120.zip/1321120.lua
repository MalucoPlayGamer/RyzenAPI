-- Lua provided by RyzenAPI
-- Game: Game: Matsuro Palette

-- MAIN APPLICATION
addappid(1321120)
-- Game: addappid(1321120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321121, 1, "d9b212ef5909df2155b7638737a857157873b3862570843b1e7d5e67b3c21528")
