-- Lua provided by RyzenAPI
-- Game: addappid(818520)

-- MAIN APPLICATION
addappid(818520)

-- MAIN APP DEPOTS / PACKAGES
addappid(818521, 1, "149a50ad89bd36bfa5c15cdd859336466689abaecc6ce54f3c8ec6cb0ff6bbd1")
