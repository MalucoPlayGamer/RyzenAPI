-- Lua provided by RyzenAPI 
-- Game: AppID 904820
addappid(904820)
addappid(904821, 1, "8b46cbb94c5195b3c34aa8aa0d3adcec29ef9b621e0ef76f3b69565881dbff83")
