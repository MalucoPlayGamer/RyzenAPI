-- Lua provided by RyzenAPI
-- Game: Crash Time 3

-- MAIN APPLICATION
addappid(33620)

-- MAIN APP DEPOTS / PACKAGES
addappid(33621, 1, "e1ce860b234383b81c55de48b11df40601e7071a34c5a56b30bc007e3a5a5f18")
addappid(33622, 1, "d8b8961dee2c6222ef26947a675abdd31e5136d82f6100e5c3abf7a1be4669f3")
addappid(33623, 1, "9b4f9517fc9685db2d1e29398b557486a79ad9856cdc3f147af2a019cbb41f9f")

