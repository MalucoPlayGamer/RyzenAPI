-- Lua provided by RyzenAPI
-- Game: Game: Zombie Apocalypse Survival Simulator

-- MAIN APPLICATION
addappid(2152190)
-- Game: addappid(2152190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152191, 1, "4e015692f8abf64b72c6ed45cbbd4d5f628a480112ab7bae980f65915224fa0a")
