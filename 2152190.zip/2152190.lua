-- Lua provided by RyzenAPI
-- Game: Zombie Apocalypse Survival Simulator

-- MAIN APPLICATION
addappid(2152190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152191, 1, "4e015692f8abf64b72c6ed45cbbd4d5f628a480112ab7bae980f65915224fa0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
