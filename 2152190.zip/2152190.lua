-- Lua provided by RyzenAPI 
-- Game: Zombie Apocalypse Survival Simulator
addappid(2152190)
addappid(2152191, 1, "4e015692f8abf64b72c6ed45cbbd4d5f628a480112ab7bae980f65915224fa0a")
