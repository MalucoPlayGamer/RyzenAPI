-- Lua provided by RyzenAPI
-- Game: Quadratic puzzle 5

-- MAIN APPLICATION
addappid(2055440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055441, 1, "13652dcd326810f958c73291fc29006641ee538ac95d9b0f592f623d52b121c9")

