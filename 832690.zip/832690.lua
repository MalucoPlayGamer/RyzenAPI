-- Lua provided by RyzenAPI
-- Game: Stonetowers

-- MAIN APPLICATION
addappid(832690)

-- MAIN APP DEPOTS / PACKAGES
addappid(832691,0,"e6d30d6b27bb203593b069803a29be22d449153f8ac4e74970e715e2e3553216")

