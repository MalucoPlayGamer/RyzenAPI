-- Lua provided by RyzenAPI
-- Game: addappid(2365870)

-- MAIN APPLICATION
addappid(2365870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365871, 1, "38cbac3257d4aa7b86ab41dc7e43e170ff5629ead4186a2bc6bae61fcddc2a5c")
