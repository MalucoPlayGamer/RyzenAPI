-- Lua provided by RyzenAPI
-- Game: Absolum

-- MAIN APPLICATION
addappid(1904480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904481, 1, "119d51fd44dd8198b1a6c12a73e3943c8587d93e990f15b7453404b51a8ce4f3")

