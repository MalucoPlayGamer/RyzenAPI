-- Lua provided by RyzenAPI
-- Game: Absolum

-- MAIN APPLICATION
addappid(1904480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904481, 1, "119d51fd44dd8198b1a6c12a73e3943c8587d93e990f15b7453404b51a8ce4f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
