-- Lua provided by RyzenAPI
-- Game: EyeRoll

-- MAIN APPLICATION
addappid(1598490)
-- Game: addappid(1598490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598491, 1, "23a875968611967284116b29fef8442f7006ae52dc2caf3c8cf812a51fd4513f")
