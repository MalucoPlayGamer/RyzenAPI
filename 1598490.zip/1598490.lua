-- Lua provided by RyzenAPI
-- Game: EyeRoll

-- MAIN APPLICATION
addappid(1598490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1598491, 1, "23a875968611967284116b29fef8442f7006ae52dc2caf3c8cf812a51fd4513f")

