-- Lua provided by RyzenAPI
-- Game: In Sink: A Co-op Escape Adventure

-- MAIN APPLICATION
addappid(1858650)
-- Game: addappid(1858650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858652,0,"7559977939e30619429f880437084991c4f807e755c509ca88987b500426198d")
