-- Lua provided by RyzenAPI
-- Game: Tale of Fallen Dragons

-- MAIN APPLICATION
addappid(570980)

-- MAIN APP DEPOTS / PACKAGES
addappid(570981, 1, "b864b9fc59c25f8fd9832746a83f7c826d3b43d3b7bf947a54d4ddd7f68db88f")

