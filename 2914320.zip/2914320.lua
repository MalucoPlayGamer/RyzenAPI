-- Lua provided by RyzenAPI
-- Game: Press Any Key

-- MAIN APPLICATION
addappid(2914320)
addappid(2921010)

