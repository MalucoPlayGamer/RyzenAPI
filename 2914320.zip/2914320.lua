-- Lua provided by RyzenAPI
-- Game: Press Any Key

-- MAIN APPLICATION
addappid(2914320)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2921010)
