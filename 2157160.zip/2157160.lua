-- Lua provided by RyzenAPI
-- Game: Needy Dragons Demo

-- MAIN APPLICATION
addappid(2157160)
-- Game: addappid(2157160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157161, 1, "2f260ef0a61f9746a2614c1ca0c8befb2a17819eff656b5166ed97dabd9b5925")
