-- Lua provided by SkyAPI 
-- Game: Needy Dragons Demo
addappid(2157160)
addappid(2157161, 1, "2f260ef0a61f9746a2614c1ca0c8befb2a17819eff656b5166ed97dabd9b5925")
