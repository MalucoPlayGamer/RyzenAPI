-- Lua provided by RyzenAPI
-- Game: addappid(491790)

-- MAIN APPLICATION
addappid(491790)

-- MAIN APP DEPOTS / PACKAGES
addappid(491791, 1, "8d0d412a113f581b3d8fd1a8be6c67c705b0f1b7ac5941d1223b09f833573d34")
