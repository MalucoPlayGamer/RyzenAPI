-- Lua provided by RyzenAPI
-- Game: AppID 1173780

-- MAIN APPLICATION
addappid(1173780)
-- Game: addappid(1173780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173781, 1, "2b92c4a4fee49b0e20479eddaaeb5ee4dc9c31a380f07c06ab5edb9501ca9fd1")
addappid(1638320, 0, "4104b8d6e24585b8b33b8fe368ca07e2aaf4320289cd78bd6f2cea44e8794db3")
