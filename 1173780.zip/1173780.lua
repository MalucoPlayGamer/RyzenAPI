-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY II

-- MAIN APPLICATION
addappid(1173780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1173781, 1, "2b92c4a4fee49b0e20479eddaaeb5ee4dc9c31a380f07c06ab5edb9501ca9fd1")
addappid(1638320, 0, "4104b8d6e24585b8b33b8fe368ca07e2aaf4320289cd78bd6f2cea44e8794db3")
