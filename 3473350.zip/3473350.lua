-- Lua provided by RyzenAPI
-- Game: Game: Shrine Of The Forest God

-- MAIN APPLICATION
addappid(3473350)
-- Game: addappid(3473350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473351, 1, "4d0a92f934f88f620abd16ab25280b88353be44685a45351b53d764e8d071b42")
