-- Lua provided by RyzenAPI
-- Game: Game: The Book of Bondmaids - Tales

-- MAIN APPLICATION
addappid(2212700)
-- Game: addappid(2212700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212701, 1, "b28765ed195c23a759eff15fb1d97b87c3116c43a0535d651cf6da3ef47c6697")
addappid(2212702, 1, "032e4fd4778798467db8b6f3a72a1e597f77f2469605f39203e83b19aa7c8bbe")
addappid(2212703, 1, "0e7b3a6c255277f84ccf02680044aa4476e5cf12e3a7844c346ad80dd830f63d")
