-- Lua provided by RyzenAPI
-- Game: 7 Sexy Sins

-- MAIN APPLICATION
addappid(1023740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023741, 1, "080d958a5c49374cd18c8d02ed6afd38caf19d49121f1bbf944ab419ad82df5d")
