-- Lua provided by RyzenAPI
-- Game: addappid(2563540)

-- MAIN APPLICATION
addappid(2563540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563541, 1, "ed1dbb8bac6aec4374d552d2e880c20dd8755ebf67bb137618a16acdbf8e661d")
