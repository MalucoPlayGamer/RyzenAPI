-- Lua provided by RyzenAPI
-- Game: RoboBunnies In Space!

-- MAIN APPLICATION
addappid(941600)
-- Game: addappid(941600)

-- MAIN APP DEPOTS / PACKAGES
addappid(941601, 1, "9cf2d48b5ccf424e81ee1585aee089935dd835f95b227428158b0055d94604b1")
