-- Lua provided by SkyAPI 
-- Game: AppID 1948660
addappid(1948660)
addappid(1948661, 1, "0c9f803a320f887a378dd778a9583f34f131a4218be5b89c331d1a80a018bd93")
