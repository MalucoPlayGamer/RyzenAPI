-- Lua provided by RyzenAPI
-- Game: Game: AppID 1948660

-- MAIN APPLICATION
addappid(1948660)
-- Game: addappid(1948660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948661, 1, "0c9f803a320f887a378dd778a9583f34f131a4218be5b89c331d1a80a018bd93")
