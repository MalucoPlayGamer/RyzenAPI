-- Lua provided by RyzenAPI
-- Game: 358090

-- MAIN APPLICATION
addappid(358090)
addappid(367590)
addappid(367591)
addappid(367592)
addappid(368060)
addappid(368061)
addappid(372510)
addappid(372511)
addappid(372512)
addappid(373560)
addappid(376270)
addappid(376340)
addappid(380910)
addappid(384220)
addappid(384221)
addappid(384222)
addappid(384223)
addappid(384224)
addappid(384225)
addappid(384226)
addappid(384227)
addappid(384228)
addappid(384229)
-- Game: addappid(358090)

-- MAIN APP DEPOTS / PACKAGES
addappid(358091, 1, "a2f4e37104219c120d58480418b9d2417af847bb601e24615ece68a2e223fbe8")
