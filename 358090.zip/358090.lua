-- Lua provided by RyzenAPI
-- Game: D4: Dark Dreams Don’t Die -Season One-

-- MAIN APPLICATION
addappid(358090)
addappid(367590)
addappid(367591)
addappid(367592)
addappid(368060)
addappid(368061)
addappid(372510)
addappid(372511)
addappid(372512)
addappid(373560)
addappid(376270)
addappid(376340)
addappid(380910)
addappid(384220)
addappid(384221)
addappid(384222)
addappid(384223)
addappid(384224)
addappid(384225)
addappid(384226)
addappid(384227)
addappid(384228)
addappid(384229)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(358091, 1, "a2f4e37104219c120d58480418b9d2417af847bb601e24615ece68a2e223fbe8")

