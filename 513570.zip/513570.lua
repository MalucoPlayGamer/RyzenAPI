-- Lua provided by RyzenAPI
-- Game: AppID 513570

-- MAIN APPLICATION
addappid(513570)
-- Game: addappid(513570)

-- MAIN APP DEPOTS / PACKAGES
addappid(513571, 1, "7a89e5e710a3a8cc1051677255be0018e66a953185cf5495f230fcff684f482f")
