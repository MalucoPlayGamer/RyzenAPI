-- Lua provided by RyzenAPI
-- Game: addappid(2223150)

-- MAIN APPLICATION
addappid(2223150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223151, 1, "46395eaeeb7f22a036abddd9b322b854736d68453d88291dab66976a3b410646")
