-- Lua provided by RyzenAPI
-- Game: 1463160

-- MAIN APPLICATION
addappid(1463160)
-- Game: addappid(1463160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463161, 1, "7f95495d92ceb8d8b85dc1ddb9a214517a4ad8a5a30bfb3afc6f9d5ab87be0ea")
