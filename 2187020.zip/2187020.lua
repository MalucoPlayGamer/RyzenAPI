-- Lua provided by RyzenAPI
-- Game: Personal Chef to the Stars Adults Only 18+ Patch

-- MAIN APPLICATION
addappid(2187020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187020,0,"bfbc5b1d45045257ba5ab38458a57babd4c6c3be02fb91c15fcb49786967d7fc")

