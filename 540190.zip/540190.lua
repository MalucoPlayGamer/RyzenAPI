-- Lua provided by RyzenAPI
-- Game: Tetropunk

-- MAIN APPLICATION
addappid(540190)

-- MAIN APP DEPOTS / PACKAGES
addappid(540191, 1, "9400b1c37a1ba47bb6fc2b2ac6f2c2ac1cc62b3484581b12fa5606acc46bd37a")
