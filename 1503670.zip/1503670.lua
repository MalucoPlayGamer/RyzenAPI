-- Lua provided by RyzenAPI
-- Game: addappid(1503670)

-- MAIN APPLICATION
addappid(1503670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503671, 1, "94879713ab4aa8c2d51d1f30ce362836adf09a6a95e27c178857d01c0acab3b4")
