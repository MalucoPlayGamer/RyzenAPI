-- Lua provided by RyzenAPI
-- Game: Kajun's Lucid Room

-- MAIN APPLICATION
addappid(2957830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957831, 1, "cf170c9f188faa422330bbd7815ea19d09cf289e4bf5c60bd3e80b5295fed978")

