-- Lua provided by RyzenAPI
-- Game: addappid(937860)

-- MAIN APPLICATION
addappid(937860)
addappid(1230910)

-- MAIN APP DEPOTS / PACKAGES
addappid(937861, 1, "9a3a18bfc05291757f29c0d1637e3417ee14005ef314ad7f00ce64910f5f7ab2")
addappid(937862, 1, "e6c5f4e6ce3e9abfd0cff3fbafc885757e6b3db209981302189cf6f522f5c8ec")
addappid(937865, 1, "3108d6cafae84db57474357e29134ad2e0b1401700888f24a164ee8874f6f7b6")
