-- Lua provided by RyzenAPI
-- Game: Poly Jigsaw: Butterflies

-- MAIN APPLICATION
addappid(2375560)
-- Game: addappid(2375560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375561, 1, "e001aeed572131d2740045c404cbba0723e54b5d77b49c37135a79196455ba6f")
