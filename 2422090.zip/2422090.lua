-- Lua provided by RyzenAPI
-- Game: Treasure Chest Clicker

-- MAIN APPLICATION
addappid(2422090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422091, 1, "ad9ed584128a94920885d956053243efdf18d6375079da485b9870b2675f4f70")
