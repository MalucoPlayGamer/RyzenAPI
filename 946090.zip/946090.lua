-- Lua provided by RyzenAPI
-- Game: Hentai Neighbors

-- MAIN APPLICATION
addappid(946090)

-- MAIN APP DEPOTS / PACKAGES
addappid(946091, 1, "7194fde0727de02d9e262b931451a209cce7f627bb6ccc47a2f78910d84b3ad4")
addappid(973750, 0, "94960baaaaab63e6a5337f5ae48afcb86b817158d3aaba4a7f79d619bd5cfc20")

