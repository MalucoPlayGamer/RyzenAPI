-- Lua provided by RyzenAPI
-- Game: Game: The Sojourn

-- MAIN APPLICATION
addappid(794960)
-- Game: addappid(794960)

-- MAIN APP DEPOTS / PACKAGES
addappid(794961, 1, "d6752444bdc33b033712d98e7c5ffc7ec44cc5befe3011b412d32af3165c3486")
addappid(1396270, 0, "6725fee2aa967c0a0ab3c04c5efa7e7e7028b1ce64b9b8b66e964a44897a67fb")
