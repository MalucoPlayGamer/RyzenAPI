-- Lua provided by RyzenAPI
-- Game: The Sojourn

-- MAIN APPLICATION
addappid(794960)

-- MAIN APP DEPOTS / PACKAGES
addappid(794961, 1, "d6752444bdc33b033712d98e7c5ffc7ec44cc5befe3011b412d32af3165c3486")
addappid(1396270, 0, "6725fee2aa967c0a0ab3c04c5efa7e7e7028b1ce64b9b8b66e964a44897a67fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
