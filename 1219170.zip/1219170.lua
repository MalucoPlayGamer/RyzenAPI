-- Lua provided by RyzenAPI
-- Game: Mayhem Masters

-- MAIN APPLICATION
addappid(1219170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219171, 1, "7a72fb5e2f49d0d6f2b32fbd1249180d830e5fea985a98da888442bd64f16d6d")
