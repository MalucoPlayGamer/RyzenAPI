-- Lua provided by SkyAPI 
-- Game: Mayhem Masters
addappid(1219170)
addappid(1219171, 1, "7a72fb5e2f49d0d6f2b32fbd1249180d830e5fea985a98da888442bd64f16d6d")
