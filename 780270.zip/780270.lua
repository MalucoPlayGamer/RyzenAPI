-- Lua provided by RyzenAPI
-- Game: Brimstone Brawlers

-- MAIN APPLICATION
addappid(780270)
addappid(1338700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(780271, 1, "8f652a733fa91fe371f377fb815351c3afd5966da0e824df59cd41262e56375c")
