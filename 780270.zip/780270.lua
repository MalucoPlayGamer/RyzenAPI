-- Lua provided by SkyAPI 
-- Game: AppID 780270
addappid(780270)
addappid(780271, 1, "8f652a733fa91fe371f377fb815351c3afd5966da0e824df59cd41262e56375c")
