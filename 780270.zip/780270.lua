-- Lua provided by RyzenAPI
-- Game: AppID 780270

-- MAIN APPLICATION
addappid(780270)
-- Game: addappid(780270)

-- MAIN APP DEPOTS / PACKAGES
addappid(780271, 1, "8f652a733fa91fe371f377fb815351c3afd5966da0e824df59cd41262e56375c")
