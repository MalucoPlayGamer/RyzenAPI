-- Lua provided by RyzenAPI
-- Game: Game: The Unicorn Princess

-- MAIN APPLICATION
addappid(970940)
-- Game: addappid(970940)

-- MAIN APP DEPOTS / PACKAGES
addappid(970941, 1, "bb586ef038507bcd9e357f157ebcaa3b5107bbc92b86a7ede129e5b93c947ead")
