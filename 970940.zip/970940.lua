-- Lua provided by RyzenAPI
-- Game: The Unicorn Princess

-- MAIN APPLICATION
addappid(970940)

-- MAIN APP DEPOTS / PACKAGES
addappid(970941, 1, "bb586ef038507bcd9e357f157ebcaa3b5107bbc92b86a7ede129e5b93c947ead")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
