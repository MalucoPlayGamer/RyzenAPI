-- Lua provided by RyzenAPI
-- Game: BioShock Remastered

-- MAIN APPLICATION
addappid(409710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409711, 1, "bd65f2941dcca212b3647a1ef093d35794fba9e1874789af52296830e5753e74")
addappid(409712, 1, "861974161720d0447dbcaf161218365bb3dade2b264871a9dd9b8a3fb10377e4")
addappid(409713, 1, "5726f9ecc0a96c7591d3bcadf845fa8dcfcc84a94b22740f7029a46a64297544")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")

