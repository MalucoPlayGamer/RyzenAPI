-- Lua provided by RyzenAPI
-- Game: Game: Rack and Slay

-- MAIN APPLICATION
addappid(2311990)
-- Game: addappid(2311990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311991, 1, "a1089db3ed442c9b88b356f8239c865d483c2ea8ecacb7da190b80937d805ae7")
