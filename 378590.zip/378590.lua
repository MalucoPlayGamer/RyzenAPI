-- Lua provided by RyzenAPI
-- Game: Forest Warrior

-- MAIN APPLICATION
addappid(378590)

-- MAIN APP DEPOTS / PACKAGES
addappid(378591, 1, "af9491ce5eee2d1fe256ea2421c1da3a956560a3cf81ccf622fe0252f02f2088")

