-- Lua provided by RyzenAPI
-- Game: AppID 695650

-- MAIN APPLICATION
addappid(695650)
-- Game: addappid(695650)

-- MAIN APP DEPOTS / PACKAGES
addappid(695651, 1, "5133c7f69f62f23c3c9826b27574eedd500b6539e1f21de3711c5d50841c7177")
