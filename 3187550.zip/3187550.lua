-- Lua provided by RyzenAPI
-- Game: Game: Cape Hideous

-- MAIN APPLICATION
addappid(3187550)
-- Game: addappid(3187550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3187551, 1, "04c389c0f32d71cf8f20165556a54128fa453654e7b970eefef9275e9aad7877")
