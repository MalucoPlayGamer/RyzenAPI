-- Lua provided by RyzenAPI
-- Game: Fading Reality

-- MAIN APPLICATION
addappid(4730570) -- Fading Reality

-- MAIN APP DEPOTS / PACKAGES
addappid(4730571, 1, "c6dfb6efe0128442275a5943ec2d6e18f360db23e3692b0e49356ae6481229ef") -- Depot 4730571
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
