-- Lua provided by RyzenAPI
-- Game: 1245040

-- MAIN APPLICATION
addappid(1245040)
-- Game: addappid(1245040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245041, 1, "f8677dc74f56e4298f5848dc0aac9ac0f20c7c8dea3fede04b8fa54be7a15d71")
