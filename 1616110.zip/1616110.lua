-- Lua provided by RyzenAPI
-- Game: Glitch Busters: Stuck On You

-- MAIN APPLICATION
addappid(1616110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616111, 1, "ded45656e281eb26147fd93767ccf77eb0bd359f1f613a9607e814df49d0e474")

