-- Lua provided by RyzenAPI
-- Game: Carly and the Reaperman - Escape from the Underworld

-- MAIN APPLICATION
addappid(547480)

-- MAIN APP DEPOTS / PACKAGES
addappid(547481, 1, "dae7ec22fe7def4c873fa6a38f1b076195ae027d9c9864a24ddda568730dc520")

