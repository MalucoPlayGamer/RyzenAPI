-- Lua provided by SkyAPI 
-- Game: Natal Perdido
addappid(1957100)
addappid(1957101, 1, "1541c5ba8767f428d4a3f6339d7a9166cde99c346bc17d16b1f4944f2fe16a1e")
addappid(1957102, 1, "4b21cc24ec8117d571c86299fb4fd15edd9be5589fb0e9f79bf9e6d3785854de")
