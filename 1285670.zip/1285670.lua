-- Lua provided by RyzenAPI
-- Game: Post Void

-- MAIN APPLICATION
addappid(1285670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285671, 1, "1f10daaab6c8c2f531459d76a7391456675dfc3daf564662d44506d361b7540b")

