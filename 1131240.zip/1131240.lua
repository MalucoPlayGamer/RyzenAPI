-- Lua provided by RyzenAPI
-- Game: addappid(1131240)

-- MAIN APPLICATION
addappid(1131240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131241, 1, "b935469609aac28128e8ea459f59dbeb70e82ad4b618af0f8567831ea5bf5f72")
