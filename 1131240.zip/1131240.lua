-- Lua provided by RyzenAPI
-- Game: Dungeons of Edera

-- MAIN APPLICATION
addappid(1131240)
addappid(1980200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1131241, 1, "b935469609aac28128e8ea459f59dbeb70e82ad4b618af0f8567831ea5bf5f72")
