-- Lua provided by RyzenAPI 
-- Game: AppID 771920
addappid(771920)
addappid(771921, 1, "f3daf1cad842e8f5e2ac85ca7d9b6f4c49304a4903c762e2d95e6558135570d2")
