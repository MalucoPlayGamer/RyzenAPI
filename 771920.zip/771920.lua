-- Lua provided by RyzenAPI
-- Game: AppID 771920

-- MAIN APPLICATION
addappid(771920)
addappid(868170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(771921, 1, "f3daf1cad842e8f5e2ac85ca7d9b6f4c49304a4903c762e2d95e6558135570d2")

