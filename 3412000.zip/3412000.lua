-- Lua provided by RyzenAPI
-- Game: Liminal Department

-- MAIN APPLICATION
addappid(3412000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3412001, 1, "dee935b626ec4082fbc1d2d4e8503da6ed870e0f50f83f418e03eca24d0524b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
