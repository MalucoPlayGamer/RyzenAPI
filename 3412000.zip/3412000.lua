-- Lua provided by RyzenAPI
-- Game: Liminal Department

-- MAIN APPLICATION
addappid(3412000)
-- Game: addappid(3412000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3412001, 1, "dee935b626ec4082fbc1d2d4e8503da6ed870e0f50f83f418e03eca24d0524b1")
