-- Lua provided by RyzenAPI 
-- Game: LIMSCAPE DEMO
addappid(3275300)
addappid(3275301, 1, "ea6448f77bd6e7cdab3d51211b1143e515176ce34f9fe3f7dff992acc70f21da")
