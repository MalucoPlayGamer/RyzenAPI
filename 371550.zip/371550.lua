-- Lua provided by RyzenAPI
-- Game: 371550

-- MAIN APPLICATION
addappid(371550)
-- Game: addappid(371550)

-- MAIN APP DEPOTS / PACKAGES
addappid(371551, 1, "8616551a9e7151229dd074d7fad31847f529ceb12eecaaf755adaf5101c1af2b")
