-- Lua provided by RyzenAPI
-- Game: addappid(1019993)

-- MAIN APPLICATION
addappid(1019993)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019993,0,"8ccf5a72f3fb6b44aa524d77503779485feded804c45b63f6c11ea0cfb105568")
