-- Lua provided by RyzenAPI
-- Game: コイカツ！ / Koikatsu Party - 拡張パック After Party

-- MAIN APPLICATION
addappid(1485180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485180,0,"c01385d129651901af75550a75641424e4224b75b69ea8b3c93ecd64c63be19b")

