-- Lua provided by RyzenAPI
-- Game: addappid(2659900)

-- MAIN APPLICATION
addappid(2659900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659901, 1, "948b537e16b1f7f17071329983f2d3d57c5cde71d1a8a34e50dafc71afc03ae7")
addappid(2659902, 1, "fca91fc5be04e1634c30f493a61926d74a97cfadd1d5f8cb9c64bcecdfba11a6")
