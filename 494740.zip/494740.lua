-- Lua provided by RyzenAPI
-- Game: AppID 494740

-- MAIN APPLICATION
addappid(494740)
-- Game: addappid(494740)

-- MAIN APP DEPOTS / PACKAGES
addappid(494741, 1, "cfab80be9e9b8c98dd6373c0a2d91f654746ba8992b4ff8561bca56cb93092b3")
