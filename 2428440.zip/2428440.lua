-- Lua provided by RyzenAPI
-- Game: addappid(2428440)

-- MAIN APPLICATION
addappid(2428440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428441, 1, "e7b52e62979bb2060594640224244f19cda0d1b3b4bb53d2990bdabc50e8c641")
