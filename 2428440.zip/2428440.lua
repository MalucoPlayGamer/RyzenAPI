-- Lua provided by SkyAPI 
-- Game: New Day
addappid(2428440)
addappid(2428441, 1, "e7b52e62979bb2060594640224244f19cda0d1b3b4bb53d2990bdabc50e8c641")
