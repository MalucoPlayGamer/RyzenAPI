-- Lua provided by RyzenAPI
-- Game: Drink And Girls

-- MAIN APPLICATION
addappid(2357040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357041, 1, "087a01a2526bb89b62bd767d91d047999bba2d4d6c10a46f47c06be9fa86cc70")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2419070)
