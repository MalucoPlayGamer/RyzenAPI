-- Lua provided by RyzenAPI
-- Game: Clawed

-- MAIN APPLICATION
addappid(3394840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3394841,0,"34e22bdc0f2bf98f9a7158ae217d5327977e69ee3e731fda1b4bc2639e4f2674")

