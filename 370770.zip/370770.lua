-- Lua provided by RyzenAPI
-- Game: AppID 370770

-- MAIN APPLICATION
addappid(370770)

-- MAIN APP DEPOTS / PACKAGES
addappid(370771, 1, "102d6e73cb018b2180ae57cb958b6f300739dc94b1813c622e44053685caf679")
addappid(370772, 1, "32189aac322493594911f089e4c580aed068989c153b310ed03f4dd953aeceab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(429310)
addappid(605690)
addappid(864750)
