-- Lua provided by RyzenAPI
-- Game: The Chronicles of Quiver Dick

-- MAIN APPLICATION
addappid(846880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(846881, 1, "8d8f95997e5ed58d7bef4d449eeec1da05a6d9d3c734eb6162c22d9368e7d69b")

