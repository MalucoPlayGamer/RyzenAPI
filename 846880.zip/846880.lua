-- Lua provided by RyzenAPI
-- Game: addappid(846880)

-- MAIN APPLICATION
addappid(846880)

-- MAIN APP DEPOTS / PACKAGES
addappid(846881, 1, "8d8f95997e5ed58d7bef4d449eeec1da05a6d9d3c734eb6162c22d9368e7d69b")
