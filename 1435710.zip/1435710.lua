-- Lua provided by RyzenAPI
-- Game: Game: AppID 1435710

-- MAIN APPLICATION
addappid(1435710)
-- Game: addappid(1435710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435711, 1, "4f85a4c7933c5da11eba6c9f3c386d8388857a1656cb3e49985c22fc479fc0ff")
