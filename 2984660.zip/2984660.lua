-- Lua provided by RyzenAPI
-- Game: He is Coming Demo

-- MAIN APPLICATION
addappid(2984660)
-- Game: addappid(2984660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984661, 1, "55481fe24966d7d8f903155a7c1a0c2b76bbca6c75a0e4493c24e408a85b1393")
