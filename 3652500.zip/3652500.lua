-- Lua provided by RyzenAPI
-- Game: 3652500

-- MAIN APPLICATION
addappid(3652500)
-- Game: addappid(3652500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652501, 1, "57a851db2d8fcbeac2e2d266d4b293a0ef928d7ecff75828d3cca667447bac65")
