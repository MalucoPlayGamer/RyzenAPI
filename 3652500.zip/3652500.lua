-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Friendly and Slightly Naughty Woman GP-02

-- MAIN APPLICATION
addappid(3652500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652501, 1, "57a851db2d8fcbeac2e2d266d4b293a0ef928d7ecff75828d3cca667447bac65")
