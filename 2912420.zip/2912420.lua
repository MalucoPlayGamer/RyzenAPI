-- Lua provided by RyzenAPI
-- Game: Game: Pals Go Only Up!

-- MAIN APPLICATION
addappid(2912420)
-- Game: addappid(2912420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2912421, 1, "f183fdd753a8170073b054518553e2def98e77a2bb21803008f180b26fed6209")
