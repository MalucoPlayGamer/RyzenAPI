-- Lua provided by RyzenAPI
-- Game: Pals Go Only Up!

-- MAIN APPLICATION
addappid(2912420)
addappid(3689730)
addappid(3689740)
addappid(3689750)
addappid(3689760)
addappid(3689770)
addappid(3689780)
addappid(3689790)
addappid(3689800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2912421, 1, "f183fdd753a8170073b054518553e2def98e77a2bb21803008f180b26fed6209")

