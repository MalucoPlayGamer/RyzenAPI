-- Lua provided by RyzenAPI
-- Game: Jixxaw

-- MAIN APPLICATION
addappid(1564830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1564831, 1, "7e522b91dfdf791cd98e00e6a033f58eee81eb8e7e19c5456662cffe52a11ce2")

