-- Lua provided by RyzenAPI
-- Game: 1564830

-- MAIN APPLICATION
addappid(1564830)
-- Game: addappid(1564830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564831, 1, "7e522b91dfdf791cd98e00e6a033f58eee81eb8e7e19c5456662cffe52a11ce2")
