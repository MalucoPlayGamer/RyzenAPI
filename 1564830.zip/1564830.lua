-- Lua provided by RyzenAPI 
-- Game: AppID 1564830
addappid(1564830)
addappid(1564831, 1, "7e522b91dfdf791cd98e00e6a033f58eee81eb8e7e19c5456662cffe52a11ce2")
