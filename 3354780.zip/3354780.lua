-- Lua provided by SkyAPI 
-- Game: The Scouring Demo
addappid(3354780)
addappid(3354781, 1, "f4a218054a7933e68b0379db3453de71d75d431d41c73e98e1cc122caba944d4")
