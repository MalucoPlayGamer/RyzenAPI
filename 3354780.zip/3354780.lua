-- Lua provided by RyzenAPI
-- Game: Game: The Scouring Demo

-- MAIN APPLICATION
addappid(3354780)
-- Game: addappid(3354780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354781, 1, "f4a218054a7933e68b0379db3453de71d75d431d41c73e98e1cc122caba944d4")
