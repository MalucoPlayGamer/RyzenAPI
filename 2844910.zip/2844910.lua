-- Lua provided by RyzenAPI
-- Game: Interior Designer

-- MAIN APPLICATION
addappid(2844910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2844911, 1, "27d50a2fca09dc3649747b3c66557722495294ccbc3a7fb7afe0fa50b6515009")

