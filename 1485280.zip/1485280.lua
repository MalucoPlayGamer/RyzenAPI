-- Lua provided by RyzenAPI 
-- Game: Demian: The Ritual
addappid(1485280)
addappid(1485281, 1, "76945173814453616780cb30f8b503faef88ca34e72e8fc63aec24ec3d0b309e")
