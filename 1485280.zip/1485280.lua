-- Lua provided by RyzenAPI
-- Game: Game: Demian: The Ritual

-- MAIN APPLICATION
addappid(1485280)
-- Game: addappid(1485280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485281, 1, "76945173814453616780cb30f8b503faef88ca34e72e8fc63aec24ec3d0b309e")
