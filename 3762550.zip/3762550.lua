-- Lua provided by RyzenAPI
-- Game: 3762550

-- MAIN APPLICATION
addappid(3762550)
-- Game: addappid(3762550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3762551, 1, "bd117b3c71f5677047fba24c3718c6f55a4ba03e9c2219df6576e38a44c040fd")
