-- Lua provided by RyzenAPI
-- Game: Game: AppID 960360

-- MAIN APPLICATION
addappid(960360)
-- Game: addappid(960360)

-- MAIN APP DEPOTS / PACKAGES
addappid(960361, 1, "183632e23e5fddc7d0b3d77a4e1828bf9588c0f2cffbac47a74345ca7cbb8ea7")
