-- Lua provided by RyzenAPI
-- Game: Yuzi Lims: Hentai

-- MAIN APPLICATION
addappid(960360)

-- MAIN APP DEPOTS / PACKAGES
addappid(960361,0,"183632e23e5fddc7d0b3d77a4e1828bf9588c0f2cffbac47a74345ca7cbb8ea7")
addappid(966150,0,"9ff5e3072b4ec4b28d76a59dd50fd2b1df3db621c7cfd18b5e72be2d44f411de")

