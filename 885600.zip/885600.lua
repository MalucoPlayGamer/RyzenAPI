-- Lua provided by RyzenAPI
-- Game: Fairyland: Blackberry Warrior

-- MAIN APPLICATION
addappid(885600)

-- MAIN APP DEPOTS / PACKAGES
addappid(885601, 1, "fa5bcdc3fc9303886f4ec791d5835027256a7f6ec59377de350998dc4e00987b")
