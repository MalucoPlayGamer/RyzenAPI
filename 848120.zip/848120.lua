-- Lua provided by RyzenAPI
-- Game: Terror World

-- MAIN APPLICATION
addappid(848120)

-- MAIN APP DEPOTS / PACKAGES
addappid(848121,0,"e5ad41fccaca488332b9582e600649f6a4463c18eca25f277fd25008418a9c4c")

