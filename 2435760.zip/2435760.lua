-- Lua provided by RyzenAPI
-- Game: Grand Emprise: Prologue

-- MAIN APPLICATION
addappid(2435760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435761, 1, "02f2b3c6d26b0e89fed34f8586ee1c07d82d2429b22abd08d97fe1c0cbb32f15")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2437590)
addappid(2437591)
