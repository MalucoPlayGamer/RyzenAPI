-- Lua provided by RyzenAPI
-- Game: addappid(2435760)

-- MAIN APPLICATION
addappid(2435760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435761, 1, "02f2b3c6d26b0e89fed34f8586ee1c07d82d2429b22abd08d97fe1c0cbb32f15")
