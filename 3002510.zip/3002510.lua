-- Lua provided by RyzenAPI
-- Game: REPOSE

-- MAIN APPLICATION
addappid(3002510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002511, 1, "58263441144fd57d7d87f84b259a70b7d285e21cab17264be1121a26d9961166")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3635750)
