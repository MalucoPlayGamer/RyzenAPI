-- Lua provided by RyzenAPI
-- Game: Space Climber

-- MAIN APPLICATION
addappid(1193520)
-- Game: addappid(1193520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193521, 1, "88dc91aeda66588698d6b74be0a76437189fe64f2a99799ad5b21538981c8e1c")
