-- Lua provided by RyzenAPI
-- Game: Dustoff Heli Rescue 2

-- MAIN APPLICATION
addappid(553690)
-- Game: addappid(553690)

-- MAIN APP DEPOTS / PACKAGES
addappid(553691, 1, "51369609f650c4905c34ecb465ee8b3320434b50e0f6bf5cb323360bde438ca9")
