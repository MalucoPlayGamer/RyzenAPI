-- Lua provided by RyzenAPI
-- Game: DIG IT! - A Digger Simulator

-- MAIN APPLICATION
addappid(311910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(311911, 1, "4efa09afd46084d2b09d68a21e8e59af4e1e043b054f1363d5f70faf827b781f")

