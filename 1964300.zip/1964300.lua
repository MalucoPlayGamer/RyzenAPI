-- Lua provided by RyzenAPI
-- Game: PongBreak

-- MAIN APPLICATION
addappid(1964300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964301, 1, "4a6e292563af7ecff066445ebca7c2d11d1cb50fd21b888b6fc1dd24cc46b81d")

