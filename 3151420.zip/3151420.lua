-- Lua provided by RyzenAPI
-- Game: Game: Mystic Explorer

-- MAIN APPLICATION
addappid(3151420)
-- Game: addappid(3151420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151421, 1, "e1da9f717b348cbed87bd964e438ea70a24d5ac9f81e9f83fc1c7fc6b78bc725")
