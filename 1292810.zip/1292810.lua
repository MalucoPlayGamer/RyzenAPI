-- Lua provided by SkyAPI 
-- Game: AppID 1292810
addappid(1292810)
addappid(1292811, 1, "3ba75b87840a4346136f71b0068a36022c8851feac0410da0a6f15d3411c414c")
