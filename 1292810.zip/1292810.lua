-- Lua provided by RyzenAPI
-- Game: Game: AppID 1292810

-- MAIN APPLICATION
addappid(1292810)
-- Game: addappid(1292810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292811, 1, "3ba75b87840a4346136f71b0068a36022c8851feac0410da0a6f15d3411c414c")
