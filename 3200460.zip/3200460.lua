-- Lua provided by RyzenAPI
-- Game: Greed Stays Home

-- MAIN APPLICATION
addappid(3200460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200461, 1, "8929d43761f7ac97eac9005f34e14c9ee13877c657fa8732c2c7fe1e40c091b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
