-- Lua provided by RyzenAPI
-- Game: Galimulator

-- MAIN APPLICATION
addappid(808100)

-- MAIN APP DEPOTS / PACKAGES
addappid(808101, 1, "8c1b2da383dc2b0b271ca7d8aa45736df37b6f874c8d72af3b4a1aacf558a087")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
