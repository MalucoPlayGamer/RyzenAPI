-- Lua provided by RyzenAPI
-- Game: addappid(3541220)

-- MAIN APPLICATION
addappid(3541220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3541220,0,"d13776f5127fd1a47386057cff144de676ad3127ffb16a81d9bf083c9028e6f4")
