-- Lua provided by RyzenAPI
-- Game: Game: 紫塞秋风 新修版Demo

-- MAIN APPLICATION
addappid(2799630)
-- Game: addappid(2799630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799631, 1, "7ae9e3b889fcc37048969386270c8249f87780307e8f5e270ddf80c7b0d4efdc")
