-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - SRPG Gear MZ - Tactical Battle system for RPG Maker MZ

-- MAIN APPLICATION
addappid(2811870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811870,0,"af2a9045240811eb8720a907bfa0a799066ea961bc3b8081098a1be0186e41d0")
