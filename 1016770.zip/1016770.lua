-- Lua provided by RyzenAPI
-- Game: AppID 1016770

-- MAIN APPLICATION
addappid(1016770)
-- Game: addappid(1016770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016771, 1, "f8d5ece1ca3b94f06a8ca7aefde14d6893305bf57557cb696f6218323633a0bf")
