-- Lua provided by RyzenAPI
-- Game: Pathologic Classic HD

-- MAIN APPLICATION
addappid(384110)

-- MAIN APP DEPOTS / PACKAGES
addappid(384111, 1, "45712e323601c6d62cddb8da08be1df5afbe935289547787df13373a6285f3bf")
addappid(384112, 1, "7336c8781ad4e6b2addc59274d2728251c71a9c8f1a4a27ca9c908d4daecab2e")
addappid(384113, 1, "706b2272d5fc065229a4fd94178e96db554323e7685b234f7f7f1be2d80072b4")
addappid(384114, 1, "ba635a89d2275a3cf2791b06d5c3a1d34b47bb518f61dfbfffc25d6f680a2757")
addappid(384115, 1, "e583baa08fe4f33df495ae859d9bd3ab8b74e0e8a8083ccac036625ca283df6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
