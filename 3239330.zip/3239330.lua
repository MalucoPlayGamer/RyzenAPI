-- Lua provided by RyzenAPI
-- Game: 3239330

-- MAIN APPLICATION
addappid(3239330)
-- Game: addappid(3239330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239331, 1, "f7f8364cdfcd1140d266a5216d5044bb8fe77c08a9962bc36385290ee6026f7f")
