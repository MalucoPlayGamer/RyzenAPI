-- Lua provided by RyzenAPI
-- Game: Creepy Castle

-- MAIN APPLICATION
addappid(450440)
-- Game: addappid(450440)

-- MAIN APP DEPOTS / PACKAGES
addappid(450441, 1, "9dbfe920eb25ff9f9340d77ccb7b83365a197ecdbb441d857175bda7b0fd8cd6")
