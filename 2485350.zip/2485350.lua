-- Lua provided by RyzenAPI
-- Game: River Towns

-- MAIN APPLICATION
addappid(2485350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485351, 1, "01512fdc1de36a29217fd71dfac8a855c8acb5a787100b2ed3b7f0c23029b32d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
