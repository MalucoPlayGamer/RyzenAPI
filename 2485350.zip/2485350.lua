-- Lua provided by SkyAPI 
-- Game: River Towns
addappid(2485350)
addappid(2485351, 1, "01512fdc1de36a29217fd71dfac8a855c8acb5a787100b2ed3b7f0c23029b32d")
