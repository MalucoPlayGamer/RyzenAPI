-- Lua provided by RyzenAPI
-- Game: addappid(2485350)

-- MAIN APPLICATION
addappid(2485350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485351, 1, "01512fdc1de36a29217fd71dfac8a855c8acb5a787100b2ed3b7f0c23029b32d")
