-- Lua provided by RyzenAPI
-- Game: Game: Balsa Model Flight Simulator

-- MAIN APPLICATION
addappid(977920)
-- Game: addappid(977920)

-- MAIN APP DEPOTS / PACKAGES
addappid(977921, 1, "01a65f42a2de9cf169d04a6511a864e427cab59faa9e6c9f9493563482434cd1")
