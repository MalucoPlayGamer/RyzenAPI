-- Lua provided by RyzenAPI
-- Game: Game Master Engine

-- MAIN APPLICATION
addappid(1451680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451681, 1, "cfe6da64413518338e760a8cdfde322bdbf1e7b2423a04029067f21ca1dcb3df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2462280)
addappid(2748210)
addappid(3098940)
