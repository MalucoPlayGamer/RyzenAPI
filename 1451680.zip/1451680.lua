-- Lua provided by RyzenAPI
-- Game: addappid(1451680)

-- MAIN APPLICATION
addappid(1451680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451681, 1, "cfe6da64413518338e760a8cdfde322bdbf1e7b2423a04029067f21ca1dcb3df")
