-- Lua provided by RyzenAPI
-- Game: addappid(1231940)

-- MAIN APPLICATION
addappid(1231940)
addappid(1309064)
addappid(1309065)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231941, 1, "c4f2eef8edc98c8b6ff5048ef85a9158755065b0950ff31bafff8af2935052d5")
