-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization VI Development Assets

-- MAIN APPLICATION
addappid(597260)

-- MAIN APP DEPOTS / PACKAGES
addappid(597261, 1, "ee2c8e57b419e6e548e0d021b8b8757e35461d255085d1b0304238bae7273e24")

