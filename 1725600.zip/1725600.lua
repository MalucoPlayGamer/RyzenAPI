-- Lua provided by RyzenAPI
-- Game: 1725600

-- MAIN APPLICATION
addappid(1725600)
-- Game: addappid(1725600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725601, 1, "ce810eacdceec69c81a73e7057f8ec61c18089e144771d53824841932b32da21")
