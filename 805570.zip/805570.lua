-- Lua provided by RyzenAPI 
-- Game: AppID 805570
addappid(805570)
addappid(805571, 1, "33edd8d8e47271b41c8830188b3045059097ff0ee5841538b06e714b7fd9fe0c")
