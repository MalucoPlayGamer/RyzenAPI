-- Lua provided by RyzenAPI
-- Game: Game: Are You Smarter Than A 5th Grader

-- MAIN APPLICATION
addappid(1521160)
addappid(1696640)
-- Game: addappid(1521160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521161, 1, "7385945ee6b8e74be4b813dd4e2f900b0d7b38986c0abfcd20b9d323d04921d5")
