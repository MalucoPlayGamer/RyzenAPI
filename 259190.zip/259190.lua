-- Lua provided by RyzenAPI
-- Game: Alone in the Dark: The New Nightmare

-- MAIN APPLICATION
addappid(259190)

-- MAIN APP DEPOTS / PACKAGES
addappid(259191, 1, "2e5aef10fe649f7ddeeabcc8dac60977bd4f8c43fd4b0bf88845418dbccb25d4")
