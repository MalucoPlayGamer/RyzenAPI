-- Lua provided by RyzenAPI
-- Game: addappid(841167)

-- MAIN APPLICATION
addappid(841167)

-- MAIN APP DEPOTS / PACKAGES
addappid(841167,0,"62737b3507f480a57fa50ceb142c676154e87fa33fa89d365f47ce17d8d97e2b")
