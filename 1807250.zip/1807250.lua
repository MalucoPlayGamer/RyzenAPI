-- Lua provided by RyzenAPI
-- Game: 1807250

-- MAIN APPLICATION
addappid(1807250)
-- Game: addappid(1807250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807251, 1, "c35a3c5ca5d06b8d7be10e501c1dade028b775a11eda76f613c1ad19172a4a88")
