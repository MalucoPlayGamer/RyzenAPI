-- Lua provided by RyzenAPI
-- Game: Hooklings

-- MAIN APPLICATION
addappid(1018240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1018241, 1, "2da7fbb7b136d6c15ebff5aa27566f8643695b7fd095b48796516e28fccc0597")
