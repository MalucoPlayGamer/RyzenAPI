-- Lua provided by RyzenAPI
-- Game: addappid(1018240)

-- MAIN APPLICATION
addappid(1018240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018241, 1, "2da7fbb7b136d6c15ebff5aa27566f8643695b7fd095b48796516e28fccc0597")
