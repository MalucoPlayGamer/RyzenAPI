-- Lua provided by RyzenAPI
-- Game: Office Simulator

-- MAIN APPLICATION
addappid(3399040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399041, 1, "bba17d3ffb70540886373a19080470a5dff40502d30cfcd5e386b1a3474e42ff")

