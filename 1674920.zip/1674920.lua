-- Lua provided by SkyAPI 
-- Game: AppID 1674920
addappid(1674920)
addappid(1674921, 1, "b5853a28eefabc5c5aeab14987cbea90a10f1c1b9947455390d98d0febb67b89")
