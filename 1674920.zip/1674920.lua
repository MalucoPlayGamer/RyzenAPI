-- Lua provided by RyzenAPI
-- Game: 1674920

-- MAIN APPLICATION
addappid(1674920)
-- Game: addappid(1674920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674921, 1, "b5853a28eefabc5c5aeab14987cbea90a10f1c1b9947455390d98d0febb67b89")
