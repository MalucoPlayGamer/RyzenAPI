-- Lua provided by RyzenAPI
-- Game: Birth

-- MAIN APPLICATION
addappid(1889040)
addappid(1889041)
addappid(1889042)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889043,0,"385e466251c0fc4ccf5340854f344b7abdb84fb353bbcace34147faae0d45427")

