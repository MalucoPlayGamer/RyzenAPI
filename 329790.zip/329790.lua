-- Lua provided by RyzenAPI
-- Game: addappid(329790)

-- MAIN APPLICATION
addappid(228985)
addappid(329790)
addappid(329791)
addappid(329794)

-- MAIN APP DEPOTS / PACKAGES
addappid(329792,0,"68d64ddc52922a6faed6eff9aa29bdaca07dfc2506232ce6a89862288296e672")
addappid(329793,0,"8eda436aa91bc0e5df564482011bcd7b625e6a1db7ddf4206278be78cea67f5c")
addappid(329795,0,"b622f409a3217c25d87489fdc86126bc07737af690004d09b7d5ec0e6d24be4a")
addappid(329796,0,"bee7bbd0f71c7ced99612b00e948dc9ca018d4977f045d72b75e0c87cee2c7a6")
