-- Lua provided by RyzenAPI
-- Game: 2494540

-- MAIN APPLICATION
addappid(2494540)
-- Game: addappid(2494540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494541, 1, "6eea164c162e6b6f0ac393c9edf8c7aa4aaa808f44418e5d961a2f91ea6b8e8d")
