-- Lua provided by RyzenAPI
-- Game: Game: Geometry Hero

-- MAIN APPLICATION
addappid(1177080)
-- Game: addappid(1177080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177081, 1, "d1660483f246d0ec5f1688af99a78e3b62764c3432bece678721fce26cd424f3")
