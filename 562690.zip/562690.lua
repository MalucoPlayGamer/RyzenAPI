-- Lua provided by RyzenAPI
-- Game: Immersion

-- MAIN APPLICATION
addappid(562690)

-- MAIN APP DEPOTS / PACKAGES
addappid(562691, 1, "c2c5c3f9d0ff868d2275517b45639b6b23cdb16c14628c1fcfb7b6bbf5df09cb")

