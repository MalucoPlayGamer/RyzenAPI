-- Lua provided by RyzenAPI
-- Game: Cards, the Universe and Everything

-- MAIN APPLICATION
addappid(3411830)

