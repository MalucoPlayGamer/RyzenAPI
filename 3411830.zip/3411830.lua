-- Lua provided by RyzenAPI
-- Game: Cards, the Universe and Everything

-- MAIN APPLICATION
addappid(3411830)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3727070)
addappid(3731900)
addappid(3731910)
addappid(3731920)
