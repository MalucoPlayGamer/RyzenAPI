-- Lua provided by RyzenAPI 
-- Game: AppID 1091650
addappid(1091650)
addappid(1091651, 1, "25f63346464bfbfecc642590502b3bcc761a74dba41ca53792412e386a809c26")
