-- Lua provided by RyzenAPI
-- Game: 1091650

-- MAIN APPLICATION
addappid(1091650)
-- Game: addappid(1091650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091651, 1, "25f63346464bfbfecc642590502b3bcc761a74dba41ca53792412e386a809c26")
