-- Lua provided by RyzenAPI
-- Game: Beat Blast

-- MAIN APPLICATION
addappid(1072640)
-- Game: addappid(1072640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072641, 1, "75e863026846c2119356367fd2f8a053fb5f7b94f67050cfca3dfba1f6207f57")
