-- Lua provided by SkyAPI 
-- Game: TANKBOX
addappid(1637030)
addappid(1637031, 1, "3035d0b6428b3d85aa03034e4bc889e32b4e0aa55f83bd6d018d033d6d8de6b7")
