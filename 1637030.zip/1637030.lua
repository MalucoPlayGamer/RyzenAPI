-- Lua provided by RyzenAPI
-- Game: TANKBOX

-- MAIN APPLICATION
addappid(1637030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637031, 1, "3035d0b6428b3d85aa03034e4bc889e32b4e0aa55f83bd6d018d033d6d8de6b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
