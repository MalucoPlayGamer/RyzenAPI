-- Lua provided by RyzenAPI
-- Game: Timespinner

-- MAIN APPLICATION
addappid(368620)
addappid(950200)

-- MAIN APP DEPOTS / PACKAGES
addappid(368621, 1, "d40c334d01d2c0c9f74d30beabdc75ca5fd370f173c3143f01707a0814ac16d8")
addappid(368622, 1, "f8cd0858d04eaca0ade8d19ccf191c4c9a0041cd31c5ff2bc633428f515b2c80")
addappid(368623, 1, "656857d0d41e59eff09746b97dc9c8ea591745131c9fef8b04262be2addc77d7")
addappid(368624, 1, "a7317661a4d6304d6901fcc64f82be02f72b62f2529b0279d1ed43310677612a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
