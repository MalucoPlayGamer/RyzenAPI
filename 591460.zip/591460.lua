-- Lua provided by RyzenAPI
-- Game: Parkasaurus

-- MAIN APPLICATION
addappid(591460)

-- MAIN APP DEPOTS / PACKAGES
addappid(591461, 1, "fecec5a1bb11beaed5f93f92404793b769fa5913d436ad4a3da8a7868a52a271")
addappid(591462, 1, "cc70030d3dc4a120b24fbe251e9f825e0aa849652486a71cde751495677accd6")

