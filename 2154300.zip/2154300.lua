-- Lua provided by RyzenAPI
-- Game: CyberTown Demo

-- MAIN APPLICATION
addappid(2154300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154301, 1, "3c516d772ab0ef0c99c50c3f640f5ceb23ccb5d5132cc210f9bb8a88012cebe1")
