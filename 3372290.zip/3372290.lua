-- Lua provided by RyzenAPI
-- Game: Game: AppID 3372290

-- MAIN APPLICATION
addappid(3372290)
-- Game: addappid(3372290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372291, 1, "8fe472261d51ec3029c2b708f37a2fa96218875d6defbf377308c1823b4a5829")
