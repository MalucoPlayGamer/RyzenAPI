-- Lua provided by RyzenAPI
-- Game: Eximius: Seize the Frontline

-- MAIN APPLICATION
addappid(505740)
addappid(948140)
addappid(1576310)
addappid(1576311)
addappid(1576312)
addappid(1723520)
addappid(1723521)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505741, 1, "ae216fe11797106d35ecfb02882c3c9c1c7b1d435c7816b8bf5741bfe15962cd")

