-- Lua provided by SkyAPI 
-- Game: Eximius: Seize the Frontline
addappid(505740)
addappid(505741, 1, "ae216fe11797106d35ecfb02882c3c9c1c7b1d435c7816b8bf5741bfe15962cd")
