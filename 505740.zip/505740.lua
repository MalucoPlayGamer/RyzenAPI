-- Lua provided by RyzenAPI
-- Game: Eximius: Seize the Frontline

-- MAIN APPLICATION
addappid(505740)

-- MAIN APP DEPOTS / PACKAGES
addappid(505741, 1, "ae216fe11797106d35ecfb02882c3c9c1c7b1d435c7816b8bf5741bfe15962cd")
