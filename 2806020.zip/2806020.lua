-- Lua provided by RyzenAPI
-- Game: Game: AppID 2806020

-- MAIN APPLICATION
addappid(2806020)
-- Game: addappid(2806020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806021, 1, "50fe770d17df573254a5af316c310ac87bd4829d31829ed3af5d7a3a535e46f5")
