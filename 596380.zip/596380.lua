-- Lua provided by RyzenAPI
-- Game: Game: Coffee Crisis

-- MAIN APPLICATION
addappid(596380)
addappid(868140)
-- Game: addappid(596380)

-- MAIN APP DEPOTS / PACKAGES
addappid(596381, 1, "102f807f5abf2690ce3906c7b396b9cf3d6cf777595ad4702daf8b1f12678fb9")
