-- Lua provided by RyzenAPI
-- Game: Apocalyptic Vibes

-- MAIN APPLICATION
addappid(1840610)
-- Game: addappid(1840610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840611, 1, "33101ad41def159019c7fe11f3ef701889ca17731ab751b3eb03801c6ed68e2f")
addappid(1840612, 1, "0d89b87a696618ec71169d8f138865263bad5e0184af04a4520459384b18db36")
