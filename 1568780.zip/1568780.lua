-- Lua provided by RyzenAPI
-- Game: Return of the Obra Dinn - Soundtrack

-- MAIN APPLICATION
addappid(1568780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568781, 1, "45dfde18c2d7526007a204696de37ee7e4b92de733e38a4593789fccd0e99c0f")
addappid(1568782, 1, "77060bcc78351ea9bf83badad5fe8aa355d89b5f3ce588268244103db232fb33")
