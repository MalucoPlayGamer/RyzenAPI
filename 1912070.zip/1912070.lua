-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Mikazuki Munechika"

-- MAIN APPLICATION
addappid(1912070)
-- Game: addappid(1912070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912070,0,"732a36ec12249e17533b0f293bf260ae2d2e1821cac7222cfb2a4dbed6e09af0")
