-- Lua provided by RyzenAPI
-- Game: BUTCHER

-- MAIN APPLICATION
addappid(474210)

-- MAIN APP DEPOTS / PACKAGES
addappid(474211, 1, "f9c318ddeea0f2dd303648f9d74d529f15d14ecf9840936eff1bbb3e8a4066a2")
addappid(474212, 1, "3010a0255a6a71bf9158cd3932b656a343a11885205bafa0620028e7c6b4060c")
addappid(474213, 1, "4fa7ddb0c0fd1c488ec01141d99e0c4b5c3b8c1c782c0268978c472c2c1ce4f6")
addappid(474214, 1, "c36832e9cb8ab13d4a39b071af95fa0f2d4dda983d2575487e5b9002ca6a6c0e")
addappid(474217, 1, "cbd203de311f7d5e4fe595c8bd04d61317acfc06604d1dc72569487ec85ef1df")
addappid(474218, 1, "08f8cdcf6df75b78c095432ce87b59f5d51dbc9bf6ef14129afb557743a3934d")
addappid(555421, 0, "0b745123a90d90afb9ac00fb1ce225ad3dcf8566934de6b014799bcabd82a3b0")
addappid(555422, 0, "b69c09e759ddc88adb4e54c7f93018145f99777c40c11171e3d07ebea6287037")
addappid(555424, 0, "fedfe215707bfcd08bb46618c0d4b5ca0c7efcf7fa7e20ed73dda4c74653b38c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(555420)
