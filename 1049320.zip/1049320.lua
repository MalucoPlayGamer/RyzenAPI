-- Lua provided by RyzenAPI
-- Game: River City Girls

-- MAIN APPLICATION
addappid(1049320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049321, 1, "235fc755a2da44983fa14105b6cd9a5220a6ae37cf4fb2a81827f3f6657e8317")

