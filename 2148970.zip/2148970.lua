-- Lua provided by RyzenAPI
-- Game: Skygard Arena

-- MAIN APPLICATION
addappid(2148970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148971, 1, "ff7f26c2ddbabe592698e6a41a008683b2e3722004ed127abc699b2336ed2eb2")

