-- Lua provided by RyzenAPI
-- Game: Game: SOK MIN

-- MAIN APPLICATION
addappid(839340)
addappid(1741020)
-- Game: addappid(839340)

-- MAIN APP DEPOTS / PACKAGES
addappid(839341, 1, "83774d51cf8ef104f1eb1031ebd5ba36f6f7978dc7ee8bc87dadd1067134173d")
