-- Lua provided by RyzenAPI
-- Game: Game: Cute Girl 2

-- MAIN APPLICATION
addappid(1637750)
-- Game: addappid(1637750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637751, 1, "721fee9cb3f002440ab6a33958eb2a5f306f5b44a4f9482311d2c4d8c7819f12")
