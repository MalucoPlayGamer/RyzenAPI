-- Lua provided by RyzenAPI
-- Game: Clockwork

-- MAIN APPLICATION
addappid(509210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(509211,0,"784fce552f09493433e1d6e93d7b16e8845b3e4e7f475eda13ad4b002148fd15")

