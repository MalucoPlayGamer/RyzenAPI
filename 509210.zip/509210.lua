-- Lua provided by RyzenAPI
-- Game: Clockwork

-- MAIN APPLICATION
addappid(509210)

-- MAIN APP DEPOTS / PACKAGES
addappid(509211,0,"784fce552f09493433e1d6e93d7b16e8845b3e4e7f475eda13ad4b002148fd15")

