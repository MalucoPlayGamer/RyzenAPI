-- Lua provided by RyzenAPI
-- Game: AppID 1353850

-- MAIN APPLICATION
addappid(1353850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353851, 1, "3cb0af97806668a7ed67d0eda708f2b075c1c8cf5f23e430838e2afb70ae2a11")
