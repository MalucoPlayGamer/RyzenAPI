-- Lua provided by RyzenAPI
-- Game: 783780

-- MAIN APPLICATION
addappid(783780)
-- Game: addappid(783780)

-- MAIN APP DEPOTS / PACKAGES
addappid(783781, 1, "27ccb4801430135c5d867b37aa03c4ffea2f73787e8c06070ddf9a91ba412124")
