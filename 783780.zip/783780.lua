-- Lua provided by RyzenAPI
-- Game: HITMAN™: Sniper Assassin

-- MAIN APPLICATION
addappid(783780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(783781, 1, "27ccb4801430135c5d867b37aa03c4ffea2f73787e8c06070ddf9a91ba412124")
