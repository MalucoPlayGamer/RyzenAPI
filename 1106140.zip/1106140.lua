-- Lua provided by RyzenAPI
-- Game: 1106140

-- MAIN APPLICATION
addappid(1106140)
-- Game: addappid(1106140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106141, 1, "533a35754266b68a5adc5b04794bd173f8e88dd0041a2c0d93d00162ed3d001e")
