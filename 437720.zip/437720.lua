-- Lua provided by RyzenAPI
-- Game: Blossoms Bloom Brightest

-- MAIN APPLICATION
addappid(437720)

-- MAIN APP DEPOTS / PACKAGES
addappid(437721, 1, "cb29591944252f712a3a8655c6798c42b9399b7c082f915809954431dd7ac328")
