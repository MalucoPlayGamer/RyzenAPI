-- Lua provided by RyzenAPI
-- Game: Happy Z-Day

-- MAIN APPLICATION
addappid(1589260)
-- Game: addappid(1589260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589261, 1, "ef89cc52db0f73e598b36c4ab5de2eb54c9b566a3acb72409b9c506bd00f3865")
