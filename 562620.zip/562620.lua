-- Lua provided by RyzenAPI
-- Game: Game: Robonauts

-- MAIN APPLICATION
addappid(562620)
-- Game: addappid(562620)

-- MAIN APP DEPOTS / PACKAGES
addappid(562621, 1, "d7fbc4810a663b46548be6821d4d2367611bda1da3037a79230058917de5729f")
