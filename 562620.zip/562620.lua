-- Lua provided by SkyAPI 
-- Game: Robonauts
addappid(562620)
addappid(562621, 1, "d7fbc4810a663b46548be6821d4d2367611bda1da3037a79230058917de5729f")
