-- Lua provided by RyzenAPI
-- Game: Dinosaur Hunt First Blood

-- MAIN APPLICATION
addappid(650490)

-- MAIN APP DEPOTS / PACKAGES
addappid(650491, 1, "0973b993c57abe3a5dab523b2356460330fd76da7b7101c7087d54ed486a29c8")
addappid(650492, 1, "a27e5b9139ee6e34760b2e0fbea2225146ae40418dbc3539ae4b6d41d4ea9e42")
addappid(650493, 1, "303059014c3262c138121190ffcc3b78b097bc229174cd7426aa43a228404caf")
addappid(650494, 1, "0fe91a2cb0e7a8bbb69e1853ebb136ec9819be0eb4189ead6db243a62a0a6f7c")

