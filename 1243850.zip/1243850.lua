-- Lua provided by RyzenAPI
-- Game: This Bed We Made

-- MAIN APPLICATION
addappid(1243850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243851, 1, "86c396a5290b9f8988b07469182701a3545368ce1f1ad107f95c504d73b7094e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
