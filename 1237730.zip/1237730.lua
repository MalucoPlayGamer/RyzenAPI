-- Lua provided by RyzenAPI
-- Game: Catlateral Damage: Remeowstered

-- MAIN APPLICATION
addappid(1237730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237731, 1, "156904ddf469a971710e983791beb8238374d294886b1de06691c6ea978e4780")

