-- Lua provided by RyzenAPI
-- Game: Game: 1001 Jigsaw: Earth Chronicles 4

-- MAIN APPLICATION
addappid(1664980)
-- Game: addappid(1664980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664981, 1, "f68448edb098e59c07e380bf130ef6375dc257efcf01fa523a212e272e824834")
addappid(1664984, 1, "e685f23873ae02f3e33adb79d940f780960cc787bfb9273e120712aba08bbd9c")
