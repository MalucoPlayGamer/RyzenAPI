-- Lua provided by RyzenAPI
-- Game: Game: Undying Soundtrack Preview

-- MAIN APPLICATION
addappid(1612740)
-- Game: addappid(1612740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612741, 1, "4af42aada980eff5f555257efd80236dd2152906a28ecb1ecdca93eaaef1250f")
