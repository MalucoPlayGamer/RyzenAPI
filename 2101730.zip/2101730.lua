-- Lua provided by RyzenAPI
-- Game: addappid(2101730)

-- MAIN APPLICATION
addappid(2101730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101731, 1, "c5d00eafe38d79cf65a97a729210ab0782acba87e6a13a2d6e6387f5783fd758")
