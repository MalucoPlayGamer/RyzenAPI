-- Lua provided by RyzenAPI
-- Game: Car Wash Simulator

-- MAIN APPLICATION
addappid(992840) -- Car Wash Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(992841, 1, "a6bdfde01817cfd02272afac8ff6cb26f28b67a4d69fdfb160ff01ff72a88306") -- Depot 992841

