-- 992840's Lua and Manifest Created by Hubcap Manifest
-- Car Wash Simulator
-- Created: August 11, 2026 at 00:21:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(992840) -- Car Wash Simulator
-- MAIN APP DEPOTS
addappid(992841, 1, "a6bdfde01817cfd02272afac8ff6cb26f28b67a4d69fdfb160ff01ff72a88306") -- Depot 992841
setManifestid(992841, "4795994964938523456", 3554578383)