-- Lua provided by RyzenAPI
-- Game: Elysium Above 履云录

-- MAIN APPLICATION
addappid(1509450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509451, 1, "225d4927d7b331250b0e9bda22fb8466f5f2680c527d8068726ac92a3252f3f6")
