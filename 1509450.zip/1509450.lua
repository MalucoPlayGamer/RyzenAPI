-- Lua provided by RyzenAPI
-- Game: Elysium Above 履云录

-- MAIN APPLICATION
addappid(1509450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509451, 1, "225d4927d7b331250b0e9bda22fb8466f5f2680c527d8068726ac92a3252f3f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
