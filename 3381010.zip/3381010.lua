-- Lua provided by RyzenAPI
-- Game: addappid(3381010)

-- MAIN APPLICATION
addappid(3381010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381011, 1, "9bdb3fd142fc4d57953e1f401e6749e7d3e694e0347c6d41dca9086b59af6bbd")
