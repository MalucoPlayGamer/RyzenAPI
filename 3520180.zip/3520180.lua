-- Lua provided by RyzenAPI
-- Game: Tasty Bite: Food dating simulator

-- MAIN APPLICATION
addappid(3520180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520181,0,"d0cbbe84df028f12d34503f8dd53e82f05299fc8b3a8a06a9e465b2051fe3198")

