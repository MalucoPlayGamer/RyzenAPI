-- Lua provided by RyzenAPI 
-- Game: AppID 2987900
addappid(2987900)
addappid(2987901, 1, "8fbe56c0b86018719135fd2c7c313091786e2bdd52da68a4f1157e0f812d1c7e")
