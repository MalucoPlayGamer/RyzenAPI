-- Lua provided by RyzenAPI
-- Game: Saviors

-- MAIN APPLICATION
addappid(314450)
addappid(334970)
addappid(456910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(314451, 1, "83ec7b684c4ce73dc00f676459f9ad2d6f097f91f11184d82cff11078d5c582b")
addappid(314452, 1, "cd391de873b5f464c640f15a3b3729e3d3ed40960ed9745407ae2c6585b7c9e6")
addappid(314453, 1, "0b4af3a137ed5c0bac99fef3ce94c581efc6e8f601c456c72c676f04d2c65b8c")
addappid(314454, 1, "07c322d2708e62ec006f4e3bc07b40a25a0a7545f77980c4c814a1f51f9c87cc")

