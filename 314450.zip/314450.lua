-- Lua provided by RyzenAPI
-- Game: Game: AppID 314450

-- MAIN APPLICATION
addappid(314450)
addappid(334970)
addappid(456910)
-- Game: addappid(314450)

-- MAIN APP DEPOTS / PACKAGES
addappid(314451, 1, "83ec7b684c4ce73dc00f676459f9ad2d6f097f91f11184d82cff11078d5c582b")
addappid(314452, 1, "cd391de873b5f464c640f15a3b3729e3d3ed40960ed9745407ae2c6585b7c9e6")
addappid(314453, 1, "0b4af3a137ed5c0bac99fef3ce94c581efc6e8f601c456c72c676f04d2c65b8c")
addappid(314454, 1, "07c322d2708e62ec006f4e3bc07b40a25a0a7545f77980c4c814a1f51f9c87cc")
