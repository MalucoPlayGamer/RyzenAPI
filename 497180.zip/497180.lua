-- Lua provided by RyzenAPI
-- Game: Street Legal Racing: Redline v2.3.1

-- MAIN APPLICATION
addappid(497180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(497181, 1, "ceb30eb975ede265200a888dd305c54baf42d6e273df05c51934f65ee75d3206")
addappid(513500, 0, "906cd0846a0a94ee8145811be685e638b21ccd227cfc06d7302efafc81bb636a")

