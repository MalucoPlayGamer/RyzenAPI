-- Lua provided by RyzenAPI
-- Game: 1758090

-- MAIN APPLICATION
addappid(1758090)
-- Game: addappid(1758090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758091, 1, "ad8d5af9a23a247ddb33a80a9a4747fc2aacdea9ab8517969b5466030f00cf8e")
