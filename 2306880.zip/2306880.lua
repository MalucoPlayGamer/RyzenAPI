-- Lua provided by RyzenAPI
-- Game: 街机捕鱼城-经典万炮捕鱼

-- MAIN APPLICATION
addappid(2306880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306881, 1, "453615ed53ea3c20b99500002604b471d39f68813329731e27f8fbf82a78689f")

