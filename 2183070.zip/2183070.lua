-- Lua provided by RyzenAPI
-- Game: 2183070

-- MAIN APPLICATION
addappid(2183070)
-- Game: addappid(2183070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183071, 1, "d3e8e6533d389c76f6a02e2cb6e73b4acbf148e6aae92f7c50a9d568ef149bc4")
