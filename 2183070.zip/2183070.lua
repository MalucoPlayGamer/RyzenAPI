-- Lua provided by SkyAPI 
-- Game: Tokyo Necro
addappid(2183070)
addappid(2183071, 1, "d3e8e6533d389c76f6a02e2cb6e73b4acbf148e6aae92f7c50a9d568ef149bc4")
