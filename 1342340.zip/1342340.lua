-- Lua provided by RyzenAPI
-- Game: 1342340

-- MAIN APPLICATION
addappid(1342340)
-- Game: addappid(1342340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342341, 1, "06270375aa9c7fd7f1dd526f675c0a8fe67c049560fac25a5d71e05f4ef7a058")
