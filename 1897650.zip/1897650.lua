-- Lua provided by RyzenAPI
-- Game: Game: Dream Tactics

-- MAIN APPLICATION
addappid(1897650)
-- Game: addappid(1897650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897651, 1, "2d34a192d0e836eb4493f7aecedba5bb303bf366544e25dd3c1c3cf3705220b5")
