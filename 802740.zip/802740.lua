-- Lua provided by RyzenAPI
-- Game: addappid(802740)

-- MAIN APPLICATION
addappid(802740)

-- MAIN APP DEPOTS / PACKAGES
addappid(802742,0,"c14d9d207a2783f35ec8d052bbb20a776172012b890a82509f1b18e0fafae2ec")
addappid(802743,0,"1bd0eac38fb25b7f42a39ee9535cdb2b51c28702dac3e2ccda5b8a610a8434c5")
