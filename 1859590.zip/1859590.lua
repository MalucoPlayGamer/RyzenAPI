-- Lua provided by RyzenAPI 
-- Game: AppID 1859590
addappid(1859590)
addappid(1859591, 1, "549bfcd39cd11e91b5dafb73e92add75c777e7c12f9b8e66498cc0065af74dd5")
