-- Lua provided by RyzenAPI
-- Game: Game: Hero Battle

-- MAIN APPLICATION
addappid(463000)
-- Game: addappid(463000)

-- MAIN APP DEPOTS / PACKAGES
addappid(463001, 1, "55e0aba8d1ecf8b51756b07f56bdaf392b6cfe358107b7300794c980ef944ab6")
