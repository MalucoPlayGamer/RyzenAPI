-- 3524750's Lua and Manifest Created by Hubcap Manifest
-- Tabletop Game Shop Simulator
-- Created: June 18, 2026 at 07:13:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3524750, 1, "a2c10df33fc8e947aee3c0e3e9e558386a4e401387d8533fd04cf40bab3e0da3") -- Tabletop Game Shop Simulator
-- MAIN APP DEPOTS
addappid(3524751, 1, "8ca9a2ea765aeb25286a5bb6e3ba6d3d308ce55ecd4670ae08314cd939c2abea") -- Depot 3524751
setManifestid(3524751, "6289199945829207283", 3276334391)