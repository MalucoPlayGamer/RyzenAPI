-- Lua provided by RyzenAPI
-- Game: Game: MasterpieceVR

-- MAIN APPLICATION
addappid(504650)
-- Game: addappid(504650)

-- MAIN APP DEPOTS / PACKAGES
addappid(504651, 1, "523384fb3085af50eeb807b4269f088b057801103d681086cb90159206a265aa")
