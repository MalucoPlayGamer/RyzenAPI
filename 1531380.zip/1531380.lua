-- Lua provided by RyzenAPI
-- Game: Ace Pilot

-- MAIN APPLICATION
addappid(1531380)
addappid(1532450)
addappid(1532451)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531381, 1, "234d37804e5b331ccfb34be7640ef662f2844b353c7203e71d97698e3ae16851")

