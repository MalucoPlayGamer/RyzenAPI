-- Lua provided by RyzenAPI
-- Game: Toree 2

-- MAIN APPLICATION
addappid(1722620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722621, 1, "dd5f689ed459c480dc387e15f5707557f29bee2b69eb2928aa2086cf9b4dc536")
