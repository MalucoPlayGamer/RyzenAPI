-- Lua provided by RyzenAPI
-- Game: addappid(587180)

-- MAIN APPLICATION
addappid(587180)

-- MAIN APP DEPOTS / PACKAGES
addappid(587181, 1, "8e82b0ef89f26f0a122835a4c1db7f5d30b7cb063ca9385bc9aee576d44bf5d8")
