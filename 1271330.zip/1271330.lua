-- Lua provided by RyzenAPI
-- Game: addappid(1271330)

-- MAIN APPLICATION
addappid(1271330)
addappid(1271331)
addappid(1271333)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271332,0,"bd171cec86f3a7327d056f06b9c666c3ff2bbb30e9d16eb72a49be424c195768")
