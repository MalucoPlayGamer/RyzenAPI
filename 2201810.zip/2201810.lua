-- Lua provided by RyzenAPI
-- Game: 筮灵 SHILING

-- MAIN APPLICATION
addappid(2201810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201811, 1, "062926c066f24d6f5fc58d527b57fd70e27d9bf48822797faa6bdf9f35cbcd04")

