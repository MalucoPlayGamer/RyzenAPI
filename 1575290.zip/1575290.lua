-- Lua provided by RyzenAPI
-- Game: addappid(1575290)

-- MAIN APPLICATION
addappid(1575290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575291, 1, "2f9cef8eebe3699aef0be370c7181e88fe92476c6c1b73b6eed39755eb483f86")
