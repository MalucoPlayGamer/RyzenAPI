-- Lua provided by RyzenAPI
-- Game: addappid(1825340)

-- MAIN APPLICATION
addappid(1825340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825341, 1, "7850a2a3454fd8c808add8dd92325cd9024b9677fe91874f0dde8c15ca773d77")
