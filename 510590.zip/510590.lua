-- Lua provided by RyzenAPI
-- Game: D: The Game

-- MAIN APPLICATION
addappid(510590)
-- Game: addappid(510590)

-- MAIN APP DEPOTS / PACKAGES
addappid(510591, 1, "5903fe777495a3f469d376940d6c11fe7c700231d0abee0a60e6e732200551af")
