-- Lua provided by RyzenAPI 
-- Game: Hentai Tales: Bunny Hole
addappid(2993660)
addappid(2993661, 1, "4c21a902c4d444062f2d35e633a0662f76b94563b2c87e4d189401eb5bac9f00")
