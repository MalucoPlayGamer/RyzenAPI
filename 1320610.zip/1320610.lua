-- Lua provided by RyzenAPI
-- Game: addappid(1320610)

-- MAIN APPLICATION
addappid(1320610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320611, 1, "b6b6e839803b8b8d2595efbef06b62c58a6a12cdb005374a12362f0c526b7537")
