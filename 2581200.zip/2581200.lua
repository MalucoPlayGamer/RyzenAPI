-- Lua provided by RyzenAPI
-- Game: Dark Odyssey

-- MAIN APPLICATION
addappid(2581200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581201, 1, "4ca371788adf0c36a61561e670a1cc242b12a1548a9072eb4f18fca43f78f986")

