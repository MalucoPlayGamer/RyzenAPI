-- Lua provided by RyzenAPI
-- Game: 253790

-- MAIN APPLICATION
addappid(253790)
-- Game: addappid(253790)

-- MAIN APP DEPOTS / PACKAGES
addappid(253791, 1, "185f4c2ce5f01ad11f02e998c23d9ef598dc72314e2a8d1612c9019cac3cf422")
