-- Lua provided by RyzenAPI
-- Game: Stripped of Title: Backlash — Episode 1

-- MAIN APPLICATION
addappid(1892910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892911, 1, "1700d40d065dc7e8e19361e482dc2e1da236e861b367f8b3e386e984334ba4ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
