-- Lua provided by RyzenAPI
-- Game: Stripped of Title: Backlash — Episode 1

-- MAIN APPLICATION
addappid(1892910)
-- Game: addappid(1892910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892911, 1, "1700d40d065dc7e8e19361e482dc2e1da236e861b367f8b3e386e984334ba4ba")
