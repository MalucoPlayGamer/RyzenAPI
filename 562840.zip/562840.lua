-- Lua provided by RyzenAPI
-- Game: addappid(562840)

-- MAIN APPLICATION
addappid(562840)

-- MAIN APP DEPOTS / PACKAGES
addappid(562841, 1, "a0099956fdf98748b1045cdb0611eb8767e77ecb2e4c56635a5f530e1c686492")
