-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1463271)
-- Game: addappid(1463271)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463271,0,"f9a6167f03bd00e016ce7afa123a56d74c808f499ad8829439bb17b2fbfa9c19")
addappid(3030910,0,"e21480f72d477e33af84c317b39ed353cd903fb0a98a696b4d99f94f67367ba2")
