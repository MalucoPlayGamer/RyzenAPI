-- Lua provided by RyzenAPI
-- Game: Inferno

-- MAIN APPLICATION
addappid(615690)
addappid(1421070)

-- MAIN APP DEPOTS / PACKAGES
addappid(615691, 1, "e6600fa9f644a31141ea2a2698353df351d4acfc9cb9f40a0dc10a9098cebcde")

