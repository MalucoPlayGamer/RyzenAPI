-- Lua provided by SkyAPI 
-- Game: AppID 381910
addappid(381910)
addappid(381911, 1, "e7dee2d5ab3b855e9898116d37262b3f1c05e93c4664f395b485f8dd0fb15a68")
addappid(400120, 0, "53b980852af1d309fc346feef97348c1d2dc070cf8b2d2dfbc39ac8839394c87")
