-- Lua provided by RyzenAPI
-- Game: The Hike

-- MAIN APPLICATION
addappid(1867480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867481, 1, "538bc9b42254cfc5a92ed893307d39be01b3db306b94b23a17afaba288298dce")
