-- Lua provided by RyzenAPI
-- Game: Game: AppID 314340

-- MAIN APPLICATION
addappid(314340)
-- Game: addappid(314340)

-- MAIN APP DEPOTS / PACKAGES
addappid(314341, 1, "3e0039ccc0db2dfe0dd81111826de4a070a3c0b7d004cf9b28045063f62839a9")
