-- Lua provided by RyzenAPI
-- Game: Chess 2: The Sequel

-- MAIN APPLICATION
addappid(314340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(314341, 1, "3e0039ccc0db2dfe0dd81111826de4a070a3c0b7d004cf9b28045063f62839a9")

