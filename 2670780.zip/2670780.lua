-- Lua provided by RyzenAPI
-- Game: Game: Death Row Escape

-- MAIN APPLICATION
addappid(2670780)
-- Game: addappid(2670780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670781, 1, "426094b1dbdf4936fbbba5dddbf1ddda044ec081ae8ac07d952bdd0a7ab19f43")
