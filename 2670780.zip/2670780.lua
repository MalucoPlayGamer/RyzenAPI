-- Lua provided by SkyAPI 
-- Game: Death Row Escape
addappid(2670780)
addappid(2670781, 1, "426094b1dbdf4936fbbba5dddbf1ddda044ec081ae8ac07d952bdd0a7ab19f43")
