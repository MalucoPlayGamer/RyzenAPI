-- Lua provided by RyzenAPI 
-- Game: Zup! 9
addappid(1098340)
addappid(1098341, 1, "af4c638b46460c8b9d93ba4f6b0ea9df6267f032a1e1f8a6fa72b804884b27a1")
