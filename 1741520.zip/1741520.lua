-- Lua provided by RyzenAPI
-- Game: addappid(1741520)

-- MAIN APPLICATION
addappid(1741520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741521, 1, "61decdbeb6ce127eef0167dfa827fd27908b61fa494ee7d907897b52c6ae80b5")
