-- Lua provided by RyzenAPI
-- Game: 791040

-- MAIN APPLICATION
addappid(791040)
-- Game: addappid(791040)

-- MAIN APP DEPOTS / PACKAGES
addappid(791041, 1, "73fff94e03b2cf933c32830a7130040401cc5f69b0ff6644835e116cb412f249")
