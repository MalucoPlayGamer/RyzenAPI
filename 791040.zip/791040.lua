-- Lua provided by RyzenAPI
-- Game: Virtual Reality Neuron Tracer

-- MAIN APPLICATION
addappid(791040)

-- MAIN APP DEPOTS / PACKAGES
addappid(791041, 1, "73fff94e03b2cf933c32830a7130040401cc5f69b0ff6644835e116cb412f249")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
