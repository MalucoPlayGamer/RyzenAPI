-- Lua provided by RyzenAPI
-- Game: Game: Outside the Window

-- MAIN APPLICATION
addappid(1824130)
-- Game: addappid(1824130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824131, 1, "9692c4ce61a78e5323d4f80cb75077b8a610ea9c7986b639d3354103d831c8dd")
