-- Lua provided by SkyAPI 
-- Game: Outside the Window
addappid(1824130)
addappid(1824131, 1, "9692c4ce61a78e5323d4f80cb75077b8a610ea9c7986b639d3354103d831c8dd")
