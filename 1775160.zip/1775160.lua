-- Lua provided by RyzenAPI 
-- Game: Geo Zombies
addappid(1775160)
addappid(1775161, 1, "ba5a6789c6644dd157018d8f1879243a288c5816122b081a8284cda72a0267b6")
