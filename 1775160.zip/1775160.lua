-- Lua provided by RyzenAPI
-- Game: Game: Geo Zombies

-- MAIN APPLICATION
addappid(1775160)
-- Game: addappid(1775160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775161, 1, "ba5a6789c6644dd157018d8f1879243a288c5816122b081a8284cda72a0267b6")
