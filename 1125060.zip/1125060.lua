-- Lua provided by RyzenAPI
-- Game: The Quest for Achievements Remix

-- MAIN APPLICATION
addappid(1125060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125061, 1, "c7da4dc8cc6d645b8054dc496dea2fb3092ed9361fa06ec2951c7921e1fce3aa")
