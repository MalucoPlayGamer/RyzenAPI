-- Lua provided by RyzenAPI
-- Game: Game: Crime Scene Cleaner Soundtrack

-- MAIN APPLICATION
addappid(3153150)
-- Game: addappid(3153150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3153151, 1, "d9b4073e24a34384ace2e0fec178772df457447a705fcc29d4cfe5cfd084ed11")
