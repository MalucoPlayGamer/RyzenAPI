-- Lua provided by RyzenAPI
-- Game: Game: Company of Heroes: Europe In Ruins

-- MAIN APPLICATION
addappid(664260)
-- Game: addappid(664260)

-- MAIN APP DEPOTS / PACKAGES
addappid(664261, 1, "b460990e30517c8f2763e84bc08a79eacc33a046e647a36f0a01b1ca728feb3b")
