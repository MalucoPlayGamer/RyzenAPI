-- Lua provided by SkyAPI 
-- Game: Stint: Rift Apart
addappid(1756060)
addappid(1756061, 1, "77e580fa053c0bda84dc389f2a1b4be515f527ce3329338f61ac3c768af7cc9a")
