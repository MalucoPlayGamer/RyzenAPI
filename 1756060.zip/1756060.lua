-- Lua provided by RyzenAPI
-- Game: addappid(1756060)

-- MAIN APPLICATION
addappid(1756060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756061, 1, "77e580fa053c0bda84dc389f2a1b4be515f527ce3329338f61ac3c768af7cc9a")
