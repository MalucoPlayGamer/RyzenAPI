-- Lua provided by RyzenAPI
-- Game: CONTASION 2

-- MAIN APPLICATION
addappid(428940)

-- MAIN APP DEPOTS / PACKAGES
addappid(428945,0,"8008f7857fcf70ceb44068a6919d672a6a697bbbaa1c504dc492b9a16f42d0e7")
addappid(428946,0,"33d124be6008a5a35a0b9d977bd95f388078dacbe161e43fc2b348c52f4c868d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
