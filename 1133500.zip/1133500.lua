-- Lua provided by RyzenAPI
-- Game: Overthrown

-- MAIN APPLICATION
addappid(1133500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133501, 1, "9e1109440b19052b9cf6765455c03edf08679a6a15324cffe92a3a7b9a24fdaf")

