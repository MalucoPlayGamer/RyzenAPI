-- Lua provided by RyzenAPI 
-- Game: The Alchemist of Ars Magna
addappid(2328240)
addappid(2328241, 1, "dbc33c3d7c234b839dc58810c47f20348498b2b0231e768fc3e99852a33143ea")
addappid(2328242, 1, "0cb6ec9fa3d5895073b8d806d67f458f31d7029f0cd78d052a3b3e765bc3f57e")
