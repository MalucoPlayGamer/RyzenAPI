-- Lua provided by RyzenAPI
-- Game: addappid(3617260)

-- MAIN APPLICATION
addappid(3617260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617261, 1, "b134c0a62bf43bf0c3fcb98accd36064e0f6388e7fbb82b60889ccb365d53923")
