-- Lua provided by RyzenAPI
-- Game: 旅行恋恋Art Book: 恋恋新天地喂养指南 Sun-Day City-Walk

-- MAIN APPLICATION
addappid(3617260)
-- Game: addappid(3617260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617261, 1, "b134c0a62bf43bf0c3fcb98accd36064e0f6388e7fbb82b60889ccb365d53923")
