-- Lua provided by RyzenAPI 
-- Game: Farm Fatale
addappid(1640130)
addappid(1640131, 1, "4683fa3d1d8239a2b15b33a0c32bb9e85d94eceb9c881edef928a6894928d368")
