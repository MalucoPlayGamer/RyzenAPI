-- Lua provided by RyzenAPI
-- Game: Farm Fatale

-- MAIN APPLICATION
addappid(1640130)
-- Game: addappid(1640130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640131, 1, "4683fa3d1d8239a2b15b33a0c32bb9e85d94eceb9c881edef928a6894928d368")
