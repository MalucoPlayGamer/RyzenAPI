-- 3948120's Lua and Manifest Created by Morrenus
-- Scritchy Scratchy
-- Created: March 26, 2026 at 14:38:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3948120) -- Scritchy Scratchy
-- MAIN APP DEPOTS
addappid(3948121, 1, "4d5ba58100eba881f6f9a66ee5982857f3db6a375f5319bdfddd6d9b71defc07") -- Depot 3948121
--setManifestid(3948121, "8601216601557071511", 438066521)
addappid(3948122, 1, "328927d058e2934b073e34b22bcbf5103daa2dea1879877f2ef930f2cf7ef046") -- Depot 3948122
--setManifestid(3948122, "3865283400215081629", 545159427)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4428640) -- Scritchy Scratchy - Supporter Pack