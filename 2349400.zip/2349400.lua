-- Lua provided by RyzenAPI
-- Game: 2349400

-- MAIN APPLICATION
addappid(2349400)
-- Game: addappid(2349400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349401, 1, "7f3de0bf4c6f7c9bfc4e99c80c7d7ba8650f830914a7fb99a9fa225a9cfd37ea")
