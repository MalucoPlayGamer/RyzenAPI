-- Lua provided by RyzenAPI
-- Game: Heretic's Lot: Prologue

-- MAIN APPLICATION
addappid(1324860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324861, 1, "4464001071e7315b8bd0a415804139c23c27ae2463fdc8abbd628c826885ff95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
