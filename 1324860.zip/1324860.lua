-- Lua provided by RyzenAPI
-- Game: Heretic's Lot: Prologue

-- MAIN APPLICATION
addappid(1324860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324861, 1, "4464001071e7315b8bd0a415804139c23c27ae2463fdc8abbd628c826885ff95")

