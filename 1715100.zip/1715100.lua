-- Lua provided by RyzenAPI
-- Game: HUMANKIND™ - Music for the Ages, Vol. I

-- MAIN APPLICATION
addappid(1715100)
-- Game: addappid(1715100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715101, 1, "7bde6dad1476987a64c0d601c187379be33b0eff7b1d1c0e3e8b30fb81ec7c7d")
addappid(1715102, 1, "3cb8b81b7a25d2993f1176d8a665a8422cae682f04af0f52463f36aaca5cb609")
