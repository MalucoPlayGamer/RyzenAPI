-- Lua provided by RyzenAPI
-- Game: Wild Legion

-- MAIN APPLICATION
addappid(2359760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359761, 1, "04c5c8957cddbd3e267aca53d891f7a0ddbba5ba0057ee7fa5bef2f460241d49")

