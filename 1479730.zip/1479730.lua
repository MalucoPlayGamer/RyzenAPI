-- Lua provided by RyzenAPI
-- Game: Commandos: Origins

-- MAIN APPLICATION
addappid(1479730)
addappid(3194180)
addappid(3933550)
addappid(4172650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1479731, 1, "64205c91ebfac38afeb2011798b9270dc5d1eec20ef0d4b176a42fbf5570de84")
addappid(3565060, 0, "25969d0cfdf09a97590616156414c9996ebf94afe209ed4cb0eb957fa79a2c77")

