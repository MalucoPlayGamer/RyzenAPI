-- Lua provided by RyzenAPI
-- Game: Halloween Arkanoid 2

-- MAIN APPLICATION
addappid(979450)

-- MAIN APP DEPOTS / PACKAGES
addappid(979451, 1, "0f6668e85e58b62f85269a700989932e9a6bf2d7354ccaed826c976b1f451a84")

