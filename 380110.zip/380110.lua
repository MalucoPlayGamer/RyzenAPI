-- Lua provided by RyzenAPI
-- Game: In The Black

-- MAIN APPLICATION
addappid(380110)

-- MAIN APP DEPOTS / PACKAGES
addappid(380111,0,"2dc8a029f4d59358a94fef96bc307bf8f21571c0eec058270beedc2b867d8a27")

