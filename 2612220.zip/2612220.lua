-- Lua provided by RyzenAPI
-- Game: Cosmic Armada

-- MAIN APPLICATION
addappid(2612220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612221, 1, "a34eb26f619fea72dfbfea3e4be97a4150ad98888a81e119507308a833522f02")

