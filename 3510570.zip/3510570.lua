-- Lua provided by RyzenAPI 
-- Game: AppID 3510570
addappid(3510570)
addappid(3510571, 1, "fa24a9dacff2eaec78ed3f451dbe36bc366910e688a6c886903acc2ceb6a6b3d")
addappid(3510572, 1, "c66e0c804f2ae1328bb466159022d1f1600dd938eefba62a51c1495c65d96202")
