-- Lua provided by RyzenAPI
-- Game: 2255420

-- MAIN APPLICATION
addappid(2255420)
-- Game: addappid(2255420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255421, 1, "a1cddeb28da4ca38dfe049758f25cfef01535b333e68e146167dbf9db74e20c4")
