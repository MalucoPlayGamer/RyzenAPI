-- Lua provided by RyzenAPI
-- Game: Love Potion

-- MAIN APPLICATION
addappid(2633760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633761, 1, "63fd7e202d52e5fd235b2a98a8f345f5a323dbe94ae7cad3c82a7412466c3bf1")
