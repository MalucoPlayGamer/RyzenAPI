-- Lua provided by RyzenAPI 
-- Game: Cozy Time
addappid(2054740)
addappid(2054741, 1, "f7642c7a334e571fa62463afe27c7c3d72dd34b4cd6810c8acfa5decb5187d78")
