-- Lua provided by RyzenAPI
-- Game: It Paints Me

-- MAIN APPLICATION
addappid(3186680)
addappid(3203330)

