-- Lua provided by RyzenAPI
-- Game: It Paints Me

-- MAIN APPLICATION
addappid(3186680)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3203330)
