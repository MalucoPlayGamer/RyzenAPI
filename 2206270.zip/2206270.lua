-- Lua provided by RyzenAPI
-- Game: AppID 2206270

-- MAIN APPLICATION
addappid(2206270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206271, 1, "11e8eea29af28f571f677aafcf463630a492c3ecb8e9639d50ca1bd5657e0d3b")
