-- Lua provided by SkyAPI 
-- Game: AppID 2206270
addappid(2206270)
addappid(2206271, 1, "11e8eea29af28f571f677aafcf463630a492c3ecb8e9639d50ca1bd5657e0d3b")
