-- Lua provided by SkyAPI 
-- Game: AppID 3471390
addappid(3471390)
addappid(3471391, 1, "e41dfaf04d3fd8c6e8a7d388339db299b284f178339036e41db0f15e1efb31db")
