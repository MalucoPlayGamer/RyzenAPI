-- Lua provided by RyzenAPI
-- Game: Game: Hammer Heads Deluxe

-- MAIN APPLICATION
addappid(3400)
-- Game: addappid(3400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3401, 1, "bc3583258dbd99eebe51203d6811d40eaca5278fc15676df24e71a196c462e10")
