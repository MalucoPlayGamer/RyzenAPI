-- Lua provided by RyzenAPI
-- Game: 3683980

-- MAIN APPLICATION
addappid(3683980)
-- Game: addappid(3683980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3683981, 1, "0e974408171236622176dadcb49d2ac9493ec93b6e304f1dd406f8475fecb737")
