-- Lua provided by RyzenAPI
-- Game: QUALIA ~The Path of Promise~

-- MAIN APPLICATION
addappid(1938120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938122,0,"b5e8591446c0097c95c5cf44a13e57171700603c453538a3c5b36258c4dc1b87")

