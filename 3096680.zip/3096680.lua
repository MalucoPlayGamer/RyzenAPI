-- Lua provided by RyzenAPI 
-- Game: AppID 3096680
addappid(3096680)
addappid(3096681, 1, "0f30265918e73d8970d2dedcd9367077de45e53d97c0e215ca7a7a38d2b9b577")
