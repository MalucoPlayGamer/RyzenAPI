-- Lua provided by RyzenAPI
-- Game: 多元守卫者 Diverse Defenders Demo

-- MAIN APPLICATION
addappid(3096680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096681, 1, "0f30265918e73d8970d2dedcd9367077de45e53d97c0e215ca7a7a38d2b9b577")
