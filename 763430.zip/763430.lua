-- Lua provided by RyzenAPI
-- Game: Front Defense Heroes

-- MAIN APPLICATION
addappid(763430)

-- MAIN APP DEPOTS / PACKAGES
addappid(763431, 1, "cf5f34f6ab0fc4581786d77d51dfcf70622c3eab4c4e19aef720b141343891f4")

