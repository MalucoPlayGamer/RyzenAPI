-- Lua provided by RyzenAPI
-- Game: Gun Club VR

-- MAIN APPLICATION
addappid(691320)
-- Game: addappid(691320)

-- MAIN APP DEPOTS / PACKAGES
addappid(691321, 1, "da30051538ebce39c7870be766d40851a774b6c250588e2408280636888be13a")
