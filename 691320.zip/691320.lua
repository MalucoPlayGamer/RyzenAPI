-- Lua provided by RyzenAPI
-- Game: Gun Club VR

-- MAIN APPLICATION
addappid(691320)

-- MAIN APP DEPOTS / PACKAGES
addappid(691321, 1, "da30051538ebce39c7870be766d40851a774b6c250588e2408280636888be13a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1562720)
addappid(2113980)
addappid(4549460)
