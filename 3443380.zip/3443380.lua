-- Lua provided by RyzenAPI
-- Game: 3443380

-- MAIN APPLICATION
addappid(3443380)
-- Game: addappid(3443380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443383,0,"de7b0fe8809000585ebaf824046be2ff44fc260daed39762f26699d53c7e56d7")
