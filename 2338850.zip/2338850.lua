-- Lua provided by RyzenAPI 
-- Game: Shiner
addappid(2338850)
addappid(2338851, 1, "41e226c6b68af5eccff44dffd23de2f55671ead92d1710362d61db8ab47dd001")
