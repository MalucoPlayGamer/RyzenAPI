-- Lua provided by RyzenAPI
-- Game: All Evil Night

-- MAIN APPLICATION
addappid(682100)

-- MAIN APP DEPOTS / PACKAGES
addappid(682101,0,"88fd512247c3fab21fb53696d216ccc4dcdbd0edeac43b385270f74eb1783e01")
addappid(682102,0,"545fe64c3d8b07280db9c58f4868221d1c6ca4c9f5c87991e2c4d42af6e01df0")

