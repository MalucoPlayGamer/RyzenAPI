-- Lua provided by RyzenAPI 
-- Game: Yooka-Laylee and the Impossible Lair
addappid(846870)
addappid(846871, 1, "99d16b553092fab84e58293a1f86a697cf883e81f338c93ac9f5dfd9abc782a5")
addappid(846872, 1, "75110ba4fbc86c6a0d8bca39f295f01918862030bfe5f859f53e3f251d871c4e")
addappid(1169810, 0, "67d0225c1105501b4b1d27edb0aee64724260c0aba6fd8dde77db3257f05377f")
