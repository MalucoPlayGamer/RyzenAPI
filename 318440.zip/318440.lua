-- Lua provided by SkyAPI 
-- Game: Cubesis
addappid(318440)
addappid(318441, 1, "7521e87a07bd51bba5ff05cfea478ec597536f111c48713deb52861c97931c8d")
