-- Lua provided by RyzenAPI
-- Game: 318440

-- MAIN APPLICATION
addappid(318440)
-- Game: addappid(318440)

-- MAIN APP DEPOTS / PACKAGES
addappid(318441, 1, "7521e87a07bd51bba5ff05cfea478ec597536f111c48713deb52861c97931c8d")
