-- Lua provided by RyzenAPI
-- Game: Game: Lunar Mirror:The Pavilion of Desire

-- MAIN APPLICATION
addappid(2157680)
-- Game: addappid(2157680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157681, 1, "73dcd3d4b21d5b46b3ccc85cd339659397f865b345c64717424a2ee33856c0d7")
addappid(2192630, 0, "1614b072f33a76e43a3c57f8a625c7062d98de4734856ac98c10ac64e03f932f")
