-- Lua provided by RyzenAPI 
-- Game: DreamWorks Dragons: Legends of The Nine Realms
addappid(1721440)
addappid(1721441, 1, "6e11861b4c5121b106918f91836d403e09034a60a91a20c36ef07a0bc780e493")
