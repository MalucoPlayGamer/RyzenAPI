-- Lua provided by RyzenAPI
-- Game: Battlesloths 2025: The Great Pizza Wars

-- MAIN APPLICATION
addappid(459350)

-- MAIN APP DEPOTS / PACKAGES
addappid(459351, 1, "16a80af1eba51f3c77bfb9592c262612b5dab362d1ccf358e7836b9371b18a9a")
addappid(459353, 1, "ec94a2bbbfc5b101a4f76927830ce904675f1a5a237935c2354c53853b5e5d17")
addappid(459355, 1, "41a12f8d6f5e7af2fedbf49014bd1967ee7cde4c85b9da01b452b6bc42f13f45")
addappid(459356, 1, "6a04580b1136664a2fadfef564f3e4d443b290b059e3f378d20dc9491e0d0ae4")
addappid(459357, 1, "b854fc0accfae0a4db26f75392ac3c54d095289b0d24abe851f70467e4bb00a7")
