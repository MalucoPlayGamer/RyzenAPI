-- Lua provided by RyzenAPI
-- Game: Pixel Poops

-- MAIN APPLICATION
addappid(1492450)
addappid(1492490)
addappid(1492491)
addappid(1498530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1492451, 1, "ed024c8ff6fdfc654a7126ea9cb470ad1e28bc73fa425395a3f05012690cf766")

