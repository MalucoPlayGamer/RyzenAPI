-- Lua provided by RyzenAPI
-- Game: 1492450

-- MAIN APPLICATION
addappid(1492450)
-- Game: addappid(1492450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492451, 1, "ed024c8ff6fdfc654a7126ea9cb470ad1e28bc73fa425395a3f05012690cf766")
