-- Lua provided by RyzenAPI
-- Game: Real Drift Multiplayer

-- MAIN APPLICATION
addappid(2481890)
-- Game: addappid(2481890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481891, 1, "3603b4f4ec6c8e0b6fb7ed0566d223973b061d51a898408e1c0d4e51311533d7")
