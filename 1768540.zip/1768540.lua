-- Lua provided by RyzenAPI
-- Game: Bewildered

-- MAIN APPLICATION
addappid(1768540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1768541, 1, "639057cc2a91dca5765eba28c52216d43e0374070b797d8dc788d91bb10a17e8")
