-- Lua provided by RyzenAPI
-- Game: 1768540

-- MAIN APPLICATION
addappid(1768540)
-- Game: addappid(1768540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768541, 1, "639057cc2a91dca5765eba28c52216d43e0374070b797d8dc788d91bb10a17e8")
