-- Lua provided by RyzenAPI
-- Game: Saiko no sutoka

-- MAIN APPLICATION
addappid(1546860)
-- Game: addappid(1546860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546861, 1, "7c4a4237e34aa6867063aeea2d82bb842554e233862966577052154bdc878c40")
