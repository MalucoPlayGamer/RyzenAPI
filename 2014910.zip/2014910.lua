-- Lua provided by RyzenAPI
-- Game: 2014910

-- MAIN APPLICATION
addappid(2014910)
-- Game: addappid(2014910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014911, 1, "bd8e08f87c9d45d6d0f9390db2cf834687edb3d467ea6c367d14fa432322ee71")
