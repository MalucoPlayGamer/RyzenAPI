-- Lua provided by RyzenAPI 
-- Game: Celestia: Chain of Fate Demo
addappid(2968090)
addappid(2968091, 1, "b2bf86a26e72070421b61068b61470db56ab10f545dbd8e33805dd9641402574")
