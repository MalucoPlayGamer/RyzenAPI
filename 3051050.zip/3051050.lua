-- Lua provided by SkyAPI 
-- Game: 100 Aztec Cats
addappid(3051050)
addappid(3051051, 1, "35381e95d32acefb8f0be02ac0e53a8e39180e9510baeb2c39a3ae69b99ebfda")
addappid(3496260, 0, "7524e6e08e6bb89f98c71bb941669093d910e35e46f49a51644d4de3dcf12420")
