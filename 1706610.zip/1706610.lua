-- Lua provided by RyzenAPI
-- Game: Game: AppID 1706610

-- MAIN APPLICATION
addappid(1706610)
-- Game: addappid(1706610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706611, 1, "cf41b457d44abaa8303e07dbf554aac4a835b71fc646c838e713d84a86fc97da")
