-- Lua provided by RyzenAPI
-- Game: Icarus Online

-- MAIN APPLICATION
addappid(921940)

-- MAIN APP DEPOTS / PACKAGES
addappid(921941, 1, "579b892428cf9c0e2f4cd2fbcda2cb72d1605d38c115a3fbd3c6aaad47cdada0")

