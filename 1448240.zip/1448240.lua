-- Lua provided by RyzenAPI
-- Game: House Soundtrack

-- MAIN APPLICATION
addappid(1448240)
-- Game: addappid(1448240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448241, 1, "1bf8f2742330dc0bd4dc5164897790c39ea148422449b20572688e8f38831155")
