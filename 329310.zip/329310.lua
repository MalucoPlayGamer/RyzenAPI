-- Lua provided by RyzenAPI 
-- Game: Tile Miner
addappid(329310)
addappid(329311, 1, "21d7bddb69862c5a146407f697a3c424d70df2f860caf1e1bf5085fb9fbbf589")
addappid(329313, 1, "0f1500514355fa3be9065a7208285c43a9bd92beb6fb20126ae7569ecc6986b7")
