-- Lua provided by RyzenAPI
-- Game: addappid(3272640)

-- MAIN APPLICATION
addappid(3272640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272642,0,"a0930c0ddbb5d791aa39e81a7148f46e464188bc3a43c9456e275bf98e3a324d")
