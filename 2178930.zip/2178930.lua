-- Lua provided by RyzenAPI
-- Game: Sexbot

-- MAIN APPLICATION
addappid(2178930)
addappid(3140610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178931, 1, "cb80e163ec34f6ba2692ac9c6e8cb13eb7c033df7e198eb1d4132066a11c28f4")

