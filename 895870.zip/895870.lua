-- Lua provided by RyzenAPI
-- Game: Project Wingman

-- MAIN APPLICATION
addappid(895870)

-- MAIN APP DEPOTS / PACKAGES
addappid(895871, 1, "baec9f1a727613a15b8f270c022c13daaf28f3558205a542970c8f8cb3ee7569")
addappid(2536180, 0, "5288aed61347456ecab313d510bea0e96f2cef2694172a9bc427278a45e518b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
