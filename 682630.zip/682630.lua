-- Lua provided by RyzenAPI
-- Game: Game: Box Maze 2 : Agent Cubert

-- MAIN APPLICATION
addappid(682630)
-- Game: addappid(682630)

-- MAIN APP DEPOTS / PACKAGES
addappid(682631, 1, "85f2f8caaaf70cb54b088437e710eef76739caa7d221a3c17e97e5ebcfd300ce")
