-- Lua provided by RyzenAPI
-- Game: And I Must Scream

-- MAIN APPLICATION
addappid(1022180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1022181, 1, "ab1b2f5c5d205515c07ff8f6b131c79dc3e51612a07b4929bd202bfb7bebf8e0")
