-- Lua provided by SkyAPI 
-- Game: AppID 1022180
addappid(1022180)
addappid(1022181, 1, "ab1b2f5c5d205515c07ff8f6b131c79dc3e51612a07b4929bd202bfb7bebf8e0")
