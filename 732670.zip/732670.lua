-- Lua provided by RyzenAPI
-- Game: Dyana Moto

-- MAIN APPLICATION
addappid(732670)
-- Game: addappid(732670)

-- MAIN APP DEPOTS / PACKAGES
addappid(732671, 1, "dc854f83c87a2b314572efc7d5d307244f40c5b62cf985850d38917ccce82af3")
