-- Lua provided by RyzenAPI
-- Game: yahtzee girl

-- MAIN APPLICATION
addappid(2635340)
-- Game: addappid(2635340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635341, 1, "448ab9077b13cb5b44b2a957fa4bf7f2b55d5d1e900c825ea5d79c4bd958cf6e")
