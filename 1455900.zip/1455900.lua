-- Lua provided by SkyAPI 
-- Game: Plunder Panic
addappid(1455900)
addappid(1455901, 1, "f3c0c21d776b9f28598e9d8c1975809e68036cea86e045cbe51be9e36076ad1f")
addappid(1455902, 1, "6a3b993017967de20c07546d1f782cf5b225a30c182682860175c3721fc437fd")
