-- Lua provided by RyzenAPI
-- Game: Drizzlepath

-- MAIN APPLICATION
addappid(355760)

-- MAIN APP DEPOTS / PACKAGES
addappid(355761, 1, "72401d3edac16cb179c9f9bf109815699f42e9fe29457f316e5223ab3b92ac98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
