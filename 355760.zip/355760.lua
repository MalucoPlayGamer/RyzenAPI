-- Lua provided by RyzenAPI
-- Game: 355760

-- MAIN APPLICATION
addappid(355760)
-- Game: addappid(355760)

-- MAIN APP DEPOTS / PACKAGES
addappid(355761, 1, "72401d3edac16cb179c9f9bf109815699f42e9fe29457f316e5223ab3b92ac98")
