-- Lua provided by RyzenAPI 
-- Game: Drizzlepath
addappid(355760)
addappid(355761, 1, "72401d3edac16cb179c9f9bf109815699f42e9fe29457f316e5223ab3b92ac98")
