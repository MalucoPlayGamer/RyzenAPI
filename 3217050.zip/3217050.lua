-- Lua provided by RyzenAPI
-- Game: Rental Store Simulator

-- MAIN APPLICATION
addappid(3217050)
-- Game: addappid(3217050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217051, 1, "7980d5f4c4363212621aabb7b379c7dfb2b7ea05933b5eecdf5a7fa6d4f779aa")
