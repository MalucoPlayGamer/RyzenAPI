-- Lua provided by RyzenAPI
-- Game: Car Puzzler

-- MAIN APPLICATION
addappid(774191)

-- MAIN APP DEPOTS / PACKAGES
addappid(774192,0,"d383f10c8107c44f708d564ababe3288cb8bb6d6f53b7cd0acf00d5eb0d331e0")

