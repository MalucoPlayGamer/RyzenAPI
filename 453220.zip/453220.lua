-- Lua provided by RyzenAPI
-- Game: Game: AppID 453220

-- MAIN APPLICATION
addappid(453220)
-- Game: addappid(453220)

-- MAIN APP DEPOTS / PACKAGES
addappid(453221, 1, "be8eec362fef5560069ab7d595a63768be754d3951b7f6df5bc8f046b100987a")
addappid(453223, 1, "5b9f09e6226734a9114cbea29bdf89b8eb6a621b99500305147cf373605b40e1")
