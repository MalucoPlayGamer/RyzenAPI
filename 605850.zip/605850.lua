-- Lua provided by RyzenAPI
-- Game: Pinball Inside: A VR Arcade Game

-- MAIN APPLICATION
addappid(605850)
-- Game: addappid(605850)

-- MAIN APP DEPOTS / PACKAGES
addappid(605851, 1, "e79168e551bdbf06c8c1a4d7fe7bada1555519d3bd16513187a2d9b8e2047016")
