-- Lua provided by SkyAPI 
-- Game: AppID 3037580
addappid(3037580)
addappid(3037581, 1, "6e34f28d479e7fba755ffc2f0f711eb06676ea6b8a6cb765a98b7c32c78f720e")
