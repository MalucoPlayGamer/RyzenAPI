-- Lua provided by RyzenAPI
-- Game: Outside the Blocks Demo

-- MAIN APPLICATION
addappid(3037580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037581, 1, "6e34f28d479e7fba755ffc2f0f711eb06676ea6b8a6cb765a98b7c32c78f720e")
