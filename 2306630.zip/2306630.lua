-- Lua provided by RyzenAPI
-- Game: Game: Frontline: Panzers & Generals Vol. I

-- MAIN APPLICATION
addappid(2306630)
-- Game: addappid(2306630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306631, 1, "bb1ab9e263529db37ace135e9ca6fde5c46f733846a49b04a51318c1833eb94b")
