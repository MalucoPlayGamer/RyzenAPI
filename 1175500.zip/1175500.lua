-- Lua provided by RyzenAPI
-- Game: 1175500

-- MAIN APPLICATION
addappid(1175500)
-- Game: addappid(1175500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175501, 1, "dac434ac7413b768e8b4c27c80187fdae13503e57b0f39156b394bf3a6e7ca4b")
