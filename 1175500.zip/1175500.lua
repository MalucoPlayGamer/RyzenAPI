-- Lua provided by RyzenAPI 
-- Game: AppID 1175500
addappid(1175500)
addappid(1175501, 1, "dac434ac7413b768e8b4c27c80187fdae13503e57b0f39156b394bf3a6e7ca4b")
