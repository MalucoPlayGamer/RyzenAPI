-- Lua provided by RyzenAPI
-- Game: BLACK BOX LSS - The Shining Immortal

-- MAIN APPLICATION
addappid(2434340)
