-- Lua provided by RyzenAPI
-- Game: TRANSFORMERS: BATTLEGROUNDS

-- MAIN APPLICATION
addappid(1177000) -- TRANSFORMERS: BATTLEGROUNDS
addappid(1315400) -- TRANSFORMERS BATLLEGROUNDS - Cube Arcade Mode Add-On
addappid(1315510) -- Transformers Battlegrounds - Nemesis Prime  Goldfire Bumblebee Pack
addappid(1315520) -- Transformers Battlegrounds - Shattered Spacebridge
addappid(1315540) -- Transformers Battlegrounds - Energon Autobots Pack
addappid(1315550) -- Transformers Battlegrounds - Gold Autobots Pack
addappid(1315560) -- Transformers Battlegrounds - Battle Hardened Autobots Pack
addappid(1315580) -- Transformers Battlegrounds - Reversed Autobots Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1177001, 1, "45a866d8600fec1f024fc9bfe9add8f8219efb7b150f89fde0b3bb77c8675985") -- Transformers Content

