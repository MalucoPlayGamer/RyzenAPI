-- Lua provided by RyzenAPI 
-- Game: AppID 1177000
addappid(1177000)
addappid(1177001, 1, "45a866d8600fec1f024fc9bfe9add8f8219efb7b150f89fde0b3bb77c8675985")
addappid(1273730)
