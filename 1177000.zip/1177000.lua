-- 1177000's Lua and Manifest Created by Hubcap Manifest
-- TRANSFORMERS: BATTLEGROUNDS
-- Created: October 01, 2025 at 03:32:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 7

-- MAIN APPLICATION
addappid(1177000) -- TRANSFORMERS: BATTLEGROUNDS
-- MAIN APP DEPOTS
addappid(1177001, 1, "45a866d8600fec1f024fc9bfe9add8f8219efb7b150f89fde0b3bb77c8675985") -- Transformers Content
setManifestid(1177001, "1383810069665747699", 5110067210)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1315400) -- TRANSFORMERS BATLLEGROUNDS - Cube Arcade Mode Add-On
addappid(1315510) -- Transformers Battlegrounds - Nemesis Prime  Goldfire Bumblebee Pack
addappid(1315520) -- Transformers Battlegrounds - Shattered Spacebridge
addappid(1315540) -- Transformers Battlegrounds - Energon Autobots Pack
addappid(1315550) -- Transformers Battlegrounds - Gold Autobots Pack
addappid(1315560) -- Transformers Battlegrounds - Battle Hardened Autobots Pack
addappid(1315580) -- Transformers Battlegrounds - Reversed Autobots Pack