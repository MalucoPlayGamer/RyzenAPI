-- Lua provided by RyzenAPI
-- Game: AppID 1177000

-- MAIN APPLICATION
addappid(1177000)
addappid(1273730)
-- Game: addappid(1177000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177001, 1, "45a866d8600fec1f024fc9bfe9add8f8219efb7b150f89fde0b3bb77c8675985")
