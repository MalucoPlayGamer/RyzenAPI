-- Lua provided by SkyAPI 
-- Game: Fireworks Simulator
addappid(323780)
addappid(323781, 1, "d981220433b6431f877c438d8232e735bd8103f24a8d9365ef17ef1e83f4fca0")
