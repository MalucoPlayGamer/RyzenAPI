-- Lua provided by RyzenAPI
-- Game: Game: Fireworks Simulator

-- MAIN APPLICATION
addappid(323780)
-- Game: addappid(323780)

-- MAIN APP DEPOTS / PACKAGES
addappid(323781, 1, "d981220433b6431f877c438d8232e735bd8103f24a8d9365ef17ef1e83f4fca0")
