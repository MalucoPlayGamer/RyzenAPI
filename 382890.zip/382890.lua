-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY V (Old ver.)

-- MAIN APPLICATION
addappid(382890)
-- Game: addappid(382890)

-- MAIN APP DEPOTS / PACKAGES
addappid(382891, 1, "4951add5f896bc23b684d2fde9c2e60490c218fd27e966ecf0a38f499891956a")
