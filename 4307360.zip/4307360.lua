-- 4307360's Lua and Manifest Created by Hubcap Manifest
-- Fallen Adventurer Anna
-- Created: August 14, 2026 at 11:07:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4307360) -- Fallen Adventurer Anna
-- MAIN APP DEPOTS
addappid(4307361, 1, "311dd1decce6ea03c4e79331a6ebb798cda11235618c08196b936314c63a6b73") -- Depot 4307361
setManifestid(4307361, "3242654475402290475", 789636124)
addappid(4307362, 1, "13e484a1a21a10b8ac820c9b025fb1c2ed1cc1769b3120781b9cbb1dd15b5088") -- Depot 4307362
setManifestid(4307362, "1912265020214993734", 803281118)
addappid(4307363, 1, "1522f583cd86d3f76ffaefe04fa9317abc8e2260a686674512ad4e1238c7e308") -- Depot 4307363
setManifestid(4307363, "8121392016997792377", 803276692)
addappid(4307364, 1, "410874e0bca515a84861a49e0f447d1dd14fa3d15e38fd475d8d67df5904d6b1") -- Depot 4307364
setManifestid(4307364, "7549213447259269158", 803276908)