-- Lua provided by RyzenAPI
-- Game: Fallen Adventurer Anna

-- MAIN APPLICATION
addappid(4307360) -- Fallen Adventurer Anna

-- MAIN APP DEPOTS / PACKAGES
addappid(4307361, 1, "311dd1decce6ea03c4e79331a6ebb798cda11235618c08196b936314c63a6b73") -- Depot 4307361
addappid(4307362, 1, "13e484a1a21a10b8ac820c9b025fb1c2ed1cc1769b3120781b9cbb1dd15b5088") -- Depot 4307362
addappid(4307363, 1, "1522f583cd86d3f76ffaefe04fa9317abc8e2260a686674512ad4e1238c7e308") -- Depot 4307363
addappid(4307364, 1, "410874e0bca515a84861a49e0f447d1dd14fa3d15e38fd475d8d67df5904d6b1") -- Depot 4307364

