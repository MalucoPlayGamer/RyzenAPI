-- Lua provided by RyzenAPI
-- Game: Dawn of the Monsters

-- MAIN APPLICATION
addappid(1642170)
addappid(2330620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642171, 1, "47327cdd19414132d60ec2d6dc0a634e84866aa8bd3d3756faa53a14a3de1933")
