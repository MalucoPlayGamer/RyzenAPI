-- Lua provided by RyzenAPI
-- Game: Game: AppID 1612850

-- MAIN APPLICATION
addappid(1612850)
-- Game: addappid(1612850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612851, 1, "5b8f8d0107612458d9d5540d3b88d65511b3a06edab5c0182ca1e32e0bada467")
