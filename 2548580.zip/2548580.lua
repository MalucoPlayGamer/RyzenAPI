-- Lua provided by RyzenAPI
-- Game: VAHLUNA CORP.

-- MAIN APPLICATION
addappid(2548580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2548581, 1, "03e3a1b797d755deb3f6f69af5f47c13eddf449c0593a1b34da4278a2c14f544")

