-- Lua provided by RyzenAPI
-- Game: addappid(2548580)

-- MAIN APPLICATION
addappid(2548580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548581, 1, "03e3a1b797d755deb3f6f69af5f47c13eddf449c0593a1b34da4278a2c14f544")
