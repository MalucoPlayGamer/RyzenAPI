-- Lua provided by SkyAPI 
-- Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Lucky Bag Ver. ECC High Poly Body Edition
addappid(2744180)
addappid(2744181, 1, "775ec780d59195532ba6b63d2dd7f49f610832262f75aca25465028ecb4a8963")
