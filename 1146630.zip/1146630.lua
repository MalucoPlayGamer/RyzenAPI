-- Lua provided by RyzenAPI 
-- Game: Yokai's Secret
addappid(1146630)
addappid(1146631, 1, "d6677ff8c86e5325c89f53ec13f6a2786d222216470de4ee86fe15a6d25de946")
