-- Lua provided by RyzenAPI
-- Game: Game: Days of War: Definitive Edition

-- MAIN APPLICATION
addappid(454350)
-- Game: addappid(454350)

-- MAIN APP DEPOTS / PACKAGES
addappid(454351, 1, "6f4495b67511df79a238aa8f57c68448635cbfd9b25ef67e99ad92e6446ee601")
