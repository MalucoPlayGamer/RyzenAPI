-- Lua provided by RyzenAPI
-- Game: Gold  Challenge

-- MAIN APPLICATION
addappid(1553970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553971, 1, "09892d7e5861ca927f1ed21e0eccab47585c3a46c79c6643e3d4fe0a86386511")

