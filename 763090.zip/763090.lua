-- Lua provided by RyzenAPI
-- Game: Aqua Fish

-- MAIN APPLICATION
addappid(763090)

-- MAIN APP DEPOTS / PACKAGES
addappid(763091, 1, "9c3f79cc5bf336922d63ae0b61d064244f6814a82b0959090bf99afebd20db85")
addappid(763092, 1, "f7b893e083113b3a5cfb06551c6761f330fe90f99dbbbe73b181738313aadbe1")
addappid(763093, 1, "495adf07ce36cbc2e12010b580dde7c9d31b7309e99b0d6f205a3dc5e84c0b01")
