-- Lua provided by RyzenAPI
-- Game: Amaranthine Voyage: The Living Mountain Collector's Edition

-- MAIN APPLICATION
addappid(647910)

-- MAIN APP DEPOTS / PACKAGES
addappid(647911,0,"97d7bec9ebecf5a8f04875164de59260df360dea17f7de938e0556351d0d3f03")

