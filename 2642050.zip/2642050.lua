-- Lua provided by SkyAPI 
-- Game: Naga Girls
addappid(2642050)
addappid(2642051, 1, "9c78ea8b81f64130f136174e39c15ab9616eec50e76a68d38ffa9d6dc7c1087e")
