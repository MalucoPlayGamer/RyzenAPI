-- Lua provided by RyzenAPI
-- Game: addappid(2642050)

-- MAIN APPLICATION
addappid(2642050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642051, 1, "9c78ea8b81f64130f136174e39c15ab9616eec50e76a68d38ffa9d6dc7c1087e")
