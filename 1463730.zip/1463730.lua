-- Lua provided by RyzenAPI 
-- Game: AppID 1463730
addappid(1463730)
addappid(1463731, 1, "c00a48b71c7c00d06fe96b909556f2520f6be02d510185f80e18609226160737")
