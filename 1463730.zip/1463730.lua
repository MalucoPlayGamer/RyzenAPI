-- Lua provided by RyzenAPI
-- Game: Arid

-- MAIN APPLICATION
addappid(1463730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1463731, 1, "c00a48b71c7c00d06fe96b909556f2520f6be02d510185f80e18609226160737")
