-- Lua provided by RyzenAPI
-- Game: Plastic Trick

-- MAIN APPLICATION
addappid(2916360)
-- Game: addappid(2916360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916362,0,"fb21c180f4b2d8490e950143869f5e303f6f6f7c1c0c337e18015adf571eb391")
