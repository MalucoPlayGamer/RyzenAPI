-- Lua provided by RyzenAPI
-- Game: Game: Knights & Guns

-- MAIN APPLICATION
addappid(2175090)
-- Game: addappid(2175090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175091, 1, "9cf97b4837834c0c2bed75af5c1f9c2215640699edf8af7ca1f881c1df315d14")
