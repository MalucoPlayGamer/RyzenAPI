-- Lua provided by RyzenAPI
-- Game: NeverGoingHome

-- MAIN APPLICATION
addappid(2837370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2837371, 1, "797628f454120b3dcf7845d21aa1449fa406222e24a3e2986228547521c600af")

