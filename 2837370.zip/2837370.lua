-- Lua provided by RyzenAPI
-- Game: NeverGoingHome

-- MAIN APPLICATION
addappid(2837370)
-- Game: addappid(2837370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837371, 1, "797628f454120b3dcf7845d21aa1449fa406222e24a3e2986228547521c600af")
