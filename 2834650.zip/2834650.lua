-- Lua provided by RyzenAPI 
-- Game: AppID 2834650
addappid(2834650)
addappid(2834651, 1, "3c7a77f634ebc7013d74805aa969113534ce5523976739443f4645667c57987f")
