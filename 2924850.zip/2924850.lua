-- Lua provided by RyzenAPI
-- Game: Cyberpunk Horror

-- MAIN APPLICATION
addappid(2924850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924851, 1, "3303245753dcbcdf31818bc41e56a9723c80da26d4007754044bfbeb56e84aa3")
