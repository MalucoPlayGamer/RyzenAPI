-- Lua provided by RyzenAPI 
-- Game: Creatures of Ava: Artbook & Original Soundtrack
addappid(3064170)
addappid(3064171, 1, "f25ae3f4513737f66e1107a96bf9cc689a4e1ec85f8e8ca69b0ee184ebb39301")
addappid(3064172, 1, "47bc30bdb9c5c13974129b9fbcf920edc0b1c3c984b5d3199cce95c29358f052")
