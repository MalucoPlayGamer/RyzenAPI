-- Lua provided by RyzenAPI
-- Game: Game: The Hunter's Journals - Tattered Sails

-- MAIN APPLICATION
addappid(1693580)
-- Game: addappid(1693580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693581, 1, "4f82d1a4fddf5fea08df76b2d439b65ac5415e62c781d4e00bd132c2cc82022b")
