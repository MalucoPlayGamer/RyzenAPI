-- Lua provided by RyzenAPI
-- Game: 1528020

-- MAIN APPLICATION
addappid(1528020)
-- Game: addappid(1528020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528021, 1, "75f44d4808edc21590188bb28b7da1e0a801e251cfa7e755f815a35562f7006c")
