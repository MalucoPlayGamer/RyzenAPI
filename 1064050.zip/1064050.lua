-- Lua provided by RyzenAPI
-- Game: 1064050

-- MAIN APPLICATION
addappid(1064050)
-- Game: addappid(1064050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064051, 1, "2316cbe4677b30cccb8041920aaced5af43090d7a8af86ffda1cbaf0481da264")
