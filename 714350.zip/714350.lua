-- Lua provided by RyzenAPI
-- Game: Game: AppID 714350

-- MAIN APPLICATION
addappid(714350)
-- Game: addappid(714350)

-- MAIN APP DEPOTS / PACKAGES
addappid(714351, 1, "c8ee23175ad1101dd27e617b88953cee3166f4fc418501c90b6f8df68fada847")
