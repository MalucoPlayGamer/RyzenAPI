-- Lua provided by RyzenAPI
-- Game: 1503040

-- MAIN APPLICATION
addappid(1503040)
-- Game: addappid(1503040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503041, 1, "cdf2dfbe5cd6773b20dd843a52749b6f645551c017e9d6808ec2c8f7704b22eb")
