-- Lua provided by RyzenAPI
-- Game: AppID 2144630

-- MAIN APPLICATION
addappid(2144630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144631, 1, "f2b1eeccf045a54f8ec0b19dea16eb47d819ce66c58bd14b810b8f28da118a22")
