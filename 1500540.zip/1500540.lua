-- Lua provided by RyzenAPI
-- Game: addappid(1500540)

-- MAIN APPLICATION
addappid(1500540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500542,0,"44d67bf2b122b6560de04037d1483ed905baceb51dfca3ec4b3d4d69d5771d3e")
