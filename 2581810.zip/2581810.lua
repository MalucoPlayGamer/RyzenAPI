-- Lua provided by SkyAPI 
-- Game: Color Splash: Birds
addappid(2581810)
addappid(2581811, 1, "9611e779a3c3afdf72c59661cc4e5da5818fce588d001f06ca76e22eb9ad6ba7")
