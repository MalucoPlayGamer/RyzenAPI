-- Lua provided by RyzenAPI
-- Game: Color Splash: Birds

-- MAIN APPLICATION
addappid(2581810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581811, 1, "9611e779a3c3afdf72c59661cc4e5da5818fce588d001f06ca76e22eb9ad6ba7")
