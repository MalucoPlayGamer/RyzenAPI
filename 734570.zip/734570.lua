-- Lua provided by RyzenAPI
-- Game: AppID 734570

-- MAIN APPLICATION
addappid(734570)

-- MAIN APP DEPOTS / PACKAGES
addappid(734571, 1, "142db27e9dfffe4abf698646a93dd33cc9a012ea85dcbf40e0150052566a5c6a")

