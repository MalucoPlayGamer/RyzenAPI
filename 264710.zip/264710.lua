-- Lua provided by RyzenAPI
-- Game: Subnautica

-- MAIN APPLICATION
addappid(264710)
-- Game: addappid(264710)

-- MAIN APP DEPOTS / PACKAGES
addappid(264712,0,"d764b2a41e9bdbf338f04948309614ea6f8d462073a610940aaf10cbfc35aa85")
addappid(264713,0,"6da396b527d2b570a039778566cef5c1e94ba486fefa835553a1831e40353dec")
