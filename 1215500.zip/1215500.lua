-- Lua provided by RyzenAPI
-- Game: addappid(1215500)

-- MAIN APPLICATION
addappid(1215500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215501, 1, "3de768f0322edbf63c3dadacdcc65cdf9ab6070ae81d095003b143c99f260458")
