-- Lua provided by RyzenAPI
-- Game: 无垢之恋 -绽放于春之花海- 试玩版

-- MAIN APPLICATION
addappid(2811260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811261, 1, "59358da4b4c6d0311e278d7893267270421731ada6b9c115111960acebd285ab")

