-- Lua provided by RyzenAPI
-- Game: Super Sami Roll

-- MAIN APPLICATION
addappid(1554640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554641, 1, "989e43b14381ae819768d7f09e39fcda14e7ed98ddbed8bb9c6c228b9ee905a7")
