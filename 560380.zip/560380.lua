-- Lua provided by RyzenAPI
-- Game: Game: AppID 560380

-- MAIN APPLICATION
addappid(560380)
-- Game: addappid(560380)

-- MAIN APP DEPOTS / PACKAGES
addappid(560381, 1, "9bdb5693b8cbe239bd87eb147abacb8ae4aa446744d1ca4a323bac611174bc8c")
