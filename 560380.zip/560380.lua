-- Lua provided by SkyAPI 
-- Game: AppID 560380
addappid(560380)
addappid(560381, 1, "9bdb5693b8cbe239bd87eb147abacb8ae4aa446744d1ca4a323bac611174bc8c")
