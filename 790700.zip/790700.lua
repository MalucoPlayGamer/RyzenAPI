-- Lua provided by RyzenAPI
-- Game: BugOut

-- MAIN APPLICATION
addappid(790700)

-- MAIN APP DEPOTS / PACKAGES
addappid(790702,0,"ee4168cecb0955b3141d7362619f1234b577e43057816b1853a82059176be473")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
