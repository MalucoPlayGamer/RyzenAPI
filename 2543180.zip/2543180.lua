-- Lua provided by RyzenAPI
-- Game: POPUCOM

-- MAIN APPLICATION
addappid(3025670) -- POPUCOM - Too Many Clothes Pack
addappid(3025970) -- POPUCOM - Rabbids Chic Pack
addappid(3929360) -- POPUCOM X ARKNIGHTS Collab Outfit Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(2543180, 1, "1f4ab702036f5e5ccc194451658a6691acbcda3fd204e1a0d9e752d2ec7377f6") -- POPUCOM
addappid(2543181, 1, "710ea94ede6b7341fc677cfed501f4a587ea3d576e9cecd917f056937548d455") -- Depot 2543181
addappid(2543182, 1, "02f5079b97e8a2548f5ae2e69794714c27fd0e1629ab5e911a659e5b773f3c23") -- Depot 2543182

