-- Lua provided by RyzenAPI
-- Game: POPUCOM

-- MAIN APPLICATION
addappid(2543180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543181, 1, "710ea94ede6b7341fc677cfed501f4a587ea3d576e9cecd917f056937548d455")
addappid(2543182, 1, "02f5079b97e8a2548f5ae2e69794714c27fd0e1629ab5e911a659e5b773f3c23")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3929360)
