-- Lua provided by RyzenAPI
-- Game: Sacrifice Your Friends

-- MAIN APPLICATION
addappid(1050160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050161, 1, "d15bc11e6b31c14446d63d7dd555ec40bce272d774af7dd0a21beccc1951a6a2")
