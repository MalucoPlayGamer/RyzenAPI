-- Lua provided by RyzenAPI
-- Game: Neonwall

-- MAIN APPLICATION
addappid(787650)

-- MAIN APP DEPOTS / PACKAGES
addappid(787651, 1, "21308730186e66c0c4d57bb15b7f1da843e53c045513bdc5996d49b574d22a59")
