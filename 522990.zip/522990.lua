-- Lua provided by RyzenAPI
-- Game: Spell Casting: Meowgically Enhanced Edition

-- MAIN APPLICATION
addappid(522990)

-- MAIN APP DEPOTS / PACKAGES
addappid(522991, 1, "37d64d1a5e216acc9fdd3fe0d260529c51a1146e7b940a19d9218966c7c11e4e")
