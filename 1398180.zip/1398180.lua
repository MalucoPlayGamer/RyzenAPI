-- Lua provided by RyzenAPI
-- Game: addappid(1398180)

-- MAIN APPLICATION
addappid(1398180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398181, 1, "6aa0c4f70e3f8a5d8c86752d181d49b6792bfa12f5e242501c8cbe6a036527e1")
