-- Lua provided by RyzenAPI
-- Game: Porcini

-- MAIN APPLICATION
addappid(1398180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398181, 1, "6aa0c4f70e3f8a5d8c86752d181d49b6792bfa12f5e242501c8cbe6a036527e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
