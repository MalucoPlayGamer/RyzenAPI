-- Lua provided by RyzenAPI 
-- Game: Slinki
addappid(354930)
addappid(354931, 1, "145b5566921bcbe57970aa0c3ac2241ca56a60bd17cc0602c9175af2f24ade49")
addappid(354932, 1, "806fc9f50b41a1e16992e23a76f2ad7c1dff06952063b53210122f0f3c806d87")
