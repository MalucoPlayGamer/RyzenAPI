-- Lua provided by RyzenAPI
-- Game: addappid(2437520)

-- MAIN APPLICATION
addappid(2437520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437521, 1, "e71cb614f7dad58f0a8dbf4e10b1ec5fd98e56a463e1a45bd7e6ceb969eb2701")
