-- Lua provided by RyzenAPI
-- Game: Game: ParkTo

-- MAIN APPLICATION
addappid(2134300)
-- Game: addappid(2134300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134301, 1, "fa40535bb1731aa3a9062f9e3bee9632693d06255da989faee75df1dbd90a484")
