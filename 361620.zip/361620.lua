-- Lua provided by RyzenAPI 
-- Game: True Bliss
addappid(361620)
addappid(361621, 1, "f6b74c7fc718c5a71a35a6933a24ddd6061a4b88d6ba02d9bc809c8bb61a594d")
