-- Lua provided by RyzenAPI
-- Game: V.O.D.K.A. Open World Survival Shooter

-- MAIN APPLICATION
addappid(1513840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513841, 1, "c150826ef06e4393841e2754a66b86f893964b13f31250b14c0cae11d5a7d7e7")
