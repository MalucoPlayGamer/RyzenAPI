-- Lua provided by RyzenAPI
-- Game: addappid(650900)

-- MAIN APPLICATION
addappid(650900)
addappid(3623450)

-- MAIN APP DEPOTS / PACKAGES
addappid(650900,0,"bc5cae3ce36c2ad6e30b57740c39222a0b2866498eeeee56baa7e25e6fe37c66")
