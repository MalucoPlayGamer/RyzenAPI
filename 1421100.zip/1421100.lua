-- Lua provided by RyzenAPI
-- Game: Game: Binaural Odyssey

-- MAIN APPLICATION
addappid(1421100)
-- Game: addappid(1421100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421101, 1, "a1130987710c8cb0c09a20807974b0e4b715a1141a3fce507f144516c92f42bc")
