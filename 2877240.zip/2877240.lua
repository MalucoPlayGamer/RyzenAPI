-- Lua provided by RyzenAPI
-- Game: 2877240

-- MAIN APPLICATION
addappid(2877240)
-- Game: addappid(2877240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877241, 1, "1b092c7ade12a51dedddec5748b4e6fad0a4d6ec2d5e4bc0aba8fbe2093e9660")
