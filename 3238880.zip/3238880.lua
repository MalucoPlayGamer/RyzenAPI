-- Lua provided by RyzenAPI
-- Game: 3238880

-- MAIN APPLICATION
addappid(3238880)
-- Game: addappid(3238880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238881, 1, "7cd5f16ceffba5008c4b6b50b31aabacd572822e814faf67d8d32787baa42e4e")
