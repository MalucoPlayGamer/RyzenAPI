-- Lua provided by RyzenAPI
-- Game: 2468400

-- MAIN APPLICATION
addappid(2468400)
addappid(2863170)
-- Game: addappid(2468400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468401, 1, "f58124265c6dd8e755a7481eca358c16989bacb6d187084e9afa1ada4d5eb5fd")
