-- Lua provided by RyzenAPI
-- Game: Hot Wheels Monster Trucks: Stunt Mayhem™

-- MAIN APPLICATION
addappid(2468400)
addappid(2863170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2468401, 1, "f58124265c6dd8e755a7481eca358c16989bacb6d187084e9afa1ada4d5eb5fd")

