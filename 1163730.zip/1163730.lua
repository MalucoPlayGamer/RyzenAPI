-- Lua provided by RyzenAPI
-- Game: Motor Assailant

-- MAIN APPLICATION
addappid(1163730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1163732,0,"1f33c131008f5698bc81dd14d980959d70c69265c3635f33a6d56e76fb3ba239")

