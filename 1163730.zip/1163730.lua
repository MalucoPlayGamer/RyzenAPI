-- Lua provided by RyzenAPI
-- Game: Motor Assailant

-- MAIN APPLICATION
addappid(1163730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163732,0,"1f33c131008f5698bc81dd14d980959d70c69265c3635f33a6d56e76fb3ba239")

