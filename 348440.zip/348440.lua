-- Lua provided by RyzenAPI
-- Game: addappid(348440)

-- MAIN APPLICATION
addappid(348440)

-- MAIN APP DEPOTS / PACKAGES
addappid(348441, 1, "9617ed8f0fc8ba90db13e0173f97787dc318d295fbc8ad3ab34669c99abef189")
