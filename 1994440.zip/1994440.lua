-- Lua provided by SkyAPI 
-- Game: Egglien
addappid(1994440)
addappid(1994441, 1, "b3cfc80dfb01762f612c36db1e26f2b46a2b83f58de5208af242651a69de6d92")
