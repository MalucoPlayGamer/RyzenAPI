-- Lua provided by RyzenAPI
-- Game: addappid(365380)

-- MAIN APPLICATION
addappid(365380)

-- MAIN APP DEPOTS / PACKAGES
addappid(365380,0,"d02d0ae98b68b78f9b9c4744219546357c695beadd24049eae3841914b90eb75")
