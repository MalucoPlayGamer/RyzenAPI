-- Lua provided by RyzenAPI
-- Game: 35000

-- MAIN APPLICATION
addappid(35000)
-- Game: addappid(35000)

-- MAIN APP DEPOTS / PACKAGES
addappid(35001, 1, "3e2759b83b703618be71cc1538fd020da79932b92071efa555ede93e26097024")
