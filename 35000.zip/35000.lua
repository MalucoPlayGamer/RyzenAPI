-- Lua provided by RyzenAPI
-- Game: Mini Ninjas

-- MAIN APPLICATION
addappid(35000)

-- MAIN APP DEPOTS / PACKAGES
addappid(35001, 1, "3e2759b83b703618be71cc1538fd020da79932b92071efa555ede93e26097024")
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

