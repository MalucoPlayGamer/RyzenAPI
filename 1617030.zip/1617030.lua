-- Lua provided by RyzenAPI
-- Game: tERRORbane

-- MAIN APPLICATION
addappid(1617030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617031, 1, "1f9968ac69f884a1cb12f89e436b4eb854f52d9096292faa85202c1ad77d5dc6")

