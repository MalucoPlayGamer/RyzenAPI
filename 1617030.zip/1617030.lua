-- Lua provided by SkyAPI 
-- Game: AppID 1617030
addappid(1617030)
addappid(1617031, 1, "1f9968ac69f884a1cb12f89e436b4eb854f52d9096292faa85202c1ad77d5dc6")
