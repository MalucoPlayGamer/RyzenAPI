-- Lua provided by RyzenAPI
-- Game: 839030

-- MAIN APPLICATION
addappid(839030)
-- Game: addappid(839030)

-- MAIN APP DEPOTS / PACKAGES
addappid(839031, 1, "2877170e29100d4bdd9b6dcf19dc3eda0ac2cdb6c5519f942f49da68be661259")
