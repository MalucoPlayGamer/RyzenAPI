-- Lua provided by RyzenAPI
-- Game: addappid(2059480)

-- MAIN APPLICATION
addappid(2059480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059481, 1, "430ed7f8e029a3ba968befe067966a3d2b6724a4fa0c82af87d12ca9d2881fba")
