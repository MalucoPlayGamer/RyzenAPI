-- Lua provided by SkyAPI 
-- Game: Disassembly 3D
addappid(747910)
addappid(747911, 1, "d11e026c4fea0e4a48a5529a94305dab00f148f1410c8a1bfc02da5b6064e4e7")
