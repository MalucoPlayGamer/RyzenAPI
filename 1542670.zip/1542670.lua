-- Lua provided by RyzenAPI
-- Game: Gachi Dungeon Master

-- MAIN APPLICATION
addappid(1542670)
-- Game: addappid(1542670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542671, 1, "89194b25eb5714b03661e83534e1f7a1d328f5135ce67c62335be8142cf0cc2e")
