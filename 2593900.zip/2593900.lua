-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Kidnap | 誘拐事件

-- MAIN APPLICATION
addappid(2593900)
-- Game: addappid(2593900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593901, 1, "593686724a16591b656424bffd25e371cc7a324b1ae8aa953357b045573888e5")
