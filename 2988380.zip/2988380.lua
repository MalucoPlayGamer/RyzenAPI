-- Lua provided by RyzenAPI
-- Game: Meow Moments: Olympicats

-- MAIN APPLICATION
addappid(2988380)
-- Game: addappid(2988380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988381, 1, "3ce5128e1cb0e9f539ace773db9884e2dd1ff7bb9e59202b262a5ab5592280f3")
