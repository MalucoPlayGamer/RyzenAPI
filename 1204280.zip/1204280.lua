-- Lua provided by RyzenAPI
-- Game: Renegade Grounds: Episode 2

-- MAIN APPLICATION
addappid(1204280)
-- Game: addappid(1204280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204281, 1, "f89480b1aa8796babc8b90104ac6a57a048254f7a09d08256e340eff5451ec7e")
