-- Lua provided by SkyAPI 
-- Game: Memory Novel - Girls Night Out
addappid(1941940)
addappid(1941941, 1, "9911e6b60aa8300eeb51e61bfcd341a15838507a3361033745cae55b4fdde4d5")
