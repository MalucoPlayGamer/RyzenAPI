-- Lua provided by RyzenAPI
-- Game: 2964010

-- MAIN APPLICATION
addappid(2964010)
-- Game: addappid(2964010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964011, 1, "d9b1b217b81e16721451142ae8adbfbeab62c99b50065a9420426ab0118fba6c")
