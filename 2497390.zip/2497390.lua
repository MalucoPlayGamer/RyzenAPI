-- Lua provided by RyzenAPI
-- Game: Viking Hiking

-- MAIN APPLICATION
addappid(2497390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497391, 1, "1e618acef598b6632a5be53287b8145aaf535a861ffd6582b9f085c20f2f9db7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
