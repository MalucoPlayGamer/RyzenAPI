-- Lua provided by RyzenAPI
-- Game: Viking Hiking

-- MAIN APPLICATION
addappid(2497390)
-- Game: addappid(2497390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497391, 1, "1e618acef598b6632a5be53287b8145aaf535a861ffd6582b9f085c20f2f9db7")
