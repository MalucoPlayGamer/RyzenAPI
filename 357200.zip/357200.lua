-- Lua provided by RyzenAPI
-- Game: addappid(357200)

-- MAIN APPLICATION
addappid(357200)

-- MAIN APP DEPOTS / PACKAGES
addappid(357201, 1, "f39038ab71dda9be498f7558263a783c886414d436dedd809717e3521e6c00ad")
