-- Lua provided by RyzenAPI
-- Game: AppID 1182150

-- MAIN APPLICATION
addappid(1182150)
-- Game: addappid(1182150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182151, 1, "ab509fddf86db333b8fa144bedf7ce82e9262f8b5d0ab16a82190e6a0f396c66")
