-- Lua provided by RyzenAPI
-- Game: Destropolis

-- MAIN APPLICATION
addappid(1316800)
-- Game: addappid(1316800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316801, 1, "8abf4d7bfc47b8556cc8e18c1d3de5c0463b5b560ba370b77c7dabd824e22f3a")
