-- Lua provided by RyzenAPI
-- Game: Just Shapes & Beats

-- MAIN APPLICATION
addappid(531510)

-- MAIN APP DEPOTS / PACKAGES
addappid(531511, 1, "846ebc3ea2e48f62b02f999f6012557a62532bf99d07747c0650ba582cd56e6e")
addappid(531512, 1, "8bbd5288779b80f12e5d557e37840e75daa483324000579826647d95bab05bdd")
addappid(531513, 1, "db8d6d9a53ddaf8a009b437e2b922601cdd7c2b35039f44d2b63a317da290862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
