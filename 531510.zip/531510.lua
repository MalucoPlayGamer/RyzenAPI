-- Lua provided by RyzenAPI 
-- Game: Just Shapes & Beats
addappid(531510)
addappid(531511, 1, "846ebc3ea2e48f62b02f999f6012557a62532bf99d07747c0650ba582cd56e6e")
addappid(531512, 1, "8bbd5288779b80f12e5d557e37840e75daa483324000579826647d95bab05bdd")
addappid(531513, 1, "db8d6d9a53ddaf8a009b437e2b922601cdd7c2b35039f44d2b63a317da290862")
