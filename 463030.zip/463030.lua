-- Lua provided by RyzenAPI
-- Game: Game: AppID 463030

-- MAIN APPLICATION
addappid(463030)
-- Game: addappid(463030)

-- MAIN APP DEPOTS / PACKAGES
addappid(463031, 1, "bb23f37c80b1d943c5dcc40f05d3a23184b0fc40505f8c122eedde8e70455dc4")
