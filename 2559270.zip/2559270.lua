-- Lua provided by RyzenAPI
-- Game: Gym Simulator 24

-- MAIN APPLICATION
addappid(2559270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559271, 1, "252240bd9ce52dac4ab6e78c116ee82a8cec8e5542292df9e7a171a3fb638f38")

