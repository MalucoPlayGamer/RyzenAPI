-- Lua provided by RyzenAPI
-- Game: Rugby 25

-- MAIN APPLICATION
addappid(2340870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340871, 1, "93ccfe6514668e6f5b1c0a8ab689650f762c3a6e18e7f21627be8e47f475801d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
