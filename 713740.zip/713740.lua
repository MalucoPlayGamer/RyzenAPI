-- Lua provided by RyzenAPI
-- Game: AppID 713740

-- MAIN APPLICATION
addappid(713740)
-- Game: addappid(713740)

-- MAIN APP DEPOTS / PACKAGES
addappid(713741, 1, "9fc88b566f1828c80b9269a17b4dec549cda57bd4037fb7ac51b28bbba5ee873")
