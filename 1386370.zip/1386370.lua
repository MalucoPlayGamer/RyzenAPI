-- Lua provided by RyzenAPI
-- Game: 1386370

-- MAIN APPLICATION
addappid(1386370)
-- Game: addappid(1386370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386371, 1, "e29a6f2dcf2bd694f3a218e857784f900606e9079a944b2caf1a9ed153eadb62")
