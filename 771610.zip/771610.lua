-- Lua provided by RyzenAPI
-- Game: 771610

-- MAIN APPLICATION
addappid(771610)
-- Game: addappid(771610)

-- MAIN APP DEPOTS / PACKAGES
addappid(771611, 1, "1c787f2651af2f0c7d0206abda51cd1805c1c140ad86bd14f43cb8c7900ea79e")
