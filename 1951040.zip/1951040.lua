-- Lua provided by RyzenAPI
-- Game: 黑帮英豪

-- MAIN APPLICATION
addappid(1951040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951042,0,"158d85bd98daa136ff8aa0e61bc50314fbc748a0e8ebaac4e89a6906b749646d")
addappid(1951043,0,"4ae4fb31cd56f7d1318f2c897ed166aec7e4a6299c5d547ea89284d6c4a33182")

