-- Lua provided by RyzenAPI
-- Game: Gungrave G.O.R.E

-- MAIN APPLICATION
addappid(1630110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630111, 1, "de7837e7f8f02bb4f6318a72ac8bd90ea58a6f54dd0d0c15b8fb16ce01b687c8")
addappid(1875760, 0, "aa183566d1c2bdb8ffd52c53202cff36d969890921a39b76d31cb9dff4ae79e4")
addappid(2144690, 0, "f97524694c112f9bbf31395d2a44c13d97d260e676fd671820b418be725d4235")
addappid(2144691, 0, "b228e7a1bf8baa323c565d325b946b47ac5f881f97cb71f97e2f0a1024e82ab3")
addappid(3072820, 0, "5244848c79a3c14e638384f14b0da4178ec771be9f18472b3cc22728bfc7117a")
addappid(3072830, 0, "18717481ef30c96d9761266cf4e7f8374e6672a303a5fe16df2f3f3bcd65ae82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
