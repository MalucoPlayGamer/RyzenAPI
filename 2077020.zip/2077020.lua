-- Lua provided by RyzenAPI
-- Game: Game: GirlPuzzle

-- MAIN APPLICATION
addappid(2077020)
addappid(2128960)
-- Game: addappid(2077020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077021, 1, "d81dcd69f6dcaae0b6044e9f4dd1490018a8fae35bf68bad286a24a6abd6f503")
