-- Lua provided by RyzenAPI
-- Game: Alien Shooter

-- MAIN APPLICATION
addappid(33100)

-- MAIN APP DEPOTS / PACKAGES
addappid(33101, 1, "dc30c4b2dfaf640760955db6fe89e6158899eac75984230e00438e0281289ddc")
addappid(33102, 1, "2435cd6120cfae76a693acbda50d9f884b532f8fa08c3656c9e730305448654c")
addappid(837860, 0, "c27d8ab36db093d5c7cabeb2d52f3f36d2ffc9c9de4eb67b76d1747b982ff6b5")
addappid(837861, 0, "018722e1451687a8579dc3e28e3906c1415d479661a0665c656c8077461c4b64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
