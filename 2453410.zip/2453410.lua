-- Lua provided by RyzenAPI
-- Game: Game Over Demo

-- MAIN APPLICATION
addappid(2453410)
-- Game: addappid(2453410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453411, 1, "40329d9252e85022320296381459863d03ce1bcfda78903314702d54df38b093")
