-- Lua provided by RyzenAPI
-- Game: 13 Candles

-- MAIN APPLICATION
addappid(2200420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200421, 1, "16d3ee403bb6944ac9644642274de1414dc8df62002a8f3a615e147a4eaf85e4")

