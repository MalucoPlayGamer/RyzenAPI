-- Lua provided by RyzenAPI
-- Game: MINDFIELD

-- MAIN APPLICATION
addappid(2587250)
-- Game: addappid(2587250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587251, 1, "944df1de33ec58bfe45df8852eb9e919cb38c3e39766bcbda9e6bc3ed311723f")
