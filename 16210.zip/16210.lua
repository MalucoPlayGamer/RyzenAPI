-- Lua provided by RyzenAPI
-- Game: AppID 16210

-- MAIN APPLICATION
addappid(16210)

-- MAIN APP DEPOTS / PACKAGES
addappid(16211, 1, "f3b863ef6d64e6fa7d6c2b20390dc31880c55a1578a68d571b1837d2c3eb7db5")

