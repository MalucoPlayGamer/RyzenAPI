-- Lua provided by RyzenAPI
-- Game: Life of Pepe

-- MAIN APPLICATION
addappid(1863250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863251, 1, "45dc5f0774ba879453047533532ccfe406072e68f80a69e89f1e99d0ca22a5f5")
