-- Lua provided by SkyAPI 
-- Game: Life of Pepe
addappid(1863250)
addappid(1863251, 1, "45dc5f0774ba879453047533532ccfe406072e68f80a69e89f1e99d0ca22a5f5")
