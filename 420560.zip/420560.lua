-- Lua provided by RyzenAPI
-- Game: Game: Firefighting Simulator - The Squad

-- MAIN APPLICATION
addappid(420560)
-- Game: addappid(420560)

-- MAIN APP DEPOTS / PACKAGES
addappid(420561, 1, "b9c305a15d2bf9b3391d9655749df9c99e797b311fdb5f4d137c7429732a9590")
