-- Lua provided by RyzenAPI 
-- Game: Firefighting Simulator - The Squad
addappid(420560)
addappid(420561, 1, "b9c305a15d2bf9b3391d9655749df9c99e797b311fdb5f4d137c7429732a9590")
