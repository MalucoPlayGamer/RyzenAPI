-- Lua provided by RyzenAPI
-- Game: Game: Lust & Legends

-- MAIN APPLICATION
addappid(2899030)
-- Game: addappid(2899030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899031, 1, "408731bef2c80bad4f420cdc3cd758419397c16b08bda7139e0b786337d4df37")
