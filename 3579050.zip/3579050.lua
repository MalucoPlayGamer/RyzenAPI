-- Lua provided by RyzenAPI
-- Game: Strawberry Chocolate

-- MAIN APPLICATION
addappid(3579050)
