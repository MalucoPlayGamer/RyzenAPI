-- Lua provided by RyzenAPI
-- Game: Foundation Soundtrack

-- MAIN APPLICATION
addappid(1015460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015460,0,"19aaffbecfc4deaa70ff8690dbba89405eb86e80becd9f41813e4e89cc4c1bc7")
