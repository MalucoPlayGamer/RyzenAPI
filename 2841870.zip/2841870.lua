-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2841870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841872,0,"fad73a0d64f6ffc1406212c724d63d6bf9b520242be052326344b85c0607dc5b")

