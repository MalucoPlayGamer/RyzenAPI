-- Lua provided by RyzenAPI 
-- Game: 你的绿帽子
addappid(3617430)
addappid(3617431, 1, "7af9bc0d159508017007cd04a4c3447db1af14144908856f9d909a37e39bb09f")
