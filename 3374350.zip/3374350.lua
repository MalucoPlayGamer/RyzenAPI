-- Lua provided by RyzenAPI
-- Game: Bad Cheese Demo

-- MAIN APPLICATION
addappid(3374350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374351, 1, "0977c0b9d02ee7ce169b2607a5c311169a48a0198a8912bccd0143954f0f28f0")
