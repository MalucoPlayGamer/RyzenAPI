-- Lua provided by RyzenAPI
-- Game: 460190

-- MAIN APPLICATION
addappid(460190)
-- Game: addappid(460190)

-- MAIN APP DEPOTS / PACKAGES
addappid(460191, 1, "04f7fce1fb39e349edbc5f344b29b065bb2160daf17ac63b71b40cd37982ef28")
addappid(528220, 0, "1f16f0b4e50e70c58519388a2a153bc89f13bd31dadc6af0e3557876d7865a84")
