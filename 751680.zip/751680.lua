-- Lua provided by RyzenAPI
-- Game: C64 & AMIGA Classix Remakes Sixpack 2

-- MAIN APPLICATION
addappid(751680)

-- MAIN APP DEPOTS / PACKAGES
addappid(751681,0,"f009b7d83cfc0c5cda37a7c30add7b4417ac01c6aa040719d7fea773e4eff4f1")

