-- Lua provided by RyzenAPI
-- Game: C64 & AMIGA Classix Remakes Sixpack 2

-- MAIN APPLICATION
addappid(751680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(751681,0,"f009b7d83cfc0c5cda37a7c30add7b4417ac01c6aa040719d7fea773e4eff4f1")

