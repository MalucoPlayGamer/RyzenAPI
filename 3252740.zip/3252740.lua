-- Lua provided by RyzenAPI
-- Game: Lust Night💋

-- MAIN APPLICATION
addappid(3252740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252741, 1, "fae4129e0373b39e81ff1647d91680f0ae4f4f7e138e5030ab4821b575871457")
