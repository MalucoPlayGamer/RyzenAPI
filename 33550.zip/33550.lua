-- Lua provided by RyzenAPI
-- Game: Time of Shadows

-- MAIN APPLICATION
addappid(33550)
addappid(33551)

-- MAIN APP DEPOTS / PACKAGES
addappid(33541,0,"1954b6e8bd929b7e577e1898f8f62aa1b5da58b979eebdcce83886b6a54efb7f")
