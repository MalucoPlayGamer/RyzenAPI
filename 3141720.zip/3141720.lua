-- Lua provided by RyzenAPI
-- Game: Monster Battles

-- MAIN APPLICATION
addappid(3141720)
addappid(3692910)
addappid(3916060)
addappid(3929620)
addappid(3929640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(3141721, 1, "faabc616950c55e2cd75e14bcf6f1dd39adfdfec8590082a77aeb3e9487c52ef")

