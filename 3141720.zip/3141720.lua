-- Lua provided by RyzenAPI
-- Game: Monster Battles

-- MAIN APPLICATION
addappid(3141720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141721, 1, "faabc616950c55e2cd75e14bcf6f1dd39adfdfec8590082a77aeb3e9487c52ef")

