-- Lua provided by RyzenAPI
-- Game: AppID 1582760

-- MAIN APPLICATION
addappid(1582760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582761, 1, "ca62dede360109b235bbfdcaf78cdc79bc1b39e4d65e7899d5aff07acef35e61")
