-- Lua provided by RyzenAPI
-- Game: Reknum Fantasy of Dreams

-- MAIN APPLICATION
addappid(1582760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1582761, 1, "ca62dede360109b235bbfdcaf78cdc79bc1b39e4d65e7899d5aff07acef35e61")

