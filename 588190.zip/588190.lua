-- Lua provided by RyzenAPI
-- Game: 588190

-- MAIN APPLICATION
addappid(588190)
-- Game: addappid(588190)

-- MAIN APP DEPOTS / PACKAGES
addappid(588191, 1, "c3591943dc43c671337de6990b554e8ccf9a128b931f48284dbeac3d1b5c8b27")
