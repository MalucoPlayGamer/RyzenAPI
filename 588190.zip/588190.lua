-- Lua provided by RyzenAPI
-- Game: AppID 588190

-- MAIN APPLICATION
addappid(588190)

-- MAIN APP DEPOTS / PACKAGES
addappid(588191, 1, "c3591943dc43c671337de6990b554e8ccf9a128b931f48284dbeac3d1b5c8b27")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(607830)
addappid(615420)
addappid(641970)
addappid(659990)
addappid(704260)
addappid(728700)
addappid(748850)
addappid(767260)
addappid(803170)
addappid(824810)
addappid(830720)
addappid(917090)
addappid(943070)
addappid(980460)
addappid(1029720)
addappid(1080280)
addappid(1101110)
addappid(1132240)
addappid(1146870)
addappid(1166420)
addappid(1184290)
addappid(1223290)
addappid(1223300)
addappid(1278510)
addappid(1344470)
addappid(1412710)
addappid(1444140)
addappid(1460370)
addappid(1493500)
addappid(1562950)
addappid(1649150)
addappid(1700390)
