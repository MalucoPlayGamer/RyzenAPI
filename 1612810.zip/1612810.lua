-- Lua provided by RyzenAPI
-- Game: Star Chef 2: Cooking Game

-- MAIN APPLICATION
addappid(1612810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1612811, 1, "ed9dba3955ab46f02a85dbaaf0c53f99bcf53688450098922aa08b63419799fd")

