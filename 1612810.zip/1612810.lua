-- Lua provided by RyzenAPI
-- Game: addappid(1612810)

-- MAIN APPLICATION
addappid(1612810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612811, 1, "ed9dba3955ab46f02a85dbaaf0c53f99bcf53688450098922aa08b63419799fd")
