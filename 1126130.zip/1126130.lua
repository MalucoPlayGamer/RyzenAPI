-- Lua provided by RyzenAPI
-- Game: addappid(1126130)

-- MAIN APPLICATION
addappid(1126130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126131, 1, "d7e89a54ba52a40284275d22f4a80cb2ed076355b58b59e9fdd7eb4a4fdde1a8")
