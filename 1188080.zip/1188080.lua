-- Lua provided by RyzenAPI
-- Game: Game: Cats are Liquid - A Better Place

-- MAIN APPLICATION
addappid(1188080)
-- Game: addappid(1188080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188081, 1, "6a254ec53d6cd8a59910009468b122ae5ff6cc8cbb3f8a1e2632722b58315c6b")
