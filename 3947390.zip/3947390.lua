-- Lua provided by RyzenAPI
-- Game: Ribbit Rogue

-- MAIN APP DEPOTS / PACKAGES
addappid(3947390, 1, "6d73a8db4309db0c62e48547152cc0cb3a3fc8412030b3b0f34ce18e15babc67") -- Ribbit Rogue
addappid(3947391, 1, "b33248be32fc6187a77dff98d804718da170adbdc1d70bc9d12dfb6c2143b7c9") -- Depot 3947391

