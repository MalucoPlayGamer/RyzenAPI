-- Lua provided by RyzenAPI
-- Game: Centum

-- MAIN APPLICATION
addappid(2625550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625552,0,"283a50e4cf32031a60029cae05b234150a329359db5857653f217d17f5d61030")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4182820)
