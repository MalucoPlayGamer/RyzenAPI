-- Lua provided by RyzenAPI
-- Game: HARVESTELLA

-- MAIN APPLICATION
addappid(1816300)
-- Game: addappid(1816300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816301, 1, "ee9bc17bfae12f0a3864b13ff4acdeefffb4a42d98740d738f71488009692478")
