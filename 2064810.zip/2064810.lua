-- Lua provided by RyzenAPI
-- Game: Game: CityDriver

-- MAIN APPLICATION
addappid(2064810)
-- Game: addappid(2064810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064811, 1, "7e25ccb0238f67152f4924b077ed53be6414306157c4bf813e3058ca755b0b0a")
