-- Lua provided by RyzenAPI
-- Game: CityDriver

-- MAIN APPLICATION
addappid(2064810)
addappid(2294470)
addappid(2294471)
addappid(2294472)
addappid(2294473)
addappid(2294474)
addappid(2294475)
addappid(2294476)
addappid(2294480)
addappid(2294481)
addappid(2563150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2064811, 1, "7e25ccb0238f67152f4924b077ed53be6414306157c4bf813e3058ca755b0b0a")

