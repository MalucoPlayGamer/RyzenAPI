-- Lua provided by SkyAPI 
-- Game: CityDriver
addappid(2064810)
addappid(2064811, 1, "7e25ccb0238f67152f4924b077ed53be6414306157c4bf813e3058ca755b0b0a")
