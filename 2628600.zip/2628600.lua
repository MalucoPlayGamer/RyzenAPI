-- Lua provided by RyzenAPI
-- Game: 疑案追了声

-- MAIN APPLICATION
addappid(2628600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2628601, 1, "d5f5e45cdba5993a8b079933fdc24ef2baec20aa78a7c39bbb3ff07c702dac96")

