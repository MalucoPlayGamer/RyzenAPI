-- Lua provided by RyzenAPI
-- Game: 疑案追了声

-- MAIN APPLICATION
addappid(2628600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628601, 1, "d5f5e45cdba5993a8b079933fdc24ef2baec20aa78a7c39bbb3ff07c702dac96")

