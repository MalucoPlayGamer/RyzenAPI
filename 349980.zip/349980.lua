-- Lua provided by RyzenAPI
-- Game: Gremlin Invasion: Survivor

-- MAIN APPLICATION
addappid(349980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(349981, 1, "c5c2916eb826493f47c23808aa2ff9368e43641c7858e3f0b391ad53158913da")
