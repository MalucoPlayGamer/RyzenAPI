-- Lua provided by RyzenAPI
-- Game: 349980

-- MAIN APPLICATION
addappid(349980)
-- Game: addappid(349980)

-- MAIN APP DEPOTS / PACKAGES
addappid(349981, 1, "c5c2916eb826493f47c23808aa2ff9368e43641c7858e3f0b391ad53158913da")
