-- Lua provided by RyzenAPI
-- Game: Construct VR - The Volumetric Movie

-- MAIN APPLICATION
addappid(1674620)
-- Game: addappid(1674620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674621, 1, "cc6806f0961419e76683f193bfcae010a556ed60490409d99e84b39647c35173")
