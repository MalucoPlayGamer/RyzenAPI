-- Lua provided by RyzenAPI
-- Game: Construct VR - The Volumetric Movie

-- MAIN APPLICATION
addappid(1674620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1674621, 1, "cc6806f0961419e76683f193bfcae010a556ed60490409d99e84b39647c35173")

