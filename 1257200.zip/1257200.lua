-- Lua provided by SkyAPI 
-- Game: False Myth
addappid(1257200)
addappid(1257201, 1, "327df4a0e0fa14e593d92c6009961de38c9361f97ab7b5a1ebe36a40c26c082a")
addappid(1257202, 1, "20f2f5848109ca513b363e0833a165b1e48d4fbee8e7291697fe93930cd93a41")
addappid(1257203, 1, "453ac5fa74f3f76ffd351f3fecec6648f0109df8e7e8f8395ed5c123259b0fb5")
