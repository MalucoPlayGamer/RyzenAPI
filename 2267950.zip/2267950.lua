-- Lua provided by RyzenAPI
-- Game: Route 66 Simulator Playtest

-- MAIN APPLICATION
addappid(2267950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267951, 1, "4a0b9d796446dcb7167b89281f114a938db7492a2eb9ec033810f66e0a405631")
