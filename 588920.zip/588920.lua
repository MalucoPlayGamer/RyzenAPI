-- Lua provided by RyzenAPI
-- Game: 588920

-- MAIN APPLICATION
addappid(588920)
-- Game: addappid(588920)

-- MAIN APP DEPOTS / PACKAGES
addappid(588921, 1, "9b8cf79607a5cc670d6faecd70f5b75d3095adceef629f5dee3ff55b4ec2df52")
addappid(658720, 0, "d5830ce19596a378d90d01206412abd9acaa678792ee7426fca760c03b00f1fe")
