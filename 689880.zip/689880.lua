-- Lua provided by RyzenAPI
-- Game: Game: Bee Aware! 2.0

-- MAIN APPLICATION
addappid(689880)
-- Game: addappid(689880)

-- MAIN APP DEPOTS / PACKAGES
addappid(689881, 1, "67e69076f2b68f299757e138da3664365642104f063351d73a26c1cb8ceb6cc7")
