-- Lua provided by RyzenAPI
-- Game: Boxing Saga

-- MAIN APPLICATION
addappid(526590)

-- MAIN APP DEPOTS / PACKAGES
addappid(526591, 1, "7038f53b41f444428c22422bf780a1007cbef22259e51dba5ad8ca115093ef98")

