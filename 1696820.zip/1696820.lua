-- Lua provided by RyzenAPI
-- Game: Low Light Combat

-- MAIN APPLICATION
addappid(1696820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696821, 1, "4e88115df7e6a825bd8ecb20f59d123470856dd5ac12d6f9a1ca5a67a3f0c275")
addappid(1696822, 1, "4fb013731d32d841e0de0e2134519670265ac8aa8b3c78eea10795ef7195edd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
