-- Lua provided by RyzenAPI
-- Game: Game: Low Light Combat

-- MAIN APPLICATION
addappid(1696820)
-- Game: addappid(1696820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696821, 1, "4e88115df7e6a825bd8ecb20f59d123470856dd5ac12d6f9a1ca5a67a3f0c275")
addappid(1696822, 1, "4fb013731d32d841e0de0e2134519670265ac8aa8b3c78eea10795ef7195edd2")
