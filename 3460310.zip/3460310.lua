-- Lua provided by RyzenAPI
-- Game: Ocean Otter Climb

-- MAIN APPLICATION
addappid(3460310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460311, 1, "855db486bc13316037eee36a8f344cb8ba6b25145011aebb23890ae194cfd134")

