-- Lua provided by RyzenAPI
-- Game: RKN Block Me: Telegram

-- MAIN APPLICATION
addappid(886110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(886111, 1, "e6cd20be484d2dd48fa6aa4d8780dfbe897ef64072189aa4db2eefd8cf270b1b")

