-- Lua provided by RyzenAPI
-- Game: addappid(886110)

-- MAIN APPLICATION
addappid(886110)

-- MAIN APP DEPOTS / PACKAGES
addappid(886111, 1, "e6cd20be484d2dd48fa6aa4d8780dfbe897ef64072189aa4db2eefd8cf270b1b")
