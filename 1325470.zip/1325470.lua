-- Lua provided by RyzenAPI
-- Game: 1325470

-- MAIN APPLICATION
addappid(1325470)
-- Game: addappid(1325470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325471, 1, "fe73ea34e8fbf2dcb1a4d550e637d20e49f8987d9de9350f7bcbd2ad5530f63d")
