-- Lua provided by RyzenAPI
-- Game: STCC - The Game Demo

-- MAIN APPLICATION
addappid(8700)
addappid(8701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")

