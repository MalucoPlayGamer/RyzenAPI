-- Lua provided by RyzenAPI
-- Game: Fellwood

-- MAIN APPLICATION
-- addappid(4632541) -- Depot 4632541 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4632540, 1, "cf4cbaaac75d47120a614b97f5a11374f751b8380d5a9d104db9d91a14741c53") -- Fellwood
addappid(4632542, 1, "44d37eb4548c5ea1dc1a16bd7d95f6da6940c4d25dd00efc660b0de2a164da3c") -- Depot 4632542
addappid(4632543, 1, "5a2d268c833eec3631f0c28fd78fa3ce1f13c448c3453e14dd60b8a72c262dc2") -- Depot 4632543

