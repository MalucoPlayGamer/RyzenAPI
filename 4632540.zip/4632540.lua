-- 4632540's Lua and Manifest Created by Hubcap Manifest
-- Fellwood
-- Created: August 15, 2026 at 00:13:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4632540, 1, "cf4cbaaac75d47120a614b97f5a11374f751b8380d5a9d104db9d91a14741c53") -- Fellwood
-- MAIN APP DEPOTS
addappid(4632542, 1, "44d37eb4548c5ea1dc1a16bd7d95f6da6940c4d25dd00efc660b0de2a164da3c") -- Depot 4632542
setManifestid(4632542, "6299831147325537141", 156101830)
addappid(4632543, 1, "5a2d268c833eec3631f0c28fd78fa3ce1f13c448c3453e14dd60b8a72c262dc2") -- Depot 4632543
setManifestid(4632543, "4395356471144362628", 172715067)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4632541) -- Depot 4632541 (empty depot)