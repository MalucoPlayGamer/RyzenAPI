-- Lua provided by RyzenAPI
-- Game: Glass Masquerade 2: Illusions

-- MAIN APPLICATION
addappid(935880)

-- MAIN APP DEPOTS / PACKAGES
addappid(935881, 1, "38bcf8a07964d2e15f2e3207e14bcdc6c801315f050016d13565ab597a4f6d2a")
addappid(935882, 1, "4a7fc1f64780eb047121d3de7deaa5845d98514853a4be26f796bba3db3e97f9")
