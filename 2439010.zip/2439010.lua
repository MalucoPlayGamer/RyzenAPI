-- Lua provided by RyzenAPI
-- Game: Game: Unibat

-- MAIN APPLICATION
addappid(2439010)
-- Game: addappid(2439010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439011, 1, "f329e1628542cd7bca945ffb0633bbe01e18de4d8aa93a326112a90339937344")
