-- Lua provided by RyzenAPI
-- Game: Open At Nine

-- MAIN APPLICATION
addappid(2270600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270601, 1, "c3b49af691e4f6d16b6594609daf53c92e3b19b3583ac4fe402cc3afd69ca006")
