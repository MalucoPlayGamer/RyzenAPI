-- Lua provided by RyzenAPI
-- Game: Desktop Fishing

-- MAIN APPLICATION
addappid(3411730)
-- Game: addappid(3411730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411731, 1, "beb5c113305901080b0f64e7c1c51827f3b6b6c7e7153dfe4dbc07b3d7c42032")
