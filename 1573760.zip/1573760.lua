-- Lua provided by RyzenAPI
-- Game: Game: Battle In The City

-- MAIN APPLICATION
addappid(1573760)
-- Game: addappid(1573760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573761, 1, "84ed744398dd4e49369449f545cc98f6525702bea2f56e842b1023253a0f5d26")
