-- Lua provided by RyzenAPI
-- Game: Tales of Zestiria

-- MAIN APPLICATION
addappid(351970)

-- MAIN APP DEPOTS / PACKAGES
addappid(351971, 1, "fb41a2aa1edc042501d542a866fbe16259fe81b314d176500d2b30aba3a4c971")
addappid(351972, 1, "2ffa1ed6db08e96e8269ddfc221d4ae0c204d556049f302007f0f1430cb2db3e")
addappid(351973, 1, "b4c488ec62f59cfacf0cc3ced66b0f5d4e70aefca1b9734b41eccd69b2471e1d")
addappid(351974, 1, "234ef3cc5c49657c88713d6ba96f816f898180a22108297a3f973f589e722944")
addappid(351975, 1, "ef2880328d633d51408599d44c70cd94bd1a6315f88700ee9f1eea6ee7a8a930")
addappid(351976, 1, "23d26d8f2cb927c29c72dead5471a0dc4aeb661410fe8332159d74f255054ab6")
addappid(351977, 1, "97faf5ff341fc8871eb29fad847eabea4905bad6502301a19c738ac01ea029ce")
addappid(351978, 1, "351b213b966ddb5926aac44e8b5dbad572ed12edb84efc32a8111616979e91f1")
addappid(351979, 1, "24190f52c61c42b939d2e49dfeb4af8eab0915307d8e631a1dd628c1e43ce659")
addappid(382453, 0, "47d3d0c4f455e91eb66cd57ecd7ef601044f893ce82d7823be913c3daad95d09")
addappid(382454, 0, "0dd852336f6ce2724058ecb6a4db2cafda8228c5339c5b02fbc7d5a1ead5632d")
addappid(382455, 0, "56231208c61405f7606b1c4df9c1ab5cdac64ae6016bf03c81c97d6b35f0ba8f")
addappid(382456, 0, "463aa2d95ca537ba240eccfdc747c7255478289f677e00921a48df2f7c27c447")
addappid(382457, 0, "e9a6765372049396db0a840096f6a093d2fbbff02feb1a2b9d716a584308ba47")
addappid(382458, 0, "522c230a217bdfb48ae38bf2a7de8a7f5f241b0d7e8a114794bf5933d7b98e80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(382450)
addappid(382451)
addappid(382452)
addappid(382460)
addappid(382461)
addappid(382462)
addappid(382463)
addappid(382464)
addappid(382465)
addappid(382466)
addappid(382467)
addappid(382468)
addappid(382469)
addappid(382470)
