-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Atmospheric Piano Channel

-- MAIN APPLICATION
addappid(3055080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3055080,0,"e39253ba495db02d1cb4cd69a6b9a7aba7b0d9439b2ee13cea0d153364b73267")

