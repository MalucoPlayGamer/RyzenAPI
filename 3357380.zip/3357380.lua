-- Lua provided by SkyAPI 
-- Game: AppID 3357380
addappid(3357380)
addappid(3357381, 1, "f6ddf3011a0f746ebcc750cf1315450781e39e18ea59864afb2c3f961708685f")
