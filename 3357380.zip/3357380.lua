-- Lua provided by RyzenAPI
-- Game: AppID 3357380

-- MAIN APPLICATION
addappid(3357380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3357381, 1, "f6ddf3011a0f746ebcc750cf1315450781e39e18ea59864afb2c3f961708685f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
