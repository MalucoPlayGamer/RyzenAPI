-- Lua provided by RyzenAPI
-- Game: addappid(1394580)

-- MAIN APPLICATION
addappid(1394580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394581, 1, "654e2b24295a1ba03f1d92fd0348c2cdfc4dc4a0f6d8647730279afdccf60fe8")
