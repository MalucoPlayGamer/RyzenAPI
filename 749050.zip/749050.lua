-- Lua provided by RyzenAPI
-- Game: 749050

-- MAIN APPLICATION
addappid(749050)
-- Game: addappid(749050)

-- MAIN APP DEPOTS / PACKAGES
addappid(749051, 1, "adced7228b901b4ac5320447434b6da35b007b5062bc36cc44f377b186a1e8d8")
