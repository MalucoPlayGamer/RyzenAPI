-- Lua provided by RyzenAPI
-- Game: The 111th Soul

-- MAIN APPLICATION
addappid(749050)

-- MAIN APP DEPOTS / PACKAGES
addappid(749051, 1, "adced7228b901b4ac5320447434b6da35b007b5062bc36cc44f377b186a1e8d8")
