-- Lua provided by RyzenAPI
-- Game: AppID 287680

-- MAIN APPLICATION
addappid(287680)

-- MAIN APP DEPOTS / PACKAGES
addappid(287681, 1, "8dbfc2a3232145bc37fe8e6d75dbd165fa675a623f0b98c7376d719caca8b8ab")
addappid(287682, 1, "d0be20adb240d52904d2f6d43cd4bc8d3688a72ee061d33217a469eebbc07e61")
addappid(287683, 1, "ce5cb51733ca1a94aded4842bf2e5c02b9f90612ee5231b0057658354784cfb2")
addappid(287684, 1, "2809d62e7baeba10df345d4ae28b989a99ca4ae26db4f1d0d97149f0a4646b25")
addappid(287685, 1, "507fbc9315a8110c86fb23b63d3b4b42e8778af34f4e96013bf192e0e64d9fe2")
addappid(287686, 1, "afc7cf0d20097fabcc405e13eea9070e68bb480a8d5e4ecdb6527cde53d4eb05")
addappid(287687, 1, "69c7a41aba9bcc8db9c46ba5291b54796d6246a717212ad8b1c7e7b221f34aea")
addappid(287688, 1, "9dfb7e38f227310b56711cf0646dcd04674b4809ff09c88372246b4fb7861d3d")
addappid(287689, 1, "8bb70ca2c7cfc2a25087cab890593a7b38d193955d8c0d4a33a1041bbb871ef2")
addappid(287690, 1, "1a60e5f333164a83632fb46de9446c8c1eb96e396e943a355fbef0e6e9003c54")
addappid(287691, 1, "c562f620f34968815e66c42cb1bdec19ad3de4f7cf9bfd6d1c7752d52d320616")
addappid(287692, 1, "badc4f1d5b9de8f465f5a754a27338decc7f07084b4523005043c26e404a1f33")
addappid(287693, 1, "b0425bcdc5bc6d685464f9db9d26a4a6044d7c4b93b07f07c10a75543bf93ee6")
addappid(287694, 1, "5010ac113495fb213a166b44af62ee91af9bb73655ef80efa5f5d6cf2bec4a3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(326451)
addappid(326452)
addappid(328030)
addappid(328031)
addappid(328040)
addappid(328041)
addappid(332170)
addappid(332180)
