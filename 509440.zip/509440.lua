-- Lua provided by RyzenAPI
-- Game: God Simulator

-- MAIN APPLICATION
addappid(509440)
-- Game: addappid(509440)

-- MAIN APP DEPOTS / PACKAGES
addappid(509441, 1, "7490f4734da09b76d9e65728531b5acd05302a020695a9f4e6f8dde82f587da2")
