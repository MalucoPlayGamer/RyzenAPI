-- Lua provided by SkyAPI 
-- Game: Fleshlight Squad - Fleshlightize -
addappid(2588590)
addappid(2588591, 1, "688a14b0674389b108952cd133dbd8f22a9829558004028bea232e900d3bdf55")
addappid(2588593, 1, "af463defa0f7966b93a6786925ebc49fbd246ca2198384e44be388a46c82b21e")
addappid(2588595, 1, "793458638c9263fef7cdf0b3a96aa3483836a5fcdc63e7a3f4502c89d53315cc")
addappid(2588597, 1, "bd97343d8ca3a83ea6a53bf2eb84e71f406ffa61129dd2e6cb14b062a15ccf78")
