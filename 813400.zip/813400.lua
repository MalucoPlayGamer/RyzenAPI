-- Lua provided by RyzenAPI
-- Game: 在这个世界的尽头，你与我被遗忘的传说（in the world end, you and me the forget's legend）

-- MAIN APPLICATION
addappid(813400)

-- MAIN APP DEPOTS / PACKAGES
addappid(813401,0,"158420a49ad3fcbec869784f4376ea52ae5d71c02d852918c2bf951477c62c00")

