-- Lua provided by RyzenAPI
-- Game: Hammerwatch II

-- MAIN APPLICATION
addappid(1538970)
addappid(2326570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1538971, 1, "dfedfe3c03f180c326c777579dd6c396988ced2ab833c4ffa12bbbe5c0670666")
addappid(1538972, 1, "e95246e91cad8a50160c99d50fe8485c4547a15a3338242f2cc42bc1c67be35a")

