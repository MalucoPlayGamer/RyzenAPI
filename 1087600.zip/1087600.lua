-- Lua provided by RyzenAPI
-- Game: 1087600

-- MAIN APPLICATION
addappid(1087600)
-- Game: addappid(1087600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087601, 1, "3fed93f3e8dd653c07871f901f14c5fa1b18a037cbc5ce56f8300d42feecadb1")
