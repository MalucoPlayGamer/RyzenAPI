-- Lua provided by SkyAPI 
-- Game: AppID 1087600
addappid(1087600)
addappid(1087601, 1, "3fed93f3e8dd653c07871f901f14c5fa1b18a037cbc5ce56f8300d42feecadb1")
