-- Lua provided by RyzenAPI
-- Game: FINAL ARCHER VR

-- MAIN APPLICATION
addappid(1087600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1087601, 1, "3fed93f3e8dd653c07871f901f14c5fa1b18a037cbc5ce56f8300d42feecadb1")

