-- Lua provided by RyzenAPI
-- Game: CodeSpells

-- MAIN APPLICATION
addappid(324190)

-- MAIN APP DEPOTS / PACKAGES
addappid(324191, 1, "16cae4b5005455e0bfa7e79b265bc49a786ba49d6797494bb3a59e73d77bba08")
addappid(324193, 1, "c438ca2f4ac681f904bb82b01af25cc643d6e7e156d9ad94a34549d5e474c847")

