-- Lua provided by RyzenAPI
-- Game: Death Swap: End As One

-- MAIN APPLICATION
addappid(2213390)
-- Game: addappid(2213390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213391, 1, "d54db2a65b77cf8ca14e859240f9a23855c6e4323f46736ad2f0e883fe7faed7")
