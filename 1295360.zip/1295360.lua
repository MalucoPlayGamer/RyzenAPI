-- Lua provided by RyzenAPI 
-- Game: AppID 1295360
addappid(1295360)
addappid(1295361, 1, "7fb252031de19061b04c08697f7c538cc858010661d4c9a57b589059dcff66e4")
