-- Lua provided by RyzenAPI
-- Game: Game: AppID 1295360

-- MAIN APPLICATION
addappid(1295360)
-- Game: addappid(1295360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295361, 1, "7fb252031de19061b04c08697f7c538cc858010661d4c9a57b589059dcff66e4")
