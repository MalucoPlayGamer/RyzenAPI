-- Lua provided by RyzenAPI
-- Game: Dune: Awakening

-- MAIN APPLICATION
addappid(3596810) -- Dune Awakening - Season Pass
addappid(3596890) -- Dune Awakening - Wildlife of Arrakis
addappid(3596900) -- Dune Awakening - Lost Harvest DLC
addappid(3596920) -- Dune Awakening - Raiders of the Broken Lands DLC
addappid(3596930) -- Dune Awakening - The Water Wars DLC
addappid(3604150) -- Dune Awakening - Terrarium of MuadDib
addappid(3604160) -- Dune Awakening - Dune (2021) Film Stillsuit
addappid(3604170) -- Dune Awakening - Sardaukar Bator Armor
addappid(3604180) -- Dune Awakening - Caladan Palace Building Set
addappid(3604190)
addappid(3604200) -- Dune Awakening - Deluxe Edition Upgrade
addappid(3604210) -- Dune Awakening - Sunset Dye Global Swatch
addappid(3604270) -- Dune Awakening - Dusk Rider Sandbike Swatch
addappid(3604280) -- Dune Awakening - Blue Dasher Ornithopter Swatch
addappid(3796170) -- Dune Awakening - Ultimate Edition Upgrade
addappid(4156640) -- Dune Awakening - Gift of the Sands Free Pack
addappid(4857580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1172710, 1, "69dc68fc6a5bb50adb32e772e7746d731a85cd2e24df94d25f3208cd3526f454") -- Dune: Awakening
addappid(1172711, 1, "fca2f8a025b411ec4d846fe6bf97d1d0589a93bb56a2527fb857a4bfe4aac2b3") -- Depot 1172711
addappid(1172719, 1, "7b18d5460246bac4620753a4ed05b5f4e42c3c6ad1fce01a9508eb6a9fac5e08") -- Depot 1172719
addappid(3604191, 1, "c572ef768fbab850c416f10be050771ed650c63967a64819d1b61d1a34e3cbaa") -- Dune Awakening - Digital Artbook - Depot 3604191

