-- Lua provided by RyzenAPI
-- Game: addappid(1172710)

-- MAIN APPLICATION
addappid(1172710)
addappid(3596810)
addappid(3596890)
addappid(3596900)
addappid(3604150)
addappid(3604160)
addappid(3604170)
addappid(3604180)
addappid(3604190)
addappid(3604200)
addappid(3604210)
addappid(3604270)
addappid(3604280)
addappid(3796170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172711, 1, "fca2f8a025b411ec4d846fe6bf97d1d0589a93bb56a2527fb857a4bfe4aac2b3")
addappid(1172719, 1, "7b18d5460246bac4620753a4ed05b5f4e42c3c6ad1fce01a9508eb6a9fac5e08")
addappid(3604191, 0, "c572ef768fbab850c416f10be050771ed650c63967a64819d1b61d1a34e3cbaa")
