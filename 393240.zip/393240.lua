-- Lua provided by RyzenAPI
-- Game: Sir! I'd Like To Report A Bug!

-- MAIN APPLICATION
addappid(393240)

-- MAIN APP DEPOTS / PACKAGES
addappid(393241, 1, "f87ac86f6849cb6e6f2077a49bf90309e67e3150490676a78993ec28d36392d0")
