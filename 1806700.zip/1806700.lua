-- Lua provided by RyzenAPI
-- Game: Monster Girl Manager

-- MAIN APPLICATION
addappid(1806700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806701, 1, "148dec586ce66477fc74a666277f788b22934d7494a02f02aa9bed036950ed5a")

