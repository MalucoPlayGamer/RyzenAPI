-- Lua provided by RyzenAPI
-- Game: Monster Girl Manager

-- MAIN APPLICATION
addappid(1806700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806701, 1, "148dec586ce66477fc74a666277f788b22934d7494a02f02aa9bed036950ed5a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
