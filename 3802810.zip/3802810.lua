-- Lua provided by RyzenAPI
-- Game: Game: AppID 3802810

-- MAIN APPLICATION
addappid(3802810)
-- Game: addappid(3802810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3802811, 1, "47b995610637cf4656e4337318d08a49984eec7bce6f12761a3c7aad84500db0")
