-- Lua provided by RyzenAPI
-- Game: addappid(979290)

-- MAIN APPLICATION
addappid(979290)

-- MAIN APP DEPOTS / PACKAGES
addappid(979291, 1, "a016783427ae14fd425d8d7b4a3e075478d86ae0f9a92c62d604f74c281d6067")
