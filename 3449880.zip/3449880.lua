-- Lua provided by SkyAPI 
-- Game: Countryside Life
addappid(3449880)
addappid(3449881, 1, "2dd4d5bf5d6096f07217685e807768e2dd9faf76869528cbc380ce95d1aae733")
addappid(3449882, 1, "9c8a2f83b24fc12b85bf6b7d595d00842453c61eb21b836598e9fb58e4b6fce4")
