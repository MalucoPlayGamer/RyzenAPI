-- Lua provided by RyzenAPI
-- Game: AppID 45750

-- MAIN APPLICATION
addappid(45750)
-- Game: addappid(45750)

-- MAIN APP DEPOTS / PACKAGES
addappid(45751, 1, "a02880af988a271f24f518e0c108b1067cebbf8f3e58d4449f8155be61cb54b6")
