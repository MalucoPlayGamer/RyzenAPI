-- Lua provided by RyzenAPI
-- Game: Unit Down

-- MAIN APPLICATION
addappid(1538350)
-- Game: addappid(1538350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538351, 1, "49fa358570fb524b37cc0864321a78461363ee365be65d656b5b52723c3ab29c")
