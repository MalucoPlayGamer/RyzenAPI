-- Lua provided by RyzenAPI
-- Game: Paint Warfare

-- MAIN APPLICATION
addappid(1602290) -- Paint Warfare - Supporter Pack
addappid(1945090) -- Paint Warfare - Glizzy Pack
addappid(2006010) -- Paint Warfare - Democratic Dino
addappid(2280310) -- Paint Warfare - Pine Tree
addappid(2728370) -- Shark Costume

-- MAIN APP DEPOTS / PACKAGES
addappid(1190150, 1, "8bf909535e191bba32c1fcaed977d842cc59dd18a2e38b1163c4c77aea1b2271") -- Paint Warfare
addappid(1190151, 1, "060616f77992bfc870a40fd6396124479764468631f420ff70c8832248597bbf") -- Windows Content
addappid(1190152, 1, "06c7c14f98b586924929d49ae54adfd2d886ffc068d61cffd8f6acc02bf68d06") -- MacOS Content
addappid(1190153, 1, "37d23640b87239d20bf47c05af8506b38450b3b88c23b1987feaa2becc3ee9bc") -- Linux Content

