-- Lua provided by RyzenAPI 
-- Game: Cursed Enigma - Priest and Prayers
addappid(2701120)
addappid(2701121, 1, "1b2e713e5497344a9eb2153026d2a36d8225810ff3a69e6be91cf311036ecd5f")
