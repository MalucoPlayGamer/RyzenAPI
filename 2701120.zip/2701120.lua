-- Lua provided by RyzenAPI
-- Game: addappid(2701120)

-- MAIN APPLICATION
addappid(2701120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701121, 1, "1b2e713e5497344a9eb2153026d2a36d8225810ff3a69e6be91cf311036ecd5f")
