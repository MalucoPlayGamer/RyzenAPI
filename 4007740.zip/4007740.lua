-- Lua provided by RyzenAPI
-- Game: Top Heroes

-- MAIN APPLICATION
addappid(4007740)

