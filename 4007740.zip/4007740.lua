-- Lua provided by RyzenAPI
-- Game: Top Heroes

-- MAIN APPLICATION
addappid(4007740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

