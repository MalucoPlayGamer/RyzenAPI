-- Lua provided by RyzenAPI
-- Game: 1750000

-- MAIN APPLICATION
addappid(1750000)
-- Game: addappid(1750000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750001, 1, "26d6315e88f90f70ff2938a19ed6f626bd5ccd705ef8cd19030932637610a2fa")
