-- Lua provided by RyzenAPI
-- Game: Adventures with Alan Parkour 3D

-- MAIN APPLICATION
addappid(2540410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540411, 1, "c7b51eb5e0376ddebfc34f9dff49563b71302ff69710ec75ca224ba660c60c59")
