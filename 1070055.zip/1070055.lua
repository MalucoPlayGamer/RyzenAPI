-- Lua provided by RyzenAPI
-- Game: 1070055

-- MAIN APPLICATION
addappid(1070055)
-- Game: addappid(1070055)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070055,0,"6e6a8b3576658ca1fa805fcf6611a1f306ead5a57972c4cc6428970fb59a1795")
