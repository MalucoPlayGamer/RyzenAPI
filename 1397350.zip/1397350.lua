-- Lua provided by RyzenAPI
-- Game: 好久不见 - Long Time No See

-- MAIN APPLICATION
addappid(1397350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397351, 1, "b42018a554070c580907c29330e758da74cd81f1a1369a0d0953e56107fe6170")

