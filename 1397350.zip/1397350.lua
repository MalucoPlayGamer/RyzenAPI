-- Lua provided by RyzenAPI 
-- Game: AppID 1397350
addappid(1397350)
addappid(1397351, 1, "b42018a554070c580907c29330e758da74cd81f1a1369a0d0953e56107fe6170")
