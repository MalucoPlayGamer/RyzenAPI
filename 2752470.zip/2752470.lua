-- Lua provided by RyzenAPI
-- Game: AppID 2752470

-- MAIN APPLICATION
addappid(2752470)
-- Game: addappid(2752470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752471, 1, "e188e6b9bf65bc6f2a64d06488b240d1351cfb7a96b295d1ad01bd979ac7c8ff")
