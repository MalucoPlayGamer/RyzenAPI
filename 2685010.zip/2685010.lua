-- Lua provided by RyzenAPI
-- Game: Lifeforms: Binary Fission Demo

-- MAIN APPLICATION
addappid(2685010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685011, 1, "670a3a87140f456bf6d653858d018a99cac60f40c2eca2f36b34ce91c225091d")

