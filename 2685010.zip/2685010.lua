-- Lua provided by SkyAPI 
-- Game: Lifeforms: Binary Fission Demo
addappid(2685010)
addappid(2685011, 1, "670a3a87140f456bf6d653858d018a99cac60f40c2eca2f36b34ce91c225091d")
