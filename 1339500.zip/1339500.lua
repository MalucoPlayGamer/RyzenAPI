-- Lua provided by SkyAPI 
-- Game: Gym Tycoon
addappid(1339500)
addappid(1339501, 1, "2cb18fe132495083a8ae13d2d86dd8d18809c98f70bb0422ecce843e6243d54e")
