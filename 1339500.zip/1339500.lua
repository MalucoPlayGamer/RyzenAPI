-- Lua provided by RyzenAPI
-- Game: 1339500

-- MAIN APPLICATION
addappid(1339500)
-- Game: addappid(1339500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339501, 1, "2cb18fe132495083a8ae13d2d86dd8d18809c98f70bb0422ecce843e6243d54e")
