-- Lua provided by RyzenAPI
-- Game: Game: The Tape

-- MAIN APPLICATION
addappid(387930)
-- Game: addappid(387930)

-- MAIN APP DEPOTS / PACKAGES
addappid(387931, 1, "7fd20c78c9e7a93aadf1af3d5535b688c74c8f07ded6a8f290ef66950f6b67bf")
addappid(387932, 1, "d83901ecd122507b353cb874989ba89c444402c692b0153405717ab3683f71ce")
