-- Lua provided by RyzenAPI 
-- Game: Revive & Prosper
addappid(2247760)
addappid(2247761, 1, "4e5edd6fcaa0fadcc53ec5faed29ca2e0025cc241a4b9183fc3b48208bdcf58d")
