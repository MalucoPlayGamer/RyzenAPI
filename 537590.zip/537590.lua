-- Lua provided by RyzenAPI
-- Game: Bridge to Nowhere

-- MAIN APPLICATION
addappid(537590)

-- MAIN APP DEPOTS / PACKAGES
addappid(537591, 1, "853634b9ebe9a473c563ed0dc260016915ed7df3eb57ef59ea3e60d35a280739")
