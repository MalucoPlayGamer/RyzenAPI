-- Lua provided by RyzenAPI
-- Game: On Scene - The Horror Stories of Fred & Karen

-- MAIN APPLICATION
addappid(1691010)
-- Game: addappid(1691010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691011, 1, "3c226cd6ec4684b99809ab78daf4aae7d2371374dc0fd6cada8e129c402a9f2f")
