-- Lua provided by RyzenAPI
-- Game: 荒岛求生

-- MAIN APPLICATION
addappid(1152250)
-- Game: addappid(1152250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152251, 1, "0ab6404d407d9841a0e91c3b72f208913e60da705d4fc08b6b39f394d7a81160")
