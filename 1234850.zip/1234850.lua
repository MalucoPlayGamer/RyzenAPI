-- Lua provided by RyzenAPI
-- Game: Synthetic blood: Mind Shift

-- MAIN APPLICATION
addappid(1234850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1234851, 1, "6578378fa5f0cbb9704f4d6ba7c794eaa4b46995d7b82663c518db02924d69d9")
