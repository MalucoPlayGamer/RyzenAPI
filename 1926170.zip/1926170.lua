-- Lua provided by RyzenAPI 
-- Game: Forgotten Hill Tales
addappid(1926170)
addappid(1926171, 1, "60210bfeca39d9b9d93ad682cfc23545229da5c1e1cc477827a63638ccc3a444")
