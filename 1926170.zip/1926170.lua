-- Lua provided by RyzenAPI
-- Game: Game: Forgotten Hill Tales

-- MAIN APPLICATION
addappid(1926170)
-- Game: addappid(1926170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926171, 1, "60210bfeca39d9b9d93ad682cfc23545229da5c1e1cc477827a63638ccc3a444")
