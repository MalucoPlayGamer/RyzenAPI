-- Lua provided by RyzenAPI
-- Game: Game: Sam & Max Save the World

-- MAIN APPLICATION
addappid(1440440)
addappid(1488603)
addappid(1488604)
-- Game: addappid(1440440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440441, 1, "664773e2abbccf94415d6723e927a7ff792ec266f541011f0a0418077b36384c")
addappid(1440449, 1, "cae3374773179c0bc056bc5229cd1537d3345d4f39489e2a91bfeffc76e610cd")
addappid(1488600, 0, "acd4a9b9e7995046a3c0eb03a65fe125b043809bd6f271473426c60912528083")
addappid(1488602, 0, "6e38cc202f8f6159dbebbc587d2211184c7f4e2c875c31cd5dd80820ff3fb817")
