-- Lua provided by RyzenAPI
-- Game: 王于兴师/Order of Kings

-- MAIN APPLICATION
addappid(4192650)

