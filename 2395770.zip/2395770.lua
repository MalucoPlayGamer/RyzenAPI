-- Lua provided by SkyAPI 
-- Game: Never Grave: The Witch and The Curse
addappid(2395770)
addappid(2395771, 1, "dd43f698f3354836535bbfc749faec735ac34c9367cbb5f0de40de1645e000aa")
addappid(4384400, 0, "3c96a9dd869952e819e5cdd47de80979dc7efe1c5bf48bf620fbc47df546a3f1")
