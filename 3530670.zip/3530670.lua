-- Lua provided by RyzenAPI
-- Game: Game: Mosaic of The Pharaohs

-- MAIN APPLICATION
addappid(3530670)
-- Game: addappid(3530670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530671, 1, "169e17ea3bfd6a5d87a3fbf0d223c05f26e00871f200a6900821b1b4d474dfcf")
