-- Lua provided by RyzenAPI
-- Game: 蛋丸之地 Demo

-- MAIN APPLICATION
addappid(2355680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355681, 1, "4dca32e5f9ca8c77c71d3fd6d70c31b60ab44b37098e11a13f2018a7aa643628")

