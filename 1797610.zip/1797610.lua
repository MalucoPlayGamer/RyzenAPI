-- Lua provided by RyzenAPI
-- Game: 1797610

-- MAIN APPLICATION
addappid(1797610)
-- Game: addappid(1797610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797611, 1, "64e96c0120134f5f264cc3b8cfd515e5a6ebc5c500d81d22c04be84198d221ed")
addappid(1797612, 1, "3a3e1ef71b19b03dda3085d44e622c0dee6f397b469bb87a9d02b3b189bfa433")
