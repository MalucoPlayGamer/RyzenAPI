-- Lua provided by RyzenAPI
-- Game: Splatter - Zombiecalypse Now

-- MAIN APPLICATION
addappid(281920)

-- MAIN APP DEPOTS / PACKAGES
addappid(281921, 1, "69449827eb9ce50c505c919611647fe9fd520a72e8410388ee44afaa983a7c19")
addappid(281922, 1, "1c0a60674d570675ad0acd36058c30cb482276c5b4da164f0708d19c18537fd0")
addappid(281923, 1, "077aa339a82acd81916067c32140c7398f26cae822ea074fc6cffccdf6cd8065")
addappid(281924, 1, "dfa5979b9fd770128e685ad303292a0e44e7105847e6d6f7878bb1460951023b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
