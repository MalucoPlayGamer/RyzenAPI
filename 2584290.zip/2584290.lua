-- Lua provided by RyzenAPI
-- Game: Violet

-- MAIN APPLICATION
addappid(2584290)
addappid(4805070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2584291, 1, "73c235d13e82779a4ffbd8761dfb1edc9f8b8170dbd8ce20ab92fef06ea1c466")

