-- Lua provided by RyzenAPI
-- Game: Violet

-- MAIN APPLICATION
addappid(2584290)
-- Game: addappid(2584290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584291, 1, "73c235d13e82779a4ffbd8761dfb1edc9f8b8170dbd8ce20ab92fef06ea1c466")
