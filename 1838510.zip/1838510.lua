-- Lua provided by RyzenAPI
-- Game: Succubus - Demons of the past

-- MAIN APPLICATION
addappid(1838510)
-- Game: addappid(1838510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838510,0,"4762c1c7d19fad1c6a6035381036c2866cdc86391ed4f2a9158c24eaf7c6069a")
