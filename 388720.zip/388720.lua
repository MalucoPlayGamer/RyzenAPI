-- Lua provided by RyzenAPI
-- Game: Link: The Unleashed Nexus

-- MAIN APPLICATION
addappid(388720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(388721, 1, "3b7e9676027475a7b23108f75e8f786ed25a5e55291e10cd2a677e1968035461")
addappid(417080, 0, "a943c7005579539d666a1ae4019f034c2535fa2951e432fc7f636d77ff0ca38c")

