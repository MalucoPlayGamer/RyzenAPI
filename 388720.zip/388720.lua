-- Lua provided by SkyAPI 
-- Game: Link: The Unleashed Nexus
addappid(388720)
addappid(388721, 1, "3b7e9676027475a7b23108f75e8f786ed25a5e55291e10cd2a677e1968035461")
addappid(417080, 0, "a943c7005579539d666a1ae4019f034c2535fa2951e432fc7f636d77ff0ca38c")
