-- Lua provided by RyzenAPI
-- Game: The Last Society

-- MAIN APPLICATION
addappid(2382310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2382311, 1, "a0dc4057e4bd12a9a7d0cdf9058d74c525d1b1435d58f0e52a9a734146253554")

