-- Lua provided by RyzenAPI 
-- Game: Deformed
addappid(2332250)
addappid(2332251, 1, "bf20d56fd5e652db114c1eff55117eb9d6f95b5e55323aeba9a83fd47d6bbf02")
addappid(3527110)
