-- Lua provided by RyzenAPI
-- Game: Deformed

-- MAIN APPLICATION
addappid(2332250)
addappid(3527110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2332251, 1, "bf20d56fd5e652db114c1eff55117eb9d6f95b5e55323aeba9a83fd47d6bbf02")

