-- Lua provided by RyzenAPI
-- Game: 2097750

-- MAIN APPLICATION
addappid(2097750)
-- Game: addappid(2097750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097751, 1, "3b05add43170849c2c90fc7ebfa7214d222cdc095af12728c88769d448adb92f")
