-- Lua provided by RyzenAPI
-- Game: Game: Idle: Generators

-- MAIN APPLICATION
addappid(2453520)
-- Game: addappid(2453520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453521, 1, "5ff4ef5a7da08bf69de5180fb1f7d2afa2acec97c0b02d9ce2480b553ad56223")
