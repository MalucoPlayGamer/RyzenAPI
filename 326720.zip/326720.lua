-- Lua provided by RyzenAPI
-- Game: Game: Instant Dungeon!

-- MAIN APPLICATION
addappid(326720)
-- Game: addappid(326720)

-- MAIN APP DEPOTS / PACKAGES
addappid(326721, 1, "e89658d465cbbb015d42847ddb3f7fff6959957963fa33e0b523ad30ec0f6105")
