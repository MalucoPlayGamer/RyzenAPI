-- Lua provided by RyzenAPI
-- Game: Instant Dungeon!

-- MAIN APPLICATION
addappid(326720)

-- MAIN APP DEPOTS / PACKAGES
addappid(326721, 1, "e89658d465cbbb015d42847ddb3f7fff6959957963fa33e0b523ad30ec0f6105")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
