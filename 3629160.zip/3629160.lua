-- Lua provided by RyzenAPI
-- Game: Game: 手机时代 Mobile era

-- MAIN APPLICATION
addappid(3629160)
-- Game: addappid(3629160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629161, 1, "fdd3ab8294ca3e434935c39407db4d4c688aeb4eb854c19d09d03023cc8e2d41")
