-- Lua provided by RyzenAPI
-- Game: AppID 264400

-- MAIN APPLICATION
addappid(264400)

-- MAIN APP DEPOTS / PACKAGES
addappid(264401, 1, "4499c00e1ef1d6c753b36fa8fd681b7858cb175d408de4a7c07d198290b5596a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
