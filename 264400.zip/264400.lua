-- Lua provided by RyzenAPI
-- Game: 264400

-- MAIN APPLICATION
addappid(264400)
-- Game: addappid(264400)

-- MAIN APP DEPOTS / PACKAGES
addappid(264401, 1, "4499c00e1ef1d6c753b36fa8fd681b7858cb175d408de4a7c07d198290b5596a")
