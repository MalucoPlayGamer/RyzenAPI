-- Lua provided by RyzenAPI
-- Game: addappid(1416620)

-- MAIN APPLICATION
addappid(1416620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416620,0,"7d07525f792843123d210678bad03cc1c4c49916f9ec86f1c9973ecbcf81abb3")
