-- Lua provided by RyzenAPI
-- Game: Queens Climax

-- MAIN APPLICATION
addappid(2807610)
-- Game: addappid(2807610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807611, 1, "dee57c7f1e5f288ff9acb5d63bc4c89e260ffcc778543465e6c8b164fc65adc2")
