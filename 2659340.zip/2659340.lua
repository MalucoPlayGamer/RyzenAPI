-- Lua provided by RyzenAPI
-- Game: Game: Feast Tower

-- MAIN APPLICATION
addappid(2659340)
-- Game: addappid(2659340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659341, 1, "51ba528d7422da94128cb119b8cd533754f3b13a34947786e4478f9f9fa06aaa")
