-- Lua provided by RyzenAPI
-- Game: Eternal Evil

-- MAIN APPLICATION
addappid(1673630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1673631, 1, "9c79274eca7230251ba28d9a207d76c05fc127a79ccd3e3434cfb510d90dc636")

