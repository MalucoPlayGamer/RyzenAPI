-- Lua provided by RyzenAPI
-- Game: 1673630

-- MAIN APPLICATION
addappid(1673630)
-- Game: addappid(1673630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673631, 1, "9c79274eca7230251ba28d9a207d76c05fc127a79ccd3e3434cfb510d90dc636")
