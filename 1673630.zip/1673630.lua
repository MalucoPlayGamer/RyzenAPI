-- Lua provided by RyzenAPI 
-- Game: AppID 1673630
addappid(1673630)
addappid(1673631, 1, "9c79274eca7230251ba28d9a207d76c05fc127a79ccd3e3434cfb510d90dc636")
