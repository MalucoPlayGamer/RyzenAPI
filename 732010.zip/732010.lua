-- Lua provided by RyzenAPI
-- Game: BrainyJoy

-- MAIN APPLICATION
addappid(732010)

-- MAIN APP DEPOTS / PACKAGES
addappid(732011, 1, "d62f862dfd1218bde81e6f7dae05b576ea4b39e27c0971edfdf99ebea835e10e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
