-- Lua provided by RyzenAPI
-- Game: Game: BrainyJoy

-- MAIN APPLICATION
addappid(732010)
-- Game: addappid(732010)

-- MAIN APP DEPOTS / PACKAGES
addappid(732011, 1, "d62f862dfd1218bde81e6f7dae05b576ea4b39e27c0971edfdf99ebea835e10e")
