-- Lua provided by RyzenAPI
-- Game: addappid(3222860)

-- MAIN APPLICATION
addappid(3222860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3222861, 1, "ba28124f23eef39732973b6c2c3da54b76c340662da3af893d92bf4b59c84535")
