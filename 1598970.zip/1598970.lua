-- Lua provided by RyzenAPI
-- Game: Magnus Failure

-- MAIN APPLICATION
addappid(1598970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598971, 1, "9030c9a460ea50edca9abd8efe82d37a6adf62b5a24c561951f15e58a0c4b764")

