-- Lua provided by RyzenAPI
-- Game: Planetary Settlers

-- MAIN APPLICATION
addappid(857860)

-- MAIN APP DEPOTS / PACKAGES
addappid(857861,0,"4faa5aa605bb17c2b5ebcf40e7be76dbbfe258a89d7348bb07a20ff9053c1cec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
