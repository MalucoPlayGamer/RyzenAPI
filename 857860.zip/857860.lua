-- Lua provided by RyzenAPI
-- Game: Planetary Settlers

-- MAIN APPLICATION
addappid(857860)

-- MAIN APP DEPOTS / PACKAGES
addappid(857861,0,"4faa5aa605bb17c2b5ebcf40e7be76dbbfe258a89d7348bb07a20ff9053c1cec")

