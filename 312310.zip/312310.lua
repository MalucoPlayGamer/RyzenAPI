-- Lua provided by RyzenAPI
-- Game: Ensign-1

-- MAIN APPLICATION
addappid(312310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(312311, 1, "581edbc60e66c61f61f02bdc6cd9a226e8b094ad6b8154030cf99dd7b585d8ce")
addappid(312312, 1, "31f9c5811a18fc8450365bdd139811a9dc4aa4aa9460fd927d55f252f8a20586")
addappid(312313, 1, "fae1676ca395f8ce6e107852e95831d801fce32c4670ac429ec3dc2071521988")

