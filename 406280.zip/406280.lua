-- Lua provided by RyzenAPI
-- Game: Game: DesertLand 2115

-- MAIN APPLICATION
addappid(406280)
-- Game: addappid(406280)

-- MAIN APP DEPOTS / PACKAGES
addappid(406281, 1, "30bdc4bcb16c54e3514bf3c75854c8451dc5ee68739dc777bbce4a0751d54a8c")
