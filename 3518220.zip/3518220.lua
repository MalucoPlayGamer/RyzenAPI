-- Lua provided by RyzenAPI
-- Game: Super Meddl Boy

-- MAIN APPLICATION
addappid(3518220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3518221, 1, "0cb88289d0739332f2a9d197dcf16dd86032b8ef40a19f53ffae1a2ca040eec0")
