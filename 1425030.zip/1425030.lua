-- Lua provided by SkyAPI 
-- Game: Cyberwinter
addappid(1425030)
addappid(1425031, 1, "6bcf1a3c4304c73d6f2d54fd3183799877429573982b7aa6a4d9536e088c586b")
