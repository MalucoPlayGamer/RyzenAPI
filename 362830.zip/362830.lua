-- Lua provided by SkyAPI 
-- Game: AppID 362830
addappid(362830)
addappid(362831, 1, "b8d37f9de6468b1cd61b3f2ad3096284857d40c4db624675f54f05f0d897e634")
addappid(362832, 1, "cddc4b43dfe1600e40675fa12db6f39b24b06a2ca13de41d7dba325112fb90c4")
