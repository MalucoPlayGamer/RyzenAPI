-- Lua provided by RyzenAPI
-- Game: addappid(746220)

-- MAIN APPLICATION
addappid(746220)

-- MAIN APP DEPOTS / PACKAGES
addappid(746221, 1, "74a907fb1d570ad404c54a3f13b3c2503d7c4ea1371b69f0e1449bb2834c807e")
