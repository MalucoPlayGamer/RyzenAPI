-- Lua provided by RyzenAPI
-- Game: addappid(209630)

-- MAIN APPLICATION
addappid(209630)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(209631, 1, "97142639fc20406d84e03b70a2784fd885878b1bbbc0392208e8b8ac940b094e")
