-- Lua provided by RyzenAPI
-- Game: 504460

-- MAIN APPLICATION
addappid(504460)
-- Game: addappid(504460)

-- MAIN APP DEPOTS / PACKAGES
addappid(504461, 1, "4dfd0d866b0e4c5eab242541b903d574dd72fa08cf3e8752dc431fa81baaa0c7")
