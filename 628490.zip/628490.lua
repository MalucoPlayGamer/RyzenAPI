-- Lua provided by RyzenAPI
-- Game: AppID 628490

-- MAIN APPLICATION
addappid(628490)
-- Game: addappid(628490)

-- MAIN APP DEPOTS / PACKAGES
addappid(628491, 1, "4f9eb576fd7dc0bc810be58342453c09a20e660300086242708dde81a66b818c")
