-- Lua provided by RyzenAPI
-- Game: 1622790

-- MAIN APPLICATION
addappid(1622790)
-- Game: addappid(1622790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622791, 1, "887dd72001f54bdc2cb4ee249e13140b6a1d117cf020f62de696d0a261a686ad")
