-- Lua provided by RyzenAPI
-- Game: Edgar

-- MAIN APPLICATION
addappid(455640)

-- MAIN APP DEPOTS / PACKAGES
addappid(455642,0,"46aad138cad71351bac86e1e49188d5755b95b412bd1646060461fbb0cebf08d")
