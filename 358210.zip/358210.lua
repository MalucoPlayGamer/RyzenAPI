-- Lua provided by SkyAPI 
-- Game: Monster Bash
addappid(358210)
addappid(358211, 1, "e487c1f4e24372492f3c40ad066c57515780cbbdd38c3b3970cb036a87eb8c4d")
addappid(358212, 1, "4957f14f989aa77f367e175285700ae8c943b2ba45dc14f9f327444c807be1a7")
