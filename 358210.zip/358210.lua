-- Lua provided by RyzenAPI
-- Game: Monster Bash

-- MAIN APPLICATION
addappid(358210)
-- Game: addappid(358210)

-- MAIN APP DEPOTS / PACKAGES
addappid(358211, 1, "e487c1f4e24372492f3c40ad066c57515780cbbdd38c3b3970cb036a87eb8c4d")
addappid(358212, 1, "4957f14f989aa77f367e175285700ae8c943b2ba45dc14f9f327444c807be1a7")
