-- Lua provided by RyzenAPI
-- Game: Bloxpath

-- MAIN APPLICATION
addappid(3249900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249901, 1, "c2da8bd78010e2813957b0928af22ead3e6dcef1655fa145e61a58a1e3de49d3")
