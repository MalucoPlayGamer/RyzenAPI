-- Lua provided by SkyAPI 
-- Game: Bloxpath
addappid(3249900)
addappid(3249901, 1, "c2da8bd78010e2813957b0928af22ead3e6dcef1655fa145e61a58a1e3de49d3")
