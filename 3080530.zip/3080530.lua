-- Lua provided by RyzenAPI
-- Game: Project X: Light Years

-- MAIN APPLICATION
addappid(3080530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3080531, 1, "beecb048a770e2f5b2ac449a00614a67ff8e0dddcefccb46ecaf516407fe5b52")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5006420)
