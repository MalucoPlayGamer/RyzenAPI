-- Lua provided by RyzenAPI
-- Game: Project X: Light Years

-- MAIN APPLICATION
addappid(3080530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080531, 1, "beecb048a770e2f5b2ac449a00614a67ff8e0dddcefccb46ecaf516407fe5b52")

