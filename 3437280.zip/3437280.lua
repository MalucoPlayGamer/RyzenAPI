-- Lua provided by RyzenAPI
-- Game: The Masculine Urge To Blow a Femboy

-- MAIN APPLICATION
addappid(3437280)
-- Game: addappid(3437280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437281, 1, "8acd921f933481413ca9eea08e8648c763ad3c3855e51f50944e75d1c407bc3a")
