-- Lua provided by RyzenAPI
-- Game: addappid(510250)

-- MAIN APPLICATION
addappid(510250)

-- MAIN APP DEPOTS / PACKAGES
addappid(510251, 1, "75f735d43d136e65c6b50f449842183dc4f8815d0b76172a7eb62e544fe884bc")
addappid(510252, 1, "1707a7a14a182f0e3f5ac182cddd56ce2b1617049728c275fbba4e2e52e7cb1d")
addappid(510253, 1, "252d5ae5a4ebe3cbbbbec56671b0574c2d5dfe9547f238a557f0350c2f6dabf4")
addappid(510254, 1, "f407c8b9a27b9e54f14eb57c3deadc530bae60390b165e8a8ddeb94efa366862")
addappid(510255, 1, "a0ef6676a80d7b6a0d08712babf5d6796e61ea95a6e73843d0f3f54b5c3ffbed")
