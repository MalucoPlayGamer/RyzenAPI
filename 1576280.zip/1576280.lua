-- Lua provided by RyzenAPI
-- Game: Moviehouse – The Film Studio Tycoon

-- MAIN APPLICATION
addappid(1576280)
-- Game: addappid(1576280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576281, 1, "fa739a2a02149d13eb222ed2a40d1d7a596b9ba11b29cbf2667c547f0bd5f803")
