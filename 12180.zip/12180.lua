-- Lua provided by SkyAPI 
-- Game: AppID 12180
addappid(12180)
addappid(12181, 1, "95b653ec5cddd0d1e62ab51e21ab4f827ec91a0c62834e2d7dcb9376fd6908fd")
