-- Lua provided by RyzenAPI
-- Game: GRANDMA

-- MAIN APPLICATION
addappid(1727550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727551, 1, "33913d6090ea3f3861ade725eb2211bd0ebc5ccf5670d3cd435fc1d82f8c0cc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
