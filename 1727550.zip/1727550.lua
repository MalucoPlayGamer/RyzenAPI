-- Lua provided by RyzenAPI
-- Game: GRANDMA

-- MAIN APPLICATION
addappid(1727550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727551, 1, "33913d6090ea3f3861ade725eb2211bd0ebc5ccf5670d3cd435fc1d82f8c0cc1")
