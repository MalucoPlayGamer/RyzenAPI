-- Lua provided by RyzenAPI
-- Game: Windward Horizon

-- MAIN APPLICATION
addappid(2665460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665461, 1, "9056134f1beb54803ae1af6bad16bf430c796326251386fa7e0fab7453828202")
