-- Lua provided by RyzenAPI 
-- Game: ROOM FOOTBALL - Ranch
addappid(3517280)
addappid(3517281, 1, "1cacbd028a28893d24be5a31c81f49a834681bd0c9686fa469ab38e03a9959a9")
