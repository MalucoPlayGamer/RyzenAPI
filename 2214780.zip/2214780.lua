-- Lua provided by RyzenAPI
-- Game: Dysterra Dedicated Server

-- MAIN APPLICATION
addappid(2214780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214781, 1, "08e21fd6f490a3506eb2a264a6254eece0c36280f6fd9366658c6ab6cfc760c6")

