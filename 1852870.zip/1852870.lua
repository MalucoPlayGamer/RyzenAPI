-- Lua provided by RyzenAPI
-- Game: Game Dev Arcade

-- MAIN APPLICATION
addappid(1852870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1852871, 1, "8cd2a6b42d70ef3c44eccdea96217bca693aca2fa5bc2455fb55f7513f77fffd")
