-- Lua provided by RyzenAPI
-- Game: AppID 1852870

-- MAIN APPLICATION
addappid(1852870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852871, 1, "8cd2a6b42d70ef3c44eccdea96217bca693aca2fa5bc2455fb55f7513f77fffd")

