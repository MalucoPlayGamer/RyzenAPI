-- Lua provided by RyzenAPI
-- Game: Gangsta Magic

-- MAIN APPLICATION
addappid(1412040)
-- Game: addappid(1412040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412041, 1, "55fef4bffa6d010da1b3612767776d03adf75e7fbd685b769ff052c7394708c6")
