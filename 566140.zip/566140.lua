-- Lua provided by RyzenAPI
-- Game: Holo-Graham

-- MAIN APPLICATION
addappid(566140)

-- MAIN APP DEPOTS / PACKAGES
addappid(566141, 1, "d0f694b197438bce015d9c8ac7b76d168250ec6a2452a8176e78e9c2736b2867")

