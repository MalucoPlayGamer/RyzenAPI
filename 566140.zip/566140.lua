-- Lua provided by SkyAPI 
-- Game: AppID 566140
addappid(566140)
addappid(566141, 1, "d0f694b197438bce015d9c8ac7b76d168250ec6a2452a8176e78e9c2736b2867")
