-- Lua provided by RyzenAPI
-- Game: addappid(1772050)

-- MAIN APPLICATION
addappid(1772050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772051, 1, "e2bcfd8c9279a9384ec0b7e5867826afa026bbc41b00e0c4230bebd79de029c5")
