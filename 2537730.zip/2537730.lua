-- Lua provided by RyzenAPI
-- Game: Noblesse Oblige: Legacy of the Sorcerer Kings

-- MAIN APPLICATION
addappid(2537730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537731, 1, "480297cef472f66d2a1db7988636e3f050f1de29171607b2317b8af111d484ca")

