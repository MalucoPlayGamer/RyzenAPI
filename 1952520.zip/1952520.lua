-- Lua provided by RyzenAPI
-- Game: addappid(1952520)

-- MAIN APPLICATION
addappid(1952520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952521, 1, "7f72773724787f8f44bafd5fef370cc606d64f80d6c3a0eabb32f11be0b5e36a")
