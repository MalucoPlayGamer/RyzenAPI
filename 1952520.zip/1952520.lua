-- Lua provided by RyzenAPI
-- Game: PAW Patrol World

-- MAIN APPLICATION
addappid(1952520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952521, 1, "7f72773724787f8f44bafd5fef370cc606d64f80d6c3a0eabb32f11be0b5e36a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2399350)
addappid(2399351)
addappid(2399352)
addappid(2399353)
addappid(2399354)
