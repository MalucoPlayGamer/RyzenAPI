-- Lua provided by RyzenAPI
-- Game: 1634698

-- MAIN APPLICATION
addappid(1634698)
-- Game: addappid(1634698)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634698,0,"d0badb871404c31168a76d76cbc58cc7f9334b8d839f8d6641f8e12de1a32c5e")
