-- Lua provided by RyzenAPI
-- Game: Night at Grandma's

-- MAIN APPLICATION
addappid(3320780)
-- Game: addappid(3320780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320781, 1, "390606ffdb4cb3c84c8b40c4804135128790fcd73a3bb3611ad03a3a6bcd84ea")
