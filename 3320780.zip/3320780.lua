-- Lua provided by RyzenAPI
-- Game: Night at Grandma's

-- MAIN APPLICATION
addappid(3320780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320781, 1, "390606ffdb4cb3c84c8b40c4804135128790fcd73a3bb3611ad03a3a6bcd84ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
