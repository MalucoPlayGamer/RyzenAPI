-- Lua provided by SkyAPI 
-- Game: Night at Grandma's
addappid(3320780)
addappid(3320781, 1, "390606ffdb4cb3c84c8b40c4804135128790fcd73a3bb3611ad03a3a6bcd84ea")
