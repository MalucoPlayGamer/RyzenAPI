-- Lua provided by RyzenAPI
-- Game: Little Witch  Luana

-- MAIN APPLICATION
addappid(1180550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180551, 1, "3b4e2a0a3923a8f7561b4e477bccf79dfcf38d6fda4783795e8c8f8c11ae7038")
