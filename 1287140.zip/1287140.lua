-- Lua provided by RyzenAPI
-- Game: Sonia and the Hypnotic City

-- MAIN APPLICATION
addappid(1287140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287141, 1, "5c886bf99630fb96a919951e9ef2ee396bd33378357d81f0eb1fbf118fbc6eb0")
addappid(1287142, 1, "cce6f1de50b26b5dd0b389450703d41d9bac1f597ebf3def907d45f7d7125b64")
addappid(1287143, 1, "948bf172565937c72fb2736e45f3ba0c9e7d405e200b8afb539d4cb177f732e0")

