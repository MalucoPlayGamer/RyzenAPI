-- Lua provided by RyzenAPI
-- Game: Zeta Leporis RTS

-- MAIN APPLICATION
addappid(2445160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445161, 1, "f6901968388efb0a479cb2a1ac7ee926e640843598c61d54afca49d84b7e4096")

