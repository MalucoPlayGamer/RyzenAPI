-- Lua provided by SkyAPI 
-- Game: Eggsplorer
addappid(2275970)
addappid(2275971, 1, "ca640eeb8079e37b3891eeb6e890d8316f3d93cf68056ffc9d449b250f72da1f")
