-- Lua provided by RyzenAPI
-- Game: Inflatality

-- MAIN APPLICATION
addappid(653080)

-- MAIN APP DEPOTS / PACKAGES
addappid(653081,0,"88247080bcc2dbfe2d08e735670ec1a7612393078fb1142575d2015e24fd1aa2")
addappid(653082,0,"31399a6de3edd2aea0eff6e256b1691ea86f5e3ad84885bdc59c285f27ee2a7b")

