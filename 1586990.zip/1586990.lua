-- Lua provided by RyzenAPI
-- Game: AppID 1586990

-- MAIN APPLICATION
addappid(1586990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586991, 1, "f1e4f1e4d6c5eef9faf87f0d522e4545d827a720de6eb5d7a01a449dc1181def")
