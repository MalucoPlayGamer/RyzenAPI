-- Lua provided by RyzenAPI
-- Game: Truck Life-Gansu

-- MAIN APPLICATION
addappid(1130600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130600,0,"697d5528eac57d580c39643293967b35b7b41fcff5e3f6bb9b59167dfd5df5e0")

