-- Lua provided by RyzenAPI
-- Game: addappid(1931060)

-- MAIN APPLICATION
addappid(1931060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931061, 1, "91cdd808ab467a46f20e6a8768bdbb7ca4000336c34c92e8ec06bcc4c167081e")
