-- Lua provided by RyzenAPI
-- Game: FUSER™ - Alanis Morissette - "Ironic"

-- MAIN APPLICATION
addappid(1432142)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432142,0,"74cbfd7656367072df4f5a4dec877dea4479f6d8e5b552e7c3b1d73bb6334442")

