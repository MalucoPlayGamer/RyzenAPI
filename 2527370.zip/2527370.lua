-- Lua provided by RyzenAPI
-- Game: Game: Darkless

-- MAIN APPLICATION
addappid(2527370)
-- Game: addappid(2527370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527371, 1, "0dc4d4ac203eed7d713103ddcc071ede2ea262ad7fc06325c3b6de83a5fed583")
