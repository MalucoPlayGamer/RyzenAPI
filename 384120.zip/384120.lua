-- Lua provided by RyzenAPI
-- Game: AppID 384120

-- MAIN APPLICATION
addappid(384120)

-- MAIN APP DEPOTS / PACKAGES
addappid(384121, 1, "b0a65f0573d0d3a2d14a28aa60685229bfd5f2103d1733c3a103dae6df2e2985")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
