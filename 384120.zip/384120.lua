-- Lua provided by RyzenAPI
-- Game: addappid(384120)

-- MAIN APPLICATION
addappid(384120)

-- MAIN APP DEPOTS / PACKAGES
addappid(384121, 1, "b0a65f0573d0d3a2d14a28aa60685229bfd5f2103d1733c3a103dae6df2e2985")
