-- Lua provided by RyzenAPI
-- Game: THE GOLD IS MINE

-- MAIN APPLICATION
addappid(3582830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582831, 1, "a124a9ec05e7dbec9b6b848f14dc938868d61c8abeae84a3f213eda4a1c59a82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
