-- Lua provided by RyzenAPI
-- Game: THE GOLD IS MINE

-- MAIN APPLICATION
addappid(3582830)
-- Game: addappid(3582830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582831, 1, "a124a9ec05e7dbec9b6b848f14dc938868d61c8abeae84a3f213eda4a1c59a82")
