-- Lua provided by RyzenAPI
-- Game: Game: Detective VR: NFT secret Files

-- MAIN APPLICATION
addappid(1610670)
-- Game: addappid(1610670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610671, 1, "f6744654142388025e8ad72a3dea748d3a889e5bfc8583282bb6baa280536b0c")
