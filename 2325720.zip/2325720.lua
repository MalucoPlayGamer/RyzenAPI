-- Lua provided by RyzenAPI
-- Game: setManifestid(3182040,"2119213363273136571")

-- MAIN APPLICATION
addappid(2325720)
-- Game: addappid(2325720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182040,0,"8e4f7b0239b2ac799c57ecef9b796a31a0583fc5274e4b5ece12dea56aa823eb")
