-- 4599710's Lua and Manifest Created by Hubcap Manifest
-- IDLE_DIRECTIVE
-- Created: July 29, 2026 at 05:14:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4599710) -- IDLE_DIRECTIVE
-- MAIN APP DEPOTS
addappid(4599711, 1, "8ae7dfe28f9b0333443240a8873902afe2df04e635767eea4c3f4ab81a39bae3") -- Depot 4599711
setManifestid(4599711, "3104530316814729481", 130721640)