-- Lua provided by RyzenAPI
-- Game: BasementVR

-- MAIN APPLICATION
addappid(561390)
-- Game: addappid(561390)

-- MAIN APP DEPOTS / PACKAGES
addappid(561391, 1, "eb3b99ce295ebd0338d4b03eddb20d214ddef10ee6283c7aca2e45f9477b8a47")
