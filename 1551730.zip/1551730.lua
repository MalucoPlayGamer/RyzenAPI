-- Lua provided by SkyAPI 
-- Game: Place for Hero
addappid(1551730)
addappid(1551731, 1, "a5ef1c8432f617acdc9162795feea2ce825d384d92b8414b44ff7b322ffc4a81")
