-- Lua provided by RyzenAPI
-- Game: FUSER™ - Ja Rule ft. Ashanti - "Always On Time"

-- MAIN APPLICATION
addappid(1559223)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559223,0,"9fd5eb0219675831903b06a36ade7d3078f4658929ed1a0546ec620025f91092")

