-- Lua provided by RyzenAPI
-- Game: addappid(2468740)

-- MAIN APPLICATION
addappid(2468740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468741, 1, "2cb8026f5afe3cd5a6cd3a72ea323a7c88e23d1426ea4bad8d7a3a1e8c8588fe")
