-- Lua provided by RyzenAPI
-- Game: Sunny village

-- MAIN APPLICATION
addappid(2468740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468741, 1, "2cb8026f5afe3cd5a6cd3a72ea323a7c88e23d1426ea4bad8d7a3a1e8c8588fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
