-- Lua provided by RyzenAPI
-- Game: FaeVerse Alchemy

-- MAIN APPLICATION
addappid(282880)

-- MAIN APP DEPOTS / PACKAGES
addappid(282881, 1, "994db01407ca185ca5b0222f8608cd36d9739c4ba4ba5bef965779d749b64b28")
addappid(282882, 1, "110cdfefabdd846d7adc68604dbee6379b1ccfcf32fb7480785ceea28db5bba7")
addappid(282883, 1, "3ff8e487753f8da00df607f9148abe42efc8dd84fe4cd36e03732d3d6d5327c2")
addappid(282884, 1, "6c516d9833b840762725158004f6f9d4984a8369b2b3a500cc16209a2f9d9f34")
