-- 4397780's Lua and Manifest Created by Hubcap Manifest
-- Roll Together
-- Created: July 16, 2026 at 03:57:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4397780, 1, "add1f6cd791b20c776a292a46378b2b0a92a3ea5f657e26e1c29c043ac176cc8") -- Roll Together
-- MAIN APP DEPOTS
addappid(4397781, 1, "246de5e8fa14cca4eb8979117d1dca6b4b8716da82813367773a46af10cfc641") -- Depot 4397781
setManifestid(4397781, "5205600027460048014", 426138327)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4873950) -- Roll Together - Supporter Pack