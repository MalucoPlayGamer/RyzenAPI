-- Lua provided by RyzenAPI
-- Game: AppID 718670

-- MAIN APPLICATION
addappid(718670)

-- MAIN APP DEPOTS / PACKAGES
addappid(718671, 1, "dc20d4bf29f7456c029b2098de8aa019810ec20323584afbc2cf84842b23d713")
addappid(718672, 1, "0ddf8de1d062d0810016e415702ec9a6fc816fa73a2c42a99a899eec3761a818")
addappid(718673, 1, "b5ded5c8975e4140177ea43127c6b0c54259631f1eb7c81905d581851c0e7fb8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(871650)
addappid(871651)
addappid(871900)
addappid(874050)
addappid(1259930)
addappid(1813090)
