-- Lua provided by RyzenAPI
-- Game: Build & Battle

-- MAIN APPLICATION
addappid(604590)

-- MAIN APP DEPOTS / PACKAGES
addappid(604591, 1, "6dbe33bebdee9088199ef666f68f4e3a006ee32901737271f436c326b28bfdb0")
