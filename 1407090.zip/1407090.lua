-- Lua provided by RyzenAPI
-- Game: AppID 1407090

-- MAIN APPLICATION
addappid(1407090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1407091, 1, "77fe256c1b86d6ba14356f6f43a5a84875bfe777b1cbe606ded9a8967f4a1d81")

