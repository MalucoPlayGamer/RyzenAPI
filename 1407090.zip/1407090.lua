-- Lua provided by SkyAPI 
-- Game: AppID 1407090
addappid(1407090)
addappid(1407091, 1, "77fe256c1b86d6ba14356f6f43a5a84875bfe777b1cbe606ded9a8967f4a1d81")
