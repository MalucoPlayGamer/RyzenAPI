-- Lua provided by RyzenAPI
-- Game: Bionic Bay

-- MAIN APPLICATION
addappid(1928690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928691, 1, "5cd51e7d45f7b58876274ad752d66d96a9320abfbbe7230fa5daa34115656679")
addappid(3590200, 0, "cf42d58c1f95af4bd257049c9373a3649174f65b1c5388a9536dd9280559c66c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3590210)
