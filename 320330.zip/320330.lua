-- Lua provided by SkyAPI 
-- Game: Earthworms
addappid(320330)
addappid(320331, 1, "970528fefbce6f538d30dea91448c522a24a34afb270fb9b9d5a2389ac6bbd3b")
addappid(803450, 0, "a4cb1b81f58772c82174d95503a999bb41fc2602d4386fc68d24e8c9fb87a49e")
