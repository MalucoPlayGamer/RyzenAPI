-- Lua provided by RyzenAPI
-- Game: Created: August 11, 2026 at 14:38:07 EDT

-- MAIN APPLICATION
addappid(2959220) -- 勇跳高峰

-- MAIN APP DEPOTS / PACKAGES
addappid(2959221, 1, "38f64d5a934912019f7bf8c5f6a0619716b10a166654500aa94a3cc71040e03d") -- Depot 2959221

