-- Lua provided by RyzenAPI
-- Game: Game: Airship Killer

-- MAIN APPLICATION
addappid(1793220)
-- Game: addappid(1793220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793221, 1, "8e0d96bb20c8c563ea7cf8d128f1ff9bccce3bd0bde66158eaafb9ca27cc0457")
