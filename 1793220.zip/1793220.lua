-- Lua provided by SkyAPI 
-- Game: Airship Killer
addappid(1793220)
addappid(1793221, 1, "8e0d96bb20c8c563ea7cf8d128f1ff9bccce3bd0bde66158eaafb9ca27cc0457")
