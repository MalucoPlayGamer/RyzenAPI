-- Lua provided by RyzenAPI
-- Game: 2 Planets Fire and Ice

-- MAIN APPLICATION
addappid(657110)

-- MAIN APP DEPOTS / PACKAGES
addappid(657111, 1, "1653d783558e743b0c52b2175ca3f6104215818231188ed52733d602bf226984")
addappid(657112, 1, "b9fa19ac64e2f0d6152554779dee0fd9ec7155493fbe486376e643861a618b39")
addappid(657113, 1, "7e6eabb3aaea1c8bf32d1bc500b6f55944dbb3bca6b30d124b9fe2f7256b18a4")
addappid(657114, 1, "5476145ea4cb62c1f4c8ecaac34a9d1d26aa2214b8b11bec927313a35d76eaef")
addappid(657115, 1, "c12663535ec314a6d5fdf9526c94b133772985d11d85759e5e86dab670bd7f0a")
addappid(657116, 1, "28fe8fb747f14a734d1fd8230dd4ef78eba27c6433490e414ec3f335fd3e99a9")
addappid(657117, 1, "294e54973e0df63d9aab8ab351fadcb8d17aaad50844dc5a69ea4ec9027ccab1")
addappid(657118, 1, "bc144c25bc6c53708c6a0cbf2b6a0756964a13869d01079e8c51e8bec2bc0a84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
