-- Lua provided by RyzenAPI 
-- Game: Floors of Discomfort
addappid(372770)
addappid(372771, 1, "83bfad04a859772e1ca0913f22bf2da76dc9f5d8510b90b00e5a83244aa72c62")
addappid(372772, 1, "cc0bb29e45fc88e51729c8628ebbf37a3dbb9790936872a9eb308266390b9f6d")
