-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Miami

-- MAIN APPLICATION
addappid(3347060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347061, 1, "23faf092012fd91ccdd9f925dac8cf6773bc7dda9a1c0ae6ebb688990a25621a")
