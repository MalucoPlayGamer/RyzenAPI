-- Lua provided by RyzenAPI
-- Game: Game: The Deepest

-- MAIN APPLICATION
addappid(1494050)
-- Game: addappid(1494050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494051, 1, "9a1dfd835f518cd543ba0ec684cf6e73d7df7b2456e6f864c9af364d4b4c4843")
