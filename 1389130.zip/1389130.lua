-- Lua provided by RyzenAPI
-- Game: Game: Folkloric Excursion

-- MAIN APPLICATION
addappid(1389130)
-- Game: addappid(1389130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389131, 1, "f3f240f53ce8a6fc2732d1a5488df1fceb0e90796ef364cc481023b54cb4c4ca")
