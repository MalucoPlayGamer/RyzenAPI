-- Lua provided by RyzenAPI
-- Game: Potion Party

-- MAIN APPLICATION
addappid(1196440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196441, 1, "2c35c81797ddb9e71e9599ffcd09441a9974cf629e30500c059e8bd6575874b0")

