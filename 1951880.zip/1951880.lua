-- Lua provided by RyzenAPI
-- Game: Sex Diary - Futanari Massage

-- MAIN APPLICATION
addappid(1951880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951881, 1, "43c127ae08f9288afade9819acab0147ab0310e61ed5c8d847a37b434051d15e")

