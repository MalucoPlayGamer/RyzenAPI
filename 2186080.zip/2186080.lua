-- Lua provided by RyzenAPI
-- Game: Art Reborn: Painting Connoisseur - The muse（Player Assistance）

-- MAIN APPLICATION
addappid(2186080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186080,0,"d7684f94c9b908e6adae67f3943f41c8c201d5d3d6b2c33efb1fdbafb4a54a73")
