-- Lua provided by RyzenAPI
-- Game: 2186080

-- MAIN APPLICATION
addappid(2186080)
-- Game: addappid(2186080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186080,0,"d7684f94c9b908e6adae67f3943f41c8c201d5d3d6b2c33efb1fdbafb4a54a73")
