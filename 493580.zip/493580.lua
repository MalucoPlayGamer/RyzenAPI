-- Lua provided by RyzenAPI
-- Game: Game: Hidden Object - 12 in 1 bundle

-- MAIN APPLICATION
addappid(493580)
-- Game: addappid(493580)

-- MAIN APP DEPOTS / PACKAGES
addappid(493581, 1, "0168cd37441675a6618dba57311c3db975f9651b8bf7052be0cc1c9fd0fbbad4")
