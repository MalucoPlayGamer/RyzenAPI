-- Lua provided by RyzenAPI
-- Game: 3243760

-- MAIN APPLICATION
addappid(3243760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243762,0,"ce5a2f218febd1014d918c2f30888c776ffd0f2fa89f012dbf005c13f7c0b8cc")
