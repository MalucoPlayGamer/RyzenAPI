-- Lua provided by RyzenAPI
-- Game: Beat Saber: Billie Eilish - 'NDA'

-- MAIN APPLICATION
addappid(1753526)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753526,0,"eb5836f4692e8e2279f89672f8d1850e2de075243c3d823ede22d917a777db11")

