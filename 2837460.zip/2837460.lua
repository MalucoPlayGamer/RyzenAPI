-- Lua provided by RyzenAPI
-- Game: Crowborne

-- MAIN APPLICATION
addappid(2837460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837461, 1, "d683c53e4a3dea6d24e6adcbbc39cf5685beefc68c832fa70b802828b9bcef8f")

