-- Lua provided by RyzenAPI
-- Game: Crowborne

-- MAIN APPLICATION
addappid(2837460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837461, 1, "d683c53e4a3dea6d24e6adcbbc39cf5685beefc68c832fa70b802828b9bcef8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
