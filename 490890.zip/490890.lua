-- Lua provided by RyzenAPI
-- Game: Game: AppID 490890

-- MAIN APPLICATION
addappid(490890)
-- Game: addappid(490890)

-- MAIN APP DEPOTS / PACKAGES
addappid(490891, 1, "1ff81df5e68cfd4435d4fe69bbc4bb18dbb6e7e869ae47ca98c911a5614eadf1")
addappid(490892, 1, "0af93bf45f8b4370236fbdb1589b06629010c4775154bc73111349df9892cce5")
addappid(947750, 0, "30d4d8e0370110f97dfd759bc49b6da862121f3d441d9eefe8a3f0df21ab428c")
addappid(1096830, 0, "cf389ffd03ece69df8646e79a269b627398feb5416017cd345a26224ca6fc561")
