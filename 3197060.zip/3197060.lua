-- Lua provided by RyzenAPI
-- Game: 3197060

-- MAIN APPLICATION
addappid(3197060)
-- Game: addappid(3197060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197061, 1, "52cab73ca8ebe68821b0526f7d2505d23a13bf22676f9bd55456263b73c20f72")
