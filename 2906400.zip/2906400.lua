-- Lua provided by RyzenAPI
-- Game: 幻想 · 遇见秦始皇 Fantasy Encountering Emperor Qin Shi Huang

-- MAIN APPLICATION
addappid(2906400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906401, 1, "8731ac2991e994d9feab4bb38b3eba619d2a31ddaba5b27b81cd6c9602670493")

