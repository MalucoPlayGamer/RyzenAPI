-- Lua provided by RyzenAPI
-- Game: addappid(2906400)

-- MAIN APPLICATION
addappid(2906400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906401, 1, "8731ac2991e994d9feab4bb38b3eba619d2a31ddaba5b27b81cd6c9602670493")
