-- Lua provided by RyzenAPI
-- Game: 665380

-- MAIN APPLICATION
addappid(665380)
-- Game: addappid(665380)

-- MAIN APP DEPOTS / PACKAGES
addappid(665381, 1, "a792bf015c0d133e2219891cded6b206019225bdc5032349f9a35e4b029ece63")
