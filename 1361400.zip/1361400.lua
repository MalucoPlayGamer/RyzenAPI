-- Lua provided by RyzenAPI
-- Game: Moonglow Bay

-- MAIN APPLICATION
addappid(1361400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361401, 1, "1e059ff1c76841cf5f86012423917391cc87d3e7f175569897f2e2b3a839da2d")
