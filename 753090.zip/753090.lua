-- Lua provided by RyzenAPI 
-- Game: AppID 753090
addappid(753090)
addappid(753091, 1, "214506cf0a714d1cebeb3d14eaab2f314a2556eb52f6bc66cae2b51b8910a53f")
