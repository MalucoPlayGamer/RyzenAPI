-- Lua provided by RyzenAPI
-- Game: Hentai Swimming Club

-- MAIN APPLICATION
addappid(1361500)
-- Game: addappid(1361500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361501, 1, "ebffcf6ad1ee2fcdab938eab8cb4b9c8952e2194391b5e33d38ace444918b602")
