-- Lua provided by RyzenAPI
-- Game: Sovereign Tower

-- MAIN APPLICATION
addappid(4911710)

-- MAIN APP DEPOTS / PACKAGES
addappid(4113940, 1, "7b4b641711856dbb7c9ede38ee988e71a1a7873f6875b198e731b0d194297131") -- Sovereign Tower
addappid(4113941, 1, "72a67b6a779a04ab1979e4f34dd67306c9473be44d64e1ab9d04efe45f0166dd") -- Depot 4113941
addappid(4113942, 1, "6a2dbc58b967c2cea4a23e3903dfd05449477ea13be2fbb311b15f2d005dd35a") -- Depot 4113942
addappid(4911710, 1, "87ef30e4aa1dc814f4f26633728bab6de23ff603fbefc9600566da18f5c1dbe8") -- Sovereign Tower Artbook - Depot 4911710

