-- Lua provided by RyzenAPI
-- Game: Game: Eschalon: Book III

-- MAIN APPLICATION
addappid(257870)
-- Game: addappid(257870)

-- MAIN APP DEPOTS / PACKAGES
addappid(257871, 1, "2af66a7a3e5b0f3d5a0e6e6e95df71e1c1cbbb47878b7125e6b55e7619f40a5a")
addappid(257872, 1, "2c32f54a7610a44b12a06618b7f2f3dd33893bfe7ddf55627d0d4797cb5f91e1")
addappid(257873, 1, "abb9a6970143dc07492b7716281f744b89d98e09b047118c0328b85121038a51")
