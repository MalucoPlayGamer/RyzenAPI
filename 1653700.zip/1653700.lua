-- Lua provided by RyzenAPI
-- Game: Game: Lona: Realm Of Colors

-- MAIN APPLICATION
addappid(1653700)
-- Game: addappid(1653700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653701, 1, "d1665e811cf58e4833559b85864c25d423225ecf72dfc3934e4c1b5076aff538")
