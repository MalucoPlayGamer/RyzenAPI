-- Lua provided by RyzenAPI
-- Game: AppID 796790

-- MAIN APPLICATION
addappid(796790)
-- Game: addappid(796790)

-- MAIN APP DEPOTS / PACKAGES
addappid(796791, 1, "707f4a7ed6663b1a63c2e61b00b9e2d114a4dca005ad48138dcdd3c1e52b1bc1")
