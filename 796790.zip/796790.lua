-- Lua provided by RyzenAPI 
-- Game: AppID 796790
addappid(796790)
addappid(796791, 1, "707f4a7ed6663b1a63c2e61b00b9e2d114a4dca005ad48138dcdd3c1e52b1bc1")
