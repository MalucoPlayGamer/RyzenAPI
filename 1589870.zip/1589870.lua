-- Lua provided by RyzenAPI
-- Game: 咸鱼喵喵 Demo

-- MAIN APPLICATION
addappid(1589870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589871, 1, "1cb0ab45469ad4106110d041c8787e469f6e08a8bd08f9d6eff96f30bcd172fe")

