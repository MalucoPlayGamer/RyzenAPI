-- Lua provided by RyzenAPI
-- Game: AppID 524340

-- MAIN APPLICATION
addappid(524340)

-- MAIN APP DEPOTS / PACKAGES
addappid(524341, 1, "edd581099bfb5943b367add5bcfef001e9037f9e3ef19ff36f7651ba31fe9e8b")
