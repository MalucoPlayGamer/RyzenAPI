-- Lua provided by RyzenAPI
-- Game: Book of Korvald Demo

-- MAIN APPLICATION
addappid(2171870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171871, 1, "ab91e02b8f41cd422702568023bad869069f43cf7c423b18f428d869feef7b6b")

