-- Lua provided by RyzenAPI
-- Game: HEROIC

-- MAIN APPLICATION
addappid(2314340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2314341, 1, "f9e8ff30b54a64b83d67ded0cec7ca880c2b0c0eac933fbd68e4b6bce34f6f5c")

