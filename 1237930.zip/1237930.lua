-- Lua provided by RyzenAPI
-- Game: Road to Nowhere Demo

-- MAIN APPLICATION
addappid(1237930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237939,0,"4cc89564a8a096ab06b10ed2fefbcadc65fb950927b7c151fee9041942e5501c")

