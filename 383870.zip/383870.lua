-- Lua provided by RyzenAPI
-- Game: Firewatch

-- MAIN APPLICATION
addappid(383870)

-- MAIN APP DEPOTS / PACKAGES
addappid(383871, 1, "1a37285423d17dfbf1e4c0f3319192c79b8a2bf6d5c861b36298bc14504faa9b")
addappid(383872, 1, "8e553fee57cb14cdc44ce815d9c1b60c9dc0d430a8170e5ad5f3fad8e62f017b")
addappid(383874, 1, "eb74dde6a14da9a19a68950093a2357e4e2cd1523688ee3eb4b89d5b06ce62b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
