-- Lua provided by RyzenAPI
-- Game: 383870

-- MAIN APPLICATION
addappid(383870)
-- Game: addappid(383870)

-- MAIN APP DEPOTS / PACKAGES
addappid(383871, 1, "1a37285423d17dfbf1e4c0f3319192c79b8a2bf6d5c861b36298bc14504faa9b")
addappid(383872, 1, "8e553fee57cb14cdc44ce815d9c1b60c9dc0d430a8170e5ad5f3fad8e62f017b")
addappid(383874, 1, "eb74dde6a14da9a19a68950093a2357e4e2cd1523688ee3eb4b89d5b06ce62b5")
