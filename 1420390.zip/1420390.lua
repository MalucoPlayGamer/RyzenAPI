-- Lua provided by RyzenAPI
-- Game: AppID 1420390

-- MAIN APPLICATION
addappid(1420390)
-- Game: addappid(1420390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420391, 1, "f603b6ebeaf001fadef5a29566eeb2712452e1a3a1aaa08276e91e4dd4aa6976")
addappid(1420392, 1, "bd072b9c308a3c587c0c124d39ec3839c0a6351122b61d83fa5d4ee228c49dc8")
