-- Lua provided by RyzenAPI
-- Game: addappid(608830)

-- MAIN APPLICATION
addappid(608830)

-- MAIN APP DEPOTS / PACKAGES
addappid(608831, 1, "ccd7b79d6cddf4bbddddffb191d7fe4ff1fc18cce34865154a9ba97ad078c2a3")
