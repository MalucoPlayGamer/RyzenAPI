-- Lua provided by RyzenAPI
-- Game: Golazo! Soccer League

-- MAIN APPLICATION
addappid(1431040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431041, 1, "3350334fa99fbf83316b13484562a4bb3f7c60dded4b976f0144a7203d9d4929")
