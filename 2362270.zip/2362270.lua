-- Lua provided by RyzenAPI
-- Game: 2362270

-- MAIN APPLICATION
addappid(2362270)
-- Game: addappid(2362270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362270,0,"125167e9c38df7ba034d6e52fd99c3a2e3af306332bff0d8c49f43f5d5eec67b")
