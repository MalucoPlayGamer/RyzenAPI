-- Lua provided by RyzenAPI
-- Game: Outpost: Infinity Siege

-- MAIN APPLICATION
addappid(1566690)
-- Game: addappid(1566690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566691, 1, "2f25b4792849f0493263efdc7cf3568fece7f152d71b05e1665f42915251711e")
addappid(1566693, 1, "678d65c96e5197298e39d3ac4380e77848bb6805441e9e923a0a2a496268b618")
addappid(1566694, 1, "f6c10612bbdd0c3ce7ddaeddf85750cabc297cad5575e7330d35f96aef8b97f0")
