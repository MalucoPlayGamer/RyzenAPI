-- Lua provided by RyzenAPI
-- Game: Outpost: Infinity Siege

-- MAIN APPLICATION
addappid(1566690)
addappid(2897530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1566691, 1, "2f25b4792849f0493263efdc7cf3568fece7f152d71b05e1665f42915251711e")
addappid(1566693, 1, "678d65c96e5197298e39d3ac4380e77848bb6805441e9e923a0a2a496268b618")
addappid(1566694, 1, "f6c10612bbdd0c3ce7ddaeddf85750cabc297cad5575e7330d35f96aef8b97f0")

