-- Lua provided by RyzenAPI
-- Game: 2570020

-- MAIN APPLICATION
addappid(2570020)
-- Game: addappid(2570020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570021, 1, "d593ac7179637c4a05d54d29cbf9f8d237e846b4c8d903d8f764a6c68f33e737")
