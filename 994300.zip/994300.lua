-- Lua provided by RyzenAPI
-- Game: addappid(994300)

-- MAIN APPLICATION
addappid(994300)

-- MAIN APP DEPOTS / PACKAGES
addappid(994300,0,"a08e12187e65c89eb570e2b0558ef2d165a85158180e6ea575101ab155bb0fee")
