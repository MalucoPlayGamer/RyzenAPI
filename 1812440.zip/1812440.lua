-- Lua provided by RyzenAPI
-- Game: 1812440

-- MAIN APPLICATION
addappid(1812440)
-- Game: addappid(1812440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812441, 1, "ffb8a24ca8bfb46c17e7fefe199133df8e5c947f6b076bc0cff464dec0fd6b0f")
