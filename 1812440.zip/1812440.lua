-- Lua provided by RyzenAPI
-- Game: Polygon Hunter

-- MAIN APPLICATION
addappid(1812440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1812441, 1, "ffb8a24ca8bfb46c17e7fefe199133df8e5c947f6b076bc0cff464dec0fd6b0f")

