-- Lua provided by RyzenAPI
-- Game: 215820

-- MAIN APPLICATION
addappid(215820)

-- MAIN APP DEPOTS / PACKAGES
addappid(215820,0,"a2aa3b3e64f888e26dacab86fbad9e7f91cc2571fc0e562fc3510b7192c61a10")

