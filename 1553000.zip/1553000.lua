-- Lua provided by RyzenAPI
-- Game: War Hospital

-- MAIN APPLICATION
addappid(1553000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553001, 1, "15930f651a4be08ba6e98bae25d98c663bc8c9cd67db8b27ba7b89df023f0e16")
