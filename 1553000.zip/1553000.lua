-- Lua provided by RyzenAPI
-- Game: War Hospital

-- MAIN APPLICATION
addappid(1553000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553001, 1, "15930f651a4be08ba6e98bae25d98c663bc8c9cd67db8b27ba7b89df023f0e16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2465860)
addappid(2556920)
