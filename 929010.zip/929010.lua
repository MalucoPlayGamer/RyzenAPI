-- Lua provided by SkyAPI 
-- Game: Swag and Sorcery
addappid(929010)
addappid(929011, 1, "3b370a4fbe8d3d8d869f412243543f52bd851bed3862eda37a57a058f1ecf1e9")
