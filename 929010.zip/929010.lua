-- Lua provided by RyzenAPI
-- Game: Swag and Sorcery

-- MAIN APPLICATION
addappid(929010)

-- MAIN APP DEPOTS / PACKAGES
addappid(929011, 1, "3b370a4fbe8d3d8d869f412243543f52bd851bed3862eda37a57a058f1ecf1e9")
