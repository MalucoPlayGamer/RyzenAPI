-- Lua provided by RyzenAPI
-- Game: Sex Simulator - Beach Resort

-- MAIN APPLICATION
addappid(2481790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481791, 1, "7331c7d8fee18c9b3a0c4e1cf87d183ee3a1686d5644a3f51237daac2d6bbd55")

