-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Cathy is streaming


-- Main AppID
addappid(3629560) -- Hentai Clicker: Cathy is streaming

-- Main Depots
addappid(3629561, 1, "88f2d50fd925617507a2cee4a1eedd43b4d4898897a7ed985d20a35520f1dace") -- (windows)
-- setManifestid(3629561, "1745919808823589975", 163260713)

-- Missing Depots (We don't have the keys yet lol): 3629562, 3629563
