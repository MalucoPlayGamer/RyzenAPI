-- Lua provided by RyzenAPI
-- Game: Game: Hentai Clicker: Cathy is streaming

-- MAIN APPLICATION
addappid(3629560)
-- Game: addappid(3629560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629561, 1, "88f2d50fd925617507a2cee4a1eedd43b4d4898897a7ed985d20a35520f1dace")
