-- Lua provided by RyzenAPI
-- Game: Z-Sector

-- MAIN APPLICATION
addappid(4919550) -- Z-Sector

-- MAIN APP DEPOTS / PACKAGES
addappid(4919551, 1, "99fe19bacf5ab46c729a71700387af3334e3605e4793d61eb1c44609908eb0a7") -- Depot 4919551

