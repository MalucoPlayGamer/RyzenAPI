-- Lua provided by RyzenAPI
-- Game: Z-Sector

-- MAIN APP DEPOTS / PACKAGES
addappid(4919550, 1, "b4caa16362c7195004428dbea336f10ec666b42599672e5a1c2560bac8077a85") -- Z-Sector
addappid(4919551, 1, "99fe19bacf5ab46c729a71700387af3334e3605e4793d61eb1c44609908eb0a7") -- Depot 4919551

