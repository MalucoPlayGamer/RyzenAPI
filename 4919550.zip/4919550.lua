-- 4919550's Lua and Manifest Created by Hubcap Manifest
-- Z-Sector
-- Created: August 13, 2026 at 11:03:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4919550, 1, "b4caa16362c7195004428dbea336f10ec666b42599672e5a1c2560bac8077a85") -- Z-Sector
-- MAIN APP DEPOTS
addappid(4919551, 1, "99fe19bacf5ab46c729a71700387af3334e3605e4793d61eb1c44609908eb0a7") -- Depot 4919551
setManifestid(4919551, "8528011294086556946", 1807101447)