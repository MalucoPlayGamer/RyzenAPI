-- 4919550's Lua and Manifest Created by Hubcap Manifest
-- Z-Sector
-- Created: August 13, 2026 at 10:28:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4919550) -- Z-Sector
-- MAIN APP DEPOTS
addappid(4919551, 1, "99fe19bacf5ab46c729a71700387af3334e3605e4793d61eb1c44609908eb0a7") -- Depot 4919551
setManifestid(4919551, "8528011294086556946", 1807101447)