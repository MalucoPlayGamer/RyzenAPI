-- Lua provided by RyzenAPI 
-- Game: Biozone
addappid(19080)
addappid(19081, 1, "d1fe336698d5660f2200e7739d493ad8c72ef749cf16f05062b0ec93c2e44ee2")
