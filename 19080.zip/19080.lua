-- Lua provided by RyzenAPI
-- Game: 19080

-- MAIN APPLICATION
addappid(19080)
-- Game: addappid(19080)

-- MAIN APP DEPOTS / PACKAGES
addappid(19081, 1, "d1fe336698d5660f2200e7739d493ad8c72ef749cf16f05062b0ec93c2e44ee2")
