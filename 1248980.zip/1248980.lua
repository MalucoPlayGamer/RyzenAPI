-- Lua provided by RyzenAPI
-- Game: Game: AppID 1248980

-- MAIN APPLICATION
addappid(1248980)
-- Game: addappid(1248980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248981, 1, "a0765054824733fde44de196f225d1184216725125f84dade4529b52a8cff37b")
