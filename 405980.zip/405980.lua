-- Lua provided by RyzenAPI
-- Game: Game: Legend of Dungeon: Masters

-- MAIN APPLICATION
addappid(405980)
-- Game: addappid(405980)

-- MAIN APP DEPOTS / PACKAGES
addappid(405981, 1, "225df96b170e2118aceb4ffd56331a8f53f3b99a6672358112aa19504ae56720")
