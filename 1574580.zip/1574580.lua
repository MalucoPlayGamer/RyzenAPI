-- Lua provided by SkyAPI 
-- Game: Strange Horticulture
addappid(1574580)
addappid(1574581, 1, "855676fed2c8660b9bc487411cf69d3ea10a505a2a3b1abc4d76b0433098f7fc")
addappid(1574582, 1, "d7d7dfe8d8d85953f24146ddb4bd34b9f661e54a7ccc74803eb7134c97745484")
