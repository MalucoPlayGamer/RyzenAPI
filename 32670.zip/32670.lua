-- Lua provided by RyzenAPI
-- Game: addappid(32670)

-- MAIN APPLICATION
addappid(32670)

-- MAIN APP DEPOTS / PACKAGES
addappid(32671, 1, "c57bb3de47119ce3a57d1e5121b090c70c32e3b2b947a51e567d52c699fc0293")
