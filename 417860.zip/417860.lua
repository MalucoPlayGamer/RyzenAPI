-- Lua provided by RyzenAPI
-- Game: Emily is Away

-- MAIN APPLICATION
addappid(417860)
