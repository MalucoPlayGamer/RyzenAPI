-- Lua provided by RyzenAPI
-- Game: Necesse

-- MAIN APPLICATION
addappid(3947840) -- Necesse - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1169040, 1, "87c68f2c84f7f3025253c63356a2952bee8fd8c159e881c256ad3937b8bf9ddb") -- Necesse
addappid(1169042, 1, "168f31e2f178a84c6ac42b81a49598131bfe33cfe115f6c2188cf87989ebc324") -- Necesse Client Windows 32 bit
addappid(1169043, 1, "213875f02f19619160afdd222ef457dc27c0d7e35f183f232901e844a9a061a0") -- Necesse Client Windows 64 bit
addappid(1169044, 1, "98c386b7df6681759cdcdd6723f6addec4555e0a293f06bcc571ed9e576c6785") -- Necesse Client MacOS
addappid(1169045, 1, "385d7f0572023561ff4cc1316510498bf711d493334cf01045dae0190206c718") -- Necesse Client Linux

