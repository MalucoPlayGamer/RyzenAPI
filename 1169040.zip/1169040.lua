-- 1169040's Lua and Manifest Created by Hubcap Manifest
-- Necesse
-- Created: August 05, 2026 at 15:30:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1169040, 1, "87c68f2c84f7f3025253c63356a2952bee8fd8c159e881c256ad3937b8bf9ddb") -- Necesse
-- MAIN APP DEPOTS
addappid(1169042, 1, "168f31e2f178a84c6ac42b81a49598131bfe33cfe115f6c2188cf87989ebc324") -- Necesse Client Windows 32 bit
setManifestid(1169042, "2639262864618925425", 398992651)
addappid(1169043, 1, "213875f02f19619160afdd222ef457dc27c0d7e35f183f232901e844a9a061a0") -- Necesse Client Windows 64 bit
setManifestid(1169043, "2668505049230363070", 523966261)
addappid(1169044, 1, "98c386b7df6681759cdcdd6723f6addec4555e0a293f06bcc571ed9e576c6785") -- Necesse Client MacOS
setManifestid(1169044, "1535685253580017275", 506312647)
addappid(1169045, 1, "385d7f0572023561ff4cc1316510498bf711d493334cf01045dae0190206c718") -- Necesse Client Linux
setManifestid(1169045, "606387073416992105", 534026202)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3947840) -- Necesse - Supporter Pack