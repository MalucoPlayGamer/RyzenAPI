-- Lua provided by RyzenAPI
-- Game: Eternal Escape: castle of shadows

-- MAIN APPLICATION
addappid(3016090)
-- Game: addappid(3016090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016091, 1, "ccb78ad6fa77c00435ddedf46001e8b388787312e38d96f4bd0b627d03af9b20")
