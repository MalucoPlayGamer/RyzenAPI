-- Lua provided by RyzenAPI
-- Game: Act of Aggression - Reboot Edition

-- MAIN APPLICATION
addappid(318020)

-- MAIN APP DEPOTS / PACKAGES
addappid(318021, 1, "7ab6dd8f67baf01fb48b29ac386cd3f4b22475129d3b66fbf64be0db43a3a268")
addappid(318022, 1, "ca5d707ad774b637e77e40e61a2fc760e706784a1dc15c773c71d99f756dca65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
