-- Lua provided by RyzenAPI
-- Game: Scarlet Defiance: The Wall Between Us

-- MAIN APPLICATION
addappid(2866430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866431, 1, "a0fb1ad3c12a55b7515962cbd0df01df8b362165c2d82d7d33aa3ec17164eb31")

