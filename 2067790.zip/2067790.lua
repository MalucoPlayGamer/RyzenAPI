-- Lua provided by RyzenAPI
-- Game: Crimson Snow (2023)

-- MAIN APPLICATION
addappid(2067790)
-- Game: addappid(2067790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067791, 1, "29921a70c90074f509873c0a98c12f2f93cd0d32c5bc0d17944a9c83802377fb")
