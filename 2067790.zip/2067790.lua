-- Lua provided by RyzenAPI
-- Game: Crimson Snow (2023)

-- MAIN APPLICATION
addappid(2067790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2067791, 1, "29921a70c90074f509873c0a98c12f2f93cd0d32c5bc0d17944a9c83802377fb")

