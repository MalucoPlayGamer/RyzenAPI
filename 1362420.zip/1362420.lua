-- Lua provided by RyzenAPI
-- Game: Game: Siege Survival: Gloria Victis Prologue

-- MAIN APPLICATION
addappid(1362420)
-- Game: addappid(1362420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362421, 1, "b8921bcd8d78d3eb324c46dee40e037aa73bf7c95fcf2fad6093a6c75ac5bbe6")
