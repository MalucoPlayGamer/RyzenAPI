-- Lua provided by RyzenAPI
-- Game: 852060

-- MAIN APPLICATION
addappid(852060)
-- Game: addappid(852060)

-- MAIN APP DEPOTS / PACKAGES
addappid(852061, 1, "ac2f87410f8806437fda9aea3bdca3bef1bb9c695ad1d7c40175e5315e781671")
