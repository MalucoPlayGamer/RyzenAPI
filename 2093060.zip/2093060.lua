-- Lua provided by RyzenAPI
-- Game: Soulbound

-- MAIN APPLICATION
addappid(2093060)
addappid(3741740)
-- Game: addappid(2093060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093061, 1, "e2dd87c0d7b42f5681e7ba9669eb14afaa98b426b2011f3be8989fc9115da5f4")
addappid(2093062, 1, "77df7fdd6b4d91119d4a3cd815f7aa9042b4436870b10e129286f5ab243301a1")
addappid(2093063, 1, "0607eaa6d22a9fac7406b7740562b858371df7c72d5e6dda8b23a407d7b0a56f")
