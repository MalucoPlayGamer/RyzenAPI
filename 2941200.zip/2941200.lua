-- Lua provided by RyzenAPI
-- Game: addappid(2941200)

-- MAIN APPLICATION
addappid(2941200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941201, 1, "28fba5dadad2225742fa42564c4b14baf559c0d3cc441274784a6389f2acca0c")
