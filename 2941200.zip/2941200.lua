-- Lua provided by RyzenAPI
-- Game: Game: 幽幽子大人食欲不振 Yuyuko is suffering from lack of appetite

-- MAIN APPLICATION
addappid(2941200)
-- Game: addappid(2941200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941201, 1, "28fba5dadad2225742fa42564c4b14baf559c0d3cc441274784a6389f2acca0c")
