-- Lua provided by RyzenAPI
-- Game: Game: LOST EPIC

-- MAIN APPLICATION
addappid(1426490)
-- Game: addappid(1426490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426491, 1, "4f03c981cb3de5cf826d1ad57de0ebb52a091bfedfc8cf4472a073314f91d7f9")
