-- Lua provided by RyzenAPI
-- Game: LOST EPIC

-- MAIN APPLICATION
addappid(1426490)
addappid(2096340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1426491, 1, "4f03c981cb3de5cf826d1ad57de0ebb52a091bfedfc8cf4472a073314f91d7f9")

