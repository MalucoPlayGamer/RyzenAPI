-- Lua provided by RyzenAPI
-- Game: Game: AppID 2449930

-- MAIN APPLICATION
addappid(2449930)
-- Game: addappid(2449930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449931, 1, "bafa2442b36cacc5a24fe3337dc73f70071e77c8f161d7b4dccd173fcc5c8e1f")
