-- Lua provided by RyzenAPI 
-- Game: Witan
addappid(486490)
addappid(486491, 1, "609f442fc3b5e229e345e1c6d9135a0de300843688f89d560482c877f0244a6b")
