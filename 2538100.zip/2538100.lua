-- Lua provided by RyzenAPI
-- Game: 鬼小队 GhostBros

-- MAIN APPLICATION
addappid(2538100)
-- Game: addappid(2538100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538101, 1, "fa5a8f6110edfe94a100c1c6b517664d75b19008a061d4e316623346955f8079")
