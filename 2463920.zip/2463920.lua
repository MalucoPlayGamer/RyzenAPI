-- Lua provided by RyzenAPI
-- Game: Game: Little Monkey King's Big Quest

-- MAIN APPLICATION
addappid(2463920)
-- Game: addappid(2463920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463921, 1, "234cbf91732e50528c1d4ff047bb6518bb35c697086c4be3ed56ebd0b4e05241")
