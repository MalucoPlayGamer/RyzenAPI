-- Lua provided by RyzenAPI
-- Game: 我有上将

-- MAIN APPLICATION
addappid(1641340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641341, 1, "2a7d4c29556e6aab0c46fe4db3d91419ab8920074c3ce9dd63899bacc7a92a34")
