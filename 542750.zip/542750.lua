-- Lua provided by SkyAPI 
-- Game: AppID 542750
addappid(542750)
addappid(542751, 1, "08e2cf3b21574c54267e868aefa2fa5bf0786495db7e046b21c579e82ab6b213")
