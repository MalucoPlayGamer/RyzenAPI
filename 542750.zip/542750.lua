-- Lua provided by RyzenAPI
-- Game: addappid(542750)

-- MAIN APPLICATION
addappid(542750)

-- MAIN APP DEPOTS / PACKAGES
addappid(542751, 1, "08e2cf3b21574c54267e868aefa2fa5bf0786495db7e046b21c579e82ab6b213")
