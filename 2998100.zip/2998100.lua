-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - SERIALGAMES LivingGoodCity Tileset - Small Zoo Set

-- MAIN APPLICATION
addappid(2998100)
-- Game: addappid(2998100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998100,0,"48f0e0494ee44565c6c8752cd4665d543735d0cb0a52e76ff68374376b2224d1")
