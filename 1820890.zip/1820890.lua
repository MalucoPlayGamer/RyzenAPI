-- Lua provided by RyzenAPI
-- Game: Princess Sera adventures

-- MAIN APPLICATION
addappid(1820890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820891, 1, "73d80ab77f37124cabd895d6566d41b8428d0671eb9175570af62ba6837deb27")

