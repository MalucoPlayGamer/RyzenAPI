-- Lua provided by RyzenAPI 
-- Game: goblinAmerica Demo
addappid(2616730)
addappid(2616731, 1, "838123dcfb52c052be3d16d3ecfe486f76e7fc8e43cee7f5d1c0c48e0aed8b2f")
