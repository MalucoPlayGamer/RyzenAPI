-- Lua provided by RyzenAPI
-- Game: 2616730

-- MAIN APPLICATION
addappid(2616730)
-- Game: addappid(2616730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616731, 1, "838123dcfb52c052be3d16d3ecfe486f76e7fc8e43cee7f5d1c0c48e0aed8b2f")
