-- Lua provided by RyzenAPI
-- Game: addappid(3315330)

-- MAIN APPLICATION
addappid(3315330)
addappid(3798040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315331, 1, "344564527350bf3b50dd5c3b53fad031f3bb5ada52f603d1bdb73a357ae67290")
