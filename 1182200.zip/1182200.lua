-- Lua provided by RyzenAPI
-- Game: AppID 1182200

-- MAIN APPLICATION
addappid(1182200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182201, 1, "0d5f0cdd258cb330e25e9dfc3df41be75daf0f903f112c88185248cc3bf5c520")
