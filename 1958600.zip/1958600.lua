-- Lua provided by RyzenAPI
-- Game: Barro F22

-- MAIN APPLICATION
addappid(1958600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958601, 1, "424a2053b7f97f7adc33929e301ba09b1327ee21dec838135634c325ea04d8e2")
addappid(1958602, 1, "768a3437b36a25d7a67d3e8231d08470fce764751fd7a8e3437d0569d97e7246")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2944300)
addappid(3061640)
