-- Lua provided by RyzenAPI
-- Game: Project Mercury

-- MAIN APPLICATION
addappid(702150)

-- MAIN APP DEPOTS / PACKAGES
addappid(702151, 1, "6f21245ff9bcbbd7a030e1c2ce604859f798e6cef323d23016b88aa68c26c9dc")

