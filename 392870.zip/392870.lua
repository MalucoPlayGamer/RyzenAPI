-- Lua provided by RyzenAPI
-- Game: 392870

-- MAIN APPLICATION
addappid(392870)
addappid(491960)
-- Game: addappid(392870)

-- MAIN APP DEPOTS / PACKAGES
addappid(392871, 1, "faa7f3236dc60c86ce1fdc998e8c2a0935e9141f35a139e76b3c341146e0adaf")
