-- Lua provided by RyzenAPI
-- Game: Game: AppID 1872160

-- MAIN APPLICATION
addappid(1872160)
-- Game: addappid(1872160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872161, 1, "db9232ffcc58a6d8ced85b10f0ce2307bb4a7caf25755a991b31d44e04791d31")
