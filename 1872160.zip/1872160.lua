-- Lua provided by RyzenAPI
-- Game: AppID 1872160

-- MAIN APPLICATION
addappid(1872160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872161, 1, "db9232ffcc58a6d8ced85b10f0ce2307bb4a7caf25755a991b31d44e04791d31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
