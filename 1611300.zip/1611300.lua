-- Lua provided by RyzenAPI
-- Game: addappid(1611300)

-- MAIN APPLICATION
addappid(1611300)
addappid(1649810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611301, 1, "7e1a3795c5ff3060e3852805a9223dee0fdcc8dc8bbd62ae00ae54c8806f8056")
