-- Lua provided by SkyAPI 
-- Game: SGS Edit
addappid(1349320)
addappid(1349321, 1, "1869f71e501d4dab20b129b8e0be281401da62f0e76499cf5c8744a70c0a7c8b")
