-- Lua provided by RyzenAPI
-- Game: SGS Edit

-- MAIN APPLICATION
addappid(1349320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349321, 1, "1869f71e501d4dab20b129b8e0be281401da62f0e76499cf5c8744a70c0a7c8b")
