-- Lua provided by SkyAPI 
-- Game: Adorable Girls
addappid(1543980)
addappid(1543981, 1, "fa439b08a535482a41fbde0d810254ef2d4908eafa4bad2105f203dd88f42f36")
