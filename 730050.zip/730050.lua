-- Lua provided by RyzenAPI
-- Game: Verdant Skies

-- MAIN APPLICATION
addappid(730050)

-- MAIN APP DEPOTS / PACKAGES
addappid(730051, 1, "afe3a7d6ea825f6d9b7a2b529b8f122cd71228dabfac8d819808708715d5c117")
addappid(730052, 1, "72857a70331480c9fb407686649680eb6c316725550af0dc7db76679744e6dd4")
addappid(730053, 1, "f03ca3321a8e0391239d0417ab8c54de64fac77f086b0a632e9226003e3ff598")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
