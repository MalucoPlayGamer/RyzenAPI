-- Lua provided by RyzenAPI
-- Game: ACE COMBAT™ 7: SKIES UNKNOWN

-- MAIN APPLICATION
addappid(502500)
addappid(868310)
addappid(868311)
addappid(868312)
addappid(929100)
addappid(929101)
addappid(929102)
addappid(929103)
addappid(929104)
addappid(929105)
addappid(929106)
addappid(1421540)
addappid(1421550)
addappid(1421551)
addappid(1421552)
addappid(1421553)
addappid(1454770)
addappid(1561360)
addappid(1561361)
addappid(1561362)
addappid(1561363)
addappid(1561364)
addappid(1561365)
addappid(1692460)
addappid(1692462)
addappid(1692463)
addappid(1692464)
addappid(1692465)
addappid(1692466)
addappid(1966880)

-- MAIN APP DEPOTS / PACKAGES
addappid(502501, 1, "4e4b9bdc3f7b06ab29a76821f3b5bce34934c44681a99dce451c0bb12ea9ff2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
