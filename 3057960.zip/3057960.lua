-- Lua provided by RyzenAPI
-- Game: Don't take me away

-- MAIN APPLICATION
addappid(3057960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057961, 1, "616ee12e40cd2e2381b1ee0ca3e8aeafbf0ab198a3ee8cf78cebea16fe54173b")

