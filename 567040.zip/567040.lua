-- Lua provided by RyzenAPI
-- Game: AppID 567040

-- MAIN APPLICATION
addappid(567040)

-- MAIN APP DEPOTS / PACKAGES
addappid(567041, 1, "485ff2df979bcfbd1b5495a968b255c23d75423fe37def13f3b07f1f2d11af20")
addappid(582090, 0, "29f4fa32973ebdf77b9c0726678b70f42904e2a9a85229c3519690d37c476bdc")
addappid(704340, 0, "863a851a6671bd5f68e516b4b263e9dd64404eaa669e1a443135a3c695653842")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
