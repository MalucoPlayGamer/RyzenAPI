-- Lua provided by RyzenAPI 
-- Game: Slime Quest
addappid(946400)
addappid(946401, 1, "b5362bf0370bf4393798955377046f8ae4d61e7cb94cd6349300a5d5f9ae5d3a")
