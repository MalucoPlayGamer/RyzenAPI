-- Lua provided by RyzenAPI
-- Game: Magic Potion Destroyer

-- MAIN APPLICATION
addappid(676910)

-- MAIN APP DEPOTS / PACKAGES
addappid(676911, 1, "123c79b45045fa48857babb4f212e75c894cc9388b1a150df7b0129bc15a891c")
