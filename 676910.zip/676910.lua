-- Lua provided by SkyAPI 
-- Game: AppID 676910
addappid(676910)
addappid(676911, 1, "123c79b45045fa48857babb4f212e75c894cc9388b1a150df7b0129bc15a891c")
