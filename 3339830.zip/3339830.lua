-- Lua provided by RyzenAPI
-- Game: Succubus Roulette

-- MAIN APPLICATION
addappid(3339830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339831, 1, "ff17dda86efd25bb8f5f5fec810fe0d03c57eda6f6a630713dec383a26fd062f")

