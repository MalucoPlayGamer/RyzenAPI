-- Lua provided by RyzenAPI
-- Game: Alpha Version.0

-- MAIN APPLICATION
addappid(359970)
-- Game: addappid(359970)

-- MAIN APP DEPOTS / PACKAGES
addappid(359971, 1, "01201423d994f540807a00bb2e052e8bf33782ac7c09ec5f789eb4f385b47684")
