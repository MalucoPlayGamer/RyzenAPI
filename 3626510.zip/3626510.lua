-- Lua provided by RyzenAPI
-- Game: Game: AppID 3626510

-- MAIN APPLICATION
addappid(3626510)
-- Game: addappid(3626510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626511, 1, "9469507dc64d62f8b2db271ac85a42585838d7f45b3c61f2ad671bac55309832")
