-- Lua provided by RyzenAPI
-- Game: Mental Hospital - Child of Evil

-- MAIN APPLICATION
addappid(1734400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734401, 1, "470c2a2bce947d49ab009083d44538b510ff3c38794c5c1edd6071eb8f52bbe8")
