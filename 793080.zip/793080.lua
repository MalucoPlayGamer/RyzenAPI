-- Lua provided by RyzenAPI
-- Game: ばるばろっさ! ～すすめ? 赤軍少女旅団～(全年齢版)

-- MAIN APPLICATION
addappid(793080)

-- MAIN APP DEPOTS / PACKAGES
addappid(793081,0,"53293115673fff1e00135b9be15327e8b75faa20019a3b71a2ad4f7914f5603b")

