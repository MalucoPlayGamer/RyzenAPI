-- Lua provided by RyzenAPI
-- Game: Might & Magic X - Legacy

-- MAIN APPLICATION
addappid(238750)
-- Game: addappid(238750)

-- MAIN APP DEPOTS / PACKAGES
addappid(238751, 1, "a381f9792e1ebad56fc354e307dd22459a78f958549cbc94b70c8794ed227369")
addappid(249740, 0, "50295ad68c9644d9620fbb120f6a279c42e3c4561bfabb873edf6a17283d26f4")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
