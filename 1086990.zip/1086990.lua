-- Lua provided by RyzenAPI
-- Game: AppID 1086990

-- MAIN APPLICATION
addappid(1086990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1086991, 1, "b0c7add948e390baf3d95366f5ed029f287dd9f27975f74c4df562811b9d94e4")

