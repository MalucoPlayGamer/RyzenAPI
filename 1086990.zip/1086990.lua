-- Lua provided by RyzenAPI 
-- Game: AppID 1086990
addappid(1086990)
addappid(1086991, 1, "b0c7add948e390baf3d95366f5ed029f287dd9f27975f74c4df562811b9d94e4")
