-- Lua provided by SkyAPI 
-- Game: FURRY HITLER 2
addappid(2877950)
addappid(2877951, 1, "8bcf5397989d806e1a2592a454c0ab9c4483e53d89e722cee752e0c99d525d65")
