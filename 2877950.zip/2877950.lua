-- Lua provided by RyzenAPI
-- Game: 2877950

-- MAIN APPLICATION
addappid(2877950)
-- Game: addappid(2877950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877951, 1, "8bcf5397989d806e1a2592a454c0ab9c4483e53d89e722cee752e0c99d525d65")
