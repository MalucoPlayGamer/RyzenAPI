-- Lua provided by RyzenAPI
-- Game: The Adventures of Captain Potato

-- MAIN APPLICATION
addappid(871220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(871221,0,"02c2939bcc74ba1bc9c99c5039b1a451cf672b08053d765f5b5413449debe3cf")

