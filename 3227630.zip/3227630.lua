-- Lua provided by RyzenAPI
-- Game: Chicken Fall:Joint raid Demo

-- MAIN APPLICATION
addappid(3227630)
-- Game: addappid(3227630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227631, 1, "eef70868d6da726c7b4c6ad0cea52498ba3c4de314e6992e682380c5978c2d91")
