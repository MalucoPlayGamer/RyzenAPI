-- Lua provided by RyzenAPI
-- Game: Shop Tycoon The Boss

-- MAIN APPLICATION
addappid(590660)

-- MAIN APP DEPOTS / PACKAGES
addappid(590661,0,"9197ce6f4f14b063eb5a1ec4380298d4be9e2576a7aec2e304f89e029d3bb4d9")

