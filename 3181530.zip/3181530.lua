-- Lua provided by RyzenAPI
-- Game: 3181530

-- MAIN APPLICATION
addappid(3181530)
-- Game: addappid(3181530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181530,0,"ff99008913ebf89123873aa135be10780f29ab0db8c08ead30bed9178660bd06")
