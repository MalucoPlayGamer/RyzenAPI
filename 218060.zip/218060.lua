-- Lua provided by RyzenAPI
-- Game: BIT.TRIP Presents... Runner2: Future Legend of Rhythm Alien

-- MAIN APPLICATION
addappid(218060)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(218061, 1, "0fd877eaee236e3bd4396b1c904ae91a2267feefc7c146e70fda1d936210672d")
addappid(218062, 1, "f1abbc6cdd26dc7f3ec2d97637f6b7c3ff77e9e5cbf6d456cea3df79b81558f7")
addappid(218063, 1, "212d05320a551ecc2ad33ce3a99a159d2a7a391bb1fa3d2e3fb9115df010fb54")
addappid(218065, 1, "253268bfa82c5e797b3f0cb943e7efa0c955442172f407da13ed922e5f7e648c")
addappid(218066, 1, "d9b1e3d1804be97d3c02535d0cea5bf70c3d507713a3af8c9afb988815d95b05")
addappid(218067, 1, "dcc1516e5f1669a9239a4de03903c5c1884a854127d747f6557c5b46ea82b5a6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(218064)
