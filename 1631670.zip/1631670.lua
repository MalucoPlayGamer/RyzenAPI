-- Lua provided by RyzenAPI
-- Game: Game: Project: AHNO's Ark

-- MAIN APPLICATION
addappid(1631670)
-- Game: addappid(1631670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631671, 1, "fef774b8c85834295d6e0f721b7770079155f79c667d3254841a7ebff45acb4b")
