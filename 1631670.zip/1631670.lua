-- Lua provided by RyzenAPI
-- Game: Project: AHNO's Ark

-- MAIN APPLICATION
addappid(1631670)
addappid(2717490)
addappid(3819400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631671, 1, "fef774b8c85834295d6e0f721b7770079155f79c667d3254841a7ebff45acb4b")

