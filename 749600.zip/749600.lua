-- Lua provided by RyzenAPI
-- Game: Insects runner

-- MAIN APPLICATION
addappid(749600)

-- MAIN APP DEPOTS / PACKAGES
addappid(749601, 1, "af1a07838f71454acb357eddc00f29fbd9ba936e5e9015c35d6f2f273e6a9f08")

