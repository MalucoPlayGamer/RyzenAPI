-- Lua provided by RyzenAPI
-- Game: 迅风的米斯特汀 Windy Mystletainn

-- MAIN APPLICATION
addappid(1289830)
-- Game: addappid(1289830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289831, 1, "8ada93c5be059efe511874c5b0c36971d8dfdd0ece383edc5859fce8e8cc1de2")
