-- Lua provided by RyzenAPI
-- Game: Sisters Royale: Five Sisters Under Fire

-- MAIN APPLICATION
addappid(1133300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1133301, 1, "3d77a54b438710a38982c90d714fc1fea4d92b7fbdb9f6c75a4ac8288f00fa5c")
addappid(1430580, 0, "8e02c4c4824f9e1de2d5fd1f8c1681e98615f833c841eb74635c0f05cfe4aacf")

