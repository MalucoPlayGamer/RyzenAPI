-- Lua provided by RyzenAPI
-- Game: 1133300

-- MAIN APPLICATION
addappid(1133300)
-- Game: addappid(1133300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133301, 1, "3d77a54b438710a38982c90d714fc1fea4d92b7fbdb9f6c75a4ac8288f00fa5c")
addappid(1430580, 0, "8e02c4c4824f9e1de2d5fd1f8c1681e98615f833c841eb74635c0f05cfe4aacf")
