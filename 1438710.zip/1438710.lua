-- Lua provided by RyzenAPI
-- Game: Modern Arena

-- MAIN APPLICATION
addappid(1438710)
addappid(1438770)
addappid(1496950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438711, 1, "919e96703b65c743f9480692798c4bb04b639cf76c6019185ecbfa137ce429a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2148530)
