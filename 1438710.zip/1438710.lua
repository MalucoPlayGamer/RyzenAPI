-- Lua provided by RyzenAPI
-- Game: Modern Arena

-- MAIN APPLICATION
addappid(1438710)
addappid(1438770)
addappid(1496950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438711, 1, "919e96703b65c743f9480692798c4bb04b639cf76c6019185ecbfa137ce429a3")
