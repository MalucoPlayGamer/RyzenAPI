-- Lua provided by RyzenAPI
-- Game: addappid(1630910)

-- MAIN APPLICATION
addappid(1630910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630911, 1, "8df89f5ef2beed5322f375dffd7c33b889a8bf74797d12ab0d457e8f22b9a8c4")
