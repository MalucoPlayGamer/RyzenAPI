-- Lua provided by RyzenAPI 
-- Game: AppID 1009850
addappid(1009850)
addappid(1009851, 1, "84011b0d64e0221c3a99b1b5bb3225d90c53ae790ac8f4309b25729bdcfccf51")
addappid(1009852, 1, "0c479931f41df98dd3bd6bc14d3a1e46dd46a9ea1edadf2990d4e85d24079f2f")
