-- 1009850's Lua and Manifest Created by Hubcap Manifest
-- OVR Advanced Settings
-- Created: September 30, 2025 at 05:31:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1009850) -- OVR Advanced Settings
-- MAIN APP DEPOTS
addappid(1009851, 1, "84011b0d64e0221c3a99b1b5bb3225d90c53ae790ac8f4309b25729bdcfccf51") -- OpenVR Advanced Settings Content
setManifestid(1009851, "2651652159210957100", 79180661)
addappid(1009852, 1, "0c479931f41df98dd3bd6bc14d3a1e46dd46a9ea1edadf2990d4e85d24079f2f") -- OVR Advanced Settings Linux
setManifestid(1009852, "399261972683075166", 37651833)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1342830) -- OVR Advanced Settings Small Donation
addappid(1342831) -- OVR Advanced Settings Medium Donation
addappid(1342840) -- OVR Advanced Settings Large Donation