-- Lua provided by RyzenAPI
-- Game: Junkyard Fury 2

-- MAIN APPLICATION
addappid(2077990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077991, 1, "e6c8102fc0556e325128fe578208e439444b7d82f4db75680dc4f2c45bd69d9b")
addappid(2268760, 0, "c9fdb6f7dd494d66f5427c1cd12d8a581e87f5c7ab662b233ebb66218ae49ead")

