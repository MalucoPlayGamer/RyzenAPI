-- Lua provided by RyzenAPI
-- Game: Snowdrop the Blade Master Demo

-- MAIN APPLICATION
addappid(2920180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920181, 1, "c991e78f71c3d139fc38b1f94c5e6b3b3c797d7acc3467503336001248139e19")
