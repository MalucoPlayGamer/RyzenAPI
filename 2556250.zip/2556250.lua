-- Lua provided by RyzenAPI
-- Game: Game: BZZZT Soundtrack

-- MAIN APPLICATION
addappid(2556250)
-- Game: addappid(2556250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556251, 1, "94fa5ba0956f28235e35c6a1867c79bf1d5a291f11d2388e7d4d1f9d1bae24b8")
addappid(2556252, 1, "8defcc679c4948b6db75f1df7dbcd902650b0098254625083bffd0678d335b21")
