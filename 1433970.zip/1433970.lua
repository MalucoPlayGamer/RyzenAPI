-- Lua provided by RyzenAPI 
-- Game: Cake Shop Simulator
addappid(1433970)
addappid(1433971, 1, "95b914c098423a10794c8c564b272b063a10dc19dca01a99bc2b14a55a682d39")
