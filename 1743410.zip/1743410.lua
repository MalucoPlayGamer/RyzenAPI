-- Lua provided by RyzenAPI
-- Game: FORGOTTEN: THE GAME

-- MAIN APPLICATION
addappid(1743410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743413,0,"0a7fc0f73bf68de14d98cb6695ba0f92ed744f4bf40cd6e1def6996cdb90999c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
