-- Lua provided by RyzenAPI
-- Game: 1743410

-- MAIN APPLICATION
addappid(1743410)
-- Game: addappid(1743410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743413,0,"0a7fc0f73bf68de14d98cb6695ba0f92ed744f4bf40cd6e1def6996cdb90999c")
