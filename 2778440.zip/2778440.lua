-- Lua provided by RyzenAPI
-- Game: addappid(2778440)

-- MAIN APPLICATION
addappid(2778440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778441, 1, "5acee93a25f1f3e1b589b9e3cbe5d43fa200a9533595dddd10776174856559a8")
