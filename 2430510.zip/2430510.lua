-- Lua provided by RyzenAPI
-- Game: 2430510

-- MAIN APPLICATION
addappid(2430510)
-- Game: addappid(2430510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430511, 1, "c131177976488b70bb1157becd4ece8d6a5c2e368a0eeec1c352333494026025")
