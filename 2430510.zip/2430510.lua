-- Lua provided by SkyAPI 
-- Game: Pyramid Curse
addappid(2430510)
addappid(2430511, 1, "c131177976488b70bb1157becd4ece8d6a5c2e368a0eeec1c352333494026025")
