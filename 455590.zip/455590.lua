-- Lua provided by RyzenAPI
-- Game: AppID 455590

-- MAIN APPLICATION
addappid(455590)

-- MAIN APP DEPOTS / PACKAGES
addappid(455591, 1, "db60a65348424cfa7641fc8d0bea8afea7b3d0b745bc8daccee8c4a9ddffb381")
addappid(455592, 1, "9fd27e9ef8d352ba68b13019b8a5211377e256ffd65cb18ab5699cd48e6138d2")

