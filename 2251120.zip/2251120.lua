-- Lua provided by RyzenAPI
-- Game: League Manager 2023

-- MAIN APPLICATION
addappid(2251120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251122,0,"8f55b4ea0cd1c8dace4a9860a124b0d3ddbde22f3cda9674f947da46bffca62c")
addappid(2251123,0,"7a91acda3909807c5d315848cf79e4991c5b5f3924c8c7a0d897e982cfbae845")

