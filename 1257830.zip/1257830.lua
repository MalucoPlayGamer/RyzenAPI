-- Lua provided by RyzenAPI
-- Game: 1257830

-- MAIN APPLICATION
addappid(1257830)
-- Game: addappid(1257830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257830,0,"ebaf32b3ea0b522dee6c7bf2d9a5f3bd7d3d0a4147931de9295f6e9ba7782a17")
