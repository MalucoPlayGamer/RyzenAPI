-- Lua provided by RyzenAPI
-- Game: Taking London

-- MAIN APPLICATION
addappid(3596510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596512,0,"31e4ce51459ff4617dd672983a9904c65777ec8c8009acd947e1ecbdf78ea03d")

