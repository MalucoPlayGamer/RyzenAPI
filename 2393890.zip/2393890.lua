-- Lua provided by RyzenAPI
-- Game: Game: IGNISTONE

-- MAIN APPLICATION
addappid(2393890)
-- Game: addappid(2393890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393891, 1, "53e8095bd4d039a14664ebbf22f723eb7e25e3526ca8344fc9831fa7bec15f8d")
