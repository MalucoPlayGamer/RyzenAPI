-- Lua provided by RyzenAPI
-- Game: Virtue's Heaven

-- MAIN APPLICATION
addappid(1929860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929861, 1, "25e13d07ffdd125eb7c7f7d778e46ee37ffaf54ef5ce797a5f9c55dafa3a2094")
