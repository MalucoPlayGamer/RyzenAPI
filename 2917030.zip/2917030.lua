-- Lua provided by SkyAPI 
-- Game: Echocalypse: The Scarlet Covenant
addappid(2917030)
addappid(2917031, 1, "55b2517de4f8978e135dd508b6751b9b31ce27d27fc080631c817554f3bb3d87")
