-- Lua provided by RyzenAPI
-- Game: Echocalypse: The Scarlet Covenant

-- MAIN APPLICATION
addappid(2917030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917031, 1, "55b2517de4f8978e135dd508b6751b9b31ce27d27fc080631c817554f3bb3d87")
