-- Lua provided by RyzenAPI
-- Game: AppID 825630

-- MAIN APPLICATION
addappid(825630)

-- MAIN APP DEPOTS / PACKAGES
addappid(825631, 1, "7272d6df7ae168e82d805f977c206d71014577137fdbee034e37d72263bf7356")
addappid(825632, 1, "57b3859a5400960dfd2f28cde339bc763997eb76e5020644ec5760d0e836bca3")
addappid(825633, 1, "6e52df2d665a0a86727a0ac82152d4d3a29fb09e9d1331bd644fc1d7b6bfeb62")
addappid(825634, 1, "6a322f897cfdd28ab04750b2547f554513251aa769ff828723c40e8907a241aa")
addappid(825635, 1, "efcbbd8adef0b300f121cb3e2dc2981b0384bbb5108525c6e66a7e3b4126290c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
