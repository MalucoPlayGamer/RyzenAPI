-- Lua provided by RyzenAPI
-- Game: addappid(3318380)

-- MAIN APPLICATION
addappid(3318380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318381, 1, "02823b3500b97e53fd4f3a22e12c32a50cffed659cf3b8b913c2a36812f3c38e")
