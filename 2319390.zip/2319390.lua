-- Lua provided by RyzenAPI
-- Game: Game: Kvark

-- MAIN APPLICATION
addappid(2319390)
addappid(3299860)
-- Game: addappid(2319390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319391, 1, "ab468b4ee689abc23d988a13c44594743242e3a7d2660d7ba32727303ca0239c")
