-- Lua provided by RyzenAPI
-- Game: Pandemommyum! Hot Single Moms in My Area

-- MAIN APPLICATION
addappid(2486030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486032,0,"8523d1bf34b40406e70dce009a3aafcd0efd22a5bce64dd93c44ce74cbf61e18")

