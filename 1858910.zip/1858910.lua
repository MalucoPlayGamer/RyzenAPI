-- Lua provided by RyzenAPI 
-- Game: AppID 1858910
addappid(1858910)
addappid(1858911, 1, "6e2ed085140aa875947d17b940fe614c577103d4b05af003430d2b7dcfb7bfde")
