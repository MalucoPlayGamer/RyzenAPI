-- Lua provided by RyzenAPI
-- Game: 2001150

-- MAIN APPLICATION
addappid(2001150)
-- Game: addappid(2001150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001153,0,"d9adca090dcae793017cc1b29762da5eb8b2cbb2510f6f47fb81c20cca69ba56")
addappid(2001154,0,"3ae5e1858084d5e8fdc1a858d80530b1604f55652174be6a576b726ffa250cfa")
