-- Lua provided by SkyAPI 
-- Game: 101 Cats in Kuala Lumpur
addappid(3582800)
addappid(3582801, 1, "a82cf856725c92d948facd88a1d537caafb951ea0b5836730f433e0dfb10806e")
