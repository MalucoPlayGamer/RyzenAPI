-- Lua provided by RyzenAPI
-- Game: Essence Bloom

-- MAIN APPLICATION
addappid(2846200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846202,0,"f81a1ba723226013172aac61e09e2af0ae5a7871ca836590b2075a15bdfae4d4")

