-- Lua provided by RyzenAPI
-- Game: Game: Virtuar Z

-- MAIN APPLICATION
addappid(2581020)
-- Game: addappid(2581020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581021, 1, "43715b1b288f91344eec80f93bb3e7c21adeb7dc65d3cb3feefd8e31866c5dcb")
