-- Lua provided by RyzenAPI
-- Game: Wilson Chronicles - Beta

-- MAIN APPLICATION
addappid(313240)

-- MAIN APP DEPOTS / PACKAGES
addappid(313241, 1, "ce1635e6abe2257501dcd0101ca3f1ca39ecb6ef6dbebd127d55877feb3414f3")
addappid(313242, 1, "bfa7fbda798c32ab2df3b84843709786bb53ab4a5738253ec781147c4a9b5a2f")
addappid(313243, 1, "6b14fd5cac35da1ecd326bcc82e04507595983bade03116774af3e4ea97ee6a3")
addappid(313244, 1, "d0b2f3ba55f8aa6de021c66f97bb88f0c776cd04f7e7d1243c4cec15567c9552")
addappid(313245, 1, "a418a51d6611f899fbfe1782512dc2359c78502866bdba79acce738dba0fae82")
addappid(313246, 1, "d5d58cef729bd48cd86e5bc87c29b161d9bdead25734f896fb321970b6ab62b5")
addappid(313247, 1, "3d6cbf1cdd0cce1b069ff5b6cdfe6fad0d3e32fa753ca46aaf27aaebefb281da")
addappid(313248, 1, "e9e722d2b1acba5ff303224a55925721759dccb195541b17791c1075ea41e732")

