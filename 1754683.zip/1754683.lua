-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1754683)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754683,0,"84ea7914b3a4be9ab29aaaa095d4ecabb421ede988931c9df531e7eb39702655")
addtoken(1754683,5776473274934807548)

