-- Lua provided by RyzenAPI
-- Game: New Year Home

-- MAIN APPLICATION
addappid(3440830)
-- Game: addappid(3440830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440831, 1, "203d351f1270f495d55a9c8797ed286c8a7ed2a6b5de70a8989077a3e462793e")
