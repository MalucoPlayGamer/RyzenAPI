-- Lua provided by RyzenAPI
-- Game: New Year Home

-- MAIN APPLICATION
addappid(3440830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440831, 1, "203d351f1270f495d55a9c8797ed286c8a7ed2a6b5de70a8989077a3e462793e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
