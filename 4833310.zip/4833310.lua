-- Lua provided by RyzenAPI
-- Game: BreakEven - Idle

-- MAIN APP DEPOTS / PACKAGES
addappid(4833310, 1, "de45fa6227672a192ff36b7716b5196686dc2265f3ab088e06a4a40f0f9cf9dd") -- BreakEven - Idle
addappid(4833311, 1, "ef27444ded188b03ab1b254854678049c7ee44da12c27e977d2ad4d49931d06a") -- Depot 4833311
