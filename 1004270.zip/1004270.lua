-- Lua provided by RyzenAPI
-- Game: My Island

-- MAIN APPLICATION
addappid(1004270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1004271, 1, "e33708c654903e5852d50c652ae8682ffd62ddb00d56e466ddc9a4e2db063bda")

