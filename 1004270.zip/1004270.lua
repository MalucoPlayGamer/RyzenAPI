-- Lua provided by RyzenAPI
-- Game: AppID 1004270

-- MAIN APPLICATION
addappid(1004270)
-- Game: addappid(1004270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004271, 1, "e33708c654903e5852d50c652ae8682ffd62ddb00d56e466ddc9a4e2db063bda")
