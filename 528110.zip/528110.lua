-- Lua provided by RyzenAPI
-- Game: Tennis Elbow Manager

-- MAIN APPLICATION
addappid(528110)

-- MAIN APP DEPOTS / PACKAGES
addappid(528111,0,"1c26b1e826ab1526da5f0ab4dbabe729b8384972ed3c2d6651e059a7bc49e724")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
