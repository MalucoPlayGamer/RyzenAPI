-- Lua provided by RyzenAPI
-- Game: Teravit

-- MAIN APPLICATION
addappid(1743650)
-- Game: addappid(1743650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743651, 1, "2da132452fa8f0630e313808fd85533729b8402ac59dd8a8f3752458ff22943e")
