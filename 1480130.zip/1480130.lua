-- Lua provided by RyzenAPI
-- Game: Free-Bees

-- MAIN APPLICATION
addappid(1480130)
-- Game: addappid(1480130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480131, 1, "01bc62b62bc5f551434b87696e4a8d6dcbabe581998c6757045a9199f368642d")
