-- Lua provided by RyzenAPI
-- Game: Fart Fiasco Premium

-- MAIN APPLICATION
addappid(1153720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153721, 1, "cb94fdad9f8dbe33caca39c08e7969a4af46a7a30a0d7e0437afe021db579c6f")
