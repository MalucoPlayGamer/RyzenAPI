-- Lua provided by RyzenAPI
-- Game: addappid(2122130)

-- MAIN APPLICATION
addappid(2122130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122131, 1, "5a55f17332cc0147ba962bab14c5d4d0d21a8da2312f7a7be6b4cee12de9649d")
