-- Lua provided by SkyAPI 
-- Game: AppID 1155330
addappid(1155330)
addappid(1155331, 1, "162e3f67b49ada80838196b01e21f4b93bbac53734b24528e22d422d30d6c208")
