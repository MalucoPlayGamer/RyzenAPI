-- Lua provided by RyzenAPI
-- Game: Showgunners

-- MAIN APPLICATION
addappid(1155330)
addappid(2303680)
addappid(2362290)
addappid(2362291)
addappid(2362292)
addappid(2362293)
addappid(2362294)
addappid(2362295)
addappid(2362296)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155331,0,"162e3f67b49ada80838196b01e21f4b93bbac53734b24528e22d422d30d6c208")
addappid(2303680,0,"4a2e4162088276b43536526a4294bf15c770f9517934542c0e8395968b819ec0")
addappid(2362290,0,"fc871fd35388373eb8fd06bdc77e24890ba67230ae7beff586d70c8d73cac68e")
addappid(2362292,0,"295c8bc4cf46a75292a16b89032f8ea23c74c5dcb12ddaa9de0cbd1dc76c23a3")
addappid(2362293,0,"be6bb5abc476d92e2d481007a776275a2126fe7b104cea8b64f013a1f9a44f03")
addappid(2362294,0,"14dc4a1b9c93ac3c1898c5dab6cd2b3362679551e0a270b9ff81c9d5d5241300")
addappid(2362295,0,"a43c70537181f2f88f6abe0e06af8fecf00e8d991bd0ca3f117908e67f25eeb4")
addappid(2362296,0,"f720db778fdaa1ad24d977736810f92b3c22575c7f6d945943d8ac4d24ea8ed2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
