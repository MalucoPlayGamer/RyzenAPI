-- Lua provided by RyzenAPI
-- Game: Game: AppID 1155330

-- MAIN APPLICATION
addappid(1155330)
-- Game: addappid(1155330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155331, 1, "162e3f67b49ada80838196b01e21f4b93bbac53734b24528e22d422d30d6c208")
