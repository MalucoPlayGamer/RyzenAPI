-- 1088090's Lua and Manifest Created by Hubcap Manifest
-- Day of Dragons
-- Created: July 12, 2026 at 17:39:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 8
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1088090, 1, "6549ce72f16773b416b1dc2e9381ee0d4380c3d15bbd4420bd3d6aeceab6facf") -- Day of Dragons
-- MAIN APP DEPOTS
addappid(1088091, 1, "c8fded390dd82352109202f64e473964be4b799640bee5ede0a10751dbb49267") -- Day of Dragons - WindowsNoEditor
setManifestid(1088091, "3115703545461614450", 28847891957)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1174110) -- Day of Dragons - Acid Spitter Drake
addappid(1183040) -- Day of Dragons - Light Elemental Skin
addappid(1268630) -- Day of Dragons - Blitz Striker Amphithere
addappid(1649530) -- Day of Dragons - Shadow Scale Emote Pack
addappid(1649531) -- Day of Dragons - Flame Stalker Emote Pack
addappid(1649532) -- Day of Dragons - Inferno Ravager Emote Pack
addappid(2641120) -- Day of Dragons - Brood Watcher Emote Pack
addappid(4374790) -- Day of Dragons - Brindle Dragon Skin Pack