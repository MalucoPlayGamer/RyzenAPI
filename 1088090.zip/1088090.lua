-- Lua provided by RyzenAPI
-- Game: Day of Dragons

-- MAIN APPLICATION
addappid(1088090)
addappid(1174110)
addappid(1183040)
addappid(1268630)
addappid(1649530)
addappid(1649531)
addappid(1649532)
addappid(2641120)
addappid(4374790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088091,0,"c8fded390dd82352109202f64e473964be4b799640bee5ede0a10751dbb49267")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
