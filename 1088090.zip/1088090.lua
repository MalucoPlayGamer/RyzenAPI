-- Lua provided by RyzenAPI
-- Game: Game: AppID 1088090

-- MAIN APPLICATION
addappid(1088090)
-- Game: addappid(1088090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088091, 1, "c8fded390dd82352109202f64e473964be4b799640bee5ede0a10751dbb49267")
