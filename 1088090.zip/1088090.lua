-- Lua provided by RyzenAPI
-- Game: Day of Dragons

-- MAIN APPLICATION
addappid(1088090)
addappid(1174110)
addappid(1183040)
addappid(1268630)
addappid(1649530)
addappid(1649531)
addappid(1649532)
addappid(2641120)
addappid(4374790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088091,0,"c8fded390dd82352109202f64e473964be4b799640bee5ede0a10751dbb49267")

