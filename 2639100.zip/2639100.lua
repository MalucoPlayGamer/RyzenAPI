-- Lua provided by RyzenAPI
-- Game: Inari

-- MAIN APPLICATION
addappid(2639100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639101, 1, "21f31c8adf14db935b09d4d1a9ea8e781df503db08605f5daa84515f3dd6f10c")

