-- Lua provided by RyzenAPI
-- Game: Oona the Druid's Path

-- MAIN APPLICATION
addappid(1464620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1464621, 1, "52aaf0430029e544561c482b2ce36d2014eeb92c9412f57d5f358f55e850a0e1")

