-- Lua provided by RyzenAPI
-- Game: Oona the Druid's Path

-- MAIN APPLICATION
addappid(1464620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464621, 1, "52aaf0430029e544561c482b2ce36d2014eeb92c9412f57d5f358f55e850a0e1")

