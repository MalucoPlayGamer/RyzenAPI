-- Lua provided by RyzenAPI
-- Game: Xiuzhen Idle DLC - Cosmetics

-- MAIN APPLICATION
addappid(2426820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426820,0,"0f8b919d4053a48bb6c01db8ea23854e7418dc3f381910c766d7e1c1d9777503")

