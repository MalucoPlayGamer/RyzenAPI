-- Lua provided by RyzenAPI
-- Game: AppID 681390

-- MAIN APPLICATION
addappid(681390)
-- Game: addappid(681390)

-- MAIN APP DEPOTS / PACKAGES
addappid(681391, 1, "6a314a43c04e8c0fe1f9623a120deaf6378ab5cdce31575393e5e55f56ef2668")
addappid(681392, 1, "f43549b7afe11b5f909aba9fe5cb8d1fca453fb8d38078c1f0129bb6fb5c78d8")
