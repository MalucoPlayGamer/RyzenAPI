-- Lua provided by RyzenAPI
-- Game: ZomDay

-- MAIN APPLICATION
addappid(681390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(681391, 1, "6a314a43c04e8c0fe1f9623a120deaf6378ab5cdce31575393e5e55f56ef2668")
addappid(681392, 1, "f43549b7afe11b5f909aba9fe5cb8d1fca453fb8d38078c1f0129bb6fb5c78d8")

