-- Lua provided by RyzenAPI
-- Game: Spatial

-- MAIN APPLICATION
addappid(1587140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587141, 1, "2eb2e71e61a4010c554fd4deb558dca97a6ebab51890c074620d4448357e75ff")
