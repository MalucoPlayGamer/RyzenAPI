-- Lua provided by RyzenAPI
-- Game: Game: AppID 970520

-- MAIN APPLICATION
addappid(970520)
-- Game: addappid(970520)

-- MAIN APP DEPOTS / PACKAGES
addappid(970521, 1, "32e693c897a34259dab74cd251341a2240b17053e3a62098151bb433e24f8a99")
