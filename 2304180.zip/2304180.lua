-- Lua provided by RyzenAPI
-- Game: Gyno Tales - Season 1

-- MAIN APPLICATION
addappid(2304180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304181, 1, "18528a406bf635988afac5a01f61eb19cc3e006afab755645b394689b4c78911")
