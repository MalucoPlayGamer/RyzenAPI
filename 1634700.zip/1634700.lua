-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Horse "Silver Coat"

-- MAIN APPLICATION
addappid(1634700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634700,0,"4c6af6591fd7eaaf704cb548df57a46468f08ac55a00d6ac99a133043601ee83")

