-- Lua provided by RyzenAPI
-- Game: addappid(3165940)

-- MAIN APPLICATION
addappid(3165940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165941, 1, "3fef96ea9cb90a5935604e3e8ffd317e9e7c51f9afa8c0166440b72aaa683728")
