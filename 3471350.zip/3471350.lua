-- Lua provided by RyzenAPI
-- Game: Alpha League HD

-- MAIN APPLICATION
addappid(3471350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471351, 1, "d87879ecb0b506b4546d8405e77f7b8c837e4e637883765eba4c5f1fc5f2f492")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
