-- Lua provided by SkyAPI 
-- Game: Alpha League HD
addappid(3471350)
addappid(3471351, 1, "d87879ecb0b506b4546d8405e77f7b8c837e4e637883765eba4c5f1fc5f2f492")
