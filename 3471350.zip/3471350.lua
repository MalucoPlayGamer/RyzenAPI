-- Lua provided by RyzenAPI
-- Game: Alpha League HD

-- MAIN APPLICATION
addappid(3471350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471351, 1, "d87879ecb0b506b4546d8405e77f7b8c837e4e637883765eba4c5f1fc5f2f492")

