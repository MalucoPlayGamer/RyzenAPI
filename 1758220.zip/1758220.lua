-- Lua provided by RyzenAPI
-- Game: 1758220

-- MAIN APPLICATION
addappid(1758220)
-- Game: addappid(1758220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758221, 1, "67673d82bda99592e1e6991328b39a4e9b730a979c0156cb34e0c0edea80b748")
