-- Lua provided by SkyAPI 
-- Game: 13:ORIGIN - Chapter One
addappid(1758220)
addappid(1758221, 1, "67673d82bda99592e1e6991328b39a4e9b730a979c0156cb34e0c0edea80b748")
