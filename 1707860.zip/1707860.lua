-- Lua provided by RyzenAPI
-- Game: addappid(1707860)

-- MAIN APPLICATION
addappid(1707860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707861, 1, "eb30dee735b1aa73bc072be83386e9966e81bf460ee1c8f676003aa054f99fad")
addappid(1707862, 1, "6dff2abb8788b4492220dbfab5b6dfd998b4930e60c1a4b902e5de29d5b07a77")
