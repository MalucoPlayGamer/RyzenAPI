-- Lua provided by RyzenAPI
-- Game: addappid(869400)

-- MAIN APPLICATION
addappid(869400)

-- MAIN APP DEPOTS / PACKAGES
addappid(869403,0,"d5c15cc26d16774ba2fdf2a637583c54d08ad073951a9592f82e59239a60dafd")
