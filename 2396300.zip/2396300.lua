-- Lua provided by SkyAPI 
-- Game: My Life of Repayment
addappid(2396300)
addappid(2396301, 1, "70d6fbed8126202238813e69f45a8104ec8e6a97cf9bce3ce8fed716f1de31f1")
