-- Lua provided by RyzenAPI
-- Game: 2396300

-- MAIN APPLICATION
addappid(2396300)
-- Game: addappid(2396300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396301, 1, "70d6fbed8126202238813e69f45a8104ec8e6a97cf9bce3ce8fed716f1de31f1")
