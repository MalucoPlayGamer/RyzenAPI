-- Lua provided by RyzenAPI
-- Game: 傲慢的怪獸公主與名偵探使魔 Demo

-- MAIN APPLICATION
addappid(2589170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589171, 1, "57e6f4be1e53b3222d6be7b715fb74225f0205ae7499053a9a440b77b60623ac")

