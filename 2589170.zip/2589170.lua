-- Lua provided by SkyAPI 
-- Game: AppID 2589170
addappid(2589170)
addappid(2589171, 1, "57e6f4be1e53b3222d6be7b715fb74225f0205ae7499053a9a440b77b60623ac")
