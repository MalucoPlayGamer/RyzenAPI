-- Lua provided by RyzenAPI
-- Game: addappid(1163480)

-- MAIN APPLICATION
addappid(1163480)
addappid(1163483)
addappid(1163484)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163482,0,"ab57e7e3846a1d0bb5a2d5ac8669f7228d427c2e16e64bfb7e8f6401e926dc7f")
