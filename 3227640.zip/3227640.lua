-- Lua provided by RyzenAPI
-- Game: Game: Sorting Inc

-- MAIN APPLICATION
addappid(3227640)
-- Game: addappid(3227640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227641, 1, "517ebd1d84a05a3bca6565e11a3a04a9aa7d583ca1209b15c353f0dbfa12e3e7")
