-- Lua provided by RyzenAPI
-- Game: one game of game

-- MAIN APPLICATION
addappid(1008290)
-- Game: addappid(1008290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008291, 1, "1c1f30c19134c10f1647772f07566e7cb0162695f4e9ded6a2c98b2e98324f8e")
