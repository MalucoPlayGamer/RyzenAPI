-- Lua provided by RyzenAPI
-- Game: Hello Lady! -New Division-

-- MAIN APPLICATION
addappid(1025070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1025071, 1, "0cf3f36438eaa0f85307c39c7f7d164a95e99a3e88675392c2f86b36afff98e8")
addappid(1025072, 1, "f59e82b8292532f72a9e5ec05d5584f68239a0e8d5181fe23705c74bbd5e3fb5")
addappid(1025073, 1, "7b640401a9dba9182e3d45409c659d886f86097ec10901cc8eccd2712a51c668")
