-- Lua provided by SkyAPI 
-- Game: AppID 3246570
addappid(3246570)
addappid(3246571, 1, "aed85f51a9d0d3f3f9b54ce533838b0caea32d8e50be3d35020405a80b9fd155")
