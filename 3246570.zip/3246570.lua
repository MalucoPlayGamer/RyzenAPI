-- Lua provided by RyzenAPI
-- Game: I wannna be The King! Demo

-- MAIN APPLICATION
addappid(3246570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246571, 1, "aed85f51a9d0d3f3f9b54ce533838b0caea32d8e50be3d35020405a80b9fd155")
