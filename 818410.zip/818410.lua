-- Lua provided by RyzenAPI
-- Game: Space Hole 2018

-- MAIN APPLICATION
addappid(818410)

-- MAIN APP DEPOTS / PACKAGES
addappid(818411,0,"e5a24a99747f9156b475c316dede04bac7638d65051e88a624c3226a0acd8f66")

