-- Lua provided by RyzenAPI 
-- Game: Chessarama
addappid(1831830)
addappid(1831831, 1, "e6725c73c7a027e03d32698300502b4414e0c8112119640c8b4a344856cf4052")
addappid(2673930, 0, "6263e48505f5ce6c8ee49a58662cedead9fb1a5410c267c182ad0b7a44c75a4d")
