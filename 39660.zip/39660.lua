-- Lua provided by RyzenAPI
-- Game: Game: AppID 39660

-- MAIN APPLICATION
addappid(39660)
-- Game: addappid(39660)

-- MAIN APP DEPOTS / PACKAGES
addappid(39661, 1, "30a92fff95bbc179c314e24c0c67200e83863b70c3f651b3a2dd1a10ab307dbd")
addappid(39662, 1, "6f2b1957d3402b85cc1c266a91f330a24cff7ca7560eeb62e71f87e0b6a9d8a6")
addappid(39663, 1, "cb5b685040792b19232f50cb6b8b6daece5085d633835becee4c1098f199e001")
addappid(39664, 1, "1eb024e44e45e7b457940792468cdbcb0bf3a43dfe30fc8028e28994feaa91b9")
addappid(39665, 1, "7b072dccadfca18cf7e4bf2ec00ba39ad99e2b636b4dd833d90355b2d3f70d43")
