-- Lua provided by RyzenAPI
-- Game: Game: Trash Horror Collection 4

-- MAIN APPLICATION
addappid(2846790)
-- Game: addappid(2846790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846791, 1, "00927f93d7ce164970ddda1d963f885bdd7b3c8642938808c367b5dca219f8e9")
