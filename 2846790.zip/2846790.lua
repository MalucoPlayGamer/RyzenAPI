-- Lua provided by SkyAPI 
-- Game: Trash Horror Collection 4
addappid(2846790)
addappid(2846791, 1, "00927f93d7ce164970ddda1d963f885bdd7b3c8642938808c367b5dca219f8e9")
