-- Lua provided by SkyAPI 
-- Game: AppID 2410550
addappid(2410550)
addappid(2410551, 1, "6bd934cedff96ee44b3dcf4ded9b825edfbdcce38c0ea9d832e30c5b108103a0")
