-- Lua provided by RyzenAPI 
-- Game: BEARS, VODKA, BALALAIKA! 🐻
addappid(1129220)
addappid(1129221, 1, "7e5f17cbf5959bf944f26fb928ba06e9dae31b96ee9f4a80ccf8f07f5691f26d")
addappid(1129222, 1, "0aadc9851e9707a00da3050d95b91137c2105af3fe3b8bbb3b363f85b5d010a6")
addappid(1129223, 1, "e0cd24dc3f05144d8b0e06f804ce236e02086b59f3a88f0106f1403bb38256c5")
