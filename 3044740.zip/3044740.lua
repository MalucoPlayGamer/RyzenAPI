-- Lua provided by RyzenAPI
-- Game: Game: V-LOVER!

-- MAIN APPLICATION
addappid(3044740)
-- Game: addappid(3044740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044741, 1, "7fe1736dcd0fdddc507d4692a06a7610a694c6875eeeca84ae09158c2ddf2165")
