-- Lua provided by RyzenAPI
-- Game: Polygunners

-- MAIN APPLICATION
addappid(1853840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853841, 1, "51543be026e8a517270aecf07c40cf4177a56b2e7ac80ffcd5329f14e6ce8d6b")

