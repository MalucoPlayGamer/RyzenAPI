-- Lua provided by RyzenAPI
-- Game: NecroCity

-- MAIN APPLICATION
addappid(1489310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489311, 1, "0b00d7d17545f43c579ec5df1d1b3a96e84b160bff57de308a33dc0fd34cc608")
