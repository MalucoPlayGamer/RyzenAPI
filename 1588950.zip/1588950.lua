-- Lua provided by RyzenAPI
-- Game: Mind-Blowing Girls 2

-- MAIN APPLICATION
addappid(1588950)
addappid(1588970)
-- Game: addappid(1588950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588951, 1, "2dcd34d991ab033c2d7809d3792d42b43c97ac7da08fb0436690fe074b9d9a41")
