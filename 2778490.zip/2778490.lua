-- Lua provided by RyzenAPI
-- Game: Millennia Demo

-- MAIN APPLICATION
addappid(2778490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778491, 1, "e835c32e215f44f9c9aa1a1663933e29f0317efa7cf02566f18437b59b0da108")

