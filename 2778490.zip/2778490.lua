-- Lua provided by SkyAPI 
-- Game: AppID 2778490
addappid(2778490)
addappid(2778491, 1, "e835c32e215f44f9c9aa1a1663933e29f0317efa7cf02566f18437b59b0da108")
