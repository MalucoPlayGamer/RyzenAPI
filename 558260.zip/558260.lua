-- Lua provided by RyzenAPI
-- Game: Gravel

-- MAIN APPLICATION
addappid(558260) -- Gravel
addappid(769740) -- Gravel Porsche Rallye pack
addappid(769750) -- Gravel Ice and Fire
addappid(769760) -- Gravel King of Buggies
addappid(769770) -- Gravel Armored Operation
addappid(769780) -- Gravel Colorado River
addappid(769790) -- Gravel Free car Bowler Bulldog
addappid(769800) -- Gravel Free car Acciona
addappid(769810) -- Gravel Free car BMW X6 Trophy Truck
addappid(769820) -- Gravel Free car Ford Bronco
addappid(769830) -- Gravel Free car Ford HRX
addappid(769850) -- Gravel Free car Opel Kadett GTE

-- MAIN APP DEPOTS / PACKAGES
addappid(558261, 1, "e5f05a146e00b4e3d61a6e50a73c87b83dffac1fedb1f26dcd15ae4d89bfc981") -- Gravel Windows Content
addappid(558262, 1, "106013e9e97fd0ac9801ca1167b38070d78c13282ee489b258b31b5c79133bd2") -- Gravel Port Data
addappid(558263, 1, "adfc19f2de16974d3c48aa0279a344e99055a6e343f06649b00561fadbb45185") -- Gravel Port Mac Binary
addappid(558264, 1, "f24378f7432845d0329d3d89643dc57dcfb0b44086566cf37ec4b1931fdc791b") -- Gravel Port Linux Binary
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
