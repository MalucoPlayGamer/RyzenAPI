-- Lua provided by RyzenAPI
-- Game: Football Club Simulator - FCS #21

-- MAIN APPLICATION
addappid(324090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(324091, 1, "cf5dfa6969d733763d96236beca790a481d4ade46fcb8398f96fc8cf310c5bc6")
addappid(324092, 1, "e37a45ff8cc62f3889cb04329c279d6b84a86a304f62a15885cb975bde7f813a")
addappid(324093, 1, "7055731ed6f22589f1e6542722f24320e50ff721f3988d52b20125279475f191")
addappid(324094, 1, "470989495cf393652a99bc7b1a31404b9982bfbd244bd30041d3821561542490")
addappid(324095, 1, "f57b940f76a9f0aeb245ea4ccc06b655f6951a0ed96719e8abb871e1cb702642")
