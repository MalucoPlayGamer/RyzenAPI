-- Lua provided by RyzenAPI
-- Game: Machorium -Muscle Aquarium Simulator-

-- MAIN APPLICATION
addappid(2903660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903661, 1, "4c188c8972d2ef5ae0d57ab15d15f27a2e9dfe22e7c1b61ad05b764b554393a2")

