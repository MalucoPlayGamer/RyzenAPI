-- Lua provided by RyzenAPI
-- Game: 686610

-- MAIN APPLICATION
addappid(686610)
-- Game: addappid(686610)

-- MAIN APP DEPOTS / PACKAGES
addappid(686611, 1, "69645f4b7442aa9f6a02157c0da26183c2c74b78f4c08f8e4f7af07a8e61bd0d")
