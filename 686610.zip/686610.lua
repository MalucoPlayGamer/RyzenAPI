-- Lua provided by RyzenAPI 
-- Game: Sobreviva
addappid(686610)
addappid(686611, 1, "69645f4b7442aa9f6a02157c0da26183c2c74b78f4c08f8e4f7af07a8e61bd0d")
