-- Lua provided by RyzenAPI
-- Game: Soulworker

-- MAIN APPLICATION
addappid(1377580)
-- Game: addappid(1377580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377581, 1, "1739a16356877ef5e098a61f8c453ab32f88bb0dc5a3c95383576ca0ff444477")
