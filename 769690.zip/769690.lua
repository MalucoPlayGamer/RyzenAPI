-- Lua provided by RyzenAPI
-- Game: Reading Simulator

-- MAIN APPLICATION
addappid(769690)

-- MAIN APP DEPOTS / PACKAGES
addappid(769691, 1, "a160789532ccd71984c5628c15d74f69dcb0462b22d5e3657182a41eeb5698b8")
