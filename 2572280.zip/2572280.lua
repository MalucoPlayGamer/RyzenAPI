-- Lua provided by RyzenAPI
-- Game: Game: THE SOUL OF TOO BIRDS GAME

-- MAIN APPLICATION
addappid(2572280)
-- Game: addappid(2572280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572281, 1, "be3202035c6d66adbfd70c92981fe351359233e4fc839bdfe1aabcf54f534193")
