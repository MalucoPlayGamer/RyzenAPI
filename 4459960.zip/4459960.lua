-- Lua provided by RyzenAPI
-- Game: Discord Bot Factory

-- MAIN APPLICATION
addappid(4459960)

-- MAIN APP DEPOTS / PACKAGES
addappid(4459963,0,"f63e6a472bab2f7ec715ba3b09595c1671d8c332ddcf0c45f5d8a60c454218c1")

