-- Lua provided by RyzenAPI
-- Game: 872180

-- MAIN APPLICATION
addappid(872180)
-- Game: addappid(872180)

-- MAIN APP DEPOTS / PACKAGES
addappid(872181, 1, "e90590711750d6557c0fe5d83d98dac558a524291bb340db2e6283876be3d5ee")
