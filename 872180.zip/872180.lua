-- Lua provided by RyzenAPI 
-- Game: AppID 872180
addappid(872180)
addappid(872181, 1, "e90590711750d6557c0fe5d83d98dac558a524291bb340db2e6283876be3d5ee")
