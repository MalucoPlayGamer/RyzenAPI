-- Lua provided by RyzenAPI
-- Game: Brutal Games

-- MAIN APPLICATION
addappid(1026060)
-- Game: addappid(1026060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026061, 1, "df8ff62d592d1e9168bd930f9366bdddce02c993fd67caefaf7c49eec40b1d09")
