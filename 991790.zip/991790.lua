-- Lua provided by RyzenAPI 
-- Game: AppID 991790
addappid(991790)
addappid(991791, 1, "b1d510aad5aa87787d733c0ff0f263564cfb9721267d02e7d4a9ca43e7ab6157")
addappid(991792, 1, "a74ad4768eab722cd7e8e8bdb33e54951a3739a319b9304a6057ead2dd533455")
