-- Lua provided by RyzenAPI
-- Game: Game: Starfend

-- MAIN APPLICATION
addappid(2540820)
-- Game: addappid(2540820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540821, 1, "fb81e818eddee2ca0d8a27cb9701382ee5f552250aed8d757c9747fe22d8b5df")
