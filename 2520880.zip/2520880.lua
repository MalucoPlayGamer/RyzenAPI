-- Lua provided by RyzenAPI
-- Game: 2520880

-- MAIN APPLICATION
addappid(2520880)
-- Game: addappid(2520880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520881, 1, "dd4b9875c1376cb9a16d3fae0c99de2765b77383eb0b88ec582309484c68165a")
