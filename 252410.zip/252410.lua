-- Lua provided by RyzenAPI
-- Game: AppID 252410

-- MAIN APPLICATION
addappid(252410)
-- Game: addappid(252410)

-- MAIN APP DEPOTS / PACKAGES
addappid(252411, 1, "05d7702c27c6483ef062cdd995081b8283474d6464b9ea54fd83f7a843a476e4")
addappid(252412, 1, "2873f3f86eedec4b3401851fa2303b28d84c363e0e4159658b3cfaca7f1e0799")
addappid(252413, 1, "3e0255680aae2bbaac320bccb9cfc50aa3efa762a4c8d4b34a4124d7efb25eba")
addappid(297900, 0, "3cd04ef4f35c1dfb1f1562fd09fd2218351a87a92f906b611ecd3557bd48ba51")
