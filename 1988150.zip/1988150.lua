-- Lua provided by RyzenAPI 
-- Game: Harem of Monster Girls
addappid(1988150)
addappid(1988151, 1, "d8116f1ff33aefdc3b98bdd16fa4d6d72f5b4a4b22329b1c563b5665c9c2449e")
