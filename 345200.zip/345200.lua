-- Lua provided by RyzenAPI
-- Game: Game: Tasty Blue

-- MAIN APPLICATION
addappid(345200)
-- Game: addappid(345200)

-- MAIN APP DEPOTS / PACKAGES
addappid(345201, 1, "5ff901dc074a9655a9293c3c2c7db4a5550a4c86b562c3e5d593fdb8291828c1")
addappid(345202, 1, "5f8c7144cd8f440b2d12629d559106584f36bcb9f35d0fe60dbef2ec18af0a7a")
