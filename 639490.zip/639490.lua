-- Lua provided by RyzenAPI
-- Game: 639490

-- MAIN APPLICATION
addappid(639490)
-- Game: addappid(639490)

-- MAIN APP DEPOTS / PACKAGES
addappid(639491, 1, "831f1ba78907bc9bb0b6068d040a726fb629e564c57dc540b0bc258e040e2a00")
