-- Lua provided by RyzenAPI
-- Game: 1144370

-- MAIN APPLICATION
addappid(1144370)
-- Game: addappid(1144370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144371, 1, "235bd35c44603cccb5c736bca71bcdd0d21a930fa76930a577c163a248683ae0")
