-- Lua provided by RyzenAPI 
-- Game: Your Sister
addappid(2957100)
addappid(2957101, 1, "745330b93973ea515b06bd1f5b257afcb4bc1c67a70a9d75f644dd70529f1a50")
