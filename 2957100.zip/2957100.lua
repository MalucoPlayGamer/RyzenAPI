-- Lua provided by RyzenAPI
-- Game: Your Sister

-- MAIN APPLICATION
addappid(2957100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2957101, 1, "745330b93973ea515b06bd1f5b257afcb4bc1c67a70a9d75f644dd70529f1a50")

