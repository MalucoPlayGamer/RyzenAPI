-- Lua provided by RyzenAPI
-- Game: Game: AppID 1128000

-- MAIN APPLICATION
addappid(1128000)
-- Game: addappid(1128000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128001, 1, "b9dbabf7542fc11c02bd4e0d11036d8225dfdf73e00331c750f236288748cc75")
