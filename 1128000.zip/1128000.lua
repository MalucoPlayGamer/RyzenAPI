-- Lua provided by RyzenAPI
-- Game: AppID 1128000

-- MAIN APPLICATION
addappid(1128000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128001, 1, "b9dbabf7542fc11c02bd4e0d11036d8225dfdf73e00331c750f236288748cc75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
