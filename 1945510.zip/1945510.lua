-- Lua provided by RyzenAPI
-- Game: Athanasy - Artbook

-- MAIN APPLICATION
addappid(1945510)
addappid(1945511)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945510,0,"ff1d70e2e251c7572ba6d87e17271196d92e24bd4f607696595176d7aefcff02")
