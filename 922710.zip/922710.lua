-- Lua provided by RyzenAPI
-- Game: AppID 922710

-- MAIN APPLICATION
addappid(922710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(922711, 1, "e57aea5f8a82464001d938164ca5f3e85544d7ee9f8f5361039341e04a400cea")

