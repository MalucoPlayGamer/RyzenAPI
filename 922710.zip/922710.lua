-- Lua provided by RyzenAPI
-- Game: AppID 922710

-- MAIN APPLICATION
addappid(922710)
-- Game: addappid(922710)

-- MAIN APP DEPOTS / PACKAGES
addappid(922711, 1, "e57aea5f8a82464001d938164ca5f3e85544d7ee9f8f5361039341e04a400cea")
