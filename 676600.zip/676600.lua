-- Lua provided by RyzenAPI
-- Game: Fuzzy's Quest

-- MAIN APPLICATION
addappid(676600)

-- MAIN APP DEPOTS / PACKAGES
addappid(676601, 1, "344c718cdaab73ae7f1221cf478b57fec0daf1140fdedf289affcd66c437cf96")

