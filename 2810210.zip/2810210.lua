-- Lua provided by RyzenAPI
-- Game: Codename CURE II

-- MAIN APPLICATION
addappid(2810210)

