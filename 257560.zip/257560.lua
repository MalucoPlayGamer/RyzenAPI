-- Lua provided by RyzenAPI
-- Game: AppID 257560

-- MAIN APPLICATION
addappid(257560)
-- Game: addappid(257560)

-- MAIN APP DEPOTS / PACKAGES
addappid(257561, 1, "28e6a3002e4b7e4fc38c12c4fffbcdbbb5e3f7feb9d2525a070b737cfccb0977")
addappid(257565, 1, "3faabb41bcc16fc19135cee2a07638f257b4444cf02c8768d05e658df792a341")
