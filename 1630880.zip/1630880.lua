-- Lua provided by RyzenAPI
-- Game: addappid(1630880)

-- MAIN APPLICATION
addappid(1630880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630881, 1, "398dc29fb86244c37723e81a36fba2654f8f42242fb1778a96dca099b16d550b")
