-- Lua provided by RyzenAPI
-- Game: Cat Chess

-- MAIN APPLICATION
addappid(4887870)
addappid(4912310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(4163030, 1, "a8c60b38b992c46a6fbed3849a5bdd54f55b3e190616be617257c30f4f6497f3") -- Cat Chess
addappid(4163031, 1, "e0ca196365997262f9e954542f3aefd38e8f5e8d4b6fb5e94d64d522f933b8e0") -- Depot 4163031
addappid(4887870, 1, "4a663ec146400e7f884949753ef465e062ec1ef206c5e7af7748c5e5ead18d20") -- Cat Chess - Supporter Cat - Depot 4887870
addappid(4912310, 1, "68e624ce711294a93969d57a5f7c04b1426db62839d937b63dfde6cc3171ac89") -- Cat Chess - RoyalCat(Deluxe Digital Edition) - Depot 4912310

