-- Lua provided by SkyAPI 
-- Game: Hentai Pussy 7
addappid(2386750)
addappid(2386751, 1, "daa64c5863ec8488737bb3036bbb14360a0a7111e18f115345622cbfdaee871a")
