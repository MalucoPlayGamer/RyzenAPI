-- Lua provided by RyzenAPI
-- Game: Game: Bagdex Demo

-- MAIN APPLICATION
addappid(3366040)
-- Game: addappid(3366040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3366041, 1, "52f26ed12c8c2e20f79880a89bff702a58e6b96ded72a74fa98dd38add509f59")
