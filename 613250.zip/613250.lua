-- Lua provided by RyzenAPI
-- Game: Keyboard Killer

-- MAIN APPLICATION
addappid(613250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(613259,0,"8814f6b0060f5f2baef1dae529b471e8af2b9862b0ca2e5c1dacd8352aa0a6a4")

