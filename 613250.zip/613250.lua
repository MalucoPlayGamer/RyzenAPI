-- Lua provided by RyzenAPI
-- Game: Keyboard Killer

-- MAIN APPLICATION
addappid(613250)

-- MAIN APP DEPOTS / PACKAGES
addappid(613259,0,"8814f6b0060f5f2baef1dae529b471e8af2b9862b0ca2e5c1dacd8352aa0a6a4")

