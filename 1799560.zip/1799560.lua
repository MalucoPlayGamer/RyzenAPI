-- Lua provided by RyzenAPI
-- Game: Larry The Unlucky Part 3

-- MAIN APPLICATION
addappid(1799560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799561, 1, "dc5c34a65d8859c82d32fe3e0c6a3c13dab78f8241796f68efd9898e90fc97e4")
