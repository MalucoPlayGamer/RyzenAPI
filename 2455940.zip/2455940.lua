-- Lua provided by RyzenAPI 
-- Game: After School
addappid(2455940)
addappid(2455941, 1, "89729124326f8f1e44ba9dfb5b43053014f6b00cf9cea874a573aa8028967f50")
