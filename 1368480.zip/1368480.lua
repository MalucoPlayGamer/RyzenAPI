-- Lua provided by RyzenAPI
-- Game: Voidwalkers - Astora's Darkness

-- MAIN APPLICATION
addappid(1368480)
addappid(1552610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1368481, 1, "e2c99a31f7c2187e5f7b4036b2d0cd53916b432ef9f1d5e4071fdac9933e48d4")

