-- Lua provided by RyzenAPI
-- Game: addappid(1368480)

-- MAIN APPLICATION
addappid(1368480)
addappid(1552610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368481, 1, "e2c99a31f7c2187e5f7b4036b2d0cd53916b432ef9f1d5e4071fdac9933e48d4")
