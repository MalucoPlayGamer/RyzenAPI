-- Lua provided by RyzenAPI
-- Game: addappid(619470)

-- MAIN APPLICATION
addappid(619470)

-- MAIN APP DEPOTS / PACKAGES
addappid(619471, 1, "6c96a074bda00f9987696b00c2bac67af315380bd10c0295488a6d41bcc41937")
