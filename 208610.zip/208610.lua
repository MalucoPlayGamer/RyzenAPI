-- Lua provided by RyzenAPI
-- Game: Skullgirls ∞Endless Beta∞

-- MAIN APPLICATION
addappid(208610)

-- MAIN APP DEPOTS / PACKAGES
addappid(208611, 1, "e0d7a9c0becda59b9deb43cb78f3ca948f03e67794e0c9a05c5bc25b8d176852")
addappid(208612, 1, "35a554a1608410ac0aef6507e9b2725488c910c21f8ef199e05ef96af9dbe959")
addappid(208613, 1, "d52a8e81aa599497669437c3442f87a976aa7558b1f5249e6c813f358edd0d65")
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
