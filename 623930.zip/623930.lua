-- Lua provided by RyzenAPI
-- Game: Solaria Moon

-- MAIN APPLICATION
addappid(623930)

-- MAIN APP DEPOTS / PACKAGES
addappid(623931, 1, "7450ce39bf6990ea58266c9cd32f15d77d11e7a70882d1ba025f610853191812")

