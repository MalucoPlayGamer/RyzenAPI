-- Lua provided by RyzenAPI
-- Game: 2772650

-- MAIN APPLICATION
addappid(2772650)
-- Game: addappid(2772650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772651, 1, "c535ddbbd87d7b26bcebd506009ea6fca0527b9e995e3fb9c47504b13232f29e")
