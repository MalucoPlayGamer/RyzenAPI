-- Lua provided by RyzenAPI
-- Game: addappid(1650980)

-- MAIN APPLICATION
addappid(1650980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650981, 1, "ed824be64fd075d3f06d3172279cb824b7304b1d8b6b7114d17a0118ebf1b989")
