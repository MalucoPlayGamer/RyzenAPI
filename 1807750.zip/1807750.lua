-- Lua provided by RyzenAPI
-- Game: 封神榜2022

-- MAIN APPLICATION
addappid(1807750)
addappid(1807751)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807752,0,"399cf9f245086900665b8075c20f4d62e93c190cdc5ada8d2a6b38de56a5ebe6")
