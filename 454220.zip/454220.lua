-- Lua provided by RyzenAPI
-- Game: 454220

-- MAIN APPLICATION
addappid(454220)
addappid(454225)
addappid(454226)
addappid(454227)
-- Game: addappid(454220)

-- MAIN APP DEPOTS / PACKAGES
addappid(454224,0,"86f2760bd20081eee2d0dafd22393e143714403f2c82ea8b499a96906fafd651")
