-- Lua provided by SkyAPI 
-- Game: Incitement 3
addappid(391660)
addappid(391661, 1, "800a58969eb98604720d069611d920899620b8f0fa34801513a703c8ec5819d1")
