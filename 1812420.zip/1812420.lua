-- Lua provided by RyzenAPI
-- Game: An Elder Scrolls Legend: Battlespire

-- MAIN APPLICATION
addappid(1812420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812421, 1, "d13adce10592a32b9c1614a262ad004b51c239f28bb9f1e5ed99daa3321fb8ed")

