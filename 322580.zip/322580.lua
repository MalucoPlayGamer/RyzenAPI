-- Lua provided by RyzenAPI
-- Game: AppID 322580

-- MAIN APPLICATION
addappid(322580)

-- MAIN APP DEPOTS / PACKAGES
addappid(322581, 1, "ef52757db60619ec4418b36e9607ea449b6bfbff29c132cc1afaccf53d4dae00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
