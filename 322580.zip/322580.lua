-- Lua provided by RyzenAPI
-- Game: AppID 322580

-- MAIN APPLICATION
addappid(322580)

-- MAIN APP DEPOTS / PACKAGES
addappid(322581, 1, "ef52757db60619ec4418b36e9607ea449b6bfbff29c132cc1afaccf53d4dae00")
