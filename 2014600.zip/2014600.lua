-- Lua provided by RyzenAPI
-- Game: Card Shark Digital Artbook

-- MAIN APPLICATION
addappid(2014600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014600,0,"8dc432030fb422c4f96b8f194433dec276bb25476c1d03fa0fea5a7beecd85d1")
addtoken(2014600,15092470204964636926)
