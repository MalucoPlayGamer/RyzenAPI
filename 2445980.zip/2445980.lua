-- Lua provided by RyzenAPI
-- Game: G-Rebels

-- MAIN APPLICATION
addappid(2445980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445981,0,"e0bbe713199445df229e9c0542b93100a26cfb2c837edbd065daf065317c3528")

