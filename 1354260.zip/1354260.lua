-- Lua provided by RyzenAPI
-- Game: Brave Escape

-- MAIN APPLICATION
addappid(1354260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354261,0,"b13a2aeb1c02a76f445f9bfeafc29c5ab11de4ed0580abe3ffe4339ffb8c6a2d")

