-- Lua provided by RyzenAPI
-- Game: addappid(761010)

-- MAIN APPLICATION
addappid(761010)

-- MAIN APP DEPOTS / PACKAGES
addappid(761011, 1, "3ccacda6feeb34b7da50798cca8b49a3992c4fd774886dcd529716a46b901118")
addappid(761012, 1, "0d8cede1f652429d8f2bd7238d7dc5eba1e755259ee0cfd22a094ce626f7c5f8")
