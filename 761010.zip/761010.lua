-- Lua provided by RyzenAPI
-- Game: Wave Break

-- MAIN APPLICATION
addappid(761010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(761011, 1, "3ccacda6feeb34b7da50798cca8b49a3992c4fd774886dcd529716a46b901118")
addappid(761012, 1, "0d8cede1f652429d8f2bd7238d7dc5eba1e755259ee0cfd22a094ce626f7c5f8")

