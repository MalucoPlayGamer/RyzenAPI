-- Lua provided by RyzenAPI
-- Game: Zhang He - Officer Ticket / 張郃使用券

-- MAIN APPLICATION
addappid(956730)

-- MAIN APP DEPOTS / PACKAGES
addappid(956730,0,"be22fa953036466ceb8acb51fbf7ce23a6bf51aa5e88350457af91903b140c35")

