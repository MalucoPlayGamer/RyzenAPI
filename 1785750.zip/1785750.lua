-- Lua provided by RyzenAPI
-- Game: 全托教师

-- MAIN APPLICATION
addappid(1785750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785751, 1, "17ff6475d0e17a6011b6aecaf7450e299bfe2d72d320602487d4bdf26be514cc")

