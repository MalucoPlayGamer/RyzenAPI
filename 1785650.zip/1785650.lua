-- Lua provided by RyzenAPI
-- Game: TopSpin 2K25

-- MAIN APPLICATION
addappid(1785650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785651, 1, "378291ca5d9f448851858d96883fd163188369d47a68b51012798acd9dc5e5b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2820460)
addappid(2820470)
addappid(2820480)
addappid(2820490)
addappid(2820500)
addappid(2820510)
addappid(2820520)
addappid(2820530)
addappid(2820540)
addappid(2820550)
addappid(2820560)
addappid(2820570)
