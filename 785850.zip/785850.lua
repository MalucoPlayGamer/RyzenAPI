-- Lua provided by RyzenAPI
-- Game: Valthirian Arc: Hero School Story

-- MAIN APPLICATION
addappid(785850)

-- MAIN APP DEPOTS / PACKAGES
addappid(785851, 1, "b9968a69df3085090a2c85b2884ea4ae05ca9eaacaa533b488ccaaf19b4942cf")

