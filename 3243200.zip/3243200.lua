-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Wandering Souls Asylum Tileset

-- MAIN APPLICATION
addappid(3243200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243200,0,"4a6aa0eec218b4ea54083663e38f282af7f8d2ce4859b59afcd9c6aa3633beb4")
