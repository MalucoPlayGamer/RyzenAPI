-- Lua provided by RyzenAPI
-- Game: Tidal Tribe

-- MAIN APPLICATION
addappid(1043430)
addappid(1155400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043431, 1, "e3add2cc7d959ff32934317f31b16784934ce68736bfbae34c9fe12342b840d3")
addappid(1043432, 1, "dc78b6366e82d4d2adc70231f084f5d6b9f0c86a334650d76f8512a108cf9215")

