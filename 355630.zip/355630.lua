-- Lua provided by RyzenAPI
-- Game: addappid(355630)

-- MAIN APPLICATION
addappid(355630)

-- MAIN APP DEPOTS / PACKAGES
addappid(355631, 1, "ff503e7a9e8786d45cd8e0156598f4ab8c9d6d63b3a46fb572b24d256aed711c")
