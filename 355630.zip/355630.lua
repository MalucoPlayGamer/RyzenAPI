-- Lua provided by RyzenAPI
-- Game: AppID 355630

-- MAIN APPLICATION
addappid(355630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(355631, 1, "ff503e7a9e8786d45cd8e0156598f4ab8c9d6d63b3a46fb572b24d256aed711c")

