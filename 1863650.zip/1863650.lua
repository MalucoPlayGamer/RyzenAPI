-- Lua provided by RyzenAPI
-- Game: 1863650

-- MAIN APPLICATION
addappid(1863650)
-- Game: addappid(1863650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863651, 1, "015f9ffd05a28fc665ec437b5a17de5cfe1369955cc4aa89dbe6b356e19c155b")
