-- Lua provided by RyzenAPI
-- Game: Yokai's Secret - HD Wallpaper Collection

-- MAIN APPLICATION
addappid(1347520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347520,0,"f9664ec1895f1f65ddae50d52c2b5bfbce9752aa0e342a9ac2cb4de749f88dfe")

