-- Lua provided by RyzenAPI
-- Game: addappid(3241780)

-- MAIN APPLICATION
addappid(3241780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241781, 1, "559a97990c8d3dc2e7300e8cac746802d54da11157af0c17a4645c672cfa63a9")
