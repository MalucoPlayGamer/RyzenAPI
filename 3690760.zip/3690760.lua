-- Lua provided by RyzenAPI
-- Game: 3690760

-- MAIN APPLICATION
addappid(3690760)
-- Game: addappid(3690760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690761, 1, "cf9cabc7524816c638c120e04c987cbd888e55af28483502a1bbccbb73b0e8f8")
