-- Lua provided by RyzenAPI
-- Game: addappid(1451970)

-- MAIN APPLICATION
addappid(1451970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451971, 1, "04fdad591cd6653de15db4b403057b2a9c3b71a39e213bc4c17de1f881858390")
