-- Lua provided by RyzenAPI
-- Game: Furry Sniper

-- MAIN APPLICATION
addappid(2326220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326222,0,"76a73950b94a1601868b0ce9c4acd952ba488f80bf5cb765d817844c612762db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
