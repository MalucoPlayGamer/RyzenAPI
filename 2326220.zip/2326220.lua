-- Lua provided by RyzenAPI
-- Game: Furry Sniper

-- MAIN APPLICATION
addappid(2326220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326222,0,"76a73950b94a1601868b0ce9c4acd952ba488f80bf5cb765d817844c612762db")

