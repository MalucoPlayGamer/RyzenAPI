-- Lua provided by RyzenAPI
-- Game: Game: Hei

-- MAIN APPLICATION
addappid(1026940)
-- Game: addappid(1026940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026941, 1, "8167823162964e9dc889c00222b0c1d9f31e97793dddb665dafdd7b3453dc303")
