-- Lua provided by RyzenAPI
-- Game: Tomb Robber

-- MAIN APPLICATION
addappid(674550)

-- MAIN APP DEPOTS / PACKAGES
addappid(674551,0,"cdae6a73584a340698498377839e13e2bc88de58bdcdde13c705b76567900edf")

