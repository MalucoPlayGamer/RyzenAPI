-- Lua provided by RyzenAPI
-- Game: Business Simulator 2016 Demo

-- MAIN APPLICATION
addappid(3251730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251731, 1, "e2bc5e1bae84c62aa27d85048175b8e9770330f1e725b69e7127ab444e930dc0")

