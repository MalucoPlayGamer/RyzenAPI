-- Lua provided by RyzenAPI
-- Game: Underwater

-- MAIN APPLICATION
addappid(1629450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629451, 1, "1e4f51ad63703eef7be8991bc85b28189e445530428e5c0c532f0352a8a10e89")

