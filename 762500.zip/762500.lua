-- Lua provided by RyzenAPI
-- Game: 762500

-- MAIN APPLICATION
addappid(762500)
-- Game: addappid(762500)

-- MAIN APP DEPOTS / PACKAGES
addappid(762501, 1, "7608bc2058e1bb45d57f5526d55dacb6c64d32eacc86643c4d973683ca3f3d34")
