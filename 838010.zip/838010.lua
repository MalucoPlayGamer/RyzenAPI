-- Lua provided by SkyAPI 
-- Game: AppID 838010
addappid(838010)
addappid(838011, 1, "a0d55b2c49113004b61fa51f756bea93f40d5e8c611717bed9c0f9fa1255a1f7")
