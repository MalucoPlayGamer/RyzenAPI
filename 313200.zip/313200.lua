-- Lua provided by RyzenAPI
-- Game: AppID 313200

-- MAIN APPLICATION
addappid(313200)
-- Game: addappid(313200)

-- MAIN APP DEPOTS / PACKAGES
addappid(313201, 1, "8db231c165c828e23430e7bc8bfd35ee25176e3a18973295e5eb75b64840105c")
