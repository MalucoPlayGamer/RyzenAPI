-- Lua provided by SkyAPI 
-- Game: AppID 463800
addappid(463800)
addappid(463801, 1, "b5305b2bb5c5211b0b9f389f85c78c4901c4a277f56fe100a04d53b34b47faeb")
addappid(463802, 1, "ce97c240f0c154437d31c71f732349df79053cb78b13186ce856c725489a48cc")
