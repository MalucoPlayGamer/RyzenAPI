-- Lua provided by RyzenAPI
-- Game: addappid(895060)

-- MAIN APPLICATION
addappid(895060)

-- MAIN APP DEPOTS / PACKAGES
addappid(895061, 1, "f9be1edd2bf43dc332c84a5fb92a3a1ace261b739f0f63a173542600434c8ed2")
