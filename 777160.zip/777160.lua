-- Lua provided by SkyAPI 
-- Game: Forgotten Places: Regained Castle
addappid(777160)
addappid(777161, 1, "8db95943d8cb2f6844567c9d6a50b52760cffd280e70958e8d9f9545e33853b1")
addappid(777162, 1, "f4b6ebb9aa8ba760bfe22c4dc503b4ebcc631b1e96affb911577c97f27fd3ee5")
