-- Lua provided by RyzenAPI
-- Game: Shot Shot Tactic

-- MAIN APPLICATION
addappid(562270)

-- MAIN APP DEPOTS / PACKAGES
addappid(562271, 1, "2d4f2b1db19e07ee5ec32320faf2bbb3c0421a29329301c31390f197fe9cf755")

