-- Lua provided by RyzenAPI
-- Game: Shot Shot Tactic

-- MAIN APPLICATION
addappid(562270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(562271, 1, "2d4f2b1db19e07ee5ec32320faf2bbb3c0421a29329301c31390f197fe9cf755")

