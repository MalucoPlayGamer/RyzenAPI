-- Lua provided by RyzenAPI
-- Game: addappid(1102880)

-- MAIN APPLICATION
addappid(1102880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102881, 1, "fcae8e58ee44ff63a73730aa8bde7caea9af34f7563fb51ab529b1fc34d6c133")
