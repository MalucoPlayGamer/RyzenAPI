-- Lua provided by RyzenAPI
-- Game: Wet Warfare

-- MAIN APPLICATION
addappid(914350)

-- MAIN APP DEPOTS / PACKAGES
addappid(914351, 1, "74f790bed66e7588b2735400dcb4ee005c69e805eb0600fe24589a2f8b6d2152")

