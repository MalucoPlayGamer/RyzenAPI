-- Lua provided by RyzenAPI
-- Game: Wet Warfare

-- MAIN APPLICATION
addappid(914350)

-- MAIN APP DEPOTS / PACKAGES
addappid(914351, 1, "74f790bed66e7588b2735400dcb4ee005c69e805eb0600fe24589a2f8b6d2152")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
