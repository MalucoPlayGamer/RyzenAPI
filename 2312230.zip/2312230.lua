-- Lua provided by RyzenAPI
-- Game: AppID 2312230

-- MAIN APPLICATION
addappid(2312230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312231, 1, "2a4f42f75ea05d2422cbfd83e02d04b8a8a2006cabbedfbabd080520b5a086d3")

