-- Lua provided by RyzenAPI
-- Game: 1985610

-- MAIN APPLICATION
addappid(1985610)
-- Game: addappid(1985610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985611, 1, "08557428c753643a197840928f98f471dfbada93adc1bb14ed5b54de4a9583a2")
