-- Lua provided by RyzenAPI
-- Game: Frenzy Retribution

-- MAIN APPLICATION
addappid(1108560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108561, 1, "9cdd98e2659d19cc99f51fdba11e78f92a5e7f3e82e77b2e437f801f3709e3ed")

