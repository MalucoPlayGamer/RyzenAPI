-- Lua provided by RyzenAPI
-- Game: 3317430

-- MAIN APPLICATION
addappid(3317430)
-- Game: addappid(3317430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317431, 1, "ec4ced1118281778a25da876e4ca27c70115d4c33a349a2cf1fc9503a87516bc")
