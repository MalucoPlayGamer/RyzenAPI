-- Lua provided by RyzenAPI
-- Game: Game: Build Wars

-- MAIN APPLICATION
addappid(816240)
-- Game: addappid(816240)

-- MAIN APP DEPOTS / PACKAGES
addappid(816241, 1, "d31aecdc2c2f24c724fc0ffe7532de806d8bd806a7d48a132fb8b8b002eaefcd")
