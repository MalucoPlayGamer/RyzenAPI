-- Lua provided by RyzenAPI
-- Game: PlataGO!

-- MAIN APPLICATION
addappid(732400)

-- MAIN APP DEPOTS / PACKAGES
addappid(732401, 1, "e907074e48204b0b0ab8aebaf379c1c292057234b54b414702943a4ebed4dc4c")
