-- Lua provided by RyzenAPI
-- Game: Operation Thunderstorm

-- MAIN APPLICATION
addappid(837590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(837591, 1, "19d385fe51f495bf552936004d46056e140f1db670f80250704a50983ec74ecb")
addappid(837592, 1, "652a7569e1729209e3b94f54416711c1adcf8a7b3ecc2fa7a8dc0c8176294605")

