-- Lua provided by RyzenAPI
-- Game: 2806450

-- MAIN APPLICATION
addappid(2806450)
-- Game: addappid(2806450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806451, 1, "5514b02dfa18f1585fedc1807d4e888b754525c3ef1a2d79d5d4af8e096ca5ba")
