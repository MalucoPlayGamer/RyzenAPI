-- Lua provided by SkyAPI 
-- Game: Time Treker Demo
addappid(2806450)
addappid(2806451, 1, "5514b02dfa18f1585fedc1807d4e888b754525c3ef1a2d79d5d4af8e096ca5ba")
