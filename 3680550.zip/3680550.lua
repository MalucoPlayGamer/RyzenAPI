-- Lua provided by RyzenAPI
-- Game: Pixel Nitro Rush

-- MAIN APPLICATION
addappid(3680550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680551, 1, "c1723b3d6bbc6e66fb072de2ae66718b94528247cf265734e32483210939811d")
