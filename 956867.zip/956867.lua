-- Lua provided by RyzenAPI
-- Game: Ding Feng - Officer Ticket / 丁奉使用券

-- MAIN APPLICATION
addappid(956867)
-- Game: addappid(956867)

-- MAIN APP DEPOTS / PACKAGES
addappid(956867,0,"edb70a1e6d47a238cf1773d8d102fd11f2bf9539789619061472bd71bd0edf51")
