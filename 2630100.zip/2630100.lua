-- Lua provided by RyzenAPI
-- Game: Definya 2D MMORPG

-- MAIN APPLICATION
addappid(2630100)
-- Game: addappid(2630100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630101, 1, "fd4a73f67e2e6c84cf268eb0322f303c7762db923617051dd5f32185168e0856")
