-- Lua provided by RyzenAPI
-- Game: Game: Carnal Coup - Overseer's Edition

-- MAIN APPLICATION
addappid(1699170)
-- Game: addappid(1699170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699171, 1, "fa9c2c5f66d339282479484172334d63b99927b059f18d229df8f4f824f34257")
addappid(1699172, 1, "d36f52ec6e418b215f3ccce8c6bccdc2d204d66b5a16f3abc34909eee29e0898")
addappid(1699173, 1, "be3c73af930ce002d79f62cbb1502ecdbea6b902a24e3a306e7f7d61909ca0d6")
