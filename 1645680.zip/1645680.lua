-- Lua provided by SkyAPI 
-- Game: Zombies Desert and Guns
addappid(1645680)
addappid(1645681, 1, "69a07f408d05303e3070f5583ab757247e421d9838206d07d8bebcab6743a75d")
