-- Lua provided by RyzenAPI
-- Game: Let's Learn Lingít

-- MAIN APPLICATION
addappid(2461000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461001, 1, "92d7594a05968d979fd95fa70e74ff8f4e063a150ca956452349f21e431b8822")
addappid(2461002, 1, "b4d61b431e81d8292659b599537acc57f7f9c9885d3339aadde58784eaba0aec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
