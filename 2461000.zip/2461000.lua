-- Lua provided by RyzenAPI 
-- Game: Let's Learn Lingít
addappid(2461000)
addappid(2461001, 1, "92d7594a05968d979fd95fa70e74ff8f4e063a150ca956452349f21e431b8822")
addappid(2461002, 1, "b4d61b431e81d8292659b599537acc57f7f9c9885d3339aadde58784eaba0aec")
