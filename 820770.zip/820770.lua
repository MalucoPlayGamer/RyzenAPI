-- Lua provided by RyzenAPI
-- Game: Game: AppID 820770

-- MAIN APPLICATION
addappid(820770)
addappid(1169840)
addappid(1169850)
addappid(1169860)
-- Game: addappid(820770)

-- MAIN APP DEPOTS / PACKAGES
addappid(820771, 1, "3484c3829e4d19a39b697e23794e94a1dc914fef88173a5714877415f9913fa5")
