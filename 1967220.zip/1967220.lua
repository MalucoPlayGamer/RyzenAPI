-- Lua provided by RyzenAPI
-- Game: No Return

-- MAIN APPLICATION
addappid(1967220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967221, 1, "c186d27d3af23cca8b3ef364c0392f9f9d5d161c465bb4f0e499cebd8c77b71f")
addappid(1967222, 1, "ccb9e4ab039d2e242a089a3cfeff880e49a390aa82bda5a3ef874bc8c7e38d8c")
addappid(1967223, 1, "69ae711ad4ecc0dc3778157baf6a50154389487f5c9af17efb4535e56111e423")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
