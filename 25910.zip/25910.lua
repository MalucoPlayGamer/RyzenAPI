-- Lua provided by RyzenAPI
-- Game: Supreme Ruler 2020 Gold

-- MAIN APPLICATION
addappid(25910)
-- Game: addappid(25910)

-- MAIN APP DEPOTS / PACKAGES
addappid(25911, 1, "e4aee142a6d34a6e684133d22d0f9496a5643ab0d84934270ab10767195e5ead")
