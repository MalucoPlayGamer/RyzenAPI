-- Lua provided by RyzenAPI
-- Game: Don't Escape Trilogy

-- MAIN APPLICATION
addappid(1070550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070551, 1, "78e04139e2795b82acf5c1fc1f8570088e57a2053fa66df5f6b179e307e4b646")

