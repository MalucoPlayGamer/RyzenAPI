-- Lua provided by RyzenAPI
-- Game: Halcyon Days at Taoyuan

-- MAIN APPLICATION
addappid(2678830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678831,0,"b8914f851e3c92fffc62f0b8e8b4e4f60dd23e298942554f1d64af42dbefcec7")
addappid(4327360,0,"08560971852a825ee16b3691d58db0915131c0cf007feccfbf63c7a9c3217be0")
addappid(4391750,0,"d5e5f3bec06e63e28defa0269c1b57337b7618c353b061383444ad48d2da106b")
addappid(4745390,0,"b8dd07035774054b62ed02ddb34a4e0f5313d7f3c9bd1a823b8b2ce7c51bcb4d")

