-- Lua provided by RyzenAPI
-- Game: Knights of the Road Demo

-- MAIN APPLICATION
addappid(2340060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340061, 1, "2ad5eb744129c91ec60d4561cc61d0e07954ccf862a95452390aa35119253024")
