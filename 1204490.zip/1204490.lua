-- Lua provided by RyzenAPI
-- Game: 武儒绘卷 - 启示录

-- MAIN APPLICATION
addappid(1204490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204491, 1, "e7e30d4a8a7661c920f3fedbeda6f4b7df2f64c9c07eb34db1e8da0769a33915")

