-- Lua provided by RyzenAPI
-- Game: Game: AppID 269450

-- MAIN APPLICATION
addappid(269450)
-- Game: addappid(269450)

-- MAIN APP DEPOTS / PACKAGES
addappid(269451, 1, "67c90a5db10777b6811f20d085a85efe62d65739369cb98a121e4178645963c1")
