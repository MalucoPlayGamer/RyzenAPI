-- Lua provided by SkyAPI 
-- Game: Grandmother
addappid(1415370)
addappid(1415371, 1, "d9f436f7ba2c9905a8fd2958962058792c947c023c920a7ea55704d9a0a68694")
