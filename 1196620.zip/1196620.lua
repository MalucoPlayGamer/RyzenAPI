-- Lua provided by SkyAPI 
-- Game: 佣兵战歌
addappid(1196620)
addappid(1196621, 1, "662d42a58d97ff79b7f124e7be221279f37af025b631cf5d102d374d4b620624")
