-- Lua provided by RyzenAPI
-- Game: 佣兵战歌

-- MAIN APPLICATION
addappid(1196620)
-- Game: addappid(1196620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196621, 1, "662d42a58d97ff79b7f124e7be221279f37af025b631cf5d102d374d4b620624")
