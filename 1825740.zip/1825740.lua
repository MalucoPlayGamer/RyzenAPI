-- Lua provided by RyzenAPI
-- Game: Game: Fat Baby

-- MAIN APPLICATION
addappid(1825740)
-- Game: addappid(1825740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825741, 1, "2c28356c35653f378a4ff3daf9268f13eab09e561bd6bd53afc74097a0d16355")
