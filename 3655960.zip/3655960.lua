-- Lua provided by SkyAPI 
-- Game: Tales Beyond The Tomb - White Silence
addappid(3655960)
addappid(3655961, 1, "e1c8db79257443a9645e373c8517fe3e2036d662916defe3c745da9fcf88c584")
