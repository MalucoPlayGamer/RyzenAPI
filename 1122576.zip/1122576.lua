-- Lua provided by RyzenAPI
-- Game: addappid(1122576)

-- MAIN APPLICATION
addappid(1122576)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122576,0,"0d958da72feebe5350e566b3d1f3a6dfec8035f688e14c95dcdb9e26b43d0d6d")
