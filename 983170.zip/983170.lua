-- Lua provided by RyzenAPI
-- Game: addappid(983170)

-- MAIN APPLICATION
addappid(983170)

-- MAIN APP DEPOTS / PACKAGES
addappid(983171, 1, "342b781c89b494d63af79000cff4f125b8de34e5cec0a1d7e1504b3ca7f202c8")
