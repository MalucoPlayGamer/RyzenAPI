-- Lua provided by SkyAPI 
-- Game: Project Rhombus (Free)
addappid(1226280)
addappid(1226281, 1, "c4d9748b577a3a33140708c6835e8d62f34196cb441e0a4fe348a94a2c85e443")
