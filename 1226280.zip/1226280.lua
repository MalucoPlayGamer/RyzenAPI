-- Lua provided by RyzenAPI
-- Game: Game: Project Rhombus (Free)

-- MAIN APPLICATION
addappid(1226280)
-- Game: addappid(1226280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226281, 1, "c4d9748b577a3a33140708c6835e8d62f34196cb441e0a4fe348a94a2c85e443")
