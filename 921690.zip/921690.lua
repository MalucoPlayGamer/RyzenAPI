-- Lua provided by RyzenAPI
-- Game: Game: O2Jam x DancingParty

-- MAIN APPLICATION
addappid(921690)
-- Game: addappid(921690)

-- MAIN APP DEPOTS / PACKAGES
addappid(921691, 1, "cbc0692031c77bece505212a0a2f8a31b2b9287ca2df435ab9249af3cb32052d")
