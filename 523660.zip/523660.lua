-- Lua provided by RyzenAPI
-- Game: AppID 523660

-- MAIN APPLICATION
addappid(523660)
-- Game: addappid(523660)

-- MAIN APP DEPOTS / PACKAGES
addappid(523661, 1, "c8a3b54e1f35fb7e32a597392ebe1ae6d117c3a3b1f5d014c0564a1c05a1deb1")
addappid(523662, 1, "3d9d5f24d2b3ea5de2ea8521213e28242a000c2f682a97e3c27d87181e19a51f")
