-- Lua provided by RyzenAPI
-- Game: HYPERCHARGE: Unboxed

-- MAIN APPLICATION
addappid(523660)
addappid(1305040)
addappid(1612210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(523661, 1, "c8a3b54e1f35fb7e32a597392ebe1ae6d117c3a3b1f5d014c0564a1c05a1deb1")
addappid(523662, 1, "3d9d5f24d2b3ea5de2ea8521213e28242a000c2f682a97e3c27d87181e19a51f")
