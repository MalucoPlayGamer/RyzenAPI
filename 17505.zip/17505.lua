-- Lua provided by RyzenAPI
-- Game: Zombie Panic! Source Dedicated Server

-- MAIN APPLICATION
addappid(17505)

-- MAIN APP DEPOTS / PACKAGES
addappid(686471,0,"e526add27277d21b12060d0f40675d83c0dae67753f26b96162f04ab8e8a80a9")
addappid(686473,0,"184e2c28fe8147b49a6f2726854228af6a2cfcdd63829ee713794306e6b31d92")

