-- Lua provided by RyzenAPI
-- Game: Nullum

-- MAIN APPLICATION
addappid(1293990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1293991, 1, "98c4c4f1e1960c5d9f93e1bfae6dd16fc418af626451298c630dad546a71ee67")

