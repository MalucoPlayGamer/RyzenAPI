-- Lua provided by RyzenAPI
-- Game: Game: AppID 1293990

-- MAIN APPLICATION
addappid(1293990)
-- Game: addappid(1293990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293991, 1, "98c4c4f1e1960c5d9f93e1bfae6dd16fc418af626451298c630dad546a71ee67")
