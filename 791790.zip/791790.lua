-- Lua provided by SkyAPI 
-- Game: AppID 791790
addappid(791790)
addappid(791791, 1, "959e4850a83227a069f472c7f2e2d60460e955685028f4d5a66ff8000b51c4b1")
