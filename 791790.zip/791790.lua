-- Lua provided by RyzenAPI
-- Game: Game: AppID 791790

-- MAIN APPLICATION
addappid(791790)
-- Game: addappid(791790)

-- MAIN APP DEPOTS / PACKAGES
addappid(791791, 1, "959e4850a83227a069f472c7f2e2d60460e955685028f4d5a66ff8000b51c4b1")
