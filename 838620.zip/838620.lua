-- Lua provided by RyzenAPI
-- Game: Slappy Ass

-- MAIN APPLICATION
addappid(838620)

-- MAIN APP DEPOTS / PACKAGES
addappid(838621, 1, "c9f4c7658b0d146122f08655916f0de2fe891af7a9214555559d9cba6e8f1fee")
