-- Lua provided by RyzenAPI 
-- Game: Cardiac Powder
addappid(2203570)
addappid(2203571, 1, "cd8a617a83e9c4109b8d04ad92a25f9afa0862d98c0a6640fe980a64a89b519c")
