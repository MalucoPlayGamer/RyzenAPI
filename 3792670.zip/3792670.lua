-- Lua provided by RyzenAPI
-- Game: Space Memory: Horses

-- MAIN APPLICATION
addappid(3792670)
-- Game: addappid(3792670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792671, 1, "332c73e3d2850ad242c186eef1e1533d398911e0ffe0c43b21b700f76001fecb")
