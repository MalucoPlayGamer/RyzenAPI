-- Lua provided by SkyAPI 
-- Game: Space Memory: Horses
addappid(3792670)
addappid(3792671, 1, "332c73e3d2850ad242c186eef1e1533d398911e0ffe0c43b21b700f76001fecb")
