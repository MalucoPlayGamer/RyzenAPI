-- Lua provided by RyzenAPI 
-- Game: DEATH TRAIN - Warning: Unsafe VR Experience
addappid(680780)
addappid(680781, 1, "91a95053b243a8e0b03d73edbbda9477be86a4ab9420c1b4e89225528f88145f")
