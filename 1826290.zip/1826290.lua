-- Lua provided by RyzenAPI
-- Game: Game: AppID 1826290

-- MAIN APPLICATION
addappid(1826290)
-- Game: addappid(1826290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826291, 1, "c9b635043b3b1f5963c998347afe5743e7b6e4661fcfdf6c83b3e980623661c5")
