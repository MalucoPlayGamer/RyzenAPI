-- Lua provided by RyzenAPI
-- Game: Dagger Directive

-- MAIN APPLICATION
addappid(2437670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437671, 1, "cd6cd445a32060bcfb152595b79aec7d484f20fa442397c9b02cb49cbc4961a8")

