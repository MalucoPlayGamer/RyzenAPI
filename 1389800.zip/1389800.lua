-- Lua provided by RyzenAPI
-- Game: Sweet and Hot - Artbook 18+

-- MAIN APPLICATION
addappid(1389800)
-- Game: addappid(1389800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389800,0,"92345e4e2a935455869b344e2ea084236db635128a8441a1f9157d85b6b4548e")
