-- Lua provided by RyzenAPI
-- Game: My Pet Sitter is a Futanari

-- MAIN APPLICATION
addappid(1854810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854811, 1, "62a01d5da26242ff49caae98de511292682813e53b4474fddcc022d0518025bb")

