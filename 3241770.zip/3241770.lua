-- Lua provided by RyzenAPI
-- Game: Novice Dungeon Master Demo

-- MAIN APPLICATION
addappid(3241770)
-- Game: addappid(3241770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241771, 1, "4d3bbc3a9d5c5936063f5a048352991a833cce77bd1d264de559add28f78b394")
