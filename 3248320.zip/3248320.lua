-- Lua provided by RyzenAPI
-- Game: Game: CDB6: A Maldição dos Zumbis

-- MAIN APPLICATION
addappid(3248320)
-- Game: addappid(3248320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248321, 1, "99e42ced7a38eacfd7954574ee4ec6cb55ed302dae6af633c0178899c3fc141f")
