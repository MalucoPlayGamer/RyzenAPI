-- Lua provided by RyzenAPI
-- Game: Death Skid Marks

-- MAIN APPLICATION
addappid(326150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(326151, 1, "a1f841a0d8c18d133220c1e8337e47376e515118375de7612fc40e52ff62ded3")
addappid(326300, 0, "d7888edb89add8fb06845eeef30a754a994ee6d81663fd6d9f8e0dc68ce9f035")

