-- Lua provided by SkyAPI 
-- Game: Overcome
addappid(1020090)
addappid(1020091, 1, "83669591210548f7ca23a6496b4615559234cb565f8bb0a7e96d329e9bb8b489")
