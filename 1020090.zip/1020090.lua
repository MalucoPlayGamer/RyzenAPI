-- Lua provided by RyzenAPI
-- Game: Overcome

-- MAIN APPLICATION
addappid(1020090)
-- Game: addappid(1020090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020091, 1, "83669591210548f7ca23a6496b4615559234cb565f8bb0a7e96d329e9bb8b489")
