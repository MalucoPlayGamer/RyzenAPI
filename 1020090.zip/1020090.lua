-- Lua provided by RyzenAPI
-- Game: Overcome

-- MAIN APPLICATION
addappid(1020090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020091, 1, "83669591210548f7ca23a6496b4615559234cb565f8bb0a7e96d329e9bb8b489")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
