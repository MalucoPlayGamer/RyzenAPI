-- Lua provided by RyzenAPI
-- Game: AppID 1352740

-- MAIN APPLICATION
addappid(1352740)
-- Game: addappid(1352740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352741, 1, "bb794fc7c4235b9e54bd429dc8dcc30bbbe9cca5036251af0e1002d0682191fb")
