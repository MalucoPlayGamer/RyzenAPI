-- Lua provided by RyzenAPI
-- Game: Pyramid Game YSBC Advance

-- MAIN APPLICATION
addappid(2969080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969081, 1, "15100b5adcc70a918a5def4a2631f29132748254fbd7d5f892989ca04285ac67")

