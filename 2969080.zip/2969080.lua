-- Lua provided by SkyAPI 
-- Game: Pyramid Game YSBC Advance
addappid(2969080)
addappid(2969081, 1, "15100b5adcc70a918a5def4a2631f29132748254fbd7d5f892989ca04285ac67")
