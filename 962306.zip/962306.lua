-- Lua provided by RyzenAPI
-- Game: Xin Xianying - Officer Ticket / 辛憲英使用券

-- MAIN APPLICATION
addappid(962306)

-- MAIN APP DEPOTS / PACKAGES
addappid(962306,0,"f77350d88eb3c277cba9dfc442693f305f68fd81602fe7edba38a5705be89243")
