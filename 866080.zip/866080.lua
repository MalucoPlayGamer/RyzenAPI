-- Lua provided by RyzenAPI
-- Game: AppID 866080

-- MAIN APPLICATION
addappid(866080)

-- MAIN APP DEPOTS / PACKAGES
addappid(866081, 1, "59c782fb24b7048e48aefb7a79e192c85757d2d4e350ccfb12019cf659473cae")

