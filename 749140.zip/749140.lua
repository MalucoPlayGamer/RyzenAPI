-- Lua provided by RyzenAPI
-- Game: addappid(749140)

-- MAIN APPLICATION
addappid(749140)

-- MAIN APP DEPOTS / PACKAGES
addappid(749141, 1, "7aa5abfa6f0faa29799cefde43ea7b470bacb0969c2a0440fcad464a3ebfec50")
