-- Lua provided by RyzenAPI
-- Game: 823920

-- MAIN APPLICATION
addappid(823920)
-- Game: addappid(823920)

-- MAIN APP DEPOTS / PACKAGES
addappid(823921, 1, "bc5bd8e2f02ba74a10e3970fddf05fa1c2c79f59c9ae4a536edf2cc2f2dc4f79")
