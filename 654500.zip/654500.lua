-- Lua provided by RyzenAPI
-- Game: Game: AppID 654500

-- MAIN APPLICATION
addappid(654500)
-- Game: addappid(654500)

-- MAIN APP DEPOTS / PACKAGES
addappid(654501, 1, "b891e6333d28cd7c3d5693217d0f97a45ff5c7dd93f6662ea6a37d17160abee0")
