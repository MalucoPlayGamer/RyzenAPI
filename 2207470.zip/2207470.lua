-- Lua provided by RyzenAPI
-- Game: addappid(2207470)

-- MAIN APPLICATION
addappid(2207470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207471, 1, "f0bda50535d56cc5301a46cd0ace3e066087e98ee877bc8685416c48992dc63b")
