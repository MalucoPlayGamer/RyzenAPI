-- 3122460's Lua and Manifest Created by Hubcap Manifest
-- Desktop Raid
-- Created: June 15, 2026 at 05:59:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(3122460, 1, "e85f053bec558ce787bc13ce61e746d32c881ad6cf7a73a5a50b79829296d882") -- Desktop Raid
-- MAIN APP DEPOTS
addappid(3122461, 1, "52933d19d80d16a07195093f8cf4540dfabf6a8a6c4df8f066bc8aae48d36880") -- Depot 3122461
setManifestid(3122461, "4285349898349591632", 967573998)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4463340) -- Desktop Raid - Supporter Pack
addappid(4539650) -- Desktop Raid - Mythic Heroes Pack