-- 3162850's Lua and Manifest Created by Hubcap Manifest
-- Lightning Katana
-- Created: August 03, 2026 at 02:49:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3162850, 1, "594b2292bc9cc63b66f5a5ab1b2810905056d9b26c394e4b0dd265773a59eb04") -- Lightning Katana
-- MAIN APP DEPOTS
addappid(3162851, 1, "e7e680c21bb6c2c35bae4a4729b9e6e23562013d83978b65ab144078a2f8b669") -- Depot 3162851
setManifestid(3162851, "6558759005449686046", 361117684)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)