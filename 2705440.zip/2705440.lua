-- Lua provided by RyzenAPI
-- Game: Minimalist Tower Defense Demo

-- MAIN APPLICATION
addappid(2705440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705441, 1, "b255b48d01830df5c966bb357ba507c7189709bf0a9141b62df6840f1d8708e8")

