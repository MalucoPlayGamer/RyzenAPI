-- Lua provided by RyzenAPI
-- Game: 长路江湖 - 九州群芳

-- MAIN APPLICATION
addappid(2543650)
-- Game: addappid(2543650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543651, 1, "db053a1163b71c4bf6d8ec289946966590866db0b8035551338c82d1fd495c0e")
