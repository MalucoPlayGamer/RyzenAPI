-- Lua provided by RyzenAPI
-- Game: 1665140

-- MAIN APPLICATION
addappid(1665140)
-- Game: addappid(1665140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665141, 1, "d5fdb43b9a2a1c76dc30a2f7bd974cb195e94ee79e76d61614a6baa35048316e")
