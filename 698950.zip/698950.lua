-- Lua provided by RyzenAPI
-- Game: Chaos and the White Robot

-- MAIN APPLICATION
addappid(698950)

-- MAIN APP DEPOTS / PACKAGES
addappid(698951, 1, "f94edbeede6db37d337017b37f370f9a5233cb01172082a065be536049cc1c6a")
