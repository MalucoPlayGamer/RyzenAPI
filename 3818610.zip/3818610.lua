-- Lua provided by RyzenAPI
-- Game: Throne of Monsters The ArtBook 怪物的王座 艺术设定

-- MAIN APPLICATION
addappid(3818610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3818610,0,"673351a3e3b212a2482f42e98cd71667b228247354f9ef9a7698c38e197eef54")

