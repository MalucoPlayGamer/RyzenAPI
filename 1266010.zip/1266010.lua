-- Lua provided by RyzenAPI
-- Game: addappid(1266010)

-- MAIN APPLICATION
addappid(1266010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266011, 1, "bce96a602bacf10b224de999a4abed8b381d41f39a96e687054569d2a27c74d4")
addappid(1266012, 1, "a5f2da70ba89633f76cbd06ec9f3dfdb6028a5c0f21bd5e7884db5c028aa637e")
