-- Lua provided by RyzenAPI
-- Game: No.HazedHeart

-- MAIN APPLICATION
addappid(2653530)
-- Game: addappid(2653530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653531, 1, "5c68a3811fd3a89054f8d12192561936bed692b0fed6067081708c2c23043f49")
