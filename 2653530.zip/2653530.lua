-- Lua provided by SkyAPI 
-- Game: No.HazedHeart
addappid(2653530)
addappid(2653531, 1, "5c68a3811fd3a89054f8d12192561936bed692b0fed6067081708c2c23043f49")
