-- Lua provided by RyzenAPI
-- Game: addappid(2423750)

-- MAIN APPLICATION
addappid(2423750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423751, 1, "94506a95a9c52a1502b8712f526dc36eccf299bd88ad546ac65af4d491a50519")
