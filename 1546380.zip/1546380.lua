-- Lua provided by RyzenAPI
-- Game: AppID 1546380

-- MAIN APPLICATION
addappid(1546380)
-- Game: addappid(1546380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546381, 1, "2adc7e744d3e1cea148694caa9ad0ea4cc312179ad9514497d3e97f23ec1ad94")
addappid(1546384, 1, "3a42abdb3c6c55e41c80b5428e66887ee32ed140326e4176c5eb9a7319d1d565")
