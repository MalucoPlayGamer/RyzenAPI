-- Lua provided by RyzenAPI
-- Game: 934810

-- MAIN APPLICATION
addappid(934810)
-- Game: addappid(934810)

-- MAIN APP DEPOTS / PACKAGES
addappid(934811, 1, "df48f9417f768d767ad3423973cdf2fee2d5a2fd333d3f28042aa92fee261ed6")
