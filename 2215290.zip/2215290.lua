-- Lua provided by RyzenAPI 
-- Game: 我在终点线等你
addappid(2215290)
addappid(2215291, 1, "7313c7aec79aca287ab103b807e4e86eafc4f55f861df92e9341bb6d924e177f")
addappid(2764330, 0, "9ced9ad8a974d85d2244388863e90e1474ca9f54505f23207e6031f79534e5c4")
