-- Lua provided by RyzenAPI 
-- Game: Doug Flutie's Maximum Football 2020
addappid(1470790)
addappid(1470791, 1, "aa3a1fbff438d562988c42cea6e43becf0aa471b056906b512fad906e1d4c91e")
