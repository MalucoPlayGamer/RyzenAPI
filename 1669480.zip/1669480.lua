-- Lua provided by RyzenAPI
-- Game: Firefighting Simulator: Ignite

-- MAIN APPLICATION
addappid(3544160)
addappid(3544170)
addappid(3544180)
addappid(3697660)
addappid(3707380) -- Firefighting Simulator Ignite - Year 1 Season Pass
addappid(3743300)
addappid(3743320)
addappid(3743330)
addappid(3743340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1669480, 1, "96862f5b0a16a7e9950ad145fb8080dd0c6b0b65d55ce998ef4b42fe61ac2822") -- Firefighting Simulator: Ignite
addappid(1669481, 1, "86379ba94d829db600d16fb1a8228f1311045edc0905cd7f55c8e674028ce2e8") -- Depot 1669481
addappid(3544160, 1, "907cfcb846ccb3902d350463e48db5bb1b98ec8850923efc377194340541da16") -- Firefighting Simulator Ignite - Rosenbauer HEROS Titan DLC  - Depot 3544160
addappid(3544170, 1, "9996513aa6cad3d5710da64183e284b73b62ded8ef8e8ff593cfa67634592351") -- Firefighting Simulator Ignite - Summer Camp DLC - Depot 3544170
addappid(3544180, 1, "210235486e18fe8d63473108a57641fcdbd4a2c673695d22e25b148138cdd881") -- Firefighting Simulator Ignite - Parkers Story DLC - Depot 3544180
addappid(3697660, 1, "7a1b1c50379f373233659c2752efbd243877e437a08464c12dd718be2496e83b") -- Firefighting Simulator Ignite - Fire Station Companion Pack - Depot 3697660
addappid(3743300, 1, "9b7c18b13cfbe88f8bb94febc845a0d5bc486db5287a368dea3ee7a38b75a05a") -- Firefighting Simulator Ignite - Kenworth Fire Truck Pack - Depot 3743300
addappid(3743320, 1, "d19bec86ce212ba3c315f2baf7027efd91340fa6e62c89fd9f8bb1530c2cec68") -- Firefighting Simulator Ignite - Blackout Truck Edition Skins DLC - Depot 3743320
addappid(3743330, 1, "19ec17815de90aa3ba91854c3aaf515a2a895e2c0b17e6c34993cfc53efaf366") -- Firefighting Simulator Ignite - Turnout Gear Pack 1 - Depot 3743330
addappid(3743340, 1, "fb6aab3a1fccaf8e8cd101eced844b5cf7757e0e61c2c1f3ccaeebf3676b9c06") -- Firefighting Simulator Ignite - Motor Vehicle Accident Expansion - Depot 3743340

