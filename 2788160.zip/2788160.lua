-- Lua provided by RyzenAPI
-- Game: Sakura Bunny Girls 2

-- MAIN APPLICATION
addappid(2788160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788161, 1, "4e7893d079d8becb7871ad8307ab532579681b35de139e54f5ad16234ddd1d3c")
