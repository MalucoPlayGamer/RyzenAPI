-- Lua provided by RyzenAPI
-- Game: 鸡肉哥哥 Chicken Brother

-- MAIN APPLICATION
addappid(2460880)
-- Game: addappid(2460880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460881, 1, "634a19e3d449e2446e0a20388c68d61c4b6583b35eeec2f1042c0f817a15e796")
