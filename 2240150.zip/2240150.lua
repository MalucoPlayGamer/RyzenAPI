-- Lua provided by RyzenAPI
-- Game: addappid(2240150)

-- MAIN APPLICATION
addappid(2240150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240156,0,"38f3f5def72b7c4fb2d2576d0fc5defe68bb7a42b24709762df57f7dc1eca08c")
addappid(2961150,0,"a3fb2af3228a08142e19202d5f1a170e379d80f949f93d2028cfffcf0b795dbd")
addappid(2975570,0,"f153dcc1363143ca690b24d1c6b0e9518ad56f5e33a6b49fabc93a99108f4c4b")
