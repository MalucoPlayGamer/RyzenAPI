-- Lua provided by SkyAPI 
-- Game: Dreamslayer
addappid(2670250)
addappid(2670251, 1, "5286c41a44a5258d333f4bdfb1a6171fedb4a58e6df705fc7e8552df981aac8c")
