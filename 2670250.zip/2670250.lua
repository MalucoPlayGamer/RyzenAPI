-- Lua provided by RyzenAPI
-- Game: Dreamslayer

-- MAIN APPLICATION
addappid(2670250)
-- Game: addappid(2670250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670251, 1, "5286c41a44a5258d333f4bdfb1a6171fedb4a58e6df705fc7e8552df981aac8c")
