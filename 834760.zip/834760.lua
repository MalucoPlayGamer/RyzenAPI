-- Lua provided by RyzenAPI
-- Game: AppID 834760

-- MAIN APPLICATION
addappid(834760)

-- MAIN APP DEPOTS / PACKAGES
addappid(834761, 1, "2c2c1119ad1a1bac2cb1d9ad58e3e7ea2bdf33d8d48948d70860149c19cd717b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
