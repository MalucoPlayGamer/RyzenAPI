-- Lua provided by RyzenAPI
-- Game: addappid(834760)

-- MAIN APPLICATION
addappid(834760)

-- MAIN APP DEPOTS / PACKAGES
addappid(834761, 1, "2c2c1119ad1a1bac2cb1d9ad58e3e7ea2bdf33d8d48948d70860149c19cd717b")
