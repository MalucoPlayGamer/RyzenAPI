-- Lua provided by RyzenAPI
-- Game: 1218230

-- MAIN APPLICATION
addappid(1218230)
-- Game: addappid(1218230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218231, 1, "badd81d88c87deb6c2f97b1f0d9480b0a1deae2afde6c6ae3cab720dd142f98c")
