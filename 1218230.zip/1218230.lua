-- Lua provided by SkyAPI 
-- Game: Rhythmic Retro Racer
addappid(1218230)
addappid(1218231, 1, "badd81d88c87deb6c2f97b1f0d9480b0a1deae2afde6c6ae3cab720dd142f98c")
