-- Lua provided by SkyAPI 
-- Game: Camping Builder Demo
addappid(1873850)
addappid(1873851, 1, "fe53740f45618d5d42e66b3cb54ec2f033762e481c3a855fa554d322b7f1611f")
