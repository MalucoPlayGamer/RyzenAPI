-- Lua provided by RyzenAPI
-- Game: Heavy Spoilers RPG: The true identity of the final enemy is the hero's father

-- MAIN APPLICATION
addappid(3739190)

