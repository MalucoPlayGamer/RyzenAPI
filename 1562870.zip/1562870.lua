-- Lua provided by SkyAPI 
-- Game: AppID 1562870
addappid(1562870)
addappid(1562871, 1, "3d3b7bff413273711c522c9554383249d8d52fc5c2b313e7fe340840f81c9020")
