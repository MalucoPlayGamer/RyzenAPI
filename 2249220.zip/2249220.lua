-- Lua provided by RyzenAPI
-- Game: addappid(2249220)

-- MAIN APPLICATION
addappid(2249220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249221, 1, "2ed74e1e5fc71eab746dfdca5c32e5e40dd8ba651278aa449df91b8fdc3468ae")
