-- Lua provided by RyzenAPI
-- Game: AppID 842420

-- MAIN APPLICATION
addappid(842420)
-- Game: addappid(842420)

-- MAIN APP DEPOTS / PACKAGES
addappid(842421, 1, "9c9acdce93bf8ccce17a70463655252696e170b077fbab09de0df390bdbb7b91")
