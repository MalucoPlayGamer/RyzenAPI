-- Lua provided by SkyAPI 
-- Game: Stick Tongue
addappid(3356480)
addappid(3356481, 1, "7c5577ebd76dab2b7f7a97614547f2bb7a42fa4711908653d4587f6f67cc8628")
