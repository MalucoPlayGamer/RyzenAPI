-- Lua provided by RyzenAPI
-- Game: Stick Tongue

-- MAIN APPLICATION
addappid(3356480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356481, 1, "7c5577ebd76dab2b7f7a97614547f2bb7a42fa4711908653d4587f6f67cc8628")

