-- Lua provided by RyzenAPI
-- Game: Stick Tongue

-- MAIN APPLICATION
addappid(3356480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356481, 1, "7c5577ebd76dab2b7f7a97614547f2bb7a42fa4711908653d4587f6f67cc8628")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
