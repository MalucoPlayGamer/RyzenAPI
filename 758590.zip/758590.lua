-- Lua provided by RyzenAPI
-- Game: League of Light: Silent Mountain Collector's Edition

-- MAIN APPLICATION
addappid(758590)

-- MAIN APP DEPOTS / PACKAGES
addappid(758591,0,"f88fb09dd425a4852c8e45d3e0ae1c7db5e2eb92c92268f457be81cdb561fbe8")

