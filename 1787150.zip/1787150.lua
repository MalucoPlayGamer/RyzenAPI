-- Lua provided by RyzenAPI
-- Game: Futanari Jigsaw Puzzle

-- MAIN APPLICATION
addappid(1787150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787151, 1, "f4238736125898f7fc878dc0afb8c81dffab00fa7becb829141757ce0715c776")
