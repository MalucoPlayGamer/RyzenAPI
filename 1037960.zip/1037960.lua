-- Lua provided by RyzenAPI
-- Game: Grand Dude Simulator

-- MAIN APPLICATION
addappid(1037960)
-- Game: addappid(1037960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037961, 1, "58711b4084548280b689693ce7631698e4be9e73c3719d64be7b600007e77445")
