-- Lua provided by RyzenAPI
-- Game: addappid(2776760)

-- MAIN APPLICATION
addappid(2776760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776761, 1, "c602c31b7d9d75facc5c088148d1a7e4f7b364584e523e2cfc81e78304b136dc")
addappid(2776762, 1, "4dc8b38455dcf30432c71cb9641534ea1c8fe8e368bf9a12cc8ff72efbdda313")
