-- Lua provided by RyzenAPI 
-- Game: AppID 1314840
addappid(1314840)
addappid(1314841, 1, "2f45a7d5f5f73cd7250aa9092d141fb8db986f3a703e985453bb962c0fb8ec28")
