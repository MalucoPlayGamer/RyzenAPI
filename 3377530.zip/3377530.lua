-- Lua provided by RyzenAPI 
-- Game: Terminal 81R
addappid(3377530)
addappid(3377531, 1, "7b36d3638d4904e5dcf21a3f71092009cddc62e8269da25fc36b484d193b5098")
