-- Lua provided by RyzenAPI
-- Game: 792650

-- MAIN APPLICATION
addappid(792650)
-- Game: addappid(792650)

-- MAIN APP DEPOTS / PACKAGES
addappid(792651, 1, "8b168ddfca95c29dd2ae8ce9e4001ea0ceda2515deaa398e640d0ad81c7357b7")
addappid(1051520, 0, "54a1aacef02c75a9ea7a6f297899a4917f0b920fceba9b98b7eeb358b800d15c")
