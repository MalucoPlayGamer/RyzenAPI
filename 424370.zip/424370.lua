-- Lua provided by RyzenAPI
-- Game: Wolcen: Lords of Mayhem

-- MAIN APPLICATION
addappid(424370)
addappid(1192620)

-- MAIN APP DEPOTS / PACKAGES
addappid(424371, 1, "dcac2232b38de14cc6ca0224e6204cb1f0125c2408e43877fbf2daf2ed3ae556")
addappid(1192450, 0, "1c8fe137dff48b73536b2e2d03cb3a3bae1ed031223a292ed260cbdf9fb88759")
