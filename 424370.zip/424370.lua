-- Lua provided by RyzenAPI
-- Game: Wolcen: Lords of Mayhem

-- MAIN APPLICATION
addappid(424370)
addappid(1192620)
addappid(1430890)
addappid(1430891)
addappid(1430892)
addappid(1430893)
addappid(1430894)
addappid(1430895)
addappid(1430896)
addappid(1430897)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(424371, 1, "dcac2232b38de14cc6ca0224e6204cb1f0125c2408e43877fbf2daf2ed3ae556")
addappid(1192450, 0, "1c8fe137dff48b73536b2e2d03cb3a3bae1ed031223a292ed260cbdf9fb88759")

