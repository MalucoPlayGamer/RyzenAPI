-- Lua provided by RyzenAPI
-- Game: 2447260

-- MAIN APPLICATION
addappid(2447260)
addappid(3113450)
-- Game: addappid(2447260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447261, 1, "aae4cd2eb8f8ec62a8916342728c56cd5482f102e1fcabcb0cf85c043d8b7bfd")
