-- Lua provided by RyzenAPI
-- Game: Cats on Duty

-- MAIN APPLICATION
addappid(2447260)
addappid(3113450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2447261, 1, "aae4cd2eb8f8ec62a8916342728c56cd5482f102e1fcabcb0cf85c043d8b7bfd")

