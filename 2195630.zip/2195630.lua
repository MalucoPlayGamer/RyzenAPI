-- Lua provided by RyzenAPI 
-- Game: circloO
addappid(2195630)
addappid(2195631, 1, "fea51c53942546700746e356f06e777de20a072a87c11862ae52480cca77002c")
