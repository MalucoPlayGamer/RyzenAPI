-- Lua provided by RyzenAPI
-- Game: 1056390

-- MAIN APPLICATION
addappid(1056390)
-- Game: addappid(1056390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056391, 1, "de07bf77db5f1c602e1ce1832aa041c4c662ff082802c9f3f9cd1b1c92c9b953")
addappid(1077280, 0, "b74a429942babb6239d273784c75eb9a9ca231de2ca8686d19ef04e3a44821e9")
