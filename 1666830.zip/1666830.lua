-- Lua provided by RyzenAPI
-- Game: 1666830

-- MAIN APPLICATION
addappid(1666830)
addappid(1673950)
addappid(1674000)
-- Game: addappid(1666830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666831, 1, "69ff3d122db8ac530bf79edeab7cb373238838ce9594e091f47bf68d4a8da9fb")
