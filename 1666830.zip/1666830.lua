-- Lua provided by RyzenAPI
-- Game: Tales of Raetrethra - Legends of the Past

-- MAIN APPLICATION
addappid(1666830)
addappid(1673950)
addappid(1674000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666831, 1, "69ff3d122db8ac530bf79edeab7cb373238838ce9594e091f47bf68d4a8da9fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
