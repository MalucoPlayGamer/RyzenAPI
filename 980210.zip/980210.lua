-- Lua provided by RyzenAPI
-- Game: HordeCore

-- MAIN APPLICATION
addappid(980210)

-- MAIN APP DEPOTS / PACKAGES
addappid(980211, 1, "f19a246d9f8e2cb6420fbe16e386b76a7b598de413218c4352f90fe728f00003")

