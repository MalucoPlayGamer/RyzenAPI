-- Lua provided by RyzenAPI
-- Game: Demonheart

-- MAIN APPLICATION
addappid(578900)

-- MAIN APP DEPOTS / PACKAGES
addappid(578906,0,"1309b4194862761d06cc00f229340087fecbdfec6088844b039bed43dd3834e5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(957630)
