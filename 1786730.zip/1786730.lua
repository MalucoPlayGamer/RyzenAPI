-- Lua provided by RyzenAPI
-- Game: Xenture

-- MAIN APPLICATION
addappid(1786730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786731, 1, "d1d2cadeee339f10f6961e15249af99ff7b86d0028180197b3551bbaaec6d373")

