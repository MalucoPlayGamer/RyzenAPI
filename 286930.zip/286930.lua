-- Lua provided by RyzenAPI
-- Game: Crouching Pony Hidden Dragon

-- MAIN APPLICATION
addappid(286930)
-- Game: addappid(286930)

-- MAIN APP DEPOTS / PACKAGES
addappid(286931, 1, "ef57af46670f2075d6f3b8b4d786d28f1848065f131f18a3251475745339ec84")
