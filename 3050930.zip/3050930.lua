-- Lua provided by RyzenAPI
-- Game: addappid(3050930)

-- MAIN APPLICATION
addappid(3050930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050931, 1, "3fb3c44166b43dc0812a4ba1ba0a5aff53906236594ca0a0f1bcc180f7600344")
