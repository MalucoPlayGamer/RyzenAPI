-- Lua provided by RyzenAPI
-- Game: Close Order

-- MAIN APPLICATION
addappid(383800)

-- MAIN APP DEPOTS / PACKAGES
addappid(383801, 1, "b1d6d6234f5142f0ba87db065054d79ae19d05fee42dfbc72178804e5c7c3498")
