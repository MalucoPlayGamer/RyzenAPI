-- Lua provided by RyzenAPI
-- Game: 2244796

-- MAIN APPLICATION
addappid(2244796)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244796,0,"fa13bfc713e7a22e921bceb1774f4b1d06f4e2da972783a3a1bba2543b1bf393")

