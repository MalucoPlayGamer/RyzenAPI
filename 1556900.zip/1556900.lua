-- Lua provided by RyzenAPI
-- Game: Stronghold: Warlords Soundtrack

-- MAIN APPLICATION
addappid(1556900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556901, 1, "62020d60d20111f296b4b48908dfd6bfb731170d63423f9c9699f671ba533de4")
