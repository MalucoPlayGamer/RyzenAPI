-- Lua provided by RyzenAPI
-- Game: addappid(1552310)

-- MAIN APPLICATION
addappid(1552310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552311, 1, "22242ce27ef077cf5b2c10602dfa4f8d33d4b22b2ac790f7341df18eab84f4d7")
