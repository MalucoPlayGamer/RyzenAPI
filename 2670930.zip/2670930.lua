-- Lua provided by RyzenAPI
-- Game: addappid(2670930)

-- MAIN APPLICATION
addappid(2670930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670931, 1, "d76bd9a7d2ea306052e48ad896cad20c27bd736307756b8cfb8a44d0c0c0d3ee")
addappid(2670932, 1, "46d474a30b36c9570a5ccd7724956fc97bb3b66f73fb4f498d5baaade5917c03")
