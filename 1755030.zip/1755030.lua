-- Lua provided by RyzenAPI
-- Game: 1755030

-- MAIN APPLICATION
addappid(1755030)
-- Game: addappid(1755030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755031, 1, "d90dd5dff48e57895a18771163d97e12dca9463a5fa9d01a9cf849ad010f657f")
