-- Lua provided by RyzenAPI
-- Game: CreatorCrate

-- MAIN APPLICATION
addappid(1027060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027062,0,"90639b56a4b8cd56e80dd78f18b5d277104c6e23db96ea7227630ce6060455cf")
