-- Lua provided by RyzenAPI
-- Game: addappid(1898430)

-- MAIN APPLICATION
addappid(1898430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898431, 1, "b4ee873fc4a0887b902c0c7660f7b738f188a63aa9c8d84c9e63cc100eb0057f")
