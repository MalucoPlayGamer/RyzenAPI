-- Lua provided by RyzenAPI
-- Game: addappid(3236460)

-- MAIN APPLICATION
addappid(3236460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236461, 1, "5d747ccf8a941851727b9f05f7b9b5b336f76351bf7de4ea6190a6ff77735031")
