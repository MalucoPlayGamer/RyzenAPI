-- Lua provided by RyzenAPI
-- Game: addappid(1696120)

-- MAIN APPLICATION
addappid(1696120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696120,0,"1c4990bd1a779d5f1aa312afc3731fa823b170cd38aac777cd221afdd212ce89")
