-- Lua provided by RyzenAPI
-- Game: Crazy Machines

-- MAIN APPLICATION
addappid(18420)

-- MAIN APP DEPOTS / PACKAGES
addappid(18421, 1, "40a10f7e4c827e86c9a2ae941ac860376423b21fcde35f208b21ee2f1290d101")
