-- Lua provided by SkyAPI 
-- Game: Crazy Machines
addappid(18420)
addappid(18421, 1, "40a10f7e4c827e86c9a2ae941ac860376423b21fcde35f208b21ee2f1290d101")
