-- Lua provided by SkyAPI 
-- Game: Arevan
addappid(385900)
addappid(385901, 1, "36304d6a0cda89de8e851a90f62796ce2a483034bd8aaaf3b1891d5e556373a1")
addappid(386130, 0, "e688d6c875ddc6071754b6d42affaa4162b69ce141e6e224827556a2b976663c")
