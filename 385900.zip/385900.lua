-- Lua provided by RyzenAPI
-- Game: Arevan

-- MAIN APPLICATION
addappid(385900)

-- MAIN APP DEPOTS / PACKAGES
addappid(385901, 1, "36304d6a0cda89de8e851a90f62796ce2a483034bd8aaaf3b1891d5e556373a1")
addappid(386130, 0, "e688d6c875ddc6071754b6d42affaa4162b69ce141e6e224827556a2b976663c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
