-- Lua provided by RyzenAPI
-- Game: 1818230

-- MAIN APPLICATION
addappid(1818230)
-- Game: addappid(1818230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818231, 1, "0c3f0ca0facc07c0ac552df14623abb24c46cb0511e1cd919fc5d4a1df5688aa")
