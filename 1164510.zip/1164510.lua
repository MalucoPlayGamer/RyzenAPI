-- Lua provided by RyzenAPI
-- Game: 1164510

-- MAIN APPLICATION
addappid(1164510)
-- Game: addappid(1164510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164511, 1, "eedd1d6fa50c6b204081b9c89dd7171e0739411b1a139227ab09f9ac059328c7")
