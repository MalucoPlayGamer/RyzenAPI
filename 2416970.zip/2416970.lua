-- Lua provided by RyzenAPI
-- Game: Vesna

-- MAIN APPLICATION
addappid(2416970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416971, 1, "b1ae4bf5b3991957c80e837896c0a9f1d29c840d3a0bdcbf35489c88f00b4a33")
