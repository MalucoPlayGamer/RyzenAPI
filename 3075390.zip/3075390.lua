-- Lua provided by RyzenAPI
-- Game: Game: AppID 3075390

-- MAIN APPLICATION
addappid(3075390)
-- Game: addappid(3075390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075391, 1, "764c50a0be394b2b17f8b53c328a5149bf88e3c5c8965050a847157081eab9d9")
