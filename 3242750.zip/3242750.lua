-- Lua provided by RyzenAPI
-- Game: Level Devil

-- MAIN APPLICATION
addappid(3242750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242751, 1, "20715373400230b7184afdfb64c33c5a97093edd019c92ada23c16db734de7b3")
