-- Lua provided by RyzenAPI
-- Game: Leap of Love

-- MAIN APPLICATION
addappid(1469300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469301, 1, "fea0462f48ef2ad87e988f175bfb13d8530e479c3fc96ca95d2e1152ec39c932")
addappid(1806280, 0, "675fd81daf5a420c0c283d47bab822063a7674b899f6dbe50d1cc0122a6a34e2")
