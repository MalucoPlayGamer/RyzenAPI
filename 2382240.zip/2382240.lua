-- Lua provided by RyzenAPI
-- Game: Game: Awita: Journey of Hope

-- MAIN APPLICATION
addappid(2382240)
-- Game: addappid(2382240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382241, 1, "e6acc007adce390d337160e15d07064465784b355da2c83c921703c6bdfe63d7")
