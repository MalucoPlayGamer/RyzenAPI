-- Lua provided by RyzenAPI
-- Game: Cute Cute Cuties

-- MAIN APPLICATION
addappid(1127390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127391, 1, "1814eab23b4619246e5e144edfece235a8c5b7d0206b742241d3dc3cdb2c989f")
