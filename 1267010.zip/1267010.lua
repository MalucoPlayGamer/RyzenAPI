-- Lua provided by RyzenAPI
-- Game: Dark Fantasy: Epic Jigsaw Puzzle

-- MAIN APPLICATION
addappid(1267010)
-- Game: addappid(1267010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267011, 1, "9a9409586910d57d1dc80c05d3e2b713ded86ae0273b63e943ff48854cfe656f")
