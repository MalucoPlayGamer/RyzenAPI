-- Lua provided by RyzenAPI
-- Game: One More Gate : A Wakfu Legend

-- MAIN APPLICATION
addappid(1832950)
-- Game: addappid(1832950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832951, 1, "7b87d673d470765d2216fbfa6bfeca74bc761b8b04a1f809c9b6e663fbad739f")
addappid(1832952, 1, "16fa15ac1711458a34c1888cc2c864f1534bed5802ae8940b07f1c3c049d6e6e")
