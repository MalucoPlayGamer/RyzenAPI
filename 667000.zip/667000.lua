-- Lua provided by RyzenAPI
-- Game: Casus Belli: Battle Of Annihilation

-- MAIN APPLICATION
addappid(667000)
-- Game: addappid(667000)

-- MAIN APP DEPOTS / PACKAGES
addappid(667001, 1, "92612a9e090406f8069cb1d8418bc973564c4263dd0491a5d476764f5c0ec485")
