-- Lua provided by RyzenAPI
-- Game: AppID 976890

-- MAIN APPLICATION
addappid(976890)

-- MAIN APP DEPOTS / PACKAGES
addappid(976891, 1, "49094bb5630971acb88990f53e33a49560b3f354cd99790ba7f978c86457bbbc")
addappid(1670550, 0, "800b9e049bb1f65fd22b1263a6dd390cadedc9e091ea64fbc8e2437d1200bbac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
