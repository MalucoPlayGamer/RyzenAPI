-- Lua provided by RyzenAPI
-- Game: addappid(976890)

-- MAIN APPLICATION
addappid(976890)

-- MAIN APP DEPOTS / PACKAGES
addappid(976891, 1, "49094bb5630971acb88990f53e33a49560b3f354cd99790ba7f978c86457bbbc")
addappid(1670550, 0, "800b9e049bb1f65fd22b1263a6dd390cadedc9e091ea64fbc8e2437d1200bbac")
