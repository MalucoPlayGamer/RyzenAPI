-- Lua provided by RyzenAPI
-- Game: Xpand Rally Xtreme

-- MAIN APPLICATION
addappid(3050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051, 1, "64c778d2e61699da1986c0b4a680d03954858c505a700d75d58b5dc4d2d21fa5")
