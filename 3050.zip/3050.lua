-- Lua provided by SkyAPI 
-- Game: Xpand Rally Xtreme
addappid(3050)
addappid(3051, 1, "64c778d2e61699da1986c0b4a680d03954858c505a700d75d58b5dc4d2d21fa5")
