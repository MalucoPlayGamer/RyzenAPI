-- Lua provided by RyzenAPI
-- Game: 1097050

-- MAIN APPLICATION
addappid(1097050)
-- Game: addappid(1097050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097051, 1, "a309fb6520469a20092a55ff371749d67e8c50dfc91f1c97cf159656ddca11c3")
