-- Lua provided by RyzenAPI 
-- Game: AppID 1097050
addappid(1097050)
addappid(1097051, 1, "a309fb6520469a20092a55ff371749d67e8c50dfc91f1c97cf159656ddca11c3")
