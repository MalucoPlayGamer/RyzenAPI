-- Lua provided by RyzenAPI
-- Game: 绝地反击

-- MAIN APPLICATION
addappid(1097050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1097051, 1, "a309fb6520469a20092a55ff371749d67e8c50dfc91f1c97cf159656ddca11c3")
