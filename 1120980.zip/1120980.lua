-- Lua provided by RyzenAPI
-- Game: addappid(1120980)

-- MAIN APPLICATION
addappid(1120980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120981, 1, "7a10d2610967bbb250cc9db22e5a2cd54dbe88d08d66d6d4c7fa5351a869e772")
