-- 3729810's Lua and Manifest Created by Hubcap Manifest
-- Yet Another Incremental Game
-- Created: July 14, 2026 at 19:36:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3729810) -- Yet Another Incremental Game
-- MAIN APP DEPOTS
addappid(3729811, 1, "7458584be9ae77d511af38f69e12d6ed7bf065caea348672b12e3ddcbbe4de9e") -- Depot 3729811
setManifestid(3729811, "2694868839116242735", 347856136)
addappid(3729812, 1, "0f264fb0b42252b7fccb4141e7635afa913f31ed130ef907f742dcd94c701153") -- Depot 3729812
setManifestid(3729812, "3526910295334121516", 319153413)
addappid(3729813, 1, "2d6732554f640841ef87e0337d811891592e8efdfe541dbb8da4159a4c6f8de1") -- Depot 3729813
setManifestid(3729813, "2421673395296835058", 337492512)