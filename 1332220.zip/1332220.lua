-- Lua provided by RyzenAPI
-- Game: addappid(1332220)

-- MAIN APPLICATION
addappid(1332220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332221, 1, "d50c62898f30a18f0c758ab2ddcedf92d24177fde0ebe683190e253724bbc501")
