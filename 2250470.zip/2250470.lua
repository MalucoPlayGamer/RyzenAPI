-- Lua provided by RyzenAPI
-- Game: addappid(2250470)

-- MAIN APPLICATION
addappid(2250470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250471, 1, "9545d2e2efffc3a1f8a7837132e2790b8a2349cea734ab2ac513e08598a73fec")
