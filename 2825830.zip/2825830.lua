-- Lua provided by RyzenAPI
-- Game: Game: Dicefolk Soundtrack

-- MAIN APPLICATION
addappid(2825830)
-- Game: addappid(2825830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825831, 1, "52945e30906e85bb9611893405b46b42f4b5b1c6f3bb719fcc6845ef346a7994")
addappid(2825832, 1, "e7cb2ee0092a6ca9d2857c9277f49739ec3ed58cba36f910d3af55ee7601143f")
