-- Lua provided by RyzenAPI
-- Game: Apocalypse Survivor

-- MAIN APPLICATION
addappid(1282040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282041, 1, "181c4039154b3c33244f0501d0e1c8173c0ab35fdf2450c56198d9f9aaff8ed3")
