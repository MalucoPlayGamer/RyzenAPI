-- Lua provided by RyzenAPI
-- Game: Supply Chain Idle

-- MAIN APPLICATION
addappid(946040)

-- MAIN APP DEPOTS / PACKAGES
addappid(946041, 1, "9605e58d708f48157fa63c80a9ffb2263f24da262a557f160336fd1b63fe040c")
addappid(946042, 1, "092fee7dc118753d42011689ec06c9c41d9883dc618e90caecc017f81710ad0c")
addappid(946043, 1, "3f4ead22b23440fa32fe1edb4df5b121f00e8d7924ef43ee0e99d6d51b15dc79")

