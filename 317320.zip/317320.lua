-- Lua provided by RyzenAPI
-- Game: Nelly Cootalot: The Fowl Fleet

-- MAIN APPLICATION
addappid(317320)

-- MAIN APP DEPOTS / PACKAGES
addappid(317321, 1, "49a5b744845945ec3970d4827be8b7efcd3ec41fa5baf61a986ba1aa25783430")
addappid(1096070, 0, "3d4700d35c594444339235e25051eccd2c199da355b03c371ed3ab871cdb4fb4")
