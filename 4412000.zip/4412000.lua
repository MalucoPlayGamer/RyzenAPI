-- Lua provided by RyzenAPI
-- Game: Zad Archery

-- MAIN APPLICATION
addappid(4412000)
addappid(5053390) -- Zad Archery - Arrowfall Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4412001, 1, "8431359d1e9c173ced3d18c8313bc5d41b3d1d7969780cc7422a2231b43c9e22") -- (windows)
addappid(4412002, 1, "aac1ac9373d25fedcb3e7538dd4aaaf2efb14e11c4a6b38047556a3a5ea79bc3") -- (macos)
addappid(4412003, 1, "643ce514b64835ece6e8b2cbf74e85a376dcb4071ab700696809689d324cd4f3") -- (linux)

