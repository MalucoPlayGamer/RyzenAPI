-- Lua provided by RyzenAPI
-- Game: Zad Archery

-- MAIN APPLICATION
addappid(4412000) -- Zad Archery
addappid(5053390) -- Zad Archery - Arrowfall Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4412001, 1, "8431359d1e9c173ced3d18c8313bc5d41b3d1d7969780cc7422a2231b43c9e22") -- Depot 4412001
