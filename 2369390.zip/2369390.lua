-- Lua provided by RyzenAPI
-- Game: Game: Far Cry® 6

-- MAIN APPLICATION
addappid(2369390)
-- Game: addappid(2369390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369391, 1, "c3d84384b92e4ab8aa58ab4d8602f408821c5ce3b7a213d07d79926a6198180b")
addappid(2432590, 0, "3b4498e4cb314f981631df47a5a260f6f0ea14bbbb77e50efa0c2810741435d4")
