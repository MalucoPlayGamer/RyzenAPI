-- Lua provided by RyzenAPI
-- Game: Far Cry® 6

-- MAIN APPLICATION
addappid(2369390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369391, 1, "c3d84384b92e4ab8aa58ab4d8602f408821c5ce3b7a213d07d79926a6198180b")
addappid(2432590, 0, "3b4498e4cb314f981631df47a5a260f6f0ea14bbbb77e50efa0c2810741435d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2369450)
addappid(2369451)
addappid(2369452)
addappid(2369453)
addappid(2369454)
addappid(2369455)
addappid(2369456)
addappid(2369457)
addappid(2369458)
addappid(2369459)
addappid(2369470)
addappid(2369471)
addappid(2369472)
addappid(2369473)
addappid(2369530)
addappid(2369531)
addappid(2369532)
addappid(2369533)
