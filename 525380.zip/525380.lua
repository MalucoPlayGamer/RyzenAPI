-- Lua provided by RyzenAPI
-- Game: 525380

-- MAIN APPLICATION
addappid(228990)
addappid(229004)
addappid(229020)
addappid(525380)
addappid(525381)
addappid(525382)
addappid(525383)
addappid(525387)

-- MAIN APP DEPOTS / PACKAGES
addappid(525388,0,"a0f9b8246f329f86a664436f3f9cfcce81fbf27993c3b14db312350ddb388d06")
addappid(525389,0,"27c149e5c916bc5412a7c577b73dc593432a6e30bd781ead506e574e5cff2c2d")

