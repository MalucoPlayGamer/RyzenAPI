-- Lua provided by RyzenAPI
-- Game: My Time At Portia - Original Soundtrack

-- MAIN APPLICATION
addappid(974290)

-- MAIN APP DEPOTS / PACKAGES
addappid(974290,0,"84be8752960a67692f7cd6bbf8a304251476906f7f6cba2c63b8c90f9b12cf76")
