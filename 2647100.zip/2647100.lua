-- Lua provided by RyzenAPI
-- Game: addappid(2647100)

-- MAIN APPLICATION
addappid(2647100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647101, 1, "48c148de57bae833bb6aacb46c39fbefbbe24acf6960d5f4176ae16daa27c9d9")
