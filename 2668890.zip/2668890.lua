-- Lua provided by RyzenAPI
-- Game: Kon's Lesson! Collector's edition

-- MAIN APPLICATION
addappid(2668890)
addappid(2668891)
addappid(2668892)
addappid(2668893)
-- Game: addappid(2668890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668890,0,"cd3317826a9e71f65b6c4a23e278360039fa98b87189e2943041f3fc16717f65")
