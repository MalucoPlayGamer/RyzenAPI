-- Lua provided by RyzenAPI
-- Game: Game: Drawy

-- MAIN APPLICATION
addappid(1547300)
-- Game: addappid(1547300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547301, 1, "0f1a22c6533140ba67e0e6b67bc55a09369052dbedf7e57af0154470d6777996")
