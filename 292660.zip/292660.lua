-- Lua provided by RyzenAPI
-- Game: addappid(292660)

-- MAIN APPLICATION
addappid(292660)

-- MAIN APP DEPOTS / PACKAGES
addappid(292661, 1, "8329ba8b3b37edcc93083c87747a7ba3478d7df10dd0d4181d24ffd7f0ea82bf")
