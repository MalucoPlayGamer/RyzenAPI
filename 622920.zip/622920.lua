-- Lua provided by RyzenAPI
-- Game: AppID 622920

-- MAIN APPLICATION
addappid(622920)
-- Game: addappid(622920)

-- MAIN APP DEPOTS / PACKAGES
addappid(622921, 1, "3dc78812a72258d75c93a31b639d074ab8c55949af80d0f8fbff8e895c0834e0")
