-- Lua provided by RyzenAPI
-- Game: XGamer - AI revolution

-- MAIN APPLICATION
addappid(2055600)
addappid(2089470)
addappid(2090720)
addappid(2091430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2055601, 1, "988586e55707736982686495361afe39fe09b1b40c32c8f1781070476085ce53")

