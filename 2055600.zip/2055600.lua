-- Lua provided by RyzenAPI 
-- Game: XGamer - AI revolution
addappid(2055600)
addappid(2055601, 1, "988586e55707736982686495361afe39fe09b1b40c32c8f1781070476085ce53")
