-- Lua provided by RyzenAPI
-- Game: Game: XGamer - AI revolution

-- MAIN APPLICATION
addappid(2055600)
-- Game: addappid(2055600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055601, 1, "988586e55707736982686495361afe39fe09b1b40c32c8f1781070476085ce53")
