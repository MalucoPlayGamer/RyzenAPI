-- Lua provided by RyzenAPI
-- Game: addappid(2661300)

-- MAIN APPLICATION
addappid(2661300)
addappid(3788090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661301, 1, "cac026f4758d6992ff85de08375749a662b82dc6517be7dc72368060eca7427d")
