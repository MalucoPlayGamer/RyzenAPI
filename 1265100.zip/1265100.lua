-- Lua provided by RyzenAPI
-- Game: addappid(1265100)

-- MAIN APPLICATION
addappid(1265100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265100,0,"211ac90a9a968e47900773241c1aa6c44f0ab7a7557d5b57715aadd3e3eac7ea")
