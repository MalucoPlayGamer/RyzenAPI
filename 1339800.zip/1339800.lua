-- Lua provided by RyzenAPI
-- Game: Seeker 2

-- MAIN APPLICATION
addappid(1339800)
-- Game: addappid(1339800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339801, 1, "9d1e7b750468a69012ea7b70cd5160996291578dfee69514388046f29e8f26b9")
