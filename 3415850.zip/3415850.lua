-- Lua provided by RyzenAPI
-- Game: AppID 3415850

-- MAIN APPLICATION
addappid(3415850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415851, 1, "b4005e61df6d97173b0c25b4df49dc9b7ff7b5ebd625d9a08b3c470c4a4e2fc3")

