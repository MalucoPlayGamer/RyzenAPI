-- Lua provided by RyzenAPI 
-- Game: Gnumz: Masters of Defense
addappid(371460)
addappid(371461, 1, "ca77dbd7f04e3b398e0c7f21ea8162419f7b36a4a97694bdb869d2b3012d2d34")
