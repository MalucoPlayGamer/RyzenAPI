-- Lua provided by RyzenAPI
-- Game: addappid(371460)

-- MAIN APPLICATION
addappid(371460)

-- MAIN APP DEPOTS / PACKAGES
addappid(371461, 1, "ca77dbd7f04e3b398e0c7f21ea8162419f7b36a4a97694bdb869d2b3012d2d34")
