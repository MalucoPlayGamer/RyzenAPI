-- Lua provided by RyzenAPI
-- Game: Jagged Alliance 2 Gold

-- MAIN APPLICATION
addappid(12370)
-- Game: addappid(12370)

-- MAIN APP DEPOTS / PACKAGES
addappid(12371, 1, "dfc0c96a2d06a6f9d8fbc5fc51e98d6f1b0a1e71b379413893792cace6597514")
