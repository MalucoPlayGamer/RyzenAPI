-- Lua provided by RyzenAPI
-- Game: Game: Waterpark Simulator

-- MAIN APPLICATION
addappid(1362910)
-- Game: addappid(1362910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362911, 1, "0b2d80c0e4107dda322bfa69e55bed8e9e1a31cc0d656576b0f7033e7634913e")
