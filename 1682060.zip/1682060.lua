-- Lua provided by RyzenAPI
-- Game: addappid(1682060)

-- MAIN APPLICATION
addappid(1682060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682061, 1, "ca21c05ae26ef70ea28fc33a4b52cead451561b3bf58513cdd9d2c3f3aa99863")
