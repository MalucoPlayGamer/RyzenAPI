-- Lua provided by RyzenAPI
-- Game: addappid(2426240)

-- MAIN APPLICATION
addappid(2426240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426241, 1, "715d4f2f0fc03cdcbc8a12a93496905d6d03063477784bd585f20fc6b6d17b09")
