-- Lua provided by RyzenAPI
-- Game: Game: AppID 428430

-- MAIN APPLICATION
addappid(428430)
-- Game: addappid(428430)

-- MAIN APP DEPOTS / PACKAGES
addappid(428431, 1, "0290fbdc3bd395e6e65bfa2302444481fb8f522a4e88c5e7d98e78a86a07c4b8")
addappid(450730, 0, "bbeb8e7072ddf678e1c1b323ffcd2519a3191360818266983edd1f6f2ceb3388")
