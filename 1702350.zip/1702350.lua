-- Lua provided by RyzenAPI 
-- Game: Mind Space
addappid(1702350)
addappid(1702351, 1, "c7e16155ef6b236a32fb6ee4549e50f0a1c3d9a7bf52c8de31a18cf78c101d39")
