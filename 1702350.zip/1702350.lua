-- Lua provided by RyzenAPI
-- Game: Game: Mind Space

-- MAIN APPLICATION
addappid(1702350)
-- Game: addappid(1702350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702351, 1, "c7e16155ef6b236a32fb6ee4549e50f0a1c3d9a7bf52c8de31a18cf78c101d39")
