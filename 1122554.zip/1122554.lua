-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1122554)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122554,0,"132bb7eb3d3c3f9f647b4e2fd427d1b2dcd84f0b422a5453b548f741866d77a4")

