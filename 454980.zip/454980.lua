-- Lua provided by RyzenAPI
-- Game: addappid(454980)

-- MAIN APPLICATION
addappid(454980)

-- MAIN APP DEPOTS / PACKAGES
addappid(454981, 1, "baff953bba2835747faa5c95cf6c53201e88bdde5803e41af6789b0bf43599ad")
