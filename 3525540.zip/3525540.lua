-- Lua provided by SkyAPI 
-- Game: AppID 3525540
addappid(3525540)
addappid(3525541, 1, "7bb94bfc6ea22c6200b8fc88d71135ebc876da657d50ad56ff4a57f240492e53")
