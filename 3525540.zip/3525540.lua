-- Lua provided by RyzenAPI
-- Game: 3525540

-- MAIN APPLICATION
addappid(3525540)
-- Game: addappid(3525540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3525541, 1, "7bb94bfc6ea22c6200b8fc88d71135ebc876da657d50ad56ff4a57f240492e53")
