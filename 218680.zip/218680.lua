-- Lua provided by RyzenAPI
-- Game: Scribblenauts Unlimited

-- MAIN APPLICATION
addappid(218680)

-- MAIN APP DEPOTS / PACKAGES
addappid(218681, 1, "9f9ca821c36d73d5fb6d7a8fafe8f736d405a573bb231646ef9811932563bf6e")

