-- Lua provided by RyzenAPI
-- Game: Detective Grimoire

-- MAIN APPLICATION
addappid(272600)
-- Game: addappid(272600)

-- MAIN APP DEPOTS / PACKAGES
addappid(272601, 1, "2553865c63c28d59cffeeb360b4bb5cf2ad50101d5dc706048e1948d53f22758")
addappid(272602, 1, "e2aed31da350e34a8e3ebef27dc4dc39ee00a9420803bbe8cad1b14e70778f82")
addappid(272603, 1, "8076797e980fcd729257d0c9619e90a8e7423c111ac9f1bdf9e02249af37c46a")
