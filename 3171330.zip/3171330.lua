-- Lua provided by RyzenAPI 
-- Game: AppID 3171330
addappid(3171330)
addappid(3171331, 1, "5377345febc690f8088b9e21d6b6fae64a9bc49a9132c37d035623e796e3973c")
