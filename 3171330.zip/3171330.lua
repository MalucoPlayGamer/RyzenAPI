-- Lua provided by RyzenAPI
-- Game: 东方奇缘记 Demo

-- MAIN APPLICATION
addappid(3171330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171331, 1, "5377345febc690f8088b9e21d6b6fae64a9bc49a9132c37d035623e796e3973c")
