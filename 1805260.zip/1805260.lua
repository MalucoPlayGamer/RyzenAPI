-- Lua provided by RyzenAPI
-- Game: Game: AppID 1805260

-- MAIN APPLICATION
addappid(1805260)
-- Game: addappid(1805260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805261, 1, "e25c543945b29b90c452daf42e07082c7062e1b291f79c39d09c08d81ab07087")
