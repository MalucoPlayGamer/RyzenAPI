-- Lua provided by RyzenAPI
-- Game: 1596850

-- MAIN APPLICATION
addappid(1596850)
-- Game: addappid(1596850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596852,0,"40cc34aa5f94adb5e17146bba1a5249b758846c20b6145a03bee21453ef096d6")
