-- Lua provided by RyzenAPI
-- Game: Cyndy

-- MAIN APPLICATION
addappid(1014730)
addappid(1153680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1014731, 1, "193799e91e157a55517d63b73f4d83d76ce21fb9d9dd5e5c90cb8c849fd22b61")
addappid(1014733, 1, "592653283c81676a577e5042c97bd250a9b15e16de5772a9cf70d0bd79f07bae")

