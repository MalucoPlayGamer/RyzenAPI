-- Lua provided by RyzenAPI 
-- Game: AppID 1338390
addappid(1338390)
addappid(1338391, 1, "064494dc6d269d45d525f63a4a589456fa968d5c5f581648402a56a8ad304213")
