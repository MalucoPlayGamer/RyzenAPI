-- Lua provided by RyzenAPI
-- Game: Cult of the Wind

-- MAIN APPLICATION
addappid(293840)

-- MAIN APP DEPOTS / PACKAGES
addappid(293841, 1, "617f673df85a42fbdee4789e947c86e0b16502b1806d8a94941fa434754ce56d")
addappid(293842, 1, "bc6deb6351d7ed7f123b3cde2018c7a5fdf58e6dac1907d4a00a5778fd8b732e")
addappid(293843, 1, "8a18134d9bb5e6bf5f2cc6521ed6337c759133dd4d64899adbae04920df6df67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
