-- Lua provided by RyzenAPI
-- Game: Game: AppID 2422620

-- MAIN APPLICATION
addappid(2422620)
-- Game: addappid(2422620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422621, 1, "6be2b91cf40ad1721d1c4a04f4336d233a8dd5c2a239eaf093c240d2e3164c8b")
