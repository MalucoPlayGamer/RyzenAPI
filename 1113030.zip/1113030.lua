-- Lua provided by RyzenAPI
-- Game: Stellar Warfare

-- MAIN APPLICATION
addappid(1113030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113031, 1, "5e7460417a30d5bc20fb11c602f552a928bf050abaf244474a5776a2d19bc7da")

