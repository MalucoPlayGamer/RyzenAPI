-- Lua provided by RyzenAPI
-- Game: Game: Pro Wrestling X

-- MAIN APPLICATION
addappid(297310)
-- Game: addappid(297310)

-- MAIN APP DEPOTS / PACKAGES
addappid(297311, 1, "596e4e64cc84caa359b96f5db0e8ef45bf5eb9ad9f35a91a2cae4987cabf51e9")
