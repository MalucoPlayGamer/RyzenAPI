-- Lua provided by RyzenAPI
-- Game: Pro Wrestling X

-- MAIN APPLICATION
addappid(297310)

-- MAIN APP DEPOTS / PACKAGES
addappid(297311, 1, "596e4e64cc84caa359b96f5db0e8ef45bf5eb9ad9f35a91a2cae4987cabf51e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
