-- Lua provided by RyzenAPI 
-- Game: The Genesis Order
addappid(2553870)
addappid(2553871, 1, "7eb6f1e8beddbfaeb434476e4d1d7c2a53c9c3b799888085d89703ee3e4ec36a")
addappid(2553872, 1, "afe6f6bc2bb24e9465165b6d86b8b674125673c0a0fbccac0d978b8ed742832f")
addappid(2553873, 1, "4f7903e435bc33dca3742bbe6899391caf0b3d0b8021fadd90d6c077b0d34fd3")
