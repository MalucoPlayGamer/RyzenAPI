-- Lua provided by RyzenAPI
-- Game: West of Dead: Soundtrack

-- MAIN APPLICATION
addappid(1301540)
-- Game: addappid(1301540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301541, 1, "78f9bb979a677efd91051c1427d2383882c4161c013809b89e00b87582b29278")
addappid(1301542, 1, "2ef61a5ccd36bc8cb24b3f2cd0cf57be98772af16ec67ee8e5866dc716067bd4")
