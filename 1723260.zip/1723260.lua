-- Lua provided by RyzenAPI
-- Game: CaseCracker

-- MAIN APPLICATION
addappid(1723260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723261, 1, "0ceea98d91910a55afb72d40979de4ca015d102c3837f0e6cb7eee5d312fab56")
addappid(1723263, 1, "4d1a532dd258ef271fc0ef20d0b8e6a424515d48e2427eb44cde7ce830cf6665")
