-- Lua provided by RyzenAPI
-- Game: 3394080

-- MAIN APPLICATION
addappid(3394080)
-- Game: addappid(3394080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3394081, 1, "a55200e42abd908499968a30dd65529e5d9c7475f5ac318dd9b45c5aa040d67b")
