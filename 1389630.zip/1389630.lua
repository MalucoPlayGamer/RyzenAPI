-- Lua provided by RyzenAPI
-- Game: High Entropy: Challenges

-- MAIN APPLICATION
addappid(1389630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389631, 1, "ba1a6f1d3036e07fdc3f816a72679cfb2f7c18dc789032c9435d8f5f886890ed")
