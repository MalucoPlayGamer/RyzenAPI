-- Lua provided by RyzenAPI
-- Game: Assetto Corsa Competizione Dedicated Server

-- MAIN APPLICATION
addappid(1430110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430111, 1, "baebc1319bfdbfaf0841d1dc24f75c2a1a48d4728609317e672a3d9cac5517ba")

