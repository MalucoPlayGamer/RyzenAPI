-- Lua provided by RyzenAPI
-- Game: Game: AppID 625730

-- MAIN APPLICATION
addappid(625730)
addappid(840520)
-- Game: addappid(625730)

-- MAIN APP DEPOTS / PACKAGES
addappid(625731, 1, "73c24a035966b9fef4419313593e7d8d74588709ba2626354986934f27829bae")
