-- Lua provided by RyzenAPI
-- Game: AppID 368780

-- MAIN APPLICATION
addappid(368780)

-- MAIN APP DEPOTS / PACKAGES
addappid(368781, 1, "f77976c59c5d91d7bc7ce0bc0801fcb86da32c22eeb1cd67abda07befde4a039")
addappid(368782, 1, "3fb2d47448bab4ea15a640012a6ddd1f9291e0dda89652bdaa04d8ff4f1b38fc")
