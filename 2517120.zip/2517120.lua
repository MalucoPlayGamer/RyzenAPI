-- Lua provided by RyzenAPI
-- Game: addappid(2517120)

-- MAIN APPLICATION
addappid(2517120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517121, 1, "5dae4580b15fe90fc3cbebb829c2e399e73ea43a977afe556cd813de4600bb68")
