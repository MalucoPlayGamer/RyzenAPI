-- Lua provided by RyzenAPI 
-- Game: Epoch of Guardians
addappid(3183500)
addappid(3183501, 1, "54df609a0197e30bfe5bd1ea8058bb42b7e9c4f8ad9e9452397ad33ee59741ec")
