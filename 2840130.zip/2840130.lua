-- Lua provided by RyzenAPI
-- Game: Game: The Endless Empty Soundtrack

-- MAIN APPLICATION
addappid(2840130)
-- Game: addappid(2840130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840131, 1, "9332f978ec43d260fc83c8ced62015225a8eb0d524fdc2ad4c9c9b25d476343a")
