-- Lua provided by RyzenAPI
-- Game: Peglin

-- MAIN APPLICATION
addappid(1296610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296612,0,"c49de821f253df8466134db36c94c7808fd1ecb08b35b78580339be9e89663c5")
addappid(1296613,0,"fb761a5ae924f7b0b79fd004dd2f05cda227b78400202d0c24b03197beb72263")
addappid(1296614,0,"8a12d17a3edba3d6cf982ceea529e1dfb0d92750fc88897ad0f553ab7664ba2c")
addappid(1296615,0,"69d4dde7164fff357b48e7935dc14348d966ff0a3bfc2af37f2a888e531fb517")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4528840)
