-- Lua provided by RyzenAPI
-- Game: Wild Cats of Wasteland

-- MAIN APPLICATION
addappid(1044460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044461, 1, "40fc9f73317dc67113cfe6f71e6528c9f2d98d51e373a87252c9a08d8de1afbd")

