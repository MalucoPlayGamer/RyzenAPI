-- Lua provided by RyzenAPI
-- Game: AppID 785880

-- MAIN APPLICATION
addappid(785880)
-- Game: addappid(785880)

-- MAIN APP DEPOTS / PACKAGES
addappid(785881, 1, "d6d72a30c78c9d41858e4a767471b3520eafded7ae91a436ae7f53e6c3a2ee6b")
