-- Lua provided by RyzenAPI
-- Game: addappid(1787030)

-- MAIN APPLICATION
addappid(1787030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787031, 1, "19d6f02eedd5d061e41f31d0fa01b24d9961254b1ec7f2daa63db498629a9184")
