-- Lua provided by RyzenAPI
-- Game: Pushcat

-- MAIN APPLICATION
addappid(308440)

-- MAIN APP DEPOTS / PACKAGES
addappid(308441, 1, "7102c34686c556605fe69e3a57bdb89fd1bae9d418b712b4a36010461336f773")
