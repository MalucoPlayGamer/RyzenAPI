-- Lua provided by RyzenAPI
-- Game: Lilim Clicker

-- MAIN APPLICATION
addappid(4071500) -- Lilim Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4071501, 1, "e50fb2a62754c4c346adc9a2268a364870163f3830ce0c8bb2a63afda4de6006") -- Depot 4071501

