-- 4071500's Lua and Manifest Created by Hubcap Manifest
-- Lilim Clicker
-- Created: August 08, 2026 at 07:57:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4071500) -- Lilim Clicker
-- MAIN APP DEPOTS
addappid(4071501, 1, "e50fb2a62754c4c346adc9a2268a364870163f3830ce0c8bb2a63afda4de6006") -- Depot 4071501
setManifestid(4071501, "3906587333328812210", 589958501)