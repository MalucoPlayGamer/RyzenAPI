-- Lua provided by RyzenAPI
-- Game: AppID 1445910

-- MAIN APPLICATION
addappid(1445910)
-- Game: addappid(1445910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445911, 1, "f1a5da0ecd66e90d19278c4c6ef0d1c25e8d15bc296c927ca868695e485715e1")
