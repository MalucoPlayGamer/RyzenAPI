-- Lua provided by RyzenAPI
-- Game: addappid(1653060)

-- MAIN APPLICATION
addappid(1653060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653061, 1, "76c92b1be8e79d420857a757b9e868efad7bef0bdfbd9282878e963feb5f820d")
