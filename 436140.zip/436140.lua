-- Lua provided by RyzenAPI
-- Game: 436140

-- MAIN APPLICATION
addappid(436140)
-- Game: addappid(436140)

-- MAIN APP DEPOTS / PACKAGES
addappid(436141, 1, "5767acb3c2d8595bd39ef788e7ea081d6720a84827b0d5cd86cc4db2bad9f654")
addappid(436142, 1, "e62fcb86078bd6c822f3c10a5ad17a41f833a9ddc0eee2bb67ffae8aaee6c6bf")
