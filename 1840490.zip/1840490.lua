-- Lua provided by RyzenAPI
-- Game: Christmas Massacre

-- MAIN APPLICATION
addappid(1840490)
-- Game: addappid(1840490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840491, 1, "44ad101d048e1320787688452b4ffc7810e67b2a596ccc784b38d4a8d869a1b3")
