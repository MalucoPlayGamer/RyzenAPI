-- Lua provided by RyzenAPI
-- Game: 1713140

-- MAIN APPLICATION
addappid(1713140)
-- Game: addappid(1713140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713141, 1, "9be3779953e16e7f5395a2d0cc633180a119cc148b4b0fe8bc8630c7b1d77aa7")
