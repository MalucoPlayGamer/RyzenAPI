-- Lua provided by RyzenAPI
-- Game: AIR

-- MAIN APPLICATION
addappid(2983250)
-- Game: addappid(2983250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983251, 1, "1d2f3c4b812333c9525df635402db7ba20966dc65af74a25b60762dbdfc2691d")
