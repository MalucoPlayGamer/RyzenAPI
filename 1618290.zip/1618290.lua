-- Lua provided by RyzenAPI
-- Game: 1618290

-- MAIN APPLICATION
addappid(1618290)
-- Game: addappid(1618290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618291, 1, "92da90c72e7bad853a950e21eb2507ecd64869c4bffb65fc55c9b87373bf883f")
