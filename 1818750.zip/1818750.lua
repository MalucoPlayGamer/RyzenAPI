-- Lua provided by RyzenAPI
-- Game: MultiVersus

-- MAIN APPLICATION
addappid(1818750)
addappid(2015370)
addappid(2015371)
addappid(2015372)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1818751, 1, "703872d235187bd044d110d6f6a64601e76f407c48822716a2d4e166651caab3")

