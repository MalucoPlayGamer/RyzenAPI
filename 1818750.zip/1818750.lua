-- Lua provided by RyzenAPI
-- Game: MultiVersus

-- MAIN APPLICATION
addappid(1818750)
-- Game: addappid(1818750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818751, 1, "703872d235187bd044d110d6f6a64601e76f407c48822716a2d4e166651caab3")
