-- Lua provided by RyzenAPI
-- Game: 1938630

-- MAIN APPLICATION
addappid(1938630)
-- Game: addappid(1938630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938631, 1, "5b72cbdf4d790f3ac37f177c955793b429d3e91ea4ee17135a39dbadd99d8a69")
