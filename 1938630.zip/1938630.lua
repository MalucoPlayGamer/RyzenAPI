-- Lua provided by RyzenAPI 
-- Game: Training Lucie
addappid(1938630)
addappid(1938631, 1, "5b72cbdf4d790f3ac37f177c955793b429d3e91ea4ee17135a39dbadd99d8a69")
