-- Lua provided by RyzenAPI
-- Game: Infernales

-- MAIN APPLICATION
addappid(705060)

-- MAIN APP DEPOTS / PACKAGES
addappid(705061, 1, "1c5434389a069580e0ead37d5d63074f6d4fc3fd4bf1b69b3f8d2f39096ea4e6")
addappid(750000, 0, "f14590acf64401f4bf19ec2557edfb5d6ce9020b08a1cdd23131a53cbfd631cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
