-- Lua provided by RyzenAPI
-- Game: Infernales

-- MAIN APPLICATION
addappid(705060)

-- MAIN APP DEPOTS / PACKAGES
addappid(705061, 1, "1c5434389a069580e0ead37d5d63074f6d4fc3fd4bf1b69b3f8d2f39096ea4e6")
addappid(750000, 0, "f14590acf64401f4bf19ec2557edfb5d6ce9020b08a1cdd23131a53cbfd631cb")
