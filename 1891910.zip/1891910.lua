-- Lua provided by RyzenAPI
-- Game: CyberCorp Demo

-- MAIN APPLICATION
addappid(1891910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891911, 1, "6e43735e656b09a0e11d1231a0f1179024bd292473792f62ae62b0ce902483dd")

