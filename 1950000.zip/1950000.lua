-- Lua provided by SkyAPI 
-- Game: Merge Cats - Idle Game
addappid(1950000)
addappid(1950001, 1, "3212f63d4cc5378d37c5205143bb7dc7595268273bb339f00fa0322f5dcb9611")
