-- Lua provided by RyzenAPI
-- Game: Merge Cats - Idle Game

-- MAIN APPLICATION
addappid(1950000)
-- Game: addappid(1950000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950001, 1, "3212f63d4cc5378d37c5205143bb7dc7595268273bb339f00fa0322f5dcb9611")
