-- Lua provided by RyzenAPI
-- Game: Waifu Covered 2: Censored Edition

-- MAIN APPLICATION
addappid(1671400)
-- Game: addappid(1671400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671401, 1, "accbf9bd146bf29bb42e51f80ff416bde92a225e47061c7d2557668ab0b700ed")
