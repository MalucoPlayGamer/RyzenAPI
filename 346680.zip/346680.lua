-- Lua provided by RyzenAPI
-- Game: Black Mesa Dedicated Server

-- MAIN APPLICATION
addappid(346680)

-- MAIN APP DEPOTS / PACKAGES
addappid(346681, 1, "8978ead177ef2406d77bf1128f33d35d9796e6ab63903eefa7ee43b3a3a06201")
addappid(346682, 1, "3aa263a5123d02847882a03282e27c4897e2bdbed535aa745d53465329ea1c41")
addappid(346683, 1, "89bd6e3a3f09ed063cefac06eb4f542f877e66bab844d785048dd28aa511fa63")

