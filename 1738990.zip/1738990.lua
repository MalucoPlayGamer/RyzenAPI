-- Lua provided by RyzenAPI
-- Game: addappid(1738990)

-- MAIN APPLICATION
addappid(1738990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738991, 1, "b8fd4ebcf7b6a25e90733e7a1bc47e193e5938d4b491fbd0d580f318c4bc77a5")
