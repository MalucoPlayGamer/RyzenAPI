-- Lua provided by RyzenAPI
-- Game: Game: AppID 591080

-- MAIN APPLICATION
addappid(591080)
-- Game: addappid(591080)

-- MAIN APP DEPOTS / PACKAGES
addappid(591081, 1, "daabb41764a6151ba48094a72d7d29a3c4b19a14c13056092f91b65d218d6ef3")
addappid(591082, 1, "b0a76cf27d4025516742a54eaeb7cc9b9d9fc49c411fb528b3d94e345161de06")
