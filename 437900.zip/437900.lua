-- Lua provided by RyzenAPI
-- Game: AppID 437900

-- MAIN APPLICATION
addappid(437900)
addappid(439450)
addappid(442830)
addappid(451890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(437901, 1, "a35d34b75effa16ee7f54908f268bf05134117e0883ae998d10107a179a8006a")

