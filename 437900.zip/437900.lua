-- Lua provided by SkyAPI 
-- Game: AppID 437900
addappid(437900)
addappid(437901, 1, "a35d34b75effa16ee7f54908f268bf05134117e0883ae998d10107a179a8006a")
