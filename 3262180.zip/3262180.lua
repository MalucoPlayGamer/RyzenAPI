-- Lua provided by RyzenAPI
-- Game: addappid(3262180)

-- MAIN APPLICATION
addappid(3262180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262181, 1, "3f0b3bed03b0cb3ea58bb8a947264112f625cac7876e1908b2909783a78402ec")
addappid(3262182, 1, "489f2a0fe4c6f9a9c854f1de0f661ebf08afa059509b862fd288fab4c9f13ce2")
