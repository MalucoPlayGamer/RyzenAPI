-- Lua provided by RyzenAPI
-- Game: Swarm Grinder

-- MAIN APPLICATION
addappid(1375900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375903,0,"268e9554d8037d1c26519b9403d05aac23d5fe0956606ec85fd20c7d007c14f2")

