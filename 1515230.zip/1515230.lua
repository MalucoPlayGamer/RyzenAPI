-- Lua provided by RyzenAPI
-- Game: LOLLIPOP!

-- MAIN APPLICATION
addappid(1515230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515231, 1, "aa0c77b3418aec5b9ea84171b3125897615e8b6929e82fbbd3c055ce8f1c3fdf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
