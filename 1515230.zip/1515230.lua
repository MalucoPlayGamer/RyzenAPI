-- Lua provided by RyzenAPI
-- Game: addappid(1515230)

-- MAIN APPLICATION
addappid(1515230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515231, 1, "aa0c77b3418aec5b9ea84171b3125897615e8b6929e82fbbd3c055ce8f1c3fdf")
