-- Lua provided by RyzenAPI
-- Game: Game: The Symbiant Re:Union - PG-13 Artbook & CG Pack

-- MAIN APPLICATION
addappid(2758930)
-- Game: addappid(2758930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758931, 1, "35970cd2b0603f242bbc4f9a403830ecaf0028d6254a8412040cd291dcb1e97a")
