-- Lua provided by RyzenAPI
-- Game: addappid(273730)

-- MAIN APPLICATION
addappid(273730)

-- MAIN APP DEPOTS / PACKAGES
addappid(273731, 1, "ede69eed992bbec8754ba70630176041e6e361b0f8496520c163d375a501ad0b")
