-- Lua provided by RyzenAPI 
-- Game: The Upturned
addappid(1717770)
addappid(1717771, 1, "ed2aa6a565d94e82591e81756261c2eafb13d793d3f79983b393f26187fa4b80")
