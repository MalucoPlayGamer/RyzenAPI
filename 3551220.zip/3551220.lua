-- Lua provided by RyzenAPI
-- Game: Chorus of Carcosa  - Digital Artbook

-- MAIN APPLICATION
addappid(3551220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3551220,0,"4906732ccf8d00ff3e0101fd401cc48531c71bc441a5f5bb8425f4cc17e6baaf")
