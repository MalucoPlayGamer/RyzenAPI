-- Lua provided by RyzenAPI
-- Game: 3551220

-- MAIN APPLICATION
addappid(3551220)
-- Game: addappid(3551220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3551220,0,"4906732ccf8d00ff3e0101fd401cc48531c71bc441a5f5bb8425f4cc17e6baaf")
