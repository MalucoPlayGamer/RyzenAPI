-- Lua provided by RyzenAPI 
-- Game: AppID 673840
addappid(673840)
addappid(673841, 1, "6d27f07c891d5f881c87df4247d292b6c924969f03037bc13f2045b1131d81b9")
addappid(673845, 1, "6651731aab9c6f1bb5ae2c623305467ce311c5844b0cba1aeaf427a910ae388b")
