-- Lua provided by RyzenAPI
-- Game: Kao the Kangaroo (2000 re-release)

-- MAIN APPLICATION
addappid(2360020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360021, 1, "204c6d1a4d5b6532ca4ac9568a261f85bd9433c134a10d3393aa071f5a646277")
