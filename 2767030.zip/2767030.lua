-- Lua provided by RyzenAPI
-- Game: Marvel Rivals

-- MAIN APPLICATION
addappid(2767030)
addappid(4406010)
-- Game: addappid(2767030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767031, 1, "6623611cb93523c4cc50d8400d48919b64f55d49dc81a8d6e0695fe740474e42")
