-- Lua provided by RyzenAPI
-- Game: Marvel Rivals

-- MAIN APPLICATION
addappid(2767030)
addappid(4406010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2767031, 1, "6623611cb93523c4cc50d8400d48919b64f55d49dc81a8d6e0695fe740474e42")

