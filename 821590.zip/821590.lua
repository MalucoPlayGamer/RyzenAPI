-- Lua provided by SkyAPI 
-- Game: Octahedron Demo
addappid(821590)
addappid(821591, 1, "a0307873d43556597b5f10024d0b1fc84ad6508d3b31bc0e2823e19bd132f853")
