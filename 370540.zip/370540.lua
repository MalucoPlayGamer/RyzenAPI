-- Lua provided by RyzenAPI
-- Game: AppID 370540

-- MAIN APPLICATION
addappid(370540)
-- Game: addappid(370540)

-- MAIN APP DEPOTS / PACKAGES
addappid(370541, 1, "b0c7e5a97400669c6aea56140780619ea5198e967d92ae4a330ad21a9675a884")
