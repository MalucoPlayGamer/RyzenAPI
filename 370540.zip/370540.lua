-- Lua provided by RyzenAPI
-- Game: Gary Grigsby's War in the East

-- MAIN APPLICATION
addappid(370540)
addappid(381200)
addappid(381201)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(370541, 1, "b0c7e5a97400669c6aea56140780619ea5198e967d92ae4a330ad21a9675a884")

