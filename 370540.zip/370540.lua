-- Lua provided by RyzenAPI 
-- Game: AppID 370540
addappid(370540)
addappid(370541, 1, "b0c7e5a97400669c6aea56140780619ea5198e967d92ae4a330ad21a9675a884")
