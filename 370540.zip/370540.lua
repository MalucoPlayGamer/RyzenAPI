-- Lua provided by RyzenAPI
-- Game: AppID 370540

-- MAIN APPLICATION
addappid(370540)

-- MAIN APP DEPOTS / PACKAGES
addappid(370541, 1, "b0c7e5a97400669c6aea56140780619ea5198e967d92ae4a330ad21a9675a884")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(381200)
addappid(381201)
