-- Lua provided by RyzenAPI
-- Game: Hit n' Rush

-- MAIN APPLICATION
addappid(1036340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1036341, 1, "e4e98d103c4d3cee164ef60a85a91998368c20b7301e2f6abc500b389339e194")
