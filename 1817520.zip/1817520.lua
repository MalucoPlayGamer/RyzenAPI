-- Lua provided by SkyAPI 
-- Game: AppID 1817520
addappid(1817520)
addappid(1817521, 1, "0f19017d071fb4df225b2c85a40d0ce1f1a7b6182107e70a2dc5632d159e6927")
