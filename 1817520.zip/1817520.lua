-- Lua provided by RyzenAPI
-- Game: 1817520

-- MAIN APPLICATION
addappid(1817520)
-- Game: addappid(1817520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817521, 1, "0f19017d071fb4df225b2c85a40d0ce1f1a7b6182107e70a2dc5632d159e6927")
