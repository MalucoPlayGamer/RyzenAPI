-- Lua provided by RyzenAPI
-- Game: Desert Golfing

-- MAIN APPLICATION
addappid(757040)

-- MAIN APP DEPOTS / PACKAGES
addappid(757041,0,"523c92d1c98cc59d787c65dbc26d1e902d19cbecafe02418f2d086d9389b9d1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
