-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails into Reverie - Soundtrack Sampler

-- MAIN APPLICATION
addappid(2434471)
-- Game: addappid(2434471)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434471,0,"7b854dbb5f59c2bbf1220f422542fa6b0914fd3986823ae4fb8d67e4dc30b811")
addappid(2493800,0,"2daa0cdca3a82732890afdeb3b62506de737dbba30d9c9acfa10839effe744c4")
