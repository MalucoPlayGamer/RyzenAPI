-- Lua provided by SkyAPI 
-- Game: LoveKami -Divinity Stage- Original Soundtrack
addappid(579510)
addappid(579511, 1, "981e902f2ad853a5bbd15241d45387c65ef8e3d23b1278fa660101f13d9c9e44")
addappid(579512, 1, "4a0393f92c216bd4d813f6b5972a9821160508f7d423388d7f9d4445a15d02f3")
