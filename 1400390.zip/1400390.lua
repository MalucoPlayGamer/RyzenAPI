-- Lua provided by RyzenAPI
-- Game: The First Confrontation

-- MAIN APPLICATION
addappid(1400390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400391, 1, "4a8d9f69451691018b66e52c6abdb7c35fe374b8f1d27fcd7da21c3a5245de2f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1400400)
