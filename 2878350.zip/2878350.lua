-- Lua provided by RyzenAPI
-- Game: Save from Bobr Curve

-- MAIN APPLICATION
addappid(2878350)
-- Game: addappid(2878350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878351, 1, "058c9c6733b0a77fcbb9bb0d0bea9a94580b99f702368851631650ff35d8505a")
