-- Lua provided by SkyAPI 
-- Game: iLLANG
addappid(2747110)
addappid(2747111, 1, "b07085293998c9ff013112be6578297f126b1974bec7af52b1985b993df94187")
