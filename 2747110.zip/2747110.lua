-- Lua provided by RyzenAPI
-- Game: Game: iLLANG

-- MAIN APPLICATION
addappid(2747110)
-- Game: addappid(2747110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747111, 1, "b07085293998c9ff013112be6578297f126b1974bec7af52b1985b993df94187")
