-- Lua provided by RyzenAPI
-- Game: addappid(916180)

-- MAIN APPLICATION
addappid(916180)

-- MAIN APP DEPOTS / PACKAGES
addappid(916181, 1, "75d307babb711f2b61ad24ec4530995baccd07da60c7a031b86cf50d936f550e")
