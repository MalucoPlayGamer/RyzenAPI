-- Lua provided by RyzenAPI
-- Game: Evil Sinister

-- MAIN APPLICATION
addappid(2892470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892471, 1, "a5e0a1ad74c6be9ec5b49fd48cbf19a75d26f4bc897edaec9e46d29bcffa9ef2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
