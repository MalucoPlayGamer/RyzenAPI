-- Lua provided by RyzenAPI
-- Game: addappid(2892470)

-- MAIN APPLICATION
addappid(2892470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892471, 1, "a5e0a1ad74c6be9ec5b49fd48cbf19a75d26f4bc897edaec9e46d29bcffa9ef2")
