-- Lua provided by RyzenAPI
-- Game: Plant Nursery Simulator

-- MAIN APPLICATION
addappid(3474700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3474701, 1, "4075e8cc2f8919127e8577261cdccc920ac14117f9cabb0054217028886ca4ca")
