-- Lua provided by RyzenAPI
-- Game: Disease Z - Zombie City Demo

-- MAIN APPLICATION
addappid(2424750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424751, 1, "1063dc223f76a244578342df131f355ca2232adefe53d034282c19aff082b739")
