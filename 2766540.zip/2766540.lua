-- Lua provided by RyzenAPI
-- Game: Game: ELECTROBASIS

-- MAIN APPLICATION
addappid(2766540)
addappid(2882120)
-- Game: addappid(2766540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766541, 1, "cdca05d8830a8ae37c8357f76ced967ce1903f992878c8b97c5ed22b390c3eae")
