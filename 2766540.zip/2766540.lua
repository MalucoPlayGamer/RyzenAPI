-- Lua provided by RyzenAPI
-- Game: ELECTROBASIS

-- MAIN APPLICATION
addappid(2766540)
addappid(2882120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766541, 1, "cdca05d8830a8ae37c8357f76ced967ce1903f992878c8b97c5ed22b390c3eae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
