-- Lua provided by RyzenAPI
-- Game: Root Letter Last Answer

-- MAIN APPLICATION
addappid(1056510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056511, 1, "65ba47d8bd7b47fec2e23a9591f7f4b989bf37b86b79eb3a027c379b3177d8b6")
addappid(1056512, 1, "3714f76b930176c841ca5842e49d9e6756b5bf5ac2e63a639615172fc3f9b7e5")
addappid(1056513, 1, "31855df97bae50e3bf21d1c087faac64cc73fca8ce4dcddbcd7efdff92af29a2")

