-- Lua provided by SkyAPI 
-- Game: Goo Goo Grapplers
addappid(3316660)
addappid(3316661, 1, "a0b790dc06775009384457a4e37f14e92ac0f51029efbf5b447e2848a6908b9c")
