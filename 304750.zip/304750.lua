-- Lua provided by RyzenAPI
-- Game: addappid(304750)

-- MAIN APPLICATION
addappid(304750)

-- MAIN APP DEPOTS / PACKAGES
addappid(304751, 1, "91cff3537f8f00c5cdc1da55df8d910e666eb3e37ba6804e1a01c4e21a30f601")
