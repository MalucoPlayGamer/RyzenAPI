-- Lua provided by RyzenAPI
-- Game: addappid(253690)

-- MAIN APPLICATION
addappid(253690)

-- MAIN APP DEPOTS / PACKAGES
addappid(253691, 1, "94b43cee1b13694f4b0bb9f6c4d20ada6628b29caf3c5f1ad6070f76adbf4387")
