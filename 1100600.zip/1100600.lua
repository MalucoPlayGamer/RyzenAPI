-- Lua provided by RyzenAPI
-- Game: Game: AppID 1100600

-- MAIN APPLICATION
addappid(1100600)
-- Game: addappid(1100600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100601, 1, "b1f488b77d6c24b132a67ceccaa83de97bc9d3634ab47705653a2929f4cdc936")
addappid(1100602, 1, "14c06b112fd03d30ae10c18c2fa8986e61ef78d1ebb1bfa6b6ddc42dabe1a588")
addappid(1100603, 1, "9f14d61a5fe8a988a23b5e2087c4052c24da0aaef9464dc6bc3182be522a1f13")
