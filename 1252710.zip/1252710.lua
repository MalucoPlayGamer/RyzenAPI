-- Lua provided by RyzenAPI
-- Game: Cardaclysm

-- MAIN APPLICATION
addappid(1252710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252711, 1, "1f0531fa3d12dd610a715e166c10796538d5ff2440a5605ef019fa20ea829263")

