-- Lua provided by RyzenAPI
-- Game: Summer Catchers Demo

-- MAIN APPLICATION
addappid(1101410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101412,0,"77ea482fd75c656e389eadc71d19322b547e5fb8131f1132770ca9b8d0332333")

