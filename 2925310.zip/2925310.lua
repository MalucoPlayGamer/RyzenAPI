-- Lua provided by RyzenAPI
-- Game: addappid(2925310)

-- MAIN APPLICATION
addappid(2925310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925311, 1, "0bafd772aae347621c3a14e865ba6de8d99e89ab600eea9148ed6fa13a0475cc")
