-- Lua provided by RyzenAPI
-- Game: BLACK CLOVER: QUARTET KNIGHTS

-- MAIN APPLICATION
addappid(714080)
addappid(907230)
addappid(921480)
addappid(921481)
addappid(921482)
addappid(921483)
addappid(921484)
addappid(921485)
addappid(921486)
addappid(921487)
addappid(921488)
addappid(921489)
addappid(938770)
addappid(997160)
addappid(997163)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(714081,0,"0e7d842486cc47d078f5476da28441d25a1db988ed95c69c3c8f70af35db9551")

