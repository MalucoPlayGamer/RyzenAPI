-- Lua provided by RyzenAPI
-- Game: addappid(714080)

-- MAIN APPLICATION
addappid(714080)

-- MAIN APP DEPOTS / PACKAGES
addappid(714081, 1, "0e7d842486cc47d078f5476da28441d25a1db988ed95c69c3c8f70af35db9551")
