-- Lua provided by RyzenAPI
-- Game: Massive Effect

-- MAIN APPLICATION
addappid(1043360)
-- Game: addappid(1043360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043361, 1, "dc42b052195797ad36ad05dcd5882799ffa10968eb23b020f1d86241c4322845")
