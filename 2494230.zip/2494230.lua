-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2494230)
-- Game: addappid(2494230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494230,0,"d136683c9a9576398983a74ffcac9bafe750915d1376beb4a2653f63e1bf1c9c")
