-- Lua provided by SkyAPI 
-- Game: Carnage Cuisine
addappid(2386560)
addappid(2386561, 1, "4e1b7fb388ae0c2c53fd19d21c60b9db9c5bd409333f665bfb3bfe73dd6f8e50")
