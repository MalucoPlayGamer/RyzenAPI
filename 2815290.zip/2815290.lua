-- Lua provided by RyzenAPI 
-- Game: The Sims™ 4 Life & Death Expansion Pack
addappid(2815290)
addappid(2815291, 1, "cc1bb9046ec0c6620ed042a9bca4f123e1d4112739ef63f0078f2873d3cd56fd")
addappid(2815293, 1, "4ecb48afeab9ae3deb9b928ee4ead5f641ba8a0059a5d160a5137e275c7c3056")
addappid(2815297, 1, "6c4ab2a78baac554d707f33bd46f3c5a86edd9da064e680dbbda6b492b3975a7")
addappid(2815298, 1, "ea9022bed7a97dcaeee189af9fc55715f988d8bd39f8c558c8599f0d60abc2cb")
addappid(3052081, 0, "52275152d81670eacdc07994269d4691e36fc3ca43b09fdf7995f8473d355bbf")
addappid(3052088, 0, "a1199cab52304fe2e809472f9733f2b0f2b7d484e8be754b4ef252ac4970a4ab")
