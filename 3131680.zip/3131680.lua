-- Lua provided by RyzenAPI
-- Game: addappid(3131680)

-- MAIN APPLICATION
addappid(3131680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131681, 1, "fdfcb50336600c43ec6da7c73fa47f784aaa9f2805fb108f6d8273264e188d92")
