-- Lua provided by RyzenAPI
-- Game: Game: Warpips - Soundtrack

-- MAIN APPLICATION
addappid(1619140)
-- Game: addappid(1619140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619141, 1, "4cef2743791db361d59e3062570b35211ae4908e231592aa36715d2962689c00")
addappid(1619142, 1, "4ee26fe10bbd506e1bc5409ae682ec87a132ae8a2d168c4e0df8f9a596021339")
