-- Lua provided by RyzenAPI
-- Game: Revenge of the Savage Planet

-- MAIN APPLICATION
addappid(3482310)
addappid(3482320) -- Revenge of the Savage Planet - Raccoon Suit
addappid(3482330) -- Revenge of the Savage Planet - HR Enforcer Suit
addappid(3482340) -- Revenge of the Savage Planet - Deluxe Edition Quests
addappid(3654280) -- The Cosmic Hoarder Upgrade
addappid(3934430) -- Revenge of the Savage Planet - Deluxe Charity Edition
addappid(3986890) -- Revenge of the Savage Planet - Remix Mode
addappid(4141000) -- Revenge of the Savage Planet - Bingo Brawl

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2787320, 1, "bb48a4e1ddc9a2b95436b7eb8880503d3a8029343b90df4023e80c722a1d214e")
addappid(2787321, 1, "07fdf2268a8c0b6b8d7dd4c5d7978e054ce837759193f7f5cacd2968150199a7") -- (windows)
addappid(3482311, 1, "ecf76b3f40656549d3b5e12e0ab1d6b9cfb6aabeb3836faf663b7d0008efaddb") -- (64-bit)

