-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Warriors"

-- MAIN APPLICATION
addappid(1099584)
-- Game: addappid(1099584)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099584,0,"c65cc4cbfb6e115114eda75937ee6a28a23646f9957f18d31392b71de3388247")
