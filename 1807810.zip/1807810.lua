-- Lua provided by RyzenAPI
-- Game: Game: The Axis Unseen

-- MAIN APPLICATION
addappid(1807810)
-- Game: addappid(1807810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807811, 1, "4135eb4fbb0382638a520149b5584c6e2205085136f341d8984084fe431dd900")
