-- Lua provided by RyzenAPI
-- Game: addappid(1975340)

-- MAIN APPLICATION
addappid(1975340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975342,0,"3d58d47fe47630007b23b09bb0ff7f3c3343cdafe77b3ef0097013e6da380923")
addappid(1975343,0,"2a6b75b879532054ecae7e7ef5e64bd8a09566ac773bceaa9aabb873b3e5b4d2")
