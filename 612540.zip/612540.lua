-- Lua provided by RyzenAPI
-- Game: Sudden Strike 3

-- MAIN APPLICATION
addappid(612540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(612541, 1, "8c67b569a5be4e053d0a87b7f8f751f562971bfed80edb551849b65beb34ffde")

