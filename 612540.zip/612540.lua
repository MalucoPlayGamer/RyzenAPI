-- Lua provided by RyzenAPI
-- Game: AppID 612540

-- MAIN APPLICATION
addappid(612540)

-- MAIN APP DEPOTS / PACKAGES
addappid(612541, 1, "8c67b569a5be4e053d0a87b7f8f751f562971bfed80edb551849b65beb34ffde")
