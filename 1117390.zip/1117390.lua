-- Lua provided by RyzenAPI
-- Game: 1117390

-- MAIN APPLICATION
addappid(1117390)
-- Game: addappid(1117390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117391, 1, "2ea5ed807f453bd0071fd745d1907c4aeee7fc36b636f3a9b55cf1b8b3da507c")
