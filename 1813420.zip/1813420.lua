-- Lua provided by RyzenAPI 
-- Game: The Perdition Man: Interval
addappid(1813420)
addappid(1813421, 1, "59eb17026f5ae37594910fb6a184952095a227c0d4491474c3960d624c4414b3")
