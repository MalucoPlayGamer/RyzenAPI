-- Lua provided by RyzenAPI
-- Game: Game: The Perdition Man: Interval

-- MAIN APPLICATION
addappid(1813420)
-- Game: addappid(1813420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813421, 1, "59eb17026f5ae37594910fb6a184952095a227c0d4491474c3960d624c4414b3")
