-- Lua provided by RyzenAPI
-- Game: Soundfall

-- MAIN APPLICATION
addappid(1608700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608701, 1, "a3d1fa7ed364d9d87f8fcfbb416fda02530461728993ae6d1682344c6d1cd897")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
