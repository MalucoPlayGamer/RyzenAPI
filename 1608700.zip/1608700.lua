-- Lua provided by RyzenAPI
-- Game: Soundfall

-- MAIN APPLICATION
addappid(1608700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608701, 1, "a3d1fa7ed364d9d87f8fcfbb416fda02530461728993ae6d1682344c6d1cd897")
