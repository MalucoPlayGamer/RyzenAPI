-- Lua provided by RyzenAPI
-- Game: The Pioneers: Surviving Desolation

-- MAIN APPLICATION
addappid(1734390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734391, 1, "624c03125ad799842d9e65e3658dee4b420c66aaa8640232486e2ba1288e6fc9")
