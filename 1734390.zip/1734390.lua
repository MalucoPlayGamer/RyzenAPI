-- Lua provided by SkyAPI 
-- Game: The Pioneers: Surviving Desolation
addappid(1734390)
addappid(1734391, 1, "624c03125ad799842d9e65e3658dee4b420c66aaa8640232486e2ba1288e6fc9")
