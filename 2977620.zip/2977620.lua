-- Lua provided by RyzenAPI
-- Game: Squirreled Away

-- MAIN APPLICATION
addappid(2977620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977621, 1, "9b2b59462dabe462d78e6bac46a35a2fe6c511f9e3a73275388da29b1900901a")
