-- Lua provided by RyzenAPI
-- Game: Squirreled Away

-- MAIN APPLICATION
addappid(2977620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2977621, 1, "9b2b59462dabe462d78e6bac46a35a2fe6c511f9e3a73275388da29b1900901a")

