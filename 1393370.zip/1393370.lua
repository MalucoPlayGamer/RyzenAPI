-- Lua provided by RyzenAPI
-- Game: Actraiser Renaissance

-- MAIN APPLICATION
addappid(1393370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393371, 1, "7a98a5fa7cc13242e8d9d3b4f77a9c779ad772459ef51f3737ff5fa862d03494")
addappid(1769080, 0, "4b3ca6dcf14a393003d618a26435d68e05e67e18d27119481db4674c28857a2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
