-- Lua provided by RyzenAPI 
-- Game: Actraiser Renaissance
addappid(1393370)
addappid(1393371, 1, "7a98a5fa7cc13242e8d9d3b4f77a9c779ad772459ef51f3737ff5fa862d03494")
addappid(1769080, 0, "4b3ca6dcf14a393003d618a26435d68e05e67e18d27119481db4674c28857a2a")
