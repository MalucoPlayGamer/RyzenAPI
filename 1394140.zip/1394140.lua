-- Lua provided by SkyAPI 
-- Game: AppID 1394140
addappid(1394140)
addappid(1394141, 1, "b9e90dcd6623f066e66d27d4ed3fad6000c47abc29b9995706fa2cfd30c67101")
