-- Lua provided by RyzenAPI
-- Game: You Can Pet The Dog VR

-- MAIN APPLICATION
addappid(1394140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394141, 1, "b9e90dcd6623f066e66d27d4ed3fad6000c47abc29b9995706fa2cfd30c67101")

