-- Lua provided by RyzenAPI
-- Game: addappid(2620420)

-- MAIN APPLICATION
addappid(2620420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620421, 1, "f483e761a533b7f20474eed6f8b078edf69d77b9dd5096daf8ec8a7f90f717ed")
