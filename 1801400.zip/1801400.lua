-- Lua provided by RyzenAPI
-- Game: Fallen Guns

-- MAIN APPLICATION
addappid(1801400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801401, 1, "aa6b4c76e2883e65497a3a57c67b30c250e0e7ff3c025e91e637db3a24bb2073")
