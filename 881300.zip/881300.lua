-- Lua provided by RyzenAPI
-- Game: Arboreal

-- MAIN APPLICATION
addappid(881300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(881301, 1, "b8d16ac919083b37d6928103d16e1089d64bed4baa5cc0c8bc320465b95fabb5")

