-- Lua provided by RyzenAPI 
-- Game: Arboreal
addappid(881300)
addappid(881301, 1, "b8d16ac919083b37d6928103d16e1089d64bed4baa5cc0c8bc320465b95fabb5")
