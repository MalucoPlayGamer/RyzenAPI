-- Lua provided by RyzenAPI
-- Game: AppID 2326470

-- MAIN APPLICATION
addappid(2326470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326471, 1, "99de1fe7e8bcfeae29f79cf510b6c7df54a868144600061a99b46ccaa3c3dae2")

