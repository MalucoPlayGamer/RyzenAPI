-- Lua provided by RyzenAPI
-- Game: World Of Undead

-- MAIN APPLICATION
addappid(454730)

-- MAIN APP DEPOTS / PACKAGES
addappid(454731, 1, "28cddc714a0514206a3dd8bdfad4adf7f8e6d81025750572311cfd2d24c63983")

