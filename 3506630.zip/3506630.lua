-- Lua provided by SkyAPI 
-- Game: Thin Threads
addappid(3506630)
addappid(3506631, 1, "bcdd4f07de7ca9a228c42df707204f13f396d32a3f7e6f8f59b8f625f6310371")
