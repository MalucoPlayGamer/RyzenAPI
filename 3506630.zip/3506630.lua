-- Lua provided by RyzenAPI
-- Game: Game: Thin Threads

-- MAIN APPLICATION
addappid(3506630)
-- Game: addappid(3506630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3506631, 1, "bcdd4f07de7ca9a228c42df707204f13f396d32a3f7e6f8f59b8f625f6310371")
