-- Lua provided by RyzenAPI
-- Game: FunkyMouse's ISO

-- MAIN APPLICATION
addappid(3152530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3152531, 1, "271751f677895c0fb1691a21780f63a715b28d31df83ac3529766e67f4519f30")

