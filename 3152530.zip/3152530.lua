-- Lua provided by SkyAPI 
-- Game: FunkyMouse's ISO
addappid(3152530)
addappid(3152531, 1, "271751f677895c0fb1691a21780f63a715b28d31df83ac3529766e67f4519f30")
