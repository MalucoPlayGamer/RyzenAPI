-- Lua provided by RyzenAPI
-- Game: 2574680

-- MAIN APPLICATION
addappid(2574680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574682,0,"baaa663d961cd59894212cd26fbeadfa197f0041bbc6d1f244f225f80a22ea5b")
