-- Lua provided by RyzenAPI
-- Game: Game: AppID 1383030

-- MAIN APPLICATION
addappid(1383030)
-- Game: addappid(1383030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383031, 1, "37ae6ce3c01704ec6052d2e9d27203107d43cbec8d1f8eaf2f05f1033aaf847b")
