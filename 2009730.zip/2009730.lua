-- Lua provided by SkyAPI 
-- Game: Meat & Greed
addappid(2009730)
addappid(2009731, 1, "8139204e6307307c9e9af1aea2b72102ad341b1ea6aa887c00355e9fe208ff6c")
