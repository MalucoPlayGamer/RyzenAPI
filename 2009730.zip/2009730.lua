-- Lua provided by RyzenAPI
-- Game: Game: Meat & Greed

-- MAIN APPLICATION
addappid(2009730)
-- Game: addappid(2009730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009731, 1, "8139204e6307307c9e9af1aea2b72102ad341b1ea6aa887c00355e9fe208ff6c")
