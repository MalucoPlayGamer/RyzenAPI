-- Lua provided by RyzenAPI
-- Game: Meat & Greed

-- MAIN APPLICATION
addappid(2009730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009731, 1, "8139204e6307307c9e9af1aea2b72102ad341b1ea6aa887c00355e9fe208ff6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
