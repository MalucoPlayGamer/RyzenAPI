-- Lua provided by RyzenAPI
-- Game: Railroad Pioneer

-- MAIN APPLICATION
addappid(306490)
-- Game: addappid(306490)

-- MAIN APP DEPOTS / PACKAGES
addappid(306491, 1, "249d18c34b00c7c4c0f4dd6d18dd6912bf8f8495f5d3d9562547dfe40607c152")
addappid(306492, 1, "92b41a29e824cee005ccc9ec7bfa5e6407d0e628220243c4d02ef43404767f54")
addappid(306493, 1, "9e624adda624e108b430d09970d06ddd2c9df8da0121933b7cd2a5b1c87045e7")
addappid(306494, 1, "f73dab516c92b8acc13e27639de6447aa747576785774f7e46c9b34c195ab9da")
