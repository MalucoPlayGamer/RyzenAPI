-- Lua provided by RyzenAPI
-- Game: Virginia

-- MAIN APPLICATION
addappid(374030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(374031, 1, "06287920b6bc8a022ab72c2858e187e6b44e963049b7d7e48f00ccdbd384ec3c")
addappid(374032, 1, "ddc01644393bf8d39ecc52324db31f170660515357b7a507abd0fdfd15015c7a")
