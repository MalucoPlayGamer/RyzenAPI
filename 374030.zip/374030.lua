-- Lua provided by RyzenAPI
-- Game: 374030

-- MAIN APPLICATION
addappid(374030)
-- Game: addappid(374030)

-- MAIN APP DEPOTS / PACKAGES
addappid(374031, 1, "06287920b6bc8a022ab72c2858e187e6b44e963049b7d7e48f00ccdbd384ec3c")
addappid(374032, 1, "ddc01644393bf8d39ecc52324db31f170660515357b7a507abd0fdfd15015c7a")
