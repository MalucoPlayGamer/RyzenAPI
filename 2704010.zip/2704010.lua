-- Lua provided by RyzenAPI 
-- Game: AppID 2704010
addappid(2704010)
addappid(2704011, 1, "d1bde44c6254bfea480d8604c52c890aec416ab0b82a9743e67f6e7644f28a40")
addappid(2704012, 1, "a80f6fa5a5359776cde1fa866a2d7ce4588c4e58a1f6fa2728d28c620945440d")
