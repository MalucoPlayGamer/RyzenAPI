-- Lua provided by RyzenAPI
-- Game: Game: Nephise Begins

-- MAIN APPLICATION
addappid(628950)
-- Game: addappid(628950)

-- MAIN APP DEPOTS / PACKAGES
addappid(628951, 1, "4c618715277dbab61302761ed03ad624f808909b4fe1fdd25bcabcd932b06fa1")
