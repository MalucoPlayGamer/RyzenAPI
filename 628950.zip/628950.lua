-- Lua provided by SkyAPI 
-- Game: Nephise Begins
addappid(628950)
addappid(628951, 1, "4c618715277dbab61302761ed03ad624f808909b4fe1fdd25bcabcd932b06fa1")
