-- Lua provided by RyzenAPI
-- Game: Mining Copper

-- MAIN APPLICATION
addappid(2197500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197501, 1, "781166feddc5490ddb12d7efd63acb48697e940748ff985e190d531ca1ff490b")
