-- Lua provided by RyzenAPI
-- Game: Contract Killer

-- MAIN APPLICATION
addappid(1588250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588251, 1, "c74333951eb6273ec1ca78dbcb0b8b69a96181e0d81addffbd2b58193f1165b7")
