-- Lua provided by RyzenAPI 
-- Game: Warhammer Quest: Silver Tower
addappid(1584980)
addappid(1584981, 1, "a8fbf8058869fd982a1c5f289240ca21deb8cab6c07dd9736b8e6a3b0e965b78")
