-- Lua provided by RyzenAPI
-- Game: Game: Card City Nights

-- MAIN APPLICATION
addappid(271820)
-- Game: addappid(271820)

-- MAIN APP DEPOTS / PACKAGES
addappid(271821, 1, "ce54df2723a63b0ba01eebd5ac5eb30f7ed86d31f13a9d72f42cb66196d02f56")
addappid(271822, 1, "eb906dcfb3b3a8d226e3d34910c39164b86d2a264d2d5f5216873dbcb901bd51")
addappid(271823, 1, "03e4e1918dcdab942615d574403557b4d8952e59c243325fda98950535d39ddc")
