-- Lua provided by RyzenAPI
-- Game: Game: Keep It Running

-- MAIN APPLICATION
addappid(2863530)
-- Game: addappid(2863530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863531, 1, "84231dd3d89462336b443f8ba58099e3318b405e2936938d1697ce3bb08c5e82")
