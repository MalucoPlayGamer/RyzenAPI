-- Lua provided by RyzenAPI
-- Game: Hope of humanity

-- MAIN APPLICATION
addappid(868710)
addappid(1219660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(868711, 1, "a31860c25f90d055621e4828798c23130be2e5f8999cf21dfc595c9f84a2671e")
addappid(868712, 1, "da82f87e7acf42132d742d19f48bc8871cef8ef11dff0ec16762ee1473464f90")
addappid(868713, 1, "b29fcaeb5a9679f83bc6811f043358c5e53dbcaf4fc9b061b8467a4373ecdd25")
addappid(868714, 1, "bd6c5e9b88e9663f1c04808ab7e4f37be22d00c9cd956e12941eaaa70b83f736")
