-- Lua provided by RyzenAPI
-- Game: addappid(1543320)

-- MAIN APPLICATION
addappid(1543320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543321, 1, "0e955491f5d5758d01da05e7fd510cf3e78df519ad8c969c402661f501923cd2")
