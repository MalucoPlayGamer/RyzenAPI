-- Lua provided by RyzenAPI
-- Game: 3187520

-- MAIN APPLICATION
addappid(3187520)
-- Game: addappid(3187520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3187521, 1, "a03bbda95f82e250d00960b3eac776adf58e98c91e29e1f63cd1a6faae917ae0")
