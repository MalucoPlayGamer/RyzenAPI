-- Lua provided by RyzenAPI 
-- Game: Escape Machines
addappid(363490)
addappid(363491, 1, "7bb1f141db4fa7921f77a8f77f67a9f5d2dc80220d17eda7b635dc05bda79184")
