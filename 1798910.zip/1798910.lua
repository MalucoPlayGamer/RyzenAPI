-- Lua provided by RyzenAPI
-- Game: Peril by MDE

-- MAIN APPLICATION
addappid(1798910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1798911, 1, "7b1029e735a56e52b426a0b59fe66346685c94d1a295f6dfc6e6e7f63d0a3ac8")

