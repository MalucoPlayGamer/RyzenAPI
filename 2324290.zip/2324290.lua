-- Lua provided by RyzenAPI
-- Game: PAC-MAN WORLD 2 Re-PAC

-- MAIN APPLICATION
addappid(2324290)
addappid(3340420)
addappid(3340430)
addappid(3810940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324291, 1, "aa6abdfd89c3a5ab5bd39204a72f8eee90db311535794b1c01f5dfac9fe58998")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3340410)
