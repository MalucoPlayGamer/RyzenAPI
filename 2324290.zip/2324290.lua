-- Lua provided by RyzenAPI
-- Game: Game: PAC-MAN WORLD 2 Re-PAC

-- MAIN APPLICATION
addappid(2324290)
addappid(3340420)
addappid(3340430)
addappid(3810940)
-- Game: addappid(2324290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324291, 1, "aa6abdfd89c3a5ab5bd39204a72f8eee90db311535794b1c01f5dfac9fe58998")
