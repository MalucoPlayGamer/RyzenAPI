-- Lua provided by RyzenAPI
-- Game: AppID 579110

-- MAIN APPLICATION
addappid(579110)

-- MAIN APP DEPOTS / PACKAGES
addappid(579111, 1, "5e46d74980e013abb9ea1bd2796982eefd58d826efbd9225280ecd23dbd90ba7")
