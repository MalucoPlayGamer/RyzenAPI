-- Lua provided by RyzenAPI
-- Game: Game: Super Mega Baseball™ 4

-- MAIN APPLICATION
addappid(1487210)
-- Game: addappid(1487210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487211, 1, "e619dbfe27bf6848767a9fed807708a87514e5db6c29c011458ed4c8f80d3a7d")
