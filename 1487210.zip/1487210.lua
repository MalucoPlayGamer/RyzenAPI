-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball™ 4

-- MAIN APPLICATION
addappid(1487210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487211, 1, "e619dbfe27bf6848767a9fed807708a87514e5db6c29c011458ed4c8f80d3a7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2378180)
addappid(2378181)
addappid(2378182)
