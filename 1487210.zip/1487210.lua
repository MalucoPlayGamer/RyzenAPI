-- Lua provided by RyzenAPI 
-- Game: Super Mega Baseball™ 4
addappid(1487210)
addappid(1487211, 1, "e619dbfe27bf6848767a9fed807708a87514e5db6c29c011458ed4c8f80d3a7d")
