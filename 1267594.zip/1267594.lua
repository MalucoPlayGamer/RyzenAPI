-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1267594)
-- Game: addappid(1267594)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267594,0,"c1236da8709c73531b973df64370fd633e7a0fba5b6268620f58cfc61114075f")
