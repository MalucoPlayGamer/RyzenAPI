-- Lua provided by RyzenAPI 
-- Game: AppID 2485750
addappid(2485750)
addappid(2485751, 1, "8f909b21ba7ab0009fffe32570b9c3c00c1090c7c731b7b54ad67ef8b1ef15de")
