-- Lua provided by RyzenAPI
-- Game: Midnight Scenes: A Safe Place

-- MAIN APPLICATION
addappid(2485750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485751, 1, "8f909b21ba7ab0009fffe32570b9c3c00c1090c7c731b7b54ad67ef8b1ef15de")

