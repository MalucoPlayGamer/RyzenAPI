-- Lua provided by RyzenAPI
-- Game: Ellentis

-- MAIN APPLICATION
addappid(3586740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586741, 1, "4f834504c680c0bd12c966372256d49e78daad317816bced0a2f43d214f83e10")

