-- Lua provided by SkyAPI 
-- Game: Infection
addappid(1203850)
addappid(1203851, 1, "b55fe9d63d340c98f04cc8b062fe91639b0ad6e1d2ea0183055369db14c7f594")
