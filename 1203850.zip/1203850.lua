-- Lua provided by RyzenAPI
-- Game: Infection

-- MAIN APPLICATION
addappid(1203850)
-- Game: addappid(1203850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203851, 1, "b55fe9d63d340c98f04cc8b062fe91639b0ad6e1d2ea0183055369db14c7f594")
