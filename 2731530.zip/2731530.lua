-- Lua provided by RyzenAPI 
-- Game: Karina Katana
addappid(2731530)
addappid(2731531, 1, "71c041a49b7bb9f33ed30f9223a3968d169b7faa0bbcdfea80b03d527fb3c201")
