-- Lua provided by RyzenAPI
-- Game: addappid(300060)

-- MAIN APPLICATION
addappid(300060)

-- MAIN APP DEPOTS / PACKAGES
addappid(300061, 1, "2b7297b6586e386f958ffdd7ee684f2db9d88aa9ecec0eefb31a9e24797f6c5a")
