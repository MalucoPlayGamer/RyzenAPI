-- Lua provided by RyzenAPI
-- Game: Hex Harmony

-- MAIN APPLICATION
addappid(4491420) -- Hex Harmony

-- MAIN APP DEPOTS / PACKAGES
addappid(4491421, 1, "5ab12477eb68a58bf3eb002cc50a8170c3ce9d8369490a5420e53753c8e701fd") -- Depot 4491421

