-- 4491420's Lua and Manifest Created by Hubcap Manifest
-- Hex Harmony
-- Created: August 06, 2026 at 11:24:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4491420) -- Hex Harmony
-- MAIN APP DEPOTS
addappid(4491421, 1, "5ab12477eb68a58bf3eb002cc50a8170c3ce9d8369490a5420e53753c8e701fd") -- Depot 4491421
setManifestid(4491421, "2845660374307181090", 324684855)