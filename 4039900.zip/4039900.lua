-- Lua provided by RyzenAPI
-- Game: ZOMBUTCHER

-- MAIN APPLICATION
addappid(4039900)

-- MAIN APP DEPOTS / PACKAGES
addappid(4039901,0,"8ecde09923727d9747f95e819de663a4d465ab2351429357b4b928dd82557f17")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
