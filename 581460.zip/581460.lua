-- Lua provided by RyzenAPI
-- Game: QuiVr Vanguard

-- MAIN APPLICATION
addappid(581460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(581461, 1, "935ef491465ee3f1b97da4fa7531424e28ed6b1217c8f5dbd9ed178dcc330aa4")

