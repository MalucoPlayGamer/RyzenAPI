-- Lua provided by RyzenAPI
-- Game: CODE VEIN II

-- MAIN APPLICATION
addappid(2362060)
addappid(3559210)
addappid(3559230)
addappid(3559240)
addappid(3559250)
addappid(3559260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362061, 1, "b01b93b4fd055fc2f23e77e6797ee933d5d83fbb293cf55442e567407723aa4b")

