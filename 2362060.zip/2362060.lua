-- Lua provided by SkyAPI 
-- Game: CODE VEIN II
addappid(2362060)
addappid(2362061, 1, "b01b93b4fd055fc2f23e77e6797ee933d5d83fbb293cf55442e567407723aa4b")
addappid(3559210)
addappid(3559230)
addappid(3559240)
addappid(3559250)
addappid(3559260)
