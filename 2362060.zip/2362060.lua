-- Lua provided by RyzenAPI
-- Game: CODE VEIN II

-- MAIN APPLICATION
addappid(2362060)
addappid(3559210)
addappid(3559230)
addappid(3559240)
addappid(3559250)
addappid(3559260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362061, 1, "b01b93b4fd055fc2f23e77e6797ee933d5d83fbb293cf55442e567407723aa4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
