-- Lua provided by RyzenAPI
-- Game: Game: 子归 - Blossom

-- MAIN APPLICATION
addappid(2579280)
-- Game: addappid(2579280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579281, 1, "9e5682519bd92613a6d8521b3e6b9e5871703733d2c61b731137c01aa6c2b4ce")
