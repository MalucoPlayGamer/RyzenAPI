-- Lua provided by RyzenAPI
-- Game: PLAYNE : The Meditation Game

-- MAIN APPLICATION
addappid(865540)
addappid(1791800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(865541, 1, "a8fd8427a1e65facc6a114141d85ced98115fbb9e54d9666484410dcaf35fecb")
addappid(1525880, 0, "d7ea2a03b57a085b06b51efa6e5b9d0e3eac2b14b6e6d32bb4e62df432851de8")

