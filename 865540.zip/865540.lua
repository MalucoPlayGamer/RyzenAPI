-- Lua provided by RyzenAPI
-- Game: addappid(865540)

-- MAIN APPLICATION
addappid(865540)
addappid(1791800)

-- MAIN APP DEPOTS / PACKAGES
addappid(865541, 1, "a8fd8427a1e65facc6a114141d85ced98115fbb9e54d9666484410dcaf35fecb")
addappid(1525880, 0, "d7ea2a03b57a085b06b51efa6e5b9d0e3eac2b14b6e6d32bb4e62df432851de8")
