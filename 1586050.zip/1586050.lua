-- Lua provided by RyzenAPI
-- Game: CyberSex 2069

-- MAIN APPLICATION
addappid(1586050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586051, 1, "39536b0709ed31b391600612f165deb4d3c02da5d4eab0439b94c703c081da7d")
addappid(1652530, 0, "ff9477ccea48c466beb2cc438464ad36dbd1acdb7f0c107046258eef39fcdedf")

