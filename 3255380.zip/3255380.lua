-- Lua provided by RyzenAPI
-- Game: Game: LUNAR Remastered Collection

-- MAIN APPLICATION
addappid(3255380)
-- Game: addappid(3255380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255381, 1, "ac38563e5a2b774e999580eda2f78158ecfe5f14419e7dd76e7f4f666937d989")
addappid(3255382, 1, "5ceb677dfd97bac6a889614914a31e941771a4b03968b8e2d89a6d5398e01c8f")
addappid(3255383, 1, "5406494f85e7ff25efa225fcb622eebf580bc008888ee39dbc82e22859a9be37")
