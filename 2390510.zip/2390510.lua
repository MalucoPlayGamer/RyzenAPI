-- Lua provided by RyzenAPI
-- Game: You Have 10 Seconds (2023)

-- MAIN APPLICATION
addappid(2390510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390511, 1, "28a6fbe2b21ee094f358558d43b7d3e0365b068b1c0a430532b1373db2eebffa")

