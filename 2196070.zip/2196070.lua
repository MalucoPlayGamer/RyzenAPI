-- Lua provided by SkyAPI 
-- Game: Time Lock VR-episode Lumber Room
addappid(2196070)
addappid(2196071, 1, "119224da7395950597e77dbe3ea0b84350c6e0cb3bb0c85a404c660ff74b2b00")
