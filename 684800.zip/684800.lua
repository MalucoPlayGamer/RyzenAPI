-- Lua provided by RyzenAPI
-- Game: AppID 684800

-- MAIN APPLICATION
addappid(684800)
-- Game: addappid(684800)

-- MAIN APP DEPOTS / PACKAGES
addappid(684801, 1, "e659f95bfc5e2ca0a5cf3e4b30a7589dd811239f6987a336045cc34a9e520af6")
