-- Lua provided by RyzenAPI 
-- Game: AppID 2706730
addappid(2706730)
addappid(2706731, 1, "c87f4473980f2560b53785479062270155c1c39a31952b7479ba92ab91d75b32")
