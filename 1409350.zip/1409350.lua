-- Lua provided by RyzenAPI
-- Game: 1409350

-- MAIN APPLICATION
addappid(1409350)
-- Game: addappid(1409350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409351, 1, "7da88c17a2c7d847e6cc8113d35a4574941d5b52458b29aac0b6e4c60674dbed")
