-- Lua provided by RyzenAPI
-- Game: Game: Bleak Faith: Forsaken

-- MAIN APPLICATION
addappid(1173220)
-- Game: addappid(1173220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173221, 1, "633cf68534b12dffbdb6a9b78d77b8a3a17fcfbe4a42c0d4547895e4e94e8ddd")
