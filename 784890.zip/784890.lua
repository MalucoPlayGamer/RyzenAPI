-- Lua provided by RyzenAPI
-- Game: Bashville

-- MAIN APPLICATION
addappid(784890)

-- MAIN APP DEPOTS / PACKAGES
addappid(784892,0,"91d690feee2af28199b27d416bb7318b47661e8dfddda6d9d0233272a133ef90")

