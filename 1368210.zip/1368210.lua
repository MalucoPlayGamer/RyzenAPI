-- Lua provided by RyzenAPI
-- Game: Project Hospital - Department of Infectious Diseases

-- MAIN APPLICATION
addappid(1368210)
-- Game: addappid(1368210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368211, 1, "e8304490307d54a9c5092ff598919fa9363613103f751e246690ba90c0f2be88")
addappid(1368212, 1, "bbd712271ed4977df01f2509d461b7148f7a0f81da7e00ba3fec257db9b2187d")
addappid(1368213, 1, "f814e39cc322cccf287e3a140d5ca26c8047ac3c37ce5ff0660e9ff08cb22a38")
