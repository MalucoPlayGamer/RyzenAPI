-- Lua provided by RyzenAPI
-- Game: Cosmic: A Journey Among Shadows

-- MAIN APPLICATION
addappid(1769100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769101, 1, "07c3c074f024e19355be017b09180963c177be1c7c94dfef286776386e44dae9")
