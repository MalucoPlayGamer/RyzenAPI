-- Lua provided by RyzenAPI
-- Game: Mimic Logic

-- MAIN APPLICATION
addappid(2455920)
-- Game: addappid(2455920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455921, 1, "dd03f5a2e3abca6cfbcd154b28f7f46a81b088984291261d19da3ac4522d5140")
