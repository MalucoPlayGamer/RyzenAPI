-- Lua provided by RyzenAPI
-- Game: Daomei Village Demo

-- MAIN APPLICATION
addappid(2523060)
-- Game: addappid(2523060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523061, 1, "53a9741906a083b8832640bf2f8818dbbf416969075c424ef8a1a0fc7749f2d7")
