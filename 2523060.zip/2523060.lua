-- Lua provided by SkyAPI 
-- Game: Daomei Village Demo
addappid(2523060)
addappid(2523061, 1, "53a9741906a083b8832640bf2f8818dbbf416969075c424ef8a1a0fc7749f2d7")
