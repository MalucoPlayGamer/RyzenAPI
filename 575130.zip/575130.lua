-- Lua provided by RyzenAPI
-- Game: addappid(575130)

-- MAIN APPLICATION
addappid(575130)

-- MAIN APP DEPOTS / PACKAGES
addappid(575131, 1, "b3089e79ef562063bdd19635d8d755ff3a936631b5f9a94fb9061c39efb79344")
