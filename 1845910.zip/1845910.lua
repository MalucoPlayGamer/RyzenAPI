-- Lua provided by RyzenAPI
-- Game: Dragon Age™: The Veilguard

-- MAIN APPLICATION
addappid(1845910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845911, 1, "55cde6d605fb6c04a505e84c44ff05f79e75dad69c4b0f6326c4ba4478e7cc1d")
