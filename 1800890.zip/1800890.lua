-- Lua provided by RyzenAPI
-- Game: 与芙兰朵露一起捉迷藏吧

-- MAIN APPLICATION
addappid(1800890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800891, 1, "e97ce207f1bbdac8873b745c1fda433878a9a14cf904e265190cd295a7586d63")
