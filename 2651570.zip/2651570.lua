-- Lua provided by RyzenAPI
-- Game: Lilim wants to Lv up♥

-- MAIN APPLICATION
addappid(2651570)
-- Game: addappid(2651570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651571, 1, "59f80dedd0a2710cd83d050ba933cf31bbcc23a680d006685dd2659b36e9fb6e")
addappid(2651572, 1, "e85c173c130e25ce9564ce01c6f8fddb1ef39ff1007655bda707dd573fdbb943")
addappid(2651573, 1, "2261ab898902cb6909c51504052d6c0d3dda6c4ccd7878cafe3d16204d2dc0ec")
