-- Lua provided by RyzenAPI
-- Game: addappid(2524400)

-- MAIN APPLICATION
addappid(2524400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524401, 1, "50873f6b4b3e9feba97626b89a0ec79030fa55fd9413e4a061350453ee8ff2ba")
