-- Lua provided by RyzenAPI
-- Game: AppID 580890

-- MAIN APPLICATION
addappid(580890)
addappid(717620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(580891, 1, "a8cb48a88f082777460a9252e1a7232af23faec56236acd94a565cdf13873ad9")

