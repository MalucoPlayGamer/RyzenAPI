-- Lua provided by RyzenAPI
-- Game: addappid(580890)

-- MAIN APPLICATION
addappid(580890)

-- MAIN APP DEPOTS / PACKAGES
addappid(580891, 1, "a8cb48a88f082777460a9252e1a7232af23faec56236acd94a565cdf13873ad9")
