-- Lua provided by RyzenAPI
-- Game: 274130

-- MAIN APPLICATION
addappid(274130)
-- Game: addappid(274130)

-- MAIN APP DEPOTS / PACKAGES
addappid(274131, 1, "882dcf297f0b6de8b95c1c8a48b52af41d15b06977d108fb6b89e4049c33e6df")
