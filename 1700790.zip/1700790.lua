-- Lua provided by RyzenAPI
-- Game: OshiRabu: Waifus Over Husbandos ~Love･or･die~ Demo

-- MAIN APPLICATION
addappid(1700790)
-- Game: addappid(1700790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700791, 1, "58407ded60a58f9cdfc5fa520e57fea650e87010e6c09a326d3aa28f12c7fd72")
