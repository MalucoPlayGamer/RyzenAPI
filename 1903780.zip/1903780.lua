-- Lua provided by RyzenAPI
-- Game: Game: Blood Camp

-- MAIN APPLICATION
addappid(1903780)
-- Game: addappid(1903780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903781, 1, "da6375c2613fd653965274cfba54e74c5c8df6ce8094ed7fb61e83ef6703bf7f")
