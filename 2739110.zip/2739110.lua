-- Lua provided by SkyAPI 
-- Game: Tiny Breakers Camp Demo
addappid(2739110)
addappid(2739111, 1, "10913ec101b7651252be9dcf80e665ff93067cc2b11aa675fa7ae2dfd4efb051")
