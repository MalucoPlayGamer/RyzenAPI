-- Lua provided by RyzenAPI
-- Game: 2739110

-- MAIN APPLICATION
addappid(2739110)
-- Game: addappid(2739110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739111, 1, "10913ec101b7651252be9dcf80e665ff93067cc2b11aa675fa7ae2dfd4efb051")
