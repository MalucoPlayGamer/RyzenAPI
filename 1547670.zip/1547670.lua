-- Lua provided by RyzenAPI
-- Game: A Day Out

-- MAIN APPLICATION
addappid(1547670)
-- Game: addappid(1547670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547671, 1, "c9c39414a1ebc3ec60c73fa8a14616ac497f329cffc5f648bdbe7b24b94f9f84")
