-- Lua provided by RyzenAPI
-- Game: A Day Out

-- MAIN APPLICATION
addappid(1547670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1547671, 1, "c9c39414a1ebc3ec60c73fa8a14616ac497f329cffc5f648bdbe7b24b94f9f84")

