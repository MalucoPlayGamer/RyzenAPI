-- Lua provided by RyzenAPI
-- Game: 3058890

-- MAIN APPLICATION
addappid(3058890)
-- Game: addappid(3058890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058891, 1, "b10c005b2f3de4f7d89d7661e812cbf52b0b86fedeab8871b5be48e2677956d9")
