-- Lua provided by RyzenAPI
-- Game: Ain Dodo

-- MAIN APPLICATION
addappid(1144280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144281, 1, "8c46172f95290a9123c4bd9dc02b08409146faeda785c62e18f54756977b5ee7")

