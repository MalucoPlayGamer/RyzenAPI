-- Lua provided by RyzenAPI
-- Game: Purgo box

-- MAIN APPLICATION
addappid(1680700)
