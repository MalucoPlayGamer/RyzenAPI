-- Lua provided by RyzenAPI
-- Game: Hidden Cats in Santa's Realm

-- MAIN APPLICATION
addappid(1726750)
addappid(2714010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726751, 1, "2b44647e13cd4285cafc01d149d03f71c67f8e070cf3ab377aad7bde514c8cfb")

