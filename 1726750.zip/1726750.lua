-- Lua provided by RyzenAPI
-- Game: 1726750

-- MAIN APPLICATION
addappid(1726750)
addappid(2714010)
-- Game: addappid(1726750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726751, 1, "2b44647e13cd4285cafc01d149d03f71c67f8e070cf3ab377aad7bde514c8cfb")
