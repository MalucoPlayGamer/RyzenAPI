-- Lua provided by RyzenAPI
-- Game: 1104170

-- MAIN APPLICATION
addappid(1104170)
-- Game: addappid(1104170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104171, 1, "c1ddb29f1f9869f72108b2f9854fa3678eb7ad2e78cb780489440f49b53ecfa2")
