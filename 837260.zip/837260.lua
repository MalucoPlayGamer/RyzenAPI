-- Lua provided by RyzenAPI
-- Game: Roller Coaster Apocalypse VR

-- MAIN APPLICATION
addappid(837260)

-- MAIN APP DEPOTS / PACKAGES
addappid(837261, 1, "fa1901f5b34eeaa022ed0d8ea95f238ae6f679740d7efd586561b9aa7ea96b09")

