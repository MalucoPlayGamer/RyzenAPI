-- Lua provided by RyzenAPI
-- Game: addappid(2332970)

-- MAIN APPLICATION
addappid(2332970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332971, 1, "9c6e426e18e62fb015eb102beb68d01ebacfe18e2c5ceb0493e984089f09b36e")
