-- Lua provided by RyzenAPI
-- Game: Capture the monster

-- MAIN APPLICATION
addappid(794920)

-- MAIN APP DEPOTS / PACKAGES
addappid(794921, 1, "7e80a187feb999ed1b50fbeecace34900de89d5d17044a3b92d0fd28839cc3ec")

