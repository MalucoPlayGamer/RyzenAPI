-- Lua provided by RyzenAPI
-- Game: Chasing the wind

-- MAIN APPLICATION
addappid(1603280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603281, 1, "50cbec1ce1e815ca055134d915134ce05bda0122a4207cb152c375b3ff471f23")
