-- Lua provided by RyzenAPI
-- Game: Game: AppID 2225030

-- MAIN APPLICATION
addappid(2225030)
-- Game: addappid(2225030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225031, 1, "7e43e1d0cc280a936ccfa3e71299a427d52943ebd8c77a606e2de41a08ebf8ee")
