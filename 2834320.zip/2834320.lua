-- Lua provided by RyzenAPI
-- Game: addappid(2834320)

-- MAIN APPLICATION
addappid(2834320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834321, 1, "ebf245d763fde18d355fd614962a3486baed5e18580bd369bcfb79cad2ac85db")
