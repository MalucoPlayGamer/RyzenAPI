-- Lua provided by SkyAPI 
-- Game: AppID 1302000
addappid(1302000)
addappid(1302001, 1, "ecdedfb39686e0e54bfa8da70b5072a0ca6bbd17344ac42a33f580aa01f062c0")
