-- Lua provided by RyzenAPI
-- Game: NO, THANK YOU!!!

-- MAIN APPLICATION
addappid(975000)
-- Game: addappid(975000)

-- MAIN APP DEPOTS / PACKAGES
addappid(975001, 1, "9575ffd3affe3782c0912278c17e21e2ea2475d82d5f5e4fe20d7219de852844")
