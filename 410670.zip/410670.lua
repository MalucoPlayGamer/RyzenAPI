-- Lua provided by RyzenAPI
-- Game: AppID 410670

-- MAIN APPLICATION
addappid(410670)
addappid(435340)

-- MAIN APP DEPOTS / PACKAGES
addappid(410671, 1, "e602a2e6e4366593942bdfff9629f51dcf188c42dc108ce4ca6325c3e083c28a")
addappid(410672, 1, "2d536391c8062c7a008431f6f1535f802a6f399b5b8c3da6394af1b2e11990bc")
addappid(410673, 1, "cb068cb81bdbc3783313716cd17e32f44c5295e6a44dcefd6132f87e02f85cad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
