-- Lua provided by SkyAPI 
-- Game: Shadowgrounds Survivor
addappid(11200)
addappid(11201, 1, "286c0f2f8714bdc2e2a228f7495135d88a5e5d6fb34aed71c514be003a752336")
addappid(11203, 1, "f668918e00b2b15b4b3650c4bf0f45e9022ee79d23bc1c492f5036dee381b017")
