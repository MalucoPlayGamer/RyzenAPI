-- Lua provided by RyzenAPI
-- Game: Game: Can blood clan girls also become paladins

-- MAIN APPLICATION
addappid(3084580)
-- Game: addappid(3084580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084581, 1, "a6cde9adf52514d9a1afbf5bb6539a917636eef9e1bf642f67c03fc73290ad7f")
