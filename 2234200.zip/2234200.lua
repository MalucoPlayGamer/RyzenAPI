-- Lua provided by RyzenAPI
-- Game: Heroes of Eternal Quest

-- MAIN APPLICATION
addappid(2234200)
-- Game: addappid(2234200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234201, 1, "c5932a8c031bc74f846bb2a3546338ea683b878ede596edcca9300d2d32c4e66")
