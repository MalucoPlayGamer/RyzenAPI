-- Lua provided by RyzenAPI 
-- Game: CaseCracker2
addappid(2294450)
addappid(2294451, 1, "5faf1af104dd600e4ae27ed4a475294183db081ffeba1b98eb35678c3a2f580f")
addappid(2294452, 1, "f334602c05e042463c76311e96b36442f6a05148eb637e01c267aeb542a5b7b1")
