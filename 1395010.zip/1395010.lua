-- Lua provided by RyzenAPI
-- Game: Magic Griddlers

-- MAIN APPLICATION
addappid(1395010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395011, 1, "db90e8cd1e1c4be97193898129f970d3b296dae4a7944b9ada4d1f20cecfbf32")
addappid(1395012, 1, "2d4a8eaddd713fecddc95078854c78aebbe6ad7d1ae2498c42855f712e929956")

