-- Lua provided by RyzenAPI
-- Game: Legacy of Shadows 影の遺産

-- MAIN APPLICATION
addappid(3604960)
-- Game: addappid(3604960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604961, 1, "fa110112de76ae3c85b46c46d78e46740c2f2ffa5b00cf572c8505b68977fd9b")
