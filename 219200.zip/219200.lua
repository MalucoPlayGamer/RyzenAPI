-- Lua provided by RyzenAPI
-- Game: Droid Assault

-- MAIN APPLICATION
addappid(219200)

-- MAIN APP DEPOTS / PACKAGES
addappid(219201, 1, "0824eb86fc21dcf39ec9a2a09b146852f307f1530c783704684b3da1445ee0ac")
