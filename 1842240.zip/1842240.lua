-- Lua provided by RyzenAPI
-- Game: AppID 1842240

-- MAIN APPLICATION
addappid(1842240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842241, 1, "f84c3e53530e32458d0125c76cc8bfe79ba2ddcf2de40b6b6d0b9b0614b659b8")
