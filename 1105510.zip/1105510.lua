-- Lua provided by RyzenAPI
-- Game: Yakuza 5 Remastered

-- MAIN APPLICATION
addappid(1105510)
-- Game: addappid(1105510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105511, 1, "0c335e9d30387b322b2822752aa8827d47a59d2bad54a144ce93dbc1e3377ae9")
addappid(1105512, 1, "dfb8b0ac80dab6c0375b39f503efa542922000358f6ffd84978656d0859cfeae")
