-- Lua provided by RyzenAPI
-- Game: DFF NT: Overture, Lightning's EX weapon

-- MAIN APPLICATION
addappid(1022512)
-- Game: addappid(1022512)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022512,0,"36a8bba4333e6c7a4c68a65a6e8cd28946b28b081e8ad8f9a6030245005f8123")
