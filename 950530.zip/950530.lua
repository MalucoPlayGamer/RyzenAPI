-- Lua provided by RyzenAPI
-- Game: Mojo 2: Mia

-- MAIN APPLICATION
addappid(950530)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(984740)
addappid(984741)
