-- Lua provided by RyzenAPI
-- Game: Mojo 2: Mia

-- MAIN APPLICATION
addappid(950530)

