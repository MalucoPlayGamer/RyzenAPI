-- Lua provided by RyzenAPI
-- Game: Tabletop Creator Pro

-- MAIN APPLICATION
addappid(861590)
-- Game: addappid(861590)

-- MAIN APP DEPOTS / PACKAGES
addappid(861592,0,"f9b2e9c6bd85ea42550dd5e6d4c1e845af2504d92e3fae4f8dfecc1b6f021c55")
