-- Lua provided by RyzenAPI
-- Game: addappid(492140)

-- MAIN APPLICATION
addappid(492140)

-- MAIN APP DEPOTS / PACKAGES
addappid(381213,0,"525dbbc5d40bca2cd810f8cb48945f893aa16ca7c1ea90895e0d0c498f183ff5")
