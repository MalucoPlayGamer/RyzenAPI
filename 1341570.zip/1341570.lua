-- Lua provided by RyzenAPI
-- Game: DoHots

-- MAIN APPLICATION
addappid(1341570)
addappid(1641110)
-- Game: addappid(1341570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341571, 1, "92f75d529f532371146a741c4721088cdf33e89124ebd9614791c54a3f83b5c0")
