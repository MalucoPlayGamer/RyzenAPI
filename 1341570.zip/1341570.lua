-- Lua provided by RyzenAPI
-- Game: DoHots

-- MAIN APPLICATION
addappid(1341570)
addappid(1641110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341571, 1, "92f75d529f532371146a741c4721088cdf33e89124ebd9614791c54a3f83b5c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
