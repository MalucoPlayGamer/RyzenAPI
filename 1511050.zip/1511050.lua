-- Lua provided by RyzenAPI
-- Game: Exploration of Xianshan

-- MAIN APPLICATION
addappid(1511050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511051, 1, "48757094abafaa5f63f85bb4da2fef189f4adfd86d6cd31b4430acb4e3d30bc6")

