-- Lua provided by RyzenAPI
-- Game: Adventure Craft

-- MAIN APPLICATION
addappid(624890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(624891, 1, "0e944e25345344e614fb07bf37046af92e0503148fb110d46e227da8578cc96d")
