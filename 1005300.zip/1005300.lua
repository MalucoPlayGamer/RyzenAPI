-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 6

-- MAIN APPLICATION
addappid(1005300)
-- Game: addappid(1005300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005301, 1, "52fc96b7852c7a07ddc9ccea93568157b96c6483185ecf7f76c9c5f1987795b0")
addappid(1005302, 1, "09bd9da0232d0bd888158efe643f69692e82d80b38e15d4bc050156f154745d6")
addappid(1005303, 1, "a6efd2723815fe2f72d2ef7a67c82e94c5aa1911937876f942bacdebed71ce68")
addappid(1005304, 1, "85d1e8e91dfc20f24d6cfab12b210eab7ccef21d4abcad471aba5a2e4d3f528d")
addappid(1005305, 1, "705c5a805600e084be3de82a57f91dc679fc1fb6e11899ded78b5bcd8e6825d3")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
