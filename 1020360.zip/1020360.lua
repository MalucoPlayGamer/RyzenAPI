-- Lua provided by RyzenAPI
-- Game: Game: AppID 1020360

-- MAIN APPLICATION
addappid(1020360)
-- Game: addappid(1020360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020361, 1, "0a858c49190389c486367dec736fbee92ac03cd7b2782083d06014968bac22c1")
