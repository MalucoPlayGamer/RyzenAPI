-- Lua provided by RyzenAPI
-- Game: Wand Wars: Rise

-- MAIN APPLICATION
addappid(1020360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1020361, 1, "0a858c49190389c486367dec736fbee92ac03cd7b2782083d06014968bac22c1")

