-- Lua provided by RyzenAPI
-- Game: Weather Lord: Royal Holidays Collector's Edition

-- MAIN APPLICATION
addappid(572570)

-- MAIN APP DEPOTS / PACKAGES
addappid(572571, 1, "2fe4cf2bb22435a8043d3698291883e0d6124981588653f0ba32efdc8daa5639")
addappid(572572, 1, "16cf7fb5cd9ca48637740162fe19a347ceda6fc34f51637ffa9439f49fae0a59")
