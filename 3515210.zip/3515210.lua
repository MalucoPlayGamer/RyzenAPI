-- Lua provided by RyzenAPI
-- Game: Wasteland Rangers

-- MAIN APPLICATION
addappid(3515210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515211, 1, "f2d2f5dd0d353faf742c4c38d2003b5446999efc953a94b13c46a914a2e7cbac")
