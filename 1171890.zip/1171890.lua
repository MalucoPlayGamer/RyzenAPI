-- Lua provided by RyzenAPI
-- Game: Hatred: Subscribe or Die - comic book

-- MAIN APPLICATION
addappid(1171890)
-- Game: addappid(1171890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171890,0,"0fdd1c65078267470f71130fd77b21931942ec50c65a511653822a02dcd9cf3e")
