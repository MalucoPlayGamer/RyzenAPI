-- Lua provided by SkyAPI 
-- Game: Wyoming Winter
addappid(2214170)
addappid(2214171, 1, "4a617c1e6acb869f0e53aa073ecb208a895f57f3d47883881f72eff84c9da3f9")
