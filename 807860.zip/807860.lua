-- Lua provided by RyzenAPI
-- Game: AppID 807860

-- MAIN APPLICATION
addappid(807860)

-- MAIN APP DEPOTS / PACKAGES
addappid(807861, 1, "d479d0ad258a352a8654c808fd881f1f81523ebfdc680a1be8b07834e4daced1")

