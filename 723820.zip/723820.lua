-- Lua provided by RyzenAPI
-- Game: BANANO BROS.

-- MAIN APPLICATION
addappid(723820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(723821, 1, "58ab0533dc63597f5b7a637618469fbb6d057784acc31b4122de436b658ba935")

