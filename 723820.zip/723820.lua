-- Lua provided by RyzenAPI
-- Game: AppID 723820

-- MAIN APPLICATION
addappid(723820)
-- Game: addappid(723820)

-- MAIN APP DEPOTS / PACKAGES
addappid(723821, 1, "58ab0533dc63597f5b7a637618469fbb6d057784acc31b4122de436b658ba935")
