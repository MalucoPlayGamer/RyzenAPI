-- Lua provided by RyzenAPI
-- Game: Sizeable

-- MAIN APPLICATION
addappid(1333910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333911, 1, "4d836b3741aadd3cd3916c195c364304080a9b356a9464ef390dc54c741c9811")

