-- Lua provided by RyzenAPI
-- Game: 2183030

-- MAIN APPLICATION
addappid(2183030)
-- Game: addappid(2183030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183031, 1, "91069cbba32efbe84d51f19b0fc1d75302c0faf60ce65b2aa4e5c15ba53fee13")
