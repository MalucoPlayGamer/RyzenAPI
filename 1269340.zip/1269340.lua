-- Lua provided by RyzenAPI
-- Game: Game: Floody Demo

-- MAIN APPLICATION
addappid(1269340)
-- Game: addappid(1269340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269341, 1, "86b07e09764c75e7232471f607c5d9b00db418633826d96aab90b0030bb0fbbd")
