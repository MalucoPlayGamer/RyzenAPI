-- Lua provided by RyzenAPI
-- Game: 587110

-- MAIN APPLICATION
addappid(587110)
-- Game: addappid(587110)

-- MAIN APP DEPOTS / PACKAGES
addappid(587111, 1, "6900203d5e965dae88c920f6ff714a2825065ace57eeacc841aab7357b444ccc")
