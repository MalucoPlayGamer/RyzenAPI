-- Lua provided by RyzenAPI
-- Game: Ys: Memories of Celceta

-- MAIN APPLICATION
addappid(587110)

-- MAIN APP DEPOTS / PACKAGES
addappid(587111, 1, "6900203d5e965dae88c920f6ff714a2825065ace57eeacc841aab7357b444ccc")
