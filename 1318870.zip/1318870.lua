-- Lua provided by RyzenAPI 
-- Game: Turkey Hunting Unlimited
addappid(1318870)
addappid(1318871, 1, "7dea6693a54b81d69370b1285022f197c3a2ba397ae8d603645494b42c6f51c7")
