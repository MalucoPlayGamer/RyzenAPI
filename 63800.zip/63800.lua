-- Lua provided by RyzenAPI
-- Game: Game: Delve Deeper

-- MAIN APPLICATION
addappid(63800)
addappid(229011)
-- Game: addappid(63800)

-- MAIN APP DEPOTS / PACKAGES
addappid(63801, 1, "90be35aab9b49661bbf2dc3425722da6a54002244222eaceed8408286432b694")
addappid(63802, 1, "91fc74dc0b4e1178ef7b0669b70f8a1740c7476127fcddad0cad130e4692e720")
addappid(63803, 1, "997a971fafbd9f042999a63e7177b1de5000b1cd1cdca615199b552d6ed30b85")
