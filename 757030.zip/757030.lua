-- Lua provided by RyzenAPI
-- Game: Christmas Stories: A Christmas Carol Collector's Edition

-- MAIN APPLICATION
addappid(757030)

-- MAIN APP DEPOTS / PACKAGES
addappid(757031,0,"cd433941aff9dff6618d66ef88857ad36e19c2f992930083fce45e0cad1cc1a1")

