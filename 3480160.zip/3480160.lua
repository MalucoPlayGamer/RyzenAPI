-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss - MASTER NINJA Formal Costume Set

-- MAIN APPLICATION
addappid(3480160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3480160,0,"3a59daf7f9721792286915ce6ddcfbbd504b646b31cc1681b874e9cdc0acfe3c")

