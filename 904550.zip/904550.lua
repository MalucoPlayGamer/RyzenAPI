-- Lua provided by RyzenAPI
-- Game: Robot Chase

-- MAIN APPLICATION
addappid(904550)

-- MAIN APP DEPOTS / PACKAGES
addappid(904551, 1, "108df1e15b41b19caf8269ba32fcccb2a709ae47377822649da87565e70a0903")

