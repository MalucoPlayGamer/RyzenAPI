-- Lua provided by RyzenAPI
-- Game: AppID 904550

-- MAIN APPLICATION
addappid(904550)
-- Game: addappid(904550)

-- MAIN APP DEPOTS / PACKAGES
addappid(904551, 1, "108df1e15b41b19caf8269ba32fcccb2a709ae47377822649da87565e70a0903")
