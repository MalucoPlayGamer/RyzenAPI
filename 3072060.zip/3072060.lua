-- Lua provided by RyzenAPI
-- Game: 101 Cats in Las Vegas

-- MAIN APPLICATION
addappid(3072060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072061, 1, "5a73caea40ea2d9b7a7ac55c8623fe01778a520337ad16dce31646e67a7c9961")
