-- Lua provided by RyzenAPI
-- Game: 2667170

-- MAIN APPLICATION
addappid(2667170)
-- Game: addappid(2667170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667171, 1, "46a3d098185015dd9a35942fb411c27befe15d521960d5937af18e25ef366fc2")
addappid(2667172, 1, "bfac90259037d20aba8e9746f4c2dd4319476392cf0c65721c4df31eab2eebca")
