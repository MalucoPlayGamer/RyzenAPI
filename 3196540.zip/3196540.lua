-- Lua provided by RyzenAPI
-- Game: IdleTale

-- MAIN APPLICATION
addappid(3196540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196541, 1, "c639786b4a2cf063d74bca2a896670913dd7fbd45bd7495be5aff12f88e92cb2")
