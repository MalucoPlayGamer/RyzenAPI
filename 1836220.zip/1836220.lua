-- Lua provided by RyzenAPI
-- Game: Frigore

-- MAIN APPLICATION
addappid(1836220)
-- Game: addappid(1836220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836221, 1, "849a9515c11db937b9f69a0308116fd9400787389147241e11312dca772a970a")
