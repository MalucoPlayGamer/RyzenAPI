-- Lua provided by RyzenAPI
-- Game: addappid(1571750)

-- MAIN APPLICATION
addappid(1571750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571751, 1, "7a48ef8e888443fd3e8b66c9e792715a2cf4f3f9cbb9c6e8d493690d0333a25b")
