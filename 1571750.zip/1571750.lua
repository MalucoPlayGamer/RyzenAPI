-- Lua provided by SkyAPI 
-- Game: Gun Game
addappid(1571750)
addappid(1571751, 1, "7a48ef8e888443fd3e8b66c9e792715a2cf4f3f9cbb9c6e8d493690d0333a25b")
