-- Lua provided by RyzenAPI 
-- Game: Lifeform Zero
addappid(1848270)
addappid(1848271, 1, "062315b3feb470d0344e646cb11ea7f2b2a83b77889c5e18376730101f837449")
