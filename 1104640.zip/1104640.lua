-- Lua provided by RyzenAPI 
-- Game: New Frontier
addappid(1104640)
addappid(1104641, 1, "fe00b5cb39c0dbf50fde588884c295719fd726e0a549edce1678dd9f24440264")
