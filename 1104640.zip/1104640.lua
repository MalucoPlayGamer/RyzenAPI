-- Lua provided by RyzenAPI
-- Game: New Frontier

-- MAIN APPLICATION
addappid(1104640)
-- Game: addappid(1104640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104641, 1, "fe00b5cb39c0dbf50fde588884c295719fd726e0a549edce1678dd9f24440264")
