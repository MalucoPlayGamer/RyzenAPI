-- Lua provided by RyzenAPI 
-- Game: Spelunky 2
addappid(418530)
addappid(418531, 1, "80aee6dd18e11eaef9aa98dd0fbf9e2a9212daf4678e5c3a3c71bbaad24b01d8")
addappid(418532, 1, "45d2641388b09ff60ca7bd0cc8e67e170d391a5b3965aca8e4d88f3683c80401")
