-- Lua provided by RyzenAPI
-- Game: AppID 3745420

-- MAIN APPLICATION
addappid(3745420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3745421, 1, "30ff06f035fb9d5b23643a88cbd77dcb7898f28f3aabe2a72d7c8e152abcb944")

