-- Lua provided by RyzenAPI
-- Game: Game: AppID 3745420

-- MAIN APPLICATION
addappid(3745420)
-- Game: addappid(3745420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3745421, 1, "30ff06f035fb9d5b23643a88cbd77dcb7898f28f3aabe2a72d7c8e152abcb944")
