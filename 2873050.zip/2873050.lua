-- Lua provided by RyzenAPI
-- Game: 2873050

-- MAIN APPLICATION
addappid(2873050)
-- Game: addappid(2873050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873051, 1, "a2d8836db35ab5be6eadc3d79e6b87988bb66f936eb70be4ea062691b84c703c")
