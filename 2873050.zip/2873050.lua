-- Lua provided by SkyAPI 
-- Game: LOVE ON Demo
addappid(2873050)
addappid(2873051, 1, "a2d8836db35ab5be6eadc3d79e6b87988bb66f936eb70be4ea062691b84c703c")
