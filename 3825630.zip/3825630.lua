-- Lua provided by RyzenAPI
-- Game: 3825630

-- MAIN APPLICATION
addappid(3825630)
-- Game: addappid(3825630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3825631, 1, "a2b9370d16e7c98f4716099e4100262e7b680c16f2cb8650be0ed89accd8fc8a")
