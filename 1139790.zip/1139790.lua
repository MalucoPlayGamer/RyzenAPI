-- Lua provided by RyzenAPI
-- Game: AppID 1139790

-- MAIN APPLICATION
addappid(1139790)
-- Game: addappid(1139790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139791, 1, "dd85cc8c80799c7b89368abed245c02c5001a19628eb4707e8f818300bc6f05b")
