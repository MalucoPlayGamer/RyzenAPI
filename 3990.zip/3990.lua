-- Lua provided by RyzenAPI
-- Game: addappid(3990)

-- MAIN APPLICATION
addappid(3990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3991, 1, "fb8c02e0947eb969c3db1de386e9f4813aa0e3889f273253bb65de2bc8efd3c8")
addappid(3992, 1, "3dca2e1893c65445688b405a78137d19fbb04c4be434ceeaf7e72fa1947c16f8")
