-- Lua provided by RyzenAPI
-- Game: Silent Storm Gold Edition

-- MAIN APPLICATION
addappid(254960)
-- Game: addappid(254960)

-- MAIN APP DEPOTS / PACKAGES
addappid(254961, 1, "f57dbd98e66de5359bf9648baeeed174e43718c57ee821bbfc06bf6c15e7967d")
addappid(254962, 1, "cdf0968a9969b5fb53eca7c64681489d576984750a60268411cb103c8196cb31")
addappid(254963, 1, "a3302dd4b1b875520544d3f99c7d8ba83bce6002a57e80d4a852631d95ee20e4")
addappid(254964, 1, "93ec17b8d21eae53ce577495dd7c44700bf9a4af7562106e74def49e53b10e42")
addappid(254965, 1, "1c10c1dc91c94dc7fb6c971ceca2b77ecb9640eea6a9004dc61bf8d434a8e16b")
addappid(254966, 1, "5bddb23b780a1acc3d3e8675f60a2687e695355fbb7a2354e58a044005191f04")
