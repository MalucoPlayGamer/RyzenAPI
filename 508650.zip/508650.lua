-- Lua provided by RyzenAPI
-- Game: 508650

-- MAIN APPLICATION
addappid(228990)
addappid(229000)
addappid(229002)
addappid(508650)
addappid(508651)

-- MAIN APP DEPOTS / PACKAGES
addappid(508652,0,"32b9145886c184bc8f7c60cb5728f95f080561fea299ca71412024ddba430b0c")

