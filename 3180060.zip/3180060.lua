-- Lua provided by RyzenAPI
-- Game: Game: Big Boobie Boss Blackmail

-- MAIN APPLICATION
addappid(3180060)
-- Game: addappid(3180060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180061, 1, "d1c2baa6997fc98e525070aa34d821f301ddb5316ec5caad00573a88517a1e0e")
