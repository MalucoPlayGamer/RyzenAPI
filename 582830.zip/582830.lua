-- Lua provided by RyzenAPI
-- Game: AppID 582830

-- MAIN APPLICATION
addappid(582830)
-- Game: addappid(582830)

-- MAIN APP DEPOTS / PACKAGES
addappid(582831, 1, "5f0fa13bea9b3ff9e6b46f50c1d81f7ef255d3a59d54fa76c2a258ab1cc8554a")
