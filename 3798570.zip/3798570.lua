-- Lua provided by RyzenAPI
-- Game: 3798570

-- MAIN APPLICATION
addappid(3798570)
-- Game: addappid(3798570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3798571, 1, "1daf69e755a9c9f4176c8212858e53cf5dc989d468b23775fbc17afc70d97b18")
