-- Lua provided by RyzenAPI 
-- Game: AppID 436470
addappid(436470)
addappid(436471, 1, "3fa58b4fa196d29128177842e9530fb95c7cc378357dcce9e751d0f34c387274")
addappid(436472, 1, "19a9b5cdc5ca63f16ad28880959b2d93808d3403b5356ec6d0c7ad5b5c010c66")
