-- Lua provided by RyzenAPI 
-- Game: AppID 3318310
addappid(3318310)
addappid(3318311, 1, "60424b6be36e7ac7002f5f9416a7aaf36e6c24b4702d6e9e441713f9923a466e")
