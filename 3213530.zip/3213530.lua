-- Lua provided by RyzenAPI
-- Game: addappid(3213530)

-- MAIN APPLICATION
addappid(3213530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213530,0,"4b1adbc4455c3b00651a922d6cb737d3c1e598ff95bd9d8eaa8531c9f44a075e")
