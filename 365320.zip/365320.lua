-- Lua provided by RyzenAPI
-- Game: AppID 365320

-- MAIN APPLICATION
addappid(365320)
-- Game: addappid(365320)

-- MAIN APP DEPOTS / PACKAGES
addappid(365321, 1, "e61898da554003d70d0a4f054cf97628f2cc8d61f86e206b445cf0c1023a81b1")
addappid(500770, 0, "de7126ff02ffc83b3dddf2df0b653a730b289e30efeed0534e9fdb4a58525bdf")
