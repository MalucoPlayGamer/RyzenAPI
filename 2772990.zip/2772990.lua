-- Lua provided by RyzenAPI 
-- Game: Ghost Janitors
addappid(2772990)
addappid(2772991, 1, "8a0caa2b87cf1a42a6164a58004bdeb18ac2760ca685d46ed55550a870122820")
