-- Lua provided by RyzenAPI
-- Game: Game: Ghost Janitors

-- MAIN APPLICATION
addappid(2772990)
-- Game: addappid(2772990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772991, 1, "8a0caa2b87cf1a42a6164a58004bdeb18ac2760ca685d46ed55550a870122820")
