-- Lua provided by RyzenAPI
-- Game: Candy Girlfriend

-- MAIN APPLICATION
addappid(2022110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022111, 1, "0d906593da7eb7325061ae1cf19af9fcb8e3fbdae0690b486362ca553bb02f07")
