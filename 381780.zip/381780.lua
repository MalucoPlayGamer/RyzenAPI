-- Lua provided by RyzenAPI
-- Game: 80 Days

-- MAIN APPLICATION
addappid(381780)

-- MAIN APP DEPOTS / PACKAGES
addappid(381782,0,"17a03153422fcd55ebdee21c11f54c3a0bdcf94018f27cb3301e89c3da72e58d")
