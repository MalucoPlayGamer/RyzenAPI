-- Lua provided by RyzenAPI
-- Game: addappid(1638660)

-- MAIN APPLICATION
addappid(1638660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638661, 1, "645bce3aefb51648b5b371ae0e705f7958cc19d2fb36f3433c43c8972132909a")
