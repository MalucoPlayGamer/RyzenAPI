-- Lua provided by SkyAPI 
-- Game: Soul Nomad & the World Eaters
addappid(1535610)
addappid(1535611, 1, "901256199fcd791ef2c039899e35d65be79621e3eb321d733927c659b4097b71")
addappid(1709010, 0, "44dbe5559d27c025c2859be31e6329836a3d5d5a2100cd5e6043480edebbd649")
