-- Lua provided by RyzenAPI
-- Game: Game: AppID 963450

-- MAIN APPLICATION
addappid(963450)
-- Game: addappid(963450)

-- MAIN APP DEPOTS / PACKAGES
addappid(963451, 1, "9614b572662d29cb3b2cdbae90fb8f1401c12ae2cf6401e84773dff11cbf40ea")
addappid(963452, 1, "157a2da8918c71d621a6c5275d4ca8ab01a2c6345ecd8a5d9aa42492677ea119")
addappid(963453, 1, "621076f2bf8bf32d71856b74b8380f4a7f34ee6c0c3f14262ea441b8b078891b")
