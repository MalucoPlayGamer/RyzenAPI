-- Lua provided by RyzenAPI
-- Game: Go-Kart Simulator

-- MAIN APPLICATION
addappid(3388640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388641,0,"0a1eea1633acdfc782b00cd895917c31bcb83cd7efc89afaea6d62d2371657bb")

