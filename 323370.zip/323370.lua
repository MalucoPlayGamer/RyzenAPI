-- Lua provided by RyzenAPI
-- Game: Game: AppID 323370

-- MAIN APPLICATION
addappid(323370)
-- Game: addappid(323370)

-- MAIN APP DEPOTS / PACKAGES
addappid(323371, 1, "6292455150aad5de9b153269feb457b9332b370c0139c5156b7f2730cab32eff")
