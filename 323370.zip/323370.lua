-- Lua provided by RyzenAPI
-- Game: TERA

-- MAIN APPLICATION
addappid(323370)
addappid(326620)
addappid(326621)
addappid(326622)
addappid(326623)
addappid(326624)
addappid(377180)
addappid(410250)
addappid(530380)
addappid(819600)
addappid(819601)
addappid(854320)
addappid(854321)
addappid(1038550)
addappid(1038560)

-- MAIN APP DEPOTS / PACKAGES
addappid(323371, 1, "6292455150aad5de9b153269feb457b9332b370c0139c5156b7f2730cab32eff")

