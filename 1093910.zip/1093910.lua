-- Lua provided by RyzenAPI
-- Game: Tales of the Black Forest

-- MAIN APPLICATION
addappid(1093910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093911, 1, "815e0377ea5af4f16ae800ccbcb5337a6e818bbbc92d8fe904b2634e2d3f5229")
addappid(1093912, 1, "866b857bcc37e14d4a5f34bb1a285236b50f280738318ca313a366ebedd8a784")
addappid(1093913, 1, "047b0ab25cb2689937b6d18c486af76652a76999adc0ef32bca790c78800b1f6")
addappid(1093914, 1, "048ce49ec45d389b9b45cb291cc29b0df53b0fa824b5aab244eb06b4e82782bc")
