-- Lua provided by RyzenAPI
-- Game: Game: 贸易与马车

-- MAIN APPLICATION
addappid(1754770)
-- Game: addappid(1754770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754771, 1, "4153100c653b065614d4c88de3488450224ca0230a98a55d9d9a0d82753e2fe1")
