-- Lua provided by RyzenAPI
-- Game: 839110

-- MAIN APPLICATION
addappid(839110)
-- Game: addappid(839110)

-- MAIN APP DEPOTS / PACKAGES
addappid(839110,0,"b17b8c331aa529e03731f129c89b5eb508de874fdcc0331d83f74c7e650913fe")
