-- Lua provided by RyzenAPI
-- Game: Re Angel - Original Sound Track

-- MAIN APPLICATION
addappid(839110)

-- MAIN APP DEPOTS / PACKAGES
addappid(839110,0,"b17b8c331aa529e03731f129c89b5eb508de874fdcc0331d83f74c7e650913fe")

