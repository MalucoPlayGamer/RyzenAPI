-- Lua provided by RyzenAPI
-- Game: AppID 918990

-- MAIN APPLICATION
addappid(918990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(918991, 1, "95f5380ff779f2805b9434867a8da61f2ab0662423dffd9d2afb0caf5715dc6a")

