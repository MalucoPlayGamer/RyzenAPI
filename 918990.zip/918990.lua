-- Lua provided by RyzenAPI
-- Game: AppID 918990

-- MAIN APPLICATION
addappid(918990)

-- MAIN APP DEPOTS / PACKAGES
addappid(918991, 1, "95f5380ff779f2805b9434867a8da61f2ab0662423dffd9d2afb0caf5715dc6a")

