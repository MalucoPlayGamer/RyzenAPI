-- Lua provided by SkyAPI 
-- Game: Spirited Thief
addappid(1709870)
addappid(1709871, 1, "62146708fc8a61d0719a0d31a37d58717f4ee60b626570273866e6bd9ce0182f")
