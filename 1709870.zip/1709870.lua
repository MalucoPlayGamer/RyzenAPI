-- Lua provided by RyzenAPI
-- Game: Game: Spirited Thief

-- MAIN APPLICATION
addappid(1709870)
-- Game: addappid(1709870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709871, 1, "62146708fc8a61d0719a0d31a37d58717f4ee60b626570273866e6bd9ce0182f")
