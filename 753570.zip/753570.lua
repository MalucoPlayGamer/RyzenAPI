-- Lua provided by RyzenAPI
-- Game: Rogue Buddies - Aztek Gold

-- MAIN APPLICATION
addappid(753570)

-- MAIN APP DEPOTS / PACKAGES
addappid(753571, 1, "bd6ed7273f4cf404112849edd067c98df98438cdae4485023d98eedf8edc3dac")

