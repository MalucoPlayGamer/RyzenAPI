-- Lua provided by RyzenAPI
-- Game: Game: Alas Astra

-- MAIN APPLICATION
addappid(1361660)
-- Game: addappid(1361660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361661, 1, "0cc9cde3accb5232d7f3b9a95b575929e2bbb66ca27d35be43bf22dfca31817c")
