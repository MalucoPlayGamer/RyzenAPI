-- Lua provided by RyzenAPI
-- Game: Alas Astra

-- MAIN APPLICATION
addappid(1361660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1361661, 1, "0cc9cde3accb5232d7f3b9a95b575929e2bbb66ca27d35be43bf22dfca31817c")

