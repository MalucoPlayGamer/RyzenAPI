-- Lua provided by SkyAPI 
-- Game: Alas Astra
addappid(1361660)
addappid(1361661, 1, "0cc9cde3accb5232d7f3b9a95b575929e2bbb66ca27d35be43bf22dfca31817c")
