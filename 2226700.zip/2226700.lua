-- Lua provided by RyzenAPI
-- Game: 2226700

-- MAIN APPLICATION
addappid(2226700)
-- Game: addappid(2226700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226701, 1, "ee747c1fc92daff746d3461ea2521b0b0aad3476223198faa77789c159929a13")
