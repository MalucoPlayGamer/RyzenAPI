-- Lua provided by RyzenAPI
-- Game: 挂姬恶魔/IdleDevils

-- MAIN APPLICATION
addappid(2226700)
addappid(2867010)
addappid(2873000)
addappid(3212190)
addappid(3212200)
addappid(3212210)
addappid(3468070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226701, 1, "ee747c1fc92daff746d3461ea2521b0b0aad3476223198faa77789c159929a13")

