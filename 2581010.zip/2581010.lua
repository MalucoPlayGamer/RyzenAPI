-- Lua provided by RyzenAPI
-- Game: ASTRA: Knights of Veda Demo

-- MAIN APPLICATION
addappid(2581010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581011, 1, "b046b0ab68f3e21e60ac2575da0fc4899584f0925c8b5d0315e392dabf3fbbd3")

