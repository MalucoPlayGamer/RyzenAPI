-- Lua provided by RyzenAPI
-- Game: AppID 1413960

-- MAIN APPLICATION
addappid(1413960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413961, 1, "92a42ab62906b4d447415a76d1203aa73a2cd440ccc5f04a71027f2d47a763fc")
addappid(1413962, 1, "cc105e11a0bc5506530e0b2f21fb811d8b259c60263c229c948feb81430e871e")
addappid(1413963, 1, "df6d9ce90644742c2072276262f7db7171783e22ae156cf03812e1b40df02580")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2006230)
