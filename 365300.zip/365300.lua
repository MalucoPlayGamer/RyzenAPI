-- Lua provided by RyzenAPI
-- Game: Transmissions: Element 120

-- MAIN APPLICATION
addappid(365300)

-- MAIN APP DEPOTS / PACKAGES
addappid(365301, 1, "da3ff564858320bbb24074ce3466c13852c0a88465d8c22e9536480465c1f0e6")
addappid(365302, 1, "ae6e3b73db358099568cb19ae1d376151e1d466da9282e58ccfaa80b5f7021d9")
addappid(365303, 1, "1cdd7ebc8fc5888d10caceca17c44dab713d40503ff2c38be4c60225075b7413")
