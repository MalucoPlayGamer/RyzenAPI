-- Lua provided by RyzenAPI
-- Game: Game: FURRY GIRL PUZZLE

-- MAIN APPLICATION
addappid(1101260)
-- Game: addappid(1101260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101261, 1, "4a3fcc26d39cf27bbf266b9a85b57d341b0a9ef917763bdbcd91aad91de81a4c")
