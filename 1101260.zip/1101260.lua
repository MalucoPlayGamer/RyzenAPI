-- Lua provided by RyzenAPI
-- Game: FURRY GIRL PUZZLE

-- MAIN APPLICATION
addappid(1101260)
addappid(1116940)
addappid(1193890)
addappid(1209640)
addappid(1209641)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101261,0,"4a3fcc26d39cf27bbf266b9a85b57d341b0a9ef917763bdbcd91aad91de81a4c")

