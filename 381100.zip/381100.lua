-- Lua provided by RyzenAPI
-- Game: The Men of Yoshiwara: Kikuya

-- MAIN APPLICATION
addappid(381100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(381101, 1, "cf190a0f6079deedfe7b26d14817339408d2d668a10a2aa70a2942b078632a2f")

