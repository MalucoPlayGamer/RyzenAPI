-- Lua provided by RyzenAPI
-- Game: addappid(381100)

-- MAIN APPLICATION
addappid(381100)

-- MAIN APP DEPOTS / PACKAGES
addappid(381101, 1, "cf190a0f6079deedfe7b26d14817339408d2d668a10a2aa70a2942b078632a2f")
