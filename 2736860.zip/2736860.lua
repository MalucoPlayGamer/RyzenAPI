-- Lua provided by RyzenAPI
-- Game: addappid(2736860)

-- MAIN APPLICATION
addappid(2736860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736861, 1, "2a5a24ed86a137618ed367ebba921977d20fabe27cc9dccfceb309a7b8646304")
