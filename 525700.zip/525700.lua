-- Lua provided by RyzenAPI
-- Game: Birthdays the Beginning

-- MAIN APPLICATION
addappid(525700)
addappid(610051)

-- MAIN APP DEPOTS / PACKAGES
addappid(525701, 1, "b4328f7aec070a2b2b75f0301b18029aa18675fce954e127d87c33659200a414")
addappid(570480, 0, "3bfc13df40c90c3b1c4783e891e557cdeaa205e278298463abb2bffa76f09eb5")
addappid(610040, 0, "7b1692822ca7d95838b366949af1c7be1aaa30a6c9c021d55f77ae73b8a0b396")
addappid(610050, 0, "8956256cdcec8d57efe54e712fbddf0b7c938da4053d26a93553cabbe3db2098")

