-- Lua provided by RyzenAPI
-- Game: AppID 534080

-- MAIN APPLICATION
addappid(534080)

-- MAIN APP DEPOTS / PACKAGES
addappid(534081, 1, "1c923fff6c58be039ee96ae0bd3591c6ff96279c8908f2dc3114ffad73068f81")

