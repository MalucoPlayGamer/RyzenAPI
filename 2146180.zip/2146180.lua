-- Lua provided by RyzenAPI
-- Game: Cyclo Chambers

-- MAIN APPLICATION
addappid(2146180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146181, 1, "2852c36b921da6217cb704ae18d963dcd6ef7f8de52197f3dd7071604c6e3d66")
