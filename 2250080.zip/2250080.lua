-- Lua provided by RyzenAPI 
-- Game: The Last Man Survivor
addappid(2250080)
addappid(2250081, 1, "33a51e40db645494995e7ae1b6c3e7e1891053746cb0e27fa1dc6e60052659af")
