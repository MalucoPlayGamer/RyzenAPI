-- Lua provided by RyzenAPI
-- Game: The Last Man Survivor

-- MAIN APPLICATION
addappid(2250080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250081, 1, "33a51e40db645494995e7ae1b6c3e7e1891053746cb0e27fa1dc6e60052659af")

