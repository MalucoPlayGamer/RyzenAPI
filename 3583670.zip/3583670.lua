-- Lua provided by RyzenAPI
-- Game: Where the forest ends

-- MAIN APPLICATION
addappid(3583670)
-- Game: addappid(3583670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3583671, 1, "69ed7d0427ffb4a1b1c8cc49853cfd1ef042aebb82e13a9876cda46f9fa723be")
