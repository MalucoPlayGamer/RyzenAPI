-- Lua provided by RyzenAPI
-- Game: The Final Station

-- MAIN APPLICATION
addappid(435530)

-- MAIN APP DEPOTS / PACKAGES
addappid(435531, 1, "2193dacbe2cf7de49036ef7f2fcbc2fa109b7ac2b4c4cfb69e8e45552cef77dd")
addappid(435532, 1, "5edbb70ddc0a5468c63b977d03b64276b95c601de302b8de1f4128d2049fdd71")
addappid(435533, 1, "9a641c411824bddee026b04982399a31c6fa97fbeddd58553a8a9e322adc03f1")
addappid(520500, 0, "3eb4d985dac7643b3bb631c6e690d5ecaa9064c747d5eccb0810bdb1a5dabfce")
addappid(595291, 0, "635ba7e58314c3ddf931cf45d895e9f9b5e44351b50a8c90ab11ee45065daffd")
addappid(595292, 0, "eb7577ebb21636ba25da8b0e6b291dc0192dff850abfc9a5f7e02f3816d1b513")
addappid(595293, 0, "7e436b14a60b92d278d47399008102d79585ddadb776a9d0b97437b82b5fe786")
