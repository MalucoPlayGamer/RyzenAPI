-- Lua provided by RyzenAPI
-- Game: Epic Battle Fantasy 5 Soundtrack

-- MAIN APPLICATION
addappid(971600)

-- MAIN APP DEPOTS / PACKAGES
addappid(971600,0,"a7a476c96ebfad34a5b6305e67a08c29304b260126fd1f2d886979f6f0e5bc11")
