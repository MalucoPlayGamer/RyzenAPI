-- Lua provided by RyzenAPI
-- Game: MiniTrans

-- MAIN APPLICATION
addappid(1958190)
-- Game: addappid(1958190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958191, 1, "9fe3896217741789f3aa946b9249fe0f23c026e316ea6fd21d309a5b6501e57b")
