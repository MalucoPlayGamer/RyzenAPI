-- Lua provided by RyzenAPI
-- Game: Cropdeck

-- MAIN APPLICATION
addappid(3500680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3500681,0,"23f6633875ca138f232d470ec79587fd49a336449734b36b99773549c627795c")

