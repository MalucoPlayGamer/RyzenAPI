-- Lua provided by RyzenAPI
-- Game: Hentai Story

-- MAIN APPLICATION
addappid(1029000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029001, 1, "eb823f3be9793abe2f4af48bc16f25c10e3f15f5e16ad93e42a02cef23c2ab1d")
addappid(1060650, 0, "751602c86ba00f805329631d894abf02b41fdecec203f127a1f33cce6452db0a")
addappid(1060660, 0, "9499d8f89c6f97a8868d0cb359e307035f36c9bf3c2e1a1895edd34fff494744")
