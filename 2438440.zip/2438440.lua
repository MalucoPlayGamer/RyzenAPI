-- Lua provided by RyzenAPI
-- Game: Game: Hammer of Pain

-- MAIN APPLICATION
addappid(2438440)
-- Game: addappid(2438440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438441, 1, "f8f676081de0db03b5f01c2c6f6aa76aab9577bfa96d41f88d3f33f432dcaf81")
