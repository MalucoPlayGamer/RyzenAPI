-- Lua provided by RyzenAPI
-- Game: Your Turn to Disembark

-- MAIN APPLICATION
addappid(2852390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852392,0,"7332a1d090026d3ae600d5dbaaff5145dc4de1bee91db48449f450fb1d9d9cd9")
addappid(2852393,0,"aa6ffd8db6cefb743106a4add767e75f73f43dcb869b8e0bb95b31cd1c00774c")
addappid(2852394,0,"2534ad86fe424237d18288a69d827e8d9fc886e1602ff586fb0658a3b4194d04")
