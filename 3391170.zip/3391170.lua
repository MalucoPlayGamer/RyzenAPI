-- Lua provided by RyzenAPI 
-- Game: AppID 3391170
addappid(3391170)
addappid(3391171, 1, "a7b98286951cb14cf4ae7d48a0120524bf7f6c8b5d30a3e605adb7cade528094")
