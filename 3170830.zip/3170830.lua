-- Lua provided by RyzenAPI
-- Game: Secret Cats - Zoo

-- MAIN APPLICATION
addappid(3170830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170831, 1, "1ef66ccf78c86b6449c797d8b400bfc728eddf24602da0bac07b665d01d3d51e")

