-- Lua provided by RyzenAPI
-- Game: Twenty One

-- MAIN APPLICATION
addappid(938520)
addappid(938540)

-- MAIN APP DEPOTS / PACKAGES
addappid(938521, 1, "f619b9fc95467169df0e1ae9deb4422cf5e69be796b67bc5743192817969c286")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
