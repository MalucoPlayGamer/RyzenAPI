-- Lua provided by RyzenAPI
-- Game: Game: Twenty One

-- MAIN APPLICATION
addappid(938520)
addappid(938540)
-- Game: addappid(938520)

-- MAIN APP DEPOTS / PACKAGES
addappid(938521, 1, "f619b9fc95467169df0e1ae9deb4422cf5e69be796b67bc5743192817969c286")
