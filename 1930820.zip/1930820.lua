-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1930820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930820,0,"8c8c6ac783b8508be24d93307a2a0de220bccf9ebdf0d96098703da7559d31bf")
