-- 4136730's Lua and Manifest Created by Hubcap Manifest
-- Solitaire Deck
-- Created: August 06, 2026 at 11:24:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4136730, 1, "b298df0723689e02776de380d6ecfc5884ce7cfd3efe8dd689fa55fb950cf52a") -- Solitaire Deck
-- MAIN APP DEPOTS
addappid(4136731, 1, "27102af858f3356aa149e1edbd9b14edfc326798478c3eef81cd7efa49d06191") -- Depot 4136731
setManifestid(4136731, "4241020702597530282", 342690951)
addappid(4136732, 1, "57854c08c670b681d110a4aebcea61acb525a5d56f61cc3567f3458019aa7d4d") -- Depot 4136732
setManifestid(4136732, "3614480598149138621", 325742951)