-- Lua provided by RyzenAPI
-- Game: Fluffy Developers

-- MAIN APPLICATION
addappid(2442550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442552,0,"47305f1583509291208db64d398c812770511bac371f3f966db760733ed3eb93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
