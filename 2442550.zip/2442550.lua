-- Lua provided by RyzenAPI
-- Game: Fluffy Developers

-- MAIN APPLICATION
addappid(2442550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442552,0,"47305f1583509291208db64d398c812770511bac371f3f966db760733ed3eb93")

