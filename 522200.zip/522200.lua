-- Lua provided by RyzenAPI
-- Game: Loading Human

-- MAIN APPLICATION
addappid(522200)

-- MAIN APP DEPOTS / PACKAGES
addappid(522201,0,"e2b3c6b6d95cf2fd25d7da5b47c519a3c6c2cde9a94ac9f172c7be5d0b4e980f")

