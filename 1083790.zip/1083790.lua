-- Lua provided by RyzenAPI
-- Game: Deathbulge: Battle of the Bands

-- MAIN APPLICATION
addappid(1083790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083791, 1, "47aba53ce953d1e7a5f67e4dcc8c07b09b997c5c5d10364432f38658082dd351")
addappid(1083792, 1, "f99cac391d295c36f9704433a6718c16626fa077a94cac99db4c92e1c563b0f9")
addappid(1083793, 1, "496e6426a2c450eba5958c0d08a7a01fc96ebb8ac6f806655101c3932fc8e9ee")

