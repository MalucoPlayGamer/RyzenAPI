-- Lua provided by SkyAPI 
-- Game: Monster Energy Supercross - The Official Videogame 3
addappid(1089830)
addappid(1089831, 1, "bcc54a019d621b0246fba54e163d0830a7be2e8b38ece6ceccbe96984883b745")
addappid(1182330)
addappid(1182340)
addappid(1182360)
addappid(1182380)
addappid(1182390)
addappid(1182400)
addappid(1185990)
addappid(1186000)
addappid(1186010)
