-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame 3

-- MAIN APPLICATION
addappid(1089830)
addappid(1182330)
addappid(1182340)
addappid(1182360)
addappid(1182380)
addappid(1182390)
addappid(1182400)
addappid(1185990)
addappid(1186000)
addappid(1186010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089831, 1, "bcc54a019d621b0246fba54e163d0830a7be2e8b38ece6ceccbe96984883b745")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
