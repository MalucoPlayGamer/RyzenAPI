-- Lua provided by RyzenAPI
-- Game: Aberrant Nights

-- MAIN APPLICATION
addappid(2990400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990401, 1, "329923102a8b34db2443cee3621f50b4f8d51d07aca4def58e960004e26ac743")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
