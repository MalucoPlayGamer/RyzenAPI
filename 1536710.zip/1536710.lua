-- Lua provided by RyzenAPI 
-- Game: Trail of Ayash Demo
addappid(1536710)
addappid(1536711, 1, "7232e2075938ac9bf580789aa24661980ad4608a8f54a66958a7c24c6b85c962")
