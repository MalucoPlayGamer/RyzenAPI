-- Lua provided by RyzenAPI 
-- Game: 江湖求生 Ganghood Survival
addappid(965080)
addappid(965081, 1, "6237e6828761dcb617fa6959276e78d9b416768657700a1e9dfb4a6ad3f7372a")
