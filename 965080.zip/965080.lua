-- Lua provided by RyzenAPI
-- Game: 江湖求生 Ganghood Survival

-- MAIN APPLICATION
addappid(965080)

-- MAIN APP DEPOTS / PACKAGES
addappid(965081, 1, "6237e6828761dcb617fa6959276e78d9b416768657700a1e9dfb4a6ad3f7372a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
