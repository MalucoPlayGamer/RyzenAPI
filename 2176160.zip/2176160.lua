-- Lua provided by RyzenAPI
-- Game: 2176160

-- MAIN APPLICATION
addappid(2176160)
-- Game: addappid(2176160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176161, 1, "c418aaaae48967e3fd8d9b97ae01851082005cceeaff162f5c8c4454076b75fa")
