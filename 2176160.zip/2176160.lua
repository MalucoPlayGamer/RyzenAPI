-- Lua provided by SkyAPI 
-- Game: Souls of Tartarus
addappid(2176160)
addappid(2176161, 1, "c418aaaae48967e3fd8d9b97ae01851082005cceeaff162f5c8c4454076b75fa")
