-- Lua provided by RyzenAPI
-- Game: Hunting Unlimited 1

-- MAIN APPLICATION
addappid(1267940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267941, 1, "e9147a3d886099aeb2aa2e715d2b989e7bea8891ac4a8ffb9b65489536a6c75f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
