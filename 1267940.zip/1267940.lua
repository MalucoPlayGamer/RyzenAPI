-- Lua provided by RyzenAPI
-- Game: Game: Hunting Unlimited 1

-- MAIN APPLICATION
addappid(1267940)
-- Game: addappid(1267940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267941, 1, "e9147a3d886099aeb2aa2e715d2b989e7bea8891ac4a8ffb9b65489536a6c75f")
