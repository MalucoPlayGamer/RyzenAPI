-- Lua provided by RyzenAPI
-- Game: Game: AppID 627670

-- MAIN APPLICATION
addappid(627670)
-- Game: addappid(627670)

-- MAIN APP DEPOTS / PACKAGES
addappid(627671, 1, "67b1d5b1cf3e6d6d4974ef2bb5fc72eb17cf8254ed0d5ae133814a44827fd9d4")
addappid(627672, 1, "82d48d10a408200aca37d610b26553fd948cd39b6f4f6f5804e14f2f5317adff")
addappid(627673, 1, "621438f759961a2488c2b3bc8e8be4c92bd7a42620df7349f1ffb8149eb6c9d9")
addappid(627674, 1, "51ab826e1623a5af076338abd1dc5dbd99559d2e9f9a70d4b1cd2e303a0a2e67")
