-- Lua provided by RyzenAPI
-- Game: AppID 1191620

-- MAIN APPLICATION
addappid(1191620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191621, 1, "6d2848b22b2f6d1bb4bc39bcced1f6e3ba2cd4ec5fd5d74c90f9656269cdbdf3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
