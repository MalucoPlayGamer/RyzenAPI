-- Lua provided by RyzenAPI
-- Game: addappid(1191620)

-- MAIN APPLICATION
addappid(1191620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191621, 1, "6d2848b22b2f6d1bb4bc39bcced1f6e3ba2cd4ec5fd5d74c90f9656269cdbdf3")
