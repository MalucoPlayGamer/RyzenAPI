-- Lua provided by RyzenAPI
-- Game: Game: AppID 3231980

-- MAIN APPLICATION
addappid(3231980)
-- Game: addappid(3231980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231981, 1, "cad7d8435073e3c2aa638b1d040b891d77013f786a3e77f6e0099899801cb75c")
