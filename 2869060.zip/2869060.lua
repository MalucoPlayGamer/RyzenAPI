-- Lua provided by RyzenAPI
-- Game: One Tank Army Demo

-- MAIN APPLICATION
addappid(2869060)
-- Game: addappid(2869060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869061, 1, "3754415be693552af554ee0c1f00c7c4acb362ec05d6b4c63ce69ee95b668941")
