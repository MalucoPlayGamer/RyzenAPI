-- Lua provided by RyzenAPI
-- Game: 星空列车与白的旅行 Demo

-- MAIN APPLICATION
addappid(1570870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1570871, 1, "5f897787a9ab36f3a2b0fc0b1cf5b2f3a5684a3f4dae091cc8fe830fe5c3940a")
