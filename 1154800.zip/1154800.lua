-- Lua provided by RyzenAPI
-- Game: AppID 1154800

-- MAIN APPLICATION
addappid(1154800)
-- Game: addappid(1154800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154801, 1, "95da9af8cf68ebfe7b3bd1b992619e2d6eed15b3f7fbe1a4e5675d1158b98f16")
