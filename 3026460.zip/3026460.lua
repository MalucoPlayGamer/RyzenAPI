-- Lua provided by RyzenAPI
-- Game: addappid(3026460)

-- MAIN APPLICATION
addappid(3026460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026461, 1, "b5db6551c1c7b758fce5960b8cfd6f2370f06e1986dfe39c4623a572036b4e66")
