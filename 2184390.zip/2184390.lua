-- Lua provided by RyzenAPI
-- Game: - Mischief Dungeon Life - 異世界転生した俺のイタズラダンジョンライフ Dorothy Edition

-- MAIN APPLICATION
addappid(2184390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184391, 1, "4f267c7b13981d26020b9b035ac8e67dbba43c2b8eab3a7c03e948d547af3c5a")

