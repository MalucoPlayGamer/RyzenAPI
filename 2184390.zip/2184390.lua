-- Lua provided by SkyAPI 
-- Game: - Mischief Dungeon Life - 異世界転生した俺のイタズラダンジョンライフ Dorothy Edition
addappid(2184390)
addappid(2184391, 1, "4f267c7b13981d26020b9b035ac8e67dbba43c2b8eab3a7c03e948d547af3c5a")
