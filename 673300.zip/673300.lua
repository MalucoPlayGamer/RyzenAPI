-- Lua provided by RyzenAPI
-- Game: addappid(673300)

-- MAIN APPLICATION
addappid(673300)

-- MAIN APP DEPOTS / PACKAGES
addappid(673301, 1, "a69cbc12a2c2e4361cd18f0037211251a2275c8de4a70b408bfd339af2829e5a")
