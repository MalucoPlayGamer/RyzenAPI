-- Lua provided by SkyAPI 
-- Game: The Tower
addappid(2162390)
addappid(2162391, 1, "f9a6abf20fd2134f990cbb045e1404a821d5b03ed307a3518062740dee70a646")
