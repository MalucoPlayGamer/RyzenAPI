-- Lua provided by RyzenAPI
-- Game: The Tower

-- MAIN APPLICATION
addappid(2162390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162391, 1, "f9a6abf20fd2134f990cbb045e1404a821d5b03ed307a3518062740dee70a646")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
