-- Lua provided by RyzenAPI
-- Game: Archangel

-- MAIN APPLICATION
addappid(661520)

-- MAIN APP DEPOTS / PACKAGES
addappid(661521, 1, "16a7b2ca6b332dc324d7e8fc985f6e291f193b2786bd1c407def7ea0e56789bb")
