-- Lua provided by RyzenAPI
-- Game: Game: Bleak Sword Soundtrack

-- MAIN APPLICATION
addappid(2467560)
-- Game: addappid(2467560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467561, 1, "1865161456097225e949c0c3afaf2f77222dfbafbba7791b91ef67680bed8ac0")
addappid(2467562, 1, "38fb8b124f0503f797b74c498eadf6280e06c5e393e703c9ac02f5a360725667")
