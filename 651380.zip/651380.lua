-- Lua provided by RyzenAPI
-- Game: BANG! BANG! Totally Accurate Redneck Simulator

-- MAIN APPLICATION
addappid(651380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(651381, 1, "2878985f7ecdbad76b3e4e95b05d8df46330a27eb81cce9da5465d395f3f3507")
addappid(651382, 1, "b573ea7b2706a4ebb18d25a447c2b563f193ae151fda248ea2bb8fcf2f21f5d9")
addappid(651384, 1, "4a06047df6018eb1e44b4ee6cb4436c4d4c68c6a3e8680e15f93099b5c8fb160")
addappid(651385, 1, "151fbe7b2a8e093cc14bf5be7fccdff34f8c90007613ebd946f4ebb58626606c")

