-- Lua provided by RyzenAPI 
-- Game: Doomed Lands
addappid(1611960)
addappid(1611961, 1, "72dd53f97074178ea8e54170fd914e9905b7efa3a120c932c77763d2dc347cd5")
