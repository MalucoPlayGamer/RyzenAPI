-- Lua provided by RyzenAPI
-- Game: Anicon - Animal Complex - Cat's Path

-- MAIN APPLICATION
addappid(502120)

-- MAIN APP DEPOTS / PACKAGES
addappid(502121, 1, "d87d0885657659e22d9d31e3ec11ffa954c2341bf5a76a33b761fb78505d1739")

