-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Personality Pack Overbearing and preppy girl maid

-- MAIN APPLICATION
addappid(1978030)
-- Game: addappid(1978030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978031, 1, "00a7ef5bb1966057c13745a56411c64cfb1aebb718493ac5d41d7bb7e6547be5")
addappid(1978032, 1, "a271723f52f0ac6a3a4e5abe1dc66c0d90b33e34a15339606d6aef8ed8f9e9a2")
