-- Lua provided by RyzenAPI
-- Game: Game: The Far Frontier

-- MAIN APPLICATION
addappid(612510)
-- Game: addappid(612510)

-- MAIN APP DEPOTS / PACKAGES
addappid(612511, 1, "10b12c7658be421c06324f15e17d74e103460b530399bc02c64e29964d037612")
