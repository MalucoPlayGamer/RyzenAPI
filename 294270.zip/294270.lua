-- Lua provided by RyzenAPI
-- Game: Beware Planet Earth Demo

-- MAIN APPLICATION
addappid(294270)

-- MAIN APP DEPOTS / PACKAGES
addappid(294271, 1, "337e3626e4940192d98dbe6c9329ced87f728856c4e5daed64855169f628859c")
