-- Lua provided by RyzenAPI
-- Game: 东方蝶梦志 交响组曲 ~ 梦中的钧天广乐

-- MAIN APPLICATION
addappid(941440)

-- MAIN APP DEPOTS / PACKAGES
addappid(941440,0,"6a59c1b32941d4d608c5422bbb8c630729e6546aada428c2156863b7104f6f73")

