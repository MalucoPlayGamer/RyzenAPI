-- Lua provided by RyzenAPI
-- Game: Gaming Cafe Life

-- MAIN APPLICATION
addappid(2806230)
addappid(3077450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806231, 1, "c0fd582a7a190953bc47fc5c28d4e7b78225e98e2b2246ebe9a4860bf7d013c6")

