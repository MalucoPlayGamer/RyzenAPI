-- Lua provided by RyzenAPI 
-- Game: The Red Button
addappid(2828820)
addappid(2828821, 1, "bd7fa5c7b678e078482a521a6f98d5e505d93d6edc84ed8a16de76a823f06c17")
addappid(2828822, 1, "0fca60f51a9e90ebec71b4cfa7f120c5840464891782ef4b7b83472b23cbbf58")
addappid(2828823, 1, "7c0754ead7349a28158e0f98bdcdaf7dda0e9bd1ab1388100745120ba3183840")
addappid(2834360)
