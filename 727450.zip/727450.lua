-- Lua provided by RyzenAPI
-- Game: Beats Of Fury

-- MAIN APPLICATION
addappid(727450)

-- MAIN APP DEPOTS / PACKAGES
addappid(727451, 1, "a26a258c98c252c92f2221e67e034c396a7e58aafb7260340be5abb6b0ba9c8b")

