-- Lua provided by RyzenAPI
-- Game: AMD Driver Updater, Vista and 7, 64 bit

-- MAIN APPLICATION
addappid(61810)

-- MAIN APP DEPOTS / PACKAGES
addappid(61811, 1, "def8b4b25bc60a0b2ad24634557876b726300e1575fd46818543074c5e5ad942")
