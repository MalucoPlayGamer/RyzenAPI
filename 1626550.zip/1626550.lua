-- Lua provided by SkyAPI 
-- Game: Components for Clip maker
addappid(1626550)
addappid(1626551, 1, "d8a9b0169c03bebaecc4255d580352dd1fa3966d93ee9a87fd4154d7eb4f695e")
