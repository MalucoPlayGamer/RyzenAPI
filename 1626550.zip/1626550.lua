-- Lua provided by RyzenAPI
-- Game: Game: Components for Clip maker

-- MAIN APPLICATION
addappid(1626550)
-- Game: addappid(1626550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626551, 1, "d8a9b0169c03bebaecc4255d580352dd1fa3966d93ee9a87fd4154d7eb4f695e")
