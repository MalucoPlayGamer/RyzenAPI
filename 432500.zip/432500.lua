-- Lua provided by SkyAPI 
-- Game: AppID 432500
addappid(432500)
addappid(432501, 1, "c562f51619a3ec13d95322d7d166253767345e18a5f0dae6359423da1cf42af0")
