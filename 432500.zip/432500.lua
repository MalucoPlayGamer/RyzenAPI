-- Lua provided by RyzenAPI
-- Game: AppID 432500

-- MAIN APPLICATION
addappid(432500)
-- Game: addappid(432500)

-- MAIN APP DEPOTS / PACKAGES
addappid(432501, 1, "c562f51619a3ec13d95322d7d166253767345e18a5f0dae6359423da1cf42af0")
