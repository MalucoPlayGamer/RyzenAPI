-- Lua provided by RyzenAPI
-- Game: Arizona Sunshine® VR Legacy - Wallpaper

-- MAIN APPLICATION
addappid(571770)

-- MAIN APP DEPOTS / PACKAGES
addappid(571770,0,"7a963f638f436af0df2e6c1c77d1850f2936800395aa78930f27c0b663b11349")
addtoken(571770,1749442031221877176)

