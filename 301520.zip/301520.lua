-- Lua provided by RyzenAPI
-- Game: AppID 301520

-- MAIN APPLICATION
addappid(301520)
-- Game: addappid(301520)

-- MAIN APP DEPOTS / PACKAGES
addappid(301521, 1, "ec0fbcdbed88e35a86153b5d1341d3dc834da68ab4b601f77a0947644f23dc12")
addappid(301522, 1, "e409bbbf702137de8eaef63c634464eac213cc0b2f76c215a24e16f12e80a763")
addappid(301523, 1, "e6f9458055d9469d9b03271ee77a49cabbb3b891aaa560c4a98083b6f343bbd7")
