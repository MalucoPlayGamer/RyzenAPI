-- Lua provided by RyzenAPI
-- Game: Game: Costly Adventure

-- MAIN APPLICATION
addappid(2014480)
-- Game: addappid(2014480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014481, 1, "c4c8993a56a34a6bf97d3cb947c91a700c5892dd88b45c96ec3d687388c2ee6c")
