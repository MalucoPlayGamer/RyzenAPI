-- Lua provided by RyzenAPI
-- Game: 534660

-- MAIN APPLICATION
addappid(534660)
addappid(638790)
-- Game: addappid(534660)

-- MAIN APP DEPOTS / PACKAGES
addappid(534661, 1, "ec0d75a889b36fd9454b75194ca98313e241724919e0757960c5c911e1b79e06")
