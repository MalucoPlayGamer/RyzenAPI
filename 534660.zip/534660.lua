-- Lua provided by RyzenAPI
-- Game: Lux umbra

-- MAIN APPLICATION
addappid(534660)
addappid(638790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(534661, 1, "ec0d75a889b36fd9454b75194ca98313e241724919e0757960c5c911e1b79e06")

