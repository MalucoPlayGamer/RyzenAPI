-- Lua provided by RyzenAPI
-- Game: HellCat Redux

-- MAIN APPLICATION
addappid(1114800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114801, 1, "1bbe5e1290e08bcd786f1322605d8be97a7fd4de5efc33f30e88b5d569a14aaa")

