-- Lua provided by SkyAPI 
-- Game: Twofold Demo
addappid(2509810)
addappid(2509811, 1, "c7f3207ec463a69372ae583975b117e680725621bb308fa3ab027a75200f6f6b")
