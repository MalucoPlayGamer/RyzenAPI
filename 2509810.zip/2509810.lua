-- Lua provided by RyzenAPI
-- Game: Game: Twofold Demo

-- MAIN APPLICATION
addappid(2509810)
-- Game: addappid(2509810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509811, 1, "c7f3207ec463a69372ae583975b117e680725621bb308fa3ab027a75200f6f6b")
