-- Lua provided by RyzenAPI 
-- Game: Spirit X Strike
addappid(2538880)
addappid(2538881, 1, "9506481c0c4259baed78cb030051d0756c74686ab42efba444cce3f08fad6698")
