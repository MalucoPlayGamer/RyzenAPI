-- Lua provided by RyzenAPI
-- Game: Game: Spirit X Strike

-- MAIN APPLICATION
addappid(2538880)
-- Game: addappid(2538880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538881, 1, "9506481c0c4259baed78cb030051d0756c74686ab42efba444cce3f08fad6698")
