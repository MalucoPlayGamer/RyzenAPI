-- Lua provided by RyzenAPI
-- Game: Game: Abyss: The Wraiths of Eden

-- MAIN APPLICATION
addappid(284710)
-- Game: addappid(284710)

-- MAIN APP DEPOTS / PACKAGES
addappid(284711, 1, "f8e2bf4ef6ebe8d50907607d29ed292e2e2730e1123952114d7719b2728ad2db")
addappid(284712, 1, "6d0d1dfd8f4033d8773d230c7b75039f9b43e6ccef15609f6c8b3d4f6d28078c")
addappid(284713, 1, "f1594a2f6050a2d269833af3ff98b1e966b15cb8a7b99e5ee7e9c893a1021403")
