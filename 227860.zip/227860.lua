-- Lua provided by RyzenAPI
-- Game: Castle Story

-- MAIN APPLICATION
addappid(227860)
addappid(758720)

-- MAIN APP DEPOTS / PACKAGES
addappid(227861, 1, "a7d6610e54c2276d32a33b580f331e1caead53b570eab42ecc6c9c79719e2a94")
addappid(227862, 1, "49082a946472ebee1b1eed09e9bee14a413b03aac312cf36ddc4eedc826ed6db")
addappid(227863, 1, "c0221a1b6ff386b1b1f93b24e09f37b17361f2d0349abae3d747a7fff10f5ddd")
addappid(227864, 1, "2373619c642a3f847af520eaafcb6b98a5b04bfc36610a7a5fc46641775c5cb7")
addappid(227865, 1, "e9c6c1eebe4cca5de1f69483fe6727da4179f593f81046db0684e96351cb47ef")
addappid(227866, 1, "86114c6dad563bf4c74072a8985d6a68fc5b6d4e56cd6f33a222b312df065fc4")

