-- Lua provided by RyzenAPI
-- Game: addappid(2287520)

-- MAIN APPLICATION
addappid(2287520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287521, 1, "a7d107435e6dce4ba92250a6ae5b0df38e5adcb5254289c5c7633489a01afaa8")
