-- Lua provided by RyzenAPI
-- Game: Five Nights at Freddy's: Help Wanted 2

-- MAIN APPLICATION
addappid(2287520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287521, 1, "a7d107435e6dce4ba92250a6ae5b0df38e5adcb5254289c5c7633489a01afaa8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
