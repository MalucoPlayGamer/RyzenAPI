-- Lua provided by RyzenAPI
-- Game: Touhou Artificial Dream in Arcadia Demo

-- MAIN APPLICATION
addappid(2257020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257021, 1, "c9348b3377f938555f9bb2363f8e703076897c8249d2539e4566c1a28dc3d739")
