-- Lua provided by RyzenAPI
-- Game: A Solitaire Mystery

-- MAIN APPLICATION
addappid(3743220)
-- Game: addappid(3743220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3743222,0,"66d99230b885450aa77e941f79333f71fa34472861fa6df267f87f4894039880")
