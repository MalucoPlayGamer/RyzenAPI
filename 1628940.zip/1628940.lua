-- Lua provided by RyzenAPI
-- Game: Street Striker

-- MAIN APPLICATION
addappid(1628940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628941, 1, "3195c84946b0dc59f939cb127060111a91443c860b7cd0402b7942eea57f6d9f")

