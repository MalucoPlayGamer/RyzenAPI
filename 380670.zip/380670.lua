-- Lua provided by RyzenAPI
-- Game: addappid(380670)

-- MAIN APPLICATION
addappid(380670)

-- MAIN APP DEPOTS / PACKAGES
addappid(380671, 1, "de0559fe161bea4ee10000b090c8cb8b5a26d885c593e93087e11e3833408bfc")
