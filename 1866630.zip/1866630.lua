-- Lua provided by RyzenAPI
-- Game: 1866630

-- MAIN APPLICATION
addappid(1866630)
-- Game: addappid(1866630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866631, 1, "8d4e37a64792e7272d0464ae8d793f8702fe1c24ede24f8185060fc493e896ff")
