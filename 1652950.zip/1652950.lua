-- Lua provided by RyzenAPI
-- Game: addappid(1652950)

-- MAIN APPLICATION
addappid(1652950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652951, 1, "263187e0eeef61b95736f31b78a4f77d38af4e5be98f46654d6cd0bcb907247e")
