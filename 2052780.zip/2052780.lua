-- Lua provided by RyzenAPI
-- Game: Painter Simulator

-- MAIN APPLICATION
addappid(2052780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052781, 1, "e572acd9804a4e9ab68bfa20b790a52a61d02ecbcb1f10418f1455f71d9c6f5f")

