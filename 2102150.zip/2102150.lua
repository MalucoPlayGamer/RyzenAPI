-- Lua provided by SkyAPI 
-- Game: JuXiaoYou
addappid(2102150)
addappid(2102151, 1, "0d0a2dbad7c6efb7b550547d20c15e45291edd5f7cb00011b1090c29b0d0dba3")
