-- Lua provided by RyzenAPI
-- Game: Poker Train

-- MAIN APPLICATION
addappid(3149430)
addappid(3383310)
-- Game: addappid(3149430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3149431, 1, "5696c69f8a1904765464fcfa5f9247d38d43b80cc04495b7000b1781c9d539ed")
addappid(3149432, 1, "cab4c620b0a26dc46e717a6c4522d2f30f4e71015a1f51e170e95d9cb5402e67")
addappid(3149433, 1, "9dd25f7772a76353cf4ae1b4c39acc4154458ef45fc43bb0ce37a72ce1d5e15e")
