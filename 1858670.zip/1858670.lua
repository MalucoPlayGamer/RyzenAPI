-- Lua provided by RyzenAPI
-- Game: Mocap Fusion [ VR ] Playtest

-- MAIN APPLICATION
addappid(1858670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858671, 1, "526617096584690dffa256a05df14ede6e48fa9583b0cf0248ed91e77718b69e")
