-- Lua provided by SkyAPI 
-- Game: Mocap Fusion [ VR ] Playtest
addappid(1858670)
addappid(1858671, 1, "526617096584690dffa256a05df14ede6e48fa9583b0cf0248ed91e77718b69e")
