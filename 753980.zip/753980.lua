-- Lua provided by RyzenAPI
-- Game: ARK -the lost fairytale-

-- MAIN APPLICATION
addappid(753980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(753981, 1, "f98a467d73ec49fc735a68753351e6bac6953d27a59eec0dd01abd98b4958291")
addappid(753983, 1, "83df0234545126cfe3d067317b8ff61f4d8e961dfb4e15e43fea1f4d0b71bcdf")

