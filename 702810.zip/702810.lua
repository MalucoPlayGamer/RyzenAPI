-- Lua provided by RyzenAPI
-- Game: AppID 702810

-- MAIN APPLICATION
addappid(702810)
addappid(865120)
addappid(870460)
addappid(870461)
addappid(870462)
-- Game: addappid(702810)

-- MAIN APP DEPOTS / PACKAGES
addappid(702811, 1, "facb38fd884a11d65f837e5164aa78427bab12dadafda3543bc3069d6aa53776")
addappid(702812, 1, "8c61b5dc517248e0e07a1df87464bda046631347d4238fbbe053b4aa725fcdc6")
addappid(702813, 1, "966484a94cd98b999fe45eecc2624b070d114c7e9e37b3cd9c13b461754a42e9")
addappid(850990, 0, "39a026ef76686168badcaf887e0924a866ffeb3a18aac2223176bfbd6ce4e0ce")
