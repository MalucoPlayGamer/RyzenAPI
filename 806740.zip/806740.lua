-- Lua provided by RyzenAPI
-- Game: Game: AppID 806740

-- MAIN APPLICATION
addappid(806740)
-- Game: addappid(806740)

-- MAIN APP DEPOTS / PACKAGES
addappid(806741, 1, "62e708e853a50ee07335b03e3a5bff7e27071b9704f6401582b25b7f517299ec")
