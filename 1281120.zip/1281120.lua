-- Lua provided by RyzenAPI
-- Game: Desktop Agents - Cov1d-999 Soundtrack

-- MAIN APPLICATION
addappid(1281120)
-- Game: addappid(1281120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281121, 1, "9e39c871e85da7db7e47893569e6d33a0a9aede20fe8a0472059e99fded21350")
