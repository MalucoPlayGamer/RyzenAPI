-- Lua provided by RyzenAPI
-- Game: 2335580

-- MAIN APPLICATION
addappid(2335580)
-- Game: addappid(2335580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335581, 1, "c8ced43bced5cb32218fbcd97650816397db9c018c15a012b43a26d8f6cd12e0")
