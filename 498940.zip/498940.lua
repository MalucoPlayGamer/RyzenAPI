-- Lua provided by RyzenAPI
-- Game: AppID 498940

-- MAIN APPLICATION
addappid(498940)
-- Game: addappid(498940)

-- MAIN APP DEPOTS / PACKAGES
addappid(498941, 1, "d4204c8114d003c7a96e078c37122154f26f3a2be0034476e4ded365b0cc9bc2")
