-- Lua provided by RyzenAPI 
-- Game: Collapsed Galaxy 2 Demo
addappid(3266430)
addappid(3266431, 1, "7c18bc21f6ac0c1683aacddb9ed1892e951b7af7534da34e373813e806df3cba")
