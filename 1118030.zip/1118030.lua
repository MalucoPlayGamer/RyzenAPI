-- Lua provided by SkyAPI 
-- Game: AppID 1118030
addappid(1118030)
addappid(1118031, 1, "51f7171ec224e8ec01ce5134d20e868c5d84b8acc8d5b6ba1e1d0ffcc382962b")
