-- Lua provided by RyzenAPI
-- Game: jut

-- MAIN APPLICATION
addappid(1135030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135031, 1, "fe99ee4f0b95e0ec32bf9dc99c5c138a5b3f6bf1ea3f238302b37200d3ac8662")

