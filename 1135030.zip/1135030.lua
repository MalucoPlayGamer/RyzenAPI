-- Lua provided by RyzenAPI
-- Game: Game: jut

-- MAIN APPLICATION
addappid(1135030)
-- Game: addappid(1135030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135031, 1, "fe99ee4f0b95e0ec32bf9dc99c5c138a5b3f6bf1ea3f238302b37200d3ac8662")
