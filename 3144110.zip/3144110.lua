-- Lua provided by RyzenAPI
-- Game: Game: Journey Up

-- MAIN APPLICATION
addappid(3144110)
-- Game: addappid(3144110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144111, 1, "334d0629087bc27c71ec099548ad8d97a191600e2022a319e8cbcaacc5c75818")
