-- Lua provided by RyzenAPI
-- Game: Rap Attack!

-- MAIN APPLICATION
addappid(2420300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420301, 1, "f98362888bab878ab77e439f249c9e5f46fb6aa7edaa8be194afff5031e93cab")
