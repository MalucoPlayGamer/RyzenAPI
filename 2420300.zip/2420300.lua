-- Lua provided by SkyAPI 
-- Game: Rap Attack!
addappid(2420300)
addappid(2420301, 1, "f98362888bab878ab77e439f249c9e5f46fb6aa7edaa8be194afff5031e93cab")
