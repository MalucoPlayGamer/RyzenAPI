-- Lua provided by RyzenAPI
-- Game: The Lustful Inn of Female Adventurers

-- MAIN APPLICATION
addappid(3461630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461632,0,"432a75b0cea646e2f18373c85659ff12173f0cf24d6c88259bd25842c429bdda")
addappid(3461633,0,"bff669ee5925946a5aef150717128bccf3fdd0a58eaeadb5917966ca9e152249")
addappid(3461634,0,"dc43655df7cea7d677d516264c52f4f713a529974f4521b1d69820c1c63775b3")
