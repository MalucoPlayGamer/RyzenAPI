-- Lua provided by RyzenAPI 
-- Game: The Medium
addappid(1293160)
addappid(1293161, 1, "5261913c3ae6ee50735867bb7fc85b75f42a052c2303e0f32dc2e25600439b41")
addappid(1293163, 1, "3a54fcfaa0c5a1d83f08ce3122893b4515ed2865b055a5481e6d54eb439cb27b")
