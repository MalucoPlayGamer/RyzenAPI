-- Lua provided by RyzenAPI
-- Game: The Medium

-- MAIN APPLICATION
addappid(1293160)
addappid(1369030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1293161, 1, "5261913c3ae6ee50735867bb7fc85b75f42a052c2303e0f32dc2e25600439b41")
addappid(1293163, 1, "3a54fcfaa0c5a1d83f08ce3122893b4515ed2865b055a5481e6d54eb439cb27b")

