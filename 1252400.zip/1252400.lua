-- Lua provided by RyzenAPI
-- Game: 1252400

-- MAIN APPLICATION
addappid(1252400)
-- Game: addappid(1252400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252401, 1, "fd1e001fede00fe25f4301863bcad8e94a06bbe81432024b478bbca66931a6ae")
