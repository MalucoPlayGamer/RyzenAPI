-- Lua provided by RyzenAPI
-- Game: Discord Rich Me! Engine

-- MAIN APPLICATION
addappid(1252400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252401, 1, "fd1e001fede00fe25f4301863bcad8e94a06bbe81432024b478bbca66931a6ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
