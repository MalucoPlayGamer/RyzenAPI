-- Lua provided by SkyAPI 
-- Game: Azure Sky Project
addappid(712650)
addappid(712651, 1, "c25d38d2636828b79f3c6992a0eabef8745aba441c8c626568de6e8681535771")
