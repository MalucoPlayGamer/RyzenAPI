-- Lua provided by RyzenAPI
-- Game: addappid(712650)

-- MAIN APPLICATION
addappid(712650)

-- MAIN APP DEPOTS / PACKAGES
addappid(712651, 1, "c25d38d2636828b79f3c6992a0eabef8745aba441c8c626568de6e8681535771")
