-- Lua provided by RyzenAPI
-- Game: Blood Vial

-- MAIN APPLICATION
addappid(3648730)
-- Game: addappid(3648730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648731, 1, "5c7ee6509cc9d6912b7177d781e891336a89c2353db00750b26a6192075bf3ed")
