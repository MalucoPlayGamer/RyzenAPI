-- Lua provided by RyzenAPI
-- Game: 1911390

-- MAIN APPLICATION
addappid(1911390)
-- Game: addappid(1911390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911391, 1, "ae3e7cf499245c2fa22cacaff4d8ab7a3198b455bd8f3ef948d5fd6affcbd81a")
