-- Lua provided by RyzenAPI
-- Game: Jumping Over It With Kang KiYun

-- MAIN APPLICATION
addappid(1107210)
-- Game: addappid(1107210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107211, 1, "465d29fdaba03fde7b5644a5bf65f886bd00a347a4b8661c76d8808153e4d44d")
