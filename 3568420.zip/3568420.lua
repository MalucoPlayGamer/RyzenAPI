-- Lua provided by RyzenAPI
-- Game: Crown of Chaos

-- MAIN APPLICATION
addappid(3568420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568421, 1, "71d8aca43e92f64569e6ca2182abe0f75ab62ffe4508ee77ee38112a310a362d")
