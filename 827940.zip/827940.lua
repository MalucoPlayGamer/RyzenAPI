-- Lua provided by RyzenAPI
-- Game: Marvellous Inc.

-- MAIN APPLICATION
addappid(827940)
addappid(2764520)

-- MAIN APP DEPOTS / PACKAGES
addappid(827941,0,"0d766e7bf5a627549beca68f22b6c4d4767a34beeafd0a730a208d4d1eb47da2")
addappid(827943,0,"1cd068da48a2a0089807761bec01a5dc668eac11f907128c96d60f5ff5a5e8e3")
addappid(827944,0,"d639fe5c14c255ba8c2d4dbb12d2cb9d1fa81fafe61425686643293ccf5f66c9")

