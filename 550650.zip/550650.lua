-- Lua provided by RyzenAPI
-- Game: Black Squad

-- MAIN APPLICATION
addappid(654170) -- Black Squad - EA FREE TIMED WEAPON PACKAGE 1
addappid(654171) -- Black Squad - EA FREE TIMED WEAPON PACKAGE 2
addappid(654172) -- Black Squad - FOUNDERS PACKAGE
addappid(654173) -- Blacksquad - AK12 FIRST RELEASE PACKAGE
addappid(654174) -- Black Squad - EA FREE TIMED WEAPON PACKAGE 3
addappid(654175) -- Blacksquad - S15 FIRST RELEASE PACKAGE
addappid(654176) -- Blacksquad - M4 CUSTOM FIRST RELEASE PACKAGE
addappid(654180) -- Black Squad - Welcome Fortune Box
addappid(654181) -- Blacksquad - AXMC FIRST RELEASE PACKAGE
addappid(654183) -- Blacksquad - SIZ556XI RUS FIRST RELEASE PACKAGE
addappid(654185) -- Blacksquad - HNK416A5 FIRST RELEASE PACKAGE
addappid(654186) -- Blacksquad - AEK973 FIRST RELEASE PACKAGE
addappid(654187) -- Black Squad - EA FREE TIMED WEAPON PACKAGE 4
addappid(654188) -- Black Squad - M40A5 FIRST RELEASE PACKAGE
addappid(654189) -- Black Squad - 1ST YEAR ANNIVERSARY PACKAGE
addappid(1034450) -- Black Squad - M4A1 FIRST RELEASE PACKAGE
addappid(1053260) -- Black Squad - AK74M FIRST RELEASE PACKAGE
addappid(1106070) -- Black Squad - START UP PACKAGE
addappid(1710430) -- Black Squad - 4TH YEAR ANNIVERSARY PACKAGE

-- MAIN APP DEPOTS / PACKAGES
addappid(550650, 1, "3c15e8a291ceb30459c0aa01e945504d18ab14ce9740daca4d74aaee94856ee6") -- Black Squad
addappid(550651, 1, "ec537a88c8f574789b198a88f8dda212dee70f249d7ed3162e5143a4e354a827") -- Black Squad Content
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
