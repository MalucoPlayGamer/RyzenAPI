-- Lua provided by RyzenAPI
-- Game: Game: AppID 550650

-- MAIN APPLICATION
addappid(550650)
-- Game: addappid(550650)

-- MAIN APP DEPOTS / PACKAGES
addappid(550651, 1, "ec537a88c8f574789b198a88f8dda212dee70f249d7ed3162e5143a4e354a827")
