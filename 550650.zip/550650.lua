-- Lua provided by RyzenAPI
-- Game: Black Squad

-- MAIN APPLICATION
addappid(550650)
addappid(654173)
addappid(654174)
addappid(654175)
addappid(654176)
addappid(654180)
addappid(654181)
addappid(654183)
addappid(654185)
addappid(654186)
addappid(654187)
addappid(654188)
addappid(654189)
addappid(1034450)
addappid(1053260)
addappid(1106070)
addappid(1710430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(550651, 1, "ec537a88c8f574789b198a88f8dda212dee70f249d7ed3162e5143a4e354a827")
