-- Lua provided by RyzenAPI
-- Game: setManifestid(1641932,"3761884879134901842")

-- MAIN APPLICATION
addappid(1641930)
-- Game: addappid(1641930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641932,0,"8b6af9a1a21dd0bf4d882261718235adee19fb38d4c80bba99fc1f45c01cc8d6")
