-- Lua provided by RyzenAPI
-- Game: Game: Tornado Driver

-- MAIN APPLICATION
addappid(1328050)
-- Game: addappid(1328050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328051, 1, "2cc731ce07ebe5d9bef261ef9567701b878e540e1eb573c544b3a685b49de2e8")
