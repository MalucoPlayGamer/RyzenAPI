-- Lua provided by RyzenAPI
-- Game: Game: Paralives

-- MAIN APPLICATION
addappid(1118520)
-- Game: addappid(1118520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118521, 1, "20543823281f3ef968fcd728fafb6786a33991bb918fbce88cd0a5c7fa49eb5a")
