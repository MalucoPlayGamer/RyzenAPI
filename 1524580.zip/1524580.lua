-- Lua provided by SkyAPI 
-- Game: Dual Cars
addappid(1524580)
addappid(1524581, 1, "b75d533c2ddcc05695e59163aab3788be2654b9fe2ea7715eba876e86b226404")
