-- Lua provided by RyzenAPI
-- Game: Astra And The New Constellation

-- MAIN APPLICATION
addappid(2425010)
-- Game: addappid(2425010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425014,0,"d088e2df22a04b069eb02c6bc42f436bc35a949eda318c8c27537a931c5b874f")
