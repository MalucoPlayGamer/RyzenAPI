-- Lua provided by RyzenAPI
-- Game: Game: AppID 921780

-- MAIN APPLICATION
addappid(921780)
-- Game: addappid(921780)

-- MAIN APP DEPOTS / PACKAGES
addappid(921781, 1, "a169665f590152ae69940ea94710634aafbd5eb08429442d6641bc7c251967e9")
