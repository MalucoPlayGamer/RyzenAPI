-- Lua provided by RyzenAPI
-- Game: The Dark Occult

-- MAIN APPLICATION
addappid(921780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(921781, 1, "a169665f590152ae69940ea94710634aafbd5eb08429442d6641bc7c251967e9")

