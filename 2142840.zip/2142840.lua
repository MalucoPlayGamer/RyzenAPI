-- Lua provided by RyzenAPI
-- Game: Light of Alariya

-- MAIN APPLICATION
addappid(2142840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2142841, 1, "bfe5d4463a393fb4c3be028cd94e0482deec8d326f523961789656c4a7b321bf")

