-- Lua provided by SkyAPI 
-- Game: Light of Alariya
addappid(2142840)
addappid(2142841, 1, "bfe5d4463a393fb4c3be028cd94e0482deec8d326f523961789656c4a7b321bf")
