-- Lua provided by RyzenAPI
-- Game: Conquest Emperor

-- MAIN APPLICATION
addappid(1934930)
-- Game: addappid(1934930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934931, 1, "dfabc1288adf4975ed8739b4b7d31bd06394c5fce589e92b36ef346f3cc66fb0")
addappid(2076370, 0, "2a19a2ffcee93abb2193e8a510d564d4a2ac086d373284b28e3a3574d57e4a67")
addappid(2133470, 0, "153ea9784ce8754a144417c91e158418c9d5607552fba7a78d77997484b7b666")
