-- Lua provided by RyzenAPI
-- Game: Half-Life 2: VR Mod - Episode Two

-- MAIN APPLICATION
addappid(2177760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177761, 1, "3a37be88826675188311cffec8a127c4f7a1546ae77a5beb332f8a338bde7ef1")
addappid(2177762, 1, "d21cde0b688050c003e84fc86fadda7632bc8ee95f263db3ed7905575864b787")
addappid(2177763, 1, "82b073ec013215b549cfcc724652bfc3083ce68658f8a521cfb792b9ade998ec")
addappid(2177764, 1, "baf4527ec91de3d8f673f684b107a5817e8fbfb28c388dab8ce08c3718041633")
addappid(2177765, 1, "4c65a42994110da0af15bc299ef88da1c95fc4a0a54486373df9d05a40e1680b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
