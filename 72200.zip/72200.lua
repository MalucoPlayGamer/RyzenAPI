-- Lua provided by RyzenAPI
-- Game: addappid(72200)

-- MAIN APPLICATION
addappid(72200)

-- MAIN APP DEPOTS / PACKAGES
addappid(72201, 1, "dc3bbd4eb85201e1e8d1d9c58ef85793b5977d37f452258f50c7113b5ad10946")
