-- Lua provided by RyzenAPI
-- Game: Nova: Space Armada

-- MAIN APPLICATION
addappid(1108270)

