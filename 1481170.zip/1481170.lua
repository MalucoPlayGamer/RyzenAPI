-- Lua provided by RyzenAPI
-- Game: ZEPHON

-- MAIN APPLICATION
addappid(1481170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481171, 1, "ab7865cbd2a8f2f7849cbd33921b1240846241cb2d269f9aacb275fe03a08147")
addappid(1481172, 1, "9a3ffa2d182a63014568fa620607a4f6f2d873b15ed7dea23b6918c5bcea5d69")
addappid(3301470, 0, "78e7364c6c382811cee9ac213efb1422278b33d673aa157271f30f2c3679d6c2")
addappid(3607430, 0, "c19547136da494638305653481437fe3d585d1c6f9cf3a268a5f2f697b5b00f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3301460)
addappid(4046850)
addappid(4559600)
