-- Lua provided by RyzenAPI
-- Game: Amidst The Darkness

-- MAIN APPLICATION
addappid(1680280)
-- Game: addappid(1680280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680281, 1, "b96961d3bf831de2dbc3720045091f9c1bf7601acc3fa57d4332b682d2d99bed")
