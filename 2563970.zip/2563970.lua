-- Lua provided by RyzenAPI
-- Game: Game: AppID 2563970

-- MAIN APPLICATION
addappid(2563970)
-- Game: addappid(2563970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563971, 1, "06802822a60598751d0c2c96a8426feb87471d54428c31f02eb34ee4ae01a1a9")
