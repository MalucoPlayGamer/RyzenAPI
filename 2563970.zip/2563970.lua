-- Lua provided by RyzenAPI
-- Game: Sky: Children of the Light Demo

-- MAIN APPLICATION
addappid(2563970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563971, 1, "06802822a60598751d0c2c96a8426feb87471d54428c31f02eb34ee4ae01a1a9")
