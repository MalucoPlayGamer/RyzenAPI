-- Lua provided by SkyAPI 
-- Game: AppID 277990
addappid(277990)
addappid(277991, 1, "8c6869d522fa12094fbfa0d9d10ef7651b979e9ad1ae75348072f27ebfac9dd3")
