-- Lua provided by RyzenAPI
-- Game: Car Mechanic Simulator 2014 Demo

-- MAIN APPLICATION
addappid(277990)

-- MAIN APP DEPOTS / PACKAGES
addappid(277991, 1, "8c6869d522fa12094fbfa0d9d10ef7651b979e9ad1ae75348072f27ebfac9dd3")

