-- Lua provided by RyzenAPI
-- Game: 1218200

-- MAIN APPLICATION
addappid(1218200)
-- Game: addappid(1218200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218201, 1, "0a50ee910e156424650f30432aa7f75c50f6513f58897ffc1a66edf3c5705b7f")
