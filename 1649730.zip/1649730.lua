-- Lua provided by RyzenAPI
-- Game: xiuzhen idle

-- MAIN APPLICATION
addappid(1649730)
addappid(2426820)
addappid(2811350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649731, 1, "b1f84051977044c0ca948f11298f7dff38f2f61e6965b33ca61a135770d24225")
addappid(1649732, 1, "b318c8c28a77d6aee5741bb0ca5ec9667d84778c62dfd6d21aa1392c8671920a")

