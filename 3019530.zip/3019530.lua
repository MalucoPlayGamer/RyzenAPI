-- Lua provided by RyzenAPI
-- Game: Game: 去码头整点薯条！ Demo

-- MAIN APPLICATION
addappid(3019530)
-- Game: addappid(3019530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019531, 1, "c25cd84ef08c76551182a752666309e20631a13563e5180f43997458f82c90b6")
