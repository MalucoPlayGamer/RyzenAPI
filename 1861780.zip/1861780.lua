-- Lua provided by RyzenAPI
-- Game: Psychic

-- MAIN APPLICATION
addappid(1861780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861781, 1, "ecc0428370cee04858d0be15cd249a7d8e553ef86cca30c9b774d38128ab77b5")
