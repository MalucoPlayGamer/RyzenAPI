-- Lua provided by RyzenAPI
-- Game: Viking Story

-- MAIN APPLICATION
addappid(1548930)
-- Game: addappid(1548930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548931, 1, "a7505015b1572322875948836c681e607ca4ab35a1fc90985d6883354485d8cc")
