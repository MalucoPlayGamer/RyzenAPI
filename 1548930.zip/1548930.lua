-- Lua provided by SkyAPI 
-- Game: Viking Story
addappid(1548930)
addappid(1548931, 1, "a7505015b1572322875948836c681e607ca4ab35a1fc90985d6883354485d8cc")
