-- Lua provided by RyzenAPI
-- Game: AppID 2766100

-- MAIN APPLICATION
addappid(2766100)
-- Game: addappid(2766100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766101, 1, "ce3fe54fc825d760b2b5de38dfca051b6fda3c6667326a9fd3ccb1f49117939c")
