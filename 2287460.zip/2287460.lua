-- Lua provided by RyzenAPI
-- Game: Game: Bleak Sword DX Demo

-- MAIN APPLICATION
addappid(2287460)
-- Game: addappid(2287460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287461, 1, "0392975ab35f87cea7ceba7d7e0a8b0bfb47d3ad789de51b152a6b1bf9d6cd7b")
