-- Lua provided by RyzenAPI
-- Game: Cavern of Dreams

-- MAIN APPLICATION
addappid(2059660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059661, 1, "00e3ba6fdf8a430f900ccd13522c7f9d835a4b7e9403fc64863c768b59db595a")

