-- Lua provided by RyzenAPI
-- Game: addappid(824600)

-- MAIN APPLICATION
addappid(824600)

-- MAIN APP DEPOTS / PACKAGES
addappid(824601, 1, "ff5fa9dd3f22286f54d972522560bc51f5bc451817ffd0ad40a2c1d7829212d1")
