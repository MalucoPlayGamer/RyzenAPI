-- Lua provided by RyzenAPI
-- Game: loathe the game

-- MAIN APPLICATION
addappid(1209300)
-- Game: addappid(1209300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209301, 1, "953a67b854557eb8b11feac1d60698719a74744ace1f6d71af0685e4badb21bc")
