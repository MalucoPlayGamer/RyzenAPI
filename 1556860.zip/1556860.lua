-- Lua provided by RyzenAPI
-- Game: Game: Role Player: Full Immersion

-- MAIN APPLICATION
addappid(1556860)
-- Game: addappid(1556860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556861, 1, "196ee3f5a762746603221198b1eb9a76a6c8ee27eb7428fdeb355d5a901c2313")
