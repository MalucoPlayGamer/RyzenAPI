-- Lua provided by SkyAPI 
-- Game: Pretty Agent
addappid(3085700)
addappid(3085701, 1, "4fe29abd60c6040bf2042438048b31e3232da1f78de6b7fca1257015f25b9d30")
