-- Lua provided by RyzenAPI
-- Game: 3085700

-- MAIN APPLICATION
addappid(3085700)
-- Game: addappid(3085700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085701, 1, "4fe29abd60c6040bf2042438048b31e3232da1f78de6b7fca1257015f25b9d30")
