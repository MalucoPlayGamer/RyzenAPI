-- Lua provided by RyzenAPI
-- Game: Nimbatus - The Space Drone Constructor

-- MAIN APPLICATION
addappid(383840)
-- Game: addappid(383840)

-- MAIN APP DEPOTS / PACKAGES
addappid(383842,0,"14941a06df762284e30b797cf117b2bf91b7333a8056b58bba8a9097fdbea123")
addappid(383843,0,"99cb3c58479cead8de6cab6424d39dc6779c66d3ef30abbddfe3babda51e3a33")
addappid(383844,0,"7b09c45efd6b6c006d1c2c1a55fa61aa517b51a17235fd9d1259c027da3c8c92")
addappid(383845,0,"691e9ee871816abc57a8d833ad61b52fc1726ce7441b33a46677f173a6e45fbc")
