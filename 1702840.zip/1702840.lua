-- Lua provided by RyzenAPI
-- Game: 1702840

-- MAIN APPLICATION
addappid(1702840)
-- Game: addappid(1702840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702841, 1, "22fbaab28139f194eba53cd5325da04c41577622b228f833ace7487c9314ab2a")
