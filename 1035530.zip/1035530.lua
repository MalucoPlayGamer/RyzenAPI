-- Lua provided by RyzenAPI
-- Game: Disobedient Sheep

-- MAIN APPLICATION
addappid(1035530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035531, 1, "f979640c9aaf91de19487a01772ddb9d7c12bf72a58ee6b38ce598d3afe30865")

