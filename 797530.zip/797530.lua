-- Lua provided by RyzenAPI
-- Game: addappid(797530)

-- MAIN APPLICATION
addappid(797530)

-- MAIN APP DEPOTS / PACKAGES
addappid(797531, 1, "d14a53fcadec4a8119b111c7b471b6266f28251bd20334fdef6f80e7aede846e")
