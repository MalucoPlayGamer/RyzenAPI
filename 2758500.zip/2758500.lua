-- Lua provided by SkyAPI 
-- Game: Anime vs Evil: Apocalypse Demo
addappid(2758500)
addappid(2758501, 1, "0f0ca37a13d677a36bea8aee6fc1469932eadc51fd06d9662aa5d1182159bb66")
