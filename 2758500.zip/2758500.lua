-- Lua provided by RyzenAPI
-- Game: Anime vs Evil: Apocalypse Demo

-- MAIN APPLICATION
addappid(2758500)
-- Game: addappid(2758500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758501, 1, "0f0ca37a13d677a36bea8aee6fc1469932eadc51fd06d9662aa5d1182159bb66")
