-- Lua provided by RyzenAPI
-- Game: addappid(874110)

-- MAIN APPLICATION
addappid(874110)

-- MAIN APP DEPOTS / PACKAGES
addappid(874111, 1, "17af8bb649bd025e802e6b5fe9d677d9759392b42cca72b935f82bc3bd9c6444")
