-- Lua provided by RyzenAPI
-- Game: The Island: Into The Mist

-- MAIN APPLICATION
addappid(941650)
addappid(1020230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(941651, 1, "350fd09e6bcbd404c3d7c86782c8169e040bc7df161fdd815470701609dcfb07")

