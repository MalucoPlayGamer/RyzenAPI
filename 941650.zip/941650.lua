-- Lua provided by RyzenAPI
-- Game: The Island: Into The Mist

-- MAIN APPLICATION
addappid(941650)

-- MAIN APP DEPOTS / PACKAGES
addappid(941651, 1, "350fd09e6bcbd404c3d7c86782c8169e040bc7df161fdd815470701609dcfb07")

