-- Lua provided by RyzenAPI 
-- Game: Hentai Magic
addappid(3729020)
addappid(3729021, 1, "6d87c554216c3554a59ebee51b2ee3f25cd810330e69fb36069f1258de17c72b")
