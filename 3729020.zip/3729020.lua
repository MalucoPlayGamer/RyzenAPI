-- Lua provided by RyzenAPI
-- Game: 3729020

-- MAIN APPLICATION
addappid(3729020)
-- Game: addappid(3729020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729021, 1, "6d87c554216c3554a59ebee51b2ee3f25cd810330e69fb36069f1258de17c72b")
