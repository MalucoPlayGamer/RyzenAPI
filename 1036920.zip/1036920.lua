-- Lua provided by RyzenAPI
-- Game: Game: DooM in the Dark

-- MAIN APPLICATION
addappid(1036920)
-- Game: addappid(1036920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036921, 1, "ca07587d244a7ceb48a4f7c39133f79c31805226e5b97b2d4760457e0d717d2d")
