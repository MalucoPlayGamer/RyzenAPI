-- Lua provided by RyzenAPI
-- Game: DooM in the Dark

-- MAIN APPLICATION
addappid(1036920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036921, 1, "ca07587d244a7ceb48a4f7c39133f79c31805226e5b97b2d4760457e0d717d2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
