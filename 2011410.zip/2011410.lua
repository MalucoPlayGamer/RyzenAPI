-- Lua provided by RyzenAPI
-- Game: Monstrous Love

-- MAIN APPLICATION
addappid(2011410)
-- Game: addappid(2011410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011411, 1, "2878adc34d0ca705f90d97d75f1af3aab3cd4214ea25f0edce223a5773632335")
addappid(2011412, 1, "2531cc8253a956bd40d1681adaccaca68df608a2201f0868c21857448526193e")
addappid(2011413, 1, "114c21394d9183dc1f26fc1b09d173818d3e65667a5ef07d2ed4fe519badea22")
addappid(2643760, 0, "bf5f2c751568bd5c169ebc2cc02464d1f428bcec8737868bc5676df2147c2fca")
