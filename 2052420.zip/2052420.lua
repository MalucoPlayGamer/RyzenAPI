-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - TRIDOME: Explorative-Platformer Sample

-- MAIN APPLICATION
addappid(2052420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052420,0,"5431431c812eab7b43ee4c24f6b42df34e4930afaf72113e75fdbb4118d566b6")

