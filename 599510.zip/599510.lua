-- Lua provided by RyzenAPI
-- Game: Game: SpaceDweller

-- MAIN APPLICATION
addappid(599510)
-- Game: addappid(599510)

-- MAIN APP DEPOTS / PACKAGES
addappid(599511, 1, "a92547c14d4d303a29868560cfc459b291f04f20c12f20528f5cfb573cc97044")
addappid(770590, 0, "5fa153ab165e440aa0d4d2d029c774793514b019115f7ea37c347dd87a348348")
