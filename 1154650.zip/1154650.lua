-- Lua provided by RyzenAPI
-- Game: GSpot Master｜穴王拳

-- MAIN APPLICATION
addappid(1154650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154651, 1, "37f0520d1ac6033306ecfbce3a66c82197556a2db602e1d27ef20ef3bb2715f6")
