-- Lua provided by RyzenAPI
-- Game: Jamestown

-- MAIN APPLICATION
addappid(94200)
addappid(204160)

-- MAIN APP DEPOTS / PACKAGES
addappid(94201,0,"a4591b9f36a901802d9c8dbe0b7a1aa356d7e67158974bb259d90e0f1b259864")
addappid(94202,0,"dda9b75f78f274e3e113ac4187d27f957bb44ab3ef4e8f40efd8cb9544e7a25f")
addappid(94203,0,"660c66712d4a9b3715bde1a747ac06531fdd2f34a375e1499b6ef3b84b72f280")
addappid(94204,0,"23571e369b06f2e610915ea3279a783915cf952f8973fc7fc1f3e59e3278f709")
addappid(94205,0,"2e78832d7804dab11c6cc97639466ea6fb21ddebf0196fa868415fead8957e2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
