-- Lua provided by SkyAPI 
-- Game: Kittens and Yarn
addappid(1644840)
addappid(1644841, 1, "aac2efd8ff7ca1d2f64912e82119be8d1bc83a2648e759639427db186dcb0b9c")
