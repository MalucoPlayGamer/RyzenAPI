-- Lua provided by RyzenAPI
-- Game: Kittens and Yarn

-- MAIN APPLICATION
addappid(1644840)
-- Game: addappid(1644840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644841, 1, "aac2efd8ff7ca1d2f64912e82119be8d1bc83a2648e759639427db186dcb0b9c")
