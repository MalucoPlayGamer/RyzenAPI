-- Lua provided by RyzenAPI
-- Game: Battletoads

-- MAIN APPLICATION
addappid(1244950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244951, 1, "5495bb2cb4e911dd539f2925b4f34214147335d6fb69f604b0b520e422230ee7")

