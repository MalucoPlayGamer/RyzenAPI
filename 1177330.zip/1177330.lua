-- Lua provided by RyzenAPI
-- Game: Billion Beat

-- MAIN APPLICATION
addappid(1177330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177332,0,"25e5957acdfd08401ccf2e8de35dfd4442513563ff9899692a6935539ef1c0a9")

