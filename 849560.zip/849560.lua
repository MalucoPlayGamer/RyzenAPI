-- Lua provided by RyzenAPI
-- Game: Game: AppID 849560

-- MAIN APPLICATION
addappid(849560)
-- Game: addappid(849560)

-- MAIN APP DEPOTS / PACKAGES
addappid(849561, 1, "5f5d0659c9a0260c415f5cdfa76e51fd3930a45f01a3bea3a5f0d284510cdade")
