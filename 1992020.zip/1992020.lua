-- Lua provided by RyzenAPI
-- Game: Demons Happened

-- MAIN APPLICATION
addappid(1992020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992021, 1, "49ed211cb9629ebb5eb3e69755717ff65377134fe84ab1fd708096c598c8011d")

