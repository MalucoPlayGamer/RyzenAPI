-- Lua provided by RyzenAPI
-- Game: Demons Happened

-- MAIN APPLICATION
addappid(1992020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1992021, 1, "49ed211cb9629ebb5eb3e69755717ff65377134fe84ab1fd708096c598c8011d")

