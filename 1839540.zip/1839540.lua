-- Lua provided by RyzenAPI
-- Game: Grocket

-- MAIN APPLICATION
addappid(1839540)
-- Game: addappid(1839540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839541, 1, "4ec449b9f41fe169d040323c3fe5a265ace60a762281d747821666c33a0f1c7b")
addappid(1839542, 1, "349674128a51cc86eecd2dec927ceec8e10335efb5fedffa76a53cb6b595f10b")
