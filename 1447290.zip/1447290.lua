-- Lua provided by RyzenAPI 
-- Game: AppID 1447290
addappid(1447290)
addappid(1447291, 1, "51eaf7e35006ade544a8db3a5f5311e0f520f30d145ccb3dde8bfd5ce2678d1b")
