-- Lua provided by RyzenAPI
-- Game: Tactical Operations Force

-- MAIN APPLICATION
addappid(1447290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1447291, 1, "51eaf7e35006ade544a8db3a5f5311e0f520f30d145ccb3dde8bfd5ce2678d1b")
