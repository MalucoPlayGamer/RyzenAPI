-- Lua provided by RyzenAPI
-- Game: Blood Harvest 3

-- MAIN APPLICATION
addappid(851180)
addappid(927900)

-- MAIN APP DEPOTS / PACKAGES
addappid(851181,0,"c54d506971e4448a8770968efd8c5ad85b89df96266b41870a2ab4a7be4d80a3")

