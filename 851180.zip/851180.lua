-- Lua provided by SkyAPI 
-- Game: Blood Harvest 3
addappid(851180)
addappid(851181, 1, "c54d506971e4448a8770968efd8c5ad85b89df96266b41870a2ab4a7be4d80a3")
