-- Lua provided by RyzenAPI 
-- Game: AppID 953340
addappid(953340)
addappid(953341, 1, "82a8023f5b9c8a8933bb66e14e78e25a9efa62e95166a7481c4693372a78bee3")
