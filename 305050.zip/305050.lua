-- Lua provided by RyzenAPI
-- Game: Game: Outland

-- MAIN APPLICATION
addappid(305050)
-- Game: addappid(305050)

-- MAIN APP DEPOTS / PACKAGES
addappid(305051, 1, "4ee303a202199987f3c78b1b4b6f91abeff576f366e5ee3755d2b40f66d58882")
addappid(305052, 1, "1701b1888ca83c5c6b00186f36580c64c9db96225ba8698445b46392fc83aa3f")
addappid(305053, 1, "6d84837d815f53276a6baf8cfd7fea7fdea0b941f46cb86ef428a00826896ad2")
addappid(325590, 0, "5d88ee065db8ae0a6c4a0bf619bbabf706404a25d9c21df008fa02364ae491f6")
