-- Lua provided by RyzenAPI
-- Game: Game: Desire FOR Power: Council Intrigues

-- MAIN APPLICATION
addappid(3765320)
-- Game: addappid(3765320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765321, 1, "b734dbe4734ceb7d5adcb3152cfe06dcc66feef6260fd46f13b223b29e121ced")
