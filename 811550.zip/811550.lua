-- Lua provided by RyzenAPI
-- Game: addappid(811550)

-- MAIN APPLICATION
addappid(811550)

-- MAIN APP DEPOTS / PACKAGES
addappid(811551, 1, "2c0ae76578abeb0080647a6bed7e02a8a2bf1e3f07712a7e644091b29e83cfc6")
