-- Lua provided by RyzenAPI
-- Game: Manor Lords - Artbook

-- MAIN APPLICATION
addappid(2932660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932660,0,"1adba25f4fa5ce03145e033f1f027e5d411e8db2042fbad6317352153d507bfe")
