-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy String Skipping Exercise 1

-- MAIN APPLICATION
addappid(899905)

-- MAIN APP DEPOTS / PACKAGES
addappid(899905,0,"5f46145195b01cf440dd21ef93161f36628ebf9dbb74b090e83acf1c486a25c5")

