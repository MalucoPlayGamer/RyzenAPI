-- Lua provided by RyzenAPI
-- Game: EverQuest

-- MAIN APPLICATION
addappid(205710)
