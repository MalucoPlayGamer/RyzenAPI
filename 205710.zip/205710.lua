-- Lua provided by RyzenAPI
-- Game: EverQuest

-- MAIN APPLICATION
addappid(205710)
addappid(227440)
addappid(249760)
addappid(332420)
addappid(332890)
addappid(334110)
addappid(334111)
addappid(334112)
addappid(334113)
addappid(420390)

