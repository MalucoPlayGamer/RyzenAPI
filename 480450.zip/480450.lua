-- Lua provided by RyzenAPI
-- Game: Floppy Heroes

-- MAIN APPLICATION
addappid(480450)

-- MAIN APP DEPOTS / PACKAGES
addappid(480451, 1, "6433be2a31d677c5f5b71e927d715d6adbe66e2e8cd7431c40425cdb93a8bf88")
