-- Lua provided by RyzenAPI
-- Game: setManifestid(1269642,"5523723852262155482")

-- MAIN APPLICATION
addappid(1269640)
-- Game: addappid(1269640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269642,0,"f576eea6649f2ec510238c9a20e94c69e8a7b32fecedd20915201a039bf25251")
addappid(2141050,0,"5f27e09870f4c2de23d4e1fc1ec03b46fddc2ae12f30b112faeea67ab11fbf96")
