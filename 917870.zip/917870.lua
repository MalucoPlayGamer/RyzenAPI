-- Lua provided by RyzenAPI
-- Game: AppID 917870

-- MAIN APPLICATION
addappid(917870)

-- MAIN APP DEPOTS / PACKAGES
addappid(917871, 1, "8335c37c65ca154ad5426bcd8970e827368829fb1fd3a098d1a62c6bccd1db55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
