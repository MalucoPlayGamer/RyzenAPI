-- Lua provided by RyzenAPI 
-- Game: AppID 917870
addappid(917870)
addappid(917871, 1, "8335c37c65ca154ad5426bcd8970e827368829fb1fd3a098d1a62c6bccd1db55")
