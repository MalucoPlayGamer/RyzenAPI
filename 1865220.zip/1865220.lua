-- Lua provided by RyzenAPI
-- Game: addappid(1865220)

-- MAIN APPLICATION
addappid(1865220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865221, 1, "e4914f342d89a4277c7dfc54d73208bfe29975ac90a476add0d2e6d8018a514b")
