-- Lua provided by RyzenAPI
-- Game: Flix and Chill 2: Millennials

-- MAIN APPLICATION
addappid(657120)
addappid(680210)
-- Game: addappid(657120)

-- MAIN APP DEPOTS / PACKAGES
addappid(657121, 1, "828c43d49ccaf84b4704abd12b567d24b4ba51c373c927edf35ef35fa338167c")
