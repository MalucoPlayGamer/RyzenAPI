-- Lua provided by RyzenAPI
-- Game: addappid(657120)

-- MAIN APPLICATION
addappid(657120)
addappid(680210)

-- MAIN APP DEPOTS / PACKAGES
addappid(657121, 1, "828c43d49ccaf84b4704abd12b567d24b4ba51c373c927edf35ef35fa338167c")
