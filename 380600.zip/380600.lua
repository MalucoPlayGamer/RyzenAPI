-- 380600's Lua and Manifest Created by Hubcap Manifest
-- Fishing Planet
-- Created: July 31, 2026 at 08:55:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 74
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(380600, 1, "b308e0484412bdf3956a22ce56445739a22635fc4f21ffaa52cc2f862873638d") -- Fishing Planet
-- MAIN APP DEPOTS
addappid(380601, 1, "5924c858980796455eb6e175328897a86ef9c115fd6fd98d4ebabcc349d9c1ed") -- Fishing Planet Content
setManifestid(380601, "8789073555765935787", 10872675076)
addappid(380602, 1, "f90c7560e7aa94c844a5db501dab96220362dcea45aa20d17b81207f5b26df78") -- Fishing Planet Depot (x32)
setManifestid(380602, "7203195350100104899", 6904453163)
addappid(380603, 1, "d5536481fe8ed073deff75fc2c0507229ff6664734ff72b9a5d848ed6eb13278") -- Fishing Planet Depot (OsX)
setManifestid(380603, "3149106676453675906", 18520401046)
addappid(380604, 1, "8141d803b45070bad8b4d19dd90f3f8b38dcc91019aa3d88ec6ebe8d30887520") -- Fishing Planet Depot (Linux)
setManifestid(380604, "3488088288466163835", 10913251886)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(422473) -- Fishing Planet St.Patricks Pack
addappid(423363) -- Sport Heavy Casting Pack
addappid(423364) -- Sport Casting Bass Pack
addappid(423365) -- Sport Spinning Trout Pack
addappid(423366) -- Sport Float Pack
addappid(423367) -- Sport Outfit DLC
addappid(423368) -- Sport Ultralight Panfish Pack
addappid(423369) -- Happy 4-th of July Pack
addappid(496431) -- Fishing Planet Anniversary Pack
addappid(496432) -- Fishing Planet Lucky Start Pack
addappid(496438) -- Fishing Planet Winter Pike Pack
addappid(496439) -- Fishing Planet Crappie Valentine Pack
addappid(591971) -- Fishing Planet Char Chargers Pack
addappid(591983) -- Sport Topwater Night Pack
addappid(591984) -- Fishing Planet GarsGlory Pack
addappid(591985) -- Fishing Planet Spooky Fishing Pack 
addappid(591986) -- Fishing Planet Kayaks Adventure Pack
addappid(730610) -- Fishing Planet Sport Kayak Pack
addappid(730611) -- Fishing Planet Christmas Giants Pack
addappid(730612) -- Fishing Planet Christmas Magic Pack
addappid(730613) -- Fishing Planet Santas Kayak Pack
addappid(730614) -- Fishing Planet Golden Dragon Pack
addappid(730615) -- Fishing Planet Tricky Treats Pack
addappid(730616) -- Fishing Planet Advanced Pack
addappid(730617) -- Fishing Planet Deluxe Pack
addappid(730619) -- Fishing Planet Feeder Dream Pack
addappid(1000712) -- Fishing Planet Metalhead Motorboat Pack
addappid(1000714) -- Fishing Planet Revolutionary Pack
addappid(1000715) -- Fishing Planet Mighty Carp Tournament Pack
addappid(1000716) -- Fishing Planet - Sport Feeder Pack
addappid(1000717) -- Fishing Planet - Sport Bottom Pack
addappid(1000718) -- Fishing Planet - Sport Carp Pack
addappid(1000719) -- Fishing Planet Rigs Combo Pack
addappid(1200340) -- Fishing Planet Holiday Pack
addappid(1200341) -- Fishing Planet Bassboat Explorer Pack
addappid(1200342) -- Fishing Planet Saltwater Match Pack
addappid(1200343) -- Fishing Planet Bream Feeder Frenzy Pack
addappid(1200344) -- Fishing Planet Rainforest Journey Pack
addappid(1200345) -- Fishing Planet Boat Series Pack
addappid(1200346) -- Fishing Planet Tropic Hunter Pack
addappid(1200347) -- Fishing Planet Krampus atcher Pack
addappid(1200348) -- Fishing Planet Amazon Carnival Pack
addappid(1200349) --  Fishing Planet Congo Discovery Pack
addappid(1804840) --  Fishing Planet Wild Africa Pack 
addappid(1804842) -- Fishing Planet World Cats Cup Pack
addappid(1804843) -- Fishing Planet World Bass Tour Pack
addappid(1804844) -- Fishing Planet Taimen Khan Pack
addappid(1804845) -- Fishing Planet Hellfish Fighter Pack
addappid(1804846) -- Fishing Planet Topwater Kayak Pack
addappid(1804847) -- Fishing Planet Black Friday Travel Pack
addappid(1804848) -- Fishing Planet Live Bait Fiesta Pack
addappid(1804849) -- Fishing Planet Club Enthusiast Pack
addappid(2654610) -- Fishing Planet Thanksgiving Cornucopia Pack
addappid(2922520) -- Fishing Planet Sailor Collection Pack
addappid(2922530) -- Fishing Planet Ocean Voyager Pack
addappid(2922540) -- Fishing Planet Japan Odyssey Pack
addappid(3255720) -- Fishing Planet Supernatural Explorer Pack
addappid(3351850) -- Fishing Planet Dnipro Delta Pack
addappid(3376360) -- Fishing Planet Golden Angler Pack
addappid(3376370) -- Fishing Planet Bottom Pack
addappid(3376380) -- Fishing Planet Daredevil Boat Pack
addappid(3376390) -- Fishing Planet Carp Pro Pack
addappid(3376400) -- Fishing Planet Green Fortune Event Pack
addappid(3743490) -- Fishing Planet Chamaeleon Cruiser Pack
addappid(3743500) -- Fishing Planet Atoll Scout Pack
addappid(4094160) -- Fishing Planet Pro Fishing Starter Pack
addappid(4094180) -- Fishing Planet Pro Upgrade Pack
addappid(4094190) -- Fishing Planet Easy Going Starter Pack
addappid(4094200) -- Fishing Planet Power Boost Pack
addappid(4094210) -- Fishing Planet Instant Lift Pack
addappid(4218160) -- Fishing Planet Nordic Legend Pack
addappid(4218170) -- Fishing Planet Valkyrie Saga Pack
addappid(4779210) -- Fishing Planet StarRanger Kayak Pack
addappid(4961440) -- Fishing Planet Anniversary Event Pack