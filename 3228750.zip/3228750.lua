-- Lua provided by RyzenAPI
-- Game: 3228750

-- MAIN APPLICATION
addappid(3228750)
-- Game: addappid(3228750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228751, 1, "1ce75bd4ec604ed2c5df384bcdc404884c1137cda40f8193de696bc2d8c064b6")
addappid(3228752, 1, "e4aa0cc5b5bf2263966950a3d93e1b78f9622f69a106dcfe55f7652ff08d9dcc")
