-- Lua provided by RyzenAPI
-- Game: Kukoro: Stream chat games

-- MAIN APPLICATION
addappid(1166990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166993,0,"13d28f310111f21d7c356f05b15f1bf8eb0071f7f9d3b9415b0131a9ac98f8c3")
