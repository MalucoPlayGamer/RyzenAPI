-- 4323290's Lua and Manifest Created by Hubcap Manifest
-- Flippant
-- Created: May 14, 2026 at 08:01:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4323290) -- Flippant
-- MAIN APP DEPOTS
addappid(4323291, 1, "a84d31da3bd1317540b051829ff512caec47d2fa5414044a86ddb8efd67cbcc4") -- Depot 4323291
-- setManifestid(4323291, "9042180258164317675", 133997236)