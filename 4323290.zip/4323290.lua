-- Lua provided by RyzenAPI
-- Game: Flippant

-- MAIN APPLICATION
addappid(4323290) -- Flippant

-- MAIN APP DEPOTS / PACKAGES
addappid(4323291, 1, "a84d31da3bd1317540b051829ff512caec47d2fa5414044a86ddb8efd67cbcc4") -- Depot 4323291

