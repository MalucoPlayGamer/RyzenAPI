-- Lua provided by RyzenAPI
-- Game: addappid(1022475)

-- MAIN APPLICATION
addappid(1022475)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022475,0,"6969717cb642b5c9ae9287decdcfb63d95a5cb18c0d096c34f172f62dc6decd7")
