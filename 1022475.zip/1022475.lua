-- Lua provided by RyzenAPI
-- Game: DFF NT: Resolute Rebel Appearance Set for Firion

-- MAIN APPLICATION
addappid(1022475)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022475,0,"6969717cb642b5c9ae9287decdcfb63d95a5cb18c0d096c34f172f62dc6decd7")
