-- Lua provided by RyzenAPI
-- Game: Thrive: Heavy Lies The Crown

-- MAIN APPLICATION
addappid(1245250)
-- Game: addappid(1245250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245251, 1, "14ac199640cb0f525ca9abb8361c1c03787d2360113d73deb293964588d776fd")
