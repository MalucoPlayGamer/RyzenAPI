-- Lua provided by RyzenAPI
-- Game: Crimson Desert

-- MAIN APPLICATION
addappid(3321460)
addappid(4024620)
addappid(4024630)
addappid(4193060)
-- Game: addappid(3321460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321461, 1, "e2e570c84eb8b4cfe9c20268cd30b84f8c1c7c076691c92ae8c5ba7b510b8a95")
addappid(3321462, 1, "6eb3bfe7d16b9eb6441dba4f7d18b341fe83ab2f1e9385d042ce622f38a600cb")
