-- Lua provided by RyzenAPI
-- Game: Crimson Desert

-- MAIN APPLICATION
addappid(4024620) -- Crimson Desert - Deluxe Pack
addappid(4024630) -- Crimson Desert - Pre Order Pack
addappid(4193060) -- Crimson Desert - Ultimate Pack
addappid(4572870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3321460, 1, "dc014470e47064263f3003feb526a87cc64784292e2a608455d18fa70ec2c1e0") -- Crimson Desert
addappid(3321461, 1, "e2e570c84eb8b4cfe9c20268cd30b84f8c1c7c076691c92ae8c5ba7b510b8a95") -- (windows, 64-bit)
addappid(3321462, 1, "6eb3bfe7d16b9eb6441dba4f7d18b341fe83ab2f1e9385d042ce622f38a600cb") -- (macos, 64-bit)
addappid(3321463, 1, "5c5b7a3590b231b68c3c0e9c33b4ced510f2281cc35ab7f552ab782931ce22b3") -- Depot 3321463
addappid(3321464, 1, "2333a1f0f77d75fa09864aeb71fa6fbafc6ee59bde5f1f13922cba1a0c8aa777") -- Depot 3321464
addappid(3321465, 1, "58dfe68b6d03e20bef08407af32e2c1c53ec82e8197e4acff6018a16d5da2b51") -- Depot 3321465
addappid(3321466, 1, "0456065fe718c350f1f71a6bb81e5601ab8a747e8b0c002efa6fd8db27caa4ed") -- Depot 3321466
addappid(3321467, 1, "b8a8a3d8540f34ce307c425fc47acd66a35b7d19d24004ceee088aa8fdd0d407") -- Depot 3321467
addappid(4024621, 1, "484792dc1b32cb5dac6885c10038165bd56bc0a0e9833ef779dafd88209548aa") -- Depot 4024621
addappid(4024622, 1, "7b098d44c85057bca03745a249136befb728f6374f003c6853ffc69b68be3800") -- Depot 4024622
addappid(4024623, 1, "c634255a500d10984483174c44544140a6afeaac9e5164c435206e3717b01c67") -- Depot 4024623
addappid(4024624, 1, "c60b8f04c8905751aac4bc4791df98ce5afe170a88e005bed8a5e2bb95e24d75") -- Depot 4024624
addappid(4024625, 1, "29f9a472428b1f8dc92f249b9e825957bf0c389b168576b13f96b2f643718275") -- Depot 4024625
addappid(4572871, 1, "fd5557767303d9a63b0b31b6a22cd1368e5d82a692e64d041890100ea0c330c4")
addappid(4572872, 1, "e071efcdac5de6bf1b6620a3110cb3ab7799943ee634eed2970db8732eeb817e")
addtoken(4024630, "17135069641874014023")

-- correcao manifest/updates
setManifestid(3321461, "3181503578355214830")
setManifestid(3321462, "5054339860124800981")
setManifestid(4572871, "6173128065949955413")
setManifestid(4572872, "1021886354207583209")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5001840)
