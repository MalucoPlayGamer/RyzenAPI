-- Lua provided by RyzenAPI
-- Game: Anomaly President

-- MAIN APPLICATION
addappid(3156330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156331,0,"e40d152eead510c87f1b945f16e2a12cdf0b56ec49cf5a58231902cc92db3060")

