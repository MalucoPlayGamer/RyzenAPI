-- Lua provided by RyzenAPI
-- Game: AppID 1547260

-- MAIN APPLICATION
addappid(1547260)
-- Game: addappid(1547260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547261, 1, "0c444f9d42ef25732a15a6805b042138a861df01fecd8ba2ef990bc49ec0d3cd")
