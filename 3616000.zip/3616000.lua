-- Lua provided by SkyAPI 
-- Game: King's Amusements
addappid(3616000)
addappid(3616001, 1, "fa19a3ea48c5333c3877a8aba4beadfde610281bf1062a710f0df0bef757835c")
