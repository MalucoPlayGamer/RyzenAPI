-- Lua provided by RyzenAPI
-- Game: King's Amusements

-- MAIN APPLICATION
addappid(3616000)
-- Game: addappid(3616000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616001, 1, "fa19a3ea48c5333c3877a8aba4beadfde610281bf1062a710f0df0bef757835c")
