-- Lua provided by SkyAPI 
-- Game: AppID 1856010
addappid(1856010)
addappid(1856011, 1, "c744865e18c1f923f27a21b1f6d01d37016caac63c84324d9c3fad11276d7856")
