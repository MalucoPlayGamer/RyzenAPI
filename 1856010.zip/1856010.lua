-- Lua provided by RyzenAPI
-- Game: addappid(1856010)

-- MAIN APPLICATION
addappid(1856010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856011, 1, "c744865e18c1f923f27a21b1f6d01d37016caac63c84324d9c3fad11276d7856")
