-- Lua provided by RyzenAPI
-- Game: 3503340

-- MAIN APPLICATION
addappid(3503340)
-- Game: addappid(3503340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503341, 1, "304ec02a99dbfe3f36b3cd388efc6809cfcda8d70b8db193a3115dba32345a1e")
