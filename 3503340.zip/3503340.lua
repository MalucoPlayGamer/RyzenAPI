-- Lua provided by RyzenAPI 
-- Game: Dream Night
addappid(3503340)
addappid(3503341, 1, "304ec02a99dbfe3f36b3cd388efc6809cfcda8d70b8db193a3115dba32345a1e")
