-- Lua provided by RyzenAPI
-- Game: CATO: Buttered Cat Demo

-- MAIN APPLICATION
addappid(1999530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999531, 1, "b17aa173ce17c7c50a8536ff9f1121f1c5356c48fc61cb47df0059cfaacf4c63")

