-- Lua provided by RyzenAPI
-- Game: Kitten Lost Her Box

-- MAIN APPLICATION
addappid(1821310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821311, 1, "a3df2120232c3b5772d4a5f73a9ea4a13d287167253fb8e774640fa961efc01b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
