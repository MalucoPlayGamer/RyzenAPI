-- Lua provided by RyzenAPI
-- Game: Kitten Lost Her Box

-- MAIN APPLICATION
addappid(1821310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821311, 1, "a3df2120232c3b5772d4a5f73a9ea4a13d287167253fb8e774640fa961efc01b")

