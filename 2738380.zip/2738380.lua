-- Lua provided by RyzenAPI
-- Game: 2738380

-- MAIN APPLICATION
addappid(2738380)
-- Game: addappid(2738380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738381, 1, "23f028f3885751ffd21c9be851661a3e4d8eadc7b743dba2c990bd07b572ff2a")
