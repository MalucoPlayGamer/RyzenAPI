-- Lua provided by RyzenAPI
-- Game: AppID 345060

-- MAIN APPLICATION
addappid(345060)

-- MAIN APP DEPOTS / PACKAGES
addappid(345061, 1, "92688edd54369e84d13a3efb8b3c9e9885891f44bbf0cc081cd3c3dd3fa250a5")
