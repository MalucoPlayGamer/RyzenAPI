-- Lua provided by RyzenAPI
-- Game: addappid(825240)

-- MAIN APPLICATION
addappid(825240)

-- MAIN APP DEPOTS / PACKAGES
addappid(825241, 1, "e5fbdab34d8917222243450b5f9286af560e261e5dc8a65463a52f8b96eaded3")
addappid(825242, 1, "adf2a1109f352fc62ea2bc6785285cea857a19b7d0b89e8ff0dd5394ba7cfff6")
