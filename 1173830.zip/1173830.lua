-- Lua provided by RyzenAPI
-- Game: Coloring Game: Pixel

-- MAIN APPLICATION
addappid(1173830)
addappid(1173831)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173832,0,"7c8c9b95cb2c14705bebb1f20a542cef2d123dc2ce9899b3ad9f2440b71b47b6")

