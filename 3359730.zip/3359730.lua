-- Lua provided by RyzenAPI
-- Game: Hatsune Miku DLC

-- MAIN APPLICATION
addappid(3359730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359730,0,"0f11d40d2674cb19a055d6d65f4d4d845bec01167e0977aba91558bb93d4cad6")

