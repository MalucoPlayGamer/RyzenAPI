-- Lua provided by RyzenAPI
-- Game: Highway Blossoms: Next Exit

-- MAIN APPLICATION
addappid(490270)
addappid(490271)

-- MAIN APP DEPOTS / PACKAGES
addappid(490270,0,"07c381c2d725f1ff338f62fdd210605a02c76188014fb586c6771e53c9b26c14")
addappid(490272,0,"34d01f95bfb04767e221ba24d3a1d1591ae7d9d97b306f5e1870ee5eb155c194")

