-- Lua provided by RyzenAPI
-- Game: 70400

-- MAIN APPLICATION
addappid(70400)
-- Game: addappid(70400)

-- MAIN APP DEPOTS / PACKAGES
addappid(70401, 1, "176d5a4a30ab75629ecc99678bf49049f0eacbfac69fffd72fe34ae4458c2759")
addappid(70402, 1, "2d98043cddaff22c6db3d9dffd1677c0720ea93f059010a4ce743781ce28a1eb")
addappid(70403, 1, "9b3ae6b02d8a2f726603afd97bd1819918858b852ebbd76d82761d6f2356bec2")
