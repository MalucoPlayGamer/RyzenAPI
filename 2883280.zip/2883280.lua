-- Lua provided by RyzenAPI
-- Game: 2883280

-- MAIN APPLICATION
addappid(2883280)
-- Game: addappid(2883280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883281, 1, "e1f8c522f44fca49076130274916a47d185f8a6a3e55b1ab30c29cf43b9cb126")
