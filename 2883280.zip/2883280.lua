-- Lua provided by SkyAPI 
-- Game: Dog Brew
addappid(2883280)
addappid(2883281, 1, "e1f8c522f44fca49076130274916a47d185f8a6a3e55b1ab30c29cf43b9cb126")
