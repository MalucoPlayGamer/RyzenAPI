-- Lua provided by RyzenAPI
-- Game: Hentai Galaxy

-- MAIN APPLICATION
addappid(2328090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328091, 1, "ab44cf5da18f3d10a4abc1a9c2e29c987f4224e79adda2a4df895dfa730b84dc")

