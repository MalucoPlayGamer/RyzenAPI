-- Lua provided by RyzenAPI
-- Game: Game: Magical Gyarus Milk Me for Mana

-- MAIN APPLICATION
addappid(3174960)
-- Game: addappid(3174960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174961, 1, "da1eb5f2d7ab67bbad2cd0768b2e9444504291fc157c90823123a53fb61658c0")
