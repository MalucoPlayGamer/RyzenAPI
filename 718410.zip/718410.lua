-- Lua provided by RyzenAPI
-- Game: AWS Argentina Wingshooting Simulator

-- MAIN APPLICATION
addappid(718410)

-- MAIN APP DEPOTS / PACKAGES
addappid(718411, 1, "bf71f6026632b7135115529867c6426b82ea63e29672a7cbd1f1ccc1c17bd0e2")
