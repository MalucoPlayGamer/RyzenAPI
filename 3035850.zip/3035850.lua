-- Lua provided by SkyAPI 
-- Game: AppID 3035850
addappid(3035850)
addappid(3035851, 1, "42096cd3b3c89194091be83b2c4d721fd5a43bcd2698c47f351d1acbd3fb3f01")
