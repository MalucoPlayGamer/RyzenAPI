-- Lua provided by RyzenAPI
-- Game: Game: skidlocked

-- MAIN APPLICATION
addappid(1163570)
-- Game: addappid(1163570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163571, 1, "97b4e29cc803555143a326dd290a3fee09d563449f0735d823e917d9585b8bd7")
addappid(1163572, 1, "58d8e2db094cf67a9c97be4a87613c742b838aeb207dcb766e1915c7def9a571")
