-- Lua provided by RyzenAPI
-- Game: addappid(1425000)

-- MAIN APPLICATION
addappid(1425000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425001, 1, "538a019189be9b823a8c7ff25c61d33657551e295cfe7a4d4abde120d7eb0eb7")
