-- Lua provided by RyzenAPI
-- Game: Endless Alice

-- MAIN APPLICATION
addappid(1425000)
addappid(2779970)
addappid(3758720)
addappid(3758730)
addappid(3818470)
addappid(3818480)
addappid(3818490)
addappid(3823330)
addappid(4074020)
addappid(4131950)
addappid(4139190)
addappid(4166830)
addappid(4166840)
addappid(4178740)
addappid(4234690)
addappid(4347220)
addappid(4347230)
addappid(4347240)
addappid(4347250)
addappid(4414180)
addappid(4414190)
addappid(4550540)
addappid(4885420)
addappid(4885430)
addappid(4924550)
addappid(4961030)
addappid(4966390)
addappid(4966400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425001,0,"538a019189be9b823a8c7ff25c61d33657551e295cfe7a4d4abde120d7eb0eb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
