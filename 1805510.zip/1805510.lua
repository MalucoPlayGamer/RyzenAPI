-- Lua provided by RyzenAPI
-- Game: Barn Finders VR: The Pilot

-- MAIN APPLICATION
addappid(1805510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805511, 1, "1a050dffc47cc593d13492371d5ca350a6f8e869dea3c20564be887b52e57845")

