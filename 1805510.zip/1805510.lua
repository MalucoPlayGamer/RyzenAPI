-- Lua provided by RyzenAPI
-- Game: Game: Barn Finders VR: The Pilot

-- MAIN APPLICATION
addappid(1805510)
-- Game: addappid(1805510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805511, 1, "1a050dffc47cc593d13492371d5ca350a6f8e869dea3c20564be887b52e57845")
