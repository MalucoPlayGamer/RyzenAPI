-- Lua provided by RyzenAPI
-- Game: Sorry, You’re on the Menu

-- MAIN APP DEPOTS / PACKAGES
addappid(4697690) -- Sorry, You’re on the Menu
addappid(4697691, 1, "f2e46bc960ced309d14470d75e61bf5eb54d25a6c579622d71e80ff1bdc8f3ca") -- Depot 4697691
