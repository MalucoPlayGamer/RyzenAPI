-- Lua provided by RyzenAPI
-- Game: 659560

-- MAIN APPLICATION
addappid(659560)
-- Game: addappid(659560)

-- MAIN APP DEPOTS / PACKAGES
addappid(659561, 1, "0abf5d01841a3faae5593304ae8de5b68432e277d5ad27076118089f73964dc1")
