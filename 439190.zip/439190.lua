-- Lua provided by RyzenAPI
-- Game: 439190

-- MAIN APPLICATION
addappid(439190)
-- Game: addappid(439190)

-- MAIN APP DEPOTS / PACKAGES
addappid(439191, 1, "f75cf3086b7d6535060167970aca7851ff431e87fdedb6d68ef8416f4a33bf87")
addappid(471741, 0, "70e9dd42cb732f3cd67c19f28fbe8ede0d44014e3d9ed51c20c1fed37591efd7")
