-- Lua provided by RyzenAPI
-- Game: Stories: The Path of Destinies

-- MAIN APPLICATION
addappid(439190)

-- MAIN APP DEPOTS / PACKAGES
addappid(439191, 1, "f75cf3086b7d6535060167970aca7851ff431e87fdedb6d68ef8416f4a33bf87")
addappid(471741, 0, "70e9dd42cb732f3cd67c19f28fbe8ede0d44014e3d9ed51c20c1fed37591efd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
