-- Lua provided by RyzenAPI 
-- Game: FragPunk
addappid(2943650)
addappid(2943651, 1, "e0df17b5ec01dc3ab91eaa828f723850723390079c285e6855f68cdd7d6aa7b6")
