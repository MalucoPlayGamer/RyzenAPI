-- Lua provided by RyzenAPI
-- Game: The Backrooms Footage

-- MAIN APPLICATION
addappid(2094850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094853,0,"fec55391879ebe4d5191df350027c105fb3e724961aa7d49d5012c736fb4d567")

