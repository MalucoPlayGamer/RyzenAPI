-- Lua provided by RyzenAPI
-- Game: Werewolf: The Apocalypse — Purgatory

-- MAIN APPLICATION
addappid(2463980)
-- Game: addappid(2463980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463981, 1, "217e8a7ccaa84e78db32b3ec7c71b11d636fa45314b8ddd97cb3455b44d111c0")
