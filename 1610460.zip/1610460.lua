-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame 5

-- MAIN APPLICATION
addappid(1610460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610461, 1, "f7d29205f2c09cf9532aa2038db7aab6bbcd6d1053b4d03799bd4f172df188c3")

