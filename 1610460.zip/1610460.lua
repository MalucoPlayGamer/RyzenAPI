-- Lua provided by RyzenAPI
-- Game: 1610460

-- MAIN APPLICATION
addappid(1610460)
-- Game: addappid(1610460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610461, 1, "f7d29205f2c09cf9532aa2038db7aab6bbcd6d1053b4d03799bd4f172df188c3")
