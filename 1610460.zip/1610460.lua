-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame 5

-- MAIN APPLICATION
addappid(1610460)
addappid(1725020)
addappid(1725030)
addappid(1725040)
addappid(1725050)
addappid(1725060)
addappid(1725070)
addappid(1725080)
addappid(1725090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1610461, 1, "f7d29205f2c09cf9532aa2038db7aab6bbcd6d1053b4d03799bd4f172df188c3")

