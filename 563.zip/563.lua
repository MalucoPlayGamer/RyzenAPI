-- Lua provided by RyzenAPI
-- Game: addappid(563)

-- MAIN APPLICATION
addappid(551)
addappid(552)
addappid(563)

-- MAIN APP DEPOTS / PACKAGES
addappid(563,0,"8c05b5ab5143d73cf7c7c68c1380289b04592bcb9c08dfed40e1eec99a12860c")
