-- Lua provided by RyzenAPI
-- Game: Game: AppID 758110

-- MAIN APPLICATION
addappid(758110)
-- Game: addappid(758110)

-- MAIN APP DEPOTS / PACKAGES
addappid(758111, 1, "615fb3e27b817762346e0583292d5065fbe18f9b6368657c15fbdfb5d59d4527")
