-- Lua provided by RyzenAPI
-- Game: Game: Educator 2076: Basics in Education

-- MAIN APPLICATION
addappid(923880)
-- Game: addappid(923880)

-- MAIN APP DEPOTS / PACKAGES
addappid(923881, 1, "d27e99768ac63bc682542deea1d45dc13c3a6ee3e4c77d219ecfb735e984631d")
