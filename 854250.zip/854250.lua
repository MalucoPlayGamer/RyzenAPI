-- Lua provided by RyzenAPI
-- Game: FPV Freerider

-- MAIN APPLICATION
addappid(854250)

-- MAIN APP DEPOTS / PACKAGES
addappid(854251, 1, "78b754c44abd295bad14d803eebe792f5647358353140c6224937c6cf667809d")
