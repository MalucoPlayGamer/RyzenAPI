-- Lua provided by RyzenAPI
-- Game: addappid(2010121)

-- MAIN APPLICATION
addappid(2010121)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010121,0,"e342d1965f8e34c39661dcaa53f2d9e5df74de3ee19758b7ef2881e02adda494")
