-- Lua provided by RyzenAPI
-- Game: My Winter Car

-- MAIN APPLICATION
addappid(4164420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4164421,0,"25786818231b18d0c50cadb12be7d574140d7de03edebbea0fdeb17c8ac49fb7")

