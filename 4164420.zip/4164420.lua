-- Lua provided by RyzenAPI
-- Game: My Winter Car

-- MAIN APPLICATION
addappid(4164420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4164420, 1, "865d1f548094d6e15893000b7ce7784bc339961b10a76a311f390757c4b1af36")
addappid(4164421,0,"25786818231b18d0c50cadb12be7d574140d7de03edebbea0fdeb17c8ac49fb7")
addappid(4164421, 1, "25786818231b18d0c50cadb12be7d574140d7de03edebbea0fdeb17c8ac49fb7")

