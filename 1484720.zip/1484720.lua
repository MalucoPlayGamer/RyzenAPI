-- Lua provided by RyzenAPI
-- Game: Dead Estate

-- MAIN APPLICATION
addappid(1484720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484721, 1, "b483a8cfd4be1921be8384435068f891b8921a3e71b86b0a281ab6163aac8575")

