-- Lua provided by RyzenAPI
-- Game: Beat Saber - Eminem - "Godzilla (feat. Juice WRLD)"

-- MAIN APPLICATION
addappid(2893460)
-- Game: addappid(2893460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893460,0,"632e890fc57854ee4c62d326d49d34e52e772f6754034443b6e091b28c66e65c")
