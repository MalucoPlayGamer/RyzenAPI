-- Lua provided by RyzenAPI
-- Game: Game: Runeblade Automaton

-- MAIN APPLICATION
addappid(3716310)
-- Game: addappid(3716310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716311, 1, "d9504ef9f9eca0d2a5d26b1153b88d240b3aa95a6f125cc58e48bf289027c9a4")
