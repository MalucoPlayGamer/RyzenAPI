-- Lua provided by RyzenAPI
-- Game: Game: AppID 1116910

-- MAIN APPLICATION
addappid(1116910)
-- Game: addappid(1116910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116911, 1, "7aa2e2a871450d5191ed4d6c50c761f574fd5ab0c1ca83c95ad7739042d86b74")
