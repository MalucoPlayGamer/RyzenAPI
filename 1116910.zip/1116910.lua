-- Lua provided by SkyAPI 
-- Game: AppID 1116910
addappid(1116910)
addappid(1116911, 1, "7aa2e2a871450d5191ed4d6c50c761f574fd5ab0c1ca83c95ad7739042d86b74")
