-- Lua provided by RyzenAPI
-- Game: addappid(1520390)

-- MAIN APPLICATION
addappid(1520390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520391, 1, "87f8222f0b7f8d77e74edec2b1ca658fef6ca8502a7eb6a01c9df76496764148")
