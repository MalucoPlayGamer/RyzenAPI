-- Lua provided by RyzenAPI
-- Game: Color Madness

-- MAIN APPLICATION
addappid(3460190)
-- Game: addappid(3460190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460191, 1, "72fedbd6c1ded132a91511fe71679346209b288521b210522f1e7b7214938539")
