-- Lua provided by RyzenAPI 
-- Game: Color Madness
addappid(3460190)
addappid(3460191, 1, "72fedbd6c1ded132a91511fe71679346209b288521b210522f1e7b7214938539")
