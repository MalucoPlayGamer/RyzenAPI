-- Lua provided by RyzenAPI
-- Game: Game: Don Duality

-- MAIN APPLICATION
addappid(2247570)
-- Game: addappid(2247570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247571, 1, "f39bbfb35bcedaea85901eb0b1ed1473784facd1a9ce873e2d3678adf09efb22")
