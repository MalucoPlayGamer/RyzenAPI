-- Lua provided by RyzenAPI
-- Game: 恋爱绮谭 不存在的真相 Demo

-- MAIN APPLICATION
addappid(1849160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849161, 1, "db96345c07bf32744979131c401ae7d28e3df0e5208dd9c410647583bc51bcbf")
