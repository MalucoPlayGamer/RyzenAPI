-- Lua provided by SkyAPI 
-- Game: AppID 2296420
addappid(2296420)
addappid(2296421, 1, "380d794dce9707665c64041e85d5a246217645d2b18261d44727cb56f12eb3a6")
addappid(2296422, 1, "17b3f289b66c7abcf72d9816b7b70cb518fc0e692bec0cef0ad9d43ca1dba12a")
