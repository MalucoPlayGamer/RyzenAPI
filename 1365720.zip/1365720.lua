-- Lua provided by RyzenAPI
-- Game: Kujlevka

-- MAIN APPLICATION
addappid(1365720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365721, 1, "8c42710ee69fa55b776b0a0b86094429cd0d28d7058f94e77154d8dd4a542d5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
