-- Lua provided by RyzenAPI
-- Game: Kujlevka

-- MAIN APPLICATION
addappid(1365720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365721, 1, "8c42710ee69fa55b776b0a0b86094429cd0d28d7058f94e77154d8dd4a542d5c")

