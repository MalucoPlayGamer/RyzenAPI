-- Lua provided by RyzenAPI
-- Game: Dream Town Island

-- MAIN APPLICATION
addappid(2488340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488341, 1, "df206280d42766c2c38debd8dc5dbf06ce3f149362a4f6a83f06a711ad95a3c8")
