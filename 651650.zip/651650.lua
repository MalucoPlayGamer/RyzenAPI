-- Lua provided by RyzenAPI
-- Game: Dunia: Masters

-- MAIN APPLICATION
addappid(651650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(651651, 1, "b35d19273a685abcef6d3a51335b87a77a9af569369bf0f2c7ce6dd4e440aa8f")

