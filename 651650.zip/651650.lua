-- Lua provided by RyzenAPI
-- Game: AppID 651650

-- MAIN APPLICATION
addappid(651650)
-- Game: addappid(651650)

-- MAIN APP DEPOTS / PACKAGES
addappid(651651, 1, "b35d19273a685abcef6d3a51335b87a77a9af569369bf0f2c7ce6dd4e440aa8f")
