-- Lua provided by RyzenAPI
-- Game: addappid(672000)

-- MAIN APPLICATION
addappid(672000)

-- MAIN APP DEPOTS / PACKAGES
addappid(672001, 1, "bf3e978b9a49cc53f5543b3773ed1bc3494a0fd29ff6f6e01b4499d2d7d2191f")
