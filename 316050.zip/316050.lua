-- Lua provided by RyzenAPI
-- Game: AppID 316050

-- MAIN APPLICATION
addappid(316050)
-- Game: addappid(316050)

-- MAIN APP DEPOTS / PACKAGES
addappid(316051, 1, "b2f5f89d8796aef63db495267ab60ef353aa6c7d9f5b72ff7a17072d299cef56")
