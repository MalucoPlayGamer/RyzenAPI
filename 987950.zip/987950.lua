-- Lua provided by RyzenAPI
-- Game: eBall

-- MAIN APPLICATION
addappid(987950)

-- MAIN APP DEPOTS / PACKAGES
addappid(987951, 1, "8c30ca22ef99a919318b8c23bb9f6281962ef56c6a3dd3a7996a26b85836d728")

