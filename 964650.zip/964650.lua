-- Lua provided by RyzenAPI
-- Game: Game: Invasion Machine

-- MAIN APPLICATION
addappid(964650)
-- Game: addappid(964650)

-- MAIN APP DEPOTS / PACKAGES
addappid(964651, 1, "7b6d79e4a4f1b36bc19efb90a787b993d0795d7a4deea07fa00f7dcce6bd86bc")
