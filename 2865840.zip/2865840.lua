-- Lua provided by RyzenAPI
-- Game: 2865840

-- MAIN APPLICATION
addappid(2865840)
-- Game: addappid(2865840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865841, 1, "a50bdb7d117e8a98c1f12f8f5b84b9aa427c7451281c4cb538e84091ffc760fa")
