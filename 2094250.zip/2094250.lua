-- Lua provided by RyzenAPI 
-- Game: Valhalla：Awakening of Valkyrie
addappid(2094250)
addappid(2094251, 1, "715aa827f80b5cda0d531e22f757bf47103c3c43d7413d65a4aeee357d4c0649")
addappid(2122500, 0, "78512e496d00b79a29beca4177fc1e5f3c25f2f919c7d1eec6402cbd6f594981")
