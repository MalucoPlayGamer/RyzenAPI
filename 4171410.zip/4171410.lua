-- Lua provided by RyzenAPI
-- Game: Is Zombody Home?

-- MAIN APPLICATION
addappid(4171410)

-- MAIN APP DEPOTS / PACKAGES
addappid(4171411,0,"65b8f773a24adbb8cbb710259e0605e089f2f10987c7ac40e79fab3f65e91ba5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
