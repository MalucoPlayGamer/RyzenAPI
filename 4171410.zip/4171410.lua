-- Lua provided by RyzenAPI
-- Game: Is Zombody Home?

-- MAIN APPLICATION
addappid(4171410)

-- MAIN APP DEPOTS / PACKAGES
addappid(4171411,0,"65b8f773a24adbb8cbb710259e0605e089f2f10987c7ac40e79fab3f65e91ba5")

