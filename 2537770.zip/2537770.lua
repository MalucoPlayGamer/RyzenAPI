-- Lua provided by RyzenAPI
-- Game: Game: Stay Still 2

-- MAIN APPLICATION
addappid(2537770)
-- Game: addappid(2537770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537771, 1, "a681245c06d0c4a93fa1d81e59a4e6c4ddb12c10d62644ef6a24c59eee5112a1")
