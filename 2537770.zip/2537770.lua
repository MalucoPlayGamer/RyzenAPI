-- Lua provided by SkyAPI 
-- Game: Stay Still 2
addappid(2537770)
addappid(2537771, 1, "a681245c06d0c4a93fa1d81e59a4e6c4ddb12c10d62644ef6a24c59eee5112a1")
