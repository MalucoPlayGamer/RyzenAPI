-- Lua provided by RyzenAPI
-- Game: addappid(1064020)

-- MAIN APPLICATION
addappid(1064020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064021, 1, "71864fa53bd9750bdd1f601c561e26357ba64292755a4ba8208b3f3ada2815ab")
