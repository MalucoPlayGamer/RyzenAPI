-- Lua provided by RyzenAPI
-- Game: Game: Bat to the Beat Demo

-- MAIN APPLICATION
addappid(3259490)
-- Game: addappid(3259490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259491, 1, "3981496020377b7efb6a51068b2aacd89f3e3ca21ecac0d12a60e3dfd9919095")
