-- Lua provided by RyzenAPI 
-- Game: Bat to the Beat Demo
addappid(3259490)
addappid(3259491, 1, "3981496020377b7efb6a51068b2aacd89f3e3ca21ecac0d12a60e3dfd9919095")
