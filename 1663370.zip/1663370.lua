-- Lua provided by RyzenAPI
-- Game: Game: Erotic Jigsaw Puzzle 4

-- MAIN APPLICATION
addappid(1663370)
-- Game: addappid(1663370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663371, 1, "25eca33c5015559422344510dc211cad449dcb997912fce3855522e22cbd887b")
addappid(1664760, 0, "b5936af684fd25ddf90e4b8d93ad51b20eb3e500cb23f0c15376462d40a3ce72")
