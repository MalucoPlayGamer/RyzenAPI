-- Lua provided by RyzenAPI
-- Game: Romans: Age of Caesar

-- MAIN APPLICATION
addappid(872570)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2479980)
