-- Lua provided by RyzenAPI
-- Game: Romans: Age of Caesar

-- MAIN APPLICATION
addappid(872570)
addappid(2479980)

