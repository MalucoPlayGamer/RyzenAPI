-- Lua provided by RyzenAPI
-- Game: Sex Simulator - College Girls

-- MAIN APPLICATION
addappid(2623540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623541, 1, "1515b7e777614aec25b307b37a11eb467569473802ddd2333de156892f2b37fe")
