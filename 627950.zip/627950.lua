-- Lua provided by RyzenAPI
-- Game: Game: 1914: Prelude to Chaos

-- MAIN APPLICATION
addappid(627950)
-- Game: addappid(627950)

-- MAIN APP DEPOTS / PACKAGES
addappid(627951, 1, "0f55740d337ab5d79850024852b41b3186129bf83e7386ebed86bf5b33a1dfcf")
