-- Lua provided by RyzenAPI
-- Game: addappid(3699380)

-- MAIN APPLICATION
addappid(3699380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699381, 1, "fd19dc1d273b19fc99e10e2a58411920fc9942f0ac4cef6d787643d1605dd6f5")
