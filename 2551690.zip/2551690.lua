-- Lua provided by RyzenAPI
-- Game: Game: Sex Bar Simulator 🍸🔞

-- MAIN APPLICATION
addappid(2551690)
-- Game: addappid(2551690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551691, 1, "3a04f94ed2cafffc0100f6613a8bb459acd456ee7f2b4be08193bbbbe94f74d4")
