-- Lua provided by RyzenAPI
-- Game: AppID 1018850

-- MAIN APPLICATION
addappid(1018850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018851, 1, "334de51773c71fca5ccb8722c0ff765563479be38c632c41d0fa15093c1e7eb4")
addappid(1018852, 1, "f0e5dc9389e5ae0e810603af4708ba7c992600361ea1283f61ef8ca92583272c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1065220)
