-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Empire at War - Gold Pack

-- MAIN APPLICATION
addappid(32470)
addappid(228983)
addappid(228990)
-- Game: addappid(32470)

-- MAIN APP DEPOTS / PACKAGES
addappid(32471, 1, "b0d95d7b0137898764bec9b667898e7c03b73112ac3a88b16807f8487f60a577")
addappid(32472, 1, "ea41a8abf8d40527e10d13cfaba20c15c74906a9516d9448032f1ac57a723669")
addappid(32473, 1, "bbb571e25d9c5eafb127dc6794899e7c1d045ea1460f900228163aa52a4019f1")
addappid(32474, 1, "52e43c909adfff92d3eaf917fdb531b903b50e1d62acfbda26e3cba9bded9220")
addappid(32475, 1, "b7a63a2490f467d120c11c999fe6a1f790a85aee9bb888429cd17148d2b691c7")
addappid(32476, 1, "6a803dcbc434aec3018ac370408cd51b3d418d7b1ba15fb2f1f6d99942012927")
