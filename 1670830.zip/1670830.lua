-- Lua provided by RyzenAPI
-- Game: addappid(1670830)

-- MAIN APPLICATION
addappid(1670830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670831, 1, "25d97a9c2c1ce80be627123ed6ea94ce1426a9e98ec8bad632731e11737180bf")
