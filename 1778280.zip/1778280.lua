-- Lua provided by RyzenAPI
-- Game: addappid(1778280)

-- MAIN APPLICATION
addappid(1778280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778281, 1, "ff7bb32335dafa84cb27419bc7b1ff64f23184d1bb6cdd9ce4a54291a9ea2330")
