-- Lua provided by RyzenAPI
-- Game: Satori

-- MAIN APPLICATION
addappid(2730020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2730021, 1, "cce145d8a81ad0a0ce66c2cf25b6fc8d8fec6020e747f38cf385263e60af5715")

