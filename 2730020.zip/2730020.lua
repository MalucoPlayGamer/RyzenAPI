-- Lua provided by RyzenAPI
-- Game: addappid(2730020)

-- MAIN APPLICATION
addappid(2730020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730021, 1, "cce145d8a81ad0a0ce66c2cf25b6fc8d8fec6020e747f38cf385263e60af5715")
