-- Lua provided by RyzenAPI
-- Game: Swordian Hero

-- MAIN APPLICATION
addappid(1383930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383931, 1, "f45dbba743b2101d456b9c0f7e72575c97bd535bb8a9073896308231703446aa")

