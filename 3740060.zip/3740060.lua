-- Lua provided by SkyAPI 
-- Game: Hapless
addappid(3740060)
addappid(3740061, 1, "47f39abe9c5228fb1c36fa358e6d67582f837f68f88f842f286635294a48e9f8")
