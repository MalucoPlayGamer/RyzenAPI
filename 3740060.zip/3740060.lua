-- Lua provided by RyzenAPI
-- Game: Game: Hapless

-- MAIN APPLICATION
addappid(3740060)
-- Game: addappid(3740060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3740061, 1, "47f39abe9c5228fb1c36fa358e6d67582f837f68f88f842f286635294a48e9f8")
