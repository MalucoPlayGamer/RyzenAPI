-- 4567230's Lua and Manifest Created by Hubcap Manifest
-- DigWorld
-- Created: July 29, 2026 at 06:11:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4567230, 1, "261cbece110d6bf6d3bddfa13455a7efe78c2f023b958ebdc140ab49bc5f7fa3") -- DigWorld
-- MAIN APP DEPOTS
addappid(4567231, 1, "977d34166051b5f08f97d5f9b494695505eac813b73539d265b83d643e5cb72e") -- Depot 4567231
setManifestid(4567231, "3781314954311113466", 2250483625)