-- Lua provided by RyzenAPI
-- Game: AppID 842140

-- MAIN APPLICATION
addappid(842140)

-- MAIN APP DEPOTS / PACKAGES
addappid(842141, 1, "31a0b739430494da52753d544ea8429d8acecf700b9e1ace82f92c973e5a1721")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
