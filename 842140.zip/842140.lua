-- Lua provided by RyzenAPI
-- Game: Game: AppID 842140

-- MAIN APPLICATION
addappid(842140)
-- Game: addappid(842140)

-- MAIN APP DEPOTS / PACKAGES
addappid(842141, 1, "31a0b739430494da52753d544ea8429d8acecf700b9e1ace82f92c973e5a1721")
