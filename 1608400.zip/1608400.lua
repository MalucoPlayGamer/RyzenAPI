-- Lua provided by RyzenAPI
-- Game: Vermillion - VR Painting

-- MAIN APPLICATION
addappid(1608400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608401, 1, "a90a70cee56fe34d1297c3ad2a6aab2587a671e7ba0815ce6f4ad80f32231c92")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
