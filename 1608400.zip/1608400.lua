-- Lua provided by RyzenAPI
-- Game: Vermillion - VR Painting

-- MAIN APPLICATION
addappid(1608400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608401, 1, "a90a70cee56fe34d1297c3ad2a6aab2587a671e7ba0815ce6f4ad80f32231c92")

