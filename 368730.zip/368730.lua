-- Lua provided by RyzenAPI
-- Game: Game: No Time To Explain Remastered

-- MAIN APPLICATION
addappid(368730)
addappid(681570)
-- Game: addappid(368730)

-- MAIN APP DEPOTS / PACKAGES
addappid(368731, 1, "6da0d3a9398313716aae5a6c1eb45437a0f97502ba3395aafb786e203970bcf2")
addappid(368732, 1, "d305084ec1dec0420674dbf2ff380f9ed05bbb4b187f42df1aa062a05aae01a7")
addappid(368733, 1, "61e9b2179791b9a55a9fe3bd4d219f9c253999cb642811976e4d50f57ef6b9d0")
