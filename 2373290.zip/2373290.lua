-- Lua provided by RyzenAPI
-- Game: The Game of Annie 安妮的游戏

-- MAIN APPLICATION
addappid(2373290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373291, 1, "79289c51bceed40bd46b866de1da991c615a833cd014f3dbbc3481cf0f90cc5c")

