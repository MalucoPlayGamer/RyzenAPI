-- Lua provided by RyzenAPI
-- Game: Cendric

-- MAIN APPLICATION
addappid(681460)

-- MAIN APP DEPOTS / PACKAGES
addappid(681461,0,"f3c2ef07e931b2640b679ef2bce798ce428fdf68575d1831f69fbf8d87c218bf")

