-- Lua provided by RyzenAPI
-- Game: Cendric

-- MAIN APPLICATION
addappid(681460)

-- MAIN APP DEPOTS / PACKAGES
addappid(681461,0,"f3c2ef07e931b2640b679ef2bce798ce428fdf68575d1831f69fbf8d87c218bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
