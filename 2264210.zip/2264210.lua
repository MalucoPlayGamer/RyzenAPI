-- Lua provided by RyzenAPI
-- Game: Hentai Puzzle Universe

-- MAIN APPLICATION
addappid(2264210)
-- Game: addappid(2264210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264211, 1, "e7bea39402cce0a7c1acc6dd5dbc6415255422b58abc6d197186f9876e56cc5e")
