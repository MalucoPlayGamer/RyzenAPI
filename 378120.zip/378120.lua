-- Lua provided by RyzenAPI
-- Game: AppID 378120

-- MAIN APPLICATION
addappid(378120)
addappid(430480)

-- MAIN APP DEPOTS / PACKAGES
addappid(378121, 1, "712a51ed10f906da5193bca55dea8040095779690386a8bc2d8a14f099e61011")
addappid(378122, 1, "cdbb9c6f5268bf6201d3a50a13dddd60b5e7e3634474fc888d84d443b439e55a")
addappid(378123, 1, "b21f773174fb06d7e79f796d552738938468cdb6830b3ebbc410573b45011f18")
addappid(378124, 1, "c45a1061d5aea06a336025fa3b8234de198a8a033d23c085520535fe0eae51fa")
addappid(378125, 1, "d03467e9dccaa1850b42b92f49889b04c3741f5b05a240a4fe84545b72959e22")
addappid(378126, 1, "75076561822c75b7acf13db4047a3332a4827f6e7b787948e210cdc78389b77d")
addappid(378127, 1, "7408fc2943309d3cbd1e01ffdcfd3cf2b6528fa92dd1fbe571a7cbcca40c5838")
addappid(378128, 1, "d71bde970003f06e24d4a112746de0a0a37732dc873a2373e8e1be74f4199460")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(383900)
addappid(383901)
addappid(383902)
addappid(383903)
addappid(383904)
addappid(383905)
addappid(383906)
addappid(383907)
addappid(383908)
addappid(383909)
addappid(383910)
addappid(383911)
addappid(403750)
addappid(405220)
