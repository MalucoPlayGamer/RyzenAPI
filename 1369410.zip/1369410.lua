-- Lua provided by RyzenAPI
-- Game: Dream Stone 2

-- MAIN APPLICATION
addappid(1369410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369411, 1, "52b5de90f5376eb44e346fbcf1541a3250f758fceb1c18be90295be190281874")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
