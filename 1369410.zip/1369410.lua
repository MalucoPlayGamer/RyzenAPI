-- Lua provided by RyzenAPI 
-- Game: Dream Stone 2
addappid(1369410)
addappid(1369411, 1, "52b5de90f5376eb44e346fbcf1541a3250f758fceb1c18be90295be190281874")
