-- Lua provided by RyzenAPI
-- Game: addappid(502400)

-- MAIN APPLICATION
addappid(502400)

-- MAIN APP DEPOTS / PACKAGES
addappid(502401, 1, "d11f274a337cdc28d9dd9f5da81ee4bafe5abfa6a64b6eaa1209ebff8942bbe7")
