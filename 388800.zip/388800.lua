-- Lua provided by RyzenAPI
-- Game: Azure Striker Gunvolt

-- MAIN APPLICATION
addappid(388800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(388801, 1, "5f8744e4a19705ec4a0ded7fbd0d4b445e1fcfbb564717d97c7044a70dc02e1c")
addappid(392670, 0, "367ef24dc5a6fb82e1cbd4a0c78713d306517f4028a05d19dae18d172904c3ed")
addappid(396990, 0, "2af52684b5899a198328019969e5c95c38fb8c65bc6e2070802bfac3927a3617")

