-- Lua provided by RyzenAPI
-- Game: Cruise Ship Manager: Prologue - Maiden Voyage

-- MAIN APPLICATION
addappid(2251420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251421, 1, "89e6a27fba4b9884ccbb7ce10e0c332e9e6d1e3de6eeef4fcd7df87328cf8042")
