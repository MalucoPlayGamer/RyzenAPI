-- Lua provided by RyzenAPI 
-- Game: New Citizen Soundtrack
addappid(2210770)
addappid(2210771, 1, "5e57ce61e2d385cd2d2a8674d98ec77c635681c0ff4c0ad6d96ec4ace72284c3")
