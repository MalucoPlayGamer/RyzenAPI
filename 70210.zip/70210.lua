-- Lua provided by RyzenAPI
-- Game: AppID 70210

-- MAIN APPLICATION
addappid(70210)

-- MAIN APP DEPOTS / PACKAGES
addappid(70211, 1, "656a86636fe4ebc379c006b77846e0b8238e5b41eddeaa111fb9c889729d7c9e")
