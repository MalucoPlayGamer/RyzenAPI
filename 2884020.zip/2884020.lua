-- Lua provided by RyzenAPI
-- Game: The Vampire

-- MAIN APPLICATION
addappid(2884020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2884021, 1, "8830daa309a0ddd6568e6bfffe7ab749ac246b0ebf24f075043b8f9191b3f9e3")

