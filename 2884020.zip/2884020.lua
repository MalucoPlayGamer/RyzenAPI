-- Lua provided by RyzenAPI
-- Game: The Vampire

-- MAIN APPLICATION
addappid(2884020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884021, 1, "8830daa309a0ddd6568e6bfffe7ab749ac246b0ebf24f075043b8f9191b3f9e3")
