-- Lua provided by RyzenAPI
-- Game: Death Stream

-- MAIN APPLICATION
addappid(3522230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3522231, 1, "51b49635da4b8cd343c456531e1738a01eedae39fe4f664c0952d0204fc70283")
