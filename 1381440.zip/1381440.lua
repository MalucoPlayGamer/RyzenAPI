-- Lua provided by RyzenAPI
-- Game: 80's OVERDRIVE

-- MAIN APPLICATION
addappid(1381440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381445,0,"b4fa0357d19fe7fc29b96e7ae6bd2f99239490e84bb849cb33bc7168ac7081aa")
addappid(1381446,0,"21e1f55778707b588780e688834557305cd8af1e146f8df92c22c64d8e11084e")
addappid(1381447,0,"857e48877e7e944e2aef76fb4cba081e89081b1f2f177afa07494d9b156bb00d")
addappid(1381448,0,"11724421a193c4f6b5bf9796d2cbedc06964cc837dcba7768d1c2f9ab8cc88e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
