-- Lua provided by RyzenAPI
-- Game: Dragons Legacy

-- MAIN APPLICATION
addappid(2520410)
-- Game: addappid(2520410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520412,0,"6b32c9060790fd709867be8bd6a1bda075a3294a6a5c8c89f8e3757201b7cce6")
addappid(2520413,0,"9ea1305ae156e25a9c1e22778adca41c337a8b30f6e97a61b6a3293fb7943d51")
