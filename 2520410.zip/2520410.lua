-- Lua provided by RyzenAPI
-- Game: Dragons Legacy

-- MAIN APPLICATION
addappid(2520410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2520412,0,"6b32c9060790fd709867be8bd6a1bda075a3294a6a5c8c89f8e3757201b7cce6")
addappid(2520413,0,"9ea1305ae156e25a9c1e22778adca41c337a8b30f6e97a61b6a3293fb7943d51")

