-- Lua provided by RyzenAPI 
-- Game: AppID 488580
addappid(488580)
addappid(488581, 1, "e03cf255394601c91aee038ecd2da48bc6f341e352d1c16b2967d8142507a3cc")
addappid(488582, 1, "5147ba46932e463b10735b9345d9f4a667f57024fdcc61b997b9199a538d9f4e")
