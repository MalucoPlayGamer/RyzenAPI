-- Lua provided by RyzenAPI
-- Game: COROCONNECT

-- MAIN APPLICATION
addappid(1729640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729641, 1, "fbc8cdeeb499cc366acb297c2b411b871863dc8278cce63bfda0b6c8a53c4c1b")

