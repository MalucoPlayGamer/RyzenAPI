-- Lua provided by RyzenAPI
-- Game: Marble Music –  Beat Bounce Ball Video Creator

-- MAIN APPLICATION
addappid(3669900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3669901, 1, "80de056dded4698a3ff10584c4a873bc98e9da33967550442588635a532cb32d")
