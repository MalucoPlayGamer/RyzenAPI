-- Lua provided by RyzenAPI
-- Game: LVN Fake News

-- MAIN APPLICATION
addappid(899990)
addappid(1215680)
addappid(1327490)

-- MAIN APP DEPOTS / PACKAGES
addappid(899991, 1, "4c76fbc5ca046db8273995a6f65e8fad739861ba61aa24e5386f9289c075ac98")

