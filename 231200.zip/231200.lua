-- Lua provided by RyzenAPI
-- Game: Kentucky Route Zero: PC Edition

-- MAIN APPLICATION
addappid(231200)

-- MAIN APP DEPOTS / PACKAGES
addappid(231203,0,"828bdc92db9b07fd9ded2bc02e1c73e5e64020e213935474927fcb790aa609c7")
