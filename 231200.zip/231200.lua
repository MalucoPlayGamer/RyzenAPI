-- Lua provided by RyzenAPI
-- Game: Kentucky Route Zero: PC Edition

-- MAIN APPLICATION
addappid(231200)

-- MAIN APP DEPOTS / PACKAGES
addappid(231203,0,"828bdc92db9b07fd9ded2bc02e1c73e5e64020e213935474927fcb790aa609c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
