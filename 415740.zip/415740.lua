-- Lua provided by RyzenAPI
-- Game: OmniBus

-- MAIN APPLICATION
addappid(415740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(415741, 1, "cdfa04cc42e7ed60ad241d54edf53068a898934c8022a8aa610aa79090bfa55c")
addappid(415744, 1, "f29293fe67bd46ce4f62f2d4e2feae295a91e1f2c0b868126c79775ee2e5eb48")

