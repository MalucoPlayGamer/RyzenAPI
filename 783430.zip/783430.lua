-- Lua provided by RyzenAPI
-- Game: Gatlin'

-- MAIN APPLICATION
addappid(783430)

-- MAIN APP DEPOTS / PACKAGES
addappid(783431, 1, "6966825ba569e12bf528041690884a797a56215efb90d2c9bf06b40c277c6ac9")

