-- Lua provided by SkyAPI 
-- Game: Gatlin'
addappid(783430)
addappid(783431, 1, "6966825ba569e12bf528041690884a797a56215efb90d2c9bf06b40c277c6ac9")
