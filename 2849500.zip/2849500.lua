-- Lua provided by RyzenAPI
-- Game: addappid(2849500)

-- MAIN APPLICATION
addappid(2849500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849501, 1, "ce97cea97e7cd697db18696a36546074f635a78de738debebc011dc220ce3bd7")
