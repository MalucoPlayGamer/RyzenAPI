-- Lua provided by RyzenAPI 
-- Game: VISK Prologue
addappid(3301760)
addappid(3301761, 1, "61bf4645484864164ccaa6f1f03c535ce05221b079291522ae8d53b1ed009aa6")
