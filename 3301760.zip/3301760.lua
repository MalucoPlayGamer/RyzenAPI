-- Lua provided by RyzenAPI
-- Game: VISK Prologue

-- MAIN APPLICATION
addappid(3301760)
-- Game: addappid(3301760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301761, 1, "61bf4645484864164ccaa6f1f03c535ce05221b079291522ae8d53b1ed009aa6")
