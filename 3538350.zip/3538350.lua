-- Lua provided by RyzenAPI
-- Game: Trump Simulator 2025

-- MAIN APPLICATION
addappid(3538350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538351, 1, "d881859e27503374ec8dc1c00fbbb894339d65ce477987dedd4959ad20f7357c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
