-- Lua provided by RyzenAPI
-- Game: Trump Simulator 2025

-- MAIN APPLICATION
addappid(3538350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538351, 1, "d881859e27503374ec8dc1c00fbbb894339d65ce477987dedd4959ad20f7357c")

