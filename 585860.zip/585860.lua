-- Lua provided by RyzenAPI
-- Game: AppID 585860

-- MAIN APPLICATION
addappid(585860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(585861, 1, "4428035a0894745a62bcdc5a70090c046a63d94b14cd9b719e49c6058ee62c9b")

