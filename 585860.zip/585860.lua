-- Lua provided by RyzenAPI
-- Game: Game: AppID 585860

-- MAIN APPLICATION
addappid(585860)
-- Game: addappid(585860)

-- MAIN APP DEPOTS / PACKAGES
addappid(585861, 1, "4428035a0894745a62bcdc5a70090c046a63d94b14cd9b719e49c6058ee62c9b")
