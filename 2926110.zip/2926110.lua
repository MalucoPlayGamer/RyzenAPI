-- Lua provided by RyzenAPI
-- Game: Vay

-- MAIN APPLICATION
addappid(2926110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926113,0,"7cf8d3b814589e40a828e028ddc449605e0f7186ec419c7df39ad51e3152c330")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
