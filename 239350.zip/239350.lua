-- Lua provided by RyzenAPI
-- Game: Spelunky

-- MAIN APPLICATION
addappid(239350)

-- MAIN APP DEPOTS / PACKAGES
addappid(239351, 1, "c73f8430e3445bc22b8394a97dedbad3103ee137ea5da92fbd98915fec8957ec")
