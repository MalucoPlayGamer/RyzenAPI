-- Lua provided by RyzenAPI
-- Game: 373750

-- MAIN APPLICATION
addappid(373750)
-- Game: addappid(373750)

-- MAIN APP DEPOTS / PACKAGES
addappid(373751, 1, "da220cc1aae8b1db4bef88e5fde09c555b9b9fd11a4e9f16c3509f4f1300cb7b")
