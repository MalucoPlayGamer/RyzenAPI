-- Lua provided by RyzenAPI
-- Game: AppID 373750

-- MAIN APPLICATION
addappid(373750)

-- MAIN APP DEPOTS / PACKAGES
addappid(373751, 1, "da220cc1aae8b1db4bef88e5fde09c555b9b9fd11a4e9f16c3509f4f1300cb7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
