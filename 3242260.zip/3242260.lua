-- Lua provided by SkyAPI 
-- Game: Banisher Demo
addappid(3242260)
addappid(3242261, 1, "96de8800256b69f77d9803d1d2ac262b0ab8263a2fdb60bb0da0d00296daaf92")
