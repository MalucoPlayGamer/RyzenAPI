-- Lua provided by RyzenAPI
-- Game: Cyber Seraph

-- MAIN APPLICATION
addappid(1310230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310232,0,"052260118b105213c315d83759290a0dba4afff0abc490c72919248d19cf572b")

