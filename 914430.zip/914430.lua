-- Lua provided by RyzenAPI
-- Game: Pro Office Calculator

-- MAIN APPLICATION
addappid(914430)
-- Game: addappid(914430)

-- MAIN APP DEPOTS / PACKAGES
addappid(914431, 1, "b42cec0024569192a17cce4e46163302003b49b8753eee7d6f63ef16d58475b9")
addappid(914432, 1, "fbed80502ebe543750de9e8a372735eeef23aea843a2aa626fbc751dae083643")
addappid(914433, 1, "36c6ec7af035be562bcad6a51c3c970c8bcc737f6af306f526ed2af38ed7991e")
