-- Lua provided by RyzenAPI
-- Game: addappid(2375960)

-- MAIN APPLICATION
addappid(2375960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375961, 1, "97a019b5245f4fa9cc5c69829a82c44be5ea8645d6b577dad0aefbbe0e251ab6")
