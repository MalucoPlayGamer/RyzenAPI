-- Lua provided by SkyAPI 
-- Game: Entogious
addappid(2375960)
addappid(2375961, 1, "97a019b5245f4fa9cc5c69829a82c44be5ea8645d6b577dad0aefbbe0e251ab6")
