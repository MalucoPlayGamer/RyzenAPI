-- Lua provided by RyzenAPI
-- Game: Xenomarine

-- MAIN APPLICATION
addappid(676830)
-- Game: addappid(676830)

-- MAIN APP DEPOTS / PACKAGES
addappid(676831, 1, "1dc139a4422c8008e06feaf7d9b1079f861f0a0547ae2cfece8a165a7dab5c6c")
addappid(676832, 1, "13632967aa3d92bfa930dc860b0e61c84565cbb7f2ec322e335b21f13990c423")
addappid(676833, 1, "6aa6cd5a0ea776c3013412e2ab9c445eb8b15edc49cb3102a152834fdb255905")
addappid(676834, 1, "a591254950c2dd5f071255cf132d8d25e6bb24a40bb362b45371b8de00c6181d")
