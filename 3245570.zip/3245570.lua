-- Lua provided by RyzenAPI
-- Game: addappid(3245570)

-- MAIN APPLICATION
addappid(3245570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245571, 1, "398e02d6bcb3be562ac2a42f4f109889bd65833ec5155dca7ec5f5451998339d")
