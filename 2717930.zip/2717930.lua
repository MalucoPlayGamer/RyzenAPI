-- Lua provided by RyzenAPI
-- Game: Game: BOTSU Demo

-- MAIN APPLICATION
addappid(2717930)
-- Game: addappid(2717930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717931, 1, "5574b799e1d8b41acbdc35b11ab788fdc6032a54005307a818d4fb0232af7a0d")
