-- Lua provided by SkyAPI 
-- Game: Zadel Princess
addappid(1893330)
addappid(1893331, 1, "0eb5c88dbee525f7fd426a28173210e298bc6a3d43fc056927d00f9094cd5a0a")
