-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(583740)
addappid(583741)
addappid(823780)

-- MAIN APP DEPOTS / PACKAGES
addappid(583742,0,"14ec57a4b67c7372c0f7d8b0ac3ee9f70a7a78645bca1742566072ed5f8fd07f")

