-- Lua provided by RyzenAPI
-- Game: Pro Arena Alpha

-- MAIN APPLICATION
addappid(1468960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468961, 1, "3e819a89dfe132b3337786b8d44fb9332984f94112215651e970a59557456d8d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1778570)
addappid(1780030)
