-- Lua provided by RyzenAPI
-- Game: Game: SPORE™ Galactic Adventures

-- MAIN APPLICATION
addappid(24720)
-- Game: addappid(24720)

-- MAIN APP DEPOTS / PACKAGES
addappid(24721, 1, "7c29bcbd157fdb3dbc911ad1b3742c86335c198abe19c7182f88f65366c8c972")
addappid(24729, 1, "0b1088b24e552bfdb30050c58e4b3e98079339d15bb2af7e4154d46250e57f1b")
