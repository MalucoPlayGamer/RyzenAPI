-- Lua provided by RyzenAPI
-- Game: AppID 1370050

-- MAIN APPLICATION
addappid(1370050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370051, 1, "a07211cd8ea7b3657552476d07beae8090dc8eb619139b58e5c1d4ab59ddde62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
