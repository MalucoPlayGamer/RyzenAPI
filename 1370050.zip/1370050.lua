-- Lua provided by RyzenAPI
-- Game: 1370050

-- MAIN APPLICATION
addappid(1370050)
-- Game: addappid(1370050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370051, 1, "a07211cd8ea7b3657552476d07beae8090dc8eb619139b58e5c1d4ab59ddde62")
