-- Lua provided by RyzenAPI
-- Game: Game: AppID 401330

-- MAIN APPLICATION
addappid(401330)
-- Game: addappid(401330)

-- MAIN APP DEPOTS / PACKAGES
addappid(401331, 1, "26f513e9b83d93a8eb016389bb25c7775c49dfec4f4cb7425bae765d5f62e0b9")
addappid(401332, 1, "f439af8350da4a851b079d04f14bc97cbcf79516a9f32b75b9cd58749b2a43c7")
addappid(401333, 1, "7ffdbb0244c3a55331ca33d5c25047bc14d89f8c642e863e577835fc61d3a60c")
