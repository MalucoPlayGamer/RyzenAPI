-- Lua provided by RyzenAPI
-- Game: Hazumi and the Pregnation

-- MAIN APPLICATION
addappid(1136330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136331, 1, "40c1c0fde7490f9030e432c6e1fd3f1255d18239e71874f299b4c740e7022005")
addappid(1136332, 1, "81f6f4911accd9bbb36335b66367078e8ec2964f01b9c24ab79524ea9ff1de2d")

