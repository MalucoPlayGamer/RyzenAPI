-- Lua provided by RyzenAPI
-- Game: addappid(3297730)

-- MAIN APPLICATION
addappid(3297730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297731, 1, "2be3a4b311f1b379bb53d7ae4c069ed5c370c38210d6b754325902fc87ff3c0f")
