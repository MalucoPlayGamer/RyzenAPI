-- Lua provided by RyzenAPI
-- Game: Rain World

-- MAIN APPLICATION
addappid(610070)
addappid(1933390)
addappid(2282210)
addappid(2857120)
addappid(3588290)

-- MAIN APP DEPOTS / PACKAGES
addappid(312520, 1, "ef800a2479027ef2829d53f0c9cccd74da5c5f7fa82e5bb626c069cd07cd2b99")
addappid(312521, 1, "f36b23dfaca5b387508e33fe17732bcd48a16ab0fef3b1eb819494ad76d5ce2a")
addappid(610070, 1, "f63bf7ebc4155578831d31a1a4dfa4cc941b91f5834ef4126562b0d08b2c3cc4")
addappid(1933390, 1, "cf34e0fb21789d7fd65c827a966d574e2fbd1e6b0cb47f81322256690ad70532") -- (windows)
addappid(2282211, 1, "099e2d6e7b4cf927fd000cfc936b650273429c4ea2131ba325b8d1e3b8b9d782")
addappid(2282212, 1, "2c67cabbc82a1b1921503214969f7e616938985e730245cfff3c5e165005366f")
addappid(2857120, 1, "f998f9f9862dc3cc8026d11be949bc4d7c17882f1240b6982766721fceaae0ad") -- (windows)
addappid(3588291, 1, "c82ba1d1991db8a741ede184960b07edb56d2c0f44679f58d0427cdec86114a0")
addappid(3588292, 1, "2bbda8e103e2ec9e5a8e6e2a8ff85fc6fc3937e3fd7acf811326c25dc2d7edce")

