-- Lua provided by RyzenAPI
-- Game: addappid(1563860)

-- MAIN APPLICATION
addappid(1563860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563861, 1, "bcf375ac0577d9a35c923ded742f410a9829e8aaaccaaa2e5e765e2d8cc944b8")
