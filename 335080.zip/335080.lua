-- Lua provided by RyzenAPI
-- Game: addappid(335080)

-- MAIN APPLICATION
addappid(335080)

-- MAIN APP DEPOTS / PACKAGES
addappid(335081, 1, "a406d567fa86dc81f771c18d3f353dc80da78659f6309d211a07d6057e5ba24e")
