-- Lua provided by RyzenAPI
-- Game: AppID 335080

-- MAIN APPLICATION
addappid(335080)

-- MAIN APP DEPOTS / PACKAGES
addappid(335081, 1, "a406d567fa86dc81f771c18d3f353dc80da78659f6309d211a07d6057e5ba24e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
