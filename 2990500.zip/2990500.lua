-- Lua provided by RyzenAPI
-- Game: Necromancer's Revenge

-- MAIN APPLICATION
addappid(2990500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990501, 1, "96c31935f0882160efef103359a98c1c69e53b411901ce205c27893d16879e57")
