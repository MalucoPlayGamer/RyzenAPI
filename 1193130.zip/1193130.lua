-- Lua provided by RyzenAPI
-- Game: Game: AppID 1193130

-- MAIN APPLICATION
addappid(1193130)
-- Game: addappid(1193130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193131, 1, "ce74c99d20d5864f7f82030e9e683614fc5bd98de1111248423c85d56f15a7d9")
