-- Lua provided by RyzenAPI
-- Game: Backrooms: Lost

-- MAIN APPLICATION
addappid(2924300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924301, 1, "4840cbbc09c9643edc858871312bb9f15d4a686a5c4bb7e2ec31786f762295bd")

