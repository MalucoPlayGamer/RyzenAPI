-- Lua provided by RyzenAPI
-- Game: 1018180

-- MAIN APPLICATION
addappid(1018180)
-- Game: addappid(1018180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018181, 1, "6b124ace8c5ec24c201d9bb5c71e40f7a326da31281508393ba539a85225eadb")
