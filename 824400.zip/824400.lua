-- Lua provided by RyzenAPI
-- Game: Havoc in heaven

-- MAIN APPLICATION
addappid(824400)

-- MAIN APP DEPOTS / PACKAGES
addappid(824401,0,"0d6faf2eadba5183163cfb30a6c07265c04fbdd856a52e1007b8c10b93d6be86")

