-- Lua provided by RyzenAPI
-- Game: Shallow Space

-- MAIN APPLICATION
addappid(305840)

-- MAIN APP DEPOTS / PACKAGES
addappid(305850,0,"be386edf9bc3a6b26f182fdfc8589fa0e13c23cf8c54bcce4d8195276e4edd40")
addappid(305851,0,"45fc17b1694039b2d4a14b6df0f9c9811b0d6852533e10996acff5c4f738dbad")
addappid(305852,0,"b2d3128990f47148d029a6353029b24bc58ab5f108de5177be84fa8d6b6d4e23")

