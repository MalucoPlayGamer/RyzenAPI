-- Lua provided by SkyAPI 
-- Game: AppID 2452060
addappid(2452060)
addappid(2452061, 1, "64a7b1e7c16891061ff62547e1b0064bacde9797f8918d5cbd010a158eec41e9")
