-- Lua provided by RyzenAPI
-- Game: Game: Backrooms: The Project Demo

-- MAIN APPLICATION
addappid(2404080)
-- Game: addappid(2404080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404081, 1, "e2dfe8913db4affe44f294e58b8f5db8ee0fddef3c3705abc45ef8a0667424b6")
