-- Lua provided by RyzenAPI 
-- Game: Swimmer Admiration
addappid(1667550)
addappid(1667551, 1, "82c0d5a6b21937ae9947fe8c2d419761e22cb3f91e8208d3dec1e2978ad92c4c")
