-- Lua provided by RyzenAPI
-- Game: addappid(386290)

-- MAIN APPLICATION
addappid(228984)
addappid(386290)
addappid(386293)

-- MAIN APP DEPOTS / PACKAGES
addappid(386292,0,"980764038df5bda057394d51547a1a87ccaca8117eff9d1f481fefa92ec33edc")
