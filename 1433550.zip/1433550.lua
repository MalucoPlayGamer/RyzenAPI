-- Lua provided by RyzenAPI
-- Game: Space Gladiators: The Hole

-- MAIN APPLICATION
addappid(1433550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433551, 1, "74516438ee689418215c17febc2ac3b7f0c2dd4cac62950d9c58ab6ce6ec9288")
