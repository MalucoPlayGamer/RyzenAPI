-- Lua provided by RyzenAPI
-- Game: AppID 9870

-- MAIN APPLICATION
addappid(9870)

-- MAIN APP DEPOTS / PACKAGES
addappid(9871, 1, "cbc919b61c587001bd519f6087b5b8c8d3d3ca85dd9146e49f2dcb00c14b3ffc")
