-- Lua provided by RyzenAPI
-- Game: Game: 神启神落

-- MAIN APPLICATION
addappid(1523130)
-- Game: addappid(1523130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523131, 1, "d276d6408202521589c44a4b047086a9dd4735d1b611160141b366487361ceb7")
