-- Lua provided by RyzenAPI
-- Game: 神启神落

-- MAIN APPLICATION
addappid(1523130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1523131, 1, "d276d6408202521589c44a4b047086a9dd4735d1b611160141b366487361ceb7")

