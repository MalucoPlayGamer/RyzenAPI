-- Lua provided by SkyAPI 
-- Game: Arcadegeddon
addappid(1515640)
addappid(1515641, 1, "7900ed37ecbfd14d823fdc731275d0ece8c1d6d9dd53634bc77de02af8715775")
