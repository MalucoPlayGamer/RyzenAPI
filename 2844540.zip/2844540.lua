-- Lua provided by RyzenAPI 
-- Game: JR EAST Train Simulator: Takasaki Line (Ueno to Takasaki) E233-3000 series
addappid(2844540)
addappid(2844541, 1, "cd3468c292f004a6312f2a428070144db9c4e9b9e07135c09e3f7935b89f324b")
addappid(2844542, 1, "a7fadc3111116c8531fbe0ee6396b05da4f388ae4f3deaab52f365a075d5d9d0")
