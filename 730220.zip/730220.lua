-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Video Game Trivia Deluxe

-- MAIN APPLICATION
addappid(730220)

-- MAIN APP DEPOTS / PACKAGES
addappid(730221, 1, "4d0096f19d9211161410d80b363fffec6437dd99b85f197e8e4ae0e970d028a6")

