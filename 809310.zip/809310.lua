-- Lua provided by RyzenAPI
-- Game: AppID 809310

-- MAIN APPLICATION
addappid(809310)

-- MAIN APP DEPOTS / PACKAGES
addappid(809311, 1, "10f38d47a72b2b67c98ee9a739d6e95eaee54c8de67fc17e7f632b6db426db14")
