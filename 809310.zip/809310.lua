-- Lua provided by RyzenAPI
-- Game: AppID 809310

-- MAIN APPLICATION
addappid(809310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809311, 1, "10f38d47a72b2b67c98ee9a739d6e95eaee54c8de67fc17e7f632b6db426db14")

