-- Lua provided by RyzenAPI
-- Game: Supraball

-- MAIN APPLICATION
addappid(321400)

-- MAIN APP DEPOTS / PACKAGES
addappid(321401, 1, "5ddaa6e2d3a6273936be783b3fe4adc297950578ac85308dd7a55c34781dbf61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
