-- Lua provided by RyzenAPI
-- Game: addappid(1567294)

-- MAIN APPLICATION
addappid(1567294)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567294,0,"fea36c9f627298d47f12b1e0a95f65246942c71357fdcdaa9df4c16a29177bb2")
