-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Pioneers of Olive Town - Princess Sakuna's Heavenly Garb

-- MAIN APPLICATION
addappid(1567294)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567294,0,"fea36c9f627298d47f12b1e0a95f65246942c71357fdcdaa9df4c16a29177bb2")

