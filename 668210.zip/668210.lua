-- Lua provided by RyzenAPI
-- Game: Game: AppID 668210

-- MAIN APPLICATION
addappid(668210)
-- Game: addappid(668210)

-- MAIN APP DEPOTS / PACKAGES
addappid(668211, 1, "8a5a9d52569b4c67ff2e01e7e1df628d3ab0991ae2a77ade3a8d49e12fd6fe3d")
addappid(668212, 1, "ae6bf2eb6d1784c18d6683ca1d68be1c5af7c27dadb6e67cfc769c3d0cf82fcc")
