-- Lua provided by RyzenAPI
-- Game: 3464590

-- MAIN APPLICATION
addappid(3464590)
-- Game: addappid(3464590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464590,0,"34a15558cad10dbf91bbb3f82e56f56bfdce3e80ca105b90fb69296f4c94d94f")
