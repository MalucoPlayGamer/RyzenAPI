-- Lua provided by SkyAPI 
-- Game: My Lovely Empress Digital Artbook
addappid(3068260)
addappid(3068261, 1, "d9dff5430bedd5fad46c46c7da45a222f0649175f86af44956896fc54c327ac5")
