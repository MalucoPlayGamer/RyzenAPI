-- Lua provided by RyzenAPI
-- Game: 3068260

-- MAIN APPLICATION
addappid(3068260)
-- Game: addappid(3068260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068261, 1, "d9dff5430bedd5fad46c46c7da45a222f0649175f86af44956896fc54c327ac5")
