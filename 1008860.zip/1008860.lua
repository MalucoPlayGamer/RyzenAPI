-- Lua provided by RyzenAPI 
-- Game: Repella Fella
addappid(1008860)
addappid(1008861, 1, "67c9aee989a86d68fc70efb38733e62d84a0709df9f8cfaed7d7458f156cef45")
addappid(2406090)
