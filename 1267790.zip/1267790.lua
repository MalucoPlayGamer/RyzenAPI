-- Lua provided by RyzenAPI
-- Game: AppID 1267790

-- MAIN APPLICATION
addappid(1267790)
-- Game: addappid(1267790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267791, 1, "b49eb1c5f696ce4ec89a7ebcf9f8c4a0c9dccae0ffa7216176e23c0aefc5de61")
