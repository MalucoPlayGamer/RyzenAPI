-- Lua provided by RyzenAPI
-- Game: Game: Proteus

-- MAIN APPLICATION
addappid(219680)
-- Game: addappid(219680)

-- MAIN APP DEPOTS / PACKAGES
addappid(219681, 1, "7cc04e866cb004519267797f3f0b3df827693cc1e1c29603d59e3f09822c987a")
addappid(219682, 1, "8c4bac87632a54a07f790f95da9911aca7e4701ea8eb4b502bf50f8e34bfbf18")
addappid(219683, 1, "a0974733c105eebfcf892e5c11adb874aae726034e649d0f4464d34d585e3c85")
