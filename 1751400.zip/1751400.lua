-- Lua provided by RyzenAPI
-- Game: Winter Warfare: Survival

-- MAIN APPLICATION
addappid(1751400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751401, 1, "9289adf6f6c07a5b69d3b59d1061c7a052ee9e9bd9076c55b2625148c265ef83")

