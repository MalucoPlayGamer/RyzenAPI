-- Lua provided by RyzenAPI
-- Game: Game: AppID 494660

-- MAIN APPLICATION
addappid(494660)
-- Game: addappid(494660)

-- MAIN APP DEPOTS / PACKAGES
addappid(494661, 1, "af6555cd140893ff5f2587e39a32cfbde6a309322aa1bced446197b7ac61ad6a")
