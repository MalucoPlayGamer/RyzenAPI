-- Lua provided by RyzenAPI
-- Game: Game: Sophisticated Puzzle

-- MAIN APPLICATION
addappid(875670)
-- Game: addappid(875670)

-- MAIN APP DEPOTS / PACKAGES
addappid(875671, 1, "44e0852421fb51e5e42115476ea764295db5608b3e5a72800b040ccd2452ee32")
