-- Lua provided by RyzenAPI
-- Game: AppID 2865370

-- MAIN APPLICATION
addappid(2865370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865371, 1, "7a5dabb3c5971af6deaf9ce9da511dbd663ace7f797204a03e5073315a50ff7a")
