-- Lua provided by SkyAPI 
-- Game: Shotgun Shenanigans
addappid(2192350)
addappid(2192351, 1, "7b571797fc98c55100405152a5abd5d545f7d809dc9fde99ac53fb037dc8d029")
