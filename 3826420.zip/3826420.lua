-- Lua provided by RyzenAPI
-- Game: Spirited Line

-- MAIN APPLICATION
addappid(3826420) -- Spirited Line

-- MAIN APP DEPOTS / PACKAGES
addappid(3826421, 1, "6512d1e32a077b7ea9e1ee0d07a6fd860f1a612008c182ee461fd24ff8e96e64") -- Depot 3826421

