-- Lua provided by RyzenAPI
-- Game: addappid(1827310)

-- MAIN APPLICATION
addappid(1827310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827311, 1, "fe26c38debb54a038a37c7c56ef9341239eb330a61c4afe81ff0241a9ca3178b")
