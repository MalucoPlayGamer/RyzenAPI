-- Lua provided by RyzenAPI 
-- Game: Lost Princess: City
addappid(2765350)
addappid(2765351, 1, "1902afe1b8d8d4891697a67aae2685ebabcf72033c8582f2cec677986ab18821")
