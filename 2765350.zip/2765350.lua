-- Lua provided by RyzenAPI
-- Game: Lost Princess: City

-- MAIN APPLICATION
addappid(2765350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765351, 1, "1902afe1b8d8d4891697a67aae2685ebabcf72033c8582f2cec677986ab18821")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
