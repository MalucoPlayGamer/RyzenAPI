-- Lua provided by RyzenAPI
-- Game: Crayon Chronicles

-- MAIN APPLICATION
addappid(341510)
-- Game: addappid(341510)

-- MAIN APP DEPOTS / PACKAGES
addappid(341511, 1, "2b3f12188044c3523432d11f9cdcd748c5d7dffa4c32ef86c9e2d5de389ef992")
