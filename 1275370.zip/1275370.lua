-- Lua provided by RyzenAPI
-- Game: Sharded World

-- MAIN APPLICATION
addappid(1275370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275372,0,"57117e972af76ef83e0679b154b55bdf519de47bd3403515df5e2757472791c4")
