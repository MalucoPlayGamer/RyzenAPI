-- Lua provided by RyzenAPI
-- Game: Heart of Dungeon

-- MAIN APPLICATION
addappid(1426950)
addappid(1426951)
addappid(1426952)
addappid(1426954)
addappid(1426955)
addappid(1426956)
addappid(1426957)
addappid(1426958)
addappid(1426959)
addappid(1989380)
addappid(1989381)
addappid(1989382)
addappid(1989383)
addappid(1989384)
addappid(1989385)
addappid(1989386)
addappid(1989387)
addappid(1989388)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426953,0,"5105cff5a450d09fa74e06efa84c13e03015f4efad65ab5d1f6d3ac3a81a020a")

