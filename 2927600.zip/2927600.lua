-- Lua provided by RyzenAPI
-- Game: Natsuno-Kanata: Beyond Summer OST

-- MAIN APPLICATION
addappid(2927600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927601, 1, "e6e530981ff5d58ca596a22c3563f0f914edca6253f3f867f0f648ea2d3da24e")
