-- Lua provided by RyzenAPI
-- Game: addappid(735490)

-- MAIN APPLICATION
addappid(735490)

-- MAIN APP DEPOTS / PACKAGES
addappid(735491, 1, "30a67f2c75951c61e8928fa7e37e3366f4f9b87291ee8a69a64ac89207b389fe")
