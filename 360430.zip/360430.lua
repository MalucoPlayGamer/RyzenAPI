-- Lua provided by RyzenAPI
-- Game: Mafia III: Definitive Edition

-- MAIN APPLICATION
addappid(360430)

-- MAIN APP DEPOTS / PACKAGES
addappid(360431, 1, "4a3e72723286eab2b8e99756608b5e7e189945dac142d4db09e2641bcc60eae8")
addappid(360432, 1, "1244262974460b4777d46674d5b9c0b4562810f162bf0dd526d29db46cfd6f40")
addappid(360438, 1, "9cc9b741c2bf74a35787dab0db3c733085d867eb1b60ae5f2f5ddce99c3facdd")
addappid(360439, 1, "8468c3e4cc98f66cdb0829e2da136c7ec2a00d2ccffc2c6c6753040cab176213")
addappid(511890, 0, "629e0b865b1822be42ca68d57c673a35661ce023442fded770e0388c63355c8d")
addappid(511892, 0, "d42487684b1cfe24dda0c1b58dee70794bf0ff8e154d4c780e2b1b2fa06dd24f")
addappid(511898, 0, "fcbcd4dd944fbac6e43ad4e5a24b5b49232353293a7afa5cdf2a9340b213badf")
addappid(511899, 0, "6b42977a58e581138a7b83a7b0f376971cbef0938280a627ad62d0af4ad32374")
addappid(598020, 0, "bfbf614d0bf361b7a9a01c2131b1562dcda664bdaf0f0cf3327e6a00dfbdd4f5")
addappid(598021, 0, "84b841715b6a1064475d21d2ee14302cdbf40ff3bbdd0f6a8c2382f7bd3355fe")
addappid(598022, 0, "f2d9fd1f15e2ee238b32f524799d913c8166a4d09498a68d9451a78c44d8af3f")
addappid(598029, 0, "d31679d286f13684adf1234b8418621ea8722da3ab886b992ae6f8dbf539576b")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(511891)
