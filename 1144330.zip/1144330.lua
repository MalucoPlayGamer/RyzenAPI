-- Lua provided by RyzenAPI
-- Game: Game: AppID 1144330

-- MAIN APPLICATION
addappid(1144330)
-- Game: addappid(1144330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144331, 1, "a9bbdd3869b5eddeef475a6031d3e2c365723251aa9ccbf31a05cfe4236de640")
