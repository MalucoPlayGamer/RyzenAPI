-- Lua provided by RyzenAPI
-- Game: Game: Dreams of Desire: Definitive Edition

-- MAIN APPLICATION
addappid(1639990)
-- Game: addappid(1639990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639991, 1, "645adb215487c20daafb25d9c56565e9814181132d0f21e9327896852eefd3c5")
