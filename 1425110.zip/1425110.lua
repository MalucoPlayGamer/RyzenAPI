-- Lua provided by RyzenAPI
-- Game: Space Empires I

-- MAIN APPLICATION
addappid(1425110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425111, 1, "c3132dabff8a0596e2c9c72898090aa2a65e9fa93075e2a49c5c298895a872cd")
