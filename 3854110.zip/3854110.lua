-- Lua provided by RyzenAPI
-- Game: Mnemonimov

-- MAIN APPLICATION
addappid(3854110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3854111,0,"a6b35dfb36455d3e6b141b00924fb6737593fa938a0fb266df3a159de8e534ed")

