-- Lua provided by RyzenAPI
-- Game: 勇者无畏 Demo

-- MAIN APPLICATION
addappid(2672580)
-- Game: addappid(2672580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672581, 1, "67d60bce32f20bc4437c13a18fa4ee1fd5e98ed3276ef21036a02516f86bff55")
