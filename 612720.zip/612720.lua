-- Lua provided by RyzenAPI
-- Game: AppID 612720

-- MAIN APPLICATION
addappid(612720)

-- MAIN APP DEPOTS / PACKAGES
addappid(612721, 1, "d3575fdef5f8a4429ed0be59eb02c6992fe5037e76f3ab08e33f2e8729a51e8e")
addappid(612723, 1, "d91319bdf93b20e0aa4fb1489a78275aae6763acd5e4b8f97b6c56583b95bb56")
addappid(612724, 1, "da6b749c1231609d17710244325041e79623a34dafe113ec694486f2a8101edb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
