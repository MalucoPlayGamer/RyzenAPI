-- Lua provided by RyzenAPI
-- Game: addappid(1462900)

-- MAIN APPLICATION
addappid(1462900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462901, 1, "e8e1d7f71c3b639c8260ad3c83fe9e78f6aba9b3fa1832ca005b4dcc65650ed1")
