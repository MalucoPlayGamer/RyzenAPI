-- Lua provided by RyzenAPI
-- Game: AppID 917840

-- MAIN APPLICATION
addappid(917840)

-- MAIN APP DEPOTS / PACKAGES
addappid(917841, 1, "717d633f47e8bad4552c525d6dd7caa91debedfe65ac6bf86b6b7e1d6f51826a")
