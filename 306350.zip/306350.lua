-- Lua provided by RyzenAPI
-- Game: addappid(306350)

-- MAIN APPLICATION
addappid(306350)

-- MAIN APP DEPOTS / PACKAGES
addappid(306351, 1, "61b3b8a9468013b66cfe6a5d4859118599ce061520cbdebe6c6f264b2843d66e")
