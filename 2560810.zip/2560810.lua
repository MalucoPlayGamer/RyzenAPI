-- Lua provided by RyzenAPI
-- Game: Game: Akasha Playtest

-- MAIN APPLICATION
addappid(2560810)
-- Game: addappid(2560810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560811, 1, "aee6a2b2cccf766e395b33362342ab4d3cc5015f5d1e22175be75e6c8ae5eeb7")
