-- Lua provided by RyzenAPI 
-- Game: AppID 3604320
addappid(3604320)
addappid(3604321, 1, "9253308044c28fa78ab9e22135c527b2f61a6367a2bb012bc8f3051ce8c38deb")
