-- Lua provided by SkyAPI 
-- Game: Shrieking Darkness: Reloaded
addappid(2199750)
addappid(2199751, 1, "92e71c014e4cb9d5807e49b2b48d44df99d259ee00b201b0a49506c8af116c08")
