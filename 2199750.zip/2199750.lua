-- Lua provided by RyzenAPI
-- Game: Shrieking Darkness: Reloaded

-- MAIN APPLICATION
addappid(2199750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199751, 1, "92e71c014e4cb9d5807e49b2b48d44df99d259ee00b201b0a49506c8af116c08")

