-- Lua provided by RyzenAPI
-- Game: 1699450

-- MAIN APPLICATION
addappid(1699450)
-- Game: addappid(1699450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699451, 1, "3d6ee51be2d4257f29a831b673aedb6f0990039837501f0f85fbcb7cd115eec4")
