-- Lua provided by RyzenAPI
-- Game: 964220

-- MAIN APPLICATION
addappid(964220)
-- Game: addappid(964220)

-- MAIN APP DEPOTS / PACKAGES
addappid(964221, 1, "e568e3cddff57ff200d8613d49b9aba65456701c179375e94781e01e40b9b9e1")
