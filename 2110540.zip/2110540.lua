-- Lua provided by RyzenAPI
-- Game: The Suits Have Gone Mad!

-- MAIN APPLICATION
addappid(2110540)
addappid(2461180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110541, 1, "71770cce95a9dbb337f5ea399ee677e26ea48892a29247bcfd1c50312027b54d")

