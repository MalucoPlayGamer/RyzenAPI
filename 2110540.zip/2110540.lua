-- Lua provided by RyzenAPI
-- Game: The Suits Have Gone Mad!

-- MAIN APPLICATION
addappid(2110540)
addappid(2461180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2110541, 1, "71770cce95a9dbb337f5ea399ee677e26ea48892a29247bcfd1c50312027b54d")

