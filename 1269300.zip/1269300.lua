-- Lua provided by RyzenAPI
-- Game: This Means Warp

-- MAIN APPLICATION
addappid(1269300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269301, 1, "5e4bbcb49cf3f095330495ea6d5d5223fef38a5d63473e3901fce58be03ea2a0")

