-- Lua provided by RyzenAPI
-- Game: Slender Threads

-- MAIN APPLICATION
addappid(1116480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116481, 1, "3b9fadc056e88d945abca7e5a5d637f9869c088ff42acb8ab7e9400935886fba")

