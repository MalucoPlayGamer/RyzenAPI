-- Lua provided by RyzenAPI
-- Game: addappid(1462060)

-- MAIN APPLICATION
addappid(1462060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462061, 1, "12d3d0564dcc209f2ca816295fce496fe5e7a942d773474f062473e6918f4fda")
