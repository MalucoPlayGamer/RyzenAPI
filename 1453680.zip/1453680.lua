-- Lua provided by RyzenAPI
-- Game: addappid(1453680)

-- MAIN APPLICATION
addappid(1453680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453681, 1, "5e4475fc316f7c30fa94de301fc217e8523f5ff43cc85f6766856bf9eba6f6b2")
