-- Lua provided by RyzenAPI
-- Game: Game: AppID 1834920

-- MAIN APPLICATION
addappid(1834920)
-- Game: addappid(1834920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834921, 1, "64ccd4d828a70578d678d340098169d3b47db0e915651139ab78df0f7d59db49")
