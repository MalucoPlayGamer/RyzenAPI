-- Lua provided by RyzenAPI 
-- Game: AppID 1834920
addappid(1834920)
addappid(1834921, 1, "64ccd4d828a70578d678d340098169d3b47db0e915651139ab78df0f7d59db49")
