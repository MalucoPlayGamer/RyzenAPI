-- Lua provided by RyzenAPI 
-- Game: Movavi Photo Editor 2024
addappid(2171300)
addappid(2171301, 1, "b1464eab2a369a95a9b110aa690142848830fb927e855d2ae346f30137b9f238")
