-- 4434520's Lua and Manifest Created by Hubcap Manifest
-- Office Leveling
-- Created: July 27, 2026 at 23:26:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4434520) -- Office Leveling
-- MAIN APP DEPOTS
addappid(4434521, 1, "961945adaa85b90a24b47ba72f3977019f1c9f01636fd5a68f971ee85d542f63") -- Depot 4434521
setManifestid(4434521, "3624767875850613140", 330820347)