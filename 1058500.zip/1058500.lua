-- Lua provided by RyzenAPI
-- Game: Game: Muscle Car Robot

-- MAIN APPLICATION
addappid(1058500)
-- Game: addappid(1058500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058501, 1, "8134bf9d3b9791b367e5f39728a38e299950fb108901784cf78efa737873d971")
