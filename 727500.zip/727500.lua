-- Lua provided by RyzenAPI
-- Game: 727500

-- MAIN APPLICATION
addappid(727500)
-- Game: addappid(727500)

-- MAIN APP DEPOTS / PACKAGES
addappid(727501, 1, "389793fc7a0945a4c7d50c9961316125d814c12e3e7c58a2adc326bdbd6708ea")
