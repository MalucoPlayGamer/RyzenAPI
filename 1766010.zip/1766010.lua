-- Lua provided by RyzenAPI
-- Game: 1766010

-- MAIN APPLICATION
addappid(1766010)
-- Game: addappid(1766010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766011, 1, "f6c8f85627a10e1dad7b19879686acae1d61e150d63b7a0fdc3edb26b3b93593")
