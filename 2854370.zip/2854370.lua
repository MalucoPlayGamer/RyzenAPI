-- Lua provided by RyzenAPI
-- Game: Floppa: The Dark Forest

-- MAIN APPLICATION
addappid(2854370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854371, 1, "f1c874488e808e284e429a95465cc9615094d46e86486e4bb1bcb516d299686a")
