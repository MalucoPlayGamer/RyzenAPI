-- Lua provided by RyzenAPI
-- Game: Kingdom of Wreck Business Demo

-- MAIN APPLICATION
addappid(1889340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889341, 1, "171508906a69088c0c614842d41be64f7b563cea0515a6bb7541f862ad0361c2")

