-- Lua provided by RyzenAPI 
-- Game: The Land of Dasthir
addappid(545700)
addappid(545701, 1, "1bea355b1e3e348de776b6271d654e5c511ce40d9b33edd95135521ca86cd0d2")
