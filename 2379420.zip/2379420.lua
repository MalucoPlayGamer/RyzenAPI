-- Lua provided by RyzenAPI
-- Game: Codex Lost Demo

-- MAIN APPLICATION
addappid(2379420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379421, 1, "624193ce705bcdd1d02de3e60ec2dcec20918701aa002f1bb67ae0671248c62f")

