-- Lua provided by RyzenAPI
-- Game: Sangokushi Eiketsuden

-- MAIN APPLICATION
addappid(628150)

-- MAIN APP DEPOTS / PACKAGES
addappid(628151, 1, "1fd2677f5a38dd9b6c7fc548bf08468b4afb8939cadd312ff891a418b2ae8257")
