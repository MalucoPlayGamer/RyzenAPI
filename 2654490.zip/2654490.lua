-- Lua provided by RyzenAPI
-- Game: Relic Arena

-- MAIN APPLICATION
addappid(2654490)

