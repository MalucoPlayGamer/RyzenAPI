-- Lua provided by RyzenAPI
-- Game: Crucible Falls: Together Forever

-- MAIN APPLICATION
addappid(834750)

-- MAIN APP DEPOTS / PACKAGES
addappid(834751,0,"753ff6c2f3c631a9415f413b15038f3a1d00421f50887374ed903cded55c2d7e")

