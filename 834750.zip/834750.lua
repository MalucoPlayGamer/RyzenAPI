-- Lua provided by RyzenAPI
-- Game: Crucible Falls: Together Forever

-- MAIN APPLICATION
addappid(834750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(834751,0,"753ff6c2f3c631a9415f413b15038f3a1d00421f50887374ed903cded55c2d7e")

