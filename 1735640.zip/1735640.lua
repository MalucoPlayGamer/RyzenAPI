-- Lua provided by RyzenAPI
-- Game: Farmers' Market

-- MAIN APPLICATION
addappid(1735640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735641, 1, "0c62b1e7e165ebf97467979732232585130523a3326b15a56c5b4427720bc740")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
