-- Lua provided by RyzenAPI
-- Game: Game: Farmers' Market

-- MAIN APPLICATION
addappid(1735640)
-- Game: addappid(1735640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735641, 1, "0c62b1e7e165ebf97467979732232585130523a3326b15a56c5b4427720bc740")
