-- Lua provided by RyzenAPI
-- Game: 9 Clues: The Secret of Serpent Creek

-- MAIN APPLICATION
addappid(284870)
-- Game: addappid(284870)

-- MAIN APP DEPOTS / PACKAGES
addappid(284871, 1, "1c335831e0f75eb5cf094c4dfd6b8c7a7bc746c8e71f29ff7df1dc389dc7166e")
addappid(284872, 1, "68a09b37a6cca80a384adffc253ecf8aedf3aca2ce9d4e67326ec8faeea4e1d4")
addappid(284873, 1, "46579f28d220dce3a56a8307f43b12facd41545fca5725518f2b3de4789e49d5")
