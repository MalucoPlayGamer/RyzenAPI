-- Lua provided by RyzenAPI
-- Game: Edmersiv

-- MAIN APPLICATION
addappid(542170)
-- Game: addappid(542170)

-- MAIN APP DEPOTS / PACKAGES
addappid(542171, 1, "7d3700e9c1302cda5eb70f250e576cc628b657b5cf9c4e11ddb759402e7994c4")
