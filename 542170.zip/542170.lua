-- Lua provided by SkyAPI 
-- Game: Edmersiv
addappid(542170)
addappid(542171, 1, "7d3700e9c1302cda5eb70f250e576cc628b657b5cf9c4e11ddb759402e7994c4")
