-- Lua provided by RyzenAPI
-- Game: 1455590

-- MAIN APPLICATION
addappid(1455590)
-- Game: addappid(1455590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455591, 1, "aff2e37627642108b39e812562cd843b986250f4ba628328bea1fc1fec53d3b7")
