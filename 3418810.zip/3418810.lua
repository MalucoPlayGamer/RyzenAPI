-- Lua provided by RyzenAPI
-- Game: Marmot Fight Club

-- MAIN APPLICATION
addappid(3418810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418811, 1, "7c3b55e50e00afe0476a4ae3a8119add403d1734ecde80de2ec1043292b3dc27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
