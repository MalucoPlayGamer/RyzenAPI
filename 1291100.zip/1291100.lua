-- Lua provided by RyzenAPI
-- Game: Night Spasm

-- MAIN APPLICATION
addappid(1291100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291101, 1, "3c137660d08b9a27640fb121626d8d41d8b9eebfc1109d67facb475c0c8f9a55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
