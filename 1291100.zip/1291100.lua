-- Lua provided by SkyAPI 
-- Game: Night Spasm
addappid(1291100)
addappid(1291101, 1, "3c137660d08b9a27640fb121626d8d41d8b9eebfc1109d67facb475c0c8f9a55")
