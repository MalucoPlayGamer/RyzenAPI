-- Lua provided by RyzenAPI
-- Game: Night Spasm

-- MAIN APPLICATION
addappid(1291100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291101, 1, "3c137660d08b9a27640fb121626d8d41d8b9eebfc1109d67facb475c0c8f9a55")
