-- Lua provided by RyzenAPI
-- Game: CAYNE

-- MAIN APPLICATION
addappid(532840)
addappid(533670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(532841, 1, "7a9830fbb5660ec6d333675f87a53dfb7aa78a210e11af1cc4e6c546014ec741")
addappid(532842, 1, "c26cebf71ab29b01f19a433678569f4eaeed09f3e902e310d8c9ec93d2f840f8")
addappid(532844, 1, "4a565235bd42a8f513a2c8a5b2dcc5072fbd8a98637e068175295146abb8e26d")

