-- Lua provided by RyzenAPI
-- Game: Game: AppID 532840

-- MAIN APPLICATION
addappid(532840)
-- Game: addappid(532840)

-- MAIN APP DEPOTS / PACKAGES
addappid(532841, 1, "7a9830fbb5660ec6d333675f87a53dfb7aa78a210e11af1cc4e6c546014ec741")
addappid(532842, 1, "c26cebf71ab29b01f19a433678569f4eaeed09f3e902e310d8c9ec93d2f840f8")
addappid(532844, 1, "4a565235bd42a8f513a2c8a5b2dcc5072fbd8a98637e068175295146abb8e26d")
