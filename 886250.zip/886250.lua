-- Lua provided by RyzenAPI
-- Game: AppID 886250

-- MAIN APPLICATION
addappid(886250)

-- MAIN APP DEPOTS / PACKAGES
addappid(886251, 1, "c3022b661f50ffeef0e317f2aef125b845e701668cabd21ebffb939073947e1c")

