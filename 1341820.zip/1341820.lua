-- Lua provided by RyzenAPI
-- Game: As Dusk Falls

-- MAIN APPLICATION
addappid(1341820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1341821, 1, "b4b3c75f07674df3633110d82ab2742027941b6c10b70efa8e634ca8a6a7f751")
addappid(1341822, 1, "8c2a3e11ee8642569e8dfd0606f3b3ade6edc2718566900e9503377a484612df")
addappid(1763020, 0, "9c33325578043692ecefdf9da14c0da18036afc3a8e28b467f163f3c35a1934a")

