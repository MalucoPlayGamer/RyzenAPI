-- Lua provided by RyzenAPI
-- Game: Twin Blue Moons

-- MAIN APPLICATION
addappid(800930)

-- MAIN APP DEPOTS / PACKAGES
addappid(800931,0,"1c8e15eab01260ff6b447f9d847155816e4af001ef2abc9a57117e95141f0c7c")

