-- Lua provided by RyzenAPI
-- Game: addappid(3094660)

-- MAIN APPLICATION
addappid(3094660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094661, 1, "c47665c8085701b63fa4908c6b6c63a65ed8b96b208f090ba9aa52934bc4210a")
