-- Lua provided by RyzenAPI
-- Game: Idol Party 2 - Love Vibe

-- MAIN APPLICATION
addappid(3798230)

