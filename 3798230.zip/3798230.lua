-- Lua provided by RyzenAPI
-- Game: Idol Party 2 - Love Vibe

-- MAIN APPLICATION
addappid(3798230)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
