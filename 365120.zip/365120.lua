-- Lua provided by RyzenAPI
-- Game: Curse of the Crescent Isle DX

-- MAIN APPLICATION
addappid(365120)

-- MAIN APP DEPOTS / PACKAGES
addappid(365122,0,"b9add6c0af31a40927438c78244e7f74e53718e81294d789a6c897c9e4fc226a")
addappid(365123,0,"8122ae2fa252b59c3024e2d05237918e2053e38c92e2cd467f67ff205b1960aa")
addappid(365124,0,"073f60f15479949fa36672d19f0ac7d3f62ccf376c87b11e083f321205d7b6da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
