-- Lua provided by RyzenAPI
-- Game: 正宗台灣十六張麻將

-- MAIN APPLICATION
addappid(1508650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508651, 1, "5b67c80734712a080d3847e53444a534bb599eb5664b67a3746bcd217493ceec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
