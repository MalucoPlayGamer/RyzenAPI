-- Lua provided by RyzenAPI
-- Game: Game: 正宗台灣十六張麻將

-- MAIN APPLICATION
addappid(1508650)
-- Game: addappid(1508650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508651, 1, "5b67c80734712a080d3847e53444a534bb599eb5664b67a3746bcd217493ceec")
