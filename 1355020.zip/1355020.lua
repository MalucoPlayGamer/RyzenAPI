-- Lua provided by RyzenAPI
-- Game: Game: AppID 1355020

-- MAIN APPLICATION
addappid(1355020)
-- Game: addappid(1355020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355021, 1, "27e21677d2b88915cb5fe12b7325ba1b6f022232cccdf9b3e949fad17029f415")
