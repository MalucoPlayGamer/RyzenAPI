-- Lua provided by RyzenAPI
-- Game: MILF's Plaza Demo

-- MAIN APPLICATION
addappid(2756090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756091, 1, "a3214bafafeaa7d3990b65427d0187c9f864ec00283c3fc7736f679b213564d4")
