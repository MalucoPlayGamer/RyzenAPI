-- Lua provided by RyzenAPI
-- Game: 488200

-- MAIN APPLICATION
addappid(488200)
-- Game: addappid(488200)

-- MAIN APP DEPOTS / PACKAGES
addappid(488201, 1, "6c7439d5f0c881a12c020ea34550d11d8116af7b4d2b0b430e7296a0bf5d8871")
