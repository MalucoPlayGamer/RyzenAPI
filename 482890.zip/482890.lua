-- Lua provided by RyzenAPI
-- Game: Fantasy Kingdom Simulator

-- MAIN APPLICATION
addappid(482890)
-- Game: addappid(482890)

-- MAIN APP DEPOTS / PACKAGES
addappid(482891, 1, "e4a3f99e99db05497e95c6fc945f41609ae2491402624ff239d6211f8827b8b3")
