-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Guarded, Blunt Girl GP-01

-- MAIN APPLICATION
addappid(2408830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408831, 1, "14f2647fddbcd35cd5b47139ea4f3309bdd80f61cfb9de6a206e44d9eee102a2")

