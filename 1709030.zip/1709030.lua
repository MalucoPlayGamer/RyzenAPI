-- Lua provided by RyzenAPI
-- Game: AppID 1709030

-- MAIN APPLICATION
addappid(1709030)
-- Game: addappid(1709030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709031, 1, "2ff7fc43b0549ba57828a99af0894803d8556e5a9d023d25ca0044db64ced8c6")
