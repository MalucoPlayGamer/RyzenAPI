-- Lua provided by RyzenAPI
-- Game: addappid(755250)

-- MAIN APPLICATION
addappid(755250)

-- MAIN APP DEPOTS / PACKAGES
addappid(755251, 1, "fecb534d03a066460533e6a7bc4e1f15957e801024711bf2094c7cf2bbe36ef0")
