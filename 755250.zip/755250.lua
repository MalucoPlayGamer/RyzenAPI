-- Lua provided by RyzenAPI 
-- Game: AppID 755250
addappid(755250)
addappid(755251, 1, "fecb534d03a066460533e6a7bc4e1f15957e801024711bf2094c7cf2bbe36ef0")
