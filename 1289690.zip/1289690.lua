-- Lua provided by RyzenAPI
-- Game: Midsummer Night

-- MAIN APPLICATION
addappid(1289690)
-- Game: addappid(1289690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289691, 1, "a8c5c887d16287ae21d4e5c29bafa36d4dc5ff7b081b8cfa37b3c1ef4861de91")
