-- Lua provided by SkyAPI 
-- Game: Midsummer Night
addappid(1289690)
addappid(1289691, 1, "a8c5c887d16287ae21d4e5c29bafa36d4dc5ff7b081b8cfa37b3c1ef4861de91")
