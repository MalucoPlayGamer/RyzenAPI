-- Lua provided by SkyAPI 
-- Game: Black Smith4
addappid(2582730)
addappid(2582731, 1, "77487f1c9d19a0eaaa485565e988f527de6d9772e9b4f80e5f64804ba6573a3c")
