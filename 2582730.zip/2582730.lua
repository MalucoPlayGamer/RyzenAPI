-- Lua provided by RyzenAPI
-- Game: Black Smith4

-- MAIN APPLICATION
addappid(2582730)
-- Game: addappid(2582730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582731, 1, "77487f1c9d19a0eaaa485565e988f527de6d9772e9b4f80e5f64804ba6573a3c")
