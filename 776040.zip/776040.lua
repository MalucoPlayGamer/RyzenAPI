-- Lua provided by RyzenAPI
-- Game: John Lazarus - Episode 1: Dead Man's Origin

-- MAIN APPLICATION
addappid(776040)

-- MAIN APP DEPOTS / PACKAGES
addappid(776041,0,"a1b57e4512f0dc7976945e8e8fbf0543517814b2c65fcc056a1b9d1bccec44f0")

