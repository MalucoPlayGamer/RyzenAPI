-- Lua provided by RyzenAPI
-- Game: Fish 'N' Chips

-- MAIN APPLICATION
addappid(1953000)
-- Game: addappid(1953000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953001, 1, "058f5b4037b2041e9bb5b44aa65a3413342d53cbcb43c39442d7c770d064ca76")
