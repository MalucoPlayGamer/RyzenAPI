-- Lua provided by RyzenAPI
-- Game: Game: Lila’s Sky Ark

-- MAIN APPLICATION
addappid(1573390)
-- Game: addappid(1573390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573391, 1, "aecaef4f7727a305a9ceda205a1a14071304f705506edc69f49aabe72332802e")
addappid(1573392, 1, "0c81f4494b9fdd7aad0b645453dd78dff5c61e5931c92789057eefd561a7dbae")
addappid(1573393, 1, "92ba7400d4dfc3aab8c19d702ba0997466badc2996792d810402c0862505229e")
