-- Lua provided by RyzenAPI
-- Game: 100 Days without delays

-- MAIN APPLICATION
addappid(1874920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874921, 1, "564675969882843810123d1a3e2bfcaa6c507003b44ecf317ab821cf66d79cac")

