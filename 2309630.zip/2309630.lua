-- Lua provided by RyzenAPI
-- Game: addappid(2309630)

-- MAIN APPLICATION
addappid(2309630)
addappid(2539300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309631, 1, "b9d7925df347170c85d79032e956ae35036b28837fa20f55a3e982ca9c45096e")
