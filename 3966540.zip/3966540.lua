-- 3966540's Lua and Manifest Created by Hubcap Manifest
-- Kioskeria: Summer Breeze!
-- Created: July 28, 2026 at 11:11:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3966540) -- Kioskeria: Summer Breeze!
-- MAIN APP DEPOTS
addappid(3966541, 1, "f12e34d9f386f44dee29cdb4430045e4d1f4a8c65be6dce02dfdef9081856cac") -- Depot 3966541
setManifestid(3966541, "2282454057590035646", 1585906110)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)