-- Lua provided by RyzenAPI
-- Game: addappid(3086060)

-- MAIN APPLICATION
addappid(3086060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086061, 1, "bca70a2e14a6c005cd9f488d8798f97e0e0936f239448bd04c0312de03f03ad3")
