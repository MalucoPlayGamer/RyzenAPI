-- Lua provided by RyzenAPI
-- Game: Stick to the end

-- MAIN APPLICATION
addappid(952970)

-- MAIN APP DEPOTS / PACKAGES
addappid(952971, 1, "ca7284ce1d4ebf80c785f32532f1ecd05bdbea48e6634110a34c5c1c99d7f887")

