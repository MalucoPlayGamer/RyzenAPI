-- Lua provided by RyzenAPI
-- Game: Desktop Agents - Cov1d-999

-- MAIN APPLICATION
addappid(778780)

-- MAIN APP DEPOTS / PACKAGES
addappid(778782,0,"2770f51b798b50dcb7070965a5b7206f302ed72f86fba758224a5cd0269f6c67")
