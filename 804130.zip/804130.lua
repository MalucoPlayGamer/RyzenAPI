-- Lua provided by RyzenAPI
-- Game: AppID 804130

-- MAIN APPLICATION
addappid(804130)
-- Game: addappid(804130)

-- MAIN APP DEPOTS / PACKAGES
addappid(804131, 1, "27bb4ce0d27c09c14fe4023a8a943fcea0a112e17653a70a3856f3c292b0ce98")
