-- Lua provided by RyzenAPI
-- Game: Light Fairytale Episode 1

-- MAIN APPLICATION
addappid(539330)

-- MAIN APP DEPOTS / PACKAGES
addappid(539331, 1, "f8ff045c8c43000b19a1b2aa178fb84a1fbfb4ddb0fbb155172f60014b9623cb")
