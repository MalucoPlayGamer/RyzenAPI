-- Lua provided by RyzenAPI
-- Game: Game: AppID 300910

-- MAIN APPLICATION
addappid(300910)
-- Game: addappid(300910)

-- MAIN APP DEPOTS / PACKAGES
addappid(300911, 1, "64fa0275ae866a5ca6d17aa14c60ce2259d19534e6c6dc1871cc73abb507f8e7")
