-- Lua provided by RyzenAPI
-- Game: The Occluder

-- MAIN APPLICATION
addappid(897880)
addappid(904920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(897881, 1, "fa309ba0039afb7183aa185ec30c433acd5b0b7edd94186f4c008a2915fe6e5e")

