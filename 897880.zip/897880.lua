-- Lua provided by RyzenAPI
-- Game: 897880

-- MAIN APPLICATION
addappid(897880)
addappid(904920)
-- Game: addappid(897880)

-- MAIN APP DEPOTS / PACKAGES
addappid(897881, 1, "fa309ba0039afb7183aa185ec30c433acd5b0b7edd94186f4c008a2915fe6e5e")
