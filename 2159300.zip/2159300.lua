-- Lua provided by RyzenAPI
-- Game: 2159300

-- MAIN APPLICATION
addappid(2159300)
-- Game: addappid(2159300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159301, 1, "522df9860c67a124a19b1a13135f69fb881d2f6896ed5e0fc93d40c1fed3d01a")
addappid(2159302, 1, "b50cfac786f4fb6cacbdb57c3a4536c77b493c0125b0fcec4b3198a9bb493c34")
