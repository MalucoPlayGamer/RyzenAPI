-- Lua provided by SkyAPI 
-- Game: Countrified
addappid(1187920)
addappid(1187921, 1, "acae7aef8ff4ed1367233abf3861089538d6aacb9039ee8b05dd53dc46f4d07c")
