-- Lua provided by RyzenAPI
-- Game: Game: Rogue Samurai

-- MAIN APPLICATION
addappid(2552680)
-- Game: addappid(2552680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552681, 1, "69c25513608bb8626c26067ff46d430cb65c71ba16d65c219e96c3340c78f580")
