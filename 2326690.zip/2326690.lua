-- Lua provided by RyzenAPI
-- Game: addappid(2326690)

-- MAIN APPLICATION
addappid(2326690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326691, 1, "9bf77bb778ecc7069d3223d46164832e1726a8f094c502af9a6cf228e4a33ce2")
