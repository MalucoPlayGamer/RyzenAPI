-- Lua provided by RyzenAPI
-- Game: addappid(1065300)

-- MAIN APPLICATION
addappid(1065300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065301, 1, "367c4f92c3c34f47b2e3606144c94b34759dcfd270bfc28b0edbad1a80f844bc")
