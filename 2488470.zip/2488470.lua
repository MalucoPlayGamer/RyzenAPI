-- Lua provided by RyzenAPI
-- Game: Politon

-- MAIN APPLICATION
addappid(2488470)
addappid(2488471)
addappid(2488472)
addappid(2488474)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488473,0,"693313a89a09869947761afc11c9c33069e80b4514e941c8c286461916d37f5d")
