-- Lua provided by RyzenAPI
-- Game: The Infectious Madness of Doctor Dekker

-- MAIN APPLICATION
addappid(545540)
-- Game: addappid(545540)

-- MAIN APP DEPOTS / PACKAGES
addappid(545542,0,"89ca12cff9e5d626e1e689f0fc02b9778a8b37e178fba6ca4b9166c9dc3b1f84")
addappid(545544,0,"48d4bc653255776cd900b79468bb09017950db95dbdc970a0c798d1866a2d214")
addappid(545545,0,"6c2cda9b75629504978f5bab332bb8e18c93c6f8b15e25da85ab6d3ae0fb31b7")
addappid(545548,0,"9468f096b1b960345b30f32c9117345fb0257d7a9f8aeca2ee4bc3ebae14a2d5")
