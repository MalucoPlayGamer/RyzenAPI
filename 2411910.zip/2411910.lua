-- Lua provided by RyzenAPI
-- Game: addappid(2411910)

-- MAIN APPLICATION
addappid(2411910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411911, 1, "ea3a207f668630bd56f125c6aeffa31c503531ce201f0bd27cbf99bbf77cc163")
