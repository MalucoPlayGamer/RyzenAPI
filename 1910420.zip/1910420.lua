-- Lua provided by RyzenAPI
-- Game: Game: VR HENTAI PLAY

-- MAIN APPLICATION
addappid(1910420)
-- Game: addappid(1910420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910421, 1, "aca551c1c52126084cd8d3294dbd10e0fa54f49a7672d7da68d76916ebfd6f6c")
