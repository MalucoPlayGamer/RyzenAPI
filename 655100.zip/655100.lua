-- Lua provided by RyzenAPI
-- Game: Game: Oik 3

-- MAIN APPLICATION
addappid(655100)
-- Game: addappid(655100)

-- MAIN APP DEPOTS / PACKAGES
addappid(655101, 1, "330ec9c4e77ff70929043e355a4399726374678b7d1be0c5fc96d96276d71a0c")
