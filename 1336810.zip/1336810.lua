-- Lua provided by RyzenAPI
-- Game: Necronator: Dead Wrong - Game Editor

-- MAIN APPLICATION
addappid(1336810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336811, 1, "86105d35f4771c236b2350bd80f78302bf7a64bc3d0087804c89779d9bc0aae7")
