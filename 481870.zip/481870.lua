-- Lua provided by RyzenAPI
-- Game: AppID 481870

-- MAIN APPLICATION
addappid(481870)

-- MAIN APP DEPOTS / PACKAGES
addappid(481871, 1, "113614cea802cbce9619a63f4faeb90ab2913454f2d9d0a41e29ca2d470b388d")
addappid(481872, 1, "cb0e7e18aa6c404b4eaa6425856e2c748ab1ad1898c5153d7862f6efcc2132e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
