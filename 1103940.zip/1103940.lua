-- Lua provided by RyzenAPI
-- Game: 1103940

-- MAIN APPLICATION
addappid(228984)
addappid(228985)
addappid(228986)
addappid(228987)
addappid(228990)
addappid(229004)
addappid(229005)
addappid(229006)
addappid(1103940)
-- Game: addappid(1103940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103944,0,"60e8156365901bfced4dcb84d5b592397de28780987c894c9ec9caddc46b3b4f")
