-- Lua provided by RyzenAPI
-- Game: Monaco 2

-- MAIN APPLICATION
addappid(1063030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063032,0,"5df2d796feaa00cfb20c5c4eb91d46021671863f04310a6da64c101e53eea95a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
