-- Lua provided by RyzenAPI
-- Game: Monaco 2

-- MAIN APPLICATION
addappid(1063030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063032,0,"5df2d796feaa00cfb20c5c4eb91d46021671863f04310a6da64c101e53eea95a")

