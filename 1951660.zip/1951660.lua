-- Lua provided by RyzenAPI
-- Game: We See You

-- MAIN APPLICATION
addappid(1951660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951661, 1, "214c36572ddd506f76f68c954ac4dddf5fa0ad832b19b9077e74703ddf15f1ac")
