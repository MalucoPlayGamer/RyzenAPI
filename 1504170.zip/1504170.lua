-- Lua provided by RyzenAPI
-- Game: 1504170

-- MAIN APPLICATION
addappid(1504170)
-- Game: addappid(1504170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504170,0,"357a7a77f8e61b03fce7a8f37f9611ebc07d44708cd43da6b505e03bd93aec9d")
