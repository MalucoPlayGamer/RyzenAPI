-- Lua provided by RyzenAPI
-- Game: Some Jello and a Hard Place

-- MAIN APPLICATION
addappid(3294730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294731, 1, "d8a517ab2745b73d304c3cba7683e2ecce84e462c5945d486f40ba7b42103310")

