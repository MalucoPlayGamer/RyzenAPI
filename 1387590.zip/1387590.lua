-- Lua provided by RyzenAPI
-- Game: addappid(1387590)

-- MAIN APPLICATION
addappid(1387590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387591, 1, "365184ed7dfb68b509def41a36ae793d56d4142d9c0a18e9e10874c2f7fe2e8a")
