-- Lua provided by RyzenAPI
-- Game: AppID 255340

-- MAIN APPLICATION
addappid(255340)

-- MAIN APP DEPOTS / PACKAGES
addappid(255341, 1, "c11da4c79a25b6dd281d94fc1a0491aa83a153046b8a8793274dbbe5266e6f57")
addappid(255342, 1, "577f728554ffe99b246a12c8e9b4007be8b18227537d5d8a66436a4444f8d466")
addappid(255343, 1, "dcc5b60cea985b5710fc50b8d6661e6dd14f46375b521a7926a9aba3cc50ac3f")
addappid(255344, 1, "aa74443d7b26aa816c678426334da1b9892224559d97aa22cbd037b4078da128")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
