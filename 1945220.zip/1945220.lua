-- Lua provided by RyzenAPI
-- Game: Rhythm Journey

-- MAIN APPLICATION
addappid(1945220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945221, 1, "8fb72e16d5cb61e33faa98e6ad13858be1e4323e3985c125f7565cda21ce0ac3")
addappid(1945222, 1, "38b6e94eda5e383988a158a073139323ad928051681c3535cbf9490da7ed94e1")
