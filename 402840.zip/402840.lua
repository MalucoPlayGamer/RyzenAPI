-- Lua provided by RyzenAPI
-- Game: Crusaders of the Lost Idols

-- MAIN APPLICATION
addappid(402840)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(492890)
addappid(492891)
addappid(492892)
addappid(799480)
addappid(799481)
addappid(799482)
addappid(952670)
addappid(952671)
addappid(980050)
addappid(1018440)
addappid(1082610)
addappid(1195540)
addappid(1255400)
addappid(1255401)
addappid(1335740)
addappid(1335750)
addappid(1379740)
addappid(1404230)
addappid(1404231)
addappid(1428250)
addappid(1476120)
addappid(1496700)
addappid(1496701)
addappid(1658430)
addappid(1799960)
addappid(1799961)
addappid(1812490)
