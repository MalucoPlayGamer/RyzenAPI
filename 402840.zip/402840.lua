-- Lua provided by RyzenAPI
-- Game: Crusaders of the Lost Idols

-- MAIN APPLICATION
addappid(402840)

