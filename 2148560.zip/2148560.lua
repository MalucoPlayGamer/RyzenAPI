-- Lua provided by RyzenAPI
-- Game: 传说世界

-- MAIN APPLICATION
addappid(2148560)
-- Game: addappid(2148560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148561, 1, "be79d75929df43ffb4cc2bcdb4c9d4a258f847433f7b2268e20b7db54e5ec296")
