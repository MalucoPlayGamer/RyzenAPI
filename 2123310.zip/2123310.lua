-- Lua provided by RyzenAPI 
-- Game: 洪荒：我挂机成圣
addappid(2123310)
addappid(2123311, 1, "607985dc6b56f18a20a8405cf65a5713806ded1eb65626e632f72dddb523bb79")
