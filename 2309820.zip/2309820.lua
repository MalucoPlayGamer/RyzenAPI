-- Lua provided by RyzenAPI
-- Game: Game: ConnVerse

-- MAIN APPLICATION
addappid(2309820)
-- Game: addappid(2309820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309821, 1, "a03f03f80c54a2255006e12e3671fe25da0cceb385392557c8da0c0b292eab9e")
