-- Lua provided by RyzenAPI
-- Game: Game: AppID 704580

-- MAIN APPLICATION
addappid(704580)
-- Game: addappid(704580)

-- MAIN APP DEPOTS / PACKAGES
addappid(704581, 1, "0a6bded3184fac94ccde352bdf632040f7c6a0d531fbfef83375d9bd6629fca3")
