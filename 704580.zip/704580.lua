-- Lua provided by RyzenAPI
-- Game: AppID 704580

-- MAIN APPLICATION
addappid(704580)

-- MAIN APP DEPOTS / PACKAGES
addappid(704581, 1, "0a6bded3184fac94ccde352bdf632040f7c6a0d531fbfef83375d9bd6629fca3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
