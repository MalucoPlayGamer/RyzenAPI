-- Lua provided by RyzenAPI
-- Game: Rend

-- MAIN APPLICATION
addappid(547860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(547861, 1, "c95cc478cc1d698be25c0c7d924c22440c2a8009d7b8914527bbadba8607c60a")

