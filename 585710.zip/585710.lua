-- Lua provided by RyzenAPI
-- Game: addappid(585710)

-- MAIN APPLICATION
addappid(585710)
addappid(1077610)

-- MAIN APP DEPOTS / PACKAGES
addappid(585711, 1, "aaef911b7f531c2a8ad4db5af89990a317def10b5ba14b03e618c6c62278a16d")
