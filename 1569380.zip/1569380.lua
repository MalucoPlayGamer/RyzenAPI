-- Lua provided by RyzenAPI
-- Game: Triple Dungeon

-- MAIN APPLICATION
addappid(1569380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569381, 1, "cc3f8d93bcb6bbdd6bae1143414406602228910010e215b0b9139888215ad306")
