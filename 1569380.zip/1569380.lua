-- Lua provided by SkyAPI 
-- Game: Triple Dungeon
addappid(1569380)
addappid(1569381, 1, "cc3f8d93bcb6bbdd6bae1143414406602228910010e215b0b9139888215ad306")
