-- Lua provided by RyzenAPI
-- Game: ヒラヒラヒヒル Demo

-- MAIN APPLICATION
addappid(2389200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389201, 1, "dafb92777aa7747d405e13fd1d2b7fe49001eb11a6a915a9282516eabdc377ae")

