-- Lua provided by RyzenAPI
-- Game: Wall World

-- MAIN APPLICATION
addappid(2187290)
addappid(2474860)
-- Game: addappid(2187290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187291, 1, "cb01cb5f16254236ce96818ecc2102c55ceb5aa5a6163fb45bd3a6687308bd78")
addappid(2474861, 0, "894ebeb3858c0eed31b480870954e01826daaef5e6df90a1aaf3dbe1393633cf")
