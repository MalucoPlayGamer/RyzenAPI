-- Lua provided by RyzenAPI
-- Game: SCP: The Foundation

-- MAIN APPLICATION
addappid(1353100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353101, 1, "a9564f8361f1f94a223d3c75e268418652e5c3c65ce0cdcf37c4a9398a9a28b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
