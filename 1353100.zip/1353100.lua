-- Lua provided by RyzenAPI
-- Game: 1353100

-- MAIN APPLICATION
addappid(1353100)
-- Game: addappid(1353100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353101, 1, "a9564f8361f1f94a223d3c75e268418652e5c3c65ce0cdcf37c4a9398a9a28b8")
