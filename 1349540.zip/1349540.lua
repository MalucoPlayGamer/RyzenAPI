-- Lua provided by RyzenAPI
-- Game: DPS IDLE

-- MAIN APPLICATION
addappid(1349540)

