-- Lua provided by RyzenAPI
-- Game: DPS IDLE

-- MAIN APPLICATION
addappid(1349540)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1450710)
addappid(1453360)
addappid(1453370)
addappid(1453380)
