-- Lua provided by SkyAPI 
-- Game: Yafti
addappid(821410)
addappid(821411, 1, "1de3f1ff0c8ce478c791c275697188930096e5413151dd6be7201e113c1e5351")
