-- Lua provided by RyzenAPI
-- Game: Game: Yafti

-- MAIN APPLICATION
addappid(821410)
-- Game: addappid(821410)

-- MAIN APP DEPOTS / PACKAGES
addappid(821411, 1, "1de3f1ff0c8ce478c791c275697188930096e5413151dd6be7201e113c1e5351")
