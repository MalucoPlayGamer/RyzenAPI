-- Lua provided by RyzenAPI
-- Game: Gumballs & Dungeons

-- MAIN APPLICATION
addappid(3112010)

