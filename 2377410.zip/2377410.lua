-- Lua provided by RyzenAPI
-- Game: 2377410

-- MAIN APPLICATION
addappid(2377410)
-- Game: addappid(2377410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377411, 1, "8ad91ae91499039eb6ba064d481832d2bdd36b55a0007bc2dafc52600b335d0a")
addappid(2377412, 1, "73fa5e414cfe1b728f749b3226494667acd9ab8952f8241738997f9ff72caf30")
addappid(2377413, 1, "df9979a4e7f4358fb5beefff3fcd2a13ac6de9829eeff56aae74c9ab6274196f")
