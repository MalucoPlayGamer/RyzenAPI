-- Lua provided by SkyAPI 
-- Game: Axis Football 2023
addappid(2103640)
addappid(2103641, 1, "7382d5908399aa0627b622494e307a7be8dfeeb8c121a717b3c385ef0c672964")
