-- Lua provided by RyzenAPI
-- Game: Touhou Danmaku Kagura Phantasia Lost

-- MAIN APPLICATION
addappid(2190220)
addappid(2790910)
addappid(2790940)
addappid(2790950)
addappid(2790960)
addappid(2790970)
addappid(2808300)
addappid(2920470)
addappid(3340370)
addappid(3340380)
addappid(3340390)
addappid(3340400)
addappid(3728710)
addappid(3728730)
addappid(3728740)
addappid(3728750)
addappid(4270280)
addappid(4270290)
addappid(4270300)
addappid(4270350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190221,0,"d94856de16f133e42d1d1c4c4c4bd5fb5c79ab25709f242ad77cd1cd5b69ba96")
addappid(2791100,0,"2a3437e1e75880812d6836420d39450fa6a965142dfbf0fe5b1ec7936b5e0f70")

