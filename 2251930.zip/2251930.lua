-- Lua provided by RyzenAPI
-- Game: CGI™: The Game

-- MAIN APPLICATION
addappid(2251930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251931, 1, "1c1bb0e0be086ae80a4801cbda91d089fc5e168aad66407c849cb9459169578f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
