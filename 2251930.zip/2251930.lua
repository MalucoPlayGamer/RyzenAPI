-- Lua provided by RyzenAPI
-- Game: Game: CGI™: The Game

-- MAIN APPLICATION
addappid(2251930)
-- Game: addappid(2251930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251931, 1, "1c1bb0e0be086ae80a4801cbda91d089fc5e168aad66407c849cb9459169578f")
