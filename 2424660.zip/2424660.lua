-- Lua provided by RyzenAPI
-- Game: Game Of Evolution - Season 1

-- MAIN APPLICATION
addappid(2424660)
-- Game: addappid(2424660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424661, 1, "386554c31a0622543a8fcde1de35281f0b9875170bde5189a93b484146e23ed4")
