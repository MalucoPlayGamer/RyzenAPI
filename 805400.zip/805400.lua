-- Lua provided by RyzenAPI
-- Game: Game: AppID 805400

-- MAIN APPLICATION
addappid(805400)
-- Game: addappid(805400)

-- MAIN APP DEPOTS / PACKAGES
addappid(805401, 1, "cd40ce0398e05d1471a58ac1711567580a4338be35792c6c411c1bd7d4258861")
