-- Lua provided by RyzenAPI
-- Game: 天羽Online

-- MAIN APPLICATION
addappid(2321290)
-- Game: addappid(2321290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321291, 1, "45a6651ba786fb2b03569c81afacb835be4533aa047e0a4a341f3356d56dcd0b")
