-- Lua provided by RyzenAPI
-- Game: SEASON: A letter to the future Demo

-- MAIN APPLICATION
addappid(2140140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140141, 1, "0834cc2f97ac7e8948e0cc45cedc28013dad3519d65363e61d2e33b8a2564a1f")

