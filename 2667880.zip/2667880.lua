-- Lua provided by RyzenAPI
-- Game: Game: Anominal

-- MAIN APPLICATION
addappid(2667880)
-- Game: addappid(2667880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667881, 1, "780c82afb453d2b3849109203a7c5bd5c3dcf351722e4d9ecc8fb92cbbda8c54")
