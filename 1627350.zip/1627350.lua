-- Lua provided by RyzenAPI
-- Game: 1627350

-- MAIN APPLICATION
addappid(1627350)
-- Game: addappid(1627350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627351, 1, "8bc236396b13778fd3a38c39cbaa20ae26e3bb34338b08e7660da2e22dc77fba")
