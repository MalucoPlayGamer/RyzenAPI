-- Lua provided by RyzenAPI
-- Game: Mexican Ninja

-- MAIN APPLICATION
addappid(3764970) -- Mexican Ninja

-- MAIN APP DEPOTS / PACKAGES
addappid(3764971, 1, "a41de601b77b2ac6a18696a538403751f5bca4024445c80126b0a65917a5f2d7") -- Depot 3764971

