-- 3764970's Lua and Manifest Created by Hubcap Manifest
-- Mexican Ninja
-- Created: August 20, 2026 at 21:38:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3764970) -- Mexican Ninja
-- MAIN APP DEPOTS
addappid(3764971, 1, "a41de601b77b2ac6a18696a538403751f5bca4024445c80126b0a65917a5f2d7") -- Depot 3764971
setManifestid(3764971, "7145149198902876963", 5863985156)