-- Lua provided by RyzenAPI
-- Game: Jump Like A Pirate

-- MAIN APPLICATION
addappid(581010)

-- MAIN APP DEPOTS / PACKAGES
addappid(581011, 1, "50f7ea16ee2a82b5919852280d5f7a9c7938c547887e10d74bf5b0ebda012a7b")
