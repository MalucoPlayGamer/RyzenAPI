-- Lua provided by RyzenAPI 
-- Game: AppID 581010
addappid(581010)
addappid(581011, 1, "50f7ea16ee2a82b5919852280d5f7a9c7938c547887e10d74bf5b0ebda012a7b")
