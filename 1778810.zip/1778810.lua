-- Lua provided by RyzenAPI
-- Game: Game: Erotic fiction for Clip maker

-- MAIN APPLICATION
addappid(1778810)
-- Game: addappid(1778810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778811, 1, "d5c9b5302d52122beea4301f243ed99cc62b32b3ec10aea8f9f8b64cf63fec2e")
