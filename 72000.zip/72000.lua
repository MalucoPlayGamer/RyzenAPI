-- Lua provided by RyzenAPI
-- Game: Closure

-- MAIN APPLICATION
addappid(72000)

-- MAIN APP DEPOTS / PACKAGES
addappid(72001, 1, "0c5cd6a7170cf2926d299c6ab50f7c783dc452330b762314af63b1d32a36eb39")
addappid(72002, 1, "bf5e3a7f4ba4cebc8b84c9dc645eca89dbcd3d19d2d23f4b0b28f397190e932c")
addappid(72003, 1, "3baaa3ef8809f3a88de0ab74c6df7b3cfba0df90b479d8c967a85bcecad1a997")

