-- Lua provided by RyzenAPI
-- Game: 899864

-- MAIN APPLICATION
addappid(899864)
-- Game: addappid(899864)

-- MAIN APP DEPOTS / PACKAGES
addappid(899864,0,"7e82b9221e4c8141c8968a443c4b524b9e6925602acb80c40d51c4df539b78f2")
