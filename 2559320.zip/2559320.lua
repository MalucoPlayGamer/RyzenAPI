-- Lua provided by RyzenAPI
-- Game: 沈める楽園 （体験版）

-- MAIN APPLICATION
addappid(2559320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559321, 1, "2f5d9ba86854899a0487af3cfde58fa772087fc01fd58c60c7f8ba247c244c10")

