-- Lua provided by RyzenAPI
-- Game: Carry The Glass

-- MAIN APPLICATION
addappid(3263320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263321, 1, "c37aea5aa76e0d105869e5a7b3134002ffb8d512a43b5c5abbd2f4007f11a627")
