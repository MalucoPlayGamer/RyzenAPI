-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1818300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818300,0,"5ce43f5f200bb97ebf8c805eb72cf2335a1a263dc65d4260e97e5d67ee6cc625")

