-- Lua provided by RyzenAPI
-- Game: AppID 288880

-- MAIN APPLICATION
addappid(288880)
-- Game: addappid(288880)

-- MAIN APP DEPOTS / PACKAGES
addappid(288881, 1, "8faf4642f8f9c9b10051894985c1e32bf055b424b2f136108dd4fb895321b601")
