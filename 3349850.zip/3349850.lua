-- Lua provided by RyzenAPI
-- Game: Game: Balantica

-- MAIN APPLICATION
addappid(3349850)
-- Game: addappid(3349850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349851, 1, "3f636b524c29a8cc6b040b89cc7d73c562ca03b3d3f53ed4ee0f230e0eaed2a1")
