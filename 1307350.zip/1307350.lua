-- Lua provided by SkyAPI 
-- Game: Cyber Manhunt Demo
addappid(1307350)
addappid(1307351, 1, "8088c17ee10172e264bbbb9f8024a11a34eeac8af4cd18a09c8811c9bf52cd53")
