-- Lua provided by RyzenAPI
-- Game: Cyber Manhunt Demo

-- MAIN APPLICATION
addappid(1307350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307351, 1, "8088c17ee10172e264bbbb9f8024a11a34eeac8af4cd18a09c8811c9bf52cd53")
