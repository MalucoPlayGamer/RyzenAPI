-- Lua provided by SkyAPI 
-- Game: Room of Depression Demo
addappid(2077760)
addappid(2077761, 1, "716d56e602826930047d65e4fe110b1f96b2f02713a290565ec916f4cb6b8213")
