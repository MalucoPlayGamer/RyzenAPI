-- Lua provided by RyzenAPI
-- Game: Game: AppID 38720

-- MAIN APPLICATION
addappid(38720)
addappid(98012)
addappid(228983)
addappid(228990)
-- Game: addappid(38720)

-- MAIN APP DEPOTS / PACKAGES
addappid(38721, 1, "4e9b49cb756500c94c30f84f5a3479e817b2082b94e7e64bb980fbcc9486a61b")
addappid(38722, 1, "f3848497f29848c9cd12a87e1faf41a21be678b35bcdd3f978357cad2a33bfd6")
addappid(38723, 1, "e0717633dbf6bd0cd4e630b912a96bcd42bd63245f5803789dabb4fb4409a756")
