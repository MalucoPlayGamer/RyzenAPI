-- Lua provided by RyzenAPI
-- Game: Game: Romans From Mars 360

-- MAIN APPLICATION
addappid(719240)
-- Game: addappid(719240)

-- MAIN APP DEPOTS / PACKAGES
addappid(719241, 1, "1d0f2c1793a5dd6cbceb99b42d044fa41eaebd9906ced9f2cf6bb274f085652c")
