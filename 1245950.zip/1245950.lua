-- Lua provided by RyzenAPI 
-- Game: Ironlights
addappid(1245950)
addappid(1245951, 1, "c09971cd7c93045f1355f6e30da159eb19e9a6a73eaba19b01b6e2369afbb3da")
addappid(1345060)
