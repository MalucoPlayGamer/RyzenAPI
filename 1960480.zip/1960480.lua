-- Lua provided by RyzenAPI
-- Game: AutoForge

-- MAIN APPLICATION
addappid(1960480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960481, 1, "fba4022ec4ba2b9af78632e666ae63546a77ae68cfb193867f5f354cedb33814")
