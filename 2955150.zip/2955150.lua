-- Lua provided by RyzenAPI
-- Game: Game: Deals With Witch

-- MAIN APPLICATION
addappid(2955150)
-- Game: addappid(2955150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955151, 1, "a26f28a51a09bb586ef567d857cecdeb861d8b3f61af76ac81b73985b167384b")
