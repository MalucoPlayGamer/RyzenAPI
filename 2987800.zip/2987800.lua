-- Lua provided by RyzenAPI
-- Game: Madoka Magica Magia Exedra

-- MAIN APPLICATION
addappid(2987800)

