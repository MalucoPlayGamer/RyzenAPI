-- Lua provided by RyzenAPI
-- Game: 933552

-- MAIN APPLICATION
addappid(933552)

-- MAIN APP DEPOTS / PACKAGES
addappid(933552,0,"b74c0eb934efde91a7319bd8fa6e037da521b09b61853da1e2fc7b12220a3c91")
