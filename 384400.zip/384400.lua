-- Lua provided by RyzenAPI
-- Game: Game: AppID 384400

-- MAIN APPLICATION
addappid(384400)
-- Game: addappid(384400)

-- MAIN APP DEPOTS / PACKAGES
addappid(384401, 1, "016ebad50de0121d845320e76673fb2af781e31ac26110dc57a77a90095815ec")
