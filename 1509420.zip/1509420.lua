-- Lua provided by RyzenAPI
-- Game: addappid(1509420)

-- MAIN APPLICATION
addappid(1509420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509421, 1, "75dca0a3ada35951436aa9d9d9e9f4e80c82edfa7305ee6f4069599d5b2e6317")
