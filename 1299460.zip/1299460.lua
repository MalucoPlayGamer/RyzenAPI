-- Lua provided by RyzenAPI
-- Game: Wanderstop

-- MAIN APPLICATION
addappid(1299460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299461, 1, "d17456022f048ed4e2819c267b7442a6fc81b5a8b031710e23d704f284d251b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
