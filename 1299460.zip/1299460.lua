-- Lua provided by RyzenAPI
-- Game: Wanderstop

-- MAIN APPLICATION
addappid(1299460)
-- Game: addappid(1299460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299461, 1, "d17456022f048ed4e2819c267b7442a6fc81b5a8b031710e23d704f284d251b3")
