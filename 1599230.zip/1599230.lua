-- Lua provided by RyzenAPI
-- Game: Puppy Adventure

-- MAIN APPLICATION
addappid(1599230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599231, 1, "f7b98dbb478219af1f7586077b096d79be24683594d9a021cae5a1cdfa3bf8b7")

