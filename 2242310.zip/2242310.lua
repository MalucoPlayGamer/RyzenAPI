-- Lua provided by RyzenAPI
-- Game: Folcroft Monastery

-- MAIN APPLICATION
addappid(2242310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242311, 1, "ecece70bf8a9b5a13be93e9097215f99f37e981281862f7d9018471c63522d17")
