-- Lua provided by RyzenAPI
-- Game: Folcroft Monastery

-- MAIN APPLICATION
addappid(2242310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2242311, 1, "ecece70bf8a9b5a13be93e9097215f99f37e981281862f7d9018471c63522d17")

