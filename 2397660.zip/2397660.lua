-- Lua provided by RyzenAPI
-- Game: Sucker for Love: Date to Die For Demo

-- MAIN APPLICATION
addappid(2397660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397661, 1, "2a55b70f9284335c5aa44a77f5db999da97b3f119b475541f07b32dcc66aa33e")
