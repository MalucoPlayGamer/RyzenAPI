-- Lua provided by RyzenAPI
-- Game: Pro Pinball Ultra

-- MAIN APPLICATION
addappid(287900)

-- MAIN APP DEPOTS / PACKAGES
addappid(287901, 1, "62ff6fe39eea5212594897fee45a4d3082d3e1a28c6749a711d6839c5e076970")
addappid(287902, 1, "61d7afc0a497a85b6b5dfa5ebf0e98746439b900b0a1fb7b62310dd2ed93731c")
addappid(287903, 1, "7fd0906bd8d7978e4b069a9cdaee7d1287040ea8126338ded1f03b5fed83a151")
addappid(287904, 1, "ca61bf69e060c63dba2fd076fec1b8e2ce38e1e110c60edd63b3c4495a8cfef0")
addappid(287905, 1, "48793d0e5f0c919242aa699b0f638786d813abce3c24049d16c2de349a719f67")
addappid(287906, 1, "bff9945b716f847a44c27347a41b925db578a6b931743aa7733f89f8744ae6c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
