-- Lua provided by RyzenAPI
-- Game: Game: Random Legion

-- MAIN APPLICATION
addappid(2749350)
-- Game: addappid(2749350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749351, 1, "8b17daff3479ef0ef9208fa59f1c58c3063b52c55e96ab7a94ae9a6c0a9801f4")
