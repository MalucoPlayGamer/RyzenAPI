-- Lua provided by RyzenAPI
-- Game: addappid(2602280)

-- MAIN APPLICATION
addappid(2602280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602281, 1, "e40cad034fdf600c292aaf60e58a1ab316a64a2089a17a452912ec2fe310ad4b")
