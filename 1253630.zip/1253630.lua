-- Lua provided by RyzenAPI
-- Game: addappid(1253630)

-- MAIN APPLICATION
addappid(1253630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253631, 1, "568e86d573f11d4c9ef2e3f6340f4b19fee0102ad7f8335d82a8a739afe699eb")
