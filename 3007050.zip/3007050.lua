-- Lua provided by RyzenAPI
-- Game: addappid(3007050)

-- MAIN APPLICATION
addappid(3007050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007052,0,"9e72f372a2a459c92de97dd5b39c6f8aa21898aad759ecf6f26b146b7eff9cfa")
