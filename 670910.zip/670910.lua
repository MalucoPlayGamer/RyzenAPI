-- Lua provided by RyzenAPI
-- Game: Game: AHTS Ship Simulator

-- MAIN APPLICATION
addappid(670910)
-- Game: addappid(670910)

-- MAIN APP DEPOTS / PACKAGES
addappid(670911, 1, "e2649473c503ca109cca8016522916f90671856cffd27c6ce8e5ee24b8e79be4")
