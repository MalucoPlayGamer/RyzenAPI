-- Lua provided by SkyAPI 
-- Game: Kill Fun Yeah
addappid(301360)
addappid(301361, 1, "523db503bef71240e92b37fe418c7f2b32ef9021f52474d66127f8d63d4731ce")
addappid(301362, 1, "54bac01f86a11cc9b8688c61da11fd9cfe330d0952c0d99c6f10ed6d0183f833")
addappid(301363, 1, "87ee8f213b20d93b6bb9615e9721c1aadc2f93bb53a3a0681183212f12b3ec2b")
