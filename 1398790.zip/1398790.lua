-- Lua provided by RyzenAPI
-- Game: Game: Boobs VR

-- MAIN APPLICATION
addappid(1398790)
-- Game: addappid(1398790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398791, 1, "703655c758da83d2561201c0778ca9ab31f155d8d596260604eee3a96099f2f1")
