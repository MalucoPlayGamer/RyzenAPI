-- Lua provided by RyzenAPI
-- Game: Spelljammer: Pirates of Realmspace

-- MAIN APPLICATION
addappid(2350550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2350551, 1, "077b18c8770a88b384ce52c2c8acb357de0a37be46ac066066ad328381bb6b77")
addappid(2350552, 1, "de2ed7ab8ff50f94044a99649dd22625fcd4591118bbb5a7b688d37e31b62784")

