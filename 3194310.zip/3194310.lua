-- Lua provided by RyzenAPI
-- Game: Pixel Dungeon VR: Prologue

-- MAIN APPLICATION
addappid(3194310)

