-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933493)

-- MAIN APP DEPOTS / PACKAGES
addappid(933493,0,"a4eb8ebdeb7fd3f33fbd229f9da8230a6be4cd7561a65e271106c9ef71deea95")
addtoken(933493,13896167761093581552)

