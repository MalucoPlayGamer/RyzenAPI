-- Lua provided by RyzenAPI
-- Game: Discolored 2 Soundtrack

-- MAIN APPLICATION
addappid(3416170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416171, 1, "146e1bc9b23ec1727a76cdc0060434b1dcbc742b54e453b475844972846ff79e")

