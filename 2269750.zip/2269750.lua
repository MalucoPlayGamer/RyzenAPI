-- Lua provided by RyzenAPI
-- Game: 메스가키 영애님!

-- MAIN APPLICATION
addappid(2269750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269751, 1, "179a8463e0c6a6fa02067f4e8e5b1efbd651b4c0a3044b3010ed19759e418b95")
addappid(2277200, 0, "d13763c4a11099d2de0bcc7a3a18c9341fdbdbb3d48871b50c0447bb0e0004fd")

