-- Lua provided by RyzenAPI
-- Game: MEGA MAN X DiVE Offline

-- MAIN APPLICATION
addappid(2183650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2183651, 1, "b65ef186c0a946139f12cda82197079ecef408e6b7eecf14b5ebf6f33faf0c81")

