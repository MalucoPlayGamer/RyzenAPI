-- Lua provided by RyzenAPI
-- Game: MEGA MAN X DiVE Offline

-- MAIN APPLICATION
addappid(2183650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183651, 1, "b65ef186c0a946139f12cda82197079ecef408e6b7eecf14b5ebf6f33faf0c81")

