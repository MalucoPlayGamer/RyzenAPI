-- Lua provided by RyzenAPI
-- Game: Mortal Online

-- MAIN APPLICATION
addappid(287920)

-- MAIN APP DEPOTS / PACKAGES
addappid(287921, 1, "f6007d05cfafe9a04b03fd88b176dd69a863aee7bce5e2a76adf921e67938882")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
