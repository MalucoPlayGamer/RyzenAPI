-- Lua provided by RyzenAPI
-- Game: Mortal Online

-- MAIN APPLICATION
addappid(287920)
-- Game: addappid(287920)

-- MAIN APP DEPOTS / PACKAGES
addappid(287921, 1, "f6007d05cfafe9a04b03fd88b176dd69a863aee7bce5e2a76adf921e67938882")
