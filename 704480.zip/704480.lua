-- Lua provided by RyzenAPI
-- Game: 704480

-- MAIN APPLICATION
addappid(704480)
-- Game: addappid(704480)

-- MAIN APP DEPOTS / PACKAGES
addappid(704481, 1, "0d069a08fb2d337a7495dbaccee8a52c9336f54e159d810c8a2bc525bafdc80b")
