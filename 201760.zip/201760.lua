-- Lua provided by RyzenAPI
-- Game: 201760

-- MAIN APPLICATION
addappid(201760)
addappid(201761)
addappid(201762)
addappid(201763)
addappid(201764)
addappid(201765)
addappid(201766)
addappid(201767)

-- MAIN APP DEPOTS / PACKAGES
addappid(231141,0,"815a9b328b48efbc031cdd6d88c29717db907810096f3715ed38bf44e62f3424")
