-- Lua provided by RyzenAPI
-- Game: addappid(2439620)

-- MAIN APPLICATION
addappid(2439620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439622,0,"dc2f35b10983ae9072dc7115306cd7de71dec9f73e5f458cfc10461cc522f7e5")
addappid(2439624,0,"6d0748f47a0abc20ea93720edfdf108bfe73580b6bca550d11b8bb069a4eaeed")
