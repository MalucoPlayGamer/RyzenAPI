-- Lua provided by RyzenAPI
-- Game: Dreadline: Net Quota

-- MAIN APPLICATION
addappid(3576880)
addappid(4487910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3576881, 1, "305a917fb951148e78dda70afd6cc512e4515b8cc9702304f2eeef6e3f44a2b5")

