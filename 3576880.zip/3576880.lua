-- Lua provided by RyzenAPI
-- Game: Game: Dreadline: Net Quota

-- MAIN APPLICATION
addappid(3576880)
addappid(4487910)
-- Game: addappid(3576880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3576881, 1, "305a917fb951148e78dda70afd6cc512e4515b8cc9702304f2eeef6e3f44a2b5")
