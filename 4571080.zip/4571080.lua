-- Lua provided by RyzenAPI
-- Game: Bloody Grids

-- MAIN APPLICATION
addappid(4571080) -- Bloody Grids

-- MAIN APP DEPOTS / PACKAGES
addappid(4571081, 1, "80f9993251090d539410fbd22a4841faab1b79f5ee28c63b6927c1e5063fb8d9") -- Depot 4571081

