-- 4571080's Lua and Manifest Created by Hubcap Manifest
-- Bloody Grids
-- Created: August 23, 2026 at 12:25:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4571080) -- Bloody Grids
-- MAIN APP DEPOTS
addappid(4571081, 1, "80f9993251090d539410fbd22a4841faab1b79f5ee28c63b6927c1e5063fb8d9") -- Depot 4571081
setManifestid(4571081, "95987576142697037", 247198707)