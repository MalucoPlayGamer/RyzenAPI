-- Lua provided by RyzenAPI
-- Game: Hellfire 1988: An Oregon Story

-- MAIN APPLICATION
addappid(1865050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865051, 1, "ae3cc8ef235dc721d622480c5a94014791c9eb355cc7873c3fa93b7e4ef1a7b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
