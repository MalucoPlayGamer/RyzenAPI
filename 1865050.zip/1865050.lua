-- Lua provided by RyzenAPI
-- Game: Hellfire 1988: An Oregon Story

-- MAIN APPLICATION
addappid(1865050)
-- Game: addappid(1865050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865051, 1, "ae3cc8ef235dc721d622480c5a94014791c9eb355cc7873c3fa93b7e4ef1a7b2")
