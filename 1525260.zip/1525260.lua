-- Lua provided by RyzenAPI
-- Game: Hellpoint: Blue Sun

-- MAIN APPLICATION
addappid(1525260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525261, 1, "35f8bf7afa009a36efcc572286888c12ecf1837f20c0333b63c366bfbd4046eb")
addappid(1525262, 1, "fb493245c527124f6a4cf6c3879a6df6c8475e53c02cee15d0d109b854227b6f")
addappid(1525263, 1, "f35fb636ffcb4f27d9d6005b6e15efdae2c38465caa2adefcbf8136bdbda237e")

