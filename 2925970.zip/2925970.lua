-- Lua provided by RyzenAPI
-- Game: The Unholy Priest

-- MAIN APPLICATION
addappid(2925970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925971, 1, "2516af666d3a9476d2bd66de2549e8549633b1051f2c6bac4dca318725e1b622")

