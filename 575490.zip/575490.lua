-- Lua provided by RyzenAPI
-- Game: Let's Draw

-- MAIN APPLICATION
addappid(575490)

-- MAIN APP DEPOTS / PACKAGES
addappid(575491, 1, "4774e3456511aba67414c81cc963f9602b05bead0b0bd5d71aa01f920d8a8f18")

