-- Lua provided by RyzenAPI
-- Game: Machine With a Big Gun

-- MAIN APPLICATION
addappid(884190)

-- MAIN APP DEPOTS / PACKAGES
addappid(884191, 1, "16f0d43e0523cf7c88af6d533d839d1204cac387f96553ef2ba1c859a7c681e6")

