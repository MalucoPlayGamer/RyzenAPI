-- Lua provided by RyzenAPI
-- Game: Zorro The Chronicles

-- MAIN APPLICATION
addappid(1571460)
-- Game: addappid(1571460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571461, 1, "c707d7d2d6b914d6e7fb5cf5d76aa05da4815508e0938041ff64d9f8ece076d8")
