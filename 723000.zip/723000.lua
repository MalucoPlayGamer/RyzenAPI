-- Lua provided by RyzenAPI
-- Game: 723000

-- MAIN APPLICATION
addappid(723000)
-- Game: addappid(723000)

-- MAIN APP DEPOTS / PACKAGES
addappid(723000,0,"b6df43b7bdb7cac8b887cb8a2fcb1a1e69aeb301360b4b997146d0e9074281fe")
