-- Lua provided by RyzenAPI
-- Game: FaceFun

-- MAIN APPLICATION
addappid(939920)

-- MAIN APP DEPOTS / PACKAGES
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(939921, 1, "93def4aaef10cb07a46a62c2bde8ea97598e06288d1230c91ccfbf9164904308")
