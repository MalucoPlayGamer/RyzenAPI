-- Lua provided by RyzenAPI
-- Game: 939920

-- MAIN APPLICATION
addappid(939920)
-- Game: addappid(939920)

-- MAIN APP DEPOTS / PACKAGES
addappid(939921, 1, "93def4aaef10cb07a46a62c2bde8ea97598e06288d1230c91ccfbf9164904308")
