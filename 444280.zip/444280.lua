-- Lua provided by RyzenAPI
-- Game: Game: AppID 444280

-- MAIN APPLICATION
addappid(444280)
-- Game: addappid(444280)

-- MAIN APP DEPOTS / PACKAGES
addappid(444281, 1, "9ef978025d1cdae39d827de1430fab2f63b553af7e2e3bd256e92d7bdb343b0c")
addappid(444282, 1, "240aa7574d4adf85b6567cf928a35e21146fe384a2272aa520ad2d4fa77a185e")
addappid(444283, 1, "a853ef7cd7846aa71c301bbb7b2c7fe809fc1a92fbf78810ecf45394354d00b3")
