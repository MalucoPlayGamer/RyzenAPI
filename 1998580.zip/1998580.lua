-- Lua provided by RyzenAPI
-- Game: 1998580

-- MAIN APPLICATION
addappid(1998580)
-- Game: addappid(1998580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998581, 1, "b7da5c15664c82b2d52d24e4accdcfa855caf294db355d1d950d7faddd149cad")
