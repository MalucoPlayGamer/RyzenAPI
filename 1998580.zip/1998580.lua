-- Lua provided by RyzenAPI
-- Game: Breath of Ghosts 2

-- MAIN APPLICATION
addappid(1998580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998581, 1, "b7da5c15664c82b2d52d24e4accdcfa855caf294db355d1d950d7faddd149cad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
