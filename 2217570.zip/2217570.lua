-- Lua provided by RyzenAPI
-- Game: CYGNI: All Guns Blazing Soundtrack

-- MAIN APPLICATION
addappid(2217570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217572,0,"5538a46a7e20391116a307aa13b7bbedef41e750ee8ff0da4b18191459f79b27")
addappid(2217573,0,"4fd5624f70bba337e25d6e848e97abe6cb8a785404b790c4095756dbb80f8f22")
