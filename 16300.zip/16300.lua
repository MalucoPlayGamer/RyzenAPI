-- Lua provided by RyzenAPI
-- Game: 16300

-- MAIN APPLICATION
addappid(16300)
-- Game: addappid(16300)

-- MAIN APP DEPOTS / PACKAGES
addappid(16301, 1, "2d449301f83a0030eb8c56a9d7dc61234e5bcd98b6f643578683cc937b93ee22")
