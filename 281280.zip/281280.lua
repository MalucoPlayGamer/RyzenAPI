-- Lua provided by RyzenAPI
-- Game: Game: Mashed

-- MAIN APPLICATION
addappid(281280)
-- Game: addappid(281280)

-- MAIN APP DEPOTS / PACKAGES
addappid(281281, 1, "c735c3da01167faf6eacef2630e874c36f95bda2766d5e29b94de6828f0a31c1")
