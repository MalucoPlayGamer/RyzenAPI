-- Lua provided by RyzenAPI
-- Game: 572480

-- MAIN APPLICATION
addappid(572480)
addappid(572481)
addappid(572483)
addappid(572484)
addappid(572485)
addappid(572486)

-- MAIN APP DEPOTS / PACKAGES
addappid(572482,0,"d89f0ea8125c12c3d063209951c874e1d614ceefa5426b503b41c6ff77c528fd")
