-- Lua provided by RyzenAPI
-- Game: Game: Paintings Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1543620)
-- Game: addappid(1543620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543621, 1, "465d521af5dae6784b2add7f4d46e2062457b68cdbbd1b71091eae0d339a00e2")
