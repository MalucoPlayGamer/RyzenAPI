-- Lua provided by RyzenAPI
-- Game: Tour de France 2023

-- MAIN APPLICATION
addappid(2062690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062691, 1, "fd2133f8a536b37dd1cd13a68f9ece86f31f5c9ee4fa480af5d84ffb37e1007b")
