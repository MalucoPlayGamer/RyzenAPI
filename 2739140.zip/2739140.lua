-- Lua provided by RyzenAPI
-- Game: Knights of the Rogue Dungeon

-- MAIN APPLICATION
addappid(2739140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739141,0,"2b64aa97496e00997d32643ef6cd05d9c6ace3f99cc48bc1d5ac48057b046f3f")

