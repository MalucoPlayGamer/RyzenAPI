-- Lua provided by SkyAPI 
-- Game: Cyberstray 101
addappid(3223590)
addappid(3223591, 1, "3de92198893e9b369749ba03abb310262e8e2c51f7e154db630825112804f3d1")
