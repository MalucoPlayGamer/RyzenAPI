-- Lua provided by RyzenAPI
-- Game: Hatsune Miku VR

-- MAIN APPLICATION
addappid(707300)

-- MAIN APP DEPOTS / PACKAGES
addappid(707301, 1, "904f3ddf557a4dddbe07c8c5c03ed19700dde27fc4c25aa47c98f97865321c1d")
addappid(929480, 0, "c5f5987fae7fe4dab1b0109cd7215149e9aabd4d92ac2df386c4721a719f7ca3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1069990)
addappid(1239010)
