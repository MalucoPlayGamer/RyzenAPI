-- Lua provided by RyzenAPI
-- Game: addappid(1870630)

-- MAIN APPLICATION
addappid(1870630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870631, 1, "642adf3ac01ddba6948ad17f0f1b018d4996a0e135ef4d988d5140df3a1f2b4d")
