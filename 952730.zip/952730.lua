-- Lua provided by RyzenAPI
-- Game: 952730

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(952730)

-- MAIN APP DEPOTS / PACKAGES
addappid(952732,0,"137aaa0607f9721180cb504a74361dbccef00700656fa5d6e5f7e161b07be110")

