-- Lua provided by RyzenAPI
-- Game: Game: Re:BF

-- MAIN APPLICATION
addappid(1770400)
-- Game: addappid(1770400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770401, 1, "8c74c9c0b3c4782c669911186a4583dce7f06b430be375beb78ec8fa0b359ef8")
addappid(1770402, 1, "3a77bafed716266b37147cc63c991d41210689e358a74e2cb01379804f2fa44d")
addappid(1770403, 1, "368558d00067af72b09eb60e86d97a0abd46d2d2eb944cc0a80c7ce71bd11bdc")
