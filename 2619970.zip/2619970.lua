-- Lua provided by SkyAPI 
-- Game: Relentless Impetus
addappid(2619970)
addappid(2619971, 1, "f9f5703801f5259664dc31f67c89abd4c984dfdac2370e968e865ff61d3deb7f")
