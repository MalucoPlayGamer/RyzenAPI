-- Lua provided by RyzenAPI
-- Game: Relentless Impetus

-- MAIN APPLICATION
addappid(2619970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2619971, 1, "f9f5703801f5259664dc31f67c89abd4c984dfdac2370e968e865ff61d3deb7f")

