-- Lua provided by RyzenAPI
-- Game: Kandagawa Jet Girls - Digital Soundtrack

-- MAIN APPLICATION
addappid(1364520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364522,0,"2f1f12da1eb8ef432d87da30a37120fb6b1c5cc6326e85c134c339e679421db2")

