-- Lua provided by RyzenAPI
-- Game: Tropical Hop

-- MAIN APPLICATION
addappid(4950890) -- Tropical Hop

-- MAIN APP DEPOTS / PACKAGES
addappid(4950891, 1, "2be97ba1628719e58edd2b79285309ea8eb9aa61bfaf22d9a36c11a1ade81bb1") -- Depot 4950891

