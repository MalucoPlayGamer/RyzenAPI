-- Lua provided by RyzenAPI
-- Game: Maximum Football

-- MAIN APPLICATION
addappid(1691280)
