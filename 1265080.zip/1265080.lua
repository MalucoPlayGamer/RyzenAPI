-- Lua provided by RyzenAPI 
-- Game: 溜冰的猪少
addappid(1265080)
addappid(1265081, 1, "3c1d2a58d8582cb3370e2b6ad87219e509e6d096bfaaf41fa5ed306aa5396977")
