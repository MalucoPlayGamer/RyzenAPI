-- Lua provided by RyzenAPI
-- Game: 溜冰的猪少

-- MAIN APPLICATION
addappid(1265080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265081, 1, "3c1d2a58d8582cb3370e2b6ad87219e509e6d096bfaaf41fa5ed306aa5396977")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
