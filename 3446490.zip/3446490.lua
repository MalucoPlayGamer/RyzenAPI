-- Lua provided by RyzenAPI 
-- Game: Sixtar Gate: STARGAZER
addappid(3446490)
addappid(3446491, 1, "d12440c9e00dd5ab17429a33804188fc23f23c48217a214515fa67f3ea38038c")
