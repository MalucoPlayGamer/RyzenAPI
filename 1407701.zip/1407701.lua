-- Lua provided by RyzenAPI
-- Game: Rock of Ages III Original Soundtrack (High Quality)

-- MAIN APPLICATION
addappid(1407701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407701,0,"dc3c5f50fe7d1ef15d176f94c240a0a6b9927dc5dd10871e33aeda7490bb5181")

