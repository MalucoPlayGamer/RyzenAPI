-- Lua provided by RyzenAPI
-- Game: Order Picker Simulator

-- MAIN APPLICATION
addappid(4798110) -- Order Picker Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4798111, 1, "e5fb88020a6deb355a2498af9a3841e68481918db66a48899e4321d0f5b97bcb") -- Depot 4798111
addappid(4798112, 1, "086ad53ad06d39192a54894082023e6777e685c9e749c2583182f6647cf7b04e") -- Depot 4798112

