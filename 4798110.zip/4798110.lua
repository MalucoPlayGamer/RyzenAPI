-- 4798110's Lua and Manifest Created by Hubcap Manifest
-- Order Picker Simulator
-- Created: August 26, 2026 at 12:22:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4798110) -- Order Picker Simulator
-- MAIN APP DEPOTS
addappid(4798111, 1, "e5fb88020a6deb355a2498af9a3841e68481918db66a48899e4321d0f5b97bcb") -- Depot 4798111
setManifestid(4798111, "8380455168632235311", 1882838427)
addappid(4798112, 1, "086ad53ad06d39192a54894082023e6777e685c9e749c2583182f6647cf7b04e") -- Depot 4798112
setManifestid(4798112, "7079065863761807613", 1907146679)