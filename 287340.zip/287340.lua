-- Lua provided by RyzenAPI
-- Game: Colin McRae Rally

-- MAIN APPLICATION
addappid(287340)

-- MAIN APP DEPOTS / PACKAGES
addappid(287341, 1, "83d1bd56f70a11d99860eb13bf9764a1f5fa525de545f885b0debb6a78319b40")

