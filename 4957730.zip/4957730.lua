-- Lua provided by RyzenAPI
-- Game: Noon Saloon

-- MAIN APPLICATION
addappid(4957730) -- Noon Saloon

-- MAIN APP DEPOTS / PACKAGES
addappid(4957731, 1, "47b0952834cf29ffc8ad73d0abf514dca9faf1816da68a2dbfab323b7a6b6c9b") -- Depot 4957731

