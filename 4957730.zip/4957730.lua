-- 4957730's Lua and Manifest Created by Hubcap Manifest
-- Noon Saloon
-- Created: August 13, 2026 at 08:32:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4957730) -- Noon Saloon
-- MAIN APP DEPOTS
addappid(4957731, 1, "47b0952834cf29ffc8ad73d0abf514dca9faf1816da68a2dbfab323b7a6b6c9b") -- Depot 4957731
setManifestid(4957731, "9217525085180423245", 444012091)