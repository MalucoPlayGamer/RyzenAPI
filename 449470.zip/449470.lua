-- Lua provided by RyzenAPI
-- Game: Atulos Online

-- MAIN APPLICATION
addappid(449470)
addappid(463360)
addappid(469880)

-- MAIN APP DEPOTS / PACKAGES
addappid(449471, 1, "8eae1506c75518050eca3c4080b03c7091197253e4ee383a4bbabb7c3fd4755c")

