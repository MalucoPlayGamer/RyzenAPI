-- Lua provided by RyzenAPI
-- Game: 449470

-- MAIN APPLICATION
addappid(449470)
-- Game: addappid(449470)

-- MAIN APP DEPOTS / PACKAGES
addappid(449471, 1, "8eae1506c75518050eca3c4080b03c7091197253e4ee383a4bbabb7c3fd4755c")
