-- Lua provided by RyzenAPI
-- Game: Sacabambaspis Chronicle

-- MAIN APPLICATION
addappid(2634610)
-- Game: addappid(2634610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634611, 1, "ed73f91950c5dd12aa4de8d415f9327e0c145641bc21b783269d298ed2e27a04")
