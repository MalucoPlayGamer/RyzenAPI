-- Lua provided by RyzenAPI
-- Game: Miss Kobayashi's Dragon Maid Burst Forth!! Choro-gon☆Breath DIRECTOR'S CUT

-- MAIN APPLICATION
addappid(2086380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086381, 1, "01f915a13f7628c96e7896c84bb3fbca3030ea71b037fa33e4ee3f8821fd528a")

