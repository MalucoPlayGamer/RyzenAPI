-- Lua provided by SkyAPI 
-- Game: ICED
addappid(575570)
addappid(575571, 1, "c753585c0f79098e607a805e3d3c44f23b54603be3e3d04e4bc703a4c3d2eb9f")
addappid(640410)
