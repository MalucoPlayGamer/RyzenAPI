-- Lua provided by RyzenAPI
-- Game: Game: ICED

-- MAIN APPLICATION
addappid(575570)
addappid(640410)
-- Game: addappid(575570)

-- MAIN APP DEPOTS / PACKAGES
addappid(575571, 1, "c753585c0f79098e607a805e3d3c44f23b54603be3e3d04e4bc703a4c3d2eb9f")
