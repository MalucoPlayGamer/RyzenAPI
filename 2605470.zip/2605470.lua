-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Overbearing and preppy girl maid GP-02

-- MAIN APPLICATION
addappid(2605470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605471, 1, "08ad566e67f0c4eb4883de1a7311f52471b6e449fc39379f7d413337d41b4221")

