-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Layout Data Classy

-- MAIN APPLICATION
addappid(2928550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928550,0,"56ba3609a2447308ca20623f4eb5f304cd427b310d004a0ecc507501fd1ffdad")

