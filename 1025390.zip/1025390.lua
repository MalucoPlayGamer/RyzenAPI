-- Lua provided by RyzenAPI
-- Game: My Arctic Farm

-- MAIN APPLICATION
addappid(1025390)
-- Game: addappid(1025390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025391, 1, "97ade0e92f7758861a564b1cfde349b3404cbd2e0ab694ef64234a51c9991400")
