-- Lua provided by SkyAPI 
-- Game: My Arctic Farm
addappid(1025390)
addappid(1025391, 1, "97ade0e92f7758861a564b1cfde349b3404cbd2e0ab694ef64234a51c9991400")
