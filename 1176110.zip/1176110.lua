-- Lua provided by RyzenAPI
-- Game: 1176110

-- MAIN APPLICATION
addappid(1176110)
-- Game: addappid(1176110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176112,0,"92d7c4fab9b2555d15bf769ea6a9a836099a4a0935a26dc06bd121c68057dcc1")
