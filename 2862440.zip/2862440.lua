-- Lua provided by RyzenAPI
-- Game: addappid(2862440)

-- MAIN APPLICATION
addappid(2862440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862441, 1, "17d8848492bbf8becf978245ed6b9d6a276c2a059d28a38d5cfdeebd9486105a")
