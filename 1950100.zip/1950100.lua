-- Lua provided by RyzenAPI
-- Game: addappid(1950100)

-- MAIN APPLICATION
addappid(1950100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950101, 1, "3868d5bfd76e6b5584ee09dcd91d85eb89d8145aa7f8dd38b2e9af9e55198b42")
