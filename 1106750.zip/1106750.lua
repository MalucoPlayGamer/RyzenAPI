-- Lua provided by RyzenAPI
-- Game: Fault: Elder Orb

-- MAIN APPLICATION
addappid(1106750)
addappid(1282960)
addappid(1288000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106751,0,"6342eebbd3cdbf876e012f8206f48d9c9956bf258151d8aaab1ee3fb2cd73e54")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
