-- Lua provided by RyzenAPI
-- Game: Fault: Elder Orb

-- MAIN APPLICATION
addappid(1106750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106751, 1, "6342eebbd3cdbf876e012f8206f48d9c9956bf258151d8aaab1ee3fb2cd73e54")
