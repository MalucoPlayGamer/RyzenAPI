-- Lua provided by RyzenAPI
-- Game: 大鹏 - The Roc

-- MAIN APPLICATION
addappid(1389900)
-- Game: addappid(1389900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389901, 1, "0d3f41a038925beb2bdc9d47b00056266c2c470979e22ba69912965e1362b116")
