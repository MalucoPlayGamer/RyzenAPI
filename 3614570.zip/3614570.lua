-- Lua provided by RyzenAPI
-- Game: 龙与精灵 Dragons and elves

-- MAIN APPLICATION
addappid(3614570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614571, 1, "03cbef5cb74ca768749f591ec23938c2bc045be88ceb2b186e47e14a31592fd7")
addappid(3614572, 1, "480e4bc897cada814a4ff2b5434e150173352fbbfacb50b09ce240c4cb3801e5")
