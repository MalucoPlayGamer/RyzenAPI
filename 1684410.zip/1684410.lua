-- Lua provided by RyzenAPI
-- Game: Seal World

-- MAIN APPLICATION
addappid(1684410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684411, 1, "53e94325e2d749609640d0035a7f5b3ff44e3700a4c7f8c3ec1f0be6c1d7a549")
