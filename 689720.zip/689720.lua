-- Lua provided by RyzenAPI
-- Game: Gangsta Underground : The Poker

-- MAIN APPLICATION
addappid(689720)

-- MAIN APP DEPOTS / PACKAGES
addappid(689721, 1, "f17e5c9f4261a4e9608cb7b9381da5935252289fb2f6d72f1d82a937846b7a71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
