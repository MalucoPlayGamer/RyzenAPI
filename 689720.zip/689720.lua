-- Lua provided by RyzenAPI
-- Game: 689720

-- MAIN APPLICATION
addappid(689720)
-- Game: addappid(689720)

-- MAIN APP DEPOTS / PACKAGES
addappid(689721, 1, "f17e5c9f4261a4e9608cb7b9381da5935252289fb2f6d72f1d82a937846b7a71")
