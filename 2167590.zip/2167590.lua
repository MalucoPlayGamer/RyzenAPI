-- Lua provided by RyzenAPI
-- Game: Slicing Slicing

-- MAIN APPLICATION
addappid(2167590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167591, 1, "279333500e6cc728aa5ba7cc4fdb3e90e6e3c930c7094ee4fb0a789f0a0b956a")
