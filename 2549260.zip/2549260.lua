-- Lua provided by RyzenAPI
-- Game: addappid(2549260)

-- MAIN APPLICATION
addappid(2549260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549261, 1, "3a83eca4ba336b1de29e4b4e4824d664770381caafcc4e0df1debe92d5a37b44")
