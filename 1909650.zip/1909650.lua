-- Lua provided by RyzenAPI
-- Game: Ring War

-- MAIN APPLICATION
addappid(1909650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909651, 1, "e5d2c6f4991706bd26ca858d7da7cc4b0bc98074121b33ddb7297ed180f4b65c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
