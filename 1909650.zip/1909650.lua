-- Lua provided by RyzenAPI
-- Game: 1909650

-- MAIN APPLICATION
addappid(1909650)
-- Game: addappid(1909650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909651, 1, "e5d2c6f4991706bd26ca858d7da7cc4b0bc98074121b33ddb7297ed180f4b65c")
