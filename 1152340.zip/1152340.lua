-- Lua provided by RyzenAPI
-- Game: Book of Travels

-- MAIN APPLICATION
addappid(1152340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152341, 1, "8fc7e899ad351f74aeaaf5fb7995faff59fc5c36525a4d2dd323715066dbc999")
addappid(1152342, 1, "a966ff0815caf977fc0bddd5cc8a982d26ac85a8f473f85b4dd2920dfbfd7289")
addappid(1152344, 1, "7a6aeff4e41bfc67af65cf6073c1c4d0ba3d7d130f628b82a99144fcb27c3454")
addappid(1152345, 1, "3394cda39c1a76dc3a8f3d3e5378743834a7f5605972a707fe81d5ae72232dd4")
