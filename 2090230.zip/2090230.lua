-- Lua provided by RyzenAPI
-- Game: SCP: Containment Breach Remastered

-- MAIN APPLICATION
addappid(228981)
addappid(228982)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228989)
addappid(228990)
addappid(229007)
addappid(2090230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090232,0,"cf23c03a007e3af01df7e2e5f7bf52e5987f7696db708e8fc6911bdd2fe8ccf7")

