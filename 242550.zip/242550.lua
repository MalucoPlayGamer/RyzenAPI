-- Lua provided by RyzenAPI
-- Game: Rayman Legends

-- MAIN APPLICATION
addappid(242550)
addappid(247811)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(242551, 1, "686bb8789459e4e3030ad32b9375d784ae80215a36f25a6e2f7d9ca04a37adcd")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
