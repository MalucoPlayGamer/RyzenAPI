-- Lua provided by SkyAPI 
-- Game: AppID 242550
addappid(242550)
addappid(242551, 1, "686bb8789459e4e3030ad32b9375d784ae80215a36f25a6e2f7d9ca04a37adcd")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
