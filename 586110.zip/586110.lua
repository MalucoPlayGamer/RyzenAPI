-- Lua provided by RyzenAPI
-- Game: 586110

-- MAIN APPLICATION
addappid(586110)
-- Game: addappid(586110)

-- MAIN APP DEPOTS / PACKAGES
addappid(586111, 1, "7b42788ec9757a4101680cb36315382f1b601da5da44080ea98cc3e51e2769c2")
