-- Lua provided by RyzenAPI
-- Game: Sansar

-- MAIN APPLICATION
addappid(586110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(586111, 1, "7b42788ec9757a4101680cb36315382f1b601da5da44080ea98cc3e51e2769c2")

