-- Lua provided by RyzenAPI
-- Game: Salvage Shop Simulator

-- MAIN APPLICATION
addappid(3555500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3555501,0,"3bd513e987dbe2e6b6dd3c0b67fbe43517e3ab65e97c971bae9e881be250aad8")

