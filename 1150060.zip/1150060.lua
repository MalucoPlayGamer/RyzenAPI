-- Lua provided by RyzenAPI
-- Game: Game: AppID 1150060

-- MAIN APPLICATION
addappid(1150060)
-- Game: addappid(1150060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150061, 1, "43f88f9e4cf79e063e5695fa416d1a62df437bcac9579566f0ca61f97310c0ca")
