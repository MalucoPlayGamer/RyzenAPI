-- Lua provided by RyzenAPI
-- Game: 913150

-- MAIN APPLICATION
addappid(913150)
-- Game: addappid(913150)

-- MAIN APP DEPOTS / PACKAGES
addappid(913151, 1, "720fe1e25ad42156b945dd9325a76cb17a5cf51086f6c765b63993a60d3fdba7")
