-- Lua provided by RyzenAPI
-- Game: addappid(3241400)

-- MAIN APPLICATION
addappid(3241400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241401, 1, "4c7d7ea56be7802e225ecf9099121d71f3ad4dacd53e0b7ee1a7396650c3b1be")
addappid(3241402, 1, "550f68fbed33983c1490feeebb6dc968e50270a6105a5c18d76fcb6e8ad101ee")
