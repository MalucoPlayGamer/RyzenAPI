-- Lua provided by RyzenAPI
-- Game: 1361760

-- MAIN APPLICATION
addappid(1361760)
-- Game: addappid(1361760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361761, 1, "fc872705e87c1606c3fbd3bb4edbb2ac023f815e37656dd03d0cdfd2692f2147")
addappid(1361762, 1, "75c91572463053e11c3d882a9efc4e1c17616cd7f0dfafc8146f7e0755448df2")
