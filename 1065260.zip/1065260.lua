-- Lua provided by RyzenAPI
-- Game: addappid(1065260)

-- MAIN APPLICATION
addappid(1065260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065261, 1, "f10f9d57f24f23522d517a4a8dff3643c136c4a4f09c122fb79c73c37b706543")
