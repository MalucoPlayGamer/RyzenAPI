-- Lua provided by RyzenAPI
-- Game: Rose Guns Days -Season 2-

-- MAIN APPLICATION
addappid(4514210) -- Rose Guns Days -Season 2-

-- MAIN APP DEPOTS / PACKAGES
addappid(4514211, 1, "875dd8af63edb145f09ad9e6310d090eaadfe7b631138396c3d6a37fe4c1d774") -- Depot 4514211
addappid(4514212, 1, "ccfb6674b14d81507ba21b581370c54bff24d216c160d008d35c1a4be5537729") -- Depot 4514212
addappid(4514213, 1, "219dbf17ca2e479b26d191d83569cb11cf3fe4c59119ce31894c490b8991a8ac") -- Depot 4514213
addappid(4514214, 1, "2f2a05331037da57ae59d5924834da751ded22b2753967f487cff385652e817f") -- Depot 4514214

