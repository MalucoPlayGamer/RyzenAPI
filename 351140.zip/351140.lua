-- Lua provided by RyzenAPI
-- Game: Rustbucket Rumble

-- MAIN APPLICATION
addappid(351140)

-- MAIN APP DEPOTS / PACKAGES
addappid(351141, 1, "6d9ac9b0575291d08aaed6a4f80daaf4dbf4245f70b4cf8148501f43cf6ffce9")
addappid(351142, 1, "c47b7882493f8e5a100cab99bce5ae841ed982845f999792b89ca3e8d86616b2")
addappid(351143, 1, "c8776f98cef37a8496d05ca81d842827419781af5d13587f02d5ab6713577693")
addappid(351144, 1, "ae504afa9a0a64804149442f1080364bfb6a7fc51704a56e42dedf8d63861007")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(354890)
addappid(356780)
