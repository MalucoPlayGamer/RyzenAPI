-- Lua provided by RyzenAPI
-- Game: Bar Breaker

-- MAIN APPLICATION
addappid(2866250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866251,0,"a24eb20cb5fa1a02144f766805a03f5bb122be76fec963bf963285a964d8ccf6")

