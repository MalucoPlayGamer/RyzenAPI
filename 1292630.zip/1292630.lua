-- Lua provided by RyzenAPI
-- Game: 1292630

-- MAIN APPLICATION
addappid(1292630)
-- Game: addappid(1292630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292631, 1, "7e57603bb47bc0c367fc8c5ff12dbd864bef355e0f5e97bac5f783fc79ddd31f")
