-- 1292630's Lua and Manifest Created by Hubcap Manifest
-- 3on3 FreeStyle: Rebound
-- Created: August 23, 2026 at 01:36:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 64
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1292630, 1, "67f2b2b94fc9519c232006f7c222b298c6cdb5416058e5be3166ef594ef2032f") -- 3on3 FreeStyle: Rebound
-- MAIN APP DEPOTS
addappid(1292631, 1, "7e57603bb47bc0c367fc8c5ff12dbd864bef355e0f5e97bac5f783fc79ddd31f") -- 3on3 FreeStyle: Rebound Content
setManifestid(1292631, "7522745699537793065", 9006709219)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1316880) -- 3on3 FreeStyle Rebound - Rookie Package
addappid(1418660) -- 3on3 FreeStyle Rebound - Welcome Package
addappid(1493080) -- 3on3 FreeStyle Rebound - Rookie Package 2
addappid(1496730) -- 3on3 FreeStyle  Rebound - Battle Pass 2020 Winter
addappid(1496731) -- 3on3 FreeStyle  Rebound - Battle Pass 2020 Winter Bundle
addappid(1561580) -- 3on3 FreeStyle - Battle Pass 2021 Spring
addappid(1574230) -- 3on3 FreeStyle - Battle Pass 2021 Spring Bundle
addappid(1648640) -- 3on3 FreeStyle  Battle Pass 2021 Summer
addappid(1648641) -- 3on3 FreeStyle  Battle Pass 2021 Summer Bundle
addappid(1700060) -- 3on3 FreeStyle - 1st Anniversary Special Gift pack
addappid(1739810) -- 3on3 FreeStyle - Battle Pass 2021 Autumn Part. 1
addappid(1746090) -- 3on3 FreeStyle - Battle Pass 2021 Autumn Bundle Part. 1
addappid(1799430) -- 3on3 FreeStyle - Battle Pass 2021 Autumn Part. 2
addappid(1801840) -- 3on3 FreeStyle - Battle Pass 2021 Autumn Bundle Part. 2
addappid(1824860) -- 3on3 FreeStyle  All Character Pass
addappid(1824870) -- 3on3 FreeStyle  Forever User Care
addappid(1824890) -- 3on3 FreeStyle  All Battle Pass  Special Lounge
addappid(1849130) -- 3on3 FreeStyle - Battle Pass 2021 Winter Part. 1
addappid(1849140) -- 3on3 FreeStyle - Battle Pass 2021 Winter Bundle Part. 1
addappid(1881730) -- 3on3 FreeStyle - Battle Pass Winter Part. 2
addappid(1881740) -- 3on3 FreeStyle - Battle Pass Winter Bundle Part. 2
addappid(1931580) -- 3on3 FreeStyle - Battle Pass Spring Part. 1
addappid(1931590) -- 3on3 FreeStyle - Battle Pass Spring Bundle Part. 1
addappid(1986160) -- 3on3 FreeStyle - Battle Pass Spring Part. 2
addappid(1986161) -- 3on3 FreeStyle - Battle Pass Spring Bundle Part. 2
addappid(2023930) -- 3on3 FreeStyle - Battle Pass Summer Part. 1
addappid(2023931) -- 3on3 FreeStyle - Battle Pass Summer Bundle Part. 1
addappid(2074720) -- 3on3 FreeStyle - 2nd Anniversary Gift pack
addappid(2099970) -- 3on3 FreeStyle  Battle Pass Summer Part. 2
addappid(2099971) -- 3on3 FreeStyle  Battle Pass Summer Bundle Part. 2
addappid(2140830) -- 3on3 FreeStyle - Battle Pass Autumn Part 1
addappid(2140831) -- 3on3 FreeStyle - Battle Pass Autumn Bundle Part 1
addappid(2205910) -- 3on3 FreeStyle  Battle Pass 2022 Autumn Part.2 Bundle
addappid(2205911) -- 3on3 FreeStyle  Battle Pass 2022 Autumn Part.2
addappid(2242670) -- 3on3 FreeStyle - Battle Pass 2022 Winter Bundle Part 1
addappid(2242671) -- 3on3 FreeStyle - Battle Pass 2022 Winter Part 1
addappid(2289620) -- 3on3 FreeStyle - Battle Pass 2023 Winter Part 2
addappid(2289621) -- 3on3 FreeStyle - Battle Pass 2023 Winter Bundle Part 2
addappid(2329510) -- 3on3 FreeStyle - Battle Pass 2023 Spring Part 1
addappid(2329511) -- 3on3 FreeStyle - Battle Pass 2023 Spring Bundle Part 1
addappid(2358180) -- 3on3 FreeStyle - Ultimate Point Bundle
addappid(2358181) -- 3on3 FreeStyle - Premium Point Bundle
addappid(2408690) -- 3on3 FreeStyle - Battle Pass 2023 Spring Bundle Part 2
addappid(2408691) -- 3on3 FreeStyle - Battle Pass 2023 Spring Part 2
addappid(2456460) -- 3on3 FreeStyle - Battle Pass 2023 Summer Part 1
addappid(2456461) -- 3on3 FreeStyle - Battle Pass 2023 Summer Bundle Part 1
addappid(2502160) -- 3on3 FreeStyle - Premium Point Bundle
addappid(2502170) -- 3on3 FreeStyle - Ultimate Point Bundle
addappid(2514560) -- 3on3 FreeStyle  3rd Anniversary Gift Pack
addappid(2556140) -- 3on3 FreeStyle  Battle Pass 2023 Summer Part 2
addappid(2556150) -- 3on3 FreeStyle  Battle Pass 2023 Summer Bundle Part 2
addappid(2593300) -- 3on3 FreeStyle - Get Ready To Ball Package
addappid(2605620) -- 3on3 FreeStyle  Battle Pass 2023 Autumn Part 1
addappid(2605630) -- 3on3 FreeStyle  Battle Pass 2023 Autumn Bundle Part 1
addappid(2681670) -- 3on3 FreeStyle  Battle Pass 2023 Autumn Bundle Part 2
addappid(2681680) -- 3on3 FreeStyle  Battle Pass 2023 Autumn Part2
addappid(2757360) -- 3on3 FreeStyle - Crossplay 3rd Anniversary Gift Pack
addappid(3367150) -- Crossplay 4th Anniversary Gift Pack
addappid(3530620) -- Beginners Starter Kit
addappid(3774100) -- 3on3 FreeStyle  2025 All-Star Access Pass
addappid(3774110) -- 3on3 FreeStyle  Selection Rookie Pack
addappid(3780040) -- 3on3 FreeStyle  2025 Special Pack
addappid(3896910) -- 3on3 FreeStyle  P6 Selection Rookie Pack
addappid(3896920) -- 3on3 FreeStyle  P5 Selection Pro Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1316880) -- Depot 1316880 (empty depot)
-- addappid(1418660) -- Depot 1418660 (empty depot)
-- addappid(1493080) -- Depot 1493080 (empty depot)
-- addappid(1496730) -- Depot 1496730 (empty depot)
-- addappid(1496731) -- Depot 1496731 (empty depot)