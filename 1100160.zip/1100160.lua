-- Lua provided by RyzenAPI
-- Game: Touhou Seirensen ~ Undefined Fantastic Object.

-- MAIN APPLICATION
addappid(1100160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100161, 1, "f37947e2532fb87a2a93faf62aca4de8a9f30a24f2733b57bc883c670ed062bd")

