-- Lua provided by RyzenAPI
-- Game: Touhou Seirensen ~ Undefined Fantastic Object.

-- MAIN APPLICATION
addappid(1100160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100161, 1, "f37947e2532fb87a2a93faf62aca4de8a9f30a24f2733b57bc883c670ed062bd")

