-- Lua provided by RyzenAPI
-- Game: Game: looK INside - Chapter 2

-- MAIN APPLICATION
addappid(1725360)
-- Game: addappid(1725360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725361, 1, "016380319828b2b0a77c13f9c461ce8e47323353f99aa27db39c7080e1a7042b")
