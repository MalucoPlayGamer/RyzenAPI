-- Lua provided by RyzenAPI
-- Game: addappid(2165430)

-- MAIN APPLICATION
addappid(2165430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165430,0,"9a859999459ed22741ad00cbb5ca0dd6b6d528564ee6bfcc7b30c92bc98def87")
