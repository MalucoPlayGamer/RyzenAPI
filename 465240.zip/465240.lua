-- Lua provided by RyzenAPI
-- Game: Serious Sam VR: The Last Hope

-- MAIN APPLICATION
addappid(465240)
addappid(706900)
-- Game: addappid(465240)

-- MAIN APP DEPOTS / PACKAGES
addappid(465241, 1, "42852748f40239566e979405aa35a34074b5ec2ab4a04e3c63c3015ff8a619df")
addappid(465245, 1, "9993fc7b51f1302c3a76f2e9bf96ce58b2c66fa234e76a7b8601a73b4f4d71bb")
addappid(465246, 1, "4d4ead7f6df5f3c683f7b5ddd11ddedf5cf71fe4ffde767d6ff7390a115e8c51")
addappid(465249, 1, "fd72880cff2baaa7e2f0f83f11403d68b4783e647e06f864570fd1c9bf017522")
