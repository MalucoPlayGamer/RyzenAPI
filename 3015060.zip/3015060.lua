-- Lua provided by RyzenAPI
-- Game: addappid(3015060)

-- MAIN APPLICATION
addappid(3015060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015060,0,"59e0c1a34bc70abc6fdfb4bfee1603878e8e29ca5f8fcded1ca518d3aed45df0")
