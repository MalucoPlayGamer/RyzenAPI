-- Lua provided by RyzenAPI
-- Game: Game: Putrika 1st.cut:The Reason She Must Perish

-- MAIN APPLICATION
addappid(2818450)
-- Game: addappid(2818450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818451, 1, "a35b5048f471143009de762fd79c3cbdbbce82b83d29d799004f9ec801d75b36")
