-- Lua provided by RyzenAPI
-- Game: Dreams of Dali

-- MAIN APPLICATION
addappid(591360)

-- MAIN APP DEPOTS / PACKAGES
addappid(591362,0,"3d86c120c534e6f0637a74d9843fa52569090cce603a302eaebca5a8c5578ea6")

