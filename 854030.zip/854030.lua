-- Lua provided by RyzenAPI
-- Game: Ancient Journey VR

-- MAIN APPLICATION
addappid(854030)
-- Game: addappid(854030)

-- MAIN APP DEPOTS / PACKAGES
addappid(854031, 1, "a61ef67f4bf24439762a0341d661f62913d5c7e2ceff8224f9009a83b74a7c8a")
