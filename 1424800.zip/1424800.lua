-- Lua provided by RyzenAPI
-- Game: Uncharted Waters IV HD Version

-- MAIN APPLICATION
addappid(1424800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1424801, 1, "05b14351850b755d45f4c0d15f6ec5fb1f228c2f5c2ad3358b2c1a2bc0dfdcca")
addappid(1424802, 1, "6327f14abde99498df25b483e5639fa2d5f6fa899900b03c757647fe736aea48")
addappid(1424809, 1, "d4fa0b028a25879d82f424cc9a2bec9a047948273430083fc78d56bcfd2eaf26")
addappid(1585610, 0, "8e1a80aabe78427a1aee11bb95d11aa9469e5fc4ca29992d6bf79ca92336a223")

