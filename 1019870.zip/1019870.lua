-- Lua provided by RyzenAPI 
-- Game: AppID 1019870
addappid(1019870)
addappid(1019871, 1, "49af2f8fac6403c592f7bdd8d6a0ddd198fcd176c23ef1996330dd197c115830")
