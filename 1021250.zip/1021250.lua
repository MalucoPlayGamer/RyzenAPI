-- Lua provided by RyzenAPI
-- Game: Welcome To... Chichester 2 : VNMaker Version

-- MAIN APPLICATION
addappid(1021250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021250,0,"2b952b3d9b4af348ddacb22c82ec6010393cdec13c0f4588467cde881b6d4a0d")

