-- Lua provided by RyzenAPI
-- Game: The Ultimate Heist

-- MAIN APPLICATION
addappid(758400)
-- Game: addappid(758400)

-- MAIN APP DEPOTS / PACKAGES
addappid(758403,0,"e6dc50d94ce75fd8833506e6ea9e0de451fbead4ac83c370eaec0aa90cb1e415")
addappid(758404,0,"6368093307f191fd459e8142fc4b5163069fd2d043f5b3ce913bcf82deba5263")
addappid(758405,0,"014e9a01c258f279fd4612f93908daf37a6562d4d76877097830fd7f9c52234a")
