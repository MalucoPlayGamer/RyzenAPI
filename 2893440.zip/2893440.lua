-- Lua provided by RyzenAPI
-- Game: Beat Saber - Nicki Minaj - "Anaconda"

-- MAIN APPLICATION
addappid(2893440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893440,0,"56d13f098cd03dac9d392dc4b7611bb9fc0c93af5461f845944568f35ab050bb")
