-- Lua provided by RyzenAPI
-- Game: EA SPORTS™ PGA TOUR™

-- MAIN APPLICATION
addappid(1677350)
addappid(2337580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677351, 1, "35926dbbb1966047e99f70059b05fc88298e874d0e6ca2b90bd37d5bf6e9028d")
addappid(1677352, 1, "36d9ae111d606396ade5b1ab43997daca111cf50de39988b97177baf9c13fc4b")
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1681650)
addappid(2226200)
addappid(2226201)
addappid(2226202)
