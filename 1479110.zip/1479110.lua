-- Lua provided by RyzenAPI
-- Game: 1479110

-- MAIN APPLICATION
addappid(1479110)
-- Game: addappid(1479110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479111, 1, "a94a33706d43f123c93d739bae1c3fdcce506b694816e67631e8f65cdf0e8160")
