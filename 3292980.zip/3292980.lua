-- Lua provided by RyzenAPI
-- Game: Hacky

-- MAIN APPLICATION
addappid(3292980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3292981, 1, "b41add0ee57cebc4d27dfd57dcea96f8fe2db83e09b4c646f1986dae79dbfc7c")

