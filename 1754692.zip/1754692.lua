-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Sophie/Plachta/Ramizel/Alette's Costume "Bunny-Eared Salesgirl"

-- MAIN APPLICATION
addappid(1754692)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754692,0,"fa1773985960e293ff442f39e4769bae393091b693960bc712350bdefbcdbac9")

