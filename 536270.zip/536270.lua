-- Lua provided by RyzenAPI
-- Game: Ancestors: The Humankind Odyssey 

-- MAIN APPLICATION
addappid(536270) -- Ancestors: The Humankind Odyssey 

-- MAIN APP DEPOTS / PACKAGES
addappid(536272, 1, "cca45dc1fc727e49cb5dd237968fd4c65c0ae75f5ae2993fbbdee2d3e625ffdb") -- Ancestors Main

