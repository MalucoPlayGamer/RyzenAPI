-- Lua provided by RyzenAPI
-- Game: Funbag Fantasy 2

-- MAIN APPLICATION
addappid(1102340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1102341, 1, "31a8d8a9aea378e4f1592575f1976838a1c06e2f42ecb05b96b1f314f8a0bb88")

