-- Lua provided by RyzenAPI
-- Game: 1102340

-- MAIN APPLICATION
addappid(1102340)
-- Game: addappid(1102340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102341, 1, "31a8d8a9aea378e4f1592575f1976838a1c06e2f42ecb05b96b1f314f8a0bb88")
