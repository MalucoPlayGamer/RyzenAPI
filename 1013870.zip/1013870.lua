-- Lua provided by RyzenAPI 
-- Game: AppID 1013870
addappid(1013870)
addappid(1013871, 1, "1a23b5febcfc60aa075e82a3355376bc4d49785d197bc40a75d37c35d7dba087")
addappid(1013872, 1, "6d6037782f2f46afa1b114173fd3dfe775bc10e0f48cebf6f0a5e107ab0e670d")
