-- Lua provided by RyzenAPI
-- Game: Game: Fran Bow

-- MAIN APPLICATION
addappid(362680)
-- Game: addappid(362680)

-- MAIN APP DEPOTS / PACKAGES
addappid(362681, 1, "44d14e5570baff72ae61a2c1d9b484c8e0ada528e532b141ec1234afaa5c49e8")
addappid(362682, 1, "b0c58d31e871b42fc70b331ec6b01ea3d6513e0316f8a2fef08ac01f2aa51014")
addappid(362683, 1, "a44a84f94135c910aba50badf09799ce3ebd35ff5160292fd5b402a75523459d")
addappid(404840, 0, "6954fc834142b8700efb11fa6b92c17db6f3ee81b4b12aa515b6a323ba4a3b33")
