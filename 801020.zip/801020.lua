-- Lua provided by RyzenAPI
-- Game: Golden Dungeons

-- MAIN APPLICATION
addappid(801020)
addappid(839760)

-- MAIN APP DEPOTS / PACKAGES
addappid(801021, 1, "d926f10d38807881a67882104480d957f682f7901c2d634ff6fef13114f16021")
