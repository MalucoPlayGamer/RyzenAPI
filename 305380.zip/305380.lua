-- Lua provided by RyzenAPI 
-- Game: Blue Estate The Game
addappid(305380)
addappid(305381, 1, "cf2cd1934e2b80bbd0bcff1062717a736c12d607b8e4681cdbd193df87fb4649")
