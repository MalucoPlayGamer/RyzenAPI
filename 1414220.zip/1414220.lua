-- Lua provided by RyzenAPI
-- Game: 1414220

-- MAIN APPLICATION
addappid(1414220)
-- Game: addappid(1414220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414221, 1, "acaea0a6802a0c35b611fe5ba785cc562aff17344548bc2ad533f101edb84f86")
