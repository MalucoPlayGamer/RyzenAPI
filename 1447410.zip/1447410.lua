-- Lua provided by RyzenAPI
-- Game: 1447410

-- MAIN APPLICATION
addappid(1447410)
-- Game: addappid(1447410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447411, 1, "e0527ed3eb269af719a81e1dd7f2d1ec68596a65ee109395736a53233878e37c")
