-- Lua provided by RyzenAPI 
-- Game: Mandew vs the Colorless Curse
addappid(1447410)
addappid(1447411, 1, "e0527ed3eb269af719a81e1dd7f2d1ec68596a65ee109395736a53233878e37c")
