-- Lua provided by RyzenAPI 
-- Game: JUSFASLEX
addappid(2769380)
addappid(2769381, 1, "a8c20558539c9f26074defe236ad91df4671bc82df19ca96b3f547cbce68109c")
