-- Lua provided by RyzenAPI
-- Game: Luma Island Soundtrack

-- MAIN APPLICATION
addappid(3387260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387261, 1, "b4c9cd24fd4ef1dabbaf1c67459c7cd2315605547c61edcda2bd0f9d558aae1c")
