-- Lua provided by RyzenAPI
-- Game: SpiritSphere DX

-- MAIN APPLICATION
addappid(458170)

-- MAIN APP DEPOTS / PACKAGES
addappid(458171, 1, "94944bd5bbec140699f7b4712359875994abb9ca413cc9309227e2eaa425aadb")
