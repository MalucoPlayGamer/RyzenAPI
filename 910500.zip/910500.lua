-- Lua provided by RyzenAPI
-- Game: Goalkeeper Legend

-- MAIN APPLICATION
addappid(910500)

-- MAIN APP DEPOTS / PACKAGES
addappid(910501, 1, "7f90b06f728b8e7428619d4149a739c09a7ed3a279b17df566d7d9f96ef6e813")
