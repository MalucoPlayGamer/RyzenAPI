-- Lua provided by RyzenAPI
-- Game: 220070

-- MAIN APPLICATION
addappid(220070)
-- Game: addappid(220070)

-- MAIN APP DEPOTS / PACKAGES
addappid(220071, 1, "72a9baaa436b9ed3e52fd00c0fbf681275c75d7f413c14b909fbcb478804ec10")
