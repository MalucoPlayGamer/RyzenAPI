-- Lua provided by RyzenAPI
-- Game: Tranquil Builds Demo

-- MAIN APPLICATION
addappid(2772290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772292,0,"37ab7d8bf57a71bff99ced5d9b7222f92d0479c62323d9c9098d82a1089cf5b0")

