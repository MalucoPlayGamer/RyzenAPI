-- Lua provided by RyzenAPI
-- Game: Game: Ley Lines

-- MAIN APPLICATION
addappid(529770)
-- Game: addappid(529770)

-- MAIN APP DEPOTS / PACKAGES
addappid(529771, 1, "f788f0453876ffa3d9ab25989708337182a7f74717441ce6bbf63dbb98d2c455")
