-- Lua provided by RyzenAPI
-- Game: Pirate Fighting Simulator

-- MAIN APPLICATION
addappid(2186400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186401, 1, "9fc2c8376f3b27a48f115067764907b7caf0c922b24acc8663c20b06afeb5b94")

