-- Lua provided by RyzenAPI
-- Game: GRIME - Demo

-- MAIN APPLICATION
addappid(1524090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524091, 1, "d9d9b9328eec27e58d17e8a78c3f50cbc3338c57d4e06c67eb8937389e09a821")
