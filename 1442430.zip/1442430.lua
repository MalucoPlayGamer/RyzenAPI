-- Lua provided by RyzenAPI 
-- Game: Storage Hunter Simulator
addappid(1442430)
addappid(1442431, 1, "2143ac048a0302d64fe1279b0b62672b0ffcb1f10350c672b96c89f5be2d01f1")
