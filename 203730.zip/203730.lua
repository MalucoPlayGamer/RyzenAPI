-- Lua provided by RyzenAPI
-- Game: 203730

-- MAIN APPLICATION
addappid(203730)
addappid(203733)

-- MAIN APP DEPOTS / PACKAGES
addappid(203732,0,"2b778a724832b04bb6eb5d59ea842a97cd947330837f8cf45ff5e7ccf77d1d1e")
addappid(203734,0,"8dc029aa0a60dae51a4cff8af3b88966db94c30cf97ca150870a65fa32b7cad6")
addappid(234570,0,"c45e51eee1607e1f329f6511fe3fe8efe8d0823fe45ae57d3396fbc223c8ecdb")

