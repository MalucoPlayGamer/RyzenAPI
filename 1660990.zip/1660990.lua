-- Lua provided by RyzenAPI 
-- Game: AppID 1660990
addappid(1660990)
addappid(1660991, 1, "eec84c117df4fd785c8828d15830fbad5126544f46f894902d7a61302ecc7366")
