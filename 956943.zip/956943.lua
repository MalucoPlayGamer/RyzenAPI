-- Lua provided by RyzenAPI
-- Game: Zhang Chunhua - Officer Ticket / 張春華使用券

-- MAIN APPLICATION
addappid(956943)

-- MAIN APP DEPOTS / PACKAGES
addappid(956943,0,"7556986eda7fe6c6176e1bc2bec5314d58566790d501cbaff71ed83dd417925e")
