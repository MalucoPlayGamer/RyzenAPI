-- Lua provided by RyzenAPI
-- Game: Game: 轩辕剑伍 原声音乐精选集

-- MAIN APPLICATION
addappid(2015550)
-- Game: addappid(2015550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015551, 1, "0bfc64294889ad0ea2ae4f3e39c3cd75807b9277d755b2614256e9aacbf88ab5")
addappid(2015552, 1, "c8c3d2276353acb476b4243bb5a0d051d4d0c9fb13e1518214123a3e34380861")
