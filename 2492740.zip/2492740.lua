-- Lua provided by RyzenAPI
-- Game: Project 13: Taxidermy Trails

-- MAIN APPLICATION
addappid(2492740)
-- Game: addappid(2492740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492741, 1, "74406a486a3fce2547407cf69477c24bf6ea90d01347c39d268f97d8588dfc97")
