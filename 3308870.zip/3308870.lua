-- Lua provided by RyzenAPI
-- Game: 3308870

-- MAIN APPLICATION
addappid(3308870)
-- Game: addappid(3308870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308871, 1, "fe2b6ca1283b62554a477c6cf46b88ba213afb70fe8568033a9afff63f5c89d6")
