-- Lua provided by RyzenAPI
-- Game: GE Neuro

-- MAIN APPLICATION
addappid(496180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(496181, 1, "0143482e8e4cebefa9282afbdc97091d97fe8eaa97a9d1b842e88ffd9d7afd3f")

