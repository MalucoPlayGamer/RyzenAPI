-- Lua provided by RyzenAPI
-- Game: AppID 496180

-- MAIN APPLICATION
addappid(496180)
-- Game: addappid(496180)

-- MAIN APP DEPOTS / PACKAGES
addappid(496181, 1, "0143482e8e4cebefa9282afbdc97091d97fe8eaa97a9d1b842e88ffd9d7afd3f")
