-- Lua provided by SkyAPI 
-- Game: Oh My Girl
addappid(1253820)
addappid(1253821, 1, "be6c8e227f0a3f9bdef0e65d71113aadcb71287edff10d9391d4a50a9f37b8a7")
