-- Lua provided by RyzenAPI
-- Game: Oh My Girl

-- MAIN APPLICATION
addappid(1253820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253821, 1, "be6c8e227f0a3f9bdef0e65d71113aadcb71287edff10d9391d4a50a9f37b8a7")

