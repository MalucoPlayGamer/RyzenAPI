-- Lua provided by SkyAPI 
-- Game: There Will Be Ink
addappid(1020450)
addappid(1020451, 1, "e0b7ad243083d04bd15ed9aacf1aa05a8180da2d47a6be0ed671b8917067dd38")
