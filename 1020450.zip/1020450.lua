-- Lua provided by RyzenAPI
-- Game: Game: There Will Be Ink

-- MAIN APPLICATION
addappid(1020450)
-- Game: addappid(1020450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020451, 1, "e0b7ad243083d04bd15ed9aacf1aa05a8180da2d47a6be0ed671b8917067dd38")
