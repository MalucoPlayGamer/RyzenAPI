-- Lua provided by RyzenAPI
-- Game: 2632720

-- MAIN APPLICATION
addappid(2632720)
-- Game: addappid(2632720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632721, 1, "bd8e2cd09835ab24f57d3c45ea77bd846ce0ef68135a2d046b0f0bcd184351e5")
