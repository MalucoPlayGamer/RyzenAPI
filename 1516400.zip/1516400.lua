-- Lua provided by RyzenAPI
-- Game: Game: Gaia Project

-- MAIN APPLICATION
addappid(1516400)
-- Game: addappid(1516400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516401, 1, "2262d478ead21423929ecb12c689d957b07b93e5dc0988e617d498dbf1a770b0")
