-- Lua provided by RyzenAPI 
-- Game: AppID 1197340
addappid(1197340)
addappid(1197341, 1, "db74b91511b30430e9c91bae5de6afb8011dd5e8b7bfd2d1dd1a6ff8070091c9")
