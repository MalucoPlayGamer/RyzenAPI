-- Lua provided by RyzenAPI
-- Game: BOKURA Soundtrack

-- MAIN APPLICATION
addappid(2875550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875553,0,"3dab584724eb265e4d9fda4267d0cc5c240b19a80d813c599313f9cc8d1a4648")
