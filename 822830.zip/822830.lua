-- Lua provided by RyzenAPI
-- Game: Ouroboros

-- MAIN APPLICATION
addappid(822830)

-- MAIN APP DEPOTS / PACKAGES
addappid(822831,0,"17c47f8874913f8d0cc97839a9d9d2f8755e47cc132be859f645fa066f242690")

