-- Lua provided by SkyAPI 
-- Game: 幸存者乐园
addappid(1694100)
addappid(1694101, 1, "d44a92ce99bfdb07c07b9b3e703096f2ee807621b82607d375c462e2d9fa5099")
