-- Lua provided by RyzenAPI
-- Game: 1648412

-- MAIN APPLICATION
addappid(1648412)
-- Game: addappid(1648412)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648412,0,"915b7f87dd846b874cbe1168808b7b2d70c87bfb13aaae99ba07dcf6944359d2")
