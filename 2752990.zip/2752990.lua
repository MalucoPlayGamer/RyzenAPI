-- Lua provided by RyzenAPI
-- Game: 煌星的勝利女神 Demo

-- MAIN APPLICATION
addappid(2752990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752991, 1, "0070d728ac771010eab1b255bf5a3eda354f7efdddca0ee579b53c0917a58efb")

