-- Lua provided by RyzenAPI
-- Game: Heroes Wanted

-- MAIN APPLICATION
addappid(2667410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667411, 1, "c5a3b2621cef06cda47226ab9cf92f5eaa707b91e57800fe9e0d1e4ef45284dd")

