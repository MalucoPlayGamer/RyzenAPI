-- Lua provided by RyzenAPI
-- Game: Game: Space Run Galaxy

-- MAIN APPLICATION
addappid(355800)
-- Game: addappid(355800)

-- MAIN APP DEPOTS / PACKAGES
addappid(355801, 1, "0de743a82063f50304b083653769350ebe5e80fb5c7dd48a4c377b23f61fb693")
addappid(355802, 1, "17b690d089f0a4a3fdaa20d51fb8ce1e96dcaee6c89ea0e4cb26a56bf77e359d")
addappid(355803, 1, "42110ee2c7a3ba95e952388042e0d18ac4137685e075708f6f171d1040b16a68")
addappid(355804, 1, "d3e16441c044a63e0e9c2968cb4f23def42b267538b6f35610ab35f381c92d3a")
