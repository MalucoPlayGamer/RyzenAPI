-- Lua provided by RyzenAPI
-- Game: Game: AppID 2924100

-- MAIN APPLICATION
addappid(2924100)
-- Game: addappid(2924100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924101, 1, "fe02cd2f085356a81a9a96b7a3993dcee690a843a23db37d61a7ddc082537704")
