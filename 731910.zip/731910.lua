-- Lua provided by RyzenAPI
-- Game: Game: JumpSky

-- MAIN APPLICATION
addappid(731910)
-- Game: addappid(731910)

-- MAIN APP DEPOTS / PACKAGES
addappid(731911, 1, "eea766638cbbc4d408964c86d29e668df44f0521e0ecbfafa5b3cc0d31b784de")
