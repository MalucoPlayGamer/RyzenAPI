-- Lua provided by RyzenAPI
-- Game: I Believe in Capybara Supremacy!

-- MAIN APPLICATION
addappid(2424680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424681, 1, "78b62de675c6eff5acd8ed3a13075fb10775f31fbf795974c73fd28667f4a331")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
