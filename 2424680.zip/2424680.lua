-- Lua provided by RyzenAPI
-- Game: I Believe in Capybara Supremacy!

-- MAIN APPLICATION
addappid(2424680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424681, 1, "78b62de675c6eff5acd8ed3a13075fb10775f31fbf795974c73fd28667f4a331")

