-- Lua provided by RyzenAPI
-- Game: Laugh Track

-- MAIN APPLICATION
addappid(3765430)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4158110)
