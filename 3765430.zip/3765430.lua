-- Lua provided by RyzenAPI
-- Game: Laugh Track

-- MAIN APPLICATION
addappid(3765430)

