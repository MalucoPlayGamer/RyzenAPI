-- Lua provided by RyzenAPI
-- Game: Game: AppID 543170

-- MAIN APPLICATION
addappid(543170)
-- Game: addappid(543170)

-- MAIN APP DEPOTS / PACKAGES
addappid(543171, 1, "2f540a41db26cf90a0a07c518d28d3c1693d12a95aee00b7f214af23cf0d0978")
