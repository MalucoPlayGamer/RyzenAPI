-- Lua provided by RyzenAPI
-- Game: Game: Art your brains

-- MAIN APPLICATION
addappid(2011140)
-- Game: addappid(2011140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011141, 1, "543959e5c0234f810fbc23041bf2ec934079177226f0c1a7844b24112a0b6678")
