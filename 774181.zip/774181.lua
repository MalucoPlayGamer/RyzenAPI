-- Lua provided by RyzenAPI
-- Game: Rhythm Doctor

-- MAIN APPLICATION
addappid(774181)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(774182, 1, "76d37d204d148b56554e8f8de5fba461e96eb4206c11c67aaf4fce8327ddd0a9")
addappid(774183, 1, "51118da8096080b0800e51f785e7b8812e81e340ad4f3e6caed07a39ff96ecab")
addappid(774184, 1, "3ae0a202ba2e80ef7386acf3a1f9014a1bf2bec36d70f66349afb9495e030006")
addappid(774185, 1, "106fec9539cb2a9532e537df1fda91b4297a1482dfc2799a4b79aa8df59a55d5")
