-- Lua provided by RyzenAPI 
-- Game: Mare Nostrum
addappid(1230)
addappid(1231, 1, "e730bef874fef4c883b2f9b9cda2f6eb03aad6a7a22c3513e2401142229e31fe")
addappid(1232, 1, "7056ece88ad57b45d789e69e8f39f52255360cce15ca6f1beecf6c6a0624ca71")
