-- Lua provided by RyzenAPI
-- Game: Otherworld: Shades of Fall Collector's Edition

-- MAIN APPLICATION
addappid(696010)

-- MAIN APP DEPOTS / PACKAGES
addappid(696011,0,"6599e0dc960fb2ca5837b62630541826127f018ff9f43f1cf2fbdd36989d69d8")

