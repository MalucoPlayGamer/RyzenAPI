-- Lua provided by RyzenAPI
-- Game: ReThink | Evolved 2

-- MAIN APPLICATION
addappid(820600)

-- MAIN APP DEPOTS / PACKAGES
addappid(820601, 1, "8a81199e203c5796d75eafe929ccf1961bc7cf7ae244a4acbdad4b4bd39a0a0c")

