-- Lua provided by RyzenAPI
-- Game: ReThink | Evolved 2

-- MAIN APPLICATION
addappid(820600)

-- MAIN APP DEPOTS / PACKAGES
addappid(820601, 1, "8a81199e203c5796d75eafe929ccf1961bc7cf7ae244a4acbdad4b4bd39a0a0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
