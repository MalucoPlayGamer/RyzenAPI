-- Lua provided by RyzenAPI
-- Game: Game: STAR WARS™: The Old Republic™ - Public Test Server

-- MAIN APPLICATION
addappid(1433120)
-- Game: addappid(1433120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433121, 1, "281907ce57ad8ce4d06f8f1dce0fe10e9a32422f43140d8966b408348fcb7cfe")
addappid(1433124, 1, "688844e5406071874833818cf66501b290da93960140439494a029bd7abd9a39")
addappid(1433125, 1, "95278dd20c95a82f8cd65308ab3c9ce9bcffe32c3d5b3126b1ba262b4d0001a3")
