-- Lua provided by RyzenAPI
-- Game: STAR WARS™: The Old Republic™ - Public Test Server

-- MAIN APPLICATION
addappid(1433120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1433121, 1, "281907ce57ad8ce4d06f8f1dce0fe10e9a32422f43140d8966b408348fcb7cfe")
addappid(1433124, 1, "688844e5406071874833818cf66501b290da93960140439494a029bd7abd9a39")
addappid(1433125, 1, "95278dd20c95a82f8cd65308ab3c9ce9bcffe32c3d5b3126b1ba262b4d0001a3")

