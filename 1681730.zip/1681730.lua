-- Lua provided by RyzenAPI 
-- Game: Joint War - [BETA]
addappid(1681730)
addappid(1681731, 1, "f040ab370b8302931fc2e1f368d34603b69737dd343847fb82558695ac488412")
