-- Lua provided by RyzenAPI
-- Game: Game: Joint War - [BETA]

-- MAIN APPLICATION
addappid(1681730)
-- Game: addappid(1681730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681731, 1, "f040ab370b8302931fc2e1f368d34603b69737dd343847fb82558695ac488412")
