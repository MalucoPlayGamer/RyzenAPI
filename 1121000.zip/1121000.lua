-- Lua provided by RyzenAPI
-- Game: 1121000

-- MAIN APPLICATION
addappid(1121000)
-- Game: addappid(1121000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121001, 1, "ee4c1c7936f358f805db5ea8415fac41eff27927ccb21722d08968880638f24e")
