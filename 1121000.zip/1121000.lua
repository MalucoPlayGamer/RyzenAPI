-- Lua provided by RyzenAPI 
-- Game: AppID 1121000
addappid(1121000)
addappid(1121001, 1, "ee4c1c7936f358f805db5ea8415fac41eff27927ccb21722d08968880638f24e")
