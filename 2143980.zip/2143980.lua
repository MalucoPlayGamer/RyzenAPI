-- Lua provided by RyzenAPI
-- Game: Wife of My Boss

-- MAIN APPLICATION
addappid(2143980)
addappid(2144050)
-- Game: addappid(2143980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143981, 1, "114e896b431ac2a9fd9912e0346ad75f951557a9a861cfc8046f181adc550f54")
