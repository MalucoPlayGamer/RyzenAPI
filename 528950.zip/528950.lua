-- Lua provided by RyzenAPI
-- Game: Nekuia

-- MAIN APPLICATION
addappid(528950)

-- MAIN APP DEPOTS / PACKAGES
addappid(528951, 1, "fe037aeec1acdee25828893c776287f25e66050a38ca71ac79fdefb079146ce1")

