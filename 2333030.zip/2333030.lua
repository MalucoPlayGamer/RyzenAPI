-- Lua provided by RyzenAPI
-- Game: AniCursor

-- MAIN APPLICATION
addappid(2333030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2333031, 1, "f204f69811b73a650407d3d375e3282f654c7f8c8a6e1014b6f32b622735597a")
