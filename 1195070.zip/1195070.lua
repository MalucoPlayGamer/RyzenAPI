-- Lua provided by SkyAPI 
-- Game: AppID 1195070
addappid(1195070)
addappid(1195071, 1, "38c417b701fb1af4d2c80e812c582d9cb7187b7ea0a92603a80a648c5b44ec8c")
