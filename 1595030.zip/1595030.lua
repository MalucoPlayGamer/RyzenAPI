-- Lua provided by RyzenAPI
-- Game: Bad Memories

-- MAIN APPLICATION
addappid(1595030)
-- Game: addappid(1595030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595031, 1, "a51353c9900493a310f180ce9269468cd6135e775a505dc1d27a261067c44ac7")
