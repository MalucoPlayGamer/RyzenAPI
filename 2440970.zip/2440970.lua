-- Lua provided by RyzenAPI 
-- Game: 飞仙诀(福利版)-上线送V15+万元真充+无限抽奖
addappid(2440970)
addappid(2440971, 1, "0be609156736892783316e410b4f0f91e56bc8eb6a9e2d836679920c98344612")
