-- Lua provided by RyzenAPI
-- Game: The Kindeman Remedy

-- MAIN APPLICATION
addappid(2055410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055411, 1, "cac1fc59f07ff5bc33c08c9c1819132f61ee0cfb90d74009e3fb8250e9270c0f")

