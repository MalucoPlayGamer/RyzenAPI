-- Lua provided by RyzenAPI
-- Game: PixARK

-- MAIN APPLICATION
addappid(593600)
-- Game: addappid(593600)

-- MAIN APP DEPOTS / PACKAGES
addappid(593601, 1, "30052f6dbd5c875ccf3833ebf47a3fec63df141df7fd13a36af93eeb3a2e28e2")
addappid(883840, 0, "412314ab6cc4fc61df3d2687d2a9a5d9e09b0f2c08797209a2a2747977f62a55")
