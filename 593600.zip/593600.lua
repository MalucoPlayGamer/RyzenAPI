-- 593600's Lua and Manifest Created by Hubcap Manifest
-- PixARK
-- Created: August 13, 2026 at 07:51:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 8 (1 excluded)
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(593600, 1, "5d449528e9846f96c4b80c481c094e74f7032321cd826fa0fdf7c7b2531f0b35") -- PixARK
-- MAIN APP DEPOTS
addappid(593601, 1, "30052f6dbd5c875ccf3833ebf47a3fec63df141df7fd13a36af93eeb3a2e28e2") -- Project Pix Content
setManifestid(593601, "7029282387141006906", 19730552979)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- PixARK-Skyward (AppID: 883840)
addappid(883840)
addappid(883840, 1, "412314ab6cc4fc61df3d2687d2a9a5d9e09b0f2c08797209a2a2747977f62a55") -- PixARK-Skyward - PixARK-Skyward (883840) 个 Depot
setManifestid(883840, "4597967802456220653", 20125170434)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1143160) -- PixARK-Skyward Structure Style Pack
addappid(2244940) -- PixARK - New DLC
addappid(2251560) -- PixARK - Christmas Skins
addappid(2391890) -- PixARK - Candy Store DLC
addappid(2659570) -- PixARK - Every Little Thing You Do Is Magic
addappid(2792640) -- PixARK - Jade Elegance A Theatrical Odyssey in the East
addappid(3154410) -- PixARK - The Legacy of Ancient Egypt
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3747200) -- 方块方舟 - 地下迷城 (unreleased)