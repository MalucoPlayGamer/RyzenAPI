-- Lua provided by RyzenAPI
-- Game: PixARK

-- MAIN APPLICATION
addappid(883840)
addappid(1143160) -- PixARK-Skyward Structure Style Pack
addappid(1449740)
addappid(2244940) -- PixARK - New DLC
addappid(2251560) -- PixARK - Christmas Skins
addappid(2391890) -- PixARK - Candy Store DLC
addappid(2659570) -- PixARK - Every Little Thing You Do Is Magic
addappid(2792640) -- PixARK - Jade Elegance: A Theatrical Odyssey in the East
addappid(3154410) -- PixARK - The Legacy of Ancient Egypt
addappid(3747200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(593600, 1, "5d449528e9846f96c4b80c481c094e74f7032321cd826fa0fdf7c7b2531f0b35")
addappid(593601, 1, "30052f6dbd5c875ccf3833ebf47a3fec63df141df7fd13a36af93eeb3a2e28e2")
addappid(883840, 1, "412314ab6cc4fc61df3d2687d2a9a5d9e09b0f2c08797209a2a2747977f62a55")
addappid(1449741, 1, "ee1ba6d691639d9067edfb5e93f4aa55446643ef4586cf635a5fe19ed7179470")
addappid(1449742, 1, "f5208958e43d48d077cc0fbbecd0fe805a626df481516d353ebf46dfe74a4d13")
addappid(3747200, 1, "707774425c8831db35d55866b36e1fbe27677c6ab182c5cced7205a6ba63571e")

