-- Lua provided by RyzenAPI
-- Game: 咸鱼喵喵 Artbook

-- MAIN APPLICATION
addappid(2495690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495690,0,"d37c959d4f78ef15c8647f82355c8f8cd155500049e39df6a36963933d1d558b")

