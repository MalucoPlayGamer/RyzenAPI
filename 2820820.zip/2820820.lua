-- 2820820's Lua and Manifest Created by Hubcap Manifest
-- Jotunnslayer: Hordes of Hel
-- Created: May 14, 2026 at 17:44:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(2820820, 1, "0ae2a1df938163eb74f103f3bdfaa387a3bbcdebe1efe184c4ff46c45ce51f0e") -- Jotunnslayer: Hordes of Hel
-- MAIN APP DEPOTS
addappid(2820821, 1, "6c3ca2723bed87cab9ee1a573779e7cd92ddfaa4f61727af0e5f5219c736611d") -- Depot 2820821
--setManifestid(2820821, "7467930491384536267", 27657212710)
-- DLCS WITH DEDICATED DEPOTS
-- Jotunnslayer Hordes of Hel - Digital Artbook (AppID: 3431390)
addappid(3431390)
addappid(3431390, 1, "aa6311cfc779ff46fdbcde4dc361ae59e77a942ab4ec0431eb5d1f560793426f") -- Jotunnslayer Hordes of Hel - Digital Artbook - Depot 3431390
--setManifestid(3431390, "2909742351710447496", 1028747818)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3400400) -- Jotunnslayer Hordes of Hel - Odins Legendary Armor Pack
addtoken(3400400, "13783583173768217623")
addappid(3883640) -- Jotunnslayer Hordes of Hel - Bifrost Legendary Armor Pack
addappid(3921120) -- Jotunnslayer Hordes of Hel - Tyrs Mythical Armor Pack
addappid(4156460) -- Jotunnslayer Hordes of Hel - Freyrs Gilded Armor Pack
addappid(4369830) -- Jotunnslayer Hordes of Hel - Conan