-- Lua provided by RyzenAPI
-- Game: INSIDE

-- MAIN APPLICATION
addappid(304430)

-- MAIN APP DEPOTS / PACKAGES
addappid(304432,0,"69afabd5b5e1e1ae7314fc1e2082761fbf63d59c300fb084a8a14883fedaab3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
