-- Lua provided by RyzenAPI
-- Game: INSIDE

-- MAIN APPLICATION
addappid(304430)
-- Game: addappid(304430)

-- MAIN APP DEPOTS / PACKAGES
addappid(304432,0,"69afabd5b5e1e1ae7314fc1e2082761fbf63d59c300fb084a8a14883fedaab3c")
