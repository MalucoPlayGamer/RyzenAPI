-- Lua provided by RyzenAPI
-- Game: 100 Funny Cats

-- MAIN APPLICATION
addappid(2881230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881231, 1, "fedf8dfa6bad88758451a643b8835e1cac37d3ba0409d57a52e6c9173d36e2ec")
