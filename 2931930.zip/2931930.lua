-- Lua provided by SkyAPI 
-- Game: AppID 2931930
addappid(2931930)
addappid(2931931, 1, "34371320446e808dd0508a9543e5d27f8be2c7af835a8ab31d9d65f770795b61")
