-- Lua provided by RyzenAPI
-- Game: Let's Minesweeper Demo

-- MAIN APPLICATION
addappid(2931930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931931, 1, "34371320446e808dd0508a9543e5d27f8be2c7af835a8ab31d9d65f770795b61")

