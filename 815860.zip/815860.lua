-- Lua provided by RyzenAPI
-- Game: Reframed

-- MAIN APPLICATION
addappid(815860)

-- MAIN APP DEPOTS / PACKAGES
addappid(815861,0,"fc07b8005020d6bf7610ad4af85b8fc603145a22ebbaf3242d28dbde0f8143e5")

