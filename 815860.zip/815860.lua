-- Lua provided by RyzenAPI
-- Game: Reframed

-- MAIN APPLICATION
addappid(815860)

-- MAIN APP DEPOTS / PACKAGES
addappid(815861,0,"fc07b8005020d6bf7610ad4af85b8fc603145a22ebbaf3242d28dbde0f8143e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
