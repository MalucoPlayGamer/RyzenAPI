-- Lua provided by RyzenAPI
-- Game: AppID 29140

-- MAIN APPLICATION
addappid(29140)
-- Game: addappid(29140)

-- MAIN APP DEPOTS / PACKAGES
addappid(29141, 1, "1fbcb17202308e1133edbff6825a2c42b22df416d163c02d07eb3a28442598a1")
