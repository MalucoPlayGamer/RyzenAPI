-- 4985140's Lua and Manifest Created by Hubcap Manifest
-- Football Fictional World Simulator
-- Created: August 06, 2026 at 11:25:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4985140) -- Football Fictional World Simulator
-- MAIN APP DEPOTS
addappid(4985141, 1, "7b47bc835b6a5a40414dc31cc9fbd097af3112a4e77720659c4c99f751a9ed48") -- Depot 4985141
setManifestid(4985141, "2981100039590281123", 178247912)