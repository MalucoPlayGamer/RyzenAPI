-- Lua provided by RyzenAPI
-- Game: Football Fictional World Simulator

-- MAIN APPLICATION
addappid(4985140) -- Football Fictional World Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4985141, 1, "7b47bc835b6a5a40414dc31cc9fbd097af3112a4e77720659c4c99f751a9ed48") -- Depot 4985141

