-- Lua provided by RyzenAPI 
-- Game: South of the Circle
addappid(1811040)
addappid(1811041, 1, "9ec77ca2f542df5f3095128145283904b053d3a140f9353f6b20df6efd90ff65")
addappid(2052820, 0, "1f5c1bee1380a9c561ce2831c907bfa84470e1faa7c93d372b0a6c2889ce1bdf")
