-- Lua provided by RyzenAPI
-- Game: 灾厄黑龙与谎言公主

-- MAIN APPLICATION
addappid(2850190)
-- Game: addappid(2850190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850191, 1, "4c9f8bc1783a2ec6740549f66edfc201abaafe316ae3bc288061425911be20fb")
