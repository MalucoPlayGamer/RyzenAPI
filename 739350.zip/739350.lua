-- Lua provided by RyzenAPI
-- Game: 739350

-- MAIN APPLICATION
addappid(739350)
-- Game: addappid(739350)

-- MAIN APP DEPOTS / PACKAGES
addappid(739351, 1, "5c438235595766b4d0b11d4a22095ea9ef532aaaae8a22c8bfe64abce5c886f7")
