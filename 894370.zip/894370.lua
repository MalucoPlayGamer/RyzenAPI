-- Lua provided by SkyAPI 
-- Game: AppID 894370
addappid(894370)
addappid(894371, 1, "449f840133a74d8f7a1c7f63ecaf927716ce265caf862cb9ea54d3c4f94e3cd3")
