-- Lua provided by RyzenAPI
-- Game: AppID 612790

-- MAIN APPLICATION
addappid(612790)

-- MAIN APP DEPOTS / PACKAGES
addappid(612791, 1, "dc527508f9d9945bf890e911828ddf5615a4841796647b1c9ac4250d8a48e750")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
