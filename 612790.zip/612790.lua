-- Lua provided by SkyAPI 
-- Game: AppID 612790
addappid(612790)
addappid(612791, 1, "dc527508f9d9945bf890e911828ddf5615a4841796647b1c9ac4250d8a48e750")
