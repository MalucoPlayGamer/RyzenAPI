-- Lua provided by RyzenAPI
-- Game: That Village

-- MAIN APPLICATION
addappid(3405020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405021, 1, "3a68ac6e036d5356dd24e7487ec4d2d44ed74510136faa3552203bded12d5b3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
