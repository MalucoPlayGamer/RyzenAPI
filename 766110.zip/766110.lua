-- Lua provided by RyzenAPI
-- Game: Félix VR

-- MAIN APPLICATION
addappid(766110)

-- MAIN APP DEPOTS / PACKAGES
addappid(766111, 1, "71310a15df2cae719e5e57a560050fcffca1edaf972e5aa5ede733d7f5e08c62")
