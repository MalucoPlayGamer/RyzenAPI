-- Lua provided by RyzenAPI
-- Game: 13260

-- MAIN APPLICATION
addappid(13260)
-- Game: addappid(13260)

-- MAIN APP DEPOTS / PACKAGES
addappid(13261, 1, "9f740592339a59a2dc1503a9671323ef5cbcf9bfe7b563d971e7238d12f0ce8d")
