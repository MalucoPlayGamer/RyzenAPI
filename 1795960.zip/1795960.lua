-- Lua provided by SkyAPI 
-- Game: AppID 1795960
addappid(1795960)
addappid(1795961, 1, "0cfc5d0eae66a42cf4314736f2d53cdf7e0f9946409d863ed4ddbdaa4dc0c02f")
addappid(1837310, 0, "521dd23bea1c2a28aa0eae4b8a795c026bddbff1e3dad4d3193e56a055f2d339")
