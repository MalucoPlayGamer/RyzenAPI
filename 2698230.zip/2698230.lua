-- Lua provided by RyzenAPI
-- Game: Karin's Instruction

-- MAIN APPLICATION
addappid(2698230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2698231, 1, "0c626efd397c7adc4e2bc44c5b2fb21318210b45317dfb72b970fba83b1ddee4")

