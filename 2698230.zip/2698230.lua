-- Lua provided by RyzenAPI
-- Game: 2698230

-- MAIN APPLICATION
addappid(2698230)
-- Game: addappid(2698230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698231, 1, "0c626efd397c7adc4e2bc44c5b2fb21318210b45317dfb72b970fba83b1ddee4")
