-- Lua provided by RyzenAPI
-- Game: AppID 285670

-- MAIN APPLICATION
addappid(285670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(285671, 1, "b551b18ff8feb8452c8f9d03e1690b9647c810c8362b975d7d882baa90ff14c7")

