-- Lua provided by RyzenAPI
-- Game: 222980

-- MAIN APPLICATION
addappid(222980)
addappid(229002)
-- Game: addappid(222980)

-- MAIN APP DEPOTS / PACKAGES
addappid(222981, 1, "172fb67b1048bcba6ea4c5ebeed5b3e5f0e0c5ebd5f25dd2fc05ff7d7ca31eff")
