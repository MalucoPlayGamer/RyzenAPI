-- Lua provided by RyzenAPI
-- Game: Supesu

-- MAIN APPLICATION
addappid(879280)
-- Game: addappid(879280)

-- MAIN APP DEPOTS / PACKAGES
addappid(879281, 1, "33b25b36d91f5067b876cfb70b052d5be2b34ed74b38c2357e68f7987c48554b")
