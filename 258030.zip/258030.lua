-- Lua provided by RyzenAPI
-- Game: EARTHLOCK: Festival of Magic

-- MAIN APPLICATION
addappid(258030)

-- MAIN APP DEPOTS / PACKAGES
addappid(258031, 1, "ca73514a15eda9d1b1d9fe32ebd386a159b60121361859d67c137553c784698b")
addappid(258032, 1, "a89617e266bea824e2c0f9412ecffa800eb5ec2141fa9add845214904ab332ce")

