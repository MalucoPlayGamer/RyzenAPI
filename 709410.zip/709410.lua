-- Lua provided by SkyAPI 
-- Game: AZURA
addappid(709410)
addappid(709411, 1, "dd7f27d2dd87584c29d30d2227b571500725c9392e492fcf1173416ae9d57bab")
