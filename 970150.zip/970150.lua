-- Lua provided by RyzenAPI
-- Game: 970150

-- MAIN APPLICATION
addappid(970150)
addappid(973280)
-- Game: addappid(970150)

-- MAIN APP DEPOTS / PACKAGES
addappid(970151, 1, "6b3f0412bab3a729744706a572009e25d2102b7703e8c76d9a71e0ab955c5df8")
