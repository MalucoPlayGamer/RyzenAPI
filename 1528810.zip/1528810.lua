-- Lua provided by SkyAPI 
-- Game: Exodus Borealis
addappid(1528810)
addappid(1528811, 1, "0bca1bbd4cf296543d03975dd17142002c48928fc750fad820275fce4ee200f5")
addappid(1528812, 1, "7e7af62022ad4bdba867e21871045928ab77dc2c4c73992a466ea8a860c659d9")
