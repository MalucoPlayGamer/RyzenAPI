-- Lua provided by RyzenAPI
-- Game: addappid(1677670)

-- MAIN APPLICATION
addappid(1677670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677671, 1, "5722ba4fa1319f6c0bc3b0c60f67fd7ad5c60b8975604d1e2b52025bdfdc0843")
