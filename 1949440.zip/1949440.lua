-- Lua provided by RyzenAPI
-- Game: Burrow of the Fallen Bear: A Gay Furry Visual Novel

-- MAIN APPLICATION
addappid(1949440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949441,0,"487cb78cf4c1bcf96749d3343d4aa4d1524a7bd8396ca524e59b67229ff48b20")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1959300)
addappid(2065760)
addappid(2065761)
