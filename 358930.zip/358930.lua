-- Lua provided by RyzenAPI
-- Game: Game: Star Control III

-- MAIN APPLICATION
addappid(358930)
-- Game: addappid(358930)

-- MAIN APP DEPOTS / PACKAGES
addappid(358931, 1, "895ec5667464a81d48c09739529ab65413a4acf564d145631044e70161431769")
