-- Lua provided by RyzenAPI 
-- Game: AppID 3005370
addappid(3005370)
addappid(3005371, 1, "a7b047a4e742a2413a0aaee75c012dbd1a1ec15f1132b11fd3860a14c008db01")
