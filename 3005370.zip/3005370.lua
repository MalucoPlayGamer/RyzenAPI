-- Lua provided by RyzenAPI
-- Game: 3005370

-- MAIN APPLICATION
addappid(3005370)
-- Game: addappid(3005370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005371, 1, "a7b047a4e742a2413a0aaee75c012dbd1a1ec15f1132b11fd3860a14c008db01")
