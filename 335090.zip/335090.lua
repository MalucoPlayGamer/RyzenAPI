-- Lua provided by RyzenAPI
-- Game: Goscurry

-- MAIN APPLICATION
addappid(335090)
-- Game: addappid(335090)

-- MAIN APP DEPOTS / PACKAGES
addappid(335091, 1, "f940d7cbbc4186ef377341f291b109fdd5749334697f83070b0407d85a70fa3a")
