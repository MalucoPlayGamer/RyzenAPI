-- Lua provided by RyzenAPI
-- Game: Tactics & Strategy Master:Joan of Arc

-- MAIN APPLICATION
addappid(820760)

-- MAIN APP DEPOTS / PACKAGES
addappid(820761, 1, "817c6c8f2b6f74925749400a57b1bb966f5041500ee5335e6672341e147a0a39")

