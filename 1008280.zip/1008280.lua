-- Lua provided by SkyAPI 
-- Game: AppID 1008280
addappid(1008280)
addappid(1008281, 1, "d38aa1ebb6c2990e586ed51a0084687c50940caacba51726cc0c9db0a578046b")
