-- Lua provided by RyzenAPI
-- Game: 勇者と魔法使いとおとぎの絵本  / Fairy Picturebook of Hero and Sorceress

-- MAIN APPLICATION
addappid(1008280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008281, 1, "d38aa1ebb6c2990e586ed51a0084687c50940caacba51726cc0c9db0a578046b")
