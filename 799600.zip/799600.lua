-- Lua provided by RyzenAPI
-- Game: Cosmoteer: Starship Architect & Commander

-- MAIN APPLICATION
addappid(799600)
-- Game: addappid(799600)

-- MAIN APP DEPOTS / PACKAGES
addappid(799601, 1, "c7c1275eba141988dcc75746510071b5a1b826a01cf6c0f974b03f07d89652d4")
addappid(799602, 1, "e15c9b74effae3f79409f360b71bf5b110cc1561e23ce2515459dee9e4569cf4")
addappid(799603, 1, "957e695d970db86795eea257e7b86217684794eaeabba1ac8ba96167dc412bfe")
