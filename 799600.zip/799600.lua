-- Lua provided by RyzenAPI
-- Game: Cosmoteer: Starship Architect & Commander

-- MAIN APPLICATION
addappid(799600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(799601, 1, "c7c1275eba141988dcc75746510071b5a1b826a01cf6c0f974b03f07d89652d4")
addappid(799602, 1, "e15c9b74effae3f79409f360b71bf5b110cc1561e23ce2515459dee9e4569cf4")
addappid(799603, 1, "957e695d970db86795eea257e7b86217684794eaeabba1ac8ba96167dc412bfe")

