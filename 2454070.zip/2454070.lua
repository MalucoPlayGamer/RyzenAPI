-- Lua provided by RyzenAPI
-- Game: Desolated District

-- MAIN APPLICATION
addappid(2454070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454071, 1, "9b3e811ef44e4da7fa628a182c3e1d3802c48272d12be7202bf1797e7bc070be")

