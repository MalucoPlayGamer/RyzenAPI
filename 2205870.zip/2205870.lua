-- Lua provided by RyzenAPI
-- Game: Inner Abyss

-- MAIN APPLICATION
addappid(2205870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205871, 1, "2f039b43b1afa627fd5591963cb861c49e7b2258030c83045fabde18333edbb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
