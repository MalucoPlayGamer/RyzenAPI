-- Lua provided by RyzenAPI
-- Game: addappid(2205870)

-- MAIN APPLICATION
addappid(2205870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205871, 1, "2f039b43b1afa627fd5591963cb861c49e7b2258030c83045fabde18333edbb3")
