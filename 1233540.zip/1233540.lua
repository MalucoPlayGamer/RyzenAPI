-- Lua provided by RyzenAPI
-- Game: How Buddy’s parents met - a jigsaw puzzle tale

-- MAIN APPLICATION
addappid(1233540)
-- Game: addappid(1233540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233542,0,"85a1c9cee600f7b0ebe7b1a84fea83cfa79ed5ee5fa82fe587051abcf13a6987")
addappid(1233543,0,"b1a111b86cf846c0297f5a2a2cacc0da663821645b0e854591981220ccf0c138")
