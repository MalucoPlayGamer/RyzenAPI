-- Lua provided by RyzenAPI
-- Game: Game: MagicMic - Real-time Voice Changer

-- MAIN APPLICATION
addappid(2620350)
-- Game: addappid(2620350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620351, 1, "f953787981888845421162793fa81e45995fb94c99f4729f11f004ad6bdf84e4")
