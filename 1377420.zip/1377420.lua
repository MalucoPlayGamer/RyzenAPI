-- Lua provided by RyzenAPI
-- Game: Baking Bustle

-- MAIN APPLICATION
addappid(1377420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377421, 1, "508ebb72c88dbf5d4605d91955669873c6fd9be4c416d32b0eb0760710c22fb1")
addappid(1377422, 1, "83d3bd841135b2c77daab3d8a5943c54c0fb95d0296ef024358f33614fa470ee")

