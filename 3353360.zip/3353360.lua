-- Lua provided by RyzenAPI
-- Game: 3353360

-- MAIN APPLICATION
addappid(3353360)
-- Game: addappid(3353360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353361, 1, "d2ffd6fecf2c56c161b37eb8eb364edd565bdfc896201e4baa4a4bafb602fe80")
