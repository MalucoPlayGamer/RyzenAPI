-- Lua provided by RyzenAPI
-- Game: 361070

-- MAIN APPLICATION
addappid(229002)
addappid(229012)
addappid(361070)
addappid(361072)

-- MAIN APP DEPOTS / PACKAGES
addappid(350621,0,"302a3334a187ec0154ae4da0a94763ebf54d4c3af29e8cf76aa72127ded07d2f")
addappid(350622,0,"1dd33a7b67739b0c223d905929e111b280df829accc8ba4a1e7f8b19e3f3f71f")

