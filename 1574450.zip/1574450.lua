-- Lua provided by RyzenAPI
-- Game: O.V.N.I. Abduction

-- MAIN APPLICATION
addappid(1574450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574451, 1, "bd5d9b0b5396cc9e80bf2702b16f72bc17b1cb1b7095848e6f6d09e13b8bd95e")

