-- Lua provided by RyzenAPI 
-- Game: AppID 1182470
addappid(1182470)
addappid(1182471, 1, "b077bcc84c40b36ee5eb0c79c9757484abff3e2885ef49b31ffdc04ff8960192")
addappid(1182473, 1, "8e974653123253784f9535613d4bfb27ee1ffd1419dbf61739b7634e00a1d8c9")
