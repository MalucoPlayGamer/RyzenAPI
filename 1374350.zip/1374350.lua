-- Lua provided by RyzenAPI
-- Game: Tiny Troopers: Global Ops

-- MAIN APPLICATION
addappid(1374350)
addappid(2237290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374351, 1, "c95ba5b1943da1d6dbebad327ebb02008eb3e6d9d29c8afb959f2ea7203e6cea")
