-- Lua provided by SkyAPI 
-- Game: NBA 2K25
addappid(2878980)
addappid(2878981, 1, "df09d8fa7b88da65f6fdce275ab09b85e5c12731cad10c147745c7501acb1f14")
addappid(3107390, 0, "a86b0e16a6d6f9946fc2671411ad8653123970931a5e289b242e3b1cf563381f")
