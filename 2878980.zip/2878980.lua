-- Lua provided by RyzenAPI
-- Game: NBA 2K25

-- MAIN APPLICATION
addappid(2878980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878981, 1, "df09d8fa7b88da65f6fdce275ab09b85e5c12731cad10c147745c7501acb1f14")
addappid(3107390, 0, "a86b0e16a6d6f9946fc2671411ad8653123970931a5e289b242e3b1cf563381f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2974820)
addappid(2974830)
addappid(2974840)
addappid(2974850)
addappid(2974860)
addappid(2974870)
addappid(2974880)
addappid(2974890)
addappid(2974900)
addappid(2974910)
addappid(2974920)
addappid(2974930)
addappid(2974940)
addappid(2974950)
addappid(2974960)
addappid(2974970)
addappid(2974980)
addappid(2974990)
addappid(2975000)
addappid(2975010)
addappid(2975020)
addappid(2982770)
addappid(2982780)
addappid(2982790)
addappid(3261610)
addappid(3261620)
addappid(3310490)
addappid(3310500)
addappid(3312950)
addappid(3312960)
addappid(3312970)
addappid(3312980)
addappid(3312990)
addappid(3313000)
addappid(3313010)
addappid(3313020)
addappid(3313030)
addappid(3313040)
addappid(3313050)
addappid(3313060)
