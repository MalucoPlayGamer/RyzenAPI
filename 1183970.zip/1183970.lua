-- Lua provided by RyzenAPI
-- Game: Hentai Nazi

-- MAIN APPLICATION
addappid(1183970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183971, 1, "350091e5c5f7fa63a18051501108d05eec89b9387202ce5ff3c2098649f81df2")

