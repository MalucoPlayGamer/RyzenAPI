-- Lua provided by SkyAPI 
-- Game: Formless Adventure
addappid(666260)
addappid(666261, 1, "db1329c411c66b4a0a32f6c13c2eb8eca21e903b09e9700628859f8e5c6cb9e3")
