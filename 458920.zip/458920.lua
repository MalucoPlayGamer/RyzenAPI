-- Lua provided by SkyAPI 
-- Game: Carnival Games® VR
addappid(458920)
addappid(458921, 1, "6ce30d7365fabb507aec6baf7721005ee9e5624934b310341f50fabe62a263a3")
addappid(458922, 1, "f5875b3a0d718ac2cdf9f8edb2e68281e5790c8cc68279eda4fa37c3b5fe249c")
addappid(631690)
