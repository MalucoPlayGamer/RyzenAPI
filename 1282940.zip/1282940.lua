-- Lua provided by RyzenAPI
-- Game: DesktopMMD

-- MAIN APPLICATION
addappid(1282940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282941, 1, "afd7654ceed1470a852505bf07e6510e0e6137e6d9e52ef19adfad222c8ee6bd")
