-- Lua provided by RyzenAPI
-- Game: Riddles of Fate: Memento Mori Collector's Edition

-- MAIN APPLICATION
addappid(796060)

-- MAIN APP DEPOTS / PACKAGES
addappid(796061, 1, "49d1832bbc6cb274c6fd687e662f45beddf693d3f8192f65e0fa6f5de2b0d2d5")
