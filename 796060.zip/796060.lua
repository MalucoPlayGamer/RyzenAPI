-- Lua provided by SkyAPI 
-- Game: Riddles of Fate: Memento Mori Collector's Edition
addappid(796060)
addappid(796061, 1, "49d1832bbc6cb274c6fd687e662f45beddf693d3f8192f65e0fa6f5de2b0d2d5")
