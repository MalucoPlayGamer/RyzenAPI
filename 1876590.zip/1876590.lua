-- Lua provided by RyzenAPI
-- Game: I Am Your Beast

-- MAIN APPLICATION
addappid(1876590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876591, 1, "8343b3e91d260eaa4144e4c3913dc72e52e9ea23872bc35479ea3c0db12b1df6")

