-- Lua provided by RyzenAPI
-- Game: 331190

-- MAIN APPLICATION
addappid(331190)
-- Game: addappid(331190)

-- MAIN APP DEPOTS / PACKAGES
addappid(331191, 1, "510124bcc5ad7a55e7e46a21036cdd1cfe6f950c7047e2f62b7a926e57cbe7ec")
addappid(331192, 1, "ce9b836d6b465ab5ba45974dc5ebfe59f5d5c2c9516b57993a2ea52404f2a377")
