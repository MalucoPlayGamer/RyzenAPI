-- Lua provided by RyzenAPI
-- Game: addappid(377670)

-- MAIN APPLICATION
addappid(377670)

-- MAIN APP DEPOTS / PACKAGES
addappid(377671, 1, "e7040bf60ebdd813e885dab455c2fc1cda06a081dd2db9fc838620cc67720748")
addappid(377672, 1, "ceb5f24426e9a7d033f042e4d0129769ddaa26637cef4bc0149182a7291bcaed")
addappid(377673, 1, "f01ea3f65b1d6eb5840afd896343fe1ccd5c3c19b2ff23cb98ccba1b3e7255a3")
addappid(417260, 0, "d43fb87af84e404e3a90ea93b21bb70b1d7169cde1285e2385a13d1473387229")
