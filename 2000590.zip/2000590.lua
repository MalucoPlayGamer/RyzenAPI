-- Lua provided by RyzenAPI
-- Game: Alvo VR

-- MAIN APPLICATION
addappid(2000590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000591, 1, "1d5e28d260cabd22ed878fb158ff1a2067c5c111f22cee5278165593277992bc")
