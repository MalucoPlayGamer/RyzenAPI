-- Lua provided by RyzenAPI
-- Game: Pneuma: Breath of Life

-- MAIN APPLICATION
addappid(347440)
addappid(349050)

-- MAIN APP DEPOTS / PACKAGES
addappid(347441, 1, "10496c72203180adf7160501d7b69c384ce1a3e6e8b9cf638da3bb8ee44d482a")

