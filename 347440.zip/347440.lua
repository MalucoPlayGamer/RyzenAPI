-- Lua provided by RyzenAPI
-- Game: Pneuma: Breath of Life

-- MAIN APPLICATION
addappid(347440)
addappid(349050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(347441, 1, "10496c72203180adf7160501d7b69c384ce1a3e6e8b9cf638da3bb8ee44d482a")

