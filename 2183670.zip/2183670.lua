-- Lua provided by RyzenAPI
-- Game: Hotel Galactic

-- MAIN APPLICATION
addappid(2183670)
addappid(3860260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183671,0,"ceefb359e132c750d33edaef6cfd205fffdea95d608acab6ace313a8025e01d7")
addappid(3860270,0,"3c62805369151fb9849bb2b170b6de030b11b6e135db59696effc053151f188d")

