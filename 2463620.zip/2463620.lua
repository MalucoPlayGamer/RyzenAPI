-- Lua provided by RyzenAPI
-- Game: 2463620

-- MAIN APPLICATION
addappid(2463620)
-- Game: addappid(2463620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463621, 1, "afc4266296f920dad2d1de47710439808ce55edf96d67ad439cf729604870f2b")
