-- Lua provided by SkyAPI 
-- Game: OZMAFIA!!
addappid(303290)
addappid(303291, 1, "60ba38c8b543128524c16037b10c43e86f5a13a09d71b1d1897aecc46f3ee35e")
