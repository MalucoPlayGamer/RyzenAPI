-- Lua provided by RyzenAPI
-- Game: Game: OZMAFIA!!

-- MAIN APPLICATION
addappid(303290)
-- Game: addappid(303290)

-- MAIN APP DEPOTS / PACKAGES
addappid(303291, 1, "60ba38c8b543128524c16037b10c43e86f5a13a09d71b1d1897aecc46f3ee35e")
