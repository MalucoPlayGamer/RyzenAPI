-- Lua provided by SkyAPI 
-- Game: 勇者联盟星耀传说
addappid(2144180)
addappid(2144181, 1, "3520a205937f83058b30f80adb4de9281a60bb755bf06bf97cfc96a6d196df58")
