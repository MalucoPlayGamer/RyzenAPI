-- Lua provided by SkyAPI 
-- Game: SideQuest Hunters
addappid(3209700)
addappid(3209701, 1, "d41451f7c272859ebbf2b58b5f4055cd7d85fa48f9ba1361c8c7035b5485e381")
