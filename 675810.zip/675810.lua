-- Lua provided by RyzenAPI
-- Game: AppID 675810

-- MAIN APPLICATION
addappid(675810)

-- MAIN APP DEPOTS / PACKAGES
addappid(675811, 1, "2b2cd4fd0a688139953129458d5db27f0b7405e3f5ea02fb8ed1caa351d44c1c")
