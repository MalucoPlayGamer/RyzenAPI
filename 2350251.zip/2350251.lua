-- Lua provided by RyzenAPI
-- Game: addappid(2350251)

-- MAIN APPLICATION
addappid(2350251)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350251,0,"5bc9fff3565864e677f5f53baf71e45fea840384a3f9c969c5984fc55ef3947f")
