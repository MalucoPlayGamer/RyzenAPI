-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! At The Disco - "Dancing’s Not A Crime"

-- MAIN APPLICATION
addappid(2350251)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350251,0,"5bc9fff3565864e677f5f53baf71e45fea840384a3f9c969c5984fc55ef3947f")
