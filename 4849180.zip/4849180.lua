-- 4849180's Lua and Manifest Created by Hubcap Manifest
-- The Day of Revenge
-- Created: August 07, 2026 at 11:09:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4849180) -- The Day of Revenge
addtoken(4849180, "9367972947007449212")
-- MAIN APP DEPOTS
addappid(4849182, 1, "9e115f43e66bc797ea58a1be4f431ec1ae3829fa61ebad778280a7fe8716a84d") -- Depot 4849182
setManifestid(4849182, "1347177283730696230", 135280160)