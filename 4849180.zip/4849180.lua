-- Lua provided by RyzenAPI
-- Game: The Day of Revenge

-- MAIN APPLICATION
addappid(4849180) -- The Day of Revenge

-- MAIN APP DEPOTS / PACKAGES
addappid(4849182, 1, "9e115f43e66bc797ea58a1be4f431ec1ae3829fa61ebad778280a7fe8716a84d") -- Depot 4849182
addtoken(4849180, "9367972947007449212")

