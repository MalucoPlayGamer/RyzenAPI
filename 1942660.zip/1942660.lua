-- Lua provided by RyzenAPI
-- Game: WWE 2K23

-- MAIN APPLICATION
addappid(1942660)
addappid(2222900)
addappid(2222901)
addappid(2222902)
addappid(2222903)
addappid(2222904)
addappid(2230150)
addappid(2230151)
addappid(2261580)
addappid(2386990)
addappid(2386991)
addappid(2386992)
addappid(2386993)
addappid(2469960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1942661, 1, "9d1b0097a379bec2df245db6cf282f44f4b7d1760a07a012f664eb1acb888686")

