-- Lua provided by RyzenAPI
-- Game: Game: WWE 2K23

-- MAIN APPLICATION
addappid(1942660)
-- Game: addappid(1942660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942661, 1, "9d1b0097a379bec2df245db6cf282f44f4b7d1760a07a012f664eb1acb888686")
