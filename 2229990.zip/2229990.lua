-- Lua provided by RyzenAPI 
-- Game: DARK NIGHT WITH FLOPPA
addappid(2229990)
addappid(2229991, 1, "a3064d822e7b3994fdb007ef4a248374a5a08e0adecd8183bf67ba1a686f9590")
