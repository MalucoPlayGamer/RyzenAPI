-- Lua provided by RyzenAPI 
-- Game: Spin Forward
addappid(3343940)
addappid(3343941, 1, "0e2c80a969767b2164a51f99149a0c35bc93036a6a718050c6dbcc65186ee962")
