-- Lua provided by RyzenAPI
-- Game: Game: Spin Forward

-- MAIN APPLICATION
addappid(3343940)
-- Game: addappid(3343940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343941, 1, "0e2c80a969767b2164a51f99149a0c35bc93036a6a718050c6dbcc65186ee962")
