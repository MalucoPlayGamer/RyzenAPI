-- Lua provided by RyzenAPI
-- Game: Ashen Empires

-- MAIN APPLICATION
addappid(937380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(937381, 1, "a4b8c5c66811e6c4f59ee9b67b38e19fdf0980be30765f254e869b1a631c0509")

