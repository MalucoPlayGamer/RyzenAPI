-- Lua provided by RyzenAPI
-- Game: AppID 787150

-- MAIN APPLICATION
addappid(787150)

-- MAIN APP DEPOTS / PACKAGES
addappid(787151, 1, "f43a8de70923126cae80e71b27b1ecb69eaecbffbf1e9ba0937698b83593be4b")

