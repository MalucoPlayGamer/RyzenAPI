-- Lua provided by RyzenAPI
-- Game: Game: AppID 3088120

-- MAIN APPLICATION
addappid(3088120)
-- Game: addappid(3088120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088121, 1, "a86ebceccc9423f78cdb0a16c2722ce5d6302d1c170007d734e8a60898d4c2ff")
