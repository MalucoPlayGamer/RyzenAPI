-- Lua provided by RyzenAPI
-- Game: Burglin' Gnomes

-- MAIN APPLICATION
addappid(3844970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3844971, 1, "6d3197ad9feb781dfe4dfd67f09fb9e834c9bbb158108a27c31e31d3001ec326")
