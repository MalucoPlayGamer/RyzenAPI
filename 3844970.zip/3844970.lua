-- Lua provided by RyzenAPI
-- Game: Burglin' Gnomes

-- MAIN APPLICATION
addappid(3844970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3844971, 1, "6d3197ad9feb781dfe4dfd67f09fb9e834c9bbb158108a27c31e31d3001ec326")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
