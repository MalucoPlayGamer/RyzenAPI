-- Lua provided by RyzenAPI
-- Game: TitTok Kitty

-- MAIN APPLICATION
addappid(2010320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010321, 1, "ee224bcaf810a7159e53e1150659bac4d3cc228df8e9830a854dc7319ad03baa")
