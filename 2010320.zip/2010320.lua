-- Lua provided by SkyAPI 
-- Game: TitTok Kitty
addappid(2010320)
addappid(2010321, 1, "ee224bcaf810a7159e53e1150659bac4d3cc228df8e9830a854dc7319ad03baa")
