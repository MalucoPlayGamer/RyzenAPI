-- Lua provided by RyzenAPI
-- Game: AppID 527100

-- MAIN APPLICATION
addappid(527100)
addappid(638541)
addappid(903810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(527101, 1, "31cdd603eb8d5711eece7e5604d1c692bb270a192dadf77e479179977c4600ae")
addappid(806190, 0, "c2c8616a5465eca52e44891132eea8a2668392423bd2dd5d6551f1678603d14f")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

