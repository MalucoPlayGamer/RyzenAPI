-- Lua provided by RyzenAPI
-- Game: My Life In A Monster Girl Paradise

-- MAIN APPLICATION
addappid(2736290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736291, 1, "91228ff8b2146bb6ee9111c3c89af5d8a49187e1383c091c5516d3e7e441acd6")

