-- Lua provided by RyzenAPI
-- Game: 3350800

-- MAIN APPLICATION
addappid(3350800)
-- Game: addappid(3350800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350801, 1, "c4e98b7f07fcc2bfade49881645aa44a9c7454c64a3877768ce326d8694945e4")
