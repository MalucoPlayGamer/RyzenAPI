-- Lua provided by RyzenAPI
-- Game: Average Routine

-- MAIN APPLICATION
addappid(4007150)
addappid(4239780)
addappid(4784050)

