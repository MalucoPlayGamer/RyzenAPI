-- Lua provided by RyzenAPI
-- Game: Average Routine

-- MAIN APPLICATION
addappid(4007150)

