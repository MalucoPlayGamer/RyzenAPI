-- Lua provided by RyzenAPI
-- Game: Average Routine

-- MAIN APPLICATION
addappid(4007150)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4239780)
addappid(4784050)
