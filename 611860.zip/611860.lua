-- Lua provided by RyzenAPI
-- Game: Game: AppID 611860

-- MAIN APPLICATION
addappid(611860)
addappid(965980)
-- Game: addappid(611860)

-- MAIN APP DEPOTS / PACKAGES
addappid(611861, 1, "2f01ef4c8271600efb5a7917f2010e0764039a08c932050d572b66210a56d9e7")
