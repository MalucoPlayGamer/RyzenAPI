-- Lua provided by RyzenAPI 
-- Game: Ancient Scroll
addappid(2942670)
addappid(2942671, 1, "31e9f2c9499fd22afc1f10219c446aa0536b23c2a40cf22fa84774dd5ae81402")
