-- Lua provided by RyzenAPI
-- Game: Without Within 3 (初衷)

-- MAIN APPLICATION
addappid(676130)
-- Game: addappid(676130)

-- MAIN APP DEPOTS / PACKAGES
addappid(676131, 1, "8a139e9b24721636cfaaebc553acecba571d2996a79fb2f4ca1c585b57cd47cb")
addappid(676151, 0, "8bdb42dd7b0e3a6b001b33d2b6ccdf6ca17a5accea35a2dd1a52fc16e81dfbee")
