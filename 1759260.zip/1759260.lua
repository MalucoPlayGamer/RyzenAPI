-- Lua provided by SkyAPI 
-- Game: Dungescape!
addappid(1759260)
addappid(1759261, 1, "e4601db7a3f0ae106005e0e15f14104f0635217ce0469f487696d4aab7e33b99")
