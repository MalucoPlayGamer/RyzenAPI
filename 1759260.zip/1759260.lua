-- Lua provided by RyzenAPI
-- Game: Game: Dungescape!

-- MAIN APPLICATION
addappid(1759260)
-- Game: addappid(1759260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759261, 1, "e4601db7a3f0ae106005e0e15f14104f0635217ce0469f487696d4aab7e33b99")
