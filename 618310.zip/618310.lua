-- Lua provided by RyzenAPI
-- Game: Game: AFTERGRINDER

-- MAIN APPLICATION
addappid(618310)
-- Game: addappid(618310)

-- MAIN APP DEPOTS / PACKAGES
addappid(618311, 1, "00933789dbbeae5f1185985f3d96cf114c7932735d582ed58627cb7e37eaadb6")
