-- Lua provided by RyzenAPI 
-- Game: Umfend
addappid(779090)
addappid(779091, 1, "1da8a0fd642776186a95248e68f4c83849dd5fc0e7181ea4e1d35531addf96dc")
