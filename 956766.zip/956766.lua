-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956766)
-- Game: addappid(956766)

-- MAIN APP DEPOTS / PACKAGES
addappid(956766,0,"8c5179176440813b88541dbe01713760a3aca81c43e32955166d149a29fc9629")
