-- Lua provided by RyzenAPI
-- Game: 3004150

-- MAIN APPLICATION
addappid(3004150)
-- Game: addappid(3004150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004151, 1, "3689749d24679c8d69c484aaa9e78b580ef040cc589ae317c8d5a77dff304ad3")
