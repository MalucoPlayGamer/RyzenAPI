-- Lua provided by RyzenAPI
-- Game: Game: EXIT 2

-- MAIN APPLICATION
addappid(1816880)
-- Game: addappid(1816880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816881, 1, "3046945af2a6e1d1dd52332610ea89b4b0d62fabd82dd7f38fabdab8933186b5")
