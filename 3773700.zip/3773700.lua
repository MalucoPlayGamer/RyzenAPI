-- Lua provided by RyzenAPI
-- Game: addappid(3773700)

-- MAIN APPLICATION
addappid(3773700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773701, 1, "5f2f982ccd592ddf59d6633fe857833daa20ee0ae7cf484e3f106751bd8c3efd")
