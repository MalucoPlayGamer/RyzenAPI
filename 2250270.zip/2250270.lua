-- Lua provided by RyzenAPI
-- Game: Revival Quest

-- MAIN APPLICATION
addappid(2250270)
-- Game: addappid(2250270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250271, 1, "c4820a9f356ab8a417e372a10a0862ee49896f4dd783a827fb7856832ff7eb2c")
