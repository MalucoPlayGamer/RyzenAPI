-- Lua provided by RyzenAPI
-- Game: Cyber Runner

-- MAIN APPLICATION
addappid(1853080)
-- Game: addappid(1853080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853081, 1, "8be940a33180242849a0f6573b3e43496e102b47da06b0860cadec1fa3432400")
