-- Lua provided by RyzenAPI
-- Game: Cyber Runner

-- MAIN APPLICATION
addappid(1853080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1853081, 1, "8be940a33180242849a0f6573b3e43496e102b47da06b0860cadec1fa3432400")

