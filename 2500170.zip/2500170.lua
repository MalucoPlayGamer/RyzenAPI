-- Lua provided by RyzenAPI 
-- Game: Blasphemous 2 - OST
addappid(2500170)
addappid(2500171, 1, "b9d3fa57528bb80453d54ddd9ac898b8d48e37176b1eaad3e8474b7b738c533d")
addappid(2500172, 1, "ef49e4da832ef9aace023b93a7e0bd9129f58b731032bc2422e64e41a2505370")
