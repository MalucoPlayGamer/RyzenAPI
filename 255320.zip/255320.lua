-- Lua provided by SkyAPI 
-- Game: Edna & Harvey: The Breakout
addappid(255320)
addappid(255321, 1, "51c5787bb48e45fedcf115e727a8f969f25a7ae6550a937a3e234f279e61506c")
addappid(255322, 1, "cb7c6b374539a26582c1f2037399bd893307421a192e1eab998fe76f816f2b59")
addappid(255323, 1, "4ba899b17298ddc8755e869109ed0d9bcc5ffd441836eaed21868e56f8617638")
