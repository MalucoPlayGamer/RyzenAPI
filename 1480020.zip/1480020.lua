-- Lua provided by RyzenAPI
-- Game: 1480020

-- MAIN APPLICATION
addappid(1480020)
-- Game: addappid(1480020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480021, 1, "9e2f74ec631c914dad2afb5088e67bd06afadbfefbb1dc8a1799346b0b92325b")
