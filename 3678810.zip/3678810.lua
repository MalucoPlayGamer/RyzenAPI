-- Lua provided by RyzenAPI
-- Game: Game: Reflection Of Sin

-- MAIN APPLICATION
addappid(3678810)
-- Game: addappid(3678810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3678811, 1, "357019e82cc3d09dc5828a0b50884e115a5285751228b2032f55abc31466d250")
