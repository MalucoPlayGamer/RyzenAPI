-- Lua provided by RyzenAPI
-- Game: Reflection Of Sin

-- MAIN APPLICATION
addappid(3678810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3678811, 1, "357019e82cc3d09dc5828a0b50884e115a5285751228b2032f55abc31466d250")

