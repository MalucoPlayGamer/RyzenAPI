-- Lua provided by RyzenAPI
-- Game: Lanternium

-- MAIN APPLICATION
addappid(618210)
-- Game: addappid(618210)

-- MAIN APP DEPOTS / PACKAGES
addappid(618211, 1, "e0735c5bbb7d59a9ecffa2c57f7018906d3b8669ad76bdc15cc93936a6689ac1")
addappid(618212, 1, "7816793f0004db63b69c7d7a389e642e3a9e01073850856490c3c2ef2374671c")
addappid(618213, 1, "d8e9c3e569c877270b562e081e82b44d53ce95707a5bfe7b9c5a31a8da31de6b")
