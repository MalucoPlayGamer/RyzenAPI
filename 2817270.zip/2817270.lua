-- 2817270's Lua and Manifest Created by Hubcap Manifest
-- Fountain
-- Created: August 20, 2026 at 23:48:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2817270) -- Fountain
-- MAIN APP DEPOTS
addappid(2817271, 1, "ac832f8e8176f36fdfe670ff6526cc4e792737c252b82de4b28d3f7cfac65a04") -- Depot 2817271
setManifestid(2817271, "3903389425699330194", 232343256)