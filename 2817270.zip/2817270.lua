-- Lua provided by RyzenAPI
-- Game: Fountain

-- MAIN APPLICATION
addappid(2817270) -- Fountain

-- MAIN APP DEPOTS / PACKAGES
addappid(2817271, 1, "ac832f8e8176f36fdfe670ff6526cc4e792737c252b82de4b28d3f7cfac65a04") -- Depot 2817271

