-- Lua provided by RyzenAPI
-- Game: 武者斗天师

-- MAIN APPLICATION
addappid(1689750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1689751, 1, "0bdb0346b4811118ca99b7e35f8044b698664260ad22791223584e162f50c555")

