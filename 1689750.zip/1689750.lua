-- Lua provided by RyzenAPI
-- Game: Game: 武者斗天师

-- MAIN APPLICATION
addappid(1689750)
-- Game: addappid(1689750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689751, 1, "0bdb0346b4811118ca99b7e35f8044b698664260ad22791223584e162f50c555")
