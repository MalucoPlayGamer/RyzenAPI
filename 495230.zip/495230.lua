-- Lua provided by SkyAPI 
-- Game: Hypnorain
addappid(495230)
addappid(495231, 1, "beb1aee9651d6afef5a1efa37777c72a5d624a2dc3976279eb299b85846ed3b3")
