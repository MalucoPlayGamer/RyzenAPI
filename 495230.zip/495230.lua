-- Lua provided by RyzenAPI
-- Game: Game: Hypnorain

-- MAIN APPLICATION
addappid(495230)
-- Game: addappid(495230)

-- MAIN APP DEPOTS / PACKAGES
addappid(495231, 1, "beb1aee9651d6afef5a1efa37777c72a5d624a2dc3976279eb299b85846ed3b3")
