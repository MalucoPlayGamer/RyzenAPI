-- Lua provided by SkyAPI 
-- Game: My Lovely Daughter
addappid(580170)
addappid(580171, 1, "941dffc83c78c5187b363a41ccdd15d251258a6525e7ff068b90a024a428f953")
addappid(580172, 1, "3587cbb8f42be0fdfddbce416f5b976491cfb3fad4924d6070b3758149504451")
addappid(580173, 1, "f0b975ac35f788c6c0e38143b6993943d16aa0bd3ace00969a6821a3c922fb06")
