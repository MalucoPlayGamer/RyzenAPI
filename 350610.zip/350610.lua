-- Lua provided by RyzenAPI
-- Game: addappid(350610)

-- MAIN APPLICATION
addappid(350610)

-- MAIN APP DEPOTS / PACKAGES
addappid(350611, 1, "4c783851bd5e3061f1724163c1b8875f3c134de35aa814c94ae8e262a8cb5e05")
