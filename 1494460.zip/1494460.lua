-- Lua provided by RyzenAPI
-- Game: addappid(1494460)

-- MAIN APPLICATION
addappid(1494460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494461, 1, "71e51d12abfa43a1c590fcecd62eb24e1e9e79e213b12c8cbc9cfe771df1ab80")
addappid(3263240, 0, "14c677c03bb07daa32a7f4df53fbd2e59164c85b756c76a15dd56145ef1ea170")
