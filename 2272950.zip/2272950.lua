-- Lua provided by RyzenAPI
-- Game: Game: Deal & Wheeler

-- MAIN APPLICATION
addappid(2272950)
-- Game: addappid(2272950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272951, 1, "b688afc8c1d4e5b7f8bc3fcc8967f270ef4ead4dc388af2b2ed95e2fae13e43c")
