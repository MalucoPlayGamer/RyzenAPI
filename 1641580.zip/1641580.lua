-- Lua provided by SkyAPI 
-- Game: Assignment 42
addappid(1641580)
addappid(1641581, 1, "5d43449be34b59c6a6caa1088dddf1d2e8b24b74b1e201c86c0cd1915422a7f6")
addappid(1641582, 1, "62fdd7fb2cb35fe78edfc2a157df468619ac16d74427ec9ba61dc2c7c8e557d3")
