-- Lua provided by RyzenAPI
-- Game: Aliens Go Home Run

-- MAIN APPLICATION
addappid(514340)

-- MAIN APP DEPOTS / PACKAGES
addappid(514341,0,"e55b8c1408455946ec5ba522d24fe3c9ddb14dafc64d666a65bea1bae8e7e7ab")

