-- Lua provided by RyzenAPI
-- Game: Lucky Gem

-- MAIN APPLICATION
addappid(1901260)
addappid(1929240)
-- Game: addappid(1901260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901261, 1, "26db1949833b858157c681779031cba96eef286459c9565abaf84552beba4ead")
