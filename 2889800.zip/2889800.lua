-- Lua provided by RyzenAPI
-- Game: 2889800

-- MAIN APPLICATION
addappid(2889800)
-- Game: addappid(2889800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889801, 1, "0694ad4ea77c87b0c4d02cc806277c42b75f7446b0a301cf8d3510329bc0d6ba")
