-- Lua provided by RyzenAPI
-- Game: Purpose 1951

-- MAIN APPLICATION
addappid(2889800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889801, 1, "0694ad4ea77c87b0c4d02cc806277c42b75f7446b0a301cf8d3510329bc0d6ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
