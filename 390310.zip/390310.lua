-- Lua provided by RyzenAPI 
-- Game: Little King's Story
addappid(390310)
addappid(390311, 1, "1345f40975c20b5af6cb71de049dd8e2f208be40a8febb8b9d4cebd27112f897")
addappid(390312, 1, "95660011cafcbcaad811fbf5e5aaa1f5f402a5eeab1908cd7315f659e86e55ae")
