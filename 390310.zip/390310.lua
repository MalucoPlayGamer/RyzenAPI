-- Lua provided by RyzenAPI
-- Game: Little King's Story

-- MAIN APPLICATION
addappid(390310)

-- MAIN APP DEPOTS / PACKAGES
addappid(390311, 1, "1345f40975c20b5af6cb71de049dd8e2f208be40a8febb8b9d4cebd27112f897")
addappid(390312, 1, "95660011cafcbcaad811fbf5e5aaa1f5f402a5eeab1908cd7315f659e86e55ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
