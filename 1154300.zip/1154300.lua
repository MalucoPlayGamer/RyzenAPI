-- Lua provided by RyzenAPI
-- Game: addappid(1154300)

-- MAIN APPLICATION
addappid(1154300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154301, 1, "fd4767e4fb989bd4f81e1a19f135d221e4784e4fa306a1d60cea0688e43fa5eb")
