-- Lua provided by RyzenAPI
-- Game: 2653920

-- MAIN APPLICATION
addappid(2653920)
addappid(2962640)
-- Game: addappid(2653920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653921, 1, "1e9e4b1e0f899659bbe619aad69011a116d0c4a066ee69d8c23bc633bd7edfd1")
