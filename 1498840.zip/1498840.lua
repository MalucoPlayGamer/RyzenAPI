-- Lua provided by RyzenAPI
-- Game: setManifestid(1498843,"4255448865010991157")

-- MAIN APPLICATION
addappid(1498840)
-- Game: addappid(1498840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498843,0,"f3c7480c5c4a5fc2ec827cd2c0cdb9db3b06ddbfc1076934901cc306faa34b0d")
