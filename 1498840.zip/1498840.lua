-- Lua provided by RyzenAPI
-- Game: RUSHING BEAT OF RAGE

-- MAIN APPLICATION
addappid(1498840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498843,0,"f3c7480c5c4a5fc2ec827cd2c0cdb9db3b06ddbfc1076934901cc306faa34b0d")

