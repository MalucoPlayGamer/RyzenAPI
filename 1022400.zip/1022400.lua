-- Lua provided by RyzenAPI
-- Game: DFF NT: Sun Blade / Diamond Shield, Warrior of Light's 4th Weapon Set

-- MAIN APPLICATION
addappid(1022400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022400,0,"cd56a0b33eedb36f8aa34a29394b504e9f6242aa0c7ea49b6a787c1de75dd3e0")
