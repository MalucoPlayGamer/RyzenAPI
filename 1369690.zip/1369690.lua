-- Lua provided by RyzenAPI
-- Game: addappid(1369690)

-- MAIN APPLICATION
addappid(1369690)
addappid(3418000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369691, 1, "fff9bb2d3887d0badb1a16f331a46a8fd78d1d0edce9747d098ae8730ba8d230")
