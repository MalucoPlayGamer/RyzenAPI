-- Lua provided by RyzenAPI
-- Game: Symphony of War: The Nephilim Saga - Art & Strategy Guide

-- MAIN APPLICATION
addappid(1999620)
-- Game: addappid(1999620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999620,0,"3d53247c8eacfd95b197c86ffaa68efd8ae7be73c150d0f297aa1378ae73b575")
