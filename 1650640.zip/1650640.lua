-- Lua provided by RyzenAPI
-- Game: Dark Deity Digital Artbook

-- MAIN APPLICATION
addappid(1650640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650641, 1, "8fe17de808ba844ee0a1c82c516efdf7e3643c4a71478a3212df33d88b486f98")
