-- Lua provided by RyzenAPI
-- Game: InkBrush: The Demon Wars

-- MAIN APPLICATION
addappid(1597600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597601, 1, "55c9c2edc4ced3915d85a95e4d7a2cd17b68f8d0762c9ba609c73b9ee3b86e20")

