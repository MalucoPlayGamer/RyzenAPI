-- Lua provided by RyzenAPI
-- Game: 1597600

-- MAIN APPLICATION
addappid(1597600)
-- Game: addappid(1597600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597601, 1, "55c9c2edc4ced3915d85a95e4d7a2cd17b68f8d0762c9ba609c73b9ee3b86e20")
