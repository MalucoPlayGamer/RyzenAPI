-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2672570)
-- Game: addappid(2672570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672570,0,"21b720441f5fccf705c1bd037a0bbd0b8c817964c20bd281dbda5bb74dc173f0")
