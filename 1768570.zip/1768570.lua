-- Lua provided by RyzenAPI
-- Game: DUBIUM Playtest

-- MAIN APPLICATION
addappid(1768570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768571, 1, "75740d3ac46b59ec70c3a954db51056ce7d5681efb4bb069ac95f4fca29fb505")

