-- Lua provided by RyzenAPI
-- Game: VR Fun World

-- MAIN APPLICATION
addappid(535750)

-- MAIN APP DEPOTS / PACKAGES
addappid(535751, 1, "9aa5036dd446369d879f5c98b63c943caf24349d248f8f443cfec35870c80888")

