-- Lua provided by RyzenAPI
-- Game: White Rooms

-- MAIN APPLICATION
addappid(4403790) -- White Rooms
addappid(4750190) -- White Rooms - Unlimited Stress Relief

-- MAIN APP DEPOTS / PACKAGES
addappid(4403791, 1, "511df9f19c670d81684953b132bfdb19c3fb84c90d8765297a131769349f1e3c") -- Depot 4403791
addappid(4403792, 1, "c458f4e24e2882103d386548c853ae31ff8abebd029840c6820774810705764b") -- Depot 4403792
addappid(4403793, 1, "06bac6419b46f1fbbd568ae1f9d2f1d910c13562c932f3c4295558275db8e1be") -- Depot 4403793

