-- 4403790's Lua and Manifest Created by Hubcap Manifest
-- White Rooms
-- Created: August 27, 2026 at 15:40:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4403790) -- White Rooms
-- MAIN APP DEPOTS
addappid(4403791, 1, "511df9f19c670d81684953b132bfdb19c3fb84c90d8765297a131769349f1e3c") -- Depot 4403791
setManifestid(4403791, "4264437246887895427", 3524498567)
addappid(4403792, 1, "c458f4e24e2882103d386548c853ae31ff8abebd029840c6820774810705764b") -- Depot 4403792
setManifestid(4403792, "3615136440077643909", 3813930743)
addappid(4403793, 1, "06bac6419b46f1fbbd568ae1f9d2f1d910c13562c932f3c4295558275db8e1be") -- Depot 4403793
setManifestid(4403793, "5833481090491305180", 3558776361)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4750190) -- White Rooms - Unlimited Stress Relief