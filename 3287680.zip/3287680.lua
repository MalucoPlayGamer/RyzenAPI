-- Lua provided by RyzenAPI
-- Game: Mecha Force- Demo

-- MAIN APPLICATION
addappid(3287680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287681, 1, "8c43d464be5127ab820a52b40ac8775dc8bd73cabf4bf461e61cb8b041fb91ad")
