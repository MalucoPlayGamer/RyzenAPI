-- Lua provided by RyzenAPI
-- Game: I Wani Hug that Gator! Original Soundtrack

-- MAIN APPLICATION
addappid(2890860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890861, 1, "f3944e3e1a89f2a1453f3178c075ea56ec9063590058a036c3c566ca810817dc")
addappid(2890862, 1, "7d9910f80d19eb952a0a3b9af48d04f1fdb888e538bfe76084ee26a5f34376ea")
