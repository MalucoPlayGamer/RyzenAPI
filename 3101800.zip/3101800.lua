-- Lua provided by RyzenAPI
-- Game: addappid(3101800)

-- MAIN APPLICATION
addappid(3101800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101801, 1, "dc1955bb8af2aa8fd0cc6d55309f8ba89d7d4602d2c3789926990658115a4de3")
