-- Lua provided by RyzenAPI
-- Game: Devil May Cry 4 Original Soundtrack

-- MAIN APPLICATION
addappid(1426690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426691, 1, "d02118b3c80d3b01bffd39ee7c50b90dd70099191275ab76facf7b770f9bde60")
addappid(1426692, 1, "14ae56906f5b5765b721dbcc0dcd4e9b89ab3cd175ef694af1b83184527ca066")
addappid(1426693, 1, "fa02f3a573c1429ac81389a2f7c7805bc2827ff938fc57408313bc8ec9cf6159")
