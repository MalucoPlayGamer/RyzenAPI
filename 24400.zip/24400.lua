-- Lua provided by RyzenAPI
-- Game: Game: AppID 24400

-- MAIN APPLICATION
addappid(24400)
-- Game: addappid(24400)

-- MAIN APP DEPOTS / PACKAGES
addappid(24401, 1, "8e2835c4f67b3eb232fd8c4aac012a62c68e3ce1b1f04b4e687a39375592f47d")
addappid(24402, 1, "6361e8df86040ea174a4988199bd514ec5f14e14a3d5066127cd6eaaab504544")
addappid(24447, 0, "f861ee1f552c7b4ef4346f4ad8fcfa4ca854436fd62df0ab59a3792d57e5b052")
addappid(24449, 0, "7e57aa86844c30eb04d5c045f1f2f6db269b80ddf3ee31edf5b1dafa2f10c6e1")
