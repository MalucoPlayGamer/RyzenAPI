-- Lua provided by RyzenAPI
-- Game: Game: AppID 1111080

-- MAIN APPLICATION
addappid(1111080)
-- Game: addappid(1111080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111081, 1, "c030be04ac111ae1dc499561e96c0d30fb8fdf070c21a19f789c0c9c4dcf6f26")
