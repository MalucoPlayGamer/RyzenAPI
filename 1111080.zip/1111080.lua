-- Lua provided by RyzenAPI
-- Game: Ghost Feed

-- MAIN APPLICATION
addappid(1111080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1111081, 1, "c030be04ac111ae1dc499561e96c0d30fb8fdf070c21a19f789c0c9c4dcf6f26")
