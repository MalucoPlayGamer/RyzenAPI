-- Lua provided by RyzenAPI
-- Game: 1350990

-- MAIN APPLICATION
addappid(1350990)
-- Game: addappid(1350990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350990,0,"7ad91f7e850ca795201a0283c5f09cbd026aa04953a68f706a43b54dc8e1b5a7")
