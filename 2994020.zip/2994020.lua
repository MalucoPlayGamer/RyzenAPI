-- Lua provided by SkyAPI 
-- Game: Puck
addappid(2994020)
addappid(2994021, 1, "2b0bdd193262e293b6422b417a9fc6330277778cd29582d6773462a276675ce3")
