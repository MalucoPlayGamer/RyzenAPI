-- Lua provided by RyzenAPI 
-- Game: BROK the InvestiGator - Soundtrack
addappid(2116310)
addappid(2116311, 1, "d26ad5e4c45d58f0b1501ba3b5515d5236067d914e93c3991f8d94cfcdffbef0")
addappid(2116312, 1, "205bd388f5ffc2a32813b14057fd33add541e8fc1a9ddb3275244b9e907b0c16")
