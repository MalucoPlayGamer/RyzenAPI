-- Lua provided by RyzenAPI
-- Game: Game: AppID 758990

-- MAIN APPLICATION
addappid(758990)
-- Game: addappid(758990)

-- MAIN APP DEPOTS / PACKAGES
addappid(758991, 1, "c8f981d7497778a947599dc4f4b1d07c0cd20f9f5ea08e91b1b7db7404294c1c")
addappid(758992, 1, "921fc7f159ff6fc15ea537dd6df7c952b2cb16aa6d46359c990c354769e3059b")
addappid(758993, 1, "ed45f9fbde7a9a82531486fd2d09fcfc0e67ea3f28b0498d18cbc61dc11f1b20")
addappid(758994, 1, "4b4826fd1970815daae691ede9e20008c75da687de1672ea22a070537ee9c1b1")
