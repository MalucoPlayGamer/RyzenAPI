-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In England Find & Color

-- MAIN APPLICATION
addappid(3766190)
addappid(4045570)

