-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In England Find & Color

-- MAIN APPLICATION
addappid(3766190)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4045570)
