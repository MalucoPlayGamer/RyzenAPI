-- Lua provided by RyzenAPI
-- Game: Sumerian Six

-- MAIN APPLICATION
addappid(1429850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429851, 1, "18e46f478f70bf5822eed7efb533a1d5753cb4e200f1267014be704869fa3342")

