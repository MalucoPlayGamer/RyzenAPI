-- Lua provided by RyzenAPI
-- Game: Sumerian Six

-- MAIN APPLICATION
addappid(1429850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1429851, 1, "18e46f478f70bf5822eed7efb533a1d5753cb4e200f1267014be704869fa3342")

