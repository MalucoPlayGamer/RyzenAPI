-- Lua provided by SkyAPI 
-- Game: AppID 875080
addappid(875080)
addappid(875081, 1, "c59a887fab19a03feb0d12a24be78b9a515161937c9339933a753183fa1ed44d")
