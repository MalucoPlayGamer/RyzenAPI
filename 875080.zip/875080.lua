-- Lua provided by RyzenAPI
-- Game: Solar Explorer: New Dawn

-- MAIN APPLICATION
addappid(875080)

-- MAIN APP DEPOTS / PACKAGES
addappid(875081, 1, "c59a887fab19a03feb0d12a24be78b9a515161937c9339933a753183fa1ed44d")

