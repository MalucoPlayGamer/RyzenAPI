-- Lua provided by RyzenAPI
-- Game: Cyber Assault

-- MAIN APPLICATION
addappid(2491520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491521, 1, "37aee21c35330c70b4734a5c0501db2cb8a639cadfa10fc24863dbfe64cdbf2f")

