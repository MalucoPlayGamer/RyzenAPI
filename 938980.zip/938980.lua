-- Lua provided by RyzenAPI
-- Game: 938980

-- MAIN APPLICATION
addappid(938980)
-- Game: addappid(938980)

-- MAIN APP DEPOTS / PACKAGES
addappid(938981, 1, "4a53747827dd98ebadfc50f7455576c003988576671fceb26d1a092b1365d7d7")
