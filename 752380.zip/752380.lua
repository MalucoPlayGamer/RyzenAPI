-- Lua provided by RyzenAPI
-- Game: Game: TERRORHYTHM (TRRT) - Rhythm driven action beat 'em up!

-- MAIN APPLICATION
addappid(752380)
-- Game: addappid(752380)

-- MAIN APP DEPOTS / PACKAGES
addappid(752381, 1, "508b315bb10470f3ef141f7b296b4d6f348f203df714668ccc3e5d6794889af6")
