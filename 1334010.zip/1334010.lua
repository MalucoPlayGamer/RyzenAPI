-- Lua provided by RyzenAPI
-- Game: addappid(1334010)

-- MAIN APPLICATION
addappid(1334010)
addappid(1721900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334011, 1, "c609e5f08da42d0cacc6bb5be89b664c13b1b276ffea084faaf8091d2b730891")
