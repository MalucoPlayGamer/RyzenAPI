-- Lua provided by RyzenAPI
-- Game: Last Room

-- MAIN APPLICATION
addappid(1334010)
addappid(1721900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334011, 1, "c609e5f08da42d0cacc6bb5be89b664c13b1b276ffea084faaf8091d2b730891")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
