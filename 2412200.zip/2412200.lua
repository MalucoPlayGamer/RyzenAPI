-- Lua provided by RyzenAPI
-- Game: Cthulhu's Reach: Devil Reef

-- MAIN APPLICATION
addappid(2412200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412201, 1, "60304c9bcaeab9c0669267c89f7f1933d97577cf72de36bae17e0489a7acac7a")
