-- Lua provided by RyzenAPI
-- Game: The Survival of Sarah Rose

-- MAIN APPLICATION
addappid(2166470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166472,0,"6ebfc97d8d151311a64c5c7e094b0a3ebe37ddcecd2a3976a2f982c354930bee")
