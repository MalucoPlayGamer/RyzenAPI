-- Lua provided by RyzenAPI
-- Game: Virtual Cottage

-- MAIN APPLICATION
addappid(1369320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369321, 1, "1a06ec685039950fc6113c195f72df453f73b83e4e9b434695081c5c88096da0")
addappid(1369322, 1, "a35b59cc95f77e603ddd947befef0be42f354c711735ea61efb0525f65255107")
addappid(1369323, 1, "f7d60524f380d12b0e2511c83db2b044999fcd90f938497998b44ec42544860a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2106700)
addappid(2661170)
