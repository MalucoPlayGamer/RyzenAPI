-- Lua provided by RyzenAPI
-- Game: Game: Viking Saga: New World

-- MAIN APPLICATION
addappid(416340)
-- Game: addappid(416340)

-- MAIN APP DEPOTS / PACKAGES
addappid(416341, 1, "a71860804de6650c5137bc62746c5e238e3052d28acd4919996ba257c3aa9df8")
addappid(416342, 1, "7e4f8e18182b5989a696241be7df8514394bf4bcf9acad50c4c8b0d2dbbd551b")
addappid(416343, 1, "4034d5d2dcc4d8574e8fc3e17ade6d5f1bc6cbed32f8101d3a78f8daebd67b25")
addappid(416344, 1, "758c685ac6c1fe8b882aa2153d8ce234bf72226be93a1922f44b7b784bb878cb")
addappid(416345, 1, "1b926e11e314baaef50674f22308a4b3e266d838b150fd77b93ba9583e0d4ea8")
addappid(416346, 1, "1b7c8749b2aacdac8596dc08d905126e24eeda7343bb0ea136bd633dc44abfdd")
addappid(416347, 1, "b2ae8770145634caf9305b05d638057d870c919e18ff0b5a94ad5a884aee56cb")
addappid(416348, 1, "5e8862ea4bf4ebffac9fdaede777149901fc9e4af35ae086c4a449c0f1c0cd10")
addappid(416349, 1, "4132576538386c86d01af106e1a81731e22d191fbd5d019cd1f72023bba3066e")
