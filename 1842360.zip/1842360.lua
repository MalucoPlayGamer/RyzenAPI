-- Lua provided by RyzenAPI 
-- Game: AppID 1842360
addappid(1842360)
addappid(1842361, 1, "4823d84654a6eb89de010f596ea35ea5eaad3611d67865eef66122a745fca96d")
