-- Lua provided by RyzenAPI
-- Game: Reign: Conflict of Nations

-- MAIN APPLICATION
addappid(46380)

-- MAIN APP DEPOTS / PACKAGES
addappid(46381, 1, "615b7b3df23b3aec7803847ab81cfbbf54ca40337dd5cf0e77e9cc743e59c025")
addappid(46382, 1, "ef15d93fdfd2c9dd896166c936d39505b204325f5f8c30409b2c1ebf91e04c76")
addappid(46383, 1, "f2dd12ece924df57e51e210c82023efd487ba942e5e69af2533809904b0e9bf3")
addappid(46384, 1, "04e4c670752d920145cec69691ba3f99dab3c4a2ab0a4b0e0a67e286f4da2b55")
addappid(46385, 1, "b416307794ae90166c557010cb31e16df6b28e7a3c594b55963cd08648371396")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

