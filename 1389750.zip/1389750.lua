-- Lua provided by RyzenAPI
-- Game: 1389750

-- MAIN APPLICATION
addappid(1389750)
-- Game: addappid(1389750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389751, 1, "5b4d6f09bc8c8e2f3a4445585329e415e5fc66826c3b06164735c494caaea759")
