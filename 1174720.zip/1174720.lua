-- Lua provided by SkyAPI 
-- Game: AppID 1174720
addappid(1174720)
addappid(1174721, 1, "b5f14ad323c5960192dedcbc8d58d6d3071eca6443b613e22b4c8c22e63e55bc")
