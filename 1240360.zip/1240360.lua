-- Lua provided by SkyAPI 
-- Game: AppID 1240360
addappid(1240360)
addappid(1240361, 1, "772d0427dfa30d9e6004b4d44313bea94f1092a86fc96a646fef452412e6213a")
