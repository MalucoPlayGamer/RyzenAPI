-- Lua provided by RyzenAPI
-- Game: 1240360

-- MAIN APPLICATION
addappid(1240360)
-- Game: addappid(1240360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240361, 1, "772d0427dfa30d9e6004b4d44313bea94f1092a86fc96a646fef452412e6213a")
