-- Lua provided by RyzenAPI
-- Game: SpaceMine

-- MAIN APPLICATION
addappid(2492890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2492891, 1, "696584ba44db6a72224117e0f7cfbf0f61f442186e1aa2021e616f81e1c74f56")

