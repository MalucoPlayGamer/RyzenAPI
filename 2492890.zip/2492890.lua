-- Lua provided by RyzenAPI
-- Game: SpaceMine

-- MAIN APPLICATION
addappid(2492890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492891, 1, "696584ba44db6a72224117e0f7cfbf0f61f442186e1aa2021e616f81e1c74f56")
