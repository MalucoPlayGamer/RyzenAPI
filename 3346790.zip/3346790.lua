-- Lua provided by RyzenAPI
-- Game: Ropebound

-- MAIN APPLICATION
addappid(3346790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346791, 1, "5a2e2c3df1367dafd93203710eda0c53a37d2be47d2a5e97c63ff7bb1f3d5cbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
