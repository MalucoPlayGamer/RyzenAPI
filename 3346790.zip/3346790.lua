-- Lua provided by RyzenAPI
-- Game: Ropebound

-- MAIN APPLICATION
addappid(3346790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346791, 1, "5a2e2c3df1367dafd93203710eda0c53a37d2be47d2a5e97c63ff7bb1f3d5cbc")
