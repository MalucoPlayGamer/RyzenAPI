-- Lua provided by RyzenAPI
-- Game: addappid(2746290)

-- MAIN APPLICATION
addappid(2746290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746291, 1, "ea4d2de0da44203be2c4ad68de63e804be3a729d35994911226868251a29b75f")
