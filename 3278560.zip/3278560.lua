-- Lua provided by RyzenAPI
-- Game: Himei Dam

-- MAIN APPLICATION
addappid(3278560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278561, 1, "263bf7d41adbec71b232564ce0e1f5223e07640f80e9bc6f67608573b322aa72")

