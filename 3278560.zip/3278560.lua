-- Lua provided by RyzenAPI
-- Game: Himei Dam

-- MAIN APPLICATION
addappid(3278560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3278561, 1, "263bf7d41adbec71b232564ce0e1f5223e07640f80e9bc6f67608573b322aa72")

