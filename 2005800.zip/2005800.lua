-- Lua provided by RyzenAPI
-- Game: NinjaThea

-- MAIN APPLICATION
addappid(2005800)
-- Game: addappid(2005800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005801, 1, "3cb4047392a25dd7482f90d66a8f578e8ee879be78f241400971e8ff3b3cb8ea")
addappid(2005802, 1, "494206011a8f7f4a465840ba1c69a7097f9dcc6915a9804b7c30511ec35b34a0")
