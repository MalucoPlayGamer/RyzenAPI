-- Lua provided by RyzenAPI
-- Game: Game: Bobls Demo

-- MAIN APPLICATION
addappid(2526480)
-- Game: addappid(2526480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526481, 1, "0ec00b1716be2b6e0f5c2c96f8a6fa93e4403507c7bad121e4d83949fc21cd94")
