-- Lua provided by RyzenAPI
-- Game: 2286520

-- MAIN APPLICATION
addappid(2286520)
-- Game: addappid(2286520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286521, 1, "00f836d6e3b770f7248ff41d7eb230c3a827fda57971d8a0d359f739ff3ddc56")
addappid(2286522, 1, "d71940e39e0baf6e3b5991778c802b349dad5ae3fd8bd287c3e8f5827f20e0d5")
