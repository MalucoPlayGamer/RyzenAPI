-- 4864540's Lua and Manifest Created by Hubcap Manifest
-- HOT HOLES
-- Created: August 17, 2026 at 15:49:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4864540) -- HOT HOLES
-- MAIN APP DEPOTS
addappid(4864541, 1, "7c2e447f432486d4e5dcab65807f99ba527bd639925c6451c0ef49cc915017cb") -- Depot 4864541
setManifestid(4864541, "8335620397147608925", 334298281)