-- Lua provided by RyzenAPI
-- Game: 777650

-- MAIN APPLICATION
addappid(777650)
-- Game: addappid(777650)

-- MAIN APP DEPOTS / PACKAGES
addappid(777651, 1, "44a5489702626e165546b4bdecd3afe6b850a8f33d8f4253f85d43282ee2242f")
