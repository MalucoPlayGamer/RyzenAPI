-- Lua provided by RyzenAPI
-- Game: AppID 3072840

-- MAIN APPLICATION
addappid(3072840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072841, 1, "d9a8b5998dd6fd83b5e7d1f96d090ebdef220f26d21309be4d06a2ce0f8482eb")
