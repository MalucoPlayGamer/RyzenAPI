-- Lua provided by RyzenAPI
-- Game: HexaMon

-- MAIN APPLICATION
addappid(743480)
-- Game: addappid(743480)

-- MAIN APP DEPOTS / PACKAGES
addappid(743481, 1, "e53594972fe4b359aaa5e74daae555bc606cf78a64620956a76bfad067685c2e")
