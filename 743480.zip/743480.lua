-- Lua provided by RyzenAPI
-- Game: HexaMon

-- MAIN APPLICATION
addappid(743480)

-- MAIN APP DEPOTS / PACKAGES
addappid(743481, 1, "e53594972fe4b359aaa5e74daae555bc606cf78a64620956a76bfad067685c2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
