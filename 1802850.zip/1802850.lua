-- Lua provided by RyzenAPI
-- Game: Yes My Lord

-- MAIN APPLICATION
addappid(1802850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802852,0,"3e74e8b9a4b0ffedf64d215a7d3b74cd898cde789d56ee3924125de093ac095a")

