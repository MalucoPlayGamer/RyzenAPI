-- Lua provided by RyzenAPI
-- Game: addappid(916000)

-- MAIN APPLICATION
addappid(916000)

-- MAIN APP DEPOTS / PACKAGES
addappid(916001, 1, "2a18398ce363db7a829c4b166bb586dd965d082a1aa39f0375fb9808a5eb0b43")
