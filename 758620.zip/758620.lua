-- Lua provided by RyzenAPI
-- Game: Shadow Wolf Mysteries: Bane of the Family Collector's Edition

-- MAIN APPLICATION
addappid(758620)

-- MAIN APP DEPOTS / PACKAGES
addappid(758621,0,"b07a454df3fb1e9dc8f6830345aefa70f516f76172ad249040b8de466238512f")

