-- Lua provided by RyzenAPI
-- Game: Trump Tariff

-- MAIN APPLICATION
addappid(3514510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3514511, 1, "7ae2ea210e6ff9192171d509d08d091242c92d3a0664082cff9b204c3a20ed57")
