-- Lua provided by RyzenAPI
-- Game: LEGO® Star Wars™ - The Complete Saga

-- MAIN APPLICATION
addappid(32440)

-- MAIN APP DEPOTS / PACKAGES
addappid(32441, 1, "d77a4f05dc43f9c65f271b3702812287726bf1b90edb9e268382f4590bc93f63")
addappid(32442, 1, "460c92a21ba7795efebe9e7911f94cdc4441cedfdc1857dcd3f6881cccd25cc1")
addappid(32443, 1, "0dae5277d39b6217ae076ce511c3208e21e7d9680faffab0ffa4e2e5b0257ae8")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

