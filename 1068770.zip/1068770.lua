-- Lua provided by RyzenAPI
-- Game: The Tower - The Order of XII

-- MAIN APPLICATION
addappid(1068770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068771, 1, "cc7919ddc8458d05328f4d51dccaf654828a705bd9f60344d070abf29394b1bc")
