-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - EVFX Shoot

-- MAIN APPLICATION
addappid(2623850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623850,0,"72d9fe31bf699dc3c88452314f9775f118bd89cd7ae3a73fb918d410b60e72c8")

