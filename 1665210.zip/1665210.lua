-- Lua provided by RyzenAPI
-- Game: Sakura Forest Girls 3

-- MAIN APPLICATION
addappid(1665210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665211, 1, "a111bf3491f4883e71356ab5e831ed038a99c4294f34f506e1fce2c7fccbc9a1")

