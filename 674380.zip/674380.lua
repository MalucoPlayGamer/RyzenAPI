-- Lua provided by RyzenAPI
-- Game: Delude - Succubus Prison

-- MAIN APPLICATION
addappid(674380)

-- MAIN APP DEPOTS / PACKAGES
addappid(674381, 1, "e3042045dd13b44a3af5e3fec1e12197fb658f27ac0be66923619ec39d833379")
addappid(674382, 1, "69c7ce4e687dc0ea470fec35f74458ee4a65631cac91ab82cedaa437dd111e06")
addappid(674383, 1, "d7b52ca0dbece535107bef954897a42cf36ee96102701718b580adab289152cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
