-- Lua provided by RyzenAPI
-- Game: Underwater

-- MAIN APPLICATION
addappid(1676200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1676201, 1, "41d8a7e67e1c2e9771d2a4e12c95a6112315e66978128d3654ac75e8365411aa")

