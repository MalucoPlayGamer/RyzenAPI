-- Lua provided by RyzenAPI
-- Game: Game: Underwater

-- MAIN APPLICATION
addappid(1676200)
-- Game: addappid(1676200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676201, 1, "41d8a7e67e1c2e9771d2a4e12c95a6112315e66978128d3654ac75e8365411aa")
