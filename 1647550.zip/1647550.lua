-- Lua provided by RyzenAPI
-- Game: NEO: The World Ends with You

-- MAIN APPLICATION
addappid(1647550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647551, 1, "47d6878c035835548c33270db1ed82d1ecbef7b0cc1cc6d3f63139b672532474")
