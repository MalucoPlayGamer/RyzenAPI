-- Lua provided by RyzenAPI
-- Game: CatboyZOOM Demo

-- MAIN APPLICATION
addappid(3041880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041881, 1, "efa5549df04f7a45087e4d27d3a3a1da756529f14ece476f40a91aab10a18802")

