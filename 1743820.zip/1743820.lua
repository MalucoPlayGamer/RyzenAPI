-- Lua provided by RyzenAPI 
-- Game: Orph - The Lost Boy
addappid(1743820)
addappid(1743821, 1, "4bd7e04b72e49e1038b84ba434063f4982178565182e9a0838082ed216208770")
