-- Lua provided by RyzenAPI
-- Game: Orph - The Lost Boy

-- MAIN APPLICATION
addappid(1743820)
-- Game: addappid(1743820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743821, 1, "4bd7e04b72e49e1038b84ba434063f4982178565182e9a0838082ed216208770")
