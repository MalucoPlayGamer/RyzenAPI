-- Lua provided by SkyAPI 
-- Game: Race Day Rampage: Streamer Edition
addappid(2025330)
addappid(2025331, 1, "28f5b284adcdece5029e573a59ce2ac4e4b29aaa5171b5b1b26d6fb30b8e4356")
