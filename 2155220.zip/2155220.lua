-- Lua provided by RyzenAPI
-- Game: Petty's Adventure: Desert

-- MAIN APPLICATION
addappid(2155220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155222,0,"804b4466c25331d8e0a2827e5358bc96fee0b1423d5cd7c944798cb850b42584")
