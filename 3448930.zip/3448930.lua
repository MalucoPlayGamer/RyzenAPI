-- Lua provided by RyzenAPI
-- Game: Game: Untitled Hand Game: Titled Edition

-- MAIN APPLICATION
addappid(3448930)
-- Game: addappid(3448930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448931, 1, "e6481f23bb6b31bf3082421cffa853d8abda351c52752a7bb62e987ae63525bf")
