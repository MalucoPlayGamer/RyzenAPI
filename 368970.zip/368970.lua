-- Lua provided by RyzenAPI
-- Game: Game: Haywire on Fuel Station Zeta

-- MAIN APPLICATION
addappid(368970)
-- Game: addappid(368970)

-- MAIN APP DEPOTS / PACKAGES
addappid(368971, 1, "3f46a648d26189e0ad191d8fe806f83864932f15d4bae09604d00e893980f6f9")
