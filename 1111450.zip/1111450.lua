-- Lua provided by RyzenAPI
-- Game: AppID 1111450

-- MAIN APPLICATION
addappid(1111450)
-- Game: addappid(1111450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111451, 1, "756b1f5dcc9a4220be7ec84a53f0e6c8fa733e0117533fbf142c4bff4684585f")
