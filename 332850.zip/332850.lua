-- Lua provided by RyzenAPI
-- Game: AppID 332850

-- MAIN APPLICATION
addappid(332850)
-- Game: addappid(332850)

-- MAIN APP DEPOTS / PACKAGES
addappid(332851, 1, "d695225221f6ba7b6a178d70b4526c1f6588da5972931357291d8e3a7b47d8ce")
