-- Lua provided by RyzenAPI
-- Game: Doodle Cats

-- MAIN APPLICATION
addappid(3072880)
addappid(3092770)

