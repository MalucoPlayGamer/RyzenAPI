-- Lua provided by RyzenAPI
-- Game: Doodle Cats

-- MAIN APPLICATION
addappid(3072880)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3092770)
