-- Lua provided by RyzenAPI
-- Game: King's Bounty: The Legend

-- MAIN APPLICATION
addappid(25900)

-- MAIN APP DEPOTS / PACKAGES
addappid(25901, 1, "f5fb9d40001fe09060d9b389c75a5a7ce68b0238992282b1a5320fe641add3fc")
addappid(25902, 1, "86f73ae3b2b16c6d22d8e5c85323d8b4f9c2182b52a56a1ed441d49c2829c6ed")
addappid(25903, 1, "1e9962c3c8f4c542967e5b27aa5a02d21c2377e9b8ee9cceef43bfd6b7ea4202")
addappid(25904, 1, "a8bd03e47fe9d154742d9689660f6e07af279680554cc1f914fd27a3f836fc34")
addappid(25905, 1, "f3a66c7669eb464df2ad0b71d703a09cc174bd1c0b193de6e1171b6c13a6b216")
addappid(25906, 1, "8c9a31e25897da602194f15f3ac90b368030b72a73d8373af8936d0e008b118d")
addappid(25907, 1, "ae6b4ab038e470027b35ace7f06f1aad26348b84ae3d411936c2548b964a8a80")
addappid(25908, 1, "2e0d8c39bbe1efd19f6b1db270a293c7a0326508f473e2ef7d1410335a8cd18b")
addappid(25909, 1, "89b42641bc806f6a5dd9f97f8525bae67ea68dd01a52f3bad47e26e944ffe331")
addappid(63918, 0, "e80c69de8603ce52b217d30b2a67a8525ae38aa4e6a1e575791fe59973b3c430")
addappid(525160, 0, "c7cf59895718590807961137218312b7ea4247abc9b60436ea181c743e2b2362")
addappid(525161, 0, "1a756a7c9981375356fa8f693e5917469b41854f74fc6ae84e3e494c0bb0ec12")
addappid(525162, 0, "9c6147b001974b9cb7e9bea4de4f2f6baae6219cf9660c5005be7dc42056118c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4716020)
