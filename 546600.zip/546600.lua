-- Lua provided by RyzenAPI
-- Game: 546600

-- MAIN APPLICATION
addappid(546600)
-- Game: addappid(546600)

-- MAIN APP DEPOTS / PACKAGES
addappid(546601, 1, "3e6dac32421675f2258cc7e595d83a5b41888686a342e4cb9389a412a8c09a6d")
