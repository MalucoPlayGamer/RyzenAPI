-- Lua provided by RyzenAPI
-- Game: addappid(1840920)

-- MAIN APPLICATION
addappid(1840920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840921, 1, "69a284f7b086eb9d9ba29e23551c49bce0eb50426a6991d15b17efd120ea7690")
