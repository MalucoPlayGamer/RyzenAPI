-- Lua provided by RyzenAPI
-- Game: Fabular: Once Upon a Spacetime

-- MAIN APPLICATION
addappid(645720)

-- MAIN APP DEPOTS / PACKAGES
addappid(645721, 1, "54827cf650e82a19e135e28c367e2f5e860da988edb157c6b89b2bdc586f41ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
