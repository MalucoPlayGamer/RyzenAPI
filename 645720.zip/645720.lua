-- Lua provided by RyzenAPI
-- Game: addappid(645720)

-- MAIN APPLICATION
addappid(645720)

-- MAIN APP DEPOTS / PACKAGES
addappid(645721, 1, "54827cf650e82a19e135e28c367e2f5e860da988edb157c6b89b2bdc586f41ce")
