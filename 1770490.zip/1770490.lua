-- Lua provided by RyzenAPI
-- Game: PAW Patrol: Grand Prix

-- MAIN APPLICATION
addappid(1770490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770491, 1, "467ee21f59e4c53ffa20ffd40ad676b10491510ca68035cb1e87101de0796346")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2100030)
addappid(2230640)
