-- Lua provided by RyzenAPI
-- Game: PAW Patrol: Grand Prix

-- MAIN APPLICATION
addappid(1770490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770491, 1, "467ee21f59e4c53ffa20ffd40ad676b10491510ca68035cb1e87101de0796346")
