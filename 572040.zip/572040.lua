-- Lua provided by RyzenAPI
-- Game: addappid(572040)

-- MAIN APPLICATION
addappid(572040)

-- MAIN APP DEPOTS / PACKAGES
addappid(572041, 1, "4eaaa6a57a6b3ce0a9654a8ffb1e29daf41a3c99641f58dd7b925f6ca4667d87")
