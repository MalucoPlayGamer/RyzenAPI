-- Lua provided by RyzenAPI
-- Game: addappid(2940990)

-- MAIN APPLICATION
addappid(2940990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940991, 1, "0322ba23ee3fdad803b2a2b58807c65c2b35c3bd82131740ce2f0c55dae0faa3")
