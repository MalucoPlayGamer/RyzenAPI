-- Lua provided by RyzenAPI
-- Game: addappid(2981790)

-- MAIN APPLICATION
addappid(2981790)
addappid(3052130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981791, 1, "81d6d5df90fdb38454aa99c07ec24fc706a29d35b394c37192eeeab8704ff0c9")
