-- Lua provided by RyzenAPI
-- Game: addappid(223510)

-- MAIN APPLICATION
addappid(223510)

-- MAIN APP DEPOTS / PACKAGES
addappid(223511, 1, "c8ce44fb7b4678a9746a138645b208a9998edb26a3ca9f44985f390ef947ff82")
