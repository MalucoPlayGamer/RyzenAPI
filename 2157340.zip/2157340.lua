-- Lua provided by RyzenAPI
-- Game: Game: Meowjiro

-- MAIN APPLICATION
addappid(2157340)
-- Game: addappid(2157340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157341, 1, "e99039f6b630020ade3060890fac9322d485d351e33b1638e18841e7f87281e2")
