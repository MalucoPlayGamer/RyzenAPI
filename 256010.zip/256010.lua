-- Lua provided by RyzenAPI
-- Game: Jagged Alliance Flashback

-- MAIN APPLICATION
addappid(256010)
addappid(338560)

-- MAIN APP DEPOTS / PACKAGES
addappid(256011, 1, "f663557fa28fa4f4eb663661e235c0f6bb8b08e836061339be7e062426917fff")
addappid(256012, 1, "0042cd08a8ee177c33b656fd1ff6f80bac118dc421a7f094de793c1656c0bf43")
addappid(256013, 1, "03c810a493e6c6a146936014c69d847781a341a0c1149c517e8c5e3a6b1cd1a9")
