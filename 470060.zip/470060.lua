-- Lua provided by RyzenAPI
-- Game: 1917 - The Alien Invasion DX

-- MAIN APPLICATION
addappid(470060)
-- Game: addappid(470060)

-- MAIN APP DEPOTS / PACKAGES
addappid(470062,0,"8761dffe7051a419363eb6a867aafdbd181b05a2780dd0de0cab9ce71e6dc897")
addappid(489950,0,"603df749fbeb7342f5eb056089e8ecd1d6748eba015a29cb8d4ec35a05efe69e")
