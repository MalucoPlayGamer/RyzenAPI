-- Lua provided by RyzenAPI
-- Game: Gonio VR

-- MAIN APPLICATION
addappid(619250)
-- Game: addappid(619250)

-- MAIN APP DEPOTS / PACKAGES
addappid(619251, 1, "f8c4ea312bc414bbc25c0464b6fda526a5697b754c3e96385b6ed8ea88201507")
