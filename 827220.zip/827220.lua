-- Lua provided by RyzenAPI 
-- Game: Overclocked: The Aclockalypse
addappid(827220)
addappid(827221, 1, "dcada31ac618ec0ee597d6f7b8c4c2b2ebd588341e3bdc1c52fa19294a4a5548")
addappid(827222, 1, "8d31bc706e076445db2182b2ab46866dd288830c4f37b2350bd2cf2c946e3c6b")
