-- Lua provided by RyzenAPI
-- Game: Game: An Arcade Full of Cats

-- MAIN APPLICATION
addappid(2368470)
addappid(2582360)
-- Game: addappid(2368470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368471, 1, "7b10f3b7ec0e6263e676eb1c225ef4b8d9296feccc292586a6f5b71e8f8720a4")
addappid(2368472, 1, "73d56ee09b5eafd771298d30e7385432e85d056d91d7abceffceb6988ed51406")
