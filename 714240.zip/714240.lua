-- Lua provided by RyzenAPI
-- Game: SWARMRIDER OMEGA

-- MAIN APPLICATION
addappid(714240)
addappid(749610)

-- MAIN APP DEPOTS / PACKAGES
addappid(714241, 1, "f9c31d3944f63c6e73be701a78b224b04aca04cb2e354c9dc92e8d3baac129e3")
addappid(714242, 1, "436d829b473403de609de27fa1fbe54fffff6277f36e75569b9593b8372eda59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
