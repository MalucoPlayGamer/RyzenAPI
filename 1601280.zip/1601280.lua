-- Lua provided by SkyAPI 
-- Game: Potato Flowers in Full Bloom
addappid(1601280)
addappid(1601281, 1, "5880cdb4302ddc57e308f4f41519e47b3181ffd67fa37489fa0329984bc3300e")
