-- Lua provided by RyzenAPI
-- Game: Potato Flowers in Full Bloom

-- MAIN APPLICATION
addappid(1601280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601281, 1, "5880cdb4302ddc57e308f4f41519e47b3181ffd67fa37489fa0329984bc3300e")
