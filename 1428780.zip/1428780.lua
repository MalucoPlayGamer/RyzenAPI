-- Lua provided by RyzenAPI
-- Game: Animal Rescuer

-- MAIN APPLICATION
addappid(1428780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1428781, 1, "4dd08298b0c1e9a94bd72be927f17bd9d515adfb3d137833508faf0cd5d12235")
addappid(1428782, 1, "10b945128684f76165a0256724d28c8b16f76307567154c0f953227d5f8e3f01")

