-- Lua provided by RyzenAPI
-- Game: Game: Rolling Toolman 2 Deathly Traps

-- MAIN APPLICATION
addappid(2607640)
-- Game: addappid(2607640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607641, 1, "ee7ad9bf45b0facb76e70c643ddcf28ec54d6a464b826b223d08a5c04243b73e")
