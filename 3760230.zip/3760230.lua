-- Lua provided by RyzenAPI
-- Game: Sherlock: Hidden Object & Match-3 Mystery

-- MAIN APPLICATION
addappid(3760230)
