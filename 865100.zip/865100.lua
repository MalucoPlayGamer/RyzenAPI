-- Lua provided by RyzenAPI
-- Game: addappid(865100)

-- MAIN APPLICATION
addappid(865100)

-- MAIN APP DEPOTS / PACKAGES
addappid(865101, 1, "ccd1130d87973c7f41d419318792c4ac3a733f8a3a9dc45abc3b7d66a42bfa39")
