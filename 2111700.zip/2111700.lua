-- Lua provided by RyzenAPI
-- Game: 水着コスチュームセット（８種）

-- MAIN APPLICATION
addappid(2111700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111700,0,"1f0d154578fc86a861173b7e222662a25e6f3b20d65a054fcc2e7beb8b3421a2")

