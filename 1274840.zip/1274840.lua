-- Lua provided by RyzenAPI
-- Game: Escape from GULAG

-- MAIN APPLICATION
addappid(1274840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274841, 1, "eddea9857abb92b64de14ecb14fad9595b1b9ab50b0ebf3157331beb496cf4d0")
