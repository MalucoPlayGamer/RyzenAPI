-- Lua provided by RyzenAPI
-- Game: addappid(1552810)

-- MAIN APPLICATION
addappid(1552810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552811, 1, "8e33c1cd1374389ea122e7f43ec5ad1301e0d6827b08e9cc05bd363fb4a8102f")
