-- Lua provided by RyzenAPI
-- Game: addappid(1420980)

-- MAIN APPLICATION
addappid(1420980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420981, 1, "bc22aa502ee973554e267949231620c4eff141425dad62ef18ccd14011cca086")
