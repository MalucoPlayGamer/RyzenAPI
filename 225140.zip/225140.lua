-- Lua provided by RyzenAPI
-- Game: Duke Nukem 3D: Megaton Edition

-- MAIN APPLICATION
addappid(225140)

-- MAIN APP DEPOTS / PACKAGES
addappid(225141, 1, "1112b5af31976bbbf3df341493aae529e646710f435ccba991d55b7fa8ba9f48")
addappid(225142, 1, "f58baddf6a358472c92f6c806e9736239ad8b214e7b64c20454595064cb00921")
addappid(225143, 1, "2f3cb66638f5534662623df0597cbbf2c4e3a450a1b5683106c8e5d42f86c05e")
addappid(225144, 1, "c34b7353a202b3aa1d08c7b715f45ed2a25deed8272f7f2dff06db1b4ef25e39")

