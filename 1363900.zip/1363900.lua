-- Lua provided by RyzenAPI
-- Game: Game: Farworld Pioneers

-- MAIN APPLICATION
addappid(1363900)
-- Game: addappid(1363900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363901, 1, "653f6e5c720026b4c31c14cb408e83c2f59998b8505b9d67a9e5c250b486d8a0")
