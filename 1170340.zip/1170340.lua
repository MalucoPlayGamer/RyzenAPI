-- Lua provided by RyzenAPI
-- Game: Hentai Jigsaw Puzzle 2

-- MAIN APPLICATION
addappid(1170340)
addappid(1182270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170341, 1, "10d8a3b8a99b0e7948b3771cabb2bdc68fc62cee5f82b6f0cc9a58d268801fba")

