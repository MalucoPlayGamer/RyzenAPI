-- Lua provided by RyzenAPI
-- Game: Hentai Jigsaw Puzzle 2

-- MAIN APPLICATION
addappid(1170340)
addappid(1182270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1170341, 1, "10d8a3b8a99b0e7948b3771cabb2bdc68fc62cee5f82b6f0cc9a58d268801fba")

