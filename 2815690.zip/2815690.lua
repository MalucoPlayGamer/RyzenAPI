-- Lua provided by SkyAPI 
-- Game: Uncle Z
addappid(2815690)
addappid(2815691, 1, "4ab49e7154227c0254dd51317689cd154296b96a8bf1a2e38cfc24b373db5709")
addappid(2815692, 1, "1ff809630dc27620f892c0374f7ab010c28a38a671628d050c1b5a0c638a8caf")
