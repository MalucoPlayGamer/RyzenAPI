-- Lua provided by RyzenAPI
-- Game: Fear Effect 2: Retro Helix

-- MAIN APPLICATION
addappid(3509140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509141, 1, "fd91747265e7e9f7ac86135e6fee7fdb3572533ef0b03098e2061d3f377ed9ca")

