-- Lua provided by RyzenAPI
-- Game: AppID 676880

-- MAIN APPLICATION
addappid(676880)
-- Game: addappid(676880)

-- MAIN APP DEPOTS / PACKAGES
addappid(676881, 1, "f375d1335df44c08409c16f202c8ba53ebc47e8f3d99f84dc357c5d5358405f4")
