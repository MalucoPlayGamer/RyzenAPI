-- Lua provided by SkyAPI 
-- Game: Zero Escape: The Nonary Games
addappid(477740)
addappid(477741, 1, "f29858bab667e03a44a8deb846c10caf95f426dde541a66555d9580f3c2338f9")
addappid(477742, 1, "668fb4977adf6589261df9f0d1ee9154138efd46664f0a4d3943e0b04be00732")
addappid(477743, 1, "e1e5b71ce861fbf74a603ae86fbf8b63aba653c6b4c513d8aba00db8c38f4f2d")
addappid(586870, 0, "13fb1fb285ab80b506a78fd5b986f14d1334564779bfaff4dfdde3d38c8911ea")
