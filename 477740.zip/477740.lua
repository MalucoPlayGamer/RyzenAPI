-- Lua provided by RyzenAPI
-- Game: Zero Escape: The Nonary Games

-- MAIN APPLICATION
addappid(477740)

-- MAIN APP DEPOTS / PACKAGES
addappid(477741, 1, "f29858bab667e03a44a8deb846c10caf95f426dde541a66555d9580f3c2338f9")
addappid(477742, 1, "668fb4977adf6589261df9f0d1ee9154138efd46664f0a4d3943e0b04be00732")
addappid(477743, 1, "e1e5b71ce861fbf74a603ae86fbf8b63aba653c6b4c513d8aba00db8c38f4f2d")
addappid(586870, 0, "13fb1fb285ab80b506a78fd5b986f14d1334564779bfaff4dfdde3d38c8911ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
