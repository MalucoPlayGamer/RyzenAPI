-- Lua provided by RyzenAPI
-- Game: Game: AppID 1344120

-- MAIN APPLICATION
addappid(1344120)
-- Game: addappid(1344120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344121, 1, "5192b81094ee78ee6cbd9b7d9c42d905948d12afa25b5f8c37d6194d0d41ff37")
