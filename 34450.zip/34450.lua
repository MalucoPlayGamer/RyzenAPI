-- Lua provided by RyzenAPI
-- Game: Civilization IV®: Warlords

-- MAIN APPLICATION
addappid(34450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3993,0,"c7391949f76a3a4241ca8bb23dea41f59f7eb1e280925b8dfe9f338362af8a8b")
