-- Lua provided by RyzenAPI
-- Game: Coloring Game 2

-- MAIN APPLICATION
addappid(1216200)
addappid(1221790)

