-- Lua provided by RyzenAPI
-- Game: Coloring Game 2

-- MAIN APPLICATION
addappid(1216200)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1221790)
