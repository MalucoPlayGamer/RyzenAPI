-- Lua provided by RyzenAPI
-- Game: Zero End: Chapter One

-- MAIN APPLICATION
addappid(2573050)
addappid(3964570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573051, 1, "e6bd7a5663beb6cec411dcf6438185e42172ecab608ec730173ad3a0ec7d7d43")
