-- Lua provided by RyzenAPI
-- Game: Game: La Pucelle: Ragnarok

-- MAIN APPLICATION
addappid(1866420)
addappid(2071700)
-- Game: addappid(1866420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866421, 1, "61cc52fc6441e44cefabb8f5013510e6965e0afdb53872c1ad7592707b59b7eb")
