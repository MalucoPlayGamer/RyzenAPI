-- Lua provided by RyzenAPI
-- Game: La Pucelle: Ragnarok

-- MAIN APPLICATION
addappid(1866420)
addappid(2071700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1866421, 1, "61cc52fc6441e44cefabb8f5013510e6965e0afdb53872c1ad7592707b59b7eb")

