-- Lua provided by RyzenAPI
-- Game: setManifestid(797612,"5438960680843512625")

-- MAIN APPLICATION
addappid(797610)
-- Game: addappid(797610)

-- MAIN APP DEPOTS / PACKAGES
addappid(797612,0,"668bcb77dd023b7ead8f3f5978199e09087fb64d8d4c0de96f8d788a16a5b015")
