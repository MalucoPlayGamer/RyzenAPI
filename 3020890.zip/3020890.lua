-- Lua provided by RyzenAPI
-- Game: 3020890

-- MAIN APPLICATION
addappid(3020890)
-- Game: addappid(3020890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020891, 1, "3fa7b3fbaa14dc1ee9f53524ebe8d5066817759a2b466adacdea8675535fe1a0")
