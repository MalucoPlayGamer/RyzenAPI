-- Lua provided by RyzenAPI
-- Game: Parkitect - Soundtrack

-- MAIN APPLICATION
addappid(1004340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004341, 1, "c0a5f21a83bb6f5a272cdd2d73f54cd78ec08d24faaa35f505ea8a9cb3038628")
