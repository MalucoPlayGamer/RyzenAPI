-- Lua provided by RyzenAPI
-- Game: AppID 1435230

-- MAIN APPLICATION
addappid(1435230)
-- Game: addappid(1435230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435231, 1, "bcce5eb56de034fb651f7485935c93643ec4de34d066a33cd0e96a52a9849221")
