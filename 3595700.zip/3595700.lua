-- Lua provided by RyzenAPI
-- Game: Metahorror Therapy Session: Hintbook & Lorebook

-- MAIN APPLICATION
addappid(3595700)
-- Game: addappid(3595700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595701, 1, "a203ff3ba1857251ec427b285741883d0a0801cf770e7a780d1d2963d8064ac9")
