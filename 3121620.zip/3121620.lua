-- Lua provided by RyzenAPI
-- Game: The King Cat Clicker

-- MAIN APPLICATION
addappid(3121620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121621, 1, "6f289aa6ddcaaae8d8266ce3b220e549a1512f2b7a3ca876d5d164a65e068c97")
