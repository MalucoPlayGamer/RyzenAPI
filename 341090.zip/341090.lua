-- Lua provided by RyzenAPI
-- Game: On A Roll 3D

-- MAIN APPLICATION
addappid(341090)

-- MAIN APP DEPOTS / PACKAGES
addappid(341091, 1, "4ead06d7250994fef30c5d3563a095a4cd538545a62f7ae36fd0dbd60b7612e8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(487570)
addappid(1889400)
