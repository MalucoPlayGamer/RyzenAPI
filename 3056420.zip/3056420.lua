-- Lua provided by RyzenAPI
-- Game: You know my name?

-- MAIN APPLICATION
addappid(3056420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056421, 1, "75e753a31d5adcc651dfe04dd0e9689cfa74430d7a9bd9ce39589d037b02a6ec")
