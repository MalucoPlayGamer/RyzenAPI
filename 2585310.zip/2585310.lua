-- Lua provided by RyzenAPI
-- Game: addappid(2585310)

-- MAIN APPLICATION
addappid(2585310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585311, 1, "917301bb451a79eb8942a801c65e7b7ef84202adefb4000595684ccae69fe742")
