-- Lua provided by RyzenAPI
-- Game: Game: AppID 1753200

-- MAIN APPLICATION
addappid(1753200)
-- Game: addappid(1753200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753201, 1, "e8a59f92b9dbcba56d0536ab1b69c709ca7d7b7f75ef042909df3bd91a3333a5")
