-- Lua provided by RyzenAPI
-- Game: Scrap Mechanic

-- MAIN APPLICATION
addappid(387990)
-- Game: addappid(387990)

-- MAIN APP DEPOTS / PACKAGES
addappid(387992,0,"a2b344f494b0b5375bf3c405e8b3de97923659c663d583eee57993952d363761")
addappid(387993,0,"93137be5385ff98af9981124f0adeb9e8d55b91d0eab1c8a2f9ab417034a3243")
