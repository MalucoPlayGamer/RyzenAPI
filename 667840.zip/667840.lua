-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Builder S

-- MAIN APPLICATION
addappid(667840)
-- Game: addappid(667840)

-- MAIN APP DEPOTS / PACKAGES
addappid(667841, 1, "cc5e54ff969379523ab8017038687740826446e74ef7aaa0d603f7640565bbd0")
