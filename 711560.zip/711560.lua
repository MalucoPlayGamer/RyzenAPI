-- Lua provided by RyzenAPI
-- Game: Game: AppID 711560

-- MAIN APPLICATION
addappid(711560)
-- Game: addappid(711560)

-- MAIN APP DEPOTS / PACKAGES
addappid(711561, 1, "a535466e0e29622b8fae809c5739096883afbb03144eaf8976eeecca8a7cd973")
