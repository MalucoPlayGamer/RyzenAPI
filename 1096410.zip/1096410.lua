-- Lua provided by RyzenAPI
-- Game: addappid(1096410)

-- MAIN APPLICATION
addappid(1096410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096411, 1, "4ab6540a3c86f58819c7d643d1fbd362a400be3fcc51e006a4b6d325399250fe")
addappid(1096412, 1, "c4e0dc1431e2c09c20cf733e430f7b31d985f172af5ddb0cc09a5d8963bbcc55")
addappid(1096413, 1, "eeefd1f999762edaa693ef73b630b64fabeb8b1a8a683ad315b56447e1ad3704")
