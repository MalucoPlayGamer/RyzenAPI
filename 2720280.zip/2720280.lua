-- Lua provided by RyzenAPI
-- Game: Follow the meaning

-- MAIN APPLICATION
addappid(2720280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720281, 1, "00dbfcda03b6c0849975da310050594b36a4880b42579700be195ab9857a7013")

