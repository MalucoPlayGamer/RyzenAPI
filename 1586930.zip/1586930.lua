-- Lua provided by RyzenAPI
-- Game: addappid(1586930)

-- MAIN APPLICATION
addappid(1586930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586931, 1, "d8f40ce362a5c476896ade6742303e93e648b6bb34558e7eba04ed7e2bc3bfd6")
