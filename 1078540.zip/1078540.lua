-- Lua provided by RyzenAPI
-- Game: AppID 1078540

-- MAIN APPLICATION
addappid(1078540)
-- Game: addappid(1078540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078541, 1, "467141038c7cbbb275730d5bbc29bdd7a03ae7e155ac419f039053fbd23b7828")
