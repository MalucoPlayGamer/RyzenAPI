-- Lua provided by RyzenAPI
-- Game: Game: Twin Sector

-- MAIN APPLICATION
addappid(27900)
-- Game: addappid(27900)

-- MAIN APP DEPOTS / PACKAGES
addappid(27901, 1, "4d2b0ee9277821d42a329519e78cd9aaf028b05abe96988f3856faa83f56bc72")
