-- Lua provided by RyzenAPI
-- Game: Project Motor Racing

-- MAIN APPLICATION
addappid(299970)
addappid(3660380)
addappid(3660390)
addappid(3660400)
-- Game: addappid(299970)

-- MAIN APP DEPOTS / PACKAGES
addappid(299971, 1, "627b7ea547216da3a24888dc32bd27fa27c0f3bfae47a0e15b6a6a3c905bfa07")
