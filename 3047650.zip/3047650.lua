-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3047650)
-- Game: addappid(3047650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3047653,0,"16603498987c3a87a3f8a3a4dcb3444edd79618c2a3e871fe8e0b84305060c29")
addappid(3047654,0,"59b4cfe90eda6fa8a68b81e982b939a431aa7b88a5fedd220125d2017e95f758")
