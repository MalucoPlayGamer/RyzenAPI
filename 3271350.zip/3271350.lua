-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3271350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271352,0,"c59435282896d1b8f13257b5386cb9ea4cf87002c374d7190bfec0d47605f255")
