-- Lua provided by RyzenAPI
-- Game: Game: World Mahjong

-- MAIN APPLICATION
addappid(2119440)
-- Game: addappid(2119440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119441, 1, "1e31ee884af04ac591e5be058e72d3f464eeb92756540b743871bdf072235f49")
