-- Lua provided by SkyAPI 
-- Game: AppID 1354950
addappid(1354950)
addappid(1354951, 1, "ef530384f16974dde33f3e35f76adb727d189fd416a5128a495e17e9fc647ed0")
