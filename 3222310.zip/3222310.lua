-- Lua provided by RyzenAPI
-- Game: Game: AppID 3222310

-- MAIN APPLICATION
addappid(3222310)
-- Game: addappid(3222310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3222311, 1, "d3cdb83191974bed2ae559d3157be6a62ff5307c5c3249d6df93b3af404f6ca4")
addappid(3222312, 1, "ba197d4ad5002f6cf3373f4f97de37ef8004100bc576211d69caef4f17ebb59c")
