-- Lua provided by RyzenAPI
-- Game: addappid(1966100)

-- MAIN APPLICATION
addappid(1966100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966101, 1, "f7ff1b8834688292d4db86750ac524041a2a46ab9f73f69ba46cdd6db37ee11c")
