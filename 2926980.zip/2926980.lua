-- Lua provided by RyzenAPI
-- Game: 2926980

-- MAIN APPLICATION
addappid(2926980)
-- Game: addappid(2926980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926981, 1, "be8c94f7bcfcf88a444b448e65807f5f681085a686abf1cf50f846915d95515c")
