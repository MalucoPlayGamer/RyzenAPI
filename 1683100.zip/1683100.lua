-- Lua provided by RyzenAPI
-- Game: Ultra Age

-- MAIN APPLICATION
addappid(1683100)
addappid(2064450)
addappid(2065470)
addappid(2065479)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1683101, 1, "a1273e8098d05cfeb8c601cf42c93dcfec861f42c0f2f3d4472a39fd57ab02c1")
addappid(2064451, 0, "b86929f44f335c92fb905f89b27893e29683f72d994af83371ec72be956365c4")

