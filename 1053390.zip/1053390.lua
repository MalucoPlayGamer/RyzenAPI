-- Lua provided by RyzenAPI
-- Game: Kowloon High-School Chronicle: ORIGIN OF ADVENTURE

-- MAIN APPLICATION
addappid(1053390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053391, 1, "6eec974b7800fffb0dd317eddbdda52b61ce1161f146ea8287ea5875b1cbca4b")

