-- Lua provided by RyzenAPI
-- Game: Game: The Awakener: Forgotten Oath

-- MAIN APPLICATION
addappid(2527660)
-- Game: addappid(2527660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527661, 1, "7ca2ce58c5b6fc3b702c3ead9aafe8738aab76887f984d547659817e543bd3f7")
