-- Lua provided by RyzenAPI
-- Game: Game: Settlemoon

-- MAIN APPLICATION
addappid(2443780)
-- Game: addappid(2443780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443781, 1, "e2f1132127a592bd66b9e6ce0abbf3d31cfa65a2a8fb86ef0eccc7c4a5c2abd6")
