-- Lua provided by RyzenAPI
-- Game: 秘封フラグメント

-- MAIN APPLICATION
addappid(1568880)
addappid(1568881)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568882,0,"6cde7772632a313828bbd52ddd5ed454528e4eb78d6dada6edb1238a62f94276")

