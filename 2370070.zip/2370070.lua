-- Lua provided by RyzenAPI
-- Game: Nightmare: Worlds Collide

-- MAIN APPLICATION
addappid(2370070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370072,0,"f5e1605b69b24a1fa9b134085b5b94a579f67724dbaac64c32dac44a39ae1aee")

