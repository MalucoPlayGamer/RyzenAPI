-- Lua provided by RyzenAPI
-- Game: Nightmare: Worlds Collide

-- MAIN APPLICATION
addappid(2370070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370072,0,"f5e1605b69b24a1fa9b134085b5b94a579f67724dbaac64c32dac44a39ae1aee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
