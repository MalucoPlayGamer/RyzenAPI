-- Lua provided by RyzenAPI
-- Game: Slot & Dungeons Demo

-- MAIN APPLICATION
addappid(3224750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224751, 1, "f8fc8bb7e5751c6b7f62f46a914f17614e3a64383959bf9f75bb47688793acb9")
