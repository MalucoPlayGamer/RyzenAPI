-- Lua provided by RyzenAPI
-- Game: Game: AppID 1994010

-- MAIN APPLICATION
addappid(1994010)
-- Game: addappid(1994010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994011, 1, "f59867622559267d946ba4432de47880cc2cc41421db1ac93eeedf508ce82782")
