-- Lua provided by SkyAPI 
-- Game: AppID 1994010
addappid(1994010)
addappid(1994011, 1, "f59867622559267d946ba4432de47880cc2cc41421db1ac93eeedf508ce82782")
