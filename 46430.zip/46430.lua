-- Lua provided by RyzenAPI
-- Game: Chrome: Specforce

-- MAIN APPLICATION
addappid(46430)

-- MAIN APP DEPOTS / PACKAGES
addappid(46431, 1, "5faf278133b7479f85cae307b7f247287362ab4787da93a3d1c905f21d44cd82")
