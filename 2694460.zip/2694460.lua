-- Lua provided by RyzenAPI
-- Game: The Quantum Conflict

-- MAIN APPLICATION
addappid(2694460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694461, 1, "cd9f956dac9248881436865fc576042f1a1501bd4373f6578cb6a10cc263cdb1")
