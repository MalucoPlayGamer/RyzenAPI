-- Lua provided by RyzenAPI
-- Game: Game: AppID 3212410

-- MAIN APPLICATION
addappid(3212410)
-- Game: addappid(3212410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3212411, 1, "e481961a6559725de4a2f5e9bb8f1ac8f25c8463409ad1b294d4b802ee850c96")
