-- Lua provided by RyzenAPI
-- Game: Saucer-Like

-- MAIN APPLICATION
addappid(602590)

-- MAIN APP DEPOTS / PACKAGES
addappid(602591, 1, "1466e6a651f74bb35756d0546393dd7fd152ed03d632c55621c34dc4a4456392")

