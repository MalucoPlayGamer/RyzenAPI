-- Lua provided by RyzenAPI
-- Game: addappid(2905250)

-- MAIN APPLICATION
addappid(2905250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905251, 1, "3a6baa45e4206cd0916eacf7a98347fc3645b6a5b471763997a525fa31b01e4a")
