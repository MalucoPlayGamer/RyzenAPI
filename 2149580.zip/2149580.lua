-- Lua provided by RyzenAPI
-- Game: 2149580

-- MAIN APPLICATION
addappid(2149580)
-- Game: addappid(2149580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149582,0,"4cc08c97f5e4989e9e50fef628ff69f4f036b742f53529997f31da76f02523bc")
