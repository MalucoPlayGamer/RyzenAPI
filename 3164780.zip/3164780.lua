-- Lua provided by RyzenAPI
-- Game: 3164780

-- MAIN APPLICATION
addappid(3164780)
-- Game: addappid(3164780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164781, 1, "21babd51cc3f93ba4df5e548daf07745eb5fbd3975e0ec0dbb377f56f8abc42d")
