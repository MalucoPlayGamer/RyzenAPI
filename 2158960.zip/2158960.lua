-- Lua provided by RyzenAPI
-- Game: Shadow Heroes Demo

-- MAIN APPLICATION
addappid(2158960)
-- Game: addappid(2158960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158961, 1, "b9b270131ac9fd9674070cb10474f29867d17d48cb5b23162166758c252a6ddf")
