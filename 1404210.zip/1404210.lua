-- Lua provided by RyzenAPI
-- Game: Red Dead Online

-- MAIN APPLICATION
addappid(1174182)
addappid(1174183)
addappid(1174184)
addappid(1174185)
addappid(1174186)
addappid(1404210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404212,0,"ae0071b18114fd98fd4ddfabb7aac3aa7fea27c0714d13bba463a0a291966e91")
addappid(1404213,0,"026be2c718d33a946e609bf5584bf0c968f1be2c323052d7d708b50b8e0b2e6f")
addappid(1404214,0,"4f80d187ee2899a12e666effb353de88053a7355913b4d64921e0467b3112535")
addappid(1404215,0,"477198cf7e75ed1026a950adeb5ccbe65a56fee259c0c0f0de3e31d4a234b683")
addappid(1404216,0,"f5d7db4186c959bb4fb99ddf612304492246187bb799685dda3f0e53b1277548")
addappid(1404217,0,"4ac1facef923c02acfe27abcc50dda9c98eff3526f0173d955ddcb61a7440075")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
