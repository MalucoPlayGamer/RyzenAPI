-- Lua provided by RyzenAPI
-- Game: PrisonSoul:Reunion

-- MAIN APPLICATION
addappid(2884780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884781, 1, "1c31f138dadafa12c1fe0f82a3dd87a3f257a50080e0e517dca4f0d095fd3587")

