-- Lua provided by RyzenAPI 
-- Game: The Solitude Project
addappid(3452280)
addappid(3452281, 1, "d91a1a38846706740f7293fc832162a8135c17938179f529651360ff6b3b0385")
