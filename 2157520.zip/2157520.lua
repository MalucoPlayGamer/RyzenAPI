-- Lua provided by RyzenAPI
-- Game: Oshirabu: Waifus Over Husbandos - Wedding Rings & Marriage Makeovers

-- MAIN APPLICATION
addappid(2157520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157523,0,"2b3b9706da328924f48c63f412dbc2a56d12af7d31f535293f515fd60c00e064")
addappid(2157524,0,"c4d47bf8d41ab44bef9e39ca0a2a25e7fed384bfe7224cf7e26fa75870513293")
addappid(2157525,0,"15cfa402801c2db705634411b4ae266a3857e61dfa5dcec1cb4252eecaa66a73")
addappid(2157526,0,"ed02e766e5d23e3848ca3d03213801cc410411b1e459f6a1970af7b4feb5c7cc")
