-- Lua provided by RyzenAPI 
-- Game: Trench Lord: Eastern Front
addappid(1647310)
addappid(1647311, 1, "0b60df88f0024a9f771c1029fb96eb9b4e4026466fce162f0eafab303dc9d323")
