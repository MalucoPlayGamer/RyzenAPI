-- Lua provided by RyzenAPI
-- Game: Venice Bridges

-- MAIN APPLICATION
addappid(2838420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838421, 1, "71f62a6a6233d47bd6fb8d35b7e2a18ab18785e6a8034700007cf10b8c770ed7")
