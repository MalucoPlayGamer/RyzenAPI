-- Lua provided by RyzenAPI
-- Game: Game: VR Masturbate

-- MAIN APPLICATION
addappid(1576850)
addappid(1583100)
-- Game: addappid(1576850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576851, 1, "db9a1d4862c8f36ba73b43247951cce2f48a033d7deb5c8419e6e098cb12f6f8")
