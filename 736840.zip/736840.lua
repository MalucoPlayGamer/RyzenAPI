-- Lua provided by RyzenAPI 
-- Game: aMAZE Double
addappid(736840)
addappid(736841, 1, "7056ed4c91e31f5126be76a550d437fa71ee5852113f354ad7078b799210a6b1")
