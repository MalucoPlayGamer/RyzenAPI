-- Lua provided by RyzenAPI
-- Game: Game: aMAZE Double

-- MAIN APPLICATION
addappid(736840)
-- Game: addappid(736840)

-- MAIN APP DEPOTS / PACKAGES
addappid(736841, 1, "7056ed4c91e31f5126be76a550d437fa71ee5852113f354ad7078b799210a6b1")
