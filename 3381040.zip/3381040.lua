-- Lua provided by RyzenAPI
-- Game: Game: LAW 56 Demo

-- MAIN APPLICATION
addappid(3381040)
-- Game: addappid(3381040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381041, 1, "10eb3fd2464078969e277d2e938fecbaf6c768d311723d17bc4e3348503b74f0")
