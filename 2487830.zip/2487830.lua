-- Lua provided by RyzenAPI
-- Game: Touhou: New World - Artbook

-- MAIN APPLICATION
addappid(2487830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487830,0,"50470ff77097a4503d1ce8fd38e455ec436c71d76bb127e2507559d52ab7278c")
