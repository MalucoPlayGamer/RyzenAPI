-- Lua provided by RyzenAPI
-- Game: Missile Command Delta

-- MAIN APPLICATION
addappid(2790160)
-- Game: addappid(2790160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790161, 1, "c875bef87c485897f3480114b91572db00b53f77c9464551898ad328eb653252")
