-- Lua provided by RyzenAPI
-- Game: A Space for the Unbound Soundtrack

-- MAIN APPLICATION
addappid(2050790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050791, 1, "e87edd5215db836b388bfa516ab3ebc265f0b395876ef001818bfac9dee9c81b")
addappid(2050792, 1, "d803fb51fd41f5c69b7f503692644be94128221de404b0e74ef203899041d08a")

