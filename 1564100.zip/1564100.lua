-- Lua provided by SkyAPI 
-- Game: Synth Drift
addappid(1564100)
addappid(1564101, 1, "2ab736bbf7696b7766edb3492a01f035143e1de691041bf4e753fdb31031c87a")
