-- Lua provided by RyzenAPI
-- Game: Shiitake Showdown

-- MAIN APPLICATION
addappid(2222850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2222851, 1, "0765c627bcbbd4989ff2e2e931a932340f8a691002cc361f13d9de9594328162")

