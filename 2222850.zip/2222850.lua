-- Lua provided by RyzenAPI
-- Game: Shiitake Showdown

-- MAIN APPLICATION
addappid(2222850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222851, 1, "0765c627bcbbd4989ff2e2e931a932340f8a691002cc361f13d9de9594328162")
