-- Lua provided by SkyAPI 
-- Game: Troupe
addappid(1338620)
addappid(1338621, 1, "a9a18b48280b2fed1fe555971259ea1e0a42f25a324e576d4eb3ea19a763d08a")
