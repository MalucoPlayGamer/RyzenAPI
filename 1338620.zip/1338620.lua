-- Lua provided by RyzenAPI
-- Game: Troupe

-- MAIN APPLICATION
addappid(1338620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1338621, 1, "a9a18b48280b2fed1fe555971259ea1e0a42f25a324e576d4eb3ea19a763d08a")

