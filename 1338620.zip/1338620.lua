-- Lua provided by RyzenAPI
-- Game: Troupe

-- MAIN APPLICATION
addappid(1338620)
-- Game: addappid(1338620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338621, 1, "a9a18b48280b2fed1fe555971259ea1e0a42f25a324e576d4eb3ea19a763d08a")
