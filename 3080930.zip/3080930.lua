-- Lua provided by RyzenAPI
-- Game: JimmyCraft

-- MAIN APPLICATION
addappid(3080930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080931, 1, "7e0f745614d127ba2a6c174436f8687ad61024fcedb448f9fd7ba99f92c791f1")
