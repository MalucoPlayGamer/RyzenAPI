-- Lua provided by RyzenAPI
-- Game: AppID 2369520

-- MAIN APPLICATION
addappid(2369520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369521, 1, "e7ef8f6de4c45cefabee6c136b8bffdc3edb84d129560794d6da255db0e8449f")
