-- Lua provided by RyzenAPI
-- Game: RPG Maker 3D Character Converter

-- MAIN APPLICATION
addappid(2218350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218351, 1, "a61a08c501aaa5d0511b409800394419abf13d8444e30111a603df8935c882b9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2467260)
addappid(2565980)
addappid(2565990)
addappid(2566000)
addappid(2566010)
addappid(2644630)
addappid(2644640)
addappid(2644650)
addappid(2644660)
addappid(2688230)
addappid(2688240)
addappid(2688250)
addappid(2688260)
addappid(2718910)
addappid(2718920)
addappid(2718930)
addappid(2718940)
addappid(2743560)
