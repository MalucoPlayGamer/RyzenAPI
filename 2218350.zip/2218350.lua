-- Lua provided by RyzenAPI
-- Game: RPG Maker 3D Character Converter

-- MAIN APPLICATION
addappid(2218350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218351, 1, "a61a08c501aaa5d0511b409800394419abf13d8444e30111a603df8935c882b9")
