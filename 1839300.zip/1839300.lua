-- Lua provided by RyzenAPI
-- Game: ATC4: Airport NEW CHITOSE [RJCC]

-- MAIN APPLICATION
addappid(1839300)
-- Game: addappid(1839300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839300,0,"5029ce7eee68a5c2c481ed0f7dcdbcad0f9afcafeda1f21a827dcb1e92bef3ae")
