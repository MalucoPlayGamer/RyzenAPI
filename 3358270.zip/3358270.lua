-- Lua provided by RyzenAPI
-- Game: Galeid.

-- MAIN APPLICATION
addappid(3358270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358272,0,"273ea43733549b3377d8d16e90095498f77615c4c9f707d355374fd184e626c6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3360350)
