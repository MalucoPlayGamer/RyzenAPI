-- Lua provided by RyzenAPI
-- Game: 西游记口袋版

-- MAIN APPLICATION
addappid(2904050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904051, 1, "5072982b80b50befa0ca88e77839bd71f592718cd99380cd25b07c824ee4aa50")

