-- Lua provided by RyzenAPI
-- Game: AppID 3163930

-- MAIN APPLICATION
addappid(3163930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163931, 1, "bc98f6efc50bf2f531dece57d9f8449e06fc6d3cb2b015c9e8b3de34ca9b9ed7")

