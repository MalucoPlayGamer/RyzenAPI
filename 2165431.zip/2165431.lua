-- Lua provided by RyzenAPI
-- Game: 2165431

-- MAIN APPLICATION
addappid(2165431)
-- Game: addappid(2165431)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165431,0,"a16201fafdf5d7d0b600c1630284431db81205b4ac38fde070ef7ff95653ea2f")
