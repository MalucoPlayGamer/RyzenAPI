-- Lua provided by RyzenAPI
-- Game: addappid(2645820)

-- MAIN APPLICATION
addappid(2645820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645821, 1, "8db7e2fbe64836be25e151a11cf7d66537e9f1d91f2c1f82e6abbdf1b3a4c077")
