-- Lua provided by RyzenAPI
-- Game: Game: AppID 767110

-- MAIN APPLICATION
addappid(767110)
-- Game: addappid(767110)

-- MAIN APP DEPOTS / PACKAGES
addappid(767111, 1, "dc528a469dee1c1568a606795329dcbd45168b36744b5cef8dcc0b8e789e4558")
