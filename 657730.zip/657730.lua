-- Lua provided by RyzenAPI
-- Game: Wolflord - Werewolf Online

-- MAIN APPLICATION
addappid(657730)
addappid(718130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(657731, 1, "9937a36f594e7b27b1492a500ade0e677bdf37de26887f3e210937fd9f6ab097")
addappid(657732, 1, "f903f26bb35add2f5afa59c9204e8ce155bdb225cd9ccd6a5711250b1369e244")
