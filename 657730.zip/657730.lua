-- Lua provided by RyzenAPI
-- Game: 657730

-- MAIN APPLICATION
addappid(657730)
-- Game: addappid(657730)

-- MAIN APP DEPOTS / PACKAGES
addappid(657731, 1, "9937a36f594e7b27b1492a500ade0e677bdf37de26887f3e210937fd9f6ab097")
addappid(657732, 1, "f903f26bb35add2f5afa59c9204e8ce155bdb225cd9ccd6a5711250b1369e244")
