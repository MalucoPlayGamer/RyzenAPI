-- Lua provided by RyzenAPI
-- Game: 945710

-- MAIN APPLICATION
addappid(945710)
-- Game: addappid(945710)

-- MAIN APP DEPOTS / PACKAGES
addappid(945711, 1, "2e9ef743e6601a105ebcaf4f19e48ea65955cf9dae1a058534a7629869cd07d1")
addappid(1359590, 0, "7f23eaab7da942825ad18236e285de76df414aa7a7247719260a54fbf7670f12")
