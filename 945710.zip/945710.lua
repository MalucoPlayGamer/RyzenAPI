-- Lua provided by RyzenAPI
-- Game: DreadOut 2

-- MAIN APPLICATION
addappid(945710)

-- MAIN APP DEPOTS / PACKAGES
addappid(945711, 1, "2e9ef743e6601a105ebcaf4f19e48ea65955cf9dae1a058534a7629869cd07d1")
addappid(1359590, 0, "7f23eaab7da942825ad18236e285de76df414aa7a7247719260a54fbf7670f12")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
