-- Lua provided by RyzenAPI
-- Game: addappid(259960)

-- MAIN APPLICATION
addappid(259960)

-- MAIN APP DEPOTS / PACKAGES
addappid(259961, 1, "75fa7da65fbc3dff8a45f6a75d54bc5930e12a1aecb047816b1dd02f2b2e8981")
