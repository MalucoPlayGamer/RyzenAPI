-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 3

-- MAIN APPLICATION
addappid(259960)

-- MAIN APP DEPOTS / PACKAGES
addappid(259961, 1, "75fa7da65fbc3dff8a45f6a75d54bc5930e12a1aecb047816b1dd02f2b2e8981")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
