-- Lua provided by RyzenAPI
-- Game: AppID 724570

-- MAIN APPLICATION
addappid(724570)
addappid(1010280)

-- MAIN APP DEPOTS / PACKAGES
addappid(724571, 1, "be97355ad98a1c3ea74fd57517bd89044ad9d00d4d56b2f2fef4e4e4ec36cf8c")
