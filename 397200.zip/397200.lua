-- Lua provided by RyzenAPI
-- Game: AppID 397200

-- MAIN APPLICATION
addappid(397200)
-- Game: addappid(397200)

-- MAIN APP DEPOTS / PACKAGES
addappid(397201, 1, "5fc6f437ee4d6c77034c5b5485719bfa985051ab48d91f0d610714fe2571216a")
