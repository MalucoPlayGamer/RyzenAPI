-- Lua provided by RyzenAPI
-- Game: Game: 幸存者幻想曲 Survivor Fantasia

-- MAIN APPLICATION
addappid(2717050)
-- Game: addappid(2717050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717051, 1, "0243298a747db61f6546cb9e4bb930ccd7695b54d4ea1d459b61059f667102c3")
