-- Lua provided by RyzenAPI
-- Game: Brave's Rage

-- MAIN APPLICATION
addappid(1124080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124081, 1, "6828c6ad68d092495c452ffb132f8ac3ff5f229287bfe87dc8662689ea02e291")

