-- Lua provided by RyzenAPI
-- Game: Asdivine Knot

-- MAIN APPLICATION
addappid(4790410) -- Asdivine Knot
addappid(4829720) -- Experience x3 - Asdivine Knot
addappid(4829730) -- SP x3 - Asdivine Knot
addappid(4829740) -- Experience  SP x2 - Asdivine Knot
addappid(4829750) -- Damage x2 - Asdivine Knot

-- MAIN APP DEPOTS / PACKAGES
addappid(4790411, 1, "31ced7847f6056bb2841f15c3b333a1745ac2fc4e6d991cca00171f04e3e415c") -- Depot 4790411
