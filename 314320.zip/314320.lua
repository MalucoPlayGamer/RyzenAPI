-- Lua provided by SkyAPI 
-- Game: GamersGoMakers
addappid(314320)
addappid(314321, 1, "a45f9f7092e62b2a98efb079217e1405eec09db76c8b577f691176d523d3d594")
