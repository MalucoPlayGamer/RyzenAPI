-- Lua provided by RyzenAPI
-- Game: Game: Awaria

-- MAIN APPLICATION
addappid(3274300)
addappid(3394230)
-- Game: addappid(3274300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274301, 1, "8bf89ecc4754d7b53f8c70589870618db3ed959f8c6ade3fbe233bf74f03e10e")
addappid(3274303, 1, "8480b04dd77d60e6c5287b1b27e1320413183761711fbb0dd7dc97edf100bc78")
addappid(3274305, 1, "d21ebd94979776030ba59bc29369a9f928a915a7337a162e2af575fd4e8c2db4")
