-- Lua provided by RyzenAPI
-- Game: 1703470

-- MAIN APPLICATION
addappid(1703470)
-- Game: addappid(1703470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703471, 1, "c955ea0bd77efa83ba2bc30c97b46e50b4bdfaeb47a7ab56d7d982d3a192ee09")
