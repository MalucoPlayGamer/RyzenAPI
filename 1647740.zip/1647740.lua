-- Lua provided by RyzenAPI
-- Game: 1647740

-- MAIN APPLICATION
addappid(1647740)
-- Game: addappid(1647740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647741, 1, "df8f1a2a0df95dce0683357c398cec72e3cb3cf2bea71d9c9547dc884930e23e")
