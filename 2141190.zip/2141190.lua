-- Lua provided by RyzenAPI
-- Game: Cruise Ship Manager Demo

-- MAIN APPLICATION
addappid(2141190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141191, 1, "6ef58f8b08f23a344f1850ddb9d2d6402385702851437a333073ddaad5d49db3")
