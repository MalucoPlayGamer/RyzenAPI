-- Lua provided by RyzenAPI
-- Game: Sexy Apocalypse Girls. Part I

-- MAIN APPLICATION
addappid(2754140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754142,0,"27f988f6fb65799d417ec6cfa185e00b282abd0d606939c577937145014bdd73")

