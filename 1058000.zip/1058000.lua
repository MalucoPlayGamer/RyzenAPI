-- Lua provided by RyzenAPI
-- Game: 雨的恋记

-- MAIN APPLICATION
addappid(1058000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058001, 1, "cfc892750f955358b2fa841f83f0dcb27f25c55c608cca906698ffcb3ab07a3d")

