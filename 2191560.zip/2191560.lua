-- Lua provided by RyzenAPI
-- Game: addappid(2191560)

-- MAIN APPLICATION
addappid(2191560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191561, 1, "8ff205008af8df2b4a498f5cd6e1c7fc99cd8d0d8cea901aef8e1dda358695f4")
