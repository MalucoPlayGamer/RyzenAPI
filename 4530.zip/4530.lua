-- Lua provided by RyzenAPI
-- Game: Full Spectrum Warrior: Ten Hammers

-- MAIN APPLICATION
addappid(4530)
-- Game: addappid(4530)

-- MAIN APP DEPOTS / PACKAGES
addappid(4531, 1, "26b1057c30817bbad7f65f15ca31dec3118af3f3fec7483ecc714403c1ac5bbe")
addappid(4532, 1, "11cf7c19441e8fd3744636b5e899481e5147db73a5b99a5117460e4936b164f5")
addappid(4533, 1, "50b9b2d7aa76535a17a11c9c67607e16c96e1e3e75d76fe510ff399a603fada7")
addappid(4534, 1, "1b111819dc834a762e936e818f2d950566f2e9bc2a0f9b2d676fd6f2645d6807")
addappid(4535, 1, "591a637109028b6b19ddfdde5606e8f878e180c8c8bfa2c18ad80928667a8b0b")
addappid(4536, 1, "b93615e5e7e9b09f3f46474fb7699406bfb569628eea02706737095610a56fab")
addappid(4537, 1, "aa599e43dd54b0bf06b2b0c7d454f9c043bd4cb1083efeed13192e8d4a4bb0bf")
