-- Lua provided by RyzenAPI
-- Game: It Comes In Waves

-- MAIN APPLICATION
addappid(2342980)
-- Game: addappid(2342980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342981, 1, "5a461d2951ac21ee987d16728d743e248098e3781a5f478c3aa1539de3ec27d8")
