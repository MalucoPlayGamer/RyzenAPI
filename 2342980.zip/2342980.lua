-- Lua provided by RyzenAPI
-- Game: It Comes In Waves

-- MAIN APPLICATION
addappid(2342980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2342981, 1, "5a461d2951ac21ee987d16728d743e248098e3781a5f478c3aa1539de3ec27d8")

