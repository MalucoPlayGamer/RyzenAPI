-- Lua provided by RyzenAPI
-- Game: Game: Contrast

-- MAIN APPLICATION
addappid(224460)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229001)
addappid(229031)
-- Game: addappid(224460)

-- MAIN APP DEPOTS / PACKAGES
addappid(224461, 1, "6700898a963bb78ec61fe6530cb21f0991ea7c4e32dbd7ec66e06b564dc728ab")
addappid(224462, 0, "2a8cf32a59cb44e2429ca5fd5e0319900bfb17fce689e6ba799405a9127407bf")
addappid(224463, 1, "6109ce6024d936cc7cb64fceff15ca34a70007ab18887352a48b355ad6226ed5")
addappid(224464, 1, "f2539107ad6c1254bfa4f5e5a0935389c2c0770fb4e7eb7eb1ee6ae3c52351b4")
