-- Lua provided by RyzenAPI
-- Game: 925910

-- MAIN APPLICATION
addappid(925910)
-- Game: addappid(925910)

-- MAIN APP DEPOTS / PACKAGES
addappid(925911, 1, "b758a24e2af00995f08f9a54bfa03c7ea3695fcbd607b66a974846b0792d0044")
