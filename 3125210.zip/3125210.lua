-- Lua provided by RyzenAPI
-- Game: Maiden Cops - Art Book

-- MAIN APPLICATION
addappid(3125210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125210,0,"415e532d7fc1cc3e263e4d80017075418e64e7d2589fe95310445153ec2e029d")

