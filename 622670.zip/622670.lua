-- Lua provided by RyzenAPI
-- Game: Game: AppID 622670

-- MAIN APPLICATION
addappid(622670)
-- Game: addappid(622670)

-- MAIN APP DEPOTS / PACKAGES
addappid(622671, 1, "24279c09bd9dba251d28e7d83265884587390fce80b7555b2527f681c807243e")
