-- Lua provided by RyzenAPI
-- Game: Huusuienbu - Chapter Spring and Summer

-- MAIN APPLICATION
addappid(622670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(622671, 1, "24279c09bd9dba251d28e7d83265884587390fce80b7555b2527f681c807243e")

