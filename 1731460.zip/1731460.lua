-- Lua provided by RyzenAPI
-- Game: LEGO® Brawls

-- MAIN APPLICATION
addappid(1731460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731461, 1, "c83939be400cd17d31bc1b24c72fdc5191bdc811be3abdb8efaca4c1bb497aa6")
