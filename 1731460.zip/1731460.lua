-- Lua provided by SkyAPI 
-- Game: LEGO® Brawls
addappid(1731460)
addappid(1731461, 1, "c83939be400cd17d31bc1b24c72fdc5191bdc811be3abdb8efaca4c1bb497aa6")
