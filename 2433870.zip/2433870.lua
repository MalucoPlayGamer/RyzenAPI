-- Lua provided by RyzenAPI
-- Game: 2433870

-- MAIN APPLICATION
addappid(2433870)
-- Game: addappid(2433870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433871, 1, "8374f59baab1a3408bb6644c933ab3d7a93db9f5dcc3b74d9e0abf931a0a02bd")
