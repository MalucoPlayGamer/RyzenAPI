-- Lua provided by RyzenAPI
-- Game: The Smurfs - Village Party

-- MAIN APPLICATION
addappid(2800630)
-- Game: addappid(2800630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800631, 1, "9ab00c9e6a7a696d67ecdea0f8df0e0c40915ce6634c815d018be1a84e307841")
