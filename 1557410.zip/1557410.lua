-- Lua provided by RyzenAPI
-- Game: BLACK WITCHCRAFT

-- MAIN APPLICATION
addappid(1557410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557411, 1, "0fb6c3a52cbe78ce8f6de537fd146cb12f176e8152b05a05eefbdb263b61e464")
addappid(2153340, 0, "24472f74c201e979802d5060a8faac72c2e4a1fe35f187d67074e3f2bb2537cb")
addappid(2153341, 0, "8def541a615d2c246e9159d2fad7ce13397f114b7d5584e8fdac637ea2ba5f8d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1569860)
addappid(2153342)
addappid(2153343)
