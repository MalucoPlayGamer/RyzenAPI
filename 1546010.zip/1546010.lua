-- Lua provided by RyzenAPI
-- Game: Game: Fallen girl - Black rose and the fire of desire

-- MAIN APPLICATION
addappid(1546010)
-- Game: addappid(1546010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546011, 1, "94cb5305129d131e57fc68bcb686f9bd95578b9c07476abba9488ec4245a6275")
addappid(1546012, 1, "c560e2b5cc929b7d3dd1936b6c54c44ea6d3f5eb641ef8496a72e50e5b251db0")
addappid(1637350, 0, "03c0396c030f05d77df2b528c0d02320804b395e3fad45c7af533ce0c40930df")
