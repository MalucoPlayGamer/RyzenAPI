-- Lua provided by RyzenAPI
-- Game: 👑 Idle Calibur 👑（选王之剑）

-- MAIN APPLICATION
addappid(1674890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674891, 1, "64e12c2aea80a055387a57a3861d12100ebae1a09fad360a5c14ce99c36c8d9f")
addappid(1674892, 1, "3dc9b9c74e431d02d895a4738a6657a616c984d8f104b9fcd09e9e887659b3e0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1701860)
addappid(1701861)
addappid(1701862)
