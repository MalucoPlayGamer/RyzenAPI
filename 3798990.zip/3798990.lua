-- Lua provided by RyzenAPI
-- Game: addappid(3798990)

-- MAIN APPLICATION
addappid(3798990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3798991, 1, "06a1baa84f5ec3c67ab20b1f3e988b7208533e6fbbbc7f7a2a934ee526a4dc26")
