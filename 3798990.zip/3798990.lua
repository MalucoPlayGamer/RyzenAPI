-- Lua provided by SkyAPI 
-- Game: Blood Sins Soundtrack
addappid(3798990)
addappid(3798991, 1, "06a1baa84f5ec3c67ab20b1f3e988b7208533e6fbbbc7f7a2a934ee526a4dc26")
