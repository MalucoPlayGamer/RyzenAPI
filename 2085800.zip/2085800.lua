-- Lua provided by RyzenAPI
-- Game: addappid(2085800)

-- MAIN APPLICATION
addappid(2085800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085801, 1, "c24783d663977db4d31bf7fe0e03ab150099689250935ee73bdc2e5b461d4be2")
