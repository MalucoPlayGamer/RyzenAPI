-- Lua provided by RyzenAPI
-- Game: Game: Robo Miner

-- MAIN APPLICATION
addappid(378570)
-- Game: addappid(378570)

-- MAIN APP DEPOTS / PACKAGES
addappid(378571, 1, "93fada97d75eb87e39af8262a370699073c641e5bf16194d26df504b66f2f0a9")
