-- Lua provided by RyzenAPI
-- Game: AppID 3231740

-- MAIN APPLICATION
addappid(3231740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231741, 1, "A5889F783DBC6C0C48A73B4EBE2FD05CD4D2974AE8935C4D03D8F0458D981823")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
