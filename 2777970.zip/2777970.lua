-- Lua provided by RyzenAPI
-- Game: Game: Stranger Things VR

-- MAIN APPLICATION
addappid(2777970)
-- Game: addappid(2777970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777971, 1, "db69f241a2a0de3ae864eab00d6fd4c3c0ddc80be0c781b69fa9c558f92101c1")
