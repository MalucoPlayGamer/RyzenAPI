-- Lua provided by RyzenAPI
-- Game: 2901290

-- MAIN APPLICATION
addappid(2901290)
-- Game: addappid(2901290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901291, 1, "4d2a43471a50d9c8509f0035ac1fc242d06bb460bddc0eaf0fc5debec8108555")
addappid(2901292, 1, "9c1d7d190381d3d024d49fd7a1489f9dbbf5ab2e0b1c6423ba537cdc5a09c92d")
