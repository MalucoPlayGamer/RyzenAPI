-- Lua provided by RyzenAPI
-- Game: addappid(816340)

-- MAIN APPLICATION
addappid(816340)

-- MAIN APP DEPOTS / PACKAGES
addappid(816342,0,"88b8bce19728b78e136f06be678e08bcb4469a3c8df937db17cbedd73fcffb0a")
addappid(816343,0,"6b1c5f682cf5d36e7d198f0316a703fddfa00b54e3ff9a3c0aa4cca82fce27d5")
addappid(816344,0,"c62c66327605b5290adf4186dbcd27c0e2359771a47b303019c452d8e18d9963")
