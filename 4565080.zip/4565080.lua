-- Lua provided by RyzenAPI
-- Game: Nightfall Empress

-- MAIN APPLICATION
addappid(4565080)

-- MAIN APP DEPOTS / PACKAGES
addappid(4565081,0,"33945aa7a3187f6e440a43fbe5eed38501e196041af38983509f38c27b984119")

