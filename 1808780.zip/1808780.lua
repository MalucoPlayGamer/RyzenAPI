-- Lua provided by RyzenAPI
-- Game: Game: 祖玛少女/Zuma Girls

-- MAIN APPLICATION
addappid(1808780)
-- Game: addappid(1808780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808781, 1, "14b0b79ed1d1c05754a7062917467d95b593dc47c807480b2066aab5ef3565f7")
addappid(1963550, 0, "3585bfe428963e2e3604c29bfb37ba69ba5e6fe157111c1c9b7ce11be94310ed")
