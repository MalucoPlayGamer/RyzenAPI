-- Lua provided by RyzenAPI
-- Game: 2248330

-- MAIN APPLICATION
addappid(2248330)
-- Game: addappid(2248330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248332,0,"7b582b092523bf76efb37236eb87a6753ce32e2553bee033388fdb83a8fdef39")
