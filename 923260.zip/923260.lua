-- Lua provided by RyzenAPI
-- Game: Golf Peaks

-- MAIN APPLICATION
addappid(923260)
-- Game: addappid(923260)

-- MAIN APP DEPOTS / PACKAGES
addappid(923261, 1, "7e708ebc2c921de89f1475c2a1ad1d6a52063bd8b7570539564964edf770c17d")
addappid(923262, 1, "0077fe7937feeae6b5e980f21e6454c6b32c703ca1f105cee7c52f88903f84f1")
