-- Lua provided by RyzenAPI
-- Game: Sethian

-- MAIN APPLICATION
addappid(432370)

-- MAIN APP DEPOTS / PACKAGES
addappid(432372,0,"8aa1016e85d17762c931cc8fdae8f4437d3861d3f7d697dcbfb28ba1c05f7af8")
