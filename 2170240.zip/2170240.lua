-- Lua provided by RyzenAPI
-- Game: 2170240

-- MAIN APPLICATION
addappid(2170240)
-- Game: addappid(2170240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170241, 1, "64f91f7cdd7062137ea0e349084a14e8150f35a1d66cb748305dfc39adac13ea")
