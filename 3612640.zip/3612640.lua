-- Lua provided by RyzenAPI
-- Game: Game: Infiniclick

-- MAIN APPLICATION
addappid(3612640)
-- Game: addappid(3612640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3612641, 1, "f6a97adb42f3cd033aa8ac6e8ce7770a1f56ecc07e5fc9aa483be49a3e16a2ff")
