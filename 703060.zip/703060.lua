-- Lua provided by RyzenAPI
-- Game: connect - Virtual Home (3D or VR)

-- MAIN APPLICATION
addappid(703060)

-- MAIN APP DEPOTS / PACKAGES
addappid(703061, 1, "9c4eacaae87afbbcef83f11be662b48f878247bad26219a7ee26c8afc7cebea0")
