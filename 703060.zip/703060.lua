-- Lua provided by RyzenAPI
-- Game: connect - Virtual Home (3D or VR)

-- MAIN APPLICATION
addappid(703060)

-- MAIN APP DEPOTS / PACKAGES
addappid(703061, 1, "9c4eacaae87afbbcef83f11be662b48f878247bad26219a7ee26c8afc7cebea0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
