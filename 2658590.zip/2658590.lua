-- Lua provided by RyzenAPI
-- Game: Game: Anger Of Peace 5

-- MAIN APPLICATION
addappid(2658590)
-- Game: addappid(2658590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658591, 1, "9c26a1505d33b952bdf4250569d8282af301726f191b99b87c2255c23010ea6a")
