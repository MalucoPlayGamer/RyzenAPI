-- Lua provided by RyzenAPI
-- Game: Anger Of Peace 5

-- MAIN APPLICATION
addappid(2658590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658591, 1, "9c26a1505d33b952bdf4250569d8282af301726f191b99b87c2255c23010ea6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
