-- Lua provided by RyzenAPI
-- Game: addappid(1872350)

-- MAIN APPLICATION
addappid(1872350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872351, 1, "6e3d762a37858f598e01a006b8f77f9d4b9bdd29291ceebfc7da855be46dc4bd")
