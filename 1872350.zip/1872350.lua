-- Lua provided by RyzenAPI
-- Game: FASTER

-- MAIN APPLICATION
addappid(1872350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872351, 1, "6e3d762a37858f598e01a006b8f77f9d4b9bdd29291ceebfc7da855be46dc4bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
