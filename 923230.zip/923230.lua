-- Lua provided by RyzenAPI
-- Game: AppID 923230

-- MAIN APPLICATION
addappid(923230)

-- MAIN APP DEPOTS / PACKAGES
addappid(923231, 1, "9607a2851cb867a7c45fbd6fd19e2da6f5f47adf60d03246077b7a9dcf43fe7b")

