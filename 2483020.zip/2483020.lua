-- Lua provided by RyzenAPI
-- Game: Game: Castle Of Alchemists Soundtrack

-- MAIN APPLICATION
addappid(2483020)
-- Game: addappid(2483020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483021, 1, "3f345509b9c40b7a0cc940cc3326ad17e89408f98cd92f227be71f2ef3597d68")
