-- Lua provided by SkyAPI 
-- Game: Castle Of Alchemists Soundtrack
addappid(2483020)
addappid(2483021, 1, "3f345509b9c40b7a0cc940cc3326ad17e89408f98cd92f227be71f2ef3597d68")
