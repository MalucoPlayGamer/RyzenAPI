-- Lua provided by RyzenAPI
-- Game: Game: NEKO-NIN exHeart +PLUS Nachi

-- MAIN APPLICATION
addappid(744520)
-- Game: addappid(744520)

-- MAIN APP DEPOTS / PACKAGES
addappid(744521, 1, "459015c8de6239b67aa3f5e7501aa3b1750af79fee603048533b64d9c8b65bed")
addappid(947710, 0, "b179409c1fc3c6cdda54584250cd55a896227ee851fef2d752b3be3310df4829")
