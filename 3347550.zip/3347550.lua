-- Lua provided by RyzenAPI
-- Game: Game: Trench Tales Playtest

-- MAIN APPLICATION
addappid(3347550)
-- Game: addappid(3347550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347551, 1, "44e2e582fe826d910c8823091d15dc7dcecae33485be5688f733e281b198f878")
