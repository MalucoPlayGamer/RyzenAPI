-- Lua provided by SkyAPI 
-- Game: Trench Tales Playtest
addappid(3347550)
addappid(3347551, 1, "44e2e582fe826d910c8823091d15dc7dcecae33485be5688f733e281b198f878")
