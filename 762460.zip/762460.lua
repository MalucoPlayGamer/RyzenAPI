-- Lua provided by RyzenAPI
-- Game: 762460

-- MAIN APPLICATION
addappid(762460)
-- Game: addappid(762460)

-- MAIN APP DEPOTS / PACKAGES
addappid(762461, 1, "7e8f0245d29b15029a97e46d55ffb3fdad06249a10c6de3a0688c3e99541e30c")
