-- Lua provided by RyzenAPI
-- Game: Game: Torn Away Demo

-- MAIN APPLICATION
addappid(1718620)
-- Game: addappid(1718620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718621, 1, "d7195d3f0b9c2054d1e8407f4288c66659436bbdd7a381c40a5b5c901908adf3")
