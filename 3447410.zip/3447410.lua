-- Lua provided by RyzenAPI
-- Game: AppID 3447410

-- MAIN APPLICATION
addappid(3447410)
-- Game: addappid(3447410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3447411, 1, "89ff5931fc303265c3de059dd23913809a98a80428cae9a81cedd1745d8041b7")
