-- Lua provided by RyzenAPI
-- Game: The Test: Reality Check

-- MAIN APPLICATION
addappid(3447410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3447411, 1, "89ff5931fc303265c3de059dd23913809a98a80428cae9a81cedd1745d8041b7")

