-- Lua provided by RyzenAPI
-- Game: Go Away My Fat

-- MAIN APPLICATION
addappid(788150)

-- MAIN APP DEPOTS / PACKAGES
addappid(788151, 1, "74b570d4a5753fbe045cb8f2ec410beb24371e60bb6fb4c597b3ca216f91decc")
