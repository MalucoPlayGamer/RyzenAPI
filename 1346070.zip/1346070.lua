-- Lua provided by RyzenAPI
-- Game: Sign of Silence

-- MAIN APPLICATION
addappid(1346070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346071, 1, "a3cabfcdae29474dc44c9b98bf22acdbcd3fa4c435b9258200c9b91d98f216b1")
