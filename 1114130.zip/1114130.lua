-- Lua provided by RyzenAPI
-- Game: Game: AppID 1114130

-- MAIN APPLICATION
addappid(1114130)
-- Game: addappid(1114130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114131, 1, "2af1e54f4b15b86203b7724cb6f589630cdf803b3eecece5dcfc7baf47d1b61a")
