-- Lua provided by SkyAPI 
-- Game: AppID 1114130
addappid(1114130)
addappid(1114131, 1, "2af1e54f4b15b86203b7724cb6f589630cdf803b3eecece5dcfc7baf47d1b61a")
