-- Lua provided by RyzenAPI
-- Game: addappid(676760)

-- MAIN APPLICATION
addappid(676760)

-- MAIN APP DEPOTS / PACKAGES
addappid(676761, 1, "83a00da6032b06ad11f0ccf731ac24cd06b6e3adb52bdc41616dbd057cf3b9b1")
