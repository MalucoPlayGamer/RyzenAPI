-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - EX Graphic Base Set Dungeon

-- MAIN APPLICATION
addappid(3495940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495940,0,"e80e236c8bb51deb966123c6b52ba83f5c8869b8d410b153a80dbb41eb65c3f5")

