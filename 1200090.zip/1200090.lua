-- Lua provided by RyzenAPI
-- Game: Game: AppID 1200090

-- MAIN APPLICATION
addappid(1200090)
-- Game: addappid(1200090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200091, 1, "b67173194d922403ba82dffd1f6148c8682929969145bdb719ca697aaedee7b0")
