-- Lua provided by RyzenAPI
-- Game: 99 Fails Lite

-- MAIN APPLICATION
addappid(2008060)
-- Game: addappid(2008060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008061, 1, "cf1222c65a75c18364d2e021468adaebaf5821a62b6b18cf22cac4de8c838d64")
addappid(2008062, 1, "ae5f9fd6dbbc11f626375e2114be4cfa0004d277a399e1a2631cdd99b68399fc")
