-- Lua provided by RyzenAPI
-- Game: Boss Rush: Mythology

-- MAIN APPLICATION
addappid(1237870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237871, 1, "8101ec9cd2bc88fe7bf77d5c10a9e99ed7c5564a7a05a1d4b8149dc1fdaeef9b")

