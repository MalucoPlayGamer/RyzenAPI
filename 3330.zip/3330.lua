-- Lua provided by RyzenAPI
-- Game: Zuma Deluxe

-- MAIN APPLICATION
addappid(3330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331, 1, "ee29d66bb30053c1ff08964ca6b256fc482c3ee0aeeeaa5bca902805859c9af4")
addappid(3333, 1, "3f2567df36ec438057609c9fbd830c03a461a6553f6ac5b82cf61d8e1da1b9bc")
addappid(3334, 1, "2f2f369e198f09aa041d8bdef9314836680de2ca9e4bd0b48cd9dab3b4695509")
addappid(3335, 1, "d0de2859c7047d53964fabcf0e86a762ccb940d7ed05986879785a1004a3b25a")
addappid(3336, 1, "2855ed6624a5b0f9ed48c93d928bed31c14fec354edd7844e2cc3dc351757abc")
addappid(3337, 1, "527fc27eddf2df1968835c2bdab4456b6adb65c1388fd99ee00891a4a4025410")

