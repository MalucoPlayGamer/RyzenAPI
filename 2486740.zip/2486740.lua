-- Lua provided by RyzenAPI
-- Game: Sledders

-- MAIN APPLICATION
addappid(2486740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486741, 1, "4144067d33e34965671b4aabd42b033e11a077b35d90afe33d67a4371b540f6a")

