-- Lua provided by RyzenAPI
-- Game: Bleak Frontier

-- MAIN APPLICATION
addappid(2474930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474931, 1, "b7cd7e770619123f34817a47fbe208f402f61bb38bd0688b771bff205aa838ff")
