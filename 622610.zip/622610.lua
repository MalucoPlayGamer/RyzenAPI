-- Lua provided by RyzenAPI
-- Game: Cult: Fear Inside

-- MAIN APPLICATION
addappid(622610)

-- MAIN APP DEPOTS / PACKAGES
addappid(622611, 1, "9b2cf1a04d6790762a70afe024cd5e65522e9f3e24069ceab48c5fe4c08feaac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
