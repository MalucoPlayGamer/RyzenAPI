-- Lua provided by RyzenAPI
-- Game: Cult: Fear Inside

-- MAIN APPLICATION
addappid(622610)
-- Game: addappid(622610)

-- MAIN APP DEPOTS / PACKAGES
addappid(622611, 1, "9b2cf1a04d6790762a70afe024cd5e65522e9f3e24069ceab48c5fe4c08feaac")
