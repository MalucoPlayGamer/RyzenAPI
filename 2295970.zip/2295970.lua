-- Lua provided by RyzenAPI
-- Game: UFO ROBOT GRENDIZER – The Feast of the Wolves

-- MAIN APPLICATION
addappid(2295970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295971, 1, "aea4ca56c25a7bc1b3f86e2db5d0be7151d7e136be82005b9baae7bbb1053e1d")
