-- Lua provided by RyzenAPI
-- Game: UFO ROBOT GRENDIZER – The Feast of the Wolves

-- MAIN APPLICATION
addappid(2295970)
addappid(2438720)
addappid(2438721)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2295971, 1, "aea4ca56c25a7bc1b3f86e2db5d0be7151d7e136be82005b9baae7bbb1053e1d")

