-- Lua provided by RyzenAPI
-- Game: Abyss Of Pleasure

-- MAIN APPLICATION
addappid(3251270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251271, 1, "4c147c851357cc13b11a6d32f023759a4e3ac5aaec722a7ce981e9d2e8f7fd83")
addappid(3251272, 1, "4b18df56f2b67f22f929dfa13b19191c015b6a32983885ed8c5d16f84ed18082")

