-- Lua provided by RyzenAPI
-- Game: AppID 331920

-- MAIN APPLICATION
addappid(331920)

-- MAIN APP DEPOTS / PACKAGES
addappid(331921, 1, "dd4f26873d7eb98ac6aeb594b144c6e0ecafb3546cc2b99c13a8a513d58c4f85")
addappid(331922, 1, "588c26a9c507a300a286471860697ca3dbcd8ba65d18ad0ac59c1b5f50a1ca6f")
addappid(331923, 1, "0f1e96bb6b2c64f8077bcaba3614c5f544b49fa62845b4ec8c917bdb8c2055b8")
addappid(331924, 1, "1c1e0fb8fb717422bcdf5fbc2819fdeb930d0568efd681ad5a4c30175657bce4")
addappid(331925, 1, "8153d7ff8d6de48ac6e2071f3cf6c0f187c137df400d6e80d8d360dd0ced5a82")
addappid(331926, 1, "6c2b18341d4a9e38c9c12ee21b97b31ea53dd12c1de439882a5bfefc5cadda4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
