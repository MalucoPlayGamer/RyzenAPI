-- Lua provided by RyzenAPI
-- Game: Programming Without Coding Technology 2.0

-- MAIN APPLICATION
addappid(1953110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953111, 1, "1dc249c51295960a93cef504c0a7b2e2168682e664bdfc86759220b5653f66e6")
