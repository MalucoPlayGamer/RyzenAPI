-- Lua provided by RyzenAPI
-- Game: TEVI

-- MAIN APPLICATION
addappid(2230650)
addappid(4553760)
addappid(4566250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230651, 1, "cf4bd9819dcbe55a664cd8774f36ed68fb0bcff0071c1600b939704a3b7df38f")

