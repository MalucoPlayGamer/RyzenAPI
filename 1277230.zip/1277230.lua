-- Lua provided by RyzenAPI
-- Game: addappid(1277230)

-- MAIN APPLICATION
addappid(1277230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277232,0,"d00bca52d1b44d8a46b11fda10471e9b14de8ed661ef0809d87ed6b02cd98525")
