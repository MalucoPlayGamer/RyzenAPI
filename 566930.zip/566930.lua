-- Lua provided by RyzenAPI
-- Game: Rescue Team 6 Collector's Edition

-- MAIN APPLICATION
addappid(566930)

-- MAIN APP DEPOTS / PACKAGES
addappid(566931,0,"7de3e55fbfc04585201124e2f9e4491835584ceee700cef1051e25b642d092df")
addappid(566932,0,"b68451751c167c5ee1e5026fa9a0fbe6c094865553ab3a62affd2a4cb8ebd4b3")
addappid(566933,0,"24dabad34887431761cca27ba8b8e85ddb0d48ef1e85ea60e57fc2eaa0a7c43c")

