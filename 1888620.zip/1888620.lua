-- Lua provided by RyzenAPI
-- Game: Save The Bear Cubs

-- MAIN APPLICATION
addappid(1888620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888621, 1, "e011a2a98a2ace24eac624f825d6dfb3752a9069be09da6e848c118bbb1944bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
