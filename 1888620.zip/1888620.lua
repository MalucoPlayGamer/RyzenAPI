-- Lua provided by RyzenAPI
-- Game: Save The Bear Cubs

-- MAIN APPLICATION
addappid(1888620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888621, 1, "e011a2a98a2ace24eac624f825d6dfb3752a9069be09da6e848c118bbb1944bf")

