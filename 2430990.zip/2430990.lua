-- Lua provided by RyzenAPI 
-- Game: Their Land
addappid(2430990)
addappid(2430991, 1, "fb75ad5701873a67e493ee1807a6c1e4b06745782edbb03e00725bf51614276d")
