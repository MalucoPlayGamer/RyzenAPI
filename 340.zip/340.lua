-- Lua provided by RyzenAPI
-- Game: 340

-- MAIN APPLICATION
addappid(340)
-- Game: addappid(340)

-- MAIN APP DEPOTS / PACKAGES
addappid(341, 1, "b1ecfe9865c3c7f4b38e95f78fb4f0598ccb241c80f0807c4a77c4a4f90c8fb0")
addappid(342, 1, "52cf71d5565827f8909429a2ace5696a5b82ddad568fb805c98690a1c5a0f5a4")
addappid(343, 1, "2412a0a1ef3d7364d72d5b0d923447bcb95bd30fbcdeaa872936da60b0c8422b")
addappid(344, 1, "87b42652fa48ca6646de63aeca37589717d5db46659d42449b0d9e1225f89558")
addappid(345, 1, "692d691055830dd04b3cddcc1a7bf9d5621b09a9269ba5fa2458cee493567acd")
addappid(346, 1, "ccd14320e7e90a810f3b0088e5fff475747ff5c8972239b4b10effdb47213cf7")
addappid(347, 1, "41d9664bf0b420e947409d9e4713e6bc92eea588ee26933c9775d6ca1bdcdfd1")
addappid(348, 1, "5f822c359d28f01a58cc40326cc2e9359da0cab42ac3636942eb27d42b82bce2")
