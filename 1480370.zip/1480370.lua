-- Lua provided by RyzenAPI
-- Game: 1480370

-- MAIN APPLICATION
addappid(1480370)
-- Game: addappid(1480370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480371, 1, "0918a8c760e0d281c935c79ab670ca2c644f2941ae64b0283b6ca3e410113e05")
addappid(1490200, 0, "e3c22accfebc79a4ad4cfc80326b75aa4d034ebcf954537fbc16d03f406173e1")
