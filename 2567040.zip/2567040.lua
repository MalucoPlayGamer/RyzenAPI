-- Lua provided by RyzenAPI
-- Game: Game: Only UP

-- MAIN APPLICATION
addappid(2567040)
-- Game: addappid(2567040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567041, 1, "f7756cc0c7d88ad26285b70f22e0a201028d2303864645703e8ff6432495887d")
