-- Lua provided by RyzenAPI
-- Game: Only UP

-- MAIN APPLICATION
addappid(2567040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567041, 1, "f7756cc0c7d88ad26285b70f22e0a201028d2303864645703e8ff6432495887d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
