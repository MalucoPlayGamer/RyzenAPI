-- Lua provided by SkyAPI 
-- Game: Wargs
addappid(766210)
addappid(766211, 1, "62788e16f766c87de4e31a53df2a063286b21f93c18e0468dffff941e32ee89f")
