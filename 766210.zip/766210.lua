-- Lua provided by RyzenAPI
-- Game: Wargs

-- MAIN APPLICATION
addappid(766210)

-- MAIN APP DEPOTS / PACKAGES
addappid(766211, 1, "62788e16f766c87de4e31a53df2a063286b21f93c18e0468dffff941e32ee89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
