-- Lua provided by RyzenAPI 
-- Game: AppID 906340
addappid(906340)
addappid(906341, 1, "cc03e3a3920c0bcb8c79a24fe0805e7e34b7991997e6fb6eeb3cf5267fd3481a")
