-- Lua provided by RyzenAPI
-- Game: Meteor

-- MAIN APPLICATION
addappid(912790)

-- MAIN APP DEPOTS / PACKAGES
addappid(912791, 1, "8dad4d9523d65d52cb80d76bb6c8352c060755401a15b9bd749b8a352d1242ad")
addappid(912792, 1, "53f993fbca3b21a28a2d22fd5f635e0102a1408b47c3d9850325c6acb982cfdb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
