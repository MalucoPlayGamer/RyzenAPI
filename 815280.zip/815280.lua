-- Lua provided by RyzenAPI
-- Game: Crooked Waters

-- MAIN APPLICATION
addappid(815280)

-- MAIN APP DEPOTS / PACKAGES
addappid(815281, 1, "7d2ea0d3b448d1bfb73606deac65e307c17365e3cb9dddc671085696695bf760")

