-- Lua provided by RyzenAPI
-- Game: The Lamplighters League - Original Soundtrack

-- MAIN APPLICATION
addappid(2244711)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244711,0,"5fc91da962403e2a1f9c903d7e8b21062ec7486cc28e2ebc490ae3157531ef42")

