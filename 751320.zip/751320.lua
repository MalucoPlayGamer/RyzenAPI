-- Lua provided by RyzenAPI
-- Game: Echo

-- MAIN APPLICATION
addappid(751320)
-- Game: addappid(751320)

-- MAIN APP DEPOTS / PACKAGES
addappid(751321, 1, "b0e9b31725f060e5ab5c1d1d5590717d24e16538538399ced18634eb977bbf59")
addappid(751324, 1, "50d8931e92bebd6f2b24cd7c0bd313247b57ca7aa973690461ac098a71ac40c1")
addappid(751325, 1, "36c8aba7f2533e14fae78c7274a39d3bddf70561adb744a237e66f385eab4b91")
