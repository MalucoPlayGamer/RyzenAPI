-- Lua provided by RyzenAPI
-- Game: addappid(862790)

-- MAIN APPLICATION
addappid(862790)

-- MAIN APP DEPOTS / PACKAGES
addappid(862791, 1, "0db141e575807c2af255012606a3775e723b58f2a63afeecddd5e3ed06133777")
