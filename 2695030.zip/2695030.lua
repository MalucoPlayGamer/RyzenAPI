-- Lua provided by RyzenAPI
-- Game: 2695030

-- MAIN APPLICATION
addappid(2695030)
-- Game: addappid(2695030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695033,0,"439ed8ed5bf9551c5a5a79e67c2efa80c0bac717cf223698f0b8fb6f6007d3f2")
