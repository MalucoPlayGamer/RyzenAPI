-- Lua provided by RyzenAPI
-- Game: Grid Legion

-- MAIN APPLICATION
addappid(504620)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(504621, 1, "52193cdc10aa4e035b68811548fbe787cbe3b40ca6199de48200ba391d8dfd90")

