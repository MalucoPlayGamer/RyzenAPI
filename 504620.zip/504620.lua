-- Lua provided by RyzenAPI
-- Game: 504620

-- MAIN APPLICATION
addappid(504620)
-- Game: addappid(504620)

-- MAIN APP DEPOTS / PACKAGES
addappid(504621, 1, "52193cdc10aa4e035b68811548fbe787cbe3b40ca6199de48200ba391d8dfd90")
