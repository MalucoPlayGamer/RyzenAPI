-- Lua provided by RyzenAPI
-- Game: 2741440

-- MAIN APPLICATION
addappid(2741440)
-- Game: addappid(2741440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741441, 1, "283949f18ab6a1d0dce28cf8e335e6c0a83c4f6b956ce5194aec472d88e6313f")
