-- Lua provided by RyzenAPI
-- Game: Red Orchestra Beta

-- MAIN APPLICATION
addappid(1210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211, 1, "86e656533389ea5d8559926e793e70d1bb363972411e4f2a704010db80937299")
