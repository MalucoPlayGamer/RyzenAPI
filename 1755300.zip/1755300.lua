-- Lua provided by RyzenAPI
-- Game: Game: Smart Factory Tycoon

-- MAIN APPLICATION
addappid(1755300)
-- Game: addappid(1755300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755301, 1, "398b347f65c0280a05bf2144d74fd01740175145d70a2bde950bd75da77461e0")
