-- Lua provided by SkyAPI 
-- Game: Smart Factory Tycoon
addappid(1755300)
addappid(1755301, 1, "398b347f65c0280a05bf2144d74fd01740175145d70a2bde950bd75da77461e0")
