-- Lua provided by RyzenAPI
-- Game: addappid(392050)

-- MAIN APPLICATION
addappid(392050)

-- MAIN APP DEPOTS / PACKAGES
addappid(392051, 1, "cd992b35662eb1ff04e2e7d02a15f12ba08df292366bb9965db7ed12a7a810c1")
