-- Lua provided by RyzenAPI
-- Game: Company of Heroes 3: Final Stand

-- MAIN APPLICATION
addappid(4836540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1677281,0,"946c1091854e4b36a1468dea11adb8fe4fe6db6485976132a50781a70d5a206e")
addappid(1677282,0,"2dbe642c09395dcb0cfab68ff34eca066c3f47e38d8511d59509fb60cf7c665a")
addappid(1677283,0,"532412e59c494bd36e8efc9d4e257208e7412c8a70b16f206103f3913d4add50")
addappid(4836541,0,"7515c0af49aad4cf3ae885c6eef73087d477cef8b7383d891d439082c36b0e86")

