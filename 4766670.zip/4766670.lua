-- Lua provided by RyzenAPI
-- Game: 幻兽纪元

-- MAIN APPLICATION
addappid(4766670)

