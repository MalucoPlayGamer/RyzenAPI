-- Lua provided by RyzenAPI
-- Game: Overpass 2

-- MAIN APPLICATION
addappid(1830630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830631, 1, "bcdd613d7c66aee792689b500e53e07d58c7d49a49f1d5bbf858fb6bde8f9ff6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2432400)
addappid(2432401)
addappid(2461590)
