-- Lua provided by RyzenAPI
-- Game: 1830630

-- MAIN APPLICATION
addappid(1830630)
-- Game: addappid(1830630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830631, 1, "bcdd613d7c66aee792689b500e53e07d58c7d49a49f1d5bbf858fb6bde8f9ff6")
