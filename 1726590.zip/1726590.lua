-- Lua provided by RyzenAPI
-- Game: Marble Mage

-- MAIN APPLICATION
addappid(1726590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1726591,0,"018085cd90ad366aa0cd2bc646d73fff7c7c29ea7fdfee14a6f60e67799383f0")
addappid(1726592,0,"3a5c4ae6429e3649555ba81a1b7d296a755cd8ef0f2dcbe4bb2a56775fa4fa9d")

