-- Lua provided by RyzenAPI
-- Game: National Park Girls: Love Our Parks Edition

-- MAIN APPLICATION
addappid(1036580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036581, 1, "4ae7cb26db14612c97d3751c323e81fcace593eadf39ee2dc776d82f1a4905da")
addappid(1167520, 0, "073ca6545aad655b477210cb454248045a1684074091eb86d54fde0e7e0d4102")
addappid(1167522, 0, "b5da2aed1f0f7fe2127118f4299a1384555484beb3d650fb4823f711b0383656")
addappid(2310480, 0, "c4a65b94a25f1a56775251b6beb56c473d13f7a937f615eada1235742e62f30f")
addappid(2578730, 0, "90ddf7d659d61d667ad15039f669faf23ee4155b7b7504c52208a889abfe6aa3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1448920)
addappid(1693720)
