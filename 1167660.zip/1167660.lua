-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! at the Disco - "The Greatest Show"

-- MAIN APPLICATION
addappid(1167660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167660,0,"92c8bc073f38d6c50af7ed9dc052247a45073b4c3ae868c6a18068df989b6aa8")
