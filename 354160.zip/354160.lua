-- Lua provided by RyzenAPI
-- Game: AppID 354160

-- MAIN APPLICATION
addappid(354160)

-- MAIN APP DEPOTS / PACKAGES
addappid(354161, 1, "1a602f2de1feb381519e2b1b0fa88512ca3aa8aa1712dac61435f6f0aef880cf")
addappid(398472, 0, "c841e22c0becf54df19c8107a2a308891754f86a87f40f623e76b2ee7f6f85b6")
addappid(398473, 0, "a20af39cece5ea5a05056da0ce99075cebf5e37876fb9f74ad9ad4b1cd665470")

