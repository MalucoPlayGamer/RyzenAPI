-- Lua provided by SkyAPI 
-- Game: SomnaBuster
addappid(2598190)
addappid(2598191, 1, "936291f263e1c2c9506b9e969d3beb037aa981c221061f5a604f534d5ea2ed55")
