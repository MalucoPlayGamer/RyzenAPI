-- Lua provided by RyzenAPI 
-- Game: Cube Destroyer
addappid(440760)
addappid(440761, 1, "a1ebb1f494fb283129e3cfe255f76ef8a9f50ebcac8d3290e17c4f9e976597f5")
