-- Lua provided by SkyAPI 
-- Game: KASIORI
addappid(2926230)
addappid(2926231, 1, "d2207e2f3035085933635c02c39eeb4f29d93b8f6f9148d605d7108746808716")
