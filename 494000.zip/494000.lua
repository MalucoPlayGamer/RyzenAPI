-- Lua provided by RyzenAPI
-- Game: addappid(494000)

-- MAIN APPLICATION
addappid(494000)

-- MAIN APP DEPOTS / PACKAGES
addappid(494001, 1, "37527c515ce2edbea9481b888a109fc1ac52d9257329fb4a3bc9635edd13f524")
addappid(494002, 1, "c2da50e03cbdd3ecf5556fda97fd0a15dd2184a107e2e7abd72c6834017ca892")
