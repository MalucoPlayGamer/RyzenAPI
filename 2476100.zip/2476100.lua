-- Lua provided by RyzenAPI
-- Game: Creepy Tale: Some Other Place

-- MAIN APPLICATION
addappid(2476100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476101, 1, "f8eb6225ed9ede179b94d565c6dbc1080e5fc13de7125e39c2d88e501946a841")
