-- Lua provided by RyzenAPI
-- Game: Ninja Infiltration

-- MAIN APPLICATION
addappid(2762940)
-- Game: addappid(2762940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762941, 1, "2004e6374ab2a73591be253678ffb7406ba6c9a931f75b471e1a07ed860f7d7e")
addappid(2762942, 1, "29ac14a3030d4a7ca2a9b021dfad766774f915ebcc923de2a58903acc1bec640")
addappid(2762943, 1, "84148b9a61ecdc9faa76b60b8fe83dbf6368f3dcd39720ee314b84512a0a08ee")
addappid(2762944, 1, "11497b43a2c7367253d304d4c89886279661c3adc91833b47d5f070ba79cb667")
