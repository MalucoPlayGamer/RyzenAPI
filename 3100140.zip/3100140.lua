-- Lua provided by RyzenAPI
-- Game: addappid(3100140)

-- MAIN APPLICATION
addappid(3100140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100141, 1, "1f9d18ed72dc45ef49997c701e605372bc4f7728d3bab76328077de133346bae")
