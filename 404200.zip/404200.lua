-- Lua provided by RyzenAPI 
-- Game: WARTILE
addappid(404200)
addappid(404201, 1, "269e536d3e462095abb876ceec39861b1d56c98b254a82258a2c0e85c4529602")
addappid(651530, 0, "d4f457ffd6e471807505b19eda98fca03aa7e360535a61e2bb96267a544142bc")
