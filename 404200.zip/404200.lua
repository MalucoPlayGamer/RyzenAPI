-- Lua provided by RyzenAPI
-- Game: WARTILE

-- MAIN APPLICATION
addappid(404200)
addappid(1078030)
addappid(2272460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(404201, 1, "269e536d3e462095abb876ceec39861b1d56c98b254a82258a2c0e85c4529602")
addappid(651530, 0, "d4f457ffd6e471807505b19eda98fca03aa7e360535a61e2bb96267a544142bc")

