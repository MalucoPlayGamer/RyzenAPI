-- Lua provided by RyzenAPI
-- Game: AppID 1183470

-- MAIN APPLICATION
addappid(1183470)
addappid(3474490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183471, 1, "5ec29a80abd8a4a77e898b8a8e47fa1f3f5ab567a29f7b61de5427182cc2e8f2")
addappid(1404250, 0, "5ffa3eb463ab1060f94b885627da1cce03f6802fd7ec65cc20d67c535b5dc646")
addappid(1520480, 0, "ddc4be7964683013b7e72e8964e4e5bfb29443eddb5a7b77612f1dee241145b3")
addappid(1839160, 0, "510aa73ef8c2a728b930ae1498a87c00f387059689ba70e2892b471db0a4ecb6")
addappid(2250440, 0, "09425a1db342837a7b8b744b938520e7ea7004be15984b12b6c1842c668f33d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3526220)
