-- Lua provided by RyzenAPI
-- Game: 1394850

-- MAIN APPLICATION
addappid(1394850)
-- Game: addappid(1394850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394851, 1, "7db4563dcc82c24fcaad8399dc60aa1e8b8adb4e43273788b8823ade959d8642")
