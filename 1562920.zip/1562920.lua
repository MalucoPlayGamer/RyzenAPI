-- Lua provided by RyzenAPI
-- Game: 7 Years From Now

-- MAIN APPLICATION
addappid(1562920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562921, 1, "235a8632e8dc285dda762bbbf565d23fa30d2e2995d04da43c8861be2716ed2d")