-- Lua provided by RyzenAPI
-- Game: 3365740

-- MAIN APPLICATION
addappid(3365740)
-- Game: addappid(3365740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365741, 1, "d87840df1607aa1fdd04c5d70fc7ebfd02b939041a625f002464b3c2e77c8f84")
