-- Lua provided by SkyAPI 
-- Game: Death Howl Demo
addappid(3365740)
addappid(3365741, 1, "d87840df1607aa1fdd04c5d70fc7ebfd02b939041a625f002464b3c2e77c8f84")
