-- Lua provided by RyzenAPI
-- Game: CarX Drift Racing Online 2

-- MAIN APPLICATION
addappid(1826420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826421, 1, "19944d24b1486ec368bb854981e194f1c8020658e793d499778efefb5e9c7443")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
