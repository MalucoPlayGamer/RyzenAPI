-- Lua provided by RyzenAPI
-- Game: RiotZ

-- MAIN APPLICATION
addappid(659460)
-- Game: addappid(659460)

-- MAIN APP DEPOTS / PACKAGES
addappid(659461, 1, "6a71dc1585fd682f1172dc10b97bca32bfb54fc024fb88f23f83a96cc59fb8b7")
