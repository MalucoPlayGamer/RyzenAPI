-- Lua provided by RyzenAPI 
-- Game: ～Daydream～When butterflies dance
addappid(1966070)
addappid(1966071, 1, "75c14e7bbec80451141e218aa2fe9b7175c2b098f2e49e63813b4fcf33c40707")
addappid(1996020, 0, "676afc6bd6957c15eff36cf800c384c030177132c35cb21ff9d29f980763ae42")
