-- Lua provided by RyzenAPI
-- Game: Project Skyward

-- MAIN APPLICATION
addappid(2256280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256281, 1, "07feb165afde78f7e5d417d639301eceda03507f4636368b6a21a8549a8d81c9")

