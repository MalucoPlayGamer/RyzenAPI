-- Lua provided by RyzenAPI
-- Game: 1935130

-- MAIN APPLICATION
addappid(1935130)
-- Game: addappid(1935130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935131, 1, "190c84bbefa135c5a5be0c937f4cf17e199dc95ff67615efb2f0ad4d8b3d92f4")
