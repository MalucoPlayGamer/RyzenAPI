-- Lua provided by RyzenAPI
-- Game: Game: Regenesis Arcade

-- MAIN APPLICATION
addappid(753370)
-- Game: addappid(753370)

-- MAIN APP DEPOTS / PACKAGES
addappid(753371, 1, "8f662fa2dd1095fb54592c6a953d3e0e303bd6931ed010224df612cbd450f587")
