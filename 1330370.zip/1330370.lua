-- Lua provided by RyzenAPI
-- Game: Game: One Shell Straight to Hell

-- MAIN APPLICATION
addappid(1330370)
addappid(1383600)
-- Game: addappid(1330370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330371, 1, "3dd8103e8a66e56885728c854a5ee441942c1bcf0dcb575ac1d77ff797959e0c")
