-- Lua provided by RyzenAPI
-- Game: Galaxy Kart VR Demo

-- MAIN APPLICATION
addappid(1407980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407981, 1, "41a5639d62d012a82abc6338aa89c83027d33b6185e4d30e68084e2a2757d96a")
