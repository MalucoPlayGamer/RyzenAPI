-- Lua provided by RyzenAPI
-- Game: Avatar: The Last Airbender - Quest for Balance

-- MAIN APPLICATION
addappid(1620030)
addappid(1923750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1620031, 1, "9c1d3f0a7a18e863e5f56723937176c79fbfd6b2caf67a16d06c94db2678705b")

