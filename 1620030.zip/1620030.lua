-- Lua provided by RyzenAPI
-- Game: 1620030

-- MAIN APPLICATION
addappid(1620030)
addappid(1923750)
-- Game: addappid(1620030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620031, 1, "9c1d3f0a7a18e863e5f56723937176c79fbfd6b2caf67a16d06c94db2678705b")
