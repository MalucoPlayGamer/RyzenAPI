-- Lua provided by RyzenAPI
-- Game: addappid(1904840)

-- MAIN APPLICATION
addappid(1904840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904841, 1, "c3eccffead65c791f37019e97c3068e0d7c4c416d6879c0a01d99b648a395913")
