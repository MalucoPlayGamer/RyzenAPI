-- Lua provided by RyzenAPI
-- Game: Sally's Salon: Kiss & Make-Up

-- MAIN APPLICATION
addappid(878520)

-- MAIN APP DEPOTS / PACKAGES
addappid(878521, 1, "69d16135ebb0574fe32e9724fde570f88c37d8e80e082ab08273f32245325aee")

