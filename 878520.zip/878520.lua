-- Lua provided by RyzenAPI
-- Game: Game: AppID 878520

-- MAIN APPLICATION
addappid(878520)
-- Game: addappid(878520)

-- MAIN APP DEPOTS / PACKAGES
addappid(878521, 1, "69d16135ebb0574fe32e9724fde570f88c37d8e80e082ab08273f32245325aee")
