-- Lua provided by RyzenAPI
-- Game: Game: AppID 1735470

-- MAIN APPLICATION
addappid(1735470)
-- Game: addappid(1735470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735471, 1, "977cf664120e279712ca5cc61fa80a25ff31d51a0a0b064be5093e25ea106b8d")
