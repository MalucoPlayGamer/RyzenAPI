-- Lua provided by RyzenAPI
-- Game: Deadly Zone

-- MAIN APPLICATION
addappid(676310)

-- MAIN APP DEPOTS / PACKAGES
addappid(676311,0,"af1be10527d0f719aa6e467b7c28ec9d418d2936d46f51ff055c2942b106cb08")

