-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2020 - Video Editing Software

-- MAIN APPLICATION
addappid(1182920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182921, 1, "54c4d6cb437e8ba24b1c4710b50e77ab172a7ae07ff259b1905eefc55654b962")
