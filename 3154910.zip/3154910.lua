-- Lua provided by RyzenAPI
-- Game: Game: SERK: Chaos City Delivery

-- MAIN APPLICATION
addappid(3154910)
-- Game: addappid(3154910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154911, 1, "85fd9ba6d139ae7fe4b94c7945f3cfa546eb5a27e5c92eb9f5e626497abb78fb")
