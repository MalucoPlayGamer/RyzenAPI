-- Lua provided by RyzenAPI
-- Game: Game: Intergalactic Bubbles

-- MAIN APPLICATION
addappid(351490)
-- Game: addappid(351490)

-- MAIN APP DEPOTS / PACKAGES
addappid(351491, 1, "3765c3e150a95beac521a957237a1f0384e2e5935d4d4a35022ec38c72584bae")
addappid(351493, 1, "b6b370d7c128dc072a2055ee06960d2b179d842994da85fae0596e8ff06d47cd")
addappid(351494, 1, "d9cea011dd46f614ece824849c7495a6fb2e362c02d51f336b1b1d9eeeab2524")
addappid(351495, 1, "8fb996b20b25a80af96fc465c6079a57cd0088f655d3d43ebd9f647016cfe312")
