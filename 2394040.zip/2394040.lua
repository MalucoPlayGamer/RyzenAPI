-- Lua provided by RyzenAPI
-- Game: 游龙传说

-- MAIN APPLICATION
addappid(2394040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394041, 1, "c2b2c34531f053ddef8452bc9fc0d2e1fc98c1294a2822d61677248410344bac")

