-- Lua provided by RyzenAPI
-- Game: addappid(2254960)

-- MAIN APPLICATION
addappid(2254960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254961, 1, "52d37c718e7f8c1b216c38c575fb6ac0ba7cb3ad0e2efdf5f4b3a3da21eeac11")
