-- Lua provided by RyzenAPI
-- Game: Game: AppID 1728370

-- MAIN APPLICATION
addappid(1728370)
-- Game: addappid(1728370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728371, 1, "c3565878af8edc0518a4f031f8bbb44b321868711fc45314422334107e2e9c7c")
