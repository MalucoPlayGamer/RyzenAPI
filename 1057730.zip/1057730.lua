-- Lua provided by RyzenAPI
-- Game: 1057730

-- MAIN APPLICATION
addappid(1057730)
-- Game: addappid(1057730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057731, 1, "28ba8cbde268ff6cdbb479658688cc5147e49436455ed076d012a25ca6e30162")
