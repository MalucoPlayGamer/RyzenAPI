-- Lua provided by SkyAPI 
-- Game: VRAdventure
addappid(1057730)
addappid(1057731, 1, "28ba8cbde268ff6cdbb479658688cc5147e49436455ed076d012a25ca6e30162")
