-- Lua provided by RyzenAPI 
-- Game: AppID 852810
addappid(852810)
addappid(852811, 1, "0d72d9ce8ce21ce6c94ca25262749eb1fff736a906520c044fa419b9539acc97")
