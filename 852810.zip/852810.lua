-- Lua provided by RyzenAPI
-- Game: Airbo

-- MAIN APPLICATION
addappid(852810)

-- MAIN APP DEPOTS / PACKAGES
addappid(852811, 1, "0d72d9ce8ce21ce6c94ca25262749eb1fff736a906520c044fa419b9539acc97")
