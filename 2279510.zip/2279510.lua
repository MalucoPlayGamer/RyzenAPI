-- Lua provided by RyzenAPI
-- Game: SEXTS

-- MAIN APPLICATION
addappid(2279510)
addappid(2280110)
addappid(2280111)
addappid(2285790)
addappid(2313430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279511, 1, "4fbf057d19f0d6d7537825caaabaf206f93a8947c400ba4187b509601e2a26f9")

