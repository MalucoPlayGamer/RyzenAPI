-- Lua provided by RyzenAPI
-- Game: Case #9

-- MAIN APPLICATION
addappid(727680)

-- MAIN APP DEPOTS / PACKAGES
addappid(727681, 1, "8fbca36f9f95b0afbab5b0360b705687189c84edf5c399fb4ba108d568285ba3")
