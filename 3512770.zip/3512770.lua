-- Lua provided by RyzenAPI
-- Game: The Beautiful Game Demo

-- MAIN APPLICATION
addappid(3512770)
-- Game: addappid(3512770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512771, 1, "32b781926e40c59f1509a14bf46c6a77d73e9926ce239fb02a2e36e58aa9db7a")
