-- Lua provided by RyzenAPI
-- Game: Banishers: Ghosts of New Eden

-- MAIN APPLICATION
addappid(1493640)
addappid(2317940)
-- Game: addappid(1493640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493641, 1, "326c7fa2a40d5873408cd1acf39a170f5fa5bfe71400e373310c48f5f154923c")
