-- Lua provided by RyzenAPI
-- Game: Hentai Cosplay Elf

-- MAIN APPLICATION
addappid(1153670)
addappid(1158960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153671, 1, "bf970930c3ec1753e9b68fab7c4a04c83fe650f7b04205a2de2f0a693ca8ea93")

