-- Lua provided by RyzenAPI
-- Game: AppID 1153670

-- MAIN APPLICATION
addappid(1153670)
-- Game: addappid(1153670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153671, 1, "bf970930c3ec1753e9b68fab7c4a04c83fe650f7b04205a2de2f0a693ca8ea93")
