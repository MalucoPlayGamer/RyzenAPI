-- Lua provided by RyzenAPI
-- Game: Clone War

-- MAIN APPLICATION
addappid(2918600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918601, 1, "c607c735611149f2fbc821b3349b1c0e6f3892e836f58e7667165ebaad40d334")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
