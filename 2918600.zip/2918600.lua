-- Lua provided by SkyAPI 
-- Game: Clone War
addappid(2918600)
addappid(2918601, 1, "c607c735611149f2fbc821b3349b1c0e6f3892e836f58e7667165ebaad40d334")
