-- Lua provided by RyzenAPI
-- Game: Clone War

-- MAIN APPLICATION
addappid(2918600)
-- Game: addappid(2918600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918601, 1, "c607c735611149f2fbc821b3349b1c0e6f3892e836f58e7667165ebaad40d334")
