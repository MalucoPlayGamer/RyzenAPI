-- Lua provided by RyzenAPI
-- Game: addappid(1373470)

-- MAIN APPLICATION
addappid(1373470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373471, 1, "964993d51accd89b54b453fae8c776e1edc74873d4de048d366f762e28c70e81")
