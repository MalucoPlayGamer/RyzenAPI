-- Lua provided by RyzenAPI
-- Game: 2089350

-- MAIN APPLICATION
addappid(2089350)
-- Game: addappid(2089350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089351, 1, "26651d46a375380b0b5e0bed4b1d5c852cac86e4765810c8b8b7d3735cfaecc0")
