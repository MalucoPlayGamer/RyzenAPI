-- Lua provided by RyzenAPI
-- Game: Plenty: Skyhearth

-- MAIN APPLICATION
addappid(538950)

-- MAIN APP DEPOTS / PACKAGES
addappid(538951, 1, "e696b1356a97ef450324011b70f121afa18d0e3b5b951ba0d7f5a7c29ae38407")
