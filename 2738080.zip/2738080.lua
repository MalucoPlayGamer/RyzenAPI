-- Lua provided by RyzenAPI
-- Game: Ignited in Cavern

-- MAIN APPLICATION
addappid(2738080)
addappid(3032720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738081, 1, "28b1b3bb31a5f5bdb20f2e86e4c8f9d24847412d6a781dcb22a6360af91c619a")

