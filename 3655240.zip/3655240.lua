-- Lua provided by RyzenAPI
-- Game: addappid(3655240)

-- MAIN APPLICATION
addappid(3655240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655241, 1, "c7d98483e13ed74455e9f3915695b6a7a55ce94dc809d2fa320beea55c563129")
