-- Lua provided by SkyAPI 
-- Game: Seed of Heroes
addappid(2942700)
addappid(2942701, 1, "a108160a36bd72fec72ebe8db02040cbeb44a01898ab923fc8d6e58d3e1ea1d2")
