-- Lua provided by RyzenAPI
-- Game: Graffiti Battle

-- MAIN APPLICATION
addappid(1935850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935851, 1, "d690636d8bdcebd99bada2d12f3fa0179d92b1f4e6c7d50f3b338ced65843585")
