-- Lua provided by RyzenAPI
-- Game: Graffiti Battle

-- MAIN APPLICATION
addappid(1935850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935851, 1, "d690636d8bdcebd99bada2d12f3fa0179d92b1f4e6c7d50f3b338ced65843585")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
