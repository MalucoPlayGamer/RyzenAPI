-- Lua provided by RyzenAPI
-- Game: The 9th Day - Original Soundtrack

-- MAIN APPLICATION
addappid(593990)

-- MAIN APP DEPOTS / PACKAGES
addappid(593990,0,"6788d46b5b22622c91c8ec6789928733ccab77957b36bb8bb7493d4fedeb3cb4")

