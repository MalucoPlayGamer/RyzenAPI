-- Lua provided by RyzenAPI
-- Game: 3508140

-- MAIN APPLICATION
addappid(3508140)
-- Game: addappid(3508140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3508141, 1, "ed9ada9d11aeabe7a086e9e7a1d7c04352d0e93cc3685e0e5d244965da80ce1f")
