-- Lua provided by SkyAPI 
-- Game: Worldwide Rush Demo
addappid(3508140)
addappid(3508141, 1, "ed9ada9d11aeabe7a086e9e7a1d7c04352d0e93cc3685e0e5d244965da80ce1f")
