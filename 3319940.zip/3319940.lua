-- Lua provided by RyzenAPI
-- Game: 3319940

-- MAIN APPLICATION
addappid(3319940)
-- Game: addappid(3319940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319940,0,"3a41ae63aea1d4d9ba069358a1159daa92ead59d2790df626c089512e6018c1f")
