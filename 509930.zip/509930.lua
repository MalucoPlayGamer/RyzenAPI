-- Lua provided by RyzenAPI 
-- Game: NightmareZ
addappid(509930)
addappid(509931, 1, "d8f8a7ff3a24eb8855fd0447210fc482e3b50f3949ac96465a919830fa4e92a4")
