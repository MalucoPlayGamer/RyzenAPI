-- Lua provided by SkyAPI 
-- Game: Roce's Journey
addappid(1448290)
addappid(1448291, 1, "ec2b8a07c3e7c3ea1b10e6d266716641986a1d9a4a0e10c9a9a7ee9f4d1640c5")
