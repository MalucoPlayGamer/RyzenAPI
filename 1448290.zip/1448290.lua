-- Lua provided by RyzenAPI
-- Game: Roce's Journey

-- MAIN APPLICATION
addappid(1448290)
-- Game: addappid(1448290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448291, 1, "ec2b8a07c3e7c3ea1b10e6d266716641986a1d9a4a0e10c9a9a7ee9f4d1640c5")
