-- Lua provided by RyzenAPI
-- Game: Game: Roman's Christmas Original Soundtrack

-- MAIN APPLICATION
addappid(1233330)
-- Game: addappid(1233330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233331, 1, "771e16150e480f1b6cf658dbed2c8030112ef5e960a70921c4178df9203f857b")
