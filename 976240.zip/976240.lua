-- Lua provided by RyzenAPI
-- Game: Spaceguy: Red Space

-- MAIN APPLICATION
addappid(976240)
addappid(977820)

-- MAIN APP DEPOTS / PACKAGES
addappid(976241, 1, "b85405a2d20fc1738d7f6984451ea605cabd966a01442756406f6ebc454f8577")

