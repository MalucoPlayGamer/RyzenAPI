-- Lua provided by RyzenAPI
-- Game: Space Memory: Dogs

-- MAIN APPLICATION
addappid(3251610)
-- Game: addappid(3251610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251611, 1, "63eef10e5bf901b887786f9c0dfe302374aa36fdb2e961873c30a98729b6c34c")
