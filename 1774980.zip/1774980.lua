-- Lua provided by RyzenAPI
-- Game: AppID 1774980

-- MAIN APPLICATION
addappid(1774980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774981, 1, "7dc79e776e3ede057274ca46074f7ec58cd3df8dbd724ead332be007fd568811")

