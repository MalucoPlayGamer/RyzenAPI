-- Lua provided by RyzenAPI
-- Game: addappid(2182020)

-- MAIN APPLICATION
addappid(2182020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182021, 1, "799c876ea2d19d5e4e6b63ed87bd23a0bb9bf480c4f0f5e6595d6f4ae4b9cac2")
