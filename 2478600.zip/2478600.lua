-- Lua provided by RyzenAPI
-- Game: Game: BloodMoon

-- MAIN APPLICATION
addappid(2478600)
-- Game: addappid(2478600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478601, 1, "b18885703bdd73371213789607061531bfa8a4221150c6a779b35e17f98ba79b")
