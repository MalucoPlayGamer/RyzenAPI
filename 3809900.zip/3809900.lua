-- Lua provided by RyzenAPI
-- Game: Habbo Hotel: Origins

-- MAIN APPLICATION
addappid(3809900)

