-- Lua provided by RyzenAPI
-- Game: Game: Wait! Life is Beautiful! Prologue

-- MAIN APPLICATION
addappid(1340470)
-- Game: addappid(1340470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340471, 1, "264fc308411f0a1b7d64a08ec43ae77e043e2841ec2447651023cc2b9b370e6c")
