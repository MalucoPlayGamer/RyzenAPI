-- Lua provided by RyzenAPI
-- Game: addappid(1885380)

-- MAIN APPLICATION
addappid(1885380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885381, 1, "6961d1b023eb36d2a260bda469b37998c5dab10d948a71815d7aac1e9ae69d51")
