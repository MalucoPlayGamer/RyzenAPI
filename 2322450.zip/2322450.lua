-- 2322450's Lua and Manifest Created by Hubcap Manifest
-- Mining Survivors
-- Created: February 11, 2026 at 10:57:07 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2322450) -- Mining Survivors
-- MAIN APP DEPOTS
addappid(2322451, 1, "0dbb2e7e3d34173e35c4450b381cb74e874b253dc24d78ebabf5d1e78624d108") -- Depot 2322451
setManifestid(2322451, "5014996319688836151", 121050354)