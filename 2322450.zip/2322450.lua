-- Lua provided by RyzenAPI
-- Game: Mining Survivors

-- MAIN APPLICATION
addappid(2322450) -- Mining Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(2322451, 1, "0dbb2e7e3d34173e35c4450b381cb74e874b253dc24d78ebabf5d1e78624d108") -- Depot 2322451

