-- Lua provided by RyzenAPI
-- Game: 2416600

-- MAIN APPLICATION
addappid(2416600)
-- Game: addappid(2416600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416601, 1, "7fc1edf1da4e11bfd76d064a923de08adc1f9bf81b57cdd4d50cd575f41e67d1")
