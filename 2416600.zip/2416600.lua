-- Lua provided by RyzenAPI
-- Game: Frightence

-- MAIN APPLICATION
addappid(2416600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2416601, 1, "7fc1edf1da4e11bfd76d064a923de08adc1f9bf81b57cdd4d50cd575f41e67d1")

