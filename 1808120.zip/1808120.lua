-- Lua provided by RyzenAPI
-- Game: AppID 1808120

-- MAIN APPLICATION
addappid(1808120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808121, 1, "dba70bd20764facee7986c4a8ace007ea51aac19da05c25a78bdabe6eda34517")

