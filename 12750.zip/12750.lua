-- Lua provided by RyzenAPI 
-- Game: AppID 12750
addappid(12750)
addappid(12751, 1, "670f401c733f2e4232176466d0b0bdf3e360ab7bc28bb62335530d4b5debf3e6")
