-- Lua provided by RyzenAPI
-- Game: AppID 107100

-- MAIN APPLICATION
addappid(107100)
addappid(228984)
addappid(229002)
-- Game: addappid(107100)

-- MAIN APP DEPOTS / PACKAGES
addappid(107101, 1, "afa93a070dd42a3bfd3c6ba3f27928721f8a81848db4854f04d4b21e29c04e5d")
addappid(107103, 1, "e06362ccdaa5c895fea82c62ef2b0eea645832251c54f54b82d60bf46e4190f4")
addappid(107105, 1, "ae01648bf73f6e14a067e7dcdec1224278fdaa37dc0ec714e18e320dbc59cd18")
addappid(107106, 1, "b0cf5745a6f483abadaef42bffb15b29a0d7f86faee356126b084176129f4a5e")
