-- Lua provided by RyzenAPI
-- Game: AppID 2185500

-- MAIN APPLICATION
addappid(2185500)
-- Game: addappid(2185500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185501, 1, "8beb87d34949dfa868313771e5e4fe816b4ae8f0cb77b214803145bc65333f70")
