-- 2556240's Lua and Manifest Created by Hubcap Manifest
-- Brews & Bastards
-- Created: June 27, 2026 at 07:57:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2556240, 1, "ad241b3e6e4643a4db7978d87e272589646158600dccc33f7ce30552baf928a8") -- Brews & Bastards
-- MAIN APP DEPOTS
addappid(2556241, 1, "0dacd0efc1c2ba5023538fffb8c8fffa5833c54fd3a54044b4af29e96c7c5acf") -- Depot 2556241
-- setManifestid(2556241, "4737880405907270636", 5531273662)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)