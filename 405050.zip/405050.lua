-- Lua provided by SkyAPI 
-- Game: Fill Up!
addappid(405050)
addappid(405051, 1, "fc20f516e1da9a7500bf2493664eaa539424fe5b50fd773fe422c8cac7155484")
