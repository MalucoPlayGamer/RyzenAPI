-- Lua provided by RyzenAPI
-- Game: Fill Up!

-- MAIN APPLICATION
addappid(405050)

-- MAIN APP DEPOTS / PACKAGES
addappid(405051, 1, "fc20f516e1da9a7500bf2493664eaa539424fe5b50fd773fe422c8cac7155484")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
