-- Lua provided by RyzenAPI
-- Game: Avernum 5

-- MAIN APPLICATION
addappid(206040)

-- MAIN APP DEPOTS / PACKAGES
addappid(206041, 1, "e747edaa7ee09c37ad68f63813fdd4e11fb97b46b89d9ff8288af42f55b198f6")
