-- Lua provided by RyzenAPI
-- Game: 1094180

-- MAIN APPLICATION
addappid(1094180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094180,0,"be69cc6b6dcf2cc0cbf2950a6ee6e46a117a383060348a4aff2bfccf611845ea")

