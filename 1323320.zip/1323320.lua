-- Lua provided by RyzenAPI
-- Game: Terraria: Otherworld Official Soundtrack

-- MAIN APPLICATION
addappid(1323320)
-- Game: addappid(1323320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323321, 1, "7f12593d69251ea1c746f77aef43b5717e1080e3edad0b43c96e17b5c552e920")
addappid(1323322, 1, "ff38e4256915093266d39cd019b3f6b8e1a596fae5b066dc824de64ab42c42d3")
