-- Lua provided by RyzenAPI
-- Game: addappid(2553110)

-- MAIN APPLICATION
addappid(2553110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553111, 1, "0748aee84f870ee8bc16cc89d9d6d0e0c395c7b3c67f95d047837c2e3ccb0207")
