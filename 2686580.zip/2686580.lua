-- Lua provided by SkyAPI 
-- Game: Trinity Survivors
addappid(2686580)
addappid(2686581, 1, "eafcbc5f6a59db883998ec09b07268a4e025fd31df320361057a104aa68441a4")
