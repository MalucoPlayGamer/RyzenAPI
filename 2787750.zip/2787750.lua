-- Lua provided by RyzenAPI
-- Game: Backrooms: Liminal Conflict

-- MAIN APPLICATION
addappid(2787750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787751, 1, "5b9d9ba5d1ca54a2c20b121ff7b8cd4fdbd54f3bf0c190d4ee564bec38775694")
