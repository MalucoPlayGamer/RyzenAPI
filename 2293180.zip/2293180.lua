-- Lua provided by RyzenAPI
-- Game: Banana Attack VR

-- MAIN APPLICATION
addappid(2293180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293181, 1, "12901e61b4f42301ad93dc74fb06d837d5f5621d60a773f9221e028228c42a52")

