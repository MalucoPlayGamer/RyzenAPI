-- Lua provided by RyzenAPI
-- Game: Unpossess: Exorcism Simulator

-- MAIN APPLICATION
addappid(2976900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976901, 1, "526cd450b93dce7088cb0b8ed4e7407d41a254d7d6f66f40c99e4e94e0ed78f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
