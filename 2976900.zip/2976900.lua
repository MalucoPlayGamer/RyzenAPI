-- Lua provided by RyzenAPI
-- Game: Game: Unpossess: Exorcism Simulator

-- MAIN APPLICATION
addappid(2976900)
-- Game: addappid(2976900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976901, 1, "526cd450b93dce7088cb0b8ed4e7407d41a254d7d6f66f40c99e4e94e0ed78f3")
