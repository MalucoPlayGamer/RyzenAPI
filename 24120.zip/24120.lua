-- Lua provided by RyzenAPI
-- Game: EverQuest: Secrets of Faydwer

-- MAIN APPLICATION
addappid(24120)

-- MAIN APP DEPOTS / PACKAGES
addappid(24121, 1, "35fcb8cb4fdec713121264246da4b225ecd790107db697df4ce07a20ac8753a1")
