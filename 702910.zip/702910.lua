-- Lua provided by RyzenAPI
-- Game: AppID 702910

-- MAIN APPLICATION
addappid(702910)
-- Game: addappid(702910)

-- MAIN APP DEPOTS / PACKAGES
addappid(702911, 1, "c85e6cd7a9e4a9e18b8fa5a4c68324eee201d49147a3255dbcf5aa677de7ce88")
