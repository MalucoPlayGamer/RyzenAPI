-- Lua provided by RyzenAPI
-- Game: KRAMPEN - Fan Pack

-- MAIN APPLICATION
addappid(3372370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372370,0,"c8513521d6c4b6ae8623b6a98447eac6e005e839657e96be9b4034759aa54891")

