-- Lua provided by RyzenAPI
-- Game: Coloring Game 3

-- MAIN APPLICATION
addappid(1275640)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1354790)
addappid(1362600)
addappid(1362601)
addappid(1362602)
