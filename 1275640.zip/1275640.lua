-- Lua provided by RyzenAPI
-- Game: Coloring Game 3

-- MAIN APPLICATION
addappid(1275640)
