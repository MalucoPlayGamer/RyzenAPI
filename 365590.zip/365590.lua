-- Lua provided by RyzenAPI
-- Game: AppID 365590

-- MAIN APPLICATION
addappid(365590)
addappid(437700)
addappid(437701)
addappid(437702)
addappid(451530)
addappid(451531)
addappid(451532)
addappid(451533)
addappid(451534)
addappid(451535)
addappid(451536)
addappid(451537)
addappid(451538)
addappid(451539)
addappid(451550)
addappid(456280)
addappid(456281)
addappid(459500)
addappid(459501)
addappid(468460)
addappid(494630)
addappid(556470)
addappid(568990)
addappid(569000)
addappid(571030)
addappid(571031)
addappid(596190)
addappid(599980)

-- MAIN APP DEPOTS / PACKAGES
addappid(365591, 1, "cfc1408fd9eb22a20e55a7cc94c75065779da06a34d6826f63a48dcd380701ae")
addappid(365592, 1, "4ec2ab170d6a036fb1f870729fbdceecc329b5d4008b84451370f72a0d0d1c1c")
addappid(365593, 1, "a8fc437e850c2360cad81e0ae5d7c0c3b276079a449ea031aebf0280b405b1f8")
addappid(365594, 1, "e1b087915fdacc02b7beab6883a2122a84eed401a39feb11ba5179eeb9bf5433")
addappid(365595, 1, "77decf95d069e54fd9c4e7f7be84626a5d71dd95abec5d06e82dac73bb466c6e")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4381160)
