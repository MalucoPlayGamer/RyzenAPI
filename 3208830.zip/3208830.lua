-- Lua provided by RyzenAPI
-- Game: addappid(3208830)

-- MAIN APPLICATION
addappid(3208830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208831, 1, "6c7a69444e94355a131bd76edd391f004eab411f08b8b043bc40478f8b956bf5")
