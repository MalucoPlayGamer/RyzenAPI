-- Lua provided by RyzenAPI 
-- Game: Splash Ship
addappid(2113690)
addappid(2113691, 1, "8db04e0b666991507809b85bc7ef6bd236237e3306fb3b693733a4292ed03f39")
