-- Lua provided by RyzenAPI
-- Game: Splash Ship

-- MAIN APPLICATION
addappid(2113690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113691, 1, "8db04e0b666991507809b85bc7ef6bd236237e3306fb3b693733a4292ed03f39")
