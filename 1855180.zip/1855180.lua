-- Lua provided by SkyAPI 
-- Game: AppID 1855180
addappid(1855180)
addappid(1855181, 1, "17d3f9e590b8ea6872710b699b43a1f4e19e641cd46e5767165800de4ecfc0e9")
