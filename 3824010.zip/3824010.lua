-- Lua provided by RyzenAPI
-- Game: 3824010

-- MAIN APPLICATION
addappid(3824010)
-- Game: addappid(3824010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3824011, 1, "ea0bbf5da3699d315a23726653f0029bce9d3355d9e8a5373e4be9e2cab2f2c0")
