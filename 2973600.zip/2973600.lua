-- Lua provided by SkyAPI 
-- Game: 茜色 Demo
addappid(2973600)
addappid(2973601, 1, "5874d74a0275006b6110d09f59636918930e2f28a3860c1a2c8f87260ed7ff94")
