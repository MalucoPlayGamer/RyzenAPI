-- Lua provided by RyzenAPI
-- Game: Hypersensitive Bob

-- MAIN APPLICATION
addappid(444270)
-- Game: addappid(444270)

-- MAIN APP DEPOTS / PACKAGES
addappid(444271, 1, "e25b201f686b28f98bd4c98f4a64c8dc61231d16ab6b558f61f18ba61977621d")
addappid(444272, 1, "45704043a7dd496249647bf5af500a8dbd011c6726c8017cc392d2662dceae5d")
addappid(444273, 1, "ce67f9ebeb0ceb052357251ef2906b02086e704e0cf1ba37b46b42e13206cbf7")
