-- Lua provided by SkyAPI 
-- Game: Raiders! Forsaken Earth
addappid(972010)
addappid(972011, 1, "093bea882cf3730e4f9e82f662da4cae1d522a13c737616522b6f0c1dbf4836f")
