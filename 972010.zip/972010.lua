-- Lua provided by RyzenAPI
-- Game: Game: Raiders! Forsaken Earth

-- MAIN APPLICATION
addappid(972010)
-- Game: addappid(972010)

-- MAIN APP DEPOTS / PACKAGES
addappid(972011, 1, "093bea882cf3730e4f9e82f662da4cae1d522a13c737616522b6f0c1dbf4836f")
