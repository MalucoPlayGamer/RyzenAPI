-- Lua provided by RyzenAPI 
-- Game: AppID 1278760
addappid(1278760)
addappid(1278761, 1, "978ae666895ee0563be9e82a12c63693f9d43c80c6d0cde2bd954f4c2dc9d81c")
