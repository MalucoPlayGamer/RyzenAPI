-- Lua provided by RyzenAPI
-- Game: Space Memory: Animals

-- MAIN APPLICATION
addappid(3154130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154131, 1, "d03d44c023aa76ad136ae16e91f12319d06f3426f614dc96b4fd02f95e48c08c")

