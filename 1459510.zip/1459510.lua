-- Lua provided by RyzenAPI
-- Game: The Seasons Collection: Spring

-- MAIN APPLICATION
addappid(1459510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1459511, 1, "28641a210bc4c9f86f7b112345ae29ef28d85f4d3286519661e93e8029099c77")

