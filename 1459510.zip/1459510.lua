-- Lua provided by RyzenAPI 
-- Game: The Seasons Collection: Spring
addappid(1459510)
addappid(1459511, 1, "28641a210bc4c9f86f7b112345ae29ef28d85f4d3286519661e93e8029099c77")
