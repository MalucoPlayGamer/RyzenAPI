-- Lua provided by RyzenAPI
-- Game: Game: Ad Infernum

-- MAIN APPLICATION
addappid(1390070)
-- Game: addappid(1390070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390071, 1, "739be05a8e21d05469718584e4ac8dc9b113189b5fa02b1886341231442aeabf")
