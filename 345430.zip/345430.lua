-- Lua provided by RyzenAPI
-- Game: The Cursed Forest

-- MAIN APPLICATION
addappid(228984)
addappid(228986)
addappid(228990)
addappid(345430)

-- MAIN APP DEPOTS / PACKAGES
addappid(345432,0,"ad85e80f295c93902ac82c8116779236cab0b2e22b44cdf1d421d217973665a9")
addappid(345434,0,"80de377113dd171eef15e6746d9a101b9b3a60eba20a2a2dc182d67d70c830d1")

