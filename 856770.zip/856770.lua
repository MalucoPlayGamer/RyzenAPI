-- Lua provided by RyzenAPI
-- Game: Hokan: Monster Slayer

-- MAIN APPLICATION
addappid(856770)
-- Game: addappid(856770)

-- MAIN APP DEPOTS / PACKAGES
addappid(856771, 1, "780ff673499a7f650a8afee0deb0e19fb4dc089cb9024738ca5d11f8dfa0f61c")
