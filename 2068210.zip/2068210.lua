-- Lua provided by RyzenAPI
-- Game: Alongside

-- MAIN APPLICATION
addappid(2068210)
-- Game: addappid(2068210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068211, 1, "a49f6df0b2ab8ad8c8e2dc6934b9a827c26379994ccee4600a40c716e984ed30")
