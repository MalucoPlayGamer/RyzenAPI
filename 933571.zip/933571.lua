-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933571)

-- MAIN APP DEPOTS / PACKAGES
addappid(933571,0,"cc621ed62d15f2656c32c1c570a4317c91a55ea13f01a51b8df70b4f1fa44e10")

