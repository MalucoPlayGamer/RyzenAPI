-- Lua provided by RyzenAPI
-- Game: Everblade

-- MAIN APPLICATION
addappid(1873570)
-- Game: addappid(1873570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873571, 1, "5835900b066359b673301902346637c6bc100cebc04dcc8a135236c29ec3c239")
