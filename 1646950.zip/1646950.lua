-- Lua provided by RyzenAPI
-- Game: Neko Beach 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1646950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646950,0,"4257253f0ca069fba4383cb0b1f1ea68839db09321710f79ef41ba1ef348b85d")

