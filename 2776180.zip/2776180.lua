-- Lua provided by RyzenAPI
-- Game: Doodle Harmony Ghosts

-- MAIN APPLICATION
addappid(2776180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776181, 1, "5fbb873ba66b8fc477d769142d661dbb74564d098102755562e21b2a27e1ae89")
