-- Lua provided by RyzenAPI
-- Game: Forest Mansion Incident

-- MAIN APPLICATION
addappid(3511340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511341, 1, "ca6a448b5cc4f3a2355012f8266e65c32a3740ed4fbbf257361d52c5baf61570")
