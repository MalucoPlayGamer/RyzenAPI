-- Lua provided by RyzenAPI
-- Game: addappid(756380)

-- MAIN APPLICATION
addappid(756380)

-- MAIN APP DEPOTS / PACKAGES
addappid(756381, 1, "f409e84d0eb7dd0e95550dcb46994ea490ac071aef09c5b04ea7ffba30d056dc")
