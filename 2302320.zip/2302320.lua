-- Lua provided by RyzenAPI
-- Game: Poke ALL Toads

-- MAIN APPLICATION
addappid(2302320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302321,0,"d369d7cfeb52b8b6bd3e448cde7e4f2172e8e8ecdb65ebf13d887b401bd51bca")

