-- 4625810's Lua and Manifest Created by Hubcap Manifest
-- Internet Survivor Survivors
-- Created: August 16, 2026 at 12:10:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4625810, 1, "f49b41e160c286859db62e492d0fd7dce36d832cd9421175bbd5ab1b0e010264") -- Internet Survivor Survivors
-- MAIN APP DEPOTS
addappid(4625811, 1, "eb3f77c4f9d2a8f4ab0b33adbd8c50f4ca0d2851b436de02eeba32d5412c51a2") -- Depot 4625811
setManifestid(4625811, "3678159831610830234", 682317168)