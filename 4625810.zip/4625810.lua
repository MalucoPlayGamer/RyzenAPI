-- Lua provided by RyzenAPI
-- Game: Internet Survivor Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(4625810, 1, "f49b41e160c286859db62e492d0fd7dce36d832cd9421175bbd5ab1b0e010264") -- Internet Survivor Survivors
addappid(4625811, 1, "eb3f77c4f9d2a8f4ab0b33adbd8c50f4ca0d2851b436de02eeba32d5412c51a2") -- Depot 4625811

