-- Lua provided by RyzenAPI
-- Game: Earthling's Undertaking

-- MAIN APPLICATION
addappid(1729410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729411, 1, "6226027665cdad24eb16aed5859cffa58aa603bf125325103ea745f43a959c7e")

