-- Lua provided by SkyAPI 
-- Game: Touhou Hero of Ice Fairy
addappid(1955830)
addappid(1955831, 1, "7c520a8442f3537e7006593708adc76ceb19a2a0bdb9ad6a1158ad9d5c570dad")
