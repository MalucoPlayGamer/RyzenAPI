-- Lua provided by RyzenAPI
-- Game: addappid(1955830)

-- MAIN APPLICATION
addappid(1955830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955831, 1, "7c520a8442f3537e7006593708adc76ceb19a2a0bdb9ad6a1158ad9d5c570dad")
