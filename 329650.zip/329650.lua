-- Lua provided by RyzenAPI
-- Game: 329650

-- MAIN APPLICATION
addappid(329650)
-- Game: addappid(329650)

-- MAIN APP DEPOTS / PACKAGES
addappid(329651, 1, "022c352975db391284082265e1dbd7cdb8aea3ed2746389af8bc00a9b9ba7530")
addappid(329652, 1, "eb354d869cb6ec358fd8deaff5580c53839a2c862584b9464f370c82fa5f4b30")
addappid(329653, 1, "4ad92cdaa5ef948dce62d28851b07137ec7f5b9a140ea617cb9c4f32ff26a4ba")
addappid(329654, 1, "91d2f449aae40419221c8cd6df4f407b286ebf4bb4705b8841be448c52d26f9b")
addappid(329655, 1, "7c38253a87d234005d9ee4424b69f7f3d659adbb7a9adcbf3c4322ec45439125")
addappid(329656, 1, "17dbd5e3f19729b02de99bc25f49ea067f75c5aaace0df4e6dbab0fdd37bc631")
