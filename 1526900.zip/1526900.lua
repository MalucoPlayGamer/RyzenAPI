-- Lua provided by RyzenAPI
-- Game: Sapphire Safari

-- MAIN APPLICATION
addappid(1526900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1526901, 1, "9c4e34006cee70e91a1245dcdd513e30d1dfcf391a5cd0d8e52b0bc8203d2178")

