-- Lua provided by RyzenAPI
-- Game: Game: Sapphire Safari

-- MAIN APPLICATION
addappid(1526900)
-- Game: addappid(1526900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526901, 1, "9c4e34006cee70e91a1245dcdd513e30d1dfcf391a5cd0d8e52b0bc8203d2178")
