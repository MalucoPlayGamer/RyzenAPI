-- Lua provided by RyzenAPI
-- Game: Alien

-- MAIN APPLICATION
addappid(2588740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588741, 1, "47b42d1e579d10ca7816f05b418c21694c91f6a40b258a48ae39dbc20bd3d869")

