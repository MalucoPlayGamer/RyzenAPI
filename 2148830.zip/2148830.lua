-- Lua provided by RyzenAPI
-- Game: 决战紫禁怀旧服

-- MAIN APPLICATION
addappid(2148830)
-- Game: addappid(2148830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148831, 1, "9d22ca32a1fd415fa031cf154fcfc275d8bbaa220c56906dc1e79a68b534803d")
