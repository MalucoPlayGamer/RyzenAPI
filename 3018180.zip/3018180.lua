-- Lua provided by RyzenAPI
-- Game: 异世界超级战争 序章 P1 Demo

-- MAIN APPLICATION
addappid(3018180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018181, 1, "3c23faa5ff4ae1316d20d2fb9d08beff792f482010fba116ea343da1bc92280b")
