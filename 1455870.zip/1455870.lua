-- Lua provided by RyzenAPI
-- Game: 1455870

-- MAIN APPLICATION
addappid(1455870)
-- Game: addappid(1455870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455870,0,"f73bf67f390db519f6f4a7da1bf1bf815485f410111742cb169ad53b035dc49b")
