-- Lua provided by RyzenAPI
-- Game: addappid(294690)

-- MAIN APPLICATION
addappid(294690)
addappid(303170)
addappid(303171)
addappid(303172)
addappid(303173)
addappid(303174)
addappid(303175)
addappid(303176)
addappid(303177)
addappid(303178)
addappid(303179)

-- MAIN APP DEPOTS / PACKAGES
addappid(294691, 1, "5eb8063097aa8d1efbf3f22cce48de994bb957397a8c4995d41ec385f0ee6476")
addappid(294694, 1, "944aac0e11aab4a5f4fa4214a7dac412877cd356bb2553bee487e64ed46258f9")
addappid(294695, 1, "55a60c9194df47b8407c192bedb1a855abf7793a66d01ef9d4a7f36ca3c2199d")
