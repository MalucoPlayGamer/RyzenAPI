-- Lua provided by RyzenAPI
-- Game: ABRISS Demo

-- MAIN APPLICATION
addappid(1722470)
-- Game: addappid(1722470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722471, 1, "892af3d7af566339f3b4e5f65f3e7e91f06f8e7d61e19208ae87ae399d7ba64f")
