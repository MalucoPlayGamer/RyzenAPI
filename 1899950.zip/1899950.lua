-- Lua provided by RyzenAPI
-- Game: Dolmenjord - Viking Islands

-- MAIN APPLICATION
addappid(1899950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899951, 1, "2753825ed8dc7059dd64f8d49fb38c1e307e8ab5481587140db9411905f2a356")
