-- Lua provided by RyzenAPI
-- Game: Awake

-- MAIN APPLICATION
addappid(2005780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005781, 1, "cc0dbb2b23b851cdc836d0227f130f4fe3fda59ffcf3640e2f19a89ba9acf51e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
