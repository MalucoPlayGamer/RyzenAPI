-- Lua provided by RyzenAPI
-- Game: addappid(2005780)

-- MAIN APPLICATION
addappid(2005780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005781, 1, "cc0dbb2b23b851cdc836d0227f130f4fe3fda59ffcf3640e2f19a89ba9acf51e")
