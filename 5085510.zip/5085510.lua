-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl 4: The Crystal Temple

-- MAIN APPLICATION
addappid(5085510) -- Fireboy & Watergirl 4: The Crystal Temple

-- MAIN APP DEPOTS / PACKAGES
addappid(5085511, 1, "f48d74cd6f8488236c43bb8ba37f05f10166aab997033fa1502cd2e6e407cf3f") -- Depot 5085511

