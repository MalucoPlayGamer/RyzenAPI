-- Lua provided by RyzenAPI
-- Game: Game: AppID 637060

-- MAIN APPLICATION
addappid(637060)
-- Game: addappid(637060)

-- MAIN APP DEPOTS / PACKAGES
addappid(637061, 1, "6d6a854387990118281eab6c45644e4c4a4fb25565af1102cf89efb2147005f5")
