-- Lua provided by SkyAPI 
-- Game: AppID 637060
addappid(637060)
addappid(637061, 1, "6d6a854387990118281eab6c45644e4c4a4fb25565af1102cf89efb2147005f5")
