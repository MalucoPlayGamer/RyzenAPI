-- Lua provided by RyzenAPI
-- Game: Picma - Picture Enigmas

-- MAIN APPLICATION
addappid(2134030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134031, 1, "d13b331e8f24efd411a91181599756f76443e32dd1cfb887bd2fc6b62f8f9f18")
addappid(2134032, 1, "a5f84fe567761945f503a64e6b2ffc6da925157dd90133606d1cfd1fdc86648c")
addappid(2134033, 1, "474165951f01ab3cc858697c54fe37e72f0dd6a314b1feca07c89af7f8d0a8be")
