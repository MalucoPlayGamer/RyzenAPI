-- Lua provided by RyzenAPI
-- Game: Cybarian: The Time Travelling Warrior

-- MAIN APPLICATION
addappid(928840)

-- MAIN APP DEPOTS / PACKAGES
addappid(928841, 1, "54d0afd44705dc17d850e1521c161ac10d4dcfa3bbcc6b208f7c4c97a9ded865")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
