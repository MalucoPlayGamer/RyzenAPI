-- Lua provided by RyzenAPI
-- Game: Cybarian: The Time Travelling Warrior

-- MAIN APPLICATION
addappid(928840)
-- Game: addappid(928840)

-- MAIN APP DEPOTS / PACKAGES
addappid(928841, 1, "54d0afd44705dc17d850e1521c161ac10d4dcfa3bbcc6b208f7c4c97a9ded865")
