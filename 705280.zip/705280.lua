-- Lua provided by RyzenAPI
-- Game: 705280

-- MAIN APPLICATION
addappid(705280)
-- Game: addappid(705280)

-- MAIN APP DEPOTS / PACKAGES
addappid(705282,0,"aab1745eef80ac8c416a0f933f826d02ea35801e5ab339864065c48f5ffd1e5f")
addappid(705284,0,"549a0b3ac1c2f522abab8ae71221636841e82c92c4738af80321a5bc7228cfc1")
addappid(859300,0,"794ec6716c92acf8e224f28fe71c8ef2ce584d314bce573adceceabb4a62916f")
