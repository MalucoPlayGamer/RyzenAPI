-- Lua provided by RyzenAPI
-- Game: Killer Worm 2

-- MAIN APPLICATION
addappid(1768260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768261, 1, "1212a5189fc19d88ebeda5aeae7fa10ce459614c80e1da1fcafebd9adc6f3796")
