-- Lua provided by RyzenAPI
-- Game: Making History: The First World War

-- MAIN APPLICATION
addappid(959150)

-- MAIN APP DEPOTS / PACKAGES
addappid(959151, 1, "16ee79503562c71006573784d6827897709e70798ba8d5f211ad3c91f4e0ac31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
