-- Lua provided by RyzenAPI
-- Game: Making History: The First World War

-- MAIN APPLICATION
addappid(959150)

-- MAIN APP DEPOTS / PACKAGES
addappid(959151, 1, "16ee79503562c71006573784d6827897709e70798ba8d5f211ad3c91f4e0ac31")

