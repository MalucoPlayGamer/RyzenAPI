-- Lua provided by RyzenAPI
-- Game: 2428770

-- MAIN APPLICATION
addappid(2428770)
-- Game: addappid(2428770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428771, 1, "4ddd1bfa2865770309a1e56ac40be63dfbc75c5ee263cce1aac8240650a70d62")
addappid(2428772, 1, "e4acaef3a910c9f91449b9e1cc2229f38627908bc82c5b76485683783515ddf1")
