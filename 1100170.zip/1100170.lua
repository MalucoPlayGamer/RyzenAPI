-- Lua provided by RyzenAPI
-- Game: Double Spoiler

-- MAIN APPLICATION
addappid(1100170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100171, 1, "a4cf5d4c4a8b7dc6730126092708b496155b6ae658ea505475d2c48c6ebd12e0")

