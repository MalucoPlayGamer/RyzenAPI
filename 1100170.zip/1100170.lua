-- Lua provided by RyzenAPI
-- Game: addappid(1100170)

-- MAIN APPLICATION
addappid(1100170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100171, 1, "a4cf5d4c4a8b7dc6730126092708b496155b6ae658ea505475d2c48c6ebd12e0")
