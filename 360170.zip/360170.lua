-- Lua provided by RyzenAPI
-- Game: How to Survive 2

-- MAIN APPLICATION
addappid(360170)

-- MAIN APP DEPOTS / PACKAGES
addappid(360171, 1, "ddabbad919b185b24244748fcbd7e57ff94c0700ee7a05955dd5c6c4bde09530")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(427080)
addappid(475130)
addappid(475131)
addappid(475132)
addappid(506040)
addappid(543190)
addappid(543191)
addappid(543192)
addappid(543193)
addappid(554390)
