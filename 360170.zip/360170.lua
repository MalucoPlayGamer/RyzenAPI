-- Lua provided by RyzenAPI
-- Game: Game: How to Survive 2

-- MAIN APPLICATION
addappid(360170)
-- Game: addappid(360170)

-- MAIN APP DEPOTS / PACKAGES
addappid(360171, 1, "ddabbad919b185b24244748fcbd7e57ff94c0700ee7a05955dd5c6c4bde09530")
