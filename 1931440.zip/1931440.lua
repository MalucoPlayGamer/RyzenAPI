-- Lua provided by RyzenAPI
-- Game: addappid(1931440)

-- MAIN APPLICATION
addappid(1931440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931441, 1, "fa937e8a0dadd37682f64f444d80f6e4c4b9ba33d61f7bf5f1661e8c4117a760")
