-- Lua provided by RyzenAPI
-- Game: IRON GUARD

-- MAIN APPLICATION
addappid(1213220)
-- Game: addappid(1213220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213221, 1, "2037ca432bcc4413a18cb67c6159de3c9f4512102ca8005a50adb2c74843b365")
