-- Lua provided by RyzenAPI
-- Game: IRON GUARD

-- MAIN APPLICATION
addappid(1213220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213221, 1, "2037ca432bcc4413a18cb67c6159de3c9f4512102ca8005a50adb2c74843b365")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
