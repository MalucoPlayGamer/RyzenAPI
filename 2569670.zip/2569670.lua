-- Lua provided by RyzenAPI
-- Game: Farmer's Dynasty 2

-- MAIN APPLICATION
addappid(2569670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2569671,0,"ec134e28be1330625eaa14ca31746901115f91b2350216524873b0e45bf97f3d")
addappid(3287820,0,"5c797e49fc1bea3832192814383d54552b71932f13e6f6dc5056ef02ea8e925a")
addappid(4553090,0,"c2c7b36cfb4935e7754f6d269d48e1ca809db2daa30fbc923c274a95c09f0d20")

