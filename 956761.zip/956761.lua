-- Lua provided by RyzenAPI
-- Game: Dong Zhuo - Officer Ticket / 董卓使用券

-- MAIN APPLICATION
addappid(956761)

-- MAIN APP DEPOTS / PACKAGES
addappid(956761,0,"9faf84c21c8711f93c9be9c26ac1b963d4355cfce3d3da939bda6fc2c070848e")

