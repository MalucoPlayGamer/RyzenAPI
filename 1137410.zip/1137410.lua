-- Lua provided by RyzenAPI
-- Game: addappid(1137410)

-- MAIN APPLICATION
addappid(1137410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137411, 1, "a5bb0ad0408ab87eeace09ac0dfb667b37b6cd194ab5e23d6a843f78139af070")
