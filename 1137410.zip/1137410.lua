-- Lua provided by SkyAPI 
-- Game: Depraved Awakening
addappid(1137410)
addappid(1137411, 1, "a5bb0ad0408ab87eeace09ac0dfb667b37b6cd194ab5e23d6a843f78139af070")
