-- Lua provided by RyzenAPI 
-- Game: 末日竟在我身边3 - Zombies Everywhere 3
addappid(2148280)
addappid(2148281, 1, "c58508fd2e1d80971a18107e455c53f48b650d4cf6dbaa975a0ff19e0f94908d")
addappid(2172290, 0, "3cc768f1825682d93d7a53fcc5a528628a8457fa6ba6e6dba82a47c019d2860d")
