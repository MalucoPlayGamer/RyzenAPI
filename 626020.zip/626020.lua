-- Lua provided by RyzenAPI
-- Game: Shadows in the Darkness

-- MAIN APPLICATION
addappid(626020)

-- MAIN APP DEPOTS / PACKAGES
addappid(626021, 1, "629d3f9dc76fc7d415ec46cad073d1c4deb58f8796b826355494b98ff789d6c6")

