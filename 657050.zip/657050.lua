-- Lua provided by RyzenAPI
-- Game: Game: AppID 657050

-- MAIN APPLICATION
addappid(657050)
-- Game: addappid(657050)

-- MAIN APP DEPOTS / PACKAGES
addappid(657051, 1, "3585aec8b6e2159e15cda66d7dc98a0666b767343dac0cebab3f148b4542dfdb")
addappid(657052, 1, "e40c79aab148e58fea00f705f2acbfaaf57dda81e2b9f8f60c977836b70fabc1")
addappid(657053, 1, "53a7b80bec9aa2420df52463ffc0bf853c9286ae01f79f8475362497002234b5")
addappid(657054, 1, "bba5c1cb57d453b9562840a195975731ecaaa3aaa667f14ed1d20d3a60565405")
addappid(657055, 1, "7d4663efe0da4e559360f047f71a370ea675ccdc429fd14dd5c0f79f1eeeb88e")
addappid(657056, 1, "c8a8dfa9c79adcc281d648bfc15236ff74fda850dd6b6f3fee758233e483652a")
addappid(657057, 1, "a4a9dffb4b8a47074df305c96a547a771032fc29c078379ebf3318139a3c41eb")
addappid(657058, 1, "e8d146626b6e292bebe2a92187cf363c8cf503ce6e3fdf373e2b7b0846dff460")
