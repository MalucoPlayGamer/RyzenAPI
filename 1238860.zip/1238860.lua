-- Lua provided by RyzenAPI
-- Game: AppID 1238860

-- MAIN APPLICATION
addappid(1238860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238861, 1, "a70aeb51423fa65eff9fb75092a3bafbedf41c2f0cc4f66caee89c3d31be99d2")
addappid(1238862, 1, "4c0d025b655f6d76c0118b94dfdb05170f5e030dcd87687c1415976908f2b07d")
addappid(1238863, 1, "9abb028584fd39382a972e489d5b0e437664b94458b65aa9cdba5d163f2821f4")
addappid(1238864, 1, "434c27900b081b42c0dbdee98ee7d2096307f6f0c1c3f4d29b0c290506e60f05")
addappid(1238865, 1, "82b5da1d97ace868a8b27c25927ec77928a9ef159c7cb4975995be22a7ab0826")
addappid(1238866, 1, "fd77ebbbd8bc560070ffc11a6f94e1d18de714341cb4e0dad41201d09863d3c3")
addappid(1238867, 1, "2e09ae88bf21599995be746fcf13f5918f4c7d65c17ca8d2edbc00c31bc58ec4")
addappid(1238868, 1, "2e231f6c99fac90432559ae3b51ad05a34c1903704e16c9240e288e03854b6ba")
addappid(1238869, 1, "c68272de8a3e563d022b970329af67fa3c2f0f35313276f085ebad2f3a4684c5")
addappid(1238872, 1, "9743c66c09d3c6e0e52fdb5cfed0341e621e36f25575576de5d9c211cfa58b6c")
addappid(1238873, 1, "776f34401a8172781ef5cc608f59dd20718fb644071a1daed61aa86bfee80813")
addappid(1238874, 1, "4663f85a8f01aa04196e1e39cddf285a44d5f46520dc2c9db18d7c957bafb443")
addappid(1238875, 1, "38f003a48cd1e5bc78b2bac043fa502b896d52c99e66199978cb29b2689f21ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1238870)
addappid(1238871)
addappid(1272640)
addappid(1272641)
addappid(1272642)
addappid(1272643)
addappid(1272644)
addappid(1272645)
addappid(1272650)
addappid(1272654)
addappid(1272657)
addappid(1276020)
addappid(1315430)
addappid(1315431)
addappid(1315432)
addappid(1315433)
addappid(1315434)
addappid(1315435)
addappid(1315440)
addappid(1315441)
addappid(1315442)
addappid(1315443)
addappid(1315470)
addappid(1315471)
addappid(1315472)
addappid(1315480)
