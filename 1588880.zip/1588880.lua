-- Lua provided by RyzenAPI
-- Game: Seductive Tombs

-- MAIN APPLICATION
addappid(1588880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1588881, 1, "d7fbb067006aba30f1e8d5db08464072857ed4801a8090d5c0f09c8ad6263398")

