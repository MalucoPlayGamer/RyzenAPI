-- Lua provided by RyzenAPI
-- Game: addappid(1588880)

-- MAIN APPLICATION
addappid(1588880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588881, 1, "d7fbb067006aba30f1e8d5db08464072857ed4801a8090d5c0f09c8ad6263398")
