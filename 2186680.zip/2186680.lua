-- Lua provided by SkyAPI 
-- Game: Warhammer 40,000: Rogue Trader
addappid(2186680)
addappid(2186681, 1, "28fb2e6880c18c5a8f226e85577726ff170ba4d056a169247856dc1ad15c45a9")
addappid(2186682, 1, "9f0466c4c63e89d1a6e336a98079e9635acfd48c7c127c1fbfcb04ccec12e05c")
addappid(2682660, 0, "42d397205a25cc88be18385660cbf934a5b60dc736bf4e610293bb24b581e1a9")
