-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Rogue Trader

-- MAIN APPLICATION
addappid(2682660)
addappid(2951990)
addappid(3622820)
addappid(4226770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186680, 1, "61c3f89a7dddaee81487d704d3932e95dde00919dee5e8499770aba982703b83") -- Warhammer 40,000: Rogue Trader
addappid(2186681, 1, "28fb2e6880c18c5a8f226e85577726ff170ba4d056a169247856dc1ad15c45a9") -- Depot 2186681
addappid(2186682, 1, "9f0466c4c63e89d1a6e336a98079e9635acfd48c7c127c1fbfcb04ccec12e05c") -- Depot 2186682
addappid(2682660, 1, "42d397205a25cc88be18385660cbf934a5b60dc736bf4e610293bb24b581e1a9") -- Warhammer 40,000 Rogue Trader - Deluxe Pack - Depot 2682660
addappid(2951991, 1, "47fb2a7f5c69f478464b2dc16e22cb386f8937b69065b47c49e8e9140ea3c3f7") -- Warhammer 40,000 Rogue Trader - Void Shadows - Depot 2951991
addappid(2951992, 1, "11d8b1c92b160025d10ae272d231b075bb4520b3a4f7b85be57be2cd0c2d2d7a") -- Warhammer 40,000 Rogue Trader - Void Shadows - Depot 2951992
addappid(3622821, 1, "734180a123f43796ae882d1d4aff76d40e67dbe95392726ea51c7651634014a1") -- Warhammer 40,000 Rogue Trader - Lex Imperialis - Depot 3622821
addappid(3622822, 1, "1880e824e9b4a1d6886ebf35dfbdae11db20c4e67923e72e52e02b9740a8dad9") -- Warhammer 40,000 Rogue Trader - Lex Imperialis - Depot 3622822
addappid(4226771, 1, "1c77fac93754bfc4d46472bbe88f1c773724e6fc1881d762e8f3f8617bbea087") -- Warhammer 40,000 Rogue Trader - The Infinite Museion - Depot 4226771
addappid(2682670) -- Warhammer 40,000 Rogue Trader - Voidfarer Pack
addappid(2687230) -- Warhammer 40,000 Rogue Trader - Season Pass
addappid(2696650) -- Warhammer 40,000 Rogue Trader - Limited Outfit
addappid(2700400) -- Warhammer 40,000 Rogue Trader - Founders Pack
addappid(3650060) -- Warhammer 40,000 Rogue Trader - Season Pass 2
addappid(3650800) -- Warhammer 40,000 Rogue Trader - Appearance Pack
addappid(3672730) -- Warhammer 40,000 Rogue Trader - The Shovel DLC
