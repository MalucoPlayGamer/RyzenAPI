-- Lua provided by RyzenAPI
-- Game: Ayni Fairyland

-- MAIN APPLICATION
addappid(885790)
-- Game: addappid(885790)

-- MAIN APP DEPOTS / PACKAGES
addappid(885792,0,"731706d9444721a106a6371c72ec2501e77000627994bd302d5808c82049cfe9")
