-- Lua provided by RyzenAPI
-- Game: 316600

-- MAIN APPLICATION
addappid(316600)
-- Game: addappid(316600)

-- MAIN APP DEPOTS / PACKAGES
addappid(316601, 1, "c74425bd896c400de53aeece45b974b9c6534bd07f1a44047f6cc8129e175315")
