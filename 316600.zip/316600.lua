-- Lua provided by RyzenAPI
-- Game: QP Shooting - Dangerous!!

-- MAIN APPLICATION
addappid(316600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(316601, 1, "c74425bd896c400de53aeece45b974b9c6534bd07f1a44047f6cc8129e175315")
