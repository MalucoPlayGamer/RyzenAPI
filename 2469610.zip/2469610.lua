-- Lua provided by RyzenAPI 
-- Game: Forklift Simulator 2023
addappid(2469610)
addappid(2469611, 1, "749f61d2988eab162857aa9ccebe2aac94f4863eabe3bdb4552202e354931edb")
