-- Lua provided by SkyAPI 
-- Game: Galaxy Pass Station
addappid(1571990)
addappid(1571991, 1, "5e0633a86b4fee9372e42b10796b8185b4764f962d52d12c727184cf585968a3")
