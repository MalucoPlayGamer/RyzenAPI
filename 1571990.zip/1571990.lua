-- Lua provided by RyzenAPI
-- Game: Galaxy Pass Station

-- MAIN APPLICATION
addappid(1571990)
-- Game: addappid(1571990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571991, 1, "5e0633a86b4fee9372e42b10796b8185b4764f962d52d12c727184cf585968a3")
