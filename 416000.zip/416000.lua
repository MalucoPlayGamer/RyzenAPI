-- Lua provided by RyzenAPI
-- Game: Game: Orange Season

-- MAIN APPLICATION
addappid(416000)
-- Game: addappid(416000)

-- MAIN APP DEPOTS / PACKAGES
addappid(416001, 1, "699b950ecb4a5a1346833509e522987654d91bc2d8c4b38fa9132bcebfde02d6")
