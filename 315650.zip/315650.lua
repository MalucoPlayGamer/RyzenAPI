-- Lua provided by RyzenAPI
-- Game: Game: Deep Under the Sky

-- MAIN APPLICATION
addappid(315650)
-- Game: addappid(315650)

-- MAIN APP DEPOTS / PACKAGES
addappid(315651, 1, "9c3653c71ecc17ad03cfcdc3f54777a0e32dc773868adba134e8ca4091cbe88f")
