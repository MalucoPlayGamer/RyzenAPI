-- Lua provided by RyzenAPI
-- Game: AppID 655350

-- MAIN APPLICATION
addappid(655350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(655351, 1, "caea677b2cd3bca64d9ada17d99ea9e06ade0f8a8897eafb462f98af9ee8570a")

