-- Lua provided by RyzenAPI 
-- Game: AppID 655350
addappid(655350)
addappid(655351, 1, "caea677b2cd3bca64d9ada17d99ea9e06ade0f8a8897eafb462f98af9ee8570a")
