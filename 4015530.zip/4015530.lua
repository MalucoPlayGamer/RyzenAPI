-- Lua provided by RyzenAPI
-- Game: MyVoiceZoo

-- MAIN APPLICATION
addappid(4015530)

-- MAIN APP DEPOTS / PACKAGES
addappid(4015531, 1, "b560c7cd9497b0a08b869cd05ee3314e848c16967d2389b02efb45d57a112ff4")

