-- 1067810's Lua and Manifest Created by Hubcap Manifest
-- First Day
-- Created: September 29, 2025 at 12:26:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 4
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(1067810) -- First Day
-- MAIN APP DEPOTS
addappid(1067811, 1, "3ef506adfd55a742f01dd0d50dad05826fa56ebd5da183d29c08fc71e05df8fd") -- First Day Content
setManifestid(1067811, "7820382884534658967", 7622123048)
addappid(1067812, 1, "ea4680cf54c17ccf1a9fb9b13c62660a46f70f88b6b19cd027c7b1890d145d3f") -- Хранилище First Day Linux
setManifestid(1067812, "1533257888292657915", 7900000249)
addappid(1067813, 1, "086254cc1decb3ba02698cac42798771645f5e5a27d438b09e9aa684504f65cb") -- Хранилище First Day Mac
setManifestid(1067813, "8407923402671536850", 7749503104)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1802320) -- First Day - Old players bonus
addappid(1832970) -- First Day - Custom Fraction Flags Uploader
addappid(1893250) -- First Day - Supporter Pack
addappid(1915650) -- First Day - Time Control