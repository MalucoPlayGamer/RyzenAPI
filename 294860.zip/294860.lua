-- Lua provided by RyzenAPI
-- Game: Valkyria Chronicles™

-- MAIN APPLICATION
addappid(294860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294861, 1, "d0b82710056792d38911606bf849827a6d039fc149916cd4d9fc37618a615ba5")
addappid(314780, 0, "75607c41123c7d4eee5d9e353a9e63c7cfd0740b2bc7b65ee9dc053269c4705d")
addappid(314781, 0, "825d30177885d5b8398e7c3cd24d6e45d4a33a648fd2659a50eaabc306e08958")
addappid(314782, 0, "1a64a815d5afce01f1e5de3f7e7a23a925ddad8e7bb73321abec337b1f2f9c06")
addappid(314783, 0, "b006873bd7091d8bc49b7ed1e4eda7d52827a1265b9b133f81df24c5c307aaad")
