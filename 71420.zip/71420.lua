-- Lua provided by RyzenAPI
-- Game: 71420

-- MAIN APPLICATION
addappid(71420)
-- Game: addappid(71420)

-- MAIN APP DEPOTS / PACKAGES
addappid(71421, 1, "65f29b45a3327cd4ff4e0dc30ad79fc15901f37407d11fb3d8efcb68d5069949")
