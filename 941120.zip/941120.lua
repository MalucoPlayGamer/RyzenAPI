-- Lua provided by RyzenAPI
-- Game: Optimum Link

-- MAIN APPLICATION
addappid(941120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(941121, 1, "9ff23818f80ded4ffde4cc2a906340b24df81992186ef8570259f8cd0a1e53ac")

