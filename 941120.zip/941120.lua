-- Lua provided by RyzenAPI
-- Game: Optimum Link

-- MAIN APPLICATION
addappid(941120)
-- Game: addappid(941120)

-- MAIN APP DEPOTS / PACKAGES
addappid(941121, 1, "9ff23818f80ded4ffde4cc2a906340b24df81992186ef8570259f8cd0a1e53ac")
