-- Lua provided by RyzenAPI
-- Game: 820190

-- MAIN APPLICATION
addappid(820190)
-- Game: addappid(820190)

-- MAIN APP DEPOTS / PACKAGES
addappid(820191, 1, "3cba504a549a8114daae505e12af5123dc046f678ceed2311f2e6a7e8b6a2b4e")
