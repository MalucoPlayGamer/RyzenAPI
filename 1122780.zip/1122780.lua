-- Lua provided by RyzenAPI
-- Game: Highly Likely

-- MAIN APPLICATION
addappid(1122780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122781, 1, "1a51be9b30070af8599548baa2a34827734cfd890999d81601d43eaeeb7f888d")

