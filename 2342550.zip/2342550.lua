-- Lua provided by RyzenAPI
-- Game: TOONCOP

-- MAIN APPLICATION
addappid(2342550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342551, 1, "c405050f0e272df824e67c7ca970cac3bb6a79ea89810e136516255630983d88")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
