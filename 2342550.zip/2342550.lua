-- Lua provided by RyzenAPI
-- Game: Game: TOONCOP

-- MAIN APPLICATION
addappid(2342550)
-- Game: addappid(2342550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342551, 1, "c405050f0e272df824e67c7ca970cac3bb6a79ea89810e136516255630983d88")
