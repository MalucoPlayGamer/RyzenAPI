-- Lua provided by RyzenAPI
-- Game: addappid(1275380)

-- MAIN APPLICATION
addappid(1275380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275381, 1, "061da62c603eaa44c2b07dd2d80532ead92d72a77a584ddb17378070259df1da")
