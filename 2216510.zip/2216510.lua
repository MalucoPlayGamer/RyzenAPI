-- Lua provided by RyzenAPI
-- Game: PostApo

-- MAIN APPLICATION
addappid(2216510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216511, 1, "9ade1382e56c09f67cff187540181a5f7883d9291bded557aa15e2b496dde021")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
