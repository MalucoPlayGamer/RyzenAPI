-- Lua provided by RyzenAPI
-- Game: Chacara

-- MAIN APPLICATION
addappid(2147640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147644,0,"65ace7fcd3863564687d6cb8e4a5af53142473c6bcb9543ce3c1e7c56a086b97")
addappid(2147645,0,"4830e97cc5bb3dc1cb83da51515fd08c13b057006383676622a8fadfab4fee38")

