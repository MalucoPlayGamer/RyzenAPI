-- Lua provided by SkyAPI 
-- Game: PIT OF GOBLIN
addappid(3253530)
addappid(3253531, 1, "53373a5c73133e1f766287d5deabd89b5913e552d587abb71dd4a8bcb81f9344")
