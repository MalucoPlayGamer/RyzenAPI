-- Lua provided by RyzenAPI
-- Game: PIT OF GOBLIN

-- MAIN APPLICATION
addappid(3253530)
-- Game: addappid(3253530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253531, 1, "53373a5c73133e1f766287d5deabd89b5913e552d587abb71dd4a8bcb81f9344")
