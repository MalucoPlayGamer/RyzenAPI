-- Lua provided by RyzenAPI
-- Game: addappid(1787330)

-- MAIN APPLICATION
addappid(1787330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787331, 1, "9d405e1bee21e52096a43769ff856cb522150a42fa61da576d6635688b0e6d45")
addappid(1787332, 1, "b51155a28fc7cebcbc45e30d2c6d9f15c26b27d9d12def30b617e3ddd3a5e555")
