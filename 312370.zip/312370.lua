-- Lua provided by RyzenAPI 
-- Game: Warhammer 40,000: Armageddon (Classic)
addappid(312370)
addappid(312371, 1, "4845b52c22b02fa0e35db3fce0c087504f90e4b6ef6d3f69585fee6de7448550")
addappid(312372, 1, "b5bb1887c9ac92f1effbce4ca2c636dc9c084f52df3f781b2e52463dfd4af9b9")
addappid(437110, 0, "1cec5197cb7ba133a2365a057ae306b00c982b06b760b8ed843f24d702f0d6f9")
