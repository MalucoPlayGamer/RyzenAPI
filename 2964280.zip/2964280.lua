-- Lua provided by RyzenAPI
-- Game: addappid(2964280)

-- MAIN APPLICATION
addappid(2964280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964281, 1, "30ea11a6a97b9f58a839b3dea80ce248d2ffecfcb93b0320ac0b8c56943b1737")
