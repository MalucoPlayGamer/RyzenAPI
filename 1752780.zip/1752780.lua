-- Lua provided by RyzenAPI
-- Game: Game: City of Springs

-- MAIN APPLICATION
addappid(1752780)
-- Game: addappid(1752780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752781, 1, "878d7798a5bfa886a4c975d14d9388ca29d96c77a712b08656837e55779dc721")
