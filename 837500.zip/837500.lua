-- Lua provided by RyzenAPI
-- Game: 837500

-- MAIN APPLICATION
addappid(837500)
addappid(925620)
addappid(925621)
-- Game: addappid(837500)

-- MAIN APP DEPOTS / PACKAGES
addappid(837501, 1, "7e57e63fd7fc28abb2dd235708a319f3f50450de134c54f7f5c8d4e897b28d0a")
