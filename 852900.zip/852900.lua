-- Lua provided by RyzenAPI 
-- Game: AppID 852900
addappid(852900)
addappid(852901, 1, "e59045644716950d5203079d774b7c4013957d619e1db6e2e9b92b9d3f559916")
addappid(852902, 1, "96f0ea9386093e39aeb67915a0d151baae55e7b2c6befba1d0856bf653e4adbc")
