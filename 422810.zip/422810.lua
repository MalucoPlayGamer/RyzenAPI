-- Lua provided by RyzenAPI
-- Game: River City Ransom: Underground

-- MAIN APPLICATION
addappid(422810)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(422812,0,"88732fc4ced9dbf78dfcb5d7d0d181f30e10cf46447381dca312546ba0392c7f")
addappid(422814,0,"f027defcd786cf7330b9269075f1f931ccc53bb6e32110e00f09a1ad5be0219b")
addappid(422815,0,"e10e91567e2facf199fe4b09c8de4ae64b088305829886d2a11ff467a606da38")

