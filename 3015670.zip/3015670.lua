-- Lua provided by RyzenAPI
-- Game: 3015670

-- MAIN APPLICATION
addappid(3015670)
-- Game: addappid(3015670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015671, 1, "141dafdc3319df50bfe9750ca458ad593c7e2e58be9996437137b6214c47d149")
