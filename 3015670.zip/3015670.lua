-- Lua provided by RyzenAPI 
-- Game: AppID 3015670
addappid(3015670)
addappid(3015671, 1, "141dafdc3319df50bfe9750ca458ad593c7e2e58be9996437137b6214c47d149")
