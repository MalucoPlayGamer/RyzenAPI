-- Lua provided by RyzenAPI
-- Game: AppID 1009990

-- MAIN APPLICATION
addappid(1009990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009991, 1, "ea0884860b9bb87171a911137286870755eabab590960ce80ce3257bb3d69031")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
