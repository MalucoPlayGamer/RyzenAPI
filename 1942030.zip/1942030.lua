-- Lua provided by RyzenAPI
-- Game: Nero Score - PC benchmark & performance test

-- MAIN APPLICATION
addappid(1942030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942031, 1, "a680e2b1f8a6c90ab884890e9fac7dd418560c5760d526fb2ce18d91352960d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
