-- Lua provided by RyzenAPI
-- Game: 1942030

-- MAIN APPLICATION
addappid(1942030)
-- Game: addappid(1942030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942031, 1, "a680e2b1f8a6c90ab884890e9fac7dd418560c5760d526fb2ce18d91352960d6")
