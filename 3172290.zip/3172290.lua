-- Lua provided by RyzenAPI
-- Game: Game: Milfy Way: Space Orgasm 🪐🔞

-- MAIN APPLICATION
addappid(3172290)
-- Game: addappid(3172290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172291, 1, "16599f2e95b031f01f0bc729788d1c30367fd1d4e795a0ae17d9d47e3cbf4f5c")
