-- Lua provided by RyzenAPI
-- Game: Anomaly Agent Demo

-- MAIN APPLICATION
addappid(2559260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559261, 1, "c59c7476f1326de1d03fedfe62fcbfbbd0f8f02436bdd4d7a9bcf78500c53485")

