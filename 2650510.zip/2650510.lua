-- Lua provided by RyzenAPI
-- Game: It's Kooky - Land of Aotearoa

-- MAIN APPLICATION
addappid(2650510) -- It's Kooky - Land of Aotearoa

-- MAIN APP DEPOTS / PACKAGES
addappid(2650511, 1, "991859256f46d86ca841d67f0e42c03a2b65b7443cd497e2b1fb73e47d23a54b") -- Depot 2650511

