-- Lua provided by RyzenAPI
-- Game: Night Swarm

-- MAIN APPLICATION
addappid(3668370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668371,0,"980df52f8f9145bce6710c1de03dd3e91fce5c30ba47bf36ef798b1217b54718")

