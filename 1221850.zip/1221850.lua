-- Lua provided by RyzenAPI
-- Game: AUDICA - Darren Korb ft. Ashley Barrett - "We All Become"

-- MAIN APPLICATION
addappid(1221850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221850,0,"465595f7eb366c77bf5f4b366de1c5f6a7296725230dd4499091499e5b323c70")

