-- Lua provided by RyzenAPI
-- Game: 异世江湖录(JiangHu Record  Of Another World)

-- MAIN APPLICATION
addappid(1103510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103511, 1, "7ed6aa1389d040e667a8b3ccb0bb7d27403d8cd390228ec4b35e41050f2d4446")
