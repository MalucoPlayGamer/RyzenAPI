-- Lua provided by RyzenAPI
-- Game: Binary Domain Demo

-- MAIN APPLICATION
addappid(210310)

-- MAIN APP DEPOTS / PACKAGES
addappid(210311, 1, "a4251d8bd2ee4494472f9b0c34b6f8588f12168fdd4ec20d50b0d9ca3cc6e644")

