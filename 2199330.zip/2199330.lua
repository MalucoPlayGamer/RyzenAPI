-- Lua provided by RyzenAPI 
-- Game: Aestik
addappid(2199330)
addappid(2199331, 1, "aa3d6f9edf5e88f0b1ea7ce1ba3b61881b19e23d603399872ae867f8573e2f8d")
