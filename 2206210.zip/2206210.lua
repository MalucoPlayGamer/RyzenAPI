-- Lua provided by RyzenAPI
-- Game: GYLT

-- MAIN APPLICATION
addappid(2206210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206211, 1, "2ed1ab5c77a13a47146db62841769107a8f98478032654e3aebf9e27a2022051")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
