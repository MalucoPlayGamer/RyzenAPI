-- Lua provided by RyzenAPI 
-- Game: GYLT
addappid(2206210)
addappid(2206211, 1, "2ed1ab5c77a13a47146db62841769107a8f98478032654e3aebf9e27a2022051")
