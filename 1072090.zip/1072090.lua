-- Lua provided by RyzenAPI
-- Game: Game: the jester's revenge

-- MAIN APPLICATION
addappid(1072090)
-- Game: addappid(1072090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072091, 1, "fd4fd4765d90a47e89b2c1d260274878bd59e8ffba8fcd18f8146ce2323e327b")
