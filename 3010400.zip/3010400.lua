-- Lua provided by RyzenAPI
-- Game: 3010400

-- MAIN APPLICATION
addappid(3010400)
-- Game: addappid(3010400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010401, 1, "1c639c072ce4613abe0a4f8e446e076d340ca35d470ddcd5bbceb2e01919aa95")
