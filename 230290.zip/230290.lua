-- Lua provided by SkyAPI 
-- Game: AppID 230290
addappid(230290)
addappid(230291, 1, "d4032e706d2ed817e94dbf0ee8e96854deacf119261215d15a4f11b481673e64")
addappid(230292, 1, "7a549608cadcf13742cccc734cbca6b6080db136ac34e96993fbf0cc8da7db8c")
