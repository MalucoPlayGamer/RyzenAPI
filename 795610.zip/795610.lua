-- Lua provided by RyzenAPI
-- Game: addappid(795610)

-- MAIN APPLICATION
addappid(795610)

-- MAIN APP DEPOTS / PACKAGES
addappid(795611, 1, "d298bcdb9d7e2cadf3d22ef484f76850ba5b56fd0fbba408d8c17ac6a5ac12d1")
addappid(961780, 0, "ae17faa531fdc7ecc72cd57ee262f6e648fdbc0b4359a44b6b0562f80fa36da1")
