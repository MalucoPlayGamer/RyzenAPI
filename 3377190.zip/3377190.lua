-- Lua provided by RyzenAPI
-- Game: The Edge of Allegoria Soundtrack

-- MAIN APPLICATION
addappid(3377190)
-- Game: addappid(3377190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3377191, 1, "cc8277ba09751e388f1e95484500baf980accc4555af04f5a4a5bc72e8ad8080")
