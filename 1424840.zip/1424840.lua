-- Lua provided by RyzenAPI
-- Game: Game: FUCK OR DIE

-- MAIN APPLICATION
addappid(1424840)
-- Game: addappid(1424840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424841, 1, "55dc42dbd543eda2b3c7b02e7f0a239406ed54aaf8fb3c8537248221e320809a")
