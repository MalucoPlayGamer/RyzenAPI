-- Lua provided by RyzenAPI
-- Game: Era of Miracles

-- MAIN APPLICATION
addappid(1037930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037931, 1, "41700add6b1860eb7025dd0fe73236ee848561b38a9537f1d941e0052ffe972b")

