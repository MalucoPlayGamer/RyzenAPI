-- Lua provided by RyzenAPI
-- Game: addappid(1203670)

-- MAIN APPLICATION
addappid(1203670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203671, 1, "83beb137293027317ec069cf6a7df23cd5c5e6f6ca62948ec31f99e4a9ddbcd4")
