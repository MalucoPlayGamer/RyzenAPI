-- Lua provided by RyzenAPI
-- Game: Cute Capybaras

-- MAIN APPLICATION
addappid(2413840)
addappid(2504280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413841, 1, "6c2fbcf9e091059b9cddc13c45c25682a8a01c0ee6df78eb33d7cb22022e30e3")
