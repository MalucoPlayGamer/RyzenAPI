-- Lua provided by RyzenAPI
-- Game: Neglected：Theia:Prequel

-- MAIN APPLICATION
addappid(1584700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584701, 1, "d04521102b4285ca6c33db11860ed97d94648719443a447eefd0257ff5b786d2")
addappid(1584702, 1, "3b5ceab5efacb5bec351b2be7d907b00c4fa2dc15efd16a89b3a193d7293cc09")
addappid(1584703, 1, "c424f9a8e84e7dc1c8bdb5fa4d3df9a5c2b62c078ce8ef5ef3836c508ca055c9")
addappid(1584704, 1, "f563646db986f9ce5402b060449ee18c2eb04b2ee3c2d06aa4d4f359d85b36c3")
addappid(1584709, 1, "697611c71f91dd9b684a40348c6e76c735436ddf81eeda21f313e88ea0f894d0")

