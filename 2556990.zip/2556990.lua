-- Lua provided by RyzenAPI
-- Game: Beyond Good & Evil - 20th Anniversary Edition

-- MAIN APPLICATION
addappid(2556990)
-- Game: addappid(2556990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556991, 1, "fcfb5884860aaf7a15a1a823f60814216d3bb2fdcac130608793ae365b774ac6")
