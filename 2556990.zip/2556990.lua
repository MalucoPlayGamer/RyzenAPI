-- Lua provided by RyzenAPI
-- Game: Beyond Good & Evil - 20th Anniversary Edition

-- MAIN APPLICATION
addappid(2556990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556991, 1, "fcfb5884860aaf7a15a1a823f60814216d3bb2fdcac130608793ae365b774ac6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2691270)
