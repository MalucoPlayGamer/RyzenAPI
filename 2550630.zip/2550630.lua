-- Lua provided by RyzenAPI 
-- Game: 808s&Genetics
addappid(2550630)
addappid(2550631, 1, "6a83f84dd43cff1e1e21033549e78e3c2131a0964bfff394e66df1a7f0a5b8de")
