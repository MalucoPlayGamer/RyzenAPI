-- Lua provided by RyzenAPI
-- Game: Return to Monkey Island

-- MAIN APPLICATION
addappid(2060130)
addappid(2147750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2060131, 1, "9b3489872d5cfd52d345652875617a7e2dedbcc7671f194b085a91ef84173295")
addappid(2060132, 1, "d49033fb18c6d449cecf1a37702b544bb15c4f2b8b6ee1fc4d1eea659b105e15")
addappid(2060133, 1, "3f61c4071a6ac73bfe28fea4de1230d15735200674dd3b3a077d16d7d0e336fb")
