-- Lua provided by RyzenAPI
-- Game: Burden

-- MAIN APPLICATION
addappid(783310)

-- MAIN APP DEPOTS / PACKAGES
addappid(783311,0,"b2969a937805750480b8b3ab789445d28b3f79a989ccefda32353b12d7da0fa0")

