-- Lua provided by RyzenAPI
-- Game: Burden

-- MAIN APPLICATION
addappid(783310)

-- MAIN APP DEPOTS / PACKAGES
addappid(783311,0,"b2969a937805750480b8b3ab789445d28b3f79a989ccefda32353b12d7da0fa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
