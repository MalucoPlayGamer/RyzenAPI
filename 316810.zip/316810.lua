-- Lua provided by RyzenAPI
-- Game: addappid(316810)

-- MAIN APPLICATION
addappid(316810)

-- MAIN APP DEPOTS / PACKAGES
addappid(316811, 1, "2a80381a49899badbc3933f9da91ef6e6e361d6bfdb5c13f3d492d4ff47023c7")
addappid(316812, 1, "5ed4365a7d01c9c6e392e07b99be40a1433b9b7e2eaaff5bf117bcebc86a82c5")
addappid(316813, 1, "833774082e4fac92ed071cf7bdee5175dd40e6faddd2c703afc87382f3939d78")
addappid(316814, 1, "cd2ce72cfd8eb2ee9f330a5cb43da222718123075cd21220e0337543588dda89")
