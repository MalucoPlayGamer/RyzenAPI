-- Lua provided by SkyAPI 
-- Game: Ratopia Demo
addappid(2337200)
addappid(2337201, 1, "843049c48fb216b8641800f0e1e959a74e91ece155ff99d874b158012b7ce179")
