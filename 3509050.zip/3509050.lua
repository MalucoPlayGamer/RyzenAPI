-- Lua provided by RyzenAPI
-- Game: Game: AppID 3509050

-- MAIN APPLICATION
addappid(3509050)
-- Game: addappid(3509050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509051, 1, "04a3d1a70bc55ef5268117e486ffad2f11b75cb9ca6ea1ceffbe53e8a8ded033")
