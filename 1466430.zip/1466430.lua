-- Lua provided by RyzenAPI
-- Game: AppID 1466430

-- MAIN APPLICATION
addappid(1466430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466431, 1, "7f8aa44a4a4873f9711766454e82a13844ab82482516e27ed12933eb2033adc8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
