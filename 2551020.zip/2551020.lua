-- Lua provided by RyzenAPI 
-- Game: One-armed robber
addappid(2551020)
addappid(2551021, 1, "8e1a748cb62a372c3114b276d9b9f1d867a346831186b859052edd7a2b050c96")
