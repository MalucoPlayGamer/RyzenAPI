-- Lua provided by RyzenAPI
-- Game: addappid(1376730)

-- MAIN APPLICATION
addappid(1376730)
addappid(1431810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376731, 1, "9710b9e83ca740fc358280587275435db7b57e7f5eb3b91cbca48f6501317136")
