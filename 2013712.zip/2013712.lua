-- Lua provided by RyzenAPI
-- Game: Kaz's Adventure | Extra Level Pack

-- MAIN APPLICATION
addappid(2013712)
-- Game: addappid(2013712)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013712,0,"ab00aeef59d52c658e58fe9f9bfee2e24ca77f4f07750d5ca74a97bd1a5c89a0")
