-- Lua provided by RyzenAPI
-- Game: 1271190

-- MAIN APPLICATION
addappid(1271190)
-- Game: addappid(1271190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271191, 1, "651a1e175c103b555cde86c89a835d61a56819bced9033f6dec8121ba7b4630f")
addappid(1271192, 1, "3924934ce5c5e7d8f89fa2533e81da74771feae1bd19d4648fc69c7e2a4c5eb5")
