-- Lua provided by RyzenAPI
-- Game: Dusk Hollow

-- MAIN APPLICATION
addappid(2151310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2151311, 1, "73a9ffc3854f876dac1fc385e97370a6961db818a7277b08a1c24a13386f0d90")

