-- Lua provided by RyzenAPI
-- Game: Game: Dusk Hollow

-- MAIN APPLICATION
addappid(2151310)
-- Game: addappid(2151310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151311, 1, "73a9ffc3854f876dac1fc385e97370a6961db818a7277b08a1c24a13386f0d90")
