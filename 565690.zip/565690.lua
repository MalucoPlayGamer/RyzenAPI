-- Lua provided by RyzenAPI
-- Game: Ayakashigami

-- MAIN APPLICATION
addappid(565690)
addappid(565691)

-- MAIN APP DEPOTS / PACKAGES
addappid(565692,0,"f01365520afc4c185c6f53f99beb86a548baa627444565fe14b532018907e193")
