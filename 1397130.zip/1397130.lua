-- Lua provided by RyzenAPI 
-- Game: Primateria
addappid(1397130)
addappid(1397131, 1, "c31c4506f23eec9ecb9e80238ded14432d9253003fbd51fcbf12f518c9ab58f2")
