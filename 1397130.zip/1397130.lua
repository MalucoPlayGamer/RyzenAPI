-- Lua provided by RyzenAPI
-- Game: Primateria

-- MAIN APPLICATION
addappid(1397130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1397131, 1, "c31c4506f23eec9ecb9e80238ded14432d9253003fbd51fcbf12f518c9ab58f2")

