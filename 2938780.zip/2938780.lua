-- Lua provided by RyzenAPI
-- Game: 2938780

-- MAIN APPLICATION
addappid(2938780)
-- Game: addappid(2938780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938781, 1, "c6e2415bdbc17aef61a28e7eae37f9d898eb217aff3c326d3e39f4b16b99065b")
