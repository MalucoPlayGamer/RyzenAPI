-- Lua provided by RyzenAPI
-- Game: BlazBlue: Chronophantasma Extend

-- MAIN APPLICATION
addappid(388750)

-- MAIN APP DEPOTS / PACKAGES
addappid(388751, 1, "2b953b431190646fdb936d3d5214f9c6c6f5d81635f0107b0a787af034cb8285")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
