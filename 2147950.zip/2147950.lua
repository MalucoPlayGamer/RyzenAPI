-- Lua provided by RyzenAPI
-- Game: 2147950

-- MAIN APPLICATION
addappid(2147950)
addappid(2147951)
addappid(2147953)
-- Game: addappid(2147950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147952,0,"645c684d240b17e2c544d67be198b29df89b3c76ef49ec5633b3b08462ae1578")
