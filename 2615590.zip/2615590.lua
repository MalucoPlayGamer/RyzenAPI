-- Lua provided by SkyAPI 
-- Game: AppID 2615590
addappid(2615590)
addappid(2615591, 1, "50e9f0c0ded2c384900fa7d8c88e64e5e80ee1420abe9a3e610cf2429848f218")
