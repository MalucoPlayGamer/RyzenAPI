-- Lua provided by RyzenAPI
-- Game: addappid(2615590)

-- MAIN APPLICATION
addappid(2615590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615591, 1, "50e9f0c0ded2c384900fa7d8c88e64e5e80ee1420abe9a3e610cf2429848f218")
