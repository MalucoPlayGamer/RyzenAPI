-- Lua provided by RyzenAPI
-- Game: AppID 203750

-- MAIN APPLICATION
addappid(203750)

-- MAIN APP DEPOTS / PACKAGES
addappid(203751, 1, "20a5d15bdd3b671723b95c229c4a63c9d5c29b3876dba04324f3fcbee4f589a6")
addappid(203752, 1, "38df45ae2edc84a400f321a8ad53bc0cc1664bfa222741e49ae9d113ffd25cb5")
addappid(203753, 1, "01f107c02443ae7cad69857fc4937f5d4725d454da030de8f1b412c5d2214163")
addappid(203754, 1, "2730dfb916c08795f79464f887044e975dee8c77427ddc75444d642df20a6a50")
addappid(203755, 1, "182f4c6769c8473e88df25d7777350e1c3a01d72961bddcaa8234172a881def6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(203765)
addappid(203766)
