-- Lua provided by SkyAPI 
-- Game: Aerial_Knight's Never Yield
addappid(1323540)
addappid(1323541, 1, "84c37b15f9cb78fc13034de58d46fc0d54b943d4c16fd33e004edf8729cf8712")
