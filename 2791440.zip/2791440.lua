-- Lua provided by RyzenAPI
-- Game: Brighter Shores

-- MAIN APPLICATION
addappid(2791440)
-- Game: addappid(2791440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791441, 1, "26a01b237e42c8808353e77330bbc1d704a25c70294ec8722b637a7b3fd7ac9f")
addappid(2791442, 1, "cb2df41209d9655d2e0c30ada7c36bf9ba42ade8082d925560b5be580630a2e7")
