-- Lua provided by RyzenAPI
-- Game: AppID 1189100

-- MAIN APPLICATION
addappid(1189100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189101, 1, "79f24bd2f4144c72053a730936b79682e151d998834bdfc7373e345617d4c6a2")
addappid(1189103, 1, "95b958463c58580250a7295e94565ede05f2cdcaee1e772a7c4d73c025d70c2e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3024430)
addappid(3732510)
