-- Lua provided by SkyAPI 
-- Game: Playtown Genesis
addappid(3247150)
addappid(3247151, 1, "b3823305ec3ed7212731c1550118744cf2a8f4dd6dbe56feac04cf0b177a6bb8")
