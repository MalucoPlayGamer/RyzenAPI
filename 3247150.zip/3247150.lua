-- Lua provided by RyzenAPI
-- Game: Playtown Genesis

-- MAIN APPLICATION
addappid(3247150)
addappid(5117650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3247151, 1, "b3823305ec3ed7212731c1550118744cf2a8f4dd6dbe56feac04cf0b177a6bb8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5119390)
