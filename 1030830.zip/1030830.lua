-- Lua provided by RyzenAPI
-- Game: Mafia II: Definitive Edition

-- MAIN APPLICATION
addappid(1030830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030831, 1, "32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")

