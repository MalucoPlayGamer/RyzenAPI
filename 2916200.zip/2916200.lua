-- Lua provided by RyzenAPI
-- Game: addappid(2916200)

-- MAIN APPLICATION
addappid(2916200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916201, 1, "fb6826a979dd204b836a619d5a88d6b0e46c1e681017b985e2d5c3c8adb45330")
