-- Lua provided by RyzenAPI
-- Game: New Yankee 9: The Evil Spellbook

-- MAIN APPLICATION
addappid(1416430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416431, 1, "ea259d41e6808fe1119addabb414f9024952d3eac670fc4efc3363c64ca744fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
