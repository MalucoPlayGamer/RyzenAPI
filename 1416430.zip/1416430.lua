-- Lua provided by RyzenAPI
-- Game: New Yankee 9: The Evil Spellbook

-- MAIN APPLICATION
addappid(1416430)
-- Game: addappid(1416430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416431, 1, "ea259d41e6808fe1119addabb414f9024952d3eac670fc4efc3363c64ca744fd")
