-- Lua provided by RyzenAPI
-- Game: MOBIUS FINAL FANTASY™

-- MAIN APPLICATION
addappid(536930)

-- MAIN APP DEPOTS / PACKAGES
addappid(536931, 1, "ebd0c3cd53e00614576dd7430799eb9aa15decd9d6dd6da99498f2453261cfd7")
addappid(536933, 1, "4c2119c8a8e454b12e2d1355a91906e31b6e69a10cce69e0bef76730da08dd9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
