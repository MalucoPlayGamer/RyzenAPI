-- Lua provided by RyzenAPI
-- Game: 536930

-- MAIN APPLICATION
addappid(536930)
-- Game: addappid(536930)

-- MAIN APP DEPOTS / PACKAGES
addappid(536931, 1, "ebd0c3cd53e00614576dd7430799eb9aa15decd9d6dd6da99498f2453261cfd7")
addappid(536933, 1, "4c2119c8a8e454b12e2d1355a91906e31b6e69a10cce69e0bef76730da08dd9f")
