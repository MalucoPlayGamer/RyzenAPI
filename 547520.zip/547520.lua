-- Lua provided by RyzenAPI
-- Game: Rapture - World Conquest

-- MAIN APPLICATION
addappid(547520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(547521, 1, "8966cf6163245bac5a0f72c3fbbdc352284c9f841fb1ce9b83d323b1b079f7eb")
addappid(547522, 1, "5b9bb174c1662096ff81a6a565a643d15e7b7b6107ae532e6ab8f7f84b28b7bc")
addappid(547523, 1, "4e33c92e0fde9079bff1ff4b02190a3bd6099c052a5e059044943682abcb6e4b")

