-- Lua provided by RyzenAPI
-- Game: Game: Desktop Kanojo

-- MAIN APPLICATION
addappid(1284820)
-- Game: addappid(1284820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284821, 1, "85ce2d712903f210b8feedf9ca3a769d7a1b302f3ca80ac5204812327a9e6304")
addappid(1291700, 0, "4755b150a6e139c4c413f3ba4e8ac53eb147adcf6b1ad2ea313b590accfa8de4")
