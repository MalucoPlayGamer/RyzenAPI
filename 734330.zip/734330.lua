-- Lua provided by RyzenAPI
-- Game: 734330

-- MAIN APPLICATION
addappid(734330)
-- Game: addappid(734330)

-- MAIN APP DEPOTS / PACKAGES
addappid(734331, 1, "e4196490f5846f461dfd7a403b4dee6f1a9ebaadedcd3eb32d923ea04e4dec74")
