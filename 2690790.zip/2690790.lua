-- Lua provided by RyzenAPI
-- Game: Christmas Present

-- MAIN APPLICATION
addappid(2690790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2690791, 1, "a3c8db14cb17560531261b273f7b42ff513613098f433996e4bc5337a27622d0")

