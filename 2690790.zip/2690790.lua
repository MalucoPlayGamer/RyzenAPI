-- Lua provided by RyzenAPI
-- Game: Christmas Present

-- MAIN APPLICATION
addappid(2690790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690791, 1, "a3c8db14cb17560531261b273f7b42ff513613098f433996e4bc5337a27622d0")

