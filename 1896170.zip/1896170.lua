-- Lua provided by RyzenAPI
-- Game: Prince of Suburbia - Part 1

-- MAIN APPLICATION
addappid(1896170)
addappid(2149280)
addappid(3593230)
addappid(4073030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896171, 1, "b210131310ba6e0161da389a200c7ca8915bdf84aaa88eda3d362f8ed2aa0d82")

