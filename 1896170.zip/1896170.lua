-- Lua provided by RyzenAPI
-- Game: Prince of Suburbia - Part 1

-- MAIN APPLICATION
addappid(1896170)
-- Game: addappid(1896170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896171, 1, "b210131310ba6e0161da389a200c7ca8915bdf84aaa88eda3d362f8ed2aa0d82")
