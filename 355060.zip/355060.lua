-- Lua provided by RyzenAPI
-- Game: Sébastien Loeb Rally EVO

-- MAIN APPLICATION
addappid(355060)
addappid(411510)

-- MAIN APP DEPOTS / PACKAGES
addappid(355061, 1, "c19a3a3f9c84a7e539b2d2c0f9847aaf7bdcb2c3eff2faeb0e55163bda1e6473")
addappid(402350, 0, "c8ea9ae267a52cb4a39222c983af388f711300f38c86c24cc0a6f2401e4b1f11")
addappid(408680, 0, "da2b42cf630433a0f757a023d89dddbcce512e475e929748d1fea443360fee9e")
addappid(408690, 0, "8f76dd4209ee678b7224ca6a031fb804aad1067ab548b6f1178f8b35fc5b4eed")
addappid(412080, 0, "e6170b7e7bdef73509e089ab5abd2da3b0d68aef7d4221525b4990fdd860f89d")
