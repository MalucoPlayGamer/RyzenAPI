-- Lua provided by SkyAPI 
-- Game: Farm & Puzzle
addappid(1433980)
addappid(1433981, 1, "72323ef501a54ef1622e83250ed7c837fb2e322a6b23ac70de828c00cf6ba030")
