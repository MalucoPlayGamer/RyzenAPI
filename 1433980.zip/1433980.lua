-- Lua provided by RyzenAPI
-- Game: 1433980

-- MAIN APPLICATION
addappid(1433980)
-- Game: addappid(1433980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433981, 1, "72323ef501a54ef1622e83250ed7c837fb2e322a6b23ac70de828c00cf6ba030")
