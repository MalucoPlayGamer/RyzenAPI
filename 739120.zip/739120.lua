-- Lua provided by RyzenAPI
-- Game: BattleRush Dedicated Server

-- MAIN APPLICATION
addappid(739120)

-- MAIN APP DEPOTS / PACKAGES
addappid(739121, 1, "e5d76ea543b51796935bc7a56dcd30d02310efcac06b1139f0f260ea92652f87")
addappid(739122, 1, "31dcc2f00c1ee1277887541f8554a5302f644ebeb9589ecf521ca21c34724d23")

