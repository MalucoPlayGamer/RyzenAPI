-- Lua provided by RyzenAPI
-- Game: addappid(770110)

-- MAIN APPLICATION
addappid(770110)

-- MAIN APP DEPOTS / PACKAGES
addappid(770111, 1, "43fb6af86d9e2c72702256b80b3e0deb4cc06fec5e2efdea6fa32abd44fb8da7")
