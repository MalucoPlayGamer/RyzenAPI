-- Lua provided by RyzenAPI
-- Game: Game: Dice of God

-- MAIN APPLICATION
addappid(2725320)
-- Game: addappid(2725320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725321, 1, "a924fe74ddc486634b8400dbeb90745a0bb6af2848f0315f203a6cbe5d8cc062")
