-- Lua provided by RyzenAPI
-- Game: Dice of God

-- MAIN APPLICATION
addappid(2725320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2725321, 1, "a924fe74ddc486634b8400dbeb90745a0bb6af2848f0315f203a6cbe5d8cc062")

