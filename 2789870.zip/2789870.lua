-- Lua provided by RyzenAPI
-- Game: Death Fighter

-- MAIN APPLICATION
addappid(2789870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789872,0,"8cf2dcc6d6af1d1bc7724d867a24d697a2da567c71c1aaeda48e7e666df1931e")
