-- Lua provided by RyzenAPI
-- Game: Death Fighter

-- MAIN APPLICATION
addappid(2789870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789872,0,"8cf2dcc6d6af1d1bc7724d867a24d697a2da567c71c1aaeda48e7e666df1931e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
