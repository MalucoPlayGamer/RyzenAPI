-- Lua provided by RyzenAPI
-- Game: 3466730

-- MAIN APPLICATION
addappid(3466730)
-- Game: addappid(3466730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3466731, 1, "f02f3e4dc40ddda75f3fda720974c3ac55e53aa2267ef8a57c6ec21ff7cf3be0")
addappid(3466732, 1, "158b6c07345e06a8e1deb95a2464263f0aaa9f23511a8d4b5721189c054685ee")
