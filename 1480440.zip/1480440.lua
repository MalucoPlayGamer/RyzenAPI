-- Lua provided by RyzenAPI
-- Game: AppID 1480440

-- MAIN APPLICATION
addappid(1480440)
-- Game: addappid(1480440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480441, 1, "7498e16e67f304dd7c549c59b357b0856f652bf2a362f26bdae635f6288fd9ab")
