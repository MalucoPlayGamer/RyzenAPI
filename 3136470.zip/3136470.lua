-- Lua provided by RyzenAPI
-- Game: addappid(3136470)

-- MAIN APPLICATION
addappid(3136470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136471, 1, "66dbb827f7aa7b4fd2906e7a239dbbc7855408d38292e51bd81f4e49b7361ede")
