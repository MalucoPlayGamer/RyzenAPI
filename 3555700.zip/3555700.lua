-- Lua provided by RyzenAPI
-- Game: Liar Game

-- MAIN APPLICATION
addappid(3555700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3555701, 1, "2ab1e0601aa2a258989d7922dd83e59a7e78c1e472cefcb543b5c1ce62e3c345")

