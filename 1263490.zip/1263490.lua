-- Lua provided by RyzenAPI
-- Game: Sweet Solitaire: School Witch

-- MAIN APPLICATION
addappid(1263490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263491, 1, "6d0a2d70e8187231492f5a04fbba948b2310ce976c0f915a5aee2ce880188c09")
addappid(1263494, 1, "42be9b658dc316f120155f9a496baa744b83834427f4f94bc292c4716343691e")

