-- Lua provided by RyzenAPI
-- Game: HELLBREAK

-- MAIN APPLICATION
addappid(3043760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043761, 1, "684821465ee5c71c0134b740a5b0c4e97366be1e609c100ded387898b3f82f7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
