-- Lua provided by RyzenAPI
-- Game: Game: HELLBREAK

-- MAIN APPLICATION
addappid(3043760)
-- Game: addappid(3043760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043761, 1, "684821465ee5c71c0134b740a5b0c4e97366be1e609c100ded387898b3f82f7d")
