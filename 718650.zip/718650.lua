-- Lua provided by RyzenAPI 
-- Game: AppID 718650
addappid(718650)
addappid(718651, 1, "6675f24122b1b934a9046a9af67d642071bcec89740f4db284276c029614e0ef")
addappid(718652, 1, "48b5c0ff4d03c21df305d5a102dfea0d38f62680b854c844c4de2bd4556f15de")
