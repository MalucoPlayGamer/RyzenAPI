-- Lua provided by RyzenAPI
-- Game: Driftland: The Magic Revival

-- MAIN APPLICATION
addappid(718650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(718651, 1, "6675f24122b1b934a9046a9af67d642071bcec89740f4db284276c029614e0ef")
addappid(718652, 1, "48b5c0ff4d03c21df305d5a102dfea0d38f62680b854c844c4de2bd4556f15de")

