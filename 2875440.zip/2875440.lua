-- Lua provided by RyzenAPI
-- Game: INESCAPED

-- MAIN APPLICATION
addappid(228990)
addappid(2875440)

