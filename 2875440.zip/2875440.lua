-- Lua provided by RyzenAPI
-- Game: 2875440

-- MAIN APPLICATION
addappid(228990)
addappid(2875440)

