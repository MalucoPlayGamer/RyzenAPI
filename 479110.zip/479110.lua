-- Lua provided by RyzenAPI 
-- Game: Hunter's Legacy
addappid(479110)
addappid(479111, 1, "b4e54f165263c63f40745c7d7e8cfc13cd668033694b58a38022ae43817d7e2b")
addappid(479113, 1, "86ccb59303395bb9a62a97b508fe9fb0e806a4282e9a94c0282a839a638a2db7")
addappid(480600)
