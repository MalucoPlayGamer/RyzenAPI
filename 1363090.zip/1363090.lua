-- Lua provided by RyzenAPI
-- Game: addappid(1363090)

-- MAIN APPLICATION
addappid(1363090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363091, 1, "83825f7606400ba97e85bf7397ad8c73e29f20e6f3ae21dfeebc5895efb9871b")
