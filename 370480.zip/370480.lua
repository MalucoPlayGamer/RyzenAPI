-- Lua provided by RyzenAPI
-- Game: Game: Pixel Galaxy

-- MAIN APPLICATION
addappid(370480)
-- Game: addappid(370480)

-- MAIN APP DEPOTS / PACKAGES
addappid(370481, 1, "5d6f5d85e17e113469e90469fd22fc5a7ae2f8099e53f133ff68663dc7407519")
addappid(408580, 0, "b38b66b47de2743a7d5d00bc76de0310d24d4a1096f02484c156fb9f1ac744a9")
