-- Lua provided by RyzenAPI
-- Game: Only Jump: GoHome回家

-- MAIN APPLICATION
addappid(2515120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515121, 1, "b1493dae3ddf71724fbdf14e8e6cb9304c9fe1fffda3ea09c5ea973ec53dc797")
