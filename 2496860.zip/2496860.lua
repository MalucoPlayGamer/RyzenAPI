-- Lua provided by RyzenAPI
-- Game: 消失的一款修仙游戏

-- MAIN APPLICATION
addappid(229004)
addappid(2496860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496862,0,"9781863987ad15ee9ef34b166d1d7e3edbea48a7548f232cc6156512d27ceb02")

