-- Lua provided by SkyAPI 
-- Game: AppID 1159520
addappid(1159520)
addappid(1159521, 1, "7d1e436f240c711312aca4fa4b525109875b8638e5596fd74245f10cbedf6075")
addappid(1159522, 1, "cc19780713bbdcf6564070bd9cffe2ca2256030220cd03bd10d42be41f3fea66")
