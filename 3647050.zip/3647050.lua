-- Lua provided by RyzenAPI
-- Game: Anime Dream Match: Girls 2

-- MAIN APPLICATION
addappid(3647050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647051, 1, "566545b400adff06db93f2f40e1919af80c99840743f47d655f32c9ccfe224a9")

