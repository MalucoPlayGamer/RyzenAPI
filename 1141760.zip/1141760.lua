-- Lua provided by SkyAPI 
-- Game: Westale: Peelgrimage
addappid(1141760)
addappid(1141761, 1, "6c0671382423c0b822237943dc30e90aa3e85b17a184ec3f6373edadd1eafec4")
addappid(3251390)
