-- Lua provided by RyzenAPI
-- Game: Westale: Peelgrimage

-- MAIN APPLICATION
addappid(1141760)
addappid(3251390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141761, 1, "6c0671382423c0b822237943dc30e90aa3e85b17a184ec3f6373edadd1eafec4")
