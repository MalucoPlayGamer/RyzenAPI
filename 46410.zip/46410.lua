-- Lua provided by RyzenAPI
-- Game: Avencast: Rise of the Mage

-- MAIN APPLICATION
addappid(46410)
-- Game: addappid(46410)

-- MAIN APP DEPOTS / PACKAGES
addappid(46411, 1, "7dc3ee928152995d0cb2033f762ba746e9968262c6e069041fc7af4b2b62e2e0")
addappid(46412, 1, "b828837ce2323abe15b204707b607c5ae8e11203e3d114638e45702ab4528f24")
addappid(46413, 1, "fa36c4a0fc920fb0443c25265c4129ed9e78829a311f4281f6357023ff9bf715")
