-- Lua provided by RyzenAPI
-- Game: 361420

-- MAIN APPLICATION
addappid(361420)
addappid(2566990)
addappid(2567000)
addappid(2567010)
addappid(2876620)
addappid(3042220)
addappid(3315070)
addappid(3884830)
-- Game: addappid(361420)

-- MAIN APP DEPOTS / PACKAGES
addappid(361422,0,"471756d013ea0594ce2fe60fa33915663d90cf64b086b5b992b85f5fc73d5283")
