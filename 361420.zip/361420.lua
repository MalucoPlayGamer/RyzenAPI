-- Lua provided by RyzenAPI
-- Game: ASTRONEER

-- MAIN APPLICATION
addappid(361420)
addappid(2566990)
addappid(2567000)
addappid(2567010)
addappid(2876620)
addappid(3042220)
addappid(3315070)
addappid(3884830)
addappid(4144820)

-- MAIN APP DEPOTS / PACKAGES
addappid(361422,0,"471756d013ea0594ce2fe60fa33915663d90cf64b086b5b992b85f5fc73d5283")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
