-- Lua provided by RyzenAPI
-- Game: Escape The MonStalkers!

-- MAIN APPLICATION
addappid(3645430)
-- Game: addappid(3645430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645432,0,"9f46f5f60bd1c61e71888245863fa9c192328943ed55f5d8f7825634d9ad4280")
