-- Lua provided by RyzenAPI
-- Game: 3104230

-- MAIN APPLICATION
addappid(3104230)
-- Game: addappid(3104230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104231, 1, "e01d2f99afa338cd6651793fbee4cbf977127cdf372d45dbf27d8bd0a2741de3")
addappid(3104232, 1, "116dba4c34483ecdbea917a4ff8f3cf5ade8a706adaa94f1e5490c1436460f93")
