-- Lua provided by RyzenAPI
-- Game: Game: Oddworld: Soulstorm Enhanced Edition Demo

-- MAIN APPLICATION
addappid(1931450)
-- Game: addappid(1931450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931451, 1, "d08264e50007a133c35f1e2b79f46d32696c97f2938396875b1aeb42b4b5d04e")
