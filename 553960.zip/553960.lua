-- Lua provided by SkyAPI 
-- Game: Husk
addappid(553960)
addappid(553961, 1, "9ce8587c45653dc196caee7816984d8a6de8ffccf58e7675888ba9112391d396")
