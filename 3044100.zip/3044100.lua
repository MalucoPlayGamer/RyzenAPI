-- Lua provided by RyzenAPI
-- Game: Game: Bat to the Heavens

-- MAIN APPLICATION
addappid(3044100)
-- Game: addappid(3044100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044101, 1, "4e0fed514d6d3e80ca95cd0eb7fe9bc6c0b49b2c5f08691ae866045800a37299")
