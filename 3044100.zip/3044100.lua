-- Lua provided by RyzenAPI 
-- Game: Bat to the Heavens
addappid(3044100)
addappid(3044101, 1, "4e0fed514d6d3e80ca95cd0eb7fe9bc6c0b49b2c5f08691ae866045800a37299")
