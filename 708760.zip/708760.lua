-- Lua provided by RyzenAPI
-- Game: Social Club VR : Casino Nights

-- MAIN APPLICATION
addappid(708760)

-- MAIN APP DEPOTS / PACKAGES
addappid(708761,0,"f458ca202e878184bcea8ea5274416e0a6502d036c94df508e0a1be104f88917")

