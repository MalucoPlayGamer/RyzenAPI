-- Lua provided by RyzenAPI
-- Game: Game: AppID 587020

-- MAIN APPLICATION
addappid(587020)
-- Game: addappid(587020)

-- MAIN APP DEPOTS / PACKAGES
addappid(587021, 1, "1e4bd82e389426f5eb24b57c89d06c68419188151fc9463b9c0b2e66f42158d9")
