-- Lua provided by RyzenAPI
-- Game: Super Monkey Ball Banana Mania

-- MAIN APPLICATION
addappid(1316910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316911, 1, "aad865dab6c37bdbed493330e094d5fb2e79311f10a554d9397df1afea88108c")
addappid(1550410, 0, "816787573db8304ef2296c2a108233dffcf653cbaff6ea0cd7152e3c1379c1ce")
addappid(1606090, 0, "17925957871208773963046c1148072abe2a8c624fe49f455bf7b7050b224a35")
addappid(1606252, 0, "b4e5a48e7557ab9d781184aae3141bc0f5e33d8dd927270c58e2148be719973d")
addappid(1606253, 0, "3797f16bb3e6d54a6939fd86187ccb9ef2f58da6950b5028cf69828b1ebcc336")
addappid(1606254, 0, "ddb36b9de118b7e87e878eb94c1640cd907e350cafd8ea9ca90b9fe268580dd3")
addappid(1606255, 0, "5ac0b3de688161e8560e6f024758f3fdb4eee6c752a19cf1a18115f3188857ec")
addappid(1606256, 0, "a0b5cd77c6ee18c16259a9b8aa0a3b0440b92f1a7f3837f78f57453df339e63b")
addappid(1647320, 0, "d482f543f2fd45f238bd47e3218b74c0270e82d7e662414f26d9ee2db0ff24cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1604970)
addappid(1604971)
