-- Lua provided by RyzenAPI
-- Game: 2214302

-- MAIN APPLICATION
addappid(2214302)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214302,0,"30f70df2fa739d2cc9c007cbbdb2fc2c492f22088f0d3cfbfe7100956448d1ab")

