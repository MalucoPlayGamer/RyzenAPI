-- Lua provided by RyzenAPI
-- Game: Action Agents

-- MAIN APPLICATION
addappid(2359850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359851, 1, "709554de06654326a6eb85958bc2ed5d980a49b70b1136113879ab0dda89c4b6")

