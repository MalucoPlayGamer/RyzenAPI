-- Lua provided by RyzenAPI
-- Game: addappid(847580)

-- MAIN APPLICATION
addappid(847580)

-- MAIN APP DEPOTS / PACKAGES
addappid(847583,0,"e78b70389bdc1f4b58a2f67cf824984429d8089aba7d76aa868447d7911dfe4f")
addappid(847584,0,"81ea0eacf34b72f40c1d331121a44cf6c717f8457da28d25893ae7d09ddfa09a")
