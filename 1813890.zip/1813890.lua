-- Lua provided by RyzenAPI
-- Game: addappid(1813890)

-- MAIN APPLICATION
addappid(1813890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813891, 1, "7f1b93cdeae83f33f2f325d5e91890d7efa8c61df32eb787f23e984fc68a7dd5")
