-- Lua provided by RyzenAPI
-- Game: Nightfall: Escape

-- MAIN APPLICATION
addappid(360880)
addappid(514630)

-- MAIN APP DEPOTS / PACKAGES
addappid(360881, 1, "300752188adb287acba23a7e1004f83ba36d387d790f1055dd73a44387f2bd29")
addappid(360882, 1, "27d644600be3ec8ff74eb755d0842479937cb407a542879cd21ff34b8ee1a7b6")
addappid(360883, 1, "a95ce2be0d8e7c38564a26d2b2d15d63c12ebf48588022ba2c9e1c8a306d87b6")
addappid(360884, 1, "5d40477feca7a230ba5c73ee4e355d1461c43b3a27cc2e233cfec0e95cb27e3a")

