-- Lua provided by RyzenAPI
-- Game: 1463600

-- MAIN APPLICATION
addappid(1463600)
-- Game: addappid(1463600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463600,0,"1c5d08062c4482375af1db0113ab0f64d3c87ccb3216f6f84ff3c9648fa28524")
