-- Lua provided by RyzenAPI
-- Game: Airport Ground Handling Simulator VR

-- MAIN APPLICATION
addappid(2088630)
-- Game: addappid(2088630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088631, 1, "1f1f311d926d8680974f24bbcc347325cc7f666864d1194534bc83ebae723dc7")
