-- Lua provided by RyzenAPI 
-- Game: Battle Royale Trainer
addappid(772540)
addappid(772541, 1, "3a0fd7a06600ebbbcc2bca25bf1d7d716a465719a6b2be16281bf4f827e16513")
