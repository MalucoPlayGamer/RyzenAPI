-- Lua provided by RyzenAPI
-- Game: 663000

-- MAIN APPLICATION
addappid(663000)
-- Game: addappid(663000)

-- MAIN APP DEPOTS / PACKAGES
addappid(663001, 1, "d3fdfe4bee847952e88552d47fb1b1ee904ebf4e9f2493fe0a581eca6497a04b")
