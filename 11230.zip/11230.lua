-- Lua provided by RyzenAPI
-- Game: Game: Gumboy Tournament

-- MAIN APPLICATION
addappid(11230)
-- Game: addappid(11230)

-- MAIN APP DEPOTS / PACKAGES
addappid(11231, 1, "a2a1d3285dbc4c7a7bfce9a0812dffb5ff37476fbf302c9600b95edb2b456832")
