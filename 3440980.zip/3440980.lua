-- Lua provided by RyzenAPI
-- Game: 3440980

-- MAIN APPLICATION
addappid(3440980)
-- Game: addappid(3440980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440981, 1, "84d4f374c5eb85454b1f07d1b0673d8e460c059cfd56a04ac3f0cc2c0bde02e9")
