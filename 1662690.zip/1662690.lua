-- Lua provided by RyzenAPI
-- Game: Game: Twin Stones: The Journey of Bukka

-- MAIN APPLICATION
addappid(1662690)
-- Game: addappid(1662690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662691, 1, "c1f250ccb6e39bce027201c6285b6c78ec9fb1ca1eb3552d3e53a36efcf9cdc2")
