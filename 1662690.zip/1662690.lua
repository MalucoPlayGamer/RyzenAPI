-- Lua provided by RyzenAPI
-- Game: Twin Stones: The Journey of Bukka

-- MAIN APPLICATION
addappid(1662690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662691, 1, "c1f250ccb6e39bce027201c6285b6c78ec9fb1ca1eb3552d3e53a36efcf9cdc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
