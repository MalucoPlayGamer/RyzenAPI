-- Lua provided by RyzenAPI
-- Game: Canvas Corridor

-- MAIN APPLICATION
addappid(3389300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389301, 1, "9ea35191b9862ed12f1884597e9be77d91d479f2092f1df0ffbc42921217c0fd")
