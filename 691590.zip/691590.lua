-- Lua provided by RyzenAPI
-- Game: KryptCrawler

-- MAIN APPLICATION
addappid(691590)

-- MAIN APP DEPOTS / PACKAGES
addappid(691591, 1, "7088843f01cca1dc7f01d8f420e634a5813888b1d26e009e8b0c8ec3ab11eeb9")

