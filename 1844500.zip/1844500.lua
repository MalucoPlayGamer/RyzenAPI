-- Lua provided by RyzenAPI
-- Game: addappid(1844500)

-- MAIN APPLICATION
addappid(1844500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844501, 1, "3ee9d7fb915387b26a55de06c32e9c57228418104466c9ffa3455d352f32f3aa")
