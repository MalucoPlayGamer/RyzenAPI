-- Lua provided by RyzenAPI 
-- Game: AppID 781280
addappid(781280)
addappid(781281, 1, "30bac691277583bcac5e5bfab640a47379936905d63b1d907ebe0681a0ca59f4")
