-- Lua provided by RyzenAPI
-- Game: Hell Maiden

-- MAIN APPLICATION
addappid(3372060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372061,0,"f74389c861c791ea4a33813b7575ac42a7abca2578013a775bc62acb2e89003f")

