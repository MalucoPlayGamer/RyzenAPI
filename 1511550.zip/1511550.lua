-- Lua provided by SkyAPI 
-- Game: AppID 1511550
addappid(1511550)
addappid(1511551, 1, "712033946e0431da35b6989f4b58f1859a9f7fa4e360cd08e18155a0bb268b25")
