-- Lua provided by RyzenAPI
-- Game: Russian Hentai

-- MAIN APPLICATION
addappid(1511550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511551, 1, "712033946e0431da35b6989f4b58f1859a9f7fa4e360cd08e18155a0bb268b25")

