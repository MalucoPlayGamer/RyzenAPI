-- Lua provided by RyzenAPI
-- Game: 2946210

-- MAIN APPLICATION
addappid(2946210)
-- Game: addappid(2946210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946211, 1, "3585700c7dce068aac2b9e6f5b1cd439283ae04320f5b1c31590b7baad76b494")
