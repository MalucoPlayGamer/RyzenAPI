-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1442910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442912,0,"d0df5cb4dc54a5b45ac24bd036443f1b8aa73899bf3cc10d886d01a8da1006db")
