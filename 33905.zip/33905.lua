-- Lua provided by RyzenAPI
-- Game: ARMA 2 Dedicated Server

-- MAIN APPLICATION
addappid(33905)

-- MAIN APP DEPOTS / PACKAGES
addappid(33903,0,"cedc16d11f863f1e9e6b08bd8ae997a353017eb9238d8e89f71f0bc458c6f13f")

