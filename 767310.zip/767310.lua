-- Lua provided by RyzenAPI
-- Game: Brutal Inventions

-- MAIN APPLICATION
addappid(767310)

-- MAIN APP DEPOTS / PACKAGES
addappid(767311, 1, "50ec49ac9248f6a59423381bfa818cdf52d27c8a6495cedcb117ecfd5745475c")
