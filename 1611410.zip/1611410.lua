-- Lua provided by RyzenAPI
-- Game: 1611410

-- MAIN APPLICATION
addappid(1611410)
-- Game: addappid(1611410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611411, 1, "2dda85ea6b029573e04eec4d8f19ee82711862fb252640c187230e9ab549443f")
