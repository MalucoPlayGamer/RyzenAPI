-- Lua provided by RyzenAPI
-- Game: Stardom 3

-- MAIN APPLICATION
addappid(1611410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611411, 1, "2dda85ea6b029573e04eec4d8f19ee82711862fb252640c187230e9ab549443f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
