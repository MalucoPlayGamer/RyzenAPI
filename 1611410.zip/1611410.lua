-- Lua provided by SkyAPI 
-- Game: Stardom 3
addappid(1611410)
addappid(1611411, 1, "2dda85ea6b029573e04eec4d8f19ee82711862fb252640c187230e9ab549443f")
