-- Lua provided by RyzenAPI
-- Game: Game: Dawn of H'btakh

-- MAIN APPLICATION
addappid(661730)
-- Game: addappid(661730)

-- MAIN APP DEPOTS / PACKAGES
addappid(661731, 1, "a28e4239bad62ac3830d74cc53715d3bd4250b427af4c9116fe6014a92354a79")
