-- Lua provided by RyzenAPI
-- Game: Dawn of H'btakh

-- MAIN APPLICATION
addappid(661730)

-- MAIN APP DEPOTS / PACKAGES
addappid(661731, 1, "a28e4239bad62ac3830d74cc53715d3bd4250b427af4c9116fe6014a92354a79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
