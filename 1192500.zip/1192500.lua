-- Lua provided by RyzenAPI 
-- Game: GraFi Christmas
addappid(1192500)
addappid(1192501, 1, "6a1f7f27f492284fe2ee08b604a9d473ad06e367eb8296ec63381b9a3ee4869e")
