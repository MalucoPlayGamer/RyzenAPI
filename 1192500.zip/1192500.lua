-- Lua provided by RyzenAPI
-- Game: addappid(1192500)

-- MAIN APPLICATION
addappid(1192500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192501, 1, "6a1f7f27f492284fe2ee08b604a9d473ad06e367eb8296ec63381b9a3ee4869e")
