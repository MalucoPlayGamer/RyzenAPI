-- Lua provided by RyzenAPI
-- Game: 3016760

-- MAIN APPLICATION
addappid(3016760)
-- Game: addappid(3016760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016761, 1, "55801fbeaf784e8ee04652c3cc98666100143afcd23b68d4160b5a57899d8ffd")
