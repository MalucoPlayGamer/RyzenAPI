-- Lua provided by RyzenAPI
-- Game: Gamma Zero

-- MAIN APPLICATION
addappid(3316750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316751, 1, "5f7b687948396b12a3e0c10b4c0776f1af35e2c49b5d2bf779720bbd6314cb07")
