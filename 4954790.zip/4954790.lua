-- 4954790's Lua and Manifest Created by Hubcap Manifest
-- Cold Bloom
-- Created: August 14, 2026 at 11:15:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4954790) -- Cold Bloom
-- MAIN APP DEPOTS
addappid(4954791, 1, "24582ddbdaae4d8df67ba245d552d21641e30db8c7f9a051975f727690f7c495") -- Depot 4954791
setManifestid(4954791, "3679580934865137988", 4544839981)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)