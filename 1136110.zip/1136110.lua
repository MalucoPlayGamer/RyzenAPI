-- Lua provided by SkyAPI 
-- Game: Hidden Objects - The Mystery House
addappid(1136110)
addappid(1136111, 1, "6620590fed6cc7a10be8d1e5869eeb41f27a0cd6dd3f6c45e7cd8781d1b705db")
