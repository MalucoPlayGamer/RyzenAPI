-- Lua provided by RyzenAPI
-- Game: Hidden Objects - The Mystery House

-- MAIN APPLICATION
addappid(1136110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136111, 1, "6620590fed6cc7a10be8d1e5869eeb41f27a0cd6dd3f6c45e7cd8781d1b705db")
