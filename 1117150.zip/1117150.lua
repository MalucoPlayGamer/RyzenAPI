-- Lua provided by RyzenAPI
-- Game: GarbageClassification

-- MAIN APPLICATION
addappid(1117150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117151, 1, "d38e28d13468379de9414a914fda01902fa76036d2216122621c47778c36a4df")
