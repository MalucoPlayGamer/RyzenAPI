-- Lua provided by RyzenAPI
-- Game: Game: FreshWomen - Season 1

-- MAIN APPLICATION
addappid(1350650)
-- Game: addappid(1350650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350651, 1, "cf1b50f8d8ab2dbf3f7cda0c9962aaf6ecaf1dfa64dd60809e3b3c2dcf94ac31")
