-- Lua provided by RyzenAPI
-- Game: Firework Demo

-- MAIN APPLICATION
addappid(1307570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307571, 1, "605d84ced6382191aaa4809161ee52faf8d8e158a62d0408e6a3c92d6e4cd99b")
addappid(1307572, 1, "5b85b7f3a7d8b824d04c0ca66197db35b0889883ea9e119cd1dbb5eefb4f9fde")
