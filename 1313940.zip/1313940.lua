-- Lua provided by RyzenAPI
-- Game: 1313940

-- MAIN APPLICATION
addappid(1313940)
-- Game: addappid(1313940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313941, 1, "f50b6fe2e931b4426f31686d8fa903907fe63734b51ddf4c7f8dea84d3b4083a")
