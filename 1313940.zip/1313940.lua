-- Lua provided by RyzenAPI
-- Game: My Holiday 2

-- MAIN APPLICATION
addappid(1313940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1313941, 1, "f50b6fe2e931b4426f31686d8fa903907fe63734b51ddf4c7f8dea84d3b4083a")

