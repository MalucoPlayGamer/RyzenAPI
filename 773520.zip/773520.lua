-- Lua provided by RyzenAPI
-- Game: Refight:Burning Engine

-- MAIN APPLICATION
addappid(773520)

-- MAIN APP DEPOTS / PACKAGES
addappid(773521, 1, "8a1a5b80643504f34bebc7c8c55cbff1a4435ea9862def5e1f51b436578841f7")

