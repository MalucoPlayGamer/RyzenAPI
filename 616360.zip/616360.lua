-- Lua provided by RyzenAPI
-- Game: AppID 616360

-- MAIN APPLICATION
addappid(616360)
-- Game: addappid(616360)

-- MAIN APP DEPOTS / PACKAGES
addappid(616361, 1, "044f574db707ba69531379f0aafe253324f47a7aa22b41fcec1b573807600896")
