-- Lua provided by RyzenAPI
-- Game: Game: AppID 2967250

-- MAIN APPLICATION
addappid(2967250)
-- Game: addappid(2967250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967251, 1, "a5317c114b6518f9b55de1abdef337503b2869ab25e665e55c1a187c55ff01d7")
