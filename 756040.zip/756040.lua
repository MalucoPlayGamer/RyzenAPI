-- Lua provided by RyzenAPI
-- Game: RollerCoaster Legends

-- MAIN APPLICATION
addappid(756040)

-- MAIN APP DEPOTS / PACKAGES
addappid(756041,0,"08150fdfdedb356d3da4c28a0bda38cd469408160a98090a1841c514ff7c74c6")

