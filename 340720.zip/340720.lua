-- Lua provided by RyzenAPI 
-- Game: The Tiny Tale 2
addappid(340720)
addappid(340721, 1, "90d5004c2f7a78968341bc4d8db97c2307e3354e18c021bad642f93aa11a5d7e")
