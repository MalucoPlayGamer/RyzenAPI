-- Lua provided by RyzenAPI
-- Game: Game: The Tiny Tale 2

-- MAIN APPLICATION
addappid(340720)
-- Game: addappid(340720)

-- MAIN APP DEPOTS / PACKAGES
addappid(340721, 1, "90d5004c2f7a78968341bc4d8db97c2307e3354e18c021bad642f93aa11a5d7e")
