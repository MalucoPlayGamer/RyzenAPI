-- Lua provided by SkyAPI 
-- Game: AppID 818950
addappid(818950)
addappid(818951, 1, "1e8e5f2bb7130a2b5df11dd911c0ca693d0777512bb21295f57f2f07a9f1c426")
