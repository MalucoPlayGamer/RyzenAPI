-- Lua provided by RyzenAPI
-- Game: 818950

-- MAIN APPLICATION
addappid(818950)
-- Game: addappid(818950)

-- MAIN APP DEPOTS / PACKAGES
addappid(818951, 1, "1e8e5f2bb7130a2b5df11dd911c0ca693d0777512bb21295f57f2f07a9f1c426")
