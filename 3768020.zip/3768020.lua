-- Lua provided by RyzenAPI
-- Game: Game: Doomvile Brainrot

-- MAIN APPLICATION
addappid(3768020)
-- Game: addappid(3768020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768021, 1, "b937f70c5b4d3d43f1fb5f621b24167d344c7d5f41b14679d47042ea82466719")
