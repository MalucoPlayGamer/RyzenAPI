-- Lua provided by RyzenAPI
-- Game: Game: EzBench Benchmark

-- MAIN APPLICATION
addappid(770170)
-- Game: addappid(770170)

-- MAIN APP DEPOTS / PACKAGES
addappid(770171, 1, "ded26c00ef942b519fe87f0502c977897b1f8481167cede2a7e3cc2f1212a763")
