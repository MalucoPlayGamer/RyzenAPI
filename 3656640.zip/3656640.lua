-- 3656640's Lua and Manifest Created by Hubcap Manifest
-- Gun Shop Manager
-- Created: August 20, 2026 at 14:22:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3656640) -- Gun Shop Manager
-- MAIN APP DEPOTS
addappid(3656641, 1, "b4aaa56818232d10ca53764fc7560431adad397c0d039894473cf82fcf4d53c3") -- Depot 3656641
setManifestid(3656641, "4131524579211625005", 4955809073)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)