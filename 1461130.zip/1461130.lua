-- Lua provided by RyzenAPI 
-- Game: LAVALAMP
addappid(1461130)
addappid(1461131, 1, "733479bb214c23d94baae7829892879101ba9737df50c672fe1fd2daaab96ad6")
addappid(1461132, 1, "fe20ac2587b77563460b6011651d9250af44356b8460d616f4b0de906d4e4589")
