-- Lua provided by RyzenAPI
-- Game: LAVALAMP

-- MAIN APPLICATION
addappid(1461130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461131, 1, "733479bb214c23d94baae7829892879101ba9737df50c672fe1fd2daaab96ad6")
addappid(1461132, 1, "fe20ac2587b77563460b6011651d9250af44356b8460d616f4b0de906d4e4589")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
