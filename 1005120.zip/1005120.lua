-- Lua provided by RyzenAPI
-- Game: Touhou Genso Wanderer -Lotus Labyrinth R-

-- MAIN APPLICATION
addappid(1005120)
addappid(1072063)
addappid(1633540)
addappid(1633570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1005121, 1, "1982936b6bf44f5c8f74295c5387f12509cc5a30464f9674e6006e35cc0c519a")
