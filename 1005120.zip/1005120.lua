-- Lua provided by RyzenAPI
-- Game: Touhou Genso Wanderer -Lotus Labyrinth R-

-- MAIN APPLICATION
addappid(1005120)
-- Game: addappid(1005120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005121, 1, "1982936b6bf44f5c8f74295c5387f12509cc5a30464f9674e6006e35cc0c519a")
