-- Lua provided by RyzenAPI
-- Game: 1232670

-- MAIN APPLICATION
addappid(1232670)
-- Game: addappid(1232670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232671, 1, "e45394ffbc7d17d24e42c9613800ec67c32eaafdf10e1ed3a969f5d9c4d28173")
