-- Lua provided by RyzenAPI
-- Game: addappid(228400)

-- MAIN APPLICATION
addappid(228400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228401, 1, "89ab00dec01ed2e290274bedeaa8ea1cbcc92e1279d83e70a589aa734e90acfe")
