-- Lua provided by SkyAPI 
-- Game: AppID 228400
addappid(228400)
addappid(228401, 1, "89ab00dec01ed2e290274bedeaa8ea1cbcc92e1279d83e70a589aa734e90acfe")
