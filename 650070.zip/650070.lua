-- Lua provided by RyzenAPI
-- Game: AppID 650070

-- MAIN APPLICATION
addappid(650070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(650071, 1, "7ffe39f0cfad05067f8e21e9c001fc21602b5be1e502070ad659098ef7565eed")

