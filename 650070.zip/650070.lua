-- Lua provided by RyzenAPI
-- Game: AppID 650070

-- MAIN APPLICATION
addappid(650070)
-- Game: addappid(650070)

-- MAIN APP DEPOTS / PACKAGES
addappid(650071, 1, "7ffe39f0cfad05067f8e21e9c001fc21602b5be1e502070ad659098ef7565eed")
