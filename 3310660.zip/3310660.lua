-- Lua provided by RyzenAPI
-- Game: 3310660

-- MAIN APPLICATION
addappid(3310660)
-- Game: addappid(3310660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310661, 1, "a8cae4d9606c7fe360f6e911d7bdb913a9463e1c28e1a6cd08c777985db3bdcd")
