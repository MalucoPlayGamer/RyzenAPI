-- Lua provided by RyzenAPI
-- Game: Tractorball

-- MAIN APPLICATION
addappid(683790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(683791, 1, "99d0bc6d39c2daf0f12808e006af820fd1d0a5cca218b89d0e86713545b17961")

