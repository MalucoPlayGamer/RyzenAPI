-- Lua provided by RyzenAPI
-- Game: Tractorball

-- MAIN APPLICATION
addappid(683790)

-- MAIN APP DEPOTS / PACKAGES
addappid(683791, 1, "99d0bc6d39c2daf0f12808e006af820fd1d0a5cca218b89d0e86713545b17961")
