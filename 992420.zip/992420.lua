-- Lua provided by RyzenAPI
-- Game: Cotropitorii

-- MAIN APPLICATION
addappid(992420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(992421, 1, "5688414631ba50d006133aac3180e27bc7535fd7b20dad4dbb215d1dad1e238a")

