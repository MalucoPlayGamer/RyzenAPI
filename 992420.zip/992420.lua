-- Lua provided by RyzenAPI 
-- Game: AppID 992420
addappid(992420)
addappid(992421, 1, "5688414631ba50d006133aac3180e27bc7535fd7b20dad4dbb215d1dad1e238a")
