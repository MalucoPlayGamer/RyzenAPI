-- Lua provided by RyzenAPI
-- Game: addappid(2496460)

-- MAIN APPLICATION
addappid(2496460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496461, 1, "b5d2f7ca546df7d73670b7256a2f6fb2016133bcfe0971df1135990bc129b7a5")
