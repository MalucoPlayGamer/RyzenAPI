-- Lua provided by RyzenAPI 
-- Game: AppID 485440
addappid(485440)
addappid(485441, 1, "c5b0a2ce24c3a2ee1837be7c6b0df8561311d09b69c7bae2e2f48d3b8c3ae507")
addappid(485442, 1, "44035b89c990c15d6c415e4a8fc3049a88587eb8f3ba97be1221e8cadf840f71")
