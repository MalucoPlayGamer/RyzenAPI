-- Lua provided by RyzenAPI
-- Game: addappid(779640)

-- MAIN APPLICATION
addappid(779640)

-- MAIN APP DEPOTS / PACKAGES
addappid(779641, 1, "cca1c3872052b6ee1325f36f5c2bd5ee72218c30382c5c020e6d7cf8bd9cc8bd")
addappid(1203830, 0, "87e2facd3a7949a95a60aa84159f19c87255642f2af6b6e44dbc7c37de5da37d")
