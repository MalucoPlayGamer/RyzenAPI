-- Lua provided by SkyAPI 
-- Game: AppID 2893260
addappid(2893260)
addappid(2893261, 1, "305319ae6ba3f1cf25e4ac55f706bdd8e5f63cc579c33b36ac451d2103262836")
