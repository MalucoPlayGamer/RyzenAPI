-- Lua provided by RyzenAPI
-- Game: Game: AppID 2893260

-- MAIN APPLICATION
addappid(2893260)
-- Game: addappid(2893260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893261, 1, "305319ae6ba3f1cf25e4ac55f706bdd8e5f63cc579c33b36ac451d2103262836")
