-- Lua provided by RyzenAPI
-- Game: Maliki : Poison Of The Past

-- MAIN APPLICATION
addappid(2893260)
addappid(3447880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893261, 1, "305319ae6ba3f1cf25e4ac55f706bdd8e5f63cc579c33b36ac451d2103262836")

