-- Lua provided by RyzenAPI
-- Game: AppID 2893260

-- MAIN APPLICATION
addappid(2893260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893261, 1, "305319ae6ba3f1cf25e4ac55f706bdd8e5f63cc579c33b36ac451d2103262836")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3447880)
