-- Lua provided by RyzenAPI
-- Game: addappid(1206330)

-- MAIN APPLICATION
addappid(1206330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206331, 1, "7420c8706e64e6f7ff67033f44216ed49c3e07ebdccab4d7cd44e7014affcfdb")
addappid(1206332, 1, "d384eff8368c5ef42bd85684145070160aee8ddfd99c68d2b7e7308f4470e9de")
