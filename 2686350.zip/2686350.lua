-- Lua provided by RyzenAPI
-- Game: Home Defender

-- MAIN APPLICATION
addappid(2686350)
-- Game: addappid(2686350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686351, 1, "823e79cdbedf3d30d10707b7e055640b151a50667581d6288034495da767a562")
