-- Lua provided by RyzenAPI 
-- Game: Hero of war
addappid(2017630)
addappid(2017631, 1, "d65cf44d3e46e2f7b006be9faf2877b7482432833dc9c50b17aa3d18e01b3813")
