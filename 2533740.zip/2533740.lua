-- Lua provided by RyzenAPI
-- Game: 2533740

-- MAIN APPLICATION
addappid(2533740)
-- Game: addappid(2533740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533741, 1, "c92684ba99000ceec557ab91d7c133db48d5ffc620e12b40a2637cc0e3375816")
