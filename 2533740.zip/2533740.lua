-- Lua provided by RyzenAPI
-- Game: The Book Of Hiro - Prologue

-- MAIN APPLICATION
addappid(2533740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2533741, 1, "c92684ba99000ceec557ab91d7c133db48d5ffc620e12b40a2637cc0e3375816")

