-- Lua provided by RyzenAPI
-- Game: Game: Elly's Cake Cafe

-- MAIN APPLICATION
addappid(1329450)
-- Game: addappid(1329450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329451, 1, "5c2a1e4a5059620727154344645ec6da31da6f3402007d1169e7abc5d40b8874")
addappid(1329452, 1, "81a3bc7fccbc37a2e59223c3506404a7b4bb325bb8af559eaed95237ef97e1cf")
addappid(1329453, 1, "4122ca913cb20492aa49b4583e8fdb66d57c03a068b170b06dddfab4a82e9656")
addappid(1329454, 1, "efeaf6a852a972e4966eb512f8551c2b739b30689f2b83b7f4f7a859b35de933")
