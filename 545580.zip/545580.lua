-- Lua provided by RyzenAPI
-- Game: AppID 545580

-- MAIN APPLICATION
addappid(545580)
-- Game: addappid(545580)

-- MAIN APP DEPOTS / PACKAGES
addappid(545581, 1, "ee1f5d075189208d20a8f11f97590b7f20595d1c73c1fbfe66dd54a2d98f3399")
