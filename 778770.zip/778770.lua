-- Lua provided by RyzenAPI 
-- Game: Ladybird Reflect
addappid(778770)
addappid(778771, 1, "75f5f0eddd4e38bb13297cc1c20a35518aaf9fc7cca225cac8f3bc1df4fe65ea")
addappid(778772, 1, "f81becaadfc32d2767c0ba8c1bf9f2b4547e28280f9526bf09a3dee11e8bb25d")
addappid(786160)
