-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Omnia Promotional Soundtrack

-- MAIN APPLICATION
addappid(1881410)
-- Game: addappid(1881410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881411, 1, "4db260c6e13150579499543a55e6b188f39ee592a78a12075bb73b371bd6edb1")
addappid(1881412, 1, "eb3edc858ae375a3a28f473da4161013a57f30de81030f97c42a89a3913f7d1e")
