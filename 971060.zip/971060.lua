-- Lua provided by RyzenAPI
-- Game: Mystery Case Files: The Countess Collector's Edition

-- MAIN APPLICATION
addappid(971060)

-- MAIN APP DEPOTS / PACKAGES
addappid(971061, 1, "e6029dd469cd630f8985b67765d29c3ffe26cdc58eb7a90d9a444e104c8d5030")
