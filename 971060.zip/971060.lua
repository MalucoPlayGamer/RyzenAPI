-- Lua provided by SkyAPI 
-- Game: Mystery Case Files: The Countess Collector's Edition
addappid(971060)
addappid(971061, 1, "e6029dd469cd630f8985b67765d29c3ffe26cdc58eb7a90d9a444e104c8d5030")
