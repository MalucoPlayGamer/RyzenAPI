-- Lua provided by SkyAPI 
-- Game: SAND LAND
addappid(1979440)
addappid(1979441, 1, "9cbc1d5d4de2f5e3ed482e899ba33c76f95a56a83c0b50132dcd85e721ba5371")
