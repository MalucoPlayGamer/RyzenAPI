-- Lua provided by RyzenAPI
-- Game: SAND LAND

-- MAIN APPLICATION
addappid(1979440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979441, 1, "9cbc1d5d4de2f5e3ed482e899ba33c76f95a56a83c0b50132dcd85e721ba5371")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2602590)
addappid(2602600)
addappid(2602610)
addappid(2602620)
addappid(2602630)
addappid(2602640)
addappid(2602650)
addappid(2602660)
addappid(2602670)
addappid(2624420)
addappid(2624430)
addappid(2680150)
