-- Lua provided by RyzenAPI
-- Game: 1979440

-- MAIN APPLICATION
addappid(1979440)
-- Game: addappid(1979440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979441, 1, "9cbc1d5d4de2f5e3ed482e899ba33c76f95a56a83c0b50132dcd85e721ba5371")
