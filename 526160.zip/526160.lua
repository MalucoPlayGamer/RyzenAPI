-- Lua provided by RyzenAPI
-- Game: The Wild Eight

-- MAIN APPLICATION
addappid(526160)
addappid(590360)
addappid(590361)

-- MAIN APP DEPOTS / PACKAGES
addappid(526161, 1, "955f55e346fe37ebfe4aa26a14cb4c71a4d8a1456956450c8dbb444e2b49bb05")
addappid(526162, 1, "13f8c0df83d65ee75853bdc37b743978bef1245c9f09ac67f770541c33809e3c")
addappid(526163, 1, "e7b7d56ac2a2042849d8b7c63f150da7f144f857ee0c43b6134f2ebce68c25f7")

