-- Lua provided by RyzenAPI
-- Game: Game: Quest room

-- MAIN APPLICATION
addappid(1965060)
-- Game: addappid(1965060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965061, 1, "50f0804a5b916ed944bf1729b0c011c04c196075de793c9871b9269d74910632")
