-- Lua provided by RyzenAPI
-- Game: Quest room

-- MAIN APPLICATION
addappid(1965060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965061, 1, "50f0804a5b916ed944bf1729b0c011c04c196075de793c9871b9269d74910632")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
