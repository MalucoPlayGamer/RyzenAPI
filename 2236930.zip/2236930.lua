-- Lua provided by RyzenAPI
-- Game: VMVA - Virtual Museum for Virtual Art

-- MAIN APPLICATION
addappid(2236930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236931, 1, "3114da5ff4f137e68f7da160183add012e2ed5872f4094d309d9896cadcbdf52")

