-- Lua provided by RyzenAPI
-- Game: VMVA - Virtual Museum for Virtual Art

-- MAIN APPLICATION
addappid(2236930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2236931, 1, "3114da5ff4f137e68f7da160183add012e2ed5872f4094d309d9896cadcbdf52")

