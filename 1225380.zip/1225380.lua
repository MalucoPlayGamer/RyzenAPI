-- Lua provided by RyzenAPI
-- Game: Into the Infinite

-- MAIN APPLICATION
addappid(1225380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225381, 1, "73bd02f3ad09b6511cd9c6bd2e5a22e15c0d05635529ae99ba53b9a8247ce355")
addappid(1225382, 1, "0de8382f8618508a78a531541b97de902df7b6ea15edf1f23fd8f18a2f0d40f1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
