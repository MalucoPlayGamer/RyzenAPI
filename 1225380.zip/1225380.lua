-- Lua provided by RyzenAPI
-- Game: Into the Infinite

-- MAIN APPLICATION
addappid(1225380)
-- Game: addappid(1225380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225381, 1, "73bd02f3ad09b6511cd9c6bd2e5a22e15c0d05635529ae99ba53b9a8247ce355")
addappid(1225382, 1, "0de8382f8618508a78a531541b97de902df7b6ea15edf1f23fd8f18a2f0d40f1")
