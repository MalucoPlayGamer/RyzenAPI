-- Lua provided by RyzenAPI
-- Game: Odd Realm

-- MAIN APPLICATION
addappid(688060)

-- MAIN APP DEPOTS / PACKAGES
addappid(688061, 1, "17113a3ff27562d68ceec2376e075ef106ff7e1227eb87560f6156b9fa493aaa")
