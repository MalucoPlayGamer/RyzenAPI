-- Lua provided by RyzenAPI
-- Game: FURRY CYBERSEX

-- MAIN APPLICATION
addappid(2012620)
-- Game: addappid(2012620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012621, 1, "dc24016b37c05f1bbd48f0bd914c86fec41db1b4eac7ae460063801f7bb7c706")
