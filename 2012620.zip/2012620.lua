-- Lua provided by SkyAPI 
-- Game: FURRY CYBERSEX
addappid(2012620)
addappid(2012621, 1, "dc24016b37c05f1bbd48f0bd914c86fec41db1b4eac7ae460063801f7bb7c706")
