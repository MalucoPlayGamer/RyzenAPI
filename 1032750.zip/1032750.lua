-- Lua provided by RyzenAPI
-- Game: Zombie Shooter: Ares Virus

-- MAIN APPLICATION
addappid(1032750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032751, 1, "443deba25887ed7120c239d03644d59b47ea981fdd633d8be0f6c49b57ee6cb8")

