-- Lua provided by RyzenAPI
-- Game: Game: SPRAWL

-- MAIN APPLICATION
addappid(1549690)
-- Game: addappid(1549690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549691, 1, "1f26aef122b6e737e69b5af0e0719f9fa59beff95ff325957c849517e4ef3978")
