-- Lua provided by RyzenAPI
-- Game: addappid(615050)

-- MAIN APPLICATION
addappid(615050)

-- MAIN APP DEPOTS / PACKAGES
addappid(615051, 1, "858b8820d8637ea98f48b60ffe63db504ebefd1740a8af85ac95e7bd833c7681")
addappid(615052, 1, "3849d2e69b09dd692f62d7db85fb45fda25845a77ddd731e371bb77a6ee63e4a")
