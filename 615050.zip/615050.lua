-- Lua provided by RyzenAPI
-- Game: Burst The Game

-- MAIN APPLICATION
addappid(615050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(615051, 1, "858b8820d8637ea98f48b60ffe63db504ebefd1740a8af85ac95e7bd833c7681")
addappid(615052, 1, "3849d2e69b09dd692f62d7db85fb45fda25845a77ddd731e371bb77a6ee63e4a")

