-- 2778220's Lua and Manifest Created by Hubcap Manifest
-- Palm Sugar: A Village Story
-- Created: August 12, 2026 at 22:54:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2778220) -- Palm Sugar: A Village Story
-- MAIN APP DEPOTS
addappid(2778222, 1, "36923b3bed4214990be9ff49bb40093a00a47dd2fea36da5e5df5d26736a7adb") -- Depot 2778222
setManifestid(2778222, "3298990667950489618", 240547701)
addappid(2778223, 1, "8cedac37871851a881947ae3f021eb6a62fd90c856d904b9e76414e8718b6e7f") -- Depot 2778223
setManifestid(2778223, "2836510727034551535", 801523818)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2778221) -- Depot 2778221 (empty depot)