-- Lua provided by RyzenAPI
-- Game: Palm Sugar: A Village Story

-- MAIN APPLICATION
addappid(2778220) -- Palm Sugar: A Village Story
-- addappid(2778221) -- Depot 2778221 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778222, 1, "36923b3bed4214990be9ff49bb40093a00a47dd2fea36da5e5df5d26736a7adb") -- Depot 2778222
addappid(2778223, 1, "8cedac37871851a881947ae3f021eb6a62fd90c856d904b9e76414e8718b6e7f") -- Depot 2778223

