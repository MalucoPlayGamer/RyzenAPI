-- Lua provided by RyzenAPI
-- Game: AppID 718910

-- MAIN APPLICATION
addappid(718910)

-- MAIN APP DEPOTS / PACKAGES
addappid(718911, 1, "ebce141eec69211d3eccafc2200af4ccdfb7a6e73e69c2d82fef3700bce9d236")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
