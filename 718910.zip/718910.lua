-- Lua provided by RyzenAPI
-- Game: AppID 718910

-- MAIN APPLICATION
addappid(718910)
-- Game: addappid(718910)

-- MAIN APP DEPOTS / PACKAGES
addappid(718911, 1, "ebce141eec69211d3eccafc2200af4ccdfb7a6e73e69c2d82fef3700bce9d236")
