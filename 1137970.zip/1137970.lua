-- Lua provided by RyzenAPI
-- Game: Zombies Ate My Neighbors and Ghoul Patrol

-- MAIN APPLICATION
addappid(1137970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137971, 1, "b9dc5770d2ee95ed1dd7b2460bcca4c3a8354268bca841968eeedf2b1776771a")
