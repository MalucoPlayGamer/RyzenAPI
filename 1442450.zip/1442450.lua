-- Lua provided by RyzenAPI
-- Game: Monsters Domain

-- MAIN APPLICATION
addappid(1442450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442451, 1, "47431010ef474878728cf1523a01990ed66ccacdffd038a213438d73dd44b97d")

