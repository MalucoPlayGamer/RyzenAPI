-- Lua provided by RyzenAPI
-- Game: 660180

-- MAIN APPLICATION
addappid(660180)
-- Game: addappid(660180)

-- MAIN APP DEPOTS / PACKAGES
addappid(660181, 1, "1f94d10eddb2ee016a0d1e505b2a4a64a73de16cce6d4dd629b9ab7f4cc972f9")
