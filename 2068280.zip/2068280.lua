-- Lua provided by RyzenAPI
-- Game: Nordic Ashes

-- MAIN APPLICATION
addappid(2952100)
addappid(3312220)
addappid(3636780)
addappid(4501990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068280, 1, "88bfba35f5dd0f0680c5db767218aeaa00cd91e6621151e04758d25c1fa4240d") -- Nordic Ashes
addappid(2068281, 1, "ee7ffd7c9029c2c860eab9bb927eba2a68583d2327418c1fa50e13a0aa0e3534") -- Depot 2068281
addappid(2068282, 1, "01210614ee8eafe7be521b727beab3aefa41b46c6a42ba8299ee4478f6c890df") -- Depot 2068282
addappid(2068283, 1, "df31c8266051f43e78990b5d97bd3b9eb293126391b671e1b14a051d460bf91b") -- Depot 2068283
addappid(2952100, 1, "288f3607fd60a1291dc7c8ac494a41f2f85aa8c9ca7cffc02e25fcbe4489ecf5") -- Nordic Ashes Digital Artbook - Depot 2952100
addappid(3312220, 1, "bab077fa19c68ee5c41735feff8f93076ae2d6c43631a8394311c453d1c7644a") -- Nordic Ashes Dark Knights - Depot 3312220
addappid(3312221, 1, "aa939f25a524b5953c06c2efdf929ea8dff8946b60f531a949f1ff71d317b30c") -- Nordic Ashes Dark Knights - Depot 3312221
addappid(3312222, 1, "978fabfc5fcaa61865a4c1fba48f7363495110c31bc7001f14f4ed3a7b5c6a52") -- Nordic Ashes Dark Knights - Depot 3312222
addappid(3636780, 1, "cb00c6cd0e5c55518a12fac8bf4339a6ad9580427e363e3f54cd97403ebbd75a") -- Nordic Ashes Remnants of Corruption - Depot 3636780
addappid(3636781, 1, "416b71bca45f18ceef8184700f4aac288dd17baff8cd4848f82702cbdd646141") -- Nordic Ashes Remnants of Corruption - Depot 3636781
addappid(3636782, 1, "3301678f8868a72b848f3280ab9b29e85446b780b03c47971d7004e81e8c69f5") -- Nordic Ashes Remnants of Corruption - Depot 3636782
addappid(4501990, 1, "444f67e695996bc61357eeca787e1d206bd39160cef5c6066fae3b5a4561548e") -- Nordic Ashes Twilight of Yggdrasil - Depot 4501990

