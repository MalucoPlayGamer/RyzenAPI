-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Classic

-- MAIN APPLICATION
addappid(329490)

-- MAIN APP DEPOTS / PACKAGES
addappid(329491, 1, "11d54b96a1d42fc4a08763b31394e7a0026632503f2b39687a7d646c8f3b6d1d")
addappid(348940, 0, "0914ebc17a2730513fb64d6927ddb0e60d17ea2e86bfd20ac2c31b601d093556")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(333110)
addappid(372110)
addappid(372112)
addappid(381760)
