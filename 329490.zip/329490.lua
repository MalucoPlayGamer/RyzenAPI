-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Classic

-- MAIN APPLICATION
addappid(329490)

-- MAIN APP DEPOTS / PACKAGES
addappid(329491, 1, "11d54b96a1d42fc4a08763b31394e7a0026632503f2b39687a7d646c8f3b6d1d")
addappid(348940, 0, "0914ebc17a2730513fb64d6927ddb0e60d17ea2e86bfd20ac2c31b601d093556")
