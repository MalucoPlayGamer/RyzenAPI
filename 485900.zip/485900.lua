-- Lua provided by RyzenAPI
-- Game: 485900

-- MAIN APPLICATION
addappid(485900)
-- Game: addappid(485900)

-- MAIN APP DEPOTS / PACKAGES
addappid(485901, 1, "57805adef65ea3f101343f15d4abac4ea3bc20d58992df075bd8d42700d55eab")
