-- Lua provided by RyzenAPI
-- Game: VR Ping Pong Pro

-- MAIN APPLICATION
addappid(1029730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029731, 1, "5ad38136b6952e8b3894f097f700d3b1c1757cf3f57e384d220dffe207ca8a73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
