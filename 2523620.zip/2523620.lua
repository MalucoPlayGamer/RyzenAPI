-- Lua provided by RyzenAPI
-- Game: 2523620

-- MAIN APPLICATION
addappid(2523620)
-- Game: addappid(2523620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523621, 1, "74acabc54820d1d1b070c7d1085bdfa1eaa76e24ac4ab77d22f47ac40e79bc55")
