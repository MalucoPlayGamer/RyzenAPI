-- Lua provided by RyzenAPI 
-- Game: AppID 850320
addappid(850320)
addappid(850321, 1, "6c055af9a7fa1cf2eac96a37eb6bd46e995ea2d409dd21f771c9694064705ed0")
