-- Lua provided by RyzenAPI
-- Game: Game: AppID 850320

-- MAIN APPLICATION
addappid(850320)
-- Game: addappid(850320)

-- MAIN APP DEPOTS / PACKAGES
addappid(850321, 1, "6c055af9a7fa1cf2eac96a37eb6bd46e995ea2d409dd21f771c9694064705ed0")
