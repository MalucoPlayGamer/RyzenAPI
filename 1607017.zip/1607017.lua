-- Lua provided by RyzenAPI
-- Game: addappid(1607017)

-- MAIN APPLICATION
addappid(1607017)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607017,0,"11710792035c5bfe1397dcdf892f8ca8d16b72cac8b92580d4c178e5192febe7")
