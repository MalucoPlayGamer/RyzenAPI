-- Lua provided by RyzenAPI
-- Game: 991065

-- MAIN APPLICATION
addappid(991065)
-- Game: addappid(991065)

-- MAIN APP DEPOTS / PACKAGES
addappid(991065,0,"98936d9901346489734fdf4ae8f29d558a0a067e3d33232f6f759fe9dcda5506")
