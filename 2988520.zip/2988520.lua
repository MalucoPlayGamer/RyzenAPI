-- Lua provided by RyzenAPI
-- Game: The Hell in I

-- MAIN APPLICATION
addappid(2988520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2988521, 1, "4018147a9c8991942a6af05926ee6065118b35a33620ff27e1043c396a134d80")

