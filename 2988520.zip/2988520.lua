-- Lua provided by RyzenAPI
-- Game: The Hell in I

-- MAIN APPLICATION
addappid(2988520)
-- Game: addappid(2988520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988521, 1, "4018147a9c8991942a6af05926ee6065118b35a33620ff27e1043c396a134d80")
