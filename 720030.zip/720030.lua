-- Lua provided by RyzenAPI
-- Game: AppID 720030

-- MAIN APPLICATION
addappid(720030)
-- Game: addappid(720030)

-- MAIN APP DEPOTS / PACKAGES
addappid(720031, 1, "b10a6e9d7964772cdea046bfa9eba8154dd12fc3de6f9287eb2f0a7135ae67e7")
addappid(720032, 1, "8d3597821866194af1883e59dd65c00fd6bf4c7a86a983381db1fe79b74c5a58")
