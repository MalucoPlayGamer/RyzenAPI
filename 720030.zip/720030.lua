-- Lua provided by RyzenAPI
-- Game: AppID 720030

-- MAIN APPLICATION
addappid(720030)

-- MAIN APP DEPOTS / PACKAGES
addappid(720031, 1, "b10a6e9d7964772cdea046bfa9eba8154dd12fc3de6f9287eb2f0a7135ae67e7")
addappid(720032, 1, "8d3597821866194af1883e59dd65c00fd6bf4c7a86a983381db1fe79b74c5a58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
