-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2486070)
-- Game: addappid(2486070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486072,0,"825578b7e4d30771c2c6f96f37419c1cdc8089116e9d95ce67bf924104a0a9e6")
