-- Lua provided by RyzenAPI
-- Game: 340830

-- MAIN APPLICATION
addappid(340830)
-- Game: addappid(340830)

-- MAIN APP DEPOTS / PACKAGES
addappid(340831, 1, "88a97bb93584686965a918f07eb27a0c3e1e0962d489c2e5c065e9f4d13ed390")
addappid(340832, 1, "beaba487690ae3ccc186c4d75be59ad734ee733b039cd56aa802fced3e629102")
