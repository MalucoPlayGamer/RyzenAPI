-- Lua provided by RyzenAPI 
-- Game: AppID 1154670
addappid(1154670)
addappid(1154671, 1, "e9caf8246e4442adce79816c51bf1c6ac73c2d3eefc922400e5dec0a482f189f")
