-- Lua provided by RyzenAPI
-- Game: addappid(1621342)

-- MAIN APPLICATION
addappid(1621342)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621342,0,"2b581979174912bbbdc81a63badc4b3aa46ec856a8bab5cafba6b7d267b4380c")
