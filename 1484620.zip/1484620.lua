-- Lua provided by RyzenAPI
-- Game: Game: Arcade Spirits: The New Challengers

-- MAIN APPLICATION
addappid(1484620)
-- Game: addappid(1484620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484621, 1, "4ca5e252866cf75012d6e8db44638aa2b55e88b8a69745a07df37a42db6629b7")
