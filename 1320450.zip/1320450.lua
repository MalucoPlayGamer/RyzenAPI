-- Lua provided by RyzenAPI
-- Game: Space Simulation Toolkit - DEMO

-- MAIN APPLICATION
addappid(1320450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320454,0,"81c1ca7907c28cc8145c1763a57b4ab5d7ab5437cdbe7608f43bd9a96b780b08")

