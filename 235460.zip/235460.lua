-- Lua provided by SkyAPI 
-- Game: METAL GEAR RISING: REVENGEANCE
addappid(235460)
addappid(235461, 1, "528bc8a310c4fe4defee57487f61d183ced5856c81a68f4b9818b97e7c60b11f")
addappid(235462, 1, "9bd8396f037cbbbc99c00d4acbc1744b2f518b774e4793cbb251a11afdfdca99")
