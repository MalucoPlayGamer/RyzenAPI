-- Lua provided by RyzenAPI
-- Game: AppID 1111250

-- MAIN APPLICATION
addappid(1111250)
-- Game: addappid(1111250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111251, 1, "934efe0150c276fc3ce0414324bd53e2bac04f0edb82472cfa38f985a2bb8f79")
