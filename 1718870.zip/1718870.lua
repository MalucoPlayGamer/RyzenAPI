-- Lua provided by RyzenAPI
-- Game: Spaceflight Simulator

-- MAIN APPLICATION
addappid(1718870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718871, 1, "f16482d24a5c12c5db47dcd5072957a40d57a63f89a7d46dde0360f092d68d16")
addappid(1718874, 1, "a86c65b9f38edda4bf5645431a5c72d9d0a93677f9359379ddf8b8034f28be97")

