-- Lua provided by RyzenAPI
-- Game: Game: AppID 307400

-- MAIN APPLICATION
addappid(307400)
-- Game: addappid(307400)

-- MAIN APP DEPOTS / PACKAGES
addappid(307401, 1, "4e64d04f566074ac6ebda4ca3371ec1a2435efb7b0006ce2e83c928783a9d2e6")
