-- Lua provided by RyzenAPI
-- Game: OCTOPATH TRAVELER II

-- MAIN APPLICATION
addappid(1971650)
-- Game: addappid(1971650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971651, 1, "b27023dd7c9a1894c98a3a8a507f86f2e56bf2f7e611addb95eba15ea538ff5a")
