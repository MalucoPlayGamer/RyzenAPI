-- Lua provided by RyzenAPI
-- Game: Bygone Dreams

-- MAIN APPLICATION
addappid(951620)

-- MAIN APP DEPOTS / PACKAGES
addappid(951622,0,"21215065a0c252b5b7b700d674beb4f8a386aace6c5f3e359834b9d11d448f3b")

