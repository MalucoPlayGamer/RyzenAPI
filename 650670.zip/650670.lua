-- Lua provided by RyzenAPI
-- Game: Grimoire : Heralds of the Winged Exemplar

-- MAIN APPLICATION
addappid(650670)

-- MAIN APP DEPOTS / PACKAGES
addappid(650672,0,"677ba8dc721f47398b46cb134ab365e5f8ca3bbc14c7bcc418b5631cbc3b136d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
