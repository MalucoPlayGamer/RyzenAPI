-- Lua provided by RyzenAPI
-- Game: Game: AppID 1116470

-- MAIN APPLICATION
addappid(1116470)
-- Game: addappid(1116470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116471, 1, "7c8321a66853e959d09f7a11be5e6c6752f2a22b4c86fb8ddbdfcf26aaff181c")
