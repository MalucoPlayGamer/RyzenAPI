-- Lua provided by RyzenAPI
-- Game: Real Girl VR

-- MAIN APPLICATION
addappid(1116470)
addappid(1132390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116471, 1, "7c8321a66853e959d09f7a11be5e6c6752f2a22b4c86fb8ddbdfcf26aaff181c")
