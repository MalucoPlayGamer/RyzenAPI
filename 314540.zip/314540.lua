-- Lua provided by RyzenAPI
-- Game: Paper Monsters Recut

-- MAIN APPLICATION
addappid(314540)
-- Game: addappid(314540)

-- MAIN APP DEPOTS / PACKAGES
addappid(314541, 1, "c7ab1cdb6240476daf6d2179fdc179bfc5e1cf8aed4d65dcb4520ee3f54a5f29")
