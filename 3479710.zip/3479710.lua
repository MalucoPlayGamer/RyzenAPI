-- Lua provided by SkyAPI 
-- Game: AppID 3479710
addappid(3479710)
addappid(3479711, 1, "7720a1ced443a67a6a65ba0832f4430ed5648e2d0a81a030fbddd2a35e3dd09d")
