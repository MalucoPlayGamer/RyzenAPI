-- Lua provided by RyzenAPI
-- Game: addappid(3479710)

-- MAIN APPLICATION
addappid(3479710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3479711, 1, "7720a1ced443a67a6a65ba0832f4430ed5648e2d0a81a030fbddd2a35e3dd09d")
