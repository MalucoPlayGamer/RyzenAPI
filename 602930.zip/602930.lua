-- Lua provided by RyzenAPI
-- Game: Wordlase

-- MAIN APPLICATION
addappid(602930)
addappid(615140)
addappid(791460)

-- MAIN APP DEPOTS / PACKAGES
addappid(602931, 1, "5aa4a3e059e2ba3364911e8a9c0b564dd352cff336d86abd11873905f9a018f9")
addappid(602932, 1, "a6434c6e29c902448a33889ce0a39b43e42e03aa59d93d0ec6e4c0ba64433a2e")
addappid(602933, 1, "d1c201668183a264c48dee54f8a3b09bd6a182719a3d34ac78c77bc50dc45527")
addappid(699250, 0, "4af7253d2598c4dd8e2a93c82611b72f174629a03ffe8aa7ce262c5dba4c7cbc")
