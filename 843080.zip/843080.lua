-- Lua provided by RyzenAPI
-- Game: VR Hero Sentry

-- MAIN APPLICATION
addappid(843080)

-- MAIN APP DEPOTS / PACKAGES
addappid(843081, 1, "654d05262e3f551096f0dce1020257c4562e628fb642dd08e2b8c7a48e0fb904")
