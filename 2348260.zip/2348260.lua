-- Lua provided by RyzenAPI
-- Game: 2348260

-- MAIN APPLICATION
addappid(2348260)
-- Game: addappid(2348260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348261, 1, "0b7e72057b764b193ecd59278871a57dc1404aee655fbabf8630da95b711a6f9")
