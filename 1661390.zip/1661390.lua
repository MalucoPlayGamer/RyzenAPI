-- Lua provided by RyzenAPI
-- Game: Duelist

-- MAIN APPLICATION
addappid(1661390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661391, 1, "980a25d781108227e85174eed71868c38bfea1b1984af4077ca382a384b3ddba")
