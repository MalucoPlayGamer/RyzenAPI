-- Lua provided by RyzenAPI
-- Game: Shooters, Ready!

-- MAIN APPLICATION
addappid(3247500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247501, 1, "2ec841279dea66acee739255080dc7b850141ee51ad4cdb9be3ed2ed7ecc98e3")

