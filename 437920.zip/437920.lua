-- Lua provided by RyzenAPI
-- Game: Tricky Towers

-- MAIN APPLICATION
addappid(437920)
addappid(481360)

-- MAIN APP DEPOTS / PACKAGES
addappid(437921, 1, "f532f401190b85a616a0963b67b28c9cf7bdbac7d6b9a8c494be964a78229cc2")
addappid(437922, 1, "601e30531b7c1447c0a1cfdbea7defa0b71ebb1609f3024b0ef71ba34968572f")
addappid(437923, 1, "dacffdbd2ab23cf306e75dc3a2c26d000992454adcfb5617429e37fd8f0d9be0")
addappid(506920, 0, "5fc277921f0d0471ad43a10c72c24fc46da1eb532b4fbeafe6c45ed04a4c4cbc")
