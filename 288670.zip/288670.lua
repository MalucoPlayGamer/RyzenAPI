-- Lua provided by RyzenAPI
-- Game: Myths Of Orion: Books of Power

-- MAIN APPLICATION
addappid(288670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(288671, 1, "c04d45912576fe68a6e0dd18f7da6c16251243205f03115d5d69ac09ef63c6be")
addappid(288672, 1, "3ba0431f7368afcf5ec0bb4ed6f5ad0094234bc0b7b8bcfd730420ed7c0cb5f5")
addappid(288673, 1, "5c989664ae15aa98d7a8fd1632bccf2739a77f633abc4fa599cb4fec9f6b024e")

