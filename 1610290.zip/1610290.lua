-- Lua provided by RyzenAPI
-- Game: Chihiro Himukai Always Walks Away

-- MAIN APPLICATION
addappid(1610290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610291, 1, "a728ce7a282929c63ff6de751446e797cdf13e052f96826bf5de065174c161d1")
