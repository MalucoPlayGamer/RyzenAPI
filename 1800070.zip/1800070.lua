-- Lua provided by RyzenAPI
-- Game: Game: accelerating hotkeys

-- MAIN APPLICATION
addappid(1800070)
-- Game: addappid(1800070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800071, 1, "35e6c36c4bfffd6b78ccbe13334dc3275f3e8f7547d21ed6da0b3c0d4eee250c")
