-- Lua provided by RyzenAPI
-- Game: Game: AppID 543010

-- MAIN APPLICATION
addappid(543010)
-- Game: addappid(543010)

-- MAIN APP DEPOTS / PACKAGES
addappid(543011, 1, "6bc2868117ca5acb1742a73a03a57dd4600fdc85239256c8abec12c4496b9f88")
