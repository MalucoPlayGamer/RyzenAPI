-- Lua provided by SkyAPI 
-- Game: AppID 543010
addappid(543010)
addappid(543011, 1, "6bc2868117ca5acb1742a73a03a57dd4600fdc85239256c8abec12c4496b9f88")
