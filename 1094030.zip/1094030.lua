-- Lua provided by SkyAPI 
-- Game: Lurk in the Dark : Prologue
addappid(1094030)
addappid(1094031, 1, "4a2cdfb10153b645e3a4330df6f5ce604f22473a4065e1e38e36ab8aaeb5de0b")
addappid(1254380)
