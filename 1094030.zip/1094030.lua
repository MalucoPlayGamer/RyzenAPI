-- Lua provided by RyzenAPI
-- Game: Lurk in the Dark : Prologue

-- MAIN APPLICATION
addappid(1094030)
addappid(1254380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1094031, 1, "4a2cdfb10153b645e3a4330df6f5ce604f22473a4065e1e38e36ab8aaeb5de0b")

