-- Lua provided by RyzenAPI
-- Game: Game: Lurk in the Dark : Prologue

-- MAIN APPLICATION
addappid(1094030)
addappid(1254380)
-- Game: addappid(1094030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094031, 1, "4a2cdfb10153b645e3a4330df6f5ce604f22473a4065e1e38e36ab8aaeb5de0b")
