-- Lua provided by RyzenAPI
-- Game: 3817900

-- MAIN APPLICATION
addappid(3817900)
-- Game: addappid(3817900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3817901, 1, "dd893fb92185d572f54cfa629d5202ee743aa35a2bb80d6b02313cb11a2b97a9")
