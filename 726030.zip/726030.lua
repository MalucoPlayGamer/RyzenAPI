-- Lua provided by RyzenAPI
-- Game: addappid(726030)

-- MAIN APPLICATION
addappid(726030)

-- MAIN APP DEPOTS / PACKAGES
addappid(726031, 1, "817fd85458194d3b9523caf09a018332294d468b3ff7fc95f9a3a5b3856d5e13")
