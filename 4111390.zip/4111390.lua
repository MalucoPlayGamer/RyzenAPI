-- Lua provided by RyzenAPI
-- Game: Nickelodeon Extreme Tennis: Next!

-- MAIN APPLICATION
addappid(4111390)

-- MAIN APP DEPOTS / PACKAGES
addappid(4111391,0,"342e53e5854a01fa52ec234f80c619a76394095c51fbf08d88541c40f08ff1a1")

