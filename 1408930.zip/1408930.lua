-- Lua provided by SkyAPI 
-- Game: Greedy Corgi
addappid(1408930)
addappid(1408931, 1, "c0e98c858717727b418f38733cb9f0b040424ab985237a4df0d07327098a6f98")
