-- Lua provided by RyzenAPI
-- Game: Greedy Corgi

-- MAIN APPLICATION
addappid(1408930)
-- Game: addappid(1408930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408931, 1, "c0e98c858717727b418f38733cb9f0b040424ab985237a4df0d07327098a6f98")
