-- Lua provided by RyzenAPI
-- Game: My life as an archeologist

-- MAIN APPLICATION
addappid(1689350)
-- Game: addappid(1689350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689351, 1, "4c4d7517d0427ce7b31eef7f09aa6e752d6227a30310e115495017405f32c9e8")
