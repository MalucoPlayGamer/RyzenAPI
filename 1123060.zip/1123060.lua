-- Lua provided by RyzenAPI
-- Game: AppID 1123060

-- MAIN APPLICATION
addappid(1123060)
-- Game: addappid(1123060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123061, 1, "84352a658fd3de02bea6328ad903527e9690f7fd83835bb04a6ace117097118c")
