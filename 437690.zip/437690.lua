-- Lua provided by RyzenAPI
-- Game: 437690

-- MAIN APPLICATION
addappid(437690)
-- Game: addappid(437690)

-- MAIN APP DEPOTS / PACKAGES
addappid(437691, 1, "2766a3ef9d6a456cce6c4b8f46452122d86c76b85c74e9006124c1b616daef26")
