-- Lua provided by SkyAPI 
-- Game: Venture Kid
addappid(437690)
addappid(437691, 1, "2766a3ef9d6a456cce6c4b8f46452122d86c76b85c74e9006124c1b616daef26")
