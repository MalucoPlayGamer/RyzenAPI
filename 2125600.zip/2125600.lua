-- Lua provided by RyzenAPI
-- Game: Políticos Memes Kombat

-- MAIN APPLICATION
addappid(2125600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125601,0,"8d3f03cde51e7b28133d870509b894c0baabc256ce9a766a136889a76ebfcbac")

