-- Lua provided by RyzenAPI
-- Game: Game: DYMENSION Prologue:Scary Horror Survival Shooter

-- MAIN APPLICATION
addappid(1869220)
-- Game: addappid(1869220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869221, 1, "dae947f7a81f69a68163129505f66681c08868d741f1d60fe5007f2950f407a5")
