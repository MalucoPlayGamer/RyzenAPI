-- Lua provided by RyzenAPI
-- Game: AppID 1056970

-- MAIN APPLICATION
addappid(1056970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056971, 1, "23ebad0269476acefdfbb69996ef999375ba1e81199dc69e2e9f11f8ec35bd69")
addappid(1056972, 1, "34c601ab67d6fc0363ee3feb57f4fc2d69ddbd9299ea773d2175e7620c11e96f")
addappid(1056973, 1, "c89043dbd84c02fa1ee59cc0bf97d2a6f8947dec194b08b2b2ce0154d408d8a5")
addappid(1056974, 1, "5b366b191ddbed2ba7c627b41d8963c2a52ee954446fb42536360f3d26dff624")
addappid(1056975, 1, "99f0161956331710088ac08db7d6da8c86e8add7fc394bb6d9df6226e1eec4e1")
addappid(1056976, 1, "6ba739f7e52f25cbd03e996ef730a7bd27118a3dbc7e99a9b774b0035d108a49")
addappid(1056977, 1, "1d68a258575549b52e32f8f46a924d9b1c39a202ca63b18bc72bed8331d0e237")
addappid(1056978, 1, "d5a1c344ae31f8793dd07e59ed928bd7da348aa8fccc5cdb82cc318e04436f20")
addappid(1056979, 1, "2e4b290cc9bf3815adf5ca717ac73a4ca29775fe1e2d5f1d5fa6c84c2559c7a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
