-- Lua provided by SkyAPI 
-- Game: AppID 1076500
addappid(1076500)
addappid(1076501, 1, "bc26c45f4aa07f561f57e7d65efe87a30e6af27e213e54b853356973943ee706")
