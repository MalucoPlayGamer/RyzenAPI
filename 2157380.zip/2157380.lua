-- Lua provided by RyzenAPI
-- Game: Game: AppID 2157380

-- MAIN APPLICATION
addappid(2157380)
-- Game: addappid(2157380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157381, 1, "55a56ce5818f4daa9d3b5a2ed4418b02cfeaf7501c0080b8b6cb2c4ad3d43aac")
