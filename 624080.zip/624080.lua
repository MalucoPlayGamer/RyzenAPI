-- Lua provided by RyzenAPI
-- Game: Game: AppID 624080

-- MAIN APPLICATION
addappid(624080)
-- Game: addappid(624080)

-- MAIN APP DEPOTS / PACKAGES
addappid(624081, 1, "80a7a96f8f8ea51b0a7e2b409daedbceb6021e160b57ae589b978cfc3afe8e31")
addappid(624082, 1, "d547f9381060c71213d33385a0f88acbbe51403d689672d54b57276bed262c60")
addappid(624083, 1, "73bbf923c894e6d2101dda22114b5f4ac2d9a8417bd415d563007c138fb689dc")
