-- Lua provided by RyzenAPI
-- Game: 1377930

-- MAIN APPLICATION
addappid(1377930)
-- Game: addappid(1377930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377931, 1, "1c7d7f5f85a946de1689f7be373637156f1736dbb76202d9b03f2157f31c04bc")
