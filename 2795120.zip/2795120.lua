-- Lua provided by RyzenAPI
-- Game: 烟花绘梦 Firework Survivor

-- MAIN APPLICATION
addappid(2795120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795122,0,"4d34a51441411ed70a61ef35fc477098a43a8b6f50c3ff2f15330c6f3570383e")
