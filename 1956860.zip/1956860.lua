-- Lua provided by RyzenAPI
-- Game: Game: Down Fast VR

-- MAIN APPLICATION
addappid(1956860)
-- Game: addappid(1956860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956861, 1, "564b18559b10c8100aefa3edd6920012b0910b4b27a66040f1f617b4964ab80f")
