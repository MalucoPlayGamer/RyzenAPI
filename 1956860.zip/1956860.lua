-- Lua provided by SkyAPI 
-- Game: Down Fast VR
addappid(1956860)
addappid(1956861, 1, "564b18559b10c8100aefa3edd6920012b0910b4b27a66040f1f617b4964ab80f")
