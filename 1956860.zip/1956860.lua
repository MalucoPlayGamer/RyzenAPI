-- Lua provided by RyzenAPI
-- Game: Down Fast VR

-- MAIN APPLICATION
addappid(1956860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956861, 1, "564b18559b10c8100aefa3edd6920012b0910b4b27a66040f1f617b4964ab80f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
