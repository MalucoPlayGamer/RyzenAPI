-- Lua provided by RyzenAPI
-- Game: 428420

-- MAIN APPLICATION
addappid(428420)
addappid(494200)
-- Game: addappid(428420)

-- MAIN APP DEPOTS / PACKAGES
addappid(428421, 1, "7c6be39d71059f49e87bbcfb6c585b6bfa237ac37ceb24149eb87da41a706e17")
