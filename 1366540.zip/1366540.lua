-- Lua provided by RyzenAPI
-- Game: 1366540

-- MAIN APPLICATION
addappid(1366540)
-- Game: addappid(1366540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366541, 1, "88e374cd6c344868ab9b1591cdf0391483ea487bde467410ba7cac376292c19c")
