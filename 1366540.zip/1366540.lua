-- Lua provided by RyzenAPI
-- Game: Dyson Sphere Program

-- MAIN APPLICATION
addappid(1366540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366541, 1, "88e374cd6c344868ab9b1591cdf0391483ea487bde467410ba7cac376292c19c")

