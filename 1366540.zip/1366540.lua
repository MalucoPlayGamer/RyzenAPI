-- Lua provided by SkyAPI 
-- Game: AppID 1366540
addappid(1366540)
addappid(1366541, 1, "88e374cd6c344868ab9b1591cdf0391483ea487bde467410ba7cac376292c19c")
