-- Lua provided by RyzenAPI
-- Game: 1558630

-- MAIN APPLICATION
addappid(1558630)
-- Game: addappid(1558630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558631, 1, "497d82ef03818a31417dbdc3da6e937121f3689563cfac0e7d03c793aa2ed397")
addappid(1558632, 1, "70e8cbe0b48d8a15f8285de78b55cbdc625378abcb80a764e2cb3ee54d9d4249")
