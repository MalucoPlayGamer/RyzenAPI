-- Lua provided by RyzenAPI
-- Game: CARRION Soundtrack

-- MAIN APPLICATION
addappid(1377100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377101, 1, "bad216c728aca1d61e33ab06ec75035af84cb3517c2e20bd6ba7e23a084963d2")
addappid(1377102, 1, "0decf4bb00c75b46176848380151b9fbb5179a6a3b1cbaade0a55933c3d6c2e8")

