-- Lua provided by RyzenAPI
-- Game: 964931

-- MAIN APPLICATION
addappid(964931)
-- Game: addappid(964931)

-- MAIN APP DEPOTS / PACKAGES
addappid(964931,0,"d412a7729a307c5cbfcb7788c13324628528b83c60ab1b4a22537e8ea199c671")
