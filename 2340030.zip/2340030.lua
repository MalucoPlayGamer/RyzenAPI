-- Lua provided by RyzenAPI
-- Game: AppID 2340030

-- MAIN APPLICATION
addappid(2340030)
-- Game: addappid(2340030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340031, 1, "118b0ba7df21e3dbc57a8b546353e5fa5bff15c9384baab6acdf62cb789d81e5")
