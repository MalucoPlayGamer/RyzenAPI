-- Lua provided by SkyAPI 
-- Game: AppID 2340030
addappid(2340030)
addappid(2340031, 1, "118b0ba7df21e3dbc57a8b546353e5fa5bff15c9384baab6acdf62cb789d81e5")
