-- Lua provided by RyzenAPI
-- Game: 614450

-- MAIN APPLICATION
addappid(614450)
-- Game: addappid(614450)

-- MAIN APP DEPOTS / PACKAGES
addappid(614453,0,"d604ec83b15dc80f998043cfb9db47471d6829e7bca92450561cb83482b8f3f5")
