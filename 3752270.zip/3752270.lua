-- Lua provided by RyzenAPI
-- Game: DELTARUNE Soundtrack

-- MAIN APPLICATION
addappid(3752270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3752271, 1, "352d2c9e8397db32f09c71c78630d3e0757d88c64a5b3cdc90ff9c5e8d4e29d3")
addappid(3752272, 1, "c062539fd525e69dac6f63b0affb372c2786b5ada1dced6d177bc1959b859f11")

