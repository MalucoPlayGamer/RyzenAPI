-- Lua provided by RyzenAPI
-- Game: Endless Inside

-- MAIN APPLICATION
addappid(757580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(757581,0,"2818880abbdba67837831cadbcda9023d92ed1fefd6f1fa0abf11027375b38a8")

