-- Lua provided by RyzenAPI
-- Game: Endless Inside

-- MAIN APPLICATION
addappid(757580)

-- MAIN APP DEPOTS / PACKAGES
addappid(757581,0,"2818880abbdba67837831cadbcda9023d92ed1fefd6f1fa0abf11027375b38a8")

