-- Lua provided by RyzenAPI
-- Game: Gun Factory Simulator

-- MAIN APPLICATION
addappid(3137520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137521, 1, "6dffa7bebdc89d2a49f94564b961d8de4b0254b0c58e9e52f218f57059b02de2")
