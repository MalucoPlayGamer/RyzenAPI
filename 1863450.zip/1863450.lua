-- Lua provided by RyzenAPI
-- Game: addappid(1863450)

-- MAIN APPLICATION
addappid(1863450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863451, 1, "63d1b2554dfb211ce943a07761bccb8efcea133c619daef71f686900ff6270d1")
