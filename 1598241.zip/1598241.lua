-- Lua provided by RyzenAPI
-- Game: 1598241

-- MAIN APPLICATION
addappid(1598241)
-- Game: addappid(1598241)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598241,0,"f5e27599b1c51c9eb52a3fdd474aa9776f73dc3e3c8ec66bc474b98d79af0fa0")
