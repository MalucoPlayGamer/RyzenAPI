-- Lua provided by RyzenAPI
-- Game: 2075340

-- MAIN APPLICATION
addappid(2075340)
-- Game: addappid(2075340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075341, 1, "d75b44c994c769c4a988aadd9d8dbf773ece1e71109917b2d9e735b2cc5cd8a6")
