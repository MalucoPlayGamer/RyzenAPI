-- Lua provided by RyzenAPI
-- Game: Platformines

-- MAIN APPLICATION
addappid(264540)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(264541, 1, "ebcf05ada669805e522df61f861da727d4a0be2aebd6f1c36502cb4b4e3c62d8")
