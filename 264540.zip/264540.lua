-- Lua provided by RyzenAPI
-- Game: AppID 264540

-- MAIN APPLICATION
addappid(264540)

-- MAIN APP DEPOTS / PACKAGES
addappid(264541, 1, "ebcf05ada669805e522df61f861da727d4a0be2aebd6f1c36502cb4b4e3c62d8")
