-- Lua provided by RyzenAPI
-- Game: Gachimuchi

-- MAIN APPLICATION
addappid(740600)

-- MAIN APP DEPOTS / PACKAGES
addappid(740601, 1, "dc63af9adb0a3c874260f4f44adc53fdfcad330c0d77e2e6612e7dc9616584cf")
