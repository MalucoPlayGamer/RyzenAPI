-- Lua provided by RyzenAPI
-- Game: Mirage Episode：1

-- MAIN APPLICATION
addappid(3362140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362142,0,"f06db3b2261d02249c92aecaf5a7fe78fc19c7ed20c4198a69745de3cfe57fdb")
