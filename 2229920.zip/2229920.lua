-- Lua provided by RyzenAPI
-- Game: Temporian

-- MAIN APPLICATION
addappid(2229920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229921, 1, "934a19081e1804bb99a3f726d6ba2a018a8db2e6f6781544527fff9251426e8a")
