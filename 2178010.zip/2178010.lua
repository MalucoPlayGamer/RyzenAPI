-- Lua provided by RyzenAPI
-- Game: Runeverse

-- MAIN APPLICATION
addappid(2178010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178011, 1, "a0752f587df40e1a4c36ea0c2eb8379abc7b80dc4fcf7b39228ca59f2861694c")
addappid(2178012, 1, "5905d17010673e9c7216c1f53893ccec96de9f45b9aa158ea16f9180680be14e")

