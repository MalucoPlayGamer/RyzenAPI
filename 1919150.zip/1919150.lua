-- Lua provided by RyzenAPI
-- Game: addappid(1919150)

-- MAIN APPLICATION
addappid(1919150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919151, 1, "a5a7e13a8bf1415240f4df52b5c88542463044c19fad67f80ef5279caa5e7425")
