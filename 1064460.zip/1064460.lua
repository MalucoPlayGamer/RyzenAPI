-- Lua provided by RyzenAPI
-- Game: Game: Murder House

-- MAIN APPLICATION
addappid(1064460)
-- Game: addappid(1064460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064461, 1, "e53b6e40c543144630fa39758e6c97913fed7c678f9b01c4868d98580dbc8cfb")
