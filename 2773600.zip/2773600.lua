-- Lua provided by RyzenAPI
-- Game: Picnic Peril

-- MAIN APPLICATION
addappid(2773600)
addappid(2773603)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773602,0,"c1e31cddb416ce6cba828e0609d70b85e3fc93ac2a76e2a2c9e44847f573be19")

