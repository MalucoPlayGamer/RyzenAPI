-- Lua provided by RyzenAPI
-- Game: Lost For Swords Demo

-- MAIN APPLICATION
addappid(2661450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661451, 1, "d7157595ba36a57f276fa80cbfa0eba41aaaa35424e90752f5b8e85c6322e2e2")

