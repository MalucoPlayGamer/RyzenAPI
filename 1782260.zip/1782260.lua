-- Lua provided by RyzenAPI
-- Game: Game: Sleep and Girls

-- MAIN APPLICATION
addappid(1782260)
-- Game: addappid(1782260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782261, 1, "1b3c8a3272034c788ddbb81ba3fb8355535d165ba3500a257c5f011f1eb20cc0")
