-- Lua provided by RyzenAPI
-- Game: 2175150

-- MAIN APPLICATION
addappid(2175150)
-- Game: addappid(2175150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175151, 1, "67acc965df93751cc43ef9f314abcd37ef5835ad9cf9b0e1422dd4246c59a1d6")
