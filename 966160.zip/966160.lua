-- Lua provided by RyzenAPI
-- Game: Seek Love

-- MAIN APPLICATION
addappid(966160)

-- MAIN APP DEPOTS / PACKAGES
addappid(966161, 1, "70db9ea03f1630b96d212129cab83f2ef65d2fb37c2fa0905691c26ca7cd3c18")
addappid(966162, 1, "61e39fc16b5b35e29b47c211b76f6306460b15a567c1163f521c764f1258c916")
addappid(990200, 0, "395bd4ea0d07a3dd4d77018ece857fe07df7599532f9374482f2af2fbb7c48a3")
addappid(990201, 0, "aeeaf2121daac7fa1073c155ccf393646b217614dcec1221ed63dda66fbc116e")
addappid(990202, 0, "be6467948b8ac7e0ef2a68da3bfc2cfcdbc6abb3fcd5423202c7ab79b864d9bc")

