-- Lua provided by RyzenAPI
-- Game: The Forest of Conx

-- MAIN APPLICATION
addappid(2513810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513811, 1, "6425fe2f39c975816fa2c427d0b0497f54e74fa490c97f0a5ec4acfec0d14573")
