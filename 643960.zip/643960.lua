-- Lua provided by RyzenAPI
-- Game: Cursed Treasure 2

-- MAIN APPLICATION
addappid(643960)

-- MAIN APP DEPOTS / PACKAGES
addappid(643961, 1, "1656bff70dc5b081a66d6fbc9328d45b97f9dc4caceb8760268d7dbe6f2e2047")

