-- Lua provided by RyzenAPI 
-- Game: Furry Milfs
addappid(2412150)
addappid(2412151, 1, "99fb5de892319f1d73c480fe7b6561460ad2a8e0df648699537a83a96a8e4d97")
