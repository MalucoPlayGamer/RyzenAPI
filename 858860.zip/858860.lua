-- Lua provided by RyzenAPI
-- Game: Tabletop Gods

-- MAIN APPLICATION
addappid(858860)

-- MAIN APP DEPOTS / PACKAGES
addappid(858861,0,"004bc78f6007b93ceb25e9d857e4ae43e747b944c778f932f4d71a56aeae59de")

