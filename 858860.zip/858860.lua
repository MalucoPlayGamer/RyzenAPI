-- Lua provided by RyzenAPI
-- Game: Tabletop Gods

-- MAIN APPLICATION
addappid(858860)

-- MAIN APP DEPOTS / PACKAGES
addappid(858861,0,"004bc78f6007b93ceb25e9d857e4ae43e747b944c778f932f4d71a56aeae59de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
