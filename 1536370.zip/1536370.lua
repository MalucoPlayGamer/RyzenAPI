-- Lua provided by RyzenAPI
-- Game: 1536370

-- MAIN APPLICATION
addappid(1536370)
-- Game: addappid(1536370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536370,0,"f181d094b56122842c212b3b737c55098b03a4ea01b6c80dfd0f12aefc7cdcbd")
