-- Lua provided by RyzenAPI
-- Game: Hairdresser Simulator

-- MAIN APPLICATION
addappid(1330560)
addappid(2782930)
addappid(3251570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330562,0,"d24eb6a3e022ee21b57a318effa94c7701d341630f17a730ec6a2ea232a66efa")

