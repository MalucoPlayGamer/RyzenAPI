-- Lua provided by RyzenAPI
-- Game: Cats in Heat - Summer Fling

-- MAIN APPLICATION
addappid(2278780)
-- Game: addappid(2278780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278781, 1, "853ee3e53c1fb7349d0f7bd2d7f2a462eb3a59f74b13086739ca955655df73cb")
