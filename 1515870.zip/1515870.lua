-- Lua provided by RyzenAPI
-- Game: Game: Hentai Balloons 2

-- MAIN APPLICATION
addappid(1515870)
-- Game: addappid(1515870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515871, 1, "87706f475e11e0007d73e9fae1a2d1750920d49788108ad666d953f794579876")
