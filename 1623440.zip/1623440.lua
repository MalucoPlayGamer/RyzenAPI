-- Lua provided by RyzenAPI
-- Game: addappid(1623440)

-- MAIN APPLICATION
addappid(1623440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623441, 1, "abe436c5dcbbd3d11638250f3821b716a1648f2924a2548c18f186ac1e512ec5")
