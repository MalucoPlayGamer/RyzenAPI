-- Lua provided by RyzenAPI
-- Game: My Yandere is a Futanari

-- MAIN APPLICATION
addappid(1854800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854801, 1, "94d91ad65155663d088400a07ec67f19932df121c73c1490e99665f0eb933f79")
