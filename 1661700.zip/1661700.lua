-- Lua provided by RyzenAPI
-- Game: 1661700

-- MAIN APPLICATION
addappid(1661700)
-- Game: addappid(1661700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661701, 1, "e7750ec3d5b5b01d7686740628da2264080f4a2b6d4d5ed8928e0d24c2f28c75")
