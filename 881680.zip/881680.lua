-- Lua provided by SkyAPI 
-- Game: Mouse Enhancer Pro
addappid(881680)
addappid(881681, 1, "92ae6ebd1c7036bd0f50a99c8575168bd928da550c97587c0dac3bb6b979c903")
