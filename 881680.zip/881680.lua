-- Lua provided by RyzenAPI
-- Game: addappid(881680)

-- MAIN APPLICATION
addappid(881680)

-- MAIN APP DEPOTS / PACKAGES
addappid(881681, 1, "92ae6ebd1c7036bd0f50a99c8575168bd928da550c97587c0dac3bb6b979c903")
