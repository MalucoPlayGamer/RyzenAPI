-- Lua provided by RyzenAPI
-- Game: VARIANTBIRTH

-- MAIN APPLICATION
addappid(3756360)
-- Game: addappid(3756360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3756361, 1, "9f1f8e0ee887f627e7a242f1af9d7aebb0e5f012926ac48821650202bf752ac0")
