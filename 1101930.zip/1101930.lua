-- Lua provided by RyzenAPI
-- Game: Monsters of Little Haven

-- MAIN APPLICATION
addappid(1101930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1101931, 1, "61b5387b1490b36f09619d7dbec1c88b597febd0252ee85f29ccf9ca573bc916")
addappid(1101932, 1, "a79fa97da66ba20021607261aad700efff8dd43c6d6ee917fee38902a37261e4")
addappid(1101933, 1, "62ee8e4b1d688e94aff229c8606c2444b343db3f9b6d65ff5291a41f4c2478e5")
addappid(1101934, 1, "fb5ef9b4bf7af3821869b2b89476c5e11983a7c68583c048ebe7bcac061539ce")
addappid(1124440, 0, "b1b70b769b434c6985f386f8a3c5c838365d77c8595dd204a9cbba3534b58075")
addappid(1124441, 0, "321de686c8a4199d8def95b32ccface2935d15958920b32e001b73f054391c7e")

