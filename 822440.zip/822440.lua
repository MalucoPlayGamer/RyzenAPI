-- Lua provided by RyzenAPI
-- Game: You Are The Apple Of My Eye 研磨时光

-- MAIN APPLICATION
addappid(822440)
addappid(856000)
addappid(856001)

-- MAIN APP DEPOTS / PACKAGES
addappid(822441, 1, "351254846d27d4f84c81b3ae38f8aa08ac5daec832cffd3e91c9301b3f3941e1")
addappid(822442, 1, "1003ccd54a783143f01ef195a51ace60ef2ea21554a7eab3aaf0880dc1eccdb8")

