-- Lua provided by RyzenAPI
-- Game: Rail Route

-- MAIN APPLICATION
addappid(1124180)
-- Game: addappid(1124180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124182,0,"81bb06ebf8b5dd9a399a9d53dcc4757d72d52e79abf196618e56468ecd339e95")
addappid(1124183,0,"8f80b57f698bd67ec3f502fb703dfca2f502c9223f1e7f6cbd2c43fe809229bc")
addappid(1124184,0,"b034d6a660d0f077240a0059876177ac31e50ac363f6f328f44eb16ef9d950fd")
