-- Lua provided by RyzenAPI
-- Game: Drunk Builder Simulator

-- MAIN APPLICATION
addappid(3113750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113751, 1, "1f4f2edd4b1c18c4a776008fc5c10e9cf5b67810889058252c80ab8f0c229ae0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
