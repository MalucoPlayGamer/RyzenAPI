-- Lua provided by RyzenAPI 
-- Game: Drunk Builder Simulator
addappid(3113750)
addappid(3113751, 1, "1f4f2edd4b1c18c4a776008fc5c10e9cf5b67810889058252c80ab8f0c229ae0")
