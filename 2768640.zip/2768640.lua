-- Lua provided by RyzenAPI
-- Game: 杀青

-- MAIN APPLICATION
addappid(2768640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768641, 1, "9fa7eb32d8273d31a18c761d1c665f2f03fc2863c3539f55eb9cbcf41eac0f38")

