-- Lua provided by RyzenAPI
-- Game: 1212610

-- MAIN APPLICATION
addappid(1212610)
-- Game: addappid(1212610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212611, 1, "cede2c18b826b0da787dee15aa28a60a84cd6f4b0762a745c2dfdbe807246680")
