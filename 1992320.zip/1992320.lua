-- Lua provided by RyzenAPI
-- Game: Sons of Valhalla Demo

-- MAIN APPLICATION
addappid(1992320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992321, 1, "213beec89d9805f100413fa505579ddbd18d66ae84ef838e525fd7f4c5dccc26")
