-- Lua provided by RyzenAPI
-- Game: The Dark Legacy

-- MAIN APPLICATION
addappid(3679470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3679471,0,"96dd3bdbfca3788324492a43b1366fbf90ab32f46a8634495e05781fc49b7384")

