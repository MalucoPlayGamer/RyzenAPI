-- Lua provided by RyzenAPI
-- Game: DERE EXE: Rebirth of Horror

-- MAIN APPLICATION
addappid(1597110)
-- Game: addappid(1597110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597111, 1, "bb9d6023740e0c08819625a375fbb505af610710611d14aca5f2d571ab30d6bf")
