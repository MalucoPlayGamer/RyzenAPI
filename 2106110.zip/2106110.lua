-- Lua provided by RyzenAPI
-- Game: Mafia Pigs

-- MAIN APPLICATION
addappid(2106110)
-- Game: addappid(2106110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106111, 1, "4b3e193d64d9f2e476359d48916cda33c2b2e1ded43ee65f35fd6766168f59cc")
addappid(2106112, 1, "4cd5d586e19e4da41fa4dc2b60083e3ed3588c0366be47e2f111401ba984fcae")
