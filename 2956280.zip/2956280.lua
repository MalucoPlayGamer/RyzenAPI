-- Lua provided by RyzenAPI
-- Game: Game: 花恋月依

-- MAIN APPLICATION
addappid(2956280)
-- Game: addappid(2956280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956281, 1, "316f169e6300ff7a1ceae59c56527357424ec2acfe840a63d1afca51c3ea6c9c")
