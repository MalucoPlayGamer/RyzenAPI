-- Lua provided by RyzenAPI
-- Game: Game: Town to City Demo

-- MAIN APPLICATION
addappid(3653800)
-- Game: addappid(3653800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653801, 1, "65e30d9fd3ad599b9079bf9d814c7e7b14f4a61a5efcd98a7f9d6a8462caa414")
