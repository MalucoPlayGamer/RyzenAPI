-- Lua provided by RyzenAPI
-- Game: Resilience Wave Survival

-- MAIN APPLICATION
addappid(429490)

-- MAIN APP DEPOTS / PACKAGES
addappid(429491, 1, "3231cebef6a1841e664716467fcf962cd988f69ffc6ba1e31eeab1bbf313f830")

