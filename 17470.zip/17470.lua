-- Lua provided by RyzenAPI
-- Game: Dead Space (2008)

-- MAIN APPLICATION
addappid(17470)
-- Game: addappid(17470)

-- MAIN APP DEPOTS / PACKAGES
addappid(17471, 1, "37c09725566a2f37a7e099db99334638a3bd9a5e0baf7d79d67039cab768535c")
addappid(17472, 1, "bb179e217854555d2ad5686797567923b79d9ca2f8bc1cc821327220afa6b493")
addappid(17473, 1, "eb3cbc31e17f7f645f2c9261acdf60aa52f6bdfc4d37d2605bd7e70f6bb48b0c")
addappid(17474, 1, "4592e52066a840fa4fef21406c8b2c6674c8eda00575e8d1e4077770e8d262cb")
addappid(17475, 1, "e6b7525043e7caadea7344e0ef880b3ee706138a5ab04a06d7f769743cb65cde")
addappid(17476, 1, "6220e7fb29844d167ad7f4142fecc275decbf522be1b2bfca5afc8f180d83e29")
