-- Lua provided by RyzenAPI
-- Game: 929730

-- MAIN APPLICATION
addappid(929730)
-- Game: addappid(929730)

-- MAIN APP DEPOTS / PACKAGES
addappid(929731, 1, "917c720b0282ff8574e6938f5b35a1f59e9a3ce94ee0f615f51f25661aebadfd")
