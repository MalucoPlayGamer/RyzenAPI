-- Lua provided by RyzenAPI
-- Game: foreverloops LONGPLAY

-- MAIN APPLICATION
addappid(725610)
addappid(1131980)

-- MAIN APP DEPOTS / PACKAGES
addappid(725611, 1, "b805e44685b1b849f4f92a94fd854a5b33509416d4214fed453ee2da884ff86f")

