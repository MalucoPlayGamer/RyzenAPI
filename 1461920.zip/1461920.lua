-- Lua provided by RyzenAPI
-- Game: Game: The Legend of Heroes: Ao no Kiseki KAI

-- MAIN APPLICATION
addappid(1461920)
-- Game: addappid(1461920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461921, 1, "75f97eb43515b11f8f575638929939f49585cd45fe0c50e24342b1e7c84248d0")
