-- Lua provided by RyzenAPI
-- Game: Who is Paul

-- MAIN APPLICATION
addappid(3215680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215681, 1, "eab46fa0ce2568362b578c8f2206074561b73932c202d5dd7bf68e41bd984cb7")

