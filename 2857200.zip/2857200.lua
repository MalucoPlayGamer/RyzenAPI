-- Lua provided by RyzenAPI 
-- Game: AppID 2857200
addappid(2857200)
addappid(2857201, 1, "8b19e4bfa06d3556399142b55b97dc3773a49ced39c2cfa72d1bd59c32fba5c3")
