-- Lua provided by RyzenAPI
-- Game: HuaBing

-- MAIN APPLICATION
addappid(2284780)
-- Game: addappid(2284780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2284781, 1, "382ba6edba1f25558517cbb7e13f936e369afa062f3ee75fe61947f397656d77")
