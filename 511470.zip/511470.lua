-- Lua provided by RyzenAPI
-- Game: Glass Masquerade

-- MAIN APPLICATION
addappid(511470)
addappid(801310)
addappid(938030)
addappid(969270)
addappid(1004130)
addappid(1105630)

-- MAIN APP DEPOTS / PACKAGES
addappid(511471, 1, "426efb631e890cdd49b2f329632aa9a135e132895ec92dca4a8ae4eb7df1c931")
addappid(511472, 1, "a0588c2977bb5715c0bf059332cb4dab6b9309032fdcc51a3ed84c89da1c70ca")

