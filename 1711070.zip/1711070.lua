-- Lua provided by RyzenAPI 
-- Game: Circe's revenge
addappid(1711070)
addappid(1711071, 1, "d8b6576f19330b69f2b94a4c01b867acfcc26223e562fc7084ca845b7ba6b734")
