-- Lua provided by RyzenAPI
-- Game: Circe's revenge

-- MAIN APPLICATION
addappid(1711070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1711071, 1, "d8b6576f19330b69f2b94a4c01b867acfcc26223e562fc7084ca845b7ba6b734")

