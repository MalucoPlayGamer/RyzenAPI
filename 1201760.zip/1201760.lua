-- Lua provided by RyzenAPI 
-- Game: AppID 1201760
addappid(1201760)
addappid(1201761, 1, "515d7811c8b6b004b14d42ceedf824a9c6f445900b78d4a668b69ab57f4b8a5b")
