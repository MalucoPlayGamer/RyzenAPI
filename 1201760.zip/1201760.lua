-- Lua provided by RyzenAPI
-- Game: Kari

-- MAIN APPLICATION
addappid(1201760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1201761, 1, "515d7811c8b6b004b14d42ceedf824a9c6f445900b78d4a668b69ab57f4b8a5b")
