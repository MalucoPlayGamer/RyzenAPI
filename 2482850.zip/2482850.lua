-- Lua provided by RyzenAPI
-- Game: POLARIS™

-- MAIN APPLICATION
addappid(2482850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482851, 1, "937d275d0dce796f966a47ea07674031e703612ef4604690c3df0349c83bd65d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
