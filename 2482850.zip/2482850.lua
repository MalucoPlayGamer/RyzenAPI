-- Lua provided by RyzenAPI
-- Game: Game: POLARIS™

-- MAIN APPLICATION
addappid(2482850)
-- Game: addappid(2482850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482851, 1, "937d275d0dce796f966a47ea07674031e703612ef4604690c3df0349c83bd65d")
