-- Lua provided by RyzenAPI
-- Game: addappid(2741950)

-- MAIN APPLICATION
addappid(2741950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741952,0,"fb63cb7bc0aa6e97f2637e7c80996e4bd04f28c51e566ede63cdfad683bf8115")
addappid(2741953,0,"567f426fa4e6964ebb69c3a792cf34ea177a9a9fe1e3df3101ec00f9d0235b28")
