-- Lua provided by RyzenAPI
-- Game: Last Of Ark: Prologue

-- MAIN APPLICATION
addappid(2068460)
-- Game: addappid(2068460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068461, 1, "1ea1035dc2b719c880a5e27ef98fbb2052cf609e0ca441909b0a7e292c205cc2")
