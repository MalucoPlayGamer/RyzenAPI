-- Lua provided by RyzenAPI
-- Game: Oblitus

-- MAIN APPLICATION
addappid(306440)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(306441, 1, "57c5b395b04d2ee859b1ae3aa280098238dc8d9fdda852ba9c4e943e75d3bb6f")

