-- Lua provided by RyzenAPI
-- Game: addappid(306440)

-- MAIN APPLICATION
addappid(306440)

-- MAIN APP DEPOTS / PACKAGES
addappid(306441, 1, "57c5b395b04d2ee859b1ae3aa280098238dc8d9fdda852ba9c4e943e75d3bb6f")
