-- Lua provided by RyzenAPI
-- Game: Navalny: Posledniy miting

-- MAIN APPLICATION
addappid(959830)

-- MAIN APP DEPOTS / PACKAGES
addappid(959831, 1, "371eb93ed73b983eafb9a15f5c7a9d8a28d71caec596903631211aa8598f52e5")

