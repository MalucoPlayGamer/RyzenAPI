-- Lua provided by RyzenAPI
-- Game: To Be A King - Volume 1

-- MAIN APPLICATION
addappid(2081630)
-- Game: addappid(2081630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081631, 1, "6f32c6d15fb0d5fff89e5cb9b8d11482bc8f1b82dbc41323d10158a7423e0351")
addappid(2109690, 0, "2f4d1324240232043695b2b6b1ddc4d50e5a70c424746d5decc300467921812f")
