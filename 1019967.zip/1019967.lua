-- Lua provided by RyzenAPI
-- Game: addappid(1019967)

-- MAIN APPLICATION
addappid(1019967)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019967,0,"27397d650ffd59c48921f66f3039b1bd336117803b7366abddf822e7eaca9fcc")
