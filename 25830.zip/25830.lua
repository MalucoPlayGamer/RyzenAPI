-- Lua provided by RyzenAPI
-- Game: Knights of Honor

-- MAIN APPLICATION
addappid(25830)

-- MAIN APP DEPOTS / PACKAGES
addappid(25831, 1, "7c8145db2f18f0387a0d828954a1f6416a91edde8bee0a581c3e3df8bff293bb")

