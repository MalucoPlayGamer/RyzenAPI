-- Lua provided by RyzenAPI
-- Game: AppID 1304770

-- MAIN APPLICATION
addappid(1304770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304771, 1, "44a1faf68fca819179ac0bf1a82d3377c9743faeb126c7dc48d0be1df3589929")

