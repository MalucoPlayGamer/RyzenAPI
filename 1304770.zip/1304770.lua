-- Lua provided by SkyAPI 
-- Game: AppID 1304770
addappid(1304770)
addappid(1304771, 1, "44a1faf68fca819179ac0bf1a82d3377c9743faeb126c7dc48d0be1df3589929")
