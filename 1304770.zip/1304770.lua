-- Lua provided by RyzenAPI
-- Game: The Magister

-- MAIN APPLICATION
addappid(1304770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1304771, 1, "44a1faf68fca819179ac0bf1a82d3377c9743faeb126c7dc48d0be1df3589929")

