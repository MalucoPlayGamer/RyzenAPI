-- Lua provided by RyzenAPI
-- Game: Where the Water Tastes Like Wine

-- MAIN APPLICATION
addappid(447120)
-- Game: addappid(447120)

-- MAIN APP DEPOTS / PACKAGES
addappid(447121, 1, "a5c0422e798f36f2dda111d61c0b73846a2dc834bbc43470a38d281e7dfece42")
addappid(447122, 1, "f2dfb614498a43c3c160db2121a3d475fd6be1c70f50164cee409ab38f7d8772")
addappid(447123, 1, "8ff73f6041f234789ae5fa0927cdded1f23431b350fdd5e9853ecf522b966a4e")
addappid(447124, 1, "1b93775f04092674a35f412b42045941f26e8ec5f28a1e3dcd84ce3f75e9395b")
addappid(798430, 0, "4252661ba14796d86ab1321d4f9778a658451ff6d6de54df38a98c6df1e29b55")
