-- Lua provided by RyzenAPI
-- Game: 1711230

-- MAIN APPLICATION
addappid(1711230)
-- Game: addappid(1711230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711231, 1, "48c909c1ce276617a400a7b90d58899c9ba849492cb9c3d8bcfb573cbede1530")
