-- Lua provided by RyzenAPI
-- Game: Game: AppID 1302240

-- MAIN APPLICATION
addappid(1302240)
-- Game: addappid(1302240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302241, 1, "1f0abf461681b647baf3263a992ea65516c85019d3015e79620b7136afb158dd")
