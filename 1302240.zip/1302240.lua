-- Lua provided by RyzenAPI
-- Game: Labyrinthine

-- MAIN APPLICATION
addappid(1302240)
addappid(2438400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302241, 1, "1f0abf461681b647baf3263a992ea65516c85019d3015e79620b7136afb158dd")
