-- Lua provided by RyzenAPI
-- Game: Dream Golf VR

-- MAIN APPLICATION
addappid(723610)
addappid(768910)
addappid(964120)
addappid(1145840)
addappid(2123880)

-- MAIN APP DEPOTS / PACKAGES
addappid(723611, 1, "71e44e8431e5035e672681a1355e223d1a1c93887873df591a7aa7e6d92d9804")

