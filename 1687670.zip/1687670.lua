-- Lua provided by RyzenAPI
-- Game: LAST CLOUDIA

-- MAIN APPLICATION
addappid(1687670)
-- Game: addappid(1687670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687671, 1, "d8dd4776e4529e69105a81b2b732fbb4f8e49e5a4edec00929f6600c4ee679ce")
