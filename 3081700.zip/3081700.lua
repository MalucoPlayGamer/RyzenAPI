-- Lua provided by RyzenAPI
-- Game: Hawk Tuah

-- MAIN APPLICATION
addappid(3081700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081701, 1, "16a0ce7720e7659851d604cd591405ca9b6c20a8724fdf220a3a71c65e1af8ad")
