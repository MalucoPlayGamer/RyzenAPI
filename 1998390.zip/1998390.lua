-- Lua provided by RyzenAPI
-- Game: Road Trip

-- MAIN APPLICATION
addappid(1998390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998391, 1, "18508cf8b00f4ac79ce6f802288c39ae6a947bb510fbe6165d41dcc84bd56888")
