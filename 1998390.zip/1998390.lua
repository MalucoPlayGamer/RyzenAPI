-- Lua provided by SkyAPI 
-- Game: Road Trip
addappid(1998390)
addappid(1998391, 1, "18508cf8b00f4ac79ce6f802288c39ae6a947bb510fbe6165d41dcc84bd56888")
