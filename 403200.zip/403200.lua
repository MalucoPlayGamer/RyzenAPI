-- Lua provided by RyzenAPI
-- Game: addappid(403200)

-- MAIN APPLICATION
addappid(403200)

-- MAIN APP DEPOTS / PACKAGES
addappid(403201, 1, "e8724fab2e5d36d915692de211d7fee7b92f52439ca6fe391dad1a983137934d")
