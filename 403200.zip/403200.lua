-- Lua provided by RyzenAPI
-- Game: Legends of Dawn Reborn

-- MAIN APPLICATION
addappid(403200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(403201, 1, "e8724fab2e5d36d915692de211d7fee7b92f52439ca6fe391dad1a983137934d")

