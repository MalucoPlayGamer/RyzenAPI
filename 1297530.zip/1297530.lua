-- Lua provided by RyzenAPI
-- Game: Game: AppID 1297530

-- MAIN APPLICATION
addappid(1297530)
-- Game: addappid(1297530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297531, 1, "b12316a7bfe7850d2dabcb80c0b60ce1f6e2e3be4dbe8ccb1d7e0d1e885ad36f")
