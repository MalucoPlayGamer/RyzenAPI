-- Lua provided by RyzenAPI
-- Game: The Lost Dachshund

-- MAIN APPLICATION
addappid(1975120)
