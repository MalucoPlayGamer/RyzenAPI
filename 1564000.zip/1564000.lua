-- Lua provided by RyzenAPI
-- Game: addappid(1564000)

-- MAIN APPLICATION
addappid(1564000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564001, 1, "9c9ed3bcaf7ec2f79c57264dd0659601d3d6d64b9ed38c4f1529d1fe3f6c3e4e")
addappid(1564002, 1, "676c369210132f8fdebc19ddb6edffa8d525c45219b7b54e4fbb6cf5a47c0cbd")
