-- Lua provided by RyzenAPI
-- Game: 1225780

-- MAIN APPLICATION
addappid(228985)
addappid(229020)
addappid(1225780)
addappid(1371030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225782,0,"8a6601c2bae40abb2f65d0ad722c76aa1b296172a0db769742afe5f8c2c88afe")
