-- Lua provided by RyzenAPI
-- Game: Game: Click To Continue

-- MAIN APPLICATION
addappid(3636440)
-- Game: addappid(3636440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3636441, 1, "070f5acd0d5383b1d0d0dc3229bf977f906b74bacc19913a16bed74350c75431")
