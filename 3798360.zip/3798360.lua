-- Lua provided by RyzenAPI
-- Game: Game: Capcom Fighting Collection 2 - Vol.2(Capcom vs SNK2 ver.2K25)［Original Soundtrack］

-- MAIN APPLICATION
addappid(3798360)
-- Game: addappid(3798360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3798361, 1, "1c19cdae10cdaa7eb969a8f99b0c9aa1edf30de182b717f50705a8cc665bcf4f")
