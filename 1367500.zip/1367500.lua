-- Lua provided by RyzenAPI
-- Game: 1367500

-- MAIN APPLICATION
addappid(1367500)
-- Game: addappid(1367500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367501, 1, "3c38a752c82b6e1cedd1c178c534c7be3fb0792c407fd3cc8c92b772ac09b003")
