-- Lua provided by RyzenAPI
-- Game: addappid(1610140)

-- MAIN APPLICATION
addappid(1610140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610141, 1, "6c3fa5fe1c63c6212815500e3ea9984319d8e76bf1290c0d3e695a57b50ce82c")
