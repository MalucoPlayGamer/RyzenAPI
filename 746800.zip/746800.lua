-- Lua provided by RyzenAPI
-- Game: Game: AppID 746800

-- MAIN APPLICATION
addappid(746800)
-- Game: addappid(746800)

-- MAIN APP DEPOTS / PACKAGES
addappid(746801, 1, "c2fd2f76f16c5864e71c59f5e7bb441f49e1ec23a6950d81453c58f51c71db92")
