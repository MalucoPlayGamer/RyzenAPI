-- Lua provided by RyzenAPI
-- Game: Paradise Sea

-- MAIN APPLICATION
addappid(3675130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3675133,0,"6b811e236997926003df791e1a76c589ca20d60a3c3b96312cfe1dccc39a9170")

