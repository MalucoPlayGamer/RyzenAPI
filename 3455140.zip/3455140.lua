-- Lua provided by RyzenAPI
-- Game: addappid(3455140)

-- MAIN APPLICATION
addappid(3455140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3455141, 1, "e5c1456545d0a46f80adacb7ea7a679c3d34acc83279f837e2c46892d1caadf7")
