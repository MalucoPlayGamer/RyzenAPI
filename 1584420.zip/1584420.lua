-- Lua provided by SkyAPI 
-- Game: Russian Mailman Simulator
addappid(1584420)
addappid(1584421, 1, "5c9204db235cb08ecf45d556ee305945af2c72e4120f6949426a7bff6a8d059e")
