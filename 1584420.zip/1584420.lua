-- Lua provided by RyzenAPI
-- Game: Russian Mailman Simulator

-- MAIN APPLICATION
addappid(1584420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584421, 1, "5c9204db235cb08ecf45d556ee305945af2c72e4120f6949426a7bff6a8d059e")

