-- Lua provided by RyzenAPI
-- Game: AppID 3227970

-- MAIN APPLICATION
addappid(3227970)
-- Game: addappid(3227970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227971, 1, "dbdebf8f5baf5c6f3b399ca6f1712913ce61766d375b9b09f1435266b2d9017d")
