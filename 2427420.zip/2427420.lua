-- Lua provided by RyzenAPI
-- Game: S.T.A.L.K.E.R.: Clear Sky - Enhanced Edition

-- MAIN APPLICATION
addappid(2427420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427421, 1, "827f45298696740de1e0a738ea404041c826aeb40dd6eccb1b6957cc711a4fc6")

