-- Lua provided by SkyAPI 
-- Game: Let's Cook Together 2
addappid(1637400)
addappid(1637401, 1, "ea14270e5247cec7afc3693c00273dffde99fc4c6da67730618e043be3d696fa")
