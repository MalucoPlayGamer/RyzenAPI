-- Lua provided by RyzenAPI
-- Game: addappid(1637400)

-- MAIN APPLICATION
addappid(1637400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637401, 1, "ea14270e5247cec7afc3693c00273dffde99fc4c6da67730618e043be3d696fa")
