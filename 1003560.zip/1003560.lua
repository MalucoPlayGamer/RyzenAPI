-- Lua provided by RyzenAPI
-- Game: Crumbling World

-- MAIN APPLICATION
addappid(1003560)
-- Game: addappid(1003560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003561, 1, "aa1a73390da2d7494a0e6bd8f26a8dbc675ae4ce57344b5167d50a6bbb860c5c")
