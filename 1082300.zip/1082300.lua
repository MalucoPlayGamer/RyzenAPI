-- Lua provided by RyzenAPI
-- Game: HentaiNYA - Artbook 18+

-- MAIN APPLICATION
addappid(1082300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082300,0,"509775a4f3a77d67060c2931d7bd948da81a48de24085cb06992fe6a4c2d814d")

