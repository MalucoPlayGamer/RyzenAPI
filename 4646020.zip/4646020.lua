-- 4646020's Lua and Manifest Created by Hubcap Manifest
-- Crystal Breaker Inc
-- Created: August 21, 2026 at 22:56:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4646020) -- Crystal Breaker Inc
-- MAIN APP DEPOTS
addappid(4646021, 1, "23b8625096ad15f2de411a61211f370fb4334f22ab1a6d8696055fa582c633fd") -- Depot 4646021
setManifestid(4646021, "7976096321790122352", 165205698)