-- Lua provided by RyzenAPI
-- Game: Crystal Breaker Inc

-- MAIN APPLICATION
addappid(4646020) -- Crystal Breaker Inc

-- MAIN APP DEPOTS / PACKAGES
addappid(4646021, 1, "23b8625096ad15f2de411a61211f370fb4334f22ab1a6d8696055fa582c633fd") -- Depot 4646021

