-- Lua provided by RyzenAPI
-- Game: Zundamon DLC

-- MAIN APPLICATION
addappid(3533450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3533450,0,"9c3422e204117b9185c9474c97cfb09cc8f9dffd5bf40704c2747623474dea8f")
