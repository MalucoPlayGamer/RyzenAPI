-- Lua provided by RyzenAPI
-- Game: ROBOCOCK

-- MAIN APPLICATION
addappid(2319100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319101, 1, "03165c97a4ae822b634ba7042e9c06576ae1bdece63d29d34b7db1e5bf9665dd")

