-- Lua provided by RyzenAPI
-- Game: Pine Hearts - Soundtrack

-- MAIN APPLICATION
addappid(2996720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996721, 1, "f2542e025a0e6adde2c2820486c6e429512e01667023a9140a131449675ed23c")
