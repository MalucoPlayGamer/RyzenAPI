-- 704850's Lua and Manifest Created by Hubcap Manifest
-- Thief Simulator
-- Created: February 01, 2026 at 11:51:46 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(704850, 1, "feb0a17499266c95256522deb820d82bc0b2d7e028b864be8388eedea5df545b") -- Thief Simulator
-- MAIN APP DEPOTS
addappid(704851, 1, "c6eb71b65618938bcf35d976cdd952c08d6fc53d1617ec8a408d9e8aedf5fb6f") -- Thief Simulator Content
setManifestid(704851, "661864796988121626", 12229192714)
addappid(704852, 1, "7fdb57788d74395af527b98fb77483e1f82f93204f6dcd1d4ae5a424c4aa006b") -- Thief Simulator - MAC Content
setManifestid(704852, "6408742455698385061", 9475040620)
-- DLCS WITH DEDICATED DEPOTS
-- Thief Simulator - Luxury Houses DLC (AppID: 1840650)
addappid(1840650)
addappid(1840650, 1, "0c60b1aec120a0a8e452e02c449781b389f1fa7fa872611e338ad9a952c7bf1b") -- Thief Simulator - Luxury Houses DLC - Depot 1840650
setManifestid(1840650, "1723464614183593186", 32495503)
-- Thief Simulator - Shopping Center DLC (AppID: 2518240)
addappid(2518240)
addappid(2518242, 1, "e62e8d87295d6ae84bdaca81214762d03705ff7d09824166bf3edb48f923b455") -- Thief Simulator - Shopping Center DLC - Depot 2518242
setManifestid(2518242, "7350979375399521797", 15662840)