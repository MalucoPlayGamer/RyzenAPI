-- Lua provided by SkyAPI 
-- Game: Thief Simulator
addappid(704850)
addappid(704851, 1, "c6eb71b65618938bcf35d976cdd952c08d6fc53d1617ec8a408d9e8aedf5fb6f")
addappid(704852, 1, "7fdb57788d74395af527b98fb77483e1f82f93204f6dcd1d4ae5a424c4aa006b")
addappid(1840650, 0, "0c60b1aec120a0a8e452e02c449781b389f1fa7fa872611e338ad9a952c7bf1b")
addappid(2518241)
