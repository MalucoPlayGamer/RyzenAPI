-- Lua provided by RyzenAPI
-- Game: Game: Clown Art

-- MAIN APPLICATION
addappid(2605940)
-- Game: addappid(2605940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605941, 1, "16b0f34debb79cc07b12bcec72eaddb968dd6cc404d601fcc5d16d880d2cb503")
