-- Lua provided by RyzenAPI
-- Game: Clown Art

-- MAIN APPLICATION
addappid(2605940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605941, 1, "16b0f34debb79cc07b12bcec72eaddb968dd6cc404d601fcc5d16d880d2cb503")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
