-- Lua provided by RyzenAPI
-- Game: CastleStorm

-- MAIN APPLICATION
addappid(241410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(241411, 1, "0dfa2b721fa449dbc659eca2de4f6ea8396cb283c3875fe6850171492e45eb2b")
addappid(242300, 0, "375463188e2cc42eb00aaef425c0bee11ece720a4b16eddcf6ac62ab44c1f206")
addappid(242310, 0, "c13ea12608ec6b614a4d044bf7b7e81ca370fd48f3123782a391bc1423425058")

