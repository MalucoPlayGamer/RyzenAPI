-- Lua provided by SkyAPI 
-- Game: CastleStorm
addappid(241410)
addappid(241411, 1, "0dfa2b721fa449dbc659eca2de4f6ea8396cb283c3875fe6850171492e45eb2b")
addappid(242300, 0, "375463188e2cc42eb00aaef425c0bee11ece720a4b16eddcf6ac62ab44c1f206")
addappid(242310, 0, "c13ea12608ec6b614a4d044bf7b7e81ca370fd48f3123782a391bc1423425058")
