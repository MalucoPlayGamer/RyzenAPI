-- 1341200's Lua and Manifest Created by Hubcap Manifest
-- DYNASTY WARRIORS 9 Empires
-- Created: September 29, 2025 at 09:45:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 28
-- Total DLCs: 23

-- MAIN APPLICATION
addappid(1341200) -- DYNASTY WARRIORS 9 Empires
-- MAIN APP DEPOTS
addappid(1341201, 1, "16471bf6e58be188589aac1dd11eb096296673df4d29f3993d090cc1431519d6") -- Common Data
setManifestid(1341201, "5157163387854106011", 3032969625)
addappid(1341202, 1, "d61410ce1caabe3bbc5011d7cc96e14d88e062bc87857acf8b439b5d1d243689") -- Data
setManifestid(1341202, "7272130505787353016", 39144278885)
addappid(1341203, 1, "374f2b4f88f64d9cbdddd290d3115b2c7373ca0790d4d92e25b2ed88f9ee13e9") -- Debug Data
setManifestid(1341203, "488013393069121366", 0)
addappid(1341204, 1, "44e321f5a792cfe686871b1849a3fd083fe931ebb2d6ee6a523f8232c26cb11d") -- Patch Data
setManifestid(1341204, "784069065835941285", 412838873)
addappid(1341205, 1, "fd315cf51a5ad41ecdc5b74b6496d8f0c2da1c801376720234d42416db2fa963") -- Exe
setManifestid(1341205, "2118592303935587464", 40834592)
-- DLCS WITH DEDICATED DEPOTS
-- DYNASTY WARRIORS 9 Empires - Guard Gem (AppID: 1684140)
addappid(1684140)
addappid(1684140, 1, "b068bce1aaa88996e490e46d025b8ba2abfffda883194fd420bd29d98ac5d53d") -- DYNASTY WARRIORS 9 Empires - Guard Gem - Depot 1684140
setManifestid(1684140, "71081331251889636", 28672)
-- DYNASTY WARRIORS 9 Empires - Male Custom Zhao Yun Set (AppID: 1684141)
addappid(1684141)
addappid(1684141, 1, "0551990412beab556f0ff42eb386f35fd4c8a8c9e19f026569982c75151ef5ed") -- DYNASTY WARRIORS 9 Empires - Male Custom Zhao Yun Set - Depot 1684141
setManifestid(1684141, "740712035941065166", 41314064)
-- DYNASTY WARRIORS 9 Empires - ScenarioGemsAncient Officers Set (AppID: 1684146)
addappid(1684146)
addappid(1684146, 1, "a35edab071067a1334254f11cb24728310b017e95b4a6f7e538e386a56f61aa5") -- DYNASTY WARRIORS 9 Empires - ScenarioGemsAncient Officers Set - Depot 1684146
setManifestid(1684146, "4471808666624536138", 68638)
-- DYNASTY WARRIORS 9 Empires - Season Pass (AppID: 1684147)
addappid(1684147)
addappid(1684147, 1, "3d91ad83b987b5bd42171f7de021cfa804761da9bcf07e61e682137ac6076edf") -- DYNASTY WARRIORS 9 Empires - Season Pass - DW9E - Season Pass デポ
setManifestid(1684147, "1934230089911784454", 28672)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Azure Dragon Armor Set (AppID: 1684148)
addappid(1684148)
addappid(1684148, 1, "7bd8440b3fc203d0d0a95cbfc0ef5f4393706b4439a5533833200e83d3d8cc86") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Azure Dragon Armor Set - Depot 1684148
setManifestid(1684148, "2704947247232534313", 96353828)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom White Tiger Armor Set (AppID: 1684149)
addappid(1684149)
addappid(1684149, 1, "77aeba6f581723b36f199c2f84cf68952c6f03fa1e85b836d2206c2a8be06c05") -- DYNASTY WARRIORS 9 Empires - Unisex Custom White Tiger Armor Set - Depot 1684149
setManifestid(1684149, "5019674809272487440", 131617568)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Vermilion Bird Armor Set (AppID: 1684150)
addappid(1684150)
addappid(1684150, 1, "896f434cab6397085e36b894da023e274e25768d89e9e1e633474a532dc4525c") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Vermilion Bird Armor Set - Depot 1684150
setManifestid(1684150, "7195384988577941035", 125442464)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Black Tortoise Armor Set (AppID: 1684151)
addappid(1684151)
addappid(1684151, 1, "618ce65f30692b2ff60ce804ca968b771751b5d4f9ef25b41aa921215e3d16d4") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Black Tortoise Armor Set - Depot 1684151
setManifestid(1684151, "6161216771811411937", 210135712)
-- DYNASTY WARRIORS 9 Empires - Far Eastern Palace (AppID: 1684152)
addappid(1684152)
addappid(1684152, 1, "92c16da2b623c120f3a9c93160e7059da852f67ce5db9a2ab984b88a37828d50") -- DYNASTY WARRIORS 9 Empires - Far Eastern Palace - Depot 1684152
setManifestid(1684152, "3625644340358015404", 18770176)
-- DYNASTY WARRIORS 9 Empires - Panda Palace (AppID: 1684153)
addappid(1684153)
addappid(1684153, 1, "ca639473be1b1181a6b31c44377fc3d71ea79b14de1af33a163729919d77923a") -- DYNASTY WARRIORS 9 Empires - Panda Palace - Depot 1684153
setManifestid(1684153, "3483682469041801168", 43097472)
-- DYNASTY WARRIORS 9 Empires - School Gymnasium (AppID: 1684154)
addappid(1684154)
addappid(1684154, 1, "86d44e10729bb74a9c4ace48ffc4e3a3ef264e4867250f65b9f7f40deff8151e") -- DYNASTY WARRIORS 9 Empires - School Gymnasium - Depot 1684154
setManifestid(1684154, "1822420679340943520", 14435072)
-- DYNASTY WARRIORS 9 Empires - Male Custom Ogre God Set  Female Custom Fu Hao Set (AppID: 1684155)
addappid(1684155)
addappid(1684155, 1, "31b346ea8a3587edb6e690ca28efbf543d7f1514e1424c864572976a1df7a0c8") -- DYNASTY WARRIORS 9 Empires - Male Custom Ogre God Set  Female Custom Fu Hao Set - Depot 1684155
setManifestid(1684155, "4326837686875696728", 73293856)
-- DYNASTY WARRIORS 9 Empires - Male Custom Regal Set  Female Custom Empress Dowager Set (AppID: 1684156)
addappid(1684156)
addappid(1684156, 1, "8e5909b7951cdd480bfb8d85925209b365de23f35c03bf0a2a4ab2ea4b60429d") -- DYNASTY WARRIORS 9 Empires - Male Custom Regal Set  Female Custom Empress Dowager Set - Depot 1684156
setManifestid(1684156, "9163399095304818312", 105089312)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Cunning Concealment Set (AppID: 1684157)
addappid(1684157)
addappid(1684157, 1, "bd3c6ea9a13d4949afba2a00fabd26d22478d4a09c1230f001be3cc2df7c71d4") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Cunning Concealment Set - Depot 1684157
setManifestid(1684157, "6368232029379781999", 81816224)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Fox Costume Set (AppID: 1684158)
addappid(1684158)
addappid(1684158, 1, "3ce719c0b41398a4473087bec92b0d34d8394ec596ef4eb420c5050183c36754") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Fox Costume Set - Depot 1684158
setManifestid(1684158, "5586179178890254911", 86587296)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Panda Costume Set (AppID: 1684159)
addappid(1684159)
addappid(1684159, 1, "cb08a05bad2d7e52d1db7ccb8213879a03352e34a7aaa2e750b664ce64dc955e") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Panda Costume Set - Depot 1684159
setManifestid(1684159, "5658848661690133482", 83890208)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Angelic Armor Set (AppID: 1684160)
addappid(1684160)
addappid(1684160, 1, "cc8112668950e6262302475708bd2316bf864176da0f790e4db07614743299aa") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Angelic Armor Set - Depot 1684160
setManifestid(1684160, "5885241530944829549", 77169696)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Demonic Armor Set (AppID: 1684161)
addappid(1684161)
addappid(1684161, 1, "536477a24ea6eddceef359481f1a940d439ad58d3662fff6a0d410d7a592b020") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Demonic Armor Set - Depot 1684161
setManifestid(1684161, "6736819562576555552", 85751712)
-- DYNASTY WARRIORS 9 Empires - Dream Fortress (AppID: 1684162)
addappid(1684162)
addappid(1684162, 1, "7804af0a422c7f7ccba4d50c7c65391fd036860589b8ae6e88dee48ecc2f163b") -- DYNASTY WARRIORS 9 Empires - Dream Fortress - DW9E - Dream Fortress デポ
setManifestid(1684162, "851123269037469033", 28002816)
-- DYNASTY WARRIORS 9 Empires - Idol Stage (AppID: 1684163)
addappid(1684163)
addappid(1684163, 1, "9c66bca814e39417c5000bfe2a639e3fc8b6ec302a67894bce6f395cf93269d4") -- DYNASTY WARRIORS 9 Empires - Idol Stage - DW9E - Idol Stage デポ
setManifestid(1684163, "69672299256598932", 9693568)
-- DYNASTY WARRIORS 9 Empires - Male Custom Heretic Set  Female Custom Sage Set (AppID: 1684164)
addappid(1684164)
addappid(1684164, 1, "83253e1bd3bbd6959be5c0acf0b4b3c800c85b80bd73f5b902215b5042a4ecee") -- DYNASTY WARRIORS 9 Empires - Male Custom Heretic Set  Female Custom Sage Set - Depot 1684164
setManifestid(1684164, "6706002190708121271", 45479456)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Steel Set (AppID: 1684165)
addappid(1684165)
addappid(1684165, 1, "1b15bb541afd0cdf76517bc02dbcf146a954f1da30f1a788cc5ba9c54e93504e") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Steel Set - Depot 1684165
setManifestid(1684165, "2107383543354544572", 96032032)
-- DYNASTY WARRIORS 9 Empires - Unisex Custom Dragoon Set (AppID: 1684166)
addappid(1684166)
addappid(1684166, 1, "adea8679f808d42def2075a1cf51944d15f7cb033e8fc2fcad55a74c092bdf1a") -- DYNASTY WARRIORS 9 Empires - Unisex Custom Dragoon Set - Depot 1684166
setManifestid(1684166, "811718815434976616", 104690592)