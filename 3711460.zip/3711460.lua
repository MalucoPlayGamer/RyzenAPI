-- Lua provided by RyzenAPI
-- Game: Paranormal Tape: KARAK

-- MAIN APPLICATION
addappid(3711460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3711461, 1, "e5dbc89913ec646384aa4854289700af176763562cf9ca40c90409f501d453d0")

