-- Lua provided by RyzenAPI
-- Game: Clam Man

-- MAIN APPLICATION
addappid(1000640)
-- Game: addappid(1000640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000641, 1, "424eac506aaf7113a483d9f195b2b2de62b20530fedd2cb224d47f72635b5d8e")
