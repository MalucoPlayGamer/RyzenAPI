-- Lua provided by RyzenAPI
-- Game: Microlandia

-- MAIN APP DEPOTS / PACKAGES
addappid(4094120, 1, "d25ede63a014afa29b8f01e5ba2e3422e3f7b6b2c1d041b44e3249d476f5041b") -- Microlandia
addappid(4094121, 1, "34b6ff5ff36d9fcb10c5576f22e7fe35e4a603237ea87e82a4b7725f40038de0") -- Depot 4094121
addappid(4094123, 1, "c6120a7610c9aa76eccdfc87be4961e21abc84b86bd8a81539e665f96192b999") -- Depot 4094123

