-- Lua provided by RyzenAPI
-- Game: 1878070

-- MAIN APPLICATION
addappid(1878070)
-- Game: addappid(1878070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878071, 1, "db350046eb3aa8cbbbe63eac765d4bba186ef37b94d61d86c9f9444a9d86bfda")
