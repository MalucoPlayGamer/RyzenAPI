-- Lua provided by RyzenAPI
-- Game: Samurai of Hyuga Book 4

-- MAIN APPLICATION
addappid(1132100)
addappid(1132150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132101, 1, "647696f0baf094eb39d55ec7142fbb57561141953828ac77e3a241c9b13c9ba7")

