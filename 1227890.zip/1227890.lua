-- Lua provided by RyzenAPI
-- Game: Game: Summer Memories

-- MAIN APPLICATION
addappid(1227890)
addappid(1390150)
-- Game: addappid(1227890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227891, 1, "2e2a6b921fea7098aab8c03d4a70aca9e6fae899b964523f7facd4756ab77567")
addappid(1227892, 1, "d44403a5f1de2fc5dfa7d8b11f80764f066518f373c1740f71453b796343688d")
addappid(1227893, 1, "ece222869909275dbc208a0825925b4b79126b1c16980f4852ac7e0e423221ba")
