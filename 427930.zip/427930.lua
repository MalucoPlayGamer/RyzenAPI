-- Lua provided by RyzenAPI
-- Game: Army of Tentacles: (Not) A Cthulhu Dating Sim

-- MAIN APPLICATION
addappid(427930)

-- MAIN APP DEPOTS / PACKAGES
addappid(427932,0,"c27ee6dc8d0a38ccadfb8647786b424f0ed2b9616e9e6e6f38a1231401079d1c")
addappid(427934,0,"e7b22c2e4498f1936fd4145a0d19294cfc5b27729e858a655be189d9cac682fc")
addappid(428711,0,"a20f0fe18122493ceb986e54f80f407820bda33a5d7ef8ade45c311074818802")
addappid(428712,0,"ab160637b9ce3634a9f016eace2df0fcd9a17f14ac94050731bda845f5d1c74e")
addappid(428713,0,"37a759b1d20bcb1bf3ece6f9d50701521ef060b9f8c45b93e28a0e16e1b730f0")
addappid(428717,0,"a107b2376fd2c854fed9c7dbc05ded8045b0c3907855ed524cf54b83d8bb6759")
addappid(428718,0,"634a60eb276e4ed47471a9830b238fe874abb461edcb0522c2e752e15c258d96")
addappid(456880,0,"a0e33a1f9c1a3489e780b66b98953aa0c1a42531ce7a08238d77eaa2adbe168c")
addappid(476561,0,"126d6719c88c4c23d386dfce0248d0f11ec8b559dd25eb5e1016a6180819993c")
addappid(476570,0,"536b79e9b9f700437d03a772de7e89599fe8109c191c0d816a76f1a7c88c66eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(428710)
addappid(459590)
addappid(476560)
addappid(531750)
addappid(710730)
addappid(780240)
