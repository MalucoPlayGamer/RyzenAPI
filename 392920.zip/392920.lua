-- Lua provided by RyzenAPI
-- Game: addappid(392920)

-- MAIN APPLICATION
addappid(392920)
addappid(425370)
addappid(526970)

-- MAIN APP DEPOTS / PACKAGES
addappid(392921, 1, "6a8e2e75ddd7b4a67c1336b666bb83f9a52cb939090e20137d3c3cedf2ddbede")
