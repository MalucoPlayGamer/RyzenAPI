-- Lua provided by RyzenAPI 
-- Game: The Golden Rose: Book One
addappid(1892950)
addappid(1892951, 1, "786e9266c27f685f3aa9e21f19547c03ff87775be5f1c3cfd47f710a7b3660f4")
