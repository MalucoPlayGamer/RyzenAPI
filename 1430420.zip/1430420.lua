-- Lua provided by RyzenAPI
-- Game: Game: CBT With Yuuka Kazami

-- MAIN APPLICATION
addappid(1430420)
-- Game: addappid(1430420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430421, 1, "6c251aa12cc29fc807b35b1dc3a3e0579b272ba4c7db25fbee8e29d61d2809f4")
addappid(1430422, 1, "cdb2082c32901faa8ef97c89454484a5c7e36d31de36570e93d93d4ff5844350")
addappid(1430423, 1, "5951eee3a7e97d008914ec6d9cffa8667e274e45339e9713f8ccca569b767ac7")
addappid(1518670, 0, "10f9aaf322cb54e71968450f17778d21d5c6c4da410ab279e3d81357b78f51cf")
