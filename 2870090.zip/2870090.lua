-- Lua provided by RyzenAPI
-- Game: The Axis Unseen Soundtrack

-- MAIN APPLICATION
addappid(2870090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870091, 1, "99e038ab105e826ce2743ecf5ff7a79b7c90176311b64bf4431988b51848e017")
