-- Lua provided by RyzenAPI
-- Game: Game: Morph Girl

-- MAIN APPLICATION
addappid(688260)
-- Game: addappid(688260)

-- MAIN APP DEPOTS / PACKAGES
addappid(688261, 1, "c68b85ff2128b553e22bf92cd104153323e07d152d0613056fc567310556a73d")
