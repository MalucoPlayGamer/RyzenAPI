-- Lua provided by SkyAPI 
-- Game: Morph Girl
addappid(688260)
addappid(688261, 1, "c68b85ff2128b553e22bf92cd104153323e07d152d0613056fc567310556a73d")
