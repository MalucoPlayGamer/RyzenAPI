-- Lua provided by RyzenAPI
-- Game: 1162520

-- MAIN APPLICATION
addappid(1162520)
-- Game: addappid(1162520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162521, 1, "e12a340b6f2b14bf01b6bfeb11833e599899d6c38ecde717e1697530afb7b368")
addappid(1162522, 1, "76aa1c3483fdefb3e385dffb170dba15b80b2384f304d670013b893f4ef9ae7e")
