-- Lua provided by RyzenAPI
-- Game: Taxi Simulator in City

-- MAIN APPLICATION
addappid(2568860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568861, 1, "c35ffc24012e50183cfd80c9e17a906e07ff5ed30dabb7d89043383d0705f1d1")
