-- Lua provided by SkyAPI 
-- Game: AppID 3169140
addappid(3169140)
addappid(3169141, 1, "966dd5db779b33da0d073935e78016f81961bb77ba4a9e1b07e1d9282c2880f0")
