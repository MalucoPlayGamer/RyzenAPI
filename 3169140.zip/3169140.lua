-- Lua provided by RyzenAPI
-- Game: Bad 2 Bad: Apocalypse Demo

-- MAIN APPLICATION
addappid(3169140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169141, 1, "966dd5db779b33da0d073935e78016f81961bb77ba4a9e1b07e1d9282c2880f0")
