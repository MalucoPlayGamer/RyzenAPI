-- Lua provided by RyzenAPI
-- Game: Cherry Kisses

-- MAIN APPLICATION
addappid(1259530)
-- Game: addappid(1259530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259532,0,"9c98a7d9d78b9a2945bf503f75df2d878902171f49240876c1253a18ca300573")
