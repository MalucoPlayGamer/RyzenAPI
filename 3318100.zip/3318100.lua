-- Lua provided by RyzenAPI
-- Game: Pinchimono: The videogame

-- MAIN APPLICATION
addappid(3318100)
-- Game: addappid(3318100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318101, 1, "6ccca4d7a437d3ad5989c3fdbf55e6250169939f914b43338b3fa6cb1a6b12f7")
