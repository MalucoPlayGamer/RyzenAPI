-- Lua provided by RyzenAPI 
-- Game: Pinchimono: The videogame
addappid(3318100)
addappid(3318101, 1, "6ccca4d7a437d3ad5989c3fdbf55e6250169939f914b43338b3fa6cb1a6b12f7")
