-- Lua provided by RyzenAPI
-- Game: 2289450

-- MAIN APPLICATION
addappid(2289450)
-- Game: addappid(2289450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289451, 1, "a1a83669f59951926c19f06c78ddfcf04332b6d86f1d66a166edf88be35db7a8")
addappid(2289452, 1, "2cb860927fed1e79438b627b015df50d1b3bfbfffc29a1f2bfa0139c969e70b6")
addappid(2289453, 1, "f4cb677c7d93cc4ff4a8d2a2601deceb7dda2c5d142ec8bde93857f8d7560eaa")
