-- Lua provided by RyzenAPI 
-- Game: Travellers Rest Soundtrack
addappid(1371830)
addappid(1371831, 1, "9844ede6bf8868e566aa289bb16529436f690fe5c07622594c81db963dfd67fe")
