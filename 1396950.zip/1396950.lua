-- Lua provided by RyzenAPI
-- Game: addappid(1396950)

-- MAIN APPLICATION
addappid(1396950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396951, 1, "c0acef08880a564650c7414d141018380fabd983e53d10020cedd7e8acc5b9a3")
