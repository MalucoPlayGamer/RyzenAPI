-- Lua provided by RyzenAPI
-- Game: CONNECTED!

-- MAIN APPLICATION
addappid(1625370)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1625371, 1, "36a44bb40bd40f002e78c6c750aae495ba61f5150ba23f2002f1dca2c5acb7d6")

