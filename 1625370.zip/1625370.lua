-- Lua provided by RyzenAPI
-- Game: CONNECTED!

-- MAIN APPLICATION
addappid(1625370)
-- Game: addappid(1625370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625371, 1, "36a44bb40bd40f002e78c6c750aae495ba61f5150ba23f2002f1dca2c5acb7d6")
