-- Lua provided by RyzenAPI 
-- Game: Chaos Party
addappid(1295420)
addappid(1295421, 1, "b3fc20446348fbd704bbe2d4d69bd2b73da8d09f95b98b6ac4799a6a2c7cd74f")
