-- Lua provided by RyzenAPI
-- Game: Playtime with Hoogie

-- MAIN APPLICATION
addappid(1908730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908732,0,"9573f63a965dd4269a778ecfe72cc3d2d684279323e83335a5c7fec6a248b314")
