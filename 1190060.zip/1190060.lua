-- Lua provided by RyzenAPI
-- Game: setManifestid(1190062,"508557387489659957")

-- MAIN APPLICATION
addappid(1190060)
-- Game: addappid(1190060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190062,0,"079603549ffc99e6eff77a7f4ddd814fb4f507dd69e6b67a9b46f5b905110074")
