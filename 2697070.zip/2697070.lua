-- Lua provided by RyzenAPI 
-- Game: Circus of TimTim - Mascot Horror Game
addappid(2697070)
addappid(2697071, 1, "1ce54e9d59713306e998d265a3131ddb7482ca2712baa1da62b21ab66f650f37")
