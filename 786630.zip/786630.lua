-- Lua provided by RyzenAPI
-- Game: MY 1980's DASHBOARD

-- MAIN APPLICATION
addappid(786630)
-- Game: addappid(786630)

-- MAIN APP DEPOTS / PACKAGES
addappid(786631, 1, "8dcbe3e9225abf5ff78d23e1fcfeb9551b4d92acb5315cddfae55537c00bc1d8")
