-- Lua provided by RyzenAPI
-- Game: Game: Lovecraft Locker: Tentacle Hell

-- MAIN APPLICATION
addappid(2778200)
-- Game: addappid(2778200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778201, 1, "77c39db667a1062e2f0dfa1d0e3f257e19b2d729ee795582d6d2035887fe4942")
