-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - Retro Game Console Sound BGM Set

-- MAIN APPLICATION
addappid(1724740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724740,0,"a4cc30cf47e998c6dd3bf31abd59c36d81e159a2fecb9b5a3d60669f09e1f375")

