-- Lua provided by RyzenAPI
-- Game: 1150720

-- MAIN APPLICATION
addappid(1150720)
-- Game: addappid(1150720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150721, 1, "f80c2675cffac28f72d1d906376ad5bd7fde4fb3d4c3b7bbb730425891b64068")
