-- Lua provided by RyzenAPI
-- Game: Dino Path Trail

-- MAIN APPLICATION
addappid(2481670)
addappid(3717410)
addappid(3717480)
-- Game: addappid(2481670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481671, 1, "2b9abb97c4d699ea90a6bbce12125533155940f97c0ba1dc3c65526cd4c44760")
