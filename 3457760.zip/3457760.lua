-- Lua provided by RyzenAPI
-- Game: 3457760

-- MAIN APPLICATION
addappid(3457760)
-- Game: addappid(3457760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3457761, 1, "84aa8b08d81ade9f0cd00e299660fbcc7d357fead158b5c807d08138eec0c24c")
