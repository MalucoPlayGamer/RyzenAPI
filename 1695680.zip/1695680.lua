-- Lua provided by RyzenAPI
-- Game: Lunar's Chosen - Episode 1

-- MAIN APPLICATION
addappid(1695680)
addappid(2202210)
-- Game: addappid(1695680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695681, 1, "bb449648212dd932489306754deb9f1941f385770814efe345c8fa05c872e181")
addappid(1820311, 0, "97c5e40b834efcb751e322cdabc38028462e55e88ce016f8cc15bbc4811e3f00")
