-- Lua provided by RyzenAPI
-- Game: 2659950

-- MAIN APPLICATION
addappid(2659950)
-- Game: addappid(2659950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659951, 1, "1d7b7809eec1c3dea2c27ab0a5d08a512b91841593dbda1e1c14c6490a805439")
