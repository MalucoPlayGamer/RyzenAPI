-- Lua provided by RyzenAPI
-- Game: Dodge It!

-- MAIN APPLICATION
addappid(1720050)
addappid(1720250)
addappid(1722880)
addappid(1724200)
addappid(1735380)
addappid(1735381)
addappid(1744600)
addappid(1744601)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1720051, 1, "03f53822bf3985f132405dbae9637f3d521a81ddc127fa10b17f368437caf8e1")

