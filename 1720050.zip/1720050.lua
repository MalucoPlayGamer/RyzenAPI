-- Lua provided by RyzenAPI
-- Game: Dodge It!

-- MAIN APPLICATION
addappid(1720050)
-- Game: addappid(1720050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720051, 1, "03f53822bf3985f132405dbae9637f3d521a81ddc127fa10b17f368437caf8e1")
