-- Lua provided by RyzenAPI
-- Game: Chris Sawyer's Locomotion

-- MAIN APPLICATION
addappid(356430)

-- MAIN APP DEPOTS / PACKAGES
addappid(356431, 1, "063e180b552129b1b449899e013332069128b5f822d9f7456e69ce06512efc6f")

