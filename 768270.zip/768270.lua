-- Lua provided by RyzenAPI
-- Game: Lisssn

-- MAIN APPLICATION
addappid(768270)

-- MAIN APP DEPOTS / PACKAGES
addappid(768272,0,"60dfa559a4b0faac91f4d0d6b67b22b93407fb98c38052410c4c803bababcb12")

