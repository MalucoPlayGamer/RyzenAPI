-- Lua provided by RyzenAPI
-- Game: Game: AppID 398170

-- MAIN APPLICATION
addappid(398170)
-- Game: addappid(398170)

-- MAIN APP DEPOTS / PACKAGES
addappid(398171, 1, "a7049f0c044d46c74c90c119a5cae418cb0f0c76a3fdccbc4e0066158f41d7b3")
