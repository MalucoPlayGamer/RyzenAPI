-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Japanese Four Seasons Tree Tiles

-- MAIN APPLICATION
addappid(1823530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823530,0,"842f4839f10539c5d6ee8137e9abcaf31791c9e34e454356e0277a9e38b5621a")
