-- Lua provided by RyzenAPI
-- Game: addappid(3665120)

-- MAIN APPLICATION
addappid(3665120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3665121, 1, "f7cd1cf6778d51e67a4c335d63a221fbff035966cb965d76beabe57c796554f8")
