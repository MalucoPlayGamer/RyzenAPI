-- Lua provided by RyzenAPI
-- Game: Super Dungeon Master Ace RPG

-- MAIN APPLICATION
addappid(717190)
addappid(808760)
-- Game: addappid(717190)

-- MAIN APP DEPOTS / PACKAGES
addappid(717191, 1, "4a6c950b7eb46ed9784506aa4ad1171ef5d8a4c5b03926f1ec24a91177653b46")
