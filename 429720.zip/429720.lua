-- Lua provided by RyzenAPI
-- Game: addappid(429720)

-- MAIN APPLICATION
addappid(429720)

-- MAIN APP DEPOTS / PACKAGES
addappid(429721, 1, "4f11e4e149d0acd7bd461776f5193219a550cec244ca09897de5a154970011cc")
