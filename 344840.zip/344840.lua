-- Lua provided by RyzenAPI 
-- Game: Gratuitous Space Battles 2
addappid(344840)
addappid(344841, 1, "32d655cd8170c77ae2fce631746a1e1c0ab5dc3dc75482190d8b65bf44e86182")
