-- Lua provided by RyzenAPI 
-- Game: Weekend Warriors MMA
addappid(2289130)
addappid(2289131, 1, "ed096ce169201a38363d67f88f402a98098eec48bae95db7385985d05aa556e1")
