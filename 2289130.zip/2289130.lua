-- Lua provided by RyzenAPI
-- Game: Weekend Warriors MMA

-- MAIN APPLICATION
addappid(2289130)
-- Game: addappid(2289130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289131, 1, "ed096ce169201a38363d67f88f402a98098eec48bae95db7385985d05aa556e1")
