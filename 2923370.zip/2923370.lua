-- Lua provided by RyzenAPI
-- Game: Game: AppID 2923370

-- MAIN APPLICATION
addappid(2923370)
-- Game: addappid(2923370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923371, 1, "2f811f89a8842339d55af6b469213db7fc510f63bd150aff663c5daef88d7cb1")
