-- Lua provided by RyzenAPI
-- Game: Key To Heaven

-- MAIN APPLICATION
addappid(1347630)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1347631, 1, "22ce6a6183b061c2cc87d255e06b87c9cc223c8ca79b497f633553cf0335a8fd")
