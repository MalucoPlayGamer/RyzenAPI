-- Lua provided by RyzenAPI 
-- Game: AppID 1347630
addappid(1347630)
addappid(1347631, 1, "22ce6a6183b061c2cc87d255e06b87c9cc223c8ca79b497f633553cf0335a8fd")
