-- Lua provided by RyzenAPI
-- Game: AppID 445420

-- MAIN APPLICATION
addappid(445420)
-- Game: addappid(445420)

-- MAIN APP DEPOTS / PACKAGES
addappid(445421, 1, "1670978f8645f602c4c3f3811c0eb14ecf3a091e2cff0b7eca82f375dc85642d")
addappid(465320, 0, "92ce54986ed25604d864df71acdc7a53020a7a647754cac67761d93bd0fc73d7")
