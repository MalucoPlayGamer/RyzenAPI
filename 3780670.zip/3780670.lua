-- Lua provided by RyzenAPI
-- Game: 3780670

-- MAIN APPLICATION
addappid(3780670)
-- Game: addappid(3780670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3780671, 1, "2a16fbc9fcdc2b7b9070a75c785401d3d2c93f751ac3c16a2fb1c649d67a0ad1")
