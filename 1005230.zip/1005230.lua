-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles Musical

-- MAIN APPLICATION
addappid(1005230)
addappid(1603030)
addappid(1603034)
addappid(1603038)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005231, 1, "c118c7f8752f3e4917309809cf8702dd1c75648a4b6d76d540d50c6b38f82230")

