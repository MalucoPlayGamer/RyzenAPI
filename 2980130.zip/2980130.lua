-- Lua provided by RyzenAPI
-- Game: addappid(2980130)

-- MAIN APPLICATION
addappid(2980130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980131, 1, "3ccc15eec8a1a7f7dbd9b3cd183c0f44397b07cb310912fbef4895b2cd33fc3e")
