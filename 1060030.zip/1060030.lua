-- Lua provided by RyzenAPI
-- Game: D.H.Trouble Guy

-- MAIN APPLICATION
addappid(1060030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060031, 1, "003d18a1bcaf6d3dcf9af9c6884e36ccc446001b97ecedca436d55a98746af43")

