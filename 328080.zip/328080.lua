-- Lua provided by SkyAPI 
-- Game: AppID 328080
addappid(328080)
addappid(328081, 1, "fb8627d205b681c7a57a0399b0c018290c2a0cb8b6e269dd3c0f8434856123d8")
