-- Lua provided by RyzenAPI
-- Game: GreenIsland

-- MAIN APPLICATION
addappid(2405390)
addappid(2405410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405391, 1, "b04bb2234581dc062b24b7a6ac2d82925e47dbdb06b7865fa5adc0f245d4499a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
