-- Lua provided by RyzenAPI
-- Game: addappid(2405390)

-- MAIN APPLICATION
addappid(2405390)
addappid(2405410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405391, 1, "b04bb2234581dc062b24b7a6ac2d82925e47dbdb06b7865fa5adc0f245d4499a")
