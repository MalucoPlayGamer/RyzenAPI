-- Lua provided by RyzenAPI
-- Game: Game: Newton Coin Web3

-- MAIN APPLICATION
addappid(3569590)
-- Game: addappid(3569590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569591, 1, "7ded0567c70d0be9637471f185854281a411215953c5cbe37191017e83704284")
