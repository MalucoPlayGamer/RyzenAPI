-- 4433730's Lua and Manifest Created by Hubcap Manifest
-- DEBRISVERSE
-- Created: August 02, 2026 at 09:43:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4433730, 1, "8892b5db7ea1a86a07828c183ae25162621b872c60b8cf3c8ebf3b427d7ddee1") -- DEBRISVERSE
-- MAIN APP DEPOTS
addappid(4433731, 1, "e4af24939074e691153d75f9a6ecceef9e90e25045a399cfcd0452776660bbfa") -- Depot 4433731
setManifestid(4433731, "7836841942883711666", 235191338)