-- Lua provided by RyzenAPI
-- Game: The Way Home: Pixel Roguelike

-- MAIN APPLICATION
addappid(2061300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061301,0,"184e1dedca9051ea9a596f537c93d56dda8e5ebde778741fab49756eedaaa0ca")
addappid(2061302,0,"09eed321d098097ce8a024b73a45582d6ee9b3335ba3fbfdc180d483b45575a4")

