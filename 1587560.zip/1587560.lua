-- Lua provided by RyzenAPI
-- Game: addappid(1587560)

-- MAIN APPLICATION
addappid(1587560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587561, 1, "5e0446a6545bfa39086156acaa07e0f801ea8e354c198dbea4092676bc9bfde1")
