-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Bad Liar"

-- MAIN APPLICATION
addappid(1099560)
-- Game: addappid(1099560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099560,0,"096a63ed30b5fd67b4d7de07131b3bcaa7ae5fea208486ee80f126f83fa4c9b1")
