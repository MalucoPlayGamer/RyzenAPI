-- Lua provided by RyzenAPI
-- Game: AppID 512160

-- MAIN APPLICATION
addappid(512160)
-- Game: addappid(512160)

-- MAIN APP DEPOTS / PACKAGES
addappid(512161, 1, "f8fdbced48f3b148bb20b765f58c27b53f58e0eb3006b0513ba35a02f30d3223")
addappid(512162, 1, "1708f065eb285c946a0b2df92a8c3ba3210475dfd217e7036bad6e574f0d9804")
