-- Lua provided by RyzenAPI
-- Game: Game: Watch Your Plastic Duck

-- MAIN APPLICATION
addappid(2088360)
-- Game: addappid(2088360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088361, 1, "e6dde8712e3be5bcb42517eb138fbaf8b556821b8a756eb695a38fa9ca370cae")
