-- Lua provided by RyzenAPI
-- Game: NTE: Neverness to Everness

-- MAIN APPLICATION
addappid(4508340)
addappid(4869730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4508341,0,"08a13e474db2e35584a634cdc868d2047fdddfa51346361442f6e904538912d8")

