-- Lua provided by RyzenAPI
-- Game: The RPG Engine

-- MAIN APPLICATION
addappid(1818180)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1929680)
addappid(1929681)
addappid(2567330)
