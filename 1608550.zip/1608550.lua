-- Lua provided by RyzenAPI
-- Game: Firegirl: Hack 'n Splash Rescue DX

-- MAIN APPLICATION
addappid(1608550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608551, 1, "718c201eb5dd3c8869f44326333cdfdf5a5ded26e81e6ef9d255e24926b3711e")
