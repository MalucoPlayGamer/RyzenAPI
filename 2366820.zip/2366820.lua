-- Lua provided by RyzenAPI
-- Game: Game: The Darkest Paths: The House - DEMO

-- MAIN APPLICATION
addappid(2366820)
-- Game: addappid(2366820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366821, 1, "c96ba2d4351f7b21809504998beb4061ab030f52d99a8ec2e91718f532e77d67")
