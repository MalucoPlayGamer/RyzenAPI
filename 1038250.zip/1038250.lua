-- Lua provided by RyzenAPI
-- Game: DIRT 5

-- MAIN APPLICATION
addappid(1038250)
addappid(1363540)
addappid(1363591)
addappid(1379260)
addappid(1379261)
addappid(1469470)
addappid(1469471)
addappid(1516260)
addappid(1517270)
addappid(1633610)
addappid(1690420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038251,0,"43d22ea77f4f8585fe8af24877fe8922406632b6508c6adf08509fdae67d2e62")
addappid(1038252,0,"8373feec31992e456a798b03476b51d4ebdb5b673a5405323ecfb1ea4dd777f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
