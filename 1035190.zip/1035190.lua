-- Lua provided by RyzenAPI
-- Game: AppID 1035190

-- MAIN APPLICATION
addappid(1035190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035191, 1, "c8e184724efc5edcd7b8debcb06718a6b5f870e8c32d21f7f2d7502cff3d1c57")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
