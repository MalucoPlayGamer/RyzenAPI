-- Lua provided by RyzenAPI
-- Game: AppID 1035190

-- MAIN APPLICATION
addappid(1035190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035191, 1, "c8e184724efc5edcd7b8debcb06718a6b5f870e8c32d21f7f2d7502cff3d1c57")
