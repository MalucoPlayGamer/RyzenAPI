-- Lua provided by RyzenAPI
-- Game: NEEDY STREAMER OVERLOAD Soundtrack

-- MAIN APPLICATION
addappid(1645220)
-- Game: addappid(1645220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645221, 1, "ad76cf7b57f451da68b1bc71859bdf42c6f448dd97484ceaae78ba72e27323b1")
addappid(1645222, 1, "555f40fba244f85a9d7b63c4412d3893de71bcc86109ee364da82f80fd3a4f6f")
