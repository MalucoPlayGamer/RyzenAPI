-- Lua provided by SkyAPI 
-- Game: Rewrite Original Soundtrack
addappid(1856580)
addappid(1856581, 1, "e8746ec72837595d89fc8a9911ed7336d449b87e4d81a8e41b2146c1247dab45")
addappid(1856587, 1, "21ff6598000e22388b9300292f4e4d00c4e792a61ce3fc7d30f009cc0632fb5b")
