-- Lua provided by RyzenAPI
-- Game: 天命三国

-- MAIN APPLICATION
addappid(2887700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887701, 1, "2963dd9c5f91bcf4c8eeb63ec6d32a2d3b8804a9ec09bf2ebe862e28087d91c3")

