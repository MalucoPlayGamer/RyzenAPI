-- Lua provided by RyzenAPI
-- Game: AppID 320850

-- MAIN APPLICATION
addappid(320850)
-- Game: addappid(320850)

-- MAIN APP DEPOTS / PACKAGES
addappid(320851, 1, "98ab0e9818e670434c6bc240450b4ed8304872cb6f328c2de05ffc2eec0f89b0")
