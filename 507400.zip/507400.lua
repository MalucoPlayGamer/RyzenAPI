-- Lua provided by RyzenAPI
-- Game: 507400

-- MAIN APPLICATION
addappid(507400)
-- Game: addappid(507400)

-- MAIN APP DEPOTS / PACKAGES
addappid(507401, 1, "f7b99ce5cc65f38adbb6860d7e5ac663cb3fb73cedd9deea0902095574dd1cb8")
