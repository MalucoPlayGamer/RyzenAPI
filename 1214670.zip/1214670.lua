-- Lua provided by RyzenAPI
-- Game: Game: AppID 1214670

-- MAIN APPLICATION
addappid(1214670)
-- Game: addappid(1214670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214671, 1, "498ad79758ee81a3600410c0e22d4bb10d4ac0a1f655e8fa5d3f3ac6d6e71f68")
addappid(1214672, 1, "028bb75b40754a2a0b5ef851347b5de529f909a262645ef05a354bc1b4201d0c")
