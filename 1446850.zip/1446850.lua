-- Lua provided by RyzenAPI
-- Game: Game: Hentai Furry 2

-- MAIN APPLICATION
addappid(1446850)
-- Game: addappid(1446850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446851, 1, "ebcf6ad086621065450e97c75d8564838dad10a2ff74776905fbf5e8f081c0bb")
