-- Lua provided by RyzenAPI
-- Game: SurrealVR

-- MAIN APPLICATION
addappid(461180)

-- MAIN APP DEPOTS / PACKAGES
addappid(461181, 1, "86018676ccaf65d3fcbb7e5977529cd112928b271bdacdd6e25f0663e09116d4")
