-- Lua provided by RyzenAPI
-- Game: Golf Guys

-- MAIN APPLICATION
addappid(2751350) -- Golf Guys
addappid(2813390)
addappid(2813400)
addappid(2813410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751351, 1, "9323bb94c459555a610816a1eea4df0a35156d49053cee3833bb835cf23325bb") -- Depot 2751351
addappid(2813390, 1, "942c2f8ec2d2b8fb352d8114928c566fa6ca16d977c88a7245432fbc8c0bbe49") -- Golf Guys Fantasy DLC - Depot 2813390
addappid(2813400, 1, "17fad3e6c6191d94681fbbf2dd3e5ed1f3bb63bad8c088a25a37ccf01ffb3210") -- Golf Guys Party DLC - Depot 2813400
addappid(2813410, 1, "dde46dddbf62b709d161f600963ca901f1af6370843a9eb5e736d4ac0757e447") -- Golf Guys Space DLC - Depot 2813410

