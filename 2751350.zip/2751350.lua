-- Lua provided by RyzenAPI
-- Game: Golf Guys

-- MAIN APPLICATION
addappid(2751350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751351, 1, "9323bb94c459555a610816a1eea4df0a35156d49053cee3833bb835cf23325bb")
