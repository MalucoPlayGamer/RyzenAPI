-- 2751350's Lua and Manifest Created by Hubcap Manifest
-- Golf Guys
-- Created: July 03, 2026 at 12:56:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(2751350) -- Golf Guys
-- MAIN APP DEPOTS
addappid(2751351, 1, "9323bb94c459555a610816a1eea4df0a35156d49053cee3833bb835cf23325bb") -- Depot 2751351
setManifestid(2751351, "3335361995774969743", 389221570)
-- DLCS WITH DEDICATED DEPOTS
-- Golf Guys Fantasy DLC (AppID: 2813390)
addappid(2813390)
addappid(2813390, 1, "942c2f8ec2d2b8fb352d8114928c566fa6ca16d977c88a7245432fbc8c0bbe49") -- Golf Guys Fantasy DLC - Depot 2813390
setManifestid(2813390, "4546256168452144259", 0)
-- Golf Guys Party DLC (AppID: 2813400)
addappid(2813400)
addappid(2813400, 1, "17fad3e6c6191d94681fbbf2dd3e5ed1f3bb63bad8c088a25a37ccf01ffb3210") -- Golf Guys Party DLC - Depot 2813400
setManifestid(2813400, "4369581866898366410", 0)
-- Golf Guys Space DLC (AppID: 2813410)
addappid(2813410)
addappid(2813410, 1, "dde46dddbf62b709d161f600963ca901f1af6370843a9eb5e736d4ac0757e447") -- Golf Guys Space DLC - Depot 2813410
setManifestid(2813410, "3229962487133180841", 0)