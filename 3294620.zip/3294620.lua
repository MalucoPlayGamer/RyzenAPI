-- Lua provided by RyzenAPI
-- Game: Last Sighting

-- MAIN APPLICATION
addappid(3294620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294621, 1, "6826c68479ea6d6b514992b43c084510036451c89f5e0e560147aa404118eaba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
