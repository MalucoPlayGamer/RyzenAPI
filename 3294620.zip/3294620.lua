-- Lua provided by RyzenAPI
-- Game: Game: Last Sighting

-- MAIN APPLICATION
addappid(3294620)
-- Game: addappid(3294620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294621, 1, "6826c68479ea6d6b514992b43c084510036451c89f5e0e560147aa404118eaba")
