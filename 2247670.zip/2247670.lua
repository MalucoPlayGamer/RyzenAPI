-- Lua provided by RyzenAPI
-- Game: Hide and Seek

-- MAIN APPLICATION
addappid(2247670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247671, 1, "5fb8267fec8151a52984fea2ec53f44494174a6ff593fca8db5e51467892d3eb")
