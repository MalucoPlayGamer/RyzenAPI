-- Lua provided by RyzenAPI
-- Game: Game: Dumpy and Bumpy

-- MAIN APPLICATION
addappid(1631500)
-- Game: addappid(1631500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631501, 1, "59065512d0ba04f4d8d18348b6c3bc3955e848ab49da6a57752bc6731f4c0be9")
