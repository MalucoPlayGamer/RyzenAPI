-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2314650)
addappid(2314651)
addappid(2314652)
addappid(2314653)
addappid(2314654)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314655,0,"91e65c3ff570fac34f58ace1b22a49dd3017d819e9a51f3c73543ff90ed0566c")

