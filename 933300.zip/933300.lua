-- Lua provided by RyzenAPI
-- Game: 御俠客 Wuxia Master

-- MAIN APPLICATION
addappid(933300)

-- MAIN APP DEPOTS / PACKAGES
addappid(933301, 1, "d003e8e35791f58f8dd5b9f4d7db15cee5ad821a6d46bfeaa2ccbdf317b48118")

