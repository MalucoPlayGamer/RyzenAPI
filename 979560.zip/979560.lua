-- Lua provided by SkyAPI 
-- Game: AppID 979560
addappid(979560)
addappid(979561, 1, "96854040abaa23fd089af40aa49d2829935d65ad5b62cf7afdb23137acc15374")
