-- Lua provided by RyzenAPI
-- Game: RainWallpaper

-- MAIN APPLICATION
addappid(979560)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(979561, 1, "96854040abaa23fd089af40aa49d2829935d65ad5b62cf7afdb23137acc15374")

