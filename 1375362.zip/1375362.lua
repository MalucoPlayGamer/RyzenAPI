-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1375362)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375362,0,"3a59cd96c81852805624c983235a5c6e4a4e036e78e6d2e0f9785c25f1d30bb7")

