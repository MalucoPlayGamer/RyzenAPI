-- Lua provided by RyzenAPI
-- Game: Wings of The Universe

-- MAIN APPLICATION
addappid(2131430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131431, 1, "2f431e6a926826215264ba87976786400b06b7fe590b63d6e3537d190fe1eb9a")
