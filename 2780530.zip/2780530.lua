-- Lua provided by SkyAPI 
-- Game: AppID 2780530
addappid(2780530)
addappid(2780531, 1, "bc80ee5d16768f8fcf269239032c9bcabc89497094508eba18582dbca2631a42")
