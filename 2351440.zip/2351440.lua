-- Lua provided by RyzenAPI
-- Game: addappid(2351440)

-- MAIN APPLICATION
addappid(2351440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351441, 1, "20bdaed0a72709f375d2c2fdda7bd5be55e476cd4123b569d9d47f04694c6ed4")
