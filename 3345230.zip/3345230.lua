-- Lua provided by RyzenAPI
-- Game: Blade Chimera - Original Soundtrack

-- MAIN APPLICATION
addappid(3345230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345231, 1, "1106da74ae8c19a0f5cbe83e7f6d857d2d02135bf9dfb26bcf14c80482a07afa")
addappid(3345233, 1, "222f95ecae669474af21d5848ec3f6041130aebdf16d139bd00a3aeac63ce51f")

