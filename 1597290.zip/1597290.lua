-- Lua provided by RyzenAPI
-- Game: Game: Swarm the City: Zombie Evolved

-- MAIN APPLICATION
addappid(1597290)
-- Game: addappid(1597290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597291, 1, "d7a38516275b00ce5d48d76c6938a2f4a4ec887a911b1f1d205fa69b0e2a55c1")
addappid(1702810, 0, "ebb7c8674c891be645704b701592a2eb2f73337c095a4e123436a8b856e9a945")
