-- Lua provided by RyzenAPI
-- Game: addappid(294660)

-- MAIN APPLICATION
addappid(294660)
addappid(303110)
addappid(303111)
addappid(303112)
addappid(303113)
addappid(303114)
addappid(303115)
addappid(303116)
addappid(303117)
addappid(303118)
addappid(303119)

-- MAIN APP DEPOTS / PACKAGES
addappid(294661, 1, "02467e31532d3ec71fd0710da9c74fef508533cc799f8a675354279c3400521b")
addappid(294664, 1, "db80809dfa5dcc33a4db063bdd278d45e9d765a95b197458a262a888083133f6")
addappid(294665, 1, "a31474a93104500a252b3ecc924b5ade4bcd57944906513e0b54bb29c8cfeb40")
