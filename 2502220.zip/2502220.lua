-- Lua provided by SkyAPI 
-- Game: AppID 2502220
addappid(2502220)
addappid(2502221, 1, "5eb89050fc1257e9f7980bc8c9903d8a98cbdd6ebf4658fc29fbff6acf3678c0")
