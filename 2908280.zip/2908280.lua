-- Lua provided by RyzenAPI
-- Game: 2908280

-- MAIN APPLICATION
addappid(2908280)
-- Game: addappid(2908280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908281, 1, "d5f957c6cb077cfac2994b6447af0442ecd3dbdbeb377ffc4a0bfda5c5186555")
