-- Lua provided by RyzenAPI
-- Game: Midnight Driver

-- MAIN APPLICATION
addappid(228990)
addappid(1608680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608682,0,"152c189c02f6ac378779848f307c0add793db43cd374b17431333ea0220dfa03")
