-- Lua provided by RyzenAPI
-- Game: Game: Slayers X Demo

-- MAIN APPLICATION
addappid(2001540)
-- Game: addappid(2001540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001541, 1, "2053521e83eb2f7fcf103f1447da3435bff564e11819c21fdacb70a8232b6cae")
