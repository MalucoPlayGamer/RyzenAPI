-- Lua provided by RyzenAPI
-- Game: VRNinja

-- MAIN APPLICATION
addappid(509170)

-- MAIN APP DEPOTS / PACKAGES
addappid(509171, 1, "eeb6ee1504c75aac4d2a46047c188b8ba4b5f649e254920f4c2d504962530879")
