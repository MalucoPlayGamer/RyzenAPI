-- Lua provided by RyzenAPI
-- Game: An alt girl for skoof: More, more!

-- MAIN APPLICATION
addappid(3058410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058411, 1, "ef73e60b02704954409f5cf035298ecbe25d819a104630c1054a015221f98109")
