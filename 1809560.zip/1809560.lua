-- Lua provided by RyzenAPI
-- Game: 69 Moriko Love

-- MAIN APPLICATION
addappid(1809560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809561, 1, "65916073f1dcc848b7a6809ff6b4be4a4dbb4430a7f93f00de892062a41a3375")
