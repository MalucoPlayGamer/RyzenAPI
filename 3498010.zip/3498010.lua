-- Lua provided by RyzenAPI
-- Game: Sushi Cat Tower Defense

-- MAIN APPLICATION
addappid(3498010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498011,0,"a8e959bdf13fac1a1ef7b2e958e9bd6df7f8487a3c298c809df0bc000368ffe9")

