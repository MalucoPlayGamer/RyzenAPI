-- Lua provided by RyzenAPI
-- Game: 1592930

-- MAIN APPLICATION
addappid(1592930)
-- Game: addappid(1592930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592931, 1, "84bfd4631a9610277cc701780dd55e0f4fa7e0d2fc60fa053149f695d254b941")
