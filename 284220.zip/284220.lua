-- Lua provided by RyzenAPI
-- Game: Diadra Empty

-- MAIN APPLICATION
addappid(284220)

-- MAIN APP DEPOTS / PACKAGES
addappid(284221, 1, "ffd7339adcae0c1de93e3c41a8a861e1544a632269d0cdd2da46eaf1ba0c2cd8")

