-- Lua provided by RyzenAPI
-- Game: PewPew Live

-- MAIN APPLICATION
addappid(2074980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074981, 1, "cc3b6640147f562ad3d2b896ed055d20386bd23a8651ceb0cdb4c1d7dabd1a7a")

