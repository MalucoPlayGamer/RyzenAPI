-- Lua provided by RyzenAPI
-- Game: addappid(2625850)

-- MAIN APPLICATION
addappid(2625850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625851, 1, "88fe483e3a2b556eb1468c857a9c5870bca3ccd7bcda310644ea5cb152e43e14")
