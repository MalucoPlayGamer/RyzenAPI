-- Lua provided by RyzenAPI 
-- Game: Sorry We're Closed Demo
addappid(2625850)
addappid(2625851, 1, "88fe483e3a2b556eb1468c857a9c5870bca3ccd7bcda310644ea5cb152e43e14")
