-- Lua provided by RyzenAPI
-- Game: addappid(456210)

-- MAIN APPLICATION
addappid(456210)

-- MAIN APP DEPOTS / PACKAGES
addappid(456211, 1, "6ac0cc1294103342e3e25d01022a279ab65544d4d8c1d751d9901fc25c3005bf")
