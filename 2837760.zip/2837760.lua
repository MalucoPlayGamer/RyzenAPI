-- Lua provided by RyzenAPI
-- Game: addappid(2837760)

-- MAIN APPLICATION
addappid(2837760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837761, 1, "a0b8afbbeca1425e6513ad839ac2b03a271e29557b32a0c0687770e94195a77b")
