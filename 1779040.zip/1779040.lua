-- Lua provided by RyzenAPI
-- Game: addappid(1779040)

-- MAIN APPLICATION
addappid(1779040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779041, 1, "e788a4c4a38a6f30119660957df609a9b3f21c66945a68bf2eb49aefe95d8427")
