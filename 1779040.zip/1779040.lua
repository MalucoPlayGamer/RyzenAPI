-- Lua provided by SkyAPI 
-- Game: Poly Memory: Furries
addappid(1779040)
addappid(1779041, 1, "e788a4c4a38a6f30119660957df609a9b3f21c66945a68bf2eb49aefe95d8427")
