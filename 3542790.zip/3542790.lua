-- Lua provided by RyzenAPI
-- Game: Riseon

-- MAIN APPLICATION
addappid(3542790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3542791, 1, "8ccb5ca9af710837886601f563fba84fa78ef91997e40225ed077fe993fd40db")
