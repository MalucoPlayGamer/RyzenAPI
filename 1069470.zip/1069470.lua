-- Lua provided by RyzenAPI
-- Game: Dots & Girls

-- MAIN APPLICATION
addappid(1069470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069471, 1, "2245ef0ac6140abd97f40bbb36e3402812c707512de52f2b08ecf94540346da3")
