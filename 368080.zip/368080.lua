-- Lua provided by RyzenAPI
-- Game: 368080

-- MAIN APPLICATION
addappid(368080)
addappid(436420)
-- Game: addappid(368080)

-- MAIN APP DEPOTS / PACKAGES
addappid(368081, 1, "c3b0791266db10f0de3443b735cf7296d08d6b7fe825988b713993d601e2f84e")
