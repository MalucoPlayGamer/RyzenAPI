-- Lua provided by RyzenAPI
-- Game: ReTrime

-- MAIN APP DEPOTS / PACKAGES
addappid(3148470, 1, "b870ed48a0c68b24730add5cd442f46dee4c35ed4da96f62a121e78d7450baa3") -- ReTrime
addappid(3148471, 1, "92b23ba9a7ea6c8a99f8167c55e9f469c91b9477a7fa84cc20e9691aeb972115") -- Depot 3148471

