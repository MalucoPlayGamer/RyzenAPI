-- 3148470's Lua and Manifest Created by Hubcap Manifest
-- ReTrime
-- Created: August 16, 2026 at 07:41:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3148470, 1, "b870ed48a0c68b24730add5cd442f46dee4c35ed4da96f62a121e78d7450baa3") -- ReTrime
-- MAIN APP DEPOTS
addappid(3148471, 1, "92b23ba9a7ea6c8a99f8167c55e9f469c91b9477a7fa84cc20e9691aeb972115") -- Depot 3148471
setManifestid(3148471, "5958922235352702458", 1956013393)