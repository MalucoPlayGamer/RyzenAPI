-- Lua provided by RyzenAPI
-- Game: Game: Professor Watts Word Search: Yummy Foods

-- MAIN APPLICATION
addappid(884440)
-- Game: addappid(884440)

-- MAIN APP DEPOTS / PACKAGES
addappid(884441, 1, "c6c0a08c813d29620ccd401e79187309b837f073ce2c5603fb401d41d4dbfc77")
