-- Lua provided by RyzenAPI
-- Game: Ballest of Them All

-- MAIN APP DEPOTS / PACKAGES
addappid(3339810, 1, "582cc6b11e271bc6f9a336c45b02c86ee3e2fa3a7c9bb8fbbc55a2df6197fefb") -- Ballest of Them All
addappid(3339811, 1, "56178a555939a03553f2cca417c03b18e051a074b10c5a0222e3b5734340cf40") -- Depot 3339811
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
