-- Lua provided by RyzenAPI
-- Game: 429630

-- MAIN APPLICATION
addappid(429630)
-- Game: addappid(429630)

-- MAIN APP DEPOTS / PACKAGES
addappid(429631, 1, "60c3df11f750c8c9229e484605e5fa76147cf0739bf2bbf8a950eb28614af9bc")
