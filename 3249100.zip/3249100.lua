-- Lua provided by RyzenAPI
-- Game: Virtual Interactive Fireplace

-- MAIN APPLICATION
addappid(3249100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249102,0,"bb9d83dfca17a291715264260803688eae75960d6cead2530f1c5047875b1d1a")

