-- Lua provided by RyzenAPI
-- Game: Out Zone

-- MAIN APPLICATION
addappid(2022920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2022921, 1, "4122f08c3cfd677274dd1d76ff4505b94f3fedf836479767a4f0a46db964a415")
addappid(2022922, 1, "11c7b4a27ce6b5d89c38278b1eec3f448eae08f6531d3f9ccbc0eaa253cb64d0")
addappid(2022923, 1, "46d85a6bd7f965cae60fd4bc553538eccde41169f8d0bac2990ba2a425eea631")

