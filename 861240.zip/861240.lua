-- Lua provided by RyzenAPI
-- Game: Paper Valley

-- MAIN APPLICATION
addappid(861240)
addappid(869700)

-- MAIN APP DEPOTS / PACKAGES
addappid(861241,0,"17e7e1113ab7bf081339961e6de4ac06d95b57951750397dcb18a2c6e1c499e4")

