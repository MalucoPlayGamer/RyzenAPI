-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - EGKK Airport

-- MAIN APPLICATION
addappid(3073920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073920,0,"790f9c0bf3782b0b4245d90cd87075db46bdb4f5b8542c0385b526867151ed05")

