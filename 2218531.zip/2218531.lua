-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2218531)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218531,0,"860dbe71b12e40682fc1e261e624348af447c67f45727add4a2a023a5e77d943")

