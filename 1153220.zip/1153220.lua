-- Lua provided by RyzenAPI
-- Game: Mahjong Dimensions 3D - Fantasy Anime

-- MAIN APPLICATION
addappid(1153220)
addappid(1163310)
addappid(1163650)
addappid(1164400)
addappid(1164780)
addappid(1165030)
addappid(1169090)
addappid(1171680)
addappid(1173080)
addappid(1177900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153221, 1, "ba429a79eaad806d6b77a8860a0d4bdacc7370a52d0d1b427d690ac3fc30bacd")

