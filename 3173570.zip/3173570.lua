-- Lua provided by RyzenAPI
-- Game: Cabin Crew Life Simulator Demo

-- MAIN APPLICATION
addappid(3173570)
-- Game: addappid(3173570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173571, 1, "934ca846b83897faa96ea5f1b1221baef8b1e5803b60235dd3787677af50331c")
