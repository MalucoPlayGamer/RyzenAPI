-- Lua provided by RyzenAPI 
-- Game: JustScroll
addappid(2675800)
addappid(2675801, 1, "46c4930afe0267d2f21f36612561081aa3a5fd5c406ccfff907edc1db0c10f03")
