-- Lua provided by RyzenAPI
-- Game: 2675800

-- MAIN APPLICATION
addappid(2675800)
-- Game: addappid(2675800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675801, 1, "46c4930afe0267d2f21f36612561081aa3a5fd5c406ccfff907edc1db0c10f03")
