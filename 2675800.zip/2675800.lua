-- Lua provided by RyzenAPI
-- Game: JustScroll

-- MAIN APPLICATION
addappid(2675800)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2675801, 1, "46c4930afe0267d2f21f36612561081aa3a5fd5c406ccfff907edc1db0c10f03")

