-- Lua provided by RyzenAPI
-- Game: AppID 92900

-- MAIN APPLICATION
addappid(92900)
-- Game: addappid(92900)

-- MAIN APP DEPOTS / PACKAGES
addappid(92901, 1, "7696c6d0d23c890bc915a319f18214fbde91fd11f6657c811603593f0980c00a")
