-- Lua provided by RyzenAPI
-- Game: Forest Mystery

-- MAIN APPLICATION
addappid(1857910)
-- Game: addappid(1857910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857911, 1, "acac5c45182d52a3c359b3178601aa89e3104a27090fda58b32ac17eef440615")
