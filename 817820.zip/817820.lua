-- Lua provided by RyzenAPI
-- Game: addappid(817820)

-- MAIN APPLICATION
addappid(817820)

-- MAIN APP DEPOTS / PACKAGES
addappid(817821, 1, "0f8cad729eaff12d80c1ecb02c70f9641525739b2d7ff53d0a9aea87ce8ce49c")
addappid(1192790, 0, "eb616c5086ecbce9ffe2289679ecbdbc12ffd58626fa7d960e772e35505b0b68")
