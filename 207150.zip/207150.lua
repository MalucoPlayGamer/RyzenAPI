-- Lua provided by RyzenAPI
-- Game: 207150

-- MAIN APPLICATION
addappid(207150)
-- Game: addappid(207150)

-- MAIN APP DEPOTS / PACKAGES
addappid(207151, 1, "58289198685d32c7045f4662fb5bed4e0ac848c661c28e749b8f8338337a7b9a")
