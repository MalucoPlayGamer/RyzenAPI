-- Lua provided by RyzenAPI
-- Game: Stellar Impact

-- MAIN APPLICATION
addappid(207150)
addappid(207165)
addappid(207166)
addappid(207167)
addappid(207168)
addappid(207169)

-- MAIN APP DEPOTS / PACKAGES
addappid(207151, 1, "58289198685d32c7045f4662fb5bed4e0ac848c661c28e749b8f8338337a7b9a")

