-- Lua provided by RyzenAPI
-- Game: Game: WarForwards

-- MAIN APPLICATION
addappid(1081870)
addappid(1089560)
-- Game: addappid(1081870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081871, 1, "908c1cb2c90aa0fdd54d73ac79cc51dc5d3538d3cc5942b2d7b1d4806a7a3091")
