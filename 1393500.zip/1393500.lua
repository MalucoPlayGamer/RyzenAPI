-- Lua provided by RyzenAPI 
-- Game: AppID 1393500
addappid(1393500)
addappid(1393501, 1, "4135de683238b2d0c691f19f7f76bdefbb4109f97a15ca86b6c9eea899ec3324")
