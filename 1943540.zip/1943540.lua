-- Lua provided by RyzenAPI
-- Game: addappid(1943540)

-- MAIN APPLICATION
addappid(1943540)
addappid(1943541)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943542,0,"3b6d5c16db10671e0efc094f66278c70e5e37946c9521171e4cd2f849fd822aa")
