-- Lua provided by SkyAPI 
-- Game: Enlisted
addappid(2051620)
addappid(2051621, 1, "2e88998155ed76d2223ff26539918546cbf9ee06024cfbef3ddb71940b022fcf")
addappid(2051623, 1, "55d1bcf02fdc2d9245ab0236c0b44a3a27321898924f5e8226cc327d043c4637")
