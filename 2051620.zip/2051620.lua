-- Lua provided by RyzenAPI
-- Game: Enlisted

-- MAIN APPLICATION
addappid(2051620)
addappid(2825670)
addappid(2825680)
addappid(2825690)
addappid(2825700)
addappid(2825710)
addappid(2900020)
addappid(2900030)
addappid(3081430)
addappid(3081440)
addappid(3214500)
addappid(3214510)
addappid(3324860)
addappid(3324870)
addappid(3324880)
addappid(3324890)
addappid(3465230)
addappid(3465240)
addappid(3824250)
addappid(3824260)
addappid(3905640)
addappid(3905650)
addappid(3905660)
addappid(4108090)
addappid(4108110)
addappid(4230030)
addappid(4421780)
addappid(4421790)
addappid(4632220)
addappid(4632230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051621,0,"2e88998155ed76d2223ff26539918546cbf9ee06024cfbef3ddb71940b022fcf")
addappid(2051623,0,"55d1bcf02fdc2d9245ab0236c0b44a3a27321898924f5e8226cc327d043c4637")

