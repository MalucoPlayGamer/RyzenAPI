-- Lua provided by SkyAPI 
-- Game: Movie Quest
addappid(1909220)
addappid(1909221, 1, "d45ab9143b5a29bf5d6ee8c93feed0ca0bbdf29d6e4417e09ec5ba6d9b0aecc1")
