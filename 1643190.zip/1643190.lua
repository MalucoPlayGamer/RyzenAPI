-- Lua provided by RyzenAPI
-- Game: setManifestid(1643192,"7959556385371612826")

-- MAIN APPLICATION
addappid(1643190)
-- Game: addappid(1643190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643192,0,"26464ea25bdfe49508fecfcda8b935d7b7f40b4a394b770d1d153d72ef01c252")
