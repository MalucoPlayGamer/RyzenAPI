-- Lua provided by RyzenAPI
-- Game: Lord of Darkness: Prologue

-- MAIN APPLICATION
addappid(1995030)
-- Game: addappid(1995030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995031, 1, "53a0e11ff177ee41a69b5c03a820af1cae818f7e0df44e5d728f03a41b67258a")
