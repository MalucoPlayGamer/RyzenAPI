-- Lua provided by RyzenAPI
-- Game: 仙途

-- MAIN APPLICATION
addappid(2477170)
-- Game: addappid(2477170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477171, 1, "443560b092e91792f2f297ccc0d67d510587191f62d4d6423633943da5c04b83")
