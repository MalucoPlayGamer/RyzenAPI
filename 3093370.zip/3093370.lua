-- Lua provided by SkyAPI 
-- Game: The Last Sight
addappid(3093370)
addappid(3093371, 1, "2e23aac3b9bf9877119c2811af2a8b855757803bb611a3362d35597155387bf6")
addappid(3220840, 0, "15507c16fcc3dda4a7596d5131116dd6ab6326b2b2f78bcfcc6ee6d2a4b79b7d")
