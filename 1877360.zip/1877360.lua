-- Lua provided by RyzenAPI
-- Game: Mars Rover Simulator

-- MAIN APPLICATION
addappid(1877360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877361, 1, "bd7f6d29f4a034b58be2f4a492a170dc1c21ed3ae4e56934286e4e542c4030b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
