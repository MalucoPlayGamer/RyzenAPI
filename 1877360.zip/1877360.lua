-- Lua provided by RyzenAPI
-- Game: Mars Rover Simulator

-- MAIN APPLICATION
addappid(1877360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877361, 1, "bd7f6d29f4a034b58be2f4a492a170dc1c21ed3ae4e56934286e4e542c4030b9")

