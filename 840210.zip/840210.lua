-- Lua provided by RyzenAPI
-- Game: addappid(840210)

-- MAIN APPLICATION
addappid(840210)

-- MAIN APP DEPOTS / PACKAGES
addappid(840211, 1, "db6aab3268c27a30a70ff0fd89b58edbe1681e0145c13c7a1d0c7708b3fdb37e")
