-- Lua provided by SkyAPI 
-- Game: Arkham Horror: Mother's Embrace
addappid(840210)
addappid(840211, 1, "db6aab3268c27a30a70ff0fd89b58edbe1681e0145c13c7a1d0c7708b3fdb37e")
