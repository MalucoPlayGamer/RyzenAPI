-- Lua provided by RyzenAPI
-- Game: Deadly Edge

-- MAIN APPLICATION
addappid(564100)

-- MAIN APP DEPOTS / PACKAGES
addappid(564101,0,"888858fc48ef14700ceee6f7cd45143d39fed616e26c1073adc0bd95bdc611b6")

