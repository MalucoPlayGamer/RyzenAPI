-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms IV with Power Up Kit

-- MAIN APPLICATION
addappid(521730)

-- MAIN APP DEPOTS / PACKAGES
addappid(521731, 1, "fd3fa496b03431c716fcccfe6fe43fe1facf1c38257ba136d057a54e14189ebd")
