-- Lua provided by RyzenAPI
-- Game: 521730

-- MAIN APPLICATION
addappid(521730)
-- Game: addappid(521730)

-- MAIN APP DEPOTS / PACKAGES
addappid(521731, 1, "fd3fa496b03431c716fcccfe6fe43fe1facf1c38257ba136d057a54e14189ebd")
