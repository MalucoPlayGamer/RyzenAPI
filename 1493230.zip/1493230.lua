-- Lua provided by RyzenAPI 
-- Game: AppID 1493230
addappid(1493230)
addappid(1493231, 1, "6c745e3097b03b08cc4966e27387f2bb44f4df4cc5d5902645c1eeede28aff4c")
