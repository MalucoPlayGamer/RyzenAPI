-- Lua provided by RyzenAPI
-- Game: Return to Nangrim - Playable Teaser

-- MAIN APPLICATION
addappid(1732880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732881, 1, "31f74c86e1dc686230ffa726393618402213972145604499c07e09fd3147b062")

