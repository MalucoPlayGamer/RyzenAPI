-- Lua provided by RyzenAPI
-- Game: Game: AppID 2264090

-- MAIN APPLICATION
addappid(2264090)
-- Game: addappid(2264090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264091, 1, "09fe8b6d4e4e72ffcc2c1a7c5350e441eb9792badeed8568f1891cd7f5b60f14")
addappid(2264092, 1, "d79f025946dfa2598c39c5f68c76707973f7a7222820bb7c8d452f6fb549041e")
