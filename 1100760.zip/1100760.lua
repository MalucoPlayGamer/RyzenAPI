-- Lua provided by RyzenAPI 
-- Game: AppID 1100760
addappid(1100760)
addappid(1100761, 1, "6c5f81c7df32e789cfbad96901649bba64debb7f53a96a7c93f11792ba63fdd5")
addappid(1100762, 1, "35d187cf5b6a72e15e572993dc83216eb143c2d11e2f4d0a1640ef70bcd4377b")
