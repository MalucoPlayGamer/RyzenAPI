-- Lua provided by RyzenAPI
-- Game: AppID 854190

-- MAIN APPLICATION
addappid(854190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(854191, 1, "e93165605a9f208b97124fdb19dc6dfa36aa1ef4469d2fd44bdeb870e949cb2e")

