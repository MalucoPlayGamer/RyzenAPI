-- Lua provided by SkyAPI 
-- Game: AppID 854190
addappid(854190)
addappid(854191, 1, "e93165605a9f208b97124fdb19dc6dfa36aa1ef4469d2fd44bdeb870e949cb2e")
