-- Lua provided by RyzenAPI
-- Game: Bullshot

-- MAIN APPLICATION
addappid(436530)

-- MAIN APP DEPOTS / PACKAGES
addappid(436531, 1, "e51ed31950e6846ea8dd0e9f9f96da1b3f1614007abfef5e44f7cb09dc41a06f")

