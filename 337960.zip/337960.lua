-- Lua provided by SkyAPI 
-- Game: ClusterPuck 99
addappid(337960)
addappid(337961, 1, "20339ce2490e1c914a81b06a9bd81c9ee2c8371d8e711e220e82287a12a4a5a2")
addappid(337962, 1, "0384ad58c8323ea3dc4a6fd77e3a45ffbb3782d73604e6e997ce13819a4c4d1f")
addappid(337963, 1, "41c09984d927241db0c412598ec5a2f58809e3abdb64c11d9a8a50bd9ec0b8ed")
