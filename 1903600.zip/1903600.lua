-- Lua provided by RyzenAPI
-- Game: Game: Zombie VS Police

-- MAIN APPLICATION
addappid(1903600)
-- Game: addappid(1903600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903601, 1, "cb66499b231470b6cd38dae28996acb96ee232943209bd614f108a778441cb92")
