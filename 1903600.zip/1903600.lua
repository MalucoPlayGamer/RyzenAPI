-- Lua provided by SkyAPI 
-- Game: Zombie VS Police
addappid(1903600)
addappid(1903601, 1, "cb66499b231470b6cd38dae28996acb96ee232943209bd614f108a778441cb92")
