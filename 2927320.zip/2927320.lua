-- Lua provided by RyzenAPI
-- Game: Touhou Danmaku Maze

-- MAIN APPLICATION
addappid(2927320)
-- Game: addappid(2927320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927321, 1, "bb710435b992a10b727890505837d22881dce7374efc85841727fc9add6011d0")
