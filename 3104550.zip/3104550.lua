-- Lua provided by RyzenAPI
-- Game: addappid(3104550)

-- MAIN APPLICATION
addappid(3104550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104551, 1, "349db2532aebcf4a79e1aade1a2484575c0ee73e302515cbeb6c49c60ccb0cc9")
