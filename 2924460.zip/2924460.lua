-- Lua provided by RyzenAPI
-- Game: addappid(2924460)

-- MAIN APPLICATION
addappid(2924460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924460,0,"73b0d5feef1f30f9d2c4a0f864cb8811a39e5705be3938a6257fbc82395278ba")
