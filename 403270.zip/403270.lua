-- Lua provided by RyzenAPI
-- Game: Cloudrift

-- MAIN APPLICATION
addappid(403270)

-- MAIN APP DEPOTS / PACKAGES
addappid(403271, 1, "cd2b76e3e907e41f19f8dc9e54af62ea68184e4d57b62e480fbcaed3fbce5415")

