-- Lua provided by RyzenAPI
-- Game: addappid(2936450)

-- MAIN APPLICATION
addappid(2936450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936451, 1, "c3359a95b450cbfffa240672c6f8f029eb944e8ae1ecc60d71ed840b73545ffa")
