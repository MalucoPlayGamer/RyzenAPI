-- Lua provided by RyzenAPI
-- Game: Game: Detective Gman

-- MAIN APPLICATION
addappid(1724510)
-- Game: addappid(1724510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724511, 1, "dca8fbde58aee059346b2c0fd0b4ab0728d86600da25ad06d852b5ce04cf760b")
