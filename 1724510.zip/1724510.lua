-- Lua provided by RyzenAPI 
-- Game: Detective Gman
addappid(1724510)
addappid(1724511, 1, "dca8fbde58aee059346b2c0fd0b4ab0728d86600da25ad06d852b5ce04cf760b")
