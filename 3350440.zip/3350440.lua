-- Lua provided by SkyAPI 
-- Game: AppID 3350440
addappid(3350440)
addappid(3350441, 1, "75444495c97164298c7ab5bc623b59853514971b3f2c0fad10f46bd62bbe0799")
