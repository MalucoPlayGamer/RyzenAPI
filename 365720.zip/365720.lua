-- Lua provided by RyzenAPI
-- Game: Skyrim Script Extender (SKSE)

-- MAIN APPLICATION
addappid(365720)
-- Game: addappid(365720)

-- MAIN APP DEPOTS / PACKAGES
addappid(365721, 1, "2e04bbfe79bd927b998969187f8b205d3331d20b8d9023a97921216ef4e863bb")
