-- Lua provided by RyzenAPI
-- Game: 3761830

-- MAIN APPLICATION
addappid(3761830)
-- Game: addappid(3761830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761831, 1, "52a82bd44eb0af857be221436519d6ae485223175bdccc48f778ea04ad98a413")
