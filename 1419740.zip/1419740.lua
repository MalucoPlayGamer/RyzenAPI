-- Lua provided by RyzenAPI
-- Game: 1419740

-- MAIN APPLICATION
addappid(1419740)
addappid(1427370)
-- Game: addappid(1419740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419741, 1, "ccee4b00992c7c5a21941a37a0b58fc256a172e3f5e09d912e236aa360298311")
