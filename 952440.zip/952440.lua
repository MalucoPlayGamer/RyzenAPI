-- Lua provided by RyzenAPI
-- Game: OVERKILL's The Walking Dead - BETA

-- MAIN APPLICATION
addappid(952440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(952441, 1, "5c6112da7cecb5d5fa8f484c4a139457a2a4b89010b9e6033fa55049310c6aa9")

