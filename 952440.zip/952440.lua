-- Lua provided by RyzenAPI
-- Game: AppID 952440

-- MAIN APPLICATION
addappid(952440)
-- Game: addappid(952440)

-- MAIN APP DEPOTS / PACKAGES
addappid(952441, 1, "5c6112da7cecb5d5fa8f484c4a139457a2a4b89010b9e6033fa55049310c6aa9")
