-- Lua provided by RyzenAPI
-- Game: Game: Yu-Gi-Oh! EARLY DAYS COLLECTION

-- MAIN APPLICATION
addappid(3013550)
-- Game: addappid(3013550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013551, 1, "3a90e491ecf2657c715ce3b366ea99455134e5fb02e320feb2040af8b82b327e")
