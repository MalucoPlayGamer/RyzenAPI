-- Lua provided by RyzenAPI
-- Game: Yu-Gi-Oh! EARLY DAYS COLLECTION

-- MAIN APPLICATION
addappid(3013550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013551, 1, "3a90e491ecf2657c715ce3b366ea99455134e5fb02e320feb2040af8b82b327e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
