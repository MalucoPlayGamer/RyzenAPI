-- Lua provided by RyzenAPI
-- Game: addappid(1973080)

-- MAIN APPLICATION
addappid(1973080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973081, 1, "2f64f2633ed9d41f13218f487ebfc86e4f88c42835a69bba2e9473ce70a7461e")
