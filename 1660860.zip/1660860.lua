-- Lua provided by RyzenAPI
-- Game: The Harem Life of Peerless Swordsmen

-- MAIN APPLICATION
addappid(1660860)
addappid(1988500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660861, 1, "1eddcbef7a174a18c91ea7705ee6e73c9700a91baa7eddc356d68d81a0e01de2")
addappid(1660862, 1, "e7b0181d6ea770eca46345e1d32d7ecdc5dacc654d174abfcbb9cd47aa176ae8")
addappid(1660865, 1, "3eec1f5d89b09d436288b239c67198533de2d8cdecfd5d6cb0f76931aac5d752")

