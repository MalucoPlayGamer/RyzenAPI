-- Lua provided by RyzenAPI
-- Game: Garrison One man army

-- MAIN APPLICATION
addappid(2433330)
-- Game: addappid(2433330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433331, 1, "080e79e7586d98213fbbf8a5a91fc4ecf7f7b9489ccd152a65dcf9aeb74a3da2")
addappid(2433332, 1, "eaa7ea866ad34089aac2352c14689c1a584eb36ed906a5921380bdea48bcab5d")
