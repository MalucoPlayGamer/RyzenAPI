-- Lua provided by RyzenAPI
-- Game: JUMP de PON

-- MAIN APPLICATION
addappid(2281550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281551, 1, "068ffd13bb345b364dfa6a36c5404eefaf94c317726010b6353ad7e4a38353ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
