-- Lua provided by RyzenAPI
-- Game: 2281550

-- MAIN APPLICATION
addappid(2281550)
-- Game: addappid(2281550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281551, 1, "068ffd13bb345b364dfa6a36c5404eefaf94c317726010b6353ad7e4a38353ea")
