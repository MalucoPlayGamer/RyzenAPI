-- Lua provided by RyzenAPI 
-- Game: JUMP de PON
addappid(2281550)
addappid(2281551, 1, "068ffd13bb345b364dfa6a36c5404eefaf94c317726010b6353ad7e4a38353ea")
