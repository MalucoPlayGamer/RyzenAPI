-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2742320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742320,0,"f47141c9a6efb59a242035b7afc2206f65e1f11e644d03cafbf684c43bac27b7")

