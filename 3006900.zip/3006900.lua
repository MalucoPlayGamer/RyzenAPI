-- Lua provided by RyzenAPI
-- Game: Horny Housewives 2

-- MAIN APPLICATION
addappid(3006900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006901, 1, "957a884c4674c977b6d5aac1a90d0f9df2a9bcf7ee0bfb19780e3848abf63d9f")

