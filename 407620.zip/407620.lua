-- Lua provided by RyzenAPI
-- Game: Game: Indie Game Battle

-- MAIN APPLICATION
addappid(407620)
-- Game: addappid(407620)

-- MAIN APP DEPOTS / PACKAGES
addappid(407621, 1, "7011dcbaf0d0662623fe34cf4e33098ef86ea434b20af71305e24cf43ce78c00")
