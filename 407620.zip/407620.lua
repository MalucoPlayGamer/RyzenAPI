-- Lua provided by SkyAPI 
-- Game: Indie Game Battle
addappid(407620)
addappid(407621, 1, "7011dcbaf0d0662623fe34cf4e33098ef86ea434b20af71305e24cf43ce78c00")
