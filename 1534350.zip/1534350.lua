-- Lua provided by RyzenAPI
-- Game: Game: Vampire's Slave

-- MAIN APPLICATION
addappid(1534350)
-- Game: addappid(1534350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534351, 1, "620743a329f8c7ff37f52e23cbc557e1ef1cef13696d382baeea1441ed4813ab")
