-- Lua provided by RyzenAPI
-- Game: 搜索·迷城掠影/The phantom of the city

-- MAIN APPLICATION
addappid(814210)
-- Game: addappid(814210)

-- MAIN APP DEPOTS / PACKAGES
addappid(814211, 1, "40640126619e2858b3c41f641b81e38a8f7fd33e638b52f916b9da8559204468")
addappid(814212, 1, "55097ceaf3d0810b6d1422d87e18f924a7486ee2725562aec2bd5aff4d2d0139")
