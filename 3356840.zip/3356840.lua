-- Lua provided by SkyAPI 
-- Game: AppID 3356840
addappid(3356840)
addappid(3356841, 1, "18dc3b375409999ce0032ed170c9ca503e79fca1f40b0acdd7974a8e8203ee64")
