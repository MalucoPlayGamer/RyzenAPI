-- Lua provided by RyzenAPI
-- Game: Game: Witch's Doll

-- MAIN APPLICATION
addappid(2892000)
-- Game: addappid(2892000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892001, 1, "624083962a29283868832b9b8e8f355a97b4440c4d35eb6bc1f2d5b772e5319c")
