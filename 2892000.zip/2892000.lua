-- Lua provided by RyzenAPI
-- Game: Witch's Doll

-- MAIN APPLICATION
addappid(2892000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2892001, 1, "624083962a29283868832b9b8e8f355a97b4440c4d35eb6bc1f2d5b772e5319c")

