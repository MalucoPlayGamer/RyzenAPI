-- Lua provided by RyzenAPI 
-- Game: REQUISITION VR
addappid(1730650)
addappid(1730651, 1, "6683a8915319d1811cb3a96ccb81b6139d766c7ebb19984c96c2349d174fa77e")
