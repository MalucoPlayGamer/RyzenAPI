-- Lua provided by RyzenAPI
-- Game: Game: Everything Explosive

-- MAIN APPLICATION
addappid(1334800)
-- Game: addappid(1334800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334801, 1, "b4d6d82e6a65a7ecc137580d696bd1570bef8a734f18d6d96dd69e052a007717")
