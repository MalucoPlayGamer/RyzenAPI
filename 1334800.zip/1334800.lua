-- Lua provided by RyzenAPI
-- Game: Everything Explosive

-- MAIN APPLICATION
addappid(1334800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334801, 1, "b4d6d82e6a65a7ecc137580d696bd1570bef8a734f18d6d96dd69e052a007717")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
