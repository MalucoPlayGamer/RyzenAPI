-- Lua provided by SkyAPI 
-- Game: Everything Explosive
addappid(1334800)
addappid(1334801, 1, "b4d6d82e6a65a7ecc137580d696bd1570bef8a734f18d6d96dd69e052a007717")
