-- Lua provided by RyzenAPI
-- Game: Senko no Ronde 2

-- MAIN APPLICATION
addappid(574160)

-- MAIN APP DEPOTS / PACKAGES
addappid(574161, 1, "32ce81d9711cc0a2e4f532bdf1000c77ae5b61d23418b760062e37572124fd30")
