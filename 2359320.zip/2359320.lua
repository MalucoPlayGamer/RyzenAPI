-- Lua provided by RyzenAPI
-- Game: 被坏女人骗成冒险者!

-- MAIN APPLICATION
addappid(2359320)
-- Game: addappid(2359320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359321, 1, "b4c316ab669cff067c2d54501a7966b976d87eaf61c2d3d2038fc35043d132be")
