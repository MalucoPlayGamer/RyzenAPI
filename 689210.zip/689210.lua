-- Lua provided by RyzenAPI
-- Game: The Museum of ThroughView

-- MAIN APPLICATION
addappid(689210)

-- MAIN APP DEPOTS / PACKAGES
addappid(689211,0,"cff77293a5a6db41d2f6abd247ad20419fc5655399e7ef2b239c85a1c9dd1fc3")

