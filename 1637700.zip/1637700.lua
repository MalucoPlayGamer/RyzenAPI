-- Lua provided by RyzenAPI
-- Game: Infiltration: Alone in Combat

-- MAIN APPLICATION
addappid(1637700)
-- Game: addappid(1637700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637701, 1, "78db8eceee4aa38cb4d50dec7f2d68974da898d2a87571ba8f6c488406f527b4")
