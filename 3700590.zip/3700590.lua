-- Lua provided by RyzenAPI
-- Game: Back to the Dawn - Supporter Pack

-- MAIN APPLICATION
addappid(3700590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700591, 1, "999ea4a5f7c7406dcf832770bb051d0ba6d4dbe8df09e6412ccdf3464379b120")

