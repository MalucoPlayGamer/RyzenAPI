-- Lua provided by RyzenAPI
-- Game: Spellbook Demonslayers Prologue

-- MAIN APPLICATION
addappid(2070390)
addappid(2110040)
-- Game: addappid(2070390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070391, 1, "1983edf29cce38d1b06c67f960cb91dd5183471823a366dbdb5480441354310f")
