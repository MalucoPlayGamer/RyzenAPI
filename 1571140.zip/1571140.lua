-- Lua provided by RyzenAPI
-- Game: 东方十昊狱 ～ Hella Dazzling Hell!!

-- MAIN APPLICATION
addappid(1571140)
-- Game: addappid(1571140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571141, 1, "cf648a545f8d8c44ffa661e1d25928c318f6bada1b57e9d484fe58cd7dbe1649")
