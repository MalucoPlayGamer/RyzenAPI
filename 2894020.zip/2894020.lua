-- Lua provided by RyzenAPI
-- Game: Game: AppID 2894020

-- MAIN APPLICATION
addappid(2894020)
-- Game: addappid(2894020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894021, 1, "9b375e5964dae9069991436e2205937f1ddcd5037b17d84075473da3f1a8f40e")
