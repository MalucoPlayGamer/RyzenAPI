-- Lua provided by RyzenAPI
-- Game: Game: Fishards

-- MAIN APPLICATION
addappid(1637140)
-- Game: addappid(1637140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637141, 1, "75e087b5ee743e1f3cf40a718e5baaf8f5da382631a857b637601a9830a78692")
addappid(1637142, 1, "4448344abc3bf6f76d65cb839bee056fe098c043a1b41a28f7cc362ed15812af")
addappid(1637143, 1, "89795c1c5b9d3eb718c803c3251b72ac2161f22d4c8e73026cb36abb130b3d0b")
