-- Lua provided by RyzenAPI
-- Game: Replica

-- MAIN APPLICATION
addappid(496890)
-- Game: addappid(496890)

-- MAIN APP DEPOTS / PACKAGES
addappid(496891, 1, "40363257e52e466bb9b6f4b3ce653f08b709f148a9757859bf3b6b19344a73e9")
addappid(496892, 1, "97d661b86695440e28cd06277728735dfea8cbeab59b60c42f164a1ce00dc6fe")
