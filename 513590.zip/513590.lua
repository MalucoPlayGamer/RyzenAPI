-- Lua provided by RyzenAPI
-- Game: Game: AppID 513590

-- MAIN APPLICATION
addappid(513590)
-- Game: addappid(513590)

-- MAIN APP DEPOTS / PACKAGES
addappid(513591, 1, "5ceebe7f1fcb9e789a98887de78fa38355787394702191ef80665882700548c2")
addappid(513592, 1, "c4dc23cb7d058cca8755b770060498d565ece84e6aa45a65c1139b8abac8f173")
addappid(513593, 1, "7ca1c25134a1b3db6210e5683fcba47ce0ea99dabeef026a026fb95b16475a3b")
