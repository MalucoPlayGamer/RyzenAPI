-- Lua provided by RyzenAPI
-- Game: Piko Piko - Original Soundtrack

-- MAIN APPLICATION
addappid(1981450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981451, 1, "8d0b4d40dfb8f6e43f730fa43cabfe317b2da4cfd7e8a2ba918803d44839a291")
