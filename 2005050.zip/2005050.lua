-- Lua provided by RyzenAPI
-- Game: Game: Dance Dash

-- MAIN APPLICATION
addappid(2005050)
-- Game: addappid(2005050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005051, 1, "fba7e1af6af6751a4390e7dea7f1b2c21f91a061947639149761ee4df632502e")
