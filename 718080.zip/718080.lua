-- Lua provided by RyzenAPI
-- Game: AppID 718080

-- MAIN APPLICATION
addappid(718080)

-- MAIN APP DEPOTS / PACKAGES
addappid(718081, 1, "e021c477e17b3516647ce9fb6cec6cdf98ec19a3b3ed51dd9a0ce0bc0966988b")
