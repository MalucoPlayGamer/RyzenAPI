-- Lua provided by RyzenAPI
-- Game: Moto Racer  4 Demo

-- MAIN APPLICATION
addappid(572460)
-- Game: addappid(572460)

-- MAIN APP DEPOTS / PACKAGES
addappid(572461, 1, "54bfd0be673c1659813532a7832601c3865643edb52409c7b66932063bbd6ad6")
