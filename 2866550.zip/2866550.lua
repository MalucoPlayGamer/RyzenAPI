-- Lua provided by RyzenAPI
-- Game: Hangul Shooter

-- MAIN APPLICATION
addappid(2866550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866551, 1, "78c9a20913e44db77946b81b77f664d27372e53854dc9ee2545757675b0f0d61")

