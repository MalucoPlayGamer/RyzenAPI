-- Lua provided by RyzenAPI
-- Game: AppID 2571680

-- MAIN APPLICATION
addappid(2571680)
-- Game: addappid(2571680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571681, 1, "62ffac236e2cec4b9f6bc1081ac10780690fe62839d531f67a251e07dfc6f007")
