-- Lua provided by RyzenAPI
-- Game: Isonzo - Soundtrack

-- MAIN APPLICATION
addappid(2078340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078341, 1, "082220a938c8754bb8d6837af4d35d5d109bb2526bd61eaf46af7abbff53b65f")
addappid(2078342, 1, "fc1202cd37239b390f588ec3a07d23db38c0acc655db6b15bd8bb12fbebeebd2")
