-- Lua provided by RyzenAPI
-- Game: Game: SHEEP.IO

-- MAIN APPLICATION
addappid(1078870)
-- Game: addappid(1078870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078871, 1, "ecdf2b56a388fa53d50ff9648da88d12e3e472a7da38a4b9d069876b6b07b660")
