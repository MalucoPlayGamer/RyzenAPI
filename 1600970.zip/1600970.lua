-- Lua provided by RyzenAPI
-- Game: Green Fairy VR

-- MAIN APPLICATION
addappid(1600970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600971, 1, "06333fba24e25f0599443ca7a63846c8e3f0d232c36ec52bda89536eb6f75eeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
