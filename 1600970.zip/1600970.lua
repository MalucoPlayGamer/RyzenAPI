-- Lua provided by RyzenAPI
-- Game: Green Fairy VR

-- MAIN APPLICATION
addappid(1600970)
-- Game: addappid(1600970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600971, 1, "06333fba24e25f0599443ca7a63846c8e3f0d232c36ec52bda89536eb6f75eeb")
