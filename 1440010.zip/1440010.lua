-- Lua provided by SkyAPI 
-- Game: Die After Sunset
addappid(1440010)
addappid(1440011, 1, "94e041db2ab47bf733f3a1780e2ae5d687aa88c410d1999803d69e80f5365622")
