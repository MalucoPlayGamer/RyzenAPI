-- Lua provided by RyzenAPI
-- Game: 仙界之剑 仙王少女战记

-- MAIN APPLICATION
addappid(2195230)
-- Game: addappid(2195230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195231, 1, "8662ac281393dcf90df0d8cfcea05154a2b8456cbddacd2899acb3868c225149")
