-- Lua provided by RyzenAPI
-- Game: addappid(1482320)

-- MAIN APPLICATION
addappid(1482320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482321, 1, "7b7e67ec9eafefe7ed1415e77c220380a41387b33e16ca2985fe7fa39256973e")
