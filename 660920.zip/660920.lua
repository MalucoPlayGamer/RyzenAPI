-- Lua provided by RyzenAPI 
-- Game: AppID 660920
addappid(660920)
addappid(660921, 1, "b9a2ee682e0dbf3b53e1368e2fef571a42397ff0000425215de07eac595508a1")
