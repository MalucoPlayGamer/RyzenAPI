-- Lua provided by SkyAPI 
-- Game: AppID 1016260
addappid(1016260)
addappid(1016261, 1, "012809301264eac384bd588d98779c3cf36356e8bf1997a6ea6f65922a9e3922")
