-- Lua provided by RyzenAPI
-- Game: AppID 1016260

-- MAIN APPLICATION
addappid(1016260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016261, 1, "012809301264eac384bd588d98779c3cf36356e8bf1997a6ea6f65922a9e3922")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
