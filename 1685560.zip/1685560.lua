-- Lua provided by RyzenAPI
-- Game: Chimes

-- MAIN APPLICATION
addappid(1685560)
-- Game: addappid(1685560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685562,0,"2cc03199123c93690e016d4694052e9e3e309d3aa36120aeec65324bed889392")
