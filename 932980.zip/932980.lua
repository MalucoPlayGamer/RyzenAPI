-- Lua provided by RyzenAPI
-- Game: Axis Football 2018

-- MAIN APPLICATION
addappid(932980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(932981, 1, "c7289c43ad65cd9f7278e63b6ed280287c9c4c092b6fec9045f2f4900cb0eca6")
addappid(932983, 1, "44d274a16a83d4a8a9bf4cc46ce204e6ca9267ac0ca4476df04d11e273567e7d")

