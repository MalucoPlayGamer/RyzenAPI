-- Lua provided by RyzenAPI 
-- Game: 破烂系统
addappid(3844200)
addappid(3844201, 1, "72dfc83620019c0b1538f17302c15204c2938979e84dd9f28866c76a67b20c7f")
