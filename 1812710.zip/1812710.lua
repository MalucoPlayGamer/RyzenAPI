-- Lua provided by RyzenAPI
-- Game: addappid(1812710)

-- MAIN APPLICATION
addappid(1812710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812711, 1, "b549d549f0205314b72eab10531c510a66c44128c7aa99cb5d9dcfd0120a953b")
