-- Lua provided by RyzenAPI
-- Game: Game: AppID 1311460

-- MAIN APPLICATION
addappid(1311460)
-- Game: addappid(1311460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311461, 1, "81c6b70180ca7711bc4d0806c6d18f0a3c8d94ee1644802c90eced86450f5f9d")
