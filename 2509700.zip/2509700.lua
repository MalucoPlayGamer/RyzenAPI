-- Lua provided by RyzenAPI
-- Game: Game: Mimi the Cat - Meow Together

-- MAIN APPLICATION
addappid(2509700)
-- Game: addappid(2509700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509701, 1, "be7b1df7354db85f98288549885e36f6e84980f7af67820201e86183e669eda4")
