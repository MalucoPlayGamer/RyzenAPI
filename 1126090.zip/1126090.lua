-- Lua provided by RyzenAPI
-- Game: Booby And The Booby Trap

-- MAIN APPLICATION
addappid(1126090)
-- Game: addappid(1126090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126091, 1, "0adb2d4bedb061e6f90582a8621845ba196e23c195a3a809c8cf1fb807fda22f")
