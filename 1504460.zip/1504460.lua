-- Lua provided by RyzenAPI
-- Game: Fruit Girls: Hentai Jigsaw Photo Studio

-- MAIN APPLICATION
addappid(1504460)
addappid(1662880)
-- Game: addappid(1504460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504461, 1, "e96b0d8545ace1c5417f1aaca01020ec4db1166dff0bf59976206e3a806ce44a")
addappid(1772332, 0, "e99218ec99f332c001dc87c705359bfcf1f22ade0cdffb44d7233fbaa85ba448")
