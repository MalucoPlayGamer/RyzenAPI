-- Lua provided by RyzenAPI
-- Game: 847470

-- MAIN APPLICATION
addappid(847470)
-- Game: addappid(847470)

-- MAIN APP DEPOTS / PACKAGES
addappid(847472,0,"a8546b629558638240790754bdf08db4e7d29c9cceec4d2e4c8008f19a3ffd52")
