-- Lua provided by SkyAPI 
-- Game: AppID 392410
addappid(392410)
addappid(392411, 1, "837e3effdd61a78f4561d44be78e5ce331256ed2bfdfd34e44b23326674c839e")
addappid(392412, 1, "1258b370ec61ca8c41ee68fbd9973dfd74df051d20a5466c9a74683d2666cb2f")
