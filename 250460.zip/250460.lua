-- Lua provided by RyzenAPI
-- Game: Bridge Constructor

-- MAIN APPLICATION
addappid(250460)
addappid(463810)

-- MAIN APP DEPOTS / PACKAGES
addappid(250461, 1, "eae01a0da0e8de3887148806b9e685174060e8941d3326a519675ebe15ff1803")
addappid(250462, 1, "3127bf9e9a5db9cff2f37eb66c028dd50fb41b00e9f83024d79951bf09b93173")
addappid(250463, 1, "22ec1b406b902a4e568710bc4d79832b10f0fb8ed9fb044f198c43049008a38f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
