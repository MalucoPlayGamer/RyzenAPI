-- Lua provided by RyzenAPI
-- Game: Orange Adventure

-- MAIN APPLICATION
addappid(510280)

-- MAIN APP DEPOTS / PACKAGES
addappid(510281,0,"fc67f7a634188ea50d3edea08fba72102714e2415217bb7ad1b0d5b39baa8465")

