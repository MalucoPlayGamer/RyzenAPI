-- Lua provided by RyzenAPI
-- Game: AppID 758370

-- MAIN APPLICATION
addappid(758370)

-- MAIN APP DEPOTS / PACKAGES
addappid(758371, 1, "5ccb8b392bad1b67001d96b3878dc4d87a2e8339a2b200f09aed5ca802bfc540")
addappid(758372, 1, "4976393a991ce51b21bf745708b94aa753426345662d35d2d31e6612aa4aa0fc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1100960)
