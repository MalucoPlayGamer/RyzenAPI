-- Lua provided by RyzenAPI
-- Game: STEAM-HEART'S Saturn Tribute

-- MAIN APPLICATION
addappid(3500600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500601, 1, "5e299b350d951922c7f9c78857ab589dbed10b293df1b9f9a53a9f26d2bad854")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3513660)
