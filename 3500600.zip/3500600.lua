-- Lua provided by RyzenAPI
-- Game: addappid(3500600)

-- MAIN APPLICATION
addappid(3500600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500601, 1, "5e299b350d951922c7f9c78857ab589dbed10b293df1b9f9a53a9f26d2bad854")
