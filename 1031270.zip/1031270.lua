-- Lua provided by RyzenAPI
-- Game: Farming Life

-- MAIN APPLICATION
addappid(1031270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031271, 1, "b93b2b0ba59f4bb4a919b49c795bba935c2b348323e0319e190239841c8784db")

