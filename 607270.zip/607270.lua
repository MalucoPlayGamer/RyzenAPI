-- Lua provided by RyzenAPI
-- Game: Jack's Gang

-- MAIN APPLICATION
addappid(607270)

-- MAIN APP DEPOTS / PACKAGES
addappid(607271, 1, "8a4b52bf4b105003434a83d5b38f593683b5e9b9df980e4f6ccfe91c85fcb4c2")

