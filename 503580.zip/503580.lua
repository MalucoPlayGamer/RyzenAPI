-- Lua provided by RyzenAPI
-- Game: Game: Duck Season

-- MAIN APPLICATION
addappid(503580)
-- Game: addappid(503580)

-- MAIN APP DEPOTS / PACKAGES
addappid(503581, 1, "67d2bc7b42d425dcce983a84d3f2f822f6bc7cde5f7e20cfc026748988bfcdca")
