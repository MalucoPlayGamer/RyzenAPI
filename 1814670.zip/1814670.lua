-- Lua provided by RyzenAPI
-- Game: 1814670

-- MAIN APPLICATION
addappid(1814670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814672,0,"6e1101c18fac51d58a7edb95ecd55c9c21cdd4d32466f2ef19a0bd8a197e839d")
