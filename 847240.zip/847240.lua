-- Lua provided by RyzenAPI
-- Game: Zombie Commander

-- MAIN APPLICATION
addappid(847240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(847241, 1, "1f5da88876e91873c9729f9982ecdf72a85202fe956db6eed0a609db32f729e3")

