-- Lua provided by SkyAPI 
-- Game: Zombie Commander
addappid(847240)
addappid(847241, 1, "1f5da88876e91873c9729f9982ecdf72a85202fe956db6eed0a609db32f729e3")
