-- Lua provided by RyzenAPI
-- Game: Game: Zombie Commander

-- MAIN APPLICATION
addappid(847240)
-- Game: addappid(847240)

-- MAIN APP DEPOTS / PACKAGES
addappid(847241, 1, "1f5da88876e91873c9729f9982ecdf72a85202fe956db6eed0a609db32f729e3")
