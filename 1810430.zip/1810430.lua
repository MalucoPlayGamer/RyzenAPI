-- Lua provided by RyzenAPI
-- Game: Grim Tales: Echo of the Past Collector's Edition

-- MAIN APPLICATION
addappid(1810430)
-- Game: addappid(1810430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810431, 1, "1bc4e9404a7e268e28cee95156b3c609a1754bc2b40d94cf76bb34d754db8842")
