-- Lua provided by RyzenAPI 
-- Game: Who's That Flying?!
addappid(57700)
addappid(57701, 1, "db7213e85e17057fee3394a9250dc27bfe0765b44b99d282c8620e8a2e1d0ffc")
