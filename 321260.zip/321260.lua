-- Lua provided by SkyAPI 
-- Game: Wickland
addappid(321260)
addappid(321261, 1, "03b45761bd9d6427da4898fa600b48314eee50d062b0ef62b886c22daf230f87")
