-- Lua provided by SkyAPI 
-- Game: Ronister Adventure
addappid(1458530)
addappid(1458531, 1, "070a1159a14938a94f9dfaaf689ccba68236e7efe11f38bc6796c1f6a5b5fa04")
