-- Lua provided by RyzenAPI
-- Game: Ranger’s Path: National Park Simulator

-- MAIN APPLICATION
addappid(2502780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2502781, 1, "5282c32747e5a2cf09349ccd9658ef78312cb83f5d83fe39b3cd8f69c5228ca3")

