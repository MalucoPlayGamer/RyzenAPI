-- Lua provided by RyzenAPI
-- Game: Hellcome Demo

-- MAIN APPLICATION
addappid(2341020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341021, 1, "c57479095f571972ecd9886d321097a915b8a8bd5ff0f8c32489a378263dfe3b")

