-- Lua provided by RyzenAPI
-- Game: 1712820

-- MAIN APPLICATION
addappid(1712820)
-- Game: addappid(1712820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712821, 1, "d65d813fc3c2e7ffb79a8768f3bed1a46534aef5307907d127eb19df9f79898e")
