-- Lua provided by RyzenAPI
-- Game: The Office

-- MAIN APPLICATION
addappid(2003620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003621, 1, "27a78221059e04c3cc63133a7490f53fbfa721cd17f6bad0eddfc86bf9a8e203")

