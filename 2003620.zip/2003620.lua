-- Lua provided by RyzenAPI
-- Game: The Office

-- MAIN APPLICATION
addappid(2003620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2003621, 1, "27a78221059e04c3cc63133a7490f53fbfa721cd17f6bad0eddfc86bf9a8e203")

