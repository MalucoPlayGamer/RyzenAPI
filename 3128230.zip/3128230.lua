-- Lua provided by SkyAPI 
-- Game: WhatRogue：Exile Land Demo
addappid(3128230)
addappid(3128231, 1, "c17813e4adbfd80feffc2cd984323b7d0f6d1ab3186b7021a927bd9ef1fae69a")
