-- Lua provided by RyzenAPI
-- Game: WhatRogue：Exile Land Demo

-- MAIN APPLICATION
addappid(3128230)
-- Game: addappid(3128230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128231, 1, "c17813e4adbfd80feffc2cd984323b7d0f6d1ab3186b7021a927bd9ef1fae69a")
