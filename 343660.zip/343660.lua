-- Lua provided by RyzenAPI
-- Game: AppID 343660

-- MAIN APPLICATION
addappid(343660)
-- Game: addappid(343660)

-- MAIN APP DEPOTS / PACKAGES
addappid(343661, 1, "3b9757c1fcd38e12883717d79886f9fbc2d00aed4372d2af07dcf6dee2fde05c")
addappid(343662, 1, "6a7f28bce3a1726a29cb6b0abc4f0f1549d4fa3313c857d511c4ece30e54db42")
addappid(343663, 1, "236198a3ab5c0b030f90d064c7e92021edeea1b59508f32e57d6dcfdf7c853c9")
addappid(343664, 1, "ffc608db87d9805aa9570d9b79acd251758251ec3bef66bdbf51a94ac59cf63c")
addappid(343665, 1, "731cd0925902bc9cb74428b35623f333cba7be6d6958ca3346bfba9420575499")
addappid(343666, 1, "30d4ab4b51f3f4100b2e4f9f40d553ad6f5c8a1bfb6cfa04dcb4fe750f0fb23f")
addappid(343667, 1, "f5ef032db4b4ee89aa8d1649d94eb6dddcff9d99e262f3a5d67ee71811ae5556")
addappid(343668, 1, "d9871f8813610cdb4ac67cac08c2acaaf227c167505f8b8424cfba3ddc4912ec")
addappid(357810, 0, "bf01b4ab6b058f58827160443e95e46ce8fb2e6d13089247faae733ad863273d")
