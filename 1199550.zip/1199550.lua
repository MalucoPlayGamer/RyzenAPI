-- Lua provided by RyzenAPI
-- Game: addappid(1199550)

-- MAIN APPLICATION
addappid(1199550)
addappid(1199600)
addappid(1199601)
addappid(1199602)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199551, 1, "5df71fd1f83291cfea7301875b06b1751d67696c363e2b17ceb3c11a830eee7b")
