-- Lua provided by RyzenAPI
-- Game: AppID 824720

-- MAIN APPLICATION
addappid(824720)
-- Game: addappid(824720)

-- MAIN APP DEPOTS / PACKAGES
addappid(824721, 1, "b929a31f1b7a0e70ec088bc7360d67c7db44033a0a2748df2b03d66001b04521")
