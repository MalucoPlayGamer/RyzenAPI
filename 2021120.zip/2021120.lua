-- Lua provided by RyzenAPI
-- Game: addappid(2021120)

-- MAIN APPLICATION
addappid(2021120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021121, 1, "20b44097478079244828c3bbd1fffb54d49561b289f1a97bd58ef51efa30714e")
