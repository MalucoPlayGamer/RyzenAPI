-- Lua provided by RyzenAPI
-- Game: Game: AppID 3427670

-- MAIN APPLICATION
addappid(3427670)
-- Game: addappid(3427670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427671, 1, "06804e40736f32f3839dd0ffe39256131f2b240caeee68c91e2ab312b4d34ddb")
