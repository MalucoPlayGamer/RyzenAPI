-- Lua provided by RyzenAPI
-- Game: Game: How Much Items - Vehicles

-- MAIN APPLICATION
addappid(3525880)
-- Game: addappid(3525880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3525881, 1, "3adb06a2f3ef9e8876e8d89b4af0ed56d37a49a142bcb256954110058a3358aa")
