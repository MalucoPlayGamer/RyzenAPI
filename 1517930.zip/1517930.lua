-- Lua provided by RyzenAPI
-- Game: Bonkey Trek Quimdung Edition

-- MAIN APPLICATION
addappid(1517930)
-- Game: addappid(1517930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517931, 1, "011b89d94c530f82e7860e754ea2c30aeda7a96a28d62824629823fb3e102024")
