-- Lua provided by RyzenAPI
-- Game: SHARK! SHARK!

-- MAIN APPLICATION
addappid(2410640)
-- Game: addappid(2410640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410641, 1, "cca2fbbf4e979a1f63919f6d26923b3e4b4938732a35c8706262394e95af10b0")
addappid(2410642, 1, "9a371a524a18ae3e574b77cbf40ae4cff9be14d481bf1b6ad39e66d3bb15bcdc")
