-- Lua provided by RyzenAPI
-- Game: Dawn of Corruption

-- MAIN APPLICATION
addappid(1608730)
addappid(4485290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608731, 1, "65e84e1ba4273f785c3b6f87a2e0702cbff6ed1d67e986ed69bd8469a6ca952c")

