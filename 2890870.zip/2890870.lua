-- Lua provided by RyzenAPI
-- Game: 2890870

-- MAIN APPLICATION
addappid(2890870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890873,0,"e71975ffb464119db267f8dfe325c1e3878f55499a6022bf1074b893ebce93b4")
addappid(2890874,0,"3de88d743beabfe283addeda2d18bbbd19f5d7c21172251df4bee6178aad9f9b")

