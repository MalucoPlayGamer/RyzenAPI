-- Lua provided by RyzenAPI
-- Game: Handyman Corporation

-- MAIN APPLICATION
addappid(1703180)
-- Game: addappid(1703180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703181, 1, "96986e91e2d5b285a66e2ede44534ce7469bb7972a50e565746df73276dfd3e4")
