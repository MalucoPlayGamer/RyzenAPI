-- Lua provided by RyzenAPI
-- Game: Handyman Corporation

-- MAIN APPLICATION
addappid(1703180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1703181, 1, "96986e91e2d5b285a66e2ede44534ce7469bb7972a50e565746df73276dfd3e4")

