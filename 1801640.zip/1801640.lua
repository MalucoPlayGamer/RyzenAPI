-- Lua provided by RyzenAPI
-- Game: 精神病大王花 Flowering Abyss

-- MAIN APPLICATION
addappid(1801640)
-- Game: addappid(1801640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801641, 1, "3279a8eefe38cc19965d756ed884b8740275508997844dfe8dc2055f015b12d9")
