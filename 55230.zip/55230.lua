-- Lua provided by RyzenAPI
-- Game: AppID 55230

-- MAIN APPLICATION
addappid(55230)

-- MAIN APP DEPOTS / PACKAGES
addappid(55231, 1, "c608ec67920e5c288d47272933491b8892eebc8b21a00aec33579ac321b8a3c9")
addappid(55232, 1, "ac7270611fe692c9cf7d75a086f22539b81658e1f1008fdedd183d7dc6d20848")
addappid(55234, 1, "981462730170dbdbb6900685e3681d3aca9a834c8946e38fd027d429048721dd")
addappid(55235, 1, "0c31f71199f3d2bed608f5dbc83bbc137ac87c1c98599bf92dbffe6e415ef7f5")
addappid(55236, 1, "5113233fe1ca13f5d5512adcc885d18dc389c47409262766e08ca90f708a8776")
addappid(55237, 1, "405ea97d029b24b90ee33643a0845ed05cfa148d5aed50cd6bd4fe22057fcdc5")
addappid(55238, 1, "ce04f8844d6785298d5a8a1f6e271c805b9a783dd6c7b9b68268088599b4268d")
addappid(55239, 1, "116fa210f9aedb823c265fb8673ec8490d577da800358fbb29dec2df0b62576f")
addappid(55241, 1, "db01da8013c1760d81c2b5b7916d88f65eff096593b5befdf6f913ceb3386ee0")
addappid(55244, 1, "765a0c05e5c582761b2de5ad5bc9348bd886ed2461ed7537b55212fa933d91a5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(55380)
addappid(55381)
addappid(55382)
addappid(55383)
addappid(55384)
addappid(55385)
addappid(55386)
addappid(55387)
addappid(55388)
addappid(55389)
addappid(55390)
addappid(55391)
addappid(55392)
addappid(55393)
addappid(55394)
addappid(55395)
addappid(55396)
addappid(55397)
addappid(55398)
addappid(55399)
addappid(55400)
addappid(55409)
