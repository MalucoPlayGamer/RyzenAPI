-- Lua provided by SkyAPI 
-- Game: Temple Of Snek
addappid(1208590)
addappid(1208591, 1, "860d2fa953cf3696d42b6f4a1372afc7b6d76235b01309b7fddb36b773a7a6c3")
