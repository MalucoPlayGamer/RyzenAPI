-- Lua provided by RyzenAPI
-- Game: Gnomes Vs. Fairies: Greckel's Quest

-- MAIN APPLICATION
addappid(406220)
addappid(575190)

-- MAIN APP DEPOTS / PACKAGES
addappid(406221, 1, "0afa423bffebd9095246129d6bcab5a6bf1d37e93470ac736226e59fe0b03a7c")
addappid(406222, 1, "8a029c9452190b7542dfb0429d656ed79c94c2a0d708c1c933e0b990c2123cf8")
addappid(406223, 1, "ca2e91a221c70fa144bd38384e45e720934d1461d50b4cb834bfb65e879461b2")

