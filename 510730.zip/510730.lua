-- Lua provided by RyzenAPI
-- Game: Game: AppID 510730

-- MAIN APPLICATION
addappid(510730)
-- Game: addappid(510730)

-- MAIN APP DEPOTS / PACKAGES
addappid(510731, 1, "7ccd6180c1ec43bac9b83c48e7d0e08833a8e2e6fc1a6f0ebae28720f8e368f2")
