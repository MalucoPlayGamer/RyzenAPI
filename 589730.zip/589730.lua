-- Lua provided by RyzenAPI
-- Game: AppID 589730

-- MAIN APPLICATION
addappid(589730)
-- Game: addappid(589730)

-- MAIN APP DEPOTS / PACKAGES
addappid(589731, 1, "2895c8cbbc00cfbcc54cba8ef07d9b164c22b8078b348bfc5a9d00852c1f0a2e")
addappid(589732, 1, "42bacb5818ad3e0567cd8b0b406457cb59a8f85e812f1b2bc7e3e1e5a06bb8ce")
addappid(589733, 1, "2240a2028aae7a1b77afc152ef8198382fa89191317b2d72122c9cef65331ada")
