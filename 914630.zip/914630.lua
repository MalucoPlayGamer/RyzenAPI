-- Lua provided by RyzenAPI
-- Game: AppID 914630

-- MAIN APPLICATION
addappid(914630)
-- Game: addappid(914630)

-- MAIN APP DEPOTS / PACKAGES
addappid(914631, 1, "d81a48d521a210d977995ce7a96f8b4ae4c588e5280bc14f45e71624fef24a04")
