-- Lua provided by RyzenAPI
-- Game: 785680

-- MAIN APPLICATION
addappid(785680)
-- Game: addappid(785680)

-- MAIN APP DEPOTS / PACKAGES
addappid(785681, 1, "749e77ab1afc50f94dc44733c7da32dfc8e1f261700c7f3791bc14e1633ebf58")
