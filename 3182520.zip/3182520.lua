-- Lua provided by RyzenAPI
-- Game: Game: AppID 3182520

-- MAIN APPLICATION
addappid(3182520)
-- Game: addappid(3182520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182521, 1, "bbcdd7dd8a1f93e6f822402a8fba707bc89ae3f6fb67b77217c44ddb64541349")
