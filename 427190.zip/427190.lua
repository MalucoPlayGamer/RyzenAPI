-- Lua provided by RyzenAPI
-- Game: DEAD RISING®

-- MAIN APPLICATION
addappid(427190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(427191, 1, "15333e205124aacce0cf02f67a82b8a1df5117d39ab30041d74d72afe545a724")
addappid(427193, 1, "7e56d51db95a29bbdbc8fea0c6614f9cb5d290f23afa84a1b29315a2e9f56d48")

