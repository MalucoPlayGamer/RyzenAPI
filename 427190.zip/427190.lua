-- Lua provided by RyzenAPI
-- Game: Game: DEAD RISING®

-- MAIN APPLICATION
addappid(427190)
-- Game: addappid(427190)

-- MAIN APP DEPOTS / PACKAGES
addappid(427191, 1, "15333e205124aacce0cf02f67a82b8a1df5117d39ab30041d74d72afe545a724")
addappid(427193, 1, "7e56d51db95a29bbdbc8fea0c6614f9cb5d290f23afa84a1b29315a2e9f56d48")
