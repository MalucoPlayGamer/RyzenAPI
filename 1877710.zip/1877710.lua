-- Lua provided by RyzenAPI
-- Game: Cool Kid Cody

-- MAIN APPLICATION
addappid(1877710)
addappid(1939310)
addappid(1939311)
addappid(1939312)
addappid(1939313)
addappid(1939314)
addappid(1939315)
addappid(1939316)
addappid(1939317)
addappid(1939318)
addappid(2056621)
addappid(2056622)
addappid(2056623)
addappid(2056624)
addappid(2056625)
addappid(2056626)
addappid(2056627)
addappid(2056628)
addappid(2056629)
addappid(2645880)
addappid(2645890)
addappid(2645900)
addappid(2645910)
addappid(2645920)
addappid(2645930)
addappid(2645940)
addappid(3262060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877711, 1, "454149240f47a3caed3d139b3de1de86f775ddaec840c0efed0df4c84440435f")
addappid(2056620, 0, "33d6536851846447a7d5b6d27c008c96fbacf62be87db6b3de9a5be03f9783b0")
addappid(2645850, 0, "ec720a6b84b612c4b71f8a2f9f7b0eb6897354fb4c9dbff080d19d6ba102df10")
addappid(2645860, 0, "021b053fba3b46cca83d69e1a1cb72fa3e7b92df6a4b73b13d6cc1c002fc5a98")
addappid(2645870, 0, "709be818e6a46bdb9f3e41ff4305142d95184b9e41256ea06ea3d6b543592a95")

