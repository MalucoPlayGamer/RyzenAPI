-- Lua provided by RyzenAPI 
-- Game: Primal Carnage: Extinction
addappid(321360)
addappid(321361, 1, "44c9aa7a8860e89276b65426256e270756e1c1b62567ee7d97de2b41008300a1")
