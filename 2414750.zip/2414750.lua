-- Lua provided by RyzenAPI
-- Game: 2414750

-- MAIN APPLICATION
addappid(2414750)
-- Game: addappid(2414750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414751, 1, "2d109f6436d3fb631ff45a60bd708df8ca330d6131b698a097a35ebad2fb7a73")
