-- Lua provided by RyzenAPI
-- Game: Game: SEVERANCE

-- MAIN APPLICATION
addappid(3815750)
-- Game: addappid(3815750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3815751, 1, "6cf0988d25caea7fe7245408960338ae4b8c86c22cee82d6d46731f2450203df")
