-- Lua provided by RyzenAPI
-- Game: Mythical Concept STARNAUT

-- MAIN APPLICATION
addappid(2508940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508941, 1, "7ee03c2730a2ebf70b12009ea2150c70ce25bfe2870d549852fa19a1efa708e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2776880)
