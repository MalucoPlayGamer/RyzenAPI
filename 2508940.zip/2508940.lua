-- Lua provided by RyzenAPI
-- Game: Mythical Concept STARNAUT

-- MAIN APPLICATION
addappid(2508940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508941, 1, "7ee03c2730a2ebf70b12009ea2150c70ce25bfe2870d549852fa19a1efa708e4")
