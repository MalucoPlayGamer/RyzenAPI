-- Lua provided by RyzenAPI
-- Game: The Galactic Harem Handbook: Chapter 2 - NSFW Sci-Fi Porn

-- MAIN APPLICATION
addappid(2736150)
-- Game: addappid(2736150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736151, 1, "3ab5e3c1aa41b253917ac5254a6b4ae54fbbdb1e6a927f6564bbec484f82405e")
