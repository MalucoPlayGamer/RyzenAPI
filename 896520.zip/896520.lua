-- Lua provided by RyzenAPI
-- Game: 896520

-- MAIN APPLICATION
addappid(896520)
-- Game: addappid(896520)

-- MAIN APP DEPOTS / PACKAGES
addappid(896521, 1, "23580a79ae776368657156552c94bb33ebd7f4d90b9a2d4f39bfd7099b3b417e")
