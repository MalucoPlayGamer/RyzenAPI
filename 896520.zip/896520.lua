-- Lua provided by SkyAPI 
-- Game: AppID 896520
addappid(896520)
addappid(896521, 1, "23580a79ae776368657156552c94bb33ebd7f4d90b9a2d4f39bfd7099b3b417e")
