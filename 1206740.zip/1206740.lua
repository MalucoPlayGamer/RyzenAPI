-- Lua provided by RyzenAPI
-- Game: addappid(1206740)

-- MAIN APPLICATION
addappid(1206740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206741, 1, "22e842448bd255bb8796149181b4579e4a62097d904be435afabd5e92fa79b0d")
