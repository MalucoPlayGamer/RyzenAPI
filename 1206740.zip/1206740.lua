-- 1206740's Lua and Manifest Created by Hubcap Manifest
-- Omnify Hotspot
-- Created: September 30, 2025 at 04:39:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 9
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1206740) -- Omnify Hotspot
-- MAIN APP DEPOTS
addappid(1206741, 1, "22e842448bd255bb8796149181b4579e4a62097d904be435afabd5e92fa79b0d") -- Omnify Hotspot Content
setManifestid(1206741, "7434162087754965040", 285985006)
-- SHARED DEPOTS (from other apps)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1206760) -- Omnify Hotspot Premium - 1 Year
addappid(1206761) -- Omnify Hotspot Premium - 2 Year
addappid(1206762) -- Omnify Hotspot Premium - 3 Year
addappid(1623050) -- Omnify Hotspot Premium - 1 Year
addappid(1623051) -- Omnify Hotspot Premium - 2 Year
addappid(2014810) -- Omnify Hotspot Premium - 1 Year
addappid(2625250) -- Omnify Hotspot Premium - 1 Year
addappid(2625270) -- Omnify Hotspot Premium - 2 Year
addappid(2625280) -- Omnify Hotspot Premium - 3 Year