-- Lua provided by RyzenAPI
-- Game: Omnify Hotspot

-- MAIN APPLICATION
addappid(1206740) -- Omnify Hotspot
addappid(1206760) -- Omnify Hotspot Premium - 1 Year
addappid(1206761) -- Omnify Hotspot Premium - 2 Year
addappid(1206762) -- Omnify Hotspot Premium - 3 Year
addappid(1623050) -- Omnify Hotspot Premium - 1 Year
addappid(1623051) -- Omnify Hotspot Premium - 2 Year
addappid(2014810) -- Omnify Hotspot Premium - 1 Year
addappid(2625250) -- Omnify Hotspot Premium - 1 Year
addappid(2625270) -- Omnify Hotspot Premium - 2 Year
addappid(2625280) -- Omnify Hotspot Premium - 3 Year

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(1206741, 1, "22e842448bd255bb8796149181b4579e4a62097d904be435afabd5e92fa79b0d") -- Omnify Hotspot Content

