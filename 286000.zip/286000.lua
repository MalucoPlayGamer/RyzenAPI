-- Lua provided by RyzenAPI
-- Game: Tooth and Tail

-- MAIN APPLICATION
addappid(286000)

-- MAIN APP DEPOTS / PACKAGES
addappid(286001, 1, "3740911e71ba1d619cefdba5bb70f3debf0183cb1ce67fc1bdd3c999e37af801")
addappid(286002, 1, "514b237bacdbf933fa053a5e9b4bb057e0448f9574eeea541c906fac07022412")
addappid(286003, 1, "e6a532d4a99b71923e1a812f85a7a004bca9bdf2ca2222bacc066866be05241a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
