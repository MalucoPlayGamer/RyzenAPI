-- Lua provided by RyzenAPI
-- Game: Fapic

-- MAIN APPLICATION
addappid(679070)

-- MAIN APP DEPOTS / PACKAGES
addappid(679071, 1, "f82c6b4b90ac5fb3b1cbf5595c5ee07d9405016ef1bea840b7bde0d39e30f30d")

