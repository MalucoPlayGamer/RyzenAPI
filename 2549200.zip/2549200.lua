-- Lua provided by RyzenAPI
-- Game: Fate and Life: The Mystery of Vaulinhorn

-- MAIN APPLICATION
addappid(2549200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549201, 1, "39168629836e608b655b257c3651f296316fd17f9d31f395b730d30b5579c17e")
addappid(2810240, 0, "c788aa3dda279fb5f1d3095048425715ec4bb10627fae9ba53b10f37316fc588")

