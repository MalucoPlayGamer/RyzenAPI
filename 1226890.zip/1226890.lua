-- Lua provided by RyzenAPI
-- Game: AppID 1226890

-- MAIN APPLICATION
addappid(1226890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1226891, 1, "66500ce60c27b80bf92371b793f0d357ce0bff0022519125dc967a5d647f2855")

