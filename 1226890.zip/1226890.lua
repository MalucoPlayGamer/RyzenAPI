-- Lua provided by RyzenAPI 
-- Game: AppID 1226890
addappid(1226890)
addappid(1226891, 1, "66500ce60c27b80bf92371b793f0d357ce0bff0022519125dc967a5d647f2855")
