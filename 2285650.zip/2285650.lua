-- Lua provided by RyzenAPI
-- Game: Game: Sword and Fairy Inn

-- MAIN APPLICATION
addappid(2285650)
-- Game: addappid(2285650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285651, 1, "883ec5c877b849499d6f03865cf651cdc30b475d8b0414fbfe3b807dd5f70d42")
addappid(2285653, 1, "f10911279348155a01da47b525d6d7b1b5298d721808fbeb6f08e5babaf08300")
