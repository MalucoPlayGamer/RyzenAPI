-- Lua provided by RyzenAPI
-- Game: Sword Art Online: Hollow Realization Deluxe Edition

-- MAIN APPLICATION
addappid(607890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(607891, 1, "2819352a1d4053633e8f2329f90f4a57b99468de507727499988a276babeb3c7")

