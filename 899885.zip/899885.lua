-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Cyndi Lauper - “Girls Just Want to Have Fun”

-- MAIN APPLICATION
addappid(899885)

-- MAIN APP DEPOTS / PACKAGES
addappid(899885,0,"6011dec0beab9e119d958b3cd50c67fb21604d64723fb87159d43598a8467d6b")
