-- Lua provided by RyzenAPI
-- Game: Isekai Sex Boutique Soundtrack

-- MAIN APPLICATION
addappid(3699300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699301, 1, "fc47ac6c789964130b36fd6da1b6f774897aa5098970bfa651606ff61fb1cbbf")
addappid(3699302, 1, "9eb0878de06c52c436cce3340adc75cf399f98a8475cf149d41d14f75680b61d")

