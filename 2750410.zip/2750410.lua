-- Lua provided by RyzenAPI
-- Game: クビトリドオルズ・レトリーバー: 島津怪談01

-- MAIN APPLICATION
addappid(2750410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750412,0,"ab8bbf31519bd6a97b5f9cd1d570ec00df55f1de9c4f5416c6724e2661cfbf00")
