-- Lua provided by RyzenAPI
-- Game: Solar Showdown

-- MAIN APPLICATION
addappid(2408120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408121, 1, "2f053343fb1a4334ddb8a4b5c6b9a758189db7d926e7ecb554f737ee52fde744")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
