-- Lua provided by RyzenAPI
-- Game: Solar Showdown

-- MAIN APPLICATION
addappid(2408120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408121, 1, "2f053343fb1a4334ddb8a4b5c6b9a758189db7d926e7ecb554f737ee52fde744")
