-- Lua provided by RyzenAPI
-- Game: 1460710

-- MAIN APPLICATION
addappid(1460710)
-- Game: addappid(1460710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460711, 1, "853901d2c1a642b1f9387423b9e9fc76fd8239051ce862fcbc31cf8cd1288555")
