-- Lua provided by RyzenAPI
-- Game: Sister Travel

-- MAIN APPLICATION
addappid(959890)
-- Game: addappid(959890)

-- MAIN APP DEPOTS / PACKAGES
addappid(959891, 1, "446661a05e3e4b87b6f6b96a94ddfd4352dc6a4b764e7c98f2058686801c43a9")
addappid(959892, 1, "c413d862054b361ec53004be0091d1194154327cc1ef797ba6de7e0a13418299")
