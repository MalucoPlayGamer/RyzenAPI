-- Lua provided by SkyAPI 
-- Game: Nimbatus - The Space Drone Constructor Soundtrack
addappid(1252890)
addappid(1252891, 1, "e533c63dba12f1e1a8eead6c19bf752996bde374247b7e6a9644f6944e8e3ca3")
addappid(1252892, 1, "2b2765b065203b30abc1148caab50c3b66e3f166b9d1eef5b8c955e5914e0b3a")
