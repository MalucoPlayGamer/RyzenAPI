-- Lua provided by RyzenAPI
-- Game: Street Outlaws: The List

-- MAIN APPLICATION
addappid(987330)

-- MAIN APP DEPOTS / PACKAGES
addappid(987331, 1, "1f4fae5f49e398939553dfcce9c0283d93ce159980e09aab77a7e644332b18b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
