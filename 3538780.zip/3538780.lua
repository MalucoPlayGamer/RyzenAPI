-- Lua provided by RyzenAPI
-- Game: Lovely Sex with Tsundere Girl -She is too much into pleasure and loves your cock-

-- MAIN APPLICATION
addappid(3538780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538781, 1, "8eff0cbb341bb2e8d6b816939d33ec22df69b323376d31b6b318cdeb6f98273b")

