-- Lua provided by RyzenAPI
-- Game: Amanda the Adventurer 2 Demo

-- MAIN APPLICATION
addappid(2828910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828911, 1, "1220a76aa6978561adf5a065b0a3223f53a8ed6ab7ccbce55805a4b86b947a42")
