-- Lua provided by RyzenAPI 
-- Game: AppID 2828910
addappid(2828910)
addappid(2828911, 1, "1220a76aa6978561adf5a065b0a3223f53a8ed6ab7ccbce55805a4b86b947a42")
