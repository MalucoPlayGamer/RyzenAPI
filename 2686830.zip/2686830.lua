-- Lua provided by RyzenAPI
-- Game: 2686830

-- MAIN APPLICATION
addappid(2686830)
-- Game: addappid(2686830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686831, 1, "829282768409ce320f56b403aa014fbfc58fc8136eb97e47b15443cf8d3e5f36")
