-- Lua provided by RyzenAPI
-- Game: addappid(1321070)

-- MAIN APPLICATION
addappid(1321070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321071, 1, "f1c794f604d95003c1d38ca9fe3153e711c020eb48cf78873b294e74315f2c4f")
