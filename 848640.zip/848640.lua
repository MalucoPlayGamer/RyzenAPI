-- Lua provided by RyzenAPI
-- Game: Game: AppID 848640

-- MAIN APPLICATION
addappid(848640)
-- Game: addappid(848640)

-- MAIN APP DEPOTS / PACKAGES
addappid(848641, 1, "a65e01903339b90c99f6dbfe0a42d3677055babedc2fe29af916c226f97f19ce")
addappid(848642, 1, "87e262d4d4358b73153e01ab6bb0aa39a92589862eee89f90a2f4452898cbac5")
