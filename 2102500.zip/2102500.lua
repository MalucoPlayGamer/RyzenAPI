-- Lua provided by RyzenAPI
-- Game: Blacksmith Weapon Merchant

-- MAIN APPLICATION
addappid(2102500)
addappid(2109740)
addappid(2109741)
addappid(2180860)
addappid(2194380)
addappid(2194381)
addappid(2303270)
addappid(2303271)
addappid(2303272)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102501, 1, "643304d0a74ca9f032a672bba353a4fb2ed5a33b75a686b9a5098f448ff3a845")

