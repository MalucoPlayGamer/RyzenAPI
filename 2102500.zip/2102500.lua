-- Lua provided by RyzenAPI
-- Game: addappid(2102500)

-- MAIN APPLICATION
addappid(2102500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102501, 1, "643304d0a74ca9f032a672bba353a4fb2ed5a33b75a686b9a5098f448ff3a845")
