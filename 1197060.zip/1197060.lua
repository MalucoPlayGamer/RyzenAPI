-- Lua provided by RyzenAPI 
-- Game: FUNGI
addappid(1197060)
addappid(1197061, 1, "f8e8543f59f67956d4bc947573da0ca685797dc39ed613612ff5646092580428")
addappid(1197062, 1, "cf78b74006fd4431262dcdfaa1fa222aab48b0fedb365c8cdf2a94ff9db919af")
