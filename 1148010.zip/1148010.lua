-- Lua provided by RyzenAPI
-- Game: Love Chan

-- MAIN APPLICATION
addappid(1148010)
addappid(1150870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148011, 1, "452e1a5848e6d23202860824b655f9cd2a534530ce01ee9c2f64a309c9cf0448")

