-- Lua provided by RyzenAPI
-- Game: 1637740

-- MAIN APPLICATION
addappid(1637740)
-- Game: addappid(1637740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637741, 1, "ef548b2e5d9fd5a7a0a1d679f6522a14d24cf8d6aa134542d0ed09e7a581aa5b")
