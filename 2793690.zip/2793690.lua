-- Lua provided by RyzenAPI
-- Game: AppID 2793690

-- MAIN APPLICATION
addappid(2793690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793691, 1, "dfc7ebd1cf56cd9964f04cc4fdf608e26ec6337afee3c886a8ec983a776b1087")

