-- Lua provided by RyzenAPI
-- Game: The Clans - Saga of the Twins

-- MAIN APPLICATION
addappid(342090)
addappid(344200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(342091, 1, "b47bb59972e77fcf14b4eb956f6457798ff9bfc2a4ca9ace08e1c6f1ebc1699f")

