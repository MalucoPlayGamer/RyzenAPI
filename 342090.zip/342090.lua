-- Lua provided by RyzenAPI
-- Game: The Clans - Saga of the Twins

-- MAIN APPLICATION
addappid(342090)
addappid(344200)

-- MAIN APP DEPOTS / PACKAGES
addappid(342091, 1, "b47bb59972e77fcf14b4eb956f6457798ff9bfc2a4ca9ace08e1c6f1ebc1699f")
