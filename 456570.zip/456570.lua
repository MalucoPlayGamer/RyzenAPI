-- Lua provided by SkyAPI 
-- Game: AppID 456570
addappid(456570)
addappid(456571, 1, "24a6356d61c98ae159eab0aae1fc9e4c79fc0f6915f189d6b381385493fc285e")
