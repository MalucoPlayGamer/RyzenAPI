-- Lua provided by RyzenAPI
-- Game: AppID 456570

-- MAIN APPLICATION
addappid(456570)

-- MAIN APP DEPOTS / PACKAGES
addappid(456571, 1, "24a6356d61c98ae159eab0aae1fc9e4c79fc0f6915f189d6b381385493fc285e")

