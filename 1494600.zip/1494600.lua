-- Lua provided by RyzenAPI
-- Game: FUSER™ - Shawn Mendes - "Higher"

-- MAIN APPLICATION
addappid(1494600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494600,0,"b555ba14ba0bf2514efe67154f2553ba72e3e0432bed23a7081052f28d32cdcf")

