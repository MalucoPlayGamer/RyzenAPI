-- Lua provided by RyzenAPI
-- Game: addappid(799830)

-- MAIN APPLICATION
addappid(799830)

-- MAIN APP DEPOTS / PACKAGES
addappid(799831, 1, "bf8389b8f4734ba3b36272f66a48860ab48ce6e9120b2c246baedb769dbf5c1d")
