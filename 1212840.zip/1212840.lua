-- Lua provided by RyzenAPI
-- Game: Game: パトルの軍事博物館３ 超絶無敵究極兵器

-- MAIN APPLICATION
addappid(1212840)
-- Game: addappid(1212840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212841, 1, "7faaa703e57292ce0d4bf62e410f8589b321cd6ad4fb2774ea6346486a4e6516")
