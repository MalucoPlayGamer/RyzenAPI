-- Lua provided by RyzenAPI
-- Game: SEASON OF MYSTERY: The Cherry Blossom Murders

-- MAIN APPLICATION
addappid(39110)
-- Game: addappid(39110)

-- MAIN APP DEPOTS / PACKAGES
addappid(39111, 1, "1c39a55795f5ffb2a848ce0b0bb95ca6163041ed79df00bec9e6d24d9d07a2a1")
addappid(39112, 1, "b1aad317af6cff7a88e87b8e2ad860f19c6208e192915f71213beb530804af0d")
