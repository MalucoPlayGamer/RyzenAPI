-- Lua provided by RyzenAPI
-- Game: Fall of Porcupine Demo

-- MAIN APPLICATION
addappid(1710850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710851, 1, "191edd37d404b38bad38da02b640c7540e3018d2862d4ffc1b87db8eb1d13a5d")
