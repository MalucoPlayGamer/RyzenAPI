-- Lua provided by RyzenAPI
-- Game: PetDoctor

-- MAIN APPLICATION
addappid(4656920)
