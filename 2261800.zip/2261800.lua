-- Lua provided by RyzenAPI
-- Game: AppID 2261800

-- MAIN APPLICATION
addappid(2261800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261801, 1, "817f71b2ca36bd9d692794ac0f5aa5e9894e2a136cee4129c5ba67bcad932b7c")
addappid(2261802, 1, "ecf4dc06839afa302c677efed0ee4780ecd497a23af601240e1e9ab29741789f")

