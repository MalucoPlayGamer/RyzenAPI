-- Lua provided by RyzenAPI
-- Game: Make War

-- MAIN APPLICATION
addappid(1120210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120211, 1, "9bf8db776703402a43ccf9ef1fac96b5e977c96f4e9a2b1a88613e083e489f61")

