-- Lua provided by RyzenAPI
-- Game: addappid(863900)

-- MAIN APPLICATION
addappid(863900)

-- MAIN APP DEPOTS / PACKAGES
addappid(863904,0,"6c82acdf36107b5e79ec7e96243f3bc8fc13dd8ede15e428985034bc8767f245")
