-- Lua provided by RyzenAPI
-- Game: Great Naval Battles: The Final Fury

-- MAIN APPLICATION
addappid(2702080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702081, 1, "23c85fa9ee5c33c2d64e3958c1470846872c4537d3c1e152f9a288219a1cb2f1")

