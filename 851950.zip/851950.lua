-- Lua provided by RyzenAPI
-- Game: addappid(851950)

-- MAIN APPLICATION
addappid(851950)

-- MAIN APP DEPOTS / PACKAGES
addappid(851951, 1, "a357f552bf625a5c8582053fcbbcc4b164324cd70798fcdf5f74cf7c0d4024a9")
