-- Lua provided by RyzenAPI
-- Game: addappid(2335980)

-- MAIN APPLICATION
addappid(2335980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335981, 1, "9fba7c53ad52e1f453c912be23384c6016ec56e1e4f8e877a8e7969337cdfce4")
