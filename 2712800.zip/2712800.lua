-- Lua provided by RyzenAPI
-- Game: Bus World Demo

-- MAIN APPLICATION
addappid(2712800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712801, 1, "5e9a55358c066495e17affe3b82b4e0aba975a16ce1a7701990c3a08fb9d71b2")
