-- Lua provided by RyzenAPI 
-- Game: AppID 2712800
addappid(2712800)
addappid(2712801, 1, "5e9a55358c066495e17affe3b82b4e0aba975a16ce1a7701990c3a08fb9d71b2")
