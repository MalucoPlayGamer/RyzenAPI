-- Lua provided by SkyAPI 
-- Game: AppID 231120
addappid(231120)
addappid(231121, 1, "c40962d86783b8a051a6055d28b9bdd825d9b80eab8b8b54ab937f62f3afb9d3")
addappid(231122, 1, "c6f3789ec67f79ffaa70e89dfdebde8cce991654f2cadf0dcf715783c9ba2410")
addappid(231123, 1, "f588b8deacf77634dba14ebc1719e7c2117f051e1004a6c600af90b432e8dc9c")
