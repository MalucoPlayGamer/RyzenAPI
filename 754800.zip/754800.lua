-- Lua provided by RyzenAPI
-- Game: Yashik

-- MAIN APPLICATION
addappid(754800)
-- Game: addappid(754800)

-- MAIN APP DEPOTS / PACKAGES
addappid(754801, 1, "971dc60a8f5e0800f9ffebeddfb9f4949ee8168510fed595650fd603eab53dd9")
