-- Lua provided by RyzenAPI
-- Game: Old Market Simulator: Prologue

-- MAIN APPLICATION
addappid(2878410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878411, 1, "0a6db80c14ae669fd441c3399dbf666a0fd897505a427dedd835982c1b7b7f54")

