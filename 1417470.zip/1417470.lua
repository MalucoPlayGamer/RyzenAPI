-- Lua provided by RyzenAPI
-- Game: Friendly Arena Demo

-- MAIN APPLICATION
addappid(1417470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417471, 1, "e86798546b663420fd9cc2e4e94956f3a2b661ae30a86a2d646df5c3d3a1ea66")
