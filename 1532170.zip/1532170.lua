-- Lua provided by RyzenAPI 
-- Game: Veneficium
addappid(1532170)
addappid(1532171, 1, "429c6c0c1906f82f04701ae1cf57b863b9fc43179f6e1779e4bb7a05d636ea6b")
