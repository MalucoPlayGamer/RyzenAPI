-- Lua provided by RyzenAPI
-- Game: Call of Duty: Black Ops - Mac Edition

-- MAIN APPLICATION
addappid(214630)

-- MAIN APP DEPOTS / PACKAGES
addappid(214631, 1, "904a406f1e717b877cb557516d994c9ec6e8af49fd1e1ba8a92925dd1da16565")
addappid(214632, 1, "481c1e943f158a88f14c744f2881f80e324eadabcf226af94a694ab798245b8a")
addappid(214633, 1, "1827c09ead4857e3d99ed07af58f7c32f468381b3594c2be3f0de7c441e239ad")
addappid(214635, 1, "2ec4aac7f7b604c205cf17bfbff40afc739beb79ba4493e1db6c98151ff4b98e")
addappid(214636, 1, "ef90f2445f2f952ba7f1dbf12ada65d4c5b7a4f23a2ea0abe0f029ba17a9d797")
addappid(214637, 1, "6383ae668b25aa3614f8ba35f8ccf6e643a4a6dda535c4683999d6f2450b89ee")
addappid(214638, 1, "f87d21994f2c02b7117e4087e5a2bb480a2bd4454214d173df7d122a85469d0f")
addappid(214646, 1, "ee8525fdbe70362e66f42974cce4b72d5a3adb9fb15fc3f2384d6f086685ab1a")
addappid(214649, 1, "7aa1998611367715c053d2f57dcd29ad635b6f7a1abfb012bf95e3ec914974ce")

