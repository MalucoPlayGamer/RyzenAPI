-- Lua provided by RyzenAPI
-- Game: Failing Witch Iris and the Philosopher's Stone

-- MAIN APPLICATION
addappid(3298500)
-- Game: addappid(3298500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298502,0,"92c8db4ce934dc5e74e03804921b2db95d49d5f805d4b59ac556bc546ba5f6cc")
addappid(3298503,0,"38da071fdaec4950baf0f87f3128158ad59c4f730395479523fe9ce964bf7697")
addappid(3298504,0,"88f016ecf493feb00b33417ded64b9bbcb956b383def88e9573d17a0d9a7949f")
