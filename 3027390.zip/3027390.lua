-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel 2 OST Vol. 2

-- MAIN APPLICATION
addappid(3027390)
-- Game: addappid(3027390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027391, 1, "65e282f8f11f23a036105d60c797b93232ad0062e364510af4f6f99aadaf722a")
addappid(3027393, 1, "22086c83f62abb2d73bec5f5e572733f24fdf0de818c506da7524e19bf9bdca9")
