-- Lua provided by RyzenAPI
-- Game: addappid(70220)

-- MAIN APPLICATION
addappid(70220)

-- MAIN APP DEPOTS / PACKAGES
addappid(70221, 1, "e5a45c183571100a3b4456390d0e78eb89ad43d4dca292665a0a643353091d84")
