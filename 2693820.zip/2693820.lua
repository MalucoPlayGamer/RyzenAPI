-- Lua provided by RyzenAPI
-- Game: Project N.E.X.T

-- MAIN APPLICATION
addappid(2693820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2693821, 1, "82b9a6f19fd19917d39536a9e930b47d9d2bc192633ac701fe402cc3e81bf8a4")

