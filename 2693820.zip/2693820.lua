-- Lua provided by RyzenAPI
-- Game: Game: Project N.E.X.T

-- MAIN APPLICATION
addappid(2693820)
-- Game: addappid(2693820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693821, 1, "82b9a6f19fd19917d39536a9e930b47d9d2bc192633ac701fe402cc3e81bf8a4")
