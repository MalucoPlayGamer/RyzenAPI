-- Lua provided by RyzenAPI
-- Game: HELLCARD: Prologue

-- MAIN APPLICATION
addappid(2207480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207481, 1, "898f6e7a03ef57740ddb2656066dcf17361475a46b5dbdcf0e97dc872b68a6d5")

