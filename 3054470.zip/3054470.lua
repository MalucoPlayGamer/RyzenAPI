-- Lua provided by SkyAPI 
-- Game: Rogue Zodiacs
addappid(3054470)
addappid(3054471, 1, "d13ccfbf295bce6051bfb7f72c6c4085b5c72564d12d99684f6a2e094f21bf3f")
