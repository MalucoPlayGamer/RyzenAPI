-- Lua provided by RyzenAPI
-- Game: 3054470

-- MAIN APPLICATION
addappid(3054470)
-- Game: addappid(3054470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054471, 1, "d13ccfbf295bce6051bfb7f72c6c4085b5c72564d12d99684f6a2e094f21bf3f")
