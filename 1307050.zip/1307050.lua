-- Lua provided by RyzenAPI
-- Game: Spoils of Plunder dedicated server

-- MAIN APPLICATION
addappid(1307050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307051, 1, "1356237392ab0476e9bb1c3b443a78d6bc7b5aa7865b0842472cd46eff15c082")
addappid(1307052, 1, "0ad5816f93cf193bae190992fa3f56a61de6a215d00b1307a882ac58577492cd")
