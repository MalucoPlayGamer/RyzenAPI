-- Lua provided by RyzenAPI
-- Game: Survival Simulator 生存模拟器

-- MAIN APPLICATION
addappid(1409510)
-- Game: addappid(1409510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409511, 1, "b201992d778321d0b99eb4f597d2c4d230274c3c06584a715d9d9835df52062c")
