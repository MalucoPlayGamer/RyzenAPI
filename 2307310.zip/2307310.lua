-- Lua provided by SkyAPI 
-- Game: AppID 2307310
addappid(2307310)
addappid(2307311, 1, "da2f6a77552bbca592ce3551a1badc58c6eda86b96737f6aa6d17dff2b63ecc2")
