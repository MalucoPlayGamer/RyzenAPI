-- Lua provided by RyzenAPI 
-- Game: Brave Princess Milia Demo
addappid(1887950)
addappid(1887951, 1, "5eada02efbfe62ba15039d534e7eaedf954cbf4a205281c6971105725a692f47")
addappid(1887952, 1, "1144fd28541c93a18e2c17dd28861afad37a1557e1d506a83844de8bcc5677b3")
