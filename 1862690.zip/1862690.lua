-- Lua provided by RyzenAPI
-- Game: My Gaming Club

-- MAIN APPLICATION
addappid(1862690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862692,0,"ba653bfb806ce11f1aa1a7b808c875004c17b059e7c1aa71e74b18403d372baf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
