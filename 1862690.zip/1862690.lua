-- Lua provided by RyzenAPI
-- Game: My Gaming Club

-- MAIN APPLICATION
addappid(1862690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862692,0,"ba653bfb806ce11f1aa1a7b808c875004c17b059e7c1aa71e74b18403d372baf")

