-- Lua provided by RyzenAPI
-- Game: addappid(3085690)

-- MAIN APPLICATION
addappid(3085690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085691, 1, "547bb181b122ad77ee9ae30d382e1f669da64a760c5fb32734826ca2aa6d3895")
