-- Lua provided by RyzenAPI
-- Game: Until You Fall

-- MAIN APPLICATION
addappid(858260)
-- Game: addappid(858260)

-- MAIN APP DEPOTS / PACKAGES
addappid(858261, 1, "324b69c4f190a393f4d2025f961d0773389b98039b26aff79552875f737647df")
