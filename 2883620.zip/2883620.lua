-- Lua provided by RyzenAPI 
-- Game: Wind field
addappid(2883620)
addappid(2883621, 1, "dc4f32a3e0e970cb5b9c76fa19c09d754de9a558bed6274ca3a0b0ceb3c99924")
