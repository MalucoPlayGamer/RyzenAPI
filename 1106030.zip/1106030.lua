-- Lua provided by RyzenAPI
-- Game: Game: ROAD HOMEWARD 3 underwater world

-- MAIN APPLICATION
addappid(1106030)
-- Game: addappid(1106030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106031, 1, "49e4925d1d412320cad305073ac0180f6fbe0226b600e881932bd93c5a604893")
