-- Lua provided by RyzenAPI
-- Game: ROAD HOMEWARD 3 underwater world

-- MAIN APPLICATION
addappid(1106030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1106031, 1, "49e4925d1d412320cad305073ac0180f6fbe0226b600e881932bd93c5a604893")

