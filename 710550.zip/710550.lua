-- Lua provided by RyzenAPI
-- Game: Cubion

-- MAIN APPLICATION
addappid(710550)

-- MAIN APP DEPOTS / PACKAGES
addappid(710551, 1, "332d552b3ba3c926e0cee3bb077a2eb85c801f427c21313f2ae6144878f1fb99")
