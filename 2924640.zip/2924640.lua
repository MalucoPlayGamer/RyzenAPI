-- Lua provided by RyzenAPI
-- Game: addappid(2924640)

-- MAIN APPLICATION
addappid(2924640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924641, 1, "f3ed6f95af8f704c45e187beaf2f9d14cfc83e2259e2c978db8e95a189f97344")
