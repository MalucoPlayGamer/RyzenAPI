-- Lua provided by SkyAPI 
-- Game: So Many Me
addappid(260530)
addappid(260531, 1, "eaa47160177c7c2bc3ba6a8e131defbe161b4c74ce5397f49bb21506ea263b06")
