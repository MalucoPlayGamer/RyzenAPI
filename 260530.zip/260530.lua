-- Lua provided by RyzenAPI
-- Game: So Many Me

-- MAIN APPLICATION
addappid(260530)

-- MAIN APP DEPOTS / PACKAGES
addappid(260531, 1, "eaa47160177c7c2bc3ba6a8e131defbe161b4c74ce5397f49bb21506ea263b06")
