-- Lua provided by RyzenAPI
-- Game: Run Tekila Run!

-- MAIN APPLICATION
addappid(2704860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704861, 1, "05b7664fdf2d3200198986d7db4eedad354ef507b7373295f172bec604d284ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
