-- Lua provided by RyzenAPI
-- Game: Run Tekila Run!

-- MAIN APPLICATION
addappid(2704860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704861, 1, "05b7664fdf2d3200198986d7db4eedad354ef507b7373295f172bec604d284ec")

