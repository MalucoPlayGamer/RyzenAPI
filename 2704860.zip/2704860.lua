-- Lua provided by SkyAPI 
-- Game: Run Tekila Run!
addappid(2704860)
addappid(2704861, 1, "05b7664fdf2d3200198986d7db4eedad354ef507b7373295f172bec604d284ec")
