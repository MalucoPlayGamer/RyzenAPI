-- Lua provided by RyzenAPI 
-- Game: AppID 1453100
addappid(1453100)
addappid(1453101, 1, "502c97bb22fa69e42d1f39021cc8652d06a9277622185498fc01cf33c8979b95")
