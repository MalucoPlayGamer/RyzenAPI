-- Lua provided by RyzenAPI
-- Game: 中医模拟器试用版

-- MAIN APPLICATION
addappid(1453100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453101, 1, "502c97bb22fa69e42d1f39021cc8652d06a9277622185498fc01cf33c8979b95")

