-- Lua provided by RyzenAPI
-- Game: Loopstructor

-- MAIN APPLICATION
addappid(2726870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726871, 1, "2fe1ac080bb10c4f2a361100606dad11c1212c7ac0a06e57c658d9c00920c13a")
