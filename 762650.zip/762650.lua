-- Lua provided by RyzenAPI
-- Game: Depraved

-- MAIN APPLICATION
addappid(762650)
addappid(777080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(762651, 1, "92a40c34b337a5e76700d852eba0abd415db56a204385923d597f24aadeb58f7")
addappid(762653, 1, "ab6c2768252683414e7266741995a5b9763d673f045a609c7dadd61e9aca5f9d")
addappid(762654, 1, "9a64bbba5c5e339f29e9de407732465333ec381a02d503faca6b497af115e253")

