-- Lua provided by RyzenAPI
-- Game: addappid(2422610)

-- MAIN APPLICATION
addappid(2422610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422611, 1, "10f75cae97b31afd68c594fede7a0378293b7cedac87a744904a4c3df19d04c8")
