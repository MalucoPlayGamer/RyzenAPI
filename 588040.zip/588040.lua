-- Lua provided by RyzenAPI
-- Game: WILL: A Wonderful World

-- MAIN APPLICATION
addappid(588040)
addappid(639620)
addappid(1277280)

-- MAIN APP DEPOTS / PACKAGES
addappid(588041, 1, "c9980cae454ca6aa70a0bde765512e866a7ac57e9db0abb4676bf7e5b38a73d7")
addappid(588042, 1, "ca9e937adaec2b4050152a9a948700c5d07200847aee3d6c781efdfb593ea4a6")
addappid(588043, 1, "a35a1ce6786b021a90ef6c510617f89d08d57feb2c53edd7c6fac764a0dd9aa7")
