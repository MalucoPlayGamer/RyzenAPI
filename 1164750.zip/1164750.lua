-- Lua provided by RyzenAPI
-- Game: Hospitality VR

-- MAIN APPLICATION
addappid(1164750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1164751, 1, "803c403006424d0b0da89e713229a3f0588adc9469f80a95465e2f8c2bb201fa")

