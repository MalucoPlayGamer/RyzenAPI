-- Lua provided by RyzenAPI
-- Game: Game: Hospitality VR

-- MAIN APPLICATION
addappid(1164750)
-- Game: addappid(1164750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164751, 1, "803c403006424d0b0da89e713229a3f0588adc9469f80a95465e2f8c2bb201fa")
