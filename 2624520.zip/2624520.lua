-- Lua provided by RyzenAPI
-- Game: Game: AppID 2624520

-- MAIN APPLICATION
addappid(2624520)
-- Game: addappid(2624520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624521, 1, "f4f5a0b407394866ea81d4844f4d44f57f8e8cdf843688891939d505edf102c4")
