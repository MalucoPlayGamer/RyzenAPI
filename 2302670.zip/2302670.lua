-- Lua provided by RyzenAPI
-- Game: 2302670

-- MAIN APPLICATION
addappid(2302670)
-- Game: addappid(2302670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302671, 1, "43cd5065e5cd157ce5400ea4c54f98eb92631ff3a9146515f810232cbaa8952a")
