-- Lua provided by RyzenAPI
-- Game: The Alters Benchmark Tool

-- MAIN APPLICATION
addappid(3787490)
-- Game: addappid(3787490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3787491, 1, "ecc6f895187c5416f4b48840825700b34bc128437d49d1c48ebe96bad70bcf2b")
