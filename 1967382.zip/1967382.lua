-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1967382)
-- Game: addappid(1967382)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967382,0,"fc69f89d00ce737d078423ee444fa9132c8e4d693f2fab36e361d7784393f490")
