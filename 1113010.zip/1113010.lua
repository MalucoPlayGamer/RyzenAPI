-- Lua provided by RyzenAPI
-- Game: Chornobyl Liquidators

-- MAIN APPLICATION
addappid(1113010)
addappid(2983690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113011, 1, "d71b286cac53c71bdb76c9ae274bf38949f8977982d9faf4939e9ac20ca0975a")
addappid(2983691, 1, "b8ad177bbc04e67f710ffd4a739eece7a264ac170118896fa0b3e0be9ce6bb0f")

