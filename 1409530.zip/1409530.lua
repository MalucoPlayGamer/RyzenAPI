-- Lua provided by RyzenAPI
-- Game: addappid(1409530)

-- MAIN APPLICATION
addappid(1409530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409531, 1, "8349a8c6273eb493d971830c427088fdeeae91a6b79a1cf6cdc727483cb7a429")
