-- Lua provided by RyzenAPI
-- Game: addappid(2145590)

-- MAIN APPLICATION
addappid(2145590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145591, 1, "dbd72a152acfa2eeefbedd078aad9db33ef14b0d13f928236fb9f2ac417085c7")
