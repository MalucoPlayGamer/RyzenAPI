-- Lua provided by SkyAPI 
-- Game: AppID 1278090
addappid(1278090)
addappid(1278091, 1, "dac7022734776643e4b53a653852c987201e412ba5c65accef4a0eeebf72d542")
