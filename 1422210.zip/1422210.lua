-- Lua provided by RyzenAPI
-- Game: Throw Me in the River

-- MAIN APPLICATION
addappid(1422210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422211,0,"c256ff5d25ecd0537e531fc2e250c797a393944b912bdda5489837a7eef11331")
addappid(1422212,0,"f97ac53c4a5c740b3b4c4f3da87a654e2b1e99306b01deab748d73102055822a")

