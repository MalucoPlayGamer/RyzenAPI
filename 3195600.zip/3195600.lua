-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Fairy Tale Forest Tileset

-- MAIN APPLICATION
addappid(3195600)
-- Game: addappid(3195600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195600,0,"ea6d031defbcbfadf05ea2e51f1fcbce1df6dc83af7475d06dac71e710eae398")
