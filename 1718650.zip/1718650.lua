-- Lua provided by RyzenAPI
-- Game: Nuremberg: VRdict of Nations

-- MAIN APPLICATION
addappid(1718650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718651, 1, "0884716bce6f0fb1229c806871afe29478dab001fa662e94fff7ce05118a22bd")

