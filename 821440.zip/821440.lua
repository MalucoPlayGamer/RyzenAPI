-- Lua provided by RyzenAPI
-- Game: GunnRunner

-- MAIN APPLICATION
addappid(821440)

-- MAIN APP DEPOTS / PACKAGES
addappid(821441,0,"c5ee291bee574ac0c173a1c6c411cb2f9100dd4a8b3e5264bc222f4997f1a617")

