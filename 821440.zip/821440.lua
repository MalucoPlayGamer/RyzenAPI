-- Lua provided by RyzenAPI
-- Game: GunnRunner

-- MAIN APPLICATION
addappid(821440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(821441,0,"c5ee291bee574ac0c173a1c6c411cb2f9100dd4a8b3e5264bc222f4997f1a617")

