-- Lua provided by RyzenAPI
-- Game: Desire Den

-- MAIN APPLICATION
addappid(1010450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010451, 1, "a72d97ce85ef8abdcd824f3f64ba0db9d28524be308dfa4e384192e2754da8e0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2668850)
