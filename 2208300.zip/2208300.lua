-- Lua provided by RyzenAPI
-- Game: Terrarium Builder

-- MAIN APPLICATION
addappid(2208300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208301,0,"2d7ee3f43d09d3b946f3196b957a0d2a4caaa5a8155a8998a60f9aa514cd1fdd")

