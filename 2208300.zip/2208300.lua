-- Lua provided by RyzenAPI
-- Game: Terrarium Builder

-- MAIN APPLICATION
addappid(2208300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208301,0,"2d7ee3f43d09d3b946f3196b957a0d2a4caaa5a8155a8998a60f9aa514cd1fdd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
