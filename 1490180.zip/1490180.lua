-- Lua provided by RyzenAPI
-- Game: For Sparta

-- MAIN APPLICATION
addappid(1490180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490181, 1, "20aa62abb6a93ae61b5ecc35604f5e60451037579268435da71b774c830fe5c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
