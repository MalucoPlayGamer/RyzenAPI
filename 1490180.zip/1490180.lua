-- Lua provided by RyzenAPI
-- Game: Game: For Sparta

-- MAIN APPLICATION
addappid(1490180)
-- Game: addappid(1490180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490181, 1, "20aa62abb6a93ae61b5ecc35604f5e60451037579268435da71b774c830fe5c0")
