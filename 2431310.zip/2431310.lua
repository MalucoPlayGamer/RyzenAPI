-- Lua provided by SkyAPI 
-- Game: ANYU
addappid(2431310)
addappid(2431311, 1, "0f0bd05812e78e3d54cb02745a4bbef38c7ca33bf6421dae395b8e1b35961ddd")
