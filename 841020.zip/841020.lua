-- Lua provided by RyzenAPI
-- Game: Knockdown the Ball

-- MAIN APPLICATION
addappid(841020)

-- MAIN APP DEPOTS / PACKAGES
addappid(841021,0,"555b33b929ad2739181580d27ff89e7980d5397bc11c59f6b73658b94646b9f7")

