-- Lua provided by RyzenAPI
-- Game: Fashion Police Squad

-- MAIN APPLICATION
addappid(1319460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319461, 1, "1afab90233d4674d40b05a8524bc992e425f598f52b7e9aa133622a51969d2a0")
