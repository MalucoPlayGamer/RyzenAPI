-- Lua provided by SkyAPI 
-- Game: Elise
addappid(2734350)
addappid(2734351, 1, "5361ed831bbeef8931bac92645c4fbdc4368fcc67e3f9d2a7aa693c130844c3d")
