-- Lua provided by RyzenAPI
-- Game: Elise

-- MAIN APPLICATION
addappid(2734350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734351, 1, "5361ed831bbeef8931bac92645c4fbdc4368fcc67e3f9d2a7aa693c130844c3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
