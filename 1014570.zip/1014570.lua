-- Lua provided by RyzenAPI
-- Game: AlienAfterlife

-- MAIN APPLICATION
addappid(1014570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1014571, 1, "601725d6c85ef0ac5513a4cb650578246327ef330745b2470672cba59404da67")
