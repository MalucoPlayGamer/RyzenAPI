-- Lua provided by RyzenAPI
-- Game: addappid(629110)

-- MAIN APPLICATION
addappid(629110)

-- MAIN APP DEPOTS / PACKAGES
addappid(629111, 1, "90bea333370cff965b2c0a8eb927144d78a1f610b2a53078bca32ebcf098958f")
