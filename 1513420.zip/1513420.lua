-- Lua provided by RyzenAPI
-- Game: Escalation!

-- MAIN APPLICATION
addappid(1513420)
addappid(1805530)
-- Game: addappid(1513420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513421, 1, "14302e0f2a2d055348ca238241f0da8be063775c8adbf1dde72f55d09b06bb09")
