-- Lua provided by SkyAPI 
-- Game: Escalation!
addappid(1513420)
addappid(1513421, 1, "14302e0f2a2d055348ca238241f0da8be063775c8adbf1dde72f55d09b06bb09")
addappid(1805530)
