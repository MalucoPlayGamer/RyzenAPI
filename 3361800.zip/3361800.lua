-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KSLC Airport

-- MAIN APPLICATION
addappid(3361800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361800,0,"54904fd1de27b414c06a9b310a2bf6c4a889dccc06595d5f66e1ebe7ba9a75d2")

