-- Lua provided by RyzenAPI
-- Game: Nothing Dog

-- MAIN APPLICATION
addappid(2696140)
addappid(2913870)
addappid(2922130)
addappid(2922360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696141,0,"163be0d5d61cd143f83decbc2250200e4c4c5f7dae8b5c0c10beb3bf2ecd0722")

