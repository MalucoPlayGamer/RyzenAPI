-- Lua provided by RyzenAPI
-- Game: Nothing Dog

-- MAIN APPLICATION
addappid(2696140)
addappid(2913870)
addappid(2922130)
addappid(2922360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696141,0,"163be0d5d61cd143f83decbc2250200e4c4c5f7dae8b5c0c10beb3bf2ecd0722")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
