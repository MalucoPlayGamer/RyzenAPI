-- Lua provided by RyzenAPI
-- Game: Nothing DOG

-- MAIN APPLICATION
addappid(2696140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696141, 1, "163be0d5d61cd143f83decbc2250200e4c4c5f7dae8b5c0c10beb3bf2ecd0722")

