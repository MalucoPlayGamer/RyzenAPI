-- Lua provided by RyzenAPI
-- Game: Game: Arcana of Paradise —The Tower— Original Soundtrack

-- MAIN APPLICATION
addappid(2387680)
-- Game: addappid(2387680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387681, 1, "5dcf8a4d404c3e893977a9a563840d8767a047b61250b38a1600d49f437012a5")
