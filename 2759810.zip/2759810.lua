-- Lua provided by RyzenAPI
-- Game: Game: VR Driver School

-- MAIN APPLICATION
addappid(2759810)
-- Game: addappid(2759810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759811, 1, "3da85af60e733ecf36511045aa6126754575f17b32a50508405359bdee602584")
