-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1523080)
-- Game: addappid(1523080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523080,0,"ae593d143583e8921f1ffe9ec0e04807e4653ffd703d30a344fbfb588c77ca44")
