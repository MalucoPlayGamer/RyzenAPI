-- Lua provided by RyzenAPI 
-- Game: AppID 1176170
addappid(1176170)
addappid(1176171, 1, "195266ccc4864fd97e066718a48519e56b27f1474a08e466c52ca9abb06a3136")
