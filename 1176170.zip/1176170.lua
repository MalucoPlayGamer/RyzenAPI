-- Lua provided by RyzenAPI
-- Game: Game: AppID 1176170

-- MAIN APPLICATION
addappid(1176170)
-- Game: addappid(1176170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176171, 1, "195266ccc4864fd97e066718a48519e56b27f1474a08e466c52ca9abb06a3136")
