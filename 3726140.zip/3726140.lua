-- Lua provided by RyzenAPI 
-- Game: AppID 3726140
addappid(3726140)
addappid(3726141, 1, "3c0130123690aeba685931aa6dbfa1da0352ad2fb3c531ed06f09cfa3308f6e2")
