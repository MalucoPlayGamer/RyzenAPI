-- Lua provided by RyzenAPI 
-- Game: AppID 420850
addappid(420850)
addappid(420851, 1, "680623d88676dd23a17c715c34e5f1694857947a9a7f653610c818297720b7ba")
