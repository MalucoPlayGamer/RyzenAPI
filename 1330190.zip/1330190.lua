-- Lua provided by RyzenAPI
-- Game: A Town Uncovered

-- MAIN APPLICATION
addappid(1330190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330191, 1, "1dce5d071f791e4cf7d4c1b571bdcaae26f359a3743bf6f52b9f3c048f1680d6")
