-- Lua provided by RyzenAPI
-- Game: NightSpawn

-- MAIN APPLICATION
addappid(2432990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432991, 1, "bb04156674221223b9d2266604bab1b467c2b3263e4ec03c4d7929ccb46b4c0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
