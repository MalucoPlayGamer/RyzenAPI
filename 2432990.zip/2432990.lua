-- Lua provided by RyzenAPI
-- Game: addappid(2432990)

-- MAIN APPLICATION
addappid(2432990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432991, 1, "bb04156674221223b9d2266604bab1b467c2b3263e4ec03c4d7929ccb46b4c0c")
