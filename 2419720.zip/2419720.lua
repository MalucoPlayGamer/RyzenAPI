-- Lua provided by RyzenAPI
-- Game: 2419720

-- MAIN APPLICATION
addappid(2419720)
-- Game: addappid(2419720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419721, 1, "cea8eafd980619750fc21de9817b2cb628f5511fad456297052d5af8d9aa429c")
