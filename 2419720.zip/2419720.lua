-- Lua provided by RyzenAPI
-- Game: Adrenaline Rampage

-- MAIN APPLICATION
addappid(2419720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419721, 1, "cea8eafd980619750fc21de9817b2cb628f5511fad456297052d5af8d9aa429c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
