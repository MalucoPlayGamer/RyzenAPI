-- Lua provided by RyzenAPI
-- Game: 3273250

-- MAIN APPLICATION
addappid(3273250)
-- Game: addappid(3273250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273251, 1, "9b6525c66c42ba5168d528e17e22d68bc7c2db1671cc499c4ea5832b953f58af")
