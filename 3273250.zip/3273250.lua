-- Lua provided by RyzenAPI 
-- Game: AppID 3273250
addappid(3273250)
addappid(3273251, 1, "9b6525c66c42ba5168d528e17e22d68bc7c2db1671cc499c4ea5832b953f58af")
