-- Lua provided by RyzenAPI
-- Game: addappid(2799580)

-- MAIN APPLICATION
addappid(2799580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799581, 1, "027a773dd3f9f97c0b78bc07bd82349a87221f735d0b1cffbe70ce8893d97f4c")
