-- Lua provided by RyzenAPI 
-- Game: GOI Survivors
addappid(2723480)
addappid(2723481, 1, "c3e081bdfb414e64a7260e26108783059a9d563597c92082c9706161fc44ca23")
