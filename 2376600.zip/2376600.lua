-- Lua provided by RyzenAPI
-- Game: Ptero Pursuit

-- MAIN APPLICATION
addappid(2376600)
-- Game: addappid(2376600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376601, 1, "395f36bed19052016efde56eab357bb3ac1cb2809c3292466120282f8d712f8d")
