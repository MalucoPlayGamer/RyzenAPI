-- Lua provided by RyzenAPI
-- Game: 2081930

-- MAIN APPLICATION
addappid(2081930)
-- Game: addappid(2081930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081931, 1, "0e457a4418403e5c45b0c9cfc6f86dd5d194cf5946db97ebe43db674ecd87768")
