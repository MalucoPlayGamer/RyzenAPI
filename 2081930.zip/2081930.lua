-- Lua provided by RyzenAPI
-- Game: Carlos the Taco

-- MAIN APPLICATION
addappid(2081930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081931, 1, "0e457a4418403e5c45b0c9cfc6f86dd5d194cf5946db97ebe43db674ecd87768")

