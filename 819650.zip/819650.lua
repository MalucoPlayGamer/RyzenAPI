-- Lua provided by SkyAPI 
-- Game: AppID 819650
addappid(819650)
addappid(819651, 1, "a5dbc898e0b19355a3e4211bdc89f4d0a8b29cb9e25409514135d98f9203a352")
