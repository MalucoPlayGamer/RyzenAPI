-- Lua provided by SkyAPI 
-- Game: Swipe Tennis
addappid(2364630)
addappid(2364631, 1, "e1d8af50d6ef6366235e59e079e128e0bb3f769890b76c6fa2448fc32ab4b74a")
