-- Lua provided by RyzenAPI
-- Game: addappid(1091460)

-- MAIN APPLICATION
addappid(1091460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091461, 1, "e02f6fbe2b0395ab54fd2df7e6cd3898c091ab1bbaa57326eddc8509eb5e9f63")
