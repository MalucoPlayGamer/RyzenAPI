-- Lua provided by RyzenAPI
-- Game: AppID 1091460

-- MAIN APPLICATION
addappid(1091460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091461, 1, "e02f6fbe2b0395ab54fd2df7e6cd3898c091ab1bbaa57326eddc8509eb5e9f63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
