-- Lua provided by RyzenAPI
-- Game: CROPS!

-- MAIN APPLICATION
addappid(3057760)
-- Game: addappid(3057760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057761, 1, "885dcd6dca673fce143a4b23fedd73ace8ab43ab07ec64dbcd321d59fbb57ab2")
