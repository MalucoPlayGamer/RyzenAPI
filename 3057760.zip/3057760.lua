-- Lua provided by RyzenAPI 
-- Game: CROPS!
addappid(3057760)
addappid(3057761, 1, "885dcd6dca673fce143a4b23fedd73ace8ab43ab07ec64dbcd321d59fbb57ab2")
