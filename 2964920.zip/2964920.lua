-- Lua provided by RyzenAPI
-- Game: Sundy Stairway

-- MAIN APPLICATION
addappid(2964920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964921,0,"fe35caa5ff31ef8baad269c5daab90f34131cdaae5adbd56d9148c245be5ec78")

