-- Lua provided by RyzenAPI
-- Game: Game: Hidden Cats of Egypt

-- MAIN APPLICATION
addappid(3334610)
addappid(3341400)
-- Game: addappid(3334610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334611, 1, "a58d039b21de7c5ac9f6657f36908cb5f5e0edb26b5209183e5cd45311440968")
