-- Lua provided by RyzenAPI
-- Game: addappid(662200)

-- MAIN APPLICATION
addappid(662200)

-- MAIN APP DEPOTS / PACKAGES
addappid(662201, 1, "563d412f9a2188365e2cb5e6c2ffddc7d16bb49553ce76f20c0e9423dafb3148")
