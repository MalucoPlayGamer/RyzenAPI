-- Lua provided by RyzenAPI
-- Game: AppID 1462520

-- MAIN APPLICATION
addappid(1462520)
-- Game: addappid(1462520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462521, 1, "f57ebbb982442e14423f4c55a99be37e5d9882c067416a8f11b06f78bc1d96ba")
