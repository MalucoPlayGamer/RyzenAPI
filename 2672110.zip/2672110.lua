-- Lua provided by RyzenAPI
-- Game: Game: Fantastic Orc

-- MAIN APPLICATION
addappid(2672110)
-- Game: addappid(2672110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672111, 1, "6c1ca96ec6c34de9c61078b9210bbdaa3cfc07a0a9083cab7b1db404c9805982")
