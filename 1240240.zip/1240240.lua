-- Lua provided by RyzenAPI
-- Game: AppID 1240240

-- MAIN APPLICATION
addappid(1240240)
addappid(1549770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240241, 1, "da7210b66c3ee9aabbce1ba21e5a7538c939c5cee3e1a02feb6528f7dfd2d649")

