-- Lua provided by RyzenAPI
-- Game: addappid(2999640)

-- MAIN APPLICATION
addappid(2999640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999640,0,"52fc013d9924ce3cabc75b710214d182cdf62cae67e14fcaeb8ae77e3b546e56")
