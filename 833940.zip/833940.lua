-- Lua provided by RyzenAPI
-- Game: Vertigo FPS

-- MAIN APPLICATION
addappid(833940)

-- MAIN APP DEPOTS / PACKAGES
addappid(833941,0,"a72f519f37317e59d10dbeb45344aa349779d726ddb5240cc32840e6f2c4309f")

