-- Lua provided by RyzenAPI 
-- Game: Tricky Doors
addappid(2552850)
addappid(2552851, 1, "bb4756392451564a8c1e01a993671b354418e896c20401d1ba22269bcffbb528")
addappid(2552852, 1, "10a793886bfaf4420867f83868d4fc63ce8269be6c77c54e8c7d6fe431645121")
