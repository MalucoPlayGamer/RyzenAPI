-- Lua provided by RyzenAPI
-- Game: Tricky Doors

-- MAIN APPLICATION
addappid(2552850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2552851, 1, "bb4756392451564a8c1e01a993671b354418e896c20401d1ba22269bcffbb528")
addappid(2552852, 1, "10a793886bfaf4420867f83868d4fc63ce8269be6c77c54e8c7d6fe431645121")

