-- Lua provided by RyzenAPI 
-- Game: AppID 679750
addappid(679750)
addappid(679751, 1, "63dc92dc9a5332eb63166a18ef9a0ad92145170ddcafe7fb69b2ddc7a4c2eb12")
