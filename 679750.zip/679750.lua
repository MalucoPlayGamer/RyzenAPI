-- Lua provided by RyzenAPI
-- Game: 679750

-- MAIN APPLICATION
addappid(679750)
-- Game: addappid(679750)

-- MAIN APP DEPOTS / PACKAGES
addappid(679751, 1, "63dc92dc9a5332eb63166a18ef9a0ad92145170ddcafe7fb69b2ddc7a4c2eb12")
