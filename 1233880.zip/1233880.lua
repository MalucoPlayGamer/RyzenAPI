-- Lua provided by RyzenAPI
-- Game: Disgaea 4 Complete+

-- MAIN APPLICATION
addappid(1233880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1233881, 1, "61c99a12f757f3bd4d8e69503c05e32e1184b97a184c79eec397860b1fdb578f")
addappid(1342160, 0, "62982db0fc7f2531b1d0de0ae7dc139e94500fcfbaf74c68e0b61d11a04824d2")

