-- Lua provided by RyzenAPI
-- Game: Military Incremental Complex

-- MAIN APPLICATION
addappid(3469750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3469751,0,"b9a37d2c0f4baddb0514874085a141a561906936c48dea739ef4540b42ba5b1f")
addappid(4194610,0,"5d074d533a7ac388e0fafad76fc8f5a7928eecf08f326061820d296a07c3c24c")

