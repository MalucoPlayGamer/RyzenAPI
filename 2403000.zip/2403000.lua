-- Lua provided by RyzenAPI 
-- Game: Fantasy Amusement Park
addappid(2403000)
addappid(2403001, 1, "2c153e82bf9bc38368e7923fb1c00700baf0ae5d712608a56bbe9391613c1cd4")
addappid(2403002, 1, "ccf014f971e9350274498549183c30bf73d9612c983a1a697d6ee4230aa5c724")
