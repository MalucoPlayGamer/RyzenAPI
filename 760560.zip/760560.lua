-- Lua provided by RyzenAPI
-- Game: AppID 760560

-- MAIN APPLICATION
addappid(760560)
addappid(767510)

-- MAIN APP DEPOTS / PACKAGES
addappid(760561, 1, "c8981fe9aeb24645f6f9800e0e175816cddb7289efc29962a64c8dc654efed9e")
