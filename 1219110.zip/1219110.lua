-- Lua provided by RyzenAPI
-- Game: Friend Sighting

-- MAIN APPLICATION
addappid(1219110)
-- Game: addappid(1219110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219111, 1, "a9a2530310fc2c75f46e9a7c052d8e3cea2e806b96b0b22e7afe052fa84db77d")
