-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms VII with Power Up Kit

-- MAIN APPLICATION
addappid(628030)

-- MAIN APP DEPOTS / PACKAGES
addappid(628031, 1, "952f39467dd1a18fd520be7f6560d3c77c6794bffb81bde0bbef48f91983539c")
addappid(628032, 1, "edf1daac5548394a8f45d4ae32b71483636b15eef181e5c3fa67dacd038bfd5b")
