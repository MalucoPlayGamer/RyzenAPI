-- Lua provided by RyzenAPI
-- Game: Hentai Crush - Uncensored (18+)

-- MAIN APPLICATION
addappid(1015900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015901, 1, "22a7ef016113fb5139e6dceec1455975fd96f1d953f26319348346b76d51053d")
