-- Lua provided by RyzenAPI 
-- Game: Pilot Brothers
addappid(336760)
addappid(336761, 1, "06f72ed666a02486987e6ecf962d1b328a62a8603a3a9a238f65e44f2c09821f")
