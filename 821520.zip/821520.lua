-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Boxing Trivia

-- MAIN APPLICATION
addappid(821520)

-- MAIN APP DEPOTS / PACKAGES
addappid(821521, 1, "60da72cb8a53cfe386a9bb8c05a805b24edb376c708fb9e8d288d114b450d54b")
