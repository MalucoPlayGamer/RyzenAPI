-- Lua provided by RyzenAPI
-- Game: Ore Factory Squad

-- MAIN APPLICATION
addappid(4210580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4210581, 1, "4d8d365d9d752745424c342dfc501048bf7d161dd44021273f535f66ee568665") -- Depot 4210581

