-- Lua provided by RyzenAPI
-- Game: JEF

-- MAIN APPLICATION
addappid(1188760)
-- Game: addappid(1188760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188761, 1, "81065d05cbf7f132456f9541b4ff1b89bfc12e15b942726a1173fd20d08f2817")
