-- Lua provided by RyzenAPI
-- Game: JEF

-- MAIN APPLICATION
addappid(1188760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1188761, 1, "81065d05cbf7f132456f9541b4ff1b89bfc12e15b942726a1173fd20d08f2817")

