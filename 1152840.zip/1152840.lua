-- Lua provided by RyzenAPI
-- Game: Game: Gator Parade

-- MAIN APPLICATION
addappid(1152840)
-- Game: addappid(1152840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152841, 1, "7741bc05f74c96b69bdc1a9bc8187c132d82d7f7d6f2095081344592cbc75238")
