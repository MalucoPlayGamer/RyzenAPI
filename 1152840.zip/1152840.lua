-- Lua provided by RyzenAPI 
-- Game: Gator Parade
addappid(1152840)
addappid(1152841, 1, "7741bc05f74c96b69bdc1a9bc8187c132d82d7f7d6f2095081344592cbc75238")
