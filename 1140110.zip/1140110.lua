-- Lua provided by RyzenAPI 
-- Game: 141
addappid(1140110)
addappid(1140111, 1, "0f0ffbb10497ce3aaba1d7aa6cfd834e44feefae947242c70e7e671e4999f5a1")
