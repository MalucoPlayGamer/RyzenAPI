-- Lua provided by RyzenAPI
-- Game: AppID 251570

-- MAIN APPLICATION
addappid(251570)
addappid(3314750)
addappid(3486400)
addappid(3635260)
addappid(4206290)
addappid(4234560)
addappid(4234570)
addappid(4234580)
addappid(4234590)

-- MAIN APP DEPOTS / PACKAGES
addappid(251571, 1, "2787b64cd24c9e42a114df4d2559813dc0f63405faa2f7e41cc77e6c3cc67bd0")
addappid(251576, 1, "525d3fda8d2195cf5a8bd10c0c158513d9f870f99a036830287c1465c73c6979")
addappid(251577, 1, "53a3478a67db1f8ed8030e845ec1be174a60cea2448401ffd4dda0c4838cbb84")
addappid(251578, 1, "4550672ef4a498246530208707b36b490dd3bb73c6b54ba6b832dd48db88f71a")

