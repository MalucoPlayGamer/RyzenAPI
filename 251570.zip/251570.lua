-- Lua provided by RyzenAPI
-- Game: 7 Days to Die

-- MAIN APPLICATION
addappid(2721510)
addappid(3486400) -- The Marauder Armor Set
addappid(3635260) -- The Desert Armor Set
addappid(4206290) -- The Classic Survivor Armor Set
addappid(4234560) -- The Butcher Armor Set
addappid(4234570) -- The Hellreaver Armor Set
addappid(4234580) -- The Holiday Hat Pack
addappid(4234590) -- The Jolly Raider Armor Set
addappid(4767590) -- The Beach Armor Set
addappid(4924490) -- The Big Beak Armor Set

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(251570, 1, "e53177a4e7b3979bb3284352de1dbcf65f8d3b1b57d5d63971906f5b75c53c86")
addappid(251571, 1, "2787b64cd24c9e42a114df4d2559813dc0f63405faa2f7e41cc77e6c3cc67bd0") -- (windows, 32-bit)
addappid(251576, 1, "525d3fda8d2195cf5a8bd10c0c158513d9f870f99a036830287c1465c73c6979") -- (windows, 64-bit)
addappid(251577, 1, "53a3478a67db1f8ed8030e845ec1be174a60cea2448401ffd4dda0c4838cbb84") -- (macos)
addappid(251578, 1, "4550672ef4a498246530208707b36b490dd3bb73c6b54ba6b832dd48db88f71a") -- (linux)
addappid(2721511, 1, "41d26a497295b9a2272150763884d4ade69473388e6fa3eb1d62270127c1fe18")
addappid(2721512, 1, "2e2cff02218afbdbac08aa587c8fd5a9b82ea9a266eb3953620e6cfa67abcdbe")

