-- Lua provided by RyzenAPI
-- Game: A NOT Troll Game

-- MAIN APPLICATION
addappid(2487640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487642,0,"3b120ae2e8dbd58067c266e013bfe6352f961a817cfb76ae4f42fb24a4d36fdc")
addappid(2487644,0,"fec6354a8cb86d5ee0b97b3d58a12870e4112ea089f7fbcd71a74e67bd495fff")

