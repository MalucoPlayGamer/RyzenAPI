-- Lua provided by RyzenAPI
-- Game: Game: 18+ for Clip maker

-- MAIN APPLICATION
addappid(1549900)
-- Game: addappid(1549900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549901, 1, "012c3b6407fb1d6cc2d21513c17957d3e3c2f79091d026b6fbfc090c82fe7b27")
