-- Generated with Luie @ https://lua.tools/
-- 4210300 - Pawbay: Cat Chaos
-- Generated 2026-08-22 15:28:03 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4210300)
addtoken(4210300, "18258893957330491208")

-- Main Depots
addappid(4210301, 1, "32f4821eacf51e5cd6c21aa02565834a95d83e64d3f847ce1ce86f1df5ea8c69") -- (windows, 64-bit)
setManifestid(4210301, "8376436679815647380", 2132719885)

-- DLC's (no depot keys required)
addappid(4685960) -- Pawbay - Silly Hats
