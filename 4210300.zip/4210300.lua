-- Lua provided by RyzenAPI
-- Game: Pawbay: Cat Chaos

-- MAIN APPLICATION
addappid(4210300)
addappid(4685960) -- Pawbay - Silly Hats

-- MAIN APP DEPOTS / PACKAGES
addappid(4210301, 1, "32f4821eacf51e5cd6c21aa02565834a95d83e64d3f847ce1ce86f1df5ea8c69") -- (windows, 64-bit)
addtoken(4210300, "18258893957330491208")

