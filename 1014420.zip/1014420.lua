-- Lua provided by RyzenAPI
-- Game: Blind Date

-- MAIN APPLICATION
addappid(1014420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014421, 1, "c4c284b235e508c20a2b80ca2ec5d9074b090c36d8cebf298279f04a766a4f78")
