-- Lua provided by RyzenAPI 
-- Game: Crysis 2 Remastered
addappid(2096600)
addappid(2096601, 1, "1d418f319c368a25582ede887aacde5011e6b3489aa80c893346692a67c1e625")
