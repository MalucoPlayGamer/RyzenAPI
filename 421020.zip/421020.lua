-- Lua provided by RyzenAPI
-- Game: AppID 421020

-- MAIN APPLICATION
addappid(421020)

-- MAIN APP DEPOTS / PACKAGES
addappid(421021, 1, "0836f2004c5d0a55b9fc2374e07b08f6ce7e0c04dd442cb725f003d5781b33e6")
addappid(421022, 1, "8f3067492da33e41e7bc26c796dc40aab4d202b16b7cfc1978936c3e04ae81fd")
addappid(421024, 1, "dd92016ed8eb719d2bd5482ac3999a77c322a906434f8b05d754fb13ad18cd65")
addappid(421026, 1, "b5dfe4213a953677854ed8b33ac59370fe102d2bdbef0ceb646ddbed8e2895bc")
addappid(421027, 1, "e30479390bde0fe4c4b22675d37c23e824ece8140939c5aa98a07edaaab1258e")
addappid(421029, 1, "2a07b92ca7432e18e8bca32ef24a74f9bc21e2c0711321c0f5a8df0dfdd41f49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(437120)
addappid(437121)
addappid(437122)
