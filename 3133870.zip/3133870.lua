-- Lua provided by RyzenAPI
-- Game: addappid(3133870)

-- MAIN APPLICATION
addappid(3133870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133871, 1, "9971d00314da71182aa150b81f2c7584d34c7212d5c58358c8faa14faac3c4b0")
