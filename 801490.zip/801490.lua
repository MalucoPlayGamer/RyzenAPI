-- Lua provided by RyzenAPI
-- Game: HellCrunch

-- MAIN APPLICATION
addappid(801490)

-- MAIN APP DEPOTS / PACKAGES
addappid(801491,0,"5a68ac92e4e32856c618a75d5a16314d18790285316683ba2a5142da691eaf9a")

