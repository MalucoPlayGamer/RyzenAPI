-- Lua provided by RyzenAPI
-- Game: AppID 331560

-- MAIN APPLICATION
addappid(331560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(331561, 1, "82f852e10af2edc0a4b689d0e56b15466075142737fb30261f676feb7deacab2")
addappid(331562, 1, "27ea65f1a958e59d5d6726bcbcee74cd3cfc60e163c1caf3b99c93aae28c40d0")

