-- Lua provided by RyzenAPI
-- Game: 331560

-- MAIN APPLICATION
addappid(331560)
-- Game: addappid(331560)

-- MAIN APP DEPOTS / PACKAGES
addappid(331561, 1, "82f852e10af2edc0a4b689d0e56b15466075142737fb30261f676feb7deacab2")
addappid(331562, 1, "27ea65f1a958e59d5d6726bcbcee74cd3cfc60e163c1caf3b99c93aae28c40d0")
