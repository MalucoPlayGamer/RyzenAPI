-- Lua provided by RyzenAPI
-- Game: addappid(652550)

-- MAIN APPLICATION
addappid(652550)

-- MAIN APP DEPOTS / PACKAGES
addappid(652551, 1, "0412c614ee20e0a242d3b3b5ef3775ea2bedb2aafc2ef1e94c0d083592a46c5c")
