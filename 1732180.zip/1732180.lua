-- Lua provided by SkyAPI 
-- Game: Kaiju Princess
addappid(1732180)
addappid(1732181, 1, "ac0a1379869b405692517e125dc9c9e23e1f224072f1d174f90e75d667b85eeb")
addappid(1732182, 1, "c18145d752e7bc0bd85a06a9575249387c5d630ef9422ccac970db703692cca0")
