-- Lua provided by RyzenAPI
-- Game: 3064670

-- MAIN APPLICATION
addappid(3064670)
-- Game: addappid(3064670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064671, 1, "ff10221690e60e5af04dcce6e9ec2f13df7b4df4dfe83c13c09b888cf9f92945")
