-- Lua provided by RyzenAPI
-- Game: 581370

-- MAIN APPLICATION
addappid(581370)
-- Game: addappid(581370)

-- MAIN APP DEPOTS / PACKAGES
addappid(581371, 1, "b3624d06c9a5dcbef86b800d02d967e3ab212c471a8353795b576e4a9beccfff")
