-- Lua provided by RyzenAPI 
-- Game: Destination: Pluto The VR Experience
addappid(580410)
addappid(580411, 1, "ca81e7f46ad23d4c79328289eb721d4a3b73ca86854fc1fec2aeb477784451af")
