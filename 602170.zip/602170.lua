-- Lua provided by RyzenAPI
-- Game: addappid(602170)

-- MAIN APPLICATION
addappid(602170)

-- MAIN APP DEPOTS / PACKAGES
addappid(602171, 1, "c91f69189c83ac5474be93f7e1af869c6e269b47010dd3f26fa742f91a4d957a")
