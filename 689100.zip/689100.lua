-- Lua provided by RyzenAPI
-- Game: addappid(689100)

-- MAIN APPLICATION
addappid(689100)

-- MAIN APP DEPOTS / PACKAGES
addappid(689101, 1, "386b0978651aa94c0ed66213f1bb0f1f25ef6e712b3ca6e53ad8c97528f6d19f")
