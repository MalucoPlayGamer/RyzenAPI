-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1494611)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494611,0,"5cc0338819c1cbf7a8b34b4facb9a3c9b0d941c44aa38f160ce8d86ce73450b3")

