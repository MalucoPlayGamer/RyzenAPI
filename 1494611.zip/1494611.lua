-- Lua provided by RyzenAPI
-- Game: addappid(1494611)

-- MAIN APPLICATION
addappid(1494611)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494611,0,"5cc0338819c1cbf7a8b34b4facb9a3c9b0d941c44aa38f160ce8d86ce73450b3")
