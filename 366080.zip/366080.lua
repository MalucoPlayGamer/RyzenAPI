-- Lua provided by RyzenAPI
-- Game: addappid(366080)

-- MAIN APPLICATION
addappid(366080)

-- MAIN APP DEPOTS / PACKAGES
addappid(366081, 1, "adaf846bda6ac0ab34644b9662d0752e03cd7b732d809f3dd1675b093f61654c")
addappid(366082, 1, "92f0ab296ca0c0ffbe1927f24afd47b4145fb11556d6b64bccd6862971556047")
