-- Lua provided by RyzenAPI
-- Game: 2308360

-- MAIN APPLICATION
addappid(2308360)
-- Game: addappid(2308360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308361, 1, "af2432fdad2952362f14d1886ea39fcf5b8d9a7c5d8c2c52ba6cf61ffcc5d770")
