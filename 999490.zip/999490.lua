-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Under the Cruel Star

-- MAIN APPLICATION
addappid(999490)
-- Game: addappid(999490)

-- MAIN APP DEPOTS / PACKAGES
addappid(999490,0,"19f1731001addd5715f58dd865535a8960fd1c2387a397053fdef37033713de4")
