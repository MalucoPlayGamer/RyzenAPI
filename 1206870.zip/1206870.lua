-- Lua provided by RyzenAPI
-- Game: Pinball universe

-- MAIN APPLICATION
addappid(1206870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206871, 1, "44fc667abfc9c01ab9615bb2ccb5d1817aa13323748084168f5f6fb6717cc932")

