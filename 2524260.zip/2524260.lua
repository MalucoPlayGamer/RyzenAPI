-- 2524260's Lua and Manifest Created by Hubcap Manifest
-- CORA
-- Created: August 17, 2026 at 03:53:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2524260, 1, "7b7037f143da560b35c090f715dceb45bcbb9207684cdd7bdb00d1ce263e6214") -- CORA
-- MAIN APP DEPOTS
addappid(2524261, 1, "46329884e4393454ca045e9dc048e6b45043e8d22e262a20c1632bae193b3b58") -- Depot 2524261
setManifestid(2524261, "6516274674512052017", 821450971)
addappid(2524262, 1, "9090255c79b234ad93b4261db7ab8aa4dc52a0a87c102ba5cd29a4302521317c") -- Depot 2524262
setManifestid(2524262, "84542217388949375", 857253707)