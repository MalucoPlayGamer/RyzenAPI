-- Lua provided by RyzenAPI
-- Game: Game: The Pathless

-- MAIN APPLICATION
addappid(1492680)
-- Game: addappid(1492680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492681, 1, "0aa0446bafce177e538108325e6034a420243f3ca4290c0d49a953a04b0f68ac")
