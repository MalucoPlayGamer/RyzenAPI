-- Lua provided by RyzenAPI
-- Game: 997180

-- MAIN APPLICATION
addappid(997180)
-- Game: addappid(997180)

-- MAIN APP DEPOTS / PACKAGES
addappid(997181, 1, "fc009a2dbb790a725ee834a487c88d873b21f9836d3badd8ed1eed93ff2b151e")
