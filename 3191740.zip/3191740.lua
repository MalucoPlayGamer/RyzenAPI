-- Lua provided by RyzenAPI
-- Game: 3191740

-- MAIN APPLICATION
addappid(3191740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191742,0,"823e87bf8174c66f365fd0af9c49b5f98b150699c26abc7a74b1fab8cc8ceccb")

