-- Lua provided by RyzenAPI
-- Game: Game: God Vs Zombies

-- MAIN APPLICATION
addappid(843500)
-- Game: addappid(843500)

-- MAIN APP DEPOTS / PACKAGES
addappid(843501, 1, "8a42b3f7f05b40fae34764055a400f8ff4c7c84e9d3447bd2590fefbf54bcd0f")
