-- Lua provided by RyzenAPI 
-- Game: STRIKERS 1945 III
addappid(1279400)
addappid(1279401, 1, "7cb480d3261e7ab33e344cc6f2b389605c456e39458c87a93c8b2f1d2c78d689")
