-- Lua provided by SkyAPI 
-- Game: Reverse Problem
addappid(3355020)
addappid(3355021, 1, "f846c5de102c5f6a47efcf506e0e6f3153b68a69e271706dc803d76411c3d860")
