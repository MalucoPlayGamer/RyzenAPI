-- Lua provided by RyzenAPI
-- Game: Reverse Problem

-- MAIN APPLICATION
addappid(3355020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3355021, 1, "f846c5de102c5f6a47efcf506e0e6f3153b68a69e271706dc803d76411c3d860")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
