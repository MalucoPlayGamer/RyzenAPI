-- Lua provided by RyzenAPI
-- Game: Scars of Mars - Original Soundtrack

-- MAIN APPLICATION
addappid(3016130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016131, 1, "d15a6fb925e88689cf125108990b5123c351b62ad320933c29c4b8a00b295805")
