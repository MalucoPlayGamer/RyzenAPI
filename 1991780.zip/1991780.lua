-- Lua provided by RyzenAPI
-- Game: 1991780

-- MAIN APPLICATION
addappid(1991780)
-- Game: addappid(1991780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991781, 1, "98d1ac7b2dc3d9d7b7918f07c8f55e740af053bd3dec493f29a78949f5111023")
