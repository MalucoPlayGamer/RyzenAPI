-- Lua provided by RyzenAPI
-- Game: 1532630

-- MAIN APPLICATION
addappid(1532630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532630,0,"aca12707dfe1d2fcd0885ece4faf376e10e67a306898ffbdfab9936cc2b97c27")

