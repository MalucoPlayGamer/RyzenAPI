-- Lua provided by RyzenAPI
-- Game: addappid(1159420)

-- MAIN APPLICATION
addappid(1159420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159421, 1, "7605714f3ee61de34134627cec623268417aff46ed724cb8fc8f2b70f239ecb1")
