-- Lua provided by RyzenAPI 
-- Game: AppID 1159420
addappid(1159420)
addappid(1159421, 1, "7605714f3ee61de34134627cec623268417aff46ed724cb8fc8f2b70f239ecb1")
