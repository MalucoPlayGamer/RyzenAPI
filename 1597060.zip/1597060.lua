-- Lua provided by RyzenAPI
-- Game: Bubbaruka!

-- MAIN APPLICATION
addappid(1597060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597061, 1, "b91fe1f8aa4df27011388cbce660baba63b81c9ccccc9912529b24f0be9e51a3")
addappid(1597062, 1, "51e8881c4444e69210f46f48d3537e9c26fc6f857d2c8181bb960b3e9f79dfbc")

