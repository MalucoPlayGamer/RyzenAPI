-- Lua provided by RyzenAPI
-- Game: Game: All of Us Are Dead... Demo

-- MAIN APPLICATION
addappid(2273620)
-- Game: addappid(2273620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273621, 1, "f9a59ee41c898d82c277e600f5a4ef99f7150186afcc0ada334c2797f83069dd")
