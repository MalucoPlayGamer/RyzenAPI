-- Lua provided by RyzenAPI
-- Game: Hollow's Land

-- MAIN APPLICATION
addappid(338840)

-- MAIN APP DEPOTS / PACKAGES
addappid(338841, 1, "a7aa455c446dede1cf0170bc5716c5246730fcddebf7c32b4e13b93a03bb5b65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
