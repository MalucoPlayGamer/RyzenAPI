-- Lua provided by RyzenAPI
-- Game: 338840

-- MAIN APPLICATION
addappid(338840)
-- Game: addappid(338840)

-- MAIN APP DEPOTS / PACKAGES
addappid(338841, 1, "a7aa455c446dede1cf0170bc5716c5246730fcddebf7c32b4e13b93a03bb5b65")
