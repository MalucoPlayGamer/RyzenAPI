-- Lua provided by RyzenAPI
-- Game: 1654810

-- MAIN APPLICATION
addappid(1654810)
-- Game: addappid(1654810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654812,0,"03c9ba399cdd3402d15c6f6cb3911cd1d38a0ee2c9c4c2441680b25c6711c1c6")
