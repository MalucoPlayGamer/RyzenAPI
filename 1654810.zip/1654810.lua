-- Lua provided by RyzenAPI
-- Game: Mix Universe

-- MAIN APPLICATION
addappid(1654810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654812,0,"03c9ba399cdd3402d15c6f6cb3911cd1d38a0ee2c9c4c2441680b25c6711c1c6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
