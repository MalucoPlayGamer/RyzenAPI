-- Lua provided by RyzenAPI
-- Game: Reforged TD - Tower Defense

-- MAIN APPLICATION
addappid(1044110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044112,0,"7290c219b7990afbc69b7b5107cfcdfa1d3b4c084c9aa034620f1d2b23409901")

