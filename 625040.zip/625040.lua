-- Lua provided by RyzenAPI
-- Game: Ophidia

-- MAIN APPLICATION
addappid(625040)

-- MAIN APP DEPOTS / PACKAGES
addappid(625041,0,"1cc4c813a772072f804c69682bc0f99bc47d7cfe1fbc9b7e5b96df035c2b0460")

