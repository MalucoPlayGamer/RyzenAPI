-- Lua provided by RyzenAPI
-- Game: GHOSTWINTER

-- MAIN APPLICATION
addappid(1470060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1470061, 1, "030553c420027cfedaf5f8c543af135c59fea6f6ce48a1ecdc958f717301394d")

