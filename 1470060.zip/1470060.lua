-- Lua provided by RyzenAPI
-- Game: Game: GHOSTWINTER

-- MAIN APPLICATION
addappid(1470060)
-- Game: addappid(1470060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470061, 1, "030553c420027cfedaf5f8c543af135c59fea6f6ce48a1ecdc958f717301394d")
