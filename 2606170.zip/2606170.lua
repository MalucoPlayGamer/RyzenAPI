-- Lua provided by RyzenAPI
-- Game: 2606170

-- MAIN APPLICATION
addappid(2606170)
-- Game: addappid(2606170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606171, 1, "34f63d146fd51f29d54d3c0d7f8b3f4e803cd2c61412a9a86a6c896bb14f6cd5")
