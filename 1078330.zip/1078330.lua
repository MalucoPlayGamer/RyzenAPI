-- Lua provided by RyzenAPI
-- Game: Game: Liz ~The Tower and the Grimoire~

-- MAIN APPLICATION
addappid(1078330)
-- Game: addappid(1078330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078331, 1, "b8c23922d876cbce4a7c6f952daeec25e70af75f1400396a894c4a61c9bbab61")
addappid(1078332, 1, "6a48ea41e83cbc43e6b01329e8ab95fb5fd0e845c14992586bad08e01e65f746")
addappid(1078333, 1, "76aa84d60d3816cd6d92726e2cee89887255ad206d5730e1c7e439eefe2a92c6")
addappid(1240200, 0, "959f781443e523511f9034ab1d3443e62d48b22e92fe8066d308e41a3aa55b95")
