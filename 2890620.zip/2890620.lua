-- Lua provided by RyzenAPI
-- Game: Springs of Ardor Demo

-- MAIN APPLICATION
addappid(2890620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890621, 1, "6bd96526fdc4940bd6b60c08d65dc6b5f944b9069a93492e24d05ae950c8f733")

