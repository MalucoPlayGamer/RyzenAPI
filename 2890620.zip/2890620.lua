-- Lua provided by SkyAPI 
-- Game: Springs of Ardor Demo
addappid(2890620)
addappid(2890621, 1, "6bd96526fdc4940bd6b60c08d65dc6b5f944b9069a93492e24d05ae950c8f733")
