-- Lua provided by RyzenAPI
-- Game: Magic Frame

-- MAIN APPLICATION
addappid(1611540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611541, 1, "c05479b5a958a15e784a1c2d6caf7c778dc0fe846d416c7ec2a6ad9792543266")

