-- Lua provided by RyzenAPI
-- Game: 萌萌２次大戰（略）３ Moe Moe World War II-3

-- MAIN APPLICATION
addappid(1088630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088631, 1, "a67a291de0967c4787ae45c7979b67522b291fe5ea5cafa5814922e9393420af")
