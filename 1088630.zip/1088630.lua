-- Lua provided by RyzenAPI
-- Game: 1088630

-- MAIN APPLICATION
addappid(1088630)
-- Game: addappid(1088630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088631, 1, "a67a291de0967c4787ae45c7979b67522b291fe5ea5cafa5814922e9393420af")
