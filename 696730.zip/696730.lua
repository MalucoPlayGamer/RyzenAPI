-- Lua provided by RyzenAPI
-- Game: Deep Ones

-- MAIN APPLICATION
addappid(696730)
addappid(701320)

-- MAIN APP DEPOTS / PACKAGES
addappid(696731, 1, "824808064f05201cc8fa6eaa840c7b3bd698773c261a38a519bb2e9394e9fc99")

