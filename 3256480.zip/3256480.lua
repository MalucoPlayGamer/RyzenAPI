-- Lua provided by RyzenAPI
-- Game: AppID 3256480

-- MAIN APPLICATION
addappid(3256480)
-- Game: addappid(3256480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256481, 1, "bbc7ab2dc24107947dd3e7c36886ebcd1cad12f48e9b0aa02a041bf1d330fcb8")
