-- Lua provided by RyzenAPI
-- Game: 370650

-- MAIN APPLICATION
addappid(370650)

-- MAIN APP DEPOTS / PACKAGES
addappid(370650,0,"b6da2caade99cf3f5b70f7edc67c0355360e2199ee0bf9d7d43751afcfd2d76f")

