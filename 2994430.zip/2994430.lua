-- Lua provided by RyzenAPI
-- Game: Sarah's Adventure: Time Travel

-- MAIN APPLICATION
addappid(2994430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994431, 1, "dec0ae6ee94945c91be976638454df129ce4de5662025dbd161eccc0413fdabd")

