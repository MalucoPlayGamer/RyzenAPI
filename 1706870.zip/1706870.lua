-- Lua provided by RyzenAPI
-- Game: Sven's SudokuPad

-- MAIN APPLICATION
addappid(1706870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706871, 1, "590cb32a077078ced27ff7c6bc7cb5a5042f0d906ee57a8b6c6fcea61bd40424")
