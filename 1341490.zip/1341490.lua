-- Lua provided by SkyAPI 
-- Game: Hellsweeper VR
addappid(1341490)
addappid(1341491, 1, "5da5f13273be3ce9cf6af7da48f8895ba3ebd10ec643cc0f6c86f425983b9867")
addappid(2465720, 0, "382ac3342286b621f14b7c8d7b2f008abbc8186313b4f6010c0fd8544be1f061")
