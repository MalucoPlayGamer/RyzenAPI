-- Lua provided by RyzenAPI
-- Game: addappid(1240970)

-- MAIN APPLICATION
addappid(1240970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240971, 1, "21c31cbb2bd34c31a9091c393dc7b67925fbf835c1224953d41ab17980ab0f19")
