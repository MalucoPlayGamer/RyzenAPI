-- Lua provided by RyzenAPI
-- Game: Tails Noir Preludes

-- MAIN APPLICATION
addappid(2020030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020031, 1, "7205cb1188048b571a80e58ebcaefb45c970c3c219c65fbdc578fd52c8e240d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
