-- Lua provided by RyzenAPI
-- Game: 2020030

-- MAIN APPLICATION
addappid(2020030)
-- Game: addappid(2020030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020031, 1, "7205cb1188048b571a80e58ebcaefb45c970c3c219c65fbdc578fd52c8e240d1")
