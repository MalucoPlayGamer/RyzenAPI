-- Lua provided by RyzenAPI 
-- Game: AppID 2300080
addappid(2300080)
addappid(2300081, 1, "6b711297768729e5324ee077a1f61cb66e8ba7aecb1a0796643b167e27d240b4")
