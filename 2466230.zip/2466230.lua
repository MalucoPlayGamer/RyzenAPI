-- Lua provided by RyzenAPI
-- Game: 2466230

-- MAIN APPLICATION
addappid(2466230)
-- Game: addappid(2466230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466231, 1, "edd2ed6cdd7f1bfb628a75ece8e81e882b13b4a27cb18f87ee4603f263ca35eb")
