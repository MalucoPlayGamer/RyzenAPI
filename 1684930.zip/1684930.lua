-- Lua provided by RyzenAPI
-- Game: 1684930

-- MAIN APPLICATION
addappid(1684930)
-- Game: addappid(1684930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684931, 1, "a66658f152af830e0aaeff5d5e5cb8c4b31bf7e379547fe442ce70c0804dde01")
