-- Lua provided by RyzenAPI
-- Game: Outliver: Redemption

-- MAIN APPLICATION
addappid(1011370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1011371, 1, "8026414fd0e7cf5af049ef012803e9a10074aa62cd8409b24c9477378f816383")

