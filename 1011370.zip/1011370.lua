-- Lua provided by RyzenAPI
-- Game: Game: Outliver: Redemption

-- MAIN APPLICATION
addappid(1011370)
-- Game: addappid(1011370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011371, 1, "8026414fd0e7cf5af049ef012803e9a10074aa62cd8409b24c9477378f816383")
