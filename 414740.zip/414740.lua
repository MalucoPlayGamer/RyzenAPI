-- Lua provided by RyzenAPI
-- Game: RAID: World War II

-- MAIN APPLICATION
addappid(414740)

-- MAIN APP DEPOTS / PACKAGES
addappid(414741, 1, "ff8f400443edb658fefc39c3014ae7265c3fb432677ae79e767f11c98afbef6c")
addappid(707081, 0, "f50e65e650663e1e56a87ae26e05a1d7d59d477a85329af1711ec3317c6707c3")

