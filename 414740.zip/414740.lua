-- Lua provided by RyzenAPI
-- Game: RAID: World War II

-- MAIN APPLICATION
addappid(414740)
addappid(707070)
addappid(707080)
addappid(804050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(414741, 1, "ff8f400443edb658fefc39c3014ae7265c3fb432677ae79e767f11c98afbef6c")
addappid(707081, 0, "f50e65e650663e1e56a87ae26e05a1d7d59d477a85329af1711ec3317c6707c3")

