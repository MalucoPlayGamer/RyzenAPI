-- Lua provided by RyzenAPI
-- Game: 2739760

-- MAIN APPLICATION
addappid(2739760)
-- Game: addappid(2739760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739761, 1, "2d1b1abaab16434ada778fc9bdea926998ee2656b27d1defbab0ae46833f6be3")
