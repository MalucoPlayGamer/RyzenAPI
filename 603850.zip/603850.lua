-- Lua provided by RyzenAPI
-- Game: Age of History II

-- MAIN APPLICATION
addappid(603850)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(603851, 1, "03e3821f3ac71152e806701403e0c9252f4839c75291b5b3a585aacd9e962080")
addappid(603852, 1, "25d7f7c9f3765d54ef8c92a699fe990ee5a27de93489240ee9f20d80a84c6ebe")
addappid(603853, 1, "ed5f7d8ff33e68853445666e40b2b2e17085a515184b7438c527ccf46340effc")
