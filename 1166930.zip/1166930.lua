-- Lua provided by RyzenAPI 
-- Game: RhythmSnake Demo
addappid(1166930)
addappid(1166931, 1, "8fe02733254c66c4a12326586eef9f5ff93b87539b517b3ee929d4586dcd90a8")
