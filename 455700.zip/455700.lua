-- Lua provided by RyzenAPI
-- Game: 455700

-- MAIN APPLICATION
addappid(455700)
-- Game: addappid(455700)

-- MAIN APP DEPOTS / PACKAGES
addappid(455701, 1, "bd9b805bca349ad815718cb2218781359cdd5e3ef607e53324fda8edbf003fab")
