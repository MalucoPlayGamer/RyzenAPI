-- Lua provided by RyzenAPI
-- Game: Flashpoint Campaigns: Red Storm Player's Edition

-- MAIN APPLICATION
addappid(330720)
addappid(411470)
-- Game: addappid(330720)

-- MAIN APP DEPOTS / PACKAGES
addappid(330721, 1, "13e974923c0a832f0939820608342d3f9ecb02a3e53f55f902c33522c3c29c56")
