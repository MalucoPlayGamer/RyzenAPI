-- Lua provided by RyzenAPI
-- Game: Flashpoint Campaigns: Red Storm Player's Edition

-- MAIN APPLICATION
addappid(330720)
addappid(411470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(330721, 1, "13e974923c0a832f0939820608342d3f9ecb02a3e53f55f902c33522c3c29c56")

