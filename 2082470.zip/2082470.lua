-- Lua provided by RyzenAPI 
-- Game: VEIN Demo
addappid(2082470)
addappid(2082471, 1, "5d097b779608575432c12250d9083fc83be9e37fd4a4e0cf9b8c1bd68b23636e")
addappid(2082472, 1, "7623c6d28c2ef1a099e590e96c14a902a70a7d54c0249804b4e2f00c84778278")
