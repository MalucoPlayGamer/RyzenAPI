-- 3724490's Lua and Manifest Created by Hubcap Manifest
-- Idle Gumball Machine
-- Created: May 13, 2026 at 02:59:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3724490, 1, "9beeeaea67b21df0374555f991778bd5f444735e74553257206b5f2d14078cf3") -- Idle Gumball Machine
-- MAIN APP DEPOTS
addappid(3724491, 1, "016a4cc686eea23ebbb5d1dfc1eedde62b3ec9d7242435afd2dffee1d5907d3d") -- Depot 3724491
--setManifestid(3724491, "7291521689992957492", 402452272)