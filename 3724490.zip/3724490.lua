-- Lua provided by RyzenAPI
-- Game: Idle Gumball Machine

-- MAIN APP DEPOTS / PACKAGES
addappid(3724490, 1, "9beeeaea67b21df0374555f991778bd5f444735e74553257206b5f2d14078cf3") -- Idle Gumball Machine
addappid(3724491, 1, "016a4cc686eea23ebbb5d1dfc1eedde62b3ec9d7242435afd2dffee1d5907d3d") -- Depot 3724491

