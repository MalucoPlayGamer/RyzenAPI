-- Lua provided by RyzenAPI
-- Game: Assemble with Care

-- MAIN APPLICATION
addappid(1202900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1202901, 1, "2f583cb6cc4307e5295753475921de7bc8a2501f7653bab8483f1afb6b8c624e")

