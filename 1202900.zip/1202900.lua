-- Lua provided by RyzenAPI
-- Game: Assemble with Care

-- MAIN APPLICATION
addappid(1202900)
-- Game: addappid(1202900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202901, 1, "2f583cb6cc4307e5295753475921de7bc8a2501f7653bab8483f1afb6b8c624e")
