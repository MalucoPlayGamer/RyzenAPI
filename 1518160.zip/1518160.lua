-- Lua provided by RyzenAPI
-- Game: Game: AppID 1518160

-- MAIN APPLICATION
addappid(1518160)
-- Game: addappid(1518160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518161, 1, "0d250962869367c37003c6047fa2db2a1c901fe5b2874ae40e69976dbb1e60f6")
