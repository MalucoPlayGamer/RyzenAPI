-- Lua provided by SkyAPI 
-- Game: AppID 1518160
addappid(1518160)
addappid(1518161, 1, "0d250962869367c37003c6047fa2db2a1c901fe5b2874ae40e69976dbb1e60f6")
