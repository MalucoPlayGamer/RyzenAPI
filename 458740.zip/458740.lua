-- Lua provided by RyzenAPI
-- Game: OPUS: The Day We Found Earth Original Soundtrack

-- MAIN APPLICATION
addappid(458740)

-- MAIN APP DEPOTS / PACKAGES
addappid(458741, 1, "bc1872821893478491e5f4d6132c4b3e258d39e0bde42984a509c7d8f1c75a2e")
addappid(458742, 1, "54af1e18882b0d4948a60d7fcd95c82e72d7c97a37f7453c98eb1909612b3adb")
