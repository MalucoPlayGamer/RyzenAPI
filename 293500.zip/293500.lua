-- Lua provided by RyzenAPI 
-- Game: AppID 293500
addappid(293500)
addappid(293501, 1, "1ffe0349a66a3437af5a41d6f92404e91583e4df17edf9f0946af8dfe369ffbf")
addappid(293502, 1, "6e00b364638c53089b7de43fe38bf7216f6ab6e2ab88a1222a5becf710e35756")
