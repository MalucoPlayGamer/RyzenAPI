-- Lua provided by RyzenAPI
-- Game: Pile Up Demo

-- MAIN APPLICATION
addappid(1381870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381871, 1, "10cff5b51803dfe7755dbc6a62726f4610220f0586a24e8018da4cf4f0a3addd")
