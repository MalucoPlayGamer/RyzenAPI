-- Lua provided by RyzenAPI
-- Game: addappid(41740)

-- MAIN APPLICATION
addappid(41740)

-- MAIN APP DEPOTS / PACKAGES
addappid(41741, 1, "3f6e1a4a0352d1dfabc4b2d1c5299ffede5a8c53360b383e7ef68b314a6a47e1")
addappid(41742, 1, "f7967757bf3f277dc8bb25b7a1edf673d6aa29a077d6eeef735aee5724c37506")
addappid(41743, 1, "cc7b3dac5e4c486e24fe2bf23e2a7e06f59331e3074310086ef5e57bfce5c074")
addappid(41744, 1, "a8581557e3f508fd9ad5e52bf2e791e8a9bba7901b50d78c0b5b5813bb827abe")
addappid(41745, 1, "465d6071b94852512dc2326ec4554e1a537d03da79f0a9ed341eaa794c2134bc")
addappid(41746, 1, "9bb231dfc49ab8c9d5399a9cb1443218d4ad52e42d85b1557a5dc471049fb923")
addappid(41747, 1, "147eccdeff8409916bacf817fce6c798e2e643f3a70fc0f0f6794c3338afca2e")
addappid(41748, 1, "6ab78bb66165a6627b9ead0c7b86391dace0288a4195d63aa7df202a8b80fef2")
addappid(41749, 1, "da01f4ce77bab8143b5995189b703cf0c1cceaac678fca59f3f8157494a99fcf")
