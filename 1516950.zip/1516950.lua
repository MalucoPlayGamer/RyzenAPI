-- Lua provided by RyzenAPI
-- Game: 1516950

-- MAIN APPLICATION
addappid(1516950)
-- Game: addappid(1516950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516951, 1, "e85ffbc224b3e0d692a7f2495ce8295589e0d69cc9cc6a8bfa595174ccb14983")
