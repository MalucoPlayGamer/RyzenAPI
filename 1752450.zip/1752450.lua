-- Lua provided by RyzenAPI
-- Game: addappid(1752450)

-- MAIN APPLICATION
addappid(1752450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752450,0,"f33c304b78ca4cbfbc156582c35dd06cd786f94b37b48ff62f9ad7756c9ff1e8")
