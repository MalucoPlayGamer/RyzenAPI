-- Lua provided by RyzenAPI
-- Game: addappid(2994100)

-- MAIN APPLICATION
addappid(2994100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994102,0,"3f0fd36805aaf8a2e220cce0dc8aae143db6d2427061b8cda1bf2c8d53faa331")
