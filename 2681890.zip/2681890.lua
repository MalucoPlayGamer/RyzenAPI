-- Lua provided by RyzenAPI
-- Game: 坦克队长-高清畅玩版

-- MAIN APPLICATION
addappid(2681890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681891, 1, "c3b51ea6bf00ea20b60c44d0464a5c82682e9b963ab43d10bc7ba4d073ed6b8e")

