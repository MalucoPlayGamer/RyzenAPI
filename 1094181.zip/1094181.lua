-- Lua provided by RyzenAPI
-- Game: 1094181

-- MAIN APPLICATION
addappid(1094181)
-- Game: addappid(1094181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094181,0,"442b0da0a060ef9c480bfaee93808c8f6edd4cf897b1411d757b5e49c489584c")
