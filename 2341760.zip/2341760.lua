-- Lua provided by RyzenAPI
-- Game: Game: Defensurvivor

-- MAIN APPLICATION
addappid(2341760)
-- Game: addappid(2341760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341761, 1, "e91ebe31aa7318adbd3e5b766955cd932ac6f70ecab87d5d4c44e15e893d86a0")
