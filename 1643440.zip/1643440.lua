-- Lua provided by RyzenAPI
-- Game: Les aventures de Fierot

-- MAIN APPLICATION
addappid(1643440)
addappid(3438390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643441, 1, "a97c23e85b8d38e0a3c8603141e52213fba3785ec34c4764943e7ee63ce49f60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
