-- Lua provided by RyzenAPI
-- Game: addappid(1643440)

-- MAIN APPLICATION
addappid(1643440)
addappid(3438390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643441, 1, "a97c23e85b8d38e0a3c8603141e52213fba3785ec34c4764943e7ee63ce49f60")
