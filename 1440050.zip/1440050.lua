-- Lua provided by RyzenAPI
-- Game: Объемная История

-- MAIN APPLICATION
addappid(1440050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440051, 1, "aac2f7248c9b1c52f64afa106781b800ed406666b081ae08d06b212fe63fb778")

