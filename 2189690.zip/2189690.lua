-- Lua provided by RyzenAPI
-- Game: Speed Up

-- MAIN APPLICATION
addappid(2189690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189691, 1, "16c5cb1f5857f066df08655b5b5514a28d51693c2e8537d4fe6c0a25884eb7f0")
