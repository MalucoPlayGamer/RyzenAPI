-- Lua provided by RyzenAPI
-- Game: Mika and The Witch's Mountain Demo

-- MAIN APPLICATION
addappid(2252840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252841, 1, "103154baa5c8138626205f5096ef38e369d4d248d8f0478b9ff5f0e959beb2d9")
