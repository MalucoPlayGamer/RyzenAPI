-- Lua provided by RyzenAPI
-- Game: 1668520

-- MAIN APPLICATION
addappid(1668520)
-- Game: addappid(1668520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668521, 1, "7ff8469ddb0a97bf177dca7527ef140b913e1760b8b518d5c33d2c4ff6d83991")
