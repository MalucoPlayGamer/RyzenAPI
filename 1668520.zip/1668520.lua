-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails to Azure

-- MAIN APPLICATION
addappid(1668520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668521, 1, "7ff8469ddb0a97bf177dca7527ef140b913e1760b8b518d5c33d2c4ff6d83991")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2318450)
