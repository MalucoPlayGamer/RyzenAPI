-- Lua provided by RyzenAPI
-- Game: AppID 1475200

-- MAIN APPLICATION
addappid(1475200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475201, 1, "de1f8db449e5fbf9d5ab5103c82fd2688a6263c62b2c6ea01760dfe6a8ae16f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
