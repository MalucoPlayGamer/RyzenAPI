-- Lua provided by RyzenAPI
-- Game: AppID 1475200

-- MAIN APPLICATION
addappid(1475200)
-- Game: addappid(1475200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475201, 1, "de1f8db449e5fbf9d5ab5103c82fd2688a6263c62b2c6ea01760dfe6a8ae16f0")
