-- Lua provided by RyzenAPI
-- Game: AppID 2640720

-- MAIN APPLICATION
addappid(2640720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2640721, 1, "4e7a5283c786b6b412f360cb62b241559578ff51822c4ae794f83ea741398a8b")

