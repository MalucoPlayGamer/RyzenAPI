-- Lua provided by RyzenAPI
-- Game: Game: AppID 2640720

-- MAIN APPLICATION
addappid(2640720)
-- Game: addappid(2640720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640721, 1, "4e7a5283c786b6b412f360cb62b241559578ff51822c4ae794f83ea741398a8b")
