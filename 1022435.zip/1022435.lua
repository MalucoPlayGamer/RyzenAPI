-- Lua provided by RyzenAPI
-- Game: DFF NT: Warrior of Light Starter Pack

-- MAIN APPLICATION
addappid(1022435)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022435,0,"cbec80ae0e12bdd22d241e67066e27713bfcd91f66d76754e48e70651bcedba0")

