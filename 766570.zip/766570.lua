-- Lua provided by RyzenAPI
-- Game: Russian Fishing 4

-- MAIN APPLICATION
addappid(766570)

-- MAIN APP DEPOTS / PACKAGES
addappid(766571, 1, "d7dba035e1a1f07015025cf2749727599df4262383e44f58bb210d3c7f33655e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(986060)
addappid(1366920)
addappid(2338590)
