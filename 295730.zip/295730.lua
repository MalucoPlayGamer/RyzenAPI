-- Lua provided by SkyAPI 
-- Game: AppID 295730
addappid(295730)
addappid(295731, 1, "e36a18992fa7e02e854efc3cc9849d1427fb4c23b5ff23c26c45d0c1512c3d97")
