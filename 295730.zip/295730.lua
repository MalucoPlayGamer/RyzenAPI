-- Lua provided by RyzenAPI
-- Game: Sweezy Gunner

-- MAIN APPLICATION
addappid(295730)

-- MAIN APP DEPOTS / PACKAGES
addappid(295731, 1, "e36a18992fa7e02e854efc3cc9849d1427fb4c23b5ff23c26c45d0c1512c3d97")
