-- Lua provided by RyzenAPI 
-- Game: Glory Wall!
addappid(3245420)
addappid(3245421, 1, "b8fab9c970139499b221b4fcbe695b2cc329575223f350818a3a8a7dbf1d9c22")
