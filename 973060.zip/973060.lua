-- Lua provided by RyzenAPI
-- Game: 恶魔迷宫 2 |Evil Maze 2 | 惡魔迷宮 2

-- MAIN APPLICATION
addappid(973060)

-- MAIN APP DEPOTS / PACKAGES
addappid(973061, 1, "1159951ced05cebcdf33980acaff5e1115f175a3c7021c683c202195eade8d8b")
addappid(1040690, 0, "8dfd69895491950a6c6e19fce00bfefa11e442901c2cf5120037fd582ef0c9c1")
addappid(1771920, 0, "d94b3f347e38f0ac4dc4783518e641a42499c192633e0e26f71d5d9d207e796b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229010, 1, "9ea8b334311d1b69b962aac11d4cce01f3dfb21722d4198c12314f2d67a0196f") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
