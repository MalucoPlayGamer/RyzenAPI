-- Lua provided by RyzenAPI
-- Game: Game: 恶魔迷宫 2 |Evil Maze 2 | 惡魔迷宮 2

-- MAIN APPLICATION
addappid(973060)
-- Game: addappid(973060)

-- MAIN APP DEPOTS / PACKAGES
addappid(973061, 1, "1159951ced05cebcdf33980acaff5e1115f175a3c7021c683c202195eade8d8b")
addappid(1040690, 0, "8dfd69895491950a6c6e19fce00bfefa11e442901c2cf5120037fd582ef0c9c1")
addappid(1771920, 0, "d94b3f347e38f0ac4dc4783518e641a42499c192633e0e26f71d5d9d207e796b")
