-- Lua provided by RyzenAPI 
-- Game: Goblin Conqueror
addappid(2410780)
addappid(2410781, 1, "e91b1b1bcf9ab7bf2b3a7e5280e65b9ec8eecd13285e04cc173a20fcad0e470f")
addappid(2410782, 1, "1220577144203a28e89c286a44ce1c14c01a1f65131745ad5485a683c12d87f5")
