-- 1555650's Lua and Manifest Created by Hubcap Manifest
-- HEXCRAFT: Harlequin Fair
-- Created: August 15, 2026 at 14:20:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1555650, 1, "49fe7acb9ab2d68a36868381dc9b89ed5d3af70a528031cd2399e5cfebda86ea") -- HEXCRAFT: Harlequin Fair
-- MAIN APP DEPOTS
addappid(1555651, 1, "ccbfbde63cab40824eabc4ca8be61fbef16c1ce291a8217a42ec4417f6b535b7") -- Depot 1555651
setManifestid(1555651, "8632615436842107309", 288344320)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Harlequin Fair - Harbour Dawn Expansion Campaign (AppID: 1960290)
addappid(1960290)
addappid(1960290, 1, "4c4d12ed7562738e81a50a1bbbd34a057915ab311876b6657f7b54b006a26608") -- Harlequin Fair - Harbour Dawn Expansion Campaign - Depot 1960290
setManifestid(1960290, "2168799902625858800", 300389791)