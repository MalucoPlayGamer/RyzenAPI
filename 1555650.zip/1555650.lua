-- Lua provided by RyzenAPI
-- Game: HEXCRAFT: Harlequin Fair

-- MAIN APPLICATION
addappid(1960290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1555650, 1, "49fe7acb9ab2d68a36868381dc9b89ed5d3af70a528031cd2399e5cfebda86ea") -- HEXCRAFT: Harlequin Fair
addappid(1555651, 1, "ccbfbde63cab40824eabc4ca8be61fbef16c1ce291a8217a42ec4417f6b535b7") -- Depot 1555651
addappid(1960290, 1, "4c4d12ed7562738e81a50a1bbbd34a057915ab311876b6657f7b54b006a26608") -- Harlequin Fair - Harbour Dawn Expansion Campaign - Depot 1960290

