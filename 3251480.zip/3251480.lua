-- Lua provided by SkyAPI 
-- Game: AppID 3251480
addappid(3251480)
addappid(3251481, 1, "2e0770495326d9dac14973fc3d8b9b9378419cb3ce0c8f8e35579f277ca9d6cd")
