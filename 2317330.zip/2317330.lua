-- Lua provided by RyzenAPI
-- Game: Trance, Trauma

-- MAIN APPLICATION
addappid(2317330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317331, 1, "4ffbc6a57b5234f40c5a529afeefa92473944169ee080fd5fd97190fed14f212")

