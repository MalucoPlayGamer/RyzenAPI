-- Lua provided by RyzenAPI 
-- Game: Nitro Nation VR Demo
addappid(1903150)
addappid(1903151, 1, "d1c284ef10f28580c57af6d0ffe5d486a38f43ed9bfeeb732b8c3925dd1bfab9")
