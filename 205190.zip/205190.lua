-- Lua provided by RyzenAPI
-- Game: Rocksmith

-- MAIN APPLICATION
addappid(206080)
addappid(206081)
addappid(206082)
addappid(206083)
addappid(206084)
addappid(206085)
addappid(206088)
addappid(206089)
addappid(206090)
addappid(206091)
addappid(206092)
addappid(206093)
addappid(206094)
addappid(206095)
addappid(206096)
addappid(206097)
addappid(206098)
addappid(206099)
addappid(206100)
addappid(206101)
addappid(206103)
addappid(206104)
addappid(206105)
addappid(206106)
addappid(206108)
addappid(206109)
addappid(206110)
addappid(206111)
addappid(206112)
addappid(206113)
addappid(206114)
addappid(206115)
addappid(206117)
addappid(206118)
addappid(206119)
addappid(206121)
addappid(206122)
addappid(206123)
addappid(206124)
addappid(206125)
addappid(206126)
addappid(206127)
addappid(206128)
addappid(206129)
addappid(206131)
addappid(206132)
addappid(206133)
addappid(206135)
addappid(206136)
addappid(206137)
addappid(206139)
addappid(206140)
addappid(206141)
addappid(206143)
addappid(206170)
addappid(206171)
addappid(206172)
addappid(206173)
addappid(206086) -- Rocksmith - Guitar Bundle Collectors Pack
addappid(206087) -- Rocksmith - Upcoming DLC
addappid(206102) -- Rocksmith - Megadeth 3-Song Pack
addappid(206107) -- Rocksmith - The Black Keys 3-Song Pack
addappid(206116) -- Rocksmith - blink-182 3-Song Pack
addappid(206120) -- Rocksmith - 3 Doors Down 3-Song Pack
addappid(206130) -- Rocksmith - Judas Priest Song Pack
addappid(206134) -- Rocksmith - The Police Song Pack
addappid(206138) -- Rocksmith - The Offspring Song Pack
addappid(206142) -- Rocksmith - My Chemical Romance Song Pack
addappid(222068) -- Rocksmith - Ultimate Time Saver Bundle

-- MAIN APP DEPOTS / PACKAGES
addappid(205190, 1, "136f2834d545e264021b499291845c0650b5747446fab3e30eac2fcd227c8135") -- Rocksmith
addappid(205199, 1, "30d2ebe0ab89225965ac0b3fa80ad57e3626221586fa00a4bdfb429b907f7212") -- Main Game Content - REQUIRED
addappid(206144, 1, "0fc3f72e80a513dd82a70f976efacfb6f2ffc4a8de0944d89bb4386241978465") -- Depot 206144
addappid(206145, 1, "45b537caeeae8a4eee43fbe7f4552f06c898dd2bf031b78c8e31e7badaea68f3") -- Depot 206145
addappid(206146, 1, "8fda17583ebc910ab8c5076a37e4837f670f4e554c5d5a4efd78955ce2211a44") -- Depot 206146
addappid(206147, 1, "eda2ad18cfddc27c8beb88ef97458274015e11da692f93fb57632baf0d3a2082") -- Depot 206147
addappid(206149, 1, "2afa7d8dd7efca0aa898326b96ba9654542fc1d2d7e41db8c3979d78119f2ac6") -- Depot 206149
addappid(206150, 1, "e0800426d5fe1075a25e64e1da70a331aeb03d84cf42eed30c9c2ff86dc002a2") -- Depot 206150
addappid(206151, 1, "729c90f6ae424dd4d3e18f1305653ed36196261c9836442f3e99d652c03dc138") -- Depot 206151
addappid(206152, 1, "bad7537b046898e727d20c27e5830a81e3f532411ddb787fa059a7f5250aa1cb") -- Depot 206152
addappid(206153, 1, "9c16716c48ef0f6ce4e86428a4734de83933d9080a233c698ee230e13df4569c") -- Depot 206153
addappid(206154, 1, "6fe252f61bf470b6b1299d89f3695914aa0a481da2430b836d8ddb7087527cd5") -- Depot 206154
addappid(206155, 1, "aba3850ccf6a5a6e43aa260c44329dccca07d15bb72b74044a6cb6553b249d13") -- Depot 206155
addappid(206156, 1, "05a4098a1a1e62de2bace719e54e7d8d8711ab428f890a538a6683df4e7968eb") -- Depot 206156
addappid(206157, 1, "3c130413eec7fe10e831112171dff92841d0a74d22e4007c424d17d5bb60530e") -- Depot 206157
addappid(206158, 1, "4f4ec9768c4fc2c749850cd342563c4fb92ef0b28692c89bbfafdcd8ee55bbc1") -- Depot 206158
addappid(206159, 1, "b93bb18fbc888c992a7f0fb3161c336e718a46f8604988e7f7afc60f1aaf3a96") -- Depot 206159
addappid(206160, 1, "a90e14cf46e2276ab5d4e4cec20fb6c0e74dba402b1b5d7fe45e16a655f3717c") -- Depot 206160
addappid(206161, 1, "5d0cb944ca864e1be0d691bf469eae5bd5772b4faa5994d216c6452abc2b9f37") -- Depot 206161
addappid(206162, 1, "9c103ac59a2daceaf36352e015f5dc9ea337d5b15ea68d3c12b629d9da1d3430") -- Depot 206162
addappid(206163, 1, "dc51e50fcd912fd8b2e3069a7847c12a82efb055ced5cf6d32056325b8e7b562") -- Depot 206163
addappid(206164, 1, "43d56f471d56329ab8c5e2c469424299999ff86025e2a54f70128a9f1f4f838a") -- TWISTED SISTER - We're Not Gonna Take It
addappid(206165, 1, "4ed484b4473068a412a888d04b0bc59de5a00040bf00a1dd0c4c0ee375450229") -- WHITESNAKE - Is This Love
addappid(206166, 1, "6d7ea879691183d9e9a10f77d5b24d20398354b790aba365a941113196cf87b6") -- EUROPE - The Final Countdown
addappid(206167, 1, "c20f89241677dfafb49122934d8b625e9dd080fb35f81ab08500c27baa8ee466") -- GARY CLARK JR. - Bright Lights
addappid(206168, 1, "de5bf83001a89c4b49a61aa373c648cf323312f290093ccce6bfe70f41de1377") -- GRACE POTTER AND THE NOCTURNALS - Paris (Ooh La La)
addappid(206169, 1, "e442b273dccde716a4b65ddd3e3d764404b92d3082bb9319c5b0a6f760afc4e4") -- THE SHINS - Caring is Creepy
addappid(206174, 1, "0ba358671bbe93ea3ee7dfd7c165d6c7c7b3bfb9b1bb874bde69bed82e2a891b") -- Depot 206174
addappid(206175, 1, "8562ba25fe496313dc52e63460f03a8973a498775ed7a22b3d590dc33176654b") -- Depot 206175
addappid(206176, 1, "8d1b6b7a9c608ae9a06be4940001193d4c8ea3959d248bbd62c9526fb6fc4f5f") -- Depot 206176
addappid(206178, 1, "fa84f42b917f271a36217fdee6c2ef8da3c1fd82fd77977acfbf09222c4631b2") -- RUSH - Tom Sawyer
addappid(206179, 1, "37bca584fe31000a5eda8b1b9b4c4748987f6680559a2643a3305b5ddb947b3b") -- RUSH - Limelight
addappid(206181, 1, "7dfc4b8e974e3e0d6958e6ecd94c6745b2a81c6d484a5864d1b0881cf7dea2ce") -- bg_content
addappid(206182, 1, "e92a9a3fec0f6da3b2f0acc23f1bbc2b934d7b8c28202f7883ba918486f51b2b") -- RUSH - Subdivisions
addappid(206193, 1, "dbd2c02ecb79eb95ff434b4ed339567f6da4161c51ad0584f95ea5917be9f0e6") -- Developer Commentary
addappid(222041, 1, "3a6d4539fea482412241406b8e32c450fd9cae388ab5d303d757fe710509cebc") -- RUSH - YYZ
addappid(222042, 1, "61c26eedd14c99aa09b11343d27e7da1e4b63e65a0f8a5b1626b27de1ad958ee") -- RUSH - Red Barchetta
addappid(222043, 1, "9c6f422500be286028e6af7cbf95a46390f594a3ea0ee9ba4012df520b7e37bb") -- RUSH - Subdivisions
addappid(222050, 1, "9e0ae5cc7e1ce8cfca88cf6103fdbf741159c528abf38d8ff6bae1dc785e0b62") -- PARLIAMENT - Give Up the Funk (Tear the Roof Off the Sucker)
addappid(222051, 1, "fbc670d3e141d7f23812815a90473afd7597e6b2f58a8e116bebec5d7e54bb66") -- RICK JAMES - Super Freak
addappid(222052, 1, "24c23fcf61f811223a63c665d17e262c5e0d6f7deffc581e74f0816cfe080052") -- CHIC - Good Times
addappid(222053, 1, "a5ba25f63d5877dbd1431b32539517489d24d23046c04303cfade277d9af0bf6") -- RUSH - Headlong Flight
addappid(222054, 1, "a22f16b640dc4dba97de089cdfda79830cea3ebbe50c24b5189959a725df9442") -- PANTERA - Cowboys From Hell
addappid(222055, 1, "d7b2971e9b5f2963c4efa5d1c039725b33a32d20e0da89f6ce1b6a9e4a00cade") -- PANTERA - Domination
addappid(222056, 1, "fa26cff88f416afb009b253974b0e0f1737d806857f35ba4292dc8c531460a05") -- PANTERA - Walk
addappid(222058, 1, "5bf28926a71cd18d0150393ea04daf136d015d545bc1031cb1ed6a4a8ae2cdea") -- NICKELBACK - How You Remind Me
addappid(222059, 1, "d9fa4e178c12c81c6cf8b77e089e6b4efff7ca1652f1cfe664ff48b10a731a8e") -- NICKELBACK - Rockstar
addappid(222060, 1, "7255720261ab997b759fa5860123fffcd03ac567ff6ebcba4459317d10822a90") -- NICKELBACK - Bottoms Up
addappid(222062, 1, "e04d128f0364204db83c6b4dd97578f75cbe7514dd29c415b7e42750bab6ae90") -- FOO FIGHTERS - Walk
addappid(222063, 1, "c3a737b2062816e986944ebcea8d21357cf1a7ea702ab9452db86efc73b6db38") -- FOO FIGHTERS - My Hero
addappid(222064, 1, "6432a28b83041ddc0cf9c84ffbb669c4ff363ffbf81bee7a1ebb6c6710a95423") -- FOO FIGHTERS - Best of You
addappid(222065, 1, "29109086b58211aa01805119e87c693b65831f83061ce939773a1a26773e32ee") -- FOO FIGHTERS - Times Like These
addappid(222066, 1, "1a9b5814fdfa42d620c9f68fc998033410c5f09fd85dde1c5b384848ff282f9f") -- FOO FIGHTERS - Wheels
addappid(222069, 1, "b731d9e8607e5831650a0ab7867a9bb4dd58b90b654b4a92ccb6792e8975cd10") -- SANTANA - Oye Como Va
addappid(222070, 1, "d32634e10f2ec1b32bc1a6f30a2b3bec525b0f562ac1e3212e603edaf9c20be8") -- SANTANA - Black Magic Woman
addappid(222071, 1, "13e8447fda9444ee0e4ea4ef085149103828d57303f31b50e238c388a320f320") -- SANTANA FEAT. ROB THOMAS - Smooth
addappid(222073, 1, "30f93e5a3f4f9d47276b91f3ef9ace29d93761c771deefc43a6fb19ef6c3d851") -- 222073
addappid(222074, 1, "f20d99ac087e185a04338ccc370876f86b079cd9843f7278c35525e93cbcfd16") -- 222074
addappid(222075, 1, "688662fe66d6ddf4fed9e1fc3557489c975d4748d944b73d9c718cfc181e6ab6") -- 222075
addappid(222076, 1, "542846ddad41a061bd51e9a64d7c5b095d0d7d0edc8aae072fb5ac72d7c3cb0c") -- 222076
addappid(222077, 1, "4b59b9f78a318ff24a6514184100341324f1c24057582cdf904c63d008e95cbf") -- 222077
addappid(222078, 1, "34d92eec03055b0ae1be99d43d5776120c04f9d1c45acd2b4c0b35d167f3ed12") -- 222078
addappid(222080, 1, "7cd907eeeb714fc755e9889ec19dcc049d8bb553fa153d02db77e6b1b4b589a5") -- 222080
addappid(222081, 1, "d528073157a054fc7e27cccc8b0a87c31e46019cf1ac73a196739287fab7a9a6") -- 222081
addappid(222082, 1, "da39ae185c1a9827433c59207b75305275a5dd183ddfb8446379f13f0b2e88ba") -- 222082
addappid(222083, 1, "8bfee11703ffca94297c3f3bf7c06bf998d19f146a3f19b731232c0b7e7c7e36") -- 222083
addappid(222084, 1, "3ea05703eb4e0ee400ca00c123c725a4b5ce52ec3996668dc12470e7f43e43dd") -- 222084
addappid(222085, 1, "97ac74742c6e07ae16cc513df1498679b1a867b882f21f8e48ff4f165118e52d") -- 222085
addappid(222086, 1, "477d044cb7d426bf7bf390441b018815216c16d1169a32634b3d84efade6cf4e") -- 222086
addappid(222087, 1, "debb01f6dadb0e5fcc49c63dfeed9f265f15f6e399a643afd9f26c1ac6a25d4d") -- 222087
addappid(222089, 1, "9a9ef29aa5c8e17dd8f76c09c342806f54821a16fd9f97c9700e81e77e8b9a65") -- 222089
addappid(222090, 1, "87a67fef615c588b02ed70228760152c352833f6e8d3c0a45b24e1187eb14b2a") -- 222090
addappid(222091, 1, "5603d98142c7df2980c5eafd441be8afca6a2a2ec6d0cd24a34bc88e13cf6527") -- 222091
addappid(222093, 1, "cb8991f1d16096c19a22713e6bf8b047e336cca77f4bda6f2323455cef6c547d") -- 222093
addappid(222094, 1, "2f7fa5581571aa12037647d88de12b0992193c38697eed8f3e307c490351be01") -- 222094
addappid(222095, 1, "81788f5c893c7ea8a9795ddf9d6e36724c7a6ebfdd1e547cdcbe5b843317d741") -- 222095
addappid(222096, 1, "fe1ac1000778d9cb28fe5491a451a413839bcb3fa95ba3fefa8e8efc7e3184ba") -- 222096
addappid(222097, 1, "79ffdffb3b349a6fdc9982eff1d2a90f0fe7128714e78b9db66c7d12befa9dc8") -- 222097
addappid(222098, 1, "58f00c4691ae151056fa543fd2da4abab3535530cc7c395f5240a8ac2f65ef3c") -- 222098
addappid(222100, 1, "a7706db9384c1fd9faca3aba428d1a936a6e024ea6edab13b24c43e3283aa227") -- 222100
addappid(222101, 1, "67cc6ac4f8e5e52d15443d370c86799d9876a299d8469bc66e92c2c2ac9be25e") -- 222101
addappid(222102, 1, "ac489c7fcfb3ccc84363700ad6eacc32c27557e2916171e52ec2a08cc541756d") -- 222102
addappid(222103, 1, "311b4823ad8ad1e0a43aab048a9e27dd5daa49ce26822179ba52a8f5a2d9dcd8") -- 222103
addappid(222104, 1, "c5bf9a9e184fe5e65385c13c375539192d7aff3b8a26d953fbcd8b067a511b17") -- 222104
addappid(222105, 1, "bfca75a9fcd0ae0cc9e9d19b8a63cc7874d2cc39f6ba6b89c04da2f87a58eb89") -- 222105
addappid(222107, 1, "cc139b76d8ee9dc35db912112896bb48cc644974ffd570c9872dfd298d51a2fb") -- 222107
addappid(222108, 1, "3505f7d92616fe607dedbd672c76ee413397b5146289f3f60c068235918d6d91") -- 222108
addappid(222109, 1, "dba45349e33431ceb6c2ab65067df42842e82f23972635f27bb9df7a89ae2b3a") -- 222109
addappid(222110, 1, "c14dfad5854808cdd1c8a2a327ab282cd9b6ad7f62ca5c3f83332f9cc2046b72") -- 222110
addappid(222111, 1, "b5093086273ba8474d7c4e22a724e34d56af81f487fa0ef81abdbbf72cfeef6c") -- 222111
addappid(222112, 1, "43ba3c88abe568ef998fa751bd89cc6296004e59ddec066154b69cc3ff9f68c4") -- 222112
addappid(222113, 1, "b254099a6355f049dd7d031fe2cc6e6fe16cae93b69e171fa9dd53dd7ce25d81") -- 222113
addappid(222114, 1, "a49ea49871e4aeccd9e43b5a38c9c3b94f8917201bb257895a9c2ec783462f65") -- 222114
addappid(222115, 1, "bf72b02ff4236a3aec832b844cb1480a27941a7fc4c7f839fb62c62fe949b6a9") -- 222115
addappid(222116, 1, "8aa8b1b08162318f64e61b9b60b482e73d227e084145f4a6cabaf6e16a7fa173") -- 222116
addappid(222117, 1, "23099644ed6c3e7743ffa424600e17bee1e27115aa6f927afde1ecb1d0bc7eb4") -- 222117
addappid(222118, 1, "32f567522790a883f09948f04fbc3ff05e8ca7b5d1319cd5bb2bfae82106a1f0") -- 222118
addappid(222120, 1, "317d23bf18a893bb193cb0d1fe4296f2b1dad4b2dbcc4d19dc185e7c1b555f65") -- 222120
addappid(222121, 1, "5b9c77e7c98b83af71139279a0d409c357767148cd343bda5e79ede54cb2fc3c") -- 222121
addappid(222122, 1, "a4ce9e5503e37a516bdd06abab3725188dd7714aa4e738311d2e9583c594d98d") -- 222122
addappid(206080, 1, "75eb767e49a67c5b1ca77ec012852d20ffa8167ef7424b3be0e5ae2a75e09df2") -- Rocksmith - Song - Barracuda by Heart - TEST 206080
addappid(206081, 1, "03832db940c5180540f9289eae228145603e0438261b245bf4f4b69e5ec108c4") -- Rocksmith DLC2 - TEST 206081
addappid(206082, 1, "19c90128ec28dcf3107b2787044fde81824fbc970d94e3004f30f5a5da1cc487") -- Rocksmith DLC3 - TEST 206082
addappid(206083, 1, "16202623ec46c1d4ae87e4e69f54deea720a5744b55aff3d16e60b33ba690c9e") -- Rocksmith DLC4 - TEST 206083
addappid(206084, 1, "470792e7ee41b6fd515e154a89045792af61ff032b09da9195da113fd1272a28") -- Rocksmith DLC5 - TEST 206084
addappid(206085, 1, "edc09803acef17181d98707d07b48316181604aadc8d9c1f8b11cc93543598ed") -- Rocksmith - Steam Digital Preorder - Steam Digital Preorder
addappid(206088, 1, "dde91507a90c948a7d982769f9af47499226193ff8104eb31b941693bcbae20d") -- Rocksmith - Heavy Metal - Gear Pack - Heavy Metal - Gear Pack
addappid(206089, 1, "315a8ea33f2236abf300e8db0c79cdde086a1f76e6df4f60fa3194df74503116") -- Rocksmith - Tone Designer Time Saver Pack - Tone Customization Time Save Pack
addappid(206090, 1, "44d3de3fc2502fa2e55c4131bb9008c6aeee97dd3e69f3d9b5ff126469cc3d62") -- Rocksmith - Tighten Up - The Black Keys - THE BLACK KEYS - Tighten Up
addappid(206091, 1, "e9d1bf446e4760097a602adb56cb4aefcdfa663199e8048ae0ad83ce25e48cbe") -- Rocksmith - Bodysnatchers - Radiohead - RADIOHEAD - Bodysnatchers
addappid(206092, 1, "76ecf103283c488cff53cfe68a5507d6a360db075386c20eda3ec640e76e4af1") -- Rocksmith - Free Bird - Lynyrd Skynyrd - LYNYRD SKYNYRD - Free Bird
addappid(206093, 1, "9677478fe7adcb782d8c4e7dd62fe03cc4f705d42762b99765b5bebd7c450ace") -- Rocksmith - More Than a Feeling - Boston - BOSTON	- More Than a Feeling
addappid(206094, 1, "d253699113fcbc6340b2ae5e491175b25f9b99e5e776057d9f74c2865a6078b0") -- Rocksmith - Jessica - The Allman Brothers Band - THE ALLMAN BROTHERS BAND - Jessica
addappid(206095, 1, "3687bf387016c58422bac7e0c8501ea29ece85a5848d8c1b144adda22676581d") -- Rocksmith - Smoke on the Water - Deep Purple - Depot 206095
addappid(206096, 1, "158782328a92205e2cd395e915ab2211e697947fcc0c504434ebb917d63c8d5e") -- Rocksmith - 20th Century Boy - T. Rex - Depot 206096
addappid(206097, 1, "9e128a70bd9cfa056cadd7c706f3af8afa1b3aa55eb96b06711d2f5f2c70616c") -- Rocksmith - I Hate Everything About You - Three Days Grace - Depot 206097
addappid(206098, 1, "bd2c50a8f06ff0925ce1feb3323df4fd5878e7f3d8de2f0cc9b7f79eb6f2c247") -- Rocksmith - Cousins - Vampire Weekend - Depot 206098
addappid(206099, 1, "fd0eec5d4191c5f3e35ce6c7df66723ca9be76a5493c0e7d2b84c59db18c5680") -- Rocksmith - Symphony of Destruction - Megadeth - Depot 206099
addappid(206100, 1, "2751ef98fc97b3d429de18612d2cafd3f11118e751712ff00f6a113d0d9cb7df") -- Rocksmith - Hangar 18 - Megadeth - Depot 206100
addappid(206101, 1, "bdbf7d3f5f40626f41ceac7ebb335c7bd8bbe6969a4dec83c1792c272dd24bc6") -- Rocksmith - Public Enemy No. 1 - Megadeth - Rocksmith - Megadeth - Hangar 18 Content
addappid(206103, 1, "fef126048effc969141cfa3e45b86c3e03bc367229c7a47ff0b55857974da536") -- Rocksmith - 2011 Holiday Song Pack - Depot 206103
addappid(206104, 1, "2cc28c826c87a1267d5a0f96748536c4eddc93f4ab48a1d061d2d93ad6684189") -- Rocksmith - Gold on the Ceiling - The Black Keys - Depot 206104
addappid(206105, 1, "84d825e4a0a860aab84012fce15ec3bf3c87ef7972dc687d41da1914625dbf74") -- Rocksmith - Mind Eraser - The Black Keys - Depot 206105
addappid(206106, 1, "c5c1cff98629f72ed7fcc78bc73f7d4c2075c778c4d8f3f2b79d2cc2d1b5e94d") -- Rocksmith - Just Got to Be - The Black Keys - Depot 206106
addappid(206108, 1, "caa72c04e1589d7504312a952a0a6e8e9c74d9e02838bbe7ff0b7fd213eafb66") -- Rocksmith - (Dont Fear) The Reaper - Blue yster Cult - Depot 206108
addappid(206109, 1, "b58f57cecefc56284d22ced98e2671b986bae35d0e9397a8c2c07668d9522eb6") -- Rocksmith - Barracuda - Heart - Depot 206109
addappid(206110, 1, "1d9b64325f71d451296dd4c5331d2ea1e26f8e17124f41a40658afa068f8f2b1") -- Rocksmith - Space Oddity - David Bowie - Depot 206110
addappid(206111, 1, "4e0a5757845c2075bbb42a6639d34241758d09943122fe43491592122bfda23f") -- Rocksmith - Black - Pearl Jam - Depot 206111
addappid(206112, 1, "622ab9e3229f9fdff3fd1b10dca4349571c20f1e31faa37e0613da5595250154") -- Rocksmith - Jeremy - Pearl Jam - Depot 206112
addappid(206113, 1, "184d028425cb1575477be62b70ba4663b24f7b7c7730f0512e56ab4ead13db73") -- Rocksmith - Dammit - blink-182 - Depot 206113
addappid(206114, 1, "cf2f0657fc09785fdb8cbe6a8ad8f94ea7cc6490b800b9ec313597a87dbf2e97") -- Rocksmith - All the Small Things - blink-182 - Depot 206114
addappid(206115, 1, "7985845fb9347f2bcee9a8897c498a9e6652036cbaed918392bff1873f3fb0dc") -- Rocksmith - Whats My Age Again - blink-182 - Depot 206115
addappid(206117, 1, "49cde9bcba0c11ce6e2d3b8e47c489429b6eef33c2573b19004a1b2171f6929e") -- Rocksmith - When Im Gone - 3 Doors Down - Depot 206117
addappid(206118, 1, "c50450a15ab9697ff968eaf2bcf744ac8709e46d8aa8a5ff460e18f6dc28cf39") -- Rocksmith - Kryptonite - 3 Doors Down - Depot 206118
addappid(206119, 1, "c30eecd7024684eb036d5683e8426264ec11674994c85432401f4e3ae19d01a2") -- Rocksmith - Loser - 3 Doors Down - Depot 206119
addappid(206121, 1, "abe766dd4e0018bc867225fb2867fc9d6672a0c7952d8213725a50fdc5f22454") -- Rocksmith - The Thrill is Gone - B.B. King - Depot 206121
addappid(206122, 1, "c92b8552378f23c03c8ae8572902d1fd86e68d9b1a480bc1e08efc3da7fd405d") -- Rocksmith - Soul Man - The Blues Brothers - Depot 206122
addappid(206123, 1, "d9f8a40ffe16b1da5c8dd7ecba6c6e898ba29a06546a46d5862c47375b4c0a70") -- Rocksmith - Born Under a Bad Sign - Albert King with Stevie Ray Vaughan - Depot 206123
addappid(206124, 1, "cb5c5b7974069fb2bf7b91b2a57176c51479dd57b6d890e5d584b1e1656621e2") -- Rocksmith - Pumped Up Kicks - Foster The People - Depot 206124
addappid(206125, 1, "7db14ec5f0f2cbb1fc2dd5d5cd9fff060d1a57ee7efc7cd4aa4a970542ca0887") -- Rocksmith - Bring Me to Life - Evanescence - Depot 206125
addappid(206126, 1, "1eea687145d78094d7fe425bb0ebe47b1ae3aaf854117f41bd113f3d7213c749") -- Rocksmith - This Love - Maroon 5 - Depot 206126
addappid(206127, 1, "093b1cf2d5294bbfc2fed84103897237af800cbedcf196830e7e858f7610da51") -- Rocksmith - Breaking the Law - Judas Priest - Depot 206127
addappid(206128, 1, "532565a73c3022f10f986ea45ab8c7213c6e766844178c9b455bd4e80db59209") -- Rocksmith - Living After Midnight - Judas Priest - Depot 206128
addappid(206129, 1, "9437c3718feea57227c832ded514922a61e4cb12a8a0dc5f7ebd0d4af48369c7") -- Rocksmith - Painkiller - Judas Priest - Depot 206129
addappid(206131, 1, "f28e479c6b49d49458b134ebb2e06189f27fc8df4a3f039dc7a6d60866e3c68c") -- Rocksmith - Roxanne - The Police - Depot 206131
addappid(206132, 1, "764d1ae45ffb44f6ba2649af90a52c7560000844a163485f59d7ac3ecb1f7bf5") -- Rocksmith - Message in a Bottle - The Police - Depot 206132
addappid(206133, 1, "c7d622f277849466715a1d531d73dcbb23a654371a71fd62dee4898337276f7e") -- Rocksmith - Synchronicity II - The Police - Depot 206133
addappid(206135, 1, "114d4ba80f53752edfa8294cda1d787330a532eed725ca78809f3797b743b5e7") -- Rocksmith - Self Esteem - The Offspring - Depot 206135
addappid(206136, 1, "ced223c0bdca44743582a8c0e025bd15b613b425968fe1da7bcc6ca9984e2939") -- Rocksmith - Gone Away - The Offspring - Depot 206136
addappid(206137, 1, "8988a13e4b511a4fe039be272beaa728d7f4d8dd8a9d735a4c0869f69a25eb8f") -- Rocksmith - Come Out and Play (Keep em Separated) - The Offspring - Depot 206137
addappid(206139, 1, "2fb91dd9447355fcbfb265d2168fba7766b06b067492042017b55cca2cac19f4") -- Rocksmith - Welcome to the Black Parade - My Chemical Romance - Depot 206139
addappid(206140, 1, "492ad552d8544e17a2892cafddb556068a2f8b2073d544e6ccdd97553150a1fd") -- Rocksmith - Na Na Na (Na Na Na Na Na Na Na Na Na) - My Chemical Romance - Depot 206140
addappid(206141, 1, "1c14d8b85e1158edaa490a4d6e97cdff125523b1b5428605a6fae50c08c50b58") -- Rocksmith - Planetary (GO) - My Chemical Romance - Depot 206141
addappid(206143, 1, "99626457b79fb8dc45478f164e732fad3b7efad11e62a0f6329782cd591f0384") -- Rocksmith - Bohemian Rhapsody - Queen - Depot 206143
addappid(206170, 1, "704686fdb9ba31951c26ca0a430149bbdb83bf7185c08e36a947b6b06c79945f") -- Rocksmith - Unlock All Guitarcade Minigames - Depot 206170
addappid(206171, 1, "f951eb035d830407f0c90822455bd021db3a055caf38bf054c3ae1b55dd6d0f1") -- Rocksmith - Unlock All Guitars and Basses - Depot 206171
addappid(206172, 1, "46f04d2586c1414c357ef230b3e7b222500e12a7ab87232d6d95ccc1bbc1c240") -- Rocksmith - Unlock All Bonus Songs - Depot 206172
addappid(206173, 1, "ebe1dba725ef84d829590db74036de0c6c3c3c62b46e3e63e79bbb35f28c21d1") -- Rocksmith - Unlock All Venues - Depot 206173
