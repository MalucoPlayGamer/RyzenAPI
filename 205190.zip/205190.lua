-- Lua provided by RyzenAPI
-- Game: Rocksmith™

-- MAIN APPLICATION
addappid(205190)
addappid(206191)
addappid(206194)
addappid(206195)
addappid(206198)
-- Game: addappid(205190)

-- MAIN APP DEPOTS / PACKAGES
addappid(206193,0,"dbd2c02ecb79eb95ff434b4ed339567f6da4161c51ad0584f95ea5917be9f0e6")
