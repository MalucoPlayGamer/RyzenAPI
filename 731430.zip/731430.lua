-- Lua provided by RyzenAPI
-- Game: influence

-- MAIN APPLICATION
addappid(731430)

-- MAIN APP DEPOTS / PACKAGES
addappid(731431, 1, "0a99d19bff4e52f448a1ecfa9f4e503caeafbf97bc9a144740c272acb022d568")
