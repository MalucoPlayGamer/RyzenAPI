-- Lua provided by RyzenAPI
-- Game: Game: The Great Yokai of the Haunted Halls

-- MAIN APPLICATION
addappid(3226890)
-- Game: addappid(3226890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226891, 1, "78ff1b54b9ac4bc905ec6a05a65d4f8a6d1004f44ef7dfe94f57398912b91f84")
addappid(3226892, 1, "63fa57eb6e5d85f1b2e66750c2dba88ed134c8cb5004cf56fa0a98d428e338d7")
