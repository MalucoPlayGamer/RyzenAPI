-- Lua provided by RyzenAPI
-- Game: Chaos Control

-- MAIN APPLICATION
addappid(781270)
-- Game: addappid(781270)

-- MAIN APP DEPOTS / PACKAGES
addappid(781271, 1, "c964395d91545d68f98c988d8b517c2770da1ec5b8798237634c5a8731b9c5ce")
