-- Lua provided by RyzenAPI
-- Game: 2864980

-- MAIN APPLICATION
addappid(2864980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864980,0,"f62ed92a7beb841d7d52a1c66d3aeea465783afc0f307c0864ca36d15becd6a8")
