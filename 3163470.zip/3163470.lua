-- Lua provided by RyzenAPI
-- Game: At Death's Door

-- MAIN APPLICATION
addappid(3163470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163471, 1, "aa7c034b5fac2d5941f946e1945a255992c34bcc9c8d7934fdc0b85139a9c4ce")

