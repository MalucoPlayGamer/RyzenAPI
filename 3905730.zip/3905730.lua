-- 3905730's Lua and Manifest Created by Hubcap Manifest
-- Nekopedia: Find Her Tail
-- Created: August 28, 2026 at 23:24:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (2 excluded)

-- MAIN APPLICATION
addappid(3905730) -- Nekopedia: Find Her Tail
addtoken(3905730, "11774751098870751619")
-- MAIN APP DEPOTS
addappid(3905731, 1, "da18637fa5a348c8328556f264a2a5363398aaafb5f522e55b0961adf376c86e") -- Depot 3905731
setManifestid(3905731, "8885891317711683852", 1678608321)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Nekopedia Find Her Tail. The Official Artbook (AppID: 3943510) - missing depot keys
-- addappid(3943510)
-- NSFW Content - Nekopedia Find Her Tail (AppID: 4005180) - missing depot keys
-- addappid(4005180)