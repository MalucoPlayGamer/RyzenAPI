-- Lua provided by RyzenAPI
-- Game: Nekopedia: Find Her Tail

-- MAIN APPLICATION
addappid(3905730) -- Nekopedia: Find Her Tail
-- addappid(3943510)
-- addappid(4005180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3905731, 1, "da18637fa5a348c8328556f264a2a5363398aaafb5f522e55b0961adf376c86e") -- Depot 3905731
addtoken(3905730, "11774751098870751619")

