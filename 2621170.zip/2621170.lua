-- Lua provided by RyzenAPI
-- Game: The Last King Playtest

-- MAIN APPLICATION
addappid(2621170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621171, 1, "d7ac47f882720c4394f7892528810fe250cac31226e17e434f659327cf3ccf6d")

