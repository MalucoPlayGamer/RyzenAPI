-- Lua provided by RyzenAPI
-- Game: Platypus

-- MAIN APPLICATION
addappid(307340)

-- MAIN APP DEPOTS / PACKAGES
addappid(307341, 1, "b93c84f83089ae5bc70a09eb1deac419aa45e85c7c873dac59daa45dbb334774")
