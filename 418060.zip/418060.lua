-- Lua provided by RyzenAPI
-- Game: Game: Battle Riders

-- MAIN APPLICATION
addappid(418060)
-- Game: addappid(418060)

-- MAIN APP DEPOTS / PACKAGES
addappid(418061, 1, "21bf81877355157cf0af4c068e76906d6190d5d05104f01b47344ef5b42cff32")
