-- Lua provided by RyzenAPI
-- Game: AppID 1260390

-- MAIN APPLICATION
addappid(1260390)
-- Game: addappid(1260390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260391, 1, "7fe8cef460cf552c1c38c0d9a3bb4e4a8e4107c53bf2bd8abca522ebe97d6001")
