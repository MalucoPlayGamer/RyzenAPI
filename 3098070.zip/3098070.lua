-- Lua provided by RyzenAPI
-- Game: Cinema Simulator 2025

-- MAIN APPLICATION
addappid(3098070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098071, 1, "07ba85ee90a70214863d849777e787e059ee14495e6ba118cbf0e1feeacd3e75")
