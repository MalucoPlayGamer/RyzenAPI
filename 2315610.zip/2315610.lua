-- Lua provided by RyzenAPI
-- Game: Muscle MILF

-- MAIN APPLICATION
addappid(2315610)
-- Game: addappid(2315610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315611, 1, "a1e0f8b980f68f745f946f9710210b450acbfd253dc3c6685111ac5b203f377c")
