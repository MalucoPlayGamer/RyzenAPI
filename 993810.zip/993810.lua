-- Lua provided by RyzenAPI
-- Game: Lost City of Vampires

-- MAIN APPLICATION
addappid(993810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(993811, 1, "f41046607533d78a0eee15df6e80381f73e41823012ad463dfcde6f2854a1ae0")

