-- Lua provided by RyzenAPI
-- Game: Game: AppID 993810

-- MAIN APPLICATION
addappid(993810)
-- Game: addappid(993810)

-- MAIN APP DEPOTS / PACKAGES
addappid(993811, 1, "f41046607533d78a0eee15df6e80381f73e41823012ad463dfcde6f2854a1ae0")
