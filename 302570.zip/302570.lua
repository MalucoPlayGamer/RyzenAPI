-- Lua provided by RyzenAPI
-- Game: Dangerous

-- MAIN APPLICATION
addappid(302570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(302571, 1, "6699df10109054bad2ebd0cbb7a2efc6c9c298a8cefabb79056f57c4815fec6e")
addappid(302572, 1, "1e00ddb7a5b36c23198b4634f2810347fbd998389d3e96fb8b950c8285521888")

