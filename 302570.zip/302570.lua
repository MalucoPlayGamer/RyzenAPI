-- Lua provided by RyzenAPI
-- Game: Dangerous

-- MAIN APPLICATION
addappid(302570)

-- MAIN APP DEPOTS / PACKAGES
addappid(302571, 1, "6699df10109054bad2ebd0cbb7a2efc6c9c298a8cefabb79056f57c4815fec6e")
addappid(302572, 1, "1e00ddb7a5b36c23198b4634f2810347fbd998389d3e96fb8b950c8285521888")

