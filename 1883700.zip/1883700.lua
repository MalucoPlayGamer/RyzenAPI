-- Lua provided by RyzenAPI
-- Game: AppID 1883700

-- MAIN APPLICATION
addappid(1883700)
-- Game: addappid(1883700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883701, 1, "5bc6c048918df44ed057480d0c33d7f0f3dc111ba20091a8c8fa5046c0fccb6f")
