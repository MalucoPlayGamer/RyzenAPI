-- Lua provided by RyzenAPI
-- Game: Game: 传颂的种族 The Celebrated Race

-- MAIN APPLICATION
addappid(2066530)
-- Game: addappid(2066530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066531, 1, "f2a3d1c9ca7f8e2e6925dc81f4d2fc3aad5aaaf2aa98772a80cfade2a25f57ac")
