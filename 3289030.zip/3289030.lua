-- Lua provided by RyzenAPI
-- Game: Ahon - Short Demo

-- MAIN APPLICATION
addappid(3289030)
-- Game: addappid(3289030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289031, 1, "751849ac493e644639b15a3a4f1302f85c1a249669189472f64828690da92322")
