-- Lua provided by RyzenAPI
-- Game: addappid(606750)

-- MAIN APPLICATION
addappid(606750)

-- MAIN APP DEPOTS / PACKAGES
addappid(606751, 1, "bca46b438fa4295e5a780a3a92621fd4ac322bc604630a704d854cabf5048929")
