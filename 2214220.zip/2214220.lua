-- Lua provided by RyzenAPI
-- Game: addappid(2214220)

-- MAIN APPLICATION
addappid(2214220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214221, 1, "5c2bae682f9e8fb9f957c4683cf802f2eb4ef95c7c17d867ebf91525695051cb")
