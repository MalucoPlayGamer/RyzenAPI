-- Lua provided by RyzenAPI
-- Game: addappid(626610)

-- MAIN APPLICATION
addappid(626610)

-- MAIN APP DEPOTS / PACKAGES
addappid(626611, 1, "5b20b9f8d584b1d834bd87b6cba07624173ab6764bff60dd387601bc4cc7e9a5")
