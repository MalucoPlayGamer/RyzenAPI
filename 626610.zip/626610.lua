-- Lua provided by RyzenAPI
-- Game: TT Isle of Man: Ride on the Edge

-- MAIN APPLICATION
addappid(626610)
addappid(756750)
addappid(814060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(626611, 1, "5b20b9f8d584b1d834bd87b6cba07624173ab6764bff60dd387601bc4cc7e9a5")
