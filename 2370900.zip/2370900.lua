-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy Character Pack - Dragon Knight Free Pack

-- MAIN APPLICATION
addappid(2370900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370900,0,"373c2308cdf6367406e284fc298106e13fb137ce45434b461d5fe018a906e3ae")

