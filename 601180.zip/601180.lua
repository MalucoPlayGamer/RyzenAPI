-- Lua provided by RyzenAPI
-- Game: AppID 601180

-- MAIN APPLICATION
addappid(601180)
-- Game: addappid(601180)

-- MAIN APP DEPOTS / PACKAGES
addappid(601181, 1, "def365cc7a29a4ce42622d363f4115d0593ff37527243eed3055805f25560e07")
