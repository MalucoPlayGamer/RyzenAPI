-- Lua provided by RyzenAPI
-- Game: AppID 601180

-- MAIN APPLICATION
addappid(601180)

-- MAIN APP DEPOTS / PACKAGES
addappid(601181, 1, "def365cc7a29a4ce42622d363f4115d0593ff37527243eed3055805f25560e07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
