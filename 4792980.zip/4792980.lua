-- 4792980's Lua and Manifest Created by Hubcap Manifest
-- Alice's Night at the Mansion
-- Created: July 27, 2026 at 23:31:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4792980) -- Alice's Night at the Mansion
-- MAIN APP DEPOTS
addappid(4792981, 1, "1f11c7221339ac4820a1f1e18dc274981894a49a4ebb104365b9d73afa720429") -- Depot 4792981
setManifestid(4792981, "3224654523208251330", 256827065)