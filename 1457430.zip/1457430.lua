-- Lua provided by RyzenAPI
-- Game: Game: 斗罗大陆-王国印记

-- MAIN APPLICATION
addappid(1457430)
-- Game: addappid(1457430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457431, 1, "e670976947018d324f3993083ba077873f6455f7e631c77b62d9928fc2dc5c95")
