-- Lua provided by RyzenAPI
-- Game: 501830

-- MAIN APPLICATION
addappid(501830)
-- Game: addappid(501830)

-- MAIN APP DEPOTS / PACKAGES
addappid(501831, 1, "02dac28e9b1f64cdff316d856e5844ebbcce3f45ba717bc521f7ea7875eeca7c")
