-- Lua provided by RyzenAPI
-- Game: Beat Saber - Britney Spears - Circus

-- MAIN APPLICATION
addappid(3181490)
-- Game: addappid(3181490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181490,0,"b77a28e145c1bd0d78736e05fe799964f307d0203998ba939aab7a33abf2000a")
