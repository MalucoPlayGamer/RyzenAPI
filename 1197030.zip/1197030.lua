-- Lua provided by RyzenAPI
-- Game: Mystic Pillars X Kantara

-- MAIN APPLICATION
addappid(1197030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197031, 1, "a4eb49bcb1861cd71be11003ca454c47dfa37dec9e1f01728615818f2708551c")

