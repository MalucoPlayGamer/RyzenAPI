-- Lua provided by RyzenAPI
-- Game: addappid(1829450)

-- MAIN APPLICATION
addappid(1829450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829451, 1, "82bd92ccf90d33362062a7f6f1d29764e709d1da70b6b2272baa083ad5f0aee1")
