-- Lua provided by RyzenAPI
-- Game: 2913550

-- MAIN APPLICATION
addappid(2913550)
-- Game: addappid(2913550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913551, 1, "fb06e9edfc26ac1f64423f6dbeae72e3ddeddede9b3d332153daddccb8fd8110")
