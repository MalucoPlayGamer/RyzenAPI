-- Lua provided by RyzenAPI
-- Game: Divine Ascent

-- MAIN APPLICATION
addappid(606300)
addappid(682950)

-- MAIN APP DEPOTS / PACKAGES
addappid(606301,0,"205a913da8d9421cee4edc2e43b8e9622560196724b24eed662cee9693b07c1f")

