-- Lua provided by RyzenAPI
-- Game: 2380450

-- MAIN APPLICATION
addappid(2380450)
-- Game: addappid(2380450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380451, 1, "f18ccf505d38ddcaf26f9ed2f31bd39e69b6c50d62207a901f1671f321524196")
