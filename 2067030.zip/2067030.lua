-- Lua provided by RyzenAPI
-- Game: Only Straight and Up!

-- MAIN APPLICATION
addappid(2067030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067032,0,"79e5a09ec4350c40143db381f99fd55f2e77f2fcb2042d9b03183aa1926269bc")

