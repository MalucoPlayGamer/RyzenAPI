-- Lua provided by RyzenAPI
-- Game: Figment 2: Creed Valley

-- MAIN APPLICATION
addappid(1085220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085221, 1, "83265318781b27b5f9fec6836c12a1e3cc67997751c2e9d43e38153292df1454")

