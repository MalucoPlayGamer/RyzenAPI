-- Lua provided by RyzenAPI
-- Game: 龙魂：魔都异闻 Demo

-- MAIN APPLICATION
addappid(2027320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027321, 1, "d794d857bd07c0059d171124a9010131c0e80a0889020c962a5b292dd64e8b5c")
