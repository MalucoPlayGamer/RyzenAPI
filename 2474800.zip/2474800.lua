-- Lua provided by RyzenAPI
-- Game: 2474800

-- MAIN APPLICATION
addappid(2474800)
-- Game: addappid(2474800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474801, 1, "a2392d5d247e9fdd6d0e4ba2a64a70fd041b7c0d80d556f731ec5cbf7410045b")
