-- Lua provided by SkyAPI 
-- Game: MiniRoyale Playtest
addappid(2023760)
addappid(2023761, 1, "eda557dd7a1f1bd3c7df8aed84c4492df57e3db4cb2e9c08e9538f993dd3cf81")
addappid(2023762, 1, "77a88519e034a0736ec93c54f46073c0dcc6c7449a1328ec8d424f4ab1f543a8")
addappid(2023763, 1, "fe0e8a531c393f58fdeb277d5350eae478b24260bf0dfea99ac3f7697c8cdc1d")
