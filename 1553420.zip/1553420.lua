-- Lua provided by RyzenAPI
-- Game: Game: Rifle Strike

-- MAIN APPLICATION
addappid(1553420)
-- Game: addappid(1553420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553421, 1, "666dd497656d395dac1c2beb63e57de215f6b421ae4af03f07188a84cb682574")
