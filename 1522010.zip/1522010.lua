-- Lua provided by RyzenAPI
-- Game: Game: Firescout

-- MAIN APPLICATION
addappid(1522010)
-- Game: addappid(1522010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522011, 1, "e3daf35ce7dfb7b21484b50d3bae31ef9ebf0edbbd8b8daa406fe7e14801d6fc")
