-- Lua provided by RyzenAPI
-- Game: AppID 1305420

-- MAIN APPLICATION
addappid(1305420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305421, 1, "e2a190fff002b76e61bc7ac0cc6e55561e04f6719710aa5a91df91458dd83c70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1580070)
addappid(1580080)
addappid(1617850)
addappid(1617851)
addappid(1617852)
addappid(1617853)
addappid(1617854)
addappid(1617855)
addappid(1617856)
addappid(1617857)
addappid(1617858)
addappid(1617859)
addappid(1617860)
addappid(1617861)
addappid(1617862)
addappid(1617863)
addappid(1617864)
addappid(1617940)
addappid(1617941)
addappid(1617942)
addappid(1617943)
addappid(1617944)
addappid(1617945)
addappid(1617946)
addappid(1617947)
addappid(1617948)
addappid(1617949)
addappid(1620760)
addappid(1620761)
addappid(1620762)
addappid(1821260)
addappid(1821261)
addappid(1821262)
addappid(1821263)
addappid(1821264)
addappid(1821265)
addappid(1821266)
addappid(1821267)
addappid(1821290)
addappid(1821291)
addappid(1821292)
addappid(1821293)
addappid(1836250)
