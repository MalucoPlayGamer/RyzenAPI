-- Lua provided by RyzenAPI 
-- Game: AppID 1305420
addappid(1305420)
addappid(1305421, 1, "e2a190fff002b76e61bc7ac0cc6e55561e04f6719710aa5a91df91458dd83c70")
