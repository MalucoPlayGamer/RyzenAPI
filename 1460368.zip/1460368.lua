-- Lua provided by RyzenAPI
-- Game: FUSER™ - Shaggy - "Boombastic (Hot Shot 2020)"

-- MAIN APPLICATION
addappid(1460368)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460368,0,"5991afe2407162b6a17e3f4fa02d88aaf55d6fe96c7f4f293fef12811fba4944")
