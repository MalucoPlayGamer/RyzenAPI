-- Lua provided by RyzenAPI
-- Game: 907620

-- MAIN APPLICATION
addappid(907620)
-- Game: addappid(907620)

-- MAIN APP DEPOTS / PACKAGES
addappid(907621, 1, "8202db4f6541f2631079af41588e2d462c5d0cfe13afe73887495a531f1f55e3")
