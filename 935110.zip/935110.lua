-- Lua provided by RyzenAPI
-- Game: The Desert's Rose

-- MAIN APPLICATION
addappid(935110)

-- MAIN APP DEPOTS / PACKAGES
addappid(935111, 1, "342f61e781dfd253100f85a642d52325e36347fe7832cfb37eaca3020182633b")
