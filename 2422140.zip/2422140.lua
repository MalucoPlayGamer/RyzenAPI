-- Lua provided by RyzenAPI
-- Game: Chill Town Demo

-- MAIN APPLICATION
addappid(2422140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422141, 1, "e257bbdd17877ac68f41f01979e4cac040e9d6dfda9515905c5d1a18908ec3a2")

