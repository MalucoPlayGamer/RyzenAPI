-- Lua provided by RyzenAPI
-- Game: Bitchy Boss Bimbofication

-- MAIN APPLICATION
addappid(1382530)
-- Game: addappid(1382530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382531, 1, "88845c47c20457253bc4651b0c1fe7bbf8544c9e65c2c7392c57958eb433e224")
