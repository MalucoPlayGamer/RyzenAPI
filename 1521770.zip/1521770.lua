-- Lua provided by RyzenAPI 
-- Game: Ero Tennis
addappid(1521770)
addappid(1521771, 1, "e735e00936c29457b3b590a1ffdbd387707fcf88ec109d675fe556fd4ced85dc")
