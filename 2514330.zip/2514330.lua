-- 2514330's Lua and Manifest Created by Hubcap Manifest
-- The Rabbit Haul
-- Created: August 27, 2026 at 05:43:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2514330) -- The Rabbit Haul
addtoken(2514330, "5225331592814449613")
-- MAIN APP DEPOTS
addappid(2514331, 1, "f2382480d3d950a06e3fbe13d08291186389bba828d03bd192898fd8aaf497b7") -- Depot 2514331
setManifestid(2514331, "3727938606991383572", 2377348487)