-- Lua provided by RyzenAPI
-- Game: The Rabbit Haul

-- MAIN APPLICATION
addappid(2514330) -- The Rabbit Haul

-- MAIN APP DEPOTS / PACKAGES
addappid(2514331, 1, "f2382480d3d950a06e3fbe13d08291186389bba828d03bd192898fd8aaf497b7") -- Depot 2514331
addtoken(2514330, "5225331592814449613")

