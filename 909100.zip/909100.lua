-- Lua provided by RyzenAPI
-- Game: Epic Fun

-- MAIN APPLICATION
addappid(909100)

-- MAIN APP DEPOTS / PACKAGES
addappid(909101, 1, "0f540c951c73fbdca40174bc1b4a27204a4a3393ce602d383271deb6b500c411")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1166820)
addappid(1166821)
addappid(1166822)
addappid(1166823)
addappid(1166824)
addappid(1166825)
addappid(1166826)
addappid(1166827)
