-- Lua provided by RyzenAPI
-- Game: Epic Fun

-- MAIN APPLICATION
addappid(909100)
-- Game: addappid(909100)

-- MAIN APP DEPOTS / PACKAGES
addappid(909101, 1, "0f540c951c73fbdca40174bc1b4a27204a4a3393ce602d383271deb6b500c411")
