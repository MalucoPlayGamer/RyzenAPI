-- Lua provided by RyzenAPI
-- Game: Lords of Ravage Demo

-- MAIN APPLICATION
addappid(3021170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021171, 1, "6b31c1a5cbed1f9eb4e9348a4c3b59fe296f6306facb72e7e66abfd121420bd5")

