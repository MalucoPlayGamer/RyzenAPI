-- Lua provided by RyzenAPI
-- Game: Blob From Space

-- MAIN APPLICATION
addappid(315070)

-- MAIN APP DEPOTS / PACKAGES
addappid(315071, 1, "12683623a359c61f17d1ecc93747c91aa81b66f3c29d9ac55172bcd84091743b")
