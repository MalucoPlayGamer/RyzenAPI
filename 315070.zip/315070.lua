-- Lua provided by RyzenAPI
-- Game: Blob From Space

-- MAIN APPLICATION
addappid(315070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(315071, 1, "12683623a359c61f17d1ecc93747c91aa81b66f3c29d9ac55172bcd84091743b")

