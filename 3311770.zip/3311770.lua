-- Lua provided by RyzenAPI
-- Game: Factorio: Space Age - Soundtrack

-- MAIN APPLICATION
addappid(3311770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311771, 1, "0565f14b3a4c063e57b257b849a52b2778d79106d0a3dacc462dabf6dc7bf0e7")
addappid(3311772, 1, "a990370a5957f13aa9ffa191a2f9fdb2bce9723697971288d0cdb65f2779cfa2")
