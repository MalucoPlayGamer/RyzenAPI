-- Lua provided by RyzenAPI
-- Game: Amer Fighting - عامر المشاجرة

-- MAIN APPLICATION
addappid(3264920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264921,0,"c2162121059c1464b55f6b531fb220acbfcc86ebfd6b1e915b8cbd4732b47597")

