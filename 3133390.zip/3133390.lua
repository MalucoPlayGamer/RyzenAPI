-- Lua provided by RyzenAPI
-- Game: 3133390

-- MAIN APPLICATION
addappid(3133390)
-- Game: addappid(3133390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133391, 1, "d63adaf2027ed48a09ee298a961c1f2b6e0b0d4ce1c03554b58d6dacdb1acaa2")
