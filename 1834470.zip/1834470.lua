-- Lua provided by RyzenAPI
-- Game: 1834470

-- MAIN APPLICATION
addappid(1834470)
-- Game: addappid(1834470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834471, 1, "2367f6a4f304a4aef267940d25b8e60583f8ad89e2ae32b23a54c49f03efc4d8")
