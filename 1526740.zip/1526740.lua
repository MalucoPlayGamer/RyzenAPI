-- Lua provided by RyzenAPI
-- Game: Lab Rat Demo

-- MAIN APPLICATION
addappid(1526740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526741, 1, "9d2955a57d136486891db0029f6d039d3b3dc3067ce5104149b32afb322271ef")

