-- Lua provided by SkyAPI 
-- Game: AppID 1526740
addappid(1526740)
addappid(1526741, 1, "9d2955a57d136486891db0029f6d039d3b3dc3067ce5104149b32afb322271ef")
