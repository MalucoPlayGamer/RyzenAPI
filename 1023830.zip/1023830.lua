-- Lua provided by RyzenAPI
-- Game: addappid(1023830)

-- MAIN APPLICATION
addappid(1023830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023831, 1, "489803a246557f84b770c4c7a60278c254ec11aad427f7386de173075b9cddfd")
