-- Lua provided by RyzenAPI
-- Game: 1736570

-- MAIN APPLICATION
addappid(1736570)
-- Game: addappid(1736570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736571, 1, "ea171882537ebdbcc855ad589bef8c5fbdfa1a7bc40943216d554e4838e1eef0")
