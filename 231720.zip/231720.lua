-- Lua provided by RyzenAPI
-- Game: Bad Hotel

-- MAIN APPLICATION
addappid(231720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(231721, 1, "5c3d826453633cdfedb1b49b2fc097181ea6771af113f30eb72af03510c4fd45")
addappid(231722, 1, "abe22413d3e184a5b2f0618377a0aed66d2780f45998fb9666cadf554bea793d")
addappid(231723, 1, "387132d8d4b370e4d604876b83d13b72f3141a79e3f61a6138838be1ee4336ec")

