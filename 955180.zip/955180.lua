-- Lua provided by RyzenAPI
-- Game: Shan Gui II Episode 2

-- MAIN APPLICATION
addappid(955180)

-- MAIN APP DEPOTS / PACKAGES
addappid(955180,0,"0322fff4522e53910e6abcc08c145a59568ef92ae85e71534fc3fa17139f76fd")
addappid(955185,0,"5f0478b72cd5281e7a219ceb90ba8ec695ceb4c832bff8dc4a6ec774ace0f0cc")
addappid(955186,0,"6abb538fb10229dadcd2624f7231dda8e3219269ab50bccf2fd4cc486a6409ce")
addappid(955187,0,"bc87f48898b539badc64124ce579251105aaac9d51c0c56cddc8ee2ac3c82bef")

