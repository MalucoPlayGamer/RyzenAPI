-- Lua provided by RyzenAPI
-- Game: Burial

-- MAIN APPLICATION
addappid(3554790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3554791, 1, "e29d22f12cc2f879e40ab18cc32a34fa82fea36c7b19b5ca2b19abef37beb325")

