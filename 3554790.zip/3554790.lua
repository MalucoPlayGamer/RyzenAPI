-- Lua provided by RyzenAPI
-- Game: Burial

-- MAIN APPLICATION
addappid(3554790)
-- Game: addappid(3554790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554791, 1, "e29d22f12cc2f879e40ab18cc32a34fa82fea36c7b19b5ca2b19abef37beb325")
