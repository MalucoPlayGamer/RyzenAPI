-- Lua provided by RyzenAPI
-- Game: Game of Thrones

-- MAIN APPLICATION
addappid(208730)

-- MAIN APP DEPOTS / PACKAGES
addappid(208731, 1, "b81b627e6e22df79427852ed15f68cf98fb1c0628b06b42ddc6b18462e53941d")
addappid(208732, 1, "af3e67ee72af32add0ffac8eaf365e6a7ba7978fae76a452914908394e2b3ea3")
addappid(208733, 1, "c4356775342c7d2f55a5cfcdf29ce213d1f7056d775b376556aeba497fe4c328")
addappid(208734, 1, "33a285a08b8b6290d1b802fa184220afc3a425f79563a6547220344eea225631")
addappid(208735, 1, "b8c74e36d39b1b1c7c6a38ff290132fa419ad50b190d92979de62f4faae8a2bd")
addappid(208736, 1, "e06833b2506d64cbf27a89588a08804d0ae72f49a07f396b107021534c8de0b0")
addappid(208737, 1, "ba96db9ede85399c0f22c13343ee9834881b9ae045ce603f563af6b8309ef4ad")
addappid(208740, 1, "b1089930a668d64a9ed9e2ee9f4b790415cb98b496afbef383fa82d4f31dfc08")
addappid(208741, 1, "0003b7ac240350e5853847d9817c66319bcfeaf2410034c2b7d9ef065a58fb84")
addappid(208742, 1, "8507a9ba26eaf754a518d389e05b17eca290866b11d5a8483729b37eb89d6ebc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(208743)
addappid(208744)
addappid(208745)
addappid(208746)
addappid(208747)
addappid(208748)
addappid(208749)
