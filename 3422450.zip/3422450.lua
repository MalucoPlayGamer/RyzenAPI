-- Lua provided by RyzenAPI
-- Game: 3422450

-- MAIN APPLICATION
addappid(3422450)
-- Game: addappid(3422450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422451, 1, "bb50c3368640da453d133afbc069a9999808178f58a9f47936bf9fca42b41a6a")
