-- Lua provided by RyzenAPI
-- Game: Archer boy

-- MAIN APPLICATION
addappid(1588000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588001, 1, "fc14c708425cc838e35552fb7f446d5418c179002aad66a6479a7eba7a75f21f")
