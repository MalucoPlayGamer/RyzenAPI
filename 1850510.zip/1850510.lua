-- Lua provided by RyzenAPI
-- Game: AppID 1850510

-- MAIN APPLICATION
addappid(1850510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850511, 1, "99eed402af9553dee98bf009dc96fb86d2f69b18d0d475147f36e1b6f8cc00ba")
addappid(1931660, 0, "bea5c4f508d15aba1f4095d42eb4aa470a112263e7aeb70917ea7550a785b4b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
