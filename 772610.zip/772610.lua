-- Lua provided by RyzenAPI
-- Game: Q-YO Blaster

-- MAIN APPLICATION
addappid(772610)

-- MAIN APP DEPOTS / PACKAGES
addappid(772611, 1, "81913eb3c6b2ea9cc7a9fd33492fa42bf342a3de79f08e75233d3d74ad488b1a")

