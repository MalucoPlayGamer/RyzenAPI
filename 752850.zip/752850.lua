-- Lua provided by RyzenAPI
-- Game: Choice of the Ninja

-- MAIN APPLICATION
addappid(752850)

-- MAIN APP DEPOTS / PACKAGES
addappid(752851, 1, "54f132643fa301d3ad8277d32aa0f0e3a65fccc01b5458d4f57e8d3e98dd889f")

