-- Lua provided by RyzenAPI
-- Game: Golf Party

-- MAIN APPLICATION
addappid(1417000)
-- Game: addappid(1417000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417001, 1, "36163f1536608f5fd9a3bb11c9794be7340b230aef5931af108d2812ecbb2d34")
