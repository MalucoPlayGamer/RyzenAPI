-- Lua provided by RyzenAPI
-- Game: Game: Spooky Mahjong

-- MAIN APPLICATION
addappid(1600240)
-- Game: addappid(1600240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600241, 1, "d8459fecee436e7c40e9cdb3f2651597d619f812570e8853e3892c13063a3b57")
addappid(1600242, 1, "2143203303ccee022820b758fb4f1fdac62121183c89bfdddc9f2825c7a1a7f6")
addappid(1600243, 1, "b43224c5f84f7a084d117034576fed157efda932ad955bde24a95467f7b2fd97")
