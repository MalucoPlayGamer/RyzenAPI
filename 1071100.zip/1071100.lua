-- Lua provided by RyzenAPI
-- Game: Game: Boom 3D Windows: Experience 3D surround sound in games

-- MAIN APPLICATION
addappid(1071100)
-- Game: addappid(1071100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071101, 1, "59a7304263d4314271b34b2318fac499949db736928b9c726f36fb989dab4417")
