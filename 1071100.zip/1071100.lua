-- Lua provided by RyzenAPI
-- Game: Boom 3D Windows: Experience 3D surround sound in games

-- MAIN APPLICATION
addappid(1071100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1071101, 1, "59a7304263d4314271b34b2318fac499949db736928b9c726f36fb989dab4417")

