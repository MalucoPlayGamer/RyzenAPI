-- Lua provided by RyzenAPI
-- Game: Game: Weakless

-- MAIN APPLICATION
addappid(1072620)
-- Game: addappid(1072620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072621, 1, "37c4492a626bfb774a91f4e3a6b3adb19fcb8661e673c88943bd6a2be0ca4c33")
