-- Lua provided by RyzenAPI
-- Game: addappid(861050)

-- MAIN APPLICATION
addappid(861050)

-- MAIN APP DEPOTS / PACKAGES
addappid(861051, 1, "21b777fca5a946f696e5f28a1bfefba74fe88618462f04f382ff4bed7c751a2d")
