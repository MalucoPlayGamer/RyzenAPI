-- Lua provided by RyzenAPI 
-- Game: Apartment No 129
addappid(2895340)
addappid(2895341, 1, "68c33779a985d189ed97eb4a6c57a3366d47c7ec271b5745fd4ea91b0533a58a")
