-- Lua provided by RyzenAPI
-- Game: 2087450

-- MAIN APPLICATION
addappid(2087450)
-- Game: addappid(2087450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087452,0,"f6304fef724d7e3335e808dfe3303a3b9c6ad92f8e30fd26448003939b06e7e1")
