-- Lua provided by RyzenAPI
-- Game: Game: Daily Wife

-- MAIN APPLICATION
addappid(1286340)
addappid(1291320)
-- Game: addappid(1286340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286341, 1, "6c17c65e6fdac47a20f1ca280fee245ef534958ed72a3fac7d7cd8e09214da83")
