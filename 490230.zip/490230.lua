-- Lua provided by RyzenAPI
-- Game: SWARMRIDERS

-- MAIN APPLICATION
addappid(490230)
