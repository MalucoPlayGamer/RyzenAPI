-- Lua provided by RyzenAPI
-- Game: SWARMRIDERS

-- MAIN APPLICATION
addappid(490230)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(527000)
