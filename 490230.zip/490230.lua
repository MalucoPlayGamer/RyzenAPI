-- Lua provided by RyzenAPI
-- Game: SWARMRIDERS

-- MAIN APPLICATION
addappid(490230)
addappid(527000)

