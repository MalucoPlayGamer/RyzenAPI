-- 2488370's Lua and Manifest Created by Hubcap Manifest
-- Cash Cleaner Simulator
-- Created: May 05, 2026 at 11:09:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2488370, 1, "890f37b45ab85bba704a5807707ae75961262bc0b5f50f44219a0faafaa0bf08") -- Cash Cleaner Simulator
-- MAIN APP DEPOTS
addappid(2488372, 1, "977e890c85c823ca9de5001068b30e038ade55c019c6e777e357cea4c148f33b") -- Depot 2488372
setManifestid(2488372, "1716580047508353223", 2702321779)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Cash Cleaner Simulator - LOUD  LOADED (AppID: 4037500)
addappid(4037500)
addappid(4037500, 1, "75ac3f64e37085ac5c56984e78af87f5b281aef66b79ffed4cfe2fba6c4916f7") -- Cash Cleaner Simulator - LOUD  LOADED - Depot 4037500
setManifestid(4037500, "5960218525984329386", 17022308)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3660310) -- Cash Cleaner Simulator - Luxury Loadout
addappid(3795660) -- Cash Cleaner Simulator - Slay the Look