-- Lua provided by RyzenAPI
-- Game: 2488370

-- MAIN APPLICATION
addappid(2488370)
addappid(3660310)
-- Game: addappid(2488370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488372,0,"977e890c85c823ca9de5001068b30e038ade55c019c6e777e357cea4c148f33b")
