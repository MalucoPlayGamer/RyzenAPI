-- Lua provided by RyzenAPI
-- Game: Survivor Girls of Monster Dungeon

-- MAIN APPLICATION
addappid(3147510)
-- Game: addappid(3147510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147511, 1, "e26c2ba8753312dc0d6bbea5f530b9ba6fc4772d64c55e5c877bf8c469c5882b")
