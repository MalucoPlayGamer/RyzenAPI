-- Lua provided by RyzenAPI
-- Game: 天临混元 Demo

-- MAIN APPLICATION
addappid(3125840)
-- Game: addappid(3125840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125841, 1, "eb4b6a4224a09c8d327b4d55aef2f0f9e45e0c645ba6ead2d9cd258c70aeefd1")
