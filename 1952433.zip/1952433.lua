-- Lua provided by RyzenAPI
-- Game: 1952433

-- MAIN APPLICATION
addappid(1952433)
-- Game: addappid(1952433)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952433,0,"d0b0dc7dc46d356f9a0ce235debd8af347bae94af79eb73ddd3bb2c99c7b6b2e")
