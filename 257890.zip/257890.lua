-- Lua provided by RyzenAPI
-- Game: AppID 257890

-- MAIN APPLICATION
addappid(257890)
-- Game: addappid(257890)

-- MAIN APP DEPOTS / PACKAGES
addappid(257891, 1, "9838e8a1a84dc6a7fe13fad377ab05bc463d8cfea8d33c01e274cdfed2fa353e")
