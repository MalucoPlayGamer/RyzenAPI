-- Lua provided by RyzenAPI
-- Game: Architectural Madman

-- MAIN APPLICATION
addappid(2660860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660861, 1, "b0b0371b5eb58df183e8d27fab199491ca6ade36d6f5bdf39c4bc2db792d784d")

