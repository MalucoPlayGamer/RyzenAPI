-- Lua provided by RyzenAPI
-- Game: Here Comes The Swarm

-- MAIN APPLICATION
addappid(3052730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052731,0,"25efa757967cde5cfa21a277239d5f05afff98c52586ae9b12699aaeac36c436")

