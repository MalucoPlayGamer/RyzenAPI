-- Lua provided by RyzenAPI
-- Game: Here Comes The Swarm

-- MAIN APPLICATION
addappid(3052730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052731,0,"25efa757967cde5cfa21a277239d5f05afff98c52586ae9b12699aaeac36c436")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
