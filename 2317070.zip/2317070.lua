-- Lua provided by RyzenAPI
-- Game: addappid(2317070)

-- MAIN APPLICATION
addappid(2317070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317071, 1, "3108c7ad7d4488a890dd271abe74dc548c44bcd41860c434300d95cb367a69d8")
