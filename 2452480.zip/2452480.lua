-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Girls

-- MAIN APPLICATION
addappid(2452480)
-- Game: addappid(2452480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452481, 1, "4a0013a3d6dd84dc49349764495c13540dd2dc9916b0cc51de7394d91cf4addf")
