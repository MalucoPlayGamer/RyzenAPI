-- Lua provided by RyzenAPI
-- Game: Catmouth Island

-- MAIN APPLICATION
addappid(336380)

-- MAIN APP DEPOTS / PACKAGES
addappid(336381, 1, "277e3b5300275001cac964dc8b48bc9fc5b160227f1cbde3e5e460e4ebb16a20")
addappid(336382, 1, "75e702aabb149142611ced0b6c0c28e76c81780855ec6ab4e69834690d1ba3b1")
addappid(336383, 1, "75ff48fcfc8ba17c954fefea60dc0a18793ac274aa10fe1eb1aa828e5a3a3467")
addappid(336384, 1, "0756281dc9e5cfac24e7a70188322586f9082568c15fe86af0dbb7d25ba48487")

