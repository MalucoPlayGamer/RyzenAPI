-- Lua provided by RyzenAPI
-- Game: Resonance Solstice

-- MAIN APPLICATION
addappid(3882350)

