-- Lua provided by RyzenAPI 
-- Game: Alta's Odyssey
addappid(2577890)
addappid(2577891, 1, "a2cdcb19aa3cb85df2231894468a8136c1c755ba73d62ff0ff401ab98d2bdbef")
