-- Lua provided by RyzenAPI
-- Game: 1763030

-- MAIN APPLICATION
addappid(1763030)
-- Game: addappid(1763030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763031, 1, "f8ba34dea2ca4cb65c6a6f52131ed7f233cc1a5ef8f88ca3a572cafbcf164695")
