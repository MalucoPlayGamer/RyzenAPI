-- Lua provided by RyzenAPI
-- Game: Isekai Reincarnation Magic Cock

-- MAIN APPLICATION
addappid(3250970)
-- Game: addappid(3250970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3250971, 1, "913b2213067e51f14c796da889b5f8b6145412eed9c5d84bf1e82532d72ae9da")
addappid(3250972, 1, "2615162d8b529519af52786e3b002fd84292f78f9f0ebfe29aeb6e7fa6c03c2e")
addappid(3250973, 1, "5e9e67aff4439914fe935ecbf0b410c2e452fd38b155793bfa678e8da7c0af25")
addappid(3250974, 1, "1f44ee3cc74188499315a8553de817aae3bb576292264f5bb5054ff6ba17b627")
