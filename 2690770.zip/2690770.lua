-- Lua provided by RyzenAPI
-- Game: Grandfather Simulator

-- MAIN APPLICATION
addappid(2690770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690771, 1, "8ab6977d922dcc8dcb37bef795857c43c57fb4b570e85216830df6b50b3464aa")

