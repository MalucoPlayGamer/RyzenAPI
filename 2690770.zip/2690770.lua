-- Lua provided by RyzenAPI
-- Game: Grandfather Simulator

-- MAIN APPLICATION
addappid(2690770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2690771, 1, "8ab6977d922dcc8dcb37bef795857c43c57fb4b570e85216830df6b50b3464aa")

