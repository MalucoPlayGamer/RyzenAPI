-- Lua provided by RyzenAPI
-- Game: Game: Fears to Fathom - Norwood Hitchhike

-- MAIN APPLICATION
addappid(1763050)
-- Game: addappid(1763050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763051, 1, "5506e30e0f825869abc207dee41bc99b82c73ca6939272e56149077f80618421")
