-- Lua provided by RyzenAPI
-- Game: addappid(1184360)

-- MAIN APPLICATION
addappid(1184360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184361, 1, "638637c32f6ff314c85712ac403290a5836e572e05c7f1d8a233ed2de950f9be")
