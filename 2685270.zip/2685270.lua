-- Lua provided by RyzenAPI
-- Game: 2685270

-- MAIN APPLICATION
addappid(2685270)
-- Game: addappid(2685270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685271, 1, "2038b9953d01a1da572642c8fe2eeb532c8aaabc269677930e9fe5621403b2e5")
