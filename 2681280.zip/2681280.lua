-- Lua provided by RyzenAPI
-- Game: The Queendom of Lithzena Demo

-- MAIN APPLICATION
addappid(2681280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681281, 1, "d4df565ccfd78a9f2e12ea2758ddba7b80a37f5b9558073ce874f43e7ab25d30")

