-- Lua provided by RyzenAPI
-- Game: Escape the Lab

-- MAIN APPLICATION
addappid(1141840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141841, 1, "78100f531cbe6b517b5040140065cfa4b49d50c2afcc9f9fc7f86163ce9875e9")

