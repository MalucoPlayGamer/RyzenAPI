-- Lua provided by RyzenAPI
-- Game: Roboquest

-- MAIN APPLICATION
addappid(692890)

-- MAIN APP DEPOTS / PACKAGES
addappid(692891, 1, "6de29760974d9a062f71a50a766e6560959934a90bd6c43849e4b5c2c3040c66")
addappid(2729110, 0, "7147a52fbc37206a8101897f11ccce51c3fe1fd5cb493899bfa7bc357f1b5d8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
