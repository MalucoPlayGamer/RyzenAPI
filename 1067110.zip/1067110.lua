-- Lua provided by RyzenAPI
-- Game: 1067110

-- MAIN APPLICATION
addappid(1067110)
-- Game: addappid(1067110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067111, 1, "6eae56adf57bafb84e4cf4f95006a2b11e10466c9bd0ae98d5cbc09924573f06")
