-- Lua provided by SkyAPI 
-- Game: Idle Chess Story
addappid(1067110)
addappid(1067111, 1, "6eae56adf57bafb84e4cf4f95006a2b11e10466c9bd0ae98d5cbc09924573f06")
