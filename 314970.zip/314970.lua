-- Lua provided by RyzenAPI
-- Game: Age of Conquest IV

-- MAIN APPLICATION
addappid(314970)

-- MAIN APP DEPOTS / PACKAGES
addappid(314972,0,"396501987959b82a84f236d50ef7ea8287396e16b7187fd48f52900807bb4f76")
addappid(314973,0,"6ea836d0bd664136bb7604901835432ce4ea969ef2c251cf3131cd6aaec15c69")
addappid(314975,0,"2c4747b848e1897e0909a93e8ba684a240b475ce4cb8f00e4a6cf436c4cd88c3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2006890)
