-- Lua provided by RyzenAPI
-- Game: Steel Empire

-- MAIN APPLICATION
addappid(563260)

-- MAIN APP DEPOTS / PACKAGES
addappid(563261, 1, "f98ef38f00815a7dbe86885408dda44bb0887b7506c0580acc8a9416f3197c2d")

