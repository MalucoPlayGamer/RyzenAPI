-- Lua provided by RyzenAPI
-- Game: Minute

-- MAIN APPLICATION
addappid(2556180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556181, 1, "a2c170abf1d1fbd3b6da15b0b3ec9f50effcae0c3e2cf71ef0ef7d2612ab34fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
