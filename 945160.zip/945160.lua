-- Lua provided by RyzenAPI
-- Game: Angelo and Deemon: One Hell of a Quest

-- MAIN APPLICATION
addappid(945160)

-- MAIN APP DEPOTS / PACKAGES
addappid(945161, 1, "fb7f641cd482bed4595fbaa08604eb6c8cecc097a05b376a0145041c887ec437")
addappid(945164, 1, "39dfb983420e96c9d74140376a60f8db16b1f22c1293174125670601abc21367")
