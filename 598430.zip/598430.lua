-- Lua provided by RyzenAPI
-- Game: addappid(598430)

-- MAIN APPLICATION
addappid(598430)

-- MAIN APP DEPOTS / PACKAGES
addappid(598431, 1, "4febb08bcbf50eb7d552996aea3c82da25bed4d8defc4371ce74d3a54fb0a097")
