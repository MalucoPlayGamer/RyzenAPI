-- Lua provided by RyzenAPI
-- Game: Book of Fei

-- MAIN APPLICATION
addappid(3733510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3733511,0,"271ea526cba23d131dc4a70146a0f1ab102e05aea331da678fe43a791aa57915")

