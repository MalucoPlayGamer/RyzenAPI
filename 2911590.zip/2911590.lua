-- Lua provided by RyzenAPI
-- Game: Sports Hero

-- MAIN APPLICATION
addappid(2911590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911591,0,"2cc071bdfe2cb7f5b8cafd321d285eb856ae8232343cb03b6e868b3d2425fd12")

