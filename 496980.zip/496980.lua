-- Lua provided by RyzenAPI
-- Game: Cosmic Cavern 3671　　宇宙最大の地底最大の作戦

-- MAIN APPLICATION
addappid(496980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(496981, 1, "5c026509d6bf8bec599d70ef11e9f861acd01eadadc8f9dd08c81dbb15ea0df7")

