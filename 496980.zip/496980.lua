-- Lua provided by RyzenAPI
-- Game: Cosmic Cavern 3671　　宇宙最大の地底最大の作戦

-- MAIN APPLICATION
addappid(496980)
-- Game: addappid(496980)

-- MAIN APP DEPOTS / PACKAGES
addappid(496981, 1, "5c026509d6bf8bec599d70ef11e9f861acd01eadadc8f9dd08c81dbb15ea0df7")
