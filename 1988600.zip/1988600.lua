-- Lua provided by RyzenAPI
-- Game: The Devil's Chosen

-- MAIN APPLICATION
addappid(1988600)
-- Game: addappid(1988600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988601, 1, "adcf9fa85838caa54dc96e5e5e21be14b7b2627c975181256fb4446d6be05ecd")
