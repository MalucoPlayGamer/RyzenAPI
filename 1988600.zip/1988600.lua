-- Lua provided by RyzenAPI 
-- Game: The Devil's Chosen
addappid(1988600)
addappid(1988601, 1, "adcf9fa85838caa54dc96e5e5e21be14b7b2627c975181256fb4446d6be05ecd")
