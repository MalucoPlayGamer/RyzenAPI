-- Lua provided by RyzenAPI
-- Game: Suicide Simulator

-- MAIN APPLICATION
addappid(703810)

-- MAIN APP DEPOTS / PACKAGES
addappid(703811, 1, "e630964f8039b1a4f087d82ddb090984edce501727b8fe3ba4e139e95ae823e2")

