-- Lua provided by RyzenAPI
-- Game: Cyber Hentai

-- MAIN APPLICATION
addappid(1476450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476451, 1, "29241d9c7c07372c53aad79aaf6f725b2aa07bd46174c0e19056ff976f41df8e")
