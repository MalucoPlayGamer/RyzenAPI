-- Lua provided by SkyAPI 
-- Game: Ant Keeping Simulator
addappid(2827520)
addappid(2827521, 1, "da03b07b1b769c2817297ba0355e1b0793d6dceb4e51827fed63f176c0b7580c")
