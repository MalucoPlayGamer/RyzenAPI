-- Lua provided by RyzenAPI
-- Game: Dusk Of Confinement

-- MAIN APPLICATION
addappid(793510)

-- MAIN APP DEPOTS / PACKAGES
addappid(793512,0,"1c662f73f6974fbee97d6df06cbe2f6655b8eb61c9fb01c1105079aa6280f197")
