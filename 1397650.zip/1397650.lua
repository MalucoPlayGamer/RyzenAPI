-- Lua provided by RyzenAPI
-- Game: 1397650

-- MAIN APPLICATION
addappid(1397650)
-- Game: addappid(1397650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397651, 1, "f3b63776f95b149ef94e99b31df768a616e21cff1a4aa83df04186368819bbfd")
