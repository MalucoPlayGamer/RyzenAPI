-- Lua provided by RyzenAPI
-- Game: Fretless - The Wrath of Riffson Soundtrack

-- MAIN APPLICATION
addappid(3796050)
-- Game: addappid(3796050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3796051, 1, "cfac1b334a2a406dd5b8ce356bcf5d073d1997c2cefb6e5c5bb396c307761535")
addappid(3796052, 1, "ffc7c5303fa6fac0e56f8c611a4b98c83a59ee5cf99ac6fb71ffa75e540a4079")
