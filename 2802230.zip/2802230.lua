-- Lua provided by RyzenAPI
-- Game: addappid(2802230)

-- MAIN APPLICATION
addappid(2802230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802231, 1, "51db5c0b4d7e53a848d239b9a1e90b2a1e45ada5ca2bc655e8c888a74ca00916")
