-- Lua provided by RyzenAPI
-- Game: Legendary Hoplite

-- MAIN APPLICATION
addappid(1479810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479811, 1, "2b9d9295cb75a5d28cc78bc571acd1bd0ec775cfe752c694552a6962df48d113")

