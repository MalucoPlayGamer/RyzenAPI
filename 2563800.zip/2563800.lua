-- Lua provided by RyzenAPI
-- Game: The Last Game

-- MAIN APPLICATION
addappid(2563800)
-- Game: addappid(2563800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563801, 1, "9d3d5574e946c291e66b5bb507aa9cbb6eac7a5b36d11d08f380d5416eba2137")
