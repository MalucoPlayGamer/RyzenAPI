-- Lua provided by SkyAPI 
-- Game: AppID 985430
addappid(985430)
addappid(985431, 1, "a2ed77677732da67b8078970a31fc88fb0fff6ee003e1ac3dfd73c8381b8acc4")
addappid(985432, 1, "23d29c3e88bdc5c4fcf1e440c7cbdceb8ddeacce4744b3fe1ef328b609d7dcc8")
addappid(985433, 1, "71ae8e8031c812c193d5446bbf5c232b1aef8f9a8bbd3621c8843c236c4d9c1c")
