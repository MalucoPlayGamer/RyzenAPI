-- Lua provided by RyzenAPI
-- Game: 玩具帝国 Demo

-- MAIN APPLICATION
addappid(2802220)
-- Game: addappid(2802220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802221, 1, "b0e98795e733790260f342acf3dfb0dab7432832f920acc00eb477ea94bbc81b")
