-- Lua provided by RyzenAPI
-- Game: Mandy's Room

-- MAIN APPLICATION
addappid(917740)

-- MAIN APP DEPOTS / PACKAGES
addappid(917741, 1, "5988659b6a54bbd58c20164f60a8cbc3cc3d32c50c1a888823d4de4928a4f324")
