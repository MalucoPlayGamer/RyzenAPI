-- Lua provided by RyzenAPI
-- Game: 2096990

-- MAIN APPLICATION
addappid(2096990)
-- Game: addappid(2096990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096991, 1, "6ee5ac0841feeac94fc3beb5346727470c12896d7fedc9290e63b3bcc5294e6a")
