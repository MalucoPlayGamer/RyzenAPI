-- Lua provided by RyzenAPI 
-- Game: King of Booze: Drinking Game
addappid(517470)
addappid(517471, 1, "6422f6d97dcbbfdd14d4859ce920c8520924a3f99880126bedf09185a2d86819")
