-- Lua provided by RyzenAPI 
-- Game: AppID 1099640
addappid(1099640)
addappid(1099641, 1, "c051cd87525c600ef8bb30546783427a158f4ca29cc54fcae46ddb6cf8331e26")
addappid(1099642, 1, "cb1f943c0d9ecf7a5a1c62c580ee62e1fcce48101ba518ce9b80d523562bbe3b")
