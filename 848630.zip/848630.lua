-- Lua provided by RyzenAPI
-- Game: Dinosaur Hunter

-- MAIN APPLICATION
addappid(848630)

-- MAIN APP DEPOTS / PACKAGES
addappid(848631,0,"a9bd34d83afe9c4f07aeb560ea5e39b2cf0624f56a0fa2d5a7f0cbdc90c10671")

