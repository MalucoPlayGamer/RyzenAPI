-- Lua provided by RyzenAPI
-- Game: addappid(447860)

-- MAIN APPLICATION
addappid(447860)

-- MAIN APP DEPOTS / PACKAGES
addappid(447861, 1, "d77c72a56dd01b390e27dbf537e16d72eaf2d0d99d85cf158ed0ebbc1bb45001")
