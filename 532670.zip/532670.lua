-- Lua provided by RyzenAPI
-- Game: addappid(532670)

-- MAIN APPLICATION
addappid(532670)

-- MAIN APP DEPOTS / PACKAGES
addappid(532671, 1, "4197fd00a9684b17f6757082240ae73ba1cbd5cfabbeafe16aad605ca4c02360")
