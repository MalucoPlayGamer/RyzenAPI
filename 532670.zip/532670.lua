-- Lua provided by RyzenAPI
-- Game: AppID 532670

-- MAIN APPLICATION
addappid(532670)

-- MAIN APP DEPOTS / PACKAGES
addappid(532671, 1, "4197fd00a9684b17f6757082240ae73ba1cbd5cfabbeafe16aad605ca4c02360")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
