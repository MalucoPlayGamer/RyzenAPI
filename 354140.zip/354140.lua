-- Lua provided by RyzenAPI
-- Game: 354140

-- MAIN APPLICATION
addappid(354140)
-- Game: addappid(354140)

-- MAIN APP DEPOTS / PACKAGES
addappid(354141, 1, "ab90f669c8c840ed1677b657358f1ea2469927005c05b738dc6f1a08c8ae4d7e")
