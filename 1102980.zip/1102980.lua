-- Lua provided by RyzenAPI
-- Game: 英雄群侠传

-- MAIN APPLICATION
addappid(1102980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102981, 1, "6062ec3b3936faf217a02b5406ba7f7c5405a016e0014c19b7142df757b6402b")
