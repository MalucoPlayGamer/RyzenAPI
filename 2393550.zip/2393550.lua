-- Lua provided by RyzenAPI
-- Game: JUMP TO SURVIVE 2

-- MAIN APPLICATION
addappid(2393550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393551, 1, "d92221310af4d7a6ec189b06d4d3be8c532dbb99942947fe89aa6ba843ae4ed4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
