-- Lua provided by RyzenAPI
-- Game: 2393550

-- MAIN APPLICATION
addappid(2393550)
-- Game: addappid(2393550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393551, 1, "d92221310af4d7a6ec189b06d4d3be8c532dbb99942947fe89aa6ba843ae4ed4")
