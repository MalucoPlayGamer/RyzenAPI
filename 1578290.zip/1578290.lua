-- Lua provided by RyzenAPI
-- Game: Pixel Fixel

-- MAIN APPLICATION
addappid(1578290)

