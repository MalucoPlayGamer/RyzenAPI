-- Lua provided by RyzenAPI
-- Game: Pixel Fixel

-- MAIN APPLICATION
addappid(1578290)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3006970)
