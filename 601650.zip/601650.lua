-- Lua provided by RyzenAPI
-- Game: AppID 601650

-- MAIN APPLICATION
addappid(601650)
addappid(626900)
-- Game: addappid(601650)

-- MAIN APP DEPOTS / PACKAGES
addappid(601651, 1, "23965e118b1bf443f6b19a20f5b67c0322f3757eb6b4d0cf9f0230cd080bd9c2")
addappid(601652, 1, "eab0682a76047f6bb5e56f7a5148c79a9cca645ef388adc846c7f9b8479ae6b6")
addappid(601653, 1, "0dda59092aa0c6c3a49ea6ca1ba026ae7281c486a3c8bdffea348c28eb7b912e")
