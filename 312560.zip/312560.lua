-- Lua provided by RyzenAPI
-- Game: Game: Xanadu Next

-- MAIN APPLICATION
addappid(312560)
-- Game: addappid(312560)

-- MAIN APP DEPOTS / PACKAGES
addappid(312561, 1, "316cc4a4fd642bdb62cf1949ec29955244ad7ee092b7fb0555826a0de2b945e9")
