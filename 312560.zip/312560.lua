-- Lua provided by RyzenAPI
-- Game: Xanadu Next

-- MAIN APPLICATION
addappid(312560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(312561, 1, "316cc4a4fd642bdb62cf1949ec29955244ad7ee092b7fb0555826a0de2b945e9")

