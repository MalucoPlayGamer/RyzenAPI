-- Lua provided by RyzenAPI
-- Game: PingPong Kings VR

-- MAIN APPLICATION
addappid(802310)

-- MAIN APP DEPOTS / PACKAGES
addappid(802311,0,"0e712b4954604741ee9575e3efe4ab5b364fc7dd2be19ac70f012ce457a10423")

