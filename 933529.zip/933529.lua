-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933529)

-- MAIN APP DEPOTS / PACKAGES
addappid(933529,0,"44b6f8bc39e68131c903078448d05dd4d27893fd94378e0ff3d369b55f621820")

