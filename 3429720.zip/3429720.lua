-- Lua provided by RyzenAPI
-- Game: 3429720

-- MAIN APPLICATION
addappid(3429720)
-- Game: addappid(3429720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3429721, 1, "d8d674c3ec92e81b64232b1def38c9f4404cf9fa1282cc5e435c0f7076429768")
