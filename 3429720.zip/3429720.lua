-- Lua provided by SkyAPI 
-- Game: Any Castle
addappid(3429720)
addappid(3429721, 1, "d8d674c3ec92e81b64232b1def38c9f4404cf9fa1282cc5e435c0f7076429768")
