-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Desert Kingdom Tileset

-- MAIN APPLICATION
addappid(3062870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062870,0,"eacd47a16a8625efe0f4802d233d109088c2315180b93c1064692e9993310e37")

