-- Lua provided by RyzenAPI
-- Game: 2820880

-- MAIN APPLICATION
addappid(2820880)
-- Game: addappid(2820880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820881, 1, "d1b2aba9a5d89b530f533ea0ad2c26ff45311516206efdcb758bb03977976d8f")
