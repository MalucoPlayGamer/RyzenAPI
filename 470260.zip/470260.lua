-- Lua provided by RyzenAPI
-- Game: Game: Event[0]

-- MAIN APPLICATION
addappid(470260)
addappid(571120)
-- Game: addappid(470260)

-- MAIN APP DEPOTS / PACKAGES
addappid(470261, 1, "7dd2701de80699048d137c0b334a63ee9998079722d55c1198760bb42a63dc2b")
addappid(470262, 1, "d9410fa313cb116fcc51426bb0d34740a8bd7ae33d9ff8d786b15a6a0798cc0f")
addappid(470263, 1, "17f5644b8d954c2ed401ee1b04d18954be19e32981b24c58d97c4f9922d100f7")
