-- Lua provided by RyzenAPI
-- Game: Event[0]

-- MAIN APPLICATION
addappid(470260)
addappid(571120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(470261, 1, "7dd2701de80699048d137c0b334a63ee9998079722d55c1198760bb42a63dc2b")
addappid(470262, 1, "d9410fa313cb116fcc51426bb0d34740a8bd7ae33d9ff8d786b15a6a0798cc0f")
addappid(470263, 1, "17f5644b8d954c2ed401ee1b04d18954be19e32981b24c58d97c4f9922d100f7")

