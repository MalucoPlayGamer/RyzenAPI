-- Lua provided by RyzenAPI
-- Game: addappid(63940)

-- MAIN APPLICATION
addappid(63940)

-- MAIN APP DEPOTS / PACKAGES
addappid(63941, 1, "e1659af0f71e5e5f53f9ead48a335a745b143e2cb3a39f48fbff137629e7a396")
addappid(63942, 0, "0dcde7389e9216d1c413317ad1bbe7c4dda709ac123d553ef609928d62bad5e6")
addappid(63943, 1, "7ef21e5dba6dda1163e6b788cc7b807c856656c3cd55b23394d0db2bab0a0927")
addappid(63944, 1, "94077c11491dfc26a5b880aa4102e76743b3721a2a392c531cc25aabba71530d")
addappid(63945, 1, "3e97f0312d2bdbcd0be9abec681bac06f4afea69bdb4bebdf60dbd83dc2722a3")
addappid(63946, 1, "90e7687a3babdd5f28ee76998b3e6b952a2d91234c3266be283de8e7bd388854")
addappid(63947, 1, "f5d76e82c913a8c923ea17a8515e60117ef952d71d8c8ccf74b0a2f7279755b7")
addappid(388209, 1, "1b1eaed914f626d66ac9273a2c4f63e9cf62e10dffceff7cec42bf8de10300ad")
