-- Lua provided by RyzenAPI
-- Game: Game: Venture Valley

-- MAIN APPLICATION
addappid(1395330)
-- Game: addappid(1395330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395331, 1, "9a94f036d44e2e80bb511c3fc060829e6b374878363e2c13c7cff6943562c50e")
addappid(1395332, 1, "5870c4f5296199e974128e0ed025f611ffb0a0de8fdd98cc7b235a09585d708c")
addappid(1395333, 1, "809ee0eda5947be0602c9b7ebf6ac60552cf02e793d690c29d130b20ef8e8d1f")
