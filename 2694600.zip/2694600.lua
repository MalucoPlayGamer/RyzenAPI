-- Lua provided by RyzenAPI
-- Game: My MILF Stepmom 2: Family Party💋

-- MAIN APPLICATION
addappid(2694600)
-- Game: addappid(2694600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694601, 1, "19187d8d586b9780102d84a217b3614c25c65f76997a5fad73bb2cb409140ae0")
