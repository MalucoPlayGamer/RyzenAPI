-- Lua provided by RyzenAPI
-- Game: Game: XP Soccer

-- MAIN APPLICATION
addappid(2013580)
-- Game: addappid(2013580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013581, 1, "033465ff1ddf2a116c9e997054c6b8f40896be162095225de5ab102a1c0ed568")
