-- Lua provided by RyzenAPI
-- Game: Where the Walls Breathe

-- MAIN APPLICATION
addappid(3456350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456351, 1, "6548e402b9bd5218d74f4ddfd8f6149f043567b5045a64ea44b1a8b23c108e64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
