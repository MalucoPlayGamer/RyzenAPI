-- Lua provided by RyzenAPI
-- Game: addappid(3456350)

-- MAIN APPLICATION
addappid(3456350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456351, 1, "6548e402b9bd5218d74f4ddfd8f6149f043567b5045a64ea44b1a8b23c108e64")
