-- Lua provided by RyzenAPI
-- Game: Game: Kidnapped Girl Soundtrack

-- MAIN APPLICATION
addappid(1357910)
-- Game: addappid(1357910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357911, 1, "d97aaf728beb07a137620e06bc3b74d637a568df4a43d3a2482f5eb0de31afbe")
