-- Lua provided by RyzenAPI 
-- Game: Kidnapped Girl Soundtrack
addappid(1357910)
addappid(1357911, 1, "d97aaf728beb07a137620e06bc3b74d637a568df4a43d3a2482f5eb0de31afbe")
