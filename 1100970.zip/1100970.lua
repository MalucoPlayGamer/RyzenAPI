-- Lua provided by SkyAPI 
-- Game: Dancing Girl
addappid(1100970)
addappid(1100971, 1, "c57cd5cc9ed14f994af9068105bdc410c08bdf3158ed79b7e8989f8b90ef0fb4")
addappid(1127340, 0, "bc4515729334c27c69917226f2be7d047d69ef59622852755249003f68ba29dd")
