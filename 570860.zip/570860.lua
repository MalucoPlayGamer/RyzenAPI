-- Lua provided by RyzenAPI
-- Game: AudioBeats

-- MAIN APPLICATION
addappid(570860)

-- MAIN APP DEPOTS / PACKAGES
addappid(570861, 1, "e075f02ad789a312a13ee0acdb223765d778252da61df6748fa0830da101b269")
addappid(570862, 1, "e644f8ea9e590f51c3d7948f5e55c1f4e58c1e8a017aa5489baf4b6ba1ca17db")
addappid(570863, 1, "fc750f520ac3c591986a83c0b54407022703e9886eb78bf5c48042a4ea0c3cb8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
