-- Lua provided by RyzenAPI
-- Game: 946190

-- MAIN APPLICATION
addappid(946190)
-- Game: addappid(946190)

-- MAIN APP DEPOTS / PACKAGES
addappid(946191, 1, "fcddea62d53c24a51e8275769149ee01f1c955d22164ec951d9d16e1d5c5c023")
