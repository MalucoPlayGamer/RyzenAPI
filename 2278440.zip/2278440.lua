-- Lua provided by SkyAPI 
-- Game: AppID 2278440
addappid(2278440)
addappid(2278441, 1, "7375cf3ab3a92e5bf328a72d0627fe8cc572f6af5690e3aae57f2dd1f6670087")
