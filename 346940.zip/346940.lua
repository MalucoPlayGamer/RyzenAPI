-- Lua provided by RyzenAPI
-- Game: Shadowrun: Hong Kong - Extended Edition

-- MAIN APPLICATION
addappid(346940)

-- MAIN APP DEPOTS / PACKAGES
addappid(346941, 1, "27059c95e2ea0fcddfff3d8e3e10403cc677af265451e7c3a857103f1a82fe8d")
addappid(346942, 1, "c87d166ef03b885d98979b2d3609acf596c97701a71212f6be9bc060c9e7e590")
addappid(346943, 1, "b65625e59d285912b45200c261aa6bcf41343e4e43f305e0e9f9eca9c0d8d27a")
addappid(395260, 0, "8361c13537643f3e20e1aeb1883b0bfdc2ffca9189dec5f535b080c0408a0c2c")
