-- Lua provided by RyzenAPI
-- Game: Hive Jump

-- MAIN APPLICATION
addappid(295670)
addappid(499260)

-- MAIN APP DEPOTS / PACKAGES
addappid(295671, 1, "7ddf150d40b7bf0841d19f7ba00201ba408d8831a29b97eee0adc06d62a1589b")
addappid(295672, 1, "caee44bbac28ef0c55442d7d4fe4d2183c17615073d4de644e8760783e4b99a7")
addappid(295673, 1, "e6f926544db6d5d691bae0b4fb6be6e022b17335f87f26c79e8eb5274baa0805")
addappid(582930, 0, "4fb5098f0d4b060bd9ed0101c54fb72275ad73b58ed33d6b4b6c9462787dfade")

