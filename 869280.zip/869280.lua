-- Lua provided by RyzenAPI
-- Game: RapStar Tycoon

-- MAIN APPLICATION
addappid(869280)
-- Game: addappid(869280)

-- MAIN APP DEPOTS / PACKAGES
addappid(869281, 1, "63f7f5a9649ed6dcbb8cd0cba2c194bfa96a6c4e2eeec252f2cb506842879d79")
