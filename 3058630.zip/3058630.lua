-- Lua provided by RyzenAPI
-- Game: Assetto Corsa EVO

-- MAIN APPLICATION
addappid(3058630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058631, 1, "a1cad1917f05e96692b066b5817fe026027823640d231576885a1f0dfe554a6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
