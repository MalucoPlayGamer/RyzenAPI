-- Lua provided by RyzenAPI
-- Game: Assetto Corsa EVO

-- MAIN APPLICATION
addappid(3058630)
-- Game: addappid(3058630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058631, 1, "a1cad1917f05e96692b066b5817fe026027823640d231576885a1f0dfe554a6e")
