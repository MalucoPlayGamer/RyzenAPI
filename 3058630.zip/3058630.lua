-- Lua provided by SkyAPI 
-- Game: Assetto Corsa EVO
addappid(3058630)
addappid(3058631, 1, "a1cad1917f05e96692b066b5817fe026027823640d231576885a1f0dfe554a6e")
