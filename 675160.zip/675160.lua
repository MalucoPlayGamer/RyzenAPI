-- Lua provided by RyzenAPI
-- Game: Game: Soldier Killer

-- MAIN APPLICATION
addappid(675160)
-- Game: addappid(675160)

-- MAIN APP DEPOTS / PACKAGES
addappid(675161, 1, "6eb94e0cae3f8057bba942289bb0048b9b2d0f5f28fe2b49600b9a9415afffd1")
