-- Lua provided by RyzenAPI
-- Game: Judofuri Demo

-- MAIN APPLICATION
addappid(3227940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227941, 1, "9e9aa80b6f5c2ae424298c14b7fadb5ea4e7ef6f27cdcc11d6cfbbe964ed358d")
