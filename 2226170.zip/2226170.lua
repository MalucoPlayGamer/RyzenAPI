-- Lua provided by RyzenAPI
-- Game: 东方梦无境 ～ Dreamland of Infinity Soundtrack

-- MAIN APPLICATION
addappid(2226170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226171, 1, "34c815a64ae611df65a48179bc49e0792fdb9c839cea2add1fd55d8b1cbca293")
addappid(2226172, 1, "e103fc7581df9cbfb1c5d3f176fdb8eb93791e9d9d05c8ff72d9b5a0d17d795e")
