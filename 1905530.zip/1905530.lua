-- Lua provided by RyzenAPI
-- Game: Game: Hammerwatch Anniversary Edition

-- MAIN APPLICATION
addappid(1905530)
-- Game: addappid(1905530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905531, 1, "93a15c5ea45c5d885deb881c4fc6c80083ab0438146fb0710d9cd62d34441854")
addappid(1905532, 1, "b4ecc5d1a82e7382994dbad334d99d99be7a84e626eb3fdf55c74355107a3660")
