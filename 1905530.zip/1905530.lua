-- Lua provided by RyzenAPI
-- Game: Hammerwatch Anniversary Edition

-- MAIN APPLICATION
addappid(1905530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1905531, 1, "93a15c5ea45c5d885deb881c4fc6c80083ab0438146fb0710d9cd62d34441854")
addappid(1905532, 1, "b4ecc5d1a82e7382994dbad334d99d99be7a84e626eb3fdf55c74355107a3660")

