-- Lua provided by RyzenAPI 
-- Game: Oik 2
addappid(611980)
addappid(611981, 1, "65d6c6beb0f957d312538d62871a0eb89d94b85e3c28e574365660c4d9ee3ba3")
