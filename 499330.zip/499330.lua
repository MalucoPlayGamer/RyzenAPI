-- Lua provided by RyzenAPI
-- Game: Game: Lord Mayor

-- MAIN APPLICATION
addappid(499330)
-- Game: addappid(499330)

-- MAIN APP DEPOTS / PACKAGES
addappid(499331, 1, "11129ee0fff7ad7f7c08f89c30d876ee5536ace53671387e2cf66e6d8322dc9d")
addappid(499332, 1, "8f8336ad7e007ec3fbab601790cf1fff84d0a1279264a49d6bd4961113ce2d94")
addappid(499333, 1, "0f1b7e7e5a4ac772cc2d06d38b3549280a5ea5f793174a56837a6a29bc27e731")
addappid(499334, 1, "6ea6b3710871bf31bcbd270e5f4aa29bc3636df125959d41428fd1f04b9a0d43")
