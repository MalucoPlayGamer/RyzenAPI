-- Lua provided by RyzenAPI
-- Game: Cavalry Girls  铁骑少女 Demo

-- MAIN APPLICATION
addappid(2084840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084841, 1, "8a441cf694d028291903fdd898d04dc7fe09db69542184818d413dd650e5071e")

