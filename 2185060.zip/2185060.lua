-- Lua provided by RyzenAPI
-- Game: Two Point Museum

-- MAIN APPLICATION
addappid(2185060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185061, 1, "a98101165ba3b99b3d98c5866360aa7cb08eeffd31ec95a9d024a824ff57c792")
addappid(2185062, 1, "50e06e5a50d397f8af97494176ecfb9f75bb4082443bbe1fb111f44715c18d61")
addappid(2185063, 1, "e68d0e65f0ced4a31e4932edecd8ff65ad2f1b503bff1b0e74faa05ae4d5356c")
addappid(2999841, 0, "17c8f80c3b69386aa95d085d8d9acf78ded50c7d234c3fe760843b1854e57d5d")
addappid(2999842, 0, "c17024c21617ad2a2c48ab1ef147fa5631840f4a8e92735f4ceddc9bcf4aa2cb")
addappid(2999843, 0, "e9ef0ab3c1526da46248fa2d6b362fe47d752025d6737c04217e276330a0f57f")
addappid(2999851, 0, "08a857d0c27299f066279413cf450e11262163e9fdd33ed8146402834a75a318")
addappid(2999852, 0, "6a30c41e89a00e6dccd56cde848599d00d6f98edb86f68d8ad3ca11a7772fbb7")
addappid(2999853, 0, "02e1edb27de1b992bbac282fe43c00b39aced6b5b1ff1e6dce02a711d64adbe4")
addappid(3592601, 0, "8fc6c6248dc796e6fd5cc6834560bebbe05cd43fca1209ce06cd28d42a3421b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2999840)
addappid(2999850)
addappid(3592600)
addappid(3804850)
addappid(4114070)
