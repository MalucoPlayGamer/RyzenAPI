-- Lua provided by RyzenAPI
-- Game: Speed Brawl

-- MAIN APPLICATION
addappid(468670)
-- Game: addappid(468670)

-- MAIN APP DEPOTS / PACKAGES
addappid(468671, 1, "65b8f4965b057a778cf6b4ab06d015c09eec29c5d3925f355b14f9edbafb4e1a")
