-- Lua provided by RyzenAPI
-- Game: Speed Brawl

-- MAIN APPLICATION
addappid(468670)

-- MAIN APP DEPOTS / PACKAGES
addappid(468671, 1, "65b8f4965b057a778cf6b4ab06d015c09eec29c5d3925f355b14f9edbafb4e1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
