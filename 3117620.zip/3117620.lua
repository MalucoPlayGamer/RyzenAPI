-- Lua provided by RyzenAPI
-- Game: Robabekya

-- MAIN APPLICATION
addappid(3117620)
-- Game: addappid(3117620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3117621, 1, "849a32f2700eef5b5d1be62bdfa33b716d67fd35fc673b55c1910a25f03eb722")
