-- Lua provided by RyzenAPI
-- Game: Achievement Machine

-- MAIN APPLICATION
addappid(851000)
-- Game: addappid(851000)

-- MAIN APP DEPOTS / PACKAGES
addappid(851001, 1, "7873dbaf63b43e713d8c0992bd03b8f340fb0dd9f146e7a3686f117c670f612e")
addappid(851002, 1, "bfeeb0a46b664267fb404d6f4da02766d11ecbd47666efdff1ffd8f643f79907")
