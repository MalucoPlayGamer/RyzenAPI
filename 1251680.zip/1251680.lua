-- Lua provided by RyzenAPI 
-- Game: Rescue Elves
addappid(1251680)
addappid(1251681, 1, "20200de47c79d62f9d9aa870eadf185cb2ed5f8c81e9034bf829fbcca083fa3c")
