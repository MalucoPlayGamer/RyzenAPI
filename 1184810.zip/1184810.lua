-- Lua provided by RyzenAPI 
-- Game: Mainframe Defenders
addappid(1184810)
addappid(1184811, 1, "8b76f08b9679d6c8d07606cb02055eb5642e457634bb0d90b71680d54e176ee0")
addappid(1184812, 1, "642142b10383b97e087a3d64cf9b6685965d74b3737b8c91908eaa13f7cea885")
