-- Lua provided by RyzenAPI
-- Game: 愚者之梦：零时将至

-- MAIN APPLICATION
addappid(3220070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220071, 1, "a3c3ca6b361f13858e98bbb46c475dfc29bc7a807e67946013c060029aec6673")

