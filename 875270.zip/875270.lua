-- Lua provided by RyzenAPI
-- Game: Anceder

-- MAIN APPLICATION
addappid(875270)

-- MAIN APP DEPOTS / PACKAGES
addappid(875271,0,"a6cf9404a7af974dd2fc67e66fe0b3719bc22291ae9b5d4fc4a80c2dd8ccbd50")

