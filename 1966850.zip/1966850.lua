-- Lua provided by RyzenAPI
-- Game: DEEP 8 Soundtrack

-- MAIN APPLICATION
addappid(1966850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966851, 1, "fed862fff9c520a6d1464be1c32f89b5cff5b1a40ab250e58b228d5fdbf598da")

