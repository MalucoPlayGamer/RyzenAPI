-- Lua provided by RyzenAPI 
-- Game: AppID 843990
addappid(843990)
addappid(843991, 1, "8164cd8b311e390877e0556c3963aae1ba8612f442e0b293a74f7b2415b3da69")
