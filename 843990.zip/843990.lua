-- Lua provided by RyzenAPI
-- Game: AppID 843990

-- MAIN APPLICATION
addappid(843990)

-- MAIN APP DEPOTS / PACKAGES
addappid(843991, 1, "8164cd8b311e390877e0556c3963aae1ba8612f442e0b293a74f7b2415b3da69")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
