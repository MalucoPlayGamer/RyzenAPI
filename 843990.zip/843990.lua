-- Lua provided by RyzenAPI
-- Game: Game: AppID 843990

-- MAIN APPLICATION
addappid(843990)
-- Game: addappid(843990)

-- MAIN APP DEPOTS / PACKAGES
addappid(843991, 1, "8164cd8b311e390877e0556c3963aae1ba8612f442e0b293a74f7b2415b3da69")
