-- Lua provided by RyzenAPI
-- Game: Delirium: Echoes of the Domino

-- MAIN APPLICATION
addappid(3707610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3707611, 1, "b9e71f44d23762797996433881e445f1fbc02aeaf967178b645be599d08e72fa")

