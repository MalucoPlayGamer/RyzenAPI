-- Lua provided by RyzenAPI
-- Game: RUUUUUUN

-- MAIN APPLICATION
addappid(2027300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027301, 1, "afdcaa476f555d82e9ce7933a34f38f6ce9b581a91d5901ebb62a93b0b64659f")

