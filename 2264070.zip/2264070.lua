-- Lua provided by RyzenAPI
-- Game: 无梦少女 DreamlessGirl Demo

-- MAIN APPLICATION
addappid(2264070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264071, 1, "dd3bd7c5439317b447c8c10816541b269ddb4dd5fd98e9a9fbe2c67e97792eab")
