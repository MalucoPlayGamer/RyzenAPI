-- Lua provided by RyzenAPI
-- Game: addappid(869560)

-- MAIN APPLICATION
addappid(869560)
addappid(983490)

-- MAIN APP DEPOTS / PACKAGES
addappid(869561, 1, "5383cc0fe89f26040aeeac0ad3ac8ebfd72a8f77fed77e73ca20c09f38da18e0")
