-- Lua provided by RyzenAPI 
-- Game: AppID 530130
addappid(530130)
addappid(530131, 1, "18ca18266c7ccf242140a4f82441b0187f9aa013a18a77f99efaa3c10adee574")
addappid(530132, 1, "196c0f812824826466670ea7e3498f655cb181bf645870e232637db9fba5b0c3")
