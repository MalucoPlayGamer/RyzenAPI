-- Lua provided by RyzenAPI
-- Game: Mask of Mists

-- MAIN APPLICATION
addappid(1215280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215281, 1, "c3de316fb157f3ff053c536a72c8fc22f4772472b9206b6a3a4fc82e87ea3860")

