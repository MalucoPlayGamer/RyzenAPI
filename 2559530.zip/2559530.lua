-- Lua provided by RyzenAPI
-- Game: Backrooms:Run For Your Life!

-- MAIN APPLICATION
addappid(2559530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559531, 1, "275e8129dfa96313e953a18853b12594f06f562472d058e6d74cc4e503894f1e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
