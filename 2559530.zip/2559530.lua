-- Lua provided by RyzenAPI
-- Game: Backrooms:Run For Your Life!

-- MAIN APPLICATION
addappid(2559530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559531, 1, "275e8129dfa96313e953a18853b12594f06f562472d058e6d74cc4e503894f1e")
