-- Lua provided by RyzenAPI
-- Game: 1637120

-- MAIN APPLICATION
addappid(1637120)
-- Game: addappid(1637120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637121, 1, "9cb69b32783b0b923b8a62462408b01bf515d78b51cc678c0e22bc154fb603b3")
