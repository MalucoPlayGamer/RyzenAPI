-- Lua provided by RyzenAPI
-- Game: Hyde & Seek

-- MAIN APPLICATION
addappid(1637120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637121, 1, "9cb69b32783b0b923b8a62462408b01bf515d78b51cc678c0e22bc154fb603b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
