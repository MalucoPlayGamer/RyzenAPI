-- Lua provided by RyzenAPI
-- Game: Memories From Beyond a Coral Sea

-- MAIN APPLICATION
addappid(2318280)
addappid(3722560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318281, 1, "9b2f91220591fcd053becf2a1b5962aa928f8836415d9cbdae44b6058146ad86")
