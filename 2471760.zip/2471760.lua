-- Lua provided by RyzenAPI
-- Game: Dekamara

-- MAIN APPLICATION
addappid(2471760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471761, 1, "64c916ab7ff4bc842fd094ac1e8f45aa817917f7757222d5192bb84deae1517f")

