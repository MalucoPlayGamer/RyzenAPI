-- Lua provided by RyzenAPI 
-- Game: INVISIBLE
addappid(777560)
addappid(777561, 1, "7f080a00a6227be89f644bc77976ede03091b1eab5e89090e662d9187476a825")
