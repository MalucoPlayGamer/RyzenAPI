-- Lua provided by RyzenAPI
-- Game: Game: INVISIBLE

-- MAIN APPLICATION
addappid(777560)
-- Game: addappid(777560)

-- MAIN APP DEPOTS / PACKAGES
addappid(777561, 1, "7f080a00a6227be89f644bc77976ede03091b1eab5e89090e662d9187476a825")
