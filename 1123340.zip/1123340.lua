-- Lua provided by RyzenAPI
-- Game: AppID 1123340

-- MAIN APPLICATION
addappid(1123340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1123341, 1, "a67749fdda15a0d4e7bad6d0e3b62edc6037bce3d0e9349a46fd4863b42dad37")

