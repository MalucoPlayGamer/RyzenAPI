-- Lua provided by RyzenAPI
-- Game: addappid(1123340)

-- MAIN APPLICATION
addappid(1123340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123341, 1, "a67749fdda15a0d4e7bad6d0e3b62edc6037bce3d0e9349a46fd4863b42dad37")
