-- Lua provided by RyzenAPI
-- Game: CasinoRPG

-- MAIN APPLICATION
addappid(658970)
