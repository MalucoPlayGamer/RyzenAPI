-- Lua provided by RyzenAPI 
-- Game: AppID 859950
addappid(859950)
addappid(859951, 1, "4439fc3864f19d1616b91316b9277619ba63e41f23024f2cabb456fb01896475")
