-- Lua provided by RyzenAPI 
-- Game: Little Racers STREET
addappid(262690)
addappid(262691, 1, "b9e718382b6f41d96f3f58b7bd96a0ffa24c3e1ea81256aaa43a6c13d1def766")
addappid(262692, 1, "9fe0c9612aa526ba9d64741e925578ac84db1470e4eab23f2f0297de04589f1e")
addappid(262693, 1, "391a6096201b18c03eb68c9499342a9690b47330a3af058583b255b9fd188146")
