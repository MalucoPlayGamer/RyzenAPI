-- Lua provided by RyzenAPI
-- Game: Little Racers STREET

-- MAIN APPLICATION
addappid(262690)

-- MAIN APP DEPOTS / PACKAGES
addappid(262691, 1, "b9e718382b6f41d96f3f58b7bd96a0ffa24c3e1ea81256aaa43a6c13d1def766")
addappid(262692, 1, "9fe0c9612aa526ba9d64741e925578ac84db1470e4eab23f2f0297de04589f1e")
addappid(262693, 1, "391a6096201b18c03eb68c9499342a9690b47330a3af058583b255b9fd188146")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
