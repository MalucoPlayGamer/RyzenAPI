-- Lua provided by RyzenAPI
-- Game: Game: Drunken FC

-- MAIN APPLICATION
addappid(1991820)
-- Game: addappid(1991820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991821, 1, "72ff0e7650cfe58c466b94b85971822e149725390ef435f97c1480ad4d78a520")
