-- Lua provided by SkyAPI 
-- Game: Drunken FC
addappid(1991820)
addappid(1991821, 1, "72ff0e7650cfe58c466b94b85971822e149725390ef435f97c1480ad4d78a520")
