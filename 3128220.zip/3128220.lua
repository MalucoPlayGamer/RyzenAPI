-- Generated with Luie @ https://lua.tools/
-- 3128220 - Nerd Simulator
-- Generated 2026-08-27 22:19:57 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3128220)

-- Main Depots
addappid(3128221, 1, "f9004f811e6a409013dd25edd4c80d7a01d28537350edd79a8ad4007af8cde6a") -- (windows)
setManifestid(3128221, "1167072210493121871", 2167397161)
