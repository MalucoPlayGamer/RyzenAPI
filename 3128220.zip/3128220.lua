-- Lua provided by RyzenAPI
-- Game: Nerd Simulator

-- MAIN APPLICATION
addappid(3128220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128221, 1, "f9004f811e6a409013dd25edd4c80d7a01d28537350edd79a8ad4007af8cde6a") -- (windows)

