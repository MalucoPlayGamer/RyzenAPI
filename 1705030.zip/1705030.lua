-- Lua provided by RyzenAPI
-- Game: Wadality

-- MAIN APPLICATION
addappid(1705030)
-- Game: addappid(1705030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705031, 1, "5f67aae86b3ac0938ae97085fcb4249cdba3c8d6211a538b00196662916563d4")
