-- Lua provided by SkyAPI 
-- Game: GLASS
addappid(1431570)
addappid(1431571, 1, "5c8ec50eb57dbc188d9fcd63de6b3e27b2fb769f4d700c95158ea15a80d5d34a")
addappid(1431572, 1, "e28706462af86f19c802826484b5eb2078361d33778f26c6a1bff66258f793f9")
