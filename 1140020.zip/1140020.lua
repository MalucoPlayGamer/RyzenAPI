-- Lua provided by RyzenAPI
-- Game: Cetetorius

-- MAIN APPLICATION
addappid(1140020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1140021, 1, "ede35cfaa92d0e5ba442bfbfe089b0a8a303648bbbea2fedb64d425e1e94d1dc")
addappid(1140022, 1, "490510f82cf7756e2b13fd57e2aa909cf9ac49a2545bd08b0c9dac174e1a9d9f")

