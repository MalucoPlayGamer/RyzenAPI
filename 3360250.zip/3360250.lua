-- Lua provided by RyzenAPI
-- Game: My Cute Egg Diary

-- MAIN APPLICATION
addappid(3360250)
-- Game: addappid(3360250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360251, 1, "918d4814efa55e2269519a219abfcf1ef6b02962624e3f8bc19ce92fcb8867d3")
