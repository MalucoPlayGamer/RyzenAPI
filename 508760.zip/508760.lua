-- Lua provided by RyzenAPI
-- Game: Game: Ball of Wonder

-- MAIN APPLICATION
addappid(508760)
-- Game: addappid(508760)

-- MAIN APP DEPOTS / PACKAGES
addappid(508761, 1, "295ab3e2d05aef1794d02195dd05a3a474e4125d8e2741b56d80ab6d47632f87")
addappid(508762, 1, "300cee25c857dfad610e8a97b9e27000215a2edd6e55397dcffd40936352683c")
addappid(508763, 1, "1f8b2d86167c2ade682470e5ddea0acad72588d4a86ed479055c33be7d931194")
addappid(508764, 1, "d52d0d6052ac7a845a8887d98ba72de7e629b7b47942b6b4f233ed073951a25c")
