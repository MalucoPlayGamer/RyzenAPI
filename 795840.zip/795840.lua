-- Lua provided by RyzenAPI
-- Game: 795840

-- MAIN APPLICATION
addappid(795840)
-- Game: addappid(795840)

-- MAIN APP DEPOTS / PACKAGES
addappid(795841, 1, "728892eb65a0f44b4f0c99b43c8f1456417e1c77cb65690f3eaa8ee4ff8778fc")
addappid(795842, 1, "e2dde721d8d6b465cef6e11ae8ae5c87e6bae625308e04071f0558454acb4c9c")
addappid(795843, 1, "2bea848409ab479a28ae4bdb1666a708cc34f31ad9e770acce7789e4ba345082")
