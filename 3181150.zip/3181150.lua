-- Lua provided by RyzenAPI
-- Game: Theater of Death

-- MAIN APPLICATION
addappid(3181150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3181151, 1, "85361eea0a2d82f9653c3b4a00c365429ece20fb82da8ec1098f30168f3c54c6")

