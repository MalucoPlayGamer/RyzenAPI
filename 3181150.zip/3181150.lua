-- Lua provided by SkyAPI 
-- Game: Theater of Death
addappid(3181150)
addappid(3181151, 1, "85361eea0a2d82f9653c3b4a00c365429ece20fb82da8ec1098f30168f3c54c6")
