-- Lua provided by RyzenAPI
-- Game: Theater of Death

-- MAIN APPLICATION
addappid(3181150)
-- Game: addappid(3181150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181151, 1, "85361eea0a2d82f9653c3b4a00c365429ece20fb82da8ec1098f30168f3c54c6")
