-- 1968430's Lua and Manifest Created by Hubcap Manifest
-- Camp Buddy: Scoutmaster Season
-- Created: August 05, 2026 at 05:27:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1968430, 1, "98e7f0c9c52923e83307899d212d6e2080f3df493e6abd51b5dd9a99b7d6712f") -- Camp Buddy: Scoutmaster Season
-- MAIN APP DEPOTS
addappid(1968431, 1, "5628cb07cc8b77300b89f279df4bb8aa8dfc56f7523d5e2b594ea90d882787cc") -- Depot 1968431
setManifestid(1968431, "91314646489444271", 6798503221)
addappid(1968432, 1, "7b23587859ff2a79aedb9c8b2b731e47145f2e1b6d8ce870bb338c565077ba78") -- Depot 1968432
setManifestid(1968432, "6502114505501169887", 6798503221)
addappid(1968433, 1, "274d680dbd051a22cd00e0a858b109cfc28e9a3e57e5e7644e1889f9773cd47b") -- Depot 1968433
setManifestid(1968433, "1914277657247934455", 6722014885)
-- DLCS WITH DEDICATED DEPOTS
-- Camp Buddy Scoutmaster Season - Side Stories (AppID: 3601730)
addappid(3601730)
addappid(3601730, 1, "66d4c302302bd59344adf4d49380f96647c689308bb1d597120cee6d9ad64583") -- Camp Buddy Scoutmaster Season - Side Stories - Depot 3601730
setManifestid(3601730, "5224913871433599083", 678984068)
-- Camp Buddy Scoutmaster Season - The Journal (AppID: 4091000)
addappid(4091000)
addappid(4091000, 1, "43954be16cdc47f322a638ab480458ca3e9cdb724560b7fd67a576df7ea73398") -- Camp Buddy Scoutmaster Season - The Journal - Depot 4091000
setManifestid(4091000, "8110325017292202619", 1032748278)