-- Lua provided by RyzenAPI
-- Game: Unlog

-- MAIN APPLICATION
addappid(3570210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3570211, 1, "540fc79ae052dd39d6e2023fde1793aef5bc0c24adff302a6439543826ef8e47")

