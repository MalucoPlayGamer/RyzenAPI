-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1912080)
-- Game: addappid(1912080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912080,0,"2455e072c56a51c2417166ecb1697d7d3a23cb8afb42605243888129b1fa8eca")
