-- Lua provided by RyzenAPI
-- Game: AppID 331220

-- MAIN APPLICATION
addappid(331220)

-- MAIN APP DEPOTS / PACKAGES
addappid(331221, 1, "090e7bb28d5821f9f74073c35ea1675f72cd68e4c918f85e2e5e773d11259556")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
