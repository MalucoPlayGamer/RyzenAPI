-- Lua provided by RyzenAPI
-- Game: AppID 331220

-- MAIN APPLICATION
addappid(331220)
-- Game: addappid(331220)

-- MAIN APP DEPOTS / PACKAGES
addappid(331221, 1, "090e7bb28d5821f9f74073c35ea1675f72cd68e4c918f85e2e5e773d11259556")
