-- Lua provided by RyzenAPI
-- Game: AppID 2571570

-- MAIN APPLICATION
addappid(2571570)
-- Game: addappid(2571570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571571, 1, "5cbbd8ff2bc652bf460832f3048293461690d18aad3e567817f923baabd1aae0")
