-- Lua provided by RyzenAPI
-- Game: 黎明前夜 Demo

-- MAIN APPLICATION
addappid(2571570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571571, 1, "5cbbd8ff2bc652bf460832f3048293461690d18aad3e567817f923baabd1aae0")

