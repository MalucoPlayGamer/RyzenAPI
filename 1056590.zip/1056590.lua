-- Lua provided by RyzenAPI
-- Game: 1056590

-- MAIN APPLICATION
addappid(1056590)
-- Game: addappid(1056590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056591, 1, "8132c19b52da0df3d777b71c8473e7c7ad8ee981554dc43fd4d890ee1de4871b")
