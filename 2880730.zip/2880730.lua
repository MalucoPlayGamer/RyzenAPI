-- Lua provided by RyzenAPI
-- Game: AI2U: With You 'Til The End

-- MAIN APPLICATION
addappid(2880730)
-- Game: addappid(2880730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880731, 1, "e2ca87b16b3ac8c52ccd235d0e58670b6d208f1fa79f280ba0b72586dc36340a")
