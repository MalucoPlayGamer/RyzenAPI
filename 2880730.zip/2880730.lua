-- Lua provided by RyzenAPI 
-- Game: AI2U: With You 'Til The End
addappid(2880730)
addappid(2880731, 1, "e2ca87b16b3ac8c52ccd235d0e58670b6d208f1fa79f280ba0b72586dc36340a")
