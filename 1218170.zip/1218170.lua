-- Lua provided by RyzenAPI 
-- Game: 回门 Way Back Home
addappid(1218170)
addappid(1218171, 1, "67c7b64ea13efa8a2efbb2d24a9b50510773f8af77c8752b6dc1e4658d263b0f")
