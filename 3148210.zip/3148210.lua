-- Lua provided by RyzenAPI
-- Game: 99 Games: Puzzle, Action, Strategy, Simulation, Casual, Roguelike, Shooter, RPG & More

-- MAIN APPLICATION
addappid(3148210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148211,0,"6c6e9e1137b29fba4007b787253841e9bd18b43932bc26a32de58c7c43153144")

