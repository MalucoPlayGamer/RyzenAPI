-- Lua provided by RyzenAPI
-- Game: addappid(3430)

-- MAIN APPLICATION
addappid(3430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431, 1, "ed13e3de6809d8f88444827ef4856183ef42fe1abc78a0d74885e0c07205ffc8")
