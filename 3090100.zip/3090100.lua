-- Lua provided by RyzenAPI
-- Game: Prison Princess: Trapped Allure

-- MAIN APPLICATION
addappid(3090100)
-- Game: addappid(3090100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090101, 1, "55ec45e591ca45d31ce7526bd025a7eedb4ff0cb4ee6d3421a879bf84c2e90c0")
