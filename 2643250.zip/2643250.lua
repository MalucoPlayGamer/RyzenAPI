-- Lua provided by RyzenAPI
-- Game: Waifu fighter - F-ist & Flirtatious: Ch.1 A decisive match

-- MAIN APPLICATION
addappid(2643250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643321,0,"9f7363001ef0ef8ce72e7c5b1ffa18acfc42910a12d7f49eac6f1b0ea5327314")

