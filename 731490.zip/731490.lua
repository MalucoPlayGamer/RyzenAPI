-- Lua provided by RyzenAPI
-- Game: 731490

-- MAIN APPLICATION
addappid(731490)
-- Game: addappid(731490)

-- MAIN APP DEPOTS / PACKAGES
addappid(731491, 1, "66bc6c9ffa8740c78dfc58ecf2a422883a6a3a30031fe52641f0060903610ab8")
addappid(731492, 1, "ca39fb3667416ca9ec3ac95ecb8fdfe1a11fc5bb2e9c2a429be87eb476df46d1")
