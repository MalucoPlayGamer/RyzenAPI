-- Lua provided by RyzenAPI
-- Game: AppID 704660

-- MAIN APPLICATION
addappid(704660)
-- Game: addappid(704660)

-- MAIN APP DEPOTS / PACKAGES
addappid(704661, 1, "b1e51d957f79c14c8e645a1ceedb094bf47708bbd7b3a24eb25d397959f6e1b7")
