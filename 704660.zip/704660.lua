-- Lua provided by SkyAPI 
-- Game: AppID 704660
addappid(704660)
addappid(704661, 1, "b1e51d957f79c14c8e645a1ceedb094bf47708bbd7b3a24eb25d397959f6e1b7")
