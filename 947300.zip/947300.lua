-- Lua provided by RyzenAPI
-- Game: Grim Nights

-- MAIN APPLICATION
addappid(947300)
addappid(1025340)
-- Game: addappid(947300)

-- MAIN APP DEPOTS / PACKAGES
addappid(947301, 1, "248937bf71768e986d736c2d6804074d7f449dd6754e39e318ac4d18d051555e")
addappid(947302, 1, "2527701ca06a045be832f604e510e3fff20299748d9cf60f44c18d73552a54db")
