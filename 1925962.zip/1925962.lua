-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Meal Time Tileset - Modern edition

-- MAIN APPLICATION
addappid(1925962)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925962,0,"dab1312527c61a0a3087126e5f6911612b63335d9841275dae5182c05c4add72")

