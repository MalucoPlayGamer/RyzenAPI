-- Lua provided by RyzenAPI
-- Game: 1799190

-- MAIN APPLICATION
addappid(1799190)
-- Game: addappid(1799190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799191, 1, "43575236687393d2ad540a7d7f63323ac36a967c86e9f5a0ca3d2f2cd4ea0d16")
