-- Lua provided by RyzenAPI
-- Game: Game: Keeplanet

-- MAIN APPLICATION
addappid(703120)
-- Game: addappid(703120)

-- MAIN APP DEPOTS / PACKAGES
addappid(703121, 1, "2979334110028da491dfb162079f1822d672e93ea680fa48aa166a23b4a63402")
