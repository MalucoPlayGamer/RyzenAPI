-- Lua provided by RyzenAPI
-- Game: Bitslap

-- MAIN APPLICATION
addappid(524690)

-- MAIN APP DEPOTS / PACKAGES
addappid(524691,0,"977ee946d364158932c4b169d3e73a380a19d12c3ebb91e4fed07e77b3eae4b0")

