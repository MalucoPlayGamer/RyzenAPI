-- Lua provided by RyzenAPI
-- Game: AppID 1020270

-- MAIN APPLICATION
addappid(1020270)
-- Game: addappid(1020270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020271, 1, "d8a81a295e69f228fd9529e0cd2e1270b058fb270f6482893ec4ce9239dfca78")
