-- Lua provided by RyzenAPI
-- Game: No zombie land: Lucy

-- MAIN APPLICATION
addappid(2414920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414921, 1, "d262f02550f804326a4c8019bf322eed081482b5c1157fe7df86911bf789a389")
