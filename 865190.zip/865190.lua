-- Lua provided by RyzenAPI
-- Game: HotFloor

-- MAIN APPLICATION
addappid(865190)

-- MAIN APP DEPOTS / PACKAGES
addappid(865191, 1, "1cf261f4c39cf7aab3ceec368a4caac9a2ab77b182c4627576d656dd6001e359")
