-- Lua provided by RyzenAPI
-- Game: Wretch: Divine Ascent

-- MAIN APPLICATION
addappid(3081280)
addappid(4133880)
addappid(4252530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3081280,0,"4931f4a6ca600e3085a9a04f13e8b35e6acffc96a2531c090faef85fab6492cf")
addappid(3081281,0,"8984314bb3ba33536229bc9accc4c59e8c4d42956e92946fb0b5d6dff14d6af8")
addappid(4133890,0,"7f51f92bf79809c0b765f5459008d2a853739a376fc82c60853dafcd0b2b65b5")

