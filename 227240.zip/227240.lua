-- Lua provided by RyzenAPI 
-- Game: AppID 227240
addappid(227240)
addappid(227241, 1, "7078df084395ffa9a85452525821fce5f4c09938015fb3d3212e92126309366a")
