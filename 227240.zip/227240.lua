-- Lua provided by RyzenAPI
-- Game: Construct 2 Free

-- MAIN APPLICATION
addappid(227240)

-- MAIN APP DEPOTS / PACKAGES
addappid(227241, 1, "7078df084395ffa9a85452525821fce5f4c09938015fb3d3212e92126309366a")

