-- Lua provided by RyzenAPI
-- Game: Gun-Running War Dogs

-- MAIN APPLICATION
addappid(678820)

-- MAIN APP DEPOTS / PACKAGES
addappid(678821, 1, "2acc03dd39d3e2e393163c81ed5fec578ff3ed05fe57883a94f8e23f4b2951ca")
