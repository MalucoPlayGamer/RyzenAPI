-- Lua provided by RyzenAPI
-- Game: 过关攒将

-- MAIN APPLICATION
addappid(985680)

-- MAIN APP DEPOTS / PACKAGES
addappid(985681, 1, "3872fdcf2592864bb691d4e47bbf03dd178b4472de6a0d3961f2c5ec4e154961")
