-- Lua provided by RyzenAPI
-- Game: Guess Pictures - Animals

-- MAIN APPLICATION
addappid(1371210)
addappid(1372540)
addappid(1376000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371211, 1, "fed9df386dc3a2d43324d1668116149148b1f976ada451adc11deb299bf8fee0")

