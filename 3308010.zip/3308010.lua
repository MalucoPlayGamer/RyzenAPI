-- Lua provided by RyzenAPI
-- Game: Wheelie City

-- MAIN APPLICATION
addappid(3308010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308011, 1, "eb471e38895698be12671c2906b2a98e0d20c813661ed229d09220d14ac1eb07")

