-- Lua provided by RyzenAPI
-- Game: Birthright Cataclysm - Overture

-- MAIN APPLICATION
addappid(528940)

-- MAIN APP DEPOTS / PACKAGES
addappid(528941, 1, "566bf078cee199b33cf1e79699cefc72693ffc4c63208fc5c8099c93ec3fc005")

