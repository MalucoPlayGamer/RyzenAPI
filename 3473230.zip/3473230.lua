-- Lua provided by RyzenAPI
-- Game: addappid(3473230)

-- MAIN APPLICATION
addappid(3473230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473231, 1, "20c8ed68a01c0bba8685f469a017bd71c230152d9ab76f24a45cbb91c3754756")
