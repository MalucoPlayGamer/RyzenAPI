-- Lua provided by RyzenAPI
-- Game: Game: AppID 1101140

-- MAIN APPLICATION
addappid(1101140)
-- Game: addappid(1101140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101141, 1, "5ded1495e1b68f80788ef7c4b567d4150b0643f6356854658ee794aea70be778")
