-- Lua provided by RyzenAPI
-- Game: Fishing Adventure

-- MAIN APPLICATION
addappid(1101140)
addappid(2270730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101141, 1, "5ded1495e1b68f80788ef7c4b567d4150b0643f6356854658ee794aea70be778")
