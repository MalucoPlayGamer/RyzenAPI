-- Lua provided by RyzenAPI
-- Game: Sapo 3D

-- MAIN APPLICATION
addappid(2963280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963281, 1, "4bb782087cc67f9e01fb14e572c49a2f257ec7678745648d386d83ec876cab0d")

