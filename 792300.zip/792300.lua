-- Lua provided by SkyAPI 
-- Game: The Beast Inside
addappid(792300)
addappid(792301, 1, "44c48d3c07f69d006381c872c6f4dbdeef588528bf50e68e493a9dd546c5754a")
