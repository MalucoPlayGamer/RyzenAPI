-- Lua provided by RyzenAPI
-- Game: The Beast Inside

-- MAIN APPLICATION
addappid(792300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(792301, 1, "44c48d3c07f69d006381c872c6f4dbdeef588528bf50e68e493a9dd546c5754a")

