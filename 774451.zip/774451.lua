-- Lua provided by RyzenAPI
-- Game: Game: Among the Dead

-- MAIN APPLICATION
addappid(774451)
-- Game: addappid(774451)

-- MAIN APP DEPOTS / PACKAGES
addappid(774452, 1, "6bed065d754477ba4b72750bca0ce1118be1030e0812fca10dbb382a3df3be1b")
addappid(873920, 0, "035cafc1c92b3cce0ccb7f45f0605d9b1a312f922367fa8c8dd0596e79e2440d")
