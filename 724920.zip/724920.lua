-- Lua provided by RyzenAPI
-- Game: AppID 724920

-- MAIN APPLICATION
addappid(724920)

-- MAIN APP DEPOTS / PACKAGES
addappid(724921, 1, "8bc424cffcabaf05629fd21d1ec0b1544192271006c795e3ab47931f476d2fef")

