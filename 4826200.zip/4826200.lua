-- Lua provided by RyzenAPI
-- Game: Nicotine Merchant Simulator™

-- MAIN APPLICATION
addappid(4826200) -- Nicotine Merchant Simulator™

-- MAIN APP DEPOTS / PACKAGES
addappid(4826201, 1, "fa5c4593473292c34cbccb8e31551e7e9eadac7d819745c1632633dfd3d3638d") -- Depot 4826201



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
