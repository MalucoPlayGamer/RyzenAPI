-- 4826200's Lua and Manifest Created by Hubcap Manifest
-- Nicotine Merchant Simulator™
-- Created: August 15, 2026 at 03:16:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4826200) -- Nicotine Merchant Simulator™
-- MAIN APP DEPOTS
addappid(4826201, 1, "fa5c4593473292c34cbccb8e31551e7e9eadac7d819745c1632633dfd3d3638d") -- Depot 4826201
setManifestid(4826201, "5077710737696077683", 1928965432)