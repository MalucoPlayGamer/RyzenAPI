-- Lua provided by RyzenAPI
-- Game: Nicotine Merchant Simulator™

-- MAIN APPLICATION
addappid(4826200) -- Nicotine Merchant Simulator™

-- MAIN APP DEPOTS / PACKAGES
addappid(4826201, 1, "fa5c4593473292c34cbccb8e31551e7e9eadac7d819745c1632633dfd3d3638d") -- Depot 4826201

