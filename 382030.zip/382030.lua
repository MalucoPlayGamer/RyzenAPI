-- Lua provided by RyzenAPI
-- Game: Yargis - Space Melee - Dedicated Server

-- MAIN APPLICATION
addappid(382030)

-- MAIN APP DEPOTS / PACKAGES
addappid(382031, 1, "d95f6da5ba307f15d4e0f8fcc0fd29ced77f3060544790469acaeee73fcdbfe0")
