-- Lua provided by RyzenAPI
-- Game: AppID 2142150

-- MAIN APPLICATION
addappid(2142150)
-- Game: addappid(2142150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142151, 1, "5e503f1c87872a5f498c44fda7b9e7c866569c7f1376a7e8f86af548503e2e4b")
