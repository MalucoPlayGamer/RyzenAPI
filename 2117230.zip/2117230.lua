-- Lua provided by RyzenAPI 
-- Game: Night of the Wererat
addappid(2117230)
addappid(2117231, 1, "cb622f213a979425147b72d203b6982631a5463d61ad3117a87d9f2f41c75b56")
