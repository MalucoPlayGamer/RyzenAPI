-- Lua provided by RyzenAPI 
-- Game: AppID 2358940
addappid(2358940)
addappid(2358941, 1, "d79356b7cff217f2ca29292ef7eb4fc5d1103950a77e7d3a4cb20f616823d65a")
addappid(2358942, 1, "031b53ad9540fd5130350ef180ac675a74836a380e7d1a9d462e8f33399f16ac")
