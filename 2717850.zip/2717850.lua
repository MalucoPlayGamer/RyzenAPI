-- Lua provided by RyzenAPI
-- Game: Forklift Simulator

-- MAIN APPLICATION
addappid(2717850)
-- Game: addappid(2717850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717851, 1, "e448a7f4c9d34173de0e8597716b9c40cb77b77784a2158ac131eadcf670b600")
