-- Lua provided by RyzenAPI
-- Game: AppID 1501570

-- MAIN APPLICATION
addappid(1501570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501571, 1, "efb8b16846f5bcdab5938956444be8abb53603de2d622d0263627a5bc3dcbbbe")
