-- Lua provided by RyzenAPI
-- Game: Park Studio

-- MAIN APPLICATION
addappid(2832220)
-- Game: addappid(2832220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832221, 1, "3b35bb36e3962e53cbab6baa9f411f41e4fe2f18cea2f9a2e6d7b2e1281a58f3")
