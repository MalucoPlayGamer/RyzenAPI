-- Lua provided by RyzenAPI
-- Game: Dominated by: Yandere Goth Girlfriend 4

-- MAIN APPLICATION
addappid(3843350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3843351, 1, "027820d6e2f62e7761d1ccc3b5daf501887a82dc732d551ff97044a3fd443568")

