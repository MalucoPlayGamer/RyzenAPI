-- Lua provided by RyzenAPI
-- Game: Succubus Dating

-- MAIN APPLICATION
addappid(2008010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008011, 1, "80e9a6aa96d3bb7a1249c1a4ae2e1174ca11ea19133f8f4407f4399ed72d11c0")
