-- Lua provided by RyzenAPI
-- Game: Coloring Game: Girls 3

-- MAIN APPLICATION
addappid(3525390)
addappid(4840360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3525391,0,"4334b43cc94f866a8fac4c0e23efe93e007097a02386d5cb2b888f54c5b54e17")
addappid(3525393,0,"9e176ae49a69011cde86a0639f3e523e07f28213c0f1e1bf4f28f158ec00cfdf")

