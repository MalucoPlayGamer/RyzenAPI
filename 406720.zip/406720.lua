-- Lua provided by RyzenAPI 
-- Game: AppID 406720
addappid(406720)
addappid(406721, 1, "233ea7b99e095c7c0e9f005494f6d97caf4afba936730c618790b63badf87a75")
