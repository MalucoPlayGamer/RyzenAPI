-- Lua provided by RyzenAPI
-- Game: AppID 406720

-- MAIN APPLICATION
addappid(406720)

-- MAIN APP DEPOTS / PACKAGES
addappid(406721, 1, "233ea7b99e095c7c0e9f005494f6d97caf4afba936730c618790b63badf87a75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
