-- Lua provided by RyzenAPI
-- Game: Supermarket Together

-- MAIN APPLICATION
addappid(2709570)
addappid(3146530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2709571, 1, "7fa16318d187d201cd5762fec6ac1022fb99b54b7ecb11f228286d5ee2a9790e")

