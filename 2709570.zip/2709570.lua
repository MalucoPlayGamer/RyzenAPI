-- Lua provided by RyzenAPI
-- Game: Game: Supermarket Together

-- MAIN APPLICATION
addappid(2709570)
addappid(3146530)
-- Game: addappid(2709570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709571, 1, "7fa16318d187d201cd5762fec6ac1022fb99b54b7ecb11f228286d5ee2a9790e")
