-- Lua provided by RyzenAPI
-- Game: The Secret Order 2: Masked Intent

-- MAIN APPLICATION
addappid(399890)

-- MAIN APP DEPOTS / PACKAGES
addappid(399891, 1, "56fc9b9498076d6499efd583b46239e468e3e9193409a58eb250f32e5e165d0e")
addappid(399892, 1, "879155a62e3f51f9d1e024122ef33e1056c143be073e8e5378cba0cb497f7acc")
addappid(399893, 1, "ce7cb20eb91252808c53accf63b73e5af9acd7e66554fca11d2b1a7e682aa985")
