-- Lua provided by RyzenAPI
-- Game: Revenge on the Streets

-- MAIN APPLICATION
addappid(1095320)
-- Game: addappid(1095320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095321, 1, "b857a7b447199962b03852867e53738db9b05ff3502a928bdf66d2c26d9b4897")
