-- Lua provided by RyzenAPI
-- Game: Supermoves - Original Soundtrack

-- MAIN APPLICATION
addappid(2648140)
-- Game: addappid(2648140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648141, 1, "1b769806abfc3859c39d4eaa3239080175f44fac1ac718b01379580875c7b0c8")
addappid(2648148, 1, "8c522c667b36b6ffb8d3156078f0b86dd64fc0ca0c414c5e286bf4b962d4dc15")
