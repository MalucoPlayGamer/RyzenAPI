-- Lua provided by RyzenAPI 
-- Game: AppID 2266660
addappid(2266660)
addappid(2266661, 1, "72269e1fc6d8f6b04a3ac4fee8017aaa400b20680b2f7ad2c63509e49d9f5ca0")
