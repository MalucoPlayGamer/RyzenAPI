-- Lua provided by RyzenAPI
-- Game: Mouse Curser Demo

-- MAIN APPLICATION
addappid(2811310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811311, 1, "ec37ba1cbe78c92076531e3b5fe5b807fc57c2b82bce276683e6dc73f6ca4ce1")
