-- Lua provided by RyzenAPI
-- Game: addappid(1560500)

-- MAIN APPLICATION
addappid(1560500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560501, 1, "8520d9c17dcc12f1f1510be5c2ba077be7f961953767c49ca69ffdd580cee69d")
