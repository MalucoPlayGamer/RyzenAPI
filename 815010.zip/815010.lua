-- Lua provided by RyzenAPI
-- Game: 815010

-- MAIN APPLICATION
addappid(815010)

-- MAIN APP DEPOTS / PACKAGES
addappid(815012,0,"e6d6f3f18fca26bc9b02bdcc734df1930df99243a623d3c941aaee9beb97d8b3")

