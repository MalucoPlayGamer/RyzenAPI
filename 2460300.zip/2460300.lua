-- Lua provided by RyzenAPI
-- Game: 2460300

-- MAIN APPLICATION
addappid(2460300)
-- Game: addappid(2460300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460301, 1, "8132a21000d9a4493f03e2afee2e2f4f2d3d004bf28c19ee8d608521dda414a8")
