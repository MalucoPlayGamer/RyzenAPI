-- Lua provided by RyzenAPI
-- Game: Game: OceanScramble:AgeOfExploration[Demo]

-- MAIN APPLICATION
addappid(2547770)
-- Game: addappid(2547770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547771, 1, "3668aecc610bdb4d15b8e1168dccb9dd92ba12a64bb4ad886cf5a15e5a71fdea")
