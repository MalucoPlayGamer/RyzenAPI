-- Lua provided by RyzenAPI
-- Game: 1766660

-- MAIN APPLICATION
addappid(1766660)
-- Game: addappid(1766660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766661, 1, "2adb0d6895f63e5838eaa2e44b092ea380594d6f6ca8c9a49f7eb0acf9b06e6b")
