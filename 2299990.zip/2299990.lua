-- Lua provided by RyzenAPI
-- Game: Into the Wonderland

-- MAIN APPLICATION
addappid(2299990)
-- Game: addappid(2299990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299991, 1, "612dc979810aa889f66393d95db34276d44d092f3f48dac28a1139a4cdd51aff")
