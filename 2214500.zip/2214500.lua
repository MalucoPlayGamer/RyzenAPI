-- Lua provided by RyzenAPI
-- Game: X Invader: Prologue

-- MAIN APPLICATION
addappid(2214500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214501, 1, "6e7a4f69b9594dd65916a346781b28918cab29a1fbbb4e6a6ea8ef1cc0479ba4")

