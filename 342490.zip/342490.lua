-- Lua provided by SkyAPI 
-- Game: AppID 342490
addappid(342490)
addappid(342491, 1, "956c1dabf953ab046227f9c88f1176a9e37c5b15e5a598bc7254da41bc2f0349")
addappid(342493, 1, "c18e48c011b6269d325ab4262d40c738f38df3814c7ce31f96bb1fe851200deb")
