-- Lua provided by RyzenAPI
-- Game: AppID 342490

-- MAIN APPLICATION
addappid(342490)

-- MAIN APP DEPOTS / PACKAGES
addappid(342491, 1, "956c1dabf953ab046227f9c88f1176a9e37c5b15e5a598bc7254da41bc2f0349")
addappid(342493, 1, "c18e48c011b6269d325ab4262d40c738f38df3814c7ce31f96bb1fe851200deb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
