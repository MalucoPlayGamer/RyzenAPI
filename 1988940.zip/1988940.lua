-- Lua provided by RyzenAPI
-- Game: 1988940

-- MAIN APPLICATION
addappid(1988940)
addappid(2009480)
-- Game: addappid(1988940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988941, 1, "d51387a620c3c5dfc9d3a0a4ed7b1d37a9ee632bb3e55728d74377b70e25914c")
