-- Lua provided by SkyAPI 
-- Game: からぱりうぉーず
addappid(1988940)
addappid(1988941, 1, "d51387a620c3c5dfc9d3a0a4ed7b1d37a9ee632bb3e55728d74377b70e25914c")
addappid(2009480)
