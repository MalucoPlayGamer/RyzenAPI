-- Lua provided by RyzenAPI
-- Game: 陨铁山 Falling Mountains

-- MAIN APPLICATION
addappid(2720540)
-- Game: addappid(2720540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720541, 1, "93626e6bfb54dedb24702f3f275e049132de33e8277fe10bd7dd03a64b0ae443")
