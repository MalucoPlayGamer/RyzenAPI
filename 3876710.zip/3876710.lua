-- 3876710's Lua and Manifest Created by Hubcap Manifest
-- Pigeon: A Love Story
-- Created: August 06, 2026 at 14:59:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3876710) -- Pigeon: A Love Story
-- MAIN APP DEPOTS
addappid(3876712, 1, "03e1ae45f2940a6e9d4a751efba03b4e1b02f37fa6ab1eed1965afd8acd3a7c4") -- Depot 3876712
setManifestid(3876712, "3367295194575211964", 1468571402)
addappid(3876713, 1, "57d7ddfcd29a17f2d7c81cc5c284eaa6a39194a1a6a091366b19bfd13a38b642") -- Depot 3876713
setManifestid(3876713, "7749441659529787216", 1605766001)
addappid(3876714, 1, "f34cbe0311c35e7a22f9007f6ab293b7190100aef4d189e41860b85b84ce5d24") -- Depot 3876714
setManifestid(3876714, "3025357844192262014", 1425147950)