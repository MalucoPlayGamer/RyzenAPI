-- Lua provided by RyzenAPI
-- Game: Pigeon: A Love Story

-- MAIN APPLICATION
addappid(3876710) -- Pigeon: A Love Story

-- MAIN APP DEPOTS / PACKAGES
addappid(3876712, 1, "03e1ae45f2940a6e9d4a751efba03b4e1b02f37fa6ab1eed1965afd8acd3a7c4") -- Depot 3876712
addappid(3876713, 1, "57d7ddfcd29a17f2d7c81cc5c284eaa6a39194a1a6a091366b19bfd13a38b642") -- Depot 3876713
addappid(3876714, 1, "f34cbe0311c35e7a22f9007f6ab293b7190100aef4d189e41860b85b84ce5d24") -- Depot 3876714

