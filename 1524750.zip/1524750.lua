-- Lua provided by RyzenAPI
-- Game: Game: AppID 1524750

-- MAIN APPLICATION
addappid(1524750)
-- Game: addappid(1524750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524751, 1, "8031d0d78d36200033b61a92439dcc977dd35f0fe4be2cd0add986181ff2da9a")
