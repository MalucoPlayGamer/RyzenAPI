-- Lua provided by RyzenAPI
-- Game: Peepo Island

-- MAIN APPLICATION
addappid(2069990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069991, 1, "3c86ca30b1b8e783be7325312ffcb88231263669e4e510dd42ac93eb9d424f40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
