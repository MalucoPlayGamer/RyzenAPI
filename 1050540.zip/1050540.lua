-- Lua provided by RyzenAPI
-- Game: AppID 1050540

-- MAIN APPLICATION
addappid(1050540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1050541, 1, "48dded694ca6240ba215f7bda83163514abd08782eabfc9bbfe05d1f1524e85e")

