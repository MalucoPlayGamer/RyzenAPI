-- Lua provided by RyzenAPI
-- Game: AppID 1050540

-- MAIN APPLICATION
addappid(1050540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050541, 1, "48dded694ca6240ba215f7bda83163514abd08782eabfc9bbfe05d1f1524e85e")

