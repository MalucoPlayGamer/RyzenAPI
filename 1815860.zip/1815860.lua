-- Lua provided by SkyAPI 
-- Game: Maze Art: Black
addappid(1815860)
addappid(1815861, 1, "711e309f6989b68083358c05dacdd8f88c82b92b4b551478817aa4855f264b1c")
