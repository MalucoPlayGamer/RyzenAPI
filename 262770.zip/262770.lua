-- Lua provided by RyzenAPI 
-- Game: Freedom Fall
addappid(262770)
addappid(262771, 1, "e76d9b6620cafb8b211080025d965feee0178dc991f3a1d5bd3c1daf1e761cac")
addappid(262772, 1, "24ef6ed2a034a5d1c52f798e9131e376cd47da7a33ef9ad7fc6bc799ae45f0ce")
