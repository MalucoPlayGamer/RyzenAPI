-- Lua provided by RyzenAPI
-- Game: addappid(753230)

-- MAIN APPLICATION
addappid(753230)

-- MAIN APP DEPOTS / PACKAGES
addappid(753231, 1, "7efc93aa24caed1dbe2e89625f929afcf23351050f84c93a274a0f9a5d1e78f7")
