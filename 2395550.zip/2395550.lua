-- Lua provided by RyzenAPI
-- Game: Game: Desktop Girlfriend NEO

-- MAIN APPLICATION
addappid(2395550)
-- Game: addappid(2395550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395551, 1, "97f4a2aa4764ab390c7fa1815d2166564e5a19bfa0259778e63015e7d95aebaa")
addappid(2512740, 0, "9c9a1fa4ae0c0807b3645748334804c36cc1059a6c6e43a0ec468ae29ed850f2")
