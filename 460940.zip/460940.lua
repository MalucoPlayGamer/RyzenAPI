-- Lua provided by RyzenAPI
-- Game: AppID 460940

-- MAIN APPLICATION
addappid(460940)

-- MAIN APP DEPOTS / PACKAGES
addappid(460941, 1, "083bfaee0e3cf74ebb47da94615d67cb7a428f8e197ee39fe789fa0ea0c73ba7")

