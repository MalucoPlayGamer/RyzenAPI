-- Lua provided by SkyAPI 
-- Game: Little Kite
addappid(610120)
addappid(610121, 1, "a999292d02e06733593151a4eb30f31623621786c43e99f78bd912fe583e9b3c")
addappid(610122, 1, "fd27d738a913febba1bd9ea9b0002722f44872f6747e6def33dc5bb995e472a4")
addappid(610123, 1, "2383d31c5fb5c41f9f1bb31c1b3e9c225862f3a90cac1b57769c88a06ff0403d")
addappid(716510)
