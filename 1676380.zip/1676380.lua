-- Lua provided by SkyAPI 
-- Game: Kingdom of Atham: Crown of the Champions
addappid(1676380)
addappid(1676381, 1, "eadaad6913563001676f31cadc528c1db1567ccf3d7f9f3c4484474885a23bf4")
