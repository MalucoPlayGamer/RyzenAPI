-- Lua provided by RyzenAPI 
-- Game: NTR'd By Clumsiness
addappid(2277300)
addappid(2277301, 1, "3c75a599c0b088d954bf25a00ad1c02918f2073d0ecb4e62d96c13ae27b0b191")
