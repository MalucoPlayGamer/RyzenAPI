-- Lua provided by RyzenAPI
-- Game: setManifestid(1833880,"726342935210612907")

-- MAIN APPLICATION
addappid(1361230)
-- Game: addappid(1361230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833880,0,"d0ce12e5641a77e5acc19116cab8e8b617394d0d8936075dfcb229e684bfea45")
