-- Lua provided by RyzenAPI
-- Game: Game: Eiyuden Chronicle: Hundred Heroes - Allraan Artistry Pack

-- MAIN APPLICATION
addappid(2843320)
-- Game: addappid(2843320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843321, 1, "ec7326b14a67a35d5ee44ef9dae9ee6d3b7f84729bf34e3e25f58d01a36e4eb4")
