-- Lua provided by RyzenAPI 
-- Game: Slime Princess
addappid(2981850)
addappid(2981851, 1, "f46f4ecae49b82d78cf5f2eee41be5f96481696b9182af176bdef31d8e971666")
