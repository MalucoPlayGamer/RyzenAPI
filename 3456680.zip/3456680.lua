-- Lua provided by SkyAPI 
-- Game: AppID 3456680
addappid(3456680)
addappid(3456681, 1, "297e84e28ba236d71f46c096175ec92f3e8cb1b395b15e87d4238a707b7495ae")
