-- Lua provided by RyzenAPI
-- Game: Game: AppID 3456680

-- MAIN APPLICATION
addappid(3456680)
-- Game: addappid(3456680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456681, 1, "297e84e28ba236d71f46c096175ec92f3e8cb1b395b15e87d4238a707b7495ae")
