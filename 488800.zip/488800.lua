-- Lua provided by SkyAPI 
-- Game: KARAKARA Demo
addappid(488800)
addappid(488801, 1, "6e4c2dce7f40b99e04b9200c2e2cb2fc9fd6dd1f5a5d9ee73afbb8fab1036655")
