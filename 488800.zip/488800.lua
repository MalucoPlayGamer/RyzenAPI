-- Lua provided by RyzenAPI
-- Game: addappid(488800)

-- MAIN APPLICATION
addappid(488800)

-- MAIN APP DEPOTS / PACKAGES
addappid(488801, 1, "6e4c2dce7f40b99e04b9200c2e2cb2fc9fd6dd1f5a5d9ee73afbb8fab1036655")
