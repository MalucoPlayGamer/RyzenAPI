-- Lua provided by RyzenAPI
-- Game: 3730600

-- MAIN APPLICATION
addappid(3730600)
-- Game: addappid(3730600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3730601, 1, "9fc11319273efe1e98c1869c31af6be482afa29e32b3d1a81c5ecd1500301d79")
