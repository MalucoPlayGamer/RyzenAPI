-- Lua provided by RyzenAPI
-- Game: Nextbots In The Backrooms

-- MAIN APPLICATION
addappid(2429490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429491, 1, "cd58585e91b470c3a9a5835d66751c0bf128e9179abe325509a98c61d5fc5e1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
