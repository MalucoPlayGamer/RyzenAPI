-- Lua provided by RyzenAPI
-- Game: Nextbots In The Backrooms

-- MAIN APPLICATION
addappid(2429490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429491, 1, "cd58585e91b470c3a9a5835d66751c0bf128e9179abe325509a98c61d5fc5e1c")

