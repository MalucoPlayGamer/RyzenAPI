-- Lua provided by RyzenAPI
-- Game: addappid(591740)

-- MAIN APPLICATION
addappid(591740)

-- MAIN APP DEPOTS / PACKAGES
addappid(591741, 1, "2979fc7611c332687edc284fc9fbf0a979687fbacfe8f3e4e1e1032bb3e9cb02")
addappid(2288540, 0, "bc58a81bc0c4708a73aaa9ad2587df02690f4fcc28f0722e2b48ac0ade699c8c")
