-- Lua provided by RyzenAPI
-- Game: Sniper Fury

-- MAIN APPLICATION
addappid(591740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(591741, 1, "2979fc7611c332687edc284fc9fbf0a979687fbacfe8f3e4e1e1032bb3e9cb02")
addappid(2288540, 0, "bc58a81bc0c4708a73aaa9ad2587df02690f4fcc28f0722e2b48ac0ade699c8c")
