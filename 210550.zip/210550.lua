-- Lua provided by SkyAPI 
-- Game: Angry Birds Space
addappid(210550)
addappid(210551, 1, "7bf50929c3097fb087324de3c9d71f14e4b7d84acd0b711be35d0732e925a781")
