-- Lua provided by RyzenAPI
-- Game: Game: Angry Birds Space

-- MAIN APPLICATION
addappid(210550)
-- Game: addappid(210550)

-- MAIN APP DEPOTS / PACKAGES
addappid(210551, 1, "7bf50929c3097fb087324de3c9d71f14e4b7d84acd0b711be35d0732e925a781")
