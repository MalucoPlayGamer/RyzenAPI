-- Lua provided by RyzenAPI
-- Game: Cinemaster Cinema Simulator

-- MAIN APPLICATION
addappid(3327470)
-- Game: addappid(3327470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327471, 1, "d6a10655c51ee01f38b8468626028b48eb2ac2357161e05872ecfa23bd4a8b26")
