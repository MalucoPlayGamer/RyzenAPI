-- Lua provided by SkyAPI 
-- Game: Cinemaster Cinema Simulator
addappid(3327470)
addappid(3327471, 1, "d6a10655c51ee01f38b8468626028b48eb2ac2357161e05872ecfa23bd4a8b26")
