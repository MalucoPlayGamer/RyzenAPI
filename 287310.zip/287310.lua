-- Lua provided by SkyAPI 
-- Game: AppID 287310
addappid(287310)
addappid(287311, 1, "982ed8d8dc570751124b3255d525f6a5fdc0a17df46013e6ec2c9a860ca23c83")
