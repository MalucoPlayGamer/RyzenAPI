-- Lua provided by RyzenAPI
-- Game: Re-Volt

-- MAIN APPLICATION
addappid(287310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(287311, 1, "982ed8d8dc570751124b3255d525f6a5fdc0a17df46013e6ec2c9a860ca23c83")

