-- Lua provided by RyzenAPI
-- Game: Game: University Days - Season 1

-- MAIN APPLICATION
addappid(2564970)
-- Game: addappid(2564970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564971, 1, "e025f6fd75d33e93b526c7ab21f7333d2f3c9e867efadabe28c5232f6c19503d")
