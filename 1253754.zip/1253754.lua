-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2020 Effects - Technology Set

-- MAIN APPLICATION
addappid(1253754)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253754,0,"42bc22a7731982c3f53495f4c9ed26bc2df5f5ad136016f4b2f8987483d78091")

