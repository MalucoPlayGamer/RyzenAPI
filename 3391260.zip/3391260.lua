-- Lua provided by RyzenAPI
-- Game: WHO'S WHO 2.0

-- MAIN APPLICATION
addappid(3391260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391261, 1, "dc9d218deb7f5e9409f7697433b9e93bfefb2a02715733713b30a4fb3bdffa53")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3572910)
addappid(3572920)
addappid(3710380)
addappid(3774240)
addappid(3774540)
addappid(3776690)
addappid(3798280)
addappid(3896690)
addappid(4474660)
addappid(4475450)
