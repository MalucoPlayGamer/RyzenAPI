-- Lua provided by RyzenAPI
-- Game: Game: WHO'S WHO 2.0

-- MAIN APPLICATION
addappid(3391260)
-- Game: addappid(3391260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391261, 1, "dc9d218deb7f5e9409f7697433b9e93bfefb2a02715733713b30a4fb3bdffa53")
