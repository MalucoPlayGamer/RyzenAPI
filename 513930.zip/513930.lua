-- Lua provided by RyzenAPI
-- Game: J.U.R : Japan Underground Racing

-- MAIN APPLICATION
addappid(513930)

-- MAIN APP DEPOTS / PACKAGES
addappid(513931, 1, "e788d50a6738d4fabdff62a619305342136f413c4d6b8b30a644b51783500374")
