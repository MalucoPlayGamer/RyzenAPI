-- Lua provided by RyzenAPI
-- Game: Game: AppID 2857890

-- MAIN APPLICATION
addappid(2857890)
-- Game: addappid(2857890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857891, 1, "b0511dc059b616361b7befa54327b3997e25b0e1e3258646639ca6756d9da4e9")
