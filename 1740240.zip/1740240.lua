-- Lua provided by SkyAPI 
-- Game: 100 hidden cups
addappid(1740240)
addappid(1740241, 1, "7431b479e5c3dc45030bb22f19af2bd0edbc9bd988308b627647cc4090c31e07")
