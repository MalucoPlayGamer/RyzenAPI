-- Lua provided by RyzenAPI
-- Game: 100 hidden cups

-- MAIN APPLICATION
addappid(1740240)
-- Game: addappid(1740240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740241, 1, "7431b479e5c3dc45030bb22f19af2bd0edbc9bd988308b627647cc4090c31e07")
