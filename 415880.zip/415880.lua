-- Lua provided by RyzenAPI
-- Game: addappid(415880)

-- MAIN APPLICATION
addappid(415880)

-- MAIN APP DEPOTS / PACKAGES
addappid(415881, 1, "bce4b6f8b1710cbe80ea91227170917f2e115bad66bcada6c681728f739feb72")
addappid(415882, 1, "2b24693f1aa00886a4f9e137e7c1768bfea9c584160ad606760d3795b26ac90f")
