-- Lua provided by RyzenAPI
-- Game: Greyhill Incident

-- MAIN APPLICATION
addappid(1905020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905021, 1, "7cb60fd791438b12c2ab746a6316489c0e32acb11106cd4e42a5076d49bf88ab")
addappid(2337590, 0, "ded22a4fa52ff0f992ae6b9aa6500b09ed441f493071d2ed79132e70bb8bd0b5")
addappid(2337591, 0, "fe9310cf9acef5f77d203753e16403e16bbe0edc2fe19896739df48ac241ab39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
