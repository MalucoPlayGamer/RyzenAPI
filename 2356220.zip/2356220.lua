-- Lua provided by RyzenAPI
-- Game: addappid(2356220)

-- MAIN APPLICATION
addappid(2356220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356221, 1, "b7ea672a9a6244fd590c41030623446caabe710e99521bab6c920f4b9af4de19")
