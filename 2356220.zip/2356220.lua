-- Lua provided by RyzenAPI
-- Game: The Adventures of LinShanHai - Chapter3:The Headless Woman

-- MAIN APPLICATION
addappid(2356220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356221, 1, "b7ea672a9a6244fd590c41030623446caabe710e99521bab6c920f4b9af4de19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
