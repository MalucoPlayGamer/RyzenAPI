-- Lua provided by RyzenAPI 
-- Game: The Adventures of LinShanHai - Chapter3:The Headless Woman
addappid(2356220)
addappid(2356221, 1, "b7ea672a9a6244fd590c41030623446caabe710e99521bab6c920f4b9af4de19")
