-- Lua provided by RyzenAPI
-- Game: Game: Machick

-- MAIN APPLICATION
addappid(2811200)
-- Game: addappid(2811200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811201, 1, "fa8263c9145b74d957a7e0616ba181fd443239009886afa11ceb8572560f7c43")
