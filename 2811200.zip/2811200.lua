-- Lua provided by RyzenAPI
-- Game: Machick

-- MAIN APPLICATION
addappid(2811200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2811201, 1, "fa8263c9145b74d957a7e0616ba181fd443239009886afa11ceb8572560f7c43")

