-- Lua provided by RyzenAPI 
-- Game: AppID 578930
addappid(578930)
addappid(578931, 1, "fbb242be66a064a20d09ebe69c463e3387a7efdaa52ebf88a870c21deb3f41d2")
addappid(748790, 0, "5cc4d14cf36f7b723924661f2b0e26faa9a737eb77dc996cca0e725f426d585d")
