-- Lua provided by RyzenAPI 
-- Game: XWidget
addappid(967130)
addappid(967131, 1, "dd74252ec64d849d203e681a8dd30f389bac52aa00342b799aafba386aed9c3f")
