-- Lua provided by RyzenAPI
-- Game: Game: AppID 1023510

-- MAIN APPLICATION
addappid(1023510)
-- Game: addappid(1023510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023511, 1, "426f070e8a1417dd2f266ba16ea9b64fba7de899747a9bc82b163203d97f4bf9")
