-- Lua provided by RyzenAPI
-- Game: AppID 1023510

-- MAIN APPLICATION
addappid(1023510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023511, 1, "426f070e8a1417dd2f266ba16ea9b64fba7de899747a9bc82b163203d97f4bf9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
