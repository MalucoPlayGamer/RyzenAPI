-- Lua provided by RyzenAPI
-- Game: Mass Effect™: Andromeda Deluxe Edition

-- MAIN APPLICATION
addappid(1238000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238001, 1, "db088a6ddb48c243fa2621cb46380a0bd0fcc691418b35c869b90fc2110b1eb8")
addappid(1238002, 1, "3b487a6917d7bd1c20c9de21d36cefd5d0f53b5fd9d7683669ac962f30aaff6e")
addappid(1238003, 1, "1bbfa9c1e83514aced1b25b9a4f8e27c62843a527b4d056e17607474d885bd51")
addappid(1238004, 1, "196e71a786ce0c722e70511d05b0eb8ae9cf5edc4cf6a5e87c36db3262a172c4")
addappid(1238005, 1, "83a5b1f942ce6e36d2572e21303e92c483e3ce468c95be25b80051ffa6944ab1")
addappid(1238006, 1, "f389bc2a72ea779c8ae7a33f784fde7a25a338ca4089193c5eca9d02f18b586e")
addappid(1238007, 1, "2b0d72e9141a1009f863f9bab057f89bb104bba4e079db2b1657d4b72973d96f")
addappid(1238008, 1, "151d7add2db9dae435868182f3d165fd3d936d83c62c3029d1c8a80e0595acea")
addappid(1238009, 1, "46bdf4027fbce17b6740c9736955b649d5156b31c8251da82ea6c977175fbf6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1238011)
addappid(1238012)
addappid(1238013)
addappid(1238014)
addappid(1290420)
addappid(1290422)
addappid(1290423)
addappid(1290424)
