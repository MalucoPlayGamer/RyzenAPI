-- Lua provided by RyzenAPI
-- Game: Hentai vs Virus: I Am Waifu

-- MAIN APPLICATION
addappid(1270930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270931, 1, "4772ade0e8956b51d033ad75bf7444c1e60e1fe6cdf6ba4d2e110a20bc82083e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
