-- Lua provided by RyzenAPI
-- Game: Hentai vs Virus: I Am Waifu

-- MAIN APPLICATION
addappid(1270930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270931, 1, "4772ade0e8956b51d033ad75bf7444c1e60e1fe6cdf6ba4d2e110a20bc82083e")
