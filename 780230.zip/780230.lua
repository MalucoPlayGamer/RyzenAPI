-- Lua provided by RyzenAPI
-- Game: AppID 780230

-- MAIN APPLICATION
addappid(780230)
-- Game: addappid(780230)

-- MAIN APP DEPOTS / PACKAGES
addappid(780231, 1, "ca56daa17916863e847d9b3c898c79f26296162053cf35ade016c744017ba798")
