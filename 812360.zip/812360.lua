-- Lua provided by RyzenAPI
-- Game: Monsters of Kanji

-- MAIN APPLICATION
addappid(812360)

-- MAIN APP DEPOTS / PACKAGES
addappid(812361,0,"3553e94415d56c26d1fc98722dcd7df5dbe6eac85d9cf5186f6fc3ce0d4cdf11")

