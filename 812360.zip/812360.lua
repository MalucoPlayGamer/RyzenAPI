-- Lua provided by RyzenAPI
-- Game: Monsters of Kanji

-- MAIN APPLICATION
addappid(812360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(812361,0,"3553e94415d56c26d1fc98722dcd7df5dbe6eac85d9cf5186f6fc3ce0d4cdf11")

