-- Lua provided by RyzenAPI
-- Game: The Planet of the Vicious Creatures

-- MAIN APPLICATION
addappid(530290)
addappid(532310)
-- Game: addappid(530290)

-- MAIN APP DEPOTS / PACKAGES
addappid(530291, 1, "63170bfd7e0e5b6e4e66fb39158348a77020b43c868560515752e2ce8508a720")
