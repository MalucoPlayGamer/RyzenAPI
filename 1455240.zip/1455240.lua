-- Lua provided by RyzenAPI
-- Game: 1455240

-- MAIN APPLICATION
addappid(1455240)
-- Game: addappid(1455240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455241, 1, "3b29c77709a34d35e729da782b0fc9f9350f3deb8e0a65b2b1a1814e4aedb088")
