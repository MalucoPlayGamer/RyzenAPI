-- Lua provided by RyzenAPI
-- Game: Game: AppID 530160

-- MAIN APPLICATION
addappid(530160)
-- Game: addappid(530160)

-- MAIN APP DEPOTS / PACKAGES
addappid(530161, 1, "c19bb2eb3316884f4a34954857c40282f1ecf6320e79d5a19f2a2c8aff306f19")
addappid(530162, 1, "40c71a7c21b1cd068cc47052a9414df878bbe1b0b73f57c423c79110d6b84c21")
