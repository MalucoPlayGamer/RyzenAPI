-- Lua provided by RyzenAPI
-- Game: Eve of Destruction - REDUX VIETNAM

-- MAIN APPLICATION
addappid(530160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(530161, 1, "c19bb2eb3316884f4a34954857c40282f1ecf6320e79d5a19f2a2c8aff306f19")
addappid(530162, 1, "40c71a7c21b1cd068cc47052a9414df878bbe1b0b73f57c423c79110d6b84c21")
