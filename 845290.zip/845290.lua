-- Lua provided by RyzenAPI
-- Game: Game: AppID 845290

-- MAIN APPLICATION
addappid(845290)
-- Game: addappid(845290)

-- MAIN APP DEPOTS / PACKAGES
addappid(845291, 1, "95c24eff2ba823efd62f0c0aeaf2182e0adf872c1aa6b4e3ab5044372cabdb2d")
