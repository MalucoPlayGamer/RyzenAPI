-- Lua provided by RyzenAPI
-- Game: 2225980

-- MAIN APPLICATION
addappid(2225980)
-- Game: addappid(2225980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225981, 1, "4a25370eec7852dce8b9499e39555ce282612c1010d9eb7ea42f92f9faaf9787")
