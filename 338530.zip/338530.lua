-- Lua provided by RyzenAPI
-- Game: addappid(338530)

-- MAIN APPLICATION
addappid(338530)

-- MAIN APP DEPOTS / PACKAGES
addappid(338531, 1, "9c40797b656f7cb7df8c6d1b9957d31118080e2e974288a97ab9b2fe8ff0e0d4")
