-- Lua provided by RyzenAPI
-- Game: addappid(1001620)

-- MAIN APPLICATION
addappid(1001620)
addappid(1001621)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001620,0,"649e8b51c09fab1a59fb32ccd558846a1377d5f566cb2995b3f98a14b889d091")
