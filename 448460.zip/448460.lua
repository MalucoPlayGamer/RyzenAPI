-- Lua provided by RyzenAPI
-- Game: AppID 448460

-- MAIN APPLICATION
addappid(448460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(448461, 1, "eb5b52f8e8c582ab2990e0c9673d5e96d14604b5fd6f088fa294b1b58d2639da")
addappid(448463, 1, "7a6b396963260b193cafe3e8edb44e48e16575da9d83cc24bdf2a8fc51455963")

