-- Lua provided by RyzenAPI
-- Game: 1860100

-- MAIN APPLICATION
addappid(1860100)
-- Game: addappid(1860100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860101, 1, "1c446fd89d9c0af593605e4dca5ecc77a918f97c4328678d07fe8603d1775106")
