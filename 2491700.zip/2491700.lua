-- Lua provided by RyzenAPI
-- Game: Puropu Defense Squad

-- MAIN APPLICATION
addappid(2491700)
addappid(3343540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(2491701, 1, "38d0d478fd0fae3bfc5ae6cb6a46a7bd2b7e3ad3dc942d27a78f36cf97cb5e55")
