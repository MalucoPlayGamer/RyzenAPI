-- Lua provided by RyzenAPI
-- Game: AppID 2491700

-- MAIN APPLICATION
addappid(2491700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491701, 1, "38d0d478fd0fae3bfc5ae6cb6a46a7bd2b7e3ad3dc942d27a78f36cf97cb5e55")

