-- Lua provided by RyzenAPI
-- Game: Lifecraft Playtest

-- MAIN APPLICATION
addappid(2584670)
-- Game: addappid(2584670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584671, 1, "bfd468d228b0abdefa535dba99230eda91e2221012d2a21903f8ca16cb74dcfb")
