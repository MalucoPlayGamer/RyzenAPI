-- Lua provided by RyzenAPI
-- Game: Wicce Soundtrack

-- MAIN APPLICATION
addappid(1607230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607231, 1, "4c0b884a66f63f2d5d9baa3faecde00522e7f9b07704f9a6acf4266f285c4d0f")

