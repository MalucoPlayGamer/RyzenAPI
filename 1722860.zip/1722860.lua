-- Lua provided by RyzenAPI
-- Game: Munchkin Digital

-- MAIN APPLICATION
addappid(1722860)
addappid(2392090)
addappid(2840360)
addappid(3008510)
addappid(4130930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722861, 1, "764f0b59ddcdcc6aced2c289b2c6e09ac70ed43d573e3a98dd1e25358f50f0e2")

