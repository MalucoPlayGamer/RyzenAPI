-- Lua provided by RyzenAPI
-- Game: Sex Summer Camp

-- MAIN APPLICATION
-- addappid(3266140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263950, 1, "1209bedaa474fec9a29fd42b44b70a8f00a7a589cbfff9276856302cf60e1897") -- Sex Summer Camp
addappid(3263951, 1, "1b9081e4af3252d9b6a755950df21231925ab9e10b60e1d91e8c227dade8bec9") -- Depot 3263951

