-- 3263950's Lua and Manifest Created by Hubcap Manifest
-- Sex Summer Camp
-- Created: August 12, 2026 at 00:03:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(3263950, 1, "1209bedaa474fec9a29fd42b44b70a8f00a7a589cbfff9276856302cf60e1897") -- Sex Summer Camp
-- MAIN APP DEPOTS
addappid(3263951, 1, "1b9081e4af3252d9b6a755950df21231925ab9e10b60e1d91e8c227dade8bec9") -- Depot 3263951
setManifestid(3263951, "6120512597141418329", 943735923)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Sex Summer camp - Halloween party (AppID: 3266140) - missing depot keys
-- addappid(3266140)