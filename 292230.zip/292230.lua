-- Lua provided by RyzenAPI
-- Game: 292230

-- MAIN APPLICATION
addappid(292230)
addappid(372710)
addappid(437560)
-- Game: addappid(292230)

-- MAIN APP DEPOTS / PACKAGES
addappid(292231, 1, "6ed8eafa0bc119fb0bc19cc4fcda59c1fc5b9d057d7d0a882d6baeaf985b785e")
