-- Lua provided by RyzenAPI
-- Game: Game Character Hub

-- MAIN APPLICATION
addappid(292230)
addappid(372710)
addappid(437560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(292231, 1, "6ed8eafa0bc119fb0bc19cc4fcda59c1fc5b9d057d7d0a882d6baeaf985b785e")

