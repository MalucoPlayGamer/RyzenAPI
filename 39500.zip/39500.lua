-- Lua provided by RyzenAPI
-- Game: Gothic® 3

-- MAIN APPLICATION
addappid(39500)
-- Game: addappid(39500)

-- MAIN APP DEPOTS / PACKAGES
addappid(39501, 1, "9559d3f3447579c024499530f3b69a3d4cb95a2fac936eb4893a363c92a89f4b")
addappid(39502, 1, "6943bcb2838d59bf1b82470636df7362cd28271605a16e776078f4e081be3f4a")
addappid(39503, 1, "e8d43baa3485ac943e81474123ff64188daa61714387ca59fb6cabbddc60f054")
addappid(39504, 1, "abce3db9c94be398caea65ee89ed00039c69cb1d788b41f9a1e8539f9e78505f")
addappid(39505, 1, "1f368a04fd67e60b5bf0f7c7876eeb65815dc7e554b090e2256cf6eff31767d2")
addappid(39506, 1, "dbc18e08dbd4ffbd7a4dfaa6b00ab7f607310ac4006517b7f2d75724c14db799")
