-- Lua provided by RyzenAPI
-- Game: Visual Novel Maker

-- MAIN APPLICATION
addappid(495480)
-- Game: addappid(495480)

-- MAIN APP DEPOTS / PACKAGES
addappid(495481, 1, "8b8e085bb7924c9c5399b4a1708696f48a2d72a3db756bb3be7b5acce16d3a86")
addappid(495482, 1, "98241dbad1138ae0bb6534eb0cadcfef923d3be0845ba923dbf0c852132e6fd2")
addappid(495485, 1, "99fc5beb9662dc26516303b03aefb4b5647592460fd0090cdea8ff58bf7ab4e8")
addappid(495486, 1, "326ffbf754741dfefb1f44b479efc06c61e81d1a79a629a609192319b280bf6e")
addappid(495487, 1, "643ff24911e7269beefd214d338f7cbfca2497c1edabe63ef3bfae5db540a5a3")
addappid(495488, 1, "2b6d0f99225a21a031fb280667bd2c5f28118ff1f047792b43760aaec6655563")
addappid(495489, 1, "d22075fc93f3ce70836adb684300993a69d822cfa08a865de5520fd2664294fe")
addappid(610291, 0, "ff3cef93ddc31bd06a668e2059c0a1857080d615e5bf3b26b710cd9ada9893d3")
