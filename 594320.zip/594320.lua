-- Lua provided by RyzenAPI
-- Game: 594320

-- MAIN APPLICATION
addappid(594320)
addappid(594321)
addappid(594322)
addappid(594325)
-- Game: addappid(594320)

-- MAIN APP DEPOTS / PACKAGES
addappid(594323,0,"a4ade4c7ec1d25607c9dc8f0a1ce2222c4964fecc2f65acbd28e21ca5941b58a")
addappid(594324,0,"57bcc0d353a34fc6d2a81e303edda626fc944c2f86692c9061cc7fa7ac2123cc")
