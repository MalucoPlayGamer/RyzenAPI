-- Lua provided by RyzenAPI
-- Game: Game: Bamerang

-- MAIN APPLICATION
addappid(1236490)
-- Game: addappid(1236490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236491, 1, "307ae6ae627c97630cfbc4f46669ed22b58c8c5e20c94faa643904e599cae371")
