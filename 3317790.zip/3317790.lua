-- Lua provided by RyzenAPI
-- Game: Game: AppID 3317790

-- MAIN APPLICATION
addappid(3317790)
-- Game: addappid(3317790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317791, 1, "72fa5714eb4780632d0836d3e7430ff18a4ff7439e6c5ffd4ce78230683820d6")
