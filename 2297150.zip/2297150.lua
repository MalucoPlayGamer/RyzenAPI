-- Lua provided by RyzenAPI
-- Game: addappid(2297150)

-- MAIN APPLICATION
addappid(2297150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297151, 1, "b8e6b43159f124d8eefdf99eaf08c714e3af9dbe03f83aa6ebea349777fe19e0")
