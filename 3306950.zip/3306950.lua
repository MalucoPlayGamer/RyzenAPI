-- Lua provided by SkyAPI 
-- Game: Runes of Legend
addappid(3306950)
addappid(3306951, 1, "4169a85e8126cff907b75ba893835e8b5904cc0e6eae1ed6a6b8724f252515bd")
