-- Lua provided by RyzenAPI
-- Game: Ice Cream Factory

-- MAIN APPLICATION
addappid(796520)

-- MAIN APP DEPOTS / PACKAGES
addappid(796521,0,"0c335c45a6b8ff2f183d38b096345352026d18fea5e15d3363406d4878c3063a")

