-- Lua provided by RyzenAPI
-- Game: AppID 1179530

-- MAIN APPLICATION
addappid(1179530)
-- Game: addappid(1179530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179531, 1, "3b5c9c110bac9884c2542cb8b3ca4e320e7fe0f49a48572912f781374791a30a")
