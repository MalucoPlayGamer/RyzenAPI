-- Lua provided by RyzenAPI 
-- Game: Cartridge Defense
addappid(1291540)
addappid(1291541, 1, "8b0185b360be0fb038f7ae75af54d9d83150dd55bf0baa88572fef18725684ad")
