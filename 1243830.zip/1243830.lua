-- Lua provided by RyzenAPI 
-- Game: AppID 1243830
addappid(1243830)
addappid(1243831, 1, "ee4fef3dceab1e96eb608bde52106366ade46c83bf1db1432b02b5f5e3d9c858")
