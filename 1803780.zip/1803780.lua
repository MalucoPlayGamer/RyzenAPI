-- Lua provided by RyzenAPI
-- Game: Surviving the Aftermath: New Alliances

-- MAIN APPLICATION
addappid(1803780)
-- Game: addappid(1803780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803780,0,"0ef019ae9214cb334cedf3404ae05fcc64bc53edb6ae8735893bfc898382a05a")
