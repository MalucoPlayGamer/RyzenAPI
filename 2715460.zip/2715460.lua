-- Lua provided by SkyAPI 
-- Game: AppID 2715460
addappid(2715460)
addappid(2715461, 1, "b3c7670710afc05b7f69f88e9b3c6019c440ea3fb5144d31db54233215feed7d")
