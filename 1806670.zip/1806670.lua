-- Lua provided by RyzenAPI
-- Game: addappid(1806670)

-- MAIN APPLICATION
addappid(1806670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806671, 1, "54f2aced9dd3db88006bd18927f5906923aae4807de2f94f978acd6f259c811e")
