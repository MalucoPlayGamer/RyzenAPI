-- Lua provided by RyzenAPI
-- Game: Haunted House Escape: A VR Experience

-- MAIN APPLICATION
addappid(1806670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806671, 1, "54f2aced9dd3db88006bd18927f5906923aae4807de2f94f978acd6f259c811e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
