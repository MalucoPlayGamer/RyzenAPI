-- Lua provided by SkyAPI 
-- Game: Lilith Odyssey
addappid(1450800)
addappid(1450801, 1, "9396965f6864b25b0256e5b2736461f2ca7b601a0da18c473520974a49d10a58")
