-- Lua provided by RyzenAPI
-- Game: Lilith Odyssey

-- MAIN APPLICATION
addappid(1450800)
-- Game: addappid(1450800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450801, 1, "9396965f6864b25b0256e5b2736461f2ca7b601a0da18c473520974a49d10a58")
