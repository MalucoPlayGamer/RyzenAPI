-- Lua provided by RyzenAPI
-- Game: ENIGMA:

-- MAIN APPLICATION
addappid(494100)

-- MAIN APP DEPOTS / PACKAGES
addappid(494101, 1, "48d9d9c137d14a95f1f206a1208d9df454d4ddca071f2193ca2bacb1a97b80db")
