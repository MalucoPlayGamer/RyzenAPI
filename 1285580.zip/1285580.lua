-- Lua provided by RyzenAPI
-- Game: Queens Garden: Sakura Season

-- MAIN APPLICATION
addappid(1285580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285581, 1, "b5019382227474535df6ba56c73a159bdcdd866c513768117a1cb36332bfd026")

