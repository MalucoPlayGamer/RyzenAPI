-- Lua provided by RyzenAPI 
-- Game: The Misadventure Of Melon
addappid(972520)
addappid(972521, 1, "89ce1628fa4330c997270a6c7fd1d75044384fa2c99f64179eeda39dcc3c9bcc")
addappid(1059250, 0, "1ca2692f646721f7134741f5bd3cb89ccaff4760b63b6f7e8a084c33fa0255ca")
