-- Lua provided by RyzenAPI 
-- Game: First Bite
addappid(1834820)
addappid(1834821, 1, "e550406d9e488b3953e0dde86b43e90a7e13ce56c76642e73cae437b6084e0e4")
addappid(2157000, 0, "146c943436987cbfb3e37e5200148a79ecc0173fb1ad16bc5b72e238c068fadf")
