-- Lua provided by RyzenAPI
-- Game: Lakeburg Legacies - Supporter's Pack

-- MAIN APPLICATION
addappid(2470590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470590,0,"7e522a821becaa6d0d8e61ac3398af39d8ed0ed27b0c39cd1db37bab46a1066e")
