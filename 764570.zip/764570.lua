-- Lua provided by RyzenAPI
-- Game: Beavers Be Dammed

-- MAIN APPLICATION
addappid(764570)
-- Game: addappid(764570)

-- MAIN APP DEPOTS / PACKAGES
addappid(764571, 1, "b56ad2be5cf542adfd7e88c0269e81e3d7f7f45009d9bf58d342dc4ebacc9e22")
addappid(764572, 1, "ec8b318fd3ebc9ee96674440e67a4c54492ea9bfc74894835183685d707430ab")
addappid(764573, 1, "3099da30a2d4c9dce67ead7520b6aa55d4cee22db089bd4b303845a54c859a24")
