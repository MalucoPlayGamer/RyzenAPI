-- Lua provided by RyzenAPI
-- Game: Three Kingdoms: Innovatory

-- MAIN APPLICATION
addappid(2340500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340502,0,"07569ac8013afae0648504e9ec455ca65316441317165769a02b92f7c9fd01eb")

