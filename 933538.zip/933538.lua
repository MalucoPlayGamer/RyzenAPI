-- Lua provided by RyzenAPI
-- Game: 933538

-- MAIN APPLICATION
addappid(933538)

-- MAIN APP DEPOTS / PACKAGES
addappid(933538,0,"3d1f464f19dbb5b77d6afcdf5c3528f825fb2e4d52e9f1ddcfc96ec6c87ad096")
