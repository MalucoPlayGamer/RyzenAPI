-- Lua provided by RyzenAPI
-- Game: AppID 1161450

-- MAIN APPLICATION
addappid(1161450)
-- Game: addappid(1161450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161451, 1, "227432d94375f1deb7ef0c02356f81352564146f8c6de4775098fea2c95d46cd")
addappid(1161452, 1, "019dc0e534cd6eecf9bf82a42f9bd30a3b1d3920520bb3e4753e7a2befcf8ba0")
