-- Lua provided by RyzenAPI
-- Game: Brány Skeldalu

-- MAIN APPLICATION
addappid(3533830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3533831, 1, "e1399d6d2799d6704ee038415c9bce843919de9722644165aad2d9d88a9ecd21")

