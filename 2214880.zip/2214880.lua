-- Lua provided by RyzenAPI
-- Game: Europa

-- MAIN APPLICATION
addappid(2214880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214881, 1, "7cc362056d81335dfe4147091ad28d268d931614a2abab6a1b17f4501c6d1432")

