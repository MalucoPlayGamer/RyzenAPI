-- Lua provided by RyzenAPI
-- Game: addappid(3230000)

-- MAIN APPLICATION
addappid(3230000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3230001, 1, "11589860b5787f6c58d66072f4afdbc9772f55683b6ad9d37beb3e3fb6aaf129")
