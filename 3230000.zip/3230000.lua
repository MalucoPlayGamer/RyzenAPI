-- Lua provided by SkyAPI 
-- Game: Europa: Ambient Moods
addappid(3230000)
addappid(3230001, 1, "11589860b5787f6c58d66072f4afdbc9772f55683b6ad9d37beb3e3fb6aaf129")
