-- Lua provided by RyzenAPI
-- Game: Game: Sakura Isekai Adventure 3

-- MAIN APPLICATION
addappid(3240500)
-- Game: addappid(3240500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3240501, 1, "5379b20cf66532c3f159a527b2a516e9f5bc293ad6949296407fbf3706255ae4")
