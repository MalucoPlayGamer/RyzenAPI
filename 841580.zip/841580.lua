-- Lua provided by RyzenAPI
-- Game: Realmstone

-- MAIN APPLICATION
addappid(841580)

-- MAIN APP DEPOTS / PACKAGES
addappid(841581,0,"3e334351dd1a419bbdddee342e9b20c63b0e61c43622a07c7eca12c9911d8bb6")

