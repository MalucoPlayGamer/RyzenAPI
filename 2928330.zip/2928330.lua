-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2928330)
addappid(2928331)
addappid(2928332)
addappid(2928333)
addappid(2959210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928334,0,"40d25c8256f47fcde8f3d12e46e422d0e1d99d49b2a887f8a56202fb1e9bcaaf")
