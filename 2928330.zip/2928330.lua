-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2928330)
addappid(2928331)
addappid(2928332)
addappid(2928333)
addappid(2959210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928334,0,"40d25c8256f47fcde8f3d12e46e422d0e1d99d49b2a887f8a56202fb1e9bcaaf")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3337020)
addappid(3362060)
addappid(3530340)
addappid(3739290)
addappid(3816310)
addappid(3872560)
addappid(3932520)
addappid(4042240)
addappid(4042250)
addappid(4042260)
addappid(4042270)
addappid(4042280)
addappid(4042290)
addappid(4042300)
addappid(4099750)
addappid(4192930)
addappid(4313950)
