-- Lua provided by RyzenAPI
-- Game: The Three Kingdoms: The Tales of Jian An

-- MAIN APPLICATION
addappid(3362990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3362991, 1, "d1f8c1d20b6f71281f05cf7dbb076f6be0b6cca082d9b1c96ce53e7b044af80e")
addappid(3362992, 1, "9798990a39e5d194686a71b75300b0a1496099a09f87f7c0462ec9217dac84a4")
addappid(3362994, 1, "c1053773c8087dd580afffa27d6e574c2f9c974efe91d0d238309827edf632aa")

