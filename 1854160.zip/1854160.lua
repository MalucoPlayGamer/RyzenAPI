-- Lua provided by RyzenAPI
-- Game: addappid(1854160)

-- MAIN APPLICATION
addappid(1854160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854161, 1, "87ba9d7ac91a14f42ba380b2dabbf02c4edaed9d84c8af9fe4539e4f14c69f1a")
