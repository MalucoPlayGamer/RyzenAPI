-- Lua provided by RyzenAPI
-- Game: addappid(1839570)

-- MAIN APPLICATION
addappid(1839570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839578,0,"8ded23ad982cbc3782761f479e79258d9da8b68e88c3c1f37943df9373aed6aa")
addappid(1839579,0,"29947574885aa4cfbbe17c1fef27865233bfbcc645cb6b079bb3567bc0ea2cea")
