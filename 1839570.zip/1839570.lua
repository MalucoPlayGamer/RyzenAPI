-- Lua provided by RyzenAPI
-- Game: College Seduction

-- MAIN APPLICATION
addappid(1839570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839578,0,"8ded23ad982cbc3782761f479e79258d9da8b68e88c3c1f37943df9373aed6aa")
addappid(1839579,0,"29947574885aa4cfbbe17c1fef27865233bfbcc645cb6b079bb3567bc0ea2cea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1851480)
addappid(1945550)
