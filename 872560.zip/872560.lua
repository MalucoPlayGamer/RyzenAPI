-- Lua provided by RyzenAPI
-- Game: Cubeology

-- MAIN APPLICATION
addappid(872560)

-- MAIN APP DEPOTS / PACKAGES
addappid(872561,0,"62fda478d4bc984ff3c3735aedd4c3ba9c6a01b5fb49292a5e148014324455aa")

