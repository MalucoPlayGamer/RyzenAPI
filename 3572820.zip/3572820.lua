-- Lua provided by RyzenAPI
-- Game: Crimson Theory

-- MAIN APPLICATION
addappid(3572820)
-- Game: addappid(3572820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572821, 1, "0b769df806c5569d0f40c0fb83a27086d0e448bec75ecd70448e544fc7c71a37")
