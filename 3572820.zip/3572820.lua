-- Lua provided by RyzenAPI
-- Game: Crimson Theory

-- MAIN APPLICATION
addappid(3572820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572821, 1, "0b769df806c5569d0f40c0fb83a27086d0e448bec75ecd70448e544fc7c71a37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
