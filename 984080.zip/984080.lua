-- Lua provided by RyzenAPI
-- Game: Christmas Carol

-- MAIN APPLICATION
addappid(984080)

-- MAIN APP DEPOTS / PACKAGES
addappid(984081, 1, "7059b702621ca8e54a32c8d267e2582cfa4f2c1af55491ba09a95040e21997fa")
