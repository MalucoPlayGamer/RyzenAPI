-- Lua provided by RyzenAPI
-- Game: addappid(2103510)

-- MAIN APPLICATION
addappid(2103510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103511, 1, "a8335fae431b595479800b85ef52a9a758f66ad49ec5b4724823b5adbfa64c5f")
