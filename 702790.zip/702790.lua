-- Lua provided by RyzenAPI
-- Game: 午餐13

-- MAIN APPLICATION
addappid(702790)

-- MAIN APP DEPOTS / PACKAGES
addappid(702791,0,"ebfdf3de4735ed4b0fce1c89f564afa2f044b8d17cab38b5ca6a93c260be75ed")

