-- Lua provided by RyzenAPI
-- Game: The Frog Prince

-- MAIN APPLICATION
addappid(4587830) -- The Frog Prince

-- MAIN APP DEPOTS / PACKAGES
addappid(4587831, 1, "7539eac2341872ebd183234f055fcbd6908e1ef70fde755669aaa5046c4ef5f0") -- Depot 4587831

