-- 4587830's Lua and Manifest Created by Hubcap Manifest
-- The Frog Prince
-- Created: August 10, 2026 at 14:56:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4587830) -- The Frog Prince
-- MAIN APP DEPOTS
addappid(4587831, 1, "7539eac2341872ebd183234f055fcbd6908e1ef70fde755669aaa5046c4ef5f0") -- Depot 4587831
setManifestid(4587831, "1700067806621928037", 788393848)