-- Lua provided by RyzenAPI
-- Game: MotoGP™19

-- MAIN APPLICATION
addappid(984780)
addappid(1058300)
-- Game: addappid(984780)

-- MAIN APP DEPOTS / PACKAGES
addappid(984781, 1, "119913263a8a2f30967c98b9ac6c1a0a56b0575467d4542d127a3b87de4aab84")
