-- Lua provided by RyzenAPI
-- Game: MotoGP™19

-- MAIN APPLICATION
addappid(984780)
addappid(1058300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(984781, 1, "119913263a8a2f30967c98b9ac6c1a0a56b0575467d4542d127a3b87de4aab84")

