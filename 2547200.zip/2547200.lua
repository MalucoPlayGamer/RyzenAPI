-- Lua provided by RyzenAPI
-- Game: MONOTONIA: First Contact

-- MAIN APPLICATION
addappid(2547200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2547201, 1, "478eddc29f26fe4d99b37de33fb7faabb3e625c6e57c900a5faad04999bc279f")

