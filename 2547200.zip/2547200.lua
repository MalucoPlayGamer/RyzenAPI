-- Lua provided by RyzenAPI 
-- Game: MONOTONIA: First Contact
addappid(2547200)
addappid(2547201, 1, "478eddc29f26fe4d99b37de33fb7faabb3e625c6e57c900a5faad04999bc279f")
