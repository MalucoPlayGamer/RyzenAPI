-- Lua provided by RyzenAPI
-- Game: Station 228

-- MAIN APPLICATION
addappid(749480)

-- MAIN APP DEPOTS / PACKAGES
addappid(749481, 1, "760d263e16cbee432b0cdee4af0b2a30a7a7502da5ab9bef56391ce686f34c07")

