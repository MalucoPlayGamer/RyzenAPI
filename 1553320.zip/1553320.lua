-- Lua provided by RyzenAPI
-- Game: Inside Depth 6

-- MAIN APPLICATION
addappid(1553320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553321, 1, "82002839d9f4fa3da32983cf535e6d7d2bdcf4142f9a7511eb5946ec68f44202")
