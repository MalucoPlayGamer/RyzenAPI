-- Lua provided by RyzenAPI
-- Game: Moving Day

-- MAIN APPLICATION
addappid(750020)
-- Game: addappid(750020)

-- MAIN APP DEPOTS / PACKAGES
addappid(750021, 1, "aeccea0b85c62ffe97bc1379a556cbc6b04be2914434d82771c4768f78f5f7f2")
