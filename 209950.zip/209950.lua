-- Lua provided by RyzenAPI
-- Game: AppID 209950

-- MAIN APPLICATION
addappid(209950)

-- MAIN APP DEPOTS / PACKAGES
addappid(209951, 1, "fa54f6240f27dd18a528eca18afcd5c423d1b760cd51ef7aa4a4ae811c375cb0")
addappid(209952, 1, "fbe65722292a775b1709dff3db026137472d8ffad8c7119166b3c292d3f09fbb")

