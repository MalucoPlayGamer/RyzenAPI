-- Lua provided by RyzenAPI 
-- Game: Cradle of Nightmare : Flowers to you
addappid(3469850)
addappid(3469851, 1, "a3451796b5c0e4b38400eef7ad7daef654ee98f673de976c56bee65637b7b9f8")
