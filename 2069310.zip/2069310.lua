-- Lua provided by RyzenAPI
-- Game: RealFlight Evolution

-- MAIN APPLICATION
addappid(2069310)
addappid(4343140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069311, 1, "f7c10cf67e59ca711014eb225bff0dd5b23321981134b4a51f54d255632bab00")
