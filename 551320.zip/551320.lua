-- Lua provided by RyzenAPI
-- Game: Lord Darydikilkil

-- MAIN APPLICATION
addappid(551320)

-- MAIN APP DEPOTS / PACKAGES
addappid(551321,0,"4bf8521f4bed8fdffaed5f378bdd328ca9cce52ccb9a6c9c4dffc4c58ac61000")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
