-- Lua provided by RyzenAPI
-- Game: Lord Darydikilkil

-- MAIN APPLICATION
addappid(551320)

-- MAIN APP DEPOTS / PACKAGES
addappid(551321,0,"4bf8521f4bed8fdffaed5f378bdd328ca9cce52ccb9a6c9c4dffc4c58ac61000")

