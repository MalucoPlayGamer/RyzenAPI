-- Lua provided by RyzenAPI
-- Game: ChessCraft

-- MAIN APPLICATION
addappid(1635790)
addappid(1635791)
addappid(1635793)
addappid(1635794)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635792,0,"1799c403db3136cabb2f48f0f0965990395f87b115f5ba48e6013d48b4e1e148")

