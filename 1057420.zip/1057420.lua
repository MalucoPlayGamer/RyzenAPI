-- Lua provided by RyzenAPI
-- Game: Earthshakers

-- MAIN APPLICATION
addappid(1057420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057421, 1, "53818ef65d4b07abdc5a4925f4ad9b33823f6c859a7761129407562bd011e89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
