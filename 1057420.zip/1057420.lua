-- Lua provided by RyzenAPI 
-- Game: Earthshakers
addappid(1057420)
addappid(1057421, 1, "53818ef65d4b07abdc5a4925f4ad9b33823f6c859a7761129407562bd011e89f")
