-- Lua provided by RyzenAPI
-- Game: 1261270

-- MAIN APPLICATION
addappid(1261270)
-- Game: addappid(1261270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261270,0,"35065fd4cc1828f50c79b892de5c9a8ce97333c1ff4bfa2f8b7757ee63cc05ae")
