-- Lua provided by RyzenAPI
-- Game: 乱斗先锋

-- MAIN APPLICATION
addappid(2868950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868951, 1, "ce81b462820a6371fdb2d138555751f3b99f702e112e7ff38ac11fd54f5217c3")

