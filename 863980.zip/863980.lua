-- Lua provided by RyzenAPI 
-- Game: AppID 863980
addappid(863980)
addappid(863981, 1, "61b8a97acb6d2a377cea711affff8f249dcac455290afc4dca6a6d7cd5ccbbc7")
