-- Lua provided by RyzenAPI
-- Game: ORIX!

-- MAIN APPLICATION
addappid(863980)

-- MAIN APP DEPOTS / PACKAGES
addappid(863981, 1, "61b8a97acb6d2a377cea711affff8f249dcac455290afc4dca6a6d7cd5ccbbc7")
