-- Lua provided by RyzenAPI
-- Game: Game: SCORCH

-- MAIN APPLICATION
addappid(1606580)
-- Game: addappid(1606580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606581, 1, "a52fd41dd35e861c67ca09ff72d12306596457194ca9ae94e2d57ba8e7a22896")
