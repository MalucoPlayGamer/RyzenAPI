-- Lua provided by RyzenAPI
-- Game: Game: AppID 1106340

-- MAIN APPLICATION
addappid(1106340)
-- Game: addappid(1106340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106341, 1, "961096860b1f2ee33e0b42b7ccdbd75a75a640a027e37269fe1cbdd84f8d81ea")
