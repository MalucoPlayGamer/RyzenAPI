-- Lua provided by RyzenAPI
-- Game: 2129670

-- MAIN APPLICATION
addappid(2129670)
-- Game: addappid(2129670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129671, 1, "c1ee40b1050215ab2a9815028a7b75429875bc51da9d2621ccbef2b54e945a76")
