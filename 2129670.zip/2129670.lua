-- Lua provided by SkyAPI 
-- Game: Hardrock Sex 3D
addappid(2129670)
addappid(2129671, 1, "c1ee40b1050215ab2a9815028a7b75429875bc51da9d2621ccbef2b54e945a76")
