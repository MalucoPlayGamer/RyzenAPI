-- Lua provided by RyzenAPI
-- Game: AppID 243220

-- MAIN APPLICATION
addappid(243220)
-- Game: addappid(243220)

-- MAIN APP DEPOTS / PACKAGES
addappid(243221, 1, "03019de2a230d8a8b2e4aeac89c07574ea3a3547e532ffaa4ab749f4a1c52e9d")
addappid(243222, 1, "f07620ec3557357794c51acabfb85550475ffddbbcf3d288c988ef020d2301da")
