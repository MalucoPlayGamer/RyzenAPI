-- Lua provided by RyzenAPI
-- Game: 1415750

-- MAIN APPLICATION
addappid(1415750)
-- Game: addappid(1415750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415751, 1, "bd43ec07a7b56e53f54e3ceedac39256c0cd2535f2f7c43df5414c28443e8ee1")
