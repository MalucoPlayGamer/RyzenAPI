-- Lua provided by RyzenAPI
-- Game: Gravity_Kid

-- MAIN APPLICATION
addappid(1415750)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1415751, 1, "bd43ec07a7b56e53f54e3ceedac39256c0cd2535f2f7c43df5414c28443e8ee1")

