-- Lua provided by RyzenAPI
-- Game: Megacopter: Blades of the Goddess

-- MAIN APPLICATION
addappid(1228360)
-- Game: addappid(1228360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228362,0,"2db2ed9bf1548f7dd47b26726b03144a909582100489e931eba5c8d8f5de64bb")
addappid(1228363,0,"1301b6079b64bb552cfd7842777da8a0a91ab863ef45e24988c5897e2a4f4642")
addappid(1228364,0,"ec0a1efcb260c33ceee0d0197afca990a03cbe95bfc7737d72ad02e74535ffbf")
