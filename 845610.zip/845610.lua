-- Lua provided by RyzenAPI
-- Game: Game: AppID 845610

-- MAIN APPLICATION
addappid(845610)
-- Game: addappid(845610)

-- MAIN APP DEPOTS / PACKAGES
addappid(845611, 1, "5c74b6e9ea001a62e239918e7982b36141c4c1be3ddc43a923280266986c0696")
