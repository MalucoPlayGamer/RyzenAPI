-- Lua provided by RyzenAPI
-- Game: 715370

-- MAIN APPLICATION
addappid(715370)
-- Game: addappid(715370)

-- MAIN APP DEPOTS / PACKAGES
addappid(715371, 1, "d65fd2e54c23c356294552ff0263f635054d4085cf565a7373be0f046bac4c47")
