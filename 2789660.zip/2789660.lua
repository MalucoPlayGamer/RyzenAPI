-- Lua provided by RyzenAPI
-- Game: AppID 2789660

-- MAIN APPLICATION
addappid(2789660)
-- Game: addappid(2789660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789661, 1, "98c9265abb23b82895cff3ece834f529d7fd23158749bc296bb3216bfd840ce8")
