-- Lua provided by RyzenAPI
-- Game: The Esoterica: Hollow Earth

-- MAIN APPLICATION
addappid(560730)

-- MAIN APP DEPOTS / PACKAGES
addappid(560731,0,"4b312965c0e7b3a0eea666747bc3d48fb17af0be59c4474a313641e3e89c22be")

