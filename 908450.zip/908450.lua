-- Lua provided by RyzenAPI 
-- Game: AppID 908450
addappid(908450)
addappid(908451, 1, "c7f761b085ac647ac3e0176f5c7cd7846792b469359b64b6ebd46a54c01511fa")
