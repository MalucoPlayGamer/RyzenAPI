-- Lua provided by SkyAPI 
-- Game: AppID 755450
addappid(755450)
addappid(755451, 1, "59557c5cc1d90fea6be45cece954a0daa90d7f420cc74756eda3d861e3d0cfd2")
