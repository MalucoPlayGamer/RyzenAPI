-- Lua provided by RyzenAPI
-- Game: Stage 3: Azaria

-- MAIN APPLICATION
addappid(755450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(755451, 1, "59557c5cc1d90fea6be45cece954a0daa90d7f420cc74756eda3d861e3d0cfd2")

