-- Lua provided by RyzenAPI
-- Game: Carsick Carventure

-- MAIN APPLICATION
addappid(2658840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658841, 1, "c1f5e8e6ed6080accbb7de8738c5adcf7eb15ac06b420b0367ca66ca0bede7be")
