-- Lua provided by SkyAPI 
-- Game: A Night in Prison
addappid(2515300)
addappid(2515301, 1, "16ed3fd3f521d06540d147c695d230f217551c9487ef290e53e33115960c1dc2")
