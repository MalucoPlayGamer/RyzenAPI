-- Lua provided by RyzenAPI
-- Game: A Night in Prison

-- MAIN APPLICATION
addappid(2515300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515301, 1, "16ed3fd3f521d06540d147c695d230f217551c9487ef290e53e33115960c1dc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
