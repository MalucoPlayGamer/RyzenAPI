-- Lua provided by RyzenAPI
-- Game: A Night in Prison

-- MAIN APPLICATION
addappid(2515300)
-- Game: addappid(2515300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515301, 1, "16ed3fd3f521d06540d147c695d230f217551c9487ef290e53e33115960c1dc2")
