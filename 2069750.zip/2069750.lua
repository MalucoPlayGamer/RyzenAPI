-- Lua provided by RyzenAPI
-- Game: Islet Hell

-- MAIN APPLICATION
addappid(2069750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2069751, 1, "e9c7362a26c09b2e692796f461209a2c8d4a54dd6790c5cb80325990efda9395")
addappid(2069752, 1, "65c7057783632270d2cdbdde0cac9f200bd63fd7db12fa8b4db1c3be74251c0f")
addappid(2069753, 1, "260f57b3fb132e1feb7608a594cc60addf65cef81a81b4f6a19694e8c29d0ea6")

