-- Lua provided by RyzenAPI
-- Game: Click and Conquer

-- MAIN APPLICATION
addappid(3267900)
-- Game: addappid(3267900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267902,0,"eb29641a981c643dd2492131a9f5eba97db5a7bc6919166b9bb41acd775c14a8")
