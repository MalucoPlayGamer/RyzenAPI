-- Lua provided by RyzenAPI
-- Game: The Crown of Leaves Demo

-- MAIN APPLICATION
addappid(615100)
addappid(615101)

-- MAIN APP DEPOTS / PACKAGES
addappid(604331,0,"93cf6dd90398f7eabad693e1f080103e2b1fac009e95e5ef22f7d45038c76385")
