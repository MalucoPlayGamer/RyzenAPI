-- Lua provided by RyzenAPI
-- Game: Game: Crazy Empress

-- MAIN APPLICATION
addappid(1780250)
-- Game: addappid(1780250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780251, 1, "40d8f3a6bf87952c05a962b1545b5ff9f48d3f7b1335ed2428eb32cc7355b260")
