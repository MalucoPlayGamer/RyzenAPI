-- Lua provided by RyzenAPI
-- Game: Crazy Empress

-- MAIN APPLICATION
addappid(1780250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1780251, 1, "40d8f3a6bf87952c05a962b1545b5ff9f48d3f7b1335ed2428eb32cc7355b260")

