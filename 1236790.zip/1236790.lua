-- Lua provided by RyzenAPI
-- Game: Game: The Pedestrian Soundtrack

-- MAIN APPLICATION
addappid(1236790)
-- Game: addappid(1236790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236791, 1, "02b3c96830b6049a5ceba03fd6d89c237fde7c47a67c925add948fbff4937fe7")
addappid(1236792, 1, "a40729380fef2b36f01c19d730edb7a089dedd226dd91ddd751b4a6b80514d1c")
