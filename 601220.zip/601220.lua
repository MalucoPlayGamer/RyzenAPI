-- Lua provided by RyzenAPI
-- Game: addappid(601220)

-- MAIN APPLICATION
addappid(601220)

-- MAIN APP DEPOTS / PACKAGES
addappid(601221, 1, "5496ee33af3bfd301dafbfe843273065368fed509f4aafb558a3513c1f40fd89")
