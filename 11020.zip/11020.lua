-- Lua provided by RyzenAPI
-- Game: 11020

-- MAIN APPLICATION
addappid(11020)
-- Game: addappid(11020)

-- MAIN APP DEPOTS / PACKAGES
addappid(11021, 1, "5bcafc9647263964cf24b18c0bb322728aec8da702b94ec8d7186e36c6e9a97e")
addappid(11022, 1, "7e52c9fcd8b1918d7ac27e6890925a5bd33f6b7e5c36021d199c14c3453e71e7")
