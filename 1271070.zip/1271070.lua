-- Lua provided by RyzenAPI
-- Game: 1271070

-- MAIN APPLICATION
addappid(1271070)
-- Game: addappid(1271070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271071, 1, "67c7e4993de80a2c8d0e5af2f35c3381efc8e30694963bfb81f715d4f286ae97")
