-- Lua provided by RyzenAPI
-- Game: AppID 1271070

-- MAIN APPLICATION
addappid(1271070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271071, 1, "67c7e4993de80a2c8d0e5af2f35c3381efc8e30694963bfb81f715d4f286ae97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
