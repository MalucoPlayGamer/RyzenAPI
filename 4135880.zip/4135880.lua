-- Lua provided by RyzenAPI
-- Game: Winds of Valen

-- MAIN APPLICATION
addappid(4135880)

