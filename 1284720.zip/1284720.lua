-- Lua provided by RyzenAPI
-- Game: 1284720

-- MAIN APPLICATION
addappid(1284720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284720,0,"c679c5a0fdced934e8f67409d7e376cb24c0f7ba86d877133f3acec206fffc49")

