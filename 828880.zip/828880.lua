-- Lua provided by RyzenAPI
-- Game: Psi Cards - Soundtrack

-- MAIN APPLICATION
addappid(828880)

-- MAIN APP DEPOTS / PACKAGES
addappid(828880,0,"004a888b7da311f9a67a4b9b9e39ed76eb4b7db1f41f01a51a84d70ac0de5b85")
