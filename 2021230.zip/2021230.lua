-- Lua provided by RyzenAPI
-- Game: Ashen Knights: One Passage

-- MAIN APPLICATION
addappid(2021230)
-- Game: addappid(2021230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021231, 1, "192fbba9a96d3684d563751dff49b449b4a6692a668aa7e32cd2ecd39c9ae7ca")
