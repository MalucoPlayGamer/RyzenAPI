-- Lua provided by RyzenAPI
-- Game: Ashen Knights: One Passage

-- MAIN APPLICATION
addappid(2021230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021231, 1, "192fbba9a96d3684d563751dff49b449b4a6692a668aa7e32cd2ecd39c9ae7ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
