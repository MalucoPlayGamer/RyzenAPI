-- Lua provided by RyzenAPI
-- Game: Game: CROWDED. FOLLOWED.

-- MAIN APPLICATION
addappid(2948790)
-- Game: addappid(2948790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948791, 1, "6eebbbdfaa92d3fd313999bf0011887219853ee3586fe0c4f0b9cedf3a83d0aa")
