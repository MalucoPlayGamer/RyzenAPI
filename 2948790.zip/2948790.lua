-- Lua provided by RyzenAPI 
-- Game: CROWDED. FOLLOWED.
addappid(2948790)
addappid(2948791, 1, "6eebbbdfaa92d3fd313999bf0011887219853ee3586fe0c4f0b9cedf3a83d0aa")
