-- Lua provided by SkyAPI 
-- Game: xingchenbian online
addappid(2351420)
addappid(2351421, 1, "2a70356701dffb1eb301c4c2edbe5129f8538ce77474a566b512569d5c6a51d5")
