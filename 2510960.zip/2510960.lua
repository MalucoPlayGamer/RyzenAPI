-- Lua provided by RyzenAPI
-- Game: Temtem: Swarm

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(2510960, 1, "180fcdaefca97641b0576afd899fd9a2ad739460ca4cff8eec4f121dd39d93ea") -- Temtem: Swarm
addappid(2510961, 1, "6298e19f83a2a76669f5695059fbdd6bb50c0bd28a05a54f178486de4283e7c4") -- Depot 2510961

