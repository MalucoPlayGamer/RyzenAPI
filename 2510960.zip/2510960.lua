-- 2510960's Lua and Manifest Created by Hubcap Manifest
-- Temtem: Swarm
-- Created: May 16, 2026 at 02:24:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2510960, 1, "180fcdaefca97641b0576afd899fd9a2ad739460ca4cff8eec4f121dd39d93ea") -- Temtem: Swarm
-- MAIN APP DEPOTS
addappid(2510961, 1, "6298e19f83a2a76669f5695059fbdd6bb50c0bd28a05a54f178486de4283e7c4") -- Depot 2510961
--setManifestid(2510961, "8803714228279728357", 2141257396)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)