-- Lua provided by RyzenAPI
-- Game: BLACKOUT

-- MAIN APPLICATION
addappid(1583590)
-- Game: addappid(1583590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583591, 1, "695a25e4ceb5c9e7fa707265eef7ef8ca683a2b6e5a375b8eccd62f0b3c213c4")
