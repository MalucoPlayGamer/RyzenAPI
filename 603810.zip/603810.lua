-- Lua provided by SkyAPI 
-- Game: AppID 603810
addappid(603810)
addappid(603811, 1, "7b1911c638e791a1953d8c31901c41a993b180ed0e96ea1defe01c73c986e3d9")
