-- Lua provided by RyzenAPI
-- Game: 603810

-- MAIN APPLICATION
addappid(603810)
-- Game: addappid(603810)

-- MAIN APP DEPOTS / PACKAGES
addappid(603811, 1, "7b1911c638e791a1953d8c31901c41a993b180ed0e96ea1defe01c73c986e3d9")
