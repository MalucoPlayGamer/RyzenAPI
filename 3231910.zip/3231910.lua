-- Lua provided by RyzenAPI
-- Game: 3231910

-- MAIN APPLICATION
addappid(3231910)
-- Game: addappid(3231910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231911, 1, "ffab6069d65389b437d21d65c7cfeb283c4c6ec177d9eb1885dda9bfac1720da")
