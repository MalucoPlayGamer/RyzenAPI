-- Lua provided by RyzenAPI
-- Game: Purgation

-- MAIN APPLICATION
addappid(682960)

-- MAIN APP DEPOTS / PACKAGES
addappid(682961, 1, "6a5565d63ca97d4c05db849ea928f67b7661621b784eea88ff8f986176d69fab")
