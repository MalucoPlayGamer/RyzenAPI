-- Lua provided by RyzenAPI
-- Game: Harem Inn

-- MAIN APPLICATION
addappid(3333360)
-- Game: addappid(3333360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333361, 1, "9ac11bd4159f8498c395295fb035e0d13b60de9445deca014a27938537396c82")
