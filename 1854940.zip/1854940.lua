-- Lua provided by RyzenAPI
-- Game: Game: Far Far Away From Here

-- MAIN APPLICATION
addappid(1854940)
-- Game: addappid(1854940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854941, 1, "88921417ef213e28f11258500f1737574429ed93c9302a86e69fa999b776d42e")
