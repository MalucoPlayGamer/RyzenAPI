-- Lua provided by RyzenAPI
-- Game: 1964620

-- MAIN APPLICATION
addappid(1964620)
-- Game: addappid(1964620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964621, 1, "daf750a009986c414f98ebebcef758ac364db2c432f79cdd27e29de787d8d7ae")
