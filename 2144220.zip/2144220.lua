-- Lua provided by RyzenAPI
-- Game: 2144220

-- MAIN APPLICATION
addappid(2144220)
-- Game: addappid(2144220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144221, 1, "516c438f0258d3f0be915822f43d2e0602f391a2552ecc666d2567ad49febd9d")
