-- Lua provided by RyzenAPI
-- Game: addappid(3495890)

-- MAIN APPLICATION
addappid(3495890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495891, 1, "2d26baf68f87fd5bc0509fa06e95af115ce4e9c747c5f2e8e129a44a7fcc0f5c")
