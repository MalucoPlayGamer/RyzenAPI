-- Lua provided by RyzenAPI
-- Game: Game: Norega

-- MAIN APPLICATION
addappid(1596380)
-- Game: addappid(1596380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596381, 1, "554b9fe72701c5a9a05f273bd50c7622a43742e28320f5c0d92cafe25584f2e4")
