-- Lua provided by RyzenAPI
-- Game: AppID 1130430

-- MAIN APPLICATION
addappid(1130430)
-- Game: addappid(1130430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130431, 1, "1c663f57e8b2ae14af298813e723832becae9259019bbb6b6c3414e8f110093d")
