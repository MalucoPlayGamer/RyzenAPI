-- Lua provided by RyzenAPI
-- Game: Strip Fighter ZERO

-- MAIN APPLICATION
addappid(2249070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(2249071,0,"cf61e41e500cdd4f845e8a641dccb8f7cba21f788e5950e6f85f5aa928bb96c3")
addappid(2249072,0,"f65021c27600ed264ccb5e38c732d006b77ed6d55921f1a3637c8ab8386e479f")
addappid(2249073,0,"ec52e7b31e295d1e933a1516ac1b8cd4e388a890dc242162f78b556e8b99e58c")
addappid(2249074,0,"57f2c24257470b029e2de4d6b61ecae0b1d2623a20767200eea2dae01c2db5ac")

