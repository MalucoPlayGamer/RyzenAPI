-- Lua provided by RyzenAPI
-- Game: Game: AppID 1295670

-- MAIN APPLICATION
addappid(1295670)
-- Game: addappid(1295670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295671, 1, "f998540dfe310579f4caa33de7312bf715481f1649117745565757177dbacaa1")
