-- Lua provided by RyzenAPI
-- Game: HOT FIT!

-- MAIN APPLICATION
addappid(962380)

-- MAIN APP DEPOTS / PACKAGES
addappid(962381, 1, "1ef89851103d2aa0b76e6857dd90a76d2d72df19fabe20b9d8316212c326e832")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(980370)
addappid(980390)
addappid(980400)
addappid(980410)
addappid(980420)
addappid(980430)
