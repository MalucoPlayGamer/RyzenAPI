-- Lua provided by RyzenAPI
-- Game: addappid(718380)

-- MAIN APPLICATION
addappid(718380)

-- MAIN APP DEPOTS / PACKAGES
addappid(718381, 1, "2b23242e12a921b5f5be29df57c5d5869fefecb6ad1a6b7e09572a5dcb64caa3")
