-- Lua provided by RyzenAPI
-- Game: 1952360

-- MAIN APPLICATION
addappid(1952360)
-- Game: addappid(1952360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952361, 1, "aaed9f5c2e09835759dce7d7b0e4dbc815b992defd884e792d341b3f9ccf1bea")
