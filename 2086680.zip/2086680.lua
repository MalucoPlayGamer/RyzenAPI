-- Lua provided by RyzenAPI
-- Game: Game: Castle Craft

-- MAIN APPLICATION
addappid(2086680)
-- Game: addappid(2086680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086681, 1, "d26f1082b54bbbc389fc56aedfc2cb3f47a9a5d8257f27f6fab2dcfcbf25bae0")
