-- Lua provided by RyzenAPI
-- Game: Castle Craft

-- MAIN APPLICATION
addappid(2086680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2086681, 1, "d26f1082b54bbbc389fc56aedfc2cb3f47a9a5d8257f27f6fab2dcfcbf25bae0")

