-- Lua provided by RyzenAPI 
-- Game: Tide of Thieves
addappid(2112290)
addappid(2112291, 1, "c240a51807e8234023abd85867d73a0e7903f189d1aa4755de9abf777e11404b")
