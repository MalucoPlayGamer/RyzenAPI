-- Lua provided by RyzenAPI
-- Game: The Franz Kafka Videogame

-- MAIN APPLICATION
addappid(392280)

-- MAIN APP DEPOTS / PACKAGES
addappid(392281, 1, "ce21435e80f33a9442989a9cd4fd7a424a21c2a8c165d9751a5ddbdb5b4a6d42")

