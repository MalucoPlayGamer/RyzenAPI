-- Lua provided by RyzenAPI
-- Game: Metamorphosis Soundtrack

-- MAIN APPLICATION
addappid(1525670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525671, 1, "be32d480ea75c134e425c720bb0d94236e99530fb6aa35cad8be7de9f9d85bdc")
