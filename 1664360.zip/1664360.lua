-- Lua provided by RyzenAPI
-- Game: Monuments Flipper: Prologue

-- MAIN APPLICATION
addappid(1664360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664361, 1, "51b99dd55dffa71014c215dca79a1a2496a6ac35710c5674f619c36c2a3a05eb")

