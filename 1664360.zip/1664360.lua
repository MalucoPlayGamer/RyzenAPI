-- Lua provided by RyzenAPI
-- Game: Monuments Flipper: Prologue

-- MAIN APPLICATION
addappid(1664360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664361, 1, "51b99dd55dffa71014c215dca79a1a2496a6ac35710c5674f619c36c2a3a05eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
