-- Lua provided by RyzenAPI
-- Game: Feet Paradise

-- MAIN APPLICATION
addappid(2973820)
addappid(2990660)
-- Game: addappid(2973820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973821, 1, "d22da2f1157c22cdb3bd7cfd4534673c726be2226f2f03e2afc9cf20f4e2063e")
