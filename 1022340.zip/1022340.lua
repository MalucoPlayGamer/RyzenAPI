-- Lua provided by RyzenAPI
-- Game: DFF NT: Novus Appearance Set for Vayne Carudas Solidor

-- MAIN APPLICATION
addappid(1022340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022340,0,"00a0fa978cae7913fad461a452023c79b994fff7b32edf2fb91eb2d2febb8d1e")

