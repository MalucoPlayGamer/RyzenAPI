-- 3515040's Lua and Manifest Created by Hubcap Manifest
-- APOCALYPTIC PUSSY
-- Created: August 12, 2026 at 00:03:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3515040, 1, "05058ec3c7a6deb7ce923ed49a335d3219f421d76282d6adfe66addc872a4db5") -- APOCALYPTIC PUSSY
-- MAIN APP DEPOTS
addappid(3515041, 1, "a195a20761d61b2eadcf37453ae6737b69890ed9d8a20a756cbfbd005723710e") -- Depot 3515041
setManifestid(3515041, "3408716054790732888", 842364035)