-- Lua provided by RyzenAPI
-- Game: OzGrind Virtual Reality Showroom

-- MAIN APPLICATION
addappid(639960)

-- MAIN APP DEPOTS / PACKAGES
addappid(639961, 1, "2e7cf774ecba66bc42f0e39b1a40b21fdcbb7cd05d41b057f6437f160c3fd424")

