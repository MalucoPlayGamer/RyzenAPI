-- Lua provided by RyzenAPI
-- Game: addappid(733090)

-- MAIN APPLICATION
addappid(733090)

-- MAIN APP DEPOTS / PACKAGES
addappid(733091, 1, "6f2efcf732c90a3eae51277049efb98037d325bd2b3704e929fd9f7518895811")
