-- Lua provided by SkyAPI 
-- Game: Mustache Politics Shooter
addappid(733090)
addappid(733091, 1, "6f2efcf732c90a3eae51277049efb98037d325bd2b3704e929fd9f7518895811")
