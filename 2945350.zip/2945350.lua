-- Lua provided by RyzenAPI
-- Game: Wukong's Pool

-- MAIN APPLICATION
addappid(2945350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945351, 1, "04b2541818d3556dbffa38726e047bb46e8d0c5ee780a3a77a0dacd3e6ac6342")
