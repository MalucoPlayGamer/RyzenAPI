-- Lua provided by RyzenAPI
-- Game: Beat Saber - Daft Punk - "Get Lucky (feat. Pharrell Williams and Nile Rodgers)"

-- MAIN APPLICATION
addappid(2838260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838260,0,"5bf29f5eb76bfe3f0bc65e32ba4f3caa6c5e075f2e13afaac42535a099e91fa4")

