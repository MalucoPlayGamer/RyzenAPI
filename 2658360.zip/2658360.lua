-- Lua provided by RyzenAPI
-- Game: WORLD OF HORROR Soundtrack

-- MAIN APPLICATION
addappid(2658360)
-- Game: addappid(2658360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658361, 1, "778d264aec0362b5d79d05a1ba055b43396883474237bda45519b344482d0fb4")
addappid(2658362, 1, "201556ff0148ccbdc9ae7fff92d085f05de9fd6388d0bcc5aac7fddf36792244")
