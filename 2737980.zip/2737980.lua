-- Lua provided by RyzenAPI
-- Game: Mashiroiro Symphony HD -Sana Edition-

-- MAIN APPLICATION
addappid(2737980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737981, 1, "882ceb591ef091f2af56f01825d27f46362ca67a764d89d7d7d6e847ade539fc")
