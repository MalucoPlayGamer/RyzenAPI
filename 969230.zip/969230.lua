-- Lua provided by RyzenAPI
-- Game: AppID 969230

-- MAIN APPLICATION
addappid(969230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(969231, 1, "d170cfdb0b783d9f28dc6f1748659e9dc9d86becd3e382e305894acd23a48adf")

