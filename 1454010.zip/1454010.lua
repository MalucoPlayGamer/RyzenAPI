-- Lua provided by RyzenAPI
-- Game: addappid(1454010)

-- MAIN APPLICATION
addappid(1454010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454015,0,"bb441852efc9e87582366d857f3f3159a6c35100ecb484f1a971e2ef28cad050")
