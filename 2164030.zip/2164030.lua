-- Lua provided by SkyAPI 
-- Game: Stop Dead
addappid(2164030)
addappid(2164031, 1, "acc8f5c990c5cfa10b5d07a4d7fef8c3c1208311468bd51ddf170929cefc3cdb")
