-- Lua provided by RyzenAPI
-- Game: addappid(2164030)

-- MAIN APPLICATION
addappid(2164030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164031, 1, "acc8f5c990c5cfa10b5d07a4d7fef8c3c1208311468bd51ddf170929cefc3cdb")
