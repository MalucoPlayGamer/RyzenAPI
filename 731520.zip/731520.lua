-- Lua provided by RyzenAPI
-- Game: Tooki

-- MAIN APPLICATION
addappid(731520)

-- MAIN APP DEPOTS / PACKAGES
addappid(731521,0,"d756e711300136d7b46bcc5024874e4177dbfc7950fa2bbe5e096be84cab6acd")

