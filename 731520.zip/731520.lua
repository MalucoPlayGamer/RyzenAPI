-- Lua provided by RyzenAPI
-- Game: Tooki

-- MAIN APPLICATION
addappid(731520)

-- MAIN APP DEPOTS / PACKAGES
addappid(731521,0,"d756e711300136d7b46bcc5024874e4177dbfc7950fa2bbe5e096be84cab6acd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
