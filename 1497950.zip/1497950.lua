-- Lua provided by RyzenAPI
-- Game: addappid(1497950)

-- MAIN APPLICATION
addappid(1497950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497951, 1, "9f0496738feba8627d5395d6d1d9d323b595b11967af8582cabc747d7a2d4696")
