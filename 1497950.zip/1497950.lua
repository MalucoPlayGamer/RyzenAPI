-- Lua provided by RyzenAPI
-- Game: EARTH DEFENSE FORCE: WORLD BROTHERS

-- MAIN APPLICATION
addappid(1497950)
addappid(1530270)
addappid(1530271)
addappid(1530272)
addappid(1530273)
addappid(1596650)
addappid(1596651)
addappid(1596652)
addappid(1596653)
addappid(1596654)
addappid(1596655)
addappid(1596660)
addappid(1596661)
addappid(1596662)
addappid(1596663)
addappid(1596664)
addappid(1596665)
addappid(1596666)
addappid(1596667)
addappid(1596670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497951,0,"9f0496738feba8627d5395d6d1d9d323b595b11967af8582cabc747d7a2d4696")

