-- Lua provided by RyzenAPI
-- Game: Demon Queen Melissa

-- MAIN APPLICATION
addappid(1042600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042601, 1, "2ff0e0fb8e45e048be38ae9c7299e05fd0ed207e212cb20c28c74e6bcb4cb158")
addappid(1042602, 1, "710e55d39c2ce830de3b1fba4d715a70c3b624cbd02ece8146098cab80687ea9")
addappid(1042603, 1, "77451660f13ba8e632e1d241a851ad447aad304f4d999cd9a7cd00de2bcf4756")
