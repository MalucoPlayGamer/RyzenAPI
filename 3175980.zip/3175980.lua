-- Lua provided by RyzenAPI
-- Game: 3175980

-- MAIN APPLICATION
addappid(3175980)
-- Game: addappid(3175980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175980,0,"841a90388017145ff0723524faffa4e532c0b0bc2c12580e97afff2f42bdcfe1")
