-- Lua provided by RyzenAPI
-- Game: A Bird Story

-- MAIN APPLICATION
addappid(327410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(327411, 1, "05d2ff6e229db03e2fdfaefe4086aa6b6dc05b13626f141da7fcb40ad4089433")
addappid(327412, 1, "abef2f436d882411db294bc5386ef24597fb63c4f87c8574816d4f39d08f26c1")
addappid(327413, 1, "596b243d55f7c8d591e6fa5aa21b557aaa6b9274dded7aadcbdaef1e328f4fd6")
addappid(328230, 0, "0724e3ff26927d38665292645e8dbe4970a7156e84c86c0e3efe58bffd4980ae")

