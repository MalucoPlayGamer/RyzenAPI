-- Lua provided by RyzenAPI
-- Game: Roomvas

-- MAIN APPLICATION
addappid(2082490)
addappid(2597270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2082491, 1, "f830bfda8d0217e0b12d0175114816034fb26f9c47cbeeea7884107a74017211")

