-- Lua provided by RyzenAPI
-- Game: Roomvas

-- MAIN APPLICATION
addappid(2082490)
addappid(2597270)
-- Game: addappid(2082490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082491, 1, "f830bfda8d0217e0b12d0175114816034fb26f9c47cbeeea7884107a74017211")
