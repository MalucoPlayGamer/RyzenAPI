-- Lua provided by RyzenAPI
-- Game: Sonic Frontiers: Holiday Cheer Suit

-- MAIN APPLICATION
addappid(2089733)
-- Game: addappid(2089733)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089733,0,"3dedee464853a2702ce024319deb87d57c6e2e404a328bce05f71b18a2649faf")
