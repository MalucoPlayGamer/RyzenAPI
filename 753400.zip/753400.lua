-- Lua provided by RyzenAPI
-- Game: Harem Girl: Evie

-- MAIN APPLICATION
addappid(753400)

-- MAIN APP DEPOTS / PACKAGES
addappid(753401, 1, "b8af8cc204a2dd8da88fa1ea4706bf8816538b2e04fccbbebbd1d6c49989bd7f")

