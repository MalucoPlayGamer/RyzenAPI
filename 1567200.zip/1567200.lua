-- Lua provided by RyzenAPI
-- Game: 1567200

-- MAIN APPLICATION
addappid(1567200)
-- Game: addappid(1567200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567202,0,"950417abd8998a09f9d9b9e9f120e241099592bbdb334c613497baf9e7d92ed7")
