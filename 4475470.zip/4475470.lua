-- Lua provided by RyzenAPI
-- Game: Holey Ship

-- MAIN APP DEPOTS / PACKAGES
addappid(4475470, 1, "6d2e3211455877947a7116a9fb18591aa3046651749fdb6414dd613331be9135") -- Holey Ship
addappid(4475471, 1, "5c95a4cbc3293ae7c9c0a4e5bbaa24f6122851ed91a40629e3ad39d26ed3636f") -- Depot 4475471
