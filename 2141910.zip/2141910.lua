-- Lua provided by RyzenAPI
-- Game: Magic: The Gathering Arena

-- MAIN APPLICATION
addappid(2141910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2141911, 1, "a89ce6d3be7e0877eba8558a188bf09a2f37ed0c2de8b9e59224a427f760fba6")
addappid(2141912, 1, "c588292e320d1a32305d1e5f2677bd3d187f561940fdc57f0a31d4f6939deebe")

