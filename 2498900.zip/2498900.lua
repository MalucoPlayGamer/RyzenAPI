-- Lua provided by RyzenAPI
-- Game: BOOM! BUSTER 2024 Kickstarter Demo

-- MAIN APPLICATION
addappid(2498900)
-- Game: addappid(2498900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498901, 1, "d587e6c3a0b8f5c7bda510bfe12ad074fff784807cbc4b68224a113ca14db5e6")
