-- Lua provided by RyzenAPI
-- Game: Lost Marbles

-- MAIN APPLICATION
addappid(291430)

-- MAIN APP DEPOTS / PACKAGES
addappid(291431, 1, "20e1d507ee6ee214bda616a507c43bedd15c1ff1b2eef3e541509309b3b8b05f")
addappid(291432, 1, "5b91c63163e9230642fb7509a38a3f7bcf26806816baa06d14c4071bbde004b1")
addappid(291433, 1, "2038365d2b9d6bc80657424a73fa368856dd06066a5833fe767cd048955092ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
