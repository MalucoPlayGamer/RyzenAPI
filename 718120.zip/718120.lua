-- Lua provided by RyzenAPI
-- Game: AppID 718120

-- MAIN APPLICATION
addappid(718120)
-- Game: addappid(718120)

-- MAIN APP DEPOTS / PACKAGES
addappid(718121, 1, "017b060b483121033dfb6aa08b90204e93d8dd94cb87d653b8873aec0012b210")
