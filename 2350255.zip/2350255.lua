-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! At The Disco - "Viva Las Vengeance"

-- MAIN APPLICATION
addappid(2350255)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350255,0,"a86ba5fa2926d4324d2d207a605a873503e10c67c823081ff32e2bad8185019d")

