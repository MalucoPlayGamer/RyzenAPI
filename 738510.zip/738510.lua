-- Lua provided by RyzenAPI
-- Game: Game: AppID 738510

-- MAIN APPLICATION
addappid(738510)
-- Game: addappid(738510)

-- MAIN APP DEPOTS / PACKAGES
addappid(738511, 1, "fac212f7bd19dea324a4d6229e8eae9f576da97b9de55406c9ac3ee4c5a9e998")
addappid(738512, 1, "41c78cd0e7541cce3bc49d52cb32ff64d1d7f3628209bfe5636d99ebf6554a65")
addappid(738513, 1, "99d67dcf07a66fc39eb2ab5521e288d5934e2d78798137bd4e97ab41af9486f6")
addappid(738514, 1, "9c1d914f30766c81a5b69f2137e8038bacd5f96bc90cbf595a2b383c5d95c1d7")
