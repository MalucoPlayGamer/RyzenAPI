-- Lua provided by RyzenAPI
-- Game: Swallow The Blue: Remastered

-- MAIN APPLICATION
addappid(1509850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509851, 1, "15ebb8a9933226a5c2aae686c948727623779870a1792c7d521cea3224cb5165")
addappid(1509852, 1, "891063d0cb25f2b7035849fe3ffe4f890661b56d5cefc3b4ed8a5ff33df4a5f1")
addappid(1509853, 1, "4825ed5d2792ea3497cbb6792001af7eab73be4c87e445fd80a11fc9b15388de")
