-- Lua provided by RyzenAPI
-- Game: Shin chan: Shiro and the Coal Town

-- MAIN APPLICATION
addappid(2699820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699821, 1, "a5ab494f996fa760e6b97926e297c9e818c68a31490ffa313141852ba4ba9c03")

