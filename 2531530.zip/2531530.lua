-- Lua provided by RyzenAPI
-- Game: Sex Simulator - Yoga Girls

-- MAIN APPLICATION
addappid(2531530)
-- Game: addappid(2531530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531531, 1, "e8043450498e45b62b870b6fb3137b67446d284d87317e52aced12ec257fb540")
