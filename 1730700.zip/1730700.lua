-- Lua provided by RyzenAPI
-- Game: We Love Katamari REROLL+ Royal Reverie

-- MAIN APPLICATION
addappid(1730700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730701, 1, "e5564ff8b8f0f4ee24cd646d993821cf147553470ebbc5b293fd1f4078d81ed0")
addappid(2261972, 0, "89cd8b92001c6e27fc25f0210117faca9c2606dc26a1722ff793d9f8a6e1d110")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2261970)
addappid(2261971)
