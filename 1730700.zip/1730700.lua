-- Lua provided by RyzenAPI
-- Game: We Love Katamari REROLL+ Royal Reverie

-- MAIN APPLICATION
addappid(1730700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730701, 1, "e5564ff8b8f0f4ee24cd646d993821cf147553470ebbc5b293fd1f4078d81ed0")
addappid(2261972, 0, "89cd8b92001c6e27fc25f0210117faca9c2606dc26a1722ff793d9f8a6e1d110")

