-- Lua provided by SkyAPI 
-- Game: Forget
addappid(3045770)
addappid(3045771, 1, "01768a832299ffb55c800f59bc2c53267cc53fe79366a5e2b26278bdcf9db590")
