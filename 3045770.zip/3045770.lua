-- Lua provided by RyzenAPI
-- Game: Game: Forget

-- MAIN APPLICATION
addappid(3045770)
-- Game: addappid(3045770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3045771, 1, "01768a832299ffb55c800f59bc2c53267cc53fe79366a5e2b26278bdcf9db590")
