-- Lua provided by RyzenAPI
-- Game: Forget

-- MAIN APPLICATION
addappid(3045770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3045771, 1, "01768a832299ffb55c800f59bc2c53267cc53fe79366a5e2b26278bdcf9db590")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
