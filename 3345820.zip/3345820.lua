-- Lua provided by RyzenAPI
-- Game: Lonely Christmas

-- MAIN APPLICATION
addappid(3345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345821, 1, "96ac843a408b638988412018529acae36f9a404e63364eba0bf21c7aa3c5c8cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
