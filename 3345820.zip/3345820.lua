-- Lua provided by RyzenAPI
-- Game: Game: Lonely Christmas

-- MAIN APPLICATION
addappid(3345820)
-- Game: addappid(3345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345821, 1, "96ac843a408b638988412018529acae36f9a404e63364eba0bf21c7aa3c5c8cd")
