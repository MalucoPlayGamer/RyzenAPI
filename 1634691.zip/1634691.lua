-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Special Costume - Mitsuhide Akechi

-- MAIN APPLICATION
addappid(1634691)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634691,0,"9038a0077b038b1e33abdc254dfb45b113bd164f07f26d018a2521daef5ce881")

