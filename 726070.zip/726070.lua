-- Lua provided by RyzenAPI
-- Game: Game: Hidden Object - Sweet Home

-- MAIN APPLICATION
addappid(726070)
-- Game: addappid(726070)

-- MAIN APP DEPOTS / PACKAGES
addappid(726071, 1, "f566ca0b73b5e3ad611069ee10fd3580ec8d8ae65d8988422934fdb2ef797c15")
