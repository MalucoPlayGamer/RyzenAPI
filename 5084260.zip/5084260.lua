-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl 1: The Forest Temple

-- MAIN APP DEPOTS / PACKAGES
addappid(5084260, 1, "e0fb570b6d3468bbc6746d0595bbffb24681716f1e104e1c3e0ac915554e6cbc") -- Fireboy & Watergirl 1: The Forest Temple
addappid(5084261, 1, "62a626ded6d4bf357d49c90ee02045b154b09dfbba1b7dcc93199e864d84c8e0") -- Depot 5084261

