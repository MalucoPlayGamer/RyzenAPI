-- Lua provided by RyzenAPI
-- Game: Dr. Langeskov, The Tiger, and The Terribly Cursed Emerald: A Whirlwind Heist

-- MAIN APPLICATION
addappid(409160)

-- MAIN APP DEPOTS / PACKAGES
addappid(409161, 1, "2daec54045433a3108a807b99cc5a51af5c85c70fd1c225f1b329efe7ea867b5")
addappid(409162, 1, "62ed3de857e990296af8ade2307d8d4a98a5f5194a0b7545b844791f11901543")
