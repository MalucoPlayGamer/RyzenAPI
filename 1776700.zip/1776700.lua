-- Lua provided by RyzenAPI
-- Game: Klaus Lee - Thunderballs

-- MAIN APPLICATION
addappid(1776700)
-- Game: addappid(1776700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776702,0,"df9de1df8e5f787a01c6fa35329169f7d3af04a72892cbd7f1349f0519eadf13")
