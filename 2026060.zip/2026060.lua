-- Lua provided by RyzenAPI
-- Game: 2026060

-- MAIN APPLICATION
addappid(2026060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026062,0,"7862ecfe223bdea5b57e7eea96ff102b5174c720d85fbbfa2873fe0343b323d7")
