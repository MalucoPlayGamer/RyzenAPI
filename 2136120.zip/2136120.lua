-- Lua provided by RyzenAPI 
-- Game: 卢沟桥事变 Playtest
addappid(2136120)
addappid(2136121, 1, "d8d9d2d7406c89de6191c9d9c1ed2c1cc25874b82c19714d4fae105bec0f68cc")
