-- Lua provided by RyzenAPI
-- Game: Dice Kingdoms

-- MAIN APPLICATION
addappid(1501690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1501691, 1, "268636a939f69b38bf5092abda0a615446164b4b3111cf3fda1c10b8bcd71f75")
addappid(1501692, 1, "6b94aae687e7f8ed9f05d3837172c2e16035def300148645f75153ef4bb44919")

