-- Lua provided by RyzenAPI
-- Game: addappid(512170)

-- MAIN APPLICATION
addappid(512170)

-- MAIN APP DEPOTS / PACKAGES
addappid(512173,0,"7a67505cd8ad30ab2e814cc4c244fca6537ce845394df0fcfd59fadea423cb4d")
