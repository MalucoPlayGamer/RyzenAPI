-- Lua provided by RyzenAPI
-- Game: GAZOLINAS

-- MAIN APPLICATION
addappid(2230740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230741, 1, "f0092552ccb81062a8857640707d40f0ae417adcc4571b0bf10b171d102e986d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
