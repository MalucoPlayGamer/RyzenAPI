-- Lua provided by RyzenAPI
-- Game: 2218970

-- MAIN APPLICATION
addappid(2218970)
-- Game: addappid(2218970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218971, 1, "48988c75888be5d10947bc1742dc672de4fc08204c95d2d809398f3eb1def877")
