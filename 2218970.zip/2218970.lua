-- Lua provided by RyzenAPI 
-- Game: AppID 2218970
addappid(2218970)
addappid(2218971, 1, "48988c75888be5d10947bc1742dc672de4fc08204c95d2d809398f3eb1def877")
