-- Lua provided by RyzenAPI
-- Game: AppID 2218970

-- MAIN APPLICATION
addappid(2218970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218971, 1, "48988c75888be5d10947bc1742dc672de4fc08204c95d2d809398f3eb1def877")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
