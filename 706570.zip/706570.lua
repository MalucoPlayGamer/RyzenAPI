-- Lua provided by RyzenAPI
-- Game: addappid(706570)

-- MAIN APPLICATION
addappid(706570)

-- MAIN APP DEPOTS / PACKAGES
addappid(706571, 1, "ce505d8e9203265cb854716d93e3a61d169fae4aad3c5781192f43f4c88c498e")
