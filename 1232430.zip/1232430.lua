-- Lua provided by RyzenAPI
-- Game: Counter Fight 4

-- MAIN APPLICATION
addappid(1232430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232431, 1, "a961c961b63d38782d9935f638cb13945175aa9651a948e1e46ce181d1ef1233")

