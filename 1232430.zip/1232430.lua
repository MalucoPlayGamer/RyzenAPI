-- Lua provided by RyzenAPI
-- Game: Counter Fight 4

-- MAIN APPLICATION
addappid(1232430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232431, 1, "a961c961b63d38782d9935f638cb13945175aa9651a948e1e46ce181d1ef1233")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
