-- Lua provided by SkyAPI 
-- Game: AppID 393790
addappid(393790)
addappid(393791, 1, "06a577309e1a95141539506a8a3daa276b33fc1f3065975eb0f0fc8f4c19c698")
