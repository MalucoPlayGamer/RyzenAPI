-- Lua provided by RyzenAPI
-- Game: addappid(1258340)

-- MAIN APPLICATION
addappid(1258340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258341, 1, "4f55d7cf3aa1324d432b99de24aeef7b14ab0915df5e8b406efb0c26cb66b656")
