-- Lua provided by RyzenAPI
-- Game: KukkoroDays

-- MAIN APPLICATION
addappid(1258340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258341, 1, "4f55d7cf3aa1324d432b99de24aeef7b14ab0915df5e8b406efb0c26cb66b656")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
