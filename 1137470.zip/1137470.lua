-- Lua provided by RyzenAPI
-- Game: addappid(1137470)

-- MAIN APPLICATION
addappid(1137470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137471, 1, "c3428a87aeb0956a5af6cfac4604df1666a7c31de580474cb828ae767a46a4f8")
