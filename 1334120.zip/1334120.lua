-- Lua provided by RyzenAPI
-- Game: Goblin Rush

-- MAIN APPLICATION
addappid(1334120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(1334121, 1, "9764274841c6642805e6e7f35451e2844fd01e92a321532462309e8898d76c8f")

