-- Lua provided by RyzenAPI
-- Game: Game: Rogue Voltage

-- MAIN APPLICATION
addappid(1494560)
-- Game: addappid(1494560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494561, 1, "151ae521976c9d9f778cdb753549bb74391175b3ca916db16a91e68f21616495")
addappid(1494562, 1, "22cf4392ad655b2f0ff3ca663d7e9e4322257cded0539ef88385605c06c202f1")
