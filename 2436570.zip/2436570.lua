-- Lua provided by RyzenAPI
-- Game: 2436570

-- MAIN APPLICATION
addappid(2436570)
-- Game: addappid(2436570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436571, 1, "0c2469bb705e28eb9c832804f8e5ed1eeeb5766e7b0aaf4feb48a004616ca1d7")
