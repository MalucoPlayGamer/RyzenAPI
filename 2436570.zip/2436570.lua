-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST BUILDERS

-- MAIN APPLICATION
addappid(2436570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436571, 1, "0c2469bb705e28eb9c832804f8e5ed1eeeb5766e7b0aaf4feb48a004616ca1d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
