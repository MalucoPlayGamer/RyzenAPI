-- Lua provided by RyzenAPI
-- Game: METALLIC CHILD Demo

-- MAIN APPLICATION
addappid(1661310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661311, 1, "77dce58a40da2e370ca4950244ab919e33d35aa72fa9089f7b6ca68e5f1ebb6c")
