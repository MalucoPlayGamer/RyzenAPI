-- Lua provided by RyzenAPI
-- Game: Aegis Descent

-- MAIN APPLICATION
addappid(1251040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1251041, 1, "864f3b13d594636964267a17d5dd887c78d67993a77483cb980ae8ab198098d8")

