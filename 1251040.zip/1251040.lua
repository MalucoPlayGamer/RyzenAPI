-- Lua provided by SkyAPI 
-- Game: Aegis Descent
addappid(1251040)
addappid(1251041, 1, "864f3b13d594636964267a17d5dd887c78d67993a77483cb980ae8ab198098d8")
