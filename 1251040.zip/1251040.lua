-- Lua provided by RyzenAPI
-- Game: Game: Aegis Descent

-- MAIN APPLICATION
addappid(1251040)
-- Game: addappid(1251040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251041, 1, "864f3b13d594636964267a17d5dd887c78d67993a77483cb980ae8ab198098d8")
