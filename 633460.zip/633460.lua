-- Lua provided by RyzenAPI
-- Game: Tannenberg

-- MAIN APPLICATION
addappid(633460)
-- Game: addappid(633460)

-- MAIN APP DEPOTS / PACKAGES
addappid(633461, 1, "d2fed73e61ef6e8010a8fcb5b3b43fdb1a0a6dd096ec2ebead16a5e2192b6347")
addappid(633463, 1, "a298f7a33ff1657c704968548877d7e39222439bbfcac6075d385f5b2e3c250e")
addappid(633464, 1, "c6e214edbe5115cbebd7b1b3f1048ade887eba53cfcbf36dceb39e73bca75385")
addappid(633465, 1, "0adc4e61e395786186e92348cf121f323654ff1ead5b36a3ce84d25da786ce65")
addappid(633469, 1, "3d4ebc7b0f36cdf41851db34a11ec3bd3853584d72a547710e14479a6ed700b5")
addappid(746960, 0, "f5cf5ad8f388f92139f7564802b6beb3d7f8c3af32fa85f6c7be597b28d57cea")
