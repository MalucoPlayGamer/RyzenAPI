-- Lua provided by RyzenAPI
-- Game: Game: Heaven's Door

-- MAIN APPLICATION
addappid(3263380)
-- Game: addappid(3263380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263381, 1, "8c9c3d0d1b750dd8f8ed748b1ef9ee83ffea752d6adcfe2cf1663e2d1a03ae27")
