-- Lua provided by RyzenAPI
-- Game: AppID 3260610

-- MAIN APPLICATION
addappid(3260610)
-- Game: addappid(3260610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260611, 1, "6abc4170d33dc43998f7cbb8e16ab1596dc89e2e3b8fe54015e0ffa121aaf276")
