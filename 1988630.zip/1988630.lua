-- Lua provided by RyzenAPI
-- Game: 1988630

-- MAIN APPLICATION
addappid(1988630)
-- Game: addappid(1988630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988631, 1, "1beccc30d999b671d819a99155d3312045bd93f7141a7da96aec1e58b16161ee")
