-- Lua provided by RyzenAPI
-- Game: 2752230

-- MAIN APPLICATION
addappid(2752230)
-- Game: addappid(2752230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752231, 1, "f6cea4895703e980892525e3c89fd3a2c3d62ab2c5a7024abc9f0bca586e7d01")
