-- Lua provided by RyzenAPI
-- Game: addappid(2463110)

-- MAIN APPLICATION
addappid(2463110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463111, 1, "bea3aa5e7f238edb58939d95d8558515f12fd9603cf401978fb0a2419b7cff79")
