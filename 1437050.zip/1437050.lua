-- Lua provided by RyzenAPI
-- Game: Game: EBOLA 2

-- MAIN APPLICATION
addappid(1437050)
-- Game: addappid(1437050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437051, 1, "1b7dd8ff13492669f05d3f345b97900b6bb5499852af3806a06bb7c6e16c0944")
