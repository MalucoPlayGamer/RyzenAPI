-- Lua provided by RyzenAPI
-- Game: EBOLA 2

-- MAIN APPLICATION
addappid(1437050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437051, 1, "1b7dd8ff13492669f05d3f345b97900b6bb5499852af3806a06bb7c6e16c0944")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
