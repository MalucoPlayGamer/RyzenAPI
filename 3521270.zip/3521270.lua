-- Lua provided by RyzenAPI
-- Game: Phoenix's Faye

-- MAIN APPLICATION
addappid(3521270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3521271,0,"e5771a6562a62cb01d42ca73f05eebfe7bb3aaf42a1f79fa13f5496f9bab7011")

