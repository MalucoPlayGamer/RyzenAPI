-- Lua provided by RyzenAPI
-- Game: Game: Grand Ages: Medieval

-- MAIN APPLICATION
addappid(310470)
addappid(386830)
addappid(386831)
addappid(386832)
-- Game: addappid(310470)

-- MAIN APP DEPOTS / PACKAGES
addappid(310471, 1, "3374fa8dbdcf3164b021773f7b6bdff8d60cabef158dce67a7749dc46799b2aa")
addappid(310474, 1, "02a7e151a094b06a09067cf884e3f46109b9d09a3067e175112252ef2a7b2208")
addappid(310475, 1, "e30582fc1f5cf863a18ce736da6671eb1fe3a48fdbfc75a1b9e74a1964a27d40")
addappid(310478, 1, "b156c3ecd5b721eecaf9f8be11b0bfc99c69b8b28fc00f0cb0feaf1c36647df1")
addappid(310479, 1, "6827d443e6fc794dd8df2e2987859db0a992b20352b181a53792286c67c9c873")
addappid(310481, 1, "220ff0b4cb52bc35d6ee928f121e4e9634f5ea327a2802424da2e93c59f66864")
addappid(310487, 1, "e9b7931be98555e7fa8bdc5529ae326026d94ff98da6278f3799ae618fd83100")
