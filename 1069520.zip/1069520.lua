-- Lua provided by RyzenAPI
-- Game: Game: Green Field Silver Tree 绿野白银树

-- MAIN APPLICATION
addappid(1069520)
-- Game: addappid(1069520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069521, 1, "65978dd584ca0e5bb52fab22bf604ddd265e4291872e37875c8741ca55dd0ef4")
