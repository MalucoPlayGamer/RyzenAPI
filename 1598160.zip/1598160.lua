-- Lua provided by RyzenAPI
-- Game: Bloodwash

-- MAIN APPLICATION
addappid(1598160)
-- Game: addappid(1598160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598161, 1, "c9cfbd36608dee03c69b8351d7356dc95f6bd912dfa2e00faf1c94a00ac775ee")
