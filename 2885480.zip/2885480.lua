-- Lua provided by RyzenAPI
-- Game: BattleCap

-- MAIN APPLICATION
addappid(2885480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885481, 1, "bb46f868623b5fb4d73fbbf157ce03651c335fc2fecc872628754a664a1ad0ec")

