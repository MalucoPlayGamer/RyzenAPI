-- Lua provided by RyzenAPI
-- Game: addappid(3616940)

-- MAIN APPLICATION
addappid(3616940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616941, 1, "584004bc56b9b694268440ad9b48e287e7c4a88f9f30eca4f9ffa19e3f21eefa")
