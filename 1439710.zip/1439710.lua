-- Lua provided by RyzenAPI 
-- Game: Theo's World
addappid(1439710)
addappid(1439711, 1, "71f52ed408ad0b0ae33edfc1ba1e2494ed90e5510aac802c59004e66158f5f0c")
