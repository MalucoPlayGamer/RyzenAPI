-- Lua provided by RyzenAPI
-- Game: Theo's World

-- MAIN APPLICATION
addappid(1439710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439711, 1, "71f52ed408ad0b0ae33edfc1ba1e2494ed90e5510aac802c59004e66158f5f0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
