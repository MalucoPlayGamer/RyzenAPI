-- Lua provided by RyzenAPI
-- Game: The last Baron's stunt (Anime)

-- MAIN APPLICATION
addappid(801900)

-- MAIN APP DEPOTS / PACKAGES
addappid(801901, 1, "d3f98ee20732cdcdb32e0b025053bf3779089054ba85c4e5a56fcba3c2d73c63")

