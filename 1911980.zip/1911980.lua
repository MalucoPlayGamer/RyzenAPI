-- Lua provided by RyzenAPI
-- Game: Dissonance

-- MAIN APPLICATION
addappid(1911980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911981, 1, "5cf28eb2ccb09a5cf66515a55803d2b120d5ba84b7594d4dd1ea0673afd80a14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
