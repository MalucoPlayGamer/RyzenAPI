-- Lua provided by RyzenAPI
-- Game: 1911980

-- MAIN APPLICATION
addappid(1911980)
-- Game: addappid(1911980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911981, 1, "5cf28eb2ccb09a5cf66515a55803d2b120d5ba84b7594d4dd1ea0673afd80a14")
