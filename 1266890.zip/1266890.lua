-- Lua provided by RyzenAPI
-- Game: AppID 1266890

-- MAIN APPLICATION
addappid(1266890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1266891, 1, "7b89eb28b0c51144d1a155fcef485476354332cff4e8a6bbc9aa4297b260e041")

