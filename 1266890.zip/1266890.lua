-- Lua provided by RyzenAPI
-- Game: AppID 1266890

-- MAIN APPLICATION
addappid(1266890)
-- Game: addappid(1266890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266891, 1, "7b89eb28b0c51144d1a155fcef485476354332cff4e8a6bbc9aa4297b260e041")
