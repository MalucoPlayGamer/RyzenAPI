-- Lua provided by SkyAPI 
-- Game: Archery Land
addappid(1808250)
addappid(1808251, 1, "a4db5403221f5d0e55f4cad914395d6d924e7ef0a8dc9d19d067b54d7fd7e75e")
