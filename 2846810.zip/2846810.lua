-- Lua provided by RyzenAPI
-- Game: addappid(2846810)

-- MAIN APPLICATION
addappid(2846810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846811, 1, "3ebb26b21d3d8376fc75895e8d6d3e13b002079613a8c6ca22c9d40948bd71d8")
