-- Lua provided by RyzenAPI
-- Game: 2505

-- MAIN APPLICATION
addappid(2501)
addappid(2505)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505,0,"7440326180cbeef561091ebc89c05b1e13f66cde208238ecff154e5610e92b3b")
addappid(2507,0,"97cd216dacff4a4a8bc2555f01f5596eb3a084e708071e881863f55cdef026f7")
