-- Lua provided by RyzenAPI
-- Game: 3001180

-- MAIN APPLICATION
addappid(3001180)
-- Game: addappid(3001180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001181, 1, "e31b212b20fce759ea1fccaf6235fd76a3facc1c69e5afe2664b617bf334fa8d")
addappid(3001182, 1, "3809e0c567f4826f7434640d88b9f8dc574fcce9890e57ace05e93c72d7e0a92")
