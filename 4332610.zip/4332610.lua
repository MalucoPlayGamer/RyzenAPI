-- Lua provided by RyzenAPI
-- Game: Gripless: Drift Valley

-- MAIN APPLICATION
addappid(4332610)

-- MAIN APP DEPOTS / PACKAGES
addappid(4332611,0,"42ac3e64aa36a24a1dd95df2822b222a403eabc74cb2cc5ba7719c189ca53689")

