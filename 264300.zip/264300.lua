-- Lua provided by RyzenAPI
-- Game: Game: Guns n Zombies

-- MAIN APPLICATION
addappid(264300)
addappid(362110)
-- Game: addappid(264300)

-- MAIN APP DEPOTS / PACKAGES
addappid(264301, 1, "64fc486e3c325b27114b2a9579477c0004f255687dc9bbb2bc1d8e81381465b4")
addappid(264302, 1, "18aa8a4e9ba36c6e8e43cad7c418823de61094132e37ce4265f15dc372d18120")
