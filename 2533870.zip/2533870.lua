-- Lua provided by RyzenAPI
-- Game: The Book Of Hiro

-- MAIN APPLICATION
addappid(2533870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533871, 1, "e2098c5927aff6489e37ae3c6dfeace82dcbf589b2708b642e4295582dabe87c")

