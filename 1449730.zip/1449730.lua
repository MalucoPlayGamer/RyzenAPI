-- Lua provided by SkyAPI 
-- Game: AppID 1449730
addappid(1449730)
addappid(1449731, 1, "73e7da8f32f6556bdf0a00f35242328b927787b28ef80d4b8aa30fa8f32f22fd")
