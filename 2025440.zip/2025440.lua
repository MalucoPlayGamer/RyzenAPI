-- Lua provided by RyzenAPI
-- Game: addappid(2025440)

-- MAIN APPLICATION
addappid(2025440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025441, 1, "d1ae0ecbb70033c25b20e2dfc6cece3c7ddaeb057386d638f2afc04b80821f11")
