-- Lua provided by RyzenAPI
-- Game: Game: AppID 1156960

-- MAIN APPLICATION
addappid(1156960)
-- Game: addappid(1156960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156961, 1, "ce628a726ab30f7197448b018a4bd0997edb442cb1f01157982069b303eb8953")
