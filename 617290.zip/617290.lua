-- Lua provided by RyzenAPI
-- Game: Remnant: From the Ashes

-- MAIN APPLICATION
addappid(617290)
addappid(1074850)
addappid(1120500)
addappid(1147300)
addappid(1245150)
addappid(1344680)

-- MAIN APP DEPOTS / PACKAGES
addappid(617291,0,"a44b1e94ad062cd59177b19472b97fbf016a18c93db2c7ab52857728012fa6ce")

