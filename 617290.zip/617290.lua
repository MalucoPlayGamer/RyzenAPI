-- Lua provided by RyzenAPI
-- Game: addappid(617290)

-- MAIN APPLICATION
addappid(617290)

-- MAIN APP DEPOTS / PACKAGES
addappid(617291, 1, "a44b1e94ad062cd59177b19472b97fbf016a18c93db2c7ab52857728012fa6ce")
