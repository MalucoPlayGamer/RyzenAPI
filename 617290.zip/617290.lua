-- Lua provided by RyzenAPI
-- Game: Remnant: From the Ashes

-- MAIN APPLICATION
addappid(617290)
addappid(1074850)
addappid(1120500)
addappid(1147300)
addappid(1245150)
addappid(1344680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(617291,0,"a44b1e94ad062cd59177b19472b97fbf016a18c93db2c7ab52857728012fa6ce")

