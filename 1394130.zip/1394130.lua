-- Lua provided by RyzenAPI
-- Game: 1394130

-- MAIN APPLICATION
addappid(1394130)
-- Game: addappid(1394130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394131, 1, "97b30b8c5182375819261f6d3d85f9a12a21f0662ecf19d66e1a108f7ae5d2c4")
