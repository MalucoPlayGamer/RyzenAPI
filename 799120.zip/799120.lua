-- Lua provided by RyzenAPI
-- Game: ZombieHunt

-- MAIN APPLICATION
addappid(799120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(799121, 1, "a801a9a07583aa39f7efdd66c2635c0537a6d50980be50f3dcf23856ae2546f9")

