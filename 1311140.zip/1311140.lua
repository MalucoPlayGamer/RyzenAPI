-- Lua provided by RyzenAPI 
-- Game: AppID 1311140
addappid(1311140)
addappid(1311141, 1, "09bf7553683c23b5d8de12439b25aff11c2686a86727b4ce8d4f2c648ffbe05b")
