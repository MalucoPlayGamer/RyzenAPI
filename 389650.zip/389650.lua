-- Lua provided by RyzenAPI
-- Game: Stardust Galaxy Warriors: Stellar Climax

-- MAIN APPLICATION
addappid(389650)
addappid(418080)
-- Game: addappid(389650)

-- MAIN APP DEPOTS / PACKAGES
addappid(389651, 1, "1a95f7089a0b54d906fda4461a28ebb635fd9a2b9c1a9b0ad2e97cdda34826a4")
addappid(860540, 0, "499cff106925c027657394f3ffb35b408ddad25bd05cf975d438bc6831210c80")
