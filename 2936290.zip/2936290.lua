-- 2936290's Lua and Manifest Created by Hubcap Manifest
-- The Life and Suffering of Prince Jerian
-- Created: July 20, 2026 at 10:52:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2936290, 1, "e947e1ef661d9d2a3418153d07b6759ed275c5548f07184782bf134fb7064925") -- The Life and Suffering of Prince Jerian
-- MAIN APP DEPOTS
addappid(2936291, 1, "d37e9bb5498f6c1def03fc192acb979995b0d76c9eacaeb410cc7fc6268a631a") -- Depot 2936291
setManifestid(2936291, "8362624900479149727", 6322850631)
-- DLCS WITH DEDICATED DEPOTS
-- The Life and Suffering of Prince Jerian  Official Artbook  Wallpapers (AppID: 4892150)
addappid(4892150)
addappid(4892150, 1, "8bef97936e1e31c62285e827260a7a3a460a8933c8c5234a5886c44d2911ef3f") -- The Life and Suffering of Prince Jerian  Official Artbook  Wallpapers - Depot 4892150
setManifestid(4892150, "6384930306906564001", 355847588)
-- The Life and Suffering of Prince Jerian  Digital World Map (AppID: 4892160)
addappid(4892160)
addappid(4892160, 1, "7f3a1bf08247691dabd6e8140ffec1bb53983c37ed297b51b6208ea385a6eeba") -- The Life and Suffering of Prince Jerian  Digital World Map - Depot 4892160
setManifestid(4892160, "9022251816851934585", 54020712)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4892151) -- Depot 4892151 (empty depot)
-- addappid(4892161) -- Depot 4892161 (empty depot)