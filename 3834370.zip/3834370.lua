-- Lua provided by RyzenAPI
-- Game: 3834370

-- MAIN APPLICATION
addappid(3834370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3834374,0,"f2bde7f3d834d837705e5bdb6eeecd1db83b8a2b6183b52bf650000c476f8aab")
