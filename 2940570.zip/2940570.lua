-- Lua provided by RyzenAPI
-- Game: Game: Hentaimon Demo

-- MAIN APPLICATION
addappid(2940570)
-- Game: addappid(2940570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940571, 1, "bb940ea49b5deb526898d63eb00070a4a5f5bb12177eeec53ac7f3e33bebcc9b")
