-- Lua provided by RyzenAPI
-- Game: Game: Super Turbo Racing

-- MAIN APPLICATION
addappid(1941390)
-- Game: addappid(1941390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941391, 1, "b6e9438a1481481571f7ce495342b485e881e28b476ba65b9d5a7c0f6f7929c3")
