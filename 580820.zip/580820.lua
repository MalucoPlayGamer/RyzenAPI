-- Lua provided by RyzenAPI
-- Game: Robot Soccer Challenge

-- MAIN APPLICATION
addappid(580820)

-- MAIN APP DEPOTS / PACKAGES
addappid(580821,0,"c7c80fc0d8ee7c6590460c5421ca69ca8d6d7ce3f79ed8242a26fbbd11440274")

