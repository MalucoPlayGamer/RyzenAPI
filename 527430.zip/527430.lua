-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Inquisitor - Martyr

-- MAIN APPLICATION
addappid(527430)
addappid(722130)
addappid(808140)
addappid(808150)
addappid(938400)
addappid(939050)
addappid(939051)
addappid(945830)
addappid(945831)
addappid(945832)
addappid(995650)
addappid(995651)
addappid(995652)
addappid(995653)
addappid(995654)
addappid(995670)
addappid(998500)
addappid(1028890)
addappid(1028891)
addappid(1028892)
addappid(1028893)
addappid(1028894)
addappid(1028895)
addappid(1351990)
addappid(2138210)
addappid(3003800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(527431, 1, "a22368d0a73cc74b4ba8445b12620a5f2662822d0fec23a38cbd5afedfe3d44d")
addappid(527432, 1, "e72027c8b7ab04a562b16333a23afd70dd1b1d6151dcadcabe70b7d5b886b34b")

