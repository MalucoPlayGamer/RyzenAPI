-- Lua provided by RyzenAPI
-- Game: 906750

-- MAIN APPLICATION
addappid(906750)
-- Game: addappid(906750)

-- MAIN APP DEPOTS / PACKAGES
addappid(906751, 1, "cf98a9a76f84c0110f2680d6990d45b813600a9f2faba337e6c5f4770d5a6029")
