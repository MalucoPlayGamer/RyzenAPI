-- Lua provided by SkyAPI 
-- Game: AppID 906750
addappid(906750)
addappid(906751, 1, "cf98a9a76f84c0110f2680d6990d45b813600a9f2faba337e6c5f4770d5a6029")
