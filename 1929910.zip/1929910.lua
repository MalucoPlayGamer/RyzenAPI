-- Lua provided by RyzenAPI
-- Game: AppID 1929910

-- MAIN APPLICATION
addappid(1929910)
addappid(1929940)
addappid(1929941)
addappid(1929942)
addappid(1929943)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929911, 1, "3059f14fce810d4f0ddbf256a9765e2e6778fae66eb70d539e18837850683929")
