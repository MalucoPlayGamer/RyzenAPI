-- Lua provided by RyzenAPI
-- Game: 2167220

-- MAIN APPLICATION
addappid(2167220)
addappid(2888760)
-- Game: addappid(2167220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167221, 1, "faf1dfb3fc4e6407ad915cba2f3ba0e484ef0e78cc8c780c928ae74ba2b34bb2")
