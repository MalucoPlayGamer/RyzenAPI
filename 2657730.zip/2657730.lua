-- Lua provided by RyzenAPI 
-- Game: ELDORANTE
addappid(2657730)
addappid(2657731, 1, "b977def85b5b15d27cf0da82a0168e6fb4aae33b47537b680f29882a3bf05038")
addappid(2657732, 1, "0825babdd4f657359e30a1b20fc2f7fd84d5f3068967aae50b497f6a42043abf")
addappid(2657733, 1, "f5eb7176d5cd8fd7760fd479e872b2fea1306b7d4c78fcf150ac315a64e39571")
