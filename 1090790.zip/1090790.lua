-- Lua provided by RyzenAPI
-- Game: Magicolors

-- MAIN APPLICATION
addappid(1090790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090791, 1, "4cb492ab1b99f38119b4b4d8cb33d17c22501cab5afda142b763069e5796fe5f")
addappid(1090792, 1, "1c884aba6ae3c71b7ce6400174caf3b5117803cf0409d2c1a0295c325a07b63c")

