-- Lua provided by RyzenAPI
-- Game: Monster Crawl: Warrior

-- MAIN APPLICATION
addappid(2569480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569481, 1, "b4555e4d8160f4120241d396c2fe1f3a278f6e939aa2976d26728821fc01be18")
