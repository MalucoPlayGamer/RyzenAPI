-- Lua provided by RyzenAPI
-- Game: Game: Sexy Heroine!

-- MAIN APPLICATION
addappid(1027900)
-- Game: addappid(1027900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027901, 1, "a375c8e5d6c2a6102050156c4885e46d2f95c0b87dc31cd91050a722b9ce59f3")
addappid(1075870, 0, "e000d7d924a7df00f0beb062df59af7ab8c800f534816ce184062684b55d9687")
addappid(1076380, 0, "ede1c935dd1f424fdb8be49ecbea4e12d486fb2425da399c7dc91e393fae7332")
