-- Lua provided by RyzenAPI
-- Game: addappid(2125720)

-- MAIN APPLICATION
addappid(2125720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125721, 1, "e232975244226bab73718db5b323de4755de07aa9de9a136137b4984cfd841ed")
