-- Lua provided by RyzenAPI
-- Game: RX Racing 2022 Pro

-- MAIN APPLICATION
addappid(2125720)
-- Game: addappid(2125720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125721, 1, "e232975244226bab73718db5b323de4755de07aa9de9a136137b4984cfd841ed")
