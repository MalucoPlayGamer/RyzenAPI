-- Lua provided by RyzenAPI
-- Game: RX Racing 2022 Pro

-- MAIN APPLICATION
addappid(2125720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2125721, 1, "e232975244226bab73718db5b323de4755de07aa9de9a136137b4984cfd841ed")

