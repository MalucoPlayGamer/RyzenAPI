-- Lua provided by RyzenAPI
-- Game: Object "Cleaning"

-- MAIN APPLICATION
addappid(781880)

-- MAIN APP DEPOTS / PACKAGES
addappid(781881, 1, "1df094e4016302593fc7962ad4fee3a0545bf8552c06263f00085dffd6df43df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
