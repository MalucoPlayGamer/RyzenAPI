-- Lua provided by RyzenAPI
-- Game: Object "Cleaning"

-- MAIN APPLICATION
addappid(781880)

-- MAIN APP DEPOTS / PACKAGES
addappid(781881, 1, "1df094e4016302593fc7962ad4fee3a0545bf8552c06263f00085dffd6df43df")

