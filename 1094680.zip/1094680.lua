-- Lua provided by RyzenAPI
-- Game: addappid(1094680)

-- MAIN APPLICATION
addappid(1094680)
addappid(1094681)
addappid(1094683)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094682,0,"0903ff5ced2d7102f189ff35b194f1ab281d8a13f71dd593844e19573742d4e3")
