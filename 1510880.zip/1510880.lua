-- Lua provided by RyzenAPI
-- Game: addappid(1510880)

-- MAIN APPLICATION
addappid(1510880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510881, 1, "89d627578a7e0b164ec46b2c8f5817fabc9c48dc379cb1255c308675aa83d7cb")
