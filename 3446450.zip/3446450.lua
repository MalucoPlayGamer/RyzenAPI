-- Lua provided by RyzenAPI
-- Game: Finding Cats In White Sand Village

-- MAIN APPLICATION
addappid(3446450)
-- Game: addappid(3446450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446451, 1, "c1334a0bb87be9883c794002143cea457e75e6902be7d7a886c7ca834192cf4d")
