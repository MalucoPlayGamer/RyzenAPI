-- Lua provided by RyzenAPI
-- Game: Sinister Entity

-- MAIN APPLICATION
addappid(2164870)
-- Game: addappid(2164870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164871, 1, "ab135a5efa4bba3aba6143e287b5efbe4d778a1412da234078e9bdff495c68cd")
