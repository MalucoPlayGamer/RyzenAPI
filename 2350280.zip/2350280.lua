-- Lua provided by RyzenAPI
-- Game: Game: Monster Jam™ Showdown

-- MAIN APPLICATION
addappid(2350280)
-- Game: addappid(2350280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350281, 1, "371384027e36f2fb56e0c76c2e825230dfd7ca8f2bdd02aac76fb5ea864f36b7")
