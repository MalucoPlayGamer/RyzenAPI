-- Lua provided by RyzenAPI
-- Game: Monster Jam™ Showdown

-- MAIN APPLICATION
addappid(2350280)
addappid(2834090)
addappid(2912210)
addappid(2912220)
addappid(2912230)
addappid(2912240)
addappid(2912250)
addappid(2912260)
addappid(2912270)
addappid(2912280)
addappid(2912290)
addappid(2912300)
addappid(2912310)
addappid(2912320)
addappid(3003500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2350281, 1, "371384027e36f2fb56e0c76c2e825230dfd7ca8f2bdd02aac76fb5ea864f36b7")

