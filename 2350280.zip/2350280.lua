-- Lua provided by RyzenAPI 
-- Game: Monster Jam™ Showdown
addappid(2350280)
addappid(2350281, 1, "371384027e36f2fb56e0c76c2e825230dfd7ca8f2bdd02aac76fb5ea864f36b7")
