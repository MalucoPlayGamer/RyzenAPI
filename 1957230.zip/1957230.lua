-- Lua provided by RyzenAPI
-- Game: Employee of The Month

-- MAIN APPLICATION
addappid(1957230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957231, 1, "d84140c86f52b67c3f7f8efd55f5ee04d4056f19971d89bcd9498ac71912da20")

