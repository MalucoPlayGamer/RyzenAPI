-- Lua provided by RyzenAPI
-- Game: 东方剑姬在西方旅行的故事

-- MAIN APPLICATION
addappid(1455530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455531, 1, "364933426ecc9d62f9259b83ac07b1255e6ec5cc9dabaac6f764954369d6d2f1")
