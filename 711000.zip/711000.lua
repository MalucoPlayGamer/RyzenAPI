-- Lua provided by RyzenAPI
-- Game: Ancient Tower

-- MAIN APPLICATION
addappid(711000)

-- MAIN APP DEPOTS / PACKAGES
addappid(711001,0,"09ed263d54510fb1ab9310f4d76e14a66e5f44dc620cc75a6dd88143e10dee3e")

