-- Lua provided by RyzenAPI
-- Game: Escape Dungeon 2

-- MAIN APPLICATION
addappid(1309000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309002,0,"9ab5101386d9b48f2408837481455885a9d1ec8c7fd240350f34ac3f4b3e8c8f")
addappid(1309003,0,"75d63b755096ea98d0d4322ec4797bbe6da142b52fcb713de69b0199efb03f43")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4045770)
