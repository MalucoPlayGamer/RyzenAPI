-- Lua provided by SkyAPI 
-- Game: AppID 884930
addappid(884930)
addappid(884931, 1, "2c21283b21043d21d5134c92993d5b7dcaff37a16182d6b3eb22bb0391513a83")
