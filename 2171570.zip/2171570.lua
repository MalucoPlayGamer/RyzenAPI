-- Lua provided by RyzenAPI
-- Game: Whisker Waters

-- MAIN APPLICATION
addappid(2171570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2171571, 1, "2f2457faed0238b9bb586e85cb020c656766be6d89dc54962326fe7c261cf881")

