-- Lua provided by RyzenAPI
-- Game: addappid(2171570)

-- MAIN APPLICATION
addappid(2171570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171571, 1, "2f2457faed0238b9bb586e85cb020c656766be6d89dc54962326fe7c261cf881")
