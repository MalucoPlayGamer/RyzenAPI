-- Lua provided by RyzenAPI
-- Game: Stary

-- MAIN APPLICATION
addappid(995280)

-- MAIN APP DEPOTS / PACKAGES
addappid(995281, 1, "d8f42f086786796576bfcb0225d6fcfec7181e7d97c77298bccbc387e7a5347c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
