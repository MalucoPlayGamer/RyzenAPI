-- Lua provided by RyzenAPI
-- Game: Stary

-- MAIN APPLICATION
addappid(995280)

-- MAIN APP DEPOTS / PACKAGES
addappid(995281, 1, "d8f42f086786796576bfcb0225d6fcfec7181e7d97c77298bccbc387e7a5347c")

