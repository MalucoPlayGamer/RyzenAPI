-- Lua provided by RyzenAPI
-- Game: 2349230

-- MAIN APPLICATION
addappid(2349230)
-- Game: addappid(2349230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349231, 1, "60ec79c6370cf2a879024de719e493450ed710bca36cb9d4277f7ee76d238435")
