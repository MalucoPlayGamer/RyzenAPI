-- Lua provided by SkyAPI 
-- Game: AppID 3021940
addappid(3021940)
addappid(3021941, 1, "a43e36cb3a19b7dfa63d0fd047e1d012dc75fde4bcce0205e1ec0b4c03a65576")
