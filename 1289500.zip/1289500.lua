-- Lua provided by RyzenAPI
-- Game: AppID 1289500

-- MAIN APPLICATION
addappid(1289500)
-- Game: addappid(1289500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289501, 1, "ae4f4c0bef22a50112286cb98b06274f6c1474b6a16dbf0b548921e62a29807f")
