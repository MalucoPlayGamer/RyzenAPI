-- Lua provided by RyzenAPI
-- Game: Color-A-Cube

-- MAIN APPLICATION
addappid(3366710)
