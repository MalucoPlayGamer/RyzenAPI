-- Lua provided by RyzenAPI
-- Game: Color-A-Cube

-- MAIN APPLICATION
addappid(3366710)
addappid(3374400)
addappid(3587170)
addappid(3587180)
addappid(3587330)
addappid(3587340)
addappid(3587350)
addappid(3587420)
addappid(3739430)
addappid(3792050)
addappid(3855900)
addappid(3886570)
addappid(3921470)
addappid(3989620)
addappid(4065150)
addappid(4124560)
addappid(4246950)
addappid(4348300)
addappid(4434450)
addappid(4498950)
addappid(4629910)
addappid(4809630)
addappid(4882150)
addappid(5020010)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5124190)
