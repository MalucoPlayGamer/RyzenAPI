-- Lua provided by RyzenAPI
-- Game: addappid(3456130)

-- MAIN APPLICATION
addappid(3456130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456130,0,"9f3cedf16a25cc4b5be38da3b8c94f55870677c5a669bf970732bce3ee0c24da")
