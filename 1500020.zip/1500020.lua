-- Lua provided by RyzenAPI
-- Game: this game waiting to be remove

-- MAIN APPLICATION
addappid(1500020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500021, 1, "b8c828465fda697ac5d1814a65da24560cad67e4e40629495b439300c1560095")
addappid(1508600, 0, "a8f57f4498adabec5e093e2a3f831a3d9cd1bc186c5aa5d3f0280fc81aa87436")
addappid(1508610, 0, "d5c75aeb7ffc2d6c65727ee6d33ed41ec9ee2a27c2eaf6e997574f94cb93b580")

