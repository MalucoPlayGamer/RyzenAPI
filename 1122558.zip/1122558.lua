-- Lua provided by RyzenAPI
-- Game: 1122558

-- MAIN APPLICATION
addappid(1122558)
-- Game: addappid(1122558)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122558,0,"f87f39d532ec19c41a703aa4e317e5057ea372b8df268b68df8e39a07767e9ab")
