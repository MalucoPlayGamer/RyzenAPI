-- Lua provided by RyzenAPI
-- Game: AppID 337650

-- MAIN APPLICATION
addappid(337650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(337651, 1, "d2a4389a0ac59e6ef48fccec1adeb2281c096f7a8476bbf7c93edb63056d850b")

