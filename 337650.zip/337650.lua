-- Lua provided by RyzenAPI
-- Game: AppID 337650

-- MAIN APPLICATION
addappid(337650)

-- MAIN APP DEPOTS / PACKAGES
addappid(337651, 1, "d2a4389a0ac59e6ef48fccec1adeb2281c096f7a8476bbf7c93edb63056d850b")

