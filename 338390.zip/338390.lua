-- Lua provided by RyzenAPI
-- Game: The Technomancer

-- MAIN APPLICATION
addappid(338390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(338391, 1, "f9e1ed02b7c368ec7626fe4e0b722d4dbb78f2c4c5285e329085b4b073509464")
