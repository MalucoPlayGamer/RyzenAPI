-- Lua provided by RyzenAPI
-- Game: addappid(1759570)

-- MAIN APPLICATION
addappid(1759570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759571, 1, "39bf22d23b499f9b04bf96c384f2d893603f2550f03dc4254e2a60e00d5cc239")
