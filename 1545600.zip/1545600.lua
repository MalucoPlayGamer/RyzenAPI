-- Lua provided by RyzenAPI
-- Game: Grapple Hoops

-- MAIN APPLICATION
addappid(1545600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545601, 1, "a17bb9228b329cf1ee98fdfa15cd9dfa6dbb68abf41cd3070ef1f66ad9dd112a")

