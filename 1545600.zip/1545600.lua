-- Lua provided by RyzenAPI
-- Game: Grapple Hoops

-- MAIN APPLICATION
addappid(1545600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1545601, 1, "a17bb9228b329cf1ee98fdfa15cd9dfa6dbb68abf41cd3070ef1f66ad9dd112a")

