-- Lua provided by RyzenAPI
-- Game: addappid(1689190)

-- MAIN APPLICATION
addappid(1689190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689191, 1, "e1f0b66b4403b346f21d020b59e0fd6cd9f6d10b3dae11209ca87ab945286680")
