-- Lua provided by RyzenAPI
-- Game: MECH PUNK

-- MAIN APPLICATION
addappid(1882550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882553,0,"8fbbcef2b277ed646c65281ed33d9d08ed48d70308e7c1efed4ba53e6e15ab50")

