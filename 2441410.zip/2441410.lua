-- Lua provided by RyzenAPI
-- Game: addappid(2441410)

-- MAIN APPLICATION
addappid(2441410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441410,0,"eb4c48ec4b170f19303d075aee724e8518d13ec87e7d62f4f46e508aab04fc61")
