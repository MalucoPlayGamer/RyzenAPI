-- Lua provided by RyzenAPI
-- Game: 595500

-- MAIN APPLICATION
addappid(595500)
-- Game: addappid(595500)

-- MAIN APP DEPOTS / PACKAGES
addappid(595501, 1, "86a2e170a65b000d81b0d33f7f503c61db1233abdf1725b9abbd3dc216e2d77b")
