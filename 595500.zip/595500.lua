-- Lua provided by SkyAPI 
-- Game: Freedom Planet 2
addappid(595500)
addappid(595501, 1, "86a2e170a65b000d81b0d33f7f503c61db1233abdf1725b9abbd3dc216e2d77b")
