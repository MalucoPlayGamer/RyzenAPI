-- Lua provided by RyzenAPI
-- Game: Terrinoth®: Heroes of Descent

-- MAIN APPLICATION
addappid(3929630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3929631,0,"cc5ae73b4401e1efe532ade9c7f067050c936a8293d7c3db6ddcee3908d667d4")

