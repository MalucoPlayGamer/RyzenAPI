-- Lua provided by RyzenAPI
-- Game: addappid(473640)

-- MAIN APPLICATION
addappid(473640)
addappid(492030)

-- MAIN APP DEPOTS / PACKAGES
addappid(473641, 1, "38d97f26161c18f27e555f23bde6104186808a4eb90deb46efeae26a1f9faf57")
