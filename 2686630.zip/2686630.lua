-- Lua provided by RyzenAPI
-- Game: Voyagers of Nera

-- MAIN APPLICATION
addappid(2686630)
addappid(3955500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686631, 1, "bb444f58dde496878d4698ea44922d7072a6c466c8b4ef9416321f4efe9ed7fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4624260)
