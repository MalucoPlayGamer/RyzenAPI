-- Lua provided by RyzenAPI
-- Game: addappid(2686630)

-- MAIN APPLICATION
addappid(2686630)
addappid(3955500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686631, 1, "bb444f58dde496878d4698ea44922d7072a6c466c8b4ef9416321f4efe9ed7fa")
