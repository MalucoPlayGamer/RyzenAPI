-- Lua provided by RyzenAPI
-- Game: Game: AppID 1557070

-- MAIN APPLICATION
addappid(1557070)
addappid(1619950)
-- Game: addappid(1557070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557071, 1, "72b46528ebc884762090437f46c16c70fef95d3c3e18113fc3ceba4c55d949da")
