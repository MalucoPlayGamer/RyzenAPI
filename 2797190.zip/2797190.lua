-- Lua provided by RyzenAPI
-- Game: 几何狂袭 Playtest

-- MAIN APPLICATION
addappid(2797190)
-- Game: addappid(2797190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797191, 1, "0c1fd6394e9d1b03e4877f342704fbae577526de24b893240aa35c7021c54cd3")
