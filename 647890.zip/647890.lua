-- Lua provided by RyzenAPI
-- Game: The Agency of Anomalies: The Last Performance Collector's Edition

-- MAIN APPLICATION
addappid(647890)

-- MAIN APP DEPOTS / PACKAGES
addappid(647891, 1, "8cdfce4a1d1f4368cebdf52b7c9adc32b9b3143c46bbaca0d8de07d55c4849ea")

