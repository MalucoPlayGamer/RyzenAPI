-- Lua provided by RyzenAPI
-- Game: addappid(650780)

-- MAIN APPLICATION
addappid(650780)

-- MAIN APP DEPOTS / PACKAGES
addappid(650782,0,"2fa03e2d9ade7ee227ce2ca5fd1f2854be82f4abf9ccf825d2a7d887b97ebb2f")
