-- Lua provided by RyzenAPI
-- Game: Game: Demonic Pack

-- MAIN APPLICATION
addappid(2226470)
-- Game: addappid(2226470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226471, 1, "b8c15ba70fa0b9c9a71be25446d27b6711e6f40ec67778b932e230681d4c3568")
