-- Lua provided by RyzenAPI
-- Game: Yujiro's Mansion

-- MAIN APPLICATION
addappid(2548070)
-- Game: addappid(2548070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548071, 1, "656917a017216a49a526f56ca43ac1975a9935cf2f850cfb70a110dfa7cb1ceb")
