-- Lua provided by RyzenAPI
-- Game: Virtual-O

-- MAIN APPLICATION
addappid(529020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(529021, 1, "a4de7472b7034326a6e3f5790f041e88e4f73736ed7b3d6005ea316cdf1b49b8")
