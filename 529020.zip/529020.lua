-- Lua provided by RyzenAPI
-- Game: addappid(529020)

-- MAIN APPLICATION
addappid(529020)

-- MAIN APP DEPOTS / PACKAGES
addappid(529021, 1, "a4de7472b7034326a6e3f5790f041e88e4f73736ed7b3d6005ea316cdf1b49b8")
