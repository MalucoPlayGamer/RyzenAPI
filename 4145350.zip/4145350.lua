-- Lua provided by RyzenAPI
-- Game: Alice and the Devil's Prison

-- MAIN APPLICATION
addappid(4145350)

-- MAIN APP DEPOTS / PACKAGES
addappid(4145354,0,"3db7b6901cd51c777930e1f4065c5da12dcdfbfb4fe69c21f4217bf69c72e692")

