-- Lua provided by RyzenAPI
-- Game: Break Sky

-- MAIN APPLICATION
addappid(1492940)
-- Game: addappid(1492940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492941, 1, "0daa3ccbfc95a54b85e5ccbd7a65ed6724eef9485920ac8ef0d085af9a94e27e")
