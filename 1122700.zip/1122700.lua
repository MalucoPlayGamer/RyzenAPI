-- Lua provided by RyzenAPI 
-- Game: AppID 1122700
addappid(1122700)
addappid(1122701, 1, "b42fb6a630405acff8816a7004cb399613c84b43ee7fc35c6b1af1f366b93995")
