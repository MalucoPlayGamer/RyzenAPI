-- Lua provided by RyzenAPI
-- Game: Pro Strategy Football 2026

-- MAIN APPLICATION
addappid(3734990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3734991,0,"863d0c7cdd2f770f7275c3110b4a0ec814e43979ae608ac324321aad0690920d")

