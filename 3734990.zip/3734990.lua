-- Lua provided by RyzenAPI
-- Game: Pro Strategy Football 2026

-- MAIN APPLICATION
addappid(3734990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3734991,0,"863d0c7cdd2f770f7275c3110b4a0ec814e43979ae608ac324321aad0690920d")

