-- Lua provided by RyzenAPI 
-- Game: Duck Detective: The Ghost of Glamping Soundtrack
addappid(3691040)
addappid(3691041, 1, "3355a0d347a2ec95b148dc05a493b58a797d2bcdbf424fc64d87bebca15ca542")
addappid(3691042, 1, "696fc5f306d4cd2356abe40f8c8a555eb167e1fc2cc24a61045c5c3ad1add99e")
