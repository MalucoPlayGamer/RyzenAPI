-- Lua provided by RyzenAPI
-- Game: 3063050

-- MAIN APPLICATION
addappid(3063050)
-- Game: addappid(3063050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063051, 1, "cd8fb7a17f9136ea607d4b0d59bbade9997509f217351980a394495844485ffc")
