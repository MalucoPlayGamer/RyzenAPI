-- Lua provided by RyzenAPI 
-- Game: Reimu Needs Help!? Aunn-chan to the Rescue!
addappid(3063050)
addappid(3063051, 1, "cd8fb7a17f9136ea607d4b0d59bbade9997509f217351980a394495844485ffc")
