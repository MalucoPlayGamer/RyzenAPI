-- Lua provided by RyzenAPI
-- Game: It Takes Two Friend's Pass

-- MAIN APPLICATION
addappid(1504980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426211,0,"c450c44e032e27d0308cf864259fb2af91bcfc58401a0caf33bb8efba85bb323")
