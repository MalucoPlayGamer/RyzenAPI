-- Lua provided by RyzenAPI
-- Game: Conqueror's Blade: Three Kingdoms

-- MAIN APPLICATION
addappid(4651220)

-- MAIN APP DEPOTS / PACKAGES
addappid(4651221, 1, "edfae0c4f4980d60ee0dcb2b7e1c23beda818694d3ac8ba2ff8814c4cf5c4319") -- Depot 4651221

