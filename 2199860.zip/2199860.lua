-- Lua provided by SkyAPI 
-- Game: Animal Trainer Simulator
addappid(2199860)
addappid(2199861, 1, "fe3ab5eea0dde57aa815452c0cea6f391fa52c99088998cb902c23d10aebe7ac")
