-- Lua provided by RyzenAPI
-- Game: 2199860

-- MAIN APPLICATION
addappid(2199860)
-- Game: addappid(2199860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199861, 1, "fe3ab5eea0dde57aa815452c0cea6f391fa52c99088998cb902c23d10aebe7ac")
