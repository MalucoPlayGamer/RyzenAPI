-- Lua provided by RyzenAPI 
-- Game: SUPER BOMBERMAN R 2
addappid(1913740)
addappid(1913741, 1, "e10d8cbc382503cf1ffe2aeb19015bb201ed2390f5d6b904490886333a200c1e")
