-- Lua provided by RyzenAPI
-- Game: addappid(1913740)

-- MAIN APPLICATION
addappid(1913740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913741, 1, "e10d8cbc382503cf1ffe2aeb19015bb201ed2390f5d6b904490886333a200c1e")
