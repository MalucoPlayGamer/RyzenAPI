-- Lua provided by RyzenAPI
-- Game: The Night of the Rabbit

-- MAIN APPLICATION
addappid(230820)
addappid(477050)

-- MAIN APP DEPOTS / PACKAGES
addappid(230821, 1, "b88f47712d3bfa382d7fb16dfe2a9a046e17aa5ce3579b14a35919b3db4fcb56")
addappid(230822, 1, "cf0b7fe703907bce38d39b13583190eced09940af529e215d2c2790fa5287a3e")
addappid(230823, 1, "d0e20f26170dd54270dd057094a323cf5eaa7cbb1b3918b950600d2b5d0ecb57")
addappid(230824, 1, "d5fa0bbc25f21438fd6fbaa0b8dbd8109f5bf639d4c2d0bd150d14b97382697f")
addappid(230827, 1, "69a409b9264c670834385235c0e7040697b63b53fbd77477cff18f4522b185e8")
addappid(230828, 1, "637e5c0d534c5c244f9c5061a07576f81d543b98664de3d66538c2cb6637e9ce")
addappid(230830, 1, "34d14c7e0804921a687104c1e384fa29c550ecc1bd47e9367cc8e1bc1d6b491b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
