-- Lua provided by RyzenAPI
-- Game: 2802380

-- MAIN APPLICATION
addappid(2802380)
-- Game: addappid(2802380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802381, 1, "64d610351dbc1aeed14bc91e57c2568ece55f36f6d6dbc36ff8c7a28a958b7db")
