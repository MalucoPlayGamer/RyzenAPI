-- Lua provided by RyzenAPI
-- Game: addappid(427810)

-- MAIN APPLICATION
addappid(427810)

-- MAIN APP DEPOTS / PACKAGES
addappid(427811, 1, "1a18618571421ec5935519947e9aa495abafa6c203c44f3193f7fd4f2a953fe9")
