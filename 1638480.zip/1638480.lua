-- Lua provided by RyzenAPI
-- Game: addappid(1638480)

-- MAIN APPLICATION
addappid(1638480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638481, 1, "00c659476aa988267034aa719564e5fdd1b96db6daccaea1bf558356a08abe6f")
