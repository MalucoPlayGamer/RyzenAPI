-- Lua provided by RyzenAPI
-- Game: Game: Heavy Armored Assassin

-- MAIN APPLICATION
addappid(2304570)
-- Game: addappid(2304570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304571, 1, "f39b0f020f4f5a9551f1e7c5e50e6bf351bd0cfdb7f24174b32754b46a5ff248")
