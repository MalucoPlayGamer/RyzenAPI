-- Lua provided by RyzenAPI
-- Game: Heavy Armored Assassin

-- MAIN APPLICATION
addappid(2304570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304571, 1, "f39b0f020f4f5a9551f1e7c5e50e6bf351bd0cfdb7f24174b32754b46a5ff248")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
