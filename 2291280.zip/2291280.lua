-- Lua provided by RyzenAPI
-- Game: addappid(2291280)

-- MAIN APPLICATION
addappid(2291280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291281, 1, "03e3cdace5cf17fea9f6b8c11516c6cec9d52933c8fccd2fc45eba83dcfaf596")
