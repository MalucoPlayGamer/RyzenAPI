-- Lua provided by RyzenAPI
-- Game: 1933700

-- MAIN APPLICATION
addappid(1933700)
-- Game: addappid(1933700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933701, 1, "2178d4cdc86266c432f74a966e9bce0a5ae6fc9f1ff3ea0c84dc7e9897b7edc4")
