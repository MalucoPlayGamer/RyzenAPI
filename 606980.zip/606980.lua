-- Lua provided by RyzenAPI
-- Game: 606980

-- MAIN APPLICATION
addappid(606980)
-- Game: addappid(606980)

-- MAIN APP DEPOTS / PACKAGES
addappid(606981, 1, "82251cd2b89ff8207bf2fbede00a2d58975505a80828c1954c0a7cf0c1181e91")
