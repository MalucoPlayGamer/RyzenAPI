-- Lua provided by RyzenAPI
-- Game: Franky the Bumwalker: REBORN

-- MAIN APPLICATION
addappid(1418470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418472,0,"c5da83dde9865cd23aac9da9e258c493c3d7c2b5a9e450d4a337928a058b77cb")
addappid(1418473,0,"1163855eb055ea83dbf31fa456ecba8bbe5639c0cb5ca371f4a913814989238d")
