-- Lua provided by RyzenAPI
-- Game: 674210

-- MAIN APPLICATION
addappid(674210)
-- Game: addappid(674210)

-- MAIN APP DEPOTS / PACKAGES
addappid(674211, 1, "ff7a8af7da0f98445735426ce6311cf1dbc47672961a9d4e9900c2153a7c54d1")
