-- Lua provided by RyzenAPI
-- Game: Game: Mirror world

-- MAIN APPLICATION
addappid(2832360)
-- Game: addappid(2832360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832361, 1, "0b21baa7ee0c88d5f9244f11446adc9909e1236a00555f3d9f50921bb13cb686")
