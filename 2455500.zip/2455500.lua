-- Lua provided by RyzenAPI
-- Game: Time Survivors: Chapter 0

-- MAIN APPLICATION
addappid(2455500)
-- Game: addappid(2455500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455501, 1, "efc85df8644da2efe30673dc138d26bf3ddbe9196fc9617c2b95832b5ec12d83")
