-- Lua provided by RyzenAPI
-- Game: Time Survivors: Chapter 0

-- MAIN APPLICATION
addappid(2455500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455501, 1, "efc85df8644da2efe30673dc138d26bf3ddbe9196fc9617c2b95832b5ec12d83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
