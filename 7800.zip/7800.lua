-- Lua provided by RyzenAPI
-- Game: Stubbs the Zombie in Rebel Without a Pulse

-- MAIN APPLICATION
addappid(7800)

-- MAIN APP DEPOTS / PACKAGES
addappid(7801, 1, "e95b5482730a48f9b66e61692b4b798ede81bc51fbbe0a5edae8ef3d77d0c401")
addappid(7802, 1, "700437a8534c96eb03092f39aefe2cc010e748bcc459e7b91fd0267b81f82b15")
addappid(1560280, 0, "93f78313ecd26f2d83b2d095ac7af003abd9ba8b9648f63b16709a6794847563")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
