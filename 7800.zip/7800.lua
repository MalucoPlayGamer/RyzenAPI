-- Lua provided by SkyAPI 
-- Game: Stubbs the Zombie in Rebel Without a Pulse
addappid(7800)
addappid(7801, 1, "e95b5482730a48f9b66e61692b4b798ede81bc51fbbe0a5edae8ef3d77d0c401")
addappid(7802, 1, "700437a8534c96eb03092f39aefe2cc010e748bcc459e7b91fd0267b81f82b15")
addappid(1560280, 0, "93f78313ecd26f2d83b2d095ac7af003abd9ba8b9648f63b16709a6794847563")
