-- Lua provided by RyzenAPI
-- Game: Antenna

-- MAIN APPLICATION
addappid(443580)

-- MAIN APP DEPOTS / PACKAGES
addappid(443581, 1, "c7840bf9ea078f4da48db61674c4a50ee11e0cade8185ac0501a215cbc5d44ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
