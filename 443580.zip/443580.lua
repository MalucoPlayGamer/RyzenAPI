-- Lua provided by RyzenAPI
-- Game: addappid(443580)

-- MAIN APPLICATION
addappid(443580)

-- MAIN APP DEPOTS / PACKAGES
addappid(443581, 1, "c7840bf9ea078f4da48db61674c4a50ee11e0cade8185ac0501a215cbc5d44ae")
