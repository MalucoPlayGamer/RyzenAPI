-- Lua provided by RyzenAPI
-- Game: Dungeon Weiqi

-- MAIN APPLICATION
addappid(3540430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3540431, 1, "de3c104c0c156c1485edb615e1a7c92c185d4e9445c8b3562ff88387511c4736")

