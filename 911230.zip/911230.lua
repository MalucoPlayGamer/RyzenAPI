-- Lua provided by RyzenAPI
-- Game: Game: AppID 911230

-- MAIN APPLICATION
addappid(911230)
-- Game: addappid(911230)

-- MAIN APP DEPOTS / PACKAGES
addappid(911231, 1, "7e2e651649d630627fe5c04d99cd7ec435a072a31e2db0359527aafe10c2d32b")
