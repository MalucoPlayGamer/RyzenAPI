-- Lua provided by SkyAPI 
-- Game: AppID 911230
addappid(911230)
addappid(911231, 1, "7e2e651649d630627fe5c04d99cd7ec435a072a31e2db0359527aafe10c2d32b")
