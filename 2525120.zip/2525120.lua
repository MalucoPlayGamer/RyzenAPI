-- Lua provided by RyzenAPI
-- Game: 鈴集無名の丘 ～ Little Doll Queen

-- MAIN APPLICATION
addappid(2525120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525121, 1, "67f1e70e8b5d4d5a9e53a1110533434ebd0ed3d7c1e929613a4e311e01dfee04")
