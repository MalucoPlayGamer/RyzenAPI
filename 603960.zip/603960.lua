-- Lua provided by RyzenAPI
-- Game: Star of Providence

-- MAIN APPLICATION
addappid(603960)
addappid(1180120)

-- MAIN APP DEPOTS / PACKAGES
addappid(603961,0,"d080bc7bd6d033e446b44c6d824255672423e854465847fb24f358616c2505da")
addappid(603962,0,"8bedc28ef406b30be99fa67afbfdec206daa6a94f66eb0d059d0a17cd4be3919")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
