-- Lua provided by RyzenAPI
-- Game: 603960

-- MAIN APPLICATION
addappid(603960)
-- Game: addappid(603960)

-- MAIN APP DEPOTS / PACKAGES
addappid(603961, 1, "d080bc7bd6d033e446b44c6d824255672423e854465847fb24f358616c2505da")
addappid(603962, 1, "8bedc28ef406b30be99fa67afbfdec206daa6a94f66eb0d059d0a17cd4be3919")
