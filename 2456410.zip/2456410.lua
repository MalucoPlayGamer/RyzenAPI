-- Lua provided by SkyAPI 
-- Game: GOBLIN SLAYER -ANOTHER ADVENTURER- NIGHTMARE FEAST
addappid(2456410)
addappid(2456411, 1, "e18e6d39466db8f0bd67c36735438bbc461df2aecb0f97fe6a0bcedaf8cff368")
