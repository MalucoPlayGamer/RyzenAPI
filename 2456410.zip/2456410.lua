-- Lua provided by RyzenAPI
-- Game: GOBLIN SLAYER -ANOTHER ADVENTURER- NIGHTMARE FEAST

-- MAIN APPLICATION
addappid(2456410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2456411, 1, "e18e6d39466db8f0bd67c36735438bbc461df2aecb0f97fe6a0bcedaf8cff368")

