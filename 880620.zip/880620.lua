-- Lua provided by RyzenAPI
-- Game: 荒漠求生

-- MAIN APPLICATION
addappid(880620)

-- MAIN APP DEPOTS / PACKAGES
addappid(880621, 1, "a44e54938ab75807c0d3c7fbcefead908c00055eb6814ef2c37d981905b73f44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
