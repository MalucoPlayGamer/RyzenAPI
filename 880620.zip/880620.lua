-- Lua provided by RyzenAPI
-- Game: 荒漠求生

-- MAIN APPLICATION
addappid(880620)

-- MAIN APP DEPOTS / PACKAGES
addappid(880621, 1, "a44e54938ab75807c0d3c7fbcefead908c00055eb6814ef2c37d981905b73f44")
