-- Lua provided by RyzenAPI
-- Game: Game: Alien Grounds

-- MAIN APPLICATION
addappid(3351550)
-- Game: addappid(3351550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351551, 1, "389029eb6113a362c1112029dfd9b40834e4198e8fe62a745f361f62872cdaeb")
