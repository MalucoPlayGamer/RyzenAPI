-- Lua provided by RyzenAPI
-- Game: Alien Grounds

-- MAIN APPLICATION
addappid(3351550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351551, 1, "389029eb6113a362c1112029dfd9b40834e4198e8fe62a745f361f62872cdaeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
