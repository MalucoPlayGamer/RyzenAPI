-- Lua provided by RyzenAPI
-- Game: Darza's Dominion

-- MAIN APPLICATION
addappid(1895130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895131, 1, "e88617367851ecd91ff518749454ba55c6b7552a985df7ec177db3f196ce5f95")

