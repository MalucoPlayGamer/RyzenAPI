-- Lua provided by RyzenAPI
-- Game: Rabi-Ribi - Orchestra Arrangement Soundtrack

-- MAIN APPLICATION
addappid(1455340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455343,0,"19dd440ae3cac4473496a6a37f72a88d20ab672b18546f0ab214e9e88d423002")
addappid(1455344,0,"fbd43f9ab27714ffb4861a55191aa620a8f3154221bc01103b9e4bf42a8c1309")

