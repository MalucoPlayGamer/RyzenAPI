-- Lua provided by RyzenAPI
-- Game: Hegemony Gold: Wars of Ancient Greece

-- MAIN APPLICATION
addappid(202690)

-- MAIN APP DEPOTS / PACKAGES
addappid(202691, 1, "a8a92553bec66e4f3392f13ee96cc7c24e9c832bea03dbfe6e8123ba175d8cc6")
