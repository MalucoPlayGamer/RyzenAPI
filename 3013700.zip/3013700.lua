-- Lua provided by RyzenAPI
-- Game: Candy & Toys Store Simulator

-- MAIN APPLICATION
addappid(3013700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013701, 1, "db71850f9aad68cc17f27c5cda550db92b5ecccb7580bd2893e36a5b9a02bb45")
