-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Dawn of War II - Chaos Rising

-- MAIN APPLICATION
addappid(20570)
addappid(428990)
addappid(428991)
addappid(428992)
addappid(428993)
addappid(428994)
addappid(428995)
addappid(428996)
addappid(428997)
addappid(428998)
addappid(428999)
addappid(429000)
addappid(429001)
addappid(429002)
addappid(429004)
addappid(429005)
addappid(429006)

-- MAIN APP DEPOTS / PACKAGES
addappid(20571, 1, "b74063ac34c157f38c84b572d58616d6914506c50c72616e84baf64be2b9ea8e")
