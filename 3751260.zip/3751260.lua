-- Lua provided by RyzenAPI
-- Game: The Blood of Dawnwalker

-- MAIN APPLICATION
addappid(4417540) -- The Blood of Dawnwalker - Sangoran Wayfarers Armor Set
addappid(4417550) -- The Blood of Dawnwalker - Eclipse Edition Content

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3751260, 1, "bfb8982d4aeb1b3b81978c18fb93b66cbc707cf9530ab92769d00c50e90c4031") -- The Blood of Dawnwalker
addappid(3751261, 1, "fe44cc16911c3d5dabb2b862a70f1b8b58ee79e1da1f47b8bf03af487c17e8fc") -- Depot 3751261

