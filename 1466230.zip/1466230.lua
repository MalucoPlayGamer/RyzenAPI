-- Lua provided by RyzenAPI
-- Game: 1466230

-- MAIN APPLICATION
addappid(1466230)
-- Game: addappid(1466230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466231, 1, "4fe93fff3fec5cb4d2875d252a65b35747c729ad2e3365beb9a05eff6fdb4fa1")
