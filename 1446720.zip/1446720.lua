-- Lua provided by RyzenAPI
-- Game: Is It Wrong to Try to Shoot 'em Up Girls in a Dungeon?

-- MAIN APPLICATION
addappid(1446720)
-- Game: addappid(1446720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446721, 1, "da7d6b669804951fadd4542b2b9ee36901ce592e55c21be8f8d91ce51afa3278")
