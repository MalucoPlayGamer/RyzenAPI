-- Lua provided by RyzenAPI
-- Game: Wonder Waifu: Ero-Hero NTR

-- MAIN APPLICATION
addappid(2777260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777261, 1, "d08b7c0d4ae280a368f414562f1e7d4992886df5dd09b584684b075ec6e6bb63")
addappid(2777262, 1, "94edb22cbb52e21ba6e48147a8d6f04564042b53427e48bd0cf42c76c283f969")
