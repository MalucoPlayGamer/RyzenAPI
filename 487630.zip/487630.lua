-- Lua provided by RyzenAPI
-- Game: addappid(487630)

-- MAIN APPLICATION
addappid(487630)

-- MAIN APP DEPOTS / PACKAGES
addappid(487631, 1, "69194a5717811c9a1276a1d394a11080dfae27a6179f614a74d0dd2ca7196b0c")
