-- Lua provided by RyzenAPI
-- Game: 3252030

-- MAIN APPLICATION
addappid(3252030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252030,0,"987da4a6d5c7598676e47329dea0a8a33aeb8bcac8b6247849aab9ae09bedb3e")
