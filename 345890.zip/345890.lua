-- Lua provided by RyzenAPI
-- Game: NASCAR '15 Victory Edition

-- MAIN APPLICATION
addappid(345890)
addappid(378550)
addappid(378551)
addappid(378552)
addappid(515300)

-- MAIN APP DEPOTS / PACKAGES
addappid(345891, 1, "e0b9b131238d4bfa0be4b4afdf98673713ed38205872322467afcc749ecca875")
addappid(345892, 1, "27fa662ad68dadc9b5693886cc9e603ed98003371fbd39107a1a471aa45ce822")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
