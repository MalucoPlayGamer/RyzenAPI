-- Lua provided by RyzenAPI
-- Game: NASCAR '15 Victory Edition

-- MAIN APPLICATION
addappid(345890)
addappid(378550)
addappid(378551)
addappid(378552)
addappid(515300)

-- MAIN APP DEPOTS / PACKAGES
addappid(345891, 1, "e0b9b131238d4bfa0be4b4afdf98673713ed38205872322467afcc749ecca875")
addappid(345892, 1, "27fa662ad68dadc9b5693886cc9e603ed98003371fbd39107a1a471aa45ce822")
