-- Lua provided by RyzenAPI
-- Game: 2548000

-- MAIN APPLICATION
addappid(2548000)
-- Game: addappid(2548000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548001, 1, "45a341b2d316b3581921c9fa24fc93c842376574009b30d3ab9dbf03b9feb618")
