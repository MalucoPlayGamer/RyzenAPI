-- Lua provided by RyzenAPI
-- Game: addappid(548020)

-- MAIN APPLICATION
addappid(548020)

-- MAIN APP DEPOTS / PACKAGES
addappid(548021, 1, "85e2de6edf72a19a96d8460f1b95f301a193bdd2f60a8b66534fdcc623ec7ee2")
