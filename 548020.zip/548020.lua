-- Lua provided by SkyAPI 
-- Game: Warmada
addappid(548020)
addappid(548021, 1, "85e2de6edf72a19a96d8460f1b95f301a193bdd2f60a8b66534fdcc623ec7ee2")
