-- Lua provided by RyzenAPI
-- Game: addappid(1424160)

-- MAIN APPLICATION
addappid(1424160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424161, 1, "562e68527efef1d3bd04988a0fe9bae1f89513cdf462b55f5f18e8db5bc50f57")
