-- Lua provided by RyzenAPI
-- Game: The Yellow King

-- MAIN APPLICATION
addappid(1149400)
-- Game: addappid(1149400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149401, 1, "b64bec175d5e04e45479420308726cefc32e27bfc83fb824ab55924bfe226045")
