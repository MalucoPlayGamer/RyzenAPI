-- Lua provided by RyzenAPI
-- Game: The Matchless KungFu Demo

-- MAIN APPLICATION
addappid(2286710)
-- Game: addappid(2286710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286711, 1, "0bcfc2b80a5354c12eb7883020844554771cb19896da7397baf117967876a89a")
