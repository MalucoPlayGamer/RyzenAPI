-- Lua provided by RyzenAPI 
-- Game: North Stars
addappid(843050)
addappid(843051, 1, "9a2e04c9283c36aeae5447875577d37a1595c9e509f99d306410bdd06f867555")
