-- Lua provided by RyzenAPI
-- Game: North Stars

-- MAIN APPLICATION
addappid(843050)
-- Game: addappid(843050)

-- MAIN APP DEPOTS / PACKAGES
addappid(843051, 1, "9a2e04c9283c36aeae5447875577d37a1595c9e509f99d306410bdd06f867555")
