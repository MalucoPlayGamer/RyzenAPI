-- Lua provided by RyzenAPI
-- Game: North Stars

-- MAIN APPLICATION
addappid(843050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(843051, 1, "9a2e04c9283c36aeae5447875577d37a1595c9e509f99d306410bdd06f867555")

