-- Lua provided by RyzenAPI
-- Game: Game: Nimbusfall

-- MAIN APPLICATION
addappid(2924040)
-- Game: addappid(2924040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924041, 1, "7cdada10f1fccf92b420c8a045260c86a385b3a5c802646f72dd1de09df0ad4c")
