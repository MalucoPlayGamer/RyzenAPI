-- Lua provided by RyzenAPI
-- Game: Everreach: Project Eden

-- MAIN APPLICATION
addappid(915670)

-- MAIN APP DEPOTS / PACKAGES
addappid(915671, 1, "ee034dc9cff955a35fdaa6a3b25c218ef79f233c0e39c9568954146b9631b3f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
