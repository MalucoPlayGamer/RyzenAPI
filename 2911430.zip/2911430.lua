-- Lua provided by RyzenAPI
-- Game: 交织的印记 Demo

-- MAIN APPLICATION
addappid(2911430)
-- Game: addappid(2911430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911431, 1, "e075f1560a7a4bd8370985a93bb66b50800da91bd2fe335a192bd8d67520ed7c")
