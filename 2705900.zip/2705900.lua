-- Lua provided by RyzenAPI
-- Game: Neocon Tower Defence 3

-- MAIN APP DEPOTS / PACKAGES
addappid(2705900, 1, "cbce4691f7eb66d4b964cf80432097560103527a99bc0fa6fb80167522057657") -- Neocon Tower Defence 3
addappid(2705901, 1, "d5d1dc5c4de6ee98d23787f4004c4d9ceb6494f764c29f9ffffe1191026a7ef9") -- Depot 2705901

