-- 2705900's Lua and Manifest Created by Hubcap Manifest
-- Neocon Tower Defence 3
-- Created: August 16, 2026 at 12:58:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2705900, 1, "cbce4691f7eb66d4b964cf80432097560103527a99bc0fa6fb80167522057657") -- Neocon Tower Defence 3
-- MAIN APP DEPOTS
addappid(2705901, 1, "d5d1dc5c4de6ee98d23787f4004c4d9ceb6494f764c29f9ffffe1191026a7ef9") -- Depot 2705901
setManifestid(2705901, "2150876371418541110", 639506009)