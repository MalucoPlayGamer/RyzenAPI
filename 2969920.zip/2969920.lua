-- Lua provided by RyzenAPI
-- Game: 2969920

-- MAIN APPLICATION
addappid(2969920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969920,0,"fefb3f75d51be11482ec482ee2dd0406d3c4fcf54c6f8754de166c60cfa4987f")
