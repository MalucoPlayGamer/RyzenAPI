-- Lua provided by SkyAPI 
-- Game: Mediterranea Inferno Demo
addappid(2393200)
addappid(2393201, 1, "319361840ea05d5f778c47e9bb98991e8c6d2456981fce57c3dac0092d36e738")
