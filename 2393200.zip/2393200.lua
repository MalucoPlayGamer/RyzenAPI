-- Lua provided by RyzenAPI
-- Game: Mediterranea Inferno Demo

-- MAIN APPLICATION
addappid(2393200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393201, 1, "319361840ea05d5f778c47e9bb98991e8c6d2456981fce57c3dac0092d36e738")

