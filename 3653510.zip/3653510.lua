-- Lua provided by RyzenAPI 
-- Game: Space Memory: Parrots
addappid(3653510)
addappid(3653511, 1, "750d79ecfda1d1b00730b74704e04fd10b6ad7294b3cf2dc3e9768e94a3ee16a")
