-- Lua provided by RyzenAPI
-- Game: Kitchen Crisis Demo

-- MAIN APPLICATION
addappid(2511020)
-- Game: addappid(2511020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511021, 1, "423fb892dfcb7faaf7b1306f914f387095492e2eb46dc506da4c5e763f725109")
