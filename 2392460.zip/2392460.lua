-- Lua provided by RyzenAPI
-- Game: addappid(2392460)

-- MAIN APPLICATION
addappid(2392460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392461, 1, "fec61bed7f85694452f57b624cd05e68fcf6eef31951bb12da6a7a7cac4336f5")
