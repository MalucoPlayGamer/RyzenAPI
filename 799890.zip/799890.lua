-- Lua provided by RyzenAPI
-- Game: REVENGER: Age of Morons

-- MAIN APPLICATION
addappid(799890)

-- MAIN APP DEPOTS / PACKAGES
addappid(799891, 1, "0489e2b78b870bc4d9da971ca3297f1025cf5c9d68043ccd51c4e8b4104a4079")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
