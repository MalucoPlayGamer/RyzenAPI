-- Lua provided by RyzenAPI
-- Game: addappid(710410)

-- MAIN APPLICATION
addappid(710410)

-- MAIN APP DEPOTS / PACKAGES
addappid(710410,0,"0f290550b39f6a42c4fc022fcfa0b44aa167a88de30fda6c6a0cc8791d4a669d")
