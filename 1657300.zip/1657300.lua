-- Lua provided by RyzenAPI
-- Game: Monuments Flipper Demo

-- MAIN APPLICATION
addappid(1657300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657301, 1, "47962c5cf2f6d54b62957e9b7c8a9a3795abdc773b15a0d185d7b09082f5fdbb")
