-- Lua provided by SkyAPI 
-- Game: Billie Bust Up Playtest
addappid(2364680)
addappid(2364681, 1, "e1eabf83cbdfbfced2d7849a20f94f1a7677f8d390912cd0836940f578a61516")
