-- Lua provided by RyzenAPI
-- Game: 2364680

-- MAIN APPLICATION
addappid(2364680)
-- Game: addappid(2364680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364681, 1, "e1eabf83cbdfbfced2d7849a20f94f1a7677f8d390912cd0836940f578a61516")
