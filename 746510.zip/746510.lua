-- Lua provided by RyzenAPI
-- Game: Game: Duck Season PC

-- MAIN APPLICATION
addappid(746510)
-- Game: addappid(746510)

-- MAIN APP DEPOTS / PACKAGES
addappid(746511, 1, "65700c15a29b036723deccc1d85f26b4d80eb9495a943720a2094e5e9b5998b2")
