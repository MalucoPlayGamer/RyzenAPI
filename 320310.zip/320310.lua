-- Lua provided by RyzenAPI
-- Game: World Truck Racing

-- MAIN APPLICATION
addappid(320310)
-- Game: addappid(320310)

-- MAIN APP DEPOTS / PACKAGES
addappid(320311, 1, "c48fc390cfe5bc59f814239127069ccfe8efa741072f0e4b9fd33dd8e5cf4aa5")
