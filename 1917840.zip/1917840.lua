-- Lua provided by RyzenAPI
-- Game: Funny Village

-- MAIN APPLICATION
addappid(1917840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917841, 1, "01e6445d1e2df568a3cf6a3bfb014467a61b929dea5420134f7be565e6625d77")

