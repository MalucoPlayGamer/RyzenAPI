-- Lua provided by RyzenAPI
-- Game: Funny Village

-- MAIN APPLICATION
addappid(1917840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917841, 1, "01e6445d1e2df568a3cf6a3bfb014467a61b929dea5420134f7be565e6625d77")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
