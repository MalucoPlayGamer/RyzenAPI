-- Lua provided by RyzenAPI
-- Game: Hentai City

-- MAIN APPLICATION
addappid(2978430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978431, 1, "110f49e27808ed092aed54837e7b9199c1485929e14ee1f1c2b95887fadcc279")
