-- Lua provided by RyzenAPI
-- Game: Automate It: Factory Puzzle

-- MAIN APPLICATION
addappid(2472770)
-- Game: addappid(2472770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472771, 1, "c985ef11facb043b5d929bee162fb609acc94e25179865354889080f7cb952ac")
