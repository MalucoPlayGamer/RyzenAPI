-- Lua provided by RyzenAPI
-- Game: Shooty

-- MAIN APPLICATION
addappid(1454060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454061, 1, "08659d7c5c6e66d4a24087ca6a2746ac07de080a4ff8b2ebe3c1ea6854fe86c8")
addappid(1522420, 0, "9f125806eb416856d32f91cecbe81b1d3d6595e190cf9904adbe0c165dde2b94")

