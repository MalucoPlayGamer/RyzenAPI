-- Lua provided by RyzenAPI 
-- Game: Farm Day 2021
addappid(1434490)
addappid(1434491, 1, "875dca399093a47b92392ba41356181de76a20536d1b71f84ad0860884c32d38")
