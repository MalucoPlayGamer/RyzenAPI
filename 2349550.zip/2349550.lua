-- Lua provided by RyzenAPI
-- Game: Game: The Test: Secrets of the Soul 2

-- MAIN APPLICATION
addappid(2349550)
addappid(2352780)
-- Game: addappid(2349550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349551, 1, "8ec9b9e6c5872cbbab3b6a1dd6e16c98c861fb274e8bd346a06beac4c1eb7102")
