-- Lua provided by RyzenAPI
-- Game: The Test: Secrets of the Soul 2

-- MAIN APPLICATION
addappid(2349550)
addappid(2352780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2349551, 1, "8ec9b9e6c5872cbbab3b6a1dd6e16c98c861fb274e8bd346a06beac4c1eb7102")

