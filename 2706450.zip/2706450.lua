-- Lua provided by RyzenAPI 
-- Game: Hands of Necromancy II
addappid(2706450)
addappid(2706451, 1, "828bc0aa79c8aaed3228670c701ef21b97d668c9651c2697ad2a743a2fc104f8")
addappid(2706452, 1, "e78681532b85320dc376338d8d00724a040e797b966f54838aa09196fc217265")
