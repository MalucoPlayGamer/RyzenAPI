-- Lua provided by RyzenAPI
-- Game: Hands of Necromancy II

-- MAIN APPLICATION
addappid(2706450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706451, 1, "828bc0aa79c8aaed3228670c701ef21b97d668c9651c2697ad2a743a2fc104f8")
addappid(2706452, 1, "e78681532b85320dc376338d8d00724a040e797b966f54838aa09196fc217265")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
