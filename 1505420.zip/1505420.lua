-- Lua provided by RyzenAPI
-- Game: Game: Run Ralph Run

-- MAIN APPLICATION
addappid(1505420)
-- Game: addappid(1505420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505421, 1, "c2c27abc9497cea39e47aed68383656c43ed1b1e0642d065847d01cbdd120d50")
