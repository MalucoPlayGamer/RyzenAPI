-- Lua provided by RyzenAPI 
-- Game: Dusk Pub - Adult Only
addappid(1974520)
addappid(1974521, 1, "b81bd5538556d82c79a9b368a24ac4d94f39479e82d525f792a8bdb5ecbcd65d")
addappid(1974522, 1, "052666b7b3d2266e432ca37468b2bc5b0b925dfec639cb9ad7a08e49ed7fae59")
addappid(2990160, 0, "c19dd0d992f1a11978725d483e0c892a77ee9bdb6e400510e8bd550b213e58e1")
