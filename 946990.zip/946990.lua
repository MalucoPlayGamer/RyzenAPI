-- Lua provided by SkyAPI 
-- Game: AppID 946990
addappid(946990)
addappid(946991, 1, "73240656097e6197fd99e2f843f572cc073c49f8478ce36542c55be69947cb40")
addappid(1847370, 0, "c87ff0d05fb221f92f61aaa56e41c8dd8ac5b871852e0c4fdd32acc2d9dee6e3")
