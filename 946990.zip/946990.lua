-- Lua provided by RyzenAPI
-- Game: AppID 946990

-- MAIN APPLICATION
addappid(946990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(946991, 1, "73240656097e6197fd99e2f843f572cc073c49f8478ce36542c55be69947cb40")
addappid(1847370, 0, "c87ff0d05fb221f92f61aaa56e41c8dd8ac5b871852e0c4fdd32acc2d9dee6e3")

