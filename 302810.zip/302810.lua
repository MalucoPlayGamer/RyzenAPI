-- Lua provided by RyzenAPI
-- Game: Divinia Chronicles: Relics of Gan-Ti

-- MAIN APPLICATION
addappid(302810)

-- MAIN APP DEPOTS / PACKAGES
addappid(302811, 1, "d3ed900f9cd3bb294ea87bf4e53492eb0d52c69c59a4d7cd9d51519426fd0516")
