-- Lua provided by RyzenAPI
-- Game: Geometry Wars: Retro Evolved

-- MAIN APPLICATION
addappid(8400)
-- Game: addappid(8400)

-- MAIN APP DEPOTS / PACKAGES
addappid(8401, 1, "a37baf5fc7bd33defcefc9b02bce6207dc96c4d067f14a3f63c86cfd7213f192")
