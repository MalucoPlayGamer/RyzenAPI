-- Lua provided by RyzenAPI
-- Game: Calm Cove [Demo]

-- MAIN APPLICATION
addappid(2612250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612251, 1, "2a745ca26d5fb6db82b1abeece0bc30c58b430b0ea25d6b8f731d2c3e141c524")

