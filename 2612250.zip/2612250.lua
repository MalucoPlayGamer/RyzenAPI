-- Lua provided by SkyAPI 
-- Game: Calm Cove [Demo]
addappid(2612250)
addappid(2612251, 1, "2a745ca26d5fb6db82b1abeece0bc30c58b430b0ea25d6b8f731d2c3e141c524")
