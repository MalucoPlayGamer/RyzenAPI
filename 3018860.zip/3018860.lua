-- Lua provided by RyzenAPI
-- Game: 49 Keys Demo

-- MAIN APPLICATION
addappid(3018860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018861, 1, "998ba733c109e67a6ae5d50161f789fd9a6ef24e67310fb5070769e3b50f5fc8")
