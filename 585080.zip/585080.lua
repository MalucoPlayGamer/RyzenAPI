-- Lua provided by RyzenAPI
-- Game: Hunting Simulator

-- MAIN APPLICATION
addappid(585080)
addappid(636440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(585081, 1, "53ea88e7d9db5bce754228f0fc75c02645e59bced84715e4023d9f402a7a4a98")

