-- Lua provided by RyzenAPI
-- Game: Hunting Simulator

-- MAIN APPLICATION
addappid(585080)
addappid(636440)
-- Game: addappid(585080)

-- MAIN APP DEPOTS / PACKAGES
addappid(585081, 1, "53ea88e7d9db5bce754228f0fc75c02645e59bced84715e4023d9f402a7a4a98")
