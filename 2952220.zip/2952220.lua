-- Lua provided by RyzenAPI
-- Game: Melo's nightmare Demo

-- MAIN APPLICATION
addappid(2952220)
-- Game: addappid(2952220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952221, 1, "725fd66f20000573ac0a5cb46ce4438e8f603273b4c9e0f9fa2d4efdd0435b63")
