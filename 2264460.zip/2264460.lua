-- Lua provided by RyzenAPI
-- Game: UnderBackrooms

-- MAIN APPLICATION
addappid(2264460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264461, 1, "c813c010d66f1f64d99ebc21bcb6b7bcc255b40e24e434ef63eeb68ed7f79f26")
