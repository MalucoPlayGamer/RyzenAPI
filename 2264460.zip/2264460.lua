-- Lua provided by RyzenAPI
-- Game: UnderBackrooms

-- MAIN APPLICATION
addappid(2264460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2264461, 1, "c813c010d66f1f64d99ebc21bcb6b7bcc255b40e24e434ef63eeb68ed7f79f26")

