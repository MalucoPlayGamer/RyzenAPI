-- Lua provided by RyzenAPI
-- Game: Peace Data

-- MAIN APPLICATION
addappid(1209140)
-- Game: addappid(1209140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209141, 1, "39f5f5ed98b932aadaa06db7ab2b71e26fdc63e02aee958119c66e633f8d7602")
