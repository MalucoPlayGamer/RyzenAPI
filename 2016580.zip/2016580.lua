-- Lua provided by SkyAPI 
-- Game: Deneb: Across the Stars
addappid(2016580)
addappid(2016581, 1, "b1aad5d7e3594a1fa18b4332b14cef6d5e2859905f44f65d1814e7caabb5547c")
addappid(2016582, 1, "571f69ef33eb6eb321d62653aa3297e5053e3f5d78e120e19d92d25337b248a4")
