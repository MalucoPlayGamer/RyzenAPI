-- Lua provided by RyzenAPI
-- Game: addappid(957630)

-- MAIN APPLICATION
addappid(957630)

-- MAIN APP DEPOTS / PACKAGES
addappid(957634,0,"c5af63c5b60b1ccc67f334f83fdc2a20bf55c7075b7186ffb539c10197f8a6f5")
