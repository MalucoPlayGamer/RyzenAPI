-- Lua provided by RyzenAPI
-- Game: Delivery Express

-- MAIN APPLICATION
addappid(2856650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856651, 1, "68cc76a6a73ecf4fb9a0cf7ff4b7e267f0a634a0faf52c2e38f51c168d73d43d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
