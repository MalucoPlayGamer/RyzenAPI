-- Lua provided by SkyAPI 
-- Game: Delivery Express
addappid(2856650)
addappid(2856651, 1, "68cc76a6a73ecf4fb9a0cf7ff4b7e267f0a634a0faf52c2e38f51c168d73d43d")
