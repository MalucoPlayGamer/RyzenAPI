-- Lua provided by RyzenAPI
-- Game: Game: Dungeons & Vampires

-- MAIN APPLICATION
addappid(759160)
-- Game: addappid(759160)

-- MAIN APP DEPOTS / PACKAGES
addappid(759161, 1, "a55446b89994b60620a573d82ad583bd883e11339e75bbd4b8b8481323b66149")
