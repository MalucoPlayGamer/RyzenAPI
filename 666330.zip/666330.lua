-- Lua provided by RyzenAPI
-- Game: Inertia

-- MAIN APPLICATION
addappid(666330)

-- MAIN APP DEPOTS / PACKAGES
addappid(666331, 1, "df2cbc9bd1cc74e253334cdf4a148bb4d3ec31609b09e2418111ff9dd6ce5eb9")

