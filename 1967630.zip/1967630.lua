-- Lua provided by RyzenAPI
-- Game: addappid(1967630)

-- MAIN APPLICATION
addappid(1967630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967631, 1, "d4fc071e5d413fb4db9dc55104ea8947d72a34e369c0c5fd0e82fa83504bc9af")
