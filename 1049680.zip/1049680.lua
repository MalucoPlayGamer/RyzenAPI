-- Lua provided by SkyAPI 
-- Game: AppID 1049680
addappid(1049680)
addappid(1049681, 1, "6a43008f1e0dff8f74bbaba426c153f719c864793d4562e836f78e54a729f603")
