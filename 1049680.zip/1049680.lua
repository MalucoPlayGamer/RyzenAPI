-- Lua provided by RyzenAPI
-- Game: addappid(1049680)

-- MAIN APPLICATION
addappid(1049680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049681, 1, "6a43008f1e0dff8f74bbaba426c153f719c864793d4562e836f78e54a729f603")
