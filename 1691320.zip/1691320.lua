-- Lua provided by RyzenAPI
-- Game: Hellbreach: Vegas

-- MAIN APPLICATION
addappid(1691320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691321, 1, "6ed7eab6be8aa8d09de38a1b99103fd5bce39cf844cae93a7ecae7abb4a9b902")

