-- Lua provided by RyzenAPI
-- Game: Hellbreach: Vegas

-- MAIN APPLICATION
addappid(1691320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1691321, 1, "6ed7eab6be8aa8d09de38a1b99103fd5bce39cf844cae93a7ecae7abb4a9b902")

