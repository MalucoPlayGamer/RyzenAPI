-- Lua provided by RyzenAPI
-- Game: Game: AppID 1042150

-- MAIN APPLICATION
addappid(1042150)
-- Game: addappid(1042150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042151, 1, "e79a7f81a7b5b001c4ebea69e68dbd135a44aea6e19df8f2ea83c551f384d1b6")
