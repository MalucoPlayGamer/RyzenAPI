-- Lua provided by RyzenAPI
-- Game: 1415410

-- MAIN APPLICATION
addappid(1415410)
-- Game: addappid(1415410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415411, 1, "c2d28ba83c5e93746cd2d9750e2fa174e5d0eadcec57fe70dcd57759266581d8")
