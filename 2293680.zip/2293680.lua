-- Lua provided by RyzenAPI
-- Game: Crestfallen: Medieval Survival

-- MAIN APPLICATION
addappid(2293680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2293681, 1, "a351d0c525166a277e3182a6d9bfde617dd626e1ad9b089f7433c044194c6c6d")

