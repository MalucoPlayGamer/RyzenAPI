-- Lua provided by RyzenAPI 
-- Game: Crestfallen: Medieval Survival
addappid(2293680)
addappid(2293681, 1, "a351d0c525166a277e3182a6d9bfde617dd626e1ad9b089f7433c044194c6c6d")
