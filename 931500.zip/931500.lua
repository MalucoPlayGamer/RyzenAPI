-- Lua provided by RyzenAPI
-- Game: Touhou Genso Wanderer -Reloaded-

-- MAIN APPLICATION
addappid(931500)
-- Game: addappid(931500)

-- MAIN APP DEPOTS / PACKAGES
addappid(931501, 1, "6bf4fb4180e8e1880ae147f5da5286b4510be068609ffe45622c0c3b144dcda7")
