-- Lua provided by RyzenAPI
-- Game: Touhou Genso Wanderer -Reloaded-

-- MAIN APPLICATION
addappid(931500)

-- MAIN APP DEPOTS / PACKAGES
addappid(931501, 1, "6bf4fb4180e8e1880ae147f5da5286b4510be068609ffe45622c0c3b144dcda7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(940620)
addappid(940730)
addappid(940731)
addappid(940732)
addappid(940733)
addappid(940734)
addappid(940735)
addappid(940736)
addappid(940737)
addappid(940738)
addappid(940739)
addappid(940740)
addappid(940750)
addappid(940770)
addappid(940771)
addappid(942210)
