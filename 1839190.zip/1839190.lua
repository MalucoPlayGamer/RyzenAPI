-- Lua provided by RyzenAPI
-- Game: 1839190

-- MAIN APPLICATION
addappid(1839190)
-- Game: addappid(1839190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839194,0,"aab8756a5a03dfc1a44ddcf9041e5201c2a74a2381f13cd5fffb6d3da5f51ac5")
addappid(1839198,0,"f757647f5b540ea064fb8057c4d2a5b8db9e3f8616581b20960199dac0e39352")
