-- Lua provided by SkyAPI 
-- Game: Soulstone Survivors: Prologue
addappid(2113430)
addappid(2113431, 1, "16c043f72d9b1329ff34d1278a57d82b7c0ab77d2acfbaa16aee7e141a627432")
addappid(2113432, 1, "a97397a718a74f5208a3e75b0e6d9786f08e40f326f5fc313c1548c9a83e054d")
addappid(2113433, 1, "ec4070c53c4103a77f1f6bd63d772c3cad129267ba1e0a531e7f4a3c1eb1afd6")
