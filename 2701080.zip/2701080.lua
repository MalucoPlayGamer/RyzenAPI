-- Lua provided by RyzenAPI 
-- Game: Intoxicated Driver
addappid(2701080)
addappid(2701081, 1, "5c99ee7ed7bfc54a2e5948d97bae477f51fdb1d7da591e6394812642f9e25bbb")
