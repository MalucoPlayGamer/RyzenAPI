-- Lua provided by RyzenAPI
-- Game: AppID 2119830

-- MAIN APPLICATION
addappid(2119830)
addappid(4119690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119831, 1, "2322e54a5ba6afee939e05b81bdc7b5477adee6b3ef54dcab5d2ccc32243c086")

