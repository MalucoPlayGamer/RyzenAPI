-- Lua provided by RyzenAPI
-- Game: Game: SUCCUBUS: Prologue

-- MAIN APPLICATION
addappid(1344350)
-- Game: addappid(1344350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344351, 1, "7438f7e16f13eeff2663eae9bf57077350ad22a8e0bf14b8f2c4016c868ca157")
