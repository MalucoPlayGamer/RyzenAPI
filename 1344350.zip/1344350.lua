-- Lua provided by SkyAPI 
-- Game: SUCCUBUS: Prologue
addappid(1344350)
addappid(1344351, 1, "7438f7e16f13eeff2663eae9bf57077350ad22a8e0bf14b8f2c4016c868ca157")
