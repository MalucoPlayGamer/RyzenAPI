-- Lua provided by RyzenAPI
-- Game: SUCCUBUS: Prologue

-- MAIN APPLICATION
addappid(1344350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1344351, 1, "7438f7e16f13eeff2663eae9bf57077350ad22a8e0bf14b8f2c4016c868ca157")

