-- Lua provided by RyzenAPI
-- Game: Catlateral Damage

-- MAIN APPLICATION
addappid(329860)
-- Game: addappid(329860)

-- MAIN APP DEPOTS / PACKAGES
addappid(329861, 1, "68cf5f1681b8575885350a4f12c363368eefb2f2f2346fca555d5f767bcda5d0")
addappid(329862, 1, "f933f53b2a346f126c799abad076404d75e6d5a563ed723e2bf26aabf25dff16")
addappid(329863, 1, "5257d78d5e7f8fb3444dd9346a3f46a86b2c1120f2c6f3441d466b0bb3fc69ca")
addappid(329864, 1, "1ea04f387eea46c2a2543c7c1e5d702f0b7b6114cc6cecae703a171213b82c25")
addappid(474720, 0, "ae0781278b13ee27e2333cbd81a5fc20e2edc6a46a33a5a884510f6a041431d1")
