-- Lua provided by RyzenAPI
-- Game: 867420

-- MAIN APPLICATION
addappid(867420)
-- Game: addappid(867420)

-- MAIN APP DEPOTS / PACKAGES
addappid(867421, 1, "04dd1145544cae6cabf32c4dd5c25330ef9ee884a7f7c76a3b3c01f1482b5ed8")
