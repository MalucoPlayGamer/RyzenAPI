-- Lua provided by RyzenAPI 
-- Game: Campus Legends College Basketball
addappid(3126980)
addappid(3126981, 1, "c4076abee915984e5d1092c0d8cb7686739fde6afc96228db8a1304b069aed14")
