-- Lua provided by RyzenAPI
-- Game: addappid(2172870)

-- MAIN APPLICATION
addappid(2172870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172871, 1, "cd9f8ad243847d9e526081f4fa4c57d5c1e11bbf10139551aa0fc45b7f909d15")
