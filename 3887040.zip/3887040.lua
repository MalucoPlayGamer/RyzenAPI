-- Lua provided by RyzenAPI
-- Game: 3887040

-- MAIN APPLICATION
addappid(3887040)
-- Game: addappid(3887040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3887041, 1, "c5e181b48ca38e389229d1beafcd0865ea4ee3c3a66212f3d1e625dc9e04888d")
