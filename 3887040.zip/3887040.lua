-- Lua provided by SkyAPI 
-- Game: Office 5
addappid(3887040)
addappid(3887041, 1, "c5e181b48ca38e389229d1beafcd0865ea4ee3c3a66212f3d1e625dc9e04888d")
