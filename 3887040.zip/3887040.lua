-- Lua provided by RyzenAPI
-- Game: Office 5

-- MAIN APPLICATION
addappid(3887040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3887041, 1, "c5e181b48ca38e389229d1beafcd0865ea4ee3c3a66212f3d1e625dc9e04888d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
