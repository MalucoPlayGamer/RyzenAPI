-- Lua provided by RyzenAPI
-- Game: 异世界的无厘头生活

-- MAIN APPLICATION
addappid(1300160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300161, 1, "478e977e482eac7731ca72f82f4afa71327261f151cefb3ec44f0d9f063965ae")
addappid(1302060, 0, "0dbc7a6aa71424a08833db7b0ff2bdaead0a5e2c30b470b65a7b7a5e2bed256e")
