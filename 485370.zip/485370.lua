-- Lua provided by RyzenAPI
-- Game: addappid(485370)

-- MAIN APPLICATION
addappid(485370)

-- MAIN APP DEPOTS / PACKAGES
addappid(485371, 1, "0d0d7279ba11de3218453d72884506869cec50d77192f04187584ccfe31855e3")
addappid(485372, 1, "6ee57d18b940ef9dcb3f2b645ee2f39bc76cbcb3cdb3b0b55c51f22278d427bc")
