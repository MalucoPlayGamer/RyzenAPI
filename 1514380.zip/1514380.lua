-- Lua provided by RyzenAPI
-- Game: Game: COGEN: Sword of Rewind / COGEN: 大鳥こはくと刻の剣

-- MAIN APPLICATION
addappid(1514380)
-- Game: addappid(1514380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514381, 1, "d85f9fc72eb520ce836a9079038c1550003690a1c05a6086056912574f2820fd")
