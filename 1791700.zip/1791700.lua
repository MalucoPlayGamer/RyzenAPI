-- Lua provided by RyzenAPI
-- Game: Kingdoms Conquer / 攻城天下

-- MAIN APPLICATION
addappid(1791700)
-- Game: addappid(1791700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791701, 1, "3a7b0f7245cdd76443b5cefacfb0edfd0a5117c52847bd74531cbf333c2f8c05")
