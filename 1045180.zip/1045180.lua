-- Lua provided by RyzenAPI
-- Game: Game: Shattered - Tale of the Forgotten King

-- MAIN APPLICATION
addappid(1045180)
-- Game: addappid(1045180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045181, 1, "bf3255fc1c4d2285bf108751f5f98c554eb37200a013f4e323b562f49aa1025a")
