-- Lua provided by RyzenAPI
-- Game: Shattered - Tale of the Forgotten King

-- MAIN APPLICATION
addappid(1045180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1045181, 1, "bf3255fc1c4d2285bf108751f5f98c554eb37200a013f4e323b562f49aa1025a")

