-- Lua provided by RyzenAPI 
-- Game: Hovercars 3077: Underground racing
addappid(1793420)
addappid(1793421, 1, "fb4b2e6fe5508e198e3108140afd5d2a624b79b2096d545e8d9d1cb81200310a")
addappid(1793422, 1, "3fba293a0b1b8425bf6b77e854942595dc2c3ab3f4fccaf1216ae4e0ad20dedb")
addappid(1793423, 1, "a0266da027370dbda8c900483a47d00c1a12c7025d35a9bf55981a406b6ddabf")
addappid(1793424, 1, "b332fc880c15e64057666d631ca286808481efb8e1011edacc9774aca3a86ac9")
