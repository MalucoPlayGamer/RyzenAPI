-- Lua provided by RyzenAPI
-- Game: Game: AppID 875340

-- MAIN APPLICATION
addappid(875340)
-- Game: addappid(875340)

-- MAIN APP DEPOTS / PACKAGES
addappid(875341, 1, "7dad83ab4829d74761abb9009c60499ad7e68e3674f09cbb30a99595fc670fb8")
