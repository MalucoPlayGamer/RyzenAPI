-- Lua provided by RyzenAPI
-- Game: AppID 875340

-- MAIN APPLICATION
addappid(875340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(875341, 1, "7dad83ab4829d74761abb9009c60499ad7e68e3674f09cbb30a99595fc670fb8")

