-- Lua provided by RyzenAPI
-- Game: addappid(2469750)

-- MAIN APPLICATION
addappid(2469750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469754,0,"7680ff33edf98e86fb131ffad64d7b2c1f8133c4cf432b0106dfe7288ad8f000")
