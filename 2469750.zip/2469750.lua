-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2469750)
-- Game: addappid(2469750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469754,0,"7680ff33edf98e86fb131ffad64d7b2c1f8133c4cf432b0106dfe7288ad8f000")
