-- Lua provided by RyzenAPI
-- Game: Muv-Luv Alternative

-- MAIN APPLICATION
addappid(802890)
addappid(2334110)
addappid(2362970)
addappid(2399240)
addappid(2399320)
addappid(2630270)
addappid(2630280)
addappid(3412870)
addappid(3412880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(802891, 1, "215b79691c91bb3febf20e9414071a595326d848a6b185b514342af033166d19")
addappid(1251940, 0, "2f32ae60d8c9c86ab1eb6b8d03f790c7e218c63113b5afd0c512795eadd94308")
addappid(1987170, 0, "1d80b563e27c56546f6d81b36c777d90f9f44c89fa559e0414541852cfc318f8")

