-- Lua provided by SkyAPI 
-- Game: Live2D Models of Project Beril
addappid(2247940)
addappid(2247941, 1, "0fedfe7609d67ae1008828c7749d10a89c24fd9a9822c3face7f2a3c99b92d68")
