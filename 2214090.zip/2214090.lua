-- Lua provided by RyzenAPI
-- Game: Hyper Shapes

-- MAIN APPLICATION
addappid(2214090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214091, 1, "a5e9c6768823db50a80c8bc1e11b82ed95aadc0f8c26ff48dcb2502d9f036aec")

