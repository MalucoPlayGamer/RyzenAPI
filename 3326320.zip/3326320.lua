-- Lua provided by RyzenAPI
-- Game: Blitzthera Playtest

-- MAIN APPLICATION
addappid(3326320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326321, 1, "1ee7e3c983ee5b1b2922905a32a594f5f3263063b0b218145003d53bb9a7cae5")
