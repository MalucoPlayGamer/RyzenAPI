-- Lua provided by SkyAPI 
-- Game: Blitzthera Playtest
addappid(3326320)
addappid(3326321, 1, "1ee7e3c983ee5b1b2922905a32a594f5f3263063b0b218145003d53bb9a7cae5")
