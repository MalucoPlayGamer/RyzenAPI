-- Lua provided by RyzenAPI
-- Game: PUZZLE: ULTIMATE

-- MAIN APPLICATION
addappid(1079720)
addappid(1084950)
addappid(1084960)
addappid(1100330)
addappid(1124590)
addappid(1124930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079721, 1, "a77a6e77e5217d6e9746d75c0e7d4c8c060a79b859e1fc49e2788781f355814e")
