-- Lua provided by RyzenAPI
-- Game: AppID 1471120

-- MAIN APPLICATION
addappid(1471120)
-- Game: addappid(1471120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471121, 1, "64486fdee7d25b588331fc3ba65bacc12e89ea39547ed6d5052d247b5494c877")
