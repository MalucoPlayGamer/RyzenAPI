-- Lua provided by RyzenAPI
-- Game: Forbidden Planet

-- MAIN APPLICATION
addappid(434610)
addappid(491300)

-- MAIN APP DEPOTS / PACKAGES
addappid(434611, 1, "e73938814bb302be29b5db5bb545e0705556d7354f6e628d2e24d28d5d62ea56")
