-- Lua provided by SkyAPI 
-- Game: AppID 434610
addappid(434610)
addappid(434611, 1, "e73938814bb302be29b5db5bb545e0705556d7354f6e628d2e24d28d5d62ea56")
addappid(491300)
