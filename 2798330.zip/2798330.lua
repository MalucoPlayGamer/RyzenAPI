-- Lua provided by RyzenAPI
-- Game: Dungeon Settlers

-- MAIN APPLICATION
addappid(2798330) -- Dungeon Settlers

-- MAIN APP DEPOTS / PACKAGES
addappid(2798331, 1, "e9e6cfc71635a146bb6da13c0f181d3466b7ddcd63665ebf1138d568ca5b5622") -- Depot 2798331

