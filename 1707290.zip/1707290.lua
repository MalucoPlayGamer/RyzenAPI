-- Lua provided by RyzenAPI
-- Game: addappid(1707290)

-- MAIN APPLICATION
addappid(1707290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707291, 1, "31a4a03fb8b872e116846eb326470ae4cd2c290c7d9cf27ccd26078e99e3b1d8")
