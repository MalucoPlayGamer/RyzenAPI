-- Lua provided by RyzenAPI 
-- Game: HUDDAM 2 BERZAH
addappid(3033500)
addappid(3033501, 1, "3b8bb588a6d2368413adcf50e394af2a7f166709d9f2772a1e756fcc0901c3fb")
