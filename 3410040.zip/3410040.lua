-- Lua provided by RyzenAPI
-- Game: WildType

-- MAIN APPLICATION
addappid(3410040)
-- Game: addappid(3410040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410043,0,"196266c62157c47b09ea6623126be059d3f86c88826b1c4f91020bd19a99b1d4")
