-- Lua provided by RyzenAPI
-- Game: addappid(2904040)

-- MAIN APPLICATION
addappid(2904040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904041, 1, "5f2fc48115edd9e7bfc1546f9dc43c8d900013aaf3d4f5035fb69ff28899f050")
