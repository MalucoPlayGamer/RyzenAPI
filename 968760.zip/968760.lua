-- Lua provided by RyzenAPI
-- Game: Game: AppID 968760

-- MAIN APPLICATION
addappid(968760)
-- Game: addappid(968760)

-- MAIN APP DEPOTS / PACKAGES
addappid(968761, 1, "a5c446b9163f69af963d3dd317a9466a37db26774085025544498550ddb1070d")
