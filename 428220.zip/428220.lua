-- Lua provided by RyzenAPI
-- Game: TurnOn

-- MAIN APPLICATION
addappid(428220)
-- Game: addappid(428220)

-- MAIN APP DEPOTS / PACKAGES
addappid(428221, 1, "c47244fa5d09e2bc5b1a44321c80cb1a99c4213fd582377d500c9bc6629fa8dc")
