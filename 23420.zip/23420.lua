-- Lua provided by RyzenAPI
-- Game: Europa Universalis: Rome - Gold Edition

-- MAIN APPLICATION
addappid(23420)

-- MAIN APP DEPOTS / PACKAGES
addappid(23421, 1, "124902a9464772f5598393ba64fddbe7677beb5741d92fea0457c0f91e148beb")
