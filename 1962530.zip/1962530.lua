-- Lua provided by RyzenAPI
-- Game: Game: The Hunsa Magic

-- MAIN APPLICATION
addappid(1962530)
-- Game: addappid(1962530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962531, 1, "f623d0e0d4e81cbfbd07d907011f1d564d377286948de519c74a250bbccf0c4c")
