-- Lua provided by RyzenAPI
-- Game: addappid(1599760)

-- MAIN APPLICATION
addappid(1599760)
addappid(1599761)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599762,0,"d9c476b8d0b865f8c1d68770cd0decab930614635b517cddbc1738d21925b309")
