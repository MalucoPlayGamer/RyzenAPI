-- Lua provided by RyzenAPI
-- Game: AppID 948680

-- MAIN APPLICATION
addappid(948680)
-- Game: addappid(948680)

-- MAIN APP DEPOTS / PACKAGES
addappid(948681, 1, "570d7b2578c10dd5bda006abb6d082ca36edb235c3199dd817d6d66bd3f71d3c")
addappid(948682, 1, "dd9ccf33ad4b95653fa4c14d267ac9c3b39791ba20088dae50d7804f213298c5")
addappid(948683, 1, "4aa195ea1741c34b8959f5623de844a063b5dfad2fdaa615438c5c44ccaa900f")
