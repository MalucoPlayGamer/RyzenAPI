-- Lua provided by RyzenAPI
-- Game: Cracking the Cryptic

-- MAIN APPLICATION
addappid(2085970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085971, 1, "53fa9429ce548b53911d495568fd550d7347f9b67fdc4614584aa582c8bd1f53")
addappid(2085972, 1, "d071974150a48041878519053f5e601b6e8428e1d210f91408b8ba4377c1bb87")
addappid(2085973, 1, "4898df1a179d09ccb4abdd80f3801bf623f231fa4d0169957e2688a58c516cf0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2096160)
addappid(2199960)
addappid(2363130)
addappid(2627750)
addappid(3165750)
addappid(3165770)
addappid(3794680)
addappid(3794690)
addappid(4020580)
addappid(4020590)
addappid(4133200)
addappid(4601580)
addappid(4756830)
