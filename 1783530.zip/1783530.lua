-- Lua provided by RyzenAPI
-- Game: addappid(1783530)

-- MAIN APPLICATION
addappid(1783530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783531, 1, "60a709223c6c0eb47fbfebf737b2e86e844b9b216da58f12257a248dc77f83dc")
