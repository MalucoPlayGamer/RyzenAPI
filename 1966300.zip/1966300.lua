-- Lua provided by RyzenAPI 
-- Game: Army of One
addappid(1966300)
addappid(1966301, 1, "5320ce346aeebb132b29550541f1d76dd66e71ac1dbe59188ecd3a60ac2950e6")
