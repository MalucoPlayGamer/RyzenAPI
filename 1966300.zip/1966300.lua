-- Lua provided by RyzenAPI
-- Game: Army of One

-- MAIN APPLICATION
addappid(1966300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1966301, 1, "5320ce346aeebb132b29550541f1d76dd66e71ac1dbe59188ecd3a60ac2950e6")

