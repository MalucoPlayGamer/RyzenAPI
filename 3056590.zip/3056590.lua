-- Lua provided by RyzenAPI
-- Game: Game: Swap Fire

-- MAIN APPLICATION
addappid(3056590)
-- Game: addappid(3056590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056591, 1, "597a497c2c30b68a214ea9dc9218dd0de0f03cdbdc0db7621badf0cb4d80e3da")
