-- Lua provided by RyzenAPI
-- Game: I'm a cowboy: Western Shooter

-- MAIN APPLICATION
addappid(1712120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712121, 1, "02f2614aeb969ab3299e22fbe0f1e4f8abc05809e8b493d2e896db15bf73cb99")

