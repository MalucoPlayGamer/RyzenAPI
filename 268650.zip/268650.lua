-- Lua provided by RyzenAPI
-- Game: AppID 268650

-- MAIN APPLICATION
addappid(268650)

-- MAIN APP DEPOTS / PACKAGES
addappid(268651, 1, "1b12fcb4281bf676e4c9f3ffff015cba3b5a54fe533342324fe8f54e1f9f7126")
addappid(268652, 1, "7f89cc4c85f41fd42e967f042e5c94ca71fab39ede20f86d2cfe56080f551132")
addappid(268654, 1, "2284988b922126c579e9abbbb9560c191ab1f010d625416f78961c48a614200c")
addappid(268655, 1, "9d0af0c64998540f2819c25ee0189908a3167c92a5fb7e96031a49c4312ef9ff")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1829380)
addappid(2288680)
