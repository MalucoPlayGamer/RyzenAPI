-- Lua provided by RyzenAPI
-- Game: Terra Nil Digital Artbook

-- MAIN APPLICATION
addappid(2321930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321930,0,"02757f56a474735a503289ae2b52ffb6aeda1c41eb2eec9b5e04bd596eca88d3")
addtoken(2321930,11175953412085981858)
