-- Lua provided by RyzenAPI
-- Game: Game: Lawnmower Game: Next Generation

-- MAIN APPLICATION
addappid(1346980)
-- Game: addappid(1346980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346981, 1, "cd5fab3240be101a968d05b66be7aee8862646a068e5e9d4901b7e82eabd1f56")
