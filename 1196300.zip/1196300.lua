-- Lua provided by RyzenAPI
-- Game: RTX Sweeper

-- MAIN APPLICATION
addappid(1196300)
-- Game: addappid(1196300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196302,0,"506492dafa9d0d972c45a2700d4261b398f3f8685e117db59c7ad621cdccf03a")
