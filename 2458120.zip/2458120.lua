-- Lua provided by RyzenAPI
-- Game: addappid(2458120)

-- MAIN APPLICATION
addappid(2458120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458121, 1, "2ef1b339110baba39999fccce5f19625906cb0439c1b5aa523d62e78c6a72855")
