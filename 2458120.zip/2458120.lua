-- Lua provided by RyzenAPI
-- Game: Mononeko: A Rhythm Adventure

-- MAIN APPLICATION
addappid(2458120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2458121, 1, "2ef1b339110baba39999fccce5f19625906cb0439c1b5aa523d62e78c6a72855")

