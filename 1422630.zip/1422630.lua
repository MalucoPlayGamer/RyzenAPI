-- Lua provided by RyzenAPI
-- Game: Active Neurons - Wonders Of The World

-- MAIN APPLICATION
addappid(1422630)

