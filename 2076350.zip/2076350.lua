-- Lua provided by RyzenAPI
-- Game: Game: 蜀山：初章 Playtest

-- MAIN APPLICATION
addappid(2076350)
-- Game: addappid(2076350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076351, 1, "7f0c6d2cbcc904f90ecfff3bcbf7d3b579c30bc06e64c8b7be63d81da2d8d173")
