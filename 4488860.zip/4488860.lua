-- Lua provided by RyzenAPI
-- Game: The Red Pearls Of Borneo

-- MAIN APPLICATION
addappid(4488860)
