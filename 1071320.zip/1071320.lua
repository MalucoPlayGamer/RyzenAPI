-- Lua provided by RyzenAPI
-- Game: Isle of the Dead

-- MAIN APPLICATION
addappid(1071320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1071321, 1, "b817c4030f6b3b103546febfd3ce71a05525259081054711b7faaf20316f2f3c")

