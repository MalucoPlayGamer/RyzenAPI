-- Lua provided by RyzenAPI
-- Game: Isle of the Dead

-- MAIN APPLICATION
addappid(1071320)
-- Game: addappid(1071320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071321, 1, "b817c4030f6b3b103546febfd3ce71a05525259081054711b7faaf20316f2f3c")
