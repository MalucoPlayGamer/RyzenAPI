-- 3004390's Lua and Manifest Created by Hubcap Manifest
-- The Cave Diver
-- Created: August 12, 2026 at 22:55:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3004390) -- The Cave Diver
-- MAIN APP DEPOTS
addappid(3004391, 1, "cfe7398a13a85036ac4251537f8140a1d042f4fc84920286c0730afda79a482d") -- Depot 3004391
setManifestid(3004391, "8455219515836602125", 516736440)