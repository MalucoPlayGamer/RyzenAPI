-- Lua provided by RyzenAPI
-- Game: The Cave Diver

-- MAIN APPLICATION
addappid(3004390) -- The Cave Diver

-- MAIN APP DEPOTS / PACKAGES
addappid(3004391, 1, "cfe7398a13a85036ac4251537f8140a1d042f4fc84920286c0730afda79a482d") -- Depot 3004391

