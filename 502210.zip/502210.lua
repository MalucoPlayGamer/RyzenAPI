-- Lua provided by RyzenAPI
-- Game: Super Markup Man

-- MAIN APPLICATION
addappid(502210)

-- MAIN APP DEPOTS / PACKAGES
addappid(502211, 1, "439e92c9d6bbe81d921ce9df11047501fa7c02c023a03c60263b31f6f7bee370")
addappid(502212, 1, "8f2688a54fc15af6eb20f7581b4fa8cf67cb7ac6a24f31f94bdcac84c0d4b487")
addappid(502213, 1, "3922515013b54049037915ab3fb412f94c11c0b8a0bdfd764895f8aa72ee2b01")

