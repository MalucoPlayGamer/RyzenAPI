-- Lua provided by RyzenAPI
-- Game: Astral Domine

-- MAIN APPLICATION
addappid(458990)

-- MAIN APP DEPOTS / PACKAGES
addappid(458991, 1, "7d6ffbced73167692f781711be0864a15c26f88cd1ee107c57d7ba9fcea19e13")
