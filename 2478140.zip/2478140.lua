-- Lua provided by RyzenAPI
-- Game: Twisted Lovestruck

-- MAIN APPLICATION
addappid(2478140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478141, 1, "ca22cedfc90f69598524cf4b28e9c0ec0465b9d4431bf680bb11f30d2690fe43")

