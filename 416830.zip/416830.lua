-- Lua provided by RyzenAPI
-- Game: 416830

-- MAIN APPLICATION
addappid(416830)
-- Game: addappid(416830)

-- MAIN APP DEPOTS / PACKAGES
addappid(416831, 1, "f8b18d2dc08955740b78ab6a6287fa7f394dcf71936bf0ec3efe1e24a2dd5ed7")
addappid(820590, 0, "27b56fa9a7e676d5ab2ca106d6109feb21df31540d14a2b4e5088b29b6b2630c")
