-- Lua provided by RyzenAPI
-- Game: Game: Streamer's Court

-- MAIN APPLICATION
addappid(2077800)
-- Game: addappid(2077800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077801, 1, "57fe0965658176dbc24cf1f21a30885a830aea9123208c2412935b1d151ea358")
