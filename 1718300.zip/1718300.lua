-- Lua provided by SkyAPI 
-- Game: Fallen Relics
addappid(1718300)
addappid(1718301, 1, "4d0b1735c9dbf9a491af5b638ea49a928126c0113acfd05cb6752a06586a5026")
