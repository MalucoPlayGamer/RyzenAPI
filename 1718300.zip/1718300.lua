-- Lua provided by RyzenAPI
-- Game: Fallen Relics

-- MAIN APPLICATION
addappid(1718300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718301, 1, "4d0b1735c9dbf9a491af5b638ea49a928126c0113acfd05cb6752a06586a5026")
