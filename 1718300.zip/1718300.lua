-- Lua provided by RyzenAPI
-- Game: Fallen Relics

-- MAIN APPLICATION
addappid(1718300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718301, 1, "4d0b1735c9dbf9a491af5b638ea49a928126c0113acfd05cb6752a06586a5026")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
