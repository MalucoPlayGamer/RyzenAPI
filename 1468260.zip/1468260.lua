-- Lua provided by SkyAPI 
-- Game: AppID 1468260
addappid(1468260)
addappid(1468261, 1, "cfa568d3359c46eb99cb43ab97a9ac8a4a873265ae44ffa2948a5d85f4a20055")
