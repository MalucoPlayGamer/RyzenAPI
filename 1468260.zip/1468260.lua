-- Lua provided by RyzenAPI
-- Game: 1468260

-- MAIN APPLICATION
addappid(1468260)
-- Game: addappid(1468260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468261, 1, "cfa568d3359c46eb99cb43ab97a9ac8a4a873265ae44ffa2948a5d85f4a20055")
