-- Lua provided by RyzenAPI
-- Game: Leaf Blower Revolution - Idle Game

-- MAIN APPLICATION
addappid(1468260)
addappid(1482630)
addappid(1482631)
addappid(1482632)
addappid(1873910)
addappid(2125730)
addappid(2239260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468261, 1, "cfa568d3359c46eb99cb43ab97a9ac8a4a873265ae44ffa2948a5d85f4a20055")
