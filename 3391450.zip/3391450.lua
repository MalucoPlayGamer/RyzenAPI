-- Lua provided by RyzenAPI
-- Game: 3391450

-- MAIN APPLICATION
addappid(3391450)
-- Game: addappid(3391450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391451, 1, "5ab57ce4fd569da078a76a2c5d2bf64d20cbe1af7b573f53dc3a86942da30a3c")
