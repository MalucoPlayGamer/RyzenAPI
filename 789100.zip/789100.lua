-- Lua provided by RyzenAPI
-- Game: 789100

-- MAIN APPLICATION
addappid(789100)
-- Game: addappid(789100)

-- MAIN APP DEPOTS / PACKAGES
addappid(789101, 1, "714fd3563b67a290e8fd6d19ddfc6840b119a408a9c007f426f9f8176fa8a11b")
