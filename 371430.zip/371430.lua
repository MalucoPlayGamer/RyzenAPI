-- Lua provided by RyzenAPI
-- Game: Space Grunts

-- MAIN APPLICATION
addappid(371430)

-- MAIN APP DEPOTS / PACKAGES
addappid(371431, 1, "5084ad6db8e70a9af60b3bfd1ea987628815b2c55086c0a6b830ff5276dd35d0")
