-- Lua provided by RyzenAPI
-- Game: 1266390

-- MAIN APPLICATION
addappid(1266390)
-- Game: addappid(1266390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266391, 1, "55205b690e26e0c57f9a2a4bb43ea0bfa7d33393df9de1da3c1919d1205f4ae6")
