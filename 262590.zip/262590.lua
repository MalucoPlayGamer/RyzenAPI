-- Lua provided by RyzenAPI
-- Game: Chuck's Challenge 3D 2020

-- MAIN APPLICATION
addappid(262590)
addappid(286991)
addappid(333700)
addappid(1406190)

-- MAIN APP DEPOTS / PACKAGES
addappid(262591, 1, "4484f469178edb25c6f196f5791c778d2194c38611624493fd72be0fae1ebdcf")
addappid(262592, 1, "39f153c3bc2907fea5b670080f66473244f9bc6763df143009afe1afb1e7893d")
addappid(262593, 1, "23996a07cfbcca5a29c4607466dfb1c8118945ef87a0655548d9ebccebe5420f")
addappid(286990, 0, "0faff36e6b87f9fe9f21069a50fb53035a812ad7e01cfb33e047abe6910c4e19")
