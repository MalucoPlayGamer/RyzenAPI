-- Lua provided by RyzenAPI
-- Game: dUpLicity ~Beyond the Lies~

-- MAIN APPLICATION
addappid(335690)

-- MAIN APP DEPOTS / PACKAGES
addappid(335691, 1, "dbe34764c224196aa464da289fc2760da2467fd4efa9803b6edb6097b6842799")
addappid(335692, 1, "fd61f6567d0aa55b5b5f497f61856fb0a70815f5bf3d545e7aa1d3740767aebf")
addappid(335693, 1, "d9a72d3b41d230438ff9d154c66fb41c0283dab26809937c0072ce97cb2ac918")
