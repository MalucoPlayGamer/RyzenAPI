-- Lua provided by RyzenAPI
-- Game: 2638240

-- MAIN APPLICATION
addappid(2638240)
-- Game: addappid(2638240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638241, 1, "e4aa64ef2e372a94542df6bfe2ed1e8fa5a9343613c29cdad88380695d63a933")
