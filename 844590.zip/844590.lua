-- Lua provided by RyzenAPI
-- Game: Hypnospace Outlaw

-- MAIN APPLICATION
addappid(844590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(844591, 1, "ed4fc1b2c4ee8f9017feba89413114a4042f9a743f3364ca4f628ac26d245f26")
addappid(844592, 1, "74246f1b6dda1e023079117320c1cdc8f1bf64a1332c9f94621be62b37c4e3d0")
addappid(844593, 1, "1c239c078d36a8fcc548aeb7a8eb5433921dc62c9a4141ad8b2bdb098f6625f9")
addappid(844594, 1, "3d4c79800cd2cb059cf44a410da83d2f6dd8d5c6af3a1a268168a85b7f4435a7")
addappid(844595, 1, "8debe98b8d53aa05cac841ae9f2b12b06071b86ec41166c69b533777b6e7b361")

