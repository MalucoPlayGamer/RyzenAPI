-- Lua provided by SkyAPI 
-- Game: Juniper Burning Playtest
addappid(3745070)
addappid(3745071, 1, "3e1d0c196926ce3c828bcaa68e235b12a82b98f359b38890b243234b2d6fb0bb")
