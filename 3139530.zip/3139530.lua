-- Lua provided by RyzenAPI
-- Game: 中年失业模拟器2-When a man lose his job 2

-- MAIN APPLICATION
addappid(3139530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3139531, 1, "a4a09da5e54bb25c4c2d9952fe2119edb4c12bb1e720a6da8436afccef67ac32")
