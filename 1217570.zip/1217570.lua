-- Lua provided by RyzenAPI
-- Game: Lessons with Chii-chan

-- MAIN APPLICATION
addappid(1217570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217571, 1, "0fca9b6c4b15a7720b72dc63cd44eafaa231e54891ce8a96822bec2577113d84")
