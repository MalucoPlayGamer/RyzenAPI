-- Lua provided by RyzenAPI
-- Game: Candy Machine

-- MAIN APPLICATION
addappid(581980)

-- MAIN APP DEPOTS / PACKAGES
addappid(581981, 1, "94aa6f6fa7e0f5a3b59a9a88833e87e2f427f78e71f1e224a73fce21822a51b7")
