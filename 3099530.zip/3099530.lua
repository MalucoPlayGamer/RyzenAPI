-- Lua provided by RyzenAPI
-- Game: addappid(3099530)

-- MAIN APPLICATION
addappid(3099530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099531, 1, "8137a0ae0eb513c0bb5383d6467229310967130adfa6aa224cd4f630c1a62d65")
