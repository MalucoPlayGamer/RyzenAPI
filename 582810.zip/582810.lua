-- Lua provided by RyzenAPI
-- Game: Awesome Metal Detecting

-- MAIN APPLICATION
addappid(582810)

-- MAIN APP DEPOTS / PACKAGES
addappid(582811, 1, "95a39d1674c5b840e1bb7f0bc8f2f3de7b7badd72f232fea39a46cebcd08db7d")

