-- Lua provided by RyzenAPI 
-- Game: Stepmom
addappid(2247490)
addappid(2247491, 1, "556217e0fa8d730b055ecf30cd1ff7ca9a84d62257dbf926c73bbc3549d29b87")
