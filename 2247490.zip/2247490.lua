-- Lua provided by RyzenAPI
-- Game: Game: Stepmom

-- MAIN APPLICATION
addappid(2247490)
-- Game: addappid(2247490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247491, 1, "556217e0fa8d730b055ecf30cd1ff7ca9a84d62257dbf926c73bbc3549d29b87")
