-- Lua provided by SkyAPI 
-- Game: Jazzpunk: Director's Cut
addappid(250260)
addappid(250261, 1, "e41ee24f8fe4f6752e6f9031a9bff87d60bdea0b2b140f184c214bfd2e97d737")
addappid(250262, 1, "4eb06dd4dbb5fadf237b93f9018e961a33cbc9db15f8dd8a8a369db46978d8cc")
addappid(250263, 1, "cb68f02e2a582d0620b455632ca09e7aa9293bd4446db73ce2592e2bc00ad901")
addappid(250264, 1, "37340d89f31079be84e9dc9b5e58e1b774c4dbedc91a4949a848a4b00fd32d9b")
addappid(649410, 0, "1c83509694eae6538f38282b9cd40457ab5447bc4318d8ef5ef37507e9bf0f69")
