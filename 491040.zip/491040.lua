-- Lua provided by RyzenAPI
-- Game: Bot Vice

-- MAIN APPLICATION
addappid(491040)

-- MAIN APP DEPOTS / PACKAGES
addappid(491041, 1, "cda334ca94270a7885ba9d213d0c234de4dc03caef5955e690332d401a9f96b3")
addappid(491042, 1, "93ee9a93cac2aa5509cfc193255420e319a0f080fe5af9274c83ec547dcfd6fe")
addappid(491043, 1, "2e42f981b0926b0550e8a4dce56cc4866ec16d628dbf000ebe6eb7a774d21be4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
