-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Burst Re:Newal

-- MAIN APPLICATION
addappid(889510)
-- Game: addappid(889510)

-- MAIN APP DEPOTS / PACKAGES
addappid(889511, 1, "8b9fef672efa78554a58dc355f467c32df5d12a571d409dd57a126f55037fa46")
addappid(925820, 0, "0e5f04a0f866effc26e513a6f17edb6f2a5d5ff055d948b035ad15dbce0dcd6d")
