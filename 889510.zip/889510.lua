-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Burst Re:Newal

-- MAIN APPLICATION
addappid(889510)
addappid(925820)
addappid(925821)
addappid(925822)
addappid(925823)
addappid(925824)
addappid(925825)
addappid(925826)
addappid(925827)
addappid(925828)
addappid(925829)
addappid(925850)
addappid(925851)
addappid(925852)
addappid(925853)
addappid(925854)
addappid(925855)
addappid(925856)
addappid(925857)
addappid(925858)
addappid(925859)
addappid(925860)
addappid(925861)
addappid(925862)
addappid(925863)
addappid(925864)
addappid(925865)
addappid(925866)
addappid(925867)
addappid(925868)
addappid(925869)
addappid(925870)
addappid(925871)
addappid(995290)

-- MAIN APP DEPOTS / PACKAGES
addappid(889511,0,"8b9fef672efa78554a58dc355f467c32df5d12a571d409dd57a126f55037fa46")
addappid(925820,0,"0e5f04a0f866effc26e513a6f17edb6f2a5d5ff055d948b035ad15dbce0dcd6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
