-- Lua provided by RyzenAPI
-- Game: Monster partner

-- MAIN APPLICATION
addappid(701620)

-- MAIN APP DEPOTS / PACKAGES
addappid(701621, 1, "f645cb8f6367959dfa95bbad63d87dc582074b37feb17516972d39a862b0f18f")
addappid(701622, 1, "292c1f1c8d54607e4d6e52735bf4f9b5b26e05e6b9ac70ba7b4f354dfbb591fd")
addappid(701623, 1, "8ecd4c3ad9a4a2099c56a4be9992cd111db67fddc328cc382016ccda0935da43")
addappid(701624, 1, "ee2341b1794e373e60a14b0c7b978502bb25048efb67ae673f8fa630e8814a7a")

