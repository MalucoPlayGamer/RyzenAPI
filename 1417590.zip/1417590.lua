-- Lua provided by RyzenAPI
-- Game: 1417590

-- MAIN APPLICATION
addappid(1417590)
-- Game: addappid(1417590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417591, 1, "2228edf720c558310ca6d90fc76a969c74abe6a51cc2ff96b0209261df708ad1")
