-- Lua provided by RyzenAPI
-- Game: addappid(1817690)

-- MAIN APPLICATION
addappid(1817690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817693,0,"f5ea911fff3fe0c74670ef672a6ed2c5f83d103202862cb23abe212a5f325a8e")
addappid(1817694,0,"83d1ccab1b0c557a28c46ae550a8a67f0c1720593a21b52abae760de5a73fd32")
