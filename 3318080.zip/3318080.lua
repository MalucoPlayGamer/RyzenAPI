-- Lua provided by RyzenAPI
-- Game: Grorb: Grow the Orb

-- MAIN APPLICATION
addappid(3318080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318081, 1, "df54cd12bc5db47f61fa2644a02d0658b26a7f1eccac7316f8f431176469f608")

