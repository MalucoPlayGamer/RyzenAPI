-- Lua provided by RyzenAPI
-- Game: Grorb: Grow the Orb

-- MAIN APPLICATION
addappid(3318080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3318081, 1, "df54cd12bc5db47f61fa2644a02d0658b26a7f1eccac7316f8f431176469f608")

