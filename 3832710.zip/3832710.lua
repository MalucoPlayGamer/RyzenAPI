-- Lua provided by RyzenAPI
-- Game: Cowgirl Maid Milk Cafe

-- MAIN APP DEPOTS / PACKAGES
addappid(3832710, 1, "00a64ccd07b5b3a98ebf3c4f27adf225af3baed8a763c0ddf3928de5ca90db01") -- Cowgirl Maid Milk Cafe
addappid(3832711, 1, "665dcfcfd4e44ac61ac374ded62e39d4021b39637653cbb7cf5db2cc8dcd0f6c") -- Depot 3832711

