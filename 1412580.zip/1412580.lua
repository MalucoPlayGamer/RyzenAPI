-- Lua provided by RyzenAPI 
-- Game: Sword of Destiny
addappid(1412580)
addappid(1412581, 1, "8b3af235a81c76f36cd00ce4212e36273b84f98729a5f56c950d56bf4e8f0e7b")
