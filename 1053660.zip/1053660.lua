-- Lua provided by RyzenAPI
-- Game: Chaos Starter

-- MAIN APPLICATION
addappid(1053660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053661, 1, "5f2ea28d7a64d2cbdf200fcd0cc9f44090752ff4b0dc24b340bfe1c0d8919378")
