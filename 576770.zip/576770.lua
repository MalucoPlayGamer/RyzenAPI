-- Lua provided by RyzenAPI
-- Game: Low Magic Age

-- MAIN APPLICATION
addappid(576770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(576771, 1, "519b7ba36b1280f253b6797384a781ec313b037da96c4aa3bc827c564a8bb8c4")

