-- Lua provided by RyzenAPI
-- Game: addappid(576770)

-- MAIN APPLICATION
addappid(576770)

-- MAIN APP DEPOTS / PACKAGES
addappid(576771, 1, "519b7ba36b1280f253b6797384a781ec313b037da96c4aa3bc827c564a8bb8c4")
