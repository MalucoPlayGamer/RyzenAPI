-- Lua provided by RyzenAPI
-- Game: Fearless Fantasy

-- MAIN APPLICATION
addappid(282100)
-- Game: addappid(282100)

-- MAIN APP DEPOTS / PACKAGES
addappid(282101, 1, "a746e9f1a6cba890be9ef34088ba6cbd916f62af9e49b6d47339d13474f9c4d5")
