-- Lua provided by RyzenAPI
-- Game: Tormentum - Dark Sorrow

-- MAIN APPLICATION
addappid(335000)
addappid(4876390)
-- Game: addappid(335000)

-- MAIN APP DEPOTS / PACKAGES
addappid(335001, 1, "e8062888fc0d10745bd745056c1711e238935006069395d1e9a6e29b24058745")
