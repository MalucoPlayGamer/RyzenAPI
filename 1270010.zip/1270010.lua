-- Lua provided by RyzenAPI 
-- Game: Gone: Survival
addappid(1270010)
addappid(1270011, 1, "4314327ce19e551613491c62c62c0ea87281a3f274c23502695d3be7f096374e")
