-- Lua provided by RyzenAPI
-- Game: Battle Babes

-- MAIN APPLICATION
addappid(2787350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787351, 1, "98a98931e9ff8d0cc4db19d1eefc312f99c94b66c2843d7b9b2056d2eefad644")
