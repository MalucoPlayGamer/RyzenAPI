-- Lua provided by RyzenAPI
-- Game: Battle Babes

-- MAIN APPLICATION
addappid(2787350)
addappid(2813920)
addappid(2841440)
addappid(2966440)
addappid(2984960)
addappid(3015490)
addappid(3158520)
addappid(3247530)
addappid(3449180)
addappid(3494650)
addappid(3495530)
addappid(3495540)
addappid(3495550)
addappid(3495560)
addappid(3495590)
addappid(3495610)
addappid(3495620)
addappid(3495650)
addappid(3495680)
addappid(3495690)
addappid(3495720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787351, 1, "98a98931e9ff8d0cc4db19d1eefc312f99c94b66c2843d7b9b2056d2eefad644")

