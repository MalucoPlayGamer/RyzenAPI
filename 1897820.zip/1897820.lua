-- Lua provided by RyzenAPI
-- Game: Game: Pirate Booty and the Bukkake Buccaneer

-- MAIN APPLICATION
addappid(1897820)
-- Game: addappid(1897820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897821, 1, "bbf8ed1eeec0491d3cface6765d59c0789c4b2c5d7d104135577d101890368c7")
