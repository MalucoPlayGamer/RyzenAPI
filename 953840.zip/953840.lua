-- Lua provided by RyzenAPI
-- Game: Apollo 11 VR HD

-- MAIN APPLICATION
addappid(953840)

-- MAIN APP DEPOTS / PACKAGES
addappid(953841, 1, "77db053da4083939af173e5992ca5b6b37942b5277bac5fc083a4b11c73cd16d")

