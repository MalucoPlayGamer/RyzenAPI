-- Lua provided by RyzenAPI
-- Game: Apollo 11 VR HD

-- MAIN APPLICATION
addappid(953840)

-- MAIN APP DEPOTS / PACKAGES
addappid(953841, 1, "77db053da4083939af173e5992ca5b6b37942b5277bac5fc083a4b11c73cd16d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
