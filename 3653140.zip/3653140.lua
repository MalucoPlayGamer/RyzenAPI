-- Lua provided by RyzenAPI
-- Game: 3653140

-- MAIN APPLICATION
addappid(3653140)
-- Game: addappid(3653140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653141, 1, "d1f30148f08a5d0a053e514090397b3f2d6cf150cd3f3432af9749e79b0d61ef")
