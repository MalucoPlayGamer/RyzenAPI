-- Lua provided by RyzenAPI
-- Game: Game: Slave Princess Finne ~ IF Story 1

-- MAIN APPLICATION
addappid(2311550)
-- Game: addappid(2311550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311551, 1, "932eb05c0635f023291c63097706369cd979b3da6d8ed664601a4c3a7b5f15ba")
