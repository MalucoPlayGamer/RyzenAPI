-- Lua provided by SkyAPI 
-- Game: Slave Princess Finne ~ IF Story 1
addappid(2311550)
addappid(2311551, 1, "932eb05c0635f023291c63097706369cd979b3da6d8ed664601a4c3a7b5f15ba")
