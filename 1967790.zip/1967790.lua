-- Lua provided by RyzenAPI
-- Game: Nickelodeon All-Star Brawl - Hugh Neutron Brawler Pack

-- MAIN APPLICATION
addappid(1967790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967790,0,"4456fb88af61c6e7de66d357e1e47a4aff6faf491b779110fbbae688f4d23ec0")

