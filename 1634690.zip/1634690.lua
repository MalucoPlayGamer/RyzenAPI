-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Special Costume - Nobunaga Oda

-- MAIN APPLICATION
addappid(1634690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634690,0,"65ea005dae87fb5522ff04be83d50767d114c5c5eb16d4af6adab84c5a803c50")

