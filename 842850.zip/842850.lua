-- Lua provided by RyzenAPI
-- Game: AppID 842850

-- MAIN APPLICATION
addappid(842850)
-- Game: addappid(842850)

-- MAIN APP DEPOTS / PACKAGES
addappid(842851, 1, "fcbeeb329e771a76e33386f509dec2c6da0f29323fba646d95fedbcbdd7b5d77")
addappid(842855, 1, "41a6e2f88e7a77f25f647b838e2df86037acfe5414a2b7dd265922f394da22a0")
