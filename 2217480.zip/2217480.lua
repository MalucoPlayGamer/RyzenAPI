-- Lua provided by RyzenAPI
-- Game: 2217480

-- MAIN APPLICATION
addappid(2217480)
-- Game: addappid(2217480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217480,0,"860118abb9d1e13ef7e22c102734eadaa2e6a742ef7c32b792ba82e1b58b8a19")
