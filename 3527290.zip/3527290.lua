-- Lua provided by RyzenAPI
-- Game: Game: PEAK

-- MAIN APPLICATION
addappid(3527290)
-- Game: addappid(3527290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05")
