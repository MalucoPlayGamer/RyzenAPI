-- Lua provided by RyzenAPI 
-- Game: PEAK
addappid(3527290)
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05")
