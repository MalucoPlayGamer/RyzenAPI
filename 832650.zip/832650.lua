-- Lua provided by RyzenAPI
-- Game: Royal Adventure

-- MAIN APPLICATION
addappid(832650)

-- MAIN APP DEPOTS / PACKAGES
addappid(832651,0,"14eb2a42f06c0637cd49ae116151cf09ddd2ef3c2db8aae70bc85ec91a293447")
addappid(832652,0,"59d8dc007a17035771a8d89504c37875ba6a893df7581e15b434dde38cdcf590")

