-- Lua provided by RyzenAPI
-- Game: Game: Godsvivors

-- MAIN APPLICATION
addappid(2441080)
-- Game: addappid(2441080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441081, 1, "4bab8b677b6a1ff3e4c73c6ee6745647690ccb717c8bf4704935fb20584adaa9")
