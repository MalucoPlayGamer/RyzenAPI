-- Lua provided by RyzenAPI
-- Game: addappid(3039350)

-- MAIN APPLICATION
addappid(3039350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039351, 1, "6eabb1ab921fe317e1b791c636a4363737a15d49be627e83adb28a16730c0ba4")
