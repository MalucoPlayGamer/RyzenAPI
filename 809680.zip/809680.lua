-- Lua provided by RyzenAPI
-- Game: Panzer Hearts - War Visual Novel

-- MAIN APPLICATION
addappid(809680)
addappid(836730)

-- MAIN APP DEPOTS / PACKAGES
addappid(809681,0,"0eb1f27b71c037cf68e7f6f5c9e3e4e6675a3293c739541179b51e65bc92a530")
addappid(809682,0,"5c8039d4cfba836fdc64ea2054d98f4ed3d85e5c52336fd44d2d42826fab2e8e")
addappid(809684,0,"a6df51baf41f0338e2025afc9d684cb7122bff342614da6b5f1a6ba80c9556fe")

