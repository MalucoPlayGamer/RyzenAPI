-- Lua provided by RyzenAPI 
-- Game: AppID 1031970
addappid(1031970)
addappid(1031971, 1, "5b4a1a6d04490f6db1fcad0e7701f4d20e7ed94cc3aea496220e25d48802cb42")
