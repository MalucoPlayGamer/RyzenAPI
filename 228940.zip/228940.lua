-- Lua provided by RyzenAPI
-- Game: AppID 228940

-- MAIN APPLICATION
addappid(228940)
addappid(228983)

-- MAIN APP DEPOTS / PACKAGES
addappid(228941, 1, "c4625ef5beb6d6eba986e2991318133e5a6c1fbcb7e7f0da9b13ab3a91f3c184")
addappid(228942, 1, "18ef642b670cd7b9aa5f2960cccfdad0b31236b677d767c3848b22841de7eea9")
