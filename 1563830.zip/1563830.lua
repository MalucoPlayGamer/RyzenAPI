-- Lua provided by RyzenAPI
-- Game: 1563830

-- MAIN APPLICATION
addappid(1563830)
-- Game: addappid(1563830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563831, 1, "a4f2b1619942e8cf49eae1a43aacef1e9b543a17a7cf917c89f1d19e33b12ba1")
