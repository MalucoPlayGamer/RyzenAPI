-- Lua provided by RyzenAPI
-- Game: Femdom Wife Game - Zoe

-- MAIN APPLICATION
addappid(2018230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018231, 1, "c6e59b240567a89fcea1176567ade45940aff3f1bd5040264bb41a7c95fa7d00")

