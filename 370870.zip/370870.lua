-- Lua provided by RyzenAPI
-- Game: Dark Future: Blood Red States

-- MAIN APPLICATION
addappid(370870)
addappid(1084700)
addappid(1084701)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(370871, 1, "19a10d1edd8ff00afe1e2599c99dbc6df6a052713f8d0910b3f8a0367b5fabcf")

