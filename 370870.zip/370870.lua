-- Lua provided by RyzenAPI
-- Game: Game: AppID 370870

-- MAIN APPLICATION
addappid(370870)
addappid(1084700)
addappid(1084701)
-- Game: addappid(370870)

-- MAIN APP DEPOTS / PACKAGES
addappid(370871, 1, "19a10d1edd8ff00afe1e2599c99dbc6df6a052713f8d0910b3f8a0367b5fabcf")
