-- Lua provided by RyzenAPI
-- Game: THRESHOLD

-- MAIN APPLICATION
addappid(2580020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580021, 1, "bbd75594b7799d37c31729e55cdc657ed45d85a6193c54f47c0c9f04b350f7dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
