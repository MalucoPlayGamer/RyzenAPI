-- Lua provided by RyzenAPI
-- Game: Game: THRESHOLD

-- MAIN APPLICATION
addappid(2580020)
-- Game: addappid(2580020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580021, 1, "bbd75594b7799d37c31729e55cdc657ed45d85a6193c54f47c0c9f04b350f7dd")
