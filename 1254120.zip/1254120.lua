-- Lua provided by RyzenAPI
-- Game: Bless Unleashed

-- MAIN APPLICATION
addappid(1254120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254121, 1, "d7c81a003fad8e4a9af6266d17bf4d24f5bbf9dc226128750e5f879aa96ed421")
addappid(1254122, 1, "d5110d95340eb0da0c7bf52c1fe55a18b1eb2bfc78808c9d6b0db54fd6060b6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1751040)
addappid(1751050)
