-- Lua provided by SkyAPI 
-- Game: Bless Unleashed
addappid(1254120)
addappid(1254121, 1, "d7c81a003fad8e4a9af6266d17bf4d24f5bbf9dc226128750e5f879aa96ed421")
addappid(1254122, 1, "d5110d95340eb0da0c7bf52c1fe55a18b1eb2bfc78808c9d6b0db54fd6060b6f")
