-- Lua provided by RyzenAPI
-- Game: AppID 1023550

-- MAIN APPLICATION
addappid(1023550)
addappid(1176980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023551, 1, "3358db2d980e995b805cb4cab1638437d2674bfb44f3f3c0b192d757d2dcc6b5")

