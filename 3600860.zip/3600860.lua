-- Lua provided by RyzenAPI
-- Game: TheLostVillage - Peerless Sect for Beta Testing

-- MAIN APPLICATION
addappid(3600860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600860,0,"0a7688ca5818fb37401d2e52695c01778e352644ff6e5f37c434fbc42bb93784")

