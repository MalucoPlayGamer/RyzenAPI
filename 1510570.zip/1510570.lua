-- Lua provided by RyzenAPI
-- Game: Game: Toy Tinker Simulator: Prologue

-- MAIN APPLICATION
addappid(1510570)
-- Game: addappid(1510570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510571, 1, "339b48442632af49bc2ed143c234023296aa2942da8e253864fabf5f2f73135b")
