-- Lua provided by RyzenAPI
-- Game: Toy Tinker Simulator: Prologue

-- MAIN APPLICATION
addappid(1510570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1510571, 1, "339b48442632af49bc2ed143c234023296aa2942da8e253864fabf5f2f73135b")

