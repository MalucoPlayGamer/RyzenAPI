-- Lua provided by RyzenAPI
-- Game: Game: Nothing

-- MAIN APPLICATION
addappid(1534200)
-- Game: addappid(1534200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534201, 1, "b2ffc12fa111fc293ac5c9c22ae8ac3566a38fcbd12e05147ea1084fe6e96bce")
