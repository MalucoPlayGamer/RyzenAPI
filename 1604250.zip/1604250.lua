-- Lua provided by RyzenAPI
-- Game: Tortuga - A Pirate's Tale

-- MAIN APPLICATION
addappid(1604250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604251, 1, "41284e414962939427477166b3a4d0c7e600b8566092e813dc3d0cbf40c979fd")
addappid(1604252, 1, "31a01030d19a45b3cdef82936e66a8888278c59b4c79e48a3d7d70d8ce397659")
addappid(1604253, 1, "78fa27344ed2d161fcecb79db64753384f6a78b19cf605c8ead8eebbdf2f383d")
addappid(1604255, 1, "cb62da326a47cb929c08894ce6ba48029e65f6500cff7c1e3212738b54b9f415")
addappid(1604256, 1, "e50b736d3d2db06d0fef893b2eac02d80c5a5664707a23aca24e29a2c6371bc6")
addappid(2153271, 0, "93f4a5c8460b3b6d29dab7243ba7e016f7d53d1639e3e3152db766b1f65fb11d")
addappid(2153272, 0, "0546fcf374c390452e76b85525ed1b881cba37bdc89386948c663154e98a1beb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
