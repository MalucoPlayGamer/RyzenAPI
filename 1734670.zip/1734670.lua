-- Lua provided by RyzenAPI
-- Game: Magic Girl Fal

-- MAIN APPLICATION
addappid(1734670)
addappid(1734671)
addappid(1734672)
addappid(1734674)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734673,0,"6c8c86b3f2a8318ccc7445ea644611267c08f7ae453b553b82f41aff55eff05f")
addtoken(1734670,12954005093553305845)

