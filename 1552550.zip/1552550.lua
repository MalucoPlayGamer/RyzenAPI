-- Lua provided by SkyAPI 
-- Game: AppID 1552550
addappid(1552550)
addappid(1552551, 1, "d24eab04f7b33d4268a45d0542c108b481464e503120245df2cb853a256c1928")
