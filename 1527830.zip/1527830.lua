-- Lua provided by RyzenAPI
-- Game: Game: Gate to Site 8

-- MAIN APPLICATION
addappid(1527830)
-- Game: addappid(1527830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527831, 1, "8743f20c4c96f5e663e1b04e3d8535917f8915801b7c0ff852077fa3b24a9cd2")
