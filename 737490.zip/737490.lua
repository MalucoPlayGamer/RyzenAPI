-- Lua provided by RyzenAPI
-- Game: Journey to Luonto

-- MAIN APPLICATION
addappid(737490)

-- MAIN APP DEPOTS / PACKAGES
addappid(737491, 1, "662294a5c5c0028d8f325a5af022a161107e3e9249d170890210f2e69c78d8c0")

