-- Lua provided by RyzenAPI
-- Game: addappid(1766180)

-- MAIN APPLICATION
addappid(1766180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766181, 1, "1db5b00d45c79005954f47b93e6c5085f3ec0a4af6b6f83578fc02a2873f804b")
