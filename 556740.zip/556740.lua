-- Lua provided by RyzenAPI
-- Game: LEGRAND LEGACY: Tale of the Fatebounds

-- MAIN APPLICATION
addappid(556740)
addappid(793910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(556741, 1, "766f62e355be6178df7c872df2e6c0144932e003f4e6e65224ad6f52b5bbe122")

