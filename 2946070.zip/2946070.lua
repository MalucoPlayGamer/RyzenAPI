-- Lua provided by SkyAPI 
-- Game: Descent the Abyss
addappid(2946070)
addappid(2946071, 1, "edf4d93085718c52c930174b16dddbc78300fdf33a2a7b36b7e943944a8de690")
