-- Lua provided by RyzenAPI
-- Game: Game: Descent the Abyss

-- MAIN APPLICATION
addappid(2946070)
-- Game: addappid(2946070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946071, 1, "edf4d93085718c52c930174b16dddbc78300fdf33a2a7b36b7e943944a8de690")
