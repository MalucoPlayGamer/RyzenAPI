-- Lua provided by RyzenAPI
-- Game: Fursan al-Aqsa: The Knights of the Al-Aqsa Mosque

-- MAIN APPLICATION
addappid(1714420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1714421, 1, "c3f26046df5d0e37d19336e829d109041ecedcb2f2f613e45cc3ce2ef13668e3")

