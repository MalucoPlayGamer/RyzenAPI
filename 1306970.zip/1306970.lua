-- Lua provided by SkyAPI 
-- Game: AppID 1306970
addappid(1306970)
addappid(1306971, 1, "5979b22ddc96c941cae9d7b0a6f107b4209ee8a1ae25a50df40536276ab5a9d0")
addappid(1306972, 1, "080563ea32f6d2adee2f02ed6bf4d9b13ca5ef69ca09b56c3c13519f6ea26916")
