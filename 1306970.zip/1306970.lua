-- Lua provided by RyzenAPI
-- Game: AppID 1306970

-- MAIN APPLICATION
addappid(1306970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306971, 1, "5979b22ddc96c941cae9d7b0a6f107b4209ee8a1ae25a50df40536276ab5a9d0")
addappid(1306972, 1, "080563ea32f6d2adee2f02ed6bf4d9b13ca5ef69ca09b56c3c13519f6ea26916")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
