-- Lua provided by RyzenAPI
-- Game: 3180260

-- MAIN APPLICATION
addappid(3180260)
-- Game: addappid(3180260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180261, 1, "487e53def7c9a6ceacaf4a5bf3cabe8696016e9ad8c99017cc259e566c97df37")
