-- Lua provided by RyzenAPI
-- Game: My So-called Future Girlfriend

-- MAIN APPLICATION
addappid(976420)

-- MAIN APP DEPOTS / PACKAGES
addappid(976422,0,"640946f24e558d7e25172562df618ceb82fa5a291e096a25463f6f997cab5138")
