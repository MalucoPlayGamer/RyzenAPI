-- Lua provided by RyzenAPI
-- Game: Phonk Cats

-- MAIN APPLICATION
addappid(2430790)
-- Game: addappid(2430790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430791, 1, "44913f442a497309d757ea9e009dc959660133085d681a33b3d3b4eb7021d095")
