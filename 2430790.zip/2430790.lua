-- Lua provided by SkyAPI 
-- Game: Phonk Cats
addappid(2430790)
addappid(2430791, 1, "44913f442a497309d757ea9e009dc959660133085d681a33b3d3b4eb7021d095")
