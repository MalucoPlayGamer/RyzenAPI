-- Lua provided by RyzenAPI
-- Game: AppID 1240950

-- MAIN APPLICATION
addappid(1240950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240951, 1, "aad665aebb968b76350732c5da5bfdbd100c2e70e91bdbcdca9c28f2fba0dff3")
addappid(1240953, 1, "d61ed6bff858cd8485779a9505b3837c3560e55a400ad6a5c17161f536894bec")

