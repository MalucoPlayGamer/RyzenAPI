-- Lua provided by RyzenAPI
-- Game: addappid(2595010)

-- MAIN APPLICATION
addappid(2595010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595011, 1, "76be434d2f9d5a39ffa70ad78d46fb60a88285de9d29092bb625f3cc878572f8")
