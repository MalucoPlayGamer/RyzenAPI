-- Lua provided by RyzenAPI
-- Game: AppID 555670

-- MAIN APPLICATION
addappid(555670)

-- MAIN APP DEPOTS / PACKAGES
addappid(555671, 1, "11650773ca7547eea5149d13a4061bd63c027832fa2c9d52b0e5a02c84a110ce")
addappid(574770, 0, "21f682793d6aaa544357cefbc642ba669726ab4138ee82cabf03204d2a30c60d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
