-- Lua provided by RyzenAPI
-- Game: 505550

-- MAIN APPLICATION
addappid(505550)
-- Game: addappid(505550)

-- MAIN APP DEPOTS / PACKAGES
addappid(505551, 1, "c99c0fd4540271320528de4344cca31ab5ef58c433f8f7481223e0c28eaa9a00")
