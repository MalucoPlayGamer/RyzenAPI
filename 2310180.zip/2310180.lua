-- Lua provided by SkyAPI 
-- Game: Tales of: Sena (Legacy)
addappid(2310180)
addappid(2310181, 1, "2b572057404af2a0ecf0453a67a2a94e7a80cc4dfd1a3804301e5f2fc373adb8")
