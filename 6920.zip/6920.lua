-- Lua provided by RyzenAPI
-- Game: Deus Ex: Invisible War

-- MAIN APPLICATION
addappid(6920)
-- Game: addappid(6920)

-- MAIN APP DEPOTS / PACKAGES
addappid(6921, 1, "fcb14bf4013852cd2b87dd1fe2fd192e67cab4a7bcbf9ae0fabba1800cc99cfc")
