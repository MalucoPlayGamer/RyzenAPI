-- Lua provided by RyzenAPI
-- Game: 1667170

-- MAIN APPLICATION
addappid(1667170)
-- Game: addappid(1667170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667171, 1, "a846ac2600e30cdc1f01d6b05a28473b0fb2ba905e34e8ec83c068b9ab1fe4a2")
