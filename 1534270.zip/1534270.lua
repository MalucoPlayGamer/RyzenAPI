-- Lua provided by RyzenAPI
-- Game: Bard Harder!

-- MAIN APPLICATION
addappid(1534270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534271, 1, "2debdcd2bd7e9eb923de37b69f74806249ebbafe359cbcf3f76d334bbf71f65f")

