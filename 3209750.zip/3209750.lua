-- 3209750's Lua and Manifest Created by Hubcap Manifest
-- STARIO: Haven Tower
-- Created: August 05, 2026 at 13:25:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3209750, 1, "10e07cb7ed8193eb2c13e5865513991e88ae45528aa5066c67388c39190ce669") -- STARIO: Haven Tower
addtoken(3209750, "18156113925995640417")
-- MAIN APP DEPOTS
addappid(3209751, 1, "b7a142c792484558e84287b67df5443074459526508835c2edfba4e2925bb269") -- Depot 3209751
setManifestid(3209751, "8094789251767077462", 3111540821)