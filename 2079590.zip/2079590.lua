-- Lua provided by RyzenAPI
-- Game: addappid(2079590)

-- MAIN APPLICATION
addappid(2079590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079591, 1, "cbe820cb761b76bd8961433bb0b38fc414b768ae2459d8e2b0386a4f951616e4")
