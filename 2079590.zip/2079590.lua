-- Lua provided by SkyAPI 
-- Game: Dark Sun
addappid(2079590)
addappid(2079591, 1, "cbe820cb761b76bd8961433bb0b38fc414b768ae2459d8e2b0386a4f951616e4")
