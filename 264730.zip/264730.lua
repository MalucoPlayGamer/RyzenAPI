-- Lua provided by RyzenAPI
-- Game: Deadly 30

-- MAIN APPLICATION
addappid(264730)

-- MAIN APP DEPOTS / PACKAGES
addappid(264731, 1, "afbd9481f6dd17aaf6d50138818f795a9ae10b0868f2b1a6c697f2b5e4ce993c")
addappid(264732, 1, "637a949393ca87345eb31852c975776b34df4f1217f96650b013bb11e119f225")
addappid(264733, 1, "8c58123c3a08cdffaf6c16a2c308c7f1ebea8f393ec897a87d7758ba468d1268")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
