-- Lua provided by RyzenAPI
-- Game: Deadly 30

-- MAIN APPLICATION
addappid(264730)
-- Game: addappid(264730)

-- MAIN APP DEPOTS / PACKAGES
addappid(264731, 1, "afbd9481f6dd17aaf6d50138818f795a9ae10b0868f2b1a6c697f2b5e4ce993c")
addappid(264732, 1, "637a949393ca87345eb31852c975776b34df4f1217f96650b013bb11e119f225")
addappid(264733, 1, "8c58123c3a08cdffaf6c16a2c308c7f1ebea8f393ec897a87d7758ba468d1268")
