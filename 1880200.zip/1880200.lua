-- Lua provided by RyzenAPI
-- Game: Nine Nights

-- MAIN APPLICATION
addappid(1880200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880201, 1, "110ed48412082e8b01eda2dbd0b3c48e49603831bdb2a1a51ed83a81ed10103a")

