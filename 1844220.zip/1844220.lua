-- Lua provided by RyzenAPI
-- Game: addappid(1844220)

-- MAIN APPLICATION
addappid(1844220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844220,0,"b5265be87311408da571157d0b33f824fdf4ecc9b6424861effd443c22f7d71b")
