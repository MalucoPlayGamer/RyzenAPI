-- Lua provided by RyzenAPI
-- Game: Last Time I Saw You

-- MAIN APPLICATION
addappid(1909750)
-- Game: addappid(1909750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909751, 1, "3ae469bdce79d8d8269569a0cfe86f855f51e47d51977dca275f9afd2dff4b6d")
