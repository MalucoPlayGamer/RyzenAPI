-- Lua provided by RyzenAPI
-- Game: addappid(492270)

-- MAIN APPLICATION
addappid(492270)

-- MAIN APP DEPOTS / PACKAGES
addappid(492271, 1, "070769f4339f84351a35ba52fae95a202d57e3eb7c072c1df259dea1ea5dcd97")
addappid(492272, 1, "841342115dfa2cacc85aef330cfac81f1b5c6206ae9b6f711659d6b8c062e6f8")
addappid(492273, 1, "c69ba94f5935b175cdb02fc3770761ab2f5e8070aa47fdecbc93e45ccd75dbbf")
