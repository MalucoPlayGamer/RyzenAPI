-- Lua provided by RyzenAPI
-- Game: AppID 492270

-- MAIN APPLICATION
addappid(492270)

-- MAIN APP DEPOTS / PACKAGES
addappid(492271, 1, "070769f4339f84351a35ba52fae95a202d57e3eb7c072c1df259dea1ea5dcd97")
addappid(492272, 1, "841342115dfa2cacc85aef330cfac81f1b5c6206ae9b6f711659d6b8c062e6f8")
addappid(492273, 1, "c69ba94f5935b175cdb02fc3770761ab2f5e8070aa47fdecbc93e45ccd75dbbf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
