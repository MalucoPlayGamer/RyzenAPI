-- Lua provided by RyzenAPI
-- Game: AppID 1152950

-- MAIN APPLICATION
addappid(1152950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152951, 1, "6e5b928e81f78ead6b8ee43b8c35cbad27c98c19ddd04df6d0e892dc10385e9f")
