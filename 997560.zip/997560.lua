-- Lua provided by RyzenAPI
-- Game: Flash Point - Online FPS

-- MAIN APPLICATION
addappid(997560)

-- MAIN APP DEPOTS / PACKAGES
addappid(997561, 1, "9489e765684821bf02534f29413ebaf352efea57179b0bc948ceba0a3d214a76")
