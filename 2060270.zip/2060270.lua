-- Lua provided by RyzenAPI
-- Game: Warlock character for B.I.O.T.A.

-- MAIN APPLICATION
addappid(2060270)
-- Game: addappid(2060270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060271, 1, "1b463a7915bff94e4cff58e1de2687bce2b91a194ae3c72fb1811d7124998c6b")
