-- Lua provided by RyzenAPI
-- Game: Aquatico

-- MAIN APPLICATION
addappid(1812300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1812301, 1, "dc67ebb492f7f7127be263676e46ba51251584736ed7dec00a49fa0da11a6a1b")
addappid(2239610, 0, "d61d3b0eea766bebdae3ea4328adbab3378c3f8187a5888dcd55ead7c603fd9b")

