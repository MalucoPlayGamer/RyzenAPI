-- Lua provided by RyzenAPI
-- Game: addappid(1812300)

-- MAIN APPLICATION
addappid(1812300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812301, 1, "dc67ebb492f7f7127be263676e46ba51251584736ed7dec00a49fa0da11a6a1b")
addappid(2239610, 0, "d61d3b0eea766bebdae3ea4328adbab3378c3f8187a5888dcd55ead7c603fd9b")
