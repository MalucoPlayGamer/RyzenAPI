-- Lua provided by RyzenAPI
-- Game: Game: Dash Dash Run!

-- MAIN APPLICATION
addappid(649570)
-- Game: addappid(649570)

-- MAIN APP DEPOTS / PACKAGES
addappid(649571, 1, "74142dabf5751105e478482cc6c96b1582af097ac3dbd3714a9cb95e132c88d4")
