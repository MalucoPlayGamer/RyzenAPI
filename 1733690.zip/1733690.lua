-- 1733690's Lua and Manifest Created by Hubcap Manifest
-- Mandate Order
-- Created: August 12, 2026 at 00:13:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1733690) -- Mandate Order
addtoken(1733690, "12179485395462989180")
-- MAIN APP DEPOTS
addappid(1733691, 1, "63fd390e7dee4070c4502e1d6108ecf41ec357c93839d7e9399b9bd0c6e67470") -- Depot 1733691
setManifestid(1733691, "9122460017792186244", 14361421518)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)