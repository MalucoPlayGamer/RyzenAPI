-- Lua provided by RyzenAPI
-- Game: Game: Star Hunter - Infinite Lagrange

-- MAIN APPLICATION
addappid(1755920)
-- Game: addappid(1755920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755921, 1, "5e29ca53636fb7df1c86931def73de81d57045082db131e7044300d40a75d366")
