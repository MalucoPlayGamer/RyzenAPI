-- Lua provided by RyzenAPI 
-- Game: From Madness with Love
addappid(2101130)
addappid(2101131, 1, "4193b4f89374021d95bd9e28827616aeeda9d90ac1d731777bd1a14c364456a9")
addappid(2101133, 1, "f0ed82cab5992869e5f4a4629612f02f88bf24b9075817506644bfe4ccc94bf9")
addappid(2101134, 1, "bfe54b35d9b8dffc750a37a4e4635398e33be74f3f8efaeaa69f3682815e2b67")
addappid(3678560, 0, "772ddab748fe663a334c73ce04eac9f159e3b0d3a0dea45bbc2f652226fcae34")
