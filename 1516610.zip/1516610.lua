-- Lua provided by RyzenAPI
-- Game: RC Airplane Challenge

-- MAIN APPLICATION
addappid(1516610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516611, 1, "0ddb914e25cfa22a7bd277540da52408663b19804c5d662f9a0661a3f9a1995c")
