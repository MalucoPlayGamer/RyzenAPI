-- Lua provided by RyzenAPI
-- Game: Apprehend

-- MAIN APPLICATION
addappid(3148610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148611, 1, "a1853c36d608e69f540237e0b41dd231e25ddf5ae026f516c4846057fbd0574d")

