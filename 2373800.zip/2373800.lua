-- Lua provided by SkyAPI 
-- Game: AppID 2373800
addappid(2373800)
addappid(2373801, 1, "1a57391bfc14db7bbfe2f05fe9010d8f9fdfb4bee3fa62aedbb1d464b6d8274f")
