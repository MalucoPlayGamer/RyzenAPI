-- Lua provided by RyzenAPI
-- Game: Alchemia: Creatio Ex Nihilo Soundtrack

-- MAIN APPLICATION
addappid(2094820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094821, 1, "ef388a9c6b226695280e8942fde265744184375a8e26269e948454d4a7e52b62")
addappid(2094822, 1, "66eb64d070274dce4e949509f380f8aca1681703e5a5d332596be2b1f912e407")
