-- Lua provided by RyzenAPI
-- Game: AppID 582620

-- MAIN APPLICATION
addappid(582620)
addappid(595980)

-- MAIN APP DEPOTS / PACKAGES
addappid(582621, 1, "7d048cc9b62b1e9ef9b65e92a2700b527e1813c39b34a084f9618ba544ee2d71")
