-- Lua provided by RyzenAPI
-- Game: AppID 582620

-- MAIN APPLICATION
addappid(582620)
addappid(595980)

-- MAIN APP DEPOTS / PACKAGES
addappid(582621, 1, "7d048cc9b62b1e9ef9b65e92a2700b527e1813c39b34a084f9618ba544ee2d71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
