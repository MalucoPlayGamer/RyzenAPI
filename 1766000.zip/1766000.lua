-- Lua provided by RyzenAPI
-- Game: Path of Ra

-- MAIN APPLICATION
addappid(1766000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766001, 1, "d0ce52096116b27b23ebc352a0fffb5c54bffed023c30bfc73792f793f5a4777")
