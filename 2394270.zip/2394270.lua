-- Lua provided by RyzenAPI
-- Game: The Invincible Demo

-- MAIN APPLICATION
addappid(2394270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394271, 1, "028a9c7e45627df8de2a3775d9f3f62720d9886b7809622f7070b19d11d922ca")
