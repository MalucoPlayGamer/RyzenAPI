-- Lua provided by RyzenAPI
-- Game: AppID 544630

-- MAIN APPLICATION
addappid(544630)
-- Game: addappid(544630)

-- MAIN APP DEPOTS / PACKAGES
addappid(544631, 1, "6bd8ffaa2405559e8385eeef263d39cef46c84d2eb923a258f3d6dbaeb98395b")
