-- Lua provided by RyzenAPI
-- Game: AppID 544630

-- MAIN APPLICATION
addappid(544630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(544631, 1, "6bd8ffaa2405559e8385eeef263d39cef46c84d2eb923a258f3d6dbaeb98395b")

