-- Lua provided by SkyAPI 
-- Game: Astro
addappid(2064970)
addappid(2064971, 1, "c29fa0604f7fd17f744d143ef86e52c4ea3d061b6bb1b0d0ad8df1434f5381d5")
