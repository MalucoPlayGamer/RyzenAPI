-- Lua provided by RyzenAPI
-- Game: 1839420

-- MAIN APPLICATION
addappid(1839420)
-- Game: addappid(1839420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839421, 1, "186aaa5581a333e6bc3123e61b78832255d69e15c2ebfc2178896a7e25b457ad")
