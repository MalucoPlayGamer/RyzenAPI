-- Lua provided by RyzenAPI
-- Game: Sound Forge Audio Studio 10 - Steam Powered

-- MAIN APPLICATION
addappid(278150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(278151, 1, "4bca843bbef4fc4b574af94bbcfd1b8777ac7727178ec1c7aab4f8429dedddb9")
