-- Lua provided by RyzenAPI
-- Game: Game: AppID 278150

-- MAIN APPLICATION
addappid(278150)
-- Game: addappid(278150)

-- MAIN APP DEPOTS / PACKAGES
addappid(278151, 1, "4bca843bbef4fc4b574af94bbcfd1b8777ac7727178ec1c7aab4f8429dedddb9")
