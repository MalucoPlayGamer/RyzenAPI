-- Lua provided by RyzenAPI
-- Game: addappid(897780)

-- MAIN APPLICATION
addappid(897780)

-- MAIN APP DEPOTS / PACKAGES
addappid(897781, 1, "f3f9e43b1120f958fb6f6063000c7a83c554b6063e99b7985cb518cd2ad09054")
