-- Lua provided by RyzenAPI
-- Game: 1577240

-- MAIN APPLICATION
addappid(1577240)
-- Game: addappid(1577240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577241, 1, "64cf80b16cfc7417dbc91b5714146238c05bf9ef0e8d7a7c8bdc06d260214e81")
