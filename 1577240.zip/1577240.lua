-- Lua provided by RyzenAPI
-- Game: AppID 1577240

-- MAIN APPLICATION
addappid(1577240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577241, 1, "64cf80b16cfc7417dbc91b5714146238c05bf9ef0e8d7a7c8bdc06d260214e81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
