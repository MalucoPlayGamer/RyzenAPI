-- Lua provided by RyzenAPI
-- Game: Dark Parables: The Swan Princess and The Dire Tree Collector's Edition

-- MAIN APPLICATION
addappid(496030)

-- MAIN APP DEPOTS / PACKAGES
addappid(496031, 1, "68130208d7984d7ed4e4dfaf03789161339d44f788434c37464cc06833101640")

