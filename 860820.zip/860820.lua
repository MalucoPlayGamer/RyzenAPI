-- Lua provided by RyzenAPI
-- Game: 860820

-- MAIN APPLICATION
addappid(860820)

-- MAIN APP DEPOTS / PACKAGES
addappid(860822,0,"4d7ac976491c3676615e189787bd1bb3b5fc9c77b287da0e0513e7d3cdb6ddbf")

