-- Lua provided by RyzenAPI
-- Game: addappid(1333470)

-- MAIN APPLICATION
addappid(1333470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333471, 1, "1f77e60b99c6d353740e8dfeb0269943b0b1e536f88b374db1b28ab8aab1b13f")
