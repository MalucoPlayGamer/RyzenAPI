-- Lua provided by RyzenAPI 
-- Game: Office Love Affair
addappid(1597430)
addappid(1597431, 1, "acee0144235a49953a10f5c100c0153303cc508706d305c87b9161d0f0fbcecb")
