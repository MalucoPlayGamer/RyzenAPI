-- Lua provided by RyzenAPI
-- Game: 2273420

-- MAIN APPLICATION
addappid(2273420)
addappid(2590231)
-- Game: addappid(2273420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273421, 1, "2d351254c8aba18f5f0d54e49c256013359c2b32d66799579b6e65df85c4b1d4")
