-- Lua provided by RyzenAPI
-- Game: Suicide Guy

-- MAIN APPLICATION
addappid(303610)

-- MAIN APP DEPOTS / PACKAGES
addappid(303626,0,"70e48b1e7df534adc9418edf0a749c138a5fb3d6aa64ccf074de1e25fa697613")
addappid(303628,0,"0e4daede113d4deabe9525b579f13c2a83e150697fdf681b9f751e57db720b2d")
addappid(303629,0,"033497cef86ec346c9375194d29d2a8a1acd7aec5290141d72ddfb2e4145fe42")

