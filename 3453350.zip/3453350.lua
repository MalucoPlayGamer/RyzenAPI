-- Lua provided by RyzenAPI
-- Game: Farm Together 2 Soundtrack

-- MAIN APPLICATION
addappid(3453350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453351, 1, "726819ce0ad0e98be37df136e7e412f6bf100f499da3e9b78516f8e914135b8f")
addappid(3453352, 1, "fa90af7b57a7f4ce7bd929f5f02ec49f6fd81575cd359ccde1609ed4f251d314")

