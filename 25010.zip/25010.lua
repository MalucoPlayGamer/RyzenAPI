-- Lua provided by RyzenAPI
-- Game: Game: Lugaru HD

-- MAIN APPLICATION
addappid(25010)
-- Game: addappid(25010)

-- MAIN APP DEPOTS / PACKAGES
addappid(25011, 1, "7d38fc1e616565f2b9491d8dd9fc2c9e240004f052eab55d402f94a13cdfc4a2")
addappid(25012, 1, "0dd4241e07433891f95e2e9401c8462be5b873ccef7d192a79fdd4ca120fc1fc")
addappid(25014, 1, "135818d2122f10eb194751740e6326d9f9b94ab8eaf6cad4e39a6e9056dfca29")
addappid(25020, 1, "b0814a62ea9acc6ee223ca395a2dbdfa2cf56ef5c4f0c20d4c3368f312bd6fa6")
addappid(25030, 1, "7976723c649375d84fdbe440da04d57610f29f028c9e85b678c112cea6a5269b")
addappid(25031, 0, "e8e1dc14b6f6ecc2ce9796030b64dc61acacee1ff363a590dfbdd37547298bb0")
addappid(25041, 0, "5e359aa685042340846d9739ffdd54ff71b680456eec714dd80acc61ccaaad88")
