-- Lua provided by SkyAPI 
-- Game: AppID 2334160
addappid(2334160)
addappid(2334161, 1, "fa9570e54c7784fb6873b4ff5e198c7926d2937f7bdf3ed808ea8f1152c6ef95")
