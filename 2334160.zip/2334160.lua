-- Lua provided by RyzenAPI
-- Game: 2334160

-- MAIN APPLICATION
addappid(2334160)
-- Game: addappid(2334160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334161, 1, "fa9570e54c7784fb6873b4ff5e198c7926d2937f7bdf3ed808ea8f1152c6ef95")
