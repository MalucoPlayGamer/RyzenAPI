-- Lua provided by RyzenAPI
-- Game: 武儒绘卷 - 天地奇缘

-- MAIN APPLICATION
addappid(1967830)
addappid(2062040)
addappid(2083550)
addappid(2092310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967831, 1, "d031c6e7ce3ca715d29ceddd8a99fe5d1dfc65927b341fc4f96377d56e7d853f")
