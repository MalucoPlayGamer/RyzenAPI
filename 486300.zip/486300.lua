-- Lua provided by RyzenAPI
-- Game: AppID 486300

-- MAIN APPLICATION
addappid(486300)

-- MAIN APP DEPOTS / PACKAGES
addappid(486301, 1, "ec15322704a647f2d5b1fecb751017f427221e04c7e16e9654ed90ced3be0cbe")

