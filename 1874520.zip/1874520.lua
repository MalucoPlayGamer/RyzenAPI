-- Lua provided by RyzenAPI
-- Game: addappid(1874520)

-- MAIN APPLICATION
addappid(1874520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874521, 1, "dd5c235f926a4733a0f5b787c86f03ab76e3bd64e250bdf52082c746436dcb52")
