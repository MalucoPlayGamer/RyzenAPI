-- Lua provided by RyzenAPI
-- Game: Tiger Knight: Empire War

-- MAIN APPLICATION
addappid(534500)

-- MAIN APP DEPOTS / PACKAGES
addappid(534501, 1, "e3881550c3a5436c452dd632771a5c06ab08fe94363473797de92d182195a620")
