-- Lua provided by RyzenAPI
-- Game: SAMARA

-- MAIN APPLICATION
addappid(2829370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829371, 1, "b97ebfe1713b1d3baaf81ddcdd840a583baab0ec0a8a646090b789b3beb6e00d")
