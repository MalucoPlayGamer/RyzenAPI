-- Lua provided by RyzenAPI
-- Game: Tostchu

-- MAIN APPLICATION
addappid(2221500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221501, 1, "7fa14f8f947993db82479fd4266befae5ea8d0e245790c76ca82b40a99cf280e")

