-- Lua provided by RyzenAPI
-- Game: Tostchu

-- MAIN APPLICATION
addappid(2221500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221501, 1, "7fa14f8f947993db82479fd4266befae5ea8d0e245790c76ca82b40a99cf280e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
