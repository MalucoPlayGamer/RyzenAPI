-- Lua provided by RyzenAPI 
-- Game: Märchen Forest
addappid(1507720)
addappid(1507721, 1, "c8c31ab9e53551036e5c9306ea485f23d27c298acd3b43dfd02a7d1a953ce9d6")
