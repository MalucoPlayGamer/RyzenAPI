-- Lua provided by RyzenAPI
-- Game: addappid(696540)

-- MAIN APPLICATION
addappid(696540)

-- MAIN APP DEPOTS / PACKAGES
addappid(696541, 1, "208c11139e02c80f77c551b9a14aeef8bdbf7e2ad011170336131533a33d9af8")
