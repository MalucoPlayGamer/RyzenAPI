-- Lua provided by RyzenAPI
-- Game: AppID 2563840

-- MAIN APPLICATION
addappid(2563840)
-- Game: addappid(2563840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563841, 1, "88f722267633ed23fcd5bd41426fb9bc5fd2e4e0c49d26181e58bd8aa0a0deb8")
