-- Lua provided by RyzenAPI
-- Game: Astor: Blade of the Monolith

-- MAIN APPLICATION
addappid(1989320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1989321, 1, "bc10d75965e08311fe709d3825b50dfff2e674244e980c29d8d324a9a71e8753")
