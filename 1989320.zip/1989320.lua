-- Lua provided by RyzenAPI
-- Game: Game: AppID 1989320

-- MAIN APPLICATION
addappid(1989320)
-- Game: addappid(1989320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989321, 1, "bc10d75965e08311fe709d3825b50dfff2e674244e980c29d8d324a9a71e8753")
