-- Lua provided by RyzenAPI
-- Game: Magical Massage Playtest

-- MAIN APPLICATION
addappid(3488830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3488831, 1, "68c9ea1975c87fbfc4a105da6b00938cfe750944e24864f32ad93612f1904272")

