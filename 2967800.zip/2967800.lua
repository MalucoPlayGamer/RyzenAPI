-- Lua provided by RyzenAPI
-- Game: addappid(2967800)

-- MAIN APPLICATION
addappid(2967800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967801, 1, "b7a46e12d41bc63d19fa4e59b973a2ead9e218c69c1e40a79033112a34d899a2")
