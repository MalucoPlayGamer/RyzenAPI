-- Lua provided by RyzenAPI
-- Game: DottyBead闪闪拼豆

-- MAIN APPLICATION
addappid(4599500)
