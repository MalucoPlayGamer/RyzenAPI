-- Lua provided by RyzenAPI
-- Game: DottyBead闪闪拼豆

-- MAIN APPLICATION
addappid(4599500)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4872040)
addappid(4876230)
addappid(4876300)
addappid(4878320)
addappid(4878350)
