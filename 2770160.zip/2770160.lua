-- Lua provided by RyzenAPI
-- Game: Maxwell's puzzling demon

-- MAIN APPLICATION
addappid(2770160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770161, 1, "a74f06ad8d58c1135b0444e51098bfebcaa6bccd1366ba37a43704505b169138")
