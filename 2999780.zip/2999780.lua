-- Lua provided by RyzenAPI
-- Game: Skeletos Sword

-- MAIN APPLICATION
addappid(2999780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2999781, 1, "9f5d4dc7148010aae97aaeec8e6e7e69fb688a604c72c7d339b22f21fecdf74f")

