-- Lua provided by RyzenAPI
-- Game: Skeletos Sword

-- MAIN APPLICATION
addappid(2999780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999781, 1, "9f5d4dc7148010aae97aaeec8e6e7e69fb688a604c72c7d339b22f21fecdf74f")
