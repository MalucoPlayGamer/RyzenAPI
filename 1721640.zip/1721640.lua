-- Lua provided by RyzenAPI
-- Game: Human Apocalypse Demo

-- MAIN APPLICATION
addappid(1721640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721641, 1, "98036159b0cd505dd092b503540de942890076bd686b5a5330f60c3af62d50d2")
