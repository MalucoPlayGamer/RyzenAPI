-- Lua provided by RyzenAPI
-- Game: Game: AppID 1464670

-- MAIN APPLICATION
addappid(1464670)
-- Game: addappid(1464670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464671, 1, "98104d8d582d419c5c12efd02bcd0d86a86d2fa2456b17c5a4edc5c9889bf5a9")
