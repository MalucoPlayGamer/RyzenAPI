-- Lua provided by RyzenAPI
-- Game: Rebellion: Rise of the Damned

-- MAIN APPLICATION
addappid(2902570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902571, 1, "ffc9e96d1472ba9e5b1d6b75197460818456960285698302a8487f5d47634d13")

