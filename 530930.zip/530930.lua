-- Lua provided by SkyAPI 
-- Game: Soulblight
addappid(530930)
addappid(530931, 1, "c5bd4ce1949d5ca30ccd7262cece459892ad249a1aac216c2cc89b5552034103")
