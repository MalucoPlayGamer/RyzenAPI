-- Lua provided by RyzenAPI
-- Game: Soulblight

-- MAIN APPLICATION
addappid(530930)
-- Game: addappid(530930)

-- MAIN APP DEPOTS / PACKAGES
addappid(530931, 1, "c5bd4ce1949d5ca30ccd7262cece459892ad249a1aac216c2cc89b5552034103")
