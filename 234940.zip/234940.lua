-- Lua provided by RyzenAPI
-- Game: The 39 Steps

-- MAIN APPLICATION
addappid(234940)
-- Game: addappid(234940)

-- MAIN APP DEPOTS / PACKAGES
addappid(234941, 1, "311dccfd4145514ac409c9f2b550fdeb54889f46eb9f2914b095a15fd2253261")
addappid(234942, 1, "7f4f85befeed9808d2884ff8b20e72cdefaab0864f895c1b9d35ce597aa30b74")
addappid(234943, 1, "eb7b8be23153f8242a84e75f78c6616eeb422903372acdb5f2cd6f781dbb815e")
