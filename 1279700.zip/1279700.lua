-- Lua provided by RyzenAPI
-- Game: 1279700

-- MAIN APPLICATION
addappid(1279700)
addappid(1279704)
-- Game: addappid(1279700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279703,0,"f0754b6d5eefa344aff60dbe70fb85d83acb3d921f63c02dccb4afb9f110b505")
