-- Lua provided by RyzenAPI
-- Game: AppID 1121230

-- MAIN APPLICATION
addappid(1121230)
-- Game: addappid(1121230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121231, 1, "647abb86ee924d887a9ef5fbfbddfe32e60206a624bcfd26215be1a78697ebde")
