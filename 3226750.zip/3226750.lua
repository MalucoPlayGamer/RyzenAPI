-- Lua provided by RyzenAPI
-- Game: Game: Deep Space Cache

-- MAIN APPLICATION
addappid(3226750)
-- Game: addappid(3226750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226751, 1, "73bc231ac362e174ec4a45a78f138d6398b439f4c88f23258a8f30dc12f42f35")
