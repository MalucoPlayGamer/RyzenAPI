-- Lua provided by RyzenAPI
-- Game: Frozenheim

-- MAIN APPLICATION
addappid(1134100)
-- Game: addappid(1134100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134101, 1, "4c5467587a34d40d8980200a39b4ffcfdeec32c4944bae3e459fb3f5d0c3a7c4")
