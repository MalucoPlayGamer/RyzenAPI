-- Lua provided by RyzenAPI
-- Game: Colonization of the Moon

-- MAIN APPLICATION
addappid(968430)

-- MAIN APP DEPOTS / PACKAGES
addappid(968431, 1, "37d378778a3d50b4a0ec9249c6a4f452fd98270134a42e9b1826afb51f4c077e")
