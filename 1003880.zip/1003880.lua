-- Lua provided by RyzenAPI
-- Game: Game: Sky of Destruction

-- MAIN APPLICATION
addappid(1003880)
-- Game: addappid(1003880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003881, 1, "ac8cfc1930b2cd549e980e101bbdf3345d6761f47731482ffff36dd6af7455b1")
