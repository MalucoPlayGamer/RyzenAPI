-- Lua provided by RyzenAPI
-- Game: Dong-Jin Rice-hime（東津萌米）

-- MAIN APPLICATION
addappid(617660)
addappid(716911)

-- MAIN APP DEPOTS / PACKAGES
addappid(617661, 1, "8265e60bdfc6e236eb5606d5d3f96cd6c4702e20810b78dd26097a5ad9be45cf")
addappid(617662, 1, "96d2f34fc1c63738bfe4a6ceb6cc41545080da4ba27c1684121697e197c81982")
addappid(617664, 1, "4af194324d1844d9a42cd2858ec435f15a998a9f3eaf169b42484d234be0515b")
addappid(716910, 0, "088221f42ccb328c319ed02d0beac34e2ea602cdb9aabe4151b4e4d970b734b0")

