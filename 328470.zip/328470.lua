-- Lua provided by RyzenAPI
-- Game: Game: Slave Zero

-- MAIN APPLICATION
addappid(328470)
-- Game: addappid(328470)

-- MAIN APP DEPOTS / PACKAGES
addappid(328471, 1, "06b8472ca18967b87cc2d908f7030172da11548808b5daa2e144e76c512601ad")
addappid(328472, 1, "6864b1c2514f104e4141d0809a6ec137678e107f844a950fb5caa0f7216dcaac")
addappid(328473, 1, "d08ae0e5ea97abacb42f1c783b23ef8172124e07a043fd2dfbf4ead3ee0beeb6")
addappid(328474, 1, "354d8cf85934bec92d35a42f4847ecbbbfe54a0b5b389eb6b2f839353a955e2d")
addappid(328475, 1, "f51cc5f9cef8030ea1c1d50c188f628a157c4c97e6dac855f358d1bcf337fc9c")
addappid(328476, 1, "a7e96ea5b11c2fe66aab2b178c98985362be6f5142546a6f1f36a8d6b78e2013")
addappid(328477, 1, "a27af11daac44a95d30f9ece84fbf7cbdb0d610e862a153120bc182ca66998a1")
