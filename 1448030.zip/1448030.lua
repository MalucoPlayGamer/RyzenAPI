-- Lua provided by RyzenAPI
-- Game: Press Any Button

-- MAIN APPLICATION
addappid(1448030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448035,0,"e47d93961f72366198492d6dd2889cf4a9e9c40c50449abd2f8f86466bf6a74f")
addappid(1448036,0,"614649a95b6a0eb7f521527d02b5a4e0971755e712080c059a8e8c3c81a7950d")
addappid(1448037,0,"53fdba3b684d347501ea8ec526b9672c7a5303c91c991823cb8fe2af4dab133e")
addappid(1448038,0,"6aecc5550f2418d93e1e413f955a7d8e44533897ccfccbedbc8b803f007f5532")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1509410)
