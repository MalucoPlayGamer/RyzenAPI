-- Lua provided by RyzenAPI 
-- Game: CAM
addappid(3097170)
addappid(3097171, 1, "872a406ef7a18a1729323cb0b0d12605a4105f4866d107817e2006746b339615")
