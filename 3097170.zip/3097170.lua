-- Lua provided by RyzenAPI
-- Game: CAM

-- MAIN APPLICATION
addappid(3097170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097171, 1, "872a406ef7a18a1729323cb0b0d12605a4105f4866d107817e2006746b339615")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
