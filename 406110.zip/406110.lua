-- Lua provided by RyzenAPI 
-- Game: Asdivine Hearts
addappid(406110)
addappid(406111, 1, "65997810d4a34ce11ac842b6007f94ef30210f86d511cdc3e71b210c423c6a6e")
addappid(406113, 1, "321e75f6e9ebbf9e644821eeda47c820193b9940f545a7c7f2ec85502ab50a90")
