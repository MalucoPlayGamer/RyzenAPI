-- Lua provided by RyzenAPI
-- Game: Beat Rider Demo

-- MAIN APPLICATION
addappid(2945590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945592,0,"9fba86034f7206d35316920f5483f5b018921e3787daa193285a961100e0982c")

