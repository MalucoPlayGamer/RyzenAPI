-- Lua provided by RyzenAPI
-- Game: SuperTrucks Offroad

-- MAIN APPLICATION
addappid(743830)

-- MAIN APP DEPOTS / PACKAGES
addappid(743831,0,"f442b7d7b49ff6e5f12f817da1ae268273abd8ed6f8ad008ea4cd42d9a895979")

