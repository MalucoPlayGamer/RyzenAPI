-- Lua provided by RyzenAPI
-- Game: 899892

-- MAIN APPLICATION
addappid(899892)
-- Game: addappid(899892)

-- MAIN APP DEPOTS / PACKAGES
addappid(899892,0,"92e5a1c8f42895fde3f0d9afdc9982f86ce38156d2930fa32b47f94a20aedd99")
