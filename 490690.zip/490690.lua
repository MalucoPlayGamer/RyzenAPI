-- Lua provided by RyzenAPI
-- Game: The Barbarian and the Subterranean Caves

-- MAIN APPLICATION
addappid(490690)

-- MAIN APP DEPOTS / PACKAGES
addappid(490691, 1, "8982648bead88b1146df3062fdb2d392e48fc70f0e8a95187fd43a69fdd4e49d")
addappid(490692, 1, "3ff5e68989c47c3c165afd98ce2c283200905589713b24916da9a62646faaf72")
addappid(490693, 1, "0a9bc9c232b803a701cfe12e51037ddf3278b34626ebe9c4fb29888da459cf09")
addappid(490694, 1, "a84e56edf3a7b2fb86d2758c5c5b806254793f61707a9ab287a35fa3fb5356ea")
addappid(490695, 1, "73f42fd4a1d0722814f2521998ac909431ee917fd8b5d3911c8c4a5f473cedd4")
