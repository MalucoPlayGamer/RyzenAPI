-- Lua provided by RyzenAPI
-- Game: Game: Witness of the Night

-- MAIN APPLICATION
addappid(2024210)
-- Game: addappid(2024210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024211, 1, "f9d4d33028642460499d2d228d565780c90e5f518226e6fcdcecd3883c81f9a1")
