-- Lua provided by RyzenAPI
-- Game: Cat & Capy

-- MAIN APPLICATION
addappid(3108140)
-- Game: addappid(3108140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108141, 1, "82cda41760dde1879f0f493672cb6046767e2d9034e06d59d794a16a0a661af0")
