-- Lua provided by RyzenAPI
-- Game: HoloCure - Save the Fans!

-- MAIN APPLICATION
addappid(2420510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420511, 1, "7ea195899460f1055e13109a95e8131204e9f83dd49dd44218addc054f178b49")
