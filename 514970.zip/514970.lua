-- Lua provided by RyzenAPI
-- Game: Drive Megapolis

-- MAIN APPLICATION
addappid(514970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(514971, 1, "41e3e20b471c6a57180f79bf719daa47fcd43b87e1378d66f7e4ff073fc092e7")
addappid(514972, 1, "5ae931b3e63f2bcee323faa4a9384b267163207bf7788817dee2fb280b4ace9a")
addappid(514988, 1, "4bca0e950f70f8572322c1ad6b2190b628e4ec3f9d7a526a8bc5dc389f7f9781")

