-- Lua provided by RyzenAPI
-- Game: AppID 514970

-- MAIN APPLICATION
addappid(514970)
-- Game: addappid(514970)

-- MAIN APP DEPOTS / PACKAGES
addappid(514971, 1, "41e3e20b471c6a57180f79bf719daa47fcd43b87e1378d66f7e4ff073fc092e7")
addappid(514972, 1, "5ae931b3e63f2bcee323faa4a9384b267163207bf7788817dee2fb280b4ace9a")
addappid(514988, 1, "4bca0e950f70f8572322c1ad6b2190b628e4ec3f9d7a526a8bc5dc389f7f9781")
