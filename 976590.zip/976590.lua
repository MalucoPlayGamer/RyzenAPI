-- Lua provided by RyzenAPI
-- Game: Bus Simulator 21 Next Stop

-- MAIN APPLICATION
addappid(1485720)
addappid(1485750)
addappid(1486560)
addappid(1486570)
addappid(1486580)
addappid(1486590)
addappid(1704440) -- Bus Simulator 21 Next Stop - Ebusco Bus Pack
addappid(1783410) -- Bus Simulator 21 Next Stop - Halloween Skin Pack
addappid(1783411) -- Bus Simulator 21 Next Stop - Halloween Interior Pack
addappid(1783412) -- Bus Simulator 21 Next Stop - Christmas Skin Pack
addappid(1783413) -- Bus Simulator 21 Next Stop - Christmas Interior Pack
addappid(1836140) -- Bus Simulator 21 Next Stop - Official Map Extension
addappid(1836141) -- Bus Simulator 21 Next Stop - Official School Bus Extension
addappid(1836142) -- Bus Simulator 21 Next Stop - Official Tram Extension
addappid(1911470) -- Bus Simulator 21 Next Stop - Easter Skin Pack
addappid(1911471) -- Bus Simulator 21 Next Stop - Easter Interior Pack
addappid(2139420) -- Bus Simulator 21 Next Stop - Thomas Built Buses Bus Pack
addappid(2306070) -- Bus Simulator 21 Next Stop - Gold Upgrade
addappid(2392580) -- Bus Simulator 21 Next Stop - Season Pass

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(976590, 1, "308d76fdf938be91c18b5c4f771181b1bfd44939688f4cbc9c2312625deb7ed6")
addappid(976591, 1, "5ef0921d386a98469f722a87b63a89c137f3418d4eab182e63beaaaa05117dd2")
addappid(976592, 1, "f071fd03e6545e0cf9b0903cd3c54c7b0671f7ad16e68dd6040b85c52b243820")
addappid(976593, 1, "aeda98aa4c46f19c709680382dcc03ad78743191c1b2c2084d57beb5a395aeab")
addappid(976594, 1, "8ffb60649532f9e7fdf5123df49ce9b4f6574aa65f04081598513f234211d868")
addappid(976595, 1, "4204d7ecb04671396e9a63f07b8b62325be135142feec5277e41f34a40d69b82")
addappid(976596, 1, "69cbb18bbb1ab6f5f32327d397047b37d5284f037a640214fdd238d70858c0a3")
addappid(976597, 1, "22db960dd5018f420575daefec4c0e15512ef2f5a0bd2d98c3da59f1cd5a4c3b")
addappid(976598, 1, "126b5b676e1ff0893b1af76119e7727e44f2e4fda103919c88722b2b6533c5e4")
addappid(976599, 1, "cc8ec1a9a089e6e4c9325d77a3341d619dc2218378789098e403d59d7284a652")
addappid(1485720, 1, "6e2c6d8595e928b883532a523ceaab9b147946aaff4f1be01befdc1c16e2383f")
addappid(1485721, 1, "46b46c6451a5d913c3bb07a93d21dd3311ad4cc53e89b5a0c71ab902d4958246")
addappid(1485722, 1, "999caef648378ff29eb1035297ade5fe8c2eb31983aa1c4eb021f84d8cbc2958")
addappid(1485723, 1, "eab1f68566387fd08fe5f8cf6406e4f61d8ac35c6021e6bc5c89953bdd94e3e9")
addappid(1485724, 1, "7cbc6a95b8f20c25dad7798ca44fbd42655d396c01269f5afdf720e609ff9175")
addappid(1485725, 1, "7108df3663a27a2177b36bb7f7790dc5c65be92eb87fca61d78a899a6608ea62")
addappid(1485726, 1, "e95de144588e3deba897df7f9ba1b9b7be2155f9be8f89ee73fb92536c079359")
addappid(1485750, 1, "969e822e8c4d3316013a18dbff76523e32d3f893319ab3f550eede49c6b923fa")
addappid(1486560, 1, "2aa99eccb29e7cc939bb7150d4e81695e6c693f9e292a7897ed840827d27f524")
addappid(1486570, 1, "6d93d2a6f34b2acc875932b0732df6731399e6e8652ec4f191b5129c718bc76b")
addappid(1486580, 1, "e402655221acb0578f276bde84173dc31c4fc14812c5b0ab0a1c58d821e593dc")
addappid(1486590, 1, "12ef7bb1e479477be75f364bd1eb39a265710e3761529ca59b32cbe7dadc03d6")
addappid(2546691, 1, "3c1a0f11f287aa5e650e4ba6a09559d978698c143e8f8119238ac4f564bccc84")

