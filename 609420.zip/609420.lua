-- Lua provided by RyzenAPI 
-- Game: AppID 609420
addappid(609420)
addappid(609421, 1, "aa2e9b606fd32a4dfb6923d14a7d0ebe9ea6ec60a3bc151f8a50249ffef8662c")
addappid(609422, 1, "bbf5813f3f0485573ceeee2b68c0d7c71f9008806bc0d7a90405d47b3c85d711")
