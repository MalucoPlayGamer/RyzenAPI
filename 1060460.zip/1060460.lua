-- Lua provided by RyzenAPI
-- Game: 1060460

-- MAIN APPLICATION
addappid(1060460)
-- Game: addappid(1060460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060461, 1, "1a9538ab2d75af90ec4d5d105c1af75eac04a9c029908e2a8d60495268b41aa6")
