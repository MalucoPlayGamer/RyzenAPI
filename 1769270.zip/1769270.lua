-- Lua provided by RyzenAPI
-- Game: addappid(1769270)

-- MAIN APPLICATION
addappid(1769270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769271, 1, "2fe49060d0c7a8c8fa88d3469fcd2795aecb406aa32f47df30f0da1252c1f21c")
