-- Lua provided by RyzenAPI
-- Game: Game: Last Whisper

-- MAIN APPLICATION
addappid(2172320)
-- Game: addappid(2172320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172321, 1, "a6229b185553429eb727a809186ed5ebb71023bc972b0144d81e408c44f54ca7")
