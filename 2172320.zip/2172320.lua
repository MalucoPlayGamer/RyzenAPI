-- Lua provided by RyzenAPI
-- Game: Last Whisper

-- MAIN APPLICATION
addappid(2172320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2172321, 1, "a6229b185553429eb727a809186ed5ebb71023bc972b0144d81e408c44f54ca7")

