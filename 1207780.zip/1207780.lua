-- Lua provided by RyzenAPI
-- Game: Game: AppID 1207780

-- MAIN APPLICATION
addappid(1207780)
-- Game: addappid(1207780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207781, 1, "7168ec46ead5fafc3b6e0f7af0c2cd5b3171c80a8edbb8ea817eec629a3b4404")
addappid(1207782, 1, "2b362a2769e864b198d204cd746bfed59e312a08124d415b2eebb667c401a946")
