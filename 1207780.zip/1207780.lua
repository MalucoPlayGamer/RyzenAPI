-- 1207780's Lua and Manifest Created by Hubcap Manifest
-- Wish
-- Created: February 01, 2026 at 12:09:35 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(1207780, 1, "d7fdaad70746b88e9158ee76b0984ef16091b03f26cd832878f54a223a9e1ec2") -- Wish
-- MAIN APP DEPOTS
addappid(1207781, 1, "7168ec46ead5fafc3b6e0f7af0c2cd5b3171c80a8edbb8ea817eec629a3b4404") -- windows
setManifestid(1207781, "7437947457860333445", 2820215374)
addappid(1207782, 1, "2b362a2769e864b198d204cd746bfed59e312a08124d415b2eebb667c401a946") -- mac osx
setManifestid(1207782, "3241909443605546729", 2372946220)
-- DLCS WITH DEDICATED DEPOTS
-- Wish-R18 Free Patch (AppID: 1231450)
addappid(1231450)
addappid(1231451, 1, "53fcaf4442fe6ee49998f1b40bd44020899e31361841832836a696d1afc2d86c") -- Wish-R18 Free Patch - Wish-DLC R18 Free Patch Windows
setManifestid(1231451, "8469806640772041820", 1284651245)
addappid(1231452, 1, "99d25f07134fe02150f9424d92682c250fe02fe518509262e525dfa929c86e20") -- Wish-R18 Free Patch - Wish-DLC R18 Free Patch macOS
setManifestid(1231452, "4612831738481054956", 1061681599)
-- Wish - Innocent (AppID: 1268940)
addappid(1268940)
addappid(1268940, 1, "c76fbddb5f873fae5df97337438a5e5a26348b3e1aa0a246034290100bc7be73") -- Wish - Innocent - Wish - Innocent Windows
setManifestid(1268940, "6174705322913032551", 186982060)
addappid(1268941, 1, "7ba9327c9f69ddddc7c0628cd4217f6cc81177bc6d6ff59693e5ceb1b7e8ae24") -- Wish - Innocent - Wish - Innocent macOS
setManifestid(1268941, "2810343725720088488", 186984382)
-- Wish - Art Book (AppID: 1269010)
addappid(1269010)
addappid(1269010, 1, "3b2e905412c598dfee18a1ed43fc53bdd2556ef14b7cbc5849a3e33b1060a97e") -- Wish - Art Book - Wish - Art Book 기본 디포
setManifestid(1269010, "1015607532790717798", 950531791)
-- addappid(1269011, 1, "MISSING_KEY") -- Wish - Art Book - Wish - Art Book Depot  Win (no key available)
-- addappid(1269012, 1, "MISSING_KEY") -- Wish - Art Book - Wish - Art Book Depot Mac (no key available)
-- Wish - Beyond Fate (AppID: 1302660)
addappid(1302660)
addappid(1302660, 1, "a65f961ca996a01a5f4a76bcbefe0e21c11259998b6a12b7bc4d8d839421bbb9") -- Wish - Beyond Fate - Wish - Beyond Fate Win
setManifestid(1302660, "7143652510032174051", 118886760)