-- Lua provided by RyzenAPI
-- Game: Wish

-- MAIN APPLICATION
addappid(1231450)
addappid(1268940)
addappid(1269010)
addappid(1302660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207780, 1, "d7fdaad70746b88e9158ee76b0984ef16091b03f26cd832878f54a223a9e1ec2") -- Wish
addappid(1207781, 1, "7168ec46ead5fafc3b6e0f7af0c2cd5b3171c80a8edbb8ea817eec629a3b4404") -- windows
addappid(1207782, 1, "2b362a2769e864b198d204cd746bfed59e312a08124d415b2eebb667c401a946") -- mac osx
addappid(1231451, 1, "53fcaf4442fe6ee49998f1b40bd44020899e31361841832836a696d1afc2d86c") -- Wish-R18 Free Patch - Wish-DLC R18 Free Patch Windows
addappid(1231452, 1, "99d25f07134fe02150f9424d92682c250fe02fe518509262e525dfa929c86e20") -- Wish-R18 Free Patch - Wish-DLC R18 Free Patch macOS
addappid(1268940, 1, "c76fbddb5f873fae5df97337438a5e5a26348b3e1aa0a246034290100bc7be73") -- Wish - Innocent - Wish - Innocent Windows
addappid(1268941, 1, "7ba9327c9f69ddddc7c0628cd4217f6cc81177bc6d6ff59693e5ceb1b7e8ae24") -- Wish - Innocent - Wish - Innocent macOS
addappid(1269010, 1, "3b2e905412c598dfee18a1ed43fc53bdd2556ef14b7cbc5849a3e33b1060a97e") -- Wish - Art Book - Wish - Art Book 기본 디포
addappid(1302660, 1, "a65f961ca996a01a5f4a76bcbefe0e21c11259998b6a12b7bc4d8d839421bbb9") -- Wish - Beyond Fate - Wish - Beyond Fate Win
-- addappid(1269011, 1, "MISSING_KEY") -- Wish - Art Book - Wish - Art Book Depot  Win (no key available)
-- addappid(1269012, 1, "MISSING_KEY") -- Wish - Art Book - Wish - Art Book Depot Mac (no key available)

