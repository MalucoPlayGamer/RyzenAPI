-- Lua provided by RyzenAPI
-- Game: Riders 2491

-- MAIN APPLICATION
addappid(1342130)
-- Game: addappid(1342130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342131, 1, "ca122edf29782fe5313c62d03edf951736c703e8894614da7240e136499a8836")
