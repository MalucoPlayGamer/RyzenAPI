-- Lua provided by RyzenAPI
-- Game: Oscillatron: Alien Frequency

-- MAIN APPLICATION
addappid(823730)

-- MAIN APP DEPOTS / PACKAGES
addappid(823731, 1, "4494119bc062ae007a2e96c04a5a136c34369807a7f044273573d5ed49b09a2f")
