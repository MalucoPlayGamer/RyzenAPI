-- Lua provided by RyzenAPI
-- Game: Superscout HD DLC

-- MAIN APPLICATION
addappid(3090560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090560,0,"e3ce86414dcb6d0ee7e9fdc4fe4887ef9c871aa81d415ac30a409857f97f2829")

