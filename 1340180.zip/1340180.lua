-- Lua provided by RyzenAPI
-- Game: Sherwood Extreme

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229005)
addappid(1340180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340182,0,"0210352bf34557c7b249c05846ce95111eac97105d19c01aa2501802a3f049a2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2125520)
