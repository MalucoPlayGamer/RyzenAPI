-- Lua provided by RyzenAPI
-- Game: TEOT - The End OF Tomorrow

-- MAIN APPLICATION
addappid(529280)
-- Game: addappid(529280)

-- MAIN APP DEPOTS / PACKAGES
addappid(529281, 1, "952a6b11df0f60b889842c17831b054442b5950c5868e4c001c97d943941d007")
