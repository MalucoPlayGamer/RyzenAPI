-- Lua provided by RyzenAPI
-- Game: Two Point Hospital

-- MAIN APPLICATION
addappid(535930)
addappid(898770)
addappid(963240)
addappid(966690)
addappid(1003310)
addappid(1035020)
addappid(1096580)
addappid(1144500)
addappid(1185850)
addappid(1196150)
addappid(1376920)
addappid(1377080)
addappid(1424940)
addappid(1440200)
addappid(1498090)
addappid(1901750)

-- MAIN APP DEPOTS / PACKAGES
addappid(535931, 1, "038f6bc45efe9b8bb282557291689a07867e95b7088cfcd700b9820f03f2cff7")
addappid(535932, 1, "e96023d14598781d7557a326368c151f5344f0f07908048976c2d936538a40c9")
addappid(535933, 1, "afd24b32446d595e1a9eb6a92f86efe39a810967276c60eac67ab013ff812226")
addappid(535934, 1, "5081596c4bc39082ba05cdd66845272d699f624a790f5019f479c77cfe32baca")

