-- Lua provided by RyzenAPI
-- Game: AppID 272890

-- MAIN APPLICATION
addappid(272890)

-- MAIN APP DEPOTS / PACKAGES
addappid(272891, 1, "94aaf892b7a0328deacd53deadef0d00d5246f14f28bbe1dc7e6d020b4af618f")
addappid(272892, 1, "d3611ad8b9674443d115b3826f34fc0932209486c76eb46d67583d20550f32c0")
addappid(272893, 1, "2c9641c220cc402c2bee159aa092225d73259428cfe16a27142a86dea58b7c8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(316590)
