-- Lua provided by RyzenAPI
-- Game: addappid(450120)

-- MAIN APPLICATION
addappid(450120)

-- MAIN APP DEPOTS / PACKAGES
addappid(450121, 1, "1b970dfdc10100954328f4a03bf9e43e247b08be0916a5f86576052a379b8e9c")
