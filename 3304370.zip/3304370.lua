-- Lua provided by RyzenAPI
-- Game: addappid(3304370)

-- MAIN APPLICATION
addappid(3304370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304371, 1, "c58b5679d6d9ea7b11cfddbd81ab4d4a8e7ce70429d57f0e1a9f25d88349ed14")
