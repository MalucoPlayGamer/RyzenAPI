-- Lua provided by RyzenAPI
-- Game: Game: Odyssey Moon

-- MAIN APPLICATION
addappid(2473110)
-- Game: addappid(2473110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473111, 1, "ae6a7f9011e7a045b62a1069ae9c256f4579806e1166cc01bf5da5866db7527c")
