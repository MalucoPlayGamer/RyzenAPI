-- Lua provided by SkyAPI 
-- Game: Odyssey Moon
addappid(2473110)
addappid(2473111, 1, "ae6a7f9011e7a045b62a1069ae9c256f4579806e1166cc01bf5da5866db7527c")
