-- Lua provided by RyzenAPI
-- Game: Hentai Fox

-- MAIN APPLICATION
addappid(2270530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270531, 1, "70ac29f5f0ba98b445fa819ce3a5fbc970cbb9d08aa173d1be088f2a42e74fbc")
