-- Lua provided by RyzenAPI
-- Game: AppID 3020990

-- MAIN APPLICATION
addappid(3020990)
-- Game: addappid(3020990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020991, 1, "a47bd0ae1ce53bde2fb97ea22b51772b40e0b180dea41d7303b8a97b32a94ff5")
