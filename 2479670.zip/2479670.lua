-- Lua provided by RyzenAPI
-- Game: 街机休闲捕鱼-Classic Arcade Fishing

-- MAIN APPLICATION
addappid(2479670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479671, 1, "f82b956af18a55003c1d34ac1b44bea90f983d957a11ea45fc526ddc21d217a0")

