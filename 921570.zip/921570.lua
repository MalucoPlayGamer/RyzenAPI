-- Lua provided by RyzenAPI
-- Game: AppID 921570

-- MAIN APPLICATION
addappid(921570)

-- MAIN APP DEPOTS / PACKAGES
addappid(921571, 1, "d68c52ab730016257e72ad98554e2a7d8cb6131790cc4490fff16873b73132b9")
addappid(1083770, 0, "233d3fdec4d0f87dbcbd2a2d77bb6d277ac034050c67ef93f7930a1952816eaf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
