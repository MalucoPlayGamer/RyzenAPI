-- Lua provided by RyzenAPI
-- Game: 921570

-- MAIN APPLICATION
addappid(921570)
-- Game: addappid(921570)

-- MAIN APP DEPOTS / PACKAGES
addappid(921571, 1, "d68c52ab730016257e72ad98554e2a7d8cb6131790cc4490fff16873b73132b9")
addappid(1083770, 0, "233d3fdec4d0f87dbcbd2a2d77bb6d277ac034050c67ef93f7930a1952816eaf")
