-- Lua provided by RyzenAPI
-- Game: addappid(368230)

-- MAIN APPLICATION
addappid(368230)

-- MAIN APP DEPOTS / PACKAGES
addappid(368231, 1, "5ea901dbec8b90508f4a19443fccf730476ab30b0fcc9c5dab1dde4a7ba09e24")
addappid(368232, 1, "20d82beb464eca68eafbd87f303fb29881f76b64720b82ad3df7a5425ed63548")
addappid(368233, 1, "37f16cddcede3f67162da9776624a97b8bdf0f720ecebb6f12cdce8347ff0144")
addappid(408370, 0, "b114fc628818dbb21e28427c1b76326caa6160c2c91e2210386710903e81a7e7")
