-- Lua provided by RyzenAPI
-- Game: Game: OTXO

-- MAIN APPLICATION
addappid(1608640)
-- Game: addappid(1608640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608641, 1, "1bc1d0a1e2499d9575a5814e5c01c15664f11e1813d86e56f10766e78757584f")
