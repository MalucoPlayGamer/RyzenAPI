-- Lua provided by RyzenAPI
-- Game: Beat Saber - Lizzo - "Everybody's Gay"

-- MAIN APPLICATION
addappid(2122143)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122143,0,"e857e6da14e717284129f09873343e8f0af3831fab1d4132dbf87b2e050c9173")

