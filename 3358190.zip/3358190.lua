-- Lua provided by RyzenAPI
-- Game: AppID 3358190

-- MAIN APPLICATION
addappid(3358190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358191, 1, "ca81a66a392ede65a1dc48b848eda49ec2cb6cddc3a96e211665dd463c268ce2")
