-- Lua provided by RyzenAPI
-- Game: Gear Up

-- MAIN APPLICATION
addappid(214420)
addappid(228987)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(214421, 1, "1bc6e289033e48678f29f5746e5932bb679779d089b5c392286fc89f89c4d1ef")
addappid(214422, 1, "be0aa54364b638bcd81135ba6d487416a75d60482ae2ea7cceb30bfe82ac9f95")
addappid(214423, 1, "e249ce9a93ac6409a9b16220d11a93daf737da9021028a6ce4591fa1a7e6fe0e")
