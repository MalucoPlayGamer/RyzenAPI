-- Lua provided by RyzenAPI
-- Game: Roof Rage

-- MAIN APPLICATION
addappid(724300)

-- MAIN APP DEPOTS / PACKAGES
addappid(724301, 1, "fc4fd50b7f1fe0de4c0f323a620a44e9720ac51d6cda1df3d690c87cbc0ad42d")
addappid(875290, 0, "ca48680ffea035d721711e3673af1523e4a18ea9be42c0d40a5b37890aa1eb0e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
