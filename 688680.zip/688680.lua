-- Lua provided by RyzenAPI
-- Game: AppID 688680

-- MAIN APPLICATION
addappid(688680)
-- Game: addappid(688680)

-- MAIN APP DEPOTS / PACKAGES
addappid(688681, 1, "a01acc592558c93b540098b1814fdab7fd5c2fc02c60183b7d8d170a1c48389d")
