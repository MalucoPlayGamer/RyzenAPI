-- Lua provided by RyzenAPI
-- Game: 3257840

-- MAIN APPLICATION
addappid(3257840)
-- Game: addappid(3257840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257841, 1, "704f57205c966d16ef52b6aa0ccd7627294b940e17a8a6da3035b929f0ad1c60")
