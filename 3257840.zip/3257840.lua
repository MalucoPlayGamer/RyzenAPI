-- Lua provided by SkyAPI 
-- Game: AppID 3257840
addappid(3257840)
addappid(3257841, 1, "704f57205c966d16ef52b6aa0ccd7627294b940e17a8a6da3035b929f0ad1c60")
