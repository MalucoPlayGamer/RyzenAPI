-- Lua provided by RyzenAPI 
-- Game: AppID 2068780
addappid(2068780)
addappid(2068781, 1, "81f93bbd4c153b1a86e7ccb0de8f46ae80421456e97974b2b806dc90dff05520")
