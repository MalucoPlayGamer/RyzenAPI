-- Lua provided by RyzenAPI
-- Game: addappid(910830)

-- MAIN APPLICATION
addappid(910830)

-- MAIN APP DEPOTS / PACKAGES
addappid(910831, 1, "a39fbb07aa3051b291171aff6517402324c63d0f5654a6708ecb17e2f232e3d5")
