-- Lua provided by SkyAPI 
-- Game: Rebel Galaxy Outlaw
addappid(910830)
addappid(910831, 1, "a39fbb07aa3051b291171aff6517402324c63d0f5654a6708ecb17e2f232e3d5")
