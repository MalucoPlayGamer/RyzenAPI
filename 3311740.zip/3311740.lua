-- Lua provided by RyzenAPI
-- Game: Game: The Cabin Factory

-- MAIN APPLICATION
addappid(3311740)
addappid(3530930)
-- Game: addappid(3311740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311741, 1, "787c16686bf240711ceb9d86f6c1c936bface7c82f473cf41154365c4e5c9448")
