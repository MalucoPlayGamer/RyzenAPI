-- Lua provided by RyzenAPI
-- Game: The Cabin Factory

-- MAIN APPLICATION
addappid(3311740)
addappid(3530930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311741, 1, "787c16686bf240711ceb9d86f6c1c936bface7c82f473cf41154365c4e5c9448")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
