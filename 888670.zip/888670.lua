-- Lua provided by RyzenAPI
-- Game: AppID 888670

-- MAIN APPLICATION
addappid(888670)

-- MAIN APP DEPOTS / PACKAGES
addappid(888671, 1, "b3356b5e3db3e3c88354a118fa89076206ffca7df0ada96536deec98aad1dee2")

