-- Lua provided by RyzenAPI
-- Game: AppID 888670

-- MAIN APPLICATION
addappid(888670)
addappid(891450)
addappid(891451)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(888671, 1, "b3356b5e3db3e3c88354a118fa89076206ffca7df0ada96536deec98aad1dee2")

