-- Lua provided by RyzenAPI
-- Game: addappid(1392060)

-- MAIN APPLICATION
addappid(1392060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392061, 1, "74af73e58ad252413f3f72633002a75cae1e3bfd9d214e13dd73010089b88b23")
