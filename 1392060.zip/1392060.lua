-- Lua provided by RyzenAPI
-- Game: Erzurum

-- MAIN APPLICATION
addappid(1392060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392061, 1, "74af73e58ad252413f3f72633002a75cae1e3bfd9d214e13dd73010089b88b23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
