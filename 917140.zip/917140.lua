-- Lua provided by RyzenAPI
-- Game: AppID 917140

-- MAIN APPLICATION
addappid(917140)
-- Game: addappid(917140)

-- MAIN APP DEPOTS / PACKAGES
addappid(917141, 1, "3371f4734bf53f7cbfd73b0a893b0af666a6cd970edc9d645d8627c97f5b0550")
