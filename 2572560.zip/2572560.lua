-- Lua provided by RyzenAPI
-- Game: addappid(2572560)

-- MAIN APPLICATION
addappid(2572560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572561, 1, "cf0bd30848acfcd86b26fc381a2c303a11193ea78f30967563afc44b2df00b1f")
