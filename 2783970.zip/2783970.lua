-- Lua provided by RyzenAPI
-- Game: Black stone

-- MAIN APPLICATION
addappid(2783970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783971, 1, "45f9e8a35215a6b4942c12af04502de4597ad2991108bcbbbbec3aede5b2004f")
