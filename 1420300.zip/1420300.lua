-- Lua provided by RyzenAPI
-- Game: No More Heroes 2: Desperate Struggle

-- MAIN APPLICATION
addappid(1420300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420301, 1, "a60b2013357bb6850214cc837c14505b5af9c1cf6ba7021b26ee0050ab4d2422")
