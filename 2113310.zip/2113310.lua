-- Lua provided by SkyAPI 
-- Game: AppID 2113310
addappid(2113310)
addappid(2113311, 1, "29bbae8f78ac29c1a410cabeb7fac1663eaa77e58a714311c6c4535909e5a2f3")
