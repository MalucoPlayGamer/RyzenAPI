-- Lua provided by RyzenAPI
-- Game: Phantom Ascension

-- MAIN APPLICATION
addappid(2738320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738321, 1, "f923c89f1387fe5f8e522ad364e2e90f465f2949ad165018b307ee0e3226a87f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
