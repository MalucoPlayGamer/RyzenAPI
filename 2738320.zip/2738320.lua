-- Lua provided by RyzenAPI
-- Game: Phantom Ascension

-- MAIN APPLICATION
addappid(2738320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738321, 1, "f923c89f1387fe5f8e522ad364e2e90f465f2949ad165018b307ee0e3226a87f")

