-- Lua provided by SkyAPI 
-- Game: Phantom Ascension
addappid(2738320)
addappid(2738321, 1, "f923c89f1387fe5f8e522ad364e2e90f465f2949ad165018b307ee0e3226a87f")
