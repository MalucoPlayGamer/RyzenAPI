-- Lua provided by RyzenAPI
-- Game: Edge of Sanity

-- MAIN APPLICATION
addappid(1897110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983820,0,"37272024a20bca4cf016479a1e188916851d43903513a70e968614356e8ebaff")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3142350)
