-- Lua provided by RyzenAPI
-- Game: addappid(2210720)

-- MAIN APPLICATION
addappid(2210720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210721, 1, "cdea7df79c49329d2da0477e20389bfd1e1448b93dde3b77560fa93612cc8bd6")
addappid(2210722, 1, "bedd588ceef5651cee16a64ce4877cd01f587d3f5496741606e09af41dabd9d0")
