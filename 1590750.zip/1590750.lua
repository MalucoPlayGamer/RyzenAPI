-- Lua provided by SkyAPI 
-- Game: JARS
addappid(1590750)
addappid(1590751, 1, "97eb393b7080554e5dc1b3bb620ed26cb86112ba090acf0040183d533a41c04d")
addappid(1634000, 0, "2ffedb29f27bf8c17634930ec999669819ab5b10cc970e715e808cd54d617b0b")
