-- Lua provided by RyzenAPI
-- Game: addappid(2753810)

-- MAIN APPLICATION
addappid(2753810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753811, 1, "bef98a0747cb03d48cbf16dcb3d8273ba9ef4d3e94ae61afc4d57a1f5035ec95")
