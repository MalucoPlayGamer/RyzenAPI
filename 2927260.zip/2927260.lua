-- Lua provided by RyzenAPI
-- Game: Hentai Misuzu

-- MAIN APPLICATION
addappid(2927260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927261, 1, "d5f312772d0de51eead4aacba406342391ffaea01d9d4b08cf207b6affba6f84")
