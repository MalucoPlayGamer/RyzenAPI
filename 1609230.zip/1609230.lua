-- Lua provided by RyzenAPI
-- Game: Scarlet Hollow

-- MAIN APPLICATION
addappid(1609230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609232,0,"29646f7f269c032994c7c4bdbb56e6a72f01de4549e0439384a040e54a4c6f24")
