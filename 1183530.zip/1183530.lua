-- Lua provided by RyzenAPI
-- Game: addappid(1183530)

-- MAIN APPLICATION
addappid(1183530)
addappid(2892360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183531, 1, "1f64b89b8ea0af3c08a566cfdf4e29c215dc0a3f1b266798d95a3e9dac9571ae")
