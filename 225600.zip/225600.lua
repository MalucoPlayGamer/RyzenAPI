-- Lua provided by RyzenAPI
-- Game: Blade Symphony

-- MAIN APPLICATION
addappid(225600)

-- MAIN APP DEPOTS / PACKAGES
addappid(225601, 1, "91f19adcacb8530dae6ffbf159f3e72660c748a93003e68330cd28ba42efcdb6")
addappid(225602, 1, "de8d020f84444ccbed5139f956506d859c0cf0091e8316ef0200dc0408edb797")
addappid(225603, 1, "6ec8309a030ce5ae1616970e7136b08f10c5b8e4d6c5c9ef9a374e9cb18ea07a")
addappid(225604, 1, "0f888b99c024f0548c7d65005b19cff059861c840f719b2ab0062deaaebf2ddc")
addappid(225605, 1, "d7369c00d65d1ed791dea5ef7115dd8b26ff588f53491479eb2901d23f9f7340")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
