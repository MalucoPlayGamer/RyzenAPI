-- Lua provided by RyzenAPI
-- Game: Blade Symphony

-- MAIN APPLICATION
addappid(225600)
-- Game: addappid(225600)

-- MAIN APP DEPOTS / PACKAGES
addappid(225601, 1, "91f19adcacb8530dae6ffbf159f3e72660c748a93003e68330cd28ba42efcdb6")
addappid(225602, 1, "de8d020f84444ccbed5139f956506d859c0cf0091e8316ef0200dc0408edb797")
addappid(225603, 1, "6ec8309a030ce5ae1616970e7136b08f10c5b8e4d6c5c9ef9a374e9cb18ea07a")
addappid(225604, 1, "0f888b99c024f0548c7d65005b19cff059861c840f719b2ab0062deaaebf2ddc")
addappid(225605, 1, "d7369c00d65d1ed791dea5ef7115dd8b26ff588f53491479eb2901d23f9f7340")
