-- Lua provided by RyzenAPI
-- Game: 2698940

-- MAIN APPLICATION
addappid(2698940)
addappid(2716050)
addappid(2805000)
addappid(2805010)
addappid(2849030)
addappid(2849040)
addappid(2865990)
addappid(2898630)
addappid(2898640)
addappid(2934260)
addappid(3251420)
addappid(3251430)
addappid(3251440)
addappid(3251450)
-- Game: addappid(2698940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698941, 1, "d883429e0c229f4e0634265ea029ccf4200bf0a6d171047809fab73ae807ba8c")
