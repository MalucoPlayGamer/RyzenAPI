-- 2698940's Lua and Manifest Created by Hubcap Manifest
-- The Crew Motorfest
-- Created: July 22, 2026 at 08:42:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 42
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2698940, 1, "0dc63a9c4ead3fdb3ad467c3c1dbbbac237f51ae9d1532ce1ceac086107d4da8") -- The Crew Motorfest
-- MAIN APP DEPOTS
addappid(2698941, 1, "d883429e0c229f4e0634265ea029ccf4200bf0a6d171047809fab73ae807ba8c") -- Depot 2698941
setManifestid(2698941, "3889162474195455966", 81255465286)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2716050) -- The Crew Motorfest - Ubisoft Activation
addappid(2805000) -- The Crew Motorfest  Year 1 Pass
addappid(2805010) -- The Crew Motorfest - Year 1 Pass - Ubisoft Activation
addappid(2849030) -- The Crew Motorfest - Welcome Pack
addappid(2849040) -- The Crew Motorfest - Welcome Pack - Ubisoft Activation
addappid(2865990) -- The Crew Motorfest - Gold Edition Ubisoft Activation
addappid(2898630) -- The Crew Motorfest - Deluxe Edition Ubisoft Activation
addappid(2898640) -- The Crew Motorfest - Ultimate Edition Ubisoft Activation
addappid(2934260) -- The Crew Motorfest - Demo - Ubisoft Activation
addappid(3251420) -- The Crew Motorfest - Year 2 Pass
addappid(3251430) -- The Crew Motorfest  Year 2 Pass - Ubisoft Activation
addappid(3251440) -- The Crew Motorfest Gold Edition Ubisoft Activation
addappid(3251450) -- The Crew Motorfest Ultimate Edition Ubisoft Activation
addappid(3917350) -- The Crew Motorfest Ultimate Edition - Year 3 Ubisoft Activation
addappid(3917380) -- The Crew Motorfest  Year 3 Pass
addappid(3917390) -- The Crew Motorfest  Year 3 Pass Ubisoft Activation
addappid(3917400) -- The Crew Motorfest  Chase Squad Pack
addappid(3917420) -- The Crew Motorfest  Chase Squad Pack Ubisoft Activation
addappid(3917430) -- The Crew Motorfest  BMW Double Car Pack
addappid(3917440) -- The Crew Motorfest  BMW Double Car Pack Ubisoft Activation
addappid(3917450) -- The Crew Motorfest  Alfa Romeo Double Car Pack
addappid(3917460) -- The Crew Motorfest  Alfa Romeo Double Car Pack Ubisoft Activation
addappid(3917470) -- The Crew Motorfest  Ford Triple Car Pack
addappid(3917490) -- The Crew Motorfest  Ford Triple Car Pack Ubisoft Activation
addappid(3917500) -- The Crew Motorfest  Porsche Triple Car Pack
addappid(3917510) -- The Crew Motorfest  Porsche Triple Car Pack Ubisoft Activation
addappid(3917520) -- The Crew Motorfest  JDM Car Pack
addappid(3917530) -- The Crew Motorfest  JDM Car Pack Ubisoft Activation
addappid(4160500) -- The Crew Motorfest RC Frenzy Pack
addappid(4160510) -- The Crew Motorfest RC Frenzy Pack Ubisoft Activation
addappid(4160650) -- The Crew Motorfest  Audi Double Car Pack
addappid(4160660) -- The Crew Motorfest Audi Double Car Pack Ubisoft Activation
addappid(4160670) -- The Crew Motorfest Triple Bike Pack
addappid(4160680) -- The Crew Motorfest Triple Bike Pack Ubisoft Activation
addappid(4160690) -- The Crew Motorfest  JDM Custom Car Pack
addappid(4160700) -- The Crew Motorfest JDM Custom Car Pack Ubisoft Activation
addappid(4670550) -- The Crew Motorfest - Drift Pack
addappid(4670560) -- The Crew Motorfest - Drift Pack Ubisoft Activation
addappid(4670570) -- The Crew Motorfest - Dodge Pack
addappid(4670580) -- The Crew Motorfest - Dodge Pack Ubisoft Activation
addappid(4670590) -- The Crew Motorfest - Chevrolet Pack
addappid(4670600) -- The Crew Motorfest - Chevrolet Pack Ubisoft Activation