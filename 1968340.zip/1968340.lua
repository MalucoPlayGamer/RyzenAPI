-- Lua provided by RyzenAPI
-- Game: 1968340

-- MAIN APPLICATION
addappid(1968340)
-- Game: addappid(1968340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968341, 1, "faf84d813f35f79349e6441e7a5033ed3d5e3fb8205f85f313e15f86fddfa708")
