-- Lua provided by RyzenAPI
-- Game: Project Gunship

-- MAIN APPLICATION
addappid(1968340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968341, 1, "faf84d813f35f79349e6441e7a5033ed3d5e3fb8205f85f313e15f86fddfa708")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
