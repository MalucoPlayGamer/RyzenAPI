-- Lua provided by RyzenAPI
-- Game: 2251690

-- MAIN APPLICATION
addappid(2251690)
-- Game: addappid(2251690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251690,0,"91aa4303a9b756b9798430e047373a6fa1dbe2f390dad3414c6d37fe52978c1e")
