-- Lua provided by RyzenAPI
-- Game: Game: Mouse People

-- MAIN APPLICATION
addappid(2011550)
-- Game: addappid(2011550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011551, 1, "8f0a9e9c82c1122f53cae761fea887008d146e4e4110012411326532637f79f5")
