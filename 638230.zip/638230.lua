-- Lua provided by RyzenAPI
-- Game: Journey

-- MAIN APPLICATION
addappid(638230)

-- MAIN APP DEPOTS / PACKAGES
addappid(638231, 1, "b49b74a2b8b9170fde12db70ff5271bfbe8cbd48407f3eab8bbe23f4671a4ba7")
