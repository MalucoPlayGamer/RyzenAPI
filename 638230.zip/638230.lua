-- Lua provided by RyzenAPI
-- Game: Journey

-- MAIN APPLICATION
addappid(638230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(638231, 1, "b49b74a2b8b9170fde12db70ff5271bfbe8cbd48407f3eab8bbe23f4671a4ba7")

