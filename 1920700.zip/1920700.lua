-- Lua provided by RyzenAPI
-- Game: Candle Prick

-- MAIN APPLICATION
addappid(1920700)
-- Game: addappid(1920700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920701, 1, "f605b6b3052e321470b1d8e41730aa58b66fdb071a2c268b5c3d804bee87d7b4")
