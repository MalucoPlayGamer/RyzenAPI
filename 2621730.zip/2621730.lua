-- Lua provided by RyzenAPI
-- Game: Station to Station Digital Artbook

-- MAIN APPLICATION
addappid(2621730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621730,0,"0cd65795c587e2d4827b11cab86ed7428b5e7dbe8a25769bf3eb204466fa6964")
