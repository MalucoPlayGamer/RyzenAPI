-- Lua provided by RyzenAPI
-- Game: Mori

-- MAIN APPLICATION
addappid(1874500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874501, 1, "7c6f60b2c93d88e1a513d9fa41436c543a4a6badb33dc2b6aba3cb0ea957b2d4")
