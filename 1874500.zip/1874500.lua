-- Lua provided by SkyAPI 
-- Game: Mori
addappid(1874500)
addappid(1874501, 1, "7c6f60b2c93d88e1a513d9fa41436c543a4a6badb33dc2b6aba3cb0ea957b2d4")
