-- Lua provided by RyzenAPI
-- Game: Death's Life 2

-- MAIN APPLICATION
addappid(4633420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4633421,0,"5517f1718b9877f71398ddac799c90340c3796300c94094d003faf0b5c9d0a51")

