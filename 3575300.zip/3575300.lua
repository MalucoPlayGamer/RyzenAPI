-- Lua provided by RyzenAPI
-- Game: Climb The Backrooms

-- MAIN APPLICATION
addappid(3575300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3575301, 1, "a8508e96a50b632f23973925f12fae84e58888a316c10b415ee7225c41530bc4")

