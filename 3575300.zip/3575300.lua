-- Lua provided by RyzenAPI
-- Game: Game: Climb The Backrooms

-- MAIN APPLICATION
addappid(3575300)
-- Game: addappid(3575300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575301, 1, "a8508e96a50b632f23973925f12fae84e58888a316c10b415ee7225c41530bc4")
