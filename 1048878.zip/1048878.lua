-- Lua provided by RyzenAPI
-- Game: addappid(1048878)

-- MAIN APPLICATION
addappid(1048878)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048878,0,"ade04ddfafc10ff3ac778a93fd7187cf03b674737cf8fbcebf7281e98815fc96")
