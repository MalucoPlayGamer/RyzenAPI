-- Lua provided by RyzenAPI
-- Game: addappid(541200)

-- MAIN APPLICATION
addappid(541200)

-- MAIN APP DEPOTS / PACKAGES
addappid(541201, 1, "8fc49d58d6f960536c3c97d21ae11e25665cd241dbe2ee80732b245d615267ce")
