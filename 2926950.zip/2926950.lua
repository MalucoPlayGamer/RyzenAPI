-- Lua provided by RyzenAPI 
-- Game: Crown Jewelz
addappid(2926950)
addappid(2926951, 1, "35ed7a9e6d975f68706380d833f7b76411839dc87216dbcc8771378901e3a729")
