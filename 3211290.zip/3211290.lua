-- Lua provided by RyzenAPI
-- Game: THE GENERAL SAGA

-- MAIN APPLICATION
addappid(3211290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3211293,0,"e4d9698d792070ae1e1959dc9a0100a6b799e7f42c717ea9bfc11f9d9c0ce81e")

