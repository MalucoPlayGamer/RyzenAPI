-- Lua provided by RyzenAPI
-- Game: THE GENERAL SAGA

-- MAIN APPLICATION
addappid(3211290)
-- Game: addappid(3211290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211293,0,"e4d9698d792070ae1e1959dc9a0100a6b799e7f42c717ea9bfc11f9d9c0ce81e")
