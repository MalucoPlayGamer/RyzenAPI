-- Lua provided by RyzenAPI
-- Game: Puyo Puyo™Tetris®

-- MAIN APPLICATION
addappid(546050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(546051, 1, "07d5ebf739c88d9ae6b74f3b8f78957637208f14b597eaf9a0d4efa03adb1ae1")

