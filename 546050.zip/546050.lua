-- Lua provided by RyzenAPI
-- Game: Game: Puyo Puyo™Tetris®

-- MAIN APPLICATION
addappid(546050)
-- Game: addappid(546050)

-- MAIN APP DEPOTS / PACKAGES
addappid(546051, 1, "07d5ebf739c88d9ae6b74f3b8f78957637208f14b597eaf9a0d4efa03adb1ae1")
