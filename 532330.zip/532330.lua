-- Lua provided by RyzenAPI
-- Game: addappid(532330)

-- MAIN APPLICATION
addappid(532330)

-- MAIN APP DEPOTS / PACKAGES
addappid(532331, 1, "971bcf4c044bef9e1d8dcae51384e9ad768fa015dcc1a54e100e444fca40eb1d")
addappid(532332, 1, "e428c7e044a6104f6079577a1cb80bbf4f63b32f3244a101a49c55715bedc855")
addappid(532333, 1, "1759cf91c93aea12909ef93448a37576e94ca39e5a3da2a3cab74c901070f1c2")
