-- Lua provided by RyzenAPI
-- Game: Game: Terminal 81

-- MAIN APPLICATION
addappid(2444470)
-- Game: addappid(2444470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444471, 1, "35ea9a74d526ad3c32259b72269a485e1761473b8287e4e614e21cc737b71e1b")
