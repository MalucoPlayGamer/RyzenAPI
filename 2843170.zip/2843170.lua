-- Lua provided by RyzenAPI
-- Game: SKUFS AND ALT-GIRLS

-- MAIN APPLICATION
addappid(2843170)
-- Game: addappid(2843170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843171, 1, "bf654f3be2a78cba6a1a504d0f0ce095e2fdced05b7c00fe3d3eace12b19f0a5")
