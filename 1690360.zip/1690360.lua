-- Lua provided by RyzenAPI
-- Game: 1690360

-- MAIN APPLICATION
addappid(1690360)
-- Game: addappid(1690360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690361, 1, "e2b81f38adabfdcec5b391d55661d1c7e7694eb52f2d11e708fc6fc8efc6647c")
