-- Lua provided by RyzenAPI
-- Game: COVID: The Outbreak

-- MAIN APPLICATION
addappid(1287000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287001, 1, "31f0361608821bd2c2fbc2f8444b7b98cf22e8c7bedff1efe1b24772097d2d3f")

