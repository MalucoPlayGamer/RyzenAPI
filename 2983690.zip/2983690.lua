-- Lua provided by RyzenAPI
-- Game: AppID 2983690

-- MAIN APPLICATION
addappid(2983690)
-- Game: addappid(2983690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983691, 1, "b8ad177bbc04e67f710ffd4a739eece7a264ac170118896fa0b3e0be9ce6bb0f")
