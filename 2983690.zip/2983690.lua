-- Lua provided by SkyAPI 
-- Game: AppID 2983690
addappid(2983690)
addappid(2983691, 1, "b8ad177bbc04e67f710ffd4a739eece7a264ac170118896fa0b3e0be9ce6bb0f")
