-- Lua provided by RyzenAPI
-- Game: Pumpkin Simulator

-- MAIN APPLICATION
addappid(3817850)

