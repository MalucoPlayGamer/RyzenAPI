-- Lua provided by RyzenAPI
-- Game: The Great Voyage - Visual Novel

-- MAIN APPLICATION
addappid(932820)

-- MAIN APP DEPOTS / PACKAGES
addappid(932821, 1, "8310ea491985b12895dc000ff96547299a00530330ed1969ae5d023292d86be0")
