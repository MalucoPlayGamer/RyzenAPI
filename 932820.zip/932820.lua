-- Lua provided by RyzenAPI
-- Game: The Great Voyage - Visual Novel

-- MAIN APPLICATION
addappid(932820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(932821, 1, "8310ea491985b12895dc000ff96547299a00530330ed1969ae5d023292d86be0")

