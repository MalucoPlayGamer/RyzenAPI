-- Lua provided by RyzenAPI
-- Game: addappid(1217190)

-- MAIN APPLICATION
addappid(1217190)
addappid(1237850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217191, 1, "12624894a733fbf01f4e7c2753aa5e6ddb628f22a1478094cb9bd2b17a9e4ad1")
