-- Lua provided by RyzenAPI
-- Game: addappid(880940)

-- MAIN APPLICATION
addappid(880940)

-- MAIN APP DEPOTS / PACKAGES
addappid(880941, 1, "ce9aa368e895b19d481941c1bc33d93fa1b495f6046caeee282580a6eac1a99c")
