-- Lua provided by RyzenAPI 
-- Game: Pummel Party
addappid(880940)
addappid(880941, 1, "ce9aa368e895b19d481941c1bc33d93fa1b495f6046caeee282580a6eac1a99c")
