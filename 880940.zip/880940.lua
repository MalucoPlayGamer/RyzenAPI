-- Lua provided by RyzenAPI
-- Game: Pummel Party

-- MAIN APPLICATION
addappid(880940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(880941, 1, "ce9aa368e895b19d481941c1bc33d93fa1b495f6046caeee282580a6eac1a99c")

