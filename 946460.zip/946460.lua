-- Lua provided by RyzenAPI 
-- Game: Seven days with the Ghost
addappid(946460)
addappid(946461, 1, "d427be78589a95b0c71ee2c6a353f339d33840fe47b8798a3396d96132138389")
addappid(969620, 0, "e956f5480644edabade38899cf3190d5f2bcf12e2d6317f36619e484049eaf10")
