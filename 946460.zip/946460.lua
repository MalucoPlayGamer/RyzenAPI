-- Lua provided by RyzenAPI
-- Game: Seven days with the Ghost

-- MAIN APPLICATION
addappid(946460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(946461, 1, "d427be78589a95b0c71ee2c6a353f339d33840fe47b8798a3396d96132138389")
addappid(969620, 0, "e956f5480644edabade38899cf3190d5f2bcf12e2d6317f36619e484049eaf10")

