-- Lua provided by RyzenAPI
-- Game: Dongo Adventure

-- MAIN APPLICATION
addappid(811450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(811451, 1, "0316d422d17d074b2837a5dc5db2ce979cd58dd7b6e9721054e94cfc4dc54ba7")

