-- Lua provided by RyzenAPI 
-- Game: Dongo Adventure
addappid(811450)
addappid(811451, 1, "0316d422d17d074b2837a5dc5db2ce979cd58dd7b6e9721054e94cfc4dc54ba7")
