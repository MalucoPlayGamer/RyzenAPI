-- Lua provided by SkyAPI 
-- Game: AppID 769520
addappid(769520)
addappid(769521, 1, "224103a428bbfe8fa50b70f21b29d31438e987dc5d642c552593376bd0d6bb4f")
