-- Lua provided by RyzenAPI
-- Game: AppID 541100

-- MAIN APPLICATION
addappid(541100)

-- MAIN APP DEPOTS / PACKAGES
addappid(541101, 1, "c48bebb98ea302d0f3b6d4a5898a3872b16fab2c096cd3e3ffeba9cc6ee9c452")
addappid(541102, 1, "f804e12b3e6c9d222bf50ddb48b20fa2be07d99a9077702dd03a79afe4ea2db0")
addappid(541103, 1, "0be21a5f3d83f5a14f9e76abb9f38711ec976d0a3aabfb4bc568d53e80f7c252")

