-- Lua provided by RyzenAPI
-- Game: AppID 1175490

-- MAIN APPLICATION
addappid(1175490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175491, 1, "9b4a0e2fcd1749cbb0cd6941fe7feb1b438ec12745ed83ba7a81ed86237c5951")
