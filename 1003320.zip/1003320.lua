-- Lua provided by RyzenAPI
-- Game: addappid(1003320)

-- MAIN APPLICATION
addappid(1003320)
addappid(1082050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003321, 1, "5455b24251c0eac89fee5aa7a68c2a036fd0422a55eab4260e596f99b74930b6")
