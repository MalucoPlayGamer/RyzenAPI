-- Lua provided by RyzenAPI
-- Game: 2793980

-- MAIN APPLICATION
addappid(2793980)
-- Game: addappid(2793980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793981, 1, "275c63aca47b2463356482effed051d121efdf66b2a9552654191affda401ef5")
