-- Lua provided by RyzenAPI
-- Game: Espire 1: VR Operative

-- MAIN APPLICATION
addappid(669290)
addappid(2932030)
-- Game: addappid(669290)

-- MAIN APP DEPOTS / PACKAGES
addappid(669291, 1, "1b6f61a82d1503ef538a798a0b7fc9648ebdc4121940d9680a901a4de18dec54")
