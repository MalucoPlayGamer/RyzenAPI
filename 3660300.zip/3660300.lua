-- Lua provided by RyzenAPI
-- Game: Cash Cleaner Simulator - Soundtrack

-- MAIN APPLICATION
addappid(3660300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660301, 1, "52b76fc0741c08617322b98fe08534682e59ccef8bc508ffee14375bdec30d77")

