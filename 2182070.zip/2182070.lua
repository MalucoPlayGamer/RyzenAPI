-- Lua provided by RyzenAPI
-- Game: AppID 2182070

-- MAIN APPLICATION
addappid(2182070)
-- Game: addappid(2182070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182071, 1, "267e36158a1c3beeb04601fda2f8c2bbc567d8bc56d816af7d174e5d66c28d70")
