-- Lua provided by RyzenAPI
-- Game: 第九日-The 9th Day-

-- MAIN APPLICATION
addappid(491420)
addappid(593990)
addappid(989480)
addappid(989500)
addappid(991580)

-- MAIN APP DEPOTS / PACKAGES
addappid(491421, 1, "90ec7dc750ea6bd728ad11626fe8ee4eee4ff262beee4134d1630839271e1a80")

