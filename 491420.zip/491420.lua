-- Lua provided by RyzenAPI
-- Game: AppID 491420

-- MAIN APPLICATION
addappid(491420)
-- Game: addappid(491420)

-- MAIN APP DEPOTS / PACKAGES
addappid(491421, 1, "90ec7dc750ea6bd728ad11626fe8ee4eee4ff262beee4134d1630839271e1a80")
