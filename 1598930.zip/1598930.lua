-- Lua provided by RyzenAPI
-- Game: 见习侦探

-- MAIN APPLICATION
addappid(1598930)
-- Game: addappid(1598930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598931, 1, "2174cae4885bbc5acc5cea1b2fda8c1ff2d9acf7151bb4d71d8d5a11ab2241ff")
