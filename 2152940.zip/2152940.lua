-- Lua provided by RyzenAPI
-- Game: Game: Hypno Mama

-- MAIN APPLICATION
addappid(2152940)
-- Game: addappid(2152940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152941, 1, "b6718585de07fb85b2d0e2cc0a479fc9cdbb8f6ff16d9c5443dd08821e9e879e")
