-- Lua provided by RyzenAPI
-- Game: Grim Reach Idle

-- MAIN APPLICATION
addappid(4915450)

-- MAIN APP DEPOTS / PACKAGES
addappid(4915451,0,"75688358b18b37b54b5e1c2796faf5f34c7510614fed8ab72929a6d461e8cfbc")

