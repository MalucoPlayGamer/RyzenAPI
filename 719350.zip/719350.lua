-- Lua provided by RyzenAPI
-- Game: setManifestid(719352,"4616380984222860662")

-- MAIN APPLICATION
addappid(719350)
-- Game: addappid(719350)

-- MAIN APP DEPOTS / PACKAGES
addappid(719352,0,"efff4acc172fa0a40646692d0e3607f411c04a60d50552fe3f05466192e0cf9c")
