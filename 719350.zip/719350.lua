-- Lua provided by RyzenAPI
-- Game: Orbits

-- MAIN APPLICATION
addappid(719350)

-- MAIN APP DEPOTS / PACKAGES
addappid(719352,0,"efff4acc172fa0a40646692d0e3607f411c04a60d50552fe3f05466192e0cf9c")

