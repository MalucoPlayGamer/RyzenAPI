-- Lua provided by RyzenAPI
-- Game: NSFW Studio

-- MAIN APPLICATION
addappid(1760080)
-- Game: addappid(1760080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760081, 1, "f96e145fa09fbc79c6b114be6ad7c8a52b746557ef4f6067a810095b8496fc3a")
