-- Lua provided by RyzenAPI
-- Game: Militia

-- MAIN APPLICATION
addappid(421260)

-- MAIN APP DEPOTS / PACKAGES
addappid(421261, 1, "69635e8407ceff1eb30112101a5f43f6083b2ae926a15c99682b1f7d4379d537")
