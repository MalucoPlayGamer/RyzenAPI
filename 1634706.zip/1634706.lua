-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Weapon set 4

-- MAIN APPLICATION
addappid(1634706)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634706,0,"3bde77d0ca2ccd97a2d26c059be283a72bf1e30532345df9f809f62c7a2155f5")

