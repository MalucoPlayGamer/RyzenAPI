-- Lua provided by RyzenAPI 
-- Game: Aunt Fatima - خالة فاطمة
addappid(3030250)
addappid(3030251, 1, "205f918c809a1f6cc90d2dfb900cb9b495ed6f486244cadfbf2d2ff4b62d9de9")
