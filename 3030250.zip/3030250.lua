-- Lua provided by RyzenAPI
-- Game: Aunt Fatima - خالة فاطمة

-- MAIN APPLICATION
addappid(3030250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030251, 1, "205f918c809a1f6cc90d2dfb900cb9b495ed6f486244cadfbf2d2ff4b62d9de9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
