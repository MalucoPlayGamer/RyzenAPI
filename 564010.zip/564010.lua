-- Lua provided by RyzenAPI
-- Game: Stern Pinball Arcade

-- MAIN APPLICATION
addappid(564010)

-- MAIN APP DEPOTS / PACKAGES
addappid(564011, 1, "ce8b309fab0f2c92aa07ae4f0dd9fefe1f06930b5ab67092759c5f532237b70c")

