-- Lua provided by RyzenAPI
-- Game: Stern Pinball Arcade

-- MAIN APPLICATION
addappid(564010)

-- MAIN APP DEPOTS / PACKAGES
addappid(564011, 1, "ce8b309fab0f2c92aa07ae4f0dd9fefe1f06930b5ab67092759c5f532237b70c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(569240)
addappid(569241)
addappid(569242)
addappid(569243)
addappid(569244)
addappid(569245)
addappid(569246)
addappid(569247)
addappid(569248)
addappid(569249)
addappid(744380)
