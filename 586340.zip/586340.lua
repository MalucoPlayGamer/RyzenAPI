-- Lua provided by RyzenAPI
-- Game: Lamm

-- MAIN APPLICATION
addappid(586340)

-- MAIN APP DEPOTS / PACKAGES
addappid(586341, 1, "7ead19ee2f7450d78ba08d86a539b67e938dc76ff6e9aa186271435af58e9613")

