-- Lua provided by RyzenAPI
-- Game: To Be In Love With Girls Group

-- MAIN APPLICATION
addappid(2817530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817531, 1, "d16926e4133c6e84a277b2d7c050cf83af81d87eeaa1ffd39ff646cbb7cdb20f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
