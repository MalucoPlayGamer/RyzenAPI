-- Lua provided by RyzenAPI
-- Game: addappid(2817530)

-- MAIN APPLICATION
addappid(2817530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817531, 1, "d16926e4133c6e84a277b2d7c050cf83af81d87eeaa1ffd39ff646cbb7cdb20f")
