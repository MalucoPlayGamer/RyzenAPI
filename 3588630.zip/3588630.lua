-- Lua provided by RyzenAPI
-- Game: PC Building Empire

-- MAIN APPLICATION
addappid(3588630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588632,0,"9ad11f019d1119b372e552612da3659336a3ec5716eb5bf5c20ea29039582189")

