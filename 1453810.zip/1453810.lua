-- Lua provided by RyzenAPI
-- Game: DEEMO -Reborn- OST: Hidden Dreams Edition

-- MAIN APPLICATION
addappid(1453810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453811, 1, "0afe2a8903e9a3f42ff69b19850865852a64365439fdf0605796069018128dc6")

