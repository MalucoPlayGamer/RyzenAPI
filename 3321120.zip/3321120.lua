-- Lua provided by RyzenAPI
-- Game: 3321120

-- MAIN APPLICATION
addappid(3321120)
-- Game: addappid(3321120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321121, 1, "7e9ca04aa9e3564a29b4cf95c681ab843e9dc8b14b68747db453305efdf070bd")
