-- Lua provided by RyzenAPI
-- Game: 她杀-The Suspected Murder Demo

-- MAIN APPLICATION
addappid(3097390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097391, 1, "2027af80a58010828705a9fa5fa2a00733f460896d3072cb511ca2d4ef8bd406")
