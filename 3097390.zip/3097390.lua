-- Lua provided by SkyAPI 
-- Game: AppID 3097390
addappid(3097390)
addappid(3097391, 1, "2027af80a58010828705a9fa5fa2a00733f460896d3072cb511ca2d4ef8bd406")
