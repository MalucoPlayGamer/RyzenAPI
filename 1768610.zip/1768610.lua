-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic "Welcome Master Set Vol.01"

-- MAIN APPLICATION
addappid(1768610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768611, 1, "aff8ba55f99adae5838a78b8a152f6654e9ee0f625f5bcacaa998846d4a3ee47")
addappid(1768612, 1, "7d8720d2fe5208bab646442b0318ce861dc52b43e8276ed1eadea98ee09347f8")

