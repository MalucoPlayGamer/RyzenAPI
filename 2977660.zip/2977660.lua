-- Lua provided by RyzenAPI
-- Game: Cats

-- MAIN APPLICATION
addappid(2977660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977661, 1, "29150367fcc9e93c29642116034902c42263aef00a211988da1acce45e534eac")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2979900)
addappid(2979910)
