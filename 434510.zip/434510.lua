-- Lua provided by RyzenAPI
-- Game: 434510

-- MAIN APPLICATION
addappid(434510)
-- Game: addappid(434510)

-- MAIN APP DEPOTS / PACKAGES
addappid(434511, 1, "9ef479e4f003d565b67b2302400ebafd204bc92b21d2435fb84880caa2b6f5f6")
