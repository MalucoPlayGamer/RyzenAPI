-- Lua provided by RyzenAPI
-- Game: Formicide

-- MAIN APPLICATION
addappid(434510)

-- MAIN APP DEPOTS / PACKAGES
addappid(434511, 1, "9ef479e4f003d565b67b2302400ebafd204bc92b21d2435fb84880caa2b6f5f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(640770)
