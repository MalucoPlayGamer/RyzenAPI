-- Lua provided by RyzenAPI
-- Game: addappid(2385140)

-- MAIN APPLICATION
addappid(2385140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385141, 1, "911c7d51e9c468d6d4568195c8895612e3642a22bcb2ab0fb48b3336b147d3da")
