-- Lua provided by RyzenAPI
-- Game: Townopolis

-- MAIN APPLICATION
addappid(462730)
-- Game: addappid(462730)

-- MAIN APP DEPOTS / PACKAGES
addappid(462731, 1, "f81a24043040e355c1e869d506d399d220ebeb28c608e3f6ad6bf55aaeb77c14")
addappid(462732, 1, "830bb81b787c3f452d960e474908da77978dc3bda45d7225f6995c10cf4c9195")
addappid(462733, 1, "ce36b5574242f199ba1aea63af029205b41ce3f79aafa317607bfad2166a5119")
addappid(462734, 1, "777fbe57ca184997fac8a2ee543466cace253d6cccaa30b75ec58b780994abeb")
