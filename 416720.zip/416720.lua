-- Lua provided by RyzenAPI
-- Game: Toro

-- MAIN APPLICATION
addappid(416720)
-- Game: addappid(416720)

-- MAIN APP DEPOTS / PACKAGES
addappid(416721, 1, "06b0e929a25c0ff8f531a6699353036344c7e098bb17d55c888d5ce3683dc70a")
