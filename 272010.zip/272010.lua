-- Lua provided by RyzenAPI
-- Game: 272010

-- MAIN APPLICATION
addappid(272010)
-- Game: addappid(272010)

-- MAIN APP DEPOTS / PACKAGES
addappid(272011, 1, "b7da61b5f25a8c164bb3ddee1d558f29441202dd043db732a5765a186c628b23")
