-- Lua provided by RyzenAPI
-- Game: Aveyond 3-1: Lord of Twilight

-- MAIN APPLICATION
addappid(272010)

-- MAIN APP DEPOTS / PACKAGES
addappid(272011, 1, "b7da61b5f25a8c164bb3ddee1d558f29441202dd043db732a5765a186c628b23")
