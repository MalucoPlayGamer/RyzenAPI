-- Lua provided by RyzenAPI
-- Game: Game: Kemono Teatime Demo

-- MAIN APPLICATION
addappid(3345060)
-- Game: addappid(3345060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345061, 1, "c7973c6088d4b10df9c6aec1c30ed49994b9b7048a1374e28bae30a8a816bf30")
