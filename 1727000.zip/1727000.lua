-- Lua provided by RyzenAPI
-- Game: 1727000

-- MAIN APPLICATION
addappid(1727000)
-- Game: addappid(1727000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727001, 1, "bb6f2e0c0915428428f42d536bb7bde4b65fe8b04a826cfcc525ad2892ab3173")
