-- Lua provided by RyzenAPI
-- Game: My Exercise

-- MAIN APPLICATION
addappid(1004330)
-- Game: addappid(1004330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004332,0,"6219aa28410fbbf7e9979cca0efba98cc6da81eff17fbc9192775ac4f1168268")
