-- Lua provided by RyzenAPI 
-- Game: Crowman & Wolfboy
addappid(339590)
addappid(339591, 1, "c65af159257591f70c089f682228abea54f3b8da33bd9559b25f0b1abcd26188")
addappid(339592, 1, "d4f31e216b42e91a8fb834801d14e1cb3379693aa286760a65f978d1a3365db1")
addappid(339593, 1, "8b7ea43ee419b71c71c02ff5b682aba22bdb6f6a928f3d697b959d5c8d907c06")
