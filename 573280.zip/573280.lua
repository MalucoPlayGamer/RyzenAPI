-- Lua provided by RyzenAPI
-- Game: Island Getaway

-- MAIN APPLICATION
addappid(573280)

-- MAIN APP DEPOTS / PACKAGES
addappid(573281,0,"516433dc9245e5013e81cd97473f2f429df7a75cf6dd2a8b3cae7eaeef4c1893")

