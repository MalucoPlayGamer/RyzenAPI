-- Lua provided by RyzenAPI
-- Game: AppID 1917410

-- MAIN APPLICATION
addappid(1917410)
addappid(1917440)
addappid(1917441)
addappid(1917442)
addappid(1917443)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917411, 1, "14d10ae97923317343d4b158b818ae62198db4069f92a7434aaf0eaf7dfcd4e1")
