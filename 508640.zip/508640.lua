-- Lua provided by RyzenAPI
-- Game: addappid(508640)

-- MAIN APPLICATION
addappid(508640)

-- MAIN APP DEPOTS / PACKAGES
addappid(508641, 1, "70814028756d6127eb2d8cdaca9670b0c6a6823d74eecc22f36000d9770cfb7a")
