-- Lua provided by RyzenAPI
-- Game: Game: Kurage Life

-- MAIN APPLICATION
addappid(2989770)
-- Game: addappid(2989770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989771, 1, "a06a1269ac9b495a9f401ce380000be4bd5c575abfffd338c465d3638c05c7f6")
addappid(2989772, 1, "91fdfa4a2ef4d2e22ce827b99710c57365645debd80d06a1b2856d85df96a8aa")
addappid(2989773, 1, "208df771787074be358307ed2950447a4e35583c4b13a49909bfaf23a9f6f2f1")
addappid(2989774, 1, "e5c7bb1a4caead9d8e0c12c9340c6fb3327cac98081f245b54ba87b46cc90cd6")
addappid(2989775, 1, "7cf8eb8a03c22462ffa62adfb0b28d80b800e5db97a44aa0b821ae4c8672f6fd")
