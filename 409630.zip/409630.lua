-- Lua provided by RyzenAPI
-- Game: 409630

-- MAIN APPLICATION
addappid(409630)
-- Game: addappid(409630)

-- MAIN APP DEPOTS / PACKAGES
addappid(409631, 1, "6fecff8dcfa7cc1d3eaf1fc5990210ecca3c031495b694a2f69827cd2f3cd314")
addappid(409632, 1, "07a8927a001e4f726a308296d7d0977f39bddfda5ed2eb77791f9638e11b3faa")
addappid(409633, 1, "bd332fe15bea755f97f8b7b29bcb522fc71f7106a10ba501e79d02774e011732")
