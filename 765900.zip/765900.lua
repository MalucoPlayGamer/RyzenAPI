-- Lua provided by RyzenAPI
-- Game: addappid(765900)

-- MAIN APPLICATION
addappid(765900)

-- MAIN APP DEPOTS / PACKAGES
addappid(765901, 1, "9161e5931ec1944f2f73e72c624e6ee1ed512361302aec79ea5d6c56f101e67d")
