-- Lua provided by RyzenAPI 
-- Game: AppID 385030
addappid(385030)
addappid(385031, 1, "46fdea4dbfe76e22a87ae8f7960a543886bb68144bb83e3c39986259848068c4")
addappid(385032, 1, "ef18741c0a755887f66d94e8133b167cc7748625cad45a8dbdac6eecab79f3b2")
addappid(385033, 1, "cd1fa6d43aa9ee4caed3ac4ff8538e77fb755c52b24f3e8d2753793cc5721b1c")
