-- Lua provided by RyzenAPI 
-- Game: GO SOME BALLS Demo
addappid(2683410)
addappid(2683411, 1, "8747bb25f8f97ea43a399fcaf241ea8906d78f5a6c87c9941816ac2190ffb82d")
