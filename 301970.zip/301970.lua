-- Lua provided by RyzenAPI
-- Game: Screencheat

-- MAIN APPLICATION
addappid(301970)

-- MAIN APP DEPOTS / PACKAGES
addappid(301971, 1, "b6ed32154cb5618765eb9683d2bd231197fed193d83d523868d6a2fac5156c6c")
addappid(301972, 1, "255a20d718a05a763683520e2cb50b98700a87751833b86191b5ab28e8230cae")
addappid(301973, 1, "c52ef5006e5a045566e782df05a0b985f569639deae0f474fdf13d9e443093d9")
addappid(326510, 0, "d9cc56763385b7d66a07f0a0d888403a235bc36a9f7544af4d1a59c71ab918e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(324480)
addappid(326500)
addappid(337020)
addappid(352820)
