-- Lua provided by RyzenAPI
-- Game: Game: AppID 768350

-- MAIN APPLICATION
addappid(768350)
-- Game: addappid(768350)

-- MAIN APP DEPOTS / PACKAGES
addappid(768351, 1, "0832432832fef3b84df003fc7c26a9918380f23325890cc301d830087d8912bd")
