-- Lua provided by RyzenAPI
-- Game: A Highland Song

-- MAIN APPLICATION
addappid(1240060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240061, 1, "96beb02c693855c8614214eb84be8b4a6319ec724365c3a30185ec162b1cfe77")
addappid(1240062, 1, "e34adc0d51d782f99f125d8b7c0d2bab14c12cc3303374fcee4da4c2f736b2dd")

