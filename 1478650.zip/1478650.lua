-- Lua provided by RyzenAPI
-- Game: Diggles: The Myth of Fenris

-- MAIN APPLICATION
addappid(1478650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478651, 1, "5e6e28e671c3df922b6d9d61e69ed7ad1635815dd734c8a1b19413e5743df45a")
addappid(1478652, 1, "b799ea85c17a4584c34f790a8f8b44a48bd845a613b2ae616e7002dbed606fed")
addappid(1478654, 1, "20205e98905cefed61eadd10aca3190ebbabdebf6f01c2509357221b68f6d96c")
addappid(1478655, 1, "99e7238ef8addbd7a258e461689c188e4aac086acd569a692ec69cf44e98903c")
addappid(1478656, 1, "57deee8b9cc97b3e7fb1c95168c64bca228c379ac24fc869ef7ea1eb584dc1d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
