-- Lua provided by RyzenAPI
-- Game: addappid(1926090)

-- MAIN APPLICATION
addappid(1926090)
addappid(2504080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926091, 1, "6158cfa58205db6b7892ff6e1af2cd2eebffdf034bbbcf1835ea5a3d54347aea")
