-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2815510)
-- Game: addappid(2815510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815512,0,"1300e25a3d42f4575462d0c45d57106388d9a7edfabf92b6352c0e184d3950d0")
addappid(2815513,0,"95d1aa60ff64ddf23447f97dace7a7b532104a9982ceffbe37c010f95077d966")
