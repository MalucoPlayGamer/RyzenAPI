-- Lua provided by SkyAPI 
-- Game: AppID 431600
addappid(431600)
addappid(431601, 1, "d638031a059c4448f4093b7353bf0d5a53046d13257c22c1f09a65e618c9ee2e")
