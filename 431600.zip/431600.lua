-- Lua provided by RyzenAPI
-- Game: AppID 431600

-- MAIN APPLICATION
addappid(431600)

-- MAIN APP DEPOTS / PACKAGES
addappid(431601, 1, "d638031a059c4448f4093b7353bf0d5a53046d13257c22c1f09a65e618c9ee2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(521600)
addappid(521610)
addappid(544260)
addappid(550800)
addappid(599810)
addappid(644210)
addappid(724720)
addappid(1150240)
addappid(1150250)
