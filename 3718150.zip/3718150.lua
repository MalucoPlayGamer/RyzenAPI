-- Lua provided by RyzenAPI
-- Game: Game: The Rewinder 2 Original Soundtrack

-- MAIN APPLICATION
addappid(3718150)
-- Game: addappid(3718150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3718151, 1, "0d003e7c236204f4a046834a4ccdbb3aa879329e006059260c9cd5a369e23a35")
addappid(3718152, 1, "76d352ef17c94b39668a3d0780ddada9369151165c189f7697c4d77a6184f2d1")
