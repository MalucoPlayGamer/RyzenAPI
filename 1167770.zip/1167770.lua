-- Lua provided by RyzenAPI
-- Game: 1167770

-- MAIN APPLICATION
addappid(1167770)
-- Game: addappid(1167770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167771, 1, "012d434aabf05e15a3d81bd6db1ab53f9f66536d8762e46fe77a2274b6589e9a")
