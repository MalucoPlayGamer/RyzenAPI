-- Lua provided by RyzenAPI
-- Game: Game: Extinction Void

-- MAIN APPLICATION
addappid(3291350)
-- Game: addappid(3291350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291351, 1, "8980d24c0f24bd60a9f7cfee3e00621887acba5cd0f77448e6e3b58a1f0f8e37")
