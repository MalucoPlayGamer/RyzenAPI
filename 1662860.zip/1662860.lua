-- Lua provided by RyzenAPI
-- Game: Trapper: Drug Dealing RPG

-- MAIN APPLICATION
addappid(1662860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662861, 1, "b0f00f0ee96a0aebcf1e7efee54f95719c6f91009a36c6422870a395dfb5a939")

