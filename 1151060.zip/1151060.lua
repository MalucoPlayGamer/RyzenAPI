-- Lua provided by SkyAPI 
-- Game: AppID 1151060
addappid(1151060)
addappid(1151061, 1, "f2665c59dc3b2f27c72b08648637e9aeb665457093e16595e86a09c738c062e1")
