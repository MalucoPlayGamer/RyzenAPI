-- Lua provided by RyzenAPI
-- Game: 2113150

-- MAIN APPLICATION
addappid(2113150)
-- Game: addappid(2113150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113151, 1, "13630d0553b8c9b6d6dc1563acebd03adb3a9a7d555bc3cf50bc2770c6159db9")
