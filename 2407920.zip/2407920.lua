-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Animals

-- MAIN APPLICATION
addappid(2407920)
-- Game: addappid(2407920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407921, 1, "6bb0a511e1d4663d7868ca885c0ec72f0da8e05ee74ea85590c61cb374d3bafa")
