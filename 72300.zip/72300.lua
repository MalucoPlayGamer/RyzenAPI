-- Lua provided by RyzenAPI
-- Game: Breach

-- MAIN APPLICATION
addappid(72300)

-- MAIN APP DEPOTS / PACKAGES
addappid(72301, 1, "6f93f4c9262dac5a1496c9b47a4d8387a9c9f3c0220f19c0c23edc54911441a2")
