-- Lua provided by SkyAPI 
-- Game: AppID 560220
addappid(560220)
addappid(560221, 1, "e66980bd253dae3084b6c55cb001a1384ac26fdd50da93c850b7eb575d781045")
