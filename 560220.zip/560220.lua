-- Lua provided by RyzenAPI
-- Game: AppID 560220

-- MAIN APPLICATION
addappid(560220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(560221, 1, "e66980bd253dae3084b6c55cb001a1384ac26fdd50da93c850b7eb575d781045")

