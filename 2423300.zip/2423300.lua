-- Lua provided by RyzenAPI
-- Game: Game: School Labyrinth

-- MAIN APPLICATION
addappid(2423300)
-- Game: addappid(2423300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423301, 1, "8f4d53fd82489e6df8c2a017d864bb9a57757dae716fb7eaecfa44ec00ab6075")
