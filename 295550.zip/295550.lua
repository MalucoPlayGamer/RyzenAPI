-- Lua provided by RyzenAPI
-- Game: Royal Quest

-- MAIN APPLICATION
addappid(295550)
addappid(311540)
addappid(313790)
addappid(323740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(295551, 1, "7eb1a222e6678c549fc2f4cb75bd93f0b08bfab98785ef66d43610daa75b894e")
addappid(295552, 1, "d44104399f95cf5ed2265d04309d98924dfc67e61222b94760bc53b8a8811f74")

