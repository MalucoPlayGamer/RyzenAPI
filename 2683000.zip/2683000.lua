-- Lua provided by RyzenAPI
-- Game: XP Soccer Demo

-- MAIN APPLICATION
addappid(2683000)
-- Game: addappid(2683000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683001, 1, "187c297641a03bd078d526ac23d1ee17637a657344f3fc650dcd82ad0e7dc039")
addappid(2683002, 1, "21d35078a0cc1b869b4911b137e7c3f4e8f8ed2c997b52eecd29f52cfe0748ad")
