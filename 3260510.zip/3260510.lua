-- Lua provided by RyzenAPI
-- Game: Game: Cursor Kingdom DEMO

-- MAIN APPLICATION
addappid(3260510)
-- Game: addappid(3260510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260511, 1, "69bd91b8a0c9c94e2b156c132b0030954a024025732f50c5896b9d852044a309")
