-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1848130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848132,0,"1d525c61f2dc68c556ccdb64611359799b8f01402d05375ee8dff8c8bb6359dd")
