-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1227463)
-- Game: addappid(1227463)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227463,0,"df794728969280985cb80b478868a5d57d6d7e9cf9e62493605d059d88e5a37a")
