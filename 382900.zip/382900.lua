-- Lua provided by RyzenAPI
-- Game: AppID 382900

-- MAIN APPLICATION
addappid(382900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(382901, 1, "1783bda70675c8cdf062d8fa6d9d1697a1367c8c20738f7280ea3f832b886551")

