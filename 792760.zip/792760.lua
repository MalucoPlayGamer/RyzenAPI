-- Lua provided by RyzenAPI
-- Game: Game: The Necklace of Blood

-- MAIN APPLICATION
addappid(792760)
-- Game: addappid(792760)

-- MAIN APP DEPOTS / PACKAGES
addappid(792761, 1, "5c9b998c22ae7055614d29a8f091abda0820e24081f8a7707028d54c9695f4e7")
