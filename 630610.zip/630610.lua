-- Lua provided by RyzenAPI
-- Game: AppID 630610

-- MAIN APPLICATION
addappid(630610)

-- MAIN APP DEPOTS / PACKAGES
addappid(630611, 1, "1ee9d227ae66c196b42a041d34a596cb7e75d5014e8a8a845f39bd7c7eae368d")
