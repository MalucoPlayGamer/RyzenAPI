-- Lua provided by RyzenAPI
-- Game: Disneyland Adventures

-- MAIN APPLICATION
addappid(630610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(630611, 1, "1ee9d227ae66c196b42a041d34a596cb7e75d5014e8a8a845f39bd7c7eae368d")
