-- Lua provided by RyzenAPI
-- Game: Crypt Hunter

-- MAIN APPLICATION
addappid(693790)

-- MAIN APP DEPOTS / PACKAGES
addappid(693791,0,"4ad862d8b1c66644b318e01e67c914d6562bda26f80358f6356b47764ea66d63")

