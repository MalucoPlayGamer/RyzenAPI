-- Lua provided by RyzenAPI
-- Game: addappid(1149080)

-- MAIN APPLICATION
addappid(1149080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149081, 1, "79ff1a4ae79feebfc4619e6b0e1c109bea5c74a7ae536841f860d99022540f35")
