-- Lua provided by RyzenAPI
-- Game: addappid(3342390)

-- MAIN APPLICATION
addappid(3342390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342391, 1, "ae39fb0efbb2b2a49cf84f0e8ee987d98eae5b9f52151d89a30cbb8ea18301aa")
