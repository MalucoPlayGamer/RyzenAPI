-- Lua provided by RyzenAPI
-- Game: 2352660

-- MAIN APPLICATION
addappid(2352660)
-- Game: addappid(2352660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352661, 1, "90267d2c860fa14bd967c6f0fe93abc89ff2b49b3f7cd2b431fc02c497bcf52f")
