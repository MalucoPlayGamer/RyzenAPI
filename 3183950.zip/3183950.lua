-- Lua provided by RyzenAPI
-- Game: Симулятор Обнимания Берёзы

-- MAIN APPLICATION
addappid(3183950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(3183951, 1, "eb2ee0eaaca5d13a6e9eb9ab82d845c9e2be82e670dc705b99f9d011f9dab401")
