-- Lua provided by RyzenAPI
-- Game: addappid(3183950)

-- MAIN APPLICATION
addappid(3183950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183951, 1, "eb2ee0eaaca5d13a6e9eb9ab82d845c9e2be82e670dc705b99f9d011f9dab401")
