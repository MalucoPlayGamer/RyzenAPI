-- Lua provided by RyzenAPI
-- Game: My Silly Life

-- MAIN APPLICATION
addappid(1329990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329991, 1, "b9a5509484af68ceb91e76fb87da575a05bb6d4ce5ae4649d6cfb7831660de5e")
