-- 3188480's Lua and Manifest Created by Hubcap Manifest
-- Sea Town - Fish Market Simulator
-- Created: June 25, 2026 at 04:25:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3188480) -- Sea Town - Fish Market Simulator
-- MAIN APP DEPOTS
addappid(3188481, 1, "4523d96b1764aed73f29acf728d83f16e0e2c8b7b78773d2ebd07100e19172ec") -- Depot 3188481
-- setManifestid(3188481, "6255730458255201973", 5558442122)