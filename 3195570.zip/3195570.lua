-- Lua provided by RyzenAPI
-- Game: Jini's Potion Shop DEMO

-- MAIN APPLICATION
addappid(3195570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195571, 1, "490dc384e419e576fb6fad88a565c7e39fbc2edc512e6ad350222a919700cff1")
