-- Lua provided by RyzenAPI
-- Game: Langrisser I & II - Visual Book

-- MAIN APPLICATION
addappid(1205511)
-- Game: addappid(1205511)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205511,0,"84760c9609474694c694666849c904fa5767a2684b15762e67b1212bc49fe637")
