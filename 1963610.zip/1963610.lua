-- Lua provided by RyzenAPI
-- Game: 1963610

-- MAIN APPLICATION
addappid(1963610)
-- Game: addappid(1963610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963611, 1, "57de6985d7bfbfb4bc70c6da255f2f14fe1058300d52b7c3dc7897dd20fc21f5")
