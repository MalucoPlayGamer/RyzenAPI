-- Lua provided by SkyAPI 
-- Game: Rivalhearts
addappid(3232710)
addappid(3232711, 1, "1c4f50fd0d839adba0dab8aa840fd44744c50a41a4c3da2ff0c62b4f87483f1a")
addappid(3232712, 1, "7fecf793e116ebd30ca281e627a459b78fd2cf09dffcc2c31b3277df743572a8")
