-- Lua provided by RyzenAPI
-- Game: Rivalhearts

-- MAIN APPLICATION
addappid(3232710)
-- Game: addappid(3232710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232711, 1, "1c4f50fd0d839adba0dab8aa840fd44744c50a41a4c3da2ff0c62b4f87483f1a")
addappid(3232712, 1, "7fecf793e116ebd30ca281e627a459b78fd2cf09dffcc2c31b3277df743572a8")
