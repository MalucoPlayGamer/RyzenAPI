-- Lua provided by RyzenAPI
-- Game: Game: AppID 603440

-- MAIN APPLICATION
addappid(603440)
-- Game: addappid(603440)

-- MAIN APP DEPOTS / PACKAGES
addappid(603441, 1, "b6941044a2a40ea4bd3949014291127d295ceecd18a1532acf8f62a344ed74e9")
