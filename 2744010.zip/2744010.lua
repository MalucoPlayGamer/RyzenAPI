-- Lua provided by RyzenAPI
-- Game: Urban Jungle

-- MAIN APPLICATION
addappid(2744010)
addappid(4036100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744011, 1, "e9485680f74b921003e502e7360fe17360400e4c16d3e0c5c0d93be67dbd83d2")
