-- Lua provided by RyzenAPI
-- Game: AppID 2744010

-- MAIN APPLICATION
addappid(2744010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744011, 1, "e9485680f74b921003e502e7360fe17360400e4c16d3e0c5c0d93be67dbd83d2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4036100)
