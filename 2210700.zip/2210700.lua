-- Lua provided by SkyAPI 
-- Game: Pechka: Historical Story Adventure
addappid(2210700)
addappid(2210701, 1, "296cafe692d415a547efc5f25e18b31e62b6e0654ef9473a84f3cccfbc75adad")
