-- Lua provided by RyzenAPI
-- Game: Nightwatch: Nightmare Creatures

-- MAIN APPLICATION
addappid(2591990)
-- Game: addappid(2591990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591992,0,"89d1a5186fe24f1e9c1f4b2b5c6ec47045ef3de318099bd5422bfa898fa10cd8")
