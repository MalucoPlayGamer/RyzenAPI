-- Lua provided by RyzenAPI
-- Game: Nightwatch: Nightmare Creatures

-- MAIN APPLICATION
addappid(2591990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591992,0,"89d1a5186fe24f1e9c1f4b2b5c6ec47045ef3de318099bd5422bfa898fa10cd8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
