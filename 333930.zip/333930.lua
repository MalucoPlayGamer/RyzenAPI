-- Lua provided by RyzenAPI
-- Game: 333930

-- MAIN APPLICATION
addappid(333930)
-- Game: addappid(333930)

-- MAIN APP DEPOTS / PACKAGES
addappid(333931, 1, "bf7f16bec55fbbfe22a84bfb8f8c72b28bae98be84685b8c8ad5981a97ccc564")
