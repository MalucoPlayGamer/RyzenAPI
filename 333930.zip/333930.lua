-- Lua provided by RyzenAPI
-- Game: Dirty Bomb®

-- MAIN APPLICATION
addappid(333930)

-- MAIN APP DEPOTS / PACKAGES
addappid(333931, 1, "bf7f16bec55fbbfe22a84bfb8f8c72b28bae98be84685b8c8ad5981a97ccc564")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(355730)
addappid(376380)
addappid(414390)
addappid(420780)
addappid(420781)
addappid(426951)
addappid(426952)
addappid(442240)
addappid(470011)
addappid(470012)
addappid(483810)
addappid(492420)
addappid(649840)
addappid(649860)
addappid(649861)
addappid(701310)
addappid(701311)
addappid(701312)
addappid(766030)
addappid(780550)
addappid(780560)
addappid(780561)
addappid(866210)
addappid(866211)
addappid(866212)
