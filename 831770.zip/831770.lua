-- Lua provided by RyzenAPI
-- Game: addappid(831770)

-- MAIN APPLICATION
addappid(831770)

-- MAIN APP DEPOTS / PACKAGES
addappid(831771, 1, "ac08b4c32c0a7d096f4dc296594d81b73d5810ce0afb8f8d50f9a6b66a823ea1")
