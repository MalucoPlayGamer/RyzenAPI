-- Lua provided by RyzenAPI
-- Game: Game: AppID 1912870

-- MAIN APPLICATION
addappid(1912870)
-- Game: addappid(1912870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912871, 1, "79c69b6f06952d41c49ec9297530e5622166725e8b15f00ca3ceab3527b020b7")
