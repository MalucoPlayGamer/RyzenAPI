-- 2568700's Lua and Manifest Created by Hubcap Manifest
-- Turbo Tails
-- Created: August 11, 2026 at 14:38:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2568700) -- Turbo Tails
-- MAIN APP DEPOTS
addappid(2568701, 1, "f1e8c095448d5324f3327f87cdca5355f9f7f12262f935b2a1b109d22f545173") -- Depot 2568701
setManifestid(2568701, "2960203624146858478", 437319230)