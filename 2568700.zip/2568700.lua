-- Lua provided by RyzenAPI
-- Game: Turbo Tails

-- MAIN APPLICATION
addappid(2568700) -- Turbo Tails

-- MAIN APP DEPOTS / PACKAGES
addappid(2568701, 1, "f1e8c095448d5324f3327f87cdca5355f9f7f12262f935b2a1b109d22f545173") -- Depot 2568701

