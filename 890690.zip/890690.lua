-- Lua provided by RyzenAPI
-- Game: Forgotten World

-- MAIN APPLICATION
addappid(890690)

-- MAIN APP DEPOTS / PACKAGES
addappid(890691, 1, "7623d8d6a2879f2d1fd5124668964457f72732620cd51a4f6e27b7ba20c0f47f")

