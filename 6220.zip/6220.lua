-- Lua provided by RyzenAPI
-- Game: FlatOut

-- MAIN APPLICATION
addappid(6220)

-- MAIN APP DEPOTS / PACKAGES
addappid(6221, 1, "a318ddc4bf8c63e6ecfa46d878c21d04dabfa80ba8ba9eb838d7f9a13bedf6f6")
addappid(6222, 1, "f947d5e1a74a04269860461fe20a5e5f9a326bd27c92186976ae617703e2f68c")
addappid(6223, 1, "c5bb8fc46acfd0ad00cd1c77cbc8d8bc35d443dbb46cd8dcebef0299952cc2ae")
addappid(6224, 1, "33544b074b5f6f40acbf2f733e97fa5e3a88e4a6c81a7564a071ebb4344e06df")
