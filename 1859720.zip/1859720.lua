-- Lua provided by RyzenAPI
-- Game: Discolored 2

-- MAIN APPLICATION
addappid(1859720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859721, 1, "c9f02eed19495e86d65c39c6c79711e5ad756ae700b25d7e5eb673784316e782")
