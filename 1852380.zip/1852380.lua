-- Lua provided by RyzenAPI
-- Game: 1852380

-- MAIN APPLICATION
addappid(1852380)
-- Game: addappid(1852380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852381, 1, "0f2dfad9280bb6838b1ffc769599309709335040b3d12a179a7babb2871c7e41")
