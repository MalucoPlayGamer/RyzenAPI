-- Lua provided by RyzenAPI
-- Game: Papetura

-- MAIN APPLICATION
addappid(593640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(593641, 1, "e901f32b88d28e01795c327b131284e7be2f92c2cb40257ed52918c4a9b76d2f")
addappid(593642, 1, "a978a41cf1ef8a5c33cba0a2b4f9a353e19fae2932d3b2c4e7dc82eb23a33013")
addappid(1622870, 0, "037213c4f993a87291239a27068d49464860fabe1e594e12e1be0ddee13e6b37")

