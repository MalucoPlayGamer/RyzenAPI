-- Lua provided by RyzenAPI
-- Game: 1089198

-- MAIN APPLICATION
addappid(1089198)
-- Game: addappid(1089198)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089198,0,"53ffdc97a17ac6191da1b4f96f202a8f7bb6c215675e41d5da8451160134d279")
