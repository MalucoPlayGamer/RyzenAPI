-- Lua provided by RyzenAPI 
-- Game: Destroy All Humans! Demo
addappid(1297100)
addappid(1297101, 1, "0cb317fa783a326d5a86e9ff54c98d30517e70915673b06a4cc505607be2ff50")
addappid(1297102, 1, "e5c7b3e7ecf431a1fb62849b585b55c18c2063c3679d32bf1db666e6c4f7cce8")
