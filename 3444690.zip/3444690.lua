-- Lua provided by SkyAPI 
-- Game: Dying Sun
addappid(3444690)
addappid(3444691, 1, "a002fa25eed233a027840cf24b67e3b91d7115eb8d70aac68000593fe372c86a")
