-- Lua provided by RyzenAPI
-- Game: Eronoctosis: Put Yourself Together

-- MAIN APPLICATION
addappid(1683860)

