-- Lua provided by RyzenAPI
-- Game: Eronoctosis: Put Yourself Together

-- MAIN APPLICATION
addappid(1683860)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1867600)
