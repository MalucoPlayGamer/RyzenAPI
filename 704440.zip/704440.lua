-- Lua provided by RyzenAPI
-- Game: Nimble Fish

-- MAIN APPLICATION
addappid(704440)

-- MAIN APP DEPOTS / PACKAGES
addappid(704441, 1, "97e9023480aa948ed3507080af52c2157f60d511a56e5650229ebb2f991e954c")
