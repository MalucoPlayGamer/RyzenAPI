-- 4008350's Lua and Manifest Created by Hubcap Manifest
-- Beat The Champions
-- Created: June 12, 2026 at 13:48:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4008350) -- Beat The Champions
-- MAIN APP DEPOTS
addappid(4008351, 1, "0371b3ca9aae8c0d8f7ad665ca8584e1428e1819914545e483094dc5cadbc91c") -- Depot 4008351
setManifestid(4008351, "4752252306519132726", 1756480656)