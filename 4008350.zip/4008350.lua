-- Lua provided by RyzenAPI
-- Game: Beat The Champions

-- MAIN APPLICATION
addappid(4008350)
addappid(4008350) -- Beat The Champions

-- MAIN APP DEPOTS / PACKAGES
addappid(4008351, 1, "0371b3ca9aae8c0d8f7ad665ca8584e1428e1819914545e483094dc5cadbc91c") -- Depot 4008351

