-- Lua provided by RyzenAPI
-- Game: addappid(625800)

-- MAIN APPLICATION
addappid(625800)

-- MAIN APP DEPOTS / PACKAGES
addappid(625803,0,"d0d4514494b28ef791f6e228fd71752a7a770ce536e0aa5b7880a16149defa4d")
