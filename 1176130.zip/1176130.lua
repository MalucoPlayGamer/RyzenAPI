-- Lua provided by RyzenAPI
-- Game: Ashes of the Singularity: Escalation - Hunter / Prey Expansion

-- MAIN APPLICATION
addappid(1176130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176130,0,"c8ea9d0ac2b508458e4b046214a1cbd0030c48e76793494484352b3562e0ca80")
