-- Lua provided by RyzenAPI
-- Game: AppID 1437510

-- MAIN APPLICATION
addappid(1437510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437511, 1, "3dad9e8883d815eb7a9cc056f8f7757daf1f1bebafa199db1eb7915cb9670143")
