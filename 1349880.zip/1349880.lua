-- Lua provided by RyzenAPI
-- Game: Faild Adventurer Demo

-- MAIN APPLICATION
addappid(1349880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349881, 1, "2a2e00c1cbf7cebf348420952c44d1b15fa9c73d65eacdfe11bd0285c05216c1")
