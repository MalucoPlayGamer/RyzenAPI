-- Lua provided by RyzenAPI
-- Game: Time to Strike

-- MAIN APPLICATION
addappid(2603410)
-- Game: addappid(2603410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603411, 1, "8528391081dfe241e80b9b183dcfc2c79da6fdd298ba3b2d2bd22f8e4b22b4bd")
