-- Lua provided by RyzenAPI
-- Game: addappid(478010)

-- MAIN APPLICATION
addappid(478010)

-- MAIN APP DEPOTS / PACKAGES
addappid(478011, 1, "99a3aa55136b9599d847ede5e5ad4a06266d254aba22a2cb01034d7194a2e378")
