-- Lua provided by SkyAPI 
-- Game: Stardiver
addappid(1599070)
addappid(1599071, 1, "6902f3a7b539e380116737cffc99935734abf889c81cbf63887c6dd7fac24f00")
