-- Lua provided by RyzenAPI
-- Game: 1599070

-- MAIN APPLICATION
addappid(1599070)
-- Game: addappid(1599070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599071, 1, "6902f3a7b539e380116737cffc99935734abf889c81cbf63887c6dd7fac24f00")
