-- Lua provided by SkyAPI 
-- Game: Wingspan Soundtrack
addappid(1332420)
addappid(1332421, 1, "8753f2c35620c8b811315dfa7573fed19bc8f4a684e0a73b760ed3525d6d6fa3")
addappid(1332422, 1, "489d4d3c9bcefa769d23ceaaf0789de21f974b57fdf42726605b19cc8ed4a497")
