-- Lua provided by RyzenAPI
-- Game: Homeseek Demo

-- MAIN APPLICATION
addappid(2123660)
-- Game: addappid(2123660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123661, 1, "68650d3be8c4c182c0421624dcad234628600d97b427359639ed6522589a68f8")
