-- Lua provided by RyzenAPI
-- Game: Death Stair

-- MAIN APPLICATION
addappid(444880)

-- MAIN APP DEPOTS / PACKAGES
addappid(444883,0,"1321897e73e9c8faea9702f65c3f50c7620ca3288275e6285960a9d39094193c")

