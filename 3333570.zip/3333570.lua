-- Lua provided by RyzenAPI
-- Game: Game: AppID 3333570

-- MAIN APPLICATION
addappid(3333570)
-- Game: addappid(3333570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333571, 1, "0242087aa6150dc26ca9c7cd3fe507891c0c2392f1377c0002d50e04a472df80")
