-- Lua provided by RyzenAPI
-- Game: 1086850

-- MAIN APPLICATION
addappid(1086850)
-- Game: addappid(1086850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086851, 1, "21cba631e376f1b388622a1059865db5e991e1b9b18ae5c5a532de3b09aa8967")
