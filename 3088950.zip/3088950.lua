-- Lua provided by RyzenAPI
-- Game: Star Trucker - Heavy Duty Pack

-- MAIN APPLICATION
addappid(3088950)
-- Game: addappid(3088950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088950,0,"360ccc21ba2392f48bb79f55743a3883e02b09f007ab33d464b425f8378a326e")
