-- Lua provided by RyzenAPI
-- Game: Tidal Shock

-- MAIN APPLICATION
addappid(1262890)
addappid(1276780)
addappid(1276781)
addappid(3358700)
addappid(3358710)
addappid(3358720)
addappid(3358730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262891, 1, "d7900800e3afdb8e572966743ba0dfde21e5a64214d6b316f063bbbdeea04883")
addappid(1262892, 1, "e7a749b7d293fb8baf311b6c1a919894110ecc0efc8c44290410fd9c6ef1563a")
