-- Lua provided by RyzenAPI
-- Game: ZPlague

-- MAIN APPLICATION
addappid(1870280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870281, 1, "046a0aa3a0bc0eacc054d4c4ee1c6407fb5cfa3e016fa5b63d2c72ebba85f152")

