-- Lua provided by RyzenAPI
-- Game: ZPlague

-- MAIN APPLICATION
addappid(1870280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1870281, 1, "046a0aa3a0bc0eacc054d4c4ee1c6407fb5cfa3e016fa5b63d2c72ebba85f152")

