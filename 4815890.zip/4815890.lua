-- Lua provided by RyzenAPI
-- Game: Monster Garden: Monster Girls Labyrinth

-- MAIN APPLICATION
addappid(4815890) -- Monster Garden: Monster Girls Labyrinth

-- MAIN APP DEPOTS / PACKAGES
addappid(4815891, 1, "df9aae6e08d70ee30cd019b516a8a3fed305ad4fa55d330c0fe4757d540a0cb3") -- Depot 4815891
addappid(4815892, 1, "907367ef646d4946f8f1a3020a229a8c5d72923f43c93e12aa620c5cd9479fc0") -- Depot 4815892

