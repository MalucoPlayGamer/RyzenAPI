-- 4815890's Lua and Manifest Created by Hubcap Manifest
-- Monster Garden: Monster Girls Labyrinth
-- Created: August 06, 2026 at 23:52:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4815890) -- Monster Garden: Monster Girls Labyrinth
-- MAIN APP DEPOTS
addappid(4815891, 1, "df9aae6e08d70ee30cd019b516a8a3fed305ad4fa55d330c0fe4757d540a0cb3") -- Depot 4815891
setManifestid(4815891, "190142452597582265", 966520810)
addappid(4815892, 1, "907367ef646d4946f8f1a3020a229a8c5d72923f43c93e12aa620c5cd9479fc0") -- Depot 4815892
setManifestid(4815892, "1228168018637604333", 967979498)