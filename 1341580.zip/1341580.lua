-- Lua provided by RyzenAPI
-- Game: addappid(1341580)

-- MAIN APPLICATION
addappid(1341580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341582,0,"aa0aa0c7ccbbf1ffab4b4d84155ed302e26fff835f02bff5e7c54c93ca6e1534")
