-- Lua provided by RyzenAPI
-- Game: 258990

-- MAIN APPLICATION
addappid(258990)

-- MAIN APP DEPOTS / PACKAGES
addappid(258995,0,"58d3da4bbbabd8d942cb669641d544a639cc7d67406c5317d7283a4618002a38")
addappid(258996,0,"c82dab5aa304f902af42fbd1a1febb073ce4bec6f9cb1a6b4b23cdb5c3638980")

