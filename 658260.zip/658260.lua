-- Lua provided by RyzenAPI
-- Game: AppID 658260

-- MAIN APPLICATION
addappid(658260)

-- MAIN APP DEPOTS / PACKAGES
addappid(658261, 1, "bc8db29f4ace088199b4a7707a605213d76c51412d5c2507cd6cf1bb78c153c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(688240)
addappid(688241)
addappid(688242)
addappid(688243)
addappid(688244)
addappid(688245)
addappid(688246)
addappid(688247)
addappid(688248)
addappid(688249)
addappid(688250)
addappid(688251)
addappid(688252)
addappid(688253)
addappid(688254)
addappid(688255)
addappid(688256)
addappid(688257)
addappid(688258)
addappid(688259)
addappid(688270)
addappid(688271)
addappid(688272)
addappid(688273)
addappid(688274)
addappid(704150)
