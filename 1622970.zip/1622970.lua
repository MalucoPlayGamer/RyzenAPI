-- Lua provided by RyzenAPI
-- Game: Game: Packing House

-- MAIN APPLICATION
addappid(1622970)
-- Game: addappid(1622970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622971, 1, "de8cff4e2e345b51e7ba8366b3a159460113f9ef15e843722d5c26bca30b62e3")
