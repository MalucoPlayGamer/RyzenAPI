-- Lua provided by RyzenAPI
-- Game: Abstract Grind

-- MAIN APPLICATION
addappid(2100300)
-- Game: addappid(2100300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100301, 1, "307fb14ea8d16ff03d45e083e6159b1a57fcae6057cc0a3892f66924e371a9b9")
