-- Lua provided by RyzenAPI
-- Game: QT Soundtrack

-- MAIN APPLICATION
addappid(1279670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279672,0,"e26f50dad6d6c6fc56a3f29a7025d3b520098f8a7ef2a8bf5e437dd4523b2528")
