-- Lua provided by RyzenAPI
-- Game: 2244620

-- MAIN APPLICATION
addappid(2244620)
-- Game: addappid(2244620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244621, 1, "fdca144cbf4078aa8e6236ec8c5780b63898efc47f292378862cb9380483ffa9")
