-- Lua provided by SkyAPI 
-- Game: AppID 2744350
addappid(2744350)
addappid(2744351, 1, "3ebf6322f0cfb5929d6e92adbcdb6980ba8d4a395065e87fd24ee965a992f659")
addappid(2748890, 0, "ad7ff7c5558d7ba1f1316f667eb95b21d980af91eb3001f4dc045cb9d6f14618")
