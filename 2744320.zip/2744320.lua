-- Lua provided by SkyAPI 
-- Game: The Stalked Demo
addappid(2744320)
addappid(2744321, 1, "ba6a09281b9bfe1848ab3a630260d1ec9b8a38be50c1d93b12e77b57aa88880a")
