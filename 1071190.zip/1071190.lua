-- Lua provided by RyzenAPI
-- Game: Game: MineRalph

-- MAIN APPLICATION
addappid(1071190)
-- Game: addappid(1071190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071191, 1, "5fac98230b7976c192bfa891d8e83a409bbcd7210c01747885adb101dd8c5c57")
