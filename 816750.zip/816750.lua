-- Lua provided by RyzenAPI
-- Game: Game: AppID 816750

-- MAIN APPLICATION
addappid(816750)
-- Game: addappid(816750)

-- MAIN APP DEPOTS / PACKAGES
addappid(816751, 1, "f0d0330a45abf6c0d8f70777904957741f672f8395248d7a4ba2c6c25e8f7752")
