-- Lua provided by SkyAPI 
-- Game: SALVATIONLAND
addappid(1807590)
addappid(1807591, 1, "188967392dc8f8462eecf35caa0ef6461fb48fb342e251d8c300432a52701da2")
