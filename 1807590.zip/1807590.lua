-- Lua provided by RyzenAPI
-- Game: 1807590

-- MAIN APPLICATION
addappid(1807590)
-- Game: addappid(1807590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807591, 1, "188967392dc8f8462eecf35caa0ef6461fb48fb342e251d8c300432a52701da2")
