-- Lua provided by RyzenAPI
-- Game: 3461780

-- MAIN APPLICATION
addappid(3461780)
-- Game: addappid(3461780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461782,0,"6f342799c4ac5a96c2c177fb1fc1a58bdcb55e8dd86643d4d03532a419fe652d")
