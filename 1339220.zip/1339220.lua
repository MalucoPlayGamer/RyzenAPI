-- Lua provided by RyzenAPI
-- Game: Game: Matt's Project Survival

-- MAIN APPLICATION
addappid(1339220)
-- Game: addappid(1339220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339221, 1, "18e369e0bcbf273dce6b9848b817e01927235db4947beb97ac5e79d65a6a9d16")
