-- Lua provided by RyzenAPI
-- Game: STAY COOL, KOBAYASHI-SAN!: A RIVER CITY RANSOM STORY

-- MAIN APPLICATION
addappid(836590)

-- MAIN APP DEPOTS / PACKAGES
addappid(836591, 1, "c54c4cb25c499519385a1b15c72ab5c52123e055e6139a3ab1a6ecca9c07f7d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
