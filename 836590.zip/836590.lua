-- Lua provided by RyzenAPI
-- Game: addappid(836590)

-- MAIN APPLICATION
addappid(836590)

-- MAIN APP DEPOTS / PACKAGES
addappid(836591, 1, "c54c4cb25c499519385a1b15c72ab5c52123e055e6139a3ab1a6ecca9c07f7d1")
