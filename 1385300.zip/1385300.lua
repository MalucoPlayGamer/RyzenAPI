-- Lua provided by RyzenAPI
-- Game: Eternal Quest - 2D MMORPG

-- MAIN APPLICATION
addappid(1385300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385301, 1, "37ba040bce2dbb30f39ede3d93dc1d1753c3916501282f8b2d02f28aa37d20f3")

