-- Lua provided by RyzenAPI
-- Game: Game: AppID 2518560

-- MAIN APPLICATION
addappid(2518560)
-- Game: addappid(2518560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518561, 1, "872c75718bcf96e67550be32b427a5c2961d9e2ee8cfdf1dc09e7171c1f24ebb")
