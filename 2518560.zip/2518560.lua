-- Lua provided by RyzenAPI
-- Game: 哥布林信条 Goblin Creed

-- MAIN APPLICATION
addappid(2518560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2518561, 1, "872c75718bcf96e67550be32b427a5c2961d9e2ee8cfdf1dc09e7171c1f24ebb")
