-- Lua provided by RyzenAPI
-- Game: The Dark Heart of Balor

-- MAIN APPLICATION
addappid(1247580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247581, 1, "91d727a854bdee167598ed35c3ad5b5ba85876f47a52ca409a2472b7b738d7ef")

