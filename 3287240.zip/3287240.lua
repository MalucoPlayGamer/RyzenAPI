-- Lua provided by RyzenAPI
-- Game: 3287240

-- MAIN APPLICATION
addappid(3287240)
-- Game: addappid(3287240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287241, 1, "05cfcbc2af2a35cc8f773eec09fe6fb1a30fb70cc71aaa93397077ec1ab73c45")
