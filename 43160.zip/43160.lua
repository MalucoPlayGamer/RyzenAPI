-- Lua provided by RyzenAPI
-- Game: Game: AppID 43160

-- MAIN APPLICATION
addappid(43160)
addappid(228983)
addappid(228990)
addappid(229032)
-- Game: addappid(43160)

-- MAIN APP DEPOTS / PACKAGES
addappid(43161, 1, "aaa7d8fa6a079dfa9f4539d14ad5d597ae9eaea8d1b47df83d83e7b5b3735f73")
addappid(43162, 1, "049f4d43c02d5084bb366177de273ba7a8e1dce19581d7bd3af8fe888398d6dc")
addappid(43163, 1, "1717ae799dd8bf33e09cdd588c55bb1d8fcad96f404a07eafa1dc31e4581d0bb")
addappid(43164, 1, "cd11061b5f7840e14afa95c8878820a0bd412d720206309b18fd76fec9b70eaf")
addappid(43165, 1, "899b0ea7f2617c62d551e2e9b8697e5b80f07a8623b588347d3ad2cfa510a2a0")
