-- Lua provided by RyzenAPI
-- Game: 529940

-- MAIN APPLICATION
addappid(529940)
-- Game: addappid(529940)

-- MAIN APP DEPOTS / PACKAGES
addappid(529941, 1, "88ece72762f56fde9a95a64f45569cde45f71d086dfa8d0deb994ac550b08bc3")
