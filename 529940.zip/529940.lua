-- Lua provided by SkyAPI 
-- Game: AppID 529940
addappid(529940)
addappid(529941, 1, "88ece72762f56fde9a95a64f45569cde45f71d086dfa8d0deb994ac550b08bc3")
