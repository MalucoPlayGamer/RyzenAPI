-- Lua provided by RyzenAPI
-- Game: Fight Crab

-- MAIN APPLICATION
addappid(1213750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213751, 1, "9213b948f61e57a0ddda5246be40ad7c18be5158a46c1e56dc9b1013dd57b209")

