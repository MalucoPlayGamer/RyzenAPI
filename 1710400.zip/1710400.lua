-- Lua provided by RyzenAPI
-- Game: addappid(1710400)

-- MAIN APPLICATION
addappid(1710400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710401, 1, "74f96b1d8d1ef9e0eca914054d9698809d03e40a28c3f36883a9a5fb4556ef62")
