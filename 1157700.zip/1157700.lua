-- Lua provided by RyzenAPI
-- Game: Pro Wrestling Sim

-- MAIN APPLICATION
addappid(1157700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157702,0,"bfff8bd2105e9dd7d3368885e07e0c04e7f54e524811e9c2f9cee3b67c96804f")
