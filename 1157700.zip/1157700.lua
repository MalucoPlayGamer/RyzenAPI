-- Lua provided by RyzenAPI
-- Game: Pro Wrestling Sim

-- MAIN APPLICATION
addappid(1157700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1157702,0,"bfff8bd2105e9dd7d3368885e07e0c04e7f54e524811e9c2f9cee3b67c96804f")

