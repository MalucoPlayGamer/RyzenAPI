-- Lua provided by RyzenAPI
-- Game: The Unnamed Game

-- MAIN APPLICATION
addappid(1651300)
-- Game: addappid(1651300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651301, 1, "0d660d62137cf06d47b6b436b536aada4e7ee09b9ec9ef1cf1b224c9a1fe5d11")
