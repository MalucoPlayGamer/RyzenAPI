-- Lua provided by RyzenAPI
-- Game: Game: Gododo

-- MAIN APPLICATION
addappid(1416140)
-- Game: addappid(1416140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416141, 1, "739152873add9d5005fe81041963da2f4c47f2d2c9fbc130a960f1aad7ab93f5")
