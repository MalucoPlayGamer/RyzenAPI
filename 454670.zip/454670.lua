-- Lua provided by RyzenAPI
-- Game: Piggy Princess

-- MAIN APPLICATION
addappid(454670)

-- MAIN APP DEPOTS / PACKAGES
addappid(454671, 1, "687d959280a4c7e1bc7516f0cc7dcd90f8aa647591c3ebcf0b9159c43d1257e7")

