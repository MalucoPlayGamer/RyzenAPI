-- Lua provided by SkyAPI 
-- Game: Piggy Princess
addappid(454670)
addappid(454671, 1, "687d959280a4c7e1bc7516f0cc7dcd90f8aa647591c3ebcf0b9159c43d1257e7")
