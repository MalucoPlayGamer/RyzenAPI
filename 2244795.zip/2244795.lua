-- Lua provided by RyzenAPI
-- Game: Rune Factory 3 Special - Martin's Outfit

-- MAIN APPLICATION
addappid(2244795)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244795,0,"15a2f21700669317dae27e83ec94f308caf8ea13bbc6a78bf464cf2b473f82be")

