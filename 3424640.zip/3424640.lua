-- Lua provided by RyzenAPI
-- Game: Game: ENDER MAGNOLIA: Bloom in the Mist Soundtrack

-- MAIN APPLICATION
addappid(3424640)
-- Game: addappid(3424640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424641, 1, "1b146a452619aa3d68065cfed55c65076107684de35d6068978676706ed2a50d")
addappid(3424642, 1, "5d45581c14f35a81d73c38d8e575827335a8c071de0f48541ed28cf67cc4b3b9")
