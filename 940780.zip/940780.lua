-- Lua provided by SkyAPI 
-- Game: AppID 940780
addappid(940780)
addappid(940781, 1, "45b13a6d1fe98ef06a52d3e835a205e341df379b6010b0cfb78b16d4cf9bf61d")
addappid(940784, 1, "7d48697c258c422b578a53ee4f248e0bd48ff53172632942dffe0affcb5b737d")
