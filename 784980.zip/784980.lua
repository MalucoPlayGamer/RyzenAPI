-- Lua provided by RyzenAPI
-- Game: 784980

-- MAIN APPLICATION
addappid(784980)
-- Game: addappid(784980)

-- MAIN APP DEPOTS / PACKAGES
addappid(784981, 1, "0547a2ab0a3fe9db527595b5f04090739a65e857f09afb30f974e8724b2a9891")
