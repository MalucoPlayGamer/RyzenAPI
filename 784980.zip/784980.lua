-- Lua provided by SkyAPI 
-- Game: AppID 784980
addappid(784980)
addappid(784981, 1, "0547a2ab0a3fe9db527595b5f04090739a65e857f09afb30f974e8724b2a9891")
