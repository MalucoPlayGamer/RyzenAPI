-- Lua provided by RyzenAPI
-- Game: Aggelos

-- MAIN APPLICATION
addappid(717310)

-- MAIN APP DEPOTS / PACKAGES
addappid(717311, 1, "4c901e92ea1eabcf94edb988679b91a3c282244a01a9edcf5d040bdf652be619")

