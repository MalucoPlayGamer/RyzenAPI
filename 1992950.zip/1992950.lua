-- Lua provided by RyzenAPI 
-- Game: CUSTOM ORDER MAID 3D2 Guarded, Blunt Girl GP-02
addappid(1992950)
addappid(1992951, 1, "a7bbdd8c1288295bca57c34a5ef6997078fa2aee8ef6f8e9ad6052fcd808ef75")
addappid(1992952, 1, "d87bb92fdd338fac8069babe046fbe89188e6086b57f588a91d07fefdc1ac18e")
addappid(1992953, 1, "60e0876ccba4040783d03245191694794e7141d2f03958dc353f6426282a535a")
