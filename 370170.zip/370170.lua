-- Lua provided by RyzenAPI 
-- Game: AppID 370170
addappid(370170)
addappid(370171, 1, "292d604e3cde9f356bf53989998c814be715a03eca1e88713c4b3cfc5c9123db")
addappid(370172, 1, "971c5cbd5290fd9e2e8d686215ebfd680a788db650ebb6874ebd244e3849b961")
addappid(370173, 1, "62e348d44d0a0a253bf9779aa252e9e414fbef7c746902cc7be67b7cec1d6915")
