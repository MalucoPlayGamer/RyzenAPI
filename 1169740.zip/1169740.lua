-- Lua provided by RyzenAPI
-- Game: Danger Scavenger

-- MAIN APPLICATION
addappid(1169740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169741, 1, "98fe95448382458b341568872cce63d29cac0b501597d7941de7e3b0108581e8")
addappid(1169742, 1, "2657a3a5d8eb878c6c12a33949b99b486a0479a8671283294e42c47a44cf1f5e")
addappid(1169743, 1, "745fbfb638fa4ee3a139bf84090902057b1486461b0ccec076e9ab60defd91c4")
addappid(1877120, 0, "ea3cb8b14df82204ce0c4b7f2ae4a54de59f9f031eed2cbd4c3413b24d633d83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
