-- Lua provided by RyzenAPI
-- Game: addappid(2367150)

-- MAIN APPLICATION
addappid(2367150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367151, 1, "9de6d34e4b6e4e493df0ca82c803b82d883f881fe035928f31cb2d35b80625bd")
