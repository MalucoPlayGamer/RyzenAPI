-- Lua provided by RyzenAPI
-- Game: Oji-Mama/憧れのガチムチおじさんがボクだけのドスケベママになっちゃった❤

-- MAIN APPLICATION
addappid(2725330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725331, 1, "3be65ca621ab122918dcf8f88642c3ef93734a4149679f060875144ee7f1b7e1")

