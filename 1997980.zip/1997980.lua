-- Lua provided by RyzenAPI
-- Game: 出牌吧冒险家 Go Poker

-- MAIN APPLICATION
addappid(1997980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997981, 1, "1926b09617a5be73bfc9025d3345c0d4acebeafb935135d8a3c87e0b97ea7e5f")
