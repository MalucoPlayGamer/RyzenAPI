-- Lua provided by RyzenAPI
-- Game: addappid(1472950)

-- MAIN APPLICATION
addappid(1472950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472951, 1, "9a8e2bab45640a00e045aa196de0cff6577fe12d964874f03a1424f7ba178976")
