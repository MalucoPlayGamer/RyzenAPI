-- Lua provided by RyzenAPI
-- Game: Moldwasher

-- MAIN APPLICATION
addappid(3688130)
-- Game: addappid(3688130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688131, 1, "e8083b43ee34229c25038949a598ca2d52cd559d3005fecf605a8ae1b410293d")
