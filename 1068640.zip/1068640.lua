-- Lua provided by RyzenAPI
-- Game: addappid(1068640)

-- MAIN APPLICATION
addappid(1068640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068641, 1, "a8c12c79465744413c532a91ea1a3b60e5b5e528a71f5186abde6b9fcff726f4")
