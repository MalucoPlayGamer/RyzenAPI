-- Lua provided by RyzenAPI
-- Game: Game: Combat Champions Playtest

-- MAIN APPLICATION
addappid(2337480)
-- Game: addappid(2337480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337481, 1, "ab1319582cf2c8979f19fcae9726c5e2199c7152467400cd23167745fa881f82")
