-- Lua provided by SkyAPI 
-- Game: Forgotten Knight
addappid(2688610)
addappid(2688611, 1, "4f3e3df7acd135fd6b639e23e7c48028169d4652fa7432bdb353e1386dc4e975")
