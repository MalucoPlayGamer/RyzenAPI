-- Lua provided by RyzenAPI
-- Game: 2688610

-- MAIN APPLICATION
addappid(2688610)
-- Game: addappid(2688610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688611, 1, "4f3e3df7acd135fd6b639e23e7c48028169d4652fa7432bdb353e1386dc4e975")
