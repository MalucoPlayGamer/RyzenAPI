-- Lua provided by RyzenAPI
-- Game: 人类终结之日——2074

-- MAIN APPLICATION
addappid(3172420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172421, 1, "1d38acc70d51fa8ce7082d5aa9d7d04bd9aab394dce640602c51e5f99faa08bf")

