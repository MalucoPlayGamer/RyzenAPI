-- Lua provided by RyzenAPI
-- Game: Of Light and Darkness

-- MAIN APPLICATION
addappid(557760)

-- MAIN APP DEPOTS / PACKAGES
addappid(557761, 1, "ec7a4c3fda9167765b2e917238ca3c1339ca063d8b5b180117a0d0ee2be44c2e")

