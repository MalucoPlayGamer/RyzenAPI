-- Lua provided by RyzenAPI
-- Game: Burokku Girls

-- MAIN APPLICATION
addappid(443980)
-- Game: addappid(443980)

-- MAIN APP DEPOTS / PACKAGES
addappid(443981, 1, "9a48d9c868211b351f823546e032c237855ed85415eee7a33a246024d1228467")
