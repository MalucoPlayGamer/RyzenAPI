-- Lua provided by RyzenAPI
-- Game: Anime vs Evil: Apocalypse

-- MAIN APPLICATION
addappid(1992640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1992641, 1, "2e206f156d52565d9065ae1a8be4d682c34b93b360c5c4899591ef2b4b4aea5c")
addappid(1999010, 0, "d2049664cfb93fd26ac4c218ee86f5a6da66d9a3dab346252631515686e044f8")

