-- Lua provided by RyzenAPI
-- Game: Anime vs Evil: Apocalypse

-- MAIN APPLICATION
addappid(1992640)
-- Game: addappid(1992640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992641, 1, "2e206f156d52565d9065ae1a8be4d682c34b93b360c5c4899591ef2b4b4aea5c")
addappid(1999010, 0, "d2049664cfb93fd26ac4c218ee86f5a6da66d9a3dab346252631515686e044f8")
