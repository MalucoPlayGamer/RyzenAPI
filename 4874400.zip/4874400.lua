-- 4874400's Lua and Manifest Created by Hubcap Manifest
-- framepacer
-- Created: August 24, 2026 at 03:09:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4874400) -- framepacer
-- MAIN APP DEPOTS
addappid(4874401, 1, "7b9247573cd6c0017088e6ecca35f305b5185fbbe4d66e1622332e5f01905ed5") -- Depot 4874401
setManifestid(4874401, "2283517939810112765", 2803306)