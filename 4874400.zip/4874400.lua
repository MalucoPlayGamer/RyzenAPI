-- Lua provided by RyzenAPI
-- Game: framepacer

-- MAIN APPLICATION
addappid(4874400) -- framepacer

-- MAIN APP DEPOTS / PACKAGES
addappid(4874401, 1, "7b9247573cd6c0017088e6ecca35f305b5185fbbe4d66e1622332e5f01905ed5") -- Depot 4874401

