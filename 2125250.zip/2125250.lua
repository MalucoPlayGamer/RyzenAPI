-- Lua provided by RyzenAPI
-- Game: Space Runaway

-- MAIN APPLICATION
addappid(2125250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125251, 1, "a5058c48116c51835eda3c1c022a586b4c60690a98091d83ad02c68b0a973a60")
