-- Lua provided by RyzenAPI
-- Game: WindStop Strategy

-- MAIN APPLICATION
addappid(2646320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646321, 1, "788707cb8c67eb748233059f2da076e2b585eb95d64774c323e01295bcc8d968")
