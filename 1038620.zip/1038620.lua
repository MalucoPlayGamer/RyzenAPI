-- Lua provided by RyzenAPI
-- Game: House of 1000 Doors: Evil Inside

-- MAIN APPLICATION
addappid(1038620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038621, 1, "4588b7efacca1252df5ccc4cedf1bc1dec480ebe5a9fe5a79ab1fc7ca51cbc53")
