-- Lua provided by RyzenAPI
-- Game: Game: Galaxy of Pen & Paper +1

-- MAIN APPLICATION
addappid(349790)
addappid(689550)
-- Game: addappid(349790)

-- MAIN APP DEPOTS / PACKAGES
addappid(349791, 1, "f719b54823305de3a45e3113454acd94cd15aad93706942513f307745b972df1")
addappid(349792, 1, "906480039d06db5b23d3c142cf8facc38a03abd52882b9b617b72a3e1a834cd5")
addappid(349793, 1, "8935cb78e339e39036d8736c74203252e7ed340e8d15402917d591cc39fb6b2e")
