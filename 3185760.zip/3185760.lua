-- Lua provided by RyzenAPI
-- Game: Tinkerlands Demo

-- MAIN APPLICATION
addappid(3185760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185761, 1, "416fbd9328cb15ec74dc68e1739f5955c865994842bc0a7f971c0b3085fbbb8b")

