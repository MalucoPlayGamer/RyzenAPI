-- Lua provided by RyzenAPI 
-- Game: Simmiland
addappid(932850)
addappid(932851, 1, "bed960827d698c68caabe0474a4cc75e2bf339a0cd393c9ab3084465f0aaffef")
addappid(932852, 1, "223e8c28f523680ae85477574cc19caef034f71175acec00648f601735b24991")
