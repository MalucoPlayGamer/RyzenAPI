-- Lua provided by RyzenAPI
-- Game: Simmiland

-- MAIN APPLICATION
addappid(932850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(932851, 1, "bed960827d698c68caabe0474a4cc75e2bf339a0cd393c9ab3084465f0aaffef")
addappid(932852, 1, "223e8c28f523680ae85477574cc19caef034f71175acec00648f601735b24991")

