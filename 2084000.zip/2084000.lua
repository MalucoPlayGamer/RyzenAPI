-- Lua provided by RyzenAPI
-- Game: Shogun Showdown

-- MAIN APPLICATION
addappid(2084000)
-- Game: addappid(2084000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084001, 1, "e467a1dc28688a4ba159328e3419a2ddbbc265d7677b0eff56c56d25954271a9")
addappid(2084002, 1, "c1e765cd79523f2e2e0b9b808de03b6a05d66412826feef443a6dfb427f5e80b")
addappid(2084003, 1, "7cb9a4ecc6751d163d9efe97d790a2b4f66bcab785782e1dd0791ecb91592bae")
