-- Lua provided by RyzenAPI
-- Game: AppID 491350

-- MAIN APPLICATION
addappid(491350)

-- MAIN APP DEPOTS / PACKAGES
addappid(491351, 1, "44a5aefb15f4ff5940b331c2a4ccbeb7dfe34a627c5371f3e9e18a163cc72c00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
