-- Lua provided by RyzenAPI
-- Game: Game: Save Daddy Trump

-- MAIN APPLICATION
addappid(1084080)
-- Game: addappid(1084080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084081, 1, "4163a74f8d1bbce1ab81451c97ac7560772d9ad344f90f76733801854d2b4f82")
