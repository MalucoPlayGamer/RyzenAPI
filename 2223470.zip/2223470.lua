-- Lua provided by SkyAPI 
-- Game: Skeleton Runner
addappid(2223470)
addappid(2223471, 1, "facdefed71bc599d6a99de8b16eae8464d87dfe5b0c1640e4097ddfa4eff031b")
