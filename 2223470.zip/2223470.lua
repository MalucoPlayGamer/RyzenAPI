-- Lua provided by RyzenAPI
-- Game: Skeleton Runner

-- MAIN APPLICATION
addappid(2223470)
-- Game: addappid(2223470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223471, 1, "facdefed71bc599d6a99de8b16eae8464d87dfe5b0c1640e4097ddfa4eff031b")
