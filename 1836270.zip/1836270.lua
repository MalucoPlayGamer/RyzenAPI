-- Lua provided by RyzenAPI
-- Game: Dark Siren - The Captain's End

-- MAIN APPLICATION
addappid(1836270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836270,0,"93355bf810961a55151313857b5e636202fbea4f9cad0312a5b2539f02ecf45f")

