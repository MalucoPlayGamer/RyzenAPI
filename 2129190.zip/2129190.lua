-- Lua provided by RyzenAPI
-- Game: Plan B - Goddess's cards

-- MAIN APPLICATION
addappid(2129190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129191, 1, "e7f35f7b1949f2b8b9d02f7af6416b057e99b5bedb2a59a71b021c3e68515f5d")
