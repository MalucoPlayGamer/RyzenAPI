-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - “Frère Jacques”

-- MAIN APPLICATION
addappid(899895)

-- MAIN APP DEPOTS / PACKAGES
addappid(899895,0,"300529ff2f1eb900a0c3eb2de248137d7b42a900208942e12ba1a6b82c8304aa")

