-- Lua provided by SkyAPI 
-- Game: Trivia Vault: Golf Trivia
addappid(822900)
addappid(822901, 1, "ee8c8aa95ab3110c2abb1bb35bf1613a1885dfaa186fe9cbe65e9b84416f42fe")
