-- Lua provided by RyzenAPI
-- Game: 25850

-- MAIN APPLICATION
addappid(25850)
-- Game: addappid(25850)

-- MAIN APP DEPOTS / PACKAGES
addappid(25851, 1, "59c6c23bcc9e3403f4192456ec0408beeab1fd3ebc19745a079873aba44338df")
addappid(25852, 1, "b3915d4de1ac6b36070c01b2359fff39d182ca13019c1103e1d98ab366ce7338")
