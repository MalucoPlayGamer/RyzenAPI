-- Lua provided by RyzenAPI
-- Game: Elven Legacy

-- MAIN APPLICATION
addappid(25850)

-- MAIN APP DEPOTS / PACKAGES
addappid(25851, 1, "59c6c23bcc9e3403f4192456ec0408beeab1fd3ebc19745a079873aba44338df")
addappid(25852, 1, "b3915d4de1ac6b36070c01b2359fff39d182ca13019c1103e1d98ab366ce7338")
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

