-- Lua provided by RyzenAPI
-- Game: AQtion

-- MAIN APPLICATION
addappid(1978800)
-- Game: addappid(1978800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978801, 1, "dd9712d9032b41fdd83b74fe5da2b8eda292f49adc4389675dcc25dcce74bb55")
addappid(1978802, 1, "a8c343198d4045721db588025e30de15f68315f09c957e02fd728b18efbd30fe")
addappid(1978803, 1, "8218b23ec53afc8519a37f7e9fe35653e0b47a08b79aae07d82218df80fa90b9")
addappid(1978804, 1, "f5493e7193d6e8f3cc3d164dc86a9fa7791055397eeae58a1f13d9beb6f0564e")
