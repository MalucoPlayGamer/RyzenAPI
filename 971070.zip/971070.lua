-- Lua provided by RyzenAPI
-- Game: 971070

-- MAIN APPLICATION
addappid(971070)
-- Game: addappid(971070)

-- MAIN APP DEPOTS / PACKAGES
addappid(971071, 1, "f9363d0fc04e973eef76e830eef2a42f55ce552c9f1546d406bdfcb6f52c8d0b")
