-- Lua provided by RyzenAPI
-- Game: Whirlwind Magician

-- MAIN APPLICATION
addappid(2597180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597181, 1, "a0286399e98633769123ba532fc35b5654be06cb1a9af742ac5900a9cae6f77a")

