-- Lua provided by RyzenAPI
-- Game: Meridian 157: Chapter 2

-- MAIN APPLICATION
addappid(1458930)
-- Game: addappid(1458930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458931, 1, "4c2875b0c367d50e5b5485e69226cc18b14128b0055b9af7250bcbfd769fe73a")
