-- Lua provided by RyzenAPI
-- Game: KOMMERSANT

-- MAIN APPLICATION
addappid(778870)

-- MAIN APP DEPOTS / PACKAGES
addappid(778871,0,"2f2ad7516295b973f85977863c7c6254d2d9e6c7547344c1cfc7592d2b1fc8a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
