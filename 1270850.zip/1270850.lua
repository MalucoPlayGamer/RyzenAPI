-- Lua provided by RyzenAPI 
-- Game: Karma City Police
addappid(1270850)
addappid(1270851, 1, "f4eda88fbaf979ef05f83ea23eb749e083622b5df86d8403a91537af82d26cdf")
