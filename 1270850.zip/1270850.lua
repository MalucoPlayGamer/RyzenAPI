-- Lua provided by RyzenAPI
-- Game: Game: Karma City Police

-- MAIN APPLICATION
addappid(1270850)
-- Game: addappid(1270850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270851, 1, "f4eda88fbaf979ef05f83ea23eb749e083622b5df86d8403a91537af82d26cdf")
