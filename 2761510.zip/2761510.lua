-- Lua provided by RyzenAPI
-- Game: Handsome Me with 100 Girlfriends!

-- MAIN APPLICATION
addappid(2761510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761511, 1, "16d6a26d0dcbb97c1ff66bd132b37cdb531eb109b2caf4e4cefb37539dac44d6")
