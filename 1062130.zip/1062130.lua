-- Lua provided by RyzenAPI
-- Game: Game: Gun Skaters

-- MAIN APPLICATION
addappid(1062130)
-- Game: addappid(1062130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062131, 1, "f454a5e398694f2cac6bd166a3a0794e1f533789ea692c70a2232514fb268084")
