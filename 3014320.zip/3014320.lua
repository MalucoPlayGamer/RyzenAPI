-- Lua provided by RyzenAPI
-- Game: OCTOPATH TRAVELER 0

-- MAIN APPLICATION
addappid(3014320)
addappid(3576180)
addappid(3718180)
addappid(3825480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014321, 1, "376135a423323c017c43031fbf0c4048cf6ea9a6ca94311cd04879ad9a043491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
