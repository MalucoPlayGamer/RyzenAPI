-- Lua provided by RyzenAPI
-- Game: addappid(3014320)

-- MAIN APPLICATION
addappid(3014320)
addappid(3576180)
addappid(3718180)
addappid(3825480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014321, 1, "376135a423323c017c43031fbf0c4048cf6ea9a6ca94311cd04879ad9a043491")
