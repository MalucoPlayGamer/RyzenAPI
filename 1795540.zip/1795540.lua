-- Lua provided by RyzenAPI
-- Game: MudGate

-- MAIN APPLICATION
addappid(1795540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795541, 1, "6c9d6ba28df0135f6e5c7bcd867193114911a1799519af77b077a0e1c388dfed")

