-- Lua provided by RyzenAPI
-- Game: Game: Hentai I'm coming! - Patch 18+

-- MAIN APPLICATION
addappid(1281410)
-- Game: addappid(1281410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281411, 1, "62070051440a16838dfffc98b8e1e5598246015b011c26ed3eb2f4b96ea8990b")
