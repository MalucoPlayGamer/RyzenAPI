-- Lua provided by RyzenAPI
-- Game: Grim Tales: The Bride Collector's Edition

-- MAIN APPLICATION
addappid(527900)

-- MAIN APP DEPOTS / PACKAGES
addappid(527901, 1, "7883a8af701770e9ed12e93a360c0efb403ba387be44cbde74f6cd530c5e1af5")

