-- Lua provided by RyzenAPI
-- Game: Your Blight

-- MAIN APPLICATION
addappid(1600500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600501,0,"f18958b1be3e1b5b50b9e512276d9f1274a4eef15d7a4628bf865c26daf94b31")

