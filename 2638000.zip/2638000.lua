-- Lua provided by RyzenAPI
-- Game: addappid(2638000)

-- MAIN APPLICATION
addappid(2638000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638000,0,"e66fa3cccc8031b2c65c88a15bafc9360caff2bbcacddea90f39735041177581")
