-- Lua provided by RyzenAPI
-- Game: AppID 3171670

-- MAIN APPLICATION
addappid(3171670)
-- Game: addappid(3171670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171671, 1, "e3177ef3339c10865c958a1d6e15f785c93b0b0d49f4ed3bac36b7bbb8f67212")
