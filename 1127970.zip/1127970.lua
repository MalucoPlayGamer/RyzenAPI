-- Lua provided by RyzenAPI 
-- Game: AppID 1127970
addappid(1127970)
addappid(1127971, 1, "8a9f5b07508554ffc97dc2eef61c0af1b518d696c6acd4cef372a7f827273fea")
