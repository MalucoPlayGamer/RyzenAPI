-- Lua provided by RyzenAPI
-- Game: Game: Cadoom

-- MAIN APPLICATION
addappid(3010760)
-- Game: addappid(3010760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010761, 1, "9ea4def8f55d6c3aa7aa75b8e78b88dcb71dc126c87d5d8bfb761f961dbe6116")
