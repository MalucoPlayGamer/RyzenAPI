-- Lua provided by SkyAPI 
-- Game: Cadoom
addappid(3010760)
addappid(3010761, 1, "9ea4def8f55d6c3aa7aa75b8e78b88dcb71dc126c87d5d8bfb761f961dbe6116")
