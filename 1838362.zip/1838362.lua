-- Lua provided by RyzenAPI
-- Game: ダウンロード特典

-- MAIN APPLICATION
addappid(1838362)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838362,0,"e84c36b8aab92eb311b1064c61f14a419fcab05348d1ba79c5221b230c144893")

