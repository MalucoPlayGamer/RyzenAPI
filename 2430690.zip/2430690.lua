-- Lua provided by RyzenAPI 
-- Game: Clover Day's Plus
addappid(2430690)
addappid(2430691, 1, "8b2540b4208868f8d243b13cd346addb345d8a9ed7fef271884389f0547b37db")
