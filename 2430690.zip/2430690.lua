-- Lua provided by RyzenAPI
-- Game: Clover Day's Plus

-- MAIN APPLICATION
addappid(2430690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2430691, 1, "8b2540b4208868f8d243b13cd346addb345d8a9ed7fef271884389f0547b37db")

