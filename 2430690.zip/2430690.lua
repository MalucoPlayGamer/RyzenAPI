-- Lua provided by RyzenAPI
-- Game: 2430690

-- MAIN APPLICATION
addappid(2430690)
-- Game: addappid(2430690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430691, 1, "8b2540b4208868f8d243b13cd346addb345d8a9ed7fef271884389f0547b37db")
