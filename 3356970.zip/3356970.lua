-- Lua provided by RyzenAPI
-- Game: Nightfall Secrets

-- MAIN APPLICATION
addappid(3356970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356971, 1, "3c02b7952d601a94922b91f04cec7c49bf768fb893d9801169ea07771fa8f796")
