-- Lua provided by RyzenAPI
-- Game: Ghost Master®

-- MAIN APPLICATION
addappid(6200)

-- MAIN APP DEPOTS / PACKAGES
addappid(6201, 1, "bb6accd4b2d72525e4f0e7a06aa74280230b3fb01eab0d956f602ecb69cd9c38")
addappid(6202, 1, "aeb1a4daab62e6b7a1ad20f0b9148ecafeae62ac2bab2e313cfe34bd3e18762e")
addappid(6203, 1, "ba1b4bb42477ed6aeec0f74d8f019008967f8eee7e73f4da0008b6ce04e58a80")
addappid(6204, 1, "7a2789b8df17298db22c23f69889c58590a67620abe0d646d5b29cdc0ee4f6ab")
addappid(6205, 1, "55d0e9c2395504df2a1b57c6571221e5e6f5086b0b82a0e59ead18e7ab250a18")

