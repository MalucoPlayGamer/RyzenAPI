-- Lua provided by RyzenAPI
-- Game: addappid(1508170)

-- MAIN APPLICATION
addappid(1508170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508171, 1, "7f660fb6ca9cc3ea7862ea12ff78b7e3f8ac9eb7ed4bd8bccc00994988d7c1b9")
