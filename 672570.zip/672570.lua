-- Lua provided by RyzenAPI
-- Game: The Western Hunter

-- MAIN APPLICATION
addappid(672570)

-- MAIN APP DEPOTS / PACKAGES
addappid(672571,0,"049ab2c04c2c8e24f5cef6a28eb912323c754eef31bb22bf211fbd9790966ebe")

