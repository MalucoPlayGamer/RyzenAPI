-- Lua provided by RyzenAPI
-- Game: Glass Wings Demo

-- MAIN APPLICATION
addappid(2342840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342841, 1, "0d1e45e60536b175907febba615bc7985e2c0215e07ece4a07a7be6a7e9b600c")
