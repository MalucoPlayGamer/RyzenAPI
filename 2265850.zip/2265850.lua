-- Lua provided by RyzenAPI
-- Game: Game: 觅长生 原声带

-- MAIN APPLICATION
addappid(2265850)
-- Game: addappid(2265850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265851, 1, "263e1ca29eb134b77ea9400b83cd563cfff27f55bf7430922bcc23ee0d751867")
