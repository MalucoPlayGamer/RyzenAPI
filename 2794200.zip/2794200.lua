-- Lua provided by RyzenAPI
-- Game: addappid(2794200)

-- MAIN APPLICATION
addappid(2794200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794201, 1, "232855797103c4aebfd00108cf24371b28af2604b9b5dc908ecc41cea7fc7e77")
