-- Lua provided by RyzenAPI
-- Game: 41660

-- MAIN APPLICATION
addappid(41660)
-- Game: addappid(41660)

-- MAIN APP DEPOTS / PACKAGES
addappid(41661, 1, "92371f8a6ff8897712c7d4aa3590b0f853ec99818e085a9434ea6e1181c804a8")
