-- Lua provided by RyzenAPI
-- Game: Angry Cubes

-- MAIN APPLICATION
addappid(2299280)
addappid(2432210)
-- Game: addappid(2299280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299281, 1, "0111727795323bcd85ef89dcdebd25e6f77312a00b5ea5902c7ffae8dc3b38dd")
