-- Lua provided by RyzenAPI
-- Game: Femdom Game World: Stepmother

-- MAIN APPLICATION
addappid(2867360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867361, 1, "94f387a2b6b2b5cadf867c6ddba2dc5a40219b0ebd703117e9f559b6080c9865")

