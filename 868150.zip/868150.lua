-- Lua provided by RyzenAPI
-- Game: Game: Takelings House Party

-- MAIN APPLICATION
addappid(868150)
-- Game: addappid(868150)

-- MAIN APP DEPOTS / PACKAGES
addappid(868151, 1, "18885cd77c8888cc10a3a749c2e9f60e1a7c71d546844da66a4885c97cc5d4f9")
