-- Lua provided by RyzenAPI
-- Game: PiraCrash!

-- MAIN APPLICATION
addappid(1220200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1220201, 1, "7d4f7452ee586e0ab23371a6569ce938e4a6a284702376187ece3b4080ef150b")
