-- Lua provided by RyzenAPI
-- Game: Game: AppID 1220200

-- MAIN APPLICATION
addappid(1220200)
-- Game: addappid(1220200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220201, 1, "7d4f7452ee586e0ab23371a6569ce938e4a6a284702376187ece3b4080ef150b")
