-- Lua provided by RyzenAPI
-- Game: Game: Expeditions: Rome Demo

-- MAIN APPLICATION
addappid(1815770)
-- Game: addappid(1815770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815771, 1, "965e781ebb0c24ec38096da597046d2c2658ddc5bf7baeedd9e93cfcdfcde5f7")
