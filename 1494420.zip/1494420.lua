-- Lua provided by RyzenAPI
-- Game: Silica

-- MAIN APPLICATION
addappid(1494420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1494421, 1, "235884e86240f9c2ed0e91f1a9f3f909896e04df14f6fdc82f5e7b5139f2e347")

