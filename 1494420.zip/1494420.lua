-- Lua provided by RyzenAPI
-- Game: Silica

-- MAIN APPLICATION
addappid(1494420)
-- Game: addappid(1494420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494421, 1, "235884e86240f9c2ed0e91f1a9f3f909896e04df14f6fdc82f5e7b5139f2e347")
