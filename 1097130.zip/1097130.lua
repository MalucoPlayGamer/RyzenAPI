-- Lua provided by RyzenAPI
-- Game: Circuit Superstars

-- MAIN APPLICATION
addappid(1097130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097131, 1, "57e21c526c488ab7641b70ab47dfe2babb40083d6f39e6871b4dee4cc7d67565")
