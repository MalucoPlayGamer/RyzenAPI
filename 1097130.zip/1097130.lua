-- Lua provided by RyzenAPI
-- Game: Circuit Superstars

-- MAIN APPLICATION
addappid(1097130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097131, 1, "57e21c526c488ab7641b70ab47dfe2babb40083d6f39e6871b4dee4cc7d67565")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1718780)
addappid(2186050)
