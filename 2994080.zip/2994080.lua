-- Lua provided by RyzenAPI
-- Game: 2994080

-- MAIN APPLICATION
addappid(2994080)
-- Game: addappid(2994080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994081, 1, "c36112422bd0e179bece97b951aaf754c736a3e51dd86cc54dccbf2c2efdf66b")
