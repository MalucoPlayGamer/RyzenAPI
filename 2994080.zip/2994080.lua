-- Lua provided by RyzenAPI
-- Game: The Cake

-- MAIN APPLICATION
addappid(2994080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994081, 1, "c36112422bd0e179bece97b951aaf754c736a3e51dd86cc54dccbf2c2efdf66b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
