-- Lua provided by RyzenAPI
-- Game: Wanna Run Again - Sprite Girl

-- MAIN APPLICATION
addappid(721850)
addappid(1071420)

-- MAIN APP DEPOTS / PACKAGES
addappid(721851, 1, "e0fe0c583d603dd75e3e28e37f9893d2e7b50d0fcaf955155e6b2336ce37be31")
