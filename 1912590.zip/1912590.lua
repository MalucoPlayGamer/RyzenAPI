-- Lua provided by RyzenAPI
-- Game: addappid(1912590)

-- MAIN APPLICATION
addappid(1912590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912591, 1, "771510fdd4b94b25cec794a120eb8ae2ee0e0bdd75fd8b560c9116f4e9ec919b")
