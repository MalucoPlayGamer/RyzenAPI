-- Lua provided by RyzenAPI
-- Game: Game: AppID 1054800

-- MAIN APPLICATION
addappid(1054800)
-- Game: addappid(1054800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054801, 1, "b61c27c4367ffb80382568619b93b49db51671481e23af67d538f0f8e55eb752")
