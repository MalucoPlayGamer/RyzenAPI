-- Lua provided by RyzenAPI
-- Game: 变量 - Variables

-- MAIN APPLICATION
addappid(1054800)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1054801, 1, "b61c27c4367ffb80382568619b93b49db51671481e23af67d538f0f8e55eb752")

