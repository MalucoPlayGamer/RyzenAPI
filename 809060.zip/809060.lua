-- Lua provided by RyzenAPI
-- Game: AppID 809060

-- MAIN APPLICATION
addappid(809060)

-- MAIN APP DEPOTS / PACKAGES
addappid(809061, 1, "90a2829b369044d5aff87613cd15d62b13651aff950e7d569137d2280d8e22f0")
addappid(809062, 1, "605a2b06f59876dd33fd26299b7f6cb646e02616f14f6f0eb1149da9c96511df")
addappid(809063, 1, "e3bb243db4479abfde91a00507c776c4325fc439593765ffa1324ea33616f2e1")
addappid(2418300, 0, "b8e747ccd9cf6f7b4f5b5f4998be8b6d647e648ac068dde37c8a65598eb0133b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
