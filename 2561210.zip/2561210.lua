-- Lua provided by RyzenAPI
-- Game: Carball 360 (beta)

-- MAIN APPLICATION
addappid(2561210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561211, 1, "4f10b00a6a75af97612408af91a0d845915df813e56971820deaa505f00a3e95")
