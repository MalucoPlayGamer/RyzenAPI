-- Lua provided by RyzenAPI
-- Game: AppID 2928650

-- MAIN APPLICATION
addappid(2928650)
-- Game: addappid(2928650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928651, 1, "68b6397e2638a982c6e29d10ced1cf877a1fe7028c523363b2e551dab0d8df81")
