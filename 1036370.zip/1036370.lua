-- Lua provided by RyzenAPI
-- Game: addappid(1036370)

-- MAIN APPLICATION
addappid(1036370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036371, 1, "bff80371a875ed3db2507a62f4a22e2828f9cdbd7be11489f857fcb770aee8f0")
