-- Lua provided by RyzenAPI
-- Game: Red Stone Online

-- MAIN APPLICATION
addappid(350700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(350701, 1, "9e8844b50ea78e55802f8461d5384a7b085c0963387fe59a56207eef58244405")
