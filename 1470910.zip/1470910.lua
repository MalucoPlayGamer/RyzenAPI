-- Lua provided by RyzenAPI
-- Game: addappid(1470910)

-- MAIN APPLICATION
addappid(1470910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470911, 1, "15fccb54d3217798d6b66432774ed8ac84d8598ddf5095d4e9534a3b7c2b3606")
