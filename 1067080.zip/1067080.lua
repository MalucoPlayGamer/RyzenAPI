-- Lua provided by RyzenAPI
-- Game: 1067080

-- MAIN APPLICATION
addappid(1067080)
-- Game: addappid(1067080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067081, 1, "4a0e9ab91968ba753750a500b75a664b55c9a8e664760cfac0fbd3b9020d8a62")
