-- Lua provided by RyzenAPI
-- Game: addappid(3182980)

-- MAIN APPLICATION
addappid(3182980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182982,0,"2640950f7fe51b002c3a9a3c500e7e59329f477942487e1ac7fb8efe07a96e0e")
