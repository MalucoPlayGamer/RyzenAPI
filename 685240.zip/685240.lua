-- Lua provided by RyzenAPI 
-- Game: Paradiddle
addappid(685240)
addappid(685241, 1, "c3a99ace87b059d65d360ffde064901d2b11fc1bb33958799fc9e64dee494f3a")
addappid(2854960)
addappid(3134110)
addappid(3373930)
