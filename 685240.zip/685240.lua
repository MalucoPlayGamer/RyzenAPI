-- Lua provided by RyzenAPI
-- Game: Paradiddle

-- MAIN APPLICATION
addappid(685240)
addappid(2854960)
addappid(3134110)
addappid(3373930)

-- MAIN APP DEPOTS / PACKAGES
addappid(685241, 1, "c3a99ace87b059d65d360ffde064901d2b11fc1bb33958799fc9e64dee494f3a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
