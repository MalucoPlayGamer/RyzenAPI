-- Lua provided by RyzenAPI
-- Game: Game: TSOTF

-- MAIN APPLICATION
addappid(822770)
-- Game: addappid(822770)

-- MAIN APP DEPOTS / PACKAGES
addappid(822771, 1, "c2770ab1f0cf285a6464526a6a2bd07ebeab7d168e7d3f1da40197bbe3cf3269")
