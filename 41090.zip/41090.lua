-- Lua provided by RyzenAPI
-- Game: Serious Sam 3 Editor

-- MAIN APPLICATION
addappid(41090)

-- MAIN APP DEPOTS / PACKAGES
addappid(41091, 1, "2fa9094921b23371b2c6acc6e139d68f296b9965064d06cc129d4ca70a6b7b3d")
addappid(41092, 1, "78bc0c29c5cfcaa192494da65a29d006d86cd1032c0229105afe6b6f8a1166cd")
addappid(41095, 1, "ff8c0c4a3127b8e3c85da81614020dbcec31267cc8811fd5bf8f5cf901ccd366")
addappid(41096, 1, "decbfaa8592cb2b59dc71c2fe7e782ded7fbdf1eca92b91edd3e4e48e53f5815")
