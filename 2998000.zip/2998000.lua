-- Lua provided by RyzenAPI
-- Game: Tactical Breach Wizards Demo

-- MAIN APPLICATION
addappid(2998000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998001, 1, "c9d29fa8d0b4bfac1587c779d8b2ab147aca11fae0dec73cd44ade098b0c73fa")
