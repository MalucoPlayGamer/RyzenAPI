-- Lua provided by RyzenAPI
-- Game: AppID 3060520

-- MAIN APPLICATION
addappid(3060520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060521, 1, "3e11db1edb76bd8d9d0d83c6b5b3c2d13d09d8b4238a4d842475a9efcae4683b")

