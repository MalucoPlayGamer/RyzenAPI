-- Lua provided by RyzenAPI
-- Game: Pavel Repin's Collection

-- MAIN APPLICATION
addappid(1599130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599131, 1, "081c682248746a343a8aaa89f0fb1ec0262f15cdb7e08d5bcb613a6f8400915c")
