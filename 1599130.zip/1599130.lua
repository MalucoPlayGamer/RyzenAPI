-- Lua provided by RyzenAPI
-- Game: Pavel Repin's Collection

-- MAIN APPLICATION
addappid(1599130)
addappid(2211030)
addappid(2219260)
addappid(2882730)
addappid(3360830)
addappid(3427930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599131, 1, "081c682248746a343a8aaa89f0fb1ec0262f15cdb7e08d5bcb613a6f8400915c")

