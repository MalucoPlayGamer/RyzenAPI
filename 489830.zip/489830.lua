-- Lua provided by RyzenAPI
-- Game: The Elder Scrolls V: Skyrim Special Edition

-- MAIN APPLICATION
addappid(489830)
addappid(598120)
addappid(1746860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(489831, 1, "a26da9ff1f2af2345ebfad1bd62bcb9ed1cbe6afcf4ced92d1a5fa944242b825")
addappid(489832, 1, "c6c5e29627073060ccf9fc8c6c9c7ec86dfdf16b51b3d1fbb0a2e7c1ad9f533e")
addappid(489833, 1, "7c5e75890b4f59b4be2d3b68c88abad8b23b159a23bf25a00c5c3a4748752f36")
addappid(489834, 1, "eeb89a10bdac7b9b83b6d03cffd9c6225d9041a8130ea52ff0f96b7f6174e857")
addappid(489835, 1, "ed764444d4ab7b8d2f98100ddd951659a57f5df3c8825b2d14df99f8ab1b6447")
addappid(489836, 1, "1ebc81b82a20b369c9c0335ed96a206b81b46846f2dc9a9f457e748d1ec48045")
addappid(489837, 1, "b2cf2cc8cadda88f33e707b79fb2b95b458553a6d768f7d1ab9ef657a18fa90c")
addappid(489838, 1, "807c9db0782a0d03abbe9f123179b7428bb952dcb3c127abcb0455d65d772cdd")
addappid(489839, 1, "19028a477ba63d9a671eed7c6590e607370062aa3bf59446cc8b79022ab64de4")
addappid(544860, 0, "b0cdbf6da886a9083687985cffde7be07f2183afe615b10af508ff8ded2f8408")
addappid(544861, 0, "586061c4ba80f7bf1fcf1da170aeffeacdc20869d4d5d622e69c935f42c26630")

