-- Lua provided by RyzenAPI
-- Game: addappid(3037490)

-- MAIN APPLICATION
addappid(3037490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037491, 1, "b2d96ab3601895c76b62d72405acb1b5e8112006aff8cfc14c736bec7f3051b1")
