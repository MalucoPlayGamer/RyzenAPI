-- Lua provided by RyzenAPI
-- Game: Game: Spirits of Mystery: Amber Maiden Collector's Edition

-- MAIN APPLICATION
addappid(514760)
-- Game: addappid(514760)

-- MAIN APP DEPOTS / PACKAGES
addappid(514761, 1, "8bb869bc605243bacb7144c0c1583a692c9100f07acb0b1cca543d16978aac05")
