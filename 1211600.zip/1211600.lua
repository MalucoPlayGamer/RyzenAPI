-- Lua provided by RyzenAPI
-- Game: 1211600

-- MAIN APPLICATION
addappid(1211600)
-- Game: addappid(1211600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211602,0,"0378532b7715d88cc41c1a7f96a42d2ac9ab565ff5818653cdbbfe54548f87db")
