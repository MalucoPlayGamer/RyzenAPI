-- Lua provided by RyzenAPI
-- Game: addappid(1144110)

-- MAIN APPLICATION
addappid(1144110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144111, 1, "30cd0da8f69c01abd637a83ba85d285a0521696c10c942e653a399fd275903c8")
