-- Lua provided by RyzenAPI
-- Game: AppID 882110

-- MAIN APPLICATION
addappid(882110)

-- MAIN APP DEPOTS / PACKAGES
addappid(882111, 1, "86aa8789be9b26d1517a096ab268512affec24e358f4ed7e26801f5745e7ea04")
addappid(882112, 1, "8511db591e7eda5f04b7c7bf2911cdb723d0e40dbe6b751a82aa798281dcfec5")

