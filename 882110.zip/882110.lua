-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Age of Sail

-- MAIN APPLICATION
addappid(882110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(882111, 1, "86aa8789be9b26d1517a096ab268512affec24e358f4ed7e26801f5745e7ea04")
addappid(882112, 1, "8511db591e7eda5f04b7c7bf2911cdb723d0e40dbe6b751a82aa798281dcfec5")

