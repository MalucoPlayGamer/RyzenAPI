-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Mechanicus

-- MAIN APPLICATION
addappid(673880)
addappid(1049290)

-- MAIN APP DEPOTS / PACKAGES
addappid(673881, 1, "89aa31906085f80bb20d0b8a7d7602c459e28a8c8ece4e7e35807bc1fbcce0c6")
addappid(673882, 1, "8a5bc773a4bc2c41903a62167095b0a2fa58a1decbab21fd9b4cb454a8a643c1")
addappid(673883, 1, "36b62d7360247e887804c18a311c3808a02ce98cb1383ba935d5fef598f5ff38")
addappid(673884, 1, "7c43b876a4e6e6b313ed07e8d934aafdeddd2b8d6f7282260bffa017a0c26895")
addappid(916250, 0, "c7f31588fd8cbdb0eeed1c684e2144817a03e391d91848d4c1c1da5f85c8baca")
addappid(1104970, 0, "2ddf38791f7b66a2f00994369228e6dc42682e4f5f87c68e7b3e954b015b00d8")

