-- Lua provided by SkyAPI 
-- Game: AppID 438490
addappid(438490)
addappid(438491, 1, "dd74de5cb0ceeb914d1d50f0e15509f435541778d0b1a61227bac1832f196db5")
