-- Lua provided by RyzenAPI
-- Game: All-Star Fielding Challenge VR

-- MAIN APPLICATION
addappid(597020)

-- MAIN APP DEPOTS / PACKAGES
addappid(597021,0,"fa1dc6f9152b87690a7964e1aaf781cb8a60087d1c320218988d2146c05d5429")

