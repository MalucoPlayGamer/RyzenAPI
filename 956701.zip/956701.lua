-- Lua provided by RyzenAPI
-- Game: 956701

-- MAIN APPLICATION
addappid(956701)

-- MAIN APP DEPOTS / PACKAGES
addappid(956701,0,"7a4db1b2a41daca4733b80091831a6b4a173e518a52cc7b5eaac3bc6f70869d7")

