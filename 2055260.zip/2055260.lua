-- Lua provided by RyzenAPI
-- Game: Dance Dash Demo

-- MAIN APPLICATION
addappid(2055260)
-- Game: addappid(2055260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055261, 1, "63c533b1e42288877c7ee8d65c7585e5c09192647b35db18299066a904a30da8")
