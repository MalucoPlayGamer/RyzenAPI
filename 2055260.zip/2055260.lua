-- Lua provided by RyzenAPI 
-- Game: AppID 2055260
addappid(2055260)
addappid(2055261, 1, "63c533b1e42288877c7ee8d65c7585e5c09192647b35db18299066a904a30da8")
