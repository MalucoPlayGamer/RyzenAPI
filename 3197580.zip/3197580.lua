-- Lua provided by RyzenAPI
-- Game: Survivor Girls of Monster Dungeon Demo

-- MAIN APPLICATION
addappid(3197580)
-- Game: addappid(3197580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197581, 1, "638ec429a8563bf030a87879f8fc02a86cce6aa8414c1764135c821d5decf29d")
