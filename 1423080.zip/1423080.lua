-- Lua provided by RyzenAPI
-- Game: 异世界无厘头生活2

-- MAIN APPLICATION
addappid(1423080)
-- Game: addappid(1423080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423081, 1, "660028547e257a0f5b3c5d86ce5fbe8d7d36761e1562ed083750db34b1aa5b66")
addappid(1968560, 0, "0199c9614ef5192bf2a1708625f21a6538031e1af7c1913ac17cc2dab54e245d")
