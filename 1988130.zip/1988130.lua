-- Lua provided by RyzenAPI
-- Game: Chirality

-- MAIN APPLICATION
addappid(1988130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988131, 1, "7758656785095c142cfe8074f52f761d1f0c07e63e4be76d8f4c3b29a84261ea")
