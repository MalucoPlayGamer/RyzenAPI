-- Lua provided by RyzenAPI
-- Game: 夜詛YASO curse of soirée

-- MAIN APPLICATION
addappid(1715550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715551, 1, "511ec593b5610bdc14521f972c191f9bd212679524ff6c10e5378e4f62091a36")
