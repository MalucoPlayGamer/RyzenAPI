-- Lua provided by RyzenAPI
-- Game: Game: AppID 1339880

-- MAIN APPLICATION
addappid(1339880)
-- Game: addappid(1339880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339881, 1, "5d0cb54120649223a9a03e01e27821ba91b594b82ee056468df737eeac0ad8cf")
