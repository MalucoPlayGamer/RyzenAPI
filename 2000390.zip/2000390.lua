-- Lua provided by RyzenAPI
-- Game: Game: Spells & Secrets Demo

-- MAIN APPLICATION
addappid(2000390)
-- Game: addappid(2000390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000391, 1, "fc62449d0f58dd354e89c04e1eb1b7a4cda1cf1643087833a8b179b89dca925c")
