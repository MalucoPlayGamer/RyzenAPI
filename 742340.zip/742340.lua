-- Lua provided by RyzenAPI
-- Game: AppID 742340

-- MAIN APPLICATION
addappid(742340)
-- Game: addappid(742340)

-- MAIN APP DEPOTS / PACKAGES
addappid(742341, 1, "e9c1f446ae42a0b3148a3cc6b4d68bfb017534de4273c3d619b3900b8996a4a2")
