-- Lua provided by RyzenAPI
-- Game: Ballooni - balloon homunculus

-- MAIN APPLICATION
addappid(2310620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310621, 1, "4c9e1ba724318ef7d1146b5660a659825a6fc1445375092db5b7070ed957dd98")

