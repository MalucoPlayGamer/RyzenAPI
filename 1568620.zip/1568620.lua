-- Lua provided by RyzenAPI
-- Game: Game: MetaPhysical

-- MAIN APPLICATION
addappid(1568620)
-- Game: addappid(1568620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568621, 1, "611f1242c9c8559fc08e0961e887417ab109de4239e899f1d6924a2ee01cd380")
