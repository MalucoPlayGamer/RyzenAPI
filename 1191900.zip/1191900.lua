-- Lua provided by RyzenAPI
-- Game: Say No! More

-- MAIN APPLICATION
addappid(1191900)
-- Game: addappid(1191900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191901, 1, "d304fe53435778f12f706d7aa0eddc2bf04568f2c088466a180a859b769e9f6e")
