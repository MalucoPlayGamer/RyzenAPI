-- Lua provided by RyzenAPI
-- Game: Loneliness

-- MAIN APPLICATION
addappid(1524790)
-- Game: addappid(1524790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524791, 1, "ccf6a8240307fa26b5f53be6f39c2e38a55c8ab70bdcd318d2592dc0bbef8b6e")
