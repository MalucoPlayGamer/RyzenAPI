-- Lua provided by RyzenAPI
-- Game: AppID 628090

-- MAIN APPLICATION
addappid(628090)

-- MAIN APP DEPOTS / PACKAGES
addappid(628091, 1, "922a771e5d4c13a77b085782bdbe5a05093e407d5ba4e6437b9ed65ba3424ced")

