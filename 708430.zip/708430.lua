-- Lua provided by SkyAPI 
-- Game: Kamikaze Cube
addappid(708430)
addappid(708431, 1, "2df8b1fec7ce6b9edbccab8b84b1f6a1544029378bffb18648995fa920827d84")
