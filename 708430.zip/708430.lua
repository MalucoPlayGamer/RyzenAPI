-- Lua provided by RyzenAPI
-- Game: addappid(708430)

-- MAIN APPLICATION
addappid(708430)

-- MAIN APP DEPOTS / PACKAGES
addappid(708431, 1, "2df8b1fec7ce6b9edbccab8b84b1f6a1544029378bffb18648995fa920827d84")
