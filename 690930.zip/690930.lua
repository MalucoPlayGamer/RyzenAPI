-- Lua provided by RyzenAPI
-- Game: Evening Surprise

-- MAIN APPLICATION
addappid(690930)
addappid(703170)

