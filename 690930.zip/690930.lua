-- Lua provided by RyzenAPI
-- Game: Evening Surprise

-- MAIN APPLICATION
addappid(690930)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(703170)
