-- Lua provided by SkyAPI 
-- Game: AppID 311340
addappid(311340)
addappid(311341, 1, "e88d146d5d2a23261b9315001e2ab7344adac66e00194985e1f00b847e2e9dbc")
addappid(311343, 1, "5498c3c90715a35f8e208cd6b380a16901cae634d9c22cb0f8a1cfed3f70b9cf")
