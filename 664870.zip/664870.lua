-- Lua provided by RyzenAPI
-- Game: Forgotten Faces

-- MAIN APPLICATION
addappid(664870)
-- Game: addappid(664870)

-- MAIN APP DEPOTS / PACKAGES
addappid(664871, 1, "68c309aa7a24f2f06d6649e9cee5645a5d1bf6f60cc6cba908a5163a6ded1582")
addappid(664872, 1, "ebb2d290445e21aa87841ff9987902afbda25950d2f2b89f9d738ff4dab0ee22")
