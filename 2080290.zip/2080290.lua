-- Lua provided by RyzenAPI
-- Game: 69 Ember Hot

-- MAIN APPLICATION
addappid(2080290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080291, 1, "0a5fcb8f6847af1f510d2491604fffacdde2f1b74fc6ff366d8d3e4e52b8f3cd")

