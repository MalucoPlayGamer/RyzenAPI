-- Lua provided by RyzenAPI
-- Game: Game: AppID 1517970

-- MAIN APPLICATION
addappid(1517970)
-- Game: addappid(1517970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517971, 1, "218b81743a1a245ae88694e01fefe4d2c67815a96cec4b37a6589937b267926a")
