-- Lua provided by RyzenAPI
-- Game: Aeterna Noctis

-- MAIN APPLICATION
addappid(1517970)
addappid(1818300)
addappid(1818310)
addappid(2283080)
addappid(2589720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517971, 1, "218b81743a1a245ae88694e01fefe4d2c67815a96cec4b37a6589937b267926a")

