-- Lua provided by RyzenAPI 
-- Game: STONEBOND: The Gargoyle's Domain
addappid(524240)
addappid(524241, 1, "8a0abc91160ab16b74345e73acc2b246d4864758d1e19a52d6bd27e5e3fe5275")
addappid(524242, 1, "5c0e4f69d61ff65211bfd9d449a5dba9fc227036cff025dd29be6a2a7cf5dc68")
