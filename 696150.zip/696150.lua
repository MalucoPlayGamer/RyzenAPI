-- Lua provided by RyzenAPI
-- Game: Game: AppID 696150

-- MAIN APPLICATION
addappid(696150)
-- Game: addappid(696150)

-- MAIN APP DEPOTS / PACKAGES
addappid(696151, 1, "ba1b29fe9e952f640c5557624d677233650ea7a0798c9bec640f8742dd40fc48")
