-- Lua provided by RyzenAPI
-- Game: Murder Mystery Paradox: Fifteen Years of Summer DEMO

-- MAIN APPLICATION
addappid(2482410)
-- Game: addappid(2482410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482411, 1, "99d833ffce490ab0c172204f0090f627edd3cc7d4086d92bb3e7df2647a37087")
