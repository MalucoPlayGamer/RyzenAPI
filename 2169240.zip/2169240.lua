-- Lua provided by RyzenAPI
-- Game: EarthRoyale Demo

-- MAIN APPLICATION
addappid(2169240)
-- Game: addappid(2169240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169241, 1, "ee48c2e142c4e43c23f303e0f4628aa93473091b1220110924da539f211ac866")
