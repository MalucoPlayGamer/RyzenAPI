-- Lua provided by RyzenAPI
-- Game: 1634699

-- MAIN APPLICATION
addappid(1634699)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634699,0,"b227b4c217c66bdf8791ea32aca6d8caea6e88dfd92f58f15db157960cc74bdc")

