-- Lua provided by RyzenAPI
-- Game: Savara

-- MAIN APPLICATION
addappid(3021630)
addappid(3711830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3021631, 1, "f0d381b395acf5a0fdf2c63241b06314a31baf17d5566e687c1071e583d8110f")
addappid(3711831, 0, "ad709f218d5bc8b43a7c6d563ff2de77ec84efa2f7df61eb25ffdcb6d976a4ba")

