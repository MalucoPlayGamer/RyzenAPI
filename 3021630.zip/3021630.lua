-- Lua provided by RyzenAPI 
-- Game: Savara
addappid(3021630)
addappid(3021631, 1, "f0d381b395acf5a0fdf2c63241b06314a31baf17d5566e687c1071e583d8110f")
addappid(3711831, 0, "ad709f218d5bc8b43a7c6d563ff2de77ec84efa2f7df61eb25ffdcb6d976a4ba")
