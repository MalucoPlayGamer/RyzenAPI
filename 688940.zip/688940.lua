-- Lua provided by RyzenAPI
-- Game: Steve's Pub - Soda on tap

-- MAIN APPLICATION
addappid(688940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(688941, 1, "7950702306ecf5b72107ce9fd69ac41bc13b5e6fd3c414a5c6d2c6b3937a3e60")
