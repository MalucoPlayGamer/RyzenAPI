-- Lua provided by RyzenAPI
-- Game: AppID 688940

-- MAIN APPLICATION
addappid(688940)

-- MAIN APP DEPOTS / PACKAGES
addappid(688941, 1, "7950702306ecf5b72107ce9fd69ac41bc13b5e6fd3c414a5c6d2c6b3937a3e60")

