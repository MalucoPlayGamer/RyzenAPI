-- Lua provided by RyzenAPI
-- Game: Game: Eldorado FPS

-- MAIN APPLICATION
addappid(1831670)
-- Game: addappid(1831670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831671, 1, "924d4fdd4c12649147d654005594dfd81a099ab8c3404a09b0832278450dcaeb")
