-- Lua provided by SkyAPI 
-- Game: Eldorado FPS
addappid(1831670)
addappid(1831671, 1, "924d4fdd4c12649147d654005594dfd81a099ab8c3404a09b0832278450dcaeb")
