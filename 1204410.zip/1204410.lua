-- Lua provided by RyzenAPI
-- Game: Kosmokrats

-- MAIN APPLICATION
addappid(1204410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204411, 1, "88b83e24ff892cd6adb1c044f847ddfaefcb2cf761ae66902e3a413f788fb4d2")

