-- Lua provided by RyzenAPI
-- Game: Gladiator: Blades of Fury Demo

-- MAIN APPLICATION
addappid(1007500)
-- Game: addappid(1007500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007501, 1, "7e71329d9c41da07fa8f40a222a07129c962b881850308929f4ed17abd915017")
