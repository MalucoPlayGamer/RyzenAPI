-- Lua provided by RyzenAPI 
-- Game: AppID 1007500
addappid(1007500)
addappid(1007501, 1, "7e71329d9c41da07fa8f40a222a07129c962b881850308929f4ed17abd915017")
