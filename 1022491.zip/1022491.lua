-- Lua provided by RyzenAPI
-- Game: 1022491

-- MAIN APPLICATION
addappid(1022491)
-- Game: addappid(1022491)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022491,0,"06cc892fb2da4fefa565d7215023b2c9b2d729e387703029e3f06002bba3717a")
