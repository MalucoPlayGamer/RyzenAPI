-- Lua provided by SkyAPI 
-- Game: Hentai Love
addappid(1711460)
addappid(1711461, 1, "4540fa38589eed8741c3f47759d02ae717702c4d61633499da8aea5a1c8068aa")
