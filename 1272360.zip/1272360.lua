-- Lua provided by RyzenAPI
-- Game: AppID 1272360

-- MAIN APPLICATION
addappid(1272360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1272361, 1, "76b3676e1368880d026462fea7cbc95a4fddeb6f1502c9037845460f446e5ccc")

