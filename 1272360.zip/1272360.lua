-- Lua provided by RyzenAPI
-- Game: 1272360

-- MAIN APPLICATION
addappid(1272360)
-- Game: addappid(1272360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272361, 1, "76b3676e1368880d026462fea7cbc95a4fddeb6f1502c9037845460f446e5ccc")
