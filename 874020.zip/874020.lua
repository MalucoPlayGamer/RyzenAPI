-- Lua provided by RyzenAPI
-- Game: Game: Lost Artifacts: Soulstone

-- MAIN APPLICATION
addappid(874020)
-- Game: addappid(874020)

-- MAIN APP DEPOTS / PACKAGES
addappid(874021, 1, "a9ec26b5f8ea0a7aca099ea5011f7ce2c61927732cdd82c4d52d267b953cab7b")
addappid(874024, 1, "c34286a90ea90d874fa60e3a89a61108ad8d63bfa42e87b915cbcda7504279f6")
