-- Lua provided by RyzenAPI
-- Game: Pixel Descent

-- MAIN APPLICATION
addappid(2569330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569331, 1, "ed45f465241c9e77aac88d650862f4490ca54115b3acd775411a61d20bd0f592")
