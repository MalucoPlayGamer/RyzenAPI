-- Lua provided by RyzenAPI 
-- Game: AppID 1056040
addappid(1056040)
addappid(1056041, 1, "89f63b0da1cf004a7ee7e26cb07f5c197a79615012d413b9d4c467bbaaaf7ea6")
