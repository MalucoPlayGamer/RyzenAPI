-- Lua provided by RyzenAPI
-- Game: Zanzarah: The Hidden Portal

-- MAIN APPLICATION
addappid(384570)

-- MAIN APP DEPOTS / PACKAGES
addappid(384571, 1, "724f6b267b0fcc100c0ca8dff1fe3fa19eac306c008dd752f86d970ff89a394d")
addappid(384572, 1, "2d88c34e96704fd1c827c3320aedd5db6b7ceb785eb119148602c7741ecfaaf8")
addappid(384573, 1, "d397a8dc452bdaf7619b7f3407554aefc81142370513b92c9962a7c08b91757a")
