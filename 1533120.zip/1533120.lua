-- Lua provided by RyzenAPI
-- Game: 1533120

-- MAIN APPLICATION
addappid(1533120)
-- Game: addappid(1533120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533121, 1, "f9e43800dbccbb461964c0674dbf09101a184aa8cdabf462ed4598242494e988")
