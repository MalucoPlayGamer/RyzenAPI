-- Lua provided by RyzenAPI 
-- Game: Shonen Adventure : The Dual Blades Hero
addappid(1533120)
addappid(1533121, 1, "f9e43800dbccbb461964c0674dbf09101a184aa8cdabf462ed4598242494e988")
