-- Lua provided by RyzenAPI
-- Game: Free Running

-- MAIN APPLICATION
addappid(254940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254941, 1, "fd1bb4325efc9588cfea8d1ffe37333bc9f401cc10f775c72772e1f30f1107c4")

