-- Lua provided by RyzenAPI
-- Game: AppID 254940

-- MAIN APPLICATION
addappid(254940)
-- Game: addappid(254940)

-- MAIN APP DEPOTS / PACKAGES
addappid(254941, 1, "fd1bb4325efc9588cfea8d1ffe37333bc9f401cc10f775c72772e1f30f1107c4")
