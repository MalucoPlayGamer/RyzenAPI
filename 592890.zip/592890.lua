-- Lua provided by RyzenAPI
-- Game: AppID 592890

-- MAIN APPLICATION
addappid(592890)
addappid(695820)
addappid(809300)

-- MAIN APP DEPOTS / PACKAGES
addappid(592891, 1, "a800bca2c06bb841fd53a3e996cba5d6f0e4bb7150463e239bb19cd64cd10fb0")

