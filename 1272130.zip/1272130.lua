-- Lua provided by SkyAPI 
-- Game: AppID 1272130
addappid(1272130)
addappid(1272131, 1, "2ed2a89e4618bdd90bc8db46ac78e8877ea7edc5a33f962972668483bd8e3eb1")
addappid(1272132, 1, "fd19f83a2dcfc7482998dd0dfb2a3b69f4c8ccd842732326b481dc22a3c37e22")
