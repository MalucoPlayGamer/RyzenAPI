-- Lua provided by RyzenAPI
-- Game: 雪凤山 Secret Opera Demo

-- MAIN APPLICATION
addappid(2730570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730571, 1, "3f7c2f50c14df2b4a8919777599767a806ceb89be3893e0d98d29af53b0bd3d6")

