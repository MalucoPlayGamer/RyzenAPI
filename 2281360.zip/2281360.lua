-- Lua provided by RyzenAPI
-- Game: Old Coin Pusher Friends 2

-- MAIN APPLICATION
addappid(2281360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281361, 1, "3bb30aeaff2279c3a3a17c1698ecb73590ae0d9b95acad9aacdee7aebbd48eb0")
