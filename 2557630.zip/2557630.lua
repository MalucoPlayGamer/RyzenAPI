-- Lua provided by RyzenAPI
-- Game: addappid(2557630)

-- MAIN APPLICATION
addappid(2557630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557631, 1, "04a8f67fd6e3d6b4409e3e4996266e3b2145fd2c2c4787fbabeb0f16936d3978")
