-- Lua provided by RyzenAPI
-- Game: AppID 859740

-- MAIN APPLICATION
addappid(859740)
-- Game: addappid(859740)

-- MAIN APP DEPOTS / PACKAGES
addappid(859741, 1, "d7c55bebdfae8fb8fd713a657058c28a05ce1a18dff8b6ec9a5c06cba1da67cd")
