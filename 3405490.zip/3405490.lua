-- Lua provided by RyzenAPI
-- Game: AppID 3405490

-- MAIN APPLICATION
addappid(3405490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3405491, 1, "1ed068e8b56383ead45f3757b93879c3c8fc2f5a1ceec3512b9323ca0747a5a9")

