-- Lua provided by RyzenAPI
-- Game: 3405490

-- MAIN APPLICATION
addappid(3405490)
-- Game: addappid(3405490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405491, 1, "1ed068e8b56383ead45f3757b93879c3c8fc2f5a1ceec3512b9323ca0747a5a9")
