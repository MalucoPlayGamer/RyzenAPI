-- Lua provided by RyzenAPI
-- Game: addappid(2742430)

-- MAIN APPLICATION
addappid(2742430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742432,0,"7c2da8bfda50f520296d49a0551b1a792e1cbb64a3d3a4d9d944b50ec3fea804")
