-- Lua provided by RyzenAPI
-- Game: Sacred Fire: A Role Playing Game

-- MAIN APPLICATION
addappid(900400)

-- MAIN APP DEPOTS / PACKAGES
addappid(900401, 1, "5bdd7fb110d5d685229d6eab33c4d7894cba1860fb87a127340b12e63ffde22f")
