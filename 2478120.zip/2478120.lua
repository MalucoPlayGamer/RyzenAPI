-- Lua provided by RyzenAPI
-- Game: 2478120

-- MAIN APPLICATION
addappid(2478120)
-- Game: addappid(2478120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478121, 1, "09e81100f0272215eba9b0142734dfec8c6bf801009409fd1ae4c0a3b2cce499")
