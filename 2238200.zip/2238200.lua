-- Lua provided by RyzenAPI
-- Game: Game: AppID 2238200

-- MAIN APPLICATION
addappid(2238200)
-- Game: addappid(2238200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238201, 1, "742ddad7f08621ef4ec726e6c0d9a4608459de069219e37c592f587d805f020d")
