-- Lua provided by RyzenAPI
-- Game: Unexplored 2: The Wayfarer's Legacy

-- MAIN APPLICATION
addappid(1095040)
addappid(2000810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095041, 1, "92a2d3e6736d448815835595ce445ae998a671a2d979e0cb5321117f7d4737cc")
