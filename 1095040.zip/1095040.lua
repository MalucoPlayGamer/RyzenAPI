-- Lua provided by SkyAPI 
-- Game: AppID 1095040
addappid(1095040)
addappid(1095041, 1, "92a2d3e6736d448815835595ce445ae998a671a2d979e0cb5321117f7d4737cc")
