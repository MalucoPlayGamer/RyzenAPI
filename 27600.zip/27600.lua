-- Lua provided by RyzenAPI
-- Game: AppID 27600

-- MAIN APPLICATION
addappid(27600)
-- Game: addappid(27600)

-- MAIN APP DEPOTS / PACKAGES
addappid(27601, 1, "d3edf2407ab3bb1d4b0581a961e162c0500e18124b3194b9a1e199b2c2c6d1b0")
