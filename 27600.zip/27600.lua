-- Lua provided by SkyAPI 
-- Game: AppID 27600
addappid(27600)
addappid(27601, 1, "d3edf2407ab3bb1d4b0581a961e162c0500e18124b3194b9a1e199b2c2c6d1b0")
