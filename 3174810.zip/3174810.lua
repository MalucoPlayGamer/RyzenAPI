-- Lua provided by SkyAPI 
-- Game: ニコニコさん | Niconico-san
addappid(3174810)
addappid(3174811, 1, "8cbb91f0a14343a26ddc28f7b637b4a8dd6daf6e92f147977e9fd5fed77f8f10")
