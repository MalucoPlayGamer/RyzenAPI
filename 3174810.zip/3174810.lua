-- Lua provided by RyzenAPI
-- Game: 3174810

-- MAIN APPLICATION
addappid(3174810)
-- Game: addappid(3174810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174811, 1, "8cbb91f0a14343a26ddc28f7b637b4a8dd6daf6e92f147977e9fd5fed77f8f10")
