-- Lua provided by RyzenAPI
-- Game: CASE 2: Animatronics Survival

-- MAIN APPLICATION
addappid(722960)

-- MAIN APP DEPOTS / PACKAGES
addappid(722961, 1, "0e22d5640582921eae5b530a9290f558416e9ea685de874d741900a74f8634ce")
