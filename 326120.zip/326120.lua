-- Lua provided by SkyAPI 
-- Game: Horizon Shift
addappid(326120)
addappid(326121, 1, "225e7923b6438c2232675b64677053d4ed6e587e35d96edd6ef1efe0573de571")
addappid(370430, 0, "f3684061923ca0b5b18144b73946c585f8b96e6a9ca2a9c655e68dd0228440f0")
