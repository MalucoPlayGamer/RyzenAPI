-- Lua provided by RyzenAPI
-- Game: Fofumia

-- MAIN APPLICATION
addappid(3459570) -- Fofumia

-- MAIN APP DEPOTS / PACKAGES
addappid(3459571, 1, "acf64b838147c45177d57412872c7bd5bf66ed66151a14dae705d60228a0a6eb") -- Depot 3459571
