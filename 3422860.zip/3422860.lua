-- Lua provided by RyzenAPI
-- Game: Game: Mage at Stake

-- MAIN APPLICATION
addappid(3422860)
-- Game: addappid(3422860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422861, 1, "ab42200be8c210c75fcb44003105489b0d63dedd09da85ed66087c0711ac3fd7")
