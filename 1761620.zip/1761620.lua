-- Lua provided by RyzenAPI
-- Game: Headbangers: Rhythm Royale

-- MAIN APPLICATION
addappid(1761620)
addappid(2076750)
addappid(2076751)
addappid(2333290)
addappid(2513610)
addappid(2543980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1761621, 1, "335db1725a0fb8006f1f1a4550f16ff869353a58818e2a2805a3530063f7f90a")

