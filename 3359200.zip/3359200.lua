-- Lua provided by RyzenAPI
-- Game: addappid(3359200)

-- MAIN APPLICATION
addappid(3359200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359201, 1, "24b2900992a8746f8861f4be9a7d2396ad60821dfbd2f62f906058befd5ca044")
