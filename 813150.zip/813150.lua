-- Lua provided by RyzenAPI
-- Game: Elevator Ritual

-- MAIN APPLICATION
addappid(813150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(813151, 1, "84a93168e55ea516ada3c3474308aed31d0a2f9614c41aee579e42b6c62e7539")

