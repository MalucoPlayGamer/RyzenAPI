-- Lua provided by RyzenAPI
-- Game: Game: AppID 474880

-- MAIN APPLICATION
addappid(474880)
-- Game: addappid(474880)

-- MAIN APP DEPOTS / PACKAGES
addappid(474881, 1, "2da0d112689b6bbfdba27e1a7eeef9ec565f84b579807d3d54fe6ca5c7c2dcfc")
