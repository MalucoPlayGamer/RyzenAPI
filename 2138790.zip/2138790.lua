-- Lua provided by RyzenAPI
-- Game: addappid(2138790)

-- MAIN APPLICATION
addappid(2138790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138791, 1, "02fa167e6ea57ea193ea04da7d9bc320732f621f2c69a386a59c185b19951c83")
