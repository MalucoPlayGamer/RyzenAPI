-- Lua provided by RyzenAPI
-- Game: 1652861

-- MAIN APPLICATION
addappid(1652861)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652861,0,"e4b4321517dfe4c0b6ce364c53bbc1b1d6a12b0b36ec7e66112fd14bcd4f1663")

