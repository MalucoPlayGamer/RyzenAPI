-- Lua provided by RyzenAPI
-- Game: Game: POLYCRUSHER

-- MAIN APPLICATION
addappid(517140)
-- Game: addappid(517140)

-- MAIN APP DEPOTS / PACKAGES
addappid(517141, 1, "9949241d21c2d07c37e85b0f7dc806c995dc7898cd0a4c9a05cdbcc17557397a")
