-- Lua provided by RyzenAPI
-- Game: Your Mother

-- MAIN APPLICATION
addappid(3399950)
-- Game: addappid(3399950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399951, 1, "2c92e94b99f89d1f72a0f462f61ad2e1b36e4b8d28c4f660ba501a4bd37276c2")
