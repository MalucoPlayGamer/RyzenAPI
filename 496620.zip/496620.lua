-- Lua provided by RyzenAPI
-- Game: AppID 496620

-- MAIN APPLICATION
addappid(496620)

-- MAIN APP DEPOTS / PACKAGES
addappid(496621, 1, "03fc1980a3d1cb6836f06e80f145a5fa0570e9f4fee0fd09ff8f09ec8dbe69e3")
addappid(496622, 1, "53511b70c40edcb98ca3b2e43ec2f5451ec9bb7a5ac9a8bcd38d6a5fcc2bf411")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(621840)
addappid(634030)
