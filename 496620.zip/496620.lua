-- Lua provided by RyzenAPI
-- Game: Game: AppID 496620

-- MAIN APPLICATION
addappid(496620)
-- Game: addappid(496620)

-- MAIN APP DEPOTS / PACKAGES
addappid(496621, 1, "03fc1980a3d1cb6836f06e80f145a5fa0570e9f4fee0fd09ff8f09ec8dbe69e3")
addappid(496622, 1, "53511b70c40edcb98ca3b2e43ec2f5451ec9bb7a5ac9a8bcd38d6a5fcc2bf411")
