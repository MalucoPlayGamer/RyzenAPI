-- Lua provided by RyzenAPI
-- Game: Cyberphobia: Prologue

-- MAIN APPLICATION
addappid(4127140) -- Cyberphobia: Prologue
addappid(4184950) -- Ghosts in the Ledger
addappid(4184960) -- Proxy War
addappid(4184970) -- Kernel Panic
addappid(4186240) -- Black Budget Arsenal (Weapons DLC)
addappid(4186250) -- Compliance Violation Kit (Items DLC)
addappid(4245780) -- Expansion Pass
addappid(4269910) -- Cyberphobia Prologue - Expansion Pass 2
addappid(4269920) -- Cyberphobia Prologue - Expansion Pass 3
addappid(4270180) -- Cyberphobia Prologue - Expansion Pass 4
addappid(4271660) -- Cyberphobia Prologue - Expansion Pass 5
addappid(4271670) -- Cyberphobia Prologue - Expansion Pass 6
addappid(4427830) -- Cyberphobia Prologue - Expansion Pass 7
addappid(4427840) -- Cyberphobia Prologue - Expansion Pass 8
addappid(4427850) -- Cyberphobia Prologue - Expansion Pass 9
addappid(4427860) -- Cyberphobia Prologue - Expansion Pass 10
addappid(4427870) -- Cyberphobia Prologue - Expansion Pass 11
addappid(4427890) -- Cyberphobia Prologue - Expansion Pass 12
addappid(4427900) -- Cyberphobia Prologue - Expansion Pass 13
addappid(4427910) -- Cyberphobia Prologue - Expansion Pass 14
addappid(4427920) -- Cyberphobia Prologue - Expansion Pass 15
addappid(4427930) -- Cyberphobia Prologue - Expansion Pass 16
addappid(4427940) -- Cyberphobia Prologue - Expansion Pass 17
addappid(4447150) -- Cyberphobia Prologue - Expansion Pass 18
addappid(4447160) -- Cyberphobia Prologue - Expansion Pass 19
addappid(4447170) -- Cyberphobia Prologue - Expansion Pass 20
addappid(4447180) -- Cyberphobia Prologue - Expansion Pass 21
addappid(4447190) -- Cyberphobia Prologue - Expansion Pass 22
addappid(4447200) -- Cyberphobia Prologue - Expansion Pass 23
addappid(4447210) -- Cyberphobia Prologue - Expansion Pass 24
addappid(4447220) -- Cyberphobia Prologue - Expansion Pass 25
addappid(4447230) -- Cyberphobia Prologue - Expansion Pass 26
addappid(4447240) -- Cyberphobia Prologue - Expansion Pass 27
addappid(4447260) -- Cyberphobia Prologue - Expansion Pass 28
addappid(4447270) -- Cyberphobia Prologue - Expansion Pass 29
addappid(4447280) -- Cyberphobia Prologue - Expansion Pass 30
addappid(4447290) -- Cyberphobia Prologue - Expansion Pass 31
addappid(4447310) -- Cyberphobia Prologue - Expansion Pass 32
addappid(4447320) -- Cyberphobia Prologue - Expansion Pass 33
addappid(4447330) -- Cyberphobia Prologue - Expansion Pass 34
addappid(4447340) -- Cyberphobia Prologue - Expansion Pass 35
addappid(4447350) -- Cyberphobia Prologue - Expansion Pass 36
addappid(4447360) -- Cyberphobia Prologue - Expansion Pass 37
addappid(4447440) -- Cyberphobia Prologue - Expansion Pass 38
addappid(4447450) -- Cyberphobia Prologue - Expansion Pass 39
addappid(4447460) -- Cyberphobia Prologue - Expansion Pass 40
addappid(4447470) -- Cyberphobia Prologue - Expansion Pass 41
addappid(4447480) -- Cyberphobia Prologue - Expansion Pass 42
addappid(4447490) -- Cyberphobia Prologue - Expansion Pass 43
addappid(4447500) -- Cyberphobia Prologue - Expansion Pass 44
addappid(4447510) -- Cyberphobia Prologue - Expansion Pass 45
addappid(4447520) -- Cyberphobia Prologue - Expansion Pass 46
addappid(4447530) -- Cyberphobia Prologue - Expansion Pass 47
addappid(4491810) -- Cyberphobia Prologue - Expansion Pass 82
addappid(4491820) -- Cyberphobia Prologue - Expansion Pass 83
addappid(4491830) -- Cyberphobia Prologue - Expansion Pass 84
addappid(4491850) -- Cyberphobia Prologue - Expansion Pass 85
addappid(4491860) -- Cyberphobia Prologue - Expansion Pass 86
addappid(4491870) -- Cyberphobia Prologue - Expansion Pass 87
addappid(4491880) -- Cyberphobia Prologue - Expansion Pass 88
addappid(4491890) -- Cyberphobia Prologue - Expansion Pass 89
addappid(4491900) -- Cyberphobia Prologue - Expansion Pass 90
addappid(4491910) -- Cyberphobia Prologue - Expansion Pass 91
addappid(4491920) -- Cyberphobia Prologue - Expansion Pass 92
addappid(4491930) -- Cyberphobia Prologue - Expansion Pass 93
addappid(4491940) -- Cyberphobia Prologue - Expansion Pass 94

-- MAIN APP DEPOTS / PACKAGES
addappid(4127141, 1, "ce4de7197488f06c4f27df4f44ca181253ecb8e70335e1cbbca2445c38a355d9") -- Depot 4127141
addappid(4127142, 1, "b98f4b911a3498177a5e797fe48edc8ff6166c6baa49f327f9e46e0915ea527d") -- Depot 4127142
addappid(4127143, 1, "1a0ff71195849ea7e683defc24a0aeb84c6d4946b2d31e9b055810e43318cc6b") -- Depot 4127143

