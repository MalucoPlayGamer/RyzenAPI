-- Lua provided by RyzenAPI
-- Game: Wildkeepers Rising

-- MAIN APPLICATION
addappid(2995560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2995561, 1, "82e700a5f0601b7e7330daa61fa8dabf30452670a844774860ceae85d6f1fce3")

