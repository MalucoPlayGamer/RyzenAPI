-- Lua provided by RyzenAPI
-- Game: Wildkeepers Rising

-- MAIN APPLICATION
addappid(2995560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995561, 1, "82e700a5f0601b7e7330daa61fa8dabf30452670a844774860ceae85d6f1fce3")

