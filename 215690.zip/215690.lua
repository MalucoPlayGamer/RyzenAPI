-- Lua provided by RyzenAPI
-- Game: Zeno Clash 2

-- MAIN APPLICATION
addappid(215690)
addappid(228983)
addappid(228990)
addappid(229002)
addappid(229020)
addappid(229030)
-- Game: addappid(215690)

-- MAIN APP DEPOTS / PACKAGES
addappid(215691, 1, "2150095b5a1788aa3d4255cd1dc7d33ba14b5ed88ac7316f1bd1f2648f3e7437")
addappid(237491, 0, "23949bd0d399d2a6e1c67db5b15061e2614e1058b6a89fea1a7f85245551102b")
