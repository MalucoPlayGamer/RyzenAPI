-- Lua provided by RyzenAPI
-- Game: Bounty Battle

-- MAIN APPLICATION
addappid(860900)

-- MAIN APP DEPOTS / PACKAGES
addappid(860901,0,"a5dd2fc5947d9818ff60c8202719c3b82bcbba09246897e172ce8bf47af1b04e")

