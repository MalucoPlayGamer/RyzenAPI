-- Lua provided by RyzenAPI
-- Game: addappid(2798590)

-- MAIN APPLICATION
addappid(2798590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2798591, 1, "3b22e40a68072047fa11e911d22be2a533bd2530fb9a29b568d99fd524f47e6b")
