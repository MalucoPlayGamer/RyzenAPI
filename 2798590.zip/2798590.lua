-- Lua provided by SkyAPI 
-- Game: Desert Blossom Demo
addappid(2798590)
addappid(2798591, 1, "3b22e40a68072047fa11e911d22be2a533bd2530fb9a29b568d99fd524f47e6b")
