-- Lua provided by RyzenAPI
-- Game: AppID 1802720

-- MAIN APPLICATION
addappid(1802720)
addappid(1986060)
addappid(2148660)
addappid(2197460)
addappid(2447170)
addappid(2648850)
addappid(2648860)
addappid(2712520)
addappid(2766750)
addappid(2909210)
addappid(3913740)
addappid(4785690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802721, 1, "f30f24123617d229af147f5c3cf9a145b0a3af2b481488d0f36e1a0efb908d1b")

