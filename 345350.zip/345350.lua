-- Lua provided by RyzenAPI
-- Game: LIGHTNING RETURNS™: FINAL FANTASY® XIII

-- MAIN APPLICATION
addappid(345350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345351, 1, "14849fffc81ea2d3839584d6689572ae90ab5650af482c7a28dad7faccde61e7")
addappid(345352, 1, "4fbdec13288eafd5f6f3eac4a1969f985c702b6042345c408b0c9e65f65d9603")

