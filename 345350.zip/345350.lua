-- Lua provided by RyzenAPI
-- Game: 345350

-- MAIN APPLICATION
addappid(345350)
-- Game: addappid(345350)

-- MAIN APP DEPOTS / PACKAGES
addappid(345351, 1, "14849fffc81ea2d3839584d6689572ae90ab5650af482c7a28dad7faccde61e7")
addappid(345352, 1, "4fbdec13288eafd5f6f3eac4a1969f985c702b6042345c408b0c9e65f65d9603")
