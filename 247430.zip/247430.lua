-- Lua provided by RyzenAPI
-- Game: Game: Hitman: Contracts

-- MAIN APPLICATION
addappid(247430)
-- Game: addappid(247430)

-- MAIN APP DEPOTS / PACKAGES
addappid(247431, 1, "182bcba5d65a64b9c0dc8156b346cb0549ee2af8a977f547686343e596012aae")
addappid(247432, 1, "e7df4fc7093e7772a0654e8df008d29afecfd28c74486250257102383c89f5ff")
addappid(247433, 1, "fd17f44320430619c3cbac87b0ad2e056ddf0477250f4deb2001e3b4dea67a2c")
addappid(247434, 1, "b556b38776a5a50f81fc0af064375f3f810e6834e8e1d6d0530e992da719d333")
addappid(247435, 1, "c9f919d3371c41c64883be0b176efb9f2eb85ba1aa0fc877ce537c02bff42216")
addappid(247436, 1, "66afd23830b046aac40aa68af0ba7dc288025377772d4efd7f9a75866e745fdd")
