-- Lua provided by RyzenAPI
-- Game: Game: Ship Ahoy Open BETA

-- MAIN APPLICATION
addappid(757380)
-- Game: addappid(757380)

-- MAIN APP DEPOTS / PACKAGES
addappid(757381, 1, "7a3a5fa06d0e62c46282c1dddce0e28ebe638eb3d7b179a889266422b1c76169")
