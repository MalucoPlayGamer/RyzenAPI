-- Lua provided by RyzenAPI
-- Game: Ship Ahoy Open BETA

-- MAIN APPLICATION
addappid(757380)

-- MAIN APP DEPOTS / PACKAGES
addappid(757381, 1, "7a3a5fa06d0e62c46282c1dddce0e28ebe638eb3d7b179a889266422b1c76169")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
