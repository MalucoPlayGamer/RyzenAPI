-- Lua provided by RyzenAPI
-- Game: Minotaur Arcade Volume 1

-- MAIN APPLICATION
addappid(906110)

-- MAIN APP DEPOTS / PACKAGES
addappid(906111, 1, "c2b46fa28ffc3849b8268cdcb49f2ed99acec5b0141ba2c70a826d996ad906f1")
