-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096290

-- MAIN APPLICATION
addappid(1096290)
-- Game: addappid(1096290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096291, 1, "4b1a04bd20f191c2bf6fa1592dd20e13a7e30d71bcea75efd04063d0c4ac2bed")
