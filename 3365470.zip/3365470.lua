-- Lua provided by RyzenAPI 
-- Game: Synthwave Driver
addappid(3365470)
addappid(3365471, 1, "83dfaccf553f6b9af34ca8c177840e8761b3f01c5d434599f9bd80a6ad1072a5")
