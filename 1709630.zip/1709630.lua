-- Lua provided by RyzenAPI
-- Game: Game: Iraq War

-- MAIN APPLICATION
addappid(1709630)
-- Game: addappid(1709630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709631, 1, "bbc81dea0195daccc0fccfaea620774d43da9996501292549c12338919b5aff0")
