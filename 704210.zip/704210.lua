-- Lua provided by RyzenAPI
-- Game: Block Warriors

-- MAIN APPLICATION
addappid(704210)

-- MAIN APP DEPOTS / PACKAGES
addappid(704211, 1, "8a354af7fbb5d81a0bb2b51c449903a1b7f1a5921b9bbf87acb4f53348aae10a")
