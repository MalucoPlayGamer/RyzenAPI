-- Lua provided by RyzenAPI
-- Game: Growtopia

-- MAIN APPLICATION
addappid(866020)
addappid(2638310)

-- MAIN APP DEPOTS / PACKAGES
addappid(866021,0,"1b04e7cf87349d1221e571253892912d066583ea19fb014434382f2a6c70a99b")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
