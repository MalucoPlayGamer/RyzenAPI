-- Lua provided by RyzenAPI
-- Game: KAVERNUM

-- MAIN APPLICATION
addappid(3161590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161591, 1, "3fd39aa37e0c953989a722dfbaea4a9bd7c2efebe0565dffd2aba5b7cd39c436")
