-- Lua provided by RyzenAPI
-- Game: KAVERNUM

-- MAIN APPLICATION
addappid(3161590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161591, 1, "3fd39aa37e0c953989a722dfbaea4a9bd7c2efebe0565dffd2aba5b7cd39c436")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
