-- Lua provided by RyzenAPI
-- Game: addappid(449520)

-- MAIN APPLICATION
addappid(449520)

-- MAIN APP DEPOTS / PACKAGES
addappid(449521, 1, "69620de5101468b5087f0a3add2cf1bfd9107fa5dc08eab02e6a40613e44b5bc")
