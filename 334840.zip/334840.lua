-- Lua provided by RyzenAPI
-- Game: addappid(334840)

-- MAIN APPLICATION
addappid(334840)

-- MAIN APP DEPOTS / PACKAGES
addappid(334841, 1, "de6dec43e4bb58872b3d9d8a46bc136a52d35a7e189063af2b4bef317f776f72")
addappid(334842, 1, "a933d1f442310fae3789b46d0ec3f46f6c30bcac8d0acb3ca524152438855c05")
addappid(334843, 1, "02e127dab01e99b8e6afed33b6e13d6cf5f9a3d36ed6fb320a62e5ddda26623a")
