-- Lua provided by RyzenAPI 
-- Game: KARAKARA
addappid(487430)
addappid(487431, 1, "c003b91d49d8e7d62e264e8a2bd990db36a8040b6d129a970f90856bbc1725df")
addappid(947680, 0, "fb0e986f34c2aadedb5762ede3731d7b1a225b2923b3e522197f56214ebd28dc")
