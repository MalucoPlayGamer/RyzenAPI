-- Lua provided by RyzenAPI
-- Game: AppID 1045070

-- MAIN APPLICATION
addappid(1045070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045071, 1, "2a0bb84362126d183af06ba17f04fbdffb5bcf9e9aed20164ea3eb3029958e91")
