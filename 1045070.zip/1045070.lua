-- Lua provided by RyzenAPI
-- Game: Please Find Me

-- MAIN APPLICATION
addappid(1045070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1045071, 1, "2a0bb84362126d183af06ba17f04fbdffb5bcf9e9aed20164ea3eb3029958e91")

