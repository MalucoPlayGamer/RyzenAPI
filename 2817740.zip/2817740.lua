-- Lua provided by RyzenAPI
-- Game: addappid(2817740)

-- MAIN APPLICATION
addappid(2817740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817742,0,"84fb951781169e2eecc6b0bfebaa864c014496db9dc36f225debfb352eef5044")
