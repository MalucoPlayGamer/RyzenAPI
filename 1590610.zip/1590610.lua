-- Lua provided by RyzenAPI
-- Game: AppID 1590610

-- MAIN APPLICATION
addappid(1590610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590611, 1, "1ebf0e0cd15ff50f8fc45697f16c548c15d084d8af93413cb22d4b40ba1ff11f")
