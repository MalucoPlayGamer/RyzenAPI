-- Lua provided by RyzenAPI
-- Game: Angrbotha Mountains

-- MAIN APPLICATION
addappid(2318670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318671, 1, "1bae07b4ec889bc4b5a418984fbe7cf0f81f9980191f6c9de255cd97364b3025")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
