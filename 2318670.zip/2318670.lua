-- Lua provided by RyzenAPI 
-- Game: Angrbotha Mountains
addappid(2318670)
addappid(2318671, 1, "1bae07b4ec889bc4b5a418984fbe7cf0f81f9980191f6c9de255cd97364b3025")
