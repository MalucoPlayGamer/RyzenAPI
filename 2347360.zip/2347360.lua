-- Lua provided by RyzenAPI
-- Game: addappid(2347360)

-- MAIN APPLICATION
addappid(2347360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347361, 1, "9b1748600168aec1aaddcde7a18ac848ac042c7697e2fc9552f9bfcad5cb2bee")
