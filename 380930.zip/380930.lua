-- Lua provided by RyzenAPI
-- Game: 380930

-- MAIN APPLICATION
addappid(228982)
addappid(228990)
addappid(380930)
addappid(380931)
addappid(380933)
addappid(380934)

-- MAIN APP DEPOTS / PACKAGES
addappid(380932,0,"76faca7e7230791bc7bdfbef9de1c250259dd4fa3af1cdb8cff8595086454b19")

