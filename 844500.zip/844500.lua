-- Lua provided by RyzenAPI
-- Game: Draw a Stickman: EPIC 3

-- MAIN APPLICATION
addappid(844500)

-- MAIN APP DEPOTS / PACKAGES
addappid(844501, 1, "9a1f0931dec4f652f43446dc2ba941ac3776f9049f0ff004da027ad0103c6cf7")

