-- Lua provided by RyzenAPI
-- Game: Yasuke Simulator

-- MAIN APPLICATION
addappid(3272300)
addappid(3599190)
addappid(3599230)
addappid(3599240)
-- Game: addappid(3272300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272301, 1, "a04583eb791521d867756bfcabe7706dd288b23799bd1a5ac112362590ab5208")
