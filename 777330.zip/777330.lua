-- Lua provided by RyzenAPI
-- Game: Only One

-- MAIN APPLICATION
addappid(777330)

-- MAIN APP DEPOTS / PACKAGES
addappid(777331, 1, "441fd8d9be999f11fe371a7e9e72d6ca03e022a89b00cd1ba1262ef70b053ccc")

