-- Lua provided by RyzenAPI
-- Game: 562230

-- MAIN APPLICATION
addappid(562230)
-- Game: addappid(562230)

-- MAIN APP DEPOTS / PACKAGES
addappid(562231, 1, "52c1ff9d201655da5845b220ffb9dfa963377778f56349a3c6989dd2038be885")
