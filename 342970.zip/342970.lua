-- Lua provided by RyzenAPI
-- Game: AppID 342970

-- MAIN APPLICATION
addappid(342970)

-- MAIN APP DEPOTS / PACKAGES
addappid(342971, 1, "5c4b33129c5aae9a1a8f8ccf9ec4fdbc983bb602a110fb839729723ab3d8deb0")

