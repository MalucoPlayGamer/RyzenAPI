-- Lua provided by RyzenAPI
-- Game: FUSER™ - Linkin Park - "Numb"

-- MAIN APPLICATION
addappid(1536762)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536762,0,"d8452acafd760f27a385350e00df157a9876d67799a9723c9875986156ec731f")

