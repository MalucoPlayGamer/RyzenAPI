-- Lua provided by RyzenAPI
-- Game: 3169680

-- MAIN APPLICATION
addappid(3169680)
-- Game: addappid(3169680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169681, 1, "0f3522eb79ace405a0f8cdbd55e2ffdd85e6934f74d9fe3af54f40d0db123f26")
