-- Lua provided by RyzenAPI
-- Game: 1767630

-- MAIN APPLICATION
addappid(1767630)
-- Game: addappid(1767630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767631, 1, "0955937eaef29141c4a65c1215b05a7b06fce9da63d6f405e8000ea7ce4929ac")
