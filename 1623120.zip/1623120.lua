-- Lua provided by RyzenAPI
-- Game: Chaos on Wheels

-- MAIN APPLICATION
addappid(1623120)
addappid(2530590)
-- Game: addappid(1623120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623121, 1, "06db757b3f20789109ac22a47a8494683ff8b5a3b83beea05214d2dd445c38fa")
