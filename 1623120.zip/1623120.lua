-- Lua provided by RyzenAPI
-- Game: Chaos on Wheels

-- MAIN APPLICATION
addappid(1623120)
addappid(2530590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1623121, 1, "06db757b3f20789109ac22a47a8494683ff8b5a3b83beea05214d2dd445c38fa")

