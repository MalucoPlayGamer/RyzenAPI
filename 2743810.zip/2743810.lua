-- Lua provided by RyzenAPI
-- Game: Kudo’s Kuppa

-- MAIN APPLICATION
addappid(2743810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743811,0,"fac833be6a32b0535f414741a0feb34f0d343d3229617bc12c9bf5aaae73a37e")

