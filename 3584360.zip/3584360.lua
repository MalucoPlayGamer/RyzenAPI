-- Lua provided by RyzenAPI
-- Game: War Untold

-- MAIN APPLICATION
addappid(3584360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584361, 1, "695072aa0f23572c39fcd3e1ea7050007e46e17fd97cbd616866409eda80c4e9")
