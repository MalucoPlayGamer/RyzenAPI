-- Lua provided by SkyAPI 
-- Game: Rush for Glory
addappid(303470)
addappid(303471, 1, "739c7ffc6b2999dbe1400f2f10b6bf399401173c5d196ac00fb5f5aeff14ac42")
