-- Lua provided by RyzenAPI
-- Game: Rush for Glory

-- MAIN APPLICATION
addappid(303470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(303471, 1, "739c7ffc6b2999dbe1400f2f10b6bf399401173c5d196ac00fb5f5aeff14ac42")

