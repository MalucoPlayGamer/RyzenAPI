-- Lua provided by RyzenAPI
-- Game: Rush for Glory

-- MAIN APPLICATION
addappid(303470)

-- MAIN APP DEPOTS / PACKAGES
addappid(303471, 1, "739c7ffc6b2999dbe1400f2f10b6bf399401173c5d196ac00fb5f5aeff14ac42")

