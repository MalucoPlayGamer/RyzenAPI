-- Lua provided by RyzenAPI
-- Game: FerryMan

-- MAIN APPLICATION
addappid(3995840) -- FerryMan

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3995841, 1, "c236b2f5090cf6c1c189cdd76c1c31da0f39d5201ffd6d10b02c34073b38b8b2") -- Depot 3995841

