-- Lua provided by RyzenAPI
-- Game: StandPoint

-- MAIN APPLICATION
addappid(322550)

-- MAIN APP DEPOTS / PACKAGES
addappid(322551, 1, "5eb6df339eb68627c292651f9df858eb84a6af6dcc2521bb018c387c89f9231e")
addappid(322552, 1, "483c25890d4837e9344302e9ec62a13d777fbd788448f4d4c7ce0fe91dc5c5ef")
addappid(322553, 1, "c88c2a532028cc2e81f9e4953eda91f237dd6e5d31e205942a651ba247779615")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
