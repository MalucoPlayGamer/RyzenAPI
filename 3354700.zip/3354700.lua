-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354700,0,"246def1b055d85477302baed99216bac14b0d5ba4448169d5d95e44711ae642a")
