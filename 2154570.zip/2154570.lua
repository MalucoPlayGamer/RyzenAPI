-- Lua provided by RyzenAPI
-- Game: Soulslinger

-- MAIN APPLICATION
addappid(2154570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154571, 1, "d4226e45eb963c0c90f7aff7b937ad2748b347dd70661cb9fd60ce174670a417")
