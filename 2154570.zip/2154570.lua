-- Lua provided by RyzenAPI 
-- Game: Soulslinger
addappid(2154570)
addappid(2154571, 1, "d4226e45eb963c0c90f7aff7b937ad2748b347dd70661cb9fd60ce174670a417")
