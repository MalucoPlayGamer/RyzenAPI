-- Lua provided by RyzenAPI
-- Game: World of Football

-- MAIN APPLICATION
addappid(946880)
-- Game: addappid(946880)

-- MAIN APP DEPOTS / PACKAGES
addappid(946881, 1, "57b03399bb7821a7195790673debd6d024c66c3466d4a245e7f3932b5499bbf1")
