-- Lua provided by RyzenAPI
-- Game: Battlegrounds : At Enemy Gates

-- MAIN APPLICATION
addappid(2599320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599321, 1, "6621e531f1646bb247bf18cb626b94fd03fe3f054d53dcb5067d6f00c5604e13")
