-- Lua provided by RyzenAPI
-- Game: Jujutsu Kaisen Phantom Parade

-- MAIN APPLICATION
addappid(4224240)

