-- Lua provided by RyzenAPI
-- Game: Holy Clash Cards

-- MAIN APPLICATION
addappid(2928340)
addappid(2931080)
-- Game: addappid(2928340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928341, 1, "f47f00518d6a01cdc41559a295e48efd9eb23eea05db379afb81c0b88684e850")
