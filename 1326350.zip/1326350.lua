-- Lua provided by RyzenAPI
-- Game: King of the Hat - Friend Pass

-- MAIN APPLICATION
addappid(1326350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326352,0,"56672b7b5ea76651746440e7cbb5e4d9d405034c1064db2316c0f8551ee9a0d7")
addappid(1326353,0,"6b9aebc2c05bcead9db337d1f62b2cd5df55ea97a6b282ea874868209fa73bba")

