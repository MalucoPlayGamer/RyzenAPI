-- Lua provided by RyzenAPI
-- Game: Ryse: Son of Rome

-- MAIN APPLICATION
addappid(302510)
addappid(321440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(302511, 1, "077ac69c92a280ff9f72fa74a851954290a19850014909f6b279a4212f58f2be")
addappid(302512, 1, "dd7454ff229c81fc90bceb393ec2890da81e9861d81451f753c83d08ead4f9e0")
addappid(302513, 1, "a9e59645be4be6ba2d78709770f02cabc2281ea94b745cb1c228d1674b1da0a8")
addappid(302514, 1, "fed6e6f944a7b2b20766b2d8a006d61bac6a3c64f7c93eecef61e51d6215e574")
addappid(302515, 1, "24b30498739fec2fd5f4686a16d7981a2d0f649f23a0ed34c474268a31eee466")

