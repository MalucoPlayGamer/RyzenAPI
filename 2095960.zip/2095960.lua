-- Lua provided by RyzenAPI
-- Game: addappid(2095960)

-- MAIN APPLICATION
addappid(2095960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095961, 1, "c1887f4cac5a0f629a8b32ef0c32abc99a5a436b435b7a323addee220ad00908")
