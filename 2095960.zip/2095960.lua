-- Lua provided by RyzenAPI
-- Game: Isostasy

-- MAIN APPLICATION
addappid(2095960)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2095961, 1, "c1887f4cac5a0f629a8b32ef0c32abc99a5a436b435b7a323addee220ad00908")
