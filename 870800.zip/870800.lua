-- Lua provided by RyzenAPI
-- Game: addappid(870800)

-- MAIN APPLICATION
addappid(870800)

-- MAIN APP DEPOTS / PACKAGES
addappid(870804,0,"940d168c6daf35f40996cbe39ece68d58778cbe3717554c85a64c257a5c7759b")
