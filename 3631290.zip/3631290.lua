-- Lua provided by RyzenAPI
-- Game: Slots & Daggers

-- MAIN APPLICATION
addappid(3631290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631291,0,"307ed58daf3aac4460d1042ec7fd87c181584a5272a9bbfe7d26284bd1f02f0f")
addappid(3631292,0,"aa07ca92101d064e6869bef65e1d227509282586c181dcd9b489fe145afb7e3e")

