-- Lua provided by RyzenAPI
-- Game: Gazing from beyond

-- MAIN APPLICATION
addappid(782690)

-- MAIN APP DEPOTS / PACKAGES
addappid(782692,0,"cb9ad9ad10a4dfa1d8d1ae8b04b7445bc19acc9cb87880279058c05f33e4cf62")
addappid(822330,0,"f6167059e00144296745cc65107b23730629970ea0fdf1b0956ada648f365e31")
