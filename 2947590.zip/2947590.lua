-- Lua provided by RyzenAPI
-- Game: Deep Desktop

-- MAIN APPLICATION
addappid(2947590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2947591, 1, "4cc8708a9b2e69c89afe0002913a8057aab15f719417a4e9b48b423eb77cb873")
addappid(2947592, 1, "995893f9afd36fd7c26b8da3ae5de68b1b0cb88c2b850eb3ba6f994444187a6c")

