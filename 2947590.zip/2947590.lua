-- Lua provided by RyzenAPI
-- Game: Game: Deep Desktop

-- MAIN APPLICATION
addappid(2947590)
-- Game: addappid(2947590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947591, 1, "4cc8708a9b2e69c89afe0002913a8057aab15f719417a4e9b48b423eb77cb873")
addappid(2947592, 1, "995893f9afd36fd7c26b8da3ae5de68b1b0cb88c2b850eb3ba6f994444187a6c")
