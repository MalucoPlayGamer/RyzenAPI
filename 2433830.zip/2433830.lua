-- Lua provided by RyzenAPI
-- Game: Game: Spider

-- MAIN APPLICATION
addappid(2433830)
-- Game: addappid(2433830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433831, 1, "b150632b0c9a875978a373ad0657399db68bca7b81dd90bc59e6eb680f4fdc47")
