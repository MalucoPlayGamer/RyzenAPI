-- Lua provided by RyzenAPI
-- Game: Game: Skate City

-- MAIN APPLICATION
addappid(1361670)
-- Game: addappid(1361670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361671, 1, "8ee3081bae04e460427781e1db845279ccefb04dd0de760102a6601034add13e")
