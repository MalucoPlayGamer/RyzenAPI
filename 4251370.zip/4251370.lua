-- Lua provided by RyzenAPI
-- Game: D.E.C.A.Y.

-- MAIN APPLICATION
addappid(4251370) -- D.E.C.A.Y.

-- MAIN APP DEPOTS / PACKAGES
addappid(4251371, 1, "aa7bc221837be89b3059e8fe515fddbe5108ea4200660681ea17a6e445c25978") -- Depot 4251371
