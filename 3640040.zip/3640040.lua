-- Lua provided by RyzenAPI
-- Game: 回煞录 | Phantom Reckoning

-- MAIN APPLICATION
addappid(3640040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3640041, 1, "b1a1fd68c238d6d7378be1cd8ecf70ec62dd173894811d94963422de44f91d96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
