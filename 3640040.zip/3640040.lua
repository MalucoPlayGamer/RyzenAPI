-- Lua provided by RyzenAPI
-- Game: Game: 回煞录 | Phantom Reckoning

-- MAIN APPLICATION
addappid(3640040)
-- Game: addappid(3640040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3640041, 1, "b1a1fd68c238d6d7378be1cd8ecf70ec62dd173894811d94963422de44f91d96")
