-- Lua provided by RyzenAPI
-- Game: 436790

-- MAIN APPLICATION
addappid(436790)
-- Game: addappid(436790)

-- MAIN APP DEPOTS / PACKAGES
addappid(436790,0,"8f339dc47a94e7629b77e49122923cd8332f116bd70950499b7ff7803e2bced5")
