-- Lua provided by RyzenAPI
-- Game: Game: 咕啾！文鸟恋爱物语 Love Story of Sparrow

-- MAIN APPLICATION
addappid(926310)
-- Game: addappid(926310)

-- MAIN APP DEPOTS / PACKAGES
addappid(926311, 1, "9e09ed4cb9fb84be2536ee89a8e8acc8de3fdc592d8a16252874790a951a4b77")
addappid(926312, 1, "d02f5f021e9a074b6939beea7164e837297fb4fe5c1b8f20625dc1b6944d08e3")
