-- Lua provided by RyzenAPI
-- Game: 264580

-- MAIN APPLICATION
addappid(264580)
-- Game: addappid(264580)

-- MAIN APP DEPOTS / PACKAGES
addappid(264581, 1, "f787ca750ec862b397dce65b943d87551e47f56f5afe5ff2f1fab94644aa36a7")
