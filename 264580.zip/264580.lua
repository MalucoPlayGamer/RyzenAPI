-- Lua provided by RyzenAPI
-- Game: Lost Civilization

-- MAIN APPLICATION
addappid(264580)

-- MAIN APP DEPOTS / PACKAGES
addappid(264581, 1, "f787ca750ec862b397dce65b943d87551e47f56f5afe5ff2f1fab94644aa36a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
