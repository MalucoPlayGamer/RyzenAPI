-- Lua provided by RyzenAPI
-- Game: Onyx

-- MAIN APPLICATION
addappid(370620)
addappid(1087890)

-- MAIN APP DEPOTS / PACKAGES
addappid(370621, 1, "dda6483a618e1bb3bc04657bbbd1ad240aaf0f35fbe86f20f12d604ecc773455")

