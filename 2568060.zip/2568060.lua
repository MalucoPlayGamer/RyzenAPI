-- Lua provided by RyzenAPI
-- Game: Interstellar Shore VR: I LIVE

-- MAIN APPLICATION
addappid(2568060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568061, 1, "bd8effd79ac020566d3991e62ff77a0b479a8856dcee468602166073402dd1b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
