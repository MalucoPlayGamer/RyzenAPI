-- Lua provided by RyzenAPI 
-- Game: Interstellar Shore VR: I LIVE
addappid(2568060)
addappid(2568061, 1, "bd8effd79ac020566d3991e62ff77a0b479a8856dcee468602166073402dd1b0")
