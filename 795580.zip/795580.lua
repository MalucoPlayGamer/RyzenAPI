-- Lua provided by RyzenAPI
-- Game: addappid(795580)

-- MAIN APPLICATION
addappid(795580)

-- MAIN APP DEPOTS / PACKAGES
addappid(795581, 1, "8c08fa2e4a405250faa70b183d83a22170e6b42f30dc1c0a5d8a83dc76a23963")
