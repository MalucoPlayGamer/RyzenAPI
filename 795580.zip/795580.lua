-- Lua provided by SkyAPI 
-- Game: THE DAY Online
addappid(795580)
addappid(795581, 1, "8c08fa2e4a405250faa70b183d83a22170e6b42f30dc1c0a5d8a83dc76a23963")
