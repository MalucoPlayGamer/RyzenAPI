-- Lua provided by RyzenAPI
-- Game: THE DAY Online

-- MAIN APPLICATION
addappid(795580)
addappid(795600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(795581,0,"8c08fa2e4a405250faa70b183d83a22170e6b42f30dc1c0a5d8a83dc76a23963")

