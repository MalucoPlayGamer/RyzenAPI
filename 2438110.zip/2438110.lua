-- 2438110's Lua and Manifest Created by Hubcap Manifest
-- Emergency Room Simulator
-- Created: August 13, 2026 at 10:29:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2438110) -- Emergency Room Simulator
-- MAIN APP DEPOTS
addappid(2438111, 1, "419aca58b5376b3ea49d013450b85a805a708cb1fe429ba7b0cd846534a85b4f") -- Depot 2438111
setManifestid(2438111, "1309770033070424301", 5964725498)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)