-- Lua provided by RyzenAPI
-- Game: 1529530

-- MAIN APPLICATION
addappid(1529530)
-- Game: addappid(1529530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529531, 1, "6cea202ad70863b80820fec7f6f0d09447840cc399b87a0d9aaf7a488850e188")
