-- Lua provided by SkyAPI 
-- Game: Into The Darkness VR
addappid(1529530)
addappid(1529531, 1, "6cea202ad70863b80820fec7f6f0d09447840cc399b87a0d9aaf7a488850e188")
