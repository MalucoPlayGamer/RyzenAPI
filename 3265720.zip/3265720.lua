-- Lua provided by RyzenAPI
-- Game: Game: Soulers Demo

-- MAIN APPLICATION
addappid(3265720)
-- Game: addappid(3265720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265721, 1, "d7c8366cd920615fa738a4c2d88958fe3ffe6a2f101701958eea04a6a15c9b78")
