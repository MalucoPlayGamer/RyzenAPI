-- Lua provided by RyzenAPI
-- Game: 294730

-- MAIN APPLICATION
addappid(294730)
-- Game: addappid(294730)

-- MAIN APP DEPOTS / PACKAGES
addappid(294731, 1, "5e20240894c2f0c1bba6d7069b008f90805db1d376066f86ca0f405bf5df7a29")
