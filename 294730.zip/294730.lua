-- Lua provided by SkyAPI 
-- Game: Marine Park Empire
addappid(294730)
addappid(294731, 1, "5e20240894c2f0c1bba6d7069b008f90805db1d376066f86ca0f405bf5df7a29")
