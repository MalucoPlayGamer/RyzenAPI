-- Lua provided by RyzenAPI
-- Game: addappid(1535540)

-- MAIN APPLICATION
addappid(1535540)
addappid(1535541)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535540,0,"756cc1ae5b01fed9d9ee883bf16aae209501a2599a542800e798341fc134c958")
