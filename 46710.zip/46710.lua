-- Lua provided by RyzenAPI
-- Game: Ironclads: High Seas

-- MAIN APPLICATION
addappid(46710)

-- MAIN APP DEPOTS / PACKAGES
addappid(46711, 1, "282fb43aa58d2c28405f1f681284a8ec9ebc14c60638e7eff0a492f14f536e4a")

