-- Lua provided by RyzenAPI
-- Game: Elemental

-- MAIN APPLICATION
addappid(1477870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477871, 1, "1ae31095837cee3c26e8f5ff85028d5fa8fdb4d525f82713fd2bd351ab01b69a")
