-- Lua provided by SkyAPI 
-- Game: Elemental
addappid(1477870)
addappid(1477871, 1, "1ae31095837cee3c26e8f5ff85028d5fa8fdb4d525f82713fd2bd351ab01b69a")
