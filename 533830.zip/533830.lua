-- Lua provided by RyzenAPI
-- Game: Starbound Dedicated Server

-- MAIN APPLICATION
addappid(533830)

-- MAIN APP DEPOTS / PACKAGES
addappid(533831, 1, "2f81137319b6f2e82b6d39428d3c3ad525f3c52a4cade92ec20cd3965378438a")
addappid(533832, 1, "19ac130c21ac18ccfb2acc16465bb2880489887a46ca64599d2635753143ba4b")
addappid(533833, 1, "406572d0dcd7a2256c614e8cddfe4c3541ecef0408093d218308fc632ba3cd6f")

