-- Lua provided by RyzenAPI
-- Game: 航海霸業 Maritime hegemony

-- MAIN APPLICATION
addappid(2082540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082541, 1, "de31edf77532372e0c930a22d9a2f14dd5492d3b0ad9181bd1ffb31d01e1f547")

