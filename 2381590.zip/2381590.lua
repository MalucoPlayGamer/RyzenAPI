-- Lua provided by RyzenAPI
-- Game: Game: not available

-- MAIN APPLICATION
addappid(2381590)
-- Game: addappid(2381590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381591, 1, "5efdd578a562ae5ff6206f805d07b6b81f168362b7c79876a4fbbb42f0d921ea")
