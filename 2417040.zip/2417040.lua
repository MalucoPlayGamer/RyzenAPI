-- Lua provided by SkyAPI 
-- Game: LUNARK Soundtrack
addappid(2417040)
addappid(2417041, 1, "b5ba994b63c75c91652bcd09a0c56e01a53ef4b881987c3e344b06f41a47c3a2")
addappid(2417042, 1, "4d50026f892f1136b78a4b987d211ff7bb650d4ac4e353e1cabb686d2fa12faf")
