-- Lua provided by RyzenAPI
-- Game: The Garden of the Gods

-- MAIN APPLICATION
addappid(2850270)
-- Game: addappid(2850270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850271, 1, "c8abf90490fb39b289d8af9844832cd4f3d57455a6185510fde53c4127189374")
addappid(3145710, 0, "1f1caf109a9832cfe83b00ea70a65cc117cbdcc5d8caf872dc0cc5552b8dcb80")
