-- Lua provided by RyzenAPI
-- Game: 972720

-- MAIN APPLICATION
addappid(972720)
-- Game: addappid(972720)

-- MAIN APP DEPOTS / PACKAGES
addappid(972720,0,"d0b0e3f233bb6440636195cfe39d6f067d40c266c45270ed1263e50cc447f64e")
