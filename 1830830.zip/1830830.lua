-- Lua provided by RyzenAPI
-- Game: Splash Fly Fire

-- MAIN APPLICATION
addappid(1830830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830831, 1, "b691d794472465d2f76b50d0c27b989297ee3aa739f4fb6c7c455d7e116018ad")

