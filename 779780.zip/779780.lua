-- Lua provided by RyzenAPI
-- Game: R Academy

-- MAIN APPLICATION
addappid(779780)

-- MAIN APP DEPOTS / PACKAGES
addappid(779781, 1, "c448b0b537714a5e12b8c629b42ef66c12cdfb3140266d4d142a39a5f7548afe")

