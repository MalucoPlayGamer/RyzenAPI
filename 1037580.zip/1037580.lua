-- Lua provided by RyzenAPI
-- Game: addappid(1037580)

-- MAIN APPLICATION
addappid(1037580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037581, 1, "2c47ef856eb33ebbc3376e1c6199c7c86a4a5e883b922737ddbfd7eeb8128f2e")
