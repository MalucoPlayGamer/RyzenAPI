-- Lua provided by RyzenAPI
-- Game: Game: Under The Warehouse

-- MAIN APPLICATION
addappid(1793340)
-- Game: addappid(1793340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793341, 1, "bb364883cea9e28ee76dfb9612bc9d64a84cdc1666608cee16f63e14e65acfa2")
