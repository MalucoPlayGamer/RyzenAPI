-- Lua provided by RyzenAPI
-- Game: Decoherence

-- MAIN APPLICATION
addappid(561660)
-- Game: addappid(561660)

-- MAIN APP DEPOTS / PACKAGES
addappid(561661, 1, "d9eff0f1d2060ef373cb05fbc240077d1feaa222dd2ba295c6105f1548818368")
