-- Lua provided by RyzenAPI
-- Game: Gunman Tales

-- MAIN APPLICATION
addappid(760320)

-- MAIN APP DEPOTS / PACKAGES
addappid(760321, 1, "a1dad5d7537db8419727e1fda9c973ccfa8095a0b0b457c4cb04c6f07a51e9a7")

