-- Lua provided by RyzenAPI
-- Game: Sex Simulator - BDSM

-- MAIN APPLICATION
addappid(2432780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432781, 1, "b2eeb3d973c148f004b6c8a8120c142874c24d30fa5c052b9347bef3097c4447")

