-- Lua provided by RyzenAPI
-- Game: addappid(2637170)

-- MAIN APPLICATION
addappid(2637170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637171, 1, "c60e18fca5cd831027c052d7c58b4c8f9d15bb4153515cbcebfc7d68ab52b7d0")
