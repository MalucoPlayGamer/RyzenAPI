-- Lua provided by RyzenAPI
-- Game: Hunter Girls

-- MAIN APPLICATION
addappid(2506470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506471, 1, "506bd8070f0934afcd96bef8c201ee7f1549a55f08c2397893f05a3443f7732f")
