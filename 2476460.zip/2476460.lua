-- Lua provided by RyzenAPI
-- Game: addappid(2476460)

-- MAIN APPLICATION
addappid(2476460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476461, 1, "de2cf5a4d950a5557cbb70f8e5e474cd803a0ee60fab652c6959f50400491d4f")
