-- Lua provided by RyzenAPI
-- Game: Rising Storm 2: Vietnam

-- MAIN APPLICATION
addappid(418460)
addappid(629750)
addappid(629751)
addappid(737270)
addappid(737272)
addappid(794340)
addappid(794341)
addappid(794342)
addappid(794343)
addappid(794344)
addappid(794345)
addappid(1042390)
addappid(1042400)
addappid(1062590)
addappid(1074650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(418461, 1, "cf81b97143fb2a34580f171c2d5eb46c95b873e1a7f079c3e18eead69aca3926")
addappid(418462, 1, "0487b915fdd473df480aa053ccbb8d1af30ca2f59525dd9e3c1d3fdf9e16f1d2")

