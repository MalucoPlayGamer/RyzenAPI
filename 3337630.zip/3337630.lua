-- Lua provided by RyzenAPI
-- Game: Paranormal Snap Shot

-- MAIN APPLICATION
addappid(3337630)
-- Game: addappid(3337630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337631, 1, "2c8291053566800aaa208ae9f0878c38785f8c4706d916327d29572f301f6666")
