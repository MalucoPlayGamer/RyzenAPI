-- Lua provided by RyzenAPI
-- Game: Paranormal Snap Shot

-- MAIN APPLICATION
addappid(3337630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337631, 1, "2c8291053566800aaa208ae9f0878c38785f8c4706d916327d29572f301f6666")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
