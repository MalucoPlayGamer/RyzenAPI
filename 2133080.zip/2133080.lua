-- Lua provided by RyzenAPI
-- Game: Vesalii Anatomy 3D Student

-- MAIN APPLICATION
addappid(2133080)
-- Game: addappid(2133080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133081, 1, "a26cd50a1768d94ea06c19a36b49c62d111e1f6953e9be6309eed81f21a01b6b")
