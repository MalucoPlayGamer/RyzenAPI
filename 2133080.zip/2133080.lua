-- Lua provided by SkyAPI 
-- Game: Vesalii Anatomy 3D Student
addappid(2133080)
addappid(2133081, 1, "a26cd50a1768d94ea06c19a36b49c62d111e1f6953e9be6309eed81f21a01b6b")
