-- Lua provided by SkyAPI 
-- Game: AppID 1260020
addappid(1260020)
addappid(1260021, 1, "b314afd2209d4b9200efbc4172395981926107aa7d67f0e26f60ae3fa87da8e7")
