-- Lua provided by RyzenAPI
-- Game: addappid(1260020)

-- MAIN APPLICATION
addappid(1260020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260021, 1, "b314afd2209d4b9200efbc4172395981926107aa7d67f0e26f60ae3fa87da8e7")
