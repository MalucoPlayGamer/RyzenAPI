-- Lua provided by RyzenAPI
-- Game: addappid(1191210)

-- MAIN APPLICATION
addappid(1191210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191211, 1, "910386b5dc6f3e38eeb826ae401bbcc7a8630aa6597ff4e77fbf9db8c5239c03")
addappid(1196510, 0, "ea8720e83fd2bdbaae10eb9225c45ca4148d4c62613d45f50887a8524d42f9fc")
