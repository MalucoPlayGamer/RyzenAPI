-- Lua provided by RyzenAPI
-- Game: Game: TheFoolish

-- MAIN APPLICATION
addappid(3164730)
-- Game: addappid(3164730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164731, 1, "246d458c9ad65007c862847882da2b188a553b59ea3ce8eac3ba4ed1369ac556")
