-- Lua provided by RyzenAPI
-- Game: The Steadfast VR Challenge

-- MAIN APPLICATION
addappid(833110)
-- Game: addappid(833110)

-- MAIN APP DEPOTS / PACKAGES
addappid(833111, 1, "683d11f94e4146efdee9ad2cc4c8fad8f9e32504eed4cf761db68536b66ba665")
