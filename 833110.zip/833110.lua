-- Lua provided by RyzenAPI
-- Game: The Steadfast VR Challenge

-- MAIN APPLICATION
addappid(833110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(833111, 1, "683d11f94e4146efdee9ad2cc4c8fad8f9e32504eed4cf761db68536b66ba665")

