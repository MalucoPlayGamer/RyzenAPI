-- Lua provided by RyzenAPI
-- Game: Project Remedium

-- MAIN APPLICATION
addappid(475090)

-- MAIN APP DEPOTS / PACKAGES
addappid(475091, 1, "9f92d7dd60b1746d8a46d7d92e171e1141c39180464ebd8e4a7d09e8eb9d09ab")
