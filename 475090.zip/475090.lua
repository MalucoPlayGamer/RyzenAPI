-- Lua provided by RyzenAPI
-- Game: Project Remedium

-- MAIN APPLICATION
addappid(475090)

-- MAIN APP DEPOTS / PACKAGES
addappid(475091, 1, "9f92d7dd60b1746d8a46d7d92e171e1141c39180464ebd8e4a7d09e8eb9d09ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
