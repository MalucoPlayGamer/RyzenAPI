-- Lua provided by RyzenAPI
-- Game: Oxenfree - OST

-- MAIN APPLICATION
addappid(433430)

-- MAIN APP DEPOTS / PACKAGES
addappid(433430,0,"21e3deebd082cf433e7dfe8f5bd0eddea4c92ae13ea20576515778257dfbd749")

