-- Lua provided by RyzenAPI
-- Game: 小小无常 Little Wu Chang

-- MAIN APPLICATION
addappid(1935400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935401, 1, "d9163b99ae775493f297bd9b9a73ebfdcfbd4f15793196987d858337527e2751")

