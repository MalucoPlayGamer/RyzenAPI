-- Lua provided by RyzenAPI
-- Game: addappid(1964380)

-- MAIN APPLICATION
addappid(1964380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964381, 1, "d085c1ed0c5fad0c82e671dae2dfec40e664b4061061edc04303fa273ac2efb5")
addappid(1964382, 1, "ae761b5337114538f302e11849eae447513caf2a80f8baecce0b94d5c6c94d43")
