-- Lua provided by RyzenAPI
-- Game: addappid(567340)

-- MAIN APPLICATION
addappid(567340)

-- MAIN APP DEPOTS / PACKAGES
addappid(567341, 1, "02b9358b2d2284388b253ba7f6174d18f7ef9ac6bcfb1a9404b616176e1d2a6a")
