-- Lua provided by RyzenAPI
-- Game: AppID 567340

-- MAIN APPLICATION
addappid(567340)

-- MAIN APP DEPOTS / PACKAGES
addappid(567341, 1, "02b9358b2d2284388b253ba7f6174d18f7ef9ac6bcfb1a9404b616176e1d2a6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
