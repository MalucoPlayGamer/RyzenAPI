-- Generated with Luie @ https://lua.tools/
-- 3189890 - Match & Mastery
-- Generated 2026-08-27 22:17:09 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3189890)
addtoken(3189890, "15097569399882305542")

-- Main Depots
addappid(3189891, 1, "84ea33b2dcdf43fd4076af2e2aacd1be0ec64c35e3309a2af099eac652bb13a8") -- (windows)
setManifestid(3189891, "2880675934342128252", 2682288147)
