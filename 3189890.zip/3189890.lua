-- Lua provided by RyzenAPI
-- Game: Match & Mastery

-- MAIN APPLICATION
addappid(3189890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3189891, 1, "84ea33b2dcdf43fd4076af2e2aacd1be0ec64c35e3309a2af099eac652bb13a8") -- (windows)
addtoken(3189890, "15097569399882305542")

