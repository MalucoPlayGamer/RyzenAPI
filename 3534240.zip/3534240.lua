-- Lua provided by RyzenAPI
-- Game: Uncanny Tales: Cold Road

-- MAIN APPLICATION
addappid(3534240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3534241, 1, "78e1e5688e3f90979552754a36f01f3e4a4b7a863737e677e9accc0275758fd8")

