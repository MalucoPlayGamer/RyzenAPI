-- Lua provided by RyzenAPI
-- Game: Fugitive Free Rider

-- MAIN APPLICATION
addappid(4147690)
addappid(4369210)
addappid(4370370)
addappid(4370380)
addappid(4370390)
addappid(4370400)

-- MAIN APP DEPOTS / PACKAGES
addappid(4147691,0,"eb687e09c43d7fa7104693b62d592f35e538a4fba4bb963f5d33dd28100afb0c")

