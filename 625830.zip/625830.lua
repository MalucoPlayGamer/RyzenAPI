-- Lua provided by RyzenAPI
-- Game: BattleSky VR

-- MAIN APPLICATION
addappid(625830)

-- MAIN APP DEPOTS / PACKAGES
addappid(625831, 1, "6500546bdf152ecd81e1b41e58e496ca75823a0f5302d138bea591e5314cabd1")

