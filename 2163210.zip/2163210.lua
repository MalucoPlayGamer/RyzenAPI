-- Lua provided by RyzenAPI
-- Game: The Archipelago Promise

-- MAIN APPLICATION
addappid(2163210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163211, 1, "4e2f698e9075467cb3fe6bed64a9ed6f86fca439b38e5016e6be59c55aaedde2")
