-- Lua provided by RyzenAPI
-- Game: addappid(3196460)

-- MAIN APPLICATION
addappid(3196460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196461, 1, "dc1b75717c148da0e70b613f13dd55d0392afcb203b8dbb86825801f4d1a84e8")
