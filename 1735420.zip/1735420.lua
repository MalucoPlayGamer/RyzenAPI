-- Lua provided by SkyAPI 
-- Game: Fake Hostel
addappid(1735420)
addappid(1735421, 1, "9b974c8b6d057f86cae094bf3b13132d07f8d3692db62fba5d6e28a85edf2b7b")
addappid(1756990, 0, "770c86f90c8b03b2923b147ada94aea58984980326d87cd9fd761448771a2bf3")
addappid(1757080, 0, "1afec6693244cd061fadbf6f2eb0c7f455850343ba9414c60077ee305dd84333")
