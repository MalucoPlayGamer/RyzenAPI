-- Lua provided by RyzenAPI
-- Game: Steel & Steam: Episode 1

-- MAIN APPLICATION
addappid(310450)

-- MAIN APP DEPOTS / PACKAGES
addappid(310451, 1, "42f38049197dcc1c82ef1f4e1c5cd431c3c0d63ff355a40db9b6786e51212ef8")

