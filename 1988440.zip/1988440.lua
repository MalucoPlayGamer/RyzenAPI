-- Lua provided by RyzenAPI
-- Game: Block Breaker 2

-- MAIN APPLICATION
addappid(1988440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988441, 1, "c85365bfd6035200d373c85c6f168be98922fa005c37dccdc08e15704e0515a3")
