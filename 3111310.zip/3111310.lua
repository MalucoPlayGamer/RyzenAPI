-- Lua provided by RyzenAPI
-- Game: 3111310

-- MAIN APPLICATION
addappid(3111310)
-- Game: addappid(3111310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111311, 1, "04431dabbb93b0406448d68b8236c6dc5ee27e9f44c387b0dcba4f2cda35888d")
