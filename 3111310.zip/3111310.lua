-- Lua provided by RyzenAPI
-- Game: FOOTAGE BODYCAM

-- MAIN APPLICATION
addappid(3111310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3111311, 1, "04431dabbb93b0406448d68b8236c6dc5ee27e9f44c387b0dcba4f2cda35888d")
