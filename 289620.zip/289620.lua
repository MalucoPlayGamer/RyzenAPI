-- Lua provided by RyzenAPI 
-- Game: Collapse
addappid(289620)
addappid(289621, 1, "4e645227ec4e46ce393988720f7fd38eea13c7a1a69f48044fed7fe30dd81797")
addappid(289622, 1, "3811c67bc7132484b4464bf83421113ebd282269ff1b18f3a81834d715425898")
