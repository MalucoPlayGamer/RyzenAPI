-- Lua provided by SkyAPI 
-- Game: PegIdle Demo
addappid(2890250)
addappid(2890251, 1, "6d00ec2040a22cba063d341b03ce564c90804a8aabd223c16738cdf87764fb36")
