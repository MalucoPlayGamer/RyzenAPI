-- Lua provided by RyzenAPI
-- Game: addappid(2890250)

-- MAIN APPLICATION
addappid(2890250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890251, 1, "6d00ec2040a22cba063d341b03ce564c90804a8aabd223c16738cdf87764fb36")
