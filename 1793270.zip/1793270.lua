-- Lua provided by SkyAPI 
-- Game: Conan Chop Chop Demo
addappid(1793270)
addappid(1793271, 1, "e215b2aed171a8e27566663d89d75d235483bdfcfde997b4750ab6c2e100bb80")
