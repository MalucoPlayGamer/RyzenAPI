-- Lua provided by RyzenAPI
-- Game: Goblins Keep Coming - Tower Defense

-- MAIN APPLICATION
addappid(739850)

-- MAIN APP DEPOTS / PACKAGES
addappid(739851, 1, "af631cb9f328caf80e1ec75b73c4ac0f7289687007b7a911c0ba7c87427ca890")

