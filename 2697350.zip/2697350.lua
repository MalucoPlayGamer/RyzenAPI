-- Lua provided by RyzenAPI
-- Game: AppID 2697350

-- MAIN APPLICATION
addappid(2697350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697351, 1, "6e998143c13fc3927e4f6b7fc1acc7aa866b859e43f3ac99fcb81dcd8007d14a")

