-- Lua provided by RyzenAPI
-- Game: Related

-- MAIN APPLICATION
addappid(1304640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1304641, 1, "7c54649937e4d7e1f7593e1c34fe1334b1be41fbe5bdc1a87b4a00498d5fa507")
addappid(1304642, 1, "e6e7735fc1bf3c24a687589035a07689f3253bac3df34a08c5cc634f017bf255")

