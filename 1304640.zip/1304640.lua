-- Lua provided by RyzenAPI
-- Game: Game: Related

-- MAIN APPLICATION
addappid(1304640)
-- Game: addappid(1304640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304641, 1, "7c54649937e4d7e1f7593e1c34fe1334b1be41fbe5bdc1a87b4a00498d5fa507")
addappid(1304642, 1, "e6e7735fc1bf3c24a687589035a07689f3253bac3df34a08c5cc634f017bf255")
