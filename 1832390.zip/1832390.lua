-- Lua provided by RyzenAPI
-- Game: Happy’s Humble Burger Farm: Seacoast Row (OST)

-- MAIN APPLICATION
addappid(1832390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832391, 1, "d0f93385cd4790e1d3336195c84f382b42ab86731ba2dd8cf99a2f8f996596f0")

