-- Lua provided by RyzenAPI
-- Game: Game: The Indigo Parallel Soundtrack

-- MAIN APPLICATION
addappid(2536440)
-- Game: addappid(2536440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536441, 1, "6b9aea6e50cdae79a63c8fc69e2f4ed890fec6103dbabc340749b32d8f501d3b")
