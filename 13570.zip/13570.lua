-- Lua provided by RyzenAPI
-- Game: Game: Tom Clancy's Splinter Cell Chaos Theory®

-- MAIN APPLICATION
addappid(13570)
-- Game: addappid(13570)

-- MAIN APP DEPOTS / PACKAGES
addappid(13571, 1, "f4af994be4acaafddf80fe38ed7af5833ac0b28a4a8a9c313b5746590f87c58c")
addappid(13572, 1, "c257b00a696f075cd515e41816d5505195d9985c5cdad3a80fc43ebdb97c28d2")
addappid(13573, 1, "0d8f1d12559fc0ab345ffa9d918a99d664819e384ee106d4125e38fd59a2ae45")
addappid(13574, 1, "b61e0918d55494ad570b7cfdd4d6582ec74219897c9a2f04a3ff41143e0808f4")
addappid(13575, 1, "686c2165692c3280c98aa469dd558c78a2ff5804abf583e6926afdb391af1967")
addappid(13576, 1, "3e89885c80304426b925eece5e33aba75bc33448ceac8ee9e6fad49e9069eeb3")
addappid(13577, 1, "1cfa73f6577503d20b9c206080638642c04f0dcf2e864881fec3cb88cc16b9b3")
addappid(13578, 1, "3437c90090bd12f40052c9d65179e7ee1e965b079f39c7c335574db0b7903c43")
