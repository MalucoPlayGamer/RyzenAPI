-- Lua provided by RyzenAPI
-- Game: Starseed Soundtrack Free Ep 2

-- MAIN APPLICATION
addappid(1643140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643141, 1, "a18d4afcc1c0af24e4a38f6a129f71fb6531c0e1daba361cb724c75482868a3b")

