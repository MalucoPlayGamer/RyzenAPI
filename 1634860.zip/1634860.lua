-- Lua provided by RyzenAPI
-- Game: 1634860

-- MAIN APPLICATION
addappid(1634860)
-- Game: addappid(1634860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634861, 1, "c62e73bcafbf331b264b4061c8e6d4dc5e6e6014ed8a9d2de860807ba7a8c4c4")
addappid(1634862, 1, "4e7a08e815ac4946b6470d4eb8731da108db4687fbf90b9d41182da0c0ebb4ed")
