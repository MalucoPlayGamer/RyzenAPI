-- Lua provided by RyzenAPI
-- Game: AppID 807920

-- MAIN APPLICATION
addappid(807920)
addappid(808050)
addappid(810300)
-- Game: addappid(807920)

-- MAIN APP DEPOTS / PACKAGES
addappid(807921, 1, "e47d600fdac5240a66c5aa7228d8c661b7db59d044bd9fad16e5a9f72e282d19")
