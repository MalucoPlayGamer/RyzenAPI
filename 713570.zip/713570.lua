-- Lua provided by RyzenAPI
-- Game: addappid(713570)

-- MAIN APPLICATION
addappid(713570)

-- MAIN APP DEPOTS / PACKAGES
addappid(713571, 1, "bf9f7f8fae8a6dd59730c90f74e6eb9c68cf72653464b532055fe5525d85fb78")
