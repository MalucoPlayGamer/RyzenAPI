-- Lua provided by RyzenAPI
-- Game: 394970

-- MAIN APPLICATION
addappid(394970)
-- Game: addappid(394970)

-- MAIN APP DEPOTS / PACKAGES
addappid(394971, 1, "86cb96a5e0d769c3cc051969ad34417d8b646df7b8e89a6019f5790cd7507acd")
