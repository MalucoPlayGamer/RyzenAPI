-- Lua provided by RyzenAPI
-- Game: DEADBOLT

-- MAIN APPLICATION
addappid(394970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394971, 1, "86cb96a5e0d769c3cc051969ad34417d8b646df7b8e89a6019f5790cd7507acd")

