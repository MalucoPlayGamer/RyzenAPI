-- Lua provided by RyzenAPI 
-- Game: Mathematics
addappid(2941740)
addappid(2941741, 1, "e8434ec7124c54656d323ca25ddaaf55f05466e0a60a0a255bbbdcd28c42674b")
