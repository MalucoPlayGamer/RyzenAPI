-- Lua provided by RyzenAPI
-- Game: True Love '95

-- MAIN APPLICATION
addappid(1094640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094641, 1, "b62581ba3a9dfb2fbfea51da433f4f70733bee669ebcbeb6b336352fca354f70")
addappid(1094700, 0, "3de491b11867e1d78c7cc6eb4b1a9576804b0912a6271ff34888e1e95da7323c")

