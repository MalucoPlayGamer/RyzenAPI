-- Lua provided by RyzenAPI
-- Game: Tribal Wars

-- MAIN APPLICATION
addappid(675690)

