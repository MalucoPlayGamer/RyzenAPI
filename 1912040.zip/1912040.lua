-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Honmaru Backdrop "Sakura Viewing - Nighttime"

-- MAIN APPLICATION
addappid(1912040)
-- Game: addappid(1912040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912040,0,"2806eee96999f5b2a96607bf661e39e88ec191bc5bf9f2a85bbaba3797fd0166")
