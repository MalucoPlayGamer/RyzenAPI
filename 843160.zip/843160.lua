-- Lua provided by RyzenAPI
-- Game: The Lift

-- MAIN APPLICATION
addappid(843160)
-- Game: addappid(843160)

-- MAIN APP DEPOTS / PACKAGES
addappid(843161, 1, "b383d25c7d93a5b164e5be2f831e7525458321c7b85b850340631664d57ef830")
