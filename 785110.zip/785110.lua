-- Lua provided by SkyAPI 
-- Game: AppID 785110
addappid(785110)
addappid(785111, 1, "c22520f7099732b40c003bc934d2d6796e87c9b327455066f377f535ed9426df")
