-- Lua provided by RyzenAPI
-- Game: Starship Traveller (Standalone)

-- MAIN APPLICATION
addappid(228985)
addappid(348180)
addappid(348181)
addappid(348182)

-- MAIN APP DEPOTS / PACKAGES
addappid(348183,0,"7373411b11d2351f375b4e6371192bf8d2e5827ae11679047c5638218d7fe220")

