-- Lua provided by RyzenAPI
-- Game: E.T. Armies

-- MAIN APPLICATION
addappid(382420)

-- MAIN APP DEPOTS / PACKAGES
addappid(382421, 1, "48a46f2f4c352046f071e4dc9f05fb679a53c171185a021f13f585b9d6d7eb6c")
