-- Lua provided by RyzenAPI
-- Game: Game: AppID 33130

-- MAIN APPLICATION
addappid(33130)
-- Game: addappid(33130)

-- MAIN APP DEPOTS / PACKAGES
addappid(33131, 1, "9d10e5ea033dbf88acb8a171faae5810f2bfbc02ff064c4b97dee1c37d17e860")
addappid(33132, 1, "01e18fa4a915d88e61817b331008136d62712db01e5ca74c9226d65bb18fde5a")
