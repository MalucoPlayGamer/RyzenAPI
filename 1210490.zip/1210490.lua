-- Lua provided by RyzenAPI
-- Game: addappid(1210490)

-- MAIN APPLICATION
addappid(1210490)
addappid(1210491)
addappid(1210493)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210492,0,"2faefc4389d552b0e6caa553142351b1011b67517ce5a1ba03f8d548bf018790")
