-- Lua provided by RyzenAPI
-- Game: 1375361

-- MAIN APPLICATION
addappid(1375361)
-- Game: addappid(1375361)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375361,0,"d1660e2cfe51af21e2c79a3d7a7bb634cd06d5d0e5bef6ad18e06e88a479ffc6")
