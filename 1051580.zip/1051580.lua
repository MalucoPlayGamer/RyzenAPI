-- Lua provided by RyzenAPI
-- Game: addappid(1051580)

-- MAIN APPLICATION
addappid(1051580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051581, 1, "264fd0da946f4b7f17a4c99a75afc3d09a842c94c6d0ee77025caf93f07c8f33")
