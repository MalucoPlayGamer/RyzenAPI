-- Lua provided by RyzenAPI 
-- Game: AppID 1077540
addappid(1077540)
addappid(1077541, 1, "92f848ad23365f9912d69f8858b2c8a23268c2eef754f2c23d8ca884fec6cda4")
