-- Lua provided by RyzenAPI
-- Game: The Deadly Tower of Monsters

-- MAIN APPLICATION
addappid(353700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(353701, 1, "f3e5b968cdddc02a8004d4990fb5ab48ca05ce3f651578f8830e94c4e9eba8f3")
addappid(353702, 1, "20f9dfb7b51eb404c80c1b7c4d0cbaf5ed7e5e60af59aa40c7bec47096c1093c")
addappid(353703, 1, "bd8cd552bb4fe49535c136d21f02cc59f441d34c95ac96018f7c2eaa8d7d4b9c")
addappid(353704, 1, "a92c903423eefc69e549317e7d3d553a77dd8ffaa8f6766c8706208139359943")
