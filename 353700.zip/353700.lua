-- Lua provided by RyzenAPI
-- Game: Game: AppID 353700

-- MAIN APPLICATION
addappid(353700)
-- Game: addappid(353700)

-- MAIN APP DEPOTS / PACKAGES
addappid(353701, 1, "f3e5b968cdddc02a8004d4990fb5ab48ca05ce3f651578f8830e94c4e9eba8f3")
addappid(353702, 1, "20f9dfb7b51eb404c80c1b7c4d0cbaf5ed7e5e60af59aa40c7bec47096c1093c")
addappid(353703, 1, "bd8cd552bb4fe49535c136d21f02cc59f441d34c95ac96018f7c2eaa8d7d4b9c")
addappid(353704, 1, "a92c903423eefc69e549317e7d3d553a77dd8ffaa8f6766c8706208139359943")
