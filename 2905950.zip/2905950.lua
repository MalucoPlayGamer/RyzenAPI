-- Lua provided by RyzenAPI
-- Game: Whispers of silence

-- MAIN APPLICATION
addappid(2905950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905951, 1, "cdc7840071434b165d26829418594b83e593e40c08d3cfed88d86580dac6f400")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
