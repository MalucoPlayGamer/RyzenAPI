-- Lua provided by RyzenAPI
-- Game: Game: Whispers of silence

-- MAIN APPLICATION
addappid(2905950)
-- Game: addappid(2905950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905951, 1, "cdc7840071434b165d26829418594b83e593e40c08d3cfed88d86580dac6f400")
