-- Lua provided by RyzenAPI
-- Game: 206480

-- MAIN APPLICATION
addappid(206480)
-- Game: addappid(206480)

-- MAIN APP DEPOTS / PACKAGES
addappid(206481, 1, "825b13c47e601e9e0fc6760d57339c7b135659274d209ebd215ac6c0ad99b26d")
addappid(206482, 1, "9d2988bdbbfccc3ee82cd64dd45a9b608fef38f4ce1776d07c73c7ec861c15da")
