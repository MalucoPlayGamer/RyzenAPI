-- Lua provided by RyzenAPI
-- Game: Poppy's Nightmare

-- MAIN APPLICATION
addappid(1132830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1132831, 1, "75e3ca9fecb48290d575e749f50499bcbf38557511387035f192fb7462702436")

