-- Lua provided by RyzenAPI
-- Game: Surface: Reel Life Collector's Edition

-- MAIN APPLICATION
addappid(586720)

-- MAIN APP DEPOTS / PACKAGES
addappid(586721,0,"a8edd3cc7887bbf398290a426acb135971794a2e0ae83a6fd2ca51785317db2d")

