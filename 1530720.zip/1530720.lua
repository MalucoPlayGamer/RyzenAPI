-- Lua provided by RyzenAPI 
-- Game: Sport Mode
addappid(1530720)
addappid(1530721, 1, "ff65664f35b153938baebe21f2a3db36cc1250a76848a8f1c38686ac6511b8a9")
