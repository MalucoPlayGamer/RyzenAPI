-- Lua provided by RyzenAPI
-- Game: Taishi Ci - Officer Ticket / 太史慈使用券

-- MAIN APPLICATION
addappid(956733)

-- MAIN APP DEPOTS / PACKAGES
addappid(956733,0,"c0c618e65156475cb227c92760466bd2dcaf3c59e3144d9a61298adcf72fa61f")

