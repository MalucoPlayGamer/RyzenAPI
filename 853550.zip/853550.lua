-- Lua provided by RyzenAPI
-- Game: addappid(853550)

-- MAIN APPLICATION
addappid(853550)
addappid(853551)
addappid(853552)
addappid(853554)

-- MAIN APP DEPOTS / PACKAGES
addappid(853553,0,"013dc530c164373cf797db88ecbb9a1da1a837e639a73aecc605e958af7b31a0")
