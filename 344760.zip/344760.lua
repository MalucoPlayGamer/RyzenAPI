-- Lua provided by RyzenAPI
-- Game: Reign Of Kings

-- MAIN APPLICATION
addappid(344760)

-- MAIN APP DEPOTS / PACKAGES
addappid(344761, 1, "552f512e7952332484cee4970163dcca1f753b50d718397558f532af5d4c7a11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
