-- Lua provided by RyzenAPI
-- Game: Game: Reign Of Kings

-- MAIN APPLICATION
addappid(344760)
-- Game: addappid(344760)

-- MAIN APP DEPOTS / PACKAGES
addappid(344761, 1, "552f512e7952332484cee4970163dcca1f753b50d718397558f532af5d4c7a11")
