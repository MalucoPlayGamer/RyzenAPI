-- Lua provided by RyzenAPI
-- Game: Editor's Hell

-- MAIN APPLICATION
addappid(2171750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171751, 1, "b3e0f816ac62f2888e5148c40d95f8c8ff95f240129582cf51c9f5aae5a79a25")

