-- Lua provided by RyzenAPI
-- Game: Street Fighter V

-- MAIN APPLICATION
addappid(425110) -- Street Fighter V - Season 1 Character Pass
addappid(439410) -- Chun-Li Battle Costume - Pre-purchase bonus
addappid(475230)
addappid(480520) -- Street Fighter V - Capcom Pro Tour 2016 Pack
addappid(480530) -- Street Fighter V - Season 2 Character Pass
addappid(480540) -- Street Fighter V - 2016 Holiday Pack
addappid(480550) -- Street Fighter V - Original Characters Battle Costume 1 Pack
addappid(590750) -- Street Fighter V - Capcom Pro Tour 2017 Premier Pass
addappid(691300) -- Street Fighter V - 2016 Summer Costume Bundle
addappid(700850) -- Street Fighter V - 2016 Halloween Costume Bundle
addappid(700851) -- Street Fighter V - 2017 Holiday Costume Bundle
addappid(750310) -- Street Fighter V - Season 3 Character Pass
addappid(780660) -- Bonus Costumes - GWP
addappid(789460) -- Street Fighter V - Capcom Pro Tour 2018 Premier Pass
addappid(863180) -- Street Fighter V - 2018 Summer Costume Bundle
addappid(863181) -- Street Fighter V - Monster Hunter Bundle
addappid(863182) -- Street Fighter V - Devil May Cry  Ghosts n Goblins Bundle
addappid(893320) -- Street Fighter V - 2017 Halloween Costume Bundle
addappid(893321) -- Street Fighter V - Darkstalkers Costume Bundle
addappid(906440) -- Street Fighter V - Sports Costumes Bundle
addappid(971240) -- Street Fighter V - Extra Battle CAPCOM LEGEND Bundle
addappid(971241) -- Street Fighter V - Story Costumes Bundle S1-S3
addappid(971242) -- Street Fighter V - Stages Bundle S1-S3
addappid(971243) -- Street Fighter V - Work Costumes Bundle
addappid(971250) -- Street Fighter V - School Costumes Bundle
addappid(971251) -- Street Fighter V - Nostalgia Costumes Bundle S1-S3
addappid(971252) -- Street Fighter V - Street Fighter 30th Anniversary Costumes Bundle
addappid(971260) -- Street Fighter V - Akiman Costumes Bundle
addappid(989970) -- Street Fighter V - Resident Evil Costume Bundle
addappid(995950) -- Street Fighter V - Capcom Pro Tour 2019 Premier Pass
addappid(1009400) -- Street Fighter V - Mech Costume Bundle
addappid(1025060) -- Street Fighter V - Ryu Costumes Bundle
addappid(1025061) -- Street Fighter V - Chun-Li Costumes Bundle
addappid(1060990) -- Street Fighter V - Cammy Costumes Bundle
addappid(1061020) -- Street Fighter V - Karin Costumes Bundle
addappid(1061030) -- Street Fighter V - R. Mika Costumes Bundle
addappid(1061040) -- Street Fighter V - Laura Costumes Bundle
addappid(1061050) -- Street Fighter V - Ken Costumes Bundle
addappid(1061060) -- Street Fighter V - Nash Costumes Bundle
addappid(1061070) -- Street Fighter V - Necalli Costumes Bundle
addappid(1075990) -- Street Fighter V - 2019 Summer Costume Bundle
addappid(1075991) -- Street Fighter V - Mega Man Costume Bundle
addappid(1075993) -- Street Fighter V - Summer 2019 Character Bundle
addappid(1075994) -- Street Fighter V - M. Bison Costume Bundle  
addappid(1075995) -- Street Fighter V - Zangief Costume Bundle
addappid(1075996) -- Street Fighter V - Birdie Costume Bundle
addappid(1075997) -- Street Fighter V - Vega Costume Bundle  
addappid(1075998) -- Street Fighter V - Rashid Costume Bundle
addappid(1075999) -- Street Fighter V - Dhalsim Costume Bundle
addappid(1076000) -- Street Fighter V - F.A.N.G Costume Bundle
addappid(1117540) -- Street Fighter V - Extra Battle CAPCOM LEGEND Bundle 2
addappid(1117541) -- Street Fighter V - 2018 Halloween Costume Bundle
addappid(1150190) -- Street Fighter V - Champion Edition Upgrade Kit
addappid(1150191) -- Street Fighter V - 2018 Holiday Costume Bundle
addappid(1150192) -- Street Fighter V - Extra Battle CAPCOM LEGEND Bundle 3
addappid(1150194) -- Street Fighter V - Season 4 Character Pass
addappid(1150195) -- Street Fighter V - Champion Edition Special Color
addappid(1172540)
addappid(1233100) -- Street Fighter V - Capcom Pro Tour 2020 Premier Pass
addappid(1405400) -- Street Fighter V - SFL2020 UYU Costumes Bundle
addappid(1405401) -- Street Fighter V - SFL2020 NASR Costumes Bundle
addappid(1473430) -- Street Fighter V - Season 5 Premium Pass
addappid(1474240)
addappid(1503030) -- Street Fighter V - Capcom Pro Tour 2021 Premier Pass
addappid(1825950) -- Street Fighter V - Capcom Pro Tour 2022 Premier Pass
-- addappid(310954) -- Depot 310954 (empty depot)
-- addappid(310955) -- Depot 310955 (empty depot)
-- addappid(425110) -- Depot 425110 (empty depot)
-- addappid(439410) -- Depot 439410 (empty depot)
-- addappid(444700)
-- addappid(807400)
-- addappid(807401)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(310950, 1, "178da158b2405aea95ef234f5a620320ba332d35d9f68c38f1224d2d49dbf8c3") -- Street Fighter V
addappid(310951, 1, "cde3f482aedb4b88421d61be7343f46674d5871746b189c56dc10b10ee3cada9") -- KIWI Content
addappid(310952, 1, "4a147f5a5cbd4194a6eed1dd029b5a5e4fe2289bd588b3523eb881b099363254") -- Street Fighter V Depot - Dev
addappid(310953, 1, "18d1e71626cb0a8e17e55bb098bedea9b4737fc4cb7e52081175c7e03af05c1e") -- Street Fighter V Depot - QA
addappid(444680, 1, "db42f16a2c7f575888338273f6a57333df09088a593c1f2ef1972d5e3bbe8052") -- Street Fighter V Original Soundtrack (444680) Depot
addappid(475230, 1, "d508e856e2373e136a7f87a1756386fcae717c758409c450ed7c7fbf4efdee3e") -- STREET FIGHTER V General Story A Shadow Falls - SFV - Cinematic Story Mode (475230) Depot
addappid(807290, 1, "736c56c0dc3b8d554a6301785f90ae2d9ddb41bd02062e39f28a2baedd80d96b") -- Street Fighter V: Arcade Edtion Original Soundtrack (MP3) (807290) Depot
addappid(1172540, 1, "654f536206ec0d43b2d537cca8c9c737ab400ab6978563f4045c0a1a73d3c226") -- Street Fighter V - Champion Edition Special Wallpapers - DLC201911_02 (1172540) デポ
addappid(1474240, 1, "02e28ddd341496a1e2d6911b524675379f2fd668b033e557317f82247463db73") -- Street Fighter V - Season 5 Special Wallpapers - DLC202101_02 (1474240) デポ
addtoken(780660, "2972272352757020185")
addtoken(1474240, "5674982419633990023")
-- addtoken(807400, "6494171694919082839")
-- addtoken(807401, "6237600527739894899")

