-- Lua provided by RyzenAPI
-- Game: Ghost 1.0

-- MAIN APPLICATION
addappid(463270)

-- MAIN APP DEPOTS / PACKAGES
addappid(463271, 1, "68b126a7ab77b2be96156f9d17c4341896c88652d4a78a183f7b9d900ae1b34e")
addappid(488750, 0, "b27a19df7a9bcf3e4ba6f3a810190acde8abb501b17c94b31ba45709f2158ef1")

