-- Lua provided by RyzenAPI
-- Game: WORLD END ECONOMiCA episode.01

-- MAIN APPLICATION
addappid(269250)
addappid(2209110)

-- MAIN APP DEPOTS / PACKAGES
addappid(269251, 1, "21f5d1961855024ee5c187cc298276a3cab34d004c22eca8894e1205076323a2")
addappid(269253, 1, "a16aacb161b1f02bdae31cfc830633e4b49547674150e32fcbc0bf6b42d0f39f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
