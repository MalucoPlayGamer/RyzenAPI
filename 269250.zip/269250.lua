-- Lua provided by RyzenAPI
-- Game: 269250

-- MAIN APPLICATION
addappid(269250)
addappid(2209110)
-- Game: addappid(269250)

-- MAIN APP DEPOTS / PACKAGES
addappid(269251, 1, "21f5d1961855024ee5c187cc298276a3cab34d004c22eca8894e1205076323a2")
addappid(269253, 1, "a16aacb161b1f02bdae31cfc830633e4b49547674150e32fcbc0bf6b42d0f39f")
