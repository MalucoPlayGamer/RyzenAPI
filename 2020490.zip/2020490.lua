-- Lua provided by RyzenAPI
-- Game: Game: 風色幻想2:Alive

-- MAIN APPLICATION
addappid(2020490)
-- Game: addappid(2020490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020491, 1, "23686196d2574576a2559dc61af80b9bc42fb05078587689591ac47538ce316e")
