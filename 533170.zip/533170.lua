-- Lua provided by RyzenAPI
-- Game: Don't Chat With Strangers

-- MAIN APPLICATION
addappid(533170)

-- MAIN APP DEPOTS / PACKAGES
addappid(533171, 1, "98fbc9981b41f8708fe08b539ff9e5bfa1d4bc57ba9cbd7a3af25b36df5e699c")
