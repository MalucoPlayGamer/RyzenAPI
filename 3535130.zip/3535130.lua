-- Lua provided by RyzenAPI
-- Game: To find her

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(3535130)
addappid(3535131)
addappid(3535134)
-- Game: addappid(3535130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3535135,0,"5324f321f49154a6eaee52425103daebc7854fd148879911d8ec579d1acf761c")
