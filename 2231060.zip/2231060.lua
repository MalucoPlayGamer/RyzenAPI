-- Lua provided by RyzenAPI
-- Game: addappid(2231060)

-- MAIN APPLICATION
addappid(2231060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231061, 1, "3fb6074b437e7ae48fe0525e661add8c3a3f1729b3f3683e91717c863ed96396")
