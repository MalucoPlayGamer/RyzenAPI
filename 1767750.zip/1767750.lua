-- Lua provided by RyzenAPI
-- Game: Wild Life Demo

-- MAIN APPLICATION
addappid(1767750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767751, 1, "248ad7baed6a4c0e069770318b696404c7462f13b1b4b8188c3e4b891450e0c6")

