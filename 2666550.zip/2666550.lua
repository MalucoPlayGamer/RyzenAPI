-- Lua provided by RyzenAPI
-- Game: Dead Season

-- MAIN APPLICATION
addappid(2666550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2666551, 1, "3c2ab5a52bca07344e60f821c3ee1fa89bed77cea722eb283422814e0860816c")

