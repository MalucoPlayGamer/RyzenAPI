-- Lua provided by RyzenAPI
-- Game: Dead Season

-- MAIN APPLICATION
addappid(2666550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666551, 1, "3c2ab5a52bca07344e60f821c3ee1fa89bed77cea722eb283422814e0860816c")

