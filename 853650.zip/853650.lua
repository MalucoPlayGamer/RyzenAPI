-- Lua provided by RyzenAPI
-- Game: Game: AppID 853650

-- MAIN APPLICATION
addappid(853650)
-- Game: addappid(853650)

-- MAIN APP DEPOTS / PACKAGES
addappid(853651, 1, "242b494f404e741e82c8e5c7f73f6ac9cbf5766348888cb8dec959fad34011a1")
