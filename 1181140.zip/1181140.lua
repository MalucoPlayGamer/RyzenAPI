-- Lua provided by RyzenAPI
-- Game: PerfectLover

-- MAIN APPLICATION
addappid(1181140)
addappid(1200360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181141, 1, "ec987ee5dfd51b9fcc2ac64d51ad4de16b43d25530ac3a49ed5f02225ba92a45")
