-- Lua provided by RyzenAPI
-- Game: Game: Sleep Stream

-- MAIN APPLICATION
addappid(2839200)
-- Game: addappid(2839200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839201, 1, "ca0db123c13773217ee265a74c1167238067308d8a641f80caf7e1ef6957e58b")
