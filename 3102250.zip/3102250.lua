-- Lua provided by RyzenAPI
-- Game: Kovoclak

-- MAIN APPLICATION
addappid(3102250)
-- Game: addappid(3102250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102253,0,"4626e1d4fdc017a6459059f824da676408f84d50cc00d5fb0b55ffcfe5518593")
