-- Lua provided by RyzenAPI
-- Game: AppID 683530

-- MAIN APPLICATION
addappid(683530)
-- Game: addappid(683530)

-- MAIN APP DEPOTS / PACKAGES
addappid(683531, 1, "88e40c40cd473ba997b45ad348ff64429ee9b6c1979a5237d4899f35c205aee0")
