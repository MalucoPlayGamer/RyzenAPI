-- Lua provided by RyzenAPI
-- Game: Re;Lord 1 ~The witch of Herfort and stuffed animals~

-- MAIN APPLICATION
addappid(788050)

-- MAIN APP DEPOTS / PACKAGES
addappid(788051, 1, "9fcddb49cb2587041ead765507d99943bf1f889b96304c416ca3f32369d20cb0")
addappid(990830, 0, "0763ad43e2b857522b820a46bba2229aff7bcfeb5e6b52e1c7250a3786672c27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
