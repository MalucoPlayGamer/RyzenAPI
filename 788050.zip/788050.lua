-- Lua provided by RyzenAPI
-- Game: Game: Re;Lord 1 ~The witch of Herfort and stuffed animals~

-- MAIN APPLICATION
addappid(788050)
-- Game: addappid(788050)

-- MAIN APP DEPOTS / PACKAGES
addappid(788051, 1, "9fcddb49cb2587041ead765507d99943bf1f889b96304c416ca3f32369d20cb0")
addappid(990830, 0, "0763ad43e2b857522b820a46bba2229aff7bcfeb5e6b52e1c7250a3786672c27")
