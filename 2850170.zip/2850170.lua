-- Lua provided by RyzenAPI
-- Game: addappid(2850170)

-- MAIN APPLICATION
addappid(2850170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850171, 1, "bc90cbc7945022fc801981cfde37942aa91f489031afc6f58536fb35d08eced4")
