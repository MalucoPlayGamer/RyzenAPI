-- Lua provided by RyzenAPI
-- Game: Veins of DARKNESS

-- MAIN APPLICATION
addappid(3549430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549431, 1, "de3df6d5f5cb1b719b90eb8a56347879e7cfc4a6d82193cf2d5d0bc8a800d4b0")
