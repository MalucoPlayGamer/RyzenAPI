-- Lua provided by RyzenAPI 
-- Game: AppID 794570
addappid(794570)
addappid(794571, 1, "e34eca97f762c957d975b3f43df303377d1ad1d043903cda1ec4588a5fb71085")
