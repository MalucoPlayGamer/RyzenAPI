-- Lua provided by RyzenAPI
-- Game: addappid(794570)

-- MAIN APPLICATION
addappid(794570)

-- MAIN APP DEPOTS / PACKAGES
addappid(794571, 1, "e34eca97f762c957d975b3f43df303377d1ad1d043903cda1ec4588a5fb71085")
