-- Lua provided by RyzenAPI
-- Game: addappid(2016120)

-- MAIN APPLICATION
addappid(2016120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016121, 1, "3ecfd1130fc888cf5cd7ee13d812fedaa5badf9e610b4c227cf556e6d150f9d9")
