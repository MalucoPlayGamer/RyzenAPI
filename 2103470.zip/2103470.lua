-- Lua provided by RyzenAPI
-- Game: Game: Republic of Pirates

-- MAIN APPLICATION
addappid(2103470)
-- Game: addappid(2103470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103471, 1, "83064d42e8372ad1c0d40277404906958b53d3c654b238d08e20c367feed5c09")
