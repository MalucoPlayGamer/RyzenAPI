-- 4135750's Lua and Manifest Created by Hubcap Manifest
-- FEED THE QUEEN
-- Created: June 14, 2026 at 12:50:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4135750, 1, "d8f245511333b126efef762707b77bb287a41f2dc22e8a3b14b7291e8b986020") -- FEED THE QUEEN
-- MAIN APP DEPOTS
addappid(4135751, 1, "665d325bfc990e5a2486dc2ffddfdf32882b349881f3ac9ccdddf9ef3709c4d5") -- Depot 4135751
-- setManifestid(4135751, "965981057178393631", 202086068)
addappid(4135752, 1, "e9a26f574c32a8602ddc11a676de6070126c59cfe6d3485927f30c3e677955c5") -- Depot 4135752
-- setManifestid(4135752, "7046699292959136937", 181130703)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4753140) -- FEED THE QUEEN - Supporter Pack