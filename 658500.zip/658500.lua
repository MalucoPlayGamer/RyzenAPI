-- Lua provided by RyzenAPI 
-- Game: AppID 658500
addappid(658500)
addappid(658501, 1, "bf6a15819a6f3267f2e4bc21b3610f5f5fc213dd67bd953ca8c7b7f232adf35c")
addappid(658502, 1, "63bc08ae18238dc8aa87f5949abb889c78e2307820f68eee5753c82cdbf82f3a")
addappid(942070)
