-- Lua provided by RyzenAPI
-- Game: Hammerwatch

-- MAIN APPLICATION
addappid(239070)

-- MAIN APP DEPOTS / PACKAGES
addappid(239071, 1, "1e6858a65a0c6be5c9abde08e6f9a1ccd39415f79a015c88f9cd52741da212c2")
addappid(239072, 1, "3baa1178583a47a027eaa8d5f3a9823207c32138eda8ac7161f85d91bb94d4f0")
addappid(239073, 1, "dd7db49c2f3138f9121c65a506f57e9a5be1da9241f99eed30048bcfa0f5dc22")
addappid(239074, 1, "eec868eb815d0ab014aa44e2151416f870deb7b81e6bde25d06273f4770a33c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
