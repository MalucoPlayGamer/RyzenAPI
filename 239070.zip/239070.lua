-- Lua provided by RyzenAPI
-- Game: Hammerwatch

-- MAIN APPLICATION
addappid(239070)
-- Game: addappid(239070)

-- MAIN APP DEPOTS / PACKAGES
addappid(239071, 1, "1e6858a65a0c6be5c9abde08e6f9a1ccd39415f79a015c88f9cd52741da212c2")
addappid(239072, 1, "3baa1178583a47a027eaa8d5f3a9823207c32138eda8ac7161f85d91bb94d4f0")
addappid(239073, 1, "dd7db49c2f3138f9121c65a506f57e9a5be1da9241f99eed30048bcfa0f5dc22")
addappid(239074, 1, "eec868eb815d0ab014aa44e2151416f870deb7b81e6bde25d06273f4770a33c0")
