-- Lua provided by RyzenAPI
-- Game: Hold on in the Dungeons

-- MAIN APPLICATION
addappid(3067790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3067791, 1, "46da67b563885b9e0e841018124420cf8d74207bfd52903007c62404655de1f0")
