-- Lua provided by RyzenAPI
-- Game: Game: Lovely Sex with Childhood Friend -An innocent girl becomes addicted to lewd play-

-- MAIN APPLICATION
addappid(3370460)
-- Game: addappid(3370460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3370461, 1, "3b64166aa24ce934dc47a4c177a3b4dbf9dd53068715f6ee784515245a65281b")
