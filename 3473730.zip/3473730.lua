-- Lua provided by RyzenAPI
-- Game: addappid(3473730)

-- MAIN APPLICATION
addappid(3473730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473730,0,"2e35b63aaefb57459672f9c1fd76cfd6bdb1ee99efc3e6ae91793694ff48a909")
