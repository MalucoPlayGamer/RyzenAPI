-- Lua provided by RyzenAPI
-- Game: Risk of Rain 2 Soundtrack

-- MAIN APPLICATION
addappid(1236890)
-- Game: addappid(1236890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236891, 1, "eea0afe4967df8f08eb94bba9f0563a39e97c260f345c73cf1f16ac87e87627a")
addappid(1236892, 1, "12eab3fd4e783ddc2fdd8a8d59379945449056e08ba6be0d9b8b9965e75044f5")
