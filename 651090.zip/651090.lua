-- Lua provided by RyzenAPI
-- Game: Aces High III

-- MAIN APPLICATION
addappid(651090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(651091, 1, "bbc9b7b154a42a1fd4ca84466dcd2fd351b24e8ec70e39be5a696fa9427a2eb3")

