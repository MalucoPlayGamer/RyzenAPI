-- Lua provided by RyzenAPI 
-- Game: AppID 651090
addappid(651090)
addappid(651091, 1, "bbc9b7b154a42a1fd4ca84466dcd2fd351b24e8ec70e39be5a696fa9427a2eb3")
