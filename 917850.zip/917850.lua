-- Lua provided by RyzenAPI 
-- Game: Elemental War - A Tower Defense Game
addappid(917850)
addappid(917851, 1, "85e882fef61feb2be1aeffba26ccad4ce625d63b86d31ba029af0464912c55a1")
