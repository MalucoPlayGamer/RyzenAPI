-- Lua provided by RyzenAPI
-- Game: Game: AppID 371190

-- MAIN APPLICATION
addappid(371190)
-- Game: addappid(371190)

-- MAIN APP DEPOTS / PACKAGES
addappid(371191, 1, "eb1bdcc5b2239581d3f7adf29fabbcaaf7e1bf98187b871d1dae03d4bddba0fd")
