-- Lua provided by RyzenAPI
-- Game: Making History: The Calm and the Storm Gold Edition

-- MAIN APPLICATION
addappid(371190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(371191, 1, "eb1bdcc5b2239581d3f7adf29fabbcaaf7e1bf98187b871d1dae03d4bddba0fd")

