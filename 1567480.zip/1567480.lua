-- Lua provided by SkyAPI 
-- Game: Realtime Mining Simulator
addappid(1567480)
addappid(1567481, 1, "9f262d2861e3f00c2de2c7aa723416c41fee5483cb55d2863fceb5b848f9b2da")
