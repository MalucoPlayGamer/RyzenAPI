-- Lua provided by RyzenAPI
-- Game: Game: Realtime Mining Simulator

-- MAIN APPLICATION
addappid(1567480)
-- Game: addappid(1567480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567481, 1, "9f262d2861e3f00c2de2c7aa723416c41fee5483cb55d2863fceb5b848f9b2da")
