-- Lua provided by RyzenAPI
-- Game: The Protagonish

-- MAIN APPLICATION
addappid(2994780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994782,0,"eab490355898a8670ba1431ba5a1f5684975054ca0312541f595be85cecc3c07")

