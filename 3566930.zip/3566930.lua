-- Lua provided by RyzenAPI
-- Game: My Pet Femboy

-- MAIN APPLICATION
addappid(3566930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3566931, 1, "d7e5feaba13dfe56b99abff60991855b101bebfaf80803e9c6a9438980c45b50")

