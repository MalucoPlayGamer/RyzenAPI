-- Lua provided by RyzenAPI
-- Game: Game: AppID 708300

-- MAIN APPLICATION
addappid(708300)
-- Game: addappid(708300)

-- MAIN APP DEPOTS / PACKAGES
addappid(708301, 1, "f4efef64afc1d21d49d996a8567fd85620954442fdf055dda58d82f60162152e")
