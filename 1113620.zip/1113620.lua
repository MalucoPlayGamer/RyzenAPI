-- Lua provided by RyzenAPI
-- Game: Transparent Taskbar

-- MAIN APPLICATION
addappid(1113620)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1113621, 1, "c9444b2ee03091c3b02c13cf1f8695b38e1aaaf4cc46fe8272377d162510ce50")

