-- Lua provided by RyzenAPI 
-- Game: Transparent Taskbar
addappid(1113620)
addappid(1113621, 1, "c9444b2ee03091c3b02c13cf1f8695b38e1aaaf4cc46fe8272377d162510ce50")
