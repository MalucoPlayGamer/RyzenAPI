-- Lua provided by RyzenAPI
-- Game: 3284700

-- MAIN APPLICATION
addappid(3284700)
-- Game: addappid(3284700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284701, 1, "95df2d8ad089da4ea919510425bc184f02fdfa80d960b1855bdaf6c03ed59706")
