-- Lua provided by RyzenAPI
-- Game: Game: Escape Game Fort Boyard

-- MAIN APPLICATION
addappid(1303140)
addappid(1580220)
-- Game: addappid(1303140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303141, 1, "f125c2f8cf2da0a2d1923f682db38e60497b6edf0a5625b67f70590d0aca502a")
addappid(1303143, 1, "f6dc8eea061851fa87c5fe3a3ab08f460ba7ccb8b12285cbf4e15ec6a4e17517")
