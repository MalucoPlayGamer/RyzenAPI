-- Lua provided by RyzenAPI
-- Game: 1459730

-- MAIN APPLICATION
addappid(1459730)
-- Game: addappid(1459730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459732,0,"501118f901333c544d0464d4ec79f52d8261374c1b75e3cdeeb984b1bf12cbaa")
