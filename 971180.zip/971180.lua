-- Lua provided by RyzenAPI
-- Game: AppID 971180

-- MAIN APPLICATION
addappid(971180)
-- Game: addappid(971180)

-- MAIN APP DEPOTS / PACKAGES
addappid(971181, 1, "529c23f7d4fe15962feb5b3e959c749f0138f70c85234a01a2a7ef5dda599a09")
