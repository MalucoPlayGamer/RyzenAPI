-- Lua provided by RyzenAPI
-- Game: 8bit Arena

-- MAIN APPLICATION
addappid(971180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(971181, 1, "529c23f7d4fe15962feb5b3e959c749f0138f70c85234a01a2a7ef5dda599a09")

