-- Lua provided by RyzenAPI
-- Game: Confronted

-- MAIN APPLICATION
addappid(2882610)
addappid(4338590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2882611, 1, "77bb699ee2ac995d1f3dbc1b1944376afc8206e199ff52046efbd82dfd07b382")

