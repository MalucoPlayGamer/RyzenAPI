-- Lua provided by RyzenAPI
-- Game: Game: Confronted

-- MAIN APPLICATION
addappid(2882610)
-- Game: addappid(2882610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882611, 1, "77bb699ee2ac995d1f3dbc1b1944376afc8206e199ff52046efbd82dfd07b382")
