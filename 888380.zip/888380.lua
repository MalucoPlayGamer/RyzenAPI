-- Lua provided by RyzenAPI
-- Game: AppID 888380

-- MAIN APPLICATION
addappid(888380)

-- MAIN APP DEPOTS / PACKAGES
addappid(888381, 1, "f6b9c4a5e06dea53b6c7d184b0092b2bd5208a083d5da7fb7decf0084c6ac08a")
