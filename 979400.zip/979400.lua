-- Lua provided by RyzenAPI
-- Game: Game: AppID 979400

-- MAIN APPLICATION
addappid(979400)
-- Game: addappid(979400)

-- MAIN APP DEPOTS / PACKAGES
addappid(979401, 1, "8c596faf6c0d7f9ab81ac3ad31de4b6de19f8339fb6a0553db7e52a5cdf56a1f")
