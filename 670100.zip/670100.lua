-- Lua provided by SkyAPI 
-- Game: Mint
addappid(670100)
addappid(670101, 1, "f46c78205cf9f4e658f7eff0699360680f62597494d33e8e9fd769a781accc23")
addappid(670102, 1, "c16bc70865fdf40ffc62a6d1e460d36e3eabb71177d0881483a3d9146539e40d")
