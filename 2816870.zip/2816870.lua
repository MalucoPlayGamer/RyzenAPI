-- Lua provided by RyzenAPI
-- Game: Game: Mighty Morphin Power Rangers: Rita's Rewind

-- MAIN APPLICATION
addappid(2816870)
-- Game: addappid(2816870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816871, 1, "2ed04d14119e881ddae844e72f279d733598e42712dcd3e2028e563b7d539a4a")
