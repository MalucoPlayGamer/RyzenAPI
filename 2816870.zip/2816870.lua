-- Lua provided by RyzenAPI
-- Game: Mighty Morphin Power Rangers: Rita's Rewind

-- MAIN APPLICATION
addappid(2816870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2816871, 1, "2ed04d14119e881ddae844e72f279d733598e42712dcd3e2028e563b7d539a4a")

