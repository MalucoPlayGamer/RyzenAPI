-- Lua provided by RyzenAPI
-- Game: Warhammer: Chaosbane

-- MAIN APPLICATION
addappid(774241)
-- Game: addappid(774241)

-- MAIN APP DEPOTS / PACKAGES
addappid(774242, 1, "a7b08c2770074f79efe6018ff609cb56c67e12554b2db95f85f05678f1d5788e")
addappid(1455550, 0, "361759d8e0d96348724ed7c736924bb97056356a9733fe20d294393233a964b2")
