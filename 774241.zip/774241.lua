-- Lua provided by RyzenAPI
-- Game: Warhammer: Chaosbane

-- MAIN APPLICATION
addappid(774241)

-- MAIN APP DEPOTS / PACKAGES
addappid(774242, 1, "a7b08c2770074f79efe6018ff609cb56c67e12554b2db95f85f05678f1d5788e")
addappid(1455550, 0, "361759d8e0d96348724ed7c736924bb97056356a9733fe20d294393233a964b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1004910)
addappid(1004911)
addappid(1004912)
addappid(1004913)
addappid(1004914)
addappid(1004915)
addappid(1004916)
addappid(1004917)
addappid(1004918)
addappid(1004919)
addappid(1081970)
addappid(1157540)
addappid(1396230)
