-- Lua provided by RyzenAPI
-- Game: addappid(510000)

-- MAIN APPLICATION
addappid(510000)

-- MAIN APP DEPOTS / PACKAGES
addappid(510001, 1, "cb143f72b00dfc2031a1cb99e64a25dad86b9a544474e3b91e762b4c4005e5e9")
