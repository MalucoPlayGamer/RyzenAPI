-- Lua provided by RyzenAPI
-- Game: Xecryst Remains

-- MAIN APPLICATION
addappid(510000)

-- MAIN APP DEPOTS / PACKAGES
addappid(510001, 1, "cb143f72b00dfc2031a1cb99e64a25dad86b9a544474e3b91e762b4c4005e5e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
