-- Lua provided by RyzenAPI
-- Game: VillageRhapsody

-- MAIN APPLICATION
addappid(2109460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109461, 1, "f77ae6d25c175811951ff2fb68f85fb653d802e950393094175b1f84598999a1")
addappid(2179250, 0, "f5a7fa1b530cd3dc9345d00c4222701be82991ddaff54d552c7fa29915bfd428")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
