-- Lua provided by RyzenAPI
-- Game: VillageRhapsody

-- MAIN APPLICATION
addappid(2109460)
-- Game: addappid(2109460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109461, 1, "f77ae6d25c175811951ff2fb68f85fb653d802e950393094175b1f84598999a1")
addappid(2179250, 0, "f5a7fa1b530cd3dc9345d00c4222701be82991ddaff54d552c7fa29915bfd428")
