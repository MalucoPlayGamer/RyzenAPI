-- Lua provided by RyzenAPI
-- Game: addappid(2292490)

-- MAIN APPLICATION
addappid(2292490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292491, 1, "21aebcb4596ed37b3c2e3a5a198f6ef1f1941dc69388596e9c528e1182abd2ec")
