-- Lua provided by RyzenAPI
-- Game: 3720510

-- MAIN APPLICATION
addappid(3720510)
-- Game: addappid(3720510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720511, 1, "a468cc2419bd18eb32df407162dc3a319f508dbbbfe5190e06370ccf5fb4b14e")
