-- Lua provided by RyzenAPI
-- Game: Game: Soulbind: Prologue

-- MAIN APPLICATION
addappid(2850630)
-- Game: addappid(2850630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850631, 1, "6bc8fa4ad2989f11f4bc9ec337ab1799190ed84d2d6b1174af01efc08b713287")
addappid(2850632, 1, "da2abb8bc741d9d05d5706e2ea29e64b548c2654659d4263ad8a118165e049b3")
