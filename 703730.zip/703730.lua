-- Lua provided by RyzenAPI
-- Game: Sorcery Jokers All Ages Version

-- MAIN APPLICATION
addappid(703730)

-- MAIN APP DEPOTS / PACKAGES
addappid(703731,0,"fb603e0bd68140c76926e58384cc3363d437b52fccfde3a185bacb77179baeab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
