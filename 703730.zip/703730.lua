-- Lua provided by RyzenAPI
-- Game: Sorcery Jokers All Ages Version

-- MAIN APPLICATION
addappid(703730)

-- MAIN APP DEPOTS / PACKAGES
addappid(703731,0,"fb603e0bd68140c76926e58384cc3363d437b52fccfde3a185bacb77179baeab")

