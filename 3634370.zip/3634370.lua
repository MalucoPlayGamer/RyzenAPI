-- Lua provided by RyzenAPI
-- Game: Sad Virus

-- MAIN APPLICATION
addappid(3634370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3634371,0,"d0a0f048eb95561df5f8eef2ebab52c4d321bf90b9ee7c7ef98c9ebfac6832ae")

