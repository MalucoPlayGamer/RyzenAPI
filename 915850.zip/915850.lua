-- Lua provided by RyzenAPI
-- Game: Game: Super Hiking League DX

-- MAIN APPLICATION
addappid(915850)
-- Game: addappid(915850)

-- MAIN APP DEPOTS / PACKAGES
addappid(915851, 1, "dfbc504595fa09b8d84db0eab1a3f72af17eacde2bcabc694a4e229069af6a18")
