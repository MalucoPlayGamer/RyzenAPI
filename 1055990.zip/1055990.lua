-- Lua provided by RyzenAPI
-- Game: Erannorth Reborn

-- MAIN APPLICATION
addappid(1055990)
-- Game: addappid(1055990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055991, 1, "f23ef1533fc65649098b0a73403db098fe57ab941040c10d93dde6fd99935b5e")
addappid(1208660, 0, "be3b3abd7f49c836f1bf64736b408e6b32f3600dcbe3ac1acc5a06e084448ffb")
addappid(1239130, 0, "ec2e474b9de34daeadf1367502e890708492ae2a4a9fff5e50e5aa530222ac32")
addappid(1301870, 0, "034f340cef65dda5caed85131717dc326f2891521444559cc1adbef0a84e3d3b")
addappid(1473810, 0, "fd831a8ab408f80d74f76ee9384d6872bf0fef3eb5fb3a3c136b76e83c474590")
