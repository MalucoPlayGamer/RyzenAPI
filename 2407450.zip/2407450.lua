-- Lua provided by RyzenAPI
-- Game: 2407450

-- MAIN APPLICATION
addappid(2407450)
-- Game: addappid(2407450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407452,0,"0bdbeb37310ceaed82f7e88119cee8d6a15c16a4a3d4c35098c85352bb5a2669")
