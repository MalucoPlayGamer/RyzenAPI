-- Lua provided by RyzenAPI
-- Game: In The Foundations

-- MAIN APPLICATION
addappid(3580630)
addappid(3592610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3580631, 1, "8dfcdb94a3057f313eb01aa6402d0276b1a4146200b31665d4dd70b6a903072b")

