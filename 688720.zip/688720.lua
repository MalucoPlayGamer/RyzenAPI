-- Lua provided by RyzenAPI
-- Game: addappid(688720)

-- MAIN APPLICATION
addappid(688720)

-- MAIN APP DEPOTS / PACKAGES
addappid(688721, 1, "5fdf18ec55e78a5c75982ef94d857b51482211c0924ca9d0ea91eb5d86456d2c")
