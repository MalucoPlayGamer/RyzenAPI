-- Lua provided by RyzenAPI
-- Game: Sylvio: Black Waters

-- MAIN APPLICATION
addappid(2531300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531301, 1, "e8b26fbf661f74528b081da4b9ad5bac64329986b2a7fb925c6fb20be186cdf2")
