-- Lua provided by RyzenAPI 
-- Game: BIAS
addappid(1631140)
addappid(1631141, 1, "5c495d20e0b3a214df354bcbe8d7e62a96b57e802404e8708f3b007f93143524")
