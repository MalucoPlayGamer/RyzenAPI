-- Lua provided by RyzenAPI 
-- Game: AppID 2651220
addappid(2651220)
addappid(2651221, 1, "42fd16bc9ac3d9cc79dfb35e210f8f74a2c158a28fe6098148484a5144d20897")
