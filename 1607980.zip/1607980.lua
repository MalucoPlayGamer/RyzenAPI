-- Lua provided by RyzenAPI 
-- Game: School For The Friendless
addappid(1607980)
addappid(1607981, 1, "d0c64e25e16be7b4f5fadebeea7488eb718d095db9ae8320094da7378eb35e82")
