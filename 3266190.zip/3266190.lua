-- Lua provided by RyzenAPI
-- Game: Game: AppID 3266190

-- MAIN APPLICATION
addappid(3266190)
-- Game: addappid(3266190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266191, 1, "b8b6a315dc6cb5171343d0187a892562c34a49bf999e9c1fa09271217ed361f1")
