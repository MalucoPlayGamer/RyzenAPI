-- Lua provided by RyzenAPI
-- Game: AppID 918900

-- MAIN APPLICATION
addappid(918900)

-- MAIN APP DEPOTS / PACKAGES
addappid(918901, 1, "a509b4209c9ab188c8a6f08a6e040a6ea4a8e69bd197a0d2b79bcedcac618ccc")

