-- Lua provided by RyzenAPI
-- Game: Lil Tanks

-- MAIN APPLICATION
addappid(495820)
addappid(619980)

-- MAIN APP DEPOTS / PACKAGES
addappid(495821, 1, "21039f32f54b54fcd2706fc31d78833982cf088c22cd07b54a76794e2f85a41f")

