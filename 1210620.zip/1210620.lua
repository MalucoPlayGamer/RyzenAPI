-- Lua provided by SkyAPI 
-- Game: lil' Sherman
addappid(1210620)
addappid(1210621, 1, "2ccfc3502114b19f2166cc61ae4d20f625dc3c6142d0f4cb25c4c60cd6c373ba")
