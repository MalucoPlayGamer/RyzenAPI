-- Lua provided by RyzenAPI
-- Game: addappid(1476700)

-- MAIN APPLICATION
addappid(1476700)
addappid(1476701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476700,0,"8cf23360356ad072a5a178d8d073f98c42ec8c69d7b940d98eb42ae94975b75b")
