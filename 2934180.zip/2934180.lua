-- Lua provided by RyzenAPI
-- Game: addappid(2934180)

-- MAIN APPLICATION
addappid(2934180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934181, 1, "2165efcdf4e74ce23492cea660fad6562b6f9889bfd16b1e6eef4f8b62f7e467")
