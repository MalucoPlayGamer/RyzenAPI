-- Lua provided by RyzenAPI
-- Game: Mutant Storm: Reloaded

-- MAIN APPLICATION
addappid(110630)

-- MAIN APP DEPOTS / PACKAGES
addappid(110631, 1, "62c2969da075c9f87661476357be9878687f1415d95c681b028f1d298aa2290b")

