-- Lua provided by RyzenAPI
-- Game: Game: Unsealed: The Mare

-- MAIN APPLICATION
addappid(3492710)
-- Game: addappid(3492710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492711, 1, "dabea2090f7d130622cf7b8b3964f155f93680bcc9bc45245cd5f5c9fa18f4b3")
