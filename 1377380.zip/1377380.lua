-- Lua provided by RyzenAPI 
-- Game: Night of the Dead
addappid(1377380)
addappid(1377381, 1, "6addb8dd08b6d64b9aa384474d0208f9121b2d32289af430eb93a7c200fac05c")
