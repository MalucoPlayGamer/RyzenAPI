-- Lua provided by RyzenAPI
-- Game: Night of the Dead

-- MAIN APPLICATION
addappid(1377380)
addappid(2635010)
addappid(2778020)
addappid(2778030)
addappid(2778040)
addappid(2778050)
addappid(2876890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1377381, 1, "6addb8dd08b6d64b9aa384474d0208f9121b2d32289af430eb93a7c200fac05c")

