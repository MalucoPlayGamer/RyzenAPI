-- Lua provided by RyzenAPI
-- Game: AppID 493070

-- MAIN APPLICATION
addappid(493070)

-- MAIN APP DEPOTS / PACKAGES
addappid(493071, 1, "62e1a518fba65462826ea59943e0fd9de0a238f87dbfcc3ffe723678d836fe13")

