-- Lua provided by RyzenAPI
-- Game: Greedland

-- MAIN APPLICATION
addappid(2218400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218401, 1, "50ce9e04af153be16d359d90ff3f2cc322ab4f88e8407139c48e34e6d6477091")
