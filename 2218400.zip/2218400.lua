-- Lua provided by RyzenAPI
-- Game: Greedland

-- MAIN APPLICATION
addappid(2218400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218401, 1, "50ce9e04af153be16d359d90ff3f2cc322ab4f88e8407139c48e34e6d6477091")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
