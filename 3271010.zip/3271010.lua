-- Lua provided by RyzenAPI
-- Game: Tearscape Demo

-- MAIN APPLICATION
addappid(3271010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271011, 1, "10c438509321d21f3be5a36933b2b0f6434672c31190d8b75ff3d59641e9eebb")
