-- Generated with Luie @ https://lua.tools/
-- 2312370 - Bloodcrave
-- Generated 2026-08-27 22:13:01 UTC
-- # Depots (Total/DLC/Shared): 3/0/0

-- Main AppID
addappid(2312370)

-- Main Depots
addappid(2312371, 1, "607c09c4b3d391fe45022eea31621150809cbdd69d9ce4607af75957db080f0b") -- (windows)
setManifestid(2312371, "862537362706692999", 7466774124)

-- Missing Depots (We don't have the keys yet lol): 2312372, 2312373
