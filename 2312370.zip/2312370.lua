-- Lua provided by RyzenAPI
-- Game: Bloodcrave

-- MAIN APPLICATION
addappid(2312370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312371, 1, "607c09c4b3d391fe45022eea31621150809cbdd69d9ce4607af75957db080f0b") -- (windows)

