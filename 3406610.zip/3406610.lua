-- Lua provided by RyzenAPI
-- Game: Teleport Master

-- MAIN APPLICATION
addappid(3406610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3406611, 1, "2f8ad3405ed9f5d60841fae510b75cd2742368c0a92b5163425585b15b0ce085")

