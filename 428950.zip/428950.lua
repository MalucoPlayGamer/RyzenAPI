-- Lua provided by RyzenAPI
-- Game: AppID 428950

-- MAIN APPLICATION
addappid(428950)

-- MAIN APP DEPOTS / PACKAGES
addappid(428951, 1, "fa2936874f1e33ed8afa0caf1f4dca3d3ea5878aceb9d10a5b89fe22dea81475")

