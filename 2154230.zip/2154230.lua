-- Lua provided by RyzenAPI
-- Game: AI: Art Impostor

-- MAIN APPLICATION
addappid(2154230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154231, 1, "481fa14ce0fcf3cf9ed41aa0e955fd1070d926b7efbb9c96fc00b6b69a78ece2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
