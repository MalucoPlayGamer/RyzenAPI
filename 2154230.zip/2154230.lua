-- Lua provided by RyzenAPI
-- Game: AI: Art Impostor

-- MAIN APPLICATION
addappid(2154230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154231, 1, "481fa14ce0fcf3cf9ed41aa0e955fd1070d926b7efbb9c96fc00b6b69a78ece2")

