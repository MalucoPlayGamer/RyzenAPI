-- Lua provided by RyzenAPI
-- Game: Coin Flipper

-- MAIN APPLICATION
addappid(2153770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153771, 1, "366241e522fa64071b93a5a06a443ce591eae02d0d65841fb04e5d3d95badf4c")
