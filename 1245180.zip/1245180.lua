-- Lua provided by RyzenAPI 
-- Game: Marco & The Galaxy Dragon - Soundtrack
addappid(1245180)
addappid(1245181, 1, "4af8ba975c572619b7502bf8d35a26a9c204bfd02e0e923dd9f22345b8e65fe8")
