-- Lua provided by RyzenAPI
-- Game: Flora & Fang: Guardians of the vampire garden Soundtrack

-- MAIN APPLICATION
addappid(3593160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593161, 1, "d759896329bd51af09e66d7c258a86729c984de839cbf485be33912e23f1fd60")
addappid(3593162, 1, "1ca27e7c66aebedf44025e8ce59eca38a79f9ce9390c58903b4f2a9238a66595")
