-- Lua provided by RyzenAPI
-- Game: 1761410

-- MAIN APPLICATION
addappid(1761410)
-- Game: addappid(1761410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761411, 1, "a5355a298092c80b069f1653140cb3b5dd010f1cdc24a55e663e1820cbc43f27")
