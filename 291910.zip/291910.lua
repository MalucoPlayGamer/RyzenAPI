-- Lua provided by RyzenAPI
-- Game: Game: Firefighters 2014

-- MAIN APPLICATION
addappid(291910)
-- Game: addappid(291910)

-- MAIN APP DEPOTS / PACKAGES
addappid(291911, 1, "5c7a90c14908a4216d0da9e5a0421913257da3dc79d8df4f12b3e3eb10b6d8ea")
