-- Lua provided by RyzenAPI
-- Game: addappid(2020510)

-- MAIN APPLICATION
addappid(2020510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020511, 1, "a53d768b96871be60c96ac107f4c04d8cd277b3566e0b907c33c6ccef31ecde6")
