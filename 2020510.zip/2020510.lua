-- Lua provided by RyzenAPI
-- Game: 風色幻想4:聖戰的終焉

-- MAIN APPLICATION
addappid(2020510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2020511, 1, "a53d768b96871be60c96ac107f4c04d8cd277b3566e0b907c33c6ccef31ecde6")

