-- Lua provided by SkyAPI 
-- Game: AppID 433100
addappid(433100)
addappid(433101, 1, "4211efcc1149e6963a9321d71febf71802804be1225d9c6c4091f38951b5d56e")
addappid(444040, 0, "6c914cf33948d487155baba7fb356f03f473676c92912ef8cbd42dc7ba2fdfa2")
