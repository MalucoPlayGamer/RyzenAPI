-- Lua provided by RyzenAPI
-- Game: addappid(571340)

-- MAIN APPLICATION
addappid(571340)

-- MAIN APP DEPOTS / PACKAGES
addappid(571341, 1, "4cfce5bfabd700d149fa462482012bb143cc547c1fc81d617f489e195cf9f278")
