-- Lua provided by RyzenAPI
-- Game: Parkour

-- MAIN APPLICATION
addappid(691220)

-- MAIN APP DEPOTS / PACKAGES
addappid(691221, 1, "bb96f8b47b20f94c9550a8f4aa7455aa2294647b77b072aa05e569933de2301b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
