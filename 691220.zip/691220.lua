-- Lua provided by RyzenAPI
-- Game: Game: Parkour

-- MAIN APPLICATION
addappid(691220)
-- Game: addappid(691220)

-- MAIN APP DEPOTS / PACKAGES
addappid(691221, 1, "bb96f8b47b20f94c9550a8f4aa7455aa2294647b77b072aa05e569933de2301b")
