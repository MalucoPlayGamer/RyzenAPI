-- Lua provided by RyzenAPI
-- Game: 1054340

-- MAIN APPLICATION
addappid(1054340)
-- Game: addappid(1054340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054343,0,"4efe0bffdf844c23fbf60061afa69547439662ff4d4a8de6e9be0542202f9b90")
