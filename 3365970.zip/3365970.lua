-- Lua provided by RyzenAPI
-- Game: Love Goal

-- MAIN APPLICATION
addappid(3365970)
-- Game: addappid(3365970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365971, 1, "f8dcc5588617b1ceea360dec0b567097e4994440f2d1b30312df77429fbb3951")
