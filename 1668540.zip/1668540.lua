-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails into Reverie

-- MAIN APPLICATION
addappid(1668540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668541, 1, "5b330d401f149ce6072096ee064b6a32eba8dc54a983ccfdb75c252551980827")
addappid(2434460, 0, "9d17c5d36dd82e793d40fbc15e04f2fd5fac86ef93976e783a16891267028ef9")
addappid(2434461, 0, "88b607da911ff60fc864703740c43ab10bdbd465b3a9e3e2fc1709841e197093")
addappid(2434462, 0, "cc6169f4cd2e80d06a4e158c858a7baee59ec13699bd41b6155ac671309b0de3")
addappid(2434463, 0, "3e263685026c05ab18ada0cc742bcffe4f28afdd9c340a851dd2eccca5833ccc")
addappid(2434464, 0, "47f6ba27efc36a633a350185ffd261fc051593b576be1cfa7d41c9c049ac850a")
addappid(2434465, 0, "d44a32bfe999b2f7a4228bff6efe968e722525952670eaaf7efe8de9feb20f51")

