-- Lua provided by RyzenAPI
-- Game: Super Demon Boy

-- MAIN APPLICATION
addappid(1118700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1118701, 1, "e42a513f4f45c6eb70a8f40f56e5de6d86bfb2f031fdf0eb6d0c6b71af8d80d8")

