-- Lua provided by RyzenAPI
-- Game: Game: AppID 1118700

-- MAIN APPLICATION
addappid(1118700)
-- Game: addappid(1118700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118701, 1, "e42a513f4f45c6eb70a8f40f56e5de6d86bfb2f031fdf0eb6d0c6b71af8d80d8")
