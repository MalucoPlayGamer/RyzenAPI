-- Lua provided by RyzenAPI
-- Game: Isle of Reveries

-- MAIN APP DEPOTS / PACKAGES
addappid(3100970, 1, "cccd2d6496492b98055b67c69f4669ebaf69f5032ecc3225df61238ecfb51f5c") -- Isle of Reveries
addappid(3100973, 1, "c8badf7a531d02c9be5cf49d954d9ee18ab23657162d1ff6662c9d81158ce8be") -- Depot 3100973
addappid(3100974, 1, "a53c5bc7db852b5425a31aa79cd13b86973dc37c4900162d66beb81e028701a2") -- Depot 3100974

