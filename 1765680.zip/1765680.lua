-- Lua provided by RyzenAPI
-- Game: 1765680

-- MAIN APPLICATION
addappid(1765680)
-- Game: addappid(1765680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765681, 1, "a74cd0aa1683d57b74ae743e71448846ba115e23854c1d25815f98bcdebb954f")
