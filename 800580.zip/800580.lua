-- Lua provided by RyzenAPI
-- Game: Highway Wars

-- MAIN APPLICATION
addappid(800580)

-- MAIN APP DEPOTS / PACKAGES
addappid(800581,0,"14c482b227ed05da9ac901b41f91c171d021cc049f3be57e0f18aca03279a518")

