-- Lua provided by SkyAPI 
-- Game: Death and the Fly
addappid(41680)
addappid(41681, 1, "8aac58b1a85bacf2e51a631bcbcb4a63598bac7ab47494f0d6b0583a6a3db131")
