-- Lua provided by RyzenAPI
-- Game: Bus Simulator Offroad

-- MAIN APPLICATION
addappid(3659780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3659781, 1, "766a03f5596d492f3843c714fa70d2a314f8b4c2d427a24a6e0851ff5ca911a4")
