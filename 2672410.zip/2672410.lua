-- Lua provided by RyzenAPI
-- Game: SteamWorld Build Soundtrack

-- MAIN APPLICATION
addappid(2672410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672411, 1, "6554f0400a7e3aef5c0b117f14355ce78bd4e018711ad3b39a7a9f7b0cd88cfc")
addappid(2672412, 1, "a11496b177d342c381964237b54cfe701a004de8fcfa13e651ecad3ef9ce36dc")
