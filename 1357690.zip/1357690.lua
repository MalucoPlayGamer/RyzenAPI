-- Lua provided by RyzenAPI
-- Game: Game: ARIA CHRONICLE Original Soundtrack

-- MAIN APPLICATION
addappid(1357690)
-- Game: addappid(1357690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357691, 1, "10a50256ee94450a972057a4ffae71fdb8f1e3db88d1fb448b9a575cacf9b3ec")
