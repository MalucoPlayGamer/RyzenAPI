-- Lua provided by RyzenAPI
-- Game: addappid(1767890)

-- MAIN APPLICATION
addappid(1767890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767891, 1, "406042a51b97b9baabd25a7b65b057b972ac3bfef50e731b99484d8e790e2508")
