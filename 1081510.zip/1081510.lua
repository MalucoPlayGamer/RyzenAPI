-- Lua provided by RyzenAPI
-- Game: 1081510

-- MAIN APPLICATION
addappid(1081510)
addappid(1081515)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081512,0,"bc6f051e741b97d13d638a2205a59e04ee99eae5a700073e15c693a72ed96ac4")
addappid(1081514,0,"9a24d8e3b44b522b55ae4ddcfdeb9d3e038c00ce3b3dad2b40c7f5c4ae833567")

