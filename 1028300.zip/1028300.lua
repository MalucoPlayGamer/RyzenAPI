-- Lua provided by RyzenAPI
-- Game: Katana Soul

-- MAIN APPLICATION
addappid(1028300)
-- Game: addappid(1028300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028301, 1, "c935bb6444af500048802b69410b3017252365f2de8c7d38fd49ff73d588f387")
