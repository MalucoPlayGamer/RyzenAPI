-- Lua provided by RyzenAPI
-- Game: 1177020

-- MAIN APPLICATION
addappid(1177020)
-- Game: addappid(1177020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177021, 1, "8114d1ff09e6cae85a75d579b34ebf798349483724b919dd99bfcf10b898fc0b")
