-- Lua provided by RyzenAPI
-- Game: Gigantosaurus The Game

-- MAIN APPLICATION
addappid(1177020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1177021, 1, "8114d1ff09e6cae85a75d579b34ebf798349483724b919dd99bfcf10b898fc0b")

