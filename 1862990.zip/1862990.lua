-- Lua provided by RyzenAPI
-- Game: Nervous Granny

-- MAIN APPLICATION
addappid(1862990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862991, 1, "28083767e3d534c28a2de8790067481701f9039b8dbb833b1ac9e0abc6109038")

