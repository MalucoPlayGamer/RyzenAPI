-- Lua provided by RyzenAPI
-- Game: Space Gladiators

-- MAIN APPLICATION
addappid(1144910)
-- Game: addappid(1144910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144911, 1, "d5dcf8b64cab94f81b886bdd407aa4a5f414c567a5d697bb7d3d87be9ee088f4")
