-- Lua provided by RyzenAPI
-- Game: 2328730

-- MAIN APPLICATION
addappid(2328730)
addappid(2328733)
addappid(2328734)
addappid(2328735)
-- Game: addappid(2328730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328732,0,"8c55de68064eab43c3c7d111e27aa8da5855a9645092e122603fef3007bf6b26")
