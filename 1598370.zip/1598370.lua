-- Lua provided by RyzenAPI
-- Game: Vojo

-- MAIN APPLICATION
addappid(1598370)
-- Game: addappid(1598370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598371, 1, "892225991685c88a32302a608b624b4f49c4d603628383bc1b42f0b312afc2ba")
