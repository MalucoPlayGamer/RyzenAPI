-- Lua provided by RyzenAPI
-- Game: The Underground Man 2

-- MAIN APPLICATION
addappid(1486950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486951, 1, "a604671d14c2a65506f55a55e43dfb685a173d389d91a2205992438b9de75ee5")

