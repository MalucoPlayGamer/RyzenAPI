-- Lua provided by RyzenAPI
-- Game: Interstellar annihilation project

-- MAIN APPLICATION
addappid(1495450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495451, 1, "27f7a1d0d831f51c19b6c52771f4446b3638432daee05d3e1defee57c00a9c7e")

