-- 4391870's Lua and Manifest Created by Hubcap Manifest
-- Bounty Pro Pulling
-- Created: August 03, 2026 at 19:22:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4391870) -- Bounty Pro Pulling
-- MAIN APP DEPOTS
addappid(4391871, 1, "f6bc141c29be9f88e6694fabfeb09419f9ad0fd95919cdd357013f96eb915980") -- Depot 4391871
setManifestid(4391871, "8816619719483137878", 12870887209)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4942530) -- Bounty Pro Pulling - Two Wheel Drive Pack 1
addappid(4942540) -- Bounty Pro Pulling - Tractor Pack 1