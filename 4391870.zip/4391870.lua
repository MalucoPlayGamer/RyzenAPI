-- Lua provided by RyzenAPI
-- Game: Bounty Pro Pulling

-- MAIN APPLICATION
addappid(4391870) -- Bounty Pro Pulling
addappid(4942530) -- Bounty Pro Pulling - Two Wheel Drive Pack 1
addappid(4942540) -- Bounty Pro Pulling - Tractor Pack 1

-- MAIN APP DEPOTS / PACKAGES
addappid(4391871, 1, "f6bc141c29be9f88e6694fabfeb09419f9ad0fd95919cdd357013f96eb915980") -- Depot 4391871

