-- Lua provided by RyzenAPI
-- Game: addappid(2796180)

-- MAIN APPLICATION
addappid(2796180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796181, 1, "0bc95c642ade277747008c7f43a7903ef23726feaa4dce9411f15cf287aebd16")
