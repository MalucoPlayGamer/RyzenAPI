-- Lua provided by RyzenAPI
-- Game: Best Elf

-- MAIN APPLICATION
addappid(1583240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583242,0,"aae531580411fa985b39b2d464b53800ce11240c1eaf365daef8e7644ba70e7e")

