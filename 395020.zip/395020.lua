-- Lua provided by RyzenAPI
-- Game: addappid(395020)

-- MAIN APPLICATION
addappid(395020)

-- MAIN APP DEPOTS / PACKAGES
addappid(395020,0,"6907c81a2662f546313a5571eb15e71914017a21ef5e3dc9efaa705ddb9f7e45")
