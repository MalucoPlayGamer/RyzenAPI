-- Lua provided by RyzenAPI
-- Game: Stilt

-- MAIN APPLICATION
addappid(2482270)
-- Game: addappid(2482270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482271, 1, "fc209ce2f1b82ee1d38671023c7e7e69367242dc1fc1446bfbf8661f8afb6801")
