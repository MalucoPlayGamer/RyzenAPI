-- Lua provided by RyzenAPI
-- Game: Runaway, A Road Adventure

-- MAIN APPLICATION
addappid(7210)
-- Game: addappid(7210)

-- MAIN APP DEPOTS / PACKAGES
addappid(7213,0,"2800ba10893d5f16617037cbfc7972f55b98a06e4ba14eadc5e806d3388863f4")
addappid(7214,0,"82fe92b2055738f2fe67a5851405953749c7cfaf43852e5dca899ca29fc06358")
