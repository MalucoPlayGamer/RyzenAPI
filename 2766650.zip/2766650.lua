-- Lua provided by RyzenAPI
-- Game: Game: Chicago Project

-- MAIN APPLICATION
addappid(2766650)
-- Game: addappid(2766650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766651, 1, "b41b2eb476353a282af15e9958bda0b141d50f05ddfa7152a93b55a4f8d7e3c2")
