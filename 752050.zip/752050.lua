-- Lua provided by RyzenAPI
-- Game: Virtual Reality Girls

-- MAIN APPLICATION
addappid(752050)

-- MAIN APP DEPOTS / PACKAGES
addappid(752051, 1, "92fbfdf1bb313006d055b1f2f162617bf456e95dd100e1df80d61e228ff9f5fa")
