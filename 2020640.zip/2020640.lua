-- Lua provided by RyzenAPI
-- Game: 跑酷达人

-- MAIN APPLICATION
addappid(2020640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020641, 1, "56e113b253e30d250503c629413aeedc312f2f800a7b0df152d761840e38a78c")

