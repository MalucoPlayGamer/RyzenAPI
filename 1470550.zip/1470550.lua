-- Lua provided by RyzenAPI 
-- Game: Stranded
addappid(1470550)
addappid(1470551, 1, "ed8dd0a1f19abb72e3caf249e432f2c11cdc4ed453354d2b5946ae3972682096")
