-- Lua provided by RyzenAPI
-- Game: Zombie Town : Online

-- MAIN APPLICATION
addappid(810190)

-- MAIN APP DEPOTS / PACKAGES
addappid(810191, 1, "b7358acc6c534b33eb081bce2fe7bd80021de51084188fe09ca034d44842ef69")
