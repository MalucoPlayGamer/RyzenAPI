-- Lua provided by RyzenAPI
-- Game: Game: AppID 912760

-- MAIN APPLICATION
addappid(912760)
-- Game: addappid(912760)

-- MAIN APP DEPOTS / PACKAGES
addappid(912761, 1, "9bafc3a7e8438c239da8fb4390e06dca5ddca83aa92237336b1bb2ec09e66615")
