-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2456610)
-- Game: addappid(2456610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456610,0,"ea7a1903ef082e2654d39d87384776997ff16ce4d0d1ed43030cf1a833fee129")
addtoken(2456610,17792956582198371615)
