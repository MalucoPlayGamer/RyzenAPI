-- Lua provided by RyzenAPI
-- Game: 1058330

-- MAIN APPLICATION
addappid(1058330)
-- Game: addappid(1058330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058331, 1, "7f16fb34466aa7d96e1c406b1ca39a7512c92b8e37e69f5e057bc4a196e41339")
