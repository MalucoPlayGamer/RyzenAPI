-- Lua provided by RyzenAPI
-- Game: Seven Bullets Zombie Apocalypse

-- MAIN APPLICATION
addappid(1036900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036902,0,"5f66949cee04e2faa8b8780da7a50b4332bcb6357fb074d80dfa82e728571966")

