-- Lua provided by RyzenAPI
-- Game: Crazy Alien

-- MAIN APPLICATION
addappid(1808580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808581, 1, "63767ffae77c80df6202b2ac35470ed764f0ae0d2b7fff97d2ae078875a90236")
