-- Lua provided by RyzenAPI
-- Game: 失踪した友人の部屋に残されていたゲーム

-- MAIN APPLICATION
addappid(3201810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201811, 1, "d68fa8a016984e8e5297dba8d70e72c78f8cb3c23a41c3416219fc85e84fda8a")
