-- Lua provided by RyzenAPI 
-- Game: AppID 2409130
addappid(2409130)
addappid(2409131, 1, "82720b57074023c44c28ed281d6426172c9f877ab4d8eb9a0c4d903ab101e7df")
addappid(2409132, 1, "82c1699caece5822c31790b6c98be1a976ea5634d9bbb716ea1192b958597cc9")
