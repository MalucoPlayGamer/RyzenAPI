-- Lua provided by RyzenAPI
-- Game: Game: Domenation

-- MAIN APPLICATION
addappid(2360410)
-- Game: addappid(2360410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360411, 1, "6417d0d064518d93aeb485f64ae10f82c8d4ac893df72b7b7aa5e0dda27ffb3c")
