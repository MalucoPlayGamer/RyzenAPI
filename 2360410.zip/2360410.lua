-- Lua provided by RyzenAPI 
-- Game: Domenation
addappid(2360410)
addappid(2360411, 1, "6417d0d064518d93aeb485f64ae10f82c8d4ac893df72b7b7aa5e0dda27ffb3c")
