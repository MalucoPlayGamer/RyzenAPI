-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1209132)
-- Game: addappid(1209132)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209132,0,"bde148d51e0bb9b79ed4f412e8d65af6d913d0f2b4d4696cbf18a3b19805a14a")
