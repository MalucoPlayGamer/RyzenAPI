-- Lua provided by RyzenAPI
-- Game: Hidden Words

-- MAIN APPLICATION
addappid(1744050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744051,0,"348bea68b542b1bbcc0f504800ecf3468d15d24acbbeba46de19faac37cc214b")

