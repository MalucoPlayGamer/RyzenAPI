-- Lua provided by RyzenAPI
-- Game: 1928640

-- MAIN APPLICATION
addappid(1928640)
-- Game: addappid(1928640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928641, 1, "01b0c20c03842fddf8cd3366302265ce11d3542041cb5f868b70dabcc9253fa5")
