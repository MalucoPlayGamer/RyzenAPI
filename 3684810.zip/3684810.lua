-- Lua provided by RyzenAPI
-- Game: Cards and Castles Ultimate

-- MAIN APPLICATION
addappid(3684810)

