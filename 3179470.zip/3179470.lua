-- Lua provided by RyzenAPI
-- Game: Game: Mars Mirage Demo

-- MAIN APPLICATION
addappid(3179470)
-- Game: addappid(3179470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179471, 1, "887cf04ff49a9cc8aeae8f4cb0e68302bdc56715d47f076cd092ef1baff3314f")
