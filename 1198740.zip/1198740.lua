-- Lua provided by RyzenAPI
-- Game: Colony Siege

-- MAIN APPLICATION
addappid(1198740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1198741, 1, "8581a6c878cc9c0bd19b3cb978a81be4f20612b33d678e58037867d1d1452dfb")
