-- Lua provided by RyzenAPI
-- Game: addappid(1198740)

-- MAIN APPLICATION
addappid(1198740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198741, 1, "8581a6c878cc9c0bd19b3cb978a81be4f20612b33d678e58037867d1d1452dfb")
