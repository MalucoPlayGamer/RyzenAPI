-- Lua provided by RyzenAPI
-- Game: The Door in the Basement

-- MAIN APPLICATION
addappid(1436810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1436811, 1, "cf7fe73d20165e0a4b9f523448972b7e0bd399d2171c52b5f7b5ca509b305dad")

