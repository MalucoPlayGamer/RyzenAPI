-- Lua provided by RyzenAPI
-- Game: addappid(1436810)

-- MAIN APPLICATION
addappid(1436810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436811, 1, "cf7fe73d20165e0a4b9f523448972b7e0bd399d2171c52b5f7b5ca509b305dad")
