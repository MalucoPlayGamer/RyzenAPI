-- Lua provided by RyzenAPI 
-- Game: Hollywood Visionary
addappid(365210)
addappid(365211, 1, "ac34d102b884a6c77f7a56f0d961ba9de533400dd18c12a0b9c62093cf3935a2")
