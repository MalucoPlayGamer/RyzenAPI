-- Lua provided by RyzenAPI
-- Game: Aconite

-- MAIN APPLICATION
addappid(2172940)
-- Game: addappid(2172940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172941, 1, "536b3df0e86dce5f6d9a4bd4b12d90fa492f36fc440371f1d5ba37cbb57b3a2e")
