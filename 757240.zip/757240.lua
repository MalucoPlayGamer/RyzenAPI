-- Lua provided by RyzenAPI
-- Game: Aimtastic

-- MAIN APPLICATION
addappid(757240)
addappid(825470)
addappid(950150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(757241, 1, "4d9221a3ee56195687cfa856a6d0e5a660c25b7dc3fbf4e3a6427250ca2dea46")

