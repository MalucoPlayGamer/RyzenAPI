-- Lua provided by SkyAPI 
-- Game: Aimtastic
addappid(757240)
addappid(757241, 1, "4d9221a3ee56195687cfa856a6d0e5a660c25b7dc3fbf4e3a6427250ca2dea46")
addappid(825470)
