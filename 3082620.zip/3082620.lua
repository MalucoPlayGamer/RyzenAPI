-- Lua provided by RyzenAPI
-- Game: Sifu's Quest

-- MAIN APPLICATION
addappid(3082620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3082621, 1, "2caed03ad9dfb9d3704a4e52373096582ece6440cc13bd86e5d5a34a63d3ac20")
