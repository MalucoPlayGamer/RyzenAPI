-- Lua provided by RyzenAPI
-- Game: AppID 877080

-- MAIN APPLICATION
addappid(877080)

-- MAIN APP DEPOTS / PACKAGES
addappid(877081, 1, "8073e5d53f6efdf77e8b6ccfc1bcec2559122b09e232bfcc6a85f4694e887a66")
addappid(877082, 1, "366969774d389cdc5638e723b97d4fdeade18b58c9d91d602ab228956b2385d0")
addappid(877083, 1, "a0432a72287231abb70d5a46f7072b9d3605ce47e7ab62c54dc523118a2897f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
