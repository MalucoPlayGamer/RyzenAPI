-- Lua provided by RyzenAPI
-- Game: 2170840

-- MAIN APPLICATION
addappid(2170840)
-- Game: addappid(2170840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170841, 1, "e65d6ff0f4771258e2a05d1ee68df6026500e8229fec696673627088b90fe4ad")
