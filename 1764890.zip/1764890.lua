-- Lua provided by RyzenAPI
-- Game: addappid(1764890)

-- MAIN APPLICATION
addappid(1764890)
addappid(2721080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764891, 1, "a9d821c310fa298a7159a5ff63282b88e75bdbda57e953137db054bbd2198448")
