-- Lua provided by RyzenAPI
-- Game: Dragon Expedition

-- MAIN APPLICATION
addappid(3435310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435311, 1, "e825760552b08c25f419765c009f342f938ceb92a03a5fede3339f57c58bd4d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
