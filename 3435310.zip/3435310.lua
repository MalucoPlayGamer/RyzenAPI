-- Lua provided by RyzenAPI
-- Game: addappid(3435310)

-- MAIN APPLICATION
addappid(3435310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435311, 1, "e825760552b08c25f419765c009f342f938ceb92a03a5fede3339f57c58bd4d3")
