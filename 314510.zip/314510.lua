-- Lua provided by RyzenAPI
-- Game: Fall of the New Age Premium Edition

-- MAIN APPLICATION
addappid(314510)

-- MAIN APP DEPOTS / PACKAGES
addappid(314511, 1, "ab261e471e39589b8265318ce0d80a43683fb7b9cf81eaf9be3aa00d65db9b1b")
addappid(314512, 1, "3e5c443598be402c9ee29ad4ca7a6202c9d3efb10f8ef4e14649420304de1f5f")
addappid(314513, 1, "fe9139c279a96cc881387ea84111d72c5383c205e1d172c3eb96de7fc4821517")

