-- Lua provided by RyzenAPI
-- Game: Hob

-- MAIN APPLICATION
addappid(404680)

-- MAIN APP DEPOTS / PACKAGES
addappid(404681, 1, "abc5c0743a37ad1a1eaa9ef729e241c8372f3bd74b134b064b366676cd929fec")
addappid(404682, 1, "f3f7fa6be07657366862463e8126a5070518ae16bd31b761d49ba028e04ba20d")
addappid(719530, 0, "9d83f5c6fabf89c7a28f5e63fb32ed3e783da1e843cae40243ec64b08aa07523")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
