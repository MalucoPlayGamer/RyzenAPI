-- Lua provided by RyzenAPI
-- Game: 404680

-- MAIN APPLICATION
addappid(404680)
-- Game: addappid(404680)

-- MAIN APP DEPOTS / PACKAGES
addappid(404681, 1, "abc5c0743a37ad1a1eaa9ef729e241c8372f3bd74b134b064b366676cd929fec")
addappid(404682, 1, "f3f7fa6be07657366862463e8126a5070518ae16bd31b761d49ba028e04ba20d")
addappid(719530, 0, "9d83f5c6fabf89c7a28f5e63fb32ed3e783da1e843cae40243ec64b08aa07523")
