-- Lua provided by RyzenAPI 
-- Game: Endless Nightmare
addappid(2065520)
addappid(2065521, 1, "f0ca842fa9dd06522ead6717206caeb3d6441b30434e2f87cdaedf68e6a323fb")
