-- Lua provided by RyzenAPI
-- Game: Dominions 2

-- MAIN APPLICATION
addappid(3533600) -- Dominions 2

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(3533601, 1, "b84eebcda13eb8168f740bdaf8988719e69f43a4c6c1674f00ffdde9a3b5c224") -- Depot 3533601

