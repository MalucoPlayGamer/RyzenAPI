-- 3533600's Lua and Manifest Created by Hubcap Manifest
-- Dominions 2
-- Created: August 15, 2026 at 03:15:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3533600) -- Dominions 2
-- MAIN APP DEPOTS
addappid(3533601, 1, "b84eebcda13eb8168f740bdaf8988719e69f43a4c6c1674f00ffdde9a3b5c224") -- Depot 3533601
setManifestid(3533601, "4783088960582918302", 219235901)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)