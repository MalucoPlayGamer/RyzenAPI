-- Lua provided by RyzenAPI
-- Game: Game: AppID 1194700

-- MAIN APPLICATION
addappid(1194700)
-- Game: addappid(1194700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194701, 1, "178b44a2ad66a8e5475efde7f71be20b881da019aefadadc1f1a0d79cd501a52")
