-- Lua provided by RyzenAPI
-- Game: addappid(3172700)

-- MAIN APPLICATION
addappid(3172700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172701, 1, "0a51fbcec9c86fe5efd4531fab2c3c094dc9418dd21ddee026bf031a10f1dea2")
