-- Lua provided by RyzenAPI
-- Game: 2742040

-- MAIN APPLICATION
addappid(2742040)
-- Game: addappid(2742040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742041, 1, "93580c29f3958fbcc3be9441dd5e7836dbd848bcf75ee05de68ad7fae6750897")
