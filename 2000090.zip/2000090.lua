-- Lua provided by RyzenAPI
-- Game: Game: The Isle Tide Hotel

-- MAIN APPLICATION
addappid(2000090)
-- Game: addappid(2000090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000091, 1, "256c84bbec8f90c59c52df89bb4327692b1dbd294b06f5658e6221eb5ee17e87")
addappid(2000092, 1, "9450d818e13fe63f1a4e2c4e0cfae50e2c3332a4268fa5ef543683f6fb694b6c")
addappid(2000093, 1, "799913a6f5105d562b2cdb7c5c5294da6212cd7e7f32ffcbf1350ecfcdd3ca83")
addappid(2000094, 1, "a489eead499d9c15bd589c157376fb8d867fa881c58d61f42b2d2c9d3d519e92")
addappid(2521410, 0, "7f74c6b9e138eb0c44757c5a814fd5645f23b6436b2f48df31d8974f641cb9a0")
