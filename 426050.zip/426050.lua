-- Lua provided by RyzenAPI
-- Game: Game: LEGIE

-- MAIN APPLICATION
addappid(426050)
-- Game: addappid(426050)

-- MAIN APP DEPOTS / PACKAGES
addappid(426051, 1, "58070d6a51131ba5e203cbfd58081dffa8948d48487bfa42ee396e972f13c1c5")
