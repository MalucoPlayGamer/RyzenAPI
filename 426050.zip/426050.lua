-- Lua provided by RyzenAPI
-- Game: LEGIE

-- MAIN APPLICATION
addappid(426050)

-- MAIN APP DEPOTS / PACKAGES
addappid(426051, 1, "58070d6a51131ba5e203cbfd58081dffa8948d48487bfa42ee396e972f13c1c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
