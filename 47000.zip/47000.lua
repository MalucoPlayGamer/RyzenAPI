-- Lua provided by RyzenAPI
-- Game: 4 Elements

-- MAIN APPLICATION
addappid(47000)
-- Game: addappid(47000)

-- MAIN APP DEPOTS / PACKAGES
addappid(47001, 1, "6ff843b689aee294b80e56d3db6e850dc5dec67f036579e5f70404a756a4545a")
