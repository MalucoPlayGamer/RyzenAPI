-- Lua provided by RyzenAPI
-- Game: Catizens - Original Soundtrack

-- MAIN APPLICATION
addappid(2543290)
-- Game: addappid(2543290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543291, 1, "c67060c1ea74deee98cd6c628eb4998cf2d50a431413962f9c34633730392ebd")
