-- Lua provided by RyzenAPI
-- Game: The Legion: FringeBound

-- MAIN APPLICATION
addappid(1064960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064961, 1, "3842fac99a007cbee8ebc16542043942545da3ea037f4479d72030f531c1464b")
