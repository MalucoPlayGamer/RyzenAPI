-- Lua provided by RyzenAPI
-- Game: Treasure of Cutuma 3rd

-- MAIN APPLICATION
addappid(1339670)
addappid(1379280)
addappid(1428990)
addappid(1477740)
addappid(2027150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1339671, 1, "775fe9e563e598488a164e5094a24a758ad8e84ae1663df9986be52f7c5c3eeb")

