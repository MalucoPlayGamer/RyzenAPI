-- Lua provided by RyzenAPI
-- Game: Treasure of Cutuma 3rd

-- MAIN APPLICATION
addappid(1339670)
addappid(1477740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339671, 1, "775fe9e563e598488a164e5094a24a758ad8e84ae1663df9986be52f7c5c3eeb")

