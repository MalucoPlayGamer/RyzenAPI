-- Lua provided by RyzenAPI
-- Game: AppID 612590

-- MAIN APPLICATION
addappid(612590)
-- Game: addappid(612590)

-- MAIN APP DEPOTS / PACKAGES
addappid(612591, 1, "bfc160aa11cdd12a714be212e6d66c3b12083275e642e28c1a9e145e15e29cec")
