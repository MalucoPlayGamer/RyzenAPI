-- Lua provided by RyzenAPI
-- Game: Mouse Playhouse

-- MAIN APPLICATION
addappid(612590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(612591, 1, "bfc160aa11cdd12a714be212e6d66c3b12083275e642e28c1a9e145e15e29cec")
