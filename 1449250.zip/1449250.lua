-- Lua provided by RyzenAPI
-- Game: 狂潮-Staggering Through The Dark

-- MAIN APPLICATION
addappid(1449250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449251, 1, "c99145fb41e4d9410f772f1a860faec935a2ccdb7414ac30c869f3e2770b0d60")

