-- Lua provided by RyzenAPI
-- Game: Countryballs: Over The World

-- MAIN APPLICATION
addappid(784940)

-- MAIN APP DEPOTS / PACKAGES
addappid(784941, 1, "ba180fc57587277198a7a8f9265ffee2e22ba38bb301c9913b7178492f5f1d78")
