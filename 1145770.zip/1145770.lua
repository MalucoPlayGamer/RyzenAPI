-- Lua provided by RyzenAPI
-- Game: AppID 1145770

-- MAIN APPLICATION
addappid(1145770)
addappid(1188500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1145771, 1, "8fe34edf0a81503a45f86a2595f9b90589a0b11e8b773eaca69962a32a202de9")

