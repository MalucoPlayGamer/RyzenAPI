-- Lua provided by SkyAPI 
-- Game: DERE EVIL EXE
addappid(871950)
addappid(871951, 1, "c9757edfac2b917582c8cc8bedc77e6ced4f1b63f252c202d4ac1e7340c608dc")
addappid(899360)
addappid(1023770, 0, "fa3c63d08748488a017a08402b4d5443457a3e9d8a359be43c4525a436be3776")
