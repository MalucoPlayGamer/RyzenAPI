-- Lua provided by RyzenAPI
-- Game: Kurofune : Descobrimentos Portugueses

-- MAIN APPLICATION
addappid(2692450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692451, 1, "c8813165966ae55d32dffe248e3401ebcfba4403df6c8af2a88e17f372544f89")
