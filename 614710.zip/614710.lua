-- Lua provided by RyzenAPI
-- Game: 614710

-- MAIN APPLICATION
addappid(614710)
-- Game: addappid(614710)

-- MAIN APP DEPOTS / PACKAGES
addappid(614711, 1, "7d4f96635274505a2287626286ec907c4c71b5d909f90dc0d176bf8b45795eec")
