-- Lua provided by RyzenAPI 
-- Game: AppID 614710
addappid(614710)
addappid(614711, 1, "7d4f96635274505a2287626286ec907c4c71b5d909f90dc0d176bf8b45795eec")
