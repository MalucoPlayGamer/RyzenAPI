-- Lua provided by RyzenAPI
-- Game: 1618280

-- MAIN APPLICATION
addappid(1618280)
-- Game: addappid(1618280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618281, 1, "896c800b8fdde9a0db5bac1796604e8949287e97b3ce03a470b512f205a54986")
