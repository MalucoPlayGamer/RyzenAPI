-- Lua provided by RyzenAPI
-- Game: Game: Cats are Liquid - A Light in the Shadows

-- MAIN APPLICATION
addappid(498330)
-- Game: addappid(498330)

-- MAIN APP DEPOTS / PACKAGES
addappid(498331, 1, "33b05b2c5b09d17f16d2883e59d9ab8c5ecafb5647128be2b5c9d5e577a51c17")
