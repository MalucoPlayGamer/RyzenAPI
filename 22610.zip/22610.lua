-- Lua provided by RyzenAPI
-- Game: Alien Breed: Impact

-- MAIN APPLICATION
addappid(22610)
addappid(22618)
addappid(22640)

-- MAIN APP DEPOTS / PACKAGES
addappid(22611, 1, "0e7762143ffc23a569089013822f0826ebaddf2947dec87897461e702417be49")
addappid(22612, 1, "6d219ea3de40f694c717c87394e67703d3d003c0e9fe26b6521bd2df7e847c5c")
addappid(22613, 1, "b96a9240f1518814119d2cfd4b8c3119d3951d485a97a376bdf3bc4612e2f804")
addappid(22614, 1, "3851579c90e1770442e0a923d1aac9b722b9f0e70d7aa20ea2000df2d420bc9b")
addappid(22615, 1, "ec7f6a933db8e139f68fd629ce3d588e815915bc44df29a3dd3a224c1a2b7133")
addappid(22616, 1, "8fa653890f516b452b4efa0c4985fc6bdc3610859db8f180e6d8d780c4b5e4a0")
addappid(22617, 1, "b8e998efb9ebb433dedec5149c43aa53e4ebcc83ba86bcef235ccabfb630bf46")

