-- Lua provided by RyzenAPI
-- Game: Game: Nimbus INFINITY

-- MAIN APPLICATION
addappid(1399170)
-- Game: addappid(1399170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399171, 1, "21570ea01d0c0b319900e51abd903642b669e3e0ac767976be19ae1bc04f6d64")
