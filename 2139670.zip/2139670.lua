-- Lua provided by RyzenAPI
-- Game: AppID 2139670

-- MAIN APPLICATION
addappid(2139670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139671, 1, "ef0dba52ffc6a3c89812a1e1237aebf9b7ddd3cdfbaa04b809f985fd44ac8217")
