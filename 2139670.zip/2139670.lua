-- Lua provided by SkyAPI 
-- Game: AppID 2139670
addappid(2139670)
addappid(2139671, 1, "ef0dba52ffc6a3c89812a1e1237aebf9b7ddd3cdfbaa04b809f985fd44ac8217")
