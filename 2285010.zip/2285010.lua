-- Lua provided by RyzenAPI
-- Game: AppID 2285010

-- MAIN APPLICATION
addappid(2285010)
-- Game: addappid(2285010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285011, 1, "bc8eb6dc620b2298b647f81fae7aae21ed2344d29651e257e44e6bea4360e04a")
