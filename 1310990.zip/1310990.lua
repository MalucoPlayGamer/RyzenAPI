-- Lua provided by RyzenAPI
-- Game: Bishojo Mangekyo Kotowari to Meikyu no Shojo

-- MAIN APPLICATION
addappid(1310990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310992,0,"28fab8a1be87167abc7c623c1142d6abdc279465b5e33f6c7f9d99a42e34a853")
