-- Lua provided by SkyAPI 
-- Game: NO TOMORROW
addappid(2837310)
addappid(2837311, 1, "24a0f6f21e812d90374e097939cd8903004553a2002d9ae3d3cf1ee64d1f5774")
