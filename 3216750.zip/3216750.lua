-- Lua provided by RyzenAPI
-- Game: Caverna

-- MAIN APPLICATION
addappid(3216750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216751, 1, "b382faa4c077cabbeecb0ba8ffc25bdfd5e1d7fd97ef21ac57c953269485818b")

