-- Lua provided by RyzenAPI
-- Game: War for the Overworld

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228988)
addappid(228990)
addappid(229004)
addappid(230190)

-- MAIN APP DEPOTS / PACKAGES
addappid(230192,0,"b34ef0d97fd6f23c54c12dbd08e27ab0f6894a0e41d2495654c041fb4baf440e")
addappid(230193,0,"ed9a800119d4a7b97a868c441c984f7ff75a59feb5889f084e57e8693f7b4d75")
addappid(230195,0,"d690a16150e6f3f2bf5151dea3aea419582e7e68f816c4c192e2b06a4fe10391")
addappid(239391,0,"f99ceb06a254e7c96e656c9777db82e826bf3628ff713708f5d991e32f487079")
