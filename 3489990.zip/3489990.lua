-- Lua provided by RyzenAPI
-- Game: Emma's Umbrella

-- MAIN APPLICATION
addappid(3489990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489991, 1, "b3fb9a3ac337dc883a6f53661c5beb8a80ce27aa91dfc86722e303d01e0acf30")
