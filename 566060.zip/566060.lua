-- Lua provided by RyzenAPI
-- Game: 566060

-- MAIN APPLICATION
addappid(566060)
-- Game: addappid(566060)

-- MAIN APP DEPOTS / PACKAGES
addappid(566061, 1, "a32418e1d70505825d8aa66baa01f547bcd5057bd3f1b0ec4b626f734edc9735")
