-- Lua provided by RyzenAPI
-- Game: Spaceship Driver License

-- MAIN APPLICATION
addappid(2862050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862051, 1, "af63dea96dad8b6a0df985ca2dcef4be1abca118eaac95461cd724b435fa9ecd")

