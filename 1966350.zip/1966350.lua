-- Lua provided by RyzenAPI
-- Game: AppID 1966350

-- MAIN APPLICATION
addappid(1966350)
-- Game: addappid(1966350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966351, 1, "9ef206317469facb235f7f59206457fe1d65bc10f2e6b8d66ae190e4c51ba084")
