-- Lua provided by RyzenAPI
-- Game: AppID 3223400

-- MAIN APPLICATION
addappid(3223400)
-- Game: addappid(3223400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223401, 1, "db000247528ae2b952db617f0ae8a948c34531e16a4e78e9441dbbf6059c879f")
