-- Lua provided by RyzenAPI
-- Game: The Communist Dogifesto

-- MAIN APPLICATION
addappid(778460)

-- MAIN APP DEPOTS / PACKAGES
addappid(778461,0,"7f10ee06c01c29d4e6f063623e2378398d90284518bb416dbf8463f59a508bd0")

