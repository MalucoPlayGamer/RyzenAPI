-- 4893350's Lua and Manifest Created by Hubcap Manifest
-- Ludus: A Gladiator Story
-- Created: July 30, 2026 at 14:11:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4893350) -- Ludus: A Gladiator Story
-- MAIN APP DEPOTS
addappid(4893351, 1, "b0032b9b534e3134cba661a478b3c282abfaaa2f2ccfdc81a5d328af96335893") -- Depot 4893351
setManifestid(4893351, "6851996707643346934", 9506662680)
addappid(4893352, 1, "4260a4b26ac5d98b75509424823e7dc9576ecc133acf788253ca829317b5fc48") -- Depot 4893352
setManifestid(4893352, "7344915704987657151", 9474150136)