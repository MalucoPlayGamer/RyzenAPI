-- Lua provided by RyzenAPI
-- Game: SKALD: Against the Black Priory Demo

-- MAIN APPLICATION
addappid(2092990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092991, 1, "e9c38a5d0357a4ffc06437e6e3b57e485662e363f6f920d970e4fd740d7d6388")

