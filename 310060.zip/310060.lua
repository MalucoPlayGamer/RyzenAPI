-- Lua provided by RyzenAPI
-- Game: AppID 310060

-- MAIN APPLICATION
addappid(310060)

-- MAIN APP DEPOTS / PACKAGES
addappid(310061, 1, "410e46050d8a9e0373ec4415d2bc8fc4e3dece59e3512b30c862861040dff0e5")
addappid(310062, 1, "d77ffcc2560be339c3d873469c6afa7b1eab9648dd386abca449847b4821d92a")
addappid(310063, 1, "b10e358020bc1585283d11e365dda2a741e45c8fb97d5367bcc8db8aa90a22f3")
addappid(363700, 0, "e838027aa753df8225db9d93f3da9310e333d3b9cc330d148c61214939587f75")
addappid(363701, 0, "27f0beaa18fccef633c43333f3d262203900407cda9d982446ad74d1e9160d36")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(363702)
addappid(363703)
addappid(420640)
