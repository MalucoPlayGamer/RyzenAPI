-- Lua provided by RyzenAPI
-- Game: addappid(3857140)

-- MAIN APPLICATION
addappid(3857140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3857141, 1, "fb592ef1c12df6d67e628336362a0adf601c18394bfefd91ac02493e9f86b18d")
