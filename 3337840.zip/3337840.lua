-- Lua provided by RyzenAPI
-- Game: No Need for Flowers

-- MAIN APPLICATION
addappid(3337840) -- No Need for Flowers

-- MAIN APP DEPOTS / PACKAGES
addappid(3337841, 1, "1746d12397aa22b81d8898a96ff530d8d74748ab1efc45ecaf2645989d4da7f3") -- Depot 3337841

