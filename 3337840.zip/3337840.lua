-- 3337840's Lua and Manifest Created by Hubcap Manifest
-- No Need for Flowers
-- Created: August 07, 2026 at 12:58:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3337840) -- No Need for Flowers
-- MAIN APP DEPOTS
addappid(3337841, 1, "1746d12397aa22b81d8898a96ff530d8d74748ab1efc45ecaf2645989d4da7f3") -- Depot 3337841
setManifestid(3337841, "1069501227182280834", 1342839380)