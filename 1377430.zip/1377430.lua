-- Lua provided by SkyAPI 
-- Game: Sword Reverie
addappid(1377430)
addappid(1377431, 1, "b750dacad153c92884070d730c6aa7c318f390c48dc658e2bdabb5f72000a211")
addappid(1833400, 0, "ec94289deca2af8f1c9bbe22ce4f159a57cdf13a07ba34e017b7111426a36a5d")
