-- Lua provided by RyzenAPI
-- Game: Game: AppID 726650

-- MAIN APPLICATION
addappid(726650)
-- Game: addappid(726650)

-- MAIN APP DEPOTS / PACKAGES
addappid(726651, 1, "6c2c46447eaff26028c07478ba140a8b28d9da77ad15c4b6e0e25b06dc875b7d")
