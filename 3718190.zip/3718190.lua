-- Lua provided by RyzenAPI
-- Game: Created: August 27, 2026 at 13:29:27 EDT

-- MAIN APPLICATION
addappid(3991320) --  Venus Returns - VRDLC

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3718190, 1, "9f5e6889d8f015b8cd85a683ad40e2cbc774563092cbbe5450cc13e8001ffd07") -- スーパーリアル麻雀 Venus Returns
addappid(3718191, 1, "4d7b23dc80a9a38ff9cf30b72a4a83dc4c564b43420112e20031c2c23cf8bb43") -- Depot 3718191

