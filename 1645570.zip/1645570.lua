-- Lua provided by RyzenAPI
-- Game: Game: Greedy Bubble

-- MAIN APPLICATION
addappid(1645570)
-- Game: addappid(1645570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645571, 1, "10989629941f416ec5f056be8b6d064ad3210b5622b9adc6310b3836d5672f2c")
