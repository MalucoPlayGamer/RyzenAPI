-- Lua provided by RyzenAPI
-- Game: 残世界的鸢尾花 Demo

-- MAIN APPLICATION
addappid(1958470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958471, 1, "aa3452dc94e00876d9e23a632e264e0aedd6bed0a4b894c719802392e5239876")

