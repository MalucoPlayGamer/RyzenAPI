-- Lua provided by RyzenAPI
-- Game: Game: Mech Armada Demo

-- MAIN APPLICATION
addappid(1650500)
-- Game: addappid(1650500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650501, 1, "a7c6b503592a41e40b7f7d8fbd617e0eb6c2d7ffe10d3a6907ee7303cbe87f24")
