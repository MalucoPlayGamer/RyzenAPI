-- Lua provided by RyzenAPI 
-- Game: Mech Armada Demo
addappid(1650500)
addappid(1650501, 1, "a7c6b503592a41e40b7f7d8fbd617e0eb6c2d7ffe10d3a6907ee7303cbe87f24")
