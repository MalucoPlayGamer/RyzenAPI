-- Lua provided by RyzenAPI
-- Game: Refence Demo

-- MAIN APPLICATION
addappid(3443770)
-- Game: addappid(3443770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443771, 1, "9d48278eb29e2f0bedc6a4d4fa1ea7ff708412e5018b01177beff7440fcd6cf8")
