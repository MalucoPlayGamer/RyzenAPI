-- Lua provided by RyzenAPI
-- Game: Beat Saber - Madeon - Icarus

-- MAIN APPLICATION
addappid(1967804)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967804,0,"35a87b77c586ed213188e17cb5736c279ac92996b738d94305ef14fd96733e6e")

