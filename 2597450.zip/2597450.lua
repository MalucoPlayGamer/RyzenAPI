-- Lua provided by RyzenAPI
-- Game: Game: Blood Kiss

-- MAIN APPLICATION
addappid(2597450)
-- Game: addappid(2597450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597451, 1, "6e816a3904708293a4f830b76329a72572bfbcff8581c9207bcf8b8074420164")
