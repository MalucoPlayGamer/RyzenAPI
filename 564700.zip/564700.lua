-- Lua provided by RyzenAPI
-- Game: addappid(564700)

-- MAIN APPLICATION
addappid(564700)

-- MAIN APP DEPOTS / PACKAGES
addappid(564701, 1, "a49621bbc2127227ce04391bb044eb7b0d99db4659f89897cd1ffd25a356f1ef")
