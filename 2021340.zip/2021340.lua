-- Lua provided by RyzenAPI
-- Game: Game: Gordian Quest Soundtrack

-- MAIN APPLICATION
addappid(2021340)
-- Game: addappid(2021340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021341, 1, "c18119306ad4d15258bb4d26b2bc01e2e6e85f1998a9e94b50f161cd4b1b765c")
addappid(2021342, 1, "6f4438a828d6b63f9d2f843184582e4298df4ffe59cc73e89877fc1950e4f6a6")
