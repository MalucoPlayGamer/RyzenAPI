-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 4 The Ride

-- MAIN APPLICATION
addappid(259980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(259981, 1, "9ad6a1e214044929a74ed9fed1deffe8e88c08c32ad65e1f54f7d33d5d5341cc")

