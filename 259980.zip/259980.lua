-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 4 The Ride

-- MAIN APPLICATION
addappid(259980)
-- Game: addappid(259980)

-- MAIN APP DEPOTS / PACKAGES
addappid(259981, 1, "9ad6a1e214044929a74ed9fed1deffe8e88c08c32ad65e1f54f7d33d5d5341cc")
