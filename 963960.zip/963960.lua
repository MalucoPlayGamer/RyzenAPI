-- Lua provided by RyzenAPI 
-- Game: AppID 963960
addappid(963960)
addappid(963961, 1, "ba35b34caaba123ccbc26fcb957cba285b50a6e27407881356642070848299c8")
