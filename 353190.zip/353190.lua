-- Lua provided by RyzenAPI
-- Game: Bombshell

-- MAIN APPLICATION
addappid(353190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(353191, 1, "10d76da71b40a188f4cc3db1487e1af2e67a4cbb1267984e26383bbcd869b24b")
addappid(437410, 1, "a12a4634815cd94463e46a91fd0e7b955975ab987471ad4ade0e65116ebefeda")
addappid(437580, 0, "768a98383186276c4bdbd016ae5adbafaac3504f670dc642adc8f844df2b1fe0")

