-- Lua provided by RyzenAPI
-- Game: 717450

-- MAIN APPLICATION
addappid(717450)
addappid(990680)
addappid(990682)
-- Game: addappid(717450)

-- MAIN APP DEPOTS / PACKAGES
addappid(717451, 1, "f6ed7ea53a335e5fb205a8f861a2c88b793b7e430cf056a9143a5f4437cb139f")
addappid(717452, 1, "fc7b4f1008a6e6a0497c74757fc337a46d88d9dce44c519e42b4ab5fc9d5cd17")
addappid(990681, 0, "2ed1439a077023a1403614e3e90a2f239a73c9135af3a89655c0fd79e3799a6c")
