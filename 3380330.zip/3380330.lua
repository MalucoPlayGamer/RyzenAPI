-- Lua provided by RyzenAPI
-- Game: addappid(3380330)

-- MAIN APPLICATION
addappid(3380330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380330,0,"dfe41463b473dd2c10fd52fb071653454dca04aba21db65bfd1288f8334c8ce7")
