-- Lua provided by RyzenAPI
-- Game: 2491360

-- MAIN APPLICATION
addappid(2491360)
addappid(2800160)
-- Game: addappid(2491360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491361, 1, "1630bdb85c85893a7997319c03d8ec9e7c0dfd7ee1e97b829a0957f4c325981e")
