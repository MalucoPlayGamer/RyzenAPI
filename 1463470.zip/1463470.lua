-- Lua provided by RyzenAPI
-- Game: Ruff Night At The Gallery

-- MAIN APPLICATION
addappid(1463470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463471, 1, "12872a4e628040531059dac56f89413fa67d14eb65bc8404c9ec9e17e1cb5eb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
