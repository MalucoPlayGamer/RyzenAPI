-- Lua provided by RyzenAPI
-- Game: Ruff Night At The Gallery

-- MAIN APPLICATION
addappid(1463470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463471, 1, "12872a4e628040531059dac56f89413fa67d14eb65bc8404c9ec9e17e1cb5eb7")

