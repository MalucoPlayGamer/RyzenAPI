-- Lua provided by RyzenAPI
-- Game: Mad Bullets

-- MAIN APPLICATION
addappid(452860)
-- Game: addappid(452860)

-- MAIN APP DEPOTS / PACKAGES
addappid(452861, 1, "e81809bef340afadf771a30cc757170257c611846cb7e884462914b6cd7ab55c")
