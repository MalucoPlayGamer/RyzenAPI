-- Lua provided by RyzenAPI
-- Game: Mad Bullets

-- MAIN APPLICATION
addappid(452860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(452861, 1, "e81809bef340afadf771a30cc757170257c611846cb7e884462914b6cd7ab55c")

