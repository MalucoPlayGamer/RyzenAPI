-- Lua provided by RyzenAPI
-- Game: Pankapu

-- MAIN APPLICATION
addappid(418670)

-- MAIN APP DEPOTS / PACKAGES
addappid(418671, 1, "5e73365d17b0820504ebb38527644a3a02ad72df421079f031d474e0228ce12a")
addappid(418672, 1, "6433b5cac7b6cd90213ba24eed5d08cce167ce71e7b98169b7234334f54038f3")
addappid(418673, 1, "f6797c9da60b3ccd1a5d8d2f75d898e5ab027ca244422a5a04b2cd54d213b89a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(522750)
