-- Lua provided by RyzenAPI
-- Game: Leaves & Lanterns

-- MAIN APPLICATION
addappid(5079660) -- Leaves & Lanterns

-- MAIN APP DEPOTS / PACKAGES
addappid(5079661, 1, "53115f656c922449c45ed8b90ef2a40637a6e953c8567f6ca9b9bcb8687eae0a") -- Depot 5079661
