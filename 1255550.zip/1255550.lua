-- Lua provided by RyzenAPI
-- Game: Strange Creatures

-- MAIN APPLICATION
addappid(1255550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1255551, 1, "4ef0a731798b07c12e2c1385edaed091bab20d587321cbe59de5e2a0a1b0c96c")

