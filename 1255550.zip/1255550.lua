-- Lua provided by SkyAPI 
-- Game: Strange Creatures
addappid(1255550)
addappid(1255551, 1, "4ef0a731798b07c12e2c1385edaed091bab20d587321cbe59de5e2a0a1b0c96c")
