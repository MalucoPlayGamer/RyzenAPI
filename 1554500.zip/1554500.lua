-- Lua provided by RyzenAPI
-- Game: Sept jours, sept lieux, sept vies

-- MAIN APPLICATION
addappid(1554500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554501, 1, "90542d3f97d2d76d45346772ee3896a13ffd01f244c2b7809db8246ca3bf7c67")
addappid(1554502, 1, "984d4a34c6764617fe905468f0ca016fc1cc953c83da19ac9ac7a328944fc181")
