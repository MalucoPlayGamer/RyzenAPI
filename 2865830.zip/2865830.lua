-- Lua provided by RyzenAPI
-- Game: Weed Harvest

-- MAIN APPLICATION
addappid(2865830)
-- Game: addappid(2865830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865831, 1, "733d8d445bc76713ed724eed0ba96fcb493a21e10852389cdb9ef57d33edd3e7")
