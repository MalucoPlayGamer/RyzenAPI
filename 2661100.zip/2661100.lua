-- Lua provided by RyzenAPI
-- Game: Game: The Braves: Beginning

-- MAIN APPLICATION
addappid(2661100)
-- Game: addappid(2661100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661101, 1, "67c27ddd236e9c458782e5f99644a513cfaf68587c4cca0962c549633f9f4121")
