-- 4804480's Lua and Manifest Created by Hubcap Manifest
-- Age of Clicks
-- Created: July 21, 2026 at 23:14:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4804480) -- Age of Clicks
-- MAIN APP DEPOTS
addappid(4804481, 1, "bf11bc9590f79de0409498223453d180eb52b6e70e30c904ac65952f34bd5c58") -- Depot 4804481
setManifestid(4804481, "8828071690899977491", 599069306)