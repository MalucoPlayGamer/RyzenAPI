-- Lua provided by RyzenAPI
-- Game: iStorm

-- MAIN APPLICATION
addappid(610940)

-- MAIN APP DEPOTS / PACKAGES
addappid(610941, 1, "9f4e7051ff53bcb3786a3482eee11b4d91102d40c3712b9d94f9a0c4877309a6")
