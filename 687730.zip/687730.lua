-- Lua provided by RyzenAPI
-- Game: AppID 687730

-- MAIN APPLICATION
addappid(687730)

-- MAIN APP DEPOTS / PACKAGES
addappid(687731, 1, "378400317862015fa337980667d7d10dd3619ca0fc31da0ee3884ae66a494c7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
