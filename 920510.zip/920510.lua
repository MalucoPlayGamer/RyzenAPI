-- Lua provided by RyzenAPI
-- Game: addappid(920510)

-- MAIN APPLICATION
addappid(920510)

-- MAIN APP DEPOTS / PACKAGES
addappid(920511, 1, "b32c7e4674f3e26443db44eacd0b0af7d16c535dfa53ccb980e71e39157d1987")
