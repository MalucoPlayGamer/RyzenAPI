-- Lua provided by RyzenAPI
-- Game: Blade & Bones

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229005)
addappid(513370)
addappid(513371)
-- Game: addappid(513370)

-- MAIN APP DEPOTS / PACKAGES
addappid(513373,0,"1f526cd80229f72d9da3dac10f01510a1586b23c284eb18e2a2bd41844624cb9")
