-- Lua provided by RyzenAPI
-- Game: Game: Death Horizon: Reloaded

-- MAIN APPLICATION
addappid(1829370)
-- Game: addappid(1829370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829371, 1, "e2f4f3ecf5cf264e4698a87bf15aee49f97a8799f591de41749294846257a432")
