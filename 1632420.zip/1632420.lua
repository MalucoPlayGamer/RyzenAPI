-- Lua provided by RyzenAPI
-- Game: Risk Of Waifus

-- MAIN APPLICATION
addappid(1632420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632421, 1, "bdaf699c3e0781633f88e1f13830e8b03c368728f6b54181a013d771e99631ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
