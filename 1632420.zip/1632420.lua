-- Lua provided by SkyAPI 
-- Game: Risk Of Waifus
addappid(1632420)
addappid(1632421, 1, "bdaf699c3e0781633f88e1f13830e8b03c368728f6b54181a013d771e99631ef")
