-- Lua provided by RyzenAPI
-- Game: Risk Of Waifus

-- MAIN APPLICATION
addappid(1632420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632421, 1, "bdaf699c3e0781633f88e1f13830e8b03c368728f6b54181a013d771e99631ef")
