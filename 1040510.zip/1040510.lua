-- Lua provided by RyzenAPI
-- Game: Game: AppID 1040510

-- MAIN APPLICATION
addappid(1040510)
-- Game: addappid(1040510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040511, 1, "38dc0eba736d14847ca44fcf2cbe72223f2f1e83c88a929dde290bc68a1367d9")
addappid(1040512, 1, "69f7c9b2b0fe70c0f6d423a19fae8582de7d3e4f3aaca6258dfe49ff34f00356")
addappid(1040513, 1, "f0c1cc21e27955fcc2777c9d8500dbbc952b901e6217b1cf78037847b585e858")
