-- Lua provided by RyzenAPI
-- Game: The Settlers 7 : History Edition

-- MAIN APPLICATION
addappid(965320)
addappid(1001440)

-- MAIN APP DEPOTS / PACKAGES
addappid(965321,0,"0dd62aea7506ba33975159efebf8ba324bc0c4526bcf21d797735755e0e82d93")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
