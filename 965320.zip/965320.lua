-- Lua provided by RyzenAPI 
-- Game: The Settlers® 7 : History Edition
addappid(965320)
addappid(965321, 1, "0dd62aea7506ba33975159efebf8ba324bc0c4526bcf21d797735755e0e82d93")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
