-- Lua provided by RyzenAPI
-- Game: Corbid! A Colorful Adventure

-- MAIN APPLICATION
addappid(1034020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034021, 1, "978da30045458f55d523cc444c7b6d4c983b449202debcdb2f5669f5825ef369")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
