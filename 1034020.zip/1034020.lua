-- Lua provided by RyzenAPI 
-- Game: Corbid! A Colorful Adventure
addappid(1034020)
addappid(1034021, 1, "978da30045458f55d523cc444c7b6d4c983b449202debcdb2f5669f5825ef369")
