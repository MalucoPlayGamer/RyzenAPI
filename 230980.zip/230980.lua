-- Lua provided by RyzenAPI
-- Game: 230980

-- MAIN APPLICATION
addappid(230980)
-- Game: addappid(230980)

-- MAIN APP DEPOTS / PACKAGES
addappid(230981, 1, "7d4b6279b204b5987c17c5992e3fadcda6ca70071f65e3de385a928e3ad50a4d")
addappid(230982, 1, "b9560c1e12ef07e567fe62675d4cc60fa0310182ffdf3958215719a9ba4665f3")
addappid(230983, 1, "aa1096f1b017ac40e908b57522e634d5aacab53b49dddbcc3cf63d6c84c725d6")
