-- Lua provided by RyzenAPI
-- Game: addappid(2945220)

-- MAIN APPLICATION
addappid(2945220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945221, 1, "f391bdfb8e7c29e86a702f9e5e3d1a7a55858873210e2d3192a2b6511d53c9b9")
