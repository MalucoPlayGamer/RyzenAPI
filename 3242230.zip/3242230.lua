-- Lua provided by RyzenAPI
-- Game: 3242230

-- MAIN APPLICATION
addappid(3242230)
-- Game: addappid(3242230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242231, 1, "30e1e62ad0ece1aa5d1eeb5465d40d604d393724581c9a43a9c4b1a341cd1691")
