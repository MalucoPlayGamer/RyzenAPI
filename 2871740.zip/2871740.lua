-- Lua provided by RyzenAPI
-- Game: HustleGame

-- MAIN APPLICATION
addappid(2871740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871741, 1, "0b2fa6ba20d6a71a9126084f5f91cddb6c2f5e8f0e29ad756416cb2941c119dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
