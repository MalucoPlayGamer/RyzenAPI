-- Lua provided by RyzenAPI
-- Game: addappid(498710)

-- MAIN APPLICATION
addappid(498710)

-- MAIN APP DEPOTS / PACKAGES
addappid(498711, 1, "05cb00428292e8f3e5650ce0fbcf32a8e142281a0d22c490e09635b749be728d")
