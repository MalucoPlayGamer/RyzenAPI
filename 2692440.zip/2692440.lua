-- Lua provided by RyzenAPI
-- Game: LoveCraft

-- MAIN APPLICATION
addappid(2692440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692441, 1, "265ff61fb95c6ca10afe9ae21cc3e1bc01bb93754e8d658167e217de34002a00")
