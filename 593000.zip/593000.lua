-- Lua provided by RyzenAPI
-- Game: 593000

-- MAIN APPLICATION
addappid(593000)
-- Game: addappid(593000)

-- MAIN APP DEPOTS / PACKAGES
addappid(593001, 1, "3969b2dbb28f6885a96c88922e5580634c67fda6f3159425e6dd95667681efb4")
