-- Lua provided by RyzenAPI
-- Game: Governor of Poker 2

-- MAIN APPLICATION
addappid(70200)

-- MAIN APP DEPOTS / PACKAGES
addappid(70201, 1, "a1a310f8bedbe418536ee9cdc1a592cba36e54d8aea27e0c6ced02aaf84d0734")
