-- Lua provided by RyzenAPI
-- Game: Metallic Metronome

-- MAIN APPLICATION
addappid(1260830)
-- Game: addappid(1260830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260831, 1, "86c4a57cc1378727ad95246b38778d8b4f768b7f4628a94785d12ca02a50a2c3")
