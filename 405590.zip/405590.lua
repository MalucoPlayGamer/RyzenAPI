-- Lua provided by RyzenAPI
-- Game: Stone Tales

-- MAIN APPLICATION
addappid(405590)

-- MAIN APP DEPOTS / PACKAGES
addappid(405591, 1, "8cff1fad408c41e3d62017a142266cf2d627888189ca82b8de42cd336c17ec43")

