-- Lua provided by SkyAPI 
-- Game: Stone Tales
addappid(405590)
addappid(405591, 1, "8cff1fad408c41e3d62017a142266cf2d627888189ca82b8de42cd336c17ec43")
