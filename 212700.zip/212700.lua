-- Lua provided by RyzenAPI
-- Game: Game: Party of Sin

-- MAIN APPLICATION
addappid(212700)
-- Game: addappid(212700)

-- MAIN APP DEPOTS / PACKAGES
addappid(212701, 1, "dcf023fdc64666286ad8f4930f3e6754f69d41cda25b1d1dc61474161dbd691c")
addappid(212702, 1, "e8777c365ce11b6f48d96241242ad0c66a8196609b73e87d5db23eab58bfe4b2")
addappid(212704, 1, "f18fa2af26db47d5c7ad2f8f220eeb2079afeda3fc5a96cc73ab75d190d10907")
addappid(212705, 1, "2965f49376ea13bcc5c61cad436284af4d3d709a4ef8eac7e4ae401acd702a54")
addappid(212706, 1, "b573a1c432722813dcc3617c2f844892f27c8350af5ba4b7c634515d50822095")
addappid(212707, 1, "8ba63e4eb34353bf28a1dbeb0dd7fff8d4cb9e6eb41fbc6075743117751b9059")
addappid(212708, 1, "f48731806bcff0d6bc8ba9b5414a4512712e38768fff7fc40e50a293d8d689e4")
addappid(212710, 0, "2b6e6aba9e7f2b73ed991a40e6cdd16c58aff5b68886d5a918e4b689a23ff94a")
