-- Lua provided by RyzenAPI
-- Game: Terrene - An Evidence Of Life Game

-- MAIN APPLICATION
addappid(1472600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472601, 1, "a23bf1bffa00d54b6237af6bdb88270be5787eb0376aa5375ed7cd180765389e")

