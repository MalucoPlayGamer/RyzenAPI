-- Lua provided by RyzenAPI
-- Game: addappid(2900760)

-- MAIN APPLICATION
addappid(2900760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900761, 1, "32edb5b89f3f3c4a2f7eab6333511aa6afa02e0fb5976b5bbbe08e4f1dcfbbf7")
