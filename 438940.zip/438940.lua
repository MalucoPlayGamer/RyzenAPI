-- Lua provided by RyzenAPI
-- Game: XBlaze Lost: Memories

-- MAIN APPLICATION
addappid(438940)

-- MAIN APP DEPOTS / PACKAGES
addappid(438941, 1, "343e80ccf026301a47919c56e3b8b10842172114db67aa32e14b917965987f2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
