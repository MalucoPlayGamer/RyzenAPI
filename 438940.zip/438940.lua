-- Lua provided by RyzenAPI
-- Game: XBlaze Lost: Memories

-- MAIN APPLICATION
addappid(438940)
-- Game: addappid(438940)

-- MAIN APP DEPOTS / PACKAGES
addappid(438941, 1, "343e80ccf026301a47919c56e3b8b10842172114db67aa32e14b917965987f2e")
