-- Lua provided by RyzenAPI
-- Game: Minishoot' Adventure Demo

-- MAIN APPLICATION
addappid(1906270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906271, 1, "6977c5ba294ac52997326836161ba7756da02dd050297cdc2ca58fa1bc893142")

