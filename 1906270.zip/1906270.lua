-- Lua provided by RyzenAPI 
-- Game: Minishoot' Adventure Demo
addappid(1906270)
addappid(1906271, 1, "6977c5ba294ac52997326836161ba7756da02dd050297cdc2ca58fa1bc893142")
