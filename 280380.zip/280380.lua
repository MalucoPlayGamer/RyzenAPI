-- Lua provided by RyzenAPI
-- Game: Uprising44: The Silent Shadows

-- MAIN APPLICATION
addappid(280380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(280381, 1, "c215a7f565b4da55d1bad2e3f2c8f7d0c30662b63c8d3cd48ade50c94a2121c8")

