-- Lua provided by SkyAPI 
-- Game: Uprising44: The Silent Shadows
addappid(280380)
addappid(280381, 1, "c215a7f565b4da55d1bad2e3f2c8f7d0c30662b63c8d3cd48ade50c94a2121c8")
