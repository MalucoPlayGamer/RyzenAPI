-- Lua provided by RyzenAPI
-- Game: 黑西游 Demo

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(2574490)
addappid(2574495)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574492,0,"3c6990fe82a64123d75babb50311c18891ecd6978aa0a1d90cff9258cb6732e4")

