-- Lua provided by RyzenAPI
-- Game: Game: AppID 392330

-- MAIN APPLICATION
addappid(392330)
-- Game: addappid(392330)

-- MAIN APP DEPOTS / PACKAGES
addappid(392331, 1, "2abc4a379f2cf6c335e77d4d9da47430e82836cb651c6ac9e49a63fe798aaed1")
