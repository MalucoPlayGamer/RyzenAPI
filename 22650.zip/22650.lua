-- Lua provided by RyzenAPI
-- Game: Alien Breed 2: Assault

-- MAIN APPLICATION
addappid(22650)

-- MAIN APP DEPOTS / PACKAGES
addappid(22651, 1, "ff3ec88304099962e2cda3e099bc1e5449e72353b302df7c13265b659fd3cd49")
addappid(22652, 1, "862b61bf30c5c084003fbd15dbf6ffa0a25996633d76840e40b0fcb70f8a85d7")
addappid(22653, 1, "e77a6b17b0afed720f17ddd8aee15f1bb992479c0df984a38d721ae35e0fd720")
addappid(22654, 1, "dad6e8cb0f5790a87c5fd2ccb0e70cb5f8490ad70904e95801806a5df338ac18")
addappid(22655, 1, "b079b73dd50678a5b5baa1395415fb0dd90640a70c3a9b12b39da1c25e2e1820")
addappid(22656, 1, "d45aef7a02a71756f2a8bacda7f96f5e3eef3bc264189e5ffa791f1ae52886ad")
addappid(22657, 1, "21d0db07e236bfe23279d8110ae58a3a7443f48c081d0f45564ff4e715896de6")
