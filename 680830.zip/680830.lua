-- Lua provided by RyzenAPI
-- Game: 680830

-- MAIN APPLICATION
addappid(680830)
-- Game: addappid(680830)

-- MAIN APP DEPOTS / PACKAGES
addappid(680831, 1, "1d447a598413d592fc7aef1038fa036a1a3c7ca2ede04dd3f1a822174c4750ac")
