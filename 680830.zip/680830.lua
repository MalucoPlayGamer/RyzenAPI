-- Lua provided by SkyAPI 
-- Game: Wait! Life is beautiful!
addappid(680830)
addappid(680831, 1, "1d447a598413d592fc7aef1038fa036a1a3c7ca2ede04dd3f1a822174c4750ac")
