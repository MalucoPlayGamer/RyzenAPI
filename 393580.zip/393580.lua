-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(393580)
-- Game: addappid(393580)

-- MAIN APP DEPOTS / PACKAGES
addappid(393580,0,"628c163c87b7bac4a376f928b2f7187534048fb3545f46f3f3d8e295fc828949")
