-- Lua provided by RyzenAPI
-- Game: Ten Seconds Trillion

-- MAIN APPLICATION
addappid(2342280)
-- Game: addappid(2342280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342281, 1, "abc82e7c495b91e4e454ba911e06c0621a63eb8647c5d1196337e537e71f1326")
