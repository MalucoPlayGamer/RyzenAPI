-- Lua provided by SkyAPI 
-- Game: Ten Seconds Trillion
addappid(2342280)
addappid(2342281, 1, "abc82e7c495b91e4e454ba911e06c0621a63eb8647c5d1196337e537e71f1326")
