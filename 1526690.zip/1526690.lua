-- Lua provided by RyzenAPI
-- Game: Chinese Bull

-- MAIN APPLICATION
addappid(1526690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526691, 1, "9f98c73fc34e139b50a8bebdc17f4ec7b269c3cb6f566f1bdc4500359ee240d8")

