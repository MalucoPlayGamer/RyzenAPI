-- Lua provided by SkyAPI 
-- Game: Atelier Escha & Logy: Alchemists of the Dusk Sky DX
addappid(1152310)
addappid(1152311, 1, "8e5e5ab894bae94cfb0bb18e52b736d7443be9ea88766a765242569213be4bbe")
