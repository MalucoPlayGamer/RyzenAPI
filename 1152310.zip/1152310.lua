-- Lua provided by RyzenAPI
-- Game: addappid(1152310)

-- MAIN APPLICATION
addappid(1152310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152311, 1, "8e5e5ab894bae94cfb0bb18e52b736d7443be9ea88766a765242569213be4bbe")
