-- Lua provided by RyzenAPI
-- Game: Atelier Escha & Logy: Alchemists of the Dusk Sky DX

-- MAIN APPLICATION
addappid(1152310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152311, 1, "8e5e5ab894bae94cfb0bb18e52b736d7443be9ea88766a765242569213be4bbe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
