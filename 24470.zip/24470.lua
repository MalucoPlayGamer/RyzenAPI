-- Lua provided by RyzenAPI
-- Game: AppID 24470

-- MAIN APPLICATION
addappid(24470)
-- Game: addappid(24470)

-- MAIN APP DEPOTS / PACKAGES
addappid(24471, 1, "0aa8423c4aa0b3afc2f68478abcef83ca9e438cb151b8febcb79d08879d55b0b")
addappid(24472, 1, "38ada277410d22ac28430dae78c01cf605d3b51e2bd8b5b523ea220ffe868bd6")
