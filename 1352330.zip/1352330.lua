-- Lua provided by RyzenAPI
-- Game: AppID 1352330

-- MAIN APPLICATION
addappid(1352330)
-- Game: addappid(1352330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352331, 1, "d9a76e33e7a222522d2a1486673cb6a697aad81f60cda4afe8c46097d473698a")
