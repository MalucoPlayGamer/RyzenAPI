-- Lua provided by RyzenAPI
-- Game: Zoo 2: Animal Park

-- MAIN APPLICATION
addappid(1352330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1352331, 1, "d9a76e33e7a222522d2a1486673cb6a697aad81f60cda4afe8c46097d473698a")
