-- Lua provided by SkyAPI 
-- Game: Maverta
addappid(1799570)
addappid(1799571, 1, "246d57f4db74f3fe41fe0b9abce57ea0700572c69a89ea4a1b3e7a47b7e6e75a")
addappid(1799572, 1, "325b0d9145c2a0d4f0ab00532e42521965fcd455006127da5ef0bf4b5ae0ac09")
