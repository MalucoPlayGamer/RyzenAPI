-- Lua provided by RyzenAPI
-- Game: Game: Maverta

-- MAIN APPLICATION
addappid(1799570)
-- Game: addappid(1799570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799571, 1, "246d57f4db74f3fe41fe0b9abce57ea0700572c69a89ea4a1b3e7a47b7e6e75a")
addappid(1799572, 1, "325b0d9145c2a0d4f0ab00532e42521965fcd455006127da5ef0bf4b5ae0ac09")
