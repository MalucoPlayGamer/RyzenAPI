-- Lua provided by RyzenAPI
-- Game: Prismatix

-- MAIN APPLICATION
addappid(805440)
-- Game: addappid(805440)

-- MAIN APP DEPOTS / PACKAGES
addappid(805441, 1, "67b8e65ed770c1e26c1d4347c17b2a36b7eb326621bcce48bd29e2cc9752d5f9")
addappid(805442, 1, "354a3feebbfc1bbac12d92bd412172e4eb86f6f34513e8f8d31b228c3f21930d")
