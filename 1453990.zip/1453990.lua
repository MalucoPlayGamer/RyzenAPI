-- Lua provided by RyzenAPI 
-- Game: INSPIRE
addappid(1453990)
addappid(1453991, 1, "7c9158b7a32b36adae163f1963817a08b98cb53553c14de315e6fce9d0d0d961")
