-- Lua provided by RyzenAPI
-- Game: Sweet Dream Succubus - Nightmare Edition

-- MAIN APPLICATION
addappid(1103490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103491, 1, "287bec314cb96bee8cdf9ebe406a9a214f6ac376652aa80515859f9ed250d196")
