-- Lua provided by RyzenAPI
-- Game: King Dragon Saga

-- MAIN APPLICATION
addappid(1517160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517161, 1, "27de55f2e60253bd896ca7525ceb4f1bdb6a2acaa63c828afee4ea0d347161c1")
