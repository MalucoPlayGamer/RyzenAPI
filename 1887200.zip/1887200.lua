-- Lua provided by RyzenAPI 
-- Game: Mechaguard
addappid(1887200)
addappid(1887201, 1, "5eac24fd6d3a5025da05a6dcd47b9a06d266d12b0e9da31f005adef9a73618e4")
