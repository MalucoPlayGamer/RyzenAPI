-- Lua provided by RyzenAPI
-- Game: Game: Blackout Z: Slaughterhouse Edition

-- MAIN APPLICATION
addappid(729660)
-- Game: addappid(729660)

-- MAIN APP DEPOTS / PACKAGES
addappid(729661, 1, "7c5962414c5c1531e544935eed72583424f7a790987eb14d3fdf246a73e59514")
addappid(729662, 1, "1a13dbd4c700f453550bf69bea8d2d94644f46d7c98393975f2a4c78997fd4ee")
addappid(738810, 0, "28fe2b37d5476d4fd783e93865c4afc48b18d897738d3695de0254a2938cb730")
