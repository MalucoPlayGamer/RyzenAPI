-- Lua provided by RyzenAPI
-- Game: ZOMBIE RAID: No One Survives DEMO

-- MAIN APPLICATION
addappid(2888150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888151, 1, "7f8afcb261f59c677bdc2c7727b9faf878b39dc30bcda9a4ed42577a9ff260f7")
