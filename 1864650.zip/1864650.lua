-- Lua provided by SkyAPI 
-- Game: Dragon Princess Anastasia
addappid(1864650)
addappid(1864651, 1, "8eaa6b6c23453be482c6ab683a76173853876c9d08ac3f4c5eb1a24adab9ea0a")
addappid(2259490)
