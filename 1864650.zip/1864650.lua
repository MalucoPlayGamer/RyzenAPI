-- Lua provided by RyzenAPI
-- Game: Game: Dragon Princess Anastasia

-- MAIN APPLICATION
addappid(1864650)
addappid(2259490)
-- Game: addappid(1864650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864651, 1, "8eaa6b6c23453be482c6ab683a76173853876c9d08ac3f4c5eb1a24adab9ea0a")
