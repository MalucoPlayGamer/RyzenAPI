-- Lua provided by RyzenAPI
-- Game: 662390

-- MAIN APPLICATION
addappid(662390)
-- Game: addappid(662390)

-- MAIN APP DEPOTS / PACKAGES
addappid(662391, 1, "cd3c1898ccb4dde8f1c0a2126079d7c344aaef4963e70fdb70fc3af635d8ac0e")
