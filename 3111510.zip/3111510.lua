-- Lua provided by RyzenAPI
-- Game: Aesthetic Clicker

-- MAIN APPLICATION
addappid(3111510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111511, 1, "deb003786fe8dc34262d3677c0dbf98f65e7af1cf8364d0bed510711437a65c3")
