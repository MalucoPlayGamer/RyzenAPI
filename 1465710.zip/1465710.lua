-- Lua provided by RyzenAPI
-- Game: Game: 白昼梦 · 心象病院

-- MAIN APPLICATION
addappid(1465710)
-- Game: addappid(1465710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465711, 1, "ae31ebb877574ad2eb3cefc1e960c4fffe0257bcc29cd99d9009780d924437d5")
addappid(1465712, 1, "502d1f027f302102c2f66a87ce8a0871c3a4c2f20fb07abc77a61923861357a2")
