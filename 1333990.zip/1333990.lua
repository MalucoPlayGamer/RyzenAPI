-- Lua provided by RyzenAPI
-- Game: Saving Animals

-- MAIN APPLICATION
addappid(1333990)
-- Game: addappid(1333990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333991, 1, "a9d98390911e65b180ffc8aa8c83ef956d118a5f8d64e9ded4cc04184d956d40")
