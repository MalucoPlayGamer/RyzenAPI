-- Lua provided by RyzenAPI
-- Game: Game: The Amazing Shinsengumi: Heroes in Love

-- MAIN APPLICATION
addappid(494440)
-- Game: addappid(494440)

-- MAIN APP DEPOTS / PACKAGES
addappid(494441, 1, "5c4953a8cf3d1aa74f166901ab3cb50bb8649f803687f5fc3a1ed026c892ef1e")
