-- Lua provided by RyzenAPI
-- Game: The Amazing Shinsengumi: Heroes in Love

-- MAIN APPLICATION
addappid(494440)

-- MAIN APP DEPOTS / PACKAGES
addappid(494441, 1, "5c4953a8cf3d1aa74f166901ab3cb50bb8649f803687f5fc3a1ed026c892ef1e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
