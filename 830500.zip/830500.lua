-- Lua provided by RyzenAPI
-- Game: The Blobs Fight

-- MAIN APPLICATION
addappid(830500)

-- MAIN APP DEPOTS / PACKAGES
addappid(830501, 1, "88c6818a612eef0c520b7a0f5718204bed78788f127145d9af3a9a3e71881b6c")
