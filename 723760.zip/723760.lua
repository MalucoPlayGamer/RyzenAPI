-- Lua provided by RyzenAPI
-- Game: Steamburg

-- MAIN APPLICATION
addappid(723760)

-- MAIN APP DEPOTS / PACKAGES
addappid(723761, 1, "bd6e3ff31ec82644e24fcb2eb39fc7f7450989de4ddff199c3293181d0130df0")
