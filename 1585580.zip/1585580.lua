-- Lua provided by RyzenAPI
-- Game: AppID 1585580

-- MAIN APPLICATION
addappid(1585580)
addappid(1589850)
addappid(1589851)
addappid(1589852)
addappid(1589853)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585581, 1, "56fc63033d18b6c154d5a00e3549a5b398e43dd5a36e68791d15b592b6fd903d")

