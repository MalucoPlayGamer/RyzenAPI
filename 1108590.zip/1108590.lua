-- Lua provided by RyzenAPI
-- Game: Eldest Souls

-- MAIN APPLICATION
addappid(1108590)
-- Game: addappid(1108590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108591, 1, "4283f4f88bf535aacb3665900a669e61b0fbb8b7841eca1d59ec274a99afb19b")
