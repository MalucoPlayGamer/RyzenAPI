-- Lua provided by RyzenAPI 
-- Game: AppID 707680
addappid(707680)
addappid(707681, 1, "7793a65cc6f5c086f8e81dc7ba6047727a9823e80e8cf0aaafdc84c0f09a0124")
addappid(707682, 1, "a5261fe181405ea26358da35f9676d4ee0a0232a372aa6b2d73f2504d71a39fd")
addappid(707683, 1, "f40588fb448d899ae2163afbea2a120f9ed97ee73563341f9d2a91943cb42c2c")
addappid(1025590)
