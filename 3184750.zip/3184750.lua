-- Lua provided by RyzenAPI
-- Game: Five Nights at Restroom 2: A Hellish Soundtrack

-- MAIN APPLICATION
addappid(3184750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184751, 1, "0778c4b842d584148282224491ad802595ac9373a6b54622619588b4ba2ff789")

