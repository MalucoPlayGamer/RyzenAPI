-- Lua provided by RyzenAPI
-- Game: 救公主？救个屁！ Save the princess？Save a fart！

-- MAIN APPLICATION
addappid(1819020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819021, 1, "569193fd34541c820cdc0f7c7b90e27ac9d3395a89575fb48b80763cf9b13e96")

