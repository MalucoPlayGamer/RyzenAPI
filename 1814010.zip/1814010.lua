-- Lua provided by RyzenAPI
-- Game: Stuck In Time

-- MAIN APPLICATION
addappid(1814010)
-- Game: addappid(1814010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814011, 1, "eef8423a0126ce8bfeffcaa20a89c549b9950adf9484155de5d21ad75b0c1bd7")
