-- Lua provided by RyzenAPI
-- Game: Innocence Or Money - Prelude

-- MAIN APPLICATION
addappid(1722270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722271, 1, "f502e6c2037e027205b48f10009cae49a05be9e569393dd37a883a82f8ced0b9")
