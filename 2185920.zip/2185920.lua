-- Lua provided by RyzenAPI
-- Game: addappid(2185920)

-- MAIN APPLICATION
addappid(2185920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185921, 1, "69cba2535a71dc081450077a785beba8f32219b8dc6063ff596256ba01e7892c")
