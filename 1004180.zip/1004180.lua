-- Lua provided by RyzenAPI
-- Game: Boundary VR

-- MAIN APPLICATION
addappid(1004180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004181, 1, "0e19fc997ad52497d0c9a77f549231acac8db75452c796198b18b3b0129f9383")

