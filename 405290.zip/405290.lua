-- Lua provided by RyzenAPI
-- Game: Game: AppID 405290

-- MAIN APPLICATION
addappid(405290)
-- Game: addappid(405290)

-- MAIN APP DEPOTS / PACKAGES
addappid(405291, 1, "12d9a3b5c07a42c7725ac40c2710728fbb2fedd02f9f5d4ff1c029213d6f9ca3")
addappid(405292, 1, "d2f24d4f555daf4933ed0fc65dec95d2f9a95c537fa393b3418b6ac7c3cbd007")
addappid(405293, 1, "99c6a545d2b20b6ea274381d727cd3cd9d8553e36630af7118c69adb8420a310")
