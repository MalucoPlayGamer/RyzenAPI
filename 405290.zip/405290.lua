-- Lua provided by RyzenAPI
-- Game: AppID 405290

-- MAIN APPLICATION
addappid(405290)

-- MAIN APP DEPOTS / PACKAGES
addappid(405291, 1, "12d9a3b5c07a42c7725ac40c2710728fbb2fedd02f9f5d4ff1c029213d6f9ca3")
addappid(405292, 1, "d2f24d4f555daf4933ed0fc65dec95d2f9a95c537fa393b3418b6ac7c3cbd007")
addappid(405293, 1, "99c6a545d2b20b6ea274381d727cd3cd9d8553e36630af7118c69adb8420a310")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
