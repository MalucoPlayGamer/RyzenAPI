-- Lua provided by RyzenAPI
-- Game: 1254160

-- MAIN APPLICATION
addappid(1254160)
-- Game: addappid(1254160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254161, 1, "670ce32e68be1815c58e1a24a8ab5f97ece88bc2e2a84824ed04dd4943ccfb68")
