-- Lua provided by RyzenAPI
-- Game: Silenthead: Ducks hunt

-- MAIN APPLICATION
addappid(1333420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333421, 1, "234b15117743032dfb7d59915fb405416a49a78148bd435cb9a7d776cc58d59d")
