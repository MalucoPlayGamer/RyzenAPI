-- Lua provided by RyzenAPI
-- Game: Orbit-X

-- MAIN APPLICATION
addappid(1625130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625131, 1, "7922ece03167b963d47d2868b065894047f0a408c968300fa5bb2c0cb2edb9bf")

