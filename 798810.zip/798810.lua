-- Lua provided by RyzenAPI
-- Game: Natural Locomotion

-- MAIN APPLICATION
addappid(798810)

-- MAIN APP DEPOTS / PACKAGES
addappid(798811, 1, "a96b9d9fdc61844aa84a2009e42960c70ea8537a371fed9650a30f765e535bd4")
addappid(798813, 1, "4b082b3203af7253974e49cbc57fc223615e6b9fa239ebf6b98fbf5e2a6f6075")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
