-- Lua provided by RyzenAPI
-- Game: OplitisAV

-- MAIN APPLICATION
addappid(1741420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1741421, 1, "c6c0e0c9e99f6c244d5a28d4e9ee71b471a2d192a7213397163652eb3c487d26")

