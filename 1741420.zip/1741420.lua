-- Lua provided by RyzenAPI
-- Game: Game: OplitisAV

-- MAIN APPLICATION
addappid(1741420)
-- Game: addappid(1741420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741421, 1, "c6c0e0c9e99f6c244d5a28d4e9ee71b471a2d192a7213397163652eb3c487d26")
