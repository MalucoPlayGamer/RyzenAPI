-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Saints & Sinners

-- MAIN APPLICATION
addappid(916840)
addappid(1237830)

-- MAIN APP DEPOTS / PACKAGES
addappid(916841, 1, "f127aed00b61e75cbf38a72bd951cc5aa5cf670555c7fbf696f5181717ece843")

