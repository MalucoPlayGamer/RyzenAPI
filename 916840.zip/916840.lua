-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Saints & Sinners

-- MAIN APPLICATION
addappid(916840)
addappid(1207100)
addappid(1207620)
addappid(1212210)
addappid(1212211)
addappid(1212212)
addappid(1212213)
addappid(1212214)
addappid(1212215)
addappid(1212216)
addappid(1212217)
addappid(1212218)
addappid(1212219)
addappid(1225400)
addappid(1237830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(916841,0,"f127aed00b61e75cbf38a72bd951cc5aa5cf670555c7fbf696f5181717ece843")
addappid(1223630,0,"815001725c619c2217d8a0c4e295fbe1342ca6c745cf0f382a5fd023af710eac")

