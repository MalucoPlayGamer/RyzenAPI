-- Lua provided by RyzenAPI
-- Game: Miska's Cave

-- MAIN APPLICATION
addappid(1517830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517831, 1, "c2d096c36b375ad31df8f1fe141e10c89a663bb460ec5a47ce796f03c1427a3a")
addappid(1517832, 1, "534554f719a953c33ecb520b2f41cea35112be59f1f89cac7b7b9ed0bc9c2eb0")
addappid(1517833, 1, "9540f7fe8d2780d9daba213723a5fec08d170cde8754ed367e65e5651ea26955")
