-- Lua provided by RyzenAPI
-- Game: 1048872

-- MAIN APPLICATION
addappid(1048872)
-- Game: addappid(1048872)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048872,0,"82f270f13f36ff49daeecea9ec9d96aa07b02c773adc42173247c843d0ee8127")
