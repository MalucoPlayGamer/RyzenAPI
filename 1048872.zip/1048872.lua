-- Lua provided by RyzenAPI
-- Game: Beat Saber - Tokyo Machine - "EPIC"

-- MAIN APPLICATION
addappid(1048872)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048872,0,"82f270f13f36ff49daeecea9ec9d96aa07b02c773adc42173247c843d0ee8127")

