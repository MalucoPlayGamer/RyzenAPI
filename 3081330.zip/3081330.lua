-- Lua provided by RyzenAPI
-- Game: addappid(3081330)

-- MAIN APPLICATION
addappid(3081330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081331, 1, "c46a602c1f61bbe055ef09b6610a47a962741ea4c18ed4dbeefbc5f71df0237b")
