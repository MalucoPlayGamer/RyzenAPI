-- Lua provided by RyzenAPI
-- Game: Bythzkel-Sombréa🤗😹👩‍🦽​​📶​

-- MAIN APPLICATION
addappid(3081330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081331, 1, "c46a602c1f61bbe055ef09b6610a47a962741ea4c18ed4dbeefbc5f71df0237b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3132500)
addappid(3504060)
addappid(4254370)
