-- Lua provided by RyzenAPI
-- Game: Verdict Guilty - 유죄 평결

-- MAIN APPLICATION
addappid(449210)

-- MAIN APP DEPOTS / PACKAGES
addappid(449211, 1, "66624c01f19ab962e001077d2343ba510685d840896dda7d3d91ba9d7a0867bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
