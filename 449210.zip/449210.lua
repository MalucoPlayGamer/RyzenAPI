-- Lua provided by RyzenAPI
-- Game: Game: Verdict Guilty - 유죄 평결

-- MAIN APPLICATION
addappid(449210)
-- Game: addappid(449210)

-- MAIN APP DEPOTS / PACKAGES
addappid(449211, 1, "66624c01f19ab962e001077d2343ba510685d840896dda7d3d91ba9d7a0867bc")
