-- Lua provided by RyzenAPI
-- Game: Days Gone

-- MAIN APPLICATION
addappid(1259420)
addappid(3238470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259421, 1, "3a92a76d80b16038abe5b2831f554a22120535ab039dbde663a70c8b52afe11b")
