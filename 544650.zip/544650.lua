-- Lua provided by RyzenAPI
-- Game: Sacred Almanac Traces of Greed

-- MAIN APPLICATION
addappid(544650)
-- Game: addappid(544650)

-- MAIN APP DEPOTS / PACKAGES
addappid(544651, 1, "89f21743c0bafabd2134652238a7acd44735cc49bffd09437c9b49f7f453b6bf")
