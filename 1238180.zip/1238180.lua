-- Lua provided by RyzenAPI 
-- Game: AppID 1238180
addappid(1238180)
addappid(1238181, 1, "adf68aa1cf854055dfa55f422aa5133db816267542600dac3287fddb2a74521f")
addappid(1238182, 1, "3b23e1dc857723107f6fd5dac73b221940ff87b47f975c1b8fc3b0758694e0f6")
