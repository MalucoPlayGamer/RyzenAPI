-- Lua provided by RyzenAPI
-- Game: addappid(1812090)

-- MAIN APPLICATION
addappid(1812090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812091, 1, "ccf3f424fd3f7eff01a1dced9fd660930fd1652c42c0fb6f9064a6a043752c81")
