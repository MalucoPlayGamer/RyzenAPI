-- Lua provided by RyzenAPI
-- Game: Escape Academy

-- MAIN APPLICATION
addappid(1812090)
addappid(1934530)
addappid(2023370)
addappid(2067480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812091,0,"ccf3f424fd3f7eff01a1dced9fd660930fd1652c42c0fb6f9064a6a043752c81")

