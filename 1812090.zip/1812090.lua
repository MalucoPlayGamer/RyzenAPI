-- Lua provided by RyzenAPI 
-- Game: Escape Academy
addappid(1812090)
addappid(1812091, 1, "ccf3f424fd3f7eff01a1dced9fd660930fd1652c42c0fb6f9064a6a043752c81")
