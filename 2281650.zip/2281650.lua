-- Lua provided by RyzenAPI
-- Game: Game: An Ankou

-- MAIN APPLICATION
addappid(2281650)
-- Game: addappid(2281650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281651, 1, "4b1720a93b1eb2ab73709b5a95bb1e7878486ee17352f127e08e7768950a46b9")
