-- Lua provided by RyzenAPI 
-- Game: Sugar Mess - Let's Play Jolly Battle Demo
addappid(2597510)
addappid(2597511, 1, "07129fe77eb30495e22e1889fea90508d3400a3906a65589ac07764724ab4d98")
