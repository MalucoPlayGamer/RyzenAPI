-- Lua provided by RyzenAPI
-- Game: 2170960

-- MAIN APPLICATION
addappid(2170960)
-- Game: addappid(2170960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170961, 1, "7077b4ec99527c263b0e9b57ed507781c5c29d5e0b07f4bb3078d881fc62b911")
