-- Lua provided by RyzenAPI
-- Game: 枪神细胞 Gunnery Cell

-- MAIN APPLICATION
addappid(2481610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481611, 1, "307146dab340b04b76e5de748e18930fe283fecd31c6c5e2d603a7c7c7d2cf37")

