-- Lua provided by RyzenAPI
-- Game: ATLYSS

-- MAIN APPLICATION
addappid(2768430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2768431, 1, "2bd641c21a3ea24a52b13cb9892f040c0664deb5017a14eb5a5e89056edb29a7")

