-- Lua provided by RyzenAPI
-- Game: Game: ATLYSS

-- MAIN APPLICATION
addappid(2768430)
-- Game: addappid(2768430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768431, 1, "2bd641c21a3ea24a52b13cb9892f040c0664deb5017a14eb5a5e89056edb29a7")
