-- Lua provided by RyzenAPI
-- Game: 2910850

-- MAIN APPLICATION
addappid(2910850)
-- Game: addappid(2910850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910851, 1, "49d613e1d3f33a3ef4202b071d2c329a99d6fce9ecc6c02d4b499cf012db35f4")
