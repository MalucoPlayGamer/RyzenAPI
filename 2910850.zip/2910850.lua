-- Lua provided by RyzenAPI
-- Game: Ghost For Hire

-- MAIN APPLICATION
addappid(2910850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2910851, 1, "49d613e1d3f33a3ef4202b071d2c329a99d6fce9ecc6c02d4b499cf012db35f4")

