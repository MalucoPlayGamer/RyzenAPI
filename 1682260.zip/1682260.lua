-- Lua provided by RyzenAPI
-- Game: Black Sheep

-- MAIN APPLICATION
addappid(1682260)
-- Game: addappid(1682260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682261, 1, "95e7bde181824455f2c9d4b4e9cdf2a958e5a27b46bffd5c16ba30f2e3d23a1b")
