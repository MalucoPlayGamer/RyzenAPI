-- Lua provided by SkyAPI 
-- Game: Black Sheep
addappid(1682260)
addappid(1682261, 1, "95e7bde181824455f2c9d4b4e9cdf2a958e5a27b46bffd5c16ba30f2e3d23a1b")
