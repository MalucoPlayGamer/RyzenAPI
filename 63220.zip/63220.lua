-- Lua provided by RyzenAPI
-- Game: Game: AppID 63220

-- MAIN APPLICATION
addappid(63220)
-- Game: addappid(63220)

-- MAIN APP DEPOTS / PACKAGES
addappid(63221, 1, "39ceb8be0dbe4aa80779efee16254d150937948f0f332fefdaf717ba403fb8e9")
