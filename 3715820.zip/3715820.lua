-- Lua provided by RyzenAPI
-- Game: Rise of the Successor

-- MAIN APPLICATION
addappid(3715820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3715821, 1, "c1fbbc3cf58902666ebf154cfd37368e14bfc2b34d8cf160fcd5654dee834b2f")

