-- Lua provided by RyzenAPI
-- Game: RealityIQ | الواقع

-- MAIN APPLICATION
addappid(3763770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3763771, 1, "a54b6be4bf66453c2d1d0349bce4efe08683d0ed572acbbd459c4438fb0db8fc")

