-- Lua provided by RyzenAPI
-- Game: 3116810

-- MAIN APPLICATION
addappid(3116810)
-- Game: addappid(3116810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116811, 1, "d0c62ba169c449a6e7260840d6d6dce47740ca3609a09d1638516a5ee7c0d410")
