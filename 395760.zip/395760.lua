-- Lua provided by RyzenAPI
-- Game: AppID 395760

-- MAIN APPLICATION
addappid(395760)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(395761, 1, "baae0772854201dc2cdfee355414f1805353ff8889e8273943fae3f7124821ae")

