-- Lua provided by RyzenAPI
-- Game: addappid(395760)

-- MAIN APPLICATION
addappid(395760)

-- MAIN APP DEPOTS / PACKAGES
addappid(395761, 1, "baae0772854201dc2cdfee355414f1805353ff8889e8273943fae3f7124821ae")
