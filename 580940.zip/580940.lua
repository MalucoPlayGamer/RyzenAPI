-- Lua provided by RyzenAPI
-- Game: addappid(580940)

-- MAIN APPLICATION
addappid(580940)

-- MAIN APP DEPOTS / PACKAGES
addappid(580942,0,"ef111450139fd72a4178a06f159f82e9c693d9fee9a4ab7435e7627d22f3663c")
