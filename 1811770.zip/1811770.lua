-- Lua provided by RyzenAPI
-- Game: addappid(1811770)

-- MAIN APPLICATION
addappid(1811770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811770,0,"64376381832d27b0c1c22e0b0512fd37eca33c1795c3c87f48abcc21a40e2ffd")
