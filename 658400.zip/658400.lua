-- Lua provided by RyzenAPI 
-- Game: AppID 658400
addappid(658400)
addappid(658401, 1, "fa30d458ca59fe2668bd9f91272332e7d6adecadc6fce1192dd5933f098eec10")
