-- Lua provided by RyzenAPI
-- Game: Shadow Tactics: Blades of the Shogun Demo

-- MAIN APPLICATION
addappid(547490)

-- MAIN APP DEPOTS / PACKAGES
addappid(547491, 1, "086768a5be523c3b59e7b7e2b139f95316564c4a6136c0f3149d0d7412b4897b")

