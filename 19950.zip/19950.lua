-- Lua provided by RyzenAPI
-- Game: 19950

-- MAIN APPLICATION
addappid(19950)

-- MAIN APP DEPOTS / PACKAGES
addappid(15171,0,"1a9f1e32152cbd8fe3bba033ea4e23961e5f7ad731190ffcaf82e2668912e33e")
