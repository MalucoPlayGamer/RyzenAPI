-- Lua provided by SkyAPI 
-- Game: Blade Prince Academy Demo
addappid(2397280)
addappid(2397281, 1, "2f6a8f07a3bfaf0ea0c44f75a2ce07755e6cb8446b232e78348153329cf454ce")
