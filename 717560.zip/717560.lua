-- Lua provided by SkyAPI 
-- Game: AppID 717560
addappid(717560)
addappid(717561, 1, "5bbf46a0a63d08e70bdd6a24e5db945cd74072a9a663255d2d6f45bc4b31ae1d")
