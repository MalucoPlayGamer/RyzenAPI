-- Lua provided by RyzenAPI
-- Game: AppID 717560

-- MAIN APPLICATION
addappid(717560)

-- MAIN APP DEPOTS / PACKAGES
addappid(717561, 1, "5bbf46a0a63d08e70bdd6a24e5db945cd74072a9a663255d2d6f45bc4b31ae1d")
