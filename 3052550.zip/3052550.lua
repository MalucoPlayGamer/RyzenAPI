-- Lua provided by SkyAPI 
-- Game: NINJA HAYATE HD-Remaster
addappid(3052550)
addappid(3052551, 1, "72aa85076a90792a440e219ef457e59d1c6055ed17d6af6ccddd777ee89a58c1")
