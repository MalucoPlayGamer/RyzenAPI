-- Lua provided by RyzenAPI
-- Game: Game: NINJA HAYATE HD-Remaster

-- MAIN APPLICATION
addappid(3052550)
-- Game: addappid(3052550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052551, 1, "72aa85076a90792a440e219ef457e59d1c6055ed17d6af6ccddd777ee89a58c1")
