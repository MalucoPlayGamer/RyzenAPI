-- 4124920's Lua and Manifest Created by Hubcap Manifest
-- Some of You May Die
-- Created: July 24, 2026 at 12:41:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4124920, 1, "5d05a44b08ade1fc45004883c50034c2c0b54d40a245e7fb67e7a1535ad814ee") -- Some of You May Die
-- MAIN APP DEPOTS
addappid(4124921, 1, "f27536e9284475b5909460161a8b69661c9466ee14a290b04af0a21ce48c7bd3") -- Depot 4124921
setManifestid(4124921, "2495618269576943079", 862777753)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4888880) -- Some of You May Die - Supporter Pack