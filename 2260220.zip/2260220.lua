-- Lua provided by SkyAPI 
-- Game: Swarm Horror
addappid(2260220)
addappid(2260221, 1, "95fd269d4cd29cdeeb8092e7a6cef872c24ca5db35361057c0baf4a882a2e9f6")
