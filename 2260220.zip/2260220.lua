-- Lua provided by RyzenAPI
-- Game: 2260220

-- MAIN APPLICATION
addappid(2260220)
-- Game: addappid(2260220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260221, 1, "95fd269d4cd29cdeeb8092e7a6cef872c24ca5db35361057c0baf4a882a2e9f6")
