-- Lua provided by SkyAPI 
-- Game: PLASMATIC VR
addappid(1938360)
addappid(1938361, 1, "a63684f36093d33e96f96b1e0ca46d71346c4311427a639e92dda2f148a46834")
