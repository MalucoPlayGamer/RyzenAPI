-- Lua provided by RyzenAPI
-- Game: Game: AppID 2771170

-- MAIN APPLICATION
addappid(2771170)
-- Game: addappid(2771170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771171, 1, "12020456ae55e401ebf62c83f37d798dcd9b2f51c024e6007a1845a51a8ac30e")
