-- Lua provided by RyzenAPI
-- Game: AppID 322450

-- MAIN APPLICATION
addappid(322450)

-- MAIN APP DEPOTS / PACKAGES
addappid(322451, 1, "4c9186424d6f567a340ea0405c942740cbc857f725e1742e11c136f0aeb6790c")
addappid(322452, 1, "43bd24f55afe223bdf2396768df2471bcf77837817874876867a01fcb75940e2")
addappid(322453, 1, "0f7800517619d88a91bcef492a01069c512b9833bb31ff5e54cb6ec29ec3cb13")
addappid(856840, 0, "dd8477b97b260338c64de543cf3d63ea7645320b4df69836251d5be8da8333a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
