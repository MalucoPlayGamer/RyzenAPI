-- Lua provided by RyzenAPI
-- Game: Kizuna AI - Touch the Beat! Additional Song "DOGS HYNOME feat. #kzn" + "#kzn"

-- MAIN APPLICATION
addappid(2426680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426680,0,"58252cdaaf621f8557cd426dc0a53569012b4f88e5bdd10e3829f24a6dca309c")
