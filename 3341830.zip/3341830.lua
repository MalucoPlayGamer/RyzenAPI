-- Lua provided by RyzenAPI
-- Game: Game: TOY BOX

-- MAIN APPLICATION
addappid(3341830)
-- Game: addappid(3341830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341831, 1, "e7ce7e5d2473ca37117952d7c54958c72e1c6dcd0dada918a8f07f278a0f9a7b")
