-- Lua provided by RyzenAPI
-- Game: addappid(3598990)

-- MAIN APPLICATION
addappid(3598990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598991, 1, "fc8f6f66c671d44475ad47909fdf3d1a136dd15da4f05b13528e6a387b871c88")
