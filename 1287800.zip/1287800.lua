-- Lua provided by RyzenAPI
-- Game: Schwarzerblitz

-- MAIN APPLICATION
addappid(1287800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287801, 1, "890703dda00cd96c86b299e5ea710c074d4407a0cb23c7dbc2c1a8d853eef244")
addappid(1514510, 0, "82457ae91945a84d24ead756f4267c57145c8d77fe33d7f674af003a8066a7fa")
addappid(1553700, 0, "1edfb9eebe49cd85849023f31ede84c7bb4e84692267662102b9a8b74dae4804")
addappid(1553720, 0, "ea4502d9107363b80f5c65c2400058453b912c9d79ef8b4471774b596afd78b7")
addappid(1553760, 0, "5971be9d9cb34539e8a3cb5d5bf2e01d5bf777bc08fdccdb784a2cbff931f190")
addappid(1553770, 0, "69fc8897337199a606028be2c69cebffa38f9d7768d81a4a1148e97c17068a11")
addappid(1554190, 0, "8447f2ca07c6e6e8cade0dbac4f3a20ef5eae81d890ee397d809aeff20a37b7a")
addappid(1554200, 0, "791acacfc83182b1cba8a957b1407e011e02775eb46f5a2c510b3b68f63585f9")
addappid(1554230, 0, "12dfe4b485f3d09e6caab920dc61b55c3ab9dd5ec8c4b4c2f1037ff0c5e07022")
addappid(1554240, 0, "59f16994ce4a88b2798fa20dc636678664bf436032c2becc454fe0526f2ef21a")
addappid(1554250, 0, "3005a5fabf2ed7cb47ba406a9bf892c7087abd42b6f86e3b36eed59fab9f1010")
addappid(2588310, 0, "c1168b9510222e3f4e921c070c1f97a194ad6c2e08408c46365bc5b750ff57c1")
addappid(2588320, 0, "31f7936d067c1d3f1801d22aa81a1f1dbe1fa042224c0e0d5990a44c075ba2cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2198360)
