-- Lua provided by RyzenAPI
-- Game: addappid(1708330)

-- MAIN APPLICATION
addappid(1708330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708331, 1, "da23bdfc9e847f186c8e9bf311589bbfaba7424c7792a6b8d5117dcb2171aacd")
