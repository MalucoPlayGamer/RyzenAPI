-- Lua provided by RyzenAPI
-- Game: 2095340

-- MAIN APPLICATION
addappid(2095340)
-- Game: addappid(2095340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095341, 1, "0a01adcefa9b31119624f9251c1cd13de56576a14f522e92b645d0a8406d5fe9")
addappid(2322790, 0, "79321ef246ccfbada003dee7fefeca263eecc0da83cec4049c0478b8da5456c0")
