-- Lua provided by RyzenAPI
-- Game: 1070131

-- MAIN APPLICATION
addappid(1070131)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070131,0,"e7db2f7d10b546ab08c417f4c888a093cbd97139d8fa2baefb1ff3a26b5253e5")

