-- Lua provided by RyzenAPI
-- Game: AppID 3277350

-- MAIN APPLICATION
addappid(3277350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277351, 1, "3983beae263b53ac80b932adba8cfd4ebb4aa1bb543b68912e8f0f216a707a13")
