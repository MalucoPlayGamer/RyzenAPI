-- Lua provided by SkyAPI 
-- Game: AppID 3277350
addappid(3277350)
addappid(3277351, 1, "3983beae263b53ac80b932adba8cfd4ebb4aa1bb543b68912e8f0f216a707a13")
