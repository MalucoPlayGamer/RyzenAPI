-- Lua provided by RyzenAPI
-- Game: Gamer Shop Simulator

-- MAIN APPLICATION
addappid(1228570)
-- Game: addappid(1228570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228571, 1, "c119144d38eab91a27855decdd1f225c45f747c423b278b9c066d9471346a2e1")
