-- Lua provided by RyzenAPI
-- Game: The Garden

-- MAIN APPLICATION
addappid(516810)

-- MAIN APP DEPOTS / PACKAGES
addappid(516811,0,"a65cdb4587f42370724b6b31fd7c8dbec885c182923006bcebac3419339ca3b0")

