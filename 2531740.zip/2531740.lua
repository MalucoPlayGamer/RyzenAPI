-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Heroine Generator DX for MZ

-- MAIN APPLICATION
addappid(2531740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531740,0,"c2c8f128414602c21d892924fe5fb595564e0d93dd764c5c4a47742cc5ba41a9")
