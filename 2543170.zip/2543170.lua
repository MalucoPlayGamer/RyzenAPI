-- Lua provided by RyzenAPI
-- Game: Game: Turlock Holmes Demo

-- MAIN APPLICATION
addappid(2543170)
-- Game: addappid(2543170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543171, 1, "4b1452050798ae3fed5caa25bb5383e4fcecf1539cc7e658e75a67cc4daeefd8")
