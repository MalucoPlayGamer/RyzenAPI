-- Lua provided by RyzenAPI
-- Game: 2543170

-- MAIN APPLICATION
addappid(2543170)
-- Game: addappid(2543170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543171, 1, "4b1452050798ae3fed5caa25bb5383e4fcecf1539cc7e658e75a67cc4daeefd8")
