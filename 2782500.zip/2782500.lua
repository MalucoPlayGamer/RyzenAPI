-- Lua provided by RyzenAPI
-- Game: SWORD OF JUSTICE

-- MAIN APPLICATION
addappid(2782500)
