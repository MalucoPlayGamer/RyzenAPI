-- Lua provided by SkyAPI 
-- Game: Prop Hunt Planet
addappid(3135070)
addappid(3135071, 1, "7d9648118325e4f9240cfaaa4d12cbd5b10084aa175b3bb20b5be0f078747f95")
