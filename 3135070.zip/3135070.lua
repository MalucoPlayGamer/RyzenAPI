-- Lua provided by RyzenAPI
-- Game: Prop Hunt Planet

-- MAIN APPLICATION
addappid(3135070)
-- Game: addappid(3135070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135071, 1, "7d9648118325e4f9240cfaaa4d12cbd5b10084aa175b3bb20b5be0f078747f95")
