-- Lua provided by RyzenAPI
-- Game: Rail Recon

-- MAIN APPLICATION
addappid(746860)

-- MAIN APP DEPOTS / PACKAGES
addappid(746861, 1, "e4c677c621b8ff6f7556feaeccb1a3a9fdcfc8ac80670a3362acc0e40cf4f5cf")

