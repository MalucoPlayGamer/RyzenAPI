-- Lua provided by RyzenAPI
-- Game: Rail Recon

-- MAIN APPLICATION
addappid(746860)

-- MAIN APP DEPOTS / PACKAGES
addappid(746861, 1, "e4c677c621b8ff6f7556feaeccb1a3a9fdcfc8ac80670a3362acc0e40cf4f5cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
