-- Lua provided by RyzenAPI
-- Game: ButtKnight

-- MAIN APPLICATION
addappid(2772820)
-- Game: addappid(2772820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772821, 1, "d9cb8cd6f940a0c4f850fd34e68dfe7ff611d4882b9b00dc6815275894e476e2")
