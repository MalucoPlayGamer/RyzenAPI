-- Lua provided by RyzenAPI
-- Game: addappid(655950)

-- MAIN APPLICATION
addappid(655950)

-- MAIN APP DEPOTS / PACKAGES
addappid(655951, 1, "ef94cbd90eb269ab2247d5e6d871e66a21b48f7eac2a19a65b9e2154af7d378c")
