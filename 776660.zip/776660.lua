-- Lua provided by RyzenAPI
-- Game: Smooth Operators 2

-- MAIN APPLICATION
addappid(776660)

-- MAIN APP DEPOTS / PACKAGES
addappid(776662,0,"f4c9c158493221137fa489240c64a87e836ab57644b5cfa3b6fd339795549f4d")

