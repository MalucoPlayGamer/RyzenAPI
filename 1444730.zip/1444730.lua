-- Lua provided by RyzenAPI
-- Game: My Sweet Washing Machine!

-- MAIN APPLICATION
addappid(1444730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444731, 1, "d8385e30f0ef07f82326ed9457f090f61215f0047b06ee8890713e95451beefb")

