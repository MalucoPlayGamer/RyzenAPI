-- Lua provided by RyzenAPI 
-- Game: Miko Gakkou Monogatari: Kaede Episode
addappid(332370)
addappid(332371, 1, "a840a3bf4b97d31567fb1ce996f082ba645aa67b009dd012d5a8a87a977e6d4f")
