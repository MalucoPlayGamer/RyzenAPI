-- Lua provided by RyzenAPI 
-- Game: Mountain Trap: The Manor of Memories
addappid(563320)
addappid(563321, 1, "7231b2b13a20b2ef32c7d099de96b3dab31bd00757c95391978e84ba15f07d83")
addappid(563322, 1, "484825579ab614b73158b03d8aea8a0d2eba827a4d4ddb6673ecef6c95e0bfe4")
addappid(563323, 1, "ac0468e78522605b6e6fddbfa3a171cb588a22a23f9fae62d59c17ff3fee934e")
addappid(563324, 1, "f13352e5da21fa5060bf1034bb67c77b97f4e403eca27902f94f541aa7b494b8")
