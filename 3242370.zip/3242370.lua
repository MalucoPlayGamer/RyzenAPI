-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Australia

-- MAIN APPLICATION
addappid(3242370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242371, 1, "5adb903076f0a4e3e0f62d1e6e48ee4fa34789b353ed7ea4a52e7cd99a9355eb")
