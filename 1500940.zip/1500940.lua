-- Lua provided by RyzenAPI
-- Game: addappid(1500940)

-- MAIN APPLICATION
addappid(1500940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500941, 1, "4e9d53ccb6cbd8d1486aed709c9e694fc8d32e6282bbee2e09a6589cfa727e83")
