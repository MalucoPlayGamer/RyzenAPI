-- 3036720's Lua and Manifest Created by Hubcap Manifest
-- METAL GEAR SOLID MASTER COLLECTION Vol.2 BONUS CONTENT
-- Created: August 27, 2026 at 09:09:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3036720) -- METAL GEAR SOLID MASTER COLLECTION Vol.2 BONUS CONTENT
-- MAIN APP DEPOTS
addappid(3036721, 1, "04fb96bc8a0473b587b962301ad9fb9b1ef5b798b1485a2cf3402473ff76441f") -- Depot 3036721
setManifestid(3036721, "5296970888889346959", 296362347)