-- Lua provided by RyzenAPI
-- Game: addappid(2328340)

-- MAIN APPLICATION
addappid(2328340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328341, 1, "6206d6ede8866445eea8ee91ab8f648282e472b8ca64d0fff0e2313548b23cd6")
