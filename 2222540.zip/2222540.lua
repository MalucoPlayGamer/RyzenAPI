-- Lua provided by RyzenAPI
-- Game: 2222540

-- MAIN APPLICATION
addappid(2222540)
-- Game: addappid(2222540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222542,0,"110c5b89375f9bcd0f3c4ba3ceda115100df150e4f182cdc71cd572d3ab1e8bb")
