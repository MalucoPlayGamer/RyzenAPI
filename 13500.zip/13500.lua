-- Lua provided by RyzenAPI
-- Game: addappid(13500)

-- MAIN APPLICATION
addappid(13500)

-- MAIN APP DEPOTS / PACKAGES
addappid(13501, 1, "1927562a78578b21ac7eb2a7ff202060c71870d222e56e4ff4a64eb19c153c85")
addappid(13502, 1, "7426889bbf0b87c1c3c474ebb8f385eefdc881a1674c88eece8e00fbb7061411")
addappid(13503, 1, "0fb111f81f635102b0391af2c60de348a5937b49dd08c5f2a95a87df40859d10")
addappid(13504, 1, "bc2d9c3220d89b05dd7b7b02c242e4d2052beaa4222fd764010728a6dc748f12")
addappid(13505, 1, "d27bd3aaf7ac1b585adc89df17f6c758eec4bebc2e9dd28ac2f829138cc0a1f0")
addappid(13506, 1, "41cd6f351ef5ff9d7ce832cae75d0bb6d502f6f0101fcfe1c160b325e399baed")
