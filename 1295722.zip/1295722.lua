-- Lua provided by RyzenAPI
-- Game: Dragon Age™ II - Warrior Item Pack II

-- MAIN APPLICATION
addappid(1295722)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295722,0,"e5171ae4dffaad823bcdaef841d44b33bb66f6dccf481973b65f8ba6e7bffb11")
addappid(1296120,0,"e9d4a5891864696b2f470696811c26cafd75871cdf54984d37f6d6c791128858")
addappid(1296121,0,"dd40f0bb878de1682c11a77a6e53b77cade4ec8abfa850e6f61a4e3745291c94")
addappid(1296122,0,"b8331aeb497a95e607cde481f19166198b25d708994f202ce77414b14bfa803e")
addappid(1296123,0,"f8473197a0e7f0faabe6e11a11ea318bdfba27b47e989f5f0b3078c3e2ccfa4c")
addappid(1296124,0,"8fb5c649e81058d40fc7ca1ebe93db12dd91a948cc4d52093aaedb90178c8e7f")
addappid(1296125,0,"d3d58f62a9301b8f5da41612df0d3b64efde49ab324a8202cfb72b096e0cb7a1")
addappid(1296126,0,"58ab484142528a4eeef289e3fbc6e460a5b2414b14c93a47ba191e53c20c9ab3")

