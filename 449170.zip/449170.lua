-- Lua provided by SkyAPI 
-- Game: Gnomes Garden 2
addappid(449170)
addappid(449171, 1, "980557ecd02da880c66242564d2d354e87c827bd30ad8bb62e3b5ef254a723d4")
