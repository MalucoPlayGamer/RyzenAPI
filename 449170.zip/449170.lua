-- Lua provided by RyzenAPI
-- Game: Gnomes Garden 2

-- MAIN APPLICATION
addappid(449170)

-- MAIN APP DEPOTS / PACKAGES
addappid(449171, 1, "980557ecd02da880c66242564d2d354e87c827bd30ad8bb62e3b5ef254a723d4")
