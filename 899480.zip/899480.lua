-- Lua provided by RyzenAPI
-- Game: addappid(899480)

-- MAIN APPLICATION
addappid(899480)

-- MAIN APP DEPOTS / PACKAGES
addappid(899481, 1, "873d4ad05df80200e8a6752f0f550be21a55a07512e83f0863a956f22742dfe0")
