-- Lua provided by SkyAPI 
-- Game: Girls Dance
addappid(899480)
addappid(899481, 1, "873d4ad05df80200e8a6752f0f550be21a55a07512e83f0863a956f22742dfe0")
