-- Lua provided by RyzenAPI
-- Game: One More Night

-- MAIN APPLICATION
addappid(535630)

-- MAIN APP DEPOTS / PACKAGES
addappid(535631, 1, "5239aed44bab5248adce0bdc6ea6768bb9882541848fa07845e40f509820ed1d")

