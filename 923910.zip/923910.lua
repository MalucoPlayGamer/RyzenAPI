-- Lua provided by RyzenAPI
-- Game: Game: Eve of Souls: Static Pod

-- MAIN APPLICATION
addappid(923910)
-- Game: addappid(923910)

-- MAIN APP DEPOTS / PACKAGES
addappid(923911, 1, "272435779785c5945c5253bda5400fc8019a339c5b283c512934aed8fc8ac43a")
addappid(923912, 1, "68b4b2b42e6abfb75b3c13b61c61c4fc78cbc26a6bbbdd6a2e72b74ba51d06f8")
