-- Lua provided by RyzenAPI
-- Game: AppID 724000

-- MAIN APPLICATION
addappid(724000)

-- MAIN APP DEPOTS / PACKAGES
addappid(724001, 1, "de3a33fb822f7f87a84a61062b9328d9d1be7293e25035d6dca8859c980491e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
