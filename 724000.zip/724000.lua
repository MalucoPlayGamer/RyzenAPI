-- Lua provided by RyzenAPI
-- Game: addappid(724000)

-- MAIN APPLICATION
addappid(724000)

-- MAIN APP DEPOTS / PACKAGES
addappid(724001, 1, "de3a33fb822f7f87a84a61062b9328d9d1be7293e25035d6dca8859c980491e4")
