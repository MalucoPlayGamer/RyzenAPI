-- Lua provided by RyzenAPI 
-- Game: AppID 724000
addappid(724000)
addappid(724001, 1, "de3a33fb822f7f87a84a61062b9328d9d1be7293e25035d6dca8859c980491e4")
