-- Lua provided by RyzenAPI
-- Game: Game: REVN

-- MAIN APPLICATION
addappid(919010)
-- Game: addappid(919010)

-- MAIN APP DEPOTS / PACKAGES
addappid(919011, 1, "209dc8c253c48cc10cd28e53360ee4a51b4179504f2e773f55636826df764fb8")
