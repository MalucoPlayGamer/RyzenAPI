-- Lua provided by SkyAPI 
-- Game: The Last Sanctum
addappid(3646380)
addappid(3646381, 1, "e41a46ec259db1343cd911722776c3b6588d4096cb5eddc7f485783aff0e1178")
