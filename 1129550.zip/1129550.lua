-- Lua provided by RyzenAPI
-- Game: 1129550

-- MAIN APPLICATION
addappid(1129550)
-- Game: addappid(1129550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129553,0,"266363876a17f2d4b469b836c6e4dc4f74ffa83d50f963d3531a31d5034e8bfd")
