-- Lua provided by RyzenAPI
-- Game: addappid(2862140)

-- MAIN APPLICATION
addappid(2862140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862144,0,"9c50c8fb6cd2aa8d0927afd8ec7710a3ce64d845dbc428bf6fdccbb8f03d75eb")
