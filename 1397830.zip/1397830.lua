-- Lua provided by RyzenAPI
-- Game: Presidential Running Games

-- MAIN APPLICATION
addappid(1397830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397831,0,"d730f5602fe45b1139acd6dae86a830ce1a5631c1c35d81a46ba7b1023c3833a")
addappid(1397832,0,"2973eadcffd83c081cce51330f7dec5e4bcde712d08cd040f677887fb2ce62c6")

