-- Lua provided by RyzenAPI
-- Game: FETUS

-- MAIN APPLICATION
addappid(2059650)
-- Game: addappid(2059650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059651, 1, "9828a46d82460fb4d082bad466b2c217444f5d4cbd45113142fe7a07134d4bf0")
