-- Lua provided by RyzenAPI 
-- Game: Torque Drift 2 - Demo
addappid(3339940)
addappid(3339941, 1, "bcdc7ce9427633eb341bfb74bdd12bd2c7cb389d4141853156720501d5136f5f")
