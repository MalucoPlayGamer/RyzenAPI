-- Lua provided by RyzenAPI
-- Game: 3339940

-- MAIN APPLICATION
addappid(3339940)
-- Game: addappid(3339940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339941, 1, "bcdc7ce9427633eb341bfb74bdd12bd2c7cb389d4141853156720501d5136f5f")
