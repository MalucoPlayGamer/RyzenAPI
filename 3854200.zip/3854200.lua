-- Lua provided by SkyAPI 
-- Game: Citadel Siege
addappid(3854200)
addappid(3854201, 1, "861dd5f1ce3a60000ad91080308a6f8f987dcf707e01b671e8ddc6695033404b")
