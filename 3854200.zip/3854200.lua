-- Lua provided by RyzenAPI
-- Game: Citadel Siege

-- MAIN APPLICATION
addappid(3854200)
-- Game: addappid(3854200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3854201, 1, "861dd5f1ce3a60000ad91080308a6f8f987dcf707e01b671e8ddc6695033404b")
