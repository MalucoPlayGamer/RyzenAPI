-- Lua provided by RyzenAPI
-- Game: Game: AppID 3142620

-- MAIN APPLICATION
addappid(3142620)
-- Game: addappid(3142620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142621, 1, "b9828000b55f4402308c296d43f73588e66e6b261e9f1a4eb32467ecfd1d890b")
