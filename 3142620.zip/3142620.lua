-- Lua provided by RyzenAPI 
-- Game: AppID 3142620
addappid(3142620)
addappid(3142621, 1, "b9828000b55f4402308c296d43f73588e66e6b261e9f1a4eb32467ecfd1d890b")
