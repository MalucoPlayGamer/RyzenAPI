-- Lua provided by RyzenAPI
-- Game: MX vs. ATV Unleashed

-- MAIN APPLICATION
addappid(359220)

-- MAIN APP DEPOTS / PACKAGES
addappid(359221, 1, "965db4b68176cbecb8b12e793858af9472bb32f6be96819aeb6dcfcb04fcf0b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
