-- Lua provided by RyzenAPI
-- Game: Game: MX vs. ATV Unleashed

-- MAIN APPLICATION
addappid(359220)
-- Game: addappid(359220)

-- MAIN APP DEPOTS / PACKAGES
addappid(359221, 1, "965db4b68176cbecb8b12e793858af9472bb32f6be96819aeb6dcfcb04fcf0b3")
