-- Lua provided by RyzenAPI
-- Game: D.N.A: Do Not Answer

-- MAIN APPLICATION
addappid(3043290)
-- Game: addappid(3043290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043291, 1, "c0c41280259a3854d7185925f331a6fa040951e639c007659b05d1b972d9d429")
