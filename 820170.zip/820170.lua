-- Lua provided by RyzenAPI
-- Game: CRAZY MAZE

-- MAIN APPLICATION
addappid(820170)
-- Game: addappid(820170)

-- MAIN APP DEPOTS / PACKAGES
addappid(820171, 1, "f4aeaea01f175e31a6a8e3ead52d7c454c6e31282af06cfeaadd784b8476299f")
