-- Lua provided by RyzenAPI
-- Game: CRAZY MAZE

-- MAIN APPLICATION
addappid(820170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(820171, 1, "f4aeaea01f175e31a6a8e3ead52d7c454c6e31282af06cfeaadd784b8476299f")

