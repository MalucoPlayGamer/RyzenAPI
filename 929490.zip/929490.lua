-- Lua provided by RyzenAPI
-- Game: RAM Pressure

-- MAIN APPLICATION
addappid(929490)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(929491, 1, "feaf68e5f07cc913e7983ba08e304a1d9f10e5601586732f8d6ecc4ca292a02c")

