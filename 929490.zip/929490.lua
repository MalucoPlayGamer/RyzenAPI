-- Lua provided by RyzenAPI
-- Game: 929490

-- MAIN APPLICATION
addappid(929490)
-- Game: addappid(929490)

-- MAIN APP DEPOTS / PACKAGES
addappid(929491, 1, "feaf68e5f07cc913e7983ba08e304a1d9f10e5601586732f8d6ecc4ca292a02c")
