-- Lua provided by RyzenAPI
-- Game: HyperBowl

-- MAIN APPLICATION
addappid(847530)

-- MAIN APP DEPOTS / PACKAGES
addappid(847531, 1, "c3c0d560a376c4b8ac38e39de65f86f6a7c45fce14b0f711713fe020145a0bc1")

