-- Lua provided by RyzenAPI
-- Game: addappid(2193750)

-- MAIN APPLICATION
addappid(2193750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193751, 1, "6bb71d0f16d5707db078ebac070cde6c10e4b163411af95b4419fa8fe3da54d0")
addappid(2193752, 1, "a00ed2e571622af2a2d70ef63143e91e8e4c9f819276a3c9c2e97bf9b2d02c1c")
