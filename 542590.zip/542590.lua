-- Lua provided by SkyAPI 
-- Game: SoulSaverOnline
addappid(542590)
addappid(542591, 1, "e0e9c96f5f7f6c418d5c0b1e7edbbc20417dded0484393b17c56700678415261")
addappid(542592, 1, "30c28a06d68bfc6d8b291a6dc3e797c34040715aebbc687bc27d3c5932713b2f")
