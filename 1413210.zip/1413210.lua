-- Lua provided by RyzenAPI
-- Game: The Cassir Simulator

-- MAIN APPLICATION
addappid(1413210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1413211, 1, "d4750a12d4e4f69494b0d3484e35ce9043a09be0b9679c0892d8679f04e92225")

