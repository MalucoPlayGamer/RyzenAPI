-- Lua provided by RyzenAPI
-- Game: Game: AppID 1911970

-- MAIN APPLICATION
addappid(1911970)
-- Game: addappid(1911970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911971, 1, "e0d847bfc5c93d6cd4bc81e90ab60c8b08b7f5a3d13c5045245ad9648e87aa61")
