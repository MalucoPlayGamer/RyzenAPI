-- Lua provided by RyzenAPI
-- Game: OverShoot Battle Race [ Dedicated Server ]

-- MAIN APPLICATION
addappid(1911970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911971, 1, "e0d847bfc5c93d6cd4bc81e90ab60c8b08b7f5a3d13c5045245ad9648e87aa61")
