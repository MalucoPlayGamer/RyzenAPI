-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Busty Miko’s Secret Bond

-- MAIN APPLICATION
addappid(4042520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4042521,0,"3eee0f24d8d6250299b0401a38d2eb376ecaed9748d58c157c389b485500c3b2")

