-- Lua provided by RyzenAPI
-- Game: Game: PowerWash Simulator – Single

-- MAIN APPLICATION
addappid(2182380)
-- Game: addappid(2182380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182381, 1, "712e31b12758bdb1248e3b0281f602b46d11fb7c5f8fd91efee87f03efcfad6b")
