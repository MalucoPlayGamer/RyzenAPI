-- Lua provided by SkyAPI 
-- Game: AppID 1276170
addappid(1276170)
addappid(1276171, 1, "facd743b27d0676667a45a463667cb8d9f5f8066b424936f0cb40b0f6576cf4f")
