-- Lua provided by RyzenAPI
-- Game: addappid(809960)

-- MAIN APPLICATION
addappid(809960)

-- MAIN APP DEPOTS / PACKAGES
addappid(809961, 1, "30e1a6d34e2f287e5a5a7e2f25f36f6bd6bec7a35c9075242d42e1f66af36b9a")
