-- Lua provided by RyzenAPI
-- Game: S.E.C.U.

-- MAIN APPLICATION
addappid(2095120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2095121, 1, "90d299e7141c1d3c501aede26603d4a5b6e30acd8d7c0dfed78e4484fc7f5649")

