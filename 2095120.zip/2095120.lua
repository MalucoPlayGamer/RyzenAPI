-- Lua provided by RyzenAPI
-- Game: Game: S.E.C.U.

-- MAIN APPLICATION
addappid(2095120)
-- Game: addappid(2095120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095121, 1, "90d299e7141c1d3c501aede26603d4a5b6e30acd8d7c0dfed78e4484fc7f5649")
