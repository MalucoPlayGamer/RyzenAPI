-- Lua provided by RyzenAPI
-- Game: addappid(1553980)

-- MAIN APPLICATION
addappid(1553980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553981, 1, "f120579ae0b32916a72407e8fb2a27d0d93be94329105c99bfd00707bb2cf4b9")
