-- Lua provided by RyzenAPI
-- Game: addappid(2714170)

-- MAIN APPLICATION
addappid(2714170)
addappid(2835900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714171, 1, "274cbadd8a44b92022e0fb30880198c53320803656be856bc9c87a891a23c29e")
