-- Lua provided by RyzenAPI
-- Game: 569840

-- MAIN APPLICATION
addappid(569840)
-- Game: addappid(569840)

-- MAIN APP DEPOTS / PACKAGES
addappid(569841, 1, "a8200d8d72f0f075245a94d5291399c12952a73f7e189a05e36ad1b00148b5cf")
