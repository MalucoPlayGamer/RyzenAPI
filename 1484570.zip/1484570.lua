-- Lua provided by RyzenAPI 
-- Game: AppID 1484570
addappid(1484570)
addappid(1484571, 1, "1cdafe528c91d02927c282694fbdb8f360c2631b54429d807561c12d87c18948")
