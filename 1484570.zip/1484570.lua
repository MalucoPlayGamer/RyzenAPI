-- Lua provided by RyzenAPI
-- Game: Game: AppID 1484570

-- MAIN APPLICATION
addappid(1484570)
-- Game: addappid(1484570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484571, 1, "1cdafe528c91d02927c282694fbdb8f360c2631b54429d807561c12d87c18948")
