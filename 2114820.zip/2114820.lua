-- Lua provided by RyzenAPI
-- Game: addappid(2114820)

-- MAIN APPLICATION
addappid(2114820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114821, 1, "2d1f134b811591d82c838e70c4dc3f8d7e40de4d2ecb4b43d03f2ecec685d731")
