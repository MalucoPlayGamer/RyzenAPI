-- Lua provided by RyzenAPI
-- Game: CrashMetal Cyberpunk

-- MAIN APPLICATION
addappid(1490130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490131, 1, "01555504130a528c2cc6557cb97f1b48ced888e3a968af190c55dbfa6bc0a083")
addappid(1490132, 1, "c5054c5d4092fc9e45a3565ad7c0afefaf46f082d59d7fe1de7543fd1fa0ce27")

