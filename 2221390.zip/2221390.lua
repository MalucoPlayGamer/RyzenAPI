-- Lua provided by RyzenAPI
-- Game: Game: Damned 2

-- MAIN APPLICATION
addappid(2221390)
-- Game: addappid(2221390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221391, 1, "c2da1b1bb731fc390029ec1c3f2e6cb39081361cc19e274260c3d77153e6c624")
