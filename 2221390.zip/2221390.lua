-- Lua provided by RyzenAPI 
-- Game: Damned 2
addappid(2221390)
addappid(2221391, 1, "c2da1b1bb731fc390029ec1c3f2e6cb39081361cc19e274260c3d77153e6c624")
