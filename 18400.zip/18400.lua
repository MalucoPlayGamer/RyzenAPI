-- Lua provided by RyzenAPI
-- Game: addappid(18400)

-- MAIN APPLICATION
addappid(18400)
addappid(202450)
addappid(202451)
addappid(202452)
addappid(202453)
addappid(202454)
addappid(202455)
addappid(202456)
addappid(229032)
addappid(242630)
addappid(242631)
addappid(242632)
addappid(312090)
addappid(323390)
addappid(335110)

-- MAIN APP DEPOTS / PACKAGES
addappid(18401, 1, "77e99054ec77e49d7663dd06a336e6e591c61e1d720ef2279f404f8fa5a7b496")
addappid(18402, 1, "e0ef02e658255d0e8e7336993fec01ca663622caeac7887f9214fbea1223e3ee")
