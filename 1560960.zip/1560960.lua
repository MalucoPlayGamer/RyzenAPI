-- Lua provided by RyzenAPI
-- Game: Night Monsters

-- MAIN APPLICATION
addappid(1560960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560961, 1, "0a94af2df11be6481d5e145e1277ab3a88f4938dc3524614d84cf3924a76492a")
