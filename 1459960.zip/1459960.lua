-- Lua provided by RyzenAPI
-- Game: Glitchpunk

-- MAIN APPLICATION
addappid(1459960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459961, 1, "d1614967bd23577a915eb8fd558a306845f6ad806504c11241e3361b97287b21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1670560)
