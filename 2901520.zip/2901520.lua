-- Lua provided by RyzenAPI
-- Game: 2901520

-- MAIN APPLICATION
addappid(2901520)
-- Game: addappid(2901520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901521, 1, "b64fd4299573b07dd83ba1acf4fd83b90c27372919b8fd1d8038b98ae79df954")
