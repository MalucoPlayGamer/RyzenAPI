-- Lua provided by RyzenAPI
-- Game: An alt girl for skoof

-- MAIN APPLICATION
addappid(2901520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901521, 1, "b64fd4299573b07dd83ba1acf4fd83b90c27372919b8fd1d8038b98ae79df954")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3058410)
addappid(3592130)
addappid(3592160)
