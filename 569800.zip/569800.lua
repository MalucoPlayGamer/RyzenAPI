-- Lua provided by RyzenAPI 
-- Game: LEAVES - The Journey
addappid(569800)
addappid(569801, 1, "28522ba234f59845eec3542473238311b3b1eab47a7dcf11271c0a68e6560b97")
addappid(569802, 1, "da1ffd3bb834245b7941b13d48e5f8fc5c96f0c76282546db9edf9c0765ba3cd")
addappid(1912350, 0, "33bee9692cef5ea71f0e29e031c0842f40a5e99e4d5b24265bb742cfa0a1d343")
