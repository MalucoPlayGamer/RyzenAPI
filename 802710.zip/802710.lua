-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(802710)

-- MAIN APP DEPOTS / PACKAGES
addappid(802710,0,"c2675050747d010c0bd883ef861cc5bdec38f545692c5ba70b3266c41bac7474")
addtoken(802710,16832406625177480643)

