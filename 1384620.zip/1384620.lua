-- Lua provided by RyzenAPI
-- Game: Game: Ninja Hanrei

-- MAIN APPLICATION
addappid(1384620)
addappid(1471360)
-- Game: addappid(1384620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384621, 1, "e16db1bd0d6ff6be8a081b9015a820855ee1151fd082227ecbf3c9df0790d3f7")
addappid(1384622, 1, "956f400660f40fff913303660a6518fa70d5bde994863c38bc6046185668f794")
addappid(1384624, 1, "86a97272bccbcf07879e0457e0faf1e630bd594eae5a3281120faff2a5574500")
