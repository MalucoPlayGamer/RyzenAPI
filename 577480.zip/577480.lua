-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.5 Meakashi

-- MAIN APPLICATION
addappid(577480)

-- MAIN APP DEPOTS / PACKAGES
addappid(577481, 1, "fe1762b9b99a18e97b887c1fac577b40004216dba9bae110bba68d3b76bdace7")
