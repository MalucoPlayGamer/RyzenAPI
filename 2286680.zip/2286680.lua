-- Lua provided by RyzenAPI
-- Game: PinBuilder

-- MAIN APPLICATION
addappid(2286680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286681, 1, "3bfa7e16bdc1ddc029485347dfab88cf8c2b144aa1b03b20c1761c30646bfdd0")
