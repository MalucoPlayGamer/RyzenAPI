-- Lua provided by RyzenAPI
-- Game: Slap 'em UP!

-- MAIN APPLICATION
addappid(3703520)
