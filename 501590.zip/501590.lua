-- Lua provided by RyzenAPI
-- Game: addappid(501590)

-- MAIN APPLICATION
addappid(501590)

-- MAIN APP DEPOTS / PACKAGES
addappid(501591, 1, "72d72f0c658a2ba05a59dd33e4b6d50667cf1fe8606fe0f0ef2c5d330acd75a5")
