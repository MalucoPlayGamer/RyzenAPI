-- Lua provided by RyzenAPI
-- Game: Bulletstorm: Full Clip Edition

-- MAIN APPLICATION
addappid(501590)

-- MAIN APP DEPOTS / PACKAGES
addappid(501591, 1, "72d72f0c658a2ba05a59dd33e4b6d50667cf1fe8606fe0f0ef2c5d330acd75a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(561730)
