-- Lua provided by RyzenAPI
-- Game: addappid(865310)

-- MAIN APPLICATION
addappid(865310)

-- MAIN APP DEPOTS / PACKAGES
addappid(865311, 1, "77b9dfc6e7c821225ca14ae003d2e4704814f69d18036ced32494ce0ecc7b933")
