-- Lua provided by RyzenAPI
-- Game: Gabriel Knight: Sins of the Fathers 20th Anniversary Edition

-- MAIN APPLICATION
addappid(262000)

-- MAIN APP DEPOTS / PACKAGES
addappid(262001, 1, "9fa652e00dfac45baad0f955eb4da4a3ea87d1bf12f0fd362dee30d27ada4f2e")
addappid(262002, 1, "81305d068ee5ff8ca7d3e4c95dd673d0239e24bec44eb8398b953ed54fae3263")
addappid(322090, 0, "bea0ae7217fcbc2843d219d1a03fa7ae2b2c37b1910f5b9bfc30423f87138ae7")
