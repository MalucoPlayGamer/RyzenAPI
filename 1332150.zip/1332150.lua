-- Lua provided by SkyAPI 
-- Game: Zorya: The Celestial Sisters ™
addappid(1332150)
addappid(1332151, 1, "50187273d64a4a16ffda1e9d5959c4f7129da450ded1c76b1f018c4e89ef4587")
addappid(1745870)
addappid(1756360)
