-- Lua provided by RyzenAPI
-- Game: Zorya: The Celestial Sisters ™

-- MAIN APPLICATION
addappid(1332150)
addappid(1745870)
addappid(1756360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332151, 1, "50187273d64a4a16ffda1e9d5959c4f7129da450ded1c76b1f018c4e89ef4587")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
