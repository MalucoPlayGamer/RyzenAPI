-- Lua provided by RyzenAPI
-- Game: addappid(2081470)

-- MAIN APPLICATION
addappid(2081470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081471, 1, "dd397f04ae1f67a806724de61145a8d1b5d581eb4db86e5ec8073413c586795a")
