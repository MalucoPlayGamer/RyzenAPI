-- Lua provided by RyzenAPI
-- Game: Game: 幸运牌

-- MAIN APPLICATION
addappid(3309020)
-- Game: addappid(3309020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3309021, 1, "6b54f9501a8dc6d46a17cd3920398414e1bdc03d00260d48ad15e25f60229c28")
