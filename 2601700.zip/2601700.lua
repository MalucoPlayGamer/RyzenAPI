-- Lua provided by RyzenAPI
-- Game: Animal Trail ☆ Girlish Square LOVE+PLUS

-- MAIN APPLICATION
addappid(2601700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601701, 1, "681774efbbe6ff991c15bd78146a6d81fe1101945beba6962362b1b15978f501")

