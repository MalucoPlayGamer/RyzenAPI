-- Lua provided by RyzenAPI
-- Game: Mainly at Rest

-- MAIN APPLICATION
addappid(1718430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718431, 1, "658df33f4d1f0c6c9d567a9665dd6c683420743990a7142796e63bf050b054ce")

