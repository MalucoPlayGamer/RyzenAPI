-- Lua provided by RyzenAPI
-- Game: Game: AppID 1927440

-- MAIN APPLICATION
addappid(1927440)
addappid(2500390)
-- Game: addappid(1927440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927441, 1, "8dd9a2c4fd92878e7b6c76cf663c0469151d59cb8e362191fbb62e85cc904f32")
