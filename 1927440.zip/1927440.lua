-- Lua provided by RyzenAPI
-- Game: AppID 1927440

-- MAIN APPLICATION
addappid(1927440)
addappid(2421810)
addappid(2500390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1927441, 1, "8dd9a2c4fd92878e7b6c76cf663c0469151d59cb8e362191fbb62e85cc904f32")

