-- Lua provided by RyzenAPI
-- Game: Game: Depth Hunter 2: Deep Dive Demo

-- MAIN APPLICATION
addappid(317910)
-- Game: addappid(317910)

-- MAIN APP DEPOTS / PACKAGES
addappid(317911, 1, "01abcee0a56f32e63654b077e04edea9798b2f58526c7cdad5f540a30de59cd7")
