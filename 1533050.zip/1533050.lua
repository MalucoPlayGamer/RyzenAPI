-- Lua provided by SkyAPI 
-- Game: Press Ctrl
addappid(1533050)
addappid(1533051, 1, "fe7169949df7efd8df8759a206d355ecc1cbe15c966328d3b3432bd7af17df3d")
