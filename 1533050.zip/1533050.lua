-- Lua provided by RyzenAPI
-- Game: Press Ctrl

-- MAIN APPLICATION
addappid(1533050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533051, 1, "fe7169949df7efd8df8759a206d355ecc1cbe15c966328d3b3432bd7af17df3d")
