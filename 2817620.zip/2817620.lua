-- Lua provided by RyzenAPI
-- Game: Game: Machinika: Atlas

-- MAIN APPLICATION
addappid(2817620)
-- Game: addappid(2817620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817621, 1, "6f999510e0319de0fa5c57dfebb31ccbbfa59fcac892e17b985561da7970cf9a")
