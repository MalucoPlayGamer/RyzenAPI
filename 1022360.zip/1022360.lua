-- Lua provided by RyzenAPI
-- Game: 1022360

-- MAIN APPLICATION
addappid(1022360)
-- Game: addappid(1022360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022360,0,"4114ac5ff7a5b6e52fbbc7971f372e992694360c637318b222ec7bf24fa5a5dd")
