-- Lua provided by RyzenAPI
-- Game: TouHou Makuka Sai ~ Fantastic Danmaku Festival

-- MAIN APPLICATION
addappid(882710)
addappid(929350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(882711, 1, "c579778b6493494fd554d6045ddf8773b6d4b7c5ee39ef9ab55d6a7d65ae6cbe")
addappid(882712, 1, "f9c6fac5c10f32f5a7b993f4c253a519a5d9e0d0967d6339dc031f46f48a1b38")
addappid(882713, 1, "6355f61710e007d980aceae7b5f8154e46de42a4642d8df06983f38d63b94007")
addappid(882714, 1, "6516c53eabfa301fc365bd9db749d0d15479cf464e598d12719f82385c052079")
addappid(882715, 1, "804ee42b4c7218a26e189004992b568c8cad2062ba7de45148b4a25fb1c064f6")

