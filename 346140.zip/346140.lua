-- Lua provided by RyzenAPI
-- Game: Hidden Object Bundle 5 in 1

-- MAIN APPLICATION
addappid(346140)
addappid(357860)
addappid(357861)
addappid(357862)

-- MAIN APP DEPOTS / PACKAGES
addappid(346141, 1, "b964714dfe201fb08ad1dff1033fbb08e694b18c32b98330b101be74836f88e2")
