-- Lua provided by RyzenAPI
-- Game: Captain of Industry - Soundtrack

-- MAIN APPLICATION
addappid(2004660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004661, 1, "d5f6bd754404f2b19465e5d4611487dba3e338d3ad20738c582e8f4a5ba0062b")
addappid(2004663, 1, "4d438c4923cd4a3f5884316f0fd3a575a2c26209fac9cb9c7216c79ec27fa423")

