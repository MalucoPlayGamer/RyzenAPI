-- Lua provided by SkyAPI 
-- Game: Contagion
addappid(238430)
addappid(238431, 1, "9634d3738964c481192d594ce8d7f9a419a244256b490377943a7bffc8b0ea19")
addappid(238432, 1, "f00f954df6fbd23bb1489bbbc205d4aaa14cd59e86be36568a009ffec817fc26")
addappid(2733030, 0, "e66920b6c71eeae9b09000478cfa408aaf4bcf7ac73d62acb75ed60896d227d7")
