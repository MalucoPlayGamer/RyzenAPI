-- Lua provided by RyzenAPI
-- Game: Contagion

-- MAIN APPLICATION
addappid(238430)

-- MAIN APP DEPOTS / PACKAGES
addappid(238431, 1, "9634d3738964c481192d594ce8d7f9a419a244256b490377943a7bffc8b0ea19")
addappid(238432, 1, "f00f954df6fbd23bb1489bbbc205d4aaa14cd59e86be36568a009ffec817fc26")
addappid(2733030, 0, "e66920b6c71eeae9b09000478cfa408aaf4bcf7ac73d62acb75ed60896d227d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
