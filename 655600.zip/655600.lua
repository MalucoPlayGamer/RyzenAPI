-- Lua provided by RyzenAPI 
-- Game: PHAT STACKS 2
addappid(655600)
addappid(655601, 1, "e6d61905abe6d6182d7b3156ecab8186274e9d954c2ddc7871225b7a293468dc")
