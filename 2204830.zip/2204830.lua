-- Lua provided by RyzenAPI
-- Game: Street Lords

-- MAIN APPLICATION
addappid(2204830)
-- Game: addappid(2204830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204831, 1, "45febbdb8a1170dbca379da9c30fc05635ae6b91043addd5e2de875b024c486a")
