-- Lua provided by RyzenAPI
-- Game: AppID 741590

-- MAIN APPLICATION
addappid(741590)
addappid(792510)

-- MAIN APP DEPOTS / PACKAGES
addappid(741591, 1, "5074989fd54c540a30e7631a2b8975644e347310839ea79628c163446160293a")
addappid(741592, 1, "de02ebb36a508a9313edced1442f874a510c4550664504ea8ccba44f99173424")
addappid(741593, 1, "9afdfb1eb7c86cbf5b262fdc2d918623233f21c3e366eec9fa195ffdc5658e26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
