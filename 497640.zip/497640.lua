-- Lua provided by RyzenAPI
-- Game: Trick & Treat

-- MAIN APPLICATION
addappid(497640)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(520360)
