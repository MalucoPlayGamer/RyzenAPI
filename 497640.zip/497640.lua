-- Lua provided by RyzenAPI
-- Game: Trick & Treat

-- MAIN APPLICATION
addappid(497640)
