-- Lua provided by RyzenAPI
-- Game: Game: Eastwood VR

-- MAIN APPLICATION
addappid(612250)
-- Game: addappid(612250)

-- MAIN APP DEPOTS / PACKAGES
addappid(612251, 1, "4fd789747d6aa420721f55943cc2c5d490b2685b00482a169e406455eda1a4ea")
