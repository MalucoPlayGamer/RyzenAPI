-- Lua provided by RyzenAPI
-- Game: Dungeon Renovation Simulator

-- MAIN APPLICATION
addappid(2222020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222021, 1, "588ee7aa488e1e51c14b98a53afb3d36a29ac49bbe22725272693ad6c6166d6f")

