-- Lua provided by RyzenAPI
-- Game: Jigsaw Puzzle World - Brazil

-- MAIN APPLICATION
addappid(2378333)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378333,0,"be5e17c178f697ae18972b5f70f258940c7c84bcb2998ec28e2874e1d9f9063c")

