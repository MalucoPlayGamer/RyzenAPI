-- Lua provided by RyzenAPI
-- Game: Trikaya

-- MAIN APPLICATION
addappid(1410870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410871, 1, "15968fc13b1114f042d1f5a05dbf24530f2e252af9810355e2a7921ed3dac3b3")

