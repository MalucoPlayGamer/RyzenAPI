-- Lua provided by SkyAPI 
-- Game: AppID 406860
addappid(406860)
addappid(406861, 1, "6f65031467a11e9fc1151258bbff94fe6b5f0fc1f541d35f6582ecb7b228b2a0")
addappid(943351)
