-- Lua provided by RyzenAPI
-- Game: 406860

-- MAIN APPLICATION
addappid(406860)
addappid(943351)
-- Game: addappid(406860)

-- MAIN APP DEPOTS / PACKAGES
addappid(406861, 1, "6f65031467a11e9fc1151258bbff94fe6b5f0fc1f541d35f6582ecb7b228b2a0")
