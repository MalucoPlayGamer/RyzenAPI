-- Lua provided by RyzenAPI
-- Game: Bone: Out From Boneville

-- MAIN APPLICATION
addappid(8310)
-- Game: addappid(8310)

-- MAIN APP DEPOTS / PACKAGES
addappid(8311, 1, "f3b30e82feac8a3eb629d5e9387ce62524ed6fc66ae115a31d7bce828bb98729")
