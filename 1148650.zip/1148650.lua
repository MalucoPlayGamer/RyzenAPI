-- Lua provided by RyzenAPI
-- Game: addappid(1148650)

-- MAIN APPLICATION
addappid(1148650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148651, 1, "0361f8c703f261c61a120fa9cfb3dbe199e54a6f18e5c23db49f39769d2941ea")
