-- Lua provided by RyzenAPI
-- Game: Highline Volleyball VR

-- MAIN APPLICATION
addappid(1852940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1852941, 1, "80fb49e7dd71a99319053f29400689ba9a66dcbba148921d60c7dc1a619c14f4")

