-- Lua provided by RyzenAPI
-- Game: Highline Volleyball VR

-- MAIN APPLICATION
addappid(1852940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852941, 1, "80fb49e7dd71a99319053f29400689ba9a66dcbba148921d60c7dc1a619c14f4")

