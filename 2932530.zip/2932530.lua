-- Lua provided by RyzenAPI
-- Game: 海山 Demo

-- MAIN APPLICATION
addappid(2932530)
-- Game: addappid(2932530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932531, 1, "45a4e84127e8d5b90e133f665a034785bad8caa96027aed12f312137b9d5ee0a")
