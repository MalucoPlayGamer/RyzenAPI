-- Lua provided by RyzenAPI
-- Game: addappid(2360370)

-- MAIN APPLICATION
addappid(2360370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360371, 1, "8f49e910d9ee141bb36af87dbf43fe04fcf949afbfeee9a7bb346853a24c037c")
