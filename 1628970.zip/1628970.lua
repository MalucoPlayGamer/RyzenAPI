-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1628970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628970,0,"fe78856ba4872c2bbe6f81cc161799e2c05e804abf4ebdb0e83b830ebe91f02f")

