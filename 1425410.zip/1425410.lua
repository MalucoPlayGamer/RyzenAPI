-- Lua provided by RyzenAPI
-- Game: Castlehold

-- MAIN APPLICATION
addappid(1425410)
-- Game: addappid(1425410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425411, 1, "d123136445255edf80838cb023aa16f1c2f4980e29642869a471fa3d7f822228")
