-- Lua provided by RyzenAPI
-- Game: 1375364

-- MAIN APPLICATION
addappid(1375364)
-- Game: addappid(1375364)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375364,0,"120f82028d894060f494e19474bc8fce6e24b01f3ff4af0fef9c3f40e99a54ca")
