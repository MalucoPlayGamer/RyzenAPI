-- Lua provided by RyzenAPI
-- Game: addappid(2124440)

-- MAIN APPLICATION
addappid(2124440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124441, 1, "f0a6527ad3b63715b736cd00de04c038d41f493cd180924fe7574055db06ab36")
addappid(2124442, 1, "77a55303f1236b2c9d34f46feea9035bba1cc6e6da9c0bea2bc6f0f3efb56f36")
addappid(2124443, 1, "f3ce1b264c0c59540ab215a66906e4ad576af829e7f11defbd29a3aaafcd7a7e")
