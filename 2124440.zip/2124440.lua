-- Lua provided by RyzenAPI
-- Game: SIC-1

-- MAIN APPLICATION
addappid(2124440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124441, 1, "f0a6527ad3b63715b736cd00de04c038d41f493cd180924fe7574055db06ab36")
addappid(2124442, 1, "77a55303f1236b2c9d34f46feea9035bba1cc6e6da9c0bea2bc6f0f3efb56f36")
addappid(2124443, 1, "f3ce1b264c0c59540ab215a66906e4ad576af829e7f11defbd29a3aaafcd7a7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
