-- Lua provided by RyzenAPI 
-- Game: SomnaBuster Demo
addappid(2743580)
addappid(2743581, 1, "84f09dee03afb837c2c34cf05eefca1590cdc36a1512b2794244a1035b128a4c")
