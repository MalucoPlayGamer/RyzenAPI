-- Lua provided by RyzenAPI
-- Game: Livingmare Cold Calls

-- MAIN APPLICATION
addappid(2805800)
-- Game: addappid(2805800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805801, 1, "79e041fccb75a853221e73ee1e6697fc1b0e00dbcbd54a2a9203b0bd95011728")
