-- Lua provided by RyzenAPI
-- Game: Doodle Harmony Idle Merge

-- MAIN APPLICATION
addappid(2949230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949231, 1, "be2c558a0833ec8e6e8d376a90605b89616861d063dcd037dc8e9b4271620118")
