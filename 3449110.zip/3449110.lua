-- Lua provided by RyzenAPI
-- Game: STELA BOSS

-- MAIN APPLICATION
addappid(3449110)
-- Game: addappid(3449110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449111, 1, "18f5ee2f39900573c4d68733e245c23687cd580c972ba63bf9755a2e9c4d3cb3")
