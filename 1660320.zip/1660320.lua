-- Lua provided by SkyAPI 
-- Game: AppID 1660320
addappid(1660320)
addappid(1660321, 1, "deab97bf0835c356f7be3d77e56255308bc5f70b0596200f2d8da9862fddf1dc")
