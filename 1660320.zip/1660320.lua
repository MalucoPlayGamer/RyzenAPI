-- Lua provided by RyzenAPI
-- Game: AppID 1660320

-- MAIN APPLICATION
addappid(1660320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660321, 1, "deab97bf0835c356f7be3d77e56255308bc5f70b0596200f2d8da9862fddf1dc")

