-- Lua provided by RyzenAPI
-- Game: 1631350

-- MAIN APPLICATION
addappid(1631350)
-- Game: addappid(1631350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631351, 1, "316077807a41e9a211ddf65b60b17bea20a862c0d51bf4e23639eafd6e39b1fe")
