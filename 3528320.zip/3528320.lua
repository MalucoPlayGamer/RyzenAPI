-- Lua provided by RyzenAPI
-- Game: Secret Seeker

-- MAIN APPLICATION
addappid(3528320)
-- Game: addappid(3528320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3528321, 1, "0cbd9a9af00df5d9df3a90af603d6f86efec63e562d09290c4e09eb1dc5040bf")
