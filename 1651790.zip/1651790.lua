-- Lua provided by RyzenAPI
-- Game: 1651790

-- MAIN APPLICATION
addappid(1651790)
-- Game: addappid(1651790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651791, 1, "459746ca66c0d336c430fd00fe74a8c674c5eb089cbf36aa62c6f082f001a57e")
