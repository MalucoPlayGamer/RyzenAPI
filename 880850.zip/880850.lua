-- Lua provided by RyzenAPI
-- Game: War Rock

-- MAIN APPLICATION
addappid(880850)

