-- Lua provided by RyzenAPI
-- Game: Femboy Survival

-- MAIN APPLICATION
addappid(3832120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3832121,0,"5fe0e6ae52258769eb74bc7a5f9438ffd660489495b7e15f347074e9f10bbc80")

