-- Lua provided by RyzenAPI
-- Game: Game: On The Road - The Truck Simulator

-- MAIN APPLICATION
addappid(285380)
-- Game: addappid(285380)

-- MAIN APP DEPOTS / PACKAGES
addappid(285381, 1, "47acd030329a5e7076013a74d10e3877b9e6893d035b92e65677f21d1d4c97ae")
