-- Lua provided by RyzenAPI
-- Game: Epistory - Original Soundtrack

-- MAIN APPLICATION
addappid(458530)

-- MAIN APP DEPOTS / PACKAGES
addappid(458530,0,"f7e9d2eb7dbb49c90d5e3be89b54afeff9a9300df3c77045687627da4785f436")
