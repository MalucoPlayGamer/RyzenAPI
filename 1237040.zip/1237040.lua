-- Lua provided by RyzenAPI
-- Game: AppID 1237040

-- MAIN APPLICATION
addappid(1237040)
addappid(1639540)
addappid(1640200)
addappid(1686740)
addappid(1776020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237041, 1, "237017fe0125f2dcabdfb0167b5ff684f2e691b247f523c99eb126c1c3bd6939")

