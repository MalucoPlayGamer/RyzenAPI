-- Lua provided by RyzenAPI
-- Game: addappid(2924870)

-- MAIN APPLICATION
addappid(2924870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924871, 1, "2928d9cb36a0cd671f6cd0dec805205c1bfb3c5b7293275d510a40ac9b41113d")
