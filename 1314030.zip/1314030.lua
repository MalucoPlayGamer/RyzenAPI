-- Lua provided by RyzenAPI
-- Game: DungeonTop Demo

-- MAIN APPLICATION
addappid(1314030)
-- Game: addappid(1314030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314031, 1, "d1799eea60e51c5576792583b1935bfb9176958279baab8193d37c6621ca811d")
