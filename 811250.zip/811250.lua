-- Lua provided by RyzenAPI
-- Game: Content Creator Simulator

-- MAIN APPLICATION
addappid(811250)
-- Game: addappid(811250)

-- MAIN APP DEPOTS / PACKAGES
addappid(811251, 1, "36d8eeed18c556f17c9895c0a7a453fde04b3f7c26b4fa388edfc399432c1080")
