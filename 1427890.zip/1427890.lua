-- Lua provided by SkyAPI 
-- Game: Blaston
addappid(1427890)
addappid(1427891, 1, "0c4dbd67cb5c1026ffc42b2416ca506b64339c7654216e34132fe2d0680f5656")
