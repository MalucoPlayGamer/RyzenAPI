-- Lua provided by RyzenAPI
-- Game: A Juggler's Tale Demo

-- MAIN APPLICATION
addappid(1281550)
-- Game: addappid(1281550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281551, 1, "a76dfd85dbe615d1c089940910199410e697d257f12aca11637216499766eaa7")
