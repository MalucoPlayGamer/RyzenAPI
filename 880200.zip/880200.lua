-- Lua provided by RyzenAPI
-- Game: Game: J15 Jet Fighter VR (歼15舰载机)

-- MAIN APPLICATION
addappid(880200)
-- Game: addappid(880200)

-- MAIN APP DEPOTS / PACKAGES
addappid(880201, 1, "1c318224080cbef14295af270cfe39e4b88dfe7ac686404588e0ae40ceb168c4")
