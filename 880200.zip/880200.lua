-- Lua provided by RyzenAPI
-- Game: 880200

-- MAIN APPLICATION
addappid(880200)
-- Game: addappid(880200)

-- MAIN APP DEPOTS / PACKAGES
addappid(880201, 1, "1c318224080cbef14295af270cfe39e4b88dfe7ac686404588e0ae40ceb168c4")
