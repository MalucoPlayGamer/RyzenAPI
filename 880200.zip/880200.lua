-- Lua provided by RyzenAPI
-- Game: J15 Jet Fighter VR (歼15舰载机)

-- MAIN APPLICATION
addappid(880200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(880201, 1, "1c318224080cbef14295af270cfe39e4b88dfe7ac686404588e0ae40ceb168c4")

