-- Lua provided by RyzenAPI
-- Game: YouRiding - Surfing and Bodyboarding Game

-- MAIN APPLICATION
addappid(1725680)
-- Game: addappid(1725680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725681, 1, "95ed52014c2fa671ab91bb681ff30ab25da45ce5c2043719f979e7ea39f888e5")
addappid(1725682, 1, "9fffa463d55482e1a1e62dae9a4d06b31645cc7ecf6c6e333c5574ebd32b3e83")
addappid(1725683, 1, "5a76fa5b0ca2d98d44e0a94f396e3a2ba0d707720da979bf1fbdead92875edf6")
addappid(1725684, 1, "f16bb18637b4c7e710356d12e33c89e924ab007c3b7096aa6ff6a8e43d3d3de5")
