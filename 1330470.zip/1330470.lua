-- Lua provided by RyzenAPI
-- Game: F.I.S.T.: Forged In Shadow Torch

-- MAIN APPLICATION
addappid(1330470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1330471, 1, "90bde5ea2666baa460c9476da114f0a78a6b63f314fcfb7456c0f499841e5dfb")
addappid(1330472, 1, "2ee73d4dd8b85b4d1601563faf22a7a679a33f4fafe1766746e8e448e4a79bcb")

