-- Lua provided by RyzenAPI
-- Game: Game: F.I.S.T.: Forged In Shadow Torch

-- MAIN APPLICATION
addappid(1330470)
-- Game: addappid(1330470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330471, 1, "90bde5ea2666baa460c9476da114f0a78a6b63f314fcfb7456c0f499841e5dfb")
addappid(1330472, 1, "2ee73d4dd8b85b4d1601563faf22a7a679a33f4fafe1766746e8e448e4a79bcb")
