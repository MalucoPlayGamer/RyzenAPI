-- Lua provided by RyzenAPI
-- Game: Kart kids

-- MAIN APPLICATION
addappid(1206230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206231, 1, "2067c97ba13f70c4da6a6dd44657df207e60f34122540138aefc966b840477cc")
addappid(1206232, 1, "37cb9da40d95399484bbeb30a00ec97afeb99df96b3838ab8a758f69f36cdbde")

