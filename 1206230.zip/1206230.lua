-- Lua provided by SkyAPI 
-- Game: Kart kids
addappid(1206230)
addappid(1206231, 1, "2067c97ba13f70c4da6a6dd44657df207e60f34122540138aefc966b840477cc")
addappid(1206232, 1, "37cb9da40d95399484bbeb30a00ec97afeb99df96b3838ab8a758f69f36cdbde")
