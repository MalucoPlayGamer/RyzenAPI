-- Lua provided by RyzenAPI
-- Game: 2430700

-- MAIN APPLICATION
addappid(2430700)
-- Game: addappid(2430700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430701, 1, "afbc916900bc78d7753c3fd2886678938a2708d44c7729f2b9bd6bcc45343e0a")
