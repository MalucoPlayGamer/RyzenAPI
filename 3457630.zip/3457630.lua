-- Lua provided by RyzenAPI
-- Game: Dwarven Rampart

-- MAIN APPLICATION
addappid(3457630) -- Dwarven Rampart

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3457631, 1, "d072bc34e455d5566176910ce7c0ac8a16ad72c362a4608d8471c1f1d3313279") -- Depot 3457631

