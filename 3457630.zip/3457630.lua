-- 3457630's Lua and Manifest Created by Hubcap Manifest
-- Dwarven Rampart
-- Created: August 12, 2026 at 09:12:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3457630) -- Dwarven Rampart
-- MAIN APP DEPOTS
addappid(3457631, 1, "d072bc34e455d5566176910ce7c0ac8a16ad72c362a4608d8471c1f1d3313279") -- Depot 3457631
setManifestid(3457631, "3937398253411068836", 436979794)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)