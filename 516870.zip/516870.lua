-- Lua provided by RyzenAPI
-- Game: Isomorph

-- MAIN APPLICATION
addappid(516870)

-- MAIN APP DEPOTS / PACKAGES
addappid(516871,0,"ba0e5a1c180796854cc5760dbfd93e593478074166fdb78f7301e71a383f908b")

