-- Lua provided by RyzenAPI 
-- Game: DEAD TRASH
addappid(3316470)
addappid(3316471, 1, "61993ca217a99ef735b4844b2464764eb8e4462c16d0b36d7701c116b7843d29")
