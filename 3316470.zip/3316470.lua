-- Lua provided by RyzenAPI
-- Game: DEAD TRASH

-- MAIN APPLICATION
addappid(3316470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316471, 1, "61993ca217a99ef735b4844b2464764eb8e4462c16d0b36d7701c116b7843d29")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4224540)
