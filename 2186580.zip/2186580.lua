-- Lua provided by RyzenAPI
-- Game: addappid(2186580)

-- MAIN APPLICATION
addappid(2186580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186581, 1, "5b0cda9fb9d3c078c6f6e91f19ff00eeb10733c39183cefe0d8b962991cc8f1c")
