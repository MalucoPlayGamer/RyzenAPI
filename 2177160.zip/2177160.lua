-- Lua provided by RyzenAPI
-- Game: addappid(2177160)

-- MAIN APPLICATION
addappid(2177160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177161, 1, "c91b525e4461fb24321d61edcf38d6c2449b0fffc76308e9c5a82a9f908b682f")
