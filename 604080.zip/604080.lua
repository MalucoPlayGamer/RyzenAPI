-- Lua provided by RyzenAPI 
-- Game: AppID 604080
addappid(604080)
addappid(604081, 1, "602f1c14e20b4f3bf056a5b75dcb04da3651caf30c4c6be98cdfbddd73f61c42")
