-- Lua provided by RyzenAPI
-- Game: AppID 423600

-- MAIN APPLICATION
addappid(423600)

-- MAIN APP DEPOTS / PACKAGES
addappid(423601, 1, "a224ea4e1acd41e5490eaa91e1c5ccfbf768131cc3bb6990e7446347e32062ae")
addappid(423607, 1, "15adcfe05a00bb9ca382c20d4ccb640980ea89478fe60d54f1d3fde29c4e645d")
addappid(423609, 1, "0837fb9145d174dd406f1a4cefe0ad045edfdf8fd024a818642a9c20167c1a21")

