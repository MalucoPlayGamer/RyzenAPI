-- Lua provided by RyzenAPI
-- Game: AppID 1300700

-- MAIN APPLICATION
addappid(1300700)
-- Game: addappid(1300700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300701, 1, "f3d26acdefd143d64bbfa1e7cd40980b61842f3dc907af9bc6965a39b27524cb")
addappid(1377570, 0, "e15ee34e787764d58dfaadd7f9b72ff487bef2b374676cbb9a856e7f206d924d")
