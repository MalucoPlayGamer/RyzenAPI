-- Lua provided by RyzenAPI
-- Game: AppID 2378470

-- MAIN APPLICATION
addappid(2378470)
-- Game: addappid(2378470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378471, 1, "206c5b9806f8e944c311e2d6d5973d0b4168150ceebd423a9c890acc8e088966")
