-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Episode II: Epsilon Indi

-- MAIN APPLICATION
addappid(431710)

-- MAIN APP DEPOTS / PACKAGES
addappid(431711, 1, "b7f1eabc6655bbe240f75b856e0bfbc1fd6d85a74d079cba77b3da5e182cac22")

