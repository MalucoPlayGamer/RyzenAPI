-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel (Manga) Vol. 4

-- MAIN APPLICATION
addappid(3534970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3534971, 1, "cfe8e0f436a18dac235b8b908a6fc7106e761ebb735f3ae485da9045b84c8a17")

