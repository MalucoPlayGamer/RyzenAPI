-- Lua provided by RyzenAPI
-- Game: Second Warfare

-- MAIN APPLICATION
addappid(372740)

-- MAIN APP DEPOTS / PACKAGES
addappid(372741, 1, "1f56c7c09dba4d642e2c03cfe56913bab823cc4c1dc9761f90d88f41d7a141fe")
addappid(372742, 1, "86ce360cf55f9f1c4f2151f5275acc3ae2b071a480887bec00eebecddec3fd7a")
addappid(372743, 1, "7c732231fddc9bdd4bf758c71ee6c5adbf715ac463878411d65b2b62f871e672")
addappid(372744, 1, "43ca0cf30f43fdfb43b91a3d2ab91765b1709dbe74481e2b8a6a641ed8cfbb6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
