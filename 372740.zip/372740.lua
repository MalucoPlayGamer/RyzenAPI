-- Lua provided by RyzenAPI
-- Game: 372740

-- MAIN APPLICATION
addappid(372740)
-- Game: addappid(372740)

-- MAIN APP DEPOTS / PACKAGES
addappid(372741, 1, "1f56c7c09dba4d642e2c03cfe56913bab823cc4c1dc9761f90d88f41d7a141fe")
addappid(372742, 1, "86ce360cf55f9f1c4f2151f5275acc3ae2b071a480887bec00eebecddec3fd7a")
addappid(372743, 1, "7c732231fddc9bdd4bf758c71ee6c5adbf715ac463878411d65b2b62f871e672")
addappid(372744, 1, "43ca0cf30f43fdfb43b91a3d2ab91765b1709dbe74481e2b8a6a641ed8cfbb6f")
