-- Lua provided by RyzenAPI 
-- Game: CARGAME
addappid(1519130)
addappid(1519131, 1, "60b39c679ba9915a38f55896dbd38f0cae3a6ce307cb6d7cd4788b3f55201012")
