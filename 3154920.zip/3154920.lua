-- Lua provided by RyzenAPI
-- Game: addappid(3154920)

-- MAIN APPLICATION
addappid(3154920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154921, 1, "ef480d4ca2f80936cd47dc6c2867274444253ca06a0a09c460c341f9de2b0022")
