-- Lua provided by SkyAPI 
-- Game: Rift of the NecroDancer Level Editor
addappid(3154920)
addappid(3154921, 1, "ef480d4ca2f80936cd47dc6c2867274444253ca06a0a09c460c341f9de2b0022")
