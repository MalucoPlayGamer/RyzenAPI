-- Lua provided by RyzenAPI
-- Game: Game: AppID 718310

-- MAIN APPLICATION
addappid(718310)
-- Game: addappid(718310)

-- MAIN APP DEPOTS / PACKAGES
addappid(718311, 1, "6dc4830fb6382d452372e31b43caf0552792404cb2cbd1e1851fbf8d5f60dfda")
