-- Lua provided by RyzenAPI
-- Game: Game: The Oldest Edda

-- MAIN APPLICATION
addappid(1745560)
-- Game: addappid(1745560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745561, 1, "9897a81f2d76292beff488bdf48ae1956951d34e24ab7f1e9ac30cf6681ef583")
