-- Lua provided by RyzenAPI 
-- Game: The Oldest Edda
addappid(1745560)
addappid(1745561, 1, "9897a81f2d76292beff488bdf48ae1956951d34e24ab7f1e9ac30cf6681ef583")
