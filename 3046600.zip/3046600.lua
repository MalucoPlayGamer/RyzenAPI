-- Lua provided by RyzenAPI
-- Game: Onimusha 2: Samurai's Destiny

-- MAIN APPLICATION
addappid(3046600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046601, 1, "7fefe6bb14dbd1acc54a633e5ed7321340bd3ca828373a0f394cc09a13ef9dbe")
addappid(3128200, 0, "431b85393dd33aff931d9749b72c4ddafa5081e072dbcf801a58fa04cc09ca07")
