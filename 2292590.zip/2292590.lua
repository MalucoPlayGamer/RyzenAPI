-- Lua provided by RyzenAPI
-- Game: Sexy Valentine 🍆 💜

-- MAIN APPLICATION
addappid(2292590)
-- Game: addappid(2292590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292591, 1, "faafca812bb58e3d19f826cd5e7ad7fad798fc11ca2e7dddb161bc7be8a0a027")
