-- Lua provided by RyzenAPI
-- Game: Milky Rush-Two Paths

-- MAIN APPLICATION
addappid(3856980) -- Milky Rush-Two Paths

-- MAIN APP DEPOTS / PACKAGES
addappid(3856981, 1, "fe1de9c89bfc0f169ec9797aace12842f72869fb22ebd32fc1d869bebcdf28f1") -- Depot 3856981

