-- Lua provided by RyzenAPI
-- Game: Romero's Aftermath

-- MAIN APPLICATION
addappid(349700)

-- MAIN APP DEPOTS / PACKAGES
addappid(349701, 1, "aa15c5bccde35f6301455dc0e2b6bf659c8862f951bd4d113e30548d45114905")
