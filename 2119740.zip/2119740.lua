-- Lua provided by RyzenAPI 
-- Game: AppID 2119740
addappid(2119740)
addappid(2119741, 1, "dcd6421cbcaadc61802f27681ffad8e251ef769eab9e2b7ec5290183d202dd24")
