-- Lua provided by RyzenAPI
-- Game: Supernormal

-- MAIN APPLICATION
addappid(2532430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532431, 1, "5e04f302a2021e890ded0718ad7e60326b21923867f97b427193fec229623ff2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
