-- Lua provided by RyzenAPI
-- Game: FUSER™ - Ava Max - "Kings & Queens"

-- MAIN APPLICATION
addappid(1432144)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432144,0,"8c4af2967d918ee8db0e5cfa93f98fa365e38dfc1c59812f2fdf2837924f299e")

