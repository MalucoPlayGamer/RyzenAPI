-- Lua provided by RyzenAPI
-- Game: 1179570

-- MAIN APPLICATION
addappid(1179570)
-- Game: addappid(1179570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179571, 1, "9cbb3e137bf3f645372d0061fe8f20b21e1bfc3b2a30afe32f7b21b59ac5e2bd")
