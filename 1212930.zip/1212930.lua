-- Lua provided by RyzenAPI
-- Game: 1212930

-- MAIN APPLICATION
addappid(1212930)
-- Game: addappid(1212930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212931, 1, "ab448d87f4bfc2461515da0e1fd250dd68d733aec584cd77a5c92bce10a9bc3c")
