-- Lua provided by RyzenAPI
-- Game: Doler

-- MAIN APPLICATION
addappid(1212930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212931, 1, "ab448d87f4bfc2461515da0e1fd250dd68d733aec584cd77a5c92bce10a9bc3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
