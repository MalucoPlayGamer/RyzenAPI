-- Lua provided by RyzenAPI
-- Game: addappid(1503540)

-- MAIN APPLICATION
addappid(1503540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503541, 1, "d715506e486dbf0080be1650e2f8fd050ce68a0bcf98a669e1e80bd16420ba22")
