-- Lua provided by SkyAPI 
-- Game: Mission IDLE
addappid(1503540)
addappid(1503541, 1, "d715506e486dbf0080be1650e2f8fd050ce68a0bcf98a669e1e80bd16420ba22")
