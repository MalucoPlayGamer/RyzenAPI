-- Lua provided by RyzenAPI
-- Game: addappid(1987990)

-- MAIN APPLICATION
addappid(1987990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987991, 1, "633de0f90ae362230afae2a9b90fadd979cfa585fdf77719b878fb7a2891d35c")
