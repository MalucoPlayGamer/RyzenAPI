-- Lua provided by SkyAPI 
-- Game: Vanilla Brulee & The Rose Bandit
addappid(1987990)
addappid(1987991, 1, "633de0f90ae362230afae2a9b90fadd979cfa585fdf77719b878fb7a2891d35c")
