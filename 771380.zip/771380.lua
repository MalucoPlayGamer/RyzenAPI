-- Lua provided by RyzenAPI
-- Game: addappid(771380)

-- MAIN APPLICATION
addappid(771380)

-- MAIN APP DEPOTS / PACKAGES
addappid(771381, 1, "5886baaf168284ff6735b02a6be6c2e4aa5d26a75b049ed35df1d177497dcf79")
