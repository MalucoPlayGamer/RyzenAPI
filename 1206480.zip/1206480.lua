-- Lua provided by RyzenAPI
-- Game: Game: Swordsman VR

-- MAIN APPLICATION
addappid(1206480)
-- Game: addappid(1206480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206481, 1, "547327d0263bf39a7565ec9d26a363234a8362049c201efbb02596625a875a73")
