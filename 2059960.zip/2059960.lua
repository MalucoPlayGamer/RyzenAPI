-- Lua provided by RyzenAPI
-- Game: The Rumble Fish 2

-- MAIN APPLICATION
addappid(2059960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059961, 1, "d3e8bebeac786c158a618ccc306a931c6f1083e4ecba4dd9ce44fc6bc08b8af9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2129310)
addappid(2129311)
addappid(2129312)
