-- Lua provided by RyzenAPI
-- Game: Game: The Rumble Fish 2

-- MAIN APPLICATION
addappid(2059960)
-- Game: addappid(2059960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059961, 1, "d3e8bebeac786c158a618ccc306a931c6f1083e4ecba4dd9ce44fc6bc08b8af9")
