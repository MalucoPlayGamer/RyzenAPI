-- Lua provided by RyzenAPI
-- Game: Godrop

-- MAIN APPLICATION
addappid(2657310)
addappid(2973780)
-- Game: addappid(2657310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657311, 1, "efcbc3f0f5b2689d083f0e1ca5fc5202c68fb3e184f11a11fe897b35231fdc62")
