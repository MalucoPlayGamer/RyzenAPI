-- Lua provided by RyzenAPI
-- Game: 100 hidden birds 2

-- MAIN APPLICATION
addappid(1766790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766791, 1, "e720e5204f761f60bc20e68a296038bff71f8b9f1639fa7cdd720b3c101a531c")
