-- Lua provided by RyzenAPI
-- Game: AppID 674250

-- MAIN APPLICATION
addappid(674250)

-- MAIN APP DEPOTS / PACKAGES
addappid(674251, 1, "92fddb0abdcb57fd817279cf221e837883b8155e319f3e6ddd0b3751e6b58efe")

