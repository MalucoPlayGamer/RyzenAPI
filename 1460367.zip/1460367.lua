-- Lua provided by RyzenAPI
-- Game: 1460367

-- MAIN APPLICATION
addappid(1460367)
-- Game: addappid(1460367)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460367,0,"fdb1cbba38f60ef537c967b4e520fe1f03c2015574bd734eaa2ca0723aa03670")
