-- Lua provided by SkyAPI 
-- Game: 景行 | Encourage
addappid(994750)
addappid(994751, 1, "93e0dc2ee5314024d2573e44aef09c92b5d36f41e7a32a88e5c176598fc7de54")
addappid(994752, 1, "271151e12066542e015d3925cf4e5d87b0656bd9fe23deea4d9d73b6b23c1a97")
