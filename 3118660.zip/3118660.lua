-- Lua provided by RyzenAPI
-- Game: Hello Cruel World - Soundtrack

-- MAIN APPLICATION
addappid(3118660)
-- Game: addappid(3118660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118663,0,"d72a693969a0e3ac5632771284a3cc1c73e17534267d71bdf00f6e91b2428424")
addappid(3118664,0,"a535404f47c43b8a724e58e35f3ab5cb999c402804a2330c69630b1b5ca02009")
