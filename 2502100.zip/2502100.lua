-- Lua provided by RyzenAPI
-- Game: Journey to the West - Blade Souls

-- MAIN APPLICATION
addappid(2502100)
addappid(2502101)

-- MAIN APP DEPOTS / PACKAGES
addappid(2502100,0,"67d7791aa8a9e072921f2cbf00ad91230a4f3308a6f1c36e8b54e2b685caff46")
