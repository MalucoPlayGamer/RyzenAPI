-- Lua provided by RyzenAPI
-- Game: The Falconers: Moonlight

-- MAIN APPLICATION
addappid(589480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(589481, 1, "2b0da5e47861bfffd53f48278885e8097990745ac42eab922ef8da4271982421")
