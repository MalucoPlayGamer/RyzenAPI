-- Lua provided by RyzenAPI
-- Game: 589480

-- MAIN APPLICATION
addappid(589480)
-- Game: addappid(589480)

-- MAIN APP DEPOTS / PACKAGES
addappid(589481, 1, "2b0da5e47861bfffd53f48278885e8097990745ac42eab922ef8da4271982421")
