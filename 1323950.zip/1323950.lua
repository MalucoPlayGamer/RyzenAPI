-- Lua provided by RyzenAPI
-- Game: Game: Dungeons & Bombs

-- MAIN APPLICATION
addappid(1323950)
-- Game: addappid(1323950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323951, 1, "f3822c3bb98e6a029695eb18dfc052bb52d5c2f71a4d92288e424bc014a7663e")
