-- Lua provided by RyzenAPI
-- Game: addappid(1315410)

-- MAIN APPLICATION
addappid(1315410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315411, 1, "33de9c8c6037e0de2bed6905205d9fdc5b1c6679af1ce4c5a088c3f81edc96c8")
