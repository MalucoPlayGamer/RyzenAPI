-- Lua provided by SkyAPI 
-- Game: AppID 1492860
addappid(1492860)
addappid(1492861, 1, "926847c796af71b5df6cd58367ccff501cb2b8b44c88ad0bb02f2fb29a0715ba")
