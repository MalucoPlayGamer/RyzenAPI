-- Lua provided by RyzenAPI
-- Game: 三国志奇侠传

-- MAIN APPLICATION
addappid(1492860)
addappid(1522910)
addappid(1523280)
addappid(1523300)
addappid(1523310)
addappid(1523380)
addappid(1524200)
addappid(1524210)
addappid(1524220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492861,0,"926847c796af71b5df6cd58367ccff501cb2b8b44c88ad0bb02f2fb29a0715ba")

