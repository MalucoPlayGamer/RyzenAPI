-- Lua provided by SkyAPI 
-- Game: AppID 3203520
addappid(3203520)
addappid(3203521, 1, "ead8a60a4c0d869830f0a53d1250be69af7bfa62bdb787d15e5569a73f7714aa")
