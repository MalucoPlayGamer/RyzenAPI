-- Lua provided by RyzenAPI
-- Game: Lynked: Banner of the Spark Demo

-- MAIN APPLICATION
addappid(3203520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203521, 1, "ead8a60a4c0d869830f0a53d1250be69af7bfa62bdb787d15e5569a73f7714aa")

