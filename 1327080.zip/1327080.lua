-- Lua provided by RyzenAPI
-- Game: Tower and Sword of Succubus

-- MAIN APPLICATION
addappid(1327080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327081, 1, "cb2b4add371e439241034149f122fbe8dfa23554d90909006c73d5e3dbe93ab8")
addappid(1404680, 0, "4303eaee0a90e3962f37e575661e426dd6609a816256e83816a0a27569a36759")

