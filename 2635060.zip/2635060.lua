-- Lua provided by RyzenAPI
-- Game: Ocelot Sunrise Demo

-- MAIN APPLICATION
addappid(2635060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635061, 1, "1381eba80b3742322faa3b4f528ac6629040228f4439a9bd17ed59b0fc7780fd")

