-- Lua provided by SkyAPI 
-- Game: The King's Request: Physiology and Anatomy Revision Game
addappid(873230)
addappid(873231, 1, "3ff96f3a895ce3b3f72228911ea2d7963a8d298f64d71dbbaa8472db3ef4b7ab")
addappid(873232, 1, "36abf2ab6c178f13b4d934a1900bfec38bf53e1560b6e0aa12cc32801f2d3a25")
addappid(873233, 1, "55395a8713627c2bde752c8f39c3da52885076b5941290ee932e37c249ae27c2")
