-- Lua provided by RyzenAPI
-- Game: Game: Guts and Glory

-- MAIN APPLICATION
addappid(537340)
-- Game: addappid(537340)

-- MAIN APP DEPOTS / PACKAGES
addappid(537341, 1, "9666002b803cda0f99f93e3397766e9c6c0cb883c255707baf99c801e84a0925")
addappid(537342, 1, "ed469e4612ea75de1c81b19cf544912616276e2ede60b1cfc0cd516fc73725d2")
addappid(537343, 1, "4af51fcd9f2fdb0102b86c4d9d96bb6a8d926bdfb5d4980d88585e169183b3ff")
