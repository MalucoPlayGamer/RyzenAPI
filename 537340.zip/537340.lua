-- Lua provided by RyzenAPI
-- Game: Guts and Glory

-- MAIN APPLICATION
addappid(646860) -- Guts and Glory - Wacky Hats Pack
addappid(646920) -- Guts and Glory - Golden Prestige
addappid(646921) -- Guts and Glory - Halls of Glory
addappid(646922) -- Guts and Glory - Founders Club

-- MAIN APP DEPOTS / PACKAGES
addappid(537340, 1, "1b1e75652d752c2eb42202dac0a7d4360bc19afa6ed0a11f7e353a3472aa4a82") -- Guts and Glory
addappid(537341, 1, "9666002b803cda0f99f93e3397766e9c6c0cb883c255707baf99c801e84a0925") -- GutsAndGlory_Win
addappid(537342, 1, "ed469e4612ea75de1c81b19cf544912616276e2ede60b1cfc0cd516fc73725d2") -- GutsAndGlory_Mac
addappid(537343, 1, "4af51fcd9f2fdb0102b86c4d9d96bb6a8d926bdfb5d4980d88585e169183b3ff") -- 537343 "GutsAndGlory_LnxUni"
