-- Lua provided by RyzenAPI
-- Game: Golden Mine Pickaxe 2: Mummy Tombs

-- MAIN APPLICATION
addappid(1941130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941131, 1, "3fc55576444f8d168cd51dadb10411c50708637e98d33d0e6d180f085256d478")

