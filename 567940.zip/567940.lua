-- Lua provided by RyzenAPI
-- Game: Piximalism

-- MAIN APPLICATION
addappid(567940)

-- MAIN APP DEPOTS / PACKAGES
addappid(567941, 1, "110d40a378480461faca9083ee578a0a4a0d10309f239c53f8b3f18487c543ad")
