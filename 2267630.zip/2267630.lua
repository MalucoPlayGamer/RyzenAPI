-- Lua provided by RyzenAPI 
-- Game: Ternion
addappid(2267630)
addappid(2267631, 1, "0b0c8a444b305b6de29d3b8919a0be46d7b31fe1ab6233111eb5e918e90ff9e0")
