-- Lua provided by RyzenAPI
-- Game: Robot-Mail Rush

-- MAIN APPLICATION
addappid(3946430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3946431,0,"5e635a9660ec7373809acfac6731e5c19783638e14e7952e92a001c95642bc8e")

