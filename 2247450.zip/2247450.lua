-- Lua provided by RyzenAPI
-- Game: Seeking Asylum: The Game (DEMO)

-- MAIN APPLICATION
addappid(2247450)
-- Game: addappid(2247450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247451, 1, "ad18ffce7c69ed9c357d74009226b0289794f99eb00fafd277f9a79666d56ba5")
