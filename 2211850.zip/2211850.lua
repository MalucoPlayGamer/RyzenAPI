-- Lua provided by RyzenAPI
-- Game: addappid(2211850)

-- MAIN APPLICATION
addappid(2211850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211851, 1, "478648686c4630bf0e57b21aeccbd56961851fbb43b1e10204f9518cda4e54ba")
