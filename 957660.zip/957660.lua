-- Lua provided by RyzenAPI
-- Game: Game: Catizens

-- MAIN APPLICATION
addappid(957660)
-- Game: addappid(957660)

-- MAIN APP DEPOTS / PACKAGES
addappid(957661, 1, "e829a594a0198fbc8170a10009da0acb0a49946a839cc60a9d79785e2d2915e4")
addappid(957662, 1, "fb9243e69776019b21e5521ab03150eaa5822c20d4831b1176f049d578e201ee")
