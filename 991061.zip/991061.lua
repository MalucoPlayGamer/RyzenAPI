-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Köln/Bonn

-- MAIN APPLICATION
addappid(991061)
-- Game: addappid(991061)

-- MAIN APP DEPOTS / PACKAGES
addappid(991061,0,"d674dcaa19ac9687a2097e93e1de9b187417d5f320530ca752302208f9844429")
