-- Lua provided by SkyAPI 
-- Game: Unruly Ghouls
addappid(523720)
addappid(523721, 1, "6203515aff4e3770db65d5d27a44ef944a8dafc2f15d411aeed108e0dcfdaeda")
