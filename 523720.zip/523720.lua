-- Lua provided by RyzenAPI
-- Game: Unruly Ghouls

-- MAIN APPLICATION
addappid(523720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(523721, 1, "6203515aff4e3770db65d5d27a44ef944a8dafc2f15d411aeed108e0dcfdaeda")

