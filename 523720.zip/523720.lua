-- Lua provided by RyzenAPI
-- Game: Unruly Ghouls

-- MAIN APPLICATION
addappid(523720)

-- MAIN APP DEPOTS / PACKAGES
addappid(523721, 1, "6203515aff4e3770db65d5d27a44ef944a8dafc2f15d411aeed108e0dcfdaeda")
