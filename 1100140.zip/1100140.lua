-- Lua provided by RyzenAPI
-- Game: Game: Touhou Fuujinroku ~ Mountain of Faith.

-- MAIN APPLICATION
addappid(1100140)
-- Game: addappid(1100140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100141, 1, "9715df9e9ce60951847251ec8bc10a3474ad77e93688c954043a4bb0dd6468f6")
