-- Lua provided by RyzenAPI
-- Game: Touhou Fuujinroku ~ Mountain of Faith.

-- MAIN APPLICATION
addappid(1100140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100141, 1, "9715df9e9ce60951847251ec8bc10a3474ad77e93688c954043a4bb0dd6468f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
