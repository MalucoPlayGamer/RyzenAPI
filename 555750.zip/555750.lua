-- Lua provided by RyzenAPI
-- Game: addappid(555750)

-- MAIN APPLICATION
addappid(555750)
addappid(923290)

-- MAIN APP DEPOTS / PACKAGES
addappid(555751, 1, "71c3d983e30141be4c83bf0bf196cec022d5a22e8028d8d2a3f881d024bad957")
addappid(555752, 1, "d369401090e32a4a557e2ce7ffdeab31f7efc5b709a95046590e1b69a674cbce")
