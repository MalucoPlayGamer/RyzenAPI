-- Lua provided by RyzenAPI
-- Game: 七楼幸存者

-- MAIN APPLICATION
addappid(2404420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404421, 1, "af168fbdadfa7405d27f127f11d77e07ae47a6a4a1ccb441d75a26d1d2a4e9fe")
