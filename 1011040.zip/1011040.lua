-- Lua provided by RyzenAPI
-- Game: AppID 1011040

-- MAIN APPLICATION
addappid(1011040)
-- Game: addappid(1011040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011041, 1, "6def49cfe365b89bfe7de8358f258921f0f02d73472bc2e7a95648f01b92ea55")
