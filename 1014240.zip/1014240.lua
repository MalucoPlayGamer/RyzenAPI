-- Lua provided by RyzenAPI
-- Game: Starship Saboteur Prototype

-- MAIN APPLICATION
addappid(1014240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014241, 1, "42ac0209718f3c81654c0dc3a997d7e5b8000754ca844ef84554739fa709c32c")

