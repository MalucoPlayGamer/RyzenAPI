-- Lua provided by SkyAPI 
-- Game: AppID 1192880
addappid(1192880)
addappid(1192881, 1, "76aeec4508048e144546a58b438027c4627776d626cd529c5e821d5c877c4992")
