-- Lua provided by RyzenAPI
-- Game: Pack my Order

-- MAIN APPLICATION
addappid(4388420) -- Pack my Order

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4388421, 1, "5b4e083f967feeb5dc3278db8d2e168f997942922b5966a6011e73bb1f262714") -- Depot 4388421

