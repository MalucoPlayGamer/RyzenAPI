-- Lua provided by RyzenAPI
-- Game: Game: AppID 2125280

-- MAIN APPLICATION
addappid(2125280)
-- Game: addappid(2125280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125281, 1, "6e7236f99c2085b0baa08df3a1df7b33482cff3b5d2fc5d659a300431808b4c3")
