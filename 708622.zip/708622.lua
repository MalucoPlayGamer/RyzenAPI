-- Lua provided by RyzenAPI
-- Game: Realities - Beelitz Heilstätten

-- MAIN APPLICATION
addappid(708622)
-- Game: addappid(708622)

-- MAIN APP DEPOTS / PACKAGES
addappid(737950,0,"d81847a4a86816c8efe6345ae75d5f373f3491151983682873d8dc831bf2c4ae")
