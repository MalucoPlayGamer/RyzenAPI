-- Lua provided by RyzenAPI
-- Game: Corpse Party: Blood Drive

-- MAIN APPLICATION
addappid(824830)

-- MAIN APP DEPOTS / PACKAGES
addappid(824831, 1, "e8b463f219de455b38a379f4bae1d81d1110b34e251f6c394a59d2558f67532e")

