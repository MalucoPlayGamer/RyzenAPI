-- Lua provided by RyzenAPI 
-- Game: Apex Heroines
addappid(2464800)
addappid(2464801, 1, "4c0f217e0b65b3096267000a7fa5bc9727d68dcb5836ed40fb7ec7ffd2930306")
