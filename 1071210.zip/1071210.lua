-- Lua provided by RyzenAPI
-- Game: Hentai DLC for Nyasha Valkyrie

-- MAIN APPLICATION
addappid(1071210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071210,0,"6566b247e99e30145e40565e7326437e9b7decc8be5fc25c7478f41166753e49")

