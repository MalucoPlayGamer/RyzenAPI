-- Lua provided by RyzenAPI
-- Game: 1971400

-- MAIN APPLICATION
addappid(1971400)
-- Game: addappid(1971400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971408,0,"2aa87e1dc62f0e21f1aec7b9ac6d2aad530f36171adf97fa6439136d83fc46b5")
addappid(1971409,0,"86a6d1f30be30b8b0017e44e7b4718eca72cc5786683ea7e923641ef8ee60a61")
