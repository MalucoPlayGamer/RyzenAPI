-- Lua provided by RyzenAPI
-- Game: 사괴야행

-- MAIN APPLICATION
addappid(1971400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971408,0,"2aa87e1dc62f0e21f1aec7b9ac6d2aad530f36171adf97fa6439136d83fc46b5")
addappid(1971409,0,"86a6d1f30be30b8b0017e44e7b4718eca72cc5786683ea7e923641ef8ee60a61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
