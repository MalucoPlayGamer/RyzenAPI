-- Lua provided by RyzenAPI
-- Game: Avalon Crew Demo

-- MAIN APPLICATION
addappid(3179800)
-- Game: addappid(3179800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179801, 1, "8e83d21add97ddd4ff71edd73fed1374988af91ed87d63be4bbcef8fa552922d")
