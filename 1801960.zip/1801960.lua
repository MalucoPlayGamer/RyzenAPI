-- Lua provided by RyzenAPI
-- Game: Nude vRoid for Clip maker

-- MAIN APPLICATION
addappid(1801960)
-- Game: addappid(1801960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801961, 1, "5c33202e3e9e67324077273e5b343e16c5883adde035bdf52d322085b11482cd")
