-- Lua provided by RyzenAPI
-- Game: addappid(1004500)

-- MAIN APPLICATION
addappid(1004500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004502,0,"5a1be72b3a5475300aa34a3df098e37be97ebd32fb3794bba6d5716a908fd6e6")
