-- Lua provided by RyzenAPI
-- Game: Game: Flux Caves

-- MAIN APPLICATION
addappid(1086750)
-- Game: addappid(1086750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086751, 1, "656cd0488e7179a8c8ae87de9d18095e27c3d718b8d7d552d599e7ac0cadc81b")
addappid(1086752, 1, "9d85b3e551116cbbef8ba62ac992820b25f9ec975080e1c534bf145eb42b5265")
addappid(1086753, 1, "c978fda8263557f3a10c01b4168d2bf740f23b3463697b8371a63079ccfa5182")
