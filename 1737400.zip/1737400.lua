-- Lua provided by RyzenAPI
-- Game: Kick Bastards

-- MAIN APPLICATION
addappid(1737400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1737401, 1, "0b79a43199b663c83b0730cafd677eee4c381b782b6f71e48377e6e5144ce393")

