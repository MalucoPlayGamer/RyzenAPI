-- Lua provided by RyzenAPI
-- Game: Kick Bastards

-- MAIN APPLICATION
addappid(1737400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737401, 1, "0b79a43199b663c83b0730cafd677eee4c381b782b6f71e48377e6e5144ce393")

