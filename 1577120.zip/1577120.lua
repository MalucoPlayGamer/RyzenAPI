-- Lua provided by RyzenAPI
-- Game: The Quarry

-- MAIN APPLICATION
addappid(1577120)
-- Game: addappid(1577120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523211,0,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
addappid(1577122,0,"d1f173e0a675ae53ba562864c36961f17e2f532af0acd7764099896fe7852d6d")
