-- Lua provided by RyzenAPI
-- Game: The Quarry

-- MAIN APPLICATION
addappid(1577120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523211,0,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
addappid(1577122,0,"d1f173e0a675ae53ba562864c36961f17e2f532af0acd7764099896fe7852d6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1877110)
addappid(1877111)
addappid(1891950)
addappid(2101870)
