-- Lua provided by RyzenAPI
-- Game: addappid(1931950)

-- MAIN APPLICATION
addappid(1931950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931951, 1, "2ffb86dd9875a0a79beebb596868d696505e63a39272556c5f3f03f4ae2831d3")
