-- Lua provided by RyzenAPI
-- Game: Game: Arcane Eternity

-- MAIN APPLICATION
addappid(3689680)
-- Game: addappid(3689680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689681, 1, "ba1ad0acd118344126c47e1880d6cd9332398989a1b9937e6f67ffd6ad90adf8")
