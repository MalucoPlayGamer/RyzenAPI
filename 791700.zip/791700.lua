-- Lua provided by RyzenAPI
-- Game: Bird Game

-- MAIN APPLICATION
addappid(791700)
-- Game: addappid(791700)

-- MAIN APP DEPOTS / PACKAGES
addappid(791701, 1, "32ee2e0062ec47f90ac59aac2e6588d28a7cbfc675a708fbf1ca54ff10a596e3")
addappid(791702, 1, "8861c5345f9f0d399afbb1692ab32b93ecac73d568831f9b917b9a42ecfec949")
addappid(791703, 1, "8cdb8bd934a2e32a1cc036230362b215d17472ffa3b02c6333741249c73a276d")
addappid(826360, 0, "5a024a3036964bd2927ba59e7b0d510ab6f5a3264163a6c89e4cbc1f49a44c67")
