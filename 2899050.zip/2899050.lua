-- Lua provided by RyzenAPI
-- Game: Desert Stalker

-- MAIN APPLICATION
addappid(2899050)
-- Game: addappid(2899050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899051, 1, "a6cff3e9d965f5096403263df0125bd18d78589c82e7642e33f2f3ab3c2be3e1")
