-- Lua provided by RyzenAPI
-- Game: DARK

-- MAIN APPLICATION
addappid(225360)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229002)
addappid(249170)

-- MAIN APP DEPOTS / PACKAGES
addappid(225361, 1, "cce21d8bd1e35241b4aaa7d8945f60975613bfbb3287f80895ebce42fa99d455")
addappid(225362, 1, "9f4c038f1e091249ad575dfd8c2114adaa6d72cb47719537c609472a7ed1020c")
addappid(225363, 1, "fb43e2600e155782556fee7393e5e28faba941b8b238cb1e542db42e0280203a")
addappid(225364, 1, "cabf07c58066302c1df915976d523a6ef5b7f72850751b2f06b91ffd9cc8fa15")
addappid(225365, 1, "ef7695c7271a2f88d327183897d02a8e5d8a21f66e8746ae58cfab0a34ce5f2d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(225370)
