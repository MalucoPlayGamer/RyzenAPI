-- Lua provided by RyzenAPI
-- Game: 746560

-- MAIN APPLICATION
addappid(746560)
-- Game: addappid(746560)

-- MAIN APP DEPOTS / PACKAGES
addappid(746561, 1, "ad323cab6c8d5a076b188beb4817cffbe9f6a1026609f885d60056d55e20d648")
