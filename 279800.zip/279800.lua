-- Lua provided by RyzenAPI
-- Game: Grim Legends 2: Song of the Dark Swan

-- MAIN APPLICATION
addappid(279800)
-- Game: addappid(279800)

-- MAIN APP DEPOTS / PACKAGES
addappid(279801, 1, "89d59a328d03570330cd4536cbe19d90219a8960011fb7772e90bb8927c71710")
addappid(279802, 1, "0ab65ebcc4612ed65d19d440d5a8374b8e37b2c7f612321c2197703e73d71bf8")
addappid(279803, 1, "6da40c67edfccb027caa29e5abcc241de07f0530793f5e9d3ea473adc0290a90")
