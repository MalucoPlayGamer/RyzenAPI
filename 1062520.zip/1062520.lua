-- Lua provided by RyzenAPI 
-- Game: Dinkum
addappid(1062520)
addappid(1062521, 1, "ef0a62caf543b86609cfc0a77c6879d1f131a1fdb5cfdda01204f0171b126a56")
