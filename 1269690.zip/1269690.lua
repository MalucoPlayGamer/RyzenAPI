-- Lua provided by RyzenAPI 
-- Game: AppID 1269690
addappid(1269690)
addappid(1269691, 1, "696234cf82c6a339615e1f4a1642e0fd261a86eeb90d6420e89a0cbcd04c0676")
