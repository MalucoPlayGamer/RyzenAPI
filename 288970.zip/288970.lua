-- Lua provided by RyzenAPI
-- Game: AppID 288970

-- MAIN APPLICATION
addappid(288970)
-- Game: addappid(288970)

-- MAIN APP DEPOTS / PACKAGES
addappid(288971, 1, "763ee2b87c713d7c4ade51cdf7134d852026057adbb158af16f37800e07c83f1")
