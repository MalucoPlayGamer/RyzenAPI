-- Lua provided by RyzenAPI
-- Game: AppID 466420

-- MAIN APPLICATION
addappid(466420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(466421, 1, "6cb332a975a3716c3ed43465a3038d0b8ec9472e73795f7fc138f9d41823988b")
addappid(488700, 0, "48ac15ecf131db90a3fd5be46e8a04bb2258c5c8a7a6a9715f73f0535278d1e2")

