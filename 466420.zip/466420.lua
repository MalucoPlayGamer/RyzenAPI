-- Lua provided by RyzenAPI
-- Game: Game: AppID 466420

-- MAIN APPLICATION
addappid(466420)
-- Game: addappid(466420)

-- MAIN APP DEPOTS / PACKAGES
addappid(466421, 1, "6cb332a975a3716c3ed43465a3038d0b8ec9472e73795f7fc138f9d41823988b")
addappid(488700, 0, "48ac15ecf131db90a3fd5be46e8a04bb2258c5c8a7a6a9715f73f0535278d1e2")
