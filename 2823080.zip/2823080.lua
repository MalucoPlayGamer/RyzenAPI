-- Lua provided by SkyAPI 
-- Game: AppID 2823080
addappid(2823080)
addappid(2823081, 1, "480fdb2c63d5aacc170025a90063437791a1cf181afafc2bc6ff5c13f7792983")
