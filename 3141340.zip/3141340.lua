-- Lua provided by RyzenAPI
-- Game: addappid(3141340)

-- MAIN APPLICATION
addappid(3141340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141341, 1, "bdd7b8dce630d00416333ce1dffe1717268b7cbf592fe3b7a08b9f98244e94cc")
