-- Lua provided by RyzenAPI 
-- Game: Visions of Mana Demo
addappid(2989250)
addappid(2989251, 1, "6b2b2ccc5405296835862ec9c5920c9e437a6929a9a9f6944122e084c4d60f70")
