-- Lua provided by RyzenAPI
-- Game: Dreamcutter

-- MAIN APPLICATION
addappid(2163030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163031, 1, "a55c7721aafdc42ecea82e9d23f6f085281c8346eea4331632ed52d17de207c9")

