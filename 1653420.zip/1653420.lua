-- Lua provided by RyzenAPI
-- Game: Train Travel Simulator

-- MAIN APPLICATION
addappid(1653420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653421, 1, "6db856fb88c20f06905b04b957f4000a88311e6993984968b4613236c51ed8d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
