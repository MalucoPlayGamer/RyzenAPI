-- Lua provided by RyzenAPI
-- Game: Train Travel Simulator

-- MAIN APPLICATION
addappid(1653420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653421, 1, "6db856fb88c20f06905b04b957f4000a88311e6993984968b4613236c51ed8d7")
