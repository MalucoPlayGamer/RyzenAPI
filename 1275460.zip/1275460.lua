-- Lua provided by RyzenAPI
-- Game: ENDLESS™ Legend - Original Soundtrack

-- MAIN APPLICATION
addappid(1275460)
-- Game: addappid(1275460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275461, 1, "9c0840221ea63c1657637b5731a17cba5f5f59e61c0a97e29c6c9311920bf0bd")
addappid(1275462, 1, "197c40e85460b26ea7df0262a8611a1423489536c7023c115630952ce047b4bb")
