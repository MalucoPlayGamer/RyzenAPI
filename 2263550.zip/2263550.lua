-- Lua provided by RyzenAPI
-- Game: 2263550

-- MAIN APPLICATION
addappid(2263550)
-- Game: addappid(2263550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263551, 1, "b848ef1a120b874874764fe59157d13e36639a7e6ec12a4295d0b8a05cdb864b")
