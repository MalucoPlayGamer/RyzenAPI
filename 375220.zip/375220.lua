-- Lua provided by SkyAPI 
-- Game: Bitweb
addappid(375220)
addappid(375221, 1, "f30bd0cf246b86ed3fa5ff2701628931965223c71af70abf81f4412c6d0d5dc6")
addappid(375222, 1, "a9e0376b82538ddd76f8a8b4a7596adf9d9ea735e14905516fc5e490588120fc")
