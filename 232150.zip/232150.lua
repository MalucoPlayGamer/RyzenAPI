-- Lua provided by RyzenAPI
-- Game: AppID 232150

-- MAIN APPLICATION
addappid(232150)

-- MAIN APP DEPOTS / PACKAGES
addappid(232151, 1, "0559680684c1de5578cf2c6a7e9799cb35eaf774a54256ebe8ba4d44adeca8fa")
addappid(232152, 1, "9dead4cf4e8625e8edc7881e02e93e5ffacf1ca7021d149c5bb96ee59fa090f0")

