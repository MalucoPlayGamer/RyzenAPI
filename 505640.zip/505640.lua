-- Lua provided by RyzenAPI
-- Game: 505640

-- MAIN APPLICATION
addappid(505640)
addappid(505644)
addappid(652490)
addappid(652491)
addappid(731460)
-- Game: addappid(505640)

-- MAIN APP DEPOTS / PACKAGES
addappid(505643,0,"1483b8d0ce1023d16a4bc2020180e20d8ec9a06c2e0eac32dc65235fca35f92f")
