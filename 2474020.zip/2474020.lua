-- Lua provided by RyzenAPI
-- Game: The Amazing Crackpots Club!

-- MAIN APPLICATION
addappid(2474020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474021, 1, "e90699687107845ab1312b686aa87f0f626743b16650514766d26e6b9c1c28a4")

