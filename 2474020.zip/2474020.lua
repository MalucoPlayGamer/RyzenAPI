-- Lua provided by RyzenAPI
-- Game: The Amazing Crackpots Club!

-- MAIN APPLICATION
addappid(2474020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2474021, 1, "e90699687107845ab1312b686aa87f0f626743b16650514766d26e6b9c1c28a4")

