-- Lua provided by RyzenAPI
-- Game: AppID 814960

-- MAIN APPLICATION
addappid(814960)
-- Game: addappid(814960)

-- MAIN APP DEPOTS / PACKAGES
addappid(814961, 1, "44a2378e8ba2688bb338a3771f81f2232b03fc29507f968bc30debe3e5e73d90")
