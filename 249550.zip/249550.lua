-- Lua provided by RyzenAPI
-- Game: NEStalgia

-- MAIN APPLICATION
addappid(249550)
-- Game: addappid(249550)

-- MAIN APP DEPOTS / PACKAGES
addappid(249551, 1, "9d9a155f7d176621a44ea33acf303a054421fcb32de66837ee62fb3218d0a56d")
addappid(537410, 0, "1910ca846fe2975844b74c9e0120be963406aedf3dee4f34fb29274c1bac7f7e")
