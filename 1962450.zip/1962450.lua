-- Lua provided by RyzenAPI
-- Game: Game: RitualSummon

-- MAIN APPLICATION
addappid(1962450)
-- Game: addappid(1962450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962451, 1, "dfd2afa82ae15fef9cb7d92e7687777a6592ec7187f538c769fbc703b1421c26")
