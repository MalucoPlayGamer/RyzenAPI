-- Lua provided by RyzenAPI
-- Game: Blacksmith Run

-- MAIN APPLICATION
addappid(1062670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062671, 1, "6399903e2a32ed9f8e66f904319897958ce320a418a5206f6a71bc5158acbf52")
