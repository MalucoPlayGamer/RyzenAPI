-- Lua provided by RyzenAPI
-- Game: LogiGun

-- MAIN APPLICATION
addappid(308360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(308361, 1, "3206e5449db890752429baad6ea1f04c3d69b5d1770873830ba7d4a7961ef9f9")

