-- Lua provided by RyzenAPI
-- Game: addappid(308360)

-- MAIN APPLICATION
addappid(308360)

-- MAIN APP DEPOTS / PACKAGES
addappid(308361, 1, "3206e5449db890752429baad6ea1f04c3d69b5d1770873830ba7d4a7961ef9f9")
