-- Lua provided by RyzenAPI
-- Game: Do As I Say - Obedience to the Priest

-- MAIN APPLICATION
addappid(4735980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558880, 1, "7441be559e63edd329e84db93829f6561591d9c64cd5d220b25238f9f64f3f4b") -- Do As I Say - Obedience to the Priest
addappid(3558881, 1, "c7a211f6824f057919a9ac5d42e3a5a17a2048557acce72d22962392601b7819") -- Depot 3558881
addappid(4735980, 1, "ae6147a6a7d131fd75ba63baca1a316fe3552b853a294e61e406706735c8e129") -- Do As I Say - Obedience to the Priest  Uncensor DLC - Depot 4735980

