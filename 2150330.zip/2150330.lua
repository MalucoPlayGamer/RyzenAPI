-- Lua provided by RyzenAPI
-- Game: Game: Rush Rally 3 Demo

-- MAIN APPLICATION
addappid(2150330)
-- Game: addappid(2150330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150331, 1, "6b3f3289d50974c378b50b85762790f478fe9443d92ca9023683a3149f26181b")
