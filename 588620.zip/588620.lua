-- Lua provided by SkyAPI 
-- Game: Mary Le Chef - Cooking Passion
addappid(588620)
addappid(588621, 1, "b3934d7c48fa9fa04143d4c16272dccb720afce08ccd72f57d0e9943da7d4fec")
