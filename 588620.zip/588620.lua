-- Lua provided by RyzenAPI
-- Game: Mary Le Chef - Cooking Passion

-- MAIN APPLICATION
addappid(588620)

-- MAIN APP DEPOTS / PACKAGES
addappid(588621, 1, "b3934d7c48fa9fa04143d4c16272dccb720afce08ccd72f57d0e9943da7d4fec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
