-- Lua provided by RyzenAPI
-- Game: addappid(588620)

-- MAIN APPLICATION
addappid(588620)

-- MAIN APP DEPOTS / PACKAGES
addappid(588621, 1, "b3934d7c48fa9fa04143d4c16272dccb720afce08ccd72f57d0e9943da7d4fec")
