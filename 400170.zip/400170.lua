-- Lua provided by RyzenAPI
-- Game: 400170

-- MAIN APPLICATION
addappid(400170)
-- Game: addappid(400170)

-- MAIN APP DEPOTS / PACKAGES
addappid(400171, 1, "7fa235914cc79a542ba4868c323775cfc2332b9b5d827f1652ab3c14dfae8177")
addappid(400172, 1, "e7ceee0bebc61e9961ed0685cd5354780db0a9a3f3d93fa2f7efdfc20ea42c13")
addappid(400173, 1, "45ee01de134f5ceca7dc7a44cb3b6d9300182bbe83ce4abeb5a913fc7c39fd56")
