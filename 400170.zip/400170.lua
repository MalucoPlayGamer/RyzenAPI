-- Lua provided by RyzenAPI
-- Game: AppID 400170

-- MAIN APPLICATION
addappid(400170)
addappid(416400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(400171, 1, "7fa235914cc79a542ba4868c323775cfc2332b9b5d827f1652ab3c14dfae8177")
addappid(400172, 1, "e7ceee0bebc61e9961ed0685cd5354780db0a9a3f3d93fa2f7efdfc20ea42c13")
addappid(400173, 1, "45ee01de134f5ceca7dc7a44cb3b6d9300182bbe83ce4abeb5a913fc7c39fd56")

