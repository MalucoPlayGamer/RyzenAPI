-- Lua provided by RyzenAPI
-- Game: addappid(1860600)

-- MAIN APPLICATION
addappid(1860600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860601, 1, "835cfcc59445205fc9dc28a931a6025613f09801be67eef744ad4c53cc92ab68")
