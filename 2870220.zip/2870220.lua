-- Lua provided by RyzenAPI
-- Game: Tuggowar

-- MAIN APPLICATION
addappid(2870220)
-- Game: addappid(2870220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870221, 1, "fcad9bd6dbcff26e0da497c4920b0d973f4893191acc64c8eaf6464b7d03776f")
