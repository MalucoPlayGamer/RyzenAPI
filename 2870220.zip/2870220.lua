-- Lua provided by SkyAPI 
-- Game: Tuggowar
addappid(2870220)
addappid(2870221, 1, "fcad9bd6dbcff26e0da497c4920b0d973f4893191acc64c8eaf6464b7d03776f")
