-- Lua provided by RyzenAPI
-- Game: Tuggowar

-- MAIN APPLICATION
addappid(2870220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870221, 1, "fcad9bd6dbcff26e0da497c4920b0d973f4893191acc64c8eaf6464b7d03776f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3594340)
addappid(3594350)
addappid(3594360)
addappid(3594370)
addappid(3682470)
addappid(3765270)
addappid(3832990)
addappid(3880380)
addappid(4054340)
addappid(4526650)
