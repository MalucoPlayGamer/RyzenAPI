-- Lua provided by RyzenAPI
-- Game: addappid(1373270)

-- MAIN APPLICATION
addappid(1373270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373271, 1, "1ced4c3a23559a59e4b14ef8307496004e46f0024b33ad8bfc7acbe9016c64bc")
