-- Lua provided by RyzenAPI
-- Game: Orbital Challenge

-- MAIN APPLICATION
addappid(1756600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756602,0,"85d4c2c58c92f91f5b815ebe4c63990deba829169060e58a10e75173ff1bf9dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
