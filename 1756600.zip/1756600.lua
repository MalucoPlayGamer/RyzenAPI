-- Lua provided by RyzenAPI
-- Game: Orbital Challenge

-- MAIN APPLICATION
addappid(1756600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756602,0,"85d4c2c58c92f91f5b815ebe4c63990deba829169060e58a10e75173ff1bf9dc")
