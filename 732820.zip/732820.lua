-- Lua provided by RyzenAPI
-- Game: Green Blood

-- MAIN APPLICATION
addappid(732820)

-- MAIN APP DEPOTS / PACKAGES
addappid(732821, 1, "c2a6b8885d08bc3ef76b57529032680eb077b6bc58e6abeedd74b4b4e3921e18")

