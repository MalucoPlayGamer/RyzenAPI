-- Lua provided by RyzenAPI
-- Game: Hidden Protector : ROADTRIP (Preface)

-- MAIN APPLICATION
addappid(838190)
-- Game: addappid(838190)

-- MAIN APP DEPOTS / PACKAGES
addappid(838191, 1, "33971374b50a167a20f3bd92a126b8752fe6c5ad8b623597af26bff3778ddd44")
