-- Lua provided by RyzenAPI
-- Game: addappid(2113120)

-- MAIN APPLICATION
addappid(2113120)
addappid(2113124)
addappid(2113125)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113123,0,"4d7ce40fed4f579ddbca60d62f1e2513437b203792fb6a1ac3c6f1ff80bed8be")
