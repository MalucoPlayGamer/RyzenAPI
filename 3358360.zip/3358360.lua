-- Lua provided by RyzenAPI 
-- Game: Motorcycle Night Ride
addappid(3358360)
addappid(3358361, 1, "756a5674283d2e083110805af231c08ed53fbb3f9a872d98e7391aacd155ef3f")
