-- Lua provided by RyzenAPI
-- Game: 2224590

-- MAIN APPLICATION
addappid(2224590)
-- Game: addappid(2224590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224591, 1, "9a13ff422d367ae15acc1f77c9121a0aa7308478ce9095ea2de8dd27a232b873")
