-- Lua provided by RyzenAPI
-- Game: 771710

-- MAIN APPLICATION
addappid(771710)
-- Game: addappid(771710)

-- MAIN APP DEPOTS / PACKAGES
addappid(771711, 1, "d6830712fadede64b4f1d9b017e6d3feba0937564cfa66f74da25b905d6cac92")
