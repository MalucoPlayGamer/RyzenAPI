-- Lua provided by RyzenAPI
-- Game: .T.E.S.T: Expected Behaviour — Sci-Fi 3D Puzzle Quest

-- MAIN APPLICATION
addappid(771710)

-- MAIN APP DEPOTS / PACKAGES
addappid(771711, 1, "d6830712fadede64b4f1d9b017e6d3feba0937564cfa66f74da25b905d6cac92")
