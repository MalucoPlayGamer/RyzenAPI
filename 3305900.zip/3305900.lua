-- Lua provided by RyzenAPI 
-- Game: DIRTY HALLOWEEN
addappid(3305900)
addappid(3305901, 1, "790c78de2baa4c902112ba8ee6a126bb16cf637012a90246fa858bf04b73687e")
