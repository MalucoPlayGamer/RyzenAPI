-- Lua provided by RyzenAPI
-- Game: AppID 765060

-- MAIN APPLICATION
addappid(765060)

-- MAIN APP DEPOTS / PACKAGES
addappid(765061, 1, "29ca53e42be1ef0ca2b1450c42250c282b1f3e79d7fefc90fc90cafca8e7c2be")
