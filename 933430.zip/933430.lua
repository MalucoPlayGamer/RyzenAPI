-- Lua provided by RyzenAPI
-- Game: 933430

-- MAIN APPLICATION
addappid(933430)
-- Game: addappid(933430)

-- MAIN APP DEPOTS / PACKAGES
addappid(933431, 1, "fd01344c4d8e6acc07379d256914ad0f7156004769e6f66bbe34787a39c4a053")
