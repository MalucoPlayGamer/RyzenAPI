-- Lua provided by RyzenAPI
-- Game: AppID 601980

-- MAIN APPLICATION
addappid(601980)

-- MAIN APP DEPOTS / PACKAGES
addappid(601981, 1, "172e0b7a3e61f353b1f6c387a3d3e4f4cdf804b649eb04a7f32b7ec0bad6493b")

