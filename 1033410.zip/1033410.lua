-- Lua provided by RyzenAPI
-- Game: AppID 1033410

-- MAIN APPLICATION
addappid(1033410)
-- Game: addappid(1033410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033411, 1, "d7fc3579a2fa6c2858f938b9b487c0aa956c8b5568ceef6c3a508c13b47c49a5")
