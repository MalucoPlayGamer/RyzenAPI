-- Lua provided by RyzenAPI
-- Game: The Incredible Adventures of Van Helsing II

-- MAIN APPLICATION
addappid(272470)
-- Game: addappid(272470)

-- MAIN APP DEPOTS / PACKAGES
addappid(272471, 1, "02fce8f9d8656c40e5d515dbf9043a3e6758b03f99af415a839557bbce85f221")
addappid(272472, 1, "e97bcd235596c453c518ffd7602b3999e26657b6699c9785031f0df2f2f49b52")
addappid(307750, 0, "c1970075d818ccb5d328f49215cb407ba901c6334eaa2fa8e3fb0321812ba054")
