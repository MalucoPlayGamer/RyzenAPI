-- Lua provided by RyzenAPI
-- Game: 2313630

-- MAIN APPLICATION
addappid(2313630)
-- Game: addappid(2313630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313631, 1, "37c49b3778c97fecd6756617e17cddf973861009c8af3cdca9932af0c7fe8c8a")
