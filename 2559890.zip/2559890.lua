-- Lua provided by RyzenAPI
-- Game: LumineNight Demo

-- MAIN APPLICATION
addappid(2559890)
-- Game: addappid(2559890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559891, 1, "70b0ab44553b4f82719463d9dd95ca06a56bd93f1e225835bbb98321a2064120")
