-- Lua provided by RyzenAPI
-- Game: addappid(3246270)

-- MAIN APPLICATION
addappid(3246270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246271, 1, "73a689afce7a783ca117431158ef600c791e7bf39bedc3de816a20f1ef1cfd86")
