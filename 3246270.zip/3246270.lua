-- Lua provided by RyzenAPI 
-- Game: Exo Wanderers Demo
addappid(3246270)
addappid(3246271, 1, "73a689afce7a783ca117431158ef600c791e7bf39bedc3de816a20f1ef1cfd86")
