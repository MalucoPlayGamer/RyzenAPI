-- Lua provided by RyzenAPI
-- Game: inVokeR

-- MAIN APPLICATION
addappid(627070)

-- MAIN APP DEPOTS / PACKAGES
addappid(627071,0,"4e2acc7dcdb8cbeed3dff7869ad9890e4f14e0134ef497fd40dda771420f3d8a")

