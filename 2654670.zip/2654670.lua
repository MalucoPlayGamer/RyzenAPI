-- Lua provided by RyzenAPI
-- Game: 2654670

-- MAIN APPLICATION
addappid(2654670)
-- Game: addappid(2654670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654671, 1, "3046ecbe08b9db280cd52ac584a4e72b27f93c61ae8c5289b1c675eae4b90e34")
