-- Lua provided by RyzenAPI
-- Game: AppID 2654670

-- MAIN APPLICATION
addappid(2654670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654671, 1, "3046ecbe08b9db280cd52ac584a4e72b27f93c61ae8c5289b1c675eae4b90e34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
