-- Lua provided by RyzenAPI
-- Game: FARAWAY TRAIN

-- MAIN APPLICATION
addappid(1601410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601411, 1, "a2e12983d56d61b564114c9be621e0b117c653f658d3c9cba05e7914d149f5e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
