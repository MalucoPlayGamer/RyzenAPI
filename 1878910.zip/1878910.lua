-- Lua provided by RyzenAPI
-- Game: WooLoop

-- MAIN APPLICATION
addappid(1878910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878911, 1, "d9239fa8596e8a09380bfb2bf2aa5523f6703ed66b714d1b3c1a6fb6e5c1ece3")
addappid(1878912, 1, "6bb6e975be123b976882157120647089350fdaf95bfd0d0f1ef1531119938ac7")
addappid(1878913, 1, "1f85319021a1ca50c846038527e7b1e17076f6910b2be779fe33d04c9f576849")
addappid(1878914, 1, "3ccc04d6ab01ea205b114b299c845a64047d67eb7188b87163bca04da057a7e3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2213370)
addappid(2213371)
addappid(2213372)
addappid(2213373)
addappid(2213374)
addappid(2213375)
addappid(2213376)
addappid(2213377)
addappid(2213378)
addappid(2213379)
addappid(2213380)
addappid(2213381)
addappid(2771810)
addappid(2867820)
addappid(2938450)
addappid(3058850)
addappid(3073080)
addappid(3126800)
addappid(3517500)
addappid(3517520)
addappid(3617970)
addappid(3743520)
addappid(3884030)
addappid(4075910)
addappid(4311690)
addappid(4391940)
addappid(4396160)
addappid(4563890)
addappid(4847790)
addappid(4945400)
