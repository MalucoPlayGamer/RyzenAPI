-- Lua provided by RyzenAPI
-- Game: addappid(3019800)

-- MAIN APPLICATION
addappid(3019800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019801, 1, "71dba35bd9263435a13da1f0dc9335b6531542ca91e1293ea34b3eb5ec641145")
