-- Lua provided by RyzenAPI
-- Game: Darksword: Battle Eternity

-- MAIN APPLICATION
addappid(2485000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485001, 1, "229ff5470248f507f2cf153a122a33bee41ccea90aa7fff73a9e88d73cfea97d")

