-- Lua provided by SkyAPI 
-- Game: Darksword: Battle Eternity
addappid(2485000)
addappid(2485001, 1, "229ff5470248f507f2cf153a122a33bee41ccea90aa7fff73a9e88d73cfea97d")
