-- Lua provided by RyzenAPI
-- Game: Darksword: Battle Eternity

-- MAIN APPLICATION
addappid(2485000)
addappid(2565820)
addappid(2600530)
addappid(2600540)
addappid(2780510)
addappid(2855890)
addappid(2897790)
addappid(3965370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2485001, 1, "229ff5470248f507f2cf153a122a33bee41ccea90aa7fff73a9e88d73cfea97d")

