-- Lua provided by RyzenAPI
-- Game: 无限骰子

-- MAIN APPLICATION
addappid(3317650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317651, 1, "2497de01f4215d3394b160ee67243c190dac46bf5b638d4b65118d3a1fbc1a43")
