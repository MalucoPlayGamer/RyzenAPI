-- Lua provided by RyzenAPI
-- Game: The face of hope: Underground

-- MAIN APPLICATION
addappid(545280)

-- MAIN APP DEPOTS / PACKAGES
addappid(545281, 1, "6a4bbe1a665514e5e98da63b9f0d9ef2377833588291d85f12db701167a5fbf7")
