-- Lua provided by SkyAPI 
-- Game: Neeron: The Blade of Nature
addappid(1747080)
addappid(1747081, 1, "d4fd15d6e77c7feace2422918557a0842d768ee9ae5f1ff3e68e4cb3ecd2a31a")
