-- Lua provided by RyzenAPI
-- Game: Neeron: The Blade of Nature

-- MAIN APPLICATION
addappid(1747080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747081, 1, "d4fd15d6e77c7feace2422918557a0842d768ee9ae5f1ff3e68e4cb3ecd2a31a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
