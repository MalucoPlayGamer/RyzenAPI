-- Lua provided by RyzenAPI
-- Game: Neeron: The Blade of Nature

-- MAIN APPLICATION
addappid(1747080)
-- Game: addappid(1747080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747081, 1, "d4fd15d6e77c7feace2422918557a0842d768ee9ae5f1ff3e68e4cb3ecd2a31a")
