-- Lua provided by RyzenAPI
-- Game: Ruined King: A League of Legends Story™

-- MAIN APPLICATION
addappid(1276790)
-- Game: addappid(1276790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276791, 1, "517dbfbb44494a9af79aa0e5d1ec7bfeec6b33e7ed68e471f2ea92648e35c58f")
