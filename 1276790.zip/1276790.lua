-- Lua provided by RyzenAPI
-- Game: AppID 1276790

-- MAIN APPLICATION
addappid(1276790)
addappid(1815930)
addappid(1815931)
addappid(1815932)
addappid(1815933)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1276791, 1, "517dbfbb44494a9af79aa0e5d1ec7bfeec6b33e7ed68e471f2ea92648e35c58f")

