-- Lua provided by RyzenAPI
-- Game: 1282760

-- MAIN APPLICATION
addappid(1282760)
-- Game: addappid(1282760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282761, 1, "5321960cdea41e3e93e37be21b0ff8446ca360073ac57e667330ceaecb4dd5a4")
