-- Lua provided by RyzenAPI
-- Game: UC KART

-- MAIN APPLICATION
addappid(1527230)
-- Game: addappid(1527230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527231, 1, "53726836dc2374cf6606ebf15a58ce0fd6ecd2ddc444afd0c487badfd96a5926")
