-- Lua provided by RyzenAPI
-- Game: addappid(522690)

-- MAIN APPLICATION
addappid(522690)

-- MAIN APP DEPOTS / PACKAGES
addappid(522691, 1, "ba60dbaba47aeb58b2af7e494e00850393e8b8468c5dcee6435cf3f688ee66ca")
