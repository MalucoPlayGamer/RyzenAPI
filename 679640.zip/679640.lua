-- Lua provided by RyzenAPI
-- Game: C64 & AMIGA Classix Remakes Sixpack

-- MAIN APPLICATION
addappid(679640)

-- MAIN APP DEPOTS / PACKAGES
addappid(679641,0,"2aedf65cf24bae884be51324a24e8a4dcc387412493800dc79c465d9b679a510")

