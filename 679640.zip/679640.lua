-- Lua provided by RyzenAPI
-- Game: C64 & AMIGA Classix Remakes Sixpack

-- MAIN APPLICATION
addappid(679640)

-- MAIN APP DEPOTS / PACKAGES
addappid(679641,0,"2aedf65cf24bae884be51324a24e8a4dcc387412493800dc79c465d9b679a510")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
