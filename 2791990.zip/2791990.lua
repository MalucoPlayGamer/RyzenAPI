-- Lua provided by RyzenAPI
-- Game: Game: Aarik And The Ruined Kingdom Demo

-- MAIN APPLICATION
addappid(2791990)
-- Game: addappid(2791990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791991, 1, "e4a7faa52e175af2fa592ab95bf48e7776cd978ba9e030d47d48458d9ff29b6c")
