-- Lua provided by RyzenAPI
-- Game: Zombie Demolition: Infinite Zombie Shooter

-- MAIN APPLICATION
addappid(3599220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599221, 1, "d23b90969ae98d2f2586aa3f16f98b2e73d08ad114a7f4a341f859f8ea7d75df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
