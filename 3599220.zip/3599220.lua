-- Lua provided by RyzenAPI
-- Game: 3599220

-- MAIN APPLICATION
addappid(3599220)
-- Game: addappid(3599220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599221, 1, "d23b90969ae98d2f2586aa3f16f98b2e73d08ad114a7f4a341f859f8ea7d75df")
