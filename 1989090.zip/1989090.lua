-- Lua provided by RyzenAPI
-- Game: addappid(1989090)

-- MAIN APPLICATION
addappid(1989090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989091, 1, "bbcc8d393aa2d68d0a29cca1b81d09a5fe1c7e3a76d9d87079e39bec9ec790de")
