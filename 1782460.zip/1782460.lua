-- 1782460's Lua and Manifest Created by Hubcap Manifest
-- Hell Clock
-- Created: July 17, 2026 at 07:02:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1782460, 1, "c9cc29b2f929f03d1f9aa5ae84866cd3caafa4b581de971c5599e953eced891d") -- Hell Clock
-- MAIN APP DEPOTS
addappid(1782461, 1, "b87981e090ab2ad89c7a18d14898061157db6a1ed5fb03d5e9f0546d734399ce") -- Depot 1782461
setManifestid(1782461, "3544339017735696879", 1574333825)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3774890) -- Hell Clock Supporter Pack Edition
addappid(3774910) -- Hell Clock Cursed War
addappid(3859500) -- Hell Clock Supporter Pack Upgrade