-- Lua provided by RyzenAPI
-- Game: Hell Clock

-- MAIN APPLICATION
addappid(1782460)
-- Game: addappid(1782460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782461, 1, "b87981e090ab2ad89c7a18d14898061157db6a1ed5fb03d5e9f0546d734399ce")
