-- Lua provided by RyzenAPI
-- Game: My Lovely Wife - Comic

-- MAIN APPLICATION
addappid(1948750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948750,0,"0b674b192063f4efe4b9a635be6602819890de7d6f8fb7d9a998a65c6013b924")

