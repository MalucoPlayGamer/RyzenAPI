-- Lua provided by RyzenAPI
-- Game: Monster Rancher 1 & 2 DX

-- MAIN APPLICATION
addappid(1716120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1716121, 1, "12c8b93a86ce2e538e74018b4d18c9666cf7bc03a9e1bfdf7f1fc8138a0f1bbf")
addappid(1716122, 1, "1c8a5acaf5dfe00fd12333d2dae37ba55f02a2022cf8c8ea7b33de8ca54efea4")

