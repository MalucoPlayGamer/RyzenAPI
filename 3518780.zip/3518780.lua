-- Lua provided by RyzenAPI
-- Game: addappid(3518780)

-- MAIN APPLICATION
addappid(3518780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3518781, 1, "32b0e209849bdbc4408db0eb14c10267aab7f501f321c4f43d8ad4de089a111a")
