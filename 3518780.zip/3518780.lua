-- Lua provided by RyzenAPI
-- Game: (The Lingering) Last Customer

-- MAIN APPLICATION
addappid(3518780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3518781, 1, "32b0e209849bdbc4408db0eb14c10267aab7f501f321c4f43d8ad4de089a111a")

