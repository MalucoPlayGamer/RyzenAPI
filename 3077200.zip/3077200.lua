-- Lua provided by RyzenAPI
-- Game: monoch room

-- MAIN APPLICATION
addappid(3077200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077201, 1, "3d58eb0ce7ceb1d5f1facdb9b6f0729d35b698a7e1cdf68c149314724093a8dc")
addappid(3077202, 1, "e4617a0a4accdbaa45de8a05390c560f6c263b5a65a26d642e9e5d008127279d")
addappid(3077204, 1, "d91c2e0981fed11bb1a5d79151bb15e1e3148da0995c10571d7b3aa3d8389aa1")
