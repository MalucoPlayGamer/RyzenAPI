-- 3825390's Lua and Manifest Created by Hubcap Manifest
-- BLUE REFLECTION Quartet
-- Created: July 30, 2026 at 00:18:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3825390, 1, "13b911032091430a197586863284fe8f53ee9e25a37582239afaedb3b2931d0f") -- BLUE REFLECTION Quartet
-- MAIN APP DEPOTS
addappid(3825391, 1, "63c7a50c91918a8eabcccbc40a90996bd220ae272570423970f75e6044c29bf4") -- Depot 3825391
setManifestid(3825391, "1598436630448407770", 56396935872)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4313510) -- BLUE REFLECTION Quartet Set of 4 Special Photo Frames
addappid(4313520) -- BLUE REFLECTION Quartet Uniform (Partner World Version)
addappid(4353430) -- BLUE REFLECTION Quartet Special Photo Frame - Quartet