-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 13

-- MAIN APPLICATION
addappid(3011660)
-- Game: addappid(3011660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011660,0,"a888b72f1553e06157af6453840763ea12d05ad1955fc055d132875006f20cfc")
