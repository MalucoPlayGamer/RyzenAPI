-- Lua provided by RyzenAPI
-- Game: Galactic Orbital Death Sport

-- MAIN APPLICATION
addappid(738210)
-- Game: addappid(738210)

-- MAIN APP DEPOTS / PACKAGES
addappid(738211, 1, "0e9e4e4feb9dbaaf7a3a6c5c8034de2fa7e4d4a83a14f83eba2f0493d40aa3c5")
