-- Lua provided by RyzenAPI
-- Game: Princess Castle Quest

-- MAIN APPLICATION
addappid(228986)
addappid(229020)
addappid(1103550)
addappid(1103551)
-- Game: addappid(1103550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103552,0,"167fa776ff9163e3e57ca3656173a2170a32392250880980a761f05fea02d3cc")
