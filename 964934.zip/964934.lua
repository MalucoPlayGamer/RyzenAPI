-- Lua provided by RyzenAPI
-- Game: 964934

-- MAIN APPLICATION
addappid(964934)
-- Game: addappid(964934)

-- MAIN APP DEPOTS / PACKAGES
addappid(964934,0,"f6a11222ee748bb85a57f1402882272ee1292f43dfb0686d04ab9dfe2f009e83")
