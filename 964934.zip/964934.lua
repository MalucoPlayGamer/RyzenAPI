-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xiaoqiao (High School Girl Costume) / 小喬 「女子高生風コスチューム」

-- MAIN APPLICATION
addappid(964934)

-- MAIN APP DEPOTS / PACKAGES
addappid(964934,0,"f6a11222ee748bb85a57f1402882272ee1292f43dfb0686d04ab9dfe2f009e83")
