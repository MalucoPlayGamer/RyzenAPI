-- Lua provided by RyzenAPI
-- Game: AppID 1101080

-- MAIN APPLICATION
addappid(1101080)
-- Game: addappid(1101080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101081, 1, "e35555ceee0eab5c62e66e87d5649843321bf602a5768768c5ad7a371e240b94")
