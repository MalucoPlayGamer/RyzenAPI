-- Lua provided by RyzenAPI
-- Game: 399920

-- MAIN APPLICATION
addappid(399920)
-- Game: addappid(399920)

-- MAIN APP DEPOTS / PACKAGES
addappid(399921, 1, "22672abc46abc3c23cf6bf9c2b120eeb919c6cbc22f90580fbea5d7a0556d51b")
