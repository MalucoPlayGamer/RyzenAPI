-- Lua provided by SkyAPI 
-- Game: Blind Fate: Edo no Yami — Dojo
addappid(1832220)
addappid(1832221, 1, "cecf00d9a7918b40654791e73d2e836d355a9c1ad4e47ca96b7a1d325d8ee3bd")
