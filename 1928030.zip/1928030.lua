-- Lua provided by RyzenAPI
-- Game: Rightfully, Beary Arms

-- MAIN APPLICATION
addappid(1928030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928031, 1, "4038f9a249fd16adbac214a013a469492018d8af5b404d434796f5df5b5819e8")
addappid(1928032, 1, "101ee70f600bc660aac618f8e94a75b72073d0974ce84c9b1c7a9eef6c978bb5")
