-- Lua provided by RyzenAPI 
-- Game: Aquarium Land
addappid(2583540)
addappid(2583541, 1, "8d12d7f55a95a0a3ce5b3604ed5c474ed9c3cdbd0823e08cf0643383935fac4a")
addappid(2597980)
addappid(2597990)
addappid(2598000)
addappid(2598010)
