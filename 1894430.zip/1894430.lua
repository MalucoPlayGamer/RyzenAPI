-- Lua provided by RyzenAPI
-- Game: Plan B: Terraform

-- MAIN APPLICATION
addappid(1894430)
addappid(5011460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1894431, 1, "9439661726bb617284dcc689e41986b97eb13d5b461523e300cc1a4a36ed3967")

