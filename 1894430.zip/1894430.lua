-- Lua provided by RyzenAPI
-- Game: Game: Plan B: Terraform

-- MAIN APPLICATION
addappid(1894430)
-- Game: addappid(1894430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894431, 1, "9439661726bb617284dcc689e41986b97eb13d5b461523e300cc1a4a36ed3967")
