-- Lua provided by RyzenAPI
-- Game: Researcher

-- MAIN APPLICATION
addappid(1541130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541131, 1, "7a9d6d6b1a2e959858b9dcd4d55ca141ee9359e36831ee194291782fe9ef9ef7")

