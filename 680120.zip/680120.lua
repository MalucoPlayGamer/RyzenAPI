-- Lua provided by SkyAPI 
-- Game: AppID 680120
addappid(680120)
addappid(680121, 1, "73e582c98236bb1dfdb9947a1521a42a90a7d268f2d75cd032cf18b0b717067a")
