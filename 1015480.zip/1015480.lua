-- Lua provided by SkyAPI 
-- Game: DrumBeats VR
addappid(1015480)
addappid(1015481, 1, "566988006481841fd4ce7c859799feed86cd66a0ca2a5fec01355a6e6d0ae3a5")
