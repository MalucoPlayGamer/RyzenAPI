-- Lua provided by RyzenAPI
-- Game: DrumBeats VR

-- MAIN APPLICATION
addappid(1015480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015481, 1, "566988006481841fd4ce7c859799feed86cd66a0ca2a5fec01355a6e6d0ae3a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
