-- Lua provided by RyzenAPI 
-- Game: AppID 1534900
addappid(1534900)
addappid(1534901, 1, "a59220503e15de6ce651a5f8c45d59d3479f0f9e500e71584cf0b977c3531b20")
