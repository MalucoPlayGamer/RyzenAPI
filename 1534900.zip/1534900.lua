-- Lua provided by RyzenAPI
-- Game: VR Guardians

-- MAIN APPLICATION
addappid(1534900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1534901, 1, "a59220503e15de6ce651a5f8c45d59d3479f0f9e500e71584cf0b977c3531b20")

