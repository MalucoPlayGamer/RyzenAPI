-- Lua provided by RyzenAPI
-- Game: MangaKa Demo

-- MAIN APPLICATION
addappid(2246260)
-- Game: addappid(2246260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246261, 1, "5e36edbb89d7f333062e5df15c85193d42ab802b36ca62a979a3cd79a06d3055")
