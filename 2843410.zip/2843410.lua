-- Lua provided by RyzenAPI
-- Game: Everloop

-- MAIN APPLICATION
addappid(2843410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843411, 1, "69dc1e365bd1e2ad931fc0a8a7a50596dd53cd4170a64d2d6a52fe42066e0e17")

