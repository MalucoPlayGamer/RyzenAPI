-- Lua provided by RyzenAPI
-- Game: AppID 330680

-- MAIN APPLICATION
addappid(330680)

-- MAIN APP DEPOTS / PACKAGES
addappid(330681, 1, "d34390d8bf77761cb4bd99bc8e4699d088d73a87cf909f09eada44a6005616f8")
addappid(330682, 1, "b755f4b6083c6ae3ecb249ce7355d3bb7b919136cba10c17addf1327f9ffef80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
