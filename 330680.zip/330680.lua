-- Lua provided by RyzenAPI
-- Game: Game: AppID 330680

-- MAIN APPLICATION
addappid(330680)
-- Game: addappid(330680)

-- MAIN APP DEPOTS / PACKAGES
addappid(330681, 1, "d34390d8bf77761cb4bd99bc8e4699d088d73a87cf909f09eada44a6005616f8")
addappid(330682, 1, "b755f4b6083c6ae3ecb249ce7355d3bb7b919136cba10c17addf1327f9ffef80")
