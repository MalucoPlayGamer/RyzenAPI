-- Lua provided by RyzenAPI
-- Game: Manacle | 猪仔

-- MAIN APPLICATION
addappid(2302680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302681, 1, "6061b52d03ce22e59c81b9a369cea537dac833ce830c1e3e598c53c19c2e3625")
