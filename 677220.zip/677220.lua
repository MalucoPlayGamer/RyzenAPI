-- Lua provided by RyzenAPI
-- Game: Silver Tale

-- MAIN APPLICATION
addappid(677220)

-- MAIN APP DEPOTS / PACKAGES
addappid(677221, 1, "ca866433367e171de2ad53d865eee75bd64cfc984bbce9ae3b8df94873692a4e")

