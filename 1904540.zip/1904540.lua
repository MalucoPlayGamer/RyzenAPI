-- Lua provided by RyzenAPI
-- Game: Football Manager 2023

-- MAIN APPLICATION
addappid(1904540)
addappid(2017220)
-- Game: addappid(1904540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904541, 1, "a5f8548ca4d2cb3f5fc3cf50004162f25fb986cb980345f50a2333479acef907")
addappid(1904542, 1, "3debd2a7254793b20b03984241f6f2cd3c9b184eb1b0f22070ab11c85e8d9c1a")
addappid(1904543, 1, "e28bf4a4d43b79c25073f58d9441476b191e66c3859f54fc068b9509df4d1b45")
