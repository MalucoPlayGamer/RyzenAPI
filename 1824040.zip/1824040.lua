-- Lua provided by RyzenAPI
-- Game: 1824040

-- MAIN APPLICATION
addappid(1824040)
-- Game: addappid(1824040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824041, 1, "b9665a815fea7c293ba54b7ad17f2afb5c4aa731cf916cb496fbb78c2bf2b75e")
addappid(1824042, 1, "a9a7c9a3a13dd32352844ccd459627ffea4a0805095cc8de9a934c5eaf5c0b24")
addappid(1824043, 1, "5a7f4e61221549b24623bd45871d8d608314eae92fe12a288a4e9819ffdbbb47")
