-- Lua provided by RyzenAPI
-- Game: BLADE ARCUS from Shining: Battle Arena Demo

-- MAIN APPLICATION
addappid(529850)

-- MAIN APP DEPOTS / PACKAGES
addappid(529851, 1, "1ee4a950caf38c150bbc4500c8b9c6f57f82b99c7e6b719cca1e4b8a58c87ff1")
