-- Lua provided by RyzenAPI
-- Game: Yummy Girl

-- MAIN APPLICATION
addappid(1615060)
addappid(1626250)
-- Game: addappid(1615060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615061, 1, "218078484d31aa5231aed961c300013ca1d7b087b7048606263a78c170811ecc")
