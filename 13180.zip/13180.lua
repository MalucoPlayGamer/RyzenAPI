-- Lua provided by SkyAPI 
-- Game: AppID 13180
addappid(13180)
addappid(13181, 1, "709242996ea926c0111687154dd7f37e1396dec56024e4ddf2b0128766ea9e16")
