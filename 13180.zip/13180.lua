-- Lua provided by RyzenAPI
-- Game: 13180

-- MAIN APPLICATION
addappid(13180)
-- Game: addappid(13180)

-- MAIN APP DEPOTS / PACKAGES
addappid(13181, 1, "709242996ea926c0111687154dd7f37e1396dec56024e4ddf2b0128766ea9e16")
