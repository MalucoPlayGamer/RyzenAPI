-- Lua provided by RyzenAPI
-- Game: KILLBUG

-- MAIN APPLICATION
addappid(2211730)
-- Game: addappid(2211730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211732,0,"e20effe671205b80e9329cc79dedf69f29c23dd2d670a70ebc15c09705966e48")
