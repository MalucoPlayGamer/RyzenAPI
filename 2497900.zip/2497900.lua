-- Lua provided by RyzenAPI
-- Game: Game: DON'T SCREAM

-- MAIN APPLICATION
addappid(2497900)
-- Game: addappid(2497900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497901, 1, "42d0e96d7b5440cf0b812b5ec843e2e437e28ba281e46830a2d2d7ec65c2a030")
