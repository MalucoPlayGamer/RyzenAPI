-- Lua provided by RyzenAPI 
-- Game: Fabula Mortis
addappid(320790)
addappid(320791, 1, "0493ca67bd032e71340d71e697393833b4634244a875fcfd8ba8f35f6033adb4")
