-- Lua provided by RyzenAPI
-- Game: Fabula Mortis

-- MAIN APPLICATION
addappid(320790)

-- MAIN APP DEPOTS / PACKAGES
addappid(320791, 1, "0493ca67bd032e71340d71e697393833b4634244a875fcfd8ba8f35f6033adb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
