-- Lua provided by RyzenAPI
-- Game: addappid(1677140)

-- MAIN APPLICATION
addappid(1677140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677141, 1, "bc446aa0e42689cf37ae5609964a181efea918f57b3cc666328aac772a487f33")
