-- Lua provided by RyzenAPI
-- Game: GameDevDan vs Life

-- MAIN APPLICATION
addappid(675750)

-- MAIN APP DEPOTS / PACKAGES
addappid(675751,0,"d6b6cc92ca3d72aeca82343b2ad5ddfccd3cf223ccba99fa0ba84cad0bec0fc0")

