-- Lua provided by RyzenAPI
-- Game: Shadow Empire

-- MAIN APPLICATION
addappid(1154840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154841, 1, "b03bab1926c955366c8cacf5364823b16b260df72526484b2b9ae2925e83d7e8")
addappid(1154842, 1, "f0602119edb1dd5ce9126d4319d32fa52daaae4363fdca533cc9f315f8d706b1")
