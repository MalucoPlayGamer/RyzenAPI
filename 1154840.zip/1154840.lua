-- Lua provided by RyzenAPI
-- Game: Shadow Empire

-- MAIN APPLICATION
addappid(1154840)
addappid(2183640)
addappid(3645760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1154841, 1, "b03bab1926c955366c8cacf5364823b16b260df72526484b2b9ae2925e83d7e8")
addappid(1154842, 1, "f0602119edb1dd5ce9126d4319d32fa52daaae4363fdca533cc9f315f8d706b1")

