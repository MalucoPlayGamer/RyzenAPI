-- Lua provided by RyzenAPI
-- Game: Album Corvus

-- MAIN APPLICATION
addappid(843230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(843232,0,"d39572722a2128800101a61d0c5415687453e6fe31adae70036cca7d335e9b78")

