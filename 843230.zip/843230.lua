-- Lua provided by RyzenAPI
-- Game: Album Corvus

-- MAIN APPLICATION
addappid(843230)

-- MAIN APP DEPOTS / PACKAGES
addappid(843232,0,"d39572722a2128800101a61d0c5415687453e6fe31adae70036cca7d335e9b78")

