-- Lua provided by RyzenAPI 
-- Game: universe treasure
addappid(2083690)
addappid(2083691, 1, "be2d8ff0fe2d8eebfb97b500cebfbf65d8beb53eddb6eb9172818b549950e142")
