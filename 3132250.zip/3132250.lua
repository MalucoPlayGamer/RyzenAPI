-- Lua provided by RyzenAPI
-- Game: Game: Heian City Story

-- MAIN APPLICATION
addappid(3132250)
-- Game: addappid(3132250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132251, 1, "8c21599629aaea7b453ca44058a3578c32b4a666572836870420d58801299230")
