-- Lua provided by RyzenAPI
-- Game: Teddy Floppy Ear - The Race

-- MAIN APPLICATION
addappid(371420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(371421, 1, "fbee88b56fd8ba1856ed1d6ba72b60459a2e13010e804c238348d6e3289c3e84")
addappid(371422, 1, "bd9fd7e2d3f8288c0e990cf89cbd12f73a935e3cdae3d6be07a957a9722405b5")
addappid(371423, 1, "352b0f9de99a30e137361a52e039039b35565277fedda417d39052877dcc8450")
