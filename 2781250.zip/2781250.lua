-- Lua provided by RyzenAPI
-- Game: Lyndaria: Lust Adventure

-- MAIN APPLICATION
addappid(2781250)
-- Game: addappid(2781250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781251, 1, "0464b6e2894be1a77f7e56e17eab98f4511d80a4dd5070bda1b4a0bebc83beb8")
