-- Lua provided by RyzenAPI
-- Game: Lyndaria: Lust Adventure

-- MAIN APPLICATION
addappid(2781250)
addappid(3170180)
addappid(3170190)
addappid(3170200)
addappid(3299220)
addappid(3467870)
addappid(3645200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781251,0,"0464b6e2894be1a77f7e56e17eab98f4511d80a4dd5070bda1b4a0bebc83beb8")
addappid(3170180,0,"7dffeacfc74b0c497258f32ab79a23d26e824b2f645ffbdc3baed3cbfaea08eb")
addappid(3170190,0,"393ad3c1b0055dbdb6e5a1f626b188486bcc4cb42e1b9f59c5e64ee1928e5b6b")
addappid(3170200,0,"61913975dce4c23923cb9319f8dbfaca4078207f9018369fba85b7dbe47cf5aa")

