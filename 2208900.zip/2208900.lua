-- Lua provided by RyzenAPI 
-- Game: World of Unlit
addappid(2208900)
addappid(2208901, 1, "49cd2ef7fc65bb6596d6c4931fa3327f7b2f4ae0d47c7a090adeb86fad9fa1b6")
