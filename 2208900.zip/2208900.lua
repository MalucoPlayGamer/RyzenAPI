-- Lua provided by RyzenAPI
-- Game: addappid(2208900)

-- MAIN APPLICATION
addappid(2208900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208901, 1, "49cd2ef7fc65bb6596d6c4931fa3327f7b2f4ae0d47c7a090adeb86fad9fa1b6")
