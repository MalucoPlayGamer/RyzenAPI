-- Lua provided by RyzenAPI
-- Game: Darkarta: A Broken Heart's Quest Standard Edition

-- MAIN APPLICATION
addappid(228984)
addappid(228990)
addappid(634180)
addappid(699200)

-- MAIN APP DEPOTS / PACKAGES
addappid(634186,0,"9711a41e55b41915443b3d5c11fa67b685b88bc230f2f52b54d79b7032549296")
addappid(634187,0,"0262cee6b45faed0c89084530e4a14454cee7fd5ad556482410b2beb0c8ff14a")
addappid(634188,0,"1bb5b4aa26d343e1863a306ca1d8ce121cb62db49c6e580a2b4eb8c178f548d0")
addappid(634189,0,"89d5f695eed679b5df2daee34285ad60c4c40873ef40525bc034efdb6015c692")

