-- Lua provided by RyzenAPI
-- Game: Sound Monster Soundboard

-- MAIN APPLICATION
addappid(2436790)
-- Game: addappid(2436790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436791, 1, "e5c3df757a652d56fbd7728b724c39377365acd8826f1a09331617dfba8d3c3d")
