-- Lua provided by SkyAPI 
-- Game: Sound Monster Soundboard
addappid(2436790)
addappid(2436791, 1, "e5c3df757a652d56fbd7728b724c39377365acd8826f1a09331617dfba8d3c3d")
