-- Lua provided by RyzenAPI
-- Game: 1497780

-- MAIN APPLICATION
addappid(1497780)
-- Game: addappid(1497780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497781, 1, "1af5bbb2245aedfb7ad0eff9a914feb1b14022728401a70b8588d47f63261d20")
