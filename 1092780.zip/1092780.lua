-- Lua provided by RyzenAPI
-- Game: Depixtion

-- MAIN APPLICATION
addappid(1092780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092781, 1, "b35d93d01f16aaec3e600d4edfa172c5683e534ec4ba2fa1163b2e0815a24cc6")
addappid(1357340, 0, "e56598c3f7eb707355fd918272ee936e83f4ba3c72a3db5f747aaeaae8ef6069")

