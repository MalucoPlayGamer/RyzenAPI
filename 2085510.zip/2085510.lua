-- Lua provided by RyzenAPI
-- Game: 2085510

-- MAIN APPLICATION
addappid(2085510)
-- Game: addappid(2085510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085511, 1, "f37d943b85d546a7b2ceef2bf1510b766e83f81d79ce15e4d17ab7c55a58a4a1")
