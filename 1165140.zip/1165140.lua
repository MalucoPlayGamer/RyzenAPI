-- Lua provided by RyzenAPI 
-- Game: Picross Love
addappid(1165140)
addappid(1165141, 1, "7aeb71a55866cbfa4a57b31f71122ff5516b62ce6693897bba52cd3024914fe3")
addappid(1193410, 0, "14528b052fdb0bac7c4c17312ff73aed886c11824f161e4166a5d56dd637deb4")
