-- Lua provided by RyzenAPI
-- Game: RetroArch - MojoZork

-- MAIN APPLICATION
addappid(2246910)
-- Game: addappid(2246910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246911, 1, "4f2b928867ad2388d0c4beea5880459b0ec06bdc68373a317c4a2d3225cce3d7")
addappid(2246912, 1, "c6fbf42d953bb132c1ebf894327c6a76c34b4a0786dbf448bdc58b0cfa478913")
