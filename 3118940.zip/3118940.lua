-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin PixelScapes Town Pack

-- MAIN APPLICATION
addappid(3118940)
-- Game: addappid(3118940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118940,0,"a9d980b0a805d10fa773b2f923a8f501f763b17799a4df0f8187ea3b78c4c08a")
