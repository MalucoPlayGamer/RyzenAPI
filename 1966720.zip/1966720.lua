-- Lua provided by RyzenAPI
-- Game: Lethal Company

-- MAIN APPLICATION
addappid(1966720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966721, 1, "b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949")
