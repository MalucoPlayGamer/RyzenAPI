-- Lua provided by RyzenAPI 
-- Game: Lethal Company
addappid(1966720)
addappid(1966721, 1, "b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949")
