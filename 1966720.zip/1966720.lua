-- Lua provided by RyzenAPI
-- Game: Lethal Company

-- MAIN APPLICATION
addappid(1966720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1966721, 1, "b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949")

