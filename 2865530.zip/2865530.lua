-- Lua provided by RyzenAPI
-- Game: FRONT MISSION 2: Remake Demo

-- MAIN APPLICATION
addappid(2865530)
-- Game: addappid(2865530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865531, 1, "05c0f034dad40a2b1f94a2f639d95aa7811b3a59ac6905b4ceefc6f7a95f4317")
