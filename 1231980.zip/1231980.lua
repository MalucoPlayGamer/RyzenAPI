-- Lua provided by RyzenAPI
-- Game: Coffee Talk - Soundtrack OST

-- MAIN APPLICATION
addappid(1231980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231981, 1, "c119ac052b8c70302386e08a7dbd304f9faf5a2e74011166189761ffd4801877")
addappid(1231982, 1, "7c14be995b0ca6c6548a36144a493aed637137abd696847a7ff2a6ee80b730d0")
