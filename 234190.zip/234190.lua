-- Lua provided by RyzenAPI
-- Game: Receiver

-- MAIN APPLICATION
addappid(234190)

-- MAIN APP DEPOTS / PACKAGES
addappid(234191, 1, "d4f466342b1f4e538d16e6e137855a7e8ab9dde11e425ff3773897ad456570f0")
addappid(234192, 1, "8fdf16219daca5d15ba0846022fc2e6e3a61db3718992511c70fad778feddb04")
addappid(234193, 1, "83b01cabd93963cf9bb0dd27df37bbdf5aa69948bfd73d70ee9fbed0e78d2999")
addappid(234194, 1, "fdc25d2a8c2bc85776c6a26d9f9eddecef2657b2bb1444d86836135e9e01b4e8")
addappid(234195, 1, "f962f2620aa6a50cfb2059f04eff982dff498a59a1a727b4c3e12b993462cc9a")

