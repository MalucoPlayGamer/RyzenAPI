-- Lua provided by RyzenAPI
-- Game: AppID 958130

-- MAIN APPLICATION
addappid(958130)
-- Game: addappid(958130)

-- MAIN APP DEPOTS / PACKAGES
addappid(958131, 1, "086cf714f1026cf93e2bfccc75f358160e3144c74b0850ebad8b64fdab094360")
