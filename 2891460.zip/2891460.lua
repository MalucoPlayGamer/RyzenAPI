-- Lua provided by RyzenAPI
-- Game: Game: DIG VR

-- MAIN APPLICATION
addappid(2891460)
-- Game: addappid(2891460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891461, 1, "63ca96859e38130e01e89522c3a63f2b1da0336d6758a9348bbfda868f987393")
