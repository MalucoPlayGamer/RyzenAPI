-- Lua provided by RyzenAPI
-- Game: 327890

-- MAIN APPLICATION
addappid(327890)
-- Game: addappid(327890)

-- MAIN APP DEPOTS / PACKAGES
addappid(327891, 1, "ede7ce25f63c5f987ecbe592f3ce0434c67b117a65def089923f3bdd56ca71d5")
addappid(327892, 1, "b5980632023a96b14be95900087bb3a12be5337413dc37c9c88519f33f319dd3")
addappid(327893, 1, "93361dbc38e3c6a7f3bdbdc255d42240bb206aaa7daed54f9978ac41960fa030")
