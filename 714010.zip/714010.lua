-- Lua provided by RyzenAPI
-- Game: Aimlabs

-- MAIN APPLICATION
addappid(714010)
addappid(1122400)
addappid(1206190)
addappid(1383420)
addappid(1417600)
addappid(1450700)
addappid(1465850)
addappid(1896380)
addappid(1974470)
addappid(1974480)
addappid(1992460)
addappid(2021550)
addappid(2021560)
addappid(2253310)
addappid(2282170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(714011, 1, "b959968aba4c376652705a7f8697f75a1e4d94e7546548e2bb26d220cea76698")

