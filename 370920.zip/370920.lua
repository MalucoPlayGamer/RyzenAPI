-- Lua provided by RyzenAPI
-- Game: Game: AppID 370920

-- MAIN APPLICATION
addappid(370920)
-- Game: addappid(370920)

-- MAIN APP DEPOTS / PACKAGES
addappid(370921, 1, "1e200410137bb6a92532849823148bcec94dead7249d7643e6a1f4bb40e357a9")
addappid(370922, 1, "3d7fd7fd53143da6cb81f8bf896478d8e2304b7352fc63abd4a59ccb479ab7eb")
addappid(370923, 1, "02496d770ea4db3657bf156084515aed3cdcb7e1e9c59e65a316a132a6402fd1")
addappid(379650, 0, "98a2955e8ed6b1d8961e2dd5cdb56ab1efa75de1e6888f092759c11aa378d7ea")
