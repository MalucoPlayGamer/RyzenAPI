-- Lua provided by RyzenAPI
-- Game: addappid(1684490)

-- MAIN APPLICATION
addappid(1684490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684491, 1, "88d4dd763e586975d0c3c44bd369815828c041aa589e7c7ec78ccbf911b873a6")
