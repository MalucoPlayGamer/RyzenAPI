-- Lua provided by RyzenAPI
-- Game: Game: ArcaniA: Fall of Setarrif

-- MAIN APPLICATION
addappid(65610)
-- Game: addappid(65610)

-- MAIN APP DEPOTS / PACKAGES
addappid(65611, 1, "10ebd3b4299eb8abdfdce9e8c3fe6e341832650f293dee765de50b3e44ee0fe9")
addappid(65612, 1, "f0738f22d36ee8ab1c89809e9e3e35a0f6f5a941848263bf6ca1a18f1dd08e1b")
addappid(65613, 1, "798e7432d153331697f62d1ee75c036f2b34b13c1837f68f17f7f0243bcb7820")
addappid(65614, 1, "262ed0d0af77e557331b75abee32178901ed1908912fd211b68b457b5c530347")
addappid(65615, 1, "bd6626de4bdb685b281ce6d83e40fcae4f2edd69c2826e7473cb21e44f94d938")
addappid(65616, 1, "b4ba865d32b4a5f43e463f68bc940615cc2a4c7f79e6af06af122608c4f14dbf")
addappid(65617, 1, "0247a78a584743e2766eb08cebb54d56adc505f89b7d7a05b86d4d4dbf2381ca")
addappid(65618, 1, "7a60c57b5fba1324db6d275a4f3bc814351b3257ea50b2aa12942d8061fa3190")
addappid(65619, 1, "6189676636fbfc5c445bd12c86b6f1b49f1b8b87586e08adda0df591e6cbe254")
