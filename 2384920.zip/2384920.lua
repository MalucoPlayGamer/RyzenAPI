-- Lua provided by RyzenAPI
-- Game: Game: Firefighter Connor

-- MAIN APPLICATION
addappid(2384920)
-- Game: addappid(2384920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384921, 1, "65a0830d086f573a699fa2c439fda65bfead80620570ca6650160b8af85dd452")
