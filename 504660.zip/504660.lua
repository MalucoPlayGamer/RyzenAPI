-- Lua provided by RyzenAPI
-- Game: addappid(504660)

-- MAIN APPLICATION
addappid(504660)

-- MAIN APP DEPOTS / PACKAGES
addappid(504661, 1, "6f4a237708f41ed6e698db91befc1b0424d8c24b9ddb379a1525536db2467d11")
