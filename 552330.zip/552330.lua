-- Lua provided by RyzenAPI
-- Game: Happy Birthday, Bernard

-- MAIN APPLICATION
addappid(552330)

-- MAIN APP DEPOTS / PACKAGES
addappid(552331,0,"6a7d735105d394d6aa442b5cfedfbdb299d785dd6ae731affd198fa7dfad2530")

