-- Lua provided by RyzenAPI
-- Game: 1063340

-- MAIN APPLICATION
addappid(1063340)
-- Game: addappid(1063340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063341, 1, "29c7d29f47328d29f98fd93e81b581e3ff2aad9d2aed70b5fd3a47d6db109831")
