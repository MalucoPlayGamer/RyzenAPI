-- Lua provided by RyzenAPI
-- Game: 灵幻先生 : 致敬一代僵尸道长！The Exorcist

-- MAIN APPLICATION
addappid(1063340)
-- Game: addappid(1063340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063341, 1, "29c7d29f47328d29f98fd93e81b581e3ff2aad9d2aed70b5fd3a47d6db109831")
