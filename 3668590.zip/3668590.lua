-- Lua provided by RyzenAPI
-- Game: addappid(3668590)

-- MAIN APPLICATION
addappid(3668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668591, 1, "53da152a23648f9a6c8487d0ec9d4334e1bde5cfc26482026e41494bc1827b1f")
