-- Lua provided by RyzenAPI
-- Game: addappid(1537450)

-- MAIN APPLICATION
addappid(1537450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537452,0,"2c2b5a372c2c79497b7eaf4222914781709b4fd15a6434c5d8defddd1757d01d")
