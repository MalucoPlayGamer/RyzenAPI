-- Lua provided by SkyAPI 
-- Game: Dead Unending
addappid(2236240)
addappid(2236241, 1, "d00d55c25031f40c0a0429114c0fc997848878af5dfa2aa56b4de0249857498c")
