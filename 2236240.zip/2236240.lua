-- Lua provided by RyzenAPI
-- Game: Dead Unending

-- MAIN APPLICATION
addappid(2236240)
-- Game: addappid(2236240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236241, 1, "d00d55c25031f40c0a0429114c0fc997848878af5dfa2aa56b4de0249857498c")
