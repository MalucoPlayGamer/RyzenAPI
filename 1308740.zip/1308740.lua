-- Lua provided by RyzenAPI 
-- Game: Hentai Roguelike
addappid(1308740)
addappid(1308741, 1, "695b690be98f7dd92d42088686f2db9674ba78012a8b0aaa8cc1a8b063672caa")
