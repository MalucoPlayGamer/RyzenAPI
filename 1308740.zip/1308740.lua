-- Lua provided by RyzenAPI
-- Game: Hentai Roguelike

-- MAIN APPLICATION
addappid(1308740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1308741, 1, "695b690be98f7dd92d42088686f2db9674ba78012a8b0aaa8cc1a8b063672caa")

