-- Lua provided by RyzenAPI
-- Game: addappid(1308740)

-- MAIN APPLICATION
addappid(1308740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308741, 1, "695b690be98f7dd92d42088686f2db9674ba78012a8b0aaa8cc1a8b063672caa")
