-- Lua provided by RyzenAPI
-- Game: Re:Lord – Tales of Adventure Demo

-- MAIN APPLICATION
addappid(2767140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767141, 1, "182c17a7616529020d9f0bcd9f37c2074e5467a948036575b8e58624ed789ca8")
