-- Lua provided by RyzenAPI 
-- Game: Terror Diversion
addappid(3190430)
addappid(3190431, 1, "ab86aebe973926a247441e3cece3eb6d3b6d2d52f614ed489924a2704fb754eb")
