-- Lua provided by RyzenAPI
-- Game: Game: Terror Diversion

-- MAIN APPLICATION
addappid(3190430)
-- Game: addappid(3190430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190431, 1, "ab86aebe973926a247441e3cece3eb6d3b6d2d52f614ed489924a2704fb754eb")
