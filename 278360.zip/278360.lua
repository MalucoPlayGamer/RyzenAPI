-- Lua provided by RyzenAPI
-- Game: AppID 278360

-- MAIN APPLICATION
addappid(278360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(278361, 1, "7bcac22295ba8f08740447ba05be0a05dbb12254a50e4e40bfeba7e565e832a8")
addappid(278362, 1, "edd1214ea431eee229b3424948951d11fecfbaa496fc751f157fbb905a29fe7c")
addappid(278363, 1, "a436c64bf784e8c66a3fadfe854b31979889dc2e039e17bd0e457e730984d124")

