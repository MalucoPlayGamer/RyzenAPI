-- Lua provided by SkyAPI 
-- Game: AppID 278360
addappid(278360)
addappid(278361, 1, "7bcac22295ba8f08740447ba05be0a05dbb12254a50e4e40bfeba7e565e832a8")
addappid(278362, 1, "edd1214ea431eee229b3424948951d11fecfbaa496fc751f157fbb905a29fe7c")
addappid(278363, 1, "a436c64bf784e8c66a3fadfe854b31979889dc2e039e17bd0e457e730984d124")
