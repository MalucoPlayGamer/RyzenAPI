-- Lua provided by RyzenAPI
-- Game: AppID 391750

-- MAIN APPLICATION
addappid(391750)
-- Game: addappid(391750)

-- MAIN APP DEPOTS / PACKAGES
addappid(391751, 1, "32067a7c8f0143ef39473bf3baf84982ce747ad442261664f469829b444bdb49")
