-- Lua provided by RyzenAPI
-- Game: AppID 91610

-- MAIN APPLICATION
addappid(91610)

-- MAIN APP DEPOTS / PACKAGES
addappid(91611, 1, "373a7ec746c5e16b464c4f28eae8a0398f602ed84285952f17b1dcefb6b17260")

