-- Lua provided by RyzenAPI
-- Game: Embr

-- MAIN APPLICATION
addappid(1062830)
addappid(1363500)
addappid(1518080)
addappid(1843280)
-- Game: addappid(1062830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062831, 1, "b67bf65058bab34ac1aec469651b75032e1bff85cdd58cb2e28d51f107d29776")
