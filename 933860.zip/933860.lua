-- Lua provided by RyzenAPI
-- Game: Game: Discolored

-- MAIN APPLICATION
addappid(933860)
-- Game: addappid(933860)

-- MAIN APP DEPOTS / PACKAGES
addappid(933861, 1, "07a889673b5318a8a530a97b334707da08bcf3fe4e69cd4a1a0704b07f111f9d")
addappid(1191130, 0, "e9d6ff9138a5fb06dce5c30ed3e6b55e9a61ab13af519691d9ecad47b12f3833")
