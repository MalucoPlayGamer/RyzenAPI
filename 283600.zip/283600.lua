-- Lua provided by RyzenAPI
-- Game: Game: World of Subways 2 – Berlin Line 7

-- MAIN APPLICATION
addappid(283600)
-- Game: addappid(283600)

-- MAIN APP DEPOTS / PACKAGES
addappid(283601, 1, "7ea8c37abd892c385a8d7fc242cd46e9afd9a4d4b3e611509138f8ed8c80b655")
addappid(283602, 1, "ce8651949f18c3254bbec4b380b2e32a70fa5db05274dcbe5500d4e8b5f862b1")
addappid(283603, 1, "2cdc51899b44d10522aee5d9ade86fcfc2aa1454d8734e0bbdf7a4372387342b")
