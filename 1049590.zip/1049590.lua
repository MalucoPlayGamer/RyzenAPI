-- Lua provided by SkyAPI 
-- Game: AppID 1049590
addappid(1049590)
addappid(1049591, 1, "1d51ccd03e39e116baa9dcd0e8cfd77a2f63e36242cfce62b80505a25f96f889")
