-- Lua provided by RyzenAPI
-- Game: 1049590

-- MAIN APPLICATION
addappid(1049590)
-- Game: addappid(1049590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049591, 1, "1d51ccd03e39e116baa9dcd0e8cfd77a2f63e36242cfce62b80505a25f96f889")
