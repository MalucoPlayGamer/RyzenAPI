-- Lua provided by RyzenAPI
-- Game: Subverse

-- MAIN APPLICATION
addappid(1034140)
addappid(3341270)
addappid(3341290)
addappid(4245650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1034141, 1, "9c712c1efc2a5b5f884a153935bfca195dbe00c3a2bba7d8ec93b2e29daeb527")
addappid(3342820, 0, "d4e7b31fc2896aa5b8dbbfba739af9743b5faea198d0e66078f4ce1e8d16d2b0")
