-- Lua provided by RyzenAPI
-- Game: AppID 1297770

-- MAIN APPLICATION
addappid(1297770)
-- Game: addappid(1297770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297771, 1, "0a332a9001eac4b556561a1d68b2f41123be665845a7aa687f9dd3deab58c801")
