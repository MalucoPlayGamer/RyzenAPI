-- Lua provided by RyzenAPI
-- Game: Turqu-chan in the Hentai Laboratory Demo

-- MAIN APPLICATION
addappid(2530440)
-- Game: addappid(2530440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530441, 1, "3aec51bcc04e6c3b9f941ee2bb638e6347b5eb27126c10e59e68b9cddadb21b7")
