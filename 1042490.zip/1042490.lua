-- Lua provided by RyzenAPI
-- Game: Call of the Sea

-- MAIN APPLICATION
addappid(1042490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1042491, 1, "fa03e31f57d085b1b10d7584d44ccd8881de3b3de3aef9ceb1d2aa7e1b650393")
addappid(1475510, 0, "412ca1e047f2b1baf96a865cc3af2db4aa9aa3048a4e3ed0c25d46202c8a09a9")

