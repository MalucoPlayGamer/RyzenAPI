-- Lua provided by SkyAPI 
-- Game: Call of the Sea
addappid(1042490)
addappid(1042491, 1, "fa03e31f57d085b1b10d7584d44ccd8881de3b3de3aef9ceb1d2aa7e1b650393")
addappid(1475510, 0, "412ca1e047f2b1baf96a865cc3af2db4aa9aa3048a4e3ed0c25d46202c8a09a9")
