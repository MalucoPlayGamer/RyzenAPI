-- Lua provided by RyzenAPI
-- Game: Cake Invaders

-- MAIN APPLICATION
addappid(1619080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619081, 1, "039d20c10244e9f9845569c83db005f926bd07ed8df05dbddd27065c0d2c560b")
