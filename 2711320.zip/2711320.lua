-- Lua provided by RyzenAPI
-- Game: CUM Queens 🔞💦

-- MAIN APPLICATION
addappid(2711320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711321, 1, "d0aba6fa153e92e1d086e518c61b2dbff32bf99174a4432a5201a31b05c8eeff")

