-- Lua provided by RyzenAPI
-- Game: Blue Hunter

-- MAIN APPLICATION
addappid(2992190) -- Blue Hunter

-- MAIN APP DEPOTS / PACKAGES
addappid(2992192, 1, "2fcac5add167b30b33a44071fe3282f652d0f67c15d54234de0835dc6e750577") -- Depot 2992192

