-- 4951480's Lua and Manifest Created by Hubcap Manifest
-- LIGHT IT
-- Created: August 07, 2026 at 13:22:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4951480) -- LIGHT IT
-- MAIN APP DEPOTS
addappid(4951481, 1, "2e38710515f98ad45ffbeac71ee8af64ac5ff0bd2f17f740395851a4dbddc479") -- Depot 4951481
setManifestid(4951481, "6665508221454445806", 202097804)