-- Lua provided by RyzenAPI
-- Game: LIGHT IT

-- MAIN APPLICATION
addappid(4951480) -- LIGHT IT

-- MAIN APP DEPOTS / PACKAGES
addappid(4951481, 1, "2e38710515f98ad45ffbeac71ee8af64ac5ff0bd2f17f740395851a4dbddc479") -- Depot 4951481

