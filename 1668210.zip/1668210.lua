-- Lua provided by RyzenAPI
-- Game: A Sad Journey

-- MAIN APPLICATION
addappid(1668210)
-- Game: addappid(1668210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668211, 1, "5286182a43f8bcb5469f00c462d1d8471f163418ca100df404078f3f796a7f59")
