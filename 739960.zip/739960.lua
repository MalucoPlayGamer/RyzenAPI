-- Lua provided by RyzenAPI
-- Game: 739960

-- MAIN APPLICATION
addappid(739960)
-- Game: addappid(739960)

-- MAIN APP DEPOTS / PACKAGES
addappid(739961, 1, "f46cc5b9daa17ac71892da67376b588c28724a87f2a1bee6647ab6bdc24fff97")
