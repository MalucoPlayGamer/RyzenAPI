-- Lua provided by RyzenAPI
-- Game: addappid(804530)

-- MAIN APPLICATION
addappid(804530)

-- MAIN APP DEPOTS / PACKAGES
addappid(804531, 1, "ecb0b6a6bf3d6efdbd7f072cef4b23b39dbbf75271d2f464892c9bb9502589ae")
