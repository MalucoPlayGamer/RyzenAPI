-- Lua provided by RyzenAPI
-- Game: Fix My Hand Doc

-- MAIN APPLICATION
addappid(2148740)
-- Game: addappid(2148740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148741, 1, "871029f86f106fd36ccb4ce2631067636d3f428ed20e34840fd2a279ba1d1c43")
