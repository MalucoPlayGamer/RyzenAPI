-- Lua provided by RyzenAPI
-- Game: Silly Suspects

-- MAIN APPLICATION
addappid(4117190) -- Silly Suspects

-- MAIN APP DEPOTS / PACKAGES
addappid(4117191, 1, "ed11de41ca59ff55794cdf54209920fb1d39ff1bc2012b19fbc970339455a74b") -- Depot 4117191

