-- 4117190's Lua and Manifest Created by Hubcap Manifest
-- Silly Suspects
-- Created: August 04, 2026 at 09:25:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4117190) -- Silly Suspects
-- MAIN APP DEPOTS
addappid(4117191, 1, "ed11de41ca59ff55794cdf54209920fb1d39ff1bc2012b19fbc970339455a74b") -- Depot 4117191
setManifestid(4117191, "4540038931359560534", 495778043)