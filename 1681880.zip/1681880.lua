-- Lua provided by RyzenAPI
-- Game: Game: NHRA Championship Drag Racing: Speed For All

-- MAIN APPLICATION
addappid(1681880)
-- Game: addappid(1681880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681881, 1, "0af574fee59dfe8273b36f9446fcd87a0b57fe6e2a28e938712101a1482dde70")
