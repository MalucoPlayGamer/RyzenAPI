-- Lua provided by RyzenAPI
-- Game: NHRA Championship Drag Racing: Speed For All

-- MAIN APPLICATION
addappid(1681880) -- NHRA Championship Drag Racing: Speed For All
addappid(1971720) -- NHRA Championship Drag Racing Speed for All - John Force Racing Pack
addappid(1971721) -- NHRA Championship Drag Racing Speed for All - Nitro Fire Pack
addappid(1971722) -- NHRA Championship Drag Racing Speed for All - Moonshot Pack
addappid(1971723) -- NHRA Championship Drag Racing Speed for All - Battle Ready Pack
addappid(1971724) -- NHRA Championship Drag Racing Speed for All - Electro Blitz Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1681881, 1, "0af574fee59dfe8273b36f9446fcd87a0b57fe6e2a28e938712101a1482dde70") -- Depot 1681881
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
