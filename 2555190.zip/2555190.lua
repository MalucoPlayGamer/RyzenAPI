-- Lua provided by RyzenAPI
-- Game: Poppy Playtime - Chapter 3

-- MAIN APPLICATION
addappid(2555190)
-- Game: addappid(2555190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555198,0,"9b728f6de496b74d3e277f9e8dd3c852dd0b70b4ab461fc5c2d5db73a5ffeec2")
