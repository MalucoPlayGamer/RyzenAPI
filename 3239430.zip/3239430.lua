-- Lua provided by RyzenAPI
-- Game: VARK SHORTS Premium Demo

-- MAIN APPLICATION
addappid(3239430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239431, 1, "b9424a697f76babce2825d45a06c68dc718ed3b53b387e5cac3d5ee2a89d1218")
