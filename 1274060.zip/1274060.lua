-- Lua provided by RyzenAPI
-- Game: The Ball Adventure

-- MAIN APPLICATION
addappid(1274060)
-- Game: addappid(1274060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274061, 1, "2c68eac4dd7ef574cce0ce3da929d19b9c80d64cb69dc31094f59e1e44091fe9")
