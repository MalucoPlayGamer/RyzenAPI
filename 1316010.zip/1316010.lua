-- Lua provided by RyzenAPI
-- Game: Grounded Demo

-- MAIN APPLICATION
addappid(228988)
addappid(1316010)
addappid(1316011)

-- MAIN APP DEPOTS / PACKAGES
addappid(962131,0,"809ed5f98fa8a3d2c3636c33504157cf05fc683e1810d35e554d7976573a4424")

