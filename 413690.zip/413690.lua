-- Lua provided by RyzenAPI
-- Game: AppID 413690

-- MAIN APPLICATION
addappid(413690)
-- Game: addappid(413690)

-- MAIN APP DEPOTS / PACKAGES
addappid(413691, 1, "88de4c47f086fd8246ec33263ae088f3b6d01c74f77afc645d67dbb9b6bd667f")
