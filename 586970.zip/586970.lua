-- Lua provided by RyzenAPI
-- Game: Game: AppID 586970

-- MAIN APPLICATION
addappid(586970)
-- Game: addappid(586970)

-- MAIN APP DEPOTS / PACKAGES
addappid(586971, 1, "1e06179c2138fda410457d6b962124abb0d262e620ed13523e8a401182f63897")
