-- Lua provided by RyzenAPI
-- Game: Game: Princess Quest

-- MAIN APPLICATION
addappid(2218030)
-- Game: addappid(2218030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218031, 1, "7cc0402acec57800e2f6f886982dbb3d996b645e149605e77641ed14047be39c")
addappid(2878870, 0, "ca18282acf958008c22e6e85bda271e91d054b6b301dfb61a2603021b239690c")
