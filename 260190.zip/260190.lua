-- Lua provided by RyzenAPI
-- Game: Marc Eckō's Getting Up: Contents Under Pressure

-- MAIN APPLICATION
addappid(260190)

-- MAIN APP DEPOTS / PACKAGES
addappid(260191, 1, "0085a61630957c85643edb83a1f78547c5e17ac68b0febb94605fee78af879c3")
