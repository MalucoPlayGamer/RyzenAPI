-- Lua provided by RyzenAPI
-- Game: WORLDS AT WAR (Monitor & VR)

-- MAIN APPLICATION
addappid(744670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(744671,0,"6f92e1831c10c89701cc556f504f56771c87c5f2698ea96741b7423336f41ce6")

