-- Lua provided by RyzenAPI
-- Game: Rhythm Any Music

-- MAIN APPLICATION
addappid(2153280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153282,0,"a935519743b86c78ea56d818d0e103bb8549a873d2707cbae5d62d124d35a294")

