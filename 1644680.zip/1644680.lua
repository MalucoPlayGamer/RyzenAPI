-- Lua provided by RyzenAPI
-- Game: AppID 1644680

-- MAIN APPLICATION
addappid(1644680)
-- Game: addappid(1644680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644681, 1, "e46c7ce1871416eb298ad8708dbbaea58658e792ff944090d17251cbe7571542")
