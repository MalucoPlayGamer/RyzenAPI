-- Lua provided by RyzenAPI
-- Game: Telling Lies - Original Soundtrack

-- MAIN APPLICATION
addappid(1138570)
-- Game: addappid(1138570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138571, 1, "4df2da1b6430bce3e05bf773a4f9a97dd8906b6adc0aa8241dab8c924d5770e7")
