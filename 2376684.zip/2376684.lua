-- Lua provided by RyzenAPI
-- Game: 2376684

-- MAIN APPLICATION
addappid(2376684)
-- Game: addappid(2376684)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376684,0,"6e52b3de3a359892d79332af8f7a699108a53088cbd5a4bedbc73c3e13fbd3b9")
