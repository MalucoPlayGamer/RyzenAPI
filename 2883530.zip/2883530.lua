-- Lua provided by RyzenAPI
-- Game: Dwarf Dove

-- MAIN APPLICATION
addappid(2883530)
-- Game: addappid(2883530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883532,0,"2bdf849ee46a25afdca51568bd76b68afc33d875768b5869ff74800fb8980675")
