-- Lua provided by RyzenAPI
-- Game: Mouthwashing Demo

-- MAIN APPLICATION
addappid(2747120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747121, 1, "179d68911cd6fecd9792428e096e0aaecd8cb48f085866071c8de435f0f6e1dd")
