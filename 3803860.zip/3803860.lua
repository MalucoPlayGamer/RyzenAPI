-- Lua provided by RyzenAPI
-- Game: Blood Oath

-- MAIN APPLICATION
addappid(3803860)
-- Game: addappid(3803860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3803861, 1, "6531150c054a0428a4753cf1903224552c0fa68b1e62171882089c7f6f971b7c")
