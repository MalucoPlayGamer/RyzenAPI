-- Lua provided by RyzenAPI
-- Game: Blood Oath

-- MAIN APPLICATION
addappid(3803860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3803861, 1, "6531150c054a0428a4753cf1903224552c0fa68b1e62171882089c7f6f971b7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
