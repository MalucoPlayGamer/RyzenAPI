-- Lua provided by RyzenAPI
-- Game: 20b

-- MAIN APPLICATION
addappid(1689730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689731, 1, "3f402c743bb1b371a766ecbc4a58c5b288088f849bb1a012878297a3b44ce4ce")
