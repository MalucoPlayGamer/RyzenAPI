-- Lua provided by RyzenAPI
-- Game: Action! - Gameplay Recording and Streaming

-- MAIN APPLICATION
addappid(228180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228181, 1, "34d0cf2ac7dbaa47a18969854e92a3a45edf17271cd04b70a31af5854b5aeaf2")
