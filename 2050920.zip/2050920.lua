-- Lua provided by RyzenAPI
-- Game: addappid(2050920)

-- MAIN APPLICATION
addappid(2050920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050921, 1, "4587b4ebe2625a118178c97d25297223a8ca03eee1099f95df38332302ef0acb")
