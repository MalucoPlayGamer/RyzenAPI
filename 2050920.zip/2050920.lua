-- Lua provided by RyzenAPI 
-- Game: Scranny
addappid(2050920)
addappid(2050921, 1, "4587b4ebe2625a118178c97d25297223a8ca03eee1099f95df38332302ef0acb")
