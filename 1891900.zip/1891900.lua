-- Lua provided by RyzenAPI
-- Game: Comixxx Flirtatious

-- MAIN APPLICATION
addappid(1891900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891901, 1, "bfa2baccd6d3717c06783f3bddcbb96e4797a1b119faf35d6da3b0f82026f7ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
