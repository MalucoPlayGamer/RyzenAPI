-- Lua provided by RyzenAPI
-- Game: AeternoBlade II Demo

-- MAIN APPLICATION
addappid(1456990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456991, 1, "04ab42bb296227d3086f137dbdefc719f6ab1e76d4093a26330932eaaea946f1")

