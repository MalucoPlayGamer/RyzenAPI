-- Lua provided by RyzenAPI
-- Game: AppID 1271080

-- MAIN APPLICATION
addappid(1271080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271081, 1, "88236e3167e841ef60e46ecdc8c8ea80065dc2fb71e5b89f1f867437baff9e9d")
