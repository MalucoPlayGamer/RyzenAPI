-- Lua provided by RyzenAPI
-- Game: 逗国科举 | Douguo Keju

-- MAIN APPLICATION
addappid(978200)
-- Game: addappid(978200)

-- MAIN APP DEPOTS / PACKAGES
addappid(978201, 1, "b11fc6336de326069960b132eff4eb796bdf08aa1b6fdeab683dba1f1b7d410e")
