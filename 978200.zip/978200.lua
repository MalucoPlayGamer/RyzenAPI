-- Lua provided by SkyAPI 
-- Game: 逗国科举 | Douguo Keju
addappid(978200)
addappid(978201, 1, "b11fc6336de326069960b132eff4eb796bdf08aa1b6fdeab683dba1f1b7d410e")
