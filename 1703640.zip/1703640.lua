-- Lua provided by RyzenAPI 
-- Game: BattleGrounds : War, Tanks And Nukes
addappid(1703640)
addappid(1703641, 1, "02d17fdc96fedc2b9f3e65222ae11eaec99a0501f1f4a2e0ca8c44a468241d11")
