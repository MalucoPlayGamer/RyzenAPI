-- Lua provided by RyzenAPI
-- Game: BattleGrounds : War, Tanks And Nukes

-- MAIN APPLICATION
addappid(1703640)
-- Game: addappid(1703640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703641, 1, "02d17fdc96fedc2b9f3e65222ae11eaec99a0501f1f4a2e0ca8c44a468241d11")
