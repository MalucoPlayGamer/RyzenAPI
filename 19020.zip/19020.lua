-- Lua provided by RyzenAPI
-- Game: AppID 19020

-- MAIN APPLICATION
addappid(19020)

-- MAIN APP DEPOTS / PACKAGES
addappid(19021, 1, "02e0329f855433ded9ab640a306a1ad366f82f526520cada9bd878bae8483baa")
