-- Lua provided by RyzenAPI
-- Game: Combat Mission Battle for Normandy

-- MAIN APPLICATION
addappid(2297010)
addappid(2298410)
addappid(2298411)
addappid(2298412)
addappid(2298413)
addappid(2971350)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2297011, 1, "30c3306f3cecd67e224dfa07d80db0e263ecbb2b639728c43a5f108e4e657896")
addappid(2297012, 1, "6c028f4d6aef4e86f22ec33d4b831d084dce349a1fd623f364f572838a791082")

