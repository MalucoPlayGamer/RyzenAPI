-- Lua provided by RyzenAPI
-- Game: Game: Dimense: Chapter 1

-- MAIN APPLICATION
addappid(1042100)
-- Game: addappid(1042100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042101, 1, "d65e4924f3e1926177fa7e94faeffce7ce9eac896649633cd659e5d0d05a893d")
