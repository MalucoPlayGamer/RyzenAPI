-- Lua provided by RyzenAPI
-- Game: 1X1

-- MAIN APPLICATION
addappid(3322770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322771, 1, "f7df2194a9b298f4cf506fcd9249fd4fa4d2e430fbfdc42efd792cdd0e9bc794")

