-- Lua provided by RyzenAPI
-- Game: Don't Trust Demo

-- MAIN APPLICATION
addappid(3414380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3414381, 1, "76c56bf9b99a37f10664b0063da31d6ce1000f425c5ce3b150c4f6f13dcf5360")

