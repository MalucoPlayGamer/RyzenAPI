-- Lua provided by RyzenAPI
-- Game: Game: AppID 978720

-- MAIN APPLICATION
addappid(978720)
-- Game: addappid(978720)

-- MAIN APP DEPOTS / PACKAGES
addappid(978721, 1, "a3d209f4c16bcce5e2b4a343c78605386ca4908a955a72c4eb5cc7a3e58f0645")
