-- Lua provided by RyzenAPI
-- Game: Space Ace

-- MAIN APPLICATION
addappid(240340)

-- MAIN APP DEPOTS / PACKAGES
addappid(240341, 1, "eaf218a5c016e7a25b1c46ac8745b4cb6b39ed6b0b65393770a588e0c9e676de")

