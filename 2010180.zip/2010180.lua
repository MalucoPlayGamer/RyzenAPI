-- Lua provided by RyzenAPI
-- Game: Game: R-Type Final 2 - Homage Stage Soundtrack

-- MAIN APPLICATION
addappid(2010180)
-- Game: addappid(2010180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010181, 1, "c63aaf7d1b4b8548556757efea2496d1166335621cfc036d29896c6746a80f73")
