-- Lua provided by RyzenAPI
-- Game: 1120960

-- MAIN APPLICATION
addappid(1120960)
-- Game: addappid(1120960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120961, 1, "d4f4a74c80a5dd9b58ea64c3e6686fd1143589b1f53af9b7bacd4e0fc97c5442")
