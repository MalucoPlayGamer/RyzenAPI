-- Lua provided by RyzenAPI
-- Game: Trooper 2 - Alien justice

-- MAIN APPLICATION
addappid(880340)

-- MAIN APP DEPOTS / PACKAGES
addappid(880341,0,"b5a02349fa380da47470c3e7fbec92abc7e622f42ea28ae011c56e175fb5588d")

