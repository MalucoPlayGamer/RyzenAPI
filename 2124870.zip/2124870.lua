-- Lua provided by RyzenAPI
-- Game: AppID 2124870

-- MAIN APPLICATION
addappid(2124870)
-- Game: addappid(2124870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124871, 1, "45dc9a8136dcd5e1ecd7679d0edf220e25f54b9a8d833f3f8c5c1338bfd0dccd")
