-- Lua provided by RyzenAPI
-- Game: Game: 电子祭祖

-- MAIN APPLICATION
addappid(2361320)
-- Game: addappid(2361320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361321, 1, "38534e7407ead1440ba9755e7b4529d8fa24a1cdb09a6df599fb7dd328c11c9b")
