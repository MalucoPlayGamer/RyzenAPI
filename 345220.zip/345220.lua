-- Lua provided by RyzenAPI
-- Game: Agent Awesome

-- MAIN APPLICATION
addappid(345220)

-- MAIN APP DEPOTS / PACKAGES
addappid(345221, 1, "6007b34addeacc2ffb226e18fc2398ec17b4f63498719c19e6231afb3eb87cd9")
addappid(345222, 1, "20ddd0664a2668e2f3de5a2f37e9c2c4c682f56e4566e9399a85a82cb2417c64")

