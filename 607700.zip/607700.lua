-- Lua provided by RyzenAPI
-- Game: Death is better than Hell

-- MAIN APPLICATION
addappid(607700)

-- MAIN APP DEPOTS / PACKAGES
addappid(607701, 1, "82164de80a62c17b6bea61c17c6409c56c74ff063f7a18b75f1fc21d5b6adb3a")

