-- Lua provided by RyzenAPI
-- Game: Red Titans

-- MAIN APPLICATION
addappid(2323840)
-- Game: addappid(2323840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323841, 1, "697ae43d6424887bd989f97f05d14cbef606c03227e32a5f03ee72db64f843e4")
