-- Lua provided by RyzenAPI
-- Game: addappid(812930)

-- MAIN APPLICATION
addappid(812930)

-- MAIN APP DEPOTS / PACKAGES
addappid(812931, 1, "14a7f84f5dcc8defc7958a1a6a7db44c9b20743f1aded2795fb55a52a6d310a8")
