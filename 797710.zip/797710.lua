-- Lua provided by RyzenAPI
-- Game: RPGolf

-- MAIN APPLICATION
addappid(797710)

-- MAIN APP DEPOTS / PACKAGES
addappid(797712,0,"65dd04a10643510d0a006516a39307b9dc3bb84ff53ca1ad9737e40f1a271d2d")

