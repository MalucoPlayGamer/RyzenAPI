-- Lua provided by SkyAPI 
-- Game: Infinity Escape
addappid(761110)
addappid(761111, 1, "8f51fa4ee4c9fce7c86737f2acf34ba85b3689c67cacb921e78c92edd99ea4d1")
addappid(761112, 1, "8ec5da80742f29e43be3311a71a75dbbda1e0d041b2d1af95dbf473c7495e043")
addappid(761113, 1, "849b9263701108d48db291d7a3d05c928a822fed0023e10296f67fe8fd547b27")
