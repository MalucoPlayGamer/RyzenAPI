-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Series BGM Pack

-- MAIN APPLICATION
addappid(1176619)
-- Game: addappid(1176619)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176619,0,"7b8bf8429706b360adc87bfd7fd8672485096445787d2b742af90e5c08d87dd1")
