-- Lua provided by RyzenAPI
-- Game: Doors Push or Pull

-- MAIN APPLICATION
addappid(854390)

-- MAIN APP DEPOTS / PACKAGES
addappid(854391, 1, "fcba2dbfff046d7f1a56433856bb71ab863991980758ea747e8eee26d09086a4")

