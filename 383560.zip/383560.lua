-- Lua provided by RyzenAPI
-- Game: AppID 383560

-- MAIN APPLICATION
addappid(383560)

-- MAIN APP DEPOTS / PACKAGES
addappid(383561, 1, "86423d834582b39aedc19dc79f7f21a13cbfcddd7e8a1e43d4d5928d351e2b7b")
