-- Lua provided by RyzenAPI
-- Game: AppID 383560

-- MAIN APPLICATION
addappid(383560)

-- MAIN APP DEPOTS / PACKAGES
addappid(383561, 1, "86423d834582b39aedc19dc79f7f21a13cbfcddd7e8a1e43d4d5928d351e2b7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
