-- Lua provided by RyzenAPI
-- Game: Curse of the Great Forest

-- MAIN APPLICATION
addappid(652060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(652061, 1, "bfd0f6fe5a1dbe368eef04d42ab92ee1b253e66cb19586035a3ee678db9aff98")

