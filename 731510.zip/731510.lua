-- Lua provided by RyzenAPI
-- Game: The Scrungeon Depths

-- MAIN APPLICATION
addappid(731510)

-- MAIN APP DEPOTS / PACKAGES
addappid(731511,0,"1bdd647ebd65023f8a7494502e3b3315a28410148f437abd040851dabb1d2622")
addappid(731512,0,"f76cc1e5e9331ec5e6fb5377eeeccc7863eca93da33587ceed31b8164da8a794")

