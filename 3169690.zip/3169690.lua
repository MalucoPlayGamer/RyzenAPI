-- Lua provided by RyzenAPI
-- Game: Minesweeper & Dungeon RPG: DEMO

-- MAIN APPLICATION
addappid(3169690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169691, 1, "5c601c281a89a0d4c5145a19fc2510883555a32800f74e6fa60a527cc4e22c3a")

