-- Lua provided by RyzenAPI
-- Game: Game: VR Harem Life ~ Your Room Became a Hang-Out for Girls!? ~ Demo

-- MAIN APPLICATION
addappid(3120610)
-- Game: addappid(3120610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120611, 1, "01563104fc5b0fb32d1a17e2494a9f6d7a5a2b88fb8bbe16e43ef216bfee0b71")
