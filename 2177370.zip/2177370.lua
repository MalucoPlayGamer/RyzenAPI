-- Lua provided by RyzenAPI
-- Game: addappid(2177370)

-- MAIN APPLICATION
addappid(2177370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177371, 1, "1145ca51bbb6305ed2feee30bb0f60d6665e4a5845e73a7ba0a2cde13ce2c14c")
