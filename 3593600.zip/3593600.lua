-- Lua provided by RyzenAPI
-- Game: Starry Trace

-- MAIN APPLICATION
addappid(3593600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593601, 1, "20dd1120aa26643cf5da5dccf3a11f3a51a5e030339859bc4955c180945f1e78")
