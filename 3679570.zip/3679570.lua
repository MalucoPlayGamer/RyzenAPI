-- Lua provided by RyzenAPI
-- Game: Screen Greens

-- MAIN APPLICATION
addappid(3679570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3679571,0,"d9ce41535fb58dc26bd988ab04cb14f350a43daebaeffe2a973a07f5e851c17c")

