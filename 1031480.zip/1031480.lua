-- Lua provided by RyzenAPI
-- Game: TouHou Makuka Sai ~ Fantastic Danmaku Festival Part II

-- MAIN APPLICATION
addappid(1031480)
addappid(1056360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1031481, 1, "3635e797f39bd8bcc7341af13dd88dfcf603d6496fdf94f9452a37e26a076068")
addappid(1031482, 1, "ccc33656d1079283a5f98c4edcaead6ee4b04f2b8ddb5ea6142b6aabe2f4b6bb")
addappid(1031483, 1, "a7bfdc862d06227c9ad06c9c5ae1cf9fe5e877b33ab68bc147510ba6e211d833")
addappid(1031484, 1, "0fbc5194d5b2c1dc20d7279b93446e5b9cfd7c17a02f3a3006125400917d7478")
addappid(1031485, 1, "f15fb3c8d58513f0ba9a1b5fbd0c8c892bf29f75f38b9b39ebbe077ec72f5a89")

