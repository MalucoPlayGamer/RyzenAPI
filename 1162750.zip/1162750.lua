-- Lua provided by RyzenAPI
-- Game: Songs of Syx

-- MAIN APPLICATION
addappid(1162750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162753,0,"0cf77b2f45376638393a163eeb4d7949593a9f55142f814d02bc047b3bc844d1")
addappid(1162754,0,"e0b5f2cfdcd692e1dfff1936c6d58da7c9e39ad1c13c8bbc64f4fea1e739ccba")
addappid(1162755,0,"0d39beec2d8a40a2fd55c5e93f3149c72fbb9ea30b0f74bd58927bb5c8b971b4")

