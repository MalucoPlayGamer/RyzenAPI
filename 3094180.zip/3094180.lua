-- Lua provided by RyzenAPI
-- Game: Stupid Cars

-- MAIN APPLICATION
addappid(3094180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094181, 1, "93416ff96361deb35d1224d9c3a446ac137ab7138b9adedab4a7bc8bd13a1ad5")
