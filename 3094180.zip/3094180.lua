-- Lua provided by SkyAPI 
-- Game: Stupid Cars
addappid(3094180)
addappid(3094181, 1, "93416ff96361deb35d1224d9c3a446ac137ab7138b9adedab4a7bc8bd13a1ad5")
