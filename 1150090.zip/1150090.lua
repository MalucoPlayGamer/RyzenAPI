-- Lua provided by RyzenAPI
-- Game: AppID 1150090

-- MAIN APPLICATION
addappid(1150090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150091, 1, "665c97034c7ae21a81c9c82e352ed9ff3c7e70626ed7afe9233db0bbed1cd939")
addappid(1150093, 1, "cba65e460e5550e33f89b1becb668701951d6782c4af8ac19d7457030344c294")
addappid(1150094, 1, "81dbda729176b415bd1b74f076ab2fab5490bc35377a56abdf34d05fd7a69384")
addappid(1545770, 0, "b1ca321815b0580c756f28ee5ddf0a4386ad33c6f969d59b33b39a43b30fff83")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1545771)
