-- Lua provided by SkyAPI 
-- Game: MUSICUS!
addappid(1418180)
addappid(1418181, 1, "6b5cc8823c204199b8c7bb8b57d00d04c04be5083574ec4c2e975f046f8c9533")
addappid(1418182, 1, "090d18889d7d42bffc8eaf8038a336ddf9b2e9a0fc43c8f264940672eeee4208")
