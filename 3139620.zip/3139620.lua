-- Lua provided by RyzenAPI
-- Game: Frontline Crisis

-- MAIN APPLICATION
addappid(3139620)
-- Game: addappid(3139620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3139621, 1, "46d86bf656eb76bd5604ede6bf0862749ba3450e8b42b1204457f512257bc826")
