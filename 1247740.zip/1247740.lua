-- Lua provided by RyzenAPI
-- Game: Your Story

-- MAIN APPLICATION
addappid(1247740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247741, 1, "bc41d2e05cd38ac6888c4a7561d732866e13b8d08ce0e50eb231b98b27f4a69d")
