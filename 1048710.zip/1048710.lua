-- Lua provided by RyzenAPI
-- Game: Hentai puzzle ? Not again....

-- MAIN APPLICATION
addappid(1048710)
-- Game: addappid(1048710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048711, 1, "c64591225921d014c7503070be45f53fd2fd644914174cdfc57d7026f42d999c")
