-- Lua provided by RyzenAPI
-- Game: 3808280

-- MAIN APPLICATION
addappid(3808280)
-- Game: addappid(3808280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3808281, 1, "08bc2d1c58c438ca28ba3c24bb26b6f0d68d50c88d43278c5263f76e44e6dad6")
