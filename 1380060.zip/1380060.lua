-- Lua provided by RyzenAPI
-- Game: Game: Urban Trial Tricky™ Deluxe Edition

-- MAIN APPLICATION
addappid(1380060)
-- Game: addappid(1380060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380061, 1, "c63269098d395526b3e7e903548359d329da7e656bb8d92d2e8d69194cac11f9")
