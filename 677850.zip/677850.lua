-- Lua provided by RyzenAPI
-- Game: Eselmir and the five magical gifts

-- MAIN APPLICATION
addappid(677850)

-- MAIN APP DEPOTS / PACKAGES
addappid(677851, 1, "03504b321d020a6b2b21d4b36375f694dda84d6f04b61005dfba03b76df5cee5")
addappid(677852, 1, "08d48ec78a1a9482f6a883ce19230e5ffe11eb9147c56e56e28e9d5f00a84f7e")
addappid(677853, 1, "c4e806c4798df4a54d2a0aefde194b3c1adea524755c35621f19a7a0ce026164")
addappid(677854, 1, "507ed96ea20f888b788917fd9418590faf4139270e6682f163486ee2e59681b7")
addappid(677855, 1, "3a220d1e601c9e2adeec5d36461ec0077291ca7e6ff16c5b07c0f9fd7360e070")
