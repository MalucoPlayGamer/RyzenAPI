-- Lua provided by RyzenAPI
-- Game: #Funtime

-- MAIN APPLICATION
addappid(1100350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100351, 1, "3c8bc0c6057de956c754dd1529e73c1a5aa57e9f60b6428cdac69d9df8727e06")

