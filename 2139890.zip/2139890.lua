-- Lua provided by RyzenAPI
-- Game: Dream Fight Will

-- MAIN APPLICATION
addappid(2139890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139891, 1, "f8a2e7d462491116d03fb1ad881e40e0dafaf4f92e43004f249bd32b0560cbc2")

