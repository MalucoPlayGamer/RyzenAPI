-- Lua provided by RyzenAPI
-- Game: Game: Commander Quest Demo

-- MAIN APPLICATION
addappid(2875110)
-- Game: addappid(2875110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875111, 1, "c444b10780747e9fd5b6b9614b0216d7f17ada50d6748a09ba41b4483bc0efe5")
