-- Lua provided by RyzenAPI
-- Game: Insurgency: Sandstorm

-- MAIN APPLICATION
addappid(581320)

-- MAIN APP DEPOTS / PACKAGES
addappid(581322,0,"1cf7a7b78cda78f21064d61cbb2ac22836872b85b7dc263a8bd13ca32e17a814")
addappid(1575020,0,"8d80c42ad2d2240671b19cde2cd7f80e7109c5403ed0373b6d0e84999ddc808c")

