-- Lua provided by RyzenAPI
-- Game: Game: AppID 775900

-- MAIN APPLICATION
addappid(775900)
-- Game: addappid(775900)

-- MAIN APP DEPOTS / PACKAGES
addappid(775901, 1, "8983a9911570dc18887ba94d022837ab093d28f3201c2beb604a80479a44514c")
