-- Lua provided by RyzenAPI
-- Game: MotoGP™18

-- MAIN APPLICATION
addappid(775900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(775901, 1, "8983a9911570dc18887ba94d022837ab093d28f3201c2beb604a80479a44514c")

