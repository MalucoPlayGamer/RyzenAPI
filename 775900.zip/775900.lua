-- Lua provided by SkyAPI 
-- Game: AppID 775900
addappid(775900)
addappid(775901, 1, "8983a9911570dc18887ba94d022837ab093d28f3201c2beb604a80479a44514c")
