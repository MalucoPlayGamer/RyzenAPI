-- Lua provided by RyzenAPI
-- Game: 626700

-- MAIN APPLICATION
addappid(626700)
-- Game: addappid(626700)

-- MAIN APP DEPOTS / PACKAGES
addappid(626701, 1, "4670c4d5bbfebba32f00bd6e38d858376214fe1706f4252ffd1ad73afd9814fc")
