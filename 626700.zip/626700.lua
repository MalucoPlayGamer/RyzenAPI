-- Lua provided by RyzenAPI
-- Game: AppID 626700

-- MAIN APPLICATION
addappid(626700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(626701, 1, "4670c4d5bbfebba32f00bd6e38d858376214fe1706f4252ffd1ad73afd9814fc")

