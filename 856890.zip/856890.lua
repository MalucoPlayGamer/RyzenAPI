-- Lua provided by RyzenAPI
-- Game: Game: JUSTICE SUCKS: Tactical Vacuum Action

-- MAIN APPLICATION
addappid(856890)
-- Game: addappid(856890)

-- MAIN APP DEPOTS / PACKAGES
addappid(856891, 1, "255a38e3e742499a0e973be0b6cbde54cf7340ff6669fdc0112d3c0d1ae033e7")
