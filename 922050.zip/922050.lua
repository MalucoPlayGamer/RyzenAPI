-- Lua provided by SkyAPI 
-- Game: DOOMBLADE
addappid(922050)
addappid(922051, 1, "370a610d88ce541ed20e4c282da7d7cdf3ba5be000757d151d98c00a1ec81506")
