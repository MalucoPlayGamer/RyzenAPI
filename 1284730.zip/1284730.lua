-- Lua provided by RyzenAPI
-- Game: addappid(1284730)

-- MAIN APPLICATION
addappid(1284730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284731, 1, "2ec5f0a44ef78beac59eb3b94d5db7af2e3ed0d7420a48062c93fa2a351e9174")
