-- Lua provided by RyzenAPI
-- Game: Lands of Rumour

-- MAIN APPLICATION
addappid(3359370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359371, 1, "b078ae84f2aaf7782c8db7545ab013a735e480db935fbf4cf325fbbdc4027461")
