-- Lua provided by RyzenAPI 
-- Game: AppID 674170
addappid(674170)
addappid(674171, 1, "9fbbba5bbfc195c890c950f5388dc368caa84bf6bcb7186320539b0745e9b093")
