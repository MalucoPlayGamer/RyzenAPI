-- Lua provided by RyzenAPI
-- Game: Blood of Old - The Rise to Greatness!

-- MAIN APPLICATION
addappid(596440)

-- MAIN APP DEPOTS / PACKAGES
addappid(596441, 1, "363f06533ae17a4ca63fcdeb947229d06aad8b79193cb5c40934c27966fb4999")
