-- Lua provided by RyzenAPI
-- Game: Epic Royal

-- MAIN APPLICATION
addappid(744760)

-- MAIN APP DEPOTS / PACKAGES
addappid(744761, 1, "295da73cfc6ef89d82487bf9fee8e431e33c719369c73ccb192f6c085f5cf5ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
