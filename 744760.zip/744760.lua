-- Lua provided by RyzenAPI
-- Game: addappid(744760)

-- MAIN APPLICATION
addappid(744760)

-- MAIN APP DEPOTS / PACKAGES
addappid(744761, 1, "295da73cfc6ef89d82487bf9fee8e431e33c719369c73ccb192f6c085f5cf5ed")
