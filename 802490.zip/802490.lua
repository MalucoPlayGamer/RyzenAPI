-- Lua provided by RyzenAPI
-- Game: Game: AppID 802490

-- MAIN APPLICATION
addappid(802490)
-- Game: addappid(802490)

-- MAIN APP DEPOTS / PACKAGES
addappid(802491, 1, "e376284175847a317a5536bccd27da0163723997374a3db3354f0dbc16f0f9b2")
