-- Lua provided by RyzenAPI
-- Game: addappid(723110)

-- MAIN APPLICATION
addappid(723110)

-- MAIN APP DEPOTS / PACKAGES
addappid(723111, 1, "e6236c4d5284cdc1d215e7991085698ca5410fefc0541cbf02cfbab643cf7ce2")
