-- Lua provided by RyzenAPI
-- Game: ARK: The Survival Of The Fittest

-- MAIN APPLICATION
addappid(407530)

-- MAIN APP DEPOTS / PACKAGES
addappid(407531, 1, "3b2ecd725e715acbe4f0faece4804881627c6b44756f8ab21b7ea7ef265d8790")
addappid(407532, 1, "7890a0784b70376002ee9a6324fc0316a0708d0885963ea04e19eb8ff39154ec")
addappid(407533, 1, "ff34a171aebbf864adebe441b8a24188fb40b5bd0a62645427132c63ca28803f")
