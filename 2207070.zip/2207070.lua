-- Lua provided by RyzenAPI
-- Game: Game: Social Credit Simulator

-- MAIN APPLICATION
addappid(2207070)
-- Game: addappid(2207070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207071, 1, "b2c265275af2f34aae2954eed0f7b26dd0faefa235ef1889d7b9d8679bdad237")
