-- Lua provided by RyzenAPI
-- Game: AppID 2887520

-- MAIN APPLICATION
addappid(2887520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887521, 1, "10c6f3a58035fc6752df2ce2bb4ec1d2a64e9fc2b0eccde58a750de9db66c71e")
