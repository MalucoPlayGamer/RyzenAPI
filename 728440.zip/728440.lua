-- Lua provided by RyzenAPI
-- Game: 728440

-- MAIN APPLICATION
addappid(728440)
-- Game: addappid(728440)

-- MAIN APP DEPOTS / PACKAGES
addappid(728441, 1, "46395fecc284fdb431925f4c04e8b7bf5c82ac308a3639517d85e30ad5129761")
