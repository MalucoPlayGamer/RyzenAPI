-- Lua provided by RyzenAPI
-- Game: 2013870

-- MAIN APPLICATION
addappid(2013870)
-- Game: addappid(2013870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013871, 1, "70efb837deb899da2b0084398042eb29a8ac07e08f9623309572df5c0c95bcc5")
