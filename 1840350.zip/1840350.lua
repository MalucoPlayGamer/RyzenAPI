-- Lua provided by RyzenAPI
-- Game: Koi-Koi VR: Love Blossoms

-- MAIN APPLICATION
addappid(1840350)
-- Game: addappid(1840350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840351, 1, "1c51caff278201cf8be36f25ccf9b50a9bfa397dcd1d947c151b8782c4fdfb42")
addappid(2340340, 0, "4ef31efb0a7d46b4dc52bf1845518efc2c6e153bf2f5015b22b3b872da6736ad")
