-- Lua provided by RyzenAPI
-- Game: addappid(885120)

-- MAIN APPLICATION
addappid(885120)

-- MAIN APP DEPOTS / PACKAGES
addappid(885121, 1, "28b668f9f7986b72d1ecf1a0c1376b4f49bf6f658bd7d1cb52591337d30625d9")
