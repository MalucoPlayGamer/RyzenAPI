-- Lua provided by SkyAPI 
-- Game: AppID 1166090
addappid(1166090)
addappid(1166091, 1, "e256b024c0977562a8664152f1ad0da8c8f2289e2c755bee064c538f08820106")
