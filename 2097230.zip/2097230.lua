-- Lua provided by RyzenAPI
-- Game: AppID 2097230

-- MAIN APPLICATION
addappid(2097230)
-- Game: addappid(2097230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097231, 1, "f87aa6fbe1030e3378fe224583b38fb0201edfd93cd4204186c4d4df5e9a5041")
