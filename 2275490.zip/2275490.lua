-- Lua provided by RyzenAPI
-- Game: addappid(2275490)

-- MAIN APPLICATION
addappid(2275490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275491, 1, "260adb3353aa7f402ec8be09bf54829d4c1546797b160af43e0f429f5b611ed4")
