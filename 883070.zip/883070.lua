-- Lua provided by RyzenAPI
-- Game: AppID 883070

-- MAIN APPLICATION
addappid(883070)

-- MAIN APP DEPOTS / PACKAGES
addappid(883071, 1, "41460fbf3fa9840a527f5267c19b7ada8faea9f7fbe8401d27999ae2acce0d81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
