-- Lua provided by RyzenAPI
-- Game: AppID 883070

-- MAIN APPLICATION
addappid(883070)
-- Game: addappid(883070)

-- MAIN APP DEPOTS / PACKAGES
addappid(883071, 1, "41460fbf3fa9840a527f5267c19b7ada8faea9f7fbe8401d27999ae2acce0d81")
