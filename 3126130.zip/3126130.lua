-- Lua provided by RyzenAPI
-- Game: Game: The Prisoner in Letter Demo

-- MAIN APPLICATION
addappid(3126130)
-- Game: addappid(3126130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126131, 1, "c7e77581522e2bbf9e9a1bfe791cabb2c4bd8301c0b4e2e7c8d4d9ddfecb81ea")
