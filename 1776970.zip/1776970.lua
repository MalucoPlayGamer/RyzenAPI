-- Lua provided by RyzenAPI
-- Game: 月に寄りそう乙女の作法

-- MAIN APPLICATION
addappid(1776970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1776971, 1, "0a2b747476c0bedeee60afcab26fda9246fd5c694cc9bd7b52a7c191a0ffab17")

