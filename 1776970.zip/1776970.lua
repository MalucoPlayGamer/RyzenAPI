-- Lua provided by RyzenAPI
-- Game: 月に寄りそう乙女の作法

-- MAIN APPLICATION
addappid(1776970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776971, 1, "0a2b747476c0bedeee60afcab26fda9246fd5c694cc9bd7b52a7c191a0ffab17")

