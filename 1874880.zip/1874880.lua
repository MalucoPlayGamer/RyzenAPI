-- Lua provided by RyzenAPI
-- Game: Arma Reforger

-- MAIN APPLICATION
addappid(1874880)
addappid(3923950)
addappid(4631450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1874881, 1, "f1bc308d3a58a8d144a76dc02d552819b433bda49c325060fcab53e8100cead3")
addappid(1874882, 1, "c964efe3e6ee7295beeb474f46e6c78d1f2f62097dc3c793b1474cfab9f2f055")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5146340)
