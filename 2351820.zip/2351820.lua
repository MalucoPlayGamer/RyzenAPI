-- Lua provided by RyzenAPI
-- Game: Stellarace (Demo)

-- MAIN APPLICATION
addappid(2351820)
addappid(3156300)
-- Game: addappid(2351820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351821, 1, "4c203b8337731bf0dc670b73f6075e0fce3bf31efd3072cf869cfd3e65f29e0c")
