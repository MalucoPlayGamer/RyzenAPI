-- Lua provided by RyzenAPI
-- Game: AppID 326840

-- MAIN APPLICATION
addappid(326840)

-- MAIN APP DEPOTS / PACKAGES
addappid(326841, 1, "36d3c00b9107a5c739e474cb7b21ad582c92e68d62b613a7049f444c2b9e56ad")
addappid(326842, 1, "26028f81df736ce99371f812190f18862f5e1a34a0863e564f3f45cc25af5f10")
addappid(326843, 1, "fb92d089832fc871634baa24ffb416a11785e1558cb73131b05f41f21812ef8d")
addappid(326844, 1, "9e728dc71ddb350459b96f7d90587df39a59fd00089c327427874bb568d25c1f")
addappid(469740, 0, "ffe70d47fc1d4c15f243737e5ebad49a3ed2bffd5ba9417381b24736d3606779")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
