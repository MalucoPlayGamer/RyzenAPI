-- Lua provided by RyzenAPI
-- Game: SAW HELL

-- MAIN APPLICATION
addappid(1500860)
-- Game: addappid(1500860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500861, 1, "a7949bf92da52783378a2d8a3de141802a2f5c8eec0f9e9246c4e0b58f3ff464")
