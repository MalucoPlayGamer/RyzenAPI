-- Lua provided by RyzenAPI
-- Game: addappid(3287520)

-- MAIN APPLICATION
addappid(3287520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287521, 1, "d026ecb27a03a6ca26771e7352214eed11c1b9d1553cc0b47aaf6cb6e7f4f371")
