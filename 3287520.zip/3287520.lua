-- Lua provided by SkyAPI 
-- Game: NINJA GAIDEN 2 Black
addappid(3287520)
addappid(3287521, 1, "d026ecb27a03a6ca26771e7352214eed11c1b9d1553cc0b47aaf6cb6e7f4f371")
