-- Lua provided by RyzenAPI
-- Game: 最强祖师

-- MAIN APPLICATION
addappid(2936220)

