-- Lua provided by RyzenAPI
-- Game: RuneSage

-- MAIN APPLICATION
addappid(542030)

-- MAIN APP DEPOTS / PACKAGES
addappid(542031, 1, "140860ea692569fbe4876e3f87765be9d29d922d793c50e81b884db1ce7c8f62")

