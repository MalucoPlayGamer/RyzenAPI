-- Lua provided by RyzenAPI
-- Game: Game: King of the Times

-- MAIN APPLICATION
addappid(2613230)
-- Game: addappid(2613230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613231, 1, "58a2e809fda9738c8f39d475101cf4ee970997dd15363923e619dc84e95649c3")
