-- Lua provided by RyzenAPI 
-- Game: King of the Times
addappid(2613230)
addappid(2613231, 1, "58a2e809fda9738c8f39d475101cf4ee970997dd15363923e619dc84e95649c3")
