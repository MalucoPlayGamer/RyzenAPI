-- Lua provided by RyzenAPI
-- Game: Into the Void

-- MAIN APPLICATION
addappid(420270)

-- MAIN APP DEPOTS / PACKAGES
addappid(420271, 1, "d6493bb0c76dec31d54f5935501691813c4fe7dc80f5c53206624346827d8f32")
addappid(420272, 1, "dd6644837e0025986de786a59b2fd4205485812c02c4adcc25467365bdde4256")
addappid(420273, 1, "6b01729bc545df1ade00c3ac0a3a5c7ddc4c73b6a17c06963411e47b6795d236")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
