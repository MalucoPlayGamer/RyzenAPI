-- Lua provided by SkyAPI 
-- Game: Pocket Harvest
addappid(2019380)
addappid(2019381, 1, "6d7c4c55f80361fb8c471378e6ed4836680afc2cdb2c1035f24a02b12ba517d3")
