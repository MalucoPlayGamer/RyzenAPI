-- Lua provided by RyzenAPI
-- Game: Game: AppID 3043090

-- MAIN APPLICATION
addappid(3043090)
-- Game: addappid(3043090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043091, 1, "e1c785fb19b218e28f8e28a59442fc749e4eb0d7554efe46930c6d80e784a28e")
