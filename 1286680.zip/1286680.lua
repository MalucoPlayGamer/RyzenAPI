-- Lua provided by RyzenAPI
-- Game: Game: Tiny Tina's Wonderlands

-- MAIN APPLICATION
addappid(1286680)
-- Game: addappid(1286680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286681, 1, "9fc3a420ac82d1a5db76b0eb7fb49dcb9beddd0843042254f712b3bec3975496")
addappid(1286682, 1, "e8012a88d38526c88c0319f71dc6361fb9d774bd84985a7f128a2ede140f7bcd")
