-- Lua provided by RyzenAPI
-- Game: Tiny Tina's Wonderlands

-- MAIN APPLICATION
addappid(1286680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286681, 1, "9fc3a420ac82d1a5db76b0eb7fb49dcb9beddd0843042254f712b3bec3975496")
addappid(1286682, 1, "e8012a88d38526c88c0319f71dc6361fb9d774bd84985a7f128a2ede140f7bcd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1621030)
addappid(1621031)
addappid(1621032)
addappid(1622260)
addappid(1769530)
addappid(1769531)
addappid(1769532)
addappid(1769533)
