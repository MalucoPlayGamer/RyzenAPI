-- Lua provided by RyzenAPI
-- Game: Uneasy Memories

-- MAIN APPLICATION
addappid(2907280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907281, 1, "15d366c71035bc12e24091b7ac2e64622e6f7a72d9e9453d92a33d5b3431185e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
