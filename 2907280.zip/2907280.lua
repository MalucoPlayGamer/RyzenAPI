-- Lua provided by RyzenAPI
-- Game: Game: Uneasy Memories

-- MAIN APPLICATION
addappid(2907280)
-- Game: addappid(2907280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907281, 1, "15d366c71035bc12e24091b7ac2e64622e6f7a72d9e9453d92a33d5b3431185e")
