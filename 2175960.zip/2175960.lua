-- Lua provided by RyzenAPI
-- Game: Secret Pie - Festival

-- MAIN APPLICATION
addappid(2175960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175960,0,"d93c7decc5b83a855f8d632f6277f2e2f4c02d7c183ace34c231fdcd0488344a")
