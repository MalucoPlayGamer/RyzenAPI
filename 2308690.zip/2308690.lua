-- Lua provided by RyzenAPI
-- Game: Ground of Aces

-- MAIN APPLICATION
addappid(2308690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308692,0,"6494680e7267af8bbc54b931dd3906812c2cc6523636a5c7c13ac2e6d385588d")
addappid(3851890,0,"f37e53192b9c5ced51dfa8acca5902a03061eae861d24f55cb5c703494496a23")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4359260)
