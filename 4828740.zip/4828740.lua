-- Lua provided by RyzenAPI
-- Game: Cover Story

-- MAIN APPLICATION
addappid(4828740) -- Cover Story

-- MAIN APP DEPOTS / PACKAGES
addappid(4828741, 1, "c4fd2eb8ee88414f7c298b8159ed3fdaa1fa927abc92dc0ca2f2d8e5c41d2a8b") -- Depot 4828741

