-- Lua provided by RyzenAPI
-- Game: Kart Racing Pro

-- MAIN APPLICATION
addappid(415600)

-- MAIN APP DEPOTS / PACKAGES
addappid(415601, 1, "2efedb4253c033ce3fcfc067c74e3175b21e25d3f7ee4ad6f2cf6ad89736598f")
