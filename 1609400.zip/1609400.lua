-- Lua provided by RyzenAPI
-- Game: Mortal Sin Demo

-- MAIN APPLICATION
addappid(1609400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494811,0,"0a511e83da83f4164929f78b0220da9474d343cbf334e814f37b5731de7196be")

