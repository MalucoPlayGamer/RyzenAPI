-- Lua provided by RyzenAPI
-- Game: Gujian3(古剑奇谭三)

-- MAIN APPLICATION
addappid(994280)

-- MAIN APP DEPOTS / PACKAGES
addappid(994283,0,"2b3d3e8e2c964c46ca71c17fb0e3d92b0ba71f18f7d09704c286a35e5982af19")

