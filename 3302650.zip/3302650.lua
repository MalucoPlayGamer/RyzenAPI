-- Lua provided by RyzenAPI
-- Game: Game: Conscience

-- MAIN APPLICATION
addappid(3302650)
-- Game: addappid(3302650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3302651, 1, "80100771e6ec8461325ec90ba9e366275a1693e9597896c666106afe4ba4c1f6")
