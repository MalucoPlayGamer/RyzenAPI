-- Lua provided by RyzenAPI
-- Game: RPG Maker 2000

-- MAIN APPLICATION
addappid(383730)

-- MAIN APP DEPOTS / PACKAGES
addappid(383731, 1, "c3dd66f9a1e0005cd297e1a39dece6464605b4ab2d46d4ce80a4ffe284d14650")
