-- Lua provided by RyzenAPI 
-- Game: AppID 383730
addappid(383730)
addappid(383731, 1, "c3dd66f9a1e0005cd297e1a39dece6464605b4ab2d46d4ce80a4ffe284d14650")
