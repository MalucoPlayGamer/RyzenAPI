-- Lua provided by RyzenAPI
-- Game: 2820110

-- MAIN APPLICATION
addappid(2820110)
-- Game: addappid(2820110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820111, 1, "a681b8c4e68d93e1652a2517c062ca9e034fdd6e2c3eaa754614a3b5609ed8c5")
