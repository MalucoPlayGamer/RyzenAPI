-- Lua provided by RyzenAPI
-- Game: 2932310

-- MAIN APPLICATION
addappid(2932310)
-- Game: addappid(2932310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932311, 1, "eb0d3a7bce13d5d10781fadf40c3e4e6a5f01b9b632c2a62ff743c5ab13bb9c4")
