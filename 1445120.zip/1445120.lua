-- Lua provided by RyzenAPI 
-- Game: Fast Typing Master
addappid(1445120)
addappid(1445121, 1, "99cfdfb33059fb04d662cdf2d5f429a9e567bc4421309afa04bf65246c872e92")
