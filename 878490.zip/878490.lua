-- Lua provided by RyzenAPI
-- Game: Game: AppID 878490

-- MAIN APPLICATION
addappid(878490)
-- Game: addappid(878490)

-- MAIN APP DEPOTS / PACKAGES
addappid(878491, 1, "c52dde7dc9572cedb9f2befb4d9eccd005ec29fc632d94bf96c449a11c0cbb9a")
