-- Lua provided by SkyAPI 
-- Game: Mosaics Galore
addappid(567150)
addappid(567151, 1, "122e85a3ea51f403c3d81d329cf5b6072876a37b80b292879b08eb374994bca4")
addappid(567153, 1, "9f045f4fe51a815a1c5315280531e0361d10688ad4eeb96a53bb0ff812eeac81")
addappid(567154, 1, "8303e876cae7634188d95fec3ad1f4c4aa99c1f13f4f4a9c145b3bc1e34e4598")
