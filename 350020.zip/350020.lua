-- Lua provided by RyzenAPI
-- Game: addappid(350020)

-- MAIN APPLICATION
addappid(350020)
addappid(350021)
addappid(350023)
addappid(350024)

-- MAIN APP DEPOTS / PACKAGES
addappid(350022,0,"894b8379864d5dabb724dd3721b48898972b7bb6fdf7d1c97b0d965852238b0c")
