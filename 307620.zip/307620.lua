-- Lua provided by RyzenAPI
-- Game: Curses 'N Chaos

-- MAIN APPLICATION
addappid(307620)

-- MAIN APP DEPOTS / PACKAGES
addappid(307621, 1, "93eadfdee80330f013d4140a6bf7b1dd536424513ee76479791a90afa1823439")
addappid(307622, 1, "5c3c9cc4badcdedcee4dd757576343b8a426bc4807be92146bd060db82e7c0cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
