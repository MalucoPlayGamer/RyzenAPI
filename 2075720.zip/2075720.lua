-- Lua provided by RyzenAPI
-- Game: Game: 9 Days

-- MAIN APPLICATION
addappid(2075720)
-- Game: addappid(2075720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075721, 1, "6075ff50d6af9b4e3ee0b83bfaa817c49e920604c04e60014156c95331112e8c")
