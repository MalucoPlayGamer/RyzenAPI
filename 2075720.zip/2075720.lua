-- Lua provided by RyzenAPI
-- Game: 9 Days

-- MAIN APPLICATION
addappid(2075720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2075721, 1, "6075ff50d6af9b4e3ee0b83bfaa817c49e920604c04e60014156c95331112e8c")