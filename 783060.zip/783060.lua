-- Lua provided by RyzenAPI
-- Game: AIDEN

-- MAIN APPLICATION
addappid(783060)

-- MAIN APP DEPOTS / PACKAGES
addappid(783061, 1, "4fcf920ebb4f336c10d93d06e84d6ba309ba9f7afe055edd5e16153070791d19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
