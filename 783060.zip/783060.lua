-- Lua provided by RyzenAPI
-- Game: AIDEN

-- MAIN APPLICATION
addappid(783060)
-- Game: addappid(783060)

-- MAIN APP DEPOTS / PACKAGES
addappid(783061, 1, "4fcf920ebb4f336c10d93d06e84d6ba309ba9f7afe055edd5e16153070791d19")
