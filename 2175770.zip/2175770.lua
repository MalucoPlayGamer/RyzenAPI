-- Lua provided by RyzenAPI
-- Game: addappid(2175770)

-- MAIN APPLICATION
addappid(2175770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175771, 1, "99e893261f580f234a7bac2c212389feec6497af930ef7b2b8fc8b85e0d4607f")
