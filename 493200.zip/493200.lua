-- Lua provided by RyzenAPI
-- Game: RiME

-- MAIN APPLICATION
addappid(493200)

-- MAIN APP DEPOTS / PACKAGES
addappid(493201, 1, "3b45bcc29900e56378948679d84042cd452c0fa9d30be16d152f6914cca74c16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
