-- Lua provided by RyzenAPI
-- Game: RiME

-- MAIN APPLICATION
addappid(493200)
-- Game: addappid(493200)

-- MAIN APP DEPOTS / PACKAGES
addappid(493201, 1, "3b45bcc29900e56378948679d84042cd452c0fa9d30be16d152f6914cca74c16")
