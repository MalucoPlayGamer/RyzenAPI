-- Lua provided by SkyAPI 
-- Game: RiME
addappid(493200)
addappid(493201, 1, "3b45bcc29900e56378948679d84042cd452c0fa9d30be16d152f6914cca74c16")
