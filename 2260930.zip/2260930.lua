-- Lua provided by RyzenAPI
-- Game: Kill Pill

-- MAIN APPLICATION
addappid(2260930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260931, 1, "aeb0e7abc088719eaf1b02135bb3e906558aa9789c84c3f414931b762db6f87e")
