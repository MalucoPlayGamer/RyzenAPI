-- Lua provided by RyzenAPI 
-- Game: Kill Pill
addappid(2260930)
addappid(2260931, 1, "aeb0e7abc088719eaf1b02135bb3e906558aa9789c84c3f414931b762db6f87e")
