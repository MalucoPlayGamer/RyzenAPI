-- Lua provided by RyzenAPI
-- Game: Mozart Requiem

-- MAIN APPLICATION
addappid(2116930)
-- Game: addappid(2116930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116931, 1, "201ed3e8d3b3483d557f126a62ee482382e4237941e6c97bacd111e6a977df0b")
