-- Lua provided by RyzenAPI
-- Game: Game: Echoes of Dread

-- MAIN APPLICATION
addappid(3015350)
-- Game: addappid(3015350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015351, 1, "1896d3386c55b924b02b458f571daa983260b59e3a4f556a661b8f84cd710e22")
