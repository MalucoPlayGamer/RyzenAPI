-- Lua provided by RyzenAPI 
-- Game: Echoes of Dread
addappid(3015350)
addappid(3015351, 1, "1896d3386c55b924b02b458f571daa983260b59e3a4f556a661b8f84cd710e22")
