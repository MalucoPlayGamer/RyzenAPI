-- Lua provided by RyzenAPI
-- Game: Game: Hot Springs Story

-- MAIN APPLICATION
addappid(1823710)
-- Game: addappid(1823710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823711, 1, "42c508b88cbe4d52e8aaf5ba364a512b55d8722188741a9d5769c299fb5c0840")
