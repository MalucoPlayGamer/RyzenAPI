-- Lua provided by RyzenAPI
-- Game: Game: The White Laboratory

-- MAIN APPLICATION
addappid(235520)
-- Game: addappid(235520)

-- MAIN APP DEPOTS / PACKAGES
addappid(235521, 1, "28e6876ca5679df8679bf1e92952638c43f60c3c512363f62a2baba60e71aeeb")
