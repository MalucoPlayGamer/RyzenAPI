-- Lua provided by RyzenAPI
-- Game: addappid(209771)

-- MAIN APPLICATION
addappid(209771)

-- MAIN APP DEPOTS / PACKAGES
addappid(209771,0,"04a3f5c534c76fe3bf20ddea074cc28a7796ae9b7ca3fba5bc0eeee8da7c8e20")
