-- Lua provided by RyzenAPI
-- Game: AppID 1262580

-- MAIN APPLICATION
addappid(1262580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262581, 1, "bc329d84c6374c986032b34aef38842598bcc144dada9d99208b5d435950bcb2")
addappid(1262582, 1, "d944730a0e8c04a08204140dad83af1b5fca609f02dcbea733e17084e4127541")
addappid(1262583, 1, "b3d27fd471f00e9c5d6ade77d8beff63126e810eb62c7dfe8df91a12cabf63f1")
addappid(1262584, 1, "f015179710bded315ad9db719d9b33cb2fe5502df5be951452422a5eee4505ce")
addappid(1262585, 1, "ee745b0c2aa66285f5639bf257523e871c90adc72c580e10c173da6572ceb2ae")
addappid(1262586, 1, "06bfc2f9d256fc4cc670dd0f2b4737c6ccef2dbc9c19fa18757b7a9670e500d7")
addappid(1262587, 1, "ecf19cfeb5cb8d9c6e5247568fd491570ebb7012dab96bfeeb70105143ec4f77")
addappid(1262588, 1, "7ba879daae75903a3f0f43be34e7460ba6f9f0c02b1c6216ea728f16699847e6")
addappid(1262589, 1, "96f9233b209291966cc85d5f05c318a54d09220daf68594b45255d99f989af73")
addappid(1262593, 1, "32217cc93c93905daacce6e78cc377791cff5097f5770f41c6fd5f062466ea1c")
addappid(1262594, 1, "acc117a10ae6835a786d131a23d4499992e594856965f28817dc8f0281a38db7")
addappid(1262595, 1, "2d59fa0b555dc9b121b943daf5294b65ff625b94e596442d6ee92705033750d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1262590)
addappid(1262591)
addappid(1262592)
addappid(1286900)
addappid(1286902)
addappid(1286903)
addappid(1286904)
addappid(1286905)
addappid(1286912)
addappid(1286913)
addappid(1286914)
addappid(1286915)
addappid(1286916)
addappid(1328030)
addappid(1328031)
addappid(1328032)
