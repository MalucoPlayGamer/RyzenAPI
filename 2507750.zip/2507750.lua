-- Lua provided by RyzenAPI
-- Game: Game: Poly Jigsaw: Furries 2

-- MAIN APPLICATION
addappid(2507750)
-- Game: addappid(2507750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507751, 1, "2c4ee8e6445282579e6ca9ad7b0d9dc138cedd737653b75ff758ddb1ca141978")
