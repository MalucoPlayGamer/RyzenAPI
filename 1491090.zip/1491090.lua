-- Lua provided by RyzenAPI
-- Game: Game: Downslope

-- MAIN APPLICATION
addappid(1491090)
-- Game: addappid(1491090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491091, 1, "ff20f2aeaa4457485562aa4d7ccb23ef6ef1fab11fc2ce88184d7243a061d0bb")
