-- Lua provided by RyzenAPI
-- Game: Missing Plane: Survival

-- MAIN APPLICATION
addappid(1855920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855921, 1, "4ff0aef393b1edbeeb4cceb3b7a247318718ad792f2cdbeb02cd48837358a90e")

