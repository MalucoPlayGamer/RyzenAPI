-- Lua provided by RyzenAPI
-- Game: Rivals of Aether

-- MAIN APPLICATION
addappid(383980)
addappid(444300)
addappid(451270)
addappid(456600)
addappid(470690)
addappid(470691)
addappid(475000)
addappid(539240)
addappid(608090)
addappid(630663)
addappid(670840)
addappid(686220)
addappid(730770)
addappid(787910)
addappid(813050)
addappid(915090)
addappid(930660)
addappid(941241)
addappid(1030270)
addappid(1035230)
addappid(1055580)
addappid(3000620)
addappid(3000630)
addappid(3000640)
addappid(3000650)
addappid(3000660)
addappid(3000670)
addappid(3000680)
addappid(3000690)
addappid(3000700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(383981, 1, "87e2ac2f9745bbb0e0696dc902d1acf156f859f20a508f91a5cea12095a16519")

