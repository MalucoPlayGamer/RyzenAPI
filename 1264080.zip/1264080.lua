-- Lua provided by RyzenAPI
-- Game: Breaking Blocks

-- MAIN APPLICATION
addappid(1264080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264081, 1, "3e65e9f9fafdb708e0542d286edbe1dfe9a1ea676f15c43c9c472818a2dc17c9")

