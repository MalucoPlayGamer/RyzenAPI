-- Lua provided by RyzenAPI
-- Game: addappid(1493340)

-- MAIN APPLICATION
addappid(1493340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493341, 1, "52e32f93bf4d86ea41a4193d4b1479baf99a20c5c2d2fd8d5ff5590c5970a8c3")
