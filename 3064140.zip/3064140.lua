-- Lua provided by RyzenAPI
-- Game: Thou Shalt Not Kill

-- MAIN APPLICATION
addappid(3064140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064141, 1, "87d878dd7eb60430db4474fdd18249d2c31f624c8def9b7af28829d95b639c70")

