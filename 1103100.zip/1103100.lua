-- Lua provided by RyzenAPI
-- Game: Game: AppID 1103100

-- MAIN APPLICATION
addappid(1103100)
-- Game: addappid(1103100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103101, 1, "d2713baa30c8f84cb69bb024359afffaf2a78b62b35e04ed27b3954909def0fd")
