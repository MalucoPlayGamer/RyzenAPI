-- Lua provided by RyzenAPI
-- Game: AppID 1218790

-- MAIN APPLICATION
addappid(1218790)
-- Game: addappid(1218790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218791, 1, "fce2ed30979c75ef4a6b80e7ae406d04027901c165c56b76978bffdf70cc2241")
