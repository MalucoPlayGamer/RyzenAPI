-- Lua provided by RyzenAPI
-- Game: Game of Thrones: Kingsroad - Standard Pack

-- MAIN APPLICATION
addappid(3477690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477690,0,"09ad1044265abc607d130258e11d192531c0471b4755edbe711911048d6bd94f")

