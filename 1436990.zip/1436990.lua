-- Lua provided by RyzenAPI
-- Game: Feign

-- MAIN APPLICATION
addappid(1436990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436991, 1, "6565aea4417dd0ea5c0ef0e7cfedae34723da97dfbb9656f34f27cfb73fe2af8")
addappid(1436992, 1, "c046e9e4bf5e86095f1f6d88924da4870357b892cc0711428eb31d57850afd23")
addappid(1436993, 1, "3680620184ee4df7dc49e48da6a0010221342c24be3a074d06e92c51151398bf")
addappid(1436995, 1, "c45e76af7498de2a0b485e3552502e511b203d66255fa1cdbff1d0542a0b2c0a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3606320)
addappid(3666380)
