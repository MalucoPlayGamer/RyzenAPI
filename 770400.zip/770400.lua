-- Lua provided by SkyAPI 
-- Game: Fairy of the treasures
addappid(770400)
addappid(770401, 1, "78980056981f05a60956d6716402f8d6941b3762dc4b8bb564eef13db67bf84c")
