-- Lua provided by RyzenAPI
-- Game: Fairy of the treasures

-- MAIN APPLICATION
addappid(770400)
-- Game: addappid(770400)

-- MAIN APP DEPOTS / PACKAGES
addappid(770401, 1, "78980056981f05a60956d6716402f8d6941b3762dc4b8bb564eef13db67bf84c")
