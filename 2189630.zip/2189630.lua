-- Lua provided by RyzenAPI
-- Game: addappid(2189630)

-- MAIN APPLICATION
addappid(2189630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189631, 1, "2298df1c0d4268a8c24a87f2b340830c7faeb6fd2cc4259b8a5f0253411841c4")
