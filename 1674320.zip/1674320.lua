-- Lua provided by RyzenAPI
-- Game: Gran Premio

-- MAIN APPLICATION
addappid(1674320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674322,0,"5a58fa939af086590074af900e96cfaa68343f56670b81d8255c5ce522c905f5")

