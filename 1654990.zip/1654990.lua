-- Lua provided by RyzenAPI
-- Game: Spies & Soldiers Demo

-- MAIN APPLICATION
addappid(1654990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654991, 1, "a59d6827b875f270588876789b8a37d7522e6cd4c71f5c4923aee034573cf1fa")
