-- Lua provided by RyzenAPI
-- Game: Project RTD: Random Tower Defense VR

-- MAIN APPLICATION
addappid(1286370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286371, 1, "f0ad563475d0a167b984304c86438eae566c83f3cf9324993880154c1318c034")

