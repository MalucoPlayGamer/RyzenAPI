-- Lua provided by RyzenAPI
-- Game: 1041780

-- MAIN APPLICATION
addappid(1041780)
-- Game: addappid(1041780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041781, 1, "1c81f92500ae5f8d063da5b5cca5be3d4ab34b2da607c0f9462af1755bf45b60")
