-- Lua provided by RyzenAPI
-- Game: Soul Valley

-- MAIN APPLICATION
addappid(1041780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041781, 1, "1c81f92500ae5f8d063da5b5cca5be3d4ab34b2da607c0f9462af1755bf45b60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
