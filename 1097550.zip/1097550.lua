-- Lua provided by RyzenAPI 
-- Game: 王国幻境 fantastic kingdom
addappid(1097550)
addappid(1097551, 1, "e144e4181c8a6c50e2fd5e7758fd795916790ade34c7ff19331bac3286deb6e3")
addappid(1097552, 1, "c5e5cb573942a27d047de9a3f1e874e9de585be08f4902c6ffe0a1caa8736581")
addappid(1097553, 1, "4b08c249981597512baf0b9f310bd3c60d7ddabf6babfaadd9581ad591aa1514")
