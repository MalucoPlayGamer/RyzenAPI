-- Lua provided by RyzenAPI
-- Game: 695830

-- MAIN APPLICATION
addappid(695830)
-- Game: addappid(695830)

-- MAIN APP DEPOTS / PACKAGES
addappid(695831, 1, "e19b4da8eaaafcb6868203e81590e47adc2518aa97114c6e22e87920f3277513")
