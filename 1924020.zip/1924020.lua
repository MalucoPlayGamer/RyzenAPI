-- Lua provided by RyzenAPI
-- Game: AppID 1924020

-- MAIN APPLICATION
addappid(1924020)
-- Game: addappid(1924020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924021, 1, "1342564a5aaf4615f9b233ee4c479a87c41a29752712db1270e1cdee6f2034f5")
