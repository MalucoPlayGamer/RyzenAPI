-- Lua provided by RyzenAPI
-- Game: addappid(516700)

-- MAIN APPLICATION
addappid(516700)

-- MAIN APP DEPOTS / PACKAGES
addappid(516701, 1, "2143776d3977e71a37eb89fa5c953da2570ffed82dd5c47dab588907efbe0e6c")
