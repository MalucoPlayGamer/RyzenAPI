-- Lua provided by RyzenAPI
-- Game: 1363680

-- MAIN APPLICATION
addappid(1363680)
-- Game: addappid(1363680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363681, 1, "dc3b98d7ac23cb198cd0cc624544d92a060267bda6df99ce85bdc774251314ea")
