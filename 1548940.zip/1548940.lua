-- Lua provided by RyzenAPI
-- Game: RUN: The world in-between

-- MAIN APPLICATION
addappid(1548940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548941, 1, "031e275e51600bbf031f560596f659601439f2974eb5d70654de87527bc29ade")

