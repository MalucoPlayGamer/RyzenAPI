-- Lua provided by RyzenAPI
-- Game: addappid(1226540)

-- MAIN APPLICATION
addappid(1226540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226541, 1, "22df1768aafb01f4d142f63623baddb5f7b112ab18c743007f10f67b9bde3a57")
