-- Lua provided by RyzenAPI
-- Game: SwingStar VR

-- MAIN APPLICATION
addappid(476430)

-- MAIN APP DEPOTS / PACKAGES
addappid(476431, 1, "f2b203d504a649f011e04f8c647c5811e30b499dc20ee75972e58a68005caa67")
