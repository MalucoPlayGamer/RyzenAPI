-- Lua provided by RyzenAPI 
-- Game: AppID 406760
addappid(406760)
addappid(406761, 1, "4f8c42e06f551b7de8ca7a440bffe2f9d6ab7208f4c8f9d74a0e3fba5dd63731")
