-- Lua provided by RyzenAPI
-- Game: 1313350

-- MAIN APPLICATION
addappid(1313350)
-- Game: addappid(1313350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313351, 1, "e6b02daadda278dbec8f7216411e832a9616997cb10aa7e45755415accec9d95")
