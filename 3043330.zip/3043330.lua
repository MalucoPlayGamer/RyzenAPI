-- Lua provided by RyzenAPI
-- Game: 100 Hiddensaurs

-- MAIN APPLICATION
addappid(3043330)
