-- Lua provided by RyzenAPI
-- Game: 100 Hiddensaurs

-- MAIN APPLICATION
addappid(3043330)
addappid(3118080)
addappid(3254740)
addappid(3407350)
addappid(3702480)
addappid(3854240)
addappid(3924450)

