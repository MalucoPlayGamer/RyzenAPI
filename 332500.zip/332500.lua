-- Lua provided by RyzenAPI
-- Game: addappid(332500)

-- MAIN APPLICATION
addappid(332500)

-- MAIN APP DEPOTS / PACKAGES
addappid(332501, 1, "caa20c300a8597f958fbbb68994a489bdffd1092abaa4e71ab6ad6cc91cad3aa")
