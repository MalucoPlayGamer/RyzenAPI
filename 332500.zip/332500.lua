-- Lua provided by RyzenAPI
-- Game: AppID 332500

-- MAIN APPLICATION
addappid(332500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(332501, 1, "caa20c300a8597f958fbbb68994a489bdffd1092abaa4e71ab6ad6cc91cad3aa")

