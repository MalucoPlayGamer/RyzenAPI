-- Lua provided by RyzenAPI
-- Game: RIDE 5

-- MAIN APPLICATION
addappid(1650010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650011, 1, "aeb35777de6823dd579753720a7ef2d1e1e4908fb2136a76d3325da51f7b3e0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2315150)
addappid(2315160)
addappid(2315170)
addappid(2315180)
addappid(2315190)
addappid(2315200)
addappid(2315210)
addappid(2315220)
addappid(2315230)
addappid(2315240)
addappid(2315250)
addappid(2315260)
addappid(2315270)
addappid(2315290)
addappid(2315300)
addappid(2315310)
addappid(2331010)
