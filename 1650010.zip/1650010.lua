-- Lua provided by RyzenAPI 
-- Game: RIDE 5
addappid(1650010)
addappid(1650011, 1, "aeb35777de6823dd579753720a7ef2d1e1e4908fb2136a76d3325da51f7b3e0a")
