-- Lua provided by RyzenAPI
-- Game: 100 Korea Cats

-- MAIN APPLICATION
addappid(2932930)
addappid(2937140)
addappid(2937150)

