-- Lua provided by RyzenAPI
-- Game: 100 Korea Cats

-- MAIN APPLICATION
addappid(2932930)

