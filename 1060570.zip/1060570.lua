-- Lua provided by RyzenAPI
-- Game: addappid(1060570)

-- MAIN APPLICATION
addappid(1060570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060571, 1, "b8c57faceb3f807fb7ea52026184abb5920963097bcf2e98ebc7261be45229c0")
