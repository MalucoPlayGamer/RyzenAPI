-- Lua provided by RyzenAPI
-- Game: The Renovator: Origins Demo

-- MAIN APPLICATION
addappid(2300050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300051, 1, "00e4e053e579dd96128dd23c0b825a74c0ea93c4646a40d959efdd9dec4c2b43")
