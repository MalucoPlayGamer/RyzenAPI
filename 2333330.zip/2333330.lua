-- Lua provided by RyzenAPI 
-- Game: bing chilling
addappid(2333330)
addappid(2333331, 1, "06d95db591f058039ca04e4b4ec9039b0fbf8c7cafa46ced52e52e650393f53c")
