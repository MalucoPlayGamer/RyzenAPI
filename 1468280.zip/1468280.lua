-- Lua provided by RyzenAPI
-- Game: Game: Inland

-- MAIN APPLICATION
addappid(1468280)
-- Game: addappid(1468280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468281, 1, "526b6ff97a26ff733f8f85d007d59ccddf6e4cc5fe19ba0b47b719f7cc479fca")
