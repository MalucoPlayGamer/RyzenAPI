-- Lua provided by SkyAPI 
-- Game: Inland
addappid(1468280)
addappid(1468281, 1, "526b6ff97a26ff733f8f85d007d59ccddf6e4cc5fe19ba0b47b719f7cc479fca")
