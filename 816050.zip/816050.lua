-- Lua provided by RyzenAPI
-- Game: 816050

-- MAIN APPLICATION
addappid(816050)
-- Game: addappid(816050)

-- MAIN APP DEPOTS / PACKAGES
addappid(816051, 1, "74a3fbba465773aface4ddd270bd0c4131257ead904baf803e7fc8f463a205e0")
