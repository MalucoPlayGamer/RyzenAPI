-- Lua provided by RyzenAPI
-- Game: Kawaii Hentai Girls 2

-- MAIN APPLICATION
addappid(2009800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009801, 1, "f2043869710ee33d9a83cfd1bbce503d8fb0d4caee56227075675f7577e17700")

