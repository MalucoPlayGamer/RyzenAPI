-- Lua provided by RyzenAPI
-- Game: AppID 3182000

-- MAIN APPLICATION
addappid(3182000)
-- Game: addappid(3182000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182001, 1, "0205e8907d676cafd5ef4305da66ae985c40edf911c4ce180c9d8a5f76290dfa")
