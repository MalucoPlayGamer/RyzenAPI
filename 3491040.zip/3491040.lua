-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3491040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491040,0,"4012a373903ec3073fecd37b606389a87f62e38b56f68a1c2bd56591d5299d2c")
