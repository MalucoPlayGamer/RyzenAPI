-- Lua provided by RyzenAPI
-- Game: Game: Hentai Neko Mosaic!

-- MAIN APPLICATION
addappid(1804340)
-- Game: addappid(1804340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804341, 1, "c73491804a1feb68d3ea51f992ecece710a7bc5b374aed383363670de2a21577")
