-- Lua provided by RyzenAPI
-- Game: Robo's World: The Zarnok Fortress

-- MAIN APPLICATION
addappid(436360)

-- MAIN APP DEPOTS / PACKAGES
addappid(436361, 1, "31c92a91c4b0d1cceabe4f40ef0ab98787604bbe52bca419a3bef37b0ae6a981")
addappid(436362, 1, "f6e3a8eba26ba8d9b7d351469502f25d3284508f767bfa9899d460ff493e76d7")
addappid(436363, 1, "368e54342193b9e7ddb15c14ef4defa162fb35311bed924e712848d02b03c4b9")
