-- Lua provided by RyzenAPI
-- Game: addappid(2218680)

-- MAIN APPLICATION
addappid(2218680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218681, 1, "92f913ec6869f91beaa03a4d4f49a65c3ecee0bddfe23987a23e9699de0e4926")
