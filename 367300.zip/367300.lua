-- Lua provided by SkyAPI 
-- Game: Pixel Star
addappid(367300)
addappid(367301, 1, "5e0f2b3ee3f3d3fbb93ff4ab9d1445b6e5d418b368e24dc1b2038c220389bb09")
