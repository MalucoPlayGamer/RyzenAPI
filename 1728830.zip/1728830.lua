-- Lua provided by SkyAPI 
-- Game: AppID 1728830
addappid(1728830)
addappid(1728831, 1, "7ae7430baf7c75926ba53499cf301c6d6e406580710aeb657647fb808529b7f2")
