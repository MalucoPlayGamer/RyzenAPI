-- Lua provided by RyzenAPI
-- Game: addappid(306760)

-- MAIN APPLICATION
addappid(306760)

-- MAIN APP DEPOTS / PACKAGES
addappid(306761, 1, "b95756c624d0ee61bc3a4d63c8bc3beb379918f07f0aa14658a84915fb6649a8")
