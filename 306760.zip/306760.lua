-- Lua provided by RyzenAPI
-- Game: Obduction

-- MAIN APPLICATION
addappid(306760)
addappid(520870)
addappid(520871)
addappid(520872)
addappid(520873)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(306761, 1, "b95756c624d0ee61bc3a4d63c8bc3beb379918f07f0aa14658a84915fb6649a8")

