-- Lua provided by RyzenAPI
-- Game: addappid(1062550)

-- MAIN APPLICATION
addappid(1062550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062551, 1, "bd98da64950b6f983bb4f1bff6bf039b62c87b835b40b7aa3bcba2f8438c75a1")
