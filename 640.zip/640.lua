-- Lua provided by RyzenAPI
-- Game: 640

-- MAIN APPLICATION
addappid(640)
-- Game: addappid(640)

-- MAIN APP DEPOTS / PACKAGES
addappid(641, 1, "ced693848789c9f10e924187809adad866b1cd615925603700b0ab728a8d7378")
