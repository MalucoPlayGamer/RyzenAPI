-- Lua provided by SkyAPI 
-- Game: AppID 640
addappid(640)
addappid(641, 1, "ced693848789c9f10e924187809adad866b1cd615925603700b0ab728a8d7378")
