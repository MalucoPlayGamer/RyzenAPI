-- Lua provided by RyzenAPI
-- Game: Game: Morning Never Comes

-- MAIN APPLICATION
addappid(829260)
-- Game: addappid(829260)

-- MAIN APP DEPOTS / PACKAGES
addappid(829261, 1, "39026588bf76476132747708c67b23111a081db33e92a0c19b8345de782ee88a")
