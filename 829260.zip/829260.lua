-- Lua provided by RyzenAPI 
-- Game: Morning Never Comes
addappid(829260)
addappid(829261, 1, "39026588bf76476132747708c67b23111a081db33e92a0c19b8345de782ee88a")
