-- Lua provided by RyzenAPI
-- Game: 3072130

-- MAIN APPLICATION
addappid(3072130)
-- Game: addappid(3072130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072131, 1, "9aad255b548e8077835eb7cdf2fa7cd061809a9f5ac9a5351da31b17faffa41c")
