-- Lua provided by RyzenAPI
-- Game: Dark Fantasy 2: Jigsaw Puzzle

-- MAIN APPLICATION
addappid(1071330)
addappid(1079710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071331, 1, "dee23d20a3fbfdc76817a93a2458bdd842f37839eec75587af0cbbb07b47ddfd")

