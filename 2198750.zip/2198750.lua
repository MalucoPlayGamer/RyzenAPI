-- Lua provided by RyzenAPI
-- Game: addappid(2198750)

-- MAIN APPLICATION
addappid(2198750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198751, 1, "8409aa3aeb3750bf5ec6e97b1e058c5cf4f42c914adceb0e0c02418e4a436be3")
