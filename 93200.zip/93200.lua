-- Lua provided by RyzenAPI
-- Game: Revenge of the Titans

-- MAIN APPLICATION
addappid(93200)

-- MAIN APP DEPOTS / PACKAGES
addappid(93201, 1, "2ad455cea96bccf4d4451a44f31b89b1aa4e7d4fdfa9ed72c80df07993e6eed7")
addappid(93203, 1, "7b1a8c6440b461edb92071efd418d9df091ceeabc72de456991f82780e4d0a40")
addappid(93204, 1, "75cac728bbe7c88929ea20db09404c72eb5ab0feb7fffef443ff2975dd10e58a")
addappid(93205, 1, "9ff4e6c87e231361e4cd207832a43f9a37fecfb1fafe752a735080dc84eed051")
addappid(93206, 1, "69f023102cb201cb119035085d406045677abdf8e900eb4b6c0bfa72c4f24ddc")
addappid(93207, 1, "2dcf21f2fd45cc07e127058f10de7a1ea8d33fc5622a1016d84b7ee00692689d")
addappid(93208, 1, "a680ddf615322edbde193dfd5ea08736474bd250a9f6f4b8b1c1b6c8db696c2c")
addappid(93209, 1, "4001c19fcd3d8c9d9c944c4a5434e3f7e5c95f4d6694d41264ea91851eb9fb64")

