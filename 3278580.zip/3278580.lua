-- Lua provided by RyzenAPI
-- Game: Kimi to Kanojo no LILYVAGANZA Demo

-- MAIN APPLICATION
addappid(3278580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278582,0,"4e54c0ccf9480fbe9ded94d916f24e13b9c43a73e44928e1175fb42c8d0c69e4")

