-- Lua provided by RyzenAPI
-- Game: addappid(3789840)

-- MAIN APPLICATION
addappid(3789840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3789841, 1, "1bc3219e265b332b6ceb42f28887333e709b6a4d5ae2da22f8fb6b92ac4c9fb5")
