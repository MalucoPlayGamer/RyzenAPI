-- Lua provided by RyzenAPI
-- Game: Game: Cooking Companions

-- MAIN APPLICATION
addappid(1263230)
-- Game: addappid(1263230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263231, 1, "4d9a1f56e9c746ad4f279ea580ca2455c097c66bbabe1a4a4ee26d6023f4ab4d")
addappid(1263232, 1, "b05950c0bd7744e895e335788604940b06db14bef8d96f0b35bc2e8334095352")
