-- Lua provided by RyzenAPI
-- Game: AppID 546430

-- MAIN APPLICATION
addappid(546430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(546431, 1, "397461bc1da197ece17435d52660a0d2ffd6369b0f50fccc5cbe30263b3d3e28")
addappid(546432, 1, "393cf1805124af882cd8ad906d097a39de85a0a9004e36554726f2baad80fa66")
addappid(546433, 1, "d1f9ca635aa69148bb621ba502f0779364adbc4bd548839adc09f373a91128a8")

