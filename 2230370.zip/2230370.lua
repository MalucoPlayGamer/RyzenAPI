-- Lua provided by RyzenAPI 
-- Game: TOUHOU RHAPSODY OF MOON RABBIT
addappid(2230370)
addappid(2230371, 1, "c826503561298ded4b2786bf09a79c8bddd4f7b65835feea58922b7f165d34e1")
