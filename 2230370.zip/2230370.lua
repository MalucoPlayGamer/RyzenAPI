-- Lua provided by RyzenAPI
-- Game: 2230370

-- MAIN APPLICATION
addappid(2230370)
-- Game: addappid(2230370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230371, 1, "c826503561298ded4b2786bf09a79c8bddd4f7b65835feea58922b7f165d34e1")
