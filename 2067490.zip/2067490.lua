-- Lua provided by RyzenAPI
-- Game: Competitive Checkers

-- MAIN APPLICATION
addappid(2067490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067493,0,"a895e4b1f5810bd2c8a0e00ba3174ae86d66b79992739b414afd047e4854c495")

