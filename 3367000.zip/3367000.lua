-- Lua provided by RyzenAPI
-- Game: Threads of Karma

-- MAIN APPLICATION
addappid(3367000)
addappid(3595950)
-- Game: addappid(3367000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367001, 1, "06ac6bab274ed940cb42836a779c5064d1786c6c9e9b42480fae149b0b7f869f")
