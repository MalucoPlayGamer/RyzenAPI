-- Lua provided by RyzenAPI
-- Game: GINKA

-- MAIN APPLICATION
addappid(2536840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2536841, 1, "9b3b47192b004e86cd514d61f138b8c45ce8f6cd0008406d4011dbb6f4a84e59")
addappid(2536842, 1, "6f83c22b4b5e9d0c07fbc00625fc5285bd9046017f2dbdffce4e6e6604269328")

