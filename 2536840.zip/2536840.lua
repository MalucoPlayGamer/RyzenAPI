-- Lua provided by RyzenAPI
-- Game: Game: GINKA

-- MAIN APPLICATION
addappid(2536840)
-- Game: addappid(2536840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536841, 1, "9b3b47192b004e86cd514d61f138b8c45ce8f6cd0008406d4011dbb6f4a84e59")
addappid(2536842, 1, "6f83c22b4b5e9d0c07fbc00625fc5285bd9046017f2dbdffce4e6e6604269328")
