-- Lua provided by RyzenAPI
-- Game: Stick Nightmare

-- MAIN APPLICATION
addappid(652610)
addappid(652611)
-- Game: addappid(652610)

-- MAIN APP DEPOTS / PACKAGES
addappid(652612,0,"15647fffeecbc14f161a9aedd4956b9c4e8b641426a282ffe84b80159567d40b")
addappid(652613,0,"ee7446b0354f5c5a3ba7846dffe544dcd0396a58851074a961a9977ecb5e6811")
addappid(652614,0,"64f2ab3e7ff68cecd912f14ac8e37118556888c574ae75afb6dde069d46ad9dc")
addappid(652615,0,"ac6d463971a541cfa7e8943d6e85827849b88e1bb80573d6b650f3657b467efb")
