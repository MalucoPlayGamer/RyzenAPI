-- Lua provided by RyzenAPI
-- Game: Game: Speebot

-- MAIN APPLICATION
addappid(731320)
-- Game: addappid(731320)

-- MAIN APP DEPOTS / PACKAGES
addappid(731321, 1, "c0546dfb6e33ca41023ac0d621a860365a88fe97e4949f9193a1e4708eaf570c")
