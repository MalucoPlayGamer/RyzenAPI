-- Lua provided by RyzenAPI 
-- Game: FlatOut 2
addappid(2990)
addappid(2991, 1, "ebc1c581ed6f3512f5d38470932b847fe4b9610ae058dbcf95de0a30cb63031c")
addappid(2992, 1, "ef9ad105bc0b0ad8950a973b3d633fd03c16e233c8bdbf1db7d867bd044ed333")
addappid(2993, 1, "063b8a9748e1ca4502cfd74d0af57d70d3cdb610ecb2b7ed93eaaf5b0344bc1d")
addappid(2994, 1, "91ad7cf3a2255a1d504de768953b9078ab1edf910c55b8f61049621bca2b56ed")
addappid(2995, 1, "f4bd26c3dc0057efbe8787ed48ce30b27e6270770a6ac154b98c352f14308b98")
