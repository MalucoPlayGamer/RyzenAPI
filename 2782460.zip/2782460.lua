-- Lua provided by SkyAPI 
-- Game: Tale of the Seas
addappid(2782460)
addappid(2782461, 1, "ec5abb7d9dfb39ae204bf1aa1a2cc91b0b42182ae39be24298679f8f38ed5745")
