-- Lua provided by RyzenAPI
-- Game: Game: Tale of the Seas

-- MAIN APPLICATION
addappid(2782460)
-- Game: addappid(2782460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782461, 1, "ec5abb7d9dfb39ae204bf1aa1a2cc91b0b42182ae39be24298679f8f38ed5745")
