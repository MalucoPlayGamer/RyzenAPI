-- Lua provided by RyzenAPI
-- Game: Astral Ascent (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2455290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455291, 1, "a4ef3df42d2b8c4b911bb7717d0bff14941a1895449b614f62afe02759a964ae")
addappid(2455292, 1, "86b14333ed98e70d9a628ae5adf8b432247c13252085ad35dc7eee13832483f4")

