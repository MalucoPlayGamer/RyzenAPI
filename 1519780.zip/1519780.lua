-- Lua provided by RyzenAPI
-- Game: Citor3 Santa's Elf VR Adult XXX Game

-- MAIN APPLICATION
addappid(1519780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519781, 1, "84b06bd3baede41fdcb527abc40e5a745d86b39c42a1f24b36fcb0f9475e7d5a")

