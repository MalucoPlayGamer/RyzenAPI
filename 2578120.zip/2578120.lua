-- Lua provided by RyzenAPI
-- Game: addappid(2578120)

-- MAIN APPLICATION
addappid(2578120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578121, 1, "25cb22a2c1dbcb507ef5fd330dfec7558058c0daeb1263ca3e2c8bec85480333")
