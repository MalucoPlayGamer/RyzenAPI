-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1725503)
-- Game: addappid(1725503)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725503,0,"829c870940e9e2a61d27a9e1ae4edf894adb8314a7a5007e286af1611f7c1b1c")
