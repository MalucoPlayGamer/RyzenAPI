-- Lua provided by RyzenAPI
-- Game: EXOME

-- MAIN APPLICATION
addappid(1761900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761901, 1, "17ec3b9151ef23edec5f4c7fb10f689944aa5e5418363eeb78ccda7d5ab0ba3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
