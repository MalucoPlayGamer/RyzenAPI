-- Lua provided by RyzenAPI
-- Game: Game: EXOME

-- MAIN APPLICATION
addappid(1761900)
-- Game: addappid(1761900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761901, 1, "17ec3b9151ef23edec5f4c7fb10f689944aa5e5418363eeb78ccda7d5ab0ba3f")
