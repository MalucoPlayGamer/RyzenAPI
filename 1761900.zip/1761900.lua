-- Lua provided by RyzenAPI 
-- Game: EXOME
addappid(1761900)
addappid(1761901, 1, "17ec3b9151ef23edec5f4c7fb10f689944aa5e5418363eeb78ccda7d5ab0ba3f")
