-- Lua provided by RyzenAPI
-- Game: 1826330

-- MAIN APPLICATION
addappid(1826330)
-- Game: addappid(1826330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826331, 1, "aed152e88059641fc58ad955f299e14abbfc70d7cacb76746ed1604773985862")
