-- Lua provided by RyzenAPI
-- Game: The Conglomerate

-- MAIN APPLICATION
addappid(4241320) -- The Conglomerate

-- MAIN APP DEPOTS / PACKAGES
addappid(4241321, 1, "aeb644daf752669367b282edab0e5d544d10acfac83e58f5f3e84d4a2dd31f56") -- Depot 4241321

