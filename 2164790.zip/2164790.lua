-- Lua provided by SkyAPI 
-- Game: Putin Destroys Alien
addappid(2164790)
addappid(2164791, 1, "46dd8b43c5e7ab6e557f627cf463fe7fb3ab9cf01dab667b8c71186ab1e43273")
