-- Lua provided by RyzenAPI
-- Game: Sqwrk

-- MAIN APPLICATION
addappid(2440280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440281, 1, "b1f0a3a5dd26bbb39cae24febd1185b0362f5847da7fad0f77c5c801f0ed4c00")

