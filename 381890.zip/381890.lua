-- Lua provided by RyzenAPI
-- Game: addappid(381890)

-- MAIN APPLICATION
addappid(381890)

-- MAIN APP DEPOTS / PACKAGES
addappid(381891, 1, "5bf7c9e6fc089ac06de7e6aa979d3b895adf14f451376f98885b12132f64a443")
