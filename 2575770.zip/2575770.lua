-- Lua provided by RyzenAPI
-- Game: UsoNatsu ~The Summer Romance Bloomed From A Lie~ Demo

-- MAIN APPLICATION
addappid(2575770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575771, 1, "21d8b06db40a15ff985b8bfabbf3a3126a041aec44b27fffa2604f3903c88a04")
