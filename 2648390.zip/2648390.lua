-- Lua provided by RyzenAPI
-- Game: Billionaire Simulator

-- MAIN APPLICATION
addappid(2648390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2648391, 1, "f52979507a59ab31d5312e9365b58a2e9c64a9f8245a8fe4a7286acc24e10946")

