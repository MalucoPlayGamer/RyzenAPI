-- Lua provided by RyzenAPI
-- Game: Billionaire Simulator

-- MAIN APPLICATION
addappid(2648390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648391, 1, "f52979507a59ab31d5312e9365b58a2e9c64a9f8245a8fe4a7286acc24e10946")
