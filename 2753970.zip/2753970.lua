-- Lua provided by RyzenAPI
-- Game: MARVEL Cosmic Invasion

-- MAIN APPLICATION
addappid(2753970)
addappid(4436470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753971, 1, "ff109204aa554d768b70d4a127f48f336e2817a37eb4f43ece799db7987c596d")
addappid(2753972, 1, "c37ee07f99ae25fae9bb80371746aa3ccb5b2d8eb9fc2f9bd590d0908c5e400f")

