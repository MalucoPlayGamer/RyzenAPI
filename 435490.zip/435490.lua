-- Lua provided by RyzenAPI
-- Game: AppID 435490

-- MAIN APPLICATION
addappid(435490)
-- Game: addappid(435490)

-- MAIN APP DEPOTS / PACKAGES
addappid(435491, 1, "8835eb6bb6903437eb58008fd5bf6cc8fed8126c55de78120a035a1237e84a16")
