-- Lua provided by RyzenAPI 
-- Game: AppID 1602200
addappid(1602200)
addappid(1602201, 1, "ab69bae5a92f808df5fcdd10c85c4b80123fdc512340c5b62a46aeaf91b1a0e0")
