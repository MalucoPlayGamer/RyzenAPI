-- Lua provided by RyzenAPI
-- Game: 1488960

-- MAIN APPLICATION
addappid(1488960)
-- Game: addappid(1488960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488961, 1, "f07fe82f81dcfdadefc0e88040bd094022d90d723d9fbbe34291c9bec870a61d")
