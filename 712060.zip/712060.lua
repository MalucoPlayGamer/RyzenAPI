-- Lua provided by RyzenAPI
-- Game: M.I.A.

-- MAIN APPLICATION
addappid(712060)

-- MAIN APP DEPOTS / PACKAGES
addappid(712061,0,"3d8774b8b9621dffb6429be84ec81f4036ffdea69bc15d12ffa19ef9490ee0ed")

