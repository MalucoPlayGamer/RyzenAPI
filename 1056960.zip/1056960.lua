-- Lua provided by RyzenAPI
-- Game: Game: Wolfenstein: Youngblood

-- MAIN APPLICATION
addappid(1056960)
addappid(1056990)
-- Game: addappid(1056960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056961, 1, "185849a7d07a28dbb77991bdad1c4c01f97e550df4aee74b9989af1fbaa6e8a5")
addappid(1056962, 1, "29b2643c71c5251adb3d5a9c390c49b6276d74fbb091602c6a2b4f1b61d84ced")
addappid(1056963, 1, "321587ab8aff11d56ea0a4146981e0c85e80f7f177416fac4ad8412e1a2cf0e2")
addappid(1056964, 1, "93c9b0eea7c3976388d44232fbcf7c409f5b73cbfa9cb92704d24f5278b6ccf0")
addappid(1056965, 1, "5b00d3d157d787a53e992abf72c92d87c86bbef33ba2f4d255ac9e663282d3b2")
addappid(1056966, 1, "afbe14cc4541a0d67ba96c4c39f7be1e80a91156c0b01a9ae35254fcac6afe46")
addappid(1056967, 1, "cf38542cdc13d2b27e5b93032e3031db407a3d6c083805fd1358d624fea8b5da")
addappid(1056968, 1, "4bd71bc863b81546a34cb8b0df828210e2bd7727bb8d481595cc3c39a39549a7")
addappid(1056969, 1, "b290ec43020913c844e81b540fcf5d8ff1b325c49a29418c4b61abda58d6bc0f")
addappid(1056991, 1, "f1e90ccf12f6f13bcee1c518df8abc5ced5565a6bbef36e78e280a7d751ac6bf")
