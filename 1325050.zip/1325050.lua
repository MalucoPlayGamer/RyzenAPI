-- Lua provided by RyzenAPI
-- Game: Game: Unspottable Demo

-- MAIN APPLICATION
addappid(1325050)
-- Game: addappid(1325050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325051, 1, "ff5f45b1c761ef485baf5f23de751277aa065e400fe2f58d80750953848a8c6b")
