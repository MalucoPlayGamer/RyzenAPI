-- Lua provided by RyzenAPI
-- Game: Cats Love Boxes

-- MAIN APPLICATION
addappid(1961160)
-- Game: addappid(1961160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961161, 1, "950d3d00636240b4827018de0bda32466bcd814dc234d76c04b344b66e7b518e")
