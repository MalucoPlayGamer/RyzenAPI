-- Lua provided by RyzenAPI
-- Game: 2095950

-- MAIN APPLICATION
addappid(2095950)
-- Game: addappid(2095950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095951, 1, "685640dc70b4ee91b9981ce35438636d6015eb4b86799989b3e4ec0abebfdea3")
