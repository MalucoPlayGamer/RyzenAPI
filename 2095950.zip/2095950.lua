-- Lua provided by SkyAPI 
-- Game: PAC-MAN Mega Tunnel Battle: Chomp Champs
addappid(2095950)
addappid(2095951, 1, "685640dc70b4ee91b9981ce35438636d6015eb4b86799989b3e4ec0abebfdea3")
