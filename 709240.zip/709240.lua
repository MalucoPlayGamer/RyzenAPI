-- Lua provided by RyzenAPI
-- Game: Ingnomia

-- MAIN APPLICATION
addappid(709240)
-- Game: addappid(709240)

-- MAIN APP DEPOTS / PACKAGES
addappid(709241, 1, "56bea17fcd7bc0e45f945c5577e917b087c2235975db3e39b8a8985806c6b19f")
