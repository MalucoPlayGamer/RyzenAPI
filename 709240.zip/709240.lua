-- Lua provided by RyzenAPI
-- Game: Ingnomia

-- MAIN APPLICATION
addappid(709240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(709241, 1, "56bea17fcd7bc0e45f945c5577e917b087c2235975db3e39b8a8985806c6b19f")

