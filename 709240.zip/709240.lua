-- Lua provided by SkyAPI 
-- Game: Ingnomia
addappid(709240)
addappid(709241, 1, "56bea17fcd7bc0e45f945c5577e917b087c2235975db3e39b8a8985806c6b19f")
