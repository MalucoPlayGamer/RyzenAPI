-- Lua provided by RyzenAPI
-- Game: addappid(1894990)

-- MAIN APPLICATION
addappid(1894990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894991, 1, "a6948520d729af9ecb511745ba84a4e4bf679fb0674c8589906d30be54b1ddbf")
