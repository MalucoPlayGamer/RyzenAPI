-- Lua provided by RyzenAPI
-- Game: Game: DAVIGO: VR vs. PC

-- MAIN APPLICATION
addappid(1116540)
-- Game: addappid(1116540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116541, 1, "5bed7319623499728b3880410fa5cbf4975d14b3ff1c5096facd5d9e72226245")
