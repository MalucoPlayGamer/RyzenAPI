-- Lua provided by RyzenAPI
-- Game: DAVIGO: VR vs. PC

-- MAIN APPLICATION
addappid(1116540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1116541, 1, "5bed7319623499728b3880410fa5cbf4975d14b3ff1c5096facd5d9e72226245")

