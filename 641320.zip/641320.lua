-- Lua provided by RyzenAPI
-- Game: Cooking Simulator

-- MAIN APPLICATION
addappid(641320)
addappid(1357180)
addappid(3218770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(641321, 1, "693af0f9d3395af0e1b880807b3b8b17e6391a03fc860c96b19ed41405f60b47")
addappid(641322, 1, "db47cd4de11025ce2760303af3fd623baa4f940a1d4abade766929e6fdea5773")
addappid(1168680, 0, "797b64d673b14e960e7038223232c095037fffe4c87d0a5df408038992d80277")
addappid(1227350, 0, "95e78a282673605fd207d57e859d2ebfad79b7e109bf46948174367912417ea4")
addappid(1400460, 0, "0b0a23c7ebe1db10757fd3fe167ad02d5a24d30b85ea6204aa955224a82deb4f")
addappid(1575660, 0, "3da4fdcde0a30525db779f45c19281032e80bdf2174c17b75edae1ff9892c4ac")
addappid(2655000, 0, "2f18b51f4778cff77849ba20d5641847ce0ee6d1695ca634a6ba22af6482b01d")

