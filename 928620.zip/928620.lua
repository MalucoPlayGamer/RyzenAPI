-- Lua provided by RyzenAPI
-- Game: 928620

-- MAIN APPLICATION
addappid(928620)
-- Game: addappid(928620)

-- MAIN APP DEPOTS / PACKAGES
addappid(928621, 1, "7071431ddfc89ca4cfc21d191f4fd9d7f65c67bc3150dcfc03d0de795eea7fd9")
