-- Lua provided by RyzenAPI
-- Game: What Lurks Inside

-- MAIN APPLICATION
addappid(2753610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2753611, 1, "94c3f286eead46cb94dcbf9f64dc7ab453010abf2c51ebceae7ce6a7fd722aa9")

