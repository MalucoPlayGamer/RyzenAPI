-- Lua provided by RyzenAPI
-- Game: 1032340

-- MAIN APPLICATION
addappid(1032340)
-- Game: addappid(1032340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032341, 1, "399e79cd1b281e423818792a1e6fb390c25dce464d45fa4614a84ea26d5b7a75")
