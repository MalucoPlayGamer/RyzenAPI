-- Lua provided by RyzenAPI
-- Game: Beastro


addappid(2417470) -- Beastro
addappid(2417471, 1, "b467b8937ecd8c2fb14ff891d7625e4bbfe31ade3c85328770590b0d6542592d") -- Depot 2417471
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
