-- Lua provided by RyzenAPI
-- Game: addappid(1022470)

-- MAIN APPLICATION
addappid(1022470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022470,0,"79fb43e9b0d390fa8c017378aa01d6abd5ba3302431a5e36f9965ce82a3aa3cc")
