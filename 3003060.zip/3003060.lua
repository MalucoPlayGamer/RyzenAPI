-- Lua provided by RyzenAPI 
-- Game: AppID 3003060
addappid(3003060)
addappid(3003061, 1, "081afb56285406aab0e687ae6532fefa1e7e8be398630839c4309d162cefbaff")
