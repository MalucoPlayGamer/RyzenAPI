-- Lua provided by RyzenAPI
-- Game: Spiritfarer Demo

-- MAIN APPLICATION
addappid(1202910)
-- Game: addappid(1202910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202911, 1, "83e86bd55878f8c1562ceb531ca3d4733f5e5896ae1dc69a51e76e7f56e71520")
