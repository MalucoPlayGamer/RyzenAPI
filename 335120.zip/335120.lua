-- Lua provided by RyzenAPI
-- Game: Serpent in the Staglands

-- MAIN APPLICATION
addappid(335120)

-- MAIN APP DEPOTS / PACKAGES
addappid(335122,0,"bb9a7b254a83e5464deb5ef646695d26f50097833ea7f92a49b7c719ac21670c")
addappid(335123,0,"42113b7de3a063b87de80c7e934af4f15077f9d31f3467654b232e4c07d29081")

