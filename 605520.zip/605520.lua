-- Lua provided by RyzenAPI
-- Game: AppID 605520

-- MAIN APPLICATION
addappid(605520)

-- MAIN APP DEPOTS / PACKAGES
addappid(605521, 1, "3dfced92bb83a523711ae879c2af7c4da274c8daed9d37b4855c767409e1f31a")

