-- Lua provided by RyzenAPI
-- Game: 1287150

-- MAIN APPLICATION
addappid(1287150)
-- Game: addappid(1287150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287152,0,"240c87ebcc891aea9d76f3973fbfabb72c75fd4696e4e194070ad7d29c695970")
