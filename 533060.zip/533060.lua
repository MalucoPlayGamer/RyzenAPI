-- Lua provided by RyzenAPI
-- Game: addappid(533060)

-- MAIN APPLICATION
addappid(533060)

-- MAIN APP DEPOTS / PACKAGES
addappid(533061, 1, "524e23b2856cf0022e790b2d5f4b90015063b4c40ee07c7db0fc9c02386c3105")
