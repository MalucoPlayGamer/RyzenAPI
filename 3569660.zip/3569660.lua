-- Lua provided by RyzenAPI
-- Game: 3569660

-- MAIN APPLICATION
addappid(3569660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569662,0,"711650bb14efa2f91b6fc41dd23ef7fcd7aab128d55f3f0471ca4258da4e973a")

