-- Lua provided by RyzenAPI
-- Game: AppID 2677300

-- MAIN APPLICATION
addappid(2677300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677301, 1, "b8387540ed43027bf8bc15b6b4ed9e6398cb5aec1fa4ccc0217b8cac087f2c4a")
