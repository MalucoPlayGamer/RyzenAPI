-- Lua provided by SkyAPI 
-- Game: CosmoDreamer
addappid(1424630)
addappid(1424631, 1, "c98f3dfe89d62d56f2ac8976867ca0fa0c6ed68249f0c4572db7536338fb9662")
