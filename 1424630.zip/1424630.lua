-- Lua provided by RyzenAPI
-- Game: CosmoDreamer

-- MAIN APPLICATION
addappid(1424630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424631, 1, "c98f3dfe89d62d56f2ac8976867ca0fa0c6ed68249f0c4572db7536338fb9662")

