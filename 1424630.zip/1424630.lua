-- Lua provided by RyzenAPI
-- Game: CosmoDreamer

-- MAIN APPLICATION
addappid(1424630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1424631, 1, "c98f3dfe89d62d56f2ac8976867ca0fa0c6ed68249f0c4572db7536338fb9662")

