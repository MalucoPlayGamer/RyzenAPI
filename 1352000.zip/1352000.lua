-- Lua provided by RyzenAPI
-- Game: AppID 1352000

-- MAIN APPLICATION
addappid(1352000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352001, 1, "db6aaad6929aff138602401486b7d79df9af30782ee50f4c4b0d36d92cebc30e")
