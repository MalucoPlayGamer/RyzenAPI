-- Lua provided by RyzenAPI
-- Game: Game: EMPULSE

-- MAIN APPLICATION
addappid(4323990)
-- Game: addappid(4323990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4323991, 1, "c0dd6705b60323bb7d06956a8fe46cdb2b7ea51a399396b4374b633f6edac2c8")
