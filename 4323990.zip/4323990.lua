-- Lua provided by RyzenAPI
-- Game: EMPULSE

-- MAIN APPLICATION
addappid(4323990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4323991, 1, "c0dd6705b60323bb7d06956a8fe46cdb2b7ea51a399396b4374b633f6edac2c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
