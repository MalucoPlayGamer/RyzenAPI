-- Lua provided by RyzenAPI
-- Game: 427240

-- MAIN APPLICATION
addappid(427240)
addappid(427241)
addappid(640401)
addappid(770150)

-- MAIN APP DEPOTS / PACKAGES
addappid(427242,0,"e9f97a3b7f519c63c100f6e59625097f2e4cc6985c6cc85b781093aa2c05c958")
