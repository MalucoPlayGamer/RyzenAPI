-- Lua provided by RyzenAPI
-- Game: addappid(2027390)

-- MAIN APPLICATION
addappid(2027390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027391, 1, "5c519ef8d3417a38d567f197a957460c7869f8a6c65e92aefdb065b29e65ae53")
