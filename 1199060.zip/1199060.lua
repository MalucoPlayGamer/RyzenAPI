-- Lua provided by RyzenAPI
-- Game: addappid(1199060)

-- MAIN APPLICATION
addappid(1199060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199061, 1, "9e9301474d6b0e88849820a4437f4bddd5019c57ade9749bcb8a522fb3431a5f")
