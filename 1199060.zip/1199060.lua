-- Lua provided by RyzenAPI
-- Game: Coin Pickers

-- MAIN APPLICATION
addappid(1199060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1199061, 1, "9e9301474d6b0e88849820a4437f4bddd5019c57ade9749bcb8a522fb3431a5f")

