-- Lua provided by RyzenAPI
-- Game: Soldat Dedicated Server

-- MAIN APPLICATION
addappid(638500)

-- MAIN APP DEPOTS / PACKAGES
addappid(638501, 1, "6ae343fa5648aaab4e96e3a7b51b887d3833e66a96e74ce10f52debde6ed4714")
