-- Lua provided by RyzenAPI
-- Game: Kung Fu Ping Pong

-- MAIN APPLICATION
addappid(568240)

-- MAIN APP DEPOTS / PACKAGES
addappid(568241,0,"2ad3e20c7e662a846f27a2ebcae19df96898c4ceb1cf2b65e38dd68f7e9e34c0")

