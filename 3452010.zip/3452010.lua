-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Istanbul

-- MAIN APPLICATION
addappid(3452010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452011, 1, "f440ea2992883d73adfdd807fe60e4644c146bd04d2d389ea7acc9ea0118968d")

