-- Lua provided by RyzenAPI
-- Game: Survival Quiz CITY おまつり編

-- MAIN APPLICATION
addappid(2328530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2328531, 1, "46913231afb399b85a0de0d1e6bf43ee4309e129d376bde5ef5a0c7199c5e6cb")

