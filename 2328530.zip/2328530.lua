-- Lua provided by RyzenAPI
-- Game: Survival Quiz CITY おまつり編

-- MAIN APPLICATION
addappid(2328530)
-- Game: addappid(2328530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328531, 1, "46913231afb399b85a0de0d1e6bf43ee4309e129d376bde5ef5a0c7199c5e6cb")
