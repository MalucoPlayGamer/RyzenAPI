-- Lua provided by RyzenAPI
-- Game: Island Of Enchantment

-- MAIN APPLICATION
addappid(2899680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899681,0,"cbd4ba1aefb8d1c285946ac969136fe0a51c282edc2e251afcdd8c607da9a59e")
addappid(4298120,0,"a30e64ba3bb3db2ba72fe984d0791fe35818186bb60efea7c064bcdbd3379bf6")

