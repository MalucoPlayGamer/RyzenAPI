-- Lua provided by RyzenAPI
-- Game: addappid(415830)

-- MAIN APPLICATION
addappid(415830)

-- MAIN APP DEPOTS / PACKAGES
addappid(415831, 1, "ded70ec07238090dd1bbed403b6f6d95199003258a41d2c02dba0bb3e1206555")
addappid(983500, 0, "84da3f3a1fd0df2b4e69c5aa9ed69cb3de36470500ee627ebcea49ba031de088")
