-- Lua provided by RyzenAPI
-- Game: 707480

-- MAIN APPLICATION
addappid(707480)
-- Game: addappid(707480)

-- MAIN APP DEPOTS / PACKAGES
addappid(537856,0,"df58414c9f1dc4b756bc705f3bc592472d898913f13fa11cfa6db9d4ba3a75c1")
