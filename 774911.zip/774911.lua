-- Lua provided by RyzenAPI
-- Game: Game: The Master

-- MAIN APPLICATION
addappid(774911)
-- Game: addappid(774911)

-- MAIN APP DEPOTS / PACKAGES
addappid(774912, 1, "2311c2feb2bbce5f8cbbc9bef2e3d67c8c6905cbceee66b4bc2f0726aee6ae2d")
