-- Lua provided by RyzenAPI
-- Game: The Master

-- MAIN APPLICATION
addappid(774911)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(774912, 1, "2311c2feb2bbce5f8cbbc9bef2e3d67c8c6905cbceee66b4bc2f0726aee6ae2d")

