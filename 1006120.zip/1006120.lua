-- Lua provided by SkyAPI 
-- Game: Tetsumo Party
addappid(1006120)
addappid(1006121, 1, "dc30331dc5f92e0567e14bcba4b40010b7ef50e889e3e46f43ad7265e8a08f90")
