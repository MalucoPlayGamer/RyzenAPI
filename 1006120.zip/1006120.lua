-- Lua provided by RyzenAPI
-- Game: Tetsumo Party

-- MAIN APPLICATION
addappid(1006120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1006121, 1, "dc30331dc5f92e0567e14bcba4b40010b7ef50e889e3e46f43ad7265e8a08f90")

