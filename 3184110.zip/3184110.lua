-- Lua provided by RyzenAPI
-- Game: Game: Widget Inc.

-- MAIN APPLICATION
addappid(3184110)
-- Game: addappid(3184110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184111, 1, "74b60bd060a9d7c1b80bbf277c4d1e46a2ffa05e2331ee133c4ceed2b70a5f2a")
