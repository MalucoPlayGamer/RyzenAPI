-- Lua provided by RyzenAPI
-- Game: Bazaar Simulator

-- MAIN APPLICATION
addappid(2379810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379811, 1, "8b3829069e1a0335e4a92aa833941379bc14c51dc6c3973542abfc6e502f20f5")
