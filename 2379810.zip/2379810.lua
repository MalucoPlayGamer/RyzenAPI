-- Lua provided by SkyAPI 
-- Game: Bazaar Simulator
addappid(2379810)
addappid(2379811, 1, "8b3829069e1a0335e4a92aa833941379bc14c51dc6c3973542abfc6e502f20f5")
