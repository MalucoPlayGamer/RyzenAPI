-- Lua provided by RyzenAPI
-- Game: AppID 795860

-- MAIN APPLICATION
addappid(795860)
-- Game: addappid(795860)

-- MAIN APP DEPOTS / PACKAGES
addappid(795861, 1, "538aafe12f477b53c376b102be4a034efd549204df776e166fb52ae8a7900b88")
addappid(795862, 1, "aaa57edb1560075395d2e5c97d3c59ff1f22d255ae281793d94102ad662eab60")
addappid(795863, 1, "5fef5e705ca8e69b1b4a2104fda309858cae27a37c6cc557b9e1d305a650cd0d")
