-- Lua provided by RyzenAPI
-- Game: Blast Brigade vs. the Evil Legion of Dr. Cread

-- MAIN APPLICATION
addappid(1550760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550761, 1, "0316cbf9ecc4380dc1adc82a7766ec1aece9c7bc19c3a92029c9a0e07a96e61f")

