-- Lua provided by RyzenAPI
-- Game: Baccarat Online: Baccarist

-- MAIN APPLICATION
addappid(3673460)
