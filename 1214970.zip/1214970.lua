-- Lua provided by RyzenAPI
-- Game: Cthulhu Saves Christmas - Soundtrack

-- MAIN APPLICATION
addappid(1214970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214970,0,"7d51d685e5cd9775289f5d75b31dc76736d75693fc52195393a588c3fb0a4fd2")

