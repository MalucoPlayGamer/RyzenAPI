-- Lua provided by RyzenAPI
-- Game: addappid(2711670)

-- MAIN APPLICATION
addappid(2711670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711671, 1, "7e33cb55c886d7c3ef4c4ba62e6665c8ad02926dade8c83014c12f2cb400bb50")
