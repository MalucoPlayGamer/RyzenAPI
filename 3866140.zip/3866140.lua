-- Lua provided by RyzenAPI
-- Game: Void of Lilly

-- MAIN APPLICATION
addappid(3866140)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4170300)
