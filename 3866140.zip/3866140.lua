-- Lua provided by RyzenAPI
-- Game: Void of Lilly

-- MAIN APPLICATION
addappid(3866140)
addappid(4170300)

