-- Lua provided by RyzenAPI
-- Game: addappid(1812130)

-- MAIN APPLICATION
addappid(1812130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812131, 1, "b8199aaff99ca899c9e2ca3a6e21afcf0ba67a9cc9802085a8dffc0b8dedfe83")
