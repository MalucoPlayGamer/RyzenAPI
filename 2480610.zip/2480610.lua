-- Lua provided by RyzenAPI
-- Game: Tomorrow Will Be Dying Demo

-- MAIN APPLICATION
addappid(2480610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480611, 1, "dd633e427e70d1f5c2768dbc746348ce12e7bb10f0a3664739858797fe21fc9b")
