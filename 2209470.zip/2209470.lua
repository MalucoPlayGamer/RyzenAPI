-- 2209470's Lua and Manifest Created by Hubcap Manifest
-- Interplayer
-- Created: August 01, 2026 at 05:07:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2209470) -- Interplayer
-- MAIN APP DEPOTS
addappid(2209472, 1, "1eb1fe28b91637b87551f60ead7a540e772429e2ae4985b4304e4fd97e54f0af") -- Depot 2209472
setManifestid(2209472, "8072712607024553822", 176077140)
addappid(2209471, 1, "421b2c277871bc84dd0682c8ec456d8bb3da711a4b6c2e736dd16c2d984090d7") -- Depot 2209471
setManifestid(2209471, "8485428536316135656", 176048184)