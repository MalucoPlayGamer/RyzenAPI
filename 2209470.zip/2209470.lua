-- Lua provided by RyzenAPI
-- Game: Interplayer

-- MAIN APPLICATION
addappid(2209470) -- Interplayer

-- MAIN APP DEPOTS / PACKAGES
addappid(2209471, 1, "421b2c277871bc84dd0682c8ec456d8bb3da711a4b6c2e736dd16c2d984090d7") -- Depot 2209471
addappid(2209472, 1, "1eb1fe28b91637b87551f60ead7a540e772429e2ae4985b4304e4fd97e54f0af") -- Depot 2209472

