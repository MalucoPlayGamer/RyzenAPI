-- Lua provided by RyzenAPI
-- Game: Game: Prehistoric Tales

-- MAIN APPLICATION
addappid(466780)
-- Game: addappid(466780)

-- MAIN APP DEPOTS / PACKAGES
addappid(466781, 1, "6fb387856a5bce6a91880c377a03b4104556a4a2e1663fbfbde48a2e14906070")
