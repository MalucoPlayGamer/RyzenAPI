-- Lua provided by RyzenAPI
-- Game: Game: Dear Mom: My Letter to You Demo

-- MAIN APPLICATION
addappid(1700610)
-- Game: addappid(1700610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700611, 1, "b4b59f25de659fc82a2e6a9e258e811c8d452f6cbb8548d51b2a71a8aee2d3ac")
