-- Lua provided by RyzenAPI
-- Game: Excive A-1000

-- MAIN APPLICATION
addappid(1008870)
addappid(1018050)
-- Game: addappid(1008870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008871, 1, "3655e7c7ef5af41234ad8567b421d0f1c697d99d1871393119e2b6be69f2a1ef")
