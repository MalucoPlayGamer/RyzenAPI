-- Lua provided by RyzenAPI
-- Game: addappid(1050370)

-- MAIN APPLICATION
addappid(1050370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050371, 1, "aa0b3db007fc776c20f9bb92ba7e40e1dc1f83487daafcf94f0573f655bd6711")
