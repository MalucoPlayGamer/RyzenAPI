-- Lua provided by RyzenAPI
-- Game: Intimate Abode

-- MAIN APPLICATION
addappid(2898130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2898131, 1, "07476c85f673da0bd50497008fc7c8e885ddfe3b7280b3756ebf9aea71fe51ba")

