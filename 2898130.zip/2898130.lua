-- Lua provided by SkyAPI 
-- Game: Intimate Abode
addappid(2898130)
addappid(2898131, 1, "07476c85f673da0bd50497008fc7c8e885ddfe3b7280b3756ebf9aea71fe51ba")
