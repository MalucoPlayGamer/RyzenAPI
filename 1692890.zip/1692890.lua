-- Lua provided by RyzenAPI
-- Game: VR Military Reporter in Middle East (with tanks & helicopters)

-- MAIN APPLICATION
addappid(1692890)
-- Game: addappid(1692890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692891, 1, "152a785571fa6d362507068725d5cfe79d82648600a3b74ea02bae6cc4f5835e")
