-- Lua provided by RyzenAPI
-- Game: VR Military Reporter in Middle East (with tanks & helicopters)

-- MAIN APPLICATION
addappid(1692890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692891, 1, "152a785571fa6d362507068725d5cfe79d82648600a3b74ea02bae6cc4f5835e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
