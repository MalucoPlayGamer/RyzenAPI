-- Lua provided by RyzenAPI
-- Game: The m0rg VS keys - Soundtrack

-- MAIN APPLICATION
addappid(828430)

-- MAIN APP DEPOTS / PACKAGES
addappid(828430,0,"df612ba9083d035d5ea34dceba244ba6d7fbfba26c15b98c59dd397d4bd2c5d5")
