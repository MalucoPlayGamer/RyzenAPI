-- Lua provided by RyzenAPI
-- Game: 206980

-- MAIN APPLICATION
addappid(206980)
-- Game: addappid(206980)

-- MAIN APP DEPOTS / PACKAGES
addappid(206981, 1, "8ec836e9955119e5f7fb942e00cc37d11ebf9929883b84dd240a20d77cd60ed1")
