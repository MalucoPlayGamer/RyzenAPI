-- Lua provided by RyzenAPI
-- Game: addappid(3143560)

-- MAIN APPLICATION
addappid(3143560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143561, 1, "c5f86521d21370c54bbcd29b140b8bb4850f1b56de005aba445de8278ddc1c5f")
