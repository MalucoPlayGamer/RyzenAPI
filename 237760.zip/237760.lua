-- Lua provided by RyzenAPI 
-- Game: Intake
addappid(237760)
addappid(237761, 1, "d54281dca731362dd1b07a1bc9b8205ddcbc91107e904e46cde2458a4c8ae626")
addappid(237762, 1, "79859fd66e0434b95d53a1e6852c25f9349291773dc1a97a960699149e037279")
