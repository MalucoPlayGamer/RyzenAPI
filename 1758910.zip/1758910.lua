-- Lua provided by RyzenAPI
-- Game: Time Commando

-- MAIN APPLICATION
addappid(1758910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758911, 1, "d9fd1a003f0171a4a93b2d7ba76485cb1ec16169697396cb9867a87c354d1595")

