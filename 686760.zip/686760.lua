-- Lua provided by RyzenAPI
-- Game: 686760

-- MAIN APPLICATION
addappid(686760)
-- Game: addappid(686760)

-- MAIN APP DEPOTS / PACKAGES
addappid(686761, 1, "92a2ab94230f5162c4bfab4a27184afd40ecb99b18a89f07abde348bbd8af062")
