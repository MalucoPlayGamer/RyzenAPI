-- Lua provided by RyzenAPI
-- Game: Waifu Simulator: Latex Edition

-- MAIN APPLICATION
addappid(3337490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337491, 1, "6ac72818e0695313092ab6a9272a6fb20e5f80442c439ff9487d8abdca075db5")

