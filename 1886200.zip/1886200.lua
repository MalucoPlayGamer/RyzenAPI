-- Lua provided by RyzenAPI
-- Game: Game: Chernobyl Trap

-- MAIN APPLICATION
addappid(1886200)
-- Game: addappid(1886200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886201, 1, "7baa681e92720fffdd13d51e04b8ba02f948392408be8a9ac9500f841a722d2d")
