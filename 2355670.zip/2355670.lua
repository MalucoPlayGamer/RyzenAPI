-- Lua provided by RyzenAPI
-- Game: AppID 2355670

-- MAIN APPLICATION
addappid(2355670)
-- Game: addappid(2355670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355671, 1, "0850b7b3cd26751d0cfcd7828fac0db85717f4dbd66ff14740c541b57da9835a")
