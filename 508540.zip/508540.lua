-- Lua provided by RyzenAPI
-- Game: 508540

-- MAIN APPLICATION
addappid(508540)

-- MAIN APP DEPOTS / PACKAGES
addappid(508546,0,"844e8498d2ef53ae4fa4f22a4e3d92287c77be83b2bfd435a092da8b7ac82f97")

