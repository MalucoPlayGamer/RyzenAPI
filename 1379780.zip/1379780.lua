-- Lua provided by RyzenAPI
-- Game: 1379780

-- MAIN APPLICATION
addappid(1379780)
addappid(1379781)
addappid(1379783)
addappid(1379784)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379782,0,"36010d9b3e4aa1b10902e43c8b82f4f5de1d5326326c27f39f914f0e91cd1008")

