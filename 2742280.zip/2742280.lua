-- Lua provided by RyzenAPI
-- Game: Fantasista Asuka

-- MAIN APPLICATION
addappid(2742280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742281, 1, "119e74230884862ea503bfc0d472854424990a8e167cfde48536a8724ec1eee9")

