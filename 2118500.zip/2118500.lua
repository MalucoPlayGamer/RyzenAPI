-- Lua provided by RyzenAPI
-- Game: addappid(2118500)

-- MAIN APPLICATION
addappid(2118500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118501, 1, "62b0064f15b250d3e9ff0599087d92a399a45b6d2162be5fba31dbf7722b94ec")
