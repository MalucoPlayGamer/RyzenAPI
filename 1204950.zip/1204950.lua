-- Lua provided by RyzenAPI 
-- Game: Cecil Run
addappid(1204950)
addappid(1204951, 1, "3b23ff464a911d7eb96677132315aa682f36717437a132c3c54430854ddec4d7")
