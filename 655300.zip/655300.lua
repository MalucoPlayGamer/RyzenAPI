-- Lua provided by RyzenAPI
-- Game: AppID 655300

-- MAIN APPLICATION
addappid(655300)
-- Game: addappid(655300)

-- MAIN APP DEPOTS / PACKAGES
addappid(655301, 1, "fbc0325769e14c78763403c376980a255e194a5bd5fc502d4e462fd7564153ff")
