-- Lua provided by RyzenAPI
-- Game: addappid(775690)

-- MAIN APPLICATION
addappid(775690)

-- MAIN APP DEPOTS / PACKAGES
addappid(775691, 1, "d87f59eaad530001056533dae77e627b6ac26d55d2b08a0deb99854972a1887c")
