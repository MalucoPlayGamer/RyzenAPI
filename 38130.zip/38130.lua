-- Lua provided by SkyAPI 
-- Game: Farm Frenzy 2
addappid(38130)
addappid(38131, 1, "b9dccd9b3a5a6a879519194137ead4b7fd465c99e5cd32e126516174d8a11c8b")
