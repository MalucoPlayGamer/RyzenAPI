-- Lua provided by RyzenAPI
-- Game: Endzone 2: Soundtrack

-- MAIN APPLICATION
addappid(3124450)
-- Game: addappid(3124450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126190,0,"7ac3c41708a414ce087309c70bd9d23f394c2a6a23b294e9c68e036290e2a985")
addappid(3126191,0,"41477a06fe546e82dd15c33b3af00f361f29f4f56f2482cf0ab94508cb755a9c")
