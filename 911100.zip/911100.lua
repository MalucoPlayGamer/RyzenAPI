-- Lua provided by RyzenAPI
-- Game: addappid(911100)

-- MAIN APPLICATION
addappid(911100)

-- MAIN APP DEPOTS / PACKAGES
addappid(911101, 1, "dd427da675050948e782bfb7fc0af209873aaab14468aec3a34a4ca46152d9d3")
