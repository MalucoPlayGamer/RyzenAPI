-- Lua provided by RyzenAPI
-- Game: Iron Core: Mech Survivor

-- MAIN APPLICATION
addappid(3586420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586421, 1, "8a3eed8f015569246e7f486ed4578c404267854e03825709d10af16f833d95b5")

