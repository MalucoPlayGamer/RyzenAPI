-- Lua provided by RyzenAPI
-- Game: AppID 3134630

-- MAIN APPLICATION
addappid(3134630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134631, 1, "c5a0dfa5adf0998c55e0074eec4cfccc942e7f7ff9915b955c1c2a82468af653")

