-- Lua provided by RyzenAPI
-- Game: Game: Sweets Pusher Friends

-- MAIN APPLICATION
addappid(2241910)
-- Game: addappid(2241910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241911, 1, "7b66089dc76a2ff4a5f3a0626513434c335bb3a5e95e1f3a4b0f20f216d5b87f")
