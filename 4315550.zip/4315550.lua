-- 4315550's Lua and Manifest Created by Hubcap Manifest
-- The Carcass
-- Created: August 12, 2026 at 09:13:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4315550) -- The Carcass
-- MAIN APP DEPOTS
addappid(4315551, 1, "60d61134cbbf76a091878435a4c44aab253e8d444a66d5ae5d4133ea70742b79") -- Depot 4315551
setManifestid(4315551, "9040839262050854245", 1511648568)