-- Lua provided by RyzenAPI
-- Game: The Carcass

-- MAIN APPLICATION
addappid(4315550) -- The Carcass

-- MAIN APP DEPOTS / PACKAGES
addappid(4315551, 1, "60d61134cbbf76a091878435a4c44aab253e8d444a66d5ae5d4133ea70742b79") -- Depot 4315551

