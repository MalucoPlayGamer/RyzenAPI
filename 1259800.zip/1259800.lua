-- Lua provided by RyzenAPI
-- Game: MXGP 2020 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1259800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259801, 1, "ab67ed1ca53fea4687c792a1630c92b4e21b9699eccfc3a9d50214511147d00f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
