-- Lua provided by RyzenAPI
-- Game: MXGP 2020 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1259800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259801, 1, "ab67ed1ca53fea4687c792a1630c92b4e21b9699eccfc3a9d50214511147d00f")

