-- Lua provided by RyzenAPI
-- Game: AppID 359340

-- MAIN APPLICATION
addappid(359340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(359341, 1, "aa5b6beefcd124944cb7bd16ab286c48da7b701e1d53e9b74ce522352e400134")

