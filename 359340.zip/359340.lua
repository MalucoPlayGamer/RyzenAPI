-- Lua provided by RyzenAPI
-- Game: 359340

-- MAIN APPLICATION
addappid(359340)
-- Game: addappid(359340)

-- MAIN APP DEPOTS / PACKAGES
addappid(359341, 1, "aa5b6beefcd124944cb7bd16ab286c48da7b701e1d53e9b74ce522352e400134")
