-- Lua provided by RyzenAPI
-- Game: AppID 2791290

-- MAIN APPLICATION
addappid(2791290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791291, 1, "b09312f0fd99d5b394c59a290e6504938c15ec726d355b95c28ce3e0b430fe22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
