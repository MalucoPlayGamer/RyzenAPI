-- Lua provided by RyzenAPI
-- Game: 1652891

-- MAIN APPLICATION
addappid(1652891)
-- Game: addappid(1652891)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652891,0,"927ff307380ff6d4ccf5e19cb9434dae2ce3aaa43296e650580564a68245684d")
