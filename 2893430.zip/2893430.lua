-- Lua provided by RyzenAPI
-- Game: Beat Saber - 2Pac - "All Eyez On Me (feat. Big Syke)"

-- MAIN APPLICATION
addappid(2893430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893430,0,"9f5717d141de0458a116c957184de18ad430aa5554f31d73ba71665a772ec6e5")
