-- Lua provided by RyzenAPI
-- Game: AppID 519490

-- MAIN APPLICATION
addappid(519490)

-- MAIN APP DEPOTS / PACKAGES
addappid(519491, 1, "f7380b705efbea4ce72d201aa905cb3153d3cd9ae4ada92109b45d02dc8bd780")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
