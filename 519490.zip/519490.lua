-- Lua provided by RyzenAPI
-- Game: AppID 519490

-- MAIN APPLICATION
addappid(519490)

-- MAIN APP DEPOTS / PACKAGES
addappid(519491, 1, "f7380b705efbea4ce72d201aa905cb3153d3cd9ae4ada92109b45d02dc8bd780")
