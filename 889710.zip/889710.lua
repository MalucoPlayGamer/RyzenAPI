-- Lua provided by RyzenAPI
-- Game: addappid(889710)

-- MAIN APPLICATION
addappid(889710)

-- MAIN APP DEPOTS / PACKAGES
addappid(889711, 1, "8151a4682a9569b9f8f6d6dec0be80ea6042b34ca8f9f1c971ad4e54d6079f02")
