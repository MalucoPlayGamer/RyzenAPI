-- Lua provided by RyzenAPI
-- Game: Muv-Luv photonmelodies♮

-- MAIN APPLICATION
addappid(889710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(889711, 1, "8151a4682a9569b9f8f6d6dec0be80ea6042b34ca8f9f1c971ad4e54d6079f02")
