-- Lua provided by RyzenAPI
-- Game: 793010

-- MAIN APPLICATION
addappid(793010)
-- Game: addappid(793010)

-- MAIN APP DEPOTS / PACKAGES
addappid(793011, 1, "532ca62c6356519ef50d759ecd91e886d6c2b511148438ace9993ac92a372bc1")
