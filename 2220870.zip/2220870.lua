-- Lua provided by RyzenAPI
-- Game: Fantasy Survivors

-- MAIN APPLICATION
addappid(3586900) -- Fantasy Survivors - Dragonium Tales

-- MAIN APP DEPOTS / PACKAGES
addappid(2220870, 1, "e0c9db8e9e165e0e56d94608a0765efb3bd150c726d6b67aedb3e91870f78fd0") -- Fantasy Survivors
addappid(2220871, 1, "25469231958c51bf8105c223f654e5a34d7f8eb27e6262e0eee6b3750c309bc6") -- Depot 2220871

