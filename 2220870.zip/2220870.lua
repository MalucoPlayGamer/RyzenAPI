-- 2220870's Lua and Manifest Created by Hubcap Manifest
-- Fantasy Survivors
-- Created: August 11, 2026 at 17:25:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2220870, 1, "e0c9db8e9e165e0e56d94608a0765efb3bd150c726d6b67aedb3e91870f78fd0") -- Fantasy Survivors
-- MAIN APP DEPOTS
addappid(2220871, 1, "25469231958c51bf8105c223f654e5a34d7f8eb27e6262e0eee6b3750c309bc6") -- Depot 2220871
setManifestid(2220871, "3484441704148507414", 699226296)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3586900) -- Fantasy Survivors - Dragonium Tales