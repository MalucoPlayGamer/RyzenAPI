-- Lua provided by RyzenAPI
-- Game: N1L (No1Lives)

-- MAIN APPLICATION
addappid(860960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(860961, 1, "25f74f374240551c7457a5c53d787ce80c5bee9cad08847f6bf0c3b8edd01ade")

