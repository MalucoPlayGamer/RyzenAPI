-- Lua provided by RyzenAPI
-- Game: N1L (No1Lives)

-- MAIN APPLICATION
addappid(860960)

-- MAIN APP DEPOTS / PACKAGES
addappid(860961, 1, "25f74f374240551c7457a5c53d787ce80c5bee9cad08847f6bf0c3b8edd01ade")
