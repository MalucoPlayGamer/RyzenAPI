-- Lua provided by RyzenAPI
-- Game: Master Detective Archives: RAIN CODE Plus - The Book of Death

-- MAIN APPLICATION
addappid(2903990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903990,0,"867085a2d7296a081e93e6bdfece17b32035a08712e5e761edea8bed259d7231")

