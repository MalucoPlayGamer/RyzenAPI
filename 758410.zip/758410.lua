-- Lua provided by RyzenAPI
-- Game: AO International Tennis

-- MAIN APPLICATION
addappid(758410)
-- Game: addappid(758410)

-- MAIN APP DEPOTS / PACKAGES
addappid(758411, 1, "6b558a75466622a2166565098c372fee093e60e928a134352242144d53497279")
