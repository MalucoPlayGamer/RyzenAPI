-- Lua provided by RyzenAPI
-- Game: Sigi - A Fart for Melusina

-- MAIN APPLICATION
addappid(677280)

-- MAIN APP DEPOTS / PACKAGES
addappid(677283,0,"866298cad43785026bb289d1853c21c784b7f4a92cd82f30bd194e52e99d8e8a")
