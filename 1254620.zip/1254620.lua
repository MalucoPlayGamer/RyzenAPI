-- Lua provided by RyzenAPI
-- Game: addappid(1254620)

-- MAIN APPLICATION
addappid(1254620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254621, 1, "4475e26ae8306d77e1bce768a0064421df2172f65fbbbffb995927c48678a89d")
