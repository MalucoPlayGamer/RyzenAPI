-- Lua provided by RyzenAPI
-- Game: NAMCO MUSEUM ARCHIVES Vol 2

-- MAIN APPLICATION
addappid(1254620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254621, 1, "4475e26ae8306d77e1bce768a0064421df2172f65fbbbffb995927c48678a89d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
