-- Lua provided by SkyAPI 
-- Game: NAMCO MUSEUM ARCHIVES Vol 2
addappid(1254620)
addappid(1254621, 1, "4475e26ae8306d77e1bce768a0064421df2172f65fbbbffb995927c48678a89d")
