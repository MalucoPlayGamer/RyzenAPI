-- Lua provided by RyzenAPI 
-- Game: AppID 1292220
addappid(1292220)
addappid(1292221, 1, "7f97e4697f164ee21cc78ceb52dea48430f4f58d73fe1135bfdba52ba72a5b04")
