-- Lua provided by SkyAPI 
-- Game: Say No! More Demo
addappid(1307820)
addappid(1307821, 1, "d32fd3b2d481d6ae6a60ef32c28152e6a54eb8689377f089ee5c3505c21d12d9")
