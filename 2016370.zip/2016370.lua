-- Lua provided by RyzenAPI
-- Game: Game: AppID 2016370

-- MAIN APPLICATION
addappid(2016370)
-- Game: addappid(2016370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016371, 1, "9b5a63b8344cdd968022f3c8bad06e55ce8bd094b29f4b3124786c2f97a3deb4")
addappid(2115540, 0, "7bc660222db7cc5b1914b314717b1cf250bcbb1aa9e4a894e847c16e1642d973")
