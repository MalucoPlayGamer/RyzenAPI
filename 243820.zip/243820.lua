-- Lua provided by RyzenAPI
-- Game: AppID 243820

-- MAIN APPLICATION
addappid(243820)

-- MAIN APP DEPOTS / PACKAGES
addappid(243821, 1, "2b552d76f633d6107bdb50e56fc4c012181aaed665dceca1cf93cbdd43c7adf3")
