-- Lua provided by RyzenAPI
-- Game: Mine the Gold

-- MAIN APPLICATION
addappid(1054930)
-- Game: addappid(1054930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054931, 1, "cc6b84c70eedb3d2e650f1d98b2fc49ded07d2cfc81cc05b369e014aef24f3ba")
