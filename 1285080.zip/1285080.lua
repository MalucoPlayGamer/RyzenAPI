-- Lua provided by RyzenAPI
-- Game: Gordian Rooms 1: A curious heritage

-- MAIN APPLICATION
addappid(1285080)
-- Game: addappid(1285080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285081, 1, "5c9389a1152ddb6f611cdc51f31dc0b181eeeda32ec4f9a5863db1e02c41c2d9")
