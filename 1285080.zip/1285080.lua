-- Lua provided by RyzenAPI
-- Game: Gordian Rooms 1: A curious heritage

-- MAIN APPLICATION
addappid(1285080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1285081, 1, "5c9389a1152ddb6f611cdc51f31dc0b181eeeda32ec4f9a5863db1e02c41c2d9")

