-- Lua provided by SkyAPI 
-- Game: Boneless Zombie
addappid(383700)
addappid(383701, 1, "72fd00e5af7c5e1729cbf41617ae62dd2f26d0dd55da20af16464d1089d409f0")
