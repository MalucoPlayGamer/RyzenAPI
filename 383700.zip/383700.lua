-- Lua provided by RyzenAPI
-- Game: 383700

-- MAIN APPLICATION
addappid(383700)
-- Game: addappid(383700)

-- MAIN APP DEPOTS / PACKAGES
addappid(383701, 1, "72fd00e5af7c5e1729cbf41617ae62dd2f26d0dd55da20af16464d1089d409f0")
