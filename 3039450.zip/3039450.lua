-- Lua provided by RyzenAPI
-- Game: 3039450

-- MAIN APPLICATION
addappid(3039450)
-- Game: addappid(3039450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039451, 1, "fb76e312a2eed0212870ba8fb51f373150a61863162ec614d1bdb08107d3cfa3")
