-- Lua provided by RyzenAPI
-- Game: AppID 1589460

-- MAIN APPLICATION
addappid(1589460)
-- Game: addappid(1589460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589461, 1, "99cae8409a83d8117d5d90a2fcdb604f0524beaff7559591fc36b11fb21b55e6")
