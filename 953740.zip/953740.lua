-- Lua provided by RyzenAPI
-- Game: AppID 953740

-- MAIN APPLICATION
addappid(953740)
-- Game: addappid(953740)

-- MAIN APP DEPOTS / PACKAGES
addappid(953741, 1, "7660c34eeeef9907b0170d86c74ea51909daf0dfdbe9f33d803171ec825de408")
