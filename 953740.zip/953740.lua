-- Lua provided by RyzenAPI
-- Game: 尸如潮水

-- MAIN APPLICATION
addappid(953740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(953741, 1, "7660c34eeeef9907b0170d86c74ea51909daf0dfdbe9f33d803171ec825de408")

