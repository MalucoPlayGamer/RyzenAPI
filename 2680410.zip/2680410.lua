-- Lua provided by RyzenAPI
-- Game: Taiko Frenzy

-- MAIN APPLICATION
addappid(2680410)
-- Game: addappid(2680410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680411, 1, "1a80985073baab160f89c4c9cfe42c152e5a8f6a00a4c872c4b675b07d7b4c8a")
