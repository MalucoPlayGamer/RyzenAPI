-- Lua provided by RyzenAPI
-- Game: Awakening of Celestial

-- MAIN APPLICATION
addappid(812590)

-- MAIN APP DEPOTS / PACKAGES
addappid(812591,0,"2aac77f7cc057bfae3837501990933b231b625b31eef7d4afb1a632f27aef3c7")

