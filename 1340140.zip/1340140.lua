-- Lua provided by RyzenAPI
-- Game: DRACU-RIOT!

-- MAIN APPLICATION
addappid(1340140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340141, 1, "acb4de520f422632f5cecc9fdf4e471dd6ae4beeb4c14f64db1a4e7985bb65fc")

