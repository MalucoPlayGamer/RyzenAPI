-- Lua provided by RyzenAPI
-- Game: 2619940

-- MAIN APPLICATION
addappid(2619940)
-- Game: addappid(2619940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619941, 1, "d7064a74fc85d13c67ad4d40355eb5550b457851add35298bdc1b026b03e3ce4")
