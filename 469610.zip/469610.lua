-- Lua provided by RyzenAPI
-- Game: Rick and Morty: Virtual Rick-ality

-- MAIN APPLICATION
addappid(469610)

-- MAIN APP DEPOTS / PACKAGES
addappid(469611, 1, "7abcef197bdb04642c4e4e7384e694c1d8e5d847888d64fdca45c9d415ebd928")
