-- Lua provided by RyzenAPI
-- Game: AppID 1058990

-- MAIN APPLICATION
addappid(1058990)
-- Game: addappid(1058990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058991, 1, "f7dbc1111e6137bae50f6c1860ff30ae14d245d50f91829f69727391beff06a1")
