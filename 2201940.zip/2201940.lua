-- Lua provided by RyzenAPI
-- Game: addappid(2201940)

-- MAIN APPLICATION
addappid(2201940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201941, 1, "786baefb7662e006fd710680e9ad8ad20bfc6b6ec4ce089d528438f1ae7b480a")
