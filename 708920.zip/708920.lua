-- Lua provided by RyzenAPI
-- Game: I Can See the Future

-- MAIN APPLICATION
addappid(708920)

-- MAIN APP DEPOTS / PACKAGES
addappid(708921, 1, "10a27bb090b0bbdcb2089ee7fb113427ada094285c0f327f426c04430890570b")

