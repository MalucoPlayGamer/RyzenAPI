-- Lua provided by RyzenAPI
-- Game: I Can See the Future

-- MAIN APPLICATION
addappid(708920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(708921, 1, "10a27bb090b0bbdcb2089ee7fb113427ada094285c0f327f426c04430890570b")

