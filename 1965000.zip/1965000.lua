-- 1965000's Lua and Manifest Created by Hubcap Manifest
-- Hotel Manager Simulator
-- Created: July 30, 2026 at 00:33:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1965000) -- Hotel Manager Simulator
-- MAIN APP DEPOTS
addappid(1965001, 1, "a1b2830693debcf1cb9616ac20ffa441007f9d94e0c46d58eb2d3c4e953e6354") -- Depot 1965001
setManifestid(1965001, "303072143407253476", 298537165)
addappid(1965002, 1, "154ac2a3f7651b99b936089d343f0b5837639614b3a61bc83054fae4315b00f0") -- Depot 1965002
setManifestid(1965002, "914941089429609621", 279810920)