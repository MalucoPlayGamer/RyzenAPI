-- Lua provided by RyzenAPI 
-- Game: AppID 1950260
addappid(1950260)
addappid(1950261, 1, "58890a664293025a32a546b6342084d3669c009ac307b7f9a9a3fa47a13cd63f")
