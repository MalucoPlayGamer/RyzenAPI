-- Lua provided by RyzenAPI
-- Game: Singularity Dungeon Demo

-- MAIN APPLICATION
addappid(1950260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950261, 1, "58890a664293025a32a546b6342084d3669c009ac307b7f9a9a3fa47a13cd63f")

