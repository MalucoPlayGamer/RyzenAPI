-- Lua provided by RyzenAPI
-- Game: Blaster Master Zero 3

-- MAIN APPLICATION
addappid(1588380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588381, 1, "1000aad03478b378ed05d268e6ce1390f6c530b78df816b5310c025fbfe0b0dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
