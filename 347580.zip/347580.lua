-- Lua provided by RyzenAPI
-- Game: AppID 347580

-- MAIN APPLICATION
addappid(347580)

-- MAIN APP DEPOTS / PACKAGES
addappid(347581, 1, "1d16626b7f3e5aab73195b67728baaa6511090cc5b2f4b111dcae8d8462dff69")

