-- Lua provided by SkyAPI 
-- Game: Aggression: Europe Under Fire
addappid(289580)
addappid(289581, 1, "683b8c237bfdcb06f0baddb0b390e1a6f00cb3b71cd7b092deb6548a72894465")
addappid(289582, 1, "469b328ea8d40d356c629cf51945f5dad64816927f78573755d8d910d99e04b0")
addappid(289583, 1, "1f657e90b14e135677051289ba4acc8bf961455cb8d12a7d87533a8c5f6169ce")
