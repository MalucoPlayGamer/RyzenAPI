-- Lua provided by RyzenAPI
-- Game: Game: Girls! Girls! Girls!? Demo

-- MAIN APPLICATION
addappid(1418530)
-- Game: addappid(1418530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418531, 1, "0d0f4fd3b8d868b4e4d4949ed22770921112eaa557082fbe5408e4caf1afcecf")
