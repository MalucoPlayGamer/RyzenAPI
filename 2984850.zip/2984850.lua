-- Lua provided by RyzenAPI
-- Game: Rita

-- MAIN APPLICATION
addappid(4911510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984850, 1, "a14b8b8ac9622cfe2aece6a263e569c67ea7f867a76b50b29d26d33e57689ab0") -- Rita
addappid(2984851, 1, "9593512c37d3146c8f9d815182cc610817fe1d60eb3631e76a892aad9e1fcd10") -- Depot 2984851
addappid(2984852, 1, "679cca2ab218e01c6aeb3648b3fa8f13693ccf90298fa7612687403ca37dd559") -- Depot 2984852
addappid(2984853, 1, "0336029f8a53a016cf50f97d560cf183afd1b883cc1a1ecf35093a565fbeca1c") -- Depot 2984853
addappid(4911510, 1, "5ecf940152e2fe86a0681956f038e177fd935a5cdd383cde78e96256a77ad1e1") -- Rita - Supporter Pack DLC - Depot 4911510

