-- Lua provided by RyzenAPI
-- Game: Girl Kill Zombies

-- MAIN APPLICATION
addappid(1156050)
addappid(1156450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156051, 1, "7d2ec380516d8bc12028a460b9cf7ed5f658952348f3679faedadb47ca1cbd20")
