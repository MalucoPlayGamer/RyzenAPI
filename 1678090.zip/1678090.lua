-- Lua provided by RyzenAPI
-- Game: Dark Home

-- MAIN APPLICATION
addappid(1678090)
-- Game: addappid(1678090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678091, 1, "04613c7599156e879d5d2abbc4e49f61005b148bb462d0c37fa1a753564a89ea")
