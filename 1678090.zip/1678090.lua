-- Lua provided by SkyAPI 
-- Game: Dark Home
addappid(1678090)
addappid(1678091, 1, "04613c7599156e879d5d2abbc4e49f61005b148bb462d0c37fa1a753564a89ea")
