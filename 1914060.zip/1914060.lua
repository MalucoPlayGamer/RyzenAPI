-- Lua provided by SkyAPI 
-- Game: Super Mini Mart
addappid(1914060)
addappid(1914061, 1, "61f0d4c2ad5f5b7d8919793bf3610b4629292d8ec7e72c6fb9d62cf7f8672ffd")
