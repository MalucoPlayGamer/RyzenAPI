-- Lua provided by RyzenAPI
-- Game: Super Mini Mart

-- MAIN APPLICATION
addappid(1914060)
-- Game: addappid(1914060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914061, 1, "61f0d4c2ad5f5b7d8919793bf3610b4629292d8ec7e72c6fb9d62cf7f8672ffd")
