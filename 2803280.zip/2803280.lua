-- Lua provided by RyzenAPI
-- Game: Dragon Is Dead

-- MAIN APPLICATION
addappid(2803280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803281, 1, "12e00b5c6ee0aee39380a7bd4071b2fc5bba906496d7844e0f92918afe895e71")
