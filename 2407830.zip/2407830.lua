-- Lua provided by RyzenAPI
-- Game: 2407830

-- MAIN APPLICATION
addappid(2407830)
-- Game: addappid(2407830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407831, 1, "ea23b0d0a0032c830f4a7465cffc83e39ed4632bf16182ddb029fadb0868cf80")
