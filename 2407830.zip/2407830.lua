-- Lua provided by RyzenAPI
-- Game: Trash Goblin

-- MAIN APPLICATION
addappid(2407830)
addappid(3710960)
addappid(3710970)
addappid(4148980)
addappid(4396120)
addappid(4601300)
addappid(4601310)
addappid(4601680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407831, 1, "ea23b0d0a0032c830f4a7465cffc83e39ed4632bf16182ddb029fadb0868cf80")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4461690)
