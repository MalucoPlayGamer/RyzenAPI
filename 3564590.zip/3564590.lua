-- Lua provided by RyzenAPI
-- Game: Rivers of Astrum: Daughter of Darkness

-- MAIN APPLICATION
addappid(3564590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564591, 1, "8ff22fc1f27aa4ff811e590a1994807efe586643955cfc172144377bf8bf1993")
