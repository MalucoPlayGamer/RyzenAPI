-- Lua provided by RyzenAPI
-- Game: 2159120

-- MAIN APPLICATION
addappid(2159120)
addappid(3475740)
-- Game: addappid(2159120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159121, 1, "93f714ad53740b18cadf0ac6e75cd1ab7c10e595ebede0f7937869d3ee4ba28f")
