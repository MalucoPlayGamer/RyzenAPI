-- Lua provided by RyzenAPI
-- Game: Widget Inc. Demo

-- MAIN APPLICATION
addappid(3207930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207931, 1, "483cb55282217c7e921146205c5aa47046090cffaedbab81d7ca906a511809e0")
