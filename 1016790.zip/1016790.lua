-- Lua provided by RyzenAPI
-- Game: Game: AppID 1016790

-- MAIN APPLICATION
addappid(1016790)
-- Game: addappid(1016790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016791, 1, "1cdb123bb0d774b4f7ed2791a2f19876e4dfcec233e64c68196f6114b9f3bd45")
addappid(1307400, 0, "5a5e6233b475ce12df59f9721ff3f67df5326cd5f45454b07c87fa4f208030a7")
