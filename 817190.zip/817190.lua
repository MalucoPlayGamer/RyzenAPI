-- Lua provided by RyzenAPI
-- Game: Next 3

-- MAIN APPLICATION
addappid(817190)

-- MAIN APP DEPOTS / PACKAGES
addappid(817191, 1, "8ccbace226010ad70ca60f2bdb6f7c31e33c49b22dc49f5a4010f0adb8319103")
