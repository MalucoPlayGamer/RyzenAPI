-- Lua provided by RyzenAPI
-- Game: Harem Hunter: Sex-ray Vision

-- MAIN APPLICATION
addappid(1490250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490251, 1, "9978841a66fb4dc880f6bf732c660b757812edb4ae7d327fe888d97530ee3b84")
addappid(1490252, 1, "2f38c78e16d25742e48364134fc73fa491ca814b4e4b920a9d3e421ebb3225a5")

