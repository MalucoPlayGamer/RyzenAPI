-- Lua provided by RyzenAPI
-- Game: Arcana: Heat and Cold. Stories

-- MAIN APPLICATION
addappid(2426310)
-- Game: addappid(2426310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426311, 1, "515a420da560be0a60e02e22f7b464a506e692ba5f68d8b8af1206e8fdaf7e61")
