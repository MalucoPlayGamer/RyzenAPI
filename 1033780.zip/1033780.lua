-- Lua provided by RyzenAPI
-- Game: AppID 1033780

-- MAIN APPLICATION
addappid(1033780)
-- Game: addappid(1033780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033781, 1, "7e705bdf2386ace687cb5681ddabb383c3cc2cb949419a430cc35623fd5c09b2")
