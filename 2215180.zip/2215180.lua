-- Lua provided by RyzenAPI 
-- Game: Virago: Herstory
addappid(2215180)
addappid(2215181, 1, "5daa052715947ccca9b41255c4fdf2db82819e674e68827b88b125295deab1c0")
