-- Lua provided by RyzenAPI
-- Game: addappid(2215180)

-- MAIN APPLICATION
addappid(2215180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215181, 1, "5daa052715947ccca9b41255c4fdf2db82819e674e68827b88b125295deab1c0")
