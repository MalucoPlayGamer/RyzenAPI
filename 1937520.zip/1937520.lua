-- Lua provided by RyzenAPI
-- Game: 1937520

-- MAIN APPLICATION
addappid(1937520)
-- Game: addappid(1937520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937521, 1, "97d33f3c426699df0d2d3eb0eb8ba02fa2a07f6cdfe8079459d39095dfaf60d2")
