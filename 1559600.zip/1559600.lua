-- Lua provided by RyzenAPI
-- Game: 1559600

-- MAIN APPLICATION
addappid(1559600)
-- Game: addappid(1559600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559601, 1, "04fb1bf1c8fdde44f763a3a56149135d1c06470e0176d631db99ccc1b4b145e4")
