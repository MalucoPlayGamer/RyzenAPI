-- Lua provided by RyzenAPI
-- Game: The Ranch of Rivershine

-- MAIN APPLICATION
addappid(1559600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1559601, 1, "04fb1bf1c8fdde44f763a3a56149135d1c06470e0176d631db99ccc1b4b145e4")

