-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Character Variety Pack

-- MAIN APPLICATION
addappid(2053880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053880,0,"930148b022b4bc9e71d16a5920b355e20c4fa0f0114ed30009916774b74b6e13")

