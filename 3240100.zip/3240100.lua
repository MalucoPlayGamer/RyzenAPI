-- Lua provided by RyzenAPI
-- Game: Rooster Demo

-- MAIN APPLICATION
addappid(3240100)
-- Game: addappid(3240100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3240101, 1, "d22f46204d45e670584f3c81b8bbd18585226e393983fcb09ab43163a244c5e9")
