-- Lua provided by RyzenAPI
-- Game: addappid(1342980)

-- MAIN APPLICATION
addappid(1342980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342981, 1, "7aad8db56a180d7e776baa723c8c922973ebd088075d9d761c497abe305d4f5f")
