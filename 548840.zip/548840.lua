-- Lua provided by RyzenAPI 
-- Game: A Rose in the Twilight
addappid(548840)
addappid(548841, 1, "0b6bbb1432bb4e531f29789ef3d032a9d33e6fac2d8023ae868c43e61a99fa84")
addappid(578280, 0, "f99c91ccd66cbe044e4e4ab6df0acb01ff715d0ca8230c4adcc44855132f2b49")
addappid(578281, 0, "c90c4f7b4957d0035d8b27e2d21249bc5a2fbc3a5c583e503eb90b6630818918")
