-- Lua provided by SkyAPI 
-- Game: iZolated
addappid(2799360)
addappid(2799361, 1, "ea1f0620904fff182d0221468365d8a51b7880934704604c520a0b12da97386d")
