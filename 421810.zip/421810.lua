-- Lua provided by RyzenAPI 
-- Game: OH! RPG!
addappid(421810)
addappid(421811, 1, "f795ee9a35bdc57ad65f95a20dba58edd8c30eef4012e487b858ba952b0f3e96")
addappid(464720, 0, "4a239f72bae619acffff4c9631840ab01af2d3fa5df0d5b9e5e4b3ad70f8765b")
