-- Lua provided by RyzenAPI
-- Game: CORVUS

-- MAIN APPLICATION
addappid(1219520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219521, 1, "a51c6403789c862c1379036c579c3814ee0e46c3122a7f2fa5150799614188a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
