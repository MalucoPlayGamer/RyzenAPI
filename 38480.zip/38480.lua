-- Lua provided by SkyAPI 
-- Game: Earthworm Jim
addappid(38480)
addappid(38481, 1, "6778a7f58d926166ed32d1f84241ff1b10a0b7145ca2ca0077ad0f7c70801607")
addappid(38482, 1, "25aa08933e66b7b47200d27a59da2d7853f12df589e7479a4c324af1e636c28f")
addappid(38483, 1, "826eb98a82d4c9e3d7ab327001926694cf02e676a1cbde059fdd9c0641b2acd7")
