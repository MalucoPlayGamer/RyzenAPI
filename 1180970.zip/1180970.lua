-- Lua provided by RyzenAPI
-- Game: Phantom Path

-- MAIN APPLICATION
addappid(1180970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180971,0,"09d01b64baf70055feb67f8c61c0951d616ee36c178a7020ba44b960340caa45")

