-- Lua provided by RyzenAPI
-- Game: Game: AppID 2956290

-- MAIN APPLICATION
addappid(2956290)
-- Game: addappid(2956290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956291, 1, "102be6f34ff893384a733ed3716abb5a38cd774cbff8efefbd3a668a98811698")
