-- Lua provided by SkyAPI 
-- Game: AppID 1079440
addappid(1079440)
addappid(1079441, 1, "c4e84a181b32db999ad004e7366906df6a1f4ece0476b330c40019cc12e8087d")
addappid(1079442, 1, "8caadd93a62cb1680c7350b3224d463d6a39c022cc495b86164aec4ed83bf2f6")
