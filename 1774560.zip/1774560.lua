-- Lua provided by RyzenAPI
-- Game: Dead Transmission

-- MAIN APPLICATION
addappid(1774560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774561, 1, "65bbcb84f6ec931d6d462c85af3cae17e0536408598424cb6c52fe4eb3d211e7")

