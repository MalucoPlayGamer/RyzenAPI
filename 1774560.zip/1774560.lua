-- Lua provided by SkyAPI 
-- Game: Dead Transmission
addappid(1774560)
addappid(1774561, 1, "65bbcb84f6ec931d6d462c85af3cae17e0536408598424cb6c52fe4eb3d211e7")
