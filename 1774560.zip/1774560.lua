-- Lua provided by RyzenAPI
-- Game: Dead Transmission

-- MAIN APPLICATION
addappid(1774560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774561, 1, "65bbcb84f6ec931d6d462c85af3cae17e0536408598424cb6c52fe4eb3d211e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
