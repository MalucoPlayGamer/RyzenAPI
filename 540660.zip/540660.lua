-- Lua provided by RyzenAPI
-- Game: Game: Sorcery Is for Saps

-- MAIN APPLICATION
addappid(540660)
-- Game: addappid(540660)

-- MAIN APP DEPOTS / PACKAGES
addappid(540661, 1, "2821c5fa9b61f37c3e8be1b0599d1e63a0639cf89cca6c2de29ee2c5ab52edcc")
