-- Lua provided by RyzenAPI
-- Game: AppID 866010

-- MAIN APPLICATION
addappid(866010)

-- MAIN APP DEPOTS / PACKAGES
addappid(866011, 1, "b617758c1f71353f19463a7e5ab207818cede863b937bb9f052edcd5a38c97e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1152700)
