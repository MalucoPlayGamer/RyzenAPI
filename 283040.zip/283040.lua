-- Lua provided by RyzenAPI
-- Game: Game: Paper Dungeons

-- MAIN APPLICATION
addappid(283040)
-- Game: addappid(283040)

-- MAIN APP DEPOTS / PACKAGES
addappid(283041, 1, "a95a116c995fa57b4111106f1353dc9d714a3b033f98633db92f962a6087f273")
addappid(283042, 1, "1ea3aeeed9ab3d59dc0fa537d28b08a799a19c9e8ff425373e1029bda64e7ff9")
addappid(283043, 1, "40b1b24d4d5f50f36f75daefd723ed12a4bcbe81ff86dbb9d7be7a2c67453029")
addappid(283044, 1, "f16ee041a87a5d806235ad6b98153c7ad63d7a8592a6a7c0eb7e8be0050b9649")
addappid(283045, 1, "9ae135cc7148c21587e1b4978ed70386123d6cf3b7b2db1396418d7e6d059f37")
addappid(283046, 1, "6269bfd470e60db43a39f6159af9a17a6d4cbb293a82ecf1d8ab42b3181fe237")
