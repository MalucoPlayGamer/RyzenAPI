-- Lua provided by RyzenAPI
-- Game: addappid(2963740)

-- MAIN APPLICATION
addappid(2963740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963741, 1, "187a0dc2e8fc136214a032883bcf4fe27388cc00ff3c56235dd6b125f815f96f")
