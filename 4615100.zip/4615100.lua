-- 4615100's Lua and Manifest Created by Hubcap Manifest
-- UrbanRail Metro Simulator
-- Created: July 30, 2026 at 14:12:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4615100) -- UrbanRail Metro Simulator
-- MAIN APP DEPOTS
addappid(4615101, 1, "fdc75ed1edd619a86916600589e21b08a0aed49d876417aeaf995379b7258d37") -- Depot 4615101
setManifestid(4615101, "3200028679103122085", 994684832)