-- Lua provided by RyzenAPI
-- Game: 修仙记——消消乐乱斗

-- MAIN APPLICATION
addappid(3135410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135411, 1, "2e546362a072b4ea5a25c8f2b3dad5d60825d68d70af5589fe17f38efc7f56c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
