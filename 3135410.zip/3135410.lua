-- Lua provided by RyzenAPI
-- Game: addappid(3135410)

-- MAIN APPLICATION
addappid(3135410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135411, 1, "2e546362a072b4ea5a25c8f2b3dad5d60825d68d70af5589fe17f38efc7f56c2")
