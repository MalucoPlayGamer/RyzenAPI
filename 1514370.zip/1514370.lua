-- Lua provided by RyzenAPI
-- Game: Game: Laid-Back Camp - Virtual - Fumoto Campsite

-- MAIN APPLICATION
addappid(1514370)
-- Game: addappid(1514370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514371, 1, "a7e458bddb3953f89230ba3790b357e0966fcd0589926fd1c00a980958623573")
