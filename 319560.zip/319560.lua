-- Lua provided by SkyAPI 
-- Game: Reprisal Universe
addappid(319560)
addappid(319561, 1, "844bbe9e4eda8cc7094223a05e5319c31eb0e334cb44aea2c672392304a5b188")
addappid(319562, 1, "a14b9aa9f1bf8b948280f3d72775f688fa065d44bd37bc3a4117c168bd587942")
