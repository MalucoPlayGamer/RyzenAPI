-- Lua provided by RyzenAPI
-- Game: Ultimate Zombie Defense 2 Demo

-- MAIN APPLICATION
addappid(2891500)
-- Game: addappid(2891500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891501, 1, "99dc069d265e11f1fabf2a5150162bd6ece30a540816c39777fdb587a99f91d0")
