-- Lua provided by RyzenAPI
-- Game: Game: Hotel Anatolia

-- MAIN APPLICATION
addappid(601010)
-- Game: addappid(601010)

-- MAIN APP DEPOTS / PACKAGES
addappid(601011, 1, "5f3d46c4a7e75fa116c7fc311a72ff971287ae88169f5481550b516fd1e95d06")
