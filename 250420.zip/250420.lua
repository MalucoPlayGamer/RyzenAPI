-- Lua provided by RyzenAPI
-- Game: AppID 250420

-- MAIN APPLICATION
addappid(250420)
-- Game: addappid(250420)

-- MAIN APP DEPOTS / PACKAGES
addappid(250421, 1, "b9f67b86a553410079258d03deb3444bfce6aef3feda2c51b210e047401a1cce")
addappid(250422, 1, "699b36e9f51c3131bbf147625a28647c267a8e3f6c4a1db76fea12d16bca7e32")
addappid(250423, 1, "ec25ebfba3a2e1a3be73d774691d317b6379dc1bbf75a0b31ea9a224d2178564")
addappid(250424, 1, "4aabe23bfd3f5e853e509da187824dcc5c45eb8749b209287d7ef9a7f301dd7a")
