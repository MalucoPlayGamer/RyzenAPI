-- Lua provided by RyzenAPI 
-- Game: Gnome Online
addappid(1878720)
addappid(1878721, 1, "19d7c930982bbc1eb3d651cb0096cf0f91f0611ee9bd0201925df3a5f9c1d379")
