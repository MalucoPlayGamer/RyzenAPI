-- Lua provided by RyzenAPI
-- Game: Game: The Hardest Dungeon

-- MAIN APPLICATION
addappid(834340)
-- Game: addappid(834340)

-- MAIN APP DEPOTS / PACKAGES
addappid(834341, 1, "39a2561905ca59bc52e4982638d35a89c9b26e72e8a55996d237a72ea5d74fe6")
