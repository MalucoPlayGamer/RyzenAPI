-- Lua provided by RyzenAPI
-- Game: addappid(2895130)

-- MAIN APPLICATION
addappid(2895130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895131, 1, "37a57bb6586dbee3d0001183be4dc0a3b5a1933d9f50d00688df2b4b68a747c8")
