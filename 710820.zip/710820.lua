-- Lua provided by RyzenAPI
-- Game: BELPAESE: Homecoming

-- MAIN APPLICATION
addappid(710820)
addappid(710823)

-- MAIN APP DEPOTS / PACKAGES
addappid(710822,0,"b0a6a34329022def9680e96e90b2cbe2faaff95bde8e890e99c60f566e7152bc")
