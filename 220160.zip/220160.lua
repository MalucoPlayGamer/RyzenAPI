-- Lua provided by RyzenAPI 
-- Game: Trials Evolution: Gold Edition
addappid(220160)
addappid(220161, 1, "bf3ef520db5b927ba0b7855a1ed169c397efcc212b0a7e00afec78b7bab5a0fd")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
