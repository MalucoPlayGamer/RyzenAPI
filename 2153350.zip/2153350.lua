-- Lua provided by RyzenAPI
-- Game: Brothers: A Tale of Two Sons Remake

-- MAIN APPLICATION
addappid(2153350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2153351, 1, "997da40415d881772fa4957ed930334f03fd3e2c3c3b6d5d832caadaba4d0d88")

