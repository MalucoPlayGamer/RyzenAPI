-- Lua provided by RyzenAPI
-- Game: Farm Frenzy: Refreshed

-- MAIN APPLICATION
addappid(1435780)
-- Game: addappid(1435780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435783,0,"f07610fb9cf3ed7524c720f6c8e525b8705d856b23505a10f251d2f3554a0555")
