-- Lua provided by RyzenAPI
-- Game: TOTEMS 2

-- MAIN APPLICATION
addappid(2050480)
-- Game: addappid(2050480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050481, 1, "d9c6ada7d6e07f0880f357e5a6f2434d09ded94d767040b5315a74f654da23d5")
