-- Lua provided by RyzenAPI
-- Game: Game: AppID 521340

-- MAIN APPLICATION
addappid(521340)
-- Game: addappid(521340)

-- MAIN APP DEPOTS / PACKAGES
addappid(521341, 1, "3355ade8a0f2ceecca7e34837815fe2d59fabcfeb0789c88847b697ec3ec41c0")
addappid(521850, 0, "28756c4074b9822b82ef0c7c8e9266912f2ddbb73b2711208a61838cadabe352")
addappid(533870, 0, "344d5387e81cf9f664fb61c12d7cdae4158a243e448af7878f2614bd6d6911f4")
