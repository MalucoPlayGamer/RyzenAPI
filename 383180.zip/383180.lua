-- Lua provided by RyzenAPI
-- Game: Dead Island: Riptide Definitive Edition

-- MAIN APPLICATION
addappid(383180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(383181, 1, "e5c6412779a7cf92956ffaff3eb32da68ea370d528486e7ffbcd7b9601462bbb")
addappid(383182, 1, "5c1b6415d57c0b21e681d8c23460674b8d1e95c84ff87344a5d03c670eda8cbd")
addappid(383183, 1, "ded166290682fe170f5c06761d1aa88a84f7732a7d127805ec09edf3669c82bf")
addappid(383184, 1, "9bc0a0eaf57a4aa6ee0cdd3c30602c28d98350665726b9f4cdaa6c36bea5bdfa")
addappid(383185, 1, "f13d473da23a036085aee096e676a68dd879bce0976c3cc4005422f21dc11ab5")
addappid(383186, 1, "dcc0d00b8402d2c88af290435591c5fbfed1af5f265123a27ebbd419b0cac3a3")
addappid(383187, 1, "060c81de6f6bf289f0008ce1c0d3eb1f1ac8b465c75d05ccfdb2824712867457")

