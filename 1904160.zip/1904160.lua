-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1904160)
addappid(1904163)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904162,0,"ea625171be4081cd1e629fb7e00e4b74125b070815dbeb501171fa7443d91a41")

