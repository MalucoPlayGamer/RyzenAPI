-- Lua provided by RyzenAPI
-- Game: Of Moons and Mania

-- MAIN APPLICATION
addappid(2185400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185401, 1, "b27cd4385275eebd33116908cdcdd31789b35897f6a5f7082004bad9c3e828ae")
addappid(2185402, 1, "54da94d8720fb60e2b987a9446a0e2b30089131b053dbbbefed64880357d0320")
