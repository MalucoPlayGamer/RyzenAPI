-- Lua provided by RyzenAPI
-- Game: Smart Game Booster PRO

-- MAIN APPLICATION
addappid(1289950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289950,0,"51844f98d8980d90abb687d240bb4e58c4a7b5207e74a384cb63c844d1540e7f")
