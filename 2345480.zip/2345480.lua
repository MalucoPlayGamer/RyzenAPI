-- Lua provided by RyzenAPI
-- Game: Alien Planet Survival

-- MAIN APPLICATION
addappid(2345480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345481, 1, "b33979f150db30c2b0792e12dea3f7173c149ff1e6dc3a87021648c837ca9847")
