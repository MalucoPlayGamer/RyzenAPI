-- Lua provided by RyzenAPI
-- Game: addappid(391280)

-- MAIN APPLICATION
addappid(391280)
addappid(502590)

-- MAIN APP DEPOTS / PACKAGES
addappid(391281, 1, "2057a5fcbd4645b685e37d47c788c8759ad05845d85d9c690c5e6c29dd9a57ea")
addappid(391282, 1, "e5ad0b6347047921136f28f0ca8f5a5817c17b81767db7b2f9c4b462d0dbf1b6")
