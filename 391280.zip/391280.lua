-- Lua provided by RyzenAPI
-- Game: Epic Manager - Create Your Own Adventuring Agency!

-- MAIN APPLICATION
addappid(391280)
addappid(502590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(391281, 1, "2057a5fcbd4645b685e37d47c788c8759ad05845d85d9c690c5e6c29dd9a57ea")
addappid(391282, 1, "e5ad0b6347047921136f28f0ca8f5a5817c17b81767db7b2f9c4b462d0dbf1b6")

