-- Lua provided by RyzenAPI
-- Game: addappid(2004470)

-- MAIN APPLICATION
addappid(2004470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004471, 1, "18b27fb71f0a7fb491f4adaecfb46568aae8890bec9f2a671418703120247b71")
