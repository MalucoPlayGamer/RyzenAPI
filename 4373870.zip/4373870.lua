-- Generated with Luie @ https://lua.tools/
-- 4373870 - Unpossess 2
-- Generated 2026-08-27 22:07:43 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4373870)

-- Main Depots
addappid(4373871, 1, "95552ea036475d4178ab079b0009703dbaea524f96a972c7213cfdcd1213c6b5")
setManifestid(4373871, "4234918034281298280", 10749599529)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
