-- Lua provided by RyzenAPI
-- Game: Miss Kawaii

-- MAIN APPLICATION
addappid(2125120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125121, 1, "608ce7be438a35d7510550b67e116c06bad3425aab7b7c9435f00198e87e8cba")

