-- Lua provided by RyzenAPI
-- Game: Song of Memories (Complete Scenario)

-- MAIN APPLICATION
addappid(752570)

-- MAIN APP DEPOTS / PACKAGES
addappid(752571, 1, "45a6dbc17750bb76b04c3033766cba389ffd367292f33079bd2447e13af83328")
addappid(752572, 1, "3d5ac901e1863e3eb9b62cef31f80e00c6e22c1ed37eeae59e97c0f9accbfa09")
addappid(752573, 1, "089092e1ddf4887c8c90a6bac6b1a9aae0f9c1bf054a52bf033910bef9d83334")
addappid(752574, 1, "3c24e0eecd627f4eef9d82609d5d0d8d6e52ef7c8c2e350d13a0cc75c483c9a2")
addappid(752575, 1, "c19259ed86330236f90eb250f1da0a48120123a7605e792826e46da4c7a48277")
addappid(752576, 1, "7180bb17f3339550b054ac8c7148960c2579085c1e8565a01ee1fa11c526deab")
addappid(752577, 1, "b378b963855dc49037636864bdf75f371b3045e87bc1eb7df4e126d8d4727278")
addappid(875191, 0, "f536261e871e69d808fc056b040245ddefc271d425455f43c3e912cda4e6c814")
addappid(875192, 0, "0766a40e79aef5d82fe2456310f464033faa63f60422d65e3ec931eb3ef589aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(875190)
addappid(875200)
addappid(875220)
