-- Lua provided by SkyAPI 
-- Game: AppID 2999800
addappid(2999800)
addappid(2999801, 1, "373ad2b3acc5d3319b55f90c954b4da5c4a20cda05c1a2cb6d0eb41b096b7d91")
