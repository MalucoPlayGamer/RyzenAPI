-- Lua provided by RyzenAPI
-- Game: addappid(570950)

-- MAIN APPLICATION
addappid(570950)

-- MAIN APP DEPOTS / PACKAGES
addappid(570951, 1, "e39316c37ab976eff9e66bfb2ccafed4ab3b3408b339f4fc7f734c32a99dfc0a")
