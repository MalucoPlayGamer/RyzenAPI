-- 3868760's Lua and Manifest Created by Hubcap Manifest
-- Exofinity Clicker
-- Created: June 26, 2026 at 06:24:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3868760) -- Exofinity Clicker
-- MAIN APP DEPOTS
addappid(3868761, 1, "5ca2546524aef55f64389ce005656d615d8b051947c2524e5ec59187714f4f1d") -- Depot 3868761
-- setManifestid(3868761, "5816435685399176659", 250504648)