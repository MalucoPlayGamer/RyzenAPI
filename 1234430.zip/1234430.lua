-- Lua provided by SkyAPI 
-- Game: Ad Infinitum
addappid(1234430)
addappid(1234431, 1, "0c6047a15ee208ec0eb1287142f4aef0765e16c05afb2ee9e03ac6999f48e08f")
addappid(2361660, 0, "6558f25748bb74095333618f39520b91e6b20a0fa470601b441f5a5c33a88df9")
