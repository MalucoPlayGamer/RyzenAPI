-- Lua provided by RyzenAPI
-- Game: Ad Infinitum

-- MAIN APPLICATION
addappid(1234430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234431, 1, "0c6047a15ee208ec0eb1287142f4aef0765e16c05afb2ee9e03ac6999f48e08f")
addappid(2361660, 0, "6558f25748bb74095333618f39520b91e6b20a0fa470601b441f5a5c33a88df9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
