-- Lua provided by RyzenAPI
-- Game: Dark Core

-- MAIN APPLICATION
addappid(773190)

-- MAIN APP DEPOTS / PACKAGES
addappid(773191,0,"9e818cf7073fb8d10c3f4af2eb41fafe8bea4ab5d105450521f07648cf69b5f9")

