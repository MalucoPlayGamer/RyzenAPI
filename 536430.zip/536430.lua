-- Lua provided by RyzenAPI
-- Game: addappid(536430)

-- MAIN APPLICATION
addappid(536430)

-- MAIN APP DEPOTS / PACKAGES
addappid(536431, 1, "c54ad8b99b043a8191cbb5f8bfbccc63c9d6940bee56b14757b98794001779c5")
addappid(536432, 1, "97af453a6dd769a4c91b5c1ac7e8341330a585051d283ed24e4f1ac678091bdc")
addappid(536433, 1, "7c791d827fc7efe6fb2f18fc34e4f5e884aba89c8492da5f3250c9a5e4ed55c3")
