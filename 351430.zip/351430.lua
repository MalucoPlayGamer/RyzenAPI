-- Lua provided by RyzenAPI
-- Game: 351430

-- MAIN APPLICATION
addappid(351430)
addappid(351431)
-- Game: addappid(351430)

-- MAIN APP DEPOTS / PACKAGES
addappid(351430,0,"14c5d50c4d139bc65a7314115ca98e7f5bdf8367dbf01632519c36e662e58d51")
