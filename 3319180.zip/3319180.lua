-- Lua provided by RyzenAPI
-- Game: AppID 3319180

-- MAIN APPLICATION
addappid(3319180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319181, 1, "1aaf7c00fe365099f43a3f34c389ba3538db53ff25d688afd59d4bf24a5eff56")

