-- Lua provided by RyzenAPI
-- Game: Contract

-- MAIN APPLICATION
addappid(409170)

-- MAIN APP DEPOTS / PACKAGES
addappid(409171, 1, "6b8ae622a3181e8eaee23a42cbcd9e09a42a10188be5a5e47a3db936e5726b81")

