-- Lua provided by RyzenAPI
-- Game: 2650900

-- MAIN APPLICATION
addappid(2650900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650900,0,"32da12f0acf07e03dd7649ce80af71a91234c803f84150ab8b52e9d9aad0d8bc")

