-- Lua provided by RyzenAPI
-- Game: Dark Sword: The Light of Ainn

-- MAIN APPLICATION
addappid(2755520)
-- Game: addappid(2755520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755521, 1, "b6d329c19b20ad2685e60388bf556a8a610286d5e804e1fee75306d139845134")
