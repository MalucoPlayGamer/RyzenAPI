-- Lua provided by RyzenAPI
-- Game: Todd's Spider Dream

-- MAIN APPLICATION
addappid(1384680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384681, 1, "efd03d3ff25049f790473e82963e87682ab65800b8321f6aee0a22fcc6168178")

