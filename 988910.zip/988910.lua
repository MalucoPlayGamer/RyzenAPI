-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball 3

-- MAIN APPLICATION
addappid(988910)

-- MAIN APP DEPOTS / PACKAGES
addappid(988911, 1, "18488965eb9d7dedc9290b91758328776fedbb61289ede109d18ec1cdefec751")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
