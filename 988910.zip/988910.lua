-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball 3

-- MAIN APPLICATION
addappid(988910)
-- Game: addappid(988910)

-- MAIN APP DEPOTS / PACKAGES
addappid(988911, 1, "18488965eb9d7dedc9290b91758328776fedbb61289ede109d18ec1cdefec751")
