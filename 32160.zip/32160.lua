-- Lua provided by RyzenAPI
-- Game: addappid(32160)

-- MAIN APPLICATION
addappid(32160)

-- MAIN APP DEPOTS / PACKAGES
addappid(32161, 1, "624eca041b6982dd447981fb4fe81a13f0640735d1b5d63d57c0e22eb83d51eb")
