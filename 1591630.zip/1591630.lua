-- Lua provided by RyzenAPI
-- Game: Bone Mayhem

-- MAIN APPLICATION
addappid(1591630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591631, 1, "5147a4e409837d93c44bb062653e1671f4ad1207f0eb393a4bdd9587e8fa8ee6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
