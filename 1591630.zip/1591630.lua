-- Lua provided by RyzenAPI
-- Game: 1591630

-- MAIN APPLICATION
addappid(1591630)
-- Game: addappid(1591630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591631, 1, "5147a4e409837d93c44bb062653e1671f4ad1207f0eb393a4bdd9587e8fa8ee6")
