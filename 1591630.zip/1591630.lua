-- Lua provided by SkyAPI 
-- Game: Bone Mayhem
addappid(1591630)
addappid(1591631, 1, "5147a4e409837d93c44bb062653e1671f4ad1207f0eb393a4bdd9587e8fa8ee6")
