-- Lua provided by RyzenAPI 
-- Game: Hentai Natsuki
addappid(3512410)
addappid(3512411, 1, "d2a3a34349dfb373b8b148863c65abf1d71a52df4e40b92b9821939c735c7487")
