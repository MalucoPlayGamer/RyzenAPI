-- Lua provided by RyzenAPI
-- Game: Motelet

-- MAIN APPLICATION
addappid(4850970) -- Motelet

-- MAIN APP DEPOTS / PACKAGES
addappid(4850971, 1, "1b268754fdc36f5f6e373bf251714bd721d6906a56133c9daef6720d8c662610") -- Depot 4850971

