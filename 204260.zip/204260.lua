-- Lua provided by RyzenAPI
-- Game: Trine 2 Demo

-- MAIN APPLICATION
addappid(204260)

-- MAIN APP DEPOTS / PACKAGES
addappid(204261, 1, "f8d66dcb5687603a915c70b5fb1c25ff9d0824748ea1bf27431a409ae1cb117c")
