-- Lua provided by RyzenAPI
-- Game: addappid(2122144)

-- MAIN APPLICATION
addappid(2122144)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122144,0,"e7db22279e9786528820aa8dbeb12dc796896c2ccc28945cec787b95db1c2730")
