-- Lua provided by RyzenAPI
-- Game: Toaster Arena

-- MAIN APPLICATION
addappid(1726530)

