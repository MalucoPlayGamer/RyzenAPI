-- Lua provided by RyzenAPI
-- Game: Kama Bullet Heritage 2

-- MAIN APPLICATION
addappid(839890)

-- MAIN APP DEPOTS / PACKAGES
addappid(839891, 1, "31902fe024464568c87f3e6ecca27cba07d890710ac59c2656b574fdb7f120db")

