-- Lua provided by RyzenAPI
-- Game: 梦魇：无归 Nightmare without return

-- MAIN APPLICATION
addappid(2113540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113541, 1, "d5d9269c745787240db9c1794410ac7967652657346bd21257b1fefe955efdab")
