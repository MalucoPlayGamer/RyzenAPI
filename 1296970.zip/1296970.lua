-- Lua provided by RyzenAPI
-- Game: AppID 1296970

-- MAIN APPLICATION
addappid(1296970)
-- Game: addappid(1296970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296971, 1, "1ca19bbb94e75de41dd8c52d6acf85d530be62d83f53f5b49a833126237bf7fb")
