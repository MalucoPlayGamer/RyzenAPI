-- Lua provided by RyzenAPI 
-- Game: AppID 3260910
addappid(3260910)
addappid(3260911, 1, "f677a485a6c560b76d0dfa3fe61707c450283d330b4278777bc54e57635348ae")
