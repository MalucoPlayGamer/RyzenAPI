-- Lua provided by RyzenAPI
-- Game: 2233133

-- MAIN APPLICATION
addappid(2233133)
-- Game: addappid(2233133)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233133,0,"d06b7c9c63a0093f65b680c7e255bdc0d2a3c2e3f2c6dca4af975f2511977161")
