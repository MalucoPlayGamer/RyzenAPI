-- Lua provided by RyzenAPI
-- Game: Grand Emprise: Time Travel Survival

-- MAIN APPLICATION
addappid(2236300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2236301, 1, "7fd0aa047274e51f9d2a4697d1efe43216bf71bfb160435b2617e220272e17a1")

