-- Lua provided by RyzenAPI
-- Game: Grand Emprise: Time Travel Survival

-- MAIN APPLICATION
addappid(2236300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236301, 1, "7fd0aa047274e51f9d2a4697d1efe43216bf71bfb160435b2617e220272e17a1")
