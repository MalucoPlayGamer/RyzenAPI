-- Lua provided by RyzenAPI
-- Game: Crown Wars - Strategy Guide

-- MAIN APPLICATION
addappid(2727760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727760,0,"e5e4deb196f858ee7e271030e4ff0700e72057f3e5f53de1aac5d3ad13b9932d")
