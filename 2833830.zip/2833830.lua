-- Lua provided by RyzenAPI
-- Game: 2833830

-- MAIN APPLICATION
addappid(2833830)
-- Game: addappid(2833830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833831, 1, "2228c5b8a8e8978e26ab89fdd63c10b417d217e2764f91ddba35fb037fc6d604")
