-- Lua provided by RyzenAPI
-- Game: Ashwalkers

-- MAIN APPLICATION
addappid(1273690)
-- Game: addappid(1273690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273692,0,"5c87d14ba49419a79cfaa0ab3e8d1dcd1a83b66696facf74fef186f8ed8abd43")
