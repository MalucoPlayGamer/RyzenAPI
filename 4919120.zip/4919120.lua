-- Lua provided by RyzenAPI
-- Game: Incremental Frog

-- MAIN APPLICATION
addappid(4919120) -- Incremental Frog
-- addappid(4919121) -- Depot 4919121 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4919122, 1, "695ff15926695af8297508fd4bc26fc63d3420d524d8e67465a2ab6e2250e663") -- Depot 4919122
addappid(4919123, 1, "77ff3333a76ac0fc28e8dc12c03ee75b3b086128a30146156d06840fa11ea5fb") -- Depot 4919123

