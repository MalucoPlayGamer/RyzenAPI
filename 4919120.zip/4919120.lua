-- 4919120's Lua and Manifest Created by Hubcap Manifest
-- Incremental Frog
-- Created: August 05, 2026 at 13:40:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4919120) -- Incremental Frog
-- MAIN APP DEPOTS
addappid(4919122, 1, "695ff15926695af8297508fd4bc26fc63d3420d524d8e67465a2ab6e2250e663") -- Depot 4919122
setManifestid(4919122, "4822007576121320835", 312465163)
addappid(4919123, 1, "77ff3333a76ac0fc28e8dc12c03ee75b3b086128a30146156d06840fa11ea5fb") -- Depot 4919123
setManifestid(4919123, "4203315108575857617", 287198191)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4919121) -- Depot 4919121 (empty depot)