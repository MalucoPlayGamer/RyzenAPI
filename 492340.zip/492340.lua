-- Lua provided by RyzenAPI
-- Game: Game: Pixel Cup Soccer 17

-- MAIN APPLICATION
addappid(492340)
-- Game: addappid(492340)

-- MAIN APP DEPOTS / PACKAGES
addappid(492341, 1, "694f10d642f8cb3b9093cac49d2dfdafc583312a4c97e76a646c31036282bd18")
