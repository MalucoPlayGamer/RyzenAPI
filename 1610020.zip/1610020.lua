-- Lua provided by RyzenAPI 
-- Game: KING HAJWALA
addappid(1610020)
addappid(1610021, 1, "4cbb31fd09c98706edb39a4bd2579895531317a689ab7357335215f0565ca52d")
