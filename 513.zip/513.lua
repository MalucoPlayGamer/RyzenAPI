-- Lua provided by RyzenAPI
-- Game: 513

-- MAIN APPLICATION
addappid(501)
addappid(502)
addappid(503)
addappid(504)
addappid(513)

-- MAIN APP DEPOTS / PACKAGES
addappid(513,0,"8c6b159dcd3e292b986cca9da6e7b0e18ee9e1012363be7bfc10372ccf5211ce")

