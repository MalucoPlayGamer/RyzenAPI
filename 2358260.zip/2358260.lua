-- Lua provided by RyzenAPI
-- Game: Cricket 24

-- MAIN APPLICATION
addappid(2358260)
-- Game: addappid(2358260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358261, 1, "d2480c418615ed3b9881736c176ae2e4d455b3394906ee7f34651ee1367897ac")
