-- Lua provided by RyzenAPI
-- Game: Spirit Guide Crucible

-- MAIN APPLICATION
addappid(619100)

-- MAIN APP DEPOTS / PACKAGES
addappid(619102,0,"d92397af5a90274955b8424d837fe2b76452f5407aeb31a572460c0fa26741f1")

