-- Lua provided by RyzenAPI
-- Game: Spork: The Manic Utensil Storm

-- MAIN APPLICATION
addappid(775590)

-- MAIN APP DEPOTS / PACKAGES
addappid(775591, 1, "b92f826f57d949cce181bab5e2b768d03a704003eeb03cd51ed7f0a29951fda8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
