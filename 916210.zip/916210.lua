-- Lua provided by SkyAPI 
-- Game: Fabrication
addappid(916210)
addappid(916211, 1, "34de75252627f7c99446b4887fdff39d7c7b2f29641dff38b4cac9f5d2b2c641")
