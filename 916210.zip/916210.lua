-- Lua provided by RyzenAPI
-- Game: 916210

-- MAIN APPLICATION
addappid(916210)
-- Game: addappid(916210)

-- MAIN APP DEPOTS / PACKAGES
addappid(916211, 1, "34de75252627f7c99446b4887fdff39d7c7b2f29641dff38b4cac9f5d2b2c641")
