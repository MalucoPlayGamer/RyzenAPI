-- Lua provided by RyzenAPI
-- Game: addappid(1477570)

-- MAIN APPLICATION
addappid(1477570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477571, 1, "1856befba774e010629edd5d68f5ea213f395230bca34f85902c7ba3c30fc97f")
