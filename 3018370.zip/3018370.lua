-- Lua provided by RyzenAPI
-- Game: Egg Surprise Demo

-- MAIN APPLICATION
addappid(3018370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018371, 1, "5be97a00335bea59fae7bc20f00bad8c226ea434e96aa4d9bde7e567e7e6f434")
