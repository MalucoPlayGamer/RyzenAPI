-- Lua provided by SkyAPI 
-- Game: AppID 480
addappid(480)
addappid(481, 1, "410c88e63fbfc9d184683d5734c8d22d4948c70b6292273888197ad98b678db4")
