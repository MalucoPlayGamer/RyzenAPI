-- Lua provided by RyzenAPI
-- Game: 480

-- MAIN APPLICATION
addappid(480)
-- Game: addappid(480)

-- MAIN APP DEPOTS / PACKAGES
addappid(481, 1, "410c88e63fbfc9d184683d5734c8d22d4948c70b6292273888197ad98b678db4")
