-- Lua provided by RyzenAPI
-- Game: Spacewar

-- MAIN APPLICATION
addappid(480)
addappid(110902)
addappid(447130)

-- MAIN APP DEPOTS / PACKAGES
addappid(481, 1, "410c88e63fbfc9d184683d5734c8d22d4948c70b6292273888197ad98b678db4")
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
