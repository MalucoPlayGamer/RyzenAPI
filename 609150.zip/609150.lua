-- Lua provided by RyzenAPI
-- Game: STAR OCEAN™ - THE LAST HOPE™ - 4K & Full HD Remaster

-- MAIN APPLICATION
addappid(609150)

-- MAIN APP DEPOTS / PACKAGES
addappid(609152,0,"7d2a7f3e6f4fe1d149fb986d089a11d32c4563c2ce7eae5370503968961929ad")
addappid(665130,0,"de4696e59c44d2339a8ed9f8001c4b6d4fd393127158220ccf3acae81d8220ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
