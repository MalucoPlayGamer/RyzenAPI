-- Lua provided by RyzenAPI
-- Game: STAR OCEAN™ - THE LAST HOPE™ - 4K & Full HD Remaster

-- MAIN APPLICATION
addappid(609150)

-- MAIN APP DEPOTS / PACKAGES
addappid(609152,0,"7d2a7f3e6f4fe1d149fb986d089a11d32c4563c2ce7eae5370503968961929ad")
addappid(665130,0,"de4696e59c44d2339a8ed9f8001c4b6d4fd393127158220ccf3acae81d8220ae")

