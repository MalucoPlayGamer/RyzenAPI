-- Lua provided by RyzenAPI
-- Game: Game: UFO Checkers

-- MAIN APPLICATION
addappid(1740120)
-- Game: addappid(1740120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740121, 1, "00a31cb16d8a163a624e263db458ffbe7cdf93108db968908b579ea0b14733ac")
