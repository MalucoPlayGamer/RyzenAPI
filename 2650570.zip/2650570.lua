-- Lua provided by RyzenAPI
-- Game: Game: Main Deity Space

-- MAIN APPLICATION
addappid(2650570)
-- Game: addappid(2650570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650571, 1, "a1762069b8541dad315e8a705561d4f51d57444ebf5a2be7969e17fecdb4f20c")
