-- Lua provided by RyzenAPI
-- Game: Mining Mechs

-- MAIN APPLICATION
addappid(1603180)
addappid(2695280)
addappid(3379790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603181, 1, "248a07b127815c2bfd1d9ebe079b9d2497536250d76b280a6b3bfa020d2c81e2")

