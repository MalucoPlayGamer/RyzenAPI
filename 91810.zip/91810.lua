-- Lua provided by RyzenAPI
-- Game: 91810

-- MAIN APPLICATION
addappid(91810)
-- Game: addappid(91810)

-- MAIN APP DEPOTS / PACKAGES
addappid(91811, 1, "3e655ecdab56312ce9765b66a7886d6199ed9b95f0c615425e893b04459df346")
addappid(91812, 1, "52d49cc648fa8172af24d965d44f4e227cfb27545e77444718791e98dbadcfa7")
