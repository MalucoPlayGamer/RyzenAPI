-- Lua provided by RyzenAPI
-- Game: Lily's Day Off

-- MAIN APPLICATION
addappid(575650)

-- MAIN APP DEPOTS / PACKAGES
addappid(575651, 1, "915c1a5ab70cad1cfe43831d9324df541b4bcc5c5499f4d9e2363efa75b53a30")
