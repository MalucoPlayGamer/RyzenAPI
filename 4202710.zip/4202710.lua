-- Lua provided by RyzenAPI
-- Game: Hocus Focus

-- MAIN APPLICATION
addappid(4202710) -- Hocus Focus

-- MAIN APP DEPOTS / PACKAGES
addappid(4202711, 1, "8a6f6f5306372d7cc1744fe5a3cef1f73dffcf83ae61d9ea603a9933880b06a5") -- Depot 4202711
addappid(4202712, 1, "a98b33053a509bcf519ec99fd2c961e8449c8f11d279befc96a3766c5da1f6c4") -- Depot 4202712

