-- Lua provided by RyzenAPI 
-- Game: AppID 2504030
addappid(2504030)
addappid(2504031, 1, "0b39dcd0b53db0dc324ce73ebdc62e56ba80d2848bcd401ae984636925eb9795")
