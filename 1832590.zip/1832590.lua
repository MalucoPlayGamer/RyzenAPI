-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Castle of Shikigami 2

-- MAIN APPLICATION
addappid(1832590)
-- Game: addappid(1832590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832590,0,"58ec0da833ee98fdbab16d9c61eadf572e4ef4d2a8f97edf448f6197f5f18aa2")
