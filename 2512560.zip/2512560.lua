-- Lua provided by RyzenAPI
-- Game: Game: Butcher's Creek

-- MAIN APPLICATION
addappid(2512560)
-- Game: addappid(2512560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512561, 1, "7f4c9ff00dc46ca0161dbbc661c3d3a03a0fa7eb3eda9a9caaaf3c81b7c0de51")
