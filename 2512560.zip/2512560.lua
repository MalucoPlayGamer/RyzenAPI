-- Lua provided by RyzenAPI 
-- Game: Butcher's Creek
addappid(2512560)
addappid(2512561, 1, "7f4c9ff00dc46ca0161dbbc661c3d3a03a0fa7eb3eda9a9caaaf3c81b7c0de51")
