-- Lua provided by RyzenAPI
-- Game: AppID 940980

-- MAIN APPLICATION
addappid(940980)

-- MAIN APP DEPOTS / PACKAGES
addappid(940981, 1, "9e44cb6f9b1603b0e640f218fcc199eaabed5e9e3367554ca0955cd9e28bfeb3")

