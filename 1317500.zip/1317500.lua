-- Lua provided by RyzenAPI 
-- Game: Lucidscape
addappid(1317500)
addappid(1317501, 1, "2128bdd9d0970330c4c6024ba8d0cb0144cff7025545f4736216844c5a7c536e")
