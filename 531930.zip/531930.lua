-- Lua provided by RyzenAPI
-- Game: 531930

-- MAIN APPLICATION
addappid(531930)
-- Game: addappid(531930)

-- MAIN APP DEPOTS / PACKAGES
addappid(531931, 1, "cf20dd38491cd20a34e8c1444ab0b7e0aac3db199fd691e515df7ae2833145b7")
