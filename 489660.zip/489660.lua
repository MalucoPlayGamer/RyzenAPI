-- Lua provided by RyzenAPI
-- Game: 489660

-- MAIN APPLICATION
addappid(489660)
addappid(516930)
-- Game: addappid(489660)

-- MAIN APP DEPOTS / PACKAGES
addappid(489661, 1, "cdc725dc28f4b91712c1c8fa46816429bd2dcb58e6a3d767c21b8078528fd8ce")
