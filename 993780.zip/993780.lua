-- Lua provided by RyzenAPI
-- Game: Jewel Match Solitaire Winterscapes

-- MAIN APPLICATION
addappid(993780)
-- Game: addappid(993780)

-- MAIN APP DEPOTS / PACKAGES
addappid(993781, 1, "3aface9ffc81da15c5172eacf36fee8a640b82ca3a77c49f5fac68bf55183053")
