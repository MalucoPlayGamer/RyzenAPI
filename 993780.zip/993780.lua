-- Lua provided by RyzenAPI 
-- Game: Jewel Match Solitaire Winterscapes
addappid(993780)
addappid(993781, 1, "3aface9ffc81da15c5172eacf36fee8a640b82ca3a77c49f5fac68bf55183053")
