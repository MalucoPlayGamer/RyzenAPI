-- Lua provided by RyzenAPI
-- Game: Don't Pee

-- MAIN APPLICATION
addappid(2753520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753521, 1, "eef68e92a38c3fa564cf9e2f37eb986c66354cae06ea45f1cb0d8a8b9fa56541")

