-- Lua provided by RyzenAPI
-- Game: Puzzle Puppers

-- MAIN APPLICATION
addappid(578430)
-- Game: addappid(578430)

-- MAIN APP DEPOTS / PACKAGES
addappid(578431, 1, "1b81aca0bad540233a4b569461b7eca9fe306d62df73ebfec136ed86ade23def")
addappid(578432, 1, "70f099fc24361d2e3b06a32bbd6b69a912260a7331d253320183a49bd4f6022b")
addappid(578433, 1, "de23d7714df03754344fa2bb27c62c6041ceda49189876e0c331ce14e448db1f")
