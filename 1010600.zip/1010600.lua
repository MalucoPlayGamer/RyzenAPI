-- Lua provided by RyzenAPI
-- Game: The Princess, the Stray Cat, and Matters of the Heart

-- MAIN APPLICATION
addappid(1010600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1010601, 1, "751eb042833e4861352f5b9a2208277fb79a3bc945578f2b163b068aa3dc1a0f")
addappid(1071230, 0, "1e823bf0de19f4a8d9fb2664de7bd4e2ede3591b774cfe30ade620d49eee9bf2")
addappid(1073000, 0, "8a3697d30e1f8f84a186252038a36b10f59cf3eeca63bd35628eb5dc7ca2e12d")
addappid(1076840, 0, "8361a5a0a70098ddf0d3b917cf655b3df23faa8d909b1af984b67f438da83cde")
addappid(1111640, 0, "40053366365788216201292157f7530ae0748c66d8db1c660384ca937e59f58c")
addappid(1111670, 0, "62fd3dbf9cbaa604df5c6f287a01f5a034ed901eac650fcb63b0e62630961e0f")
addappid(1111671, 0, "d91bbf48942826fce67ae678984db33c2c1c5e7690ddf0ca7f4f1c558ac94622")
