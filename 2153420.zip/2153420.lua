-- Lua provided by RyzenAPI
-- Game: Game: Don't Stop

-- MAIN APPLICATION
addappid(2153420)
-- Game: addappid(2153420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153421, 1, "0b3b9c6f7a776ea430d4a2d30cf3c41c42b1220d4910fd86e5cba2cadee91630")
