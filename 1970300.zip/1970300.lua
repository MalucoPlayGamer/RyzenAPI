-- Lua provided by RyzenAPI
-- Game: 1970300

-- MAIN APPLICATION
addappid(1970300)
-- Game: addappid(1970300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970301, 1, "fe39f9c2f617163c4c9c57cca726d0faae33374f3422a19d3d6a3a502b991387")
