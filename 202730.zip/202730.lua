-- Lua provided by RyzenAPI
-- Game: 202730

-- MAIN APPLICATION
addappid(202730)
-- Game: addappid(202730)

-- MAIN APP DEPOTS / PACKAGES
addappid(202731, 1, "22bc4df69aa78722f0246b8fc91d55caf97396ca08b1ea266a5538b2ea2de550")
addappid(202732, 1, "5b68dbc0d9be08e1f8672b08ea0914ee1f849b76febcd81f16a71c4ff191fde6")
addappid(202733, 1, "42e663785db064156d1bdbe3ec5bc0d357ffaeb04212ace1e4c9fcd510c68c54")
