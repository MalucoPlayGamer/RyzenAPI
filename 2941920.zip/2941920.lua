-- Lua provided by RyzenAPI
-- Game: 完美恋人~fragile love Demo

-- MAIN APPLICATION
addappid(2941920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941921, 1, "788b024f8a2c71315594d2673b195028c86b6e89deb6022b42e1908915af9556")
