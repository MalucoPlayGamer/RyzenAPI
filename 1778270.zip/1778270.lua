-- Lua provided by SkyAPI 
-- Game: AppID 1778270
addappid(1778270)
addappid(1778271, 1, "d1241efc0e9226580b9683d35b21806e2acc470a78f00b621275e24cc1149960")
