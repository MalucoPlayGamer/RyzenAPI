-- Lua provided by RyzenAPI
-- Game: addappid(2262080)

-- MAIN APPLICATION
addappid(2262080)
addappid(2262084)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262083,0,"31daa42b8a98cf4b7dc0d1704fad5f2434fbed33a67a2b4f1fb73c7234b1428f")
