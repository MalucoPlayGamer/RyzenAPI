-- Lua provided by RyzenAPI
-- Game: 1221640

-- MAIN APPLICATION
addappid(1221640)
addappid(1221641)
addappid(1221643)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221642,0,"7dade88030291f801cdeda59a93c0ad75a21e087e8e4d5e6159d3ddc0179a8bd")

