-- Lua provided by RyzenAPI
-- Game: 433480

-- MAIN APPLICATION
addappid(433480)
-- Game: addappid(433480)

-- MAIN APP DEPOTS / PACKAGES
addappid(433481, 1, "b3adbfc9242113c82305329882e8136124d13abfd2d19819985c1eb3a83955a5")
