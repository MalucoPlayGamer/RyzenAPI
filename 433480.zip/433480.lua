-- Lua provided by RyzenAPI
-- Game: Rayon Riddles - Rise of the Goblin King

-- MAIN APPLICATION
addappid(433480)

-- MAIN APP DEPOTS / PACKAGES
addappid(433481, 1, "b3adbfc9242113c82305329882e8136124d13abfd2d19819985c1eb3a83955a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
