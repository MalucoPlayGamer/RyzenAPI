-- 4695530's Lua and Manifest Created by Hubcap Manifest
-- A Game About Getting Bigger
-- Created: August 07, 2026 at 23:04:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4695530) -- A Game About Getting Bigger
-- MAIN APP DEPOTS
addappid(4695531, 1, "db837bf0258cbdb20afeb10702b222b932083f40576fd5ce37a5f62ee633824e") -- Depot 4695531
setManifestid(4695531, "1916942019779183396", 3973462961)
addappid(4695532, 1, "51c0407bed3ba93e1379cb2b8ec52653f4b51367496403f049865db243f1eb0d") -- Depot 4695532
setManifestid(4695532, "1045918203881081831", 4138887608)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4695700) -- A Game About Getting Bigger Supporter Pack