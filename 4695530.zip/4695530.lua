-- Lua provided by RyzenAPI
-- Game: A Game About Getting Bigger

-- MAIN APPLICATION
addappid(4695530) -- A Game About Getting Bigger
addappid(4695700) -- A Game About Getting Bigger Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4695531, 1, "db837bf0258cbdb20afeb10702b222b932083f40576fd5ce37a5f62ee633824e") -- Depot 4695531
addappid(4695532, 1, "51c0407bed3ba93e1379cb2b8ec52653f4b51367496403f049865db243f1eb0d") -- Depot 4695532

