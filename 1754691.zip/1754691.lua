-- Lua provided by RyzenAPI
-- Game: 1754691

-- MAIN APPLICATION
addappid(1754691)
-- Game: addappid(1754691)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754691,0,"bd5a71f908e3be7dac852e56dc93a2ea6a08fe5c9b28ffdaa6b587563cbb12fd")
