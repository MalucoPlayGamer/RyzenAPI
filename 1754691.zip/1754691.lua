-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Accessory "Animal Headband"

-- MAIN APPLICATION
addappid(1754691)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754691,0,"bd5a71f908e3be7dac852e56dc93a2ea6a08fe5c9b28ffdaa6b587563cbb12fd")

