-- Lua provided by RyzenAPI 
-- Game: Telegraphist 1920: Beats of War Demo
addappid(2613430)
addappid(2613431, 1, "3f69bed5b4c9945b90b82f40868bb9297d061f37b3508f12a39b59e74774e95d")
