-- Lua provided by SkyAPI 
-- Game: AppID 640700
addappid(640700)
addappid(640701, 1, "640aaae65c88d6c0a1da58fd16d7e04e47d6d3746f0329b9a5c3cfcc76e5107b")
