-- Lua provided by RyzenAPI
-- Game: addappid(2661440)

-- MAIN APPLICATION
addappid(2661440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661441, 1, "6daa54e05df20ac72268edb20dc3347348ea9cd8a3a8a5d0596f0451b3f9ed7b")
