-- Lua provided by RyzenAPI
-- Game: addappid(2389270)

-- MAIN APPLICATION
addappid(2389270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389271, 1, "cfa1506d59510e63221baf96a1c69f716268f912f0fa4ebf9fb39e156a96be83")
