-- Lua provided by RyzenAPI
-- Game: Crystals of Niberium

-- MAIN APPLICATION
addappid(728650)

-- MAIN APP DEPOTS / PACKAGES
addappid(728651, 1, "a7882d20a78cbcb3102c47c9d590ca5792111e651b50e816a273e30bd62d7b1a")

