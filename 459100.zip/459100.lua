-- Lua provided by RyzenAPI 
-- Game: AppID 459100
addappid(459100)
addappid(459101, 1, "e56de7423ea29bf47593db2ac7b94a59dfeb8c1d8b699b1b843ccea5984e54da")
addappid(459102, 1, "f1c2d0914e5daaafa1e04de2f25098251138b3fffc96b13c457ce3332c47fd5a")
