-- Lua provided by RyzenAPI
-- Game: Glass Masquerade 2: Illusions Soundtrack

-- MAIN APPLICATION
addappid(2574950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574951, 1, "52e7b4fde221542da6ed96529f1f32cae73b97e3ad32e797de418f9b3ef304a0")
