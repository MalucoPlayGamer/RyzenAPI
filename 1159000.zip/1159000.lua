-- Lua provided by SkyAPI 
-- Game: AppID 1159000
addappid(1159000)
addappid(1159001, 1, "61312367a82bd73e0c3ea743be297add7d5f4b37adffb6e6ffc0615af8ea5e7c")
