-- Lua provided by RyzenAPI 
-- Game: AppID 1436230
addappid(1436230)
addappid(1436231, 1, "33d32b5f2aea1e6ec77b84632dd7f9d56d1583289193a01ced18a1c608306d18")
addappid(1436232, 1, "c7187faf46aab2427f6635063f45e787fbe54f6246c4b3fb47175139a66f12ac")
