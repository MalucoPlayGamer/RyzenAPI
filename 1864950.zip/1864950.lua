-- Lua provided by RyzenAPI
-- Game: Game: Beastieball

-- MAIN APPLICATION
addappid(1864950)
-- Game: addappid(1864950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864951, 1, "c3dda4cc4c3d5cc5b69389a9dd3ed1cce3d643163b4927f5f020972f67caeea0")
