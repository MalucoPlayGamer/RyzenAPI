-- Lua provided by RyzenAPI
-- Game: 2589440

-- MAIN APPLICATION
addappid(2589440)
addappid(2672210)
-- Game: addappid(2589440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589441, 1, "ed980819d67b8d3065b3244dcd3769805c0854f0e348279ce1db561a2b6f20ee")
