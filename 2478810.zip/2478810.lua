-- Lua provided by RyzenAPI
-- Game: Strangers on Paper

-- MAIN APPLICATION
addappid(2478810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478811, 1, "ce16974d55daa253c93de4373d9287795393af242b5f7c4296853c802e5c6fc1")
