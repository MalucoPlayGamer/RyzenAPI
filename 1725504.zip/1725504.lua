-- Lua provided by RyzenAPI
-- Game: Beat Saber: Skrillex – 'Ragga Bomb (feat. Ragga Twins)'

-- MAIN APPLICATION
addappid(1725504)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725504,0,"44726de5c447be13a030bb60373b66877a1cbfdb719a89e410c953877be366d5")

