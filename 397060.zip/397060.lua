-- Lua provided by RyzenAPI
-- Game: Faeria

-- MAIN APPLICATION
addappid(397060)
addappid(574570)
addappid(880520)
addappid(880521)
addappid(939940)
addappid(947950)
addappid(1054730)
addappid(1083830)
addappid(1083831)
addappid(1083832)
addappid(1083833)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(397061, 1, "7bfe84c05c83f4cf91a19efda2cbffea366559b9f66baaaacd20c458a7345d96")
addappid(397062, 1, "72d4fc8797bc7ff0a45f81f62cee1848e0ac6cc2f3c642ae3b2f313dca7f058e")
addappid(397063, 1, "75efb60b8c87f7df999fe14b8d69cb1d74f9a2257a5b32b7a08e290bb0772b7b")

