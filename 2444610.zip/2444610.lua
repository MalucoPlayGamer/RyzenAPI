-- Lua provided by RyzenAPI
-- Game: addappid(2444610)

-- MAIN APPLICATION
addappid(2444610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444611, 1, "75fa2d5d08c5519ad2b2ec625954e111bf117ccf41178f6a1821ccbdd20fd625")
