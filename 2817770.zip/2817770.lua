-- Lua provided by RyzenAPI
-- Game: 2817770

-- MAIN APPLICATION
addappid(2817770)
-- Game: addappid(2817770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817771, 1, "1249dd1acff7deac119a708a4bf9ab612ed0049360294f316936848a60db3fdc")
