-- Lua provided by RyzenAPI 
-- Game: Catale
addappid(2922690)
addappid(2922691, 1, "2adb5aa0dc2671abb937107034835573795483d6c5b2b5cfd017324ec7752429")
