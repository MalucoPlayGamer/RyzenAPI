-- Lua provided by RyzenAPI
-- Game: addappid(2847120)

-- MAIN APPLICATION
addappid(2847120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2847121, 1, "d0d6f3bc5cb7c2035315152a7c81fb8d9e8b69be41262b3030a987898b76db3a")
