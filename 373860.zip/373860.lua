-- Lua provided by RyzenAPI
-- Game: Apothecarium: The Renaissance of Evil - Premium Edition

-- MAIN APPLICATION
addappid(373860)

-- MAIN APP DEPOTS / PACKAGES
addappid(373861, 1, "9053dfbf916fe0c188f18f7dbb7f12d447bd5b12b29ed1b0df2271ef48daf619")
addappid(373863, 1, "cc61bd7bde072ef52e80603b11f5d8c1f7344794f1041047f00432f7880ad84f")
addappid(373864, 1, "de2f4469a051d9b61b39e69a593f4cf67da25db3f64b4f5eee316c8ca341c758")
addappid(373865, 1, "630889573ff1138495fda3e89955d89a4a6a37f18b2f3effa4768231bfd28cd4")
addappid(373866, 1, "8025d099728c283d6fcf8748baef947315f94b07891d861f60e28cdf5db58f7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
