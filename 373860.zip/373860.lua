-- Lua provided by RyzenAPI 
-- Game: Apothecarium: The Renaissance of Evil - Premium Edition
addappid(373860)
addappid(373861, 1, "9053dfbf916fe0c188f18f7dbb7f12d447bd5b12b29ed1b0df2271ef48daf619")
addappid(373863, 1, "cc61bd7bde072ef52e80603b11f5d8c1f7344794f1041047f00432f7880ad84f")
addappid(373864, 1, "de2f4469a051d9b61b39e69a593f4cf67da25db3f64b4f5eee316c8ca341c758")
addappid(373865, 1, "630889573ff1138495fda3e89955d89a4a6a37f18b2f3effa4768231bfd28cd4")
addappid(373866, 1, "8025d099728c283d6fcf8748baef947315f94b07891d861f60e28cdf5db58f7d")
