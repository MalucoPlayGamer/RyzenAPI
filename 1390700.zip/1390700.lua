-- Lua provided by RyzenAPI
-- Game: Game: The Crackpet Show

-- MAIN APPLICATION
addappid(1390700)
addappid(2466420)
-- Game: addappid(1390700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390701, 1, "396949ef5363f95d19cab579593b442825caa7574764208b9c4b58cd8635f636")
