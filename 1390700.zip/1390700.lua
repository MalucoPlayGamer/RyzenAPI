-- Lua provided by SkyAPI 
-- Game: The Crackpet Show
addappid(1390700)
addappid(1390701, 1, "396949ef5363f95d19cab579593b442825caa7574764208b9c4b58cd8635f636")
addappid(2466420)
