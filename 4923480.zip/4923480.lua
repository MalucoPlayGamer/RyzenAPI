-- Lua provided by RyzenAPI
-- Game: FRAGLINE: Esports Manager

-- MAIN APPLICATION
addappid(4923480) -- FRAGLINE: Esports Manager

-- MAIN APP DEPOTS / PACKAGES
addappid(4923481, 1, "c279478b5bf2f02034e4a3d3d0d5281a00f3a302b922ed74437044da651a8a78") -- Depot 4923481

