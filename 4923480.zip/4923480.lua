-- 4923480's Lua and Manifest Created by Hubcap Manifest
-- FRAGLINE: Esports Manager
-- Created: August 26, 2026 at 17:42:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4923480) -- FRAGLINE: Esports Manager
-- MAIN APP DEPOTS
addappid(4923481, 1, "c279478b5bf2f02034e4a3d3d0d5281a00f3a302b922ed74437044da651a8a78") -- Depot 4923481
setManifestid(4923481, "4260966910654028202", 257692380)