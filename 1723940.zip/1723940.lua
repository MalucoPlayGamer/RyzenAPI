-- Lua provided by SkyAPI 
-- Game: MonoRaceVR Demo
addappid(1723940)
addappid(1723941, 1, "6e6371c0a80ced6d5761bd317ae2f95aa4d1800d45347ca7ac93faf00e88d9bc")
