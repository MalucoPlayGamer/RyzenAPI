-- Lua provided by RyzenAPI
-- Game: Metropolis 1998 Demo

-- MAIN APPLICATION
addappid(2728140)
-- Game: addappid(2728140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728141, 1, "acdf48a6f0b4d7a5a44bbdab44ce2e7a20255c507e31d273df9cece375eb0c56")
