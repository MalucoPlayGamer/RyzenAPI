-- Lua provided by RyzenAPI 
-- Game: AppID 3104440
addappid(3104440)
addappid(3104441, 1, "8c0ed31265f1a3f3a9968087cae1d37199f1705816e8dcd15855b51acfb99229")
