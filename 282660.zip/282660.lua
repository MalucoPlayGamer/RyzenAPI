-- Lua provided by RyzenAPI
-- Game: Easy™ eSports

-- MAIN APPLICATION
addappid(282660)

-- MAIN APP DEPOTS / PACKAGES
addappid(282661, 1, "f9c2c09bc856e12e5aa03dad4bf73cf7222eec7e013fc047b9e9ddb4ccb1c7fe")

