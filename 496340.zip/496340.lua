-- Lua provided by RyzenAPI
-- Game: Fighting Fantasy Legends

-- MAIN APPLICATION
addappid(496340)
-- Game: addappid(496340)

-- MAIN APP DEPOTS / PACKAGES
addappid(496341, 1, "429e0a763a2bd093380e1a9d67c89b0d1d160722f4600b803d47693de8f90168")
addappid(496342, 1, "a6e3cdcdc6f1f8fe7c3836bce72e643336e3ac45a590a0cfed8959f08de62c89")
addappid(496343, 1, "c52d9add6738a1193878ed710db872b40ca0f940bccf6cc357104544230152a0")
