-- Lua provided by RyzenAPI
-- Game: addappid(906634)

-- MAIN APPLICATION
addappid(906634)

-- MAIN APP DEPOTS / PACKAGES
addappid(910100,0,"f04c2bdb902ff3d58226a18bc76e7b08f8a2cd7ad41803ebc65893fff8e299c6")
addappid(910101,0,"22cc9d095082f280c78533850ee584f907bd50189a455565c3c29785923bdefb")
addappid(910102,0,"445ba6f80b4deced19b904a6920e9a84bd4fb2c4bcbd513edca86beaa997fbf3")
