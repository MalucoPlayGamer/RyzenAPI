-- Lua provided by RyzenAPI
-- Game: Slave Princess Finne ~ IF Story 2

-- MAIN APPLICATION
addappid(2320020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320021, 1, "dcba44a1f1e34bf959aa8eef007049bbb55c222cc715ff11bb30dabe4726e605")

