-- Lua provided by RyzenAPI
-- Game: Beyond The Diorama: Caribou World

-- MAIN APPLICATION
addappid(1488050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488051, 1, "7b14bc16302dbda92d3df52f866eb27a5baa9088275a20a624b3ca8b99e49b64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
