-- Lua provided by RyzenAPI 
-- Game: Beyond The Diorama: Caribou World
addappid(1488050)
addappid(1488051, 1, "7b14bc16302dbda92d3df52f866eb27a5baa9088275a20a624b3ca8b99e49b64")
