-- Lua provided by SkyAPI 
-- Game: AppID 1266740
addappid(1266740)
addappid(1266741, 1, "d1d612e51c519bf5fb64bcf9e08f98f871c5172f60cb43644b72cdd44be8e709")
addappid(1266742, 1, "50d2b507919d42633968cf4c196352a45bc60cbd848ba0c0eb2c581485b92c64")
