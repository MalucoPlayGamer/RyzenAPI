-- Lua provided by RyzenAPI
-- Game: 1356460

-- MAIN APPLICATION
addappid(1356460)
-- Game: addappid(1356460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356461, 1, "a46dfe9fedfe9cb4a63936cda638fc764d8bccda10ec36c5f810cad074089ed5")
addappid(1356462, 1, "7de719f5e45e18239c302c97b0e67650f7d9b3fed0142e1c61c7daffd020adde")
