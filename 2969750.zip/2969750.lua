-- Lua provided by RyzenAPI
-- Game: 2969750

-- MAIN APPLICATION
addappid(2969750)
-- Game: addappid(2969750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969750,0,"ae9e8ffbba4d5df70f49fe34a51ead7f3a081cb76453911db779e4ecf03a02e8")
