-- Lua provided by RyzenAPI
-- Game: GroundFall

-- MAIN APPLICATION
addappid(934260)

-- MAIN APP DEPOTS / PACKAGES
addappid(934261, 1, "c172b41982d95dfe950e8e14a2fe0dfec4775981d0fb756b24981d05c966d9a4")
