-- Lua provided by RyzenAPI
-- Game: addappid(1130620)

-- MAIN APPLICATION
addappid(1130620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130621, 1, "413cc73b0863f91a3e1e44733da9846746b58bc1d614d71d418b920ad25cb4e1")
