-- Lua provided by RyzenAPI
-- Game: Lumencraft Demo

-- MAIN APPLICATION
addappid(1740210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740211, 1, "ba5762caba8589644c8ba1dadec7af8410426402870c7eaa9e8989537194f1fb")

