-- Lua provided by RyzenAPI
-- Game: The Mobius Machine

-- MAIN APPLICATION
addappid(2281940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281942,0,"e9b5e877074cf654eae4c1758f8ae3ab622c8b23cc02ed300fdcbaec6e0be0db")

