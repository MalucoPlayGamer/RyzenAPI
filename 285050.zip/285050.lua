-- Lua provided by RyzenAPI
-- Game: Showtime!

-- MAIN APPLICATION
addappid(285050)

-- MAIN APP DEPOTS / PACKAGES
addappid(285051, 1, "ccb3da3525d7334c0a0f3848e0be38744b8c0b01b5499d4043b085bcb4e3c64e")

