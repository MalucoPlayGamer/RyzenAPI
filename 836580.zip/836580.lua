-- Lua provided by RyzenAPI
-- Game: Dead GroundZ

-- MAIN APPLICATION
addappid(836580)

-- MAIN APP DEPOTS / PACKAGES
addappid(836581,0,"99c7cd24c457b0e37ff1cb9b6deba4c64646b04fc02b9d5be13a32b7a2aecca9")

