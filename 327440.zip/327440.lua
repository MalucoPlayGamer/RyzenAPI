-- Lua provided by RyzenAPI
-- Game: Hail to the King: Deathbat

-- MAIN APPLICATION
addappid(327440)
-- Game: addappid(327440)

-- MAIN APP DEPOTS / PACKAGES
addappid(327441, 1, "2a6844e52b97672b0a3e2c6393b9f17635829fb634dcc357bc08e38cf096e1a7")
