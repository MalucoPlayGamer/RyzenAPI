-- Lua provided by RyzenAPI
-- Game: AppID 2697980

-- MAIN APPLICATION
addappid(2697980)
-- Game: addappid(2697980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697981, 1, "9c70699b5648f6a1d4eccc9de7ab363749a9aeed6d4533552e0f159f059c437e")
