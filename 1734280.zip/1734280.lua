-- Lua provided by RyzenAPI
-- Game: Card Storm Idle

-- MAIN APPLICATION
addappid(1734280)
addappid(1834090)
addappid(1842870)
addappid(1843570)
addappid(1844520)
addappid(1845190)
addappid(1845650)
addappid(1846220)
addappid(1849290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734281, 1, "0742054cf519fd30f7864302643537af4533fc756b7681babca2d29a4a2fbdde")

