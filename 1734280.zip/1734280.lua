-- Lua provided by RyzenAPI
-- Game: Card Storm Idle

-- MAIN APPLICATION
addappid(1734280)
-- Game: addappid(1734280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734281, 1, "0742054cf519fd30f7864302643537af4533fc756b7681babca2d29a4a2fbdde")
