-- Lua provided by RyzenAPI
-- Game: Vivaldia 2

-- MAIN APPLICATION
addappid(2623150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623151, 1, "0d0afe0715e6b9a61a4ce3cb5f37bf280c12745b8c21ce0f1f63f47933768587")
addappid(2623152, 1, "b1729acb307befc9fc441afb4e362799cb63aee362cc6431e07b57370027e65b")

