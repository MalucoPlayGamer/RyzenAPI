-- Lua provided by RyzenAPI
-- Game: We Who Are About To Die Demo

-- MAIN APPLICATION
addappid(2020240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020241, 1, "0bbda09e4359719105f10a848a3f837b9d1720e676415040b9c60b43195f8449")
