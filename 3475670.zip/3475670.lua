-- Lua provided by RyzenAPI
-- Game: addappid(3475670)

-- MAIN APPLICATION
addappid(3475670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3475671, 1, "64fac743d940dee8b7f4029890300732913bb8c777a92ceaf3a00be2238aefbb")
