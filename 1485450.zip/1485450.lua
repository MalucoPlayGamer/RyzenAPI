-- Lua provided by SkyAPI 
-- Game: Free Kick X
addappid(1485450)
addappid(1485451, 1, "83ad88523eef4be5c7f4139fd32d55a3cbd1ea44b3d71d9242f8b2febc847d73")
