-- Lua provided by SkyAPI 
-- Game: LineArt Jigsaw Puzzle - Airplanes
addappid(1616230)
addappid(1616231, 1, "fa62c6cc71d8d5c13c4f43e0c43cb45887a9843c3acf56e4277183ab13e5e42b")
addappid(1617730, 0, "ea735ecd322594a37249a401abf2cd6cd57851e7a4d867411320a4566361644b")
