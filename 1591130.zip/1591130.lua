-- Lua provided by RyzenAPI
-- Game: The Station: Escape Room

-- MAIN APPLICATION
addappid(1591130)
-- Game: addappid(1591130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591131, 1, "3e4ad68271eb3c24055de64d22891220556b48023a1d36d39ee24521fd9961d0")
