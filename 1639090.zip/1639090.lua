-- Lua provided by RyzenAPI
-- Game: Survive Isolation

-- MAIN APPLICATION
addappid(1639090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1639091, 1, "b34a3896d79c77a31ca2e501201e4af3e20c6f43fe92ddab845709dfa5d241e1")

