-- Lua provided by RyzenAPI 
-- Game: Survive Isolation
addappid(1639090)
addappid(1639091, 1, "b34a3896d79c77a31ca2e501201e4af3e20c6f43fe92ddab845709dfa5d241e1")
