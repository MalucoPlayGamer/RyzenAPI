-- Lua provided by RyzenAPI
-- Game: Everlasting Flowers Soundtrack Side B

-- MAIN APPLICATION
addappid(3114560)
-- Game: addappid(3114560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114590,0,"e0007fecb27998d78e4bc869e143d869e1e177bed9a79a676e801f6cde7da8fd")
addappid(3114591,0,"eae97e48984a061bd83643421ac291efb2b3cc9b45d3d133f66bfef9d2158346")
