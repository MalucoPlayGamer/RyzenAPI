-- Lua provided by RyzenAPI
-- Game: The Smurfs 2 - The Prisoner of the Green Stone

-- MAIN APPLICATION
addappid(2397500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397501, 1, "3feab20d9d9c5de04dcba3efb9d6f23ba79f1bf175e8e9c40d4c483cd1dd464f")

