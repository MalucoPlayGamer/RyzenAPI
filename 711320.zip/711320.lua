-- Lua provided by RyzenAPI 
-- Game: Battle of Frigates
addappid(711320)
addappid(711321, 1, "0b9730ed5c2bfc8689bbf4e13e1f77f88ac391f7f4f6c85f39830851cf37960e")
