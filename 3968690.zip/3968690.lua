-- Lua provided by RyzenAPI
-- Game: 除邪2(CHUXIE2)

-- MAIN APPLICATION
addappid(3968690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3968691, 1, "c6438974151527fbfaab6d48db73d20b620eb3e42771f01bfe816fc5c4b1077e")

