-- Lua provided by RyzenAPI
-- Game: Game: 除邪2(CHUXIE2)

-- MAIN APPLICATION
addappid(3968690)
-- Game: addappid(3968690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3968691, 1, "c6438974151527fbfaab6d48db73d20b620eb3e42771f01bfe816fc5c4b1077e")
