-- Lua provided by RyzenAPI
-- Game: Paper cut

-- MAIN APPLICATION
addappid(3811980)
-- Game: addappid(3811980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3811981, 1, "4f35894f7f6fca3398032fca98058a3b0e382161895fc80f58718e88f20689c0")
