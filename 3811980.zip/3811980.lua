-- Lua provided by RyzenAPI
-- Game: Paper cut

-- MAIN APPLICATION
addappid(3811980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3811981, 1, "4f35894f7f6fca3398032fca98058a3b0e382161895fc80f58718e88f20689c0")

