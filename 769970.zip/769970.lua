-- Lua provided by RyzenAPI
-- Game: AppID 769970

-- MAIN APPLICATION
addappid(769970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(769971, 1, "c7317c7725929e502bfa6b0a5e890dc6b6b38e39be1fabbe8da3f87c2e2e5153")
addappid(769972, 1, "e67f91b4bf3748e613fef88ac264f6b91f6917154e602cf74643ac7f8a344959")

