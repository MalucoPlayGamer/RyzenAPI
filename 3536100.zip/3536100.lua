-- Lua provided by RyzenAPI
-- Game: addappid(3536100)

-- MAIN APPLICATION
addappid(3536100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536101, 1, "1914ef28e79e87af367e8d50e43c36818feb705f78baa5f291e791900b85c4a6")
