-- Lua provided by SkyAPI 
-- Game: CYBERSLAYER: No Time to Regret
addappid(3536100)
addappid(3536101, 1, "1914ef28e79e87af367e8d50e43c36818feb705f78baa5f291e791900b85c4a6")
