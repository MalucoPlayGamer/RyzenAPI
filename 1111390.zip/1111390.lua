-- Lua provided by RyzenAPI
-- Game: ROBOTICS;NOTES DaSH

-- MAIN APPLICATION
addappid(1111390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111391, 1, "0f9c61da1a3073595a4a142823f126e091452107ae1915a40477bb4ef92e50dc")
addappid(1111392, 1, "ad493f7a8aa9ea8fae5729a885a05643d61880560dedff09816dba04e150d212")
addappid(1111393, 1, "cc127eb42cc94c5116179f6064770aa85658069fcadc38e8cc7bc4d9e15cc941")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
