-- Lua provided by RyzenAPI
-- Game: 9 Childs Street

-- MAIN APPLICATION
addappid(1895890)
-- Game: addappid(1895890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895891, 1, "76bd65cfa1cf0e6251d8dfea4d6ebebc1bae12610375531f6968465f18053615")
