-- Lua provided by RyzenAPI
-- Game: Fire Place

-- MAIN APPLICATION
addappid(933080)

-- MAIN APP DEPOTS / PACKAGES
addappid(933081, 1, "ae5412feaade5a01e04db3029595aedc71dd80ee4e6a03c61f04362a812e43b7")
addappid(933082, 1, "3436232af6e28078a6046f01da73a7be876d4bfeb763c88136e1662ac0d4cab7")
addappid(933083, 1, "388ea72ad3ae7e8f69d80f9fad5a8a417fc137b9f96a5da3754e743270093243")
