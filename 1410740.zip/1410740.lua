-- Lua provided by RyzenAPI
-- Game: IDIOT

-- MAIN APPLICATION
addappid(1410740)
-- Game: addappid(1410740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410741, 1, "52c5b8cc8799035e0de73c73e4f55f1e8ed16621e1545a671bdffdbdc113bfe0")
