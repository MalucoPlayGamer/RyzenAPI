-- Lua provided by RyzenAPI
-- Game: IDIOT

-- MAIN APPLICATION
addappid(1410740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1410741, 1, "52c5b8cc8799035e0de73c73e4f55f1e8ed16621e1545a671bdffdbdc113bfe0")

