-- Lua provided by RyzenAPI 
-- Game: Wobbledogs
addappid(1424330)
addappid(1424331, 1, "61cdfa42fe87a6545223dfb026473078ac79c527acd60fdf982cfa7177db9c72")
addappid(1424332, 1, "6af1e161d39bba5c556213b42a701c3466df95e6e6384a0b6463a9343cbdce02")
addappid(1424333, 1, "5b58f2e1a497753804dd7d88dfca5619b4c13c3fe580d8f49963dd8f0480184d")
