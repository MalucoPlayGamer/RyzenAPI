-- Lua provided by RyzenAPI
-- Game: Super Trench Attack!

-- MAIN APPLICATION
addappid(311870)
-- Game: addappid(311870)

-- MAIN APP DEPOTS / PACKAGES
addappid(311871, 1, "abf6b183a28b1a84b4381ec1ffee083128a43472cbd78016510fa6c2570567e5")
