-- Lua provided by RyzenAPI
-- Game: Super Trench Attack!

-- MAIN APPLICATION
addappid(311870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(311871, 1, "abf6b183a28b1a84b4381ec1ffee083128a43472cbd78016510fa6c2570567e5")

