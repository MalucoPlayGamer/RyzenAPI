-- Lua provided by RyzenAPI
-- Game: A Day in the Park

-- MAIN APPLICATION
addappid(1730670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730671, 1, "5c78b064ffb2d52e42042dce4a3b1a37c64dc3aff8be49fc21901d0a21cdd97f")
