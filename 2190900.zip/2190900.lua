-- Lua provided by RyzenAPI
-- Game: Game: HUDDAM

-- MAIN APPLICATION
addappid(2190900)
-- Game: addappid(2190900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190901, 1, "fb05d03704b4a4315883efeda8f4430459e1c2cf9d85f816c44f7418cfc513ca")
