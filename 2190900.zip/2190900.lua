-- Lua provided by RyzenAPI 
-- Game: HUDDAM
addappid(2190900)
addappid(2190901, 1, "fb05d03704b4a4315883efeda8f4430459e1c2cf9d85f816c44f7418cfc513ca")
