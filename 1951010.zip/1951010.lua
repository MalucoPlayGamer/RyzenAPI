-- Lua provided by RyzenAPI
-- Game: DLC Scenario: Itsuki's Homemade Lunch!

-- MAIN APPLICATION
addappid(1951010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951011, 1, "29eb15ad55a447b35c9a4efca706e049ca137a35a6b02d432220b0e35f4d15a3")
