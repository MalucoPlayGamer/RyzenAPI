-- Lua provided by RyzenAPI
-- Game: Tomb Raider V: Chronicles (2000)

-- MAIN APPLICATION
addappid(225000)

-- MAIN APP DEPOTS / PACKAGES
addappid(225001, 1, "56793b08606b910cad690e2fc0f660497ece7aff03add9ef4b5550119aa182c1")

