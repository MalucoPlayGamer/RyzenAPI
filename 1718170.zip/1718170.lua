-- Lua provided by RyzenAPI
-- Game: addappid(1718170)

-- MAIN APPLICATION
addappid(1718170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718170,0,"a5f4fd7c4d88c8eb3678be7b220a8c7b092a47af4ee0fade4b044fa05216689f")
