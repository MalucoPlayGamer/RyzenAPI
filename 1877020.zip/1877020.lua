-- Lua provided by RyzenAPI
-- Game: Jujutsu Kaisen Cursed Clash

-- MAIN APPLICATION
addappid(1877020)
addappid(2441230)
addappid(2579320)
addappid(2579330)
addappid(2579350)
addappid(2579360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1877021, 1, "f4499035fd1470f7dd2681e390fbbb1cd5160885c4f5b9fcc25183bc557e1568")
addappid(2544910, 0, "93b392c3ea70c794465f9b051e69db14b421062bc65bb03ebfdb25f7b70cf119")
addappid(2544920, 0, "410c45819542016f665d18953ecc4e08cc691f93f9952ceb7085309cfff121a5")

