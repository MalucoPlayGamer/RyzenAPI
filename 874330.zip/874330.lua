-- Lua provided by RyzenAPI
-- Game: Me And Dungeons

-- MAIN APPLICATION
addappid(874330)
addappid(874334)
-- Game: addappid(874330)

-- MAIN APP DEPOTS / PACKAGES
addappid(874333,0,"cf4aa6f5c0b55220673cf740e2e916ba71c37baac2c5d628bfa68ac5d9e3b2e0")
