-- Lua provided by RyzenAPI
-- Game: 血色天堂 2 Demo

-- MAIN APPLICATION
addappid(2847040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2847041, 1, "39ab6eeb0db9897ad1271123b479b14ae920d9008bd065e1f120dd4475510def")
