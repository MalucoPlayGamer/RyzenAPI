-- Lua provided by RyzenAPI
-- Game: Football Manager 2019 Resource Archiver

-- MAIN APPLICATION
addappid(872950)

-- MAIN APP DEPOTS / PACKAGES
addappid(872951, 1, "439ad05a316b0317acc0effc14236c83251c41214f71ea63ca0366752fef2970")
addappid(872952, 1, "2ef1377e2fa2a486a00288f8aeda42350fa7eff3037bc7486a51bc9a736e8191")
addappid(872953, 1, "a4a3762d14be1500ecc291057081cc29e5f1d883f479d41588614fdad9956664")
