-- Lua provided by RyzenAPI 
-- Game: AppID 2437750
addappid(2437750)
addappid(2437751, 1, "fbfeaffc471988000b182f3f11fb3018a63b5f28d740781e360cb287c60bd84a")
addappid(2437752, 1, "226225f2ea2b7bd6393e6e907de1e34a40c5d83c817b289be8941491f65b5457")
