-- Lua provided by RyzenAPI
-- Game: Game: SUPERVIVE

-- MAIN APPLICATION
addappid(1283700)
-- Game: addappid(1283700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283701, 1, "134aa92a7460f5a353591299ff98705f20ae3c02fa7263010847be2f4b5a7a0d")
