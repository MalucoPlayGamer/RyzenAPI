-- Lua provided by RyzenAPI
-- Game: 消失的妹妹(The Vanished Sister)

-- MAIN APPLICATION
addappid(2778320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2778321, 1, "d5c0c141823d65ba55f275e60141088d72adcf1f395868f3594e4da07bf4d230")

