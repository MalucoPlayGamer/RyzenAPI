-- Lua provided by RyzenAPI
-- Game: Super Treasure Arena

-- MAIN APPLICATION
addappid(338330)
-- Game: addappid(338330)

-- MAIN APP DEPOTS / PACKAGES
addappid(338331, 1, "50c275b500248b66ac7d70edf348c4b960eef3e6d00d2dba2589c4220dd18a82")
