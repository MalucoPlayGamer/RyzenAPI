-- Lua provided by RyzenAPI
-- Game: Volume

-- MAIN APPLICATION
addappid(365770)
addappid(395440)
addappid(395441)

-- MAIN APP DEPOTS / PACKAGES
addappid(365771, 1, "56a994ca292ca3263d07068b0b8a03ca6e377c753f18c81975ab660373c51efc")
addappid(365772, 1, "581adc5098846b45ba2c54f43cd3a8ba9eee27b26830d1bae58bcfaf028571db")

