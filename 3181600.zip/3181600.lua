-- Lua provided by RyzenAPI
-- Game: Beat Saber - Britney Spears - Womanizer

-- MAIN APPLICATION
addappid(3181600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181600,0,"10c59170966dd6bd878558785e5c7ef08128ef81f12f095117694db6d0e43fc7")

