-- Lua provided by RyzenAPI
-- Game: 101 Cats in Amsterdam

-- MAIN APPLICATION
addappid(3110520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110521, 1, "2cbac464de370b31965a7992f4b252f60af62dc9883c973c685eb34511f52136")

