-- Lua provided by RyzenAPI
-- Game: 1292370

-- MAIN APPLICATION
addappid(1292370)
-- Game: addappid(1292370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292371, 1, "41dc087d71eaabdc8898e9490cfefa74be956e2ee47c8e0298cbccb622ef966f")
