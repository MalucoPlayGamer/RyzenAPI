-- Lua provided by SkyAPI 
-- Game: LAZR - A Clothformer Demo
addappid(1292370)
addappid(1292371, 1, "41dc087d71eaabdc8898e9490cfefa74be956e2ee47c8e0298cbccb622ef966f")
