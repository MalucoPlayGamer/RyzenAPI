-- Lua provided by RyzenAPI
-- Game: Virtual Virtual Reality

-- MAIN APPLICATION
addappid(889480)
-- Game: addappid(889480)

-- MAIN APP DEPOTS / PACKAGES
addappid(889481, 1, "48c8cb86fe001530f1a1dbe3b5f34035b2e2992e223d326f99f873d72ed21156")
