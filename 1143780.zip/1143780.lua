-- Lua provided by RyzenAPI
-- Game: Graveyard Defender

-- MAIN APPLICATION
addappid(1143780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143781, 1, "4bb7b19459a38820af868cc43329a9066cce94dcce8c07c61ef7ef58c0df992d")

