-- Lua provided by RyzenAPI
-- Game: Deconstruction Simulator: Prologue

-- MAIN APPLICATION
addappid(2778430)
-- Game: addappid(2778430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778431, 1, "80ace82ea059f360c909550e5d44541e6506718851092412cdef4cd638496f3a")
