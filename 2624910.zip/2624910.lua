-- Lua provided by RyzenAPI
-- Game: addappid(2624910)

-- MAIN APPLICATION
addappid(2624910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624911, 1, "5ea0effdd59991dea3acdd21722757d0143414228cde452e91d54a2ae3c5b676")
