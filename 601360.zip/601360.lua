-- Lua provided by RyzenAPI
-- Game: Game: Portal: Revolution

-- MAIN APPLICATION
addappid(601360)
-- Game: addappid(601360)

-- MAIN APP DEPOTS / PACKAGES
addappid(601361, 1, "c585b091c6692f9d8a5cc733c9ea372be00edbe7429019f9316e56ed4b935268")
addappid(601362, 1, "9ab52f9b922eac1c57d69fb1059c9fdcce20516c2efc82d6db43e063eb6e97c8")
addappid(601363, 1, "5608ad50c107578d774e8083d4129f7ef1156222ad2859256a8cb5043e428979")
