-- Lua provided by SkyAPI 
-- Game: Do It With Hay
addappid(1396610)
addappid(1396611, 1, "d0550ea88f73f1526c6823365749a6a9bf2cc83ec6f3a8210c9c181d428c26df")
