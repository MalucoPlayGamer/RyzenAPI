-- Lua provided by RyzenAPI
-- Game: Do It With Hay

-- MAIN APPLICATION
addappid(1396610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1396611, 1, "d0550ea88f73f1526c6823365749a6a9bf2cc83ec6f3a8210c9c181d428c26df")

