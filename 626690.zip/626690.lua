-- Lua provided by RyzenAPI
-- Game: AppID 626690

-- MAIN APPLICATION
addappid(626690)
-- Game: addappid(626690)

-- MAIN APP DEPOTS / PACKAGES
addappid(626691, 1, "d13786cc9fbb38ba37c0da1e5a7148f908520d248bcb1b44cd3d368b4c569984")
