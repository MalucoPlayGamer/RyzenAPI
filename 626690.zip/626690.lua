-- Lua provided by RyzenAPI
-- Game: Sword Art Online: Fatal Bullet

-- MAIN APPLICATION
addappid(626690)
addappid(774821)
addappid(774822)
addappid(774823)
addappid(775480)
addappid(800450)
addappid(802610)
addappid(836810)
addappid(836811)
addappid(836812)
addappid(990310)
addappid(990320)
addappid(990330)
addappid(990340)
addappid(1010220)
addappid(4474260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(626691, 1, "d13786cc9fbb38ba37c0da1e5a7148f908520d248bcb1b44cd3d368b4c569984")
