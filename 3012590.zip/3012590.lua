-- Lua provided by RyzenAPI
-- Game: 3012590

-- MAIN APPLICATION
addappid(3012590)
-- Game: addappid(3012590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012592,0,"4c0a6573c067b8b0e5beebd5e8098ccf0d70070573d550d167c6d35f7a869792")
