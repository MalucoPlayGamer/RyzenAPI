-- Lua provided by RyzenAPI
-- Game: 704350

-- MAIN APPLICATION
addappid(704350)
-- Game: addappid(704350)

-- MAIN APP DEPOTS / PACKAGES
addappid(704351, 1, "1642c85ad43be7ad028446f636d12c246324d97b0a9dcd404a36c4cbb0a5ad74")
