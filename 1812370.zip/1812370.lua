-- Lua provided by RyzenAPI
-- Game: Game: Little Goody Two Shoes

-- MAIN APPLICATION
addappid(1812370)
-- Game: addappid(1812370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812371, 1, "36d5219affd1a0162ca0c54d1820627147db3975ca60b60623909981d8f5b3f1")
