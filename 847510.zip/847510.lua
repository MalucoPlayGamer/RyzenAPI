-- Lua provided by RyzenAPI
-- Game: Roller

-- MAIN APPLICATION
addappid(847510)

-- MAIN APP DEPOTS / PACKAGES
addappid(847511,0,"53d9ebe1dc713d645652ac6d0e8eeb3d6b2b7295953bc9d4a226755f5df04a28")

