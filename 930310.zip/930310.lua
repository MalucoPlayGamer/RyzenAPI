-- Lua provided by RyzenAPI
-- Game: Puzzle Plunder

-- MAIN APPLICATION
addappid(930310)
addappid(935080)
addappid(1445800)

-- MAIN APP DEPOTS / PACKAGES
addappid(930311, 1, "024eca2df546ce905ebd40e133035a65bc9a65260d1ab125e0328890a04cffbc")

