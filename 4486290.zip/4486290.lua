-- Lua provided by RyzenAPI
-- Game: Thunder Tank: Iron Shield

-- MAIN APPLICATION
addappid(4486290)

-- MAIN APP DEPOTS / PACKAGES
addappid(4486291,0,"40067d426a97e92aa4e8110e676d35c857223b86c0ad2fd1b84323a5390bd4ec")

