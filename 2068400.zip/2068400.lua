-- Lua provided by RyzenAPI
-- Game: addappid(2068400)

-- MAIN APPLICATION
addappid(2068400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068401, 1, "fc07d4f7887526600c25084b7d7c88adde82d24df474ab0a74aee615829c877d")
