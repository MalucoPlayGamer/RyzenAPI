-- Lua provided by RyzenAPI
-- Game: Radiant Cell

-- MAIN APPLICATION
addappid(2068400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2068401, 1, "fc07d4f7887526600c25084b7d7c88adde82d24df474ab0a74aee615829c877d")
