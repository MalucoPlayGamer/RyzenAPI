-- Lua provided by RyzenAPI
-- Game: Game: Nerobi

-- MAIN APPLICATION
addappid(2534250)
-- Game: addappid(2534250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534251, 1, "f986c2d704c6c803decc5bbe2392b2fbfa5f1836283f67a2e8b2b7cced600f5b")
addappid(2534252, 1, "1d1007d496e7819a647963a6128793714c685887669dfe3cb39a703a4af25217")
