-- Lua provided by RyzenAPI
-- Game: 1158111

-- MAIN APPLICATION
addappid(1158111)
-- Game: addappid(1158111)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158111,0,"9aaf0983692baa458a164715f4463a8f4bb6aad4e5e477afb95b8c5cee89823a")
