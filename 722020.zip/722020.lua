-- Lua provided by RyzenAPI
-- Game: Bitcoin Collector: Spinners Attack

-- MAIN APPLICATION
addappid(722020)
-- Game: addappid(722020)

-- MAIN APP DEPOTS / PACKAGES
addappid(722021, 1, "9ce5717362a6a44e0b45d4e63865108343ba357b727288000c929eaecd09ef97")
