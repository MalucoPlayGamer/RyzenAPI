-- Lua provided by RyzenAPI
-- Game: AppID 362810

-- MAIN APPLICATION
addappid(362810)

-- MAIN APP DEPOTS / PACKAGES
addappid(362811, 1, "a2d48e2096fa9f3b61c6684d0ca23e7a1b470dc427adefb1b34c3b42dffa1046")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
