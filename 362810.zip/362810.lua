-- Lua provided by RyzenAPI
-- Game: 362810

-- MAIN APPLICATION
addappid(362810)
-- Game: addappid(362810)

-- MAIN APP DEPOTS / PACKAGES
addappid(362811, 1, "a2d48e2096fa9f3b61c6684d0ca23e7a1b470dc427adefb1b34c3b42dffa1046")
