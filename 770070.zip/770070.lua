-- Lua provided by RyzenAPI
-- Game: Swords and Sandals 5 Redux: Maximus Edition

-- MAIN APPLICATION
addappid(770070)

-- MAIN APP DEPOTS / PACKAGES
addappid(770071, 1, "d16452a3b8fcfeb4a8fc9eba09422b3caad04e07e3ab9501109bec057c718f6d")
