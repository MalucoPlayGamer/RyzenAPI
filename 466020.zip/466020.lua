-- Lua provided by RyzenAPI
-- Game: 466020

-- MAIN APPLICATION
addappid(466020)
-- Game: addappid(466020)

-- MAIN APP DEPOTS / PACKAGES
addappid(466021, 1, "b335e38d02936e9b6848345a1293a4c9e43bd283373b633d63970db09d9b6f4b")
