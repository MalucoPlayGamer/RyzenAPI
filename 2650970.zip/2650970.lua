-- Lua provided by RyzenAPI
-- Game: addappid(2650970)

-- MAIN APPLICATION
addappid(2650970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650970,0,"fa0c997207ec0cca118bcc46e2d54d360080c4ebe987a823dd91e20e5919766e")
