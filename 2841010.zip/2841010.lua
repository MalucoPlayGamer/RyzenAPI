-- Lua provided by RyzenAPI
-- Game: Destiny Online

-- MAIN APPLICATION
addappid(2841010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841011, 1, "83288ea2c25af05c85435d47defcfb1eeb906d29d0e806a79f118c533841494d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
