-- Lua provided by RyzenAPI
-- Game: Destiny Online

-- MAIN APPLICATION
addappid(2841010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841011, 1, "83288ea2c25af05c85435d47defcfb1eeb906d29d0e806a79f118c533841494d")

