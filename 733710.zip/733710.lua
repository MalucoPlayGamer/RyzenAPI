-- Lua provided by RyzenAPI
-- Game: AppID 733710

-- MAIN APPLICATION
addappid(733710)

-- MAIN APP DEPOTS / PACKAGES
addappid(733711, 1, "8256cd1b72487c0449f7717fc7b6f4ce3c2620bb310881c400f2592593fb88ce")
addappid(733712, 1, "c9030d2b26281b8d8d79367a0df5ccf91270d79a2ded683517871c93dbf2a168")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
