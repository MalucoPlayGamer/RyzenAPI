-- Lua provided by RyzenAPI
-- Game: Rabbit Burn

-- MAIN APPLICATION
addappid(991600)

-- MAIN APP DEPOTS / PACKAGES
addappid(991601, 1, "e504dbe79d02e75070cbec68f6e472756f4f064cdf0d7c4fd00c2a33bdcaf1d5")
