-- Lua provided by RyzenAPI
-- Game: Traffic Cop

-- MAIN APPLICATION
addappid(756340)

-- MAIN APP DEPOTS / PACKAGES
addappid(756341, 1, "0b7d9e44932605d8ea08d85aadacd483797e302213e673292d3894090613bcdc")

