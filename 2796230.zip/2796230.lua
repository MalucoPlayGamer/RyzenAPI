-- Lua provided by RyzenAPI
-- Game: Bunny Guntz

-- MAIN APPLICATION
addappid(2796230)
-- Game: addappid(2796230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796231, 1, "5b32595c1eb354dc6e3a6d4aa88dffc933b6567cb6857a1b39a269a9872c61e6")
