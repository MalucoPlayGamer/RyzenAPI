-- Lua provided by RyzenAPI
-- Game: addappid(243160)

-- MAIN APPLICATION
addappid(243160)
addappid(408070)

-- MAIN APP DEPOTS / PACKAGES
addappid(243162,0,"aae5e6c36b8fb5ea8cdb3b0e4502b7c2327899098c0bcf055531352f639a07d2")
addappid(243163,0,"620d8365a3dcec878707ad17e1c48933c5fdcba7db61a5139c0c3f091650b151")
addappid(243164,0,"4e48f0fa351051ec2191cd336aa25272d5fb18c5cdfbdd7a7a1cb11185a46a8a")
