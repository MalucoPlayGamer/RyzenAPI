-- Lua provided by RyzenAPI 
-- Game: AppID 831230
addappid(831230)
addappid(831231, 1, "b99f55f05a9517527de2a70490d5862eae5d7e3eaad918c2ed59fd315a1cda84")
