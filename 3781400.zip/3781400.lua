-- Lua provided by RyzenAPI
-- Game: 3781400

-- MAIN APPLICATION
addappid(3781400)
-- Game: addappid(3781400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781401, 1, "4da9defdf7056f1e6f36f84af1501c8f502481b887d72717b680ceffe04e09ff")
