-- Lua provided by RyzenAPI
-- Game: flood of zombies

-- MAIN APPLICATION
addappid(3347250)
-- Game: addappid(3347250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347251, 1, "81d2a8b29e4157abad95aedab0f0c612ac490ba7177bb33e712b1537de1a7560")
