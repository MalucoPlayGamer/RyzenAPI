-- Lua provided by SkyAPI 
-- Game: Rebellion Gaia
addappid(1519550)
addappid(1519551, 1, "9a612520c557df6d866e049c72771c43ccbf5892c0a8a95e8188f9fdf37c22d6")
