-- Lua provided by RyzenAPI
-- Game: Game: Rebellion Gaia

-- MAIN APPLICATION
addappid(1519550)
-- Game: addappid(1519550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519551, 1, "9a612520c557df6d866e049c72771c43ccbf5892c0a8a95e8188f9fdf37c22d6")
