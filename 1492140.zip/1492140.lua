-- Lua provided by RyzenAPI
-- Game: Game: Club Hentai: Girls, Love, Sex

-- MAIN APPLICATION
addappid(1492140)
-- Game: addappid(1492140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492141, 1, "6caad09749092994f17a3b8bc453a3e1439b31744b0dc63ba436fc08f0ee5e8f")
