-- Lua provided by RyzenAPI
-- Game: 魅魔新妻 Succubus Waifu

-- MAIN APPLICATION
addappid(1184400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184401, 1, "88e7dd6a8a9ce3e1947596d857d20e040dfbc32ef84c35c0472152a26acc30c0")
addappid(1184402, 1, "fefd81353a107b6de92a635bb54b88fd69cf6a2967b03708bea719d21bbb4612")

