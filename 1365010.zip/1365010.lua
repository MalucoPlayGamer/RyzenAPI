-- Lua provided by RyzenAPI
-- Game: Lost Potato

-- MAIN APPLICATION
addappid(1365010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365011, 1, "6df1f3e39c5199cc203df90a428405ab3dafbd3da109f58b514d30f66fb8c91f")
