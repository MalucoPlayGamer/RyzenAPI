-- Lua provided by RyzenAPI
-- Game: Game: The Great Escape

-- MAIN APPLICATION
addappid(814570)
-- Game: addappid(814570)

-- MAIN APP DEPOTS / PACKAGES
addappid(814571, 1, "fc9e8cba3d117f54860793c0526de87a0c13c2aa2f863d8a216e6d7722b21ab8")
