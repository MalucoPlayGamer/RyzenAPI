-- Lua provided by RyzenAPI
-- Game: xVASynth

-- MAIN APPLICATION
addappid(1765720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1765721, 1, "fe7b2dd8833f55083fbff4a24f37d56ecfff0f53863c0817c83a0f58a40eb497")

