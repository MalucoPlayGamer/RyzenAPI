-- Lua provided by RyzenAPI 
-- Game: Idling Gears
addappid(2285820)
addappid(2285821, 1, "15e8ef8b5bf63effaf869c0e394f28e50655bc0cc22cdb84e5d66b6f749eccc0")
