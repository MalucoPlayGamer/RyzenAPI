-- Lua provided by RyzenAPI
-- Game: Game: Idling Gears

-- MAIN APPLICATION
addappid(2285820)
-- Game: addappid(2285820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285821, 1, "15e8ef8b5bf63effaf869c0e394f28e50655bc0cc22cdb84e5d66b6f749eccc0")
