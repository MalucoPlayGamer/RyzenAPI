-- Lua provided by RyzenAPI
-- Game: Dave

-- MAIN APPLICATION
addappid(833980)

-- MAIN APP DEPOTS / PACKAGES
addappid(833981, 1, "b4ba25eb2f35e6dd8d578ce06543e03290068e2b1b437ce5c8b551f6c1e5195b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
