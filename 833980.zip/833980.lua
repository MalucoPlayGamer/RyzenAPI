-- Lua provided by RyzenAPI
-- Game: 833980

-- MAIN APPLICATION
addappid(833980)
-- Game: addappid(833980)

-- MAIN APP DEPOTS / PACKAGES
addappid(833981, 1, "b4ba25eb2f35e6dd8d578ce06543e03290068e2b1b437ce5c8b551f6c1e5195b")
