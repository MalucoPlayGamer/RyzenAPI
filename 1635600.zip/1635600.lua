-- Lua provided by RyzenAPI
-- Game: addappid(1635600)

-- MAIN APPLICATION
addappid(1635600)
addappid(1840900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635601, 1, "fece03bfe1d48573e4a73f36537cbb5bc29c994ce5391c075743c433b68e75b0")
