-- Lua provided by RyzenAPI
-- Game: 1997470

-- MAIN APPLICATION
addappid(1997470)
-- Game: addappid(1997470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997471, 1, "21c5cfb52304df2db2c79b0aa9f35c80be5c589a5032e306d30665bee5f1e4c0")
