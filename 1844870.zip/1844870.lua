-- Lua provided by RyzenAPI
-- Game: addappid(1844870)

-- MAIN APPLICATION
addappid(1844870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844871, 1, "25466b31b93f4473925ac0c6f3e7fd13771900a5bc344cec3f3722f6bf05c930")
