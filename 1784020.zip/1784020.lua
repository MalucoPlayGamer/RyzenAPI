-- Lua provided by RyzenAPI
-- Game: East Trapper

-- MAIN APPLICATION
addappid(1784020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1784021, 1, "94ea58d845c8caae779464570673c51d10b476ac582ce9568cb24fe0bb16f8c7")

