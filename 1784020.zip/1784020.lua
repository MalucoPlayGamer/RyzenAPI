-- Lua provided by RyzenAPI 
-- Game: East Trapper
addappid(1784020)
addappid(1784021, 1, "94ea58d845c8caae779464570673c51d10b476ac582ce9568cb24fe0bb16f8c7")
