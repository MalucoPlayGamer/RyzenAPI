-- Lua provided by RyzenAPI
-- Game: The Fox Hare Disaster: Chapter One

-- MAIN APPLICATION
addappid(3214910)
-- Game: addappid(3214910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214911, 1, "694cfcd8de87193f7be8b1aec260b792d4790551177ff5da6f758c673d965868")
