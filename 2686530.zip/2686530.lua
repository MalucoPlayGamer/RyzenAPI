-- Lua provided by RyzenAPI
-- Game: addappid(2686530)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(2686530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686532,0,"150bedb8ff60599115c9aa0efdc6fd4e34dc12cc8841db3d7f120c3dc55bda7f")
