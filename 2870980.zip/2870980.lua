-- Lua provided by RyzenAPI
-- Game: Border Pioneer Playtest

-- MAIN APPLICATION
addappid(2870980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870981, 1, "089a47a0fd4e60d313b018377654ce77b28690f165997db3c9507b75fd401d5a")
