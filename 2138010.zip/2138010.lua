-- Lua provided by RyzenAPI
-- Game: addappid(2138010)

-- MAIN APPLICATION
addappid(2138010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138011, 1, "2429d9ba46423ed141e67977000f4e64ba94f9b31c337fd744bcd1e23b050db2")
