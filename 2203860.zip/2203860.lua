-- Lua provided by RyzenAPI 
-- Game: Populous™
addappid(2203860)
addappid(2203861, 1, "749060be0e346fbc4389a07ed994cd5ea35397a1e6bc10a809b53853f83edf00")
