-- Lua provided by RyzenAPI
-- Game: Populous™

-- MAIN APPLICATION
addappid(2203860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203861, 1, "749060be0e346fbc4389a07ed994cd5ea35397a1e6bc10a809b53853f83edf00")

