-- Lua provided by RyzenAPI 
-- Game: SIMULACRA 2
addappid(1011190)
addappid(1011191, 1, "5f46b768617e823a9a3c4ba78c3ab9ba8fd6149c295b2d85026142701112879f")
