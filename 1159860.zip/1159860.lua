-- Lua provided by RyzenAPI
-- Game: Dash Dash World

-- MAIN APPLICATION
addappid(1159860)
-- Game: addappid(1159860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159861, 1, "5752a2a0119a527282eb82d56beef296cc64a65900b73c754a74040c0da1c81d")
