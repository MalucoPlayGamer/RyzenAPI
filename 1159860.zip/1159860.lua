-- Lua provided by RyzenAPI
-- Game: Dash Dash World

-- MAIN APPLICATION
addappid(1159860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159861, 1, "5752a2a0119a527282eb82d56beef296cc64a65900b73c754a74040c0da1c81d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
