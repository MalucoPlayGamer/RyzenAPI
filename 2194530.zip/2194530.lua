-- Lua provided by RyzenAPI
-- Game: Yog-Sothoth’s Yard

-- MAIN APPLICATION
addappid(2194530)
addappid(2699860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194531, 1, "6e4d968905352d244ba2c7560e36a41444e533a61d2cc9d5fcd571eb62621e63")

