-- Lua provided by RyzenAPI
-- Game: AppID 292910

-- MAIN APPLICATION
addappid(292910)

-- MAIN APP DEPOTS / PACKAGES
addappid(292911, 1, "05e969a9113dd23adc7205b57d9adf07a98c74720650e020a85f34907aff4609")
addappid(292912, 1, "d62f909c2f3197693df9d41a50f72279cb8fd44eb1b1006a367fc28d9202681d")
addappid(292913, 1, "f62f5ef4483e1d7542ab69555deb8e1f195b649cda087028c40c6cf8e92f9d7f")
addappid(292914, 1, "cf7530f0643a43708e557cd672b30c904d231da06985ba253410239dfb0c3a97")
addappid(292915, 1, "d816894559cee845f0a6e3e34ecff015e091cc3982065a35a8af8cabf02cf3ea")
addappid(292916, 1, "12811563e1df153d1e81372c58938ce0743a4b5f56d6b641c61d8267c1e676bb")
addappid(292917, 1, "da9d08d0fa8854d580b6a08d19f648ec3ac4b06302b80b7723402289af0ffbc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(567110)
