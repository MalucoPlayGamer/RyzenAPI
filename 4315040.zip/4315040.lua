-- 4315040's Lua and Manifest Created by Hubcap Manifest
-- Hearth and Hamlet
-- Created: August 19, 2026 at 12:05:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4315040) -- Hearth and Hamlet
-- MAIN APP DEPOTS
addappid(4315041, 1, "9a026c36ec2e999340ac2f8abfb6b3618b8ab5222b430be7fad4f6ffd3111ab0") -- Depot 4315041
setManifestid(4315041, "5256410707204114419", 932152968)
addappid(4315042, 1, "f794569cef99784d563efb86ffa0616f0810e356d8ee780483e03a32ab3f1c6d") -- Depot 4315042
setManifestid(4315042, "354776260394251968", 895132560)