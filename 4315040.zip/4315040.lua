-- Lua provided by RyzenAPI
-- Game: Hearth and Hamlet

-- MAIN APPLICATION
addappid(4315040) -- Hearth and Hamlet

-- MAIN APP DEPOTS / PACKAGES
addappid(4315041, 1, "9a026c36ec2e999340ac2f8abfb6b3618b8ab5222b430be7fad4f6ffd3111ab0") -- Depot 4315041
addappid(4315042, 1, "f794569cef99784d563efb86ffa0616f0810e356d8ee780483e03a32ab3f1c6d") -- Depot 4315042

