-- Lua provided by SkyAPI 
-- Game: Maze Art: Orange
addappid(1818790)
addappid(1818791, 1, "da3f7411c0cfb7c7a8239c2e55084200a3e12f7d89445b9a0087ec1e034ece2b")
