-- Lua provided by RyzenAPI
-- Game: Maze Art: Orange

-- MAIN APPLICATION
addappid(1818790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818791, 1, "da3f7411c0cfb7c7a8239c2e55084200a3e12f7d89445b9a0087ec1e034ece2b")
