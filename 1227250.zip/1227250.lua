-- Lua provided by RyzenAPI
-- Game: 小镇放置修仙

-- MAIN APPLICATION
addappid(1227250)
-- Game: addappid(1227250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227251, 1, "1b14580719103ccbf184327eb2b77dfcd37cecd8d8b10568098d1608266570bb")
