-- Lua provided by RyzenAPI
-- Game: Exit Together

-- MAIN APPLICATION
addappid(3333740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333741, 1, "7fa44b2c24cdd990958d660a9bcd6f76ac85152efbd06e46125685383ec040f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
