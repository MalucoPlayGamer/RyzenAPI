-- Lua provided by RyzenAPI
-- Game: 3333740

-- MAIN APPLICATION
addappid(3333740)
-- Game: addappid(3333740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333741, 1, "7fa44b2c24cdd990958d660a9bcd6f76ac85152efbd06e46125685383ec040f7")
