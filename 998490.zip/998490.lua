-- Lua provided by RyzenAPI
-- Game: Game: AppID 998490

-- MAIN APPLICATION
addappid(998490)
-- Game: addappid(998490)

-- MAIN APP DEPOTS / PACKAGES
addappid(998491, 1, "db3c18ebd2b9d537ef01b37dab69904f1b13638d2497fe02735f81581888bc84")
