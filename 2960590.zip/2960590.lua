-- Lua provided by RyzenAPI
-- Game: Unveiling the Unknown

-- MAIN APPLICATION
addappid(2960590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960591, 1, "a2f93acc1c318ea1a8a1be8039dff0a34abd50bf4be8e0a6145afff42ffe6d8a")
