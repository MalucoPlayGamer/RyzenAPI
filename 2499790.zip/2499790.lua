-- Lua provided by SkyAPI 
-- Game: Daybreakers Demo
addappid(2499790)
addappid(2499791, 1, "4e1c9a5e9b4faf458ddfad9745c11057c7c38ad31af7d84799e75505cae00fa7")
