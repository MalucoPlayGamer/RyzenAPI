-- Lua provided by RyzenAPI
-- Game: Game: Daybreakers Demo

-- MAIN APPLICATION
addappid(2499790)
-- Game: addappid(2499790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499791, 1, "4e1c9a5e9b4faf458ddfad9745c11057c7c38ad31af7d84799e75505cae00fa7")
