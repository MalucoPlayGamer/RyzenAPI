-- Lua provided by RyzenAPI
-- Game: Game: The Icon Battles: Game

-- MAIN APPLICATION
addappid(2381460)
-- Game: addappid(2381460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381461, 1, "560c6f270312549267b0c27ef1c8ca7702520d9c97971641371d240e35520005")
