-- Lua provided by RyzenAPI
-- Game: The Icon Battles: Game

-- MAIN APPLICATION
addappid(2381460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381461, 1, "560c6f270312549267b0c27ef1c8ca7702520d9c97971641371d240e35520005")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
