-- Lua provided by SkyAPI 
-- Game: The Icon Battles: Game
addappid(2381460)
addappid(2381461, 1, "560c6f270312549267b0c27ef1c8ca7702520d9c97971641371d240e35520005")
