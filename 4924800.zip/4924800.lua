-- 4924800's Lua and Manifest Created by Hubcap Manifest
-- Axion Racer
-- Created: August 06, 2026 at 23:52:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4924800) -- Axion Racer
-- MAIN APP DEPOTS
addappid(4924801, 1, "d612d83aeb25abbc31579071d7862ec04dbf4184c4a07c3a187e32b2d88fd50d") -- Depot 4924801
setManifestid(4924801, "7738024633384260333", 2913641689)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)