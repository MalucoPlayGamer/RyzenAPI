-- Lua provided by RyzenAPI
-- Game: 2884810

-- MAIN APPLICATION
addappid(2884810)
-- Game: addappid(2884810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884811, 1, "8a0f17ad21ee81770fa207c13743fd964822b5c45d6c2bbeeafcc5dd84dbec1f")
