-- Lua provided by RyzenAPI
-- Game: 100 hidden snails 2

-- MAIN APPLICATION
addappid(1549030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549031, 1, "df57c8eb444a7cb321bcd16b7d420e56581881f54c91c39aa05255db7a7b737a")

