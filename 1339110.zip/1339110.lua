-- Lua provided by RyzenAPI
-- Game: The Maze: Humanity

-- MAIN APPLICATION
addappid(1339110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339111, 1, "dd2d7fdc15cfc90a6a464936b24ea2cd9d4fa26bbdaac27131b430d53cce7d37")
