-- Lua provided by RyzenAPI
-- Game: addappid(2659590)

-- MAIN APPLICATION
addappid(2659590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659591, 1, "652618cedc2e8a244aad28b083685e1e0f0bff602f6cb80639ae429b30153a59")
