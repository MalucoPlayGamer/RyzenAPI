-- Lua provided by RyzenAPI
-- Game: 1024220

-- MAIN APPLICATION
addappid(1024220)
-- Game: addappid(1024220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024221, 1, "4425a08b88cb9b121510d19cd4f1319eb8f2e9f79eda11485f7e9636a44b52e6")
