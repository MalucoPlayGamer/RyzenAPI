-- Lua provided by RyzenAPI
-- Game: Blood On The Dusty Trail

-- MAIN APPLICATION
addappid(2411780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411781, 1, "30b88b83b88173455a831e446e2e4d309ff59ec3a66df485a6317204bc2842d0")
