-- Lua provided by RyzenAPI
-- Game: To Pixelia

-- MAIN APPLICATION
addappid(1954160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954161, 1, "332f2483767301ab094b5f487bec95a0d0595d293c04cc1a244f9af56736db56")
