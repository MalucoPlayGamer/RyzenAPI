-- Lua provided by RyzenAPI
-- Game: Desperate Place

-- MAIN APPLICATION
addappid(3058140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058141, 1, "d4f7732f4305f14411de00651566d9d732a2c4d62b0d7fda32108713798e4640")
