-- Lua provided by RyzenAPI
-- Game: Wet Girl

-- MAIN APPLICATION
addappid(1008710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008711, 1, "969e03b8763c4a6ebd452c33a98c39b2509efa386f59dbb7afbb1f1dbb67c7b1")
addappid(1058420, 0, "536d26fb8714ff634bfb1e6119b617b6a14c5f2c090a2a6d9bd887d02c82b578")
