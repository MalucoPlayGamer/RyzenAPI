-- Lua provided by RyzenAPI
-- Game: addappid(1396870)

-- MAIN APPLICATION
addappid(1396870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396871, 1, "d3d1143f9995b15c30765d48acb98b1fba9751289664dbdcdcddff74e66d98c9")
