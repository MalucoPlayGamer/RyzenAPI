-- Lua provided by RyzenAPI
-- Game: Fret Smasher Playtest

-- MAIN APPLICATION
addappid(1648350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648351, 1, "801140569045125acc78ef1dfe225d8308ae1093fc57b39dec15093feceb1c63")

