-- Lua provided by RyzenAPI
-- Game: Game: REKA

-- MAIN APPLICATION
addappid(1737870)
-- Game: addappid(1737870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737871, 1, "288b0a2a0e74dc9fa05b6bc7ff0cb545073f5cef5c2039549a4373491652e742")
