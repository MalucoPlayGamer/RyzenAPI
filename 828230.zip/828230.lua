-- Lua provided by RyzenAPI
-- Game: Dungeons of the dead

-- MAIN APPLICATION
addappid(828230)

-- MAIN APP DEPOTS / PACKAGES
addappid(828231, 1, "08077e31beae2a698110d5c3915f7d683235844e35e6d5425a7f5fe865e72425")
