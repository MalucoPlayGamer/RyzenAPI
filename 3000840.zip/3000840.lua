-- Lua provided by RyzenAPI
-- Game: Game: AppID 3000840

-- MAIN APPLICATION
addappid(3000840)
-- Game: addappid(3000840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000841, 1, "5e8f9ba193945ecc1bee733fad7a7c6129a9d1fb7847eaba5239862b2a34aaad")
