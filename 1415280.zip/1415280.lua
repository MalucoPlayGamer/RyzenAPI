-- Lua provided by RyzenAPI
-- Game: addappid(1415280)

-- MAIN APPLICATION
addappid(1415280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415281, 1, "77f073b0a6a87d3b168e531d00d0037053da7b69d5d3d0302feeab9673e8fb7f")
