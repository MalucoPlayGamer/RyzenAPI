-- Lua provided by RyzenAPI
-- Game: DFF NT: The Espers' Progeny Appearance Set for Terra Branford

-- MAIN APPLICATION
addappid(1046320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046320,0,"cc3c2a167268efed95d45d6bb650b0b223e00558f41f8f33b1e3e5a12e623fc9")

