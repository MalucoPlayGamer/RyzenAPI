-- Lua provided by RyzenAPI
-- Game: Duke Dashington Remastered

-- MAIN APPLICATION
addappid(894420)

-- MAIN APP DEPOTS / PACKAGES
addappid(894421, 1, "58b61036f8db75a61a6304c3ff77210e8649018a08410beff0eb207099bf6afd")
