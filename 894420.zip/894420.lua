-- Lua provided by RyzenAPI
-- Game: 894420

-- MAIN APPLICATION
addappid(894420)
-- Game: addappid(894420)

-- MAIN APP DEPOTS / PACKAGES
addappid(894421, 1, "58b61036f8db75a61a6304c3ff77210e8649018a08410beff0eb207099bf6afd")
