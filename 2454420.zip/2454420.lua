-- Lua provided by RyzenAPI
-- Game: Paragon Pioneers 2

-- MAIN APPLICATION
addappid(2454420)
addappid(2967720)
addappid(2971810)
addappid(3059310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454421, 1, "8011d7d792ebff0802121e75465bf36f60878e9778c7e474e71fa20b1606fc67")

