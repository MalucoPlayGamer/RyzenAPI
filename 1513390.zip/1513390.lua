-- Lua provided by RyzenAPI
-- Game: addappid(1513390)

-- MAIN APPLICATION
addappid(1513390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513391, 1, "b15f77d87047543ede1aece60ebb26ee1173cef5f85871a1ae68db76f59cef0d")
