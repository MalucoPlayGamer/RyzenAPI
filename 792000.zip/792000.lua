-- Lua provided by RyzenAPI 
-- Game: AppID 792000
addappid(792000)
addappid(792001, 1, "0d1db82ad3a2a74d259840ff1f737557429cf69d56d8196d9fcb36aac2ca1bb8")
addappid(792002, 1, "740458512616a8c7ab5593645f33298fee1c4ebb677491d0f19264822479a8ca")
