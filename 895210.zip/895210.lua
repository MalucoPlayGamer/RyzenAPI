-- Lua provided by RyzenAPI
-- Game: On Board Remastered

-- MAIN APPLICATION
addappid(895210)

-- MAIN APP DEPOTS / PACKAGES
addappid(895211, 1, "67ff673cb88f3c7642839e3fa7270fb7a0711bba0caa70240bfc87c172c52b87")
