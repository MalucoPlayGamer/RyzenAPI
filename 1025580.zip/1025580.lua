-- Lua provided by RyzenAPI
-- Game: Game: AppID 1025580

-- MAIN APPLICATION
addappid(1025580)
-- Game: addappid(1025580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025581, 1, "5f0976e0ac9252329c430716d8a1495cc444873eba2b60c01a6389ed758d316b")
