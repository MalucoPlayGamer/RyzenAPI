-- 4660980's Lua and Manifest Created by Hubcap Manifest
-- Temptation's Price - Episode 1
-- Created: August 27, 2026 at 06:26:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4660980) -- Temptation's Price - Episode 1
-- MAIN APP DEPOTS
addappid(4660981, 1, "36eca3f5e3ea1520484fdb08c2d479ad8b0bc07333560ff0abb02f0591d9086c") -- Depot 4660981
setManifestid(4660981, "170346698032465465", 2328209441)