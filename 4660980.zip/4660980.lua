-- Lua provided by RyzenAPI
-- Game: Temptation's Price - Episode 1

-- MAIN APPLICATION
addappid(4660980) -- Temptation's Price - Episode 1

-- MAIN APP DEPOTS / PACKAGES
addappid(4660981, 1, "36eca3f5e3ea1520484fdb08c2d479ad8b0bc07333560ff0abb02f0591d9086c") -- Depot 4660981

