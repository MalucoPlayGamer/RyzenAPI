-- Lua provided by RyzenAPI 
-- Game: Post Human W.A.R
addappid(462240)
addappid(462241, 1, "ecbe30be0cae2e185d90d6a9a5b0aeb099f799e36fccfd60ad5a2d9fee479bf7")
addappid(462242, 1, "92e38de2a88d2d34d818406df07ec0ee5029e24be53b4c8fe5f990df5987ea9a")
addappid(462243, 1, "807237f427ff2c42b3b3857f9c3d66db36784d0e43b81013ca4e9f2c25dd5ef2")
addappid(462244, 1, "90b76114aa5dd07e6e8be2ca04b2fa65686bd4ff066774bca12d815c0c9f253e")
