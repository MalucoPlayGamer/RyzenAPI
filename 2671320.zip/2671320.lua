-- Lua provided by RyzenAPI
-- Game: 2671320

-- MAIN APPLICATION
addappid(2671320)
-- Game: addappid(2671320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671321, 1, "d8d2ced31a8b855e16db22b6a2dad387a3d718d4897c5a34b140bbc60795d929")
