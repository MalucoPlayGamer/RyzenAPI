-- Lua provided by RyzenAPI
-- Game: The Hand of Merlin Demo

-- MAIN APPLICATION
addappid(1310710)
addappid(1310712)
addappid(1310713)
addappid(1310714)

-- MAIN APP DEPOTS / PACKAGES
addappid(600611,0,"42c9d2b3965a10255cd85707b25aeaf4379ed3d561092ca17f4ca875409d1789")
addappid(600613,0,"0d3a6405bbafa6cc1b40ad971d6056e4d3697a7e7ee87c394c13c5344fb4fe1a")
addappid(600616,0,"c28c482327093efe56aee67639df39fc5a447cedf7d9b11c154acf04ae0958a5")
addappid(600617,0,"474a7909eaf330fbedb051119e2992f0d2facf40b8d92176d885d88dccf89085")

