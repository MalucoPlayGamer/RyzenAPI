-- Lua provided by RyzenAPI
-- Game: Dream Park Story

-- MAIN APPLICATION
addappid(2119660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119661, 1, "485e324cb8105908cc03f4f7173cedf40e725a27458847360bbbd1b34a6966a3")

