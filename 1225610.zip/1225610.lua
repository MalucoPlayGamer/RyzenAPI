-- Lua provided by RyzenAPI
-- Game: ∀kashicverse-Malicious Wake-

-- MAIN APPLICATION
addappid(1225610)
addappid(1500700)
addappid(1543310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225611, 1, "7bf8e4a6fcbb9ff254db0cddf61bbc74580d2b5eab01ff820a1573ad2e8958cb")
