-- Lua provided by RyzenAPI
-- Game: Space Ghost Pirate Zombie Slayer

-- MAIN APPLICATION
addappid(553350)

-- MAIN APP DEPOTS / PACKAGES
addappid(553351,0,"6dfd154fbe0991319b96b484303ee9687b537a45d0bb5741517938d94329d863")

