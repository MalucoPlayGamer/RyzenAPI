-- Lua provided by RyzenAPI
-- Game: Date With a Girl: Mahjong

-- MAIN APPLICATION
addappid(1815060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815061, 1, "8d30716fafefbf9559004a634c2040128a31a041bfd285985f4901500c8f4fab")

