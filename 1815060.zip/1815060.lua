-- Lua provided by SkyAPI 
-- Game: AppID 1815060
addappid(1815060)
addappid(1815061, 1, "8d30716fafefbf9559004a634c2040128a31a041bfd285985f4901500c8f4fab")
