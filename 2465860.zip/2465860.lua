-- Lua provided by RyzenAPI
-- Game: 2465860

-- MAIN APPLICATION
addappid(2465860)
-- Game: addappid(2465860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465860,0,"b003aaaaa65b6ef9eedf7f8b053fbd4fb761e88046a0499ffef1f2524dfef73d")
