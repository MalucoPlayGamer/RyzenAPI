-- Lua provided by RyzenAPI
-- Game: Tales of Tomorrow: Experiment

-- MAIN APPLICATION
addappid(1189730)
-- Game: addappid(1189730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189731, 1, "bba2329b113a7e081fdb36ea6ddeb1341f8e2bc06f213eaa8bbb31520923a290")
