-- Lua provided by RyzenAPI
-- Game: Sea Chronicles

-- MAIN APPLICATION
addappid(2347290)
-- Game: addappid(2347290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347291, 1, "d926dc43486859d7605687050b31807be4e9d32c47bd7f0de6f512c0b3856a3d")
