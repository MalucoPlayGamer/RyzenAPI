-- Lua provided by RyzenAPI
-- Game: Sea Chronicles

-- MAIN APPLICATION
addappid(2347290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347291, 1, "d926dc43486859d7605687050b31807be4e9d32c47bd7f0de6f512c0b3856a3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
