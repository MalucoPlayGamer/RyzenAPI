-- Lua provided by RyzenAPI
-- Game: Alice49 EP.0 Diamonds and Cream Puffs

-- MAIN APPLICATION
addappid(2727810) -- Alice49 EP.0 Diamonds and Cream Puffs

-- MAIN APP DEPOTS / PACKAGES
addappid(2727811, 1, "0dd823e63a8d789fa7965821bbef0a0a5669a9305556d34b87dac59bb108edb4") -- Depot 2727811

