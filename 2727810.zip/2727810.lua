-- 2727810's Lua and Manifest Created by Hubcap Manifest
-- Alice49 EP.0 Diamonds and Cream Puffs
-- Created: August 04, 2026 at 22:45:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2727810) -- Alice49 EP.0 Diamonds and Cream Puffs
-- MAIN APP DEPOTS
addappid(2727811, 1, "0dd823e63a8d789fa7965821bbef0a0a5669a9305556d34b87dac59bb108edb4") -- Depot 2727811
setManifestid(2727811, "2341120120453669307", 2035200323)