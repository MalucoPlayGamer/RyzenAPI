-- Lua provided by RyzenAPI
-- Game: Game: Rogalia

-- MAIN APPLICATION
addappid(528460)
-- Game: addappid(528460)

-- MAIN APP DEPOTS / PACKAGES
addappid(528461, 1, "9d7e9270222d205a548f5652c2529faa9266e36eade762b4f25186466879e5c7")
addappid(528462, 1, "5cb2967b0d2ed87e8e9b4a5b9cf7940c7a5f43cfb8e388937d330dcf7b353b25")
addappid(528463, 1, "138002a88814536b02a1c9bb3493ab95f4fdddd75f03e42bb7b1d4c7a35d03e6")
