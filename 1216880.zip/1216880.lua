-- Lua provided by RyzenAPI
-- Game: Risen Kingdom

-- MAIN APPLICATION
addappid(1216880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216881, 1, "5ad1d0b318bd2c34282d1cd16630c5f38cf94937e5cd17a7ec8874210fbd8b3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
