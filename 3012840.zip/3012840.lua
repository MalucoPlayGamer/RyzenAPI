-- Lua provided by SkyAPI 
-- Game: AppID 3012840
addappid(3012840)
addappid(3012841, 1, "dfd71610002a4ced905aa302509019430d98f92b5f19eda16da7060d1b50ed2c")
