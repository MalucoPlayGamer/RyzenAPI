-- Lua provided by RyzenAPI
-- Game: Parking World: Build & Manage Demo

-- MAIN APPLICATION
addappid(3012840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012841, 1, "dfd71610002a4ced905aa302509019430d98f92b5f19eda16da7060d1b50ed2c")
