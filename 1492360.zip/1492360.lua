-- Lua provided by RyzenAPI
-- Game: Recipe for Disaster

-- MAIN APPLICATION
addappid(1492360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492361, 1, "58e1aae49216308edd67d61400a32e765ef444ec5a9de8000de4be4eeaedd82b")

