-- Lua provided by RyzenAPI 
-- Game: Recipe for Disaster
addappid(1492360)
addappid(1492361, 1, "58e1aae49216308edd67d61400a32e765ef444ec5a9de8000de4be4eeaedd82b")
