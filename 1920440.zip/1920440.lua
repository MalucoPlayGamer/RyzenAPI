-- Lua provided by RyzenAPI
-- Game: Big Tower Tiny Square 2

-- MAIN APPLICATION
addappid(1920440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920442,0,"a337b90a84790987e2ed411c52697ab9b86b9af3f8c9ef3265e71c0ec338247c")

