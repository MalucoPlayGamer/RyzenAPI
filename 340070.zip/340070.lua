-- Lua provided by RyzenAPI
-- Game: Game: Battle Ranch: Pigs vs Plants

-- MAIN APPLICATION
addappid(340070)
-- Game: addappid(340070)

-- MAIN APP DEPOTS / PACKAGES
addappid(340071, 1, "fde1a25dd21b450947b56844b6e5cbdc57c28dbec7e1b82d0ce8f580c5ebcc3a")
addappid(340072, 1, "7f2e8845ea0ebdb6b40bf18c88f5e00caf75118dae3d96daaeef0e6484c2220b")
addappid(340073, 1, "d04972fd499fae7c5cf4950bdfca8e97e904e0a41cfbabbfd6add38cb9ae72ab")
addappid(340074, 1, "ec34c1362a13e27cbf65a275a70d06f4710543b7b5d04b40849dca874c698a1d")
