-- Lua provided by RyzenAPI
-- Game: AppID 880580

-- MAIN APPLICATION
addappid(880580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(880581, 1, "1718aa99ffc4b95a9f2151b506ae3b369f99fb34db7f46bddaaaa171182c3a62")

