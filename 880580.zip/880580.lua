-- Lua provided by RyzenAPI 
-- Game: AppID 880580
addappid(880580)
addappid(880581, 1, "1718aa99ffc4b95a9f2151b506ae3b369f99fb34db7f46bddaaaa171182c3a62")
