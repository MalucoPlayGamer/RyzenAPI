-- Lua provided by RyzenAPI 
-- Game: AppID 1333960
addappid(1333960)
addappid(1333961, 1, "5f7749c6c9918cb3e31381527b1d8efbc14ace252623e70435c906db9dc912e5")
