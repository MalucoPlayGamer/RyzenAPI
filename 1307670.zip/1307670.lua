-- Lua provided by RyzenAPI
-- Game: The Unexpected Quest

-- MAIN APPLICATION
addappid(1307670)
-- Game: addappid(1307670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307671, 1, "52f7167b20217fb2a19ba7424da704b4dc96bc944a89e4489e8bfaee793ce1de")
