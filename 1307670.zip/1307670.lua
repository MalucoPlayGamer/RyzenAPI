-- Lua provided by SkyAPI 
-- Game: The Unexpected Quest
addappid(1307670)
addappid(1307671, 1, "52f7167b20217fb2a19ba7424da704b4dc96bc944a89e4489e8bfaee793ce1de")
