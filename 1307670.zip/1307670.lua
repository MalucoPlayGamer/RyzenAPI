-- Lua provided by RyzenAPI
-- Game: The Unexpected Quest

-- MAIN APPLICATION
addappid(1307670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1307671, 1, "52f7167b20217fb2a19ba7424da704b4dc96bc944a89e4489e8bfaee793ce1de")

