-- Lua provided by RyzenAPI
-- Game: Shipped

-- MAIN APPLICATION
addappid(1037190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037191,0,"f0ce8b641fe62547f5cce5b201b1f9dd946b49ffb7ee8ff4f3dd4bdf0c1b1fdf")
addappid(1037192,0,"303ed07f2d4946d3e506f8f5d5e1c8b07ae400a94b7c44a9a31abaf3fcb7aca2")
addappid(1037193,0,"5a4394e2d3e7ae96100140b29a029c12e00b1275165395aca6f089aadb51f6ea")
addappid(1037194,0,"ff4bae13f600c05e526f79cb256223189c42c99877b9dfb6f699c31becc34f31")

