-- Lua provided by RyzenAPI
-- Game: 948960

-- MAIN APPLICATION
addappid(948960)
-- Game: addappid(948960)

-- MAIN APP DEPOTS / PACKAGES
addappid(948962,0,"f15da3b2ea417dd147ad4f14086d3d9deec042962335095a4c8a08fdc7efa999")
addappid(948963,0,"7832f950cd39a812803a98ef4bcaeedc056565dd28449c620e78d00bf14b074a")
