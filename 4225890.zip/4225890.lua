-- Lua provided by RyzenAPI
-- Game: Desktop Detective

-- MAIN APPLICATION
addappid(4225890) -- Desktop Detective

-- MAIN APP DEPOTS / PACKAGES
addappid(4225891, 1, "19a52b7667fb227e3bcd8976f900a3b8a9d76185a70bd97cb47e6198431ad520") -- Depot 4225891
addappid(4225892, 1, "4c5df251bf76406baaadbb3864fec95d6a6b2f345bb186a9b750a73b81b35c21") -- Depot 4225892

