-- 4225890's Lua and Manifest Created by Hubcap Manifest
-- Desktop Detective
-- Created: August 21, 2026 at 22:33:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4225890) -- Desktop Detective
-- MAIN APP DEPOTS
addappid(4225891, 1, "19a52b7667fb227e3bcd8976f900a3b8a9d76185a70bd97cb47e6198431ad520") -- Depot 4225891
setManifestid(4225891, "5022436535227450894", 1385638364)
addappid(4225892, 1, "4c5df251bf76406baaadbb3864fec95d6a6b2f345bb186a9b750a73b81b35c21") -- Depot 4225892
setManifestid(4225892, "5615254574701096215", 1406321311)