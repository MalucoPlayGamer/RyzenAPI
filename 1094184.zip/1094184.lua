-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Sun Shangxiang "Race Queen Costume" / 孫尚香「レースクイーン風コスチューム」

-- MAIN APPLICATION
addappid(1094184)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094184,0,"b846ed49d117ae71e041922c3c430cc854c2eca0a03d9700bd12fe26ea3b7320")

