-- Lua provided by RyzenAPI
-- Game: Zopa

-- MAIN APPLICATION
addappid(2690760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690761, 1, "2edb11edf5783bdd9b02a4796ad8519e59c6cc6399401a7a0d2bbe82344e4c10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
