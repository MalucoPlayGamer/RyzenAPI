-- Lua provided by RyzenAPI
-- Game: Zopa

-- MAIN APPLICATION
addappid(2690760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690761, 1, "2edb11edf5783bdd9b02a4796ad8519e59c6cc6399401a7a0d2bbe82344e4c10")

