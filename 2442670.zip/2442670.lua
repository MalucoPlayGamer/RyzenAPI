-- Lua provided by RyzenAPI
-- Game: SS.Archives

-- MAIN APPLICATION
addappid(2442670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2442671, 1, "7e02de289789ddb78735ac51dfa14f02a4bb0820e8b0427fd4b9c401f3730404")

