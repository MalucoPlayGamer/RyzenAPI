-- Lua provided by RyzenAPI
-- Game: addappid(2442670)

-- MAIN APPLICATION
addappid(2442670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442671, 1, "7e02de289789ddb78735ac51dfa14f02a4bb0820e8b0427fd4b9c401f3730404")
