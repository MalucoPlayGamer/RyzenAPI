-- Lua provided by RyzenAPI
-- Game: addappid(456090)

-- MAIN APPLICATION
addappid(456090)

-- MAIN APP DEPOTS / PACKAGES
addappid(456091, 1, "44bcfa4320f1d506a3502f9a064e4e921dae3ee9b5bedc224da3430bcef7d368")
