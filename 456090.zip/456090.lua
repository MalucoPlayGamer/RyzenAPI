-- Lua provided by RyzenAPI
-- Game: DEAD SOME DAY

-- MAIN APPLICATION
addappid(456090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(456091, 1, "44bcfa4320f1d506a3502f9a064e4e921dae3ee9b5bedc224da3430bcef7d368")

