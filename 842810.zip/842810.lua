-- Lua provided by RyzenAPI
-- Game: AppID 842810

-- MAIN APPLICATION
addappid(842810)
addappid(864220)
-- Game: addappid(842810)

-- MAIN APP DEPOTS / PACKAGES
addappid(842811, 1, "ccfe08c5433baf231434405c3ef6f5e93f9e818d75bea9b19bd39c6dafe09f14")
