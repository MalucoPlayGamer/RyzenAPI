-- Lua provided by RyzenAPI
-- Game: 东方栖霞园 ~ Blue devil in the Belvedere. Soundtrack

-- MAIN APPLICATION
addappid(1608510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608511, 1, "167244439ef4b9c8d766cfd876561fdbddc7c55f496ccf3a21258ea64094349e")
addappid(1608512, 1, "daf16c64cc26944bee9958fa04f2b94dc58ed6e142e80a66332c2ba63c7d9b9e")
