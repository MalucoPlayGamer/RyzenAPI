-- Lua provided by RyzenAPI
-- Game: Game: Speed Crew

-- MAIN APPLICATION
addappid(2367480)
-- Game: addappid(2367480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367481, 1, "cc4901a42906af2f640d8ffdf8922fb0be6cbb222bc152a3fdccb3320d1592ac")
