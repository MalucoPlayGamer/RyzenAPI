-- Lua provided by RyzenAPI 
-- Game: Speed Crew
addappid(2367480)
addappid(2367481, 1, "cc4901a42906af2f640d8ffdf8922fb0be6cbb222bc152a3fdccb3320d1592ac")
