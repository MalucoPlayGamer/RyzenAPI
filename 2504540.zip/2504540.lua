-- Lua provided by RyzenAPI
-- Game: CUBE ROYALE

-- MAIN APPLICATION
addappid(2504540)
-- Game: addappid(2504540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504541, 1, "208c3f4e10dd7a7135c41862ffd72a13f41549764bc3fcca5d26826072dbce76")
