-- Lua provided by RyzenAPI
-- Game: The Lust City

-- MAIN APPLICATION
addappid(2348680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348681, 1, "84681af374b6fb235e30b6d62e2c9b0b8d39b147d1198bc84380a467793ace9e")
