-- Lua provided by RyzenAPI
-- Game: Game: Real Farm

-- MAIN APPLICATION
addappid(573680)
-- Game: addappid(573680)

-- MAIN APP DEPOTS / PACKAGES
addappid(573681, 1, "4f885efbb17dde3ea0f46f1a7208b6e3dac9c75ca77a56d2cbdb66099d4b5b07")
addappid(573682, 1, "428142cf7baeed02f8f89d55c07eb5ecc01db44621f6567e3c64cf64f99155c4")
addappid(573683, 1, "ffc1a9e216a26b5522ec26130831bbbf8ce5250f125e488b6f9a5f7156a02ae2")
addappid(573684, 1, "951912d15399b0573c32f7248970cd7eba3c5f1b50211d0db9d252823554cace")
