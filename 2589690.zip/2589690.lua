-- Lua provided by RyzenAPI
-- Game: AppID 2589690

-- MAIN APPLICATION
addappid(2589690)
-- Game: addappid(2589690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589691, 1, "e69f6cc3f72c3d1935d9287441a741fadc24aa79fd625e4de0ddc950b4bb25bf")
