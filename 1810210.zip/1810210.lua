-- Lua provided by RyzenAPI
-- Game: Bad Cat

-- MAIN APPLICATION
addappid(1810210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810211, 1, "07cec98195da47c8abf15c8ec4205af35f66162f782c522e07af1a3b862dad99")

