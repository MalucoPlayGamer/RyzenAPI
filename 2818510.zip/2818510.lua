-- Lua provided by RyzenAPI
-- Game: Observe and Report

-- MAIN APPLICATION
addappid(2818510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818511, 1, "e46f588890898065ef46e3f188acb2cf826b68f9e55c5ef4e7dbd5be3ee10d4e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
