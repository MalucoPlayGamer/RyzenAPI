-- Lua provided by RyzenAPI
-- Game: Game: Observe and Report

-- MAIN APPLICATION
addappid(2818510)
-- Game: addappid(2818510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818511, 1, "e46f588890898065ef46e3f188acb2cf826b68f9e55c5ef4e7dbd5be3ee10d4e")
