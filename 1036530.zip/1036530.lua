-- Lua provided by RyzenAPI
-- Game: Game: AppID 1036530

-- MAIN APPLICATION
addappid(1036530)
-- Game: addappid(1036530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036531, 1, "43023de046001a4f8add2a08dff2118734a33b7376ba15cc6467997a63ee155a")
