-- Lua provided by RyzenAPI
-- Game: addappid(3238120)

-- MAIN APPLICATION
addappid(3238120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238121, 1, "90019ed446ca6ad07491d0c1dcaaf0254e58609df7010270b40fba38156ea723")
