-- Lua provided by RyzenAPI
-- Game: 741100

-- MAIN APPLICATION
addappid(741100)
-- Game: addappid(741100)

-- MAIN APP DEPOTS / PACKAGES
addappid(741101, 1, "b1534e74f9dd0ca352b8ac38b75426c58bee9121eb40afde6c7edc84ee38cee0")
