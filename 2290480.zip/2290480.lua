-- Lua provided by RyzenAPI
-- Game: 2290480

-- MAIN APPLICATION
addappid(2290480)
-- Game: addappid(2290480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290481, 1, "53d9c7ab7f0fcaa3f1492295bef06e7685636baf40d1944847a8eb82f90ebb26")
