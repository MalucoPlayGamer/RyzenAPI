-- Lua provided by RyzenAPI
-- Game: The Obscura Experiment

-- MAIN APPLICATION
addappid(2290480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2290481, 1, "53d9c7ab7f0fcaa3f1492295bef06e7685636baf40d1944847a8eb82f90ebb26")

