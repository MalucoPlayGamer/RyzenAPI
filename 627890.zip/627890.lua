-- Lua provided by RyzenAPI
-- Game: Game: AppID 627890

-- MAIN APPLICATION
addappid(627890)
-- Game: addappid(627890)

-- MAIN APP DEPOTS / PACKAGES
addappid(627891, 1, "5be093cb5557a1a9444dbde698104e94c81ea8e782b8304c3ab5316398162614")
