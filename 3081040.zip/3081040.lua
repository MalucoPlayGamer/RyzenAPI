-- Lua provided by RyzenAPI
-- Game: Puppetstring VTuber Tracking

-- MAIN APPLICATION
addappid(3081040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081041, 1, "dfce308128c6d9bb4400f8529ef9a86f2805dc1fb36e3896274603e6ca60c869")
addappid(3081042, 1, "b98e6ce21c64c973a8af88bb78fb077da61d49129c72674a36250c8656741d9d")
addappid(3081043, 1, "c5ec8abeb14ee516b452f7835e9107b885d3628ecc76a0b179b826c3dc5a56ee")

