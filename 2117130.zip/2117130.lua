-- Lua provided by SkyAPI 
-- Game: Hentai Pussy 4
addappid(2117130)
addappid(2117131, 1, "c947c6751929e65e4d9ad0384490140f0748e4d546673a51e159028e39fa2e62")
