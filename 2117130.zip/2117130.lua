-- Lua provided by RyzenAPI
-- Game: Game: Hentai Pussy 4

-- MAIN APPLICATION
addappid(2117130)
-- Game: addappid(2117130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117131, 1, "c947c6751929e65e4d9ad0384490140f0748e4d546673a51e159028e39fa2e62")
