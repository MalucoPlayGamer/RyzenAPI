-- Lua provided by RyzenAPI
-- Game: AppID 2754200

-- MAIN APPLICATION
addappid(2754200)
-- Game: addappid(2754200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754201, 1, "7636fbc0343c3dd00b6366f47872224816b322ea9a4258b580b377f15ab3cfab")
