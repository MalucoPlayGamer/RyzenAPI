-- Lua provided by SkyAPI 
-- Game: Floating Life2
addappid(1934080)
addappid(1934081, 1, "92f9a5d8026f1fd9ad4acabf7b7eb4cf74e0e5ca7ba4b8b17fd1fa1e427ead8e")
addappid(1934082, 1, "84cf2c2ce83f8dec3247dd59a6bb109888b50a0c462258b23d84e885802a85dc")
addappid(1934084, 1, "c73fc88d54021a607c4abfd8fd13aa7d42f9f2492d148f5f8e8a0753a44bdaae")
addappid(1934085, 1, "76e249b81d3f90b1fbabfa8feceec6324db15c0c24b8389ab0e61936498c481c")
addappid(1934086, 1, "a55503c6d799cc0f5df0dd0b26ea1d0dd77828cefca3c53bb577053c0ea94fb3")
