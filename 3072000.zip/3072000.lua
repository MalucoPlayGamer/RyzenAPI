-- Lua provided by RyzenAPI
-- Game: Literally Just Pixels On A Screen

-- MAIN APPLICATION
addappid(3072000)
