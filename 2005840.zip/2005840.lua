-- Lua provided by RyzenAPI
-- Game: addappid(2005840)

-- MAIN APPLICATION
addappid(2005840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005841, 1, "e5d1aa2601915627ebe20fb32be309d781aeba0324d65e70058c459c8147099a")
