-- Lua provided by RyzenAPI
-- Game: AppID 389900

-- MAIN APPLICATION
addappid(389900)
-- Game: addappid(389900)

-- MAIN APP DEPOTS / PACKAGES
addappid(389901, 1, "3f0f0054678f9d160ca05db51c32dd9ded5e248ba12604e23a94b315a653f9c2")
