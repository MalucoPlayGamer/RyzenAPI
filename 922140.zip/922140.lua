-- Lua provided by RyzenAPI 
-- Game: Oh, you touch my balls ( ͡° ͜ʖ ͡°)
addappid(922140)
addappid(922141, 1, "5b919bbe12df7f4e34ff9c90364ccd37fc6dd93d5ecd3c9fb05b97e24e0d0b4e")
