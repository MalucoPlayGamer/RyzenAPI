-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2930000)
-- Game: addappid(2930000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930000,0,"86c7fe7448362aff3634df4ce02eb3a0b214c6bc6af6ac069d12516545bc5586")
