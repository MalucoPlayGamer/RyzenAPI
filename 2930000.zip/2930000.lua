-- Lua provided by RyzenAPI
-- Game: addappid(2930000)

-- MAIN APPLICATION
addappid(2930000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930000,0,"86c7fe7448362aff3634df4ce02eb3a0b214c6bc6af6ac069d12516545bc5586")
