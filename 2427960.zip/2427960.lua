-- Lua provided by RyzenAPI
-- Game: Calcium Contract

-- MAIN APPLICATION
addappid(2427960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427961, 1, "32dfc84d29e1ae4dfd5fee8afffbf3b297c1cbb95bff674dc0079c98ef4062db")

