-- Lua provided by RyzenAPI
-- Game: Calcium Contract

-- MAIN APPLICATION
addappid(2427960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427961, 1, "32dfc84d29e1ae4dfd5fee8afffbf3b297c1cbb95bff674dc0079c98ef4062db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
