-- Lua provided by RyzenAPI
-- Game: OddBallers Demo

-- MAIN APPLICATION
addappid(1321060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064071,0,"971cd1fcaac107fa34ba3c516489d893499c90c9936b56782985787d3b1f4e59")

