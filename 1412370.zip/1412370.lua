-- Lua provided by RyzenAPI
-- Game: addappid(1412370)

-- MAIN APPLICATION
addappid(1412370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412371, 1, "6ad950637b50a4485e23180e62c4fade9fd974db1adcfed88bab2715ac61dc26")
