-- Lua provided by RyzenAPI
-- Game: Inspector Schmidt - A Bavarian Tale

-- MAIN APPLICATION
addappid(1694560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694561, 1, "5a2d8605389f206edf6d3f382442c80f6bbe5d404a7dba40956ec1248e0a464d")
