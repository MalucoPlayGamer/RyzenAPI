-- Lua provided by RyzenAPI
-- Game: Ship of Fools Original Soundtrack

-- MAIN APPLICATION
addappid(2222360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222362,0,"ff9543e8fbc8b87eff373a529b7879477b8f179431255f9731473d1ae0c9d3e0")
addappid(2222363,0,"a5a6a5d239b5cf35913b82de539f1c3da98ff9e35d1fa2051ce8d1d82a5a778e")

