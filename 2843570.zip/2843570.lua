-- Lua provided by RyzenAPI
-- Game: 2843570

-- MAIN APPLICATION
addappid(2843570)
-- Game: addappid(2843570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843571, 1, "7f9778b107f78e0376539a8f68603545af96592af9ff1eccc45ea751baae5f1b")
