-- Lua provided by RyzenAPI
-- Game: Darksiders Warmastered Edition

-- MAIN APPLICATION
addappid(462780)

-- MAIN APP DEPOTS / PACKAGES
addappid(462781, 1, "96eb6dd1c57eb2d2444bf75225a3aacd4ce143a43a111c4e0afa3b7565575e29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
