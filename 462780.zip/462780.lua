-- Lua provided by RyzenAPI
-- Game: Darksiders Warmastered Edition

-- MAIN APPLICATION
addappid(462780)

-- MAIN APP DEPOTS / PACKAGES
addappid(462781, 1, "96eb6dd1c57eb2d2444bf75225a3aacd4ce143a43a111c4e0afa3b7565575e29")
