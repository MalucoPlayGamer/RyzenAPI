-- Lua provided by RyzenAPI
-- Game: Game: AppID 2985940

-- MAIN APPLICATION
addappid(2985940)
-- Game: addappid(2985940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985941, 1, "604ce237e5cd511b4d85f969c3c318e76f229394c08278f8c950352a601caaf7")
