-- Lua provided by RyzenAPI
-- Game: Game: Witching Tower: Heroes

-- MAIN APPLICATION
addappid(1276720)
-- Game: addappid(1276720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276721, 1, "e1a48d55a9ffde980556b3d4e89e05a55513b4345d8671469e4d34435f3a3162")
