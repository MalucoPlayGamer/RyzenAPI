-- Lua provided by RyzenAPI
-- Game: 2806530

-- MAIN APPLICATION
addappid(2806530)
-- Game: addappid(2806530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806531, 1, "40936b4301b7796aed0195abdd9ea97cc89bb10d137b7ead89c2f081ceff6320")
