-- Lua provided by RyzenAPI
-- Game: 辩经[Yo_Choice!!!!!]

-- MAIN APPLICATION
addappid(2806530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2806531, 1, "40936b4301b7796aed0195abdd9ea97cc89bb10d137b7ead89c2f081ceff6320")

