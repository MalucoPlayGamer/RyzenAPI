-- Lua provided by RyzenAPI
-- Game: Game: AppID 703210

-- MAIN APPLICATION
addappid(703210)
-- Game: addappid(703210)

-- MAIN APP DEPOTS / PACKAGES
addappid(703211, 1, "7b321beb926557675f6f71ecad4566896305031a2c9a8db0773706210f5a1f14")
