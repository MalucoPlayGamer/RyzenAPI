-- Lua provided by RyzenAPI
-- Game: Game: Farming & Supermarket Simulator

-- MAIN APPLICATION
addappid(3070880)
-- Game: addappid(3070880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070881, 1, "7689083b7ce5497c3fe92f58a175d1777d2c19284e940681609557d9d5c940a3")
