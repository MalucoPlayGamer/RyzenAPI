-- Lua provided by RyzenAPI
-- Game: Dead Shits

-- MAIN APPLICATION
addappid(679700)

-- MAIN APP DEPOTS / PACKAGES
addappid(679701, 1, "1df39785b92556f5700ede26bff9f801907b24d72dc40b8caca28af55acceb32")

