-- Lua provided by RyzenAPI
-- Game: Loop Hero Soundtrack

-- MAIN APPLICATION
addappid(1562200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562201, 1, "8a5834bb46109f585608a3d8f50895fa5835798a69f23a9e1375c9ad30b3f237")

