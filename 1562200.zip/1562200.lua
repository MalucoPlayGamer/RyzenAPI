-- Lua provided by SkyAPI 
-- Game: Loop Hero Soundtrack
addappid(1562200)
addappid(1562201, 1, "8a5834bb46109f585608a3d8f50895fa5835798a69f23a9e1375c9ad30b3f237")
