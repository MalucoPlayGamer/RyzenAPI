-- Lua provided by RyzenAPI
-- Game: 1386660

-- MAIN APPLICATION
addappid(1386660)
-- Game: addappid(1386660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386661, 1, "e4dc8dd238557ef3d32bb6cde6b0286822253c547dd8906a9f09291b8457f49d")
