-- Lua provided by RyzenAPI
-- Game: Game: Hunting Unlimited 2

-- MAIN APPLICATION
addappid(1330790)
-- Game: addappid(1330790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330791, 1, "757f1cb5bd2e6038eadd50b64aa516222af0d8c9f7958fd45d8b66917958bd69")
