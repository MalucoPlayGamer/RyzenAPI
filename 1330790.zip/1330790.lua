-- Lua provided by RyzenAPI
-- Game: Hunting Unlimited 2

-- MAIN APPLICATION
addappid(1330790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330791, 1, "757f1cb5bd2e6038eadd50b64aa516222af0d8c9f7958fd45d8b66917958bd69")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
