-- Lua provided by RyzenAPI
-- Game: Campus Life Demo

-- MAIN APPLICATION
addappid(2958080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958081, 1, "98ba5087c9c2bde870f85810877d945b4fd940168bc0d17855f2b1702ca266a8")
