-- Lua provided by RyzenAPI
-- Game: AppID 1175980

-- MAIN APPLICATION
addappid(1175980)
-- Game: addappid(1175980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175981, 1, "54acfb53e7db889fb934a5eddd38846ad4e422a259df5ea0b4a9d148c7270cb4")
addappid(1175982, 1, "a3215d23ee13fb093c8a90a614c3689af0f14a4cb4c289e0151b03a113a5c494")
