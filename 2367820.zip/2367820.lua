-- Lua provided by RyzenAPI
-- Game: despelote

-- MAIN APPLICATION
addappid(2367820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367821, 1, "8796585f6b24ff0b4e1c6bcde948308409cade875d6c7d8a78040aee7dd09b2e")

