-- Lua provided by RyzenAPI
-- Game: Psychiatrist Simulator 2: Prologue

-- MAIN APPLICATION
addappid(2508280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508281, 1, "ec3a6c9b687933982941c55abf262989b25978cfe343d4c4bca1ae4910a25811")
