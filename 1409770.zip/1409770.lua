-- Lua provided by SkyAPI 
-- Game: Cat's Kiss
addappid(1409770)
addappid(1409771, 1, "7789220da295002120b28bdcca81d32299c37b8378b1ef02412a082dcf27db4b")
addappid(3001080, 0, "7df367d17bdc49e855f3e87857a323fe74bdd009da4085a3cff74aac3f7a6423")
