-- Lua provided by RyzenAPI
-- Game: Game: Cat's Kiss

-- MAIN APPLICATION
addappid(1409770)
-- Game: addappid(1409770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409771, 1, "7789220da295002120b28bdcca81d32299c37b8378b1ef02412a082dcf27db4b")
addappid(3001080, 0, "7df367d17bdc49e855f3e87857a323fe74bdd009da4085a3cff74aac3f7a6423")
