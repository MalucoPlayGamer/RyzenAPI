-- Lua provided by RyzenAPI
-- Game: Half Sword Playtest

-- MAIN APPLICATION
addappid(2527870)
-- Game: addappid(2527870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527871, 1, "3f6418b433c5e9b32d9c205e085ee5ae124bc8c7c0d40d39b9588648008515df")
