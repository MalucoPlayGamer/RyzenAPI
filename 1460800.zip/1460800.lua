-- Lua provided by RyzenAPI 
-- Game: Super Dungeon Maker ⚒ - Fink`s Awakening (Prologue)
addappid(1460800)
addappid(1460801, 1, "aee08a6678b588992f8225877062e01ae4f4956b2d74ba0315b0c039ab1ece53")
