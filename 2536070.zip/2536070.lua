-- Lua provided by RyzenAPI
-- Game: Nephilim Uprising

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2536070)
-- Game: addappid(2536070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536073,0,"e8b6f45db80d60c50f87bb1afd70639cf540e7d4b7287f11a32bc0bd25000a42")
