-- Lua provided by RyzenAPI
-- Game: GALSAD - Galactic Salvage and Disposal

-- MAIN APPLICATION
addappid(1344340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1344341, 1, "4de558a3d75ec78afae37f94a6194002234bfda16de4648d2e2c2ef10825a7f1")

