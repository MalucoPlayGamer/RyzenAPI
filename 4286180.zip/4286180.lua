-- 4286180's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Vicky is streaming
-- Created: July 10, 2026 at 21:35:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4286180) -- Hentai Clicker: Vicky is streaming
-- MAIN APP DEPOTS
addappid(4286181, 1, "eb82e1adde058354a8bb77b5ae7cc2fd7e61c670f48b42be03fa6948fc3fce60") -- Depot 4286181
setManifestid(4286181, "6064751623958513859", 159768464)
addappid(4286182, 1, "ca533336b58b9b30f2c814b38493feb1c90c822b469faec4c31b4564b3c64935") -- Depot 4286182
setManifestid(4286182, "8926610249388184463", 194465612)
addappid(4286183, 1, "8583a446cdd8f4170540dee9616f1274df4412e8a054a5ddbf3a56e0765a8cc1") -- Depot 4286183
setManifestid(4286183, "1735824608213168470", 167524459)