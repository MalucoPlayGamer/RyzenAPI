-- Lua provided by RyzenAPI
-- Game: addappid(1011830)

-- MAIN APPLICATION
addappid(1011830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011831, 1, "7d4956732260a56a83b88c8c025a50189eaa84ceb4caf1b8dd977d579e04988d")
