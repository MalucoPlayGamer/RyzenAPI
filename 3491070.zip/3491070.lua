-- Lua provided by RyzenAPI
-- Game: Don't Sleep

-- MAIN APPLICATION
addappid(3491070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491071, 1, "4fb490ef190334f122f56d78e71c9800c904d3dfa06d9746edca07b2b4e5c8e3")

