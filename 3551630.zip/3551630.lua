-- Lua provided by RyzenAPI
-- Game: Game: Backrooms: The Next Level

-- MAIN APPLICATION
addappid(3551630)
-- Game: addappid(3551630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3551631, 1, "f2285ff509bd5d8521979ffbe8ddc9f73b8d3a7126bfabca07b9d51499a22f65")
