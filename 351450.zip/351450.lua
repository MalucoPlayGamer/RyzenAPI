-- Lua provided by RyzenAPI
-- Game: Scribble Space

-- MAIN APPLICATION
addappid(351450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(351451, 1, "74f7d2ccfe126ef69f16100f7b8e71efcc8436be66c1a669fd43852d7b978a6b")
addappid(351452, 1, "8bb657077d5318d22784ca27db97306cf2821fab30d3d2cf830f9fa87d2b75d6")
addappid(351453, 1, "ec25e335c7a6e6d0f418e86a5d9dd8a2e2ba8bc3877fc4ada4bfc9452b893fe3")

