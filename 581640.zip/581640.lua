-- Lua provided by RyzenAPI
-- Game: AppID 581640

-- MAIN APPLICATION
addappid(581640)
-- Game: addappid(581640)

-- MAIN APP DEPOTS / PACKAGES
addappid(581641, 1, "85b0f237945abef47002b79d05b95dc9c2e9aa81de9a9b31f104b8a40a880e91")
addappid(581642, 1, "32850de0a6a9be4c844119bb402f8f1633db74a6a77a490d7e6c1e757ca5dcce")
