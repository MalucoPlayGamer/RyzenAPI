-- Lua provided by RyzenAPI
-- Game: 968350

-- MAIN APPLICATION
addappid(968350)
-- Game: addappid(968350)

-- MAIN APP DEPOTS / PACKAGES
addappid(968352,0,"15e3ac466917f604850637ed27012cd1cd7623e69c17dc93f5b116ea8cb1ed3d")
