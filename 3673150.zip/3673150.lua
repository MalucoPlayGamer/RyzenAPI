-- Lua provided by RyzenAPI
-- Game: Vegas Casino & Slots: Slottist

-- MAIN APPLICATION
addappid(3673150)

