-- Lua provided by RyzenAPI
-- Game: Spacefighter Rukia 2

-- MAIN APPLICATION
addappid(3732040)
-- Game: addappid(3732040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732041, 1, "b796cbbe5f6c8678d1b8ccd6ef624cec644650b6d47014cce9fb7e88d46158ce")
