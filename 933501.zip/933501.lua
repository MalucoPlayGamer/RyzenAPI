-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３- Bonus Costume for Yoshitsugu Otani

-- MAIN APPLICATION
addappid(933501)

-- MAIN APP DEPOTS / PACKAGES
addappid(933501,0,"d9adf98e03cc6f70f9080eb28dfbd0f636c9f30e1470f8ee240551239e114974")
addtoken(933501,16165073147105620311)

