-- Lua provided by RyzenAPI 
-- Game: Wanted Killer VR
addappid(759540)
addappid(759541, 1, "713eec2468f9c185ad3c0133ca3a9da5e8e7523daf8af162acdb317617ed575b")
