-- Lua provided by RyzenAPI
-- Game: Sleeping Dogs Demo

-- MAIN APPLICATION
addappid(215220)

-- MAIN APP DEPOTS / PACKAGES
addappid(215221, 1, "85b4425a4bef7522c2e11da92cef44ad8ecdf97f3d878275929060ec25a620e8")
addappid(215222, 1, "7773fd9ae5f083c52615b641d7e2eec4a740ef0c1a379b608aa657aa699f2b43")
addappid(215223, 1, "a45aff7f3348abbd662d2648bc910758c15ee676cd9a92ca688120aa01a5f6a4")
