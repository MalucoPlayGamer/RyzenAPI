-- Lua provided by RyzenAPI
-- Game: Desperate Place Demo

-- MAIN APPLICATION
addappid(3413250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413251, 1, "3ef1bc572b047f52c59fc24a2cc1067701fb0905b9decfdcb40c5e3a0a58c6cf")
