-- Lua provided by RyzenAPI
-- Game: 579740

-- MAIN APPLICATION
addappid(579740)
-- Game: addappid(579740)

-- MAIN APP DEPOTS / PACKAGES
addappid(579741, 1, "f41fed3bb7163828434cdaf973bea9bb72f081efc896cdc055bc494c7c364bec")
