-- Lua provided by RyzenAPI
-- Game: FlatOut 4: Total Insanity Soundtrack

-- MAIN APPLICATION
addappid(1299740)
-- Game: addappid(1299740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299741, 1, "3aee3223a6d1f31e407d2e2996bcb09b42845b9bc608b845f88009c243a983af")
