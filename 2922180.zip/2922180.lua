-- Lua provided by RyzenAPI
-- Game: Game: Bonds of Yachiyo

-- MAIN APPLICATION
addappid(2922180)
-- Game: addappid(2922180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922181, 1, "cd2cf093a3d08d83110642aa6f6988a4808545214e9822607abc7cccd00ea77b")
addappid(2922182, 1, "3169e9e0fd74c632b46d31493f93a105f2eaae17118598f6524e87ac1df8a3a6")
addappid(2922183, 1, "36acd78ed219bbd7052ce8881a283f961423e5ac0ef8529b18acbb7c3f112b3d")
addappid(2922184, 1, "a7304da6093a1c379436f8625b5357fa6cfdede257737c0ca965c1ec26536e2b")
