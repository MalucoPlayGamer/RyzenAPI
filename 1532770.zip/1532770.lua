-- Lua provided by RyzenAPI
-- Game: Sex and the Furry Titty

-- MAIN APPLICATION
addappid(1532770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532771, 1, "dbc2cd6327f98c3df57a699fdb5bb5b9c66b9d9926889ee6464391cd04d39ff1")
addappid(1756970, 0, "0725e5aa4d9951df6d442b6d7a33f63319ec6a18d331252fe377ec6474cda411")
addappid(2403200, 0, "1463c2501f6d997be27e4dab7e4e91d38ef719c8e3fb9105d10a1da3eb3c72d8")
