-- Lua provided by RyzenAPI
-- Game: addappid(2304170)

-- MAIN APPLICATION
addappid(2304170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304171, 1, "836a6eb4d9047c7d01b8a609ab719161fac206f1c1666f1adc4706a8d288f9ef")
addappid(2304172, 1, "db61e2d74d497c9def6d0b4627adf713dbe1919a5dfdb91ebf41d0a6cb22ca3a")
