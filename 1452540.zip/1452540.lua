-- Lua provided by RyzenAPI
-- Game: Game: Frincess&Cnight

-- MAIN APPLICATION
addappid(1452540)
-- Game: addappid(1452540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452541, 1, "484ca774a7aeeaf2cd2686f413542586d2a7b8efc4b29308571ff62fa4d6db69")
