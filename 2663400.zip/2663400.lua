-- Lua provided by RyzenAPI
-- Game: Beach Vacation Simulator Demo

-- MAIN APPLICATION
addappid(2663400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663401, 1, "a7ac959437c83dd7033f043ecdef15a752ff4b0c4df4104fb04544373d2e3b07")

