-- Lua provided by RyzenAPI 
-- Game: AppID 2663400
addappid(2663400)
addappid(2663401, 1, "a7ac959437c83dd7033f043ecdef15a752ff4b0c4df4104fb04544373d2e3b07")
