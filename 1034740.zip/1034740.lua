-- Lua provided by RyzenAPI
-- Game: addappid(1034740)

-- MAIN APPLICATION
addappid(1034740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034741, 1, "ae40ad1a786121e8a4900323ecb4de1dc0d1a0cad7e69fe6cd6635400542569f")
