-- Lua provided by RyzenAPI
-- Game: Hard Light Vector

-- MAIN APPLICATION
addappid(1034740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1034741, 1, "ae40ad1a786121e8a4900323ecb4de1dc0d1a0cad7e69fe6cd6635400542569f")

