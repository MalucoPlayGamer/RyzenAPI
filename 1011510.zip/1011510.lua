-- Lua provided by RyzenAPI
-- Game: Wizard And Minion Idle

-- MAIN APPLICATION
addappid(1011510)

