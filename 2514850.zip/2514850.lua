-- Lua provided by RyzenAPI
-- Game: Maid Slaves & Golden Dungeon

-- MAIN APPLICATION
addappid(2514850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514853,0,"7269ba68749775b04aca47fe460090d6fa961dd5cdb07fbee9d7806f839f6198")
addappid(2514854,0,"1c348a75f7d35ced0f27c3c87d6e7d670edcd3e20c9abfff4ee62c837b7ab561")
