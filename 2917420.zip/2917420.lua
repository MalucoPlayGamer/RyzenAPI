-- Lua provided by RyzenAPI
-- Game: Game: SysOps Saga Demo

-- MAIN APPLICATION
addappid(2917420)
-- Game: addappid(2917420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917421, 1, "781c080cd8a48eff590863f2210d9c19109812409ca3a0f248cadc14f994760f")
