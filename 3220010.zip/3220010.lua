-- Lua provided by RyzenAPI
-- Game: addappid(3220010)

-- MAIN APPLICATION
addappid(3220010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220011, 1, "54bfe07fe3455190a0a9f0489ba360d40469e9f5a7ac7a727bba84e71be38c77")
