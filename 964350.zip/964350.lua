-- Lua provided by RyzenAPI
-- Game: At Home Alone

-- MAIN APPLICATION
addappid(964350)

-- MAIN APP DEPOTS / PACKAGES
addappid(964351, 1, "2b645caf5619d4a95b5c5af4dd7b7b85cddaf0621342669a2cdce6479a8b3bb6")
addappid(964352, 1, "5c510085a343680b8f9d0d9d9c01b4e66a9093bfead5af1dc59afd3b4fd4b2b5")

