-- Lua provided by RyzenAPI
-- Game: addappid(1889710)

-- MAIN APPLICATION
addappid(1889710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889711, 1, "5f14cec84e3b9cff5a75675dd065f16e2ed7cccb4db430ce3a80546e051c4576")
