-- Lua provided by RyzenAPI
-- Game: Toasterball

-- MAIN APPLICATION
addappid(1142810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142811, 1, "a81afe5243eb7d7a11a5cae54fc7ee4924bbb5ebd1778316cc28f91d10db7573")

