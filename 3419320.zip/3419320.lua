-- Lua provided by RyzenAPI
-- Game: Game: Virtua Fighter 5 R.E.V.O. World Stage - Virtua Fighter 30th Anniversary Music Selection

-- MAIN APPLICATION
addappid(3419320)
-- Game: addappid(3419320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419321, 1, "0929d2d358fbfe514e71e5350f6e02c08d6e99e0492c03a8a6c50415d3133d63")
addappid(3419322, 1, "46010cfa219028e127529941b1c113493625693d14509b1ce3608db4ed496534")
