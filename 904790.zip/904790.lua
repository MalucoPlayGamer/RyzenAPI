-- Lua provided by RyzenAPI
-- Game: Game: AppID 904790

-- MAIN APPLICATION
addappid(904790)
-- Game: addappid(904790)

-- MAIN APP DEPOTS / PACKAGES
addappid(904791, 1, "9bef65d669edb0c1897bd056b8a4f53ee62dc5ce32559e141a1de098000f8ef0")
