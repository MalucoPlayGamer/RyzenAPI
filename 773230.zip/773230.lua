-- Lua provided by RyzenAPI
-- Game: Game: AppID 773230

-- MAIN APPLICATION
addappid(773230)
-- Game: addappid(773230)

-- MAIN APP DEPOTS / PACKAGES
addappid(773231, 1, "96b9194f9dcd84ea3acfa4e0a98c01f86cb3f5ec4857f0b8dea85542ec297f89")
