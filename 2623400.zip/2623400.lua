-- Lua provided by RyzenAPI
-- Game: Surrogate

-- MAIN APPLICATION
addappid(2623400)
-- Game: addappid(2623400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623401, 1, "cfc3c05bf71d4d622d819b29c7baeb5e8c296e152fccb24baa7451f22544d492")
