-- Lua provided by RyzenAPI 
-- Game: Surrogate
addappid(2623400)
addappid(2623401, 1, "cfc3c05bf71d4d622d819b29c7baeb5e8c296e152fccb24baa7451f22544d492")
