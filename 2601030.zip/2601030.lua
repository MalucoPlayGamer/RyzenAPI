-- Lua provided by RyzenAPI 
-- Game: Exanimum: The Silent Call
addappid(2601030)
addappid(2601031, 1, "63406cc408fa86ef14ef634a8b9a37974e44c030fb6e5e248768c38d8ac0e8d0")
