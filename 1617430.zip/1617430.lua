-- Lua provided by RyzenAPI
-- Game: Game: Bunhouse

-- MAIN APPLICATION
addappid(1617430)
-- Game: addappid(1617430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617431, 1, "f405432fc5ea5a1cabd680b660ac073e0bdb64b01e3d6b84fb699218af06fd45")
