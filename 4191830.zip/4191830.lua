-- Generated with Luie @ https://lua.tools/
-- 4191830 - OH DEMON! Fix my TV
-- Generated 2026-08-23 03:00:40 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4191830)

-- Main Depots
addappid(4191831, 1, "d4f9e20b6b4782fd182b4ba8a4207af6024c66515823ee7da89e3c6d64890d58")
setManifestid(4191831, "255620880545823819", 11126429298)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
