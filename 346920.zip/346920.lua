-- Lua provided by SkyAPI 
-- Game: Undead Shadows
addappid(346920)
addappid(346921, 1, "42bfc2d88203f30871ea3deea03c911508edbf0997a33f4cd1e14e45203366df")
