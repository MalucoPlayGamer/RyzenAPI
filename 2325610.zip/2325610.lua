-- Lua provided by RyzenAPI
-- Game: addappid(2325610)

-- MAIN APPLICATION
addappid(2325610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325610,0,"ca92fdcb81ef6f1b00dee056d9682572b797343ccafcd2e4e430984d15b5d7cb")
