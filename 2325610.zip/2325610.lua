-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2325610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325610,0,"ca92fdcb81ef6f1b00dee056d9682572b797343ccafcd2e4e430984d15b5d7cb")

