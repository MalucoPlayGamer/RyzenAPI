-- Lua provided by RyzenAPI
-- Game: AppID 857010

-- MAIN APPLICATION
addappid(857010)
-- Game: addappid(857010)

-- MAIN APP DEPOTS / PACKAGES
addappid(857011, 1, "1691949846f287476abe7b18cd7e06dc7329a3fee016164d9e80de5a67387457")
