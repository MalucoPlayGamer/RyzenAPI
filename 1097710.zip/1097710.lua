-- Lua provided by RyzenAPI
-- Game: addappid(1097710)

-- MAIN APPLICATION
addappid(1097710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097711, 1, "2966de81fd0baa54c33fccec325ff2f6e6fa2330f6a41abeab89cddb44781d14")
