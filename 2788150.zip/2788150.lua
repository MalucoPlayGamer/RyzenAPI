-- Lua provided by RyzenAPI
-- Game: addappid(2788150)

-- MAIN APPLICATION
addappid(2788150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788151, 1, "0af418b471e15025357f1c4f094d947a6ca3db954fee7a5ab35418138bf1a332")
