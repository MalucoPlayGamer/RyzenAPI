-- Lua provided by SkyAPI 
-- Game: Sakura Succubus 9
addappid(2788150)
addappid(2788151, 1, "0af418b471e15025357f1c4f094d947a6ca3db954fee7a5ab35418138bf1a332")
