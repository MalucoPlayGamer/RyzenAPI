-- Lua provided by RyzenAPI
-- Game: Toy Tinker Simulator

-- MAIN APPLICATION
addappid(1510580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510581, 1, "1f244b9241af9ab2debf7d905cbe81ec6ad5d7c60889ddbe6ef711ca4508aed7")

