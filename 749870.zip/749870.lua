-- Lua provided by RyzenAPI
-- Game: MyTD 我的塔防

-- MAIN APPLICATION
addappid(749870)
-- Game: addappid(749870)

-- MAIN APP DEPOTS / PACKAGES
addappid(749871, 1, "bf5917acf123e8c590fd4d359bbd6f982f3395cd75d09a9cfdecbd0fc8c02b55")
