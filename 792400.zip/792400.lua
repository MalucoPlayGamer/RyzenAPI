-- Lua provided by RyzenAPI
-- Game: Battleship Lonewolf 2

-- MAIN APPLICATION
addappid(792400)

-- MAIN APP DEPOTS / PACKAGES
addappid(792401,0,"b270f314979ce96bded92c9c0382e08f28a5a127293a0930af29fadda608bb9c")

