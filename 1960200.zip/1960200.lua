-- Lua provided by RyzenAPI 
-- Game: AChat Next
addappid(1960200)
addappid(1960201, 1, "014b72bf7f9951d39b6dd8dd730b9c19145025ab3e0ebd58f0fb5c58c8cd2ced")
