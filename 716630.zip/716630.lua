-- Lua provided by RyzenAPI
-- Game: 716630

-- MAIN APPLICATION
addappid(716630)
addappid(716631)
addappid(716633)
addappid(716634)
addappid(716635)
-- Game: addappid(716630)

-- MAIN APP DEPOTS / PACKAGES
addappid(716632,0,"b3c671d23ac256d959a42854ca0cf301d08e73be4471367aa0f432db6aea2643")
addappid(736800,0,"b0184f49f930abb8d66dea9e79f05525124118c2f5e17e0e0cc017f11e392930")
