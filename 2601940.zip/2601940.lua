-- Lua provided by RyzenAPI
-- Game: Game: AppID 2601940

-- MAIN APPLICATION
addappid(2601940)
-- Game: addappid(2601940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601941, 1, "abb367feaf3ec1d399531e980035a787956e55842fdc3bf1edde4bd385aacdfe")
