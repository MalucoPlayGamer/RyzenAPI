-- Lua provided by RyzenAPI
-- Game: 2285240

-- MAIN APPLICATION
addappid(2285240)
-- Game: addappid(2285240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285241, 1, "3acfb048541223d510f190c927528671d2d996f0af5a56a208d35bd8ec9ea29b")
addappid(2285242, 1, "079d2e7c855e57e7e85fec430170d4c5fac5ff13310f1e93eae46b0c42cb0e90")
