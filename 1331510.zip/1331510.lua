-- Lua provided by RyzenAPI
-- Game: addappid(1331510)

-- MAIN APPLICATION
addappid(1331510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331511, 1, "9d19b5149dfae08b763ccd5e2ebf36ab20614929162165dd5aa4bc7d6e7cdd18")
