-- Lua provided by RyzenAPI
-- Game: addappid(1020540)

-- MAIN APPLICATION
addappid(1020540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020541, 1, "ef01444ff6b79229f900afaa117fb502e1ed4bba8ff219cd3f4996180fe0f67a")
