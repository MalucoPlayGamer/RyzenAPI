-- Lua provided by RyzenAPI
-- Game: CONTRA: ROGUE CORPS

-- MAIN APPLICATION
addappid(1020540)
addappid(1049460)
addappid(1065660)
addappid(1065661)
addappid(1138930)
addappid(1138931)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020541,0,"ef01444ff6b79229f900afaa117fb502e1ed4bba8ff219cd3f4996180fe0f67a")

