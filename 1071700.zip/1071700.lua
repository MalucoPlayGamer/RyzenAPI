-- Lua provided by RyzenAPI
-- Game: addappid(1071700)

-- MAIN APPLICATION
addappid(1071700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071701, 1, "1d70c306f12e7f0a6c1f9736c82079b34dfd80765eb4c6c71f0226f47faaba2f")
