-- Lua provided by RyzenAPI
-- Game: addappid(3443610)

-- MAIN APPLICATION
addappid(3443610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443611, 1, "ecdd1086f173caecac7eb9f1298c44c1e56031881be090190852ac324a2b5f17")
