-- Lua provided by RyzenAPI
-- Game: Velocity®Ultra

-- MAIN APPLICATION
addappid(244890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(244891, 1, "e87af81c79a12affe3c7ed68f95951a50607e5ba5045b6b266527cd3508f0997")
addappid(267880, 0, "66b921b9865cb6490659a0063122cbd9ab8ca8e6e3ee40155f7c146837186fcb")

