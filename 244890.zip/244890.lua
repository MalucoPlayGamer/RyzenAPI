-- Lua provided by RyzenAPI 
-- Game: Velocity®Ultra
addappid(244890)
addappid(244891, 1, "e87af81c79a12affe3c7ed68f95951a50607e5ba5045b6b266527cd3508f0997")
addappid(267880, 0, "66b921b9865cb6490659a0063122cbd9ab8ca8e6e3ee40155f7c146837186fcb")
