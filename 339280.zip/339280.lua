-- Lua provided by RyzenAPI
-- Game: Strife®

-- MAIN APPLICATION
addappid(339280)
addappid(352730)
addappid(356140)
addappid(360240)
addappid(363830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(339281, 1, "0657e965dbf711c9f250af5ab36cd534d2821340e6471e8c4fdd6ed1f6e257dd")
addappid(339282, 1, "336c7f3d9821e9bc3edd6642d9667ec289784b07443709ff21a84d0e8d63e6d9")
addappid(339284, 1, "e2ad54b7938e6e5885b9f7f783fd6014195918b16c17a6057883950d0b838e09")

