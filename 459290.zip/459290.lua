-- Lua provided by RyzenAPI
-- Game: 459290

-- MAIN APPLICATION
addappid(459290)
-- Game: addappid(459290)

-- MAIN APP DEPOTS / PACKAGES
addappid(459291, 1, "f7c4203e543ca17d20b9d7d7e18695a29e64d264a48641ed2d08deca365619e0")
