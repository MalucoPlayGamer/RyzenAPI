-- Lua provided by RyzenAPI
-- Game: Art of Stunt

-- MAIN APPLICATION
addappid(1913610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913611, 1, "21560a0bb7ad7f0b73089cc6910945160d9fb199ff7a978418213956d53d3ae1")

