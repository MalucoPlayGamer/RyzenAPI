-- Lua provided by RyzenAPI
-- Game: addappid(3022140)

-- MAIN APPLICATION
addappid(3022140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022141, 1, "0a5893fbcd9323ff2f7536f8ed229f7562bd216e3fb230bd387fcb63c3d088e8")
