-- Lua provided by RyzenAPI
-- Game: Lily’s Labyrinth of Lust

-- MAIN APPLICATION
addappid(2866440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866441, 1, "72efb7fe79c1a54168b510a4895ad5b3326dd92d86846cb6b7a1c45fdfa6ab27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
