-- Lua provided by RyzenAPI
-- Game: Game: Lily’s Labyrinth of Lust

-- MAIN APPLICATION
addappid(2866440)
-- Game: addappid(2866440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866441, 1, "72efb7fe79c1a54168b510a4895ad5b3326dd92d86846cb6b7a1c45fdfa6ab27")
