-- Lua provided by RyzenAPI
-- Game: Burst

-- MAIN APPLICATION
addappid(454080)
-- Game: addappid(454080)

-- MAIN APP DEPOTS / PACKAGES
addappid(454081, 1, "c58e94bfa6415766be0bfcd48b04960825040b260a66d4b749df667f265d35ef")
