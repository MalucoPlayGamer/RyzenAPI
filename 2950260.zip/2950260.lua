-- Lua provided by RyzenAPI
-- Game: Sun City - Episode 1

-- MAIN APPLICATION
addappid(2950260)
-- Game: addappid(2950260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950261, 1, "8fd8183b15f6752bcd8279145ccf164d70fae34d3d542a6a77c1d2846fcc09dd")
