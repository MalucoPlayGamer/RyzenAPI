-- Lua provided by RyzenAPI
-- Game: A Match with a Succubus Witch

-- MAIN APPLICATION
addappid(1990830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990831, 1, "cb7a2192b0bdcc1de331009977d3ad3333a1206e3183f0c287b8476c4db919ca")

