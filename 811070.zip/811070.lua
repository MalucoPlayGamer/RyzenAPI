-- Lua provided by RyzenAPI
-- Game: 眼中的世界 - Conviction -

-- MAIN APPLICATION
addappid(811070)
addappid(1191170)
-- Game: addappid(811070)

-- MAIN APP DEPOTS / PACKAGES
addappid(811071, 1, "9777832927a1395e75c3a60a82cbdc9f70d7495439b2d17557eff0a69ab26ffa")
