-- Lua provided by RyzenAPI
-- Game: 1966370

-- MAIN APPLICATION
addappid(1966370)
-- Game: addappid(1966370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966371, 1, "f51c177e88f33e6705610cfd305514b68f072ee1d831add091927e14a6e27c2b")
