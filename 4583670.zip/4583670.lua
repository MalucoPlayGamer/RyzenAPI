-- Lua provided by RyzenAPI
-- Game: Floppy-Ear Chaos

-- MAIN APPLICATION
addappid(4583670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4583671,0,"c07ccf9d782238c206d8bce8269561e22aadf089b82a1c407a88acf34fe9974d")

