-- Lua provided by SkyAPI 
-- Game: AppID 2975890
addappid(2975890)
addappid(2975891, 1, "81db26faae922783565596e4359af668a12514e56372e848686ea40e83aad8f3")
