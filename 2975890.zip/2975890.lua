-- Lua provided by RyzenAPI
-- Game: Game: AppID 2975890

-- MAIN APPLICATION
addappid(2975890)
-- Game: addappid(2975890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975891, 1, "81db26faae922783565596e4359af668a12514e56372e848686ea40e83aad8f3")
