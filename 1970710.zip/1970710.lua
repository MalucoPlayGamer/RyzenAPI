-- Lua provided by RyzenAPI
-- Game: Sex Diary - Swingers Yacht

-- MAIN APPLICATION
addappid(1970710)
-- Game: addappid(1970710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970711, 1, "5c3a509363cc75b76eb27993ff81adecbec1b551290b51f179be17cd82a30626")
