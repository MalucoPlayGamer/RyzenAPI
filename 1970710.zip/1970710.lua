-- Lua provided by SkyAPI 
-- Game: Sex Diary - Swingers Yacht
addappid(1970710)
addappid(1970711, 1, "5c3a509363cc75b76eb27993ff81adecbec1b551290b51f179be17cd82a30626")
