-- Lua provided by RyzenAPI
-- Game: Game: AppID 1302800

-- MAIN APPLICATION
addappid(1302800)
-- Game: addappid(1302800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302801, 1, "49faf9189f206feeac4e224e8ee773bb3bd723ba57909739198da9530009f61b")
