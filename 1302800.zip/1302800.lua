-- Lua provided by SkyAPI 
-- Game: AppID 1302800
addappid(1302800)
addappid(1302801, 1, "49faf9189f206feeac4e224e8ee773bb3bd723ba57909739198da9530009f61b")
