-- Lua provided by RyzenAPI
-- Game: SOK MAX

-- MAIN APPLICATION
addappid(786820)
-- Game: addappid(786820)

-- MAIN APP DEPOTS / PACKAGES
addappid(786821, 1, "1635d03b3805c2552f6b5c0bd22f3c39e19b726a0f88b078fefe90622065e8a7")
