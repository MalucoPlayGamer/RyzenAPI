-- Lua provided by RyzenAPI
-- Game: addappid(2395400)

-- MAIN APPLICATION
addappid(2395400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395401, 1, "0f956edc910c27b4d4fd23db0f3869b399e2f7129a3f33204f9e745060269def")
