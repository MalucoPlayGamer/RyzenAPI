-- Lua provided by RyzenAPI
-- Game: Sea Power : Naval Combat in the Missile Age

-- MAIN APPLICATION
addappid(1286220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286221, 1, "984343174565db9374b496a4535fbef08482bad32064195c9afa10617cb1346f")
