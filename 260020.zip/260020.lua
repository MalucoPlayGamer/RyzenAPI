-- Lua provided by RyzenAPI 
-- Game: YOU DON'T KNOW JACK SPORTS
addappid(260020)
addappid(260021, 1, "4811b9e564eba4f3b1b040443e25ca5546021d1a4e795868c00de89df8407c38")
