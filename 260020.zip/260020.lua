-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK SPORTS

-- MAIN APPLICATION
addappid(260020)

-- MAIN APP DEPOTS / PACKAGES
addappid(260021, 1, "4811b9e564eba4f3b1b040443e25ca5546021d1a4e795868c00de89df8407c38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
