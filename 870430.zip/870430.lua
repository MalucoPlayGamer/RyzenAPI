-- Lua provided by RyzenAPI
-- Game: AppID 870430

-- MAIN APPLICATION
addappid(870430)
-- Game: addappid(870430)

-- MAIN APP DEPOTS / PACKAGES
addappid(870431, 1, "74b5215ffcc5c489cdef55075af5817974ea2babb1fda7a5cc2969fa8c125bd7")
