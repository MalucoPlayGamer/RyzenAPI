-- Lua provided by RyzenAPI
-- Game: PizzaPanic

-- MAIN APPLICATION
addappid(2716960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716961, 1, "b565beb6bfedbfff8163089067c9f61e5a56282718aaedfcce0fa051965d8b96")
