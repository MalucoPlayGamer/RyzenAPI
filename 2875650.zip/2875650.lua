-- Lua provided by RyzenAPI
-- Game: 暮雨流花

-- MAIN APPLICATION
addappid(2875650)
-- Game: addappid(2875650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875651, 1, "e017803d843d11a27a76ddd85b9b3672943d46001b552ec9bf84b67c00600a2a")
