-- Lua provided by RyzenAPI
-- Game: Game: Nordicandia

-- MAIN APPLICATION
addappid(1503790)
-- Game: addappid(1503790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503791, 1, "c5aee8ab1697c4d2b2f484955c9aaeecabd3e31a65ef1e367233351ad189c73c")
addappid(1503792, 1, "601b493931cdb376d15d53fc1690e9593a51b25c07d4dc806592b7df78536e20")
