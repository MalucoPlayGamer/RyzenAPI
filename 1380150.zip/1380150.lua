-- Lua provided by RyzenAPI
-- Game: 1380150

-- MAIN APPLICATION
addappid(1380150)
-- Game: addappid(1380150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380151, 1, "d19abd4d9e63b3105c8170b82423331ee1f817ca8472630dec4bf8cb27ea5542")
