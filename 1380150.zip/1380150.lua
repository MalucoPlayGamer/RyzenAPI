-- Lua provided by SkyAPI 
-- Game: Sword Game
addappid(1380150)
addappid(1380151, 1, "d19abd4d9e63b3105c8170b82423331ee1f817ca8472630dec4bf8cb27ea5542")
