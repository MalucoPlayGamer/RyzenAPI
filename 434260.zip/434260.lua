-- Lua provided by RyzenAPI
-- Game: AppID 434260

-- MAIN APPLICATION
addappid(434260)
-- Game: addappid(434260)

-- MAIN APP DEPOTS / PACKAGES
addappid(434261, 1, "d9df13fa6c2d092ec6cc450d0bdb6f4f477ae4f1273ec6e3d0ee44368729c85c")
