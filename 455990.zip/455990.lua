-- Lua provided by RyzenAPI
-- Game: Smash Pixel Racing

-- MAIN APPLICATION
addappid(455990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(455991, 1, "c4eb576af6b97283b785f9d403ca3a8e747f7e7c8a75df42c15e767be45d6b42")

