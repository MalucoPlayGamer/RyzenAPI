-- Lua provided by RyzenAPI
-- Game: addappid(455990)

-- MAIN APPLICATION
addappid(455990)

-- MAIN APP DEPOTS / PACKAGES
addappid(455991, 1, "c4eb576af6b97283b785f9d403ca3a8e747f7e7c8a75df42c15e767be45d6b42")
