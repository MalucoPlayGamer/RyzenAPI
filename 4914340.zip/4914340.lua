-- 4914340's Lua and Manifest Created by Hubcap Manifest
-- Someone's Here
-- Created: August 15, 2026 at 00:09:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4914340) -- Someone's Here
-- MAIN APP DEPOTS
addappid(4914341, 1, "a69b441726351013c236e675c7f196b780b6840b36f3a3ded510e4f7565e461e") -- Depot 4914341
setManifestid(4914341, "3221937639636216676", 1616722441)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)