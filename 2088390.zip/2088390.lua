-- Lua provided by RyzenAPI 
-- Game: Chickenoidz Super Party Demo
addappid(2088390)
addappid(2088391, 1, "e38357128b4cc11819f3460356f2aedef13d0664fbbeb1348038699ea17ef969")
