-- Lua provided by RyzenAPI
-- Game: Lockheart Indigo

-- MAIN APPLICATION
addappid(1345470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345471, 1, "88cee942466a49d8c9d898f30aa254057e0a2cc645460cd55f9cdfcd03becd7a")

