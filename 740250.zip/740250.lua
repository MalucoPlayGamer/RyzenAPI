-- Lua provided by RyzenAPI
-- Game: AppID 740250

-- MAIN APPLICATION
addappid(740250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(740251, 1, "da2dc28d9565bacbe71c04cd1dc416c5ee0d332300beee06b783b61fd12bc5e9")
addappid(740252, 1, "a962ac67e8403280d07ecdc66bdb161d7e0293596614a543da91593ad3a81c95")

