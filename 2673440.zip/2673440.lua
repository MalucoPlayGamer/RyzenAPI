-- Lua provided by RyzenAPI
-- Game: Rogue Climber

-- MAIN APPLICATION
addappid(2673440)
-- Game: addappid(2673440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673441, 1, "81cafaddf9e8be26e2d73f78242a84051d845dd3bd5798963d75ade0108d79fc")
