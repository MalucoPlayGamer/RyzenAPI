-- Lua provided by RyzenAPI
-- Game: 2382780

-- MAIN APPLICATION
addappid(2382780)
-- Game: addappid(2382780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382781, 1, "aadfeeb2c511ff5766533b4d7e8245e45aec55a9aaf28269707098dc49ad2d1b")
