-- Lua provided by SkyAPI 
-- Game: The Monster War
addappid(2382780)
addappid(2382781, 1, "aadfeeb2c511ff5766533b4d7e8245e45aec55a9aaf28269707098dc49ad2d1b")
