-- Lua provided by RyzenAPI
-- Game: Physics World

-- MAIN APPLICATION
addappid(1571010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571011, 1, "cffb068345213c2a9472478516b34a74af9bc5394d8bb5d8c9c67d59c81b0c73")
