-- Lua provided by RyzenAPI
-- Game: Filthy, Stinking, Orcs!

-- MAIN APPLICATION
addappid(590560)

-- MAIN APP DEPOTS / PACKAGES
addappid(590561, 1, "484b44a4dae028d6af8357a64338d6d0607515e43bf128704f6b593c1894726a")

