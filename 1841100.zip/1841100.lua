-- Lua provided by RyzenAPI
-- Game: addappid(1841100)

-- MAIN APPLICATION
addappid(1841100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841101, 1, "c3b030e2cd08680e03975a4ec779e55ed53dcf455fa516506add130170568fb5")
