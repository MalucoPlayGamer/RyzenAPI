-- Lua provided by RyzenAPI
-- Game: DRAGON: A Game About a Dragon

-- MAIN APPLICATION
addappid(351150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(351151, 1, "e3f7893fc4ed2ae96f7058d01ad16b863da8eb6532b7186540f13f43e55eaa91")

