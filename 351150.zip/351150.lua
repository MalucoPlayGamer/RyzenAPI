-- Lua provided by SkyAPI 
-- Game: AppID 351150
addappid(351150)
addappid(351151, 1, "e3f7893fc4ed2ae96f7058d01ad16b863da8eb6532b7186540f13f43e55eaa91")
