-- Lua provided by RyzenAPI
-- Game: Game: AppID 351150

-- MAIN APPLICATION
addappid(351150)
-- Game: addappid(351150)

-- MAIN APP DEPOTS / PACKAGES
addappid(351151, 1, "e3f7893fc4ed2ae96f7058d01ad16b863da8eb6532b7186540f13f43e55eaa91")
