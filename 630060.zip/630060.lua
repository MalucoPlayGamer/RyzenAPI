-- Lua provided by RyzenAPI
-- Game: 630060

-- MAIN APPLICATION
addappid(630060)
-- Game: addappid(630060)

-- MAIN APP DEPOTS / PACKAGES
addappid(630061, 1, "ef307ae882451b79f9b06353d4c4449b85882ace7dd3cb75509001204274b2d2")
