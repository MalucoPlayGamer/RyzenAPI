-- Lua provided by RyzenAPI
-- Game: 寇莎梅特：困世迷情 Consummate:Missing World

-- MAIN APPLICATION
addappid(630060)

-- MAIN APP DEPOTS / PACKAGES
addappid(630061, 1, "ef307ae882451b79f9b06353d4c4449b85882ace7dd3cb75509001204274b2d2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(847470)
addappid(1153050)
