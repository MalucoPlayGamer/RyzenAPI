-- Lua provided by RyzenAPI
-- Game: World of Motors

-- MAIN APPLICATION
addappid(1753900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753901, 1, "4543c78b196f9f543c13be28f31641c2eda66cc8e8fa5300c3316530e8b20ca8")

