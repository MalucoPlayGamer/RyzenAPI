-- Lua provided by RyzenAPI
-- Game: Game: Stephen's Sausage Roll

-- MAIN APPLICATION
addappid(353540)
-- Game: addappid(353540)

-- MAIN APP DEPOTS / PACKAGES
addappid(353541, 1, "8ad5462b01bfdd08ea41087fc254078c0249ed54a490b880b2760829b8d62f70")
addappid(353542, 1, "063788497d216236a15f70225f02ebec5cc687483913a772eafcbe7a6f5788cc")
addappid(353543, 1, "43e85715e1aac871e3b6f90bc8aa00c045fe98049d06df1d823ec6e93c6dd488")
addappid(353544, 1, "3202fc49ee1db5ef5cbb7e67f7887b0af68493422f632915a4721ad414e0bea0")
