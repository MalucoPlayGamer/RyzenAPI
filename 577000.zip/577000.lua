-- Lua provided by RyzenAPI
-- Game: addappid(577000)

-- MAIN APPLICATION
addappid(577000)

-- MAIN APP DEPOTS / PACKAGES
addappid(577002,0,"87a8312c0e1c51c9846884252b8aac5e7a70ee39e5f2494cd3da0f0a5fa7df58")
