-- Lua provided by RyzenAPI
-- Game: Game: White Lavender

-- MAIN APPLICATION
addappid(1975670)
-- Game: addappid(1975670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975671, 1, "8181b5879e52a889eac2093805e73eddec95fa80ec54664235f08a77840f9480")
addappid(1975672, 1, "f5cb4fb994d3927d5bfba0d4d0cd444a08d6d64ccf227820d10aec147cb17b8b")
