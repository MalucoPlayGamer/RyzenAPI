-- Lua provided by SkyAPI 
-- Game: Fellowship
addappid(2352620)
addappid(2352621, 1, "60938858a99f1cfbe331ae096354a6c7b0bdb5db303d42eb4feb417074140597")
addappid(4079610)
addappid(4082970)
addappid(4082980)
