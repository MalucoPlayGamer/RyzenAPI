-- Lua provided by RyzenAPI
-- Game: Aberoth

-- MAIN APPLICATION
addappid(354200)

-- MAIN APP DEPOTS / PACKAGES
addappid(354201, 1, "d9c19490fa4abe18bea1c1dd9a50ee859f2c3aaef5d6d152d8ddf934830c1eaf")
addappid(354202, 1, "360028b1e6ac932cad8175f0219caa96616d1dcacaacc710973c09a8bb770d6f")
addappid(354203, 1, "3fff50542369e7a43d02eb6f54931c7d9de6079d9ec5a78fb3b4ebe40d886c61")
addappid(354204, 1, "f5c14b2ed2d29d4e7c93c136edcf9b45df6c59cf3cdd82aee9cb344aa7ff973a")
