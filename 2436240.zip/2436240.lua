-- Lua provided by RyzenAPI
-- Game: Gobbo's Gambit

-- MAIN APPLICATION
addappid(2436240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436241, 1, "414ffb56e51ad504252f831601c0f379d6961fd31c354ebcd97fde4b37f3568d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
