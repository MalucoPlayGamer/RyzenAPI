-- Lua provided by RyzenAPI
-- Game: Gobbo's Gambit

-- MAIN APPLICATION
addappid(2436240)
-- Game: addappid(2436240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436241, 1, "414ffb56e51ad504252f831601c0f379d6961fd31c354ebcd97fde4b37f3568d")
