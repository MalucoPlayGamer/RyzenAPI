-- Lua provided by RyzenAPI
-- Game: Game: One Hunt

-- MAIN APPLICATION
addappid(894330)
-- Game: addappid(894330)

-- MAIN APP DEPOTS / PACKAGES
addappid(894331, 1, "0af32bc0cc1103011a961e6bd30e37f8db89ba2eb3f0e30511d61203af1019b3")
