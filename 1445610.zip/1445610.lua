-- Lua provided by RyzenAPI
-- Game: WW2: Bunker Simulator   Demo

-- MAIN APPLICATION
addappid(1445610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445611, 1, "4271f9252acc4e7f1f7e45f90cb57743442c5be6f8288f65e8d43f40c3e25bb3")
