-- Lua provided by RyzenAPI
-- Game: Lunch Lady

-- MAIN APPLICATION
addappid(1571440)
-- Game: addappid(1571440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571441, 1, "5af4b12644dccedb81bc1ea50e49f8fb4308bf9e6aabd9f26e209a67bd7880d3")
