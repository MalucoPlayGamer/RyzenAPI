-- Lua provided by RyzenAPI
-- Game: AppID 709820

-- MAIN APPLICATION
addappid(709820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(709821, 1, "55f69e5227ab1d054a8bc6ab4e2fe5dc0f3fe4bdca6d82f46da8653d5557112a")
addappid(709822, 1, "51a8c3d518245b475cc84700a8c8ea653ffee7f4b3692ff87ebd12be23806528")
addappid(709823, 1, "f753e4c0d26edcee72c048a85755a3ed2e0a62576460dcf4116cef433cac5888")

