-- Lua provided by RyzenAPI
-- Game: 你已经猜到结局了吗

-- MAIN APPLICATION
addappid(1788850)
-- Game: addappid(1788850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788851, 1, "734df2f28139f8a71a32ef69c370b6a4f154de5d9284b4f5a5d9e18757210f3d")
addappid(2052360, 0, "9d825169961a024c0c9370736b2a5c9c1bcabc283cf6b17e6b6e3b8f2294be7d")
