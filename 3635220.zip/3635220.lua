-- Lua provided by SkyAPI 
-- Game: Zynga Poker ™ – Texas Holdem
addappid(3635220)
addappid(3635221, 1, "228987cdac77fc471e465b52758026b276f5ec70f3a9d5807a7482d434303961")
