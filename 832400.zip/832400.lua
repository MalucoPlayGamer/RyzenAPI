-- Lua provided by RyzenAPI
-- Game: Game: 茂伸奇谈-HAPPY END- Demo

-- MAIN APPLICATION
addappid(832400)
-- Game: addappid(832400)

-- MAIN APP DEPOTS / PACKAGES
addappid(832401, 1, "3126b87e38a0228282baffb8ecf64e14cb82dd080b5560e541038b76f75b6879")
