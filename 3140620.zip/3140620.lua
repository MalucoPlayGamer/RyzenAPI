-- Lua provided by RyzenAPI
-- Game: addappid(3140620)

-- MAIN APPLICATION
addappid(3140620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140621, 1, "6b666c3790c092f34983d87895ab3adc087fc195a6eafe8cd3c85ac64f26636c")
