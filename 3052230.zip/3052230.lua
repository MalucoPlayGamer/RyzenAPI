-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Character EX Pack Gyaru

-- MAIN APPLICATION
addappid(3052230)
-- Game: addappid(3052230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052231, 1, "4859496007c15b2c0ad0fb5f93d39244f00b56f4d09a3a9af04564c65911b3e6")
