-- Lua provided by RyzenAPI
-- Game: Ground Zero Texas - Nuclear Edition

-- MAIN APPLICATION
addappid(1188160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188161, 1, "5b52a9c68da83714e9947b4514dcf3e4750511c485f1a74c892932df4761835a")
