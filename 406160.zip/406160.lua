-- Lua provided by RyzenAPI
-- Game: Game: Dust Fleet

-- MAIN APPLICATION
addappid(406160)
-- Game: addappid(406160)

-- MAIN APP DEPOTS / PACKAGES
addappid(406161, 1, "4a6340235ac704c786b4cf89dd1aac3cd8467682380d00f4f110da731a1b9fe6")
