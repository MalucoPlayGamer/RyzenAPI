-- Lua provided by RyzenAPI
-- Game: Catie in MeowmeowLand

-- MAIN APPLICATION
addappid(1417890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417891, 1, "17fbfc523a48f0dd023da8302d1198617e6f521896e6e44e6d07283df453d214")

