-- Lua provided by RyzenAPI
-- Game: Game: Stowaway

-- MAIN APPLICATION
addappid(1428470)
-- Game: addappid(1428470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428471, 1, "74db53873bb3c6237860f7088736eecfead2ad38ea27050d59b7a5e83e6494c4")
