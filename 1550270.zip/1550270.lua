-- Lua provided by RyzenAPI 
-- Game: Togges
addappid(1550270)
addappid(1550271, 1, "d794532a3fc3594fa6554a480f41da609c4401304be62e6f1f3e0585205739bd")
