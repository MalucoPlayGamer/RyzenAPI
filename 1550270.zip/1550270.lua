-- Lua provided by RyzenAPI
-- Game: Game: Togges

-- MAIN APPLICATION
addappid(1550270)
-- Game: addappid(1550270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550271, 1, "d794532a3fc3594fa6554a480f41da609c4401304be62e6f1f3e0585205739bd")
