-- Lua provided by RyzenAPI
-- Game: Nioh 2 – The Complete Edition

-- MAIN APPLICATION
addappid(1325200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1325201, 1, "20da81589e0a73461a18d3f42426068e48228b81ea86664c8b93ffdf7285762a")
addappid(1325202, 1, "e644223a7b80d05032b8d93def9d0473b80c7430da7e55e3540eefbf0961d0e1")
