-- Lua provided by RyzenAPI
-- Game: Bloody Zombies

-- MAIN APPLICATION
addappid(449640)
-- Game: addappid(449640)

-- MAIN APP DEPOTS / PACKAGES
addappid(449641, 1, "13601a8fc041500f1661c01589c03f6e97b8456979f63d4c797e644f01e2f494")
