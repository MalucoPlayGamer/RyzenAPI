-- Lua provided by RyzenAPI
-- Game: Comic Book Hero: The Greatest Cape

-- MAIN APPLICATION
addappid(422130)
-- Game: addappid(422130)

-- MAIN APP DEPOTS / PACKAGES
addappid(422131, 1, "444a2eacbd9c9731eb9cee1b0058cc49f504aab8611de19b9f550e9184f959fb")
