-- Lua provided by SkyAPI 
-- Game: B.C.E.
addappid(516960)
addappid(516961, 1, "6de65bc7761803bfc94cce99e5a4248136c7d5557ae11360a5941553f6842995")
