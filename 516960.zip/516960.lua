-- Lua provided by RyzenAPI
-- Game: Game: B.C.E.

-- MAIN APPLICATION
addappid(516960)
-- Game: addappid(516960)

-- MAIN APP DEPOTS / PACKAGES
addappid(516961, 1, "6de65bc7761803bfc94cce99e5a4248136c7d5557ae11360a5941553f6842995")
