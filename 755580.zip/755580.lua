-- Lua provided by RyzenAPI
-- Game: Daddy's gone a-hunting

-- MAIN APPLICATION
addappid(755580)

-- MAIN APP DEPOTS / PACKAGES
addappid(755581, 1, "996b6a0a322f1c92db3e346910ec67737bc506d8346d469bfcdb413ef55e3047")
