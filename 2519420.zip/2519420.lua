-- Lua provided by RyzenAPI
-- Game: Cat city

-- MAIN APPLICATION
addappid(2519420)
-- Game: addappid(2519420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519421, 1, "528c659464565657a224465c1bd950a9757201e21c4d4c4e55f47beef36d2a12")
