-- Lua provided by RyzenAPI
-- Game: addappid(1103950)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1103950)
addappid(1103951)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103952,0,"17676a4199f897850866b383781ddf8d772779be295f73edd1df7c0b044ef472")
