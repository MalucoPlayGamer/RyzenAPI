-- Lua provided by RyzenAPI 
-- Game: SkateLab
addappid(2983940)
addappid(2983941, 1, "620f341dbd89ba3cb4eddd84f36f5cc3bb73095b28a59a4b9557ec88173f36d1")
