-- Lua provided by RyzenAPI
-- Game: Game: Harvest Green

-- MAIN APPLICATION
addappid(1455430)
-- Game: addappid(1455430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455431, 1, "8af6f7d4849473046a29d5388f466261242b13ea40b3e006cda8f02726b7a66d")
addappid(1455432, 1, "e3e39ecf1e42f976143eae84259856651843be0148cc4bfee2ebbeb3404838a6")
