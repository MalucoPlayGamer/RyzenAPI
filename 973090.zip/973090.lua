-- Lua provided by RyzenAPI
-- Game: Toilet Simulator

-- MAIN APPLICATION
addappid(973090)

-- MAIN APP DEPOTS / PACKAGES
addappid(973091, 1, "b24fb47273eccc3a0041af2ef12dbd6ff81d2d5dc23280311a5a07fa9425e048")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
