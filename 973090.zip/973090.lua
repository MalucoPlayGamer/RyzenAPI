-- Lua provided by RyzenAPI
-- Game: Toilet Simulator

-- MAIN APPLICATION
addappid(973090)
-- Game: addappid(973090)

-- MAIN APP DEPOTS / PACKAGES
addappid(973091, 1, "b24fb47273eccc3a0041af2ef12dbd6ff81d2d5dc23280311a5a07fa9425e048")
