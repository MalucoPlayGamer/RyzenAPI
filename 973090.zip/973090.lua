-- Lua provided by SkyAPI 
-- Game: Toilet Simulator
addappid(973090)
addappid(973091, 1, "b24fb47273eccc3a0041af2ef12dbd6ff81d2d5dc23280311a5a07fa9425e048")
