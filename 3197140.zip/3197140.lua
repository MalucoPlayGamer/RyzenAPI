-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Cozy Kitsch Kit

-- MAIN APPLICATION
addappid(3197140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197141, 1, "33ef339e07b5d80a42af0248bfdd40488d9c9782d4deed2f0c4669bdeaa0a8c9")
addappid(3197143, 1, "f571a5b17007dfae033cd62b82c8b0dc835bc6ba7f1d5e06cbb556d67f2e6ded")
addappid(3197147, 1, "b230175b4bf87879e65ab182f31b77ad1f1c13c679f3b3b4338668a4b891809f")
addappid(3275161, 0, "770c23fc0ec31ab8c89b1331e9f62fb7103df784ba0b8f331b34e52f2cec0098")
