-- Lua provided by RyzenAPI
-- Game: Defective Holiday

-- MAIN APPLICATION
addappid(1281890)
-- Game: addappid(1281890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281891, 1, "0067981858d1ba443020421146737ed47f5b0a8d2b9579f65fd500014c400d48")
