-- Lua provided by RyzenAPI
-- Game: Escape the Clinic

-- MAIN APPLICATION
addappid(1355930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355931, 1, "795b73e90e8549d52f54e17cac309c1258db50b6b817b5218508649353c818f8")
