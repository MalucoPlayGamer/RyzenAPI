-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross 25 - The Official Video Game

-- MAIN APPLICATION
addappid(2581370)
-- Game: addappid(2581370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581371, 1, "bcb42dd9e43302ffdf68d9320a16c5072985bbf983d65652920b8a0cdc8d5fdd")
