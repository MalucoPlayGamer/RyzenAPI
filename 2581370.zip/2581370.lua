-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross 25 - The Official Video Game

-- MAIN APPLICATION
addappid(2581370)
addappid(3271370)
addappid(3271380)
addappid(3271390)
addappid(3377080)
addappid(3377090)
addappid(3377100)
addappid(3377110)
addappid(3377120)
addappid(3377130)
addappid(3377140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2581371, 1, "bcb42dd9e43302ffdf68d9320a16c5072985bbf983d65652920b8a0cdc8d5fdd")

