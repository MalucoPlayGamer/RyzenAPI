-- Lua provided by RyzenAPI
-- Game: Game: AppID 1492990

-- MAIN APPLICATION
addappid(1492990)
-- Game: addappid(1492990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492991, 1, "4bde1521945cab0dbc2bb4726b12e2d9d9ef6e365d67b7ad358cfc4d0f873348")
