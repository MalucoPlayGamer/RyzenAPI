-- Lua provided by RyzenAPI
-- Game: A Tithe in Blood

-- MAIN APPLICATION
addappid(2989270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989272,0,"4da7c8ba8a0d3883e32876fed327b1f2cfc12e11f30bba9fdf874f0acb81d813")

