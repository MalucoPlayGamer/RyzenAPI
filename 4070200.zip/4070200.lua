-- 4070200's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Sayuri is streaming
-- Created: June 18, 2026 at 04:08:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4070200) -- Hentai Clicker: Sayuri is streaming
-- MAIN APP DEPOTS
addappid(4070201, 1, "645618bf2249b494659458659f22830efe58abde665914b680b959506d4dfe15") -- Depot 4070201
setManifestid(4070201, "1967891146275029320", 164819657)