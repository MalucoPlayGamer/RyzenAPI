-- Lua provided by RyzenAPI
-- Game: Killing Floor

-- MAIN APPLICATION
addappid(1250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251, 1, "948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92")
addappid(1252, 1, "63619af1635f84aaf89f4e199b11c118fe6f2cc1b5d9ee32c4e27f34e2165d9b")
addappid(1258, 1, "d18cf52d5a51542928f279c19c1124cf86e9eac11fb756218b3fba1af58ca302")
addappid(35411, 0, "5e90f263a39ff0aa3e9e0ace96587284b2184c095ac231e603be44cbda000dd5")
addappid(35412, 0, "dba800cf4bf02fa884ed0bc39695f0bdf8ca4bd02c1feec9462d6419ee7faa0d")
addappid(35413, 0, "ea63939f49f1d556594eb7e1e766123a552c1d79beca2b9cb7489bcfdf1991ae")
addappid(35414, 0, "5df9fa1e7461a27775ed92811a64ab5ae935f8148333b9a9d17c81a4c432084e")
addappid(35415, 0, "9438d68a90267aa57aabe35c308be1eb9fce264d10e5f10bc70f110aeaf0c72c")
addappid(35416, 0, "a37d5144d606e876bfc32e9488d20bd11b45ba267b21cbec5825426b30c00d4a")
addappid(35428, 0, "55245614dca5ba68071421dcea7c967d952a2b9b5e753b6d89d497ffff1d4c5c")
addappid(98009, 0, "1a56b7f2c47e6793771a1e9ad64ae9527cd5c64f18c0392ae6e9cdb51781922e")
addappid(210935, 0, "233eadb66d2acac096a4bc5fadb2fb4758899a17c6fbf6fe433c5592da284e40")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1255)
addappid(1256)
addappid(1257)
addappid(35417)
addappid(35418)
addappid(35419)
addappid(35425)
addappid(35426)
addappid(35429)
addappid(210931)
addappid(210932)
addappid(210933)
addappid(210934)
addappid(210936)
addappid(210937)
addappid(210938)
addappid(210939)
addappid(210942)
addappid(210943)
addappid(210944)
addappid(210945)
addappid(258750)
addappid(258751)
addappid(258752)
addappid(309990)
addappid(309991)
addappid(1374790)
addappid(1379540)
addappid(1379541)
addappid(1935740)
addappid(1935741)
