-- Lua provided by RyzenAPI
-- Game: Skater 2D

-- MAIN APPLICATION
addappid(551930)

-- MAIN APP DEPOTS / PACKAGES
addappid(551931, 1, "55cac9cc9950e2b1356fbbbf05938343d34fcb47d881261b9f49fc3f5d5ffe20")
