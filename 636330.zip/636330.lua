-- Lua provided by RyzenAPI
-- Game: The God Paradox

-- MAIN APPLICATION
addappid(636330)

-- MAIN APP DEPOTS / PACKAGES
addappid(636331, 1, "527ddd4ea8b3c0e0b7d0bfec682621a28693c74c9c7771506b952802e07448a0")
addappid(636332, 1, "14eb069f7ead1b20cbb35d15fc8bfb9da811cf7c1d119244ab74c07d8c50f472")

