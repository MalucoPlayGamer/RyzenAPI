-- Lua provided by RyzenAPI
-- Game: Remorse: The List

-- MAIN APPLICATION
addappid(867960)

-- MAIN APP DEPOTS / PACKAGES
addappid(867961, 1, "4f70cca7bd5d1186ef0b1b15a6f9711315f530da3dd7a4be80b86eee77bff6d6")
