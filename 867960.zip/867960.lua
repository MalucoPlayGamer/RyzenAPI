-- Lua provided by RyzenAPI
-- Game: Remorse: The List

-- MAIN APPLICATION
addappid(867960)

-- MAIN APP DEPOTS / PACKAGES
addappid(867961, 1, "4f70cca7bd5d1186ef0b1b15a6f9711315f530da3dd7a4be80b86eee77bff6d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
