-- Lua provided by RyzenAPI
-- Game: Game: Scuttle Demo

-- MAIN APPLICATION
addappid(3278200)
-- Game: addappid(3278200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278201, 1, "690addbc064527647676a055992fcb694eeb39bddaf2ecf6590265b59bd0569c")
