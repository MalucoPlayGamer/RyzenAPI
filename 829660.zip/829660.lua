-- Lua provided by RyzenAPI
-- Game: No Time to Relax

-- MAIN APPLICATION
addappid(829660)

-- MAIN APP DEPOTS / PACKAGES
addappid(829661, 1, "0fe1127cdf38dd2078df4a1e13c6bfd88d20d6dbd6407177ce027a2651c8072c")
addappid(829662, 1, "03b8320ac9ddc30210b4f3ed1a36c6ae3e664d8ed8f1a1ecc5206894df620a24")

