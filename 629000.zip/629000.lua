-- Lua provided by RyzenAPI
-- Game: Lydia

-- MAIN APPLICATION
addappid(629000)

-- MAIN APP DEPOTS / PACKAGES
addappid(629009,0,"e0c8df390c7c2bb17fc698b2c531934d2d6c24d3fca38461ce1a2ca6f38abc4b")
