-- Lua provided by RyzenAPI
-- Game: SourceWorlds

-- MAIN APPLICATION
addappid(1712690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712691, 1, "f53f03c95938893752977bbe2e0a3fe50dc0ca9931efe5a8ea4afd8045d57313")

