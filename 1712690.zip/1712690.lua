-- Lua provided by RyzenAPI
-- Game: SourceWorlds

-- MAIN APPLICATION
addappid(1712690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1712691, 1, "f53f03c95938893752977bbe2e0a3fe50dc0ca9931efe5a8ea4afd8045d57313")

