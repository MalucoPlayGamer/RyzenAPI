-- Lua provided by RyzenAPI
-- Game: addappid(2463090)

-- MAIN APPLICATION
addappid(2463090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463091, 1, "3a26725e17d74032b85cf74681a75d9fa3aa285714c9e467d944ecc66824ceec")
