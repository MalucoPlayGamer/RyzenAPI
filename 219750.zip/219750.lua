-- Lua provided by RyzenAPI
-- Game: Don't Starve Soundtrack

-- MAIN APPLICATION
addappid(219750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248440,0,"26168de66cddde0536aff5aeee9e8b44c871c60a452fecc4342e5aaa65ab464d")
addappid(1248441,0,"a8ed3012b69c98def96c710b2ae1e2efdd10b3c901099ab7fb30871aec7a460c")

