-- Lua provided by RyzenAPI
-- Game: Game: Ballionaire Demo

-- MAIN APPLICATION
addappid(2673520)
-- Game: addappid(2673520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673521, 1, "6f2292efebbbf3a2366554bb2360814d7ea817f2baf78b80ac0dc847318b15e5")
