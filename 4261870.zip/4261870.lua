-- 4261870's Lua and Manifest Created by Hubcap Manifest
-- Pixel Orbit
-- Created: July 20, 2026 at 13:08:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4261870) -- Pixel Orbit
-- MAIN APP DEPOTS
addappid(4261871, 1, "673c10f192fe9f03f948b585b4839f692efb039031c13afb481a149aac2c3946") -- Depot 4261871
setManifestid(4261871, "7308841703268048881", 133052735)