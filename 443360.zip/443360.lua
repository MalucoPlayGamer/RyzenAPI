-- Lua provided by RyzenAPI
-- Game: Game: Red Comrades 2: For the Great Justice. Reloaded

-- MAIN APPLICATION
addappid(443360)
-- Game: addappid(443360)

-- MAIN APP DEPOTS / PACKAGES
addappid(443361, 1, "cc1cf9199200d424c197d728b443986dff9a5879059deb424c0a22c8e9776b63")
addappid(443362, 1, "577f9eef96656d7aab4bb32e21271678fde8ff3d1467644df786e58e76de3492")
