-- Lua provided by SkyAPI 
-- Game: The Heilwald Loophole
addappid(1697720)
addappid(1697721, 1, "18b72d8535c9f09dc6e60b0c19f2c17734e3b8d1d01375c9a16c0f9f4e205b44")
