-- Lua provided by RyzenAPI
-- Game: Game: The Heilwald Loophole

-- MAIN APPLICATION
addappid(1697720)
-- Game: addappid(1697720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697721, 1, "18b72d8535c9f09dc6e60b0c19f2c17734e3b8d1d01375c9a16c0f9f4e205b44")
