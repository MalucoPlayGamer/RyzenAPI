-- Lua provided by RyzenAPI
-- Game: 2170100

-- MAIN APPLICATION
addappid(2170100)
-- Game: addappid(2170100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170101, 1, "3ea16f5fc30b560bcea5be514429a2443c5c6c8dce8a5ca8863eab8a8b81ab01")
