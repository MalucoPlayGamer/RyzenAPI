-- Lua provided by SkyAPI 
-- Game: Volley Pals
addappid(2170100)
addappid(2170101, 1, "3ea16f5fc30b560bcea5be514429a2443c5c6c8dce8a5ca8863eab8a8b81ab01")
