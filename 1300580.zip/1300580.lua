-- Lua provided by SkyAPI 
-- Game: AppID 1300580
addappid(1300580)
addappid(1300581, 1, "e495c829b1860742d4cde2a5f2b71a255e22930ba938cb499f6bdf2915d99ee3")
