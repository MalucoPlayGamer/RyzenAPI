-- Lua provided by RyzenAPI
-- Game: Game: AppID 1300580

-- MAIN APPLICATION
addappid(1300580)
-- Game: addappid(1300580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300581, 1, "e495c829b1860742d4cde2a5f2b71a255e22930ba938cb499f6bdf2915d99ee3")
