-- Lua provided by RyzenAPI
-- Game: Double It

-- MAIN APPLICATION
addappid(3587090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587091, 1, "2e3e3a58cdd70e1badc4b5d64dba857d13ef44f43866bcf1b75e667748784535")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
