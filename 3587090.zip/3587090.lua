-- Lua provided by RyzenAPI
-- Game: Double It

-- MAIN APPLICATION
addappid(3587090)
-- Game: addappid(3587090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587091, 1, "2e3e3a58cdd70e1badc4b5d64dba857d13ef44f43866bcf1b75e667748784535")
