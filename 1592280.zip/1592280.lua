-- Lua provided by RyzenAPI
-- Game: Selaco

-- MAIN APPLICATION
addappid(1592280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592281, 1, "a077492ae4958f6f3c15f8d729767df2e3b8417ead345c8fe4776b97bf03feed")
addappid(1592283, 1, "5cf662d0aa870184d6c4daacab13cdac55ea53f84ca3efbd8e71fe3d8c560cd4")
addappid(1592284, 1, "b3b0285daccc988a23b315e1d321b06a67c36ca7f9eaa30cd95723feebe0d4d1")
addappid(1592286, 1, "b4ce7af6bf12168e278c2d1be6777948b120bb27c1d7ae4d03583a4692191807")
