-- Lua provided by RyzenAPI
-- Game: AppID 576880

-- MAIN APPLICATION
addappid(576880)
-- Game: addappid(576880)

-- MAIN APP DEPOTS / PACKAGES
addappid(576881, 1, "fd7d7703dceeff6809373cb560d3d83856f5cc0d46c420ed826195bcada57df6")
