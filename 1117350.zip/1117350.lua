-- Lua provided by RyzenAPI
-- Game: GALAHAD 3093

-- MAIN APPLICATION
addappid(1117350)
addappid(2131130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1117351, 1, "6aca8e50a96ea435d328b04d9e09c9394e162b7b08c89291aa19a562c99ebe2f")

