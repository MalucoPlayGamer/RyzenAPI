-- Lua provided by RyzenAPI
-- Game: Super Space Pug

-- MAIN APPLICATION
addappid(466840)

-- MAIN APP DEPOTS / PACKAGES
addappid(466841, 1, "cba6a04e9b6d4e641061dee71473eb658f769656dc346833608a9591dceb4c1c")
