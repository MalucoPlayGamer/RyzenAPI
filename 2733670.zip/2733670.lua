-- Lua provided by RyzenAPI
-- Game: Meowhiss the snake

-- MAIN APPLICATION
addappid(2733670)
-- Game: addappid(2733670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733671, 1, "f9ff0b7cb1f67f6a1584c8f74171990954eb39f139da69c236391554d720a766")
