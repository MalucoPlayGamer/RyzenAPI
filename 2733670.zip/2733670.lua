-- Lua provided by RyzenAPI
-- Game: Meowhiss the snake

-- MAIN APPLICATION
addappid(2733670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(2733671, 1, "f9ff0b7cb1f67f6a1584c8f74171990954eb39f139da69c236391554d720a766")

