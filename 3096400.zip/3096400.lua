-- Lua provided by RyzenAPI
-- Game: Game: Beauty Riddle

-- MAIN APPLICATION
addappid(3096400)
-- Game: addappid(3096400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096401, 1, "42203e54c44cd3117550809e04f6b531b56a09283bd556c67b1d03687d20886e")
