-- Lua provided by SkyAPI 
-- Game: Beauty Riddle
addappid(3096400)
addappid(3096401, 1, "42203e54c44cd3117550809e04f6b531b56a09283bd556c67b1d03687d20886e")
