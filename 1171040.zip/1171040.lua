-- Lua provided by SkyAPI 
-- Game: AppID 1171040
addappid(1171040)
addappid(1171041, 1, "93c908b14975b7b6f8fc2e27354c04df171cb42bb806beaf9e2e729b3ae9109d")
addappid(1171042, 1, "6d5d351a8425a5ea5444c724c04c959e87833b518ccbbf00fbf320ee243c6df4")
