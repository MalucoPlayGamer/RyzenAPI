-- Lua provided by RyzenAPI
-- Game: Shadow of the Tomb Raider

-- MAIN APPLICATION
addappid(849160)
addappid(849165)
addappid(849166)
addappid(849167)
addappid(849168)
addappid(849170)
addappid(849171)
addappid(849176)
addappid(849177)
addappid(849178)
addappid(849179)
addappid(849180)
addappid(849181)
addappid(849186)
addappid(849187)
addappid(849188)
addappid(849200)
addappid(849260) -- Shadow of the Tomb Raider - Deluxe Extras
addappid(849261) -- Shadow of the Tomb Raider - Croft Edition Extras
addappid(849262) -- Shadow of the Tomb Raider - Season Pass
addappid(849300) -- Shadow of the Tomb Raider - Spectre Gear
addappid(849301) -- Shadow of the Tomb Raider - Golden Eagle Gear
addappid(849302)
addappid(849303)
addappid(849304)
addappid(849305)
addappid(849306) -- Shadow of the Tomb Raider - The Forge
addappid(849307) -- Shadow of the Tomb Raider - The Pillar
addappid(849308)
addappid(849309)
addappid(849310)
addappid(849311)
addappid(890032)
addappid(930440) -- Early Access DeluxeCroft Edition Owner
addappid(943200)
addappid(1058360)
addappid(1109290)
-- addappid(829778) -- Depot 829778 (empty depot)
-- addappid(829779) -- Depot 829779 (empty depot)
-- addappid(849260) -- Depot 849260 (empty depot)
-- addappid(849261) -- Depot 849261 (empty depot)
-- addappid(849262) -- Depot 849262 (empty depot)
-- addappid(849266) -- Depot 849266 (empty depot)
-- addappid(849267) -- Depot 849267 (empty depot)
-- addappid(849300) -- Depot 849300 (empty depot)
-- addappid(849301) -- Depot 849301 (empty depot)
-- addappid(849306) -- Depot 849306 (empty depot)
-- addappid(849307) -- Depot 849307 (empty depot)
-- addappid(943205) -- Depot 943205 (empty depot)
-- addappid(943206) -- Depot 943206 (empty depot)
-- addappid(943207) -- Depot 943207 (empty depot)
-- addappid(943208) -- Depot 943208 (empty depot)
-- addappid(943209) -- Depot 943209 (empty depot)
-- addappid(991341) -- Depot 991341 (empty depot)
-- addappid(991342) -- Depot 991342 (empty depot)
-- addappid(991361) -- Depot 991361 (empty depot)
-- addappid(991362) -- Depot 991362 (empty depot)
-- addappid(991401) -- Depot 991401 (empty depot)
-- addappid(991402) -- Depot 991402 (empty depot)
-- addappid(991403) -- Depot 991403 (empty depot)
-- addappid(991404) -- Depot 991404 (empty depot)
-- addappid(991405) -- Depot 991405 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(750920, 1, "b7f214c838b6bbcba043a4ac3ecacae4db0be3687613df54c60fa302a57afc79") -- Shadow of the Tomb Raider
addappid(750921, 1, "56dbdfdb61f3d6402ff0443f37e8b3aea76e85148abeb5713dafe832ef44a60b") -- Game Content
addappid(750922, 1, "d2b307fe8b2015f2c355992d281d94a4666a4b37121aaa795a3601ac7f77910e") -- Executable
addappid(750924, 1, "2439121a7abcb93115ba8349a9d2529f55500781ca29e48100c37046de65c235") -- Game Content English
addappid(750925, 1, "93a9010b68140443dc3376b6156fd0d9a0b3e2351091414845312331ed2837eb") -- Game Content French
addappid(750926, 1, "e3c36bf6727dac95592155ce5ce1e1f9d932c60e2fd423aa6b6124c2a865115c") -- Game Content German
addappid(750927, 1, "420107874a734bb2b3854e307019f747e11d8d106d9c3d265567d8905fd6a177") -- Game Content Italian
addappid(750928, 1, "6ea93e79e25cda302915db897e0b8ecefd8c60f80c5b2e1db016faa600cda76a") -- Game Content Spanish
addappid(750929, 1, "3175f9389688f827c905a123d48360bf3b9570367ea418bb1df52169ea55df6b") -- Game Content Portuguese
addappid(792461, 1, "6a3140d277ada5e3c0cca76bea22d2663ac84fe1f76a19433d343744ac6fc07e") -- Game Content Polish
addappid(792462, 1, "077a256f829ecf2b85251c602ec26f910283239c5b9e6e40215d00238621655d") -- Game Content Russian
addappid(792463, 1, "a7bde3203f485eaf3321ea146eacd4bd4ec8d2c3d28f46c7241e7abe993ff0b8") -- Game Content Korean
addappid(792464, 1, "fab6269e12072eee806c2bb87c4726a743513d0699e8af29ced0f3fdc216db8c") -- Game Content Chinese
addappid(792465, 1, "6e3c303bce0599b882fa0eec5e51a194abd5a56fbd70164c40e70dbfe4ab7843") -- Mac - Game Content (750921)
addappid(792466, 1, "e45909db618c9e9f095212948e0cb10ca20ee468eaafa333a47ed79dc94ea5fe") -- Game Content Latam Spanish
addappid(792467, 1, "4cf6f406908d56becb19765fca13de0ee8d2dcd23a73893d32ac1b5c46140d86") -- Game Content Japanese SKU
addappid(792468, 1, "6b1eea01ee931f595b4ed1cbe3c1bb19186b9fd54ef55610a6e317ef68fa5f4c") -- Game Content Arabic SKU
addappid(792469, 1, "282d77af8fa407ad4b334f7134e085e61f5e0ccaab650a2d297f8eaaff825bd3") -- Game Content WWW SKU
addappid(829772, 1, "bb5866bcfdc3890e7cae4ccbbb656e78004be72c0298d7fd7f7af63187cacab6") -- Game Content English KSA
addappid(829774, 1, "3220d7b8457d955af1ec2ab43503e531c2df4e3847c3cf12cea5ade12366b28b") -- Game Content Japanese
addappid(829775, 1, "745ec496e4112085ce0ebe2e720cd50d101dfca68c243bf3b8afd161cbc8513f") -- Game Content Arabic
addappid(829776, 1, "f74e958b11df662bcf7f187945fc68eb5abd627a2860e412000f0490096ed321") -- Game Content Simplified Chinese
addappid(829777, 1, "e3733cb5688b31d740c7416cfe3be8c6ea7d99199bc28bd157eec6bd4d06abae") -- Mac - Executable (750922)
addappid(849160, 1, "387bc990e1e14ab3e17b4668838807070b8b2a4583ebef750f95e419f4944ab7") -- Shadow of the Tomb Raider - Skills Booster Pack - Shadow of the Tomb Raider Skill Booster Pack  (849160) Depot
addappid(849165, 1, "7a86ffdb209e34902689775dbec149e7fa09f4b2600d196699137d1693bf8136") -- Shadow of the Tomb Raider - Original Game Soundtrack - OST (849165) Depot
addappid(849166, 1, "d74e73a7bb8c890f64dea4f76227e41cde9f50b5cd116094f7ea05502514914d") -- Shadow of the Tomb Raider - Robes of Puka Huk - Outfit1_Edition_1 (849166) Depot
addappid(849167, 1, "da9e01c72e83ba5d37b086b3ad70160b684c396ff09d2aea39aaa0638c759407") -- Shadow of the Tomb Raider - Tactical Adventurer (Black) Outfit - Outfit2_Edition_2 (849167) Depot
addappid(849168, 1, "9891a584921e7ec487aedccc86b5262a1a4d1733d5eb78177b83dbfa9186d774") -- Shadow of the Tomb Raider - Explorer Outfit - Outfit3_Edition_3 (849168) Depot
addappid(849170, 1, "3f4a3b86502320cfd8aad10ba6f2bc04f260d44cd0e15c7a1795a8a232e2cf64") -- Shadow of the Tomb Raider - Outfit Brocken - Outfit4_DLC_1 (849170) Depot
addappid(849171, 1, "8eeb3b624e6876d9ecf2909ad9316b9b5ea0649c3ae08aa9bfc596f61cca851a") -- Shadow of the Tomb Raider - Sinchi Chiqa Battle Dress - Outfit5_DLC_2 (849171) Depot
addappid(849176, 1, "a765b4ada6e764e700436c6ee4e22fd6d1597459a2daa8fce48f68ddde0c0592") -- Shadow of the Tomb Raider - Tunic of the Exiled Fox - Outfit10_SP (849176) Depot
addappid(849177, 1, "c71327982a97164202d9d3e43a3cf32f37c1dd4e9c5785cbe54847d47c8782c9") -- Shadow of the Tomb Raider - Puka Huks Bow - Weapon1_Edition_1 (849177) Depot
addappid(849178, 1, "cf31046917e288fceeffdce0a42314e92bbf783eae91221837b570f490ae2259") -- Shadow of the Tomb Raider - KH Kap Pistol - Weapon2_Edition_2 (849178) Depot
addappid(849179, 1, "040a66f75e050d25b4fa9dc86b666744e38676a9b8c327b44819568d2189230f") -- Shadow of the Tomb Raider - Sedgewick 707 Shotgun - Weapon3_Edition_3 (849179) Depot
addappid(849180, 1, "a2d21f85b2f3b23051141f3b25252a27eb65a0fe9158bf24c234109b9e0e2153") -- Shadow of the Tomb Raider - Weapon Umbrage 3-80 - Weapon4_DLC_1 (849180) Depot
addappid(849181, 1, "15f683380dbd3ef2be1df461bbe227fc7e9e651951d7d0006481713ba70d84ce") -- Shadow of the Tomb Raider - Oathtakers Bow - Weapon5_DLC_2 (849181) Depot
addappid(849186, 1, "ad4ac8633bd00104a5e1ded2e5da86e2af20dbf4571340000b2fbc64b104a59c") -- Shadow of the Tomb Raider - Exiled Foxs Bow - Weapon10_SP (849186) Depot
addappid(849187, 1, "6d4fb37522f78418e4773dcbf37e8cbd2778d61dcf890315b5a3a37fa3ad59f2") -- Shadow of the Tomb Raider - The Forge Content - DLC1 (849187) Depot
addappid(849188, 1, "26bf3af5423bb8b28b7402c2cdbb714e3aa5281b14f3f1a0dd802658f62e6855") -- Shadow of the Tomb Raider - The Pillar Content - DLC2 (849188) Depot
addappid(849194, 1, "371f2afe467d1afc4b6efe4db95abbdc3a448aacce718c452162f3e20b62b776") -- Mac - Game Content English (750924)
addappid(849195, 1, "c2643f9ee300e9d7a38c1696961ecfec1492ae7eca2096b14f2f005a360407da") -- Mac - Game Content English KSA (892772)
addappid(849196, 1, "5697169e3cc8f56cf9603bff53b9a7f543281327f2635b40a31b54e1ddc717c6") -- Mac - Game Content French (750925)
addappid(849197, 1, "161288bfdc90d6b180aacc1cd828fe48b7e976f4a315aa29a66e41aa333cd166") -- Mac - Game Content German (750926)
addappid(849198, 1, "920d6aeab59bb87bc5a5b3d6f7596a8a2c9b64878c348cd87c3422ec4cbbbcb1") -- Mac - Game Content Italian (750927)
addappid(849199, 1, "f7bf12776e147ce45e4c30f66d97a647653c917d1d25e5961a2badf62b0e7173") -- Mac - Game Content Spanish (750928)
addappid(849200, 1, "7b16ea559dce0dce7e0f17dd08ff0d125376f1cd1c0fc9f4d6d5671f8814acca") -- Shadow of the Tomb Raider - Official Wallpaper - Wallpaper (849200) Depot
addappid(849201, 1, "fc5f1c22108b0521191b682c362dc2b59251a693e6d8d35b7322e7af440844dc") -- Mac - Game Content Portuguese (750929)
addappid(849202, 1, "22cf010a6783b85678721755cc0481928b766a82e7253e32983d8acd4b7c2b8a") -- Mac - Game Content Polish (792461)
addappid(849203, 1, "429dd614614614247c80522fa08fa0392bc2246ce491b0b2428029387604ef54") -- Mac - Game Content Russian (792462)
addappid(849204, 1, "cb320d1df9cbd074dd663b2ff066560272c1d0388e26bd5d30d9dad88e184c49") -- Mac - Game Content Korean (792463)
addappid(849205, 1, "e04c2a63c226c8d4e938b71ad374bb7673a66df0115e5920bbe8dfeb971b738f") -- Mac - Game Content Chinese (792464)
addappid(849206, 1, "f07633a17924912bf9fe1b535d9ee29104d46f649835ad39368fc4c5bbc01178") -- Mac - Game Content Latam Spanish (792466)
addappid(849207, 1, "f6303abde12934259c772e5963fdb9998891f1da4471ea24e6aea1a5ab41c5ac") -- Mac - Game Content Arabic (829775)
addappid(849208, 1, "f59d9d42cb63ad31822fa44eb354d761b337be78d6f94cbbda2a81c6619d5648") -- Mac - Game Content Japanese (829774)
addappid(849209, 1, "658715cfcda45be4129c9871c6b0bca10e0b6aa8b25eaa322130af3781b49362") -- Mac - Game Content Japanese SKU (792467)
addappid(849263, 1, "243a259671a0021ac7f5bdab2ddb02586d3457be905be103be74941954b1420f") -- Mac - Game Content Arabic SKU (792468)
addappid(849264, 1, "4966bff48df41a162a1828629d289bdc933529cd7544f2500b45087c5ccffc74") -- Mac - Game Content WWW SKU (792469)
addappid(849268, 1, "3ec12dfc4b0f57c12b48ca1ba7b0a7fee29dd636d05fe431464be0e0e407600d") -- Shadow of the Tomb Raider - Skills Booster Pack - Mac - Shadow of the Tomb Raider Skill Booster Pack (849160)
addappid(849302, 1, "f6c936d4db19adad22efe9c30244912145457e5c215d97a3232dddf44e1fe312") -- Shadow of the Tomb Raider - Fear Incarnate Gear - Weapon & Outfit Only Bundle DLC3 (849302) Depot
addappid(849303, 1, "e57a126829d4be97c6566ffe9782a32a7d41509283905083749d04d887557040") -- Shadow of the Tomb Raider - Classic Trinity Gear - Weapon & Outfit Only Bundle DLC4 (849303) Depot
addappid(849304, 1, "45373dbddf27a617e97db5d0ef1637eefe0270dace4c0585495e6bb7819a2c51") -- Shadow of the Tomb Raider - Myth Hunter Gear - Weapon & Outfit Only Bundle DLC5 (849304) Depot
addappid(849305, 1, "4b011e61365a34fd5f7851e3e739d3e592c343d271110a127ff456717c02e5f5") -- Shadow of the Tomb Raider - Force of Chaos Gear - Weapon & Outfit Only Bundle DLC6 (849305) Depot
addappid(849308, 1, "24edfe97f004662ce7c67ed1d2da876a1736f072905d188843d7136d1083adda") -- Shadow of the Tomb Raider - The Nightmare - Full DLC3 (849308) Depot
addappid(849309, 1, "7eeabaa3ab634e5a26eefdf3963acd094d62338a2539077e7bd361b2f8147b8e") -- Shadow of the Tomb Raider - The Price of Survival - Full DLC4 (849309) Depot
addappid(849310, 1, "1c54f45bde07ab63ace04e2b2136b0bbc5e990c0591463a8f93db92727fa0326") -- Shadow of the Tomb Raider - The Serpents Heart - Full DLC5 (849310) Depot
addappid(849311, 1, "13f748f9a6d3f744e5856aacf23ce83425dbd2da9e7e981a54f9119c085e53a0") -- Shadow of the Tomb Raider - The Grand Caiman - Full DLC6 (849311) Depot
addappid(849316, 1, "e8c4a6711b285411a10309cb99807c9bffab96a225ab88d5d0b53a265ac167a5") -- Shadow of the Tomb Raider - Original Game Soundtrack - Mac - OST (849165)
addappid(849317, 1, "bc992345d41de790578962a662657942fef9bfe91e9f7a37d489d9845703340a") -- Shadow of the Tomb Raider - Robes of Puka Huk - Mac - Outfit1_Edition_1 (849166)
addappid(849318, 1, "bc2c1991ad31b636e691d1eb519fb513bcc4b5a4473c61f094253cf9d96820ff") -- Shadow of the Tomb Raider - Tactical Adventurer (Black) Outfit - Mac - Outfit2_Edition_2 (849167)
addappid(849319, 1, "b376c2193598d00516bfe60ee7dad067ae3a8b5c6ed4202011cfa2f520967fff") -- Shadow of the Tomb Raider - Explorer Outfit - Mac - Outfit3_Edition_3 (849168)
addappid(890032, 1, "6c40e38ffeee2c55a878ced581b57cb2227e96871c1a4e4f8da2885779f404dc") -- Shadow of the Tomb Raider - Yellow Shadow Band Resource Pack - Shadow of the Tomb Raider Lucozade Resource Pack (890032) Depot
addappid(890033, 1, "7ba6f4fc091bd19529975d9bd47bf1fcbb8a3ed106e20d3ac2acf4477c7b0e6d") -- Shadow of the Tomb Raider - Outfit Brocken - Mac - Outfit4_DLC_1 (849170)
addappid(890034, 1, "5ca9ade922879c8d3ebfe7f7e0dd569e7d7a65133c4abd39df82e5123e1ab9fb") -- Shadow of the Tomb Raider - Sinchi Chiqa Battle Dress - Mac - Outfit5_DLC_2 (849171)
addappid(890039, 1, "bd4944ea5d37ed3408111e89221972c8367e74d3a3637e29e68b933700500411") -- Shadow of the Tomb Raider - The Nightmare - Mac - Full DLC3 (849308)
addappid(905321, 1, "04022efb6c05d146e9319993396ecb42a01c20efc9bdb283e1444842dcc75870") -- Shadow of the Tomb Raider - The Price of Survival - Mac - Full DLC4 (849309)
addappid(905322, 1, "9b37093fce8ee58d7e815d81c0d732bcd6928b411c5e413a23e34a11e679ba01") -- Shadow of the Tomb Raider - The Serpents Heart - Mac - Full DLC5 (849310)
addappid(905323, 1, "cc5a094dc8b0c54dfa3b4858fd09fa72620c8376da2eed954fba25b815aac460") -- Shadow of the Tomb Raider - The Grand Caiman - Mac - Full DLC6 (849311)
addappid(905324, 1, "6294df699448a3b5a1de75c8f3417289bc18cb51b07a1b7ee0763851b366c936") -- Shadow of the Tomb Raider - Tunic of the Exiled Fox - Mac - Outfit10_SP (849176)
addappid(905325, 1, "db2bbe65b5812c28abb79a6eb6feff0da45fc43bb795be3c56da78398463208e") -- Shadow of the Tomb Raider - Puka Huks Bow - Mac - Weapon1_Edition_1 (849177)
addappid(905326, 1, "007426bb5cf18ccd3063d759327581304799e6d78ce821e177a60b9d5415a868") -- Shadow of the Tomb Raider - KH Kap Pistol - Mac - Weapon2_Edition_2 (849178)
addappid(905327, 1, "ab3dbbd6e40950562e4970b468f4ddc56b9f3e041d7ec5ab188e1056534674cb") -- Shadow of the Tomb Raider - Sedgewick 707 Shotgun - Mac - Weapon3_Edition_3 (849179)
addappid(905328, 1, "e34885014f98dc6cf4ce5dfc60cab1f0ae4c3734296c45965e961d73c51354cb") -- Shadow of the Tomb Raider - Weapon Umbrage 3-80 - Mac - Weapon4_DLC_1 (849180)
addappid(905329, 1, "82df3801ca3c195a91b3177af1a961d9ebd82da9cc57693df1b5c5617667326c") -- Shadow of the Tomb Raider - Oathtakers Bow - Mac - Weapon5_DLC_2 (849181)
addappid(930445, 1, "6cde8f77945ac85014fc09c73edda8a07db74c26c616d9c364d3a16a13b6ea9f") -- Shadow of the Tomb Raider - Exiled Foxs Bow - Mac - Weapon10_SP (849186)
addappid(930446, 1, "d79da3a09064a213a7d5dc4f688cec906b72734df0f876aebb3aac18b2a04709") -- Shadow of the Tomb Raider - The Forge Content - Mac - DLC1 (849187)
addappid(930447, 1, "79144f09826edc70feabf2cacaa56e1f75eb750ef1f67c4166763fbf4eed929c") -- Shadow of the Tomb Raider - The Pillar Content - Mac - DLC2 (849188)
addappid(943200, 1, "a06e1f0dafbe2e3ac02dcc9a9dcc15df6de5c055aaf4f79380b77566c63427c6") -- Shadow of the Tomb Raider - The Path Home - Full DLC7 (943200)
addappid(943204, 1, "86c34db5226c6eb4a0e67e74656ef3ab70042018ebb5fa522f35e29b87fc1481") -- Shadow of the Tomb Raider - Official Wallpaper - Mac - Wallpaper (849200)
addappid(991330, 1, "f0d83741751142ac85369436db8f27d0359ecdae19049f85508a8d6762ae70b3") -- Shadow of the Tomb Raider - Fear Incarnate Gear - Mac - Weapon & Outfit Only Bundle DLC3 (849302)
addappid(991331, 1, "0db0af072389ae259bd8c6f7862d86d1c4a64c6a39bad897cdf780456d55cfcd") -- Shadow of the Tomb Raider - Classic Trinity Gear - Mac - Weapon & Outfit Only Bundle DLC4 (849303)
addappid(991332, 1, "758e27449fc18435413b7f7211105691a44cac54a9b1f09ded69fce39c5e7109") -- Shadow of the Tomb Raider - Myth Hunter Gear - Mac - Weapon & Outfit Only Bundle DLC5 (849304)
addappid(991333, 1, "3bd79ea7c6856b8355a700a224b7df8db454ebc2458e88b7525df468037039e1") -- Shadow of the Tomb Raider - Force of Chaos Gear - Mac - Weapon & Outfit Only Bundle DLC6 (849305)
addappid(991336, 1, "77cb5a69f4c469a7a3b83d40f998b79f3cc7718cfc93f9a992d1221ad174d811") -- Shadow of the Tomb Raider - Yellow Shadow Band Resource Pack - Mac - Shadow of the Tomb Raider Lucozade Resource Pack (890032)
addappid(991337, 1, "350961929179685ac272082dd7c4ef67fa72cc6257409d71b676295fbdd14cb2") -- Mac - Game Content Simplified Chinese (829776)
addappid(991339, 1, "3a94c4041e164cb90fd08d9d2dc34627d5dea6d288a34577d1815818740b8fb0") -- Linux - Game Content (750921)
addappid(991340, 1, "cacf4b8c9aec4cb668d6b0e3b0f958f6333a4e7bedfefe7fe418f62212e2355f") -- Linux - Executable (750922)
addappid(991343, 1, "b876970c33defb7eb861f80a177659708a2b47e1cc67c681622fcc2a8ab6eb64") -- Linux - Game Content English (750924)
addappid(991344, 1, "e57995905cd27a536e53aa20dc69d472cd93fc7abf5d5b01a48426362cad10f8") -- Linux - Game Content English KSA (892772)
addappid(991345, 1, "bd281634b7beeb6ef2ab51dd3c27649a130b2a9c761a03172e0927576e8043f4") -- Linux - Game Content French (750925)
addappid(991346, 1, "9791449ff43ee0cd427900a3a8a0d84d1ccf57a93742bb9d676b70c3eff0855d") -- Linux - Game Content German (750926)
addappid(991347, 1, "79bfa57f10614a84e6f4ef33a0add72728d9b459f0af2568a0c4bea869686300") -- Linux - Game Content Italian (750927)
addappid(991348, 1, "815dd0298686307aab297d6212b0b21ab25e8c51b80330e7eda9780ccb8c8b45") -- Linux - Game Content Spanish (750928)
addappid(991349, 1, "11de1eb362eaab3be4ca55556c9a65395c8ab19646226dcea3237807c8c34ce9") -- Linux - Game Content Portuguese (750929)
addappid(991350, 1, "3649104ca93c33038963b37bda73c47ba08fbbbdbc7da5478a85bd16a3f24ab2") -- Linux - Game Content Polish (792461)
addappid(991351, 1, "0ab02dc1e0c99bf201942ba83ef15032c2bb895f9210f7c8a86452e09070c72f") -- Linux - Game Content Russian (792462)
addappid(991352, 1, "2d0f560eff12a87d1625044ba2ac8b36acb7a3eeaa4e97ee72f0eaf531f5bfe8") -- Linux - Game Content Korean (792463)
addappid(991353, 1, "9f10df702b9198dcfc662d2e4438a5e20b4332640ec36b44af1e97428e696ed5") -- Linux - Game Content Chinese (792464)
addappid(991354, 1, "d22ce384ba0517e42443253c30836861e29294e09d84c84f246904811ce526cb") -- Linux - Game Content Latam Spanish (792466)
addappid(991355, 1, "e34e2ca5a532e70e0c31a2807efc2515be833a4cf13ed1415d0e79837f113998") -- Linux - Game Content Arabic (829775)
addappid(991356, 1, "83eb9ec509bff17bca449ecc4ca7d55687c3d4f980617a31f00982bd03782ba8") -- Linux - Game Content Japanese (829774)
addappid(991357, 1, "a47414f05460a9db408d67c1af32fd6fc8319bcd89076c588e2137fcabcfb727") -- Linux - Game Content Japanese SKU (792467)
addappid(991358, 1, "12ae410b1d13b946de6511b31a6c9d7092f74d9996724ca8e69f3117a795a44c") -- Linux - Game Content Arabic SKU (792468)
addappid(991359, 1, "a8e55ad2e0178646ed7e7d42c94077ad8fdfc1ab57cc71814b24fbfacfd92d0b") -- Linux - Game Content WWW SKU (792469)
addappid(991363, 1, "c02b43949ae2550a56ab28a368a7df45f2208bc4c9ca23067440af80b2d9cd75") -- Shadow of the Tomb Raider - Skills Booster Pack - Linux - Shadow of the Tomb Raider Skill Booster Pack (849160)
addappid(991368, 1, "e92661e8fa5cee1cb417d7ef8cde66d46f5feb1e32300784c9749acc38db6c85") -- Shadow of the Tomb Raider - Original Game Soundtrack - Linux - OST (849165)
addappid(991369, 1, "f4a118440ca84aa0672b135aee83bd1e294510898221f5b8117bfa87e1bf2dd7") -- Shadow of the Tomb Raider - Robes of Puka Huk - Linux - Outfit1_Edition_1 (849166)
addappid(991370, 1, "fecf8283de79ad225e70e9d9db1851604be3b9aab1dca681812339ff6978a3c6") -- Shadow of the Tomb Raider - Tactical Adventurer (Black) Outfit - Linux - Outfit2_Edition_2 (849167)
addappid(991371, 1, "cc2859339f967141db4a057a2cd815763f7173a75111b655364a8ef536b1109c") -- Shadow of the Tomb Raider - Explorer Outfit - Linux - Outfit3_Edition_3 (849168)
addappid(991372, 1, "60766b39cdfaeac01d67f57c993e5ad8400910b42ecae7be077b464c08f072dd") -- Shadow of the Tomb Raider - Outfit Brocken - Linux - Outfit4_DLC_1 (849170)
addappid(991373, 1, "4377e9072b7edcc6826b842c845c13685e20209437bbb9b33d43b7dae2d97b78") -- Shadow of the Tomb Raider - Sinchi Chiqa Battle Dress - Linux - Outfit5_DLC_2 (849171)
addappid(991378, 1, "61761da4936c76f943d9a505552e00c1396cd47f72d6786be1c991bda5874382") -- Shadow of the Tomb Raider - The Nightmare - Linux - Full DLC3 (849308)
addappid(991379, 1, "5183bfdc932342909939a42443ec126da1c9f3e479df2b0ad21bd21429021c2a") -- Shadow of the Tomb Raider - The Price of Survival - Linux - Full DLC4 (849309)
addappid(991380, 1, "179ac41c3a1aad4d30686add3e59d12fb9ebfb954ce1736d84dd87f0b5f67687") -- Shadow of the Tomb Raider - The Serpents Heart - Linux - Full DLC5 (849310)
addappid(991381, 1, "4355a3a395ef5299cd6ce6771646825c6d4fad84fe270e0580a0a7d668c590fa") -- Shadow of the Tomb Raider - The Grand Caiman - Linux - Full DLC6 (849311)
addappid(991382, 1, "e6c7dce41a5954955de45458a58bfa8c7d80557406ce9809f255520d0554a2f4") -- Shadow of the Tomb Raider - Tunic of the Exiled Fox - Linux - Outfit10_SP (849176)
addappid(991383, 1, "f2756a59270dec66fef52c5958c8c5f63ec51cd6fe0778de37519f690b2dae46") -- Shadow of the Tomb Raider - Puka Huks Bow - Linux - Weapon1_Edition_1 (849177)
addappid(991384, 1, "cb7684fab6f8fa4227d70e5613a6744f82469086628e7ce64265183b40eec86d") -- Shadow of the Tomb Raider - KH Kap Pistol - Linux - Weapon2_Edition_2 (849178)
addappid(991385, 1, "5471f9ad66c055e6783519445f37041d2f1a6bd2c686cdd99650109dc66b6b66") -- Shadow of the Tomb Raider - Sedgewick 707 Shotgun - Linux - Weapon3_Edition_3 (849179)
addappid(991386, 1, "97d256f6317623d308e202148791d299c0485620e1d553b68235e279a7b2a147") -- Shadow of the Tomb Raider - Weapon Umbrage 3-80 - Linux - Weapon4_DLC_1 (849180)
addappid(991387, 1, "86458c3d008ca16c1724f0f0e0368a218941a131240d2d18a5dbdd1773a04be7") -- Shadow of the Tomb Raider - Oathtakers Bow - Linux - Weapon5_DLC_2 (849181)
addappid(991392, 1, "b1ff1040afa12689c46d66329b69283f0dc6d473422dda3f2b2bc91865f00b18") -- Shadow of the Tomb Raider - Exiled Foxs Bow - Linux - Weapon10_SP (849186)
addappid(991393, 1, "727613992b86a541251de8b14e9bb37cdd4d16e17e804e028beebba0e76b776c") -- Shadow of the Tomb Raider - The Forge Content - Linux - DLC1 (849187)
addappid(991394, 1, "952db96b00d62f9aab0958f8c360d836c608b12efd3af275341aa680e9a5fa67") -- Shadow of the Tomb Raider - The Pillar Content - Linux - DLC2 (849188)
addappid(991400, 1, "a79ab01d13633b31cab2beb05ff70b59d69f8f88f92072b4804974a063fba30d") -- Shadow of the Tomb Raider - Official Wallpaper - Linux - Wallpaper (849200)
addappid(991406, 1, "602e94cdff0c774a7edbc8940ba94c5a04f97a5d3618351686be6f518c6e1b5f") -- Shadow of the Tomb Raider - Fear Incarnate Gear - Linux - Weapon & Outfit Only Bundle DLC3 (849302)
addappid(991407, 1, "e8e9dc301aa74ff4eebf8877f2c27a15a6d8ba43d9faeb60c317fc894e3dc342") -- Shadow of the Tomb Raider - Classic Trinity Gear - Linux - Weapon & Outfit Only Bundle DLC4 (849303)
addappid(991408, 1, "f020ccdbbe0b353e246329d70c66c816464a8af89d346c9ab62f7460cbbeabf6") -- Shadow of the Tomb Raider - Myth Hunter Gear - Linux - Weapon & Outfit Only Bundle DLC5 (849304)
addappid(991409, 1, "7faa135c7ec09b02f102dc2f050de43ae718b78611edf9c0c698678125e76b9a") -- Shadow of the Tomb Raider - Force of Chaos Gear - Linux - Weapon & Outfit Only Bundle DLC6 (849305)
addappid(991412, 1, "fd31dd3eb1cb2e0fc3c84c73c88f6e3974e86606ba2ecaa0c59f7a2a3f386e3b") -- Shadow of the Tomb Raider - Yellow Shadow Band Resource Pack - Linux - Shadow of the Tomb Raider Lucozade Resource Pack (890032)
addappid(991413, 1, "291c0f4378e3dfdabc035c5437a7096db22ae13f39f098c4c4cfb62955094dde") -- Linux - Game Content Simplified Chinese (829776)
addappid(991415, 1, "86027d7db13cb13a934285da74d211b08445353f8fc4c557dbb7eadbd142f71c") -- Shadow of the Tomb Raider - The Path Home - Mac - Full DLC7 (943200)
addappid(991416, 1, "dea3ef070efbf05428bd315b861f99ec27a41054987325f96792342fee0f221b") -- Shadow of the Tomb Raider - The Path Home - Linux - Full DLC7 (943200)
addappid(991417, 1, "ce21db8936da77abca68e14dfefd824a9e9430e2f760119b9bb934d5ac3e85ff") -- Shadow of the Tomb Raider - Sworn Defender - Mac - Weapon & Outfit Only Bundle DLC7 (1058360)
addappid(991418, 1, "0b9ed2b321fecdfa374fadff0777d5895a635e049ed3834a57a9f36bd487317d") -- Shadow of the Tomb Raider - Sworn Defender - Linux - Weapon & Outfit Only Bundle DLC7 (1058360)
addappid(991419, 1, "870f4bdcc784b02d285276aed0a0ee2e25f627ada25096061a34318e25ea5b44") -- Shadow of the Tomb Raider - Definitive Edition Content - Mac - Full DLC8 (1109290)
addappid(991420, 1, "6e4b79f0afe5e7f9d4b169cc918f4644ffe05f7db2b37d7dfde0e4a94df89cec") -- Shadow of the Tomb Raider - Definitive Edition Content - Linux - Full DLC8 (1109290)
addappid(1058360, 1, "e4c6e569fd184b82091a3c9e27449c439927554bc412acee9e1c587b02773bd4") -- Shadow of the Tomb Raider - Sworn Defender - Weapon & Outfit Only Bundle DLC7 (1058360) Depot
addappid(1109290, 1, "8d66aff22ade47c855790836b50f6c4f32621cf12893de876144fce2e4371d75") -- Shadow of the Tomb Raider - Definitive Edition Content - Full DLC8 (1109290)
addtoken(849160, "8882043331379459006")
addtoken(849171, "6232336317715293192")
addtoken(849181, "13664027529741777647")
addtoken(849188, "11815758407858361964")
addtoken(849200, "8564477102624847234")
addtoken(1109290, "4219646215126977587")
-- addappid(849161) -- DLC 849161 (Only mac and linux keys, which breaks lua)
-- addappid(849162) -- DLC 849162 (Only mac and linux keys, which breaks lua)
-- addappid(849163) -- DLC 849163 (Only mac and linux keys, which breaks lua)
-- addappid(849164) -- DLC 849164 (Only mac and linux keys, which breaks lua)
-- addappid(890030) -- DLC 890030 (Only mac and linux keys, which breaks lua)
-- addappid(890031) -- DLC 890031 (Only mac and linux keys, which breaks lua)
-- addappid(905320) -- DLC 905320 (Only mac and linux keys, which breaks lua)

