-- Lua provided by RyzenAPI
-- Game: Team Fortress 2

-- MAIN APPLICATION
addappid(440)

-- MAIN APP DEPOTS / PACKAGES
addappid(441, 1, "c05cfb536f07ea221c20d5a4f6f7d2444e6190536aa7e53202e41158b443f6bb")
addappid(444, 1, "2e54917111193472b5968afee6b02a48d018774f79762897158ec6f82fd19b79")
addappid(445, 1, "5de23d3a008b6de37e573068f0feda39d55e435f134fb531c80865f6451dad68")
addappid(446, 1, "d0b3a2e80975b0511f08c7129e2c04b6f7e2d8c83b061dfdc915363d4edd392e")
addappid(448, 1, "8ba091d509d3763a7be4e8e6179cb884298cc863a1048784fbca98ee664b5378")
addappid(449, 1, "44eacd2f58fc19987f08ed089dd19bb0009108649246d7ab4459fff29d657bf5")
addappid(232251, 0, "20234395a6d4e6a89257e197259286ac36e725e8dde94ccc468816bb14b35677")
addappid(232252, 0, "2332c85e8962207698d8d77cce22035502d7ab91bdf0891358dad1a0dd92ff46")
addappid(232253, 0, "bdbeae4f56fa865d8df2f76623d3346fcd7e56df6dee13b0f23e4a0fe160a446")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(456)
addappid(457)
addappid(458)
addappid(459)
addappid(217221)
addappid(217222)
