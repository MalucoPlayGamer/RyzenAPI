-- Lua provided by RyzenAPI
-- Game: Mighty Switch Force! Hose It Down!

-- MAIN APPLICATION
addappid(375310)

-- MAIN APP DEPOTS / PACKAGES
addappid(375311, 1, "47125c1465c393f0ef8364582f538cd2c5e36ba747a84c2195fbd659e98e4740")
