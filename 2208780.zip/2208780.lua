-- Lua provided by RyzenAPI
-- Game: Psycho Fear

-- MAIN APPLICATION
addappid(2208780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2208781, 1, "b1bf2fb3eb739d0dbc10debf8519f7b0ae4bc98cf78e5a2ea7f95f3121249b08")

