-- Lua provided by RyzenAPI
-- Game: Psycho Fear

-- MAIN APPLICATION
addappid(2208780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208781, 1, "b1bf2fb3eb739d0dbc10debf8519f7b0ae4bc98cf78e5a2ea7f95f3121249b08")
