-- Lua provided by RyzenAPI
-- Game: Hello Kitty Island Adventure

-- MAIN APPLICATION
addappid(2495100)
-- Game: addappid(2495100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495101, 1, "62b02a1a603b53787ec2fea81ea2b505fdca436fa17d52d82e3df9097e14fab7")
