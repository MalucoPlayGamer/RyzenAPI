-- Lua provided by RyzenAPI
-- Game: fault Series ORIGINAL SOUNDTRACK vol 1

-- MAIN APPLICATION
addappid(408360)

-- MAIN APP DEPOTS / PACKAGES
addappid(408361, 1, "ac14034fab04227d0ee7a4744671c2bc7ce09dec9adb307e50113a64a364a6e3")
