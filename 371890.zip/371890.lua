-- Lua provided by RyzenAPI
-- Game: Gunslugs

-- MAIN APPLICATION
addappid(371890)
-- Game: addappid(371890)

-- MAIN APP DEPOTS / PACKAGES
addappid(371891, 1, "efc6ca2c1e1cebda6dab58cc03201835f36428152291b20160e7badabfabb8eb")
addappid(371892, 1, "c51414cf0d22220587bf267939160bd8cd7c0225120899ef849e9893251ee9a5")
addappid(371893, 1, "8dc35a1de7ecc2da058ab03fd7f8d6bcdf02a28885b208ad563e64eb55265e69")
