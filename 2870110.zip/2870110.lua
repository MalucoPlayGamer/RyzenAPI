-- Lua provided by RyzenAPI
-- Game: Tennis Manager 2024

-- MAIN APPLICATION
addappid(2870110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2870111, 1, "c0c6dc5725b1b8f4f308601bb21e2cdc40eb936bebc725d38148e219370af25f")

