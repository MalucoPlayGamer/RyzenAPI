-- Lua provided by RyzenAPI
-- Game: Game: Tennis Manager 2024

-- MAIN APPLICATION
addappid(2870110)
-- Game: addappid(2870110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870111, 1, "c0c6dc5725b1b8f4f308601bb21e2cdc40eb936bebc725d38148e219370af25f")
