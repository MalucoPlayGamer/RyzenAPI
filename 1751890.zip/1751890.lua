-- Lua provided by SkyAPI 
-- Game: The Red Exile: Survival Horror
addappid(1751890)
addappid(1751891, 1, "c3da0d149b8cbffd47004b0c0ee43991a2f8a612638ac9560f15ed769d9456a3")
