-- Lua provided by RyzenAPI
-- Game: addappid(1751890)

-- MAIN APPLICATION
addappid(1751890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751891, 1, "c3da0d149b8cbffd47004b0c0ee43991a2f8a612638ac9560f15ed769d9456a3")
