-- Lua provided by RyzenAPI
-- Game: addappid(1563840)

-- MAIN APPLICATION
addappid(1563840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563841, 1, "81250bd1ff6a946621cdf803d70d5a872646c96cda751d89c68dc4764ce22e05")
