-- Lua provided by SkyAPI 
-- Game: 蚂蚁模拟器（Ant simulator）
addappid(1563840)
addappid(1563841, 1, "81250bd1ff6a946621cdf803d70d5a872646c96cda751d89c68dc4764ce22e05")
