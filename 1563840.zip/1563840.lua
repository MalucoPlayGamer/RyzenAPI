-- Lua provided by RyzenAPI
-- Game: 蚂蚁模拟器（Ant simulator）

-- MAIN APPLICATION
addappid(1563840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1563841, 1, "81250bd1ff6a946621cdf803d70d5a872646c96cda751d89c68dc4764ce22e05")

