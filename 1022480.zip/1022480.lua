-- Lua provided by RyzenAPI
-- Game: 1022480

-- MAIN APPLICATION
addappid(1022480)
-- Game: addappid(1022480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022481, 1, "c518fdc5cf8fbef373dd1c832241b7a93921330503fa63d253e5b1378a6532cc")
