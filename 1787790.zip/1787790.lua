-- Lua provided by RyzenAPI
-- Game: addappid(1787790)

-- MAIN APPLICATION
addappid(1787790)
addappid(1787791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787792,0,"58f680025ac0437e4f6b8ec1a924e2d4be5c277fb5a27416ef0f69e9cfdab4d4")
