-- Lua provided by RyzenAPI
-- Game: addappid(2593890)

-- MAIN APPLICATION
addappid(2593890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593891, 1, "cd83ff61ec4d703fc26e05ae2118171301ad20a8c87cd41463a5a8fec32f097f")
addappid(2593892, 1, "619c605b5c006ca4dcda3fe636d4b2b4c03984b5a96ea88446f04dbe4a3f3e51")
