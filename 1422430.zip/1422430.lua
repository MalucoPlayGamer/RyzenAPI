-- Lua provided by RyzenAPI
-- Game: Next Space Rebels

-- MAIN APPLICATION
addappid(1422430)
-- Game: addappid(1422430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422431, 1, "c9634b772b843f6e499d8a7c89990dcbfa250128c5785d2a0a0333c225eb0a11")
addappid(1422432, 1, "4c86cba482ae5c058a12108b3989e46bb9d5d23e09c4548740a0d596c5dca9d6")
