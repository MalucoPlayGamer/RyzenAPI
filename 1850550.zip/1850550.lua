-- Lua provided by RyzenAPI
-- Game: Game: I'm on Observation Duty 5

-- MAIN APPLICATION
addappid(1850550)
-- Game: addappid(1850550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850551, 1, "f1500874439fe839ef88213e995a26676f3e3a1101598ea605aaae95432c7582")
addappid(1850552, 1, "d2065b8dcb4edf64caf597170309532412ae8bd25f689172c765777dd12fcb3c")
addappid(1850553, 1, "b5e5243e926cca28d8ba014056793d5321ddd763ac81e18e5c948f53f2575f0d")
