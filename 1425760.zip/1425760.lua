-- Lua provided by RyzenAPI
-- Game: Pulling No Punches

-- MAIN APPLICATION
addappid(1425760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425761, 1, "42b0f77fc3f89fb266101a3bb8d4d64cff2f9da54f854973cb6b626f13ddd87a")

