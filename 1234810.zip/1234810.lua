-- Lua provided by RyzenAPI
-- Game: Unbound: Worlds Apart Prologue

-- MAIN APPLICATION
addappid(1234810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1234811, 1, "b6c8293542d0c44f41ffa88659d13b8ad996346f340dbbfcc3bade4cb19a8e04")

