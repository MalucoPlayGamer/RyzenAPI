-- Lua provided by RyzenAPI
-- Game: Unbound: Worlds Apart Prologue

-- MAIN APPLICATION
addappid(1234810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234811, 1, "b6c8293542d0c44f41ffa88659d13b8ad996346f340dbbfcc3bade4cb19a8e04")
