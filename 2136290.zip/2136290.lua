-- Lua provided by RyzenAPI 
-- Game: Space Roguelike Adventure Demo
addappid(2136290)
addappid(2136291, 1, "2cddc6068b2a15c5228ac3f04425093f032b5dc616e4151eef376af028a88a21")
