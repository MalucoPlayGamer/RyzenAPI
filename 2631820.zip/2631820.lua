-- Lua provided by RyzenAPI
-- Game: AppID 2631820

-- MAIN APPLICATION
addappid(2631820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631821, 1, "a426de662c3af1b21dbf664dbe7ef14f407b19ed13a038535c6d38a5ece2db0b")
