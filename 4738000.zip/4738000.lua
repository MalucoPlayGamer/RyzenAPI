-- Lua provided by RyzenAPI
-- Game: My Sexy Fairies

-- MAIN APPLICATION
addappid(4738000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4738001, 1, "aadf6861eee799003d62ed87e21343ed326f57d4e4fbf18de23d05f2620f4d5f")

