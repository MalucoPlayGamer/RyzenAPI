-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REBIRTH

-- MAIN APPLICATION
addappid(2909400)
addappid(3260650)
addappid(3312260)
addappid(3312270)
addappid(3312280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909401, 1, "7ab31662f5cf76b4197f27c340a2a0589dc4713c137aadfd22b281df42c07a56")
addappid(2909402, 1, "fd15686ace81b2e7a839997e1bcc40d7dd9c15f49ce21714252771aa357fd67f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3260630)
addappid(3260660)
addappid(3260670)
addappid(3260680)
addappid(3361450)
addappid(3376810)
