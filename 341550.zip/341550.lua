-- Lua provided by RyzenAPI
-- Game: Super Cyborg

-- MAIN APPLICATION
addappid(341550)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(341551, 1, "60bcaf6ffd69e03eb07664da306e6fe04742f89941093424166f8561b55c793e")
