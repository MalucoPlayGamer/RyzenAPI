-- Lua provided by RyzenAPI
-- Game: 341550

-- MAIN APPLICATION
addappid(341550)
-- Game: addappid(341550)

-- MAIN APP DEPOTS / PACKAGES
addappid(341551, 1, "60bcaf6ffd69e03eb07664da306e6fe04742f89941093424166f8561b55c793e")
