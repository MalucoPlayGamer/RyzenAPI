-- Lua provided by RyzenAPI 
-- Game: Nature's Zombie Apocalypse
addappid(378530)
addappid(378531, 1, "ceb2ee4500c93f3f72518bc521772dcf8387bb335ada5632221e273059f9d5d7")
