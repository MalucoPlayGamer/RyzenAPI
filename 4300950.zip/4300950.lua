-- 4300950's Lua and Manifest Created by Hubcap Manifest
-- Around The Core
-- Created: August 21, 2026 at 22:56:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4300950) -- Around The Core
-- MAIN APP DEPOTS
addappid(4300951, 1, "abffa9a1a9d980a02f62b3ea36c58b989ce866b2e53f638bd9fbff9fad847934") -- Depot 4300951
setManifestid(4300951, "5997605041176659046", 497496701)
addappid(4300952, 1, "113865e6172c6d0facdfd095128e0e1df534283d27c8621af1eb6102269b3ac9") -- Depot 4300952
setManifestid(4300952, "7762875356057763606", 569297089)