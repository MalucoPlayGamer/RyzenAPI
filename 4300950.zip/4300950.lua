-- Lua provided by RyzenAPI
-- Game: Around The Core

-- MAIN APPLICATION
addappid(4300950) -- Around The Core

-- MAIN APP DEPOTS / PACKAGES
addappid(4300951, 1, "abffa9a1a9d980a02f62b3ea36c58b989ce866b2e53f638bd9fbff9fad847934") -- Depot 4300951
addappid(4300952, 1, "113865e6172c6d0facdfd095128e0e1df534283d27c8621af1eb6102269b3ac9") -- Depot 4300952

