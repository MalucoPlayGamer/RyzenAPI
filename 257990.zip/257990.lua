-- Lua provided by SkyAPI 
-- Game: Oozi: Earth Adventure
addappid(257990)
addappid(257991, 1, "7581c644bd586d567763015a393d12573a6c6f9b8626534db229b318e1551532")
