-- Lua provided by RyzenAPI
-- Game: Oozi: Earth Adventure

-- MAIN APPLICATION
addappid(257990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(257991, 1, "7581c644bd586d567763015a393d12573a6c6f9b8626534db229b318e1551532")

