-- Lua provided by RyzenAPI
-- Game: Game: AppID 530390

-- MAIN APPLICATION
addappid(530390)
-- Game: addappid(530390)

-- MAIN APP DEPOTS / PACKAGES
addappid(530391, 1, "958f6097b6ea2be0de528db5d5cc2a4aaf8647fcfa62ca7e7e6aabbbcc68f0e6")
addappid(530392, 1, "c079de3257041f3480741bef966dc42eed4781ab0e1f580fcf9534050d6b6bd1")
addappid(530393, 1, "c6598fc8f5d6e4aecba8200fa8a4d08166929ebefe2af3b5f661bf15d8906c00")
addappid(540730, 0, "33762efdb4ef0c239a548df191b7f7629a88e0bdbd4b5fba2ccbbc946456ee3a")
addappid(559670, 0, "88753d30293515e355609fcdcf6e445438b7066e7ab7884196f7ad61711dbf38")
