-- Lua provided by RyzenAPI
-- Game: Headquarters: World War II Demo

-- MAIN APPLICATION
addappid(2231030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231031, 1, "9af0e7669d422cfe6ad69bc09b76f71177c2e676a48b85241d0c198be323b1a9")
addappid(2231032, 1, "59852f830ce59ce63225f03c4b282677313922adaba265235b0fc2766023f6b9")
