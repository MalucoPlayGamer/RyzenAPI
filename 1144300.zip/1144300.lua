-- Lua provided by RyzenAPI
-- Game: addappid(1144300)

-- MAIN APPLICATION
addappid(1144300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144301, 1, "23d040c83263c90ade9bd184a2ccf087c8639e9f4c76b0b069ce21bbbed780a8")
addappid(1144302, 1, "e732ef3ce1b0ef5c79c00ec927c48b39c637f70267ff671a329e257df058017f")
