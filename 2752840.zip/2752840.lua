-- Lua provided by RyzenAPI
-- Game: Game: 渔海

-- MAIN APPLICATION
addappid(2752840)
-- Game: addappid(2752840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752841, 1, "bfa85100bb7bfdc85bc3e92b474d31fad77b2810486e37ee1cd14b81965f0983")
