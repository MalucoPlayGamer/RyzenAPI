-- Lua provided by RyzenAPI
-- Game: Drunk: Relapsed Demo

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2150980)
addappid(2150981)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150982,0,"605df368dc95aafdbaad4b95943700591c4573dafa1880814ebd29358efd3e2f")

