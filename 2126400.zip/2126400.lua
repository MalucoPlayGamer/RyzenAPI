-- Lua provided by RyzenAPI
-- Game: Super Kill-BOI 9000

-- MAIN APPLICATION
addappid(2126400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126401, 1, "70cfee264352f4ab1a12b4f1ec24abb8d140de3040c2630816c979280cfa597d")

