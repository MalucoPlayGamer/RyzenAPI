-- Lua provided by RyzenAPI
-- Game: Makai Kingdom: Reclaimed and Rebound

-- MAIN APPLICATION
addappid(1732060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732061, 1, "1f0cf0e489a8339b871a11abae96302706e80454afada8b0c6c530d0adb8bc1b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1959150)
