-- Lua provided by RyzenAPI
-- Game: 我和妹子的爱恨情仇DEMO

-- MAIN APPLICATION
addappid(2464560)
-- Game: addappid(2464560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464561, 1, "f8ec4885137ac2f88a041e7eef5628625a624e058fabe1d946a295839411595f")
