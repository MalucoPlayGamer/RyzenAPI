-- Lua provided by RyzenAPI
-- Game: Game: Recolit Demo

-- MAIN APPLICATION
addappid(1748040)
-- Game: addappid(1748040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748041, 1, "30f05d332d07c92c810d00660c5467705467b21b06e25ff126d5ebef05081583")
