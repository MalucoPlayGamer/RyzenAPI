-- Lua provided by RyzenAPI
-- Game: 1917110

-- MAIN APPLICATION
addappid(1917110)
-- Game: addappid(1917110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917111, 1, "720325d6676bcf745134f0ea57b6af7d90df73dc509d3cca9b36e78f1a7a7eb2")
