-- Lua provided by RyzenAPI
-- Game: addappid(662270)

-- MAIN APPLICATION
addappid(662270)

-- MAIN APP DEPOTS / PACKAGES
addappid(662271, 1, "da01aacd4097d4378ea72492764cc1d1965e8a4a4b59f18ec27181607eeedf63")
