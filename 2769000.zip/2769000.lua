-- Lua provided by RyzenAPI
-- Game: Chessire Demo

-- MAIN APPLICATION
addappid(2769000)
-- Game: addappid(2769000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769001, 1, "5264ac21bf18da5ec19a066e2f9e7cb06698152f9b500eb7cde484c3d0e01e6a")
