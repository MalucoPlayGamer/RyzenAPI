-- Lua provided by RyzenAPI
-- Game: Game: 恋爱单选题

-- MAIN APPLICATION
addappid(2865490)
-- Game: addappid(2865490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865491, 1, "4a5ab7923257656e33bae19469a051c8648fe4f3d4ec40283d471c8118390b0b")
