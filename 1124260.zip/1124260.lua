-- Lua provided by SkyAPI 
-- Game: AppID 1124260
addappid(1124260)
addappid(1124261, 1, "18bc51c020f9fcb8eff231e026113f63dd27afdcabf0a3367810b6bcf98e6aa9")
addappid(1124262, 1, "8dc4af4f7fe2f53388efe9e35cc77263da57a7670b753df2d970d6032f3579e0")
addappid(1124263, 1, "445aa853cbbb0ba0b91ecb4d375e9a1f69f3a9802fb0fc4445914d357ae5fe0b")
addappid(1124264, 1, "00f36b4e84dae892dba24dfed0c0fa196337b4d8f1e93ce998fa02198087e0bd")
