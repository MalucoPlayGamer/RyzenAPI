-- Lua provided by RyzenAPI
-- Game: Demon Goblin and Mr. Knight 小鬼哥布林與騎士先生

-- MAIN APPLICATION
addappid(3526830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3526831, 1, "da83e205998bdd3eaa8fedf5747a7f8c5dfe2730427d5c6e8be1eb4cde9af906")

