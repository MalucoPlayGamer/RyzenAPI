-- Lua provided by RyzenAPI
-- Game: Game: Tiny Witch

-- MAIN APPLICATION
addappid(1740310)
-- Game: addappid(1740310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740311, 1, "d2b45d905c99f372d1c0d2a82a6c7e7961baba4c2b59e99c8c3c97c3a56c5056")
