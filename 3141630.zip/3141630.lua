-- Lua provided by RyzenAPI
-- Game: Montabi

-- MAIN APPLICATION
addappid(4946140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141630, 1, "4e262aa2cb3f80d0939723f0e83bea3993c04f30182204e428157cf1c06cf648") -- Montabi
addappid(3141631, 1, "b911a48b7e70338d2b3a6aa031bb231c5fd380697a82ffe75853775b2979e922") -- Depot 3141631
addappid(3141632, 1, "7593d9db3318d514ce3ae500b7e3a840dbf87dec99a8ba66ef72fa5c9f333c7a") -- Depot 3141632
addappid(4946140, 1, "6c75534276479b1a4a4ddb63a28f2f532815abe2928fc0853c9c379ba6b7988c") -- Montabi - Art Book - Depot 4946140

