-- 3141630's Lua and Manifest Created by Hubcap Manifest
-- Montabi
-- Created: August 06, 2026 at 14:59:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3141630, 1, "4e262aa2cb3f80d0939723f0e83bea3993c04f30182204e428157cf1c06cf648") -- Montabi
-- MAIN APP DEPOTS
addappid(3141631, 1, "b911a48b7e70338d2b3a6aa031bb231c5fd380697a82ffe75853775b2979e922") -- Depot 3141631
setManifestid(3141631, "5713439049422976743", 1684809427)
addappid(3141632, 1, "7593d9db3318d514ce3ae500b7e3a840dbf87dec99a8ba66ef72fa5c9f333c7a") -- Depot 3141632
setManifestid(3141632, "1387301440274367714", 1798256638)
-- DLCS WITH DEDICATED DEPOTS
-- Montabi - Art Book (AppID: 4946140)
addappid(4946140)
addappid(4946140, 1, "6c75534276479b1a4a4ddb63a28f2f532815abe2928fc0853c9c379ba6b7988c") -- Montabi - Art Book - Depot 4946140
setManifestid(4946140, "2817375048785278672", 404042546)