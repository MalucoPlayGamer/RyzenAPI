-- Lua provided by RyzenAPI
-- Game: 794030

-- MAIN APPLICATION
addappid(794030)
-- Game: addappid(794030)

-- MAIN APP DEPOTS / PACKAGES
addappid(794031, 1, "11c7bca499ac16241123781a8ce4a2d6713b66139c6e4902326a6f1478cbaafd")
