-- Lua provided by RyzenAPI
-- Game: Game: AppID 1085610

-- MAIN APPLICATION
addappid(1085610)
-- Game: addappid(1085610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085611, 1, "decdd59e2547dd8f8f843a50d66acad6609c114b8da59f30076a8178e2c75f49")
