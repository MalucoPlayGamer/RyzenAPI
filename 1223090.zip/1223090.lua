-- Lua provided by RyzenAPI
-- Game: Emily Archer and the Curse of Tutankhamun

-- MAIN APPLICATION
addappid(1223090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223091, 1, "430748fb853f3fddd0b227f20a5b3c3af18b35dc42f24efbe99eee41067595d8")
