-- Lua provided by RyzenAPI
-- Game: Gravity Circuit Demo

-- MAIN APPLICATION
addappid(2104650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104651, 1, "7285ba70192c5cc625939a6e2eee6bf537b52839e61be76192ea6eae607b46ff")
