-- Lua provided by RyzenAPI
-- Game: 1221852

-- MAIN APPLICATION
addappid(1221852)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221852,0,"6ef8af5f6109dfa7f681cede4b9111e4ada39f06c8c76a749b39cba92f429a66")
