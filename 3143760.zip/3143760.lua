-- Lua provided by RyzenAPI
-- Game: Marry a Deep One: Innsmouth Simulator

-- MAIN APPLICATION
addappid(3143760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143761, 1, "84c763c6d91312618c7c46d7f4dd779c1e850334604a9b032da8da02b538551e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
