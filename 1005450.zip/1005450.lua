-- Lua provided by RyzenAPI
-- Game: Vision Soft Reset

-- MAIN APPLICATION
addappid(1005450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005451, 1, "2c866e5a9e16716fd957375ad45325a9e60605b68d61b76060e42ebbb625f340")
