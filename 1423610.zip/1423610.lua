-- Lua provided by RyzenAPI
-- Game: Tales from Zilmurik

-- MAIN APPLICATION
addappid(1423610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423611, 1, "f348dbb2ed387b80a1653e694e824999df10c8b193e48d9d67efb43fc53b6fda")

