-- Lua provided by RyzenAPI
-- Game: 2249460

-- MAIN APPLICATION
addappid(2249460)
-- Game: addappid(2249460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249461, 1, "d666654864d3733b24faace8ad61790e21c916094bb75655e5f366e46d9f4dea")
