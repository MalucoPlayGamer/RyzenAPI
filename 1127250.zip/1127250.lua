-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228987)
addappid(228990)
addappid(229006)
addappid(229012)
addappid(229020)
addappid(229033)
addappid(1127250)
addappid(1127251)
addappid(1127252)
-- Game: addappid(1127250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130220,0,"5c715ee27c33f20acc9c55b45763df0e8d2ac57165b199dd3b931328bdcd38f0")
