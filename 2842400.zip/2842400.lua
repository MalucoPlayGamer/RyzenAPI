-- Lua provided by SkyAPI 
-- Game: AppID 2842400
addappid(2842400)
addappid(2842401, 1, "daace7628064e211960bf3c58a0e93246df30896d36e92fdf5d62cad5f4f697d")
