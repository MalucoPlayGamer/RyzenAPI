-- Lua provided by RyzenAPI
-- Game: While Waiting Demo

-- MAIN APPLICATION
addappid(2842400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842401, 1, "daace7628064e211960bf3c58a0e93246df30896d36e92fdf5d62cad5f4f697d")
