-- Lua provided by RyzenAPI
-- Game: 375250

-- MAIN APPLICATION
addappid(375250)
-- Game: addappid(375250)

-- MAIN APP DEPOTS / PACKAGES
addappid(375251, 1, "6c1dd5332448def58f3acf041a51da6655ffce5b68672d080b61dc9351fb55b1")
