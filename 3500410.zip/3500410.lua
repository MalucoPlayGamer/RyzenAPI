-- Lua provided by SkyAPI 
-- Game: 󠀡󠀡
addappid(3500410)
addappid(3500411, 1, "31065f8209bf2d3f2436b50afd21b32d00bb747a6510ce41d66c333d26d8a64d")
