-- Lua provided by RyzenAPI 
-- Game: Stay Out Of The Farm: Prologue
addappid(2166490)
addappid(2166491, 1, "be4702485c052f73f29eb4800e6960e35437f9eec07bbb121ea5127aef947867")
