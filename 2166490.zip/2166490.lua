-- Lua provided by RyzenAPI
-- Game: Stay Out Of The Farm: Prologue

-- MAIN APPLICATION
addappid(2166490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166491, 1, "be4702485c052f73f29eb4800e6960e35437f9eec07bbb121ea5127aef947867")

