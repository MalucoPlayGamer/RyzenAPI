-- Lua provided by RyzenAPI
-- Game: AppID 58400

-- MAIN APPLICATION
addappid(58400)

-- MAIN APP DEPOTS / PACKAGES
addappid(58401, 1, "356f01cb067f1df2c5ec5b6f755ae4f11301dc398e970e35ea9e4e9f6c1e2b18")

