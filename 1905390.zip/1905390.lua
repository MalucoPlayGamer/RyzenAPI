-- Lua provided by RyzenAPI
-- Game: Risk of Rain 2: Survivors of the Void - Soundtrack

-- MAIN APPLICATION
addappid(1905390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905393,0,"f8ae1eab05f478f114bc7a9285ce1fbabe29c9a8fa932469d4650079d30185b9")
addappid(1905394,0,"99f1bb81bde821aff6c4d39dd440b7c43e9c8e4ff45d35193f99c83f07bba3a4")

