-- Lua provided by RyzenAPI
-- Game: Atelier Marie Remake: The Alchemist of Salburg

-- MAIN APPLICATION
addappid(2138090)
addappid(2296600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2138091, 1, "d6e28b10a983e0ea312f862604580bc5e9f3a9ed43c33da6ec85a2fe1f4d8396")
addappid(2208450, 0, "5fc1ba0661996fc11482796740067dab5888c518f2f042604b2f188cbad04cbb")
addappid(2261010, 0, "11b653c7577d5c65e11f4d4bfc481bd53bf146055f425366a7aa0fc870d5496a")
addappid(2261011, 0, "329240972cb6c6caaaf644bfc469081d82224728f74df7545915ff82f48d215b")

