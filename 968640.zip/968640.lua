-- Lua provided by RyzenAPI
-- Game: 968640

-- MAIN APPLICATION
addappid(968640)
-- Game: addappid(968640)

-- MAIN APP DEPOTS / PACKAGES
addappid(968642,0,"3fdde7b322dd8df9d8749bf89adde45e777eb1debb7e9535853d9cbf5e0a6789")
