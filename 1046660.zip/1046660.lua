-- Lua provided by RyzenAPI
-- Game: addappid(1046660)

-- MAIN APPLICATION
addappid(1046660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046661, 1, "e0c1e7bbb596acc9df2d8bca2bedc6c5f24ebcd3d84c08d24ae9c12214db7151")
