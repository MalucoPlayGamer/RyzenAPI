-- Lua provided by RyzenAPI
-- Game: 1815530

-- MAIN APPLICATION
addappid(1815530)
-- Game: addappid(1815530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815531, 1, "b1be1001f79652095dfbc597f9ba43ad9719f94f4170b6b1a7282a795a736c67")
