-- Lua provided by RyzenAPI
-- Game: Horse Tales: Emerald Valley Ranch 

-- MAIN APPLICATION
addappid(1474740)
addappid(2154320)
addappid(2164520)
addappid(2583480)
addappid(2583490)
addappid(2583520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474741,0,"5e4cde8ee4d971842c65f7cc30af82320812877a5ced9b1309be0350e0fad556")

