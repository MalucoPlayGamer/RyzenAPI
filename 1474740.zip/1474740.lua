-- Lua provided by RyzenAPI
-- Game: Horse Tales: Emerald Valley Ranch

-- MAIN APPLICATION
addappid(1474740)
addappid(2154320)
addappid(2164520)
addappid(2583480)
addappid(2583490)
addappid(2583520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1474741,0,"5e4cde8ee4d971842c65f7cc30af82320812877a5ced9b1309be0350e0fad556")

