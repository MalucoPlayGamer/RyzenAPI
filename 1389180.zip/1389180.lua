-- Lua provided by RyzenAPI
-- Game: 1389180

-- MAIN APPLICATION
addappid(1389180)
-- Game: addappid(1389180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389181, 1, "8f7de585f9f176c4b53ddc597357d0fd02415a35bc3decd50e68936fbefe2bbf")
