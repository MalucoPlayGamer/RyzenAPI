-- Lua provided by RyzenAPI
-- Game: Game: AppID 512770

-- MAIN APPLICATION
addappid(512770)
-- Game: addappid(512770)

-- MAIN APP DEPOTS / PACKAGES
addappid(512771, 1, "64cb7bbc2d2799bb83e445f9cb7e6e0615f1f3130446ba1b029099e1ea530f2e")
