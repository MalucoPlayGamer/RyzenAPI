-- Lua provided by SkyAPI 
-- Game: SEXSTELLAR
addappid(3472100)
addappid(3472101, 1, "6612b9c58e708157d18c0aa7d3658fbcdda501793a9a17bf4410c00a3caa6402")
