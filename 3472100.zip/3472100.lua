-- Lua provided by RyzenAPI
-- Game: Game: SEXSTELLAR

-- MAIN APPLICATION
addappid(3472100)
-- Game: addappid(3472100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472101, 1, "6612b9c58e708157d18c0aa7d3658fbcdda501793a9a17bf4410c00a3caa6402")
