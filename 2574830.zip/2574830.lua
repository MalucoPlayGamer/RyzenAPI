-- Lua provided by RyzenAPI
-- Game: addappid(2574830)

-- MAIN APPLICATION
addappid(2574830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574831, 1, "ef5741d23e651839f3b85edf21f4fd69de4f2c6b2cc0472581b09cddabde9bda")
