-- Lua provided by RyzenAPI
-- Game: The Oath of The Dark Magic Queen

-- MAIN APPLICATION
addappid(1745620)
-- Game: addappid(1745620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745621, 1, "f1571df9b99e5f4a2c4842f8c65db60dc235b1b50e6dafc2f6163f82d11ff5e5")
