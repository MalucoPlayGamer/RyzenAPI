-- Lua provided by RyzenAPI
-- Game: addappid(724590)

-- MAIN APPLICATION
addappid(724590)

-- MAIN APP DEPOTS / PACKAGES
addappid(724591, 1, "e8da620c481b97515717c997b401e860cc9136294df66702fcc2f7646ff8fbcf")
