-- Lua provided by RyzenAPI 
-- Game: Sharecare YOU VR
addappid(724590)
addappid(724591, 1, "e8da620c481b97515717c997b401e860cc9136294df66702fcc2f7646ff8fbcf")
