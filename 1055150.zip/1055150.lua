-- Lua provided by RyzenAPI
-- Game: Eva Reynes

-- MAIN APPLICATION
addappid(1055150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055151, 1, "b5cbbbf5f581d668f3038b8a966db79c1c9db8bfd6c625653573807be11e970a")

