-- Lua provided by RyzenAPI
-- Game: 1813690

-- MAIN APPLICATION
addappid(1813690)
-- Game: addappid(1813690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813691, 1, "5b2c838a1cd2e17b9491a8c92690350c8c29ecc627f1c163d9b325a1d8140c2d")
