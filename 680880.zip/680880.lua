-- Lua provided by RyzenAPI
-- Game: Flood: The Prequel

-- MAIN APPLICATION
addappid(680880)

-- MAIN APP DEPOTS / PACKAGES
addappid(680881,0,"9ae60f93891d398320f53a4e738acdad8969a705af923c2e7456454bc94f7009")
addappid(680882,0,"0995f80bce246b0a22a9bbd7a311753fa690afc25e13be0ca19a9ce85187f0e1")

