-- Lua provided by RyzenAPI
-- Game: addappid(579040)

-- MAIN APPLICATION
addappid(579040)

-- MAIN APP DEPOTS / PACKAGES
addappid(579041, 1, "6ac61836679923588aca6ca4fa6bc3fe6b1f42eb3d733f0674fae5df11bf7fe4")
