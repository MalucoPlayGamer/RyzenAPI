-- Lua provided by RyzenAPI
-- Game: Tales of Terra Ocean Open World ARPG

-- MAIN APPLICATION
addappid(1964770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964771, 1, "5ee009bfd9e68726a66a53cec1c79bb675e4796c6133baebce91b17cfe4aff39")
