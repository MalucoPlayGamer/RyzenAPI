-- Lua provided by RyzenAPI
-- Game: addappid(2077030)

-- MAIN APPLICATION
addappid(2077030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077031, 1, "94c5e38a3d1ad17785fa2577b68ee8b01dc0cb5473d299c9165ed1c96675fcc5")
