-- Lua provided by RyzenAPI
-- Game: TroubleDays

-- MAIN APPLICATION
addappid(1171270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1171271, 1, "a544b2fa24bdf04d9cef50a68771cb60215973dcdb3b84c7b5c0cd5a5bc10aa4")

