-- Lua provided by RyzenAPI
-- Game: AppID 1171270

-- MAIN APPLICATION
addappid(1171270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171271, 1, "a544b2fa24bdf04d9cef50a68771cb60215973dcdb3b84c7b5c0cd5a5bc10aa4")
