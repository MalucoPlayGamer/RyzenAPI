-- Lua provided by RyzenAPI
-- Game: Dark Dimensions: Homecoming Collector's Edition

-- MAIN APPLICATION
addappid(956380)
-- Game: addappid(956380)

-- MAIN APP DEPOTS / PACKAGES
addappid(956381, 1, "949daf98a2f662d57786b7d7da80e240a0d2ef5bb286f5bdfc06fadf6a415449")
