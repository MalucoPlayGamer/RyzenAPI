-- Lua provided by RyzenAPI
-- Game: Game: Forests, Fields and Fortresses

-- MAIN APPLICATION
addappid(2113450)
-- Game: addappid(2113450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113451, 1, "87c3e36f6480ca901ba1329f80376056409ae658fe5d01b5c8dee99839bd56db")
