-- Lua provided by RyzenAPI
-- Game: This Starry Midnight We Make

-- MAIN APPLICATION
addappid(320090)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(320091, 1, "336db929c5d903e695de5d65a51b275ad67cd12964b4a57def88f06450b6ac41")

