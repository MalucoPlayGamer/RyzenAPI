-- Lua provided by RyzenAPI
-- Game: Game: This Starry Midnight We Make

-- MAIN APPLICATION
addappid(320090)
-- Game: addappid(320090)

-- MAIN APP DEPOTS / PACKAGES
addappid(320091, 1, "336db929c5d903e695de5d65a51b275ad67cd12964b4a57def88f06450b6ac41")
