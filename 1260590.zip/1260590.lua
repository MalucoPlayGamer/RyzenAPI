-- Lua provided by RyzenAPI 
-- Game: Hadean Tactics
addappid(1260590)
addappid(1260591, 1, "713a3afb76db28c62316451087cf527f8b3ff7d3f17a8ca92f9a5369f8858591")
addappid(1260592, 1, "d913b50de6552fec5c65fd18011582ee6c4df531b1b52150bdaa02a9fe5cb885")
addappid(1260593, 1, "1cd6ebd8af5e1c51d5a0f8b42a7bb56a3dcf8f91ac1920638dd17c14ab535025")
addappid(4323120)
