-- Lua provided by RyzenAPI
-- Game: Game: AppID 526730

-- MAIN APPLICATION
addappid(526730)
-- Game: addappid(526730)

-- MAIN APP DEPOTS / PACKAGES
addappid(526731, 1, "4961a71218a8687a9e244992074e7c53c9e850524637eddc311fcb11b851a824")
