-- Lua provided by RyzenAPI
-- Game: addappid(2287650)

-- MAIN APPLICATION
addappid(2287650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287651, 1, "15d56fd9f608905e11bd23dad138d05d006ce25bd31acfc1f8f5d3c2b9beeb70")
