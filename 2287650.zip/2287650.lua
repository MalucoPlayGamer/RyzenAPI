-- Lua provided by SkyAPI 
-- Game: HITLER: BDSM BUNKER
addappid(2287650)
addappid(2287651, 1, "15d56fd9f608905e11bd23dad138d05d006ce25bd31acfc1f8f5d3c2b9beeb70")
