-- Lua provided by RyzenAPI
-- Game: 2672090

-- MAIN APPLICATION
addappid(2672090)
addappid(2672100)
-- Game: addappid(2672090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672091, 1, "f00adaa65d1a82eb28b9a4f2e769599cad3d817bfd13f42112a2998e5d73b890")
addappid(2672092, 1, "6c9baa1090a9271d0c116c26a7e35aedbf95e712c5190078339b6a85e2eaedb2")
