-- Lua provided by RyzenAPI
-- Game: 1352850

-- MAIN APPLICATION
addappid(1352850)
-- Game: addappid(1352850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352851, 1, "a9f4aacc2b9293fce5e3c1c38e975aee543b830783c7e09ca6e4c3a7e24c6cf1")
