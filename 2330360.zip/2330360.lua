-- Lua provided by RyzenAPI
-- Game: Game: Pixel Art Academy: Learn Mode

-- MAIN APPLICATION
addappid(2330360)
-- Game: addappid(2330360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330361, 1, "189631d951af14a00cb17eb458e7b3b5f6e6c07ac0db8cd81ffb050d83d43f39")
