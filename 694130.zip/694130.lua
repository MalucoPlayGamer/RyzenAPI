-- Lua provided by RyzenAPI
-- Game: 694130

-- MAIN APPLICATION
addappid(694130)
-- Game: addappid(694130)

-- MAIN APP DEPOTS / PACKAGES
addappid(694131, 1, "14e3d276ecf059139070126a14071503a8addc8e7a7f0238cca2e2080bf48a73")
