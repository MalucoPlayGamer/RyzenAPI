-- Lua provided by RyzenAPI
-- Game: Game: AppID 811860

-- MAIN APPLICATION
addappid(811860)
-- Game: addappid(811860)

-- MAIN APP DEPOTS / PACKAGES
addappid(811861, 1, "a78fc91d7d5da40e8cefa53c785544812cdb045798302dad455959a8a03e35d1")
