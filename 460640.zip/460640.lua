-- Lua provided by RyzenAPI
-- Game: Breached

-- MAIN APPLICATION
addappid(460640)

-- MAIN APP DEPOTS / PACKAGES
addappid(460641, 1, "57d1c686d9785deccb4b52a7ef0076c96950b2ae2ddd95a5c703d5e47cd1b792")
addappid(493130, 0, "e47d924ef2de4d23ad5bd3aa8238dc704d37df088a92540b74d90081b33405b6")
addappid(493160, 0, "91b5011d191bdc0b7101139e03ae67e5046abac04de3da2210c82e3afc06edb7")
