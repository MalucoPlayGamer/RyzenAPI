-- Lua provided by RyzenAPI
-- Game: 974520

-- MAIN APPLICATION
addappid(974520)
-- Game: addappid(974520)

-- MAIN APP DEPOTS / PACKAGES
addappid(974521, 1, "d2741224aa49de55d0cca856ec504c519d34d45454d7cc9225bfad6cad799e13")
