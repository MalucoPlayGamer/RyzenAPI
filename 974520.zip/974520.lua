-- Lua provided by SkyAPI 
-- Game: Ultimo Reino
addappid(974520)
addappid(974521, 1, "d2741224aa49de55d0cca856ec504c519d34d45454d7cc9225bfad6cad799e13")
