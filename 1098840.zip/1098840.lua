-- Lua provided by RyzenAPI
-- Game: 1098840

-- MAIN APPLICATION
addappid(1098840)
-- Game: addappid(1098840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098841, 1, "12214f0979c7e04813af92293b722d9f5efe2a422b4e3aa36f969d0f36774fc6")
