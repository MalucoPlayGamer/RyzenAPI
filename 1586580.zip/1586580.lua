-- Lua provided by RyzenAPI
-- Game: Game: Narita Boy Soundtrack

-- MAIN APPLICATION
addappid(1586580)
-- Game: addappid(1586580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586581, 1, "8d26c7ef80bf73117785d444c1fd702a62bafabb63cf90d03e0274c11bc8ab09")
addappid(1586582, 1, "ee3624b0f7285f63771059c12a533766a4396f0a2185098f2936643be0e10f94")
