-- Lua provided by SkyAPI 
-- Game: Narita Boy Soundtrack
addappid(1586580)
addappid(1586581, 1, "8d26c7ef80bf73117785d444c1fd702a62bafabb63cf90d03e0274c11bc8ab09")
addappid(1586582, 1, "ee3624b0f7285f63771059c12a533766a4396f0a2185098f2936643be0e10f94")
