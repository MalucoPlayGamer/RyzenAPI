-- Lua provided by RyzenAPI
-- Game: 438460

-- MAIN APPLICATION
addappid(438460)
-- Game: addappid(438460)

-- MAIN APP DEPOTS / PACKAGES
addappid(438461, 1, "0413777f64abaffdccbdf2f7379cf75973b5b5343ad6b6b8e199b63d12ba969c")
