-- Lua provided by RyzenAPI
-- Game: A hundred kinds of your smile

-- MAIN APPLICATION
addappid(2179060)
-- Game: addappid(2179060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179067,0,"7ce78bf0184a255c83a3beb5c51d56bfef37ce547040fb82e6517cdf6b1026a5")
