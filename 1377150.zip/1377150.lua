-- Lua provided by RyzenAPI
-- Game: Operation: Tango - Friend Pass

-- MAIN APPLICATION
addappid(1377150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377151, 1, "bb898cdc9d90b324534c75daeda6d2ffea591d1a015f0d2c4d09819b511703c5")

