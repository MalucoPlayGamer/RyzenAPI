-- Lua provided by RyzenAPI
-- Game: Game: candle flame in the wind

-- MAIN APPLICATION
addappid(1293040)
addappid(1307420)
-- Game: addappid(1293040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293041, 1, "f6ee40a0c8ecdb5e7114972a77cb53b73f23da1cfc5fa3436ba031c35d4bdb9a")
