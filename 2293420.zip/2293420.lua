-- Lua provided by RyzenAPI
-- Game: Game: СИМУЛЯТОР ЛАЗАНЬЯ ПО ЗАБРОШКАМ

-- MAIN APPLICATION
addappid(2293420)
-- Game: addappid(2293420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293421, 1, "7e4e87e92af3478b5ca325265c6ce103a088e66fd90953bab1bb3267870bd2da")
