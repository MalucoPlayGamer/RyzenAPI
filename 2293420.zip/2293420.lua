-- Lua provided by RyzenAPI
-- Game: СИМУЛЯТОР ЛАЗАНЬЯ ПО ЗАБРОШКАМ

-- MAIN APPLICATION
addappid(2293420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2293421, 1, "7e4e87e92af3478b5ca325265c6ce103a088e66fd90953bab1bb3267870bd2da")

