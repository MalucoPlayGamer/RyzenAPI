-- Lua provided by RyzenAPI
-- Game: Garden Simulator - Original Soundtrack

-- MAIN APPLICATION
addappid(2130600)
-- Game: addappid(2130600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130601, 1, "274f2d1ba220999c20531cb65e2e71b0f6c2ae46153aebc4abf818fe2b602702")
