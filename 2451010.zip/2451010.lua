-- 2451010's Lua and Manifest Created by Hubcap Manifest
-- Project Hunt
-- Created: August 14, 2026 at 20:46:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2451010) -- Project Hunt
-- MAIN APP DEPOTS
addappid(2451011, 1, "0537abcde8e1efe481cd600dfddf10c71eb1288c81409e9827a12d0f61b3de53") -- Depot 2451011
setManifestid(2451011, "8938401952733633555", 34499957347)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4018820) -- PROJECT HUNT - LONE STAR HUNTING RANCH
addappid(4142960) -- PROJECT HUNT - HTR .338 Big Game Access Pack
addappid(4241260) -- PROJECT HUNT - Trophy Sanctuary
addappid(4522390) -- PROJECT HUNT - Trophy Museum
addappid(4762230) -- PROJECT HUNT - MANCHURIAN TAIGA