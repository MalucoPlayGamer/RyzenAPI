-- Lua provided by SkyAPI 
-- Game: Project Hunt
addappid(2451010)
addappid(2451011, 1, "0537abcde8e1efe481cd600dfddf10c71eb1288c81409e9827a12d0f61b3de53")
