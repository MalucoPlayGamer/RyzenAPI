-- Lua provided by RyzenAPI
-- Game: Project Hunt

-- MAIN APPLICATION
addappid(2451010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451011, 1, "0537abcde8e1efe481cd600dfddf10c71eb1288c81409e9827a12d0f61b3de53")

