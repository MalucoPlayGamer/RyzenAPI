-- Lua provided by RyzenAPI
-- Game: AppID 1539860

-- MAIN APPLICATION
addappid(1539860)
-- Game: addappid(1539860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539861, 1, "2ad591da0335bdc33f8701ed5b7f073ae47fcb91d4edd0ba5f3f45b2a6d4f785")
