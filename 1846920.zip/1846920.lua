-- Lua provided by SkyAPI 
-- Game: Lust Academy - Season 1
addappid(1846920)
addappid(1846921, 1, "968da0d81dd4d407ea6d039b91343d094120a5985547875e05dcb987a815c588")
addappid(1846922, 1, "f0123615f7078b5892e2ba3615665c6eadd1b15e23c34c75c7394e7b454405e0")
