-- Lua provided by RyzenAPI
-- Game: Atonement

-- MAIN APPLICATION
addappid(3377680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3377681, 1, "f624665fd47fdeb6c06977ec7feda4004b311a2b342be403d476d6d2f4e13498")
