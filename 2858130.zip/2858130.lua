-- Lua provided by SkyAPI 
-- Game: Soul Shifters: MMORPG
addappid(2858130)
addappid(2858131, 1, "201b49c18b27b1e93b198a5c32dff6ddc9204a902a088d4c33300d09fd91269d")
addappid(2858132, 1, "ac44647de9acf086493e1e428ed8ecbec0dc56723f031fdb6dec214204920db2")
