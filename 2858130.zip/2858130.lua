-- Lua provided by RyzenAPI
-- Game: 2858130

-- MAIN APPLICATION
addappid(2858130)
-- Game: addappid(2858130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858131, 1, "201b49c18b27b1e93b198a5c32dff6ddc9204a902a088d4c33300d09fd91269d")
addappid(2858132, 1, "ac44647de9acf086493e1e428ed8ecbec0dc56723f031fdb6dec214204920db2")
