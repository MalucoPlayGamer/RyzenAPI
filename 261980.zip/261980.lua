-- Lua provided by RyzenAPI
-- Game: Game: Half-Life: Before

-- MAIN APPLICATION
addappid(261980)
-- Game: addappid(261980)

-- MAIN APP DEPOTS / PACKAGES
addappid(261981, 1, "43d789f197c40f8549987898369e067ea7e2268e3de48b84c425fa5d2a41bb92")
