-- Lua provided by RyzenAPI
-- Game: addappid(3589940)

-- MAIN APPLICATION
addappid(3589940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3589941, 1, "35bd3a8958a22c04adbce233bf62e184755f4895c436d4bb306a999f06548a30")
