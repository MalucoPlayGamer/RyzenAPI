-- Lua provided by RyzenAPI
-- Game: 1610150

-- MAIN APPLICATION
addappid(1610150)
-- Game: addappid(1610150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610151, 1, "430d4fc3cdb5d3f2a76b077ce1214fbfbec7185baf0a815b568a7173ec3ea72a")
