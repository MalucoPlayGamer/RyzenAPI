-- Lua provided by RyzenAPI
-- Game: 533340

-- MAIN APPLICATION
addappid(533340)
-- Game: addappid(533340)

-- MAIN APP DEPOTS / PACKAGES
addappid(533341, 1, "6499bfa59d09b93ad6819eb8e1da80e658b8c8fced23c0467f3157425ef26e9d")
