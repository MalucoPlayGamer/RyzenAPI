-- Lua provided by RyzenAPI
-- Game: Captivity

-- MAIN APPLICATION
addappid(533340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(533341, 1, "6499bfa59d09b93ad6819eb8e1da80e658b8c8fced23c0467f3157425ef26e9d")

