-- Lua provided by RyzenAPI
-- Game: 1676620

-- MAIN APPLICATION
addappid(1676620)
-- Game: addappid(1676620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676621, 1, "38a3a5e925352977aa630f5d6b6bfbb14333d0f51b88f5cf3c9e2826efd0910b")
