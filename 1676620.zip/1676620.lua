-- Lua provided by RyzenAPI
-- Game: Kellogg's Gut Bacteria Reef

-- MAIN APPLICATION
addappid(1676620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676621, 1, "38a3a5e925352977aa630f5d6b6bfbb14333d0f51b88f5cf3c9e2826efd0910b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
