-- Lua provided by RyzenAPI
-- Game: Magical Valkyrie Lyristia

-- MAIN APPLICATION
addappid(1666510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666511, 1, "aea822186f18b67f909bc68d4bdde4afb3979733c71a85c0a030bb3a48ad9d9b")
addappid(1666512, 1, "12858de25781d51a7caf57207fe1a79a35a8ae3b8d5573e48e2f040baa106189")
addappid(1666513, 1, "060601d1af565790d94758aade93cf2c190d013c01c33668d5a7f31afafe63de")

