-- Lua provided by RyzenAPI
-- Game: Invisigun Reloaded

-- MAIN APPLICATION
addappid(375750)
addappid(632190)

-- MAIN APP DEPOTS / PACKAGES
addappid(375751, 1, "849739b1fb6eff0f5daac08d6e0060055100ca93a32cdcd91649ed8873ecdc8d")
addappid(375752, 1, "b230552233a6e1f1aa4a826ac1f5c4174bf3a3430768e33a70a5ca54b2d377cf")
addappid(375753, 1, "c3adc886746e857eaa203ecb1dff7c0ad26a362eb8c6a9ef9df62a616af2ef87")

