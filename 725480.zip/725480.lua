-- Lua provided by RyzenAPI
-- Game: Game: Slap City

-- MAIN APPLICATION
addappid(725480)
-- Game: addappid(725480)

-- MAIN APP DEPOTS / PACKAGES
addappid(725481, 1, "fc23754d322a25297af4f3dbc64388cc69b1a097c27e40fee631265f82479fd0")
