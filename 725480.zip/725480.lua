-- Lua provided by RyzenAPI
-- Game: Slap City

-- MAIN APPLICATION
addappid(725480)

-- MAIN APP DEPOTS / PACKAGES
addappid(725481, 1, "fc23754d322a25297af4f3dbc64388cc69b1a097c27e40fee631265f82479fd0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
