-- Lua provided by RyzenAPI
-- Game: Game: Edgar Poe: Hidden Objects

-- MAIN APPLICATION
addappid(2050740)
-- Game: addappid(2050740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050741, 1, "f0fc5ee6413349f2404c259d9cdc63c14c2de303566f37f275dfcfe39115623d")
