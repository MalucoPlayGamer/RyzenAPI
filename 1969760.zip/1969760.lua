-- Lua provided by SkyAPI 
-- Game: Nubla Soundtrack
addappid(1969760)
addappid(1969761, 1, "445ff5dcee1bda277e4d22b80707ec2cbb7de845c5f641649f713739c73c9be6")
