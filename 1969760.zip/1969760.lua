-- Lua provided by RyzenAPI
-- Game: 1969760

-- MAIN APPLICATION
addappid(1969760)
-- Game: addappid(1969760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969761, 1, "445ff5dcee1bda277e4d22b80707ec2cbb7de845c5f641649f713739c73c9be6")
