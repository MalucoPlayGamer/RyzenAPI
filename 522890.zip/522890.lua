-- Lua provided by RyzenAPI
-- Game: Ant-gravity: Tiny's Adventure

-- MAIN APPLICATION
addappid(522890)

-- MAIN APP DEPOTS / PACKAGES
addappid(522891, 1, "f72d84201326cd244925fcebba69eb107f8b092a1283e44e6ab46942c5f5c8bb")
addappid(522892, 1, "9e8d487be92f59226c3145223b35e5cbeb7c1294c3dc4f21e4c120aff360bb1b")
addappid(522893, 1, "fa9eed190979de947a1ff2268e6b6deb3d75ec91eb9155233575635256d17cfc")
addappid(522894, 1, "7cb4ddd97e6080e43cbf9ff6cfd5f08131395f0f75a6becc9b78dd387d57a100")
addappid(522895, 1, "bbcc64e420849e2a6ed44dfe6f62b366f5266c8de5394ba88115991733be7d37")

