-- Lua provided by RyzenAPI
-- Game: Jumping Jack

-- MAIN APPLICATION
addappid(3205090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3205091, 1, "62aee060f159d1b8c772807d59346cb887b44d52b4a0cfabc73f85e5d0f41144")

