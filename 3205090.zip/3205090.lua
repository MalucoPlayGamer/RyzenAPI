-- Lua provided by RyzenAPI
-- Game: Jumping Jack

-- MAIN APPLICATION
addappid(3205090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205091, 1, "62aee060f159d1b8c772807d59346cb887b44d52b4a0cfabc73f85e5d0f41144")

