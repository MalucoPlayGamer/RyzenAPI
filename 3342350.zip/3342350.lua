-- Lua provided by RyzenAPI
-- Game: Scary Granny

-- MAIN APPLICATION
addappid(3342350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342351, 1, "e85c6398875deacf80f1821b7bbff2a1fd92de1114f71c1cec2922a1bde856aa")

