-- Lua provided by RyzenAPI 
-- Game: Uncle Chop's Rocket Shop
addappid(1849790)
addappid(1849791, 1, "6d0f8659146fe7a0724eb29aebd14d99775683d6183f564f36fe4cbdf4098500")
addappid(3335150, 0, "aab400e888d674173ee067744ecd7d2b42f86d0b3284465f0ad0d6a53a3caec8")
