-- Lua provided by RyzenAPI
-- Game: Uncle Chop's Rocket Shop

-- MAIN APPLICATION
addappid(1849790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849791, 1, "6d0f8659146fe7a0724eb29aebd14d99775683d6183f564f36fe4cbdf4098500")
addappid(3335150, 0, "aab400e888d674173ee067744ecd7d2b42f86d0b3284465f0ad0d6a53a3caec8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
