-- Lua provided by RyzenAPI
-- Game: Childhood Fears

-- MAIN APPLICATION
addappid(1563550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563551, 1, "6dbad2949c111bc2cb5331e54e3150f4e8499bb8f2e461e2405dc271b203f6ef")
