-- Lua provided by RyzenAPI
-- Game: 2267870

-- MAIN APPLICATION
addappid(2267870)
addappid(2861530)
-- Game: addappid(2267870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267871, 1, "39c539183345083ef7b290f06a7578de9c8c4578f530c6159c7f351fcfb204c1")
