-- Lua provided by RyzenAPI
-- Game: Stewart The Fox

-- MAIN APPLICATION
addappid(2267870)
addappid(2861530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267871, 1, "39c539183345083ef7b290f06a7578de9c8c4578f530c6159c7f351fcfb204c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
