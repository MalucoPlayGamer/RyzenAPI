-- Lua provided by RyzenAPI
-- Game: Stewart The Fox

-- MAIN APPLICATION
addappid(2267870)
addappid(2861530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267871, 1, "39c539183345083ef7b290f06a7578de9c8c4578f530c6159c7f351fcfb204c1")

