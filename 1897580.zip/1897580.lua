-- Lua provided by RyzenAPI 
-- Game: SEARCH ALL - RUNES
addappid(1897580)
addappid(1897581, 1, "119121ff9b4128cba3638181ed462fc8bbefe6bb4650bbd9285ecf3ac7ca44a7")
