-- Lua provided by RyzenAPI
-- Game: addappid(1897580)

-- MAIN APPLICATION
addappid(1897580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897581, 1, "119121ff9b4128cba3638181ed462fc8bbefe6bb4650bbd9285ecf3ac7ca44a7")
