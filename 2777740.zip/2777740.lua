-- Lua provided by RyzenAPI
-- Game: addappid(2777740)

-- MAIN APPLICATION
addappid(2777740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777741, 1, "67775202f1ab122035d31aa8a0442dcb0d0a7b50858fb95d0107387f5abdeb4d")
