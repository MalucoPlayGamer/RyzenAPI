-- Lua provided by SkyAPI 
-- Game: Line of Fire - Pirate Waltz
addappid(2769110)
addappid(2769111, 1, "ad5ba1fba98f585a675cc8d7c2b944c34d3469fbc9d89aed495e7e6097ac91a2")
