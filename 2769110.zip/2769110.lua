-- Lua provided by RyzenAPI
-- Game: Line of Fire - Pirate Waltz

-- MAIN APPLICATION
addappid(2769110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2769111, 1, "ad5ba1fba98f585a675cc8d7c2b944c34d3469fbc9d89aed495e7e6097ac91a2")

