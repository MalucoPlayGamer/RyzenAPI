-- Lua provided by RyzenAPI
-- Game: 2769110

-- MAIN APPLICATION
addappid(2769110)
-- Game: addappid(2769110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769111, 1, "ad5ba1fba98f585a675cc8d7c2b944c34d3469fbc9d89aed495e7e6097ac91a2")
