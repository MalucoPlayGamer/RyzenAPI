-- Lua provided by RyzenAPI
-- Game: Plankton

-- MAIN APPLICATION
addappid(542550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(542551, 1, "84bd73456caed7d0aa064b21d3ba3ed21eea804442143d59ac495796189b04f6")
addappid(542552, 1, "72da5ac4c026d7348bbb7861d4fcd183eb60405c108a5fe51e054337f89831f5")
addappid(542553, 1, "4feb63b7ddf24c1b7234dbaecc7d0e4d303ea1ec1d39bde5d3bb4ec0e4aaba3c")
addappid(542554, 1, "02f2d0cd3eeee282f72da97b55a9d797f931682d5f70acaa76dccd2028bbcb07")

