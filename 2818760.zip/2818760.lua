-- Lua provided by RyzenAPI
-- Game: Game: AppID 2818760

-- MAIN APPLICATION
addappid(2818760)
-- Game: addappid(2818760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818761, 1, "78641303f625f1fc391e6ec6b6d6df72e6bf384321ac2b9195e080434bfbd3e0")
