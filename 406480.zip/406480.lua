-- Lua provided by RyzenAPI
-- Game: 406480

-- MAIN APPLICATION
addappid(406480)
-- Game: addappid(406480)

-- MAIN APP DEPOTS / PACKAGES
addappid(406481, 1, "1f35746f2730386cd4f6ccd9e02e6ace585be2ef723f1b475d220b3420f1a428")
