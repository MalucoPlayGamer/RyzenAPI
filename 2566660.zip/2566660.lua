-- Lua provided by RyzenAPI
-- Game: Don Duality Soundtrack

-- MAIN APPLICATION
addappid(2566660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566661, 1, "e367fa040b90bc238b0d90308ce59b5991db8e78e3570e788a7801252f1a8295")
