-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Tied Love 结绳束爱

-- MAIN APPLICATION
addappid(2743570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743570,0,"54f91f056a79f170a8ae13547ade4a3bb99cfbfcaf48e87a86d6629544073cc4")

