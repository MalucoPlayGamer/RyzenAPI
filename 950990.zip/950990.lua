-- Lua provided by RyzenAPI
-- Game: Game: Business Magnate

-- MAIN APPLICATION
addappid(950990)
-- Game: addappid(950990)

-- MAIN APP DEPOTS / PACKAGES
addappid(950991, 1, "47c2949123ea4c6a0a89248654a7cbb255cc9a52f5ba33c3f008cbf65e335b60")
