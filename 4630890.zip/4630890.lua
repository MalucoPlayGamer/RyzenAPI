-- Lua provided by RyzenAPI
-- Game: IIGG: Incremental Idle Goblin Game

-- MAIN APPLICATION
addappid(4630890) -- IIGG: Incremental Idle Goblin Game

-- MAIN APP DEPOTS / PACKAGES
addappid(4630891, 1, "08a4183dcd1aa053c3fd565c9d586ccf9de67ce0cffa0b038c8aab7a02f53d66") -- Depot 4630891
