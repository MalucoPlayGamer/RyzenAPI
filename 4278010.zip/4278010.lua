-- Lua provided by RyzenAPI
-- Game: The Grade 5B Case Files

-- MAIN APPLICATION
addappid(4278010)

