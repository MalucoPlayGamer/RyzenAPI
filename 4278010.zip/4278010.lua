-- Lua provided by RyzenAPI
-- Game: The Grade 5B Case Files

-- MAIN APPLICATION
addappid(4278010)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4851790)
addappid(4851800)
addappid(4937000)
addappid(4937010)
