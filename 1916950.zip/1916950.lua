-- Lua provided by SkyAPI 
-- Game: GoodNight
addappid(1916950)
addappid(1916951, 1, "03cd85bfce785acf3fb27097e6a5063b5c68fac4726e44436f7cf05b1b25b775")
