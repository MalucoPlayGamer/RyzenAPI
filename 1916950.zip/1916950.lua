-- Lua provided by RyzenAPI
-- Game: GoodNight

-- MAIN APPLICATION
addappid(1916950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916951, 1, "03cd85bfce785acf3fb27097e6a5063b5c68fac4726e44436f7cf05b1b25b775")
