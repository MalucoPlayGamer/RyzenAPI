-- Lua provided by RyzenAPI
-- Game: 3340530

-- MAIN APPLICATION
addappid(3340530)
-- Game: addappid(3340530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340531, 1, "3426f6ef36ab13736cdc3796302cfbe70368dbde1b1e67330f7f28a4871b8b87")
