-- Lua provided by RyzenAPI 
-- Game: Holbrook Hotel
addappid(3340530)
addappid(3340531, 1, "3426f6ef36ab13736cdc3796302cfbe70368dbde1b1e67330f7f28a4871b8b87")
