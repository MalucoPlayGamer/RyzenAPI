-- Lua provided by RyzenAPI
-- Game: Living Dolls Rebirth Alpha

-- MAIN APPLICATION
addappid(2483220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483221, 1, "697582b93981b0bed815bdcdacbd1d7089088f6d39a3b11aa4df6fe9c080ded4")

