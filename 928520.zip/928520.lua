-- Lua provided by RyzenAPI
-- Game: Game: Story of Eve - A Hero's Study

-- MAIN APPLICATION
addappid(928520)
-- Game: addappid(928520)

-- MAIN APP DEPOTS / PACKAGES
addappid(928521, 1, "b72390140ae74b7320cda28b268bdd6592333c4accad1db5372e74fbf897384e")
