-- Lua provided by RyzenAPI
-- Game: 383950

-- MAIN APPLICATION
addappid(383950)
-- Game: addappid(383950)

-- MAIN APP DEPOTS / PACKAGES
addappid(383951, 1, "3205c3f8b5c43c8f2125c895fc6899117db158224a94d2f2a9d2b518b21157db")
