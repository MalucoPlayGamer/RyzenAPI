-- Lua provided by RyzenAPI
-- Game: League of Mermaids

-- MAIN APPLICATION
addappid(383950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(383951, 1, "3205c3f8b5c43c8f2125c895fc6899117db158224a94d2f2a9d2b518b21157db")
