-- Lua provided by RyzenAPI
-- Game: AppID 1073870

-- MAIN APPLICATION
addappid(1073870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073871, 1, "b1067aa37d7b57efb0a814e05f2d692c4c10bf6bccfa837d9485bd1a42db4a72")
