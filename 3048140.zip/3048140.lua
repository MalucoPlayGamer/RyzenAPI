-- Lua provided by RyzenAPI
-- Game: Game: Daemonologie

-- MAIN APPLICATION
addappid(3048140)
-- Game: addappid(3048140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048141, 1, "531205b8845996877e9e9151004b975680666add46655d08675393e72541571b")
