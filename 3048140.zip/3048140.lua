-- Lua provided by RyzenAPI
-- Game: Daemonologie

-- MAIN APPLICATION
addappid(3048140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048141, 1, "531205b8845996877e9e9151004b975680666add46655d08675393e72541571b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
