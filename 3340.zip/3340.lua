-- Lua provided by RyzenAPI
-- Game: AstroPop Deluxe

-- MAIN APPLICATION
addappid(3340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341, 1, "b2f492f45f0cbbcb8b344424e4417361f05cbc4c124f2c0210119509a920f2c6")
