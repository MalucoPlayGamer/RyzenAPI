-- Lua provided by SkyAPI 
-- Game: AstroPop Deluxe
addappid(3340)
addappid(3341, 1, "b2f492f45f0cbbcb8b344424e4417361f05cbc4c124f2c0210119509a920f2c6")
