-- Lua provided by RyzenAPI
-- Game: US Spy: Mission in Russia

-- MAIN APPLICATION
addappid(1219940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219941, 1, "7fe17644c8824744352240a9be7dc440db15eddbeeced233daeb2fbea46a6971")
addappid(1219942, 1, "a9fea684050e3a4f320337d8ba1de7f4164774e28f8ef5b9598f1503a41db347")

