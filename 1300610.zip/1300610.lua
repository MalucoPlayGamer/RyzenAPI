-- Lua provided by RyzenAPI 
-- Game: AppID 1300610
addappid(1300610)
addappid(1300611, 1, "bc6c0c572704976029b360e9a992f95c13a596e65b18626804dafb1742e03bda")
