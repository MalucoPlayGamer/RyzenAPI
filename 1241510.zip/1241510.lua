-- Lua provided by RyzenAPI
-- Game: The Test

-- MAIN APPLICATION
addappid(1241510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1241511, 1, "fb43bf5c6fb4aee4dc51764bb66b431460a9f2cacc3ff6460c4b9ff8d92cf645")

