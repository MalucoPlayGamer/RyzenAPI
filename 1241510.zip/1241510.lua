-- Lua provided by RyzenAPI 
-- Game: The Test
addappid(1241510)
addappid(1241511, 1, "fb43bf5c6fb4aee4dc51764bb66b431460a9f2cacc3ff6460c4b9ff8d92cf645")
