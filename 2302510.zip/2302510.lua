-- Lua provided by RyzenAPI
-- Game: Game: Hentai Military

-- MAIN APPLICATION
addappid(2302510)
-- Game: addappid(2302510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302511, 1, "a639df139f76419a54affeb92101b25dd9b5f79e705d9d3009f37dd915151ea0")
