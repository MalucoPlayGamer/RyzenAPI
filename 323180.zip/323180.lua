-- Lua provided by RyzenAPI
-- Game: Portal 2 Soundtrack

-- MAIN APPLICATION
addappid(323180)

-- MAIN APP DEPOTS / PACKAGES
addappid(323184,0,"e20344b3d3b8542dd688df9c0ea6c68482dabe0d49774a297fc06782acd1d952")
addappid(323185,0,"33658cb0a5a5c9d74b8bb94b2307030da8b8925b41edc06674458a1d094cabba")
