-- Lua provided by RyzenAPI
-- Game: AppID 962730

-- MAIN APPLICATION
addappid(962730)
-- Game: addappid(962730)

-- MAIN APP DEPOTS / PACKAGES
addappid(962731, 1, "d40a19216eb72a40d8ccee687beb14fa0b2f7678d0c65a9e48606889e089c047")
