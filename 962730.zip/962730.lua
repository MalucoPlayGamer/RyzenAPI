-- Lua provided by RyzenAPI
-- Game: Skater XL

-- MAIN APPLICATION
addappid(962730)
addappid(1952000)

-- MAIN APP DEPOTS / PACKAGES
addappid(962731, 1, "d40a19216eb72a40d8ccee687beb14fa0b2f7678d0c65a9e48606889e089c047")

