-- Lua provided by RyzenAPI
-- Game: DunkRatz

-- MAIN APPLICATION
addappid(1090960)
-- Game: addappid(1090960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090961, 1, "edea158afa1fd5dc0f36be89678af2e8a03d46a71b4bdc56b30e16c9de56500f")
