-- Lua provided by RyzenAPI
-- Game: LIBLADE

-- MAIN APPLICATION
addappid(1736300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1736301, 1, "1d02bbc1840cd551d39ac530e98432baa27d9e0ce454bd6c25262b26cb771b27")
