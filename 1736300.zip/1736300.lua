-- Lua provided by SkyAPI 
-- Game: AppID 1736300
addappid(1736300)
addappid(1736301, 1, "1d02bbc1840cd551d39ac530e98432baa27d9e0ce454bd6c25262b26cb771b27")
