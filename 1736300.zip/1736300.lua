-- Lua provided by RyzenAPI
-- Game: 1736300

-- MAIN APPLICATION
addappid(1736300)
-- Game: addappid(1736300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736301, 1, "1d02bbc1840cd551d39ac530e98432baa27d9e0ce454bd6c25262b26cb771b27")
