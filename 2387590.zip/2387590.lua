-- Lua provided by RyzenAPI
-- Game: Fairy Biography4 : Affair

-- MAIN APPLICATION
addappid(2387590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387591, 1, "9c07c0eb9dc8940a9a83213f17e49128c1ac353d9b4ca49090d9555284d26825")
addappid(2404540, 0, "dc9e216474f03d5c483a5a70b1c6f43c505daa3770e1e62bea70e54b1da71428")
