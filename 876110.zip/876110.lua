-- Lua provided by SkyAPI 
-- Game: AppID 876110
addappid(876110)
addappid(876111, 1, "8d1604aff5bdbd503155f16975377a412cf92c57cc417df62e0ee6480b116af0")
