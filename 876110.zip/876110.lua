-- Lua provided by RyzenAPI
-- Game: addappid(876110)

-- MAIN APPLICATION
addappid(876110)

-- MAIN APP DEPOTS / PACKAGES
addappid(876111, 1, "8d1604aff5bdbd503155f16975377a412cf92c57cc417df62e0ee6480b116af0")
