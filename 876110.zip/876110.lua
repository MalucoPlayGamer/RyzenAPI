-- Lua provided by RyzenAPI
-- Game: Envoy of Nezphere

-- MAIN APPLICATION
addappid(876110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(876111, 1, "8d1604aff5bdbd503155f16975377a412cf92c57cc417df62e0ee6480b116af0")
