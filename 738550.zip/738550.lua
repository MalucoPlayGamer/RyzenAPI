-- Lua provided by RyzenAPI
-- Game: Spike Volleyball

-- MAIN APPLICATION
addappid(738550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(738551, 1, "cf023512716060791aa6108df57a7b906184780ecc8532d87cee2bb84f2fa613")

