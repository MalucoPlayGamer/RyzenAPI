-- Lua provided by RyzenAPI
-- Game: Spike Volleyball

-- MAIN APPLICATION
addappid(738550)

-- MAIN APP DEPOTS / PACKAGES
addappid(738551, 1, "cf023512716060791aa6108df57a7b906184780ecc8532d87cee2bb84f2fa613")
