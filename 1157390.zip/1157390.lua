-- Lua provided by RyzenAPI
-- Game: King Arthur: Knight's Tale

-- MAIN APPLICATION
addappid(1157390)
addappid(2221040)
addappid(2221041)
addappid(2222070)
addappid(2985590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157391,0,"440e25a18d8a04ae7387ea9dab463d5431a037752dfc7a462eb711c2c30c142f")
addappid(1157392,0,"e759c77e1eb84437a8d49baf98f20425253345b9fda21f133919828686bbffc3")
addappid(2222070,0,"55dc4955e35b4602844c8878f830b0b7fa6ab07b58961e0f71fdf17f6927d591")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
