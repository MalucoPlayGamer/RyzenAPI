-- Lua provided by RyzenAPI
-- Game: Apollo's Adventure

-- MAIN APPLICATION
addappid(2098370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2098371, 1, "45f89f24c293c3f3ec4ee53ce5c020c0e2786f00ff415242b967be8e1e52e698")

