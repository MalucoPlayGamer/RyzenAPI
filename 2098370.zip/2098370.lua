-- Lua provided by RyzenAPI 
-- Game: Apollo's Adventure
addappid(2098370)
addappid(2098371, 1, "45f89f24c293c3f3ec4ee53ce5c020c0e2786f00ff415242b967be8e1e52e698")
