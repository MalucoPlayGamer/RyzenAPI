-- Lua provided by RyzenAPI
-- Game: Log Drive Runner

-- MAIN APPLICATION
addappid(464040)

-- MAIN APP DEPOTS / PACKAGES
addappid(464041, 1, "e0cb7fe45de5be3ca6be61d80ee95c8ada448b14819103633b319d90a0d5d1d6")

