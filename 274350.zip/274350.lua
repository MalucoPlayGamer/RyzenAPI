-- Lua provided by RyzenAPI
-- Game: Dropsy

-- MAIN APPLICATION
addappid(274350)

-- MAIN APP DEPOTS / PACKAGES
addappid(274351, 1, "9417eb74ed752b62b7ce7ce5ba75bfe56dfa64ee64d8f362d89e82433327bb11")
addappid(274352, 1, "374ea40458999c04841093457afe39c23bf998dbce7ad8eaa5bf03d23139b57f")
addappid(274353, 1, "f360b6d6b65d4efebdf9f5f3310f39b95a79ca0a7b81ec11d9ae6460227c5480")
addappid(274354, 1, "ba9868512d73bd2e33f2842892231a0b4f503b095cdb108394801e7a8cb0143e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(403790)
