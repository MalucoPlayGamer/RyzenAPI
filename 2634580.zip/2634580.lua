-- Lua provided by RyzenAPI
-- Game: 2634580

-- MAIN APPLICATION
addappid(2634580)
-- Game: addappid(2634580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634580,0,"a7a99c69a53da55db6c051b6353fa9f79d88bcc0817c839b32660a913ca03369")
