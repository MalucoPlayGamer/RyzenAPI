-- Lua provided by RyzenAPI
-- Game: Dance Hero: More Jiggle

-- MAIN APPLICATION
addappid(2085240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085241, 1, "bc498b8a87707f4a6e33806cf496da0118bc4fe017eb1dafeb86f81f95185017")

