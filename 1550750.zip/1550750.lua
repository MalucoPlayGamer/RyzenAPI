-- Lua provided by RyzenAPI
-- Game: Light Head Hentai Edition

-- MAIN APPLICATION
addappid(1550750)
-- Game: addappid(1550750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550751, 1, "ddc12bc7a16e68362629c92fd963b4c6296ea533aaec1cef0f540c48fcef9e1f")
