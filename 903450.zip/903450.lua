-- Lua provided by RyzenAPI
-- Game: Turbo Cat Fight

-- MAIN APPLICATION
addappid(903450)

-- MAIN APP DEPOTS / PACKAGES
addappid(903451, 1, "b7d58b5ab1f4a1d5b67084f10c081cdf8b17a814d9637ff37849dc5f6c1fbc19")
