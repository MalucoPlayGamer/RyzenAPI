-- Lua provided by SkyAPI 
-- Game: AppID 903450
addappid(903450)
addappid(903451, 1, "b7d58b5ab1f4a1d5b67084f10c081cdf8b17a814d9637ff37849dc5f6c1fbc19")
