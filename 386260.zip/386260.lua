-- Lua provided by RyzenAPI
-- Game: Game: Microcosmum: survival of cells

-- MAIN APPLICATION
addappid(386260)
-- Game: addappid(386260)

-- MAIN APP DEPOTS / PACKAGES
addappid(386261, 1, "7e9084773df97d8032886645be42efe99841e5bbf992015ec25c8e15b08f432e")
