-- Lua provided by SkyAPI 
-- Game: Space Ark
addappid(19320)
addappid(19321, 1, "283365328b82c6f99fae048281f043b7afdfbed1abfd397ace7436900f495371")
