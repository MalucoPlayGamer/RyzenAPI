-- Lua provided by RyzenAPI
-- Game: Space Ark

-- MAIN APPLICATION
addappid(19320)
-- Game: addappid(19320)

-- MAIN APP DEPOTS / PACKAGES
addappid(19321, 1, "283365328b82c6f99fae048281f043b7afdfbed1abfd397ace7436900f495371")
