-- Lua provided by RyzenAPI
-- Game: 1205480

-- MAIN APPLICATION
addappid(1205480)
-- Game: addappid(1205480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205481, 1, "c5b02015dfa6f70e6dfc85296ef3ed65c41e68c1a0585845bec1fc65bd623652")
