-- Lua provided by RyzenAPI
-- Game: Monster Jam Steel Titans 2

-- MAIN APPLICATION
addappid(1205480)
addappid(1430390)
addappid(1443220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1205481, 1, "c5b02015dfa6f70e6dfc85296ef3ed65c41e68c1a0585845bec1fc65bd623652")

