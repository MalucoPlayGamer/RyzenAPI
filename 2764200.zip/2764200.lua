-- Lua provided by RyzenAPI 
-- Game: Chronicles Of Crystal: Turn-Basde Epoch
addappid(2764200)
addappid(2764201, 1, "a66ec60c15dbca87e859efa088ebb4f5400c43d9f0f5823a5105cfe74b3711bd")
