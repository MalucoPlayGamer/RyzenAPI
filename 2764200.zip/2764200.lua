-- Lua provided by RyzenAPI
-- Game: Chronicles Of Crystal: Turn-Basde Epoch

-- MAIN APPLICATION
addappid(2764200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764201, 1, "a66ec60c15dbca87e859efa088ebb4f5400c43d9f0f5823a5105cfe74b3711bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
