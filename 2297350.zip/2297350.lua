-- Lua provided by RyzenAPI
-- Game: addappid(2297350)

-- MAIN APPLICATION
addappid(2297350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297351, 1, "a0d9562462cd8e2af0ea9521211603d8e48ce98b315f7574d8d9ec7513e7a79f")
