-- Lua provided by RyzenAPI
-- Game: addappid(1002000)

-- MAIN APPLICATION
addappid(1002000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002001, 1, "84d642f76535a955fcdfec4fc75bc271eb4ff24ee7d9368e52db5096669caf13")
