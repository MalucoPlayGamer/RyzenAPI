-- Lua provided by RyzenAPI 
-- Game: Novivors
addappid(3002860)
addappid(3002861, 1, "40923c47c826de77149f6361b092fb9825fd42448a72d0c19832d55548f467ee")
