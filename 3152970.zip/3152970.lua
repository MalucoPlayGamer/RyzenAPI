-- Lua provided by RyzenAPI
-- Game: Monkey Tag Arena

-- MAIN APPLICATION
addappid(3152970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152971, 1, "ba26a8b063de7109ddcdd091612ba49a55df83401e406aed288deb032d7a5cff")
addappid(3152972, 1, "ce213860eb61eb548d59bc65b0754c306d1b9c53cbf726d46df117105859d694")
addappid(3152973, 1, "917525a98a036018a367ecae47ca404a13bbb19ed0d8daee55557dfcebe4322b")
