-- Lua provided by RyzenAPI
-- Game: Tusker's Number Adventure [Malware Detected]

-- MAIN APPLICATION
addappid(1063240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063241, 1, "5cee89ee82d92556da13523bad3f54c780bda6add75133c83bd662a88142df6a")

