-- Lua provided by RyzenAPI
-- Game: Investigator

-- MAIN APPLICATION
addappid(482300)
addappid(491290)
addappid(571850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(482301, 1, "9385b86bc258b6098096b5d1da4173ba8a3f822393aa0d143392799b87ec911c")
addappid(740640, 0, "d9ec4a834f2c6c0f1d35af18b9126033c2b96d618cdf8b1ed7cdd4c996fcf0ee")

