-- Lua provided by RyzenAPI
-- Game: AppID 1442330

-- MAIN APPLICATION
addappid(1442330)
-- Game: addappid(1442330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442331, 1, "94d65d2f7c3bc159107f83bc48ff55ba0547c65f5cee11e4904f99a69e660665")
