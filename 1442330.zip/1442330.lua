-- Lua provided by SkyAPI 
-- Game: AppID 1442330
addappid(1442330)
addappid(1442331, 1, "94d65d2f7c3bc159107f83bc48ff55ba0547c65f5cee11e4904f99a69e660665")
