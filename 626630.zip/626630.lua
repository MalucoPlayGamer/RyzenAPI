-- Lua provided by RyzenAPI
-- Game: Two Worlds II HD - Call of the Tenebrae

-- MAIN APPLICATION
addappid(626630)

-- MAIN APP DEPOTS / PACKAGES
addappid(626631, 1, "b359b00694f8f6ae1f5c9f033ad4d4c5e16e3d7cf6ef8162a0faa50b5674921f")
addappid(626632, 1, "02acdad139e467f1a97fe869ac08d309cd26b5e9ff52f36e4221a55d4a829c7e")
addappid(626633, 1, "72d62c6f6098f5b9267bb75982c668f3fd72e12d37d14f3f9200f74fcbbb78c7")
