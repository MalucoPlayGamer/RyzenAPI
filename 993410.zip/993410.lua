-- Lua provided by RyzenAPI
-- Game: addappid(993410)

-- MAIN APPLICATION
addappid(993410)

-- MAIN APP DEPOTS / PACKAGES
addappid(993410,0,"892ce4cca6df4a7fbe339824a2d9232132b224f69e25f025f3631af9a8f08715")
