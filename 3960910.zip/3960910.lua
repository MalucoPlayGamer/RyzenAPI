-- Lua provided by RyzenAPI
-- Game: Parcel Pals

-- MAIN APPLICATION
addappid(3960910) -- Parcel Pals
-- addappid(3960912) -- Depot 3960912 (empty depot)
-- addappid(3960913) -- Depot 3960913 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3960911, 1, "f437ef57690b6861a9213c8e2716a1d6f46adbb21168d968507954d1df1c15b4") -- Depot 3960911

