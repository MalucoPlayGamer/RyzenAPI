-- 3960910's Lua and Manifest Created by Hubcap Manifest
-- Parcel Pals
-- Created: August 01, 2026 at 00:02:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3960910) -- Parcel Pals
-- MAIN APP DEPOTS
addappid(3960911, 1, "f437ef57690b6861a9213c8e2716a1d6f46adbb21168d968507954d1df1c15b4") -- Depot 3960911
setManifestid(3960911, "3265281140635290350", 943333895)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3960912) -- Depot 3960912 (empty depot)
-- addappid(3960913) -- Depot 3960913 (empty depot)