-- Lua provided by RyzenAPI 
-- Game: AppID 1314470
addappid(1314470)
addappid(1314471, 1, "13bc8660c2b8abed935023897fe2939239af41dc56f5042a60782d4cbc407fd3")
addappid(1314472, 1, "0bcac4a4df652f9607c7944f8c520fe1578c187018240e275abfe637c1b35c54")
