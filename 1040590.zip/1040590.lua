-- Lua provided by RyzenAPI
-- Game: Killer Chambers

-- MAIN APPLICATION
addappid(1040590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040591,0,"b7fabc18543a1d5c1338f006a7feaadbd7aa7558b6361fae599ceedf06c318b1")

