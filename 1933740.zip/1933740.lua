-- Lua provided by RyzenAPI
-- Game: Game: The Caligula Effect 2

-- MAIN APPLICATION
addappid(1933740)
-- Game: addappid(1933740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933741, 1, "06970b0a38e62242c10338aeaa1d357ec8d077397a1dbe164cc912c9beb4513b")
