-- Lua provided by RyzenAPI
-- Game: The Caligula Effect 2

-- MAIN APPLICATION
addappid(1933740)
addappid(1958290)
addappid(1958291)
addappid(1958292)
addappid(1958293)
addappid(1958295)
addappid(1958296)
addappid(1958298)
addappid(1958299)
addappid(1958300)
addappid(1958302)
addappid(1958303)
addappid(1958304)
addappid(1958305)
addappid(1999890)
addappid(1999891)
addappid(1999892)
addappid(1999893)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933741, 1, "06970b0a38e62242c10338aeaa1d357ec8d077397a1dbe164cc912c9beb4513b")

