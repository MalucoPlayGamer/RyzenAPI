-- Lua provided by RyzenAPI
-- Game: 510370

-- MAIN APPLICATION
addappid(510370)
-- Game: addappid(510370)

-- MAIN APP DEPOTS / PACKAGES
addappid(510371, 1, "af91cf0ff7ae8a77a21a5005e99d3c809b32d7e47319284d13c34ba11eca278d")
