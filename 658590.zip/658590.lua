-- Lua provided by RyzenAPI
-- Game: AppID 658590

-- MAIN APPLICATION
addappid(658590)
addappid(965791)
addappid(965792)
addappid(1009130)

-- MAIN APP DEPOTS / PACKAGES
addappid(658591, 1, "098d43288fef3ba471c7600d9fe6a8c7e60e71f3d9d4f9ac8c4444b0a14a9462")
addappid(658592, 1, "bcc56c629d02388edff6ffcb7d15b7d6380e219510661dd1451d1426f6a8b048")

