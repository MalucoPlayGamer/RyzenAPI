-- Lua provided by RyzenAPI
-- Game: Game: Roll of Fate

-- MAIN APPLICATION
addappid(2860330)
-- Game: addappid(2860330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860331, 1, "316661568d540e21433f28b42b1e8ef666ea2475fcada4c231c4e513415baa73")
