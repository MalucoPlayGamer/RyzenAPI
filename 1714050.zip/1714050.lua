-- Lua provided by RyzenAPI 
-- Game: SOKOBOT
addappid(1714050)
addappid(1714051, 1, "a4d67aa306d7ad7538d1534215ed008501b3964f5b250ada173164898fbfb466")
