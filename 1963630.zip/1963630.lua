-- Lua provided by RyzenAPI
-- Game: addappid(1963630)

-- MAIN APPLICATION
addappid(1963630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963631, 1, "59dfae218e3a9e3a66c5c368e5ec850d1e67d1f221ea795bac2c8b154c53660d")
