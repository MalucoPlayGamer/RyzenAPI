-- Lua provided by RyzenAPI
-- Game: Devil Edge

-- MAIN APPLICATION
addappid(1468950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468951, 1, "bcff82ce7fdb3963b28ce6dfce67a48b657ccfb86fde3285f75d7143b2c66dfe")

