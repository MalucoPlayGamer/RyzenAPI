-- Lua provided by RyzenAPI 
-- Game: Pitiri 1977
addappid(305740)
addappid(305741, 1, "307536923ec06f782427136e52dc7f1f6674268ec1ae40b198d2cc535c3291f7")
