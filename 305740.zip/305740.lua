-- Lua provided by RyzenAPI
-- Game: Pitiri 1977

-- MAIN APPLICATION
addappid(305740)
-- Game: addappid(305740)

-- MAIN APP DEPOTS / PACKAGES
addappid(305741, 1, "307536923ec06f782427136e52dc7f1f6674268ec1ae40b198d2cc535c3291f7")
