-- Lua provided by RyzenAPI
-- Game: 977610

-- MAIN APPLICATION
addappid(977610)
-- Game: addappid(977610)

-- MAIN APP DEPOTS / PACKAGES
addappid(977611, 1, "d7ea2d4a26e6b83babdec6daf4fb919b775deafb8768cb8a55125a754bf558cb")
