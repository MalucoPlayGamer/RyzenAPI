-- Lua provided by RyzenAPI
-- Game: My Inner Darkness Is A Hot Anime Girl!

-- MAIN APPLICATION
addappid(1753050)
-- Game: addappid(1753050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753051, 1, "d345175a59cccedf22bc9227ea8817b56b8221100e1a706b803b453090830b2d")
