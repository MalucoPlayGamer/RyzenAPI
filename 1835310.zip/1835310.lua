-- Lua provided by RyzenAPI
-- Game: addappid(1835310)

-- MAIN APPLICATION
addappid(1835310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835311, 1, "da62385e080d9efaeaf878b92c6eee175ce7f4c68fa131af2bded9500558eb98")
