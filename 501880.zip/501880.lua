-- Lua provided by RyzenAPI
-- Game: StoneBack | Prehistory

-- MAIN APPLICATION
addappid(501880)

-- MAIN APP DEPOTS / PACKAGES
addappid(501881, 1, "c79290dccce17b3b8de6d13bd192adf5bba711611550c579416db4e074a94fd2")
