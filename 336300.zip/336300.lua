-- Lua provided by RyzenAPI
-- Game: Hearthlands

-- MAIN APPLICATION
addappid(336300)

-- MAIN APP DEPOTS / PACKAGES
addappid(336301, 1, "8881858abe952c7a0e534f6d41869c123efb106bd1aa8ad978b5e48e6c617073")
addappid(336302, 1, "d1d8bde71fd3853c72c8d880911fe30220335c5875c422592c3bd3018753915e")
addappid(336303, 1, "98f5c962f46b91c3cdd7f7d36f1244cdcad89eb6c9e9041217cbc4a710809bb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
