-- Lua provided by RyzenAPI
-- Game: Rhythm Taichi XR

-- MAIN APPLICATION
addappid(2266270)
addappid(2266280)
-- Game: addappid(2266270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266271, 1, "fe97e1d82f03f064600d6f13c9e7ce1c43c6f015d106950c11803b9f1e8d8b9c")
