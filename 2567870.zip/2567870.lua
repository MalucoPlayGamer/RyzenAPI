-- Lua provided by RyzenAPI
-- Game: Chained Together

-- MAIN APPLICATION
addappid(2567870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567871, 1, "84ff26693d69b1f13f653ad7d1a182142a2a5049bf0ce8dc73735d955d3cb186")
