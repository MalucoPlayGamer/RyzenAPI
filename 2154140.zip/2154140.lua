-- Lua provided by RyzenAPI
-- Game: Heroes of Eroticism - New Beginnings

-- MAIN APPLICATION
addappid(2154140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154141, 1, "97918992461904af5c44c66d63a7580ae9dbd6505c672b2d75d74a156b0d3898")
