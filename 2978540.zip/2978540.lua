-- Lua provided by RyzenAPI
-- Game: Gaming Cafe Simulator

-- MAIN APPLICATION
addappid(2978540)
-- Game: addappid(2978540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978541, 1, "c078db4446370348acbe7cd5a779bcb7f5c37d600381a939948d082744b8e50a")
