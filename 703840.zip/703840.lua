-- Lua provided by RyzenAPI
-- Game: AppID 703840

-- MAIN APPLICATION
addappid(703840)

-- MAIN APP DEPOTS / PACKAGES
addappid(703841, 1, "4ef78b7a85b7fbc827f488438b00996bedfff27aa50ce35219cf88cf324e11f1")
