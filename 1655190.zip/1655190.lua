-- Lua provided by RyzenAPI
-- Game: AIKAGI

-- MAIN APPLICATION
addappid(1655190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1655191, 1, "7bd57e178c9459cde204324258141fa84a5ed4fa076eb262af5be59fbe5f216f")

