-- Lua provided by SkyAPI 
-- Game: AIKAGI
addappid(1655190)
addappid(1655191, 1, "7bd57e178c9459cde204324258141fa84a5ed4fa076eb262af5be59fbe5f216f")
