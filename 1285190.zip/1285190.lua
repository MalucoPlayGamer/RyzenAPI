-- Lua provided by RyzenAPI
-- Game: Borderlands 4

-- MAIN APPLICATION
addappid(1285190)
addappid(3802360)
addappid(3802370)
addappid(3829670)
addappid(3829680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285191, 1, "aabb315ef5573fc2633c461cd2ac9b553e2713ca90a67ad2df09781274cbb20f")
addappid(1285192, 1, "3e212ce90691e4e8f2f1418c35495c50a725bb0d012d9f415b0a8a9119dfb0f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2013850)
addappid(3802420)
addappid(3802450)
addappid(4598000)
addappid(4598010)
addappid(4614350)
addappid(4614360)
