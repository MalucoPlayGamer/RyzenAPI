-- Lua provided by RyzenAPI
-- Game: DNO Rasa's Journey

-- MAIN APPLICATION
addappid(376160)
-- Game: addappid(376160)

-- MAIN APP DEPOTS / PACKAGES
addappid(376161, 1, "6c851b83369571722e87a00a5e4e41a3937dc3c8f2edf14c766d45a426653940")
