-- Lua provided by RyzenAPI
-- Game: AppID 1950070

-- MAIN APPLICATION
addappid(1950070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950071, 1, "75e06b81deba6e52a9fb717738f43fdb6248d8c1d8f7cf54fec3cf2ff5b93e86")

