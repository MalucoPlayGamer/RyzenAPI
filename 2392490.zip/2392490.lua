-- Lua provided by RyzenAPI
-- Game: Hazard Hill Idle

-- MAIN APPLICATION
addappid(2392490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392491, 1, "4d732f660983bc9e17cce82b4c0ad3d7bb7603b5103d4674845d6f97e5a21986")

