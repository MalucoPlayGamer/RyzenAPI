-- Lua provided by RyzenAPI
-- Game: 2975720

-- MAIN APPLICATION
addappid(2975720)
-- Game: addappid(2975720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975721, 1, "1caa4edeec17741f25f67fdb611b984d8f3503e2631ba931dd28691ca7dafe2b")
