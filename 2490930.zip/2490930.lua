-- Lua provided by SkyAPI 
-- Game: 富甲天下W
addappid(2490930)
addappid(2490931, 1, "93d2e2557b783a2e58ba71848961462e77f1692a8687d3a222d5005d3d232090")
addappid(2490932, 1, "72176105d0b258628f6c48cdee0cb55c68e26fc9dedcd8c66cc38d60ac72e163")
addappid(2490933, 1, "cab0c0b6fcc01b4bb2d84bc261ff903532be382eacdb95e8504fe85ccd5d46cd")
