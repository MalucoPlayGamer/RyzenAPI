-- Lua provided by RyzenAPI
-- Game: HOARD

-- MAIN APPLICATION
addappid(63000)
addappid(228987)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(63001, 1, "a5a5d3cb6feb3f6d5ec548deb238b672bf7ccf49dc94bcb5088f44a57b5c7450")
addappid(63002, 1, "054399cf151ab30fb791b73316e0ac2ecb2d2b2ae3ad285ab8799447f1e9bd54")
addappid(63006, 1, "aa76992d3aae68243e0bc0a27cf9082b6ace1204136725458655499e90629652")

