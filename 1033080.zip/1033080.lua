-- Lua provided by RyzenAPI
-- Game: Letters - a written adventure

-- MAIN APPLICATION
addappid(1033080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033081, 1, "817bbe7a34224ef4423a53bc6c541ab29545c4cbc4ae59bd87b213484b760d68")
addappid(1033082, 1, "9e960faa9127bab3e1ce2fe1526f06d5aa6d0e0c1270d37bccd906215e50cef0")
addappid(1827490, 0, "569a2f87b6a5b36779c5a12e903c0ac4b38790af2b855673abaf86b149ac9b3d")
