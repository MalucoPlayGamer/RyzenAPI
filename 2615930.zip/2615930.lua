-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2615930)
-- Game: addappid(2615930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582361,0,"05c99615b6197147cb94aa1b27dedf8041417c951807455e36c3ee45be2c1424")
