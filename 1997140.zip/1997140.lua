-- Lua provided by RyzenAPI
-- Game: addappid(1997140)

-- MAIN APPLICATION
addappid(1997140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997140,0,"6922a2000f6aed35d334af0dc9d4de3ab21abaddf3ee943f059322f0645d6a4c")
