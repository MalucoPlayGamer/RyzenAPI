-- Lua provided by RyzenAPI
-- Game: 1704450

-- MAIN APPLICATION
addappid(1704450)
-- Game: addappid(1704450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704451, 1, "e5b62385e1c1009c6cd916249868ba828ac5747cb1aeb408e2623ffbc4e8dc03")
addappid(2771491, 0, "ad405e9681e81f161b2d384e4ced0ab5c3f6091feebc59ffa54f01be8e8c1067")
addappid(3228670, 0, "eb6d1e09eb965bc56e91e3b948a7cf63b5e243f20eb8600190bde140d50f5c23")
addappid(3230180, 0, "502c29aa4b558ece6f784acddc14ccf3bf508f9374a50c19a97736e1ed24c042")
