-- Lua provided by SkyAPI 
-- Game: Alien Hominid Invasion
addappid(843200)
addappid(843201, 1, "5df80a615fc7b65c54a992a7d57b2f942b128c3d919b4ddf37f8ca2e5070f628")
