-- Lua provided by RyzenAPI 
-- Game: Sex Adventures - Swingers Cabin
addappid(2232810)
addappid(2232811, 1, "8b931fcc38c8bb5ac5efe300f45c960a3443d1c71f7a3d65ba4de07e3ad13fc9")
