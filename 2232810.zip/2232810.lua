-- Lua provided by RyzenAPI
-- Game: Game: Sex Adventures - Swingers Cabin

-- MAIN APPLICATION
addappid(2232810)
-- Game: addappid(2232810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232811, 1, "8b931fcc38c8bb5ac5efe300f45c960a3443d1c71f7a3d65ba4de07e3ad13fc9")
