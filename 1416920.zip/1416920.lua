-- Lua provided by RyzenAPI
-- Game: 1416920

-- MAIN APPLICATION
addappid(1416920)
-- Game: addappid(1416920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416921, 1, "baa863b7295b6249af3fd91f6f55956ca6f8b5185529106ae13f60c51ca21988")
addappid(3193590, 0, "d20a4d95eebfeb18d60aff959a5c584787ab9793bcfa5ba415dcc7b3dffc3acf")
