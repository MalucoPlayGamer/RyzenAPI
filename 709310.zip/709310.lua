-- Lua provided by RyzenAPI
-- Game: Decksplash Free Week

-- MAIN APPLICATION
addappid(709310)

-- MAIN APP DEPOTS / PACKAGES
addappid(709311, 1, "32d56fde8da89bccdc74af1a2aaebcec93d6b9e6e3589fdf0f4a8aee7c0acff4")
