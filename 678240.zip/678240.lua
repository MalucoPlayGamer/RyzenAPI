-- Lua provided by RyzenAPI
-- Game: 678240

-- MAIN APPLICATION
addappid(678240)
-- Game: addappid(678240)

-- MAIN APP DEPOTS / PACKAGES
addappid(678241, 1, "67e3b50dee39d4195dc6229d308ef51b690fab478687779766120a648204ed0b")
