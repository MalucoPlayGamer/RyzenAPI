-- Lua provided by RyzenAPI
-- Game: Midinous

-- MAIN APPLICATION
addappid(1727420)
-- Game: addappid(1727420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727421, 1, "538e324b9c76e1bc0ffe9dc2b3a9f30c271bdcd6e5c80a75ba315170ae480830")
