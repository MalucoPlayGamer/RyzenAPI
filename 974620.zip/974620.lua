-- Lua provided by RyzenAPI
-- Game: AppID 974620

-- MAIN APPLICATION
addappid(974620)

-- MAIN APP DEPOTS / PACKAGES
addappid(974621, 1, "d33174917dfbf8ea2cd7e95bc6a9b8d5b8c9ce5d8159cc62a8bfbd5b289a23d9")

