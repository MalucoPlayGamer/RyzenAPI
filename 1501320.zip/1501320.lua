-- Lua provided by RyzenAPI
-- Game: Prison Girl

-- MAIN APPLICATION
addappid(1501320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501321, 1, "acdba518b60879f7c1a583cd76df2f13aceaba4224f23643a0b627de8d56c626")

