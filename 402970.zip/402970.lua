-- Lua provided by RyzenAPI
-- Game: Game: Fringes of the Empire

-- MAIN APPLICATION
addappid(402970)
-- Game: addappid(402970)

-- MAIN APP DEPOTS / PACKAGES
addappid(402971, 1, "341d01707dc086db82f0b8b7ba17d57fcee4fcdb1aa5e97cfbe8fd3987465b29")
