-- Lua provided by RyzenAPI
-- Game: addappid(1091190)

-- MAIN APPLICATION
addappid(1091190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091191, 1, "50740f487b070fc3804058f0f115c3eb91e07689c1036b1c62a67aa97ee9abba")
