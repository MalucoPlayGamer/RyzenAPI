-- Lua provided by RyzenAPI
-- Game: DEEP FOG 霧城 Demo

-- MAIN APPLICATION
addappid(1869340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869341, 1, "1e3509ac3ad10b4ff2ac812469572da80080f589b4ef0ed58c7dbac9836a9a2b")

