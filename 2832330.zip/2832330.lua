-- Lua provided by RyzenAPI
-- Game: Game: Aeons Echo

-- MAIN APPLICATION
addappid(2832330)
addappid(3307150)
addappid(3307160)
addappid(3307170)
addappid(3397630)
-- Game: addappid(2832330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832331, 1, "d309006077b9d88146dcefbda1d88409da93f37bc3b5745197613c663976f6b1")
