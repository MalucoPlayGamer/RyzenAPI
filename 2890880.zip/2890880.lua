-- Lua provided by RyzenAPI
-- Game: 2890880

-- MAIN APPLICATION
addappid(2890880)
-- Game: addappid(2890880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890881, 1, "41f543bd07d40dc49f3cc436b9522131cb52069104823f80da5d7f42d31ebb5b")
