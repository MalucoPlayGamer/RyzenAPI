-- Lua provided by RyzenAPI
-- Game: Game: Playing History 2 - Slave Trade

-- MAIN APPLICATION
addappid(386870)
-- Game: addappid(386870)

-- MAIN APP DEPOTS / PACKAGES
addappid(386871, 1, "3b351442f34114fbe8ab5670e97d5e0a2e903674a73e03c52f5d8735d75c9740")
addappid(386872, 1, "2e8fda3451a01ee81795250a265411b0169e1d83836c0448eed345a576d3483d")
