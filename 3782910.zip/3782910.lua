-- Lua provided by RyzenAPI
-- Game: Goblin Nest

-- MAIN APPLICATION
addappid(3782910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3782912,0,"75d15fb72e9dae9778af3d9bef60148e919910a369c89c0990ba9889e0a96ca7")

