-- Lua provided by RyzenAPI
-- Game: Merk Mayhem

-- MAIN APPLICATION
addappid(2370990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370991, 1, "ee369aff8ab33fb7160283db1059abb8c2223f41907e73c5cf80c2b901aac382")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
