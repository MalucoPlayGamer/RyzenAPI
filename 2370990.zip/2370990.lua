-- Lua provided by RyzenAPI
-- Game: Merk Mayhem

-- MAIN APPLICATION
addappid(2370990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370991, 1, "ee369aff8ab33fb7160283db1059abb8c2223f41907e73c5cf80c2b901aac382")

