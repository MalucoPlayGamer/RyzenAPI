-- Lua provided by RyzenAPI
-- Game: 3D LOVER - The Nature Body

-- MAIN APPLICATION
addappid(2413540)
-- Game: addappid(2413540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413540,0,"55809828311585b28a7b70d33c4f5709321b52c174cf4e64997d068e023201fc")
