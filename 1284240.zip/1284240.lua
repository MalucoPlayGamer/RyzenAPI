-- Lua provided by RyzenAPI 
-- Game: AppID 1284240
addappid(1284240)
addappid(1284241, 1, "14321934e4da0f71bd5e7b8b7993a16e5058be97387a72af4eac4b94ab565fbc")
addappid(1284242, 1, "7f4216a606bcdac32fde0c0360e670f528ce3b0a1235c570787418bccccd7a33")
addappid(1284243, 1, "7a6893e35a04bc48ac7ebc3668bf6d57f363c9fec09b975c34e2aac2ae962cb3")
