-- Lua provided by RyzenAPI
-- Game: Far Cry® 4

-- MAIN APPLICATION
addappid(298110)
addappid(324340)
addappid(324342)
addappid(332220)
addappid(332221)
addappid(332222)
addappid(332223)
addappid(332224)
addappid(332225)
addappid(332226)
addappid(332227)
addappid(332228)
addappid(332229)
addappid(332230)
addappid(332231)
addappid(332232)
addappid(338620)
addappid(343700)
addappid(345910)
addappid(348080)
addappid(353870)

-- MAIN APP DEPOTS / PACKAGES
addappid(298111, 1, "90765df7a812f66db8794bd7b41b398e9b12fe77ec22caaff1442644d2c2c91d")
addappid(298112, 1, "4f2126199ab0506f24ed8517d6b0e0c2ecf3a5cf4adbb2e5b32efbf21f3bb2e8")
addappid(298113, 1, "e524b5855fe79757f864359e1de9606d4a0ab23ecd59b79f2af270bd97f497c8")
addappid(298114, 1, "2218dbe36d21dd99bf8e46cbf5cb8e9c91897c36983a14363f38dd29d82e94d4")
addappid(324341, 0, "0a4894abdd94b40c7464d6beced29025b9b2c3b1476d44fdff2697e82edb34a9")
addappid(324343, 0, "8bcb7ae406c8a5325315decbe096d6b0afecf265d66514a10a1fe242be970690")
addappid(324344, 0, "47c247776a41ae1192804e89b02b35c7567a9f87b280d3e49bab395db669e1da")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
