-- Lua provided by RyzenAPI
-- Game: 2653240

-- MAIN APPLICATION
addappid(2653240)
-- Game: addappid(2653240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653241, 1, "51a7b5bc5f336d82eb41093cc7fb22382b62f1f3063370286c0c6c03a2ad8b14")
