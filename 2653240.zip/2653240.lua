-- Lua provided by RyzenAPI
-- Game: AppID 2653240

-- MAIN APPLICATION
addappid(2653240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653241, 1, "51a7b5bc5f336d82eb41093cc7fb22382b62f1f3063370286c0c6c03a2ad8b14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
