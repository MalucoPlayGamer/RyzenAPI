-- Lua provided by RyzenAPI
-- Game: 956752

-- MAIN APPLICATION
addappid(956752)
-- Game: addappid(956752)

-- MAIN APP DEPOTS / PACKAGES
addappid(956752,0,"6ead28ae250a8047a06b6311cca3c245f421d22cee0f1c02c8a33847366cfe11")
