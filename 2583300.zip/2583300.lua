-- Lua provided by RyzenAPI
-- Game: Simulator of Ukraine 1991

-- MAIN APPLICATION
addappid(2583300)
addappid(2684540)
addappid(2817830)
addappid(3115050)
addappid(3149110)
addappid(3217190)
addappid(3338930)
addappid(3498970)
addappid(3826280)
addappid(4461970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583301, 1, "e41b7386ee9735c75be0b9d3d55c15001c2d7a1e6bb73a12435d74709d749320")

