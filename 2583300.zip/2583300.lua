-- Lua provided by RyzenAPI
-- Game: Simulator of Ukraine 1991

-- MAIN APPLICATION
addappid(2583300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583301, 1, "e41b7386ee9735c75be0b9d3d55c15001c2d7a1e6bb73a12435d74709d749320")
