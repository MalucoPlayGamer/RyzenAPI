-- Lua provided by SkyAPI 
-- Game: PolyRoyale
addappid(2085330)
addappid(2085331, 1, "2d1e88639a36e0c9c753e0758f3e9428d582ea9c6db9c8c965e4edda99a0f5d6")
