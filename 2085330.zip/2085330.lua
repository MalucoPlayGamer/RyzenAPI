-- Lua provided by RyzenAPI
-- Game: 2085330

-- MAIN APPLICATION
addappid(2085330)
-- Game: addappid(2085330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085331, 1, "2d1e88639a36e0c9c753e0758f3e9428d582ea9c6db9c8c965e4edda99a0f5d6")
