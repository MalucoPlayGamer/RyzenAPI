-- Lua provided by RyzenAPI
-- Game: Game: AppID 1285160

-- MAIN APPLICATION
addappid(1285160)
-- Game: addappid(1285160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285161, 1, "4b9b771476945953a83bb50e198e503058644817f3fd794dc58253ffcd6a0c7b")
