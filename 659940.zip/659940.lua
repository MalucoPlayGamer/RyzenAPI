-- Lua provided by RyzenAPI
-- Game: Travel Riddles: Trip To France

-- MAIN APPLICATION
addappid(659940)

-- MAIN APP DEPOTS / PACKAGES
addappid(659941, 1, "3d522ca4de55c755a15d3fb9263d141cae7d453705c808c77669df0e8499a18c")

