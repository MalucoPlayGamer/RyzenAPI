-- Lua provided by RyzenAPI
-- Game: Game: Black Cat

-- MAIN APPLICATION
addappid(1547490)
-- Game: addappid(1547490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547491, 1, "46eed010f9d4afdb3cf836b2c3328bbab7fc89cc8393b429667638ca76080cad")
