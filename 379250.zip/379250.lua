-- Lua provided by RyzenAPI
-- Game: addappid(379250)

-- MAIN APPLICATION
addappid(379250)

-- MAIN APP DEPOTS / PACKAGES
addappid(379251, 1, "3066cfbe9a840c1ced933d0ea32477d53ebc12c404b8b5bed89862c077ad6181")
