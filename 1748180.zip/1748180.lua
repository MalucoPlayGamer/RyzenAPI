-- Lua provided by RyzenAPI
-- Game: Unsung Empires: The Cholas

-- MAIN APPLICATION
addappid(1748180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748181, 1, "1ca0543ed315d3e514298d8cd39f07dac0afb786e7eb26863fc17c93e2723054")

