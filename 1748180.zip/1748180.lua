-- Lua provided by RyzenAPI
-- Game: Unsung Empires: The Cholas

-- MAIN APPLICATION
addappid(1748180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1748181, 1, "1ca0543ed315d3e514298d8cd39f07dac0afb786e7eb26863fc17c93e2723054")

