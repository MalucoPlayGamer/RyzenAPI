-- Lua provided by RyzenAPI
-- Game: Devil In The Capital

-- MAIN APPLICATION
addappid(659490)

-- MAIN APP DEPOTS / PACKAGES
addappid(659491,0,"18b020e5543cc910f6f82dbc3fdec50e8b81342ddb966ec2f03db308f919501e")

