-- Lua provided by SkyAPI 
-- Game: Super Chaos
addappid(1265010)
addappid(1265011, 1, "505a67ff51b0e4891016902cf774278f67a91e45b55cb4e302da95e790f97ef2")
