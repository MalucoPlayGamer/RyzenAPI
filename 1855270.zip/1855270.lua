-- Lua provided by RyzenAPI 
-- Game: Pachillinko
addappid(1855270)
addappid(1855271, 1, "a2c5756cfe9d44cfee83b9e1a1d8281ab29abc3a90423820dc5ed65514820a95")
