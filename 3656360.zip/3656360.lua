-- Lua provided by RyzenAPI
-- Game: Melody Ball

-- MAIN APPLICATION
addappid(3656360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3656361, 1, "c1999996d511ac30108fd65aaab23cabfb1feb50002dafe8da8cd79d5cec31d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
