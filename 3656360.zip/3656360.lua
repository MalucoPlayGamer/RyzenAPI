-- Lua provided by RyzenAPI 
-- Game: Melody Ball
addappid(3656360)
addappid(3656361, 1, "c1999996d511ac30108fd65aaab23cabfb1feb50002dafe8da8cd79d5cec31d2")
