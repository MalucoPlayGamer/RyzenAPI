-- Lua provided by RyzenAPI
-- Game: 1315590

-- MAIN APPLICATION
addappid(1315590)
-- Game: addappid(1315590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315591, 1, "af4f2627df36a6339a7630ec1869c60be0bbefe01359a1166f13ea139d66118b")
