-- Lua provided by RyzenAPI
-- Game: Game: 迷途

-- MAIN APPLICATION
addappid(1430010)
-- Game: addappid(1430010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430011, 1, "da9c24b7ee3c346099a4af835f5a515bacfd15bf1dbcf7dcb5dea0d27a807850")
