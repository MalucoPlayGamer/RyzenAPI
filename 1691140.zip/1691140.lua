-- Lua provided by RyzenAPI
-- Game: Car Physics Simulator - Sports Car #2

-- MAIN APPLICATION
addappid(1691140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691140,0,"aef04f83f4f900228588ac9ec1cc4f50141961ef89efdf263cd290426826c5de")

