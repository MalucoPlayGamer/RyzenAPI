-- Lua provided by RyzenAPI
-- Game: addappid(2913740)

-- MAIN APPLICATION
addappid(2913740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913741, 1, "dabf7b2aab07836cd7dfd9acf817026c20c56bf151e8a560d064001cf818218b")
