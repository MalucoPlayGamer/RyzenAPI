-- Lua provided by RyzenAPI
-- Game: Hentai Mia

-- MAIN APPLICATION
addappid(3474590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3474591, 1, "5f931c06609bb772f12dc5fb91323f8a1c435bf34034dad2815fd8dcbb5ac003")
