-- Generated with Luie @ https://lua.tools/
-- 2712590 - Dragon Shelter
-- Generated 2026-08-27 22:16:42 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2712590)
addtoken(2712590, "6629517472004915185")

-- Main Depots
addappid(2712591, 1, "18a7e63ad3790704c10b907637904fa971aaf84476a489e498fd402c36cc2c10") -- English (windows, 64-bit)
setManifestid(2712591, "8751820281326939378", 687)
