-- Lua provided by RyzenAPI
-- Game: Dragon Shelter

-- MAIN APPLICATION
addappid(2712590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712591, 1, "18a7e63ad3790704c10b907637904fa971aaf84476a489e498fd402c36cc2c10") -- English (windows, 64-bit)
addtoken(2712590, "6629517472004915185")

