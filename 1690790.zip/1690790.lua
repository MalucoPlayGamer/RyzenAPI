-- Lua provided by RyzenAPI
-- Game: Hate Free Heroes RPG [2D/3D RPG Enhanced] *Leaving Steam

-- MAIN APPLICATION
addappid(1690790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690791, 1, "06c1be4f10371e1072c5aad12c5ce9580feaf56dff48bdfb93551072036c66c6")

