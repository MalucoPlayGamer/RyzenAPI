-- Lua provided by RyzenAPI
-- Game: 🧠 OUT OF THE BOX

-- MAIN APPLICATION
addappid(576960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(576961, 1, "1384357b81af5f9f5bec0dad8e8169dc4cfd8eab93a9c844ed1c2c2428a75275")
addappid(576962, 1, "49071f8d71c865faa79835a7779fdf6114a435afad9b317655ace5ca8aeec1ac")
addappid(576963, 1, "3ca1f7c8bbf165ea45e015fff9877b27f756ac5b5d54fa5c275f6879496b3924")

