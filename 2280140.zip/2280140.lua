-- Lua provided by RyzenAPI
-- Game: AppID 2280140

-- MAIN APPLICATION
addappid(2280140)
-- Game: addappid(2280140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280141, 1, "2523163b4bacc5f7642577a0c0af7e40e689cc6609a0e6bbc7323e348ac9c02c")
