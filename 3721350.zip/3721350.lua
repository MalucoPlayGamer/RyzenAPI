-- Lua provided by RyzenAPI 
-- Game: Farm Chicken
addappid(3721350)
addappid(3721351, 1, "42b947e612a413798eb8a76c72816b10548fe47a7449ddefd849defc8b3e572c")
