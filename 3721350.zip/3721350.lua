-- Lua provided by RyzenAPI
-- Game: Farm Chicken

-- MAIN APPLICATION
addappid(3721350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3721351, 1, "42b947e612a413798eb8a76c72816b10548fe47a7449ddefd849defc8b3e572c")

