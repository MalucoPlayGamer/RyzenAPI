-- Lua provided by RyzenAPI
-- Game: addappid(2087060)

-- MAIN APPLICATION
addappid(2087060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087060,0,"5ca95a891b2b5664523233d3293f1b94ae7e5cb10c2736082877144ecdecbc8e")
