-- Lua provided by RyzenAPI
-- Game: addappid(863520)

-- MAIN APPLICATION
addappid(863520)

-- MAIN APP DEPOTS / PACKAGES
addappid(863521, 1, "80f7f5b36927564fed2173e60c64c1fc651c0cd2b58b14e582ccd20226392c6d")
