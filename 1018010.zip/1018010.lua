-- Lua provided by RyzenAPI
-- Game: AppID 1018010

-- MAIN APPLICATION
addappid(1018010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018011, 1, "f369e7edc8f5b3ceafff6f9366fbf8d1b5f3ce2d064444f966315ff1b0cbdf4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
