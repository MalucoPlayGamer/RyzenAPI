-- Lua provided by RyzenAPI
-- Game: addappid(1018010)

-- MAIN APPLICATION
addappid(1018010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018011, 1, "f369e7edc8f5b3ceafff6f9366fbf8d1b5f3ce2d064444f966315ff1b0cbdf4b")
