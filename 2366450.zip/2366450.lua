-- Lua provided by RyzenAPI
-- Game: Fortune Follow: The Mansion

-- MAIN APPLICATION
addappid(2366450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2366451, 1, "d6a0bb4a8a82dd9db7a2ebdb4abbfa23129b532b95a3c8a33d3a604dcd15e037")
