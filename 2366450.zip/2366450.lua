-- Lua provided by RyzenAPI 
-- Game: AppID 2366450
addappid(2366450)
addappid(2366451, 1, "d6a0bb4a8a82dd9db7a2ebdb4abbfa23129b532b95a3c8a33d3a604dcd15e037")
