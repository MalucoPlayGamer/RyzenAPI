-- Lua provided by RyzenAPI
-- Game: AppID 316390

-- MAIN APPLICATION
addappid(316390)
-- Game: addappid(316390)

-- MAIN APP DEPOTS / PACKAGES
addappid(316391, 1, "1a0383b08db30c30253c637f2a387b517fb804d95de8907c5e777b033f45299d")
