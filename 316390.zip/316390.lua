-- Lua provided by RyzenAPI
-- Game: 316390

-- MAIN APPLICATION
addappid(316390)
addappid(409500)
addappid(514450)
addappid(547400)
addappid(547530)
addappid(572390)
addappid(572420)
addappid(572470)
addappid(572490)
addappid(572930)
addappid(573150)

-- MAIN APP DEPOTS / PACKAGES
addappid(316391,0,"1a0383b08db30c30253c637f2a387b517fb804d95de8907c5e777b033f45299d")

