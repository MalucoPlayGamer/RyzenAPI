-- Lua provided by RyzenAPI
-- Game: Anomaly Zone

-- MAIN APPLICATION
addappid(316390)
addappid(409500)
addappid(514450)
addappid(547400)
addappid(547530)
addappid(572390)
addappid(572420)
addappid(572470)
addappid(572490)
addappid(572930)
addappid(573150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(316391,0,"1a0383b08db30c30253c637f2a387b517fb804d95de8907c5e777b033f45299d")

