-- Lua provided by RyzenAPI 
-- Game: Two Falls (Nishu Takuatshina)
addappid(1671740)
addappid(1671741, 1, "0ae81f6748c2128a7d543fb6f9b45e888288c3a8b5c65e14fd8944851837d08e")
