-- Lua provided by RyzenAPI
-- Game: Two Falls (Nishu Takuatshina)

-- MAIN APPLICATION
addappid(1671740)
-- Game: addappid(1671740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671741, 1, "0ae81f6748c2128a7d543fb6f9b45e888288c3a8b5c65e14fd8944851837d08e")
