-- Lua provided by RyzenAPI
-- Game: Red Rocket Defencism

-- MAIN APP DEPOTS / PACKAGES
addappid(2854440, 1, "4a62410b9e1b69f140a5580998f1c7f6ba01ce737e4a83f8d28ac0ea943b6a7c") -- Red Rocket Defencism
addappid(2854441, 1, "e9e28d3ee579cae013dd38e18befd893751bc10b9ea6ed058cc2658c144c2f98") -- Depot 2854441

