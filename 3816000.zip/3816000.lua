-- Lua provided by RyzenAPI
-- Game: Flowers and Deities

-- MAIN APPLICATION
addappid(3816000) -- Flowers and Deities

-- MAIN APP DEPOTS / PACKAGES
addappid(3816001, 1, "b21bc90d98e80c4eb7440c4f66fbc1a595cea9fb676a9a77e5272bd57a112f71") -- Depot 3816001

