-- 3816000's Lua and Manifest Created by Hubcap Manifest
-- Flowers and Deities
-- Created: August 15, 2026 at 03:08:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3816000) -- Flowers and Deities
-- MAIN APP DEPOTS
addappid(3816001, 1, "b21bc90d98e80c4eb7440c4f66fbc1a595cea9fb676a9a77e5272bd57a112f71") -- Depot 3816001
setManifestid(3816001, "2222789243038756473", 553196315)