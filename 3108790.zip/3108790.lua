-- Lua provided by SkyAPI 
-- Game: Three Kingdoms Heroes
addappid(3108790)
addappid(3108791, 1, "043b18feb8b6efd5d18f96151a75ecb6d99b3559630a69fe5f54c2da4f4cb4b0")
addappid(3108792, 1, "f7c798f4412ec1c1e7c94869fad5d3ba3b965ff130ac78ce4b14f7b2249fc961")
