-- Lua provided by RyzenAPI
-- Game: Game: Three Kingdoms Heroes

-- MAIN APPLICATION
addappid(3108790)
-- Game: addappid(3108790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108791, 1, "043b18feb8b6efd5d18f96151a75ecb6d99b3559630a69fe5f54c2da4f4cb4b0")
addappid(3108792, 1, "f7c798f4412ec1c1e7c94869fad5d3ba3b965ff130ac78ce4b14f7b2249fc961")
