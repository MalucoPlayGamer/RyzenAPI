-- Lua provided by RyzenAPI
-- Game: Lucky gem

-- MAIN APPLICATION
addappid(2522620)
-- Game: addappid(2522620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522621, 1, "cd903e66352e006c4dc6a8340332525fdbcf46cdaf5e7696c265a89417109471")
