-- Lua provided by RyzenAPI
-- Game: Escape from the Cursed Convent Demo

-- MAIN APPLICATION
addappid(3206920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206921, 1, "bb439c06774e0729017ed0fa91fcfce7eb114af679279f1ef2f4302f0ec1d8cd")
