-- Lua provided by RyzenAPI
-- Game: 211400

-- MAIN APPLICATION
addappid(211400)
-- Game: addappid(211400)

-- MAIN APP DEPOTS / PACKAGES
addappid(211401, 1, "81f2aa5c99f1f9d6a2793a7fcf622a10311954cea91bbfe18e137531bddc452d")
addappid(211419, 0, "000f3bd15a4dc24bcdcdb53cdf91ee17f75e8ebd69af284dc3dff9a51745ccac")
