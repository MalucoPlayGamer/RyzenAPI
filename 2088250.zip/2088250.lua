-- Lua provided by RyzenAPI
-- Game: 瘟疫清零计划 Project Zero

-- MAIN APPLICATION
addappid(2088250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088251, 1, "4df832f485ff8757b293b3a77abe85b5048625b9c9268db5f3a05295d292e221")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
