-- Lua provided by RyzenAPI
-- Game: It's high noon

-- MAIN APPLICATION
addappid(1965670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(1965671, 1, "fc68e34909dc63529f573306a737642b867926a012dce080eccf3b24fb53fd2d")

