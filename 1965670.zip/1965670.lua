-- Lua provided by RyzenAPI
-- Game: Game: It's high noon

-- MAIN APPLICATION
addappid(1965670)
-- Game: addappid(1965670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965671, 1, "fc68e34909dc63529f573306a737642b867926a012dce080eccf3b24fb53fd2d")
