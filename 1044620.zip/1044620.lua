-- Lua provided by RyzenAPI 
-- Game: Aokana - Four Rhythms Across the Blue
addappid(1044620)
addappid(1044621, 1, "e4de2e5ad93821687c7cc71aec870246915e61b66bec007091abb381da5454a1")
addappid(1162110, 0, "75cada30e8bfa481e7d923acc24e1593c5e1cf3f4df79ec9b81690af8f97a670")
addappid(1219130, 0, "7b39c1cbdc7abf346f2879d68ddf26e62080a42daf5ca6da87d0889ef27093c8")
addappid(1219150, 0, "205e9eaa30e63e10a340ad5057e4dba01087016109bb4065215bfb62b473a6dc")
addappid(1966540, 0, "9d67124c756a85a8c6115c471b6694bec604df1ccfa9ea8ecc44744daacfc25d")
addappid(1966541, 0, "2c2d64c11ec16a8d7f980ced69d635c558e1fc79f0b9f66df3f7a41fc79a182f")
