-- Lua provided by RyzenAPI
-- Game: Temtem: Showdown

-- MAIN APPLICATION
addappid(2254920)
-- Game: addappid(2254920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254921, 1, "46c87f8081f8ce42378aeb4511eeba8559ca4cdd58e5d0507b5d9ee9d45e2b7e")
