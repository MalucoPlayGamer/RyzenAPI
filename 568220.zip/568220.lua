-- Lua provided by RyzenAPI
-- Game: Game: Lobotomy Corporation | Monster Management Simulation

-- MAIN APPLICATION
addappid(568220)
-- Game: addappid(568220)

-- MAIN APP DEPOTS / PACKAGES
addappid(568221, 1, "4b83656636360e659df7b8f983d8436fe8216360fe0c6edf14f819a8622d70c7")
addappid(896000, 0, "76d7260e37893f7d0e8100d73d3685b1ebe2a0c8e71be8034d6f4c2d6596374b")
