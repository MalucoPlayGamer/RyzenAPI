-- Lua provided by RyzenAPI
-- Game: 1126290

-- MAIN APPLICATION
addappid(1126290)
-- Game: addappid(1126290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126291, 1, "e83afde6761301fe3dbc6dac26b94aa751ee4ce3d24a50ee38514c8a6f235a42")
addappid(1163360, 0, "4f4490ab394740bafe11a590c479b8c1583c8fda00a8315648de7289b2d986c1")
