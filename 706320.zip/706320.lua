-- Lua provided by RyzenAPI
-- Game: AppID 706320

-- MAIN APPLICATION
addappid(706320)
-- Game: addappid(706320)

-- MAIN APP DEPOTS / PACKAGES
addappid(706321, 1, "7127b2ed90ad399597b0af3e8c2de75432b73df67beec5e8b336753586c67126")
