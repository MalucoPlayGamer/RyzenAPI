-- Lua provided by RyzenAPI
-- Game: 3271320

-- MAIN APPLICATION
addappid(3271320)
-- Game: addappid(3271320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271321, 1, "a7bb3c75769c175b68ea1fdc4304d59e2729cc24a56b9537057d66e45afda09f")
