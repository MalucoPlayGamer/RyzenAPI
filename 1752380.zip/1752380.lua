-- Lua provided by RyzenAPI 
-- Game: 逐光之旅 Lumione Soundtrack
addappid(1752380)
addappid(1752381, 1, "8204afab7f360eb8cd76412d82ae44fab76b5b3677ee0ac7cb58971e23375d7a")
