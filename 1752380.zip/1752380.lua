-- Lua provided by RyzenAPI
-- Game: addappid(1752380)

-- MAIN APPLICATION
addappid(1752380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752381, 1, "8204afab7f360eb8cd76412d82ae44fab76b5b3677ee0ac7cb58971e23375d7a")
