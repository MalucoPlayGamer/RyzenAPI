-- Lua provided by RyzenAPI
-- Game: 2767070

-- MAIN APPLICATION
addappid(2767070)
-- Game: addappid(2767070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767071, 1, "224aee035620757ea0e9dffe92f63ff1396bf597946ef620ef55e6700ebbda2a")
