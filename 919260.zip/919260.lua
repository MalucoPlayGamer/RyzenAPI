-- Lua provided by RyzenAPI
-- Game: AppID 919260

-- MAIN APPLICATION
addappid(919260)

-- MAIN APP DEPOTS / PACKAGES
addappid(919261, 1, "e852c3022758f8879a96ca0f10dcf493c4a4563d14ea83afd08bad80aca63bc1")
