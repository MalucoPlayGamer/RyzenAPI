-- Lua provided by RyzenAPI
-- Game: AppID 919260

-- MAIN APPLICATION
addappid(919260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(919261, 1, "e852c3022758f8879a96ca0f10dcf493c4a4563d14ea83afd08bad80aca63bc1")

