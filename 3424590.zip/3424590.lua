-- Lua provided by SkyAPI 
-- Game: Jotunnslayer: Hordes of Hel Soundtrack
addappid(3424590)
addappid(3424591, 1, "570ca8f84f34b64ee06d56fea52312e3304f432dde9d38b55d2c603f2476c4d7")
addappid(3424592, 1, "c90e91c2327af1b4c3a709fbe2549c7282655fd16e15bff3f6441abccaa95b3a")
addappid(3424593, 1, "6260a43433591b82534d6118d9e9450e5289cbb75f97e4096ee7f45ef3508ceb")
