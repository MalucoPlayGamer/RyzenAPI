-- Lua provided by RyzenAPI
-- Game: addappid(585770)

-- MAIN APPLICATION
addappid(585770)

-- MAIN APP DEPOTS / PACKAGES
addappid(585771, 1, "d8ca3183b5d468bde822c416bb4b40de6fc082e5319000169e797bf999f6d6d0")
