-- Lua provided by RyzenAPI
-- Game: WanderLust

-- MAIN APPLICATION
addappid(1507420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507421, 1, "415aabc37c47dba3bba33d34d0397320ab90054e88b83f3d0ce49e0e1278b35c")
