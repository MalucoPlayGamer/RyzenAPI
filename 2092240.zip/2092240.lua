-- Lua provided by RyzenAPI 
-- Game: Anolock
addappid(2092240)
addappid(2092241, 1, "88f7b0e6a1087f97f920bed294023274ce98481f756cdf1a66a2a55071e0b2e2")
