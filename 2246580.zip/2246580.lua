-- Lua provided by RyzenAPI
-- Game: The Kill Zone Playtest

-- MAIN APPLICATION
addappid(2246580)
-- Game: addappid(2246580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246581, 1, "996a2beace4cfd1f09ba3533ba56941b0c111c742b0d6fea77704db4a797e79e")
