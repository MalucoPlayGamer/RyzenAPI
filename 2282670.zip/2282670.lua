-- Lua provided by RyzenAPI
-- Game: Game: 捉妖物语2-5个新角色大礼包 5 New Character Pack

-- MAIN APPLICATION
addappid(2282670)
-- Game: addappid(2282670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282671, 1, "5f24581d35766db52f8a3ffb0a921447fb420c2d1dd29b38d7ae55b5113d0e77")
