-- Lua provided by RyzenAPI
-- Game: addappid(2282670)

-- MAIN APPLICATION
addappid(2282670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282671, 1, "5f24581d35766db52f8a3ffb0a921447fb420c2d1dd29b38d7ae55b5113d0e77")
