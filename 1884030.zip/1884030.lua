-- Lua provided by RyzenAPI
-- Game: One Of The Victims

-- MAIN APPLICATION
addappid(1884030)
-- Game: addappid(1884030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884031, 1, "7d6b67a1a4ff79f25169c03b3a40e2ee43b75c7d85a7cccb014a0ed2a1be2d99")
