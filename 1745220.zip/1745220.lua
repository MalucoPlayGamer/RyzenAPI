-- Lua provided by RyzenAPI
-- Game: Mr.DomusMundi

-- MAIN APPLICATION
addappid(1745220)
-- Game: addappid(1745220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745221, 1, "b692f824ce30685d3b30fa8ba59f10a93f9af1cfe1a25106e354930e8206a09f")
