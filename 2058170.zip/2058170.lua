-- Lua provided by RyzenAPI
-- Game: Haunted Places

-- MAIN APPLICATION
addappid(2058170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058171, 1, "490f8bcd6bb912a71e33e00676a9256eccecc2d546e2b42103a9c15c31f6ada0")
