-- Lua provided by RyzenAPI
-- Game: 3190480

-- MAIN APPLICATION
addappid(3190480)
-- Game: addappid(3190480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190481, 1, "519657066cfff7b65c83a6d8aa32d2c6e701e5ce2bb3eb9239cdebdda4ece050")
