-- Lua provided by SkyAPI 
-- Game: A Few Nights With : Margaret
addappid(3190480)
addappid(3190481, 1, "519657066cfff7b65c83a6d8aa32d2c6e701e5ce2bb3eb9239cdebdda4ece050")
