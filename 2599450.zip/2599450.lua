-- Lua provided by SkyAPI 
-- Game: EarthKart: Google Maps Driving Simulator
addappid(2599450)
addappid(2599451, 1, "3821e04b68249991b76d71a5f5a8ca70a3b1f6d66713d33a2d32ccea1bb166de")
