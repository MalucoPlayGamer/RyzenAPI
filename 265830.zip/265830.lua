-- Lua provided by RyzenAPI
-- Game: Monochroma

-- MAIN APPLICATION
addappid(265830)
addappid(310600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(265831, 1, "e15ad7d0dfd684c12696e8adc1f63780322420fb30264d7e66ac935781022b33")
addappid(265832, 1, "e6fddba98b6985b45f75216a1dc394a4730317ff0f7557864c7f4a50f110c25e")
addappid(265833, 1, "1ea5689176a9bd50aaf0b86b30028a4232f8e7fffd22a3d0fd716f1130016e46")

