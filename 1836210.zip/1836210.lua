-- Lua provided by RyzenAPI
-- Game: Blocky Snake

-- MAIN APPLICATION
addappid(1836210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836211, 1, "8fb25dd90ffe43c91ff6831f0c8716d8adac2d03d150005e9c0f92b10ab88f95")
