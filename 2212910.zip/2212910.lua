-- 2212910's Lua and Manifest Created by Hubcap Manifest
-- Expeditions: Samurai
-- Created: August 07, 2026 at 11:23:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2212910) -- Expeditions: Samurai
-- MAIN APP DEPOTS
addappid(2212911, 1, "b79f8ae9ee060e4cff9d8be9dc937db5626ff9f3a160734ad0934668f4ebb269") -- Depot 2212911
setManifestid(2212911, "6064332079428705622", 7687633706)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)