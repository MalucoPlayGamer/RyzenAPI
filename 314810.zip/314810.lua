-- Lua provided by RyzenAPI
-- Game: Randal's Monday

-- MAIN APPLICATION
addappid(314810)

-- MAIN APP DEPOTS / PACKAGES
addappid(314811, 1, "dccef00e02b6b6c5b42f2834d818bd59b84c26fe1c182e7b34a46fa9f3850d93")
addappid(314812, 1, "7a42de3d6c7427a0d20eca7245f8e0bd6faaf0bb8bccdb6d5318194d4827831c")
addappid(314813, 1, "25d035a6de01612f77d1d36ae0c8d6fe11f9e38a5014527663653966854d9606")
addappid(314814, 1, "5ddb4ab16210bb8362498fd97d8d1c7f1329d1f325f0c3181fe1676a265497bd")
addappid(314815, 1, "f3b019a39cad4e6bd02daed90b408187c3455824ec96ff6a8d5cd3c23945607d")
addappid(314816, 1, "ff2ab0f1515f1d0c29d66657b8fa1037429a78a18f369362fc8630a5d038cde0")
addappid(314818, 1, "4757854536e7524194b30edb88af5d22b125c0d56b56aa89e77dcee1c1fd8183")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
