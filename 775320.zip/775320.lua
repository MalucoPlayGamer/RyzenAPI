-- Lua provided by RyzenAPI
-- Game: 775320

-- MAIN APPLICATION
addappid(775320)
-- Game: addappid(775320)

-- MAIN APP DEPOTS / PACKAGES
addappid(775321, 1, "5c5b1f1feff636fd644f15e162c8cecd7715ed1649d68905d5f8b2aa4059db52")
