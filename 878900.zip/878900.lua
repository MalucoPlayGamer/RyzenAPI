-- Lua provided by RyzenAPI 
-- Game: GMH - Good Morning Human !
addappid(878900)
addappid(878901, 1, "6279b1ebc90e5b640a8d168c7daa40b8114613dbca37c6e968ecc893ed73e2a6")
