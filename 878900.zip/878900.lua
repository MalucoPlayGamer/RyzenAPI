-- Lua provided by RyzenAPI
-- Game: GMH - Good Morning Human !

-- MAIN APPLICATION
addappid(878900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(878901, 1, "6279b1ebc90e5b640a8d168c7daa40b8114613dbca37c6e968ecc893ed73e2a6")

