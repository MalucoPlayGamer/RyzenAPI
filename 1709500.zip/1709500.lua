-- Lua provided by RyzenAPI
-- Game: Adorable Witch 2

-- MAIN APPLICATION
addappid(1709500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709501, 1, "ddab139823c90894215fb911eeed3b07a3c3b2c369892fa743f8b7e1d6f99e1c")
addappid(1752350, 0, "956a2f8931de2064dbee3de6b80d34e3fbd69230451fdcb1774d9d7cdf680348")

