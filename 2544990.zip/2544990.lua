-- Lua provided by RyzenAPI
-- Game: Game: Hypnosis Card

-- MAIN APPLICATION
addappid(2544990)
-- Game: addappid(2544990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544991, 1, "21db9bd328df7e3f98086b305be0dfc5dd6f71fe8746c3d4b13f941309233563")
addappid(2605650, 0, "0f8f8ac8430384cf56fbe67d88b3840c474b0a86599212cddbf3e8cae3807e77")
