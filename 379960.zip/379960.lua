-- Lua provided by RyzenAPI
-- Game: Game: AppID 379960

-- MAIN APPLICATION
addappid(379960)
-- Game: addappid(379960)

-- MAIN APP DEPOTS / PACKAGES
addappid(379961, 1, "e17bb9db1d81f3f3f1c29a2f7060be885b59c048060051938f60915d6f3b3289")
