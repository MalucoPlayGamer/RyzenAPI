-- Lua provided by RyzenAPI
-- Game: Mahjong Pretty Girls Battle : School Girls Edition

-- MAIN APPLICATION
addappid(379960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(379961, 1, "e17bb9db1d81f3f3f1c29a2f7060be885b59c048060051938f60915d6f3b3289")
