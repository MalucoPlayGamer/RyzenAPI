-- Lua provided by RyzenAPI
-- Game: Game: AppID 1140290

-- MAIN APPLICATION
addappid(1140290)
-- Game: addappid(1140290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140291, 1, "4e34bea0108d79c5f1984c0b1e4431632f5f2827f6b372e1811e9c98882df466")
