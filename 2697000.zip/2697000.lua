-- Lua provided by RyzenAPI
-- Game: addappid(2697000)

-- MAIN APPLICATION
addappid(2697000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697001, 1, "1cb4d75453db1b62aeeda84656052819f265e0909f92cc071c3f2bc3b1e9764b")
