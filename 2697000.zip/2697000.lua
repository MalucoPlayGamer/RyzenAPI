-- Lua provided by RyzenAPI
-- Game: The Legend of Khiimori

-- MAIN APPLICATION
addappid(2697000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2697001, 1, "1cb4d75453db1b62aeeda84656052819f265e0909f92cc071c3f2bc3b1e9764b")

