-- Lua provided by RyzenAPI
-- Game: Escape Z

-- MAIN APPLICATION
addappid(2571140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2571141, 1, "3ccd2c31bf0903f00a1c351a55ad95e1dabf3afb8d6388d4d8461d02088f4ca8")

