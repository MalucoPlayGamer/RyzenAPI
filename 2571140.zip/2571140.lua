-- Lua provided by RyzenAPI
-- Game: Escape Z

-- MAIN APPLICATION
addappid(2571140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571141, 1, "3ccd2c31bf0903f00a1c351a55ad95e1dabf3afb8d6388d4d8461d02088f4ca8")

