-- Lua provided by SkyAPI 
-- Game: Escape Z
addappid(2571140)
addappid(2571141, 1, "3ccd2c31bf0903f00a1c351a55ad95e1dabf3afb8d6388d4d8461d02088f4ca8")
