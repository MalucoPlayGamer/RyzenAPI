-- Lua provided by RyzenAPI
-- Game: Game: Dark Fall: The Journal

-- MAIN APPLICATION
addappid(260690)
-- Game: addappid(260690)

-- MAIN APP DEPOTS / PACKAGES
addappid(260691, 1, "4da672a0d692403681766124a2492c2581f693a3b641328a38c9634c20aea2b5")
