-- Lua provided by RyzenAPI
-- Game: Game: 2024 U.S. Election Simulator

-- MAIN APPLICATION
addappid(2542440)
-- Game: addappid(2542440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542441, 1, "97bec4371974f001f78bf2d457964eaf1c5c57cb129cf66e3b15f28c38db24af")
