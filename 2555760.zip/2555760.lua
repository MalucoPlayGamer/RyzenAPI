-- Lua provided by RyzenAPI
-- Game: Century of Anticipation

-- MAIN APPLICATION
addappid(2555760)
addappid(3836540)

