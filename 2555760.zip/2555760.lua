-- Lua provided by RyzenAPI
-- Game: Century of Anticipation

-- MAIN APPLICATION
addappid(2555760)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3836540)
