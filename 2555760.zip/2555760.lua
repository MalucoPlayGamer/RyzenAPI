-- Lua provided by RyzenAPI
-- Game: Century of Anticipation

-- MAIN APPLICATION
addappid(2555760)

