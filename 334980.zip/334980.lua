-- Lua provided by RyzenAPI
-- Game: Into Blue Valley

-- MAIN APPLICATION
addappid(334980)

-- MAIN APP DEPOTS / PACKAGES
addappid(334981, 1, "2e3d5d9756306f31d1915d0e8403747312530b03a391e411424b15715c13a8f1")
addappid(334982, 1, "cc9c56a2b8f97f605d987c1bc95564e1abd01414abcec7dd8debaf1971810987")
addappid(339870, 0, "c60f68a2518020989779ecf738079a613ceb680fb162139120385730bc0ba118")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
