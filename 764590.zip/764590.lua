-- Lua provided by SkyAPI 
-- Game: Shadow of Loot Box
addappid(764590)
addappid(764591, 1, "9bfcc1f3664ec0d40fbe8f52e0189e8879d6068cbb9cdd90dacd22aa784ca2e8")
