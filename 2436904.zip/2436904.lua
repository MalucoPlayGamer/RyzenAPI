-- Lua provided by RyzenAPI
-- Game: 2436904

-- MAIN APPLICATION
addappid(2436904)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436904,0,"e25ebae0fece5831d9ac46a4abfcd55ba5859a28f311748a38679ef91b3adb83")

