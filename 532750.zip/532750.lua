-- Lua provided by RyzenAPI 
-- Game: Dwarrows
addappid(532750)
addappid(532751, 1, "e75a332ab10143335aa9b8a65cc909591386c52bb7675810092ca898e41d22b6")
