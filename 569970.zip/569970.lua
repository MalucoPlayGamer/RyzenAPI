-- Lua provided by RyzenAPI
-- Game: addappid(569970)

-- MAIN APPLICATION
addappid(569970)

-- MAIN APP DEPOTS / PACKAGES
addappid(569971, 1, "4953f73257b36294c9b70b7709445b0acca61d3e18edbd51e03f5be9af801782")
