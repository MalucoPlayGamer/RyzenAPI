-- Lua provided by SkyAPI 
-- Game: AppID 3375580
addappid(3375580)
addappid(3375581, 1, "356f9f51b32235d1960ba5c55dddff8f9ce4af31717026e1e314d0da2096e2a7")
