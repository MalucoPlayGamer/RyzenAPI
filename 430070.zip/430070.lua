-- Lua provided by RyzenAPI
-- Game: 430070

-- MAIN APPLICATION
addappid(430070)
-- Game: addappid(430070)

-- MAIN APP DEPOTS / PACKAGES
addappid(430071, 1, "f1d443f336a6a72f8aac3c2de378c593ff061ad22569cbd4900816af993addf2")
