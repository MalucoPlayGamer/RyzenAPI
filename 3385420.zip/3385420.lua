-- Lua provided by RyzenAPI
-- Game: Game: How Much Items - Weapon

-- MAIN APPLICATION
addappid(3385420)
-- Game: addappid(3385420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385421, 1, "0323892df3477abfcef1062dad87175fad259c030aa3cb8154ef2a22d73d6e6b")
