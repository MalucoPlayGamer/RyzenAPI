-- Lua provided by RyzenAPI
-- Game: I'm Surrounded by Classical Beauties!

-- MAIN APPLICATION
addappid(2765200)
-- Game: addappid(2765200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765201, 1, "ca671813e2cff1191ad6e9468bb7cd2d490380952e8961834a682a67ee657541")
