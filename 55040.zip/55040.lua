-- Lua provided by RyzenAPI
-- Game: addappid(55040)

-- MAIN APPLICATION
addappid(55040)
addappid(228983)
addappid(228988)
addappid(229006)

-- MAIN APP DEPOTS / PACKAGES
addappid(55041, 1, "3e803851b05ca82eaa3d1f119cee0eb66673caa9ae32cb765ab5d3253aca5cb1")
addappid(55042, 1, "0254a6e6a39dfd9c9e0110450a962069fe9c13dc6434b38a280361a6633d7640")
addappid(55043, 1, "cac3f13288edd5df363325ad1f922bd4296dd388638bccf973676ae0ff472e27")
