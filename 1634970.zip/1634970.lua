-- Lua provided by RyzenAPI
-- Game: 1634970

-- MAIN APPLICATION
addappid(1634970)
-- Game: addappid(1634970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634971, 1, "7b6cf8342ee80bdb680a5f55b8dc0f410ef82c3352f5b48c75c65d7c7623d958")
