-- Lua provided by RyzenAPI
-- Game: Five Nations - Renegades

-- MAIN APPLICATION
addappid(2471720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471720,0,"f222be84794c9e36cf8361928046806879a77cb6085b28d44f23409052e691f3")

