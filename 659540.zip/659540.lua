-- Lua provided by SkyAPI 
-- Game: AppID 659540
addappid(659540)
addappid(659541, 1, "3f78a6499faa1c2bbd2c31927293c4dfdd7057277c7c8b532e7fd41b1861b232")
