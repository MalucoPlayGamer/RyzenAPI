-- Lua provided by RyzenAPI
-- Game: 659540

-- MAIN APPLICATION
addappid(659540)
-- Game: addappid(659540)

-- MAIN APP DEPOTS / PACKAGES
addappid(659541, 1, "3f78a6499faa1c2bbd2c31927293c4dfdd7057277c7c8b532e7fd41b1861b232")
