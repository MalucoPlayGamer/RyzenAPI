-- Lua provided by RyzenAPI
-- Game: Tollway Tycoon

-- MAIN APPLICATION
addappid(3976220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3976223,0,"d427fef1d6c6b8298371d3ac96488be051d0fbbbd9f8485814d4fd074c041416")

