-- Lua provided by RyzenAPI
-- Game: Game: Orbitality

-- MAIN APPLICATION
addappid(753100)
-- Game: addappid(753100)

-- MAIN APP DEPOTS / PACKAGES
addappid(753101, 1, "a7e6e735de3d9743b2e4da81597d6701cb9429fc31a17422a3bd32ca2a9fa883")
