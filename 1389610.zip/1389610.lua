-- Lua provided by RyzenAPI
-- Game: Hell Road VR

-- MAIN APPLICATION
addappid(1389610)
addappid(1784850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389611, 1, "8d313e1cc90bf3d76b4362c99b6ee43d594c2f1f4720b7ef040f5724a612a0d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
