-- Lua provided by RyzenAPI
-- Game: 40980

-- MAIN APPLICATION
addappid(40980)
addappid(1802300)
addappid(1802301)
-- Game: addappid(40980)

-- MAIN APP DEPOTS / PACKAGES
addappid(40981, 1, "c1c382c8aa767a8ba91e585e6c2b4502a11a623d0ba8542cbccbe6e1f049bbe4")
addappid(40982, 1, "8ec4ed81cfa3b972c0b8a2972d453e51a218dc789b13ccd68f52c49036acd5c7")
addappid(40983, 1, "bc226ca49cbe4dc7670388e7d735d831d7e35c87e5c7c4f7b3e3b8b2bcbddf29")
addappid(40984, 1, "3691b5fde619fee2dc5f87eddac1a1fc47d1c4be9742bc6fd99388f2bb568c83")
addappid(40985, 1, "a0e3482e87d4d616a1bb1d772c73d52e851e6f4d24fe124d496666e49681dd5d")
addappid(40986, 1, "6bfd7376a2aaea11760fa8aff2f7da184c0c54abeebcf44ccb07ccde7f9fee2e")
addappid(40987, 1, "f063a59289c3f6f331d880426be63a3b9c4f17f17564bf117e0383271bc2fc8f")
addappid(40988, 1, "20b764f1d64aaa1bdc533ef7ee12c7b74d9ae51ca76d77dbf63dfe1ac3f87d5d")
addappid(40989, 1, "8c008792271ae8087061c71ad94b2d738a26d2651b3e9274be28888ab019cb42")
