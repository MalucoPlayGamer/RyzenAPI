-- Lua provided by RyzenAPI
-- Game: addappid(1696440)

-- MAIN APPLICATION
addappid(1696440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696441, 1, "d9d9203084ea5a76bb40325b0d450fda89e2f4b27f1c4a336f062110ed51c526")
