-- Lua provided by RyzenAPI
-- Game: Retro City Rampage™ DX

-- MAIN APPLICATION
addappid(204630)

-- MAIN APP DEPOTS / PACKAGES
addappid(204631, 1, "7097b669de45c1396ed78238536c2988accc5a85b51f6cc0c2ea9db8f70e1fbf")
addappid(204632, 1, "a4602f910b346ccc153ac193de7a35a3d04a62a83798a9cb2403623017319177")
addappid(204633, 1, "83bbcf9d7720ab01622a759822e50baf2ed3c79688d25cb0db377dc70a501ade")
addappid(204634, 1, "51f6f917f2c8dd2b47040ee55c180d6950cc2eac998954af049d84204e0753c4")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
