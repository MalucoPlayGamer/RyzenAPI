-- Lua provided by RyzenAPI
-- Game: addappid(1060170)

-- MAIN APPLICATION
addappid(1060170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060171, 1, "4e758536c5384a9dd4243df42f476de9fc12d6538d7fcac3ddc4e819fab779a9")
