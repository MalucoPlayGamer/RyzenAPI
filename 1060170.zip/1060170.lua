-- Lua provided by RyzenAPI
-- Game: Azurael's Circle: Chapter 4

-- MAIN APPLICATION
addappid(1060170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1060171, 1, "4e758536c5384a9dd4243df42f476de9fc12d6538d7fcac3ddc4e819fab779a9")
