-- Lua provided by RyzenAPI
-- Game: Delta Force Xtreme 2

-- MAIN APPLICATION
addappid(32610)

-- MAIN APP DEPOTS / PACKAGES
addappid(32611, 1, "630feed02b38c37825b08daf843337ac5ab9c8b44987bfd6a5bbe03bf31b1e04")
