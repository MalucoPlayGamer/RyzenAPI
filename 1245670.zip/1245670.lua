-- Lua provided by RyzenAPI
-- Game: Blackstone Academy for the Magical Arts

-- MAIN APPLICATION
addappid(1245670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245671, 1, "317c0ddd6844e1a379967a64c7b744c31c0a5a83f2848dfdbbe2e228f4dacf94")
addappid(1245672, 1, "143d7e2008d2b8cf852622a8bdf308803cd4dd9a45a1331942bc1d8842ee73bb")
addappid(1245673, 1, "c58bce9a45614414620ffe4d5dcae634c4258175dd31f093579305a4ba1f7cdd")

