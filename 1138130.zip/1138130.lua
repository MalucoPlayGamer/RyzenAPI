-- Lua provided by RyzenAPI
-- Game: Game: AppID 1138130

-- MAIN APPLICATION
addappid(1138130)
-- Game: addappid(1138130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138131, 1, "cde0b96c9a0a5d5012a10fdc6beecea7fa21078f544f60965725607d2af0eb63")
