-- Lua provided by RyzenAPI
-- Game: Game: Blue Sheep

-- MAIN APPLICATION
addappid(409280)
-- Game: addappid(409280)

-- MAIN APP DEPOTS / PACKAGES
addappid(409281, 1, "f7ed864b527c9d93e70d45aae2de577188cfe84563322dd32e9f314137728b50")
addappid(409282, 1, "ad9df3229ebf24a1523fac2d7c7a058b76382f0f575b2931a6b4762f82291290")
addappid(409283, 1, "b671c2926cadb1f5afea462a689a368c9a209f30cb6360a9481c8a53fb64f930")
