-- Lua provided by RyzenAPI
-- Game: Game: Spellbound Survivors

-- MAIN APPLICATION
addappid(2602450)
-- Game: addappid(2602450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602451, 1, "515edcd325ac4c4b433b1567baa848a13eca447bf892217396019f5b56cf2918")
