-- Lua provided by RyzenAPI
-- Game: World of Guns: Gun Disassembly

-- MAIN APPLICATION
addappid(262410)
-- Game: addappid(262410)

-- MAIN APP DEPOTS / PACKAGES
addappid(262411, 1, "ff42141cc1f34989188abbb4dbb59c495b355f743db74eca4bf677a37b0f5aad")
addappid(262412, 1, "4277a3b9facc196c21a8ca501d15c9583befd87ad2138a4fcc69d1d7c9fafbde")
addappid(262413, 1, "6dd747d3385f1e409f8a9d1ea9d390395bf80e6cb0f2ef996ff97ea1d65b5851")
addappid(262414, 1, "e2305f613f7ac465d51c806f157f98291c4ecb704b36b91a150d54d49a849187")
