-- Lua provided by RyzenAPI
-- Game: World of Guns: Gun Disassembly

-- MAIN APPLICATION
addappid(304310) -- World of Guns Guns Full Access
addappid(304320) -- 4 Cars Pack
addappid(304330) -- World of Guns 5 Skeletons Pack
addappid(304360) -- 10 Shooting Ranges Pack
addappid(307420) -- World of Guns Starter Pack
addappid(310400) -- World of GunsWorld War II Pack
addappid(350130) -- World of GunsTexture Pack 1
addappid(393910) -- World of Guns Spec Ops Pack
addappid(464210) -- World of Guns Sniper Rifles Pack 1
addappid(519950) -- World of Guns U.S.A. Guns Pack 1
addappid(526070) -- World of Guns USSR Guns Pack 1
addappid(535130) -- World of GunsTexture Pack 2
addappid(558630) -- World of Guns World War I Pack 1
addappid(578270) -- World of GunsAircraft Guns
addappid(641440) -- World of Guns Revolver Pack 1
addappid(653570) -- World of GunsWorld War II Pack 2
addappid(660050) -- World of Guns Pistols Pack 1
addappid(660060) -- World of Guns Pistols Pack 2
addappid(674290) -- World of Guns Hunting Pack 1
addappid(674300) -- World of Guns Shotguns Pack 1
addappid(709210) -- World of Guns Machine Guns Pack 1
addappid(724020) -- World of Guns US Army Guns Pack 1
addappid(850440) -- World of Guns SMG Pack 1
addappid(917250) -- World of Guns Assault Rifles Pack 1
addappid(917260) -- World of Guns Bolt Action Rifles Pack 1
addappid(969070) -- World of Guns XIX Century Pack 1
addappid(1083250) -- World of Guns Suppressed Guns Pack 1
addappid(4944540) -- World of Guns Pocket Guns Pack 1
addappid(4972740) -- World of Guns Artillery Pack
addappid(4972760) -- World of Guns Suppressed Guns Pack 2

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(262410, 1, "16257c0d5e87471ae7b2681af88c480caa00bffde1242a9de2c9a264b6597d6c") -- World of Guns: Gun Disassembly
addappid(262411, 1, "ff42141cc1f34989188abbb4dbb59c495b355f743db74eca4bf677a37b0f5aad") -- World of Guns PC
addappid(262412, 1, "4277a3b9facc196c21a8ca501d15c9583befd87ad2138a4fcc69d1d7c9fafbde") -- World of Guns Mac
addappid(262413, 1, "6dd747d3385f1e409f8a9d1ea9d390395bf80e6cb0f2ef996ff97ea1d65b5851") -- World of Guns Linux
addappid(262414, 1, "e2305f613f7ac465d51c806f157f98291c4ecb704b36b91a150d54d49a849187") -- Depot 262414

