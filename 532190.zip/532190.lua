-- Lua provided by RyzenAPI
-- Game: Super Blood Hockey

-- MAIN APPLICATION
addappid(532190)

-- MAIN APP DEPOTS / PACKAGES
addappid(532191, 1, "a0689f723c6c3993e48db15ffb4472b57f5bb755291f05eae39f3eab9adf7eac")
addappid(532192, 1, "26e19cb5e89240f6106fe2eb48a22071619b74615df5a57dfbbf0ccdced82962")
addappid(532193, 1, "27177d790b1e0a44cf99a5f9517fdf28523bd034b2815e560e8b317b94922894")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(693000)
