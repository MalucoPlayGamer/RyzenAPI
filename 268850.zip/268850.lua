-- Lua provided by RyzenAPI 
-- Game: EVGA Precision X1
addappid(268850)
addappid(268851, 1, "5cc9bc2d471dcb7c404e6b53cc1ba2c7338208615adc76cff7b6a4eacc15ff91")
