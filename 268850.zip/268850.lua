-- Lua provided by RyzenAPI
-- Game: addappid(268850)

-- MAIN APPLICATION
addappid(268850)

-- MAIN APP DEPOTS / PACKAGES
addappid(268851, 1, "5cc9bc2d471dcb7c404e6b53cc1ba2c7338208615adc76cff7b6a4eacc15ff91")
