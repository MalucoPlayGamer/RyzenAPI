-- Lua provided by RyzenAPI
-- Game: 2765860

-- MAIN APPLICATION
addappid(2765860)
-- Game: addappid(2765860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765861, 1, "afb974bac8d4f0daff36ca40a0a0ec678575af0a3d4cfd5d82dd82f3ea94c336")
addappid(2765862, 1, "f967a40a5d719b9fb2752463b0e89225e5f7515d6f7725be6f388bf6bfc41e97")
