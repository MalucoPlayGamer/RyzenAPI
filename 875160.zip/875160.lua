-- Lua provided by RyzenAPI
-- Game: Mall Town

-- MAIN APPLICATION
addappid(875160)

-- MAIN APP DEPOTS / PACKAGES
addappid(875161,0,"74840c7b00f60bc9d6221bb5d99299dc90c054b2680c02e2eeefdbf9e02b7f77")

