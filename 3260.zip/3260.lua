-- Lua provided by RyzenAPI
-- Game: Safecracker: The Ultimate Puzzle Adventure

-- MAIN APPLICATION
addappid(3260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261, 1, "965cd42bb7d3ade83b28891079967082243d70af4443c049e3f4d525a258e3a6")
addappid(3263, 1, "ae3a9641fdb762499adeed6e4d161fd25c724d54358add23e7bc16ef941bf3ca")
addappid(3264, 1, "1b0b4977f67165d0716dc3e00625bf58eb64a37fffcdd3354ca9e895a2584181")
addappid(3265, 1, "fc6fef6c5dacf1b99584523e6edcb75b6a9d76b6b09b9f44eb5b0877995db993")
