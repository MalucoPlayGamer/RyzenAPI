-- Lua provided by RyzenAPI
-- Game: Game: Agatha Knife

-- MAIN APPLICATION
addappid(618950)
-- Game: addappid(618950)

-- MAIN APP DEPOTS / PACKAGES
addappid(618951, 1, "15a39d2134dccf24d965d173ae45a42ee9957e2f0f153eff0518290a2cdc4e2d")
addappid(618952, 1, "884b7c918b009d74acebeed9678188b67b0eaca16d95ebf014706c7d34943878")
addappid(618953, 1, "ef8432ad7d0880b4ba5d4ee8472d3f2e25b0838ca6183b4bfecbb7fc39bcdab2")
addappid(618954, 1, "a8546b6ebdd757316a12d0a19d0a823d8827586516473e95739616bec79860f0")
