-- Lua provided by RyzenAPI
-- Game: Hentai Waifu

-- MAIN APPLICATION
addappid(1044450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044451, 1, "73228aa78cc7161442aae94ecbcca99227f61aaa0e7dfd2fa96f137dfc215601")
addappid(1046800, 0, "a26f4a4db3e037872d16ef1984f6cf9ddc31121ec2a0bf1bfe15a676cd915294")
addappid(1046801, 0, "915912167a8148ef6b5e51541bc7bfba62578306ff93638203da3bfbed7f4ce0")

