-- Lua provided by RyzenAPI
-- Game: Little Witch Nobeta Demo

-- MAIN APPLICATION
addappid(1054530)
-- Game: addappid(1054530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054531, 1, "24fccd3ec6d23ec5c8eed645f0334995848aee542101de3214167efe50c6fca9")
