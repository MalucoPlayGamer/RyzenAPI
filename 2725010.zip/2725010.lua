-- Lua provided by RyzenAPI
-- Game: 西游伏妖传

-- MAIN APPLICATION
addappid(2725010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725011, 1, "9e9beea2d9922bac1db9f08cd15ce64ce2d97ff682a158f4cd81f5484e6a2499")

