-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(606480)
addappid(606481)
-- Game: addappid(606480)

-- MAIN APP DEPOTS / PACKAGES
addappid(606482,0,"624d1587ab0fdc37274df3e54761c3d76ed828cb7e39ef4047e5d57c3e0afbdb")
addappid(647400,0,"d3ac1a9dc13da25720b82591a300d6657b0db1315b9e1c422d2e9a2fadc44858")
