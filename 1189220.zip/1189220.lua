-- Lua provided by RyzenAPI
-- Game: addappid(1189220)

-- MAIN APPLICATION
addappid(1189220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189221, 1, "ef75ee0dc433ec62c98d68b7c76eda896ae6f6fbf32530f76511d2a902bb75ef")
