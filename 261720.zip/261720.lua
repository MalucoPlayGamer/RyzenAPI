-- Lua provided by RyzenAPI
-- Game: AppID 261720

-- MAIN APPLICATION
addappid(261720)

-- MAIN APP DEPOTS / PACKAGES
addappid(261721, 1, "0029556174c7cc47d06bc28f623b2822c8a40a311831e56cc74c8822ae2a3357")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
