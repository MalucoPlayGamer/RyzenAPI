-- Lua provided by RyzenAPI 
-- Game: AppID 261720
addappid(261720)
addappid(261721, 1, "0029556174c7cc47d06bc28f623b2822c8a40a311831e56cc74c8822ae2a3357")
