-- Lua provided by RyzenAPI
-- Game: AppID 315640

-- MAIN APPLICATION
addappid(315640)

-- MAIN APP DEPOTS / PACKAGES
addappid(315641, 1, "41115a3a083bf9388f5e7a64ff27bc2ce396282f25dc7e5eb93df0a7957fd9b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(330360)
addappid(330361)
addappid(330362)
addappid(330363)
