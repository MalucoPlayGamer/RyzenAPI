-- Lua provided by RyzenAPI
-- Game: 315640

-- MAIN APPLICATION
addappid(315640)
-- Game: addappid(315640)

-- MAIN APP DEPOTS / PACKAGES
addappid(315641, 1, "41115a3a083bf9388f5e7a64ff27bc2ce396282f25dc7e5eb93df0a7957fd9b6")
