-- Lua provided by RyzenAPI 
-- Game: AppID 3394460
addappid(3394460)
addappid(3394461, 1, "36120a42596bdc0393db9d05db67235272a0d24b6e990d31c7017d89689d9695")
