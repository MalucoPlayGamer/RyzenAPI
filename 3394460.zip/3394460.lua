-- Lua provided by RyzenAPI
-- Game: AppID 3394460

-- MAIN APPLICATION
addappid(3394460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3394461, 1, "36120a42596bdc0393db9d05db67235272a0d24b6e990d31c7017d89689d9695")

