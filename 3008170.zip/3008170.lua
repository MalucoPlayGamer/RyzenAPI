-- Lua provided by RyzenAPI 
-- Game: AppID 3008170
addappid(3008170)
addappid(3008171, 1, "edb6fe24b4dfe01d5ef2fa73973e521b9768b2c117ebf135347caec2505d5013")
