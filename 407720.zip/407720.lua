-- Lua provided by RyzenAPI
-- Game: Poker Pretty Girls Battle: Texas Hold'em

-- MAIN APPLICATION
addappid(407720)
-- Game: addappid(407720)

-- MAIN APP DEPOTS / PACKAGES
addappid(407721, 1, "ad8f64bc94e5a13ab911569b27ff1892730d95f46f0f664877a5915afaf83882")
