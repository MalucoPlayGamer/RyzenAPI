-- Lua provided by RyzenAPI
-- Game: addappid(1210570)

-- MAIN APPLICATION
addappid(1210570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210571, 1, "f0103b2882988cec3c9ae66f270f7d7f68a905a410aa3d5d37b9b39e5462c535")
