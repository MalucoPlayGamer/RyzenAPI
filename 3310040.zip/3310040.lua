-- Lua provided by RyzenAPI
-- Game: addappid(3310040)

-- MAIN APPLICATION
addappid(3310040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310041, 1, "7cceca005e10602c267d03c7b0bdb7821d99643fbe785e7616af88b34b6d4556")
