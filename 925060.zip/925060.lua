-- Lua provided by RyzenAPI 
-- Game: Fiber Twig 2
addappid(925060)
addappid(925061, 1, "cb0f1f50c856835579a34a7b05aa22218a79b91a9c00ff20aab418c45e46dce6")
