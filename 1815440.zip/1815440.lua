-- Lua provided by RyzenAPI
-- Game: 1815440

-- MAIN APPLICATION
addappid(1815440)
-- Game: addappid(1815440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815441, 1, "382c8c7d46808692f897625a2716644ae1ee3be176d6b656ba9c6f3ac35b3f05")
