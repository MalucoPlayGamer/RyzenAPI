-- Lua provided by RyzenAPI
-- Game: Heroes of Hammerwatch

-- MAIN APPLICATION
addappid(677120)
addappid(1015030)
addappid(1086870)
addappid(1142880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(677121, 1, "a175a07de8796904ceaff58ff186aa983270cf4301f6a26d4f76abc7d8b2749e")
addappid(677122, 1, "52a310f44e22eee98421d0dd9e87de2c210896905877bd2f04f52401660739e4")
addappid(677123, 1, "7027f8c7f8da0b83184d381e52a5f34362cbfee68b65d5dd6822341c6fd4f159")
addappid(677124, 1, "a5b87dcb4717817ae4774487248222d19cda763f2e7fccb349c2d5a4d4d65e5d")
