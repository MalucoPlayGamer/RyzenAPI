-- Lua provided by RyzenAPI
-- Game: Disappearance - Takeshi. You were right. That Abandoned Village is Too Bad

-- MAIN APPLICATION
addappid(2775310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775311, 1, "6a0ee61b3983ab39252ca5dbf55b53f253347390a0e8d68569084b6ca3239d2d")

