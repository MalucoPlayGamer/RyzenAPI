-- Lua provided by RyzenAPI
-- Game: 1767880

-- MAIN APPLICATION
addappid(1767880)
-- Game: addappid(1767880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767881, 1, "b5c9c0984148a02cb6a62f5ce44049b838e1c15211accf9d1832235cd4d16281")
