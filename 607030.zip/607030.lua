-- Lua provided by SkyAPI 
-- Game: AppID 607030
addappid(607030)
addappid(607031, 1, "c91a6482395f2871e0f670aeda1c911d39b8d49ebed9f1137e0b8f1811118e98")
