-- Lua provided by RyzenAPI
-- Game: Jade's Journey 2

-- MAIN APPLICATION
addappid(607030)

-- MAIN APP DEPOTS / PACKAGES
addappid(607031, 1, "c91a6482395f2871e0f670aeda1c911d39b8d49ebed9f1137e0b8f1811118e98")
