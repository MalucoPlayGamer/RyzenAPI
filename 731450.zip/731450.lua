-- Lua provided by RyzenAPI
-- Game: Game: DROP VR - AUDIO VISUALIZER

-- MAIN APPLICATION
addappid(731450)
-- Game: addappid(731450)

-- MAIN APP DEPOTS / PACKAGES
addappid(731451, 1, "c3318c8a88d04bc124328799c1ae9198222b87cd6dcac095bf945bf46f02b458")
