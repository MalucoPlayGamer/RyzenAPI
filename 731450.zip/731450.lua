-- Lua provided by RyzenAPI
-- Game: DROP VR - AUDIO VISUALIZER

-- MAIN APPLICATION
addappid(731450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(731451, 1, "c3318c8a88d04bc124328799c1ae9198222b87cd6dcac095bf945bf46f02b458")

