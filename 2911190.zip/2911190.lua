-- Lua provided by RyzenAPI
-- Game: Heroes Wanted Demo

-- MAIN APPLICATION
addappid(2911190)
-- Game: addappid(2911190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911191, 1, "1180a512574f7adf28c6ad221deda56cb57c5b34d010e426ca30a2df2ee820f1")
