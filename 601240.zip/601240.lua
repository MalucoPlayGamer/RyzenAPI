-- Lua provided by RyzenAPI
-- Game: Game: AppID 601240

-- MAIN APPLICATION
addappid(601240)
-- Game: addappid(601240)

-- MAIN APP DEPOTS / PACKAGES
addappid(601241, 1, "005982f5f7b9013f5f305581be57994c8632ef212a6180fada302911f05e099d")
