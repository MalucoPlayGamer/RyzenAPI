-- Lua provided by RyzenAPI
-- Game: Game: AppID 3181820

-- MAIN APPLICATION
addappid(3181820)
-- Game: addappid(3181820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181821, 1, "9fea2b676f1209c9228b2431df537d71bc1a4a739716358527038bbb3c801a66")
