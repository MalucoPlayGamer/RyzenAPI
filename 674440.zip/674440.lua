-- Lua provided by RyzenAPI
-- Game: Game: AppID 674440

-- MAIN APPLICATION
addappid(674440)
-- Game: addappid(674440)

-- MAIN APP DEPOTS / PACKAGES
addappid(674441, 1, "0e3d02783ca9b2168db4b2a6e54895e28b3c349658dd4b6526348b9633334337")
