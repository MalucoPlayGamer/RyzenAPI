-- Lua provided by SkyAPI 
-- Game: AppID 674440
addappid(674440)
addappid(674441, 1, "0e3d02783ca9b2168db4b2a6e54895e28b3c349658dd4b6526348b9633334337")
