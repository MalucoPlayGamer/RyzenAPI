-- Lua provided by RyzenAPI
-- Game: Arctic Trucker Simulator

-- MAIN APPLICATION
addappid(273890)

-- MAIN APP DEPOTS / PACKAGES
addappid(273891, 1, "a74be23565676881482b8ff8fef331388b89f20444fef4d1eb5903a745d7afa2")

