-- Lua provided by RyzenAPI
-- Game: 356450

-- MAIN APPLICATION
addappid(356450)
-- Game: addappid(356450)

-- MAIN APP DEPOTS / PACKAGES
addappid(356451, 1, "29d6ebce08d1ff99d14f0534fa0bd4f0d40d623fa7b612e15c30187d53b20d26")
addappid(356452, 1, "5fc164b8feffd69bc5e22fa1b50b7b8e782a954f7d7b89a8d440edcd8a7cc86e")
addappid(356453, 1, "838fff9c4fdf420bf8ab1061a3b7fa136f317d95be2061d6a804af2e3e967651")
