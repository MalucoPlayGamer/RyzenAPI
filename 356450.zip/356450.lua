-- Lua provided by RyzenAPI
-- Game: AppID 356450

-- MAIN APPLICATION
addappid(356450)

-- MAIN APP DEPOTS / PACKAGES
addappid(356451, 1, "29d6ebce08d1ff99d14f0534fa0bd4f0d40d623fa7b612e15c30187d53b20d26")
addappid(356452, 1, "5fc164b8feffd69bc5e22fa1b50b7b8e782a954f7d7b89a8d440edcd8a7cc86e")
addappid(356453, 1, "838fff9c4fdf420bf8ab1061a3b7fa136f317d95be2061d6a804af2e3e967651")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
