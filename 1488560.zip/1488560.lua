-- Lua provided by RyzenAPI
-- Game: Football Simulator

-- MAIN APPLICATION
addappid(1488560)
-- Game: addappid(1488560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488561, 1, "f95f16186d655c77c7291f449147c6c688be6c189ab6fa5a166c0b56c75c184b")
