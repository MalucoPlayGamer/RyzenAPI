-- Lua provided by RyzenAPI
-- Game: addappid(1309560)

-- MAIN APPLICATION
addappid(1309560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309561, 1, "f1f6f18b872434a3a7d86bba5b2dc3ed93c6dae203dae0b665294ac6725486c4")
