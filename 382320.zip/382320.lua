-- Lua provided by RyzenAPI 
-- Game: Heart of Ember CH1
addappid(382320)
addappid(382321, 1, "1b4ae10667f8ad8e4a4e3fc88d85b612b5094ddac290c718e83e0a25c218cf4b")
