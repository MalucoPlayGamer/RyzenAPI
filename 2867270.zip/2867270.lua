-- Lua provided by RyzenAPI
-- Game: AppID 2867270

-- MAIN APPLICATION
addappid(2867270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867271, 1, "8bebc6746633dbd6035230fdaef79ff2e5950c77d244d2e9db3a64d9c96b16d7")
