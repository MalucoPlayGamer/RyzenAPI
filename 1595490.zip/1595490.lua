-- Lua provided by RyzenAPI
-- Game: Super Raft Boat VR

-- MAIN APPLICATION
addappid(1595490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595491, 1, "e78e49a1657e4c51354edd3b243a8b4232766cc892a1a0ca5cc55832b00ba4b6")
