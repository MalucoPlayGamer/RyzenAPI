-- Lua provided by RyzenAPI
-- Game: Spanky!

-- MAIN APPLICATION
addappid(1732420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1732421, 1, "96e3e7efcf64757664a4ff547d7ae664f3aa5d999dac014e4715f0db696e11da")

