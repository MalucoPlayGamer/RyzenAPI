-- Lua provided by RyzenAPI
-- Game: Game: Spanky!

-- MAIN APPLICATION
addappid(1732420)
-- Game: addappid(1732420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732421, 1, "96e3e7efcf64757664a4ff547d7ae664f3aa5d999dac014e4715f0db696e11da")
