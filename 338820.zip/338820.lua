-- Lua provided by RyzenAPI
-- Game: Retro Commander

-- MAIN APPLICATION
addappid(338820)

-- MAIN APP DEPOTS / PACKAGES
addappid(338822,0,"cfcf4a618f89110af67ebe30f044bf8b80e189b022203a7ce85cdd93cde9536d")
addappid(338823,0,"d3bfd154f233c6d8a6427fd4363046250177525edf5f9174b6a0bb28a6369044")
addappid(338825,0,"70452174b740abca864cc3db8bde20e659168d9e5ea057d1f005119e32e0139f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2002530)
