-- Lua provided by SkyAPI 
-- Game: AppID 612850
addappid(612850)
addappid(612851, 1, "b9e937c7f9c84efa657656d1a3038e0a39f88cf45d6b245e0fbdadba1914e55c")
