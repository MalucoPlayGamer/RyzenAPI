-- Lua provided by RyzenAPI
-- Game: Game: AppID 612850

-- MAIN APPLICATION
addappid(612850)
-- Game: addappid(612850)

-- MAIN APP DEPOTS / PACKAGES
addappid(612851, 1, "b9e937c7f9c84efa657656d1a3038e0a39f88cf45d6b245e0fbdadba1914e55c")
