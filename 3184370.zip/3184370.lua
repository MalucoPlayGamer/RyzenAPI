-- Lua provided by RyzenAPI
-- Game: AppID 3184370

-- MAIN APPLICATION
addappid(3184370)
-- Game: addappid(3184370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184371, 1, "dde89635ff397c1e3bc22aa6a4d0faf7b3e887d5fea12297d730eaec15a57e1f")
