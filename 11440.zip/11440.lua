-- Lua provided by RyzenAPI
-- Game: addappid(11440)

-- MAIN APPLICATION
addappid(11440)

-- MAIN APP DEPOTS / PACKAGES
addappid(11441, 1, "0fe8ec32469df72ed38d8cea46c956993fbcd2715b64ad2faff774517b80fce7")
