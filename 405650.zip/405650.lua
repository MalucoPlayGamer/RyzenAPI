-- Lua provided by RyzenAPI
-- Game: addappid(405650)

-- MAIN APPLICATION
addappid(405650)
addappid(427020)

-- MAIN APP DEPOTS / PACKAGES
addappid(405651, 1, "09ef93e9a2c6b5cf49cab2479fdc5d0ef54cfce8d08ccd0c0d0fed76a11b5adf")
addappid(405652, 1, "d78c414a1fc7a10e63536ffd24e034e94e79ea5ef6fdab36ece9ec8223ac6f72")
addappid(405653, 1, "b479cd48c6db7886712a4e15dc71beb71b2f896ded33a9114fea1b96b7362574")
addappid(405654, 1, "f5d2ad6525d474592a49f0ca4d5c7ad1edbb32b34d64041104110c6679980875")
