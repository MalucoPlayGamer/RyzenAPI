-- Lua provided by RyzenAPI
-- Game: STEINS;GATE: Linear Bounded Phenogram

-- MAIN APPLICATION
addappid(930910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(930911, 1, "10fb0a4b6d5655dc4ea847bb780338fec402a568e4753269a7be0a2918d38907")
addappid(930912, 1, "5fd0457c901b8cfc4fdeb7831a8ad49ffb2731203e33973123af4863908a056e")
addappid(930913, 1, "495472150fcce3ec282a49abebf0c90a31ce4b128af49872aa615c7eca4df6c4")

