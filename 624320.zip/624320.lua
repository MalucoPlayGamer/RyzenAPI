-- Lua provided by SkyAPI 
-- Game: AppID 624320
addappid(624320)
addappid(624321, 1, "107eb1bf58657c67e6c0fb0dde187d0fe9639896e318b0342a25e760d4eade7d")
addappid(818200, 0, "b8b518fbe6673d46be376a3b77380f371332404dbc2c567e03106ba98d785c36")
