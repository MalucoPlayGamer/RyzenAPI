-- Lua provided by RyzenAPI
-- Game: Loyalty and Blood: Viktor Origins

-- MAIN APPLICATION
addappid(624320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(624321, 1, "107eb1bf58657c67e6c0fb0dde187d0fe9639896e318b0342a25e760d4eade7d")
addappid(818200, 0, "b8b518fbe6673d46be376a3b77380f371332404dbc2c567e03106ba98d785c36")

