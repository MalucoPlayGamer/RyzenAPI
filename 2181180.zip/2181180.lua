-- Lua provided by RyzenAPI
-- Game: Crib

-- MAIN APPLICATION
addappid(2181180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181181, 1, "ce51fb9c2f5330f4927eb55578be925cdbcb5472780a6f3138769e109e3a69df")

