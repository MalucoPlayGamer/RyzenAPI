-- Lua provided by SkyAPI 
-- Game: LAN Party
addappid(2613480)
addappid(2613481, 1, "cd1624e25f4bc9df61477e6dc1b8af3feaf6324547b2427e550886aa8ddb2c9b")
