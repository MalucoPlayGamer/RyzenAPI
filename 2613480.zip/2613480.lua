-- Lua provided by RyzenAPI
-- Game: addappid(2613480)

-- MAIN APPLICATION
addappid(2613480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613481, 1, "cd1624e25f4bc9df61477e6dc1b8af3feaf6324547b2427e550886aa8ddb2c9b")
