-- Lua provided by RyzenAPI
-- Game: Destroy All Humans! 2 - Reprobed

-- MAIN APPLICATION
addappid(1266700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266701, 1, "ae5c9073f56b7f287b657d279d00ea5f42df953b35a7a6da543a8f68fc51efdb")
addappid(1266702, 1, "b1d9a25d04e79436bcdcc0a8fba11bba11e549f70ef3aa1eccc724e0342b08e8")
addappid(2080852, 0, "e04e6d3dac96e79b745b5240c5998417fcd44e99aa82ecec82aa88854e537f1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2080850)
addappid(2080851)
