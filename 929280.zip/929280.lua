-- Lua provided by RyzenAPI
-- Game: 929280

-- MAIN APPLICATION
addappid(929280)
-- Game: addappid(929280)

-- MAIN APP DEPOTS / PACKAGES
addappid(929282,0,"bf78af3133f649ce53b6a745d1add9ca1c400927568fe48b657ea0775bdd9429")
