-- Lua provided by RyzenAPI
-- Game: Tiska Buska

-- MAIN APPLICATION
addappid(929280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(929282,0,"bf78af3133f649ce53b6a745d1add9ca1c400927568fe48b657ea0775bdd9429")

