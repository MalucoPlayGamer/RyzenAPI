-- Lua provided by RyzenAPI
-- Game: Game: Sakura Forest Girls 2

-- MAIN APPLICATION
addappid(1630490)
-- Game: addappid(1630490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630491, 1, "0a1916832c8a448ad1ea2fa78ca27ed11c5f6fbddc44c5d1d35cd0beb9c6f3a3")
