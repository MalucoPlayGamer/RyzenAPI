-- Lua provided by RyzenAPI
-- Game: AppID 2144850

-- MAIN APPLICATION
addappid(2144850)
-- Game: addappid(2144850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144851, 1, "678cdb5d36c47cf0954e7c4c22df4c920faa504020e3f2e4603ee41c814f7312")
