-- Lua provided by RyzenAPI
-- Game: 490910

-- MAIN APPLICATION
addappid(490910)
-- Game: addappid(490910)

-- MAIN APP DEPOTS / PACKAGES
addappid(490911, 1, "8d6240db8ec502b0cb8ffac0b5a2ae83c1aa6e9dde2f48289cc3ddfa34e0dc67")
addappid(490912, 1, "bef97621b226dbc588bddc9d262163415fa018feb3ab630a849b5f5dfa1bd854")
