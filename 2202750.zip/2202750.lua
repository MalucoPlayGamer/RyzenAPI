-- Lua provided by RyzenAPI 
-- Game: Hardhat Wombat
addappid(2202750)
addappid(2202751, 1, "91a5c82d1627c0f635c03c94bece1a69dbefdc8fa4f523d24c2484ab169f0e09")
