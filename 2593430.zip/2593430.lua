-- Lua provided by RyzenAPI
-- Game: 剑雨风云

-- MAIN APPLICATION
addappid(2593430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593431, 1, "e2291279a921dbbfad13bcca8534d2b3916c65cefd20be94216262cb685af2f0")

