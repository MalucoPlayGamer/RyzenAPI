-- Lua provided by RyzenAPI
-- Game: Game: Sidestep Legends

-- MAIN APPLICATION
addappid(2077590)
-- Game: addappid(2077590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077591, 1, "ba149a9fc6c4fdc6b5c1ca69772e489eda260f4c68ef11a45cfe760cf5bde621")
