-- Lua provided by RyzenAPI
-- Game: AppID 864040

-- MAIN APPLICATION
addappid(864040)
-- Game: addappid(864040)

-- MAIN APP DEPOTS / PACKAGES
addappid(864041, 1, "8e22cd08fb424b32ebdf6ac920f0af136899c742d58dd06a5ad264c374ccd4e3")
