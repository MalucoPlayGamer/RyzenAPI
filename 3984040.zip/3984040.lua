-- Lua provided by RyzenAPI
-- Game: SPEEDSHOT

-- MAIN APPLICATION
addappid(3984040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3984041,0,"dcbbf970f984d8b18f11c5d35c3ae12b6abd44dad7ae59e587f6a645525d6cbb")

