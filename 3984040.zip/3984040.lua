-- Lua provided by RyzenAPI
-- Game: SPEEDSHOT

-- MAIN APPLICATION
addappid(3984040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3984041,0,"dcbbf970f984d8b18f11c5d35c3ae12b6abd44dad7ae59e587f6a645525d6cbb")

