-- Lua provided by RyzenAPI
-- Game: Small Aircraft

-- MAIN APPLICATION
addappid(2609040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609041, 1, "1c0b84c3c47971f281cbb372722cdd67f9a138751862860220a79a1f4d363a44")
