-- Lua provided by RyzenAPI
-- Game: Meow Moments: Valentine's Day

-- MAIN APPLICATION
addappid(2810220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810221, 1, "2d0ccb195d5c844637ac268063d04681aa7a701a16c7a27249c9e7c2b9a5ca59")

