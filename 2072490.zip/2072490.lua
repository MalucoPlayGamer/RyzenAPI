-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy Generator - Armor Parts Set

-- MAIN APPLICATION
addappid(2072490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072490,0,"0a77d8e59804dd85e8a9baefef0a8a88032ba64983a619afbe6801db43426704")

