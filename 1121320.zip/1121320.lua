-- Lua provided by RyzenAPI
-- Game: Chains of Fury

-- MAIN APPLICATION
addappid(1121320)
-- Game: addappid(1121320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121321, 1, "6b7bd8761e45625e8a4142cf1d3b5a62939dbd51c15091be1e654c6a2894ebae")
addappid(1121322, 1, "2ef5675c620111e68925b8a8f1b2b7a53b12207abf3b8aebf9bb59490d8d639f")
