-- Lua provided by SkyAPI 
-- Game: One Line
addappid(1820690)
addappid(1820691, 1, "4ce30fda3a68d1ed9af2a8641aaf0dd3459d321af06977bb3932f7d9ea7edb28")
