-- Lua provided by RyzenAPI
-- Game: Game: Revenant

-- MAIN APPLICATION
addappid(2317510)
-- Game: addappid(2317510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317511, 1, "7d49514a871f6cee725a62107bb97363ade6523e1315e7864a63e446ec1cf988")
