-- Lua provided by RyzenAPI 
-- Game: AppID 974370
addappid(974370)
addappid(974371, 1, "27d4238ab4d464bb852f14179f003858c49416ab6818d63585af6f4f833b956f")
