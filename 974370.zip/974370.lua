-- Lua provided by RyzenAPI
-- Game: Chop is dish

-- MAIN APPLICATION
addappid(974370)

-- MAIN APP DEPOTS / PACKAGES
addappid(974371, 1, "27d4238ab4d464bb852f14179f003858c49416ab6818d63585af6f4f833b956f")

