-- Lua provided by RyzenAPI
-- Game: Game: Miraculous - Paris Under Siege

-- MAIN APPLICATION
addappid(2676410)
addappid(3097870)
-- Game: addappid(2676410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676411, 1, "0a3bcba17f0785ca95929768ed677a50924aceb0690eadbf383a0a3a6e0bf511")
