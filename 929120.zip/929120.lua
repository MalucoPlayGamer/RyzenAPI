-- Lua provided by RyzenAPI 
-- Game: Hop Step Sing! Nozokanaide Naked Heart (HQ Edition)
addappid(929120)
addappid(929121, 1, "5fe64c59b7129957abea35fc2a46e773bfe2ea4e7ccd1d64d94ee8d7fe820900")
addappid(929122, 1, "a98f9765c380f053046c27cc2b50b8a6be011cb5e061360db7c6e46dcd28f17c")
addappid(929123, 1, "c097c47d3b53c9d1e202422042b511211d1956a30a3d6810b6eac7f04d6d8e15")
