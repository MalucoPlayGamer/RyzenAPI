-- Lua provided by RyzenAPI
-- Game: Disney Speedstorm

-- MAIN APPLICATION
addappid(1537830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537831, 1, "c1ef1c4f38c2854785cf158e35515b5568ec2442e79ecbaae97b045391091e9b")
