-- Lua provided by RyzenAPI
-- Game: addappid(2709800)

-- MAIN APPLICATION
addappid(2709800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709801, 1, "9c573d0818fe29f2e238f787a4cd07c6e4a516d6afe56cbf0ec006c11967bfef")
addappid(2709802, 1, "33c3d494c5c1e4ba1bf8f8319fa119b725178de2c8967268bed1c054ce7b8d43")
