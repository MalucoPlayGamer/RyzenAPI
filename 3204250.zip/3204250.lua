-- Lua provided by RyzenAPI
-- Game: Game: Lost But Found

-- MAIN APPLICATION
addappid(3204250)
-- Game: addappid(3204250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204251, 1, "02f7ccd2d70fc07720713ec9b6050c50ab6cdc94da70f9d3bc957b7c1b8a3415")
addappid(3204252, 1, "7c474507298e54e35fa4f20cb6f55651b42b3fb8707d60f226b7f9ab64ad40df")
addappid(3204253, 1, "33e97ec1e5a5c3813b65bdc5061d915c3d0d533753c03cef89e2e926a266eceb")
