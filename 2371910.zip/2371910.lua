-- Lua provided by RyzenAPI
-- Game: Demon Command Token   御妖令

-- MAIN APPLICATION
addappid(2371910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371911, 1, "0c6b4751da2d71fd1129aae74270e381ea66cbc6290fd14d61cdaa5debf02333")

