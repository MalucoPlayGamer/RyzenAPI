-- Lua provided by RyzenAPI
-- Game: 2371910

-- MAIN APPLICATION
addappid(2371910)
-- Game: addappid(2371910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371911, 1, "0c6b4751da2d71fd1129aae74270e381ea66cbc6290fd14d61cdaa5debf02333")
