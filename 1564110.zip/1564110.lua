-- Lua provided by RyzenAPI
-- Game: Beside Myself

-- MAIN APPLICATION
addappid(1564110)
-- Game: addappid(1564110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564111, 1, "cb428960ccf85418ae7e450fb649f914af50688e45ce9d53dd815a7c297f30c4")
