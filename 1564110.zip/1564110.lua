-- Lua provided by RyzenAPI
-- Game: Beside Myself

-- MAIN APPLICATION
addappid(1564110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1564111, 1, "cb428960ccf85418ae7e450fb649f914af50688e45ce9d53dd815a7c297f30c4")

