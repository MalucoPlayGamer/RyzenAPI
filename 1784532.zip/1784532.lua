-- Lua provided by RyzenAPI
-- Game: 1784532

-- MAIN APPLICATION
addappid(1784532)
-- Game: addappid(1784532)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784532,0,"ebdd2cc662352c1bb08b1ee6a4973db44ef2ec27c4d70ed7666c46c73d0cfaf0")
