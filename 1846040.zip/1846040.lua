-- Lua provided by RyzenAPI
-- Game: 1846040

-- MAIN APPLICATION
addappid(1846040)
addappid(1847270)
-- Game: addappid(1846040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846041, 1, "fafd2489312bb199fa117c25a77d779ef20b14b71622ae7f5728d0544710f23f")
