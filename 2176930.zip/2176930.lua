-- Lua provided by RyzenAPI
-- Game: Trinity Trigger

-- MAIN APPLICATION
addappid(2176930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176931, 1, "1800444a46d123c7da7819c3197321658b365d7830382b5eca7b7bb33e4ea8ab")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2190050)
addappid(2190330)
addappid(2190331)
addappid(2190332)
addappid(2210350)
addappid(2210351)
addappid(2210352)
addappid(2210360)
addappid(2210370)
addappid(2210371)
addappid(2210372)
addappid(2210373)
addappid(2210374)
addappid(2210375)
addappid(2210376)
addappid(2210377)
addappid(2210378)
addappid(2210391)
