-- Lua provided by RyzenAPI
-- Game: Trinity Trigger

-- MAIN APPLICATION
addappid(2176930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176931, 1, "1800444a46d123c7da7819c3197321658b365d7830382b5eca7b7bb33e4ea8ab")
