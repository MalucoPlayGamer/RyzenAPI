-- Lua provided by RyzenAPI
-- Game: The Last Show of Mr. Chardish: Act I

-- MAIN APPLICATION
addappid(1397140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397141, 1, "06507bddd5d96de214f7396089437367f398417b38b9031b14e6f73745b45756")
