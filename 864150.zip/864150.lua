-- Lua provided by RyzenAPI
-- Game: Game: Feelin

-- MAIN APPLICATION
addappid(864150)
-- Game: addappid(864150)

-- MAIN APP DEPOTS / PACKAGES
addappid(864151, 1, "0791d268b1eef8676acbd5de9fb825b2010e6baec7cb490b2927f1b2380a67a0")
