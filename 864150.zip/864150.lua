-- Lua provided by SkyAPI 
-- Game: Feelin
addappid(864150)
addappid(864151, 1, "0791d268b1eef8676acbd5de9fb825b2010e6baec7cb490b2927f1b2380a67a0")
