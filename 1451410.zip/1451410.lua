-- Lua provided by SkyAPI 
-- Game: Watch Your Ride - Bicycle Game
addappid(1451410)
addappid(1451411, 1, "c18877fd945d42e863ed6e8eed271a206670023019aab323f3ca8f23d4450c52")
