-- Lua provided by RyzenAPI
-- Game: Leafing Home Demo

-- MAIN APPLICATION
addappid(3415160)
-- Game: addappid(3415160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415161, 1, "4b9ff58f71c7b23365efa482cee8b63c4536843db333b643fdc09449221e2fea")
