-- Lua provided by RyzenAPI
-- Game: addappid(3478200)

-- MAIN APPLICATION
addappid(3478200)
addappid(3668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478201, 1, "03bb32be6195269cf7e30a1f0ba4207cf42c817b2d0c70f7eb87e9529c0875a5")
