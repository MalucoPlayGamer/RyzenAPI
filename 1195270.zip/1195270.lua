-- Lua provided by RyzenAPI
-- Game: AppID 1195270

-- MAIN APPLICATION
addappid(1195270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195271, 1, "e7d73ddd5088af24977c0d9ea30687e6b6e66d91cad930c22ce954a6bccc7a79")

