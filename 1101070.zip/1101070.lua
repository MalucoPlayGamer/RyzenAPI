-- Lua provided by RyzenAPI
-- Game: 鬼哭岭：序

-- MAIN APPLICATION
addappid(1101070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101071, 1, "74d23ec4912df9dea8df75801ba949c19a386d1b4c2ef571d35c722f101a3a23")
