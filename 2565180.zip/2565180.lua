-- Lua provided by RyzenAPI
-- Game: Game: Sniper Wild West Shooting Simulator

-- MAIN APPLICATION
addappid(2565180)
-- Game: addappid(2565180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565181, 1, "6c35b313a04b2e5f7185c4940181a68a0ded12c640b17ecdb4658773401d860d")
