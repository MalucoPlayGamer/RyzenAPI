-- Lua provided by RyzenAPI
-- Game: Everseeker: Little Critters

-- MAIN APPLICATION
addappid(3105620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3105621, 1, "76597513785cae6297ff99f4bc53eb628184eb7975233925503fb663701e3158")

