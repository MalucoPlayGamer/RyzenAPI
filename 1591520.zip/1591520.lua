-- Lua provided by RyzenAPI 
-- Game: Clownfield 2042
addappid(1591520)
addappid(1591521, 1, "175b20df8d3d1ab31b36b4265328e0d4210d586bc817c54ad356da629e4c365d")
