-- Lua provided by RyzenAPI
-- Game: Game: Boom

-- MAIN APPLICATION
addappid(1519020)
-- Game: addappid(1519020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519021, 1, "254ebbe09a34f279ce6792f433f7dc843c13790f2b9e61073369f9496a8f6a3b")
