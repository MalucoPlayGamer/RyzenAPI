-- Lua provided by RyzenAPI
-- Game: Thymesia - Artbook

-- MAIN APPLICATION
addappid(2118360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118360,0,"837e400e70207d8424743048821b734c6bf2764bef515a95ad6a4e2ee4e236ea")
