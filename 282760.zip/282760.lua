-- Lua provided by RyzenAPI
-- Game: AppID 282760

-- MAIN APPLICATION
addappid(282760)

-- MAIN APP DEPOTS / PACKAGES
addappid(282761, 1, "1e5a3e598e6e9140711ac4623d9f3146b83348c371aace794ac572ce18c296ef")
addappid(282762, 1, "8a040c03277f732ba5b0c11c3649ee715f6d6f0b6a3c2d2fdafea964ca6707d1")
addappid(282763, 1, "ae324d2e744e121c9d51bf5687d8c959ef8ebca9091647c4d77a0fb370e048d0")
addappid(282764, 1, "9166aa3848cea7e73e355d82f2735884bdde757a69d9ff9947ac5ef98cb7343c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
