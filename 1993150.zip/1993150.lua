-- Lua provided by RyzenAPI
-- Game: 轮回修仙路

-- MAIN APPLICATION
addappid(1993150)
addappid(2397130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993151, 1, "0e57a3fafa5a7d7c47c90af3af199cad54b348aa13cdc672d15017310f078cfd")
addappid(2329850, 0, "eaf46355c5ed1beb1a98d7573ab3f205800cd0395598ac50918a8bc471a031f5")

