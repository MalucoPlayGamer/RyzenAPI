-- Lua provided by RyzenAPI
-- Game: Leaf on Wind

-- MAIN APPLICATION
addappid(1601040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601041, 1, "c5964c7d963fb26559532b3c2c3dc90bfc140301d18f03419c46afc1fb1bb9ed")
