-- Lua provided by RyzenAPI
-- Game: AppID 433800

-- MAIN APPLICATION
addappid(433800)
addappid(447260)
addappid(447261)
addappid(450530)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(433801, 1, "80569090ac606e45fd570d41a73fb6a1e1f5373d2cc9952346804b4121f1864a")
addappid(433802, 1, "0d867bdb02fee673d5c70238c0d550b817d385d7adf772e5a33a70f67eaf6156")

