-- Lua provided by RyzenAPI
-- Game: 音灵 INVAXION

-- MAIN APPLICATION
addappid(921630)
addappid(1057470)

-- MAIN APP DEPOTS / PACKAGES
addappid(921631, 1, "6729f5827cedc3036b1516f14d3f4037aae1ad9c908841e3cbbdf95814d7b743")
