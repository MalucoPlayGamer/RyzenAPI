-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Honmaru Backdrop "Sakura Viewing"

-- MAIN APPLICATION
addappid(1912030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912030,0,"5060aedbc1a51dc48a2327c7ff84b4793e8fe3f50e143b36c1a9415303854018")

