-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1634701)
-- Game: addappid(1634701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634701,0,"8ac5bc8173fc0b52e903685049d038784226e09e121fedadf884a9ac1f8bf94f")
