-- Lua provided by RyzenAPI
-- Game: Frog Legs

-- MAIN APPLICATION
addappid(1734110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734111, 1, "0c7d4bc1afa7cf00c77fd61276463e77777dfede9bbf4bbe9f7a49e4d21423b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
