-- Lua provided by RyzenAPI
-- Game: Frog Legs

-- MAIN APPLICATION
addappid(1734110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734111, 1, "0c7d4bc1afa7cf00c77fd61276463e77777dfede9bbf4bbe9f7a49e4d21423b0")
