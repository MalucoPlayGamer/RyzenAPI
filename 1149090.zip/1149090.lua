-- Lua provided by RyzenAPI
-- Game: AppID 1149090

-- MAIN APPLICATION
addappid(1149090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149091, 1, "abbc8d51a536623bb38407c330caeae3a824a2a31dd4edcfa0d7bdc68813ba07")

