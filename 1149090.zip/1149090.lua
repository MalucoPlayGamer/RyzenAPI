-- Lua provided by RyzenAPI
-- Game: AppID 1149090

-- MAIN APPLICATION
addappid(1149090)
addappid(1193360)
addappid(1417100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1149091, 1, "abbc8d51a536623bb38407c330caeae3a824a2a31dd4edcfa0d7bdc68813ba07")

