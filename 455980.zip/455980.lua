-- Lua provided by RyzenAPI 
-- Game: Judgment: Apocalypse Survival Simulation
addappid(455980)
addappid(455981, 1, "eb54498c1b128d1b461a3bba5d371b2ccaf4041047b09b9f23b30092d6fb7797")
addappid(455983, 1, "41c1f346961e1fce7c5bd38c01f3cc32b5571695de6f35ea5e7a4a988793788e")
addappid(1089940, 0, "49f747b3c352b07fac5f5022f7da3f4be815d0d5544c98a4c1ba251f211baa12")
addappid(2416090, 0, "dab170e14b8e65c637130482643dc212718db62491cf343dac965fea87557c1b")
