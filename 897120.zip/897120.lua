-- Lua provided by RyzenAPI
-- Game: 897120

-- MAIN APPLICATION
addappid(897120)
-- Game: addappid(897120)

-- MAIN APP DEPOTS / PACKAGES
addappid(897121, 1, "1efef32e7c295c6230d3f8546e917de46528b2ddb8154c846664960c3650872a")
