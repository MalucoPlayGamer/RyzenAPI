-- Lua provided by RyzenAPI
-- Game: Moko's Advice

-- MAIN APPLICATION
addappid(897120)
addappid(1201080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(897121, 1, "1efef32e7c295c6230d3f8546e917de46528b2ddb8154c846664960c3650872a")
