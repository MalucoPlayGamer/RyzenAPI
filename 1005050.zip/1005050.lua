-- Lua provided by RyzenAPI
-- Game: Fabulous - Angela's True Colors

-- MAIN APPLICATION
addappid(1005050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005051, 1, "31019ef36be1ab093ac61147a6b34795fedab10fe5b3b6276e8739b197d4b053")
