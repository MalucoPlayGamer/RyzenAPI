-- Lua provided by RyzenAPI
-- Game: Game: Lunaria Fantasia

-- MAIN APPLICATION
addappid(2952680)
-- Game: addappid(2952680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952681, 1, "5ec2103385f0865ade17ea24c43f68a97423b8e766a900dc0509184c4047bf98")
addappid(2952682, 1, "28a1e629064ac445c5d75d35b4411d30577ec3d10c4b96d32aa7c766fdc1a7e0")
