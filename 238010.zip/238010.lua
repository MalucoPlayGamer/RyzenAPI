-- Lua provided by RyzenAPI
-- Game: Game: Deus Ex: Human Revolution - Director's Cut

-- MAIN APPLICATION
addappid(238010)
-- Game: addappid(238010)

-- MAIN APP DEPOTS / PACKAGES
addappid(238011, 1, "77b8344b13ff87aaf6428bc74a3ff31986da71e196ae08c110464feaf6cb43cb")
addappid(238012, 1, "04bb72cec5a63bdf85a1cd66d39ea48499379927bdf3d16fc2e3ab3a9657d221")
addappid(238013, 1, "c8da26f2da72d03d9d5adac2dc121e738e3dba289b43926570c169e27c5013d4")
addappid(238014, 1, "77a78c14464e7730d1990f41f8616e0c294a01774e9948d8f3a113c52dee92a3")
addappid(238015, 1, "d02d91e9ba728652a8b07b909f4003f4e773abd25976f89b54e892a12e378035")
addappid(238016, 1, "268ad66215be09a611143ecf36a43d8cbd039aeb9bda62176000d370968cad6c")
addappid(238017, 1, "426c69e6eaf4fdeeeb5ffac1dbdcbcdf93edfe9b8917f32e8872750dffe2bd6e")
addappid(238018, 1, "35bb79abc3db5defff315a1789fae73268e8d803c8438d2d91f279ffcbc33bef")
addappid(238019, 1, "c24f371c9f4a32a0dc2f96c4fea5a7c102704ff0a76d2e782e75f6c6332c28ad")
