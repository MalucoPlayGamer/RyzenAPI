-- Lua provided by RyzenAPI
-- Game: 1956630

-- MAIN APPLICATION
addappid(1956630)
-- Game: addappid(1956630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956631, 1, "4730cb23289f384b7869bd49b311cd217da20d40bb4ba14a64186ebfbb79d1f8")
