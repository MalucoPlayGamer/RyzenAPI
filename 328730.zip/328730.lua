-- Lua provided by RyzenAPI 
-- Game: Letter Quest: Grimm's Journey
addappid(328730)
addappid(328731, 1, "6d6bf40403b167ede287e03dc389236c501b107ec8bd42ea734bc92922a673d8")
addappid(328732, 1, "195c14d60b899e2b57db5bce0b042911682f690d96e57dbc7e6ca270bd8b165b")
addappid(328733, 1, "216f4293b49292f43ef03f7a8b92bd850eb83c9cda9624b746615c21bad982e1")
addappid(328734, 1, "fb7708207365d1bd96e7721bb672b1a5f120ccd20906c905079fb897bae9ddc3")
