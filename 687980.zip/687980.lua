-- Lua provided by RyzenAPI
-- Game: Mothlight

-- MAIN APPLICATION
addappid(687980)
-- Game: addappid(687980)

-- MAIN APP DEPOTS / PACKAGES
addappid(687981, 1, "14650f79146c363d55ab3d83c048614389ed8540ea6b2e21ea154abe8b9dc172")
