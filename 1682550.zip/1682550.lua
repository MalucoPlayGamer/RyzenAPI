-- Lua provided by SkyAPI 
-- Game: Lost and found - What if I come and find it
addappid(1682550)
addappid(1682551, 1, "5215d9d43a8ebf5d0c878aef2dd932a07e9e1a5cc4db99f859fa389c40da5f36")
