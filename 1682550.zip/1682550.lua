-- Lua provided by RyzenAPI
-- Game: Game: Lost and found - What if I come and find it

-- MAIN APPLICATION
addappid(1682550)
-- Game: addappid(1682550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682551, 1, "5215d9d43a8ebf5d0c878aef2dd932a07e9e1a5cc4db99f859fa389c40da5f36")
