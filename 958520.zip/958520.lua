-- 958520's Lua and Manifest Created by Hubcap Manifest
-- 33 Immortals
-- Created: June 10, 2026 at 14:07:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 11

-- MAIN APPLICATION
addappid(958520, 1, "64d32111db9f3a8fffc504cb5c125a3bd0584b4841035cda824e54d71425a396") -- 33 Immortals
-- MAIN APP DEPOTS
addappid(958521, 1, "3b3e825494da5eba01605e1254ce18163cd4c7553d18ac5ade63a4c629185faa") -- Depot 958521
setManifestid(958521, "213397335906484220", 3267737766)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4715780) -- 33 Immortals - Eminent Elephant Pack
addappid(4715790) -- 33 Immortals - Chill Capybara Pack
addappid(4715800) -- 33 Immortals  Immortal Menagerie Pack
addappid(4716390) -- 33 Immortals  Supporters Pack
addappid(4716400) -- 33 Immortals - Turbulent Winds Pack
addappid(4716410) -- 33 Immortals - Mighty Quakes Pack
addappid(4716420) -- 33 Immortals - Infernal Flames Pack
addappid(4716430) -- 33 Immortals - Fierce Tides Pack
addappid(4716440) -- 33 Immortals - Good Luck Pack
addappid(4716560) -- 33 Immortals - Ill Omens Pack
addappid(4720220) -- 33 Immortals - Chromatic Chameleon Pack