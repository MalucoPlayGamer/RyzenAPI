-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1458154)
addappid(1537221)
addappid(1537222)
addappid(1537223)
addappid(1537224)
addappid(1537225)
addappid(1537226)
addappid(1537227)
addappid(1537228)
addappid(1537229)
addappid(1537230)
addappid(1537231)
addappid(1537233)
addappid(1537234)
addappid(1537235)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458154,0,"1f5f1d7fe28998b617b0ded5ffb4109f351d21639f8d42e39a42da120373fed5")
addappid(1537220,0,"56f6ce4b3b5656442126cba84cf9a0f37b0a7da222949ab788372b6708b30c40")
addappid(1537232,0,"9372b056edcdcfd57b79c53004bb9a4c09f1be8199a81459c8360d7bb278b162")
addappid(1537236,0,"088fd4d57fabd6fedc31b967d1d43bf610d389a7c427a662c843cb580a1d18f1")
addappid(1537237,0,"c51f486a7fbe8e1fe7d12315119af498fa42cd7a5a8ae903d2ea9c0cf3d34fca")

