-- Lua provided by RyzenAPI
-- Game: Nightingale

-- MAIN APPLICATION
addappid(1928980)
addappid(2834900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928981, 1, "9e9e27b584625ef587f734aed79c2eb91a692a977394c7b37b2198d5fb40122c")

