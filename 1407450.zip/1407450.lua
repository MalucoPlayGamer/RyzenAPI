-- Lua provided by RyzenAPI
-- Game: The World of Kungfu: Dragon and Eagle

-- MAIN APPLICATION
addappid(1407450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407451, 1, "e77c2b5425b6c805511e3c7765549c490def944d6408b724c7f5e5296618e42c")
addappid(1407452, 1, "f34851dd40298961c2625dd380b7a365558b0824159a15b0c7eda39026cd9c42")

