-- Lua provided by RyzenAPI
-- Game: addappid(2680250)

-- MAIN APPLICATION
addappid(2680250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680251, 1, "bb009d20596bdb8346541b7d2d18f734ec4fcad3accf7debe9629cdf8e8877cf")
