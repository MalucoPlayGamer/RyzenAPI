-- Lua provided by RyzenAPI
-- Game: Holy Maid Academy

-- MAIN APPLICATION
addappid(2680250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680251, 1, "bb009d20596bdb8346541b7d2d18f734ec4fcad3accf7debe9629cdf8e8877cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
