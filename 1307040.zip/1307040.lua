-- Lua provided by RyzenAPI
-- Game: AppID 1307040

-- MAIN APPLICATION
addappid(1307040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307041, 1, "d45ee9fefea7e756b1bfa343f9d13a305152efc1f34997567aee18ed484ce058")

