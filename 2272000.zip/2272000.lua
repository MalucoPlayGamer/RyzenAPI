-- Lua provided by RyzenAPI
-- Game: 玛娜指南 Demo

-- MAIN APPLICATION
addappid(2272000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272001, 1, "9e2547f1f1e0fb3ee6052d5511d9602caceb4319b2cac59c5b7d1658050d7696")

