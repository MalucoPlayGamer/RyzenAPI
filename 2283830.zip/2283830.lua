-- Lua provided by RyzenAPI
-- Game: Game: Raw Metal Demo

-- MAIN APPLICATION
addappid(2283830)
-- Game: addappid(2283830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283831, 1, "9b29d8eae23d8bd3502cda80e6d3770cf12e9c8970596d14c0d29bca64e32c7d")
