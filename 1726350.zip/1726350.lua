-- Lua provided by RyzenAPI
-- Game: 夜詛-YASO- Demo

-- MAIN APPLICATION
addappid(1726350)
-- Game: addappid(1726350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726351, 1, "92d1dffaeb6dd82a69722316c0fdc291ce4069a6fa96e891814cc04ecea866fd")
