-- Lua provided by RyzenAPI
-- Game: STRETCHER MEN

-- MAIN APPLICATION
addappid(2884650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884651, 1, "dc26307acf43372560a41c67f5b684576923d6fa7a466a7ee9816eebe9e96669")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
