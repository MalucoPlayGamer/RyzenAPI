-- Lua provided by RyzenAPI
-- Game: Game: STRETCHER MEN

-- MAIN APPLICATION
addappid(2884650)
-- Game: addappid(2884650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884651, 1, "dc26307acf43372560a41c67f5b684576923d6fa7a466a7ee9816eebe9e96669")
