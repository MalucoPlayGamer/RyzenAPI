-- Lua provided by RyzenAPI
-- Game: 1268220

-- MAIN APPLICATION
addappid(1268220)
-- Game: addappid(1268220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268221, 1, "fea3fd642557ce32ad1d6a146892de427c3df0808425eaf7db31add2db7f1a38")
