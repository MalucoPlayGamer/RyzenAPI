-- Lua provided by RyzenAPI
-- Game: Game: Override: Mech City Brawl

-- MAIN APPLICATION
addappid(709440)
-- Game: addappid(709440)

-- MAIN APP DEPOTS / PACKAGES
addappid(709441, 1, "977342e99393747c53048c5e402dc2bc90f6792f9abc917341fd0677ad75ed5c")
