-- Lua provided by RyzenAPI
-- Game: Override: Mech City Brawl

-- MAIN APPLICATION
addappid(709440)

-- MAIN APP DEPOTS / PACKAGES
addappid(709441, 1, "977342e99393747c53048c5e402dc2bc90f6792f9abc917341fd0677ad75ed5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(966840)
addappid(966841)
addappid(966842)
addappid(966843)
addappid(966844)
addappid(966845)
addappid(970170)
