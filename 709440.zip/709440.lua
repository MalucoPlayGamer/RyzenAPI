-- Lua provided by SkyAPI 
-- Game: Override: Mech City Brawl
addappid(709440)
addappid(709441, 1, "977342e99393747c53048c5e402dc2bc90f6792f9abc917341fd0677ad75ed5c")
