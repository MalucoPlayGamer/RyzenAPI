-- Lua provided by RyzenAPI
-- Game: Westard

-- MAIN APPLICATION
addappid(576950)
-- Game: addappid(576950)

-- MAIN APP DEPOTS / PACKAGES
addappid(576951, 1, "a4616ade55fe50d1ed5b2516b0cfc82eff02a08bef918207cd77ea6032a27cd4")
