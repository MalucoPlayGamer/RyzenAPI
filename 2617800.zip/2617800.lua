-- Lua provided by RyzenAPI
-- Game: Desktop Tourney World

-- MAIN APPLICATION
addappid(2617800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617801, 1, "f2800c56e02af2c0763ba40f02fae1a9501bb7ab8fb9e9c6578c81e2faf2dd7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
