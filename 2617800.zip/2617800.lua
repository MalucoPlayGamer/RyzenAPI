-- Lua provided by RyzenAPI
-- Game: Desktop Tourney World

-- MAIN APPLICATION
addappid(2617800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617801, 1, "f2800c56e02af2c0763ba40f02fae1a9501bb7ab8fb9e9c6578c81e2faf2dd7b")

