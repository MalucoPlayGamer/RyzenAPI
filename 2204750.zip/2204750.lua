-- Lua provided by RyzenAPI
-- Game: Happy Town

-- MAIN APPLICATION
addappid(2204750)
-- Game: addappid(2204750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204751, 1, "a2dd35eddec4521de32a52ef4a402dbf3e0812ca2981dfcbb31c41b8c5c70cf9")
addappid(2204752, 1, "5c567826604c2a3ac0c1253f16f908a7620d10541771454e377f0204e6e6ed0c")
addappid(2204754, 1, "b0488a9959fa97689f2a57c803a4065d6f4f5b9d997ef54ecd8d3ebea5310db0")
