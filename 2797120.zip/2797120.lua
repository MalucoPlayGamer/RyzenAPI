-- Lua provided by RyzenAPI
-- Game: Zero's Fantastic Anecdote

-- MAIN APPLICATION
addappid(2797120)
-- Game: addappid(2797120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797121, 1, "38dc1cd5d9db00d3a8ac81b439ec801c1ee7cab862bbee28ee1f6fdcdc96fa1e")
addappid(2797122, 1, "986ab77a876fd19f07bdb8bf593d6d9857c40572d43b61ca661c1fb2436ebe32")
addappid(2797123, 1, "3c28b756d21f322df43aebe80e25e69c21f3daedc4a8139eb2912f9c4168bb53")
addappid(2797124, 1, "c6a6325b071ee8a5ba789e0e6cbda488ba423b431b9619d60b46216fc3520101")
addappid(2797125, 1, "f9abcdeb5b40b1da42d33eea27f9a2b47afc5e7cfa93e4253cdebd17ab99abb0")
addappid(2797126, 1, "8b4b31ad3f425d7ffd17a3b6a1810a2cfc66f3614ceb9dce5b79ed117aa6b946")
addappid(2797127, 1, "61aed370e544afd1255731a35ff54bdd6c2409e95cd5ae312b89b14c461934c1")
