-- Lua provided by SkyAPI 
-- Game: Imagine Earth Soundtrack
addappid(1640330)
addappid(1640331, 1, "12f2929a5a0485e4823304b10f2da5ed56310b7147510181c61839bea47314f8")
addappid(1640332, 1, "e3b200496286291d31459f4c5ee3332b302ff84958a960b253b41a31e888b54b")
