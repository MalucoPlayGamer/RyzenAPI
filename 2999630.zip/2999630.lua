-- Lua provided by RyzenAPI
-- Game: 2999630

-- MAIN APPLICATION
addappid(2999630)
-- Game: addappid(2999630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999630,0,"b7dd710afb9dcb1e0106c84e2354771188f530aa7da4260f05281dda109f69c3")
