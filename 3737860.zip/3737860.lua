-- Lua provided by RyzenAPI
-- Game: 3737860

-- MAIN APPLICATION
addappid(3737860)
-- Game: addappid(3737860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737862,0,"77f03721a72fe04b8266f20dfa7b80b8f659d5c49abeb33e15776f1ee7019c71")
