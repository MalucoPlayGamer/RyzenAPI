-- Lua provided by RyzenAPI
-- Game: Tales of Arise Demo

-- MAIN APPLICATION
addappid(1458040)
-- Game: addappid(1458040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458041, 1, "e936a01a83a236dafed9559f83850737aa5017328e1881d647120404554cd847")
