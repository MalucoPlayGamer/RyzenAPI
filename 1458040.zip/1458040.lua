-- Lua provided by RyzenAPI 
-- Game: Tales of Arise Demo
addappid(1458040)
addappid(1458041, 1, "e936a01a83a236dafed9559f83850737aa5017328e1881d647120404554cd847")
