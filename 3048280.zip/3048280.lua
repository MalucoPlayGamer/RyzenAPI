-- Lua provided by RyzenAPI
-- Game: Realistic Ragdoll Sandbox

-- MAIN APPLICATION
addappid(3048280)
-- Game: addappid(3048280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048281, 1, "4c6dfc73dd4bc4e4bea567490a70390e025d43a85b8b98c910ae5e2e3b8ca060")
