-- Lua provided by RyzenAPI
-- Game: Battery Jam

-- MAIN APPLICATION
addappid(751330)

-- MAIN APP DEPOTS / PACKAGES
addappid(751331,0,"eeb128bd2094d51eb84851675272171c4cc0fee5cfc13e12da67113ac32075a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
