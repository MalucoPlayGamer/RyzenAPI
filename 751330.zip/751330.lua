-- Lua provided by RyzenAPI
-- Game: Battery Jam

-- MAIN APPLICATION
addappid(751330)

-- MAIN APP DEPOTS / PACKAGES
addappid(751331,0,"eeb128bd2094d51eb84851675272171c4cc0fee5cfc13e12da67113ac32075a6")

