-- Lua provided by RyzenAPI
-- Game: 1967940

-- MAIN APPLICATION
addappid(1967940)
-- Game: addappid(1967940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967941, 1, "53b8f9e73703c2b742373adad18ccc928f1d83ada366c25d6cbe55cc2366baeb")
