-- Lua provided by RyzenAPI
-- Game: Red Orchestra: Ostfront 41-45

-- MAIN APPLICATION
addappid(1213)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211,0,"86e656533389ea5d8559926e793e70d1bb363972411e4f2a704010db80937299")
addappid(1213,0,"3b1fbe3f49b301f44b746f5b1e0636dcef339e83fde6b3e96a3530972f0fce08")

