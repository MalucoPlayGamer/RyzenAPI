-- Lua provided by RyzenAPI 
-- Game: AppID 1360190
addappid(1360190)
addappid(1360191, 1, "70f1ecf6d201a437ef80a1eeda5490afd5998a4320f2a16ede4dc22f718ed02e")
