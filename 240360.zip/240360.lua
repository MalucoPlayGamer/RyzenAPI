-- Lua provided by RyzenAPI
-- Game: 240360

-- MAIN APPLICATION
addappid(240360)
-- Game: addappid(240360)

-- MAIN APP DEPOTS / PACKAGES
addappid(240361, 1, "dc52a91c63cc9455a9f1069c35b3ac04a013cf11f5428acb7f50b7ec45804bf1")
