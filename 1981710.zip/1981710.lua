-- Lua provided by RyzenAPI
-- Game: addappid(1981710)

-- MAIN APPLICATION
addappid(1981710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981711, 1, "abf0b018bcde0f01f5f5295554e9bfdd6262aaad0c24ba730537b1eba77394f2")
