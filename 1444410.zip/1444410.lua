-- Lua provided by RyzenAPI
-- Game: Game: Yuoni

-- MAIN APPLICATION
addappid(1444410)
-- Game: addappid(1444410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444411, 1, "44a4fcfb6bc53449c92863e8962ea5db799aec0e3d2bee34f150995ed8d92066")
