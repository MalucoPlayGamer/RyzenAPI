-- Lua provided by SkyAPI 
-- Game: Tomb Raider: Underworld Demo
addappid(8150)
addappid(8151, 1, "1832e952b6bf138da00b25fc8ef3c09d9de599f8bd6ea09698c3d901df2aee0b")
