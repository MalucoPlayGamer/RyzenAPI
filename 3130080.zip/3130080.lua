-- Lua provided by RyzenAPI
-- Game: addappid(3130080)

-- MAIN APPLICATION
addappid(3130080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130082,0,"758bb4cc38af1cf2f86f444127d98bb8ceb0f82f81ed2bb1eabf9df17b00da8b")
addappid(3130083,0,"885343ba39da535d72c361788b0ce6970f153ad76eb995a99b40c5194eb0db5f")
