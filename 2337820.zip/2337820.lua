-- Lua provided by RyzenAPI
-- Game: The Crush House

-- MAIN APPLICATION
addappid(2337820)
-- Game: addappid(2337820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337821, 1, "5e4b2d6aaedb6898f0af02cc4dc5db2338f62eedefb9453c1b4c3a065fec25a3")
