-- Lua provided by RyzenAPI
-- Game: de Blob

-- MAIN APPLICATION
addappid(532320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(532321, 1, "fbba3fa7002cb8c8ce32cd9d80309e3bc28abf4985b6362cdb7580eeae1b7697")
addappid(532322, 1, "24bb46608a7efdd6316890dcc24b6120fd5c0f2de2845a83b43f71a795b2275b")

