-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1521220)
addappid(1521221)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463731,0,"c00a48b71c7c00d06fe96b909556f2520f6be02d510185f80e18609226160737")
