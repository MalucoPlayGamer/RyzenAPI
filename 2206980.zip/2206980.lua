-- Lua provided by RyzenAPI
-- Game: 與魔共舞

-- MAIN APPLICATION
addappid(2206980)
-- Game: addappid(2206980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206981, 1, "1dbda38b688c793229de51b1488502efe6ebd326731901b64eb5d9b505a11b16")
