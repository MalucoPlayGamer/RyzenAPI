-- Lua provided by RyzenAPI 
-- Game: ViRo Playspace
addappid(1121310)
addappid(1121311, 1, "d5750daabef7d08a7cd01d4bbf3c09c2917c695d8ad69c64b9837c96ef30ba2e")
