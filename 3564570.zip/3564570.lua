-- Lua provided by RyzenAPI
-- Game: Game: MazeSlug

-- MAIN APPLICATION
addappid(3564570)
-- Game: addappid(3564570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564571, 1, "dd51770c7709925a4ca7f1981c6fd747fb36db5208abc848ecb330a0345033f6")
