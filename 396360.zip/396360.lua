-- Lua provided by RyzenAPI
-- Game: LocoSoccer Classic

-- MAIN APPLICATION
addappid(396360)

-- MAIN APP DEPOTS / PACKAGES
addappid(396361, 1, "89a11381e8861cf1c7f35c973c965fe9ebbfef36e6d02b31ec07dfc5a4120c95")
addappid(396362, 1, "7716aa4f77868b6f11ef39861b8fc31772247326a086d7afc84dd8c4ab594b08")
