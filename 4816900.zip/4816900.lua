-- Lua provided by RyzenAPI
-- Game: Keypress Express

-- MAIN APPLICATION
addappid(4816900)

