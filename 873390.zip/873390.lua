-- Lua provided by RyzenAPI
-- Game: Celestial Hacker Girl Jessica

-- MAIN APPLICATION
addappid(873390)

-- MAIN APP DEPOTS / PACKAGES
addappid(873391, 1, "aa883a9c5656a13871f6fc12e7864505595bbf14dad0257307f6571226d9a6e8")

