-- Lua provided by SkyAPI 
-- Game: AppID 873390
addappid(873390)
addappid(873391, 1, "aa883a9c5656a13871f6fc12e7864505595bbf14dad0257307f6571226d9a6e8")
