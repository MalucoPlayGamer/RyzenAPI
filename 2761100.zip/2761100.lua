-- Lua provided by RyzenAPI 
-- Game: Pomberito
addappid(2761100)
addappid(2761101, 1, "a967e587eeab84dcab4295c761a05f67ac157505f6b222fb174fa624355529b9")
