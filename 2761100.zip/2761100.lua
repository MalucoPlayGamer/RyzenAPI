-- Lua provided by RyzenAPI
-- Game: addappid(2761100)

-- MAIN APPLICATION
addappid(2761100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761101, 1, "a967e587eeab84dcab4295c761a05f67ac157505f6b222fb174fa624355529b9")
