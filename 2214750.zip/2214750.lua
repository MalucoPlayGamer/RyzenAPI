-- Lua provided by RyzenAPI
-- Game: Primal Age

-- MAIN APPLICATION
addappid(2214750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214751, 1, "6062eee2d19b55e8624dca063ae6a564e79f353fba860b0dc7ad4c8d8500b6e8")
