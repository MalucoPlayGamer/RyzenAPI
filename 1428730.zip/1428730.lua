-- Lua provided by RyzenAPI 
-- Game: BRoS - Battle Royale of Survival
addappid(1428730)
addappid(1428731, 1, "a218348f920cce348eb0a82ca9380bb28bde69127c5b90b6877d51bc0f3d7d6e")
