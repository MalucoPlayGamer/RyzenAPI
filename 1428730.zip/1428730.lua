-- Lua provided by RyzenAPI
-- Game: 1428730

-- MAIN APPLICATION
addappid(1428730)
-- Game: addappid(1428730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428731, 1, "a218348f920cce348eb0a82ca9380bb28bde69127c5b90b6877d51bc0f3d7d6e")
