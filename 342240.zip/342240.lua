-- Lua provided by RyzenAPI
-- Game: addappid(342240)

-- MAIN APPLICATION
addappid(342240)
addappid(349660)

-- MAIN APP DEPOTS / PACKAGES
addappid(342241, 1, "a397538d1d765c8b8064ded4c2d508d67c604b9d03a1457d5b2a7037dcd04383")
