-- Lua provided by RyzenAPI
-- Game: Starship

-- MAIN APPLICATION
addappid(793060)

-- MAIN APP DEPOTS / PACKAGES
addappid(793061,0,"10a406c1abb7f95743996c368fa88c73ee06e898d785925d591106e412f7b76b")

