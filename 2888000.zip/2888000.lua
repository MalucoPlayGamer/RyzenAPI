-- Lua provided by RyzenAPI
-- Game: Game: AppID 2888000

-- MAIN APPLICATION
addappid(2888000)
-- Game: addappid(2888000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888001, 1, "4665f5185bb51104e01da1f5ef0286d9c1c42fab5e5a8813944d8529de248d6c")
