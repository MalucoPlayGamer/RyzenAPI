-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2003680)
-- Game: addappid(2003680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003680,0,"491d189a245a85c406ee71ff46b421542688d34fa12c680da2d0613b8652d8f2")
