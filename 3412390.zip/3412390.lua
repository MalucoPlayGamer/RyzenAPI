-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3412390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3412390,0,"37e17674a05b51d07bbd80281c5d2d375fd403c39f888e847d32366b1bd099a6")

