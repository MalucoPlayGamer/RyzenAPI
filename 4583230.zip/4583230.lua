-- 4583230's Lua and Manifest Created by Hubcap Manifest
-- Harvest Dice Profit
-- Created: July 24, 2026 at 06:09:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4583230) -- Harvest Dice Profit
-- MAIN APP DEPOTS
addappid(4583231, 1, "a60224b96c3abd49b85f32b7abe31dbbef1b73e34e8fa607ffcdc2c5b0f29bbf") -- Depot 4583231
setManifestid(4583231, "5255384094007766473", 981415698)