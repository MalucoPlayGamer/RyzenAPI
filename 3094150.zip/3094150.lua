-- Lua provided by RyzenAPI
-- Game: Take Notes

-- MAIN APPLICATION
addappid(3094150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094151, 1, "bcd498e2fcd87326de7f1524d2fa84d6b14623b322ffdc6fb685f180e7add747")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
