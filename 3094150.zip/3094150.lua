-- Lua provided by RyzenAPI
-- Game: Game: Take Notes

-- MAIN APPLICATION
addappid(3094150)
-- Game: addappid(3094150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094151, 1, "bcd498e2fcd87326de7f1524d2fa84d6b14623b322ffdc6fb685f180e7add747")
