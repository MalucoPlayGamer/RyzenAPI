-- Lua provided by SkyAPI 
-- Game: Take Notes
addappid(3094150)
addappid(3094151, 1, "bcd498e2fcd87326de7f1524d2fa84d6b14623b322ffdc6fb685f180e7add747")
