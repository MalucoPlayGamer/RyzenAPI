-- Lua provided by RyzenAPI
-- Game: 1125240

-- MAIN APPLICATION
addappid(1125240)
-- Game: addappid(1125240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125241, 1, "1bfcf656f87f970028487f832ba08b3131dd9c57882e261e9e8585a9cd84ccd5")
