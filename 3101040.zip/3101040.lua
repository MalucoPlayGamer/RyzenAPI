-- Lua provided by RyzenAPI
-- Game: Magical Girl Witch Trials

-- MAIN APPLICATION
addappid(3101040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101041, 1, "bc30bed29c59a3d5f0fd1ce9ec95897294403c5f89f2eb2cb08b903cf872246a")
