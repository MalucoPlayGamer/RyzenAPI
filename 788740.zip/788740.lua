-- Lua provided by RyzenAPI
-- Game: 788740

-- MAIN APPLICATION
addappid(788740)
-- Game: addappid(788740)

-- MAIN APP DEPOTS / PACKAGES
addappid(788741, 1, "fc1c46ae3db95fd86f6c6e92e70783e61321a74231e7faedf7013cf2a258d263")
