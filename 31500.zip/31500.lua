-- Lua provided by RyzenAPI
-- Game: Game: COIL

-- MAIN APPLICATION
addappid(31500)
-- Game: addappid(31500)

-- MAIN APP DEPOTS / PACKAGES
addappid(31501, 1, "02c2517c9dbd340b5342f0c423c433f59497b86604d7dd828ad46c7b631c62a7")
