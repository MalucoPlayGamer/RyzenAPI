-- Lua provided by RyzenAPI 
-- Game: Blood Memery|血色记忆
addappid(1021850)
addappid(1021851, 1, "8f0a84141feb327124c14499ee3763aff04f747578edb1e0aff67c2e0975da62")
addappid(1038060, 0, "fc537d9243bf5877d1f4857c5ccb26a505df868b7bd37e0e28ebf538d05191d0")
