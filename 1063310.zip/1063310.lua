-- Lua provided by RyzenAPI 
-- Game: Vane
addappid(1063310)
addappid(1063311, 1, "e0a78b74d46a3d494a646745509d5b15ba3e1bc1ac506e6a808c7ac0107755bd")
addappid(1063480)
