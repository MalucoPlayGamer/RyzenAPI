-- Lua provided by RyzenAPI
-- Game: AppID 933920

-- MAIN APPLICATION
addappid(933920)

-- MAIN APP DEPOTS / PACKAGES
addappid(933921, 1, "7a87e21ad9e8fcc52e63443f4ded9720f7218d470dac194b885925e6b0cc92fd")

