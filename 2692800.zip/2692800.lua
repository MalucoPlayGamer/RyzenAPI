-- Lua provided by RyzenAPI 
-- Game: I Love You Freddy
addappid(2692800)
addappid(2692801, 1, "3e742ad9817d5639688e748ac5877ffb78ef2685cc837a6478e10f36db7c1ca7")
