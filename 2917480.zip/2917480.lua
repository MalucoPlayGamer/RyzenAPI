-- Lua provided by RyzenAPI
-- Game: addappid(2917480)

-- MAIN APPLICATION
addappid(2917480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917481, 1, "c9c58f200e7f0d0190bc66af096afb30a3b5be64788cc11697e621a3013c30fb")
