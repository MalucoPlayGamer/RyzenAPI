-- Lua provided by RyzenAPI
-- Game: addappid(2663160)

-- MAIN APPLICATION
addappid(2663160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663161, 1, "2177f539d4c780a319a4f9474645b6dcba51a736bd84d72c20c1d6db7352d360")
