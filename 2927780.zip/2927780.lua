-- Lua provided by RyzenAPI
-- Game: Last Outpost

-- MAIN APPLICATION
addappid(2927780)
-- Game: addappid(2927780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927781, 1, "2f80066bc2ec65724f707d1bac4cfa8c63355e03a969f77b06891f789c8bc55a")
