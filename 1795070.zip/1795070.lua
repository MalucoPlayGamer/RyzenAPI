-- Lua provided by RyzenAPI
-- Game: addappid(1795070)

-- MAIN APPLICATION
addappid(1795070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795071, 1, "3eb35a0f16faae43c2e5c36f00c97aa7024daba30b1cd107d627d36781e15c3c")
