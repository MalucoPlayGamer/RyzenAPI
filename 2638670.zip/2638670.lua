-- Lua provided by RyzenAPI
-- Game: Game: Temple Guy - Quest for chest

-- MAIN APPLICATION
addappid(2638670)
-- Game: addappid(2638670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638671, 1, "24463d171c1ce4523b96ffac0fa72afaecfe2fa3a8b77854579138a521408ec0")
