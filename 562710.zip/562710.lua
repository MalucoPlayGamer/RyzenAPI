-- Lua provided by RyzenAPI
-- Game: Western Adventure

-- MAIN APPLICATION
addappid(562710)

-- MAIN APP DEPOTS / PACKAGES
addappid(562711, 1, "901041ae54705fda30ab01a48d3295e7350f41ec301906e1b8199f5ff67384eb")

