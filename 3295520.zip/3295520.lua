-- Lua provided by RyzenAPI
-- Game: Lilith Rising - Season 2 Demo

-- MAIN APPLICATION
addappid(3295520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295521, 1, "de0aaf0c7775cf308722dc53296a791883c935ac5fa97ddfb7b4e4782b8a1d1f")

