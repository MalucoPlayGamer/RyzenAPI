-- Lua provided by RyzenAPI
-- Game: Game: Zeroptian Invasion

-- MAIN APPLICATION
addappid(974110)
-- Game: addappid(974110)

-- MAIN APP DEPOTS / PACKAGES
addappid(974111, 1, "9a0035ca2a42a83b20a3e488628580f943d6ed8c773a160d9a7e7b6c42fc7386")
