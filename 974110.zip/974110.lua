-- Lua provided by RyzenAPI
-- Game: Zeroptian Invasion

-- MAIN APPLICATION
addappid(974110)

-- MAIN APP DEPOTS / PACKAGES
addappid(974111, 1, "9a0035ca2a42a83b20a3e488628580f943d6ed8c773a160d9a7e7b6c42fc7386")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
