-- Lua provided by RyzenAPI
-- Game: Virus L

-- MAIN APPLICATION
addappid(1192060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1192061, 1, "5a28e3d50d17b62d0d44df44976482d9e0d2b4927c777574a0cf69a21b2a6246")
