-- Lua provided by SkyAPI 
-- Game: AppID 1192060
addappid(1192060)
addappid(1192061, 1, "5a28e3d50d17b62d0d44df44976482d9e0d2b4927c777574a0cf69a21b2a6246")
