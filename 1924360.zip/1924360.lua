-- Lua provided by RyzenAPI
-- Game: Game: Lil' Guardsman

-- MAIN APPLICATION
addappid(1924360)
-- Game: addappid(1924360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924361, 1, "489edc4193c8c1b31355e921f21f4aefb2817bb72a43051f867d4630743ba325")
