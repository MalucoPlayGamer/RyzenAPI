-- Lua provided by RyzenAPI
-- Game: Game: MONSTER CARDS

-- MAIN APPLICATION
addappid(2010530)
-- Game: addappid(2010530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010531, 1, "1230ba9bc651c3afd1ab6327168e6687da083f7eaa5a90a3be00a35133ad48d3")
