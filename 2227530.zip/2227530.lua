-- Lua provided by RyzenAPI
-- Game: 2227530

-- MAIN APPLICATION
addappid(2227530)
-- Game: addappid(2227530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227532,0,"f94fe663c525b3b0b45106e17aa7ff3847eb68cb2cfe30c932523eb35733badf")
