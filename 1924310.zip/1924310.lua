-- Lua provided by RyzenAPI
-- Game: Pixel Pirate

-- MAIN APPLICATION
addappid(1924310)
-- Game: addappid(1924310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924311, 1, "850288c92d9b75f25ba8886adf14a9f1bc1bf156056e0735dfceb6c87dea2451")
