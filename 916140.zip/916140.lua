-- Lua provided by RyzenAPI
-- Game: The Tale of Bistun

-- MAIN APPLICATION
addappid(916140)

-- MAIN APP DEPOTS / PACKAGES
addappid(916141,0,"878ee4680efaf543fae9eb2f56b65434af9f52c3185a6eb54d91ddbf9d35f5af")
addappid(2081750,0,"ecf44a47b7872803e2dc9d020847716db5b6908aa5ddbbc008ece47a6e1840d2")

