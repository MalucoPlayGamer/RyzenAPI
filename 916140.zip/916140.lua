-- Lua provided by RyzenAPI
-- Game: 916140

-- MAIN APPLICATION
addappid(916140)
-- Game: addappid(916140)

-- MAIN APP DEPOTS / PACKAGES
addappid(916141, 1, "878ee4680efaf543fae9eb2f56b65434af9f52c3185a6eb54d91ddbf9d35f5af")
