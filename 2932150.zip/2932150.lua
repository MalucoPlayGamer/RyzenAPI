-- Lua provided by RyzenAPI
-- Game: Life Below

-- MAIN APPLICATION
addappid(2932150)
addappid(4684890)
addappid(4684900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932151,0,"1bb778455d12189287bcc3ea536a24651f8ca4274cc1f74810d31a9e317cb6e7")
addappid(4660330,0,"05ec3d13bbec8991a7db3ce5e254eee9fc890dfa68e1ffec775d8aa06c73ea96")
addappid(4660340,0,"cbb0f475ddad51e9a6f75ae09432e4df8adcf89b9f309c0aebdb24d4fc5817ee")
addappid(4711690,0,"fd98b203baeaada72126976e2fba4005b3aacf4ef624de6f57351ddd28e80668")

