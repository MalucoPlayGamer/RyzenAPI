-- Lua provided by RyzenAPI
-- Game: addappid(494430)

-- MAIN APPLICATION
addappid(494430)

-- MAIN APP DEPOTS / PACKAGES
addappid(494431, 1, "f3e90e6c386ee5c53b1d838df766777febca68f68ca94cbe4ae6f7f0087c5eed")
