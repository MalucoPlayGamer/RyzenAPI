-- Lua provided by RyzenAPI
-- Game: Game: AppID 43110

-- MAIN APPLICATION
addappid(43110)
-- Game: addappid(43110)

-- MAIN APP DEPOTS / PACKAGES
addappid(43111, 1, "244dd2de1baccbd6b85d59e9bfb1f1a7d6fffde8d9effc29a99817197e0d8470")
addappid(43112, 1, "98becea47557e53542316cc760b4246791a918acfe8c51ab99ac03fd9cd54c19")
addappid(43113, 1, "c4fdeb196dc74804e38929653328225c535599d187153d16c07843cddfe4d670")
addappid(43114, 1, "67ec3f5938830ff1e241386cb4b2f646d0432f58835a55b560d855550aacac73")
addappid(43115, 1, "aad78c0b7b00e3bca29940c9446f329e80efab4e3f977cc09d1ed297201d79df")
