-- Lua provided by RyzenAPI
-- Game: addappid(790300)

-- MAIN APPLICATION
addappid(790300)

-- MAIN APP DEPOTS / PACKAGES
addappid(790301, 1, "bbc768e1d24b9d06c34cd8b3460d0df3f520b1375352e074af4fc75cb20871fb")
