-- Lua provided by RyzenAPI
-- Game: Ferrum's Secrets: Where Is Grandpa?

-- MAIN APPLICATION
addappid(391340)
addappid(399870)

-- MAIN APP DEPOTS / PACKAGES
addappid(391341, 1, "3f65da33108a80595a3a7b3013a5ea07fefdb6480e219f11b4d23266df3a5be3")
addappid(391343, 1, "10c5c0fed3f4bb1314f70a43dca3426ca4daed1d4e42a73c07bbba93bd05db0d")

