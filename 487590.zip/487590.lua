-- Lua provided by RyzenAPI
-- Game: Pepe Porcupine

-- MAIN APPLICATION
addappid(487590)
-- Game: addappid(487590)

-- MAIN APP DEPOTS / PACKAGES
addappid(487591, 1, "54efb45fdcd64e825d637179d7fc0cf4cb8b8777c8458fee503c45d75f0b0074")
