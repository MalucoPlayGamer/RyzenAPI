-- Lua provided by RyzenAPI
-- Game: Diefrosty

-- MAIN APPLICATION
addappid(1814950)
-- Game: addappid(1814950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814951, 1, "4aa3eaa60810ae8d4e88564fb014191ada6134b7c86b501a48cab75b3f1afbe5")
