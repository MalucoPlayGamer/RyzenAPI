-- Lua provided by RyzenAPI
-- Game: SuchArt: Genius Artist Simulator

-- MAIN APPLICATION
addappid(1293180)
addappid(1514860)
addappid(2478320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293181, 1, "f6079b2733d87ac0376cd47ec42e78ccb05f39cf6e4fd42aac21f2c5a1babd4a")

