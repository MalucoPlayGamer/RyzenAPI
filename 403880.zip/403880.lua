-- Lua provided by RyzenAPI
-- Game: MotoGP™15 Compact

-- MAIN APPLICATION
addappid(403880)

-- MAIN APP DEPOTS / PACKAGES
addappid(403881, 1, "b4b844af1403eba64a7e50bc19aa589b15365b042165a467c33d391e25b74138")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
