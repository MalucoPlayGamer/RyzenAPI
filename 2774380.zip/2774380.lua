-- Lua provided by RyzenAPI
-- Game: Hospital 666

-- MAIN APPLICATION
addappid(2774380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774381, 1, "375790a30273b5f285bca3d552eb92c9442933076e3c858c9d58026f98bfe360")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
