-- Lua provided by RyzenAPI
-- Game: Game: Hospital 666

-- MAIN APPLICATION
addappid(2774380)
-- Game: addappid(2774380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774381, 1, "375790a30273b5f285bca3d552eb92c9442933076e3c858c9d58026f98bfe360")
