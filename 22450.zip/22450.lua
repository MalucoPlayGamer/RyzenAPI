-- Lua provided by RyzenAPI
-- Game: Hunted: The Demon’s Forge™

-- MAIN APPLICATION
addappid(22450)

-- MAIN APP DEPOTS / PACKAGES
addappid(22451, 1, "a40ea69f861d3b7b149a906a27571edc9602af1f9834c230419388e69802cc87")
addappid(22452, 1, "bca7a95df02850f702fadd9442f435a62905e75287652fcd46df0d76b0f58944")
addappid(22453, 1, "bee7ef727f54819a7a7249693b164eff1182c4a97e7cb8d26444ecf7defae720")
addappid(22454, 1, "3fa7d266bcc4998fe9c6d30538a7b3db3838932137685b9a37be53b88dfd75ad")
addappid(22455, 1, "11d6e17dc94cf930a757ccdea29d2939be4524df3b6540c2a121d70e7fa798c3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(22456)
