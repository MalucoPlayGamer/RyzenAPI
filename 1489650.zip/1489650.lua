-- Lua provided by RyzenAPI
-- Game: Game: AppID 1489650

-- MAIN APPLICATION
addappid(1489650)
-- Game: addappid(1489650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489651, 1, "414f3b8152c2d2584c83d2d16411c853306de2388e483401dfd66ba46b0e2f61")
