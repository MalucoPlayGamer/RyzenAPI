-- Lua provided by RyzenAPI
-- Game: 1713640

-- MAIN APPLICATION
addappid(1713640)
-- Game: addappid(1713640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713641, 1, "9aa2a892e53187cee091696dcc39138b08e6d7160b92122a3fc99a13a09fadea")
