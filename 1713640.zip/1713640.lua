-- Lua provided by RyzenAPI
-- Game: Ransack Raccoon

-- MAIN APPLICATION
addappid(1713640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1713641, 1, "9aa2a892e53187cee091696dcc39138b08e6d7160b92122a3fc99a13a09fadea")

