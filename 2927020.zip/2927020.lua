-- Lua provided by RyzenAPI
-- Game: 2927020

-- MAIN APPLICATION
addappid(2927020)
-- Game: addappid(2927020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927021, 1, "8849ca33bccd2104ce0b552d6ec6c74a29fd63babb91cdbc0c82f520a23c0b32")
