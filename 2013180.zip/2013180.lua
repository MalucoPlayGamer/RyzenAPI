-- Lua provided by RyzenAPI
-- Game: Game: Futanari Sex - Pool Party

-- MAIN APPLICATION
addappid(2013180)
-- Game: addappid(2013180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013181, 1, "e7ac5cd44e8e49d77018d93ed07c60eb2827b4d7199bfb220b457e0f1df2878e")
