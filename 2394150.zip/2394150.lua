-- Lua provided by RyzenAPI
-- Game: 2394150

-- MAIN APPLICATION
addappid(2394150)
-- Game: addappid(2394150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394151, 1, "aa2b9354756405c091bddb7713a464a01f50d048ddc1e3abeea70659fbfc603d")
