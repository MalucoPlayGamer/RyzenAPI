-- Lua provided by RyzenAPI
-- Game: Vugluskr: Zombie Rampage

-- MAIN APPLICATION
addappid(1164760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1164761, 1, "8abeb5d1201d70cc9f3385551cdf3c9f8132f1d44e285b02ad5ed3452cfdd67e")
