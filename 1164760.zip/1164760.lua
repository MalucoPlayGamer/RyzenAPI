-- Lua provided by RyzenAPI
-- Game: AppID 1164760

-- MAIN APPLICATION
addappid(1164760)
-- Game: addappid(1164760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164761, 1, "8abeb5d1201d70cc9f3385551cdf3c9f8132f1d44e285b02ad5ed3452cfdd67e")
