-- Lua provided by RyzenAPI
-- Game: Game: Traveler Of Light

-- MAIN APPLICATION
addappid(3099680)
-- Game: addappid(3099680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099681, 1, "d536d1fedcab83796327287a1a4fb9360f36de71631d14a65be844d568e7a377")
