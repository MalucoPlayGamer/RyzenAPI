-- Lua provided by SkyAPI 
-- Game: Rescuties! VR
addappid(468110)
addappid(468111, 1, "27c8b743f1bff141626d0eaf2860de98ef3b49a35f319b1fdcdaaa82a1e5aecf")
