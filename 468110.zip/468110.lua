-- Lua provided by RyzenAPI
-- Game: Rescuties! VR

-- MAIN APPLICATION
addappid(468110)
-- Game: addappid(468110)

-- MAIN APP DEPOTS / PACKAGES
addappid(468111, 1, "27c8b743f1bff141626d0eaf2860de98ef3b49a35f319b1fdcdaaa82a1e5aecf")
