-- Lua provided by RyzenAPI
-- Game: addappid(1657900)

-- MAIN APPLICATION
addappid(1657900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657901, 1, "41aff3ce69377e0b6c357e3efed15a224879eb8197c07d19df4ede45c7c5d867")
