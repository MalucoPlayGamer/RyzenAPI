-- Lua provided by RyzenAPI
-- Game: Get Out ! A "Very Bad Dreams" Story

-- MAIN APPLICATION
addappid(3883710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3883711,0,"6584d38c671f580cb9f88955f2291a888575e4d9577525c7d5dc2eef89b5b9aa")

