-- Lua provided by RyzenAPI
-- Game: addappid(1257790)

-- MAIN APPLICATION
addappid(1257790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257791, 1, "a45c3b37021d94dc31ff54e0988ba30c708406da0d72efe65174a469596a07c9")
