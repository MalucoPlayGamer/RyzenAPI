-- Lua provided by RyzenAPI
-- Game: AppID 277700

-- MAIN APPLICATION
addappid(277700)

-- MAIN APP DEPOTS / PACKAGES
addappid(277701, 1, "25866b104a3b0f6230a757ccd973b5524924672d36a888e5ca204275b70f1cca")
addappid(277702, 1, "c84e889bc16fe93dd46f14e62c3b3bfde3b259b36dbffe591570d1ccc585f1f4")
addappid(277703, 1, "b9c5ab191a2b3866426b7255d12e2b5d26957142b1e68257073da9f39a1e0900")
addappid(277704, 1, "94f85c920975a009c6831c8a09ad1d243c868ebfae88f6d01fcf9b03cfaca1cb")
addappid(277705, 1, "bde91e703ed734fbf70bc522a6076f3e6c14b75a15f2dc402758e5fa1e9494a4")
addappid(277706, 1, "c3d6db01d3db49288c3b99acaefaa1f0ca1dd529689b8ea03b36b875040cee67")
addappid(485961, 0, "49d95ac20421d2df19d8bd4fc339f028a8b1189c06c4999cf01c97f992a679ef")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(485960)
