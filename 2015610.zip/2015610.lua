-- Lua provided by RyzenAPI
-- Game: Blood Hospital

-- MAIN APPLICATION
addappid(2015610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015611, 1, "44507ad15f132d1cf75249bf60072c6a28275656c372a2ec2d9e3cc2a79ae388")

