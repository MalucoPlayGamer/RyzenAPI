-- Lua provided by RyzenAPI
-- Game: Synergism

-- MAIN APPLICATION
addappid(3552310)
