-- Lua provided by RyzenAPI
-- Game: Climbey

-- MAIN APPLICATION
addappid(520010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(520011, 1, "440514d6b253325af0c21da38287579b5d685fa51de2711a46a705045166c904")

