-- Lua provided by RyzenAPI
-- Game: 810580

-- MAIN APPLICATION
addappid(810580)
addappid(810581)

-- MAIN APP DEPOTS / PACKAGES
addappid(810582,0,"51185cf26dbcdd03ac4983324ee719af155c258e2599ff00e7a6c14ed663d82f")
