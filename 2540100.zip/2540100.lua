-- Lua provided by RyzenAPI
-- Game: Game: Crime Scene Cleaner: Prologue

-- MAIN APPLICATION
addappid(2540100)
-- Game: addappid(2540100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540101, 1, "9cac104abb6edc59f897aafebbd7ff51ee58b7ee47acbb72e3141e3b00efe074")
