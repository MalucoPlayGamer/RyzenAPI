-- Lua provided by RyzenAPI
-- Game: Sakura Swim Club

-- MAIN APPLICATION
addappid(402180)

-- MAIN APP DEPOTS / PACKAGES
addappid(402181, 1, "4f58fbe240d3252853b4e7b072c04698219aa43ccb7e83fc3244bf2fc328a1c2")

