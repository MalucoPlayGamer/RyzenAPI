-- Lua provided by RyzenAPI
-- Game: Hentai Stories - Supporter Art Pack

-- MAIN APPLICATION
addappid(3430230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430230,0,"e3b37d0e2c43e9c753a3c8e27261557118be46361db78662fd1e9cdab5f1e766")

