-- Lua provided by RyzenAPI
-- Game: 1548680

-- MAIN APPLICATION
addappid(1548680)
-- Game: addappid(1548680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548681, 1, "600cee073136ce6a972fc056a60d87cab48be3be92ce881d8ff3b9ffbd25e9b2")
