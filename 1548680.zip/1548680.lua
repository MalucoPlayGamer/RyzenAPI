-- Lua provided by SkyAPI 
-- Game: Untitled Crossing Record
addappid(1548680)
addappid(1548681, 1, "600cee073136ce6a972fc056a60d87cab48be3be92ce881d8ff3b9ffbd25e9b2")
