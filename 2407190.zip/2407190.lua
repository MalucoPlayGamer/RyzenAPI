-- Lua provided by RyzenAPI
-- Game: 東京サイコデミック Demo

-- MAIN APPLICATION
addappid(2407190)
-- Game: addappid(2407190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407191, 1, "16fa6799ab9d5edb8adf2d7b67597a76fce3f5b7f06a28be0edecd457996f5d4")
