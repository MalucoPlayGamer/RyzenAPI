-- Lua provided by RyzenAPI
-- Game: Retro Parking

-- MAIN APPLICATION
addappid(535280)

-- MAIN APP DEPOTS / PACKAGES
addappid(535281, 1, "e5d62171cd1a289fb0650f27190c79cd55e813ab4a790b3788089e29742331c3")
