-- Lua provided by RyzenAPI
-- Game: Retro Parking

-- MAIN APPLICATION
addappid(535280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(535281, 1, "e5d62171cd1a289fb0650f27190c79cd55e813ab4a790b3788089e29742331c3")

