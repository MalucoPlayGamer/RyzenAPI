-- Lua provided by RyzenAPI
-- Game: Coffin of Ashes

-- MAIN APPLICATION
addappid(546080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(546081, 1, "ec2c6709089d4b07c217c9ba262a1e19595f998af15aebab9d66e22212059dfc")

