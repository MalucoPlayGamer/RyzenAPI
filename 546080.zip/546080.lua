-- Lua provided by RyzenAPI
-- Game: Coffin of Ashes

-- MAIN APPLICATION
addappid(546080)
-- Game: addappid(546080)

-- MAIN APP DEPOTS / PACKAGES
addappid(546081, 1, "ec2c6709089d4b07c217c9ba262a1e19595f998af15aebab9d66e22212059dfc")
