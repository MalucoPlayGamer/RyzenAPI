-- Lua provided by RyzenAPI
-- Game: My Neighbor Neko

-- MAIN APPLICATION
addappid(2261660)
addappid(2273890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261661, 1, "de971374febd0c000b5f42739b2b40c99834fad46b9ec81264e5719ebccb6952")

