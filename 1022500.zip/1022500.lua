-- Lua provided by RyzenAPI
-- Game: addappid(1022500)

-- MAIN APPLICATION
addappid(1022500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022500,0,"f06ce4220f6f0ede23b9e7fd63755dd6e62c45763132dad1b22f74b206b55247")
