-- Lua provided by RyzenAPI
-- Game: Hold Your Ground

-- MAIN APPLICATION
addappid(1121190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121191, 1, "3d16ccc3f6137bbebd143d3ad702f31a79c9911a1a01d095c1d39426c85431f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
