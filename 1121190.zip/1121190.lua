-- Lua provided by RyzenAPI
-- Game: Hold Your Ground

-- MAIN APPLICATION
addappid(1121190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121191, 1, "3d16ccc3f6137bbebd143d3ad702f31a79c9911a1a01d095c1d39426c85431f6")

