-- Lua provided by RyzenAPI
-- Game: Kitty May Cry

-- MAIN APPLICATION
addappid(2123100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2123101, 1, "ce3ff66d4c788f4e57c8fa9353fcf5c4ebabdf0342452db5d58a8f54b0ab0bc7")

