-- Lua provided by RyzenAPI
-- Game: Witch of Ice Kingdom II

-- MAIN APPLICATION
addappid(568830)
addappid(578160)
addappid(578161)

-- MAIN APP DEPOTS / PACKAGES
addappid(568831, 1, "a7d029a3df20d4b994c2787d161979061f5f0664d5dec9dab8b592a688c3b589")
addappid(568832, 1, "5ece36e7a4a469ac3d2459ef568998c7f19b9b3eebc800ca7e833c0a0bc6b7b8")
addappid(619720, 0, "ec032ea1e382b9fc448871648a7183803a029312b676a1802a5e5729ba2cc37e")
addappid(619721, 0, "48ef7b43ed2adcbdadd25097521845df223d7717e8611e4fd7be34a0fde17306")
