-- Lua provided by RyzenAPI
-- Game: Game: Bewitched game

-- MAIN APPLICATION
addappid(935190)
-- Game: addappid(935190)

-- MAIN APP DEPOTS / PACKAGES
addappid(935191, 1, "d88f3ee32b79d50a89f9ab6bc72cfd080edc1a74d342261e15da9980a059aa25")
addappid(935192, 1, "e67df34ebda618e931e10272fe3f2eec5555216631f485c0b2c32203f00a736a")
