-- Lua provided by RyzenAPI
-- Game: Anthology of Fear

-- MAIN APPLICATION
addappid(1092530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092531, 1, "9c457383d10f9db0d9c667b9c6603df581cd8350b70487695f9e9a6e2085abfb")

