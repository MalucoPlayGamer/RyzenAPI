-- Lua provided by RyzenAPI
-- Game: 1618540

-- MAIN APPLICATION
addappid(1618540)
-- Game: addappid(1618540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618541, 1, "bd23a464581d71234d60a9a93530b20637584ea6db55bf465f45c5a2869abac7")
