-- Lua provided by RyzenAPI
-- Game: Zanshin

-- MAIN APPLICATION
addappid(768550)

-- MAIN APP DEPOTS / PACKAGES
addappid(768551,0,"6b6822969a4c42bde98c2b898cef301c3ca7c22f732355c354d0beed556b2069")

