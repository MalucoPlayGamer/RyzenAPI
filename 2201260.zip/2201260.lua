-- Lua provided by RyzenAPI
-- Game: Fiend Heart

-- MAIN APPLICATION
addappid(2201260)
addappid(2223210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201261, 1, "5a8fcf74d10a9527a129c5a59fc80554c826cf3d364ec05ad7c95191e953dc9e")

