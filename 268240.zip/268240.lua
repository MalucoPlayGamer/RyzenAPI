-- Lua provided by RyzenAPI
-- Game: Mechanic Escape

-- MAIN APPLICATION
addappid(268240)
-- Game: addappid(268240)

-- MAIN APP DEPOTS / PACKAGES
addappid(268241, 1, "926d571c8a97ab61450c9a722bd153b9d5a166b99162784fa67b448d340833bd")
addappid(268243, 1, "81bc6f9829e2161f3bd9aaa1296e1975a564dcb0bca5258c2775d4fb28c6ff90")
addappid(268244, 1, "d5c654ceda165dccfc2f70318a34478198a054815bcde465477b7823b940ea31")
