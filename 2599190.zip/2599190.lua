-- Lua provided by RyzenAPI
-- Game: Game: Peaky Blinders: The King's Ransom Complete Edition Demo

-- MAIN APPLICATION
addappid(2599190)
-- Game: addappid(2599190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599191, 1, "f81965f7fc2a8b09dd3d8b1cccb7e401700fcf8fe82ed7d3eb2b965c295c7ee9")
