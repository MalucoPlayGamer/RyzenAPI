-- Lua provided by RyzenAPI
-- Game: Vivid World Demo

-- MAIN APPLICATION
addappid(3160290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160291, 1, "f4eb514a7ba9a54ff86fe88e700c0ce1647d4be4acab37f2bc210966b50bcf6b")
