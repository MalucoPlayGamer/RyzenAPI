-- Lua provided by RyzenAPI
-- Game: Game: The Crown of Wu

-- MAIN APPLICATION
addappid(1732220)
-- Game: addappid(1732220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732221, 1, "a67daa6625ee95eda5c3a5ff2532b38e10b5578efce905d5be3de63065858aa5")
