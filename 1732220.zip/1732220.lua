-- Lua provided by RyzenAPI
-- Game: The Crown of Wu

-- MAIN APPLICATION
addappid(1732220)
addappid(2316630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1732221, 1, "a67daa6625ee95eda5c3a5ff2532b38e10b5578efce905d5be3de63065858aa5")

