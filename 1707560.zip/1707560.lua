-- Lua provided by RyzenAPI
-- Game: 1707560

-- MAIN APPLICATION
addappid(1707560)
-- Game: addappid(1707560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707561, 1, "3e2d509c574b67572ab199071614666c0b25fcb02a33ab4daf9a88e2b543c69e")
