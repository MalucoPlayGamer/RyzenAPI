-- Lua provided by RyzenAPI
-- Game: Dungeon Of Dragon Knight

-- MAIN APPLICATION
addappid(823610)
addappid(1071930)
addappid(1447460)

-- MAIN APP DEPOTS / PACKAGES
addappid(823611, 1, "194fbf52b02bac693b66843a1fceeef6eb0f8a9dfa6c5578372aa6e9dcdb2fde")
addappid(823612, 1, "f23ace20de9450dba94532d851ea6a7df573df251ea31578c746f7e74b33fe89")
addappid(1071960, 0, "70b51c5f57defa4c825337196380ffbedf26432af687b6762427526046349a76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
