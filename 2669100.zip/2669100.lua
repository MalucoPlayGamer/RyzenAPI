-- Lua provided by RyzenAPI
-- Game: WATCHER

-- MAIN APPLICATION
addappid(2669100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669101, 1, "6859150df9c924b13ca6e5cfdeb6f9687dd9df71e3c360525399942c1e71d816")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
