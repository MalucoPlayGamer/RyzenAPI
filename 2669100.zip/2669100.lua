-- Lua provided by SkyAPI 
-- Game: WATCHER
addappid(2669100)
addappid(2669101, 1, "6859150df9c924b13ca6e5cfdeb6f9687dd9df71e3c360525399942c1e71d816")
