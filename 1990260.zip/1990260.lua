-- Lua provided by SkyAPI 
-- Game: Phantom Tentacle
addappid(1990260)
addappid(1990261, 1, "b1e35063386c35620d9a056101f8f176477c0463db70bfc785c5fbd8f246fe7b")
addappid(2070370, 0, "d686601c4bf0b8dc8c8dee03282895d2c9b673972bd717e7308e1b7031bbdec2")
