-- Lua provided by RyzenAPI
-- Game: Portal Fantasy Demo

-- MAIN APPLICATION
addappid(2695390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695391, 1, "b81371fa38572b5bddd3805dc5fc158aecb0666b8a5e57a90a5e694dd8d367a7")
