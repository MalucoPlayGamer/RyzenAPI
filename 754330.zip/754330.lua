-- Lua provided by RyzenAPI
-- Game: Nogibator: Way Of Legs

-- MAIN APPLICATION
addappid(754330)

-- MAIN APP DEPOTS / PACKAGES
addappid(754331, 1, "8f28d83eae82d19612d968141b69ee97623707b93808a4a0ca10c8824eeeb3ae")

