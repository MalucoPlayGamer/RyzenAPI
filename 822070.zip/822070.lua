-- Lua provided by RyzenAPI
-- Game: AppID 822070

-- MAIN APPLICATION
addappid(822070)
-- Game: addappid(822070)

-- MAIN APP DEPOTS / PACKAGES
addappid(822071, 1, "ec08846e13d8cb974269f9dd25c3b125e00587aa47797f704cfacfd50e6220b1")
