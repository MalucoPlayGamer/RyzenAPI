-- Lua provided by RyzenAPI 
-- Game: AppID 822070
addappid(822070)
addappid(822071, 1, "ec08846e13d8cb974269f9dd25c3b125e00587aa47797f704cfacfd50e6220b1")
