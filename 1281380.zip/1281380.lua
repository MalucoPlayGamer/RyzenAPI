-- Lua provided by RyzenAPI
-- Game: Game: INVASION

-- MAIN APPLICATION
addappid(1281380)
-- Game: addappid(1281380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281381, 1, "b579b5a7121c6823a443935d4e5d73a6432cae669283bef836f8021e97cc6278")
