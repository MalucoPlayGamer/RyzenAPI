-- Lua provided by SkyAPI 
-- Game: Porsche Hall of Legends VR
addappid(1231900)
addappid(1231901, 1, "aae11a524d9a3181d852f0604278eebb9c478d8dbe039ed81be8ea55d14212f9")
addappid(1231902, 1, "620726c49adc067f96ddb455b02fdb854e7182d61638cb301070aaf1223d160b")
addappid(1231903, 1, "689bfa310e282fab51d8dbc3056b3e78ffe5169ae541e510a788ab63a76fb44d")
addappid(1231904, 1, "d4488689e0b584d89abc8c936569366b7bbaada8c708d8a89e9d0d178b6dad6c")
