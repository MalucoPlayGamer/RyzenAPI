-- Lua provided by RyzenAPI
-- Game: Porsche Hall of Legends VR

-- MAIN APPLICATION
addappid(1231900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231901, 1, "aae11a524d9a3181d852f0604278eebb9c478d8dbe039ed81be8ea55d14212f9")
addappid(1231902, 1, "620726c49adc067f96ddb455b02fdb854e7182d61638cb301070aaf1223d160b")
addappid(1231903, 1, "689bfa310e282fab51d8dbc3056b3e78ffe5169ae541e510a788ab63a76fb44d")
addappid(1231904, 1, "d4488689e0b584d89abc8c936569366b7bbaada8c708d8a89e9d0d178b6dad6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
