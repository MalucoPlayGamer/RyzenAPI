-- Lua provided by RyzenAPI
-- Game: RAMS

-- MAIN APPLICATION
addappid(809580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809581,0,"75e0d5157e434bd4f6994d250ff39c142d596accf3bf9f8512db3038b40d01f1")

