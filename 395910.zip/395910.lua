-- Lua provided by RyzenAPI
-- Game: Get Rich or Die Gaming

-- MAIN APPLICATION
addappid(395910)

-- MAIN APP DEPOTS / PACKAGES
addappid(395912,0,"f82d93cb5c27542c587ef7890d78df2b6211cc26026a2f521a47dfdf256a29e4")

