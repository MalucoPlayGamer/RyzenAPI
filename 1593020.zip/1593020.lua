-- Lua provided by RyzenAPI
-- Game: Game: Milk inside a bag of milk inside a bag of milk Soundtrack

-- MAIN APPLICATION
addappid(1593020)
-- Game: addappid(1593020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593021, 1, "29094a8174a90b45b4725f939d342aa6a585aaaa180fe974bbcf6e97bd9aec38")
