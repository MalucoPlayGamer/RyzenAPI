-- Lua provided by RyzenAPI
-- Game: Harvest Hunt

-- MAIN APPLICATION
addappid(2009620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009621, 1, "547fcbd645f2e5b723eae0a7510ab92197cc21d6747a6e4e79f7ac3545d97605")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
