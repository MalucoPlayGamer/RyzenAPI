-- Lua provided by RyzenAPI
-- Game: Harvest Hunt

-- MAIN APPLICATION
addappid(2009620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009621, 1, "547fcbd645f2e5b723eae0a7510ab92197cc21d6747a6e4e79f7ac3545d97605")

