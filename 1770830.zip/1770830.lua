-- Lua provided by RyzenAPI
-- Game: Virtual Maid Streamer Ramie

-- MAIN APPLICATION
addappid(1770830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1770831, 1, "5c104a365cba613beaf9d841269c2773532f424dde4b6703a24700876e944caa")

