-- Lua provided by RyzenAPI 
-- Game: Virtual Maid Streamer Ramie
addappid(1770830)
addappid(1770831, 1, "5c104a365cba613beaf9d841269c2773532f424dde4b6703a24700876e944caa")
