-- Lua provided by RyzenAPI
-- Game: 1770830

-- MAIN APPLICATION
addappid(1770830)
-- Game: addappid(1770830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770831, 1, "5c104a365cba613beaf9d841269c2773532f424dde4b6703a24700876e944caa")
