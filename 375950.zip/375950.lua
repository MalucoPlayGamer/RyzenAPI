-- Lua provided by RyzenAPI
-- Game: Viridi

-- MAIN APPLICATION
addappid(375950)

