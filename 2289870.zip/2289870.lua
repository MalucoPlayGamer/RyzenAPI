-- Lua provided by RyzenAPI
-- Game: 2289870

-- MAIN APPLICATION
addappid(2289870)
-- Game: addappid(2289870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289871, 1, "d350d33846c3b94d44cdc01bfad075e09565af13cd7fa48fb3f2d7741eed14f9")
