-- Lua provided by SkyAPI 
-- Game: 100% Challenge Demo
addappid(2355400)
addappid(2355401, 1, "9eaf9c913b6fdc9839fceea7c45d37b2db388e202e3dd8ebbfd7668bf6f24a96")
