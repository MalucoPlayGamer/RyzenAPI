-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Thunder"

-- MAIN APPLICATION
addappid(1099583)
-- Game: addappid(1099583)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099583,0,"045297eb4f7eb3cf7f65f26fba8a8a038aa1d00845e7682d33e873e9b55cc055")
