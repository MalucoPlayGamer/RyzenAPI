-- Lua provided by RyzenAPI
-- Game: Farmer Against Potatoes Idle

-- MAIN APPLICATION
addappid(1535560)
-- Game: addappid(1535560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535561, 1, "84e8c05a65f0c95d7850ae9ea2d2848ceb25acd5dd72356d917ba0305e5cecbd")
