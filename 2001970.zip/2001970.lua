-- Lua provided by RyzenAPI
-- Game: 2001970

-- MAIN APPLICATION
addappid(2001970)
-- Game: addappid(2001970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001971, 1, "948260248614c9f8395c0f2df09ca4d5bd4720efde305fe2c3639214254d0efd")
