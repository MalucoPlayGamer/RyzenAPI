-- Lua provided by RyzenAPI
-- Game: Born Again

-- MAIN APPLICATION
addappid(2332210)
-- Game: addappid(2332210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332212,0,"864be72c3bf0f07d55c80388d4a5d2bd7409da224729eb9dccd6b83d0b108b6b")
addappid(2332213,0,"f199f7c97c47fdd5512a3797401cb3a25c214a7ede4960d25ff208e1ef2d7003")
addappid(2332214,0,"9b73581687d5085a2e2401be2193e93817a3cb3a967d73d23aacfcb9e807da59")
addappid(2332215,0,"1ae86dc74efbb0d5bc50126f435192a36eba0ad56b96e99adeb4b02cadf8d2c0")
