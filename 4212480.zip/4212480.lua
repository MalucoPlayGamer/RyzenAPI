-- Lua provided by RyzenAPI
-- Game: Ragnarok: The New World

-- MAIN APPLICATION
addappid(4212480)
