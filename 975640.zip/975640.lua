-- Lua provided by RyzenAPI
-- Game: AppID 975640

-- MAIN APPLICATION
addappid(975640)
-- Game: addappid(975640)

-- MAIN APP DEPOTS / PACKAGES
addappid(975641, 1, "2edc0bb171cfe7cdc6b140a39e12a42816e0483988f3960702e2e7852726fb25")
