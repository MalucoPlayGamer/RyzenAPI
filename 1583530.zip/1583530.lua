-- Lua provided by RyzenAPI
-- Game: Crazy indian

-- MAIN APPLICATION
addappid(1583530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583531, 1, "790ba2c7f119d59bd375b0151f1bb75cb06e5855fd5d25de743157351c8c254b")
