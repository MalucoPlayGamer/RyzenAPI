-- Lua provided by RyzenAPI
-- Game: Game: There Is No Light 616

-- MAIN APPLICATION
addappid(1700700)
-- Game: addappid(1700700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700701, 1, "91db856dcb6b8b9ed0b09733f7dd8a378624f5207c597fd36aec486715077dc2")
