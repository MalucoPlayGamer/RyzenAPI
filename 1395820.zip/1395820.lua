-- Lua provided by RyzenAPI
-- Game: addappid(1395820)

-- MAIN APPLICATION
addappid(1395820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395821, 1, "5370f20df0d53ea71f264d69d2536629c70eaa78f9dfe251a277f641b319fc69")
