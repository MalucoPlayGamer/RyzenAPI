-- Lua provided by RyzenAPI
-- Game: Ninja JaJaMaru: The Great Yokai Battle + Hell OriginalSoundTrack

-- MAIN APPLICATION
addappid(1970170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970171, 1, "6dbffc1b763356321be42052b975d89db597da9b1f0ef52766d32fa6f6a06e1f")

