-- Lua provided by RyzenAPI
-- Game: AppID 367690

-- MAIN APPLICATION
addappid(367690)

-- MAIN APP DEPOTS / PACKAGES
addappid(367691, 1, "616b2b7e386c3a9d796d710c69cafaa31eb721276d55919fc9c5b60066ebc08d")

