-- Lua provided by RyzenAPI 
-- Game: Vigaro Runner 2: Return
addappid(3376620)
addappid(3376621, 1, "02f2255e5b057c97e7e1c7019c926d6cfd692b883fa3fffbeaefedf499349764")
