-- Lua provided by RyzenAPI
-- Game: AppID 719040

-- MAIN APPLICATION
addappid(719040)
addappid(1191060)
addappid(1522650)
addappid(1593330)
addappid(1642320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(719041, 1, "f91809973de8000057590dbcfbacae7ca360a08589cc923bb510ac7c4722240a")
addappid(719042, 1, "d0407125cf6118a0c1f63530d500cef3a3037f1b1754352da78fa6e80d8de4f8")
addappid(719043, 1, "3854aed268d9b1757b5164f935bac1b58d8ee99fa05be8ed40a26c598188bf44")
addappid(1382210, 0, "68e5b6c946ca34cd022286692fccfc5aac7da40cfae9dd3ff4e5e8f09c49baa8")

