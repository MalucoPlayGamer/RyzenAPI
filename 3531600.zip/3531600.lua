-- Lua provided by RyzenAPI 
-- Game: Kappa Quest Soundtrack
addappid(3531600)
addappid(3531601, 1, "13d156c622f5a61ed9a55f2d7101078e7c4d5ed6869207d88f3e4c01fb0495eb")
addappid(3531602, 1, "fb30d6cca8cdbf1f1cec0ef09df042b0a025b8afa7bd520e9eb4000198dc5cb0")
