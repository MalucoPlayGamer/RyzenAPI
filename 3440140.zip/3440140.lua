-- Lua provided by RyzenAPI
-- Game: Do Not Disturb

-- MAIN APPLICATION
addappid(3440140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440141, 1, "0fa730b20d55aaaa1f95cfc7de5f899de0ea7c279c5dbaa87e320d87e5bf1c64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
