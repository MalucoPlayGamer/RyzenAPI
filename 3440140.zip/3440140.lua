-- Lua provided by RyzenAPI 
-- Game: Do Not Disturb
addappid(3440140)
addappid(3440141, 1, "0fa730b20d55aaaa1f95cfc7de5f899de0ea7c279c5dbaa87e320d87e5bf1c64")
