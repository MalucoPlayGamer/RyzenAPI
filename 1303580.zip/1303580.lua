-- Lua provided by RyzenAPI
-- Game: Mars Horizon Demo

-- MAIN APPLICATION
addappid(1303580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303581, 1, "73d0d02f6c6a7856f37e2ed85789b672dca1d5e2b605ae00b503638f8d432d6c")

