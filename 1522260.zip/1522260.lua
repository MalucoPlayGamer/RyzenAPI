-- Lua provided by RyzenAPI
-- Game: AppID 1522260

-- MAIN APPLICATION
addappid(1522260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522261, 1, "194ef189bd8f2cedee567729b0548cc8d813d55323a4f84b034efbef0297e0b3")
addappid(1522262, 1, "1301080db902f4c1718f6efd6e057451892d4bf2cf565851d1a4f37ccccada7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
