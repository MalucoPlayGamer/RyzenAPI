-- Lua provided by RyzenAPI
-- Game: addappid(1522260)

-- MAIN APPLICATION
addappid(1522260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522261, 1, "194ef189bd8f2cedee567729b0548cc8d813d55323a4f84b034efbef0297e0b3")
addappid(1522262, 1, "1301080db902f4c1718f6efd6e057451892d4bf2cf565851d1a4f37ccccada7d")
