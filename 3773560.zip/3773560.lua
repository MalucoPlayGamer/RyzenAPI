-- Lua provided by RyzenAPI
-- Game: addappid(3773560)

-- MAIN APPLICATION
addappid(3773560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773561, 1, "ee2d5eb0b49b6633b093006c94674c6efd959083f76cd7f355439c743b7d9c43")
