-- Lua provided by RyzenAPI
-- Game: Hydroponics Farm & Store Simulator Demo

-- MAIN APPLICATION
addappid(3233920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233921, 1, "1922c1e4ea20107311324ba91a0b748de7e8168c63b948cd6bbf0966d2848ede")
