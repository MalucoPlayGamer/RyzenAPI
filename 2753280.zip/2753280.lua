-- Lua provided by RyzenAPI
-- Game: 小夜怪奇物语追加章节：十四到二十章

-- MAIN APPLICATION
addappid(2753280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753280,0,"7f3464bb57b11bea066802dd4ba2c9b1f846bf698e1f2a29442e48910349b8fc")

