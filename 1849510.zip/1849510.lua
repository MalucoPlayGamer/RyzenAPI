-- Lua provided by RyzenAPI
-- Game: 1849510

-- MAIN APPLICATION
addappid(1849510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849511, 1, "9ec6322cbe9ad3f59e77d99d1796332bbfff8db1f2bed306158f65ecce041197")

