-- Lua provided by RyzenAPI
-- Game: The Ouroboros King

-- MAIN APPLICATION
addappid(2096510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096511, 1, "a8a921b3d9869991f4c4e13aef96fe20085bfb03140a8ccfd9969ef6a9ebefc4")

