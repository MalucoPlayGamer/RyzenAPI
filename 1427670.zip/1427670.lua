-- Lua provided by RyzenAPI
-- Game: FUSER™ - Dua Lipa - "New Rules"

-- MAIN APPLICATION
addappid(1427670)
-- Game: addappid(1427670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427670,0,"d4a6af2c451f1f4b17faafd39d5989fbb8cd0a9310ab423c2f219654935e5efe")
addtoken(1427670,8089851906629943813)
