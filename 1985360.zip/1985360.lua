-- Lua provided by RyzenAPI
-- Game: Cute Cats 3

-- MAIN APPLICATION
addappid(1985360)
addappid(2003400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985361, 1, "a91f7290e24ab12ec9d11f19dfb92cd4051175f13bb862caed98e52493776fda")

