-- Lua provided by RyzenAPI
-- Game: 2870570

-- MAIN APPLICATION
addappid(2870570)
-- Game: addappid(2870570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870571, 1, "b661dc72c9ceb1335272fb990fe35291d7dc590b274ef0a073dfd5d255611367")
