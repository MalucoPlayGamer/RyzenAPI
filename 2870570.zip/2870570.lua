-- Lua provided by RyzenAPI
-- Game: Find 101 Doomers

-- MAIN APPLICATION
addappid(2870570)
addappid(2885940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2870571, 1, "b661dc72c9ceb1335272fb990fe35291d7dc590b274ef0a073dfd5d255611367")

