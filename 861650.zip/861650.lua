-- Lua provided by RyzenAPI 
-- Game: AppID 861650
addappid(861650)
addappid(861651, 1, "68c4836650ec6ae4232194aa81a3025fa622c15ed614cdaf9c76fe67819fbf22")
