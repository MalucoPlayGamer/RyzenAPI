-- Lua provided by RyzenAPI
-- Game: 861650

-- MAIN APPLICATION
addappid(861650)
-- Game: addappid(861650)

-- MAIN APP DEPOTS / PACKAGES
addappid(861651, 1, "68c4836650ec6ae4232194aa81a3025fa622c15ed614cdaf9c76fe67819fbf22")
