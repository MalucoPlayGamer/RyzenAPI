-- Generated with Luie @ https://lua.tools/
-- 861650 - Session: Skate Sim
-- Generated 2026-08-22 22:24:57 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(861650, 1, "8bc39fd3b27228ef8d96a7955bc37c75996e649dcf94306607a908a46563ad0c")

-- Main Depots
addappid(861651, 1, "68c4836650ec6ae4232194aa81a3025fa622c15ed614cdaf9c76fe67819fbf22") -- (windows)
setManifestid(861651, "341888445509651443", 18011622201)

-- DLC's (no depot keys required)
addappid(2075190) -- Session: Skate Sim Brandalised® Pack
addappid(2075191) -- Session: Skate Sim Supporter Pack
addappid(2313400) -- Session: Skate Sim Waterpark & Chris Cole
addappid(2590440) -- Session: Skate Sim Abandoned Mall
addappid(2727340) -- Session: Skate Sim - Year 1 Pack
addappid(2732710) -- Session: Skate Sim Schoolyard
addappid(2877960) -- Session: Skate Sim Paris
addappid(3155940) -- Session: Skate Sim Prague
addappid(3389600) -- Session: Skate Sim - Year 2 Pack
addappid(3966690) -- Session: Skate Sim El Lay

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
