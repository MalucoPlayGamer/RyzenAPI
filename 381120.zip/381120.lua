-- Lua provided by RyzenAPI
-- Game: Shoppe Keep

-- MAIN APPLICATION
addappid(381120)

-- MAIN APP DEPOTS / PACKAGES
addappid(381121, 1, "4b28ea7077b0cc1528a81e9141dc678b345fb1b27571f4b4c3534322324f842f")
addappid(381122, 1, "b2c5ff7cb9cb40a10e8e9a89adcbd5f4466c26268c6095f869b0ad739b9ce675")
addappid(381123, 1, "4f5f7eb32f43a3fc6167c508bc6e3a75ae13de6bdc260587a305e994b47f218d")
addappid(381124, 1, "6de3cc7c2c1379ae71a9af7ea8c523c657804e8e95742344f8aa0fcbde89f461")
addappid(381126, 1, "6a2066362f4aea6f75893519f37414d4a69abdbc280c2c6f2c17fa02686a5835")
addappid(381127, 1, "5db93f67ab10070213b8881f66efd90077819ef9817073ccb9a7fa648f7a06d7")
addappid(473090, 0, "9185c5fda740eed3f394efe92a83a4a47d26d32fdf8b114d641cc2ffb2276afe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
