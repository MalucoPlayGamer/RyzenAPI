-- Lua provided by RyzenAPI
-- Game: addappid(3385900)

-- MAIN APPLICATION
addappid(3385900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385901, 1, "4dafc39c36ae0ff181cff5602f886b88ca2c976300fc71753f2647fc8b19bb87")
