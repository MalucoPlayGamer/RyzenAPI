-- Lua provided by RyzenAPI 
-- Game: Open Wheel Manager 2
addappid(1757580)
addappid(1757581, 1, "a4dc7ccb8f20a3f7ff5382ef2e3f0680c91952296dd103a5f6f3ba9f4df80c6d")
