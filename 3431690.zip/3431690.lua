-- Lua provided by RyzenAPI
-- Game: AppID 3431690

-- MAIN APPLICATION
addappid(3431690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431691, 1, "d99c9bc0bb371c4bb38ddb1293630dc1c2ee0518177eb34c3d6dc736aaa4cdc2")

