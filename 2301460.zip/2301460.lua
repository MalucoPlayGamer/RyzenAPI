-- Lua provided by RyzenAPI
-- Game: Game: BrokenLore: UNFOLLOW Demo

-- MAIN APPLICATION
addappid(2301460)
-- Game: addappid(2301460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301461, 1, "4b643402f6091acf5ba4f712f01190c7e8b52cf3a9fb0da607cad71934b0fa00")
