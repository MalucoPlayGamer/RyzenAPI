-- Lua provided by SkyAPI 
-- Game: BrokenLore: UNFOLLOW Demo
addappid(2301460)
addappid(2301461, 1, "4b643402f6091acf5ba4f712f01190c7e8b52cf3a9fb0da607cad71934b0fa00")
