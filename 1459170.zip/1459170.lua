-- Lua provided by RyzenAPI
-- Game: Military Crusaders

-- MAIN APPLICATION
addappid(1459170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459171, 1, "557f9c2074e29dda730436be4a2bbeebd83d61d0e9943f0cabd47f01a3e8db23")

