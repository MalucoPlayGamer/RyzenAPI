-- Lua provided by RyzenAPI 
-- Game: Military Crusaders
addappid(1459170)
addappid(1459171, 1, "557f9c2074e29dda730436be4a2bbeebd83d61d0e9943f0cabd47f01a3e8db23")
