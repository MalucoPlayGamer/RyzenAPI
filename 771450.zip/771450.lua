-- Lua provided by RyzenAPI
-- Game: addappid(771450)

-- MAIN APPLICATION
addappid(771450)

-- MAIN APP DEPOTS / PACKAGES
addappid(771451, 1, "f878f41953f103eb358a998f58ed04221720e3c02a012bc7f48e7c6eba9d2bab")
