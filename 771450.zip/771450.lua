-- Lua provided by RyzenAPI
-- Game: ERROR: Human Not Found

-- MAIN APPLICATION
addappid(771450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(771451, 1, "f878f41953f103eb358a998f58ed04221720e3c02a012bc7f48e7c6eba9d2bab")
