-- Lua provided by RyzenAPI
-- Game: Love challenge

-- MAIN APPLICATION
addappid(2334130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334131, 1, "aebbb153040db09fd7b331cc06dcdec6f1477ab1c830756623fd199fcf1b39a6")

