-- Lua provided by RyzenAPI
-- Game: Click-Her

-- MAIN APPLICATION
addappid(3994640)
addappid(4856750)
addappid(4856760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3994641,0,"ac5d774e162c6df237b6ed51bf07c8a6c052f13a6bba2ec35ef086dfbcf2515e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4853850)
