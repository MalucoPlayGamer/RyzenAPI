-- Lua provided by RyzenAPI
-- Game: 扩张吧王国 Expand the Kingdom

-- MAIN APPLICATION
addappid(3459810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3459811, 1, "a14367d786586e2b9c050594c65fd18d6352f1009794af3f30bb73015d257eae")

