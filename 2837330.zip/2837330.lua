-- Lua provided by SkyAPI 
-- Game: Milky Way TD SURVIVORS AUTOBATTLER RTS
addappid(2837330)
addappid(2837331, 1, "066149d08d5ea39cc571f4ac3438e055234ee0a3c0b443a2e74deac9d5c5949f")
