-- Lua provided by RyzenAPI
-- Game: addappid(1213000)

-- MAIN APPLICATION
addappid(1213000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213002,0,"e20d11bf01e58aee72f8eb2c516e9e2e1509c4d0ce7e96efecf1222523c2e6e6")
