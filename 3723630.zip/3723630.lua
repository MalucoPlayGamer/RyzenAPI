-- Lua provided by RyzenAPI
-- Game: Kathy Rain 2: Soothsayer Original Soundtrack

-- MAIN APPLICATION
addappid(3723630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723631, 1, "1a13ed83c99ffe7db65a9065c1e59ad2a7aa274f79d81bc73528ff156befe20d")
addappid(3723632, 1, "00b6eb1b1c93d8bd7655abdd71e0945b4f44f544f9ca01604291f46482f1d7e0")
