-- Lua provided by RyzenAPI
-- Game: addappid(2256930)

-- MAIN APPLICATION
addappid(2256930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256931, 1, "859a6ee0c4ae817cc81a3cc8643abc893496304724f1adec6866dd2dc353e324")
