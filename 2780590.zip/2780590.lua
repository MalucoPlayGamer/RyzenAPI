-- Lua provided by RyzenAPI
-- Game: 2780590

-- MAIN APPLICATION
addappid(2780590)
-- Game: addappid(2780590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780591, 1, "616879846e62e5ea3fcd9f6e3c5c50b9eb197284502b7c0d5f71bfe4e5595553")
