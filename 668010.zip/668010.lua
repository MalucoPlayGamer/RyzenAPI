-- Lua provided by RyzenAPI
-- Game: Goalie VR

-- MAIN APPLICATION
addappid(668010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(668011, 1, "1e9c7831aa9363220fc531444bbd92ff49f7594ecd22bce9ce14c5200c0a866f")

