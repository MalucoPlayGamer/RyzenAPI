-- Lua provided by RyzenAPI
-- Game: Goalie VR

-- MAIN APPLICATION
addappid(668010)

-- MAIN APP DEPOTS / PACKAGES
addappid(668011, 1, "1e9c7831aa9363220fc531444bbd92ff49f7594ecd22bce9ce14c5200c0a866f")

