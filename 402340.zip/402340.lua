-- Lua provided by RyzenAPI
-- Game: addappid(402340)

-- MAIN APPLICATION
addappid(402340)

-- MAIN APP DEPOTS / PACKAGES
addappid(402341, 1, "3f310b5ba2c0b47892fd8d58a0a86cf8adbf25e17860d5ac19a4f810e736f13f")
addappid(459890, 0, "486f3c73914c6b4aaf5920d88bf40371e2c0f3cb9ce0aa8d8c130fbaeac01f14")
