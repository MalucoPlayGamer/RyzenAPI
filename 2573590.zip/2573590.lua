-- Lua provided by RyzenAPI
-- Game: Toytopia

-- MAIN APPLICATION
addappid(2573590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573591, 1, "fb3d676ecb2fc50f566fc00935823f3de525d430eac6f3d94a0226a01840fdb1")
