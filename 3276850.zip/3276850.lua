-- Lua provided by RyzenAPI
-- Game: Game: AppID 3276850

-- MAIN APPLICATION
addappid(3276850)
-- Game: addappid(3276850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276851, 1, "4bea31bf5ed06ddbabb63bdfff127822b5a310d074491382c7c5418daccd9244")
addappid(3276852, 1, "be7fe6623a7b4968b3b58786873fd485572e6b8ff007f1238196667764cc7db5")
