-- Lua provided by RyzenAPI
-- Game: Game: AppID 1823270

-- MAIN APPLICATION
addappid(1823270)
-- Game: addappid(1823270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823271, 1, "7e9b3b5d28b015786d5b964978b365592680df7afc552a1ec3e55706a43763df")
