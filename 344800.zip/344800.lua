-- Lua provided by RyzenAPI
-- Game: World of Mixed Martial Arts 3

-- MAIN APPLICATION
addappid(344800)

-- MAIN APP DEPOTS / PACKAGES
addappid(344801, 1, "921abf07ec2fd7ec03a5462afd8829594b89688a0460a7b91acf06ba2408e650")
