-- Lua provided by RyzenAPI
-- Game: 3096050

-- MAIN APPLICATION
addappid(3096050)
-- Game: addappid(3096050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096051, 1, "39b5b9cc1ae4864a034cd8bddcea9ae980584834f7ebfe5ae90b36a42daa3d83")
