-- Lua provided by RyzenAPI
-- Game: Rock the Rim

-- MAIN APPLICATION
addappid(3522430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3522431, 1, "faf364f2378e5381b454ba9d6c6783f5cc219321496205ad6b00d60966b486e0")
