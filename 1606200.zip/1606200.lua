-- Lua provided by RyzenAPI 
-- Game: Frostpunk Expansions Original Soundtrack
addappid(1606200)
addappid(1606201, 1, "d78a4523ebff58db6162b08db4e1c5503c923cf44473a811b347baed95a4ffa9")
addappid(1606202, 1, "051d91b98b9c1ffee58b24fe59d215a28454d1efce88d18c6314e8907b9970bd")
