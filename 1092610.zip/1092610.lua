-- Lua provided by RyzenAPI
-- Game: 末日機甲：戰術獵人

-- MAIN APPLICATION
addappid(1092610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092612,0,"1aff2cb23339c6673db5081b3e842d11c626884f98da5b12763c4a41ddc78996")

