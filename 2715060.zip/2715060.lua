-- Lua provided by RyzenAPI
-- Game: PolyZen Drive

-- MAIN APPLICATION
addappid(2715060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715062,0,"1441a0362fef9f96a47e3d4bfc073d9e343e2dbcb037b95671896fc63eb446d3")
