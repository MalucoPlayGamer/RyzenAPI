-- Lua provided by RyzenAPI
-- Game: One Thousand Lies

-- MAIN APPLICATION
addappid(463390)
