-- Lua provided by RyzenAPI
-- Game: System Shock

-- MAIN APPLICATION
addappid(482400)

-- MAIN APP DEPOTS / PACKAGES
addappid(482401, 1, "412c806b5c53587b7d89ead695e603da1e9d2d6bd7a3cc85e4387aa6f0565c23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
