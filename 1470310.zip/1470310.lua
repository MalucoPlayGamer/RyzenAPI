-- Lua provided by RyzenAPI
-- Game: Witch 2 Hell Adventure

-- MAIN APPLICATION
addappid(1470310)
addappid(1606310)
-- Game: addappid(1470310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470311, 1, "3f88b95eea0f419f15a167d78e119fce80f55ed82cfc51ecd1b8e2d0183b2edd")
addappid(1741190, 0, "a152a40afe8a6d98b3814bcb37f2c9dfe26a1e25f01aee12d4c6ba0adc1fedbd")
addappid(1752550, 0, "158c71860fd101924896ba4323e48a0adb021aeb0e83cd395f76c64ce5dda80c")
