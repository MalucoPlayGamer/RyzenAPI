-- Lua provided by RyzenAPI
-- Game: Witch 2 Hell Adventure

-- MAIN APPLICATION
addappid(1470310)
addappid(1606310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470311, 1, "3f88b95eea0f419f15a167d78e119fce80f55ed82cfc51ecd1b8e2d0183b2edd")
addappid(1741190, 0, "a152a40afe8a6d98b3814bcb37f2c9dfe26a1e25f01aee12d4c6ba0adc1fedbd")
addappid(1752550, 0, "158c71860fd101924896ba4323e48a0adb021aeb0e83cd395f76c64ce5dda80c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
