-- Lua provided by RyzenAPI
-- Game: 1504840

-- MAIN APPLICATION
addappid(1504840)
-- Game: addappid(1504840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504841, 1, "0aba628506ca3e6b84ae069d8d15ed26dc2ac10bca8b5409158b70b286221f79")
