-- Lua provided by RyzenAPI
-- Game: addappid(696280)

-- MAIN APPLICATION
addappid(696280)

-- MAIN APP DEPOTS / PACKAGES
addappid(696281, 1, "dae158a3ba7504c06c29d4b93f410f11d8cf7ae3b362c88013d5d97466e43a96")
