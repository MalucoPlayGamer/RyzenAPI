-- Lua provided by RyzenAPI
-- Game: Phyllis, The Receptionist of The Guild

-- MAIN APPLICATION
addappid(1989840)
addappid(2323460)
-- Game: addappid(1989840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989841, 1, "aa6ab526a5885714926c95a98c202d71d2ea39780410634b8be712b4e5d419c0")
