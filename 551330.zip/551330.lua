-- Lua provided by RyzenAPI
-- Game: Sea of Lies: Mutiny of the Heart Collector's Edition

-- MAIN APPLICATION
addappid(551330)

-- MAIN APP DEPOTS / PACKAGES
addappid(551331,0,"ef889dfcbc7a3acd5bb3f454fe298bf2590749e4c99441fd08ff77956e8d1e18")

