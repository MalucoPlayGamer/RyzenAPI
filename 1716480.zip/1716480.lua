-- Lua provided by RyzenAPI
-- Game: Tied by your Red

-- MAIN APPLICATION
addappid(1716480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716481, 1, "9eebbbc4bd3ed60fe303ec8128d09ccf55cb68dbc51cb35b58206109a9e5d1d8")
