-- Lua provided by RyzenAPI
-- Game: 诗意塔罗牌

-- MAIN APPLICATION
addappid(3592390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592391, 1, "e8909dbeca4b471214bb931b9790a19aa4a8c9c047b7caee1b218aa9c94b6784")
