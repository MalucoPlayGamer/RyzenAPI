-- Lua provided by RyzenAPI
-- Game: Loki's Revenge

-- MAIN APPLICATION
addappid(2936750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936751, 1, "ab7a57caee905f8521ac876a19ed54dfb1d184159c7fe7165d18c99e5d0842b5")
