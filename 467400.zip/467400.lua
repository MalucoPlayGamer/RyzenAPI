-- Lua provided by RyzenAPI
-- Game: 467400

-- MAIN APPLICATION
addappid(467400)
-- Game: addappid(467400)

-- MAIN APP DEPOTS / PACKAGES
addappid(467401, 1, "7bf71b572fcd9d2a1921621db6d9a4979eb52efdafd750fa6754f536caae2c89")
