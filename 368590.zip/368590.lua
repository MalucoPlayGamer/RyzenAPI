-- Lua provided by RyzenAPI 
-- Game: Albert and Otto
addappid(368590)
addappid(368591, 1, "721c554b63650351fc7461fc54aa96a8c8b1b12c686ef4d1f556f90d8ad4a3cf")
addappid(368592, 1, "7d9d14c432c997605938f63b3ef2a5bcbc73dc44fc92fdde8b5b51bcb2499ee5")
addappid(418580, 0, "ad97eba66f5bf661290b521302ec294ac9e7bc276329f63bfc84ff0464949059")
