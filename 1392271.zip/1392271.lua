-- Lua provided by RyzenAPI
-- Game: addappid(1392271)

-- MAIN APPLICATION
addappid(1392271)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392271,0,"e9dbf331d5a735bd329cf2f6ab1bd8f7d4ba29fc683a97032bb0e2bb4b97710d")
