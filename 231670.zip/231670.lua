-- Lua provided by RyzenAPI
-- Game: Football Manager 2014

-- MAIN APPLICATION
addappid(231670)
addappid(261200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(231671, 1, "cbbd7d224a77e9cfa99950aee0075b9dddba48c23054adb887725c6421055b61")
addappid(231672, 1, "04141f946db236ac98acc6f0d76d9d4610dfa2ab1912f3fc05994956d9d7c78c")
addappid(231673, 1, "eeb670e4dfbf567b7ea9ca8495ad8f8c041c8679cddbde0d24dfb8df47cc949a")
addappid(231674, 1, "a29fcf776a8e62c0972c482ee71d26753a7b93390150d5d5f34d2a00dd2cdbfc")
addappid(231675, 1, "33f4ea2a33ceac4c63372c12ed766231cddb47526f0f3db8e1c00891b9eba79b")
addappid(231676, 1, "c9fa26a1afabe2c40337822714fdab11d4b69b519d74efbc2f133273e933defa")
addappid(231677, 1, "0e9c26c702e9978ca8865897ec7219061b5286dd19fe065bc88b04ee6e62d129")
addappid(231678, 1, "7fe026405b9d075c841687a7a665efdfba2b721d17d2b520cc8a4a0a53410497")
