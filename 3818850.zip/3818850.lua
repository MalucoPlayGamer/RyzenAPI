-- 3818850's Lua and Manifest Created by Hubcap Manifest
-- TowerLine
-- Created: July 14, 2026 at 14:45:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3818850) -- TowerLine
-- MAIN APP DEPOTS
addappid(3818851, 1, "d95b8879650a3cd8c8783da906b6c54c25839611be9ec19cea9f1ade341965d9") -- Depot 3818851
setManifestid(3818851, "5921583424809526890", 313792178)
addappid(3818852, 1, "cf86a9aa2a4e9fd10a1081bc8bbfc043457fa124f78aa4040348bed1e471f32c") -- Depot 3818852
setManifestid(3818852, "8882586259040206018", 332104871)