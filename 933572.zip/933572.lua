-- Lua provided by RyzenAPI
-- Game: 933572

-- MAIN APPLICATION
addappid(933572)
-- Game: addappid(933572)

-- MAIN APP DEPOTS / PACKAGES
addappid(933572,0,"5f97aa5a53a963d247864ccf5050d670efe3c5b48f6f4f6a4dc499c8310d3102")
