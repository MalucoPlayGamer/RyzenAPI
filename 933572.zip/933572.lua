-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 - Scenario Pack 2

-- MAIN APPLICATION
addappid(933572)

-- MAIN APP DEPOTS / PACKAGES
addappid(933572,0,"5f97aa5a53a963d247864ccf5050d670efe3c5b48f6f4f6a4dc499c8310d3102")

