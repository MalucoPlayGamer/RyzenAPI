-- Lua provided by SkyAPI 
-- Game: Pleasure Airlines
addappid(1085110)
addappid(1085111, 1, "f6edb9eaf0b903707366c3398fd92c71e95e89cf8237060f7e0114860734c982")
addappid(1085112, 1, "64972696398665a45f54a89f5c49a9bde4b10abed960b01ecc43c646da1e079f")
