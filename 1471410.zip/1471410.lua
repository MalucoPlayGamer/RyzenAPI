-- Lua provided by RyzenAPI
-- Game: 1471410

-- MAIN APPLICATION
addappid(1471410)
-- Game: addappid(1471410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471411, 1, "7736e6becbf754713c9a4974b4accd1e7eea9cc5f22721a9899ccb43010a8398")
