-- Lua provided by RyzenAPI
-- Game: Game: Wild Planet

-- MAIN APPLICATION
addappid(1323060)
-- Game: addappid(1323060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323061, 1, "800f3d8432013329398a1a5633f2f834545253f92d8a5885ed55ca959193cce5")
