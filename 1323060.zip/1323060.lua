-- Lua provided by RyzenAPI 
-- Game: Wild Planet
addappid(1323060)
addappid(1323061, 1, "800f3d8432013329398a1a5633f2f834545253f92d8a5885ed55ca959193cce5")
