-- Lua provided by RyzenAPI
-- Game: 2350180

-- MAIN APPLICATION
addappid(2350180)
-- Game: addappid(2350180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350181, 1, "0dd690b64ce7cd8a9c79f9432ea5c5fcb33b183d78e69013337cd6d4917c4a37")
