-- Lua provided by RyzenAPI
-- Game: Avoid - Sensory Overload

-- MAIN APPLICATION
addappid(286660)

-- MAIN APP DEPOTS / PACKAGES
addappid(286661, 1, "1a671158f7e8ec720176464b38545d22edf12052908186fb120c191a70b143d7")
