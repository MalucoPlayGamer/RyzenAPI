-- Lua provided by RyzenAPI
-- Game: The Last Plague: Blight Demo

-- MAIN APPLICATION
addappid(1741880)
-- Game: addappid(1741880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741882,0,"ec2b299652c425df2145c06831bea304b3e2d5c517829a06a9aff8f7f570fdb6")
