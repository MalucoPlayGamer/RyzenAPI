-- Lua provided by RyzenAPI
-- Game: Game: The Purring Quest

-- MAIN APPLICATION
addappid(409100)
-- Game: addappid(409100)

-- MAIN APP DEPOTS / PACKAGES
addappid(409101, 1, "e7bba4bf9cf69123db910521423fa4b6036d07255bc630fcf6430963848d6983")
