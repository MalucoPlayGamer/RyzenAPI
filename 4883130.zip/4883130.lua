-- Lua provided by RyzenAPI
-- Game: Nowhere House

-- MAIN APPLICATION
addappid(4883130) -- Nowhere House

-- MAIN APP DEPOTS / PACKAGES
addappid(4883131, 1, "a892ef01d35cbe7a866c39410d6c8cf34447ad27b0ee16ddeefa3f79ac4ae038") -- Depot 4883131
