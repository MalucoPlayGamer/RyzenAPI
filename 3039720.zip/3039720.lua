-- Lua provided by RyzenAPI 
-- Game: Sealed
addappid(3039720)
addappid(3039721, 1, "b1f476746cc5c79bb4245b3201dd785a308d354c61cb04ebf2e39a440ea31008")
