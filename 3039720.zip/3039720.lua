-- Lua provided by RyzenAPI
-- Game: Sealed

-- MAIN APPLICATION
addappid(3039720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3039721, 1, "b1f476746cc5c79bb4245b3201dd785a308d354c61cb04ebf2e39a440ea31008")

