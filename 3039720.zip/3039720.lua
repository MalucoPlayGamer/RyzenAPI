-- Lua provided by RyzenAPI
-- Game: 3039720

-- MAIN APPLICATION
addappid(3039720)
-- Game: addappid(3039720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039721, 1, "b1f476746cc5c79bb4245b3201dd785a308d354c61cb04ebf2e39a440ea31008")
