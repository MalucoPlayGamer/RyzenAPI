-- Lua provided by RyzenAPI
-- Game: 2226430

-- MAIN APPLICATION
addappid(2226430)
-- Game: addappid(2226430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226432,0,"3440e78392fbba4f1d65b654b9867eb20cdfcb50bd75c285bf0f064dd0c4ff4c")
addappid(2226433,0,"476d8e74d6baef15a7ad9492e6d454407bbeb1748ab5b8210539135ed70c807f")
