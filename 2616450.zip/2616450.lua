-- Lua provided by RyzenAPI
-- Game: Game: Populous™ II: Trials of the Olympian Gods

-- MAIN APPLICATION
addappid(2616450)
-- Game: addappid(2616450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616451, 1, "cff381d85a17fe8940211b70ae67d57a271a8b0268ab8eadf07cb64e13a126a1")
