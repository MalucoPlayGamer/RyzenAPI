-- Lua provided by RyzenAPI
-- Game: DashPanel

-- MAIN APPLICATION
addappid(715670)

-- MAIN APP DEPOTS / PACKAGES
addappid(715671, 1, "90974c5f4f72554e50495e425b80ed0e5485ca361cc79dedcad380ca2de3dfaa")
