-- Lua provided by RyzenAPI
-- Game: DashPanel

-- MAIN APPLICATION
addappid(715670)
addappid(754470)
addappid(755070)
addappid(755071)
addappid(755072)
addappid(755073)
addappid(778480)
addappid(1127510)
addappid(1379080)
addappid(1544190)
addappid(2061220)
addappid(3068040)
addappid(3776850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(715671, 1, "90974c5f4f72554e50495e425b80ed0e5485ca361cc79dedcad380ca2de3dfaa")

