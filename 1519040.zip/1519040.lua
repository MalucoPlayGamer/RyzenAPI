-- Lua provided by RyzenAPI
-- Game: Kombi Travels - Jigsaw Landscapes

-- MAIN APPLICATION
addappid(1519040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519041, 1, "44bea113c76710c7749a750724d1d6681594e9a4c92bebb01335ded345278b44")
