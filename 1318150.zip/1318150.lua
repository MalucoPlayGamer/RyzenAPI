-- Lua provided by SkyAPI 
-- Game: Beautiful Model2
addappid(1318150)
addappid(1318151, 1, "32df1e6df5af7f20aa41252c0b2c58af024e5f6b4c3e426400b8a6b3f0d8c587")
