-- Lua provided by SkyAPI 
-- Game: Black Market of Bulletphilia  ~ 100th Black Market.
addappid(2097720)
addappid(2097721, 1, "59a292d3938b8a6f6127ad7264cdaed62d5512a6200445640b0b204f5bf0d02b")
