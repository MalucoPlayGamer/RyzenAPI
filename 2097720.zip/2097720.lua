-- Lua provided by RyzenAPI
-- Game: Black Market of Bulletphilia  ~ 100th Black Market.

-- MAIN APPLICATION
addappid(2097720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2097721, 1, "59a292d3938b8a6f6127ad7264cdaed62d5512a6200445640b0b204f5bf0d02b")

