-- Lua provided by RyzenAPI
-- Game: Unworthy

-- MAIN APPLICATION
addappid(613190)

-- MAIN APP DEPOTS / PACKAGES
addappid(613191, 1, "aea3b47e31a1eca3d28965cd061b3baa4254d8d413fdc1e795cbc2d400cbb90e")
addappid(872420, 0, "b54547f183c6cbd23e4366488fbfe133c0a3178ea1d89bda08765aadb4ed7b28")
