-- Lua provided by RyzenAPI
-- Game: Solas and the White Winter

-- MAIN APPLICATION
addappid(813590)

-- MAIN APP DEPOTS / PACKAGES
addappid(813591, 1, "c365b0bdcbf7634146c6412b9ff3bf50056bfc2092036508e6a36564af9eb014")
