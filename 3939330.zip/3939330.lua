-- Lua provided by RyzenAPI
-- Game: Shoot! Is done

-- MAIN APPLICATION
addappid(3939330) -- Shoot! Is done

-- MAIN APP DEPOTS / PACKAGES
addappid(3939331, 1, "ea3e1d8c0689d17079176ff34b671b028dcf1b8cd4c841a036cb1af9ca8d2d09") -- Depot 3939331

