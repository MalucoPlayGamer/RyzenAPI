-- 3939330's Lua and Manifest Created by Hubcap Manifest
-- Shoot! Is done
-- Created: October 11, 2025 at 13:17:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3939330) -- Shoot! Is done
-- MAIN APP DEPOTS
addappid(3939331, 1, "ea3e1d8c0689d17079176ff34b671b028dcf1b8cd4c841a036cb1af9ca8d2d09") -- Depot 3939331
setManifestid(3939331, "390809081504987731", 713935786)