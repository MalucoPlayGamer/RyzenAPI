-- Lua provided by RyzenAPI
-- Game: Queen's Wish: The Conqueror

-- MAIN APPLICATION
addappid(1058130)
-- Game: addappid(1058130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058131, 1, "70be393becdf89ab909e2d8b11f722e5327f84f328f3def4aee3628eed0bf3e6")
addappid(1058132, 1, "c13081fcf5052a82eaadbdd9bee71c8179b457ca0634586f8026623479f3b3a5")
addappid(1146620, 0, "eceecfb5704fc225bcbf5a9a5f93a6f4744a104883ae5cea3fe30cb9e7597a43")
