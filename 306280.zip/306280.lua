-- Lua provided by RyzenAPI 
-- Game: AppID 306280
addappid(306280)
addappid(306281, 1, "67cd27851f817f991c2f23a070594e7a89da03ca65a2fa01d715485e70037881")
