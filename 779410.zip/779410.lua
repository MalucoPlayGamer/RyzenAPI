-- Lua provided by RyzenAPI
-- Game: addappid(779410)

-- MAIN APPLICATION
addappid(779410)

-- MAIN APP DEPOTS / PACKAGES
addappid(779411, 1, "b2908cfafa05352f53ff5a3fe92f0436465d40d730de3368def4b6c527e5ebd6")
