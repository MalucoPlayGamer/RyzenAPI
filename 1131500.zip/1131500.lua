-- Lua provided by RyzenAPI
-- Game: Hentai Vampire Soundtrack + Artbook

-- MAIN APPLICATION
addappid(1131500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131500,0,"7c342e951b92342ee1a1ca6c0c4dc86898cecb26519f2bd66b2fbd17a4a39377")
