-- Lua provided by RyzenAPI
-- Game: 732430

-- MAIN APPLICATION
addappid(732430)
-- Game: addappid(732430)

-- MAIN APP DEPOTS / PACKAGES
addappid(732431, 1, "52ff73e06c3cc683bc6f5e520890ceb348d8e10384fd65473d6b04e1c2d9b9ec")
addappid(732432, 1, "2f2b2163c42839f1358143bc31639104b2b005ed242dba2bc84bfecfb8ae4a90")
