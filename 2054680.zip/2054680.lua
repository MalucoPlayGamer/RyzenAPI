-- Lua provided by RyzenAPI
-- Game: Odd One Out

-- MAIN APPLICATION
addappid(2054680)
-- Game: addappid(2054680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054681, 1, "688c8c5ae02a2a1152b85e2c6f5f882272767e7d5feda70b377cbe67c5823a8d")
