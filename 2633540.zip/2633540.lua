-- Lua provided by RyzenAPI
-- Game: addappid(2633540)

-- MAIN APPLICATION
addappid(2633540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633541, 1, "904a3d6d11654c1d5932714422150a9a7dc5111faef0b9db352069d1eb9d7d23")
