-- Lua provided by RyzenAPI
-- Game: addappid(565200)

-- MAIN APPLICATION
addappid(565200)

-- MAIN APP DEPOTS / PACKAGES
addappid(565201, 1, "b4b25b1f3dec5afbc542239dc96ec4f421353a157a7e806dbbdfcc36155939fb")
