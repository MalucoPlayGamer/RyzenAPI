-- Lua provided by RyzenAPI 
-- Game: Disciples III - Renaissance Steam Special Edition
addappid(33670)
addappid(33671, 1, "c6d554a14868993d7e762e94c002f76a8ff293873896afc2d52e26b8dd38871a")
addappid(33672, 1, "ff38f46fc5ed80f898b33c36a37644a4556329d6221368fbbef99d3a045684a9")
addappid(33673, 1, "dee7663df0fa3674c3da7e26e8455f5c5587e375fb9cc7c97f61b5d399406fdf")
addappid(33674, 1, "877248e97bfa385e959fe349b229712a140eb0b7e3c7125516c3b2e7bf3e1a8c")
