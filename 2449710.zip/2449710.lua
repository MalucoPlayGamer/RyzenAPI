-- Lua provided by RyzenAPI 
-- Game: Town of Sins
addappid(2449710)
addappid(2449711, 1, "74cf88f1df971c8bfbf51064b1f9b97db24013c05df2bf42cd18ef7cb9eeaf60")
