-- Lua provided by RyzenAPI
-- Game: Hamburg: 'Neue Burg' VR

-- MAIN APPLICATION
addappid(2769660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769661, 1, "030e46093ff1488d89b94f27639b1fd7fdab464a632c8b2ac3100ab50ebc6406")

