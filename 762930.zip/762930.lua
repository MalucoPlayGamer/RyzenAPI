-- Lua provided by SkyAPI 
-- Game: Supipara - Chapter 2 Spring Has Come!
addappid(762930)
addappid(762931, 1, "81448f42ba6620fb4d7700620d08d9e3400a0d90af482e942e9476a937a61229")
