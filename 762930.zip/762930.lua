-- Lua provided by RyzenAPI
-- Game: Supipara - Chapter 2 Spring Has Come!

-- MAIN APPLICATION
addappid(762930)

-- MAIN APP DEPOTS / PACKAGES
addappid(762931, 1, "81448f42ba6620fb4d7700620d08d9e3400a0d90af482e942e9476a937a61229")

