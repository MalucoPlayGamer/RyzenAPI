-- Lua provided by RyzenAPI
-- Game: MadOut

-- MAIN APPLICATION
addappid(352170)
-- Game: addappid(352170)

-- MAIN APP DEPOTS / PACKAGES
addappid(352171, 1, "6b645bd10848b45931e7637d59096e506cddca1fe0099b43391434e01a4066be")
