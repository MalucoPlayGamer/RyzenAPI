-- Lua provided by RyzenAPI
-- Game: MadOut

-- MAIN APPLICATION
addappid(352170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(352171, 1, "6b645bd10848b45931e7637d59096e506cddca1fe0099b43391434e01a4066be")

