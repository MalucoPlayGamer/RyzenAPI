-- Lua provided by SkyAPI 
-- Game: JellyCar Worlds Demo
addappid(2099740)
addappid(2099741, 1, "dd7cc48f03e5a0dd491d6ef8774f933fc1de5ae19737af6bd462cae315bd388b")
