-- Lua provided by RyzenAPI
-- Game: 1826480

-- MAIN APPLICATION
addappid(1826480)
-- Game: addappid(1826480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826481, 1, "9a0d343f582904e7c1b1912ecafc52d609aea332f9a83de461460936043bcae5")
