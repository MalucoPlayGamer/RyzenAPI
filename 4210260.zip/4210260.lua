-- Lua provided by RyzenAPI
-- Game: Project: Station

-- MAIN APPLICATION
addappid(4210260) -- Project: Station

-- MAIN APP DEPOTS / PACKAGES
addappid(4210261, 1, "49cb00c7e4f3451fc8d9b73abce213c7c6dfc2228afa9b5eba18371ab6be305e") -- Depot 4210261

