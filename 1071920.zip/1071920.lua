-- Lua provided by RyzenAPI
-- Game: Foreign Frugglers

-- MAIN APPLICATION
addappid(1071920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1071921, 1, "cb2c28bb4c0e43ee6e58986e675bf9dde4d4a95f5e11b943115dcbab4ac7fb9c")
