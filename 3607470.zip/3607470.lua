-- Lua provided by RyzenAPI
-- Game: 虫林好汉：乌合之众

-- MAIN APPLICATION
addappid(3607470) -- 虫林好汉：乌合之众

-- MAIN APP DEPOTS / PACKAGES
addappid(3607471, 1, "f9a85630798c10065ee5a995ae6c39b6701397bdb6611bd97d2bb71c0d1e2c6d") -- Depot 3607471

