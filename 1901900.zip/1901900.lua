-- Lua provided by RyzenAPI
-- Game: Take Over Body 2

-- MAIN APPLICATION
addappid(1901900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901901, 1, "af7e7876bd50eb4940d20340c7b1a1bd6281ed68534c78db693760820b3a2f09")

