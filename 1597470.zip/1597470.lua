-- Lua provided by RyzenAPI
-- Game: Game: 31st prototype

-- MAIN APPLICATION
addappid(1597470)
-- Game: addappid(1597470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597471, 1, "46c66a60950252c414d823193f56fce51072615e7c2f21420c4857672e39c26c")
addappid(1597472, 1, "6903d4054e6f8af4c78af5757c2f83f362b5ee1fef7d490d8946176b5ea61e1c")
