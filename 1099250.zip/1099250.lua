-- Lua provided by RyzenAPI
-- Game: GTFO Beta

-- MAIN APPLICATION
addappid(1099250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099251, 1, "bc46abac735c432ebd7d46806158b8fbc841e84413eafddb877bd423cf5fe2a1")

