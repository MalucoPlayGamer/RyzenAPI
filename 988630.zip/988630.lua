-- Lua provided by RyzenAPI
-- Game: AppID 988630

-- MAIN APPLICATION
addappid(988630)

-- MAIN APP DEPOTS / PACKAGES
addappid(988631, 1, "06ea62ca3f44dc1f592e79e0b38ba3ef372d21afbe54bf0418eb9236ed6e7888")
