-- Lua provided by RyzenAPI
-- Game: Game: AppID 1768420

-- MAIN APPLICATION
addappid(1768420)
-- Game: addappid(1768420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768421, 1, "2d12781604bf71f3e65946e7b34cf0e9bff9815948b11399c508e42c2a122c41")
