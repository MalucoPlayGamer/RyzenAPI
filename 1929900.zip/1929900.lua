-- Lua provided by RyzenAPI
-- Game: addappid(1929900)

-- MAIN APPLICATION
addappid(1929900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929901, 1, "c9eef4afda7fa5e0aff9a73afd7671d81faa6054a4364e657b827254d87ac80a")
