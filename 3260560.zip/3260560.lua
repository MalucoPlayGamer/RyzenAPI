-- Lua provided by RyzenAPI
-- Game: 天际都市物语 Demo

-- MAIN APPLICATION
addappid(3260560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260561, 1, "49b254c2170fbcd6311f07732c0345f3ac1f17a026b6ab800af1646fa231f965")

