-- Lua provided by RyzenAPI
-- Game: 1771180

-- MAIN APPLICATION
addappid(1771180)
-- Game: addappid(1771180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771182,0,"fea6fb0c8569b6a14ae84850168f001226abec7c9cafa685a8c61a4618ad683d")
