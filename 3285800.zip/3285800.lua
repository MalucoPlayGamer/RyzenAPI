-- Lua provided by SkyAPI 
-- Game: AppID 3285800
addappid(3285800)
addappid(3285801, 1, "4361a07cff901d939f8dcc48eb4857cae8d09bd04117328f1e14ab8cd4969910")
