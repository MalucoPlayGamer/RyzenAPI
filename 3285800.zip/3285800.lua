-- Lua provided by RyzenAPI
-- Game: AppID 3285800

-- MAIN APPLICATION
addappid(3285800)
-- Game: addappid(3285800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285801, 1, "4361a07cff901d939f8dcc48eb4857cae8d09bd04117328f1e14ab8cd4969910")
