-- Lua provided by RyzenAPI
-- Game: VR Cops

-- MAIN APPLICATION
addappid(884220)
addappid(2159790)
addappid(2159800)
addappid(2159801)
addappid(2159810)
addappid(2382830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(884222,0,"daddfa018639b2c0c3edaa0cef7b543142f7e0df455b17d4ad4d032f5df8319d")

