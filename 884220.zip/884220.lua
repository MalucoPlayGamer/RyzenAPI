-- Lua provided by RyzenAPI
-- Game: VR Cops

-- MAIN APPLICATION
addappid(884220)
addappid(2159790)
addappid(2159800)
addappid(2159801)
addappid(2159810)
addappid(2382830)

-- MAIN APP DEPOTS / PACKAGES
addappid(884222,0,"daddfa018639b2c0c3edaa0cef7b543142f7e0df455b17d4ad4d032f5df8319d")

