-- Lua provided by RyzenAPI
-- Game: VR Cops

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(884220)
-- Game: addappid(884220)

-- MAIN APP DEPOTS / PACKAGES
addappid(884222,0,"daddfa018639b2c0c3edaa0cef7b543142f7e0df455b17d4ad4d032f5df8319d")
