-- Lua provided by RyzenAPI
-- Game: Battle Shapers Soundtrack

-- MAIN APPLICATION
addappid(2632470)
-- Game: addappid(2632470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632471, 1, "f1152005467bfc106fbaf745e20f6b00175f5d052d5394bf0f0d2eb573b5ef39")
