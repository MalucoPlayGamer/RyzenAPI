-- Lua provided by RyzenAPI
-- Game: The Grinch: Christmas Adventures

-- MAIN APPLICATION
addappid(1978210)
addappid(3694440)
-- Game: addappid(1978210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978211, 1, "f5321f47ddc16c376743aac65457034d4c27eb8242cac9d34e524ed2ce6d6bef")
