-- Lua provided by RyzenAPI
-- Game: Atomic Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1516840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516840,0,"12ff0294d58b7202568037620c8ee8c07ddfd41772c55e6a074e4dec5db86991")

