-- Lua provided by RyzenAPI
-- Game: addappid(1787450)

-- MAIN APPLICATION
addappid(1787450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787451, 1, "224739ed54d8065ddf51343e1def0996ab643397ba1344eee68e897ce8e6c270")
