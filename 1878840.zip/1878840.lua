-- Lua provided by RyzenAPI
-- Game: Luna: Supernatural Hunter

-- MAIN APPLICATION
addappid(1878840)
-- Game: addappid(1878840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878841, 1, "81a611cd2c8d3e86adf83e46201f902f859314146b47dbae7f8f068573879690")
