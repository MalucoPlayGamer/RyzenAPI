-- Lua provided by SkyAPI 
-- Game: Swordsman
addappid(2914060)
addappid(2914061, 1, "b9cbc477df8ce46485ca13cafbf1748acee2d85669e7be4f6decdded167bd217")
