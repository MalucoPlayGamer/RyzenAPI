-- Lua provided by RyzenAPI
-- Game: 2914060

-- MAIN APPLICATION
addappid(2914060)
-- Game: addappid(2914060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914061, 1, "b9cbc477df8ce46485ca13cafbf1748acee2d85669e7be4f6decdded167bd217")
