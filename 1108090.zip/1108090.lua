-- Lua provided by RyzenAPI
-- Game: AppID 1108090

-- MAIN APPLICATION
addappid(1108090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1108091, 1, "418809a911de9c9201f1b641a74a84a2a9d7aacf2dba7bd154af2c721384b772")

