-- Lua provided by RyzenAPI
-- Game: Game: AppID 1583880

-- MAIN APPLICATION
addappid(1583880)
-- Game: addappid(1583880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583881, 1, "ff6d2fbf0496f7e7704f3e969d20e574a3fa63ab1e50f25bb5a73cae21d0c086")
