-- Lua provided by RyzenAPI 
-- Game: GOVNOVOZ
addappid(3387560)
addappid(3387561, 1, "dd884ff5968d0150be99308a606b0e3bd16442e0ecc396bed7f274b08d255ea1")
