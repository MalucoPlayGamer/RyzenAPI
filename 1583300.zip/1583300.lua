-- Lua provided by RyzenAPI
-- Game: Game: Cute Girls: Find Secrets

-- MAIN APPLICATION
addappid(1583300)
-- Game: addappid(1583300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583301, 1, "1a1258ca7560e377e9472aafbc29c07d282be6313c050f98a3a02fc3dae43489")
