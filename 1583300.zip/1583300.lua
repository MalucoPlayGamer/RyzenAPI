-- Lua provided by SkyAPI 
-- Game: Cute Girls: Find Secrets
addappid(1583300)
addappid(1583301, 1, "1a1258ca7560e377e9472aafbc29c07d282be6313c050f98a3a02fc3dae43489")
