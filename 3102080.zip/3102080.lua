-- Lua provided by RyzenAPI
-- Game: addappid(3102080)

-- MAIN APPLICATION
addappid(3102080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102081, 1, "72b9be2ee5df71059b166e1c7012757db8a07e1e149dee49ca9b1cf9881ce7cf")
