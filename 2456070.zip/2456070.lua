-- Lua provided by RyzenAPI
-- Game: Motorbike Evolution 2024

-- MAIN APPLICATION
addappid(2456070)
-- Game: addappid(2456070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456071, 1, "8553e180c795f31d0e1900f1a553b0b52bcfdb38d430d30b6a019715ce498909")
