-- Lua provided by RyzenAPI
-- Game: 2403860

-- MAIN APPLICATION
addappid(2403860)
-- Game: addappid(2403860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403860,0,"6129b68d9fef4e4a498c6c568c3db7509105ee7ee0a195877c041d57ef0f92d3")
