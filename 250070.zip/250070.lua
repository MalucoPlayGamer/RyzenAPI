-- Lua provided by RyzenAPI
-- Game: TorqueL

-- MAIN APPLICATION
addappid(250070)

-- MAIN APP DEPOTS / PACKAGES
addappid(250071, 1, "517460780c338aafd8eb6341aa22fd48750f7604f9c3bfd31e86da65b1be4b84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
