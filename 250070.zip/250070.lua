-- Lua provided by RyzenAPI
-- Game: 250070

-- MAIN APPLICATION
addappid(250070)
-- Game: addappid(250070)

-- MAIN APP DEPOTS / PACKAGES
addappid(250071, 1, "517460780c338aafd8eb6341aa22fd48750f7604f9c3bfd31e86da65b1be4b84")
