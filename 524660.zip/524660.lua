-- Lua provided by RyzenAPI
-- Game: 524660

-- MAIN APPLICATION
addappid(524660)
-- Game: addappid(524660)

-- MAIN APP DEPOTS / PACKAGES
addappid(524661, 1, "667216d1e037ad6011ef1b1a2cd8dc91df816ab8a544df61f5c9f367e2be95fe")
addappid(649390, 0, "7b2dd837de7ec7b4d3b39054626ad925b23f5c9699e12052ef1189b416e92c8e")
