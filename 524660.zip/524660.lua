-- Lua provided by RyzenAPI
-- Game: RutonyChat

-- MAIN APPLICATION
addappid(524660)

-- MAIN APP DEPOTS / PACKAGES
addappid(524661, 1, "667216d1e037ad6011ef1b1a2cd8dc91df816ab8a544df61f5c9f367e2be95fe")
addappid(649390, 0, "7b2dd837de7ec7b4d3b39054626ad925b23f5c9699e12052ef1189b416e92c8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(846280)
addappid(1358330)
