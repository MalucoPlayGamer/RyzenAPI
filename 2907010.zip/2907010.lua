-- Lua provided by RyzenAPI
-- Game: FIND KITTENS: The last of cats

-- MAIN APPLICATION
addappid(2907010)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2918610)
addappid(3434230)
