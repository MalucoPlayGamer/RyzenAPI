-- Lua provided by RyzenAPI
-- Game: FIND KITTENS: The last of cats

-- MAIN APPLICATION
addappid(2907010)
