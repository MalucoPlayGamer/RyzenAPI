-- Lua provided by RyzenAPI
-- Game: FIND KITTENS: The last of cats

-- MAIN APPLICATION
addappid(2907010)
addappid(2918610)
addappid(3434230)

