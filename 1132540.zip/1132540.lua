-- Lua provided by RyzenAPI
-- Game: Colonies End

-- MAIN APPLICATION
addappid(1132540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132541, 1, "c964be8815b616e29a1b2163c01818f3659be733ee8dbaba1f157a58a704533f")
