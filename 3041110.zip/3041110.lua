-- Lua provided by RyzenAPI
-- Game: 中传有戏

-- MAIN APPLICATION
addappid(3041110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3041111, 1, "9df2c0a2d5ecff68900b8794371cd330883dc244ac7a8ae5143d97083aa70229")

