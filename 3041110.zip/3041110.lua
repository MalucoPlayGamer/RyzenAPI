-- Lua provided by RyzenAPI
-- Game: 中传有戏

-- MAIN APPLICATION
addappid(3041110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041111, 1, "9df2c0a2d5ecff68900b8794371cd330883dc244ac7a8ae5143d97083aa70229")

