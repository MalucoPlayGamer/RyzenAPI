-- Lua provided by RyzenAPI
-- Game: addappid(3496550)

-- MAIN APPLICATION
addappid(3496550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496551, 1, "f3c8cd52988cc36ff8e6e6b60a066e7786b2181f2008a167aec296bafc479f68")
