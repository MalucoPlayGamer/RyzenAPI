-- Lua provided by RyzenAPI
-- Game: 559910

-- MAIN APPLICATION
addappid(559910)
addappid(559911)
addappid(559912)
addappid(559913)
addappid(559915)
addappid(559916)
-- Game: addappid(559910)

-- MAIN APP DEPOTS / PACKAGES
addappid(559914,0,"01cc910ff0bf7b18005f21c7e366af1b63c5d9b7f9138b042ecfafc03cbe08fd")
addappid(1004450,0,"6c79af8c30459d74a72b3301f336c411666d97adb6f0d0aae8e4d32ef4ea0fc2")
