-- Lua provided by RyzenAPI
-- Game: BoX -containment-

-- MAIN APPLICATION
addappid(479150)
-- Game: addappid(479150)

-- MAIN APP DEPOTS / PACKAGES
addappid(479151, 1, "6ca3795268d4d43710045f0630bf59683e68343ab913361d396d2a90a492b970")
