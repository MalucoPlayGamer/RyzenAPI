-- Lua provided by RyzenAPI
-- Game: GetsuFumaDen: Undying Moon - Digital Art Book

-- MAIN APPLICATION
addappid(1556590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556590,0,"3b8143bd3251f409580fb18256771a720bd4d760629acc9dcc32b9895647dd62")

