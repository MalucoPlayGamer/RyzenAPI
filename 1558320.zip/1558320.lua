-- Lua provided by RyzenAPI
-- Game: Sky Goddess

-- MAIN APPLICATION
addappid(1558320)
addappid(1558341)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558321, 1, "a4f399c229490b40c3f1ea62e773e0848223b4c29907f0f6f4c3ee5df303a061")

