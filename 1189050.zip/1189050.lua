-- Lua provided by RyzenAPI 
-- Game: AppID 1189050
addappid(1189050)
addappid(1189051, 1, "a53abd96bf3c0feb10119c183208d1b9ad9270d6f5bd3d431c31b8ffafa8477e")
addappid(1219410, 0, "9a7dadd3e40505cf113ad592b63d1209406cfb0490b98cc0f1b4a678fd01647e")
addappid(1223000, 0, "c8805ce3f461b34f5ccd27532a927ed16cd948ca5cdfd3d9ef6fde8d05dfb3ec")
