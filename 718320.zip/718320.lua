-- Lua provided by RyzenAPI 
-- Game: AppID 718320
addappid(718320)
addappid(718321, 1, "019e3eeb19cc3566853a54aea29d88d8d54a00d8d46ff062f8b57be20d43ab95")
