-- Lua provided by RyzenAPI
-- Game: addappid(7260)

-- MAIN APPLICATION
addappid(7260)

-- MAIN APP DEPOTS / PACKAGES
addappid(7261, 1, "af54090953f9c5cbf6d7376024ab61b8225db1e08ca5f0270c12b1920fe32c55")
addappid(7262, 1, "a23a8e4ebdcf40d7123c4ee1d18151ebc96c8cb5c7c3bf1de746648d5a01d7f0")
addappid(7263, 1, "9afdb23b7e23bdb1e1e62f163fecece116cd9f428317bc9185c87a5a31b2716b")
addappid(7264, 1, "ab13bf0b9c25b5a13be3224a450bca2a040ba79f90314e9b50fbd9633a87b723")
addappid(7265, 1, "88c153c9f4c91aafab1e3e6161bc79a30b99290600a9af0f9763eede923e14f8")
