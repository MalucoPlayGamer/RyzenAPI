-- Lua provided by RyzenAPI
-- Game: addappid(2462780)

-- MAIN APPLICATION
addappid(2462780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462780,0,"dd1595f16ac8a2836cde2e84389b996551cd9f56d644fd23a2c0fbd758845a4d")
