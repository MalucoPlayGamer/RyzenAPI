-- Lua provided by RyzenAPI
-- Game: Bad Lady

-- MAIN APPLICATION
addappid(1254500)
-- Game: addappid(1254500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254501, 1, "99ed04238428660a936ab2e18fcfb03b36677ae45fc43d98f1a55b4fc11911ce")
