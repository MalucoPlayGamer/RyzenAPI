-- Lua provided by SkyAPI 
-- Game: Bad Lady
addappid(1254500)
addappid(1254501, 1, "99ed04238428660a936ab2e18fcfb03b36677ae45fc43d98f1a55b4fc11911ce")
