-- Lua provided by RyzenAPI
-- Game: 1560200

-- MAIN APPLICATION
addappid(1560200)
-- Game: addappid(1560200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560201, 1, "649d4e182701e41cffc54aa5fd4e35c946a60b718afb5b9b83066926d94f38f5")
