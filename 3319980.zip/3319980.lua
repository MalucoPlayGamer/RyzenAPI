-- Lua provided by RyzenAPI
-- Game: Game: AppID 3319980

-- MAIN APPLICATION
addappid(3319980)
-- Game: addappid(3319980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319981, 1, "beff603934cd406501df117644006c112bd48a71b1c1a0963e5e267ac56127d9")
