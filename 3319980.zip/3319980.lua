-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Kai no Kiseki -Farewell, O Zemuria-

-- MAIN APPLICATION
addappid(3319980)
addappid(3321870)
addappid(3321920)
addappid(3321930)
addappid(3321940)
addappid(3321950)
addappid(3321960)
addappid(3321970)
addappid(3321980)
addappid(3321990)
addappid(3444250)
addappid(3444270)
addappid(3444280)
addappid(3444290)
addappid(3444300)
addappid(3444310)
addappid(3444320)
addappid(3444330)
addappid(3444340)
addappid(3447450)
addappid(3447470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3319981, 1, "beff603934cd406501df117644006c112bd48a71b1c1a0963e5e267ac56127d9")
