-- Lua provided by SkyAPI 
-- Game: AppID 3319980
addappid(3319980)
addappid(3319981, 1, "beff603934cd406501df117644006c112bd48a71b1c1a0963e5e267ac56127d9")
