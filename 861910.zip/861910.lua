-- Lua provided by RyzenAPI
-- Game: Catch'em

-- MAIN APPLICATION
addappid(861910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(861911,0,"bde0ba06d2bed2c0c05e96d68205dac440b52e364bb7c1d33deeecb1f1458e00")

