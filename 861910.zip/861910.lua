-- Lua provided by RyzenAPI
-- Game: Catch'em

-- MAIN APPLICATION
addappid(861910)

-- MAIN APP DEPOTS / PACKAGES
addappid(861911,0,"bde0ba06d2bed2c0c05e96d68205dac440b52e364bb7c1d33deeecb1f1458e00")

