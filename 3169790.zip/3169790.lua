-- Lua provided by RyzenAPI 
-- Game: AppID 3169790
addappid(3169790)
addappid(3169791, 1, "10edcf41a99c068a6998ddc8beba9aa56a0fd61c670cf707d18a6a787888e826")
