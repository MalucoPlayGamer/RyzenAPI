-- Lua provided by RyzenAPI
-- Game: 2877690

-- MAIN APPLICATION
addappid(2877690)
-- Game: addappid(2877690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877691, 1, "07aa72c035e83b6ee06f7000946eb315b9d11a3ccf3774713b4b9dd2999e97ee")
