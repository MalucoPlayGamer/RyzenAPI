-- Lua provided by RyzenAPI
-- Game: Game: Dragon Age™: Origins Awakening

-- MAIN APPLICATION
addappid(47730)
-- Game: addappid(47730)

-- MAIN APP DEPOTS / PACKAGES
addappid(47731, 1, "d67781b2f9215cc47516ce20ce19e51a3eef8ef16fbab0da55e716bf23e8c637")
addappid(47732, 1, "3b78bff4d725fb6b5529ff12a5d6feed62fdb1d161507da2311b6cf856eef0f8")
addappid(47733, 1, "dcb300f22879aeb5e28d38de73bcac24402071e6e9bb4facc2ac53cf4d8bc324")
addappid(47734, 1, "9ca0b0967dfda16307d6237217f2328191a77af0f9dc8db31d142172e4405b40")
addappid(47735, 1, "7953382ab71196cec2b7978bb09736082791bf1d9204cf7a7284a81b2ac78528")
addappid(47736, 1, "bb5b38d9c14052bff1e6fa0d3021e4bd5172360088f211e5ee834e63737d9328")
addappid(47737, 1, "4ac1640a5534c792078e74ea66f42ff88ba94b6eeb30f84e711a6433bde457f2")
addappid(47738, 1, "ebb95e450ac5bc7e128812e694645aaeae01938e2ba9ec27f68f18bee6423a15")
addappid(47740, 1, "699bcffe63c3a4caa95844efa6dd6d3ffa39e0465beca481939663866dc23b36")
