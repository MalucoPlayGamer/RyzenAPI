-- Lua provided by RyzenAPI
-- Game: addappid(1711400)

-- MAIN APPLICATION
addappid(1711400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711401, 1, "9ad2fe12e0b4929c8590eb1011fbd77b78d172ee29f101e5ff3aedbd282c77c4")
