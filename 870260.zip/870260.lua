-- Lua provided by RyzenAPI
-- Game: AppID 870260

-- MAIN APPLICATION
addappid(870260)

-- MAIN APP DEPOTS / PACKAGES
addappid(870261, 1, "8444dd63905ff18cef3cdffab27f5d91a1f4b057c456c678a5bcba1595ebbde5")

