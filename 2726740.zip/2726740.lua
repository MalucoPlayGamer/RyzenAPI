-- Lua provided by RyzenAPI
-- Game: Don't Text and Drive

-- MAIN APPLICATION
addappid(2726740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726741, 1, "81de1467e1e653398af7fcf4dc57a821e7b00c3cd64ed1bcba3f74e123cca03f")

