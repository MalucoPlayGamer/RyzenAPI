-- Lua provided by RyzenAPI 
-- Game: AppID 1323190
addappid(1323190)
addappid(1323191, 1, "5258651e992f1ac9e14c8f398ca93c1815e4111254ea8ddb9cfbf4db3bd5440c")
