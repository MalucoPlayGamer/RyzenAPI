-- Lua provided by RyzenAPI
-- Game: addappid(1323190)

-- MAIN APPLICATION
addappid(1323190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323191, 1, "5258651e992f1ac9e14c8f398ca93c1815e4111254ea8ddb9cfbf4db3bd5440c")
