-- Lua provided by RyzenAPI
-- Game: The Fear Business

-- MAIN APPLICATION
addappid(2855770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855771, 1, "75728cb67238ba7fe6b4b181878de604442a8503cd85b34c361b1cc738b7522f")
