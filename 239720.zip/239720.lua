-- Lua provided by RyzenAPI
-- Game: Game: PAC-MAN™ and the Ghostly Adventures

-- MAIN APPLICATION
addappid(239720)
-- Game: addappid(239720)

-- MAIN APP DEPOTS / PACKAGES
addappid(239721, 1, "c34c740e183195aaba05b419041368f83efdc7def753cc521898b787f40a1f90")
