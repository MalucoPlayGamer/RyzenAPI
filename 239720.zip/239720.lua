-- Lua provided by RyzenAPI
-- Game: PAC-MAN™ and the Ghostly Adventures

-- MAIN APPLICATION
addappid(239720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(239721, 1, "c34c740e183195aaba05b419041368f83efdc7def753cc521898b787f40a1f90")

