-- Lua provided by RyzenAPI
-- Game: Jockey Rush

-- MAIN APPLICATION
addappid(500680)

-- MAIN APP DEPOTS / PACKAGES
addappid(500681, 1, "5bc2c5934118f2b0939abe59cdbd065b6f8e336bbad0a8e0683c24d51c53b7e0")
