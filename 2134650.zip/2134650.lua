-- Lua provided by RyzenAPI 
-- Game: New Yankee: Karma Tales
addappid(2134650)
addappid(2134651, 1, "22b8ceb259bb1250faae00b44e69db4c87f942cb64800ad42d0c7f01ae22a116")
addappid(2134652, 1, "20e4d0aa67150d9343d0de7fd0442bb27fe710982daba06e753d6e72e9741373")
