-- Lua provided by RyzenAPI
-- Game: AppID 331200

-- MAIN APPLICATION
addappid(331200)

-- MAIN APP DEPOTS / PACKAGES
addappid(331201, 1, "880aace7dc07a32e9a2d3c7671973e413b71f74a4c6e239cb611f08049d2e3eb")
addappid(331202, 1, "205244e7506dbf24b61e7441d482207fe23f39fb1f5fb87839e0fa6d78567fdc")
addappid(331203, 1, "37706c8a7d2f4e7fade5465b58a29060ac64cac9dae7b7a20dd822f95eb38b07")
addappid(331204, 1, "d40c370b6887650e87495af736eb15e3d2ba17e82197550438898482f4394f3a")
addappid(341610, 0, "466fd123d79fa5c82f7e0026154ba4a6981493f64463255456422c8a24e61d2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
