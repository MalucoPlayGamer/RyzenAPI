-- Lua provided by RyzenAPI
-- Game: Game: Haegemonia: Legions of Iron

-- MAIN APPLICATION
addappid(294770)
-- Game: addappid(294770)

-- MAIN APP DEPOTS / PACKAGES
addappid(294771, 1, "4a373463478406153d32d2c76fd3d17353cffa1cbbc4163043995615f43138bc")
addappid(294773, 1, "ba7c8aa894939de0de0fd11248f67c9f4bb50c9c2076ce04b21afd3d7de0857f")
addappid(294774, 1, "467803c9d07131458b1511249f87169ff88e5fa08e0af9f12cb8077e269e3c76")
addappid(294775, 1, "858c956f86f5cadaba00a4fc67203e23cc41a365906974148030d53e9d8184ed")
addappid(294776, 1, "2f1ec18189bf1a6ef733acec718efc3660c3443932240149dfc59feff117c7be")
