-- Lua provided by RyzenAPI
-- Game: 2508670

-- MAIN APPLICATION
addappid(2508670)
-- Game: addappid(2508670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508671, 1, "f4f70d7bfe2366198c4c9c80533f981053c96eadfa985181f01050c7dc6e3c07")
