-- Lua provided by RyzenAPI
-- Game: Reus 2 Demo

-- MAIN APPLICATION
addappid(1875061)
addappid(2563380)

