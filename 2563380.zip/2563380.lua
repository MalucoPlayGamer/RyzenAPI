-- Lua provided by RyzenAPI
-- Game: addappid(2563380)

-- MAIN APPLICATION
addappid(1875061)
addappid(2563380)

