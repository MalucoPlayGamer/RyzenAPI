-- Lua provided by RyzenAPI
-- Game: Galacticverse

-- MAIN APPLICATION
addappid(2656180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656181, 1, "3af8bb3a59556ce397465fbd88e2c62bc0ec5cc1f4f4fa4a9f6e692e230e13f8")
