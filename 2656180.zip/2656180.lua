-- Lua provided by SkyAPI 
-- Game: Galacticverse
addappid(2656180)
addappid(2656181, 1, "3af8bb3a59556ce397465fbd88e2c62bc0ec5cc1f4f4fa4a9f6e692e230e13f8")
