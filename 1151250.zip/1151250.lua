-- Lua provided by RyzenAPI
-- Game: AppID 1151250

-- MAIN APPLICATION
addappid(1151250)
-- Game: addappid(1151250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151251, 1, "55892b5dee52c0a03551550d89bcbb67c26ac3dd88ff14b60798c1c2404be33d")
