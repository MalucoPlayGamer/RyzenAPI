-- Lua provided by RyzenAPI
-- Game: AppID 1151250

-- MAIN APPLICATION
addappid(1151250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1151251, 1, "55892b5dee52c0a03551550d89bcbb67c26ac3dd88ff14b60798c1c2404be33d")

