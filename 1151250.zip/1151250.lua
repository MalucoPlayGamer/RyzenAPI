-- Lua provided by SkyAPI 
-- Game: AppID 1151250
addappid(1151250)
addappid(1151251, 1, "55892b5dee52c0a03551550d89bcbb67c26ac3dd88ff14b60798c1c2404be33d")
