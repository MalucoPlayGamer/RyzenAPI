-- Lua provided by RyzenAPI
-- Game: Obscurite Magie: The Blood of Kings

-- MAIN APPLICATION
addappid(2303810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303811, 1, "6a0cb76aef1d609defe1d3a6a0d15ba1c4e8f48beceba5b241926bb74ec9fe98")
addappid(2303812, 1, "e0a70fb5b351060504cb8f6a58c24c6455e4b3ed0e9b3198209d61bfc7d9c835")
addappid(2303813, 1, "85e49cb3533ba1f1e5738e8079cf65c10422fbb625822469236c6342d4bd159e")
