-- Lua provided by RyzenAPI
-- Game: AppID 1005950

-- MAIN APPLICATION
addappid(1005950)
-- Game: addappid(1005950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005951, 1, "d7f51a1ea8a79a28ec08842989e245ae8e7825b60c41ca2ee848dfe4fc149530")
