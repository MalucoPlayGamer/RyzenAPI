-- Lua provided by RyzenAPI
-- Game: addappid(3751150)

-- MAIN APPLICATION
addappid(3751150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751151, 1, "def1992297140d8e40a39e1cdfa2c04e9de970757b88b947a79efd6ba1b1e054")
