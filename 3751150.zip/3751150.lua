-- Lua provided by RyzenAPI
-- Game: Station 0 - المحطة 0

-- MAIN APPLICATION
addappid(3751150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751151, 1, "def1992297140d8e40a39e1cdfa2c04e9de970757b88b947a79efd6ba1b1e054")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
