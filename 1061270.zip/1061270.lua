-- Lua provided by RyzenAPI
-- Game: Blacklist Brigade

-- MAIN APPLICATION
addappid(1061270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061271, 1, "e989ca54f534f0c7e8ed4b0115895098816ab238993acf59c7353b5156d72cfc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
