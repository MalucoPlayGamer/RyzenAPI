-- Lua provided by SkyAPI 
-- Game: Blacklist Brigade
addappid(1061270)
addappid(1061271, 1, "e989ca54f534f0c7e8ed4b0115895098816ab238993acf59c7353b5156d72cfc")
