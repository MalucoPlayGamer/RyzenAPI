-- Lua provided by RyzenAPI
-- Game: 1061270

-- MAIN APPLICATION
addappid(1061270)
-- Game: addappid(1061270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061271, 1, "e989ca54f534f0c7e8ed4b0115895098816ab238993acf59c7353b5156d72cfc")
