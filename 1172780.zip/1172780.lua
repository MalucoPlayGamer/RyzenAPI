-- Lua provided by RyzenAPI
-- Game: Fences 5

-- MAIN APPLICATION
addappid(1172780)
-- Game: addappid(1172780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172781, 1, "42ea13fe7a3949bffe8fa649b31e8ce4c7458af239a5332c67caf7d1c18b1799")
