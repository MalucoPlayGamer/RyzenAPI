-- Lua provided by RyzenAPI 
-- Game: Fences 5
addappid(1172780)
addappid(1172781, 1, "42ea13fe7a3949bffe8fa649b31e8ce4c7458af239a5332c67caf7d1c18b1799")
