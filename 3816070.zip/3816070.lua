-- Lua provided by SkyAPI 
-- Game: Farm and Dishes
addappid(3816070)
addappid(3816071, 1, "3b9a4f4c500b9f83ac261e364aa88dcf9a98bb3d9d528d18da405263616d97d4")
