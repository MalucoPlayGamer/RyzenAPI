-- Lua provided by RyzenAPI
-- Game: Farm and Dishes

-- MAIN APPLICATION
addappid(3816070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3816071, 1, "3b9a4f4c500b9f83ac261e364aa88dcf9a98bb3d9d528d18da405263616d97d4")
