-- Lua provided by RyzenAPI
-- Game: Rem Survival

-- MAIN APPLICATION
addappid(228988)
addappid(228989)
addappid(228990)
addappid(574180)

-- MAIN APP DEPOTS / PACKAGES
addappid(574183,0,"cdd2f55806ecb15fd268dd047093038f31b1b3ed4d8f16b5700650b97a026adb")

