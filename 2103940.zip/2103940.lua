-- Lua provided by RyzenAPI
-- Game: Skate Rift

-- MAIN APPLICATION
addappid(2103940)
-- Game: addappid(2103940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103941, 1, "9e0afbb3e0a02a0c77440c374b6bfaa78edce2890eae7f161a2bbd7c4a25225d")
addappid(2103943, 1, "979ba31ef7199022b44d45d17cb9596a473504e497734b38364ea5e39a6bb759")
