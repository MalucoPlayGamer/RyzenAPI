-- Lua provided by RyzenAPI
-- Game: addappid(1446980)

-- MAIN APPLICATION
addappid(1446980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446981, 1, "f4e5619b7ffd7747ce9f5a52be0fdde2063bc97f046557e14156cc894ae62369")
