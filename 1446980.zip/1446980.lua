-- Lua provided by SkyAPI 
-- Game: Quick Square
addappid(1446980)
addappid(1446981, 1, "f4e5619b7ffd7747ce9f5a52be0fdde2063bc97f046557e14156cc894ae62369")
