-- Lua provided by RyzenAPI
-- Game: Quick Square

-- MAIN APPLICATION
addappid(1446980)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1446981, 1, "f4e5619b7ffd7747ce9f5a52be0fdde2063bc97f046557e14156cc894ae62369")

