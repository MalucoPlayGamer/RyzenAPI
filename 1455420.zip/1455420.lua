-- Lua provided by RyzenAPI
-- Game: Choco Pixel S

-- MAIN APPLICATION
addappid(1455420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455421, 1, "a772f8c72aa67b89a3d9e2355ed694e69f7a1e1fe7cae8e64d85d048aff4df8e")
