-- Lua provided by SkyAPI 
-- Game: Choco Pixel S
addappid(1455420)
addappid(1455421, 1, "a772f8c72aa67b89a3d9e2355ed694e69f7a1e1fe7cae8e64d85d048aff4df8e")
