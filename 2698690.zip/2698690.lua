-- Lua provided by RyzenAPI
-- Game: addappid(2698690)

-- MAIN APPLICATION
addappid(2698690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698691, 1, "fff6e78c2c5a406c371257b11f9553f46c4b9b494dec826f11eef40c49fe5d0a")
