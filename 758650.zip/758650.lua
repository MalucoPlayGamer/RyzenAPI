-- Lua provided by RyzenAPI
-- Game: Haunted Train: Frozen in Time Collector's Edition

-- MAIN APPLICATION
addappid(758650)

-- MAIN APP DEPOTS / PACKAGES
addappid(758651,0,"5ae615af67238872764a203e098d9e4b8db6255f640a577e8b9c4a259c63c197")

