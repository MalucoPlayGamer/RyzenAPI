-- Lua provided by RyzenAPI
-- Game: First Samurai

-- MAIN APPLICATION
addappid(1672350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672351, 1, "44faf67cb260103ae21b466b4132c4f19f0430f64c32cbd5bd36f123fa5b6ce6")

