-- Lua provided by RyzenAPI
-- Game: Disney's Chicken Little: Ace in Action

-- MAIN APPLICATION
addappid(338300)

-- MAIN APP DEPOTS / PACKAGES
addappid(338301, 1, "08a5f175fa666a601fc5f9aa518c0937cfc52a88a65700db41ad4e3dffb94bbf")
addappid(338302, 1, "8aa73c621727618eb2176065315c9f76a1a0ded0e378bee28aeec16731a63614")
addappid(338303, 1, "a8f9b45269c63cfac5619d0282cd4710369efc61ecf4d22dc7a1f1fa59ba8baa")
addappid(338304, 1, "054a343fad1cf65784db37ca4e057e2633a0fb8bef8f59fd0b4d9947b851a67c")
addappid(338305, 1, "bb8e6d38176967ea75dfb19fa4db5dea442002616f578e6f96f32dae5419deaa")
addappid(338306, 1, "ab1b09646bf72293971ff624a699ae37bc7f0f9a114baba31913a0ef4b5bae1b")
addappid(338307, 1, "afb408a17fab2eedc89720b641decfbd738030e79645d74326716119fb08e942")
addappid(338308, 1, "046ddcc2ccfba53e85ed0b916a05c439afc69512c5e9de09f2d0b54c3c8ae966")
addappid(338309, 1, "fc4d48733bc6cdd7b84ff3f4240f06a533cf2fb4fc653c58e56735773e1ca5e2")

