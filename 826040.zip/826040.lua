-- Lua provided by RyzenAPI
-- Game: AppID 826040

-- MAIN APPLICATION
addappid(826040)

-- MAIN APP DEPOTS / PACKAGES
addappid(826041, 1, "a81df54b52f8f824d7466ec86468e73decb5200fa8e2bb4fb411043204f627b9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(864050)
