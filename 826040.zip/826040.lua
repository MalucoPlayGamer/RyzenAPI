-- Lua provided by SkyAPI 
-- Game: AppID 826040
addappid(826040)
addappid(826041, 1, "a81df54b52f8f824d7466ec86468e73decb5200fa8e2bb4fb411043204f627b9")
