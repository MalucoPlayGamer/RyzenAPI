-- Lua provided by RyzenAPI
-- Game: 496930

-- MAIN APPLICATION
addappid(496930)
addappid(496931)
addappid(496932)
addappid(509300)
-- Game: addappid(496930)

-- MAIN APP DEPOTS / PACKAGES
addappid(496933,0,"1f77fb5f4396563c74af8c004ee43c0729d94407137f703a0bb8a699a69b1bcc")
