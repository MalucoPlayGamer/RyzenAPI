-- Lua provided by RyzenAPI
-- Game: Soul Wargame

-- MAIN APPLICATION
addappid(1952930)
-- Game: addappid(1952930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952931, 1, "bee25409733e48fb654699ea9b1e0c00113f2521a208016fd58a7154ea9978a0")
