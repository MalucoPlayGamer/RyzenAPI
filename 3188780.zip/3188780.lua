-- Lua provided by RyzenAPI
-- Game: WHIP: but not too much Demo

-- MAIN APPLICATION
addappid(3188780)
-- Game: addappid(3188780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188781, 1, "0561cdfa5129abd22b4bdff43bcb5e56cc35de0cfe8145b41a8a54d2ce195d11")
