-- Lua provided by RyzenAPI
-- Game: Factory Town Idle

-- MAIN APPLICATION
addappid(2207490)
-- Game: addappid(2207490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207491, 1, "897860484f7d9751e73184572b646fb0bf9aa699d0dc8530ed0f740a07984560")
