-- Lua provided by RyzenAPI
-- Game: FarSky

-- MAIN APPLICATION
addappid(286340)

-- MAIN APP DEPOTS / PACKAGES
addappid(286341, 1, "3513598f201c1465b065c7faaada03b78a50d7388e758ece2fae95f73ac6f1e8")

