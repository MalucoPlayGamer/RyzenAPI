-- Lua provided by RyzenAPI
-- Game: addappid(2545010)

-- MAIN APPLICATION
addappid(2545010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545011, 1, "0bdb738769867cfde7ab61bc3cbad52765f0ab409164177a404cf08c09d08099")
