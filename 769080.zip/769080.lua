-- Lua provided by RyzenAPI
-- Game: The Little War

-- MAIN APPLICATION
addappid(769080)

-- MAIN APP DEPOTS / PACKAGES
addappid(769081,0,"bf283edd282d36941fe703224e77aa23a3fd183db95f1aae513b13dfe4aaa9e9")

