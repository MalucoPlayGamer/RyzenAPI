-- Lua provided by RyzenAPI 
-- Game: File Destined
addappid(2257460)
addappid(2257461, 1, "4fd9cf03e77d187cee38c622753567b637ab4d8257f40f002014942a76c8e30f")
