-- Lua provided by RyzenAPI
-- Game: 2889290

-- MAIN APPLICATION
addappid(2889290)
-- Game: addappid(2889290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889291, 1, "de5c3a4740f5bd6509987f34e6f43d5b75aee0869a3c3b8b57ff28027fe1c404")
