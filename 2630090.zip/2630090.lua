-- Lua provided by RyzenAPI
-- Game: Game: AppID 2630090

-- MAIN APPLICATION
addappid(2630090)
-- Game: addappid(2630090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630091, 1, "84bed86929db488f2840dede18d47af9a0f6b6cad2a6871e1b40303d791194e8")
