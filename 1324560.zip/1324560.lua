-- Lua provided by RyzenAPI
-- Game: Krum - Battle Arena

-- MAIN APPLICATION
addappid(1324560)
addappid(1359880)
addappid(1361420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1324561, 1, "972e1029921de74796fb044325dbee8f23d39138ddb82d4135d77a035f73d3d2")

