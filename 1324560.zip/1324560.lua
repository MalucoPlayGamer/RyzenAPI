-- Lua provided by RyzenAPI
-- Game: Krum - Battle Arena

-- MAIN APPLICATION
addappid(1324560)
-- Game: addappid(1324560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324561, 1, "972e1029921de74796fb044325dbee8f23d39138ddb82d4135d77a035f73d3d2")
