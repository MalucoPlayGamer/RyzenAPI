-- Lua provided by RyzenAPI
-- Game: addappid(1340560)

-- MAIN APPLICATION
addappid(1340560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340561, 1, "433601c7c183a69d0f137f9917dc4bc11396f0c5d7efdf1336bc13fa0ffb4904")
