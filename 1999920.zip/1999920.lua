-- Lua provided by RyzenAPI
-- Game: Game: Red List Girls. -Andean Flamingo-

-- MAIN APPLICATION
addappid(1999920)
-- Game: addappid(1999920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999921, 1, "b8db38030b6b71c271004662350be56f90762a7bd0455bc11800e3fcd7234e0e")
