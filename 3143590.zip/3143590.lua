-- Lua provided by RyzenAPI
-- Game: Game: All in Abyss: Judge the Fake Demo

-- MAIN APPLICATION
addappid(3143590)
-- Game: addappid(3143590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143591, 1, "01ef80c81d01f900a8cb8b00518d88e2b67ab8b754d91f931a11eb6a772c1520")
