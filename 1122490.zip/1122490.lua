-- Lua provided by RyzenAPI
-- Game: Battleheart Legacy

-- MAIN APPLICATION
addappid(1122490)
-- Game: addappid(1122490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122491, 1, "1efa18aa30d269bb6a7a988a95f186b397bd90c99df8add224aab44a7acfcaa9")
