-- Lua provided by RyzenAPI
-- Game: Dungeons & Dragons: Ravenloft Series

-- MAIN APPLICATION
addappid(1904560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1904561, 1, "1dc0d2da1dac66f263d4f9df06e1ed1838af426b71c7353cfd669865f7d10869")
addappid(1904570, 1, "21cf5d55fef0041b6a71d3290bfe82e9ff0bbd78e116cf39fdde8adaf67863d3")
addappid(1904571, 1, "750108ba130f35c62446041f0050d70b3b2885dc97911c73de97f0a23e804658")
