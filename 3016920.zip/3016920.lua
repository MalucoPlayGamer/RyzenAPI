-- Lua provided by RyzenAPI
-- Game: Game: Awaken: Hentai Dice

-- MAIN APPLICATION
addappid(3016920)
addappid(3347980)
addappid(3453170)
-- Game: addappid(3016920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016921, 1, "3f651ffe3e62f40c3a3359eeff2e7251707fe9367bbce65df51e287273255fad")
addappid(3296930, 0, "1d318bfeee7b1871cf53b4f4487e95b9889962a166b6cc3d123815617cb4f850")
addappid(3296940, 0, "bed706587164d7911a7055c5b0b3e1d508d59aedd99b91cd0713014b8cc22074")
addappid(3296950, 0, "480bfc3f2eb8b7a604b9582ccba095654d7c6142f76e356e336a2979a6fa74db")
