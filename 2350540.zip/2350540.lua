-- Lua provided by RyzenAPI
-- Game: Game: DeathKeep

-- MAIN APPLICATION
addappid(2350540)
-- Game: addappid(2350540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350541, 1, "22113aed402fd79e9e9d419d9342f05ca5aceef757db0418176dc2e7a190de98")
addappid(2350542, 1, "3d670afbd4575c40e3ff21711d445f084e55021bd31c3b7edbd673d008a861b6")
