-- Lua provided by RyzenAPI
-- Game: 3148120

-- MAIN APPLICATION
addappid(3148120)
-- Game: addappid(3148120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148121, 1, "103095c7f743aee67782dfc3cfd596dd8552d167f0d722e61cd44bc90a045f12")
