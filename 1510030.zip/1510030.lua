-- Lua provided by RyzenAPI
-- Game: Game: Knights College

-- MAIN APPLICATION
addappid(1510030)
-- Game: addappid(1510030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510031, 1, "4b6d4839e187ee85a9106864e0daa9812fd1c5615463465fe6b2d5880cee9552")
