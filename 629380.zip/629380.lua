-- Lua provided by RyzenAPI 
-- Game: AppID 629380
addappid(629380)
addappid(629381, 1, "8c430736c117fc4134c0c249c519e1f12a3b929f6d93ac3ce0be6338e2176679")
