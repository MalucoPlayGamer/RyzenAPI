-- Lua provided by RyzenAPI
-- Game: Game: Beach Invasion 1945 - Pacific

-- MAIN APPLICATION
addappid(2390480)
-- Game: addappid(2390480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390481, 1, "538c41454746d351e1d597c104f1b7e72d26101716e741373c32bdd69954a525")
addappid(2962360, 0, "4eee276bcb908c193fc2dfcadf3b044796c9b36c9770e20548e4b8479e19a9e8")
