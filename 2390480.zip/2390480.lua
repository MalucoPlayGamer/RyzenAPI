-- Lua provided by SkyAPI 
-- Game: Beach Invasion 1945 - Pacific
addappid(2390480)
addappid(2390481, 1, "538c41454746d351e1d597c104f1b7e72d26101716e741373c32bdd69954a525")
addappid(2962360, 0, "4eee276bcb908c193fc2dfcadf3b044796c9b36c9770e20548e4b8479e19a9e8")
