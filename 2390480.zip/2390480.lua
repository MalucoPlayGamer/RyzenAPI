-- Lua provided by RyzenAPI
-- Game: Beach Invasion 1945 - Pacific

-- MAIN APPLICATION
addappid(2390480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2390481, 1, "538c41454746d351e1d597c104f1b7e72d26101716e741373c32bdd69954a525")
addappid(2962360, 0, "4eee276bcb908c193fc2dfcadf3b044796c9b36c9770e20548e4b8479e19a9e8")

