-- Lua provided by RyzenAPI
-- Game: The Darkside Detective: A Fumble in the Dark Demo

-- MAIN APPLICATION
addappid(1386070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386071, 1, "b33cbc28501b7eafa429e4beef072439544c79afff48be1ecfc73e129f6cfd36")
