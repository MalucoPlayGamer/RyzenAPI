-- Lua provided by RyzenAPI
-- Game: addappid(512680)

-- MAIN APPLICATION
addappid(512680)

-- MAIN APP DEPOTS / PACKAGES
addappid(512681, 1, "0a65880ed188730daac1c7997e409361743310247d1f4bce19bd1c387a7d20d2")
