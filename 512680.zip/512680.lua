-- Lua provided by RyzenAPI
-- Game: Pan-Dimensional Conga Combat

-- MAIN APPLICATION
addappid(512680)

-- MAIN APP DEPOTS / PACKAGES
addappid(512681, 1, "0a65880ed188730daac1c7997e409361743310247d1f4bce19bd1c387a7d20d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
