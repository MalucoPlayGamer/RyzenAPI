-- Lua provided by RyzenAPI
-- Game: It came from space and ate our brains

-- MAIN APPLICATION
addappid(342620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(342621, 1, "4ad93afb49a071fec87a1a8f99b2258ee667a6beb0771f28cd728e86f61ae4c6")
addappid(342622, 1, "72a84c1eb5a8d7aa6531a91f32daa157d1d77b4fb0b363364e22124184f6f415")
addappid(342623, 1, "0d74a90b1eb963fd43090e07db4fc940861be471f2a664099437c08275231ca1")

