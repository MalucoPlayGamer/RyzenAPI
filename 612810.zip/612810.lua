-- Lua provided by RyzenAPI
-- Game: addappid(612810)

-- MAIN APPLICATION
addappid(612810)
addappid(612811)
addappid(612812)
addappid(612814)

-- MAIN APP DEPOTS / PACKAGES
addappid(612813,0,"40a8a547b3e9827a876246c7ea11cd36e4154c0e041bae2c158fca5c8c8b2c3d")
