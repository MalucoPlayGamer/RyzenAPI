-- Lua provided by RyzenAPI
-- Game: addappid(3236230)

-- MAIN APPLICATION
addappid(3236230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236231, 1, "996f29b5676288ce450555a5edb438216f603f549ad991c96512edbe5de20f1b")
