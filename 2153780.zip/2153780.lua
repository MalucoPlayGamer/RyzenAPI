-- Lua provided by SkyAPI 
-- Game: Survival Nation
addappid(2153780)
addappid(2153781, 1, "43869a6685228a4cc04d9134a759865d816f912ea192cd1aa874e442a49f50c5")
