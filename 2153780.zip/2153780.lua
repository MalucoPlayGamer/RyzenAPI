-- Lua provided by RyzenAPI
-- Game: Survival Nation

-- MAIN APPLICATION
addappid(2153780)
-- Game: addappid(2153780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153781, 1, "43869a6685228a4cc04d9134a759865d816f912ea192cd1aa874e442a49f50c5")
