-- Lua provided by RyzenAPI
-- Game: Survivors of the Plague

-- MAIN APPLICATION
addappid(2505350)
-- Game: addappid(2505350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505351, 1, "5c53819f546bd84842f9a04a9600b6136e25b17f74bacafe7d30ec8f63623153")
