-- Lua provided by RyzenAPI
-- Game: 920200

-- MAIN APPLICATION
addappid(920200)
-- Game: addappid(920200)

-- MAIN APP DEPOTS / PACKAGES
addappid(920201, 1, "2c6ade86c8df65a92ca63c638d97e9293808cf396bb67269cc9411347a8d215f")
