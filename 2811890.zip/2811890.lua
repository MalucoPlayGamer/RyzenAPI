-- Lua provided by RyzenAPI
-- Game: NejicomiSimulator TMA02 Demo

-- MAIN APPLICATION
addappid(2811890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811891, 1, "6829479c5f083502e435aeefc760c15e58ae0c9db329ae17f67c830424f4e3a1")
