-- Lua provided by RyzenAPI
-- Game: Game: Hiraeth Playtest

-- MAIN APPLICATION
addappid(2648460)
-- Game: addappid(2648460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648461, 1, "4e6d5addbaf276e0840ac313bd9f0f6e2c21a9a892930783344ec9c496669e3f")
