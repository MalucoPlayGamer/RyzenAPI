-- Lua provided by RyzenAPI
-- Game: Cowboy Life Simulator: Prologue

-- MAIN APPLICATION
addappid(1662230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1662231, 1, "befd9f4ceb4a05493156e2107de2a4abd12fbb1e92b9365baca6dce1b8785d0c")

