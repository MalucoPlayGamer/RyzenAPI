-- Lua provided by RyzenAPI
-- Game: 1662230

-- MAIN APPLICATION
addappid(1662230)
-- Game: addappid(1662230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662231, 1, "befd9f4ceb4a05493156e2107de2a4abd12fbb1e92b9365baca6dce1b8785d0c")
