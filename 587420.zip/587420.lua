-- Lua provided by RyzenAPI
-- Game: Game: Cart Racer

-- MAIN APPLICATION
addappid(587420)
-- Game: addappid(587420)

-- MAIN APP DEPOTS / PACKAGES
addappid(587421, 1, "00d71031a073363e467691782fd7af0d2161437f6f067c0726395db545894793")
