-- Lua provided by RyzenAPI
-- Game: Game: AppID 623070

-- MAIN APPLICATION
addappid(623070)
-- Game: addappid(623070)

-- MAIN APP DEPOTS / PACKAGES
addappid(623071, 1, "75a599685bbf6d81283bc42ce773b50e97a91897b83edf427afa05a033778497")
