-- Lua provided by RyzenAPI
-- Game: ASCII Game Series: Beginning

-- MAIN APPLICATION
addappid(798550)

-- MAIN APP DEPOTS / PACKAGES
addappid(798551, 1, "cc33bad9c56f0191307103b478c55e3dcdf94bd9d15f892ba00c1d0c1981fd3e")
