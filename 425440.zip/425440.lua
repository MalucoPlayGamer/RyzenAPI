-- Lua provided by RyzenAPI
-- Game: addappid(425440)

-- MAIN APPLICATION
addappid(425440)

-- MAIN APP DEPOTS / PACKAGES
addappid(425440,0,"e1ed16f965e3956fe08f51aeca118c5b811606101d1d17ee61633b012e72b4c2")
