-- Lua provided by RyzenAPI 
-- Game: Indiana Jones® and the Fate of Atlantis™
addappid(6010)
addappid(6011, 1, "d3e02b7a8336c3539b3f96c0c750220bb1168cab324590c2c88c074cceeb3aa0")
addappid(6012, 1, "4c0afa2e651c2412d76dd2963f032ff88c32ca2ebcc2df66dbeeb6860578cd85")
addappid(6013, 1, "b636cff3468adddc39ce62ba63dd6ef2555e67f55fd8773c0db92c9b3b5d6dde")
addappid(6014, 1, "a19a476ed387a979adbeb971ca0af81b690b21875fd279551e4f869cd8877d89")
addappid(6015, 1, "b4d830b9893f2dbe7e217b4fd06025ad5b27784b71021d2c95260f375ae2ebe3")
addappid(6016, 1, "13b2ac833ba17da2d8cc8042d675588e429681e9ba7b555a4cc0f62a711a9d01")
