-- Lua provided by RyzenAPI
-- Game: Game: AppID 570550

-- MAIN APPLICATION
addappid(570550)
-- Game: addappid(570550)

-- MAIN APP DEPOTS / PACKAGES
addappid(570551, 1, "057d5419ffd18e24aeb085dea6eb26f7076f060a812125f42394c49460892608")
