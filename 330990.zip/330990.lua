-- Lua provided by RyzenAPI
-- Game: Demon Hunter: Chronicles from Beyond

-- MAIN APPLICATION
addappid(330990)

-- MAIN APP DEPOTS / PACKAGES
addappid(330991, 1, "2a72c0f9295caa9799f9446a7a1a55bcb4272560ddeb2845e31b8dabbf08e430")
addappid(330992, 1, "b3c2ce9e24f443e6ab107a461f06aab237e618859a721813332ca30d861c9d1c")
addappid(330993, 1, "337cc3e2177e13692c4ccb6b24560423092ae1bdffe530554334906b3419224d")
