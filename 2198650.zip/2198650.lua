-- Lua provided by RyzenAPI
-- Game: Surrealidade - Definitive Edition

-- MAIN APPLICATION
addappid(2198650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198651, 1, "a1e84964b576629fd5cdf2c1b8813cf8de041d647b156548c6c1b5c1e27fceec")
