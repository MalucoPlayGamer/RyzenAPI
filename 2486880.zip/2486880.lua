-- Lua provided by RyzenAPI
-- Game: addappid(2486880)

-- MAIN APPLICATION
addappid(2486880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486881, 1, "3f0eb01a67ba3e3d348290d5a7b868b8597bcd308b660bacdd1cf8d1074008d8")
