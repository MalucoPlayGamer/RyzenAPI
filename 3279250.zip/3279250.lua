-- Lua provided by RyzenAPI 
-- Game: AppID 3279250
addappid(3279250)
addappid(3279251, 1, "edf759c5ba11d312f7f57183d6b26a029ef19ff7defac12cdfbfd158773d3b72")
