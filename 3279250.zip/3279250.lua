-- Lua provided by RyzenAPI
-- Game: 3279250

-- MAIN APPLICATION
addappid(3279250)
-- Game: addappid(3279250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279251, 1, "edf759c5ba11d312f7f57183d6b26a029ef19ff7defac12cdfbfd158773d3b72")
