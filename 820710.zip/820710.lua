-- Lua provided by RyzenAPI
-- Game: Game: Mogic

-- MAIN APPLICATION
addappid(820710)
addappid(839360)
-- Game: addappid(820710)

-- MAIN APP DEPOTS / PACKAGES
addappid(820711, 1, "df699f8e6a9eea11f73a839bb54f415f2b48fe78a38eb726baecc2d6b9139629")
