-- Lua provided by RyzenAPI
-- Game: Starcom: Unknown Space

-- MAIN APPLICATION
addappid(1750770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750771, 1, "14c59a14483bf41745ce97ea0a1ca33e57817e1f744d59aa9ff2a411111df765")
