-- Lua provided by RyzenAPI
-- Game: Charlie in the Moistverse of Madness

-- MAIN APPLICATION
addappid(1908670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908671, 1, "06bac866fdb859805449c87e51b24efe07b0918a74b10737777d669d9c88202e")

