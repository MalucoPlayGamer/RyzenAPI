-- Lua provided by RyzenAPI
-- Game: Charlie in the Moistverse of Madness

-- MAIN APPLICATION
addappid(1908670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1908671, 1, "06bac866fdb859805449c87e51b24efe07b0918a74b10737777d669d9c88202e")

