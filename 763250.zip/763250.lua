-- Lua provided by RyzenAPI
-- Game: addappid(763250)

-- MAIN APPLICATION
addappid(763250)

-- MAIN APP DEPOTS / PACKAGES
addappid(763251, 1, "d3a63727467fece7138666d3741ea98bd57c801d0b64d78dd4f8b45de4df004c")
