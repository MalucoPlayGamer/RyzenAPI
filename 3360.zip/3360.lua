-- Lua provided by SkyAPI 
-- Game: Big Money! Deluxe
addappid(3360)
addappid(3361, 1, "943048ff15393e19220e43bc9541434d98e3a1f15b9be933669aa255b7655ced")
