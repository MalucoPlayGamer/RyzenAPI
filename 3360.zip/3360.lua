-- Lua provided by RyzenAPI
-- Game: Big Money! Deluxe

-- MAIN APPLICATION
addappid(3360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361, 1, "943048ff15393e19220e43bc9541434d98e3a1f15b9be933669aa255b7655ced")

