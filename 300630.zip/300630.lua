-- Lua provided by RyzenAPI
-- Game: 300630

-- MAIN APPLICATION
addappid(300630)
-- Game: addappid(300630)

-- MAIN APP DEPOTS / PACKAGES
addappid(300631, 1, "0324eb6058561fa8f6034a8c70d0c712f25b8c0b98d199bedb5b84ad5cf969db")
addappid(330950, 0, "1cc44024eb5d10e35fe0f959d9a3d336e2373b73a7a4b8cdd213b8a5a1266c53")
addappid(439830, 0, "4325558153721ea0282ecaed40bc1a8fba5eea41c7e4ebaabed229db2b2a6687")
