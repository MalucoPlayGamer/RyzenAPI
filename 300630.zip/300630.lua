-- Lua provided by RyzenAPI
-- Game: Pure Chess

-- MAIN APPLICATION
addappid(300630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(300631, 1, "0324eb6058561fa8f6034a8c70d0c712f25b8c0b98d199bedb5b84ad5cf969db")
addappid(330950, 0, "1cc44024eb5d10e35fe0f959d9a3d336e2373b73a7a4b8cdd213b8a5a1266c53")
addappid(439830, 0, "4325558153721ea0282ecaed40bc1a8fba5eea41c7e4ebaabed229db2b2a6687")
