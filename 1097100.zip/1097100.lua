-- Lua provided by RyzenAPI 
-- Game: Please, Touch The Artwork
addappid(1097100)
addappid(1097101, 1, "91468cdeee394d52adb2e74136857849f04ccc83d3efddad5c337b743be2e01b")
