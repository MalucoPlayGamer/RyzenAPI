-- Lua provided by RyzenAPI
-- Game: AppID 246900

-- MAIN APPLICATION
addappid(246900)

-- MAIN APP DEPOTS / PACKAGES
addappid(246901, 1, "d2ee8c17262a1b1f88c3f44fdc38593575d39f48778f840d5aba990f33690dcb")
addappid(246902, 1, "4a9745e9f6a784242eabb42020119de6c7070b45a616d307d055f35f8ef42b90")
addappid(413160, 0, "7050a5a62a7f6956b16ba2f97473d16f44150078a150425115d95309f0d961f2")
addappid(413161, 0, "15dbd9080b49304174cbb658508c2508fb354d7837f34e8bf2a95e4bcb209b23")
addappid(982110, 0, "82940d420adbbbe4fe82ee291da4c99e1e67ebd4dbf18ac31f12f0184b404382")
addappid(982111, 0, "eaed594d2148c951432ba51190e3249b75f7b10cd8a2fa88f175bbdde995ea38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
