-- Lua provided by RyzenAPI 
-- Game: AppID 234740
addappid(234740)
addappid(234741, 1, "844d841a52d8c99a67b5c403ad9eeaee1f3f106289ba6967d25cd594d0f0a4c7")
