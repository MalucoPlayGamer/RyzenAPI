-- Lua provided by RyzenAPI
-- Game: 3509220

-- MAIN APPLICATION
addappid(3509220)
-- Game: addappid(3509220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509221, 1, "7f09ff787aa0deb5f32e3ac952bdae91a94a2efe169d377bd99f62beefb08c62")
