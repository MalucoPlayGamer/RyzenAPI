-- Lua provided by RyzenAPI
-- Game: Crunch Time! Beat the Clock

-- MAIN APPLICATION
addappid(2251500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2251501, 1, "5c3ff4e22f66988e9ce07b4f80d6a844d041ec9d3d732843f6a2601813da7478")

