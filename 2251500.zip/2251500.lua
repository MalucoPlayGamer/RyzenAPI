-- Lua provided by RyzenAPI
-- Game: addappid(2251500)

-- MAIN APPLICATION
addappid(2251500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251501, 1, "5c3ff4e22f66988e9ce07b4f80d6a844d041ec9d3d732843f6a2601813da7478")
