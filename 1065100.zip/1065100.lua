-- Lua provided by RyzenAPI
-- Game: Golden Treasure: The Great Green

-- MAIN APPLICATION
addappid(1065100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065101, 1, "a1c5b0a512a02842c121d5046ecbe638c69185c05076d013ee2c097af144b30f")
addappid(1105880, 0, "afd29b7dc24613c9b9e0f57f0ccffd90fe9bc1cede26bf0b8b3f2690574ec1d1")

