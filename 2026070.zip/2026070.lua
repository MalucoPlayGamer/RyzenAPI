-- Lua provided by RyzenAPI
-- Game: Game: Tank Commander: Battlefield

-- MAIN APPLICATION
addappid(2026070)
-- Game: addappid(2026070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026071, 1, "9c791df9cc90d04f3745627a293e408d7683bdf00d782045f2b7ac80895cd104")
