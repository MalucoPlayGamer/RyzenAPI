-- Lua provided by RyzenAPI
-- Game: Game: SiNKR

-- MAIN APPLICATION
addappid(676420)
-- Game: addappid(676420)

-- MAIN APP DEPOTS / PACKAGES
addappid(676421, 1, "ccaed1f105c020f8f9e42bd52ec4aabaafd1f2352f156db79065a4fd987f0fc8")
addappid(676422, 1, "7cd00e9914e9000dbe6e44783a77c90d82f54a16ddb2e847142816a073394ba9")
addappid(676423, 1, "1166d7b6682fd5ad54a52a38b579e229f800f9741368c74a30a3bc0929706c80")
