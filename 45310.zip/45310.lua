-- Lua provided by RyzenAPI
-- Game: Game: Wings of Prey Demo

-- MAIN APPLICATION
addappid(45310)
-- Game: addappid(45310)

-- MAIN APP DEPOTS / PACKAGES
addappid(45311, 1, "7012b982adf870e31a134e30429ebd885723259d8499b85e59e74899846b6bb9")
