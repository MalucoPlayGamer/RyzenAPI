-- Lua provided by RyzenAPI
-- Game: addappid(1797060)

-- MAIN APPLICATION
addappid(1797060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797061, 1, "41b93236f347beb0a4d4673ab83fe1dafefa0b85208e4be2636198e3281b8a67")
