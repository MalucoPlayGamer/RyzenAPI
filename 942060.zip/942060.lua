-- Lua provided by RyzenAPI
-- Game: JUMPGRID

-- MAIN APPLICATION
addappid(942060)
-- Game: addappid(942060)

-- MAIN APP DEPOTS / PACKAGES
addappid(942062,0,"d374d27fa962149d6904ba7bd0f900a6625ab4a227b30143ed0cbad600eced65")
