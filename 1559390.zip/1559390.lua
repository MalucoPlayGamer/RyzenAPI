-- Lua provided by RyzenAPI
-- Game: Fate Seeker II

-- MAIN APPLICATION
addappid(1559390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559391, 1, "58119c93ebe4b940d4b167bb3a1c7a17f5ca47e7202b3eff66071d19368d0648")

