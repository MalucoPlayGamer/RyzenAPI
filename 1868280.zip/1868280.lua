-- Lua provided by SkyAPI 
-- Game: Coins Collector Simulator
addappid(1868280)
addappid(1868281, 1, "77be0ed401a3aa92e9fcb0121a07281fbb1f36858e0bc475d4a7f949a6701325")
