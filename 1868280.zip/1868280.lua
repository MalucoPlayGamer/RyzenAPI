-- Lua provided by RyzenAPI
-- Game: 1868280

-- MAIN APPLICATION
addappid(1868280)
-- Game: addappid(1868280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868281, 1, "77be0ed401a3aa92e9fcb0121a07281fbb1f36858e0bc475d4a7f949a6701325")
