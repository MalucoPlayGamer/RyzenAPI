-- Lua provided by RyzenAPI
-- Game: addappid(2928920)

-- MAIN APPLICATION
addappid(2928920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928921, 1, "ed79c045fc23cc63941adfc4651db0be9bc2a62847f4188b8e53c2286b7df0d5")
