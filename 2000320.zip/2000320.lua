-- Lua provided by RyzenAPI
-- Game: Keep it Cool, Man

-- MAIN APPLICATION
addappid(2000320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000321, 1, "e65f5a0422280b9eeaec92785f33b2164fdfce7407783eef11437ae42949242c")
addappid(2000322, 1, "477aef33d3c8d121b062b9ee081b726da6961161230164ae5f4ad8e5b7babe7a")
addappid(2000323, 1, "82f7a9e5dfef5881ab04c752343d43e72c119c474fbdab6c4de957ebc8dc0c0e")
addappid(2000324, 1, "f150feb86f6b4fe963d95cc2ee070af6c20986907a704e2c9fecbb3a73a82ed4")
