-- Lua provided by RyzenAPI
-- Game: AppID 3130520

-- MAIN APPLICATION
addappid(3130520)
-- Game: addappid(3130520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130521, 1, "895f1b1688c0c5b2c1dbcee5831bdaad6ec47137a9cbbe1f6a593540151f29a4")
