-- Lua provided by RyzenAPI
-- Game: AppID 1982370

-- MAIN APPLICATION
addappid(1982370)
-- Game: addappid(1982370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982371, 1, "e9cea6d1cd39fe7a6d2e1677b8f8275a6976d90215a3e792df38720829efd642")
