-- Lua provided by RyzenAPI
-- Game: AppID 2868500

-- MAIN APPLICATION
addappid(2868500)
-- Game: addappid(2868500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868501, 1, "fff736782ea1bc71c5c7c556738eaa838912c2fa674c9e28d132083b7c2f41b4")
