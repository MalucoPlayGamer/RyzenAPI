-- Lua provided by RyzenAPI
-- Game: Breakout: Epilepsia Demo

-- MAIN APPLICATION
addappid(3109720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109721, 1, "5708590df078f62413c3f458358afee3d4faa337228de4cf89739bd5e6bde427")
