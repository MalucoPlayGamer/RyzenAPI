-- Lua provided by RyzenAPI
-- Game: Disgaea 7: Vows of the Virtueless

-- MAIN APPLICATION
addappid(2540740)
addappid(2540760)
addappid(2396930) -- Disgaea 7 Vows of the Virtueless - Special Weapons Set
addappid(2396931) -- Disgaea 7 Vows of the Virtueless - Cosmetic Set
addappid(2396932) -- Disgaea 7 Vows of the Virtueless - Starter Support Set
addappid(2396951) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Zombie Sibs and Angel Little Sister
addappid(2396953) -- Disgaea 7 Vows of the Virtueless - Pleinair Completion Bonus

-- MAIN APP DEPOTS / PACKAGES
addappid(2250600, 1, "c7cae809926fb3056cbe222b5a0c12efef42ece879b34fb6af7c97cbd6da9f80") -- Disgaea 7: Vows of the Virtueless
addappid(2250601, 1, "611aaa6ffc70388e7bb62f4b14a877bd178c3d31c98e1d2bcc3046a0b3f0a574") -- Depot 2250601
addappid(2540740, 1, "cc20d1dae797cacb38173b04e3023e15126b20742bf45d0514294a17112191f3") -- Disgaea 7 Vows of the Virtueless - Art Book - Depot 2540740
addappid(2540760, 1, "1c301261d234ea9bb3ec3ab48d09831c3c16c35865f642511ee8b64ff4a3954d") -- Disgaea 7 Vows of the Virtueless - Mini Art Book - Depot 2540760
addappid(2396933) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Overlord, Demon Lord, and Sheltered Girl
addappid(2396934) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Hothead, Princess, and Dreamer
addappid(2396935) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Honor Student, Final Boss, and Ex-President
addappid(2396940) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Instructor, Steward, and Fallen Angel of Love
addappid(2396950) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Kind Demon, Singing Princess, and Thief Angel
addappid(2396952) -- Disgaea 7 Vows of the Virtueless - Bonus Story The Delinquent, Curry Lover, and Lady Overlord
