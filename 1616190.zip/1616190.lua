-- Lua provided by RyzenAPI
-- Game: LineArt Jigsaw Puzzle - Erotica 5

-- MAIN APPLICATION
addappid(1616190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616191, 1, "a612dab32477c2fab39fe7a8b8c6f6d005635dbc9e7a01653a513070dfd00589")
addappid(1644760, 0, "11d560dd35f78aec76c13cb91b9902afb902d80e3069cb3b106ebafb82a42532")

