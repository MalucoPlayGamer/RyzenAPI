-- Lua provided by RyzenAPI
-- Game: 675510

-- MAIN APPLICATION
addappid(675510)
-- Game: addappid(675510)

-- MAIN APP DEPOTS / PACKAGES
addappid(675511, 1, "b8f7202567791f5ed6a5f7e3fada18aed17e0801ee710ecc448fad2360062798")
