-- Lua provided by RyzenAPI
-- Game: 2353060

-- MAIN APPLICATION
addappid(2353060)
addappid(4229690)
addappid(4229700)
addappid(4439910)
addappid(4439980)
addappid(4439990)
addappid(4440070)
addappid(4440100)
addappid(4440110)
-- Game: addappid(2353060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353061, 1, "c3961a7a4786839c1bda96e5698609ac8677615ff115704a380f9a565e9f1204")
