-- Lua provided by RyzenAPI
-- Game: Invincible VS

-- MAIN APPLICATION
addappid(2353060)
addappid(4229690)
addappid(4229700)
addappid(4439910)
addappid(4439920)
addappid(4439930)
addappid(4439940)
addappid(4439950)
addappid(4439980)
addappid(4439990)
addappid(4440020)
addappid(4440030)
addappid(4440050)
addappid(4440060)
addappid(4440070)
addappid(4440100)
addappid(4440110)
addappid(4447740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353061,0,"c3961a7a4786839c1bda96e5698609ac8677615ff115704a380f9a565e9f1204")

