-- Lua provided by RyzenAPI
-- Game: addappid(1136210)

-- MAIN APPLICATION
addappid(1136210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136211, 1, "f44f22ca2f41c811f43bcf7799eff5c0ac330a630249af088458752eec5d767f")
