-- Lua provided by SkyAPI 
-- Game: AppID 1699770
addappid(1699770)
addappid(1699771, 1, "bd74876509ae8b99d1bf67e1d1e6660f8a33d633e7fff1fc9d9fe9d4de3659ff")
