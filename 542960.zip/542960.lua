-- Lua provided by RyzenAPI 
-- Game: AppID 542960
addappid(542960)
addappid(542961, 1, "79ff9a766a662a8a270afc8909aaf3c33d8c51cc9698abb457f3d7c4ac95c62a")
