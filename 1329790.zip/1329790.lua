-- Lua provided by RyzenAPI
-- Game: Game: Override 2: Super Mech League

-- MAIN APPLICATION
addappid(1329790)
-- Game: addappid(1329790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329791, 1, "27278c273b6bd900a591ca0175026461db89f183e2b45877ce0f27e3e2ee9c7e")
