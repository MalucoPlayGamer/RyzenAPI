-- Lua provided by RyzenAPI
-- Game: addappid(1997630)

-- MAIN APPLICATION
addappid(1997630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997631, 1, "21de5e28c4888ecba7fbb2cfb30ea4bd893764a0e565149e5ddbe18dba1b7934")
