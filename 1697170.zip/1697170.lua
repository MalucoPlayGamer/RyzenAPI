-- Lua provided by RyzenAPI
-- Game: addappid(1697170)

-- MAIN APPLICATION
addappid(1697170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697171, 1, "33ac55b5951d44573d90f0ff99ba252dfa718dc4d28a4701201152cdd60ff190")
