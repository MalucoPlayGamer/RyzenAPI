-- Lua provided by RyzenAPI
-- Game: Pantsu Hunter: Back to the 90s

-- MAIN APPLICATION
addappid(953900)

-- MAIN APP DEPOTS / PACKAGES
addappid(953901, 1, "865641b9519569a8944954dbeb4790e4f653e5a6bcf384e54e3e31348dedc597")
addappid(953902, 1, "5ac60a584cc227e1fca18480ddc45e4b55f29f5696a9b55622b58d34462385a9")
addappid(953903, 1, "d72c1ecc54b54eb07381a7aa2f65accaf271077c0675d8114f7b59190e6d9fdb")

