-- Lua provided by RyzenAPI
-- Game: Cyborg Detonator

-- MAIN APPLICATION
addappid(462370)

-- MAIN APP DEPOTS / PACKAGES
addappid(462371, 1, "e3c9357a224871947b725124b9706a144daa9ba220b35e6addc70aa7fe9a81d8")
