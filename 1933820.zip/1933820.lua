-- Lua provided by RyzenAPI
-- Game: Game: SGS Korean War

-- MAIN APPLICATION
addappid(1933820)
-- Game: addappid(1933820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933821, 1, "3d918997ab933176bdf82ddaa5a95301f09add1988b12c55b9f5f6561af52ba5")
addappid(1933823, 1, "ade643d2d2fc55e006072251c91e6fd97b78de1c1b18537e471c1523cca1dcb4")
