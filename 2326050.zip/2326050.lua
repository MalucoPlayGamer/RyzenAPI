-- Lua provided by RyzenAPI
-- Game: Dethroned

-- MAIN APPLICATION
addappid(2326050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326051, 1, "ed31c37a4714322cef099d0e37d2241543c1f3fe79601ee0341e85a5104c1a93")
