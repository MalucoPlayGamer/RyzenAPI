-- Lua provided by RyzenAPI
-- Game: Wendy’s Mart 3D

-- MAIN APPLICATION
addappid(789700)

-- MAIN APP DEPOTS / PACKAGES
addappid(789701,0,"389458af89c1043ddba236640d563af27e0e4bc74a70b0e570cd3278c23f26b0")

