-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(221001)

-- MAIN APP DEPOTS / PACKAGES
addappid(221001,0,"45274bfd49c3b586f89ab2ea236455b4479d781bf2a869c7e1b4add2766c5798")

