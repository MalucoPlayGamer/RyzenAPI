-- Lua provided by RyzenAPI
-- Game: Passed Out Demo

-- MAIN APPLICATION
addappid(2134810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134811, 1, "17cdffb2ba4ccdf1ef6f969014184c554584ca680c37a920d1512a8a7c5b37b4")

