-- Lua provided by RyzenAPI
-- Game: addappid(3022950)

-- MAIN APPLICATION
addappid(3022950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022951, 1, "3687d7cd966a592515d6bd25ff5a92e8727e28d474c99a19ee683f252ea9224a")
