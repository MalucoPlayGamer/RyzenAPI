-- Lua provided by SkyAPI 
-- Game: In Your Shoes: An NSFW MILF & Daughter Sex VN
addappid(3022950)
addappid(3022951, 1, "3687d7cd966a592515d6bd25ff5a92e8727e28d474c99a19ee683f252ea9224a")
