-- Lua provided by RyzenAPI
-- Game: 2597230

-- MAIN APPLICATION
addappid(2597230)
-- Game: addappid(2597230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597231, 1, "1076cd35443f3340c2bc405e185988a8a3cad92fc0fbdea32a40a4cdaf69bc40")
