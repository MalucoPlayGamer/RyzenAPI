-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3080140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080140,0,"0dd6610571147f1273561eff793276b4e3e6f41489372085c1db6987cbce2d42")
