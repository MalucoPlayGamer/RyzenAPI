-- Lua provided by RyzenAPI
-- Game: A fascinating story : Wedding Night

-- MAIN APPLICATION
addappid(2736210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736211, 1, "a8b1957e2dad2a2797367dd9998d61ba451d31a6c0f552f451ce72a577d07f35")
addappid(2819280, 0, "ee2493888d35f54eea44e46b25bad96b2581469f183e5852087f91350c3b3565")

