-- Lua provided by RyzenAPI
-- Game: Neko Secret - Homecoming

-- MAIN APPLICATION
addappid(1834960)
-- Game: addappid(1834960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834962,0,"bf62c6ab70560615991986f7bbb8b4e4466d1296cb4861d52ecd6cb63c04b878")
