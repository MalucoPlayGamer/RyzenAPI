-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - The Music Box: Japanese Horror

-- MAIN APPLICATION
addappid(1450980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450980,0,"98a24c31b2059bf3a9431ba6e72eac80a71e5946d7e60808a215517dc00c2e32")

