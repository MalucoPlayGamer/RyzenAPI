-- Lua provided by RyzenAPI
-- Game: Game: AppID 689520

-- MAIN APPLICATION
addappid(689520)
-- Game: addappid(689520)

-- MAIN APP DEPOTS / PACKAGES
addappid(689521, 1, "aabe6b2c98449d80a90f913d79c65afc066b37033ade8922bc884837c91e6c68")
