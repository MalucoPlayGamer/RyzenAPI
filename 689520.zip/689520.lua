-- Lua provided by SkyAPI 
-- Game: AppID 689520
addappid(689520)
addappid(689521, 1, "aabe6b2c98449d80a90f913d79c65afc066b37033ade8922bc884837c91e6c68")
