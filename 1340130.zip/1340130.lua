-- Lua provided by RyzenAPI
-- Game: Aokana - Four Rhythms Across the Blue - EXTRA1

-- MAIN APPLICATION
addappid(1340130)
-- Game: addappid(1340130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340131, 1, "d659f626753e28ea7097e3e5d281466524c89702758ce481ded3bbc7dbc34422")
