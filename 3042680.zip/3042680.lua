-- Lua provided by RyzenAPI
-- Game: Lightracer: For Judge

-- MAIN APPLICATION
addappid(3042680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042681, 1, "247ce5f3d5f8bc0e23ba67ff3334acc55076a32aa6b10881ed187ef39e21533d")

