-- Lua provided by SkyAPI 
-- Game: AppID 1040920
addappid(1040920)
addappid(1040921, 1, "c11abb022e7e9a287efa9c621a97685bf1175049a01a770329460833d57ff9fd")
