-- Lua provided by RyzenAPI
-- Game: 1040920

-- MAIN APPLICATION
addappid(1040920)
-- Game: addappid(1040920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040921, 1, "c11abb022e7e9a287efa9c621a97685bf1175049a01a770329460833d57ff9fd")
