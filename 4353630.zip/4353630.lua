-- Lua provided by RyzenAPI
-- Game: summer sisters

-- MAIN APPLICATION
addappid(4353630)

