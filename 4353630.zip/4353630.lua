-- Lua provided by RyzenAPI
-- Game: addappid(4353630)

-- MAIN APPLICATION
addappid(4353630)

