-- Lua provided by RyzenAPI
-- Game: Game: D'LIRIUM

-- MAIN APPLICATION
addappid(670160)
-- Game: addappid(670160)

-- MAIN APP DEPOTS / PACKAGES
addappid(670161, 1, "2772a1ea6667775a9bcbdfb20c5c8a6eea1aa04aeb3b4e8056e8b574515fa0d7")
