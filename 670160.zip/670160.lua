-- Lua provided by SkyAPI 
-- Game: D'LIRIUM
addappid(670160)
addappid(670161, 1, "2772a1ea6667775a9bcbdfb20c5c8a6eea1aa04aeb3b4e8056e8b574515fa0d7")
