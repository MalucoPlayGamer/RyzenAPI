-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2594100)
addappid(2594100,0,"97f6fc4811b0a1757eb47d8f1e22f41df82693f86037d1d77bc656839544bb3c")
-- setManifestid(2594100,"8783428574681803848")