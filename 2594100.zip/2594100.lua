-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2594100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594100,0,"97f6fc4811b0a1757eb47d8f1e22f41df82693f86037d1d77bc656839544bb3c")

