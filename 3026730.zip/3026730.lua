-- Lua provided by RyzenAPI
-- Game: Tamer: King of Dinosaurs

-- MAIN APPLICATION
addappid(4585050)
addappid(4712800)
addappid(4909470)
addappid(4909480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026730, 1, "e88bc7b911a32f3d6a7c011c4c1a6b285206190a82f35975055b5a166b5aa91c") -- Tamer: King of Dinosaurs
addappid(3026731, 1, "4aa0903b04bc64497106e1cc76e20ea33ba05a58986f118fe10e5cd755e488a6") -- Depot 3026731
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4585050, 1, "91c79cfa518bde14a4cd8c36e47143e959d48cd985049f41db22f66cabbccec8") -- Tamer KoD Digital Art Book, eBooksAudiobooks - Depot 4585050
addappid(4712800, 1, "58a3e4baacf3aa93439c3aa669866c33b6fda2c3a76ceecb09a15ba1e8d8dec7") -- GothMommy-DLC - Depot 4712800
addappid(4909470, 1, "59f2f604f3f34101f0f079626257e48c12323898936efb1260e4daa7f23b04ce") -- Blind Bunny Costume Pack - Depot 4909470
addappid(4909480, 1, "294aa1e68bef4402421ee9955cad8c18f413635a4a08e08efec52ae6c146889e") -- Pajama Party Costume Pack - Depot 4909480
