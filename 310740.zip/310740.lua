-- Lua provided by SkyAPI 
-- Game: AppID 310740
addappid(310740)
addappid(310741, 1, "9381d5c0cf4f94187ce52c2749f640c2bb48be7ab900d2fdb0985918da82b21f")
addappid(341790, 0, "a05a9d64df5c20a82135640bcc33afac0641abf8b0436f389e5a848bd8002213")
