-- Lua provided by RyzenAPI
-- Game: AppID 310740

-- MAIN APPLICATION
addappid(310740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(310741, 1, "9381d5c0cf4f94187ce52c2749f640c2bb48be7ab900d2fdb0985918da82b21f")
addappid(341790, 0, "a05a9d64df5c20a82135640bcc33afac0641abf8b0436f389e5a848bd8002213")

