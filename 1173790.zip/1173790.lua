-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY III
addappid(1173790)
addappid(1173791, 1, "0fe015ebeb9bd2ffde769fbf06c276395ecca9bc028829443ecba3460b77e613")
addappid(1638370, 0, "41cbb276f49dda1545e52ef4be1aa47a3e5f6bb7083c826ff70dc577d094ca77")
