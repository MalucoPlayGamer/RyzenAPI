-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY III

-- MAIN APPLICATION
addappid(1173790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1173791, 1, "0fe015ebeb9bd2ffde769fbf06c276395ecca9bc028829443ecba3460b77e613")
addappid(1638370, 0, "41cbb276f49dda1545e52ef4be1aa47a3e5f6bb7083c826ff70dc577d094ca77")

