-- Lua provided by RyzenAPI
-- Game: Game: Just Futanari 2

-- MAIN APPLICATION
addappid(3004880)
-- Game: addappid(3004880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004881, 1, "9b1c5e572729beb14cc4a81269435ec652c7e7db3fa2ec5c3283c38a3dcb4868")
