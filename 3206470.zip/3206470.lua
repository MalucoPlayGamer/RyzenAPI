-- Lua provided by RyzenAPI
-- Game: 3206470

-- MAIN APPLICATION
addappid(3206470)
-- Game: addappid(3206470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206471, 1, "eb42821b1cd567174bdaec9dfa50d334244ee2d2bb46103d6efbbbdd9833cfe0")
