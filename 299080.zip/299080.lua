-- Lua provided by RyzenAPI
-- Game: setManifestid(299082,"4647820811819107626")

-- MAIN APPLICATION
addappid(299080)

-- MAIN APP DEPOTS / PACKAGES
addappid(299082,0,"6d153d2bbdfbe9728dd31e0c4832c6dd84c6a6fe0cf6ccc612e5541618cb1147")

