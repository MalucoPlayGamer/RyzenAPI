-- Lua provided by RyzenAPI 
-- Game: AppID 217290
addappid(217290)
addappid(217291, 1, "fd65fe0f9df6f0bb0f5d9efdebf8a595817205c1e9f15c1c1e95c693b9331f17")
addappid(217292, 1, "bb71f87e4e34007874e2c8e718f3cefdfed0c658cfcbb1268d5417a00193e3ac")
addappid(217293, 1, "3b415a30f2de6579f025af4721b9ea93c1a707eada3a8ed238f25d769d8ba197")
addappid(217294, 1, "76db855bfdb3a3cbeab10a9c2ba397aac76979ad6d1dd8bbd3829ad8feb78abf")
addappid(217300, 1, "ad0215df5910cc34b1101ee0793564e4593ef082d91050c5b68cff0f1622033f")
