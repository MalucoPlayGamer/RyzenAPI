-- Lua provided by RyzenAPI
-- Game: Game: 鳥獣妖怪戯画　(Choju Yokai Giga)

-- MAIN APPLICATION
addappid(1878620)
-- Game: addappid(1878620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878621, 1, "8aabad3ba949fe5fc0be03cbf87b6c9dbfb033ef7d21ab6bc942f599a4934404")
