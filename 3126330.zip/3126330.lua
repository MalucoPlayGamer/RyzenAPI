-- Lua provided by RyzenAPI 
-- Game: Kiosk
addappid(3126330)
addappid(3126331, 1, "7569912f8548bbe2ffbf0cd75ab6c8cab1dffa6348fa7657970895d9c5161d78")
addappid(3126332, 1, "c7ca641cf58761e53aa8e95f746dcfbe37093b8db75257bf29cff35dd6ff045f")
addappid(3126333, 1, "d85591a97c21daed42382e4ed6cc5c95ac8ab83af5079158d40b6d1cbda3a754")
