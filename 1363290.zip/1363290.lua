-- Lua provided by RyzenAPI
-- Game: Game: SIGNAL

-- MAIN APPLICATION
addappid(1363290)
-- Game: addappid(1363290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363291, 1, "cfcecabbeb952215aef07b058b11ab6a58f57b6ae8a8bb4912100f4c322c3e64")
