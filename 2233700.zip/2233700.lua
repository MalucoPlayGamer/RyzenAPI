-- Lua provided by RyzenAPI
-- Game: Last Night in zombie village

-- MAIN APPLICATION
addappid(2233700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233701, 1, "bdf00a15c57de69e355a1bc96d7837ae94d754e7c02a19173b97ea77e5540783")
