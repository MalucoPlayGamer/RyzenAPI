-- Lua provided by RyzenAPI
-- Game: Humans Must Answer

-- MAIN APPLICATION
addappid(261740)

-- MAIN APP DEPOTS / PACKAGES
addappid(261741, 1, "c775684257c66d02c1459c3087cc5913682e394ea389b75c1a114682e4fb662b")

