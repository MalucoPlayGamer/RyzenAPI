-- Lua provided by RyzenAPI
-- Game: addappid(1549220)

-- MAIN APPLICATION
addappid(1549220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549221, 1, "553fde5a98242bbb2e56657e27164732d5af02e219815db866e0bb56d616e7c5")
