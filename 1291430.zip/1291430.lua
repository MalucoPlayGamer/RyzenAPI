-- Lua provided by RyzenAPI
-- Game: AppID 1291430

-- MAIN APPLICATION
addappid(1291430)
-- Game: addappid(1291430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291431, 1, "899e9fc4236aec9ddc0a77f36e31f1ef8f64ab4bf5a539f82e72096aaa267e23")
