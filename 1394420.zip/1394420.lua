-- Lua provided by SkyAPI 
-- Game: Dallen Clicker Ultimate
addappid(1394420)
addappid(1394421, 1, "18409ac79d1cf486b01a8041a7bc9c39149c230986f2cf770632b29e81c148e8")
