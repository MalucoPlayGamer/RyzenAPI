-- Lua provided by RyzenAPI
-- Game: Game: Dallen Clicker Ultimate

-- MAIN APPLICATION
addappid(1394420)
-- Game: addappid(1394420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394421, 1, "18409ac79d1cf486b01a8041a7bc9c39149c230986f2cf770632b29e81c148e8")
