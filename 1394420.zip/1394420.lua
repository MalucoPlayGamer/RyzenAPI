-- Lua provided by RyzenAPI
-- Game: Dallen Clicker Ultimate

-- MAIN APPLICATION
addappid(1394420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1394421, 1, "18409ac79d1cf486b01a8041a7bc9c39149c230986f2cf770632b29e81c148e8")

