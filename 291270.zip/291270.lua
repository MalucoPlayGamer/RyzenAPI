-- Lua provided by RyzenAPI
-- Game: Vitrum

-- MAIN APPLICATION
addappid(291270)
-- Game: addappid(291270)

-- MAIN APP DEPOTS / PACKAGES
addappid(291271, 1, "ad5d95c53b36d47af2e819b4539727012adf623f9d11e00e6e95ff6b75e86475")
