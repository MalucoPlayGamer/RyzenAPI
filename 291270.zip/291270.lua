-- Lua provided by RyzenAPI
-- Game: Vitrum

-- MAIN APPLICATION
addappid(291270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(291271, 1, "ad5d95c53b36d47af2e819b4539727012adf623f9d11e00e6e95ff6b75e86475")

