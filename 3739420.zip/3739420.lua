-- Lua provided by RyzenAPI 
-- Game: Burr Puzzle
addappid(3739420)
addappid(3739421, 1, "960ff1b73fd16efbc1f7b2ff0d9872c6de251cf5a808963c249367bd140302f5")
