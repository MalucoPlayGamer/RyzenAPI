-- Lua provided by RyzenAPI
-- Game: addappid(2679660)

-- MAIN APPLICATION
addappid(2679660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679661, 1, "5f675672b3edd7e898ef7b87caefb74b291fe5d420fe302331c18731614e1174")
