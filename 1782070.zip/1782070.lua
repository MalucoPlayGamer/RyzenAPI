-- Lua provided by RyzenAPI
-- Game: Blue Max: Aces of the Great War

-- MAIN APPLICATION
addappid(1782070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782071, 1, "3ccc552b5867cc2c1337f77345355adbf69d6dd73203e26fbf536df8bcdb889e")
