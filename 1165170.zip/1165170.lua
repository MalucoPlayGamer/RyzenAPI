-- Lua provided by RyzenAPI
-- Game: Morok

-- MAIN APPLICATION
addappid(1165170)
-- Game: addappid(1165170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165171, 1, "411e2a3b03ffc8f94d2ed21c383b4b86ba24149767aa9abcbde8c8d0f44e4954")
