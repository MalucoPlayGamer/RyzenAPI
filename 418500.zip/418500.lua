-- Lua provided by RyzenAPI
-- Game: Rising Storm 2: Vietnam

-- MAIN APPLICATION
addappid(418500)
addappid(629750)
addappid(737270)
addappid(737272)
addappid(794340)
addappid(794341)
addappid(794342)
addappid(794343)
addappid(794344)
addappid(794345)
addappid(1042390)
addappid(1062590)
addappid(1074650)

-- MAIN APP DEPOTS / PACKAGES
addappid(418501, 1, "66460eb9d7da79e5be2515b584f9024e053624ed40881a2ba75e6cd3f10844bb")
addappid(418502, 1, "67c03fa355fb081d98c2eaee71a66b7027d319af1e4aa0f43d00dd79b3322e54")

