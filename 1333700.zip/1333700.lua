-- Lua provided by RyzenAPI
-- Game: AppID 1333700

-- MAIN APPLICATION
addappid(1333700)
-- Game: addappid(1333700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333701, 1, "4f72e939277e25bc53f7b6f089ee431bd965fcc00ef81fe9669918fe1d468d56")
