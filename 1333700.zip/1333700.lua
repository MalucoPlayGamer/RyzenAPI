-- Lua provided by RyzenAPI
-- Game: Real Heroes: Firefighter HD

-- MAIN APPLICATION
addappid(1333700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1333701, 1, "4f72e939277e25bc53f7b6f089ee431bd965fcc00ef81fe9669918fe1d468d56")
