-- Lua provided by RyzenAPI
-- Game: 3277420

-- MAIN APPLICATION
addappid(3277420)
-- Game: addappid(3277420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277421, 1, "dcd650c29fa863623eb0bfe500e6c83c85e4fd2ca096d7f451118df7de069b80")
