-- Lua provided by RyzenAPI 
-- Game: William and Sly: Classic Collection
addappid(2684790)
addappid(2684791, 1, "debf4426d3cbdad10a19b42f25c4151f3c67a8d6a4b91c150f3027f052e2aee0")
