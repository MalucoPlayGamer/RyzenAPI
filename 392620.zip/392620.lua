-- Lua provided by RyzenAPI
-- Game: Game: AppID 392620

-- MAIN APPLICATION
addappid(392620)
-- Game: addappid(392620)

-- MAIN APP DEPOTS / PACKAGES
addappid(392621, 1, "e2f5e607eb8b2488c0a821117f82161260101ceb4dc215dd3d7f93d0ed877752")
