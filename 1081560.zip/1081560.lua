-- Lua provided by RyzenAPI
-- Game: GOLD EXPRESS

-- MAIN APPLICATION
addappid(1081560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1081561, 1, "304aa5de25b33ce1976a115723df277bdd8eba9721233e89b7363f02c0e891f7")

