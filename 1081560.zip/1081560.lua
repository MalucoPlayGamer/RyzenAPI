-- Lua provided by RyzenAPI
-- Game: addappid(1081560)

-- MAIN APPLICATION
addappid(1081560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081561, 1, "304aa5de25b33ce1976a115723df277bdd8eba9721233e89b7363f02c0e891f7")
