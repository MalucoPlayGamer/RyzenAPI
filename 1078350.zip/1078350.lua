-- Lua provided by RyzenAPI
-- Game: Ambrosia

-- MAIN APPLICATION
addappid(1078350)
-- Game: addappid(1078350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078351, 1, "f1b7d5bee1dbdcb18667b63b903c20aa60f61bfc0503ad947154d3e5bd571454")
addappid(1078352, 1, "70534fea5710b3898e8dfc255a4643be10016a18fc439c4b7c01c8a4bd1fe10f")
addappid(1078353, 1, "91abff83d9c70dba592a56841491159f0352c31704f7140b36d05d9ad6d49182")
