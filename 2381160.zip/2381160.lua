-- Lua provided by RyzenAPI
-- Game: Game: Quest for the Golden Candelabra

-- MAIN APPLICATION
addappid(2381160)
-- Game: addappid(2381160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381161, 1, "a2b49d9f3ffb345cdb8327b23a07686babcca6ad83162ee8bed0e0e4564be066")
