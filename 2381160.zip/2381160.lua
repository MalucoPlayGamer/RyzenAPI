-- Lua provided by RyzenAPI
-- Game: Quest for the Golden Candelabra

-- MAIN APPLICATION
addappid(2381160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381161, 1, "a2b49d9f3ffb345cdb8327b23a07686babcca6ad83162ee8bed0e0e4564be066")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
