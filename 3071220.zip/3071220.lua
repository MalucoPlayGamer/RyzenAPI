-- Lua provided by RyzenAPI
-- Game: 10秒ルール【8番ライクホラー】 Demo

-- MAIN APPLICATION
addappid(3071220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071221, 1, "8d4ee3d9b06c17c9f1a36d29b6c717b26784d6e184018e62da13001e6438bb76")