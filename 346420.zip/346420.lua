-- Lua provided by RyzenAPI
-- Game: AppID 346420

-- MAIN APPLICATION
addappid(346420)

-- MAIN APP DEPOTS / PACKAGES
addappid(346421, 1, "8e4df4568e22174f20fe0b975bf8c0b6339f4a51c3f8020fbf5f62411d756498")
addappid(346422, 1, "76099c3214158f9dcce943871f698e9a8893f2e26ae380b1173ef1aec85149b3")
addappid(346423, 1, "0f2c1e8c6671d7bf9fc33b0a16b5818a08128478172707b2da11b4d855a72c9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
