-- Lua provided by RyzenAPI
-- Game: addappid(3372280)

-- MAIN APPLICATION
addappid(3372280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372281, 1, "238914f54210c1e50aa7a04bc4cda8df17cda8a00a464d52dffa505e0d8a7846")
