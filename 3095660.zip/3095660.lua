-- Lua provided by RyzenAPI
-- Game: Twizzle Puzzle: Mushrooms

-- MAIN APPLICATION
addappid(3095660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095661, 1, "a5634097635f8a1824ae1dde4bb81e51310c4e1de5b940cde978390030c3f561")
