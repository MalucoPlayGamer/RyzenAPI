-- Lua provided by RyzenAPI
-- Game: PropFight

-- MAIN APPLICATION
addappid(2881590)
-- Game: addappid(2881590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881591, 1, "aca66d2a8ffb693991fdf41c0690c77852bb0767c5ebcf8ab1eeaa22a4352be0")
