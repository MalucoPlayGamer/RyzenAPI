-- Lua provided by SkyAPI 
-- Game: Robosnow
addappid(1734610)
addappid(1734611, 1, "082404119c2e666186a9469c23620eecf6df5b5a1ab6ea8811f025d1a3e62c81")
