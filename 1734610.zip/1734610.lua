-- Lua provided by RyzenAPI
-- Game: Robosnow

-- MAIN APPLICATION
addappid(1734610)
-- Game: addappid(1734610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734611, 1, "082404119c2e666186a9469c23620eecf6df5b5a1ab6ea8811f025d1a3e62c81")
