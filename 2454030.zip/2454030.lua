-- Lua provided by RyzenAPI
-- Game: Spook a Pooh!

-- MAIN APPLICATION
addappid(2454030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2454031, 1, "48260c740254f5bbfe30d82d7b5db72855669f09915b920c68b7bf369de9bf1f")

