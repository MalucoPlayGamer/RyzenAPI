-- Lua provided by RyzenAPI
-- Game: addappid(2454030)

-- MAIN APPLICATION
addappid(2454030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454031, 1, "48260c740254f5bbfe30d82d7b5db72855669f09915b920c68b7bf369de9bf1f")
