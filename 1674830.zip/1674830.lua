-- Lua provided by RyzenAPI
-- Game: Victory at Sea Atlantic - World War II Naval Warfare

-- MAIN APPLICATION
addappid(1674830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674831, 1, "9b5fcc1db7c8baf4fea68fde86c9cc64170df6287337a5e23290dad5afccb213")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3781200)
addappid(3781210)
addappid(3781220)
