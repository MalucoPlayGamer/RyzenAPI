-- Lua provided by RyzenAPI
-- Game: 1674830

-- MAIN APPLICATION
addappid(1674830)
-- Game: addappid(1674830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674831, 1, "9b5fcc1db7c8baf4fea68fde86c9cc64170df6287337a5e23290dad5afccb213")
