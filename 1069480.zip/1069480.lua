-- Lua provided by RyzenAPI
-- Game: AppID 1069480

-- MAIN APPLICATION
addappid(1069480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069481, 1, "166fc98c8674b2c50e1b008c01f0dfe518a5572fb31da092df07904e0386f21e")
addappid(1069482, 1, "137c6870fbfd43d2be7eb1e7372f87cf3d7219204a5353c7f34b78ff23877eac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
