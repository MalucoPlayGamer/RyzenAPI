-- Lua provided by RyzenAPI
-- Game: My dream setup

-- MAIN APPLICATION
addappid(2637930) -- My Dream Setup - Pets DLC
addappid(2926420) -- My Dream Setup - Bathroom DLC
addappid(2926430) -- My Dream Setup - Kitchen DLC
addappid(3371380) -- My Dream Setup - Garage DLC
addappid(4131550) -- My Dream Setup - Sim Racing DLC
addappid(4920470) -- My Dream Setup - Shopping DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(2200780, 1, "1957169343776760d0f1b8df91fffc145375164fbbd63ef790dd530467933649") -- My dream setup
addappid(2200781, 1, "29406521ce5331ba5fdd43d43177449ef8464b67e6b6de257c894a5dbdb26cb1") -- Depot 2200781
addappid(2200782, 1, "112155b443b5d2147602ac203014c4d4baeb01b241d22704420be8135a38f04a") -- Depot 2200782

