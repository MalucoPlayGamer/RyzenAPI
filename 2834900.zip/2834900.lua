-- Lua provided by RyzenAPI
-- Game: Game: Nightingale - Digital Art Book

-- MAIN APPLICATION
addappid(2834900)
-- Game: addappid(2834900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834901, 1, "19017e82480e010d2b1bd4df327956ac12921ff4f73ffac6005d34f77899581b")
