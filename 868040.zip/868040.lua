-- Lua provided by RyzenAPI
-- Game: Stick Spartans

-- MAIN APPLICATION
addappid(868040)

-- MAIN APP DEPOTS / PACKAGES
addappid(868041,0,"f258c83ca3aa12f767fb3a8cd978dcb4b37be0c387eb23880ca16bb29916b7cb")

