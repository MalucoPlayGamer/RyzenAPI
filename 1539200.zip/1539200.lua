-- Lua provided by RyzenAPI
-- Game: addappid(1539200)

-- MAIN APPLICATION
addappid(1539200)
addappid(1539201)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539200,0,"8881f75a243cf1925b3675c7e458d1d34e7e3f2174edb5f0d0db712da3fda27b")
