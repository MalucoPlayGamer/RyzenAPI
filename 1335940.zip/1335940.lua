-- Lua provided by RyzenAPI
-- Game: AppID 1335940

-- MAIN APPLICATION
addappid(1335940)
-- Game: addappid(1335940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335941, 1, "4a3bf6bfb512332e43b0984bbcf5e9a6bcfbcc5a2716294ea4dff22daea8086a")
