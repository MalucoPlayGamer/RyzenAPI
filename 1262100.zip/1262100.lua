-- Lua provided by RyzenAPI
-- Game: Borderus

-- MAIN APPLICATION
addappid(1262100)
-- Game: addappid(1262100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262101, 1, "9d0fa21fba96571b879c2873752e40a6b0f5377583326d6fb5ff648fd1d016ff")
