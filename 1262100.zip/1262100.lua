-- Lua provided by RyzenAPI
-- Game: Borderus

-- MAIN APPLICATION
addappid(1262100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262101, 1, "9d0fa21fba96571b879c2873752e40a6b0f5377583326d6fb5ff648fd1d016ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
