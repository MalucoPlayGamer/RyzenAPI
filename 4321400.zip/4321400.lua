-- Lua provided by RyzenAPI
-- Game: Gold Up

-- MAIN APPLICATION
addappid(4321400) -- Gold Up

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4321401, 1, "5b33c06511c18c3a20151b08f8128bfa0d5b015eac2a8c943ba9e398020088cf") -- Depot 4321401

