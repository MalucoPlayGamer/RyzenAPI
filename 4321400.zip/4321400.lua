-- 4321400's Lua and Manifest Created by Hubcap Manifest
-- Gold Up
-- Created: August 13, 2026 at 04:04:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4321400) -- Gold Up
-- MAIN APP DEPOTS
addappid(4321401, 1, "5b33c06511c18c3a20151b08f8128bfa0d5b015eac2a8c943ba9e398020088cf") -- Depot 4321401
setManifestid(4321401, "1489696689421075743", 1936914188)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)