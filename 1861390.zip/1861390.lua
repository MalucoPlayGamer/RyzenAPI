-- Lua provided by RyzenAPI
-- Game: Way On Where

-- MAIN APPLICATION
addappid(1861390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1861391, 1, "73aa24e8cd291630687a71df85322f3fb93a12007846d05e2629362c30b32355")
