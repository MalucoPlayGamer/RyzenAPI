-- Lua provided by RyzenAPI 
-- Game: AppID 1861390
addappid(1861390)
addappid(1861391, 1, "73aa24e8cd291630687a71df85322f3fb93a12007846d05e2629362c30b32355")
