-- Lua provided by RyzenAPI
-- Game: Game: AppID 418960

-- MAIN APPLICATION
addappid(418960)
-- Game: addappid(418960)

-- MAIN APP DEPOTS / PACKAGES
addappid(418961, 1, "d921608c2dec55d2a9719dcff35a3b39ba3b83d88f57d6972496587d1c364e85")
