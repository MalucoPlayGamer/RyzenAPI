-- Lua provided by RyzenAPI
-- Game: Bonfire Peaks

-- MAIN APPLICATION
addappid(1147890)
-- Game: addappid(1147890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147891, 1, "464133c8d6074b0339f91632029811374c11e66fa99697ac89418d8be78af260")
