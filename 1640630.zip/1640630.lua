-- Lua provided by RyzenAPI
-- Game: Game: Heading Out

-- MAIN APPLICATION
addappid(1640630)
-- Game: addappid(1640630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640631, 1, "5e86125460087045de71f7cacd85aac39aff11b4d15859d8b891d21088be57ed")
