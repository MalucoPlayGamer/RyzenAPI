-- Lua provided by RyzenAPI
-- Game: Be King

-- MAIN APPLICATION
addappid(2471950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471951, 1, "8812ce3a1a40228bd554478b63cc9f7d1a2afd92e31792ba43ce48e6c58ba326")
