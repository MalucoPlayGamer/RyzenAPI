-- Lua provided by RyzenAPI
-- Game: 1311150

-- MAIN APPLICATION
addappid(1311150)
-- Game: addappid(1311150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311151, 1, "0183a8f65beba62ffd3dc53b9c1ad1d668b637d65baaf2c50d05ef4c4ca48505")
