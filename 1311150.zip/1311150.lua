-- Lua provided by RyzenAPI 
-- Game: Long Car Journey - A road trip game
addappid(1311150)
addappid(1311151, 1, "0183a8f65beba62ffd3dc53b9c1ad1d668b637d65baaf2c50d05ef4c4ca48505")
