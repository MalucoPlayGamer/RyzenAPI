-- Lua provided by RyzenAPI
-- Game: 392690

-- MAIN APPLICATION
addappid(392690)
-- Game: addappid(392690)

-- MAIN APP DEPOTS / PACKAGES
addappid(392691, 1, "0007b471662b4c20800fbcdceb0cf35c7b4c6c08f3daec357ab1ed4f23c01af7")
