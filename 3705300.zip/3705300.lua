-- Lua provided by RyzenAPI
-- Game: Between Her Toes

-- MAIN APPLICATION
addappid(3705300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3705301, 1, "01a5150ade5c1aaad2d55718fe66cb065462ce41e480e25131067a42b2403ede")
