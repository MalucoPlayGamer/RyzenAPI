-- Lua provided by RyzenAPI
-- Game: addappid(2462690)

-- MAIN APPLICATION
addappid(2462690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462691, 1, "0ba2ad5a968c725b6b8e4989a1fff9182cdeb98391f48e1a9892ee799b4c7a8a")
