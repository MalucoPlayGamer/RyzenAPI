-- Lua provided by RyzenAPI
-- Game: Ostalgie: The Berlin Wall

-- MAIN APPLICATION
addappid(774091)

-- MAIN APP DEPOTS / PACKAGES
addappid(774092, 1, "eba58582ab0dbc0d16691378ef2a05090b6b8568d9cd652ee7cf2048714e830a")
addappid(774093, 1, "aa2dda849073c587853ffbf782643bd6f4e27bfab45ee24929b4d333d1a96db8")
addappid(774094, 1, "90dcbe3e721df9229eaf43476709a7101d072e3a6248f5e973cc5cb5435dcfd7")
addappid(774095, 1, "9a06ec1099198fb82febd538ed20585c16660f3ac26cc13e475cf685c63eba00")
addappid(950760, 0, "1e22712719a10374f5cef7efe9f52089d70279647d10e9313f012f5f82551c06")
addappid(1034970, 0, "48dd310c5033b96a10f23ddd1aea14c353b28750f23264bb318e62d604dd3e9e")
addappid(1794910, 0, "780c7fb9b350d9b84ec6499cf3f26877d9fb185950ab24416be6228a7caa48ec")
addappid(1886380, 0, "930677f8e4402242e5777cdf331b8faaa86faf37ceed001b54ae4fa95de80fd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
