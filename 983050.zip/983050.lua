-- Lua provided by RyzenAPI
-- Game: addappid(983050)

-- MAIN APPLICATION
addappid(983050)

-- MAIN APP DEPOTS / PACKAGES
addappid(983051, 1, "d6d233a2a78f08dadb3726c1c93eb4a6322d3cf9eda40cd989487c16fdbfd98a")
