-- Lua provided by RyzenAPI
-- Game: Horse Farm

-- MAIN APPLICATION
addappid(821670)

