-- Lua provided by RyzenAPI 
-- Game: Battle Bruise
addappid(618510)
addappid(618511, 1, "717ee63d873e8ec06394ab42bc2c39b478bff46583d73f6f9fa6e16f91d612cb")
addappid(702040)
