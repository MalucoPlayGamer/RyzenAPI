-- Lua provided by RyzenAPI
-- Game: Cooking Festival

-- MAIN APPLICATION
addappid(1928710)
-- Game: addappid(1928710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928711, 1, "0933d59a3b13fb8a0a96295bb875d34ebef73636777c11cb335ea1be60ec30dc")
