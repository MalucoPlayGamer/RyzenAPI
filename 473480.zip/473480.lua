-- Lua provided by RyzenAPI
-- Game: Miko Mole

-- MAIN APPLICATION
addappid(473480)
-- Game: addappid(473480)

-- MAIN APP DEPOTS / PACKAGES
addappid(473481, 1, "736f56f5d0d499e8dc2ce53705f2950636ed8f06d7415761e2fb1e8459ffc162")
