-- Lua provided by RyzenAPI
-- Game: Past Particles

-- MAIN APPLICATION
addappid(1943280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943281, 1, "316b213f113d43cbf0f8d23d521e21a35fd86119e0d6da5df7d2e9dbdcbc3926")

