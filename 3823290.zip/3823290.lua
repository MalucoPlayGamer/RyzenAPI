-- Lua provided by RyzenAPI
-- Game: Heroine Conquest

-- MAIN APPLICATION
addappid(3823290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3823291,0,"97c6b9903507e53632ff1f9a079b3d2812ce5117297e91c0f6b76ca9beee5102")

