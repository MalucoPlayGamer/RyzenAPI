-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(753080)
-- Game: addappid(753080)

-- MAIN APP DEPOTS / PACKAGES
addappid(753082,0,"9015f212658e4ec66bec4668be6eca1d70c35b8c44f9794bc87917685739e177")
