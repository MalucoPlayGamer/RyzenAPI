-- Lua provided by RyzenAPI
-- Game: 1409830

-- MAIN APPLICATION
addappid(1409830)
-- Game: addappid(1409830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409831, 1, "2d48b5d0006cdc441f501a7c84673acec7aa74cd9dfb8e4fbcc98a4d8618e314")
addappid(1409833, 1, "105670d6ae4ee8bef9a12fc84b72280df3ed478bbab6fb355fbe5750e391a808")
