-- Lua provided by RyzenAPI
-- Game: Rescue Team 8

-- MAIN APPLICATION
addappid(1148430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148431, 1, "5672ac816c9be1dc06968acde1d5a8fbccf4f082f1f2c552d94d36e5b524a91d")
addappid(1148432, 1, "74bab67fe73e8a102fcaadbaf38faa3c9f1aa2f9aa6e39c108ba1a3c07a17add")
addappid(1148433, 1, "b2ef90d7001fba9e6631187f113bdd5e7dfd8f19cc0b9c882751aabaa63cb6b4")
addappid(1148434, 1, "f701d2f825346779a08c769e5d2437f34a536ffd5ac400bacecb1fc514b9e1ce")
addappid(1148435, 1, "004b16f21753e2f4d1650452758d756ed4693568378d92ad33421ad7189f8731")
addappid(1148436, 1, "9e85a59f1f4be9884167cd712c5f0dee07ed27a39eb748b9a9993c13e09bbdcb")
