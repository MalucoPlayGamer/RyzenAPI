-- Lua provided by RyzenAPI
-- Game: Who's Lila? Soundtrack

-- MAIN APPLICATION
addappid(1929370)
-- Game: addappid(1929370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929371, 1, "66ea1231fe565c355dda174c7b678935af96e6dccd1ed073a0cc5a94c8ca74e2")
