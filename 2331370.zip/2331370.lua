-- Lua provided by RyzenAPI 
-- Game: KITS
addappid(2331370)
addappid(2331371, 1, "fcc59b27852be93a65ef707409560fe93b721dc6349a218679787882109715f8")
