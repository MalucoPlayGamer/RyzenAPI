-- Lua provided by RyzenAPI
-- Game: You Need a Budget 4

-- MAIN APPLICATION
addappid(227320)
-- Game: addappid(227320)

-- MAIN APP DEPOTS / PACKAGES
addappid(227321, 1, "9837ab5ce5d429aca8a7e0fd9971edaecf1827e626eb4997fe31ed3ccdaf5dc4")
