-- Lua provided by RyzenAPI
-- Game: I Wanna Build a Robot

-- MAIN APPLICATION
addappid(1337210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337212,0,"86900d15d90cc31daa38261d36b687bfee8b7302b856005adcd52f842812666f")

