-- Lua provided by RyzenAPI
-- Game: Little Misfortune

-- MAIN APPLICATION
addappid(714120)

-- MAIN APP DEPOTS / PACKAGES
addappid(714121, 1, "9c8332d28ea3cc30897635a7e15fb74637c0ba49bde89c1a8d697ef70c77bcad")
addappid(714122, 1, "e386b71b624c76abab0ebfd0b2ffc234ae03731e4e15517ecc34c083ca208507")
addappid(714123, 1, "a06bfa34f7f5afebbc5cc77e1bf2c5ac5a4cea980938025e54490f9429b5166d")
addappid(1146790, 0, "a5ee4a47b15583927994977ed495dc321cbccf682d8936de73535cd1919a04bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
