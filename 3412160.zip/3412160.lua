-- Lua provided by RyzenAPI
-- Game: 拉斯维加斯模拟器

-- MAIN APPLICATION
addappid(3412160)
addappid(4972780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3412161,0,"e13415101c7f16966fbeb09c1666b9b664b1f8587de1b79e5ff93f37a85f1b00")
addappid(4579370,0,"85efbaa380949c2b7ab1edfde70b05ca834e47fe581784d03b33f6f2582326ac")

