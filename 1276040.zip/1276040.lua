-- Lua provided by RyzenAPI
-- Game: Game: Mini Words: Top Movies

-- MAIN APPLICATION
addappid(1276040)
-- Game: addappid(1276040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276041, 1, "3a1fa8c367b59be31c9d1b4f287628d49702dcec40f48284070549d863330e71")
addappid(1276042, 1, "f9592ca526b10a9c0e24e6e04cb57a571a48f0f8c892747d59c21286009c7bec")
