-- Lua provided by RyzenAPI
-- Game: addappid(2814050)

-- MAIN APPLICATION
addappid(2814050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814050,0,"fdc28af477798d60fb5b1a7798d598b8d57473e6ea89ce5e6949f58594344d9c")
