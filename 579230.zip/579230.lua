-- Lua provided by RyzenAPI
-- Game: Alpacapaca Dash

-- MAIN APPLICATION
addappid(579230)
-- Game: addappid(579230)

-- MAIN APP DEPOTS / PACKAGES
addappid(579231, 1, "fa8021508eb28e0a8e147dd8ba79bc6f2c6996b4a35c295c291ab148c3e1a947")
addappid(579232, 1, "67f2ad39f8c1c4074929b18ba9fb76c00c00ffd5f606fcb7f388bd784a766d26")
addappid(579233, 1, "8f4701e9d225d8de72763488fccd50c733b63a9a1759e3c04483d9059f368ea5")
