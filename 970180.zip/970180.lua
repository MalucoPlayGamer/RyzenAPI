-- Lua provided by RyzenAPI
-- Game: 3 Days in the Abyss

-- MAIN APPLICATION
addappid(970180)

-- MAIN APP DEPOTS / PACKAGES
addappid(970181, 1, "ec75b2d4fdea6e8a09e7f25ce56436aca8f7d6e2f5dd8f6ee1386171967a81df")