-- Lua provided by RyzenAPI 
-- Game: Dear Leader
addappid(812940)
addappid(812941, 1, "f1ac002465a64febb8ac63109ac00cbede0ae11b30445669edcd9826d8729249")
