-- Lua provided by RyzenAPI
-- Game: addappid(812940)

-- MAIN APPLICATION
addappid(812940)

-- MAIN APP DEPOTS / PACKAGES
addappid(812941, 1, "f1ac002465a64febb8ac63109ac00cbede0ae11b30445669edcd9826d8729249")
