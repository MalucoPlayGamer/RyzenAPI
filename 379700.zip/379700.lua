-- Lua provided by RyzenAPI
-- Game: AppID 379700

-- MAIN APPLICATION
addappid(379700)

-- MAIN APP DEPOTS / PACKAGES
addappid(379701, 1, "b1976ceb748cf47a68347cb21a1c1cbe24b9e170df349fd3dfd5f0917ae2b29a")
