-- Lua provided by SkyAPI 
-- Game: SurvivalWorld
addappid(3217980)
addappid(3217981, 1, "fe270087ed4d42bd19692ee162449798eaef8d84135c850372f5e1daae503e7c")
