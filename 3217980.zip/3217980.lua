-- Lua provided by RyzenAPI
-- Game: addappid(3217980)

-- MAIN APPLICATION
addappid(3217980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217981, 1, "fe270087ed4d42bd19692ee162449798eaef8d84135c850372f5e1daae503e7c")
