-- Lua provided by RyzenAPI
-- Game: Kitty Nigiri

-- MAIN APPLICATION
addappid(647950)

-- MAIN APP DEPOTS / PACKAGES
addappid(647951,0,"cc16238e072fc0adf82228bd910d81fa7413176c9425d2d648795f3280f9c3e5")

