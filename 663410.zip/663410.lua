-- Lua provided by RyzenAPI
-- Game: Circle Up

-- MAIN APPLICATION
addappid(663410)

-- MAIN APP DEPOTS / PACKAGES
addappid(663411, 1, "0f5c6c076238ddf52aeed42e2a1536b31d33eb9d728640ac32c4bde43898ea69")
