-- Lua provided by RyzenAPI
-- Game: Game: AppID 2478030

-- MAIN APPLICATION
addappid(2478030)
-- Game: addappid(2478030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478031, 1, "1229c1dcbcef8d505c0f413b7db057b361d3f3623edfd98919dd30384d77f583")
