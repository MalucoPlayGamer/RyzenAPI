-- Lua provided by SkyAPI 
-- Game: AppID 2478030
addappid(2478030)
addappid(2478031, 1, "1229c1dcbcef8d505c0f413b7db057b361d3f3623edfd98919dd30384d77f583")
