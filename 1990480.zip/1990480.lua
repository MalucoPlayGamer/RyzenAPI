-- Lua provided by RyzenAPI
-- Game: Game: Realms

-- MAIN APPLICATION
addappid(1990480)
-- Game: addappid(1990480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990481, 1, "e20707088854b27779c63529012465e361f4260e7a8afc14480ee9b4b8a17630")
