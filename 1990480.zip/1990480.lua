-- Lua provided by RyzenAPI 
-- Game: Realms
addappid(1990480)
addappid(1990481, 1, "e20707088854b27779c63529012465e361f4260e7a8afc14480ee9b4b8a17630")
