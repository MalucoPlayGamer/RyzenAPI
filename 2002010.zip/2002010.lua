-- Lua provided by RyzenAPI
-- Game: My Academy's Special Place

-- MAIN APPLICATION
addappid(2002010)
-- Game: addappid(2002010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002011, 1, "8ca3ed3ee5ebe8067b062df976407eccac47d03f943b0efa25af4e58da270cce")
