-- Lua provided by RyzenAPI
-- Game: Game: AppID 563930

-- MAIN APPLICATION
addappid(563930)
-- Game: addappid(563930)

-- MAIN APP DEPOTS / PACKAGES
addappid(563931, 1, "917419b52c0afb978548562b175e21f88ee19e4256f4d0ee5a5c28ff83287f78")
addappid(563932, 1, "fae499504da32c746ca8c7676af73a1400ce04c0440bf33999f9d53e0eb19fb0")
addappid(563933, 1, "dfb59bb89979065fa30e21babd2979dd404477b2bd598d3bca3d3ec2ff7243b5")
