-- Lua provided by RyzenAPI
-- Game: Game: HARMONIC REFLECTIONS

-- MAIN APPLICATION
addappid(3782920)
-- Game: addappid(3782920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3782921, 1, "cc3bc97fe4ec861dbcb1bc1fe86eb5ea5c02bff9ee82fd7f89424ab8da407c54")
