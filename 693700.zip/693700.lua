-- Lua provided by RyzenAPI
-- Game: Prime Mover

-- MAIN APPLICATION
addappid(693700)
addappid(884650)

-- MAIN APP DEPOTS / PACKAGES
addappid(693701, 1, "cb4d1f5acdcd5e78a555dd7958fbace071ef3a68e5333630fac628d3985acefb")

