-- Lua provided by RyzenAPI
-- Game: addappid(1852520)

-- MAIN APPLICATION
addappid(1852520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852521, 1, "4058ded91d811892b1bdf1bbd28c7fdc7ab2d88d3a98c6541d00ec6c755a71a9")
