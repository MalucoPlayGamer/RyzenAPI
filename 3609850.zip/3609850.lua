-- Lua provided by RyzenAPI
-- Game: Millennium Runners Soundtrack

-- MAIN APPLICATION
addappid(3609850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609851, 1, "6ee6e260e66f35c0c758d58eaf5f744cc78992f7caea826db788514e0c1542e4")
