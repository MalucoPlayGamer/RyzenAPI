-- Lua provided by SkyAPI 
-- Game: Shieldwall
addappid(1216320)
addappid(1216321, 1, "121ffa3e85426ad033d75eabafe829aa9fc20168fff2efc6513554cb11139b6e")
