-- Lua provided by RyzenAPI
-- Game: My Furry Dictator - 18+ Adult Only Patch 🐾

-- MAIN APPLICATION
addappid(1743840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743840,0,"24117525bad4d3472af77e10f0fd7f8664de94e1d0d095de5b7c7b43cb465074")

