-- Lua provided by RyzenAPI
-- Game: Lost in the Rift - Reborn

-- MAIN APPLICATION
addappid(542520)

-- MAIN APP DEPOTS / PACKAGES
addappid(542521,0,"db3e12134511630e0d8c0c0684c51351d3ac5dd785da72205e6f3aa2f29e14ab")

