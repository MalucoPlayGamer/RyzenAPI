-- Lua provided by RyzenAPI
-- Game: Game: Romopolis

-- MAIN APPLICATION
addappid(471170)
-- Game: addappid(471170)

-- MAIN APP DEPOTS / PACKAGES
addappid(471171, 1, "5b13a87525355302c9c2fa2fec3eee4c523266e735c62c79d08868d2bb34d09c")
addappid(471172, 1, "3beee6f362f9671a01e99f6acbfdcf9e7a24e7d94996d9962138bed570baeba4")
addappid(471173, 1, "46794e2483a580f270660825e3ce6b8b006e892bc1f4653ff744dce2a9b86ed5")
addappid(471174, 1, "9766fc3ca1d686615d224050ae2769ccbbfc71c043ef5c5ea485734ed147e0d7")
