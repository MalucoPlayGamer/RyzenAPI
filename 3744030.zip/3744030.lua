-- Lua provided by SkyAPI 
-- Game: After Inc: Revival Soundtrack
addappid(3744030)
addappid(3744031, 1, "49580c7de6b2dec5e0ed92b8e55033b674c8d71b4362a7c7a494a6c44ff38c2e")
