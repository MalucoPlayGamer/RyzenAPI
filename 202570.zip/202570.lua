-- Lua provided by RyzenAPI
-- Game: Game: AppID 202570

-- MAIN APPLICATION
addappid(202570)
-- Game: addappid(202570)

-- MAIN APP DEPOTS / PACKAGES
addappid(202571, 1, "5c97e0f178a064b081a5c639f663b9c9d9878e4837219d865a4f3869b0c35249")
