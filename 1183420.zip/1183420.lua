-- Lua provided by SkyAPI 
-- Game: AppID 1183420
addappid(1183420)
addappid(1183421, 1, "4b0aafcfc77da066c70b57c45cded38f5f2ce3f358c7221ebcae2258ae4fcd80")
