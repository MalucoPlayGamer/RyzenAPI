-- Lua provided by RyzenAPI
-- Game: AppID 1183420

-- MAIN APPLICATION
addappid(1183420)
-- Game: addappid(1183420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183421, 1, "4b0aafcfc77da066c70b57c45cded38f5f2ce3f358c7221ebcae2258ae4fcd80")
