-- Lua provided by RyzenAPI
-- Game: Game: Voice of Belldona Demo

-- MAIN APPLICATION
addappid(2382030)
-- Game: addappid(2382030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382031, 1, "c2a82850c4dd7e629a764cda6d0df28b1f906a2d66e316d3b294689e3930ce60")
