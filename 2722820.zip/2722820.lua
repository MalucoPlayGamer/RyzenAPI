-- Lua provided by RyzenAPI
-- Game: Game: AppID 2722820

-- MAIN APPLICATION
addappid(2722820)
-- Game: addappid(2722820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722821, 1, "a6b3076c05fcc421f3f165a0c3fb77d8c1d806262a86474b269f8f6d07ef6e9a")
