-- Lua provided by RyzenAPI
-- Game: Strategic Command WWII: War in the Pacific

-- MAIN APPLICATION
addappid(2740080)
addappid(3508930)
-- Game: addappid(2740080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740081, 1, "2800de2bd9ef3e4aabe7c261d2e0f3a20fc0dc781b5cb5a5cbe4d0a461e88427")
addappid(2740082, 1, "5f36c4cf63844cca6d0d9233043b3c9791520e1fc884c7068fb7fced9bf4074c")
