-- Lua provided by RyzenAPI
-- Game: AppID 1042130

-- MAIN APPLICATION
addappid(1042130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042131, 1, "5fdb090ac3f2cf341b9ec0c8067fed04e875e11cf95a58550ffe771b9bdc901b")
