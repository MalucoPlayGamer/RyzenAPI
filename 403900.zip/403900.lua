-- Lua provided by RyzenAPI
-- Game: AppID 403900

-- MAIN APPLICATION
addappid(403900)
-- Game: addappid(403900)

-- MAIN APP DEPOTS / PACKAGES
addappid(403901, 1, "13ee0b066ba913990a03296f4008ce02b06ebd374dfd61a7f1b0f537dc644256")
