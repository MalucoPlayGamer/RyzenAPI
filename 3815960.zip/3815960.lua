-- Lua provided by RyzenAPI
-- Game: The Mines

-- MAIN APPLICATION
addappid(3815960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3815961, 1, "7e1761d210c43c5207fcb0d3842a05d1c6ebc8c4c0a693f6bc17f91a958f3ee4")

