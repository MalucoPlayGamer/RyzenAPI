-- 4860340's Lua and Manifest Created by Hubcap Manifest
-- Dream House Cleaning
-- Created: August 14, 2026 at 06:09:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4860340) -- Dream House Cleaning
-- MAIN APP DEPOTS
addappid(4860341, 1, "0e18ea558b720bf6be4bb0c19b45063a87558f63ad64595aa3192dc3ef4cadd7") -- Depot 4860341
setManifestid(4860341, "675841047158538315", 1114253705)