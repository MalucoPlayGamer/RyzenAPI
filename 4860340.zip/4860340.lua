-- Lua provided by RyzenAPI
-- Game: Dream House Cleaning

-- MAIN APPLICATION
addappid(4860340) -- Dream House Cleaning

-- MAIN APP DEPOTS / PACKAGES
addappid(4860341, 1, "0e18ea558b720bf6be4bb0c19b45063a87558f63ad64595aa3192dc3ef4cadd7") -- Depot 4860341

