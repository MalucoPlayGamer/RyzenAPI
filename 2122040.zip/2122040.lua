-- Lua provided by RyzenAPI
-- Game: Dimensional Gears

-- MAIN APPLICATION
addappid(2122040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122041, 1, "cea2051a34951dfaa5b52be6888100141afe5fd52e6afe19dbee0d2e0783e11d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
