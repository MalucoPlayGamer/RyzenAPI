-- Lua provided by RyzenAPI 
-- Game: Dimensional Gears
addappid(2122040)
addappid(2122041, 1, "cea2051a34951dfaa5b52be6888100141afe5fd52e6afe19dbee0d2e0783e11d")
