-- Lua provided by RyzenAPI
-- Game: Game: AppID 1971230

-- MAIN APPLICATION
addappid(1971230)
-- Game: addappid(1971230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971231, 1, "7d5dfcc372246827f81a946cd745ef30dee565abb4fbdecf7192cec18a334ed6")
