-- Lua provided by RyzenAPI
-- Game: addappid(885000)

-- MAIN APPLICATION
addappid(885000)

-- MAIN APP DEPOTS / PACKAGES
addappid(885001, 1, "02645ffcb89ba0e277f11418e05f7dc010d530aed0399178ea0acfb44beada08")
