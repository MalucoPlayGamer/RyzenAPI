-- Lua provided by RyzenAPI
-- Game: Monster Knockout

-- MAIN APPLICATION
addappid(2181620)
addappid(2258600)
addappid(2258610)
addappid(3420470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(2181621, 1, "a7bedd17f3a6ba86683a8a0a3ec6d8db4e46d636a82c8dbbaaba1a3f00506a63")
addappid(2181622, 1, "ed28a8e8a78011a12bba5d63194d4281768bb03a67ebcd204edc23fd9e1d511d")
addappid(2181623, 1, "2dd684c5caf39eada1f27df149cf10b2193c34839ec6c2e8fff1a604b30e443a")

