-- Lua provided by RyzenAPI
-- Game: Game: Monster Knockout

-- MAIN APPLICATION
addappid(2181620)
-- Game: addappid(2181620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181621, 1, "a7bedd17f3a6ba86683a8a0a3ec6d8db4e46d636a82c8dbbaaba1a3f00506a63")
addappid(2181622, 1, "ed28a8e8a78011a12bba5d63194d4281768bb03a67ebcd204edc23fd9e1d511d")
addappid(2181623, 1, "2dd684c5caf39eada1f27df149cf10b2193c34839ec6c2e8fff1a604b30e443a")
