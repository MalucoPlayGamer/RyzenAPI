-- Lua provided by RyzenAPI
-- Game: Game: Detroit: Become Human Demo

-- MAIN APPLICATION
addappid(1224230)
-- Game: addappid(1224230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224231, 1, "a612d52ff30d0fa42cb72462da1807a094453883731b4b9962deee527f59125b")
