-- Lua provided by RyzenAPI
-- Game: Spaceteam VR

-- MAIN APPLICATION
addappid(866770)

-- MAIN APP DEPOTS / PACKAGES
addappid(866771, 1, "3f870bec1c9c1e175b9a26d581c5e5658e10f852992eec883107d1a5e8095ba8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
