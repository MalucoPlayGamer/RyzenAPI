-- Lua provided by RyzenAPI
-- Game: addappid(866770)

-- MAIN APPLICATION
addappid(866770)

-- MAIN APP DEPOTS / PACKAGES
addappid(866771, 1, "3f870bec1c9c1e175b9a26d581c5e5658e10f852992eec883107d1a5e8095ba8")
