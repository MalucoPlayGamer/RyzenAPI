-- Lua provided by RyzenAPI
-- Game: Yugo: the non-game

-- MAIN APPLICATION
addappid(3151830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151831, 1, "8c7cc436915d5d113e33241f4760c29d9d035256dd9a6ab10f82ebb779a14157")
