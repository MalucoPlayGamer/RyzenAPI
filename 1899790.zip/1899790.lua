-- Lua provided by RyzenAPI
-- Game: 1899790

-- MAIN APPLICATION
addappid(1899790)
-- Game: addappid(1899790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899791, 1, "01fcde8b8106374cc26800dc104131f71ebfbf6f5cbc21b361067ee3cce1734b")
