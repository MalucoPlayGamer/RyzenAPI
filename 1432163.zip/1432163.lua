-- Lua provided by RyzenAPI
-- Game: 1432163

-- MAIN APPLICATION
addappid(1432163)
-- Game: addappid(1432163)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432163,0,"bde532d43f291e32f2e085a36b4daf8e85106ba1081882a4b5aed92f346ac10d")
