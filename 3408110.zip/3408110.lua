-- Lua provided by RyzenAPI
-- Game: Game: Cafemart Simulator

-- MAIN APPLICATION
addappid(3408110)
-- Game: addappid(3408110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408111, 1, "2aef89bb87db60712d3e2c4b11326e22d215f62e1d19aca2105194e14dc865ac")
