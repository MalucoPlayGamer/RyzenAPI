-- Lua provided by RyzenAPI
-- Game: Cafemart Simulator

-- MAIN APPLICATION
addappid(3408110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408111, 1, "2aef89bb87db60712d3e2c4b11326e22d215f62e1d19aca2105194e14dc865ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
