-- Lua provided by RyzenAPI 
-- Game: AppID 1159660
addappid(1159660)
addappid(1159661, 1, "d32d1a1b8bfbeb92237a8f1aca5fc86cfe7bc791f5628a9340f2a9cd8515ce49")
