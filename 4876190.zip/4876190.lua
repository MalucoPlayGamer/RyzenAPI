-- Lua provided by RyzenAPI
-- Game: Not a bug

-- MAIN APPLICATION
addappid(4876190) -- Not a bug

-- MAIN APP DEPOTS / PACKAGES
addappid(4876191, 1, "5a0707677e7bda617b9bb36bd9ceb064c9a4a42f0ed7295fb6ef3615fe533c70") -- Depot 4876191

