-- 4876190's Lua and Manifest Created by Hubcap Manifest
-- Not a bug
-- Created: August 08, 2026 at 22:55:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4876190) -- Not a bug
-- MAIN APP DEPOTS
addappid(4876191, 1, "5a0707677e7bda617b9bb36bd9ceb064c9a4a42f0ed7295fb6ef3615fe533c70") -- Depot 4876191
setManifestid(4876191, "7841362733718349211", 102099153)