-- Lua provided by RyzenAPI
-- Game: 新倾国之怒

-- MAIN APPLICATION
addappid(1685470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685471, 1, "a5b12625bd5e532b3a16934951860adefd0c6b6d7dda5414daf40426edf44bb5")
