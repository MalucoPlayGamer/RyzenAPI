-- Lua provided by RyzenAPI
-- Game: Cosmic Tempest

-- MAIN APPLICATION
addappid(3688310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688311, 1, "e0deb86fcb4a8a08fff47ea06c7cee74a5349ae4a3baf96f40632dc07df70382")

