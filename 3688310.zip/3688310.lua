-- Lua provided by RyzenAPI 
-- Game: Cosmic Tempest
addappid(3688310)
addappid(3688311, 1, "e0deb86fcb4a8a08fff47ea06c7cee74a5349ae4a3baf96f40632dc07df70382")
