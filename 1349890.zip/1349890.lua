-- Lua provided by RyzenAPI
-- Game: Game: The last earth man

-- MAIN APPLICATION
addappid(1349890)
-- Game: addappid(1349890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349891, 1, "88f124bdfa0e1c1f2e8000ca2724c46b5278626c9e1fe6de740426719c85f49e")
