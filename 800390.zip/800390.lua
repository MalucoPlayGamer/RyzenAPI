-- Lua provided by RyzenAPI
-- Game: Puppet Fever

-- MAIN APPLICATION
addappid(800390)

-- MAIN APP DEPOTS / PACKAGES
addappid(800391,0,"cb70cd200eabbd949492d1fdf475e0626937c45d1d7e9c0e6543c00b73981397")

