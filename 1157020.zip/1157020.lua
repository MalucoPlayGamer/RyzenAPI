-- Lua provided by RyzenAPI
-- Game: 1157020

-- MAIN APPLICATION
addappid(1157020)
-- Game: addappid(1157020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157021, 1, "eb14803d665f61605ac48983b0d066eff3f226c927ef7e9cd6117d469ecc73d3")
