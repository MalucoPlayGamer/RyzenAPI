-- Lua provided by RyzenAPI
-- Game: 1001 Hugs

-- MAIN APPLICATION
addappid(1157020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1157021, 1, "eb14803d665f61605ac48983b0d066eff3f226c927ef7e9cd6117d469ecc73d3")

