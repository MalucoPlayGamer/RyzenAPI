-- Lua provided by RyzenAPI
-- Game: Game: Project Warlock II

-- MAIN APPLICATION
addappid(1640300)
-- Game: addappid(1640300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640301, 1, "0a4a648a90ec7381d779c624da1caf5b9fec4e69b48d0aae04af2a4011dafe29")
addappid(1640304, 1, "b2270fbdd3fc0854ded2b31343530bda1a3222e0ea70945212458f258a97ad8d")
