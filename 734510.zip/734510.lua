-- Lua provided by RyzenAPI
-- Game: 734510

-- MAIN APPLICATION
addappid(734510)
-- Game: addappid(734510)

-- MAIN APP DEPOTS / PACKAGES
addappid(734511, 1, "814fa2177ec8de1bac49d6ee31d547736ab6e6d69a41a96a0de805a34b1ed196")
