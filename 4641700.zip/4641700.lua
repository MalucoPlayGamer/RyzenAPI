-- Lua provided by RyzenAPI
-- Game: Sill Cats

-- MAIN APPLICATION
addappid(4641700)

