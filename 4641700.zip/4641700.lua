-- Lua provided by RyzenAPI
-- Game: Sill Cats

-- MAIN APPLICATION
addappid(4641700)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4641710)
addappid(4641720)
addappid(4641730)
addappid(4824710)
addappid(4852410)
addappid(4854110)
addappid(4890190)
addappid(4890950)
