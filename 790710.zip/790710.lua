-- Lua provided by RyzenAPI
-- Game: World of Warplanes

-- MAIN APPLICATION
addappid(790710)

-- MAIN APP DEPOTS / PACKAGES
addappid(790712,0,"529fe4f9361644adfdc2389388bc10afd1563f0289b363c7dc39bfd113061639")

