-- Generated with Luie @ https://lua.tools/
-- 790710 - World of Warplanes
-- Generated 2026-08-23 07:05:54 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(790710, 1, "de400295c24024c03f64c6e558da90ce2e9035f10587ddbae19956083a66685d")

-- Main Depots
addappid(790712, 1, "529fe4f9361644adfdc2389388bc10afd1563f0289b363c7dc39bfd113061639") -- (windows)
setManifestid(790712, "5419002723822955597", 52080903693)

-- DLC's (no depot keys required)
addappid(890050) -- DLC 890050
addappid(1001290) -- World of Warplanes -Starter Pack
addappid(1001291) -- World of Warplanes -I-16-29 Pack
addappid(1001320) -- World of Warplanes -P-39N-1 Pack
addappid(1001321) -- World of Warplanes -Meteor Pack
addappid(1881860) -- DLC 1881860
addappid(1881970) -- World of Warplanes - I-5 SHKAS Pack
addtoken(1881970, "6741215742446035724")
addappid(1881990) -- World of Warplanes - P-51K Mustang Pack
addappid(1882010) -- World of Warplanes - Ki-43-Ic Pack
addappid(2288670) -- DLC 2288670
addappid(2288671) -- World of Warplanes - SNCASE SE 100 Pack
addappid(2510900) -- DLC 2510900
addappid(2510910) -- DLC 2510910
addappid(2510920) -- World of Warplanes - Tupolev Tu-1 Pack
addappid(2510930) -- World of Warplanes - Messerschmitt Me 210 Pack
addappid(2510940) -- World of Warplanes - Douglas A-26B Invader Pack
addappid(2805180) -- DLC 2805180
addappid(3444680) -- DLC 3444680
addappid(3844470) -- World of Warplanes - Trident Strike
addappid(4273710) -- World of Warplanes - Flying Mustang Pack
addappid(4273720) -- World of Warplanes - Swift Takeoff Pack

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
