-- Lua provided by RyzenAPI 
-- Game: Choco Pixel 5
addappid(1307640)
addappid(1307641, 1, "4b7383a308dc3deaa64f2ac9e6a76dddabf176dbd2d4e19c2cccc3d97e4683c5")
