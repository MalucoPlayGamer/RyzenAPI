-- Lua provided by SkyAPI 
-- Game: Aviassembly
addappid(2660460)
addappid(2660461, 1, "20759e43cbde1f884d0690ee03b21326da837eb3937e6c811d57f5669dc3b9d2")
