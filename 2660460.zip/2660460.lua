-- Lua provided by RyzenAPI
-- Game: Aviassembly

-- MAIN APPLICATION
addappid(2660460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660461, 1, "20759e43cbde1f884d0690ee03b21326da837eb3937e6c811d57f5669dc3b9d2")

