-- Lua provided by RyzenAPI
-- Game: addappid(3169060)

-- MAIN APPLICATION
addappid(3169060)
addappid(3734600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169061, 1, "f227a4863a87f023180ec969b79b06bb2e28e6aa0dff21d21554dae40f660ffd")
