-- Lua provided by RyzenAPI
-- Game: 1580960

-- MAIN APPLICATION
addappid(1580960)
-- Game: addappid(1580960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580961, 1, "7816adfef0a266126d7e1f1894513c9df1d48f4e3a4e2b9f58b49cfda7259cf3")
