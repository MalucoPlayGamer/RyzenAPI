-- Lua provided by RyzenAPI
-- Game: 838160

-- MAIN APPLICATION
addappid(838160)
-- Game: addappid(838160)

-- MAIN APP DEPOTS / PACKAGES
addappid(838161, 1, "5d8138ee028b9baa7e6e4e09b15d137b85d0477faf1800b01a780f51d6348486")
