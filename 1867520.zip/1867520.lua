-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1867520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867522,0,"32139e23768d4680e8589e7bc3715018370a69af6252c674b8069f5b74e6161a")
