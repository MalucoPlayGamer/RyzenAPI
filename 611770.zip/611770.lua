-- Lua provided by RyzenAPI
-- Game: Void Source

-- MAIN APPLICATION
addappid(611770)
addappid(775031)

-- MAIN APP DEPOTS / PACKAGES
addappid(611771, 1, "596aae474ea74e34d931ac4ace04231da2a5fc8a677650be96b6c5dfbd634c6a")
