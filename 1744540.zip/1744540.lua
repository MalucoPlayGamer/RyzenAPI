-- Lua provided by RyzenAPI
-- Game: addappid(1744540)

-- MAIN APPLICATION
addappid(1744540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744540,0,"5287664570dad14ed7d7b9c4d9d36458952006a8ae2e6f4bd7e8df7cf21698ad")
