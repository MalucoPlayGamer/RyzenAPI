-- Lua provided by RyzenAPI
-- Game: Biodigital

-- MAIN APPLICATION
addappid(923460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(923461, 1, "38389946d93b40eddb57857314423952670610febf1571c0120b0a7bbda1e568")

