-- Lua provided by RyzenAPI
-- Game: Game: AppID 923460

-- MAIN APPLICATION
addappid(923460)
-- Game: addappid(923460)

-- MAIN APP DEPOTS / PACKAGES
addappid(923461, 1, "38389946d93b40eddb57857314423952670610febf1571c0120b0a7bbda1e568")
