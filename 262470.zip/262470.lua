-- Lua provided by RyzenAPI 
-- Game: Rollers of the Realm
addappid(262470)
addappid(262471, 1, "8e0856c71d817fd13a62e2d498b6c02a1a3d7416bfab0ce0ffa76b6234cf20f5")
