-- Lua provided by RyzenAPI
-- Game: Rollers of the Realm

-- MAIN APPLICATION
addappid(262470)

-- MAIN APP DEPOTS / PACKAGES
addappid(262471, 1, "8e0856c71d817fd13a62e2d498b6c02a1a3d7416bfab0ce0ffa76b6234cf20f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
