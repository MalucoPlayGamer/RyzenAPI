-- 4265410's Lua and Manifest Created by Hubcap Manifest
-- Innocent Assault SS
-- Created: August 07, 2026 at 08:54:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4265410, 1, "1c8689082cd77af5edc57b88a3e47d9c9726055147ef93deca9332d7b715a683") -- Innocent Assault SS
-- MAIN APP DEPOTS
addappid(4265411, 1, "a47c26cd9b51e22221088ac5b55e642bf02754135978e8bc8b628663d888f614") -- Depot 4265411
setManifestid(4265411, "3713481491945225826", 3072950097)
addappid(4265412, 1, "0657e59dd38170bbf2b5d795e426b9538c30901ea19ed86830180d52bf391fe4") -- Depot 4265412
setManifestid(4265412, "1898477773090459039", 3072423761)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Innocent Assault SS - ArtBook (AppID: 4803940)
addappid(4803940)
addappid(4803941, 1, "c92064368377e094a40ad8dc1d30a45c956c727c9c2af2739fce8a8f55b54a45") -- Innocent Assault SS - ArtBook - Depot 4803941
setManifestid(4803941, "634725796014788159", 1307088790)
addappid(4803942, 1, "70f0936b45f000d1733692923ee430d660257e2548bf8d6af5faaecf20b8cba2") -- Innocent Assault SS - ArtBook - Depot 4803942
setManifestid(4803942, "7124310908157638383", 1304522407)
addappid(4803943, 1, "d0e9e9ed600587b3e5de9a5f7d1583edbc5dee20347fe8fe50191947c1c51fa8") -- Innocent Assault SS - ArtBook - Depot 4803943
setManifestid(4803943, "6058644692149599685", 1304562499)
addappid(4803944, 1, "b24cedfddfe0d9032a2eadb9244182f99df0fc261498a0836845a58c228ff2e5") -- Innocent Assault SS - ArtBook - Depot 4803944
setManifestid(4803944, "7027500959171513625", 1302550511)
addappid(4803945, 1, "b16865db48bc0bd83b0a3dc88713ca4123416ce9f0d147c09c21253375966702") -- Innocent Assault SS - ArtBook - Depot 4803945
setManifestid(4803945, "5508170699383960879", 1303457572)