-- Lua provided by RyzenAPI
-- Game: AppID 743650

-- MAIN APPLICATION
addappid(743650)

-- MAIN APP DEPOTS / PACKAGES
addappid(743651, 1, "527af2d1792b4ae9dab3157589125765d37b1670dbe436d89ccec29649ca5c7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
