-- Lua provided by RyzenAPI
-- Game: Game: AppID 500920

-- MAIN APPLICATION
addappid(500920)
-- Game: addappid(500920)

-- MAIN APP DEPOTS / PACKAGES
addappid(500921, 1, "b924f3a15284e71512ad44111890b7bbf3f68253b09f6571293ef3cbc99451ac")
