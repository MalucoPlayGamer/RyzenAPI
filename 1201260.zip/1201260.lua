-- Lua provided by RyzenAPI
-- Game: Happy Engine

-- MAIN APPLICATION
addappid(1201260)
addappid(1201980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201261, 1, "65ffc736adfad14fe99915a4fd33964032c41230be9ac44449a653a53f2d3c57")
