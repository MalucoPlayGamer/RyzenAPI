-- Lua provided by RyzenAPI
-- Game: Snake Eyes Dungeon

-- MAIN APPLICATION
addappid(740240)

-- MAIN APP DEPOTS / PACKAGES
addappid(740241, 1, "1c959e696b80bd9d82f1fb6c34fc44bb60d7d7139827bf4233e529648cd48177")
