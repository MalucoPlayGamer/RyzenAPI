-- Lua provided by RyzenAPI
-- Game: One-armed cook

-- MAIN APPLICATION
addappid(1977530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977531, 1, "98b4b8e72a6e160f09fcd025685d8cbbd09b3707ad3e5b72d192ece21e832963")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2007210)
addappid(2125390)
addappid(2393610)
