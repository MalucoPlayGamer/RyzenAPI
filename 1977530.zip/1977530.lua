-- Lua provided by RyzenAPI
-- Game: addappid(1977530)

-- MAIN APPLICATION
addappid(1977530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977531, 1, "98b4b8e72a6e160f09fcd025685d8cbbd09b3707ad3e5b72d192ece21e832963")
