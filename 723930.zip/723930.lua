-- Lua provided by RyzenAPI
-- Game: Dark Romance: Vampire in Love Collector's Edition

-- MAIN APPLICATION
addappid(723930)

-- MAIN APP DEPOTS / PACKAGES
addappid(723931,0,"c9a4cfc932d628f50342eb4a3ffe29ff118acd5c944f1fc7a03eea3fe60a85f7")
addappid(723932,0,"fc0b1b5772afe0b86ac9b6bd9871cb4aa3353cd206be7499f001834afc07334c")

