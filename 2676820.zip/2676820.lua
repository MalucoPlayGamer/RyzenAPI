-- Lua provided by RyzenAPI
-- Game: 无畏舰队：炮火战争（Noah City:Rise of the conqueror）

-- MAIN APPLICATION
addappid(2676820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676821, 1, "30f551d706de129d7d3fed397df163e90cc7bc6111dc9459740520b51bd21333")

