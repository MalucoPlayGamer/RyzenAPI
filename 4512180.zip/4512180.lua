-- Lua provided by RyzenAPI
-- Game: Vivid Intrusion

-- MAIN APPLICATION
addappid(4512180) -- Vivid Intrusion

-- MAIN APP DEPOTS / PACKAGES
addappid(4512181, 1, "9699986fde22ca19e0ec5837398df63a80244e744c6b87e81895c948b63423e4") -- Depot 4512181
addappid(4512182, 1, "24c965c6477d61f25f4972019aea4b4f75b649244fe585183f7bd7c7247c0f17") -- Depot 4512182

