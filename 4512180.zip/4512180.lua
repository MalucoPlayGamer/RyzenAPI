-- 4512180's Lua and Manifest Created by Hubcap Manifest
-- Vivid Intrusion
-- Created: August 11, 2026 at 12:46:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4512180) -- Vivid Intrusion
-- MAIN APP DEPOTS
addappid(4512181, 1, "9699986fde22ca19e0ec5837398df63a80244e744c6b87e81895c948b63423e4") -- Depot 4512181
setManifestid(4512181, "9104667331836383280", 165829848)
addappid(4512182, 1, "24c965c6477d61f25f4972019aea4b4f75b649244fe585183f7bd7c7247c0f17") -- Depot 4512182
setManifestid(4512182, "1868514404782692113", 130832120)