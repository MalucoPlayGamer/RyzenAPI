-- Lua provided by RyzenAPI
-- Game: 1618340

-- MAIN APPLICATION
addappid(1618340)
-- Game: addappid(1618340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618341, 1, "473ed56093b5d2fcfbf97853c124b8f1209ede1efb9f2297be4eecbe0aac6134")
