-- Lua provided by RyzenAPI
-- Game: Archaeology - Medieval

-- MAIN APPLICATION
addappid(3214810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214811, 1, "95fa3998cac02e8927bd214147ad409c00911625d5ad1c1025e0a89c2a321983")

