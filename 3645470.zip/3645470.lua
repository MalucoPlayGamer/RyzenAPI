-- Lua provided by RyzenAPI
-- Game: Sad Virus Winter

-- MAIN APPLICATION
addappid(3645470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645471, 1, "4b34b99b73cfec83f4a42d156d3dc2c27d83819eb42bb5ef581c6d86926f9d06")

