-- Lua provided by RyzenAPI 
-- Game: Sad Virus Winter
addappid(3645470)
addappid(3645471, 1, "4b34b99b73cfec83f4a42d156d3dc2c27d83819eb42bb5ef581c6d86926f9d06")
