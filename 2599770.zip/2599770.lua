-- Lua provided by RyzenAPI
-- Game: Tactical Warfare

-- MAIN APPLICATION
addappid(2599770)
-- Game: addappid(2599770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599771, 1, "d82fa44d507ef702920ae0fe0a7d8f15c82ce01563f67d2c2b7bd804d993c9d7")
