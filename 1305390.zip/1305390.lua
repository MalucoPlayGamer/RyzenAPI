-- Lua provided by RyzenAPI 
-- Game: Gel-Tank
addappid(1305390)
addappid(1305391, 1, "56547781d28f99560337d2b3df4864db4fdfa24193402f7a803923008ae506bb")
