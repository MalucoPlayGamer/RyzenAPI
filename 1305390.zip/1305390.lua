-- Lua provided by RyzenAPI
-- Game: Gel-Tank

-- MAIN APPLICATION
addappid(1305390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305391, 1, "56547781d28f99560337d2b3df4864db4fdfa24193402f7a803923008ae506bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
