-- Lua provided by RyzenAPI
-- Game: addappid(3581680)

-- MAIN APPLICATION
addappid(3581680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3581681, 1, "9061b332b16d9d388afb1522ec019f3207fe92be90abd2dbec0ed02ef5a68a9f")
