-- Lua provided by SkyAPI 
-- Game: AppID 2143240
addappid(2143240)
addappid(2143241, 1, "3c542b4f002992a1b7741edf6a4061a7114c911bb6810ece5a328755ed59505f")
