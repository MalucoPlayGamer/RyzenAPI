-- Lua provided by RyzenAPI
-- Game: Quasimorph Demo

-- MAIN APPLICATION
addappid(2143240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143241, 1, "3c542b4f002992a1b7741edf6a4061a7114c911bb6810ece5a328755ed59505f")
