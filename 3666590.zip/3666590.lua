-- Lua provided by RyzenAPI
-- Game: Hentai Ladyboy Ren

-- MAIN APPLICATION
addappid(3666590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666591, 1, "20f077a13a9d8ce0b62cffcc4072c393dfbfd7e55a737a8299377ac8bdd7a956")
