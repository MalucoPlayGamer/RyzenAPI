-- Lua provided by RyzenAPI
-- Game: Animal Shelter 2: Prologue

-- MAIN APPLICATION
addappid(2887780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887781, 1, "deb57a9eea72237f5f18e959c9c7b0662f287ce3455297d8d2eb020f12525230")

