-- Lua provided by SkyAPI 
-- Game: Animal Shelter 2: Prologue
addappid(2887780)
addappid(2887781, 1, "deb57a9eea72237f5f18e959c9c7b0662f287ce3455297d8d2eb020f12525230")
