-- Lua provided by RyzenAPI 
-- Game: Runaway Demon Bride
addappid(1250180)
addappid(1250181, 1, "8b031a0905c2fadce4743a8c16825bb637c4c1f030e2b70b5500d7e4a001969c")
addappid(1250182, 1, "a0a2d84c3e51c2ee4b7835efb267bec635ceb00cb0456cb734369347e8e18b51")
