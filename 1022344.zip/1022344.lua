-- Lua provided by RyzenAPI
-- Game: DFF NT: Locke Cole Starter Pack

-- MAIN APPLICATION
addappid(1022344)
-- Game: addappid(1022344)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022344,0,"59425e0f41926e16c8e7eb08e344866843b20337c4d7f00014948473ccb747f0")
