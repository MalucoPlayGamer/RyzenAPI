-- Lua provided by RyzenAPI
-- Game: Anomaly Rooms

-- MAIN APPLICATION
addappid(3725070)
-- Game: addappid(3725070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3725072,0,"379f247c4c9bd95dc627d7160f314441d8bd58340150c20356c927d35df64787")
