-- Lua provided by RyzenAPI 
-- Game: Fragrance Point
addappid(2303610)
addappid(2303611, 1, "21f7803a317bc7dd3758c44a06f07eb7218807aa539578e5962af16a3f59333c")
