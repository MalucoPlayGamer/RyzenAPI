-- Lua provided by RyzenAPI
-- Game: Project Three

-- MAIN APPLICATION
addappid(1895720)
addappid(3404310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895721, 1, "f308d728a87295770c01e88d299b6fe3c72d2d605a9a2ecc153f0b922eb4a140")
