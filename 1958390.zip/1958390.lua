-- Lua provided by RyzenAPI
-- Game: Game: Innocence Or Money Season 1 - Episodes 1 to 3

-- MAIN APPLICATION
addappid(1958390)
addappid(2753550)
-- Game: addappid(1958390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958391, 1, "4aa1959328c69eac10af7546c3a2fc2da9d84067636203ad3268e4595d207e4c")
addappid(1958392, 1, "cf8c3212f560652a6f0405feb9c2e9da83ca2c8549735904064a9cbfa413f75d")
