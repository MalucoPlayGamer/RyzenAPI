-- Lua provided by RyzenAPI
-- Game: AppID 790130

-- MAIN APPLICATION
addappid(790130)
-- Game: addappid(790130)

-- MAIN APP DEPOTS / PACKAGES
addappid(790131, 1, "6e4022a739d81af894bac88ce994be84018a882c27e3826fde0516ecc1b79d65")
