-- Lua provided by SkyAPI 
-- Game: Epic of Tarot
addappid(2687140)
addappid(2687141, 1, "5d7d12e04a5db2c08aa981acc054e73da9767eda91e1839e39bcd4fbdb296874")
