-- Lua provided by RyzenAPI 
-- Game: Story of White Stone State
addappid(1101980)
addappid(1101981, 1, "ed97d23d5c201a258f969ec784f01e7b86f2e978bc87e0ae2c4209d11271c638")
