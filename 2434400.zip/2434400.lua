-- Lua provided by RyzenAPI
-- Game: Ghost Simulator

-- MAIN APPLICATION
addappid(2434400)
-- Game: addappid(2434400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434401, 1, "5d35ca8b47580d846416b344103c60ff1176aed3a6cfc0fbbb5874310c3c3699")
