-- Lua provided by RyzenAPI
-- Game: addappid(3288480)

-- MAIN APPLICATION
addappid(3288480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288480,0,"3e3828e344ebf5ebf060fc7f1f19dcae7a71a9958a5835a0d654c341e6bb2445")
