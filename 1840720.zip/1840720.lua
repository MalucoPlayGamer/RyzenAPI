-- Lua provided by RyzenAPI
-- Game: MAGLAM LORD - Special Pack DLC

-- MAIN APPLICATION
addappid(1840720)
-- Game: addappid(1840720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840720,0,"c0f177a2a2094b8d6e7ccdead86770a6ca6c97bc204655df1081376fd8145431")
