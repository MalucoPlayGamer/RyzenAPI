-- Lua provided by RyzenAPI
-- Game: 3372200

-- MAIN APPLICATION
addappid(3372200)
-- Game: addappid(3372200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372201, 1, "b2a82557c2dfd3acebd089ff26a525133d4ce1b08f463a8ef0725705b0649917")
