-- Lua provided by RyzenAPI
-- Game: Super Steampunk Pinball 2D

-- MAIN APPLICATION
addappid(775490)

-- MAIN APP DEPOTS / PACKAGES
addappid(775491, 1, "09296b898fcb419bed52a26f2c3626a38552d388771d479dfa7278916c04eb85")
addappid(781400, 0, "d6b447ad76d6c6581fc0ffc128fccabb8e78a994a25b05e45b939733fb5bac9d")

