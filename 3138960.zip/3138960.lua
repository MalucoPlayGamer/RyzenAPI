-- Lua provided by RyzenAPI
-- Game: Game: Immerse Gamepack

-- MAIN APPLICATION
addappid(3138960)
-- Game: addappid(3138960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138961, 1, "d36eadc9baf30a06cb898e7d7c7664ee8b551a93155c884834113eab00cc6165")
addappid(3138962, 1, "b6c0b9a6b38edd7b1691f888f1176ed2a9f96747a9614196e90480e5a4fa2109")
addappid(3138963, 1, "f0c5b70e118f9ffead87e096e9e9699ec25650456081008ddf75b6b78df72581")
