-- Lua provided by RyzenAPI
-- Game: Gummy Bear Idle: No Job, Just Jelly♥.

-- MAIN APPLICATION
addappid(3206860)
addappid(3949360)
addappid(3949370)
addappid(3949380)
addappid(3949390)
addappid(3949400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206867,0,"f3c3dbe3480b6986ff4230d5bf6430c645d617ac661df523a4e53a91f7746375")
addappid(3949361,0,"217466a15974f0a0821ef7bd7c427dec586af5890568ebb930d67d95c079e5b8")
addappid(3949371,0,"124153945c6e5fb8d8676aebe1e3eeaea42284cd115283c7529692dac71a8188")
addappid(3949391,0,"cab09e7d1d78bef32122cebaa3c351abf95dfac04a978f6df8857e179dca74fe")
addappid(3949401,0,"60cc60ec378ece26cd97a7f19e1afbf271e4445ed9010b003417d94e63053903")

