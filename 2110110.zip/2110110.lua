-- Lua provided by RyzenAPI
-- Game: Motherless - Season 1

-- MAIN APPLICATION
addappid(2110110)
addappid(2128150)
addappid(2156780)
addappid(2157990)
addappid(2158000)
addappid(2158010)
addappid(2158011)
addappid(2204890)
addappid(2261470)
addappid(2611790)
addappid(3195550)
addappid(3649120)
addappid(4509180)
addappid(4987100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110111, 1, "6431489b1541bc67ac1f67b0f891dc75be8446657c444bfc5837ae0dd619d162")

