-- Lua provided by RyzenAPI
-- Game: addappid(2110110)

-- MAIN APPLICATION
addappid(2110110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110111, 1, "6431489b1541bc67ac1f67b0f891dc75be8446657c444bfc5837ae0dd619d162")
