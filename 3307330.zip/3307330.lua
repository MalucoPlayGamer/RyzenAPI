-- Lua provided by RyzenAPI
-- Game: 3307330

-- MAIN APPLICATION
addappid(3307330)
-- Game: addappid(3307330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307331, 1, "fc09854754854d97b47477f632dcf2ef1043e2f98b0d160ebcdb149cccc2c1b2")
