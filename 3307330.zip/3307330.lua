-- Lua provided by SkyAPI 
-- Game: AppID 3307330
addappid(3307330)
addappid(3307331, 1, "fc09854754854d97b47477f632dcf2ef1043e2f98b0d160ebcdb149cccc2c1b2")
