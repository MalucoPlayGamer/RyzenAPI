-- Lua provided by RyzenAPI
-- Game: 1690210

-- MAIN APPLICATION
addappid(1690210)
-- Game: addappid(1690210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690211, 1, "b9c3b17b4a6d4fdc42d8eeda1352590cd3c28e076bcaf87efdbe1a78c40e42a0")
