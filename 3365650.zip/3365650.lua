-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REMAKE Original Soundtrack

-- MAIN APPLICATION
addappid(3365650)
-- Game: addappid(3365650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365651, 1, "6ae2f0df4ac4f2599d26e91be198cd60486c19d92fa1549e79d83ee96e41156c")
