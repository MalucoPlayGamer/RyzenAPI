-- Lua provided by RyzenAPI
-- Game: Shoot. Push. Repeat.

-- MAIN APPLICATION
addappid(1328810)
-- Game: addappid(1328810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328811, 1, "c4696f90b84a502b8ceb5913d59435f272c23e5da6851d0ccd1a6117330f9b05")
