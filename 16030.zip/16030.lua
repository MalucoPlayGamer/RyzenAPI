-- Lua provided by SkyAPI 
-- Game: AppID 16030
addappid(16030)
addappid(16031, 1, "368c461c0439cf81ee6680cc2e6c70cdd6e2c7a93dc078d66c2356eb0bdc5f65")
