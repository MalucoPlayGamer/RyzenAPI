-- Lua provided by RyzenAPI
-- Game: Deconstruction Simulator Demo

-- MAIN APPLICATION
addappid(2765650)
-- Game: addappid(2765650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765651, 1, "ec6b2b94f45928dc4c8a74a9407b346c3b15f7751adaed7fc55066d9b5953a43")
