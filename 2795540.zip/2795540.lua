-- Lua provided by RyzenAPI
-- Game: The Midnight Walkers

-- MAIN APPLICATION
addappid(2795540)
addappid(4013880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795541, 1, "42c809bf5298def7768b06e6813406be21a70a2969ef2aa100a3fb8b20b2ef39")
