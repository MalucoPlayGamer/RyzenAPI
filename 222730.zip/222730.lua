-- Lua provided by RyzenAPI
-- Game: Reus

-- MAIN APPLICATION
addappid(222730)
addappid(228983)
addappid(228985)
addappid(228986)
addappid(229002)
addappid(229012)

-- MAIN APP DEPOTS / PACKAGES
addappid(222731, 1, "9de0116de41593a84ebc02989bf597683118fa7ddee9fd951062fc4e9cf84afd")
addappid(222732, 1, "65afb8a655cf94625a501cc3378735422280fd475ef07ef04b4db07975199923")
addappid(222733, 1, "e5cee269761508ad6b749495fd11d0fd272bb82710954aa2d74542a0186fa700")
