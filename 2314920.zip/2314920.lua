-- Lua provided by RyzenAPI 
-- Game: Pixel Piracy - Shrimp Legacy
addappid(2314920)
addappid(2314921, 1, "42a13548ef940e7e46d4c1136c71184d6f0c62e4d0697b72bdfbdd42fe38bbd8")
