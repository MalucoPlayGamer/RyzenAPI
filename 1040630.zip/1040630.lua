-- Lua provided by RyzenAPI
-- Game: Alchemy Story

-- MAIN APPLICATION
addappid(1040630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040631, 1, "c1bf0590dc2b69a7612d745385934d309c0c73e76585834c2caa0cc5227c9d64")

