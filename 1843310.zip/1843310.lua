-- Lua provided by RyzenAPI
-- Game: Funko Fusion

-- MAIN APPLICATION
addappid(1843310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843311, 1, "b727ec45805174cdf8fc7ec522fec599a44a5131fe329f2aa39437d7013ec4bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3037350)
addappid(3037360)
addappid(3112580)
addappid(3112590)
addappid(3112600)
addappid(3112750)
addappid(3158300)
addappid(3158320)
addappid(3158330)
addappid(3158340)
addappid(3158360)
addappid(3172000)
addappid(3268050)
addappid(3268060)
addappid(3268090)
addappid(3268110)
addappid(3268220)
addappid(3268230)
addappid(3268240)
addappid(3307520)
addappid(3307530)
addappid(3307540)
addappid(3350580)
addappid(3361290)
addappid(3361300)
addappid(3462740)
addappid(3462750)
addappid(3462760)
addappid(3551550)
addappid(3780200)
addappid(3780210)
addappid(3829370)
addappid(3942910)
addappid(3957700)
addappid(4022990)
addappid(4023000)
addappid(4023010)
addappid(4023020)
