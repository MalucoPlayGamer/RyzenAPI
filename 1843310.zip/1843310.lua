-- Lua provided by RyzenAPI
-- Game: addappid(1843310)

-- MAIN APPLICATION
addappid(1843310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843311, 1, "b727ec45805174cdf8fc7ec522fec599a44a5131fe329f2aa39437d7013ec4bb")
