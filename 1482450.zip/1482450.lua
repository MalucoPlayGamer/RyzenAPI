-- Lua provided by RyzenAPI
-- Game: Rosy Manga

-- MAIN APPLICATION
addappid(1482450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482451, 1, "6138a5bc6c48567a7c97e44df401a2f758c4f78797469ae785a3808c8cd8efcd")

