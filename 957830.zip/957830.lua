-- Lua provided by RyzenAPI
-- Game: Crystal Maidens

-- MAIN APPLICATION
addappid(957830)
-- Game: addappid(957830)

-- MAIN APP DEPOTS / PACKAGES
addappid(957831, 1, "dd862a36af71ce0d52f786a1aa758cba4c15258c1eff3cbfa19d3695b0afbfa1")
