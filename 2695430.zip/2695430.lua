-- Lua provided by RyzenAPI
-- Game: A.I.L.A

-- MAIN APPLICATION
addappid(2695430)
addappid(4261890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2695431, 1, "059aa71cb66544e31c563e0bcc18b9bab023a8fa58ce942eeb07ce7f3f170eed")

