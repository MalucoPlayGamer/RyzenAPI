-- Lua provided by RyzenAPI
-- Game: 2695430

-- MAIN APPLICATION
addappid(2695430)
-- Game: addappid(2695430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695431, 1, "059aa71cb66544e31c563e0bcc18b9bab023a8fa58ce942eeb07ce7f3f170eed")
