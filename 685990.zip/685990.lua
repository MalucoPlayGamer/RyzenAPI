-- Lua provided by RyzenAPI
-- Game: AppID 685990

-- MAIN APPLICATION
addappid(685990)

-- MAIN APP DEPOTS / PACKAGES
addappid(685991, 1, "10d036bb7f21eb68d8d5b0cf18bda99f6e92488a39013afd5abe2cc7875e0880")
