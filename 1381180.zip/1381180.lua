-- Lua provided by RyzenAPI 
-- Game: THE IMPOSSIBLE SOUNDTRACK (+Patch autograph)
addappid(1381180)
addappid(1381181, 1, "541428aa6eedc62652d35081f0ff0d1e3a825920e97d20348556829011eb41e6")
addappid(1381182, 1, "1ce9382db1dd560d0f7aeaf388b4dc22eed0b024228d6a57c2e6959200535b7f")
