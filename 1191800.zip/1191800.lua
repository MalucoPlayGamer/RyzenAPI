-- Lua provided by RyzenAPI
-- Game: City Block Builder

-- MAIN APPLICATION
addappid(1191800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191801, 1, "c99bd5683fae018d96bd15c2680f60e4cd83c740360cb7d9cfea16394f2573b2")

