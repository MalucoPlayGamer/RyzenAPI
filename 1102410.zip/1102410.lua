-- Lua provided by RyzenAPI
-- Game: AppID 1102410

-- MAIN APPLICATION
addappid(1102410)
addappid(1125080)
addappid(1235860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102411, 1, "f6f61a8258a9e33924ed8335b2dcbc86a9720f66811b261cdda55ce851b84a9a")
addappid(1102440, 0, "da96a52a3e8ccc4ee0a1f8941a8b2f64b67b062095bcc4031d74036b625cb1aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
