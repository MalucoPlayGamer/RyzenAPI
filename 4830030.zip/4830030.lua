-- Lua provided by RyzenAPI
-- Game: Unknown Zone

-- MAIN APPLICATION
addappid(4830030) -- Unknown Zone

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4830031, 1, "8bc60fb98a8a8385419cbfebd7230f3248a74deb2ed611e13bb360eb92309faa") -- Depot 4830031

