-- 4830030's Lua and Manifest Created by Hubcap Manifest
-- Unknown Zone
-- Created: August 14, 2026 at 05:59:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4830030) -- Unknown Zone
-- MAIN APP DEPOTS
addappid(4830031, 1, "8bc60fb98a8a8385419cbfebd7230f3248a74deb2ed611e13bb360eb92309faa") -- Depot 4830031
setManifestid(4830031, "2079810436377578212", 1324406590)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)