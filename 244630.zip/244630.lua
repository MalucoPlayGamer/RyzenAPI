-- Lua provided by RyzenAPI
-- Game: 244630

-- MAIN APPLICATION
addappid(244630)
-- Game: addappid(244630)

-- MAIN APP DEPOTS / PACKAGES
addappid(244631, 1, "8924e31fe0f5474eb7a590450a38f5b8ff78b3a60bd13dbc62a9dc579af1cbfc")
