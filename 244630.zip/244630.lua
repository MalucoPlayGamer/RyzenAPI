-- Lua provided by RyzenAPI
-- Game: NEOTOKYO

-- MAIN APPLICATION
addappid(244630)

-- MAIN APP DEPOTS / PACKAGES
addappid(244631, 1, "8924e31fe0f5474eb7a590450a38f5b8ff78b3a60bd13dbc62a9dc579af1cbfc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
