-- Lua provided by RyzenAPI
-- Game: Hidden Expedition Titanic

-- MAIN APPLICATION
addappid(50940)

-- MAIN APP DEPOTS / PACKAGES
addappid(50941, 1, "4b34dd210ca9df4bfff09d5b02d25fb0086a45fcf7cb3fac8f916c98f57d7b0b")

