-- Lua provided by SkyAPI 
-- Game: AppID 2937990
addappid(2937990)
addappid(2937991, 1, "89b94bc7d155a7c67ee98241d35ad02195fff89a7ef3dd7435022ac1488e816d")
addappid(3128070, 0, "9e4add0ceed5437967ddc02b0b3196443c68e50a4d0412fb32d0c577e91ad60d")
