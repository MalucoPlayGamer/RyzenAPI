-- Lua provided by RyzenAPI
-- Game: Towns

-- MAIN APPLICATION
addappid(221020)
-- Game: addappid(221020)

-- MAIN APP DEPOTS / PACKAGES
addappid(221022,0,"3a61a17b9af11b4a54d5e0a1654f457079d081850d8469049b975e68dfadd489")
addappid(221023,0,"10ac9c84962457c25bd7b9d81f2a6fe700714ed1b947a94b1ea82d844dac6967")
addappid(221024,0,"3f234ffe5ae4075a8a18bee923668195ca5316d36b94a64febc009a58e42c1a2")
addappid(221026,0,"ce00bebd6fbb79d98102c33ecaba2bfafea6bf4c2c036f4d322d38bde237a375")
