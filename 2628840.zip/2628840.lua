-- Lua provided by RyzenAPI
-- Game: Heróis de Noname - Pacote de Apoio ao Desenvolvedor 1

-- MAIN APPLICATION
addappid(2628840)
-- Game: addappid(2628840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628840,0,"5ca01fff9474e9f0096ded1c1375f9de7da720703a9cf481cb75d62de814f319")
