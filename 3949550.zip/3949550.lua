-- Lua provided by RyzenAPI
-- Game: 1666: Amsterdam

-- MAIN APPLICATION
addappid(3949550) -- 1666: Amsterdam

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3949551, 1, "a9794caab18073a61249771706caec73a29da82b3442b92204d415b310ee9c5b") -- Depot 3949551

