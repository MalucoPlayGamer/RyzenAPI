-- Lua provided by RyzenAPI 
-- Game: Fast & Furious: Spy Racers Rise of SH1FT3R
addappid(1434320)
addappid(1434321, 1, "00cef26b26766b954e373e9f35abbc944d39f798594ccb3392f7a40e1c570987")
addappid(1825120)
