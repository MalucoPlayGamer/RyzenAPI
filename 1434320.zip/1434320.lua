-- Lua provided by RyzenAPI
-- Game: Fast & Furious: Spy Racers Rise of SH1FT3R

-- MAIN APPLICATION
addappid(1434320)
addappid(1825120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1434321, 1, "00cef26b26766b954e373e9f35abbc944d39f798594ccb3392f7a40e1c570987")

