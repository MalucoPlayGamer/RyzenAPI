-- Lua provided by RyzenAPI
-- Game: addappid(2522280)

-- MAIN APPLICATION
addappid(2522280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522281, 1, "f535b00f6f4b6cadad87d857f6e8e221057afaabaedd6b17cd777290ee44fecf")
