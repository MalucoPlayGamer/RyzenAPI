-- Lua provided by RyzenAPI
-- Game: The Third Age

-- MAIN APPLICATION
addappid(2511040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511041, 1, "7772be9c1728f212f85487c1566595ce2eef0b04319fe0cdae45865346a2022b")
