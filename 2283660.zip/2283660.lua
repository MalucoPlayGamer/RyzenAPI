-- Lua provided by RyzenAPI
-- Game: Time Hoppers: The Silk Road

-- MAIN APPLICATION
addappid(2283660)
-- Game: addappid(2283660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283661, 1, "654c1543e9534aef28c8598e7c748d5e1d579a73d5b1351f06ce7ca4975832b8")
