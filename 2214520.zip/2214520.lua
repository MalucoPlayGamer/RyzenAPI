-- Lua provided by RyzenAPI
-- Game: Game: AppID 2214520

-- MAIN APPLICATION
addappid(2214520)
-- Game: addappid(2214520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214521, 1, "842909d56f1d138f863a0851328d946b03a306e3d553a33eed6505b33a3d8ca4")
