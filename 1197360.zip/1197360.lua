-- Lua provided by RyzenAPI
-- Game: Santa Challenge

-- MAIN APPLICATION
addappid(1197360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197361, 1, "b46946599e1cf2ce3548e453b517af6c8bd4e3b4bd3d489e3d556eab5ad7f417")

