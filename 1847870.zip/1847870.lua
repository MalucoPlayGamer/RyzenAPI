-- Lua provided by RyzenAPI
-- Game: Alisha's Sexual Fear

-- MAIN APPLICATION
addappid(1847870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847871, 1, "eb31fbcadbf3614117587e48ecbb4934867164e752d0c240d66a6a5d0ce9dde8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
