-- Lua provided by RyzenAPI
-- Game: Alisha's Sexual Fear

-- MAIN APPLICATION
addappid(1847870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847871, 1, "eb31fbcadbf3614117587e48ecbb4934867164e752d0c240d66a6a5d0ce9dde8")
