-- Lua provided by RyzenAPI
-- Game: Easy Ball Game

-- MAIN APPLICATION
addappid(3151020)
-- Game: addappid(3151020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151021, 1, "d557891ebb35427b41efca3b1b4634a3a8e060bb67ea747884d2be91c3c2ef1a")
