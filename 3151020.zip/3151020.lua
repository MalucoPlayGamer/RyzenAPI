-- Lua provided by RyzenAPI
-- Game: Easy Ball Game

-- MAIN APPLICATION
addappid(3151020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151021, 1, "d557891ebb35427b41efca3b1b4634a3a8e060bb67ea747884d2be91c3c2ef1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
