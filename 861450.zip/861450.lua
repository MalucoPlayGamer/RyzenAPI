-- Lua provided by RyzenAPI
-- Game: Color Cingdom

-- MAIN APPLICATION
addappid(861450)

-- MAIN APP DEPOTS / PACKAGES
addappid(861451, 1, "bc9f067e76f16375add5a8697f419900b6b18e025f4524496bcc074fbf027d2a")

