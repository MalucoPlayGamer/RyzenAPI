-- Lua provided by RyzenAPI
-- Game: Game: Drawn®: The Painted Tower

-- MAIN APPLICATION
addappid(51060)
-- Game: addappid(51060)

-- MAIN APP DEPOTS / PACKAGES
addappid(51061, 1, "3fb51d9e44b440da21459540e75ebad60e630299e5be4b0b899b03b96c2d7cd0")
