-- Lua provided by RyzenAPI
-- Game: Game: AppID 820610

-- MAIN APPLICATION
addappid(820610)
-- Game: addappid(820610)

-- MAIN APP DEPOTS / PACKAGES
addappid(820611, 1, "80ff45eeeb4ad0ad882e59950dd4c351bd8303c390f6ceb085a05764818b79c0")
