-- Lua provided by RyzenAPI
-- Game: Sunset Speedway

-- MAIN APPLICATION
addappid(3680540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680541, 1, "de89b9e9e3552222170c64d93b10a7f8e89d7d9fd19d081c52a83c527a88d8c6")
