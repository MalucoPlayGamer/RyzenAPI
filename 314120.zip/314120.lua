-- Lua provided by RyzenAPI 
-- Game: AppID 314120
addappid(314120)
addappid(314121, 1, "edf92288579c7707e8a945d5aed4b2f82e099757584a5a5c62e35a699ffa5aa7")
