-- Lua provided by RyzenAPI
-- Game: Game: AppID 314120

-- MAIN APPLICATION
addappid(314120)
-- Game: addappid(314120)

-- MAIN APP DEPOTS / PACKAGES
addappid(314121, 1, "edf92288579c7707e8a945d5aed4b2f82e099757584a5a5c62e35a699ffa5aa7")
