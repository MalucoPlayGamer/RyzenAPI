-- Lua provided by RyzenAPI
-- Game: Game: Toy Fight

-- MAIN APPLICATION
addappid(3432130)
-- Game: addappid(3432130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432131, 1, "8fa22b0e670dd67048139f3e59c9632d6206674a4c660d05c661e7d9276b3847")
