-- Lua provided by RyzenAPI 
-- Game: AppID 628340
addappid(628340)
addappid(628341, 1, "312068788f18c8119babbc1d366d0b74bbeb53ec74c2ed92fc56b16cd006133e")
