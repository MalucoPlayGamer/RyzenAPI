-- Lua provided by RyzenAPI
-- Game: 1 vs 1 : Global Operations

-- MAIN APPLICATION
addappid(628340)

-- MAIN APP DEPOTS / PACKAGES
addappid(628341, 1, "312068788f18c8119babbc1d366d0b74bbeb53ec74c2ed92fc56b16cd006133e")