-- Lua provided by RyzenAPI
-- Game: addappid(729240)

-- MAIN APPLICATION
addappid(729240)
addappid(729241)

-- MAIN APP DEPOTS / PACKAGES
addappid(729240,0,"b70b69d7c9a8d7619c7d3f45ad6c606b18a156e9f651e4abc6b5779bb4978944")
