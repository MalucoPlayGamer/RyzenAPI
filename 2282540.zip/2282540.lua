-- Lua provided by RyzenAPI
-- Game: Scary Turnaround

-- MAIN APPLICATION
addappid(2282540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282541, 1, "a4d32d91dffeab17837e81b02d324dca330f97d2d8eb65a45641a049b06f7d27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
