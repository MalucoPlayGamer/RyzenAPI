-- Lua provided by RyzenAPI
-- Game: Game: Scary Turnaround

-- MAIN APPLICATION
addappid(2282540)
-- Game: addappid(2282540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282541, 1, "a4d32d91dffeab17837e81b02d324dca330f97d2d8eb65a45641a049b06f7d27")
