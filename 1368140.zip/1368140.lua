-- 1368140's Lua and Manifest Created by Hubcap Manifest
-- Corsair Cove
-- Created: July 31, 2026 at 12:33:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1368140) -- Corsair Cove
-- MAIN APP DEPOTS
addappid(1368141, 1, "622125856d179fd026496cefcabadac4e6a40520051ae9ed5cb210a6f05d364d") -- Depot 1368141
setManifestid(1368141, "2761654638117383029", 29580311738)
addappid(1368142, 1, "6a84f1a9c026c5fd7bbdf63013d95d0ec71fd06876a0703d56a4e2b55a98e587") -- Depot 1368142
setManifestid(1368142, "4050571179734322575", 0)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)