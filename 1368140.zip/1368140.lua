-- Lua provided by RyzenAPI
-- Game: Corsair Cove

-- MAIN APPLICATION
addappid(1368140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(1368141, 1, "622125856d179fd026496cefcabadac4e6a40520051ae9ed5cb210a6f05d364d")
addappid(1368142, 1, "6a84f1a9c026c5fd7bbdf63013d95d0ec71fd06876a0703d56a4e2b55a98e587")

