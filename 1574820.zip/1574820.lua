-- Lua provided by RyzenAPI
-- Game: Game: Until Then

-- MAIN APPLICATION
addappid(1574820)
addappid(3902750)
-- Game: addappid(1574820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574821, 1, "a195ac176ad8fdc6cae6bceff829cc13231f258d8c2379b96016589c4843d290")
