-- Lua provided by RyzenAPI
-- Game: Until Then

-- MAIN APPLICATION
addappid(1574820)
addappid(3902750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574821, 1, "a195ac176ad8fdc6cae6bceff829cc13231f258d8c2379b96016589c4843d290")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
