-- Lua provided by RyzenAPI
-- Game: AppID 2497320

-- MAIN APPLICATION
addappid(2497320)
-- Game: addappid(2497320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497321, 1, "3fb1f389cf7f504387f98187d5743460f47710ffc287cbe82ce8cd7d6338c08a")
