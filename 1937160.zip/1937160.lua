-- Lua provided by RyzenAPI
-- Game: The Nightmare Catcher

-- MAIN APPLICATION
addappid(1937160)
-- Game: addappid(1937160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937161, 1, "39b0efeae423ae43e074830b993734dcbcd579574f404a53122cbfec9cbd0d07")
