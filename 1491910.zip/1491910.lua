-- Lua provided by RyzenAPI 
-- Game: Andromeda 2 Zombies
addappid(1491910)
addappid(1491911, 1, "12bd2ce5b379a3e5bdd5a961c3d3e90e836f40a8139876fb840063dccaf122e3")
