-- Lua provided by RyzenAPI
-- Game: Andromeda 2 Zombies

-- MAIN APPLICATION
addappid(1491910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1491911, 1, "12bd2ce5b379a3e5bdd5a961c3d3e90e836f40a8139876fb840063dccaf122e3")

