-- Lua provided by RyzenAPI
-- Game: Game: AppID 257420

-- MAIN APPLICATION
addappid(257420)
addappid(1330600)
-- Game: addappid(257420)

-- MAIN APP DEPOTS / PACKAGES
addappid(257421, 1, "8096f8677bd37048df6dc882760cfe3acf7e8fd4bb525f250f604d2b93eac97f")
addappid(257426, 1, "4a353c662b034310254d9c7d00885e076d46c5990eb7d7f46e68197e50a9db1b")
addappid(257427, 1, "e50c354bca42cdade83dbb7b8857d9a0118284edbd368e34b7c4e98f5024e9a6")
addappid(1330602, 0, "6f8d624640e2eabb756241dc57f9ccd1a8d49d231ba6df818b6bec810b084e53")
