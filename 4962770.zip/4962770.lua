-- Lua provided by RyzenAPI
-- Game: Lobotomy

-- MAIN APPLICATION
addappid(4962770) -- Lobotomy

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4962771, 1, "9823d7216a0f8be7a3a47bd43857bcc64f91fa2df414a98f1d5874d20e18070c") -- Depot 4962771

