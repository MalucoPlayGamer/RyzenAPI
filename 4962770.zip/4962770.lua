-- 4962770's Lua and Manifest Created by Hubcap Manifest
-- Lobotomy
-- Created: August 11, 2026 at 23:25:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4962770) -- Lobotomy
-- MAIN APP DEPOTS
addappid(4962771, 1, "9823d7216a0f8be7a3a47bd43857bcc64f91fa2df414a98f1d5874d20e18070c") -- Depot 4962771
setManifestid(4962771, "559753738832193528", 6694032288)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)