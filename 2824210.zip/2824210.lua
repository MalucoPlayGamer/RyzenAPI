-- Lua provided by RyzenAPI
-- Game: The Cursed Legacy

-- MAIN APPLICATION
addappid(2824210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824211, 1, "afd7e7066230a0fd38041128a2c54179cf8a98081fa9ccb85922202f8a1b0d6f")

