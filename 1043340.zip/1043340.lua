-- Lua provided by RyzenAPI
-- Game: AppID 1043340

-- MAIN APPLICATION
addappid(1043340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043341, 1, "6cacd8ad6995eee791022c2c1cf956eeae2bae1cc693150d53dc016e346eeb08")

