-- Lua provided by RyzenAPI
-- Game: Lilly and Sasha: Guardian Angels

-- MAIN APPLICATION
addappid(383520)

-- MAIN APP DEPOTS / PACKAGES
addappid(383521, 1, "b340e4814214a3b2b5536b0206913f47f0c45795ff0468a4b1c529d0b6ab9706")
