-- Lua provided by RyzenAPI
-- Game: Scrap Garden

-- MAIN APPLICATION
addappid(465760)

-- MAIN APP DEPOTS / PACKAGES
addappid(465761, 1, "0cfaf139749f0d69df406ade472d553711859ec2479fe1609d198c729472a058")
addappid(465762, 1, "6ed7edc2b210ba38ad158391608520609dd46a0be01ef848e3d16a48b12c9b65")
addappid(465763, 1, "9135c0ec6403daf549e94f2638ca4c8b40e55afbd573e5a9450b0ed192084196")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
