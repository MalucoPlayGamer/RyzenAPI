-- 4513640's Lua and Manifest Created by Hubcap Manifest
-- YGGDRA: SURVIVOR
-- Created: August 02, 2026 at 04:15:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4513640) -- YGGDRA: SURVIVOR
-- MAIN APP DEPOTS
addappid(4513641, 1, "029aac847ab39d8e86434cac2d34c34a280280eb15ec4e0cb7fdb2143776e6a8") -- Depot 4513641
setManifestid(4513641, "9194705698708002761", 380426174)
-- DLCS WITH DEDICATED DEPOTS
-- YGGDRA SURVIVOR - Summer Character Pack (AppID: 4980990)
addappid(4980990)
addappid(4980990, 1, "b6a984f8e1e297f93d0a1c9bcb0c7e21b242394c9b4891cf030aecb9259679bb") -- YGGDRA SURVIVOR - Summer Character Pack - Depot 4980990
setManifestid(4980990, "2533896854413411366", 6401540)