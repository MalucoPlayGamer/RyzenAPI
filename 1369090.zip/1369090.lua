-- Lua provided by RyzenAPI
-- Game: Chibi Wars Kinetic Novel

-- MAIN APPLICATION
addappid(1369090)
-- Game: addappid(1369090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369091, 1, "bcdbbb4f5e53b492dd3d6a9364e2cec1595330a630f466d56d3b9324abf2e997")
