-- Lua provided by RyzenAPI
-- Game: Mage's Initiation: Reign of the Elements

-- MAIN APPLICATION
addappid(270610)

-- MAIN APP DEPOTS / PACKAGES
addappid(270611, 1, "87809d05fe9260472f3d6d17e6add72ce8c8f0ee768e0be650239454550b5391")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
