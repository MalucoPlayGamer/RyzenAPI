-- Lua provided by RyzenAPI
-- Game: Squares

-- MAIN APPLICATION
addappid(786750)

-- MAIN APP DEPOTS / PACKAGES
addappid(786751, 1, "85192ffc089326c1c52f8ab354eb884626e9d55c4f1f99eda6255102df7af383")
