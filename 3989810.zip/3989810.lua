-- Generated with Luie @ https://lua.tools/
-- 3989810 - FUTA FUCKS FEMBOYS
-- Generated 2026-08-13 22:44:07 UTC
-- # Depots (Total/DLC/Shared): 6/4/0

-- Main AppID
addappid(3989810, 1, "846496d313800d76ae5e8243a59f69791190096542412a76d07a5fee364c0ec7")

-- Main Depots
addappid(3989811, 1, "f6e8f5535ace4378147ca42a0a7522dda75edff837b68f3dc656f4c95fcebb99") -- (windows)
setManifestid(3989811, "7590013942416503790", 2895220105)
addappid(3989812, 1, "3a4a91f1962fb8c5a4262927397f35c5a953e4720071ca8cae01bf2b215abf9b") -- (macos)
setManifestid(3989812, "1250865238647617512", 2914652318)

-- DLC's (no depot keys required)
addappid(4468090) -- FUTA FUCKS FEMBOYS - XXXL Skins Pack

-- DLC's (with depot keys)
-- FUTA FUCKS FEMBOYS - Animations Pack (AppID: 4395420)
addappid(4395420)
addappid(4395420, 1, "3b1bcd39ead4d3af921a5476214c3d65a8becd99b90500468eaa6ce5ec4f6ac2")
setManifestid(4395420, "1944639781078596343", 5012321191)
-- FUTA FUCKS FEMBOYS - Digital Artbook (AppID: 4395430)
addappid(4395430)
addappid(4395430, 1, "ab9ebc2c100bed0a80c02e3086345d23ad0b9a8f394fefe6b8dea0934746a6a8")
setManifestid(4395430, "589027307449213919", 696141739)
-- FUTA FUCKS FEMBOYS - Wallpapers Pack (AppID: 4395440)
addappid(4395440)
addappid(4395440, 1, "3b1aff0141c2611775dac4ab574539c090ce0c0f98c464d6cac5026636882192")
setManifestid(4395440, "2789526287206530868", 722066009)

-- Missing Depots (We don't have the keys yet lol): 4395451

-- Token-locked DLCs (couldn't read depots): 4629990, 4925520
