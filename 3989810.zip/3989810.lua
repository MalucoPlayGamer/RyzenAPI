-- Lua provided by RyzenAPI
-- Game: FUTA FUCKS FEMBOYS

-- MAIN APPLICATION
addappid(4395420)
addappid(4395430)
addappid(4395440)
addappid(4468090) -- FUTA FUCKS FEMBOYS - XXXL Skins Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3989810, 1, "846496d313800d76ae5e8243a59f69791190096542412a76d07a5fee364c0ec7")
addappid(3989811, 1, "f6e8f5535ace4378147ca42a0a7522dda75edff837b68f3dc656f4c95fcebb99") -- (windows)
addappid(3989812, 1, "3a4a91f1962fb8c5a4262927397f35c5a953e4720071ca8cae01bf2b215abf9b") -- (macos)
addappid(4395420, 1, "3b1bcd39ead4d3af921a5476214c3d65a8becd99b90500468eaa6ce5ec4f6ac2")
addappid(4395430, 1, "ab9ebc2c100bed0a80c02e3086345d23ad0b9a8f394fefe6b8dea0934746a6a8")
addappid(4395440, 1, "3b1aff0141c2611775dac4ab574539c090ce0c0f98c464d6cac5026636882192")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4629990)
addappid(4925520)
