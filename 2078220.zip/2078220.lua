-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2078220)
-- Game: addappid(2078220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078220,0,"cbb7598f322d696fa324af6603d9d18269923b303ac49bdfd27b75c6b5e97f1e")
