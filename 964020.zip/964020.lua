-- Lua provided by RyzenAPI
-- Game: addappid(964020)

-- MAIN APPLICATION
addappid(964020)

-- MAIN APP DEPOTS / PACKAGES
addappid(964021, 1, "0b19ae804e9013e7365afda4b0699e9d100a2b05dd86142af4d54396db9c7681")
