-- Lua provided by SkyAPI 
-- Game: Make Your Kingdom
addappid(964020)
addappid(964021, 1, "0b19ae804e9013e7365afda4b0699e9d100a2b05dd86142af4d54396db9c7681")
