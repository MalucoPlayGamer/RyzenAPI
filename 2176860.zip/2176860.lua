-- Lua provided by SkyAPI 
-- Game: Suffer The Night Demo
addappid(2176860)
addappid(2176861, 1, "abba3e7d1c4a7837c228f033beba1d5a783672aa4e7685a2d32853d36782a4fb")
