-- Lua provided by RyzenAPI
-- Game: Suffer The Night Demo

-- MAIN APPLICATION
addappid(2176860)
-- Game: addappid(2176860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176861, 1, "abba3e7d1c4a7837c228f033beba1d5a783672aa4e7685a2d32853d36782a4fb")
