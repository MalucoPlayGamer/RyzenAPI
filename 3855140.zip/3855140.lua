-- Lua provided by RyzenAPI
-- Game: Moonlit Lanterns

-- MAIN APPLICATION
addappid(3855140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3855142,0,"2d510b04a5d04a57889905821d8143119cdce840074d5eb23e6371a986ae87bf")

