-- Lua provided by RyzenAPI
-- Game: Hentai Shiri

-- MAIN APPLICATION
addappid(1166320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166321, 1, "393fb01407e9e22beea13d2d6db5b0ca52269e05e4c2407b1e81dc46e7e98238")

