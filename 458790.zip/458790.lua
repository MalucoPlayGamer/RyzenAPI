-- Lua provided by RyzenAPI
-- Game: The House in Fata Morgana Original Soundtrack

-- MAIN APPLICATION
addappid(458790)

-- MAIN APP DEPOTS / PACKAGES
addappid(458790,0,"c274856c027b0cc8ef32e4a753076cde89507122a74fff3b12e5412ffa8af929")

