-- Lua provided by RyzenAPI 
-- Game: Lawnmower Game: Survival
addappid(3522650)
addappid(3522651, 1, "bf7f8f7ce8272be93436ff9573f0d2b872c53c8be6b1e09dfab438ab0828b113")
