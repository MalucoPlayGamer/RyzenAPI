-- Lua provided by RyzenAPI
-- Game: Criminal Girls: Invite Only - Digital Soundtrack

-- MAIN APPLICATION
addappid(516331)

-- MAIN APP DEPOTS / PACKAGES
addappid(516331,0,"85835ccf4ffe5b8f2cc55bf42c560fd12a5aba4bde2a5ff8546c77c04ff5e431")

