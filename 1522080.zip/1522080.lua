-- Lua provided by RyzenAPI 
-- Game: Jitsu Squad
addappid(1522080)
addappid(1522081, 1, "81a741e78e1a125f41d7a850b3f71bc2a5161ee358ca5910cef69e6082516aa7")
