-- Lua provided by RyzenAPI
-- Game: addappid(2294070)

-- MAIN APPLICATION
addappid(2294070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294071, 1, "15173e1d061fc04c389e8ad6d0d31f01bb00f5a0ffc856294a61276d55a1a7d7")
