-- Lua provided by RyzenAPI
-- Game: 864430

-- MAIN APPLICATION
addappid(864430)
-- Game: addappid(864430)

-- MAIN APP DEPOTS / PACKAGES
addappid(864431, 1, "a21987412134cfd37921a428cafba6ba3e2283857a658da3429f53c5b78bd80e")
