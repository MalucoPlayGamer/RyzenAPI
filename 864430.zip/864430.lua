-- Lua provided by RyzenAPI
-- Game: SilverFrame(纯白星原)

-- MAIN APPLICATION
addappid(864430)

-- MAIN APP DEPOTS / PACKAGES
addappid(864431, 1, "a21987412134cfd37921a428cafba6ba3e2283857a658da3429f53c5b78bd80e")
