-- Lua provided by RyzenAPI 
-- Game: NINJA GAIDEN Σ2 [NINJA GAIDEN: Master Collection]
addappid(1580790)
addappid(1580791, 1, "5fe25654f65219c67b3ac5ad1c2d068646dc00f4437064041f723cc5d893120e")
addappid(1580792, 1, "93d9d00a7d2a40b06bc2e177c504bf3005300de9431dffe80b7572e231639a1c")
