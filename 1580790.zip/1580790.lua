-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN Σ2 [NINJA GAIDEN: Master Collection]

-- MAIN APPLICATION
addappid(1580790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580791, 1, "5fe25654f65219c67b3ac5ad1c2d068646dc00f4437064041f723cc5d893120e")
addappid(1580792, 1, "93d9d00a7d2a40b06bc2e177c504bf3005300de9431dffe80b7572e231639a1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
