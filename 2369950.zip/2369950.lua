-- Lua provided by RyzenAPI
-- Game: Game: Blade of the Netherworld

-- MAIN APPLICATION
addappid(2369950)
-- Game: addappid(2369950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369951, 1, "8ce534b8f17d672f921ea8640ed93f113ed312927b39e928ad5161de9aefd10c")
