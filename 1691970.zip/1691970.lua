-- Lua provided by RyzenAPI
-- Game: Danganronpa S: Ultimate Summer Camp

-- MAIN APPLICATION
addappid(1691970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691971, 1, "ef865324c35579e6b37b60fded989943e391b4e2cc69b4ca1de12bdd1bd759b5")
