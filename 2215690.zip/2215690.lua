-- Lua provided by RyzenAPI
-- Game: 2215690

-- MAIN APPLICATION
addappid(2215690)
addappid(2256870)
addappid(2805470)
addappid(3242480)
-- Game: addappid(2215690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215691, 1, "0488679a925d28c4d5c827ffc8eef9818959fb1524273d69614dcdf80ab8accf")
addappid(2251690, 0, "91aa4303a9b756b9798430e047373a6fa1dbe2f390dad3414c6d37fe52978c1e")
