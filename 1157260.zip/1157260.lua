-- Lua provided by SkyAPI 
-- Game: AppID 1157260
addappid(1157260)
addappid(1157261, 1, "1d6db7c94555204e1946def20a582d269b95746d8a85da363c01570188816ae5")
