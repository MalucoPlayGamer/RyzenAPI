-- Lua provided by RyzenAPI
-- Game: 策马守天关

-- MAIN APPLICATION
addappid(3984570)

