-- Lua provided by RyzenAPI 
-- Game: AppID 1853600
addappid(1853600)
addappid(1853601, 1, "f3b41708446267662d9eba57d82ba78155c616232494dd210dddb0abe35bf7d9")
