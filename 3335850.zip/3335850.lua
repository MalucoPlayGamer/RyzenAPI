-- Lua provided by RyzenAPI
-- Game: addappid(3335850)

-- MAIN APPLICATION
addappid(3335850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335851, 1, "930e63993da4079a344d68af7b9ed9d6fbcb3df2336c847bffe811f0d60687c9")
