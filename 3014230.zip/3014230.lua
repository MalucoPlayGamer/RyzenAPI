-- Lua provided by RyzenAPI
-- Game: addappid(3014230)

-- MAIN APPLICATION
addappid(3014230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014231, 1, "ed446a3881a62cd58d6f4cacb1fb933d572cb5299eb6d4d075c0e96cbe48146d")
