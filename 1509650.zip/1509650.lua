-- Lua provided by RyzenAPI
-- Game: I Am Jesus Christ: Prologue

-- MAIN APPLICATION
addappid(1509650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509651, 1, "c1a833d073dc694ee38cc6b48df70225dc827ef07eadc3ac3a96b72d6d542d06")

