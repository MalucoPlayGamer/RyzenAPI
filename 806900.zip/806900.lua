-- Lua provided by RyzenAPI
-- Game: AppID 806900

-- MAIN APPLICATION
addappid(806900)

-- MAIN APP DEPOTS / PACKAGES
addappid(806901, 1, "b949671dd310a36b281b427efa6edceb9501a199eb651b5e87a7efbb7b2c7c82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
