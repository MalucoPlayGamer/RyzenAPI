-- Lua provided by RyzenAPI
-- Game: addappid(2932960)

-- MAIN APPLICATION
addappid(2932960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932961, 1, "968615d7322f18dda5a36a70f8da86d8fbf504465b02572a7386febe2fc7ba8b")
