-- Lua provided by RyzenAPI
-- Game: Ghost Exile

-- MAIN APPLICATION
addappid(1807080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807081, 1, "589b37c3941d4cbe363fbca9c77b3119c8c942dfb056f92e7cea0f42f30382fd")
