-- Lua provided by RyzenAPI
-- Game: Ghost Exile

-- MAIN APPLICATION
addappid(1807080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807081, 1, "589b37c3941d4cbe363fbca9c77b3119c8c942dfb056f92e7cea0f42f30382fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
