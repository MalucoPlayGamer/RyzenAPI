-- Lua provided by RyzenAPI
-- Game: Witching Hour Demo

-- MAIN APPLICATION
addappid(1871070)
-- Game: addappid(1871070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871071, 1, "8898cd87774166d83fb561fe23378146358ba9473a53fc3206ed5914e2a62665")
