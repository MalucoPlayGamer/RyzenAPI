-- Lua provided by SkyAPI 
-- Game: Witching Hour Demo
addappid(1871070)
addappid(1871071, 1, "8898cd87774166d83fb561fe23378146358ba9473a53fc3206ed5914e2a62665")
