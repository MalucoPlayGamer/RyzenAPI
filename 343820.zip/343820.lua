-- Lua provided by RyzenAPI
-- Game: AppID 343820

-- MAIN APPLICATION
addappid(343820)
-- Game: addappid(343820)

-- MAIN APP DEPOTS / PACKAGES
addappid(343821, 1, "e6fd6ef7d291d8f115cece24926a5a5f671ad7634f9f41cab3cae2b64840d7f3")
