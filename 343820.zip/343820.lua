-- Lua provided by SkyAPI 
-- Game: AppID 343820
addappid(343820)
addappid(343821, 1, "e6fd6ef7d291d8f115cece24926a5a5f671ad7634f9f41cab3cae2b64840d7f3")
