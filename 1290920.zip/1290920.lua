-- Lua provided by RyzenAPI
-- Game: Roll Control

-- MAIN APPLICATION
addappid(1290920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290921, 1, "97d9b06a2001439faad0ca3aa78eb5ba6edd2756aed0e19c46e3720abe190d70")

