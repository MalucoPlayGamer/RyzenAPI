-- Lua provided by RyzenAPI
-- Game: Zombie Horde Dominator

-- MAIN APPLICATION
addappid(2545130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2545131, 1, "1f9336874468e6dae4f4ce87de43d16746c3527ffb9de95e87e62a4d1a977c8f")

