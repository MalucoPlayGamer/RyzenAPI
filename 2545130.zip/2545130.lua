-- Lua provided by RyzenAPI
-- Game: Zombie Horde Dominator

-- MAIN APPLICATION
addappid(2545130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545131, 1, "1f9336874468e6dae4f4ce87de43d16746c3527ffb9de95e87e62a4d1a977c8f")

