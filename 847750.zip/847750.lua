-- Lua provided by RyzenAPI 
-- Game: River City Ransom: Underground OST
addappid(847750)
addappid(847751, 1, "50c339e7b48ee326b38297fe8369d3a2f0e242bb4f184dfd936712919108b916")
addappid(847752, 1, "51996d0e8d67d28721bb5fde585746d034f3c02c7c5714a07bd4ec7ca447935f")
