-- Lua provided by RyzenAPI 
-- Game: Blood Orange: Definitive Edition
addappid(2655840)
addappid(2655841, 1, "8e4b3d315d123d25b3643c897bb8b366b78f7bb58989120d4c7d1d975104343c")
