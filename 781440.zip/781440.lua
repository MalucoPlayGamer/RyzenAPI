-- Lua provided by SkyAPI 
-- Game: AppID 781440
addappid(781440)
addappid(781441, 1, "03c4e9f73f60142e145de001ef791b8f805d9b730d72e2a94f97370bac9b746e")
