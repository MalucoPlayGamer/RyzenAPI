-- Lua provided by RyzenAPI
-- Game: AppID 781440

-- MAIN APPLICATION
addappid(781440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(781441, 1, "03c4e9f73f60142e145de001ef791b8f805d9b730d72e2a94f97370bac9b746e")

