-- Lua provided by RyzenAPI
-- Game: Machinika: Museum

-- MAIN APPLICATION
addappid(1507190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507191, 1, "de655c928602b89e0af3dd4aafdde11dcb7a829f10ba559b6a7d350ddf1442f1")
addappid(1507192, 1, "80cea4a63a887a7fb67f5764c8944e704a44fef00b6ec081625133f4ac049ee7")

