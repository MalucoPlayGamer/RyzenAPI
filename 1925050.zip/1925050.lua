-- Lua provided by RyzenAPI
-- Game: Sub for You

-- MAIN APPLICATION
addappid(1925050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925051, 1, "fbbf250a18281a9e3d4cbf9349773320e93e3568d9e07450755e2dca09c3cdb3")
