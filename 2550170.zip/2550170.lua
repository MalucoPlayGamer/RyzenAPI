-- Lua provided by RyzenAPI
-- Game: WILD SEX: WET GIRLS

-- MAIN APPLICATION
addappid(2550170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2550171, 1, "cc94013274e6a4a204910c012aca3be311cc936cbaaefd2af95e843df1eae769")

