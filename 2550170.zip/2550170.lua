-- Lua provided by RyzenAPI
-- Game: Game: AppID 2550170

-- MAIN APPLICATION
addappid(2550170)
-- Game: addappid(2550170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550171, 1, "cc94013274e6a4a204910c012aca3be311cc936cbaaefd2af95e843df1eae769")
