-- Lua provided by RyzenAPI
-- Game: Ship of Fools

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1286580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286583,0,"883b29255b4c97d3e7840bebc536032840afa67a523fe14b16462d25f394f3e9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2342680)
addappid(2512030)
addappid(3547520)
addappid(3547530)
