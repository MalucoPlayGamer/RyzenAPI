-- Lua provided by SkyAPI 
-- Game: Insane Decay of Mind: The Labyrinth
addappid(450060)
addappid(450061, 1, "db0bd65d7245bcc6d5c8a79783d0952935db7c3af743e8d8328307957684cdd4")
