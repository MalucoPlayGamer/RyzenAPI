-- Lua provided by RyzenAPI
-- Game: 450060

-- MAIN APPLICATION
addappid(450060)
-- Game: addappid(450060)

-- MAIN APP DEPOTS / PACKAGES
addappid(450061, 1, "db0bd65d7245bcc6d5c8a79783d0952935db7c3af743e8d8328307957684cdd4")
