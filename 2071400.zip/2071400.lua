-- Lua provided by RyzenAPI
-- Game: Bum Bum Monsterz

-- MAIN APPLICATION
addappid(2071400)
-- Game: addappid(2071400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071401, 1, "06e06fbb32e7308427c565ab56ee35edfc2eb16fef7c2bdb319ed55846d9afb3")
