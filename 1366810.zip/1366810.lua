-- Lua provided by RyzenAPI
-- Game: AccrO

-- MAIN APPLICATION
addappid(1366810)
-- Game: addappid(1366810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366811, 1, "a54064c2993d374fc10ad93e22b884b36f7842bcf1fbc6cae64b827e37978fcc")
