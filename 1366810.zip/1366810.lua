-- Lua provided by SkyAPI 
-- Game: AccrO
addappid(1366810)
addappid(1366811, 1, "a54064c2993d374fc10ad93e22b884b36f7842bcf1fbc6cae64b827e37978fcc")
