-- Lua provided by RyzenAPI
-- Game: 1569200

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1569200)
addappid(1569201)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569202,0,"58c2c5f40fce13f50d78659e5bbe35b1f7ca80ef6230140aea17a59e7eef8835")

