-- Lua provided by RyzenAPI
-- Game: Summer Clover

-- MAIN APPLICATION
addappid(2458860)
-- Game: addappid(2458860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458861, 1, "3e20430ed7318a56fac69f79ed704aa4e7c820ad27f78481e5b31fcd6bb4fd87")
addappid(3008220, 0, "edd0c6d426f35323011c803abd710e9946c91ef04f58aaa64cc6b6d55b39ddec")
