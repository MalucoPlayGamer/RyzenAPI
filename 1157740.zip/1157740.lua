-- Lua provided by RyzenAPI
-- Game: Iron Meat

-- MAIN APPLICATION
addappid(1157740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157741, 1, "9575b37dcacda67ed9e2966999b1258c3255c65e2404ac12219267257b7baf77")

