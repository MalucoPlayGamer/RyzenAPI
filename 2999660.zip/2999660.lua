-- Lua provided by RyzenAPI
-- Game: 2999660

-- MAIN APPLICATION
addappid(2999660)
-- Game: addappid(2999660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999660,0,"64e42d838da4dc83cc7878389b50de24d9aebe6102a7ed346f3d5f69b830d5b6")
