-- Lua provided by RyzenAPI
-- Game: Shadow Complex Remastered

-- MAIN APPLICATION
addappid(385560)
addappid(468600)

-- MAIN APP DEPOTS / PACKAGES
addappid(385561, 1, "f457beb7d35ff2cbfd7495ca64e9ef515e7686cd5c746425f45fc3353b82ea34")
addappid(385562, 1, "83e342feb8a9aaa81a19f6adc8b8ca44ae66834365c2b21a9206a023c96e253d")
addappid(385563, 1, "cc36ea2cf1947f51c35ae51f943d4f46acfc18688a035e8e398250129770b116")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
