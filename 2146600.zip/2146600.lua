-- Lua provided by RyzenAPI
-- Game: addappid(2146600)

-- MAIN APPLICATION
addappid(2146600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146601, 1, "4f806c0e873e238358dac8277f8ed07ff6b15dbef5161ffd3313397e5ddc6dbc")
