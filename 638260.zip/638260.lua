-- Lua provided by RyzenAPI
-- Game: Myths of the World: Stolen Spring Collector's Edition

-- MAIN APPLICATION
addappid(638260)
-- Game: addappid(638260)

-- MAIN APP DEPOTS / PACKAGES
addappid(638261, 1, "8e0eea2ac2636e015462dfe1a25ca777b831ad4056275ae9120975bd7e20580c")
