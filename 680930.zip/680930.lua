-- Lua provided by RyzenAPI
-- Game: Fairy Lands: Rinka and the Fairy Gems

-- MAIN APPLICATION
addappid(680930)

-- MAIN APP DEPOTS / PACKAGES
addappid(680931, 1, "27e7e82ff44d10587f86273013f95948760cf234d4302b3835da67999455b157")

