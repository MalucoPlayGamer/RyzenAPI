-- Lua provided by RyzenAPI
-- Game: Hell Wedding 夜嫁

-- MAIN APPLICATION
addappid(934580)
addappid(1073180)

-- MAIN APP DEPOTS / PACKAGES
addappid(934581, 1, "b08601d3dee6f34661b9d6dab17772492d5341d56f231244445afd19336f2feb")

