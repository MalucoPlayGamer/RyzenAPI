-- Lua provided by RyzenAPI 
-- Game: Hell Wedding 夜嫁
addappid(934580)
addappid(934581, 1, "b08601d3dee6f34661b9d6dab17772492d5341d56f231244445afd19336f2feb")
addappid(1073180)
