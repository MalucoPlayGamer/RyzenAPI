-- Lua provided by RyzenAPI
-- Game: AppID 1277920

-- MAIN APPLICATION
addappid(1277920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277921, 1, "790b6c474987a4fe21cf4cf59190895088e279bdddc16684754161de6570d029")
addappid(1277922, 1, "ed3758f9d6d3dabb6744f49e487ed73cb44ffe184940d5f2f81da92135671908")
addappid(1277923, 1, "358927525cdf508134741940919975d9747082ce0c8fab43ff65ff79cb7c4a36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
