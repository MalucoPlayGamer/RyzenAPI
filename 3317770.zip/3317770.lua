-- Lua provided by RyzenAPI
-- Game: addappid(3317770)

-- MAIN APPLICATION
addappid(3317770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317772,0,"bb06e848be971f83bacc47569a79fd304dac35fcb32b2f1ca81fb183469a887f")
