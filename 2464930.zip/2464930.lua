-- Lua provided by RyzenAPI
-- Game: addappid(2464930)

-- MAIN APPLICATION
addappid(2464930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464931, 1, "2e607efc9d612652ee5db344b2d031c3f9a14b80ae1f0ed296694514740eefe2")
