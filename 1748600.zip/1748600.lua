-- Lua provided by RyzenAPI
-- Game: Sainthood

-- MAIN APPLICATION
addappid(1748600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748601, 1, "3f34c836463feefd6e3f7821baea386679cd27cfc25ea5e6f3892b7c778639aa")

