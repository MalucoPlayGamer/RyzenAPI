-- Lua provided by RyzenAPI
-- Game: Supernatural Super Squad Fight!

-- MAIN APPLICATION
addappid(1019790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019791, 1, "411aa4918b0edb4d6914293691f11eac922d5ff36aed3d41ff2f172f13fd0137")
addappid(1019792, 1, "ccc4d6ee315ebd3f1dee6f000e69fb210ddd08078d7415125efa59b0a3570758")
addappid(1019793, 1, "1591b6e2225977c84d15a2c9581239c6c1de038c1e3d7482b019ec3e8457ad16")
addappid(1019795, 1, "eab8c3be7a3d5f611aebf8ad07644c571a2f0a959dd75854e327c132ccca7d42")

