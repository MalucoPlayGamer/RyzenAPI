-- Lua provided by RyzenAPI
-- Game: addappid(299240)

-- MAIN APPLICATION
addappid(299240)

-- MAIN APP DEPOTS / PACKAGES
addappid(299240,0,"e1f9e739d808ad1b1349357904d359ca6a895c36b0b54734d67a67285a2fafc1")
