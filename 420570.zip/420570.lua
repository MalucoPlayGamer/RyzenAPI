-- Lua provided by RyzenAPI
-- Game: Cubixx HD

-- MAIN APPLICATION
addappid(420570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(420571, 1, "02eede4519da770a8907f5d59864345dc12218de822803a1ae6f2c78205fdbaf")
