-- Lua provided by RyzenAPI
-- Game: addappid(420570)

-- MAIN APPLICATION
addappid(420570)

-- MAIN APP DEPOTS / PACKAGES
addappid(420571, 1, "02eede4519da770a8907f5d59864345dc12218de822803a1ae6f2c78205fdbaf")
