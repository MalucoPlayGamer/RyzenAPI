-- Lua provided by RyzenAPI
-- Game: Terror In The Atomic Desert

-- MAIN APPLICATION
addappid(955490)

-- MAIN APP DEPOTS / PACKAGES
addappid(955491, 1, "de137d812899f822ef29c5f738c9ea9bee346237bf19b5a10506d44f43d63974")
