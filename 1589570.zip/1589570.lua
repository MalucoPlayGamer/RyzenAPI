-- Lua provided by SkyAPI 
-- Game: Dunjungle
addappid(1589570)
addappid(1589571, 1, "b279480a59b8ae5c32073d58db964ea027458c94f59bcf7c7d72ed1b45b974eb")
addappid(1589572, 1, "9232ac1d3c2ec661d0ce7000269f63647ed2ffa401639e8745b29fb461ea0eb0")
