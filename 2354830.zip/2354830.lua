-- Lua provided by RyzenAPI
-- Game: Wise Garden

-- MAIN APPLICATION
addappid(2354830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354831, 1, "f77acfee217626248a8b8d66b7c6b33e1b0967d60aba602c443f6cf497f6e22c")
