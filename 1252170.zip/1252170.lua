-- Lua provided by RyzenAPI
-- Game: addappid(1252170)

-- MAIN APPLICATION
addappid(1252170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252171, 1, "f6fb382431971b0a11ca0d72e40e818a8a0fcdb0f4a111d7b0ba3435a3d5430e")
