-- Lua provided by RyzenAPI
-- Game: Discord Bot Maker

-- MAIN APPLICATION
addappid(682130)

-- MAIN APP DEPOTS / PACKAGES
addappid(682131,0,"3bd530a8ab432b421e8764e0bfd71830a8aaa0ed73383039d4d7aaa7a88bd6ac")

