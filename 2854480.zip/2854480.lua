-- Lua provided by RyzenAPI
-- Game: Blindfire

-- MAIN APPLICATION
addappid(2854480)
-- Game: addappid(2854480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854481, 1, "6efc7aeef56a46aff81839de0d97b24440f12301879c5dac7e4e400fb5def456")
