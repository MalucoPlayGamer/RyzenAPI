-- Lua provided by RyzenAPI
-- Game: Blindfire

-- MAIN APPLICATION
addappid(2854480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854481, 1, "6efc7aeef56a46aff81839de0d97b24440f12301879c5dac7e4e400fb5def456")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
