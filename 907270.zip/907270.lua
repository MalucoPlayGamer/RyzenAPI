-- Lua provided by SkyAPI 
-- Game: AppID 907270
addappid(907270)
addappid(907271, 1, "1e7ab575a558052570c4da445f81cae1810e4da2f477ba8707a23c7f4067dcfb")
addappid(907272, 1, "06e7c2ae597a592a7ba35dfbe6c55f146d9780b6764841deca4dc8a026114c66")
