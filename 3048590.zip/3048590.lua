-- Lua provided by RyzenAPI
-- Game: Game: AppID 3048590

-- MAIN APPLICATION
addappid(3048590)
-- Game: addappid(3048590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048591, 1, "75f36b71f7ebff857252f5e5f1f8f05a1db30fab60a544d892e21f95391716fb")
