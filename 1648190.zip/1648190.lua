-- Lua provided by SkyAPI 
-- Game: QANGA
addappid(1648190)
addappid(1648191, 1, "1677f7efc59df6ff08c335fc08fc015d725ede40b360c1c5770a122e5aafead4")
