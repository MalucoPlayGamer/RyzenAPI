-- Lua provided by RyzenAPI
-- Game: QANGA

-- MAIN APPLICATION
addappid(1648190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648191, 1, "1677f7efc59df6ff08c335fc08fc015d725ede40b360c1c5770a122e5aafead4")
