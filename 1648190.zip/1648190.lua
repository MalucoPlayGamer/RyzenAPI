-- Lua provided by RyzenAPI
-- Game: QANGA

-- MAIN APPLICATION
addappid(1648190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648191, 1, "1677f7efc59df6ff08c335fc08fc015d725ede40b360c1c5770a122e5aafead4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
