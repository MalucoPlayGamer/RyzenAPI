-- Lua provided by SkyAPI 
-- Game: Panzer Knights - Elefant & Maus
addappid(2054090)
addappid(2054091, 1, "78c06f4af815301efebd44d42e51e8d86152aa6e01bb21bcaf17617c61d32047")
