-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Tendou with Power Up Kit

-- MAIN APPLICATION
addappid(363110)

-- MAIN APP DEPOTS / PACKAGES
addappid(363111, 1, "2122679773ef7d6a80c4d52d65f1317a0f6767f69c1a13d81476e2ea6ad9289c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(381720)
addappid(381721)
