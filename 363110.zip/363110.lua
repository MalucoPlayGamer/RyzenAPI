-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Tendou with Power Up Kit

-- MAIN APPLICATION
addappid(363110)

-- MAIN APP DEPOTS / PACKAGES
addappid(363111, 1, "2122679773ef7d6a80c4d52d65f1317a0f6767f69c1a13d81476e2ea6ad9289c")

