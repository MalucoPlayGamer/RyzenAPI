-- Lua provided by RyzenAPI 
-- Game: SEX Cyber Lust VR
addappid(2347760)
addappid(2347761, 1, "c7409aa89fe5ebbf72f56b9aa7e5fef4e46dfd3df33b6533267ab861c11a3275")
