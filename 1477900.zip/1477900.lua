-- Lua provided by RyzenAPI
-- Game: AppID 1477900

-- MAIN APPLICATION
addappid(1477900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477901, 1, "cfe623835b1fbd7de89447eb85b347ef7b4b71823ab7a43c35ba54082ed4e131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
