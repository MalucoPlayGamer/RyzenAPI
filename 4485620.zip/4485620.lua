-- Lua provided by RyzenAPI
-- Game: Artesnaut

-- MAIN APPLICATION
addappid(4485620)

