-- Lua provided by RyzenAPI
-- Game: Ecto

-- MAIN APPLICATION
addappid(2256970)

