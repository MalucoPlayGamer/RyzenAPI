-- Lua provided by RyzenAPI
-- Game: Ecto

-- MAIN APPLICATION
addappid(2256970)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4462110)
