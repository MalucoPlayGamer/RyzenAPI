-- Lua provided by RyzenAPI
-- Game: Ecto

-- MAIN APPLICATION
addappid(2256970)
addappid(4462110)

