-- Lua provided by RyzenAPI
-- Game: Aphotic Descent

-- MAIN APPLICATION
addappid(2364090)
-- Game: addappid(2364090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364091, 1, "eaebe335045d58aeb182855e3ffd8e435397596c35638682cc93e0d5f8609429")
