-- Lua provided by RyzenAPI
-- Game: AppID 1169550

-- MAIN APPLICATION
addappid(1169550)
-- Game: addappid(1169550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169551, 1, "2ed59399b0dbd25423e19a42ca6adcf58cc84d45fb8c618cebfb1d82763853df")
