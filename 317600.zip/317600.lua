-- Lua provided by RyzenAPI
-- Game: AppID 317600

-- MAIN APPLICATION
addappid(317600)
-- Game: addappid(317600)

-- MAIN APP DEPOTS / PACKAGES
addappid(317601, 1, "ce4eb8bbe6b60b81ba5b18f7bcbada5dd6540ecffac455aa45a796db6fe0c424")
