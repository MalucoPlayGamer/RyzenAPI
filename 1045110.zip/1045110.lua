-- Lua provided by SkyAPI 
-- Game: Space Ops VR: Reloaded
addappid(1045110)
addappid(1045111, 1, "4c8609b761fcfcf98ea22c3676f7342de062319490aee74ab5e6462ec249f9a0")
