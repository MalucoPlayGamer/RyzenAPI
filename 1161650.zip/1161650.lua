-- Lua provided by RyzenAPI
-- Game: Game: AppID 1161650

-- MAIN APPLICATION
addappid(1161650)
-- Game: addappid(1161650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161651, 1, "f894a10e36631e1217ae798a98db022402d865410b657ed27ea07423a1cdd9cc")
