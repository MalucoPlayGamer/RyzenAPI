-- Lua provided by RyzenAPI
-- Game: 585950

-- MAIN APPLICATION
addappid(585950)
-- Game: addappid(585950)

-- MAIN APP DEPOTS / PACKAGES
addappid(585951, 1, "e8dd2583debe2e2669771e5865e9a8f67ac39fe63b0764df1ca5eb8db256d1ce")
addappid(585952, 1, "7a478e72c14dbdec0c83c25166891dee75567ffa2ede777cae375cafcc575805")
addappid(585953, 1, "6d76315dd67bb8a90c8f45b1278cd2e79d566052709ea6d98e7f0a3efc9af76a")
