-- Lua provided by RyzenAPI
-- Game: 965640

-- MAIN APPLICATION
addappid(965640)
-- Game: addappid(965640)

-- MAIN APP DEPOTS / PACKAGES
addappid(965641, 1, "4867521c694fb74ad502ead44435721160fbf73e2ebae8f8293277ce7c3dff09")
