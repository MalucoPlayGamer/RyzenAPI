-- Lua provided by RyzenAPI
-- Game: Abode

-- MAIN APPLICATION
addappid(548340)

-- MAIN APP DEPOTS / PACKAGES
addappid(548341, 1, "b3645aaf46bb1fb2c1bf0fa7de37568a06445b75c9cdee9daa7c7b7538a06c9a")

