-- Lua provided by RyzenAPI
-- Game: 1092730

-- MAIN APPLICATION
addappid(1092730)
-- Game: addappid(1092730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092731, 1, "212c79af37a0e4d2b8050d538cd0bea11513b30d71b99689228bfd1bd32b2885")
