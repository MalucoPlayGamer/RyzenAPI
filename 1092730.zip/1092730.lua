-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Alpha 3

-- MAIN APPLICATION
addappid(1092730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1092731, 1, "212c79af37a0e4d2b8050d538cd0bea11513b30d71b99689228bfd1bd32b2885")
