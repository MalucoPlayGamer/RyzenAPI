-- Lua provided by SkyAPI 
-- Game: Mazetools Soniface Lab Demo
addappid(2644900)
addappid(2644901, 1, "5d814c4cfb9705a846fb42af9ef3c1a17df1ff41648daeecb997dbcf4f8ca7d8")
