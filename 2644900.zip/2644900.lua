-- Lua provided by RyzenAPI
-- Game: Mazetools Soniface Lab Demo

-- MAIN APPLICATION
addappid(2644900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644901, 1, "5d814c4cfb9705a846fb42af9ef3c1a17df1ff41648daeecb997dbcf4f8ca7d8")
