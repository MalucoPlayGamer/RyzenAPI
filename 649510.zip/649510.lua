-- Lua provided by RyzenAPI
-- Game: AppID 649510

-- MAIN APPLICATION
addappid(649510)
-- Game: addappid(649510)

-- MAIN APP DEPOTS / PACKAGES
addappid(649511, 1, "3fc4c30a2f527213237bdbb4cdc82d41570cd7bcfe8878eb759c8270d6b1d880")
