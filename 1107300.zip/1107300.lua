-- Lua provided by RyzenAPI
-- Game: Down in Bermuda

-- MAIN APPLICATION
addappid(1107300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107301, 1, "b76b590b8653ebcbeaf55d4e0c06be35d93f2c25df5bd64656d5b553ca228c32")
addappid(1107302, 1, "e2127697fc389bd33f6f72441f22850a723a1167cec2ab75cb8d8ef5a7cbd6f1")
