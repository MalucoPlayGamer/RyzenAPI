-- Lua provided by SkyAPI 
-- Game: Slender: The Arrival
addappid(252330)
addappid(252331, 1, "e5560ed6dd390ae0d9f6871ca9c1876e16ad21133a7b86d6a7122b0fefa85ffd")
addappid(252333, 1, "72f4636af73f4fe564875b914f96d4e9901a8af683c3288c7499bbd7f9de61b6")
addappid(324720, 0, "68b676b8e2acb3037d54da8df98b19b42f1d199f7c4f77533b69685f2b194968")
