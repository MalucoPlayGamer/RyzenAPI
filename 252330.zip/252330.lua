-- Lua provided by RyzenAPI
-- Game: Slender: The Arrival

-- MAIN APPLICATION
addappid(252330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(252331, 1, "e5560ed6dd390ae0d9f6871ca9c1876e16ad21133a7b86d6a7122b0fefa85ffd")
addappid(252333, 1, "72f4636af73f4fe564875b914f96d4e9901a8af683c3288c7499bbd7f9de61b6")
addappid(324720, 0, "68b676b8e2acb3037d54da8df98b19b42f1d199f7c4f77533b69685f2b194968")

