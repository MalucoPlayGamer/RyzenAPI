-- Lua provided by RyzenAPI
-- Game: 1562420

-- MAIN APPLICATION
addappid(1562420)
-- Game: addappid(1562420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562421, 1, "c25810bf9718e5f1478a56120bc69663eeba36ee9972e8a4de4a1ff3ada546df")
