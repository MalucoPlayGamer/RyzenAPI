-- Lua provided by RyzenAPI
-- Game: Game: VITATIO 2

-- MAIN APPLICATION
addappid(586380)
-- Game: addappid(586380)

-- MAIN APP DEPOTS / PACKAGES
addappid(586381, 1, "dcab438549de1a494075c1f86fe03bf87e48c4c10bb892d233815b1535d07b66")
