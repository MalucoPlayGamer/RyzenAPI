-- Lua provided by RyzenAPI
-- Game: Divide By Sheep

-- MAIN APPLICATION
addappid(252130)

-- MAIN APP DEPOTS / PACKAGES
addappid(252131, 1, "fd32afafb7b6bbb9520e58ccd99492d48796bee984add334ff320bdbbe352bb3")
addappid(252132, 1, "00cff11a838a3ab4dc11d817022cd812a12c0af77f92cc54c0bba603ad261f95")
