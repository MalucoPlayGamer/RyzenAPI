-- Lua provided by SkyAPI 
-- Game: ChatWaifu
addappid(2331610)
addappid(2331611, 1, "248618b4fec29942f8d7fb8a2d9c5fef6dab4bdb463f6646d8f4fb8bf35f6098")
