-- Lua provided by RyzenAPI
-- Game: ChatWaifu

-- MAIN APPLICATION
addappid(2331610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331611, 1, "248618b4fec29942f8d7fb8a2d9c5fef6dab4bdb463f6646d8f4fb8bf35f6098")

