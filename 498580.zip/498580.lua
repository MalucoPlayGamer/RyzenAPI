-- Lua provided by RyzenAPI
-- Game: ASRECorp

-- MAIN APPLICATION
addappid(498580)

-- MAIN APP DEPOTS / PACKAGES
addappid(498581, 1, "7fccdbc3b4e57e664bf252e035f9c8556b2df6b4bc444e02a3f1de4558c4fb11")

