-- Lua provided by RyzenAPI
-- Game: AppID 472870

-- MAIN APPLICATION
addappid(472870)

-- MAIN APP DEPOTS / PACKAGES
addappid(472871, 1, "3840b67289bf6bf1ff4d211ce84dfdbb312f8cb2445e94d81db7ab6c841219d2")

