-- Lua provided by RyzenAPI
-- Game: Meet Cute: Delivery 🐾

-- MAIN APPLICATION
addappid(1897960)
addappid(1969800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897961, 1, "24ef4ada5b5b15d9174fb07fee8f80dd17e2fba9afdeb8dce0eab54ca690f876")
