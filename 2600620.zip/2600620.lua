-- Lua provided by RyzenAPI
-- Game: Lost Princess

-- MAIN APPLICATION
addappid(2600620)
-- Game: addappid(2600620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600621, 1, "620a38ef7f0ad5eb51d8ef316873313da483302012f6bd0c8d3d41ac96e3afc7")
