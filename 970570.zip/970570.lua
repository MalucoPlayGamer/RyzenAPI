-- Lua provided by RyzenAPI
-- Game: AppID 970570

-- MAIN APPLICATION
addappid(970570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(970571, 1, "df13289a2685be6337cea2864ba8d7678623c84a0570b3a07b18df6000abb0b3")
addappid(970572, 1, "83a3cd0a4cf929943cbc8bd90342ce77c27aeaa51618ae24e1f789ce305ac239")
addappid(970573, 1, "5ad6ce664dac8fbe885d14b0a3728b6cc37f3a3411854e3df91528dbe2ef8612")
addappid(1011950, 0, "dc0ff7ec57afae0402bf956e215353a9c65e60c296f11c41be3bc9edb22f40f7")

