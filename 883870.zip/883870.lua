-- Lua provided by RyzenAPI
-- Game: AppID 883870

-- MAIN APPLICATION
addappid(883870)
-- Game: addappid(883870)

-- MAIN APP DEPOTS / PACKAGES
addappid(883871, 1, "43a214d834380d63c90f17f34cb748730ef3f22ceee7cfb3355cf965078f810d")
