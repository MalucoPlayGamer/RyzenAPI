-- Lua provided by RyzenAPI
-- Game: addappid(1132700)

-- MAIN APPLICATION
addappid(1132700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132701, 1, "30471595bc06c7271097b2ffdebcb2f336da7817dd728c7bafca4aeb88b19c64")
addappid(1132702, 1, "01a305bd6c06b8b409b597fcedc53b49aed10a9b5757b9b068061fb26f37af1c")
