-- Lua provided by RyzenAPI
-- Game: Destinies Community Editor

-- MAIN APPLICATION
addappid(1883720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883721, 1, "a9aba381cee88751edc8f1da7db7b14e4c7fee8f320d9937d1651357bd2004bd")
addappid(1883722, 1, "fb0882806edc4dea0e5da505a72d49cb11b99872095455a51cc9a604889695c4")
addappid(1883723, 1, "04d30f577db5f4029469744aee72981995f7d8f1b9714bbba072390daa224263")
