-- Lua provided by RyzenAPI
-- Game: AppID 813000

-- MAIN APPLICATION
addappid(813000)

-- MAIN APP DEPOTS / PACKAGES
addappid(813001, 1, "eeec36e1ad5ecd3cfe0200e06b656dda6d3336deffab097b0b1e6685e4e60061")
