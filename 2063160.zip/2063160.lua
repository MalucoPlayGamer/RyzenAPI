-- Lua provided by RyzenAPI
-- Game: Courage

-- MAIN APPLICATION
addappid(2063160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063161, 1, "67edb82d181399178a0396295082c61505fd0cabd0bb3b14ecee34462c506397")

