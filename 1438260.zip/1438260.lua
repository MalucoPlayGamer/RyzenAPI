-- Lua provided by RyzenAPI
-- Game: 1438260

-- MAIN APPLICATION
addappid(1438260)
-- Game: addappid(1438260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438261, 1, "a3039eae8e5718de6b3b46e242889f6272e48df12ca02eca2e0ca86247fd34d9")
