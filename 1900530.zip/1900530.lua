-- Lua provided by RyzenAPI
-- Game: La Villa de la Muerte

-- MAIN APPLICATION
addappid(1900530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900531, 1, "f8e0a87c8da59152ffc0b7ab0c1c9a9882d24b3b6ea547af3136855b86a3a356")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
