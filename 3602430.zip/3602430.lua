-- Lua provided by RyzenAPI
-- Game: Game: Night Shift

-- MAIN APPLICATION
addappid(3602430)
-- Game: addappid(3602430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602431, 1, "36d948ec7b339fddb97a5d0fddab5fd638a7d80925b71aaa608dfc8f97fcc790")
