-- Lua provided by SkyAPI 
-- Game: Night Shift
addappid(3602430)
addappid(3602431, 1, "36d948ec7b339fddb97a5d0fddab5fd638a7d80925b71aaa608dfc8f97fcc790")
