-- Lua provided by RyzenAPI
-- Game: Pocket Arcade Story

-- MAIN APPLICATION
addappid(2072130)
-- Game: addappid(2072130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072131, 1, "cd9219ab4bd200af3f1cc85e7cb3618dd85c5706f5b55e1c2fa7173fb4b586e9")
