-- Lua provided by RyzenAPI
-- Game: addappid(2875140)

-- MAIN APPLICATION
addappid(2875140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875141, 1, "8b3e91f1ed5f67b93b42edabf455c00936c84e3d5c1159b9ac55434e91146630")
