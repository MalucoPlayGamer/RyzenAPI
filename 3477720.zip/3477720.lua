-- Lua provided by RyzenAPI
-- Game: 3477720

-- MAIN APPLICATION
addappid(3477720)
-- Game: addappid(3477720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477721, 1, "b0aa011e549efe08010aacc84673bd043a24f4c1d0c04dc262b1d4791730931e")
