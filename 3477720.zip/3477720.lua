-- Lua provided by RyzenAPI
-- Game: Go To Sleep

-- MAIN APPLICATION
addappid(3477720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3477721, 1, "b0aa011e549efe08010aacc84673bd043a24f4c1d0c04dc262b1d4791730931e")

