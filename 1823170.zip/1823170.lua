-- Lua provided by RyzenAPI
-- Game: Cosmos Bit

-- MAIN APPLICATION
addappid(1823170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823171, 1, "938cde94597b1333086e14dd9c6f78ac31874a7002e64cfb859bff36d59a3359")

