-- Lua provided by RyzenAPI 
-- Game: Cosmos Bit
addappid(1823170)
addappid(1823171, 1, "938cde94597b1333086e14dd9c6f78ac31874a7002e64cfb859bff36d59a3359")
