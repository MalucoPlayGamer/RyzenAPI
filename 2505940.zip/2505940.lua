-- Lua provided by RyzenAPI
-- Game: Rock 'N Racing Off Road

-- MAIN APPLICATION
addappid(2505940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505941,0,"d37a7a3b0d635bbf8ba967c6130e8107daa566a0d644707733b8ebda0a29db1c")

