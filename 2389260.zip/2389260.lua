-- Lua provided by RyzenAPI
-- Game: Game: Aldro

-- MAIN APPLICATION
addappid(2389260)
-- Game: addappid(2389260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389261, 1, "6dc4cde9e09284fc4905e51e8491ad11625d6bbae4bbd72cf8fdaf7fc9963425")
