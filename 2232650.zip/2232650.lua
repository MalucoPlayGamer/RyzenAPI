-- Lua provided by RyzenAPI
-- Game: Game: Expand & Exterminate: Terrytorial Disputes - Endless Base Defense

-- MAIN APPLICATION
addappid(2232650)
-- Game: addappid(2232650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232651, 1, "8732692bd47d02842a8bf7632f84121ae2bed68bd56635e39b2e7d5677230483")
