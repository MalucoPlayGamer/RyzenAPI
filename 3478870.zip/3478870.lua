-- Lua provided by RyzenAPI
-- Game: addappid(3478870)

-- MAIN APPLICATION
addappid(3478870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478872,0,"58b66b515624ba447ca136a45cdb5af016cb5cfd0a080a4d35d5a0760f2f9d28")
addappid(3478873,0,"146e64df011efa3de9e745c92a20bfc9b8c98953355afc1bed3e3ebe123d0fb0")
