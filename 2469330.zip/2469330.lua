-- Lua provided by RyzenAPI 
-- Game: The Pirate Queen with Lucy Liu
addappid(2469330)
addappid(2469331, 1, "ae6c913b2f95fcc7750f67dc0a6a4ffe2d14f5c243af5ed65d3128b5be5bef8e")
