-- Lua provided by RyzenAPI
-- Game: addappid(3097050)

-- MAIN APPLICATION
addappid(3097050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097051, 1, "a37ff2909a4fcc445da59e7e6f7062cb93b76a5fde0b46895918357831976c38")
