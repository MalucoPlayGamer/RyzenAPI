-- Lua provided by RyzenAPI
-- Game: Seraphic Destroyer

-- MAIN APPLICATION
addappid(1118820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118821, 1, "a9b13734fdac39425f30a538558b0da1379442fcfc5fe420afde4f7b97ae7098")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1230950)
