-- Lua provided by RyzenAPI
-- Game: Seraphic Destroyer

-- MAIN APPLICATION
addappid(1118820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118821, 1, "a9b13734fdac39425f30a538558b0da1379442fcfc5fe420afde4f7b97ae7098")

