-- Lua provided by RyzenAPI
-- Game: 701470

-- MAIN APPLICATION
addappid(701470)
-- Game: addappid(701470)

-- MAIN APP DEPOTS / PACKAGES
addappid(701471, 1, "2eef7a402453263d2a2e1aaacaa29a46883b1157f62d709d0bb2cf211d2ebfb1")
addappid(701472, 1, "ead9952e9aa44596a817638064dc003097db49c2424ad6b6070a2e0d326ded7a")
