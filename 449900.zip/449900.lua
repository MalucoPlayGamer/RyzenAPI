-- Lua provided by RyzenAPI
-- Game: 449900

-- MAIN APPLICATION
addappid(449900)
-- Game: addappid(449900)

-- MAIN APP DEPOTS / PACKAGES
addappid(449900,0,"b934e71d8b5f7666bb60a7677412a082a0e88baff22ae383fba38dfddcc3d07b")
