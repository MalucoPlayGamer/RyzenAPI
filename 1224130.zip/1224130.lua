-- Lua provided by RyzenAPI 
-- Game: DREAMLIVE
addappid(1224130)
addappid(1224131, 1, "af76545256cf33299628b2f4242e3e1ccac76e17f94b5421f081dbd6677729de")
