-- Lua provided by RyzenAPI
-- Game: DREAMLIVE

-- MAIN APPLICATION
addappid(1224130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1224131, 1, "af76545256cf33299628b2f4242e3e1ccac76e17f94b5421f081dbd6677729de")

