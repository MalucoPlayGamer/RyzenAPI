-- Lua provided by RyzenAPI
-- Game: 1224130

-- MAIN APPLICATION
addappid(1224130)
-- Game: addappid(1224130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224131, 1, "af76545256cf33299628b2f4242e3e1ccac76e17f94b5421f081dbd6677729de")
