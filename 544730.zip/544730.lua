-- Lua provided by RyzenAPI
-- Game: Game: AppID 544730

-- MAIN APPLICATION
addappid(544730)
-- Game: addappid(544730)

-- MAIN APP DEPOTS / PACKAGES
addappid(544731, 1, "6c9052efca71f4aa72e432331d286b60e39116f28e0e2aec4f20977734986385")
addappid(544732, 1, "8a0f1e7436ca2643faff46457e4fc2d33039fbe42a7cc4859385cb96f7cceb46")
