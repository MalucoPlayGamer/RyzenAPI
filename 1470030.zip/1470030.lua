-- Lua provided by RyzenAPI 
-- Game: Funtime with Buffy
addappid(1470030)
addappid(1470031, 1, "0b006e52a2984bbc94bf0fa37acd417c9fca25f64f986664465df18d6d246f2c")
