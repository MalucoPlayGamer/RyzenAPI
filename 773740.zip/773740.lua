-- Lua provided by RyzenAPI
-- Game: Overpass

-- MAIN APPLICATION
addappid(773740)

-- MAIN APP DEPOTS / PACKAGES
addappid(773741,0,"fb7437e79ebc53ee5e7e9b0636a37a63c52848da0957965946a62eadf0fc4900")
addappid(1098820,0,"886fdbf2d97a440cf901b9da69614caa5804c601bcf9ab1a3684ff4a9b2747c8")

