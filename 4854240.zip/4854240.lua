-- 4854240's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Nazumi is streaming
-- Created: July 09, 2026 at 00:17:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4854240) -- Hentai Clicker: Nazumi is streaming
-- MAIN APP DEPOTS
addappid(4854241, 1, "34db5b6045006f24c8e898a834c66546e08d6c0f5298abd3b4e338f1a4b75464") -- Depot 4854241
setManifestid(4854241, "3873558168921537153", 156667087)
addappid(4854242, 1, "f83693be70605a76e1cef38005faad08e9f09b9ea040288508f788942f4453ec") -- Depot 4854242
setManifestid(4854242, "3875655972305421741", 191369627)
addappid(4854243, 1, "c3574aec8f426ea2752590e45c497a9ad5e1e57630c571d4ce896d8157857e90") -- Depot 4854243
setManifestid(4854243, "6555953255123924485", 205266540)