-- Lua provided by SkyAPI 
-- Game: Wylde Flowers Soundtrack
addappid(2097590)
addappid(2097591, 1, "cb7dde14527b1a6b021144aed3d760ae4a9c87137fb15e4633e5b3017f47bd55")
