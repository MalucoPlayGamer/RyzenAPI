-- Lua provided by RyzenAPI
-- Game: Game: Monster Bullets

-- MAIN APPLICATION
addappid(2056090)
-- Game: addappid(2056090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056091, 1, "47ced1646a2fe3fada169b0d870351916561bff02e2006a2e42a7e6ac6d20824")
