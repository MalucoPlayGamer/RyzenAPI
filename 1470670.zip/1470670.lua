-- Lua provided by RyzenAPI
-- Game: addappid(1470670)

-- MAIN APPLICATION
addappid(1470670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470673,0,"d1c60e0aa577c680e738bae948fb1412459cbf46fddf1b84e34c5358b38355a1")
