-- Lua provided by RyzenAPI
-- Game: Squirrelmageddon!

-- MAIN APPLICATION
addappid(1470670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1470673,0,"d1c60e0aa577c680e738bae948fb1412459cbf46fddf1b84e34c5358b38355a1")

