-- Lua provided by RyzenAPI
-- Game: 2538470

-- MAIN APPLICATION
addappid(2538470)
-- Game: addappid(2538470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538471, 1, "db3ec9a96d5fc08b638d257e11e5a847b3b45e981f5f910ed2aeff8e3c3ee2b1")
