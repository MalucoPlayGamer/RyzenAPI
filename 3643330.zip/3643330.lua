-- Lua provided by RyzenAPI
-- Game: Zenith Drift

-- MAIN APPLICATION
addappid(3643330)
-- Game: addappid(3643330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3643331, 1, "7530744367e11c4db48c321b04d3881e601dc295e0b60bccceafe36e9f8da2e3")
