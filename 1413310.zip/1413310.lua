-- Lua provided by RyzenAPI
-- Game: Game: 幻刃录

-- MAIN APPLICATION
addappid(1413310)
-- Game: addappid(1413310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413311, 1, "1e1c01f66230b7f14ea8d8ac96eeee46aa59465677e9368be5392d88b2b25418")
