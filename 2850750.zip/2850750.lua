-- Lua provided by RyzenAPI
-- Game: Toofan AlAqsa

-- MAIN APPLICATION
addappid(2850750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2850752,0,"32ade9e90b423ec71b94d99bb49e59935087f323d53db7751563cb2296120f01")

