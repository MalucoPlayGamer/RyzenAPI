-- Lua provided by RyzenAPI
-- Game: Toofan AlAqsa

-- MAIN APPLICATION
addappid(2850750)
-- Game: addappid(2850750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850752,0,"32ade9e90b423ec71b94d99bb49e59935087f323d53db7751563cb2296120f01")
