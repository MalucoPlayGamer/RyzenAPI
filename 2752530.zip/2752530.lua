-- Lua provided by RyzenAPI
-- Game: Sect And Monsters

-- MAIN APPLICATION
addappid(2752530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752531, 1, "0dbfd7fa1bae0978a7a3d5907baf77a9b69ea5e7f7a078d14938bf76b4956050")

