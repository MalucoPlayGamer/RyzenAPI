-- Lua provided by RyzenAPI
-- Game: Game: Words Can Kill

-- MAIN APPLICATION
addappid(1732090)
-- Game: addappid(1732090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732091, 1, "d6e0e78dd812c1d767e8715617b313e323d55b1039cd55537746811295a00ded")
