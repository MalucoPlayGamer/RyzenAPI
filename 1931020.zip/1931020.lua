-- Lua provided by RyzenAPI
-- Game: Slayers X: Terminal Aftermath: Vengance of the Slayer

-- MAIN APPLICATION
addappid(1931020)
-- Game: addappid(1931020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931021, 1, "f0d50b7e45ed8a78fd5a3dbfca3478fad5c80af707f63ffdc8ecbf2389d6abc2")
