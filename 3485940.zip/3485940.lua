-- Lua provided by RyzenAPI 
-- Game: Shrimp Keeping Simulator
addappid(3485940)
addappid(3485941, 1, "c137111a4971de4eb0290fd3d7c94597744fbab950f33927f5189fe354f0bbd0")
