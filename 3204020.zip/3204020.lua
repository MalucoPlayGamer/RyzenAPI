-- Lua provided by RyzenAPI 
-- Game: Juufuutei Raden™'s Guide for Pixel Museum
addappid(3204020)
addappid(3204021, 1, "8bd0f832a898e70858c5f49b7fb59c250442ed573f7c72bdf80e8f5178048c24")
