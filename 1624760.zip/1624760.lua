-- Lua provided by RyzenAPI 
-- Game: Cardiac Unrest
addappid(1624760)
addappid(1624761, 1, "5f562e33750eccbf6f6114bba9fb4aea111ebbb02a5941d0b9ae7746bb1296f7")
