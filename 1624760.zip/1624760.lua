-- Lua provided by RyzenAPI
-- Game: 1624760

-- MAIN APPLICATION
addappid(1624760)
-- Game: addappid(1624760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624761, 1, "5f562e33750eccbf6f6114bba9fb4aea111ebbb02a5941d0b9ae7746bb1296f7")
