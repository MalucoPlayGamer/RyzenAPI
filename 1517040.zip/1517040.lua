-- Lua provided by RyzenAPI
-- Game: Game: CrossCode Original Soundtrack EX

-- MAIN APPLICATION
addappid(1517040)
-- Game: addappid(1517040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517041, 1, "9d544c96926f7884a67a0a3f2f282915c82b4e500b3224b13033145a59de09f3")
