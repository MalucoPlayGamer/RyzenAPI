-- Lua provided by RyzenAPI
-- Game: Game: No Strings Attached

-- MAIN APPLICATION
addappid(2716540)
-- Game: addappid(2716540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716541, 1, "870084e5dbf39ff1f333a1a356f55678498d40f57dfaf1a5c57af2f5557d924d")
