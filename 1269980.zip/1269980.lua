-- Lua provided by RyzenAPI
-- Game: Formata Soundtrack

-- MAIN APPLICATION
addappid(1269980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269981, 1, "6f61e7c756a13832ca18b9c6569979141148ffd0b627eefe0e499b982b79c748")
addappid(1269982, 1, "18b7aa2bc2dfe40a5898c6c3119bdc4ffec7a0e3066f07700833fd299a99f390")
