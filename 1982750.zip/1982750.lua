-- Lua provided by SkyAPI 
-- Game: WONDER POT
addappid(1982750)
addappid(1982751, 1, "ee55832eec79fdcdbf6e101a22c48658fc937d6f6638db63fefcbd122e390dae")
