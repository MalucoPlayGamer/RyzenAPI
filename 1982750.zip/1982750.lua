-- Lua provided by RyzenAPI
-- Game: Game: WONDER POT

-- MAIN APPLICATION
addappid(1982750)
-- Game: addappid(1982750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982751, 1, "ee55832eec79fdcdbf6e101a22c48658fc937d6f6638db63fefcbd122e390dae")
