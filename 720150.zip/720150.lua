-- Lua provided by RyzenAPI
-- Game: Shikhondo(食魂徒) - Soul Eater

-- MAIN APPLICATION
addappid(720150)

-- MAIN APP DEPOTS / PACKAGES
addappid(720151, 1, "7fc8b0878ca442fb2105787917b6466bb5c0c937077ef0e5f8f3917d5bdd206b")
addappid(725030, 0, "66af6534aabc9a2a4186feeeee2f5f60968cc08558d1dd7ecaed085b937770e4")

