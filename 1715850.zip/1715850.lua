-- Lua provided by RyzenAPI
-- Game: NAIR

-- MAIN APPLICATION
addappid(1715850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1715851, 1, "1e16e98862035f1552e0f4e6bc59d93c80a0a4f9f42d939ba044b24b0a9297d3")

