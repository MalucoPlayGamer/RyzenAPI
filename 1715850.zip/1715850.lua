-- Lua provided by RyzenAPI
-- Game: NAIR

-- MAIN APPLICATION
addappid(1715850)
-- Game: addappid(1715850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715851, 1, "1e16e98862035f1552e0f4e6bc59d93c80a0a4f9f42d939ba044b24b0a9297d3")
