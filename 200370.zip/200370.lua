-- Lua provided by RyzenAPI
-- Game: A Game of Dwarves

-- MAIN APPLICATION
addappid(200370)

-- MAIN APP DEPOTS / PACKAGES
addappid(200371, 1, "31d139366c43687c96aad187d5d3ec8ddfb242acd3df30c3813f73b649577978")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(222220)
addappid(222221)
addappid(222222)
addappid(222223)
addappid(222224)
addappid(222225)
