-- Lua provided by RyzenAPI
-- Game: 200370

-- MAIN APPLICATION
addappid(200370)
-- Game: addappid(200370)

-- MAIN APP DEPOTS / PACKAGES
addappid(200371, 1, "31d139366c43687c96aad187d5d3ec8ddfb242acd3df30c3813f73b649577978")
