-- Lua provided by RyzenAPI
-- Game: Starship Troopers: Ultimate Bug War!

-- MAIN APPLICATION
addappid(2321780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321781, 1, "cb775e098e46a6f68f2d02dbb1c9095df4afaa034fa74666ac66de8e6e06fa4d")
