-- Lua provided by RyzenAPI
-- Game: Halfway Home

-- MAIN APPLICATION
addappid(950250)
-- Game: addappid(950250)

-- MAIN APP DEPOTS / PACKAGES
addappid(950251, 1, "933cd49199ad70a20147495e90bd78843b68afb203f017673415121925ddf16c")
