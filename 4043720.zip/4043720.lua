-- Lua provided by RyzenAPI
-- Game: Without A Hitch

-- MAIN APPLICATION
addappid(4043720)
addappid(4515680)

-- MAIN APP DEPOTS / PACKAGES
addappid(4043721,0,"f6ab1d2ee9c742c8b329e219af3dff761a4e5690de7b5e130e1d6c74c6cc684f")

