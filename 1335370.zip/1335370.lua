-- Lua provided by RyzenAPI
-- Game: DVR Simulator

-- MAIN APPLICATION
addappid(1335370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335371, 1, "e1fe4231ec4d3069d684c5fc781c3093f4d426dfda0260830e4907d94081758b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
