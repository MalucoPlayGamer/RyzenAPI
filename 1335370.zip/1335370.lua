-- Lua provided by RyzenAPI
-- Game: DVR Simulator

-- MAIN APPLICATION
addappid(1335370)
-- Game: addappid(1335370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335371, 1, "e1fe4231ec4d3069d684c5fc781c3093f4d426dfda0260830e4907d94081758b")
