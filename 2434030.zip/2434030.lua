-- Lua provided by RyzenAPI
-- Game: Lacuna Lo-Fi Soundtrack

-- MAIN APPLICATION
addappid(2434030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434032,0,"dd66e190f62238509d99270d6712e08f21221aca73dad8433d9fc30350bf7594")
addappid(2434033,0,"7e2cc2367e0892ca5fdc90e5c538e2c30289e78010fc12cfe4017adbc19bada0")

