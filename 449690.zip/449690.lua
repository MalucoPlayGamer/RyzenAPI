-- Lua provided by RyzenAPI
-- Game: 449690

-- MAIN APPLICATION
addappid(449690)
-- Game: addappid(449690)

-- MAIN APP DEPOTS / PACKAGES
addappid(449691, 1, "917f91df2a5a5b7743cd6e771dac61212955f0b09e3f1f93a2de6ac119ed1f8e")
