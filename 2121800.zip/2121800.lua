-- Lua provided by RyzenAPI
-- Game: Wild Light: Darkest Isles Demo

-- MAIN APPLICATION
addappid(2121800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121801, 1, "0b39d758a7e85eb07d622269baa94575a7265f256899ff1c3f7979d2366499e1")

