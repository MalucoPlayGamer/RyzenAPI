-- Lua provided by RyzenAPI
-- Game: Game: Across the Obelisk

-- MAIN APPLICATION
addappid(1385380)
-- Game: addappid(1385380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385381, 1, "212b4c54a7dadad3bb6a4a55088868dde54c128e58d7ce4afab3363c77ba1383")
addappid(1385382, 1, "18b37f64253b8d3e91a2b06f6a1e6446857b10fc0c3ef5dc99fda4e626054e9b")
addappid(1385383, 1, "0671ea1b8cec86cac27391f005068b3758b9c4bf96d10f781893e87127a6b0c0")
addappid(1385384, 1, "5f65b73ec54888e940b46ea6f2de6b59069f8242617e44dde98d89adbf9d67a1")
