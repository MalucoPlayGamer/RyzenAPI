-- Lua provided by RyzenAPI
-- Game: Vestiges: Fallen Tribes

-- MAIN APPLICATION
addappid(2511780)
-- Game: addappid(2511780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511781, 1, "0790dbd3cf777b75548120aa0674f4afe4ac4d79cca556edfa0f332d7b6430ff")
