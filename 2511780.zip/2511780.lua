-- Lua provided by RyzenAPI
-- Game: Vestiges: Fallen Tribes

-- MAIN APPLICATION
addappid(2511780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511781, 1, "0790dbd3cf777b75548120aa0674f4afe4ac4d79cca556edfa0f332d7b6430ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
