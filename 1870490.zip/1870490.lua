-- Lua provided by RyzenAPI
-- Game: Prop Hunt 2.0

-- MAIN APPLICATION
addappid(1870490)
addappid(1979040)
addappid(1979041)
addappid(1979050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1870491, 1, "6b07bdb9cb7e06278ab823d4f0cd9abc3ae946600afb66d99b102fbd4ea77f0a")

