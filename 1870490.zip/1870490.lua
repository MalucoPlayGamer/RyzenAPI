-- Lua provided by RyzenAPI
-- Game: 1870490

-- MAIN APPLICATION
addappid(1870490)
-- Game: addappid(1870490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870491, 1, "6b07bdb9cb7e06278ab823d4f0cd9abc3ae946600afb66d99b102fbd4ea77f0a")
