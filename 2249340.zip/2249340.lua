-- Lua provided by RyzenAPI
-- Game: 互联网大亨 Internet tycoon

-- MAIN APPLICATION
addappid(2249340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249341, 1, "b7d06a8b55ea4201850617f895acbc393256a21e6ec1c79e6ea7340de3847228")
