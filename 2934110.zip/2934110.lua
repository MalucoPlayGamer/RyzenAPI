-- Lua provided by RyzenAPI
-- Game: Death Horizon: Cyberfusion

-- MAIN APPLICATION
addappid(2934110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934111, 1, "b039b09e4276649b4b006038d9601739192238dbab18742e74cb1055618ace51")
