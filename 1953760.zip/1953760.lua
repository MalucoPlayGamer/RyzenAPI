-- Lua provided by RyzenAPI
-- Game: Symbiotic

-- MAIN APPLICATION
addappid(1953760)
-- Game: addappid(1953760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953761, 1, "f4be9cad9e11f7e446ebff747b255e275a2a5010ca28e0c2fb57d3d7bb551364")
