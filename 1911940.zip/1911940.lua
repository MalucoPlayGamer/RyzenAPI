-- Lua provided by RyzenAPI
-- Game: 1911940

-- MAIN APPLICATION
addappid(1911940)
-- Game: addappid(1911940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911941, 1, "47af141dd232750fa872debb725881a41b05cb4124f59feea60ca89d344ae839")
