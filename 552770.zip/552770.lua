-- Lua provided by RyzenAPI
-- Game: Speech Trainer

-- MAIN APPLICATION
addappid(552770)

-- MAIN APP DEPOTS / PACKAGES
addappid(552771, 1, "ae5faa2dd6c382fcc72116aca17aad617cf39b3ebf5e091d8852ea8161a7e1a9")
