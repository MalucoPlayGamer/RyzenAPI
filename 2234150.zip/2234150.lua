-- Lua provided by RyzenAPI
-- Game: 2234150

-- MAIN APPLICATION
addappid(2234150)
-- Game: addappid(2234150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234151, 1, "b7d3cfbe2d7ab09a4e80d1083ae7b7ce90e9e11c3d33c29cf6677ae379ce23ce")
