-- Lua provided by RyzenAPI
-- Game: addappid(1781380)

-- MAIN APPLICATION
addappid(1781380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781383,0,"c10c218a8f3f845529e49870a74bbb209fda02d9ad2f9ce1e6add7c74b4b1279")
