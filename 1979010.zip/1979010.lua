-- Lua provided by SkyAPI 
-- Game: AppID 1979010
addappid(1979010)
addappid(1979011, 1, "59603c56b5269c5aca8a110c83b52b41b41a7b0459092da22eabbbb96b890100")
