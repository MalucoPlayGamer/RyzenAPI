-- Lua provided by RyzenAPI
-- Game: 1526570

-- MAIN APPLICATION
addappid(1526570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526572,0,"d8a8f93fb2b9aa9a679dbf0a36c75e4acd9bec35a2f7af8782d41ebae88dc5e1")

