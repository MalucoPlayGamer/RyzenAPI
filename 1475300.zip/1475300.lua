-- Lua provided by RyzenAPI
-- Game: Barbarian

-- MAIN APP DEPOTS / PACKAGES
addappid(1475300, 1, "3193b73fc690937d039aa2857228218ff9733bfba45c67179788edb0495ffafc") -- Barbarian
addappid(1475301, 1, "b1484ce9b525c829920b80b2405f81ddd780f3408cb35594d9969bfd1d8472bc") -- Depot 1475301

