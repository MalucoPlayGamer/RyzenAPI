-- 1475300's Lua and Manifest Created by Hubcap Manifest
-- Barbarian
-- Created: August 27, 2026 at 10:28:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1475300, 1, "3193b73fc690937d039aa2857228218ff9733bfba45c67179788edb0495ffafc") -- Barbarian
-- MAIN APP DEPOTS
addappid(1475301, 1, "b1484ce9b525c829920b80b2405f81ddd780f3408cb35594d9969bfd1d8472bc") -- Depot 1475301
setManifestid(1475301, "8531194882986531649", 1710442055)