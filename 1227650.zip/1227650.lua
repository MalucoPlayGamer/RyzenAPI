-- Lua provided by SkyAPI 
-- Game: AppID 1227650
addappid(1227650)
addappid(1227651, 1, "fafeeb93c5e87699a3d532456a7a4fc657f22c436a1d6664ce94d48450b26fd3")
addappid(1227653, 1, "ccb234c0bdb9a326c686b34c0eb76def617d67fd96501e4aea5c3965d54e8b95")
