-- Lua provided by RyzenAPI
-- Game: AppID 1227650

-- MAIN APPLICATION
addappid(1227650)
addappid(2624940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1227651, 1, "fafeeb93c5e87699a3d532456a7a4fc657f22c436a1d6664ce94d48450b26fd3")
addappid(1227653, 1, "ccb234c0bdb9a326c686b34c0eb76def617d67fd96501e4aea5c3965d54e8b95")

