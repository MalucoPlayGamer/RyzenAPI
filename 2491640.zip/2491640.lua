-- Lua provided by RyzenAPI
-- Game: Game: SNAKE FARM

-- MAIN APPLICATION
addappid(2491640)
-- Game: addappid(2491640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491641, 1, "21be1f30b6749f03dcf0c20522c1df0024bb0b8f4e0849ac340a1d869af0b113")
