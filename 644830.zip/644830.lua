-- Lua provided by RyzenAPI
-- Game: AppID 644830

-- MAIN APPLICATION
addappid(644830)
addappid(1068260)
addappid(1068261)
addappid(1068262)
addappid(1068263)
addappid(1068264)
addappid(1068265)
addappid(1068266)
addappid(1068267)
addappid(1068268)
addappid(1068269)
addappid(1102331)
addappid(1102332)
addappid(1102333)
addappid(1135970)
addappid(1135971)
addappid(1135972)
addappid(1137640)
addappid(1137641)
addappid(1162230)

-- MAIN APP DEPOTS / PACKAGES
addappid(644831, 1, "5273086060e6534a2869d0aa041197d1800ee255416bc62d8054f8cfb34ce6cc")
addappid(644832, 1, "264b2b4974f18466c6fc793568ee06180368326452a3b67cafa9d41e0f8ca0a7")
addappid(644833, 1, "c4528347167bcbc478ea4676f78c1bc4d65211250d443d84269196fb5f233e7a")
addappid(644834, 1, "45f4adb20300ea55959279bf0b9bc1b8618bd2b3d6ffb2b91628e3f5fe877b9b")
addappid(644835, 1, "782f58e874be3f73dd144917d6ba9c497bda342787d297e74780e45bb3475fcf")
addappid(644836, 1, "7b2266bd09aa555d1e75ae40445c2cc678b470f96c570d54dac264506ee10449")
addappid(644837, 1, "c6f4f22308baf57e31bf82a38aa604f412bdcc8add016073253dfcee46c27fab")
addappid(644838, 1, "bbb343d1f71ac58b573ba9a44ab20a5872fd5452ac67e65737455cc342a38eaf")
addappid(1102334, 0, "0547a3098567ccdff45ca84909f835af85911cb22db4eeeb36ee2ddc014b3247")
addappid(1102335, 0, "35eff09e4d09506b683bcadea614fb2b066a37a657f96da02dc6aa6c8d914d5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
