-- Lua provided by RyzenAPI
-- Game: Doodle Adventure of Chameleon

-- MAIN APPLICATION
addappid(2544900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544901, 1, "1154b462c3f81b7ddb705a94e98b851b0b433e020e50e3b5134f31b73969b71b")
