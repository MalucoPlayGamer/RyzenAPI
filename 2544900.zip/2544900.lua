-- Lua provided by RyzenAPI
-- Game: Doodle Adventure of Chameleon

-- MAIN APPLICATION
addappid(2544900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2544901, 1, "1154b462c3f81b7ddb705a94e98b851b0b433e020e50e3b5134f31b73969b71b")

