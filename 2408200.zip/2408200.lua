-- Lua provided by RyzenAPI
-- Game: Game: AppID 2408200

-- MAIN APPLICATION
addappid(2408200)
-- Game: addappid(2408200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408201, 1, "896011c669a74d312d9b93fdc13b50a5d82bb1167f5f7f5461688f2358d31f19")
