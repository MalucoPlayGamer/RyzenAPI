-- Lua provided by RyzenAPI 
-- Game: AppID 1471180
addappid(1471180)
addappid(1471181, 1, "b958b6ff26796c1543f3db4cd318da9d33a8847e97a1e5a6a608851967db3ba1")
addappid(1471182, 1, "ff67d2c86db2e7573abbb8391acf81fc65849d34bf67615071c900152b8a31e0")
