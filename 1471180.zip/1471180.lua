-- Lua provided by RyzenAPI
-- Game: 梦江湖

-- MAIN APPLICATION
addappid(1471180)
addappid(1691150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1471181, 1, "b958b6ff26796c1543f3db4cd318da9d33a8847e97a1e5a6a608851967db3ba1")
addappid(1471182, 1, "ff67d2c86db2e7573abbb8391acf81fc65849d34bf67615071c900152b8a31e0")

