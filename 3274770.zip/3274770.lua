-- Lua provided by RyzenAPI
-- Game: The Gleaming Grill

-- MAIN APPLICATION
addappid(3274770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274771, 1, "596e3df10e00aca0df1d5ba896951b9a724e0217bfbf1199a5afe832f66f3b49")

