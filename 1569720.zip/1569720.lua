-- Lua provided by RyzenAPI
-- Game: Attack Of UNDO Zai

-- MAIN APPLICATION
addappid(1569720)
-- Game: addappid(1569720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569721, 1, "e79f5980721dc3ec6a26c55318226dc3d047ce317ceab425f418a63ec3c0511d")
