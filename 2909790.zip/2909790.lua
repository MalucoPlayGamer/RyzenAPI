-- Lua provided by RyzenAPI
-- Game: SONIC X SHADOW GENERATIONS: Sonic Jam Legacy Skin

-- MAIN APP DEPOTS / PACKAGES
addappid(2909790, 1)

