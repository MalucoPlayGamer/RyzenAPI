-- Lua provided by RyzenAPI
-- Game: Облик из Sonic Jam в SONIC X SHADOW GENERATIONS

-- MAIN APP DEPOTS / PACKAGES
addappid(2909790, 1)
-- Game: addappid(2909790, 1)
