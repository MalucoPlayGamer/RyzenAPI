-- Lua provided by RyzenAPI
-- Game: 2909790

-- MAIN APP DEPOTS / PACKAGES
addappid(2909790, 1)
-- Game: addappid(2909790, 1)
