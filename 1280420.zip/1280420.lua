-- Lua provided by RyzenAPI
-- Game: Mannequin Character Generator

-- MAIN APPLICATION
addappid(1280420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280421, 1, "70f61105b645192b0611a9f846ff09f52918aa66c4756760a6cadd70ced4ff0c")

