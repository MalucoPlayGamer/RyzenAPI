-- Lua provided by RyzenAPI
-- Game: Kubinashi Recollection

-- MAIN APPLICATION
addappid(1635980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635981, 1, "e2c898b5a962d69fb9657ae5d5a40bd00efe11988f10fcf963f356b2d21690e9")
