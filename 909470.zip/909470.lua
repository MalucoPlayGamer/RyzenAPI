-- Lua provided by SkyAPI 
-- Game: Touch Type Tale - Strategic Typing
addappid(909470)
addappid(909471, 1, "7d3e57bf0483f7d96546a1ae1c58d49b4c74c11964077176859ec7f11c37699a")
