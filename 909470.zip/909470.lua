-- Lua provided by RyzenAPI
-- Game: Touch Type Tale - Strategic Typing

-- MAIN APPLICATION
addappid(909470)
-- Game: addappid(909470)

-- MAIN APP DEPOTS / PACKAGES
addappid(909471, 1, "7d3e57bf0483f7d96546a1ae1c58d49b4c74c11964077176859ec7f11c37699a")
