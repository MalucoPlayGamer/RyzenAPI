-- Lua provided by RyzenAPI
-- Game: Sandwich Sudoku

-- MAIN APPLICATION
addappid(1117310)
-- Game: addappid(1117310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117311, 1, "e518183cd21a2410c8e87dcf05ebc10ed099e7ddf064de3c3f67fed55e2a6acd")
