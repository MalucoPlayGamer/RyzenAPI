-- Lua provided by RyzenAPI
-- Game: addappid(378200)

-- MAIN APPLICATION
addappid(378200)

-- MAIN APP DEPOTS / PACKAGES
addappid(378201, 1, "d3c97a2c7a80c6b34caa2765a05ac1ff723a2965d311272f5065e242f9c37596")
