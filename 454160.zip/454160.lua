-- Lua provided by RyzenAPI
-- Game: Dark Fear

-- MAIN APPLICATION
addappid(454160)

-- MAIN APP DEPOTS / PACKAGES
addappid(454161, 1, "9526133209e576b8cf01fd233ad4efa4500c2801bb65a8bcf808e9d24ceb5a42")

