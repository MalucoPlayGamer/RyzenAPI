-- Lua provided by RyzenAPI
-- Game: addappid(2336580)

-- MAIN APPLICATION
addappid(2336580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336581, 1, "201635e36944089c699cfd7d6f56644ea2a1bee77cffba3697caafc1e85bc131")
