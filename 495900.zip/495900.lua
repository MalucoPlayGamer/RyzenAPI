-- Lua provided by RyzenAPI
-- Game: Lance A Lot: Classic Edition

-- MAIN APPLICATION
addappid(495900)

-- MAIN APP DEPOTS / PACKAGES
addappid(495901, 1, "de005f97cc799d2e4b61683d3dd2284eea2ddaef5124f27971124bb79a59d6ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
