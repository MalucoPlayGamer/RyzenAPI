-- Lua provided by RyzenAPI
-- Game: Lance A Lot: Classic Edition

-- MAIN APPLICATION
addappid(495900)

-- MAIN APP DEPOTS / PACKAGES
addappid(495901, 1, "de005f97cc799d2e4b61683d3dd2284eea2ddaef5124f27971124bb79a59d6ca")

