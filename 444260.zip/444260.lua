-- Lua provided by RyzenAPI
-- Game: Game: AppID 444260

-- MAIN APPLICATION
addappid(444260)
-- Game: addappid(444260)

-- MAIN APP DEPOTS / PACKAGES
addappid(444261, 1, "0a7108c8da70ba87a319828a2b72daf71bd2fcbd5b13617a0bc506a983dd8e3c")
