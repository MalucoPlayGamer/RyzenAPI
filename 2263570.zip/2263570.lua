-- Lua provided by RyzenAPI
-- Game: addappid(2263570)

-- MAIN APPLICATION
addappid(2263570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263571, 1, "9dc74a9a6265d62d0023ae06c6b7e45f7e48a39b8e65caaa5f16b4c8391926b1")
