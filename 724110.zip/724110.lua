-- Lua provided by RyzenAPI
-- Game: PlayUSA

-- MAIN APPLICATION
addappid(724110)

-- MAIN APP DEPOTS / PACKAGES
addappid(724111, 1, "d17ddead18a7301b9f377bc1c0278aee61716bfcf43e1f1fcb1891473263478a")
