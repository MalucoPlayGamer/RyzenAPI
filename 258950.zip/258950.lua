-- Lua provided by RyzenAPI 
-- Game: Montague's Mount
addappid(258950)
addappid(258951, 1, "5b916e0ef477fdfddcb9c886722b23edfb1fdc5bcdce4b08941cb492cd1f4e7e")
addappid(258952, 1, "acedb0342a3e55e6b64e1605aca2b308be699f4392ec4db2a641a53c443931c5")
addappid(258953, 1, "4a304b6c5c643aa077a55310954be9925d96c756501bb8dcbccb9047e246259d")
