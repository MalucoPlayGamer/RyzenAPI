-- Lua provided by RyzenAPI
-- Game: Game: Welcome to Albion!

-- MAIN APPLICATION
addappid(1885520)
addappid(2640430)
-- Game: addappid(1885520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885521, 1, "ed5260a92ee63cc49d683c59b68bc23caa66336af0064c76bb6abfc97b95ce7e")
