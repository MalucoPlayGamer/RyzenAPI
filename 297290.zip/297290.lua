-- Lua provided by RyzenAPI
-- Game: 297290

-- MAIN APPLICATION
addappid(297290)
-- Game: addappid(297290)

-- MAIN APP DEPOTS / PACKAGES
addappid(297291, 1, "d4fbe27d187904c3a028f168e990c3ba53e4bc67245110af3b0eb71265d4a346")
addappid(297292, 1, "6e11a899a635b2b1769ac56cb8c234d9aa7bb01cda9b1e45d350e8e2b60fd721")
addappid(297293, 1, "be2844599d5f2cf8d15a3d6d18e023a98c67cb8bba029604c4da0dc3b462b6c0")
addappid(326070, 0, "7534a32be5c3fa629ffee2e4cb8e7ef999c3ca29da4b8a35977da1194427c556")
