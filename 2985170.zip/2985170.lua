-- Lua provided by RyzenAPI
-- Game: Game: 學生騎士團

-- MAIN APPLICATION
addappid(2985170)
-- Game: addappid(2985170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985171, 1, "df21e0dc99f0b61dbf8e0930ef60ab3aa7590edf9e6bb1fb7ae5d4b8eccc41af")
addappid(2985172, 1, "a90353bf05dda46136fce88d54ca24313bc19a6d3c085000c0170703e679f90d")
addappid(2985173, 1, "7925400f877939561d9c5c656178d3ad7bdc58264771e223bbe0145a430d1e32")
