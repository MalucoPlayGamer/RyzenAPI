-- Lua provided by RyzenAPI
-- Game: Game: 跑团工坊 TRPG Workshop Demo

-- MAIN APPLICATION
addappid(1720380)
-- Game: addappid(1720380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720381, 1, "c3578457310f36dd94efad46fec1bbd3ae1fb175326301bbaf22c9b44fa1de60")
