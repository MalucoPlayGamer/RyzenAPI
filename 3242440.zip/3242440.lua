-- Lua provided by RyzenAPI
-- Game: Globalism Demo

-- MAIN APPLICATION
addappid(3242440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242441, 1, "963c0c2964e4c1bbf4e2ecaf476f05628565aaded8986fd8554268d526de912f")

