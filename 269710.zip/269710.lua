-- Lua provided by RyzenAPI
-- Game: Tumblestone

-- MAIN APPLICATION
addappid(269710)
addappid(484910)
addappid(484920)
addappid(531650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(269711,0,"667e4a1c498de9a27f579dc1cb7afe1bbe51fb809fb843a9ec2ef363f02394c0")
addappid(269712,0,"8ab12c9675b9b0f7cc1f926cbb7c427665cea28fc113e066f195e743b042057c")
addappid(269713,0,"aafc39abd0940380642cf0383d35e027e39c464a9196e29676812e2271929942")

