-- Lua provided by RyzenAPI 
-- Game: Pseudoregalia
addappid(2365810)
addappid(2365811, 1, "c877a58e869714c7851568326dfcdd4dbf2ff0508447e7d25643b460009c26b5")
