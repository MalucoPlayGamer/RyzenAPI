-- Lua provided by RyzenAPI
-- Game: Pseudoregalia

-- MAIN APPLICATION
addappid(2365810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365811, 1, "c877a58e869714c7851568326dfcdd4dbf2ff0508447e7d25643b460009c26b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
