-- Lua provided by RyzenAPI
-- Game: Backrooms Descent: Multiplayer Horror

-- MAIN APPLICATION
addappid(2232180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232181, 1, "6da7d9bb69c5e1c4f154422df859eb3fc101bea81210542ff050d1b85fc8f651")
