-- Lua provided by RyzenAPI
-- Game: Backrooms Descent: Multiplayer Horror

-- MAIN APPLICATION
addappid(2232180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232181, 1, "6da7d9bb69c5e1c4f154422df859eb3fc101bea81210542ff050d1b85fc8f651")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
