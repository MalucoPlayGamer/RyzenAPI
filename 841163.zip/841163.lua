-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(841163)
-- Game: addappid(841163)

-- MAIN APP DEPOTS / PACKAGES
addappid(865480,0,"497c2041bf2981ec6bf1bea2f830fb83ea5bb8877afc6701ec93e90e38ade04a")
