-- Lua provided by RyzenAPI
-- Game: addappid(841163)

-- MAIN APPLICATION
addappid(841163)

-- MAIN APP DEPOTS / PACKAGES
addappid(865480,0,"497c2041bf2981ec6bf1bea2f830fb83ea5bb8877afc6701ec93e90e38ade04a")
