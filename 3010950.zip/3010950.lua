-- Lua provided by RyzenAPI
-- Game: Game: AppID 3010950

-- MAIN APPLICATION
addappid(3010950)
-- Game: addappid(3010950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010951, 1, "5ff0b7e631f1568e1bf9a514c2a198a66046e00db631309308486fff32c828e2")
