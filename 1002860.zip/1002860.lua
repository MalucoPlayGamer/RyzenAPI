-- Lua provided by RyzenAPI
-- Game: Magus Over Fool

-- MAIN APPLICATION
addappid(1002860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1002861, 1, "a0219d6e3487c7be09672e3e46b05854051df4b28790f1412a8af9912a494ab3")

