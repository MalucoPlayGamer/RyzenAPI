-- Lua provided by RyzenAPI
-- Game: Magus Over Fool

-- MAIN APPLICATION
addappid(1002860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002861, 1, "a0219d6e3487c7be09672e3e46b05854051df4b28790f1412a8af9912a494ab3")
