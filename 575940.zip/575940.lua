-- Lua provided by RyzenAPI
-- Game: The Tenth Line

-- MAIN APPLICATION
addappid(575940)

-- MAIN APP DEPOTS / PACKAGES
addappid(575941, 1, "170fcc27bda435c23fde183da96f7b54fc7c0abfdf4048f9f1b132d8b6d16f98")
addappid(575942, 1, "2f7fd35ae4d16638c6941cc4b7b6b838b8b95c23633371829c20d120be616d89")

