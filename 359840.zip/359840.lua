-- Lua provided by RyzenAPI
-- Game: Shift Happens

-- MAIN APPLICATION
addappid(359840)

-- MAIN APP DEPOTS / PACKAGES
addappid(359841, 1, "cc32cf49b1522b5157f606604c2faa3495a55b160c670e3ab7ba501eb298eb49")
addappid(359842, 1, "a10b419acce9fd5c94bc7bf92828f5b00989012884468fef152f9cf86c6e5ff1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
