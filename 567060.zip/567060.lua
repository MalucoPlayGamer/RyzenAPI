-- Lua provided by SkyAPI 
-- Game: AppID 567060
addappid(567060)
addappid(567061, 1, "3b3547184c38436d305458e808d9d9923ffff30b1d1ce21d8c789f90cd5767a4")
