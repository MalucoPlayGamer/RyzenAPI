-- 2864290's Lua and Manifest Created by Hubcap Manifest
-- Aggelos 2
-- Created: August 27, 2026 at 11:16:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2864290) -- Aggelos 2
-- MAIN APP DEPOTS
addappid(2864291, 1, "5e5ad3cfac2e6f2c26171cf541f14dc26d60978633a9dc4e2f4019628af8bae6") -- Depot 2864291
setManifestid(2864291, "2616498403026539651", 85801826)