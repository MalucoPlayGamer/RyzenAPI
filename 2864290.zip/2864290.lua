-- Lua provided by RyzenAPI
-- Game: Aggelos 2

-- MAIN APPLICATION
addappid(2864290) -- Aggelos 2

-- MAIN APP DEPOTS / PACKAGES
addappid(2864291, 1, "5e5ad3cfac2e6f2c26171cf541f14dc26d60978633a9dc4e2f4019628af8bae6") -- Depot 2864291

