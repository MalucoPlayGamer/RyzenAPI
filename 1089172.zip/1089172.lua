-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Rocksmith Intermediate Exercises, Vol. 1

-- MAIN APPLICATION
addappid(1089172)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089172,0,"4eab017c2dddc5fc88212be96a197eb0cf6b931a1de316250cf953083e02969d")

