-- Lua provided by SkyAPI 
-- Game: AppID 957790
addappid(957790)
addappid(957791, 1, "74b1afe87a1c65aeda390a1fe9b891137c3b0fc957a0f4359e56e3a0bf587047")
