-- Lua provided by RyzenAPI
-- Game: Linelith

-- MAIN APPLICATION
addappid(1923790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923791, 1, "457cf9e139c6a7a17bc6d553913b02f0b23dac88b286385052f7152e2049487d")

