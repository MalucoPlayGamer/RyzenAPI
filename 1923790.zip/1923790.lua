-- Lua provided by SkyAPI 
-- Game: Linelith
addappid(1923790)
addappid(1923791, 1, "457cf9e139c6a7a17bc6d553913b02f0b23dac88b286385052f7152e2049487d")
