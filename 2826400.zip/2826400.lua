-- Lua provided by RyzenAPI
-- Game: CASE RECORDS: Fear of Abduction

-- MAIN APPLICATION
addappid(2826400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826401, 1, "e56e3248a19c365e23aa8eaa1f00e703ed57725d877c40945441f6b8d364a1a5")

