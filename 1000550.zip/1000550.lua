-- Lua provided by RyzenAPI
-- Game: Love Hentai: Endgame

-- MAIN APPLICATION
addappid(1000550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000551, 1, "48a04783291a258ede4a48a5e7bdcb9dae63168fdaf0507d6a95f3b333ce0581")
