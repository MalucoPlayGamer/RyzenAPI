-- Lua provided by RyzenAPI
-- Game: Game: AppID 60340

-- MAIN APPLICATION
addappid(60340)
-- Game: addappid(60340)

-- MAIN APP DEPOTS / PACKAGES
addappid(60341, 1, "9c40dfd43c8cfe8b7266addc9bedf4ae255469fa028ba0c1ee1386db29dc2bde")
addappid(60342, 1, "737eda0115d32a6daedf96df20174dea1834ecc4c2e67f66251b88f6a2af85c6")
