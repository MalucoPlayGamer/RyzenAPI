-- Lua provided by RyzenAPI
-- Game: Hentai Girls: The Princesses

-- MAIN APPLICATION
addappid(2968250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968251, 1, "d56cbd8830b662181de84d1bd4ba2d4d3b93a317e975907b31fcfc18e77ee6ce")
