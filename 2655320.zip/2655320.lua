-- Lua provided by RyzenAPI
-- Game: addappid(2655320)

-- MAIN APPLICATION
addappid(2655320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655321, 1, "609348c38d7eea614dfa1134abf7259ae2ace0e06654f66d68c5449a4beb6836")
