-- Lua provided by RyzenAPI
-- Game: Parallax Tunnel

-- MAIN APPLICATION
addappid(1582130)
-- Game: addappid(1582130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582131, 1, "f60335506aee2c5523896e1122415fe305e398b6cd5843c553d11ff86d553811")
