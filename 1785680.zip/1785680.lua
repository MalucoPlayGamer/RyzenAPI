-- Lua provided by RyzenAPI
-- Game: addappid(1785680)

-- MAIN APPLICATION
addappid(1785680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785681, 1, "b97b12bedcd8c86ee6b9dd6ed9714fc69d1514883028a8aad3e66d8fa35b1b38")
