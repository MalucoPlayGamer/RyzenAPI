-- Lua provided by RyzenAPI
-- Game: Game: Aleesha's Tower

-- MAIN APPLICATION
addappid(1130590)
-- Game: addappid(1130590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130591, 1, "a22915e134f6248cec85ab3c8bc0f0549630406b14a96f5d31e8835d49df4680")
