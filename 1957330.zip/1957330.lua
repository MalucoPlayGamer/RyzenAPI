-- Lua provided by RyzenAPI 
-- Game: VTuber Plus
addappid(1957330)
addappid(1957331, 1, "4c072bd778d71bb1cf3b9424a53cede86d2114e187f1299bcf0fa820697890ea")
