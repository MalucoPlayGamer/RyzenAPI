-- Lua provided by RyzenAPI
-- Game: VTuber Plus

-- MAIN APPLICATION
addappid(1957330)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1957331, 1, "4c072bd778d71bb1cf3b9424a53cede86d2114e187f1299bcf0fa820697890ea")

