-- Lua provided by RyzenAPI
-- Game: Game: VTuber Plus

-- MAIN APPLICATION
addappid(1957330)
-- Game: addappid(1957330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957331, 1, "4c072bd778d71bb1cf3b9424a53cede86d2114e187f1299bcf0fa820697890ea")
