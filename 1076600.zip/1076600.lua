-- Lua provided by RyzenAPI
-- Game: Red Gate

-- MAIN APPLICATION
addappid(1076600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1076601, 1, "f67d8f4b38701f69d338ca1a098a82dad4c5ff1b446270b3891a988ace078aec")

