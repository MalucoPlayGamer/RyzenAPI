-- Lua provided by RyzenAPI
-- Game: addappid(1246400)

-- MAIN APPLICATION
addappid(1246400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246401, 1, "077d4a9df148fe40bff9ad3bb7b0fe87e4b1a21a1cbbd85c58dea29083335c46")
