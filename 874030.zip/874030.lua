-- Lua provided by RyzenAPI
-- Game: Game: To the Core

-- MAIN APPLICATION
addappid(874030)
-- Game: addappid(874030)

-- MAIN APP DEPOTS / PACKAGES
addappid(874031, 1, "47e3956642404e77f7267c45dcf948799f735e933517f67095aaa813b6cc43b9")
