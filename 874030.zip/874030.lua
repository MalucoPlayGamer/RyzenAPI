-- Lua provided by RyzenAPI 
-- Game: To the Core
addappid(874030)
addappid(874031, 1, "47e3956642404e77f7267c45dcf948799f735e933517f67095aaa813b6cc43b9")
