-- Lua provided by RyzenAPI
-- Game: Dreamfall: The Longest Journey

-- MAIN APPLICATION
addappid(6300)
-- Game: addappid(6300)

-- MAIN APP DEPOTS / PACKAGES
addappid(6301, 1, "545e4fed0b8f876b32db86babaafdce2f48b0b84c54433f7279737ce431cb99f")
addappid(6302, 1, "befe72c2b86471b2e5c8640f2a807e34ddd71b4a0ef01bc361d46d8fff0f0e39")
addappid(6303, 1, "3494b42c09af5e721eed1ae880ac93647812334ecaa065342d0ba6d829095939")
addappid(6304, 1, "d9c100af93f999eec2de6c51dc8281f06e579972c1e0c064522c465fe9b652d9")
addappid(6305, 1, "42aea9f15fc674d20c69858efd9d40b3b78e18deeab35d2d94c544351e006539")
