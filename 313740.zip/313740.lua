-- Lua provided by RyzenAPI
-- Game: Game: Sakura Spirit

-- MAIN APPLICATION
addappid(313740)
-- Game: addappid(313740)

-- MAIN APP DEPOTS / PACKAGES
addappid(313741, 1, "601143dbd584baebb8f9ed0f80062f3ab899956a00e0526a1a3300423a717f56")
addappid(339070, 0, "e62e8b475aed63c1a5a165baaa8c9470fb2ecc02fd5dac4fcf573bc7281c8080")
