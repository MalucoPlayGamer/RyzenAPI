-- Lua provided by RyzenAPI
-- Game: addappid(2745660)

-- MAIN APPLICATION
addappid(2745660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745661, 1, "413cf1b78b3697b9ee70d8ec6697d913d0e1821b9e84f79c50054ab85f8be0d9")
