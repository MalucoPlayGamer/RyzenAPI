-- Lua provided by SkyAPI 
-- Game: Monsters of Mican
addappid(2745660)
addappid(2745661, 1, "413cf1b78b3697b9ee70d8ec6697d913d0e1821b9e84f79c50054ab85f8be0d9")
