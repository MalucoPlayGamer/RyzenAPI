-- Lua provided by RyzenAPI
-- Game: Monsters of Mican

-- MAIN APPLICATION
addappid(2745660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2745661, 1, "413cf1b78b3697b9ee70d8ec6697d913d0e1821b9e84f79c50054ab85f8be0d9")

