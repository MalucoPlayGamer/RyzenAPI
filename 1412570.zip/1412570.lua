-- Lua provided by RyzenAPI
-- Game: Monster Hunter Stories 2: Wings of Ruin Trial Version

-- MAIN APPLICATION
addappid(1412570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412571, 1, "799764b28555acc75b6ec29d4a9b1c07777be1c374588fd5b8f6c28dd6b1e472")
addappid(1412572, 1, "a3d9622bcd55e6fccbeeddd75163a3de84fab9c5915064f9e3eaf571f98b21c1")
