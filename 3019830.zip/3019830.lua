-- Lua provided by RyzenAPI
-- Game: Sandbox Apocalypse

-- MAIN APPLICATION
addappid(3019830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019831, 1, "2ff31bdcd135c3226b91926f3f007b93248539c341438052b970e1a9a270fc2b")
