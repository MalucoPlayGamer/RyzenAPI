-- Lua provided by RyzenAPI 
-- Game: Sandbox Apocalypse
addappid(3019830)
addappid(3019831, 1, "2ff31bdcd135c3226b91926f3f007b93248539c341438052b970e1a9a270fc2b")
