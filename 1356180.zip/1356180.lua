-- Lua provided by RyzenAPI
-- Game: Game: AppID 1356180

-- MAIN APPLICATION
addappid(1356180)
-- Game: addappid(1356180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356181, 1, "eff0f8d1f96a11faa1a4d476d960ba9e99afad4c9d41d8d2cb4277e4c0153ac0")
