-- Lua provided by RyzenAPI
-- Game: addappid(763300)

-- MAIN APPLICATION
addappid(763300)

-- MAIN APP DEPOTS / PACKAGES
addappid(763301, 1, "f5adc061230e865d51a3de1c63d6ec4e3e24eab14169e154da38b5ca85e27f5a")
