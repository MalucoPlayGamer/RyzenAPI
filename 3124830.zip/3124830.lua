-- Lua provided by RyzenAPI
-- Game: Plants & Paws Demo

-- MAIN APPLICATION
addappid(3124830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124832,0,"063444ef2c3d01c4eb0c242201b3d83d481bc268a446a0360013780f1b7666ba")

