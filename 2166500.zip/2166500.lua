-- Lua provided by RyzenAPI
-- Game: That Makes Sense

-- MAIN APPLICATION
addappid(2166500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166501, 1, "46380b6dc0a4f2ee497368cc4b18ef371fcef2df9e9aa49f1e6fbdb6d863b608")
