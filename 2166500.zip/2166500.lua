-- Lua provided by RyzenAPI
-- Game: That Makes Sense

-- MAIN APPLICATION
addappid(2166500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166501, 1, "46380b6dc0a4f2ee497368cc4b18ef371fcef2df9e9aa49f1e6fbdb6d863b608")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
