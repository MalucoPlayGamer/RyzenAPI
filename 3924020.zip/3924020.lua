-- Lua provided by RyzenAPI
-- Game: Until North Ends

-- MAIN APPLICATION
addappid(3924020) -- Until North Ends

-- MAIN APP DEPOTS / PACKAGES
addappid(3924021, 1, "4b621b53a8b10945f4c7db54035b501a13cb34395eccf2a158e5736a6b3edeb8") -- Depot 3924021

