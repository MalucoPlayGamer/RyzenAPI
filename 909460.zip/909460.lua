-- Lua provided by RyzenAPI
-- Game: AppID 909460

-- MAIN APPLICATION
addappid(909460)
-- Game: addappid(909460)

-- MAIN APP DEPOTS / PACKAGES
addappid(909461, 1, "6954df710c24386eca9ebaf01c918cb9db209cd14c348369ed8292c9e048b2a4")
