-- Lua provided by RyzenAPI
-- Game: PhotoVidShow

-- MAIN APPLICATION
addappid(909460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(909461, 1, "6954df710c24386eca9ebaf01c918cb9db209cd14c348369ed8292c9e048b2a4")

