-- Lua provided by RyzenAPI
-- Game: The Great War: Western Front™

-- MAIN APPLICATION
addappid(2109370)
addappid(2361670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2109371, 1, "10ef091d30c140edf4aaae9d81771407eb4c6053d7ed10c256f173c2661d5b6b")
addappid(2285590, 0, "3a691865239e553dea5eb6f96ec162d91ea200caf69f4a56943b7ef9ab4f9eea")
addappid(2285591, 0, "a236d6daefe296fd050be090384dda6651c1977693db554da0d03c653516f634")

