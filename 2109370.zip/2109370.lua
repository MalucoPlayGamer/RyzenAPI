-- Lua provided by RyzenAPI
-- Game: Game: The Great War: Western Front™

-- MAIN APPLICATION
addappid(2109370)
addappid(2361670)
-- Game: addappid(2109370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109371, 1, "10ef091d30c140edf4aaae9d81771407eb4c6053d7ed10c256f173c2661d5b6b")
addappid(2285590, 0, "3a691865239e553dea5eb6f96ec162d91ea200caf69f4a56943b7ef9ab4f9eea")
addappid(2285591, 0, "a236d6daefe296fd050be090384dda6651c1977693db554da0d03c653516f634")
