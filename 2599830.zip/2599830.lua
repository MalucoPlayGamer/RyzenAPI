-- Lua provided by RyzenAPI
-- Game: Game: Candlelight: Lament Demo

-- MAIN APPLICATION
addappid(2599830)
-- Game: addappid(2599830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599831, 1, "faf05d28f855ee29105f5a70c54cdb8122fefac486796d1c523aede7ab48f5d6")
