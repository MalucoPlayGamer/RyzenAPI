-- Lua provided by RyzenAPI
-- Game: Truck Town: Kids and Toddlers Driving Game

-- MAIN APPLICATION
addappid(3584120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584121, 1, "1e3c9ab63252803b070cfa3be7859ee1b64bac8ec2fba321fde19b4e1d5015f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
