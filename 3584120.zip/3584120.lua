-- Lua provided by RyzenAPI
-- Game: 3584120

-- MAIN APPLICATION
addappid(3584120)
-- Game: addappid(3584120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584121, 1, "1e3c9ab63252803b070cfa3be7859ee1b64bac8ec2fba321fde19b4e1d5015f0")
