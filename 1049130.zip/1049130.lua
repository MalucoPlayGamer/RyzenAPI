-- Lua provided by RyzenAPI 
-- Game: SPECIAL FORCE VR: INFINITY WAR
addappid(1049130)
addappid(1049131, 1, "55c707f15023eeb7433c2bc942470b9c66f841a2accc18c3a86a54b0c47502bd")
