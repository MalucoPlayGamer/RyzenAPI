-- Lua provided by SkyAPI 
-- Game: Radiant: Guardians of Light
addappid(2383180)
addappid(2383181, 1, "9251b66881b33eaff0c91ab0d021b210d524cfb1d2d47744870ec1e1870e377f")
