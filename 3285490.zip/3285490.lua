-- Lua provided by RyzenAPI
-- Game: 3285490

-- MAIN APPLICATION
addappid(3285490)
-- Game: addappid(3285490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285492,0,"068430043616fc55e894bf7e516ac891fbdeab9a7dd421bc76f9572e499cc935")
