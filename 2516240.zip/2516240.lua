-- Lua provided by RyzenAPI
-- Game: Save the Dungeon!

-- MAIN APPLICATION
addappid(2516240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516241, 1, "8ad2d897647c8f3bde164d1103b8a18798b8af50173ab89afeb359f0afab9b8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
