-- Lua provided by RyzenAPI
-- Game: Save the Dungeon!

-- MAIN APPLICATION
addappid(2516240)
-- Game: addappid(2516240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516241, 1, "8ad2d897647c8f3bde164d1103b8a18798b8af50173ab89afeb359f0afab9b8a")
