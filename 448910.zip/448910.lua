-- Lua provided by RyzenAPI
-- Game: Axes and Acres

-- MAIN APPLICATION
addappid(448910)

-- MAIN APP DEPOTS / PACKAGES
addappid(448911, 1, "fb839ab641d1b7c8cdab95ba6a65e454daabbf7bf9c1abf483dd92fc751bda9c")

