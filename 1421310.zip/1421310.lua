-- Lua provided by RyzenAPI
-- Game: Secret of Harrow Manor 2

-- MAIN APPLICATION
addappid(1421310)
-- Game: addappid(1421310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421311, 1, "c0ca38b9096be2d743db6dde5e5551d72ae0d733082396d561e9c76c42415ced")
