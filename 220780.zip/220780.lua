-- Lua provided by RyzenAPI
-- Game: Game: Thomas Was Alone

-- MAIN APPLICATION
addappid(220780)
-- Game: addappid(220780)

-- MAIN APP DEPOTS / PACKAGES
addappid(220781, 1, "a77467feedbe9b39c8507a3374195b416f3f9851ca10b2c0f49a23b934b71cf0")
addappid(220782, 1, "0dcd7561ab036f479608b13c9f3072ffa81c9858b13bba0c0611e35d6c739967")
addappid(220783, 1, "521645042d7bf741a77314306093afdb79b862c2dabb20c365b49ffc214192e4")
