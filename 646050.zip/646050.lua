-- Lua provided by RyzenAPI
-- Game: Past Cure

-- MAIN APPLICATION
addappid(646050)

-- MAIN APP DEPOTS / PACKAGES
addappid(646052,0,"054a604ad21ece98062b0b61d4d35a34b0aeb5dbc808015da6cd9d67346fbad6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(898230)
