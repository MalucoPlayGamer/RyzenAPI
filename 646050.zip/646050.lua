-- Lua provided by RyzenAPI
-- Game: Past Cure

-- MAIN APPLICATION
addappid(646050)

-- MAIN APP DEPOTS / PACKAGES
addappid(646052,0,"054a604ad21ece98062b0b61d4d35a34b0aeb5dbc808015da6cd9d67346fbad6")

