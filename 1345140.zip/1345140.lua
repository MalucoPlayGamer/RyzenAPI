-- Lua provided by RyzenAPI
-- Game: Claw Crane Company

-- MAIN APPLICATION
addappid(1345140)
-- Game: addappid(1345140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345141, 1, "39e66d3854949e9d839390968e5a767a0bb3ff06e7fa2a10693473a736818832")
