-- Lua provided by RyzenAPI 
-- Game: Those Who Rule
addappid(1822060)
addappid(1822061, 1, "a10baea0b4c1a2cba826d80b3fdcc88a8a38e9700cab983a4f8d30d55100d8b5")
