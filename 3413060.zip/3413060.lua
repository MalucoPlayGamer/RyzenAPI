-- Lua provided by RyzenAPI 
-- Game: The Anomaly Experiment
addappid(3413060)
addappid(3413061, 1, "6565c1af9751c977d6a2ea073717ff6ce810851e6b3654caf7afa5f9c6993518")
