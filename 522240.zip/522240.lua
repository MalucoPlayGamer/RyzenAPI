-- Lua provided by RyzenAPI 
-- Game: Pool Panic
addappid(522240)
addappid(522241, 1, "7e8b4ceeb54656fcf4f60d5444831ddff3023b75111b9f56fae750e4e256c1bd")
