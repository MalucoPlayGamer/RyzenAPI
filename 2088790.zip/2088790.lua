-- Lua provided by RyzenAPI
-- Game: Game: The Big Con Soundtrack and Artbook

-- MAIN APPLICATION
addappid(2088790)
-- Game: addappid(2088790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088791, 1, "e1aefbf1824919e143ee1a83dad751a75e900a1c1efbf187d66f5d3cf50e5a32")
