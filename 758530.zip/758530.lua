-- Lua provided by RyzenAPI
-- Game: Sprout

-- MAIN APPLICATION
addappid(758530)

