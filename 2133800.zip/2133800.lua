-- Lua provided by RyzenAPI
-- Game: addappid(2133800)

-- MAIN APPLICATION
addappid(2133800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133801, 1, "d67e1517b023a50e7a11212e87bbe04f17f1847f8bc5e3794b5e65cb821ac939")
