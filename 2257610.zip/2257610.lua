-- Lua provided by RyzenAPI
-- Game: Game: A Moment of Bliss

-- MAIN APPLICATION
addappid(2257610)
-- Game: addappid(2257610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257611, 1, "2ad01e79465d8e0036cc196fb1b4c0f7739abbfc0d5c4c96b739e1b691a494b0")
