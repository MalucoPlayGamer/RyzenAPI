-- Lua provided by RyzenAPI
-- Game: Man of Law | Judge simulator

-- MAIN APPLICATION
addappid(694440)

-- MAIN APP DEPOTS / PACKAGES
addappid(694441,0,"e49dbd9fc68b7b0ff5f7d9bd1fbe1a11bef54954a1b30635730b29045c6e8b43")
addappid(694442,0,"9cfc8d2fcb5439fb54aadd32aa57a624ccdba5807e33ef9c2f7b1b2a0611e314")
addappid(694443,0,"a978b9e4722286cb34b62292739c753679150078f57d6e81610c2caaea6039c2")
addappid(694444,0,"dfd47b6d19b4a853dd003aab643abd6c0c0486ff9a235a74a41f6f405f5712d4")

