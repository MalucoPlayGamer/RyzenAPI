-- Lua provided by RyzenAPI
-- Game: Halloween Memory: Reborn

-- MAIN APPLICATION
addappid(1744420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744421, 1, "055a5d587d2c006687874ff469f9c198e02b38e1f13d521b4dc7c28e3e6bba75")
