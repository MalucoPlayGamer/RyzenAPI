-- Lua provided by RyzenAPI
-- Game: 孤高之人

-- MAIN APPLICATION
addappid(2568640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2568641, 1, "8578320ab27ff1bead9364bf401e55ebb5b6695be0c3cbef5cf15144dc223787")

