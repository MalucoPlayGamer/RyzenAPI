-- Lua provided by RyzenAPI
-- Game: Game: 孤高之人

-- MAIN APPLICATION
addappid(2568640)
-- Game: addappid(2568640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568641, 1, "8578320ab27ff1bead9364bf401e55ebb5b6695be0c3cbef5cf15144dc223787")
