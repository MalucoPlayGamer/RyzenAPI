-- Lua provided by RyzenAPI
-- Game: 2413590

-- MAIN APPLICATION
addappid(2413590)
-- Game: addappid(2413590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413591, 1, "d4fce77ed75313d4d1101e6c44153bfe2a87abc81333c8baa007d7490a7859b6")
