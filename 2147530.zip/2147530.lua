-- Lua provided by SkyAPI 
-- Game: Raining Blood: Hellfire
addappid(2147530)
addappid(2147531, 1, "fb31e66f583fb6609b0587b988db6c21f560cf9e7efd00abf3446ce0bc80eede")
