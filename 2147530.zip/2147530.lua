-- Lua provided by RyzenAPI
-- Game: Raining Blood: Hellfire

-- MAIN APPLICATION
addappid(2147530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2147531, 1, "fb31e66f583fb6609b0587b988db6c21f560cf9e7efd00abf3446ce0bc80eede")

