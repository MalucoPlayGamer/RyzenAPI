-- Lua provided by RyzenAPI
-- Game: Game: Raining Blood: Hellfire

-- MAIN APPLICATION
addappid(2147530)
-- Game: addappid(2147530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147531, 1, "fb31e66f583fb6609b0587b988db6c21f560cf9e7efd00abf3446ce0bc80eede")
