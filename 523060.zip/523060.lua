-- Lua provided by RyzenAPI
-- Game: Planet Smasher

-- MAIN APPLICATION
addappid(523060)

-- MAIN APP DEPOTS / PACKAGES
addappid(523061, 1, "5179c16f8e0cb9794be939d587baad2341bc92312235806d8c19ce63e8026605")

