-- Lua provided by RyzenAPI 
-- Game: AppID 523060
addappid(523060)
addappid(523061, 1, "5179c16f8e0cb9794be939d587baad2341bc92312235806d8c19ce63e8026605")
