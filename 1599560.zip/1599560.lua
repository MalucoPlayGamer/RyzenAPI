-- Lua provided by RyzenAPI
-- Game: Wanderer

-- MAIN APPLICATION
addappid(1599560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599561, 1, "8ffebe0202faef6fed9833812f4700cddce17b5bbeac700897dbfea41f6c7798")
addappid(1961910, 0, "d0ccf614d65350583246cd807b200c928fde641a722a67b7537ade6cb74221e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2014150)
