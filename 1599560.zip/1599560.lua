-- Lua provided by RyzenAPI 
-- Game: Wanderer
addappid(1599560)
addappid(1599561, 1, "8ffebe0202faef6fed9833812f4700cddce17b5bbeac700897dbfea41f6c7798")
addappid(1961910, 0, "d0ccf614d65350583246cd807b200c928fde641a722a67b7537ade6cb74221e9")
