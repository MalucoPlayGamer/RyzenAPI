-- Lua provided by RyzenAPI 
-- Game: LABJAMS - Official BoneLab OST
addappid(2165980)
addappid(2165981, 1, "7732dd91ead3da826de61f387cdc1581e8117bfd8b3250788825bc29a537095a")
addappid(2165982, 1, "3ba6c381538967c836962d0deb855e8d63d3f63556ba2f9291942fa89294229b")
