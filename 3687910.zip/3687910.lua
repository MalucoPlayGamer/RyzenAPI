-- Lua provided by RyzenAPI
-- Game: In The Dark

-- MAIN APPLICATION
addappid(3687910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3687911, 1, "6cec68366524a4b30541b777115e1693689b09450b8eab494b3570d6b982375c")

