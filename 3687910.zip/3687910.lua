-- Lua provided by RyzenAPI
-- Game: In The Dark

-- MAIN APPLICATION
addappid(3687910)
-- Game: addappid(3687910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3687911, 1, "6cec68366524a4b30541b777115e1693689b09450b8eab494b3570d6b982375c")
