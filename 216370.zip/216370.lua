-- Lua provided by RyzenAPI
-- Game: AppID 216370

-- MAIN APPLICATION
addappid(216370)
-- Game: addappid(216370)

-- MAIN APP DEPOTS / PACKAGES
addappid(216371, 1, "166eb7646bff14e876c4e85be66d2729a0654d4f24dd90b91a3aec09be58531a")
