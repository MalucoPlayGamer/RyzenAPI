-- Lua provided by RyzenAPI 
-- Game: AppID 216370
addappid(216370)
addappid(216371, 1, "166eb7646bff14e876c4e85be66d2729a0654d4f24dd90b91a3aec09be58531a")
