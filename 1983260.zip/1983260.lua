-- Lua provided by RyzenAPI
-- Game: Dungeons of Hinterberg

-- MAIN APPLICATION
addappid(1983260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1983261, 1, "2724a2dda83865f53e04a7135efa955f0ac72fdde362d72124a0e2235d945287")
addappid(1983262, 1, "700ea54ca24fc7e1114e844f7d93cb7edaa902c7df62a7dcf76fd199be1933b2")
addappid(1983263, 1, "f7fabea326e8d067c8ed415623c6962450f3313881142119ca3567641a340792")
addappid(3066600, 0, "fe8fa492e94b143f16282b0ee96166e5836e398ca685eac8820c8b1058afd989")

