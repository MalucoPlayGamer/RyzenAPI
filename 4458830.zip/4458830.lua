-- Lua provided by RyzenAPI
-- Game: Hypnophobia; From Your Shadow

-- MAIN APPLICATION
addappid(4458830)
