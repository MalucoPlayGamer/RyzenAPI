-- Lua provided by RyzenAPI
-- Game: Game: Everyday Life in Hospital VR DEMO

-- MAIN APPLICATION
addappid(1789040)
-- Game: addappid(1789040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789041, 1, "44e130f88028ac92e56c73fb7c2e4a5897d72af78a781f4cddb004bc5eb95b17")
