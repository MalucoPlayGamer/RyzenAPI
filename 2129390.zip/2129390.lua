-- Lua provided by SkyAPI 
-- Game: CATAIRE - Gambling with cats
addappid(2129390)
addappid(2129391, 1, "abc1b106dd32cc3a85cf92bc03c94432266f4e9dfba5bb27187f7f6075d3f667")
addappid(2129392, 1, "d5c5b8c28ca29dd14d7e6bc36147d7239a2237022b511791101563470334886a")
