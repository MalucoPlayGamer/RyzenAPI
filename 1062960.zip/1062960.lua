-- Lua provided by RyzenAPI
-- Game: Under the Sand REDUX - a road trip simulator

-- MAIN APPLICATION
addappid(1062960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062961, 1, "3f0e2e3915ddb9229ca249dc16ea8adf8de6151ab8cf518d79c47081a91e6e44")
addappid(1062962, 1, "989d21b0f93b1ddd79d230d1de15813a52063f0bbc554b0266534b54d5a36c4e")
