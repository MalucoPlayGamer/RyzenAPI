-- Lua provided by RyzenAPI
-- Game: Game: WHAT THE BAT?

-- MAIN APPLICATION
addappid(2012100)
-- Game: addappid(2012100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012101, 1, "6dfa9fefe1db86d58d02fda1874aa913c5d2017769c11f3d511647dc3984df3e")
