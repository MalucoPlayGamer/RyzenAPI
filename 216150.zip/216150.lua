-- Lua provided by RyzenAPI 
-- Game: MapleStory
addappid(216150)
addappid(216151, 1, "45ce0d0da6dd16d67482cc76298dd320ecdd9160df7a27a570fbfc8f028b2333")
