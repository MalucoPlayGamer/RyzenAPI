-- Lua provided by RyzenAPI
-- Game: MapleStory

-- MAIN APPLICATION
addappid(216150)
addappid(216153)
addappid(573510)
addappid(573511)
addappid(573512)
addappid(573513)

-- MAIN APP DEPOTS / PACKAGES
addappid(216151, 1, "45ce0d0da6dd16d67482cc76298dd320ecdd9160df7a27a570fbfc8f028b2333")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

