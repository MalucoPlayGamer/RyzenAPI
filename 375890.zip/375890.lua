-- Lua provided by RyzenAPI
-- Game: addappid(375890)

-- MAIN APPLICATION
addappid(375890)

-- MAIN APP DEPOTS / PACKAGES
addappid(375891, 1, "444785c2ac982152cc845dc9ce096cb6b938b56e62028db2ccd22e7039582511")
