-- Lua provided by SkyAPI 
-- Game: Five Nights at Restroom 2
addappid(3184460)
addappid(3184461, 1, "a4afd4fb1c5b6ac882043d820d5b18dfbe767b9863899abd4ba4048bc03a1996")
addappid(3184760, 0, "3242085fa1b7d65f9251040ba1498709e06c7e1dc8c4e7d30f10e49b6f565dd8")
addappid(3431940, 0, "7ecc1784aa8902e88ae28af7a8ac76720550cb34095f684959f1a7f7b522a6a0")
