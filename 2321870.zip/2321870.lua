-- Lua provided by RyzenAPI
-- Game: Lawnmower Game: Zombies

-- MAIN APPLICATION
addappid(2321870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321871, 1, "1f6547bbe705f0175a8a4dd730ee44fc7c3e0a346934aa4a6dbe720b41ebd8f1")

