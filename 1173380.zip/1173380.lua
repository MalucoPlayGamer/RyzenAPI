-- Lua provided by RyzenAPI
-- Game: addappid(1173380)

-- MAIN APPLICATION
addappid(1173380)
addappid(1421460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173381, 1, "6712a3322d07bd0849a8bcd347cb29ff2c27bb1423e704c229b315f6cf9472e9")
