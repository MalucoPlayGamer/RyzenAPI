-- Lua provided by RyzenAPI
-- Game: Doctor Who: The Edge of Reality

-- MAIN APPLICATION
addappid(1444920)
addappid(1775070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444921, 1, "44acc710058ac6afe990270dd63083e4f008b47646ac9272d3c924b7c94d594f")

