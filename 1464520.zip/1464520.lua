-- Lua provided by RyzenAPI
-- Game: Game: Blewie

-- MAIN APPLICATION
addappid(1464520)
-- Game: addappid(1464520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464521, 1, "248e4586d6180e7768dbd930b1e2dc0a3c97f24e8908c9148b7571633f1ca646")
