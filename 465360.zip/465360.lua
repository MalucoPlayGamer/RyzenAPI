-- Lua provided by RyzenAPI
-- Game: Uprising: Join or Die

-- MAIN APPLICATION
addappid(465360)

-- MAIN APP DEPOTS / PACKAGES
addappid(465361, 1, "89b78e2450c2d527657fe0778617f54a3ffc0a84ceec8979d1da1a4053fda12e")

