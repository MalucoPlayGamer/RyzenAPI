-- Lua provided by RyzenAPI
-- Game: Golden Warden Original Soundtrack

-- MAIN APPLICATION
addappid(3348700)
-- Game: addappid(3348700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3348701, 1, "f079c01d671b914510f41428ed768a1259523c0786d6f06de1823c165be32a00")
addappid(3348702, 1, "75530c06f3be6a59993bf3ea1569ff329733801a3989713938dafab54076778f")
