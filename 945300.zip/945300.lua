-- Lua provided by RyzenAPI
-- Game: AppID 945300

-- MAIN APPLICATION
addappid(945300)
-- Game: addappid(945300)

-- MAIN APP DEPOTS / PACKAGES
addappid(945301, 1, "a69100dbc6bd65772bee1ecd8f8ff8757f9fa970bf7259bb7406aed0596ae827")
