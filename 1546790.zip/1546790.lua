-- Lua provided by RyzenAPI
-- Game: Peace, Death! 2

-- MAIN APPLICATION
addappid(1546790)
addappid(1757530)
-- Game: addappid(1546790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546791, 1, "5c76a86fa94d36f3f77c5d98e348c6b21068f8234570e2769dc47aab4c68dec3")
