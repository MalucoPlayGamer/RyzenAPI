-- Lua provided by RyzenAPI
-- Game: Peace, Death! 2

-- MAIN APPLICATION
addappid(1546790)
addappid(1757530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546791, 1, "5c76a86fa94d36f3f77c5d98e348c6b21068f8234570e2769dc47aab4c68dec3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
