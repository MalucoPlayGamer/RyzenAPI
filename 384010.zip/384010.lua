-- Lua provided by RyzenAPI 
-- Game: Castles
addappid(384010)
addappid(384011, 1, "34e65cb3186da7928792e8a3a5c781619d8b8ddd92f0e6baaaaec5f57982d047")
addappid(384012, 1, "fbf9d3d1dd479afdbb04e22274223095d93e08692caece913e540c1aca398827")
addappid(384013, 1, "73b5d6d53c24bf96e7d226d8dc7f17cf5a6d961bcb8ae1c73cacb4bb3460a1e5")
addappid(384014, 1, "5a961c6e4f73d58e608f1c5df5ed4a4c28797fa2b02a904ce3ae2b8b729ce699")
