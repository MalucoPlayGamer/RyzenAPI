-- Lua provided by RyzenAPI
-- Game: Game: Kinky Cosplay Heroes

-- MAIN APPLICATION
addappid(2672510)
-- Game: addappid(2672510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672511, 1, "b3966858900b0e002a4224dc76149db3b8e6014c8548a5fbb25d60e793c631ef")
