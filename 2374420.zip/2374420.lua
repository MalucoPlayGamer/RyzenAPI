-- Lua provided by RyzenAPI
-- Game: 100 Steps

-- MAIN APPLICATION
addappid(2374420)
-- Game: addappid(2374420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374421, 1, "6284b1fbd75998887c51436e4a9046ba61c2a1432c9524b95d262efc5e60443b")
