-- Lua provided by SkyAPI 
-- Game: 100 Steps
addappid(2374420)
addappid(2374421, 1, "6284b1fbd75998887c51436e4a9046ba61c2a1432c9524b95d262efc5e60443b")
