-- Lua provided by RyzenAPI
-- Game: 西游记2021

-- MAIN APPLICATION
addappid(1742450)
-- Game: addappid(1742450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742451, 1, "105341390bdd3b6913015e27b786168b3dabee166cfdfa9754f0dfe71f35c45e")
