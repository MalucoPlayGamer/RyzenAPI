-- Lua provided by RyzenAPI
-- Game: SUPER BOMBERMAN COLLECTION

-- MAIN APPLICATION
addappid(3756010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3756011,0,"1d444f9339cc4e776127c190e7f8f474736a99e2e72768f78fccc1aeb8f8004e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
