-- Lua provided by RyzenAPI
-- Game: waxweaver

-- MAIN APPLICATION
addappid(3599070)
