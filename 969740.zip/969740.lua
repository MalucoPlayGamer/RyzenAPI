-- Lua provided by RyzenAPI
-- Game: addappid(969740)

-- MAIN APPLICATION
addappid(969740)

-- MAIN APP DEPOTS / PACKAGES
addappid(969741, 1, "070ca1eb1e3534e520717e0577cf1551aa4a59f80b56cf97091e23fa06fd23ef")
