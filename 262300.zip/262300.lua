-- Lua provided by RyzenAPI
-- Game: Tsukumogami

-- MAIN APPLICATION
addappid(262300)

-- MAIN APP DEPOTS / PACKAGES
addappid(262301, 1, "7df7e284a9573553d34ab928bb5e49319a53bdf8ee0dfd12fe9f06f10c8691c6")
