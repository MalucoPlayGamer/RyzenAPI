-- Lua provided by RyzenAPI
-- Game: Pocket Rogues

-- MAIN APPLICATION
addappid(946610)
-- Game: addappid(946610)

-- MAIN APP DEPOTS / PACKAGES
addappid(946611, 1, "44050fc17a2a1d0e74da964eb0d9fcf65e3f7a1bd1500ba09a6d51e6a49ead5e")
