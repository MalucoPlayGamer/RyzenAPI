-- Lua provided by RyzenAPI
-- Game: 2236 A.D. Secretary Stories

-- MAIN APPLICATION
addappid(1627520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627521, 1, "755e995193652f551f150f5dc720007d8a6970905ef59298f98dec73807feb26")
addappid(1627522, 1, "3caf417b3aceb724010a4e324d1844b76b62e19a52cdbbb90bc39b848c0b7e1a")

