-- Lua provided by RyzenAPI
-- Game: addappid(2554000)

-- MAIN APPLICATION
addappid(2554000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554001, 1, "3bb8ff245a6fe01e556bc3957d5ee0d59e63175a9cc80797a948d9a23ffe1f92")
