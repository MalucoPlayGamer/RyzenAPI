-- Lua provided by RyzenAPI
-- Game: AppID 899770

-- MAIN APPLICATION
addappid(899770)
addappid(2303580)
addappid(2303581)
addappid(2303582)
addappid(2303583)
addappid(2744750)
addappid(2744760)
addappid(2744770)
addappid(2744780)
addappid(2744790)
addappid(2744800)
addappid(2744810)
addappid(2744820)
addappid(2744830)
addappid(2768230)
addappid(3080440)
addappid(3080450)
addappid(3080460)
addappid(3080470)
addappid(3512570)
addappid(3512580)
addappid(3512590)
addappid(3512600)
addappid(3865720)
addappid(3865730)
addappid(3865740)
addappid(3865750)

-- MAIN APP DEPOTS / PACKAGES
addappid(899771, 1, "c2e2078a202c652383c595f86a2661e2c0bf747e070ab942890d958aaecb06d9")
addappid(2768220, 0, "d15b6fec494066fa9ecfbd19f48042c6db781c7db9336752a23b066d645c1607")

