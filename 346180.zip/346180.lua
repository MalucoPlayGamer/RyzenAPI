-- Lua provided by RyzenAPI
-- Game: Game: AppID 346180

-- MAIN APPLICATION
addappid(346180)
-- Game: addappid(346180)

-- MAIN APP DEPOTS / PACKAGES
addappid(346181, 1, "66949f0744d60a8051b0b2768c5f8d488be1710642264cc72eb7ccc5e63b1e22")
