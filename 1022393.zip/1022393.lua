-- Lua provided by RyzenAPI
-- Game: DFF NT: Wedding Gown Appearance Set for Yuna

-- MAIN APPLICATION
addappid(1022393)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022393,0,"a9ac1e0707def69f1bc9d1b59ab1742a1a03f6369a9264a3647641260d248a1d")

