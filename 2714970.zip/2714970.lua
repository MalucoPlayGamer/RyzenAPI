-- Lua provided by RyzenAPI
-- Game: Backrooms Media

-- MAIN APPLICATION
addappid(2714970)
-- Game: addappid(2714970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714971, 1, "ab4bc4223396ff5d6b91856b16a2f239cf1ca363f100362049154f2b54d3e3a7")
