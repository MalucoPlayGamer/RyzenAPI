-- Lua provided by RyzenAPI
-- Game: Game: BMX Bastards

-- MAIN APPLICATION
addappid(2563760)
-- Game: addappid(2563760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563761, 1, "8b08639d48243075627c3a67336803861405ee66784880fa8c21083f7ff5aaf6")
