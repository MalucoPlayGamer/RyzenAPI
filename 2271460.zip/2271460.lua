-- Lua provided by RyzenAPI
-- Game: 2271460

-- MAIN APPLICATION
addappid(2271460)
-- Game: addappid(2271460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271461, 1, "019c01526ae7fc43f124976b905f23a3c8d99e02e7d42eb3157aab1937c9b825")
