-- Lua provided by SkyAPI 
-- Game: AppID 2271460
addappid(2271460)
addappid(2271461, 1, "019c01526ae7fc43f124976b905f23a3c8d99e02e7d42eb3157aab1937c9b825")
