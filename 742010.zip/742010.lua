-- Lua provided by RyzenAPI
-- Game: Lab 03 Yrinth

-- MAIN APPLICATION
addappid(742010)

-- MAIN APP DEPOTS / PACKAGES
addappid(742011, 1, "9d133a25fd62ea4f2f23012414ce190790a26de5414034c7b50093a954dd9bd4")
addappid(742012, 1, "68f41afecc117abdfcdf01db502a30bc67e5d8f1dee020eb1d6f06f305b94726")
addappid(742013, 1, "6b50c50d18e0d1c185c6a9fa1ac60e65affff7758bbf50dfd3885bc532c90407")
addappid(742014, 1, "6178af97cee46c6e91350a018c253fb39e4c3c615ade0eb49d146673e825c0b2")
addappid(742016, 1, "a5a011dc6c4243c5b811573e6587a53f7b65d6b501d959823d24b18fa68471c5")
addappid(742017, 1, "d27b976e720cd5bb61e16f2ec64f49c805245c8e1923724dee9fda7ba9c7b62d")
addappid(742018, 1, "16f0efbea0a69158b4f606fec2b0b596ec6254a154610c6f8a8f905abd91723f")
addappid(742020, 1, "7edbb41362ed85e8ed4dfb2f8b6bee4f6562fa207f97efdc40013426ad3fe011")
addappid(749230, 0, "51a3cbe2fdad5bb6389bb21409138fceb61f80ef208683366eb1b4a8855fd5b1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(742021)
addappid(747420)
