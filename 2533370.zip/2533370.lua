-- Lua provided by RyzenAPI
-- Game: Heads Up! Phones Down Edition

-- MAIN APPLICATION
addappid(2533370)
-- Game: addappid(2533370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533371, 1, "4f283d1e06ad2d74eafe2dd8f3a2e136810c1eeb48f68ad1c0f92675ac7e8d56")
