-- Lua provided by RyzenAPI
-- Game: Mech Engineer

-- MAIN APPLICATION
addappid(1428520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428521, 1, "280fd485852fbab3a36add81276306fde37e6462b727dbed45bcfec1545ed030")
