-- Lua provided by RyzenAPI
-- Game: Tsugunohi -Pocky dog’s adventure-

-- MAIN APPLICATION
addappid(2947210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947212,0,"6d8c5087e263ab0d53b8df1e38c600197f7af4e75fa45ce946852c1780c0be17")
addappid(2947213,0,"cbae01e8d8458e90770326d250d3ba5ca91a328e5e38e9c6695e12ae10c5e09b")
addappid(2947214,0,"4ea32668882fceb89454a6faf90357dd749f8c346927dad9628e7a8d0bffd832")

