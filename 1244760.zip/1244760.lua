-- Lua provided by RyzenAPI
-- Game: 美少女格斗学院／Beautiful Girl Fight School

-- MAIN APPLICATION
addappid(1244760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244761, 1, "0c01ed27015ff1b84d747a04d3985dbff7559219da48146a8158cb70785f8010")

