-- Lua provided by RyzenAPI
-- Game: Eye in the Sky

-- MAIN APPLICATION
addappid(566700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(566701,0,"c1d4f7028af476ceacddea4b3b81b2d671db35dbfb84adb39dbafa15aa8129b7")
addappid(566702,0,"2031a67eee49c2d7b2664b5f5e235c35e92319a6c6d327abb6dcb9fb653aa13c")

