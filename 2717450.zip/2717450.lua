-- Lua provided by RyzenAPI
-- Game: Museum Mystery: Deckbuilding Card Game

-- MAIN APPLICATION
addappid(2717450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717451, 1, "29123a5dbaa6d3dd575b90f76fde6b55f6ea4bf6a67eca254cd0fcf6149d6ee1")

