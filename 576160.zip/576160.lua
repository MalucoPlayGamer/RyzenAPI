-- Lua provided by RyzenAPI
-- Game: A Long Road Home

-- MAIN APPLICATION
addappid(576160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(576161, 1, "f120576067c4b05fb9888ca818bd95fd27cdd3d0da5bf8712cd0b896c22ef3b3")
