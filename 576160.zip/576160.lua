-- Lua provided by RyzenAPI
-- Game: Game: AppID 576160

-- MAIN APPLICATION
addappid(576160)
-- Game: addappid(576160)

-- MAIN APP DEPOTS / PACKAGES
addappid(576161, 1, "f120576067c4b05fb9888ca818bd95fd27cdd3d0da5bf8712cd0b896c22ef3b3")
