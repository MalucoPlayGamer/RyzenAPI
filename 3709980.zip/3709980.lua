-- Lua provided by RyzenAPI
-- Game: 3709980

-- MAIN APPLICATION
addappid(3709980)
-- Game: addappid(3709980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709981, 1, "02e5d644ffb6380c74180523dc23a16f1cad6cfbb6ac15cb35b252dcbfc5c13e")
