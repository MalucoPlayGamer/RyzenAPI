-- Lua provided by RyzenAPI
-- Game: Polygon Attack

-- MAIN APPLICATION
addappid(529900)

-- MAIN APP DEPOTS / PACKAGES
addappid(529901, 1, "b61e1e9716474c561d0f09b94d9a4ab8044c4271c845722f0e74089819ab25e9")
addappid(529902, 1, "7ff3b6b3cd01dea15c363058fd80e4b80bf08a7878827437d9ef89e285ec4504")
addappid(639080, 0, "9655c82bed260bbf27cb5b681f0de6ab22cc0b1705282217b206527a7928f287")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
