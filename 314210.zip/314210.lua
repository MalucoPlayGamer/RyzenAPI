-- Lua provided by RyzenAPI
-- Game: Tesla Breaks the World!

-- MAIN APPLICATION
addappid(314210)
-- Game: addappid(314210)

-- MAIN APP DEPOTS / PACKAGES
addappid(314211, 1, "8d2a13c6174f6a8f36aecc44c148a47cd806074f91483691ac5ab71b1c30b66f")
addappid(314213, 1, "5ed29ac2f2549271deecfe238fe073e04d6bca9b54db2047d2ba465df5bb8148")
addappid(314214, 1, "ea5784fe6aa811f4c85338945927413678e98f1bd3bc88852476ff297ccde59e")
addappid(334990, 0, "2cc64cb935add5f61a2cd65f57d7bdee110596b0aa121749b53d4cbbce39ef5d")
