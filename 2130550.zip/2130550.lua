-- Lua provided by RyzenAPI
-- Game: Game: LET ME OUT

-- MAIN APPLICATION
addappid(2130550)
-- Game: addappid(2130550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130551, 1, "3e6586c884f518c0bf81f37568eddb61d85ec8bc12fcb7326f05c49747fa7beb")
