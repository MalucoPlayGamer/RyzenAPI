-- Lua provided by SkyAPI 
-- Game: LET ME OUT
addappid(2130550)
addappid(2130551, 1, "3e6586c884f518c0bf81f37568eddb61d85ec8bc12fcb7326f05c49747fa7beb")
