-- Lua provided by RyzenAPI
-- Game: 806790

-- MAIN APPLICATION
addappid(806790)
-- Game: addappid(806790)

-- MAIN APP DEPOTS / PACKAGES
addappid(806791, 1, "510175fc81468da8105fbfa59b050ebcea36494f2b4116a77f9e1289459c95f5")
