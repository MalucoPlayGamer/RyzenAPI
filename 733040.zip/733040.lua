-- Lua provided by RyzenAPI
-- Game: Cube Defender 2000

-- MAIN APPLICATION
addappid(733040)

-- MAIN APP DEPOTS / PACKAGES
addappid(733041, 1, "f13d5428532926378dee6d036ea76b6e43dad6de34001e9177cb12c49155087b")

