-- Lua provided by RyzenAPI
-- Game: Game: AppID 1406810

-- MAIN APPLICATION
addappid(1406810)
-- Game: addappid(1406810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406811, 1, "6850bc050630a6b33c8fcb36eb6fc670971cf782986eef134b92a28cb17c9fd6")
