-- Lua provided by RyzenAPI
-- Game: 933536

-- MAIN APPLICATION
addappid(933536)
-- Game: addappid(933536)

-- MAIN APP DEPOTS / PACKAGES
addappid(933536,0,"13d2ff1c48957306f40353e0035b5d1fc44b0baba4565e77068a3f42fc9b3a7e")
