-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Shu Pack 2

-- MAIN APPLICATION
addappid(933536)

-- MAIN APP DEPOTS / PACKAGES
addappid(933536,0,"13d2ff1c48957306f40353e0035b5d1fc44b0baba4565e77068a3f42fc9b3a7e")

