-- Lua provided by RyzenAPI
-- Game: The Scream

-- MAIN APPLICATION
addappid(1097120)
-- Game: addappid(1097120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097121, 1, "af320bc432c0738df08e732e90396dedd85119690455ce4373112003570842fb")
