-- Lua provided by RyzenAPI
-- Game: The Scream

-- MAIN APPLICATION
addappid(1097120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097121, 1, "af320bc432c0738df08e732e90396dedd85119690455ce4373112003570842fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
