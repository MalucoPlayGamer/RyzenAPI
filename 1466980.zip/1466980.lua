-- Lua provided by SkyAPI 
-- Game: Project DeepWeb: Artbook
addappid(1466980)
addappid(1466981, 1, "4a2bdca282438e71218eb4d09ccb6503ac77d130bf3f5d74ed74ef68a2aacc7a")
