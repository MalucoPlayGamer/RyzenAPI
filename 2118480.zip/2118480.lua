-- Lua provided by RyzenAPI 
-- Game: Vengeful Guardian Moonrider Demo
addappid(2118480)
addappid(2118481, 1, "6d82303dbd93ac5cbf94f8d20149b8ed896df5c346602551a833adcfc4b5f2d5")
