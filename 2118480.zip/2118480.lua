-- Lua provided by RyzenAPI
-- Game: 2118480

-- MAIN APPLICATION
addappid(2118480)
-- Game: addappid(2118480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118481, 1, "6d82303dbd93ac5cbf94f8d20149b8ed896df5c346602551a833adcfc4b5f2d5")
