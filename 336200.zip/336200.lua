-- Lua provided by RyzenAPI
-- Game: Starlaxis Supernova Edition

-- MAIN APPLICATION
addappid(336200)

-- MAIN APP DEPOTS / PACKAGES
addappid(336201, 1, "1afcabd743eca12a171be41b09edf298c68fd1187369599c237449939442b9c3")
addappid(336202, 1, "097c41418280c456ba82edf7045e56831fe2bbe4c8905b28f287862c585ec281")

