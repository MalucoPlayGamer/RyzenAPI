-- Lua provided by RyzenAPI
-- Game: 1245470

-- MAIN APPLICATION
addappid(1245470)
-- Game: addappid(1245470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245471, 1, "1df1f1d303f7b4f508679a665a305e87e23ac6bec84945c7e08ce6d1e28d578f")
