-- Lua provided by RyzenAPI
-- Game: Ultimate Ski Jumping 2020

-- MAIN APPLICATION
addappid(1245470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1245471, 1, "1df1f1d303f7b4f508679a665a305e87e23ac6bec84945c7e08ce6d1e28d578f")

