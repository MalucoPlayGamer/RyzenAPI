-- Lua provided by RyzenAPI
-- Game: addappid(3699090)

-- MAIN APPLICATION
addappid(3699090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699090,0,"78b3704014041b2a4425aab3be126dcef3b3764459cc9c8910eac534cad3a5f3")
