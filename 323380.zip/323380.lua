-- Lua provided by RyzenAPI
-- Game: 323380

-- MAIN APPLICATION
addappid(228990)
addappid(323380)
addappid(323381)
addappid(323382)
addappid(323383)
addappid(323384)
addappid(323385)
addappid(323386)
addappid(323388)
addappid(368910)
-- Game: addappid(323380)

-- MAIN APP DEPOTS / PACKAGES
addappid(323387,0,"e9d425229ce6af7abc58c1c0b4368a04618712a0a081611cbc32e0444075ade1")
