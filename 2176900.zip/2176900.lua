-- Lua provided by RyzenAPI
-- Game: Tales of Fablecraft

-- MAIN APPLICATION
addappid(2176900)

