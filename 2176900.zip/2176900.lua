-- Lua provided by RyzenAPI
-- Game: Tales of Fablecraft

-- MAIN APPLICATION
addappid(2176900)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3248100)
addappid(3281150)
addappid(3281160)
addappid(3281170)
addappid(3469710)
addappid(3469720)
addappid(3871220)
