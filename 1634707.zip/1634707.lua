-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Weapon set 5

-- MAIN APPLICATION
addappid(1634707)
-- Game: addappid(1634707)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634707,0,"50c73d1d3ed009c28a177790f37f846e8d4ed4c5d3e04435faba87bbe25daf9a")
