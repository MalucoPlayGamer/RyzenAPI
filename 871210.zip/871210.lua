-- Lua provided by RyzenAPI
-- Game: Game: Lamp Chronicle

-- MAIN APPLICATION
addappid(871210)
-- Game: addappid(871210)

-- MAIN APP DEPOTS / PACKAGES
addappid(871211, 1, "bb95d73b302c82eb8d64ee34f0f6c2cad01c839e2e49e9d07d2cebd1933ed115")
