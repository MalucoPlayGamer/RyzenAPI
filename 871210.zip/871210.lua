-- Lua provided by RyzenAPI
-- Game: Lamp Chronicle

-- MAIN APPLICATION
addappid(871210)

-- MAIN APP DEPOTS / PACKAGES
addappid(871211, 1, "bb95d73b302c82eb8d64ee34f0f6c2cad01c839e2e49e9d07d2cebd1933ed115")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
