-- Lua provided by RyzenAPI
-- Game: Game: AppID 410210

-- MAIN APPLICATION
addappid(410210)
-- Game: addappid(410210)

-- MAIN APP DEPOTS / PACKAGES
addappid(410211, 1, "914b6d6a90b6788c136f152bc8d6bcc2456cc99534eff2b802a9236defdddef8")
