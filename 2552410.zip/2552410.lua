-- Lua provided by RyzenAPI
-- Game: 2552410

-- MAIN APPLICATION
addappid(2552410)
-- Game: addappid(2552410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552411, 1, "d7fe9fc8ec05dadefe16c35cbccb2e21b3cdb4797a86a9410f7b898777aec557")
