-- Lua provided by RyzenAPI
-- Game: Ary and the Secret of Seasons

-- MAIN APPLICATION
addappid(935570)

-- MAIN APP DEPOTS / PACKAGES
addappid(935571, 1, "c2566dbd2d550852506fcf9aa00979e61ae3592e2276f1c8260252ffc1fb4fb8")

