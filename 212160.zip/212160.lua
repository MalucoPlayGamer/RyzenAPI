-- Lua provided by RyzenAPI
-- Game: AppID 212160

-- MAIN APPLICATION
addappid(212160)
-- Game: addappid(212160)

-- MAIN APP DEPOTS / PACKAGES
addappid(212161, 1, "fd89531b4a3d135c2d2841963aa6a3b9fd54f90fe6f67788e862d92e0ae2df22")
