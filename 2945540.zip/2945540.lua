-- Lua provided by RyzenAPI
-- Game: Another Farm Roguelike: Rebirth Demo

-- MAIN APPLICATION
addappid(2945540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945541, 1, "72627ac7ccb39b43201937056ae924647b932284c64b1301ad263dc8319576b9")
