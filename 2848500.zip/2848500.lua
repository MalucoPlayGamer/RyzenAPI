-- Lua provided by RyzenAPI
-- Game: 2848500

-- MAIN APPLICATION
addappid(2848500)
-- Game: addappid(2848500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848501, 1, "f4e3ad8ba6ad0b8660e82bd4f48d6f9014961c8be27a6035cd55c682708d39c4")
