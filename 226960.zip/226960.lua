-- Lua provided by RyzenAPI 
-- Game: Ironclad Tactics
addappid(226960)
addappid(226961, 1, "45296a3e0e8c132c6cd2d3bb302b1edeb844f8a258ebbdfd51c65075657a4f5f")
addappid(228983)
addappid(229003)
addappid(254620, 0, "4720e2c86391d7bbbdd73e457a1e98a766c722c99ab86defaafcc81591c58c4d")
