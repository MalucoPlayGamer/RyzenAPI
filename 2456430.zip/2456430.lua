-- Lua provided by RyzenAPI
-- Game: Athena Crisis

-- MAIN APPLICATION
addappid(2456430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456433,0,"7bfc8472f32933f27e76036b39c6bc3e90c34b5761b298eca4576c16f8e550d6")

