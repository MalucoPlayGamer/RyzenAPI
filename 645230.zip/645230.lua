-- Lua provided by RyzenAPI
-- Game: Game: RUCKBALL

-- MAIN APPLICATION
addappid(645230)
-- Game: addappid(645230)

-- MAIN APP DEPOTS / PACKAGES
addappid(645231, 1, "e9adbf413943025002698a59f6a733946a8c38e032ddbda3900b71e5d0058281")
