-- Lua provided by RyzenAPI
-- Game: AppID 3362010

-- MAIN APPLICATION
addappid(3362010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362011, 1, "e6c710cd6b8a056e7cfd4085b0bccfad567c297c60c8f74e97f50485ae10e096")
