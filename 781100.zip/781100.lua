-- Lua provided by RyzenAPI
-- Game: Game: Winner Winner Chicken Dinner!

-- MAIN APPLICATION
addappid(781100)
addappid(789230)
-- Game: addappid(781100)

-- MAIN APP DEPOTS / PACKAGES
addappid(781101, 1, "a7ddc81632942f1c63bfeeca21d3c874d3d3773d4ca96d5d087b4b111f8dd02e")
