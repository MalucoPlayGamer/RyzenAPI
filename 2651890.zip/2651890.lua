-- Lua provided by RyzenAPI
-- Game: Star Trek: Infinite - DDE Tracker

-- MAIN APPLICATION
addappid(2651890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651890,0,"489ac5d1cf0d4b78b870e144ad2e2a1e3a3511080c0408e0b0202cfb95d13af5")

