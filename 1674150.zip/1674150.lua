-- Lua provided by SkyAPI 
-- Game: Gromopoli
addappid(1674150)
addappid(1674151, 1, "23f3400a7492a6b30f5dc4d1b20ea2745420ff668bbc5e7ac30631328d78221b")
