-- Lua provided by RyzenAPI
-- Game: Way Back Witness

-- MAIN APPLICATION
addappid(1587260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587261, 1, "d7efee0434e658e734a91f4085423a42b9f3f8109e6a652e7ba7263644b23f30")
