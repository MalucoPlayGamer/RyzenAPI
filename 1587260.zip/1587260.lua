-- Lua provided by SkyAPI 
-- Game: Way Back Witness
addappid(1587260)
addappid(1587261, 1, "d7efee0434e658e734a91f4085423a42b9f3f8109e6a652e7ba7263644b23f30")
