-- Lua provided by RyzenAPI
-- Game: addappid(1684162)

-- MAIN APPLICATION
addappid(1684162)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684162,0,"7804af0a422c7f7ccba4d50c7c65391fd036860589b8ae6e88dee48ecc2f163b")
