-- Lua provided by RyzenAPI
-- Game: Anark.io

-- MAIN APPLICATION
addappid(808120)
-- Game: addappid(808120)

-- MAIN APP DEPOTS / PACKAGES
addappid(808121, 1, "875b32599caa1a6d8846c504057bf16c88ccae8d2ad509385a7abf84cba48836")
