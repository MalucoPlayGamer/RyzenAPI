-- Lua provided by RyzenAPI
-- Game: CatTuber

-- MAIN APPLICATION
addappid(1337970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1337971, 1, "2ede2f7f386f1de2bc56cfade95c5e38fd659cd196435b8eb8352db65de172c1")
addappid(1337972, 1, "99dac576d0f45b7665734057eb271ca511f8fd355b39fced89a2e0aeac8f2194")
addappid(1337973, 1, "993033524ce3552f61246e258864e5d7c65605f31989ad37776dd145eab6b047")
addappid(1337974, 1, "b7d7bb28e173d1facdf58ba477f6c07417a7570d7372f4a90e266722d267f822")
addappid(1337975, 1, "fc9bc08e25f46e13d101fb3a8f1c32a075ce113c8bb8dbd337088a6daba524d9")

