-- Lua provided by RyzenAPI
-- Game: AppID 13250

-- MAIN APPLICATION
addappid(13250)
-- Game: addappid(13250)

-- MAIN APP DEPOTS / PACKAGES
addappid(13251, 1, "30de512fe1f57d38b1081a26c95b3f05416e656c19829d147fb4d5998c2a9ead")
