-- Lua provided by RyzenAPI
-- Game: Danganronpa Another Episode: Ultra Despair Girls

-- MAIN APPLICATION
addappid(555950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(555951, 1, "372a12a1d96aa1014642e4fe55b82a77887e22246cf3266402e7096ef3aae5b5")
addappid(555952, 1, "2e9a60957d79f2cc3fbdfcf4b2a852364493e626daef3d3b4f702c24e2d305a0")
addappid(555953, 1, "3d5b471314018f6a9a16c0d4ec7b98ccb93fbe70bbf4626bf43e60c1323ac4cc")
addappid(555954, 1, "021aca3dfcf2206b2a4ed988642fcb09d11eea690e48d4abed4c508493bbfcf3")
