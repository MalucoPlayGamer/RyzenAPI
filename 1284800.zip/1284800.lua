-- Lua provided by RyzenAPI
-- Game: Game: My Strange Girlfriends

-- MAIN APPLICATION
addappid(1284800)
-- Game: addappid(1284800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284801, 1, "412794385a807ba424e37b5f6c3b5b2a5d3c330fde832aa17ae857deb05e1f8b")
