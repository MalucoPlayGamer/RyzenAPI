-- Lua provided by RyzenAPI
-- Game: addappid(895860)

-- MAIN APPLICATION
addappid(895860)

-- MAIN APP DEPOTS / PACKAGES
addappid(895861, 1, "98b4ab87d339b3c7b227723f647c3bf86e4ff64256b85e6c513bb7d50e6163e2")
