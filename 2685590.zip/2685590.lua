-- Lua provided by RyzenAPI
-- Game: TriggerHeart EXELICA

-- MAIN APPLICATION
addappid(2685590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685591, 1, "9a14c975bd0c3dea7c37b8a178e51f414599fbc91c15065b22701ea3c4130093")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
