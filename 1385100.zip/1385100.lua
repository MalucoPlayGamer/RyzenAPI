-- Lua provided by RyzenAPI
-- Game: Insurmountable

-- MAIN APPLICATION
addappid(1385100)
addappid(1906210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385101, 1, "ab7705a87084994d24fe415dd012f3c852d91b0e6efe41ccf032781593fe5d33")

