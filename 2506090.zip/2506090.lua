-- Lua provided by RyzenAPI
-- Game: Twisted Tower Demo

-- MAIN APPLICATION
addappid(2506090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506091, 1, "435c77f1ec71498c868a2a10acd1986cc0572f30cb0d0b3dd0aff477d917a43e")
