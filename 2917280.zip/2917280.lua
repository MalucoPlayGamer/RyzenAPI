-- Lua provided by RyzenAPI
-- Game: Game: Backroom Demo

-- MAIN APPLICATION
addappid(2917280)
-- Game: addappid(2917280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917281, 1, "50d51adb5117db2efd5296f7c23d009db7abe6b6edafc32efda2f2a78e7d1be5")
