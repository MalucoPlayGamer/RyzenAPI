-- Lua provided by RyzenAPI
-- Game: Labyrinth of Galleria: The Moon Society - Tome of Wonders Art Book

-- MAIN APPLICATION
addappid(2253220)
-- Game: addappid(2253220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253220,0,"0715cfb21705b3c3c87af852b8fba9ba568b7ab2dc29cf90740449045c3fec79")
