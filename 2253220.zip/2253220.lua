-- Lua provided by RyzenAPI
-- Game: 2253220

-- MAIN APPLICATION
addappid(2253220)
-- Game: addappid(2253220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253220,0,"0715cfb21705b3c3c87af852b8fba9ba568b7ab2dc29cf90740449045c3fec79")
