-- Lua provided by RyzenAPI
-- Game: Harold

-- MAIN APPLICATION
addappid(338890)

-- MAIN APP DEPOTS / PACKAGES
addappid(338891, 1, "aca80c058aa9a608f0dbd8049337dca3e1404dbd2d80448fba3f38650e49c574")
