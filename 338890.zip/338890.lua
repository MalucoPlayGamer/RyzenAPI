-- Lua provided by RyzenAPI
-- Game: Harold

-- MAIN APPLICATION
addappid(338890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(338891, 1, "aca80c058aa9a608f0dbd8049337dca3e1404dbd2d80448fba3f38650e49c574")

