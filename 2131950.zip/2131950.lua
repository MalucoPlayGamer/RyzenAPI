-- Lua provided by RyzenAPI
-- Game: Cracked Demo

-- MAIN APPLICATION
addappid(2131950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131951, 1, "6a5c4edfbda134469086a0ee6f5cdc11784059d67ea4e72927858f9785159965")

