-- Lua provided by RyzenAPI
-- Game: Sneaky Bears

-- MAIN APPLICATION
addappid(712240)

-- MAIN APP DEPOTS / PACKAGES
addappid(712241, 1, "9d807f69fd6329898ad81d55d3b7c7020be4e0f66a3a5b784a6e795d3b168f57")

