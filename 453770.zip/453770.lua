-- Lua provided by RyzenAPI 
-- Game: Forgotten Tales: Day of the Dead
addappid(453770)
addappid(453771, 1, "f29b60f5979d49637225cc5d4b477df867a1c82efec30df4188a88b3997b0cea")
addappid(453772, 1, "e3e194bbbb0387c7248d28b425327b83c65efa438688058700ad53a929cd52cc")
addappid(453773, 1, "facfbd72286ad25789323adee052fde9e674470f2939102c7e71bcb25f9c144b")
