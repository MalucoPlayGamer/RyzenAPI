-- Lua provided by RyzenAPI
-- Game: Running Through Russia

-- MAIN APPLICATION
addappid(604490)

-- MAIN APP DEPOTS / PACKAGES
addappid(604491, 1, "fdc9c4fcb5836df3321554af6211fab2efef45c6e3eb16cdb78005ec03776ca5")
