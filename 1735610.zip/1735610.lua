-- Lua provided by RyzenAPI
-- Game: Game: Multiply Factory

-- MAIN APPLICATION
addappid(1735610)
-- Game: addappid(1735610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735611, 1, "028328361ba0f95a430141ee8cce98bd7fb716cb0a3352083cd588709df49b5b")
addappid(1735613, 1, "8f287a219905119c9cff075edc32cb34bf2a34d5b3f89b8b9845880b62c0b06f")
addappid(1735614, 1, "621f64c8e8fdf04dc3ae3658ce798f19946bdbd0e2718ad18245d8f57be29c86")
