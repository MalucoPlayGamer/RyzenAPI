-- Lua provided by RyzenAPI
-- Game: addappid(1167662)

-- MAIN APPLICATION
addappid(1167662)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167662,0,"aea87c47c81f65819bafc61ac4e13282e407167b1f4a2a9ad055cb318fccc0c0")
