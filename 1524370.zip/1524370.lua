-- Lua provided by RyzenAPI
-- Game: Astellia Royal

-- MAIN APPLICATION
addappid(1524370)
-- Game: addappid(1524370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524371, 1, "98480cba30e985f95e30a4e988a86ab07d1e3935ea66f7f2dc6f18018905a0c8")
addappid(1524372, 1, "65289dc6c82c39cb3e8e9e573ceccb812e01b38776131289b238088070f299b4")
