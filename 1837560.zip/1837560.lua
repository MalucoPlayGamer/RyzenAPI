-- Lua provided by RyzenAPI
-- Game: AppID 1837560

-- MAIN APPLICATION
addappid(1837560)
-- Game: addappid(1837560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837561, 1, "8e56859b1b8cba9a013db9e563e2e8cf8982323f54d9b9d11fcc61071653090a")
