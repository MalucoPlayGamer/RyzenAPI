-- Lua provided by RyzenAPI 
-- Game: Boulder Dash - 30th Anniversary
addappid(502320)
addappid(502321, 1, "6f203a9014c0a99701cb1751022f9187c2e384711a3b41b013b73e9cd7aec783")
addappid(502322, 1, "e2e4d6141dce9fb907339efadad4d67a8636c08345ff6c8a9fb936e0d722d89f")
addappid(505450, 0, "ce00599e1c93bcb34f8747dd6610930d8d0e8c5761d474654275ef58173308c8")
addappid(505451, 0, "d0c4ef070e24f83c89f3f7ddb9c3d373f1c7987408dfae8b00a54dad400168ab")
