-- Lua provided by RyzenAPI
-- Game: Boulder Dash - 30th Anniversary

-- MAIN APPLICATION
addappid(502320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(502321, 1, "6f203a9014c0a99701cb1751022f9187c2e384711a3b41b013b73e9cd7aec783")
addappid(502322, 1, "e2e4d6141dce9fb907339efadad4d67a8636c08345ff6c8a9fb936e0d722d89f")
addappid(505450, 0, "ce00599e1c93bcb34f8747dd6610930d8d0e8c5761d474654275ef58173308c8")
addappid(505451, 0, "d0c4ef070e24f83c89f3f7ddb9c3d373f1c7987408dfae8b00a54dad400168ab")

