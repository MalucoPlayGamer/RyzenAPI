-- Lua provided by RyzenAPI
-- Game: WalkinVR

-- MAIN APPLICATION
addappid(1248360)
addappid(1854240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1248361, 1, "43c02cb1f3feebb7d3225de97913e34d0aba6e8b67488b635a3984adbf51b279")

