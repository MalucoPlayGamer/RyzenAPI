-- Lua provided by RyzenAPI
-- Game: addappid(1248360)

-- MAIN APPLICATION
addappid(1248360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248361, 1, "43c02cb1f3feebb7d3225de97913e34d0aba6e8b67488b635a3984adbf51b279")
