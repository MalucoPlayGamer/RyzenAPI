-- Lua provided by RyzenAPI
-- Game: The EverFloating Island

-- MAIN APPLICATION
addappid(3546070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3546071, 1, "14645ca546b4a959ca0a8b21c12fe32c9d65f0ef8131f32787fc1dc75995cc46")

