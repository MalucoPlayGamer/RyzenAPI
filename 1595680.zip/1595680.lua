-- Lua provided by RyzenAPI
-- Game: 1595680

-- MAIN APPLICATION
addappid(1595680)
-- Game: addappid(1595680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595681, 1, "0474e71a78ea66aea6d869f030be97248cc0a0c5627aff73c5fbf6556a00dae5")
