-- Lua provided by RyzenAPI
-- Game: Bacon May Die

-- MAIN APPLICATION
addappid(646240)

-- MAIN APP DEPOTS / PACKAGES
addappid(646241, 1, "41d7061cba4fe3cab0492e82b46c6c0a05693a18fcfe51bba7adeb31ac4dbe5e")

