-- Lua provided by RyzenAPI
-- Game: VoxVR Viewer

-- MAIN APPLICATION
addappid(504990)

-- MAIN APP DEPOTS / PACKAGES
addappid(504992,0,"8e94d522e635f924a13d5d01a1a6cd3e75e155fdb56d5168f0750a4aa4211f92")

