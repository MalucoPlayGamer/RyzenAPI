-- Lua provided by RyzenAPI
-- Game: VoxVR Viewer

-- MAIN APPLICATION
addappid(504990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(504992,0,"8e94d522e635f924a13d5d01a1a6cd3e75e155fdb56d5168f0750a4aa4211f92")

