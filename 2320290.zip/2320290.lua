-- Lua provided by RyzenAPI
-- Game: The Mute House Demo

-- MAIN APPLICATION
addappid(2320290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320291, 1, "49c6322327c7fa53d49b990a128bba570f790409b63c1790343887ae58e592d2")
