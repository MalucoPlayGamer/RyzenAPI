-- Lua provided by SkyAPI 
-- Game: AppID 2320290
addappid(2320290)
addappid(2320291, 1, "49c6322327c7fa53d49b990a128bba570f790409b63c1790343887ae58e592d2")
