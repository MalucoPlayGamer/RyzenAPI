-- Lua provided by RyzenAPI
-- Game: Barking Puzzle

-- MAIN APPLICATION
addappid(1673550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673551, 1, "4d887d046dc76cf9ac626f2d36b7cb2bd30134931833c575b05ff66b791d654b")
