-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096730

-- MAIN APPLICATION
addappid(1096730)
-- Game: addappid(1096730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096731, 1, "a608f60119ce6b67443a3b9edc9476071725d3aab23834c03300cbfef47e0d92")
addappid(1096732, 1, "dfb69f0aad1dc394a77384c140431a9c68521ddab2d1c54c4d56f9a1c5213a9f")
