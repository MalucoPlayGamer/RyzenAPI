-- Lua provided by RyzenAPI
-- Game: addappid(755150)

-- MAIN APPLICATION
addappid(755150)

-- MAIN APP DEPOTS / PACKAGES
addappid(755151, 1, "2b77cbf36e8d8ca1920b36ff5d7a5695e467c342c49f97c553268619f5727dde")
