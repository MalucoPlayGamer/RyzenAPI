-- Generated with Luie @ https://lua.tools/
-- 822710 - Clash: Mutants Vs Pirates
-- Generated 2026-08-23 06:44:04 UTC
-- # Depots (Total/DLC/Shared): 4/3/0

-- Main AppID
addappid(822710)

-- Main Depots
addappid(822711, 1, "e245ac76b1e32e3f0f8907710cbb515b6deaacdae98eefc6c74569ebaa9b4a4c")
setManifestid(822711, "3746116108790377435", 5273448652)

-- DLC's (with depot keys)
-- Clash: Mutants Vs Pirates - Mutant Pack (AppID: 1515130)
addappid(1515130)
addappid(1515130, 1, "07D3CE51037A67BB88B7169C7C80FE3695E26316ED33930DA2737DF32B38C476")
setManifestid(1515130, "390884985024769583", 5273448652)
-- Clash: Mutants Vs Pirates - Pirate Pack (AppID: 1517130)
addappid(1517130)
addappid(1517130, 1, "093c9edabb289ec649494cc1e3e71df1ebba8a76961efbb5fb87d2bdfc312114")
setManifestid(1517130, "4243915654108666391", 5273448652)
-- Clash: Mutants Vs Pirates - Kinvader Pack (AppID: 1517131)
addappid(1517131)
addappid(1517131, 1, "8658dd8a071b69b8776da531daeb015e2f4d55d3e8613d6f2939f505994e28a6")
setManifestid(1517131, "6618537188607279546", 5273448652)
