-- Lua provided by RyzenAPI
-- Game: 822710

-- MAIN APPLICATION
addappid(822710)
-- Game: addappid(822710)

-- MAIN APP DEPOTS / PACKAGES
addappid(822711, 1, "e245ac76b1e32e3f0f8907710cbb515b6deaacdae98eefc6c74569ebaa9b4a4c")
