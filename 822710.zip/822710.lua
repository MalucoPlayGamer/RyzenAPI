-- Lua provided by RyzenAPI
-- Game: Clash: Mutants Vs Pirates

-- MAIN APPLICATION
addappid(822710)

-- MAIN APP DEPOTS / PACKAGES
addappid(822711, 1, "e245ac76b1e32e3f0f8907710cbb515b6deaacdae98eefc6c74569ebaa9b4a4c")

