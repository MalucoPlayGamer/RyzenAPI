-- Lua provided by RyzenAPI
-- Game: Ultimate Ragdoll Game Demo

-- MAIN APPLICATION
addappid(2369110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369111, 1, "d88a93d10aae4786ab1097d4527cd16f838989c98815d02fab78b3bd33d5afc9")

