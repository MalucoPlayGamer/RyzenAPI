-- Lua provided by RyzenAPI
-- Game: AppID 2369110

-- MAIN APPLICATION
addappid(2369110)
-- Game: addappid(2369110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369111, 1, "d88a93d10aae4786ab1097d4527cd16f838989c98815d02fab78b3bd33d5afc9")
