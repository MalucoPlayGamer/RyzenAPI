-- Lua provided by RyzenAPI
-- Game: addappid(2928700)

-- MAIN APPLICATION
addappid(2928700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928701, 1, "7cb6c7b2ed0db27470623462bc04ea1ec1a252ef81a746fe73f7d3694ff1cbfd")
