-- Lua provided by RyzenAPI
-- Game: No More Heroes 3 - The Art of No More Heroes 3

-- MAIN APPLICATION
addappid(2122940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122940,0,"ce09861c8c655507f29b5d8263d3edf1590a305e2b48e4d1d9ed9fec0bf5ec31")

