-- Lua provided by RyzenAPI
-- Game: AppID 674140

-- MAIN APPLICATION
addappid(674140)

-- MAIN APP DEPOTS / PACKAGES
addappid(674141, 1, "77b0c4854d7e898ae517df0022e9c8ce1afe274bf8258b1fe830c76e9a9d93fb")
addappid(674142, 1, "d0dd5f75a7d7ccdb41511b7b6806284ae0516528e0782a3b448d419c328f3245")
addappid(674143, 1, "50010f618a6286c6c87b54069293d4b5aa26f35c64afcc87ab80afe1ead22e89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
