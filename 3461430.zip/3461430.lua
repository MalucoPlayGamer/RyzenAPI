-- Lua provided by RyzenAPI 
-- Game: Corporate Suck Up
addappid(3461430)
addappid(3461431, 1, "14f7ae373c7db3d805d179b96e413b7faf053b86cd2f35e8fbe07a7312f51c50")
