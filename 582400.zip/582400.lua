-- Lua provided by RyzenAPI
-- Game: Alien Swarm: Reactive Drop Dedicated Server

-- MAIN APPLICATION
addappid(582400)

-- MAIN APP DEPOTS / PACKAGES
addappid(582401, 1, "e8b47259be06a7ed76a9551ac6d424e292e4a5804f365602a07b3e91c34b5d6d")
