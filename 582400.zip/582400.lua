-- Lua provided by RyzenAPI
-- Game: 582400

-- MAIN APPLICATION
addappid(582400)
-- Game: addappid(582400)

-- MAIN APP DEPOTS / PACKAGES
addappid(582401, 1, "e8b47259be06a7ed76a9551ac6d424e292e4a5804f365602a07b3e91c34b5d6d")
