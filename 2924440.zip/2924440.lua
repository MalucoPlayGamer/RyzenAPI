-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2924440)
-- Game: addappid(2924440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924440,0,"f2c1a9b7a12874361ff385a135a0360c33ba6ed85da22e746c14971e5cafec7a")
