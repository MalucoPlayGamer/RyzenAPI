-- Lua provided by RyzenAPI
-- Game: 523120

-- MAIN APPLICATION
addappid(523120)
-- Game: addappid(523120)

-- MAIN APP DEPOTS / PACKAGES
addappid(523121, 1, "c97e1d641195bcff9aac713cc1e715fde2f0ffd9914db373d5cec72b103e070c")
