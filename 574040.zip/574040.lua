-- Lua provided by RyzenAPI
-- Game: Christmas Massacre VR

-- MAIN APPLICATION
addappid(574040)
-- Game: addappid(574040)

-- MAIN APP DEPOTS / PACKAGES
addappid(574041, 1, "3ea119852a28710a69abc604de53f1cc5c2eb7825f8171e2d74d13469a9b7fb4")
