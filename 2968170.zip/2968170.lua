-- Lua provided by RyzenAPI
-- Game: 2968170

-- MAIN APPLICATION
addappid(2968170)
-- Game: addappid(2968170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968171, 1, "c6ba1e902714b1ba26d8e072c17eba03fe81b610e55b5c1953c91689d1e8d773")
