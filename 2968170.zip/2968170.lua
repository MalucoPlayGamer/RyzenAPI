-- Lua provided by RyzenAPI
-- Game: Hazing - Night Shift

-- MAIN APPLICATION
addappid(2968170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2968171, 1, "c6ba1e902714b1ba26d8e072c17eba03fe81b610e55b5c1953c91689d1e8d773")

