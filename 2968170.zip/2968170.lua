-- Lua provided by SkyAPI 
-- Game: Hazing - Night Shift
addappid(2968170)
addappid(2968171, 1, "c6ba1e902714b1ba26d8e072c17eba03fe81b610e55b5c1953c91689d1e8d773")
