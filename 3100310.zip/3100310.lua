-- Lua provided by RyzenAPI
-- Game: Arms of God

-- MAIN APPLICATION
addappid(3100310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100311,0,"4f6806b594a4f6b601cbb79736c7004672bff04b8e0c273c0883d73839fe436c")
addappid(4639880,0,"cf806ec4dea7b88e82eb05b29e22309affec9c0f9eec14bdd8f705006aa9d04d")

