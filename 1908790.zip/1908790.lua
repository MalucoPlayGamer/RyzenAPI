-- Lua provided by RyzenAPI
-- Game: Penny for Your Thoughts

-- MAIN APPLICATION
addappid(1908790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908791, 1, "f924a70f4db741ad3153e80e679ef86b657886f85b7c17cb2730be5b0b95e784")
