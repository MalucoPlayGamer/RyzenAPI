-- Lua provided by RyzenAPI 
-- Game: AppID 2633430
addappid(2633430)
addappid(2633431, 1, "8dd0e62c5d7badea0c2821665d38a6af82e86fed7ea4d1925ef4ed86d5b73477")
