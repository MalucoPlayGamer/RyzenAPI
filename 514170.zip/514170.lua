-- Lua provided by RyzenAPI
-- Game: 514170

-- MAIN APPLICATION
addappid(514170)
-- Game: addappid(514170)

-- MAIN APP DEPOTS / PACKAGES
addappid(514171, 1, "5bbdee49c8312fb81e49596f419285b91b7399cbe444132865e44dc9e991fac3")
