-- Lua provided by SkyAPI 
-- Game: AppID 514170
addappid(514170)
addappid(514171, 1, "5bbdee49c8312fb81e49596f419285b91b7399cbe444132865e44dc9e991fac3")
