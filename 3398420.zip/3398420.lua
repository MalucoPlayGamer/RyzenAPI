-- Lua provided by RyzenAPI
-- Game: Game: Citizen Sleeper 2: Starward Vector Soundtrack

-- MAIN APPLICATION
addappid(3398420)
-- Game: addappid(3398420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398421, 1, "43d49bb9c46219e1c78e019713f5853496d199148ad3317b0dce96e6d5945fdf")
addappid(3398422, 1, "16383c4208c41753cfd0b78ee006cbf027a3f7af91a4b75c9065c8d48149ab87")
