-- Lua provided by RyzenAPI
-- Game: Oil Refinery - The Simulation

-- MAIN APPLICATION
addappid(3452740)
-- Game: addappid(3452740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452741, 1, "f613abb7540ef16b58987d29c3c89f5dabb995d22925345080548b57c44d74b4")
