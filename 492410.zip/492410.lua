-- Lua provided by RyzenAPI
-- Game: AppID 492410

-- MAIN APPLICATION
addappid(492410)
-- Game: addappid(492410)

-- MAIN APP DEPOTS / PACKAGES
addappid(492411, 1, "5f5dce4a99f267c4007b03f040a16e3ff4a4a63d91676b693903ec19a14ef4a8")
