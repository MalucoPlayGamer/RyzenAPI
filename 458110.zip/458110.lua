-- Lua provided by RyzenAPI
-- Game: AppID 458110

-- MAIN APPLICATION
addappid(458110)

-- MAIN APP DEPOTS / PACKAGES
addappid(458111, 1, "c4dda8a6aa28781f4f2e9e40570c0b20c1a7ba51ca2a20615fc6e8d06b9464e3")

