-- Lua provided by RyzenAPI
-- Game: The Eye of Borrack

-- MAIN APPLICATION
addappid(1170960)
addappid(1495590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170961, 1, "d41ef4700afbc838217a61f750d0fb406cd73fe50dc196a2cca843a521b6be4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
