-- Lua provided by RyzenAPI
-- Game: Game: The Eye of Borrack

-- MAIN APPLICATION
addappid(1170960)
addappid(1495590)
-- Game: addappid(1170960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170961, 1, "d41ef4700afbc838217a61f750d0fb406cd73fe50dc196a2cca843a521b6be4b")
