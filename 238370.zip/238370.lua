-- Lua provided by RyzenAPI
-- Game: Game: Magicka 2

-- MAIN APPLICATION
addappid(238370)
-- Game: addappid(238370)

-- MAIN APP DEPOTS / PACKAGES
addappid(238371, 1, "68d0e908b275c96efc36c4d8e016c0c74736fa50eabb1972468bc8a8be1db743")
addappid(238372, 1, "8e0bbf10ae98b625b22601f8a2ddc53dff5071be3f64ca9bc997dfff0c20ab82")
addappid(238373, 1, "0cb45bbaeccb11bd187aa2a57f459cb774e82f0e66a4a5417d9458aaca25c206")
addappid(238374, 1, "9c1dd8e922785c4ee33fa268d9245be15d68c07ba48332b12a068cefbdedd705")
addappid(238375, 1, "b5434ad7471362fdabb1cb554dd51ef89068cbf9b56ec8ddf1939a301d86d106")
addappid(238376, 1, "ca7cdc125e71fb7d51a137a82ea6476e81d71b34d1065a43e678a2cd6dc76511")
addappid(238377, 1, "86aa56d28275459a04b74057e0a71bac091e7b971e62a58e47dbf2b9512e4dae")
addappid(353120, 0, "b425fd7f4db54eeb127f94ca8d5bf2916ec0d52d1959bda63f028ebc57ac0018")
addappid(354390, 0, "c0bd11dd082f0b8b7f630f456f18e5058c3990ce2b7a18247637233c7b86e64a")
