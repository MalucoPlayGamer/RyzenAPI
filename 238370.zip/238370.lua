-- Lua provided by RyzenAPI
-- Game: Magicka 2

-- MAIN APPLICATION
addappid(343980) -- Magicka 2 - Ritual sickle
addappid(343981) -- Magicka 2 - Peace Treaty staff
addappid(343982) -- Magicka 2 - Warlock robe
addappid(352860) -- Magicka 2 - Headmaster Robe
addappid(352861) -- Magicka 2 - Headmaster Sword
addappid(352862) -- Magicka 2 - Headmaster Staff
addappid(352870) -- Magicka 2 - Cultist Robe
addappid(352871) -- Magicka 2 - Cultist Staff of Aeons
addappid(352872) -- Magicka 2 - Cultist Ritual Sword
addappid(352873) -- Magicka 2 - Epic Warlord Dragon Armor
addappid(352874) -- Magicka 2 - Epic Crystal Staff
addappid(352875) -- Magicka 2 - Epic Soul Screecher Sword
addappid(353120)
addappid(354390)
addappid(393830) -- Magicka 2 Gates of Midgrd Challenge pack
addappid(393831) -- Magicka 2 Three Cardinals Robe Pack
addappid(414650) -- Magicka 2 Chirpy Staff

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(238370, 1, "475965f6a77dd6b37085519e3195eab3b947b3cefa6f9ee0172ad9cec0042db1") -- Magicka 2
addappid(238371, 1, "68d0e908b275c96efc36c4d8e016c0c74736fa50eabb1972468bc8a8be1db743") -- Joan of Arc Content Windows
addappid(238372, 1, "8e0bbf10ae98b625b22601f8a2ddc53dff5071be3f64ca9bc997dfff0c20ab82") -- Joan of Arc Content Linux
addappid(238373, 1, "0cb45bbaeccb11bd187aa2a57f459cb774e82f0e66a4a5417d9458aaca25c206") -- Joan of Arc Content OSX
addappid(238374, 1, "9c1dd8e922785c4ee33fa268d9245be15d68c07ba48332b12a068cefbdedd705") -- Joan of Arc Engine Windows
addappid(238375, 1, "b5434ad7471362fdabb1cb554dd51ef89068cbf9b56ec8ddf1939a301d86d106") -- Joan of Arc Engine Linux 32-bit
addappid(238376, 1, "ca7cdc125e71fb7d51a137a82ea6476e81d71b34d1065a43e678a2cd6dc76511") -- Joan of Arc Engine OSX
addappid(238377, 1, "86aa56d28275459a04b74057e0a71bac091e7b971e62a58e47dbf2b9512e4dae") -- Joan of Arc Engine Linux 64-bit
addappid(353120, 1, "b425fd7f4db54eeb127f94ca8d5bf2916ec0d52d1959bda63f028ebc57ac0018") -- Magicka 2 - Midgrd Interactive Map - Midgård Interactive Map (353120) Depot
addappid(354390, 1, "c0bd11dd082f0b8b7f630f456f18e5058c3990ce2b7a18247637233c7b86e64a") -- Magicka 1 Orchestral soundtrack - Magicka 1 Orchestral soundtrack (354390) Depot
addappid(414651) -- Magicka 2 Ice, Death and Fury
addtoken(352860, "567074154069307617")
addtoken(352861, "13456906228759326165")
addtoken(352862, "3497211682544400395")

