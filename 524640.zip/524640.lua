-- Lua provided by SkyAPI 
-- Game: AppID 524640
addappid(524640)
addappid(524641, 1, "a359b6e92f845e64556585e6d6cff009bd43e4079ab6f5fe26f8b0e0f8ba967b")
addappid(524642, 1, "1aca548839b539a4de935e12d53d45c69eea6bf4fc57203565dcfb093621744f")
addappid(524643, 1, "c431e0fd51add9d426ee1ae087d1380cadd91d7e330a7db26d2c213641a3e7dc")
