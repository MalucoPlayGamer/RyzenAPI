-- Lua provided by RyzenAPI
-- Game: Tokyo Snap

-- MAIN APPLICATION
addappid(1016430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016431, 1, "9c8afcd32620eec0f1bd4a61e81ea88d944f1658b15eccfb9a5542f8af9cb51a")
addappid(1016432, 1, "42edf824d217d53fcca3792f871429406fde9b90d4dd62bf439eb8e587260838")
addappid(1016433, 1, "6ec0a378a2507edc10b306b162e11a106b34e7e24433fa9c5a812637ea37ff9b")

