-- Lua provided by RyzenAPI
-- Game: Punch Line

-- MAIN APPLICATION
addappid(766680)
-- Game: addappid(766680)

-- MAIN APP DEPOTS / PACKAGES
addappid(766681, 1, "23409f078a4286204d5a1829d4cc37fdc8a6b3487198cce445dd9448728cb289")
