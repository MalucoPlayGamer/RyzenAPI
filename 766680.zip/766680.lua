-- Lua provided by RyzenAPI
-- Game: Punch Line

-- MAIN APPLICATION
addappid(766680)

-- MAIN APP DEPOTS / PACKAGES
addappid(766681, 1, "23409f078a4286204d5a1829d4cc37fdc8a6b3487198cce445dd9448728cb289")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
