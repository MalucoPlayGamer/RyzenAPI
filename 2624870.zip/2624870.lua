-- Lua provided by RyzenAPI
-- Game: addappid(2624870)

-- MAIN APPLICATION
addappid(2624870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624871, 1, "b639c25fe08af0a3e5d2f68d6f80972e9bacf8df4910d3f0a3ec734133ce62b6")
addappid(3977740, 0, "840a10096e49e6bd28961b6e7cd53a86cb6acb0f7a819787844096e5c7fbac85")
