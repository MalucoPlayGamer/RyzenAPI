-- Lua provided by RyzenAPI
-- Game: 过阴 Demo

-- MAIN APPLICATION
addappid(2358130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358131, 1, "28b0e78bb0d09f5f88ce7a6694e39babdec33d336ea6ddfdd02ca63b1ea3003b")
