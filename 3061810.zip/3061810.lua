-- Lua provided by RyzenAPI
-- Game: Like a Dragon: Pirate Yakuza in Hawaii

-- MAIN APPLICATION
addappid(3061810)
addappid(3183940)
addappid(3184000)
addappid(3184010)
addappid(3184020)
addappid(3184030)
addappid(3184040)
addappid(3184050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3061811, 1, "7a902c59f558f53204bf21403faa08aa113c0eca94bc03ad642f533ed35fc10a")

