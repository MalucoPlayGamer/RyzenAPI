-- Lua provided by RyzenAPI
-- Game: Game: Rogue'n Roll

-- MAIN APPLICATION
addappid(600310)
-- Game: addappid(600310)

-- MAIN APP DEPOTS / PACKAGES
addappid(600311, 1, "1c51b4058f745b35fd353dc558897088604ed19a38f69cf9b4697505eb717460")
