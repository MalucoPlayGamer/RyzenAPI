-- Lua provided by RyzenAPI
-- Game: The Wife Next Door - Demo

-- MAIN APPLICATION
addappid(3227910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227911, 1, "00cbe292c64dfc1164627ed736a794b755c61360a0594ea0040c745df7034e38")

