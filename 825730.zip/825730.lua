-- Lua provided by RyzenAPI
-- Game: Tzar: The Burden of the Crown

-- MAIN APPLICATION
addappid(825730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(825731, 1, "c51c3d6d11dc12354439a619fc7a7d7aa4bb0eac899c83b833e00746a4905643")
