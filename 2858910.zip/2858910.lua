-- Lua provided by RyzenAPI
-- Game: Game: Hamster Clicker!

-- MAIN APPLICATION
addappid(2858910)
-- Game: addappid(2858910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858911, 1, "78e6dd1db7651e31cb5b3207ce5bcbcd3ed7845554d131e320a6f4dd80d49d2e")
