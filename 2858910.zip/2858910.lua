-- Lua provided by RyzenAPI
-- Game: Hamster Clicker!

-- MAIN APPLICATION
addappid(2858910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2858911, 1, "78e6dd1db7651e31cb5b3207ce5bcbcd3ed7845554d131e320a6f4dd80d49d2e")

