-- Lua provided by RyzenAPI
-- Game: AppID 733650

-- MAIN APPLICATION
addappid(733650)

-- MAIN APP DEPOTS / PACKAGES
addappid(733651, 1, "12ad03854dad20600c047cc634dbe8311ab6ed2a492e23a1cd0b69ae5537a80f")
