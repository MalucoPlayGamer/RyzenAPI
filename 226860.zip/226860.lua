-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations III

-- MAIN APPLICATION
addappid(226860)
addappid(228984)
addappid(228986)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(226862,0,"6067537ac75af7810b7225b2f9e9a85d05f2aaca5b5bf5a7fdd55c8a850d8119")
addappid(226863,0,"7a0797bef021473111784fa82c087d0d35c672becc8f927c7aca62178c1b214a")
addappid(226864,0,"b1150160ffc804e4e617034d67f4cd83b8ecb6324a483192fc8f300178d4c31f")
addappid(226865,0,"2073b507ca7bfb9ed8fd86b84a8fc52ce5705f5ceffa69a65e506fd644b57f28")
addappid(226866,0,"9b09233195de9033c7db56ebc50e65112d972bca17cbfe1aebe0e8a96afb8fe7")
addappid(226867,0,"cf40110cdabb1e4d021c0173430bfbe3ee83e0392defa6acafadd1a1c948f61c")
addappid(226874,0,"4e060c70edf9559a9f58c13a44c3497ad975f32153a27443e990b672a7f7454d")
addappid(226875,0,"4136114dea721d001d39286759b582371305b367a72fc99897fca63ae5977477")
addappid(226876,0,"91dde2d2ba29651cc7d6e300a782a9e7c5b67ad4e7af0dc86ee19c153d319245")
addappid(226877,0,"661484c8f130ad9870da69419301e90c596d2e1fdff6b237169d6d468c29894f")
addappid(389930,0,"157efa84e9aacbd489e82405810668c103994b8db8c797fc86fed9bebb50f494")
addappid(455460,0,"aa18593b8723fa9f8097474fa07c5ebd586e65704d6183936b496127b9b9bbc4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(365950)
addappid(373980)
addappid(389770)
addappid(395990)
addappid(411650)
addappid(420030)
addappid(484860)
addappid(495370)
addappid(495371)
addappid(513520)
addappid(527070)
addappid(747060)
addappid(954810)
addappid(976210)
addappid(1104410)
addappid(1277830)
