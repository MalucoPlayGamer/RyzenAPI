-- Lua provided by RyzenAPI 
-- Game: Rock and Girls
addappid(1284180)
addappid(1284181, 1, "396c09d2f96397e287810eb5c19682e733b448a6b74a2b299b3046604e4f9905")
