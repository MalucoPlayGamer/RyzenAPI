-- Lua provided by RyzenAPI
-- Game: Rock and Girls

-- MAIN APPLICATION
addappid(1284180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284181, 1, "396c09d2f96397e287810eb5c19682e733b448a6b74a2b299b3046604e4f9905")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1290800)
