-- Lua provided by RyzenAPI
-- Game: 2389570

-- MAIN APPLICATION
addappid(2389570)
-- Game: addappid(2389570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389571, 1, "b13bf2bebedf915caa1d9d969b7fcd43d730af50413d962d84b6b21c31d4a1e9")
