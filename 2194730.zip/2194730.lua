-- Lua provided by RyzenAPI
-- Game: ServiceIT: You can do IT

-- MAIN APPLICATION
addappid(2194730)
addappid(4194140)
addappid(4753970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2194731, 1, "54bf44cc8249563ea86f88474f83467d819eae17775a0e82a8b440be87b81804")

