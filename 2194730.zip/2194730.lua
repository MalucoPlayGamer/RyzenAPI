-- Lua provided by RyzenAPI
-- Game: ServiceIT: You can do IT

-- MAIN APPLICATION
addappid(2194730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194731, 1, "54bf44cc8249563ea86f88474f83467d819eae17775a0e82a8b440be87b81804")

