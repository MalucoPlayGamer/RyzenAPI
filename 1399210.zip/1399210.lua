-- Lua provided by RyzenAPI
-- Game: addappid(1399210)

-- MAIN APPLICATION
addappid(1399210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399211, 1, "f8a751d104ddd36a9758b66e2101784bc3fa434060b4fc1bbc364a87dbec823e")
