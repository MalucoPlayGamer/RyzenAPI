-- Lua provided by RyzenAPI
-- Game: AppID 1292690

-- MAIN APPLICATION
addappid(1292690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292691, 1, "72b67b79a37f90150100e29f681d9fcf6724f28885e8e75f6b6b0919e399f225")
addappid(1292692, 1, "e2a36d3b055dadd2081a3699d0c798f57bb05fc69936826dc08982c81d5e3b26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
