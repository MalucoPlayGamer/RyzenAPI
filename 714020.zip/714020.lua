-- Lua provided by RyzenAPI
-- Game: addappid(714020)

-- MAIN APPLICATION
addappid(714020)

-- MAIN APP DEPOTS / PACKAGES
addappid(714021, 1, "b6a8d89a4ef878f3b050ade35857e329c09a487469dfe5e2c4cebe49016d93e8")
