-- Lua provided by RyzenAPI
-- Game: Idle Adventure

-- MAIN APPLICATION
addappid(714020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(714021, 1, "b6a8d89a4ef878f3b050ade35857e329c09a487469dfe5e2c4cebe49016d93e8")

