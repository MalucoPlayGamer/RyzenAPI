-- Lua provided by RyzenAPI
-- Game: addappid(512750)

-- MAIN APPLICATION
addappid(512750)

-- MAIN APP DEPOTS / PACKAGES
addappid(512751, 1, "cabd84fcb4a387c9753f593f101a3de4b7fdac1a92679553cf6a14f1a6dba3fd")
