-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(930020)
-- Game: addappid(930020)

-- MAIN APP DEPOTS / PACKAGES
addappid(930020,0,"aaa79262a03c3d20f4a84feca780b6d9384a88d8eff352cca3b9742ae0e0842c")
