-- Lua provided by RyzenAPI
-- Game: Crazy Ball Adventures

-- MAIN APPLICATION
addappid(655080)
addappid(765340)
addappid(768600)

-- MAIN APP DEPOTS / PACKAGES
addappid(655081, 1, "563ff85e14c557519744bbaebdd77759a7d79605a065319a2c505a72ec2e1d29")

