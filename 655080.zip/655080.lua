-- Lua provided by RyzenAPI
-- Game: addappid(655080)

-- MAIN APPLICATION
addappid(655080)

-- MAIN APP DEPOTS / PACKAGES
addappid(655081, 1, "563ff85e14c557519744bbaebdd77759a7d79605a065319a2c505a72ec2e1d29")
