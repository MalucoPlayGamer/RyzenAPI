-- Lua provided by RyzenAPI
-- Game: 2260750

-- MAIN APPLICATION
addappid(2260750)
-- Game: addappid(2260750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260751, 1, "58d608d19026d8b1c1311a91cee57ea75ad2b4dfdd45c3652e266bda9a38165d")
