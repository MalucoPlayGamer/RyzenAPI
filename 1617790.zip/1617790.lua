-- Lua provided by RyzenAPI
-- Game: G for Gravity

-- MAIN APPLICATION
addappid(1617790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617791, 1, "eaa354b9311b84f45e8d3e62698dd574b9af23b4844bfa1e893f4dd7f4c3f539")
