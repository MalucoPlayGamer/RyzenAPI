-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Tsundere ~Prideful and Competitive~ GP-01Fb

-- MAIN APPLICATION
addappid(3578640)
-- Game: addappid(3578640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578641, 1, "cafacb0dc6e5a21ec876216de5a6d6498c0a13c411496fbffc5f4cb5a7f4cfee")
