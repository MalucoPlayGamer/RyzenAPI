-- Lua provided by RyzenAPI
-- Game: 1537600

-- MAIN APPLICATION
addappid(1537600)
-- Game: addappid(1537600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537601, 1, "e98b1bc7bab4b11245a37286dc7b09deff8d910739075aaaf4a233609ea65500")
