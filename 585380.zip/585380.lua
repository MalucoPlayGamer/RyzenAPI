-- Lua provided by RyzenAPI
-- Game: Acceleration of SUGURI 2 Demo

-- MAIN APPLICATION
addappid(585380)
-- Game: addappid(585380)

-- MAIN APP DEPOTS / PACKAGES
addappid(585381, 1, "659e43421d24d5a877689318befc2397cda0a4673df4b40b939bc9e54595964e")
