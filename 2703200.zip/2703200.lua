-- Lua provided by RyzenAPI
-- Game: Hidden Western Top-Down 3D

-- MAIN APPLICATION
addappid(2703200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703201, 1, "2453ac0ba6abb89764a6dba9584a0f0840411b2b4202fdca6ee6134070f4c640")
