-- Lua provided by RyzenAPI
-- Game: Game: Paradigm Shift

-- MAIN APPLICATION
addappid(299820)
-- Game: addappid(299820)

-- MAIN APP DEPOTS / PACKAGES
addappid(299821, 1, "16de2df834d5e3f5539c999d0d8103e7ccfecccef65c23634be517e0caa26909")
