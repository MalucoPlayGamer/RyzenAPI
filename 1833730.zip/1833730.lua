-- Lua provided by RyzenAPI
-- Game: Game: Our Battle Has Just Begun! episode 2

-- MAIN APPLICATION
addappid(1833730)
-- Game: addappid(1833730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833731, 1, "9667bbe36d0de7565e8ca969b758bf3a3df910bd53371e49f29935028cb56a07")
