-- Lua provided by RyzenAPI
-- Game: Undawn

-- MAIN APPLICATION
addappid(1881700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881705,0,"19ff311f44a7cf4a7cb182cbcacff73563d218f5d04e69320dc838ca49e23f93")
addappid(1881706,0,"2f87bfdcee622070c415df7de3d087e187e54b91a548aa46659a6595916713b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
