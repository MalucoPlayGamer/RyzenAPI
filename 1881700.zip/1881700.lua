-- Lua provided by RyzenAPI
-- Game: Undawn

-- MAIN APPLICATION
addappid(1881700)
-- Game: addappid(1881700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881705,0,"19ff311f44a7cf4a7cb182cbcacff73563d218f5d04e69320dc838ca49e23f93")
addappid(1881706,0,"2f87bfdcee622070c415df7de3d087e187e54b91a548aa46659a6595916713b1")
