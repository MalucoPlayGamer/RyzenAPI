-- Lua provided by RyzenAPI
-- Game: Game: AppID 1293520

-- MAIN APPLICATION
addappid(1293520)
-- Game: addappid(1293520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293521, 1, "12f17e5833f16aef4340a183621acf7fe6c15d7b72c5a13a588c821ed3ef71c3")
