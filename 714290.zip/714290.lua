-- Lua provided by RyzenAPI
-- Game: Endless Treasure Hunt

-- MAIN APPLICATION
addappid(714290)

-- MAIN APP DEPOTS / PACKAGES
addappid(714291,0,"6af7e42d97a8c4c569f79714348a64c480eda68507d41f4ed635f35cec820734")

