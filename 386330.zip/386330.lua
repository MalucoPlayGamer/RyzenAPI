-- Lua provided by RyzenAPI 
-- Game: AppID 386330
addappid(386330)
addappid(386331, 1, "3dcca88fb841631c23adfc0cbc1d6caf29ac0d27c97ec7280e3a690e832ba49c")
addappid(386332, 1, "d0e271138efe05dffa0f26240fe3bc500e61bcaf29b2d2c71a149a2ced5ac3e9")
addappid(386333, 1, "31791b7c185027e06fc8e37fa260c5e913c0a54d95b76693366d75299486da52")
