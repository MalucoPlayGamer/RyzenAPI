-- Lua provided by RyzenAPI
-- Game: Dick Wilde 2

-- MAIN APPLICATION
addappid(975430)

-- MAIN APP DEPOTS / PACKAGES
addappid(975431, 1, "ebd8dbe05b31855bb63cbc30a9c6ffddd5e536ca63cfebeff9261adb7b21adbc")

