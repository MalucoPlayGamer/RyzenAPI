-- Lua provided by RyzenAPI
-- Game: The Legend of Tango

-- MAIN APPLICATION
addappid(394720)
-- Game: addappid(394720)

-- MAIN APP DEPOTS / PACKAGES
addappid(394721, 1, "40407297cd087a5a4177213a2784a0b7008eeac85b17e6455fad8fbc30b74349")
