-- Lua provided by RyzenAPI
-- Game: Parking Garage Rally Circuit

-- MAIN APPLICATION
addappid(2737300)
addappid(3949820)
-- Game: addappid(2737300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737301, 1, "90dedf7af32e5263c433582527aa3915a84f51e3fd6b4041e4b3d0f2508dd5d4")
addappid(2737302, 1, "cc6f655ab93320fe9c7fc18b858be3f4b0ba446e8f76bd830dc2deb3efe512e8")
addappid(2737303, 1, "be2fd45ba43d2c0122fe7c7ff0ff68c9b74e0a9397157a74f86a3972c1f74650")
