-- Lua provided by RyzenAPI
-- Game: addappid(687750)

-- MAIN APPLICATION
addappid(687750)

-- MAIN APP DEPOTS / PACKAGES
addappid(687751, 1, "cb2b9de56e4c058898e9c536b06b59013a9352f4f1c64bf32f6bbb4dc44a8f4d")
