-- Lua provided by SkyAPI 
-- Game: AppID 687750
addappid(687750)
addappid(687751, 1, "cb2b9de56e4c058898e9c536b06b59013a9352f4f1c64bf32f6bbb4dc44a8f4d")
