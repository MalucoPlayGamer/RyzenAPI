-- Lua provided by RyzenAPI
-- Game: addappid(1221240)

-- MAIN APPLICATION
addappid(1221240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221241, 1, "bf8581ee1559d6154c71e212e759d20c71277f1e720b62a0f0a978fb05ea6df7")
