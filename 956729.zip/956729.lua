-- Lua provided by RyzenAPI
-- Game: Xu Huang - Officer Ticket / 徐晃使用券

-- MAIN APPLICATION
addappid(956729)

-- MAIN APP DEPOTS / PACKAGES
addappid(956729,0,"50a8c76d42d7a53e78d0dbe3310962a19f85d88c104a7e760e2450007385a04a")

