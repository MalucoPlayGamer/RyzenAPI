-- Lua provided by RyzenAPI
-- Game: 984750

-- MAIN APPLICATION
addappid(984750)
-- Game: addappid(984750)

-- MAIN APP DEPOTS / PACKAGES
addappid(984751, 1, "19bfa2430e71d4eb5e60223044aea8b6eacf0d630b8c4663bba2aa25619ce046")
