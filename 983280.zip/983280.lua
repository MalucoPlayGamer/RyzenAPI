-- Lua provided by SkyAPI 
-- Game: Chocolate makes you happy: New Year
addappid(983280)
addappid(983281, 1, "c79cccc621110e6c6a82cb95240e5619ff3f13ad768b1165132b0b54c6eb715e")
