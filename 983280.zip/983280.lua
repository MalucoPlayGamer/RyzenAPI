-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy: New Year

-- MAIN APPLICATION
addappid(983280)

-- MAIN APP DEPOTS / PACKAGES
addappid(983281, 1, "c79cccc621110e6c6a82cb95240e5619ff3f13ad768b1165132b0b54c6eb715e")

