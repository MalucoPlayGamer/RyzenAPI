-- Lua provided by RyzenAPI
-- Game: Madden NFL 21

-- MAIN APPLICATION
addappid(1239520)
addappid(1293890)
addappid(1293891)
addappid(1293892)
addappid(1293893)
addappid(1337090)
addappid(1337091)
addappid(1337092)
addappid(1358160)
addappid(1358161)
addappid(1358162)
addappid(1372740)
addappid(1458130)
addappid(1458131)
addappid(1476190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1239521, 1, "37260877aa7fd2ea7e076f5132d7b03bc0725f92bbe2f147dc202f8d32623027")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")

