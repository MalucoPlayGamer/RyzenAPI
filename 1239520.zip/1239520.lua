-- Lua provided by RyzenAPI
-- Game: Madden NFL 21

-- MAIN APPLICATION
addappid(1239520)
-- Game: addappid(1239520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239521, 1, "37260877aa7fd2ea7e076f5132d7b03bc0725f92bbe2f147dc202f8d32623027")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
