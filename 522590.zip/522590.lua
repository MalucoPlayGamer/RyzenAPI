-- Lua provided by RyzenAPI
-- Game: addappid(522590)

-- MAIN APPLICATION
addappid(522590)

-- MAIN APP DEPOTS / PACKAGES
addappid(522591, 1, "2c2e714747e38c790a4a3eaf294edc7584c0ce3a9decfa2a2b44de7fc2eff307")
