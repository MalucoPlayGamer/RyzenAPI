-- Lua provided by RyzenAPI
-- Game: Game: Night Stones

-- MAIN APPLICATION
addappid(2300340)
-- Game: addappid(2300340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300341, 1, "890323f3c9e10ce2e65df7c63c941136cb8910c9cfb992b4ac2a7d87541da56d")
