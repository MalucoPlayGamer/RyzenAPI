-- Lua provided by RyzenAPI
-- Game: GeoDepths

-- MAIN APPLICATION
addappid(2206140)
-- Game: addappid(2206140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206141, 1, "e4262396efb1f77a2d2cc73036410a61f769997a6995546539f5ac726184d90f")
