-- Lua provided by RyzenAPI 
-- Game: GeoDepths
addappid(2206140)
addappid(2206141, 1, "e4262396efb1f77a2d2cc73036410a61f769997a6995546539f5ac726184d90f")
