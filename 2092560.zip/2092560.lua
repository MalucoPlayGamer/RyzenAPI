-- Lua provided by RyzenAPI
-- Game: Runscore

-- MAIN APPLICATION
addappid(2092560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092561, 1, "06c684c99cd5ceff36bf3ae4976908ecb3e856c4bdc7982ec8db8284305bdaca")
