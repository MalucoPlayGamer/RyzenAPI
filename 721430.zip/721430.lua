-- Lua provided by RyzenAPI
-- Game: 721430

-- MAIN APPLICATION
addappid(721430)
-- Game: addappid(721430)

-- MAIN APP DEPOTS / PACKAGES
addappid(721431, 1, "43d818eb773e0225d5a52637325828e345bc8d8bc53caf7f662fae135c0203b8")
addappid(721432, 1, "2e63224bc4cc2ef7a896696725033ddb9df27eb5f22f30247fee58c490d9f31f")
addappid(721433, 1, "a08f929ecfb50c7ca51b4f7742a22b2c4263d8cdcafe2bf8a6c9c7a9fa911bca")
