-- Lua provided by RyzenAPI
-- Game: addappid(1855070)

-- MAIN APPLICATION
addappid(1855070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855071, 1, "797624ec576c12acf5fc7443a490822808afca5919f4cc2cf3376c9b625c48bd")
