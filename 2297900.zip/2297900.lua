-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Hero Generator for MZ

-- MAIN APPLICATION
addappid(2297900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297900,0,"898f2325fc6cfed796f86362e1a4a08e07b018aeaf1755de7a0aa74ecdec1e8a")
