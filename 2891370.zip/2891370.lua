-- Lua provided by RyzenAPI
-- Game: Pieced Together

-- MAIN APPLICATION
addappid(2891370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891371,0,"4f7efe2ea100f942d0b0d45833b635ce611b90082b47ffa816f1523525bbb41d")

