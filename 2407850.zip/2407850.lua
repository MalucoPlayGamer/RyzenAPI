-- Lua provided by RyzenAPI 
-- Game: Typing Tempo Demo
addappid(2407850)
addappid(2407851, 1, "0cb8bca117f32f04da9637d0b7256c8bb61b6a70a95c5ac1368cf3e68e89efdf")
