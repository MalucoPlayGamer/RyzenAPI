-- Lua provided by RyzenAPI
-- Game: Memeside

-- MAIN APPLICATION
addappid(2374610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374611, 1, "987c251b8f247cc3da4e9c9fddf0fe74ac21acdb2afeed984f56e21c85dae289")
