-- Lua provided by SkyAPI 
-- Game: AppID 498830
addappid(498830)
addappid(498831, 1, "9d38f2a9f84a7ac04b375836ff9581d1054471f8ec7074e4478820824193d2ca")
