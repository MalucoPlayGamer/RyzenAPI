-- Lua provided by RyzenAPI 
-- Game: Alchemist Tris's Desire Demo
addappid(2146900)
addappid(2146901, 1, "fd49e7ec390360a12f6eb92ce03b0065f2ffe5f9bf05b478438605bb73589d6f")
addappid(2146902, 1, "148af0c7508363314ec074d16b9c4e32c460a04950e506dac284235bcf938da1")
