-- Lua provided by RyzenAPI
-- Game: Game: 100 hidden turtles

-- MAIN APPLICATION
addappid(2013900)
-- Game: addappid(2013900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013901, 1, "9a1ee04a0da970fe0b520e2b4027e7c6d864952695778500323070962fc61022")
