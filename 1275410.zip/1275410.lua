-- Lua provided by RyzenAPI
-- Game: Only One Rectangle

-- MAIN APPLICATION
addappid(1275410)
-- Game: addappid(1275410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275411, 1, "6a1c77b7a23df88a7ca4304865758d440e2e7523b42bb6c7ffd31f20abfac0ff")
