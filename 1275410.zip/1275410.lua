-- Lua provided by SkyAPI 
-- Game: Only One Rectangle
addappid(1275410)
addappid(1275411, 1, "6a1c77b7a23df88a7ca4304865758d440e2e7523b42bb6c7ffd31f20abfac0ff")
