-- Lua provided by RyzenAPI
-- Game: MINOS

-- MAIN APPLICATION
addappid(3181650)
addappid(4359010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3181651,0,"91d8d483b86332b4ba5c069699f0f9baa66d40aa6176029e2e862c789d4743cd")

