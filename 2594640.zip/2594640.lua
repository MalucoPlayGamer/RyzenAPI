-- Lua provided by RyzenAPI
-- Game: Game: Taora : Beginning

-- MAIN APPLICATION
addappid(2594640)
-- Game: addappid(2594640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594641, 1, "07bcb934b36290855a83aedf23809b0277972b44d949aaf57848e35093c67951")
