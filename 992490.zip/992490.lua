-- Lua provided by SkyAPI 
-- Game: iVRy Driver for SteamVR
addappid(992490)
addappid(992491, 1, "1a9d7637e8c9d0e2be9e5c3e66639ca1838a7bff8edcabb3c3208ecabd227a33")
