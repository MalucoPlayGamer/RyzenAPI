-- Lua provided by RyzenAPI
-- Game: addappid(992490)

-- MAIN APPLICATION
addappid(992490)

-- MAIN APP DEPOTS / PACKAGES
addappid(992491, 1, "1a9d7637e8c9d0e2be9e5c3e66639ca1838a7bff8edcabb3c3208ecabd227a33")
