-- Lua provided by RyzenAPI
-- Game: iVRy Driver for SteamVR

-- MAIN APPLICATION
addappid(992490)

-- MAIN APP DEPOTS / PACKAGES
addappid(992491, 1, "1a9d7637e8c9d0e2be9e5c3e66639ca1838a7bff8edcabb3c3208ecabd227a33")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1005970)
addappid(1005971)
addappid(1005972)
addappid(1021000)
addappid(1257790)
addappid(1487090)
addappid(1501870)
addappid(1591080)
addappid(2261230)
addappid(2261231)
addappid(2772740)
addappid(2829580)
addappid(3260890)
addappid(3458760)
addappid(3458770)
