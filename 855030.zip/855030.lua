-- Lua provided by RyzenAPI
-- Game: Game: Balloon Strike

-- MAIN APPLICATION
addappid(855030)
-- Game: addappid(855030)

-- MAIN APP DEPOTS / PACKAGES
addappid(855031, 1, "dfd7462ad49545e8145e49187b7d5ac5caac1e7b5a9162dbb887350b3f092a07")
