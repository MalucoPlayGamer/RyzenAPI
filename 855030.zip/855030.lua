-- Lua provided by SkyAPI 
-- Game: Balloon Strike
addappid(855030)
addappid(855031, 1, "dfd7462ad49545e8145e49187b7d5ac5caac1e7b5a9162dbb887350b3f092a07")
