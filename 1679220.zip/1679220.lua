-- Lua provided by RyzenAPI
-- Game: Portal Dungeon

-- MAIN APPLICATION
addappid(1679220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679221, 1, "7a72debfccc6e5d77fa00fa1e1c3be6f3bd125e4f960453777f05beaa098df4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2631370)
addappid(2860320)
