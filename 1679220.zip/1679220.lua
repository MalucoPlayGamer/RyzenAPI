-- Lua provided by RyzenAPI
-- Game: 1679220

-- MAIN APPLICATION
addappid(1679220)
-- Game: addappid(1679220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679221, 1, "7a72debfccc6e5d77fa00fa1e1c3be6f3bd125e4f960453777f05beaa098df4f")
