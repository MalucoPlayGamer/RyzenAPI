-- Lua provided by RyzenAPI
-- Game: Game: Adventure Llama

-- MAIN APPLICATION
addappid(1483800)
-- Game: addappid(1483800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483801, 1, "3db2b612d025c1c9044252844d2f8dd6378c8a8124ba3ba4c6bf13cc5f33ba8b")
