-- Lua provided by RyzenAPI
-- Game: AppID 461570

-- MAIN APPLICATION
addappid(461570)

-- MAIN APP DEPOTS / PACKAGES
addappid(461571, 1, "64c5be708c7da835ffe60756fa7c8d24b88cae06528f0e1b9a1900496c6ae15a")

