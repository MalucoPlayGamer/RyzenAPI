-- Lua provided by RyzenAPI
-- Game: addappid(2640350)

-- MAIN APPLICATION
addappid(228990)
addappid(2640350)
addappid(2640353)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640352,0,"db556642f4e4a23d6da93e5c0a859fe15aa38819fff39d97c58bf1a3707a4aca")
