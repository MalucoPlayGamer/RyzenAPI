-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2640350)
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(2640353)
addappid(2640352,0,"db556642f4e4a23d6da93e5c0a859fe15aa38819fff39d97c58bf1a3707a4aca")