-- Lua provided by RyzenAPI
-- Game: TT Isle of Man: Ride on the Edge 2

-- MAIN APPLICATION
addappid(1082180)
addappid(1189870)
addappid(1189871)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1082181, 1, "7de4b3132732a7f661ed50c98e58dccf533e87d7280c749a8b5a00ff13036388")

