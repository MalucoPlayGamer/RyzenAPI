-- Lua provided by RyzenAPI
-- Game: Game: TT Isle of Man: Ride on the Edge 2

-- MAIN APPLICATION
addappid(1082180)
-- Game: addappid(1082180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082181, 1, "7de4b3132732a7f661ed50c98e58dccf533e87d7280c749a8b5a00ff13036388")
