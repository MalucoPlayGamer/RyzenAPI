-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Battle Royal

-- MAIN APPLICATION
addappid(2466850)
-- Game: addappid(2466850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466851, 1, "6f6a3fd819ab2298110f6358414b11acc03ff79ece045a70a39463a89c66f924")
