-- Lua provided by RyzenAPI
-- Game: addappid(1291400)

-- MAIN APPLICATION
addappid(1291400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291401, 1, "8b0a0f565f475b5c9e6ba7eaf7dd2695197a6e6b84a69d16ca1717396fe0db30")
addappid(1291402, 1, "9d678ec18f57a69f2420c7dd8e0935e8dfc6490c39cd903d5ffcc36e450b878d")
