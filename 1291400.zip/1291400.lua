-- Lua provided by SkyAPI 
-- Game: AppID 1291400
addappid(1291400)
addappid(1291401, 1, "8b0a0f565f475b5c9e6ba7eaf7dd2695197a6e6b84a69d16ca1717396fe0db30")
addappid(1291402, 1, "9d678ec18f57a69f2420c7dd8e0935e8dfc6490c39cd903d5ffcc36e450b878d")
