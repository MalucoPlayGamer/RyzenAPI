-- Lua provided by RyzenAPI
-- Game: Game: Poltergirl Demo

-- MAIN APPLICATION
addappid(1949320)
-- Game: addappid(1949320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949321, 1, "0b1f476e74c22a04101e2916083c25c6f23765867ff8112df02cf4571bab560f")
