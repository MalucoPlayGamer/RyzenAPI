-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Piggy

-- MAIN APPLICATION
addappid(750350)

-- MAIN APP DEPOTS / PACKAGES
addappid(750351, 1, "be52bda817b812a5f3e003e33195396386429cd06597a7d1ae669f8c72eb621d")
addappid(750352, 1, "3e14afbe84b094101434c2fd61b772540d72f4e25b55bc8d48911a30677aa5f0")

