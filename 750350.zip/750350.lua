-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Piggy

-- MAIN APPLICATION
addappid(750350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(750351, 1, "be52bda817b812a5f3e003e33195396386429cd06597a7d1ae669f8c72eb621d")
addappid(750352, 1, "3e14afbe84b094101434c2fd61b772540d72f4e25b55bc8d48911a30677aa5f0")

