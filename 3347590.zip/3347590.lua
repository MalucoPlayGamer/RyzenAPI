-- Lua provided by RyzenAPI
-- Game: Neon Hearts City Demo

-- MAIN APPLICATION
addappid(3347590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347591, 1, "7a1fdbff545293f4229abdfdda790e4969c1aff764cd081f19c4485607f4c9f7")

