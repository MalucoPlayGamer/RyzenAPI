-- Lua provided by RyzenAPI
-- Game: Return to Planet X

-- MAIN APPLICATION
addappid(643970)

-- MAIN APP DEPOTS / PACKAGES
addappid(643971,0,"d73d34e483e4606d0a3d79937d132b48a8a5ccc463147f3649b7a7b547f359f4")

