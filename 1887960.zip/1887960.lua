-- Lua provided by RyzenAPI
-- Game: Shadow of Egypt

-- MAIN APPLICATION
addappid(1887960)
-- Game: addappid(1887960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887961, 1, "035e400a61f00caf266a458d001795390a46e175b2693333683ca13c0b15c581")
