-- Lua provided by RyzenAPI
-- Game: addappid(703430)

-- MAIN APPLICATION
addappid(703430)

-- MAIN APP DEPOTS / PACKAGES
addappid(703431, 1, "3c630a343ae57e62254325389379be04b65fc9ef911838c08defa2f83a39d3fe")
