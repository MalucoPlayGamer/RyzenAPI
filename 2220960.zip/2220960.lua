-- Lua provided by RyzenAPI
-- Game: Outlanders Demo

-- MAIN APPLICATION
addappid(2220960)
-- Game: addappid(2220960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220961, 1, "cf169290886fd1cf4dc751818e08c69582f3533dbc3ce02787c6955c153ee71e")
