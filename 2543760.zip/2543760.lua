-- Lua provided by RyzenAPI
-- Game: Shadow of the Ninja - Reborn

-- MAIN APPLICATION
addappid(2543760)
addappid(2880920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543761, 1, "650e2c12f9c39e4c5aed98acf1d1f8136d1185c04b6dc660f0241574ce2f7918")
addappid(2543762, 1, "48ca8e40c1114e72c86efec0d0d1ec0fb12ce405750c6d9b6cdc07e736969d78")
