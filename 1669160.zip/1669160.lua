-- Lua provided by RyzenAPI
-- Game: ENDLESS BECOMING - APARTMENT

-- MAIN APPLICATION
addappid(1669160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669161, 1, "d708e15cb4184ee5b6942c3490af438e86ded2de77678327750bb7d26196f2b0")
addappid(1669162, 1, "895bce70734bc809a7e8511b3de2c09c876a8990bc3fc0c7bfc66914372cd950")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
