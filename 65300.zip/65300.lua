-- Lua provided by RyzenAPI
-- Game: Dustforce DX

-- MAIN APPLICATION
addappid(65300)
addappid(228990)
addappid(229020)
-- Game: addappid(65300)

-- MAIN APP DEPOTS / PACKAGES
addappid(65301, 1, "e7687a38df6062926365a5951797f2ea4bdcd2b0995032b85d7cf571ff477140")
addappid(65303, 1, "a410b8fe70e0b8fb4f5940a31a0635914d03a8442fe376b8a45a3a9d45ab67ce")
addappid(65304, 1, "ece92d106500fbedad472b76df53fce3cd00e546c4dde2ede8942a3520e3edab")
