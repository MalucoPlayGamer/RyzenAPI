-- Lua provided by RyzenAPI
-- Game: Game: To Kill a God Demo

-- MAIN APPLICATION
addappid(3261920)
-- Game: addappid(3261920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261921, 1, "3b0424be0deaf5c0d4e9f4c31e6379de4de333301860c4347b7f8d56e0b27d60")
