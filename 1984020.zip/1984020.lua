-- Lua provided by RyzenAPI
-- Game: Everhood 2

-- MAIN APPLICATION
addappid(1984020)
-- Game: addappid(1984020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984021, 1, "08f1a3d67b607bd3ee2f42873e693d99e99ed8ef0f93389a91debed6bb422dee")
