-- Lua provided by RyzenAPI
-- Game: Iron Meat Demo

-- MAIN APPLICATION
addappid(1323260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323261, 1, "66f9d81ec01decd3e837ffa62e11a8d516201078a4c6802dcc180cb9bdb5aecc")
