-- Lua provided by RyzenAPI
-- Game: VR Time Machine Travelling in history: Visit ancient Egypt, Babylon and Greece in B.C. 400

-- MAIN APPLICATION
addappid(1397230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397231, 1, "c917a4106531212c204f8b56b887aa7494b7e1cd95b868198365945ff4bd65c3")
