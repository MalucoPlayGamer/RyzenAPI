-- Lua provided by SkyAPI 
-- Game: AppID 1397230
addappid(1397230)
addappid(1397231, 1, "c917a4106531212c204f8b56b887aa7494b7e1cd95b868198365945ff4bd65c3")
