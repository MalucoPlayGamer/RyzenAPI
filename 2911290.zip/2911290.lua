-- Lua provided by SkyAPI 
-- Game: SKUF BACKROOMS
addappid(2911290)
addappid(2911291, 1, "debf18a0eb15020446458c9dae2abd992319c83e7ec7ea4a4a749a18c491dbda")
