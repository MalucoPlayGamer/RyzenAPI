-- Lua provided by RyzenAPI
-- Game: SKUF BACKROOMS

-- MAIN APPLICATION
addappid(2911290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911291, 1, "debf18a0eb15020446458c9dae2abd992319c83e7ec7ea4a4a749a18c491dbda")

