-- Lua provided by RyzenAPI
-- Game: SKUF BACKROOMS

-- MAIN APPLICATION
addappid(2911290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911291, 1, "debf18a0eb15020446458c9dae2abd992319c83e7ec7ea4a4a749a18c491dbda")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
