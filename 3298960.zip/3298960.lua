-- Lua provided by RyzenAPI 
-- Game: AppID 3298960
addappid(3298960)
addappid(3298961, 1, "82e1b8e1f5ae1c6c9a351a0d11198ceff24b1101676e7f94fd587f31985e7632")
