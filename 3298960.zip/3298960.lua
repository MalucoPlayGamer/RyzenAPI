-- Lua provided by RyzenAPI
-- Game: AppID 3298960

-- MAIN APPLICATION
addappid(3298960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298961, 1, "82e1b8e1f5ae1c6c9a351a0d11198ceff24b1101676e7f94fd587f31985e7632")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
