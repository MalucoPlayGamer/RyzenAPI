-- Lua provided by RyzenAPI
-- Game: Game: NejicomiSimulator Vol.4 Demo

-- MAIN APPLICATION
addappid(1931610)
-- Game: addappid(1931610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931611, 1, "e43e0129f49044729decdb88c6d6a78a4375ce35771bf6c348ec34087b3e43cc")
