-- Lua provided by RyzenAPI
-- Game: Car War Legends

-- MAIN APPLICATION
addappid(1918930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918931, 1, "923da1e66a0f70101204cbc0666f634f32eb87770a54937a5ad19fde87de063a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
