-- Lua provided by RyzenAPI
-- Game: addappid(1918930)

-- MAIN APPLICATION
addappid(1918930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918931, 1, "923da1e66a0f70101204cbc0666f634f32eb87770a54937a5ad19fde87de063a")
