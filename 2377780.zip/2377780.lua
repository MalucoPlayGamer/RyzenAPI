-- Lua provided by RyzenAPI
-- Game: 终极功德模拟器 | Zen Simulator

-- MAIN APPLICATION
addappid(2377780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377781, 1, "3f7ffcaa3d98dbae545ff2d97b7bc0b2262fb57e340d2cc91bdcb304464cd575")
