-- Lua provided by RyzenAPI
-- Game: addappid(2844850)

-- MAIN APPLICATION
addappid(2844850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844851, 1, "8d0c42b4beecb7174b656f8bb0dfe61661adfd80d854a21fba5bb180ccef7996")
