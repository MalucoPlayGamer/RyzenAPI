-- Lua provided by RyzenAPI
-- Game: FANTASIAN Neo Dimension

-- MAIN APPLICATION
addappid(2844850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844851, 1, "8d0c42b4beecb7174b656f8bb0dfe61661adfd80d854a21fba5bb180ccef7996")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3065990)
