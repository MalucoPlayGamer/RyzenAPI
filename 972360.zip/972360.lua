-- Lua provided by RyzenAPI
-- Game: addappid(972360)

-- MAIN APPLICATION
addappid(972360)

-- MAIN APP DEPOTS / PACKAGES
addappid(972360,0,"ed2ae34bf8e1d299b698af5b9cd74a5044079387fff85baafc031c169b2624f3")
