-- Lua provided by RyzenAPI 
-- Game: Fatty Rabbit Hole
addappid(686510)
addappid(686511, 1, "f71bc00de0cf8351b942390a3bcaecdf8a8dd528d12902b5f189cab17da14927")
