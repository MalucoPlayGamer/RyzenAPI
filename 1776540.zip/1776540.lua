-- Lua provided by RyzenAPI
-- Game: Lawnmower Game: Pinball

-- MAIN APPLICATION
addappid(1776540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1776541, 1, "d4189c66937e4470aa730834e43566a8e5cb08a750a748d4feb83950dcd7728e")

