-- Lua provided by RyzenAPI
-- Game: Lawnmower Game: Pinball

-- MAIN APPLICATION
addappid(1776540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776541, 1, "d4189c66937e4470aa730834e43566a8e5cb08a750a748d4feb83950dcd7728e")

