-- Lua provided by RyzenAPI
-- Game: ZONE OF THE ENDERS THE 2nd RUNNER : M∀RS / アヌビス ゾーン・オブ・エンダーズ : マーズ

-- MAIN APPLICATION
addappid(229004)
addappid(650510)
-- Game: addappid(650510)

-- MAIN APP DEPOTS / PACKAGES
addappid(650512,0,"f45d939a07bc038a0dabf47c1f170ff94286b5eb344b5e770218f8481dbe48ad")
