-- Lua provided by RyzenAPI
-- Game: 538050

-- MAIN APPLICATION
addappid(538050)
-- Game: addappid(538050)

-- MAIN APP DEPOTS / PACKAGES
addappid(538051, 1, "a5a642a609aa1866486acef057a6dcf4761a424e29cccdd8b293a84d654ddb1e")
