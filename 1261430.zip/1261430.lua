-- Lua provided by RyzenAPI
-- Game: Kandria

-- MAIN APP DEPOTS / PACKAGES
addappid(1261430, 1, "2b00b402f4fd8e63dac5467e41bf1e4a64d0c39df573011be55115037b2a45d5") -- Kandria
addappid(1261431, 1, "4f24b5f438b12a43a029e360cdd63a552e4c068bfb6bbb1d3777f33657da3268") -- Depot 1261431
addappid(1261432, 1, "4baa545156d8c7daac31b9b271a9e02f26bcc5f22f63cd3c5baf6c51c10dad73") -- Depot 1261432
addappid(1261433, 1, "aae021f19232c79a9dcebd789c12a8540631c5cc10ffc5fe785b97692f5e867c") -- Depot 1261433
addappid(1261434, 1, "941dae56d89767b0014a6faf625c034e36be95690af242c940bfc4e048b3cdf5") -- Depot 1261434

