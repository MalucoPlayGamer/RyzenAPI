-- 1261430's Lua and Manifest Created by Hubcap Manifest
-- Kandria
-- Created: August 03, 2026 at 14:57:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1261430, 1, "2b00b402f4fd8e63dac5467e41bf1e4a64d0c39df573011be55115037b2a45d5") -- Kandria
-- MAIN APP DEPOTS
addappid(1261431, 1, "4f24b5f438b12a43a029e360cdd63a552e4c068bfb6bbb1d3777f33657da3268") -- Depot 1261431
setManifestid(1261431, "2419437752876664283", 65125617)
addappid(1261432, 1, "4baa545156d8c7daac31b9b271a9e02f26bcc5f22f63cd3c5baf6c51c10dad73") -- Depot 1261432
setManifestid(1261432, "7268807275494480751", 47568761)
addappid(1261433, 1, "aae021f19232c79a9dcebd789c12a8540631c5cc10ffc5fe785b97692f5e867c") -- Depot 1261433
setManifestid(1261433, "4490701110778718133", 0)
addappid(1261434, 1, "941dae56d89767b0014a6faf625c034e36be95690af242c940bfc4e048b3cdf5") -- Depot 1261434
setManifestid(1261434, "2921836012953564281", 194203741)