-- Lua provided by RyzenAPI
-- Game: Street Cleaner Simulator

-- MAIN APPLICATION
addappid(2856100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856101, 1, "0d83e8167d3cb4c24c6b24b0ae6493b6acd282b87a003203c832b222fdd798fe")

