-- Lua provided by RyzenAPI
-- Game: Street Cleaner Simulator

-- MAIN APPLICATION
addappid(2856100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2856101, 1, "0d83e8167d3cb4c24c6b24b0ae6493b6acd282b87a003203c832b222fdd798fe")

