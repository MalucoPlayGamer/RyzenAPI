-- Lua provided by RyzenAPI
-- Game: 7 Days in Dream EX

-- MAIN APPLICATION
addappid(852800)

-- MAIN APP DEPOTS / PACKAGES
addappid(852800,0,"de496f1cc3912ae6d4c579040dd1113da0c462c9bd926d6b98de4202b73c7c6e")
