-- Lua provided by RyzenAPI
-- Game: Staffer Retro : A Supernatural Mystery Quest

-- MAIN APPLICATION
addappid(3837350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3837351,0,"95fc4c33ab2f6b33d2f54a2fb797323d792f830e25eef876c80f94c4fce965e6")

