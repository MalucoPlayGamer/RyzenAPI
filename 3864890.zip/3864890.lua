-- Lua provided by RyzenAPI
-- Game: 星火燎原

-- MAIN APPLICATION
addappid(3864890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3864891,0,"3610f3146bbe9cb3ff58de8feb4705bcab952a4a067634bc25d5520bcda14bc4")

