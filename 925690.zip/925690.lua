-- Lua provided by RyzenAPI
-- Game: Witch The Bloodlines

-- MAIN APPLICATION
addappid(925690)
-- Game: addappid(925690)

-- MAIN APP DEPOTS / PACKAGES
addappid(925691, 1, "df39aecaa3369656e8915f5a5d7897c92090b7287b925cad4a1ef453f93bb769")
