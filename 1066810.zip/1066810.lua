-- Lua provided by RyzenAPI
-- Game: Forge and Fight!

-- MAIN APPLICATION
addappid(1066810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066811, 1, "eca936cca3e67649b71af81c4b96a765cc62514c0b3fa2e940f665139021115b")
addappid(1066812, 1, "db64ba1e93deec5403e8e16e2edf4f1299d17a375004c3aeaa3713806df30ba8")
addappid(1066813, 1, "65b3162e9e8545bde390a5ff9e7f02abbf1b671d167596280c3d5ce066b0a6ca")
