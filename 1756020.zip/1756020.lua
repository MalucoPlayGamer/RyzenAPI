-- Lua provided by RyzenAPI
-- Game: Super Roboy

-- MAIN APPLICATION
addappid(1756020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756021, 1, "e20755b13da3adf2f48966357154040fc1f4e0a4ed7403137b0b4f78f31937c0")

