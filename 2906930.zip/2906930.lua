-- Lua provided by RyzenAPI
-- Game: 小石冒险 Koishi Adventure⁓

-- MAIN APPLICATION
addappid(2906930)
addappid(3009580)
addappid(3032880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906931, 1, "9f1221beec8dffe82cbf83a8e017f9032bc89e2e3f52c67c93d12ff3fcb8c222")

