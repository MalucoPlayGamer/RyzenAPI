-- Lua provided by RyzenAPI
-- Game: AppID 927380

-- MAIN APPLICATION
addappid(927380)
addappid(1030500)

-- MAIN APP DEPOTS / PACKAGES
addappid(927381, 1, "23ab2918d89de8bcea11ba1517ea120e1c8bc8ef188f22abefeb07765362193c")
addappid(927382, 1, "5fab821dbe4cb51d6cede5ab01323beb934e97d7234cd006748536c657693c54")

