-- Lua provided by RyzenAPI
-- Game: Game: Fossil Corner

-- MAIN APPLICATION
addappid(1587710)
-- Game: addappid(1587710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587711, 1, "1f718d056d6f622919b53882304a499a4794d181397d7ca7838d133b587406a4")
addappid(1587712, 1, "ee273a0fa52d2c1ff0fcdde2f179f3e21da03e85315dfe273ca05f34214586ab")
