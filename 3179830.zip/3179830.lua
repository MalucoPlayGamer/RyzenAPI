-- Lua provided by SkyAPI 
-- Game: ShoppingMall: Manager Simulator
addappid(3179830)
addappid(3179831, 1, "20720b550f41957b8e6f153a2e61b70bd42ca15735bedd0ca7ee4c0208b20725")
