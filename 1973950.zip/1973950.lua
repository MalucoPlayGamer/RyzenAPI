-- Lua provided by RyzenAPI
-- Game: 1973950

-- MAIN APPLICATION
addappid(1973950)
-- Game: addappid(1973950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973951, 1, "5fdc2657fcc46d4d8be9fc746e2539c2b81b63b9611caf7cc4e990538687bdd8")
