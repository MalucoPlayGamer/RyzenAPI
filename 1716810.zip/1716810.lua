-- Lua provided by RyzenAPI
-- Game: Game: AppID 1716810

-- MAIN APPLICATION
addappid(1716810)
-- Game: addappid(1716810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716811, 1, "f324069d89d410a9de577a484396da3798659d5bafedc1640052dbfca1968db6")
