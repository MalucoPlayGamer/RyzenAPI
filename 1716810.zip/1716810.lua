-- Lua provided by RyzenAPI
-- Game: Herodes

-- MAIN APPLICATION
addappid(1716810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1716811, 1, "f324069d89d410a9de577a484396da3798659d5bafedc1640052dbfca1968db6")

