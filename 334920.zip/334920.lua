-- Lua provided by RyzenAPI
-- Game: AppID 334920

-- MAIN APPLICATION
addappid(334920)

-- MAIN APP DEPOTS / PACKAGES
addappid(334921, 1, "c0eb74e9aa418970fb1f834173b9bbbd598920ca9d17ca742d3f2b4421f73fe8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(842950)
addappid(842951)
addappid(842952)
