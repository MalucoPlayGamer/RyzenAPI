-- Lua provided by RyzenAPI
-- Game: AppID 334920

-- MAIN APPLICATION
addappid(334920)

-- MAIN APP DEPOTS / PACKAGES
addappid(334921, 1, "c0eb74e9aa418970fb1f834173b9bbbd598920ca9d17ca742d3f2b4421f73fe8")

