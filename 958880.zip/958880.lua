-- Lua provided by RyzenAPI
-- Game: addappid(958880)

-- MAIN APPLICATION
addappid(958880)

-- MAIN APP DEPOTS / PACKAGES
addappid(958881, 1, "008ece755dbb64bde307d41ee7ac680c3a35c85c811b28c0115667b4569997ca")
