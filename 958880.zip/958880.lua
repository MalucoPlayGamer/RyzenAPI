-- Lua provided by RyzenAPI
-- Game: Game: Nick Bounty and the Dame with the Blue Chewed Shoe

-- MAIN APPLICATION
addappid(958880)
-- Game: addappid(958880)

-- MAIN APP DEPOTS / PACKAGES
addappid(958881, 1, "008ece755dbb64bde307d41ee7ac680c3a35c85c811b28c0115667b4569997ca")
