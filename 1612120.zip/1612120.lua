-- Lua provided by RyzenAPI
-- Game: 1612120

-- MAIN APPLICATION
addappid(1612120)
-- Game: addappid(1612120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612121, 1, "34aa8e02ba3ac351621d81da6a507f7576ea0b1ba8c00328319eab56e36ab227")
