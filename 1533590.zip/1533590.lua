-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1533590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533593,0,"94b0bc67d00a32214219bf801ab2ef3b01a23a7003d1f0457d18f4a7b8cc0c11")

