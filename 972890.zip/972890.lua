-- Lua provided by RyzenAPI
-- Game: AppID 972890

-- MAIN APPLICATION
addappid(972890)
addappid(1002620)
-- Game: addappid(972890)

-- MAIN APP DEPOTS / PACKAGES
addappid(972891, 1, "3b168fa19b6a9aae2c69572752727c27c39263675255f6d443426080c4f5f9c5")
