-- Lua provided by RyzenAPI 
-- Game: Kink.inc [18+]
addappid(2190210)
addappid(2190211, 1, "7d793617880d4c2500640d0f32578a3b3c7106686d680d031f2cd28b3cad3f1e")
