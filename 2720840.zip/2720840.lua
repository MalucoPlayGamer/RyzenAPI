-- Lua provided by RyzenAPI
-- Game: Hentai Nekomimi

-- MAIN APPLICATION
addappid(2720840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720841, 1, "38342eb233454df41e59b4653d4f0fc0f12fa9e3523f86e307f39233ee768d50")
