-- Lua provided by RyzenAPI
-- Game: Below the Surface:Uncovering the Truth in the Sewers

-- MAIN APPLICATION
addappid(2391420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391421, 1, "e68c9cc6925b6c9df9bbc11fbddcb65a8efc63d95726df346cf499d3393860a5")
