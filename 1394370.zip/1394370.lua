-- Lua provided by RyzenAPI
-- Game: Super Symbol Boys

-- MAIN APPLICATION
addappid(1394370)
-- Game: addappid(1394370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394371, 1, "244341e344cfffe449345b241cb5cc7105c99ee3d6983c7fed081b75806d2250")
