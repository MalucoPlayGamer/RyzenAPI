-- Lua provided by RyzenAPI
-- Game: addappid(1394370)

-- MAIN APPLICATION
addappid(1394370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394371, 1, "244341e344cfffe449345b241cb5cc7105c99ee3d6983c7fed081b75806d2250")
