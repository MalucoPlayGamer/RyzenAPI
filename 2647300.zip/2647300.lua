-- Lua provided by RyzenAPI 
-- Game: Meow Moments: Celebrating Together
addappid(2647300)
addappid(2647301, 1, "a5d10d130630f4e9b34cf956a5118d55e2fafd6978d99a49d3b9d2b7d4207ea5")
addappid(2647302, 1, "36851d04f9a9ec35de5c8ec8d504c0f67bb9f837d8588e4cf1a3d0256463633e")
