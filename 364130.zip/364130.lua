-- Lua provided by RyzenAPI
-- Game: addappid(364130)

-- MAIN APPLICATION
addappid(364130)

-- MAIN APP DEPOTS / PACKAGES
addappid(364132,0,"35ba36181969dc2b5a84659a8b7c54d05fc841891af4fafe563b2a0d1f5c91a9")
