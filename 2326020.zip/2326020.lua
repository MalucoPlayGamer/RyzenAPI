-- Lua provided by RyzenAPI
-- Game: addappid(2326020)

-- MAIN APPLICATION
addappid(2326020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326021, 1, "217474f17706ba9ee5184850f29dbefa1def8f9a8438ac54db87847d57fa7c30")
