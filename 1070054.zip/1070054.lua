-- Lua provided by RyzenAPI
-- Game: Crystar - Rei's Santa Costume

-- MAIN APPLICATION
addappid(1070054)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070054,0,"91cefd5049aa6879c1a4c2c45ab693228db00a9757c0e901151ef1338b44ef42")

