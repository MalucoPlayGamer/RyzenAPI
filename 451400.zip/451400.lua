-- Lua provided by RyzenAPI
-- Game: Meridian: Squad 22

-- MAIN APPLICATION
addappid(451400)

-- MAIN APP DEPOTS / PACKAGES
addappid(451401, 1, "1761f210f6d5e06db2b6c3919a7b7a6faac2bebf9827dfa20bc125da4484a945")
addappid(486960, 0, "9ecd88af4e1805f72e3f4a202b5ff0f9dddf58930c580d267d42381c2d98fb8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
