-- Lua provided by RyzenAPI
-- Game: Meridian: Squad 22

-- MAIN APPLICATION
addappid(451400)

-- MAIN APP DEPOTS / PACKAGES
addappid(451401, 1, "1761f210f6d5e06db2b6c3919a7b7a6faac2bebf9827dfa20bc125da4484a945")
addappid(486960, 0, "9ecd88af4e1805f72e3f4a202b5ff0f9dddf58930c580d267d42381c2d98fb8a")
