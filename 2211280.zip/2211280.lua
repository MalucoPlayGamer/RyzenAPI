-- Lua provided by RyzenAPI
-- Game: Game: AppID 2211280

-- MAIN APPLICATION
addappid(2211280)
-- Game: addappid(2211280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211281, 1, "ef443af54e8ec6946086891aff341b074b73673288c88fdb89794f48e193f1c7")
