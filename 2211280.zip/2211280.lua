-- Lua provided by RyzenAPI
-- Game: Roller Champions™

-- MAIN APPLICATION
addappid(2211280)
addappid(2212900)
addappid(2212901)
addappid(2212902)
addappid(2212903)
addappid(2236160)
addappid(2369340)
addappid(2369341)
addappid(2369342)
addappid(2369343)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2211281, 1, "ef443af54e8ec6946086891aff341b074b73673288c88fdb89794f48e193f1c7")
