-- Lua provided by RyzenAPI
-- Game: METAL SLUG XX

-- MAIN APPLICATION
addappid(975680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(975681, 1, "21f6fbebee5780b9d663651af3112f8f440fe42ac4cb833d0ca31f9ff6498ded")

