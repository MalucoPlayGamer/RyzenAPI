-- Lua provided by RyzenAPI
-- Game: AppID 975680

-- MAIN APPLICATION
addappid(975680)

-- MAIN APP DEPOTS / PACKAGES
addappid(975681, 1, "21f6fbebee5780b9d663651af3112f8f440fe42ac4cb833d0ca31f9ff6498ded")

