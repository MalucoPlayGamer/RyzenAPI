-- Lua provided by RyzenAPI 
-- Game: VR Dunhuang
addappid(752200)
addappid(752201, 1, "2e0d62d2438396e91b184473fe3d68263b4c9e6ca7b355cb8f32aabd4cedb04f")
