-- Lua provided by RyzenAPI
-- Game: Game: VR Dunhuang

-- MAIN APPLICATION
addappid(752200)
-- Game: addappid(752200)

-- MAIN APP DEPOTS / PACKAGES
addappid(752201, 1, "2e0d62d2438396e91b184473fe3d68263b4c9e6ca7b355cb8f32aabd4cedb04f")
