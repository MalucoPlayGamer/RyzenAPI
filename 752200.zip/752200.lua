-- Lua provided by RyzenAPI
-- Game: VR Dunhuang

-- MAIN APPLICATION
addappid(752200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(752201, 1, "2e0d62d2438396e91b184473fe3d68263b4c9e6ca7b355cb8f32aabd4cedb04f")

