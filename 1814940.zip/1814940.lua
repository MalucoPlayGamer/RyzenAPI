-- Lua provided by SkyAPI 
-- Game: Kurokami-sama's Feast Demo
addappid(1814940)
addappid(1814941, 1, "9f998cc3bb53821d62c4cf30724bb4b9feeea6fdbd3041b4c4b6d9a4dfe1da72")
