-- Lua provided by RyzenAPI
-- Game: Kurokami-sama's Feast Demo

-- MAIN APPLICATION
addappid(1814940)
-- Game: addappid(1814940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814941, 1, "9f998cc3bb53821d62c4cf30724bb4b9feeea6fdbd3041b4c4b6d9a4dfe1da72")
