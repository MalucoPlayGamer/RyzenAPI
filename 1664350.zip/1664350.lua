-- Lua provided by RyzenAPI
-- Game: 1664350

-- MAIN APPLICATION
addappid(1664350)
-- Game: addappid(1664350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664351, 1, "ba300182f7eda5b76de50704866e94b893bcbb4b8172378c2d3bfe87568df0d2")
