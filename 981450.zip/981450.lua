-- Lua provided by RyzenAPI
-- Game: Game: AppID 981450

-- MAIN APPLICATION
addappid(981450)
-- Game: addappid(981450)

-- MAIN APP DEPOTS / PACKAGES
addappid(981451, 1, "1cde1b1bebedef73026195d3673d24c784fb91b77599dc8503ae907ea355df41")
