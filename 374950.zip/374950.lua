-- Lua provided by RyzenAPI
-- Game: Game: ADventure Lib

-- MAIN APPLICATION
addappid(374950)
-- Game: addappid(374950)

-- MAIN APP DEPOTS / PACKAGES
addappid(374951, 1, "8b5cac17fc9c9378a4ae3568407e0c4a2eadce458a39dfbfe94d506536f2496b")
addappid(374952, 1, "0befcd62d945a2b9baaec05d5f20915b2e5074799b310a1b526fff8a61652419")
addappid(374953, 1, "87f076a8972d572e08cd858f9ebfb729ea1236f7a9db30f7e79c783e9eb21d1e")
addappid(374954, 1, "a51198648d480ac1ee9350930999f13024db227a0ac95beefcedc4fe9cce1066")
addappid(390120, 0, "5b9277a3e280133f621a1370b819c290f2976b1c8ae5d49d0fd11e081d79747d")
