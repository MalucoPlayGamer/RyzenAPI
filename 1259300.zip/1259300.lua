-- Lua provided by RyzenAPI
-- Game: Game: AppID 1259300

-- MAIN APPLICATION
addappid(1259300)
-- Game: addappid(1259300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259301, 1, "85a230f9ae19c1025ff3fe4ee9c1bcf09a2ca387377de6ca60823ad67d01bef9")
