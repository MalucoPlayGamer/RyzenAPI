-- Lua provided by RyzenAPI 
-- Game: AppID 1259300
addappid(1259300)
addappid(1259301, 1, "85a230f9ae19c1025ff3fe4ee9c1bcf09a2ca387377de6ca60823ad67d01bef9")
