-- Lua provided by RyzenAPI
-- Game: Warlock's Tower

-- MAIN APPLICATION
addappid(530370)

-- MAIN APP DEPOTS / PACKAGES
addappid(530371,0,"ce5b889a2d52a55a6436e04a4594ef6f6f3a64d37da9bc7751205275c596b531")
addappid(530372,0,"bd68cd05bbb9ceae61e7655129d35e28bc048e686b303cd5c93d130026626db5")

