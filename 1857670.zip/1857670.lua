-- Lua provided by RyzenAPI
-- Game: Block Collide Soundtrack

-- MAIN APPLICATION
addappid(1857670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857671, 1, "547b1596889e60bf70e737fa38035a2bec84b0dc132aa0edbf32e282a909a90c")
addappid(1857672, 1, "804e37c6d8e857598b59b8bad62c4f28649d8674eb24433f53d39ee91afa8f3e")
addappid(1857673, 1, "74982b03a9f5ab97453e9b5bab627fda1d403a9eac91550638215caee6df1734")
addappid(1857674, 1, "76c436799aeb8fcd81250bd12f5b115c93b21f8a0c722fc17de9f37c679d1dfe")
