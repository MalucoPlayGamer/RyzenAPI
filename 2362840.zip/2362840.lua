-- Lua provided by RyzenAPI
-- Game: Kingsblade: King's Keep Prologue

-- MAIN APPLICATION
addappid(2362840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362841, 1, "95cfeb88c87aa2d942c9bf25f6b669015bcca3f90370d06bb8f6ea7af63df8e3")
