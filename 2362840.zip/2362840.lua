-- Lua provided by SkyAPI 
-- Game: Kingsblade: King's Keep Prologue
addappid(2362840)
addappid(2362841, 1, "95cfeb88c87aa2d942c9bf25f6b669015bcca3f90370d06bb8f6ea7af63df8e3")
