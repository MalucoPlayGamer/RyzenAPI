-- Lua provided by RyzenAPI
-- Game: Game: AppID 407780

-- MAIN APPLICATION
addappid(407780)
-- Game: addappid(407780)

-- MAIN APP DEPOTS / PACKAGES
addappid(407781, 1, "9f698cbfb1fce3f30a8849e3abaf8c413436f2d6643d7e848133ac8a52e75d12")
