-- Lua provided by RyzenAPI
-- Game: DON'T EXIST

-- MAIN APPLICATION
addappid(2892660)
-- Game: addappid(2892660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892661, 1, "48e6575cce687151a9a7d7f65aeac4df280f5aa3848fa1e1c4fe0de49369e2c3")
