-- Lua provided by RyzenAPI
-- Game: DON'T EXIST

-- MAIN APPLICATION
addappid(2892660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892661, 1, "48e6575cce687151a9a7d7f65aeac4df280f5aa3848fa1e1c4fe0de49369e2c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
