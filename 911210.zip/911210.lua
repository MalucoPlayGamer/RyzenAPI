-- Lua provided by RyzenAPI
-- Game: 911210

-- MAIN APPLICATION
addappid(911210)
-- Game: addappid(911210)

-- MAIN APP DEPOTS / PACKAGES
addappid(911211, 1, "2c585fe4ce8e4cd220b67499960cfc679c3dfdb8445a971b1415b39855e56f82")
