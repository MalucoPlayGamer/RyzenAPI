-- Lua provided by RyzenAPI
-- Game: Gori: Cuddly Carnage Soundtrack

-- MAIN APPLICATION
addappid(1364190)
-- Game: addappid(1364190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364191, 1, "28f0189cdd9fa2b250e9ebcc6bc701ff6a8168c99510ee53d09638477c0f1a90")
addappid(1364192, 1, "743c392f86a4df773dd4dc707943b70667743a68c5f5dc2ab1c5717de8a2078a")
