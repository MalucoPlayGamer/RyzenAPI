-- Lua provided by RyzenAPI
-- Game: Moonless Moon

-- MAIN APPLICATION
addappid(2951340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951341, 1, "e5ec31bf76f5b0fdf48d86c41d9cf32fd29ed56b24cd14cbced556b67283adca")

