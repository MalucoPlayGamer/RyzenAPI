-- Lua provided by RyzenAPI
-- Game: Game: Knights of the Kitchen Table

-- MAIN APPLICATION
addappid(2016210)
-- Game: addappid(2016210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016211, 1, "50699f66a64078f29b4bc327473be88f499faf8e5c5eb53fcc1f2126e6ac9478")
