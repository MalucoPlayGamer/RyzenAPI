-- Lua provided by RyzenAPI
-- Game: Dungeon of the ENDLESS™

-- MAIN APPLICATION
addappid(249050)

-- MAIN APP DEPOTS / PACKAGES
addappid(249051, 1, "6d80e58f49ef3fb5f2851a475f109b1361bc5469b710248e1bc4af4c6a9d844c")
addappid(249052, 1, "ab875e1bf4fe5a00a49921e8030ee08a00cd01b3bf7264b581feceac5187db38")
addappid(249053, 1, "ea27923e33a1d9af43aa64d75080b5596701aa4d57d31466683f5e6d6d5e225d")
addappid(249054, 1, "74e06f815f5e1b84a906f41eeb6de78ba8cbf0c109db319bbb7aa0d6a30bbf39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(268080)
addappid(268081)
addappid(268082)
addappid(349770)
addappid(365940)
addappid(407200)
addappid(407210)
addappid(410940)
addappid(744930)
