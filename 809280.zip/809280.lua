-- Lua provided by RyzenAPI
-- Game: 809280

-- MAIN APPLICATION
addappid(809280)
addappid(809281)
addappid(809282)

-- MAIN APP DEPOTS / PACKAGES
addappid(910620,0,"7b6a5bd9dd180694431aa9fbdc4fe4be1f0aaec5ef9f48e706ad2318443c29ff")
