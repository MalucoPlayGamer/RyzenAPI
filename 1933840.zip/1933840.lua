-- Lua provided by RyzenAPI
-- Game: Game: Moon Mystery

-- MAIN APPLICATION
addappid(1933840)
-- Game: addappid(1933840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933841, 1, "efebc1963fbdfda1f875c52ed63f479308c90da6d38aae8ba37cc889d44dc171")
