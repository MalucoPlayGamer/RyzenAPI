-- Lua provided by RyzenAPI
-- Game: Moon Mystery

-- MAIN APPLICATION
addappid(1933840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933841, 1, "efebc1963fbdfda1f875c52ed63f479308c90da6d38aae8ba37cc889d44dc171")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
