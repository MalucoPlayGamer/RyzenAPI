-- Lua provided by RyzenAPI
-- Game: Bed Lying Simulator: Girlfriend Experience

-- MAIN APPLICATION
addappid(1220610)
-- Game: addappid(1220610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220610,0,"d175449f9f0c12de1a1d1d2ddcdae29e71555701d6369aa2faad4e64a8f31327")
