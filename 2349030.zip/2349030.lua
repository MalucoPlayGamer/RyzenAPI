-- Lua provided by RyzenAPI
-- Game: B-PROJECT RYUSEI*FANTASIA

-- MAIN APPLICATION
addappid(2349030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2349031, 1, "b8d31ab3d71383bde937f2247c59fa4cad0c36411fe8eeb9decdf18424ae08bb")

