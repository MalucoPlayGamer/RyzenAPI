-- Lua provided by SkyAPI 
-- Game: B-PROJECT RYUSEI*FANTASIA
addappid(2349030)
addappid(2349031, 1, "b8d31ab3d71383bde937f2247c59fa4cad0c36411fe8eeb9decdf18424ae08bb")
