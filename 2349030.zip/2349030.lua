-- Lua provided by RyzenAPI
-- Game: B-PROJECT RYUSEI*FANTASIA

-- MAIN APPLICATION
addappid(2349030)
-- Game: addappid(2349030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349031, 1, "b8d31ab3d71383bde937f2247c59fa4cad0c36411fe8eeb9decdf18424ae08bb")
