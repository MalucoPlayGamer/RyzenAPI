-- Lua provided by RyzenAPI
-- Game: Vitamins

-- MAIN APPLICATION
addappid(2187210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187211, 1, "6c331d58e93aab02845c3419f2f01983d700f0eb63758c8d93e369395b191ee7")

