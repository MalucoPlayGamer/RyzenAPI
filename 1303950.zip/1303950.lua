-- Lua provided by RyzenAPI
-- Game: Toodee and Topdee

-- MAIN APPLICATION
addappid(1303950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303951, 1, "e4cfad84990f84df00ec7820f7c83d9162c29fb0e082b38c502625c797de31f4")
