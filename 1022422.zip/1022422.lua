-- Lua provided by RyzenAPI
-- Game: 1022422

-- MAIN APPLICATION
addappid(1022422)
-- Game: addappid(1022422)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022422,0,"77f00f1a016a9fdc72b71fa329af4548fafbcc2189f998d818c8e7bd390ddab1")
