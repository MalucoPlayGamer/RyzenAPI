-- Lua provided by SkyAPI 
-- Game: AppID 3111790
addappid(3111790)
addappid(3111791, 1, "959f6b4afed42ec25bab260da1a93b5b6cc402e3a2626fb1bb27e6ed0adce733")
