-- Lua provided by RyzenAPI
-- Game: AppID 3111790

-- MAIN APPLICATION
addappid(3111790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111791, 1, "959f6b4afed42ec25bab260da1a93b5b6cc402e3a2626fb1bb27e6ed0adce733")

