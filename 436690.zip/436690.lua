-- Lua provided by SkyAPI 
-- Game: AppID 436690
addappid(436690)
addappid(436691, 1, "48e1efa21c2d1f4784f17f7709f12bf74e3be774e81c53355a1a8042fcd82342")
