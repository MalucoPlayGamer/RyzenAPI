-- Lua provided by RyzenAPI
-- Game: The Book of Legends

-- MAIN APPLICATION
addappid(277470)

-- MAIN APP DEPOTS / PACKAGES
addappid(277471, 1, "507fe37b0976fa89dfa50cb8825fbf5138b1683bd8876aad0425f44e7a51095a")
addappid(366750, 0, "5c48714d0b70d8795b1fe324a7ba6513836a08006a955b4cb422b880cf0d44f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
