-- Lua provided by SkyAPI 
-- Game: The Book of Legends
addappid(277470)
addappid(277471, 1, "507fe37b0976fa89dfa50cb8825fbf5138b1683bd8876aad0425f44e7a51095a")
addappid(366750, 0, "5c48714d0b70d8795b1fe324a7ba6513836a08006a955b4cb422b880cf0d44f9")
