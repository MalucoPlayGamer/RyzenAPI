-- Lua provided by RyzenAPI
-- Game: Age of Steel: Recharge

-- MAIN APPLICATION
addappid(421060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(421061, 1, "588449e6f85b7679e1578f788c105c2703a295ba629700cb00e2adacddaf114a")
addappid(421062, 1, "605b6eaf793d3fe6d51047bce1b9eff528ba8fb9337590d4444bc5b60d845e7e")
addappid(421063, 1, "d84cc4e8dcb55d36efd4a3610371338c1f6d134a86cb844b7c2d1267d75e6f0e")
addappid(447250, 0, "6908218c0dfe950d447b8c33bf691b79e136eabd453124724c49b097c12a494c")
