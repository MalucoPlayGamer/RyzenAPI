-- Lua provided by RyzenAPI
-- Game: AppID 410950

-- MAIN APPLICATION
addappid(410950)
-- Game: addappid(410950)

-- MAIN APP DEPOTS / PACKAGES
addappid(410951, 1, "e1b9d60588cf199f17af5741adff3f1052a85706bd212497c08a0fcc1cea63c8")
