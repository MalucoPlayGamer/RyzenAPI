-- Lua provided by RyzenAPI
-- Game: Legend of Ares

-- MAIN APPLICATION
addappid(536950)
-- Game: addappid(536950)

-- MAIN APP DEPOTS / PACKAGES
addappid(536951, 1, "5c1ba09857a7fbd2f723ccffc60daba30edd7933ec003ba2f2d6a3945c73ddc7")
