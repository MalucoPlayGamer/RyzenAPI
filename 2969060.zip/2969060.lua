-- Lua provided by RyzenAPI
-- Game: Casino Island Simulator

-- MAIN APPLICATION
addappid(2969060)
-- Game: addappid(2969060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969061, 1, "883f95c6349db665575617618e868395ae0f708668dc74134c082b88ba0bdeb0")
