-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 2: Lost Legends & the Secret Fairy DX

-- MAIN APPLICATION
addappid(3365040)
addappid(3782460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365041,0,"d598945b8eadbb0ec9bad54928aeaa1549a79faa8df45f1d1d6d83c0d5127cbd")

