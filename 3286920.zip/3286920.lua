-- Lua provided by SkyAPI 
-- Game: AppID 3286920
addappid(3286920)
addappid(3286921, 1, "719bd19a05e901ad5a680922354b3addf2743a86fcdf1074207e16776e4c4c09")
