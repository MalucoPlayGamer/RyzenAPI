-- Lua provided by RyzenAPI
-- Game: Bugaboo Pocket Demo

-- MAIN APPLICATION
addappid(2413400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413401, 1, "fb652c68af68eef9a1662bfc6e09c84d07dcae9c0427210e1598bb6fc824c175")

