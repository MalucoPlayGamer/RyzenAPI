-- Lua provided by RyzenAPI
-- Game: Game: Huge Jaws

-- MAIN APPLICATION
addappid(2137600)
-- Game: addappid(2137600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137601, 1, "19075b72dc6b43afe8b7339991bc9d7e8fcf3f8dd6d7ae9e832624bf1e1b8c99")
