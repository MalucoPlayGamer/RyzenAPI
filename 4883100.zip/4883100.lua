-- Lua provided by RyzenAPI
-- Game: Unwanted Experiment

-- MAIN APPLICATION
addappid(4883100) -- Unwanted Experiment

-- MAIN APP DEPOTS / PACKAGES
addappid(4883101, 1, "03b50a171d0400e3cafb4df9d3fce88edd1d5ab7f7b24dbd7d104e7ff9380414") -- Depot 4883101
