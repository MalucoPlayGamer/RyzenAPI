-- Lua provided by RyzenAPI 
-- Game: road of death
addappid(2784240)
addappid(2784241, 1, "592be5fcac2eee15a3b729852a1d0c9a5f1d448bb525c07603c85f7d6bfa1845")
