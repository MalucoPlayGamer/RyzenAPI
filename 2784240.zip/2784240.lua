-- Lua provided by RyzenAPI
-- Game: Game: road of death

-- MAIN APPLICATION
addappid(2784240)
-- Game: addappid(2784240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784241, 1, "592be5fcac2eee15a3b729852a1d0c9a5f1d448bb525c07603c85f7d6bfa1845")
