-- Lua provided by RyzenAPI
-- Game: Fear & Hunger 2: Termina

-- MAIN APPLICATION
addappid(2171440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171441, 1, "7a46cff961d9fa3f623ea26bfbdedf875b01cee8fe35a1cd5310a5e796e094a9")
