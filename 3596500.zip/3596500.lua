-- Lua provided by RyzenAPI
-- Game: Coffee & Boobs - Wallpapers Pack

-- MAIN APPLICATION
addappid(3596500)
-- Game: addappid(3596500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596500,0,"1b6f0256a913f3905de0ac2018bfcd862b70547dda9376018d83c2f575de081e")
