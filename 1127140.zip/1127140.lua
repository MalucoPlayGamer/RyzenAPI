-- Lua provided by RyzenAPI 
-- Game: AppID 1127140
addappid(1127140)
addappid(1127141, 1, "8db4ebb38572552502bb5d3dd6b4c693224ee637ad0d2b62a4cf7fa9b9da6cc6")
addappid(1173560)
addappid(1173580)
