-- Lua provided by RyzenAPI
-- Game: Paradise Marsh Demo

-- MAIN APPLICATION
addappid(2008690)
-- Game: addappid(2008690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008691, 1, "8088439930d96c94b2926380fffc4b70c2b16505a5acded82c399bbb1826d3e9")
