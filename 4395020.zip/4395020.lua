-- 4395020's Lua and Manifest Created by Hubcap Manifest
-- Chronicles of Clams Island
-- Created: August 15, 2026 at 14:51:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4395020, 1, "600db0296404f647d557502bb3a534cc2256fb415f241a2eb85766042069e107") -- Chronicles of Clams Island
-- MAIN APP DEPOTS
addappid(4395021, 1, "2e2e18377e9870220efccc360b61acaf33dd63dd6f51cb2437f555f873b50bae") -- Depot 4395021
setManifestid(4395021, "5430530681523331712", 1019585594)
addappid(4395022, 1, "2c47304e20acc8ef1252f74be50a74f69bcb990684d2a440b4b4fca11a3050a2") -- Depot 4395022
setManifestid(4395022, "5148772609785021482", 1019782375)
addappid(4395023, 1, "785eba56b07a5e40c88d22be8b9381face6eba270dc20e8c4c3179e6e3fffe29") -- Depot 4395023
setManifestid(4395023, "3078890841223969388", 1029580684)
addappid(4395024, 1, "90d23c5ea802e2b5bd2cf27acb8c05626379fdb6c2a223f738859398010ebe5d") -- Depot 4395024
setManifestid(4395024, "1494333625389979721", 1026013643)