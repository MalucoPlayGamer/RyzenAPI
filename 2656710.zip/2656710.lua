-- Lua provided by RyzenAPI 
-- Game: Fantasy Blacksmith Shop Simulator
addappid(2656710)
addappid(2656711, 1, "9874530ae0c85c7d29bf4ad6a073312de0da0c7c2c2269b367a5dd5a88d26863")
