-- Lua provided by RyzenAPI
-- Game: Game: Sword and Fairy 5: Original soundtrack collection

-- MAIN APPLICATION
addappid(1637980)
-- Game: addappid(1637980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637981, 1, "c04cdb7be3c0fa5570e6720ab3ee2315d09da5ade60c4c7d6d1442ef94c2d37d")
addappid(1637982, 1, "6578d6fc44555852bf06463292459ff9c63f33a13bf894f9fce52d4947c4e110")
