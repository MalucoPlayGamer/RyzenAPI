-- Lua provided by RyzenAPI
-- Game: CORPUS EDAX

-- MAIN APPLICATION
addappid(2017610)
-- Game: addappid(2017610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017611, 1, "1ef4f53fafeab2bca07a911a0cc4e1eca9200f8e4cb854d04add3e8ee9450f5f")
