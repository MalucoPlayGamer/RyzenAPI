-- Lua provided by RyzenAPI
-- Game: addappid(2631610)

-- MAIN APPLICATION
addappid(2631610)
addappid(2850710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631611, 1, "53864406cd892210a85246a9b7f4d76b24da9388c552b7dd3ac11eaf8c7b2207")
