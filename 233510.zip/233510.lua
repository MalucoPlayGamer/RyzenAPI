-- Lua provided by RyzenAPI
-- Game: Game: Lunnye Devitsy

-- MAIN APPLICATION
addappid(233510)
-- Game: addappid(233510)

-- MAIN APP DEPOTS / PACKAGES
addappid(233511, 1, "26830347ba5cc40f6d0f922e1771f447965433055277af31264db3d267059dfe")
