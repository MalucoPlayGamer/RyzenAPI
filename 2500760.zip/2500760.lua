-- Lua provided by RyzenAPI
-- Game: addappid(2500760)

-- MAIN APPLICATION
addappid(2500760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500761, 1, "b432c4b4698ac40f06747c27df1f937edd6bf2ad4902deaf4dc1da4ef5f4d56e")
