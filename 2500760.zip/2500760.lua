-- Lua provided by RyzenAPI
-- Game: かぞえ飯

-- MAIN APPLICATION
addappid(2500760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2500761, 1, "b432c4b4698ac40f06747c27df1f937edd6bf2ad4902deaf4dc1da4ef5f4d56e")

