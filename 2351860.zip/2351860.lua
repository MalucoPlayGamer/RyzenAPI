-- Lua provided by RyzenAPI
-- Game: Tower of Kalemonvo

-- MAIN APPLICATION
addappid(2351860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351861, 1, "ddcb15054e2dd0d3cb7cb9835f66f9cf3171a3a60800a079bff419f95d539276")
