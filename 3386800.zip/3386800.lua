-- Lua provided by RyzenAPI
-- Game: TheSilentSnowfall

-- MAIN APPLICATION
addappid(3386800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386801, 1, "71e358eb4bc2f92515514e0cfb418b2d86129a9f133bcc01f867f4108c17ec1c")

