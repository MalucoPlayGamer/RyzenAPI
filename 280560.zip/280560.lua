-- Lua provided by RyzenAPI
-- Game: Game: Danmaku Unlimited 2

-- MAIN APPLICATION
addappid(280560)
-- Game: addappid(280560)

-- MAIN APP DEPOTS / PACKAGES
addappid(280561, 1, "96a116a184cd8995741650a5a1e4fc8b5dcb0c778aa52fbf9219afc0f1b15056")
