-- Lua provided by RyzenAPI
-- Game: Danmaku Unlimited 2

-- MAIN APPLICATION
addappid(280560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(280561, 1, "96a116a184cd8995741650a5a1e4fc8b5dcb0c778aa52fbf9219afc0f1b15056")

