-- Lua provided by SkyAPI 
-- Game: AppID 754130
addappid(754130)
addappid(754131, 1, "eeb2125ab7c1105815f797d1a0007466d0038a9e1a3fd2db77044d3c0db0c60f")
