-- Lua provided by RyzenAPI
-- Game: FMatheg

-- MAIN APPLICATION
addappid(754130)

-- MAIN APP DEPOTS / PACKAGES
addappid(754131, 1, "eeb2125ab7c1105815f797d1a0007466d0038a9e1a3fd2db77044d3c0db0c60f")

