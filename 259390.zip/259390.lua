-- Lua provided by RyzenAPI
-- Game: Game: Ballpoint Universe - Infinite

-- MAIN APPLICATION
addappid(259390)
-- Game: addappid(259390)

-- MAIN APP DEPOTS / PACKAGES
addappid(259391, 1, "e5196c15800f75a62bc4877d4f0b549c9cea2983116031388d8bdcde46b290d0")
addappid(259392, 1, "8af2811469c7e9f4b07d93cf2deec9de7e6010492ec7d35eeae2d3a1822b66c2")
addappid(259393, 1, "f1415e48989be39885790ec35f0d2c7c6eb369a298ff03d6f133b311dee5fd08")
addappid(259394, 1, "d9a477e79eca2e5713e1b586d60c42e07e8c08926e333bd4d8a76817f5c5dc63")
addappid(259395, 1, "fa3ae7861ec08ca4870d628f6caa3e9b3084b635c21c651cd566eb3a1a107690")
