-- Lua provided by RyzenAPI
-- Game: Brawl Tactics: Origins

-- MAIN APPLICATION
addappid(2451820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451821, 1, "857358a6d9e969cf5ea810e4dc61ee281d2971af4e2925580d0655a0e97ec23d")
