-- Lua provided by RyzenAPI
-- Game: addappid(1769090)

-- MAIN APPLICATION
addappid(1769090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769091, 1, "2fc0e5f03fec93af320ac2c09debd5da2919728a57652ba672c8d1d2dbe949f5")
