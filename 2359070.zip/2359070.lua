-- Lua provided by RyzenAPI
-- Game: Waifu Puzzles

-- MAIN APPLICATION
addappid(2359070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359071, 1, "64f2428c5cfcb12c1e65f7f5df3846cfbc4e9b53c1d0cec5177bde34f071ea4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
