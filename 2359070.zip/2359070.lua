-- Lua provided by SkyAPI 
-- Game: Waifu Puzzles
addappid(2359070)
addappid(2359071, 1, "64f2428c5cfcb12c1e65f7f5df3846cfbc4e9b53c1d0cec5177bde34f071ea4d")
