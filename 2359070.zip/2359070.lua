-- Lua provided by RyzenAPI
-- Game: Waifu Puzzles

-- MAIN APPLICATION
addappid(2359070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359071, 1, "64f2428c5cfcb12c1e65f7f5df3846cfbc4e9b53c1d0cec5177bde34f071ea4d")
