-- Lua provided by RyzenAPI
-- Game: Beat Saber - BTS - "Burning Up (Fire)"

-- MAIN APPLICATION
addappid(1463220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463221, 1, "09d2994029d6f7f8363392ef6ae332933acb9a77914b15e344514cd50d17419b")

