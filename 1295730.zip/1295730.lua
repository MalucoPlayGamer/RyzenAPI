-- Lua provided by RyzenAPI
-- Game: Leveling up girls in another world

-- MAIN APPLICATION
addappid(1295730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295731, 1, "ecd4fa55c564ffb3bcbcd3626f26a654aa0ae0eb35fd4c1743afc08997881d54")

