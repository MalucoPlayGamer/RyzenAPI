-- Lua provided by RyzenAPI
-- Game: AppID 1295730

-- MAIN APPLICATION
addappid(1295730)
-- Game: addappid(1295730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295731, 1, "ecd4fa55c564ffb3bcbcd3626f26a654aa0ae0eb35fd4c1743afc08997881d54")
