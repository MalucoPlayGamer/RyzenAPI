-- Lua provided by RyzenAPI
-- Game: Mr. Massagy

-- MAIN APPLICATION
addappid(511350)
-- Game: addappid(511350)

-- MAIN APP DEPOTS / PACKAGES
addappid(511351, 1, "391552eb44eddc603316d1fd68611b0a5a7e1c49785b4a5a72a29c6bd995dc5d")
