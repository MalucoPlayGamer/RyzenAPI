-- Lua provided by RyzenAPI
-- Game: addappid(596350)

-- MAIN APPLICATION
addappid(596350)

-- MAIN APP DEPOTS / PACKAGES
addappid(596351, 1, "b67f1d048a1fc5267115ad902396c9725598e0ac4dafcfd97c7c187c1178fd03")
addappid(596352, 1, "4e12ea6e469bad0ab943aeb7dcfc407459a76c2f05b0e2d200d038727b2b6525")
