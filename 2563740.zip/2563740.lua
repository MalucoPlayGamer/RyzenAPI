-- Lua provided by RyzenAPI
-- Game: Game: Polygons Tower Defense

-- MAIN APPLICATION
addappid(2563740)
-- Game: addappid(2563740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563741, 1, "8f6248f8e1b7a5a802ba015e002b1b3b866eb651d9c9dfb991dd898366745b90")
