-- Lua provided by RyzenAPI
-- Game: Game: Space Slam

-- MAIN APPLICATION
addappid(568480)
-- Game: addappid(568480)

-- MAIN APP DEPOTS / PACKAGES
addappid(568481, 1, "a80ea682cc007531f7864f9f8550809b7f07dc16738993790cb176510324372e")
