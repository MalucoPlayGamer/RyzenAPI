-- Lua provided by SkyAPI 
-- Game: Space Slam
addappid(568480)
addappid(568481, 1, "a80ea682cc007531f7864f9f8550809b7f07dc16738993790cb176510324372e")
