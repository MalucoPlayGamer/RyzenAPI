-- Lua provided by RyzenAPI
-- Game: Game: Morbid: The Seven Acolytes

-- MAIN APPLICATION
addappid(1140890)
-- Game: addappid(1140890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140891, 1, "b0ec00aac3da8e6d769a24a3d5359fd8145558fd397eb7d2fb41d170d29eeac1")
