-- Lua provided by RyzenAPI
-- Game: addappid(2433290)

-- MAIN APPLICATION
addappid(2433290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433291, 1, "0813b66d190e40ef206f51016b2cca9f95c4651e6ed7caa6dc0c40771b5789fb")
addappid(2433292, 1, "f0661961934190e97b5d130a917fc8c0ae8e072c1ae7cf8dfaaca17f4a0b3fa1")
