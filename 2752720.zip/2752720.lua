-- Lua provided by RyzenAPI
-- Game: Dice Player One

-- MAIN APPLICATION
addappid(2752720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752721, 1, "57ab5d7b9335b5c606559dd68d876965acce6267a2d52de0a7b8a6202479abc1")
