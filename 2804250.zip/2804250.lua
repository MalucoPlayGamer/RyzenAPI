-- Lua provided by RyzenAPI
-- Game: 2804250

-- MAIN APPLICATION
addappid(2804250)
addappid(2806000)
-- Game: addappid(2804250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804251, 1, "456e07c812ece6ea70d89b720ecff9e2087a0f2d7090a8ce3b712efd24e28b07")
