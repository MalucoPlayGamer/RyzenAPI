-- Lua provided by RyzenAPI
-- Game: AppID 423880

-- MAIN APPLICATION
addappid(423880)
addappid(425120)

-- MAIN APP DEPOTS / PACKAGES
addappid(423881, 1, "269815ad747ad5322a69f87045a342652b93e9dcd06bf5d0d843cfbd12d51fd7")

