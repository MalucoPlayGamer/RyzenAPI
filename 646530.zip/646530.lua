-- Lua provided by RyzenAPI
-- Game: Hop Step Sing! kiss×kiss×kiss (HQ Edition)

-- MAIN APPLICATION
addappid(646530)

-- MAIN APP DEPOTS / PACKAGES
addappid(646531, 1, "fdee47178c2c61e442753acbe5630140c14e0892fc8c7b578aaa4e890dba6579")

