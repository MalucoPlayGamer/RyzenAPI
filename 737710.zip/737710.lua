-- Lua provided by RyzenAPI
-- Game: Melody of Iris-虹色旋律-(Full Color ver.)

-- MAIN APPLICATION
addappid(737710)
addappid(884700)

-- MAIN APP DEPOTS / PACKAGES
addappid(737711, 1, "4309ac01c19da7ff3f3a0810f90cd3c43aeecb34f7a0f65a3b6681b4ea639721")
