-- Lua provided by RyzenAPI
-- Game: 1412960

-- MAIN APPLICATION
addappid(1412960)
-- Game: addappid(1412960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412961, 1, "580e76e551d676f8a6df58de43bd3fcea29258f0bfde407c27fe188cec19d0ba")
