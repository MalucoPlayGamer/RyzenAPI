-- Lua provided by RyzenAPI
-- Game: Without a Voice

-- MAIN APPLICATION
addappid(1262190)
