-- Lua provided by RyzenAPI
-- Game: Without a Voice

-- MAIN APPLICATION
addappid(1262190)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1262200)
