-- Lua provided by RyzenAPI 
-- Game: MeiQi 2019
addappid(1549440)
addappid(1549441, 1, "1eeb97f617672e7db870c306d53f79441bb975b222d019f65c136996381e20c0")
