-- Lua provided by RyzenAPI
-- Game: Game: Irritability & Mood Swings

-- MAIN APPLICATION
addappid(1941760)
-- Game: addappid(1941760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941761, 1, "fc610e4bef14d9216549f8e217b17d2afee63472d00ec0e5b7f1c6df60621c70")
