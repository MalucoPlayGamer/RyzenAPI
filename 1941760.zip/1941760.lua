-- Lua provided by RyzenAPI
-- Game: Irritability & Mood Swings

-- MAIN APPLICATION
addappid(1941760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941761, 1, "fc610e4bef14d9216549f8e217b17d2afee63472d00ec0e5b7f1c6df60621c70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
