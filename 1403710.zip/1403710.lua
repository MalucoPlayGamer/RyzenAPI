-- Lua provided by RyzenAPI
-- Game: 1403710

-- MAIN APPLICATION
addappid(1403710)
-- Game: addappid(1403710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403711, 1, "cf9e673bf0cc0fd94032f2202d7d14e66e4be30c5b2de2e1fdd98d8441c04322")
