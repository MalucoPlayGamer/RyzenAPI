-- Lua provided by RyzenAPI
-- Game: Game: AppID 268200

-- MAIN APPLICATION
addappid(268200)
addappid(332130)
addappid(332131)
addappid(332132)
addappid(332133)
addappid(335980)
addappid(335981)
addappid(335982)
addappid(335984)
addappid(335985)
addappid(335986)
addappid(335987)
addappid(335988)
addappid(335990)
addappid(335991)
addappid(335992)
addappid(335993)
addappid(335994)
addappid(335995)
addappid(335996)
addappid(335997)
addappid(338380)
-- Game: addappid(268200)

-- MAIN APP DEPOTS / PACKAGES
addappid(268201, 1, "a46a245b732d9d730dfdcebd9e26a0d0f76e23713257e3cd0322a1c8545b8a58")
addappid(268208, 1, "381b1890ace5be53b49b73a73634812cf0e733cbed6f25efc98ff2950efb6f65")
addappid(335983, 0, "679714492e11df42be7e4e0a7c1b122677d423290470bfb79a8055ced1c87b81")
addappid(335989, 0, "15f15cd50559155c35ddc16d86285a98cbd4668b5b56775041818dee88a706ae")
