-- Lua provided by RyzenAPI
-- Game: Cast Out Colony

-- MAIN APPLICATION
addappid(2386920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386921, 1, "fbb87299b4eaff100e1f67d92f5992d4c4a95d1de489f8fd1a932082f384120f")
