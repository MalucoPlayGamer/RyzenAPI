-- Lua provided by RyzenAPI
-- Game: Notes To Myself

-- MAIN APPLICATION
addappid(2723880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723881, 1, "b5ab5c880fa6162fbfe407d39500185608f2b47fd04a151ecf26967ccfa552c6")
addappid(2723883, 1, "39067bb7cafcb973556b4d2365ab861e56d781aa722574c5cc704e8db2231a71")
