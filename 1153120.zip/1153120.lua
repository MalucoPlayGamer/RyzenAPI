-- Lua provided by RyzenAPI
-- Game: Game: AppID 1153120

-- MAIN APPLICATION
addappid(1153120)
-- Game: addappid(1153120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153121, 1, "538d715975398a8a7f2755fb4dcf050384260aefabbc32b96aff6813aa7982dc")
