-- Lua provided by RyzenAPI
-- Game: ROAD HOMEWARD 4: last step

-- MAIN APPLICATION
addappid(1153120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1153121, 1, "538d715975398a8a7f2755fb4dcf050384260aefabbc32b96aff6813aa7982dc")
