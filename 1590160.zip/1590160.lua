-- Lua provided by RyzenAPI
-- Game: Liberte

-- MAIN APPLICATION
addappid(1590160)
-- Game: addappid(1590160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590161, 1, "0fe6304d98c46c173883220fbd10ef05d6131f61a70d074dd1f12734c9eb7025")
