-- 2682270's Lua and Manifest Created by Hubcap Manifest
-- Pight
-- Created: August 09, 2026 at 09:45:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2682270) -- Pight
-- MAIN APP DEPOTS
addappid(2682271, 1, "e9d7b0271925e247452d88cf7b0605436093d0837cd0cec5f175bf1b8647870f") -- Depot 2682271
setManifestid(2682271, "970695580145120769", 192670461)