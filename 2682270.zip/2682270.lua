-- 2682270's Lua and Manifest Created by Hubcap Manifest
-- Pight
-- Created: August 10, 2026 at 01:11:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2682270) -- Pight
-- MAIN APP DEPOTS
addappid(2682271, 1, "e9d7b0271925e247452d88cf7b0605436093d0837cd0cec5f175bf1b8647870f") -- Depot 2682271
setManifestid(2682271, "970695580145120769", 192670461)
addappid(2682272, 1, "2531fde680d04f7b8715f907ea5e618fac68e55e3dba0dd9877be5f91c832fa5") -- Depot 2682272
setManifestid(2682272, "2857599778641349740", 194542731)
addappid(2682273, 1, "c5ccb0e38695781e683fd1bdae13f73973405f1151633ab6bdd7567be6e714e2") -- Depot 2682273
setManifestid(2682273, "3519179936200965572", 213256966)