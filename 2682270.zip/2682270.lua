-- Lua provided by RyzenAPI
-- Game: Pight

-- MAIN APPLICATION
addappid(2682270) -- Pight

-- MAIN APP DEPOTS / PACKAGES
addappid(2682271, 1, "e9d7b0271925e247452d88cf7b0605436093d0837cd0cec5f175bf1b8647870f") -- Depot 2682271

