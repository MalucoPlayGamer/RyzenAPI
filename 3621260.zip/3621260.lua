-- Lua provided by RyzenAPI
-- Game: House of Terror

-- MAIN APPLICATION
addappid(3621260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621261, 1, "1c99355f41b81e8ae7446d78629cc6a6daa7c3613a2941891f93da6a3c08eaeb")
