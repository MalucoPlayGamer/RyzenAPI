-- Lua provided by RyzenAPI
-- Game: Alter Ego

-- MAIN APPLICATION
addappid(664780)

-- MAIN APP DEPOTS / PACKAGES
addappid(664781, 1, "d0bb43080d29e1ef00f62a976c91b700ca1ed32a4ea4149f1b6579f5b8cd6a30")
