-- Lua provided by RyzenAPI
-- Game: 1592990

-- MAIN APPLICATION
addappid(1592990)
-- Game: addappid(1592990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592991, 1, "30e1948f4150dab28e800a75542deccc09602d54e2010b7c25eef30c6a032f86")
