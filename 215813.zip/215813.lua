-- Lua provided by RyzenAPI
-- Game: Darksiders II - Angel of Death

-- MAIN APPLICATION
addappid(215813)

-- MAIN APP DEPOTS / PACKAGES
addappid(215813,0,"37b8a838cc4abbee926736f90cd7e3b93d3829669d01db2ebfeb56a985388493")

