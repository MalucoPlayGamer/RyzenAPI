-- Lua provided by RyzenAPI
-- Game: 215813

-- MAIN APPLICATION
addappid(215813)
-- Game: addappid(215813)

-- MAIN APP DEPOTS / PACKAGES
addappid(215813,0,"37b8a838cc4abbee926736f90cd7e3b93d3829669d01db2ebfeb56a985388493")
