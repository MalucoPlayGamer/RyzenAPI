-- Lua provided by RyzenAPI
-- Game: addappid(1663910)

-- MAIN APPLICATION
addappid(1663910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663911, 1, "57a43fe5ce0e5e326ff824c9b5470c0be06fde904de6ff9cc5ea103ca77530da")
