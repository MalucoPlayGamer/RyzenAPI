-- Lua provided by RyzenAPI
-- Game: Bakery

-- MAIN APPLICATION
addappid(746620)

-- MAIN APP DEPOTS / PACKAGES
addappid(746621, 1, "2e51001f6fdd8815b9c755846a62917b78ba5fe941df3497da609ded5494e9ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
