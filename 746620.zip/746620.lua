-- Lua provided by RyzenAPI
-- Game: Bakery

-- MAIN APPLICATION
addappid(746620)

-- MAIN APP DEPOTS / PACKAGES
addappid(746621, 1, "2e51001f6fdd8815b9c755846a62917b78ba5fe941df3497da609ded5494e9ed")

