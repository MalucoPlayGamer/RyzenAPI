-- Lua provided by RyzenAPI
-- Game: Snooker Nation Championship

-- MAIN APPLICATION
addappid(458830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(458831, 1, "cc52e65385ceb4906122f108a0cba6d7f61948feed78c64291cf975eba1356d5")

