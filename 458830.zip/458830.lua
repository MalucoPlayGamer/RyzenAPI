-- Lua provided by RyzenAPI
-- Game: addappid(458830)

-- MAIN APPLICATION
addappid(458830)

-- MAIN APP DEPOTS / PACKAGES
addappid(458831, 1, "cc52e65385ceb4906122f108a0cba6d7f61948feed78c64291cf975eba1356d5")
