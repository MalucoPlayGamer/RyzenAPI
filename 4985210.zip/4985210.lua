-- 4985210's Lua and Manifest Created by Hubcap Manifest
-- Storehand
-- Created: August 20, 2026 at 04:32:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4985210, 1, "9dc24774ccc1d439d1d1480cda85127cc4e985c4f1c7f03d630471e4b0d8044e") -- Storehand
-- MAIN APP DEPOTS
addappid(4985211, 1, "a468ee82e1164156fb03238aa91614a58235d7fb7095911e4499bd29c52bdf0a") -- Depot 4985211
setManifestid(4985211, "3278132010416430893", 759106672)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)