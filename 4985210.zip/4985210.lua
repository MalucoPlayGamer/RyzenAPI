-- Lua provided by RyzenAPI
-- Game: Storehand

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4985210, 1, "9dc24774ccc1d439d1d1480cda85127cc4e985c4f1c7f03d630471e4b0d8044e") -- Storehand
addappid(4985211, 1, "a468ee82e1164156fb03238aa91614a58235d7fb7095911e4499bd29c52bdf0a") -- Depot 4985211

