-- Lua provided by RyzenAPI
-- Game: Achievement Clicker 2018

-- MAIN APPLICATION
addappid(771350)
addappid(786600)

-- MAIN APP DEPOTS / PACKAGES
addappid(771351, 1, "f44ccca523812d50f7df47e58adb776547400b117733ab3e5c38eec1ac6a3ba8")
