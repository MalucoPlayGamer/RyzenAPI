-- Lua provided by RyzenAPI
-- Game: Kingdom's Life

-- MAIN APPLICATION
addappid(1847600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847601, 1, "e6de9ba3cafe78a3b55fe457cfd6df04a019646dbbb71f2c9774cb47f605943d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
