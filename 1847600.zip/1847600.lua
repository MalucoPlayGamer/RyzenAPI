-- Lua provided by RyzenAPI 
-- Game: Kingdom's Life
addappid(1847600)
addappid(1847601, 1, "e6de9ba3cafe78a3b55fe457cfd6df04a019646dbbb71f2c9774cb47f605943d")
