-- Lua provided by RyzenAPI 
-- Game: 41 Hours: Prologue
addappid(1536830)
addappid(1536831, 1, "209957c5107e7415c73e14f506c4278c114bf9766d291a7fe8afd9948640c4de")
