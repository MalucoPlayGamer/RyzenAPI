-- Lua provided by RyzenAPI
-- Game: 41 Hours: Prologue

-- MAIN APPLICATION
addappid(1536830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536831, 1, "209957c5107e7415c73e14f506c4278c114bf9766d291a7fe8afd9948640c4de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
