-- Lua provided by RyzenAPI
-- Game: Game: Pushing It! With Sisyphus

-- MAIN APPLICATION
addappid(2899090)
-- Game: addappid(2899090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899091, 1, "fa3b156c2a5f4fba522cca5c5caaae4b1745d05fdbc01ae69324bd24bbc178d7")
