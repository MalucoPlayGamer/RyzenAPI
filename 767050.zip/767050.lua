-- Lua provided by RyzenAPI
-- Game: Game: Last Day of FEAR

-- MAIN APPLICATION
addappid(767050)
-- Game: addappid(767050)

-- MAIN APP DEPOTS / PACKAGES
addappid(767051, 1, "41035cba8299189405b29a90dfa90194078aa1d4f6ac3e2722dabee5191cea49")
