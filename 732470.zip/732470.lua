-- Lua provided by RyzenAPI
-- Game: 732470

-- MAIN APPLICATION
addappid(732470)
-- Game: addappid(732470)

-- MAIN APP DEPOTS / PACKAGES
addappid(732471, 1, "f08e315ee071afd361c03c7d6105e68164cf16cd945f3f23c121e86c4dd24f07")
