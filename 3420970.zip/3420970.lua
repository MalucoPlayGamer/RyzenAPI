-- Lua provided by RyzenAPI
-- Game: Game: Inkwellers Demo

-- MAIN APPLICATION
addappid(3420970)
-- Game: addappid(3420970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3420971, 1, "49a5ceb4b74d91406e18b82ceb151337f083de3cd27b0e6e2f1daa7bc0d68acb")
