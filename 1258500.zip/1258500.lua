-- Lua provided by RyzenAPI
-- Game: addappid(1258500)

-- MAIN APPLICATION
addappid(1258500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258501, 1, "d7d43c06b7ee517902677b10a2b30d50eaae4714b126d1de20f08c7d18f4f551")
