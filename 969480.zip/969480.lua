-- Lua provided by SkyAPI 
-- Game: Warp Glider
addappid(969480)
addappid(969481, 1, "8954c88e6fc54dd81edd2b9706552c1cba9d77adf203703f62c7fd38fc49d7ed")
addappid(969482, 1, "b3315a20ea09ec7721fa1d5b890033def0b40b09522b34f28336c2857498f385")
addappid(969483, 1, "0b7d2d9cc8120deac19585389ce84f96a96aac82a0d082166e9bd0e2db235e62")
