-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Recipe Expansion Pack "The Art of Battle"

-- MAIN APPLICATION
addappid(1754694)
-- Game: addappid(1754694)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754694,0,"7ff85e8497b2526a676d9b7653ba1461045be0785ad93b5a5d310a97b90895cb")
