-- Lua provided by RyzenAPI
-- Game: Lightyear Frontier

-- MAIN APPLICATION
addappid(1677110)
-- Game: addappid(1677110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677111, 1, "5867f4cfbcf22c9f91f80049ace8660657651cbd62163e7e690b3644dbd98d8b")
