-- Lua provided by RyzenAPI
-- Game: 1182820

-- MAIN APPLICATION
addappid(1182820)
-- Game: addappid(1182820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182821, 1, "da373c4fc70923d1b28f0f5bdee969ae620ca2490f0efbf6893c52ae13f7f1a8")
