-- Lua provided by RyzenAPI 
-- Game: Miracle Calamity Homeostasis
addappid(1182820)
addappid(1182821, 1, "da373c4fc70923d1b28f0f5bdee969ae620ca2490f0efbf6893c52ae13f7f1a8")
