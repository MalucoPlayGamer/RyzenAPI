-- Lua provided by RyzenAPI
-- Game: Flower Design

-- MAIN APPLICATION
addappid(546070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(546071, 1, "6f4ea26a3795ac6e4759264ce33ca9221f9195ee4842282eb7b86ba0a1d22ef1")
addappid(546072, 1, "6e101b3601bc3e96a2039349d9bb3bcf5b2661a19ce681aed5d51a79c1a32d09")

