-- Lua provided by RyzenAPI
-- Game: Dice Tribes: Ambitions

-- MAIN APPLICATION
addappid(1965800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965802,0,"0008cd00975f658221835771e02548bf6ba5ce8c34d4f77cbba88aba5755034a")

