-- Lua provided by RyzenAPI
-- Game: Dimension Tripper Neptune: TOP NEP

-- MAIN APPLICATION
addappid(1798780)
-- Game: addappid(1798780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798781, 1, "95cd39b5a6a171d0d84a420cd463e86fa05c62071e780912bf9c6feee641ef21")
