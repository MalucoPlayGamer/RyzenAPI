-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Rusty

-- MAIN APPLICATION
addappid(3009790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009791, 1, "c89839fd3ea36522ff171dcc808f4560cfa0ec01e06c4ddf0ae58cf2ba6af3f1")

