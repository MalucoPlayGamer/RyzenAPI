-- Lua provided by RyzenAPI
-- Game: Game: AppID 595120

-- MAIN APPLICATION
addappid(595120)
-- Game: addappid(595120)

-- MAIN APP DEPOTS / PACKAGES
addappid(595121, 1, "9e462e6103de4e638329ded5022a5ab55a18f6881633f81dc74920f0fcc1d783")
addappid(595122, 1, "3cba9ae05832968336a40a137a14951aa60de3298821431d4c2bdca3055bddce")
addappid(595123, 1, "57a656217f8150be09748c40cbd0f38efff53fd0f22c52a5848e5a3dbd9b270e")
addappid(595124, 1, "d2374b0b178dee7ad143cc97cdd37bc469d2a9a54e41d3b4da84c4d7ebcb4e47")
