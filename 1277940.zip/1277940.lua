-- Lua provided by RyzenAPI
-- Game: Kinkoi: Golden Loveriche

-- MAIN APPLICATION
addappid(1277940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277941, 1, "c0c2ff32ce49dd9856f9f7511f7466b2d4a5cbf7e40c569c8f7c281521bbf66d")
addappid(1665630, 0, "30559a5fdea302b0ab0627c9f7944c0ec79cdbd905767e332df5da494cb22407")

