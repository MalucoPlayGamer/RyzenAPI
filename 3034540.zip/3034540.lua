-- Lua provided by RyzenAPI
-- Game: TNYN

-- MAIN APPLICATION
addappid(3034540)
-- Game: addappid(3034540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034542,0,"069dba752c7d90427959bd122c11efc83067397232b33cc1ca539f6c64aec4a4")
