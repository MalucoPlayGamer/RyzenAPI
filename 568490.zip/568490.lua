-- Lua provided by RyzenAPI
-- Game: Frog Hop

-- MAIN APPLICATION
addappid(568490)

-- MAIN APP DEPOTS / PACKAGES
addappid(568491, 1, "25fdb28290653277d6c63444260e5d3a562277d68a030f27ae4396cf816ab67d")
addappid(1437960, 0, "c61d7e32119a439d5544a4c4c14474090019e0f82dacea88abf6cc8a9529e3a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
