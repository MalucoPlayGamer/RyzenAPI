-- Lua provided by SkyAPI 
-- Game: Frog Hop
addappid(568490)
addappid(568491, 1, "25fdb28290653277d6c63444260e5d3a562277d68a030f27ae4396cf816ab67d")
addappid(1437960, 0, "c61d7e32119a439d5544a4c4c14474090019e0f82dacea88abf6cc8a9529e3a4")
