-- Lua provided by RyzenAPI
-- Game: 2082370

-- MAIN APPLICATION
addappid(2082370)
-- Game: addappid(2082370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082371, 1, "caa116bf5bf6128e0001138e2c108b9a360db59eb87edf48ca098387a3903c41")
