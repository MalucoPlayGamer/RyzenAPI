-- Lua provided by RyzenAPI
-- Game: Crash Dummy

-- MAIN APPLICATION
addappid(345690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345691, 1, "64dd0208b994308cb69369ea4f1082c7c6f79fb3960fc1e63fcae63079f68977")
addappid(345692, 1, "3628ecadc50f930d5bf4c505fd2b1b2e84f02394a48ef2bf86893af8f6ff0372")
addappid(345693, 1, "19bbd0646cef2919fc1da372bc925680a535cd47cbf2393650756bda4e742234")

