-- Lua provided by SkyAPI 
-- Game: Crash Dummy
addappid(345690)
addappid(345691, 1, "64dd0208b994308cb69369ea4f1082c7c6f79fb3960fc1e63fcae63079f68977")
addappid(345692, 1, "3628ecadc50f930d5bf4c505fd2b1b2e84f02394a48ef2bf86893af8f6ff0372")
addappid(345693, 1, "19bbd0646cef2919fc1da372bc925680a535cd47cbf2393650756bda4e742234")
