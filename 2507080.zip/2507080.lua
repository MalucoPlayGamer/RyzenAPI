-- Lua provided by SkyAPI 
-- Game: Cecelia
addappid(2507080)
addappid(2507081, 1, "23cf9e79c9a97bedb263ec35d31c072f2555442efa52602398b5474371f85742")
addappid(2507082, 1, "0fe6e78bbc90aba8133f5d7ef119fa5b78b945d95e47dcd100434c22c79e373c")
