-- Lua provided by RyzenAPI
-- Game: Cecelia

-- MAIN APPLICATION
addappid(2507080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507081, 1, "23cf9e79c9a97bedb263ec35d31c072f2555442efa52602398b5474371f85742")
addappid(2507082, 1, "0fe6e78bbc90aba8133f5d7ef119fa5b78b945d95e47dcd100434c22c79e373c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
