-- Lua provided by RyzenAPI
-- Game: AppID 329190

-- MAIN APPLICATION
addappid(329190)
-- Game: addappid(329190)

-- MAIN APP DEPOTS / PACKAGES
addappid(329191, 1, "8bc967235a127dda2f8c66cccf7d9f8d0dd65648a202ea8db844b5ff3b9f10dd")
