-- Lua provided by RyzenAPI 
-- Game: AppID 2992670
addappid(2992670)
addappid(2992671, 1, "733a99dc17493dcbf9e8f6e21b27e7d7e728d703b2e0593d6e1f41bae686b0d5")
