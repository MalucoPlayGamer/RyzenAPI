-- Lua provided by RyzenAPI
-- Game: AppID 903630

-- MAIN APPLICATION
addappid(903630)

-- MAIN APP DEPOTS / PACKAGES
addappid(903631, 1, "c3395379ccd28285b01e4c77e1e8cc26fdd5bdaa6c5ee43951f6e75a201c733b")
