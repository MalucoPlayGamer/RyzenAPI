-- Lua provided by RyzenAPI
-- Game: addappid(1309490)

-- MAIN APPLICATION
addappid(1309490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309491, 1, "39b2dab021d12705e5951bbc9b30a3805544f079ddff6056db073bebaed41929")
