-- Lua provided by RyzenAPI
-- Game: Romancing SaGa 2: Revenge of the Seven Demo

-- MAIN APPLICATION
addappid(2476940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476941, 1, "01bbbc368330651fa488d370a91e86c58f9711f1d71e9af2e45d6bd53b78b162")
