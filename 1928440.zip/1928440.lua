-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - Particle Set

-- MAIN APPLICATION
addappid(1928440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928440,0,"a6dce2d4121c8e8ec99191676430e7ac222f32a6f84aed923a63e440bb8c9466")

