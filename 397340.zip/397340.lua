-- Lua provided by RyzenAPI
-- Game: SimplePlanes

-- MAIN APPLICATION
addappid(397340)
-- Game: addappid(397340)

-- MAIN APP DEPOTS / PACKAGES
addappid(397341, 1, "9ad022de1aa292386b951a78bc8bb0464901e227f7d778be8a85eab26c025628")
addappid(397342, 1, "87fd74d6e0041f8ffb2940577a4478a0368d00d0887641b290cbc557ea539eb3")
addappid(397343, 1, "e0ac4e6069202eb261f10f12b83dbda66b3afe4d5915160364b8e54803b5ddac")
