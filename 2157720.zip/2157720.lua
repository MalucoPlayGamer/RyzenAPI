-- Lua provided by RyzenAPI
-- Game: addappid(2157720)

-- MAIN APPLICATION
addappid(2157720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157722,0,"876b74c41ace89826921c65a949acd6a0d53a7001de7fdb397d8723a88f1deba")
