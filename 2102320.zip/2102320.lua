-- Lua provided by RyzenAPI
-- Game: MISTROGUE: Mist and the Living Dungeons

-- MAIN APPLICATION
addappid(2102320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102322,0,"9ee91a18dbb217ac2125eaaa626a2acb378bf9c59993cafa31f6e852ee2a4feb")
addappid(2102323,0,"7e39db7ccfa1a6bef1cc83174c8cd9d8f7687615f1fd312ae5f5813a819e0608")

