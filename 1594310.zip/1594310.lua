-- Lua provided by RyzenAPI
-- Game: Midnight Ohota

-- MAIN APPLICATION
addappid(1594310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594311, 1, "338d7c0552871e253b44a40c111d516c924c5a89a1f31fcf5dbc3b0b3cae2d15")

