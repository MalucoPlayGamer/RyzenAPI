-- Lua provided by RyzenAPI
-- Game: 201160

-- MAIN APPLICATION
addappid(201160)
-- Game: addappid(201160)

-- MAIN APP DEPOTS / PACKAGES
addappid(201161, 1, "5fb3aed1781a21d0fa409e8b1359fcaf2913e474594ba568e4025a1f30b4e575")
