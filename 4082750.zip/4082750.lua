-- Lua provided by RyzenAPI
-- Game: Log Riders

-- MAIN APP DEPOTS / PACKAGES
addappid(4082750, 1, "71c5b3471a2cebf66200752ceea7902235a7bdd8ab68f82a2fd930cfe8aef337") -- Log Riders
addappid(4082751, 1, "25e409fecd35d4e0d0c4f118068763d697c1e9c37454b404e64cec9ff356f482") -- Depot 4082751
addappid(4082752, 1, "9110f415e2cba698a97c098e3e6ce0b44ee0cce7199175c64199f3015dd4c4f1") -- Depot 4082752
addappid(4082753, 1, "238c61c035d57d6638318de5f5cfe5cdb5fc11f652f7ffd78f8def0f562e7416") -- Depot 4082753
