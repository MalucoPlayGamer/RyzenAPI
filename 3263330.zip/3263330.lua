-- Lua provided by RyzenAPI
-- Game: Game: AppID 3263330

-- MAIN APPLICATION
addappid(3263330)
-- Game: addappid(3263330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263331, 1, "a138a87ae7d1bb6070acd0f9afc048c1d332e3a383e24b995dd8ec699e4206c5")
