-- Lua provided by RyzenAPI
-- Game: AppID 398710

-- MAIN APPLICATION
addappid(398710)

-- MAIN APP DEPOTS / PACKAGES
addappid(398711, 1, "7adff4eabe477cbdb5be54fc83f3a69a54cc1ef797cf89926858d696ed60240e")
addappid(398712, 1, "1d8606fc5e9aa8dd1e1cbff12d5a3e127cea6d60308ac970d36b15223656a6e8")
addappid(398713, 1, "eef0089a58c3f3320ddc5aaa9fb9e02667d52c7bad506644a86db4181b25dc95")
