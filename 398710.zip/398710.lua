-- Lua provided by RyzenAPI
-- Game: AppID 398710

-- MAIN APPLICATION
addappid(398710)

-- MAIN APP DEPOTS / PACKAGES
addappid(398711, 1, "7adff4eabe477cbdb5be54fc83f3a69a54cc1ef797cf89926858d696ed60240e")
addappid(398712, 1, "1d8606fc5e9aa8dd1e1cbff12d5a3e127cea6d60308ac970d36b15223656a6e8")
addappid(398713, 1, "eef0089a58c3f3320ddc5aaa9fb9e02667d52c7bad506644a86db4181b25dc95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
