-- Lua provided by RyzenAPI
-- Game: addappid(2258580)

-- MAIN APPLICATION
addappid(2258580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258581, 1, "fbaf58dfee681fb3b99f91bb97609af83f3e5b83ea18556b447793ddfafee674")
