-- Lua provided by RyzenAPI
-- Game: SuperCupOnline

-- MAIN APPLICATION
addappid(1370600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370601, 1, "34ac47379484eddd1da93b38e62fea62a9fe3e803aaa0673204f053e25022373")
