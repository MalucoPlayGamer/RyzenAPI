-- Lua provided by RyzenAPI
-- Game: AppID 254860

-- MAIN APPLICATION
addappid(254860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254861, 1, "f2d0534d55c5825c91adb543daa1f5fdc8c4b9c2bc8b6baff548c0b46102a7e2")

