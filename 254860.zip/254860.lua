-- Lua provided by RyzenAPI
-- Game: 254860

-- MAIN APPLICATION
addappid(254860)
-- Game: addappid(254860)

-- MAIN APP DEPOTS / PACKAGES
addappid(254861, 1, "f2d0534d55c5825c91adb543daa1f5fdc8c4b9c2bc8b6baff548c0b46102a7e2")
