-- Lua provided by RyzenAPI
-- Game: 1939833

-- MAIN APPLICATION
addappid(1939833)
-- Game: addappid(1939833)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939833,0,"2e6bbd45fa9702fba2f55ca81af9d0dbf4d9f69f974db4032fa718c29c3e3a59")
