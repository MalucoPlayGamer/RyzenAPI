-- Lua provided by RyzenAPI
-- Game: Umbrella Girl

-- MAIN APPLICATION
addappid(2722260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722262,0,"d192b5cf436552785a203e8680586ee940d4d017256616da943f903a67c8cacb")

