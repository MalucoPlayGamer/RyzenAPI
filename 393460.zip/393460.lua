-- Lua provided by RyzenAPI 
-- Game: AppID 393460
addappid(393460)
addappid(393461, 1, "833d652455d0c4e40a499a0de444a1d3bfc660dd10f146f988d326b6ae9d673c")
addappid(393462, 1, "ad4563a11a758246e14491798b9d59717621269f9bd09113a42fb3aed02b6a7e")
addappid(393463, 1, "ec4ccf62adee52d75666bd554adabb87496c8039b2ce4281aed8cbfa814099f5")
addappid(492620)
