-- Lua provided by RyzenAPI
-- Game: Crazy Pixel Streaker

-- MAIN APPLICATION
addappid(393460)
addappid(492620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(393461, 1, "833d652455d0c4e40a499a0de444a1d3bfc660dd10f146f988d326b6ae9d673c")
addappid(393462, 1, "ad4563a11a758246e14491798b9d59717621269f9bd09113a42fb3aed02b6a7e")
addappid(393463, 1, "ec4ccf62adee52d75666bd554adabb87496c8039b2ce4281aed8cbfa814099f5")
