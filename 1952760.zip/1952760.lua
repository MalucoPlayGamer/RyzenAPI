-- Lua provided by RyzenAPI
-- Game: RGB Rush

-- MAIN APPLICATION
addappid(1952760)
-- Game: addappid(1952760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952761, 1, "e930dab34d4ff6a0cc3d9a5f3e71d3c9305007c972c3fd7d77548e665ae8673d")
