-- Lua provided by RyzenAPI
-- Game: Assassin's Creed

-- MAIN APPLICATION
addappid(15100)

-- MAIN APP DEPOTS / PACKAGES
addappid(15101, 1, "b7078f8a461fea68d5578326047a7a9eaffb543057f47ce1416f7bc3fc28fb50")
addappid(15102, 1, "8915337fcf26fc715e10c04ddc26d9d04ace33a4efd5cbc1507172518b088c71")
addappid(15103, 1, "9a6e1442aa4aee64126e043c562de82cdbc172496cc89811eb49e3585d80548e")
addappid(15104, 1, "83baae6d5ecf324a5ff64020351f1ee45e3cf516846d06929b36ed1cca4bb763")
addappid(15105, 1, "d581feb74f87aefcca92b1bd3a44ae05aa48256fb6fb6d57e53878ec4393d881")
addappid(15106, 1, "7e201cb7ea1a6cabdc89df564aa7ca09046cb90efca479aafdbdeb95c38681bc")
addappid(15107, 1, "289144b9861a0ad49cb658171c3ca20b1bffb103e6cbad46ba7cdf9f4f1ef067")
addappid(15108, 1, "77930027f599176b2b3552b0ea052ce5417b2737c9f9a53ded6ed3e7f751b5b9")
addappid(15109, 1, "5b32af30a9bef331443c7b8389233b7b515cbac4a934f6f6117691a3036b88d7")
