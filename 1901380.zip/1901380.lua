-- Lua provided by RyzenAPI
-- Game: 1901380

-- MAIN APPLICATION
addappid(1901380)
addappid(1901440)
addappid(1901441)
addappid(1901442)
addappid(1901443)
-- Game: addappid(1901380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901381, 1, "8e007347c567e75544e007619f99347e4aec7018c1b4f287ebd337c201b9078f")
