-- Lua provided by RyzenAPI 
-- Game: AppID 1222250
addappid(1222250)
addappid(1222251, 1, "2c3ee5c3f71e9048763c6685015d42cda2d3441e895db615e46a81b8a89bac8f")
