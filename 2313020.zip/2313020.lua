-- Lua provided by RyzenAPI
-- Game: Umamusume: Pretty Derby - Party Dash

-- MAIN APPLICATION
addappid(2313020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313021, 1, "a7ea6226751ac88e77dd048b3af5cba983ea6c96f6f62bdce18b80f106f4c3b4")

