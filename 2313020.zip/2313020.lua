-- Lua provided by RyzenAPI
-- Game: Umamusume: Pretty Derby - Party Dash

-- MAIN APPLICATION
addappid(2313020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313021, 1, "a7ea6226751ac88e77dd048b3af5cba983ea6c96f6f62bdce18b80f106f4c3b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3050720)
addappid(3050730)
addappid(3050740)
addappid(3050750)
