-- Lua provided by RyzenAPI
-- Game: SCP: Retrieval

-- MAIN APPLICATION
addappid(3241520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241521, 1, "74e73a6a4585c329d96056085cc6467d38821b98ad5df42136d16f485a065d9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
