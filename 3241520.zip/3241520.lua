-- Lua provided by RyzenAPI
-- Game: Game: SCP: Retrieval

-- MAIN APPLICATION
addappid(3241520)
-- Game: addappid(3241520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241521, 1, "74e73a6a4585c329d96056085cc6467d38821b98ad5df42136d16f485a065d9c")
