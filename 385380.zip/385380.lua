-- Lua provided by RyzenAPI
-- Game: addappid(385380)

-- MAIN APPLICATION
addappid(385380)
addappid(485930)
addappid(549870)

-- MAIN APP DEPOTS / PACKAGES
addappid(385381, 1, "5a08ff2ba746a8bf217dd783ed3b90d5794374ef9ad6dbe589c8a31741224d63")
addappid(385382, 1, "9fc617c5edd72f37c0d904e46f79308eb4a8df96d43954af683d01f1dae9f953")
addappid(385383, 1, "b321d7b5e266382c1049a450e2e52b263f002ca9afd7e512d931d184ccd3d07f")
addappid(385384, 1, "fd32c06ee9a4194fabe7efd5daaddb2597f2c81b6216297ba23fde5db3199ef9")
