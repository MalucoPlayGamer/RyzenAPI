-- Lua provided by RyzenAPI
-- Game: Bean Story

-- MAIN APPLICATION
addappid(1978920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978921, 1, "11d65a22309cdbbefc496a760be5a4e2e85ddc71dfd8a7f267a05388ebec4926")
