-- Lua provided by RyzenAPI
-- Game: The Spell Brigade

-- MAIN APPLICATION
addappid(2904000)
addappid(3194200)
addappid(4235530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904001,0,"1cea3f47529b0e53e7add1f7e63dcdf14634adfde24faf952128ad1034ee90e8")
addappid(4457551,0,"28b7307eedd29b4f32201952a9ded776d14e53d1a3e88a0db4af253431d2c373")

