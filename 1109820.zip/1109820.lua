-- Lua provided by RyzenAPI 
-- Game: AppID 1109820
addappid(1109820)
addappid(1109821, 1, "4e4c3821ba59737d1a13328b5cf4d8201109c550fde4efa040c6585cd2b05cd0")
