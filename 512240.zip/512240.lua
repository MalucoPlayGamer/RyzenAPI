-- Lua provided by RyzenAPI
-- Game: Duckpocalypse

-- MAIN APPLICATION
addappid(512240)

-- MAIN APP DEPOTS / PACKAGES
addappid(512241,0,"cb74d981be0ce0177145bdc0314f40cea645689f5035c633d4a16899a84111e1")

