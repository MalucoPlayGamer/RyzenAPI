-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(648080)

-- MAIN APP DEPOTS / PACKAGES
addappid(648080,0,"2bd27bf970884306aac731a260ca7de77798954bf94523dc9d1d25267d2ac418")
