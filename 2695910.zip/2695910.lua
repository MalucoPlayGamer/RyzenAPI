-- Lua provided by RyzenAPI
-- Game: 2695910

-- MAIN APPLICATION
addappid(2695910)
-- Game: addappid(2695910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695911, 1, "3922476b1306fe357a7ca357b4b2ab9a1077587a699a75cbfb910a786eb5430b")
