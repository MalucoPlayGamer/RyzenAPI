-- Lua provided by RyzenAPI 
-- Game: Milky Quest II
addappid(2166140)
addappid(2166141, 1, "7e701d4cd8ad44e0714071f7e8c143237c9ee481c6282e6694fca0b94dbc4914")
addappid(2166142, 1, "6b009b61df2086ae43ee560112fc85413be988537e3f56c53ed6ed7b24abf723")
addappid(2166143, 1, "6444c80da098ecc9d75153d7079d6327465991d21ff92eaccc42b306fd5ad4c7")
