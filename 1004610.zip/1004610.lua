-- Lua provided by SkyAPI 
-- Game: Roombo: First Blood
addappid(1004610)
addappid(1004611, 1, "91a2579ee2ef6ac757a2284b3810df3421d0222debeb4cccc6b2095022e59ab8")
addappid(1004612, 1, "1fd331a0bd9545e08142399edb84f769e361acef820de6da5ec703ad92de7da4")
