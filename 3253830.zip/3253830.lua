-- Lua provided by RyzenAPI
-- Game: Tank Arena:Total Operation

-- MAIN APPLICATION
addappid(3253830)
