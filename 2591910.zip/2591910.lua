-- Lua provided by RyzenAPI
-- Game: Game: My Furry Protogen 2 🐾

-- MAIN APPLICATION
addappid(2591910)
addappid(2612260)
-- Game: addappid(2591910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591911, 1, "bc1fae6142fbec1a1cabfccfd1dd45ea24003c9418c16f3a6bddb6531aa26747")
