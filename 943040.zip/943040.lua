-- Lua provided by RyzenAPI
-- Game: 943040

-- MAIN APPLICATION
addappid(943040)
-- Game: addappid(943040)

-- MAIN APP DEPOTS / PACKAGES
addappid(943041, 1, "fa2b22ed8a5223c55d35ea64437318e19ca42a6be53b2ba9910853006130e910")
