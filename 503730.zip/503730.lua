-- Lua provided by RyzenAPI
-- Game: addappid(503730)

-- MAIN APPLICATION
addappid(503730)

-- MAIN APP DEPOTS / PACKAGES
addappid(503731, 1, "e9fa49c32cff292c75da466ea3385ca23ff884fe794dfdb34d4fc80620222b4c")
