-- Lua provided by RyzenAPI
-- Game: Saving Harmony

-- MAIN APPLICATION
addappid(503730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(503731, 1, "e9fa49c32cff292c75da466ea3385ca23ff884fe794dfdb34d4fc80620222b4c")

