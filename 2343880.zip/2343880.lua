-- Lua provided by RyzenAPI
-- Game: The Diary

-- MAIN APPLICATION
addappid(2343880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343881, 1, "b649fe78222dc93d505d94fa40b76ee5c07791d38a473748ea57d371ec717c44")
