-- Lua provided by RyzenAPI
-- Game: addappid(3016670)

-- MAIN APPLICATION
addappid(3016670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016671, 1, "145956718383a0f3b32fe82880c6651a50817c1f9a10cf2bf372f39dd98bf5df")
