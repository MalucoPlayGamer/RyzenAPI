-- Lua provided by RyzenAPI
-- Game: A Plunge into Darkness

-- MAIN APPLICATION
addappid(615700)
addappid(1249930)

-- MAIN APP DEPOTS / PACKAGES
addappid(615701, 1, "9df24ebf4a13ef8bcb41e7332abc41fc812456d231bb19f895d82228b72048c8")

