-- Lua provided by RyzenAPI
-- Game: Circle

-- MAIN APPLICATION
addappid(1210220)
-- Game: addappid(1210220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210221, 1, "034f260b54c7bb3ba4bf035edb482051c08da947815b43b0b27af64665978adc")
