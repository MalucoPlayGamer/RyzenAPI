-- Lua provided by RyzenAPI
-- Game: 394700

-- MAIN APPLICATION
addappid(394700)
addappid(394701)
addappid(394703)

-- MAIN APP DEPOTS / PACKAGES
addappid(394702,0,"8f8fa761b6328907bf029c222f5e3baeeda830d2a1cd51ca93acf75c97b4a403")
