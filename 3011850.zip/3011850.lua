-- Lua provided by SkyAPI 
-- Game: CRUELTY
addappid(3011850)
addappid(3011851, 1, "36b4e4faeec7372a15a684b165644a0ee5dd002a4b1316e6a6e875d8cc42bbac")
