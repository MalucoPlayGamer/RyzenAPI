-- Lua provided by RyzenAPI
-- Game: CRUELTY

-- MAIN APPLICATION
addappid(3011850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011851, 1, "36b4e4faeec7372a15a684b165644a0ee5dd002a4b1316e6a6e875d8cc42bbac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
