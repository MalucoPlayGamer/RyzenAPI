-- Lua provided by RyzenAPI 
-- Game: Lens Life
addappid(1346970)
addappid(1346971, 1, "28e41781573c16ae115676d763166e885e62363544ad59fbba857ddaae7597fe")
addappid(1698190)
