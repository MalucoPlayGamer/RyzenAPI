-- Lua provided by RyzenAPI
-- Game: 1346970

-- MAIN APPLICATION
addappid(1346970)
addappid(1698190)
-- Game: addappid(1346970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346971, 1, "28e41781573c16ae115676d763166e885e62363544ad59fbba857ddaae7597fe")
