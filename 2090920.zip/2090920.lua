-- Lua provided by RyzenAPI
-- Game: Wet Cute Girls - Artbook 18+

-- MAIN APPLICATION
addappid(2090920)
-- Game: addappid(2090920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090920,0,"3eb7cd5b161781d77fd0915e86211272cdd1221fd0ac06062b64b17db0166c91")
