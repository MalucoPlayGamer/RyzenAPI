-- Lua provided by RyzenAPI
-- Game: AppID 956580

-- MAIN APPLICATION
addappid(956580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(956581, 1, "2aa378e57778901484160b2c3dac36c344476fda32e05a127f1a8be2cb4bb073")

