-- Lua provided by SkyAPI 
-- Game: AppID 956580
addappid(956580)
addappid(956581, 1, "2aa378e57778901484160b2c3dac36c344476fda32e05a127f1a8be2cb4bb073")
