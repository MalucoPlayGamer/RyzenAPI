-- Lua provided by RyzenAPI
-- Game: addappid(956580)

-- MAIN APPLICATION
addappid(956580)

-- MAIN APP DEPOTS / PACKAGES
addappid(956581, 1, "2aa378e57778901484160b2c3dac36c344476fda32e05a127f1a8be2cb4bb073")
