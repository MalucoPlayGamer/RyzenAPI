-- Lua provided by RyzenAPI
-- Game: Winter ~Life in the Countryside~

-- MAIN APPLICATION
addappid(3289580)
-- Game: addappid(3289580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289581, 1, "a5435012d9b4011281fbd9e9208e14af1593ad7f2670fe552875f5ebba8ebb51")
addappid(3289582, 1, "52d62701fc2c1f1aac3a997161d1edda60a964dab4dd50037be116eb2075535d")
