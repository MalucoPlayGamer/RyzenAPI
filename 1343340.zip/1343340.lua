-- Lua provided by RyzenAPI
-- Game: HORROR TALES: The Beggar

-- MAIN APPLICATION
addappid(1343340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1343341, 1, "6e55771d9b9ba61a81d904d7930622a9f6bd2e7060ff7c912ef51d2997ac6000")
