-- Lua provided by RyzenAPI
-- Game: addappid(1343340)

-- MAIN APPLICATION
addappid(1343340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343341, 1, "6e55771d9b9ba61a81d904d7930622a9f6bd2e7060ff7c912ef51d2997ac6000")
