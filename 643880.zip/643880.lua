-- Lua provided by RyzenAPI 
-- Game: Strikey Sisters
addappid(643880)
addappid(643881, 1, "2d276504468e4eb8e45d72e1f81201d4f5011aaa2f43040b7fb969429fecb89f")
addappid(643882, 1, "7d74d6e475ad0ac886a95ca3b1d8f7d49d95dcb50e75cc227cb8bc332563f277")
addappid(643883, 1, "ee1b7878b26a9206825600deb39ac8a8b3e908394233033d7be809fb5481d402")
