-- Lua provided by RyzenAPI
-- Game: The Utility Room

-- MAIN APPLICATION
addappid(2091960)
-- Game: addappid(2091960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091961, 1, "bcf71904a6d9f0a1d340f9b34a9c3a123ff237d1f95d6706f299f01c846bbf93")
