-- Lua provided by RyzenAPI
-- Game: The Backrooms

-- MAIN APPLICATION
addappid(1825160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1825161, 1, "07d5554c503f17b69601d860b926550d3aa9b8726e8cd92d2ae5feeba5f39332")

