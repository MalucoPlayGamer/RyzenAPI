-- Lua provided by RyzenAPI
-- Game: The Backrooms

-- MAIN APPLICATION
addappid(1825160)
-- Game: addappid(1825160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825161, 1, "07d5554c503f17b69601d860b926550d3aa9b8726e8cd92d2ae5feeba5f39332")
