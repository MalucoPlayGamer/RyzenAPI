-- Lua provided by SkyAPI 
-- Game: The Backrooms
addappid(1825160)
addappid(1825161, 1, "07d5554c503f17b69601d860b926550d3aa9b8726e8cd92d2ae5feeba5f39332")
