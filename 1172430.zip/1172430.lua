-- Lua provided by RyzenAPI
-- Game: AppID 1172430

-- MAIN APPLICATION
addappid(1172430)
-- Game: addappid(1172430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172431, 1, "99917ef83ed2c4c7f3db6ad99697132c47beada0f36c24cfdbbfc00786af6975")
