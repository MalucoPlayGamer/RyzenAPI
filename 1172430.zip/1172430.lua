-- Lua provided by RyzenAPI
-- Game: AppID 1172430

-- MAIN APPLICATION
addappid(1172430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1172431, 1, "99917ef83ed2c4c7f3db6ad99697132c47beada0f36c24cfdbbfc00786af6975")

