-- Lua provided by RyzenAPI
-- Game: AppID 3248750

-- MAIN APPLICATION
addappid(3248750)
-- Game: addappid(3248750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248751, 1, "eaced425cecb1abaffd1bde8a89865ce716d31ea17eda307002682b0c7c5cab1")
