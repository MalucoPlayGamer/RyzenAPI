-- Lua provided by RyzenAPI 
-- Game: AppID 1684330
addappid(1684330)
addappid(1684331, 1, "15eb1f0984e750c5db16e590cda17284cbf64c9b21b1fc3ac4614b8eecb810da")
