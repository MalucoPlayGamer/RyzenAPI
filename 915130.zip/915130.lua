-- Lua provided by RyzenAPI
-- Game: 东方龙隐談 ~ Touhou Chaos of Black Loong

-- MAIN APPLICATION
addappid(915130)
-- Game: addappid(915130)

-- MAIN APP DEPOTS / PACKAGES
addappid(915131, 1, "e23aebd9f037ed31557ddf47de4504ee1543e39fcdd51fd4e63aeeb739e81d93")
