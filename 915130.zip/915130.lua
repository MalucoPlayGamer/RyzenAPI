-- Lua provided by RyzenAPI
-- Game: 东方龙隐談 ~ Touhou Chaos of Black Loong

-- MAIN APPLICATION
addappid(915130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(915131, 1, "e23aebd9f037ed31557ddf47de4504ee1543e39fcdd51fd4e63aeeb739e81d93")

