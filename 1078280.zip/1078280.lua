-- Lua provided by RyzenAPI
-- Game: Game: AppID 1078280

-- MAIN APPLICATION
addappid(1078280)
-- Game: addappid(1078280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078281, 1, "6248a93a8bef6fbd4a45876431923f588a1c16a85a325bbafa94f465a8df27fd")
addappid(1078282, 1, "f3ad4134a11d14157e9942f54f1e9101c18ccd2ad823e16df48b61e69aa03950")
addappid(1078283, 1, "7ac7c381faec5675b3cd55f08ad822719f5625d833cc92fca476e3fb02da44eb")
