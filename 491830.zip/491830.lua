-- Lua provided by RyzenAPI
-- Game: addappid(491830)

-- MAIN APPLICATION
addappid(491830)

-- MAIN APP DEPOTS / PACKAGES
addappid(491831, 1, "0fa84216217c5fab0587ba85fd506e59fa8051ff586af7d68a7afe795e55c790")
addappid(491832, 1, "0b48d09a4b0b5aaff6aa0f1aef76b211bcc2ab96c3c4ca6c2e0990ba7821ad28")
