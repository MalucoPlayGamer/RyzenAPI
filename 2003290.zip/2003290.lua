-- Lua provided by RyzenAPI
-- Game: Garden Galaxy Demo

-- MAIN APPLICATION
addappid(2003290)
-- Game: addappid(2003290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003291, 1, "2d65fc1e85cacd2cb1e916d057c645c951183e202c2903e0ae456c1debe7e12f")
