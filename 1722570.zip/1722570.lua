-- Lua provided by RyzenAPI
-- Game: Jerma's Big Adventure

-- MAIN APPLICATION
addappid(1722570)
