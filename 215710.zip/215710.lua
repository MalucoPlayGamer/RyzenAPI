-- Lua provided by RyzenAPI
-- Game: Game: Fieldrunners 2

-- MAIN APPLICATION
addappid(215710)
-- Game: addappid(215710)

-- MAIN APP DEPOTS / PACKAGES
addappid(215711, 1, "1df7e2faa672ef1322170075626c34d6b3b4a2a0ddddb845950a9b5bab86488d")
