-- Lua provided by RyzenAPI
-- Game: Crazy Cursed Grandma's House

-- MAIN APPLICATION
addappid(2635390)
-- Game: addappid(2635390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635391, 1, "a72f9a5a7c0b9f8fb938bfb347dda728f6ec1791f8bbac4ed21720fc78f39f3f")
