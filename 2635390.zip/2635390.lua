-- Lua provided by RyzenAPI
-- Game: Crazy Cursed Grandma's House

-- MAIN APPLICATION
addappid(2635390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635391, 1, "a72f9a5a7c0b9f8fb938bfb347dda728f6ec1791f8bbac4ed21720fc78f39f3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
