-- Lua provided by RyzenAPI
-- Game: AppID 739200

-- MAIN APPLICATION
addappid(739200)

-- MAIN APP DEPOTS / PACKAGES
addappid(739201, 1, "82acefec211ad8e9a4efec322af89a552b5474c2c66e141fce08a55ed8c60ef5")
