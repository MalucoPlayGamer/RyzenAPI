-- Lua provided by RyzenAPI
-- Game: Project Starship

-- MAIN APPLICATION
addappid(454890)

-- MAIN APP DEPOTS / PACKAGES
addappid(454891, 1, "c7861a16fdb6e5f764d4239cbed712db9905e1869f1793a14b0765109cb5b143")
addappid(541830, 0, "b47d5fda68b86b5c25313cd61b9c21b0e1a70ce29c2a0d2667ccdf7ac929ae60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
