-- Lua provided by RyzenAPI 
-- Game: Elevator Action™ -Returns- S-Tribute
addappid(1913680)
addappid(1913681, 1, "0e2371b83d04568ec7fb997e6a1c589ce48beb6ae5a21bc4e32e9d3a4f220072")
