-- Lua provided by RyzenAPI
-- Game: Elevator Action™ -Returns- S-Tribute

-- MAIN APPLICATION
addappid(1913680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1913681, 1, "0e2371b83d04568ec7fb997e6a1c589ce48beb6ae5a21bc4e32e9d3a4f220072")

