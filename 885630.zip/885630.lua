-- Lua provided by RyzenAPI 
-- Game: AppID 885630
addappid(885630)
addappid(885631, 1, "d5b0b3e7d06101c77c6a58e44e1468c1643907cd22f1318e4e9c7c81b58bde3a")
