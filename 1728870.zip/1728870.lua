-- Lua provided by RyzenAPI
-- Game: Game: Disciples: Liberation Demo

-- MAIN APPLICATION
addappid(1728870)
-- Game: addappid(1728870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728871, 1, "ec6c46e80ff86b77e19ca969c10d8d73e2cd483ffc2a03ba548d4bac9ba79617")
addappid(1728872, 1, "86a16e79f10138c7c511956cd2e3b383aa033b5b1f3e1de824d64c340e335666")
