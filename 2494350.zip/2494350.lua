-- Lua provided by RyzenAPI 
-- Game: Pro Cycling Manager 2024
addappid(2494350)
addappid(2494351, 1, "2e3162ac09964bb2fc2a2bb4a9ccb4524030b6cc0337cb18f519b4ea584a69cc")
