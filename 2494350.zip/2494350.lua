-- Lua provided by RyzenAPI
-- Game: Pro Cycling Manager 2024

-- MAIN APPLICATION
addappid(2494350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494351, 1, "2e3162ac09964bb2fc2a2bb4a9ccb4524030b6cc0337cb18f519b4ea584a69cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
