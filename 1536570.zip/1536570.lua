-- Lua provided by RyzenAPI
-- Game: 1536570

-- MAIN APPLICATION
addappid(1536570)
-- Game: addappid(1536570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536571, 1, "9ad820ef649cff6d5859d0c2c0045168bb25b79122c95c252d4b2c5c3d7724b6")
