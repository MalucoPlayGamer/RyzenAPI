-- Lua provided by RyzenAPI
-- Game: Daymare: 1994 Sandcastle

-- MAIN APPLICATION
addappid(1530470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530471, 1, "59a219e71bf3bffe8b6f329ae250dec7fbd1d09db31e21bffd5c5f8f95b66def")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
