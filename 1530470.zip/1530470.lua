-- Lua provided by RyzenAPI
-- Game: addappid(1530470)

-- MAIN APPLICATION
addappid(1530470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530471, 1, "59a219e71bf3bffe8b6f329ae250dec7fbd1d09db31e21bffd5c5f8f95b66def")
