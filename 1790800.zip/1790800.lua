-- Lua provided by RyzenAPI
-- Game: addappid(1790800)

-- MAIN APPLICATION
addappid(1790800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790801, 1, "dcf319d76691ce2aba5d83abfb3ffa8ebcaef9b7090f5a798c51f459e55ad4e6")
