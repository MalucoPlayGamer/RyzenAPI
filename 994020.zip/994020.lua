-- Lua provided by RyzenAPI
-- Game: AppID 994020

-- MAIN APPLICATION
addappid(994020)

-- MAIN APP DEPOTS / PACKAGES
addappid(994021, 1, "ee42503db538e2dd57c4fef1794eebf23870601b764b637e14c266e91aacb916")

