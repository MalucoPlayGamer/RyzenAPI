-- Lua provided by RyzenAPI
-- Game: Tempest of the Heavens and Earth

-- MAIN APPLICATION
addappid(994020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(994021, 1, "ee42503db538e2dd57c4fef1794eebf23870601b764b637e14c266e91aacb916")

