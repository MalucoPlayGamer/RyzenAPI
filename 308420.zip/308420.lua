-- Lua provided by RyzenAPI 
-- Game: Ziggurat
addappid(308420)
addappid(308421, 1, "e85401770b2ddd2331f6693d6bd64de5c4b1b9e2c3a935b3b1a2066b1d81ed9c")
addappid(308422, 1, "11611ed6e21338bf674165492eeebb91e312d81f2ecea4aa0807851d2ae1462d")
addappid(308423, 1, "ee70c43f4d05d137631cca04bd20512a55b16c972f05cff491a1e8c2ad6a9e9a")
addappid(308424, 1, "38336dd289b4f933f01cefbaf145032bbe17bb3f0430c976fc525addfacc199d")
