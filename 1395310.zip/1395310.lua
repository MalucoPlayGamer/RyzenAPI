-- Lua provided by SkyAPI 
-- Game: World of Soccer RELOADED
addappid(1395310)
addappid(1395311, 1, "f2020d78a87e2cf53b7d28145046b4c489830a9c060641776f7bf7e9c1fc410f")
