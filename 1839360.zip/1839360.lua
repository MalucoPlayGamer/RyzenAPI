-- Lua provided by RyzenAPI
-- Game: Dawn of Kagura: Keika's Story

-- MAIN APPLICATION
addappid(1839360)
addappid(1839361)
addappid(1839362)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839363,0,"de370a90ca19d366fc0422d37665674b2f7bf1a448a7a12af88cf77f6a4b9f5e")

