-- Lua provided by RyzenAPI
-- Game: AppID 1274600

-- MAIN APPLICATION
addappid(1274600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274601, 1, "07ff7574977d57fd084377ff691488430aaac2e53ff9f19b703e69b505ea91fd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3905110)
