-- Lua provided by RyzenAPI
-- Game: Game: D-Hospital

-- MAIN APPLICATION
addappid(2980510)
-- Game: addappid(2980510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980511, 1, "c2ca6c1fb3a99048ead1bc61daba9b81340327f5781dd6f139f0831a1fd08732")
addappid(2980512, 1, "eaa03de79ebac286f9e8463980f1e5e3668bef3613cd79ee7f9742f4951125eb")
addappid(2980513, 1, "be9d10bd83b26b43679dfb437fd6242c4b2ffd74d32c2f948acb0cd7f2cb537f")
addappid(2980514, 1, "5e1af7af087b591da13cd91abddb4bc8d5ffff4576affdf13770a058092d8bfd")
