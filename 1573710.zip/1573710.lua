-- Lua provided by RyzenAPI
-- Game: Monster In The Dark

-- MAIN APPLICATION
addappid(1573710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573711, 1, "0057a7736e3037445e962c7c274bde687fa8a05e5c0a26ef790fcc9481143077")
