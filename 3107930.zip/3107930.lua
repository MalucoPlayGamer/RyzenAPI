-- Lua provided by RyzenAPI
-- Game: addappid(3107930)

-- MAIN APPLICATION
addappid(3107930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107931, 1, "1a9bc46e1bf594f9ab2b47a835bc870ad957a19c0ced89968cdf36a95ad362be")
