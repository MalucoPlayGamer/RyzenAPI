-- Lua provided by RyzenAPI
-- Game: 2075420

-- MAIN APPLICATION
addappid(2075420)
-- Game: addappid(2075420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075421, 1, "740750eea9b2d8919d9a08bda28ac3721bc47dac494845f64b2b1c18a38976e1")
