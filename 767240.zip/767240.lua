-- Lua provided by RyzenAPI
-- Game: BASIC8

-- MAIN APPLICATION
addappid(767240)

-- MAIN APP DEPOTS / PACKAGES
addappid(767241, 1, "6262e24daab644f71500f398c71874df97c0105a0ca0460c9d92ed3bea134137")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
