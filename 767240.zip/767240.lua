-- Lua provided by RyzenAPI 
-- Game: BASIC8
addappid(767240)
addappid(767241, 1, "6262e24daab644f71500f398c71874df97c0105a0ca0460c9d92ed3bea134137")
