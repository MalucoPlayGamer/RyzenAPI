-- Lua provided by RyzenAPI
-- Game: BASIC8

-- MAIN APPLICATION
addappid(767240)
-- Game: addappid(767240)

-- MAIN APP DEPOTS / PACKAGES
addappid(767241, 1, "6262e24daab644f71500f398c71874df97c0105a0ca0460c9d92ed3bea134137")
