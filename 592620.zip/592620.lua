-- Lua provided by RyzenAPI
-- Game: Game: Trajectory

-- MAIN APPLICATION
addappid(592620)
-- Game: addappid(592620)

-- MAIN APP DEPOTS / PACKAGES
addappid(592621, 1, "44b33c6d497b4ab97dc2b9a1edd773a5779c05d832f36aa8996d3d50238e65f6")
