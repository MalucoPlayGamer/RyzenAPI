-- Lua provided by RyzenAPI
-- Game: Riven (1997)

-- MAIN APPLICATION
addappid(63610)

-- MAIN APP DEPOTS / PACKAGES
addappid(63611, 1, "bbab6bc956cdec6de22bb380af99db1af024da253b40b7b7fed97cf752769562")
addappid(63612, 1, "a612fff0688008c3bcf1ca70e04ac0f70daa7121aa39d66b008936ba50979dc5")
