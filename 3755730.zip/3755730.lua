-- Lua provided by RyzenAPI
-- Game: 3755730

-- MAIN APPLICATION
addappid(3755730)
-- Game: addappid(3755730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3755731, 1, "c9f32b4e4e32408b076d888004074de99ca67e75a60512b18dfeb39a005cda89")
