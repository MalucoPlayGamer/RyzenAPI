-- Lua provided by RyzenAPI 
-- Game: Rotating Machine
addappid(3755730)
addappid(3755731, 1, "c9f32b4e4e32408b076d888004074de99ca67e75a60512b18dfeb39a005cda89")
