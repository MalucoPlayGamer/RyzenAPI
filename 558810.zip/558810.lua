-- Lua provided by RyzenAPI
-- Game: AppID 558810

-- MAIN APPLICATION
addappid(558810)

-- MAIN APP DEPOTS / PACKAGES
addappid(558811, 1, "cbdb06e296a6a366bcdf8187d458039015aeb2d5bea7c491c79dbb0d36ad8aa8")

