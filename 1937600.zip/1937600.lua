-- Lua provided by RyzenAPI
-- Game: 1937600

-- MAIN APPLICATION
addappid(1937600)
-- Game: addappid(1937600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937601, 1, "da30916c9ac93ca7b2f0a25a8d3d0fda8168eb7cab71208b2660270dc0cd00b4")
