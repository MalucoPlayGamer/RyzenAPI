-- Lua provided by SkyAPI 
-- Game: Сrime Сity
addappid(1937600)
addappid(1937601, 1, "da30916c9ac93ca7b2f0a25a8d3d0fda8168eb7cab71208b2660270dc0cd00b4")
