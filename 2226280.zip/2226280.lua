-- Lua provided by RyzenAPI
-- Game: BAPBAP

-- MAIN APPLICATION
addappid(2226280)
