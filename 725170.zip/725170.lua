-- Lua provided by RyzenAPI
-- Game: 725170

-- MAIN APPLICATION
addappid(725170)
-- Game: addappid(725170)

-- MAIN APP DEPOTS / PACKAGES
addappid(725171, 1, "b94788e6c16f0b35a17a7b2bb1876ad6b65359cba34f1f3fd73add444ba83f36")
