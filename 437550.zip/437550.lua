-- Lua provided by SkyAPI 
-- Game: Melon Simulator™
addappid(437550)
addappid(437551, 1, "98bd58accf1df112d54e34623b46c5a7db3eb3ed8e10e8a782c07e3bc20cd715")
