-- Lua provided by RyzenAPI
-- Game: Defense Zone

-- MAIN APPLICATION
addappid(312410)

-- MAIN APP DEPOTS / PACKAGES
addappid(312411, 1, "369f6bc0fcfbdbe0c857514b5737ffb80116372889223055f93e6dd8fa35dc0c")

