-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Classic Rock Trivia

-- MAIN APPLICATION
addappid(690240)

-- MAIN APP DEPOTS / PACKAGES
addappid(690241, 1, "1bd8fd7a852ecaeb947606b07a2153298fc6ca713e811c01e44c066c056434fa")

