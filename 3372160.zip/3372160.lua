-- Lua provided by RyzenAPI
-- Game: Game: FINAL FANTASY XIII-2 Original Soundtrack

-- MAIN APPLICATION
addappid(3372160)
-- Game: addappid(3372160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372161, 1, "ce7f75463fc61ff1b62e91ebd65887ba19960d31700db62e995c8d180d591a2d")
