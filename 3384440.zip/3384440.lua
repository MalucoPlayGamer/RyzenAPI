-- Lua provided by RyzenAPI 
-- Game: Call of Clans
addappid(3384440)
addappid(3384441, 1, "f2219ce6600a5dbf57d2c3c1969a93435d6c89bd9d4410543e0f8ae426f45aef")
