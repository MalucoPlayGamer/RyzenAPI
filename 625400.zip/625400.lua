-- Lua provided by RyzenAPI
-- Game: Sisters in hotel

-- MAIN APPLICATION
addappid(625400)

-- MAIN APP DEPOTS / PACKAGES
addappid(625401, 1, "a1903c05b9fedefc865b3a2f98564d23b777259f7d6e0a6f409449ff50730d61")
addappid(625402, 1, "4f05f929dc8975e5d94637967a2f1a303feec79da34b9ad2262d714aea3038ee")
addappid(625403, 1, "5497cfc00b92bd628ca963ff2f9ae23c844342fe9ac036720cf537f0b04341f4")

