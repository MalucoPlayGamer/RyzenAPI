-- Lua provided by RyzenAPI
-- Game: AppID 2301340

-- MAIN APPLICATION
addappid(2301340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301341, 1, "a34e2196e37b485e746dac2f3668fbdec9468a1f279e0639a5ce0b3c452bdd1e")
