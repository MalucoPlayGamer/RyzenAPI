-- Lua provided by RyzenAPI
-- Game: Hentai Swapy Puzzle

-- MAIN APPLICATION
addappid(2631570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631571,0,"62513fbce11494145d358ef16356ff1496e83ca861fe1eaa0bbf12716abdcd3c")

