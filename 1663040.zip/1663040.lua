-- Lua provided by SkyAPI 
-- Game: Amber Isle
addappid(1663040)
addappid(1663041, 1, "b9f4d19c440a906456ce54c56b3fd16b31dbdea5d2759168137e11f90fa29be8")
addappid(2809280, 0, "44ba18351f6adca7e2b4cebeaa1cf12028ea1d35ce1f207ef63f59a66613ab5d")
