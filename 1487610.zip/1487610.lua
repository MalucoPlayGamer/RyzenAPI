-- Lua provided by RyzenAPI
-- Game: 1487610

-- MAIN APPLICATION
addappid(1487610)
-- Game: addappid(1487610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487611, 1, "61c6336e4b7d6ae755071ee249f1b16fdb2d5358965bf8ba8c64548a818c8b14")
