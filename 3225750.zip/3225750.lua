-- Lua provided by RyzenAPI
-- Game: 3225750

-- MAIN APPLICATION
addappid(3225750)
-- Game: addappid(3225750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225751, 1, "95447f15e7c6fcb0f267bd7ec716d9afd49d4923dfe8e5057d54eb5ba1e66aa9")
