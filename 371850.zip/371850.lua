-- Lua provided by RyzenAPI 
-- Game: AppID 371850
addappid(371850)
addappid(371851, 1, "1d62f326c39dbd2816fb5d1038d530b6154aef3232102670de3c409d63e7007e")
