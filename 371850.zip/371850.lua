-- Lua provided by RyzenAPI
-- Game: 371850

-- MAIN APPLICATION
addappid(371850)
-- Game: addappid(371850)

-- MAIN APP DEPOTS / PACKAGES
addappid(371851, 1, "1d62f326c39dbd2816fb5d1038d530b6154aef3232102670de3c409d63e7007e")
