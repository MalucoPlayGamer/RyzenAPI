-- Lua provided by RyzenAPI
-- Game: Alarm112: Fire Unit

-- MAIN APPLICATION
addappid(4735640) -- Alarm112: Fire Unit

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4735641, 1, "3bde4dd99909e1a57fe93770d91da05546be5f1859278cf126b67cc125783b58") -- Depot 4735641

