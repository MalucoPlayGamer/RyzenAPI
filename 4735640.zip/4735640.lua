-- 4735640's Lua and Manifest Created by Hubcap Manifest
-- Alarm112: Fire Unit
-- Created: August 04, 2026 at 22:46:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4735640) -- Alarm112: Fire Unit
-- MAIN APP DEPOTS
addappid(4735641, 1, "3bde4dd99909e1a57fe93770d91da05546be5f1859278cf126b67cc125783b58") -- Depot 4735641
setManifestid(4735641, "8885755278122522334", 1319036917)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)