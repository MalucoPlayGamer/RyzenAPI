-- Lua provided by RyzenAPI
-- Game: Alphabeats: Master Edition

-- MAIN APPLICATION
addappid(420160)

-- MAIN APP DEPOTS / PACKAGES
addappid(420161, 1, "c532432e84ac9cccffd0d69531902fce595642bf8e8bae188c56169570f25ebc")
