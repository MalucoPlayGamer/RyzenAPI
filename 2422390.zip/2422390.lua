-- Lua provided by RyzenAPI
-- Game: Citizens: On Mars - Prologue

-- MAIN APPLICATION
addappid(2422390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2422391, 1, "e3565b5c9887ca5fbaa1c6f4f591f9457b514de70ba31997cc6090a625c83c98")

