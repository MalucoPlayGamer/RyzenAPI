-- Lua provided by RyzenAPI
-- Game: 2422390

-- MAIN APPLICATION
addappid(2422390)
-- Game: addappid(2422390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422391, 1, "e3565b5c9887ca5fbaa1c6f4f591f9457b514de70ba31997cc6090a625c83c98")
