-- Lua provided by RyzenAPI
-- Game: Diorama Builder - Noir City

-- MAIN APPLICATION
addappid(2777580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777581, 1, "e37216c0ce6a382c6fd9e6865a39fdc11c110f6ec562d9509b0a7ee734e86f8b")
