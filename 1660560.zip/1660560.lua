-- Lua provided by RyzenAPI 
-- Game: Chess Valley 2
addappid(1660560)
addappid(1660561, 1, "065993ca73b0e8494175772d683022791bf58fc441cfab12cacc0860ec46c5b3")
