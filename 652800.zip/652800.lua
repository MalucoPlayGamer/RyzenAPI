-- Lua provided by RyzenAPI
-- Game: Game: Sojourner

-- MAIN APPLICATION
addappid(652800)
-- Game: addappid(652800)

-- MAIN APP DEPOTS / PACKAGES
addappid(652801, 1, "0c7a89a660c2a5249e3f5db18309033c21d683e9d0ca36c33be290df5306bb3d")
