-- Lua provided by RyzenAPI
-- Game: AppID 646360

-- MAIN APPLICATION
addappid(646360)

-- MAIN APP DEPOTS / PACKAGES
addappid(646361, 1, "06bb76e12dcea1c4b5ebb48662b13c1df65ccaded92946a17d0db9ac9115dc9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
