-- Lua provided by RyzenAPI
-- Game: AppID 646360

-- MAIN APPLICATION
addappid(646360)
-- Game: addappid(646360)

-- MAIN APP DEPOTS / PACKAGES
addappid(646361, 1, "06bb76e12dcea1c4b5ebb48662b13c1df65ccaded92946a17d0db9ac9115dc9f")
