-- Lua provided by RyzenAPI
-- Game: AppID 1070940

-- MAIN APPLICATION
addappid(1070940)
-- Game: addappid(1070940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070941, 1, "a868a2689aae54274ce3324fa7af154e3deba81fd684409442ceae2626fe0675")
