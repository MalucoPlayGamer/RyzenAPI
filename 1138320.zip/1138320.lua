-- Lua provided by RyzenAPI
-- Game: AppID 1138320

-- MAIN APPLICATION
addappid(1138320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138321, 1, "a1450de1eb357cec85e0cf4fef79e1fab82cc478faf3a159d8c70bfbc1e6d87e")

