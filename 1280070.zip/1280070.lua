-- Lua provided by RyzenAPI 
-- Game: Ballad of The Masked Bandits
addappid(1280070)
addappid(1280071, 1, "db6a2c0888757a923f9651f7c4713565ba672b4ba15f64120f2746b95bcb8251")
