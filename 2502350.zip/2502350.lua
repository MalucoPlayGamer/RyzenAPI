-- Lua provided by RyzenAPI
-- Game: 2502350

-- MAIN APPLICATION
addappid(2502350)
-- Game: addappid(2502350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2502351, 1, "083cc8af8ecfe7d192aecc423d3eaaf9b7a4d6ddcfb6f49cceaedc3f39970de5")
