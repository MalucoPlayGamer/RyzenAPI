-- Lua provided by RyzenAPI
-- Game: Game: DUMB: Treasure

-- MAIN APPLICATION
addappid(1746370)
-- Game: addappid(1746370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746371, 1, "370bab09284e599f237c3523a1f1f91db907992770480e0b0e3b46f0d9f4553b")
