-- 4141350's Lua and Manifest Created by Hubcap Manifest
-- RUNT
-- Created: August 11, 2026 at 00:21:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4141350) -- RUNT
-- MAIN APP DEPOTS
addappid(4141351, 1, "c529b302c17d25d183d22e2217124a2f6ed52edc23ed0cab0180ff2b1a39e9f5") -- Depot 4141351
setManifestid(4141351, "8790755479777172789", 3105830893)