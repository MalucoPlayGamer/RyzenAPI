-- Lua provided by RyzenAPI
-- Game: RUNT

-- MAIN APPLICATION
addappid(4141350) -- RUNT

-- MAIN APP DEPOTS / PACKAGES
addappid(4141351, 1, "c529b302c17d25d183d22e2217124a2f6ed52edc23ed0cab0180ff2b1a39e9f5") -- Depot 4141351

