-- Lua provided by RyzenAPI
-- Game: AppID 1063300

-- MAIN APPLICATION
addappid(1063300)
-- Game: addappid(1063300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063301, 1, "a8f8613e0a9c346ceaeb93c550ca74371412c74fe75088e6cd22057eef7aa7f0")
