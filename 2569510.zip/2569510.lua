-- Lua provided by RyzenAPI
-- Game: MLB 9 Innings Rivals 26

-- MAIN APPLICATION
addappid(2569510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569511, 1, "aa9bad623f3f5f60cb0ead0ba890e9a51401a5a285ef007171dba86d9e0930e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
