-- Lua provided by RyzenAPI 
-- Game: MLB 9 Innings Rivals 26
addappid(2569510)
addappid(2569511, 1, "aa9bad623f3f5f60cb0ead0ba890e9a51401a5a285ef007171dba86d9e0930e0")
