-- Lua provided by RyzenAPI
-- Game: Somerholm

-- MAIN APPLICATION
addappid(2123150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123151, 1, "977072272c6cfa2f5769fc1e23471075d957d2cdda2ee26731da6e81b3a6c580")

