-- Lua provided by RyzenAPI
-- Game: 759970

-- MAIN APPLICATION
addappid(759970)
-- Game: addappid(759970)

-- MAIN APP DEPOTS / PACKAGES
addappid(759971, 1, "cdca582b58d84da6e5f2341c716c22871d322832f74afe98fbd8b8cffa4e4ab0")
