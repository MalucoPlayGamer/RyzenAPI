-- Lua provided by SkyAPI 
-- Game: Live the Life
addappid(1373220)
addappid(1373221, 1, "0e933ffef14ba0bdd9cbf1ff512d8158fa4a5d900e557f309371bc1dba5004ca")
