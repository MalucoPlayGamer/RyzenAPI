-- Lua provided by RyzenAPI
-- Game: Live the Life

-- MAIN APPLICATION
addappid(1373220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1373221, 1, "0e933ffef14ba0bdd9cbf1ff512d8158fa4a5d900e557f309371bc1dba5004ca")

