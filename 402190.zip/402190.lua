-- Lua provided by RyzenAPI
-- Game: 402190

-- MAIN APPLICATION
addappid(402190)
-- Game: addappid(402190)

-- MAIN APP DEPOTS / PACKAGES
addappid(402191, 1, "7cf2273bc6dd846db3dae0d7adcc5e3503b3d29873d32d45341818e3633a4534")
