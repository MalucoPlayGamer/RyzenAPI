-- Lua provided by RyzenAPI
-- Game: Final Outpost: Definitive Edition Demo

-- MAIN APPLICATION
addappid(3400990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400991, 1, "01fb9767a66ef66e3efbce600d64fba7a82d36473eef48b3a3746fe934caec1d")

