-- Lua provided by RyzenAPI
-- Game: Deadswitch Combat

-- MAIN APPLICATION
addappid(3408170)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4017250)
addappid(4017260)
addappid(4017270)
addappid(4017280)
addappid(4088790)
addappid(4505220)
