-- Lua provided by RyzenAPI
-- Game: Deadswitch Combat

-- MAIN APPLICATION
addappid(3408170)
