-- Lua provided by RyzenAPI
-- Game: 1241950

-- MAIN APPLICATION
addappid(1241950)
-- Game: addappid(1241950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241951, 1, "a72f902eff634a9e5b0146ae21bb82c6722719f49591de0b079bd34b79e73657")
