-- Lua provided by RyzenAPI
-- Game: Monomyth Demo

-- MAIN APPLICATION
addappid(1706860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706861, 1, "bb93fb165b631219ca3a8aa8f3a9ab97c26197025ecb1845b9764c3ca3a533d6")

