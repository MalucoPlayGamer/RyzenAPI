-- Lua provided by RyzenAPI
-- Game: Game: AppID 2775620

-- MAIN APPLICATION
addappid(2775620)
-- Game: addappid(2775620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775621, 1, "d7709f4773075afb9d53149458eb314b3931a487f1cb9a00cb7075b4b660585e")
