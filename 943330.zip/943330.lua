-- Lua provided by RyzenAPI
-- Game: Ruins War

-- MAIN APPLICATION
addappid(943330)

-- MAIN APP DEPOTS / PACKAGES
addappid(943331, 1, "a7d9cb16d0c8d421c63c8ed4d34d08103256ad3e52ad579b3273d69cae6c1dba")

