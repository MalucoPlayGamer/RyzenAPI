-- Lua provided by RyzenAPI
-- Game: addappid(290100)

-- MAIN APPLICATION
addappid(290100)

-- MAIN APP DEPOTS / PACKAGES
addappid(290102,0,"8964452056d0aeece0de5a0de024de4bb431008c7e976f89e75fa35e227042fd")
