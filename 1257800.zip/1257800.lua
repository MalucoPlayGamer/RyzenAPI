-- Lua provided by RyzenAPI
-- Game: Hats and Hand Grenades

-- MAIN APPLICATION
addappid(1257800)
addappid(1995540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257802,0,"e0b721a5464b893defb840d162d83a4a0f8de9ef6f939b7f894f4e801efe6e6f")

