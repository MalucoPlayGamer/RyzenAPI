-- Lua provided by RyzenAPI
-- Game: addappid(1437040)

-- MAIN APPLICATION
addappid(1437040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437041, 1, "b2faeb9b2b0807d646aec42f38c78a67ecdfab6b8b6a33ffffb66e47d4bae65c")
