-- Lua provided by RyzenAPI
-- Game: 544140

-- MAIN APPLICATION
addappid(544140)
-- Game: addappid(544140)

-- MAIN APP DEPOTS / PACKAGES
addappid(544141, 1, "4b4ecdc324ab9f1090bd7975433fc131f3b20a0d9ad331f51313b5cb915f3047")
