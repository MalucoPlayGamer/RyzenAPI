-- Lua provided by RyzenAPI
-- Game: 1421960

-- MAIN APPLICATION
addappid(1421960)
-- Game: addappid(1421960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421961, 1, "0c665167184e3a3001b7f30d1abaef574e81a6cc255df5f1c2a1d8ee96d813a0")
