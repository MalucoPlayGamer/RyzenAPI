-- Lua provided by RyzenAPI
-- Game: Cult Of Babel

-- MAIN APPLICATION
addappid(2078970)
-- Game: addappid(2078970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078971, 1, "80e6752621a9d7ba04b7c3a371b2108a29f09a792ebf4f5edac0edd324f00d14")
