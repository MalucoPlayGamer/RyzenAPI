-- Lua provided by RyzenAPI
-- Game: Golden Light

-- MAIN APPLICATION
addappid(1245430)
addappid(1915480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245431, 1, "b64b75d0477f52f967773c3590fe10b6d42f0affd900869d68e8c56b7268f92a")

