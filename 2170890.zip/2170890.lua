-- Lua provided by RyzenAPI
-- Game: Missing Pieces

-- MAIN APPLICATION
addappid(2170890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170891, 1, "68fd7a9a64ee41ff2d9ebd66c741abd36f8fe03ff1e159c3ed521c30b4ed1920")

