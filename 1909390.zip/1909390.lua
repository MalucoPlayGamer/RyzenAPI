-- Lua provided by RyzenAPI
-- Game: Game: Once Upon a Breeze (Demo)

-- MAIN APPLICATION
addappid(1909390)
-- Game: addappid(1909390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909391, 1, "94b1726b856f95faa3a9e281d2621f3d80380f2417ffe05da3389143f82b8d4f")
