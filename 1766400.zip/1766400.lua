-- Lua provided by RyzenAPI
-- Game: qingping Bookstore

-- MAIN APPLICATION
addappid(1766400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766401, 1, "42fc4573534086989376b72058940e0fd79e5bac45a254c2da741fd9c522d06f")

