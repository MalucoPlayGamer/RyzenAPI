-- Lua provided by SkyAPI 
-- Game: AppID 3075280
addappid(3075280)
addappid(3075281, 1, "ad6c4f3d8e2bb49dded3141d6a804b43ba21690c85453246430c577812cd26d8")
