-- Lua provided by RyzenAPI
-- Game: Rogue Contracts: Syndicate

-- MAIN APPLICATION
addappid(453660)

-- MAIN APP DEPOTS / PACKAGES
addappid(453661, 1, "97ad43dcf27b243dfea2a61447f68db88ee909a089ccb14b24f16cb594144c38")
