-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY IX Original Soundtrack

-- MAIN APPLICATION
addappid(3365710)
-- Game: addappid(3365710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365711, 1, "c67081096b66ce35a2f6fd8f4fa18281a6d942eba6140ec174c98a816f4bd0f3")
