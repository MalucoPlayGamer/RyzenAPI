-- Lua provided by RyzenAPI
-- Game: addappid(908350)

-- MAIN APPLICATION
addappid(908350)

-- MAIN APP DEPOTS / PACKAGES
addappid(908351, 1, "ac5159c07f81eb5e2361b23abe68919434805f7e42a16fffebd5f0ff8cd1dbd1")
