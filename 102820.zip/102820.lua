-- Lua provided by RyzenAPI
-- Game: AppID 102820

-- MAIN APPLICATION
addappid(102820)

-- MAIN APP DEPOTS / PACKAGES
addappid(102821, 1, "abb3e7760a4eeebb6d0b410e11fdb8c719b92e94c439bd9517de754880b612ee")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(102822)
