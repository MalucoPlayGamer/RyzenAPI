-- Lua provided by SkyAPI 
-- Game: AppID 793050
addappid(793050)
addappid(793051, 1, "2949cb19e6c915335f38b0cc4858a181617f418e961c75315829285ab1a385ef")
