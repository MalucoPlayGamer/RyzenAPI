-- Lua provided by RyzenAPI
-- Game: AppID 793050

-- MAIN APPLICATION
addappid(793050)

-- MAIN APP DEPOTS / PACKAGES
addappid(793051, 1, "2949cb19e6c915335f38b0cc4858a181617f418e961c75315829285ab1a385ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
