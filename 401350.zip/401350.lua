-- Lua provided by RyzenAPI
-- Game: AppID 401350

-- MAIN APPLICATION
addappid(401350)
-- Game: addappid(401350)

-- MAIN APP DEPOTS / PACKAGES
addappid(401351, 1, "9ff94bbbc5bb2df2734bd0c6092b41f5e7d310ed7e5b445c9f3ec97c4df1a4dd")
