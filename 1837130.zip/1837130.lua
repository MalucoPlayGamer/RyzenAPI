-- Lua provided by SkyAPI 
-- Game: 星塔星夜MONOBEHEVO
addappid(1837130)
addappid(1837131, 1, "bc10a479e86e5833d2d4e7be6feb2e29e132c7b1b7dd949fc3718a9bf69e5639")
addappid(1995310, 0, "01efeb622ffa43abaddaf8cbbb68d0a7edda0412ce38a05b1f38760223e71dd4")
addappid(2008290, 0, "5b790a7ec97814130d20f58e97c73055a6d17042793e80d77c9ca26a09a5fb14")
