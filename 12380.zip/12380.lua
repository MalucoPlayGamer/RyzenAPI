-- Lua provided by RyzenAPI
-- Game: Jagged Alliance 2 Gold

-- MAIN APPLICATION
addappid(12380)

-- MAIN APP DEPOTS / PACKAGES
addappid(12381, 1, "710a880317ee88c6c21534f7975cf084913b0ea084b618f4a9302bedeac52138")

