-- Lua provided by SkyAPI 
-- Game: Drama Queens
addappid(2741820)
addappid(2741821, 1, "21293a99e6badffe09948e0ac6d37c51ed14a72a7674c9ab8c6982673b80ca7a")
