-- Lua provided by RyzenAPI 
-- Game: AppID 1182160
addappid(1182160)
addappid(1182161, 1, "e088da0ef925fd537878f6bcfeeb291d09a8bd0bf90551f9df4abe65e14a27b0")
