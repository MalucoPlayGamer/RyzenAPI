-- Lua provided by RyzenAPI
-- Game: The Maze : Endless nightmare

-- MAIN APPLICATION
addappid(580970)

-- MAIN APP DEPOTS / PACKAGES
addappid(580971, 1, "69e6922558ab710e5ecac37632c78d9092fd9dee4dd29cf982b9163998f44604")
