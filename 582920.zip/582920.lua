-- Lua provided by RyzenAPI
-- Game: From Shadows

-- MAIN APPLICATION
addappid(582920)

-- MAIN APP DEPOTS / PACKAGES
addappid(582922,0,"04804ae8fff76e54fc442d12d2d922cb6d302ca0528d34d149f0ef13285dbcc8")
addappid(582923,0,"46a25420abdba4669a6ec5696022b884475664a147e3fd7dc88800498b70c0d8")
addappid(582924,0,"62786a4ba78ed4ccf0492b0df393305d530d159fe9bab9e7766163ef5442f512")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
