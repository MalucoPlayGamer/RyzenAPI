-- Lua provided by RyzenAPI 
-- Game: Digimon Survive
addappid(871980)
addappid(871981, 1, "f25a7a7ea76f051ede83b59fef4bef825807cdc488dccc8b89d43dd2038981de")
