-- Lua provided by RyzenAPI
-- Game: Game: Digimon Survive

-- MAIN APPLICATION
addappid(871980)
-- Game: addappid(871980)

-- MAIN APP DEPOTS / PACKAGES
addappid(871981, 1, "f25a7a7ea76f051ede83b59fef4bef825807cdc488dccc8b89d43dd2038981de")
