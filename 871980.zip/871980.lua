-- Lua provided by RyzenAPI
-- Game: Digimon Survive

-- MAIN APPLICATION
addappid(871980)
addappid(1958820)
addappid(1958830)
addappid(2000030)
addappid(2000031)
addappid(2000032)
addappid(2000033)
addappid(2005340)
addappid(2005341)

-- MAIN APP DEPOTS / PACKAGES
addappid(871981,0,"f25a7a7ea76f051ede83b59fef4bef825807cdc488dccc8b89d43dd2038981de")

