-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Seasons of Harvest Farm Tileset

-- MAIN APPLICATION
addappid(3011780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011780,0,"7bc933791f67205e9a26ed5e171cce1b49e0bc55be7cb2e5e6a48426722d7280")
