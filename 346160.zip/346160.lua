-- Lua provided by RyzenAPI
-- Game: Game: AppID 346160

-- MAIN APPLICATION
addappid(346160)
-- Game: addappid(346160)

-- MAIN APP DEPOTS / PACKAGES
addappid(346161, 1, "a680f35dc4e89645022eb08e2250ce4bff149ad382cff43398215b267df19f4c")
