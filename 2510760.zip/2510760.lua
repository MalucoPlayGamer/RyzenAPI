-- Lua provided by RyzenAPI
-- Game: Game: Gods Wars : infinity Epic

-- MAIN APPLICATION
addappid(2510760)
-- Game: addappid(2510760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510761, 1, "3c09948685c0430ab0028f0dbe407aaa046486a7fdaaafddf7f820c4d419f26a")
