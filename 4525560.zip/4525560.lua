-- Lua provided by RyzenAPI
-- Game: Garlic Ramen Shop Simulator

-- MAIN APPLICATION
addappid(4525560) -- Garlic Ramen Shop Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4525561, 1, "4adbda02fd14afdaed6a9e470f08f0f9c1ab11d45669e936b94186b6b03bde69") -- Depot 4525561
addappid(4525562, 1, "206e40eaac744893f68431bcb0eb986aae80917f5eb3f92e9d00791e8bb7bff3") -- Depot 4525562

