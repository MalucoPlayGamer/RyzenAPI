-- 4525560's Lua and Manifest Created by Hubcap Manifest
-- Garlic Ramen Shop Simulator
-- Created: August 03, 2026 at 19:21:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4525560) -- Garlic Ramen Shop Simulator
-- MAIN APP DEPOTS
addappid(4525561, 1, "4adbda02fd14afdaed6a9e470f08f0f9c1ab11d45669e936b94186b6b03bde69") -- Depot 4525561
setManifestid(4525561, "3853077449168289225", 1698828240)
addappid(4525562, 1, "206e40eaac744893f68431bcb0eb986aae80917f5eb3f92e9d00791e8bb7bff3") -- Depot 4525562
setManifestid(4525562, "5545821675962937062", 1678246872)