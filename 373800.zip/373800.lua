-- Lua provided by RyzenAPI
-- Game: 373800

-- MAIN APPLICATION
addappid(373800)
-- Game: addappid(373800)

-- MAIN APP DEPOTS / PACKAGES
addappid(373801, 1, "32919a0778b99a4935e2e28a19a5bb54788af8bf0197fc08f26a9ee8b37f5edb")
addappid(373802, 1, "0875de1c911dbabc6a0f1440ef3a57eb38c4e0ac5afcbf345c28872e002d029e")
