-- Lua provided by RyzenAPI 
-- Game: 100 Italy Cats
addappid(3141130)
addappid(3141131, 1, "a031a5a52cfba1769268c1df773853eca5acca6c5ba2eada1f5f9a4666d7e73d")
