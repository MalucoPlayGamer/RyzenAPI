-- Lua provided by RyzenAPI
-- Game: Game: 100 Italy Cats

-- MAIN APPLICATION
addappid(3141130)
-- Game: addappid(3141130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141131, 1, "a031a5a52cfba1769268c1df773853eca5acca6c5ba2eada1f5f9a4666d7e73d")
