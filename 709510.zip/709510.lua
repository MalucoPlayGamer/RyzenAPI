-- Lua provided by RyzenAPI
-- Game: 709510

-- MAIN APPLICATION
addappid(709510)
-- Game: addappid(709510)

-- MAIN APP DEPOTS / PACKAGES
addappid(709511, 1, "2042c9dee37dcd92ba065a242cc7fe53d7ea4141dc08382f17ce032daa6f94ff")
