-- Lua provided by RyzenAPI
-- Game: Towards The Pantheon

-- MAIN APPLICATION
addappid(709510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(709511, 1, "2042c9dee37dcd92ba065a242cc7fe53d7ea4141dc08382f17ce032daa6f94ff")

