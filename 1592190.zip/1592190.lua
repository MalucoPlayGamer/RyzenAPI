-- Lua provided by RyzenAPI 
-- Game: BONELAB
addappid(1592190)
addappid(1592191, 1, "bc35259e671ec631d2c638538cb2cabeb1201419b767484986fd0c9145ca0713")
