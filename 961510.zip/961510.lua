-- Lua provided by RyzenAPI 
-- Game: AppID 961510
addappid(961510)
addappid(961511, 1, "36e06abd7b555b40468a5c08557c8081a124a5e6bca1aac1ca2febe0a65dfa21")
