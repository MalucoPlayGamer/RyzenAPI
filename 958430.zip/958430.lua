-- Lua provided by RyzenAPI
-- Game: Fast Dust Demo

-- MAIN APPLICATION
addappid(958430)
-- Game: addappid(958430)

-- MAIN APP DEPOTS / PACKAGES
addappid(958431, 1, "e038edeb24a92b734c6ca1af5f73269d33f192ddf34a8f1229e5dc399d178779")
