-- Lua provided by RyzenAPI
-- Game: AppID 2336130

-- MAIN APPLICATION
addappid(2336130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336131, 1, "3ceaabc408ea10c1cdbfc0ed6ea1837866c417600a07d36fb4a58c9d9d63f233")

