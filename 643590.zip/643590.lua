-- Lua provided by RyzenAPI
-- Game: Everyday Golf VR

-- MAIN APPLICATION
addappid(643590)
-- Game: addappid(643590)

-- MAIN APP DEPOTS / PACKAGES
addappid(643591, 1, "91182ef9605b051b781f73fe7422f772d0ae04566c044d3f7f15792c5476a205")
