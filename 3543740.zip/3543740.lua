-- Lua provided by RyzenAPI
-- Game: The B.L.O.O.M Initiative

-- MAIN APPLICATION
addappid(3543740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543741, 1, "ff1bf59d9c03ed78044306070d55eadb325969205a4188a9853cd136fb3089f8")
