-- Lua provided by RyzenAPI
-- Game: TRAHA Global

-- MAIN APPLICATION
addappid(2119490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119491, 1, "741ec350f58a390ba1a24d3530a541ff165cb183c8202326d14bc0c049f4797a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
