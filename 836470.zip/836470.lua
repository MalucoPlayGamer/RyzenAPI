-- Lua provided by RyzenAPI
-- Game: Mage Fort

-- MAIN APPLICATION
addappid(836470)
-- Game: addappid(836470)

-- MAIN APP DEPOTS / PACKAGES
addappid(836471, 1, "beacc5632f7e39222b6e45697dc560e276ccc40f3bc2fdcb830e130bf7844df0")
