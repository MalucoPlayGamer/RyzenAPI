-- Lua provided by RyzenAPI
-- Game: addappid(375850)

-- MAIN APPLICATION
addappid(375850)

-- MAIN APP DEPOTS / PACKAGES
addappid(375851, 1, "781a158cfe0cee1c8ced324b46ee4dd2030f4e396b2d0e64b590845d1aaad8f5")
