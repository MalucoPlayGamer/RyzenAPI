-- Lua provided by RyzenAPI
-- Game: addappid(1427510)

-- MAIN APPLICATION
addappid(1427510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427511, 1, "16cd681aeaa48423ac09bddb66107e3039eae1541d5e47e6daf030a8ec9a1525")
