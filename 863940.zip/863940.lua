-- Lua provided by RyzenAPI
-- Game: Game: Treasure Adventure Game

-- MAIN APPLICATION
addappid(863940)
-- Game: addappid(863940)

-- MAIN APP DEPOTS / PACKAGES
addappid(863941, 1, "65ea878be820364d07d012667348418ca350f53f60b16475c1d9bebc9105f948")
