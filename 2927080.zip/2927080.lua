-- Lua provided by RyzenAPI
-- Game: 2927080

-- MAIN APPLICATION
addappid(2927080)
-- Game: addappid(2927080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927081, 1, "936b144c7dc72d48e5a0f3ca469d9f6a484b0750e0541994612ab1e15d9d7d3a")
