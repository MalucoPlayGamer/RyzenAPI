-- Lua provided by SkyAPI 
-- Game: follow dream
addappid(2927080)
addappid(2927081, 1, "936b144c7dc72d48e5a0f3ca469d9f6a484b0750e0541994612ab1e15d9d7d3a")
