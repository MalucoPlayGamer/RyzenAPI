-- Lua provided by RyzenAPI
-- Game: AppID 876890

-- MAIN APPLICATION
addappid(876890)
-- Game: addappid(876890)

-- MAIN APP DEPOTS / PACKAGES
addappid(876891, 1, "a66cf8827e54bee4cdcfc284ad9dba72dafaf5402d918c15a2f02d9139272cda")
