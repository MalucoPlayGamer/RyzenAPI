-- Lua provided by RyzenAPI
-- Game: Game: Jerez's Arena

-- MAIN APPLICATION
addappid(1333360)
-- Game: addappid(1333360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333361, 1, "c4373ab715ff7c8e195f6aa029e2b98bbbbc8aed27bc5923af2017c8aff56e65")
