-- Lua provided by RyzenAPI
-- Game: Game: 猎魔者战纪

-- MAIN APPLICATION
addappid(1066290)
-- Game: addappid(1066290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066291, 1, "087b642e26f3aaa9c77977610cecaec221200904a68fbec4602c217603c84ee6")
