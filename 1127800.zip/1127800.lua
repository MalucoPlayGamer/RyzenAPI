-- Lua provided by RyzenAPI
-- Game: 异化之恶〇Abnormal Treatment - OST

-- MAIN APPLICATION
addappid(1127800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127800,0,"19f374cf8bdc6963d125321c83b48f1a090708b3cb037b9f4ce263c79f2dcb55")

