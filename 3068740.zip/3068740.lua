-- Lua provided by RyzenAPI
-- Game: Ground of Aces Demo

-- MAIN APPLICATION
addappid(3068740)
-- Game: addappid(3068740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068742,0,"57c3a05809437082f2e741502c3d8a0b162e790a04dd2744b95fb64b2dbc8141")
