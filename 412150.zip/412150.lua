-- Lua provided by RyzenAPI
-- Game: Game: AppID 412150

-- MAIN APPLICATION
addappid(412150)
addappid(497750)
-- Game: addappid(412150)

-- MAIN APP DEPOTS / PACKAGES
addappid(412151, 1, "4ded44f190a70362966ec403136d8b724277cea7333ce378dd2e7b4368aeab73")
