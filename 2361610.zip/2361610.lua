-- Lua provided by RyzenAPI
-- Game: In His Time

-- MAIN APPLICATION
addappid(2361610)
-- Game: addappid(2361610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361611, 1, "850adefdee2312dfdc4e3e6b2742f65ba2dcdd23a765137345471affa19a690e")
