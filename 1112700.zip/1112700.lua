-- Lua provided by SkyAPI 
-- Game: AppID 1112700
addappid(1112700)
addappid(1112701, 1, "85444dcd2171b64de4e2ece44f5ba30c9c9248facb4bb4b79249cb55b3f11de1")
addappid(1143300, 0, "b46938bddae85e282c7cd4fd1638c21fe83df52cf9f6d3db04d4361729c07f68")
