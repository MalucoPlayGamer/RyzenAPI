-- Lua provided by RyzenAPI
-- Game: Guroopia!

-- MAIN APPLICATION
addappid(1112700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1112701, 1, "85444dcd2171b64de4e2ece44f5ba30c9c9248facb4bb4b79249cb55b3f11de1")
addappid(1143300, 0, "b46938bddae85e282c7cd4fd1638c21fe83df52cf9f6d3db04d4361729c07f68")

