-- Lua provided by RyzenAPI
-- Game: Game: Code Reactors

-- MAIN APPLICATION
addappid(2171640)
-- Game: addappid(2171640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171641, 1, "2c2be216977623b52a7175a2655e271bb41214ea52c50084132b506d22dd4830")
