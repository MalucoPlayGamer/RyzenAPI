-- Lua provided by RyzenAPI
-- Game: Game: The Burnt School

-- MAIN APPLICATION
addappid(1615020)
-- Game: addappid(1615020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615021, 1, "d4a2a70b2c92970005420ba13eaabcf739bb857bd464d19b2a64524c850bc806")
