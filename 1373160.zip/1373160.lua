-- Lua provided by RyzenAPI 
-- Game: Pilgrims Soundtrack
addappid(1373160)
addappid(1373161, 1, "2bcf3e6ef82857be57de9ca21d06ad1a971db5e74b16f38d8df3f43bb9c141e6")
addappid(1373162, 1, "b7e30c8e47694ef1f6d144f56f20751d33f16f3bcd5c8c20dedf3aecc4d501a7")
