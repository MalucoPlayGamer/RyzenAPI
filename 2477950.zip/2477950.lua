-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2477950)
addappid(2477951)
addappid(2477952)
addappid(2477954)
-- Game: addappid(2477950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477953,0,"29a6b2e8b0e85d685a79a8f8a6d4c12122a964cd7ced11d742f8b45d91f1850f")
