-- Lua provided by RyzenAPI
-- Game: Jumping Joe! - Friends Edition

-- MAIN APPLICATION
addappid(1273590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273591, 1, "043bbcda0956b123b0668b016f96aa48ad83ceae71bd42097420de0d2050a9d7")

