-- Lua provided by RyzenAPI
-- Game: Game: AppID 628060

-- MAIN APPLICATION
addappid(628060)
-- Game: addappid(628060)

-- MAIN APP DEPOTS / PACKAGES
addappid(628061, 1, "a6cf040a75cd5b37c28840a5a87ded72f9ab930804f603f30783bd2fdb0126e2")
addappid(628062, 1, "4b0a89d2d393278761caac429c3c7e0539cb51bd5daa7ad4f805bb50343a0156")
