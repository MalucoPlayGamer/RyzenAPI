-- Lua provided by RyzenAPI
-- Game: Game: King of Ping Pong: MEGAMIX

-- MAIN APPLICATION
addappid(2940100)
-- Game: addappid(2940100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940101, 1, "5f38968f1d22d7fe807d99502d6342b77ac6df6f9b99c59754a6d24640554482")
