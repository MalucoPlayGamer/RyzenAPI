-- Lua provided by RyzenAPI
-- Game: Breaking Fast

-- MAIN APPLICATION
addappid(523870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(523871, 1, "ed3b920aff596403fc7af5a99d63f07edb0fdaa35868fc8100205415d507fe5b")
addappid(523872, 1, "61bc79ef7cb170395e88b5ca593c27c21babcf109d229e0aa199081b49d233d0")
addappid(523873, 1, "bc046cfb5581d021047f47d012950fd6809ed547829dc2b54f47acc033e74018")

