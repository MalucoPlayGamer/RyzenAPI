-- Lua provided by SkyAPI 
-- Game: Breaking Fast
addappid(523870)
addappid(523871, 1, "ed3b920aff596403fc7af5a99d63f07edb0fdaa35868fc8100205415d507fe5b")
addappid(523872, 1, "61bc79ef7cb170395e88b5ca593c27c21babcf109d229e0aa199081b49d233d0")
addappid(523873, 1, "bc046cfb5581d021047f47d012950fd6809ed547829dc2b54f47acc033e74018")
