-- Lua provided by RyzenAPI 
-- Game: Dungeon Defenders Demo
addappid(201680)
addappid(201681, 1, "1bc4a040c8299a24b93d81f63af5a87b39a4b7051b8bc8331d9eaacd0a008a36")
