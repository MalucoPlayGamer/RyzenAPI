-- Lua provided by RyzenAPI
-- Game: Monsters Domain: Prologue

-- MAIN APPLICATION
addappid(2003060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2003061, 1, "13a3e677172b3d9eb19210783a8617ad677733a320326fdbff2c7322fc4219f3")

