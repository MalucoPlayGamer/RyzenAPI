-- Lua provided by RyzenAPI
-- Game: Hello Goodboy

-- MAIN APPLICATION
addappid(1789090)
-- Game: addappid(1789090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789092,0,"329dc7969f31ce65396063d4a06c07b8826a50de7010062a58754a66d9881a1a")
