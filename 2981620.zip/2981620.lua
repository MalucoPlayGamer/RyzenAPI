-- Lua provided by RyzenAPI
-- Game: Game: Mind Diver Demo

-- MAIN APPLICATION
addappid(2981620)
-- Game: addappid(2981620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981621, 1, "969c10ca299415622d7f32eed56b847b2040e59126dd0e7ffbbd141876f6c8c2")
