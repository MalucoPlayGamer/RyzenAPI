-- Lua provided by RyzenAPI
-- Game: addappid(1589020)

-- MAIN APPLICATION
addappid(1589020)
addappid(2711640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589021, 1, "03c1a0fc5e1c1fe4d4723cadbe3baf30a58946b9551619a64ff96950b78a15b4")
