-- Lua provided by RyzenAPI
-- Game: Organ Trail: Director's Cut

-- MAIN APPLICATION
addappid(233740)

-- MAIN APP DEPOTS / PACKAGES
addappid(233741, 1, "a156f52ce80d353704339390bece6e3b2b2b0a4bc81d4078708944c0c8558c13")
addappid(233742, 1, "1802325a3e76bea0ef40d6155d4afd97fb002ecbb5b39303523ea6387ebccc37")
addappid(233743, 1, "9f21931b87396f059dc0609007b09df1fe63009abf548a274730a5ac385409d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(408300)
