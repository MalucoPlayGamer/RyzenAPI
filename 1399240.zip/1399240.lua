-- Lua provided by RyzenAPI
-- Game: Yotsume God -Reunion-

-- MAIN APPLICATION
addappid(1399240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399241, 1, "1f4f41958051e402c9f897cd0013d74c3ffbcc008ddcc8deeae44fd11ef16a02")

