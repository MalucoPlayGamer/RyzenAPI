-- Lua provided by RyzenAPI
-- Game: Bikini Girls

-- MAIN APPLICATION
addappid(1708210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708211, 1, "ace8a14a2069ae0a15393184d671256813c8a0a803914e471a4f46717bf0f6af")
