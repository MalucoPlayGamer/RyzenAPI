-- Lua provided by SkyAPI 
-- Game: AppID 887900
addappid(887900)
addappid(887901, 1, "8cb1b546a25521acfd52934e87f82696b0dfed0c8bb0e50c4b6aa1a3f56ddd27")
