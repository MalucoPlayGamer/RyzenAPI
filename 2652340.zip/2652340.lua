-- Lua provided by RyzenAPI
-- Game: 2652340

-- MAIN APPLICATION
addappid(2652340)
-- Game: addappid(2652340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652341, 1, "8cde3b913e209898bd42b5916dfa30d7aefd6cf1d2d021de611b3067ebadf5f9")
