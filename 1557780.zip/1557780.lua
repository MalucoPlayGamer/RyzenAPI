-- Lua provided by RyzenAPI
-- Game: Help Me!

-- MAIN APPLICATION
addappid(1557780)
-- Game: addappid(1557780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557781, 1, "1bd0b6a4d07000e4cb7c373308bccb0f3e618f62f5b1b143082297dc13384aef")
addappid(1557782, 1, "ecceabf3690a286eb97a0bd5a0bb9f891ff706417f82c0576ade61ff8650e91b")
