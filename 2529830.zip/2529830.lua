-- Lua provided by RyzenAPI 
-- Game: Pixel Colony
addappid(2529830)
addappid(2529831, 1, "1e5d52d99ac51024bf2f829e1c257f5a42dfc611b29757198c3f8228fd60b669")
