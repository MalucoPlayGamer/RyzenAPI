-- Lua provided by RyzenAPI
-- Game: AppID 521950

-- MAIN APPLICATION
addappid(521950)

-- MAIN APP DEPOTS / PACKAGES
addappid(521951, 1, "cd781e75f61edf345b0c7fbc77903a4e06b066bedc45af5cd4ecde79ad26dae9")

