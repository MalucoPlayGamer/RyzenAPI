-- Lua provided by RyzenAPI
-- Game: My Holiness the Gobliness Demo

-- MAIN APPLICATION
addappid(2597790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597791, 1, "76b34b1f8d327740d6a28b23b2bc793aad7a5e241d14778f9c6d15d6dc7c12fa")
