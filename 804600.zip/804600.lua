-- Lua provided by RyzenAPI
-- Game: Trivia Vault Football Trivia

-- MAIN APPLICATION
addappid(804600)

-- MAIN APP DEPOTS / PACKAGES
addappid(804601, 1, "ebf16521e3c8e13f7fe86b98e7bc718bf456f1778f5a33f118cbe1eb68d19930")

