-- Lua provided by RyzenAPI
-- Game: Mystery Riddles

-- MAIN APPLICATION
addappid(598620)

-- MAIN APP DEPOTS / PACKAGES
addappid(598621,0,"debf0ad05b4a0397d994ed461b69aa85184087db4dcbce56651b0739bd4961f0")

