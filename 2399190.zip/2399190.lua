-- Lua provided by RyzenAPI
-- Game: Star Quest

-- MAIN APPLICATION
addappid(2399190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2399191, 1, "430d889847c6c4eaada74aef2b3ad55cf26402e4f725f1ce403a609f634f1854")

