-- Lua provided by RyzenAPI
-- Game: Star Quest

-- MAIN APPLICATION
addappid(2399190)
-- Game: addappid(2399190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399191, 1, "430d889847c6c4eaada74aef2b3ad55cf26402e4f725f1ce403a609f634f1854")
