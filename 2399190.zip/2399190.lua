-- Lua provided by SkyAPI 
-- Game: Star Quest
addappid(2399190)
addappid(2399191, 1, "430d889847c6c4eaada74aef2b3ad55cf26402e4f725f1ce403a609f634f1854")
