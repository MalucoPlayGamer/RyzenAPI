-- Lua provided by RyzenAPI
-- Game: Dungeon Quest

-- MAIN APPLICATION
addappid(849920)

-- MAIN APP DEPOTS / PACKAGES
addappid(849921, 1, "8deead6793dee533b5599077f9967e6d94b686b8a80a4928a746b922fac8c52c")

