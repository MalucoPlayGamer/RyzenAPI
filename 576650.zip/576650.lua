-- Lua provided by RyzenAPI
-- Game: 576650

-- MAIN APPLICATION
addappid(576650)
-- Game: addappid(576650)

-- MAIN APP DEPOTS / PACKAGES
addappid(576651, 1, "9aa915bd7a6260193fcb85b21caba039213fb67f705ce693190bb1bbc268802a")
