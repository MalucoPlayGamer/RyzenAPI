-- Lua provided by RyzenAPI 
-- Game: Fovos VR
addappid(576650)
addappid(576651, 1, "9aa915bd7a6260193fcb85b21caba039213fb67f705ce693190bb1bbc268802a")
