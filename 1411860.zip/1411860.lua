-- Lua provided by RyzenAPI
-- Game: Game: Invasion: Lost in Time

-- MAIN APPLICATION
addappid(1411860)
-- Game: addappid(1411860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411861, 1, "75e75d140749b656f7c8072f9656b674842768313605d00ce3bd2c8107aeb67a")
