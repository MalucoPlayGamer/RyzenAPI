-- Lua provided by RyzenAPI
-- Game: Ni no Kuni Wrath of the White Witch Remastered - Wallpaper -

-- MAIN APPLICATION
addappid(1154000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154000,0,"8ce42d40489dd4eb6b3e1fc33a88f87687751d03d5f4a56e6d79ac2d852f919b")

