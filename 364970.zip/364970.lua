-- Lua provided by RyzenAPI
-- Game: AppID 364970

-- MAIN APPLICATION
addappid(364970)

-- MAIN APP DEPOTS / PACKAGES
addappid(364971, 1, "6608842dfa11e0746db96217866a65b7cf9e205dff01086f5488972b7701e2e0")
addappid(364972, 1, "8c4084797c2d79df0f5423c1e68bba40d740e289e5e241f2d8f44fc9d7693bc9")
addappid(364973, 1, "c497d3f16ff790c46b94cebd07fe430d4f39d65d8852bc13b776c0cd4885cc0c")
addappid(364974, 1, "4ba3aaab6c3cc13dfe7ec36f7f3253f747c7a36925fefc287686bedc2a589cc4")
addappid(366190, 0, "33e59bea54c8af965e0b27322c88d25538f484929fcef0eb066ea231384169c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
