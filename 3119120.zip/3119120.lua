-- Lua provided by RyzenAPI
-- Game: 3119120

-- MAIN APPLICATION
addappid(3119120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119120,0,"7dc274e184cdd5432bc4becb4c02724eab0ff5c5fe41e05e32bda4184b9d5642")
