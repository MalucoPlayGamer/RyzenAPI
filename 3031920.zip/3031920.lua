-- Lua provided by RyzenAPI
-- Game: addappid(3031920)

-- MAIN APPLICATION
addappid(3031920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3031921, 1, "d27a099555e49475ae20e35e6efddb9c8ee39301c8bed17ad1bcf3b7507be282")
