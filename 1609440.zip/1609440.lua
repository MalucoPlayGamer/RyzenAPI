-- Lua provided by RyzenAPI
-- Game: addappid(1609440)

-- MAIN APPLICATION
addappid(1609440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609441, 1, "782f0ebbb239f9faa594962fee3d88fcf6e9adb22434bb731741a5f2a05cb861")
