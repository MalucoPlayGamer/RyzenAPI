-- Lua provided by RyzenAPI
-- Game: Game Type DX

-- MAIN APPLICATION
addappid(373630)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(373631, 1, "ee5612d93dc85707e871536c325b3fa8b739f9e527d3e3ac3fa11ddd04e67ddf")

