-- Lua provided by RyzenAPI
-- Game: Game Type DX

-- MAIN APPLICATION
addappid(373630)

-- MAIN APP DEPOTS / PACKAGES
addappid(373631, 1, "ee5612d93dc85707e871536c325b3fa8b739f9e527d3e3ac3fa11ddd04e67ddf")
