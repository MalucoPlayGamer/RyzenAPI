-- Lua provided by RyzenAPI
-- Game: 2179170

-- MAIN APPLICATION
addappid(2179170)
-- Game: addappid(2179170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179172,0,"23f53d1a9eea8840e76ab0b793ef58979ed88f0ba5a04df0414f69fdf66d15b6")
