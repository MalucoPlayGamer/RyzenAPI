-- Lua provided by RyzenAPI
-- Game: Car Detailing Simulator Demo

-- MAIN APPLICATION
addappid(1522510)
-- Game: addappid(1522510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522519,0,"499e8995801112936f3e084641074abc2ede78babfa25255ad2675f82a611091")
