-- Lua provided by RyzenAPI 
-- Game: AppID 1000510
addappid(1000510)
addappid(1000511, 1, "8bbf026c363d3e2bcc7589154ada55422f08b14b18dc7e5285647b67ea21b51a")
