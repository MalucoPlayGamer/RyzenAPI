-- Lua provided by RyzenAPI
-- Game: 919280

-- MAIN APPLICATION
addappid(919280)
-- Game: addappid(919280)

-- MAIN APP DEPOTS / PACKAGES
addappid(919281, 1, "3ce51f70b689c57d25ffac5396273520667c532e3ceea4c44e7d43c2aa622367")
addappid(919282, 1, "eb9e654fca69170908803df02b48eec4fca07abcc0cbb142148f74198d2878a8")
