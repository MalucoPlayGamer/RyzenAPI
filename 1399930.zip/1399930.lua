-- Lua provided by RyzenAPI
-- Game: Game: Furry Shades of Gay

-- MAIN APPLICATION
addappid(1399930)
-- Game: addappid(1399930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399931, 1, "1b2f6f2a1a54e6ac798b85cb9d72b5d49eb8813708248948318dfeb2f8e806c1")
addappid(1744310, 0, "4a47ec44c2dc80f0a5d5aed80a8dd94f7243d11d0a56f7bd88433215522b1bfc")
addappid(2403180, 0, "3f5f5e36f8c4314e65a558569abd798e63d3ede332fdb3e22c62a8d14cb6713e")
