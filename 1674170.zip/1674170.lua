-- Lua provided by RyzenAPI
-- Game: Sprocket

-- MAIN APPLICATION
addappid(1674170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1674171, 1, "499f4c7f29d6fce3e91d26828c4520d13d5dfc7a4b88ba43d5fe01959baaec54")

