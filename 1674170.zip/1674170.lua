-- Lua provided by RyzenAPI
-- Game: addappid(1674170)

-- MAIN APPLICATION
addappid(1674170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674171, 1, "499f4c7f29d6fce3e91d26828c4520d13d5dfc7a4b88ba43d5fe01959baaec54")
