-- Lua provided by RyzenAPI
-- Game: 2628390

-- MAIN APPLICATION
addappid(2628390)
-- Game: addappid(2628390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628391, 1, "3f438cd76ec5e8517fc5a3756c2d4930b966b45059561ea616bcc0f9e538ded4")
