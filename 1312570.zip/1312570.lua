-- Lua provided by RyzenAPI 
-- Game: ハンターハーツ Hunter Hearts
addappid(1312570)
addappid(1312571, 1, "2b89bb0ae9b4b40cccd719b266a404e03af0dc66d23d7d369d2792506c7772b7")
