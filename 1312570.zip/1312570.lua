-- Lua provided by RyzenAPI
-- Game: 1312570

-- MAIN APPLICATION
addappid(1312570)
-- Game: addappid(1312570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312571, 1, "2b89bb0ae9b4b40cccd719b266a404e03af0dc66d23d7d369d2792506c7772b7")
