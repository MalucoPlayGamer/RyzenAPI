-- Lua provided by RyzenAPI
-- Game: WarDogs: Red's Return

-- MAIN APPLICATION
addappid(1247160)
-- Game: addappid(1247160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247161, 1, "d67cd4186e345c297238e29f2d73220447915f468dd8511a347baa36cefe1661")
