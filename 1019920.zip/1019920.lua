-- Lua provided by RyzenAPI
-- Game: addappid(1019920)

-- MAIN APPLICATION
addappid(1019920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019921, 1, "3ab20f19cea6c8e7cef4ddba8f6172f61c19f3accba7123f2670f639b3817949")
addappid(1060700, 0, "9aef0fb105394b435e48f1de105d422ce50eb80dba1acb22616c13385273b303")
