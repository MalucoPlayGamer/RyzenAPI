-- Lua provided by RyzenAPI
-- Game: 我家恋天使太废柴鸟真～可怕。

-- MAIN APPLICATION
addappid(4491980)

-- MAIN APP DEPOTS / PACKAGES
addappid(4491981,0,"0eb1296b5f2ad6037ebc415b376e1c3d142b67280b0d8fd7c05c4a8d680f5111")

