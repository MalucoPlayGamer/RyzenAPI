-- Lua provided by RyzenAPI
-- Game: 2424740

-- MAIN APPLICATION
addappid(2424740)
-- Game: addappid(2424740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424741, 1, "9f56be9750d74a9a9c48586e135c55b6939ef795c1ec8ee5160b4536fd24a570")
