-- Lua provided by RyzenAPI
-- Game: 希望之城 The City Of Hope

-- MAIN APPLICATION
addappid(2424740)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2424741, 1, "9f56be9750d74a9a9c48586e135c55b6939ef795c1ec8ee5160b4536fd24a570")

