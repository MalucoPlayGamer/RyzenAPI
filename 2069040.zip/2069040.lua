-- Lua provided by RyzenAPI
-- Game: setManifestid(2069043,"5919216189154471993")

-- MAIN APPLICATION
addappid(2069040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069043,0,"0ddce7b44b6cf7b8808e115a3ead4991ca85fd80c77fa4149c5cbdb73dddd15f")
