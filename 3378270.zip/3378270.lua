-- Lua provided by RyzenAPI
-- Game: Love and Bitch

-- MAIN APPLICATION
addappid(3378270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378271, 1, "b8dc00a62803ced58faa3ad513bb7543d6dd6c1604b8e2c79d5518757d146096")
addappid(3378272, 1, "2ac31e231ae6e01d0aac9445124d742377fbf3ebd9a7e7d4d1a9d6118d251e9b")
addappid(3378273, 1, "8f7143d2465e0e5d2e4ca6470d474f4b2df6c6a52ea538ae877c8c957e70ea2c")
addappid(3378274, 1, "80a8d5ad0a7dfe05cbd12bc21dfa1f8bc049f4c0554866b8e1942dac07077477")
