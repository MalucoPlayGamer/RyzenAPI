-- Lua provided by RyzenAPI
-- Game: 1415540

-- MAIN APPLICATION
addappid(1415540)
-- Game: addappid(1415540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415541, 1, "511ba72df2c148c372e435d6aac9fc5d233d9d3f69f3ee46bb5d3733a26a66fe")
