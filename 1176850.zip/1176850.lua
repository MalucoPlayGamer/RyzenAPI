-- Lua provided by RyzenAPI
-- Game: Game: AppID 1176850

-- MAIN APPLICATION
addappid(1176850)
-- Game: addappid(1176850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176851, 1, "4e8db12c5a1cdcd614146edc1658ba14829060315c43f8ce03cc2722e8b42c34")
