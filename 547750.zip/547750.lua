-- Lua provided by RyzenAPI
-- Game: Endless Night - Alpha

-- MAIN APPLICATION
addappid(547750)

-- MAIN APP DEPOTS / PACKAGES
addappid(547751, 1, "9aff69e7e37bdd3a16b35dfe1b783a81fac888911411a889c71fe4ce7aeaf6d1")

