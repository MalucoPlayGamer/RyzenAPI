-- Lua provided by RyzenAPI
-- Game: TRADER LIFE SIMULATOR

-- MAIN APPLICATION
addappid(1415660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1415661, 1, "b740ee7aae04ace2f2c021647729eaae0da3a389ae40f2e74c8a9e2f66640895")

