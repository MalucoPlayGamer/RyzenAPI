-- Lua provided by RyzenAPI
-- Game: Mini-Market Simulator VR

-- MAIN APPLICATION
addappid(2282410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2282411, 1, "2a3153c6537980cff540829487727fd1a70642fe5206b82486c44be1b8c2e7b9")

