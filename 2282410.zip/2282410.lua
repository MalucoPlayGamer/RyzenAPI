-- Lua provided by RyzenAPI 
-- Game: Mini-Market Simulator VR
addappid(2282410)
addappid(2282411, 1, "2a3153c6537980cff540829487727fd1a70642fe5206b82486c44be1b8c2e7b9")
