-- Lua provided by RyzenAPI
-- Game: Fracture Point

-- MAIN APPLICATION
addappid(3560110) -- Fracture Point

-- MAIN APP DEPOTS / PACKAGES
addappid(3560111, 1, "ad4914accbd90797968ff9f72cdbfe4b37ec854e84bfefb5b698f53600f88cbb") -- Depot 3560111
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
