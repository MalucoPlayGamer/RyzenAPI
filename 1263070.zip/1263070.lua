-- 1263070's Lua and Manifest Created by Hubcap Manifest
-- Blightbound
-- Created: September 29, 2025 at 01:29:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1263070) -- Blightbound
-- MAIN APP DEPOTS
addappid(1263071, 1, "850b739619642c88079846b442d40e3283129ac43c904be5ac708b93ab1b074a") -- Blightbound Content
setManifestid(1263071, "1840497777127718622", 4009076742)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1504040) -- Blightbound - Weapon skin (Flamingo)
addappid(1518260) -- Blightbound - Name plate skin (Viper)
addappid(1518261) -- Blightbound - Weapon skin (Holo Blade)
addappid(1518262) -- Blightbound - Weapon skin (Electro-Daggers)