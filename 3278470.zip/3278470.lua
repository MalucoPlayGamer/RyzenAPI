-- Lua provided by RyzenAPI
-- Game: Game: Beloved Rapture Soundtrack

-- MAIN APPLICATION
addappid(3278470)
-- Game: addappid(3278470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278471, 1, "73dc5d8ea5373db3bd390ecc6b21a362503f0eab88a0753a7e94c75f7b480305")
