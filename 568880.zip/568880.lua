-- Lua provided by RyzenAPI
-- Game: Sniper Elite 4 Dedicated Server

-- MAIN APPLICATION
addappid(568880)

-- MAIN APP DEPOTS / PACKAGES
addappid(568881, 1, "edd7786124c9d1901a04a26b37d60be5df08a275548e81a5a8f460d063052126")

