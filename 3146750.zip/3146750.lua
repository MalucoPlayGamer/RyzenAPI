-- Lua provided by RyzenAPI
-- Game: Game: The Black Labyrinth Demo

-- MAIN APPLICATION
addappid(3146750)
-- Game: addappid(3146750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146751, 1, "5001d2b7f027b73580ab693a086fe88b98357a5be3469a2768cfe5904fc7d0be")
