-- Lua provided by RyzenAPI
-- Game: Game: AppID 1276130

-- MAIN APPLICATION
addappid(1276130)
-- Game: addappid(1276130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276131, 1, "56b036f04adcde903b635cb4f478b781bb6fe1d8140a357651d6181a6b823afb")
