-- Lua provided by RyzenAPI
-- Game: AppID 870040

-- MAIN APPLICATION
addappid(870040)

-- MAIN APP DEPOTS / PACKAGES
addappid(870041, 1, "e855365236b0b1e2f10cc6cc7206c54deb9a5aa97f03d8e3d0d286e7c12d333a")

