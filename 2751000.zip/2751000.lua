-- Lua provided by RyzenAPI
-- Game: Prince of Persia The Lost Crown

-- MAIN APPLICATION
addappid(2751000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751001, 1, "3570b20701e5a605870438400f373ede72ba4b0d20d00fedabb48ac6a5158136")
