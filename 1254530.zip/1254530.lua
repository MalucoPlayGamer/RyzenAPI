-- Lua provided by RyzenAPI
-- Game: 1254530

-- MAIN APPLICATION
addappid(1254530)
-- Game: addappid(1254530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254531, 1, "b81901f54f2febc79d2db30c08164fef125593f9a99d2e8b07c542a5645d9017")
