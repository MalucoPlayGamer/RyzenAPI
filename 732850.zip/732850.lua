-- Lua provided by RyzenAPI
-- Game: Sector Assault

-- MAIN APPLICATION
addappid(732850)
-- Game: addappid(732850)

-- MAIN APP DEPOTS / PACKAGES
addappid(732851, 1, "a01ccf9c61eabe15eae1b83e4c2052b0dad4ff358437adee2c25417b34258855")
addappid(732852, 1, "1eb9ea73576a265f870ba4fe9c6b272ba9facc38b5d95f3c93995f7011976417")
