-- Lua provided by SkyAPI 
-- Game: Santa's Workshop
addappid(727200)
addappid(727201, 1, "610d6a5c7818e214d969775d3d71763c08f06eb608818fe681b4c8646851f0af")
