-- Lua provided by RyzenAPI
-- Game: Game: Path to Mnemosyne

-- MAIN APPLICATION
addappid(770410)
-- Game: addappid(770410)

-- MAIN APP DEPOTS / PACKAGES
addappid(770411, 1, "ba0e52f28a9caf87f43acb45eb981e800212703a433c00daf88b77b2ff7cd933")
