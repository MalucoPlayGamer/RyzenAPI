-- Lua provided by RyzenAPI
-- Game: Game: The Memory of Eldurim

-- MAIN APPLICATION
addappid(268670)
-- Game: addappid(268670)

-- MAIN APP DEPOTS / PACKAGES
addappid(268671, 1, "d7df985038e2257e7004ff1580b1f571d33174c1a65aa82ab2248a498f4c0b46")
