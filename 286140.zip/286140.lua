-- Lua provided by RyzenAPI
-- Game: Game: Eidolon

-- MAIN APPLICATION
addappid(286140)
-- Game: addappid(286140)

-- MAIN APP DEPOTS / PACKAGES
addappid(286141, 1, "d5367a73ba6b61257acf6cef913d9bc6003ffa33648258b17225bd5f3ddac73e")
addappid(286142, 1, "d7c9fc6be187cec732de386c761d58b761a17c49c297f8af06c671e39467eb0f")
