-- Lua provided by RyzenAPI
-- Game: Eidolon

-- MAIN APPLICATION
addappid(286140)

-- MAIN APP DEPOTS / PACKAGES
addappid(286141, 1, "d5367a73ba6b61257acf6cef913d9bc6003ffa33648258b17225bd5f3ddac73e")
addappid(286142, 1, "d7c9fc6be187cec732de386c761d58b761a17c49c297f8af06c671e39467eb0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
