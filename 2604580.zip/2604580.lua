-- Lua provided by RyzenAPI
-- Game: THE JUSOU 3

-- MAIN APPLICATION
addappid(2604580)
-- Game: addappid(2604580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604581, 1, "54085ee848103cfef508f154f2335326af5c60d80c54abf78f28165d0fa8d095")
