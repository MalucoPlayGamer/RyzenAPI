-- Lua provided by RyzenAPI
-- Game: 1819980

-- MAIN APPLICATION
addappid(1819980)
-- Game: addappid(1819980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819981, 1, "8ca809d7a42f87b3aab28b60b7c023864811e71a97e69e60d99fc0f06f0ffa09")
