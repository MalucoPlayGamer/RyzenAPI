-- Lua provided by RyzenAPI
-- Game: Game: AppID 302060

-- MAIN APPLICATION
addappid(302060)
-- Game: addappid(302060)

-- MAIN APP DEPOTS / PACKAGES
addappid(302061, 1, "75f7f8a6f9e14cdad8721a1919654b90763e0cb843ae8b95a074d908693d67dc")
addappid(302062, 1, "def871fe79bbcff44d62cb2f07386f0890b2ef56871c9f4f753608e238e7e4a6")
