-- Lua provided by RyzenAPI
-- Game: Signed and Sealed With a Kiss

-- MAIN APPLICATION
addappid(933230)
-- Game: addappid(933230)

-- MAIN APP DEPOTS / PACKAGES
addappid(933231, 1, "ac70fa456c7658f30c8a264abe56d16fa54be0af9103c0c81a2e38684b3db4bf")
addappid(933260, 0, "c88f13448799f066e6e8f6262a740f4f5d35a7b4a80e9726e1dcf76419a5e75e")
addappid(1069410, 0, "3081b97750031da0ca4b45ab74335f3d6829c96bf9fee20cef853420af0fd4ad")
addappid(1148190, 0, "ff6534faf1731971865b5a6e27bcdabe1c2faaeb87b2e72b0de80b06246c72af")
