-- Lua provided by RyzenAPI
-- Game: Return to Krondor

-- MAIN APPLICATION
addappid(564960)
-- Game: addappid(564960)

-- MAIN APP DEPOTS / PACKAGES
addappid(564961, 1, "cce5053dada54d274440252f2866bb87450a7b7052240386163255f9ff7153d6")
