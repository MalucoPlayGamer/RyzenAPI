-- Lua provided by RyzenAPI
-- Game: Drying Paint Simulator VR

-- MAIN APPLICATION
addappid(903880)

-- MAIN APP DEPOTS / PACKAGES
addappid(903881, 1, "496db922d9b3b9e93b157d044c76cd6681110fa65141217f757f7904d5e9ae17")
