-- Lua provided by RyzenAPI 
-- Game: Andromeda: Rebirth of Humanity
addappid(1511650)
addappid(1511651, 1, "1e5d24a2f93b9298b1a9bd7e9f33510ce01ea53087bee513def691ba99998c28")
addappid(1511652, 1, "3b009b902981a466a87bd54816be5b3615a1e769d733e7d9493d153d88a00e9e")
