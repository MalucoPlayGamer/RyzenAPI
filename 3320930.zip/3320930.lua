-- Lua provided by RyzenAPI
-- Game: 3320930

-- MAIN APPLICATION
addappid(3320930)
-- Game: addappid(3320930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320931, 1, "d7f818bd1a88df25164b18ff2dfb5209fa3b3c454342ba5b22973106bac3764a")
