-- Lua provided by RyzenAPI
-- Game: Steambirds Alliance

-- MAIN APPLICATION
addappid(386010)
addappid(1144710)

-- MAIN APP DEPOTS / PACKAGES
addappid(386011, 1, "1f6e00293d1183d685c354dc11a409c41bf31cc23bb30737f511d368d4788593")
addappid(386012, 1, "275b025f5c6abb82dc1f126100015ecd8d289768d5ed282e2f170a6c464931d9")
