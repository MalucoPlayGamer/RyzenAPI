-- Lua provided by RyzenAPI
-- Game: AppID 1205730

-- MAIN APPLICATION
addappid(1205730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205731, 1, "bf9174e7e0775f4bcdf491373b7c6dd382cc57a69dde6bf9b49c0c14c55a34bf")
