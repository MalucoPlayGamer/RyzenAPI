-- Lua provided by RyzenAPI
-- Game: Game: Mad Experiments: Escape Room Premium Pack

-- MAIN APPLICATION
addappid(1472800)
-- Game: addappid(1472800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472801, 1, "3dbb61a6ab92add03af4feb736bacc4dd8c11da497a31f5d528035f6412f5a4f")
