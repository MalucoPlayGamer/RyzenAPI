-- Lua provided by RyzenAPI
-- Game: Go Mecha Ball Demo

-- MAIN APPLICATION
addappid(2581780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581781, 1, "18fd36ac413fa3299f79d63eacecf7de0723f339af4a87b444b4ce17345d82fb")
