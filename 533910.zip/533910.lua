-- Lua provided by RyzenAPI
-- Game: Offroad: VR

-- MAIN APPLICATION
addappid(533910)

-- MAIN APP DEPOTS / PACKAGES
addappid(533911, 1, "4faa81088e4eb7eb587a42a08a00336b1f98b1bee9232f05b6fbb56e86d151c1")
