-- Lua provided by RyzenAPI
-- Game: The Paribneur Combination

-- MAIN APPLICATION
addappid(1838670)
-- Game: addappid(1838670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838671, 1, "9ab3fd24145c8c90f5829ba3cf5b240c103457f3af2ba7ed7472b1b6327b96fc")
