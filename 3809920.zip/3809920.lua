-- 3809920's Lua and Manifest Created by Hubcap Manifest
-- Wicked Little Witch 小小坏女巫
-- Created: August 11, 2026 at 00:21:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3809920) -- Wicked Little Witch 小小坏女巫
-- MAIN APP DEPOTS
addappid(3809921, 1, "5e2b7103ddc1dfe91b2dbbab9a44ef3b5e4fa5c0e14248466a87c8cc36d0b02b") -- Depot 3809921
setManifestid(3809921, "4456087244779116538", 846324386)