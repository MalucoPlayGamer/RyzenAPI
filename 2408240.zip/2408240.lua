-- Lua provided by RyzenAPI
-- Game: Game: Fly Wheel

-- MAIN APPLICATION
addappid(2408240)
-- Game: addappid(2408240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408241, 1, "9d75da1f69852a859eb6a5cdac5258f9d12c23956fd01a341fa44f54e4e5d342")
