-- Lua provided by RyzenAPI
-- Game: 1894230

-- MAIN APPLICATION
addappid(1894230)
-- Game: addappid(1894230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894231, 1, "bb8c02c4411e5aea9675913ee5eae4ef64bf9dd695c32ad385c49f6c1bfe166f")
