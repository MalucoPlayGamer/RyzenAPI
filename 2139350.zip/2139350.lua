-- Lua provided by RyzenAPI
-- Game: 2139350

-- MAIN APPLICATION
addappid(2139350)
-- Game: addappid(2139350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139351, 1, "ae31583640422e52057a598b9523fa7fd92e6624ba6ed92dc2bcb6d5ef8ff6b9")
