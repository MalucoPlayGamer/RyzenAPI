-- Lua provided by RyzenAPI
-- Game: Loot or Die

-- MAIN APPLICATION
addappid(523760)

-- MAIN APP DEPOTS / PACKAGES
addappid(523761,0,"3f044aeeaa00f0a1e811c5b545fc2d880ef79b723a0f14c71994cd8f710ccfd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
