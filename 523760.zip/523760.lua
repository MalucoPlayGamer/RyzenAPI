-- Lua provided by RyzenAPI
-- Game: Loot or Die

-- MAIN APPLICATION
addappid(523760)

-- MAIN APP DEPOTS / PACKAGES
addappid(523761,0,"3f044aeeaa00f0a1e811c5b545fc2d880ef79b723a0f14c71994cd8f710ccfd3")

