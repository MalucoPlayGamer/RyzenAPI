-- Lua provided by RyzenAPI
-- Game: addappid(1019250)

-- MAIN APPLICATION
addappid(1019250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019251, 1, "48b4e02e53d0465ff1ab60c7b7f630fb892de1a86bddf60f3d267f85c8cb2af5")
addappid(1019252, 1, "f07c62900acf4b33f10022d71191b2a5e312f0ab579030abebd673517bd0ee49")
