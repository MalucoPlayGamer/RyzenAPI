-- Lua provided by RyzenAPI
-- Game: Last Word

-- MAIN APPLICATION
addappid(355530)
addappid(368820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(355531, 1, "ef0d9f97e799eef17a805bcf08d486fd7b3f384f387799578ec95a759f6b8cea")
addappid(355533, 1, "79eeefd82972cee1ee039ceace8f7ba049b4e20872f1cc54cc94c9418b01aac6")
addappid(355534, 1, "d26086c72cf6f8d452ccfd765d3241cb64c5a83d9c4646259dd6c03d1a3fef60")

