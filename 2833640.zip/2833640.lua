-- Lua provided by SkyAPI 
-- Game: Pyramids and Aliens: Escape Room
addappid(2833640)
addappid(2833641, 1, "236ae49a23176d706470f33502cee3a45f72698e5ff167281bfe5c386d50717f")
