-- Lua provided by RyzenAPI
-- Game: Spiritbound: The Goddess's Quest

-- MAIN APPLICATION
addappid(3421410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421412,0,"97650cbe9c0805ccf8854d79c4a52c5d16f6d33478a2abb51feaa66dddf2782c")

