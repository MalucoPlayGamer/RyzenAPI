-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Landmark Pack Vol.1

-- MAIN APPLICATION
addappid(1952426)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952426,0,"65b79bf6c3a724d576770cd5973b8ad6254717f6c60ece4900671e3b45fa7049")
