-- Lua provided by RyzenAPI
-- Game: addappid(350140)

-- MAIN APPLICATION
addappid(350140)

-- MAIN APP DEPOTS / PACKAGES
addappid(350141, 1, "0b8dbef0b6f50f226a9ba59429c552270237b05f4fb2671e4475434fb853d1d2")
