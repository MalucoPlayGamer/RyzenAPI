-- Lua provided by RyzenAPI
-- Game: Majestic-12

-- MAIN APPLICATION
addappid(350140)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(350141, 1, "0b8dbef0b6f50f226a9ba59429c552270237b05f4fb2671e4475434fb853d1d2")

