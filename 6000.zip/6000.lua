-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Republic Commando™

-- MAIN APPLICATION
addappid(6000)
-- Game: addappid(6000)

-- MAIN APP DEPOTS / PACKAGES
addappid(6001, 1, "15050729a6407a6dc38c021c8790c0a6a01cfb8e741226ade2c292aad4277537")
addappid(6002, 1, "429c5f4d2a7e9f36a45a9aabd9e8bd0b4f12c5a53c941b9ea1e35b37c8a982d7")
addappid(6003, 1, "d1ca96f26854033a4c7c36972aea27321da8805838f3b3ad25e1a633a9e253e2")
addappid(6004, 1, "1eb063ff67bdead87cdd842d1417cd355718928c1144e351a037ef64f6f58c97")
addappid(6005, 1, "d5e076452e0dc3df9fc727ac202490191b7f320e8d5d5b0a8307fce8b7340424")
