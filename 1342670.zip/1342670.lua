-- Lua provided by RyzenAPI
-- Game: 1342670

-- MAIN APPLICATION
addappid(1342670)
-- Game: addappid(1342670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342670,0,"9b47563c76f4c2b3db87ba744350d9ec8ff44dd662c44b2a7a07e23d1627af92")
