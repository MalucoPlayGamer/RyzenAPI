-- Lua provided by RyzenAPI
-- Game: Orders of Magnitude

-- MAIN APPLICATION
addappid(1250300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1250303,0,"8d9222ee30062b947d2320177e2326c97aeb90f32561283ec5c4dda0c3d82750")

