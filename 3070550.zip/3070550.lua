-- Lua provided by RyzenAPI
-- Game: 3070550

-- MAIN APPLICATION
addappid(3070550)
-- Game: addappid(3070550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070551, 1, "83ed4611161a7899e19ba3c55182fde05b16e19c354d7d2a0dbd0b6b655cbf9c")
addappid(3070552, 1, "17eca143690f688631213aa5a1b97370d36530d1fcd274f5fddbb9ed8c6bd8a1")
