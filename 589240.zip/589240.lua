-- Lua provided by RyzenAPI
-- Game: addappid(589240)

-- MAIN APPLICATION
addappid(589240)

-- MAIN APP DEPOTS / PACKAGES
addappid(589241, 1, "6498bc2b7f640ca0007395f28e0ee96bf998a9785649d8675f6f77894e82dac7")
