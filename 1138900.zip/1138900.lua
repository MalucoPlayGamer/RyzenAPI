-- Lua provided by RyzenAPI
-- Game: addappid(1138900)

-- MAIN APPLICATION
addappid(1138900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138901, 1, "c2402dad61a478c4d4764be90f02d737fb4fc679ac5c3c4688c5c6ad23e91d15")
