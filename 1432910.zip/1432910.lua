-- Lua provided by RyzenAPI
-- Game: Godlike Burger

-- MAIN APPLICATION
addappid(1432910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432911, 1, "5297145e4fda3277ada496c6af9f83f7bab55c27b2e55c69105b6546557d7166")
addappid(1432912, 1, "17ee54a7376d5040680f3be1b53d8e61766c8f1bade29212471f4c9b29ac0a1b")
addappid(1432913, 1, "01e0b1bfa2ab58776122e6781948daaff7284a0bd2f46a3f8692b5e6979244f6")
addappid(1670580, 0, "9b59574bdf6f03c848d2d2b71e01fdf2f091899cdb36c484e44d71051e91cc1b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
