-- Lua provided by RyzenAPI
-- Game: Gunmetal Arcadia Zero

-- MAIN APPLICATION
addappid(555610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(555611, 1, "53e39b8fdc8cc00f1ab24d4e8d6d7a6fc23d135e6c706909a91f2a2e6a307408")
addappid(555612, 1, "27359dd3ae09b6041e4355538d7ff0ca3f2971b7cc535e54e2da11079222617c")
addappid(555613, 1, "a779fc13656b4f2d7c03043a1c119b14eef7c2d7b78e0b4da5a78dd10887ccdf")

