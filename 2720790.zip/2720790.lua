-- Lua provided by RyzenAPI 
-- Game: AppID 2720790
addappid(2720790)
addappid(2720791, 1, "964da76d0cbc38e5899bd6461daef082fe59210ff978f887975803acbec9ba57")
