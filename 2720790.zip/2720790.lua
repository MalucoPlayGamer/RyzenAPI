-- Lua provided by RyzenAPI
-- Game: 2720790

-- MAIN APPLICATION
addappid(2720790)
-- Game: addappid(2720790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720791, 1, "964da76d0cbc38e5899bd6461daef082fe59210ff978f887975803acbec9ba57")
