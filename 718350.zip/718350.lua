-- Lua provided by SkyAPI 
-- Game: Loot Collection: Mahjong
addappid(718350)
addappid(718351, 1, "a244c90df0f27acff9bdf6b1c5ad517e65689369336ea925fb23443c26573d33")
