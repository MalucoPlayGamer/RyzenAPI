-- Lua provided by RyzenAPI
-- Game: Loot Collection: Mahjong

-- MAIN APPLICATION
addappid(718350)
-- Game: addappid(718350)

-- MAIN APP DEPOTS / PACKAGES
addappid(718351, 1, "a244c90df0f27acff9bdf6b1c5ad517e65689369336ea925fb23443c26573d33")
