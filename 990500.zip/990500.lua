-- Lua provided by RyzenAPI
-- Game: Game: PANTY SLIDE VR

-- MAIN APPLICATION
addappid(990500)
-- Game: addappid(990500)

-- MAIN APP DEPOTS / PACKAGES
addappid(990501, 1, "c8f9c21cf9810f36ef77b46b94171bbc3e13a3c353c1186818b3aad25ce86841")
