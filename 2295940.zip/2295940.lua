-- Lua provided by RyzenAPI
-- Game: Master of Realms

-- MAIN APPLICATION
addappid(2295940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295941,0,"38bbd0fd06b8ccc46da341f00f01ccdb782a66fc63b30da91636c7691584f616")
addappid(3295470,0,"80999ae1e3eec0b4c408c07ebd43535988b0b918d0c206b7db7dcdda7aa8b6d2")
addappid(4046940,0,"72aa43922b2b5e3c86f88d4e62d0371fc8aeef0ea25f58cd45d844cefacc6510")
addappid(4321980,0,"bcccd70526557d98c96ed9e931f0992fddf02dee13b1a321ba6a2bb9c3dcc4ee")
addappid(4321990,0,"0de1e42cc6b3cd2277fc06d12df92334e1a0621edc1eb25a99f3549d53ef3f7f")
addappid(4322030,0,"11a5467fd54462e0855bb66837b6946163691a190dd37cb6b4078470537193a9")
addappid(4434960,0,"50022aa757734457544ade7088bc65e2fe34b0030e3d4fa88d442a42e4c0e328")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3295170)
