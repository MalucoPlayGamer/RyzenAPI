-- Lua provided by RyzenAPI 
-- Game: Untold Mystery: Angel's Cry 2 - Tears of the Fallen
addappid(413470)
addappid(413471, 1, "cad6c8e2daf1f169c976bc9f825529b4e46c3f00398c1a4d5d43db30e9b29535")
addappid(413472, 1, "3bbbe24b7301a4bcf631c960667023d9ceb047dfa20b0b0e4cb1b50396c43a72")
addappid(413473, 1, "bfc6ce04b0473151f68839640798b7b6e0b0ea0cc48325c88c24975055f5f4b0")
