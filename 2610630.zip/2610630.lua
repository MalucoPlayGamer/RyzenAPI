-- Lua provided by RyzenAPI
-- Game: addappid(2610630)

-- MAIN APPLICATION
addappid(2610630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610631, 1, "ef81e7a92e8cf2c588eae5f73bb4dfcace6972328e031ebcf99842bb523e618c")
