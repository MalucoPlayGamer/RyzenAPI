-- Lua provided by RyzenAPI
-- Game: Game: Calcflow

-- MAIN APPLICATION
addappid(547280)
-- Game: addappid(547280)

-- MAIN APP DEPOTS / PACKAGES
addappid(547281, 1, "083bf198268ab82aeac88507937a55939d64cf20e01325e58140366b3f4f4109")
