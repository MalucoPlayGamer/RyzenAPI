-- Lua provided by RyzenAPI
-- Game: addappid(922580)

-- MAIN APPLICATION
addappid(922580)

-- MAIN APP DEPOTS / PACKAGES
addappid(922581, 1, "1f20777246011f0e969fe0c7b2a2080d570692177d9e7cedfb8e0cf973fa10e0")
