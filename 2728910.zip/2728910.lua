-- Lua provided by RyzenAPI
-- Game: addappid(2728910)

-- MAIN APPLICATION
addappid(2728910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728911, 1, "2228fedb02fc1dae6df1ff85f83baf7428cc742396e857a549d35788b009d44c")
