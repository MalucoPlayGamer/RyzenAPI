-- Lua provided by RyzenAPI
-- Game: Gnomes

-- MAIN APPLICATION
addappid(3133060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133061, 1, "a76320d1e852615ddeceb3f882bf2ed6a44fd35b783d326c63f2542b9b99c9e9")
