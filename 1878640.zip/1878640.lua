-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1878640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878642,0,"208ae86028c6528d51de4cbd9bb07a3bce290bccf42decf9beeb3cf076b14399")
addtoken(1878640,7863677098843194496)

