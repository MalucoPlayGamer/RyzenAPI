-- Lua provided by RyzenAPI
-- Game: Game: Sex and the Furry Titty 2: Sins of the City

-- MAIN APPLICATION
addappid(1750200)
-- Game: addappid(1750200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750201, 1, "0fc0057a167ee8605ab6dfeaef8ecccff8f406bcd28b2d06c32585006f70331a")
addappid(2123470, 0, "c55542f436fcc2a9f218a17312be20db29fb233bcca85d9d4ed055875b6bbcca")
addappid(2123471, 0, "38e96b866cdd613bed564a2892f027927c82fa09b801e260dcdd4ced5d432d2c")
