-- Lua provided by RyzenAPI
-- Game: addappid(489220)

-- MAIN APPLICATION
addappid(489220)

-- MAIN APP DEPOTS / PACKAGES
addappid(489221, 1, "6c145f95dffa411729948107d9b2cc03d8356276e7a7e02f77411e5dcaa9873d")
