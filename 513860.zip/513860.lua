-- Lua provided by RyzenAPI
-- Game: Game: Elena

-- MAIN APPLICATION
addappid(513860)
-- Game: addappid(513860)

-- MAIN APP DEPOTS / PACKAGES
addappid(513861, 1, "a9f809d864a88c18083ce833c7388da7700e11c60534638e7f466189e1b1b13f")
