-- Lua provided by SkyAPI 
-- Game: Shadow of Azrael
addappid(1527460)
addappid(1527461, 1, "8ae05b9d62222df4525e6713b233d10c72270da46307bea351ac8e1617d53a61")
