-- Lua provided by RyzenAPI
-- Game: Shadow of Azrael

-- MAIN APPLICATION
addappid(1527460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527461, 1, "8ae05b9d62222df4525e6713b233d10c72270da46307bea351ac8e1617d53a61")
