-- Lua provided by RyzenAPI 
-- Game: Town Market Simulator 2025
addappid(3470980)
addappid(3470981, 1, "776e081a961dc8ce72086a0963e46d370fe618f6050dfbe437d34d2720b8afb6")
