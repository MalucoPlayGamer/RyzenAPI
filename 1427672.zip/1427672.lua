-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1427672)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427672,0,"e24b6e17f64410ae15f2dd208ca32772efdece2b28e375c0b2d4d4bfb33f2692")
addtoken(1427672,5168607812412684674)
