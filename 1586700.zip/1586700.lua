-- Lua provided by RyzenAPI
-- Game: addappid(1586700)

-- MAIN APPLICATION
addappid(1586700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586701, 1, "284ad4ac85538aae65942e64311e54d9619326d3c2c4cf420e8b5ebe20616cbc")
