-- Lua provided by RyzenAPI
-- Game: Kitten Hero

-- MAIN APPLICATION
addappid(1813440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813443,0,"4f59820d2097201fe295251f58fb06f38ad702e482d1bf8aa934c0b576958263")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
