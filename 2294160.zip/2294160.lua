-- Lua provided by RyzenAPI
-- Game: 2294160

-- MAIN APPLICATION
addappid(2294160)
-- Game: addappid(2294160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294161, 1, "edaf25a250bf5da006b091975dbdba5572393fd8fe1386fcb471d633828bdcfc")
