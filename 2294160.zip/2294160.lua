-- Lua provided by SkyAPI 
-- Game: Isle of Swaps
addappid(2294160)
addappid(2294161, 1, "edaf25a250bf5da006b091975dbdba5572393fd8fe1386fcb471d633828bdcfc")
