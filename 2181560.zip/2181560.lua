-- Lua provided by RyzenAPI 
-- Game: UniFont Writer
addappid(2181560)
addappid(2181561, 1, "d326b8ab5b3c84809356f34bb1bd086c2f6e0cdd60ebf24d5d407ada89fc4c85")
