-- Lua provided by RyzenAPI
-- Game: UniFont Writer

-- MAIN APPLICATION
addappid(2181560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2181561, 1, "d326b8ab5b3c84809356f34bb1bd086c2f6e0cdd60ebf24d5d407ada89fc4c85")

