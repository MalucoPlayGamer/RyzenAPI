-- Lua provided by RyzenAPI
-- Game: 2181560

-- MAIN APPLICATION
addappid(2181560)
-- Game: addappid(2181560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181561, 1, "d326b8ab5b3c84809356f34bb1bd086c2f6e0cdd60ebf24d5d407ada89fc4c85")
