-- Lua provided by RyzenAPI
-- Game: Game: AppID 3198170

-- MAIN APPLICATION
addappid(3198170)
-- Game: addappid(3198170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198171, 1, "01d1573fb22ae618283fa8bab7740dfc9ac299c197d1c8111e2d5568919205b7")
