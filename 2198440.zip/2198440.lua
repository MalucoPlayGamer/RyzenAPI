-- Lua provided by RyzenAPI
-- Game: Game: Krimson Demo

-- MAIN APPLICATION
addappid(2198440)
-- Game: addappid(2198440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198441, 1, "3937c3b1d4c5588b85b90181569ad1f4d4e5b18a766c988f226c2f2bc7134718")
