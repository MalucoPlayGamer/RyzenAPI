-- Lua provided by RyzenAPI
-- Game: Game: AppID 723940

-- MAIN APPLICATION
addappid(723940)
-- Game: addappid(723940)

-- MAIN APP DEPOTS / PACKAGES
addappid(723941, 1, "9d4b1213b451c57f249ca85f21b979b92fa93ea3d3ccf2b266da0b0e6de8350f")
