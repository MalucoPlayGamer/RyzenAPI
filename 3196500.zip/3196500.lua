-- Lua provided by RyzenAPI
-- Game: Wayblazer Dämmerung

-- MAIN APPLICATION
addappid(3196500)
addappid(4229510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3196502,0,"2f7b8bb0953297908c514e6501621b990cf4684fec5022dde0a2a944396b3370")
addappid(4229511,0,"5348a57482619df0dee805904a048b77efc025dbd73cda233ff067393663736a")

