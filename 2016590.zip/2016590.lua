-- Lua provided by RyzenAPI
-- Game: Dark and Darker

-- MAIN APPLICATION
addappid(2016590)
addappid(3211120)
addappid(3622300)
addappid(3996400)
addappid(4317300)
addappid(4599020)
addappid(4863550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2016591, 1, "317a5c70883ad23bbef6b5944503332e3bc3af8049ae6fb372da6a9e3ce63931")

