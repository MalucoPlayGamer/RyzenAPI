-- Lua provided by RyzenAPI
-- Game: Game: Dark and Darker

-- MAIN APPLICATION
addappid(2016590)
-- Game: addappid(2016590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016591, 1, "317a5c70883ad23bbef6b5944503332e3bc3af8049ae6fb372da6a9e3ce63931")
