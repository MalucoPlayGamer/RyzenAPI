-- Lua provided by RyzenAPI
-- Game: addappid(2654350)

-- MAIN APPLICATION
addappid(2654350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654351, 1, "8bdebf96c5b753b1500b32c08162fb915c5ebac8321d29d4cb72132be715f56d")
