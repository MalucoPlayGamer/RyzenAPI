-- Lua provided by RyzenAPI 
-- Game: Signal
addappid(2594940)
addappid(2594941, 1, "ef49471e22a3a38134bdf0b58eebe0ceab226ad2464db2491eb5c8462f7a6bb9")
