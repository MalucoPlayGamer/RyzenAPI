-- Lua provided by RyzenAPI
-- Game: addappid(2594940)

-- MAIN APPLICATION
addappid(2594940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594941, 1, "ef49471e22a3a38134bdf0b58eebe0ceab226ad2464db2491eb5c8462f7a6bb9")
