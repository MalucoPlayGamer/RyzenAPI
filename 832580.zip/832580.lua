-- Lua provided by RyzenAPI
-- Game: 832580

-- MAIN APPLICATION
addappid(832580)
-- Game: addappid(832580)

-- MAIN APP DEPOTS / PACKAGES
addappid(832580,0,"60b71172c983800eb49c245c58494f9c09b00a128b5c9254c16c2c1a84dd1bf5")
