-- Lua provided by RyzenAPI
-- Game: AI Image Generator

-- MAIN APPLICATION
addappid(2240000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240001, 1, "226bb43d68115b81e4b4153d445688fd1b0fe83dc7f4034bb001188796a033cf")
