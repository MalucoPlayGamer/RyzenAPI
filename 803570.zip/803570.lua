-- Lua provided by RyzenAPI
-- Game: 803570

-- MAIN APPLICATION
addappid(803570)
-- Game: addappid(803570)

-- MAIN APP DEPOTS / PACKAGES
addappid(803571, 1, "1509ec9b8c04aede86d4b5f42015421fc3c178c0f81980496b9e8131be7db5f0")
