-- Lua provided by RyzenAPI
-- Game: Last Pirates: Die Together

-- MAIN APPLICATION
addappid(4317790) -- Last Pirates: Die Together

-- MAIN APP DEPOTS / PACKAGES
addappid(4317791, 1, "3d1c1770af5234972a92eb34df6e9b32b6d44f45ae02e1fdce4760f843c2206d") -- Depot 4317791

