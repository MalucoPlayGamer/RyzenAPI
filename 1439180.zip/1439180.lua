-- Lua provided by RyzenAPI
-- Game: Game: AppID 1439180

-- MAIN APPLICATION
addappid(1439180)
-- Game: addappid(1439180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439181, 1, "ae46b74860e81e25fbccfa42ae23db1add735b4b6eba8d5a50cbc8223cbfea36")
