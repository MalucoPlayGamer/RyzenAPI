-- Lua provided by RyzenAPI
-- Game: Game: Raw Nerve

-- MAIN APPLICATION
addappid(2386850)
-- Game: addappid(2386850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386851, 1, "a2d2089a1bf526c87a813d71d9212e71e76e3509e87e09d919072ff0cff35a1e")
addappid(2386859, 1, "1db3b5e3cd02984e827028128c5bdb2647ff36516212dac5f496b04bda4e2d30")
