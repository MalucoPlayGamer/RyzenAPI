-- Lua provided by RyzenAPI
-- Game: Airport Firefighters - The Simulation

-- MAIN APPLICATION
addappid(350530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(350531, 1, "5c1ca5ace31b214acb054cff1d8b8191fb1b471322bdfccee5f31ae22d1a1679")

