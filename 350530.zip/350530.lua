-- Lua provided by RyzenAPI
-- Game: Airport Firefighters - The Simulation

-- MAIN APPLICATION
addappid(350530)

-- MAIN APP DEPOTS / PACKAGES
addappid(350531, 1, "5c1ca5ace31b214acb054cff1d8b8191fb1b471322bdfccee5f31ae22d1a1679")

