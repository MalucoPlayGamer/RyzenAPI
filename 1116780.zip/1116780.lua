-- Lua provided by RyzenAPI
-- Game: Shovel Knight: King of Cards

-- MAIN APPLICATION
addappid(1116780)
-- Game: addappid(1116780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116781, 1, "936ca04a0b74963547ec7893e58fcab8d94dcf5def1c240a09b62da33809c54e")
