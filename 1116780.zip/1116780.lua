-- Lua provided by RyzenAPI
-- Game: Shovel Knight: King of Cards

-- MAIN APPLICATION
addappid(1116780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116781, 1, "936ca04a0b74963547ec7893e58fcab8d94dcf5def1c240a09b62da33809c54e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
