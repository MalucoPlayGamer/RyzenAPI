-- Lua provided by RyzenAPI
-- Game: Game: AppID 3224000

-- MAIN APPLICATION
addappid(3224000)
-- Game: addappid(3224000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224001, 1, "5d56a31996742910acef5ce4e13869ec6ebe93f5558d110b035756d759e9c086")
