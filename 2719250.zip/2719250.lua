-- Lua provided by RyzenAPI
-- Game: Curse Errant

-- MAIN APPLICATION
addappid(2719250)
-- Game: addappid(2719250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719251, 1, "6dc66e049f626a7bcb75c14f5351eda805f53c076592ee4a6c16cee568af4a79")
addappid(2719252, 1, "d35617af5df77635aa4fd343d040e274e4847c0fba1976b28fd22e4501e6973b")
