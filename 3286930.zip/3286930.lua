-- Lua provided by RyzenAPI
-- Game: Heretic + Hexen

-- MAIN APPLICATION
addappid(3286930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286931, 1, "9b93d7f5baf46df2860922615af3bd0cc1c32dabd3e3adb53df73cfc425f3eb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
