-- Lua provided by SkyAPI 
-- Game: Merry Fishing Meow
addappid(3751930)
addappid(3751931, 1, "035806b5835ac1eba0d801a58e296c16b564404ca954faa36327a0c86f7ce303")
