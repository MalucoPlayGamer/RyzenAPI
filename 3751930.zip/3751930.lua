-- Lua provided by RyzenAPI
-- Game: Merry Fishing Meow

-- MAIN APPLICATION
addappid(3751930)
-- Game: addappid(3751930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751931, 1, "035806b5835ac1eba0d801a58e296c16b564404ca954faa36327a0c86f7ce303")
