-- Lua provided by RyzenAPI
-- Game: Merry Fishing Meow

-- MAIN APPLICATION
addappid(3751930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3751931, 1, "035806b5835ac1eba0d801a58e296c16b564404ca954faa36327a0c86f7ce303")

