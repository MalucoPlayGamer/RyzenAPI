-- Lua provided by RyzenAPI
-- Game: 3372130

-- MAIN APPLICATION
addappid(3372130)
-- Game: addappid(3372130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372131, 1, "14df2779bdb9ed6804f47fa63898a2cc82f6a68782411e2095edf8ba8cd48592")
