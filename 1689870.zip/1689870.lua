-- Lua provided by RyzenAPI
-- Game: Meridian 157: Chapter 3

-- MAIN APPLICATION
addappid(1689870)
-- Game: addappid(1689870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689871, 1, "9421a5da95ed04715a38e36322b516f22c8e49b8759140e48742834b37194219")
