-- Lua provided by RyzenAPI
-- Game: Sinsations

-- MAIN APPLICATION
addappid(1738420)
addappid(2155790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738421, 1, "462a50d6cb76dce9079dcefcba25409816083784eed68793ce2fecb95d35ce95")

