-- Lua provided by SkyAPI 
-- Game: AppID 2709240
addappid(2709240)
addappid(2709241, 1, "488e7e751b875831d6e850d4a2392123d5df7eb16081e5a18698020a24996080")
