-- Lua provided by RyzenAPI
-- Game: Game: Sex Coach: Hot Yoga

-- MAIN APPLICATION
addappid(2432670)
-- Game: addappid(2432670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432671, 1, "e1b4062cf8d935edda8730c6cae64a6ea81cea5c0be34436d84789de60799230")
