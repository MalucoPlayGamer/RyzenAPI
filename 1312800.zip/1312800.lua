-- Lua provided by SkyAPI 
-- Game: EVERSPACE™ 2 Demo
addappid(1312800)
addappid(1312801, 1, "87e04779c81265c17a6ebe80b3e5f959dba97cf7a4eb318bb0f84af28de4d3c6")
