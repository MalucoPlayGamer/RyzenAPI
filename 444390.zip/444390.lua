-- Lua provided by RyzenAPI
-- Game: addappid(444390)

-- MAIN APPLICATION
addappid(444390)

-- MAIN APP DEPOTS / PACKAGES
addappid(355242,0,"8dbe98779d4fa903846d7ec8e76753f246840cb95fb0dec165f2a472ba87893a")
