-- Lua provided by RyzenAPI
-- Game: addappid(1038300)

-- MAIN APPLICATION
addappid(1038300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038301, 1, "f5d4eeb236ac66a76dd64496eea4454bab770ead1012b61340ebda93b53c0ee5")
