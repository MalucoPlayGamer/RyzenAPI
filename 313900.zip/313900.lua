-- Lua provided by RyzenAPI 
-- Game: AppID 313900
addappid(313900)
addappid(313901, 1, "4edfb6c18168304e1b25f6ad96eec0e2b6cee2b4631b64335cbe52043bee736b")
addappid(313902, 1, "e15c527b97933a7c4322af1765e1ab3820d4309fdf942cc57f8b52ce8e64eb20")
addappid(313903, 1, "a7f90010f52a3af6e95bd68a1178e47abc99e51f2170c89a2f6bbbdeff4d8047")
