-- Lua provided by RyzenAPI
-- Game: addappid(2746720)

-- MAIN APPLICATION
addappid(2746720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746720,0,"65fd718582834496b38250a2fa98d14bf55cda23ffaf3d18fcb38301eae41977")
