-- Lua provided by RyzenAPI
-- Game: AppID 1630340

-- MAIN APPLICATION
addappid(1630340)
-- Game: addappid(1630340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630341, 1, "6fbfe01ffcd654f301ec48e5a7de2225577df6210fd134f89f27a492b9185d47")
