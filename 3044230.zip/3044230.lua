-- Lua provided by RyzenAPI
-- Game: addappid(3044230)

-- MAIN APPLICATION
addappid(3044230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044231, 1, "eb21327d990738648c53deef23706710b9c666de102aba847af7aa36c18d7f3d")
