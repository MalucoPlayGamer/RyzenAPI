-- Lua provided by RyzenAPI
-- Game: Football, Tactics & Glory: Football Stars

-- MAIN APPLICATION
addappid(1293080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293080,0,"76855d18960ffdf8f90229b55dcd4bfd845ee9b3d53dba8cf6b1034d45550e60")

