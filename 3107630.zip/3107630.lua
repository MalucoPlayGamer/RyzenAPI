-- Lua provided by RyzenAPI
-- Game: 伯克利家的女仆：重制版（玛格丽特） Playtest

-- MAIN APPLICATION
addappid(3107630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107631, 1, "f2a3f620c0ba7aac4b5183ed9d7a8065f011ab859e360f760f5776019b23b283")
