-- Lua provided by RyzenAPI
-- Game: W4RR-i/o-RS

-- MAIN APPLICATION
addappid(752780)

-- MAIN APP DEPOTS / PACKAGES
addappid(752781, 1, "7e759085beb091f029cf5d219d4dadd407910f22a2ac6706de564117b0637af8")

