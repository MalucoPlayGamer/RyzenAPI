-- Lua provided by RyzenAPI
-- Game: 山海长歌

-- MAIN APPLICATION
addappid(2113990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2113991, 1, "23a15dd5e8d10daf26e1fdcd28c5eda85fd406afaa400b6ab2c63e6a88d05287")

