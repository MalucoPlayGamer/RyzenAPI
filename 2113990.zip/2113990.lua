-- Lua provided by RyzenAPI
-- Game: Game: 山海长歌

-- MAIN APPLICATION
addappid(2113990)
-- Game: addappid(2113990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113991, 1, "23a15dd5e8d10daf26e1fdcd28c5eda85fd406afaa400b6ab2c63e6a88d05287")
