-- Lua provided by RyzenAPI
-- Game: Viy: Retold Story

-- MAIN APPLICATION
addappid(1828910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828911, 1, "858e9009ddecbe8ea0c993762b8730dcd4e282587be29679d51a4749de253bb5")
