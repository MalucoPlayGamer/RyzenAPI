-- Lua provided by RyzenAPI
-- Game: Asteroidiga

-- MAIN APPLICATION
addappid(772110)

-- MAIN APP DEPOTS / PACKAGES
addappid(772111, 1, "b22f448abc4896ced3d387b2a0e6b2772850ed537152f0c009758f06b9d22bb3")

