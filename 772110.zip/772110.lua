-- Lua provided by RyzenAPI
-- Game: Asteroidiga

-- MAIN APPLICATION
addappid(772110)

-- MAIN APP DEPOTS / PACKAGES
addappid(772111, 1, "b22f448abc4896ced3d387b2a0e6b2772850ed537152f0c009758f06b9d22bb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
