-- Lua provided by RyzenAPI
-- Game: Monkey Split

-- MAIN APPLICATION
addappid(1480930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1480931, 1, "67e5851c65818fff921d2e1848a8d454e70654b0dcd99f782f96f886f3f98612")

