-- Lua provided by RyzenAPI
-- Game: Monkey Split

-- MAIN APPLICATION
addappid(1480930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480931, 1, "67e5851c65818fff921d2e1848a8d454e70654b0dcd99f782f96f886f3f98612")

