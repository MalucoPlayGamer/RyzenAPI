-- Lua provided by RyzenAPI
-- Game: addappid(3143980)

-- MAIN APPLICATION
addappid(3143980)
addappid(4270620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143981, 1, "357508c8f7bb7d6de027936e80b7ab841a92d4c51e1133864ed8679ffd320431")
