-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost in Italy Find & Color

-- MAIN APPLICATION
addappid(3809600)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4045650)
