-- Lua provided by RyzenAPI
-- Game: Chaser

-- MAIN APPLICATION
addappid(39670)

-- MAIN APP DEPOTS / PACKAGES
addappid(39671, 1, "35675e62746d6bc4c3bb68d33b210609b98a9d33eea81b6279ffc506a0efd976")
addappid(39671, 1, "35675e62746d6bc4c3bb68d33b210609b98a9d33eea81b6279ffc506a0efd976") -- Main
addappid(39672, 1, "2cc1c6ee1cd026bd74f862e24c20ffaa8a25f85ae123283d232d66b43a2c121e")
addappid(39672, 1, "2cc1c6ee1cd026bd74f862e24c20ffaa8a25f85ae123283d232d66b43a2c121e") -- Chaser French
addappid(39673, 1, "8131d432f977a6bda38a3c4faec6b3e1c543b82c3407dfbbd49ae151492e1bd1")
addappid(39673, 1, "8131d432f977a6bda38a3c4faec6b3e1c543b82c3407dfbbd49ae151492e1bd1") -- Chaser German
addappid(39674, 1, "5041f3cf7bd2fe6c5e1face1ccca6a374dd630c97f352728fab1936e08bc4061")
addappid(39674, 1, "5041f3cf7bd2fe6c5e1face1ccca6a374dd630c97f352728fab1936e08bc4061") -- Chaser Spanish
addappid(39675, 1, "1f0904d86c441d92c6760de2bef2099157eb07e31721a8adc192e14ae3faf3d0")
addappid(39675, 1, "1f0904d86c441d92c6760de2bef2099157eb07e31721a8adc192e14ae3faf3d0") -- Chaser Russian
addappid(39676, 1, "5ffefa10f53bd3a6b0f90050900f1450a1ccf3ed7d34aecfd9c586b827ee5b2f")
addappid(39676, 1, "5ffefa10f53bd3a6b0f90050900f1450a1ccf3ed7d34aecfd9c586b827ee5b2f") -- Chaser Japanese
addappid(39677, 1, "1cb394e87ecb6d0d8a71fc9d329c9527ed0ef98260a14e2978c1fbd9b35e4220")
addappid(39677, 1, "1cb394e87ecb6d0d8a71fc9d329c9527ed0ef98260a14e2978c1fbd9b35e4220") -- Chaser Hungarian

