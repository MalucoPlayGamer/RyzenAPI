-- Lua provided by RyzenAPI
-- Game: 悪魔の家 -6 Day Nightmare-

-- MAIN APPLICATION
addappid(2641630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641631, 1, "51bd23c8338714c1b11b6bf1469ab25dba3d258b4739b34395e9c08b539ff35a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
