-- Lua provided by RyzenAPI
-- Game: 2641630

-- MAIN APPLICATION
addappid(2641630)
-- Game: addappid(2641630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641631, 1, "51bd23c8338714c1b11b6bf1469ab25dba3d258b4739b34395e9c08b539ff35a")
