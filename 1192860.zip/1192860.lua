-- Lua provided by RyzenAPI
-- Game: Winter Snow | 冬雪

-- MAIN APPLICATION
addappid(1192860)
-- Game: addappid(1192860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192861, 1, "ed146fbbba8483d7e09eaac09be09f5d757df4f7125a3c14d3c4e03e1d8e2a70")
addappid(1192862, 1, "b726bb45a8bf067851c1e5d728febca67fd151ea181618ceadbd203f74652209")
addappid(1213270, 0, "6a18be56003bc32d76ee9c9d72fbd074252d4fd6413b2c66c74584f9a00fb99d")
