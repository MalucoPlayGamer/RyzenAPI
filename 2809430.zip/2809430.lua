-- Lua provided by RyzenAPI
-- Game: Serbian Dancing Lady

-- MAIN APPLICATION
addappid(2809430)
-- Game: addappid(2809430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809431, 1, "3d4d63bc8d854d21b1a04f301638cf23e8cdb92b477f3d722030807b9a706758")
