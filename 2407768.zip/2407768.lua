-- Lua provided by RyzenAPI
-- Game: Beat Saber - Queen - Stone Cold Crazy

-- MAIN APPLICATION
addappid(2407768)
-- Game: addappid(2407768)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407768,0,"02e0ddbdc8b67c03cf321a9d620d4e29d6e614ac1fd1a026674cff066cb05a0f")
