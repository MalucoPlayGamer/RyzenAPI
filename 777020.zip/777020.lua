-- Lua provided by RyzenAPI
-- Game: Mumps

-- MAIN APPLICATION
addappid(777020)

-- MAIN APP DEPOTS / PACKAGES
addappid(777021, 1, "e725ea992715ead7fac35ed295a6df76ffb3016ccf0e590a66648d380422f4d7")

