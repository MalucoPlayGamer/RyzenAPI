-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 14

-- MAIN APPLICATION
addappid(3195640)
-- Game: addappid(3195640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195640,0,"c253ad9d6c0b3e6b262cecef9a233917c33ce8ff6cb0ad1f23794268973bb6ce")
