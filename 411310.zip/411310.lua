-- Lua provided by RyzenAPI
-- Game: Game: AppID 411310

-- MAIN APPLICATION
addappid(411310)
-- Game: addappid(411310)

-- MAIN APP DEPOTS / PACKAGES
addappid(411311, 1, "b341a20ccbf522ead41cd3b8ef447fa9750f8441facda966a83cb592cecba51d")
addappid(411312, 1, "87d05f8dce33be69eb11b5db6b7907cc9580b2ed21673464fc5428729d85c59b")
addappid(411313, 1, "9afa9b41e8ee13f57feb9eaf1bc2407755368c124e0545ef6bade2984d47c6fb")
addappid(411314, 1, "481eb010fb005df049ebf9b56ecaf342f193a5df4109005ff8d9f2b0c6a86475")
addappid(411315, 1, "b78f11c6f36c23af3f583c146d4e5e971e3ca00991ff7ead15098eafffa16f03")
addappid(411316, 1, "0d6d263a8a03ceb8d68840439411f6dab4294bb4b631c3b76007c9b670e281ee")
addappid(411317, 1, "60bc23f9fc26f6c02eaf06e1377f66afbdc02dfd91dfa625e11aed43e6d2fda4")
addappid(411318, 1, "eaed18ed9311a1638c90891adfe1ece43d118e2b0e3c4ba3b74b0afbc21329d1")
addappid(411319, 1, "4ac087451ab1712be69fe9621cf83aaa03a59472e9054ddc80b1eb058a57d9a3")
addappid(431070, 0, "1c28624b2c42afdb1b7ded53b8ad7c2d61308a099a91f9d4af61d968c416b720")
