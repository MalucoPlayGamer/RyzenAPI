-- Lua provided by RyzenAPI
-- Game: Game: Desktop Farm

-- MAIN APPLICATION
addappid(1357610)
addappid(2957220)
-- Game: addappid(1357610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357611, 1, "ec605718d8fdbc46816c4aab6cd3907e16d1f48fc4e610915c945a889806d8e1")
