-- Lua provided by RyzenAPI
-- Game: Angry Video Game Nerd Adventures

-- MAIN APPLICATION
addappid(237740)

-- MAIN APP DEPOTS / PACKAGES
addappid(237741, 1, "9b664a623e71d07b993b393c87228fb336082e8b672782b7c71a7d1813b94aaa")

