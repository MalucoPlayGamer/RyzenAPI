-- Lua provided by RyzenAPI
-- Game: Angry Video Game Nerd Adventures

-- MAIN APPLICATION
addappid(237740)

-- MAIN APP DEPOTS / PACKAGES
addappid(237741, 1, "9b664a623e71d07b993b393c87228fb336082e8b672782b7c71a7d1813b94aaa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
