-- Lua provided by RyzenAPI
-- Game: Hitler Hates Anime

-- MAIN APPLICATION
addappid(1684720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684721, 1, "fddf8edfcacaf839ecb64e0f54967dd966ddceab2d5e3d5632dcaa7e34351876")
