-- Lua provided by RyzenAPI
-- Game: Millennium Runners

-- MAIN APPLICATION
addappid(3582420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3582421, 1, "784d238b6a31904b5df11d0915516b3159e443b0c2fda6562abcccc397dc29ce")

