-- Lua provided by SkyAPI 
-- Game: Millennium Runners
addappid(3582420)
addappid(3582421, 1, "784d238b6a31904b5df11d0915516b3159e443b0c2fda6562abcccc397dc29ce")
