-- Lua provided by RyzenAPI
-- Game: Through The Dark: Prologue

-- MAIN APPLICATION
addappid(635270)

-- MAIN APP DEPOTS / PACKAGES
addappid(635271, 1, "42b8feb866f11179ceb15b9b3321cb7017a4028ccdc70fe4697163fd66bcbf67")
