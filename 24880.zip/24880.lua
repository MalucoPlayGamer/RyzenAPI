-- Lua provided by RyzenAPI
-- Game: The Saboteur

-- MAIN APPLICATION
addappid(24880)
addappid(228981)
addappid(228985)
addappid(228990)
addappid(229000)

-- MAIN APP DEPOTS / PACKAGES
addappid(24881, 1, "60558a538e6c5ee02a37e67572373ff7cc47b5b44e5f53a3873c58b31c5e94cf")
addappid(24882, 1, "f123a11e1cc31612e3776c56e8576be770c6869a59c78ad357f3bb27b715125d")
addappid(24883, 1, "024f206649bd391d709321dde068d1520ae09ada7a519a62ccccda2a36421754")
addappid(24884, 1, "188be6951219cf6edf2cb1567ccae3eab16199fce7b3ea9766bb29473aeb1950")
addappid(24885, 1, "35b52f449838c6ceac5875af84ebcb1aeb456a3318f54092487bc9d2e71ad26f")
addappid(24886, 1, "4b01ec3c9478d96fad66963f082d92b016d3f1ce6250ca5fd49d381be07fc89b")
