-- Lua provided by RyzenAPI
-- Game: Notice me, Leena-senpai!

-- MAIN APPLICATION
addappid(1988530)
addappid(2806650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988531, 1, "1f319938d14914cc8858ab1715db9bb35bbda17d7edb6d0138b454f22f4153b0")
