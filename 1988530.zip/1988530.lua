-- Lua provided by RyzenAPI 
-- Game: AppID 1988530
addappid(1988530)
addappid(1988531, 1, "1f319938d14914cc8858ab1715db9bb35bbda17d7edb6d0138b454f22f4153b0")
