-- Lua provided by RyzenAPI
-- Game: Grey Scout

-- MAIN APPLICATION
addappid(1442390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442391, 1, "5a9bbe3472ee552646800eace35db5058371396a57634433f01b6dfabf5cdeed")

