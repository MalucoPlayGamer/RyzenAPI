-- Lua provided by RyzenAPI
-- Game: Hamster Bomba

-- MAIN APPLICATION
addappid(3101350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101351,0,"7e6a4189546b3077ad48a0ca0ad85cc8b7f7fdffab6e4dfb2bfa4a94b5246f62")
