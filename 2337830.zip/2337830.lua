-- Lua provided by RyzenAPI
-- Game: The Crush House Demo

-- MAIN APPLICATION
addappid(2337830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337831, 1, "98a274c2fbe3110fa65d1720a7f6d5369f9aa79142242a61c16ab83f246c981c")

