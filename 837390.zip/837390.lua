-- Lua provided by RyzenAPI
-- Game: 837390

-- MAIN APPLICATION
addappid(837390)
-- Game: addappid(837390)

-- MAIN APP DEPOTS / PACKAGES
addappid(837391, 1, "212b25c0ce1ebe589d8b086ca10fee269e3910ff9dc69675e8f93115703c2f97")
