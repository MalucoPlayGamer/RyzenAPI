-- Lua provided by RyzenAPI
-- Game: eXceed - Gun Bullet Children

-- MAIN APPLICATION
addappid(207370)
-- Game: addappid(207370)

-- MAIN APP DEPOTS / PACKAGES
addappid(207371, 1, "5c877c5addadabf9d5654be8ef2f803e26f044bbe6b0ed1e30fe6fd1acb94631")
addappid(334510, 0, "f8f8ce3661da00ecfbccf0c9d1a5c2743bdd2cb9f373d9121bddde972b143324")
