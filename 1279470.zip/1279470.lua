-- Lua provided by RyzenAPI
-- Game: Game: AppID 1279470

-- MAIN APPLICATION
addappid(1279470)
-- Game: addappid(1279470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279471, 1, "94a9d2b71ba854bbe392beb18086b8c1a3eeba47001f8cd409a431ee0470c11f")
