-- Lua provided by SkyAPI 
-- Game: AppID 1058980
addappid(1058980)
addappid(1058981, 1, "292e98d1464074e77ca9e916c9318ada2b971dbc09979b7bd4bece256c6d1d7d")
