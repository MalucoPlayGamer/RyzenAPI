-- Lua provided by RyzenAPI
-- Game: 1058980

-- MAIN APPLICATION
addappid(1058980)
-- Game: addappid(1058980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058981, 1, "292e98d1464074e77ca9e916c9318ada2b971dbc09979b7bd4bece256c6d1d7d")
