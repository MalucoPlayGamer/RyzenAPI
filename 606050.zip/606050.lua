-- Lua provided by RyzenAPI
-- Game: Gump Runner

-- MAIN APPLICATION
addappid(606050)

-- MAIN APP DEPOTS / PACKAGES
addappid(606051, 1, "783b6baaefa7c835b56cd4ce505748dfc54324866018bfce1ec988f83f4d744e")

