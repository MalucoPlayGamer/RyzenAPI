-- Lua provided by RyzenAPI
-- Game: Lovely Heroines

-- MAIN APPLICATION
addappid(1170290)
addappid(1175010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170291, 1, "a0a55dcbce6294d67d71c9b9566ffb9db04bb66dd68a611002b73ad19092454d")

