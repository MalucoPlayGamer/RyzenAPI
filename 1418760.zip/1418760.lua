-- Lua provided by RyzenAPI
-- Game: 1418760

-- MAIN APPLICATION
addappid(1418760)
-- Game: addappid(1418760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418761, 1, "08b33bb0a2e65279fce5067a732b5a640de9fda271f645e65e7009562448ebfc")
