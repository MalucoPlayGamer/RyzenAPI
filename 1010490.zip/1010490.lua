-- Lua provided by RyzenAPI
-- Game: 1010490

-- MAIN APPLICATION
addappid(1010490)
addappid(1022590)
-- Game: addappid(1010490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010491, 1, "7db2c68b6575a1e06fbd146c933a3b7709342e5045e4d76a8b1244bff9f9d083")
