-- Lua provided by RyzenAPI
-- Game: 2865360

-- MAIN APPLICATION
addappid(2865360)
-- Game: addappid(2865360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865361, 1, "000293b1b020de83de23d4b48d30a20c518b3bbac3ba2e62ca48fc1295f85fbb")
