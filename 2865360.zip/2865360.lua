-- Lua provided by RyzenAPI
-- Game: Inline: Out of Time

-- MAIN APPLICATION
addappid(2865360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2865361, 1, "000293b1b020de83de23d4b48d30a20c518b3bbac3ba2e62ca48fc1295f85fbb")

