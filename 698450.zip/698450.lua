-- Lua provided by RyzenAPI
-- Game: Midnight Quest

-- MAIN APPLICATION
addappid(698450)

-- MAIN APP DEPOTS / PACKAGES
addappid(698451,0,"3fff421b907ffab6794c27fba110615557c40ae1e34e68baba5d67035107175a")

