-- Lua provided by RyzenAPI
-- Game: AppID 756450

-- MAIN APPLICATION
addappid(756450)
-- Game: addappid(756450)

-- MAIN APP DEPOTS / PACKAGES
addappid(756451, 1, "3f17729b36fb1c604919ffb028bf4e2fbbb00e942f80406d547b6d11162130a5")
