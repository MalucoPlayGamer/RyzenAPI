-- Lua provided by RyzenAPI
-- Game: Ara History Untold: Anniversary Edition

-- MAIN APPLICATION
addappid(2021880)
addappid(3143380)
addappid(3143390)
addappid(3143400)
addappid(3143410)
addappid(3143420)
addappid(3143430)
addappid(3158790)
addappid(3495280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2021881, 1, "2ee32023245e16a98b624134e65f2cb58176b2ec23c8cccf202cc305d57d864e")
addappid(3144830, 0, "46ec9fab404dcd3a5e0b2862b1f9c1a0410157b5071f35a086bd4f57f6b79beb")

