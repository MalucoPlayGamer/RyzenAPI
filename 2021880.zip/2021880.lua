-- Lua provided by RyzenAPI
-- Game: addappid(2021880)

-- MAIN APPLICATION
addappid(2021880)
addappid(3143380)
addappid(3143390)
addappid(3143400)
addappid(3143410)
addappid(3143420)
addappid(3143430)
addappid(3158790)
addappid(3495280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021881, 1, "2ee32023245e16a98b624134e65f2cb58176b2ec23c8cccf202cc305d57d864e")
addappid(3144830, 0, "46ec9fab404dcd3a5e0b2862b1f9c1a0410157b5071f35a086bd4f57f6b79beb")
