-- Lua provided by RyzenAPI
-- Game: Rude Racers: 2D Combat Racing

-- MAIN APPLICATION
addappid(1099440)
addappid(1169120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099441, 1, "2247ff5f9292786ab91a6d195050da7eaa22c85f76e55b363326fbe3d57ebaea")
addappid(1169121, 1, "13ec0ae4e7f0984bcf242692294e805c44ef59b5b9450aa08aae7017a6a18114")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
