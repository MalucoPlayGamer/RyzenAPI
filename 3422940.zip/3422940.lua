-- Lua provided by RyzenAPI
-- Game: addappid(3422940)

-- MAIN APPLICATION
addappid(3422940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422941, 1, "645aa87430073713d1ebaf7a044aafc9154af91c4495ccbdfea515db9e8263af")
