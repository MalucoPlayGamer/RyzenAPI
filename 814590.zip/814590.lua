-- Lua provided by RyzenAPI
-- Game: Caveman Stories

-- MAIN APPLICATION
addappid(814590)
-- Game: addappid(814590)

-- MAIN APP DEPOTS / PACKAGES
addappid(814591, 1, "70691c5b07b211a89ca264c3d734d2041368fa8005342ac18e8c27dcf34d49d0")
