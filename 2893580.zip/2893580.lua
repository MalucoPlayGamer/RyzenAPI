-- Lua provided by RyzenAPI
-- Game: Game: AI-VJ

-- MAIN APPLICATION
addappid(2893580)
-- Game: addappid(2893580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893581, 1, "a55642b002c49b50101eda917391963d4e2ed96f8c76073691c63ddb463862bc")
