-- Lua provided by SkyAPI 
-- Game: AI-VJ
addappid(2893580)
addappid(2893581, 1, "a55642b002c49b50101eda917391963d4e2ed96f8c76073691c63ddb463862bc")
