-- Lua provided by RyzenAPI
-- Game: 347690

-- MAIN APPLICATION
addappid(347690)
-- Game: addappid(347690)

-- MAIN APP DEPOTS / PACKAGES
addappid(347691, 1, "1d54312f3abc02ddf170d1b37dc010fba0b11477d97808abc6f42c4f3a66e4e9")
