-- Lua provided by RyzenAPI
-- Game: AppID 347690

-- MAIN APPLICATION
addappid(347690)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(347691, 1, "1d54312f3abc02ddf170d1b37dc010fba0b11477d97808abc6f42c4f3a66e4e9")

