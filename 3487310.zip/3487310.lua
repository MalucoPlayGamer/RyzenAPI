-- Lua provided by RyzenAPI
-- Game: addappid(3487310)

-- MAIN APPLICATION
addappid(3487310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487311, 1, "3443582fb063a46c6f5d12159c0e9dea841401549bf17e2ff2ebbcd104c3b786")
