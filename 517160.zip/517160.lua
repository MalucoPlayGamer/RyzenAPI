-- Lua provided by RyzenAPI
-- Game: addappid(517160)

-- MAIN APPLICATION
addappid(517160)

-- MAIN APP DEPOTS / PACKAGES
addappid(517161, 1, "b2c28238837e10b8090f19d16b4926f562feb8ebe42fbc3a2527bb74a63b92dd")
