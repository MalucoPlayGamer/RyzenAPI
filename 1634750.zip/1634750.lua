-- Lua provided by RyzenAPI
-- Game: Game: AppID 1634750

-- MAIN APPLICATION
addappid(1634750)
-- Game: addappid(1634750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634751, 1, "2c5bdac580fe49ac1ba92d521fbe30993cc99abf162cf79a7fbdea2422bd40d7")
