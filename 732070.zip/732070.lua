-- Lua provided by RyzenAPI
-- Game: Lost in the tomb

-- MAIN APPLICATION
addappid(732070)

-- MAIN APP DEPOTS / PACKAGES
addappid(732071, 1, "dac3c3105a8f993ad1cc5df100f64276d63f51bef05ebf7c910cff63c8c43008")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
