-- Lua provided by RyzenAPI
-- Game: Picayune Dreams

-- MAIN APPLICATION
addappid(2088840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2088841, 1, "d94248295f21c98beccd3492513b916ce1614a571d684ac7f904bfbd84d7900c")

