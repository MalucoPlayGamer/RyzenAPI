-- Lua provided by RyzenAPI
-- Game: addappid(2088840)

-- MAIN APPLICATION
addappid(2088840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088841, 1, "d94248295f21c98beccd3492513b916ce1614a571d684ac7f904bfbd84d7900c")
