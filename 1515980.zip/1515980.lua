-- Lua provided by RyzenAPI
-- Game: Kill Demons

-- MAIN APPLICATION
addappid(1515980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515981, 1, "21a17c7e0734fdffbd870fbe79dfafdc1c9569a07a2be8b283ec4f4ab788534c")

