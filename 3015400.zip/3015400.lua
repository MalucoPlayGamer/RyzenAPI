-- Lua provided by RyzenAPI
-- Game: Game: AppID 3015400

-- MAIN APPLICATION
addappid(3015400)
-- Game: addappid(3015400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015401, 1, "5b007486db2b5095ee614d20851c1b9e113a28e5037f1fa003e7554a82a21a64")
