-- Lua provided by RyzenAPI
-- Game: JumpHead: Battle4Fun!

-- MAIN APPLICATION
addappid(402080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(402081, 1, "469cc498b8883cab5b1f93c79bd808f3e9dc00b1bd128a7e9c0a25d25b2bb9c0")
addappid(402082, 1, "11cc11d9f78121eb52603f4e03b407d1ef698456bb044108a046220ce387a428")

