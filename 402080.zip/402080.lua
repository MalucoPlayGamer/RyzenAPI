-- Lua provided by SkyAPI 
-- Game: JumpHead: Battle4Fun!
addappid(402080)
addappid(402081, 1, "469cc498b8883cab5b1f93c79bd808f3e9dc00b1bd128a7e9c0a25d25b2bb9c0")
addappid(402082, 1, "11cc11d9f78121eb52603f4e03b407d1ef698456bb044108a046220ce387a428")
