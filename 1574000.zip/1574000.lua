-- Lua provided by RyzenAPI
-- Game: Industry Idle

-- MAIN APPLICATION
addappid(1574000)
