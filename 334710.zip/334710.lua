-- Lua provided by RyzenAPI
-- Game: addappid(334710)

-- MAIN APPLICATION
addappid(334710)

-- MAIN APP DEPOTS / PACKAGES
addappid(334711, 1, "aacc917b1d193a3d86c8a50fd18246baba1b59861414f9e08c435e711805f284")
