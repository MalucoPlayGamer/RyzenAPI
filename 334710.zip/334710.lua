-- Lua provided by RyzenAPI 
-- Game: Ilamentia
addappid(334710)
addappid(334711, 1, "aacc917b1d193a3d86c8a50fd18246baba1b59861414f9e08c435e711805f284")
