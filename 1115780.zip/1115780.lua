-- Lua provided by RyzenAPI
-- Game: 1115780

-- MAIN APPLICATION
addappid(1115780)
-- Game: addappid(1115780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115781, 1, "d48ece661d9803f46fca8078d34ce8f277c7b56f68054fade4905153e45e0dbd")
addappid(1115782, 1, "e1c69927703c0c8714e299ece365b4d449cc8b0353dab2f3299a0b1faf01261b")
