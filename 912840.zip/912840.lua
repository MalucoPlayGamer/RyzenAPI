-- Lua provided by RyzenAPI
-- Game: Game: AppID 912840

-- MAIN APPLICATION
addappid(912840)
-- Game: addappid(912840)

-- MAIN APP DEPOTS / PACKAGES
addappid(912841, 1, "2032eade4a0ba87fa3b0f801ac163d73ea1d21d3f3530b2c013abd0e845b8df4")
