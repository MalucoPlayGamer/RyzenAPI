-- Lua provided by RyzenAPI
-- Game: AppID 912840

-- MAIN APPLICATION
addappid(912840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(912841, 1, "2032eade4a0ba87fa3b0f801ac163d73ea1d21d3f3530b2c013abd0e845b8df4")

