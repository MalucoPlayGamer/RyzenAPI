-- Lua provided by RyzenAPI
-- Game: Cuties Monster Girl

-- MAIN APPLICATION
addappid(2861070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2861071,0,"c1983e087492cd5940845e43ff36230e560d09974c4be7e1bf8d5d1a00d80c5d")

