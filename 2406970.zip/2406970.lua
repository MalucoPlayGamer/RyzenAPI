-- Lua provided by RyzenAPI
-- Game: The doll

-- MAIN APPLICATION
addappid(2406970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406971, 1, "b521aef9e05141c5f85cda98c4cef22413c3a92f5f67963a32132257cc2c82cd")

