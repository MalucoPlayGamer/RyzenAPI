-- Lua provided by RyzenAPI
-- Game: Gunjack

-- MAIN APPLICATION
addappid(410570)
-- Game: addappid(410570)

-- MAIN APP DEPOTS / PACKAGES
addappid(410571, 1, "c3bad4d52eb48b5988f9f81f30da9d2ac4f19c01f10ad0d807aaaf714634a958")
