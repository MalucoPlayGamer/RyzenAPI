-- Lua provided by SkyAPI 
-- Game: Gunjack
addappid(410570)
addappid(410571, 1, "c3bad4d52eb48b5988f9f81f30da9d2ac4f19c01f10ad0d807aaaf714634a958")
