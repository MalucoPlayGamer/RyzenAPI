-- Lua provided by RyzenAPI
-- Game: Always The Same Blue Sky...

-- MAIN APPLICATION
addappid(363410)
addappid(382170)
-- Game: addappid(363410)

-- MAIN APP DEPOTS / PACKAGES
addappid(363411, 1, "9cbf7e8c6551d912f0d4706f965f36d09daaa314bfcb6b1baebf705a0b884fd2")
