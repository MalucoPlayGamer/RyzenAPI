-- Lua provided by RyzenAPI
-- Game: Spinny Dungeon

-- MAIN APPLICATION
addappid(2837790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837791,0,"0f7aa7be7af752d9274236c2e5c027b5a6a7c7e03b3c3d0bfb96e5272c3fa631")

