-- Lua provided by RyzenAPI
-- Game: Game: ToruTaru

-- MAIN APPLICATION
addappid(1650250)
-- Game: addappid(1650250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650251, 1, "f3cde8c44ee7aaba727698484ce284fea2a8104f2d2686862e172fc474c0e815")
addappid(1650252, 1, "e97cd17cb66396d7a8496714689e6cff13ad989fefb434c7d41d405afaf181ce")
