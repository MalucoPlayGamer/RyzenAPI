-- Lua provided by RyzenAPI
-- Game: 2009900

-- MAIN APPLICATION
addappid(2009900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009900,0,"40bbbbd4bcaf3be9c6246c22bbf13c55fac900f92cac7c6603289ed04081f65f")
