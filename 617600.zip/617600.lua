-- Lua provided by RyzenAPI
-- Game: AppID 617600

-- MAIN APPLICATION
addappid(617600)
-- Game: addappid(617600)

-- MAIN APP DEPOTS / PACKAGES
addappid(617601, 1, "1f05cea591001e7e76bb09eebfea1ca19b8c66272c512fc183ee930f7f99bbea")
