-- Lua provided by RyzenAPI
-- Game: Company of Heroes: Far East War

-- MAIN APPLICATION
addappid(547180)
addappid(4459060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(547181, 1, "a1db80eb3055bdfb725b46e1cb08960c008a3d4a86ea5142841c30d90772f82f")
addappid(547182, 1, "494a7ac961b27deff4e5cfdc944c82c646bf3fc58b0be9487496c8ab18e62f24")
addappid(547183, 1, "a671049ca31d9286cf57ed72e8f1726f3742cef4de5dd3c84d3c608ad2317b4d")
addappid(566390, 0, "f7039cb1019387cae5a4c4ab3bd0386008568f7067f5b8b5fcc4146b28238877")

