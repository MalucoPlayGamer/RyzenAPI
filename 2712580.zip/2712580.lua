-- Lua provided by RyzenAPI
-- Game: addappid(2712580)

-- MAIN APPLICATION
addappid(2712580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712582,0,"031981ecef7c0c9211198cec0eb974066a9c77ec6d35db0023f436694f3aba4b")
