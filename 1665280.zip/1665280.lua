-- Lua provided by RyzenAPI
-- Game: Skábma™ - Snowfall

-- MAIN APPLICATION
addappid(1665280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665281, 1, "492aa99f07713346985e109e7fd0da5ac3c4393efede71ddcfb24e3a2f00b443")
