-- Lua provided by RyzenAPI
-- Game: addappid(2429210)

-- MAIN APPLICATION
addappid(2429210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429211, 1, "f22c87a3609c7c93862b26258cacfdeb9ea049d3f1200a61067d88d009de9fd0")
