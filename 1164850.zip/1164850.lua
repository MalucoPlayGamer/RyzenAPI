-- Lua provided by RyzenAPI 
-- Game: Sinking Simulator
addappid(1164850)
addappid(1164851, 1, "1c55a77639f39ca14364ed9c66a42a37f425e50ca91722c6abeb559e41335812")
addappid(1164852, 1, "f5ff811020c11849a8d50da7760a8a866b59874f830e2569282559a4af080fbe")
addappid(1171190, 0, "e7cff60611bac07923da3d5f9adb2277cd84042cb7fefda4c73906c24ded8179")
