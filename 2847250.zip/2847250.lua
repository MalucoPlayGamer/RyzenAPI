-- Lua provided by RyzenAPI
-- Game: River Town Factory: Prologue

-- MAIN APPLICATION
addappid(2847250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2847251, 1, "c3a01eeb4f3ec03e7c5c9e1163da614b393df968eaeaf659837c3ba75a23fd62")

