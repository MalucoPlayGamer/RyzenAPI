-- Lua provided by RyzenAPI
-- Game: 2115940

-- MAIN APPLICATION
addappid(2115940)
-- Game: addappid(2115940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115942,0,"b25abec17b242fcbaa1ffe8b74199862019e2204421e75c49bfee2913b57616a")
addappid(2115943,0,"dcea2ae4f6e9e6783c8f0c020bca24fa73634b488d0c0eba49d44b12a2438843")
