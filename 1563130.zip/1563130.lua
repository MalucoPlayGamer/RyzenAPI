-- Lua provided by RyzenAPI
-- Game: SuperPower 3

-- MAIN APPLICATION
addappid(1563130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563131, 1, "699ff475cc4eba06592a2fa150847dafd45426707a86f6ca8c32044053c76fbe")
