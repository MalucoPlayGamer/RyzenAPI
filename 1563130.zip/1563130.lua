-- Lua provided by RyzenAPI
-- Game: SuperPower 3

-- MAIN APPLICATION
addappid(1563130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563131, 1, "699ff475cc4eba06592a2fa150847dafd45426707a86f6ca8c32044053c76fbe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
