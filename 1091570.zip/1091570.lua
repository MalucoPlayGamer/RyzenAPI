-- Lua provided by RyzenAPI
-- Game: Transporter Truck Simulator

-- MAIN APPLICATION
addappid(1091570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091571, 1, "e7f89fc10051120f4ee722870c25f4bc469daed66512fab57562d4fe31d7ecaa")
