-- Lua provided by RyzenAPI
-- Game: The Last Good Boy

-- MAIN APPLICATION
addappid(3524950) -- The Last Good Boy

-- MAIN APP DEPOTS / PACKAGES
addappid(3524951, 1, "c9ba8cf697a26304345a6c4019ffcd4ec909f9b6e744468f39d07e1736d942b5") -- Depot 3524951

