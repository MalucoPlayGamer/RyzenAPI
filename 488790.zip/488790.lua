-- Lua provided by RyzenAPI
-- Game: South Park™: The Fractured But Whole™

-- MAIN APPLICATION
addappid(488790)
addappid(564780)
addappid(564790)
addappid(564791)
addappid(564792)
addappid(564793)
addappid(564794)
addappid(729590)
addappid(732560)
addappid(732570)
addappid(732580)
addappid(732590)
addappid(732600)
addappid(732610)
addappid(732620)
addappid(732630)
addappid(732640)
addappid(732650)
addappid(797320)
addappid(797321)

-- MAIN APP DEPOTS / PACKAGES
addappid(488791, 1, "91ae41f7e0eba911942b0e6c268e1d22a942fdd9c9521e3e68ecf42563202678")
addappid(488792, 1, "7b37fd64e50668a85d6c00223deed02337c23e3c6c29023c0f55bb2045c54112")
addappid(488793, 1, "b61f408c4574381dcf80351f090aa9e445965227032f6987d0dcd464160288cb")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
