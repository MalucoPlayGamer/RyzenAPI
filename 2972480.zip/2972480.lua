-- Lua provided by RyzenAPI
-- Game: addappid(2972480)

-- MAIN APPLICATION
addappid(2972480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972481, 1, "2109f1d11002979f07db4de0bea50f9b9a5cf4ad18c4bf429fe366e3e34e1ab5")
