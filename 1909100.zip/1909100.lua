-- Lua provided by RyzenAPI
-- Game: Only Lead Can Stop Them

-- MAIN APPLICATION
addappid(1909100)
-- Game: addappid(1909100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909101, 1, "10cf4415ac7f7fbd6e33191dee8a53ddc3cbbf03e6e4ac281eeb70ad22653359")
