-- Lua provided by SkyAPI 
-- Game: Ghost Pirates of Vooju Island
addappid(344030)
addappid(344031, 1, "a07a165de41ae3da40c3f5ba461d405be34575d92b14761e03d141db4b87be3d")
addappid(344032, 1, "53494c4f5576fe300c438fb2524cd5514415f82607be4e3e7337c7a6382211af")
