-- Lua provided by SkyAPI 
-- Game: Furry Toys
addappid(2445130)
addappid(2445131, 1, "d2676d824e91bb5e4e5a004115366db3a8eb5cd9072fb5d082b3ed2bd113f932")
