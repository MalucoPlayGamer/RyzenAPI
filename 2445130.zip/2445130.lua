-- Lua provided by RyzenAPI
-- Game: Game: Furry Toys

-- MAIN APPLICATION
addappid(2445130)
-- Game: addappid(2445130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445131, 1, "d2676d824e91bb5e4e5a004115366db3a8eb5cd9072fb5d082b3ed2bd113f932")
