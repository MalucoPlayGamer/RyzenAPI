-- Lua provided by RyzenAPI
-- Game: 1036114

-- MAIN APPLICATION
addappid(1036114)
-- Game: addappid(1036114)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036114,0,"55a11e303a0877850848ae437e375f8c4b8d504ef5ecee3e30d937d4e093b7ab")
