-- Lua provided by SkyAPI 
-- Game: The Crimson Diamond: Chapter 1
addappid(1242790)
addappid(1242791, 1, "f3b5f58294cc564c456c6871fdfca6f961a90b95c061a2a52c610c17437cf74d")
addappid(1242792, 1, "2e28d0e44eb5f33cc2a0dd04036011394cff0d3877f7d9bde96bfe42b0fcf323")
