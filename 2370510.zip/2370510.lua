-- Lua provided by RyzenAPI
-- Game: 2370510

-- MAIN APPLICATION
addappid(2370510)
-- Game: addappid(2370510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370511, 1, "98444cf43940a9d0d832ba91c577dbe30df2aa1a1ccb930935303de7ab70d14a")
