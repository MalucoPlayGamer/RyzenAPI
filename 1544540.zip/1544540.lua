-- Lua provided by RyzenAPI
-- Game: AppID 1544540

-- MAIN APPLICATION
addappid(1544540)
-- Game: addappid(1544540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544541, 1, "0ac2c78af0e3a6e0f91c705af1b9941dc1212ab107be6349e4ce1068949103f1")
