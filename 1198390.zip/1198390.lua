-- Lua provided by RyzenAPI
-- Game: Game: Kawaii Girl

-- MAIN APPLICATION
addappid(1198390)
-- Game: addappid(1198390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198391, 1, "56008414f9c876a50d726db3cca4a9e94bc935737a314f5c4c2d55710ef665f6")
