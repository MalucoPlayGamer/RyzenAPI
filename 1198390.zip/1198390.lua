-- Lua provided by RyzenAPI 
-- Game: Kawaii Girl
addappid(1198390)
addappid(1198391, 1, "56008414f9c876a50d726db3cca4a9e94bc935737a314f5c4c2d55710ef665f6")
