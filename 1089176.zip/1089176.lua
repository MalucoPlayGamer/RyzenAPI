-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1089176)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089176,0,"a9c9d89b6026d8f6e139190c1e7d0bc43fd58e6ffa0e35fedb5a35b88c313b0f")
addtoken(1089176,11713462100656534661)
