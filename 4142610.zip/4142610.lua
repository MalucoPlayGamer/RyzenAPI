-- 4142610's Lua and Manifest Created by Hubcap Manifest
-- Clan and Crown
-- Created: August 10, 2026 at 01:12:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4142610) -- Clan and Crown
-- MAIN APP DEPOTS
addappid(4142611, 1, "7965f88eba6dadf72678b865e489d44d1384abd1fa958b522aaa32f6ca2061e2") -- Depot 4142611
setManifestid(4142611, "2201163965904983304", 551466185)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4907000) -- Clan and Crown - Supporter Pack