-- Lua provided by RyzenAPI
-- Game: Clan and Crown

-- MAIN APPLICATION
addappid(4142610) -- Clan and Crown
addappid(4907000) -- Clan and Crown - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4142611, 1, "7965f88eba6dadf72678b865e489d44d1384abd1fa958b522aaa32f6ca2061e2") -- Depot 4142611

