-- Lua provided by RyzenAPI
-- Game: Garlant: My Story

-- MAIN APPLICATION
addappid(2022850)
-- Game: addappid(2022850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022851, 1, "c9f95fa4b504648534ce2f6d053a88e3aba3a750d966513b14dce497e26ae6a8")
