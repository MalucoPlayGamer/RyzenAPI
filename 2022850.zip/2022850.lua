-- Lua provided by RyzenAPI
-- Game: Garlant: My Story

-- MAIN APPLICATION
addappid(2022850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2022851, 1, "c9f95fa4b504648534ce2f6d053a88e3aba3a750d966513b14dce497e26ae6a8")

