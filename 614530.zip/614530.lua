-- Lua provided by SkyAPI 
-- Game: Garden Tale
addappid(614530)
addappid(614531, 1, "9afe437e70643b25a12f59cb0fa07e4a7b94f0a9427e9eda6dfecc92f4bbe671")
addappid(614532, 1, "7f3f4c5f9b06b382b2c23e5cb36b17aadba20600e0a92a73a3ccbbcf7bbd03f2")
