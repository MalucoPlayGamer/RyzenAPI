-- Lua provided by RyzenAPI
-- Game: Emerge: Cities of the Apocalypse

-- MAIN APPLICATION
addappid(457600)

-- MAIN APP DEPOTS / PACKAGES
addappid(457601, 1, "d1c3fe204bc5a7bdc0406da576689beac06f2ce08868fa780b6d54ca6611c983")

