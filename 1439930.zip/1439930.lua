-- Lua provided by RyzenAPI
-- Game: Game: BROTHER WAKE UP

-- MAIN APPLICATION
addappid(1439930)
-- Game: addappid(1439930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439931, 1, "d6d501e977c3fba313ac39e2fdfb431d18a693df595a874a48d3da69eed23eb8")
