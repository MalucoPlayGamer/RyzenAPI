-- Lua provided by RyzenAPI
-- Game: Stock Car Extreme

-- MAIN APPLICATION
addappid(273840)

-- MAIN APP DEPOTS / PACKAGES
addappid(273841, 1, "345271d5e64856816d0157e59ffc69ca62b9994fec68f6c7e81cbf351c30404c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
