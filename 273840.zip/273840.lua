-- Lua provided by RyzenAPI
-- Game: Stock Car Extreme

-- MAIN APPLICATION
addappid(273840)

-- MAIN APP DEPOTS / PACKAGES
addappid(273841, 1, "345271d5e64856816d0157e59ffc69ca62b9994fec68f6c7e81cbf351c30404c")

