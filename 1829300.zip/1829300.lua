-- Lua provided by RyzenAPI
-- Game: 萌萌宝石

-- MAIN APPLICATION
addappid(1829300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829301, 1, "272ddbd4b55ff5f597d93b08ef523a1c0efed520cfee25871efce8b661e49267")
