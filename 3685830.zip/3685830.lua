-- Lua provided by RyzenAPI 
-- Game: Trump Horror
addappid(3685830)
addappid(3685831, 1, "b0fa17a03f61a65730cd94af2ac8a34924cf65540e047fca6e47ac020c7f3f47")
