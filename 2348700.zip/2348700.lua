-- Lua provided by RyzenAPI 
-- Game: Wild Omission
addappid(2348700)
addappid(2348701, 1, "90c5de20787d7ce3f227f56300059fce7269a62e78a6dde13ce0ff4b82584ad6")
