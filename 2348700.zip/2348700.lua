-- Lua provided by RyzenAPI
-- Game: Wild Omission

-- MAIN APPLICATION
addappid(2348700)
addappid(4877470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2348701, 1, "90c5de20787d7ce3f227f56300059fce7269a62e78a6dde13ce0ff4b82584ad6")

