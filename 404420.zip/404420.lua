-- Lua provided by RyzenAPI
-- Game: Sun Dogs

-- MAIN APPLICATION
addappid(404420)
-- Game: addappid(404420)

-- MAIN APP DEPOTS / PACKAGES
addappid(404421, 1, "65c59c81f582cf53fd0ca76625689b7895b113066b79e9d9b35c8b5694f07746")
