-- Lua provided by RyzenAPI
-- Game: Some Some Convenience Store / OST

-- MAIN APPLICATION
addappid(1256620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256628,0,"deb0b0f08b6bba9cb07d4b0c160d7112f442026ff655cca644aae2536932f010")
addappid(1256629,0,"eefe48473947a58b6fa8791d9ee18e3fbc77288857747648a9c6349431ae19da")

