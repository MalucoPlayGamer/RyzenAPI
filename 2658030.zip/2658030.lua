-- Lua provided by RyzenAPI
-- Game: addappid(2658030)

-- MAIN APPLICATION
addappid(2658030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658031, 1, "58fba4c0f0d986335948fb17253cb7ad5fc0f3ba602789c143f581a7d833771e")
