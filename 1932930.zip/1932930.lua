-- Lua provided by RyzenAPI
-- Game: Space Salvage Demo

-- MAIN APPLICATION
addappid(1932930)
-- Game: addappid(1932930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932931, 1, "6973cd1505a61e92133bbd1183cd63ee131e620942b64af939d48be4df315ef1")
