-- Lua provided by RyzenAPI
-- Game: 843430

-- MAIN APPLICATION
addappid(843430)
-- Game: addappid(843430)

-- MAIN APP DEPOTS / PACKAGES
addappid(843431, 1, "0ceb7c3eb49f2b060fe9ffea1099012dad3763020eb953def792658bd27432a5")
