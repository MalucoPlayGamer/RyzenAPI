-- Lua provided by RyzenAPI
-- Game: Righty Tighty XL

-- MAIN APPLICATION
addappid(843430)

-- MAIN APP DEPOTS / PACKAGES
addappid(843431, 1, "0ceb7c3eb49f2b060fe9ffea1099012dad3763020eb953def792658bd27432a5")

