-- Lua provided by RyzenAPI
-- Game: addappid(1567350)

-- MAIN APPLICATION
addappid(1567350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567350,0,"42cd13dd60d04a2ac295c686cbb6304627a343ac4cfc6241063810ad469a42fc")
