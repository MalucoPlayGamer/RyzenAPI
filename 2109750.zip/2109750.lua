-- Lua provided by RyzenAPI
-- Game: Game: Passion Eye

-- MAIN APPLICATION
addappid(2109750)
-- Game: addappid(2109750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109751, 1, "d9ce09d342a315c82141a647af0f8ae336abcece4b4235d6fde322f3ccf79601")
