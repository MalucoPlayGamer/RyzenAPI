-- Lua provided by RyzenAPI
-- Game: AppID 836450

-- MAIN APPLICATION
addappid(836450)
-- Game: addappid(836450)

-- MAIN APP DEPOTS / PACKAGES
addappid(836451, 1, "6ecfc9428a5a833677870d53af40fcbbf83e8d0d03dd52b756807d5cc3a9d48f")
addappid(836452, 1, "c46370c1848ae65a5f7f6f551cf211f92c76763f8e66de920621e91e9cf405ab")
addappid(837450, 0, "1f49eea1805ba23896a61dfbb8308c0931a9d93eb52dead48fee97b731b3e2de")
