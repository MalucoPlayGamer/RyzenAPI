-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2889150)
addappid(2889150,0,"b0a9860b92ff3a8825c49608f2165a2d7d73dae26292401e9fe1767c62ef88d7")
-- setManifestid(2889150,"8623422436674332995")