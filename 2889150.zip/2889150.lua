-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2889150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889150,0,"b0a9860b92ff3a8825c49608f2165a2d7d73dae26292401e9fe1767c62ef88d7")
