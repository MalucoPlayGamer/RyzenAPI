-- Lua provided by RyzenAPI
-- Game: Hisui no Kikai

-- MAIN APPLICATION
addappid(1639420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639421, 1, "9f5808575262d8cb7252a32284ad477beaa7366827271bba17f124aa08f925e7")
