-- Lua provided by RyzenAPI
-- Game: Game: Coreupt

-- MAIN APPLICATION
addappid(2360770)
-- Game: addappid(2360770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360771, 1, "3c2e52371015fc5ccdc3a965a24e810ff463885b14fc1a532cb0f21f29d5a77d")
