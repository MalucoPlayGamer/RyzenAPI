-- Lua provided by SkyAPI 
-- Game: Coreupt
addappid(2360770)
addappid(2360771, 1, "3c2e52371015fc5ccdc3a965a24e810ff463885b14fc1a532cb0f21f29d5a77d")
