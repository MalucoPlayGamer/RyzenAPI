-- Lua provided by RyzenAPI
-- Game: The Ai Games

-- MAIN APPLICATION
addappid(1131660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1131661, 1, "f60ab1aa2f866d4438d54b7012e53bac2d2804adc32ae10f27691fbd0a10b043")

