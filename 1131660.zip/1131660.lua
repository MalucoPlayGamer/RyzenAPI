-- Lua provided by RyzenAPI
-- Game: The Ai Games

-- MAIN APPLICATION
addappid(1131660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131661, 1, "f60ab1aa2f866d4438d54b7012e53bac2d2804adc32ae10f27691fbd0a10b043")
