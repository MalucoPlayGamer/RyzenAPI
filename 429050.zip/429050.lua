-- Lua provided by RyzenAPI
-- Game: Game: Feed and Grow: Fish

-- MAIN APPLICATION
addappid(429050)
-- Game: addappid(429050)

-- MAIN APP DEPOTS / PACKAGES
addappid(429051, 1, "85ef14566628e754a339d2f5ad9de91bd521f6cef00d101af3dd1ba569d9b212")
