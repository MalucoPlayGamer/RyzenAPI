-- Lua provided by RyzenAPI
-- Game: Feed and Grow: Fish

-- MAIN APPLICATION
addappid(429050)

-- MAIN APP DEPOTS / PACKAGES
addappid(429051, 1, "85ef14566628e754a339d2f5ad9de91bd521f6cef00d101af3dd1ba569d9b212")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
