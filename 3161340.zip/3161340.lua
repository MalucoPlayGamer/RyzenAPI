-- Lua provided by RyzenAPI
-- Game: addappid(3161340)

-- MAIN APPLICATION
addappid(3161340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161341, 1, "b1f8813d429c85e6aae57f60f0e61b6371ff6d2f6e18935eb9673b941f90f1bf")
