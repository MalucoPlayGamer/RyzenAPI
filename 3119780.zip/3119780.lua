-- Lua provided by RyzenAPI
-- Game: Drive Thru Miami - Restaurant Simulator

-- MAIN APPLICATION
addappid(3119780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119782,0,"4a55a01501901dea7ca5a60ddbdce672733238b6b838f6bae252ccda69436572")

