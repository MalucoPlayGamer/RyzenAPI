-- Lua provided by RyzenAPI
-- Game: REDCON Demo

-- MAIN APPLICATION
addappid(3333770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333771, 1, "19ea7bfb00f8f1bca920acaf69d938ee9fb96c76f9e4652ca62711558d98f405")

