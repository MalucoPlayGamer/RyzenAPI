-- Lua provided by RyzenAPI
-- Game: Game: Zeitghast

-- MAIN APPLICATION
addappid(2593070)
-- Game: addappid(2593070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593071, 1, "7f68b2e21e71483756d700e3d93653c7c218f3ca7ac3b1751f30191102d5a428")
