-- Lua provided by RyzenAPI
-- Game: Parisian Bistro Simulator

-- MAIN APPLICATION
addappid(3058360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058361,0,"26406a7886eee2c23db04271be53ba949b04ea41e7f2626113e76c244f89f9b1")

