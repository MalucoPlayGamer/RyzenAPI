-- Lua provided by RyzenAPI
-- Game: Animyst

-- MAIN APPLICATION
addappid(871100)

