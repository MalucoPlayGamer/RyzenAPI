-- Lua provided by RyzenAPI
-- Game: イライザの秘薬

-- MAIN APPLICATION
addappid(4713810)

-- MAIN APP DEPOTS / PACKAGES
addappid(4713811,0,"9e5da69030c141279841c3b178311c52329ad7aa9d3f64a7c87ee0854b8a6e95")

