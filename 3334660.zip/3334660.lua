-- Lua provided by RyzenAPI
-- Game: Winion Virus

-- MAIN APPLICATION
addappid(3334660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334661, 1, "481749caf913f8ab96b6e58f8294d6d3f8dd724d96b3f7a3d508e9956356ff8c")
