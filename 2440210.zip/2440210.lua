-- Lua provided by RyzenAPI
-- Game: Lost Beacon

-- MAIN APPLICATION
addappid(2440210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440211, 1, "43ae1d7ddc2d9e2b9bdec3698d18bb8d4f26ec2a8579f228ef73b53aa7b8aa0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
