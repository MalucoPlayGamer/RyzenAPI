-- Lua provided by RyzenAPI
-- Game: Lost Beacon

-- MAIN APPLICATION
addappid(2440210)
-- Game: addappid(2440210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440211, 1, "43ae1d7ddc2d9e2b9bdec3698d18bb8d4f26ec2a8579f228ef73b53aa7b8aa0a")
