-- Lua provided by RyzenAPI
-- Game: Sorry, James

-- MAIN APPLICATION
addappid(659190)

-- MAIN APP DEPOTS / PACKAGES
addappid(659191, 1, "0b0c8733715423c3d2da8f30aca0ce8f2d2f79d852471aef4904c04833ca01b0")

