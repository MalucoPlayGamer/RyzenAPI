-- Lua provided by RyzenAPI
-- Game: Game: Collapsed

-- MAIN APPLICATION
addappid(1949850)
-- Game: addappid(1949850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949851, 1, "0866031dd11a190916194b8857f5c29015113c95cdbb2a547c5b376df94b2ab7")
