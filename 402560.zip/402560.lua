-- Lua provided by RyzenAPI
-- Game: 402560

-- MAIN APPLICATION
addappid(402560)
-- Game: addappid(402560)

-- MAIN APP DEPOTS / PACKAGES
addappid(402561, 1, "db7579f964fd367cec4c679dadd63fe886594ddc0f988c3610c525a99f25e01c")
addappid(402562, 1, "6ef4235c1cdeddfa419438a896b2b033f92ae2ea351cc08fd36eff5fe1ea4514")
addappid(402563, 1, "762abb5aa305f9873f29cae346d30d8f388928ccecf37797c416f8acaf81a37c")
addappid(402564, 1, "abd8e519bff4b71c4e474adf43938bd60107fe93d12127c82fe3d8e30aa6f72d")
