-- Lua provided by RyzenAPI
-- Game: Lethal League

-- MAIN APPLICATION
addappid(261180)

-- MAIN APP DEPOTS / PACKAGES
addappid(261181, 1, "00fcf997d4736a229775d41c0352b2aa27b1166f0503b22beab0165525cd28e6")
addappid(261183, 1, "f64af6cec3fc66a4c9fe1288c0607dcb316ad7df8296d2f677ffdbb02f824c16")
addappid(261184, 1, "23371550348f06f1782ffe3c3f2d54f817ff6da28dae910f1306bc57a56c474c")
