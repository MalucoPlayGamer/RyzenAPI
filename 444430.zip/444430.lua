-- Lua provided by RyzenAPI
-- Game: AppID 444430

-- MAIN APPLICATION
addappid(444430)

-- MAIN APP DEPOTS / PACKAGES
addappid(444431, 1, "da7de71a572eef161e03b2e72b3370111dd66e98cb0ca33188e011d28183fbe4")
addappid(444432, 1, "20ceb1c884e75d6caa00fc38924e423d581b9d85dd29e53a5dbfb9c7b0ef0aab")
