-- Lua provided by RyzenAPI
-- Game: AppID 1909200

-- MAIN APPLICATION
addappid(1909200)
-- Game: addappid(1909200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909201, 1, "7ffdc3c794b9ec1307c64b009b1a38dc9e6107fc03291f845983baa3f9b3e6f4")
