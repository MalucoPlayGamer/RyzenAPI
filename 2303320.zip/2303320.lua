-- Lua provided by RyzenAPI
-- Game: Game: Three Minutes To Eight

-- MAIN APPLICATION
addappid(2303320)
-- Game: addappid(2303320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303321, 1, "1fe476ca610e1602fda5ced7432174277b614d628ed60263d5b87c83bb73bec7")
addappid(2303322, 1, "686a778ef4cfdb3b5ef419ab2f5ad72d0480397f269012d8f1de3b0022b409b6")
addappid(2303323, 1, "a3ac64b55ca143ab5f7edcad03bdfd5ed221b280f3872ee1e613268422a44435")
