-- Lua provided by RyzenAPI
-- Game: Yakiniku simulator

-- MAIN APPLICATION
addappid(2001570)
-- Game: addappid(2001570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001571, 1, "a6307b1d5c1ed13686cb8b6ac2b9f2da72e740dcbfc7ebf6a639313e094f4741")
