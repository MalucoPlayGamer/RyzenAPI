-- Lua provided by RyzenAPI
-- Game: Cyberline Racing

-- MAIN APPLICATION
addappid(514460)

-- MAIN APP DEPOTS / PACKAGES
addappid(514463,0,"3b04e0f259de3c174ef1b76389ce2e22c29b63317d11be4e6d605d053301f3d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
