-- Lua provided by RyzenAPI
-- Game: Cyberline Racing

-- MAIN APPLICATION
addappid(514460)
-- Game: addappid(514460)

-- MAIN APP DEPOTS / PACKAGES
addappid(514463,0,"3b04e0f259de3c174ef1b76389ce2e22c29b63317d11be4e6d605d053301f3d2")
