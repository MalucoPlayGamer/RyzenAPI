-- Lua provided by RyzenAPI
-- Game: 投资模拟器：打工篇

-- MAIN APPLICATION
addappid(1355760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355761, 1, "f11bb7370de946420f06a9f2099c80ee900a43475999058937a8c89172adee30")

