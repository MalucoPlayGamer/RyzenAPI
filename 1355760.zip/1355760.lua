-- Lua provided by RyzenAPI 
-- Game: AppID 1355760
addappid(1355760)
addappid(1355761, 1, "f11bb7370de946420f06a9f2099c80ee900a43475999058937a8c89172adee30")
