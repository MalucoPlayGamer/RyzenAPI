-- Lua provided by RyzenAPI
-- Game: Spy Story. The Elusive Evidence

-- MAIN APPLICATION
addappid(1263510)
-- Game: addappid(1263510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263511, 1, "3e9ea7ab2e9f941f9e051de86e5783bc5c507a6fb4b9cdb8f605472c85a2a24c")
addappid(1263512, 1, "49428102db79cc77611d3e6111150d574f5b3999c4022e2e58eaacd1d604f3a8")
addappid(1263513, 1, "8022c848ad54e7d92c5d5664f6b49b9859dfdae139f5a858a88aa5d816d2ed05")
addappid(1263514, 1, "2d1982286856e991290331c35080a1a9d8c3db578175a5d9cbd1d04bbe3fe2c8")
