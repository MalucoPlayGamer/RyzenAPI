-- Lua provided by RyzenAPI
-- Game: Deadly Heart Gambit

-- MAIN APPLICATION
addappid(3202110)
-- Game: addappid(3202110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202111, 1, "49e5cab226d156cbc74eb84e80c3e1d6c1b0f84fe672bf20fd1a93acda0ed13f")
