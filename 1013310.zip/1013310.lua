-- Lua provided by RyzenAPI
-- Game: Peaky Blinders: Mastermind

-- MAIN APPLICATION
addappid(1013310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013312,0,"f541ca94dec83e92609c67585941c5b6177c37181c2347e04ae116527f0c39b9")

