-- Lua provided by RyzenAPI
-- Game: Great Ambition of the SLIMES

-- MAIN APPLICATION
addappid(2171500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171501, 1, "48e6432b8accc52852e0d3883dfffe38798f55d2474b7d2facd5300b678e911d")
