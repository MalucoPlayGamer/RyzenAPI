-- Lua provided by RyzenAPI 
-- Game: AppID 636570
addappid(636570)
addappid(636571, 1, "688307cf0dbdaee57a8cfe3b1f4835f34bfd2e315993c8fdbfd90f0d3386530f")
