-- Lua provided by RyzenAPI
-- Game: Nights of Azure 2: Bride of the New Moon

-- MAIN APPLICATION
addappid(636570)
addappid(696350)
addappid(727880)
addappid(743270)
addappid(743280)

-- MAIN APP DEPOTS / PACKAGES
addappid(636571,0,"688307cf0dbdaee57a8cfe3b1f4835f34bfd2e315993c8fdbfd90f0d3386530f")

