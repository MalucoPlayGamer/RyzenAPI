-- Lua provided by RyzenAPI
-- Game: Nights of Azure 2: Bride of the New Moon

-- MAIN APPLICATION
addappid(636570)
addappid(696350)
addappid(727880)
addappid(743270)
addappid(743280)

-- MAIN APP DEPOTS / PACKAGES
addappid(636571,0,"688307cf0dbdaee57a8cfe3b1f4835f34bfd2e315993c8fdbfd90f0d3386530f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
