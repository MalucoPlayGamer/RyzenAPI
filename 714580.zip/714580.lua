-- Lua provided by RyzenAPI 
-- Game: Google Spotlight Stories: Son of Jaguar
addappid(714580)
addappid(714581, 1, "e770ef1db70df7be5671f6472671c194343d414f81255bd8a801caa37b7a984e")
addappid(714582, 1, "e3c4c1aa7e550bac5a50655b2a84078dd93aa8b97208eb15bca16213459fe957")
