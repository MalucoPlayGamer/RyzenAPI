-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Son of Jaguar

-- MAIN APPLICATION
addappid(714580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(714581, 1, "e770ef1db70df7be5671f6472671c194343d414f81255bd8a801caa37b7a984e")
addappid(714582, 1, "e3c4c1aa7e550bac5a50655b2a84078dd93aa8b97208eb15bca16213459fe957")

