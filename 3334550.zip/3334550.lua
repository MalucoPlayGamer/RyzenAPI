-- Lua provided by RyzenAPI
-- Game: Cursed Digicam | 呪われたデジカメ

-- MAIN APPLICATION
addappid(3334550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334551, 1, "69f60caeb41d4add1a61687aeda7b5f6093aaaf8b3a114bfed61ee506c06917c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
