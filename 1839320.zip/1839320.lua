-- Lua provided by RyzenAPI 
-- Game: The Future Project
addappid(1839320)
addappid(1839321, 1, "4a02140dd935fe3eb2c58cdf9f9eed34d82231fdcecb2cd9e80687f2c9e1224f")
