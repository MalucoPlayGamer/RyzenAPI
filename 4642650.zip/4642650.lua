-- 4642650's Lua and Manifest Created by Hubcap Manifest
-- Souls Inferno
-- Created: July 22, 2026 at 14:13:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4642650) -- Souls Inferno
-- MAIN APP DEPOTS
addappid(4642651, 1, "5df90d82e0694ef1df43b35382f8cbbd761381ea7eeb963b207a8164bfaedc10") -- Depot 4642651
setManifestid(4642651, "8518922160206177315", 58741188)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)