-- Lua provided by RyzenAPI
-- Game: Game: 风岬-The Everlasting lovestory at the Windcap Demo

-- MAIN APPLICATION
addappid(2599660)
-- Game: addappid(2599660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599661, 1, "c4522cd3aa95b21330e0471d2bb68e42e4d6fa3ee158a5ab19f3005766bdf1af")
