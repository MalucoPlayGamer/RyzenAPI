-- Lua provided by RyzenAPI
-- Game: AppID 228080

-- MAIN APPLICATION
addappid(228080)
-- Game: addappid(228080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228081, 1, "6a08456582cd60ce4ed2629ff519aada3b48dcfdf001e67c3d2762e01729340f")
addappid(228082, 1, "16434c1bd9ed919c601d82dea6e9ec87a836ca324765ac720bb1ff1798ae7851")
