-- Lua provided by RyzenAPI
-- Game: Battlerite

-- MAIN APPLICATION
addappid(504370)
addappid(524330)
addappid(717340)
addappid(746730)
addappid(746731)

