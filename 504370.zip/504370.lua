-- Lua provided by RyzenAPI
-- Game: Battlerite

-- MAIN APPLICATION
addappid(504370)

