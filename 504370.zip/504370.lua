-- Lua provided by RyzenAPI
-- Game: Battlerite

-- MAIN APPLICATION
addappid(504370)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(524330)
addappid(717340)
addappid(746730)
addappid(746731)
