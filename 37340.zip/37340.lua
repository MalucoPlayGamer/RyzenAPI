-- Lua provided by RyzenAPI
-- Game: Fitness Dash™

-- MAIN APPLICATION
addappid(37340)

-- MAIN APP DEPOTS / PACKAGES
addappid(37341, 1, "823dd673e5d353620257541ae8155835140e6ab02bd0cfb45eca90824fe68746")

