-- Lua provided by RyzenAPI
-- Game: The Afterlife Cafe

-- MAIN APPLICATION
addappid(3763730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3763731,0,"7d92937c34b42214f4f35b45bd9a3b0a03cf32861e46542a07810881d62cb55f")

