-- Lua provided by RyzenAPI
-- Game: Matchpoint - Tennis Championships

-- MAIN APPLICATION
addappid(1345760)
-- Game: addappid(1345760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345761, 1, "b4f659779486e7d7fc10b412ac39ba6a643b46c14f58626a5c03a9fb001720c5")
