-- Lua provided by RyzenAPI
-- Game: Love is Dead

-- MAIN APPLICATION
addappid(453910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(453911, 1, "9d4c33b295771f1bd672874eeabfe5f92aa0b063b7e2b3144c5bdaff53abf2fe")
addappid(453912, 1, "040e4f434e27964df656322cba60803de3c73854a7e51e6ba3581c93806eb170")
addappid(453913, 1, "f48036560e7e04b5a0133780bea6087614ebcb13c8a3a2db3ba72efebcb7fdb0")
addappid(453914, 1, "19b4f63037f8f70e78267db0195af8f83fb720e3c03eadf2b0d23f66ad1cc345")

