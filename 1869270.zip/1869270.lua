-- Lua provided by RyzenAPI
-- Game: Multi Turret Academy

-- MAIN APPLICATION
addappid(1869270)
addappid(3020050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869271, 1, "383cfc607b678816d447a6c1deead0f145f9e4d59ab77ddbb80af0fd50f29fc8")

