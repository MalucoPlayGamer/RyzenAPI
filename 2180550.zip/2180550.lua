-- Lua provided by RyzenAPI
-- Game: Game: Dragon Princess is Hungry

-- MAIN APPLICATION
addappid(2180550)
-- Game: addappid(2180550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180551, 1, "36b684f637883c576bc7fa012dd400189f16b911e56bbfc1a09329c2088056c3")
addappid(2180552, 1, "f2cb2f750d4d4953780d82cf951a09b106a117428797e7eeb07c44cb52bc0ce5")
addappid(2180553, 1, "8b4e39035b4b84ef3850ae750f580838f8562eaa9ec4095d80148580882edc6e")
