-- Lua provided by RyzenAPI
-- Game: Game: AppID 740090

-- MAIN APPLICATION
addappid(740090)
-- Game: addappid(740090)

-- MAIN APP DEPOTS / PACKAGES
addappid(740091, 1, "95a3d36c235bc624289d5d3dd6ce6b78577f9a0eb0e2cce192d90a79c8d4d7c2")
