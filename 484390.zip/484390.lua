-- Lua provided by RyzenAPI
-- Game: AppID 484390

-- MAIN APPLICATION
addappid(484390)

-- MAIN APP DEPOTS / PACKAGES
addappid(484391, 1, "dd8025b8144fa5659bae755e7ef7fab851b713bcfc8f39cd45a232755e0fea90")

