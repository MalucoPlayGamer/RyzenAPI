-- Lua provided by RyzenAPI
-- Game: addappid(2346410)

-- MAIN APPLICATION
addappid(2346410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346411, 1, "d7c9d01b64ae87808d13677c8bcf87ec9c65923a7145864d396a3f5023069fad")
