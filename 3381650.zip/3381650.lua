-- Lua provided by RyzenAPI
-- Game: AppID 3381650

-- MAIN APPLICATION
addappid(3381650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381651, 1, "8bdff00193ec833a64e40b60ce4580358e14930fb824cb4712c66096c1739cc9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
