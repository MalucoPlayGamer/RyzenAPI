-- Lua provided by RyzenAPI
-- Game: Game: AppID 3381650

-- MAIN APPLICATION
addappid(3381650)
-- Game: addappid(3381650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381651, 1, "8bdff00193ec833a64e40b60ce4580358e14930fb824cb4712c66096c1739cc9")
