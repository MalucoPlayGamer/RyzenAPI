-- Lua provided by RyzenAPI
-- Game: Game: Lunar Axe

-- MAIN APPLICATION
addappid(1305820)
-- Game: addappid(1305820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305821, 1, "cc176bfcb424021d8c3c97eaf543d8a0d1bb537892a99b578d4a6d1b36ea4ee8")
