-- Lua provided by RyzenAPI
-- Game: AppID 3433030

-- MAIN APPLICATION
addappid(3433030)
addappid(3502280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3433031, 1, "c1191daad2c55f0d496b5c809fb4280db1765a3e094eda8b5bd813ee1e2fbd02")

