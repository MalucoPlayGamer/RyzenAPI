-- Lua provided by RyzenAPI
-- Game: Combat Kart

-- MAIN APPLICATION
addappid(2399430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399431,0,"d86d1b9b0561a6404cf7da28d757baf3a7b5ca28b393118f1ff74ac5dac5b91c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2653800)
addappid(4108340)
