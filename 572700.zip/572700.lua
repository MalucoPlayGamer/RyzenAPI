-- Lua provided by RyzenAPI
-- Game: Nancy Drew: Sea of Darkness

-- MAIN APPLICATION
addappid(572700)
addappid(954130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(572701,0,"ee59e09fa3cf4139a95636f3be57a5bda50086cee250c0bec5ad2725f28d0d75")

