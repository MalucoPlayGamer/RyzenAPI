-- Lua provided by RyzenAPI
-- Game: Nancy Drew: Sea of Darkness

-- MAIN APPLICATION
addappid(572700)

-- MAIN APP DEPOTS / PACKAGES
addappid(572701,0,"ee59e09fa3cf4139a95636f3be57a5bda50086cee250c0bec5ad2725f28d0d75")

