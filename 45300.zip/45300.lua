-- Lua provided by SkyAPI 
-- Game: Wings of Prey: Special Edition
addappid(45300)
addappid(45301, 1, "210f5f0e1ba80078cc90ea18f0988b90f94a3b102a05b9de64963077a3b2a438")
