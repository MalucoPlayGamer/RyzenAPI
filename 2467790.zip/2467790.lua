-- Lua provided by RyzenAPI
-- Game: Joker Show - Horror Escape

-- MAIN APPLICATION
addappid(2467790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467791, 1, "d91af3f986c78d860ec5818b635f12c0f49ed46b126fc6a7cc820f603207aa2a")
