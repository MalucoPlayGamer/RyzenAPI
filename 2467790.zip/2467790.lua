-- Lua provided by RyzenAPI 
-- Game: Joker Show - Horror Escape
addappid(2467790)
addappid(2467791, 1, "d91af3f986c78d860ec5818b635f12c0f49ed46b126fc6a7cc820f603207aa2a")
