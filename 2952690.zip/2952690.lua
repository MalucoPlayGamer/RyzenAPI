-- Lua provided by RyzenAPI
-- Game: Witch of Eclipse

-- MAIN APPLICATION
addappid(2952690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952691, 1, "a7c471d3bd0c8e17e79b837eee5c56e785de66eeee3ba9076bff20a463f7b8e0")
addappid(2952692, 1, "15a330ef32aadf50a12e4d531d136d541e9efdf90192fc9c0c3bd679baff176f")
addappid(2952693, 1, "568a41ccf7ed79ceda326429c88610e4c70c29f4c9a7147b32fa0fc6aa314b26")

