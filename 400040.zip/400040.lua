-- Lua provided by RyzenAPI
-- Game: addappid(400040)

-- MAIN APPLICATION
addappid(400040)

-- MAIN APP DEPOTS / PACKAGES
addappid(400041, 1, "c11cc8fc37ef0584f8e81955b8d6b5dd1f9ed6f8519cc44b5eedc435da815653")
