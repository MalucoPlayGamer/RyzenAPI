-- Lua provided by RyzenAPI
-- Game: ShareX

-- MAIN APPLICATION
addappid(400040)
addappid(406420)
addappid(406421)
addappid(406422)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(400041, 1, "c11cc8fc37ef0584f8e81955b8d6b5dd1f9ed6f8519cc44b5eedc435da815653")
