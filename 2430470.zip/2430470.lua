-- Lua provided by RyzenAPI
-- Game: Game: Vilde

-- MAIN APPLICATION
addappid(2430470)
-- Game: addappid(2430470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430471, 1, "003e2f29b651f13ced562761e2661d1f9436e28c504d16ed7ce77a52d219565c")
