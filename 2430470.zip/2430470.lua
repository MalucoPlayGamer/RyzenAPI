-- Lua provided by RyzenAPI
-- Game: Vilde

-- MAIN APPLICATION
addappid(2430470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2430471, 1, "003e2f29b651f13ced562761e2661d1f9436e28c504d16ed7ce77a52d219565c")

