-- Lua provided by RyzenAPI
-- Game: Beat animals

-- MAIN APPLICATION
addappid(2255850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255851, 1, "d055a91a9b49c79bbc61a2d758fadfb88971b510ba32bd435e823afe0ecf47b4")

