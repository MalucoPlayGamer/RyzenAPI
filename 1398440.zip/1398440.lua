-- Lua provided by RyzenAPI 
-- Game: Transcender
addappid(1398440)
addappid(1398441, 1, "90dbc208c890e2d6692c9ee1c888921e2d7f3a43aa680d8e398346e6d09a929f")
