-- Lua provided by RyzenAPI 
-- Game: Three Kingdom: The Journey
addappid(1314770)
addappid(1314771, 1, "5b722f4170b4bd0ccb122047b9f1916150278c887256a439e963af8875c025f8")
