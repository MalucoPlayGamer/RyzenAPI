-- Lua provided by RyzenAPI
-- Game: Three Kingdom: The Journey

-- MAIN APPLICATION
addappid(1314770)
-- Game: addappid(1314770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314771, 1, "5b722f4170b4bd0ccb122047b9f1916150278c887256a439e963af8875c025f8")
