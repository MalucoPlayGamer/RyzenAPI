-- Lua provided by RyzenAPI
-- Game: AppID 629220

-- MAIN APPLICATION
addappid(629220)
addappid(817260)
-- Game: addappid(629220)

-- MAIN APP DEPOTS / PACKAGES
addappid(629221, 1, "407c6a9c03dca3e04505d8a5684af2c6a159317656a68c0556faefbfd6ffd36f")
