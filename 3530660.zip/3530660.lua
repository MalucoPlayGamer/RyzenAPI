-- Lua provided by RyzenAPI 
-- Game: Reboot My Heart
addappid(3530660)
addappid(3530661, 1, "dddb50a503c9ce5b202a1f6739a6fed1c0054d8fec693f7d86976d1b8e945b23")
