-- Lua provided by RyzenAPI
-- Game: Game: Tisnart Shapes

-- MAIN APPLICATION
addappid(820500)
-- Game: addappid(820500)

-- MAIN APP DEPOTS / PACKAGES
addappid(820501, 1, "cc6fa62a0a468157683d8226485d450b26f4d452cb7de31f2dda87f11217097a")
