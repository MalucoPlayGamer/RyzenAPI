-- Lua provided by RyzenAPI
-- Game: Black Ink

-- MAIN APPLICATION
addappid(233680)

-- MAIN APP DEPOTS / PACKAGES
addappid(233681, 1, "01283df5e1fc27077b9efbe9f0fd3c7e6bb14bdbb0e680dc59af70e0d730527c")
addappid(1827230, 0, "07a3118471c51dfe2cfa0e574a7e6c0bc0c0e62b584c3eb84310227e7b830231")
