-- Lua provided by RyzenAPI
-- Game: Black Ink

-- MAIN APPLICATION
addappid(233680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(233681, 1, "01283df5e1fc27077b9efbe9f0fd3c7e6bb14bdbb0e680dc59af70e0d730527c")
addappid(1827230, 0, "07a3118471c51dfe2cfa0e574a7e6c0bc0c0e62b584c3eb84310227e7b830231")

