-- Lua provided by SkyAPI 
-- Game: Boring Man - Online Tactical Stickman Combat
addappid(346120)
addappid(346121, 1, "dad68e423a1e59d97f0c3eea6b4f8558b7006b4e62eb076f0e12be16828a4aa1")
addappid(346122, 1, "5bf450b61a59ac7687a096ba8ec3eb892cc52b856008bd4a949f372a6ea2ac3e")
