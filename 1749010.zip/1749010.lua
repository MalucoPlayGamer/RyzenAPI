-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1749010)
addappid(1749011)
-- Game: addappid(1749010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749012,0,"d5fae04fcf591663475153cc15137c81a4c2d2ff1f39dc14ef4e076768b2f3fc")
addappid(1749013,0,"37bfdb350a84a1af624ea5a3f810def24c6ee4d0b12d678f53b41690647b0913")
addappid(1749014,0,"bb1c90eb9181b0eaa9a3fcbabe34b3ce332dccc2004c777cba75912ced67c387")
