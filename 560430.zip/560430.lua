-- Lua provided by RyzenAPI
-- Game: Indiana Jones® and the Emperor's Tomb™

-- MAIN APPLICATION
addappid(560430)

-- MAIN APP DEPOTS / PACKAGES
addappid(560431, 1, "817ebb2b7864788bafca445ba418190f10f6fc455cb9c83ef989b7483d15437a")
addappid(560432, 1, "967e62d5dd689f01fe4e210c2ce7f25d4b8d0e18ba8601a2ebb844448abb577f")
addappid(560433, 1, "68b9609460e65caebe6d865398a2b2cc85804ede39f338593250af8a52c1ed37")
addappid(560434, 1, "307092cb017811f905a3d3d64472c6d5887f9ee43ff85677b1715f4ce8f4f0da")
addappid(560435, 1, "be21f3a3c25d60afa37a2d4773a27ca1921088f65e6ce7d86a0eb3fb05275120")

