-- 2950790's Lua and Manifest Created by Hubcap Manifest
-- IRON NEST: Heavy Turret Simulator
-- Created: August 06, 2026 at 11:01:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2950790) -- IRON NEST: Heavy Turret Simulator
-- MAIN APP DEPOTS
addappid(2950791, 1, "9024fbcca954551a182e4f9158ef6d35f5e2acc4c5f547f48d3ce0f725f76d4f") -- Depot 2950791
setManifestid(2950791, "8207907692792295652", 3813606245)