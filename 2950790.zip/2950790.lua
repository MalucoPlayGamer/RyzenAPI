-- Lua provided by RyzenAPI
-- Game: IRON NEST: Heavy Turret Simulator

-- MAIN APPLICATION
addappid(2950790) -- IRON NEST: Heavy Turret Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(2950791, 1, "9024fbcca954551a182e4f9158ef6d35f5e2acc4c5f547f48d3ce0f725f76d4f") -- Depot 2950791

