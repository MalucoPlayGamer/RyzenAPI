-- Lua provided by RyzenAPI
-- Game: Game: Welcome To Everdell

-- MAIN APPLICATION
addappid(2553410)
-- Game: addappid(2553410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553411, 1, "5efb66c0fef4401eae190dd3fb07f4feeae757947c6abafc4817759a356fc68f")
