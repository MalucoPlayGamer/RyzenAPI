-- Lua provided by RyzenAPI
-- Game: In Marte - The First Moon

-- MAIN APPLICATION
addappid(1583370)
addappid(1721760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583371, 1, "abf631611a020306cd83106c52183599b552a06fa22a83e4651bcbae97d84cfd")

