-- Lua provided by RyzenAPI
-- Game: 666160

-- MAIN APPLICATION
addappid(666160)
-- Game: addappid(666160)

-- MAIN APP DEPOTS / PACKAGES
addappid(666161, 1, "543a32ffcfb0463f9fb01db40a9c710cde0e56471a1ba53b06cf664af5545c3d")
addappid(666162, 1, "4f57db0d51fa047ecd9b28b5baf5b5ee91da8fe094fd223814ed17043f953bb6")
addappid(666163, 1, "22d384fe3f91c37af674a7a9534fc3ceeda87a5db4f3cc6b4b8e3b2c9881c171")
addappid(666164, 1, "cae13d9386b1abb2f1f1d0613eb2ae124d81e82902564316e3fafd37438c9fec")
