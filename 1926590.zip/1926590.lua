-- Lua provided by RyzenAPI
-- Game: Game: Nancy Drew®: Mystery of the Seven Keys™

-- MAIN APPLICATION
addappid(1926590)
-- Game: addappid(1926590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926591, 1, "538d9c3e9bd58af0afe52160a629cd57d31457fddc4a8a8375468fdd613e76f7")
