-- Lua provided by RyzenAPI
-- Game: 3418690

-- MAIN APPLICATION
addappid(3418690)
-- Game: addappid(3418690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418692,0,"9ce628d90a7d2d0ab7f1a9d33926a1aaf097c3a880585ba9f8a058af6065c1b9")
