-- Lua provided by RyzenAPI
-- Game: Please Smile Demo

-- MAIN APPLICATION
addappid(3111220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111221, 1, "b999ffaee104d77eabf6638f3cc84964e93e4e45b35243594dd93dfa2e22b9be")

