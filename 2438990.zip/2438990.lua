-- Lua provided by RyzenAPI
-- Game: Ark Nova

-- MAIN APPLICATION
addappid(2438990)
-- Game: addappid(2438990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438991, 1, "0121c6ac9603a1d3570b8736085b758e5c13b06aca26ce3a35148fd47e75a4fa")
