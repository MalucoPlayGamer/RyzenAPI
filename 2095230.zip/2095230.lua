-- Lua provided by RyzenAPI
-- Game: 2095230

-- MAIN APPLICATION
addappid(2095230)
-- Game: addappid(2095230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095231, 1, "de9f4befecd938948624e6196a85752176c4431504b99b03ae2d9a276ada52cf")
