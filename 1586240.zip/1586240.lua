-- Lua provided by RyzenAPI
-- Game: Pro Deer Hunting 2

-- MAIN APPLICATION
addappid(1586240)
-- Game: addappid(1586240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586241, 1, "1f966d322343d9ff6162313103316effb7686624aa80f1d4a287e776764db49f")
