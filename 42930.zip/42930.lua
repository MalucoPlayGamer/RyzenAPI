-- Lua provided by SkyAPI 
-- Game: Elven Legacy: Magic
addappid(42930)
addappid(42931, 1, "49d75d1c12a77bd72b1b0238f93b560d8c1f93e8e91b01a8f171465c47b0fada")
addappid(42932, 1, "6eb59b2f9fdc5b3177804f6989234c90b558e5598159e1776187fc44239869a2")
