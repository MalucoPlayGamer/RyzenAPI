-- Lua provided by RyzenAPI
-- Game: REKKR: Sunken Land

-- MAIN APPLICATION
addappid(1715690)
-- Game: addappid(1715690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715691, 1, "b403ddad9aa1edc51237acafff3fa5e9790b642f6fc0b1c99b0d1126086d3b37")
addappid(1715692, 1, "bdf1c45d423791cc6862eddbfcdbb829a394b79ec1e931e364aeaa995fe0ffbc")
