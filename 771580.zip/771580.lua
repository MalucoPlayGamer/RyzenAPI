-- Lua provided by RyzenAPI
-- Game: Mad World  - Age of Darkness - MMORPG

-- MAIN APPLICATION
addappid(771580)

-- MAIN APP DEPOTS / PACKAGES
addappid(771581, 1, "53363cefd45ea37bf1446b713456ed7a411bb7c02529b44c2540836524762b80")
