-- Lua provided by RyzenAPI
-- Game: Robot King Part I: Rebooted and Ready

-- MAIN APPLICATION
addappid(660340)

-- MAIN APP DEPOTS / PACKAGES
addappid(660341, 1, "0d11a710a831fafb8145d8b88905c22db28ea56016237878b437f958550ce5c8")
