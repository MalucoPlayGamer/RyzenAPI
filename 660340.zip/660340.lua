-- Lua provided by SkyAPI 
-- Game: AppID 660340
addappid(660340)
addappid(660341, 1, "0d11a710a831fafb8145d8b88905c22db28ea56016237878b437f958550ce5c8")
