-- Lua provided by RyzenAPI
-- Game: 965180

-- MAIN APPLICATION
addappid(965180)
-- Game: addappid(965180)

-- MAIN APP DEPOTS / PACKAGES
addappid(965181, 1, "089a7cc45bd43f7cdb7d5ad6da01d6218ee5517f45c7f7f6096414b9a66cbb34")
