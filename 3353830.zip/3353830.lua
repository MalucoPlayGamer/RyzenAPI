-- 3353830's Lua and Manifest Created by Hubcap Manifest
-- LivingBattle
-- Created: June 03, 2026 at 16:52:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 15

-- MAIN APPLICATION
addappid(3353830, 1, "9d7a5b6c8e5cf84be87819bf591b7fdc578cb62cdbc1ac0572abee76d02d306a") -- LivingBattle
-- MAIN APP DEPOTS
addappid(3353831, 1, "d94d4a7751267ad77d8b2eccd72299c2a3dbc464f3428146845f638031f7a092") -- Depot 3353831
setManifestid(3353831, "1860629567454493133", 757265471)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3773110) -- LivingBattle Normal M4A1
addappid(3780190) -- LivingBattle Ambulance
addappid(3782940) -- LivingBattle Guitar
addappid(3788480) -- LivingBattle Modern City
addappid(3795450) -- LivingBattle Wandering Backpacker
addappid(3808510) -- LivingBattle Normal AK47
addappid(3813080) -- LivingBattle Blue Mid Size Car
addappid(3818180) -- LivingBattle Chair
addappid(3820570) -- LivingBattle Simple City
addappid(3872010) -- LivingBattle Motorcycle Rider
addappid(3875450) -- LivingBattle SCAR-H
addappid(3920560) -- LivingBattle Bustop Sign
addappid(3927620) -- LivingBattle Car Muscle
addappid(4036570) -- LivingBattle Rugby Office Worker
addappid(4047700) -- LivingBattle Office Building