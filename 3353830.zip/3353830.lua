-- Lua provided by SkyAPI 
-- Game: LivingBattle
addappid(3353830)
addappid(3353831, 1, "d94d4a7751267ad77d8b2eccd72299c2a3dbc464f3428146845f638031f7a092")
