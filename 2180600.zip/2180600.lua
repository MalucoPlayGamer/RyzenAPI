-- Lua provided by RyzenAPI
-- Game: addappid(2180600)

-- MAIN APPLICATION
addappid(2180600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180602,0,"bc8e45a620e78dd90f21c23a7018fb3490b79a64da78422bb33ec6c8beb610fa")
