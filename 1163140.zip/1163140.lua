-- Lua provided by RyzenAPI
-- Game: addappid(1163140)

-- MAIN APPLICATION
addappid(1163140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163141, 1, "dfc9b91c8e7371e96560ded9ca1a46abd05258a540d9298a0f5b4f4f59529d6d")
