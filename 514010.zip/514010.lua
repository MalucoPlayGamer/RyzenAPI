-- Lua provided by RyzenAPI
-- Game: Game: Football Mogul 15

-- MAIN APPLICATION
addappid(514010)
-- Game: addappid(514010)

-- MAIN APP DEPOTS / PACKAGES
addappid(514011, 1, "c17c9678e5bf31944cbff3583b1f0d15667a0b84c69b64e84b128b9c918ba39d")
