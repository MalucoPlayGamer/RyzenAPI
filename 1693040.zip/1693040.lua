-- Lua provided by SkyAPI 
-- Game: Synthwave Burnout
addappid(1693040)
addappid(1693041, 1, "4be7da259ee2a384e9c65a3288b0aa09c3284b06f6b72678eca40bfc7bda7e2e")
