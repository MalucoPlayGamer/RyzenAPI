-- Lua provided by RyzenAPI
-- Game: addappid(1138490)

-- MAIN APPLICATION
addappid(1138490)
addappid(1138491)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138490,0,"9289a052206c36e66b3a5cae767d2e60a5016a627bf4dce8cc53712745ea0d8f")
