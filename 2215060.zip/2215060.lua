-- Lua provided by RyzenAPI
-- Game: Conquer Humanity

-- MAIN APPLICATION
addappid(2215060)
-- Game: addappid(2215060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215061, 1, "3cf1a30a1757702d6139cfe54531999e602474420313109707d3537e014b2e99")
