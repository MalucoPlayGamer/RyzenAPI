-- Lua provided by RyzenAPI
-- Game: Death's Hangover

-- MAIN APPLICATION
addappid(521920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521921, 1, "17bb7cc662e43a678b76531d1c66dc9417155232619b69e9b7fd7f8d0bec3ecf")

