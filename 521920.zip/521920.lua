-- Lua provided by RyzenAPI
-- Game: addappid(521920)

-- MAIN APPLICATION
addappid(521920)

-- MAIN APP DEPOTS / PACKAGES
addappid(521921, 1, "17bb7cc662e43a678b76531d1c66dc9417155232619b69e9b7fd7f8d0bec3ecf")
