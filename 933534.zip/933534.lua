-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Wei Pack 2

-- MAIN APPLICATION
addappid(933534)
-- Game: addappid(933534)

-- MAIN APP DEPOTS / PACKAGES
addappid(933534,0,"493855e7d7642ae6b59ab55f6cce3845a7af225b044f044b408ab23144ad527c")
