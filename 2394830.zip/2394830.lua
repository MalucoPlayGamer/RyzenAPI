-- Lua provided by RyzenAPI 
-- Game: Snakedate
addappid(2394830)
addappid(2394831, 1, "96efc64e3b3fac0e6abc8bdf656bd94040d63d9f8233195ad7f8cfc49daf06fc")
