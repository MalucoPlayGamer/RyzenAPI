-- Lua provided by RyzenAPI
-- Game: Dead Rising® 2

-- MAIN APPLICATION
addappid(45740)
addappid(228981)

-- MAIN APP DEPOTS / PACKAGES
addappid(45741, 1, "5425412bd84884fae4910b7e8775d60cd2e0b300a945a832abc8c8a4437c1e21")
addappid(45742, 1, "87a1fcfa76a7b5505a7d0f34a13f43bc3fc11e102e7d513875d8a3a97dd1b889")
addappid(353050, 0, "b0950738575d41cf27903212edcbffb8d6d223b26b20a7c4b0a84582c21ea899")
addappid(353051, 0, "75ddcc7d56019fd9f2ed8b1081012b41473b219bdadbdce32b9064516db51fd9")
addappid(353052, 0, "ab9fac0b51b89fe68261ed25cc6f12c73df43e59cb003ca4256d5b9d40fea5f7")
addappid(353053, 0, "b59488b11854f4a2111904de5f308437c9c67fcfbefc842b151da5feea10b182")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
