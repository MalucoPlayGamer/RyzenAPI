-- Lua provided by RyzenAPI
-- Game: Beware of Trains

-- MAIN APPLICATION
addappid(894270)

-- MAIN APP DEPOTS / PACKAGES
addappid(894271, 1, "2f965968678ba9006a185fa02f59bdb194f01f94363ae11ea6c84ee4bb0e7d93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
