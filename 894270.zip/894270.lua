-- Lua provided by RyzenAPI
-- Game: Beware of Trains

-- MAIN APPLICATION
addappid(894270)

-- MAIN APP DEPOTS / PACKAGES
addappid(894271, 1, "2f965968678ba9006a185fa02f59bdb194f01f94363ae11ea6c84ee4bb0e7d93")

