-- Lua provided by RyzenAPI 
-- Game: Scoot
addappid(1494840)
addappid(1494841, 1, "eb14283ecc75934fce88f8dc7b3eeeee8e138990a7befcdcc3b80a618755a353")
