-- Lua provided by RyzenAPI
-- Game: Gym Empire - Idle Gym Tycoon Management

-- MAIN APPLICATION
addappid(756300)

-- MAIN APP DEPOTS / PACKAGES
addappid(756301,0,"72956526986ce8a75dce5e3eac1e2c48a3c9f9f953cedada92e290d2117e4d8d")

