-- Lua provided by RyzenAPI
-- Game: MorphVOX Pro 5 - Voice Changer

-- MAIN APPLICATION
addappid(1529570)
addappid(1535250)
addappid(1535251)
addappid(1535260)
addappid(1535261)
addappid(1535262)
addappid(1535263)
addappid(1535264)
addappid(1535265)
addappid(1535266)
addappid(1535400)
addappid(1535580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1529571, 1, "7644dd8db3fe3d54a8c304c530d7c0bbdd9437c01a87406bf156cd6f5cc95093")
addappid(1529576, 1, "21ffaf16aeb8bfa25ea5b3560718cb8dd88d5eaad6e4c4c8515445e45ca2252e")

