-- Lua provided by RyzenAPI
-- Game: Game: MorphVOX Pro 5 - Voice Changer

-- MAIN APPLICATION
addappid(1529570)
-- Game: addappid(1529570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529571, 1, "7644dd8db3fe3d54a8c304c530d7c0bbdd9437c01a87406bf156cd6f5cc95093")
addappid(1529576, 1, "21ffaf16aeb8bfa25ea5b3560718cb8dd88d5eaad6e4c4c8515445e45ca2252e")
