-- Lua provided by RyzenAPI
-- Game: The Caligula Effect: Overdose

-- MAIN APPLICATION
addappid(889600)
addappid(934200)
addappid(934300)
addappid(934310)
addappid(934320)
addappid(934321)
addappid(934330)
addappid(934331)
addappid(934340)
addappid(934341)
addappid(934350)
addappid(934351)
addappid(934352)
addappid(934353)
addappid(934360)
addappid(934361)
addappid(1039250)

-- MAIN APP DEPOTS / PACKAGES
addappid(889601,0,"e4c8b0e2bd0fcb46537f2a5bf40e348a064eb7e0041643adbcc6b3df22505c15")
addappid(934200,0,"d7e36eb610e9e98bead83dd7ab135165eae43a2fc6cf09178e97a59c4e24eae2")
addappid(934300,0,"a09eed7a69428985ee9ffde0ce9cac18d32a2c7b73fd14184f2d5a92cf9e7dce")

