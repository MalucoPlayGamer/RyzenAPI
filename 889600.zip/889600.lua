-- Lua provided by RyzenAPI
-- Game: 889600

-- MAIN APPLICATION
addappid(889600)
-- Game: addappid(889600)

-- MAIN APP DEPOTS / PACKAGES
addappid(889601, 1, "e4c8b0e2bd0fcb46537f2a5bf40e348a064eb7e0041643adbcc6b3df22505c15")
