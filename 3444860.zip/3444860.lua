-- Lua provided by RyzenAPI
-- Game: 3444860

-- MAIN APPLICATION
addappid(3444860)
-- Game: addappid(3444860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444861, 1, "b743ab735f5a3181a30648527a733addffa7763e8fae9b17782948fd31982d29")
