-- Lua provided by RyzenAPI
-- Game: SUPER WHIPLASH

-- MAIN APPLICATION
addappid(1450190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1450191, 1, "e1d801ba1c9be6eaba9d1cc6177ee844bef05964208b14c115cbb8b51d39f2a4")

