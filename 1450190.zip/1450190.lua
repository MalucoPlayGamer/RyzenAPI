-- Lua provided by RyzenAPI
-- Game: Game: SUPER WHIPLASH

-- MAIN APPLICATION
addappid(1450190)
-- Game: addappid(1450190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450191, 1, "e1d801ba1c9be6eaba9d1cc6177ee844bef05964208b14c115cbb8b51d39f2a4")
