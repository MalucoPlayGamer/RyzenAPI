-- Lua provided by SkyAPI 
-- Game: AppID 1137090
addappid(1137090)
addappid(1137091, 1, "9bb2f46d10aae1aab5cb36732daff66ce494b8e65377c64ce2db72a19b6c639f")
