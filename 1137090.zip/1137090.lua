-- Lua provided by RyzenAPI
-- Game: ROMANCE OF THE THREE KINGDOMS XIV Demo

-- MAIN APPLICATION
addappid(1137090)
-- Game: addappid(1137090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137091, 1, "9bb2f46d10aae1aab5cb36732daff66ce494b8e65377c64ce2db72a19b6c639f")
