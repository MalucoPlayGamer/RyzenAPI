-- Lua provided by RyzenAPI
-- Game: The Quiet Sleep

-- MAIN APPLICATION
addappid(724510)

-- MAIN APP DEPOTS / PACKAGES
addappid(724511,0,"f18cc08f93649edc18be51244e41ef78137f5cd9dc2c18204529492e47d05d07")

