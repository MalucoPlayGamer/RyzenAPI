-- Lua provided by SkyAPI 
-- Game: Nokta
addappid(1606570)
addappid(1606571, 1, "ca948ddf25a6908a9a6b8d419b6aa2f4ad6b5be00dcdef54a99afe80882e1550")
