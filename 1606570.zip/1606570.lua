-- Lua provided by RyzenAPI
-- Game: Nokta

-- MAIN APPLICATION
addappid(1606570)
-- Game: addappid(1606570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606571, 1, "ca948ddf25a6908a9a6b8d419b6aa2f4ad6b5be00dcdef54a99afe80882e1550")
