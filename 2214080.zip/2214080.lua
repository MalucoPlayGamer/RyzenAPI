-- Lua provided by RyzenAPI 
-- Game: Die in the Dungeon: PROLOGUE
addappid(2214080)
addappid(2214081, 1, "4f65dfba67a8cdf1f8cd086eeb8d3a8eb0c4d2fa96d182cb2ff68364de44ac03")
addappid(2214083, 1, "282431498860c1ef105b1f7506a31c09b9f1cc2aa00021f8b3969858239e3f8a")
