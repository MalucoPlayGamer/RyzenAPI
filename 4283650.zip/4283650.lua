-- 4283650's Lua and Manifest Created by Hubcap Manifest
-- Cozy Mining
-- Created: June 27, 2026 at 03:52:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4283650) -- Cozy Mining
-- MAIN APP DEPOTS
addappid(4283651, 1, "6a75dca906dba36c881264814a83dcd4a5a62c8a88d5f3216da8da5a02cd4556") -- Depot 4283651
setManifestid(4283651, "8651750551988424880", 102299811)
addappid(4283652, 1, "e9b13bc7e860b991f3b74cbff47feadad986187080a7c8fdd5448fec2ba6bd48") -- Depot 4283652
setManifestid(4283652, "8743647845244094146", 117218755)