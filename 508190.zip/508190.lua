-- Lua provided by RyzenAPI
-- Game: Game: Dragon Knight

-- MAIN APPLICATION
addappid(508190)
-- Game: addappid(508190)

-- MAIN APP DEPOTS / PACKAGES
addappid(508191, 1, "1166aad3fc9c4ce83480570b468f1ba50687777e675b52390c0f470101ac7765")
addappid(508192, 1, "ddbbd4986a9949f3d2166877b38945250f04d4c6c7f1e7d3b5e94381e3b41e43")
