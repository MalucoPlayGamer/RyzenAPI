-- Lua provided by RyzenAPI
-- Game: WEBFISHING

-- MAIN APPLICATION
addappid(3146520)
-- Game: addappid(3146520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146521, 1, "fbcacb22ed8487248d655f943d8583e6250bc26ae968561e209ef2474ecd7834")
