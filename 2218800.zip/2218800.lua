-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Kinky Bondage

-- MAIN APPLICATION
addappid(2218800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218801, 1, "6c0eddcb7da748c330a184517a1b486e36c40c180dad88bd323520891a78d3d7")
