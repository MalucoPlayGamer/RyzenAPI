-- Lua provided by RyzenAPI
-- Game: Game: Africa Hunting

-- MAIN APPLICATION
addappid(758470)
-- Game: addappid(758470)

-- MAIN APP DEPOTS / PACKAGES
addappid(758471, 1, "8d3649268d17cb787b7d1b4b61d8398f0e7ba88edf22407cfe66d560b25f7b3d")
