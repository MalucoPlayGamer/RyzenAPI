-- Lua provided by SkyAPI 
-- Game: 6-Mon Adventure
addappid(2000310)
addappid(2000311, 1, "f7ff277643975bd3c5e54059a07d7973c47f609603bce7a068b1800a4af3ee64")
