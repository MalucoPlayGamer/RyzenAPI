-- Lua provided by RyzenAPI
-- Game: addappid(2000310)

-- MAIN APPLICATION
addappid(2000310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000311, 1, "f7ff277643975bd3c5e54059a07d7973c47f609603bce7a068b1800a4af3ee64")
