-- Lua provided by RyzenAPI
-- Game: 6-Mon Adventure

-- MAIN APPLICATION
addappid(2000310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2000311, 1, "f7ff277643975bd3c5e54059a07d7973c47f609603bce7a068b1800a4af3ee64")

