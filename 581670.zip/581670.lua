-- Lua provided by RyzenAPI
-- Game: addappid(581670)

-- MAIN APPLICATION
addappid(581670)

-- MAIN APP DEPOTS / PACKAGES
addappid(581671, 1, "1d81630525ac2cc0e89d9f17d4d277907c07bd5ed35d9a95a37dde8a4d0f6ca7")
