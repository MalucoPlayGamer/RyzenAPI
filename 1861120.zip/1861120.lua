-- Lua provided by RyzenAPI
-- Game: Line Time

-- MAIN APPLICATION
addappid(1861120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861121, 1, "682c014edd9456765e72e2b51071dbd99b51f32001ff5fee4ba683695ce9a866")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
