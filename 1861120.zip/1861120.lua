-- Lua provided by RyzenAPI
-- Game: Line Time

-- MAIN APPLICATION
addappid(1861120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861121, 1, "682c014edd9456765e72e2b51071dbd99b51f32001ff5fee4ba683695ce9a866")

