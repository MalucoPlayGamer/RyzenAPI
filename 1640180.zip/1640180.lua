-- Lua provided by RyzenAPI
-- Game: Rebel! Pure love fighters!

-- MAIN APPLICATION
addappid(1640180)
addappid(1666900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640181, 1, "a64fe182e38f8aa910b46fc3a71d7585611239cdff4ebae211942ae9168860f1")
addappid(1640182, 1, "37797a839ebffc9af8c1eac878f6c73e2896b05b538bb88d136aa0979b5baaa2")
addappid(1640183, 1, "fe28299f10754f48919b105f8fd051777fc51f4fa21b64e54f0c2134707b5251")
addappid(1640185, 1, "c5d0bd06bf66a22a517a7b65ae64e0bed024a70e16986834932bf7a4ae9e5e4c")

