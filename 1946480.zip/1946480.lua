-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Nature Pack Vol.1

-- MAIN APPLICATION
addappid(1946480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946480,0,"91c3859672653e211b75bea572644c7724934333f6c1c5fb50a86668be704998")

