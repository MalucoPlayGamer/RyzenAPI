-- Lua provided by RyzenAPI
-- Game: addappid(1967180)

-- MAIN APPLICATION
addappid(1967180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967181, 1, "8c04ebdb1814e3ba1cd5473b2fb0889f73fa57f0a16758bce7446c8313c53fdf")
