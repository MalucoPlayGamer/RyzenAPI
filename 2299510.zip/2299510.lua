-- Lua provided by RyzenAPI
-- Game: Pixel Composer

-- MAIN APPLICATION
addappid(2299510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299511, 1, "780887386de4e3ffa401f46b7a4c5b477a07e48ec2ec3db4f965648a24015397")

