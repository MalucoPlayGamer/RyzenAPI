-- Lua provided by SkyAPI 
-- Game: Modest Kind
addappid(701740)
addappid(701741, 1, "d9592ac4c67d66ee2019b885211bbf02b53e78f8b24d2aab23d2e38a3180ed38")
