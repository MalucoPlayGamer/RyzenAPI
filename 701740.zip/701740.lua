-- Lua provided by RyzenAPI
-- Game: Modest Kind

-- MAIN APPLICATION
addappid(701740)

-- MAIN APP DEPOTS / PACKAGES
addappid(701741, 1, "d9592ac4c67d66ee2019b885211bbf02b53e78f8b24d2aab23d2e38a3180ed38")
