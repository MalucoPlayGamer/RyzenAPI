-- Lua provided by RyzenAPI
-- Game: addappid(2396190)

-- MAIN APPLICATION
addappid(2396190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396191, 1, "144906de4a50849be82d0d0bb664eb6d3a45eb7552476bafae6db83bd584218d")
