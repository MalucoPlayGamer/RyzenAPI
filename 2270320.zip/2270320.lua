-- Lua provided by RyzenAPI
-- Game: My Gym Mommy Treats Me Like A Kid

-- MAIN APPLICATION
addappid(2270320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270321, 1, "0f40f7002da9b86a4f3e788a06228facf933a1a93f79cf11c15ada2409750921")

