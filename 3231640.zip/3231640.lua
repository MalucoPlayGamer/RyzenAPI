-- Lua provided by RyzenAPI
-- Game: Game: AppID 3231640

-- MAIN APPLICATION
addappid(3231640)
-- Game: addappid(3231640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231641, 1, "d44ff1389d2e93ad52216c9716b2e3af458df3efdaa33aaa0249a6500c1d987b")
