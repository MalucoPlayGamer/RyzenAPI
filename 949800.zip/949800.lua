-- Lua provided by RyzenAPI
-- Game: Skyland: Heart of the Mountain

-- MAIN APPLICATION
addappid(949800)

-- MAIN APP DEPOTS / PACKAGES
addappid(949801, 1, "1211190be26de4e2ac8a46f88c7eab7f1149497a67e3d41894dca2cae1be2fe0")
