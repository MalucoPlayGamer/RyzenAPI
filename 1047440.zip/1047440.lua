-- Lua provided by RyzenAPI
-- Game: DATE A LIVE: Rio Reincarnation

-- MAIN APPLICATION
addappid(1047440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047441, 1, "42c300ed85d7618f3fa71ad5ba690b96a67971de91e986d9e920527d400ec700")
addappid(1055670, 0, "8fc5e53493b08c7ffb83539a743a7c012b87566802eb320fc37fc43c7dae751a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
