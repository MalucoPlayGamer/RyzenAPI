-- Lua provided by RyzenAPI
-- Game: Chess Brain

-- MAIN APPLICATION
addappid(1404190)
-- Game: addappid(1404190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404192,0,"818ff53981b552557756edf4970b67a53b28aeac25e6ef5210eec601b1aae70a")
addappid(1404193,0,"a2d6801d78f08f3c1896866748eb6dadbc14cfbec0197df4ecc800a3eb3e8386")
addappid(1404194,0,"81457bfb092f0cd77d9472d2d18b643c0dae080e377f8923311ee95fe8f75ebc")
