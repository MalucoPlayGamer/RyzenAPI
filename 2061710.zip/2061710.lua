-- Lua provided by RyzenAPI
-- Game: DO NOT OPEN

-- MAIN APPLICATION
addappid(2061710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061712,0,"88b7174fd55a09804c86c63081383362abf8ff27e3896e5f6ea8129862c803f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
