-- Lua provided by RyzenAPI
-- Game: addappid(3147870)

-- MAIN APPLICATION
addappid(3147870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147872,0,"4ae9e9c98fc76a41e97e43e330a4ac489614f22e61877838c09fecd6b7384b99")
