-- Lua provided by RyzenAPI
-- Game: Slash It 2

-- MAIN APPLICATION
addappid(583760)
-- Game: addappid(583760)

-- MAIN APP DEPOTS / PACKAGES
addappid(583761, 1, "02c46e33b40e6c08eb5bb91f1982ba12f5f9a7c0d62f5d4e95a770e34612ad6d")
addappid(583762, 1, "1ef3acdc10346dea2f3798e49a2bb9f34d2d19b1dfe2314d7f885581e3ad2e7e")
addappid(583763, 1, "9121102b337a66dc8c2e1f2d1bc52cbf674d0be6899ba2b6c66a640888bfad71")
addappid(583764, 1, "c5b32d13aa4fe8aba5a5e0bad968458a2178f9efcbc83f1ab03c9b06002a5566")
