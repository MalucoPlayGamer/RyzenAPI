-- Lua provided by RyzenAPI
-- Game: Slash It 2

-- MAIN APPLICATION
addappid(583760) -- Slash It 2
addappid(586490)
addappid(588790)
addappid(588830)
addappid(588840)
addappid(590470)
addappid(590480)
addappid(590490)

-- MAIN APP DEPOTS / PACKAGES
addappid(583761, 1, "02c46e33b40e6c08eb5bb91f1982ba12f5f9a7c0d62f5d4e95a770e34612ad6d") -- Slash It 2 Content
addappid(583762, 1, "1ef3acdc10346dea2f3798e49a2bb9f34d2d19b1dfe2314d7f885581e3ad2e7e") -- Slash It 2 Mac
addappid(583763, 1, "9121102b337a66dc8c2e1f2d1bc52cbf674d0be6899ba2b6c66a640888bfad71") -- Slash It 2 lin32
addappid(583764, 1, "c5b32d13aa4fe8aba5a5e0bad968458a2178f9efcbc83f1ab03c9b06002a5566") -- Slash It 2 lin64
addappid(586491, 1, "5aad1ccd4a26df801e6722654d8a84dd82f068851cdfa415ab8047b2080d64ca") -- Slash it 2 - Electronic Music Pack - Slash it 2 - Electronic Music Pack Windows
addappid(586492, 1, "ad54f714f6ab7b98911c5604149658e22d780223e03ff3dba26e1416ee2b1f64") -- Slash it 2 - Electronic Music Pack - Slash it 2 - Electronic Music Pack Mac
addappid(586493, 1, "703ecdeb3595644dbec74b1869074f1e45b758d32fb5036a6c8fcf705828bf94") -- Slash it 2 - Electronic Music Pack - Slash it 2 - Electronic Music Pack Linux32
addappid(586494, 1, "c31d285aa182dd408249b67e0f09b18db535b6258c9e465cc009f3a84340237c") -- Slash it 2 - Electronic Music Pack - Slash it 2 - Electronic Music Pack Linux64
addappid(588793, 1, "05cdbe3b89cc69a6c4133bf51cf2d82a18bce1186dab227df4fcfc7396e2b169") -- Slash it 2 - Russian Edition - Slash it 2 - Russian Edition Windows
addappid(588794, 1, "976cee213a3857594a5636469fc2000cfd71c7b3a18a9b096cfd1cd77e67e836") -- Slash it 2 - Russian Edition - Slash it 2 - Russian Edition Mac
addappid(588795, 1, "7b08b4ca6e934c3ba6a55487289fe5d6ddd0fd7764381f93f412552046632772") -- Slash it 2 - Russian Edition - Slash it 2 - Russian Edition Lin32
addappid(588796, 1, "dd403f3e80c2c987df2f4b7e5600bc8bb6a9582f73121656774a4e28ebbeeb52") -- Slash it 2 - Russian Edition - Slash it 2 - Russian Edition lin64
addappid(588831, 1, "29196e0cb98cbc34fc0dd9fc6340bf1eb915f2f7c78eaca69f574bc9d13d173c") -- Slash it 2 - Chinese Edition Pack - Slash it 2 - Chinese Edition Pack Windows
addappid(588832, 1, "4faa44e4f3586ee1fda2e4f91a28355e49b564f1edfa79aa1b138b8b471e69f1") -- Slash it 2 - Chinese Edition Pack - Slash it 2 - Chinese Edition Pack Mac
addappid(588833, 1, "de02e7a2a74c491eb0f0cec1a74de20d9ef8c52f2be8772aff16ce2ccc36f2c9") -- Slash it 2 - Chinese Edition Pack - Slash it 2 - Chinese Edition Pack Linux32
addappid(588834, 1, "9b5e772d7a46d79daebab4e280667a033230a78241d56ed0c32ac8cad3980f53") -- Slash it 2 - Chinese Edition Pack - Slash it 2 - Chinese Edition Pack Linux64
addappid(588841, 1, "8ab70acd0bdf90ec3eec7c8972ee2ffd9d58d8f27c5491e9e2030190f5c85090") -- Slash it 2 - German Edition Pack - Slash it 2 - German Edition Pack Windows
addappid(588842, 1, "bd6961dfd5008ddbf3b14b59fa93b99ef5132c511b77b9c6271b5e0d81374af4") -- Slash it 2 - German Edition Pack - Slash it 2 - German Edition Pack Mac
addappid(588843, 1, "76d9e553e52578ad65e688a908e76c8615f88d872b372b50133dbd3b931a3e84") -- Slash it 2 - German Edition Pack - Slash it 2 - German Edition Pack Linux32
addappid(588844, 1, "b4dd0aa7232a77bfc851eea388e7d4cadd0612eb51e17709510bde15786f4912") -- Slash it 2 - German Edition Pack - Slash it 2 - German Edition Pack Linux64
addappid(590471, 1, "7a47f54121bf946c91e9ccedeb53af223e695aafd94e50c65796a844ecd24296") -- Slash It 2 - A Himitsu Exclusive Edition - Slash It 2 - A Himitsu Exclusive Edition WIndows
addappid(590472, 1, "838bcf634570457419a8a43911886861e0fed4867524eae4015c3da95fa6e14f") -- Slash It 2 - A Himitsu Exclusive Edition - Slash It 2 - A Himitsu Exclusive Edition Mac
addappid(590473, 1, "ec30af41f27cb032e910d919a1ce71d2f1640265a212e19725804c51fa69c9ce") -- Slash It 2 - A Himitsu Exclusive Edition - Slash It 2 - A Himitsu Exclusive Edition Linux32
addappid(590474, 1, "678d67943a6b068e531b6e0bed109ad6e0d68fae35d53c99417309e5d78c371d") -- Slash It 2 - A Himitsu Exclusive Edition - Slash It 2 - A Himitsu Exclusive Edition Linux64
addappid(590481, 1, "f0c52caaf87bea639b07f2eaecca6c189b3c7cfc0a51e976272aeebeed387516") -- Slash It 2 - Elexive Exclusive Edition - Slash It 2 - Elexive Exclusive Edition Windows
addappid(590482, 1, "8d8a61e0fe25f46b6e891f2ba310c8cdd42edb25413522342bf1ad95e5a6ec25") -- Slash It 2 - Elexive Exclusive Edition - Slash It 2 - Elexive Exclusive Edition Mac
addappid(590483, 1, "3aef02d0814ff798a4178a40a5152f6dfc5e953fb0f5f0245b7c4a1c06967858") -- Slash It 2 - Elexive Exclusive Edition - Slash It 2 - Elexive Exclusive Edition Linux32
addappid(590484, 1, "d8713dcf5b8396dfb4c396b4a58af1e4f81f097c7316334af6a1d8189fe148e5") -- Slash It 2 - Elexive Exclusive Edition - Slash It 2 - Elexive Exclusive Edition Linux64
addappid(590491, 1, "100a8941d5b4c7585d3a95cced48ed07904a3120c37efad121f70464f8eaa7d1") -- Slash It 2 - JanjiMusic Exclusive Edition - Slash It 2 - JanjiMusic Exclusive Edition Windows
addappid(590492, 1, "a9817d2bb502eebbfcb7525805758b90335436193c35db0bf264c54cc382ac82") -- Slash It 2 - JanjiMusic Exclusive Edition - Slash It 2 - JanjiMusic Exclusive Edition Mac
addappid(590493, 1, "9bcbd3ddbfa53ef2ccd28e18ba207d38019b1584e84843161bca9e69ecf0489b") -- Slash It 2 - JanjiMusic Exclusive Edition - Slash It 2 - JanjiMusic Exclusive Edition Linux32
addappid(590494, 1, "a72e16a577f843ed45b464f2eb30da16467595c9faa3e38c3278d92bd070bb12") -- Slash It 2 - JanjiMusic Exclusive Edition - Slash It 2 - JanjiMusic Exclusive Edition Linux64

