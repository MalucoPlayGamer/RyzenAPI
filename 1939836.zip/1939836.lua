-- Lua provided by RyzenAPI
-- Game: 1939836

-- MAIN APPLICATION
addappid(1939836)
-- Game: addappid(1939836)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939836,0,"fe1f51a66e7dd81400bfb9889a1174ead139beba138403e42bddabfcebab3baf")
