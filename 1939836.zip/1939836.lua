-- Lua provided by RyzenAPI
-- Game: Beat Saber - Fall Out Boy - 'This Ain’t A Scene, It’s An Arms Race'

-- MAIN APPLICATION
addappid(1939836)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939836,0,"fe1f51a66e7dd81400bfb9889a1174ead139beba138403e42bddabfcebab3baf")

