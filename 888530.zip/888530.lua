-- Lua provided by RyzenAPI
-- Game: Yaga

-- MAIN APPLICATION
addappid(888530)

-- MAIN APP DEPOTS / PACKAGES
addappid(888531, 1, "d8cb25f7d62ebd121eac03ba78d536d41ee06427f7a7c9f8d2aadb15d0c94b8a")
addappid(1462090, 0, "d81a2a563f968a9b62121324a37d7404a2f17884b02bb6fec6c90f728278fe47")
