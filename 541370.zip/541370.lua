-- Lua provided by RyzenAPI
-- Game: Clickdraw Clicker

-- MAIN APPLICATION
addappid(541370)

-- MAIN APP DEPOTS / PACKAGES
addappid(541371, 1, "ade63f409155a6d165fbd3d12f7a7b77648e3e210b4c61b9388398e0db5ae488")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1338060)
addappid(1338080)
