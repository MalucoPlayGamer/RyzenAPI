-- Lua provided by SkyAPI 
-- Game: Clickdraw Clicker
addappid(541370)
addappid(541371, 1, "ade63f409155a6d165fbd3d12f7a7b77648e3e210b4c61b9388398e0db5ae488")
