-- Lua provided by RyzenAPI
-- Game: Lucid Dream

-- MAIN APPLICATION
addappid(773090)

-- MAIN APP DEPOTS / PACKAGES
addappid(773091,0,"d21bb97d654dcb6fd45b63d695202206ad35af3548280cd08c235bb2c7763eef")

