-- Lua provided by RyzenAPI
-- Game: Game: AppID 3020640

-- MAIN APPLICATION
addappid(3020640)
-- Game: addappid(3020640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020641, 1, "cf521e3ddbd8f305957d77d4e83f64320e4de16152d9657918113462bfcd06d3")
