-- Lua provided by RyzenAPI
-- Game: Bang Bang Barrage Demo

-- MAIN APPLICATION
addappid(3020640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020641, 1, "cf521e3ddbd8f305957d77d4e83f64320e4de16152d9657918113462bfcd06d3")
