-- Lua provided by RyzenAPI
-- Game: DreadHaunt

-- MAIN APPLICATION
addappid(1855580)
addappid(3257830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1855581, 1, "3a5ca0d8018a58703618dfe8e3f2ff4cee5c0f0b5488f0eb0fa9fbda6295bbdb")

