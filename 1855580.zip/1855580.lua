-- Lua provided by RyzenAPI
-- Game: addappid(1855580)

-- MAIN APPLICATION
addappid(1855580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855581, 1, "3a5ca0d8018a58703618dfe8e3f2ff4cee5c0f0b5488f0eb0fa9fbda6295bbdb")
