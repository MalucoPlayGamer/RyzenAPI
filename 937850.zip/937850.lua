-- Lua provided by RyzenAPI
-- Game: 937850

-- MAIN APPLICATION
addappid(937850)
-- Game: addappid(937850)

-- MAIN APP DEPOTS / PACKAGES
addappid(937851, 1, "2e1b82b3a002f5343a896fb1ac1360cce52cf548ed791065d8d6270d00eb46eb")
