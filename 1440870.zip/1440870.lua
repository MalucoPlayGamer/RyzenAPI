-- Lua provided by RyzenAPI
-- Game: Corrupted Hospital : Part1

-- MAIN APPLICATION
addappid(1440870)
-- Game: addappid(1440870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440871, 1, "9243a81f69ac67ee67ae028de833f01daa5e1523fc24faaa9dcebf665eb411b0")
