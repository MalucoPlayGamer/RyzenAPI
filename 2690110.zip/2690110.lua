-- Lua provided by RyzenAPI
-- Game: 2690110

-- MAIN APPLICATION
addappid(2690110)
-- Game: addappid(2690110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690111, 1, "3e36251c46767cee3e8ab920c1abf9e7ee2711b583ad082c2587a5ad216d8faf")
