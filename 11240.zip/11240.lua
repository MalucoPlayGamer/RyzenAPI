-- Lua provided by RyzenAPI
-- Game: Space Trader: Merchant Marine

-- MAIN APPLICATION
addappid(11240)
-- Game: addappid(11240)

-- MAIN APP DEPOTS / PACKAGES
addappid(11241, 1, "9fd882e13e20b669c960208bd85a1f9ed4e38b85ecede0a8a37251254a1613f3")
