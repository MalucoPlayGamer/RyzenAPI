-- Lua provided by RyzenAPI
-- Game: AppID 294250

-- MAIN APPLICATION
addappid(294250)
-- Game: addappid(294250)

-- MAIN APP DEPOTS / PACKAGES
addappid(294251, 1, "8ae506351b53a3faf10501e01d82dcd1e607130456f18722d57b0d848d17a170")
