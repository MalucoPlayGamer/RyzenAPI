-- Lua provided by RyzenAPI
-- Game: Generation Zero®

-- MAIN APPLICATION
addappid(704270)
addappid(974380)
addappid(1062400)
addappid(1062420)
addappid(1099600)
addappid(1103830)
addappid(1157550)
addappid(1173930)
addappid(1252740)
addappid(1301740)
addappid(1450340)
addappid(1580920)
addappid(1610690)
addappid(1610720)
addappid(1771050)
addappid(1850670)
addappid(2009530)
addappid(2144760)
addappid(2144761)
addappid(2200740)
addappid(2334430)
addappid(2473770)
addappid(2591100)
addappid(2689180)
addappid(2955520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(704271, 1, "bec34bd7a4b8b9e13563f62a6dab312a919c164703f0739da3f138a71e64db7c")

