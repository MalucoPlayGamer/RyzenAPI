-- Lua provided by RyzenAPI
-- Game: 704270

-- MAIN APPLICATION
addappid(704270)
-- Game: addappid(704270)

-- MAIN APP DEPOTS / PACKAGES
addappid(704271, 1, "bec34bd7a4b8b9e13563f62a6dab312a919c164703f0739da3f138a71e64db7c")
