-- Lua provided by RyzenAPI
-- Game: 3740040

-- MAIN APPLICATION
addappid(3740040)
-- Game: addappid(3740040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3740041, 1, "1d4cc522f18afb2358f89e283951c7cece150db5bdf6186c8f7e4da9db0df87e")
