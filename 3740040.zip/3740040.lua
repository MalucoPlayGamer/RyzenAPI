-- Lua provided by RyzenAPI 
-- Game: Ostensible
addappid(3740040)
addappid(3740041, 1, "1d4cc522f18afb2358f89e283951c7cece150db5bdf6186c8f7e4da9db0df87e")
