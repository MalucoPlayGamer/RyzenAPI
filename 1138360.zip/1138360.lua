-- Lua provided by RyzenAPI
-- Game: addappid(1138360)

-- MAIN APPLICATION
addappid(1138360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138361, 1, "7c81ca38cdf597cf1418c9c49dfc1b4f5946b3b0bb80e7def598bfa5aa315444")
