-- Lua provided by RyzenAPI 
-- Game: Uniform for Clip maker
addappid(1670220)
addappid(1670221, 1, "4f95d15fbc784f763c4ebe83f299cd3272b0dcabd6896c7b429a09679182cfd0")
