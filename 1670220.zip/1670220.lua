-- Lua provided by RyzenAPI
-- Game: addappid(1670220)

-- MAIN APPLICATION
addappid(1670220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670221, 1, "4f95d15fbc784f763c4ebe83f299cd3272b0dcabd6896c7b429a09679182cfd0")
