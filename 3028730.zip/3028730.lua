-- Lua provided by RyzenAPI
-- Game: 3028730

-- MAIN APPLICATION
addappid(3028730)
-- Game: addappid(3028730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028731, 1, "1390f042c30dc02a36a56078fcaaaf1366c27a1fb3a94e0cd478a200a8700bfc")
