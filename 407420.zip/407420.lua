-- Lua provided by RyzenAPI
-- Game: Gabe Newell Simulator

-- MAIN APPLICATION
addappid(407420)

-- MAIN APP DEPOTS / PACKAGES
addappid(407422,0,"c1c7999a4254db67130a451d782eee509adfd72f199168e36d0dff6435aec0a8")
addappid(407423,0,"ee9aa98b6961e5f05dceea3de564e88000d841227bdac0b27767ae22d162e55a")
addappid(407424,0,"642ebd1cac55c887f946bdcd977eccb13d01d95cd05aa8850859e957ddb5d0a1")
addappid(480580,0,"09ea9c82375f639032757be87fafa698f8f48a24eb5df5e60ac108566ac353e0")

