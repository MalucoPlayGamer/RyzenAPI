-- Lua provided by RyzenAPI
-- Game: addappid(729040)

-- MAIN APPLICATION
addappid(729040)

-- MAIN APP DEPOTS / PACKAGES
addappid(729041, 1, "6bf645f76a001bb548c0f52d99fb5a7f5c7130c9a7ed3d6518318c0bdea77f8d")
