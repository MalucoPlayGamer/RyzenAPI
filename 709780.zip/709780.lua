-- Lua provided by RyzenAPI
-- Game: Crazy Scientist

-- MAIN APPLICATION
addappid(709780)
-- Game: addappid(709780)

-- MAIN APP DEPOTS / PACKAGES
addappid(709781, 1, "9ffe36cbb9340bf876de6d9a51c493f61fadf7063e7fc7da138254ba5111cc2e")
