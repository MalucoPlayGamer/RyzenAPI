-- Lua provided by RyzenAPI
-- Game: Witch Way

-- MAIN APPLICATION
addappid(3034180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034181, 1, "d8f0fd60ce39e755e5fcb486cf10322a8bac5d9c5d05c54dcb36b9ce4f724b8e")

