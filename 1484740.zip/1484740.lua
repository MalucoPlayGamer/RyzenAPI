-- Lua provided by RyzenAPI
-- Game: addappid(1484740)

-- MAIN APPLICATION
addappid(1484740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484741, 1, "19a507b46d5380b4fecb9ff6512ffd6fd6343a46fa958fb4a1f1d3aee7903247")
