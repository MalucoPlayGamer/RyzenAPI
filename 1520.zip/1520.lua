-- Lua provided by SkyAPI 
-- Game: DEFCON
addappid(1520)
addappid(1521, 1, "c3d037dde2d61d13f18390480d788d37b51e6970543e8142cb05d284bec37f0e")
addappid(1523, 1, "251fc988abdc830d11c03c40efa19601b729e6b333463cc21d025d1d1c1a48a4")
addappid(1527, 1, "eda1c9403d5431539e1245cdc6f080b89e539c53d97eaa0fb76f735b418ef036")
