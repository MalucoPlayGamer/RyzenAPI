-- Lua provided by RyzenAPI
-- Game: addappid(1764810)

-- MAIN APPLICATION
addappid(1764810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764811, 1, "30d76371c330fbd6e03359a51e542242754febb9ffb5245fe7b4bfeb781ae6a0")
