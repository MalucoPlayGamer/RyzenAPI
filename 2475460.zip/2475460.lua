-- Lua provided by RyzenAPI
-- Game: SOS OPS!

-- MAIN APPLICATION
addappid(2475460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475461, 1, "35d0fe1da8af85fe194219860e7c34c03d704ef29aecc959c8c1029a906fbbc7")
