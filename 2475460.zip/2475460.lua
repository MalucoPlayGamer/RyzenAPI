-- Lua provided by RyzenAPI
-- Game: SOS OPS!

-- MAIN APPLICATION
addappid(2475460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475461, 1, "35d0fe1da8af85fe194219860e7c34c03d704ef29aecc959c8c1029a906fbbc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2902230)
addappid(3086710)
addappid(4312180)
addappid(4446280)
addappid(4855980)
