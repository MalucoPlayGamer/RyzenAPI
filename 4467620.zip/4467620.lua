-- Lua provided by RyzenAPI
-- Game: The Pirate: Republic of Nassau

-- MAIN APPLICATION
addappid(4467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4467621,0,"39114f1ae8afa4d7dd6c8b51800ca64ff33e6c2d4516d33dc98dfd0668ab23b1")

