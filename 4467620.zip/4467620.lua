-- Lua provided by RyzenAPI
-- Game: The Pirate: Republic of Nassau

-- MAIN APPLICATION
addappid(4467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4467621,0,"39114f1ae8afa4d7dd6c8b51800ca64ff33e6c2d4516d33dc98dfd0668ab23b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
