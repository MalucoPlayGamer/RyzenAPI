-- Lua provided by RyzenAPI
-- Game: Fintube

-- MAIN APPLICATION
addappid(2610990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610991, 1, "9927aeed54768a2aef19a35cb3dcf25da92dbc6d56d391ac7828de0af51975e3")
