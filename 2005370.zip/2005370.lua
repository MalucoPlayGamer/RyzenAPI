-- Lua provided by RyzenAPI
-- Game: 2005370

-- MAIN APPLICATION
addappid(2005370)
-- Game: addappid(2005370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005371, 1, "4e9e4a38effd8e19468995722367c4e3b1c1aff67f81c198bc90e7668002112d")
