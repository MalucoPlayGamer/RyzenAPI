-- Lua provided by RyzenAPI
-- Game: 2986260

-- MAIN APPLICATION
addappid(2986260)
-- Game: addappid(2986260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986261, 1, "446ed15ab2cdaa4d73ba54453a09f6b9aef798107b33e5ba94d483cf208c797e")
addappid(2986262, 1, "3f7fdb2d0ba1061c20ccf6c285405f1ecc0579bab8ac95213e2e66da2f8584e2")
addappid(2986263, 1, "d23bcf75695d713847e34ed80fffc7edeb2430369f8ca4a7e22887003d29d64b")
