-- Lua provided by RyzenAPI
-- Game: addappid(1638750)

-- MAIN APPLICATION
addappid(1638750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638750,0,"e51e419e20816dacb3b065e6ea6223e40ca2d4b03aa2b28f21f4a71b2d45acc4")
