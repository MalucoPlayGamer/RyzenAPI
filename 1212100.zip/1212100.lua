-- Lua provided by RyzenAPI
-- Game: AppID 1212100

-- MAIN APPLICATION
addappid(1212100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1212101, 1, "d6aa342c8605fc251a59f4d30370593fc4c4e3610e2f75754b891833e308912c")
addappid(1212102, 1, "50ccdd04bb9eacd93c966a4bdf03f6aff452ce6bd7fa3d4af3ddd3a6e80df8e3")

