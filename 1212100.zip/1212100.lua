-- Lua provided by RyzenAPI
-- Game: Game: AppID 1212100

-- MAIN APPLICATION
addappid(1212100)
-- Game: addappid(1212100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212101, 1, "d6aa342c8605fc251a59f4d30370593fc4c4e3610e2f75754b891833e308912c")
addappid(1212102, 1, "50ccdd04bb9eacd93c966a4bdf03f6aff452ce6bd7fa3d4af3ddd3a6e80df8e3")
