-- Lua provided by RyzenAPI
-- Game: Primordialis Demo

-- MAIN APPLICATION
addappid(3267910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267911, 1, "9eae691e5bfa388f428774f7ff16c12f8afb99c9e83f89daa5c0a84a669e5420")
