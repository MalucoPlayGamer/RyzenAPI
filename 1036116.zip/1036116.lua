-- Lua provided by RyzenAPI
-- Game: Dusk Diver-Welcome Summer! swimsuits PACK

-- MAIN APPLICATION
addappid(1036116)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036116,0,"5329c1bd21838abf22c54f013bcfe74a0fb9acc1ce05b4babefc5ccadbcb39ba")

