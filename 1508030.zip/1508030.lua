-- Lua provided by RyzenAPI
-- Game: Object N

-- MAIN APPLICATION
addappid(1508030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508031, 1, "c86864000b986ff74069e89884c1859f662528ec8340d69f4ef67abfc6f3e5c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
