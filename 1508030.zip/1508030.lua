-- Lua provided by RyzenAPI
-- Game: Game: Object N

-- MAIN APPLICATION
addappid(1508030)
-- Game: addappid(1508030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508031, 1, "c86864000b986ff74069e89884c1859f662528ec8340d69f4ef67abfc6f3e5c9")
