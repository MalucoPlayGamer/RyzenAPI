-- Lua provided by RyzenAPI
-- Game: addappid(3582790)

-- MAIN APPLICATION
addappid(3582790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582791, 1, "8550299231c7a5605434273cbdab661014b9352dec5cb3f8c3fda0730b18d2fb")
