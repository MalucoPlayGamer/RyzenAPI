-- Lua provided by RyzenAPI
-- Game: 2857980

-- MAIN APPLICATION
addappid(2857980)
-- Game: addappid(2857980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857981, 1, "4fdafd1e1a8472937c7f2a7a4958af5322af796df78c0f681e83cbfc471b6178")
