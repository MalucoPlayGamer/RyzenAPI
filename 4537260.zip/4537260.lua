-- Generated with Luie @ https://lua.tools/
-- 4537260 - Hentai Clicker: Yuki is streaming
-- Generated 2026-08-15 01:08:11 UTC
-- # Depots (Total/DLC/Shared): 3/0/0

-- Main AppID
addappid(4537260)

-- Main Depots
addappid(4537261, 1, "9086fd1545d9ad53d2c370b75a0d376e36a3c42ade5ff836f314eadda4d7afcb") -- (windows)
setManifestid(4537261, "3077184887140658549", 156221845)

-- Missing Depots (We don't have the keys yet lol): 4537262, 4537263
