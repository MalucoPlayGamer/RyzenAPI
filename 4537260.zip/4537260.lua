-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Yuki is streaming

-- MAIN APPLICATION
addappid(4537260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4537261, 1, "9086fd1545d9ad53d2c370b75a0d376e36a3c42ade5ff836f314eadda4d7afcb") -- (windows)

