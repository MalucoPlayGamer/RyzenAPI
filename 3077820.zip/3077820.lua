-- Lua provided by RyzenAPI
-- Game: Heretical Demo

-- MAIN APPLICATION
addappid(3077820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077821, 1, "ebae0af01753a4ee1432181b964461e8bedf31052da909c028ec40d167821287")
