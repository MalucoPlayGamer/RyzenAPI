-- Lua provided by RyzenAPI 
-- Game: AppID 3077820
addappid(3077820)
addappid(3077821, 1, "ebae0af01753a4ee1432181b964461e8bedf31052da909c028ec40d167821287")
