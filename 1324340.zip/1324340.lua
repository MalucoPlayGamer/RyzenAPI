-- Lua provided by RyzenAPI
-- Game: addappid(1324340)

-- MAIN APPLICATION
addappid(1324340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324341, 1, "9eaf4b7ea8830e817a0347e7d9579f940c5368a0759b9f2ecdf4443466eada7e")
