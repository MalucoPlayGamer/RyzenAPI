-- Lua provided by RyzenAPI
-- Game: My Land!

-- MAIN APPLICATION
addappid(2203490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203491, 1, "4f70ffbf2a06ae2f1f2a5ae21d6845406f98788a99cc2e4b4b8c6103b755bca2")
