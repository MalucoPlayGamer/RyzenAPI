-- Lua provided by RyzenAPI
-- Game: My Furry Dictator 🐾

-- MAIN APPLICATION
addappid(1719460)
addappid(1743840)
-- Game: addappid(1719460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719461, 1, "083f672d5625251666cda299c79db0d2231f785758d7aa588ea2dd8e7ff09060")
addappid(1719462, 1, "84828433813df3b1583d66964a4aba929bbc95753e16c20c7129422f96b07257")
