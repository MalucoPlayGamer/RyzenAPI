-- Lua provided by RyzenAPI
-- Game: 1061400

-- MAIN APPLICATION
addappid(1061400)
-- Game: addappid(1061400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061401, 1, "2c24ade27ee28d785fd7d212aab2bcc8ada7f6051aa90173cbc0d1521fd2cdd4")
