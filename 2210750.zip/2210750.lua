-- Lua provided by RyzenAPI
-- Game: VR Dinosaur Hunter

-- MAIN APPLICATION
addappid(2210750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210751, 1, "b879cb0140589c0fcd0fb52e0eb500cc45cca358fd5a4381d72514b21775bade")
