-- Lua provided by RyzenAPI
-- Game: 好想躺平啊，但是 Playtest

-- MAIN APPLICATION
addappid(3296880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296881, 1, "9cfe911d55724f9d92e366a0d18ef2d327ecf928d80674013cc39d607781d2be")
