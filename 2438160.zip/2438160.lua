-- Lua provided by RyzenAPI
-- Game: World War Armies

-- MAIN APPLICATION
addappid(2438160)
addappid(2826470)
addappid(2826480)
addappid(2826490)
addappid(2936560)
addappid(2936570)
addappid(2936580)
addappid(3165270)
addappid(3381000)
addappid(3687220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2438161, 1, "9bbe74ebfcb59f9ceb1838b59527be8b8ebcec60e8ba6461a1dcd752784b5b06")
addappid(2438162, 1, "60bf93d22518466f2c8e18e3cd7e0e371ca5ffeaa2e095d28de96575cd855709")

