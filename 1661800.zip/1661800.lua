-- Lua provided by SkyAPI 
-- Game: Dash Dash Delivery
addappid(1661800)
addappid(1661801, 1, "5261143652679ef76e38cb173f96735441929407545a1ee487edc7e834120898")
