-- Lua provided by RyzenAPI
-- Game: Dash Dash Delivery

-- MAIN APPLICATION
addappid(1661800)
-- Game: addappid(1661800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661801, 1, "5261143652679ef76e38cb173f96735441929407545a1ee487edc7e834120898")
