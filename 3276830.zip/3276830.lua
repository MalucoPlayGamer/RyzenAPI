-- Lua provided by RyzenAPI 
-- Game: Mouthwashing Soundtrack
addappid(3276830)
addappid(3276831, 1, "5396b32f5f3d5f995606ef3542c509adb1b53749d3dd83becbcc80f8b9bd26ca")
addappid(3276832, 1, "1861450a449f1c0b6524b121012380fa3d1eb8da5e90944c9a57cc02751e6860")
