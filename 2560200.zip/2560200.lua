-- Lua provided by RyzenAPI
-- Game: Gym Management Simulator Demo

-- MAIN APPLICATION
addappid(2560200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560201, 1, "1fecc290f0a730d2069c046b97912316ebf6f897714ac518a5e35a5352327fd0")

