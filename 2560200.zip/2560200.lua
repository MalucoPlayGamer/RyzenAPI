-- Lua provided by SkyAPI 
-- Game: AppID 2560200
addappid(2560200)
addappid(2560201, 1, "1fecc290f0a730d2069c046b97912316ebf6f897714ac518a5e35a5352327fd0")
