-- Lua provided by RyzenAPI
-- Game: ZooKeeper

-- MAIN APPLICATION
addappid(1027810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027811, 1, "f5610bf97997ea77faecd6a634bcacee36798493d2ad23310f78a9f1050a649c")
