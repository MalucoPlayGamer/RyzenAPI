-- Lua provided by RyzenAPI
-- Game: Qwerty Quest

-- MAIN APPLICATION
addappid(2211570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211571, 1, "ed0c338c007a3cc885a72b2a816a221ece2615c47ce0ecda44b88a2eb4e9b43b")
