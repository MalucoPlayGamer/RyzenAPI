-- Lua provided by RyzenAPI
-- Game: Sorry We're Closed

-- MAIN APPLICATION
addappid(1796580)
addappid(4236260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796581, 1, "45fad82572fb613085919dbc9a542d60221d038570a535a0ba087dea89e98c40")

