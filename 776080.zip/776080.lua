-- Lua provided by RyzenAPI
-- Game: Game: AppID 776080

-- MAIN APPLICATION
addappid(776080)
-- Game: addappid(776080)

-- MAIN APP DEPOTS / PACKAGES
addappid(776081, 1, "ba2ebccbd2ab26fa0b0e659f691e6d52d5d476617831e8b6224d06ba6a3d787d")
