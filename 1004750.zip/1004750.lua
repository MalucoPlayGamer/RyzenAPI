-- Lua provided by RyzenAPI
-- Game: AppID 1004750

-- MAIN APPLICATION
addappid(1004750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004751, 1, "1634a0db5e059e9e0eb5c72533baa526a769d66fda7602f5c7cb893adf3ef935")

