-- 1004750's Lua and Manifest Created by Hubcap Manifest
-- WRC 8 FIA World Rally Championship
-- Created: October 01, 2025 at 08:14:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 5
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(1004750) -- WRC 8 FIA World Rally Championship
-- MAIN APP DEPOTS
addappid(1004751, 1, "1634a0db5e059e9e0eb5c72533baa526a769d66fda7602f5c7cb893adf3ef935") -- WRC 8 FIA World Rally Championship Content
setManifestid(1004751, "1343133403813617173", 21576771183)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1101810) -- WRC 8 - RWD Legends						
addappid(1101830) -- WRC 8 - Alpine A110 (1973)
addappid(1101870) -- WRC 8 - Ford Escort MkII 1800 (1979)
addappid(1101880) -- WRC 8 - Lancia Delta HF Integrale Evoluzione (1992)
addappid(1101890) -- WRC 8 - Senior Staff Members Unlock