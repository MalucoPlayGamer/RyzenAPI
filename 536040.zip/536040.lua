-- Lua provided by RyzenAPI
-- Game: AppID 536040

-- MAIN APPLICATION
addappid(536040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(536041, 1, "9dc7b0c71a8a9557fd972577682adf9adc5929fa55aa4c634ad039942f4220cb")
addappid(536042, 1, "138984c3afa77ad33fdf49b904883fb991f0032c11a89378ecf0b8e6fa1d229e")
addappid(536043, 1, "4e5c701b211cbeeb2d23fab3f453c3f099369d8e777ca36c8736bba8bd11cecf")
addappid(536044, 1, "f23b157601259ca603a5af06c768354fc53ef8992fc0f14e58ddbe66a35f422e")

