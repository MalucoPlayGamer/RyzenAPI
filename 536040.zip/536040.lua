-- Lua provided by RyzenAPI
-- Game: AppID 536040

-- MAIN APPLICATION
addappid(536040)
-- Game: addappid(536040)

-- MAIN APP DEPOTS / PACKAGES
addappid(536041, 1, "9dc7b0c71a8a9557fd972577682adf9adc5929fa55aa4c634ad039942f4220cb")
addappid(536042, 1, "138984c3afa77ad33fdf49b904883fb991f0032c11a89378ecf0b8e6fa1d229e")
addappid(536043, 1, "4e5c701b211cbeeb2d23fab3f453c3f099369d8e777ca36c8736bba8bd11cecf")
addappid(536044, 1, "f23b157601259ca603a5af06c768354fc53ef8992fc0f14e58ddbe66a35f422e")
