-- Lua provided by RyzenAPI 
-- Game: AppID 900250
addappid(900250)
addappid(900251, 1, "8d58f2df6aa1c071e7beae37bde815a6203a7a0f847fcc74bdaefa3c67418751")
