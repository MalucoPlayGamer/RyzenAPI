-- Lua provided by RyzenAPI
-- Game: Game: AppID 900250

-- MAIN APPLICATION
addappid(900250)
-- Game: addappid(900250)

-- MAIN APP DEPOTS / PACKAGES
addappid(900251, 1, "8d58f2df6aa1c071e7beae37bde815a6203a7a0f847fcc74bdaefa3c67418751")
