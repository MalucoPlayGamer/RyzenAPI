-- Lua provided by RyzenAPI
-- Game: Raiden III x MIKADO MANIAX - Soundtrack Sampler

-- MAIN APPLICATION
addappid(2366840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366840,0,"1f6845e98c9db59034c34e9c687b25eb74fae502ceb7e16051e41cef1f929955")
