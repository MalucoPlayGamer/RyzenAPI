-- Lua provided by RyzenAPI 
-- Game: AppID 1479470
addappid(1479470)
addappid(1479471, 1, "b8420af08b3850e47b7651a035c68536308e8ef338950293b6f58147d92dc501")
