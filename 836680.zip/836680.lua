-- Lua provided by RyzenAPI
-- Game: addappid(836680)

-- MAIN APPLICATION
addappid(836680)

-- MAIN APP DEPOTS / PACKAGES
addappid(836685,0,"3f99e3a15a13d59109c76490684ca43ad9c01e5bfc80fa1989e3ffb845c0bc35")
