-- Lua provided by RyzenAPI
-- Game: addappid(534930)

-- MAIN APPLICATION
addappid(534930)

-- MAIN APP DEPOTS / PACKAGES
addappid(534930,0,"a772d275d17b9174a85cb507302bfd5df48f570ef10c2b0bc97929efead7b89d")
addappid(2418960,0,"77ad1a08816fb24aa5f1fd763c82ef827af3b0a33078ff8d8b3fc8f1762ddaca")
