-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Demon Lord Army Set 2

-- MAIN APPLICATION
addappid(3180950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180950,0,"510d4ab2138e86e9b881fe1f69386102b614ac5779e8706aab08e3ba6bace900")

