-- Lua provided by RyzenAPI
-- Game: addappid(16500)

-- MAIN APPLICATION
addappid(16500)

-- MAIN APP DEPOTS / PACKAGES
addappid(16501, 1, "db69065ea42ed3b2992595168590f564fa975afec28696e79e4325e2307aa551")
