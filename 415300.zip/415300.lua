-- Lua provided by RyzenAPI
-- Game: Monster Monpiece

-- MAIN APPLICATION
addappid(415300)

-- MAIN APP DEPOTS / PACKAGES
addappid(415301, 1, "67f353db9c971fb154df00436335b3df231ec1052d4be1bd171faff95afb31a4")
addappid(586010, 0, "e074cfb31bcc27d3fbab68ff96711d31c9085878df88ec8d418d6e70f389e439")

