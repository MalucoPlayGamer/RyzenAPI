-- Lua provided by RyzenAPI
-- Game: Monster Monpiece

-- MAIN APPLICATION
addappid(415300)

-- MAIN APP DEPOTS / PACKAGES
addappid(415301, 1, "67f353db9c971fb154df00436335b3df231ec1052d4be1bd171faff95afb31a4")
addappid(586010, 0, "e074cfb31bcc27d3fbab68ff96711d31c9085878df88ec8d418d6e70f389e439")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
