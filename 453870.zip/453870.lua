-- Lua provided by RyzenAPI
-- Game: Game: AppID 453870

-- MAIN APPLICATION
addappid(453870)
-- Game: addappid(453870)

-- MAIN APP DEPOTS / PACKAGES
addappid(453871, 1, "2f17eb78bd1bd14ed05bec3f0e32ff72f914dae721fec0256eab5e04d144a96d")
