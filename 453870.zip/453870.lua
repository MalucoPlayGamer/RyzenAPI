-- Lua provided by RyzenAPI
-- Game: Quantum Chess

-- MAIN APPLICATION
addappid(453870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(453871, 1, "2f17eb78bd1bd14ed05bec3f0e32ff72f914dae721fec0256eab5e04d144a96d")
