-- Lua provided by RyzenAPI
-- Game: AppID 791430

-- MAIN APPLICATION
addappid(791430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(791431, 1, "6fbaaeb497c947bec16c92f49c51ced5744ed1790256776eacaa1495a57f8ca0")

