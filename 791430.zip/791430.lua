-- Lua provided by RyzenAPI
-- Game: addappid(791430)

-- MAIN APPLICATION
addappid(791430)

-- MAIN APP DEPOTS / PACKAGES
addappid(791431, 1, "6fbaaeb497c947bec16c92f49c51ced5744ed1790256776eacaa1495a57f8ca0")
