-- Lua provided by RyzenAPI
-- Game: Rock of Ages 2: Bigger & Boulder™

-- MAIN APPLICATION
addappid(434460)
addappid(645970)
addappid(700900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(434461, 1, "3a02fbf8f2b8f47ee3ba37a0e4fa6e8f4b9e794dd2d95abd4cbf41c71c5721cd")
addappid(434462, 1, "ff41ed9ac0228ce19c30fc6ae2aa20cdb4dc3bbc185c510910fdb5ee01227e64")
addappid(434463, 1, "f77c2bb98646e339a89a460e92088ca71a430d3bb7478951b27905181a2bae5c")

