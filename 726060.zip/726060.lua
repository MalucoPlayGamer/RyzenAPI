-- Lua provided by RyzenAPI
-- Game: Game: AppID 726060

-- MAIN APPLICATION
addappid(726060)
-- Game: addappid(726060)

-- MAIN APP DEPOTS / PACKAGES
addappid(726061, 1, "dbdcb92b40526504517a0c907e8644d268a8089d0e786aea7909391e55254712")
