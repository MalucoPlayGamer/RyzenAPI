-- Lua provided by RyzenAPI 
-- Game: AppID 2602560
addappid(2602560)
addappid(2602561, 1, "4645f4aa16b74132540655a33cfd2f76463b795830b6349a5d1106f05c9bb43e")
