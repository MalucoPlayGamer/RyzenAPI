-- Lua provided by RyzenAPI
-- Game: DØM RUSALOK

-- MAIN APPLICATION
addappid(1281420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1281421, 1, "6a6d8afee68ac65d6ea4c9556b131182b341828e2171f06aa6b17dfa629431a0")
addappid(1281422, 1, "510842879644bf077bbe84bba0cab98146a2884c7881a8c94aa86c196b6caf11")
