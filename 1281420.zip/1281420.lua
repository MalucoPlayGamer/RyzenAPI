-- Lua provided by SkyAPI 
-- Game: AppID 1281420
addappid(1281420)
addappid(1281421, 1, "6a6d8afee68ac65d6ea4c9556b131182b341828e2171f06aa6b17dfa629431a0")
addappid(1281422, 1, "510842879644bf077bbe84bba0cab98146a2884c7881a8c94aa86c196b6caf11")
