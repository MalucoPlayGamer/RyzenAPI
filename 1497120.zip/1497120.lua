-- Lua provided by RyzenAPI
-- Game: Game: Movavi Screen Recorder

-- MAIN APPLICATION
addappid(1497120)
-- Game: addappid(1497120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497121, 1, "c33de210b01718d3f0ff7dd48ac74abbafb9619bf09d96ca373e123bdc249848")
