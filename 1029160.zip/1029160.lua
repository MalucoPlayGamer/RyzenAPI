-- Lua provided by RyzenAPI
-- Game: addappid(1029160)

-- MAIN APPLICATION
addappid(1029160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029161, 1, "265f2b1ee1cf8bb8a9dc5dad2b6bd353be87c5c03f146a8d0e1db590eaf45384")
