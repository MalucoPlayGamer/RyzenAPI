-- Lua provided by RyzenAPI
-- Game: Sunset Planet

-- MAIN APPLICATION
addappid(1029160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1029161, 1, "265f2b1ee1cf8bb8a9dc5dad2b6bd353be87c5c03f146a8d0e1db590eaf45384")

