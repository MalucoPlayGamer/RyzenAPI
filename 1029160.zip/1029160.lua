-- Lua provided by SkyAPI 
-- Game: Sunset Planet
addappid(1029160)
addappid(1029161, 1, "265f2b1ee1cf8bb8a9dc5dad2b6bd353be87c5c03f146a8d0e1db590eaf45384")
