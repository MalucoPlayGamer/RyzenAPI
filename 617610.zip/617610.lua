-- Lua provided by RyzenAPI
-- Game: 617610

-- MAIN APPLICATION
addappid(617610)
addappid(617611)
addappid(617612)

-- MAIN APP DEPOTS / PACKAGES
addappid(617613,0,"68eb17d2af67bf73efa9abd8b1192806fedede6691d2860b9e3af494b90b4809")
addappid(617614,0,"40e34b0b22ed53d9f2a1e7972216477758f076e014f16fac8ffe0dc04721e35b")
