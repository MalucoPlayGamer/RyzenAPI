-- Lua provided by RyzenAPI
-- Game: AppID 995980

-- MAIN APPLICATION
addappid(995980)
-- Game: addappid(995980)

-- MAIN APP DEPOTS / PACKAGES
addappid(995981, 1, "15c289a6616f8f4645786130d201975ed02eb288f0cc069aa4ef872e9c0f4650")
