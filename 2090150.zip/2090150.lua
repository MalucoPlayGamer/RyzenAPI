-- Lua provided by RyzenAPI
-- Game: Furry Sex: Poker 🃏♥️

-- MAIN APPLICATION
addappid(2090150)
-- Game: addappid(2090150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090151, 1, "4e61c24a9110bae634bca3f2f81be4e728c301ded56c226bf0ccd5b6b7e9420f")
