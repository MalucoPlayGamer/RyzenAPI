-- Lua provided by SkyAPI 
-- Game: Unknown Rules
addappid(2909140)
addappid(2909141, 1, "9a020b57261bfa6931f9c44953e257b83b76fc419f80dbe44233d6ecbfb50741")
