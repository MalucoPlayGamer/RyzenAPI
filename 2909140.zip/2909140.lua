-- Lua provided by RyzenAPI
-- Game: 2909140

-- MAIN APPLICATION
addappid(2909140)
-- Game: addappid(2909140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909141, 1, "9a020b57261bfa6931f9c44953e257b83b76fc419f80dbe44233d6ecbfb50741")
