-- Lua provided by RyzenAPI
-- Game: Through The Unknown

-- MAIN APPLICATION
addappid(1183210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183211, 1, "5fac3c9fac1ba6c753889a76e3721bf647f8dcf37fc79d06f50168797cf851d2")

