-- Lua provided by RyzenAPI
-- Game: Wiki's Wild Ride

-- MAIN APPLICATION
addappid(2526610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526611, 1, "8164dcb52a1c7bd9cae3065648213118e3ca286506f431e52d68d68a21c91b4e")
