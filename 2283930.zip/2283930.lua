-- Lua provided by SkyAPI 
-- Game: Hentai EroCum
addappid(2283930)
addappid(2283931, 1, "dc4cce942b4a7b5c31a391ebcf285a5962b11d61c1ddb65e02698d06307a39a7")
