-- Lua provided by RyzenAPI 
-- Game: Lila's Synthetic Shadows
addappid(2411890)
addappid(2411891, 1, "fe8f3f9f3b4a2de499647fa5d009d8abcab7f3f8bbf02f671e15d89c70a8f812")
