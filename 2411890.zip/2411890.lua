-- Lua provided by RyzenAPI
-- Game: 2411890

-- MAIN APPLICATION
addappid(2411890)
-- Game: addappid(2411890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411891, 1, "fe8f3f9f3b4a2de499647fa5d009d8abcab7f3f8bbf02f671e15d89c70a8f812")
