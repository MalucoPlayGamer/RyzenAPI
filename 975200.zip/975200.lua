-- Lua provided by SkyAPI 
-- Game: AppID 975200
addappid(975200)
addappid(975201, 1, "5164f3ac8675137ec0f04ab72f10eab9c14bec6d0da991665b5f325d170fb6d4")
