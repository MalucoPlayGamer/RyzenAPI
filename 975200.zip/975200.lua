-- Lua provided by RyzenAPI
-- Game: AppID 975200

-- MAIN APPLICATION
addappid(975200)
-- Game: addappid(975200)

-- MAIN APP DEPOTS / PACKAGES
addappid(975201, 1, "5164f3ac8675137ec0f04ab72f10eab9c14bec6d0da991665b5f325d170fb6d4")
