-- Lua provided by RyzenAPI
-- Game: Spark the Electric Jester 3

-- MAIN APPLICATION
addappid(1629530)
-- Game: addappid(1629530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629531, 1, "711ebef50643ce151eb6fa57a0d5c8f9ddf306134d76301196ac3be8c4900157")
