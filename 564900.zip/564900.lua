-- Lua provided by RyzenAPI
-- Game: Space Hotel

-- MAIN APPLICATION
addappid(564900)

-- MAIN APP DEPOTS / PACKAGES
addappid(564901,0,"0c407f22d39529209d1d118068d4145a07c925cff44f6e1d7920f155844ff7fc")

