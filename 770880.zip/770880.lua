-- Lua provided by RyzenAPI
-- Game: Love Story: The Beach Cottage

-- MAIN APPLICATION
addappid(770880)

-- MAIN APP DEPOTS / PACKAGES
addappid(770881,0,"a0b15e9099e89069025db22f53a6f7033c8218b757d2c2b0134f5733602bfe87")

