-- Lua provided by RyzenAPI
-- Game: CreepWars TD

-- MAIN APPLICATION
addappid(1345120)
-- Game: addappid(1345120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345121, 1, "13fe68c0655ab0d90842f712e1f926b95f20ca69dff3b57dc1f2a3f96694313e")
