-- Lua provided by RyzenAPI
-- Game: Legacy of Kain™ Soul Reaver 1&2 Remastered

-- MAIN APPLICATION
addappid(2521380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521381, 1, "2587966585ac710c4512d39adb6aca7694ca672aedc3a168ce3c3845f3a03722")

