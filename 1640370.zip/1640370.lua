-- Lua provided by RyzenAPI
-- Game: addappid(1640370)

-- MAIN APPLICATION
addappid(1640370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640371, 1, "7646d0d0cc604b84f5d4ed4d5948d3c496a5ae1f53abb5e0693c0e25ca78e8bc")
