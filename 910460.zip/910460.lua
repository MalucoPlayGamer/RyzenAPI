-- Lua provided by RyzenAPI
-- Game: Game: AppID 910460

-- MAIN APPLICATION
addappid(910460)
-- Game: addappid(910460)

-- MAIN APP DEPOTS / PACKAGES
addappid(910461, 1, "450ab7c33ff23afdc255b63cbb3d77ac38fe410aa1f434e293f59523113a5def")
addappid(910462, 1, "21433627cf7e5b1cc16b2fa2c5cc1d8529f0fae6bccc56b8f3d6e0adf63bb4c9")
addappid(910463, 1, "bac05ab5c409bc0a85e0f305efff09ee4dae82470f342f1ab9d9759ab973a5e2")
