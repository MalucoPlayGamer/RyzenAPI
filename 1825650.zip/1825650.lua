-- Lua provided by RyzenAPI
-- Game: Human Apocalypse: Prologue

-- MAIN APPLICATION
addappid(1825650)
-- Game: addappid(1825650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825651, 1, "d5199298231a936acc8a0fa7e23eadb598e2367b57363df90c9d583736f12528")
addappid(1825652, 1, "5fd86325d87259bb752c93da94d278e2d16fee6cea9f19500683794eac585e83")
addappid(1825653, 1, "08d95479e4c2f85c03217545ed8c3e9698fa74e04ec419390b6e63c1ff0d0ae3")
