-- Lua provided by RyzenAPI
-- Game: Heavy Rain

-- MAIN APPLICATION
addappid(960910)

-- MAIN APP DEPOTS / PACKAGES
addappid(960911, 1, "57fe2fc09eab86ac6d503e89fc037645053df15f387ab695fcb04411d8ea5593")
addappid(960912, 1, "98995c508adefd7850bd76950fb941e5eacdf0075eef458659aaf622542a778b")
addappid(960913, 1, "81af1bd341d0823d04d9f818fcc3816ee5c3bfaede466e9d451ff467d4426598")
