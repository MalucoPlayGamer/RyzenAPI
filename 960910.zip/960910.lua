-- Lua provided by RyzenAPI
-- Game: Heavy Rain

-- MAIN APPLICATION
addappid(960910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(960911, 1, "57fe2fc09eab86ac6d503e89fc037645053df15f387ab695fcb04411d8ea5593")
addappid(960912, 1, "98995c508adefd7850bd76950fb941e5eacdf0075eef458659aaf622542a778b")
addappid(960913, 1, "81af1bd341d0823d04d9f818fcc3816ee5c3bfaede466e9d451ff467d4426598")

