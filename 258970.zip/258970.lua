-- Lua provided by SkyAPI 
-- Game: Gauntlet™ Slayer Edition
addappid(258970)
addappid(258971, 1, "c9af0eb8ded0f92e61c1460730ac4864622496eb18354809dcf8a14e6dc3382b")
addappid(258972, 1, "8b58a324ddc491166a8f0d0e78642cb8dfc625c0a22a6a4d0206237509607643")
addappid(298987, 1, "772fa225563294d221806a79d1a83678fc58febe367956d4a290e334cd3d2591")
addappid(335510)
