-- Lua provided by RyzenAPI
-- Game: Gauntlet™ Slayer Edition

-- MAIN APPLICATION
addappid(258970)
addappid(298980)
addappid(298981)
addappid(298982)
addappid(298983)
addappid(298984)
addappid(298985)
addappid(298986)
addappid(302280)
addappid(302281)
addappid(302282)
addappid(324040)
addappid(335510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(258971, 1, "c9af0eb8ded0f92e61c1460730ac4864622496eb18354809dcf8a14e6dc3382b")
addappid(258972, 1, "8b58a324ddc491166a8f0d0e78642cb8dfc625c0a22a6a4d0206237509607643")
addappid(298987, 1, "772fa225563294d221806a79d1a83678fc58febe367956d4a290e334cd3d2591")

