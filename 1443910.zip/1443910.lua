-- Lua provided by RyzenAPI
-- Game: addappid(1443910)

-- MAIN APPLICATION
addappid(1443910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443911, 1, "de70e2fdbca7d8f135d21113382b8d3df33b8bc710d9c9c219bd4117a7ca9f74")
