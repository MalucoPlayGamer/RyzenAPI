-- Lua provided by RyzenAPI
-- Game: Game: AppID 767600

-- MAIN APPLICATION
addappid(767600)
-- Game: addappid(767600)

-- MAIN APP DEPOTS / PACKAGES
addappid(767601, 1, "e017b2298de950805566c8e73b48c3946c19e7e1f93ba917470d2424ef5b7d55")
