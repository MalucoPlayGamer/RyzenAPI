-- Lua provided by RyzenAPI
-- Game: The Backrooms: Found Footage

-- MAIN APPLICATION
addappid(1958130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958131, 1, "434837600b8482769d961605d8112ef137dda2a5fea601cc64ca805f5faf7a97")

