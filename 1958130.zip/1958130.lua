-- Lua provided by SkyAPI 
-- Game: The Backrooms: Found Footage
addappid(1958130)
addappid(1958131, 1, "434837600b8482769d961605d8112ef137dda2a5fea601cc64ca805f5faf7a97")
