-- Lua provided by RyzenAPI
-- Game: The Backrooms: Found Footage

-- MAIN APPLICATION
addappid(1958130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1958131, 1, "434837600b8482769d961605d8112ef137dda2a5fea601cc64ca805f5faf7a97")

