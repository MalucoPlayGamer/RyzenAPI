-- Lua provided by RyzenAPI
-- Game: AppID 658530

-- MAIN APPLICATION
addappid(658530)

-- MAIN APP DEPOTS / PACKAGES
addappid(658531, 1, "96dd8494380bc682930a8c13f2b7d494928f348131ed3385342090a59f3a6764")
addappid(658532, 1, "7c3ca9e3f06d68503cda1a2f5be68fed77665abfc713dbaf8866823aec82741c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
