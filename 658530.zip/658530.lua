-- Lua provided by SkyAPI 
-- Game: AppID 658530
addappid(658530)
addappid(658531, 1, "96dd8494380bc682930a8c13f2b7d494928f348131ed3385342090a59f3a6764")
addappid(658532, 1, "7c3ca9e3f06d68503cda1a2f5be68fed77665abfc713dbaf8866823aec82741c")
