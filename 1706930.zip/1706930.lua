-- Lua provided by RyzenAPI
-- Game: A Taste of the Past

-- MAIN APPLICATION
addappid(1706930)

