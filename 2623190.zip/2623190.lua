-- Lua provided by RyzenAPI
-- Game: The Elder Scrolls IV: Oblivion Remastered

-- MAIN APPLICATION
addappid(2623190)
addappid(3533970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623191, 1, "35dc19b14e7481262176a54f0a9de8f9e76c3dcf493a26fa085ed999e684b5f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2988900)
