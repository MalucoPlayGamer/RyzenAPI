-- Lua provided by RyzenAPI
-- Game: Game: The Elder Scrolls IV: Oblivion Remastered

-- MAIN APPLICATION
addappid(2623190)
addappid(3533970)
-- Game: addappid(2623190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623191, 1, "35dc19b14e7481262176a54f0a9de8f9e76c3dcf493a26fa085ed999e684b5f7")
