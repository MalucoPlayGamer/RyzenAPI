-- Lua provided by RyzenAPI
-- Game: Victorian characters for Clip maker

-- MAIN APPLICATION
addappid(1716340)
-- Game: addappid(1716340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716341, 1, "5acd90ad784cb9cc7241bf3c30536f9cbf212483a3e00050830f256781ee3cf0")
