-- Lua provided by RyzenAPI
-- Game: Sphere 3

-- MAIN APPLICATION
addappid(397040)
addappid(794000)
addappid(794010)
addappid(794020)
addappid(2152370)
addappid(2152890)
addappid(2152910)
addappid(2200520)
addappid(2200630)
addappid(3225170)
addappid(3225180)
addappid(3225190)
addappid(3225200)

-- MAIN APP DEPOTS / PACKAGES
addappid(397041, 1, "32d52463d492fc4495d3702937006ef714e417bd7edb65ecb5803381a6af6925")

