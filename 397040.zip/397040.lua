-- Lua provided by RyzenAPI
-- Game: 397040

-- MAIN APPLICATION
addappid(397040)
-- Game: addappid(397040)

-- MAIN APP DEPOTS / PACKAGES
addappid(397041, 1, "32d52463d492fc4495d3702937006ef714e417bd7edb65ecb5803381a6af6925")
