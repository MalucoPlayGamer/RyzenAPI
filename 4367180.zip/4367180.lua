-- Lua provided by RyzenAPI
-- Game: Agrocracy

-- MAIN APPLICATION
addappid(4367180) -- Agrocracy
-- addappid(4367182) -- Depot 4367182 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4367181, 1, "cb744125251578cadfdfed709004e024a9ded7655beaa0347f3786f1b5fe94ab") -- Depot 4367181

