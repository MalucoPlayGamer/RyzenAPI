-- 4367180's Lua and Manifest Created by Hubcap Manifest
-- Agrocracy
-- Created: August 13, 2026 at 04:05:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4367180) -- Agrocracy
-- MAIN APP DEPOTS
addappid(4367181, 1, "cb744125251578cadfdfed709004e024a9ded7655beaa0347f3786f1b5fe94ab") -- Depot 4367181
setManifestid(4367181, "3607994809529293447", 620844568)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4367182) -- Depot 4367182 (empty depot)