-- Lua provided by RyzenAPI
-- Game: addappid(1866260)

-- MAIN APPLICATION
addappid(1866260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866261, 1, "b20f424de8b45eeee1e556568ab2f6d69210b45fabda0b7d1ba66de1678520a5")
