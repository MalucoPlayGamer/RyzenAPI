-- Lua provided by SkyAPI 
-- Game: Bone's Cafe Demo
addappid(1918200)
addappid(1918201, 1, "662b2314ef848760961e4f5eacf4d7653f93bdf656bda973507ae06ffad7db3f")
