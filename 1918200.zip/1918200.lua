-- Lua provided by RyzenAPI
-- Game: Bone's Cafe Demo

-- MAIN APPLICATION
addappid(1918200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918201, 1, "662b2314ef848760961e4f5eacf4d7653f93bdf656bda973507ae06ffad7db3f")

