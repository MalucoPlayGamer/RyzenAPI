-- Lua provided by RyzenAPI
-- Game: Game: Leadwerks Game Launcher

-- MAIN APPLICATION
addappid(355500)
-- Game: addappid(355500)

-- MAIN APP DEPOTS / PACKAGES
addappid(355501, 1, "9a6b49708156c88e1d84aaa3be062e173ca25e0a56922125b98f004c45ecd59e")
