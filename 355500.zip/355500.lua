-- Lua provided by RyzenAPI
-- Game: Leadwerks Game Launcher

-- MAIN APPLICATION
addappid(355500)

-- MAIN APP DEPOTS / PACKAGES
addappid(355501, 1, "9a6b49708156c88e1d84aaa3be062e173ca25e0a56922125b98f004c45ecd59e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
