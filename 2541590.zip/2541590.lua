-- Lua provided by RyzenAPI
-- Game: Flow Parkour

-- MAIN APPLICATION
addappid(2541590)
-- Game: addappid(2541590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541591, 1, "613b0885315994844432113cdc9a34d1e95022aee9149cce40bb58470a99b831")
addappid(2541592, 1, "6556da28ffc7dbade2cfde1e33f6bddfa2a629e62718a167173d0c6c14ab37e7")
