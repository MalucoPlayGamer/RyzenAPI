-- Lua provided by RyzenAPI
-- Game: Q.U.B.E. 10th Anniversary

-- MAIN APPLICATION
addappid(1564220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564221, 1, "15ede31b776d6710ded0593b967fc010f6266889d327f92fc648eeb892175d22")
addappid(1564222, 1, "9af26770feaabc64d01b2598e74782324058bb2543c78c7c4e8b8a0a88604363")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
