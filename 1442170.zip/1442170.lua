-- Lua provided by RyzenAPI
-- Game: KILLRUN

-- MAIN APPLICATION
addappid(1442170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1442171, 1, "d11c7c7ff3fd0c4d8a2f027d4303880c6a2d1b8c1d0ac18d1f9324cb49834746")

