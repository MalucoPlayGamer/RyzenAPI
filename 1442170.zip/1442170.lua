-- Lua provided by RyzenAPI 
-- Game: KILLRUN
addappid(1442170)
addappid(1442171, 1, "d11c7c7ff3fd0c4d8a2f027d4303880c6a2d1b8c1d0ac18d1f9324cb49834746")
