-- Lua provided by RyzenAPI
-- Game: Armored Gear

-- MAIN APPLICATION
addappid(581000)

-- MAIN APP DEPOTS / PACKAGES
addappid(581001, 1, "eadcc0d89e88232f9a0f06603f4861acd13175d1aca8e1898b56b7a3df40277e")

