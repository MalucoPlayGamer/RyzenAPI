-- Lua provided by RyzenAPI
-- Game: Foreign Legion: Multi Massacre

-- MAIN APPLICATION
addappid(205550)

-- MAIN APP DEPOTS / PACKAGES
addappid(205551, 1, "6c5fa12b8abbafe0bfc5b8b89f38dd102a070c14d91f1c32d308f84fd422c81d")
addappid(205552, 1, "4de65c29949696d3057e80201134a06fcc0c71b708f48a43e74483ead6b7e8b1")

