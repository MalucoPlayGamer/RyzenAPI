-- Lua provided by RyzenAPI
-- Game: Demon Hunter 2: New Chapter

-- MAIN APPLICATION
addappid(465720)

-- MAIN APP DEPOTS / PACKAGES
addappid(465721, 1, "4556c74330d0bb5502a16da90beb40b588ee11c0195681f1d8bf7e9fd2eff529")
addappid(465722, 1, "9516b68768ae7358a7be4a1b0efd7a3c960a562389f24e95bf9b7b4000ab0783")
addappid(465723, 1, "429c411005f50a76c60cb812c0a7e535d65ef4ffbd3e9ce4c45a08703a248159")
