-- Lua provided by RyzenAPI
-- Game: Game: AppID 2242590

-- MAIN APPLICATION
addappid(2242590)
-- Game: addappid(2242590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242591, 1, "ff0a56f4a16124b9e945ac5159ac5002df1e0025186ab77955a771138bb2a63a")
