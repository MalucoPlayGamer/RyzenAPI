-- Lua provided by RyzenAPI
-- Game: AppID 1408220

-- MAIN APPLICATION
addappid(1408220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408221, 1, "8fb32bda402555bb781b2988a0a1fbe2dedee743237f349b10268c37245d11fa")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1453690)
