-- Lua provided by RyzenAPI
-- Game: Journey of Wrestling

-- MAIN APPLICATION
addappid(2941580)
-- Game: addappid(2941580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941581, 1, "4cb8a29fbbbfbfc50393e33ddb82b534d8aef247b9823eee85712c63385c6918")
