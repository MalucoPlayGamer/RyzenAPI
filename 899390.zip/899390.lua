-- Lua provided by RyzenAPI
-- Game: Xenon Racer

-- MAIN APPLICATION
addappid(899390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(899391, 1, "33bbcbe9deac845fae05b7b643717c9d99e7f4c7cc5c86d4eb9e97208082580a")

