-- Lua provided by RyzenAPI
-- Game: Game: Xenon Racer

-- MAIN APPLICATION
addappid(899390)
-- Game: addappid(899390)

-- MAIN APP DEPOTS / PACKAGES
addappid(899391, 1, "33bbcbe9deac845fae05b7b643717c9d99e7f4c7cc5c86d4eb9e97208082580a")
