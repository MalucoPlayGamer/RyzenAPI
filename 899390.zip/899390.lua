-- Lua provided by SkyAPI 
-- Game: Xenon Racer
addappid(899390)
addappid(899391, 1, "33bbcbe9deac845fae05b7b643717c9d99e7f4c7cc5c86d4eb9e97208082580a")
