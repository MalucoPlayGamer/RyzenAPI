-- Lua provided by SkyAPI 
-- Game: KillSteel
addappid(1269550)
addappid(1269551, 1, "cb280b04650e0c63deb091d01c861c69c37fb4476b32926a6573982fcb3b3fe7")
