-- Lua provided by RyzenAPI
-- Game: My Butler

-- MAIN APPLICATION
addappid(494470)

-- MAIN APP DEPOTS / PACKAGES
addappid(494471, 1, "b896d794453d574c46026dfa5b3a4ac9b6b6d8c13641e6f4baff54c48191703e")

