-- Lua provided by RyzenAPI
-- Game: My Butler

-- MAIN APPLICATION
addappid(494470)

-- MAIN APP DEPOTS / PACKAGES
addappid(494471, 1, "b896d794453d574c46026dfa5b3a4ac9b6b6d8c13641e6f4baff54c48191703e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
