-- Lua provided by RyzenAPI
-- Game: Banner of Conquest

-- MAIN APPLICATION
addappid(2483730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483731, 1, "f5a5c09a28760aa3cc0410a57d04dfba3879f0df7b7988db89121c13a1767eb2")

