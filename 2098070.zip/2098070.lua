-- Lua provided by RyzenAPI
-- Game: addappid(2098070)

-- MAIN APPLICATION
addappid(2098070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098071, 1, "5714cd3cd3cff8ab56f5a1ffc12e42cf59ddf1cd11f37b5aaf888748f86d89ed")
