-- Lua provided by RyzenAPI 
-- Game: Bloons TD Battles 2
addappid(1276390)
addappid(1276391, 1, "3906c873bfc5a0974c59a35dd0a92eb215158ebd43fe686cc7253ff7037e6dde")
addappid(1276392, 1, "3f29749f5600a4d14e4005553ee833ebc94be009b2e10a4884044c570ff9d117")
