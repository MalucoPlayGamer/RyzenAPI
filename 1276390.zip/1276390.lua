-- Lua provided by RyzenAPI
-- Game: Bloons TD Battles 2

-- MAIN APPLICATION
addappid(1276390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1276391, 1, "3906c873bfc5a0974c59a35dd0a92eb215158ebd43fe686cc7253ff7037e6dde")
addappid(1276392, 1, "3f29749f5600a4d14e4005553ee833ebc94be009b2e10a4884044c570ff9d117")

