-- Lua provided by RyzenAPI
-- Game: addappid(1699390)

-- MAIN APPLICATION
addappid(1699390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699391, 1, "433b9c94024771c8346055dca4089ba46ebcee05c77b90c7ca8c8a71a5dfad4b")
