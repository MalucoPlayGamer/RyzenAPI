-- Lua provided by RyzenAPI 
-- Game: VEHICLES FURY
addappid(749290)
addappid(749291, 1, "14a5c7b95522fcf184639588413151a7f4584ba9a9cc7667db9dcf610f9ff256")
