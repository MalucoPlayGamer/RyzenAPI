-- Lua provided by RyzenAPI
-- Game: 749290

-- MAIN APPLICATION
addappid(749290)
-- Game: addappid(749290)

-- MAIN APP DEPOTS / PACKAGES
addappid(749291, 1, "14a5c7b95522fcf184639588413151a7f4584ba9a9cc7667db9dcf610f9ff256")
