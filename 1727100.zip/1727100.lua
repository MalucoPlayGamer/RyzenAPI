-- Lua provided by RyzenAPI
-- Game: 69 Summon Succubus

-- MAIN APPLICATION
addappid(1727100)
addappid(1982740)
-- Game: addappid(1727100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727101, 1, "bbc64f9f1c11d5cb35672da8c63a43d2dd64fb3cb0dc2edfa5d19cddf74ee8c2")
