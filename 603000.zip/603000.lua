-- Lua provided by RyzenAPI
-- Game: Hillbilly Apocalypse

-- MAIN APPLICATION
addappid(603000)

-- MAIN APP DEPOTS / PACKAGES
addappid(603001, 1, "dfa1842ecf677e13574e67036f027e98f9277711004a574b36a87fe68403af88")
