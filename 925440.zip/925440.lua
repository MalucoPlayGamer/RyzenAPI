-- Lua provided by RyzenAPI
-- Game: addappid(925440)

-- MAIN APPLICATION
addappid(925440)

-- MAIN APP DEPOTS / PACKAGES
addappid(925441, 1, "42f1335ee2d94c465a50c547b7c52bffd1f49872c140ffd3ab4af6f83cdbd982")
