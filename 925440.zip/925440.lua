-- Lua provided by RyzenAPI
-- Game: 神社的百合香 ~ Floral Aroma in the Shrine

-- MAIN APPLICATION
addappid(925440)

-- MAIN APP DEPOTS / PACKAGES
addappid(925441, 1, "42f1335ee2d94c465a50c547b7c52bffd1f49872c140ffd3ab4af6f83cdbd982")
