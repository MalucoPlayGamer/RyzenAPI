-- Lua provided by RyzenAPI
-- Game: Game: ABYSSAL BLADE – Original Soundtrack

-- MAIN APPLICATION
addappid(3821390)
-- Game: addappid(3821390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3821391, 1, "fd44496029f461dd74354e88dccac15d0919168931dc9f594cbf83dd2f82765b")
addappid(3821392, 1, "09a36570b09291604f6993685bc76a27d2b35153dc8ba1f0fa15a1bd19b90971")
