-- Lua provided by RyzenAPI
-- Game: Game: Exorcist

-- MAIN APPLICATION
addappid(3364650)
-- Game: addappid(3364650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364651, 1, "667e11614d7d23bfb74a74d2d7b8b0621814190d9fe532bfd2d0944778b99ea1")
