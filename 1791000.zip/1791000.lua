-- Lua provided by RyzenAPI
-- Game: AppID 1791000

-- MAIN APPLICATION
addappid(1791000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791001, 1, "dd56a0b5ce746d4cf2e0b3aef26409df4d80d8e956dd75c1710bb1dbf89da3de")

