-- Lua provided by RyzenAPI
-- Game: AppID 43500

-- MAIN APPLICATION
addappid(43500)

-- MAIN APP DEPOTS / PACKAGES
addappid(43501, 1, "2fb1edb7589ef4f1b9d7d0ac370fa0dc9d9c85e7f53b185ef6fe145ad2eb40d0")
addappid(43502, 1, "0052d2550899e5892df0802a0b1fe4327a53771ec8d41c33b446eca29dc0aaad")
addappid(43504, 1, "e1676ead6bca699252bf05543daf15b18a1452ce676ef8853a74b81553c7220e")
