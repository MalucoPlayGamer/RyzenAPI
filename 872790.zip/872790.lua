-- Lua provided by RyzenAPI
-- Game: Football Manager 2019

-- MAIN APPLICATION
addappid(872790)
addappid(933720)

-- MAIN APP DEPOTS / PACKAGES
addappid(872790,0,"51ea7632e585c1a246fc5c1fbc68a1bf677490e2b208ef0590eadea6e7f04e60")
addappid(872791,0,"63278fd41c9a08e70afebf79ff71847c54e3449dd22960fc80c3ae1fb4b3ec45")
addappid(872792,0,"a8f710f559b9e168b9e497ae15f56029a40fcd2d1de29802c774e2aa392802c5")
addappid(872793,0,"4b2a05a92e71309af5bccfa94c7912d41b26e4d784a4e179e546286ec22c4b84")
addappid(872794,0,"d61afa7da0f4272d2364fdd6be576a907f462f237380a4770914afd6cbb507a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
