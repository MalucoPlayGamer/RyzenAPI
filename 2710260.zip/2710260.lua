-- Lua provided by RyzenAPI
-- Game: addappid(2710260)

-- MAIN APPLICATION
addappid(2710260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710261, 1, "45f19d3005efcc12780e3effff1905b2198eacd4fdb2d06882a6ecc4184ff949")
addappid(2710262, 1, "bb2f0eeef822e8fd204be33de46197e31eed3603fd277f6bdde27040242b8e39")
