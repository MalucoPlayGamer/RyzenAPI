-- Lua provided by RyzenAPI
-- Game: The Boo Croo

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1424540, 1, "9b3377ed01fc0ac698faa449b22ab531d2c941aa90230d6c9377013eed28f8d0") -- The Boo Croo
addappid(1424541, 1, "472a37b61f8ae724c1c72575ce940d410bd8b06bdbe5a9a541c5739ab1e371c4") -- Depot 1424541

