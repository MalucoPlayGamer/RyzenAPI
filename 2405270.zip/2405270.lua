-- Lua provided by RyzenAPI
-- Game: Project Asteroids

-- MAIN APPLICATION
addappid(2405270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405271, 1, "d75240a1412517ec9182ade1ae471761d6e39c54b5c0320b6777210042f45080")

