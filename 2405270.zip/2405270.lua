-- Lua provided by RyzenAPI
-- Game: Project Asteroids

-- MAIN APPLICATION
addappid(2405270)
addappid(3459440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2405271, 1, "d75240a1412517ec9182ade1ae471761d6e39c54b5c0320b6777210042f45080")

