-- Lua provided by RyzenAPI 
-- Game: VRoid Studio
addappid(1486350)
addappid(1486351, 1, "d7f7173e82faedae356b19b75a8f6a7649767601cd3f8b171b198b706e282173")
addappid(1486352, 1, "8aae19ad1ab9f4c920e5168df4ce9e66f7280f3dfcf4fbeb51ac2aeb4682c3be")
