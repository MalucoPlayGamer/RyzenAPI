-- Lua provided by RyzenAPI
-- Game: Game: Under The Waves ( Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2216990)
-- Game: addappid(2216990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216991, 1, "ff6795be6c9431f745315811661372f51d852f5a2dfaec6bbcf2dfbd45701a19")
addappid(2216992, 1, "4ffe14b572714786dac9a13ea692d908bd12fbd9037f2ba88f5242de30d7986c")
