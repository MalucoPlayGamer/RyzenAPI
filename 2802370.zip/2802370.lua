-- Lua provided by RyzenAPI
-- Game: Construction Runner

-- MAIN APPLICATION
addappid(2802370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2802371, 1, "2dca1e224e743f534cf4d4ce25836f308329f200d4c90f569bf20ffce867077f")
addappid(2802372, 1, "fa28b929320612551305c690475bcb8f4a005742c3c10aebe979ac0a189bfb93")

