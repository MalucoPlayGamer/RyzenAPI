-- Lua provided by RyzenAPI
-- Game: Game: Construction Runner

-- MAIN APPLICATION
addappid(2802370)
-- Game: addappid(2802370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802371, 1, "2dca1e224e743f534cf4d4ce25836f308329f200d4c90f569bf20ffce867077f")
addappid(2802372, 1, "fa28b929320612551305c690475bcb8f4a005742c3c10aebe979ac0a189bfb93")
