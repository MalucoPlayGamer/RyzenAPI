-- Lua provided by RyzenAPI
-- Game: MoeMoni Land

-- MAIN APPLICATION
addappid(2651080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651081, 1, "1a0e02822d37eaa491ff0c5d688062e587dc8e82d7a00c0da36383506b5e3bd2")

