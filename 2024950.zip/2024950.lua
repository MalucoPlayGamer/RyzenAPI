-- Lua provided by RyzenAPI
-- Game: Rally 9000

-- MAIN APPLICATION
addappid(2024950)
-- Game: addappid(2024950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024951, 1, "4020361d8e075213d9272522e3c966382caf15f6edc822a29fef43c2ffdbe45e")
