-- Lua provided by RyzenAPI 
-- Game: AppID 802400
addappid(802400)
addappid(802401, 1, "62b6b18ec1ee7552c84b2813e70e666f981b6c4e62f3c57e401f8b1423c2021e")
