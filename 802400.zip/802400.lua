-- Lua provided by RyzenAPI
-- Game: Fhtagn! - Tales of the Creeping Madness

-- MAIN APPLICATION
addappid(802400)

-- MAIN APP DEPOTS / PACKAGES
addappid(802401, 1, "62b6b18ec1ee7552c84b2813e70e666f981b6c4e62f3c57e401f8b1423c2021e")

