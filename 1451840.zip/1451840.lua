-- Lua provided by RyzenAPI
-- Game: Heart of Metal

-- MAIN APPLICATION
addappid(1451840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1451841, 1, "8d8c250a3ee4fa79a1ecf00062ce618bc14110171aac5eef6801c17f359ebf32")

