-- Lua provided by RyzenAPI
-- Game: AppID 1451840

-- MAIN APPLICATION
addappid(1451840)
-- Game: addappid(1451840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451841, 1, "8d8c250a3ee4fa79a1ecf00062ce618bc14110171aac5eef6801c17f359ebf32")
