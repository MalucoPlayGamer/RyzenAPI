-- Lua provided by RyzenAPI
-- Game: Knights and Dungeons

-- MAIN APPLICATION
addappid(1359300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359302,0,"9e5efd61577d3a8eaf49add59d4fc16b831d27514ba455c4741c327b04f5451a")
addappid(1411760,0,"d84b1ed4c95f5b6f42c3c7035e5c3b3981b6ac6bd7582a34f4242093bb52c6e4")

