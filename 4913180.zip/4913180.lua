-- Lua provided by RyzenAPI
-- Game: Reawait

-- MAIN APPLICATION
addappid(4913180) -- Reawait

-- MAIN APP DEPOTS / PACKAGES
addappid(4913181, 1, "5dc6c2a132b092919eb159a8375964c62be2afcfe54705e65647706c4554464d") -- Depot 4913181

