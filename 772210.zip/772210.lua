-- Lua provided by RyzenAPI
-- Game: Committed: Mystery at Shady Pines

-- MAIN APPLICATION
addappid(772210)

-- MAIN APP DEPOTS / PACKAGES
addappid(772211,0,"324c7827702b2a29298dd337a373de9eaedea8c4e3d580502d76703b5e43de9d")

