-- Lua provided by RyzenAPI
-- Game: Divine Dawn

-- MAIN APPLICATION
addappid(2170920) -- Divine Dawn

-- MAIN APP DEPOTS / PACKAGES
addappid(2170921, 1, "1a2b0b03891744219755c82989bdb3d68e856025040a118d98726e9778d8fbc7") -- Depot 2170921

