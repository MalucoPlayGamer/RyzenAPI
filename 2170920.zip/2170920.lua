-- 2170920's Lua and Manifest Created by Hubcap Manifest
-- Divine Dawn
-- Created: August 20, 2026 at 23:48:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2170920) -- Divine Dawn
-- MAIN APP DEPOTS
addappid(2170921, 1, "1a2b0b03891744219755c82989bdb3d68e856025040a118d98726e9778d8fbc7") -- Depot 2170921
setManifestid(2170921, "7924607794558112481", 513999569)