-- Lua provided by RyzenAPI
-- Game: Strike Force - War on Terror

-- MAIN APPLICATION
addappid(860260)

-- MAIN APP DEPOTS / PACKAGES
addappid(860261,0,"14eaaca9effb604df6aa9f068c46c305d649bc2f1b02d31ce6b23826df4619eb")

