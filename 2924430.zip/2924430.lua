-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Seven Sisters High School Uniform (7), Battle BGM & Battle Jingle Set

-- MAIN APPLICATION
addappid(2924430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924430,0,"d938b2988775f6ee36386f348d136198b811e977d25792973d3efbf25b5ee23d")

