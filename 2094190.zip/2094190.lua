-- Lua provided by RyzenAPI
-- Game: addappid(2094190)

-- MAIN APPLICATION
addappid(2094190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094191, 1, "fdd518c919d5a77c4d9fcb731089e6a7f7e7fb9314b2768419014e76ac41e2ff")
