-- Lua provided by RyzenAPI 
-- Game: AppID 1371780
addappid(1371780)
addappid(1371781, 1, "28bb9818e5d7df143d7db8aa3f3c316005dffb0836b5ba511f676ea47dc171ad")
