-- Lua provided by RyzenAPI
-- Game: Game: AppID 1371780

-- MAIN APPLICATION
addappid(1371780)
-- Game: addappid(1371780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371781, 1, "28bb9818e5d7df143d7db8aa3f3c316005dffb0836b5ba511f676ea47dc171ad")
