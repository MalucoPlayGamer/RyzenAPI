-- Lua provided by RyzenAPI
-- Game: 3380830

-- MAIN APPLICATION
addappid(3380830)
-- Game: addappid(3380830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380831, 1, "f84c9508030a24d02ca4a74f23984228b3a79653bdc5259b1bcf0ea0da08443b")
