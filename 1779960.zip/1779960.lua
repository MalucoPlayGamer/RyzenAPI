-- Lua provided by RyzenAPI
-- Game: Salome's Kiss

-- MAIN APPLICATION
addappid(1779960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779961, 1, "23e8e92ce614e3b38d83f1e32e65d7ec0647b424343d25dcbea0a46f51d48d9b")
addappid(1870500, 0, "d75a2ca65ad0c5b8db8266e180eecc0dafa1bc44155e619c493c360111782858")
