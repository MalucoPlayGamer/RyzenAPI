-- Lua provided by RyzenAPI
-- Game: Idle TD: Heroes vs Zombies

-- MAIN APPLICATION
addappid(1647440)
