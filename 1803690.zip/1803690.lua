-- Lua provided by RyzenAPI
-- Game: Ping Pong Pufferfish

-- MAIN APPLICATION
addappid(1803690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803691, 1, "9552f919e9887c4b30769b8a61eac1c0ebd3825fde1b67a3985174b45c0ffb22")

