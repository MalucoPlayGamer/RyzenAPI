-- Lua provided by RyzenAPI
-- Game: Smash Up

-- MAIN APPLICATION
addappid(446540)
addappid(529530)
addappid(529531)
addappid(532940)
addappid(852580)
addappid(1232030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(446541, 1, "d6b28056a819512ddd8d605b8391f58cb468633c33ba808a01d66c5e73e53b76")
addappid(446542, 1, "da0b651a32cbfd585b81dbe29acd19e53ee02fe28d12b8ee03710e2df4f40a4b")
addappid(446543, 1, "558921676289f7f2daa87ffad9c5d5e16bae0bea9242ad9d05d945214e9c5989")

