-- Lua provided by RyzenAPI
-- Game: Mina & Michi

-- MAIN APPLICATION
addappid(1373710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373711, 1, "9a8baf6bbf0f50e0f079db97edb88dd6c6217d13ea011d8d75b98295b30f89cd")

