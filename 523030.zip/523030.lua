-- Lua provided by SkyAPI 
-- Game: Tank Universal 2
addappid(523030)
addappid(523031, 1, "98a37a8fd562229de89ec26e03ff5de87cacc9864816ec88b899d3c3a803a160")
