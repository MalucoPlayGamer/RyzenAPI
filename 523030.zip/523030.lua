-- Lua provided by RyzenAPI
-- Game: Tank Universal 2

-- MAIN APPLICATION
addappid(523030)

-- MAIN APP DEPOTS / PACKAGES
addappid(523031, 1, "98a37a8fd562229de89ec26e03ff5de87cacc9864816ec88b899d3c3a803a160")

