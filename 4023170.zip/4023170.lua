-- 4023170's Lua and Manifest Created by Hubcap Manifest
-- SWEET HOLES
-- Created: February 16, 2026 at 03:21:17 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4023170) -- SWEET HOLES
-- MAIN APP DEPOTS
addappid(4023171, 1, "003d9ed1c42586b6cdad0a04bb4a45b11063d75972a8d30e04e0fdc4bbe94f89") -- Depot 4023171
setManifestid(4023171, "5157605905330693326", 331561394)