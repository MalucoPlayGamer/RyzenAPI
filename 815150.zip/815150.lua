-- Lua provided by RyzenAPI
-- Game: AppID 815150

-- MAIN APPLICATION
addappid(815150)

-- MAIN APP DEPOTS / PACKAGES
addappid(815151, 1, "eb7bb52eaa675f9a109fa62f0708cbfdd44156a6ffb6ddc115bff4501aa2dcc6")

