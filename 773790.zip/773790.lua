-- Lua provided by RyzenAPI
-- Game: AppID 773790

-- MAIN APPLICATION
addappid(773790)

-- MAIN APP DEPOTS / PACKAGES
addappid(773791, 1, "2242383a779d80c162f0433017a5bd4cf1126742e28c7ad87fa2f34b9388db57")
addappid(773792, 1, "6209a71559609cbec426f1f082501e5011d326f58c544f7fd182ab222111bc8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2365430)
