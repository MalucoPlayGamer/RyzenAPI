-- Lua provided by RyzenAPI
-- Game: Sagres

-- MAIN APPLICATION
addappid(2120310)
-- Game: addappid(2120310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120311, 1, "f2669ee6193a753107ad30f5bd399269292b132966d703f209f54ad983db1a4c")
