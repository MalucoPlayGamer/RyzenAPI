-- Lua provided by RyzenAPI
-- Game: Lone Archer

-- MAIN APPLICATION
addappid(1414060)
-- Game: addappid(1414060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414061, 1, "3de38bcaa81aea009988dc6480b44434a786843cb771301bb3d6c8e9fc6a4f3a")
