-- Lua provided by RyzenAPI
-- Game: No Ghost in Stay Home

-- MAIN APPLICATION
addappid(1645640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645641, 1, "31259b86369d37a1faa37ae25da58f4ce9ae61f1affdd59d71d822c6f5fec10c")

