-- Lua provided by RyzenAPI
-- Game: Game: Soccer Rage

-- MAIN APPLICATION
addappid(356510)
-- Game: addappid(356510)

-- MAIN APP DEPOTS / PACKAGES
addappid(356511, 1, "dc4ba54cc902145a6eba8680e270ea6a79785edc22a0482dd50f8e09315990f5")
