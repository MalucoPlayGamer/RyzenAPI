-- Lua provided by RyzenAPI
-- Game: Crimzon Clover WORLD IGNITION

-- MAIN APPLICATION
addappid(285440)
addappid(367530)

-- MAIN APP DEPOTS / PACKAGES
addappid(285441, 1, "3f8181cb439156e6a79d0237d41c2774abd75f3d91fd2bbc896cb2fb1f57b50f")
addappid(326310, 0, "f94746a3d216fc1f610401570913ab6b80a139024495b50db88b96193e49cbc3")
addappid(373090, 0, "8d5ff46be8d73ae774d719a2cc1febec9f417d7432ea92de42525e63ee04e963")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
