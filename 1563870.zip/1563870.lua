-- Lua provided by RyzenAPI
-- Game: addappid(1563870)

-- MAIN APPLICATION
addappid(1563870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563871, 1, "68614bea131c346f8dceb7486b706cc4c4b22cfb2e1ebd25e8d9785b64136f37")
