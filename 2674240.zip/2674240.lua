-- Lua provided by RyzenAPI
-- Game: Jinni : Haunted House

-- MAIN APPLICATION
addappid(2674240)
-- Game: addappid(2674240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674241, 1, "0ef9034bdb729385b371dd31d818528d0e9435382a36d64705387454c3e7badc")
