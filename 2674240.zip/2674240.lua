-- Lua provided by RyzenAPI
-- Game: Jinni : Haunted House

-- MAIN APPLICATION
addappid(2674240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2674241, 1, "0ef9034bdb729385b371dd31d818528d0e9435382a36d64705387454c3e7badc")

