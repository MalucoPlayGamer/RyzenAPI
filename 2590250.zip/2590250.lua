-- Lua provided by RyzenAPI 
-- Game: The Windows Are Gone
addappid(2590250)
addappid(2590251, 1, "e1fe54c743082e672b3de05dced542d8ce0127a3ffdd1bff08f2506a615aeabe")
