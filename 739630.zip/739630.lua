-- Lua provided by SkyAPI 
-- Game: Phasmophobia
addappid(739630)
addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")
