-- Generated with Luie @ https://lua.tools/
-- 739630 - Phasmophobia
-- Generated 2026-08-26 03:01:08 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(739630, 1, "6850686ca304da94d7b1a8ebd9203bcf007712610dc92eb9452e22a31b6b823d")

-- Main Depots
addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")
setManifestid(739631, "570071836422739540", 44319237640)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
