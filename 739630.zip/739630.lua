-- Lua provided by RyzenAPI
-- Game: Phasmophobia

-- MAIN APPLICATION
addappid(739630)

-- MAIN APP DEPOTS / PACKAGES
addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")
