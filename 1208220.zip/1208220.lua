-- Lua provided by RyzenAPI
-- Game: Escape from Life Inc

-- MAIN APPLICATION
addappid(1208220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208222,0,"4d3731fb596cec99e6f35bed2ba96dafafe9fde816ad806478c10b82efae06c2")

