-- Lua provided by RyzenAPI
-- Game: 428370

-- MAIN APPLICATION
addappid(428370)
addappid(428371)
addappid(428373)
addappid(428374)
-- Game: addappid(428370)

-- MAIN APP DEPOTS / PACKAGES
addappid(428372,0,"c12e35866321f47e1ec6913a1112e7e45e4e68f3ac19f585c3716546e963cf0e")
addappid(485810,0,"5dc259439f7d42676951873627cffb6879b1b1485f01b9ae66bd9e9c992289bf")
