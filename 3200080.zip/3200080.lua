-- Lua provided by RyzenAPI
-- Game: 3200080

-- MAIN APPLICATION
addappid(3200080)
-- Game: addappid(3200080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200081, 1, "19a2717bcc3a4e4f1af863bbb5e9338fa95e225e1cd84de3cd0e9854e1c32627")
