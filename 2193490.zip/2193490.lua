-- Lua provided by RyzenAPI
-- Game: Game: First Cut: Samurai Duel

-- MAIN APPLICATION
addappid(2193490)
-- Game: addappid(2193490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193491, 1, "d2a64f44381142fbdbd0a3d5d2b1535f9656eadbdced14c19c1ae048a153ae63")
