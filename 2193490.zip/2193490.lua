-- Lua provided by RyzenAPI
-- Game: First Cut: Samurai Duel

-- MAIN APPLICATION
addappid(2193490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2193491, 1, "d2a64f44381142fbdbd0a3d5d2b1535f9656eadbdced14c19c1ae048a153ae63")

