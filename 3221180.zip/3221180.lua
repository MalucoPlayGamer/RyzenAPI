-- Lua provided by RyzenAPI
-- Game: Game: Re:Flex

-- MAIN APPLICATION
addappid(3221180)
-- Game: addappid(3221180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221181, 1, "4ee28b84d055d503ab9e888fa8a437a5409311d9dbe4f3aa0af5e8043eb490f5")
