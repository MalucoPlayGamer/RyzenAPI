-- Lua provided by RyzenAPI
-- Game: AppID 759850

-- MAIN APPLICATION
addappid(759850)

-- MAIN APP DEPOTS / PACKAGES
addappid(759851, 1, "be1b085817be6255ef2584b81324735455073ae5393f6bdea38e81fe1ebf0ffa")
addappid(759852, 1, "48de91cbac8684b8d5d24cee1253e59341e3c0a93e40e57a66f4142beff71763")
addappid(759853, 1, "e474d7b600ba3f0011fe1ad8029fe965a2455261725c33598efc54427965d53a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
