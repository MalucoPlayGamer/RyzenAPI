-- Lua provided by RyzenAPI
-- Game: Master Hanzi

-- MAIN APPLICATION
addappid(3592790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592791, 1, "ec6321a857df7bcc321a1c760202ca21717551ff4a8c3cb0dd0e59890403cd62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
