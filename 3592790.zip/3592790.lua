-- Lua provided by RyzenAPI 
-- Game: Master Hanzi
addappid(3592790)
addappid(3592791, 1, "ec6321a857df7bcc321a1c760202ca21717551ff4a8c3cb0dd0e59890403cd62")
