-- Lua provided by RyzenAPI 
-- Game: AppID 567130
addappid(567130)
addappid(567131, 1, "015880de416e5231ff7dbf518569cb620f6fa656fbdc5a6a233e214a15e13a5b")
