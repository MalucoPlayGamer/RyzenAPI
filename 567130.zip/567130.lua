-- Lua provided by RyzenAPI
-- Game: Boogeyman 2

-- MAIN APPLICATION
addappid(567130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(567131, 1, "015880de416e5231ff7dbf518569cb620f6fa656fbdc5a6a233e214a15e13a5b")
