-- Lua provided by RyzenAPI
-- Game: Beyond the Invisible: Evening

-- MAIN APPLICATION
addappid(650880)

-- MAIN APP DEPOTS / PACKAGES
addappid(650881,0,"c055b11dbd7827cd92ad04924ada4a6d7f2d2f30b52f97a4c3d8826081cdee82")
addappid(650888,0,"61fcec42edd7d8eb94b74bad3275f95aa90cc8ae9d26cd3f7d2f188aa2098b37")

