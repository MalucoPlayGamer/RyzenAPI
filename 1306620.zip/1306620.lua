-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Missing Children | 行方不明

-- MAIN APPLICATION
addappid(1306620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306621, 1, "70e41151f37c562c4c6f08b2bc8a0d0bf84b75414f5bc3f04ff8bf4cb2d0a480")
