-- Lua provided by RyzenAPI
-- Game: X-Force Genesis

-- MAIN APPLICATION
addappid(1686470)
-- Game: addappid(1686470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686471, 1, "0885266d9e14058e1505866ac1778fb351680568d55b33af33636f8fc5ba3166")
