-- Lua provided by RyzenAPI
-- Game: 60 Seconds!

-- MAIN APPLICATION
addappid(368360)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(368361, 1, "2ae9e0ceea9fa82714b84c935be78ba81079c2a262113051c5fa634a29804699")
addappid(368363, 1, "ef8ba55610beb7b64ea12aa6841c7915c109713db9847ec3a3795ff72fdf869e")
addappid(368364, 1, "abebb6eabe4d79da75b4eedd4991ed0c620708feabc16b4106183bcf892583b1")
addappid(368365, 1, "c0a0ee89acc3419ac7476d34852b51ad791eb12e36a43aa07de20ce6ea69b266")
addappid(368366, 1, "903fd4f5c27dd32b6d461d027b8068046de105d0d649a47efebb330228e5b95b")
addappid(368367, 1, "cbea14a4cdcedfed26d44652dd11dd982ccf368f476804d9fba917b1dc5a819a")
