-- Lua provided by RyzenAPI
-- Game: 最后的送别

-- MAIN APPLICATION
addappid(1852120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852121, 1, "671d1be8ed54cf712e906b0d8bdd08b77277e98c015fd66e676c489c77d62fd7")
