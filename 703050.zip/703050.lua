-- Lua provided by RyzenAPI
-- Game: 703050

-- MAIN APPLICATION
addappid(703050)
-- Game: addappid(703050)

-- MAIN APP DEPOTS / PACKAGES
addappid(703051, 1, "1cf40e45f5779d9ac3b9f4e7db4390680ceb84f37121ae6026fc3dfd49566ac7")
