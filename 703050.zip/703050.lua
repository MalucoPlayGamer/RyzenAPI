-- Lua provided by RyzenAPI
-- Game: iHUGU: I Hug You

-- MAIN APPLICATION
addappid(703050)

-- MAIN APP DEPOTS / PACKAGES
addappid(703051, 1, "1cf40e45f5779d9ac3b9f4e7db4390680ceb84f37121ae6026fc3dfd49566ac7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
