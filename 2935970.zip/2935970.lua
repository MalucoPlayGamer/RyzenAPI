-- Lua provided by RyzenAPI
-- Game: 2935970

-- MAIN APPLICATION
addappid(2935970)
-- Game: addappid(2935970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935970,0,"8672d14359ddb0d510628f135a2f7eac25adf3580f3c5da06c9f91dbdd480c06")
