-- Lua provided by RyzenAPI
-- Game: Brigador - Uplink EP

-- MAIN APPLICATION
addappid(1239512)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239540,0,"0b39de73ca7b164e53b54961cffb358b07d79cbbf5afd2eb0bfdad606eb2c055")
addappid(1239545,0,"f067011914e72c1b85d83038785922c102930e9c8396ea4629af19feda807448")
