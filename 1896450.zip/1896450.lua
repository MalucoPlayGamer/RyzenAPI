-- Lua provided by RyzenAPI
-- Game: Dank Subs

-- MAIN APPLICATION
addappid(1896450)
-- Game: addappid(1896450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896451, 1, "1fbdd999416b018a8eae46ab8a7e172a4ed297519199b5da223747702b8c2216")
