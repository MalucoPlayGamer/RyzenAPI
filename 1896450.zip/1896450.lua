-- Lua provided by RyzenAPI
-- Game: Dank Subs

-- MAIN APPLICATION
addappid(1896450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896451, 1, "1fbdd999416b018a8eae46ab8a7e172a4ed297519199b5da223747702b8c2216")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
