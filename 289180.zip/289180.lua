-- Lua provided by RyzenAPI 
-- Game: AppID 289180
addappid(289180)
addappid(289181, 1, "5e381e1ecc4843d93833cad8041afde49841f716a3c0a1945d422057ee5be198")
addappid(289182, 1, "b86d674eefc565ae1203f590afd87b7d351d6be62286bc7a026d6a723ea21e08")
