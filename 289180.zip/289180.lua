-- Lua provided by RyzenAPI
-- Game: A.I.M.2 Clan Wars

-- MAIN APPLICATION
addappid(289180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(289181, 1, "5e381e1ecc4843d93833cad8041afde49841f716a3c0a1945d422057ee5be198")
addappid(289182, 1, "b86d674eefc565ae1203f590afd87b7d351d6be62286bc7a026d6a723ea21e08")
