-- Lua provided by RyzenAPI
-- Game: Sheepy: A Short Adventure

-- MAIN APPLICATION
addappid(1568400)
-- Game: addappid(1568400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568401, 1, "b90983c6a8e71b83138c26a87555797449b139354f23976e28b5aba444f751d5")
