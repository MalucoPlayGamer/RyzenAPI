-- Lua provided by RyzenAPI
-- Game: Card Dungeon

-- MAIN APPLICATION
addappid(361130)

-- MAIN APP DEPOTS / PACKAGES
addappid(361131, 1, "9bd60db235dd9fa1a67bbce722f873f0160d95cdeb063cd617c9731d16abb8ab")
