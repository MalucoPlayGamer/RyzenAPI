-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Scent Of Mixed

-- MAIN APPLICATION
addappid(3478420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478421, 1, "7a8b6c04983343f3854fe49ffcb15fe474721872bf1e5f1bcf076f9a63457740")

