-- Lua provided by RyzenAPI
-- Game: 2776500

-- MAIN APPLICATION
addappid(2776500)
addappid(3204680)
-- Game: addappid(2776500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776501, 1, "64b6ebf9f232e6f678495c08effdedb960da104a62bc7a78eef3c45bdd07d4dd")
