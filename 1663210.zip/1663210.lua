-- Lua provided by RyzenAPI
-- Game: addappid(1663210)

-- MAIN APPLICATION
addappid(1663210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663211, 1, "38dc0abc98338de86057ef95dc89ceb3edcc24ba77768db24ee0e378d76912b6")
