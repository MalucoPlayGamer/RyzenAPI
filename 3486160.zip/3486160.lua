-- Lua provided by RyzenAPI
-- Game: 3486160

-- MAIN APPLICATION
addappid(3486160)
-- Game: addappid(3486160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486161, 1, "4294707af852c199238081711a53ecad02bbce02e72152f2fec6bf0fc6c35ffa")
