-- Lua provided by RyzenAPI
-- Game: 625560

-- MAIN APPLICATION
addappid(625560)
-- Game: addappid(625560)

-- MAIN APP DEPOTS / PACKAGES
addappid(625561, 1, "40d02f934cf33178acf565e00c68247cbc1eee499d6bf01d501b21afc3fc82ec")
