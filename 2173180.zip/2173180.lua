-- Lua provided by RyzenAPI 
-- Game: Jack
addappid(2173180)
addappid(2173181, 1, "497b8c1a05508d7daa30301e4912771cc15354c94f88bdb131405ce229ed383d")
