-- Lua provided by RyzenAPI
-- Game: Bridge2Code

-- MAIN APPLICATION
addappid(1547630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547631, 1, "38e20d08dd7990ccf5efaf326b8d115b39836524d3fcaf7dd7b8da368e3037f0")
addappid(1547632, 1, "e6448bd68fd25146962aa3d962e65fb2454bfe7f8e1482325275f7d56b14f53d")

