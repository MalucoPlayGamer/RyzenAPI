-- Lua provided by RyzenAPI
-- Game: Chill Drive

-- MAIN APPLICATION
addappid(2579840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579841, 1, "7ec965bc34d579b736ca7cc956f1aaecb70c87a13d7bcad7fb2c1380d2007b7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
