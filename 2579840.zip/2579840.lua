-- Lua provided by RyzenAPI
-- Game: Chill Drive

-- MAIN APPLICATION
addappid(2579840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579841, 1, "7ec965bc34d579b736ca7cc956f1aaecb70c87a13d7bcad7fb2c1380d2007b7b")

