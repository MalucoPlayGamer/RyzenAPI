-- Lua provided by RyzenAPI
-- Game: AppID 2967880

-- MAIN APPLICATION
addappid(2967880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967881, 1, "ca0faaaecc079f4113d0717f224bf8f7d6600e2acc16cc43cee58dc2c935d77f")
