-- Lua provided by RyzenAPI 
-- Game: AppID 2967880
addappid(2967880)
addappid(2967881, 1, "ca0faaaecc079f4113d0717f224bf8f7d6600e2acc16cc43cee58dc2c935d77f")
