-- Lua provided by RyzenAPI
-- Game: 《Drifting : Weight of Feathers》 Demo

-- MAIN APPLICATION
addappid(1509290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509291, 1, "ba45258b6def77a9b21b08a95dd6b87527e18bd01697b1a078c78807d38069de")

