-- Lua provided by RyzenAPI
-- Game: 2633910

-- MAIN APPLICATION
addappid(2633910)
-- Game: addappid(2633910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633911, 1, "fbe31866799bfb95edffae099bed86c2250d64b1571e064bfdaea95da296bbb6")
addappid(2633912, 1, "c68aea075773fa299221ffaf09472d69baf12ec25cfb86f5214266c96a6f6c15")
