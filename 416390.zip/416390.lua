-- Lua provided by RyzenAPI
-- Game: 416390

-- MAIN APPLICATION
addappid(416390)
-- Game: addappid(416390)

-- MAIN APP DEPOTS / PACKAGES
addappid(416391, 1, "6319d987bcffda62700ddf8208d726fd482111517c1c371e1e17e278330bb08d")
