-- Lua provided by RyzenAPI
-- Game: addappid(3181510)

-- MAIN APPLICATION
addappid(3181510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181510,0,"20b2ea8e1ee289d0343f81d99db015d3dd4c755c3cca078473382b49386a31e1")
