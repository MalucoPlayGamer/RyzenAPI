-- Lua provided by RyzenAPI
-- Game: Game: Love at First Sight

-- MAIN APPLICATION
addappid(353330)
-- Game: addappid(353330)

-- MAIN APP DEPOTS / PACKAGES
addappid(353331, 1, "aab077dd9b7830fb39e961d16fde345db4167e92ad715ede1f7e22b011a1e853")
