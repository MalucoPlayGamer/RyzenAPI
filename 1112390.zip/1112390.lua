-- 1112390's Lua and Manifest Created by Hubcap Manifest
-- HyperCore
-- Created: August 21, 2026 at 14:09:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1112390) -- HyperCore
-- MAIN APP DEPOTS
addappid(1112391, 1, "72747cd91eda212a5c45201aa13df3275d18e8c8223844a90821cd2bbd978f3d") -- Depot 1112391
setManifestid(1112391, "731524632339028727", 4975759747)
addappid(1112392, 1, "763b0d3465101c5b44ebf54effc44e2fa3ee2601aabacaef381ccce4b80e6cc3") -- Depot 1112392
setManifestid(1112392, "2577914003201526476", 0)