-- Lua provided by RyzenAPI
-- Game: HyperCore

-- MAIN APPLICATION
addappid(1112390) -- HyperCore

-- MAIN APP DEPOTS / PACKAGES
addappid(1112391, 1, "72747cd91eda212a5c45201aa13df3275d18e8c8223844a90821cd2bbd978f3d") -- Depot 1112391
addappid(1112392, 1, "763b0d3465101c5b44ebf54effc44e2fa3ee2601aabacaef381ccce4b80e6cc3") -- Depot 1112392

