-- Lua provided by RyzenAPI 
-- Game: Infinite Vector
addappid(830890)
addappid(830891, 1, "a57ff411317f26cc90ad27d446e84a3b2069a7575d7064ac6496b408b7edac61")
