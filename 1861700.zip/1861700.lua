-- Lua provided by SkyAPI 
-- Game: Drop one NPC to another
addappid(1861700)
addappid(1861701, 1, "00daad9060e7dd7120ae74694cf122f1e595954a80970a37f41e454fbbd6a764")
addappid(1886980)
