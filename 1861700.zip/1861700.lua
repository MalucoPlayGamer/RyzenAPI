-- Lua provided by RyzenAPI
-- Game: Game: Drop one NPC to another

-- MAIN APPLICATION
addappid(1861700)
addappid(1886980)
-- Game: addappid(1861700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861701, 1, "00daad9060e7dd7120ae74694cf122f1e595954a80970a37f41e454fbbd6a764")
