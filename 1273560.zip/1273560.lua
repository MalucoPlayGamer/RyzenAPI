-- Lua provided by RyzenAPI
-- Game: DeathSprint 66

-- MAIN APPLICATION
addappid(1273560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1273561, 1, "d7e5cc6f932b2f521fdfaf7ca8e32ff330ee6bc88e4392a4c7063ea50380ec5f")

