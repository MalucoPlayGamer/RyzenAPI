-- Lua provided by RyzenAPI
-- Game: DeathSprint 66

-- MAIN APPLICATION
addappid(1273560)
-- Game: addappid(1273560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273561, 1, "d7e5cc6f932b2f521fdfaf7ca8e32ff330ee6bc88e4392a4c7063ea50380ec5f")
