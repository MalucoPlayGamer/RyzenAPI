-- Lua provided by RyzenAPI
-- Game: 974180

-- MAIN APPLICATION
addappid(974180)
-- Game: addappid(974180)

-- MAIN APP DEPOTS / PACKAGES
addappid(974181, 1, "ea008ad796d82c33b98e85bfa33606f779416395225dddf221c58f7b02a12a78")
