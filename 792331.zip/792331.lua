-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(792331)

-- MAIN APP DEPOTS / PACKAGES
addappid(851400,0,"18b0dc2c98401cfd46682ff888e40bcee159f8933655cc361e4f829973e5ef5c")
addappid(851401,0,"dc1c93c5e8913607797d1adda7bd65239421020303c161349514b05342c93981")
addappid(851402,0,"c2da71111e43dcc33a38bcedfa53aee00a147dc7a048d471ab11b793863a92fe")
addappid(851403,0,"2ec0fdf4901f89817c01d92a8e92ce75afbbf79fe5ac2a9659398fd946a16504")
addappid(851404,0,"bec14a2710d038f291bb9d05d988ebd93a1c0ec4f0ee8ab7d788f7b18dad09b7")
addappid(851405,0,"e56d1d32c9f2ef0f12085a6ba20080c959dd61e504f5286458d3bae52b8c5d67")
addappid(851406,0,"c159c790689542384b83b2dd71527a307f242eee99fc28fed6fafb5c2281b994")
addappid(851407,0,"cc4d4bdec81fa451a9a891646e6dbd4203382dafce57ae4191ec213e8b5678be")
addappid(851408,0,"c97eac088823b66fcc2ce71ebd1e29654caf826826a92b2d8519fe2ae72a2bce")
