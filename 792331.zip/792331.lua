-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(792331)
addappid(851400,0,"18b0dc2c98401cfd46682ff888e40bcee159f8933655cc361e4f829973e5ef5c")
-- setManifestid(851400,"8299267786813933869")
addappid(851401,0,"dc1c93c5e8913607797d1adda7bd65239421020303c161349514b05342c93981")
-- setManifestid(851401,"3464417602491318630")
addappid(851402,0,"c2da71111e43dcc33a38bcedfa53aee00a147dc7a048d471ab11b793863a92fe")
-- setManifestid(851402,"1250424072390645719")
addappid(851403,0,"2ec0fdf4901f89817c01d92a8e92ce75afbbf79fe5ac2a9659398fd946a16504")
-- setManifestid(851403,"6010834097048815078")
addappid(851404,0,"bec14a2710d038f291bb9d05d988ebd93a1c0ec4f0ee8ab7d788f7b18dad09b7")
-- setManifestid(851404,"6558777678579415743")
addappid(851405,0,"e56d1d32c9f2ef0f12085a6ba20080c959dd61e504f5286458d3bae52b8c5d67")
-- setManifestid(851405,"8819129897409112103")
addappid(851406,0,"c159c790689542384b83b2dd71527a307f242eee99fc28fed6fafb5c2281b994")
-- setManifestid(851406,"9111932358512395579")
addappid(851407,0,"cc4d4bdec81fa451a9a891646e6dbd4203382dafce57ae4191ec213e8b5678be")
-- setManifestid(851407,"6334491182133462885")
addappid(851408,0,"c97eac088823b66fcc2ce71ebd1e29654caf826826a92b2d8519fe2ae72a2bce")
-- setManifestid(851408,"3866091803819272626")