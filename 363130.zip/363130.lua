-- Lua provided by RyzenAPI
-- Game: Toukiden: Kiwami

-- MAIN APPLICATION
addappid(363130)
addappid(376611)
addappid(377790)

-- MAIN APP DEPOTS / PACKAGES
addappid(363131, 1, "43fc61c36e43f633efabdea9293458e7488e97bb4f047dc7709cace9baf32ba7")
addappid(376610, 0, "9e6cba4f42a5b9ed70df73f8d844d223558678529cd2b993ff201a634a9ce872")
addappid(379590, 0, "a7c885b66aeab3b5ab782796a5ebcf4bf8e2d33a85749040ee232113e73b534f")
addappid(380900, 0, "6f76aa023dcaed6a0659680afde5caa2b50a97040f77f1444d455b34134090af")
addappid(380901, 0, "2b4b3458e38b54f9a3d510b16252d73e07ffe15f96c189e7cfd2b29bc0480caa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
