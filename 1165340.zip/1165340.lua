-- Lua provided by RyzenAPI
-- Game: The Leopard Catgirl in Miaoli -Original Sound Track-

-- MAIN APPLICATION
addappid(1165340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165340,0,"bee0ea8ebe000a50f676423513946e728025b86a81c18b20cb627e3e5b36a72e")

