-- Lua provided by RyzenAPI
-- Game: 834910

-- MAIN APPLICATION
addappid(834910)
-- Game: addappid(834910)

-- MAIN APP DEPOTS / PACKAGES
addappid(834911, 1, "5934a46827146d5b1a85650ab1b774e6758b94bd5db93d5beca4c8fa5dd2d1d9")
addappid(1129370, 0, "47344aec4a466954eddb06d464a30eb7fe336949288eb4b511adddde1af483a5")
