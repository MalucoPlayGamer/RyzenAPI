-- Lua provided by RyzenAPI
-- Game: ATLAS

-- MAIN APPLICATION
addappid(834910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(834911, 1, "5934a46827146d5b1a85650ab1b774e6758b94bd5db93d5beca4c8fa5dd2d1d9")
addappid(1129370, 0, "47344aec4a466954eddb06d464a30eb7fe336949288eb4b511adddde1af483a5")
