-- Lua provided by RyzenAPI
-- Game: Veloria: The Knot of Candle - Digital Companion

-- MAIN APPLICATION
addappid(3706240)
-- Game: addappid(3706240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706240,0,"03df21931ff9f9b000c43fa7387116bf6183da63d8a0a1f726b6150e19b64dae")
