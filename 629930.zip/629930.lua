-- Lua provided by RyzenAPI
-- Game: addappid(629930)

-- MAIN APPLICATION
addappid(629930)

-- MAIN APP DEPOTS / PACKAGES
addappid(629931, 1, "15aabf292cf8cf590cf21bd3b946c41d5bac32bb4c0319bf218d226d8e9523bf")
