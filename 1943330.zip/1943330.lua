-- Lua provided by RyzenAPI 
-- Game: Nightmare of Decay Demo
addappid(1943330)
addappid(1943331, 1, "d9d4b8efa6af0c65423f9b598f626f7964da411aa40733fbacb14d5e70b2e55a")
