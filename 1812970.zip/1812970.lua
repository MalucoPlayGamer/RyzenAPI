-- Lua provided by RyzenAPI
-- Game: Immortal Tactics: War of the Eternals

-- MAIN APPLICATION
addappid(1812970)
-- Game: addappid(1812970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812971, 1, "9455064f8c2016dabb8c24bae7de8583884e0bcf0c5839514c4cc33136299141")
