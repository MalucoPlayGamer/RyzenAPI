-- Lua provided by SkyAPI 
-- Game: The Nightmare Cooperative
addappid(310070)
addappid(310071, 1, "42945f1594bb29fcd6ec3f6ae9894ee00907ee60f9ee210c48c6e5b8a67f17f6")
addappid(310072, 1, "9aa39e30bf106eebafdf9fbfb6701b9d9f98ee78ba8f3ec233230c8ca9b4d18d")
addappid(310073, 1, "8d4cad10399293388170c2f9b3995ef710bec4acafbc82782235973c1b4894c4")
