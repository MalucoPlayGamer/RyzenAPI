-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3140610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140610,0,"5b845b6264a072d79829e3ff6e57e97ad841fd9e51d65ea35f3c97ac3727f92b")
