-- Lua provided by RyzenAPI
-- Game: addappid(2237940)

-- MAIN APPLICATION
addappid(2237940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237941, 1, "18ce528d50d3aee886878d04cee341fbc1156c24839c1fdc4258691798a88bd8")
