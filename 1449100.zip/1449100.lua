-- Lua provided by RyzenAPI
-- Game: Kore

-- MAIN APPLICATION
addappid(1449100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449101, 1, "1ea60134b87fb7dc36d5c7465c9a1f5bc68895f2b0e36b8b3b04c0aaffd0a6b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
