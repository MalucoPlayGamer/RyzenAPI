-- Lua provided by RyzenAPI 
-- Game: Kore
addappid(1449100)
addappid(1449101, 1, "1ea60134b87fb7dc36d5c7465c9a1f5bc68895f2b0e36b8b3b04c0aaffd0a6b3")
