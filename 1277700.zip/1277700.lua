-- Lua provided by RyzenAPI
-- Game: Goat of Duty Digital ArtBook

-- MAIN APPLICATION
addappid(1277700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277700,0,"e09b8443b0dbf0f6d90a2d0cef5a0cf8c92f31c56fefbc6097c084394d8bc34d")

