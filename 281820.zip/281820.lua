-- Lua provided by SkyAPI 
-- Game: Explodemon
addappid(281820)
addappid(281821, 1, "29a48ea2e266db8a430c17a8e0eea9ef80e7ec36a0d025c20cb44c07d77ca3c1")
