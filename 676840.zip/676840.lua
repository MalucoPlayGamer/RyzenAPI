-- Lua provided by RyzenAPI
-- Game: addappid(676840)

-- MAIN APPLICATION
addappid(676840)

-- MAIN APP DEPOTS / PACKAGES
addappid(676841, 1, "54cfdc0cd115ff5fb39c1e3295540d630b869d13d2635e9767fa321504a09099")
