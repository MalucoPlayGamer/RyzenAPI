-- Lua provided by RyzenAPI
-- Game: Contagion VR: Outbreak

-- MAIN APPLICATION
addappid(676840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(676841, 1, "54cfdc0cd115ff5fb39c1e3295540d630b869d13d2635e9767fa321504a09099")

