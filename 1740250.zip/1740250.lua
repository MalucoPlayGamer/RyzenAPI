-- Lua provided by RyzenAPI
-- Game: Strange Town

-- MAIN APPLICATION
addappid(1740250)
-- Game: addappid(1740250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740251, 1, "0e194be8e38b6b7271d123fb34659070ada88a6daf7dd276fb293c1e402c9bff")
