-- Lua provided by RyzenAPI
-- Game: 1432161

-- MAIN APPLICATION
addappid(1432161)
-- Game: addappid(1432161)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432161,0,"ca9c9eb7307ad61c6c9b1b33861c20f53f1e3bcd41a9b8b15fa62a6c5fdef7e1")
