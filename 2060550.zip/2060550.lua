-- Lua provided by RyzenAPI 
-- Game: Fabular: Prologue
addappid(2060550)
addappid(2060551, 1, "ddb7e073036b8bd0a349b7ae8d135325697fa6b1bcc12518aa1c5f5f529f9375")
