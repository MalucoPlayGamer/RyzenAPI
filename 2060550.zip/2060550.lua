-- Lua provided by RyzenAPI
-- Game: Game: Fabular: Prologue

-- MAIN APPLICATION
addappid(2060550)
-- Game: addappid(2060550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060551, 1, "ddb7e073036b8bd0a349b7ae8d135325697fa6b1bcc12518aa1c5f5f529f9375")
