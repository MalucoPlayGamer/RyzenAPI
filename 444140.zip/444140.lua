-- Lua provided by RyzenAPI
-- Game: AppID 444140

-- MAIN APPLICATION
addappid(444140)
-- Game: addappid(444140)

-- MAIN APP DEPOTS / PACKAGES
addappid(444141, 1, "f3ad9233a3405867bc6f70ee5cc7b39e5a15c798251e1abd0ed4b0cc0c89ffcc")
