-- Lua provided by RyzenAPI
-- Game: Sonicomi

-- MAIN APPLICATION
addappid(444140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(444141, 1, "f3ad9233a3405867bc6f70ee5cc7b39e5a15c798251e1abd0ed4b0cc0c89ffcc")

