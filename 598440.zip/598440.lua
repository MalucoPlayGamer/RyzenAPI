-- Lua provided by RyzenAPI
-- Game: Roots of Insanity

-- MAIN APPLICATION
addappid(598440)

-- MAIN APP DEPOTS / PACKAGES
addappid(598441, 1, "0907e8a6980817857e1ed1674feef1a8db96e79eda64dc1c5627649c3264f538")
