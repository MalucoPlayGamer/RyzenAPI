-- Lua provided by RyzenAPI
-- Game: Hentai Killer

-- MAIN APPLICATION
addappid(1157340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157341, 1, "8f2d7e2f9b9262925a6d87ed40a65d5573322c01fe32dfc5253e667fc233480f")
