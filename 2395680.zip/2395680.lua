-- Lua provided by RyzenAPI
-- Game: Unyielding Succubus Princess of Arrogance

-- MAIN APPLICATION
addappid(2395680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395682,0,"dea16acdefc442c52a9c3b93f63808ad7bdf89a9a4cb3d110ca45c8569990911")
addappid(2395683,0,"e22d4e34fb0f4941348cd38c0a2865a9f996beb8d77db197339e3014235af67b")
