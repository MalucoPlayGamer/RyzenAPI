-- Lua provided by RyzenAPI
-- Game: Grim Diary

-- MAIN APPLICATION
addappid(3723410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723411, 1, "a8c5bd1d5819cdfc3f0b65e3d15aecde0f00dcc0578ccb9877e0ca793e63681b")

