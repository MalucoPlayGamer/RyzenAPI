-- Lua provided by RyzenAPI
-- Game: Rogue AI Simulator Demo

-- MAIN APPLICATION
addappid(1976560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976561, 1, "d0e96c9417010a214369737a861ad6f6579dfb5345fba5ddddf27305fb55df64")

