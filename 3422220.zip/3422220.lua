-- Lua provided by RyzenAPI
-- Game: addappid(3422220)

-- MAIN APPLICATION
addappid(3422220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422221, 1, "fcca2b659fd65d906c32a75d69389bc6dab8b0139fb89a298b8e6eff02b17c89")
