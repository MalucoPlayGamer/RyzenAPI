-- Lua provided by RyzenAPI
-- Game: AppID 211010

-- MAIN APPLICATION
addappid(211010)

-- MAIN APP DEPOTS / PACKAGES
addappid(211011, 1, "435d56c637df27ec1f9775a391e261a199778c5ee19e983718898559cb759183")
addappid(211012, 1, "fabfc6babecf7c7d86a990aec85d6e19098a75d99daf3b6ad32bcf31f5474866")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

