-- Lua provided by RyzenAPI
-- Game: AppID 273240

-- MAIN APPLICATION
addappid(273240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(273241, 1, "e4d9c8c379570bd2e9bcc4dc63b43eaa714eb2ddb1dff17ad72da37676fd5569")

