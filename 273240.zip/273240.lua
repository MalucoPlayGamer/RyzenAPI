-- Lua provided by RyzenAPI
-- Game: AppID 273240

-- MAIN APPLICATION
addappid(273240)
-- Game: addappid(273240)

-- MAIN APP DEPOTS / PACKAGES
addappid(273241, 1, "e4d9c8c379570bd2e9bcc4dc63b43eaa714eb2ddb1dff17ad72da37676fd5569")
