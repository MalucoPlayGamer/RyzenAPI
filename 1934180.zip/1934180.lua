-- Lua provided by RyzenAPI
-- Game: Hot“Sento Girls”and love

-- MAIN APPLICATION
addappid(1934180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1934181, 1, "84e0f0803b22659b3a8a3008515e9ea948c519e6a1357acbd03afdfb6992b613")

