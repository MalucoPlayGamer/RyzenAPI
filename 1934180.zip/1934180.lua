-- Lua provided by RyzenAPI 
-- Game: Hot“Sento Girls”and love
addappid(1934180)
addappid(1934181, 1, "84e0f0803b22659b3a8a3008515e9ea948c519e6a1357acbd03afdfb6992b613")
