-- Lua provided by RyzenAPI
-- Game: Republique VR

-- MAIN APPLICATION
addappid(915200)

-- MAIN APP DEPOTS / PACKAGES
addappid(915201, 1, "8c87a9497ca0261a05cc7433eae70b2ed2f5ed8e201db76ff5864dcfaaa4bc0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
