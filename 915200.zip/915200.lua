-- Lua provided by RyzenAPI
-- Game: Game: Republique VR

-- MAIN APPLICATION
addappid(915200)
-- Game: addappid(915200)

-- MAIN APP DEPOTS / PACKAGES
addappid(915201, 1, "8c87a9497ca0261a05cc7433eae70b2ed2f5ed8e201db76ff5864dcfaaa4bc0f")
