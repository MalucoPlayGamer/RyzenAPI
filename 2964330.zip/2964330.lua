-- Lua provided by RyzenAPI
-- Game: Suika Watermelon Fruits

-- MAIN APPLICATION
addappid(2964330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964331, 1, "c8c483bfe5c7a5ef08d5dd9ce2c078f044a4aa880dc62a48dcda5ff0c0387ce2")

