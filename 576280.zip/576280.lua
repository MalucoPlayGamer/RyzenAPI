-- Lua provided by RyzenAPI
-- Game: Arena Hero

-- MAIN APPLICATION
addappid(576280)

-- MAIN APP DEPOTS / PACKAGES
addappid(576281, 1, "0a62749a611c216ed1c07353efbe3013925d32a351a6e01e1edda7a2cf7dd96b")

