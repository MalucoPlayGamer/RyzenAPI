-- Lua provided by RyzenAPI
-- Game: 1030380

-- MAIN APPLICATION
addappid(1030380)
-- Game: addappid(1030380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030381, 1, "b5c902821b9e2a516260277f82b3dc82e20aafd08125b83cb1d046186b0a9dfd")
