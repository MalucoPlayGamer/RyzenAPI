-- Lua provided by RyzenAPI
-- Game: Epistory - Typing Chronicles

-- MAIN APPLICATION
addappid(398850)

-- MAIN APP DEPOTS / PACKAGES
addappid(398851, 1, "ce7c069d0969b28de0426e5d88b32eed2446a259aa4979815a3c277581531543")
addappid(398852, 1, "88b203fab20a03ab44a82714ef8cf104bcabd3cfe7c4a4334a1bdf4d92ba319c")
addappid(398853, 1, "b0821b4238128a867a4a453c932ac70016aac2e60b817f8ca031a334bff69f4c")
addappid(398854, 1, "436c91180e2aa41e47d3ec0f6292af1bda8f9400cc10d5df80929e5b375a15ba")

