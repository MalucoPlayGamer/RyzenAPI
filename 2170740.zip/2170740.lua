-- Lua provided by RyzenAPI
-- Game: Potionomics - Artbook

-- MAIN APPLICATION
addappid(2170740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170740,0,"30b379e5a3efc74751b754c5f454b21a7b1598e170d6dba21b309fff47015fa8")
