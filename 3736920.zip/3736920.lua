-- Lua provided by RyzenAPI
-- Game: Bus Flipper: Renovator Simulator Demo

-- MAIN APPLICATION
addappid(3736920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3736921, 1, "406b4b73c39a327a0690ecb83e1a040706470bf60f50b2d3fa23a4805beb2f91")

