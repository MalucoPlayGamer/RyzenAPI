-- Lua provided by RyzenAPI
-- Game: Loot Box Simulator

-- MAIN APPLICATION
addappid(889240)
-- Game: addappid(889240)

-- MAIN APP DEPOTS / PACKAGES
addappid(889241, 1, "8989700e53b14dc80e233ab6352bbc2709de5d74f5f2e0fbea1b2706249ccaa9")
