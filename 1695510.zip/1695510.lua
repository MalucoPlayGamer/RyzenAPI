-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス19 マジカルドロップDX

-- MAIN APPLICATION
addappid(1695510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695511, 1, "3aace6c4a96b242b5f76ee8a7738a3023aa044a6546475ab256c85477b95f9ed")
