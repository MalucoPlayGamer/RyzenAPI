-- Lua provided by RyzenAPI
-- Game: Deadly Premonition: The Director's Cut

-- MAIN APPLICATION
addappid(247660)

-- MAIN APP DEPOTS / PACKAGES
addappid(247661, 1, "81d8f5f9f1d7c135fabb5c00d1a639991225b4dbd03b59f0195649dad01aab79")
addappid(256240, 0, "7e899ef565ff363fbb15449b503b26d2fa59a7ae9966b30d8a68cab2612e1322")
