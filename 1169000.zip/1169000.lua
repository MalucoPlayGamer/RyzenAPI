-- Lua provided by SkyAPI 
-- Game: TORINTO
addappid(1169000)
addappid(1169001, 1, "91ce482dc9d094c8aca9cb2fb7d52f7ff15ee7edfd98bf74107f0942e06cde8c")
