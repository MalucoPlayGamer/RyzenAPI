-- Lua provided by RyzenAPI
-- Game: 东方远空界 ~ Ultimate Vitality of Imagination

-- MAIN APPLICATION
addappid(1700220)
-- Game: addappid(1700220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700221, 1, "96adc6d59866bbc0c84b0ed6d2a06cfc2bf374ed928ef5341358f696c3c37122")
