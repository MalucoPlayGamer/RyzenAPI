-- Lua provided by RyzenAPI
-- Game: Click Your Crush!

-- MAIN APPLICATION
addappid(1597560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597561, 1, "b041745038bf8c0a7224706dcf7c78674edb53bf7c9472b4f8b76e6b29a476e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
