-- Lua provided by RyzenAPI
-- Game: 1597560

-- MAIN APPLICATION
addappid(1597560)
-- Game: addappid(1597560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597561, 1, "b041745038bf8c0a7224706dcf7c78674edb53bf7c9472b4f8b76e6b29a476e4")
