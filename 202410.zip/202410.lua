-- Lua provided by RyzenAPI
-- Game: Game: Scoregasm

-- MAIN APPLICATION
addappid(202410)
-- Game: addappid(202410)

-- MAIN APP DEPOTS / PACKAGES
addappid(202411, 1, "c49623d716dcc6446030c73065d24a1e459ebfb0758db272ae7a7194168ad560")
addappid(202412, 0, "fc3c7b0585d5e7f1013888a158ab51d9253bb82ede81049d1ea4c47a85eecb93")
addappid(202413, 1, "989eed3623de58170cfdafd1d64c1538b4e65233a87d0a51a870e2b4237158a4")
