-- Lua provided by RyzenAPI
-- Game: 1022465

-- MAIN APPLICATION
addappid(1022465)
-- Game: addappid(1022465)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022465,0,"15b3ab1743c8800cc55a2b956dcdb8352ab72d4b7ed87066f85820d54adc15bf")
