-- Lua provided by RyzenAPI
-- Game: Game: Hentai Vampire

-- MAIN APPLICATION
addappid(1119100)
addappid(1131500)
-- Game: addappid(1119100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119101, 1, "0859b252179f54a1a1cc32ec97aa4607df42fd550386123e5d7146f3e6014b06")
