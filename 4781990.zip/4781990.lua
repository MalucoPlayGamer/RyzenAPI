-- Lua provided by RyzenAPI
-- Game: Rain Station Z

-- MAIN APPLICATION
addappid(4781990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4781991,0,"5149dc86ad06bf5eed6962f34425d06ceff420c5386e2b3cdefcef73ce9d2922")

