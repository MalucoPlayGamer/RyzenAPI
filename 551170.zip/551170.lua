-- Lua provided by RyzenAPI
-- Game: AppID 551170

-- MAIN APPLICATION
addappid(551170)
-- Game: addappid(551170)

-- MAIN APP DEPOTS / PACKAGES
addappid(551171, 1, "1177fe761a87f3644c11981b2f2d2c69a79d4ecb28fc1967f2a59c20b94a3737")
