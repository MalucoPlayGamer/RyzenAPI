-- Lua provided by RyzenAPI
-- Game: Conflicks - Revolutionary Space Battles

-- MAIN APPLICATION
addappid(288260)

-- MAIN APP DEPOTS / PACKAGES
addappid(288261, 1, "bfb803b63a665410c197e5f2c474c1779b04bf0c93f4f71bb4619307fb38bcec")
addappid(288262, 1, "b7555f06e12ddfc7a5ed9cd55e6b7ec530c759219bc42f51a93cffbb27ffa9db")
addappid(288263, 1, "e6196b518592d439164c1b2d532195027a283d7f3b98953bfc481a83da4cd222")

