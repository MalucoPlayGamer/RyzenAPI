-- Lua provided by SkyAPI 
-- Game: TNMverse VIP
addappid(2631910)
addappid(2631911, 1, "d8b2e1d611ef3faeff767e07201bb2c318f40ba540e47b7d504772533c3f1ff4")
