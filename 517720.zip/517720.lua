-- Lua provided by RyzenAPI
-- Game: Game: Epic Tavern

-- MAIN APPLICATION
addappid(517720)
-- Game: addappid(517720)

-- MAIN APP DEPOTS / PACKAGES
addappid(517721, 1, "c097033a9a05908a02c0e4c3ba491d1a52324f834f6ce080683c9cea7b737b4f")
