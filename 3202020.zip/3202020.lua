-- Lua provided by RyzenAPI
-- Game: The Riftbreaker: Multiplayer Playtest

-- MAIN APPLICATION
addappid(3202020)
-- Game: addappid(3202020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202021, 1, "84e57b2ce86e5a998aeb674f8dcd9f4a4756737a42e499b3e26bbf654edcf484")
