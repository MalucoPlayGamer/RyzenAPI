-- Lua provided by RyzenAPI
-- Game: Knockout Daddy

-- MAIN APPLICATION
addappid(1219740)
addappid(1220970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1219741, 1, "be7dcb15bc20970ab0ee1c10862f0fbc1e56c70b2593f29cd71ecdfdc14a8b3a")
addappid(1219742, 1, "93fa5270c87ebef7dbfac56a6424dd96469ec32039ef2492aad13def1ab7d12c")
addappid(1219743, 1, "53de479852128f3775811beb85864bc3a9cc0c6736db718cd09a4bd8a07e12a3")

