-- Lua provided by RyzenAPI
-- Game: We Were Here

-- MAIN APPLICATION
addappid(582500)
-- Game: addappid(582500)

-- MAIN APP DEPOTS / PACKAGES
addappid(582501, 1, "a2ab8a8cfa82778d504311ac95ed3fff638e43f6ae539ca79ae579f543a971ef")
addappid(582504, 1, "d09f7c09049892abae6089e76e5eaa403d0ccd2a2712b3b76ea453038731fadf")
