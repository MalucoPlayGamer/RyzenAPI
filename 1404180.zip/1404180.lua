-- Lua provided by RyzenAPI
-- Game: 1404180

-- MAIN APPLICATION
addappid(1404180)
-- Game: addappid(1404180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404182,0,"496d02b3c018ae8760dee6e8cc406199d4ee465377aba128a11a0b9454deb6d0")
