-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Weapons Icon Set

-- MAIN APPLICATION
addappid(3386610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386610,0,"2e60747c9d46e079d77634e5abc01db5664ba9ffbbee6c683ee16b166b04962a")

