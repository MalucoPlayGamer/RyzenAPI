-- Lua provided by RyzenAPI
-- Game: Beat Saber - BTS - "Not Today"

-- MAIN APPLICATION
addappid(1463270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463270,0,"2d04324bd1b0770de341bf1026aa70e3a289c5fb3b9b632ed4b08418aa25e662")
addappid(1463272,0,"f4ca2b5c54caedee4ec98c346c8afec3f7546133953869e1688341ac8d225e89")
