-- Lua provided by RyzenAPI
-- Game: addappid(2985530)

-- MAIN APPLICATION
addappid(2985530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985531, 1, "c8497aa35afd14b00efb091c792b6b53c0dd3c43bd14094436423da4d6e6a2c6")
