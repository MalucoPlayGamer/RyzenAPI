-- Lua provided by RyzenAPI
-- Game: Spider Queen cave

-- MAIN APPLICATION
addappid(1197180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197181, 1, "08713bc991bf21e4ef09cd15c901d23632a4f012ca9d20af3d09b77e1614315c")
