-- Lua provided by RyzenAPI
-- Game: Game: Gripper's 3D/VR Adventure

-- MAIN APPLICATION
addappid(3549440)
-- Game: addappid(3549440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549441, 1, "8d205086ebdc84dff3bc5855802a5e0c0b27ab9bab57bff88e48c18df40a304f")
