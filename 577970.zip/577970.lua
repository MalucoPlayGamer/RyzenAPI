-- Lua provided by RyzenAPI
-- Game: Punch Planet

-- MAIN APPLICATION
addappid(1052860) -- Costume - Cid - Commando
addappid(1059480) -- Costume - Dog - Terminate
addappid(1062300) -- Costume - Roy - Luna PD
addappid(1204820) -- Costume - Maxx - Lunar League
addappid(1206390) -- Costume - Agent - Prototype
addappid(1206400) -- Costume - Tyara - Huntress
addappid(1600540) -- Costume - ARN-01D - The K-0 Wars
addappid(1600541) -- Costume - Gat - Vizier

-- MAIN APP DEPOTS / PACKAGES
addappid(577970, 1, "c63a72a6087f422ab81f9d233cc078c28ddf285719d205e311450fecc3a0e284") -- Punch Planet
addappid(577971, 1, "f81fc63373c158a93c6fe78ac870055655e35a6960da7dbdf287da138245f375") -- Punch Planet Content
