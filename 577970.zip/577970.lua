-- Lua provided by RyzenAPI
-- Game: Punch Planet

-- MAIN APPLICATION
addappid(577970)

-- MAIN APP DEPOTS / PACKAGES
addappid(577971, 1, "f81fc63373c158a93c6fe78ac870055655e35a6960da7dbdf287da138245f375")
