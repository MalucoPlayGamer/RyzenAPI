-- Lua provided by RyzenAPI
-- Game: 3041090

-- MAIN APPLICATION
addappid(3041090)
-- Game: addappid(3041090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041091, 1, "37bc468045c4960ea4fb5d62ca79ecc5b2d47d945fe60bc48f27121beb934078")
addappid(3041092, 1, "a0bf08b76d6cf0c86ddc6aa2f7e24077e20e3c575c57f375b5b4ce9cec9ad98e")
