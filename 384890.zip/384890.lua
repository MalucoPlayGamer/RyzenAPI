-- Lua provided by RyzenAPI
-- Game: Game: Hack Run ZERO

-- MAIN APPLICATION
addappid(384890)
-- Game: addappid(384890)

-- MAIN APP DEPOTS / PACKAGES
addappid(384891, 1, "cea17348191956151e3a03ecfe5b07a0c37a0c0d1f6fcf57826630ffc939f914")
