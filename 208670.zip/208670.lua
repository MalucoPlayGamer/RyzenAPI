-- Lua provided by RyzenAPI
-- Game: Blades of Time

-- MAIN APPLICATION
addappid(208670)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(208671, 1, "78bea053d56238ec09fb5a2bfa991e52b2300a1099a0bc0f15a3bca4e2b36988")
addappid(208672, 1, "2344ee299632df68b096699804ec86276226837a6fd5ab2572382862e6008e94")
addappid(208673, 1, "24b1565038b5f877765ca891cfceeba446e417bed6d3799adfa13bf88dba0c82")
addappid(208981, 0, "eeb272cbaf693bc430391f939afa17c97bc34b8d66b85f42ed151fe239f9f511")
addappid(208982, 1, "8d4c38a7bd38db308a40aac557d82a0e154b86a7bb7980cb9d8710465b9a29ca")
addappid(208985, 1, "3c7aeadab2e3af394e7fd91d10981639b127689618c7593599c97407a57c03ba")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(208980)
addappid(208983)
addappid(208984)
