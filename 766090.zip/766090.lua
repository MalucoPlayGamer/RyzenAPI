-- Lua provided by RyzenAPI
-- Game: We Walked In Darkness

-- MAIN APPLICATION
addappid(766090)
-- Game: addappid(766090)

-- MAIN APP DEPOTS / PACKAGES
addappid(766091, 1, "e0cb827064fb2a33323679ff137122a4b1275a6b4748896b35533d63270432ec")
