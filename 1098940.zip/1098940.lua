-- Lua provided by RyzenAPI
-- Game: Home Sweet Home EP2

-- MAIN APPLICATION
addappid(1098940)
-- Game: addappid(1098940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098941, 1, "e62c2dbe711e77d44ddc52b0de32e3c32b08e79f526f80078608a780b3be6582")
