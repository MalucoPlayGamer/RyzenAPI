-- Lua provided by RyzenAPI 
-- Game: AudiobookConverter
addappid(1529240)
addappid(1529241, 1, "a500200598dfdb3833c7f7eaa11ee664f30ba33373d3472cacda4556ae704cc2")
