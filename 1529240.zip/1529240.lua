-- Lua provided by RyzenAPI
-- Game: AudiobookConverter

-- MAIN APPLICATION
addappid(1529240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529241, 1, "a500200598dfdb3833c7f7eaa11ee664f30ba33373d3472cacda4556ae704cc2")

