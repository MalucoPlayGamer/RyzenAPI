-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin PixelScapes Forest Pack

-- MAIN APPLICATION
addappid(2996360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996360,0,"bc479e510075416892a729b74f8b0619305b49899d6d0d155b8091947652a9a2")
