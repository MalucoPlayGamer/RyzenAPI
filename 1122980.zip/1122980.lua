-- Lua provided by SkyAPI 
-- Game: Hentai Shojo
addappid(1122980)
addappid(1122981, 1, "cd11dc5a274f9d569c9177b14eb737a5c130b41375009c1819b20b6002803b48")
