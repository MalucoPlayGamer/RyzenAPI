-- Lua provided by RyzenAPI
-- Game: Game: Hentai Shojo

-- MAIN APPLICATION
addappid(1122980)
-- Game: addappid(1122980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122981, 1, "cd11dc5a274f9d569c9177b14eb737a5c130b41375009c1819b20b6002803b48")
