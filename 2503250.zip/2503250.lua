-- Lua provided by RyzenAPI
-- Game: Game: Roam Across

-- MAIN APPLICATION
addappid(2503250)
-- Game: addappid(2503250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503251, 1, "a51638da2643cf0b6638735bedf67fbaa20066b865baaa2c0ca94ad63657703b")
