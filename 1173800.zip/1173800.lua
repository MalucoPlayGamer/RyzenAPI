-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY IV

-- MAIN APPLICATION
addappid(1173800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1173801, 1, "81eeba512901afad70a794fda96e542241c5baf0127035bbe2b0cd961cc3effe")
addappid(1638380, 0, "fda1ebeaed0a78c3763208ab93f284009638971d4b66c335df4896b6a91a26e2")

