-- Lua provided by RyzenAPI
-- Game: Beauty Girl Chronicles: Island Obstacle Challenge Demo

-- MAIN APPLICATION
addappid(3004200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004201, 1, "f92f41143444101fe1fdb5a9c65262b09302ae18f0ed5491db5774fe57aed60f")
