-- Lua provided by RyzenAPI
-- Game: Endless Fireworks Simulator

-- MAIN APPLICATION
addappid(2286880)
-- Game: addappid(2286880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286881, 1, "c780a67d11bd14afa258d569b5b0f36ea9a5dc624860b548abebbbb09321895b")
