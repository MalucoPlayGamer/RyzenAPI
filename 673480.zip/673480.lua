-- Lua provided by RyzenAPI
-- Game: Game: Timbertales

-- MAIN APPLICATION
addappid(673480)
-- Game: addappid(673480)

-- MAIN APP DEPOTS / PACKAGES
addappid(673481, 1, "b7b39d5aa435b0fb2fc957ae9d01e89b35f8a43000d1226aefe977ff3b7e3c62")
addappid(673482, 1, "c28dd9d384f39096bbb0915a22ff25a9ce671554de5c359220f34e291c920bca")
addappid(673483, 1, "85ca102fa76ae35cdd957f6db0d571096a4a0d6b12f849364b7b0d72268de8f9")
