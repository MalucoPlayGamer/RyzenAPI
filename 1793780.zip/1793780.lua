-- Lua provided by RyzenAPI 
-- Game: Poly Memory: Furries 2
addappid(1793780)
addappid(1793781, 1, "a38877507567f20f504456969fa183b9236c25a43381dfe4135dcd5198c541f4")
