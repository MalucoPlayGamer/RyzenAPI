-- Lua provided by RyzenAPI
-- Game: Hobo Cat Adventures

-- MAIN APPLICATION
addappid(1438090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438091, 1, "3580b50900edd85fa3dbdad5fb2a3398e112ed3e8ccd580df3fdc39489b34ee1")
