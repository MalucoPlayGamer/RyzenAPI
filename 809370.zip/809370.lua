-- Lua provided by RyzenAPI
-- Game: !4RC4N01D! 3: Cold Space

-- MAIN APPLICATION
addappid(809370)

-- MAIN APP DEPOTS / PACKAGES
addappid(809371, 1, "4613559f5e93c5006045e8c71fd7a631d59bfb95cf8a4782d05c62dd94e579d0")
