-- Lua provided by RyzenAPI
-- Game: AppID 1888750

-- MAIN APPLICATION
addappid(1888750)
-- Game: addappid(1888750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888751, 1, "4f222eda94f2a999d8bef9c515e9a5a0ef43a16662b3e7116e92b798199b9b70")
