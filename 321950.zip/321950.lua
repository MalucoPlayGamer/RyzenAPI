-- Lua provided by RyzenAPI
-- Game: Yury

-- MAIN APPLICATION
addappid(321950)
-- Game: addappid(321950)

-- MAIN APP DEPOTS / PACKAGES
addappid(321951, 1, "a3b2be692f4cca1512bc558530fb67a2a50ed2243582b8d0e9ebcaaf3ea7af6d")
addappid(321952, 1, "599a1957bf11a8bd8421bf456d38ed90f35b00a94cea4a6f5a61f8ec9de37305")
addappid(321953, 1, "805a3cd3b58a6d6d482263a11cf818a28c282db92ba9bdbeb3395071a56b9990")
