-- Lua provided by RyzenAPI
-- Game: 1958340

-- MAIN APPLICATION
addappid(1958340)
-- Game: addappid(1958340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958341, 1, "fe299ec04331e8d79d96236840bdfb7f68d5bfdcd56f294d95277db13b3bbd08")
addappid(1958343, 1, "87277355be83d4928bb5f809414a2d483bdd16e4ca7ca35bd19df0725d1d4443")
