-- Lua provided by RyzenAPI
-- Game: Dungeon Rushers - Veterans Skins Pack

-- MAIN APPLICATION
addappid(581950)

-- MAIN APP DEPOTS / PACKAGES
addappid(581950,0,"d494a227a857ab5dcae6572e3475a1564fca3f882f4783a027bd86e4d479933d")

