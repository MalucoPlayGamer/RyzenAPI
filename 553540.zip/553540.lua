-- Lua provided by SkyAPI 
-- Game: AppID 553540
addappid(553540)
addappid(553541, 1, "bb9ac408ba5f99dd9165f146bd8ec58038354d0645454b00a1dad6bf7aefa7ba")
