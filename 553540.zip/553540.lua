-- Lua provided by RyzenAPI
-- Game: AppID 553540

-- MAIN APPLICATION
addappid(553540)

-- MAIN APP DEPOTS / PACKAGES
addappid(553541, 1, "bb9ac408ba5f99dd9165f146bd8ec58038354d0645454b00a1dad6bf7aefa7ba")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3782180)
