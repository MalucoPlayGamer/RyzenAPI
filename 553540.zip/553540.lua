-- Lua provided by RyzenAPI
-- Game: Phantom Brigade

-- MAIN APPLICATION
addappid(553540)
addappid(3782180)

-- MAIN APP DEPOTS / PACKAGES
addappid(553541, 1, "bb9ac408ba5f99dd9165f146bd8ec58038354d0645454b00a1dad6bf7aefa7ba")

