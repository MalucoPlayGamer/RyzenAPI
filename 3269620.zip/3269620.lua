-- Lua provided by RyzenAPI
-- Game: Archaeology - Frozen Knights

-- MAIN APPLICATION
addappid(3269620)
-- Game: addappid(3269620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269621, 1, "23bb86f89845d8ac9c5e629706f6abce7b4c677d50be0942bba0577abe3b257a")
