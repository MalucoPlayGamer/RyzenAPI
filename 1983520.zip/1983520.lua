-- Lua provided by RyzenAPI
-- Game: 1983520

-- MAIN APPLICATION
addappid(1983520)
-- Game: addappid(1983520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983521, 1, "f19ee12478b605dd0ff94b420d8d895193c31a1994812fbf3b61a7dbd92b4821")
