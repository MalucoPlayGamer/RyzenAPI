-- Lua provided by RyzenAPI
-- Game: Hentai Cosplay Heroes Demo

-- MAIN APPLICATION
addappid(2825940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825941, 1, "420a9cfd94102e261dfd11c3c23044387174c105453401a0a2d544c43fce7c6e")

