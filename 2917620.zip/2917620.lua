-- Lua provided by RyzenAPI
-- Game: Psychopath Massacre

-- MAIN APPLICATION
addappid(2917620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917621, 1, "05f8167020accdf1cbeaebe90533512c9905e9830b96941cfa5b4ba73a4fb296")

