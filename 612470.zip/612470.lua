-- Lua provided by SkyAPI 
-- Game: AppID 612470
addappid(612470)
addappid(612471, 1, "68db1b2a5f2fe2a87f86e45cfbb3b8fdc3291c91084cf12483bfe24700a68320")
