-- Lua provided by RyzenAPI
-- Game: addappid(612470)

-- MAIN APPLICATION
addappid(612470)

-- MAIN APP DEPOTS / PACKAGES
addappid(612471, 1, "68db1b2a5f2fe2a87f86e45cfbb3b8fdc3291c91084cf12483bfe24700a68320")
