-- Lua provided by RyzenAPI
-- Game: Warring States

-- MAIN APPLICATION
addappid(1477320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477324,0,"757e02b0af80b07893b0a2af1c6c94e0e85f336b812b902839f93d7f336c2413")
addappid(1477325,0,"623c37e2901caa8508b7bf9828ab46910df93f5541568e20d24960fc732bd679")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1484310)
