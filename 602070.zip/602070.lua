-- Lua provided by RyzenAPI
-- Game: Plasma Puncher

-- MAIN APPLICATION
addappid(602070)

-- MAIN APP DEPOTS / PACKAGES
addappid(602071, 1, "740a9178aa8b9944cc482e24b5bd2c69050b2ca1b64589085c400aa429a84492")

