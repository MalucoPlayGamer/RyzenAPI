-- Lua provided by RyzenAPI
-- Game: A Street Cat's Tale 2: Outside is Dangerous

-- MAIN APPLICATION
addappid(2356450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356451, 1, "e70f1cd5f916ec24ebac16239876809146039b90c8802750681de76ed5b3607c")

