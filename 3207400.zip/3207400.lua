-- Lua provided by RyzenAPI
-- Game: 3207400

-- MAIN APPLICATION
addappid(3207400)
-- Game: addappid(3207400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207401, 1, "f88661c7db00151d3013dfae8455a2c17edd9ae56c55fa0c48c70f09ef366aa0")
