-- Lua provided by RyzenAPI
-- Game: Beat Saber - Sid Tipton & Timbaland - "Has A Meaning"

-- MAIN APPLICATION
addappid(1267590)
-- Game: addappid(1267590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267590,0,"2b6525f5172a2b5e10b4704c139ca00426336c106e01e3fe64b4bbd0b6af3628")
