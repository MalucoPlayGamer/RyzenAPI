-- Lua provided by RyzenAPI
-- Game: words from pluto...

-- MAIN APPLICATION
addappid(4302030)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4433570)
