-- Lua provided by SkyAPI 
-- Game: Battle Star
addappid(1436650)
addappid(1436651, 1, "4bf0ea98d7f2a38d9bf192ebac22dce2084d21f1992c25d0a93fd526c18ea4a4")
