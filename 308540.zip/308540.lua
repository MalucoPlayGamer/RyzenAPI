-- Lua provided by RyzenAPI
-- Game: SLEEPOVER

-- MAIN APPLICATION
addappid(308540)

-- MAIN APP DEPOTS / PACKAGES
addappid(308541, 1, "10565f672dbcd1e3789078aad8553939f8ef1285d192243b3991315f09076959")
addappid(308542, 1, "019d02a414acbd1f83790f446e329933490e0f12581bc08a54734c61b1c36b2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
