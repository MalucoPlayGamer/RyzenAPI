-- Lua provided by RyzenAPI 
-- Game: Gleaner Heights
addappid(786580)
addappid(786581, 1, "86e7bb5496e86631b05a9bd1e1698ba10cc9042592f571147ce0a08df1643234")
addappid(1899580, 0, "115361f5a7b585572894b78f5af5974e68ae602f5ab20a8095a2860b78a74662")
