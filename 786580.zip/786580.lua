-- Lua provided by RyzenAPI
-- Game: Gleaner Heights

-- MAIN APPLICATION
addappid(786580)

-- MAIN APP DEPOTS / PACKAGES
addappid(786581, 1, "86e7bb5496e86631b05a9bd1e1698ba10cc9042592f571147ce0a08df1643234")
addappid(1899580, 0, "115361f5a7b585572894b78f5af5974e68ae602f5ab20a8095a2860b78a74662")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
