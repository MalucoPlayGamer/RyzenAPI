-- Lua provided by RyzenAPI
-- Game: 3231490

-- MAIN APPLICATION
addappid(3231490)
-- Game: addappid(3231490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231491, 1, "31925e878261354808814a6aadcd88db90df5dd19d56e315e27666aef98bec1d")
