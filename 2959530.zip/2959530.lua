-- Lua provided by RyzenAPI
-- Game: 欺神弄鬼 Demo

-- MAIN APPLICATION
addappid(2959530)
-- Game: addappid(2959530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959531, 1, "25c1e7d07311276dfe1a25a42014f5ed67a41119c9a328db5c502f7805b40476")
