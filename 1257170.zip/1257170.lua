-- Lua provided by RyzenAPI
-- Game: Game: Saint Emiliana

-- MAIN APPLICATION
addappid(1257170)
-- Game: addappid(1257170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257171, 1, "e828047ac9d101e4d2f48f28249efa318b2cad5fbbbbfe4618570660e9c7a0ca")
addappid(1257172, 1, "026040f1155ad72a9177a4ecb37f91f41c8612c02edc795329bf8fb0147c1651")
addappid(1257173, 1, "131e197d71a98294bff6cb76b88446669d0a0e14d55763dd315647a41d43cb43")
