-- Lua provided by RyzenAPI
-- Game: Game: Legend of Feather

-- MAIN APPLICATION
addappid(2171270)
-- Game: addappid(2171270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171271, 1, "00badbf4c8f578e98a397681a90a549253452ffc6222da24654a0d469ee0efb7")
