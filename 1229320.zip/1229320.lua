-- Lua provided by RyzenAPI
-- Game: 1229320

-- MAIN APPLICATION
addappid(1229320)
-- Game: addappid(1229320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229321, 1, "aabffdf335260ba3a1609a699afe267f038bd26f104d5080c6c84f4c2f954c5e")
addappid(1229322, 1, "c8f0226c60c667cc2115ac95cc5b2fd10b11f3c924812ed419147a480bfc5e74")
