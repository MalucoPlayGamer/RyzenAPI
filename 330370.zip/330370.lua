-- Lua provided by RyzenAPI
-- Game: Reload

-- MAIN APPLICATION
addappid(330370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(330371, 1, "afd20a59d78c4640c34e5aba1e5fe986dec1c86d19b428aa7b99621bdcb84d02")

