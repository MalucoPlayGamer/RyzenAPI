-- Lua provided by SkyAPI 
-- Game: Reload
addappid(330370)
addappid(330371, 1, "afd20a59d78c4640c34e5aba1e5fe986dec1c86d19b428aa7b99621bdcb84d02")
