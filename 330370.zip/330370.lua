-- Lua provided by RyzenAPI
-- Game: Game: Reload

-- MAIN APPLICATION
addappid(330370)
-- Game: addappid(330370)

-- MAIN APP DEPOTS / PACKAGES
addappid(330371, 1, "afd20a59d78c4640c34e5aba1e5fe986dec1c86d19b428aa7b99621bdcb84d02")
