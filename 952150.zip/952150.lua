-- Lua provided by RyzenAPI
-- Game: AppID 952150

-- MAIN APPLICATION
addappid(952150)

-- MAIN APP DEPOTS / PACKAGES
addappid(952151, 1, "6483b10c0fb8686b3c5c7fa4bb320329fe20b54c35280759dc08ce8dfe7fbc45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
