-- Lua provided by SkyAPI 
-- Game: AppID 952150
addappid(952150)
addappid(952151, 1, "6483b10c0fb8686b3c5c7fa4bb320329fe20b54c35280759dc08ce8dfe7fbc45")
