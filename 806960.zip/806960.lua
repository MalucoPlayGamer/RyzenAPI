-- Lua provided by RyzenAPI
-- Game: Dr. Cares - Amy's Pet Clinic

-- MAIN APPLICATION
addappid(806960)

-- MAIN APP DEPOTS / PACKAGES
addappid(806961, 1, "af7637614ca285b2aea64ac5c975dfa9e174b1163c9c8bd8d62804e08082b3fb")
addappid(806962, 1, "2d334e4b3f25bbcd326bc03b105ed8a009717de4bb17b17cc8c72fa4ed5e0c21")
