-- Lua provided by RyzenAPI
-- Game: Game: Final Theory

-- MAIN APPLICATION
addappid(894630)
-- Game: addappid(894630)

-- MAIN APP DEPOTS / PACKAGES
addappid(894631, 1, "3282747151ee46b48f1f6126f3031de3a0006d765ef64bb3c7a73d0e2ada8239")
