-- Lua provided by SkyAPI 
-- Game: Loot Box Quest
addappid(758500)
addappid(758501, 1, "369564827cf7dcb291ed9d1f0a7f2fcad2ea25d41e4c4a5550cf0bc214780839")
