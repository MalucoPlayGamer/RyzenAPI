-- Lua provided by RyzenAPI 
-- Game: AppID 1000380
addappid(1000380)
addappid(1000381, 1, "4ddc9c441f1a7ec69abf28e983b2b38a31b0dedad9494bc13c3a3d036f500863")
