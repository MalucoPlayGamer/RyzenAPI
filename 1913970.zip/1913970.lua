-- Lua provided by RyzenAPI
-- Game: PSYCHO

-- MAIN APPLICATION
addappid(1913970)
-- Game: addappid(1913970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913971, 1, "32b8c636ef7b0a5c76839a5555eb5da4fc98f156d86ca59328668632ff3880e0")
