-- Lua provided by RyzenAPI
-- Game: 迎夢　茶釜物語

-- MAIN APPLICATION
addappid(2712420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712421, 1, "0d5faf28b732230f2bf7976b0c5e3d160afb8120d2d820731885b265098d39bf")

