-- Lua provided by RyzenAPI
-- Game: Mercenaries Saga 1 -Will of the White Lions-

-- MAIN APPLICATION
addappid(2142230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142231, 1, "9c691ab7113ca910a7b415eb74977282cb253a7b3178e0793153907ad50659dc")

