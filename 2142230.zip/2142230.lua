-- Lua provided by SkyAPI 
-- Game: AppID 2142230
addappid(2142230)
addappid(2142231, 1, "9c691ab7113ca910a7b415eb74977282cb253a7b3178e0793153907ad50659dc")
