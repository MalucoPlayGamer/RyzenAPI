-- Lua provided by RyzenAPI
-- Game: addappid(2058850)

-- MAIN APPLICATION
addappid(2058850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058851, 1, "47b0627ffb76b789b0db933118d4d702e5ef5652f306fa6a8370327d5dbd79d2")
