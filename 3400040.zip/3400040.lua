-- Lua provided by RyzenAPI
-- Game: Haunted Property

-- MAIN APPLICATION
addappid(3400040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400041, 1, "3c7645f525690adc1f954c769105033bf9034787c844e60024d7aac215ff8ddb")

