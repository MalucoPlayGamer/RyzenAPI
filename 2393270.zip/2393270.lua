-- Lua provided by RyzenAPI
-- Game: Game: OVRLRD Demo

-- MAIN APPLICATION
addappid(2393270)
-- Game: addappid(2393270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393271, 1, "a29f70a5de3f4512c26df2296b82ed29c8cc6a0582d11e5094273b6a548fec70")
