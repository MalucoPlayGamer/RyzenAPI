-- Lua provided by RyzenAPI 
-- Game: OVRLRD Demo
addappid(2393270)
addappid(2393271, 1, "a29f70a5de3f4512c26df2296b82ed29c8cc6a0582d11e5094273b6a548fec70")
