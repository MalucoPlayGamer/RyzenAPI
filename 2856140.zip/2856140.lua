-- Lua provided by RyzenAPI
-- Game: Banishers: Ghosts of New Eden Demo

-- MAIN APPLICATION
addappid(2856140)
-- Game: addappid(2856140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856141, 1, "45d88d9a5e88db28a2d6c6740658263806289f9893816cd2110e5610608b250a")
