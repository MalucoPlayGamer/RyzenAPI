-- 3657180's Lua and Manifest Created by Hubcap Manifest
-- Skigill
-- Created: May 19, 2026 at 07:25:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3657180) -- Skigill
-- MAIN APP DEPOTS
addappid(3657181, 1, "64eef027aa7cdb1f0046388c957a42bdff7b31c1a34aad392adc61e767238363") -- Depot 3657181
-- setManifestid(3657181, "461037954221002406", 381575022)
addappid(3657182, 1, "dfa1b8eb53072d6e591a16241645b2d0dd1c84f325c37a4c3720c4c033fff95b") -- Depot 3657182
-- setManifestid(3657182, "2651229712991938264", 378956626)
addappid(3657183, 1, "a73ba31d501e058b989108824e2c1d4381dee4101927bb452e9474eb11eccb65") -- Depot 3657183
-- setManifestid(3657183, "8439145889382220174", 398620237)