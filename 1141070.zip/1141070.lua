-- Lua provided by RyzenAPI
-- Game: UFO : Brawlers from Beyond

-- MAIN APPLICATION
addappid(1141070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141071, 1, "85840843235ce4a3683379daeefbfb12e30f9c3f35f2a967da5cef2ce6df584d")
