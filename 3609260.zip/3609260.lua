-- Lua provided by RyzenAPI
-- Game: addappid(3609260)

-- MAIN APPLICATION
addappid(3609260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609262,0,"09f11a841a13d0efd1846e0ddb83d0a5057246eaea61741be1161a08884fd491")
