-- Lua provided by RyzenAPI
-- Game: StudioS Fighters: Climax Champions

-- MAIN APPLICATION
addappid(1924820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924821, 1, "c3ddb63c590901e7e79ed28b7ffb0d01ed000adca6d1d701fbffbe84608f1e21")
addappid(1924823, 1, "69a481325a3583e686142a419cd96c2ce5543453c0c94d7e9c364f2cb219037b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
