-- Lua provided by RyzenAPI
-- Game: StudioS Fighters: Climax Champions

-- MAIN APPLICATION
addappid(1924820)
-- Game: addappid(1924820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924821, 1, "c3ddb63c590901e7e79ed28b7ffb0d01ed000adca6d1d701fbffbe84608f1e21")
addappid(1924823, 1, "69a481325a3583e686142a419cd96c2ce5543453c0c94d7e9c364f2cb219037b")
