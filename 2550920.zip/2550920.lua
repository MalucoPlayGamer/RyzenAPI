-- Lua provided by RyzenAPI 
-- Game: AppID 2550920
addappid(2550920)
addappid(2550921, 1, "676811b73aa986c72c7ee669753d4ff64958617bdea015edc9b33d95a6d84004")
