-- Lua provided by RyzenAPI
-- Game: The Accursed Crown of the Giant King

-- MAIN APPLICATION
addappid(1970780)
addappid(1976090)
addappid(1976091)
addappid(1976092)
-- Game: addappid(1970780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970781, 1, "c3b69f3d78eff0d8e74c1dc7f009b97667922b3c795dc9140a234f4d61c6daa9")
addappid(1970782, 1, "4e850be99313738e039e31184aaa23b7df18a3feea6bd017ab18f1ba519cb695")
addappid(1970783, 1, "b4d26017f78cc26a1fb5c83caaad66d16979bae0d7b2a7973a671fc3ca9ae9e0")
