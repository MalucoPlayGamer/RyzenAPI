-- Lua provided by RyzenAPI 
-- Game: Wolf and The Warren
addappid(3584070)
addappid(3584071, 1, "28f491a2e3fdf63b055baeb35dbda8b50fa27a4fabffc42a2254b1dbb9e1bda6")
