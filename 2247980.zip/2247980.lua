-- Lua provided by RyzenAPI
-- Game: Denizen Demo

-- MAIN APPLICATION
addappid(2247980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247981, 1, "5ef7f869128dfb11dc1c8b1900957f7a3c19e60652f0af341b7ad567b98360dd")

