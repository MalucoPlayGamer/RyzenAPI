-- Lua provided by RyzenAPI
-- Game: Game: The Demon Lord is New in Town!

-- MAIN APPLICATION
addappid(1413980)
-- Game: addappid(1413980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413981, 1, "42c51cc817fd7aee3eb542713e6c91e0990b8aa00badbccdf67018c1ce202fcf")
addappid(1413982, 1, "bcb8b34aeb89c6caa8a50dd2fe6fa836f8e09d9354512ad785886d5cc1e48aa9")
