-- Lua provided by RyzenAPI
-- Game: Crown Wars - Artbook

-- MAIN APPLICATION
addappid(2727750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727750,0,"b76a7a415e516fd63ecd2b282537a2f74ed88373d5a147e69369b52591925e13")

