-- Lua provided by RyzenAPI
-- Game: Overture

-- MAIN APPLICATION
addappid(343100)
addappid(347900)

-- MAIN APP DEPOTS / PACKAGES
addappid(343101, 1, "39bfd00b9bce5ed7421919c0ed476aa62c04c697859598e341ac1c3abbd5c929")
addappid(343102, 1, "1ba85584970c524af8de9e5b3540890dabe5574f60ad748ba8c0d1822465d4ea")
