-- Lua provided by RyzenAPI
-- Game: Game: Knights And Bikes

-- MAIN APPLICATION
addappid(592480)
-- Game: addappid(592480)

-- MAIN APP DEPOTS / PACKAGES
addappid(592481, 1, "3123441fd098eb0f24c92b2711997d62a04dfee752d959762e96bcfbf41e65d6")
addappid(592482, 1, "1069bf94c9d16ffd545a1e345224336658de2c50c12b3a60a3687b8c1e838af0")
addappid(592483, 1, "1317cdf365a0c1724cf6b5942bf26bb3066b3e6cde92f9ed26db7c69390ff0b2")
addappid(592484, 1, "7355daaf90f6929a825b2c2ade9455c691ee2acdf346014f373f22c9622aa29a")
