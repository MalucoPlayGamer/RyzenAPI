-- Lua provided by RyzenAPI
-- Game: Pandamonium

-- MAIN APPLICATION
addappid(2332170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332171, 1, "b653928f2f7e4b0d7c5ea92154453b2cd26cb76960411692c680096db4e5dec1")
