-- Lua provided by RyzenAPI
-- Game: Hentai Rika

-- MAIN APPLICATION
addappid(3490090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3490091,0,"ba7166dd289708301f6897a7483ba51715d82c07d3597f45585b9ecf6a7bab8d")

