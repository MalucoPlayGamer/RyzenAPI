-- Lua provided by RyzenAPI
-- Game: 11号小镇综合症

-- MAIN APPLICATION
addappid(2055390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055391, 1, "bde10991a49de93e4c219a4c23a6f17625efdff3839c56377eba28d365a7b3ce")