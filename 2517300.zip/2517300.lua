-- Lua provided by RyzenAPI 
-- Game: Persona 3 Reload - Digital Artbook
addappid(2517300)
addappid(2517301, 1, "99c413d3350860f2c095f2948891bdaf234aff41e3de3ecdce62384d0db89c1e")
