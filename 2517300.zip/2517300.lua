-- Lua provided by RyzenAPI
-- Game: Game: Persona 3 Reload - Digital Artbook

-- MAIN APPLICATION
addappid(2517300)
-- Game: addappid(2517300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517301, 1, "99c413d3350860f2c095f2948891bdaf234aff41e3de3ecdce62384d0db89c1e")
