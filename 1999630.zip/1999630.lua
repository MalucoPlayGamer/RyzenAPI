-- Lua provided by RyzenAPI
-- Game: LIMINAL PHASE

-- MAIN APPLICATION
addappid(1999630)
-- Game: addappid(1999630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999631, 1, "7c5aa2d59cba65cbaf43986a46fa893ef968203daaabe2d6fadc4e9a2e775ba1")
