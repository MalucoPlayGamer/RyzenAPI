-- Lua provided by RyzenAPI
-- Game: 明治東亰恋伽 Full Moon

-- MAIN APPLICATION
addappid(2779890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779891, 1, "da09acc9a01580964465d6ef76255c1ab19737ac5e22421c29a86be8746e3def")

