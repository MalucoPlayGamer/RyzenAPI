-- Lua provided by RyzenAPI
-- Game: Game: My Harem

-- MAIN APPLICATION
addappid(1257430)
-- Game: addappid(1257430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257431, 1, "96a1eb0090e324f5a02096da50c6a94cdafd96793a2628faa61a45e9a848fb12")
