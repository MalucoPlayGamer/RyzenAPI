-- Lua provided by RyzenAPI
-- Game: Zarya and the Cursed Skull

-- MAIN APPLICATION
addappid(605040)

-- MAIN APP DEPOTS / PACKAGES
addappid(605041,0,"e0cda7935371f98001ffa70695e2080f2c22b0d0918015b4dfa609f010437f9d")

