-- Lua provided by RyzenAPI
-- Game: addappid(42160)

-- MAIN APPLICATION
addappid(42160)
addappid(218843)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228990)
addappid(271090)

-- MAIN APP DEPOTS / PACKAGES
addappid(42161, 1, "6048030d6a07998986fdc986c1c200c1c2caf37566db8b10c2eb0646ad19b84b")
