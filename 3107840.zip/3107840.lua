-- Lua provided by RyzenAPI
-- Game: ABAB

-- MAIN APPLICATION
addappid(3107840)
-- Game: addappid(3107840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107841, 1, "cbc600d013f3ea6711d5ab539c74a0f670cb52cc15c08e544690d7c6c43b4642")
