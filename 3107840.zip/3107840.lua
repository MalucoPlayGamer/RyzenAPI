-- Lua provided by SkyAPI 
-- Game: ABAB
addappid(3107840)
addappid(3107841, 1, "cbc600d013f3ea6711d5ab539c74a0f670cb52cc15c08e544690d7c6c43b4642")
