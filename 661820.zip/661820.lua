-- Lua provided by RyzenAPI
-- Game: setManifestid(661822,"5351766999044724209")

-- MAIN APPLICATION
addappid(661820)
-- Game: addappid(661820)

-- MAIN APP DEPOTS / PACKAGES
addappid(661822,0,"7cba0237a36b243ceaa6cb8546c58a94297e8fb07d208d07022e4240784ea3a6")
