-- Lua provided by RyzenAPI
-- Game: Rage Quest

-- MAIN APPLICATION
addappid(709290)

-- MAIN APP DEPOTS / PACKAGES
addappid(709291, 1, "24f6e08898b0d95c8f4b498b36bb4ef0d30ed6edec82687e3b7fb9bfc150971e")
