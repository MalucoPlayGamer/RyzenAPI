-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY XVI - Original DLC Soundtrack - From Spire to Sea

-- MAIN APPLICATION
addappid(3372360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372361, 1, "925873942a1404520bdac75d984b41af4be65f647df751cd6c9381c032f347d4")
