-- Lua provided by RyzenAPI
-- Game: Witches' Legacy: The Dark Throne Collector's Edition

-- MAIN APPLICATION
addappid(696000)

-- MAIN APP DEPOTS / PACKAGES
addappid(696001,0,"ba3d80e7050f2bc01c28cbf213bc345fd60ae3c58f5db7f9acfa223ddb7c805b")

