-- Lua provided by RyzenAPI 
-- Game: Subnautica 2
addappid(1962700)
addappid(1962701, 1, "96feb03fc707b975cf8271da4659fdb16c14c4b1a5c5bf8f94bd66e39edd4d96")
