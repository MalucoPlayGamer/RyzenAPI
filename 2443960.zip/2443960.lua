-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2443960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443962,0,"144e274c435f2e8122191c5ca7a63ddc372265012ad7b07b367ffc0c180c71ac")

