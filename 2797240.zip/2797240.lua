-- Lua provided by SkyAPI 
-- Game: Space Survivor
addappid(2797240)
addappid(2797241, 1, "419a3f179bafd2c26780e18dece2d5ec3c1ad4ba637a1b8a04d48ed80b37f388")
