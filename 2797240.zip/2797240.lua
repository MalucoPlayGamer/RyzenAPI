-- Lua provided by RyzenAPI
-- Game: 2797240

-- MAIN APPLICATION
addappid(2797240)
-- Game: addappid(2797240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797241, 1, "419a3f179bafd2c26780e18dece2d5ec3c1ad4ba637a1b8a04d48ed80b37f388")
