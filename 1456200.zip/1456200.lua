-- Lua provided by RyzenAPI
-- Game: Initial Drift Online

-- MAIN APPLICATION
addappid(1456200)
addappid(1869920)
addappid(2352970)
addappid(2352971)
addappid(3590930)
addappid(3626790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456201, 1, "eed2cdba2247e0e72d722b8073f6981c92fedf61e4f3a8bc078f539144132fd2")

