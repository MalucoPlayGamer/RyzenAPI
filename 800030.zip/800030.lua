-- Lua provided by RyzenAPI
-- Game: Magikiras

-- MAIN APPLICATION
addappid(800030)

-- MAIN APP DEPOTS / PACKAGES
addappid(800031,0,"13b3cabd3d24d2fd764c6eb7a4647f0319eb4f2aab1ee301a152bbee19f77aca")

