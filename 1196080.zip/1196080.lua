-- Lua provided by RyzenAPI
-- Game: 1196080

-- MAIN APPLICATION
addappid(1196080)
-- Game: addappid(1196080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196084,0,"fd1c25c2833bad4decdbea014440eafc068e6b569558468cdc73996a442d74ca")
