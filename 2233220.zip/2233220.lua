-- Lua provided by RyzenAPI 
-- Game: AppID 2233220
addappid(2233220)
addappid(2233221, 1, "a9974d9a89695c25d9fe032bc8b28e3dba32f8c222e68f6910700e991ccf4b0a")
