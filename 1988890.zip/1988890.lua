-- Lua provided by RyzenAPI
-- Game: Little Rhapsody of Game

-- MAIN APPLICATION
addappid(1988890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1988891, 1, "21d73df4acaeabdf252422fe91efc05759e05bffa1d7cc0a71a8fa474d98fc9e")

