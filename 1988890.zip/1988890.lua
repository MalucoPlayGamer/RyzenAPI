-- Lua provided by RyzenAPI
-- Game: Little Rhapsody of Game

-- MAIN APPLICATION
addappid(1988890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988891, 1, "21d73df4acaeabdf252422fe91efc05759e05bffa1d7cc0a71a8fa474d98fc9e")

