-- Lua provided by RyzenAPI
-- Game: addappid(960420)

-- MAIN APPLICATION
addappid(960420)

-- MAIN APP DEPOTS / PACKAGES
addappid(960421, 1, "e57d39ea940a4a99455460d6090313abd14cab4a85289d06199a90844e39da3e")
