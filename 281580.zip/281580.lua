-- Lua provided by RyzenAPI
-- Game: addappid(281580)

-- MAIN APPLICATION
addappid(281580)

-- MAIN APP DEPOTS / PACKAGES
addappid(281581, 1, "c04086ecc24cb15dcb4257c94a5ce0daea38356b053e889892cacae75ad30cb9")
