-- Lua provided by RyzenAPI
-- Game: Game: LightRay

-- MAIN APPLICATION
addappid(3134840)
-- Game: addappid(3134840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134841, 1, "04bb66ccf590407b5242285266a53e94d29125a8b472c310262dbd380176b41f")
