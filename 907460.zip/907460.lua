-- Lua provided by SkyAPI 
-- Game: AppID 907460
addappid(907460)
addappid(907461, 1, "71c46904564b322221ac24464ef33ae258e0aaeec5c633b44eba6608b574d84a")
