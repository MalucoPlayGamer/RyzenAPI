-- Lua provided by RyzenAPI
-- Game: Game: SkyFly

-- MAIN APPLICATION
addappid(2657890)
-- Game: addappid(2657890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657891, 1, "bf05afcb7e5f8363ab203d40ff7c7333c79aa1238f15d8cddcf64d905ba34546")
