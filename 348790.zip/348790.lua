-- Lua provided by RyzenAPI
-- Game: Wooden Floor

-- MAIN APPLICATION
addappid(348790)

-- MAIN APP DEPOTS / PACKAGES
addappid(348791, 1, "dc56543cece53ac054a65345b2229fdc2a1f8d80f72fefd0483ef5e1eb3160a7")

