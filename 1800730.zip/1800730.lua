-- Lua provided by RyzenAPI
-- Game: I MAED A GAM3 W1TH Z0MB1ES 1N IT!!!1

-- MAIN APPLICATION
addappid(1800730)
