-- Lua provided by RyzenAPI
-- Game: Game: Valley Knights

-- MAIN APPLICATION
addappid(1781590)
-- Game: addappid(1781590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781591, 1, "c6e10b3686a3d5c64babdc24739e5e3f9b5ec8c7f6fe07330a7379fd11c950e0")
