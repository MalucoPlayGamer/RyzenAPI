-- Lua provided by RyzenAPI
-- Game: Valley Knights

-- MAIN APPLICATION
addappid(1781590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781591, 1, "c6e10b3686a3d5c64babdc24739e5e3f9b5ec8c7f6fe07330a7379fd11c950e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
