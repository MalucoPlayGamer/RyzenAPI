-- Lua provided by RyzenAPI
-- Game: Tiny Thief

-- MAIN APPLICATION
addappid(669650)

-- MAIN APP DEPOTS / PACKAGES
addappid(669651,0,"fee617491cea72259c65cdfe4ebd7976c38700696e73df7cfafac83ed2890179")

