-- Lua provided by RyzenAPI
-- Game: London Detective Mysteria

-- MAIN APPLICATION
addappid(627350)

-- MAIN APP DEPOTS / PACKAGES
addappid(627351, 1, "ab591be847338f5fca063dc9767a8de27852851f0aac0abee49f9c5e62b88ccb")
