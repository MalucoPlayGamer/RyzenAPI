-- Lua provided by RyzenAPI
-- Game: Aefen Fall

-- MAIN APPLICATION
addappid(1467020)
-- Game: addappid(1467020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467021, 1, "ba9754a005be982356058a00d17ac9df10a18affa0ccc28be688d459cae2890c")
