-- Lua provided by RyzenAPI
-- Game: addappid(2707110)

-- MAIN APPLICATION
addappid(2707110)
addappid(3405300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707111, 1, "875cd6f79143248cbd37ffa0dbce04e477655c39e693911f74080b33e45bfdcc")
