-- Lua provided by RyzenAPI
-- Game: 1409600

-- MAIN APPLICATION
addappid(1409600)
-- Game: addappid(1409600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409601, 1, "a3cb0ee8b7c19beb7178623a08e2efaa9d136c6e01f943434f51d2769a991d25")
