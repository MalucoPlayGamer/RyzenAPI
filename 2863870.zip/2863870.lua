-- Lua provided by RyzenAPI
-- Game: Exit 13 Gallery Escape

-- MAIN APPLICATION
addappid(2863870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863871,0,"e8d9b195171a2a6b1b7bc541b2e62441c16a9bb2f39e0f097b600bd1f179c9a8")

