-- Lua provided by RyzenAPI
-- Game: Apotheon

-- MAIN APPLICATION
addappid(208750)

-- MAIN APP DEPOTS / PACKAGES
addappid(208751, 1, "b3bc7615081e70a630ac23b14ba909d94c51a585cbaa8e2c540ff12364d906b6")
addappid(208752, 1, "26af9942fa6de446b2931801cb92558d8bbe1f3e65cb2f7ac1b5fe95072b2ba8")
addappid(208753, 1, "aaf0f16225fb8341f1b9c90f2b08dff28c88023a5ece7cf0ec147a76427dc9bc")
addappid(344730, 0, "07f139b978fd51634d24e027f1fd7da3a0c017b28d9a76201b59fed703fe7809")

