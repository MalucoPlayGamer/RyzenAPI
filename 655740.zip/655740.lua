-- Lua provided by RyzenAPI
-- Game: Tallowmere 2: Curse of the Kittens

-- MAIN APPLICATION
addappid(228990)
addappid(655740)
addappid(655743)
addappid(655744)
-- Game: addappid(655740)

-- MAIN APP DEPOTS / PACKAGES
addappid(655742,0,"266dae46d421a214d5a9fe3b77c86bca1791c6af7b25e0bfb4dbdb1a950a1bd9")
