-- Lua provided by RyzenAPI
-- Game: Apartment of Love

-- MAIN APPLICATION
addappid(788910)
addappid(788911)
addappid(788913)
addappid(788914)
addappid(788915)

-- MAIN APP DEPOTS / PACKAGES
addappid(788912,0,"eb53259e85cf67f2b04e7c50a2db03913097790c146b2e963406ee856c860acf")
