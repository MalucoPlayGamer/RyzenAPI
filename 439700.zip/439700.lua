-- Lua provided by RyzenAPI
-- Game: Z1 Battle Royale: Test Server

-- MAIN APPLICATION
addappid(439700)

-- MAIN APP DEPOTS / PACKAGES
addappid(439701, 1, "5467907d5be42494fae9aaaab51d70528d517c130c1d18df5be75274b5244378")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
