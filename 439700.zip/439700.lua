-- Lua provided by RyzenAPI
-- Game: addappid(439700)

-- MAIN APPLICATION
addappid(439700)

-- MAIN APP DEPOTS / PACKAGES
addappid(439701, 1, "5467907d5be42494fae9aaaab51d70528d517c130c1d18df5be75274b5244378")
