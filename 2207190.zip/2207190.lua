-- Lua provided by RyzenAPI
-- Game: Game: Monochrome Mobius: Rights and Wrongs Forgotten - Soundtrack “Prelude”

-- MAIN APPLICATION
addappid(2207190)
-- Game: addappid(2207190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207191, 1, "d8435fda081fc83a849bb4097cd3ca210cabd40bb43fc899d9f225c12c5367d9")
