-- Lua provided by RyzenAPI
-- Game: 1535390

-- MAIN APPLICATION
addappid(1535390)
-- Game: addappid(1535390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535390,0,"c87c79cbb636e5d2aef783d56bc9958e197dec05e9fbeab97286a746ce97fe3f")
