-- Lua provided by RyzenAPI
-- Game: Fix it - The Handyman Simulator

-- MAIN APPLICATION
addappid(1203320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203321, 1, "10fa2d86905a483a49163f2a157355a3e6026dca8d7f09d5ef064909a91e504e")
