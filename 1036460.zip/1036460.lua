-- Lua provided by RyzenAPI
-- Game: Game: AppID 1036460

-- MAIN APPLICATION
addappid(1036460)
-- Game: addappid(1036460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036461, 1, "8f9038cd44ef7d6cac0e80d6b2d0f07b3c0428e782638fafa99d8e90a1ce81db")
