-- Lua provided by RyzenAPI
-- Game: addappid(2312220)

-- MAIN APPLICATION
addappid(2312220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312221, 1, "d8543f1324dc15d22f59de3dcb090124b990e221af519a5f3801d8076ba20d27")
