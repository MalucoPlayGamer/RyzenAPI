-- Lua provided by SkyAPI 
-- Game: Oddworld: Stranger's Wrath HD
addappid(15750)
addappid(15751, 1, "8d289fdead7fa7e4bc9dfbbbe51d35b779d3e8f7d67920c0560be32f4f0354b7")
addappid(616970)
