-- Lua provided by RyzenAPI
-- Game: Game: AppID 1062080

-- MAIN APPLICATION
addappid(1062080)
-- Game: addappid(1062080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062081, 1, "f3a8f1f36bff32c05ee05b49636e61f61368e839b406c1146a443a5e126fc98f")
