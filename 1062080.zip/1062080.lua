-- Lua provided by RyzenAPI
-- Game: Goofballs

-- MAIN APPLICATION
addappid(1062080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1062081, 1, "f3a8f1f36bff32c05ee05b49636e61f61368e839b406c1146a443a5e126fc98f")
