-- Lua provided by RyzenAPI
-- Game: Game: Bombagun

-- MAIN APPLICATION
addappid(1509780)
-- Game: addappid(1509780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509781, 1, "b3513c936651ef325fab43161840df51e531c9844375472969c40310e966c263")
addappid(1509782, 1, "d9ee639345df77afa54daf20261f1c270c0d6c9bfb70cee2ae6d8a7e774e4ab3")
addappid(1509783, 1, "b661f52783129696eed9c121358edbab49f396905c07798a0cf9fb0de5f80de5")
