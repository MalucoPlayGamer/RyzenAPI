-- Lua provided by RyzenAPI
-- Game: Aveyond 4: Shadow of the Mist

-- MAIN APPLICATION
addappid(433920)

-- MAIN APP DEPOTS / PACKAGES
addappid(433921, 1, "d34dfff4ffef1e0785069537e4dc09cc933d66a60c94bc42bfcffee8c589b4c0")
addappid(434950, 0, "44a629cb0e267aefe8ca5ff19c23a6de8b69fd93fa5299443c4fa16126123e1b")
