-- Lua provided by RyzenAPI
-- Game: Game: Doodle Devil

-- MAIN APPLICATION
addappid(608760)
-- Game: addappid(608760)

-- MAIN APP DEPOTS / PACKAGES
addappid(608761, 1, "e6817d81bb207899a6f7dd9cd43a4e12b84d61b53a0acc2c191f23997a929a77")
addappid(608762, 1, "92a83b5ced3fec7e1d0405f30c1f2ed96116729df48870eed67c9f5646fac4ee")
addappid(608763, 1, "2a074eb825e1f18c8afcc105c73be798217d694af0b489bfa2a605f4b72085fa")
addappid(608764, 1, "fdd44f96c16f270482a2b6424638e80ab6112d6499ac3f4e3b787c7f4fbb8b1f")
addappid(608765, 1, "0ffe2721f6191abd449c10f081c017e71d552c257ad63e6b6fc976ad045d8bc7")
