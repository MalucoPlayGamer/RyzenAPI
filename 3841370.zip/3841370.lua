-- Lua provided by RyzenAPI
-- Game: Game: AppID 3841370

-- MAIN APPLICATION
addappid(3841370)
-- Game: addappid(3841370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3841371, 1, "1285e22aefa86536ea6a334472ebe0c1b457685eea573ca331891664a9814183")
