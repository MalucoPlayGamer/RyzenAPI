-- Lua provided by RyzenAPI
-- Game: Otoko Cross: Pretty Boys Mahjong Solitaire

-- MAIN APPLICATION
addappid(1941840)
-- Game: addappid(1941840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941841, 1, "d9b1439784dfcc4a44351a47fe4a2c8c8fdd68ca5ede7898df1b6e785c5a0e08")
