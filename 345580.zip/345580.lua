-- Lua provided by RyzenAPI
-- Game: Universal Combat CE

-- MAIN APPLICATION
addappid(345580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345581, 1, "f67f4aa2590c711617ff431413a48fc09b9c155a9ffbb9c4b62cc777d0292719")
addappid(370810, 0, "8aeea16fd67d10aa73b9a86de8ae8b47b52d063b90e1900cd26d7af04f94fc32")

