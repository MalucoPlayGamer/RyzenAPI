-- Lua provided by SkyAPI 
-- Game: AppID 345580
addappid(345580)
addappid(345581, 1, "f67f4aa2590c711617ff431413a48fc09b9c155a9ffbb9c4b62cc777d0292719")
addappid(370810, 0, "8aeea16fd67d10aa73b9a86de8ae8b47b52d063b90e1900cd26d7af04f94fc32")
