-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2690510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690510,0,"ef81698c62006143f3d1f1d7d82cadc70a2eb6ecc0df93baeb5ca075fc885e19")
