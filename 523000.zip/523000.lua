-- Lua provided by RyzenAPI
-- Game: Game: Princess Maker 2 Refine

-- MAIN APPLICATION
addappid(523000)
-- Game: addappid(523000)

-- MAIN APP DEPOTS / PACKAGES
addappid(523001, 1, "d841e3d7402739816d841432a80165512e92cac51051a7c44106d7c493557222")
addappid(523002, 1, "a16e7bbc42b5287d13bd359ef0473f393c0988a1afbbce1161879a716422f7f5")
addappid(523003, 1, "d11b0f045c423ca7138d261b73e190855ca13d992b3b67129a595dddc7ddd3bb")
addappid(523004, 1, "cdbe8c6f02005eab7c3dc6b1a95e8fa1a6968acc3c5ca15e5694b9226b5d4234")
addappid(523005, 1, "e9bdaa19692129030c51666c00622c302fbf1d65633b0648e4ac16d6d22ddfa9")
addappid(540000, 0, "f0899e05fcf742544b565eefe4dffd78ee61ec5b6065a209a06abacbcb4a8cdc")
