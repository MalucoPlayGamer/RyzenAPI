-- Lua provided by SkyAPI 
-- Game: Goodboy Galaxy
addappid(2705890)
addappid(2705891, 1, "1c32d9cc1b66c7ec5489dc2087ae1bd3e06940d032565fd01c9b373402163f5b")
