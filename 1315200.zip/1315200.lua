-- Lua provided by SkyAPI 
-- Game: Kingdom Under Fire: Heroes
addappid(1315200)
addappid(1315201, 1, "8ef497deadd965715b72128f3cc423558df0df79513055dd50a1753aea731846")
