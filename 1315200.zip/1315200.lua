-- Lua provided by RyzenAPI
-- Game: Kingdom Under Fire: Heroes

-- MAIN APPLICATION
addappid(1315200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315201, 1, "8ef497deadd965715b72128f3cc423558df0df79513055dd50a1753aea731846")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
