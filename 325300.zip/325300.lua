-- Lua provided by RyzenAPI
-- Game: addappid(325300)

-- MAIN APPLICATION
addappid(325300)

-- MAIN APP DEPOTS / PACKAGES
addappid(325301, 1, "b3f72acc93facf5aca4f6b5b7cd2dc9bd609227631b82e24a57b4eaa995d6157")
addappid(325302, 1, "3e20f2a66aaeb354311794350914c2e5eba016e8bd5aee488f3bacbbd78972f5")
