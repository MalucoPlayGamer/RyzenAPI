-- Lua provided by RyzenAPI
-- Game: BEARZERKERS

-- MAIN APPLICATION
addappid(325300)

-- MAIN APP DEPOTS / PACKAGES
addappid(325301, 1, "b3f72acc93facf5aca4f6b5b7cd2dc9bd609227631b82e24a57b4eaa995d6157")
addappid(325302, 1, "3e20f2a66aaeb354311794350914c2e5eba016e8bd5aee488f3bacbbd78972f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
