-- Lua provided by RyzenAPI
-- Game: Game: PlanetSprite

-- MAIN APPLICATION
addappid(2319240)
-- Game: addappid(2319240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319241, 1, "ad63a1081cce57ee79418f1c1665af38ed26ec9d42ebce7eaf5217c6681e02b0")
