-- Lua provided by RyzenAPI
-- Game: PlanetSprite

-- MAIN APPLICATION
addappid(2319240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319241, 1, "ad63a1081cce57ee79418f1c1665af38ed26ec9d42ebce7eaf5217c6681e02b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
