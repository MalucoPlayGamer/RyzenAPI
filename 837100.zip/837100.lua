-- Lua provided by RyzenAPI
-- Game: Chronicles of Mystery - The Legend of the Sacred Treasure

-- MAIN APPLICATION
addappid(837100)
-- Game: addappid(837100)

-- MAIN APP DEPOTS / PACKAGES
addappid(837101, 1, "3589f040fcf1358d3bd56dfbe2c9ea9d6069ca7b124822cc3117061fb5910f20")
addappid(837102, 1, "7d303a7d44f74ab1f599566cc4d98d8a8d550a268affbbfcaaf370a7e8f05a4a")
addappid(837105, 1, "f3e2ad6be6b9a3e274c1cdfb4fec6ab3c38b76ff6062f80a80b8d0bde8cf739c")
addappid(837107, 1, "62fea3f54f931d8cf927d092189d52a595cf7fc8c3d1edd73bea67a385c07c26")
