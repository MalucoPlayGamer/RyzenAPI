-- Lua provided by RyzenAPI
-- Game: The Lost Tape - Cellar

-- MAIN APPLICATION
addappid(2769310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769311, 1, "82aebfe5b8f0360a3bb5aadb6a8d78590a8ae267ee45913146fbcfec24654a78")

