-- Lua provided by RyzenAPI 
-- Game: The Lost Tape - Cellar
addappid(2769310)
addappid(2769311, 1, "82aebfe5b8f0360a3bb5aadb6a8d78590a8ae267ee45913146fbcfec24654a78")
