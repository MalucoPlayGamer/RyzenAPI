-- Lua provided by RyzenAPI
-- Game: addappid(1306580)

-- MAIN APPLICATION
addappid(1306580)
addappid(1342820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306581, 1, "8c90a5df0a8c0225d18a3e4e0a39ce42eaa40120e0d13b780f9d61b6454526be")
