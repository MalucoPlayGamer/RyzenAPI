-- Lua provided by RyzenAPI
-- Game: addappid(415150)

-- MAIN APPLICATION
addappid(415150)

-- MAIN APP DEPOTS / PACKAGES
addappid(415151, 1, "e67db114565f4995091a607aac42f5003869c6dbf7dd669a5f001cd44440bd99")
