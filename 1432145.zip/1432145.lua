-- Lua provided by RyzenAPI
-- Game: 1432145

-- MAIN APPLICATION
addappid(1432145)
-- Game: addappid(1432145)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432145,0,"24902074a5bd1ffddb0aec46406b0049d88a6118999560f2eb40a44f5befad91")
