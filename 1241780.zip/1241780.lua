-- Lua provided by SkyAPI 
-- Game: CatDog Puzzle
addappid(1241780)
addappid(1241781, 1, "25ffdb86d43015175d0a615eaf5c5c37bd14513beef618a6e157db6ed2de2a7d")
