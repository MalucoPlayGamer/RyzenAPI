-- Lua provided by RyzenAPI
-- Game: Sandwalkers Demo

-- MAIN APPLICATION
addappid(2199020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199021, 1, "90dae05bc824194b092c963d8d31cf56b42691251b9df37fb392e516ac8ba068")

