-- Lua provided by RyzenAPI
-- Game: addappid(1229050)

-- MAIN APPLICATION
addappid(1229050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229051, 1, "679da5c3c9d6d8b83d9c4374dc2c58ace00b0cc4ca7627f97cfd5c85b4d624f3")
addappid(1229052, 1, "a800e5ab1ae02b714de97f7ca5746afd3f81f546f77a6ae454b13825b0f521d7")
