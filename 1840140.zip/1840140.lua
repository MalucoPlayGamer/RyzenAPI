-- Lua provided by RyzenAPI
-- Game: Venture's Gauntlet: The Ultimate VR Fitness Obstacle Course

-- MAIN APPLICATION
addappid(1840140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840141, 1, "b49fb4eea1187dfdf3fe69ffcc9f4a097dacc9fc062c10a7ec84786624ef64c7")

