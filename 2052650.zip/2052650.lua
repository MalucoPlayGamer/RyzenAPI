-- Lua provided by RyzenAPI
-- Game: Sword & Shield Simulator

-- MAIN APPLICATION
addappid(2052650) -- Sword & Shield Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2052651, 1, "a6c9f9471d09075afc743709b94f0c9fd00b33a7d51a3ae4cf2cf726f6c39dff") -- Depot 2052651

