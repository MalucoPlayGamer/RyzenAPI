-- 2052650's Lua and Manifest Created by Hubcap Manifest
-- Sword & Shield Simulator
-- Created: August 11, 2026 at 23:23:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2052650) -- Sword & Shield Simulator
-- MAIN APP DEPOTS
addappid(2052651, 1, "a6c9f9471d09075afc743709b94f0c9fd00b33a7d51a3ae4cf2cf726f6c39dff") -- Depot 2052651
setManifestid(2052651, "4224306016879685775", 7561695458)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)