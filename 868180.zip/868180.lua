-- Lua provided by RyzenAPI
-- Game: Salty Seabird Bay

-- MAIN APPLICATION
addappid(868180)

-- MAIN APP DEPOTS / PACKAGES
addappid(868181, 1, "02e9a5d05e74042566b5fd9d23caca3fd8e627cb7e73d901b5e05e7fee1c43f3")
