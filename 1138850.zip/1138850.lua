-- Lua provided by RyzenAPI
-- Game: AppID 1138850

-- MAIN APPLICATION
addappid(1138850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138851, 1, "3ee5d58111adfc1a06a0946b6e7e64dc1ce741bf0595101c0c8f160d8d8d4123")
addappid(1138852, 1, "6838db63ea5a3fe9072ce181d8cbce7d748d5f67dce5deccd0f02dc5f933a39a")
