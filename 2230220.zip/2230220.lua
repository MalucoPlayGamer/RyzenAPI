-- Lua provided by RyzenAPI
-- Game: Game: Wilderless

-- MAIN APPLICATION
addappid(2230220)
-- Game: addappid(2230220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230221, 1, "4686411e8363da3c56cf4dfa13939fd9a6fcd48f2cc38d14ce2f699140a1a94e")
