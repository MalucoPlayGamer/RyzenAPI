-- Lua provided by RyzenAPI
-- Game: Bloomon

-- MAIN APPLICATION
addappid(3742930) -- Bloomon

-- MAIN APP DEPOTS / PACKAGES
addappid(3742931, 1, "e46c8dddcdaf2b368aef75accd2fbc2fd394b16bb29942e2a6c33c2e642cc1ac") -- Depot 3742931

