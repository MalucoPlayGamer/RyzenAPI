-- Lua provided by RyzenAPI 
-- Game: Sword Legacy: Omen
addappid(690140)
addappid(690141, 1, "41fd6db8fe3519c7d344521d16c13e4cd51d7b09d956cc32ec8ebfc429ca3686")
addappid(914830, 0, "4a9d4da90752a3a04a9ebf9bd66d27615c4da82caaac4e80610bddffe096edff")
addappid(914831, 0, "ab3d2d142773e8678b75c89d8df84829b763675986a17c8edb3e8ce493e0087f")
