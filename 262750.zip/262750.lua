-- Lua provided by RyzenAPI
-- Game: GoD Factory: Wingmen

-- MAIN APPLICATION
addappid(262750)
addappid(315970)

-- MAIN APP DEPOTS / PACKAGES
addappid(262751, 1, "ed21dd0f7136766a9b6bfc28ef8d3ed25cd71573ed0cb1a1275d7cec21cc92c3")

