-- Lua provided by RyzenAPI
-- Game: GoD Factory: Wingmen

-- MAIN APPLICATION
addappid(262750)
addappid(315970)

-- MAIN APP DEPOTS / PACKAGES
addappid(262751, 1, "ed21dd0f7136766a9b6bfc28ef8d3ed25cd71573ed0cb1a1275d7cec21cc92c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(315980)
