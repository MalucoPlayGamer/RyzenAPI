-- Lua provided by RyzenAPI
-- Game: Infinite Widgets

-- MAIN APPLICATION
addappid(1743370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743371, 1, "bc3768e22f0c58e42cabb3b3e5e72587d1b799a15d36031a2f3f491702b8712b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
