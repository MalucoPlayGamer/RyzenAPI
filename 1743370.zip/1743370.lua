-- Lua provided by RyzenAPI
-- Game: addappid(1743370)

-- MAIN APPLICATION
addappid(1743370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743371, 1, "bc3768e22f0c58e42cabb3b3e5e72587d1b799a15d36031a2f3f491702b8712b")
