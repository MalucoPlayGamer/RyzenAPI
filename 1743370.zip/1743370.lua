-- Lua provided by RyzenAPI 
-- Game: Infinite Widgets
addappid(1743370)
addappid(1743371, 1, "bc3768e22f0c58e42cabb3b3e5e72587d1b799a15d36031a2f3f491702b8712b")
