-- Lua provided by RyzenAPI
-- Game: AppID 2882440

-- MAIN APPLICATION
addappid(2882440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882441, 1, "7ffaeab1059850f6d2bc4a2e1fdd40e249380ed027dd1d4df60c117ca796e391")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
