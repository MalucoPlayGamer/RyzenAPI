-- Lua provided by RyzenAPI 
-- Game: Tower of Mask
addappid(2918410)
addappid(2918411, 1, "1f284fac92d3917d156bc005b8b4cbcd3437430e372592529da6448c62c1625c")
