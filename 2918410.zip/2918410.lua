-- Lua provided by RyzenAPI
-- Game: Tower of Mask

-- MAIN APPLICATION
addappid(2918410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918411, 1, "1f284fac92d3917d156bc005b8b4cbcd3437430e372592529da6448c62c1625c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
