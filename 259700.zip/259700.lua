-- Lua provided by RyzenAPI
-- Game: Dead Sky

-- MAIN APPLICATION
addappid(259700)

-- MAIN APP DEPOTS / PACKAGES
addappid(259701, 1, "9aad71058a9a6b2be56cb1260c193fa2f8885d48941563af392392871ead4260")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
