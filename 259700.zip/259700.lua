-- Lua provided by RyzenAPI
-- Game: 259700

-- MAIN APPLICATION
addappid(259700)
-- Game: addappid(259700)

-- MAIN APP DEPOTS / PACKAGES
addappid(259701, 1, "9aad71058a9a6b2be56cb1260c193fa2f8885d48941563af392392871ead4260")
