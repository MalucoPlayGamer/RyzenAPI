-- Lua provided by RyzenAPI
-- Game: Game: AppID 1328530

-- MAIN APPLICATION
addappid(1328530)
-- Game: addappid(1328530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328531, 1, "b4ddbb3e0e2d71032beb9a36a8a7ed14f179fef7c91df0361da68c4a9b9c2ab8")
