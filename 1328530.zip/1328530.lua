-- Lua provided by RyzenAPI
-- Game: Quantum Protocol

-- MAIN APPLICATION
addappid(1328530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1328531, 1, "b4ddbb3e0e2d71032beb9a36a8a7ed14f179fef7c91df0361da68c4a9b9c2ab8")

