-- Lua provided by SkyAPI 
-- Game: ISEKAI FRONTLINE Demo
addappid(2136500)
addappid(2136501, 1, "587d154ba62ca9b468dcd1abdbec1d6eebce1783077bd19d623c3a6230b06ed3")
