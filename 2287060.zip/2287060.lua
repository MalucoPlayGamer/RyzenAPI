-- Lua provided by SkyAPI 
-- Game: Extreme Car Drift Simulator
addappid(2287060)
addappid(2287061, 1, "bd07d7375d9779e6e723a1b13890acb8b431319b6384ab47f92cd1fe9ca36cdc")
