-- Lua provided by RyzenAPI
-- Game: 2287060

-- MAIN APPLICATION
addappid(2287060)
-- Game: addappid(2287060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287061, 1, "bd07d7375d9779e6e723a1b13890acb8b431319b6384ab47f92cd1fe9ca36cdc")
