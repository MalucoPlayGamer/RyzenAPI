-- Lua provided by RyzenAPI 
-- Game: AppID 1025130
addappid(1025130)
addappid(1025131, 1, "7331153a09cbe04bcd53e0f58b73b7604ecff13881dba7eaf567777a042bdc47")
