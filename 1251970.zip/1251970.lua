-- Lua provided by RyzenAPI
-- Game: addappid(1251970)

-- MAIN APPLICATION
addappid(1251970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251971, 1, "a6523b61490940c2fa03ece0c48dfb33ba6cbbba6ac9e0d952b78ef83d6da70d")
