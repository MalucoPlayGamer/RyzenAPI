-- Lua provided by RyzenAPI
-- Game: addappid(1622470)

-- MAIN APPLICATION
addappid(1622470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622471, 1, "9edbc645d99a0f972f608ea26edd877649c367d5e73bb15bfc42ddb05cbb1158")
