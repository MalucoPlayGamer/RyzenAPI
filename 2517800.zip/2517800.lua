-- Lua provided by RyzenAPI
-- Game: Game: Bouncers

-- MAIN APPLICATION
addappid(2517800)
-- Game: addappid(2517800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517801, 1, "13f163e2435f64c68c4db5fbde458aa7c3bb1ffbbdd0bc3f32b76f7b2bd2dce1")
