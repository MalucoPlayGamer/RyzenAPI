-- Lua provided by RyzenAPI
-- Game: Game: Nightmare Shift

-- MAIN APPLICATION
addappid(3212180)
-- Game: addappid(3212180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3212181, 1, "09f843e621271d2d260be421e7cce34328ce229c63919f0d0857e25b70016978")
