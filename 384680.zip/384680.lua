-- Lua provided by RyzenAPI
-- Game: MechaNika

-- MAIN APPLICATION
addappid(384680)
-- Game: addappid(384680)

-- MAIN APP DEPOTS / PACKAGES
addappid(384681, 1, "8fb148f7cce838b482e4deef5a8f3a5e07a6eb15b8930a8ac1c145af5b38ecbf")
addappid(384682, 1, "c324629f6e7e1b8b4bc17ca2e1a7fc1c2825d4cb4d5f7577dba994d45904f608")
addappid(384683, 1, "3bb1a6cab179a3114d670659ec3f293d3cc490bcaf700e6aa14941447138cb59")
addappid(384684, 1, "54ea2971b07cb87bbb718c0dd00b5fc86a151ee12b58d783ce007d1cd6691044")
