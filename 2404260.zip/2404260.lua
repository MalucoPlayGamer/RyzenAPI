-- Lua provided by SkyAPI 
-- Game: AppID 2404260
addappid(2404260)
addappid(2404261, 1, "1a3a72b84284baeaa21d38348d7b79488985526661ce0da8153570e55266a2c1")
