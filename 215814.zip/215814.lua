-- Lua provided by RyzenAPI
-- Game: 215814

-- MAIN APPLICATION
addappid(215814)
-- Game: addappid(215814)

-- MAIN APP DEPOTS / PACKAGES
addappid(215814,0,"e14043563143bffb1fff84c537c47f631d531df0599c672360d68f798d0b10e0")
