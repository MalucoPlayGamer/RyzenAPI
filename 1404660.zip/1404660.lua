-- Lua provided by RyzenAPI 
-- Game: Psych
addappid(1404660)
addappid(1404661, 1, "0a7b3c036984877b676a46908497166c70b43dbba5abbc1c8f9d277b3c72ad62")
