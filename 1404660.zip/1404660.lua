-- Lua provided by RyzenAPI
-- Game: Psych

-- MAIN APPLICATION
addappid(1404660)
-- Game: addappid(1404660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404661, 1, "0a7b3c036984877b676a46908497166c70b43dbba5abbc1c8f9d277b3c72ad62")
