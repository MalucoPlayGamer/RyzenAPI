-- Lua provided by RyzenAPI
-- Game: Shadow of the Ninja - Reborn Digital Soundtrack

-- MAIN APPLICATION
addappid(2880920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880921, 1, "8dcb817bc96fe5d4844308868e9fce56b330cbfd482fb17635af9b5691095108")
addappid(2880922, 1, "f200e7630302459be3fdfc8390b75068629996675073e3f3a1dbba26f820985a")
