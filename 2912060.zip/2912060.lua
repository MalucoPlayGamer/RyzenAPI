-- Lua provided by SkyAPI 
-- Game: Color Splash: Rodents
addappid(2912060)
addappid(2912061, 1, "7c14f87fbf85186fafc691ab74464e88c3f0a66c577b0c6bc23b462aa87d46de")
