-- Lua provided by RyzenAPI
-- Game: Game: Color Splash: Rodents

-- MAIN APPLICATION
addappid(2912060)
-- Game: addappid(2912060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2912061, 1, "7c14f87fbf85186fafc691ab74464e88c3f0a66c577b0c6bc23b462aa87d46de")
