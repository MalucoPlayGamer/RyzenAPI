-- Lua provided by RyzenAPI
-- Game: 760400

-- MAIN APPLICATION
addappid(760400)
-- Game: addappid(760400)

-- MAIN APP DEPOTS / PACKAGES
addappid(760401, 1, "1671b7334627cadecf77420086d2affcfa196eab93f03b692324f8017f33c330")
