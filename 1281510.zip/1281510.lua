-- Lua provided by RyzenAPI
-- Game: Kirakira stars project Nagisa

-- MAIN APPLICATION
addappid(1281510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281511, 1, "64784c7739c5eda3813495ea9c47b192f6f8866ba31fb831bfc15cf5f1d8bcd3")
