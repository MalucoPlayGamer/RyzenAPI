-- Lua provided by RyzenAPI
-- Game: 923590

-- MAIN APPLICATION
addappid(923590)
-- Game: addappid(923590)

-- MAIN APP DEPOTS / PACKAGES
addappid(923591, 1, "041c9c752a563047f973a72df4fb82d12dd1c68636baab239c50810d2760b000")
