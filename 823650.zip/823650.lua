-- Lua provided by RyzenAPI
-- Game: Game: AppID 823650

-- MAIN APPLICATION
addappid(823650)
-- Game: addappid(823650)

-- MAIN APP DEPOTS / PACKAGES
addappid(823651, 1, "ab531acabaa4fce1c4df3e010e4e6dc9a038ebe72da93fe66c84af2b98c7de5f")
