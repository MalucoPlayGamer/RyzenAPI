-- Lua provided by RyzenAPI
-- Game: Game: Joe Danger 2: The Movie

-- MAIN APPLICATION
addappid(242110)
-- Game: addappid(242110)

-- MAIN APP DEPOTS / PACKAGES
addappid(242111, 1, "c46ff154e673e17af8a00ecc43f2cc22f72732ce66f87392f71488758197aff8")
addappid(242112, 1, "5d50923635b0ed8fb8c74bb4889db75de1840c4d737d4afc0f171785db8894fd")
addappid(242113, 1, "4df8662d3e10a76090a30c27097f0d4b91a9d4f61f3ef2e61df06b024e0871e3")
addappid(242120, 0, "70b432fc13cb3ec47af8ce1d8d975019176e622096a3ac1416068264f4729f8b")
