-- Lua provided by RyzenAPI
-- Game: 羽翼的祈愿 - Feather Of Praying

-- MAIN APPLICATION
addappid(869840)

-- MAIN APP DEPOTS / PACKAGES
addappid(869841, 1, "13a44308d32fd128ad6a1daeda6463f293bcd10948d9e50bd70f72305314dbbe")
