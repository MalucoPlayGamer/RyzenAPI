-- Lua provided by RyzenAPI
-- Game: Road to Ballhalla

-- MAIN APPLICATION
addappid(425410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425411, 1, "1a47f1bffeac2a5a122a8f390ae5510950825f2d8d7579ce009761c09b895220")

