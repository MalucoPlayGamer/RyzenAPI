-- Lua provided by RyzenAPI
-- Game: addappid(425410)

-- MAIN APPLICATION
addappid(425410)

-- MAIN APP DEPOTS / PACKAGES
addappid(425411, 1, "1a47f1bffeac2a5a122a8f390ae5510950825f2d8d7579ce009761c09b895220")
