-- Lua provided by RyzenAPI
-- Game: addappid(488310)

-- MAIN APPLICATION
addappid(488310)

-- MAIN APP DEPOTS / PACKAGES
addappid(488311, 1, "6a8f5a73fe66474a12587100029fef4b0c2a1344323ae6d0167708fefb00b7b3")
