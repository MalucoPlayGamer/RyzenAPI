-- Lua provided by RyzenAPI
-- Game: Building 847

-- MAIN APPLICATION
addappid(1373380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1373381, 1, "395b52365d64305491afa88a5459683bc064164a4a16f21d56b09f1af6be0e94")

