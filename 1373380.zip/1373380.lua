-- Lua provided by RyzenAPI
-- Game: Game: Building 847

-- MAIN APPLICATION
addappid(1373380)
-- Game: addappid(1373380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373381, 1, "395b52365d64305491afa88a5459683bc064164a4a16f21d56b09f1af6be0e94")
