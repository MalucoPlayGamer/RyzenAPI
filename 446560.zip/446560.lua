-- Lua provided by RyzenAPI 
-- Game: Just Dance 2017
addappid(446560)
addappid(446561, 1, "a3d6565bf3f549c0c1340d58e3ee6a95f234f8ceab87c6bfe7c6e61963fdd677")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
