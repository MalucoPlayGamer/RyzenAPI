-- Lua provided by RyzenAPI
-- Game: Just Dance 2017

-- MAIN APPLICATION
addappid(446560)
addappid(541360)
addappid(541361)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(446561, 1, "a3d6565bf3f549c0c1340d58e3ee6a95f234f8ceab87c6bfe7c6e61963fdd677")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

