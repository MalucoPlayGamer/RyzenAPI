-- Lua provided by RyzenAPI
-- Game: addappid(1258290)

-- MAIN APPLICATION
addappid(1258290)
addappid(1259200)
addappid(1259900)
addappid(1260900)
addappid(1270790)
addappid(1271800)
addappid(1272180)
addappid(1272880)
addappid(1273860)
addappid(1275100)
addappid(1275780)
addappid(1276770)
addappid(1277990)
addappid(1278980)
addappid(1281000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258291, 1, "52abc72171a656ce7e6db39b2b2c4ac498895980496e2490beb8c933f421f9aa")
