-- Lua provided by RyzenAPI
-- Game: ANIMARAMA

-- MAIN APPLICATION
addappid(2015940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015941, 1, "7feed9655b85d5c3df41d1eedc61afbc7b18d97517e8a6a98c7425ce4aa6acc4")
