-- Lua provided by RyzenAPI
-- Game: Game: AppID 3172060

-- MAIN APPLICATION
addappid(3172060)
-- Game: addappid(3172060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172061, 1, "d66c7efadc63e9260aa599f569707a81a0981a2ac669d64fa1149f1ec7c9f0f1")
