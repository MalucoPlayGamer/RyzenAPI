-- Lua provided by RyzenAPI
-- Game: QUAKE Mission Pack 2: Dissolution of Eternity

-- MAIN APPLICATION
addappid(9030)

-- MAIN APP DEPOTS / PACKAGES
addappid(9031, 1, "7ef94b5c717c5cba5594033a30f064c88ddde36483df8599209a619f8cc6bbe3")

