-- Lua provided by RyzenAPI
-- Game: Game: Little Man Has a Day

-- MAIN APPLICATION
addappid(2494720)
-- Game: addappid(2494720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494721, 1, "9613fe03f1d218b7d3c207e7394db45f505d3912760f153da1caf053d98e74e1")
