-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Weapon `Fork`

-- MAIN APPLICATION
addappid(1176623)
-- Game: addappid(1176623)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176623,0,"17e5a774d054a88796d6555b8153b64705422150ff6162c3f9c01c50f327421c")
