-- Lua provided by RyzenAPI
-- Game: addappid(604140)

-- MAIN APPLICATION
addappid(604140)

-- MAIN APP DEPOTS / PACKAGES
addappid(604141, 1, "ad71cb97995a5b0e15f99cb33089d0bc7e0d1be27e71f13f00eb360dd3f56d3a")
