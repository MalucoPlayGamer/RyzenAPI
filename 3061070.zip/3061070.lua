-- Lua provided by RyzenAPI
-- Game: Game: Valet Simulator: Parking & Business

-- MAIN APPLICATION
addappid(3061070)
-- Game: addappid(3061070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061071, 1, "675fc995f60e2ded16969056df49dad0a4271f2034923ad3e10d451b09cad679")
