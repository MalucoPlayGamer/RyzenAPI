-- Lua provided by RyzenAPI
-- Game: Magic Duels

-- MAIN APPLICATION
addappid(316010)
-- Game: addappid(316010)

-- MAIN APP DEPOTS / PACKAGES
addappid(316011, 1, "990bcd60ef9a365f7c33490f019a778966179f532f0ed4dc3f769cf1d415c846")
