-- Lua provided by RyzenAPI
-- Game: 1943700

-- MAIN APPLICATION
addappid(1943700)
-- Game: addappid(1943700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943701, 1, "a358a424b1dadd4e6868a9813602e8949e1b5de51624adc4dfff8e04d5e9cc24")
