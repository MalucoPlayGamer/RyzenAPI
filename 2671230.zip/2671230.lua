-- Lua provided by RyzenAPI
-- Game: BLADECHIMERA

-- MAIN APPLICATION
addappid(2671230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(2671231, 1, "83393dbe4d646f58e4904203ccee9e147af7a942cdec79617be2e13061f0f3ea")

