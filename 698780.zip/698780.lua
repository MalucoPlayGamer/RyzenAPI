-- Lua provided by RyzenAPI
-- Game: Doki Doki Literature Club!

-- MAIN APPLICATION
addappid(698780)
addappid(717250)
-- Game: addappid(698780)

-- MAIN APP DEPOTS / PACKAGES
addappid(698781, 1, "c24a048a8453bd60406b67d609faf739001185d7e0de5388cabdea3b45b0c73b")
