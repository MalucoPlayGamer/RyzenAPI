-- Lua provided by RyzenAPI
-- Game: One Fateful Night

-- MAIN APPLICATION
addappid(1733310)
-- Game: addappid(1733310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733311, 1, "87255e67db599d51b69c1079b919a523ce047146a00e364230077d4577bab4fd")
