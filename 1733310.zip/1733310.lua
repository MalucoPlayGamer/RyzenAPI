-- Lua provided by RyzenAPI
-- Game: One Fateful Night

-- MAIN APPLICATION
addappid(1733310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1733311, 1, "87255e67db599d51b69c1079b919a523ce047146a00e364230077d4577bab4fd")

