-- Lua provided by RyzenAPI
-- Game: addappid(3527410)

-- MAIN APPLICATION
addappid(3527410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3527410,0,"a6b757b89d8447056bb087290388bde63bf046cc0d4b2f1beae3d904f481ed24")
