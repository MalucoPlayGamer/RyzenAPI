-- Lua provided by RyzenAPI
-- Game: Crime Simulator

-- MAIN APPLICATION
addappid(2737070)
addappid(4794830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737071,0,"36e272c2274c8d6dbf4a697d1faa618de36bbacf8439215d60cca4350601aedb")

