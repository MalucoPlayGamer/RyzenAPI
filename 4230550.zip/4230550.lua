-- 4230550's Lua and Manifest Created by Hubcap Manifest
-- MILFS 2025
-- Created: August 17, 2026 at 14:26:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4230550) -- MILFS 2025
-- MAIN APP DEPOTS
addappid(4230551, 1, "ad02fb64600d8bcff3dda86710612046c66203aa2e6b6f37c4bb75d01eb6850b") -- Depot 4230551
setManifestid(4230551, "8706891530500914829", 331859530)