-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2594080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594080,0,"ac02903c3ad99f5468432fe21b87432f0d4cf53c244eed103968ab2abfafb322")
