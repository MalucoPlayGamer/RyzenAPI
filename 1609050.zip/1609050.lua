-- Lua provided by RyzenAPI
-- Game: Unforgettable You

-- MAIN APPLICATION
addappid(1609050)
addappid(1610580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609051, 1, "04164907ff6143afea526e132fdd4c7c29cb96cf9311dec3b9279b336e6d483a")
addappid(1609052, 1, "a900be4f875e5fdfecacb38044d29e6b5bd10ff48363f8206b4edf944438fc94")

