-- Lua provided by RyzenAPI 
-- Game: AppID 454140
addappid(454140)
addappid(454141, 1, "36ddbbe95bb85acdf0afd2249b28a3cc5adb2e7ef04796591ab4ca74f9e6a1ca")
