-- Lua provided by RyzenAPI
-- Game: AppID 1279410

-- MAIN APPLICATION
addappid(1279410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279411, 1, "4cf4e12f6bde29c0bceb93e67845c061e3b1ffee3a0e886615471e95ebf066e3")

