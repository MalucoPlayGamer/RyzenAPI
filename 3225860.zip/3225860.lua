-- Lua provided by RyzenAPI
-- Game: Super Ricko’s Islands

-- MAIN APPLICATION
addappid(3225860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225861, 1, "e42733340c988827accccc1dd1c3684406148587ebca429970c10357f9a20eaa")
