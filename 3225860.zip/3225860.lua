-- Lua provided by RyzenAPI
-- Game: Super Ricko’s Islands

-- MAIN APPLICATION
addappid(3225860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225861, 1, "e42733340c988827accccc1dd1c3684406148587ebca429970c10357f9a20eaa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
