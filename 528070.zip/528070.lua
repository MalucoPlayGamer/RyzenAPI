-- Lua provided by RyzenAPI
-- Game: addappid(528070)

-- MAIN APPLICATION
addappid(528070)

-- MAIN APP DEPOTS / PACKAGES
addappid(528071, 1, "aca1d73a33612942f95fff36994ea5b4480d987556bff929885f2d5dd3c6ef02")
