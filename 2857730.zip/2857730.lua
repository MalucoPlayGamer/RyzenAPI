-- Lua provided by RyzenAPI 
-- Game: Bakahazard 1+2
addappid(2857730)
addappid(2857731, 1, "baff89fbdaa8311cf5273c4037530eaf7dec4de595fa1e58220913345ed34bd7")
addappid(2857732, 1, "f816af3f76ad6c552ebb0f57c6e91c7cae5efb383df26780ff147d2f041a6251")
addappid(2858300)
