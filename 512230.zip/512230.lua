-- Lua provided by RyzenAPI
-- Game: 512230

-- MAIN APPLICATION
addappid(512230)
-- Game: addappid(512230)

-- MAIN APP DEPOTS / PACKAGES
addappid(512231, 1, "a2830d865ed368a58a846b3f30f87c8adda75ed9b0b83db6bee0277e5e77ef3e")
