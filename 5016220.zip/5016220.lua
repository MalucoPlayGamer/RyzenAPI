-- Lua provided by RyzenAPI
-- Game: Pixel Airport Tycoon 3D

-- MAIN APPLICATION
addappid(5016220) -- Pixel Airport Tycoon 3D
-- addappid(5095240) -- Depot 5095240 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(5016221, 1, "76a551ca7ab87ca7ed201cfbfc858c0dd350aec8a708079fd5c1944a69251fea") -- Depot 5016221

