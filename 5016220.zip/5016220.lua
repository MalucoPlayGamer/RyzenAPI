-- 5016220's Lua and Manifest Created by Hubcap Manifest
-- Pixel Airport Tycoon 3D
-- Created: August 14, 2026 at 06:00:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5016220) -- Pixel Airport Tycoon 3D
-- MAIN APP DEPOTS
addappid(5016221, 1, "76a551ca7ab87ca7ed201cfbfc858c0dd350aec8a708079fd5c1944a69251fea") -- Depot 5016221
setManifestid(5016221, "931050306257049951", 769811147)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(5095240) -- Depot 5095240 (empty depot)