-- Lua provided by RyzenAPI
-- Game: DSquad War

-- MAIN APPLICATION
addappid(661370)

-- MAIN APP DEPOTS / PACKAGES
addappid(661371, 1, "1ca646b575bf88c8276e12f795487ec396e3779bdd3b0f065e4d0758478393f4")

