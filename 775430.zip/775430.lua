-- Lua provided by RyzenAPI
-- Game: addappid(775430)

-- MAIN APPLICATION
addappid(775430)

-- MAIN APP DEPOTS / PACKAGES
addappid(775431, 1, "6b2badd0c90b2228c6615b5f7998cf9acfac86fac2c96dfbd8a08a828aa13e80")
