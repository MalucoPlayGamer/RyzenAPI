-- Lua provided by RyzenAPI
-- Game: Game: SURVIVAL IN THE BACKROOMS

-- MAIN APPLICATION
addappid(2184110)
-- Game: addappid(2184110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184111, 1, "1fceda987edfc72a2ed4a1d4351d19cb9f0e9e4b82e9361907c2af3d34e9ac0d")
