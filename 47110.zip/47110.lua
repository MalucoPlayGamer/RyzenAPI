-- Lua provided by RyzenAPI
-- Game: Escape From Paradise

-- MAIN APPLICATION
addappid(47110)

-- MAIN APP DEPOTS / PACKAGES
addappid(47111, 1, "84ba831f93bb834162a9328e902387aeb763a46f3cc3af2ac1b7753e2b0987fb")

