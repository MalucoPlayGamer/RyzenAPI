-- Lua provided by RyzenAPI
-- Game: Inklings

-- MAIN APPLICATION
addappid(498720)

-- MAIN APP DEPOTS / PACKAGES
addappid(498721, 1, "15e9da657dd35da5f6b9fb7a49ffcc8ededd4a1e0dd135128ebf8a0c8c106fe1")
addappid(498722, 1, "b1b88dc079ae1d2a8a9d3793f3122172fcb99dd373a31263ce80f73b8b4ddd0a")
addappid(498723, 1, "9ee258e46b5ef983b252de2d44c22bec820442ed4aa33c2246c36acb6813fb8b")

