-- Lua provided by RyzenAPI
-- Game: 述罪 Playtest

-- MAIN APPLICATION
addappid(3333280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333281, 1, "47178b497308ba84351149b3947de744d9de78ee148ea09aa1fcc290784c0734")

