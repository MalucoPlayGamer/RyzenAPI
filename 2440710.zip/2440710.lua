-- Lua provided by RyzenAPI
-- Game: Surface Runner

-- MAIN APPLICATION
addappid(2440710)
-- Game: addappid(2440710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440711, 1, "f09e3924bfe87e52cee95cac2f21bd112f6b6b57e85e727e48fd78736180594d")
