-- Lua provided by RyzenAPI
-- Game: Surface Runner

-- MAIN APPLICATION
addappid(2440710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2440711, 1, "f09e3924bfe87e52cee95cac2f21bd112f6b6b57e85e727e48fd78736180594d")

