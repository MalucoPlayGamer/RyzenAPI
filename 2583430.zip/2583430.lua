-- Lua provided by RyzenAPI
-- Game: Alice in the Nightmare Land

-- MAIN APPLICATION
addappid(2583430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583431, 1, "8d8f86d22fbf30d1a43cb75940038463c7d5c37f8d4bcbf3ad5d972508782061")
addappid(2583432, 1, "6cb1d2d9b31487ff44a3d981cdbcf9fd07e541781968d5811eae6446893c5e7c")
addappid(2583433, 1, "8f7751bb2a2cea8c8c477bfce02b687e0122a67cac0fa61d7cf2a12fe693f477")
addappid(2583434, 1, "4d426d3a9d3a698b5bab905e83f4db5e1a728afc03c6ae173a6e06f7f5157fbe")

