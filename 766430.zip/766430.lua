-- Lua provided by RyzenAPI
-- Game: addappid(766430)

-- MAIN APPLICATION
addappid(766430)

-- MAIN APP DEPOTS / PACKAGES
addappid(766431, 1, "3d131dfbb2c617ae32bf4a8fbf3272de0abf04b80ce1b15ff96cfbea7fb07321")
