-- Lua provided by RyzenAPI
-- Game: CUFFBUST

-- MAIN APPLICATION
addappid(2592220)
addappid(3955640)
addappid(3958060)
addappid(3958070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2592220,0,"d31f0b5de13974c7489327aa2ad9d9b16da25746699fee261e8a59252e03f1aa")
addappid(2592221,0,"914c0251c64db12c834ce77fb3a670a605dea4f6824171c1529e0900c1f58342")

