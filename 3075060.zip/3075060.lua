-- Lua provided by RyzenAPI
-- Game: 3075060

-- MAIN APPLICATION
addappid(3075060)
-- Game: addappid(3075060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075061, 1, "1987bdd42e415f043a0555d34a02994d99278ce4cb3c19cd37d02ba5ad8ba00e")
