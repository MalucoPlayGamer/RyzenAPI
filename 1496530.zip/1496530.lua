-- Lua provided by RyzenAPI
-- Game: Game: Cinders Of Hades

-- MAIN APPLICATION
addappid(1496530)
-- Game: addappid(1496530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496531, 1, "789d75e164b88269898362eb75aaac13b276ab9c6c26c22d02afa7afc6db8ade")
