-- Lua provided by RyzenAPI
-- Game: Game: AppID 740170

-- MAIN APPLICATION
addappid(740170)
-- Game: addappid(740170)

-- MAIN APP DEPOTS / PACKAGES
addappid(740171, 1, "7b751e2ebc8690cabc5e8e42ef190d0d3f3e4ed5b5a701a06cf82a80267ce694")
