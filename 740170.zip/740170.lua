-- Lua provided by RyzenAPI 
-- Game: AppID 740170
addappid(740170)
addappid(740171, 1, "7b751e2ebc8690cabc5e8e42ef190d0d3f3e4ed5b5a701a06cf82a80267ce694")
