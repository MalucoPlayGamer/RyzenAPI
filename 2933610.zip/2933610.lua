-- Lua provided by RyzenAPI
-- Game: 2933610

-- MAIN APPLICATION
addappid(2933610)
-- Game: addappid(2933610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933611, 1, "b8ec973a3e88f3771a9c57b2e79b84ec0d8fd06298b17a3660082bb6190f3db1")
