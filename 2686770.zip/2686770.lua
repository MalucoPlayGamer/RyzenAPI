-- Lua provided by RyzenAPI
-- Game: 2686770

-- MAIN APPLICATION
addappid(2686770)
-- Game: addappid(2686770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686771, 1, "7b14be018829e673c5b3a48ba9b20a4a6cce127ecba4edf6b5e00786741a9ab7")
