-- Lua provided by RyzenAPI
-- Game: AppID 265120

-- MAIN APPLICATION
addappid(265120)
addappid(288240)
addappid(288980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(265121, 1, "d1fcf3448fe50dafd61bf296e2c98ccaa1ea1bf7f38cdc587ca86d6bdbf66e7a")

