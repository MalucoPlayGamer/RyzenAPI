-- Lua provided by RyzenAPI
-- Game: addappid(265120)

-- MAIN APPLICATION
addappid(265120)
addappid(288240)
addappid(288980)

-- MAIN APP DEPOTS / PACKAGES
addappid(265121, 1, "d1fcf3448fe50dafd61bf296e2c98ccaa1ea1bf7f38cdc587ca86d6bdbf66e7a")
