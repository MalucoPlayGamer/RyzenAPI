-- Lua provided by RyzenAPI
-- Game: addappid(45000)

-- MAIN APPLICATION
addappid(45000)

-- MAIN APP DEPOTS / PACKAGES
addappid(45001, 1, "dc2252a54790a0bf2b4d23b5c070266ceadd727daec38912648554dd89788ffb")
