-- Lua provided by RyzenAPI
-- Game: Battletank LOBA

-- MAIN APPLICATION
addappid(337730)

-- MAIN APP DEPOTS / PACKAGES
addappid(337731, 1, "08e2809b0738e21ac4e2ab0fb3c33f2aa93bb10064e66d53cc83d4e730ba8a15")
