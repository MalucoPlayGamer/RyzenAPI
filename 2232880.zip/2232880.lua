-- Lua provided by RyzenAPI
-- Game: setManifestid(2232882,"7149208090351849459")

-- MAIN APPLICATION
addappid(2232880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232882,0,"71d9f856e62caa4bf86b498cab27355028f4af93ca0b6abfaea4a2c7296c8d0d")
