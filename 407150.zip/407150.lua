-- Lua provided by RyzenAPI
-- Game: Trap Them - Sniper Edition

-- MAIN APPLICATION
addappid(407150)

-- MAIN APP DEPOTS / PACKAGES
addappid(407151, 1, "965b83bda21b0fc6396befe80f479de2ec7b92c9346b50772a4162728a0a3ee2")
