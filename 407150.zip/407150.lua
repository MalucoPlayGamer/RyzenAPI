-- Lua provided by RyzenAPI
-- Game: Trap Them - Sniper Edition

-- MAIN APPLICATION
addappid(407150)

-- MAIN APP DEPOTS / PACKAGES
addappid(407151, 1, "965b83bda21b0fc6396befe80f479de2ec7b92c9346b50772a4162728a0a3ee2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
