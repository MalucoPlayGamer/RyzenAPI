-- Lua provided by RyzenAPI
-- Game: Color Cube

-- MAIN APPLICATION
addappid(1496620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496621, 1, "ca8d67abfc10e0472ba45b80148d812dd9ef160826485bfcef24e4f951d564ae")
