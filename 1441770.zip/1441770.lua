-- Lua provided by RyzenAPI
-- Game: 1441770

-- MAIN APPLICATION
addappid(1441770)
-- Game: addappid(1441770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441771, 1, "9d912f6c543490ff8e621eee0daff9258c1b50c0bade78da3d00b2c781a4c182")
