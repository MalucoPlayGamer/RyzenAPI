-- Lua provided by RyzenAPI
-- Game: Dolls Nest

-- MAIN APPLICATION
addappid(1839430)
addappid(3309800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839431, 1, "f909216fd63f07d4cc6cad35d3482673e78c92b1b28db3b493113c7f7145c40a")
addappid(1839432, 1, "7a4af8a39e4d674b4af25ac5edbf78f3330b80a25891cdc78a58809863bd41b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4112710)
addappid(4123330)
addappid(4123340)
