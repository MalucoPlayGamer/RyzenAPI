-- Lua provided by RyzenAPI
-- Game: Dolls Nest

-- MAIN APPLICATION
addappid(1839430)
addappid(3309800)
-- Game: addappid(1839430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839431, 1, "f909216fd63f07d4cc6cad35d3482673e78c92b1b28db3b493113c7f7145c40a")
addappid(1839432, 1, "7a4af8a39e4d674b4af25ac5edbf78f3330b80a25891cdc78a58809863bd41b9")
