-- Lua provided by RyzenAPI
-- Game: All Will Fall Playtest

-- MAIN APPLICATION
addappid(3320480)
-- Game: addappid(3320480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320481, 1, "ab9ae9a46340a8a3c4d32c933103c75b781db714993c36db0df0324c08b6cb29")
