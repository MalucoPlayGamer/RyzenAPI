-- Lua provided by RyzenAPI
-- Game: The Banner Saga 2

-- MAIN APPLICATION
addappid(281640)

-- MAIN APP DEPOTS / PACKAGES
addappid(281641, 1, "7fcd1bb5051f6247f245960af3bd4e5208fc431804cbcf0a3402627c30ee022d")
addappid(281642, 1, "23f69f71a56c710f95570f23b1c4a413605b356b34bd6368e2072264e20bc39d")
addappid(281643, 1, "9cf33c1c8eda8c0b95e8960c0381bd2f0992b813da85d1d5de733bdd4f83bc53")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
