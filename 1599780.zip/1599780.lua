-- Lua provided by RyzenAPI
-- Game: Afterlove EP

-- MAIN APPLICATION
addappid(1599780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599781, 1, "7f040a1f00b276e19dc53c2c92828047371b4b63ded93eec07754fbfc785f586")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3407400)
