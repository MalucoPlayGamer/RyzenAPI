-- Lua provided by RyzenAPI
-- Game: Keep on Mining! - Worlds

-- MAIN APP DEPOTS / PACKAGES
addappid(4286550, 1, "2eb48304e26ac2d620c4ccbe213c65aa642b8689ae29eb47698830589d401eaf") -- Keep on Mining! - Worlds
addappid(4286551, 1, "2500be67ef3fc3ff04d580bc360128433d6d9351b464524dad7dc2257c6d2918") -- Depot 4286551

