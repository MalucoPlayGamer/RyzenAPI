-- Lua provided by RyzenAPI
-- Game: Forbidden place

-- MAIN APPLICATION
addappid(1741220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741221, 1, "c7d16272c894d1d730916e7d2d4bac330304e6a85b9e12ca7bd93e0a0d2ae188")
