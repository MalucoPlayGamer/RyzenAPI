-- Lua provided by RyzenAPI
-- Game: Game: AppID 1337600

-- MAIN APPLICATION
addappid(1337600)
-- Game: addappid(1337600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337601, 1, "ab50cd8cf3b738d47edaa33d95700383e4aadcd6f363195437532fd7b693eea5")
