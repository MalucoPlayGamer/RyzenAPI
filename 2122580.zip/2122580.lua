-- Lua provided by RyzenAPI
-- Game: 2122580

-- MAIN APPLICATION
addappid(2122580)
-- Game: addappid(2122580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122581, 1, "5a4ead3a18e389aa785501b033f056e2331004455fe3fe3f24f30e159626badf")
