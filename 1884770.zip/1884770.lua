-- Lua provided by RyzenAPI
-- Game: Oaken Demo

-- MAIN APPLICATION
addappid(1884770)
-- Game: addappid(1884770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884771, 1, "e613df64c9ab83580ca4c2770f910bad76771083d994f316238711cb62a7bcfb")
