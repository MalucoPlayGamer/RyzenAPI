-- Lua provided by RyzenAPI
-- Game: Aircraft Evolution

-- MAIN APPLICATION
addappid(597030)
addappid(914060)

-- MAIN APP DEPOTS / PACKAGES
addappid(597031, 1, "048342f9de7044b2b2a19a9b3ed8db89d87576dae49d6ba62423419d5fa45cba")
