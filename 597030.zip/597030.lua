-- Lua provided by RyzenAPI
-- Game: Game: AppID 597030

-- MAIN APPLICATION
addappid(597030)
-- Game: addappid(597030)

-- MAIN APP DEPOTS / PACKAGES
addappid(597031, 1, "048342f9de7044b2b2a19a9b3ed8db89d87576dae49d6ba62423419d5fa45cba")
