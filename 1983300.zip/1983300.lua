-- Lua provided by RyzenAPI
-- Game: Paper Ghost Stories: Third Eye Open

-- MAIN APPLICATION
addappid(1983300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983301, 1, "b3d198e5355067a73b7b0f9dec3a8ae8160d4d0e5545d0ff10d617818acbd862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
