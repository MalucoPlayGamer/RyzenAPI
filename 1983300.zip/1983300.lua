-- Lua provided by RyzenAPI
-- Game: addappid(1983300)

-- MAIN APPLICATION
addappid(1983300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983301, 1, "b3d198e5355067a73b7b0f9dec3a8ae8160d4d0e5545d0ff10d617818acbd862")
