-- Lua provided by RyzenAPI
-- Game: AppID 2129230

-- MAIN APPLICATION
addappid(2129230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129231, 1, "d59ac050d4a46e3c19f0ac807cbffb79a1ed12c8afb47934ea164fb8538a5f0a")

