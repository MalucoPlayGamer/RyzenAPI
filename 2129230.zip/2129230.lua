-- Lua provided by RyzenAPI
-- Game: AppID 2129230

-- MAIN APPLICATION
addappid(2129230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129231, 1, "d59ac050d4a46e3c19f0ac807cbffb79a1ed12c8afb47934ea164fb8538a5f0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
