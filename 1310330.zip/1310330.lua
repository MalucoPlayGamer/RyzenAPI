-- Lua provided by SkyAPI 
-- Game: AppID 1310330
addappid(1310330)
addappid(1310331, 1, "b0ba59c0af44f1c125682594cfc5f8728e41bbe23303f2fdb94ddb5c0d7526b9")
