-- Lua provided by RyzenAPI
-- Game: addappid(1310330)

-- MAIN APPLICATION
addappid(1310330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310331, 1, "b0ba59c0af44f1c125682594cfc5f8728e41bbe23303f2fdb94ddb5c0d7526b9")
