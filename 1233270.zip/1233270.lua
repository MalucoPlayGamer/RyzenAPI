-- Lua provided by RyzenAPI
-- Game: Game: AppID 1233270

-- MAIN APPLICATION
addappid(1233270)
-- Game: addappid(1233270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233271, 1, "de577ded1fe5226b7935c00e7c5ef09042445071d73943b44885452dd8db9b86")
