-- Lua provided by RyzenAPI
-- Game: AppID 603550

-- MAIN APPLICATION
addappid(603550)
-- Game: addappid(603550)

-- MAIN APP DEPOTS / PACKAGES
addappid(603551, 1, "90ed7b95d55bb0cc46649128a020094133e7c1c830fb45c64970e442cf33d750")
