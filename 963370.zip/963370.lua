-- Lua provided by RyzenAPI
-- Game: 963370

-- MAIN APPLICATION
addappid(963370)
-- Game: addappid(963370)

-- MAIN APP DEPOTS / PACKAGES
addappid(963371, 1, "286ea725935999461a215601fc70a58fd2cd3d226ae5a71df0fc36d1168c5122")
