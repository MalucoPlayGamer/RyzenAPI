-- Lua provided by RyzenAPI
-- Game: addappid(1101000)

-- MAIN APPLICATION
addappid(1101000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101001, 1, "95613347e9d46b5d6e8aff900c2a096e4c05f2eb479b16d16a9e01b7696e8cd4")
