-- Lua provided by SkyAPI 
-- Game: AppID 2023500
addappid(2023500)
addappid(2023501, 1, "0cf0f352ed1fce9ba5f519e0369b88c7711343750ba721abbefbeb26d28387fa")
