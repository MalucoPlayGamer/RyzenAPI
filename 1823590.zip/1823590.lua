-- Lua provided by RyzenAPI
-- Game: 1823590

-- MAIN APPLICATION
addappid(1823590)
-- Game: addappid(1823590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823591, 1, "90980352f3ff9d3a1261c029bf00881df56f20e3cbf671a9e038dfa6bb26cad8")
