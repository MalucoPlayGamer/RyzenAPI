-- Lua provided by SkyAPI 
-- Game: 112 Operator
addappid(793460)
addappid(793461, 1, "2923abff356f40a6626759eef98e74c0fab20968d61d1d0a75916c77ea6bc0b6")
addappid(793462, 1, "6f789024b4260378373b82f48b9ebf951de6ee06ca48a46558fdbfd80b5efd04")
