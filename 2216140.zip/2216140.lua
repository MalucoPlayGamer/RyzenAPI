-- Lua provided by RyzenAPI
-- Game: AppID 2216140

-- MAIN APPLICATION
addappid(2216140)
-- Game: addappid(2216140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216141, 1, "03be746805dcc216d4cc2eb9b8fb7752534aefa84997a6112da6fd6aab3d6e8f")
