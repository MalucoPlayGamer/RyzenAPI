-- Lua provided by RyzenAPI
-- Game: 2681260

-- MAIN APPLICATION
addappid(2681260)
-- Game: addappid(2681260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681262,0,"d63b8472cea040072fad3fa0d23776c9f068ea27f37a292ed8d03fd51376d689")
