-- Lua provided by RyzenAPI
-- Game: 1168190

-- MAIN APPLICATION
addappid(1168190)
-- Game: addappid(1168190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168192,0,"702492197959afb7929b3fdfd96491b02db14cf69d92fe1c41a88f1da208199c")
