-- Lua provided by RyzenAPI
-- Game: Cinders

-- MAIN APPLICATION
addappid(293680)
-- Game: addappid(293680)

-- MAIN APP DEPOTS / PACKAGES
addappid(293681, 1, "6ee6c660703f7b81a6ccbd742b6a39cf8d16c5606134bae4b0190cad024951ef")
