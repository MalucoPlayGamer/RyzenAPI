-- Lua provided by RyzenAPI
-- Game: addappid(2374320)

-- MAIN APPLICATION
addappid(2374320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374321, 1, "a098ac88d513bd5d63c36ea8262326b981c687dd6549aa0cd4e021e9f9ea7ac0")
