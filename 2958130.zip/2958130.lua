-- Lua provided by RyzenAPI
-- Game: Jurassic World Evolution 3

-- MAIN APPLICATION
addappid(2958130)
addappid(3651190)
addappid(3651200)
addappid(4131660)
addappid(4131670)
addappid(4553980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958131,0,"dc7cb4cb8d7d76fdcab84fed34fa1f799e7459cf1be5ed041116ed846211889d")

