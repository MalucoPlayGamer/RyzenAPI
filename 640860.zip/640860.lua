-- Lua provided by RyzenAPI
-- Game: Stone Rage

-- MAIN APPLICATION
addappid(640860)

-- MAIN APP DEPOTS / PACKAGES
addappid(640861,0,"99222824d810714575639d819d110bfa7322f50a810da2d66fef3a20e229162d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
