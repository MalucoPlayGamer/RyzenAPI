-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Soft Rock Radio

-- MAIN APPLICATION
addappid(2427745)
-- Game: addappid(2427745)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427745,0,"3ab8a19fe1ec5a750b6a807a30203880c99504c321500a7e64e18c361e7cce0f")
