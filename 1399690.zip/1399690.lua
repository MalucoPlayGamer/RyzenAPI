-- Lua provided by RyzenAPI
-- Game: Reverie Knights Tactics

-- MAIN APPLICATION
addappid(1399690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399691, 1, "ba48c2204cefafdcb5daea451281ac4d1bdc28a0746cc0c8365cf1d682703c78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
