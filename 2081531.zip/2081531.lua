-- Lua provided by RyzenAPI
-- Game: Endling - Extinction is Forever - Wallpaper Pack

-- MAIN APPLICATION
addappid(2081531)
-- Game: addappid(2081531)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081531,0,"f1738038675b3a68fa8fddb46a7eeb21bd45a7a733410a71851c8c9d2ced7eb2")
addtoken(2081531,5802627578465250095)
