-- Lua provided by RyzenAPI
-- Game: Blaite

-- MAIN APPLICATION
addappid(461730)

-- MAIN APP DEPOTS / PACKAGES
addappid(461731, 1, "b47df4946b855953f8481a621c56904ca9106391a181be63a62551924c3af490")
addappid(461732, 1, "165945e65305c71b290d0c8b01b01b12a6c3401ff7c8bdc79cc16480e92cc74c")
addappid(461733, 1, "4ca2b9da6a9bed9efaae8879b2ae53cd3fadb6d6d98612f219b6111cacfe3592")
addappid(461734, 1, "63f57685091b5be4daf784d7208f0779e4dc6f69baf9e2dc9c3ac4670885078d")
addappid(461735, 1, "654924215f349644b7ee939a0a8eb9ad71e9762f5dfc2fbbcd3406492b09d705")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
