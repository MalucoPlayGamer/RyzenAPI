-- Lua provided by RyzenAPI
-- Game: SUDOKU

-- MAIN APPLICATION
addappid(681170)
addappid(709580)

-- MAIN APP DEPOTS / PACKAGES
addappid(681171, 1, "2a2a6b7d666c02271985449258c5d1f49bee16bb984379ac6bb62dabcd57c864")
