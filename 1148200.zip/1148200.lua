-- Lua provided by RyzenAPI
-- Game: Fadó: Chapter One

-- MAIN APPLICATION
addappid(1148200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148202,0,"ddfc74f60b36393239ec6a49916832faf253478bef3a27c9b9fe42a7839cb44b")

