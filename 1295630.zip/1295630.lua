-- Lua provided by RyzenAPI
-- Game: Helskate

-- MAIN APPLICATION
addappid(1295630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295631, 1, "77b6ee1f6ff0bac4ea70132e9d60eb7cf9385c64a7cf1d24418c0f8695b3be3b")
addappid(1295632, 1, "c70f23c96a9926564d6c1700385873c7de5d51efe2898786da53a9f1711539cc")
