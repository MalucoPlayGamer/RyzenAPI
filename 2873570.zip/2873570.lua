-- Lua provided by RyzenAPI
-- Game: addappid(2873570)

-- MAIN APPLICATION
addappid(2873570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873570,0,"0112e9dce211b80465433d8f75f2aaddb769530350f876f1fbc6be52efc5ab11")
