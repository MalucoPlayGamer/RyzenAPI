-- Lua provided by RyzenAPI
-- Game: AppID 1022980

-- MAIN APPLICATION
addappid(1022980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022981, 1, "23cc5af30ebc1c8e4c2abf3e5b4114dbf78fffbb24855fa3ac13ed24a116c3ab")
addappid(1022982, 1, "076062f175ac5ad3eb3c620073f57acb90bb47aa2b176446df99b9eca4ea54ef")

