-- Lua provided by RyzenAPI
-- Game: Atelier Resleriana: Forgotten Alchemy and the Polar Night Liberator

-- MAIN APPLICATION
addappid(2594920)
-- Game: addappid(2594920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594921, 1, "cc74cf5fd6f04a4b93dcda5d2a932e7acba5f090808eb95b5b7cc1498454b20f")
