-- Lua provided by RyzenAPI
-- Game: Atelier Resleriana: Forgotten Alchemy and the Polar Night Liberator

-- MAIN APPLICATION
addappid(2594920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2594921, 1, "cc74cf5fd6f04a4b93dcda5d2a932e7acba5f090808eb95b5b7cc1498454b20f")

