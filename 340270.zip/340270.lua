-- Lua provided by RyzenAPI
-- Game: TIMEframe

-- MAIN APPLICATION
addappid(340270)
addappid(377170)

-- MAIN APP DEPOTS / PACKAGES
addappid(340271, 1, "ad7daa2075c8e5c2dc8dbe4db54ce709627df1a89af6ee651865aa5c54de894d")
addappid(340273, 1, "bd9e2ef3b251a88e568bfd68a89c619ced3c08321feb4889b3f4984e5c867024")
