-- Lua provided by RyzenAPI
-- Game: Bone: The Great Cow Race

-- MAIN APPLICATION
addappid(8320)
-- Game: addappid(8320)

-- MAIN APP DEPOTS / PACKAGES
addappid(8321, 1, "5c313bb4d97977d29bfa28c164673baa5e6631025b2f04e9a324fdc622c26d2f")
