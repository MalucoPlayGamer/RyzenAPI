-- Lua provided by SkyAPI 
-- Game: Dream Big 2
addappid(1551150)
addappid(1551151, 1, "b1cf315d4b0e392ba7c5facecf660372608facb324623c56679e4e5f60ecf8fd")
