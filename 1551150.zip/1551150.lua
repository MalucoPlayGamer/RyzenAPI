-- Lua provided by RyzenAPI
-- Game: Dream Big 2

-- MAIN APPLICATION
addappid(1551150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1551151, 1, "b1cf315d4b0e392ba7c5facecf660372608facb324623c56679e4e5f60ecf8fd")

