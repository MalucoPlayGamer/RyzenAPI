-- Lua provided by RyzenAPI
-- Game: Game: Dawn of Man

-- MAIN APPLICATION
addappid(858810)
-- Game: addappid(858810)

-- MAIN APP DEPOTS / PACKAGES
addappid(858811, 1, "4d48f5ab34027a5f10f343fe3bc5534b0d98e11096526cdfd5ba1343f242ec56")
addappid(858812, 1, "0236c27bb148aea7260528d2e2eb2dfd1b0a5e80db2956b7495e802be6806ec5")
