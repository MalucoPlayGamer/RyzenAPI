-- Lua provided by RyzenAPI
-- Game: DARK SOULS™ III

-- MAIN APPLICATION
addappid(374320)
addappid(442010)

-- MAIN APP DEPOTS / PACKAGES
addappid(374321, 1, "1e1f904451f44a8549008ac8152430dc18288dd22c8edda058afa86b926a4162")
addappid(374322, 1, "2e8b33176e957bf7c6ed4ad3c34847d1eef1ee846e900e1b4a2b4fc3a51b6c09")
addappid(455380, 0, "ee1942ee70f7707eb40415a87cd933fedf4de04aeab6f69421e106ff4b8d3228")
addappid(506970, 0, "2dc303f9e1fc1f45f385b5d262b3b481ed10f11d38e5ca44edf7096a4f280385")
addappid(506971, 0, "0ce07245c46df4c8b1c5d7bef627f59f34b9fde6ea903ec21ea879cf6d9c10d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(435470)
