-- Lua provided by RyzenAPI
-- Game: 1597580

-- MAIN APPLICATION
addappid(1597580)
-- Game: addappid(1597580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597581, 1, "7f248ebb0c181144622f672b8dca5a8dc07b6b0a68c11d23733f6c96aedebfe8")
