-- Lua provided by RyzenAPI
-- Game: 立方杀阵（Cubic Kill Array）

-- MAIN APPLICATION
addappid(898090)
-- Game: addappid(898090)

-- MAIN APP DEPOTS / PACKAGES
addappid(898091, 1, "64ff18ee847f4626f4b374b46fb1239b72f6a26f8234a7216c389376118f57bf")
