-- Lua provided by RyzenAPI
-- Game: AppID 777640

-- MAIN APPLICATION
addappid(777640)

-- MAIN APP DEPOTS / PACKAGES
addappid(777641, 1, "531ebf510e48c792346e4dbed891bf3b1fa23421a58b133474ebebc67f6b852a")
addappid(777642, 1, "7d36dc8a61456fdabc404881e13dea755577e14fbd8ff5caacc5cbb415ccc536")
