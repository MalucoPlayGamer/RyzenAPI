-- Lua provided by SkyAPI 
-- Game: AppID 1566590
addappid(1566590)
addappid(1566591, 1, "e3382c3bcd9417e41a2dd561450c0242be421c934a29724eea1f0d91549b4986")
