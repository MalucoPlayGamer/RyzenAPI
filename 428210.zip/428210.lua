-- Lua provided by RyzenAPI
-- Game: Horror in the Asylum

-- MAIN APPLICATION
addappid(428210)

-- MAIN APP DEPOTS / PACKAGES
addappid(428211, 1, "a5efd4b7db9be5d28a4e3b1c021dd1c2d0b7a80ef2d4d25831e65e5bf8454760")
