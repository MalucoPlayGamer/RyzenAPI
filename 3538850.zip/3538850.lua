-- Lua provided by RyzenAPI 
-- Game: Entropy Architects
addappid(3538850)
addappid(3538851, 1, "5cb71da33edf6b1ff204be66e1f739b7e3b23a607f794008b9b79cc11c1b58d1")
addappid(3538852, 1, "d4b5af498481baa74fcefef7aa1010e1ed3cde6f0deb599d438b0db51a332ac2")
