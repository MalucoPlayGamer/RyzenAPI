-- Lua provided by SkyAPI 
-- Game: Lay a Beauty to Rest: The Darkness Peach Blossom Spring
addappid(1506980)
addappid(1506981, 1, "7162226371b6bf6bd61a86cb90163891af3edce582c7e651ae0680eebf2de49e")
addappid(2001090, 0, "ea90d4fc6dadd13c75c35914762b333e8c5007b26f85135f17c76417d49dc0be")
