-- Lua provided by RyzenAPI
-- Game: AppID 2578530

-- MAIN APPLICATION
addappid(2578530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578531, 1, "0ca261afa3b5a6bab9d6d908ca43c7b9bbf0eb6512bfba15c59670e493314873")

