-- Lua provided by SkyAPI 
-- Game: AppID 2693640
addappid(2693640)
addappid(2693641, 1, "6bbee59e9c188c3cef8e4f7b9cc43b331939e6b8e744c978e693268d286ca8ba")
