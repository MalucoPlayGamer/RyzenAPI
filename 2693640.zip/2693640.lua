-- Lua provided by RyzenAPI
-- Game: Game: AppID 2693640

-- MAIN APPLICATION
addappid(2693640)
-- Game: addappid(2693640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693641, 1, "6bbee59e9c188c3cef8e4f7b9cc43b331939e6b8e744c978e693268d286ca8ba")
