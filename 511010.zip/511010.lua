-- Lua provided by RyzenAPI
-- Game: 511010

-- MAIN APPLICATION
addappid(511010)
-- Game: addappid(511010)

-- MAIN APP DEPOTS / PACKAGES
addappid(511011, 1, "29b81cfcfbeb3b899076446dd2858469a120ce307003f2044c1fdd0a2e1f6d23")
