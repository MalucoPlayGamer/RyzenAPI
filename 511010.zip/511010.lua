-- Lua provided by RyzenAPI
-- Game: TAIKER

-- MAIN APPLICATION
addappid(511010)

-- MAIN APP DEPOTS / PACKAGES
addappid(511011, 1, "29b81cfcfbeb3b899076446dd2858469a120ce307003f2044c1fdd0a2e1f6d23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
