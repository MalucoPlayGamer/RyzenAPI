-- Lua provided by RyzenAPI
-- Game: addappid(492090)

-- MAIN APPLICATION
addappid(228985)
addappid(492090)

-- MAIN APP DEPOTS / PACKAGES
addappid(492092,0,"ba5617e59653e188835be2a30a746d3103f7b645340a88b1c179aad8f83d8e60")
