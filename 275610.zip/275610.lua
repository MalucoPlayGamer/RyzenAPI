-- Lua provided by RyzenAPI
-- Game: 275610

-- MAIN APPLICATION
addappid(228990)
addappid(275610)
-- Game: addappid(275610)

-- MAIN APP DEPOTS / PACKAGES
addappid(275612,0,"737f04d26d4b2aaf02e3a29cd5cb903ea9ecda45009ff2f5e7dd6c1549d21c64")
