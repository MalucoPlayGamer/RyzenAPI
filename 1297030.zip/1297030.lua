-- Lua provided by RyzenAPI
-- Game: 1297030

-- MAIN APPLICATION
addappid(1297030)
-- Game: addappid(1297030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297031, 1, "070a6d33d52cdf833887f44842e3d9efcc9167d2e2bd1c634189b37957fd9e9e")
