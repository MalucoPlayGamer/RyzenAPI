-- Lua provided by RyzenAPI
-- Game: OutlawZ : Headhunter

-- MAIN APPLICATION
addappid(2696190)
-- Game: addappid(2696190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696191, 1, "cd542bec6917b7e64e0d274290eea4d1592673ab2d79c51e3dfc327d41e2d9fa")
