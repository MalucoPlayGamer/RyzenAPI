-- Lua provided by RyzenAPI
-- Game: 2381760

-- MAIN APPLICATION
addappid(2381760)
-- Game: addappid(2381760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381761, 1, "64358f0090a4f947e89e1d58858a903bcaad0ba26d9a009ce074b3af7aa70e0a")
