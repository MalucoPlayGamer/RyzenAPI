-- Lua provided by RyzenAPI
-- Game: Milf Bar

-- MAIN APPLICATION
addappid(2026440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026441, 1, "d3618a4dfb4bea75877c66711d164684c71915fe23acdca9b5cd507674a70ff9")

