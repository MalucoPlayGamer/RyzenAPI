-- Lua provided by RyzenAPI
-- Game: 3030580

-- MAIN APPLICATION
addappid(3030580)
-- Game: addappid(3030580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030581, 1, "d56771511ab0ff8936088ad5e03db553915093d2cd98ac941b8024f8db73f7c3")
