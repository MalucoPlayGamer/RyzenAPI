-- Lua provided by SkyAPI 
-- Game: Click Click Dig: Prologue
addappid(3030580)
addappid(3030581, 1, "d56771511ab0ff8936088ad5e03db553915093d2cd98ac941b8024f8db73f7c3")
