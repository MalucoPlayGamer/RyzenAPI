-- Lua provided by RyzenAPI
-- Game: Project Silverfish

-- MAIN APPLICATION
addappid(2941710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941711, 1, "58f3fb42e32fc7f54e16d87c3952b2a1c537e0be679fd35a1d16acc5e4d870d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
