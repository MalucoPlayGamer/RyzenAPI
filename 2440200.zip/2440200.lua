-- Lua provided by RyzenAPI
-- Game: AURA: Hentai Cards

-- MAIN APPLICATION
addappid(2440200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440201, 1, "6dbc7e13591d109bd45665429c0863f0f95df37f15196a6ee1668330bb03de29")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2614170)
addappid(2614180)
addappid(2685560)
addappid(2723440)
addappid(2814050)
addappid(2960450)
addappid(3188410)
