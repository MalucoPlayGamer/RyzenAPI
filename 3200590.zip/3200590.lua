-- Lua provided by RyzenAPI
-- Game: Axxx: Taught and fucked

-- MAIN APPLICATION
addappid(3200590)
-- Game: addappid(3200590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200591, 1, "b7267ce572e83e799b25f3e8276a38896f4b1500f2cb6ef838a3c33d17f515f8")
