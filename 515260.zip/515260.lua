-- Lua provided by RyzenAPI
-- Game: Virtual Rides 3 - Funfair Simulator

-- MAIN APPLICATION
addappid(515260)
-- Game: addappid(515260)

-- MAIN APP DEPOTS / PACKAGES
addappid(515262,0,"955b377d43a8cb64ef9c10805a27cc6909827496e99694eeb6eda8afc420d1d1")
addappid(515263,0,"13767fdc2a56a576ecc69efd70855d9f6a627cd285b14605a7394c4679d26cd3")
addappid(515264,0,"c961d56346b6a5c15ead441cf390603e323099f0c72302b05a45b4215ac1424d")
