-- Lua provided by RyzenAPI
-- Game: Virtual Rides 3 - Funfair Simulator

-- MAIN APPLICATION
addappid(515260)
addappid(1020290)
addappid(1065730)
addappid(1113140)
addappid(1188040)
addappid(1270000)
addappid(1427010)
addappid(1833970)
addappid(2594530)
addappid(2790450)
addappid(3010360)
addappid(3463040)

-- MAIN APP DEPOTS / PACKAGES
addappid(515262,0,"955b377d43a8cb64ef9c10805a27cc6909827496e99694eeb6eda8afc420d1d1")
addappid(515263,0,"13767fdc2a56a576ecc69efd70855d9f6a627cd285b14605a7394c4679d26cd3")
addappid(515264,0,"c961d56346b6a5c15ead441cf390603e323099f0c72302b05a45b4215ac1424d")

