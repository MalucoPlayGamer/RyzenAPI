-- Lua provided by RyzenAPI
-- Game: Game: Hentai Girl Linda

-- MAIN APPLICATION
addappid(927890)
-- Game: addappid(927890)

-- MAIN APP DEPOTS / PACKAGES
addappid(927891, 1, "764ea0d3fc8ad62d9cc01ce956a618f07f864d79487c3f2c6740577e929cbc8b")
addappid(927892, 1, "e4c1f08a84102b5b297dfcf57f6b425204453919db7655c7b8eff5f42bc505ad")
