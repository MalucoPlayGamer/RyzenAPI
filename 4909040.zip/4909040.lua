-- 4909040's Lua and Manifest Created by Hubcap Manifest
-- Fantasy Classic: Dungeon Crawler
-- Created: August 15, 2026 at 16:42:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4909040) -- Fantasy Classic: Dungeon Crawler
-- MAIN APP DEPOTS
addappid(4909042, 1, "d365a837fd3fd7a86e035f7277ddba39d4a090eaee64d9c7e9d7b3e871d2f260") -- Depot 4909042
setManifestid(4909042, "9006346908065248694", 258220965)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4909041) -- Depot 4909041 (empty depot)