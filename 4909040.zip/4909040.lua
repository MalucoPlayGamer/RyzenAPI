-- Lua provided by RyzenAPI
-- Game: Fantasy Classic: Dungeon Crawler

-- MAIN APPLICATION
addappid(4909040) -- Fantasy Classic: Dungeon Crawler
-- addappid(4909041) -- Depot 4909041 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4909042, 1, "d365a837fd3fd7a86e035f7277ddba39d4a090eaee64d9c7e9d7b3e871d2f260") -- Depot 4909042

