-- Lua provided by RyzenAPI
-- Game: Hidden: On the trail of the Ancients

-- MAIN APPLICATION
addappid(352580)
-- Game: addappid(352580)

-- MAIN APP DEPOTS / PACKAGES
addappid(352581, 1, "9bf5b7f9005d13e6f89ab074e69e27d7fa4106dba464a4113dd18f5e90f90059")
