-- Lua provided by RyzenAPI
-- Game: Game: Movies Tycoon

-- MAIN APPLICATION
addappid(2659050)
-- Game: addappid(2659050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659051, 1, "133ee3867f80351b5847389715a9e4278ec58d3fe5d7ceb9bc9d157229b05d53")
addappid(3613010, 0, "91b8d1e0310e331b44890527309d6225da64b84364d017c750ac65dbfbf2b47a")
