-- 2659050's Lua and Manifest Created by Hubcap Manifest
-- Movies Tycoon
-- Created: August 07, 2026 at 14:17:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(2659050) -- Movies Tycoon
-- MAIN APP DEPOTS
addappid(2659051, 1, "133ee3867f80351b5847389715a9e4278ec58d3fe5d7ceb9bc9d157229b05d53") -- Depot 2659051
setManifestid(2659051, "8115372924270978602", 22002555471)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3613010) -- Movies Tycoon - Dawn of Cinema
addappid(4171240) -- Movies Tycoon - Thrills  Spectacles
addappid(4870370) -- Movies Tycoon - Streaming Wars