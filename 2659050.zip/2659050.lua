-- Lua provided by RyzenAPI
-- Game: Movies Tycoon

-- MAIN APPLICATION
addappid(2659050) -- Movies Tycoon
addappid(3613010) -- Movies Tycoon - Dawn of Cinema
addappid(4171240) -- Movies Tycoon - Thrills  Spectacles
addappid(4870370) -- Movies Tycoon - Streaming Wars

-- MAIN APP DEPOTS / PACKAGES
addappid(2659051, 1, "133ee3867f80351b5847389715a9e4278ec58d3fe5d7ceb9bc9d157229b05d53") -- Depot 2659051

