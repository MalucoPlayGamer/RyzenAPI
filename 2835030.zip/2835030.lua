-- Lua provided by RyzenAPI
-- Game: Dino Cats

-- MAIN APPLICATION
addappid(2835030)
