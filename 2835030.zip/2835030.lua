-- Lua provided by RyzenAPI
-- Game: Dino Cats

-- MAIN APPLICATION
addappid(2835030)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2853720)
addappid(2853800)
