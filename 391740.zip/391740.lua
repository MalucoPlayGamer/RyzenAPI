-- Lua provided by RyzenAPI
-- Game: Blaster Shooter GunGuy!

-- MAIN APPLICATION
addappid(391740)

-- MAIN APP DEPOTS / PACKAGES
addappid(391741, 1, "ff0ce51626a852fb894569a24082e05217964f522f023440eb7f53d03504ce94")
