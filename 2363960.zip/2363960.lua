-- Lua provided by RyzenAPI
-- Game: Bomhops

-- MAIN APPLICATION
addappid(2363960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363962,0,"9da133ef41391e670bf27d5dc79d07a5c66c0bccd074ae5e2f12ba3cd26e4224")

