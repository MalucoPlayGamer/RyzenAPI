-- Lua provided by RyzenAPI
-- Game: LONE RUIN

-- MAIN APPLICATION
addappid(1452070)
-- Game: addappid(1452070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452071, 1, "b214809429f4ca1ed0aca90ea4a06b998266b1d557277ed3b72a0e57856df7cb")
