-- Lua provided by RyzenAPI
-- Game: Retro/Grade IGF Demo

-- MAIN APPLICATION
addappid(29110)

-- MAIN APP DEPOTS / PACKAGES
addappid(29111, 1, "a58804c6b9c00a3b036bee02be461098dd0ef3fc526f851747d1047a3c0d2f7a")
