-- Lua provided by RyzenAPI
-- Game: Heliborne Collection

-- MAIN APPLICATION
addappid(433530)
addappid(722800)
addappid(726700)
addappid(729760)
addappid(730480)
addappid(730490)
addappid(730500)
addappid(730510)
addappid(730520)
addappid(730530)
addappid(749240)
addappid(749241)
addappid(749242)
addappid(863450)
addappid(971770)
addappid(1309790)

-- MAIN APP DEPOTS / PACKAGES
addappid(433531, 1, "fba36bf7d2b84f45af70fda8e88a90f203fe044643b1b508695230a22326f7e8")
addappid(433532, 1, "9c3828f3eef61bf68a9c7beef02b7ea826719f478e736642b8dcb8e8b5dea222")
addappid(433533, 1, "0b04087838b206c8c0eb7ea0c0727618004dfe3ba345165c34de984e5b033f6a")
addappid(433534, 1, "868e5c91fcfa9d353d6650d3a489286ba32fcb6f4f0e389d0c5d56412bdeb8dc")
addappid(730350, 0, "016271882659c00bae19fa416fc39363892c558b7c01643ef1c9032112f818ea")

