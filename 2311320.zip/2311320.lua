-- Lua provided by RyzenAPI
-- Game: 失与寻 ~ The Awaited ReCollection ~

-- MAIN APPLICATION
addappid(2311320)
-- Game: addappid(2311320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311321, 1, "90f08b7905f9916bf89f0a825e6bcd5c24464744da8d57db5393974537216395")
