-- Lua provided by RyzenAPI
-- Game: Esports History

-- MAIN APPLICATION
addappid(1742360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742361, 1, "29986ba78fc92bb73f5c899c4684f29e9f221bed3c75ef5154accd4f442d5afb")

