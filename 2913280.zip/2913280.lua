-- Lua provided by RyzenAPI
-- Game: AppID 2913280

-- MAIN APPLICATION
addappid(2913280)
-- Game: addappid(2913280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913281, 1, "c8ccc9c65435db87fd07e1d50e57e4beffbe68fd1fe142064717314ac3b80395")
