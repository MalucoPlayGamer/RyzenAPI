-- Lua provided by RyzenAPI
-- Game: 3303230

-- MAIN APPLICATION
addappid(3303230)
-- Game: addappid(3303230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3303231, 1, "3eda0ccd7a7260716c65fb96eb056ecf62f47aa0ac417ab78f654f08d308cb5a")
