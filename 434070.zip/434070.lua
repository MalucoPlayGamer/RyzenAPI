-- Lua provided by RyzenAPI
-- Game: Plight of the Zombie

-- MAIN APPLICATION
addappid(434070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(434071, 1, "57507cb62ebfb0291586cf45934dbf1510dcc3af7c43171e45d18880a03127ea")
addappid(434072, 1, "8463b3afe191dbd68605fd27a23942924fb414a02f03d966d6bc61b618121768")
addappid(434073, 1, "8a14c8f644734abb9cb0ec78127bf14af4448969487f7ff6f3339f097b225246")

