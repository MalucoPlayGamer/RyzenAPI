-- Lua provided by RyzenAPI 
-- Game: Event Horizon
addappid(465000)
addappid(465001, 1, "f48306240029861f8d91dd83954ebcd6dff914c944f175d8f7945bb0a28b3f7e")
addappid(465002, 1, "8c868afbbfc57b063313f6c8dd215783774234a3a6dc48213ed50474a3fae329")
addappid(465003, 1, "433b7fe1c170df843ffa130444129633da89c77f5fe6c95e805d9b7b91db5f8a")
