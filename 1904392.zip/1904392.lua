-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1904392)
addappid(2112481)
addappid(2112483)
addappid(2112484)
addappid(2112485)
addappid(2112488)
addappid(2112489)
addappid(2112491)
addappid(2112492)
addappid(2112493)
addappid(2112494)
addappid(2112495)
-- Game: addappid(1904392)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904392,0,"35720e27381fb46832b003eb33785dc8e27b6f5076ae22b5901fb0ddd628518d")
addappid(2112480,0,"b861c595b9ad8bfb551c777b9cbe224f8601ea03ea9d566b01047585a43366cc")
addappid(2112482,0,"564487fe7faa30ef2f01382c9966e91a979ed837039a1b36cd685866c6ce2016")
addappid(2112486,0,"129fef3ff7d919d113058cc79e5f70ff4b0cb884ce28bf83c7f6cd6ffa577ca2")
addappid(2112487,0,"171d729c39e69b34df5b42649dd2ac25cd6e756428867f2eed64319c43a412a1")
addappid(2112490,0,"c087a295833d94a764e8a79a9760d68ed3229b7191ed4cac36de1f89fad9127d")
addappid(2112496,0,"59d35928f45faa995c6ca2c904e63a70c8aa731a5e69f305ad70c33a17fdd2fa")
addappid(2112497,0,"6172bd16c311880c44c892ba4d0860129e3ea2f3489f0eca04ebab4a9ff0b3f6")
