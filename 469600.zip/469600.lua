-- Lua provided by RyzenAPI
-- Game: Legion TD 2 - Multiplayer Tower Defense

-- MAIN APPLICATION
addappid(228985)
addappid(228988)
addappid(228990)
addappid(229001)
addappid(469600)

-- MAIN APP DEPOTS / PACKAGES
addappid(469606,0,"8b591e56a834f70ff1bf49b14b99e2c490adca60ee83a708449f01edab91a597")
addappid(469607,0,"ef467d7153533cc467dc641f921c9274318d344d3e47b1e58160a96a2ce46b6d")
addappid(469608,0,"392006f5e4e2964f66056341e4f8cc8a45b3d9c85ee44f5ea0629153f2c6768e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(562150)
addappid(2162190)
