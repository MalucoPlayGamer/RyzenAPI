-- Lua provided by RyzenAPI
-- Game: Microcosmum: survival of cells - Soundtrack

-- MAIN APPLICATION
addappid(524990)
-- Game: addappid(524990)

-- MAIN APP DEPOTS / PACKAGES
addappid(524990,0,"45968dce218afc9b2503ee8b93d0113a5fdba886128330973c0f86d556ab4b31")
