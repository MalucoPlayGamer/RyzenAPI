-- Lua provided by RyzenAPI
-- Game: World War Legion

-- MAIN APPLICATION
addappid(3577060)
