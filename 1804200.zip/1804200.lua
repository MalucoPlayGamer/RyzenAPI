-- Lua provided by RyzenAPI
-- Game: Dragon Slaying

-- MAIN APPLICATION
addappid(1804200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804201, 1, "2131c2f67cf0a19ada6141a2b2ca5513f00d51c695fedbf1c592f36834ad6c13")
