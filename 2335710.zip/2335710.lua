-- Lua provided by RyzenAPI
-- Game: Px2d - Three Kingdoms Theme Role Expansion Package 001

-- MAIN APPLICATION
addappid(2335710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335710,0,"99f88665277af5b0cf8843317935454f72e76425d15162a7384f1b34b756cc39")
