-- Lua provided by RyzenAPI
-- Game: Plasmatic

-- MAIN APPLICATION
addappid(2449490)
-- Game: addappid(2449490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449491, 1, "7d454454ce0d0b1ea7538a43f8cebbe2988dea4defe275fe2fe63ec7e152657e")
