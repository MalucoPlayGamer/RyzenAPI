-- Lua provided by RyzenAPI
-- Game: Vampire's Fall 2

-- MAIN APPLICATION
addappid(4264230)

