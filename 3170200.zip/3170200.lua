-- Lua provided by RyzenAPI
-- Game: Lyndaria: Lust Adventure - Digital Artbook

-- MAIN APPLICATION
addappid(3170200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170200,0,"61913975dce4c23923cb9319f8dbfaca4078207f9018369fba85b7dbe47cf5aa")

