-- Lua provided by RyzenAPI
-- Game: Flashback 2

-- MAIN APPLICATION
addappid(2008420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008421, 1, "6e322d32d20507ab3b3abdb33be081c7ac769882eb427532375f13389c4abf9d")
