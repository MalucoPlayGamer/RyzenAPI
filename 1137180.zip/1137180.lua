-- Lua provided by RyzenAPI
-- Game: AppID 1137180

-- MAIN APPLICATION
addappid(1137180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137181, 1, "1df89a60c62031ff0d316b04a53c5b624e0080ade41525d2fe391968eac9cbf5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
