-- Lua provided by RyzenAPI
-- Game: Game: GiLGuL

-- MAIN APPLICATION
addappid(3351660)
-- Game: addappid(3351660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351661, 1, "892718c4641967506040a7d03c40cfb90adfaf285a2c597c69288d0d83ae7ced")
