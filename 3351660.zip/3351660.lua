-- Lua provided by SkyAPI 
-- Game: GiLGuL
addappid(3351660)
addappid(3351661, 1, "892718c4641967506040a7d03c40cfb90adfaf285a2c597c69288d0d83ae7ced")
