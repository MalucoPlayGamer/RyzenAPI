-- Lua provided by RyzenAPI
-- Game: Game: AppID 1162590

-- MAIN APPLICATION
addappid(1162590)
-- Game: addappid(1162590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162591, 1, "d7282ec694978ee2b7c6edd1bfb661599bb25462fc17b29993ef34c8e2e257bc")
