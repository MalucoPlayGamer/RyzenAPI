-- Lua provided by RyzenAPI
-- Game: Arcade Boss Simulator

-- MAIN APPLICATION
addappid(3725770)
-- Game: addappid(3725770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3725771, 1, "2c04762f8b76440b182e09e6d0c18231975bfc4c23b97820b60c5287e91b701f")
addappid(3725772, 1, "7dabc0eb1685784c82f6ad84f1327929e7e7a12a15918ba6a864908374298beb")
