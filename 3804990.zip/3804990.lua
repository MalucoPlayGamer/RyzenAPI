-- Lua provided by RyzenAPI 
-- Game: Slimy Harvest
addappid(3804990)
addappid(3804991, 1, "513440e6277a5d66bfe9fe27317e240874738d57cfbd95f6cfef0b44bcb1852f")
