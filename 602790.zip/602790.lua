-- Lua provided by RyzenAPI
-- Game: 602790

-- MAIN APPLICATION
addappid(602790)
-- Game: addappid(602790)

-- MAIN APP DEPOTS / PACKAGES
addappid(602791, 1, "1e50ffb75798d4f2e462033dacf551e5ced2b6d23d3716b18d5e864eb4f082ea")
