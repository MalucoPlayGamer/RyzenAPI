-- Lua provided by RyzenAPI
-- Game: Biztopia

-- MAIN APPLICATION
addappid(3310510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310511, 1, "d07a514eb529ce1f5d66b1ec7790545184b3c8a6f4405ac46c3d923acd7ef0f3")
