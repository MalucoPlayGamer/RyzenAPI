-- Lua provided by RyzenAPI
-- Game: Biztopia

-- MAIN APPLICATION
addappid(3310510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3310511, 1, "d07a514eb529ce1f5d66b1ec7790545184b3c8a6f4405ac46c3d923acd7ef0f3")

