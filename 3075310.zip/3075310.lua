-- Lua provided by RyzenAPI
-- Game: 3075310

-- MAIN APPLICATION
addappid(3075310)
-- Game: addappid(3075310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075311, 1, "b690e92ef04a09728fc7b09eeb7beccc48012d743568665b5396889b690d0d38")
