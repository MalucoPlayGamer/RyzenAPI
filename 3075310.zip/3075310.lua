-- Lua provided by RyzenAPI
-- Game: Pirates Outlaws 2: Heritage Playtest

-- MAIN APPLICATION
addappid(3075310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075311, 1, "b690e92ef04a09728fc7b09eeb7beccc48012d743568665b5396889b690d0d38")
