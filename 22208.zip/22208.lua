-- Lua provided by RyzenAPI
-- Game: Zeno Clash Models

-- MAIN APPLICATION
addappid(22208)

-- MAIN APP DEPOTS / PACKAGES
addappid(22208,0,"709a97b8f7ee6659e9636d9e6563d91d005a67646acb0fc18567e502e634ce6c")

