-- Lua provided by RyzenAPI
-- Game: Headliner: NoviNews

-- MAIN APPLICATION
addappid(918820)

-- MAIN APP DEPOTS / PACKAGES
addappid(918821, 1, "fef43ad025c22f4f077f6609347b0865ff8ffd50d65987490f2e3718d48aea1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
