-- Lua provided by RyzenAPI
-- Game: Headliner: NoviNews

-- MAIN APPLICATION
addappid(918820)

-- MAIN APP DEPOTS / PACKAGES
addappid(918821, 1, "fef43ad025c22f4f077f6609347b0865ff8ffd50d65987490f2e3718d48aea1c")
