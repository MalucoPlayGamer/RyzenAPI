-- Lua provided by RyzenAPI
-- Game: Game: SkyCraft Demo

-- MAIN APPLICATION
addappid(2314830)
-- Game: addappid(2314830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314831, 1, "a582446b87e23ca9648be88446c68559f0b74c33ec23a6509944ad33d9ee93ad")
