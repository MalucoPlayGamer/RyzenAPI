-- Lua provided by RyzenAPI
-- Game: Velocity Rift

-- MAIN APPLICATION
addappid(2200270)
-- Game: addappid(2200270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200271, 1, "365b79771a2599a029d527778f7375d0c7e24b47c88be3b91df0915f6778f022")
