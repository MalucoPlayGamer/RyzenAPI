-- Lua provided by RyzenAPI
-- Game: Velocity Rift

-- MAIN APPLICATION
addappid(2200270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2200271, 1, "365b79771a2599a029d527778f7375d0c7e24b47c88be3b91df0915f6778f022")

