-- Lua provided by SkyAPI 
-- Game: Velocity Rift
addappid(2200270)
addappid(2200271, 1, "365b79771a2599a029d527778f7375d0c7e24b47c88be3b91df0915f6778f022")
