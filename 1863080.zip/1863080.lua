-- Lua provided by RyzenAPI
-- Game: Beat Invaders

-- MAIN APPLICATION
addappid(1863080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863081, 1, "5fd7d90ed6370756a5de271b9573d0a59d6dfd2ecc435c4621bdd1a4d9053501")

