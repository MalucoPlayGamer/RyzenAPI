-- Lua provided by SkyAPI 
-- Game: Garten of Banban 2
addappid(2262770)
addappid(2262771, 1, "b20a1f79e7725d56ecc5699fc4586354de3c46370649ae4248adff7910dd6979")
