-- Lua provided by RyzenAPI
-- Game: Garten of Banban 2

-- MAIN APPLICATION
addappid(2262770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262771, 1, "b20a1f79e7725d56ecc5699fc4586354de3c46370649ae4248adff7910dd6979")
