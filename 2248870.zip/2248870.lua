-- Lua provided by RyzenAPI
-- Game: Little white man

-- MAIN APPLICATION
addappid(2248870)
-- Game: addappid(2248870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248872,0,"797b64e277698dd0a4da40b541b0fc00506211159d41fe1c2b78756da3a9d742")
