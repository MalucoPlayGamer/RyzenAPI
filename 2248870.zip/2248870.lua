-- Lua provided by RyzenAPI
-- Game: Little white man

-- MAIN APPLICATION
addappid(2248870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248872,0,"797b64e277698dd0a4da40b541b0fc00506211159d41fe1c2b78756da3a9d742")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
