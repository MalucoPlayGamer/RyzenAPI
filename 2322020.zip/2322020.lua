-- Lua provided by RyzenAPI
-- Game: Game: SeaFeud

-- MAIN APPLICATION
addappid(2322020)
-- Game: addappid(2322020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322021, 1, "f1cf0a633ab7444b12cecc23749cb32dc1313068f97bddf5f800357544477c5a")
