-- Lua provided by RyzenAPI
-- Game: SeaFeud

-- MAIN APPLICATION
addappid(2322020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2322021, 1, "f1cf0a633ab7444b12cecc23749cb32dc1313068f97bddf5f800357544477c5a")

