-- Lua provided by RyzenAPI 
-- Game: SeaFeud
addappid(2322020)
addappid(2322021, 1, "f1cf0a633ab7444b12cecc23749cb32dc1313068f97bddf5f800357544477c5a")
