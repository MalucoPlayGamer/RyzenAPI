-- Lua provided by RyzenAPI
-- Game: Lonely Turret 2

-- MAIN APPLICATION
addappid(2529460)
-- Game: addappid(2529460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529461, 1, "3c0a9dcd2389cd5d264c112699fb153453c97a8779d9ae40825c691425bdd866")
