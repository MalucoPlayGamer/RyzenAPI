-- Lua provided by RyzenAPI
-- Game: Shuffs

-- MAIN APPLICATION
addappid(1345240)
-- Game: addappid(1345240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345241, 1, "f4f4eec963b3242907b93a7e1ac351a9c36c6cb401bb064b76fbb960b233813a")
