-- Generated with Luie @ https://lua.tools/
-- 2324150 - Neuroshima Hex
-- Generated 2026-08-08 18:59:08 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2324150)

-- Main Depots
addappid(2324151, 1, "3cf60845882cfe04c21b3cb40e17d2351f1cca6a6eff0127531fc9db73c69d30")
setManifestid(2324151, "2051549131054988308", 1272100612)

-- DLC's (no depot keys required)
addappid(3587690) -- Neuroshima Hex Army - Neojungle
addappid(3587700) -- Neuroshima Hex Army - Uranopolis
addappid(3587710) -- Neuroshima Hex Army - Sharrash
