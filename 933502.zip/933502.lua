-- Lua provided by RyzenAPI
-- Game: 933502

-- MAIN APPLICATION
addappid(933502)
-- Game: addappid(933502)

-- MAIN APP DEPOTS / PACKAGES
addappid(933502,0,"dc40f4f6ad1edad6b1090d234157c8054fba631fa8aef34dbc5b7e721b8fd5fb")
addtoken(933502,14300075965904469837)
