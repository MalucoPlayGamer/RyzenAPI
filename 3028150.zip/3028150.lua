-- Lua provided by RyzenAPI
-- Game: Nao in Heat! ~Kemomimi Girl's Naughty Treatment~

-- MAIN APPLICATION
addappid(3028150)
-- Game: addappid(3028150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028151, 1, "986aa9569123b83aa25c3d41172b7771df2599a0bf26499f6fee6991b377f905")
addappid(3028152, 1, "93bf341e7ebd99310f0abcaf0c9c1a3209896157ff8e5e4bf61fbf7fa0eb9699")
addappid(3028153, 1, "7d064254509157e124dbde7d15ddcb804b9a88a375ae321dc91b2023b984e21a")
addappid(3028154, 1, "90dbc110accf01ecc563b969afb2fc701b8d2eaff9caec8b2a09fad8f110cdfa")
