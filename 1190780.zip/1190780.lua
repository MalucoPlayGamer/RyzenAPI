-- Lua provided by RyzenAPI
-- Game: DooM in the Dark 2

-- MAIN APPLICATION
addappid(1190780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190781, 1, "fd3f2ccda0c5eea9c0296fdd4dcbebecc3fc07de6444bd2f3cd278b0d97d0932")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
