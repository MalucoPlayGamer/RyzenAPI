-- Lua provided by RyzenAPI
-- Game: Noblesse Oblige

-- MAIN APPLICATION
addappid(2094620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094621, 1, "df39eb7b48229202fa8d59713a000855e4229e342aa5387dc36125af59ca99e2")

