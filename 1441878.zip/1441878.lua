-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2021 Effects - Technology Set

-- MAIN APPLICATION
addappid(1441878)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441878,0,"c2fef698570abebf1fc8a90249f21bdb9bd3fd3dd47778184fd07348a334c9b9")

