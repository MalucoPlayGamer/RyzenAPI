-- Lua provided by RyzenAPI
-- Game: Best Friends

-- MAIN APPLICATION
addappid(3544480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3544481, 1, "cb9c7a5064f7ea5acd62329ce1eb1cde96764cf306bb3be191ecd1bcc6447081")
