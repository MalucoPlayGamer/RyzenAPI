-- Lua provided by RyzenAPI
-- Game: ViSP - Virtual Space Port

-- MAIN APPLICATION
addappid(800290)

-- MAIN APP DEPOTS / PACKAGES
addappid(800299,0,"d9eea34117e88a385b8004ed13a06c9d7a8dd9a2275d44c02a00ec4d14004ad9")

