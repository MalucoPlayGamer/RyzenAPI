-- Lua provided by RyzenAPI
-- Game: The Girl in the Window

-- MAIN APP DEPOTS / PACKAGES
addappid(4700560, 1, "fb573f13ff1348e5c436e51ee5a8a23d4be0eb8ffe7867f274b4ef0b73a0adb6") -- The Girl in the Window
addappid(4700561, 1, "1775b3053811d7c6cfd99a9800b4b2d8247355b0cff91b992637ea8e6293f8ad") -- Depot 4700561
