-- Lua provided by RyzenAPI
-- Game: 1728210

-- MAIN APPLICATION
addappid(1728210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728212,0,"7f26eb5cbe2a877c73b5ed3ef6345cbcc50df4f1031dbb915c1bf7658118ebe5")
