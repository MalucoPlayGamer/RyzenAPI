-- Lua provided by RyzenAPI
-- Game: addappid(2230080)

-- MAIN APPLICATION
addappid(2230080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230081, 1, "ffa9a93f4f294990192c0084c192954430a485dd415d23fdba6bcd3de4f53cb2")
