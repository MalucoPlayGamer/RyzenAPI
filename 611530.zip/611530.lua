-- Lua provided by RyzenAPI
-- Game: AppID 611530

-- MAIN APPLICATION
addappid(611530)
-- Game: addappid(611530)

-- MAIN APP DEPOTS / PACKAGES
addappid(611531, 1, "47ac5d170d8e74afa572f90792ff733dd78aa2847e934cbfafe825d213c25e70")
