-- Lua provided by RyzenAPI
-- Game: Fantasy Sliding Puzzle

-- MAIN APPLICATION
addappid(1738630)
-- Game: addappid(1738630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738631, 1, "85933535549a74347fbfeebc4e88c4776d5c2ad40f65a6065c2c13338022a128")
addappid(1738633, 1, "ab6b6bc148febf49da72a0060e69932637ae363af96e47a5cc8446561414ac4d")
addappid(1746690, 0, "fce4038d901695757ea756cb548bcab8376c6c60112a8b1f2434207a41d8edef")
