-- Lua provided by RyzenAPI 
-- Game: AppID 1390830
addappid(1390830)
addappid(1390831, 1, "904820a7a4c2988dc836fcb74c36ceac90528d42286ac4eb0f741c7f76bf5006")
