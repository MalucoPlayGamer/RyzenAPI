-- Lua provided by RyzenAPI
-- Game: Super Dungeon Bros

-- MAIN APPLICATION
addappid(306000)

-- MAIN APP DEPOTS / PACKAGES
addappid(306001, 1, "5b9769f67ef9b747ce6cff13ba1926b0edeb8f0e58398fd9e37c6804bcbfea70")
