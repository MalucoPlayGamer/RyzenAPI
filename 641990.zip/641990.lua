-- Lua provided by RyzenAPI
-- Game: The Escapists 2

-- MAIN APPLICATION
addappid(641990)
addappid(666350)
addappid(701180)
addappid(716580)
addappid(784930)
addappid(821170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(641990,0,"3cad74989afb503f1fb211678e7e72510b12bf1cd75f2d69e75f30476a6d74e5")
addappid(641992,0,"8c3af5e78c682bcf051a7eb58d709dff6af4aad4a97be9f80484a81ecd10d577")
addappid(641993,0,"29057c4876f7ba3fcef935f9d0d5697f98c12481e81325e6e67c47b5dc77228a")
addappid(641994,0,"1af8fc14e0c6fcbc4e13186ff8c04538029382e544aae3b31ed1145993143311")

