-- Lua provided by RyzenAPI
-- Game: addappid(570050)

-- MAIN APPLICATION
addappid(570050)

-- MAIN APP DEPOTS / PACKAGES
addappid(570051, 1, "c14ca313a237ac1201ad35b3c02a04f75412ef18e86311188e0372dfd50d10fa")
