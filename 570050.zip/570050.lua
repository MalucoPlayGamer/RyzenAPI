-- Lua provided by RyzenAPI
-- Game: Raiden V: Director's Cut | 雷電 V Director's Cut | 雷電V:導演剪輯版

-- MAIN APPLICATION
addappid(570050)

-- MAIN APP DEPOTS / PACKAGES
addappid(570051, 1, "c14ca313a237ac1201ad35b3c02a04f75412ef18e86311188e0372dfd50d10fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
