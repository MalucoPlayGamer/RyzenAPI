-- Lua provided by RyzenAPI
-- Game: GNOSIA

-- MAIN APPLICATION
addappid(1608290)
-- Game: addappid(1608290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608291, 1, "e46bfbf4201bb8d293e80d779cce6a9dfefbdb8feadaf40f8d283ac16990726e")
