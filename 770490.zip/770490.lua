-- Lua provided by RyzenAPI
-- Game: Death in the Water

-- MAIN APPLICATION
addappid(770490)

-- MAIN APP DEPOTS / PACKAGES
addappid(770492,0,"92e7ad33afc811c09467e8fc435a24cddf03b1b603799e52d564327a7644beb9")
addappid(770493,0,"39dd5c99824c22276399fe807709aaab25507aa8b2a003a6e4853aa46165c9b7")

