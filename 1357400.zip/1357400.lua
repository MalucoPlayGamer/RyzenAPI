-- Lua provided by RyzenAPI
-- Game: addappid(1357400)

-- MAIN APPLICATION
addappid(1357400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357401, 1, "7a3e68cc8b01badc2717b771a62088d409250ef2099dec16ea13265da27a0eb3")
