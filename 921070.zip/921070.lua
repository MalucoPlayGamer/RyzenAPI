-- Lua provided by RyzenAPI
-- Game: Spellwake

-- MAIN APPLICATION
addappid(921070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(921071, 1, "d5238787d8d6123964530a05085f6508b03d95d5215efe38b1c8e963fda061c0")

