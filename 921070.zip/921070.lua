-- Lua provided by RyzenAPI
-- Game: Spellwake

-- MAIN APPLICATION
addappid(921070)

-- MAIN APP DEPOTS / PACKAGES
addappid(921071, 1, "d5238787d8d6123964530a05085f6508b03d95d5215efe38b1c8e963fda061c0")

