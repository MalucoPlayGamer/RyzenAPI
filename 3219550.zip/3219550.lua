-- Lua provided by RyzenAPI
-- Game: Garbage Packer

-- MAIN APPLICATION
addappid(3219550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219551, 1, "0804615a34d81a941c1e1f74175fcc4fc05f8f80292ee831eec450927a998c8e")
