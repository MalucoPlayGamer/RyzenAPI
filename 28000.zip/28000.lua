-- Lua provided by RyzenAPI
-- Game: AppID 28000

-- MAIN APPLICATION
addappid(28000)

-- MAIN APP DEPOTS / PACKAGES
addappid(28001, 1, "fe83aa0db0de00182c1969553909d9937c9dce3c1b620854de3ee7f2488b8d9a")
addappid(28002, 1, "583699c3b52b8f05a2582b955f0cc8310821e2c5d8dd664ea845eabb87b06572")
addappid(28003, 1, "29a48864750cd1b1c82f2b32bb6cf9042ddde100cf48924f93beaae7fde0775a")
addappid(28004, 1, "f3114bbf496946e16f115b087fb8a09ad6079622b3a5a2f9a9c8f85c300d0967")
addappid(28005, 1, "1853f49043bb5a5f562b532e92f954d7932776207f4fa929b9f6b77cf949d908")
addappid(28006, 1, "77863523ddb8c2358d84f12cbae74e0d89f8c6297a5a34b30064daf88672649d")
addappid(28007, 1, "cd552acb020d67e1a393e4f88b762063c1fce2b626a4ff68332d515bbc630453")
addappid(28008, 1, "eb0cb3750bbc489447d9442deb00758015eea3bdb982e2d4d2d6d9588823067a")
addappid(28009, 1, "190e8059f49ae03fb83cb7d017b0023eb842219af114c5f2f0fecb99485ad80e")
addappid(28010, 1, "5e38504b2e92b1b250f3aefbb7409da7a0a0b9ab93e2f9cd4e38cc68199f6893")
addappid(28016, 1, "0dbdfc0f0d1a58bd22b1a2efc2d71a5fe8c0c3930e6b022f56a933d710057958")
addappid(28017, 1, "90a27a43c41a7d1dfea0b72a1ab92f556a208681ccd9b79e45f616ad209374e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(28011)
addappid(28012)
addappid(28013)
addappid(28014)
addappid(28015)
