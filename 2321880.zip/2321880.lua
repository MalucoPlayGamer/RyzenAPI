-- 2321880's Lua and Manifest Created by Hubcap Manifest
-- Spire Horizon
-- Created: September 30, 2025 at 19:06:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 17
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2321880) -- Spire Horizon
-- MAIN APP DEPOTS
addappid(2321881, 1, "9565d2f34c315b3c5ac147c028613d03bffb5fb1b39ab45c31f557a4385ed9ff") -- Depot 2321881
setManifestid(2321881, "8273870954262474661", 9017406276)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2515080) -- Spire Horizon - Companion Expansion
addappid(2568070) -- Spire Horizon - Little Dragon Aquanox Expansion
addappid(2568080) -- Spire Horizon - Little Dragon Volcano Expansion
addappid(2568090) -- Spire Horizon - Little Dragon Rosso Expansion
addappid(2568100) -- Spire Horizon - Little Dragon Navy Expansion
addappid(2568110) -- Spire Horizon - Little Dragon Verdant Expansion
addappid(2568120) -- Spire Horizon - Little Dragon Mossy Expansion
addappid(2568130) -- Spire Horizon - Little Dragon Midnight Expansion
addappid(2568140) -- Spire Horizon - Little Dragon Terracotta Expansion
addappid(2568150) -- Spire Horizon - Little Dragon Ivy Expansion
addappid(2568160) -- Spire Horizon - Little Dragon Copper Expansion
addappid(2568170) -- Spire Horizon - Little Dragon Cinnamon Expansion
addappid(2568180) -- Spire Horizon - Little Dragon Deepsea Expansion
addappid(2568190) -- Spire Horizon - Little Dragon Basilisk Expansion
addappid(2568200) -- Spire Horizon - Little Dragon Peony Expansion
addappid(2568210) -- Spire Horizon - Little Dragon Luminous Expansion
addappid(2568220) -- Spire Horizon - Little Dragon Buttercup Expansion