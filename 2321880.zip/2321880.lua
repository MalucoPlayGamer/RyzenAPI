-- Lua provided by RyzenAPI
-- Game: addappid(2321880)

-- MAIN APPLICATION
addappid(2321880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321881, 1, "9565d2f34c315b3c5ac147c028613d03bffb5fb1b39ab45c31f557a4385ed9ff")
