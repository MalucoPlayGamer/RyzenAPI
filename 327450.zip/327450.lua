-- Lua provided by RyzenAPI
-- Game: 327450

-- MAIN APPLICATION
addappid(327450)
-- Game: addappid(327450)

-- MAIN APP DEPOTS / PACKAGES
addappid(327451, 1, "a1eefe5597b56fba17b636d60ac2022ba24d63845859cb39f48c4056a817af13")
