-- Lua provided by RyzenAPI
-- Game: 1296680

-- MAIN APPLICATION
addappid(1296680)
-- Game: addappid(1296680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296681, 1, "6ea771265e8db399c672f565d979ef3a39eaeff23facf63d4dec261c14f5952a")
