-- Lua provided by RyzenAPI
-- Game: Bionite: Origins

-- MAIN APPLICATION
addappid(414770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(414775,0,"5f08116b0b3eb115249d4d01b2526457d4c89ad66a712375c4bcf2d0a550c14c")

