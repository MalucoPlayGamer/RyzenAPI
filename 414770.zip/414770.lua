-- Lua provided by RyzenAPI
-- Game: setManifestid(414775,"2892494893336059152")

-- MAIN APPLICATION
addappid(414770)
-- Game: addappid(414770)

-- MAIN APP DEPOTS / PACKAGES
addappid(414775,0,"5f08116b0b3eb115249d4d01b2526457d4c89ad66a712375c4bcf2d0a550c14c")
