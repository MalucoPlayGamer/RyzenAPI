-- Lua provided by RyzenAPI 
-- Game: AppID 646820
addappid(646820)
addappid(646821, 1, "26b9959e3c4b64a24d84e9f94cba2eb32900efb2e6c724fe9b418151f0f0bb54")
