-- Lua provided by RyzenAPI
-- Game: 2569210

-- MAIN APPLICATION
addappid(2569210)
-- Game: addappid(2569210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569211, 1, "5051b68d4558f9e62970b5e569da4865d28f6516bf054c20ef884bd7ad2b8de1")
