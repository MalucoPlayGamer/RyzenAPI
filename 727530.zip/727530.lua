-- Lua provided by RyzenAPI
-- Game: Expelled

-- MAIN APPLICATION
addappid(727530)

-- MAIN APP DEPOTS / PACKAGES
addappid(727531, 1, "982dc2b57f2719c8196645bd0ba93bb4baf15c7f9a30c205814363fc89d24638")

