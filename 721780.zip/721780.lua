-- Lua provided by RyzenAPI
-- Game: Roguevive

-- MAIN APPLICATION
addappid(721780)

-- MAIN APP DEPOTS / PACKAGES
addappid(721781,0,"d7b04ecc4036f0658452fdef6845fbe47658883815ae846a2b6e9fb2178c0b61")

