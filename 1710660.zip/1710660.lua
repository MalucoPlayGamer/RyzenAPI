-- Lua provided by RyzenAPI
-- Game: Mind-Blowing Girls 3 Arts

-- MAIN APPLICATION
addappid(1710660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710660,0,"d8ffb56bde55229fd33a705956458c96e34d0c37115b5ee43652f331a935e737")

