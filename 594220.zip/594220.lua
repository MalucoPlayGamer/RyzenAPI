-- Lua provided by RyzenAPI
-- Game: Game: The Living Remain

-- MAIN APPLICATION
addappid(594220)
-- Game: addappid(594220)

-- MAIN APP DEPOTS / PACKAGES
addappid(594221, 1, "e12024e39b25cbe4f3e5527a7b3420f1f793e10cf567702bc9ebea4afff06fd6")
