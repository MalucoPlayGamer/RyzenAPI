-- Lua provided by RyzenAPI
-- Game: Banners of Ruin

-- MAIN APPLICATION
addappid(1075740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1075741, 1, "9bc9bfdf1f759e30836770ebac7f161939e8645ad95c657701c7f5e32709e2b0")
addappid(1359660, 0, "f8d817e1173dedce9eeab445da2d08411104caa18aff86c1d5a490a36f17a991")
addappid(1937690, 0, "b07c471e677227c5f7260970b41c76be61f1bf1c8064583f66085a4291d2889b")
addappid(2191860, 0, "378ac5144f87cfbfc90a87ff42be384f991c31ef99e6904b5627ef53fda76c92")
addappid(2523180, 0, "c36afb2ac310b8faed4a260b0e57682bd282ac2d25f1281265b8b0f9205b3c0f")

