-- Lua provided by RyzenAPI
-- Game: Species: Unknown

-- MAIN APPLICATION
addappid(2747330)
addappid(4030870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747331,0,"eaf1bf14654ecb971af8f25146dd5706b5f21004784acf95f63867aac7a6fae9")
addappid(4030871,0,"d2b8c1be6534e67712c38f147d80cb7e7af1ae3ed98e485feef03a71afe889a4")

