-- Lua provided by RyzenAPI
-- Game: AppID 622770

-- MAIN APPLICATION
addappid(622770)

-- MAIN APP DEPOTS / PACKAGES
addappid(622771, 1, "8ec62138bae6eb834b227803d98fd192391100d5455f32bd360a90594215dfce")
addappid(622775, 1, "8177ec593f163cb6ca3a638dc690a35c9421e4e2eb49e355ce16a1ec7531403f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
