-- Lua provided by RyzenAPI
-- Game: Escape until Friday

-- MAIN APPLICATION
addappid(1064010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064011, 1, "d770ae11afdc92ed140fd5571c64b48370d947c771cd28b7713438745f625451")

