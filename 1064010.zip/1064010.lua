-- Lua provided by RyzenAPI 
-- Game: Escape until Friday
addappid(1064010)
addappid(1064011, 1, "d770ae11afdc92ed140fd5571c64b48370d947c771cd28b7713438745f625451")
