-- Lua provided by RyzenAPI
-- Game: Chained in the Backrooms

-- MAIN APPLICATION
addappid(3060170)
-- Game: addappid(3060170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060172,0,"f451eb645020944aa802d8e58cf2d6829ea1e3e5e0ed4b5940f2871693984da9")
