-- Lua provided by RyzenAPI
-- Game: Gensokyo Odyssey

-- MAIN APPLICATION
addappid(1865670)
-- Game: addappid(1865670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865673,0,"685c46f9b25e1b02f66bca1381a5360e351d2225fec2ac3bf2e3b3ad77965a29")
