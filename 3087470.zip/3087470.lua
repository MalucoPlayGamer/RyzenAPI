-- Lua provided by RyzenAPI
-- Game: 3087470

-- MAIN APPLICATION
addappid(3087470)
-- Game: addappid(3087470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087471, 1, "972c2beef08124f36514338a32faf32124cf478ba635c1f44ac851b334ca1156")
