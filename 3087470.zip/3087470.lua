-- Lua provided by RyzenAPI
-- Game: Game: EmyLiveShow: Demons & Mistresses Tale

-- MAIN APPLICATION
addappid(3087470)
-- Game: addappid(3087470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087471, 1, "972c2beef08124f36514338a32faf32124cf478ba635c1f44ac851b334ca1156")
