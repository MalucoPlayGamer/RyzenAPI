-- Lua provided by RyzenAPI
-- Game: Game: Home Sweet Home : Online

-- MAIN APPLICATION
addappid(2334220)
-- Game: addappid(2334220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334221, 1, "47f64dc96a325cd0e94dfb67f970ef3cf5eaeaedb7b1b9760f0bd3c29417611a")
