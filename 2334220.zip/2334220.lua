-- Lua provided by RyzenAPI
-- Game: Home Sweet Home : Online

-- MAIN APPLICATION
addappid(2334220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2334221, 1, "47f64dc96a325cd0e94dfb67f970ef3cf5eaeaedb7b1b9760f0bd3c29417611a")

