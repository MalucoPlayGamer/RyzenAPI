-- Lua provided by RyzenAPI
-- Game: HumanitZ

-- MAIN APPLICATION
addappid(1766060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1766061, 1, "33229ac4689c705f913fd8f448d3f896fe128255629ad018dca089578dbf85c3")

