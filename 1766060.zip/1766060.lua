-- Lua provided by RyzenAPI
-- Game: HumanitZ

-- MAIN APPLICATION
addappid(1766060)
-- Game: addappid(1766060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766061, 1, "33229ac4689c705f913fd8f448d3f896fe128255629ad018dca089578dbf85c3")
