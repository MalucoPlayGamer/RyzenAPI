-- Lua provided by RyzenAPI
-- Game: Metal War Online: Retribution

-- MAIN APPLICATION
addappid(412470)
-- Game: addappid(412470)

-- MAIN APP DEPOTS / PACKAGES
addappid(412471, 1, "c14c8d708c8684f67d10eeffe87f790ff6b8912eadeac1ec1e950de36a0d9922")
