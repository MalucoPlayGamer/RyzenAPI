-- Lua provided by RyzenAPI
-- Game: 2906030

-- MAIN APPLICATION
addappid(2906030)
-- Game: addappid(2906030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906031, 1, "7c7c8fe085d6c210bb417a7e159fbc49394934cf71b81eebb727933d83c79924")
