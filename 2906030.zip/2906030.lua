-- Lua provided by RyzenAPI
-- Game: Monster United

-- MAIN APPLICATION
addappid(2906030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906031, 1, "7c7c8fe085d6c210bb417a7e159fbc49394934cf71b81eebb727933d83c79924")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
