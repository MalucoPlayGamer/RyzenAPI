-- Lua provided by RyzenAPI
-- Game: Game: Mutant Alley: Do The Dinosaur

-- MAIN APPLICATION
addappid(1556770)
-- Game: addappid(1556770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556771, 1, "4189376032a067fa8bde780f2af318cf8383a54aa95e19476da97c8900a14072")
addappid(1593910, 0, "a6ace8dab31230ca1e52b73ce703f0ae3130ab8bbea36dba57c0e80b70b5be43")
