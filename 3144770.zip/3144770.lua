-- Lua provided by SkyAPI 
-- Game: AppID 3144770
addappid(3144770)
addappid(3144771, 1, "d316d6bafaf3fb2cf926d8d2cb395582f6d0808a81fd730156f61db4387ca869")
