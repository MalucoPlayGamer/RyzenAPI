-- Lua provided by RyzenAPI
-- Game: ALEON's Nightmare

-- MAIN APPLICATION
addappid(1893420)
-- Game: addappid(1893420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893421, 1, "c36980fa73fe8386c544796cb6e632d472c8494c891f97d3ee888baa0c8ff121")
