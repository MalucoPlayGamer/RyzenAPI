-- Lua provided by RyzenAPI
-- Game: addappid(2406110)

-- MAIN APPLICATION
addappid(2406110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406111, 1, "d202733054e5f8bc9c1dc81025d5bf7a401f0a3eb39f2d363a0ef0a3c466f8ba")
