-- Lua provided by RyzenAPI
-- Game: Operation Marakudja

-- MAIN APPLICATION
addappid(2844450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2844451, 1, "0b727d2023a8edda66df6cbfec4cf067425ef9889534750eda5fc626898b9f76")

