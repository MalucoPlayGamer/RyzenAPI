-- Lua provided by SkyAPI 
-- Game: Operation Marakudja
addappid(2844450)
addappid(2844451, 1, "0b727d2023a8edda66df6cbfec4cf067425ef9889534750eda5fc626898b9f76")
