-- Lua provided by RyzenAPI
-- Game: addappid(2844450)

-- MAIN APPLICATION
addappid(2844450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844451, 1, "0b727d2023a8edda66df6cbfec4cf067425ef9889534750eda5fc626898b9f76")
