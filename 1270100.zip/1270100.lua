-- Lua provided by RyzenAPI
-- Game: addappid(1270100)

-- MAIN APPLICATION
addappid(1270100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270101, 1, "a57adb5e1d4b482095177476bc8e56a864475601d6ec59fae5baf1268c662a56")
