-- Lua provided by RyzenAPI
-- Game: 2339790

-- MAIN APPLICATION
addappid(2339790)
-- Game: addappid(2339790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339791, 1, "0bd7cd9a97018b03e1527cd0265f549781dfc0d1bdc9fe729a4d980eb4a91f1c")
