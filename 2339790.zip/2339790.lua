-- Lua provided by RyzenAPI 
-- Game: Dr. Fetus' Mean Meat Machine Demo
addappid(2339790)
addappid(2339791, 1, "0bd7cd9a97018b03e1527cd0265f549781dfc0d1bdc9fe729a4d980eb4a91f1c")
