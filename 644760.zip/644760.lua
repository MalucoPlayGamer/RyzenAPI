-- Lua provided by RyzenAPI
-- Game: 644760

-- MAIN APPLICATION
addappid(644760)
-- Game: addappid(644760)

-- MAIN APP DEPOTS / PACKAGES
addappid(645960,0,"e4256d8ad56f7bfccd7bab9d94eca4d0ff3e37dddd9cf1c47f792f3049830910")
addappid(645969,0,"2aa96d836044437c519f8f2ef6039a6a10a56571274091f5b20f39d6dbd5746e")
