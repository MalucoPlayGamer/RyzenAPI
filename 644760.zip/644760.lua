-- Lua provided by RyzenAPI
-- Game: Streetball VR

-- MAIN APPLICATION
addappid(644760)

-- MAIN APP DEPOTS / PACKAGES
addappid(645960,0,"e4256d8ad56f7bfccd7bab9d94eca4d0ff3e37dddd9cf1c47f792f3049830910")
addappid(645969,0,"2aa96d836044437c519f8f2ef6039a6a10a56571274091f5b20f39d6dbd5746e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
