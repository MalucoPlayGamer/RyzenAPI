-- Lua provided by RyzenAPI
-- Game: I See Red

-- MAIN APPLICATION
addappid(1594460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594461, 1, "4f81e2b0680b6fb57c47d257fcc9eaf0e0fceac1327860efdc57486c4268a290")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
