-- Lua provided by RyzenAPI
-- Game: I See Red

-- MAIN APPLICATION
addappid(1594460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594461, 1, "4f81e2b0680b6fb57c47d257fcc9eaf0e0fceac1327860efdc57486c4268a290")

