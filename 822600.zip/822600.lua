-- Lua provided by RyzenAPI
-- Game: AppID 822600

-- MAIN APPLICATION
addappid(822600)

-- MAIN APP DEPOTS / PACKAGES
addappid(822601, 1, "5fca6f70a12b2cf2b4b73c16c598d8dce8cf78799d3cf3ed370439497203d67e")

