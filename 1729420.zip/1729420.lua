-- Lua provided by RyzenAPI
-- Game: PaintballX

-- MAIN APPLICATION
addappid(1729420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729421, 1, "400412143d47312130d04c0b9fe3b07dd62faec6c6f1c9445a592d3368acc17b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
