-- Lua provided by RyzenAPI
-- Game: PaintballX

-- MAIN APPLICATION
addappid(1729420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729421, 1, "400412143d47312130d04c0b9fe3b07dd62faec6c6f1c9445a592d3368acc17b")

