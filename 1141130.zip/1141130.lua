-- Lua provided by RyzenAPI
-- Game: Serious Scramblers

-- MAIN APPLICATION
addappid(1141130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141131, 1, "94eb08a1f44e8b4370c09dc66e24fda6b6a1c68808d560f502374c1fc4d2799b")

