-- Lua provided by RyzenAPI
-- Game: A Mystic Journey With Crystalia

-- MAIN APPLICATION
addappid(4901950) -- A Mystic Journey With Crystalia

-- MAIN APP DEPOTS / PACKAGES
addappid(4901951, 1, "34b77a0814a6f855bb1a7821032de60987a347b604839d90f0d960e781109208") -- Depot 4901951

