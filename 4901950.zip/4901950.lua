-- 4901950's Lua and Manifest Created by Hubcap Manifest
-- A Mystic Journey With Crystalia
-- Created: August 12, 2026 at 00:07:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4901950) -- A Mystic Journey With Crystalia
-- MAIN APP DEPOTS
addappid(4901951, 1, "34b77a0814a6f855bb1a7821032de60987a347b604839d90f0d960e781109208") -- Depot 4901951
setManifestid(4901951, "7549388944574858377", 231643992)