-- Lua provided by RyzenAPI
-- Game: CONTRACTED

-- MAIN APPLICATION
addappid(600330)

-- MAIN APP DEPOTS / PACKAGES
addappid(600331, 1, "84a515c35cf8b7f273c8e63a7b0a36cfeeac46acef9e0422445bb5b5f7fe95a9")
