-- Lua provided by RyzenAPI
-- Game: Mashinky

-- MAIN APPLICATION
addappid(598960)
-- Game: addappid(598960)

-- MAIN APP DEPOTS / PACKAGES
addappid(598961, 1, "9d88d079e93fef860f02f523d96753834ca8ba9f4d621b9d3f2b0eea5c1636d9")
addappid(598962, 1, "58a08fd3b80707e9aca19c25a82c68596c32077137f451f8ab0bd4dae5729bb8")
addappid(598963, 1, "1105caa0d783a873e19369cec68a8effd8b323ad04931bcbff23d71b6ce67077")
