-- Lua provided by RyzenAPI
-- Game: Mashinky

-- MAIN APPLICATION
addappid(598960)

-- MAIN APP DEPOTS / PACKAGES
addappid(598961, 1, "9d88d079e93fef860f02f523d96753834ca8ba9f4d621b9d3f2b0eea5c1636d9")
addappid(598962, 1, "58a08fd3b80707e9aca19c25a82c68596c32077137f451f8ab0bd4dae5729bb8")
addappid(598963, 1, "1105caa0d783a873e19369cec68a8effd8b323ad04931bcbff23d71b6ce67077")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
