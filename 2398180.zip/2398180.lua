-- Lua provided by RyzenAPI
-- Game: addappid(2398180)

-- MAIN APPLICATION
addappid(2398180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398181, 1, "92b4eda772807c0136e49c238fe79f9e855a2892ff228051e3b681b5e5a8a6ee")
