-- Lua provided by RyzenAPI 
-- Game: Escape Party
addappid(2700960)
addappid(2700961, 1, "39a158e1dab9c1bcc802f3d16f86845e1659c4190d0a4162a73b4379cd748fd1")
