-- Lua provided by RyzenAPI
-- Game: addappid(17530)

-- MAIN APPLICATION
addappid(17530)

-- MAIN APP DEPOTS / PACKAGES
addappid(17531, 1, "d860a6fc1be0717a4959692904e6f5743f661e972c52317cffbcf431f69d1a80")
