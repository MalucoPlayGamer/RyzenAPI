-- Lua provided by RyzenAPI 
-- Game: D.I.P.R.I.P. Warm Up
addappid(17530)
addappid(17531, 1, "d860a6fc1be0717a4959692904e6f5743f661e972c52317cffbcf431f69d1a80")
