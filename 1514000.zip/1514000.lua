-- Lua provided by SkyAPI 
-- Game: Anime Holidays
addappid(1514000)
addappid(1514001, 1, "2d778204ecf44a4ae1d5e3169b8f4e270a6fc839812ef3ab11ac56118c4ea7ad")
addappid(1514110)
