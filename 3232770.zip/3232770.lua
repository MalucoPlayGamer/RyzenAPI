-- Lua provided by RyzenAPI
-- Game: Radio Commander: Pacific Campaign Demo

-- MAIN APPLICATION
addappid(3232770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232771, 1, "4e9027984385a64825ee0df5e586c35b2c9d48c9b8cd87068a43019c94199104")
