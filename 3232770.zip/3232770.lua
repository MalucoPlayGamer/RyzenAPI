-- Lua provided by SkyAPI 
-- Game: AppID 3232770
addappid(3232770)
addappid(3232771, 1, "4e9027984385a64825ee0df5e586c35b2c9d48c9b8cd87068a43019c94199104")
