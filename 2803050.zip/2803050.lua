-- Lua provided by RyzenAPI
-- Game: Game: Hauntii - Original Soundtrack

-- MAIN APPLICATION
addappid(2803050)
-- Game: addappid(2803050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803051, 1, "c20fba9060044301b1d5597dfc778d6d08ce9928d9956bbf7f5db8718b43aab3")
addappid(2803052, 1, "699231753a4dee643b790aaca15c86d822b1d691d85e5215a948009cffe6782c")
addappid(2803053, 1, "758ab6c3058f5212b2f4b383c129a58c848b015f1be6f75eb73f908140510ab7")
