-- Lua provided by RyzenAPI
-- Game: 君临传奇之风起云涌

-- MAIN APPLICATION
addappid(4773930)
