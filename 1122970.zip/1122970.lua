-- Lua provided by RyzenAPI
-- Game: Zombie Island

-- MAIN APPLICATION
addappid(1122970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122971, 1, "28413191daade9c78de568c826e69796806b6866fc1b20e0804c74665a47aa51")

