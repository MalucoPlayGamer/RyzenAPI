-- Lua provided by RyzenAPI
-- Game: Steel Century Groove: Midnight

-- MAIN APPLICATION
addappid(2969180)

