-- Lua provided by RyzenAPI
-- Game: Sexbot Lab Demo

-- MAIN APPLICATION
addappid(3423320)
-- Game: addappid(3423320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423321, 1, "102284219e8714934890c08392bfc0c83f68021dd7cfb73100060cbed57dd2a5")
