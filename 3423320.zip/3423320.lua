-- Lua provided by SkyAPI 
-- Game: Sexbot Lab Demo
addappid(3423320)
addappid(3423321, 1, "102284219e8714934890c08392bfc0c83f68021dd7cfb73100060cbed57dd2a5")
