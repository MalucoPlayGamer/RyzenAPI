-- Lua provided by RyzenAPI
-- Game: 252850

-- MAIN APPLICATION
addappid(228985)
addappid(228990)
addappid(229003)
addappid(252850)
addappid(529200)
-- Game: addappid(252850)

-- MAIN APP DEPOTS / PACKAGES
addappid(252852,0,"d14b84eddbb08d1a2d56431f795adbe9cce0a5e283683a4f506a953acddbc4a4")
