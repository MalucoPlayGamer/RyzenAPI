-- Lua provided by RyzenAPI
-- Game: Game: Gravitia

-- MAIN APPLICATION
addappid(2735690)
-- Game: addappid(2735690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735691, 1, "87c3f24f7ef48fa7cecf7ee98e8a89a88c1aafede6490cf3a6d4d97513f73042")
