-- Lua provided by RyzenAPI
-- Game: Jumpscare Simulator: Deluxe Supporter Edition

-- MAIN APPLICATION
addappid(3614440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614441, 1, "5c6ada1124085942a79bc86fc52c9100bf6aeea007de54620da4c3187c58c8ca")

