-- Lua provided by RyzenAPI
-- Game: addappid(1187740)

-- MAIN APPLICATION
addappid(1187740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187741, 1, "6ea89b0f59849e1ea86a051be21eea9afd6e8adbe6a3ba4f38e32b6e3a45ba34")
