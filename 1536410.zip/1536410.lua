-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1536410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536412,0,"dd073d5eaf38cecc9bd16858e1781c432e6c91cf948eb3a4cee0c2491b3d077d")

