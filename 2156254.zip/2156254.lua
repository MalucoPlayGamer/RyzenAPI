-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - Atelier Series Legacy BGM Pack

-- MAIN APPLICATION
addappid(2156254)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156254,0,"825a1b44176601dc6c37f3cd83cae2ecf2f2b6b81908361f349add0298d9048f")

