-- Lua provided by RyzenAPI
-- Game: Game: Gunnihilation

-- MAIN APPLICATION
addappid(502920)
-- Game: addappid(502920)

-- MAIN APP DEPOTS / PACKAGES
addappid(502921, 1, "cf7026f53734e409521b97e687e57390900c307aa54f8d64668f13cf939047d9")
