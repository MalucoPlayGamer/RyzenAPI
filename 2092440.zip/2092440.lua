-- Lua provided by RyzenAPI
-- Game: Human or Not Demo

-- MAIN APPLICATION
addappid(2092440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092441, 1, "3dc2eabd76f59bd65e1f7c1ebb415509fbb1d138cad84a887ffd9f78647c1644")

