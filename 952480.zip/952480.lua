-- Lua provided by RyzenAPI
-- Game: MOMO.EXE 2 - Official Soundtrack DLC

-- MAIN APPLICATION
addappid(952480)

-- MAIN APP DEPOTS / PACKAGES
addappid(952480,0,"0445c31087386ded828476cba484e55713d498a7d4f3095488577d6dd678b8db")

