-- Lua provided by RyzenAPI
-- Game: Game: ShapeHero Factory

-- MAIN APPLICATION
addappid(2389040)
-- Game: addappid(2389040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389041, 1, "e02efa2085a6430f99abd6920f993e651b6e7c6d4ea524a92eba66a689f5ae59")
