-- Lua provided by RyzenAPI
-- Game: 3223330

-- MAIN APPLICATION
addappid(3223330)
-- Game: addappid(3223330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223331, 1, "8731b8cdc655bd2afb1b147ee0b9dbd7b79a338c83ad621745f7e160ac869ffb")
