-- 2375260's Lua and Manifest Created by Hubcap Manifest
-- Tattoo Tycoon
-- Created: May 06, 2026 at 14:28:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2375260) -- Tattoo Tycoon
-- MAIN APP DEPOTS
addappid(2375261, 1, "370bbceb536a246700e8325729577ce7655e800e573c8bd1a10cc035513d6bb8") -- Depot 2375261
setManifestid(2375261, "5039575246410285209", 26)
addappid(2375262, 1, "84f62e505bb37098c956ef8dcebbcdc7435227d23a154c25358ff0fac4be1af8") -- Depot 2375262
setManifestid(2375262, "3659099171441808801", 2102711974)
-- DLCS WITH DEDICATED DEPOTS
-- Tattoo Tycoon - Animal Ink Society Style Pack (AppID: 3815930)
addappid(3815930)
addappid(3815930, 1, "8785b39a179306c17210e552857c9ccbb0dce383714e8f0cba6a87f7d1587be4") -- Tattoo Tycoon - Animal Ink Society Style Pack - Depot 3815930
setManifestid(3815930, "5935665520287199924", 21)
-- Tattoo Tycoon - China Town Dragon Studio Style Pack (AppID: 3815940)
addappid(3815940)
addappid(3815940, 1, "f0a9cedb1104b1ae2deaa1b643a7e5df6e35012fe144dc233709ccdb59c69c14") -- Tattoo Tycoon - China Town Dragon Studio Style Pack - Depot 3815940
setManifestid(3815940, "5972311625974865768", 18)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3815930) -- Depot 3815930 (empty depot)
-- addappid(3815940) -- Depot 3815940 (empty depot)