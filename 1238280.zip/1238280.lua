-- Lua provided by RyzenAPI 
-- Game: 100 Doors Game - Escape from School
addappid(1238280)
addappid(1238281, 1, "c6d98b97a9ad84c5307da68629ae2c627b8a31bc7cad275c6a5d784610109753")
addappid(1238282, 1, "45ad343370c64b316fba3a5b778c2e3df516de3f08868f19d4e06c309f68b0af")
