-- Lua provided by RyzenAPI
-- Game: Game: 100 Doors Game - Escape from School

-- MAIN APPLICATION
addappid(1238280)
-- Game: addappid(1238280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238281, 1, "c6d98b97a9ad84c5307da68629ae2c627b8a31bc7cad275c6a5d784610109753")
addappid(1238282, 1, "45ad343370c64b316fba3a5b778c2e3df516de3f08868f19d4e06c309f68b0af")
