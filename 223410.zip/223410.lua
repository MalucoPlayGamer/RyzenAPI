-- Lua provided by RyzenAPI
-- Game: Perpetuum

-- MAIN APPLICATION
addappid(223410)

-- MAIN APP DEPOTS / PACKAGES
addappid(223411, 1, "c2061303d30814ed6add5e38a9645bd2e82acf0eae8c9e564b56973eb34e0e4b")
addappid(223412, 1, "a1081a69d4793e1ecd3135c8e70629c6dc37fbb6ea4e7a099c10618c19cadee3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(426280)
addappid(426281)
