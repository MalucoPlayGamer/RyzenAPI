-- Lua provided by RyzenAPI
-- Game: addappid(223410)

-- MAIN APPLICATION
addappid(223410)

-- MAIN APP DEPOTS / PACKAGES
addappid(223411, 1, "c2061303d30814ed6add5e38a9645bd2e82acf0eae8c9e564b56973eb34e0e4b")
addappid(223412, 1, "a1081a69d4793e1ecd3135c8e70629c6dc37fbb6ea4e7a099c10618c19cadee3")
