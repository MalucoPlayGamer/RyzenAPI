-- Lua provided by RyzenAPI
-- Game: Paths & Danger

-- MAIN APPLICATION
addappid(1403990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403991, 1, "909d4bdd1d85c5f10db91a7e346906d094c7512b174a74e3b936a83d26ac4306")
