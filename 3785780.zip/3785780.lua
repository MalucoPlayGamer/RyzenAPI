-- Lua provided by RyzenAPI
-- Game: 3785780

-- MAIN APPLICATION
addappid(3785780)
-- Game: addappid(3785780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3785781, 1, "6d1e13dd0e7842a056e4eb893474fd7691b9ee048b8fd502731c100a4f8d970c")
