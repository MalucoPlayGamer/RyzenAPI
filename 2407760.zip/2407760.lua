-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2407760)
-- Game: addappid(2407760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407760,0,"0302887fc3d2d99119d410c93adcb6c24715ce8a8c302885b1116c31ce8c7337")
