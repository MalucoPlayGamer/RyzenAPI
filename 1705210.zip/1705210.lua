-- Lua provided by RyzenAPI
-- Game: Game: Swimmer Admiration Demo

-- MAIN APPLICATION
addappid(1705210)
-- Game: addappid(1705210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705211, 1, "f04e93890aeb5d5723163b8002a82a327d198643485e00cef341ea07d571df74")
