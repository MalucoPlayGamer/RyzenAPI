-- Lua provided by RyzenAPI 
-- Game: Swimmer Admiration Demo
addappid(1705210)
addappid(1705211, 1, "f04e93890aeb5d5723163b8002a82a327d198643485e00cef341ea07d571df74")
