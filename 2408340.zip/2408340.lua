-- Lua provided by RyzenAPI
-- Game: Only Climber

-- MAIN APPLICATION
addappid(2408340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408341, 1, "30432638f971addf9586b96831541cddd49d510c1a051665196ef18a4c53efe6")

