-- Lua provided by RyzenAPI
-- Game: 704710

-- MAIN APPLICATION
addappid(704710)
-- Game: addappid(704710)

-- MAIN APP DEPOTS / PACKAGES
addappid(704711, 1, "355f7a6485745876ae337f59efb63a2a7c2012d8cfcbaf99fe6e93b511184b03")
addappid(704712, 1, "1d311725ca119b72edfa849cbbe123b72e39cdaef19dc8a22f15529d8ef2a556")
