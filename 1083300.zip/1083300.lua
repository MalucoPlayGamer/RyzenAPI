-- Lua provided by RyzenAPI
-- Game: Drill Deal – Oil Tycoon

-- MAIN APPLICATION
addappid(1083300)
-- Game: addappid(1083300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083301, 1, "18567129eaaf573c49bf6dbdf47317d40ceb8a558f1fdd00a392fd35f63e72f9")
