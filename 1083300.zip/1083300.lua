-- Lua provided by SkyAPI 
-- Game: Drill Deal – Oil Tycoon
addappid(1083300)
addappid(1083301, 1, "18567129eaaf573c49bf6dbdf47317d40ceb8a558f1fdd00a392fd35f63e72f9")
