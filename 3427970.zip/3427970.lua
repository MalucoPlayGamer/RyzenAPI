-- Lua provided by RyzenAPI
-- Game: A Session with Dr. Liebnitz

-- MAIN APPLICATION
addappid(3427970)
-- Game: addappid(3427970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427971, 1, "6d60bfd059cb457fbc313eca7206423bc385395e57fed6a83829b759e7739eb9")
