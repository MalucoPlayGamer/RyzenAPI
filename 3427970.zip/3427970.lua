-- Lua provided by RyzenAPI
-- Game: A Session with Dr. Liebnitz

-- MAIN APPLICATION
addappid(3427970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427971, 1, "6d60bfd059cb457fbc313eca7206423bc385395e57fed6a83829b759e7739eb9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
