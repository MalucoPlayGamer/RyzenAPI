-- Lua provided by RyzenAPI
-- Game: Mad Tracks

-- MAIN APPLICATION
addappid(1202970)
-- Game: addappid(1202970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202971, 1, "90328195a93496e6601b3be0019e74d272bcd3147007038939fc9161a237cf3d")
