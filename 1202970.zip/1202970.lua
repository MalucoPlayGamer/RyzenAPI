-- Lua provided by RyzenAPI
-- Game: Mad Tracks

-- MAIN APPLICATION
addappid(1202970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1202971, 1, "90328195a93496e6601b3be0019e74d272bcd3147007038939fc9161a237cf3d")

