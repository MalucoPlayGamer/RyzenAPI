-- Lua provided by RyzenAPI
-- Game: AppID 2642280

-- MAIN APPLICATION
addappid(2642280)
-- Game: addappid(2642280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642281, 1, "80d5fb3c6e449f75af0fc049bb9a903f0d4d7cdbd6a7e31dbfaaf6c8f68f6185")
