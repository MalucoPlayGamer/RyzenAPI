-- Lua provided by SkyAPI 
-- Game: AppID 2530970
addappid(2530970)
addappid(2530971, 1, "2c500e0cc715d125f344404d418ce12c869717072b0d232d370e37099d80f2d2")
