-- Lua provided by RyzenAPI
-- Game: AppID 2530970

-- MAIN APPLICATION
addappid(2530970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530971, 1, "2c500e0cc715d125f344404d418ce12c869717072b0d232d370e37099d80f2d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
