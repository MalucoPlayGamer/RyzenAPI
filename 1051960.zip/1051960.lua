-- Lua provided by RyzenAPI
-- Game: Game: Fly Punch Boom!

-- MAIN APPLICATION
addappid(1051960)
-- Game: addappid(1051960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051961, 1, "d707d2e353fcc826e2426226fab7e379a283f05dd2dc668e34cebc5b17764244")
