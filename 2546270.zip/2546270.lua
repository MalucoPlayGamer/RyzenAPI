-- Lua provided by RyzenAPI
-- Game: 2546270

-- MAIN APPLICATION
addappid(2546270)
-- Game: addappid(2546270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546271, 1, "a0c98b745f6c87efb9c75705d3097f070fe44f40a47350a5e2c207435d5df2a9")
