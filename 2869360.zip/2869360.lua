-- Lua provided by RyzenAPI
-- Game: DLC Scenario Pack: Hana and Itsuki's Secret Moments 2

-- MAIN APPLICATION
addappid(2869360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869361, 1, "6fc4f271f6568809160f2fa6f43ff078636d7b16e4540cb8818c25290e11fab2")

