-- Lua provided by RyzenAPI
-- Game: Mister Versatile: A Gay Superhero Visual Novel

-- MAIN APPLICATION
addappid(1260670)
addappid(1420470)
addappid(1420471)
addappid(1916600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260671, 1, "1ca9bf33ff8dca00c59b6602b1b947a51117f3267536d8d196a3ab90705be419")
addappid(1886530, 0, "b7420fd14007d53f77aa3368a3a4a8b2ec6f843c8c40be3ca9b7385ef4612197")
addappid(2278020, 0, "95a559bd32a27aaa9d4e83c54ee11bf73556854585811e24f33cfcfb5a9795f5")
addappid(2335290, 0, "354212bf9b55bd012e519b4aba3c5ca5b07a37ae4dde48978e448594c974ec60")
addappid(2628820, 0, "f8f79b999bf5b79ffcf54cc246cf5b9a20567c40836eb346e83ed19020e0ed55")
addappid(2628830, 0, "b91f22753c1649f8b1bbb9c4c8d37c52a590354cafe6375540effe79059c34ff")
