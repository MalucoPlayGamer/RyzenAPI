-- Lua provided by RyzenAPI
-- Game: AppID 2166920

-- MAIN APPLICATION
addappid(2166920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166921, 1, "3087cbbefe2957c9dede553fdf46d947fa3808a6097ef3ca9476a9f80c8d4d20")

