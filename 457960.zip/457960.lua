-- Lua provided by RyzenAPI
-- Game: Holopoint

-- MAIN APPLICATION
addappid(457960)
-- Game: addappid(457960)

-- MAIN APP DEPOTS / PACKAGES
addappid(457961, 1, "4e3e6b9972ff255a8d6fa86ee49c4977c126753cb0043a520c52b932c48d05ed")
