-- Lua provided by RyzenAPI
-- Game: Game: KeepUp Survival

-- MAIN APPLICATION
addappid(1524630)
addappid(1955090)
addappid(1988040)
addappid(2096140)
-- Game: addappid(1524630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524631, 1, "1ceb76f0abd6cb3f022e98eff9073fa4c46f33172a7f369ef21f39f593757582")
