-- Lua provided by RyzenAPI
-- Game: Our War: Firepower Suppression

-- MAIN APPLICATION
addappid(3373540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373541, 1, "1511307eefad3e3d24df11d575f47aa0abf0d3d00c4ccfa567fb32ef7f21383c")

