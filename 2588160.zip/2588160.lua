-- Lua provided by RyzenAPI
-- Game: 2588160

-- MAIN APPLICATION
addappid(2588160)
-- Game: addappid(2588160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588161, 1, "f9abab16606ed1f2b43dffed4a39048c87fe9439760249346fffcd0c8544e40b")
