-- Lua provided by RyzenAPI
-- Game: addappid(2372950)

-- MAIN APPLICATION
addappid(2372950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372951, 1, "0a3cbe45f584c4d1b5ea2903d04a27c83c9cb614cc77d85a28966352adf90379")
