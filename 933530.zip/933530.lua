-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933530)

-- MAIN APP DEPOTS / PACKAGES
addappid(933530,0,"672c8bd00026bb6c630644c0274f0264753d2114614b91479d2777801dec9f60")
