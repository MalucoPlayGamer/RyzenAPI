-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes - Nemesis

-- MAIN APPLICATION
addappid(11040)
addappid(228990)
addappid(229033)

-- MAIN APP DEPOTS / PACKAGES
addappid(11041, 1, "5f07d895a954bc13c3a3083e9871145e318cbf4e5d54ac4d834354663301d682")
addappid(11042, 1, "0c416991f2088b7dae316501047dd94dae7f51eed138f1429d31bce5e341dad7")
addappid(11043, 1, "00b3e52738ada4ae4789393be122371ffccff940170b4af159c370e337fe528c")
addappid(11044, 1, "f5eb194317ee7f992460beba8db0dcf988acd2c6341eec92775a1ae5c678086b")
addappid(11045, 1, "816dbd8838aa3dd347e645f4b40fa24143a3b6caafed311aa6f62e3a3f5b9c9b")
addappid(11046, 1, "517e185a0076ecb7aa6d425db767b2e5513df78947f529f675e19c93a7d45435")

