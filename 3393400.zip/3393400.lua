-- Lua provided by RyzenAPI
-- Game: addappid(3393400)

-- MAIN APPLICATION
addappid(3393400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393401, 1, "1cdca9d9ae49498dc1d72535f383dbee4df475d22bf841f279d3c4f0b856ae62")
