-- Lua provided by RyzenAPI
-- Game: DESPOILER

-- MAIN APPLICATION
addappid(635050)

-- MAIN APP DEPOTS / PACKAGES
addappid(635051,0,"23bcc26ab61fcbacbd475a170c1c74db94b24f1b19a0f09aa6aa83689ad4cd9f")

