-- Lua provided by RyzenAPI 
-- Game: Pennon and Battle
addappid(2915660)
addappid(2915661, 1, "f0bf2571d787ba3210d43491c0d778fff7c3e19f2bf42ccb09f7ca2fac8f338c")
addappid(3058870)
