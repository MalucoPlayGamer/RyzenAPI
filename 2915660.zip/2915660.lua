-- Lua provided by RyzenAPI
-- Game: Pennon and Battle

-- MAIN APPLICATION
addappid(2915660)
addappid(3058870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2915661, 1, "f0bf2571d787ba3210d43491c0d778fff7c3e19f2bf42ccb09f7ca2fac8f338c")

