-- Lua provided by RyzenAPI 
-- Game: Drawize - Draw and Guess
addappid(1823740)
addappid(1823741, 1, "b6cafb1de83bd9776898d461be39318ba8cfc94b8c214145881b32178efb9f4e")
