-- Lua provided by RyzenAPI
-- Game: Game: The Doll Beneath

-- MAIN APPLICATION
addappid(1916920)
-- Game: addappid(1916920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916921, 1, "21ba511a63665eec87c2943134080ad9cc41f255a243ad287f8b4f2b989c876c")
