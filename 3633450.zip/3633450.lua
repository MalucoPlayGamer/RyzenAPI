-- Lua provided by RyzenAPI
-- Game: Game: Fingerdance

-- MAIN APPLICATION
addappid(3633450)
-- Game: addappid(3633450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3633451, 1, "48978a05050e6df5716426684c440d0510750cd587427c68e62eba93d88603b6")
