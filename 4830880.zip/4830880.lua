-- 4830880's Lua and Manifest Created by Hubcap Manifest
-- Task Bar of Ragnalis
-- Created: July 31, 2026 at 01:00:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(4830880) -- Task Bar of Ragnalis
-- MAIN APP DEPOTS
addappid(4830881, 1, "b92f1882b45efc103cda0a8f45e44810284be93ee5fe50ea1d24536301582f2c") -- Depot 4830881
setManifestid(4830881, "2019430655932688173", 752210584)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4863060) -- PIRATES (CLASS) - Task Bar of Ragnalisa
addappid(4863070) -- OVERLOAD (CLASS) - Task Bar of Ragnalisa
addappid(4926240) -- Pirate  Overlord Class Pack - Task Bar of Ragnalis
addappid(4927610) -- Storage Expansion Pack
addappid(4927620) -- Complete DLC Pack