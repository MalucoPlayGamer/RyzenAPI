-- Lua provided by RyzenAPI
-- Game: Bury Me, My Love

-- MAIN APPLICATION
addappid(808090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(808091, 1, "358190b0ac72fa9e582148cbe11d8250dcd120c8df0f7e9458e4304ecabba804")

