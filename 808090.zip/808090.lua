-- Lua provided by RyzenAPI 
-- Game: Bury Me, My Love
addappid(808090)
addappid(808091, 1, "358190b0ac72fa9e582148cbe11d8250dcd120c8df0f7e9458e4304ecabba804")
