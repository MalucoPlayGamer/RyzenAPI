-- Lua provided by RyzenAPI
-- Game: Grim Facade: Sinister Obsession Collector’s Edition

-- MAIN APPLICATION
addappid(638290)

-- MAIN APP DEPOTS / PACKAGES
addappid(638291,0,"9087031202b834f03c0771bada7ae52286ee3fe7ac1685ce09a5148ee433d930")

