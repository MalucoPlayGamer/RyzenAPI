-- Lua provided by RyzenAPI
-- Game: ESCAPE POINT

-- MAIN APPLICATION
addappid(1250590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1250591, 1, "a11d836a7a2c80cd1b57153f20f7ea1b21e8abca39087d63ee24cbe9a3ac7a89")

