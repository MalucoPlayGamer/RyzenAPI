-- Lua provided by RyzenAPI
-- Game: ESCAPE POINT

-- MAIN APPLICATION
addappid(1250590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250591, 1, "a11d836a7a2c80cd1b57153f20f7ea1b21e8abca39087d63ee24cbe9a3ac7a89")
