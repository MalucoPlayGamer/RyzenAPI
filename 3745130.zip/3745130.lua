-- Lua provided by SkyAPI 
-- Game: Mirai's Midnight Stream - Collector's Edition
addappid(3745130)
addappid(3745131, 1, "7ef6759f6a487c1f1e91ce704482274f14d1b359c43c78c915a233572a8ed01f")
