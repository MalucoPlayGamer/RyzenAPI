-- Lua provided by RyzenAPI 
-- Game: 球球少女 Soundtrack
addappid(1431390)
addappid(1431391, 1, "d445cc257a2ca18ccff316bdbcb5af89516dbc1cf45eeb3e603bfc624d74697e")
addappid(1431392, 1, "07ebbf5dd7acc0cbfa7057e81c825e9da51d4bd252275d1e7599f4c9aae068e6")
