-- Lua provided by RyzenAPI
-- Game: Game: 球球少女 Soundtrack

-- MAIN APPLICATION
addappid(1431390)
-- Game: addappid(1431390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431391, 1, "d445cc257a2ca18ccff316bdbcb5af89516dbc1cf45eeb3e603bfc624d74697e")
addappid(1431392, 1, "07ebbf5dd7acc0cbfa7057e81c825e9da51d4bd252275d1e7599f4c9aae068e6")
