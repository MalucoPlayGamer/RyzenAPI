-- Lua provided by RyzenAPI
-- Game: Game: The Stillness of the Wind

-- MAIN APPLICATION
addappid(828900)
-- Game: addappid(828900)

-- MAIN APP DEPOTS / PACKAGES
addappid(828901, 1, "afe006e2ef989c3d3e01cc6dc6b72486e628e37e0020a28e03041028899b166e")
addappid(828902, 1, "6d9a50c49737d86246ef032ba77ba35606a685ccdc9af474877b73bbc896ec50")
addappid(828903, 1, "4b612c117185fb413386e52b08093de43108a3f6508e0c6500c3517e9e09069f")
