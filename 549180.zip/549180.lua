-- Lua provided by RyzenAPI 
-- Game: AppID 549180
addappid(549180)
addappid(549181, 1, "64f89147d53511e6ac6d6c942fc5635466d5fcbd76f67654333d5b0afb078db0")
addappid(549182, 1, "a5f470789deb7403a9edc65349e488491944f0ef928ed4abb53fcfea60210e0d")
