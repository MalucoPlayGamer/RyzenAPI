-- Lua provided by RyzenAPI
-- Game: Army Men: Toys in Space

-- MAIN APPLICATION
addappid(549180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(549181, 1, "64f89147d53511e6ac6d6c942fc5635466d5fcbd76f67654333d5b0afb078db0")
addappid(549182, 1, "a5f470789deb7403a9edc65349e488491944f0ef928ed4abb53fcfea60210e0d")
