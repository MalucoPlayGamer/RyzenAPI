-- Lua provided by RyzenAPI
-- Game: AppID 1212850

-- MAIN APPLICATION
addappid(1212850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212851, 1, "b50618c44a3a5b3efa036c2c0ed1340f1f131a8e08285a38dea08d5aaf1b2a99")

