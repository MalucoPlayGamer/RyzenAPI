-- Lua provided by RyzenAPI
-- Game: addappid(2443570)

-- MAIN APPLICATION
addappid(2443570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443571, 1, "84480e6190466fadb9c2020cf2e3348aa74bae8016aa999fb1c31351e3363fcc")
