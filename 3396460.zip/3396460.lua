-- Lua provided by SkyAPI 
-- Game: Urban Shadows Racing™ Tokyo
addappid(3396460)
addappid(3396461, 1, "46fe289b6c66cb35e2c198b8725c400168a8315f9ce79364c1fa7bb57e318923")
