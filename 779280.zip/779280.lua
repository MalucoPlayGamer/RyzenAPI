-- Lua provided by RyzenAPI
-- Game: 779280

-- MAIN APPLICATION
addappid(779280)

-- MAIN APP DEPOTS / PACKAGES
addappid(779280,0,"ebafb2163ec7f7614a48dc4c7da1b3c658487a7e544dec720d0bb847f2b40609")

