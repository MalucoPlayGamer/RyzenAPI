-- Lua provided by RyzenAPI
-- Game: addappid(3042340)

-- MAIN APPLICATION
addappid(3042340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042341, 1, "493dbab5a75720d84f9da7f75a9404b8d04c3377295dbc34c237a6788b87bc88")
