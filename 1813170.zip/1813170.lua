-- Lua provided by RyzenAPI
-- Game: Surrounded

-- MAIN APPLICATION
addappid(1813170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813171, 1, "e87cdb750b28cde795daa55a163e11d8db0eea895982a49209837aaa65f4d6cc")

