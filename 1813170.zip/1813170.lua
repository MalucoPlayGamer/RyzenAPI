-- Lua provided by RyzenAPI
-- Game: Surrounded

-- MAIN APPLICATION
addappid(1813170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813171, 1, "e87cdb750b28cde795daa55a163e11d8db0eea895982a49209837aaa65f4d6cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
