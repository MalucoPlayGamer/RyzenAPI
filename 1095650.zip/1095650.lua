-- Lua provided by RyzenAPI
-- Game: 1095650

-- MAIN APPLICATION
addappid(1095650)
-- Game: addappid(1095650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095651, 1, "5caafd1fda620b780d87452ccef906a5e795d1be35a3d6f9ac6a842e48f504bc")
