-- Lua provided by RyzenAPI
-- Game: Red Hood Adventure

-- MAIN APPLICATION
addappid(2051830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051831, 1, "a19f41b83965df41d03305d0081d4804eb4e8be054c5df08f3c0c56a25de1a65")
