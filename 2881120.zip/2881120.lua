-- Lua provided by RyzenAPI
-- Game: 2881120

-- MAIN APPLICATION
addappid(2881120)
-- Game: addappid(2881120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881121, 1, "9c0def7349aa20920fde8f93753ac986dc4a66268bc901bdd83b6aff11050166")
