-- Lua provided by RyzenAPI
-- Game: Her Place VR

-- MAIN APPLICATION
addappid(3594190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594191, 1, "0549442421a2aa7f183fe947c50d418a070ebc91e62af83bcdfda2977b9cb81d")

