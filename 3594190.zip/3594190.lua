-- Lua provided by RyzenAPI
-- Game: Her Place VR

-- MAIN APPLICATION
addappid(3594190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3594191, 1, "0549442421a2aa7f183fe947c50d418a070ebc91e62af83bcdfda2977b9cb81d")

