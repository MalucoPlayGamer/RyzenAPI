-- Lua provided by SkyAPI 
-- Game: AppID 777790
addappid(777790)
addappid(777791, 1, "02f6f4bac96cfcdbe0b078f4cda3d0caed0710ac5347a7c534d227162c54462f")
