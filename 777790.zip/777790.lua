-- Lua provided by RyzenAPI
-- Game: 777790

-- MAIN APPLICATION
addappid(777790)
-- Game: addappid(777790)

-- MAIN APP DEPOTS / PACKAGES
addappid(777791, 1, "02f6f4bac96cfcdbe0b078f4cda3d0caed0710ac5347a7c534d227162c54462f")
