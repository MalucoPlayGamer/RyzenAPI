-- Lua provided by RyzenAPI
-- Game: A Sweet Date With Azalea

-- MAIN APPLICATION
addappid(5064840) -- A Sweet Date With Azalea

-- MAIN APP DEPOTS / PACKAGES
addappid(5064841, 1, "6731165af5e93ae917a5b2c3156066ead49c3704f7c0e62b2f0b210fb2d53bf7") -- Depot 5064841
