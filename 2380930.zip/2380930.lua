-- Lua provided by RyzenAPI
-- Game: Game: Coral Caper

-- MAIN APPLICATION
addappid(2380930)
-- Game: addappid(2380930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380931, 1, "7188840ca922157091b1d57da52290b90d79aa0686fcc042d1832a18911115d9")
