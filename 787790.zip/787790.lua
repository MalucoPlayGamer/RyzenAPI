-- Lua provided by RyzenAPI
-- Game: Game: AppID 787790

-- MAIN APPLICATION
addappid(787790)
-- Game: addappid(787790)

-- MAIN APP DEPOTS / PACKAGES
addappid(787791, 1, "2fd4ae3df79053d5a795ec0c74898205e1e357c52d7462f96d6fb24edcbd0535")
