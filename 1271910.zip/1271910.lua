-- Lua provided by RyzenAPI
-- Game: Baby Dino Adventures

-- MAIN APPLICATION
addappid(1271910)
-- Game: addappid(1271910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271912,0,"1e62c2e65a9ff69ea2d1399c5aed39fb96a82b5aad5a755ac126757632dc3283")
addappid(1271913,0,"959402dbd1e4ca19755febdca04c2647608b4a302c35c1f35a4ab5567e639bcd")
addappid(1271914,0,"a7b39868508da79f8f4744e7b7129631bdc025a690d439f2db9a62ab3477da33")
