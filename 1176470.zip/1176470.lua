-- Lua provided by RyzenAPI
-- Game: Terra Invicta

-- MAIN APPLICATION
addappid(1176470)
addappid(2939040)
addappid(4713340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1176471, 1, "32afe0ca44ac3ee8659bb2d081a83e48b296b6a04937ad62f469dff1a46068e3")
