-- Lua provided by SkyAPI 
-- Game: AppID 1176470
addappid(1176470)
addappid(1176471, 1, "32afe0ca44ac3ee8659bb2d081a83e48b296b6a04937ad62f469dff1a46068e3")
