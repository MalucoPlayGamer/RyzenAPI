-- Lua provided by RyzenAPI
-- Game: Wordle на Русском

-- MAIN APPLICATION
addappid(1532610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532610,0,"cd4da3e61e933d754d8198863ab7a820f02287227cf117881705bd2ce0e5f32c")

