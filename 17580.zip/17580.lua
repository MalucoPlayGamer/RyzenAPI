-- Lua provided by RyzenAPI
-- Game: Dystopia

-- MAIN APPLICATION
addappid(17580)

-- MAIN APP DEPOTS / PACKAGES
addappid(17581, 1, "06dbb53f43c234945eb426efbe5cfc606cd18fdb4cc34444a17a9b17c077188f")
addappid(17582, 1, "9ecdd3d65cad65fa70168e212297e0c67657edd866642f7ce62bfc82ba8fd313")
addappid(17583, 1, "4f85c433f6d6cd9be31dc68b03a6514d53e1464263f750fbadf018074d1fe8cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
