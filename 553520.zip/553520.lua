-- Lua provided by RyzenAPI
-- Game: addappid(553520)

-- MAIN APPLICATION
addappid(553520)

-- MAIN APP DEPOTS / PACKAGES
addappid(553521, 1, "dfe8a2efbc72e8a5d56d2d37e574aa0e973bb651d14a2a5a32eec90424bf062d")
addappid(553522, 1, "4eaf142281eefcc1678c2ab3e6178a5c8558924638c9102622e9233429c12cf1")
