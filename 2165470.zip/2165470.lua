-- Lua provided by SkyAPI 
-- Game: Taora : Survival
addappid(2165470)
addappid(2165471, 1, "d2d9ff9be71ef176fdb84cac9cc15f96033eb5926472a1ff8dfc8b9b58a79a57")
