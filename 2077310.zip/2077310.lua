-- Lua provided by RyzenAPI 
-- Game: GogMagog
addappid(2077310)
addappid(2077311, 1, "5f8b9a6a4149f45a0f542f18f94ff36ed91b55ed9c6cbced3c9db8fabf9ff884")
