-- Lua provided by RyzenAPI
-- Game: Xenonauts 2 Demo

-- MAIN APPLICATION
addappid(1326030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326031, 1, "1f750237711cf16ea3041fe4c9097bb322cdf1f687ae356ddde07112ca442d2b")

