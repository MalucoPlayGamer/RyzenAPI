-- Lua provided by RyzenAPI
-- Game: Island Supermarket Simulator

-- MAIN APPLICATION
addappid(3700210)
-- Game: addappid(3700210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700211, 1, "78b07e3d9c600c4b1c36a4891c92da27923990fb16d14539a0512df032ae7a8a")
