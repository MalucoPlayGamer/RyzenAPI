-- Lua provided by RyzenAPI
-- Game: Game: AppID 2615560

-- MAIN APPLICATION
addappid(2615560)
-- Game: addappid(2615560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615561, 1, "4fa9e098f64fd88529a9f0f8982d29f4a50a2e2b3c8ed8d1369a706b6943c322")
