-- 4565560's Lua and Manifest Created by Hubcap Manifest
-- Princess Knight Concedes to Cum
-- Created: July 25, 2026 at 06:07:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4565560, 1, "293aaae1bc60ae3e56fe6e9e3be3b3deab30e8def6170a5a13f6c269a3b66089") -- Princess Knight Concedes to Cum
-- MAIN APP DEPOTS
addappid(4565561, 1, "bf5047396d34852b8671b2cd1a8b59dbf49d636564af8b7f02d79f9d86d7a1af") -- Depot 4565561
setManifestid(4565561, "5041609040484085799", 1332569722)
addappid(4565562, 1, "0e2a1727a57e7c59daee71488fb2be6ea4b16df3c9b2c241521b3a70d52d0395") -- Depot 4565562
setManifestid(4565562, "5262000922786159299", 1296890469)