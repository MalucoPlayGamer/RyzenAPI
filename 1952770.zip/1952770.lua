-- Lua provided by RyzenAPI 
-- Game: ConquestAreas
addappid(1952770)
addappid(1952771, 1, "686e325558c5cfe3f36471eac0bc41d569f67a53d61631b8dd31ae878b2ab67f")
