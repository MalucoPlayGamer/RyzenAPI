-- Lua provided by RyzenAPI
-- Game: Game: yni^

-- MAIN APPLICATION
addappid(2278390)
-- Game: addappid(2278390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278391, 1, "564ce0c95bb4912b49dd49c796168622084a141a95748ec96ae936358a15e40f")
