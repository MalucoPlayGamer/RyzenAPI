-- Lua provided by RyzenAPI
-- Game: Girl in Crimson Dress - Tales of the demons in the mountain Demo

-- MAIN APPLICATION
addappid(2797020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797021, 1, "6dfffb9521733483a5c34db3129a6f61f233d74c6d0cebbb6365f628c6fa0e60")
