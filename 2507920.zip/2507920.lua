-- Lua provided by RyzenAPI
-- Game: Game: Hookah Haze Demo

-- MAIN APPLICATION
addappid(2507920)
-- Game: addappid(2507920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507921, 1, "147e98b97a7d742112d40084c119f3ab30cfddc4a2e008a671e871ca0fcb307b")
