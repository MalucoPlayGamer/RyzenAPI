-- Lua provided by RyzenAPI 
-- Game: Hookah Haze Demo
addappid(2507920)
addappid(2507921, 1, "147e98b97a7d742112d40084c119f3ab30cfddc4a2e008a671e871ca0fcb307b")
