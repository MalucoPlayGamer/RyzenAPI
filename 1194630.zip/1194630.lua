-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: Little Hope

-- MAIN APPLICATION
addappid(1194630)
addappid(1259810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1194633,0,"c2a60fdea7b1519ad4f79cde6079b8cd3894fa5884ea554071369734d3977594")
addappid(1194634,0,"2d0d066d3183f8a09ff116446a893895daeda82fbb6911588ed7ef21f4814f60")

