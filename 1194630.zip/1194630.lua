-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: Little Hope

-- MAIN APPLICATION
addappid(1194630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194633,0,"c2a60fdea7b1519ad4f79cde6079b8cd3894fa5884ea554071369734d3977594")
addappid(1194634,0,"2d0d066d3183f8a09ff116446a893895daeda82fbb6911588ed7ef21f4814f60")
