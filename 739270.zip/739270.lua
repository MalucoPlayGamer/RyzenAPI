-- Lua provided by RyzenAPI
-- Game: Cradle of Links VR

-- MAIN APPLICATION
addappid(739270)

-- MAIN APP DEPOTS / PACKAGES
addappid(739271,0,"0fc4dbabff4ff6309f9cde660c540a1511e6b0e5b58faeba63685fd024339be9")

