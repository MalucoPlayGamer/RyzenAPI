-- 3978390's Lua and Manifest Created by Hubcap Manifest
-- Frontline: Operation Kosmonaut
-- Created: August 12, 2026 at 00:04:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3978390) -- Frontline: Operation Kosmonaut
-- MAIN APP DEPOTS
addappid(3978391, 1, "64c4cd2fb30dde85c86cf76322fd52511c3cf19947f15d82a44b888ff58373a7") -- Depot 3978391
setManifestid(3978391, "4113569550793943154", 808489142)
addappid(3978392, 1, "b3062bc967503f55803b4da69659702f79ebe32ae542a976c622a0fd42d5bac8") -- Depot 3978392
setManifestid(3978392, "1949722380978297186", 831060692)