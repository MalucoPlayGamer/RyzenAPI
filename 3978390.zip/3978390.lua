-- Lua provided by RyzenAPI
-- Game: Frontline: Operation Kosmonaut

-- MAIN APPLICATION
addappid(3978390) -- Frontline: Operation Kosmonaut

-- MAIN APP DEPOTS / PACKAGES
addappid(3978391, 1, "64c4cd2fb30dde85c86cf76322fd52511c3cf19947f15d82a44b888ff58373a7") -- Depot 3978391
addappid(3978392, 1, "b3062bc967503f55803b4da69659702f79ebe32ae542a976c622a0fd42d5bac8") -- Depot 3978392

