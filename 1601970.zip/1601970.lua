-- Lua provided by SkyAPI 
-- Game: AppID 1601970
addappid(1601970)
addappid(1601971, 1, "5e54b63ec13550b8bbe92b018835c1b5725fc730a71818801107cd26b4e8a79e")
addappid(1836780)
