-- Lua provided by RyzenAPI
-- Game: Tunguska: The Visitation - Final Cut

-- MAIN APPLICATION
addappid(1601970)
addappid(1836780)
addappid(2181860)
addappid(2194620)
addappid(2426340)
addappid(2509350)
addappid(2692830)
addappid(3077300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601971,0,"5e54b63ec13550b8bbe92b018835c1b5725fc730a71818801107cd26b4e8a79e")

