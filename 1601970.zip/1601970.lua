-- Lua provided by RyzenAPI
-- Game: Tunguska: The Visitation - Final Cut

-- MAIN APPLICATION
addappid(1601970)
addappid(1836780)
addappid(2181860)
addappid(2194620)
addappid(2426340)
addappid(2509350)
addappid(2692830)
addappid(3077300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601971,0,"5e54b63ec13550b8bbe92b018835c1b5725fc730a71818801107cd26b4e8a79e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
