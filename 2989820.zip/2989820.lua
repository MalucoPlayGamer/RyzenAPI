-- Lua provided by RyzenAPI
-- Game: Pocket Waifu: Desktop Pet

-- MAIN APPLICATION
addappid(2989820)
