-- Lua provided by RyzenAPI
-- Game: Game: Sudeki

-- MAIN APPLICATION
addappid(233350)
-- Game: addappid(233350)

-- MAIN APP DEPOTS / PACKAGES
addappid(233351, 1, "74a9a4be91b255f637653cff4e712834a35bf1a3086b6b89b05f5f88c47220a4")
