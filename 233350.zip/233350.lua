-- Lua provided by RyzenAPI
-- Game: Sudeki

-- MAIN APPLICATION
addappid(233350)

-- MAIN APP DEPOTS / PACKAGES
addappid(233351, 1, "74a9a4be91b255f637653cff4e712834a35bf1a3086b6b89b05f5f88c47220a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
