-- Lua provided by RyzenAPI
-- Game: addappid(2086050)

-- MAIN APPLICATION
addappid(2086050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086052,0,"84af280228b4bd02a9c66b858cd9f9ffd607e6ad8c1cbd092a007b9ec488fd91")
