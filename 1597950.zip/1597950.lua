-- Lua provided by RyzenAPI
-- Game: 1597950

-- MAIN APPLICATION
addappid(1597950)
-- Game: addappid(1597950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597951, 1, "1aaf1e1f703622126b75e7402f8ceb17653dc9768d5964ed3487b89e38970fef")
