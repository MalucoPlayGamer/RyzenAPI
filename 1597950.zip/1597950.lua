-- Lua provided by RyzenAPI 
-- Game: Dawn of Light
addappid(1597950)
addappid(1597951, 1, "1aaf1e1f703622126b75e7402f8ceb17653dc9768d5964ed3487b89e38970fef")
