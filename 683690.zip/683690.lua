-- Lua provided by RyzenAPI
-- Game: Game: AppID 683690

-- MAIN APPLICATION
addappid(683690)
-- Game: addappid(683690)

-- MAIN APP DEPOTS / PACKAGES
addappid(683691, 1, "acd981f369a68de0118842c9a7d4d17e795d675d0200f575cab8bd0f82d7b8e5")
