-- Lua provided by RyzenAPI
-- Game: Lost Eidolons

-- MAIN APPLICATION
addappid(1580520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580521, 1, "5640fed1f15b15a419f909fc50eda8f53a1ca47a45b2e8c43b4cbe9dc8492bb0")
addappid(2162250, 0, "b32e42fd464f44311079f0f8ea2719cd74d37fcba56832e3654306f08ce7307a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2162280)
