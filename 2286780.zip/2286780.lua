-- Lua provided by RyzenAPI 
-- Game: Aeruta
addappid(2286780)
addappid(2286781, 1, "f35f978f4b5c9e3f39fe30c37e6965286a571f2600868f74d364e6ddf8f13ee7")
