-- Lua provided by RyzenAPI
-- Game: addappid(360230)

-- MAIN APPLICATION
addappid(360230)

-- MAIN APP DEPOTS / PACKAGES
addappid(360231, 1, "0193c79c6e17aa54501915296cdfbacc0fce43e037f4fcbd103ce927e79bd6f4")
