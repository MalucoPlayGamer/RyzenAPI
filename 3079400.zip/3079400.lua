-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Abandoned Prison

-- MAIN APPLICATION
addappid(3079400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079401, 1, "f8aeddd31d4df20615b36b3381a55566b96315499d4b8ee4f9d473f718fb9c4c")