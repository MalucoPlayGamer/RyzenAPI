-- Lua provided by RyzenAPI
-- Game: Gay Sex Adventures - Episode 1

-- MAIN APPLICATION
addappid(2675660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675661, 1, "bb92647ccd5a8601ed8dddf957a26e7429848d628241ac9e1b56f37025a32ced")
