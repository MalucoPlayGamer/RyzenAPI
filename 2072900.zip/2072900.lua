-- Lua provided by RyzenAPI
-- Game: Ultimate Soldier

-- MAIN APPLICATION
addappid(2072900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072901, 1, "e2958d75657dc73bfd67ad5bb1e291f3b8aae94f3fd6e13367b2379480506504")

