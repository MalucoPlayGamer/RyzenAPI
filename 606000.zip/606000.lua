-- Lua provided by RyzenAPI
-- Game: Die for Valhalla!

-- MAIN APPLICATION
addappid(606000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(606001, 1, "fb03979470867c51c8f8a50732229fea53018ca68f9091b06088fb1d99436b4c")

