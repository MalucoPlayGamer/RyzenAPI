-- Lua provided by RyzenAPI
-- Game: Die for Valhalla!

-- MAIN APPLICATION
addappid(606000)

-- MAIN APP DEPOTS / PACKAGES
addappid(606001, 1, "fb03979470867c51c8f8a50732229fea53018ca68f9091b06088fb1d99436b4c")

