-- 3252310's Lua and Manifest Created by Hubcap Manifest
-- Comet Rogue
-- Created: December 01, 2025 at 10:33:46 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3252310) -- Comet Rogue
-- MAIN APP DEPOTS
addappid(3252311, 1, "f27a839c17c518f337bea793291c8a2a0af155732f317d92b38f075f37c78743") -- Depot 3252311
-- setManifestid(3252311, "970742214176030130", 849274048)