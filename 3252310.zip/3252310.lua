-- Lua provided by RyzenAPI
-- Game: Comet Rogue

-- MAIN APPLICATION
addappid(3252310) -- Comet Rogue

-- MAIN APP DEPOTS / PACKAGES
addappid(3252311, 1, "f27a839c17c518f337bea793291c8a2a0af155732f317d92b38f075f37c78743") -- Depot 3252311

