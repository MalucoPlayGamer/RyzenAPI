-- Lua provided by RyzenAPI
-- Game: addappid(1610560)

-- MAIN APPLICATION
addappid(1610560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610561, 1, "c187bc1bf6c3e8c774ce3a1cce14d7d298178cddf3c864e37e21bac871e6df85")
