-- Lua provided by RyzenAPI
-- Game: addappid(2158380)

-- MAIN APPLICATION
addappid(2158380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158381, 1, "9d744eb3a95d77772f7d71c52c0231e7e2b3d4ded7bd36b3681eb2e6df9ae3d0")
