-- Lua provided by RyzenAPI
-- Game: zoku sonohigurashi vs touhou universe 2

-- MAIN APPLICATION
addappid(1320240)
-- Game: addappid(1320240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320241, 1, "ec757dd454bb5b36c2b8694476f4494894ec2bed954f351d4587e28508b5d854")
