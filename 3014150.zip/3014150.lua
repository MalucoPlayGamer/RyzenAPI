-- Lua provided by RyzenAPI
-- Game: 1/8192

-- MAIN APPLICATION
addappid(3014150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3014151, 1, "6887a88c9d8d90ceddc1efad1e145cd31fce4d988dc81afa4870f3166977a711")