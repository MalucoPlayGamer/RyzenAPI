-- Lua provided by RyzenAPI
-- Game: 3014150

-- MAIN APPLICATION
addappid(3014150)
-- Game: addappid(3014150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014151, 1, "6887a88c9d8d90ceddc1efad1e145cd31fce4d988dc81afa4870f3166977a711")
