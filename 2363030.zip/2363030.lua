-- Lua provided by RyzenAPI
-- Game: Tasking

-- MAIN APPLICATION
addappid(2363030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363031, 1, "fb60ab1e7eeb1b32699d4b5f9e0125a5e8656ea962781906644740b58b21c027")
