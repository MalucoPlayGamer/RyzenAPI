-- Lua provided by RyzenAPI
-- Game: The Googol Clicker

-- MAIN APPLICATION
addappid(2155480)
-- Game: addappid(2155480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155481, 1, "f6f019b54cd003272e4415a30e19cea7cc7c650b18117d35c7d4c7ca636b95bc")
