-- Lua provided by RyzenAPI
-- Game: True or False Universe

-- MAIN APPLICATION
addappid(698370)

-- MAIN APP DEPOTS / PACKAGES
addappid(698371,0,"3a6982dce63a564f40470614492367c6e87c764223d9fb3b85ebe713f11d9894")

