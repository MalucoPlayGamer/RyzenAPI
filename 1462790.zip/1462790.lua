-- Lua provided by RyzenAPI
-- Game: Game: Fight of Animals: Arena

-- MAIN APPLICATION
addappid(1462790)
-- Game: addappid(1462790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462791, 1, "1b62f06406a21996ece8090c0f46f4b0c1adebbe038a523e07ae0e908c593b1f")
