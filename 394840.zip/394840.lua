-- Lua provided by RyzenAPI
-- Game: addappid(394840)

-- MAIN APPLICATION
addappid(394840)

-- MAIN APP DEPOTS / PACKAGES
addappid(394841, 1, "bc6932c20b9f53ca7b47a6f8320445c759cfbdd6619e1f97161085d50aa05634")
