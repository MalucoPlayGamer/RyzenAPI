-- Lua provided by RyzenAPI
-- Game: Mars Colony: Frontier

-- MAIN APPLICATION
addappid(394840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394841, 1, "bc6932c20b9f53ca7b47a6f8320445c759cfbdd6619e1f97161085d50aa05634")
