-- Lua provided by RyzenAPI 
-- Game: AppID 623920
addappid(623920)
addappid(623921, 1, "bb373194957a5f60f7726644961ae785af22db15378f7e202a215e8ff1301d46")
addappid(623922, 1, "f3308f2ceb4f440963cc75f20d6241c3eda86e1dcc396047cfe05a6859a0b920")
