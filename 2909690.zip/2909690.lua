-- Lua provided by RyzenAPI
-- Game: Honeymoon : Mystery Journey Artbook

-- MAIN APPLICATION
addappid(2909690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909691, 1, "233bd70d46a87c5a0cb540b4fe81601c9c5f4470b890d5871cd60b1d003df279")

