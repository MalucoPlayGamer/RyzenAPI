-- Lua provided by RyzenAPI
-- Game: Game: Shephy

-- MAIN APPLICATION
addappid(651340)
-- Game: addappid(651340)

-- MAIN APP DEPOTS / PACKAGES
addappid(651341, 1, "a6c3d4a637cb30a1764fd8c24cf63a466eee805246ed3d437850309915098b1f")
