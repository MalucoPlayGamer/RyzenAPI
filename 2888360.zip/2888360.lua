-- Lua provided by RyzenAPI
-- Game: Sex Universe [18+]

-- MAIN APPLICATION
addappid(2888360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888361, 1, "219e89a724660e5c6fd46b6978bc67fd33a6430473801d9d0b44e1d0ed14da1d")
