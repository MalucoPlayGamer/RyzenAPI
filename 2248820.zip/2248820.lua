-- Lua provided by RyzenAPI
-- Game: Five Nights At Smog's

-- MAIN APPLICATION
addappid(2248820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248821, 1, "c2b53392431a7ce21639bbeb035a1122a598006ed73aac470f4a804fe143b57c")
