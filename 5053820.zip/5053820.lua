-- Lua provided by RyzenAPI
-- Game: Mimic Party

-- MAIN APPLICATION
addappid(5168110) -- All Characters

-- MAIN APP DEPOTS / PACKAGES
addappid(5053820, 1, "3687a910eb76c9e3eccddcb2ce6cc97c4bc5667ef8e20e668cbedc150283773a") -- Mimic Party
addappid(5053821, 1, "3bf0ccc9e3c7c0ff61adcadc28e45680676fe6f9a82c9c4ad55c417c532c35e6") -- Depot 5053821

