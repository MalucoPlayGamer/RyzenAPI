-- Lua provided by RyzenAPI
-- Game: 特務朔的祕密行動 Demo

-- MAIN APPLICATION
addappid(3244860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244861, 1, "a046a4101bd4b758a418884d0d1d2393b09a1655ae8b26c5acc8706517c543d6")
