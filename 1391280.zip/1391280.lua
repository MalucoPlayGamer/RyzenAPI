-- Lua provided by RyzenAPI
-- Game: 3D Hentai Chess

-- MAIN APPLICATION
addappid(1391280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391281, 1, "4531861bb762b715d81f46ed3596fdc1ee2c9f0044412231ec82f619d48b9562")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1450440)
addappid(1450450)
addappid(1707360)
