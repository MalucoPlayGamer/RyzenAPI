-- Lua provided by RyzenAPI 
-- Game: 3D Hentai Chess
addappid(1391280)
addappid(1391281, 1, "4531861bb762b715d81f46ed3596fdc1ee2c9f0044412231ec82f619d48b9562")
