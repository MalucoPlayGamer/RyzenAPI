-- Lua provided by RyzenAPI
-- Game: Zeepkist - King's Day DLC

-- MAIN APPLICATION
addappid(1962260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962260,0,"0b68d435c01dc67f9c7993a9ecfc92ddcaf0c1be1854d97d5c3e8fb33e07de43")
