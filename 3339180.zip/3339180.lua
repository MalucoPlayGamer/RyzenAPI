-- Lua provided by SkyAPI 
-- Game: Lost Verses
addappid(3339180)
addappid(3339181, 1, "dc1a04e8a9bdd3db235501b9a807b3b8574c674dec8596d790e325862bcbb5c9")
