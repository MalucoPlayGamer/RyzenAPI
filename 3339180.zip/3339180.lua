-- Lua provided by RyzenAPI
-- Game: addappid(3339180)

-- MAIN APPLICATION
addappid(3339180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339181, 1, "dc1a04e8a9bdd3db235501b9a807b3b8574c674dec8596d790e325862bcbb5c9")
