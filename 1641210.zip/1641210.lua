-- Lua provided by SkyAPI 
-- Game: AppID 1641210
addappid(1641210)
addappid(1641211, 1, "e8b654b28595157cef85f3e9fa71ff010cb6d3ceb05fa68c6c19d619eb1e5e4e")
