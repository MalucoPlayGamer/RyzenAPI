-- Lua provided by RyzenAPI
-- Game: addappid(1380040)

-- MAIN APPLICATION
addappid(1380040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380040,0,"9ae1c8d6d4d8ecf5c84637f84f3f17d8dcc27b9fad706cc2574f3b93beb17f2a")
