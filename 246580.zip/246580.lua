-- Lua provided by RyzenAPI
-- Game: The Typing of The Dead: Overkill

-- MAIN APPLICATION
addappid(246580)

-- MAIN APP DEPOTS / PACKAGES
addappid(246581, 1, "976876bb00da7560e27d8ee567af59026d035d782916bb06a5d77186aa7d59f2")
addappid(255210, 0, "dc69e23823dfe5c9ba212c83bc370b080ab4573c88c3e3337d0d59673bf5d326")
addappid(259210, 0, "268d8e6f51cda08e22aef42af6a1a371583746873ffbb0491060a051c6e113b4")
addappid(259211, 0, "ce111422bb763840d53baedf41dbaf846cde7cd6ff82d2a2e5b0bd5ef0a80f76")
addappid(278130, 0, "1d66a5c9f494248f493203c5193895d13a64daec84cdd5001dba7a5a6e093e33")
addappid(278131, 0, "19019e72c097e00044eb562750331c5b37cc0c3c0cc69c30a0bc48fd3b8ef666")
addappid(282520, 0, "a3b0e04337391e1719c5e9a49bfe5e015b28eedc93aab15069c0e8a580ab2a4a")
addappid(286920, 0, "59f1c839af3537ef80f75d1be433cacf317211011ce634597665990a0b225230")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
