-- Lua provided by RyzenAPI
-- Game: Game: AppID 2362250

-- MAIN APPLICATION
addappid(2362250)
-- Game: addappid(2362250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362251, 1, "aa51817e60379dc995ed206f2f3bf01f15ac2ed7521757ffa29a5001f17dcd91")
