-- Lua provided by SkyAPI 
-- Game: AppID 3580110
addappid(3580110)
addappid(3580111, 1, "247aab193f4110823002071b5307c04d872b83f1c6ab13aae2f7e1edd8ac0c70")
