-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Toge Land

-- MAIN APPLICATION
addappid(3145350)

