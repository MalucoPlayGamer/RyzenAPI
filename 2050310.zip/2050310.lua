-- Lua provided by SkyAPI 
-- Game: OutWave: Retro chase
addappid(2050310)
addappid(2050311, 1, "6efa8c3141b4110313cc6ec892f3bb23fa8b516224cd29a3c8758bc4b2fc9d78")
