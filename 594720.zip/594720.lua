-- Lua provided by RyzenAPI 
-- Game: AppID 594720
addappid(594720)
addappid(594721, 1, "5fc6f04e030834b14b61e4d180462ce63f86e482fb73cb490b5f683020e4f015")
