-- Lua provided by RyzenAPI
-- Game: addappid(594720)

-- MAIN APPLICATION
addappid(594720)

-- MAIN APP DEPOTS / PACKAGES
addappid(594721, 1, "5fc6f04e030834b14b61e4d180462ce63f86e482fb73cb490b5f683020e4f015")
