-- Lua provided by RyzenAPI
-- Game: SHUFFLE! Episode 2 ~Kami ni mo Akuma ni mo Nerawareteiru Otoko~

-- MAIN APPLICATION
addappid(2321180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2321181, 1, "8ccfee7d23e7e2288776358238799f34bebb815ef72aab375c234f3ef6c03fe2")
addappid(2321183, 1, "072dbcb0edbd177bab6b742467d848919842d325343b03f2eb5a6c532cd51aff")

