-- Lua provided by SkyAPI 
-- Game: SHUFFLE! Episode 2 ~Kami ni mo Akuma ni mo Nerawareteiru Otoko~
addappid(2321180)
addappid(2321181, 1, "8ccfee7d23e7e2288776358238799f34bebb815ef72aab375c234f3ef6c03fe2")
addappid(2321183, 1, "072dbcb0edbd177bab6b742467d848919842d325343b03f2eb5a6c532cd51aff")
