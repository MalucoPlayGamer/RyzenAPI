-- Lua provided by RyzenAPI
-- Game: Frozen Synapse Prime

-- MAIN APPLICATION
addappid(328600)
addappid(332340)

-- MAIN APP DEPOTS / PACKAGES
addappid(328601, 1, "95ca43f72b35bdfac60ed14fa963b91bf5b462805d864cb9607ee70e7a16f9f6")

