-- Lua provided by RyzenAPI
-- Game: Forbidden Ingress

-- MAIN APPLICATION
addappid(1175200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175202,0,"79156a5fbbeea26724acb6dd1f63e245723fa5468ea1f4dfe094a1d64464e3d2")
