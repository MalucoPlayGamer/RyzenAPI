-- Lua provided by RyzenAPI
-- Game: SubwaySim 2

-- MAIN APPLICATION
addappid(2707070)
-- Game: addappid(2707070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707071, 1, "45615e6f882308fd298bcb21be7a3df4add896748f19c82ef96f52d48b95de36")
addappid(2707072, 1, "97255bb5f8bd6943cb3b760c158efafb1f7a5f0042c0e15b49485bb128ab1b82")
addappid(2707073, 1, "1440d88a0caea0b27f1dcb8159b3851d48b1adfb743b98de0c0f78c8034b4dfa")
