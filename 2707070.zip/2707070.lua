-- Lua provided by RyzenAPI
-- Game: SubwaySim 2

-- MAIN APPLICATION
addappid(2707070)
addappid(3405560)
addappid(3405570)
addappid(4600590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2707071, 1, "45615e6f882308fd298bcb21be7a3df4add896748f19c82ef96f52d48b95de36")
addappid(2707072, 1, "97255bb5f8bd6943cb3b760c158efafb1f7a5f0042c0e15b49485bb128ab1b82")
addappid(2707073, 1, "1440d88a0caea0b27f1dcb8159b3851d48b1adfb743b98de0c0f78c8034b4dfa")

