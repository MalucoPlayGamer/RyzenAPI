-- Lua provided by RyzenAPI
-- Game: Yggdra Union

-- MAIN APPLICATION
addappid(2107860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107861, 1, "02a08ee30f83c1f9856786f2447150aa4004f014174f15264e8ae4c8cf5a7ac0")
addappid(2107862, 1, "f06bb9fe4951bb1c57446c5e9f11d4c5a487e345b8d0ebb63125c2453b76d5e2")
addappid(2107863, 1, "daff04885d6453f3ee9abe5ad0f413d7cbe526e62d682a7927ea002caf7fe7ab")
addappid(2107864, 1, "9c6458663f60ad8979ce56077f19717e6b21e6f6d735f9d39bf0f98f1d8f4a7c")
addappid(2107865, 1, "367866279cbca2534549d986630bc58103cfa1ce3136a559bbcf8ba5615c6204")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
