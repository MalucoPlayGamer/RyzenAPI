-- Lua provided by RyzenAPI 
-- Game: YOU DON'T KNOW JACK Vol. 2
addappid(259940)
addappid(259941, 1, "c32006645855e171d6a3e24094c95957735e162c97457aba7d8493258227862b")
