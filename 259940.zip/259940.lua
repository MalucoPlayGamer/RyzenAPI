-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 2

-- MAIN APPLICATION
addappid(259940)

-- MAIN APP DEPOTS / PACKAGES
addappid(259941, 1, "c32006645855e171d6a3e24094c95957735e162c97457aba7d8493258227862b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
