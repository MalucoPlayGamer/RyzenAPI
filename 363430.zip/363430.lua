-- Lua provided by RyzenAPI
-- Game: setManifestid(363432,"3980887520846089941")

-- MAIN APPLICATION
addappid(363430)
-- Game: addappid(363430)

-- MAIN APP DEPOTS / PACKAGES
addappid(363432,0,"6cb914bb6790fb3282a0e10967e32131ca8484ce7ad55778272c1a75a74fe13e")
