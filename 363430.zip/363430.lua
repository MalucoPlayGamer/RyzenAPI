-- Lua provided by RyzenAPI
-- Game: D Series OFF ROAD Driving Simulation

-- MAIN APPLICATION
addappid(363430)

-- MAIN APP DEPOTS / PACKAGES
addappid(363432,0,"6cb914bb6790fb3282a0e10967e32131ca8484ce7ad55778272c1a75a74fe13e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
