-- Lua provided by SkyAPI 
-- Game: AppID 533300
addappid(533300)
addappid(533301, 1, "122c8a3c7b0fa1b4761e4e779efd6e2f5f9bb1b4da0c974bdca9d6cf2b8affe1")
addappid(542330, 0, "cd2d272756b06d36cbc918ca8a3a26a0045e7817ceedf78eeab79641c2730bf2")
