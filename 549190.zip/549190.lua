-- Lua provided by RyzenAPI
-- Game: 549190

-- MAIN APPLICATION
addappid(549190)
-- Game: addappid(549190)

-- MAIN APP DEPOTS / PACKAGES
addappid(549191, 1, "02f5c2bc5e45457f34765e6655db4651977e11e3268dbb10068371e2caae7eae")
