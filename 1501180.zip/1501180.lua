-- Lua provided by RyzenAPI
-- Game: Crazy Kung Fu Demo

-- MAIN APPLICATION
addappid(1501180)
-- Game: addappid(1501180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501181, 1, "ce2d1a35250c68f7a13fb3de1fb98f31ff6ee8fd290f785a17f0f36760f81001")
