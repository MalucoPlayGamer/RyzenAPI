-- Lua provided by RyzenAPI 
-- Game: MISTOVER
addappid(909510)
addappid(909511, 1, "09e13754483527af7d8859821319d7a814be7a1817a36754ac076ee2366e236a")
addappid(1231660, 0, "33faf33ffb0496ed1fae997681fdf4e3c758a6b912f662b5b4007125fc2249b3")
