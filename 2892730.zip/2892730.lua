-- Lua provided by RyzenAPI
-- Game: addappid(2892730)

-- MAIN APPLICATION
addappid(2892730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892731, 1, "daec0891e21f10f2bb5981d8c6c6cb8950b5c37aaab1a79a66c0bdaac07278bc")
