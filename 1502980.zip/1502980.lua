-- Lua provided by RyzenAPI
-- Game: Atelier Firis: The Alchemist and the Mysterious Journey DX

-- MAIN APPLICATION
addappid(1502980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502981, 1, "01343cf6681e4e09f5839b0c0274341b959bf00739ae8fe1ab113b90bb787052")
