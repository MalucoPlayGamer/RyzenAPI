-- Lua provided by RyzenAPI
-- Game: Atelier Firis: The Alchemist and the Mysterious Journey DX

-- MAIN APPLICATION
addappid(1502980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502981, 1, "01343cf6681e4e09f5839b0c0274341b959bf00739ae8fe1ab113b90bb787052")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
