-- Lua provided by RyzenAPI
-- Game: Game: Runnyk

-- MAIN APPLICATION
addappid(1826410)
-- Game: addappid(1826410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826411, 1, "12266ba616c4b5ea797217390dccf5e382a296f66b4e114983145d71813c7a79")
