-- Lua provided by SkyAPI 
-- Game: Guardians of Lodino Forest
addappid(2508680)
addappid(2508681, 1, "f3a2b3ea473b9d2145b6bf9d1f7242c89fa78e53d26d0d70bdab069a12c2c0df")
