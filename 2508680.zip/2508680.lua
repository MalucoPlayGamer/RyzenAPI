-- Lua provided by RyzenAPI
-- Game: 2508680

-- MAIN APPLICATION
addappid(2508680)
-- Game: addappid(2508680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508681, 1, "f3a2b3ea473b9d2145b6bf9d1f7242c89fa78e53d26d0d70bdab069a12c2c0df")
