-- Lua provided by RyzenAPI
-- Game: Game: Lucius

-- MAIN APPLICATION
addappid(218640)
-- Game: addappid(218640)

-- MAIN APP DEPOTS / PACKAGES
addappid(218641, 1, "479d7801c407ceca67cccaf7ea7eec1d11aabf034d72b408199a87efa7042ab2")
addappid(218643, 1, "8d941de0a2c5dd06413d4fb0ea7a33243b5223813fa133249d2e2c818a571abb")
addappid(218644, 1, "489c482d8fb29d816f0af07c8e89626b78fab0f4c4d5f64d566a3c5c40dd8f87")
addappid(218645, 1, "e9e027440a7a011fa19d3c3f4c3e1a13b331ce4a6ac94e6b3f9a8b8e0c37d483")
addappid(218646, 1, "5db208c1d7c56cdeafdf8c16fb70ed6914f8173d571582ed41ba556d56c20b2c")
addappid(218647, 1, "4613923ebeafba9bf9f8bbc5a0199fad2097e2d8f5949cf2b76333ccd2dafcac")
addappid(218648, 1, "2bad8c63e08e9659e09831e7600c1dea8907897f2a2828d16c186a811d7301a5")
addappid(218649, 1, "c80072ed1edce3a4035b54d23845bfc90e8f9ec2b2da67a5d664cc04f6c3d6a8")
addappid(218650, 1, "460d043981c46707dfb260c6212f9eba41b75d9babf3c22dd6500fc3c05a6013")
