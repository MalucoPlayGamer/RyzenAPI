-- Lua provided by RyzenAPI
-- Game: 2387120

-- MAIN APPLICATION
addappid(2387120)
-- Game: addappid(2387120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387121, 1, "93c0d7e00dec77f927657f66e01b001ff5cd4ebe1bbf4696ef56dd22c94962d8")
