-- Lua provided by RyzenAPI
-- Game: Game: Radiant Victorias

-- MAIN APPLICATION
addappid(2652480)
-- Game: addappid(2652480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652481, 1, "1e06011410c52d49a63a62d1aeb28828b62bc49e0efd3d64d86a4fb9d56d200a")
addappid(2652482, 1, "1fcf8c4d25588f4479021516967d8e384b98ae85ca22b0cbffbcf5dc5940854d")
addappid(2652483, 1, "b39563af2f389c73ef29da80485704fb740f7e3af988664b71d8e6a3ef6e86b5")
addappid(2652484, 1, "810004b42142dd071aa846fa2065a5c52cc1af6af201299fc2412cb7076b1284")
