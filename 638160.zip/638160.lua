-- Lua provided by RyzenAPI
-- Game: addappid(638160)

-- MAIN APPLICATION
addappid(638160)

-- MAIN APP DEPOTS / PACKAGES
addappid(638161, 1, "e663078cd05b6e86e769d4434d9f99b8a5769ece6dac924c7d17cacd1f9def07")
addappid(688090, 0, "ce6359a7554ff81dc82ad52327704f3ac5495bb0d1c61ce649b12cb36478434a")
