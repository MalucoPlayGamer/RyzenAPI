-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1467990)
addappid(1467991)
addappid(1467992)
-- Game: addappid(1467990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467993,0,"45af09308839589c9275b7493afd463397dfc71fc9f051f3ace846fd6ba0e946")
addtoken(1467990,11479786099503550857)
