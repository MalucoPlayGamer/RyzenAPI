-- Lua provided by RyzenAPI
-- Game: AppID 697650

-- MAIN APPLICATION
addappid(697650)
addappid(770950)
addappid(770951)

-- MAIN APP DEPOTS / PACKAGES
addappid(697651, 1, "1df384a77684cee9456f73953603aa677d0172f96659bc2bc4b9e338b96d08f0")

