-- Lua provided by RyzenAPI 
-- Game: AppID 903160
addappid(903160)
addappid(903161, 1, "fa020e2702d3b63e7cd5975b3b209544bad2a31e2010b29df691a3de90715d58")
addappid(912350, 0, "00265c277cf356d87db81219af2967263a4ccb9306d32ce5adea6e6bf8130110")
