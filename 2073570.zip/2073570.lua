-- Lua provided by RyzenAPI
-- Game: AppID 2073570

-- MAIN APPLICATION
addappid(2073570)
-- Game: addappid(2073570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073571, 1, "32ca08452285baeef5e0ddaffd1838f505b29ee11918806a2883a07be4c69785")
addappid(2073572, 1, "f0d00254ac8a4b7dabf4ebe34fd25beed07667ed1920601f7a95ce923c48b227")
