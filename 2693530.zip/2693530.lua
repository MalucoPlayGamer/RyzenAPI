-- Lua provided by SkyAPI 
-- Game: Witching Stone
addappid(2693530)
addappid(2693531, 1, "64664e4b41ab2c8f9a04361f9f5a56fdaeca10a9b5c1ffeb2c2b64193a20ac44")
