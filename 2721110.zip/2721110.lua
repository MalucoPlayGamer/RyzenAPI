-- Lua provided by RyzenAPI 
-- Game: AppID 2721110
addappid(2721110)
addappid(2721111, 1, "6b2cc7048f7a77ac220d9f5fce1a432136df802cbce0bf340ab87e540ee8a3c3")
