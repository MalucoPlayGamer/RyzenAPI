-- Lua provided by RyzenAPI
-- Game: Game: Crazy Foods

-- MAIN APPLICATION
addappid(1641730)
-- Game: addappid(1641730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641731, 1, "b1d46f42b5bc03758e0302cb8c4a4179ddd4ba6e9ef2cd1bc02300a6dda53b7f")
