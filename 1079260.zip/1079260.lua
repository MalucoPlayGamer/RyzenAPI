-- Lua provided by RyzenAPI
-- Game: 1079260

-- MAIN APPLICATION
addappid(1079260)
-- Game: addappid(1079260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079261, 1, "9ef012833a3fdebc10b1f390b4c16fcae877c9f4253d463fa80622a4d863af13")
