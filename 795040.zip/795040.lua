-- Lua provided by SkyAPI 
-- Game: E.Z
addappid(795040)
addappid(795041, 1, "52d8b77f48eb4c0021839f8c52f1eb931541cb0fde74cfcfdf51d35add07c81c")
