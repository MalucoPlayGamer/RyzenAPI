-- Lua provided by RyzenAPI
-- Game: 795040

-- MAIN APPLICATION
addappid(795040)
-- Game: addappid(795040)

-- MAIN APP DEPOTS / PACKAGES
addappid(795041, 1, "52d8b77f48eb4c0021839f8c52f1eb931541cb0fde74cfcfdf51d35add07c81c")
