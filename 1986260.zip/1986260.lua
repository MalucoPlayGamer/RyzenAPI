-- Lua provided by RyzenAPI
-- Game: Beautiful Mystic Survivors Demo

-- MAIN APPLICATION
addappid(1986260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986261, 1, "074e935b4e37b204844b945050d967c0ff6a7f4d4cd967a2454b3e027ac1425d")
