-- Lua provided by RyzenAPI
-- Game: 3443980

-- MAIN APPLICATION
addappid(3443980)
-- Game: addappid(3443980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443981, 1, "0db2b650d8512bd64088304c795ee16fb97f3dcc0e09ec52dd0bd98b7b163d31")
