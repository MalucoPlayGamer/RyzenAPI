-- Lua provided by RyzenAPI
-- Game: Lost in Space

-- MAIN APPLICATION
addappid(1731940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731941, 1, "5988497f113c811a9db49845589f45172413dbce6effe8bce8b033c15f24fa20")

