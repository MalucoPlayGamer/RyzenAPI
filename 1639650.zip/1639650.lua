-- Lua provided by RyzenAPI
-- Game: AppID 1639650

-- MAIN APPLICATION
addappid(1639650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639651, 1, "286b56a59dc8610396b5b02387cc3752b29de07563b2da819813283af7ec6bd1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
