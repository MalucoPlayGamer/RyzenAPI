-- Lua provided by RyzenAPI
-- Game: Game: AppID 1639650

-- MAIN APPLICATION
addappid(1639650)
-- Game: addappid(1639650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639651, 1, "286b56a59dc8610396b5b02387cc3752b29de07563b2da819813283af7ec6bd1")
