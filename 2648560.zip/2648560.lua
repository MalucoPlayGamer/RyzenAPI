-- Lua provided by RyzenAPI
-- Game: Super Retro Retry

-- MAIN APPLICATION
addappid(2648560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648561, 1, "701f4fbfac2ffffff52d2a5b6d7acdc8e3bd16f8b3cb4fcee3385cc4fbc78dd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
