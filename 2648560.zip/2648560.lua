-- Lua provided by RyzenAPI
-- Game: Super Retro Retry

-- MAIN APPLICATION
addappid(2648560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648561, 1, "701f4fbfac2ffffff52d2a5b6d7acdc8e3bd16f8b3cb4fcee3385cc4fbc78dd2")
