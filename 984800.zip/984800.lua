-- Lua provided by RyzenAPI 
-- Game: Automachef
addappid(984800)
addappid(984801, 1, "181da046ebe33aa005ccf5052b8a435074cf27aec101ef5f22fd7884ea56f74a")
addappid(1110301, 1, "a751e12dfd54b7957d6389fc55dc2715508e977297a63fd6245f171b04a28305")
addappid(1154820, 0, "2d1fedc508ce577bdc102671ae32ed9f296bbf879e19bd92ef58ce66961339a6")
