-- Lua provided by RyzenAPI
-- Game: Game: AppID 853380

-- MAIN APPLICATION
addappid(853380)
-- Game: addappid(853380)

-- MAIN APP DEPOTS / PACKAGES
addappid(853381, 1, "4dbce86041f98fd07cb93fe6a4388c771fcc985e1214d65fb3f03fbc8e414460")
