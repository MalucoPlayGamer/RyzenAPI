-- Lua provided by SkyAPI 
-- Game: CowboysShowdown
addappid(1970700)
addappid(1970701, 1, "80e3401b35899cf799896788123b67773b0b2af9c609674d39d072db65cd4878")
