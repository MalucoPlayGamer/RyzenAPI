-- Lua provided by RyzenAPI
-- Game: LastOneStanding

-- MAIN APPLICATION
addappid(2499950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2499951, 1, "bc87fd39505faf2e23b9a6f0d3bea83c34bed629c1a6d1483e554aea10f88f62")

