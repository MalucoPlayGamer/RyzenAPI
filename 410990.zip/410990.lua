-- Lua provided by RyzenAPI
-- Game: Master of Orion 3

-- MAIN APPLICATION
addappid(410990)

-- MAIN APP DEPOTS / PACKAGES
addappid(410991, 1, "bf342ebd1dea04582f0c723b8e866149bcfc3b4fe395df363e9101f63dc55383")
