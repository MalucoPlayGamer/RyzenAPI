-- Lua provided by RyzenAPI
-- Game: Ancient Wars: Sparta Definitive Edition

-- MAIN APPLICATION
addappid(1693250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693251, 1, "4ca16a1bba9f1f179dc04ecad3373e120e78dbbe06700dcfdc0fe2fd3edd7f9a")
addappid(1693253, 1, "c271e6d503bdd8125a7a78ec85f7911e91698065ad6a3242a0527190b7b79b26")
addappid(1693255, 1, "bb5008a37b22beb1a1a7c86a248b922f63e2f62e4553b5443eb3c65421dbf393")
addappid(1693259, 1, "bf0ab9e4effa63c727d88f2f059377aac22d1d91f5ba65a74aa02d1dc25b0768")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
