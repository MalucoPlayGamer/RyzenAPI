-- Lua provided by RyzenAPI
-- Game: Skotos

-- MAIN APPLICATION
addappid(1721830)
addappid(1982060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721831, 1, "c4ce29473aa0ffb8369c0ee7fe06dde1bad309e3a45af682503e519f729c8661")
