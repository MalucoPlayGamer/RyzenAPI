-- Lua provided by RyzenAPI
-- Game: addappid(3113220)

-- MAIN APPLICATION
addappid(3113220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113221, 1, "46c4294d45e11632ea715cf3bbdfd9254a1f394c9ea0feb96d377906ddb9ca53")
addappid(3113222, 1, "61ebe8ad6e2dc57d98d5399801cf4cef894ca0083a23ee0cf53c929b975374cf")
