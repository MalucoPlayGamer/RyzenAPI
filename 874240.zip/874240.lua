-- Lua provided by RyzenAPI
-- Game: MU Legend

-- MAIN APPLICATION
addappid(874240)
addappid(892810)
addappid(923850)
addappid(923851)

-- MAIN APP DEPOTS / PACKAGES
addappid(874241,0,"23e65b7d458c10bdf95ba893fdfc5d8ed657fded7a3a1d0235019f18ebc28c58")
addappid(923850,0,"ed89bfcde1b0e3fb909d83757261a3b701d7a0971156da68972fadb7c4b1e728")
addappid(923851,0,"9ee2930c0b7702c6befa672d93aa941c95ca3c26fd5988f6b95164180d6e2ba3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
