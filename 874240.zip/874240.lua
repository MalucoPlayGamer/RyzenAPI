-- Lua provided by RyzenAPI
-- Game: MU Legend

-- MAIN APPLICATION
addappid(874240)
addappid(923850)
addappid(923851)

-- MAIN APP DEPOTS / PACKAGES
addappid(874241, 1, "23e65b7d458c10bdf95ba893fdfc5d8ed657fded7a3a1d0235019f18ebc28c58")
