-- Lua provided by RyzenAPI
-- Game: MU Legend

-- MAIN APPLICATION
addappid(874240)
addappid(892810)
addappid(923850)
addappid(923851)

-- MAIN APP DEPOTS / PACKAGES
addappid(874241,0,"23e65b7d458c10bdf95ba893fdfc5d8ed657fded7a3a1d0235019f18ebc28c58")
addappid(923850,0,"ed89bfcde1b0e3fb909d83757261a3b701d7a0971156da68972fadb7c4b1e728")
addappid(923851,0,"9ee2930c0b7702c6befa672d93aa941c95ca3c26fd5988f6b95164180d6e2ba3")

