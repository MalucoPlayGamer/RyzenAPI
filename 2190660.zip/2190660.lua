-- Lua provided by RyzenAPI 
-- Game: The Unliving Soundtrack
addappid(2190660)
addappid(2190661, 1, "f7a4d690217b866644e16d95cde9fa893c6a3c0c1df6dff46804471fa7f02c60")
addappid(2190662, 1, "17f566035b511e4aebbe3664975affcc6cff1aff0f7598189ae8c2ca2e33ba9b")
