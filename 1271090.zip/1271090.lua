-- Lua provided by RyzenAPI
-- Game: Let's Cook Together

-- MAIN APPLICATION
addappid(1271090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271091, 1, "639bfda837763e69f630242c49880d575b77f1438106fa2ae99bcd5256411043")

