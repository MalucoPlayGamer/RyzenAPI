-- Lua provided by RyzenAPI
-- Game: Metal Slug: Awakening

-- MAIN APPLICATION
addappid(2963870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963871, 1, "d9d37ba599e18f1a9f535214896754232ecaebbb0438ff8516aa3d8eae599d8e")
