-- Lua provided by RyzenAPI
-- Game: addappid(1921760)

-- MAIN APPLICATION
addappid(1921760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921761, 1, "3ae4dda5c9f6a8f230ff7417fa472d8a31987557c23e658a0d4d47f0e356813b")
