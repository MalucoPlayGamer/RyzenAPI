-- Lua provided by RyzenAPI
-- Game: Consolation: Board Meeting - Anthology Edition

-- MAIN APPLICATION
addappid(1008030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008032,0,"eda938fdf01dee2c9aa993e617b7c3fa320fa1b3b865759a1fc5dcdf71535751")

