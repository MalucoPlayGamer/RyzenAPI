-- Lua provided by RyzenAPI
-- Game: AppID 649870

-- MAIN APPLICATION
addappid(649870)

-- MAIN APP DEPOTS / PACKAGES
addappid(649871, 1, "0df1df0b2b378462d3749b87de975ffff3e6cd2322ef13210e296979fea702e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
