-- Lua provided by RyzenAPI
-- Game: FootRock 2

-- MAIN APPLICATION
addappid(576740)
addappid(624960)

-- MAIN APP DEPOTS / PACKAGES
addappid(576741, 1, "7cb8cccfda8d203d533f6625d99d35c56ab501eaa83549ffacfb37e6aecee300")
