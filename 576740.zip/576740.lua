-- Lua provided by RyzenAPI
-- Game: AppID 576740

-- MAIN APPLICATION
addappid(576740)

-- MAIN APP DEPOTS / PACKAGES
addappid(576741, 1, "7cb8cccfda8d203d533f6625d99d35c56ab501eaa83549ffacfb37e6aecee300")
