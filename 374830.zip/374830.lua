-- Lua provided by RyzenAPI
-- Game: Defend The Highlands

-- MAIN APPLICATION
addappid(374830)
-- Game: addappid(374830)

-- MAIN APP DEPOTS / PACKAGES
addappid(374831, 1, "98204aa7def353c8e98f5c4dbd36420338beb8c629407b1a9ad4f9c2f7a16ed0")
addappid(374832, 1, "b492749ef29db202e5ac5eeb8e1b338c7c72b6804b01040f28e1b50a0fc2098e")
addappid(374833, 1, "863dcde419408123f869616a516fb056ca4de695398157fb8526d0b1e1772109")
