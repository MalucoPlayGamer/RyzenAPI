-- Lua provided by SkyAPI 
-- Game: Animal Shelter Demo
addappid(1657180)
addappid(1657181, 1, "1363661afee6302975f954c983a2763ff35b1429837ffce57e317ff7e03932e8")
