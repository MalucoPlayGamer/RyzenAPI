-- Lua provided by RyzenAPI
-- Game: Card Crawl Adventure

-- MAIN APPLICATION
addappid(2190260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190262,0,"118a9beec4172cdc78fc70ddfe566329d351450476a6d8b1b75ef9e36769ce95")
addappid(2190263,0,"2c96e561e219aef4dc6cfc1a3b1163609357ccd538a9e4b024324c8343998ee8")
