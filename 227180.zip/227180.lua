-- Lua provided by SkyAPI 
-- Game: AppID 227180
addappid(227180)
addappid(227181, 1, "27c067ed5e3f418455dd9449960f43df57a9579ed50d920f91f69d861b6f6ac5")
addappid(228983)
addappid(228990)
addappid(366330)
addappid(366331)
