-- Lua provided by RyzenAPI
-- Game: addappid(227180)

-- MAIN APPLICATION
addappid(227180)
addappid(228983)
addappid(228990)
addappid(366330)
addappid(366331)

-- MAIN APP DEPOTS / PACKAGES
addappid(227181, 1, "27c067ed5e3f418455dd9449960f43df57a9579ed50d920f91f69d861b6f6ac5")
