-- Lua provided by RyzenAPI
-- Game: 坦率的小红帽和爱说谎的狼

-- MAIN APPLICATION
addappid(1216080)
