-- Lua provided by RyzenAPI
-- Game: Worms Reloaded

-- MAIN APPLICATION
addappid(22600)

-- MAIN APP DEPOTS / PACKAGES
addappid(22601, 1, "3668c89cbf481cb9a0f8b9ad86fb8b3551af41f5b6b7caea6fa083df5b502fd6")
addappid(22602, 1, "01c97e869d1d831fd8931f0253c7205526663aae60f66e33dae71cf2b3053725")
addappid(22603, 1, "d670fb7756f330307438018cd068aecef07e1f65fe3d7815a4dbc9737c60122c")
addappid(22604, 1, "f1b182cde9caf6df3fcbdef5a40d31b26a185c3b78c95b45e7968990149e1ea6")
addappid(22605, 1, "d20d37e734aab39e658e4610e56eea127b4db6181af02eae15c80cfd6cea27e8")
addappid(22606, 1, "4a7a21d54e66c06c77a549747786120c5f0399492835759c2befbf8d15014872")
addappid(22607, 1, "1f52207bb996f45e2c111dcfcff95d2ad99339697df7a104c4e12ee516d1bdc9")
addappid(22608, 1, "44e7507094d101fdeb36c89e384b6a03a4d7cc202e88673e7642d4e9a4f8a9a7")
addappid(22629, 0, "790580c26db7e8f54bcaad9e42177f231b39ba8aa482a777c9a36a370010de53")
addappid(22635, 0, "a434095b2463962050fbe1e2458f273adf48e7cb6574e721493acea388ed4b63")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(22630)
addappid(22631)
addappid(22632)
addappid(22633)
addappid(22634)
addappid(22636)
addappid(22637)
addappid(22638)
addappid(22639)
