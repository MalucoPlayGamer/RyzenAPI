-- Lua provided by RyzenAPI
-- Game: DRAGON BALL XENOVERSE 3

-- MAIN APPLICATION
addappid(1857810)
-- Game: addappid(1857810)

