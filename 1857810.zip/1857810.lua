-- Lua provided by RyzenAPI
-- Game: 1857810

-- MAIN APPLICATION
addappid(1857810)

