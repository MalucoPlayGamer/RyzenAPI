-- Lua provided by RyzenAPI
-- Game: Clustertruck

-- MAIN APPLICATION
addappid(397950)
addappid(529050)
-- Game: addappid(397950)

-- MAIN APP DEPOTS / PACKAGES
addappid(397951, 1, "de9ce3a3453e17c9e0c42708f09ab4331933ba21745754536d182a0bfb194c57")
addappid(397952, 1, "92a7a241a50c36c21d18be55b3fd45dc7d533b1319438d4239dcc7d549f124f6")
addappid(397953, 1, "c083ab03aaa582199d22f2efbd6331a23bd0b8546c5bbb31631cb496c789d0eb")
addappid(397954, 1, "8d2a77f0e2e9849987bd78605e53ee19fafb62ed4122c022c0cb15fad155553f")
