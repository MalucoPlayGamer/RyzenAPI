-- Lua provided by RyzenAPI 
-- Game: Lab Remnants
addappid(1953020)
addappid(1953021, 1, "28fae40b2b9a5ae36291f0edecc03f95bcf09b28b06ba3c2d1078ff5568420c5")
