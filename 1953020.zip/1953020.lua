-- Lua provided by RyzenAPI
-- Game: Game: Lab Remnants

-- MAIN APPLICATION
addappid(1953020)
-- Game: addappid(1953020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953021, 1, "28fae40b2b9a5ae36291f0edecc03f95bcf09b28b06ba3c2d1078ff5568420c5")
