-- Lua provided by RyzenAPI
-- Game: Door Kickers: Action Squad

-- MAIN APPLICATION
addappid(686200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(686201, 1, "4468d8cca1465dfb6322cd5ceb1debae5b786f86a4ed70da09d65a7b1958993d")
addappid(1286400, 0, "5b8af095f5b118953eed88d2fbde46207eb5bd40e6eceaeda170d7416224ff25")
addappid(1788610, 0, "650172f9d8cd4a212c836859c0efba5957165939e24e920e0ba01746a1a6d358")

