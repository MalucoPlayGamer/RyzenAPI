-- Lua provided by RyzenAPI
-- Game: The Bridge Curse 2: The Extrication Demo

-- MAIN APPLICATION
addappid(2417770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417771, 1, "4cc80b19e52864271fb7272ea7114bdc2b2f1391d5cff2850c75ede1cc529f3b")
