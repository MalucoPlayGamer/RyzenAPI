-- Lua provided by RyzenAPI
-- Game: addappid(3491510)

-- MAIN APPLICATION
addappid(3491510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491516,0,"bda2432ae44fef2a0e02e52e25eb6324587dcc2e78b81b3c1cb475b9be6ee438")
