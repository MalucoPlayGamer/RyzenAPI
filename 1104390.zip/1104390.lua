-- Lua provided by RyzenAPI
-- Game: AppID 1104390

-- MAIN APPLICATION
addappid(1104390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104391, 1, "f25fe3b050eb54fd7b9e20831047b9d4fbe5da9297b461916762b10a8424e45f")
addappid(1104392, 1, "9e1f33531a3c68ee9728499434eb86e187bec95fbdbf7dea900ebd671cd5b8aa")
addappid(1104393, 1, "8e850ef53bc6d63d174e89963348f6f69c41e0eb9359c7869b639ee7c42dc131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
