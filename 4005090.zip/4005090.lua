-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Antiqua 2

-- MAIN APPLICATION
addappid(4005090)
-- Game: addappid(4005090)

-- MAIN APP DEPOTS / PACKAGES
addappid(4005091, 1, "017093db667651103f157d65c0d37985e18010385fa128ad6c9267b0595cfa22")
addappid(4005092, 1, "005d80b99ce3df56ebe81cb45d28ae61cc95220c624c485e2c122509add3bbe9")
