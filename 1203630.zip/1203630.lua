-- Lua provided by RyzenAPI
-- Game: addappid(1203630)

-- MAIN APPLICATION
addappid(1203630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203631, 1, "ba99be4ace76a1d6ff34257014a3657facf14b365807a9c6209ade4851a4fc57")
