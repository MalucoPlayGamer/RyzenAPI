-- Lua provided by RyzenAPI
-- Game: Cossacks II: Napoleonic Wars

-- MAIN APPLICATION
addappid(115200)

-- MAIN APP DEPOTS / PACKAGES
addappid(115201, 1, "2157cbe8cef1e284c94a77c91234e06c877010da7a3ef7515adaefb311fff824")
addappid(115202, 1, "0edebd5b687ecdfaac2aa51ad0d292370f502e23932a30a45aae8fa7c0ed426c")
addappid(115203, 1, "549f4a467a0a995fadc96b7816791fdd3c653d9c98c3d563bf2e131a0b53de6a")
addappid(115204, 1, "cd4e4a7832b1966b5a64285a7114861d63ce6a585632474462437ee1083e1cdf")
addappid(115205, 1, "dd47b23f89a06cee36f0dd0748dd9103a0e5715aff21a1b2c4f18c66b0edea06")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

