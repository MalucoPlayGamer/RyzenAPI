-- Lua provided by RyzenAPI
-- Game: Game: SOLAR CAGE

-- MAIN APPLICATION
addappid(1795640)
-- Game: addappid(1795640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795641, 1, "3f0446fa18f073e697b6592489a9324662d1ca83b0aba487d164f5dd328230c1")
