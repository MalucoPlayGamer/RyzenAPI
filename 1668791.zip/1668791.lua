-- Lua provided by RyzenAPI
-- Game: 1668791

-- MAIN APPLICATION
addappid(1668791)
-- Game: addappid(1668791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668791,0,"64a1081e7e6d408a166bf3cf058fd384486eef13abdcbbc477f3dec90267f5a2")
