-- Lua provided by RyzenAPI
-- Game: addappid(3839590)

-- MAIN APPLICATION
addappid(3839590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3839591, 1, "385177d41941dada4dd5653c1d6ff677bc6106bc5c0d53fe8d30084daf737f79")
