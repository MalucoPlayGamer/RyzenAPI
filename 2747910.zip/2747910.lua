-- Lua provided by RyzenAPI
-- Game: Game: Secret School Demo

-- MAIN APPLICATION
addappid(2747910)
-- Game: addappid(2747910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747911, 1, "e507727f63546fb88cf2ca94c7c997a5c4c6f674c8120ea9344357691a021d3f")
