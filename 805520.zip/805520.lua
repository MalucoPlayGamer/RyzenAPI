-- Lua provided by RyzenAPI
-- Game: addappid(805520)

-- MAIN APPLICATION
addappid(805520)

-- MAIN APP DEPOTS / PACKAGES
addappid(805521, 1, "44f27984b35b3cca566da51f1da3614042a9ca4de37ad4510d489e1b8461f7e8")
