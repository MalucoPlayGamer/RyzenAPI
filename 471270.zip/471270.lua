-- Lua provided by RyzenAPI
-- Game: Game: AppID 471270

-- MAIN APPLICATION
addappid(471270)
-- Game: addappid(471270)

-- MAIN APP DEPOTS / PACKAGES
addappid(471271, 1, "67349a9a7a1486d0cd275ab7be757c51b02e32d9ed8eaf8d9764c672d095e2fa")
