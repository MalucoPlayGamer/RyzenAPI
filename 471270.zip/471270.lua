-- Lua provided by RyzenAPI 
-- Game: AppID 471270
addappid(471270)
addappid(471271, 1, "67349a9a7a1486d0cd275ab7be757c51b02e32d9ed8eaf8d9764c672d095e2fa")
