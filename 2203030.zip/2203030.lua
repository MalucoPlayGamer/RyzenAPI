-- Lua provided by RyzenAPI
-- Game: Girl Fantasy

-- MAIN APPLICATION
addappid(2203030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203031, 1, "8d6abcc0d9a14955afee854f6371adeae98f98929b8ad8b2dd9e25217ca65e61")
addappid(2212980, 0, "b6c27b7125fad2b9cd4138e4ba13662e7ac5d9e413a140a952d35b973078a4ee")
