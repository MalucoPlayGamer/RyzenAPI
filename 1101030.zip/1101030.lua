-- Lua provided by RyzenAPI
-- Game: Noara: The Conspiracy

-- MAIN APPLICATION
addappid(1101030)
addappid(1919170)
addappid(2191740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101032,0,"760515b1844b66471808409bab20edc53130158dfdc055fb3fccd226b200c418")
addappid(1101034,0,"4add3cdaf380a98406ba1ece2e6f95e81473c3f0e5d4ff65ea31e50a78519373")

