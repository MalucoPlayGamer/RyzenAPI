-- Lua provided by RyzenAPI
-- Game: 1101030

-- MAIN APPLICATION
addappid(1101030)
-- Game: addappid(1101030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101031, 1, "a6fd7267e6aa7ee41bcd225f8e42ed41fe8054ed4a466b026ca1b1ec60d75d72")
