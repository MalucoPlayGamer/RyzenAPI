-- Lua provided by RyzenAPI
-- Game: Game: AppID 1386260

-- MAIN APPLICATION
addappid(1386260)
-- Game: addappid(1386260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386261, 1, "383313241fba51de6035c4812db78b568c19f6543592d1f2ed54377ac56d7d5e")
