-- Lua provided by RyzenAPI
-- Game: FRONT MISSION 2: Remake

-- MAIN APPLICATION
addappid(2865440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865441, 1, "482559fb2638bef793aaaf13ad2d9a3e97e41b6f6b9541970ce0dfa0e59e8f56")
