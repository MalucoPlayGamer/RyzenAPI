-- Lua provided by RyzenAPI
-- Game: 611040

-- MAIN APPLICATION
addappid(611040)
-- Game: addappid(611040)

-- MAIN APP DEPOTS / PACKAGES
addappid(611041, 1, "90bddb686f4c31fca62c00a25be0199216145d76726f915593ff182a7ad2bf8b")
addappid(611042, 1, "cf84031e34673031b5b6faff7f8044eaac0c5990e2573f029bac54aebc1ae240")
