-- Lua provided by RyzenAPI
-- Game: addappid(1291930)

-- MAIN APPLICATION
addappid(1291930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291930,0,"73efbfe8497fccd2fe0fa53699f82cd41b0b8f7d926d0bc303d337847e50d400")
