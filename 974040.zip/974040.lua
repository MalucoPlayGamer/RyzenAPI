-- Lua provided by SkyAPI 
-- Game: AppID 974040
addappid(974040)
addappid(974041, 1, "fe00857db91d57d125d3c7e218eb9f9762307d163d9af8b8c12c98727c207fac")
