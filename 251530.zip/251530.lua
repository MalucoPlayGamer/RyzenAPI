-- Lua provided by RyzenAPI
-- Game: Anomaly Korea

-- MAIN APPLICATION
addappid(251530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251531, 1, "b636c863af3f67cd1fe619c822730f1e7d0e2eb50cdbf01c95b43b5b2f2330c7")
addappid(251532, 1, "b44f60f9fcbf80fdf1221bec0d35abcddf7eb1790598afdc5f2bfd3c1ca3110d")
addappid(251533, 1, "387a35ca38e90430bea0f5c4af00e327345297877e984f64dfd8c4cecca5e8ed")

