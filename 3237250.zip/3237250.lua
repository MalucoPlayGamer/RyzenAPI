-- Lua provided by RyzenAPI
-- Game: A Sexy Tour With : Akiko

-- MAIN APPLICATION
addappid(3237250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237251, 1, "f32c6a09ef57342f631030a0f7d443b1cb54acc5fc0ade6f9958cca2bd2138d5")

