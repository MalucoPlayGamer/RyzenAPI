-- Lua provided by RyzenAPI
-- Game: addappid(1448260)

-- MAIN APPLICATION
addappid(1448260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448261, 1, "b4295e0b6f610a626f4c1db5161b5a374132551ae49e394755c2914c5dfa2ccf")
