-- Lua provided by RyzenAPI
-- Game: '83

-- MAIN APPLICATION
addappid(1059220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1059221, 1, "a7d937f812ecf7bdfee3622eb75fea1975cd8e993e085dbf13d3b002164f9a4c")
addappid(1059222, 1, "23a7676e2f0133966ec474e9e359a2f13c75f78e5b046bf618fae59e53e57940")

