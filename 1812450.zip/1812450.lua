-- Lua provided by RyzenAPI
-- Game: Bellwright

-- MAIN APPLICATION
addappid(1812450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812451, 1, "287e622ba6bcbad4ca8384750d7928d394c05c2377042af90f4d9eb474cba91a")

