-- Lua provided by RyzenAPI
-- Game: Game: Reflections of Life: Equilibrium Collector's Edition

-- MAIN APPLICATION
addappid(1075750)
-- Game: addappid(1075750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075751, 1, "6b10bc5ebf6591c71dc2d19f2495ba2ea2a80c434c78a19475c4afaa8de515f2")
