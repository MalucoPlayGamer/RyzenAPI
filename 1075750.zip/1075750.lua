-- Lua provided by SkyAPI 
-- Game: Reflections of Life: Equilibrium Collector's Edition
addappid(1075750)
addappid(1075751, 1, "6b10bc5ebf6591c71dc2d19f2495ba2ea2a80c434c78a19475c4afaa8de515f2")
