-- Lua provided by RyzenAPI
-- Game: Roundabout

-- MAIN APPLICATION
addappid(303430)
-- Game: addappid(303430)

-- MAIN APP DEPOTS / PACKAGES
addappid(303431, 1, "1b4269706ce7acad6de6073c186ded456e3d203057554e1e0f003105b92f52a9")
addappid(309920, 0, "775c4f282eed4006f7c8a45f261c5816c52d4aa0d839ed5ded5675d94d127934")
addappid(309921, 1, "df9b28f6bbd05b4c8a94a2b7598e8465a9778b3a4ae68902726cf5ddc3342507")
