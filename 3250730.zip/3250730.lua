-- Lua provided by RyzenAPI
-- Game: Paper 2 - Origami Refolded

-- MAIN APPLICATION
addappid(3250730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3250731, 1, "dc2449c3f7f34ebcf96b2e78f6a5109370279a8cb6848c26c93de8773ac19e80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
