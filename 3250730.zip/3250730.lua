-- Lua provided by RyzenAPI
-- Game: addappid(3250730)

-- MAIN APPLICATION
addappid(3250730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3250731, 1, "dc2449c3f7f34ebcf96b2e78f6a5109370279a8cb6848c26c93de8773ac19e80")
