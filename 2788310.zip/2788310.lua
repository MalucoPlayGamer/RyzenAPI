-- Lua provided by RyzenAPI
-- Game: Game: Twilight Survivors

-- MAIN APPLICATION
addappid(2788310)
-- Game: addappid(2788310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788311, 1, "8cc164865b658ab43fdfa17c84f11109c87a43d9d5d461497428635adcb63763")
