-- Lua provided by RyzenAPI
-- Game: Twilight Survivors

-- MAIN APPLICATION
addappid(2788310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2788311, 1, "8cc164865b658ab43fdfa17c84f11109c87a43d9d5d461497428635adcb63763")

