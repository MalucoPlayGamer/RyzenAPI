-- Lua provided by RyzenAPI
-- Game: The Crystal Archer Girl

-- MAIN APPLICATION
addappid(2891950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891951, 1, "c325015a78d0bf8cd7fb436f38a50cf6d1addfb06a07c5e94da845cfb0101c66")

