-- Lua provided by RyzenAPI
-- Game: Death Education

-- MAIN APPLICATION
addappid(2902270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902271, 1, "ab24592712287f43ddd4dedfc69a4797c6d23fcf2c25ffb31e65f050794f63d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
