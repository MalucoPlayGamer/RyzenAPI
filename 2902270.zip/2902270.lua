-- Lua provided by RyzenAPI
-- Game: Death Education

-- MAIN APPLICATION
addappid(2902270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902271, 1, "ab24592712287f43ddd4dedfc69a4797c6d23fcf2c25ffb31e65f050794f63d2")
