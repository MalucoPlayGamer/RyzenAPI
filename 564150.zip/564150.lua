-- Lua provided by RyzenAPI
-- Game: 564150

-- MAIN APPLICATION
addappid(564150)
-- Game: addappid(564150)

-- MAIN APP DEPOTS / PACKAGES
addappid(564151, 1, "7669abdb23a3f0107f864cf41acdfe55be196e7673320094e105a8cb87f3edd5")
addappid(564152, 1, "63ade1e9071eedef5c6e1a4b91bc4acf5a1434afbddffd6f0542fc0ef094eba3")
