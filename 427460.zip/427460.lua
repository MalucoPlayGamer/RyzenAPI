-- Lua provided by RyzenAPI 
-- Game: AppID 427460
addappid(427460)
addappid(427461, 1, "832492e3b11d528d89ad743052ec5d7477c0cb4db59545205dca43fff010ee56")
