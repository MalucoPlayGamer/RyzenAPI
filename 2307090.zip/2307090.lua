-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.4「白鷺に紅の羽」

-- MAIN APPLICATION
addappid(2307090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307091, 1, "09c31820799e227062280499dd5e26a041a991778e36dede544cb5ab79be07f0")
