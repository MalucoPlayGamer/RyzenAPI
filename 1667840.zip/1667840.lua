-- Lua provided by SkyAPI 
-- Game: Slime Story
addappid(1667840)
addappid(1667841, 1, "1c10a1b0ed64f19bbd036aac79d348548cf10848a318064908c73c80825c5f66")
