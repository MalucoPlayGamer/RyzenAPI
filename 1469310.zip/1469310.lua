-- Lua provided by RyzenAPI
-- Game: 梦幻江湖

-- MAIN APPLICATION
addappid(1469310)
-- Game: addappid(1469310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469311, 1, "d87455c96c08aedfd1d4fa58c208a6a2ac6448af23bea0f6ec9e380f7a3a8988")
