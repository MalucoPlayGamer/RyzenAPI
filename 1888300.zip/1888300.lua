-- Lua provided by RyzenAPI
-- Game: HOROS - Magnifica

-- MAIN APPLICATION
addappid(1888300)
addappid(4501770)
-- Game: addappid(1888300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888301, 1, "5cdef4abca469061c06c50521dd389de595bc156e60a49c2bc6a77f1a372caf5")
