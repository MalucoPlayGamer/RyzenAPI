-- Lua provided by RyzenAPI
-- Game: Zombieville USA 3D Demo

-- MAIN APPLICATION
addappid(3141430)
-- Game: addappid(3141430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141431, 1, "2948115627634da86278418e8e83b460f682b9c0909aa93e297ba4c2414f732f")
