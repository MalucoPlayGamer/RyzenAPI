-- Lua provided by SkyAPI 
-- Game: SWORD x HIME
addappid(1384630)
addappid(1384631, 1, "ce72ef8ddbf891aadec67833dcd27f6cccda1d2dcc919ab33e2178830533259a")
addappid(1384632, 1, "33c44122fb63024323d6f5f00ee459b9a6e95b41c764f0d21422eab418b38767")
addappid(1384633, 1, "c9d672e66e927a842b56c3c8d50978f3252a2483e50cc2de24ab5df6664158fb")
