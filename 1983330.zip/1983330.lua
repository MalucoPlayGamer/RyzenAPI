-- Lua provided by RyzenAPI
-- Game: Game: Exorcist

-- MAIN APPLICATION
addappid(1983330)
-- Game: addappid(1983330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983331, 1, "3cccc38ccd032450684664f399c74b817831845076525eedf9420547e16cba06")
