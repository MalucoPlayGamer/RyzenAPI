-- Lua provided by RyzenAPI
-- Game: Warriors of Vilvatikta

-- MAIN APPLICATION
addappid(515690)
-- Game: addappid(515690)

-- MAIN APP DEPOTS / PACKAGES
addappid(515691, 1, "f586ffddd5961676e9bd04c4931c0940067129916d63736cb65b30abf7c2ef74")
