-- Lua provided by RyzenAPI
-- Game: Lost Socks: Naughty Brothers

-- MAIN APPLICATION
addappid(501480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(501481, 1, "c3941b68ad6c3ce401a718f23686a199a91f93af854d850f21e6bc8b2f301e68")
addappid(572530, 0, "782464e8929f32875fb7770da8653100ba1a53e7491e2991091844db216979d6")

