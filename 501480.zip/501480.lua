-- Lua provided by SkyAPI 
-- Game: Lost Socks: Naughty Brothers
addappid(501480)
addappid(501481, 1, "c3941b68ad6c3ce401a718f23686a199a91f93af854d850f21e6bc8b2f301e68")
addappid(572530, 0, "782464e8929f32875fb7770da8653100ba1a53e7491e2991091844db216979d6")
