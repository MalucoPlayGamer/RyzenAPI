-- Lua provided by RyzenAPI
-- Game: addappid(1671200)

-- MAIN APPLICATION
addappid(1671200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671201, 1, "18cebce265978fc20bb293bd48613f9850a6b79cfc67ad4ed76d5f5618ab4fe4")
