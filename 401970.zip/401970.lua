-- Lua provided by RyzenAPI
-- Game: Hypatia

-- MAIN APPLICATION
addappid(401970)
addappid(926970)
addappid(968180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(401971, 1, "9650397fce052818b8dbc63eb6344fb55deb602839576ea8d3f3ac16a083493c")
addappid(401972, 1, "a403e3c1ff5bbbef6aaf16729500062c0acc61dbd171ee32ce92cfe586e05af4")

