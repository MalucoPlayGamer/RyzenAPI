-- Lua provided by RyzenAPI
-- Game: OPEN DOOR

-- MAIN APPLICATION
addappid(1771130)
addappid(4563640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1771131, 1, "a51b0fbf51aa8990d0fff0c57f234211c4e21a391ad24dd9190aad690b8b260a")

