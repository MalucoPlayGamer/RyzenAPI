-- Lua provided by RyzenAPI
-- Game: Game: openCanvas 7

-- MAIN APPLICATION
addappid(398810)
addappid(766331)
addappid(766334)
-- Game: addappid(398810)

-- MAIN APP DEPOTS / PACKAGES
addappid(398811, 1, "40a98e6e401bb452e9c495ead3f58b79e6b6bd25a861d7e0241f0e55953c24dd")
addappid(398812, 1, "b45b599c6f8a99a2b2daac9f2adaae6d4e0388b2257542e264d5dc4c4ef4ea6d")
addappid(398814, 1, "48f6de2a7f8f7cfd23bac30fd02ce9c2b408024b5250d05ecdcc9e7527a34798")
addappid(398816, 1, "0362d51718df43234b993cb1b2fcd837ef3759cef4a8e97b9ee2da0c77abbdff")
addappid(766330, 0, "8b12a8646b0043d888a46ae85f04980e54923678b703385cc36947f9bb5211a1")
addappid(766332, 0, "ecef6f173a3f604814476ad5e456019249202edd41265ecfb93bd730291658f3")
addappid(766333, 0, "36d8387570e42f6d2d00de51ad413c5a44fe00693e42c0ae9630ba250edb9c16")
addappid(766335, 0, "bf85e905b19e7ec41bffde74c59ad04ec91cdbf513440f24960f65d57f2789c2")
