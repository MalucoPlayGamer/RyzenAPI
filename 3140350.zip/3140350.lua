-- Lua provided by RyzenAPI
-- Game: AppID 3140350

-- MAIN APPLICATION
addappid(3140350)
-- Game: addappid(3140350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140351, 1, "1d3a119e1856d4ae305b7e00e64d93d00ddbdd5e85e625930cefd3c8623eb7ab")
