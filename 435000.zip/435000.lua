-- Lua provided by RyzenAPI
-- Game: The Whisperer in Darkness

-- MAIN APPLICATION
addappid(435000)

-- MAIN APP DEPOTS / PACKAGES
addappid(435002,0,"cb037a160fa1e5f6b7e0e23a6ce4bcc5d3593734a07420ed5c5cf2708cfbd10e")

