-- Lua provided by RyzenAPI
-- Game: addappid(839680)

-- MAIN APPLICATION
addappid(839680)

-- MAIN APP DEPOTS / PACKAGES
addappid(839681, 1, "e806026454bdcac8188115cae0d43a0f974b6b1e9ba829d1cc4dce4cfa8cdaff")
