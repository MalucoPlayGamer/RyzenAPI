-- Lua provided by RyzenAPI
-- Game: Game: AppID 822550

-- MAIN APPLICATION
addappid(822550)
-- Game: addappid(822550)

-- MAIN APP DEPOTS / PACKAGES
addappid(822551, 1, "9782f1d36fb6ac0b59b9407b29669f3706366841cc0d491c0148d126228b3df5")
