-- Lua provided by RyzenAPI
-- Game: Game: Love Fantasy

-- MAIN APPLICATION
addappid(1460040)
addappid(1533240)
-- Game: addappid(1460040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460041, 1, "06dd1133bbc4a68e48c36790e9542d2b3787bb418edeffb24d85b7f4c9807017")
