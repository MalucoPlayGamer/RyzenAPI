-- Lua provided by SkyAPI 
-- Game: Leningrad
addappid(1855950)
addappid(1855951, 1, "555dde2d52a85ce729cb2450aa9d60478ad869a7a63483347e11b1a580201e63")
