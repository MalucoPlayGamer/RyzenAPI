-- Lua provided by RyzenAPI
-- Game: Leningrad

-- MAIN APPLICATION
addappid(1855950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855951, 1, "555dde2d52a85ce729cb2450aa9d60478ad869a7a63483347e11b1a580201e63")
