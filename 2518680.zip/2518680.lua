-- Lua provided by RyzenAPI
-- Game: THEORY

-- MAIN APPLICATION
addappid(2518680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518681, 1, "70eb7f71fbaa4d332907646bf203938bbb88dbf4ce5ab7653418f7753443a69d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
