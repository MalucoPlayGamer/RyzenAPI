-- Lua provided by RyzenAPI
-- Game: Game: THEORY

-- MAIN APPLICATION
addappid(2518680)
-- Game: addappid(2518680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518681, 1, "70eb7f71fbaa4d332907646bf203938bbb88dbf4ce5ab7653418f7753443a69d")
