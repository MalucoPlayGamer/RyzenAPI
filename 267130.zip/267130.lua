-- Lua provided by RyzenAPI
-- Game: Star Swarm Stress Test

-- MAIN APPLICATION
addappid(267130)
-- Game: addappid(267130)

-- MAIN APP DEPOTS / PACKAGES
addappid(267131, 1, "ffbe1b39e6207aa839f6f3c56444b12b36f15144c8dabc65a1e390b74167ad31")
