-- Lua provided by RyzenAPI
-- Game: Intense! Miyu-chan and Teacher's Rock-Paper-Scissors battle!

-- MAIN APPLICATION
addappid(2799950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799951, 1, "da03935ca1f4dff9f7d8d59bbdeeb638965650907b942a1f427efa942b1a8bfa")
addappid(2799952, 1, "3908ae9cbc24c9038aaacd9baf41a005cdb06714be61841c755928d9a85443b2")
addappid(2799953, 1, "0eddf329b272d726c927aeb7ca0a22bbfb80d2b66aaa5ecacb33035589f95550")
addappid(2799954, 1, "d1ae3867a4e43b24c57bdb10a229828255ad38e43377d5ff47c4e06133100a45")

