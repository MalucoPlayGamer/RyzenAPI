-- Lua provided by RyzenAPI
-- Game: addappid(3386340)

-- MAIN APPLICATION
addappid(3386340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386341, 1, "1a72d970dbdc9b98a40c5f0ef08fd2c3563cf1687935f1d82f72b3ec9a1d7e78")
