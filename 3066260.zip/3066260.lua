-- Lua provided by RyzenAPI
-- Game: Hand Simulator: Shooter

-- MAIN APPLICATION
addappid(3066260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3066262,0,"4be0690c00a9f9bcaa89fb1b642b7323165f11f40c64eba59c24733f24ae85c6")

