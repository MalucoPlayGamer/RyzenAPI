-- Lua provided by RyzenAPI 
-- Game: AppID 1012730
addappid(1012730)
addappid(1012731, 1, "11ff2bee3172799f35ce84bf1c379663d52783f8afc45d0b79dbeac935dec22e")
