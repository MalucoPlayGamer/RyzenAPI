-- Lua provided by RyzenAPI
-- Game: Abnormal1999:Apartment of Death

-- MAIN APPLICATION
addappid(2862730)
-- Game: addappid(2862730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862731, 1, "711c5bdd06e581eecde8002d939a70038d5ea8273406bd8c453db3fdc6cd138d")
