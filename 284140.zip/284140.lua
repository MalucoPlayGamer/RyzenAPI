-- Lua provided by RyzenAPI
-- Game: Majestic Nights

-- MAIN APPLICATION
addappid(284140)
addappid(322690)

-- MAIN APP DEPOTS / PACKAGES
addappid(284141, 1, "9d60fb48f9bd9ffeea6015526aae99cb0052edc3b0a2621aacfb3c45cdb912c3")
addappid(284142, 1, "d0c6ea737c7db1fb3b6cd54c0797842a6580073def8fa4fe0e23bcbf0e27601d")
addappid(284144, 1, "ef1b7b35e85aefc8cf5f2f9dc1bb6f837e5643078272a959ec79b681b2262f4a")
addappid(327460, 1, "9c4d120d3595bc8b8fd32bf679515b495c5dd8e2d799c3a3c43299a1cf80bc0c")
addappid(327461, 1, "188ed3d533b49a2635154beee21afd88f80bd7544ef9a41bebcd004944dc44c0")
addappid(330430, 1, "f440978b453da97fa3dcb3e08616a7adcbf6a0e0a84ecbc0ae9295c24425aa04")
addappid(330440, 1, "1cca3b2638ed72edb96b1f4033d19f77ece7910de1eea9f807f285c9a5ed6987")
addappid(332110, 1, "30e7a8b391bb153ad4e14161862ad25a20754af5d4763f06082774e256a76ee6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
