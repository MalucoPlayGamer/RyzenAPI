-- Lua provided by RyzenAPI
-- Game: addappid(1110631)

-- MAIN APPLICATION
addappid(1110631)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110631,0,"95c70569c245415ff1db5b827bd8bba7819b4f6f7baaadf92c0635e6382449ee")
