-- Lua provided by SkyAPI 
-- Game: AppID 647500
addappid(647500)
addappid(647501, 1, "6663963383c96641c8bcc214bf783733c21ccc1849d0d38c8958f66953ac2785")
