-- Lua provided by RyzenAPI
-- Game: Near Death Experience

-- MAIN APPLICATION
addappid(647500)
-- Game: addappid(647500)

-- MAIN APP DEPOTS / PACKAGES
addappid(647501, 1, "6663963383c96641c8bcc214bf783733c21ccc1849d0d38c8958f66953ac2785")
