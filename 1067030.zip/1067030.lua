-- Lua provided by SkyAPI 
-- Game: AppID 1067030
addappid(1067030)
addappid(1067031, 1, "d339facbd4a82f9a53fa5d188c3f818974ed49b27c782d39c11b578d274eb7d4")
