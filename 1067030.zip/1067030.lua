-- Lua provided by RyzenAPI
-- Game: AppID 1067030

-- MAIN APPLICATION
addappid(1067030)
-- Game: addappid(1067030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067031, 1, "d339facbd4a82f9a53fa5d188c3f818974ed49b27c782d39c11b578d274eb7d4")
