-- Lua provided by RyzenAPI
-- Game: CosmicBreak Universal

-- MAIN APPLICATION
addappid(1140620)

