-- Lua provided by RyzenAPI
-- Game: CosmicBreak Universal

-- MAIN APPLICATION
addappid(1140620)
addappid(1851980)
addappid(1952130)
addappid(1998560)
addappid(2068870)
addappid(2170930)
addappid(2287740)
addappid(2505390)
addappid(2505410)
addappid(2680160)

