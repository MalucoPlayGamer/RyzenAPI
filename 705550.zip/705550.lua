-- Lua provided by RyzenAPI
-- Game: 705550

-- MAIN APPLICATION
addappid(705550)
-- Game: addappid(705550)

-- MAIN APP DEPOTS / PACKAGES
addappid(705551, 1, "a4a03b03c6088a8486f096888fc8b2be24fe17f309ce209464d597f6fded7999")
