-- Lua provided by RyzenAPI
-- Game: Russian Train Trip 3

-- MAIN APPLICATION
addappid(2405740)
addappid(2522540)
addappid(2525280)
addappid(2525370)
addappid(2525470)
addappid(2526640)
addappid(2526650)
addappid(2526930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2405741, 1, "ae6bfc438574f7e4e874269a66f2920fa471fe5bd2c72115d606f22b8f62ca3e")

