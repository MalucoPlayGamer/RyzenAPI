-- Lua provided by RyzenAPI 
-- Game: Russian Train Trip 3
addappid(2405740)
addappid(2405741, 1, "ae6bfc438574f7e4e874269a66f2920fa471fe5bd2c72115d606f22b8f62ca3e")
