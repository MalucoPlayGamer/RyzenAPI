-- Lua provided by RyzenAPI
-- Game: Game: Russian Train Trip 3

-- MAIN APPLICATION
addappid(2405740)
-- Game: addappid(2405740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405741, 1, "ae6bfc438574f7e4e874269a66f2920fa471fe5bd2c72115d606f22b8f62ca3e")
