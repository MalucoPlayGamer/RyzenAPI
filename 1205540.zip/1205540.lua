-- Lua provided by RyzenAPI
-- Game: Shmup Arena

-- MAIN APPLICATION
addappid(1205540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205541, 1, "65ec0b0753ce372c66aee2e59bcc26681ecd58b672bc5afd74861328d6d654ac")
