-- Lua provided by RyzenAPI
-- Game: AppID 1229270

-- MAIN APPLICATION
addappid(1229270)
-- Game: addappid(1229270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229271, 1, "a52d45a993058f3cf2e5300bef20957689ee7823ca38f6fc5f31020927c4da2d")
