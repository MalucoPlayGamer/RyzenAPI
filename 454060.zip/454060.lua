-- Lua provided by RyzenAPI 
-- Game: AppID 454060
addappid(454060)
addappid(454061, 1, "907543d8c9514722f4e005d9bc890ce3840deb163fcfd75233b642f23b804a82")
addappid(454062, 1, "73aae8f41dc1d45b3bbea3dbde1ac6a3177141c6200c17511d478c4f254e57b3")
addappid(454063, 1, "2754abba6c0f9db426847a2fe26c6b73cdb47ad5b5d8511a3cb2c9902b1efa6d")
