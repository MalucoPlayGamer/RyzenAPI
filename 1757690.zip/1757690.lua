-- Lua provided by RyzenAPI
-- Game: Haunted Hell House

-- MAIN APPLICATION
addappid(1757690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757691, 1, "9202c8fc8e9ed705b2be1b895d5458c227a0658d6933ae2607d6bbad080f64fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
