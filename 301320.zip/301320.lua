-- Lua provided by RyzenAPI
-- Game: NoLimits 2 Roller Coaster Simulation

-- MAIN APPLICATION
addappid(301320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(301321, 1, "39116189658e36eedc227dea0a8dc51c08f2b29b26e3398579e88ac74dd7f486")
addappid(301322, 1, "40f7c0a0fbb9f9f869241ae593c4841d116dac8d20becdbc041cae33357f585c")
addappid(301324, 1, "9786d7dbcd7d03b8599b391d738f6ee731cede94feaa0a475c082121cc1be9ff")
addappid(301326, 1, "ab7ae529b7042ff2ef6a5186df0a324e2b1af2d27fc5e4840cf8b2ad13e594d9")
addappid(305170, 0, "ee7ae6fed252650029a2090bc246e80b36524de0c254c2f65a3089b9a5eac0d9")
addappid(2539050, 0, "9ffdadc8680eebc72ce24a876f3f5ff984ded478463e9b4b0d450003eb7ba0b6")

