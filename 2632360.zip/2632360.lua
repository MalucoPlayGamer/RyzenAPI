-- Lua provided by RyzenAPI 
-- Game: Beer Strip
addappid(2632360)
addappid(2632361, 1, "408c6d7f2f44659d8788502e97b7722522a6a55648afde0d82b13634f6787186")
addappid(2632362, 1, "9a208568342963221af6c7263d3bda1fd2b6f4dfa48b290c0e0a7d188f5c45be")
