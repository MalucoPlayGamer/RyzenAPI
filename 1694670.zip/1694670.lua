-- Lua provided by RyzenAPI
-- Game: Apotheorasis • Lab of the Blind Gods

-- MAIN APPLICATION
addappid(1694670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694671, 1, "9e796c8e67000ba871fedf8056b9c4ffe92cc8b9ba781f1a315a06a0aa693945")
