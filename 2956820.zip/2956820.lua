-- Lua provided by RyzenAPI
-- Game: addappid(2956820)

-- MAIN APPLICATION
addappid(2956820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956821, 1, "d85f0965b6ceadca1d4c00a1d750c5c8374707418384253a53c980d98ad7b3bd")
