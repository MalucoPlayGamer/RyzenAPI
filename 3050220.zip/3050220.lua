-- Lua provided by RyzenAPI
-- Game: 3050220

-- MAIN APPLICATION
addappid(3050220)
-- Game: addappid(3050220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050221, 1, "ce82976ac100fcb11681d16de899309652c7d66f55a1be142470d3c3a44a22f2")
