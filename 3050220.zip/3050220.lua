-- Lua provided by RyzenAPI
-- Game: THE KING OF FIGHTERS XIII GLOBAL MATCH

-- MAIN APPLICATION
addappid(3050220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050221, 1, "ce82976ac100fcb11681d16de899309652c7d66f55a1be142470d3c3a44a22f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
