-- Lua provided by RyzenAPI
-- Game: Ancestors Legacy Free Peasant Edition

-- MAIN APPLICATION
addappid(720380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(720381, 1, "d8227ba7326156ae22e315f734ecddaf47b8c57c2193045875e20dcd0a3af0b0")

