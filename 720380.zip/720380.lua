-- Lua provided by RyzenAPI
-- Game: Game: Ancestors Legacy Free Peasant Edition

-- MAIN APPLICATION
addappid(720380)
-- Game: addappid(720380)

-- MAIN APP DEPOTS / PACKAGES
addappid(720381, 1, "d8227ba7326156ae22e315f734ecddaf47b8c57c2193045875e20dcd0a3af0b0")
