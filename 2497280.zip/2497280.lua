-- Lua provided by RyzenAPI
-- Game: addappid(2497280)

-- MAIN APPLICATION
addappid(2497280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497281, 1, "d6b540d31caf1ed9f9284f9eb2b8f13d1801d36b019f823d10d38734c0e098bd")
addappid(2538080, 0, "a78db132007f6b7e9ad4553bd7c67c7c3481c56df93f44ecad82982e89b9efd3")
