-- 4898750's Lua and Manifest Created by Hubcap Manifest
-- Harvest Deadline
-- Created: August 24, 2026 at 15:07:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4898750) -- Harvest Deadline
-- MAIN APP DEPOTS
addappid(4898751, 1, "b3dcf3b44993e0386afbf468e43cd6dfedea7ed82dd0bc305fb03b76aff1f466") -- Depot 4898751
setManifestid(4898751, "7006273696681648131", 546339687)