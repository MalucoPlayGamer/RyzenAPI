-- Lua provided by RyzenAPI
-- Game: Harvest Deadline

-- MAIN APPLICATION
addappid(4898750) -- Harvest Deadline

-- MAIN APP DEPOTS / PACKAGES
addappid(4898751, 1, "b3dcf3b44993e0386afbf468e43cd6dfedea7ed82dd0bc305fb03b76aff1f466") -- Depot 4898751

