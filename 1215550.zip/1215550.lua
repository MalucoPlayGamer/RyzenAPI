-- Lua provided by RyzenAPI
-- Game: Game: AppID 1215550

-- MAIN APPLICATION
addappid(1215550)
-- Game: addappid(1215550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215551, 1, "06487509eabb4560424693e3cc9ff27109b58bbd736ea3d1202e397514427cef")
