-- Lua provided by RyzenAPI
-- Game: Planetary Annihilation: TITANS

-- MAIN APPLICATION
addappid(386070)

-- MAIN APP DEPOTS / PACKAGES
addappid(386071, 1, "6c0a8f44035b5cc530870da7203e593924817ee6e29398c5cb1402121c75cd30")
addappid(386072, 1, "797f31c15a6d3044afc9e27d5b23cac73cb71b51b38a24dc33010e1b71f02f10")
addappid(386073, 1, "600fe1fe56dba345ffd6c99f073bca9cb789f504381848aaf9a8a300fb7ddcc6")
addappid(386074, 1, "62e39b8a0bef75660759bacc905ed99c0e1aa35e8520225272846be0b0941754")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(395000)
