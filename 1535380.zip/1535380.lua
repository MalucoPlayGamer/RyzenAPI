-- Lua provided by RyzenAPI
-- Game: Game: Minute of Islands - Soundtrack

-- MAIN APPLICATION
addappid(1535380)
-- Game: addappid(1535380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535381, 1, "269ef5724775ec8cd72c80da55738199984ea12b57d9321880749c89fc88a0c0")
addappid(1535382, 1, "ff2119e36631787d12807442ab764cc03bdab704dce80aea20cf0c7fbe5cac83")
