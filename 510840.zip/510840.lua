-- Lua provided by RyzenAPI
-- Game: Evolvation

-- MAIN APPLICATION
addappid(510840)
addappid(961160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(510841, 1, "184671c131437b37a00c49824c4af7096b98e13957fad1543f0da315a77e8824")
addappid(510842, 1, "f744674412928d90eef9be2e6047c570730747b8311b1e9b1ed20ed0cf52bae6")
addappid(510843, 1, "3a766ebe157b37d85ee72a5b7a97df1f3ef7f76dfb50e56de05957ee5f43db50")

