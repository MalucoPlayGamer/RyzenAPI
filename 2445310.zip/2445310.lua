-- Lua provided by RyzenAPI
-- Game: AppID 2445310

-- MAIN APPLICATION
addappid(2445310)
-- Game: addappid(2445310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445311, 1, "b9440d817cd126cdad734f7f4535f3d963a2e2a298468b2224ff55b443d335ab")
