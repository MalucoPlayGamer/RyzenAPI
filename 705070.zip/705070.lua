-- Lua provided by RyzenAPI
-- Game: FEMINAZI: 3000

-- MAIN APPLICATION
addappid(705070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(705071, 1, "85babf2982b1896b0c7c773dd10254fd04f7c74d032b9e8248ca1dfc99a4d30d")
