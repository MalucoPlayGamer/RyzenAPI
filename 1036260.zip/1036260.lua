-- Lua provided by RyzenAPI
-- Game: Journey For Elysium

-- MAIN APPLICATION
addappid(1036260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036261, 1, "b310dbbc8331a613a023900f320db5f4cc8c11175733417066d594e50666a181")
