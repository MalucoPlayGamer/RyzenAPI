-- Lua provided by RyzenAPI
-- Game: The Touryst

-- MAIN APPLICATION
addappid(1796410)
-- Game: addappid(1796410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796411, 1, "983251694858c98f4d57cb865eb68adeabd21bb0446471933e12591ce604fbf6")
