-- Lua provided by RyzenAPI
-- Game: The Touryst

-- MAIN APPLICATION
addappid(1796410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1796411, 1, "983251694858c98f4d57cb865eb68adeabd21bb0446471933e12591ce604fbf6")

