-- Lua provided by SkyAPI 
-- Game: The Touryst
addappid(1796410)
addappid(1796411, 1, "983251694858c98f4d57cb865eb68adeabd21bb0446471933e12591ce604fbf6")
