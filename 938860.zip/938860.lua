-- Lua provided by RyzenAPI
-- Game: Get In The Car, Loser!

-- MAIN APPLICATION
addappid(938860)
addappid(1733360)
addappid(1759520)

-- MAIN APP DEPOTS / PACKAGES
addappid(938861, 1, "e74caabc6832513d8359576467a7fdaa7e854d7ea735cc74ba66df1580d00ce1")

