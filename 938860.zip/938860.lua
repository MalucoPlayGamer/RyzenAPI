-- Lua provided by RyzenAPI
-- Game: Game: Get In The Car, Loser!

-- MAIN APPLICATION
addappid(938860)
-- Game: addappid(938860)

-- MAIN APP DEPOTS / PACKAGES
addappid(938861, 1, "e74caabc6832513d8359576467a7fdaa7e854d7ea735cc74ba66df1580d00ce1")
