-- Lua provided by RyzenAPI
-- Game: 803980

-- MAIN APPLICATION
addappid(803980)
-- Game: addappid(803980)

-- MAIN APP DEPOTS / PACKAGES
addappid(803981, 1, "324b41c00ff2d29ffc2be4fa964a21513194a806a1a58901a5fd9553ffaba959")
