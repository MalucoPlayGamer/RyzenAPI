-- Lua provided by RyzenAPI 
-- Game: Plane Mechanic Simulator
addappid(803980)
addappid(803981, 1, "324b41c00ff2d29ffc2be4fa964a21513194a806a1a58901a5fd9553ffaba959")
