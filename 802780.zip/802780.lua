-- Lua provided by RyzenAPI
-- Game: addappid(802780)

-- MAIN APPLICATION
addappid(802780)

-- MAIN APP DEPOTS / PACKAGES
addappid(802781, 1, "e3270632b22d7b3f0f145a339489711755512f44b7eff2dfb569c6a9dc6fd63f")
