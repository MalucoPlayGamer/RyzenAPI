-- Lua provided by SkyAPI 
-- Game: 【NekoGakuen】《MatthiolaReverieVerse:LostIsland》
addappid(618420)
addappid(618421, 1, "6ed1961a53b6032efa2a8eadd8927e26db2f7ab1865d8ea957071de78c4fc2b0")
addappid(618422, 1, "d3b637162e6f1c09c186186783e5f9e9159cdf0ba1f90bd9d596a07ad089c0f0")
