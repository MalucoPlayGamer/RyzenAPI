-- Lua provided by RyzenAPI
-- Game: The Tower Stories Green 1 Demo

-- MAIN APPLICATION
addappid(2821080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821081, 1, "ff072cdfdc35fe022d801b700eecb8ff23174f4710f986333da5098fdc733405")
