-- Lua provided by RyzenAPI
-- Game: 2821080

-- MAIN APPLICATION
addappid(2821080)
-- Game: addappid(2821080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821081, 1, "ff072cdfdc35fe022d801b700eecb8ff23174f4710f986333da5098fdc733405")
