-- Lua provided by RyzenAPI
-- Game: Dances and Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1455320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455320,0,"a724a91af6b0275873090010458a8245a3020b53a14489f4916e624cd49f717d")

