-- Lua provided by RyzenAPI
-- Game: Cleaning The World With Pampam

-- MAIN APPLICATION
addappid(2056310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056311, 1, "273bcabdc81d76446dc4ea4f8465ae3b5b5be44106576f727a726d9566f57c2c")

