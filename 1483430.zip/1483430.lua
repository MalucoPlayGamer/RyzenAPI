-- Lua provided by RyzenAPI
-- Game: addappid(1483430)

-- MAIN APPLICATION
addappid(1483430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483431, 1, "ddca7c2b849f6a0cf10d34cd9634aa9ce38469f990be45785f1108a0883761b6")
