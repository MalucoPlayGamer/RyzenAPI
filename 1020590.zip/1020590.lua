-- Lua provided by RyzenAPI 
-- Game: Space Pilgrim Academy: Reunion
addappid(1020590)
addappid(1020591, 1, "ea1cf1ab24fee5e5c85c1f087be88434d7f5b7e3d88d2183d35352c29e85ef18")
