-- Lua provided by RyzenAPI
-- Game: Game: Space Pilgrim Academy: Reunion

-- MAIN APPLICATION
addappid(1020590)
-- Game: addappid(1020590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020591, 1, "ea1cf1ab24fee5e5c85c1f087be88434d7f5b7e3d88d2183d35352c29e85ef18")
