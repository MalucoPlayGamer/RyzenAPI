-- Lua provided by SkyAPI 
-- Game: The forgotten phobia
addappid(1743810)
addappid(1743811, 1, "0e8ce1ef8c8b66b93451e223a6f021dbc3799921a3b54bd4bd1e0e387abe066f")
