-- Lua provided by RyzenAPI
-- Game: Omen Fall

-- MAIN APPLICATION
addappid(1745050)
-- Game: addappid(1745050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745052,0,"78c6e729114406b71db2a463bf009848d0dd5c2eacd76f32ce6fa723eb899b2f")
