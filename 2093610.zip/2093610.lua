-- Lua provided by RyzenAPI
-- Game: Game: AppID 2093610

-- MAIN APPLICATION
addappid(2093610)
-- Game: addappid(2093610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093611, 1, "2d3bcbcc2a0fb617542ae814939d3649d16f44a237325068ab0afc4d58c5e09c")
