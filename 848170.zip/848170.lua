-- Lua provided by RyzenAPI
-- Game: Movavi Video Converter Premium 18

-- MAIN APPLICATION
addappid(848170)

-- MAIN APP DEPOTS / PACKAGES
addappid(848171, 1, "700c6d9460a9be36df9f4487e329ac04ee4cd056950d7462e7312830a3f8ffeb")

