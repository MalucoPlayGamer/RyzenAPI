-- Lua provided by SkyAPI 
-- Game: AppID 788470
addappid(788470)
addappid(788471, 1, "dfe06d3b07d27eb364935368c92bf38670ecadbfb40bbdee93997a40d2f9b484")
