-- Lua provided by RyzenAPI
-- Game: addappid(788470)

-- MAIN APPLICATION
addappid(788470)

-- MAIN APP DEPOTS / PACKAGES
addappid(788471, 1, "dfe06d3b07d27eb364935368c92bf38670ecadbfb40bbdee93997a40d2f9b484")
