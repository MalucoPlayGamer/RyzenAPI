-- Lua provided by RyzenAPI
-- Game: Midnight Witch Starlight

-- MAIN APPLICATION
addappid(2539420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2539421, 1, "10694fc99b31a1d38fcf581a8e5dbee387f2754b133857f5d6bc3699cfd6ef56")

