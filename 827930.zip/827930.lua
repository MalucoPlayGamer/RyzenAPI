-- Lua provided by SkyAPI 
-- Game: Strive
addappid(827930)
addappid(827931, 1, "83f66eec06559256af2a3729ccf79d29e03dd90479f0251711199636bb9e4f70")
