-- Lua provided by RyzenAPI
-- Game: Game: Strive

-- MAIN APPLICATION
addappid(827930)
-- Game: addappid(827930)

-- MAIN APP DEPOTS / PACKAGES
addappid(827931, 1, "83f66eec06559256af2a3729ccf79d29e03dd90479f0251711199636bb9e4f70")
