-- Lua provided by RyzenAPI
-- Game: 1579880

-- MAIN APPLICATION
addappid(1579880)
-- Game: addappid(1579880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579881, 1, "a814880fd9143fa3d8cca2b9adfc9abf607385b172ca28019931277fed04d287")
