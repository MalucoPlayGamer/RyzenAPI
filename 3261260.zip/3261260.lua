-- Lua provided by RyzenAPI
-- Game: Game: Two Falls (Nishu Takuatshina) Demo

-- MAIN APPLICATION
addappid(3261260)
-- Game: addappid(3261260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261261, 1, "0c8249455d9b2c533ff87b24500717afa8a47cf9fe04fb29c3c0bdab55f5a440")
