-- Lua provided by RyzenAPI
-- Game: 298790

-- MAIN APPLICATION
addappid(298790)
-- Game: addappid(298790)

-- MAIN APP DEPOTS / PACKAGES
addappid(298791, 1, "45081cc0d06b4369bc3e50666a705c31c2d6f71614dfaf8a4ba68bfef91e1815")
