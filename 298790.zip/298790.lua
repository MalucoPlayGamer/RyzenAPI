-- Lua provided by RyzenAPI
-- Game: AppID 298790

-- MAIN APPLICATION
addappid(298790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(298791, 1, "45081cc0d06b4369bc3e50666a705c31c2d6f71614dfaf8a4ba68bfef91e1815")

