-- Lua provided by RyzenAPI
-- Game: Decarnation Soundtrack - Rêve

-- MAIN APPLICATION
addappid(2445860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445861, 1, "c6a1b80252b0065d272ebb40681616c6aba2b0f4fc247c5cd29c1182f0c2e369")
