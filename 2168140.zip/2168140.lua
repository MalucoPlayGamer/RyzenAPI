-- Lua provided by RyzenAPI
-- Game: Game: Picayune Dreams Demo

-- MAIN APPLICATION
addappid(2168140)
-- Game: addappid(2168140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168141, 1, "547862aeadd3e1223d7e99d3f7dd569eed23b0c5ce8c8132d96fbb1d11ae9049")
