-- Lua provided by RyzenAPI
-- Game: Game: Amazing Frog? 2

-- MAIN APPLICATION
addappid(1559680)
-- Game: addappid(1559680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559681, 1, "274a5cc627fe54c61daf8e1c089fc62ea53d53af956d035a58954c7b29547de0")
addappid(1559682, 1, "bd324a3eba603f0e521137580660afe5afc50023b3be624ada2164da28abb35e")
