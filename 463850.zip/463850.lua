-- Lua provided by RyzenAPI
-- Game: addappid(463850)

-- MAIN APPLICATION
addappid(463850)

-- MAIN APP DEPOTS / PACKAGES
addappid(463851, 1, "d4509cad694b250130cfce14d18dee45971310d1b409126c7a11cf428ed59b3d")
