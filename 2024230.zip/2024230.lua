-- Lua provided by RyzenAPI
-- Game: Project Lazarus

-- MAIN APPLICATION
addappid(2024230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024231, 1, "b11e3ede6bfb693832059702668c9ea2a5558c1458c2d37e4af7f439bbc11164")
