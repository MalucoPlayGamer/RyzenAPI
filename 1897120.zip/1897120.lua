-- Lua provided by RyzenAPI
-- Game: 幸福的二人房

-- MAIN APPLICATION
addappid(1897120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897121, 1, "b55056806cd1d9ee4f5b9cb6760a7488028681e4c9e7894ea3971f7ce3589f17")
addappid(1897122, 1, "c90aab7a426acef9a6d7713d10692a2777f7d7f2646396f27cecc1e8ae2fbeff")
