-- Lua provided by RyzenAPI
-- Game: 沙盒启示录 Sandbox Revelation Demo

-- MAIN APPLICATION
addappid(2359680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359681, 1, "299d3706006a4f8f0d748597747091d8cf28fae3333ed21e30ddfd4c6f902000")

