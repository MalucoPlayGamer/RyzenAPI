-- Lua provided by RyzenAPI
-- Game: Etaria | Survival Adventure

-- MAIN APPLICATION
addappid(423920)

-- MAIN APP DEPOTS / PACKAGES
addappid(423921, 1, "38f14038d4b08c145b69ecc2d5bf21d8addda870f99a90d4d6c403f907b37e0e")

