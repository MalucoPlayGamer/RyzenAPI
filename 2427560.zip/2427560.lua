-- Lua provided by RyzenAPI
-- Game: 2427560

-- MAIN APPLICATION
addappid(2427560)
-- Game: addappid(2427560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427561, 1, "e9e3502fa33b987a966975b34e65bc6c7ac9843f2fe767cdbf198a2c789b4007")
