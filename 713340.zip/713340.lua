-- Lua provided by RyzenAPI
-- Game: Space Ship Commander

-- MAIN APPLICATION
addappid(713340)

-- MAIN APP DEPOTS / PACKAGES
addappid(713341, 1, "c2bd3db78149629ffa078a7f2d249f2f917ca8e9dce10feaf0eee396fb7f8346")

