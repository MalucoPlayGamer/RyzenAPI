-- Lua provided by RyzenAPI
-- Game: Naughty Nate : Cosplay

-- MAIN APPLICATION
addappid(3100190)
-- Game: addappid(3100190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100191, 1, "2b33a613d750d38f11b5c1d2803221f18437fa5a7ea67cccd09d817ec50765f0")
