-- Lua provided by RyzenAPI
-- Game: 1045290

-- MAIN APPLICATION
addappid(1045290)
-- Game: addappid(1045290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045290,0,"65d0cef71b2232c62d23a63236472ebf537a6880d2b4dca4d8f42eec80bfcf91")
