-- Lua provided by RyzenAPI 
-- Game: Once Human
addappid(2139460)
addappid(2139461, 1, "78a785be75b7bf5ace231ff22287308bed5800f9afecb4b545a180f7f00b9c11")
addappid(2139463, 1, "ad7c624324a12728521ce39b4e13e9a9bd4df554bc77e25484ade5072f77615e")
