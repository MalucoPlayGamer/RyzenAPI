-- Lua provided by RyzenAPI
-- Game: AENTITY

-- MAIN APPLICATION
addappid(536690)

-- MAIN APP DEPOTS / PACKAGES
addappid(536691, 1, "98235e29d8ffe483bfaaea85e2140dfdce0dd31a2d9e0af20c0acd950dc054c4")

