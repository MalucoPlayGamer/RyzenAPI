-- Lua provided by RyzenAPI
-- Game: Airmen

-- MAIN APPLICATION
addappid(647740)

-- MAIN APP DEPOTS / PACKAGES
addappid(647741,0,"5125447bc900bc2a273bc5491d28fd8eba2e3b2506cf37ee36e6560ae7fb06cb")

