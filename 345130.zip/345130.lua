-- Lua provided by RyzenAPI
-- Game: 345130

-- MAIN APPLICATION
addappid(345130)
-- Game: addappid(345130)

-- MAIN APP DEPOTS / PACKAGES
addappid(345131, 1, "98932869857b85dffc80b600e008065546b9149e50149cdec1059b628ace7d0b")
