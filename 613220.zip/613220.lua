-- Lua provided by SkyAPI 
-- Game: Steam 360 Video Player
addappid(613220)
addappid(613221, 1, "ffde17bd17b9b5b23cda51a04b7a914cf43fc258933be028db4d57676c68d06b")
