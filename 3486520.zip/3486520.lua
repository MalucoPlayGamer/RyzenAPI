-- Lua provided by RyzenAPI
-- Game: Isle Frontier

-- MAIN APPLICATION
addappid(3486520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486521, 1, "2e3fb8499308462b6a5c2ffafac3bedaaa653bd8bdf1b2d34e0623a89275dc6e")

