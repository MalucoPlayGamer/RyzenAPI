-- Lua provided by RyzenAPI
-- Game: addappid(2533110)

-- MAIN APPLICATION
addappid(2533110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533111, 1, "5afc1c8fd2e7818bcfb2330801e6f64573e80702b4a3e635d8b46ae0179b58b6")
addappid(2533112, 1, "ab034ce7f6c71ce36a5a3045d12baf87213dfceb6c88adf635057b1aec67f862")
