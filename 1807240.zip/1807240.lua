-- Lua provided by RyzenAPI
-- Game: Casual Pixel Warrior

-- MAIN APPLICATION
addappid(1807240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1807241, 1, "d1c230cd6cd37b1a4bfb62bc7c9ed0c9bed19a8dbcac2c2b1f4e138a68c902c0")

