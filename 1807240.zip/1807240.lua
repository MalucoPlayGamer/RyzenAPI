-- Lua provided by RyzenAPI
-- Game: Casual Pixel Warrior

-- MAIN APPLICATION
addappid(1807240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807241, 1, "d1c230cd6cd37b1a4bfb62bc7c9ed0c9bed19a8dbcac2c2b1f4e138a68c902c0")

