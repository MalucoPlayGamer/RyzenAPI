-- Lua provided by RyzenAPI
-- Game: Cute Suika: Big Watermelon

-- MAIN APPLICATION
addappid(2740000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740001, 1, "abb5fddae68f6ae4b5e38bd3150323ec0999d0e84e11ffa57a812a5adb48f7b5")

