-- Lua provided by RyzenAPI
-- Game: 1043610

-- MAIN APPLICATION
addappid(1043610)
-- Game: addappid(1043610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043611, 1, "1aecc18563a33ed8395aa0715fc00e7994c7d76b73004c4cf8858bd0c2e3910f")
