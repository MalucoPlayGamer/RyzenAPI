-- Lua provided by RyzenAPI
-- Game: setManifestid(910593,"5694805986333915888")

-- MAIN APPLICATION
addappid(910590)
-- Game: addappid(910590)

-- MAIN APP DEPOTS / PACKAGES
addappid(910593,0,"7a32724bb321e9f50c59de5f3fd8f9c9c6fe5ecb694519695a1b742febe0754f")
