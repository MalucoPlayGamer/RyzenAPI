-- Lua provided by RyzenAPI
-- Game: Supaplex SQUARES

-- MAIN APPLICATION
addappid(910590)

-- MAIN APP DEPOTS / PACKAGES
addappid(910593,0,"7a32724bb321e9f50c59de5f3fd8f9c9c6fe5ecb694519695a1b742febe0754f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
