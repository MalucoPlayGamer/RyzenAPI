-- Lua provided by RyzenAPI
-- Game: 1199210

-- MAIN APPLICATION
addappid(1199210)
-- Game: addappid(1199210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199210,0,"6f74b5c3afe3b7bbbf8ffd18b1ceca9d7c1fcdc1badc30ec73f2a0aaeb32dfcc")
