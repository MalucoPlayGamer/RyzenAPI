-- Lua provided by RyzenAPI
-- Game: Superior: Vengeance

-- MAIN APPLICATION
addappid(1297490)
addappid(2634040)
-- Game: addappid(1297490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297491, 1, "7a240302efce7a0c6f4e1836ecfcdc1e2456daf496c21419bc594ae8cd3eb7e3")
