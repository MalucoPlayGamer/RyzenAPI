-- Lua provided by RyzenAPI
-- Game: Superior: Vengeance

-- MAIN APPLICATION
addappid(1297490)
addappid(2634040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297491, 1, "7a240302efce7a0c6f4e1836ecfcdc1e2456daf496c21419bc594ae8cd3eb7e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
