-- Lua provided by RyzenAPI
-- Game: addappid(722730)

-- MAIN APPLICATION
addappid(722730)

-- MAIN APP DEPOTS / PACKAGES
addappid(722731, 1, "25240df3d4d832044a0c94e601dae06dd0fa0a10316cbbc20711eb4befae1f9a")
