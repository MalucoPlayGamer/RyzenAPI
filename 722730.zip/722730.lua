-- Lua provided by RyzenAPI
-- Game: Cogmind

-- MAIN APPLICATION
addappid(722730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(722731, 1, "25240df3d4d832044a0c94e601dae06dd0fa0a10316cbbc20711eb4befae1f9a")

