-- Lua provided by SkyAPI 
-- Game: Cogmind
addappid(722730)
addappid(722731, 1, "25240df3d4d832044a0c94e601dae06dd0fa0a10316cbbc20711eb4befae1f9a")
