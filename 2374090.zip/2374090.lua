-- Lua provided by SkyAPI 
-- Game: Asterix & Obelix: Heroes
addappid(2374090)
addappid(2374091, 1, "ed4b3d8968da8d2edd7d9a3d6adc8a7df225ab66dc45c9bee8415c0e1336894e")
