-- Lua provided by RyzenAPI
-- Game: Asterix & Obelix: Heroes

-- MAIN APPLICATION
addappid(2374090)
-- Game: addappid(2374090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374091, 1, "ed4b3d8968da8d2edd7d9a3d6adc8a7df225ab66dc45c9bee8415c0e1336894e")
