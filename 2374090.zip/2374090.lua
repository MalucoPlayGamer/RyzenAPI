-- Lua provided by RyzenAPI
-- Game: Asterix & Obelix: Heroes

-- MAIN APPLICATION
addappid(2374090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374091, 1, "ed4b3d8968da8d2edd7d9a3d6adc8a7df225ab66dc45c9bee8415c0e1336894e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
