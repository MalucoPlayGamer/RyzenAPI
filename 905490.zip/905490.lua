-- Lua provided by RyzenAPI
-- Game: Deck Hunter

-- MAIN APPLICATION
addappid(905490)

-- MAIN APP DEPOTS / PACKAGES
addappid(905492,0,"0fbd3447d5271c298dac93b560299ab68d97d24c7419eedfb89a0900de153824")

