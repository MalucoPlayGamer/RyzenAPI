-- Lua provided by RyzenAPI
-- Game: Game: AppID 251310

-- MAIN APPLICATION
addappid(251310)
-- Game: addappid(251310)

-- MAIN APP DEPOTS / PACKAGES
addappid(251311, 1, "c76ab7fb3cb5b458aa34b455f53415fb3831f9f38eadf74b838f194dfc54b96c")
