-- Lua provided by RyzenAPI 
-- Game: AppID 251310
addappid(251310)
addappid(251311, 1, "c76ab7fb3cb5b458aa34b455f53415fb3831f9f38eadf74b838f194dfc54b96c")
