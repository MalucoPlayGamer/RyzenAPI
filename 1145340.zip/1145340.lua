-- Lua provided by RyzenAPI
-- Game: Rogue State Revolution

-- MAIN APPLICATION
addappid(1145340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1145341, 1, "0a42cf706cc68a319cac6996235d9f9261d9bc9cd3ebb2ea7ec768e40cff2762")
addappid(1145342, 1, "79c8a5ff00e653e7b9a35c565a70ef9af41300342543820c5eeb1955500a2df2")
addappid(1145343, 1, "66a9105ca769b437bc4443595de05ea7bbdbb006f5ef9de74ffac55265adc1f5")
addappid(1145344, 1, "925b4772a3704d0dca094e09459682ceca6ecdf07fc4236b01d4311612d922a0")
addappid(1145345, 1, "e782dfaaf8748ebcea6783dfa65f15133acf568bfb140222be62e2253e6350fa")
