-- Lua provided by RyzenAPI
-- Game: Heroes of Eternal Quest Demo

-- MAIN APPLICATION
addappid(2376460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376461, 1, "07beb39d7a37a1179c6083f52530ae84bf102ec6f1f7a9e72baac177b9e90606")

