-- Lua provided by RyzenAPI
-- Game: Astronite

-- MAIN APPLICATION
addappid(1489590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489591, 1, "2c3d2fcdaa4ab12d60ebebda5955db501a469e5e3f22020fda9ae90394d347c2")

