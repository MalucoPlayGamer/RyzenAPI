-- Lua provided by RyzenAPI
-- Game: AppID 1237350

-- MAIN APPLICATION
addappid(1237350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237351, 1, "65af970edd20e3a75b7f272f75795da95c342d474e66b8e32bdb05a6daa6ab6f")
