-- Lua provided by SkyAPI 
-- Game: Booty Farm [18+]
addappid(1941000)
addappid(1941001, 1, "9d0819549ccebbe21a27c5e37e8ba24d5562b0cbdf8fb163f7e8aeed600e11ce")
