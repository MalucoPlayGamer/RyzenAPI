-- Lua provided by SkyAPI 
-- Game: AppID 492170
addappid(492170)
addappid(492171, 1, "a610ab44b85ec06e1d607cf61463484067ce448fe841c29936f2234b03c667cc")
