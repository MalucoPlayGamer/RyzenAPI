-- Lua provided by RyzenAPI
-- Game: addappid(492170)

-- MAIN APPLICATION
addappid(492170)

-- MAIN APP DEPOTS / PACKAGES
addappid(492171, 1, "a610ab44b85ec06e1d607cf61463484067ce448fe841c29936f2234b03c667cc")
