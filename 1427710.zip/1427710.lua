-- Lua provided by RyzenAPI
-- Game: Game: EmptyBottle

-- MAIN APPLICATION
addappid(1427710)
-- Game: addappid(1427710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427711, 1, "49fc813cf793dfd96a7856d127562c077464b5b4524ed7f67642865e9fa46e7c")
