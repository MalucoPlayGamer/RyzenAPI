-- Lua provided by RyzenAPI
-- Game: Bloodland

-- MAIN APPLICATION
addappid(1427420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1427421, 1, "da86c00d628d2c6f2e2ba5f29eb27912b09a48e379cd19db42bbb4718b79b1ff")

