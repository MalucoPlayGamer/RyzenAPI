-- Lua provided by RyzenAPI
-- Game: addappid(1427420)

-- MAIN APPLICATION
addappid(1427420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427421, 1, "da86c00d628d2c6f2e2ba5f29eb27912b09a48e379cd19db42bbb4718b79b1ff")
