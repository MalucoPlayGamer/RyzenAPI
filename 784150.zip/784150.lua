-- Lua provided by RyzenAPI
-- Game: Workers & Resources: Soviet Republic

-- MAIN APPLICATION
addappid(784150)

-- MAIN APP DEPOTS / PACKAGES
addappid(784150,0,"c09fda78c22d893fbed2ed6733c5b1d153a9d3a991b3b6ebfcb276e87ff7bb68")
addappid(784151,0,"3cbf0aae21e6bfca8d67af48b8f449d1ab056ef999590f4f3eb4c487badc6a19")
addappid(1948180,0,"b696c3e1ec422855ee25cedaa1728344b4700f94fb0857da3e3e19f470f91550")
addappid(2499360,0,"c7307729a15331dec7fc6d57ca362afae67d7a014999b980c5d88ef198e26331")
addappid(3333420,0,"4b5e8038aff5bb90f428d2a559cc99e36a0d1f0be5e5180df163807db5c0a37c")
addappid(3334790,0,"40c9ff3a431a75ba2a4056613920f62e835a5c1fc3d25cfce748848f0d91995f")

