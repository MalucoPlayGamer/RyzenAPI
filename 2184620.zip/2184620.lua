-- Lua provided by RyzenAPI
-- Game: Never 7 - The End of Infinity

-- MAIN APPLICATION
addappid(2184620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184621, 1, "39551a4d76f98b8d5b49a223341364752575137d856bf932d38d65a0035d337d")

