-- Lua provided by RyzenAPI
-- Game: 1672880

-- MAIN APPLICATION
addappid(1672880)
-- Game: addappid(1672880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672881, 1, "0c250d90bd342a1dad8bfe3ce7784ac391cae1e124eb6a5bbad9200813a187ac")
