-- Lua provided by RyzenAPI
-- Game: 8-Bit Bayonetta

-- MAIN APPLICATION
addappid(567090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(567091, 1, "01ea5afeb8d7e6e018e09750ad360b268dd081718e2ddbf8eb347a273b0c2b4c")
