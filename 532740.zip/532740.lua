-- Lua provided by RyzenAPI
-- Game: CrazyFlies

-- MAIN APPLICATION
addappid(532740)

-- MAIN APP DEPOTS / PACKAGES
addappid(532741,0,"4482d0656d9a540dedbefe1aabacb3c9a01e98646ca8db063eed8e5a4b2ee0f7")

