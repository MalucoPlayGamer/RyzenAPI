-- Lua provided by RyzenAPI
-- Game: Game: AppID 1242850

-- MAIN APPLICATION
addappid(1242850)
-- Game: addappid(1242850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242851, 1, "9de37453e7bebd3625b6eafafe7d105797582eadd06d9c56fa8ad1f96c014934")
