-- Lua provided by RyzenAPI
-- Game: Ven VR Adventure

-- MAIN APPLICATION
addappid(1139310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139311, 1, "3e4b17c584ed99bd2b88b86a00802613e0fef10eadb0d6c1847936d68683adf9")
