-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2020840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020842,0,"bafd3c590a65fa253b717a88760d8d6251d3cd91f65237f78ee595746dbdfa93")
