-- 3300050's Lua and Manifest Created by Hubcap Manifest
-- System Breakdown
-- Created: August 13, 2026 at 05:08:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3300050, 1, "f5ec19712ebb36f36c16b6c91851a269a67f4b61de73df404507c1a133b05e36") -- System Breakdown
-- MAIN APP DEPOTS
addappid(3300051, 1, "7643bfa8892407e65c595b162d101d9ab955bc311ce7dd0a901da6ebdd593a73") -- Depot 3300051
setManifestid(3300051, "264309130240009052", 1904648301)
addappid(3300052, 1, "dfdd9a83f15f34aec894f8647f2f2f8aca7c0f01f77bbab472d9e33b1b19b1ac") -- Depot 3300052
setManifestid(3300052, "8973860105526383298", 1974488706)