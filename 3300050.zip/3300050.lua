-- Lua provided by RyzenAPI
-- Game: System Breakdown

-- MAIN APP DEPOTS / PACKAGES
addappid(3300050, 1, "f5ec19712ebb36f36c16b6c91851a269a67f4b61de73df404507c1a133b05e36") -- System Breakdown
addappid(3300051, 1, "7643bfa8892407e65c595b162d101d9ab955bc311ce7dd0a901da6ebdd593a73") -- Depot 3300051
addappid(3300052, 1, "dfdd9a83f15f34aec894f8647f2f2f8aca7c0f01f77bbab472d9e33b1b19b1ac") -- Depot 3300052

