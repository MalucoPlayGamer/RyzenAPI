-- Lua provided by RyzenAPI
-- Game: Spring Dash

-- MAIN APPLICATION
addappid(2093070)
-- Game: addappid(2093070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093071, 1, "484b396a953caad93ab61f431640309eea37143b8d5eab36af7bb9ed5e0e3b35")
