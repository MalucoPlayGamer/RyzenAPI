-- Lua provided by RyzenAPI
-- Game: Zetria Demo

-- MAIN APPLICATION
addappid(1980180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980181, 1, "7087f0d27f2810d7b8627eb88d622d37945f52871eb7bacef45e3376374a3af2")

