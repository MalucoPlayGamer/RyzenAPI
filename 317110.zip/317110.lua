-- Lua provided by RyzenAPI
-- Game: Game: AppID 317110

-- MAIN APPLICATION
addappid(317110)
-- Game: addappid(317110)

-- MAIN APP DEPOTS / PACKAGES
addappid(317111, 1, "85725af9fead8ad6fa6d4a4284741c61bd3d62db97771c4eccdbc40ac3fb37e7")
