-- Lua provided by RyzenAPI
-- Game: [Bober Bros] Last Pill Bar

-- MAIN APPLICATION
addappid(4603670) -- [Bober Bros] Last Pill Bar

-- MAIN APP DEPOTS / PACKAGES
addappid(4603671, 1, "5776bbe94a54b5fd3184e55e8801a4558285951e7bb698bd925cfd15403700ac") -- Depot 4603671
addappid(4603672, 1, "bbd2903bcd93003c05ef12db82c64ae92f275ffd3c7e9362bce3f2bc0fc65644") -- Depot 4603672

