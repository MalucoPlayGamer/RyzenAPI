-- Lua provided by RyzenAPI
-- Game: Defend Your Castle

-- MAIN APPLICATION
addappid(708710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(708711, 1, "b53d1b87bdaea8d74ab3243736603dd5c449b8e706d5818182efc2ba132c95d6")

