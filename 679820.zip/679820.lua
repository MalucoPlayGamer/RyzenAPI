-- Lua provided by RyzenAPI
-- Game: Solitaire Mystery: Stolen Power

-- MAIN APPLICATION
addappid(679820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(679821, 1, "a867d0b70fe732af9b8d1164011ad5614b6f896a11135dd4134f394954a818a1")
addappid(679823, 1, "b4ef8a4430b167b930a77f5d893657c6d93c54ad572069d02fb338eee7d5ba8f")

