-- Lua provided by RyzenAPI
-- Game: Game: Sigil of the Magi

-- MAIN APPLICATION
addappid(1781960)
-- Game: addappid(1781960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781961, 1, "a057b3990608f1ec501ec21d8c85db93667c27f52a8f34816721e3ed4fb80ebd")
