-- 629520's Lua and Manifest Created by Hubcap Manifest
-- Soundpad
-- Created: August 04, 2026 at 22:40:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(629520, 1, "c437ad2314a89b2d736db77e137dd9afc1a597b34162483465c358a4a39408c2") -- Soundpad
addtoken(629520, "6704532945332869425")
-- MAIN APP DEPOTS
addappid(629521, 1, "40df4fcb0748caf1d77bff732f597eebb26b3a36539b1646d149f54eb676807f") -- Soundpad x64 Depot
setManifestid(629521, "2194751461096945836", 17763331)
addappid(629522, 1, "832c15ab1f9cffda454f899b8d69ce24ae020d79dadfcaf97cb9b4494698b4cf") -- Soundpad x86 Depot
setManifestid(629522, "773590455848779170", 16511491)