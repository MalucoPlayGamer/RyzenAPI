-- Lua provided by RyzenAPI 
-- Game: Soundpad
addappid(629520)
addappid(629521, 1, "40df4fcb0748caf1d77bff732f597eebb26b3a36539b1646d149f54eb676807f")
addappid(629522, 1, "832c15ab1f9cffda454f899b8d69ce24ae020d79dadfcaf97cb9b4494698b4cf")
