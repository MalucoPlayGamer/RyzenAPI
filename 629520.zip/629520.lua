-- Lua provided by RyzenAPI
-- Game: Soundpad

-- MAIN APP DEPOTS / PACKAGES
addappid(629520, 1, "c437ad2314a89b2d736db77e137dd9afc1a597b34162483465c358a4a39408c2") -- Soundpad
addappid(629521, 1, "40df4fcb0748caf1d77bff732f597eebb26b3a36539b1646d149f54eb676807f") -- Soundpad x64 Depot
addappid(629522, 1, "832c15ab1f9cffda454f899b8d69ce24ae020d79dadfcaf97cb9b4494698b4cf") -- Soundpad x86 Depot
addtoken(629520, "6704532945332869425")

