-- Lua provided by RyzenAPI
-- Game: Temptations X

-- MAIN APPLICATION
addappid(1457020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457021, 1, "62f4792e247ab7a8f3b4e27716161cb502982a73a21aa20dc3cf5f9d1c2d9541")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
