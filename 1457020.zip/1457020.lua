-- Lua provided by RyzenAPI
-- Game: Temptations X

-- MAIN APPLICATION
addappid(1457020)
-- Game: addappid(1457020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457021, 1, "62f4792e247ab7a8f3b4e27716161cb502982a73a21aa20dc3cf5f9d1c2d9541")
