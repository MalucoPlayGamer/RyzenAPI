-- Lua provided by RyzenAPI 
-- Game: Plutocracy
addappid(754500)
addappid(754501, 1, "d1c9aba47698dd43f7b6d0bfd95efaf5e1598693bd92903575b0150b8435f9d3")
addappid(754502, 1, "ed7e86fc7eeeaf77dfffdc051bd0f1381d39437910c66cdf0397b610f861b463")
addappid(754503, 1, "6cd20bafa4e5a60ef99d0b2b65c72ac8ee478e8f5ee741e31fa5c6107e3d1b0d")
