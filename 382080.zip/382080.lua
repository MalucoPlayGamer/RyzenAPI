-- Lua provided by RyzenAPI
-- Game: addappid(382080)

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(229002)
addappid(382080)

-- MAIN APP DEPOTS / PACKAGES
addappid(382082,0,"961b7ff1c63e2501256885032615ced0b951d694253ad4307a5b196f88a01cea")
