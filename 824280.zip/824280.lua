-- Lua provided by RyzenAPI
-- Game: Monster Jam Steel Titans

-- MAIN APPLICATION
addappid(824280)
addappid(1025490)
addappid(1102670)
addappid(1102671)

-- MAIN APP DEPOTS / PACKAGES
addappid(824281,0,"f78b96146408dc464951b7a80f3f3d65c927eab31541b374a9085fba5dd243a2")

