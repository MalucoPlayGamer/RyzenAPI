-- Lua provided by RyzenAPI
-- Game: Monster Jam Steel Titans

-- MAIN APPLICATION
addappid(824280)
-- Game: addappid(824280)

-- MAIN APP DEPOTS / PACKAGES
addappid(824281, 1, "f78b96146408dc464951b7a80f3f3d65c927eab31541b374a9085fba5dd243a2")
