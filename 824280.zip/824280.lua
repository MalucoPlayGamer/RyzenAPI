-- Lua provided by RyzenAPI
-- Game: Monster Jam Steel Titans

-- MAIN APPLICATION
addappid(824280)
addappid(1025490)
addappid(1102670)
addappid(1102671)

-- MAIN APP DEPOTS / PACKAGES
addappid(824281,0,"f78b96146408dc464951b7a80f3f3d65c927eab31541b374a9085fba5dd243a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
