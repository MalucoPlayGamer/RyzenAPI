-- Lua provided by RyzenAPI
-- Game: The Station VR

-- MAIN APPLICATION
addappid(877510)

-- MAIN APP DEPOTS / PACKAGES
addappid(877511, 1, "1479453f62464866def2d69ebd59f53464010b6c511c590b7a150d892487c0af")

