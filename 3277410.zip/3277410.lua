-- Lua provided by SkyAPI 
-- Game: Patient 001
addappid(3277410)
addappid(3277411, 1, "68d280cea527c37d74f905aaa1315c4cc404fa87b4e274ba30d01631969f8469")
