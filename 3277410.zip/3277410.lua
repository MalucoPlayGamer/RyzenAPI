-- Lua provided by RyzenAPI
-- Game: addappid(3277410)

-- MAIN APPLICATION
addappid(3277410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277411, 1, "68d280cea527c37d74f905aaa1315c4cc404fa87b4e274ba30d01631969f8469")
