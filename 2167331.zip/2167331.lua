-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Basement Treasures Kit

-- MAIN APPLICATION
addappid(2167331)
-- Game: addappid(2167331)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167331,0,"d3d1326005f94e784871be83d7ee2572eff935ac0e5e98484a1d6d92953be614")
addappid(2243790,0,"4198add96ccbabd42ac78a00a61ac931d05ce50f376765b428b05126f32b6d2e")
addappid(2243791,0,"438ee161c08a9e6f05ce417e27af0901cb7565344a6ea1af9536f7ec76d173dd")
addappid(2243792,0,"c8fee852935c9e281185d451a2f34b03ccc35e92d04cba8b186e99a1c2bb87d3")
addappid(2243796,0,"31b1fcdf87c10adf3dd1da3fee94213043df7bea13082bbf4e1aa16e5b929f08")
addappid(2243797,0,"793d207ecd5f700b335b6333ba1d0b97b2672acf11b2b60dccd517836bcdfa9c")
addappid(2243800,0,"a08fc38ebf8c5169ede854d80f0a2edf04e6b7ce9d0dc775ac8abc61f9c1b8a5")
addappid(2243807,0,"2938857c3a9626d2386a9bb48dd51a20bf356b9839a0bcdced8a1a4639401ee5")
