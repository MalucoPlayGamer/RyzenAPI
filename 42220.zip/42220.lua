-- Lua provided by RyzenAPI 
-- Game: AppID 42220
addappid(42220)
addappid(42221, 1, "065191b90917c54bf45239494073a7aad7f8d74c2c7c0a42592b450d8dd5489d")
