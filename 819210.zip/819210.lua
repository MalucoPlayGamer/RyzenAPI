-- Lua provided by RyzenAPI
-- Game: 819210

-- MAIN APPLICATION
addappid(819210)
addappid(819211)
addappid(819213)

-- MAIN APP DEPOTS / PACKAGES
addappid(819212,0,"046b43d890de59512f0f441427a83e31ddd52431de1e0bad2a949fc1d3e9c0d7")
