-- Lua provided by RyzenAPI
-- Game: Game: The Few

-- MAIN APPLICATION
addappid(300320)
-- Game: addappid(300320)

-- MAIN APP DEPOTS / PACKAGES
addappid(300321, 1, "5b2b76c9cb1a55f719e306d0be4effa71a046bfa8d03bc11eabe091f258a61a1")
