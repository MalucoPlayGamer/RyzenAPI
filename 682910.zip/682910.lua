-- Lua provided by RyzenAPI
-- Game: Game: No Lights

-- MAIN APPLICATION
addappid(682910)
-- Game: addappid(682910)

-- MAIN APP DEPOTS / PACKAGES
addappid(682911, 1, "bd8c1cf9940096695323c88e8e699f55d548990ad7540258ad734cebf0e96547")
