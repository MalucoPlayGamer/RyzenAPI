-- Lua provided by RyzenAPI
-- Game: 1471960

-- MAIN APPLICATION
addappid(1471960)
addappid(1471962)
addappid(1471964)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471963,0,"9d975405ad542ba3bff882c5b6990943ef9fba5395ca4bc2efaa66298bae1f48")

