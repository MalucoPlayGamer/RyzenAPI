-- Lua provided by SkyAPI 
-- Game: Anthology of Fear: Prologue
addappid(1325610)
addappid(1325611, 1, "a7ff62f37c7847b522fb8d0fedf653f6da355ff002e19ac28d2236fa106eba0d")
