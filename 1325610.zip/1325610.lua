-- Lua provided by RyzenAPI
-- Game: addappid(1325610)

-- MAIN APPLICATION
addappid(1325610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325611, 1, "a7ff62f37c7847b522fb8d0fedf653f6da355ff002e19ac28d2236fa106eba0d")
