-- Lua provided by RyzenAPI
-- Game: Zero World Dedicated Server

-- MAIN APPLICATION
addappid(2070070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070071, 1, "c7d69c013e80eaa34b467a4bbd085181603e0a60fd8c93c139f166627a94ca35")

