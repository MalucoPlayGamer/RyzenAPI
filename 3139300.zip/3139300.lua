-- Lua provided by RyzenAPI 
-- Game: AppID 3139300
addappid(3139300)
addappid(3139301, 1, "2a385bfca27e699e1178fd9cdafe4bd737451db355e3e5f1a9d3b997520368d5")
