-- Lua provided by RyzenAPI
-- Game: Human Within

-- MAIN APPLICATION
addappid(1546070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546071, 1, "de80988609f6c2172197e412a5b7e37f2a900a3666d7f64600cdb03fe86087f7")

