-- Lua provided by RyzenAPI
-- Game: 红月

-- MAIN APPLICATION
addappid(2131820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131821, 1, "0455e9a29b9ed8d66fbb4336f4faf9507ab76470e411cc1c55d56e5ea0618634")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
