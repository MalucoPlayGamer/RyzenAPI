-- Lua provided by RyzenAPI
-- Game: addappid(2131820)

-- MAIN APPLICATION
addappid(2131820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131821, 1, "0455e9a29b9ed8d66fbb4336f4faf9507ab76470e411cc1c55d56e5ea0618634")
