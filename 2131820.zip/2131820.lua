-- Lua provided by RyzenAPI 
-- Game: 红月
addappid(2131820)
addappid(2131821, 1, "0455e9a29b9ed8d66fbb4336f4faf9507ab76470e411cc1c55d56e5ea0618634")
