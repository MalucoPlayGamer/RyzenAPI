-- Lua provided by SkyAPI 
-- Game: Ludo Online: Classic Multiplayer Dice Board Game
addappid(883080)
addappid(883081, 1, "2402aa4b2fa0371fe9b66d7c68223cc8f2c57d3e38cd869fd9c15da9a7cc4e36")
