-- Lua provided by RyzenAPI
-- Game: Ludo Online: Classic Multiplayer Dice Board Game

-- MAIN APPLICATION
addappid(883080)

-- MAIN APP DEPOTS / PACKAGES
addappid(883081, 1, "2402aa4b2fa0371fe9b66d7c68223cc8f2c57d3e38cd869fd9c15da9a7cc4e36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
