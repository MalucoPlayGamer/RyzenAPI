-- Lua provided by RyzenAPI
-- Game: addappid(2066550)

-- MAIN APPLICATION
addappid(2066550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066551, 1, "c57ffd2602bd94769b1df09ed4e7a52fd99c8372cdd79dae39d54fd9942bfe8c")
