-- Lua provided by RyzenAPI
-- Game: ERROR143

-- MAIN APPLICATION
addappid(2066550)
addappid(2230570)
addappid(2738730)
addappid(3815660)
addappid(3815670)
addappid(3815680)
addappid(3815690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066551, 1, "c57ffd2602bd94769b1df09ed4e7a52fd99c8372cdd79dae39d54fd9942bfe8c")

