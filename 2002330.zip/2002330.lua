-- Lua provided by RyzenAPI
-- Game: 2002330

-- MAIN APPLICATION
addappid(2002330)
-- Game: addappid(2002330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002331, 1, "273cdffee715c0adda40bf933fb415d289e214fd67d750aa5e87d0a81a28e108")
