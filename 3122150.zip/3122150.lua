-- Lua provided by RyzenAPI
-- Game: Under the blue horizon

-- MAIN APPLICATION
addappid(3122150)
-- Game: addappid(3122150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122151, 1, "c56bd6696bacb3b28785607aa0b3f8deccc40c3632e9f5e42a4c70e804b8e382")
