-- Lua provided by RyzenAPI
-- Game: M1: A Death in the Desert

-- MAIN APPLICATION
addappid(675530)

-- MAIN APP DEPOTS / PACKAGES
addappid(675531,0,"7b6a7d20cf4e51f6c6f967ca74a97683a3412bf03bb4ae2698a7dd7332c3980e")
addappid(677360,0,"a9bdfe805a4bfb16511982247488f1276029a2fb506dda81408e0e1215012d9c")

