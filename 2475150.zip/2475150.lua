-- Lua provided by RyzenAPI
-- Game: SuccuBoss💋 我的上司是魅魔

-- MAIN APPLICATION
addappid(2475150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475151, 1, "6e178d5311e4de1c0211d7dc5145d80019d7cfe8e9ede5577dd8d9e6f27e512c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
