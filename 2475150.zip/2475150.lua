-- Lua provided by RyzenAPI
-- Game: 2475150

-- MAIN APPLICATION
addappid(2475150)
-- Game: addappid(2475150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475151, 1, "6e178d5311e4de1c0211d7dc5145d80019d7cfe8e9ede5577dd8d9e6f27e512c")
