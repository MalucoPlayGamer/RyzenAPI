-- Lua provided by RyzenAPI
-- Game: Detective Failure

-- MAIN APPLICATION
addappid(874080)

-- MAIN APP DEPOTS / PACKAGES
addappid(874081,0,"feb7220463e09b567e9dc1d1a16dc7b8bd16fcc0e8f3c5a2767e33617957071d")

