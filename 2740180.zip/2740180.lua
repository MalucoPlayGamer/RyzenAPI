-- Lua provided by RyzenAPI
-- Game: Sex Euphoria 💖

-- MAIN APPLICATION
addappid(2740180)
-- Game: addappid(2740180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740181, 1, "879f1370f685a5cb6271155b009c5af370ca733bb0582feedd2745b96a8d65fa")
