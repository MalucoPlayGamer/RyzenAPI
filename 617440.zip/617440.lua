-- Lua provided by SkyAPI 
-- Game: AppID 617440
addappid(617440)
addappid(617441, 1, "7360bdab98619976fcdd4ec41fa1ee4891a79939a67452d94384f897c4895420")
addappid(684241)
addappid(684290)
