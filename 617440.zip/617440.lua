-- Lua provided by RyzenAPI
-- Game: addappid(617440)

-- MAIN APPLICATION
addappid(617440)
addappid(684241)
addappid(684290)

-- MAIN APP DEPOTS / PACKAGES
addappid(617441, 1, "7360bdab98619976fcdd4ec41fa1ee4891a79939a67452d94384f897c4895420")
