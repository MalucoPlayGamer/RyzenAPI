-- Lua provided by RyzenAPI
-- Game: Sakura Fox Adventure

-- MAIN APPLICATION
addappid(1157640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157641, 1, "2cdf397c4c1076518fdf6ffe6a99611c30802767ac36dad1918792c8a23d3b8f")

