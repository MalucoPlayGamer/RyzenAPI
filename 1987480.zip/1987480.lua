-- Lua provided by RyzenAPI
-- Game: 勇者与亡灵之都

-- MAIN APPLICATION
addappid(1987480)
addappid(3260270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1987481, 1, "dc0befd55709cf6bd2d6a04a83903131b389a68389566cb3d3faf0c3e08198eb")

