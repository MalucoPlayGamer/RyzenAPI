-- Lua provided by RyzenAPI
-- Game: Game: 勇者与亡灵之都

-- MAIN APPLICATION
addappid(1987480)
addappid(3260270)
-- Game: addappid(1987480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987481, 1, "dc0befd55709cf6bd2d6a04a83903131b389a68389566cb3d3faf0c3e08198eb")
