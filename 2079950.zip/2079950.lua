-- Lua provided by RyzenAPI
-- Game: Filthy us 2

-- MAIN APPLICATION
addappid(2079950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079951, 1, "47b71c8e541b51d4d3d013f49cb139ce59ebb1d1462b6551f055ab28c9d82b65")
