-- Lua provided by RyzenAPI
-- Game: addappid(230410)

-- MAIN APPLICATION
addappid(230410)

-- MAIN APP DEPOTS / PACKAGES
addappid(230411, 1, "4a31d148d70cafd9b9bd15811fab33a188cc5cb39204551984777dae0cb08f33")
