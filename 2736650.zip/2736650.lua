-- Lua provided by RyzenAPI
-- Game: Tiny Connections

-- MAIN APPLICATION
addappid(2736650)
addappid(2736652)
-- Game: addappid(2736650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736653,0,"9e381f3893514e1eea181202d39b08d1949985e4844ee5d969af6a37b14006ef")
