-- Lua provided by SkyAPI 
-- Game: AppID 1283250
addappid(1283250)
addappid(1283251, 1, "341e0ad3b16682f3cba42864403c1b3cf21bec5825dfc7a45a07cf94ff436f8a")
addappid(1283252, 1, "1b7e8ef576d46cd62ac19350e7850769333c8e1ba5f128d0118cb7764378432d")
