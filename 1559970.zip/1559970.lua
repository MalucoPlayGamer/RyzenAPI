-- Lua provided by RyzenAPI
-- Game: AppID 1559970

-- MAIN APPLICATION
addappid(1559970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559971, 1, "5f8afa33b408536d60bfd580a71ddb129f95d1e5dd9ba2fd2c09c448913c4b7d")
