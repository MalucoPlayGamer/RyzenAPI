-- Lua provided by SkyAPI 
-- Game: SpellForce: Conquest of Eo Soundtrack
addappid(3214940)
addappid(3214941, 1, "5491cf932d3d301b687b6136aeeb31c00df711f12a92a7aee67d521fe97b35d0")
addappid(3214942, 1, "204914b6fbc2e1e5ddb3e458b3a6333cc751eb45897511ce6331ac8d3e2ff005")
