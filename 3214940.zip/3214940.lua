-- Lua provided by RyzenAPI
-- Game: 3214940

-- MAIN APPLICATION
addappid(3214940)
-- Game: addappid(3214940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214941, 1, "5491cf932d3d301b687b6136aeeb31c00df711f12a92a7aee67d521fe97b35d0")
addappid(3214942, 1, "204914b6fbc2e1e5ddb3e458b3a6333cc751eb45897511ce6331ac8d3e2ff005")
