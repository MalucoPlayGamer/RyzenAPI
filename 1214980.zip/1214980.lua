-- Lua provided by RyzenAPI
-- Game: The Line

-- MAIN APPLICATION
addappid(1214980)
-- Game: addappid(1214980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214981, 1, "f650b52eb34697550e25d7938c0927bf93a837cf1823a3cf1f5a4581f4e80332")
