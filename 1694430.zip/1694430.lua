-- Lua provided by RyzenAPI
-- Game: addappid(1694430)

-- MAIN APPLICATION
addappid(1694430)
addappid(1695440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694431, 1, "4bbb930aa2a6f83a4e4cf25cc6e0e4b4cb9e54315819224c2d38d0362054ff03")
