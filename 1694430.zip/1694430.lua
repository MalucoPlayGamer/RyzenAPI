-- Lua provided by RyzenAPI 
-- Game: Dynamic Dungeons Editor
addappid(1694430)
addappid(1694431, 1, "4bbb930aa2a6f83a4e4cf25cc6e0e4b4cb9e54315819224c2d38d0362054ff03")
addappid(1695440)
