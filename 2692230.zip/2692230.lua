-- Lua provided by RyzenAPI
-- Game: 山海经之仙剑传奇

-- MAIN APPLICATION
addappid(2692230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692231, 1, "a54098f97dc51cff496a9bfcb269654513db12c80232977f2ca8fda7d854337d")
