-- Lua provided by RyzenAPI
-- Game: 1943060

-- MAIN APPLICATION
addappid(1943060)
addappid(2308180)
-- Game: addappid(1943060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943061, 1, "6b4af366257fae5f6dc60ee1f20f3d6ca4814f965b93317e2d656f8032ffff46")
