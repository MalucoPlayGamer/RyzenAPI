-- Lua provided by RyzenAPI
-- Game: Game: Four Color Jump

-- MAIN APPLICATION
addappid(1656640)
-- Game: addappid(1656640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656641, 1, "1982c4a127c63214314df17c5c36d77487a219256183c441bba951b22bd988a8")
addappid(1661990, 0, "5e5f34f1ef33c2713922e53018ae73ba29a804c5faa9f1fab643b6748ce186b8")
