-- Lua provided by RyzenAPI
-- Game: Primitive Survival

-- MAIN APPLICATION
addappid(1206320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206321, 1, "bf5423a8701da45873b86dc2a599c1fe6d2b0affb5b57c4c9218ca69d5ec33ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
