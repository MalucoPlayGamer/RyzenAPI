-- Lua provided by RyzenAPI
-- Game: Fiora Arc

-- MAIN APPLICATION
addappid(1999730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999731, 1, "3d85a11ea11dab242d3abd2acd57c5f26fdf0e673872af4e5a3da99d8225cee6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
