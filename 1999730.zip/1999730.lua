-- Lua provided by RyzenAPI 
-- Game: Fiora Arc
addappid(1999730)
addappid(1999731, 1, "3d85a11ea11dab242d3abd2acd57c5f26fdf0e673872af4e5a3da99d8225cee6")
