-- Lua provided by RyzenAPI
-- Game: addappid(2062820)

-- MAIN APPLICATION
addappid(2062820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062821, 1, "26dfb78631e9958fb3c97ce0c40ce3b4740d57e00fc49bc718ed346da8d0d8ec")
