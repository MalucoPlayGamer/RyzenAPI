-- Lua provided by RyzenAPI
-- Game: Backroom Beyond

-- MAIN APPLICATION
addappid(2062820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2062821, 1, "26dfb78631e9958fb3c97ce0c40ce3b4740d57e00fc49bc718ed346da8d0d8ec")

