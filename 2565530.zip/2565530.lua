-- Lua provided by RyzenAPI
-- Game: Vexlands Demo

-- MAIN APPLICATION
addappid(2565530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565531, 1, "3e4b7502f51b3e085592d2a0ec49cb6dcdf5df787c191c12892106656c07ae10")

