-- Lua provided by RyzenAPI 
-- Game: THE MEME HUNTER
addappid(2310300)
addappid(2310301, 1, "a33fc85dc2504b01c63dee5e922bfe52475202b237cfe36ffd6f036b275d975b")
