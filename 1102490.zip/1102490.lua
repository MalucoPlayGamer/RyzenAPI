-- Lua provided by RyzenAPI
-- Game: AppID 1102490

-- MAIN APPLICATION
addappid(1102490)
-- Game: addappid(1102490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102491, 1, "0843b533a337c783448e0b44f75490eaa79251d9fc2d531c3ef5d6ffbf91e2ec")
