-- Lua provided by RyzenAPI
-- Game: G-Scramble

-- MAIN APPLICATION
addappid(2515790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2515791, 1, "0adb98d9068e757fa4e6c6386b5d60e0afb786be547a1336ca3d98995b521ec2")

