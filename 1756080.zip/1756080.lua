-- Lua provided by RyzenAPI 
-- Game: Doomsday Defense
addappid(1756080)
addappid(1756081, 1, "02d9c74e57727533b58e0466304fe4090b998829317b0324f269dfbbe3a41fa0")
