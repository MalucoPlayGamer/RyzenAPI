-- Lua provided by RyzenAPI
-- Game: addappid(453740)

-- MAIN APPLICATION
addappid(453740)

-- MAIN APP DEPOTS / PACKAGES
addappid(453741, 1, "513c884b6e91299783b8ee9650cf976958cca457e3450ad1e274d29001cb1aed")
addappid(453744, 1, "10dfa5080b8ffcf6cb52fbf851ea093c5506d7f276910f59539049822c42e9ab")
addappid(455750, 0, "577c4e62a4d561299abcd696f2bcde07adf2fbd081ab58e21b9d3bb4d23b78bb")
