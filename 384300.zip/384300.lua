-- Lua provided by RyzenAPI
-- Game: CPUCores :: Maximize Your FPS

-- MAIN APPLICATION
addappid(384300)
addappid(726480)
addappid(736580)
addappid(842680)

-- MAIN APP DEPOTS / PACKAGES
addappid(384301, 1, "da5a3e68c9ed912dc199160655f508a26739096a242cf275dce4ff6bafde0277")
