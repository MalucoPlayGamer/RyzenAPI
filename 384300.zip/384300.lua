-- Lua provided by RyzenAPI
-- Game: 384300

-- MAIN APPLICATION
addappid(384300)
-- Game: addappid(384300)

-- MAIN APP DEPOTS / PACKAGES
addappid(384301, 1, "da5a3e68c9ed912dc199160655f508a26739096a242cf275dce4ff6bafde0277")
