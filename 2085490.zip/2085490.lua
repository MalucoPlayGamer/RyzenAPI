-- Lua provided by RyzenAPI
-- Game: The Sexorcist

-- MAIN APPLICATION
addappid(2085490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085491, 1, "ac2d7000b122168920cbfc5d4a6285d6351f6b600d6c89f12a2541d464fd6742")

