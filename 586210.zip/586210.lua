-- Lua provided by RyzenAPI
-- Game: AppID 586210

-- MAIN APPLICATION
addappid(586210)

-- MAIN APP DEPOTS / PACKAGES
addappid(586211, 1, "1f32dc1bb9c2e43ac8e02fd5e3119f52910b22412772a2d160553a885fd4f4ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
