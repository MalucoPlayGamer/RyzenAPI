-- Lua provided by SkyAPI 
-- Game: 出马
addappid(3593940)
addappid(3593941, 1, "a4201300c119b5b5ca6084b65550008a047ee4f4e01386d69f3c35eebea1250e")
