-- Lua provided by RyzenAPI
-- Game: 1046342

-- MAIN APPLICATION
addappid(1046342)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046342,0,"d062e71b6bd2d6dbe16262959a0a68c83521dbe4fd26fe0c52e44d27aaa7addf")

