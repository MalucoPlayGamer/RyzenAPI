-- Lua provided by RyzenAPI
-- Game: 686680

-- MAIN APPLICATION
addappid(686680)
-- Game: addappid(686680)

-- MAIN APP DEPOTS / PACKAGES
addappid(686682,0,"1c1ef0386ad207d0a43d583320ad97b37ef42b2df55521cd489ef0dc45abe3a5")
addappid(686683,0,"ed8a1f580bd9710ec365ad9ff92980f51a2289ac89c9958c352d9bcdd060b1dd")
