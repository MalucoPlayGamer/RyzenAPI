-- Lua provided by RyzenAPI
-- Game: 3486560

-- MAIN APPLICATION
addappid(3486560)
-- Game: addappid(3486560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486561, 1, "e407691f14256af11a9fa582cb1be18126a8a3cb5d043468b242454e30c77dc6")
