-- Lua provided by RyzenAPI
-- Game: 2487620

-- MAIN APPLICATION
addappid(2487620)
-- Game: addappid(2487620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487621, 1, "764a18604419db3e02ba7f936ba16973d4fbc6b7164bc32739ce74fcd8112cb7")
