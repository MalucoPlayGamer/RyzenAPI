-- Lua provided by RyzenAPI 
-- Game: Angela's Odyssey
addappid(1061680)
addappid(1061681, 1, "440008186372ae15ab08c59e1ece4bf7d12c844380cfd5db5a15569e954ffecb")
