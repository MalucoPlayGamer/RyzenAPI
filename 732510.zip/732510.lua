-- Lua provided by RyzenAPI
-- Game: 732510

-- MAIN APPLICATION
addappid(732510)
-- Game: addappid(732510)

-- MAIN APP DEPOTS / PACKAGES
addappid(732511, 1, "31c9a0875809c9a6de052ec73a91399ccd5f8545f6cec5efa47fefccb7a07832")
