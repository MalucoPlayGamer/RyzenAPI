-- Lua provided by SkyAPI 
-- Game: AppID 602220
addappid(602220)
addappid(602221, 1, "076b6aa82b0fd46bee09bc8ed1df7cd4d7e875c122b713e94b4c6f9835af38e9")
