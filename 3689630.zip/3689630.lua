-- Lua provided by RyzenAPI
-- Game: Bubble Rage

-- MAIN APPLICATION
addappid(3689630)
-- Game: addappid(3689630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689631, 1, "e58a9ef4179943c960fdc3150fbb9600f6bb6968edad945419abd8a8f44a5b0f")
