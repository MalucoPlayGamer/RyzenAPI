-- Lua provided by RyzenAPI
-- Game: NeverMine

-- MAIN APPLICATION
addappid(493920)

-- MAIN APP DEPOTS / PACKAGES
addappid(493921, 1, "1c45d55b60e72fffa0c98b037fae9a97f0fb150d6606f148cff0c6633ed1bf9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
