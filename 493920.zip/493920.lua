-- Lua provided by RyzenAPI
-- Game: NeverMine

-- MAIN APPLICATION
addappid(493920)

-- MAIN APP DEPOTS / PACKAGES
addappid(493921, 1, "1c45d55b60e72fffa0c98b037fae9a97f0fb150d6606f148cff0c6633ed1bf9a")

