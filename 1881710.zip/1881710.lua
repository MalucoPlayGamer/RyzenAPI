-- Lua provided by RyzenAPI
-- Game: Bitlands

-- MAIN APPLICATION
addappid(1881710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881711, 1, "40d703e72a8ce252ca323d50d47b3736da39410800bf569d33d29562b63a98bc")
