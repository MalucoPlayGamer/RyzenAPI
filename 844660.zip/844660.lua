-- Lua provided by RyzenAPI
-- Game: Heart of the Woods

-- MAIN APPLICATION
addappid(844660)

-- MAIN APP DEPOTS / PACKAGES
addappid(844661, 1, "38ebb7d0d3302381d79aef3f0e270f809a2234fe2e6a04804934dc2589b86150")
addappid(1412330, 0, "a336927c91bacaf8ca607ca9cc4c4317dceeeaf7b90d7ca983731be2e104863f")

