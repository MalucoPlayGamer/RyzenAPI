-- Lua provided by RyzenAPI
-- Game: Big Hops Together

-- MAIN APPLICATION
addappid(1221480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221481,0,"86dcd14cf0f64c73a34c08b535ba5c7f5469a2811d7d4904e14a3d1d64e3361e")

