-- Lua provided by RyzenAPI
-- Game: Game: AppID 2614300

-- MAIN APPLICATION
addappid(2614300)
-- Game: addappid(2614300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614301, 1, "ba08af0278b09b13ba7057f1d6e8a7cdb64c3ba9043ceadb61a03b9485bc5286")
