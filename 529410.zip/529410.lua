-- Lua provided by RyzenAPI
-- Game: 529410

-- MAIN APPLICATION
addappid(529410)
-- Game: addappid(529410)

-- MAIN APP DEPOTS / PACKAGES
addappid(529411, 1, "4c34e3aa0a5690ef888dc747cc1c8b8917c0568c40cfb5cd7b0813138274bd0a")
