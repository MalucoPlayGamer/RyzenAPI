-- Lua provided by RyzenAPI
-- Game: Game: Reanimation Inc.

-- MAIN APPLICATION
addappid(1089820)
-- Game: addappid(1089820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089821, 1, "f74925dcf6f049b66f22a82d461b5b9ebf1464ff9240c74e7d48eed7a1b8b801")
