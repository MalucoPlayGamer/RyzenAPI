-- Lua provided by RyzenAPI 
-- Game: Wordfright
addappid(3107040)
addappid(3107041, 1, "1d04e780d594294e677f8489af742b5145a57b0fef0fc445c414592c4d35b43e")
