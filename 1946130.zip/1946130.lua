-- Lua provided by RyzenAPI
-- Game: What Lies in the Multiverse - Main Theme

-- MAIN APPLICATION
addappid(1946130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946130,0,"c6090800fff0cb9b3597256a33a7b6d740b2a2969efd23cc971e24114d4468bd")

