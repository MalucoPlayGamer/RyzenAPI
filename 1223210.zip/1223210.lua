-- Lua provided by RyzenAPI
-- Game: Zombie Towns

-- MAIN APPLICATION
addappid(1223210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223211, 1, "82711321301a4dbcdd0482421b35cfdfdeacc01331754e46f0df0d2372bbd8a9")
