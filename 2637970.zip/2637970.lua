-- Lua provided by SkyAPI 
-- Game: AppID 2637970
addappid(2637970)
addappid(2637971, 1, "050d86ae822b5fb27e273268b80c8a97abe34a756d9aea8d183c8af5920340ea")
