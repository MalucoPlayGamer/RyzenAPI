-- Lua provided by RyzenAPI
-- Game: Oddsparks: An Automation Adventure Demo

-- MAIN APPLICATION
addappid(2637970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637971, 1, "050d86ae822b5fb27e273268b80c8a97abe34a756d9aea8d183c8af5920340ea")

