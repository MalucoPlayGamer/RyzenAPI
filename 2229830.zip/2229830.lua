-- Lua provided by RyzenAPI
-- Game: Command & Conquer™ and The Covert Operations™

-- MAIN APPLICATION
addappid(2229830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229831, 1, "7922ca1ce2b6ca75b82a1bb12ae9fa4b5c472852f2613ae275301060b2ffcd08")
addappid(2229832, 1, "36f10dbb680b3a150f426b800db58b338fce856458b44b4e062591c4a90ed380")
addappid(2229833, 1, "acb9173532617f3765927ff68af501d777460ab3870f3215410401e65906da0c")
addappid(2229834, 1, "8ac1aa768d5a2d88b4d55324b49d17b93f6538484a8d33862cf00345eb7c7688")
addappid(2229835, 1, "2603c6dae84288ea3080a6788a3d0e2ba30a59751d89e2e8ab158054d13675ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
