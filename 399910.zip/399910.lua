-- Lua provided by RyzenAPI
-- Game: Game: Ookibloks

-- MAIN APPLICATION
addappid(399910)
-- Game: addappid(399910)

-- MAIN APP DEPOTS / PACKAGES
addappid(399911, 1, "f80a27d06e09087caf1f0779b8c2694ef722d12649168c690df5b2b50988976f")
addappid(399912, 1, "2ee7309c82e9a48112a837286561d82123893ab5a233e29167999c253e0c2c0f")
addappid(399913, 1, "a8491f76c018afd5ead2d4a0cafaf0e2fab9cc3c454a5c5e6c608d39d71799dc")
