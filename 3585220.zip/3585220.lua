-- Lua provided by RyzenAPI
-- Game: Monster Mayhem

-- MAIN APPLICATION
addappid(3585220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3585221, 1, "04a9d337f6f0d6ae80f122f995b7148210d4bd3aa7bdee383d8102fa744c21f3")

