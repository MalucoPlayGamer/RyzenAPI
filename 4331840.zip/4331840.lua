-- 4331840's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Davinya is streaming
-- Created: May 17, 2026 at 12:05:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4331840) -- Hentai Clicker: Davinya is streaming
-- MAIN APP DEPOTS
addappid(4331841, 1, "7e97ad413f2587a3e52d7b27d5153b56511c974208c64b37439b32e453a679f0") -- Depot 4331841
setManifestid(4331841, "5947758087880169234", 158989865)