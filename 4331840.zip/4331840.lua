-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Davinya is streaming

-- MAIN APPLICATION
addappid(4331840) -- Hentai Clicker: Davinya is streaming

-- MAIN APP DEPOTS / PACKAGES
addappid(4331841, 1, "7e97ad413f2587a3e52d7b27d5153b56511c974208c64b37439b32e453a679f0") -- Depot 4331841

