-- Lua provided by RyzenAPI
-- Game: Onikira: Demon Killer

-- MAIN APPLICATION
addappid(310850)
addappid(330511)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(310851, 1, "a8f95a9f620dca506b5501d7228d1bfa12cb72b3ba601c3d90e77af9cf4b8746")
addappid(330510, 0, "50f80473d56a686d70c577afac60f4e079233e3cbfe781b39ddb94a6596a22da")
