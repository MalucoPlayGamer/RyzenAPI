-- Lua provided by RyzenAPI
-- Game: Pantyhose Test Girl

-- MAIN APPLICATION
addappid(1416210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416211, 1, "e21900c739b6a543c5868ff513c57d00f2901e4a3e35c06b97b969794ef550e1")
