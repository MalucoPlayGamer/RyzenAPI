-- Lua provided by RyzenAPI
-- Game: HIVE

-- MAIN APPLICATION
addappid(468330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(468331, 1, "f3b19ba1834f61dc5592083ce9de1927e0aa90eda263a0e03b28aa33b9b8b898")
addappid(468332, 1, "92aeb597ee66552ad9b6fbb8e410b5a05254bb0c4d87cbfdc7e6d98a426d1d18")
