-- Lua provided by RyzenAPI
-- Game: The Almost Gone Demo

-- MAIN APPLICATION
addappid(1293010)
-- Game: addappid(1293010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293011, 1, "67eadc12e6954604670d7c5ab7babf7a8250c7c12c60225fc33289318825d1fe")
