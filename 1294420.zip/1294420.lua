-- Lua provided by RyzenAPI 
-- Game: AppID 1294420
addappid(1294420)
addappid(1294421, 1, "217e437dd9e6a8046529afe31829434cc3d3cf90c2af8b599cdc33fcf248b940")
