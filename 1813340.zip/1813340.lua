-- Lua provided by RyzenAPI
-- Game: Cube Space

-- MAIN APPLICATION
addappid(1813340)
-- Game: addappid(1813340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813341, 1, "50cccecb88eaa4d0be5a37fd2021012c6b6c0ed702e2a41139b752898f5ab448")
