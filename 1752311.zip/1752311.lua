-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - World Music Pack Vol.1

-- MAIN APPLICATION
addappid(1752311)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752311,0,"8b1b31c2794fad46de906f93e260e2269a9008c8504d1333ad6204d20a73504c")

