-- Lua provided by SkyAPI 
-- Game: AppID 2395760
addappid(2395760)
addappid(2395761, 1, "7a8b3bf2f8f31ec68d8f4f9ea0eb54bb1cdc20e6a1722294d27cee776c00b240")
