-- Lua provided by RyzenAPI
-- Game: 冬日树下的回忆AFTER

-- MAIN APPLICATION
addappid(2546970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546971, 1, "bea7b9cd1e385baa035d6c5c61847e58a56c31c7a39b76425f2cf3f2e9dadf76")
