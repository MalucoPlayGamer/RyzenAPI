-- Lua provided by RyzenAPI 
-- Game: Project Aftermath
addappid(21400)
addappid(21401, 1, "9aafd5c97c0b183dbf2a836de1d18f80daaa79682f4aa2a0a0870260adc05d01")
