-- Lua provided by RyzenAPI
-- Game: addappid(21400)

-- MAIN APPLICATION
addappid(21400)

-- MAIN APP DEPOTS / PACKAGES
addappid(21401, 1, "9aafd5c97c0b183dbf2a836de1d18f80daaa79682f4aa2a0a0870260adc05d01")
