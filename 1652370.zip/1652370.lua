-- Lua provided by RyzenAPI
-- Game: Disciples: Liberation Soundtrack

-- MAIN APPLICATION
addappid(1652370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652371, 1, "c858d8c0c8a8a8efa32f97229cf48607a789b116ee3c4e199f4c647a70a0ad48")
addappid(1652373, 1, "bde100ddcd5690e1702a7f462767d689694c70e909e16f3cf3e5919a20926ea9")
