-- Lua provided by SkyAPI 
-- Game: Last Oasis
addappid(903950)
addappid(903951, 1, "ff12e0c2a6e6ffd00cd305eb3f8a404cb932e582b33a6fe524de975d447072d1")
