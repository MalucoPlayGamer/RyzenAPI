-- Lua provided by RyzenAPI
-- Game: 903950

-- MAIN APPLICATION
addappid(903950)
-- Game: addappid(903950)

-- MAIN APP DEPOTS / PACKAGES
addappid(903951, 1, "ff12e0c2a6e6ffd00cd305eb3f8a404cb932e582b33a6fe524de975d447072d1")
