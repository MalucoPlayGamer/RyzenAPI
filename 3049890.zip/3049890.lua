-- Lua provided by RyzenAPI
-- Game: Egg Surprise - Styria Vampire Pack

-- MAIN APPLICATION
addappid(3049890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049891, 1, "fd3e18ecef7e0a4e50ebe536c5c10457034db824c8e508ed95b0479f5bed759d")

