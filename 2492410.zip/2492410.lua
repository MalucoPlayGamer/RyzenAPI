-- Lua provided by RyzenAPI
-- Game: Bootleg Steamer

-- MAIN APPLICATION
addappid(2492410)
-- Game: addappid(2492410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492411, 1, "6428967cc48ff24de23282d0bd55464e738663798449def643fea02597cfac71")
