-- Lua provided by SkyAPI 
-- Game: Bootleg Steamer
addappid(2492410)
addappid(2492411, 1, "6428967cc48ff24de23282d0bd55464e738663798449def643fea02597cfac71")
