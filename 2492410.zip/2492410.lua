-- Lua provided by RyzenAPI
-- Game: Bootleg Steamer

-- MAIN APPLICATION
addappid(2492410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2492411, 1, "6428967cc48ff24de23282d0bd55464e738663798449def643fea02597cfac71")

