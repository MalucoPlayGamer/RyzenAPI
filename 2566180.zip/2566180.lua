-- Lua provided by RyzenAPI
-- Game: Terranny Demo

-- MAIN APPLICATION
addappid(2566180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131151,0,"d012689d59379055228c03576e5f34d1cb840b75a570c7c14d22eccac72287c3")
