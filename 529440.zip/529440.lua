-- Lua provided by SkyAPI 
-- Game: Behold the Kickmen
addappid(529440)
addappid(529441, 1, "3b36879f58aa9891b1ee65b1b3e31fcd0a7d463bb4b2463f7c5bcdfe07ffeaa4")
addappid(529442, 1, "ef09e6b4dbcab99ee3c91cccb8add35c3c492030946134240e3b33097730c19a")
addappid(529443, 1, "b1f46a916e94a1be29cb223ad93052c0c707ce385f5ba3c3191c7289835a4f38")
