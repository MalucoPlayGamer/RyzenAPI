-- Lua provided by RyzenAPI
-- Game: addappid(1761740)

-- MAIN APPLICATION
addappid(1761740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761741, 1, "92edbc715e3799e06a890da8b3f934259ac62ddc56e2b8f7e5959f7de7c2b95f")
