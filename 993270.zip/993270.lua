-- Lua provided by RyzenAPI
-- Game: Bobs Track Builder Pro

-- MAIN APPLICATION
addappid(993270)

-- MAIN APP DEPOTS / PACKAGES
addappid(993271, 1, "a3645a58f82c46944f88ee76fc9928a1823e76d0e851d4e0771774d6fa6035c3")

