-- Lua provided by RyzenAPI
-- Game: Bobs Track Builder Pro

-- MAIN APPLICATION
addappid(993270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(993271, 1, "a3645a58f82c46944f88ee76fc9928a1823e76d0e851d4e0771774d6fa6035c3")

