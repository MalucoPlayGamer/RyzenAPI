-- Lua provided by RyzenAPI
-- Game: Neon Abyss 2 Original Soundtrack

-- MAIN APP DEPOTS / PACKAGES
addappid(3821760, 1)

