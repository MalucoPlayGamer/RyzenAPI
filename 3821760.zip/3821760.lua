-- Lua provided by RyzenAPI
-- Game: addappid(3821760, 1)

-- MAIN APP DEPOTS / PACKAGES
addappid(3821760, 1)
