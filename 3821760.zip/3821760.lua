-- Lua provided by RyzenAPI
-- Game: 3821760

-- MAIN APP DEPOTS / PACKAGES
addappid(3821760, 1)
-- Game: addappid(3821760, 1)
