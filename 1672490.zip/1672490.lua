-- Lua provided by RyzenAPI
-- Game: I'm Strongest Legend

-- MAIN APPLICATION
addappid(1672490)
addappid(1854960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672491, 1, "b7ff7b5e2f0ec8f410834372eabc0258ae10d2ea93b1b0b0dcbba190c197dcad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
