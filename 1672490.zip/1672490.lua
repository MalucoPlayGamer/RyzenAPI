-- Lua provided by RyzenAPI
-- Game: Game: I'm Strongest Legend

-- MAIN APPLICATION
addappid(1672490)
addappid(1854960)
-- Game: addappid(1672490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672491, 1, "b7ff7b5e2f0ec8f410834372eabc0258ae10d2ea93b1b0b0dcbba190c197dcad")
