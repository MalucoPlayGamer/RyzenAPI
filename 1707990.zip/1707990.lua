-- Lua provided by RyzenAPI
-- Game: Skydance's BEHEMOTH

-- MAIN APPLICATION
addappid(1707990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707991, 1, "573a21de5c170e2cab9f3a65540656d19ff87f616d2746c35d4d7e1470ea4923")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3105160)
