-- Lua provided by RyzenAPI
-- Game: addappid(1707990)

-- MAIN APPLICATION
addappid(1707990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707991, 1, "573a21de5c170e2cab9f3a65540656d19ff87f616d2746c35d4d7e1470ea4923")
