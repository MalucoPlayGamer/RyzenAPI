-- Lua provided by RyzenAPI
-- Game: The Secret Story

-- MAIN APPLICATION
addappid(3367740)
addappid(3532630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367741, 1, "89c7a7713003674ded8d7b2dad7e7a97de1830b16b5ffba116b252d31b1f0ad2")
