-- Lua provided by RyzenAPI 
-- Game: My Last Appointment
addappid(2785980)
addappid(2785981, 1, "e847db1a573160a1c8f0cb5eb8d9a769cdcfd7f6cbe9d777145ae426d7b9d87a")
