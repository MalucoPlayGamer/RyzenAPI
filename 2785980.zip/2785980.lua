-- Lua provided by RyzenAPI
-- Game: My Last Appointment

-- MAIN APPLICATION
addappid(2785980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785981, 1, "e847db1a573160a1c8f0cb5eb8d9a769cdcfd7f6cbe9d777145ae426d7b9d87a")
