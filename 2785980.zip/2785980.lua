-- Lua provided by RyzenAPI
-- Game: My Last Appointment

-- MAIN APPLICATION
addappid(2785980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785981, 1, "e847db1a573160a1c8f0cb5eb8d9a769cdcfd7f6cbe9d777145ae426d7b9d87a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
