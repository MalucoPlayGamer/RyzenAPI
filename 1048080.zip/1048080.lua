-- Lua provided by RyzenAPI
-- Game: Game: aMAZE Easter

-- MAIN APPLICATION
addappid(1048080)
-- Game: addappid(1048080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048081, 1, "1bb24b4142f48653b8a84ad925234263727e8f6a7150c1509f56760f84cde1eb")
