-- Lua provided by SkyAPI 
-- Game: aMAZE Easter
addappid(1048080)
addappid(1048081, 1, "1bb24b4142f48653b8a84ad925234263727e8f6a7150c1509f56760f84cde1eb")
