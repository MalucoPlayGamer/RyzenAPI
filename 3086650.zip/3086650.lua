-- Lua provided by RyzenAPI
-- Game: 3086650

-- MAIN APPLICATION
addappid(3086650)
-- Game: addappid(3086650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086651, 1, "ec2b1335ede721ea856617d67ec3bb67de3885f4c0cb61398658142d964d3a35")
addappid(3086652, 1, "b90ab61dea0e7a5b438108e0ab7bdbb822331af5164f53a2114ec7fdea129e15")
