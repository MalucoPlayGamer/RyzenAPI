-- Lua provided by RyzenAPI 
-- Game: Chaos Domain
addappid(287100)
addappid(287101, 1, "7225559f382dbb35d8fbc5c09f1ed43464814b8f94b37a0094c84fafcfcd8153")
addappid(298690, 0, "d40c98b31a2b1772b7b550c038f2c659b00f6c8c3b8209e6664e0d6b6e161ce0")
