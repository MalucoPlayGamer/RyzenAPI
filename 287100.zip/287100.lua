-- Lua provided by RyzenAPI
-- Game: Chaos Domain

-- MAIN APPLICATION
addappid(287100)

-- MAIN APP DEPOTS / PACKAGES
addappid(287101, 1, "7225559f382dbb35d8fbc5c09f1ed43464814b8f94b37a0094c84fafcfcd8153")
addappid(298690, 0, "d40c98b31a2b1772b7b550c038f2c659b00f6c8c3b8209e6664e0d6b6e161ce0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
