-- Lua provided by RyzenAPI
-- Game: Game: AppID 986790

-- MAIN APPLICATION
addappid(986790)
-- Game: addappid(986790)

-- MAIN APP DEPOTS / PACKAGES
addappid(986791, 1, "5c3d324c49606bce1c6880d4f54598283af397716fba00c924c064a7d2cee21a")
