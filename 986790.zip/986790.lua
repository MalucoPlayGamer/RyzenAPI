-- Lua provided by RyzenAPI
-- Game: AppID 986790

-- MAIN APPLICATION
addappid(986790)

-- MAIN APP DEPOTS / PACKAGES
addappid(986791, 1, "5c3d324c49606bce1c6880d4f54598283af397716fba00c924c064a7d2cee21a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
