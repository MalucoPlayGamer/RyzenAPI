-- Lua provided by RyzenAPI
-- Game: Far Cry Primal

-- MAIN APPLICATION
addappid(371660)
addappid(446130)
addappid(446131)
addappid(446132)
addappid(446133)
addappid(446134)
addappid(446135)
addappid(446140)
addappid(446141)
addappid(446142)
addappid(453360)
addappid(453361)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(371661, 1, "09438b91bfc9be90cdfe09dffc54d5b6296a1c9623059513bb8bf156411b75f9")
addappid(456310, 0, "50be66b7c5295a8547e5ea2d3f92ec783e871cf34431279f1b6c37fef23b1774")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

