-- Lua provided by RyzenAPI
-- Game: AppID 371660

-- MAIN APPLICATION
addappid(371660)
addappid(446130)
addappid(446131)
addappid(446132)
addappid(446133)
addappid(446134)
addappid(446135)
addappid(446140)
addappid(446141)
addappid(446142)
addappid(453360)
addappid(453361)

-- MAIN APP DEPOTS / PACKAGES
addappid(371661, 1, "09438b91bfc9be90cdfe09dffc54d5b6296a1c9623059513bb8bf156411b75f9")
addappid(456310, 0, "50be66b7c5295a8547e5ea2d3f92ec783e871cf34431279f1b6c37fef23b1774")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

