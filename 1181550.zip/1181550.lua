-- Lua provided by RyzenAPI
-- Game: Carnival Hunt

-- MAIN APPLICATION
addappid(1181550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181551,0,"a8021dac5f7a4af175c330dbef4b966af7f7cd5dfe590b02a5bb10f8d63d3b62")

