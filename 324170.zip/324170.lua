-- Lua provided by RyzenAPI
-- Game: addappid(324170)

-- MAIN APPLICATION
addappid(324170)

-- MAIN APP DEPOTS / PACKAGES
addappid(324171, 1, "bed9cfcff4c230a572460268f4de790128dfd90843f2980a086aea1b1f139e81")
