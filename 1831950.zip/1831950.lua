-- Lua provided by RyzenAPI
-- Game: Game: AppID 1831950

-- MAIN APPLICATION
addappid(1831950)
-- Game: addappid(1831950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831951, 1, "166e190d0b0849706b1e30ea1594bce20731db39e77afcf8a72779b395e0f780")
