-- Lua provided by RyzenAPI
-- Game: AppID 623810

-- MAIN APPLICATION
addappid(623810)

-- MAIN APP DEPOTS / PACKAGES
addappid(623811, 1, "ec69585c6fe5ebb6030cbb99139fef6e068b38de1bb911f7e33f712a253f41e6")
addappid(623812, 1, "b36472829f08361ef50c9b72b9d7fae69419bafeeba8f67b500b0aa2aa2291b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
