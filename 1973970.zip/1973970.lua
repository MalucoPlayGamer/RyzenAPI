-- Lua provided by RyzenAPI
-- Game: 雀皇麻雀

-- MAIN APPLICATION
addappid(1973970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973971, 1, "98fa31a6c8c5c856b1c4700dd759e18f5f75b706fab3ca8c2c2b32dc5e35b3a5")
