-- Lua provided by RyzenAPI
-- Game: AppID 1102990

-- MAIN APPLICATION
addappid(1102990)
addappid(1124920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102991, 1, "521bfaf555e5405c5a73cf4f7361a3e8f83fb336edffc9fa2204f2af81acba97")
addappid(1102992, 1, "1542c11b04fc835379172c3aac98db649b17db55abedf41dc49cb908bce4700a")

