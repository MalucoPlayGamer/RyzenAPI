-- Lua provided by RyzenAPI
-- Game: Weird RPG

-- MAIN APPLICATION
addappid(1902710)
-- Game: addappid(1902710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902711, 1, "d3468ffbac12cd92d962cbf311fd31f6618bbb444a0c79ceae1ef5d1143fea13")
