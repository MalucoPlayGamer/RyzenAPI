-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes: The Awakened (2008)

-- MAIN APPLICATION
addappid(11140)
-- Game: addappid(11140)

-- MAIN APP DEPOTS / PACKAGES
addappid(11141, 1, "5959039d53e23e5260a4787741645f00bc69b409c92106fc1df70c4cb29dfc3d")
addappid(11142, 1, "a35ff1c23c38e410c03163b0ab7f0aef0686d647badb1efbc6797e396f23330b")
addappid(11143, 1, "9f9d9738ec799d00ae8febcd5f6a6e173ea3ad71aae5b057374628cb213b844b")
addappid(11144, 1, "341e3e85639869984bfa937981d4218c7b0c997808b080cbf16d14afbc6b9fc8")
addappid(11145, 1, "8575a09b6967308cc6157184ace8896d34df3f3004d496c067cb9c2a3fc2f073")
addappid(11146, 1, "e73a9e252d607e6faafc3205a2aa255e0a99a082d6b55d84bf4a2ec40bb9e057")
