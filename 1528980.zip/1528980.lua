-- Lua provided by SkyAPI 
-- Game: Pit of Ascension
addappid(1528980)
addappid(1528981, 1, "89b0f0687e5047eebe9a54f74ff4b2e6606d34939129473fb90c07d10d287a31")
