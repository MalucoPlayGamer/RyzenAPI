-- Lua provided by RyzenAPI
-- Game: Pit of Ascension

-- MAIN APPLICATION
addappid(1528980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528981, 1, "89b0f0687e5047eebe9a54f74ff4b2e6606d34939129473fb90c07d10d287a31")

