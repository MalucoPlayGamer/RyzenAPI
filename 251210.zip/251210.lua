-- Lua provided by RyzenAPI
-- Game: Hive

-- MAIN APPLICATION
addappid(251210)

-- MAIN APP DEPOTS / PACKAGES
addappid(251211, 1, "c799ec4bbaef7377f2fb894540a4efc75b8260949d69095fbe4cd591fe0aee86")
addappid(251212, 1, "8cbb960e768cb807b00ccc8346b86f2cadee445f55b7ad3ad99a90f12760e057")
addappid(251213, 1, "FD0FECDB86A8ACA9AC09382C3C4E397249BFB70B41EBF1FE2027E9ACE4D16E80")
addappid(251214, 1, "10FD141503432560774E8A3FF8ED1D4A8202BB37D4AF2CC58E067A1C9815C21E")
addappid(251215, 1, "B69113D0730AF5C0506FBE5202DC940ABD749C1356B0FB150E0CCB1105E7ADAB")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(258850)
addappid(258851)
addappid(258852)
