-- Lua provided by RyzenAPI
-- Game: AppID 2923380

-- MAIN APPLICATION
addappid(2923380)
-- Game: addappid(2923380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923381, 1, "59c7b038bb0dc121bc31cc88f99195a61d3ca75108736c5283638c7c5a5076fc")
