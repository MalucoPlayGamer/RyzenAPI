-- Lua provided by RyzenAPI
-- Game: Hard Chip Demo

-- MAIN APPLICATION
addappid(3033160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033161, 1, "f1da77088ca0b02443058d2b82d75205df40488735c28ff476ce6092f6f410b1")
