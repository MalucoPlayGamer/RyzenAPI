-- Lua provided by RyzenAPI
-- Game: 451410

-- MAIN APPLICATION
addappid(451410)

-- MAIN APP DEPOTS / PACKAGES
addappid(451410,0,"67e3cebb44f09bba15f13ebdf92f45b6081fc8a9a9d8774faa91897c6633d58e")
