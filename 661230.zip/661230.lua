-- Lua provided by RyzenAPI
-- Game: AppID 661230

-- MAIN APPLICATION
addappid(661230)
addappid(1251610)
addappid(3276020)

-- MAIN APP DEPOTS / PACKAGES
addappid(661231, 1, "3d84390371a02577d47dfa7fd4161ad0e7352c5c9e160cb1e207924aea4c7a32")

