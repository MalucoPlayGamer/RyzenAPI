-- Lua provided by SkyAPI 
-- Game: Tools Up! Ultimate Edition
addappid(2551920)
addappid(2551921, 1, "87608a10db261f976970560b8b0ad8c1178b933c1e0f11078326b3f0531dcb51")
