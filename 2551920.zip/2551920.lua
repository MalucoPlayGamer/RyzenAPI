-- Lua provided by RyzenAPI
-- Game: Game: Tools Up! Ultimate Edition

-- MAIN APPLICATION
addappid(2551920)
-- Game: addappid(2551920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551921, 1, "87608a10db261f976970560b8b0ad8c1178b933c1e0f11078326b3f0531dcb51")
