-- Lua provided by RyzenAPI
-- Game: 1559790

-- MAIN APPLICATION
addappid(1559790)
-- Game: addappid(1559790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559791, 1, "9c228fdbe0ff1a0c03f096f96f5dbf976d79b01ef6c807c229025ec9250b0995")
