-- Lua provided by RyzenAPI
-- Game: Where Winds Meet

-- MAIN APPLICATION
addappid(3564740)
