-- Lua provided by RyzenAPI
-- Game: AppID 2775600

-- MAIN APPLICATION
addappid(2775600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775601, 1, "d8604dccc274f137c059e2b9ec2fba9872b6b9fbd6c548498fadc7a968e0efc1")
