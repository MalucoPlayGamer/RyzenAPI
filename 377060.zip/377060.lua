-- Lua provided by RyzenAPI
-- Game: On a Roll

-- MAIN APPLICATION
addappid(377060)

-- MAIN APP DEPOTS / PACKAGES
addappid(377061, 1, "1e41b7e9f778554ac3d570ecd08ed024bc2063542c6f43bdf4db9084c1e976c2")
