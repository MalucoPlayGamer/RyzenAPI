-- Lua provided by RyzenAPI
-- Game: Turkish Throne

-- MAIN APPLICATION
addappid(2839450)
addappid(2946730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839451, 1, "b763e5212d6f405715a8c31093ffd46b9ac26aa9469860c49529e0db06f107fa")

