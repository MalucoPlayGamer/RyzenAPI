-- Lua provided by RyzenAPI 
-- Game: Fastlane Bowling
addappid(1644930)
addappid(1644931, 1, "dd9b13b5630d9ae6c8d5036a92cd5b59484b1df0cced0b32db4f62c3f97bc50a")
