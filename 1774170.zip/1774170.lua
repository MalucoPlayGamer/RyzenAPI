-- Lua provided by RyzenAPI
-- Game: Robin Hood - Sherwood Builders Demo

-- MAIN APPLICATION
addappid(1774170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774171, 1, "0c1cbaeffba7c1822ee29fb87ed369454a22a886e494f9b333594b57af43160b")
