-- Lua provided by RyzenAPI
-- Game: 231250

-- MAIN APPLICATION
addappid(231250)
-- Game: addappid(231250)

-- MAIN APP DEPOTS / PACKAGES
addappid(231251, 1, "30da6ae92d706d94be5c062a0c57adff4ef76ffea83a4f1e79dff15fd69f0a92")
