-- Lua provided by RyzenAPI
-- Game: addappid(2057170)

-- MAIN APPLICATION
addappid(2057170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057171, 1, "9937e0d0bef338ccd02d6179255f7f613dd5c93cd540f7ac230b08858439ca68")
