-- Lua provided by RyzenAPI
-- Game: AppID 1193990

-- MAIN APPLICATION
addappid(1193990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193991, 1, "a10d0c1c9985f09fbdd89a3f852de692afa48bc2b2e340da265a190440ac8e1a")

