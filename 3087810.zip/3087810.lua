-- Lua provided by RyzenAPI
-- Game: Recesses

-- MAIN APPLICATION
addappid(3087810)
-- Game: addappid(3087810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087811, 1, "a44085d4ba5d3448d3c03b1d946e4dd5a11e57b4624eceb20b1e3de96bedc109")
