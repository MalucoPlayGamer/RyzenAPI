-- Lua provided by SkyAPI 
-- Game: Recesses
addappid(3087810)
addappid(3087811, 1, "a44085d4ba5d3448d3c03b1d946e4dd5a11e57b4624eceb20b1e3de96bedc109")
