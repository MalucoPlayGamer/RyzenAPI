-- Lua provided by RyzenAPI
-- Game: Game: InnerCube

-- MAIN APPLICATION
addappid(344270)
-- Game: addappid(344270)

-- MAIN APP DEPOTS / PACKAGES
addappid(344271, 1, "47eebf15c3082e8eddafe695f539e118e667b4e5d08f514c1644b6ca6a14c3dc")
