-- Lua provided by RyzenAPI
-- Game: Game: AppID 843010

-- MAIN APPLICATION
addappid(843010)
-- Game: addappid(843010)

-- MAIN APP DEPOTS / PACKAGES
addappid(843011, 1, "87fd4a215b0d9fb49a49985e84ed97d3d5b6171bea5bcb66554414727049e271")
