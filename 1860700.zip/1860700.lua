-- Lua provided by RyzenAPI
-- Game: 1860700

-- MAIN APPLICATION
addappid(1860700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860703,0,"8ee5e2cad7dec5f7abd844162610b9bb4eff49ab0f139bf768e730a75c760d66")

