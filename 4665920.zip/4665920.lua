-- Lua provided by RyzenAPI
-- Game: Mad Merchant

-- MAIN APPLICATION
addappid(4665920)

-- MAIN APP DEPOTS / PACKAGES
addappid(4665921,0,"e402c57beb435d1843d3b64794eb835300a83165c34ffa9314e7f54a53432f13")

