-- Lua provided by RyzenAPI
-- Game: addappid(1562780)

-- MAIN APPLICATION
addappid(1562780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562781, 1, "513a2f808310ea89e6d1c6229383c89688a1b1ade138754abae277a32b28b85d")
