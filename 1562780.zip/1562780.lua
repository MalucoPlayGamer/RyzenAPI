-- Lua provided by SkyAPI 
-- Game: Broilers
addappid(1562780)
addappid(1562781, 1, "513a2f808310ea89e6d1c6229383c89688a1b1ade138754abae277a32b28b85d")
