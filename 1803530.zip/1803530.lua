-- Lua provided by RyzenAPI
-- Game: 经典象棋

-- MAIN APPLICATION
addappid(1803530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803531, 1, "1e2755d5933e7230dd9610e12e951fe8ec26eff8b2f3192f56505c832c27c839")

