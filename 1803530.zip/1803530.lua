-- Lua provided by RyzenAPI
-- Game: 经典象棋

-- MAIN APPLICATION
addappid(1803530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1803531, 1, "1e2755d5933e7230dd9610e12e951fe8ec26eff8b2f3192f56505c832c27c839")

