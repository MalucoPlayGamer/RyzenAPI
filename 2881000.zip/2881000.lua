-- Lua provided by RyzenAPI
-- Game: Game: Meteorite Z: The Apocalypse

-- MAIN APPLICATION
addappid(2881000)
-- Game: addappid(2881000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881001, 1, "741be3649366e85ce65632f6594e15f2ba3770b8dfbbd281bdca47fe4208ab93")
