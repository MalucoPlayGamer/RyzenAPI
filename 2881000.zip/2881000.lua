-- Lua provided by SkyAPI 
-- Game: Meteorite Z: The Apocalypse
addappid(2881000)
addappid(2881001, 1, "741be3649366e85ce65632f6594e15f2ba3770b8dfbbd281bdca47fe4208ab93")
