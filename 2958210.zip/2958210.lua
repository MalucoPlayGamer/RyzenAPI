-- 2958210's Lua and Manifest Created by Hubcap Manifest
-- Connie and the Essence of Chaos
-- Created: August 06, 2026 at 11:23:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2958210) -- Connie and the Essence of Chaos
-- MAIN APP DEPOTS
addappid(2958211, 1, "0b944888276a3480f5c7aa4623a74cd3c974c30372320a26ffab01df3c57d672") -- Depot 2958211
setManifestid(2958211, "5982019145076752776", 426379446)