-- Lua provided by RyzenAPI
-- Game: Connie and the Essence of Chaos

-- MAIN APPLICATION
addappid(2958210) -- Connie and the Essence of Chaos

-- MAIN APP DEPOTS / PACKAGES
addappid(2958211, 1, "0b944888276a3480f5c7aa4623a74cd3c974c30372320a26ffab01df3c57d672") -- Depot 2958211

