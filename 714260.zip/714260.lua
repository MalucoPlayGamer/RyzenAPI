-- Lua provided by RyzenAPI
-- Game: AppID 714260

-- MAIN APPLICATION
addappid(714260)

-- MAIN APP DEPOTS / PACKAGES
addappid(714261, 1, "bda06787dee785837e9341d3027ab0d55f3e40db72efaa97e7e604cb22c0cb24")
