-- Lua provided by RyzenAPI 
-- Game: Realms of the Haunting
addappid(292390)
addappid(292391, 1, "7cce0bc1f7017d9afac48d540a472323f71cdf144e619dc66631e316529b82a8")
