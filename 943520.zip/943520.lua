-- Lua provided by RyzenAPI 
-- Game: Pixie Panic Garden
addappid(943520)
addappid(943521, 1, "c49eaa81333d584e25c3d008549d42ae36bc0aa6288e015b0ebef7e290c3eedd")
