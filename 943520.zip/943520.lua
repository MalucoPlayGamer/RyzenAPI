-- Lua provided by RyzenAPI
-- Game: 943520

-- MAIN APPLICATION
addappid(943520)
-- Game: addappid(943520)

-- MAIN APP DEPOTS / PACKAGES
addappid(943521, 1, "c49eaa81333d584e25c3d008549d42ae36bc0aa6288e015b0ebef7e290c3eedd")
