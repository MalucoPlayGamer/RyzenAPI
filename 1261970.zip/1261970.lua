-- Lua provided by RyzenAPI
-- Game: Game: AppID 1261970

-- MAIN APPLICATION
addappid(1261970)
-- Game: addappid(1261970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261971, 1, "00c3dc5d10a87585d912f999e7ca5f6cec318ef0a7c86f24ba8d0adccc0fe932")
