-- Lua provided by RyzenAPI
-- Game: Spiders Everywhere

-- MAIN APPLICATION
addappid(1851390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851392,0,"3aad2121281a436f1dcfc95e0ed050078d81de6e5009da5e7ac129773f817bde")

