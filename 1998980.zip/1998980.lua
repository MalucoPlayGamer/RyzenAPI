-- Lua provided by RyzenAPI
-- Game: Peppa Pig: World Adventures

-- MAIN APPLICATION
addappid(1998980)
-- Game: addappid(1998980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998981, 1, "4d53e2d33713f352c0fcee26e3aa150013317fc5e72f39e5ad24310837e54053")
