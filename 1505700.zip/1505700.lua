-- Lua provided by RyzenAPI 
-- Game: Berzerk Flashback
addappid(1505700)
addappid(1505701, 1, "0a219f9d43de07de4efea538482c0ad06812a79937fd5f196c4e0aeb1caf6828")
