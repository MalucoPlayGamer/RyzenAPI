-- Lua provided by RyzenAPI
-- Game: 415610

-- MAIN APPLICATION
addappid(415610)
-- Game: addappid(415610)

-- MAIN APP DEPOTS / PACKAGES
addappid(415611, 1, "b98315e093bcd3705f50a4e54fb32dd3c2af758956c57e5808254f28697d2a5b")
addappid(415612, 1, "bdeaa1d1e38cf70c944be66d45abf1198e78d1be111dc40a1f3de32b4156760d")
