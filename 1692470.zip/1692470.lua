-- Lua provided by RyzenAPI
-- Game: Game: The Trader

-- MAIN APPLICATION
addappid(1692470)
-- Game: addappid(1692470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692471, 1, "661e2e6c669a6056468a3de365d3a44c844a9931a637d1fcaeab2f5548081336")
