-- Lua provided by RyzenAPI
-- Game: Space Mercenary Shooter : Episode 1

-- MAIN APPLICATION
addappid(1096630)
-- Game: addappid(1096630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096631, 1, "8803df754a7d2ee9e40b32c1f79bf2c0916ef2b7527ef32f6559668a6640cd6c")
