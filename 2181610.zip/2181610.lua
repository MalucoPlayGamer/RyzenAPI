-- Lua provided by RyzenAPI
-- Game: Heretic's Fork

-- MAIN APPLICATION
addappid(2181610)
addappid(2589740)
addappid(2744540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181611, 1, "5a03d9d0c80ec83426e64dc7850226cd8471d4715a8d6274913d832946937f1a")

