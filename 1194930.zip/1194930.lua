-- Lua provided by RyzenAPI
-- Game: addappid(1194930)

-- MAIN APPLICATION
addappid(1194930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194931, 1, "3a9a47b2ed305afe0d731458634b6b080e0f22c327f46d9219db697e57968a0c")
