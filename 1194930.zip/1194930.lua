-- Lua provided by RyzenAPI
-- Game: Blackthorn Arena

-- MAIN APPLICATION
addappid(1194930)
addappid(1352030)
addappid(1504590)
addappid(1665680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194931,0,"3a9a47b2ed305afe0d731458634b6b080e0f22c327f46d9219db697e57968a0c")

