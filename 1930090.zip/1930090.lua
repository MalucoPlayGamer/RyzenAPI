-- Lua provided by RyzenAPI
-- Game: Pirate Solitaire 2

-- MAIN APPLICATION
addappid(1930090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930091, 1, "616898842cc304ba0004f4df93de0e0d1bf8ed36ce821cf4e85509e4b72c3b70")
addappid(1930094, 1, "65c360ef2f845cb6f6c26a8d6fc6f8efeea14c61ec02dae4123d348578d8674b")
