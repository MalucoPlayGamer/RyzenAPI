-- Lua provided by RyzenAPI
-- Game: Sill Sticks

-- MAIN APPLICATION
addappid(4861510)
addappid(4891680)
addappid(4891690)

