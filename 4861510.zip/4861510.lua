-- Lua provided by RyzenAPI
-- Game: Sill Sticks

-- MAIN APPLICATION
addappid(4861510)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4891680)
addappid(4891690)
