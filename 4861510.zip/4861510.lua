-- Lua provided by RyzenAPI
-- Game: Sill Sticks

-- MAIN APPLICATION
addappid(4861510)

