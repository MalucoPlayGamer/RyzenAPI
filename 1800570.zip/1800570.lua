-- Lua provided by RyzenAPI
-- Game: Pet Vet 3D Animal Hospital

-- MAIN APPLICATION
addappid(1800570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800573,0,"44812ecb80a534ca7f02021404bac3ea5257794165b496ca4dff8fec64f6010d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
