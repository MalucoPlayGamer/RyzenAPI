-- Lua provided by RyzenAPI
-- Game: 1800570

-- MAIN APPLICATION
addappid(1800570)
-- Game: addappid(1800570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800573,0,"44812ecb80a534ca7f02021404bac3ea5257794165b496ca4dff8fec64f6010d")
