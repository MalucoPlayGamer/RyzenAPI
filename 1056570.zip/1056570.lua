-- Lua provided by RyzenAPI
-- Game: TAISHO x ALICE episode 1

-- MAIN APPLICATION
addappid(1056570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056571, 1, "c990fd4739f120ae914e1c12b60948a38b5faaa5de09f4f5204ba0305402f31c")
