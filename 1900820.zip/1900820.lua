-- Lua provided by RyzenAPI
-- Game: addappid(1900820)

-- MAIN APPLICATION
addappid(1900820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900821, 1, "4cb7f88c74eeaa1382795b99d31fe535cf3cba28ff89fd02257c7d412e8641dc")
