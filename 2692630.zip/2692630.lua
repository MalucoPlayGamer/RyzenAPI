-- Lua provided by RyzenAPI
-- Game: Lunacid: Original Soundtrack

-- MAIN APPLICATION
addappid(2692630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692631, 1, "c55d03c26f2c777e6c444038fa15728a7be37624dd7e116b9f6b40e674968876")

