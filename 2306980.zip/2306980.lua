-- Lua provided by RyzenAPI
-- Game: Replik Survivors

-- MAIN APPLICATION
addappid(2306980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2306981, 1, "9b5b6e49f67d2b8123eeecfd9b7fa129150244702b53d99e27dee7a831ed60cf")

