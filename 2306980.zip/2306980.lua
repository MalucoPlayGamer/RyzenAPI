-- Lua provided by RyzenAPI
-- Game: Replik Survivors

-- MAIN APPLICATION
addappid(2306980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306981, 1, "9b5b6e49f67d2b8123eeecfd9b7fa129150244702b53d99e27dee7a831ed60cf")
