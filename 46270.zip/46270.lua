-- Lua provided by RyzenAPI 
-- Game: Star Wolves
addappid(46270)
addappid(46271, 1, "0f919d5adf24e874b9645ec5a30a86898c6a37ea78e4be4b222dc5a995fb979d")
addappid(46272, 1, "8323218a6ee4eeebced88d3c39d04d0c66c5f5f9821cf2e8cdd6945fcbe0866b")
addappid(46273, 1, "8f4b7db6dc16ceee78c73d01c6203ca508e646fcee8bd4fc1af456aa2620548e")
addappid(46274, 1, "6fe803a5f23306415b9e8c090de37a71d7c3e8c20eb09ecbdb3eb02cc4441bd6")
