-- Lua provided by RyzenAPI
-- Game: Paranoid Comic

-- MAIN APPLICATION
addappid(2732560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732560,0,"30d024dc31b1f32a4f4710b1bdcce3e78365917a08b3e344490a1d581a23f45a")
