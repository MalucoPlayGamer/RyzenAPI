-- Lua provided by RyzenAPI
-- Game: Game: AppID 2936880

-- MAIN APPLICATION
addappid(2936880)
-- Game: addappid(2936880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936881, 1, "7eaf2b2b1dfbbd1f6b9b3b7f3030b2c870baa48991d5787af6d79c1a78092c36")
