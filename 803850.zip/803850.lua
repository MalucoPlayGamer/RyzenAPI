-- Lua provided by RyzenAPI 
-- Game: Pixelpunk XL
addappid(803850)
addappid(803851, 1, "3abef54eef8734181e379c8b84494e77df1047fe96f005211dd33826a2b8a269")
