-- Lua provided by RyzenAPI
-- Game: Pixelpunk XL

-- MAIN APPLICATION
addappid(803850)

-- MAIN APP DEPOTS / PACKAGES
addappid(803851, 1, "3abef54eef8734181e379c8b84494e77df1047fe96f005211dd33826a2b8a269")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
