-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1136020)
addappid(1136021)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136022,0,"f6fd4a41112d7eafbd2309a8395a373d7d7702130a8ac4b6ddbe9b0e24d44827")
