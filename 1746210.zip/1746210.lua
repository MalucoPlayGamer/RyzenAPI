-- Lua provided by RyzenAPI
-- Game: 日记簿

-- MAIN APPLICATION
addappid(1746210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746211, 1, "1ae7561ddd23fc3637810940e18c9679fcf68bdc23ae1f7143168ad99551caa3")
