-- Lua provided by RyzenAPI 
-- Game: AppID 1088400
addappid(1088400)
addappid(1088401, 1, "b6646180f6a3d76ba93bc2caeb30abc7098c58a2669f6e97956ca3f79ebbeb3e")
