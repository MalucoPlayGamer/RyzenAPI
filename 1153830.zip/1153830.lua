-- Lua provided by SkyAPI 
-- Game: AppID 1153830
addappid(1153830)
addappid(1153831, 1, "0eb363b730bbb6e4d6ea5af65a2e79a23afd378b85cb483e01dbf60147b092f8")
