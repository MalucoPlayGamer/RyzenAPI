-- Lua provided by RyzenAPI
-- Game: addappid(1104330)

-- MAIN APPLICATION
addappid(1104330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104331, 1, "8df331e8e4dda34da7b2945eb629fb5b7dceea04da5a994b40c5ae2e139c2a9f")
addappid(1104332, 1, "e8fecd7030c1e43d78b3fa233fe5c332e5701aeb47879c9403ab4ab6071744e3")
