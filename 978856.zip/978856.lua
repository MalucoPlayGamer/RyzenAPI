-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Lu Lingqi (High School Girls Costume) / 呂玲綺 「女子高生風コスチューム」

-- MAIN APPLICATION
addappid(978856)
-- Game: addappid(978856)

-- MAIN APP DEPOTS / PACKAGES
addappid(978856,0,"3412eced9e0e923698a1e3209a61f0a8f1bca550b6cdff63ca0da8740188aa7a")
