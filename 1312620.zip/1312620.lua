-- Lua provided by RyzenAPI
-- Game: 1312620

-- MAIN APPLICATION
addappid(1102371)
addappid(1312620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102372,0,"c91808681bbba11b1dac00687152ac60cc6b65f15fd2c3e21f54ae98cec79d3c")

