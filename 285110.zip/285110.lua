-- Lua provided by RyzenAPI
-- Game: GearCity

-- MAIN APPLICATION
addappid(285110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(285111, 1, "61bce14c60e5e2c8f840f855735e57ad43d87702204c298ef9473504f7ed1d8f")
addappid(285112, 1, "2ad1e422ac64c4317859d51fbc9822d874237bf78142fc7c5f37edb7773ad6d0")
addappid(285113, 1, "6d75db06b429295da0e92c58a7be6f43a77e90f8274188ee078f85c622ff5d3f")
addappid(285114, 1, "322a0df0407a31bb105e4b1eafd218ec42cdf2a7d7a7cac2f3e7e341f53f97d3")
addappid(285115, 1, "86c031671ef95628052c3b12ea09029e38ed65766b3f4c556d80d3fbb9228d4e")
addappid(285116, 1, "7ed3ec854999242f3bc6b69713a026c30a0ad3bd7f8c0805898bc43a462cdf4f")

