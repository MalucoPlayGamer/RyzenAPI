-- Lua provided by SkyAPI 
-- Game: AppID 2020890
addappid(2020890)
addappid(2020891, 1, "ac0634153daa913b816a67ea2733ef10eafe7da8af78c147c44e37a92757b0fd")
