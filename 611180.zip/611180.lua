-- Lua provided by RyzenAPI
-- Game: Super Street: The Game

-- MAIN APPLICATION
addappid(611180)

-- MAIN APP DEPOTS / PACKAGES
addappid(611181, 1, "9d75a468a91c4f84d46ed8ed4b1cbc6daea30d7b01b94047cd15d76bf9c439cb")
