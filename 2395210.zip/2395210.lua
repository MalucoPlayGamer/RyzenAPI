-- Lua provided by RyzenAPI
-- Game: Tony Hawk's™ Pro Skater™ 1 + 2

-- MAIN APPLICATION
addappid(2395210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395211, 1, "ec38e51d7550cee26aa882d00fd667e7151be357001e9705d7cad29c5d74f9cc")
addappid(2395212, 1, "075552dcaa4900b55ed24f823d7b1056af53aa2d62af4a453fef7f14dc6e44a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2586220)
