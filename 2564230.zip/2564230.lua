-- Lua provided by RyzenAPI
-- Game: addappid(2564230)

-- MAIN APPLICATION
addappid(2564230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564231, 1, "661fe4311e3a8d90f2a3b93df07485d283a0e7c2f7624fb04c62cfe558d877d7")
