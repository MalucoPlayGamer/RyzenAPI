-- Lua provided by RyzenAPI
-- Game: 3308560

-- MAIN APPLICATION
addappid(3308560)
-- Game: addappid(3308560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308561, 1, "dbd1ca2b61866dce87a1e2c2afe20bd237ec0fc74fc3536bc30182042be46bcd")
