-- Lua provided by RyzenAPI
-- Game: 2983800

-- MAIN APPLICATION
addappid(2983800)
-- Game: addappid(2983800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983801, 1, "e35bf7dd586c31037f7b84744d179de3f8a523ac4b59ab22f154c8810d40ce51")
