-- Lua provided by RyzenAPI
-- Game: Gravity Sketch VR

-- MAIN APPLICATION
addappid(551370)
addappid(623830)
addappid(691170)

-- MAIN APP DEPOTS / PACKAGES
addappid(551371, 1, "2feb1056b1d98332407748b5ca95aca786d34533776b0dd42276db157504526d")

