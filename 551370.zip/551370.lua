-- Lua provided by RyzenAPI
-- Game: Game: AppID 551370

-- MAIN APPLICATION
addappid(551370)
-- Game: addappid(551370)

-- MAIN APP DEPOTS / PACKAGES
addappid(551371, 1, "2feb1056b1d98332407748b5ca95aca786d34533776b0dd42276db157504526d")
