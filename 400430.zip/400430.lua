-- Lua provided by RyzenAPI
-- Game: The Vanishing of Ethan Carter Redux

-- MAIN APPLICATION
addappid(400430)
-- Game: addappid(400430)

-- MAIN APP DEPOTS / PACKAGES
addappid(400431, 1, "25825486346c9fa38d02577557936d805ac169cd8a79a6143140b5a135bb585f")
