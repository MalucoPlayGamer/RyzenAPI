-- Lua provided by RyzenAPI
-- Game: Mirror News Center

-- MAIN APPLICATION
addappid(1856540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856541, 1, "d6e65f39c752056082ab498d5b276d3e3f63dd45120f0f2bd5a1c53cc3275ca6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
