-- Lua provided by RyzenAPI
-- Game: 1856540

-- MAIN APPLICATION
addappid(1856540)
-- Game: addappid(1856540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856541, 1, "d6e65f39c752056082ab498d5b276d3e3f63dd45120f0f2bd5a1c53cc3275ca6")
