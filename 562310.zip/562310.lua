-- Lua provided by RyzenAPI
-- Game: Game: Spacecats with Lasers : The Outerspace

-- MAIN APPLICATION
addappid(562310)
-- Game: addappid(562310)

-- MAIN APP DEPOTS / PACKAGES
addappid(562311, 1, "8575510282c89d2bb61fa33d65f1fa56b4322afde774796e15ebbc83565022a9")
addappid(562312, 1, "4cbc5c58b87aed21d29b8657ba96adb1f3a0607bedb5ae4933332da3ae2be500")
addappid(562313, 1, "f823179ac6b0b3a6786f4170cc969ad09cef115605eb0c06c702ded1a44a1a0d")
addappid(562314, 1, "ceb6684f1c69f6668b2562882b48cbafbcf37dbcef5c3680a3a324d6d448f122")
