-- Lua provided by RyzenAPI
-- Game: Dave's Fun Algebra Class: Remastered

-- MAIN APPLICATION
addappid(2570390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570392,0,"4d44b4f5a94f1d6a458a8710cbfbdf889e87b0b0289fa91c11b2f42988058733")
addappid(2570393,0,"a597d978bf28a282a71b867dd6070daf62ba569d9601992174f084dffe765059")
addappid(2570394,0,"eb8b9b0224bbbceaf34ff3e39c7dc3d1b84f42b94620b04aefece14739f73025")
