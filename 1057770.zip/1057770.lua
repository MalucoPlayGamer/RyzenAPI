-- Lua provided by RyzenAPI
-- Game: addappid(1057770)

-- MAIN APPLICATION
addappid(1057770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057771, 1, "8f6f9ecd61c3e22dd9c94df1485fb3393b857847e51c9db81621e936a4e67020")
