-- Lua provided by RyzenAPI
-- Game: Story of one night

-- MAIN APPLICATION
addappid(1057770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1057771, 1, "8f6f9ecd61c3e22dd9c94df1485fb3393b857847e51c9db81621e936a4e67020")
