-- Lua provided by RyzenAPI
-- Game: Retail Company Simulator

-- MAIN APPLICATION
addappid(3089130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089131, 1, "5786ccb1d1879ab3e1ea79533b18f26a2738a511b8085872aef7a6a38e8a19bd")

