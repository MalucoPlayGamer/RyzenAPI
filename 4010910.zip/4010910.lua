-- 4010910's Lua and Manifest Created by Hubcap Manifest
-- MeowSon
-- Created: June 03, 2026 at 00:12:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4010910) -- MeowSon
-- MAIN APP DEPOTS
addappid(4010911, 1, "40fa70dda46f81ac9fdd0e6323df529a4bbd3e42b65c747358086e765d823e4f") -- Depot 4010911
setManifestid(4010911, "2675420714315826367", 688932683)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)