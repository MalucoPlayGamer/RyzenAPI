-- Lua provided by RyzenAPI
-- Game: 2228010

-- MAIN APPLICATION
addappid(2228010)
-- Game: addappid(2228010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228011, 1, "6dba1cff1e064d8eb235cc3bfdf8fea85dd25e8f8980a61a45bd3ec2e1d82e28")
