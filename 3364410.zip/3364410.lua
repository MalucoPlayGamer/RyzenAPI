-- Lua provided by RyzenAPI
-- Game: 3364410

-- MAIN APPLICATION
addappid(3364410)
-- Game: addappid(3364410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364410,0,"d90d04dbc2410daa5e68424fe1b1d14b48c6aeda28322bd25752f6a86109042a")
