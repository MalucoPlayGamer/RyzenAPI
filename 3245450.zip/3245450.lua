-- Lua provided by RyzenAPI
-- Game: No Heroes Here 2 Demo

-- MAIN APPLICATION
addappid(3245450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245451, 1, "21120da151205c78bc66196726c3a15066eaa1c963cb84084bfb9b111fcf3356")
