-- Lua provided by RyzenAPI
-- Game: Press X to Not Die

-- MAIN APPLICATION
addappid(402330)

-- MAIN APP DEPOTS / PACKAGES
addappid(402331, 1, "33a12e3ac6bc15a808f572e40b036a5ae8bcc564319ee435d33b7886231f1b6f")
addappid(402332, 1, "3f1f91c5e7d0688af0c77a0ca1cd4c10470f89352cafd7569ed066003c656b81")
addappid(402333, 1, "a50749aea2292211368e5c6a5e4cfdfcc9349883ddfadd285b8a4fa3c24188ab")
addappid(402334, 1, "789cc217a68816052e45315fbe01aac7af783ca3b0b5fc10e0d9a8f813c014e0")
addappid(402335, 1, "b690c52814d085ac5b5cdc8f67165a2df1145745f8c01d429a666fd11ca09e9a")
addappid(497970, 0, "1cb9d456c478cf6f2adad094e17ef1cbff129d67fc42aa24de63c295872204d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
