-- Lua provided by RyzenAPI
-- Game: Wallpaper Last Fantasy Hentai #2

-- MAIN APPLICATION
addappid(1356510)
-- Game: addappid(1356510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356510,0,"6e6b3297903842c744d56c8cb36cc91c587557a64c21b65a48ba3290bc3cba95")
