-- Lua provided by RyzenAPI
-- Game: Play Together Playtest

-- MAIN APPLICATION
addappid(2671870)
-- Game: addappid(2671870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671871, 1, "63c4e43722ec4cdfdf8cc9ee0fa9eade292a995ee5040b1fc046d58829fad122")
