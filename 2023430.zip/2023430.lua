-- Lua provided by RyzenAPI
-- Game: Hermea

-- MAIN APPLICATION
addappid(2023430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2023431, 1, "612cc1e86859ebde9a2959868babcbdac6c548cd4fa1d6e3cd1ecf4afe26e2a6")

