-- Lua provided by RyzenAPI
-- Game: Complex Complex

-- MAIN APPLICATION
addappid(1265790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265791, 1, "dab7809017a331ba7ac2ff9e9a47f97c5ac766ed8dd0b9dd57a4f6bc4498c0b8")

