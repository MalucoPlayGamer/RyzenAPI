-- Lua provided by RyzenAPI
-- Game: Game: Neva

-- MAIN APPLICATION
addappid(2420660)
-- Game: addappid(2420660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420661, 1, "5ca6d5bbd9fbd7ad5bf1afb46519bbd0402cc2f4a4adb1fb7bd21fb6aebeb8b4")
addappid(2420662, 1, "0b2929a37f8fc545a55e1eb47dfadd71c8f8ece5ab661230b33319455bb2dbfb")
addappid(2420663, 1, "e1b77f2ffd255ee62c486b6a270418881e9acd62293343a99e46e6eac9e055bf")
addappid(3160860, 0, "82fa5ada5ff666e82dfefd7a52ff2b0463028507255188d504b2daf377d51e61")
