-- Lua provided by RyzenAPI 
-- Game: Quiz Pro - Guess Pictures
addappid(1366830)
addappid(1366831, 1, "6dc00c432642cfc352e7bf4369125c7e6ba38f1eb8af110a5df086f1b6fef9a6")
addappid(1369380)
