-- Lua provided by RyzenAPI
-- Game: 2443990

-- MAIN APPLICATION
addappid(2443990)
addappid(2443993)
-- Game: addappid(2443990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443992,0,"17eacecb2b34603820124815ea679a6b0304cf78088b920820ddbd3878bb7683")
