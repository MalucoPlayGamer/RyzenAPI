-- Lua provided by RyzenAPI
-- Game: 2587190

-- MAIN APPLICATION
addappid(2587190)
-- Game: addappid(2587190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587191, 1, "e5a7be9b60e40fb260942e7cedc1bb323ef622b01dd049a4549ceb762a372343")
