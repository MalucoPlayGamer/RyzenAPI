-- Lua provided by SkyAPI 
-- Game: AppID 1320710
addappid(1320710)
addappid(1320711, 1, "f9ae770b016b691ccbaa6c93de16e9b301620ff15bd41e27acf1f4821b7f4121")
