-- Lua provided by RyzenAPI
-- Game: HEAVEN SEEKER ――The Savior of This Cruel World

-- MAIN APPLICATION
addappid(2865230)
addappid(3227440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865231, 1, "cacb7e2580465b9365628d8bdc5f9d64f6ab035b7234f4ce5860f58246b0d2ce")
