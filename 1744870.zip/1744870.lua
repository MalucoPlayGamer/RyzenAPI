-- Lua provided by RyzenAPI 
-- Game: The Chrono Jotter Original Soundtrack
addappid(1744870)
addappid(1744871, 1, "d18a671592ef82a4d2a9f7233eff3263f686ff30f3d4e16ab6d001d3ea7049a7")
