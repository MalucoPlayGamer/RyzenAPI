-- Lua provided by RyzenAPI
-- Game: The Chrono Jotter Original Soundtrack

-- MAIN APPLICATION
addappid(1744870)
-- Game: addappid(1744870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744871, 1, "d18a671592ef82a4d2a9f7233eff3263f686ff30f3d4e16ab6d001d3ea7049a7")
