-- Lua provided by RyzenAPI
-- Game: Game: AppID 576010

-- MAIN APPLICATION
addappid(576010)
-- Game: addappid(576010)

-- MAIN APP DEPOTS / PACKAGES
addappid(576011, 1, "a8349f5b5fe0c5789f7ef5d487c3f35e6ce8416d9ea6c864246717c7842c937a")
addappid(576012, 1, "2e9b6ccbd3377ac4a34e08c5b18187dda52bff4d29ca657932ed975b24369548")
addappid(576013, 1, "457cdeb9b58574471c2c0265e4ea471c6facadd4afe9600d1f538cc851ff6386")
