-- Lua provided by RyzenAPI
-- Game: Riptide GP2

-- MAIN APPLICATION
addappid(257790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(257791, 1, "ba71e123a7c9c64fb5f50f4d44a73133e0c088f81352d329f59f571010d9e72e")
