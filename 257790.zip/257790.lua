-- Lua provided by RyzenAPI
-- Game: Game: AppID 257790

-- MAIN APPLICATION
addappid(257790)
-- Game: addappid(257790)

-- MAIN APP DEPOTS / PACKAGES
addappid(257791, 1, "ba71e123a7c9c64fb5f50f4d44a73133e0c088f81352d329f59f571010d9e72e")
