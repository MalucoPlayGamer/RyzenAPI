-- Lua provided by RyzenAPI
-- Game: 1215060

-- MAIN APPLICATION
addappid(1215060)
-- Game: addappid(1215060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215061, 1, "1b53824d96cd2826e4ba15fded81722abd007e4e8a422a960cda769b3d3c8c8b")
