-- Lua provided by RyzenAPI
-- Game: Viki Spotter: Shopping

-- MAIN APPLICATION
addappid(829540)

-- MAIN APP DEPOTS / PACKAGES
addappid(829541, 1, "6b7d20e93698421545d0118a29fb0d7c46dc0865aa76839ba88dff3596fa1dff")
