-- Lua provided by RyzenAPI
-- Game: 3063420

-- MAIN APPLICATION
addappid(3063420)
-- Game: addappid(3063420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063421, 1, "862d57772c8647b13737d28481bab2e24261ddc3ff4473fce7111471be2b5eb7")
