-- Lua provided by RyzenAPI
-- Game: FUSER™ - Modern English - "I Melt With You"

-- MAIN APPLICATION
addappid(1536764)
-- Game: addappid(1536764)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536764,0,"4ab6d20a11f11040a4923be0ab2187d11c9897559cbf758651d9ddeb13b3f87f")
