-- Lua provided by RyzenAPI
-- Game: The Inn-Sanity

-- MAIN APPLICATION
addappid(2688570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688571, 1, "77496ac0aabbc8afeed0af2d9d7610fc5ba54ddc8ad823a98f45d0f70b4cc7f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
