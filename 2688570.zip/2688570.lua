-- Lua provided by RyzenAPI
-- Game: Game: The Inn-Sanity

-- MAIN APPLICATION
addappid(2688570)
-- Game: addappid(2688570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688571, 1, "77496ac0aabbc8afeed0af2d9d7610fc5ba54ddc8ad823a98f45d0f70b4cc7f4")
