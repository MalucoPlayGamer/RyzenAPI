-- Lua provided by RyzenAPI 
-- Game: Roles & Dice
addappid(2560120)
addappid(2560121, 1, "a13d3789b8c478dfee223e17fd32b6a2be7ea89025a2d93d02aef7319ec97783")
