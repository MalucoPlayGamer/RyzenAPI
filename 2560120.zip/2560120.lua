-- Lua provided by RyzenAPI
-- Game: Roles & Dice

-- MAIN APPLICATION
addappid(2560120)
-- Game: addappid(2560120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560121, 1, "a13d3789b8c478dfee223e17fd32b6a2be7ea89025a2d93d02aef7319ec97783")
