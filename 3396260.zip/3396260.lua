-- Lua provided by RyzenAPI
-- Game: Minutescape Demo

-- MAIN APPLICATION
addappid(3396260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396261, 1, "a9dfdb0792bcc7f74b592e4ec5316784e2c209fe714365fa187c3e9c2ce7042a")
