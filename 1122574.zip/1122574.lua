-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1122574)
-- Game: addappid(1122574)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122574,0,"6b330934a9d23655c91babaa30efb128003ed7a5b3488624692e58817fa12a25")
