-- Lua provided by RyzenAPI
-- Game: AppID 2746080

-- MAIN APPLICATION
addappid(2746080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746081, 1, "7d2771daad794485bd58ea9ee4fb8d6425825bead3fde569271c1290be560fcd")
