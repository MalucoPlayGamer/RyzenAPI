-- Lua provided by RyzenAPI
-- Game: addappid(656940)

-- MAIN APPLICATION
addappid(656940)

-- MAIN APP DEPOTS / PACKAGES
addappid(656941, 1, "c55144e785380d364b5bf3edc5876526e9317fde756d53988daa8098def29121")
