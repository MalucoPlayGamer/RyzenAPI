-- Lua provided by RyzenAPI
-- Game: AppID 656940

-- MAIN APPLICATION
addappid(656940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(656941, 1, "c55144e785380d364b5bf3edc5876526e9317fde756d53988daa8098def29121")

