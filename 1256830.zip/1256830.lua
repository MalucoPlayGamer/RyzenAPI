-- Lua provided by RyzenAPI 
-- Game: AppID 1256830
addappid(1256830)
addappid(1256831, 1, "1a1528dd709686793df8628a3dc911b91f2d8af868dab0e8d975b038a58d4e81")
