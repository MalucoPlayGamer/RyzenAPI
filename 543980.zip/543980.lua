-- Lua provided by RyzenAPI
-- Game: Zombie Exodus: Safe Haven

-- MAIN APPLICATION
addappid(543980)

-- MAIN APP DEPOTS / PACKAGES
addappid(543981, 1, "70e52613202e05d3bb46b6b128c994f07691e28d98abfc5b983739b5422098ed")

