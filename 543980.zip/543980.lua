-- Lua provided by RyzenAPI
-- Game: Zombie Exodus: Safe Haven

-- MAIN APPLICATION
addappid(543980)
addappid(548920)
addappid(830400)
addappid(1052730)
addappid(1052731)
addappid(1888610)
addappid(2303510)
addappid(2866590)
addappid(4132680)

-- MAIN APP DEPOTS / PACKAGES
addappid(543981, 1, "70e52613202e05d3bb46b6b128c994f07691e28d98abfc5b983739b5422098ed")

