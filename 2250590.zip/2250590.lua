-- Lua provided by SkyAPI 
-- Game: Hentai EroElf
addappid(2250590)
addappid(2250591, 1, "1d5844e00c7be6fcd9fd6932d9d9fadf797f1911c3c4713a9d9cdc6f884dd619")
