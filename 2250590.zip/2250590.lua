-- Lua provided by RyzenAPI
-- Game: addappid(2250590)

-- MAIN APPLICATION
addappid(2250590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250591, 1, "1d5844e00c7be6fcd9fd6932d9d9fadf797f1911c3c4713a9d9cdc6f884dd619")
