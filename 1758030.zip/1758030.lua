-- Lua provided by RyzenAPI
-- Game: AppID 1758030

-- MAIN APPLICATION
addappid(1758030)
-- Game: addappid(1758030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758031, 1, "e374b1120674acf742a33cb6cb41f151d7f4dc0763f84658f4fca7d03fc07f8c")
