-- Lua provided by RyzenAPI
-- Game: battleMETAL

-- MAIN APPLICATION
addappid(1447830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447831, 1, "cb4fe7cbf01b5b645cb943257a1028836f8de0dafc5552033e78710af5002bbb")

