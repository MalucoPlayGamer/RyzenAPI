-- Lua provided by RyzenAPI 
-- Game: Stealth Assault: Urban Strike
addappid(2642970)
addappid(2642971, 1, "81c23624a6f5e8b1c5915465878aa9d630733cf12507a38c7af2afe436fb5607")
