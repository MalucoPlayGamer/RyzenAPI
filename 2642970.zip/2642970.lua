-- Lua provided by RyzenAPI
-- Game: Stealth Assault: Urban Strike

-- MAIN APPLICATION
addappid(2642970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642971, 1, "81c23624a6f5e8b1c5915465878aa9d630733cf12507a38c7af2afe436fb5607")

