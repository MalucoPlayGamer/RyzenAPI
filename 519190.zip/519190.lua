-- Lua provided by RyzenAPI
-- Game: Next Day: Survival

-- MAIN APPLICATION
addappid(519190)
addappid(735510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(519191, 1, "84d403e31869312cf481ee038d18d9f6a6830b252509321a861c31ad198fae23")
addappid(519192, 1, "43b29a13a3f69632d61230d34c3bd9142ebfa1a552fbdc8803155e2aaf2cc1d1")

