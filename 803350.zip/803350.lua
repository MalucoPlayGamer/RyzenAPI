-- Lua provided by RyzenAPI
-- Game: Fighter Royale - Last Ace Flying

-- MAIN APPLICATION
addappid(803350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(803351, 1, "c2b86b7f3804b7dab93e726d88538d3edeb0e4de84de5f8bb64c92d5ab04db20")

