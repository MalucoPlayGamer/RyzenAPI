-- Lua provided by RyzenAPI
-- Game: addappid(803350)

-- MAIN APPLICATION
addappid(803350)

-- MAIN APP DEPOTS / PACKAGES
addappid(803351, 1, "c2b86b7f3804b7dab93e726d88538d3edeb0e4de84de5f8bb64c92d5ab04db20")
