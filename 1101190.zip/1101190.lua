-- Lua provided by RyzenAPI
-- Game: Dungeon Defenders: Awakened

-- MAIN APPLICATION
addappid(1101190)
addappid(1668430)
addappid(1692610)
addappid(1703400)
addappid(1847620)
addappid(2253000)
addappid(2331670)
addappid(2396790)
addappid(4611330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101191,0,"6a43114e90d71b1716d5395bd8413a6239add746332f4fc11290d8c4d1e80b0c")

