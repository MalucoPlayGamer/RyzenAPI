-- Lua provided by RyzenAPI
-- Game: Dungeon Defenders: Awakened

-- MAIN APPLICATION
addappid(1101190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101191, 1, "6a43114e90d71b1716d5395bd8413a6239add746332f4fc11290d8c4d1e80b0c")

