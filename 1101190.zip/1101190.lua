-- Lua provided by RyzenAPI
-- Game: Dungeon Defenders: Awakened

-- MAIN APPLICATION
addappid(1101190)
addappid(1668430)
addappid(1692610)
addappid(1703400)
addappid(1847620)
addappid(2253000)
addappid(2331670)
addappid(2396790)
addappid(4611330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101191,0,"6a43114e90d71b1716d5395bd8413a6239add746332f4fc11290d8c4d1e80b0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
