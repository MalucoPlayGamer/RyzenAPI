-- Lua provided by RyzenAPI
-- Game: Succubus - Comic book

-- MAIN APPLICATION
addappid(1670521)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670521,0,"88ed751e69fd0e0002f68ec2c2f3de7b7b8b09a87529344f2b589f80cb06ca19")

