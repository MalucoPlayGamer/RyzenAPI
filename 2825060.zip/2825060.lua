-- Lua provided by RyzenAPI
-- Game: Game: AppID 2825060

-- MAIN APPLICATION
addappid(2825060)
-- Game: addappid(2825060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825061, 1, "aee394420c6fd20281d9297fab078702a28ad80ea1bef57c55a82760d15ea346")
