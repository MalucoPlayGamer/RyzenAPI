-- Lua provided by RyzenAPI
-- Game: 2361940

-- MAIN APPLICATION
addappid(2361940)
-- Game: addappid(2361940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361941, 1, "7e9d6d6511f0d8e7256b1ce60f3e26e028215aac88981d3e6640e8bd8b9bc205")
