-- Lua provided by RyzenAPI 
-- Game: AppID 3027400
addappid(3027400)
addappid(3027401, 1, "615ad33a4d8c666a5b363a31c1bd9e0b9781a66da459c3d2a6959a709c00bf81")
addappid(3027403, 1, "19239e01c2aada9a51de9c6e63a30d426c282290c18c4bc68358ad912787b4e1")
