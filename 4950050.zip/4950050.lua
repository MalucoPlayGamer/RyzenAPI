-- Lua provided by RyzenAPI
-- Game: The Magical girl Childhood friend lives Next Door

-- MAIN APP DEPOTS / PACKAGES
addappid(4950050, 1, "46f8bfbfd9e8b50bfe281882d2da57d4c97d0fa33198039a32a7862487f9b415") -- The Magical girl Childhood friend lives Next Door
addappid(4950051, 1, "b7154f5489d1587ce037418a86b769fa3d7bde58ff91cd6862fe59cfad823f80") -- Depot 4950051

