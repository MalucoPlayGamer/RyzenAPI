-- Lua provided by RyzenAPI
-- Game: Neverwinter Nights: Enhanced Edition Official Soundtrack

-- MAIN APPLICATION
addappid(738710)

-- MAIN APP DEPOTS / PACKAGES
addappid(738712,0,"08bb550c9134dc270218ced92efc1ea60349912ce9ba4e1f06bbfeea4176b5f5")
addappid(738713,0,"6c6e9032472fdc945684875a55cbed7abcf7b5267e754f68f760bc995b40361f")
