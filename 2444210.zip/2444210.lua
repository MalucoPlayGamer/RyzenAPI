-- Lua provided by RyzenAPI
-- Game: HANA : Hide and seek

-- MAIN APPLICATION
addappid(2444210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444211, 1, "c45262a33c0454cc0be13ccfdc138b844985f1a94a018de00f3c3e73a11bb9f5")

