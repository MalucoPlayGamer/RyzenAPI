-- Lua provided by RyzenAPI
-- Game: addappid(2945410)

-- MAIN APPLICATION
addappid(2945410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945412,0,"9a2dc7b2923fedcc966a6377a62465b6d8a8f8e255e9f9f93c6f900298f63c36")
