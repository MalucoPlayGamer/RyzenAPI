-- Lua provided by RyzenAPI
-- Game: 463700

-- MAIN APPLICATION
addappid(463700)
-- Game: addappid(463700)

-- MAIN APP DEPOTS / PACKAGES
addappid(463701, 1, "996317552d733fa91c0e8df5a3591907bd8a2c078bc9cfa9f3281537e374320e")
