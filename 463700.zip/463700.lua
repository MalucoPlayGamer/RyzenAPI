-- Lua provided by RyzenAPI
-- Game: Super Cloudbuilt

-- MAIN APPLICATION
addappid(463700)

-- MAIN APP DEPOTS / PACKAGES
addappid(463701, 1, "996317552d733fa91c0e8df5a3591907bd8a2c078bc9cfa9f3281537e374320e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
