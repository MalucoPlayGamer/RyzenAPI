-- Lua provided by RyzenAPI
-- Game: Full Ace Tennis Simulator

-- MAIN APPLICATION
addappid(779430)
-- Game: addappid(779430)

-- MAIN APP DEPOTS / PACKAGES
addappid(779431, 1, "240478122ad93c6ca2842dd1dcfa213ae0b0b01b6af713877f33a08dbc68dffa")
