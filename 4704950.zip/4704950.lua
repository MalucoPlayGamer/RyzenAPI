-- 4704950's Lua and Manifest Created by Hubcap Manifest
-- ANIMALS 18+
-- Created: August 17, 2026 at 14:42:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4704950) -- ANIMALS 18+
-- MAIN APP DEPOTS
addappid(4704951, 1, "f848f699c7819c63727eef00616e19784ebd9e01ea6c389da6c75849c8b67a92") -- Depot 4704951
setManifestid(4704951, "7785851576701775125", 352624984)