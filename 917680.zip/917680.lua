-- Lua provided by RyzenAPI
-- Game: one night, hot springs

-- MAIN APPLICATION
addappid(917680)
addappid(918490)
-- Game: addappid(917680)

-- MAIN APP DEPOTS / PACKAGES
addappid(917681, 1, "b6d4564f041a7cff6c97d7518b44c5fd5005d4f9ca84591a701aabe45f9fc407")
