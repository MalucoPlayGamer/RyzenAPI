-- Lua provided by RyzenAPI
-- Game: Game: Silver Axe - The Honest Elf

-- MAIN APPLICATION
addappid(1698870)
-- Game: addappid(1698870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698871, 1, "7feaef3349a5f9dcea99cd89b033fd9415bb65edb3a612098676d106055ee683")
