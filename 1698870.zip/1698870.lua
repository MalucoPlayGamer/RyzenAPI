-- Lua provided by SkyAPI 
-- Game: Silver Axe - The Honest Elf
addappid(1698870)
addappid(1698871, 1, "7feaef3349a5f9dcea99cd89b033fd9415bb65edb3a612098676d106055ee683")
