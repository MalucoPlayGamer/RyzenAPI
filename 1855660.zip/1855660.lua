-- Lua provided by RyzenAPI
-- Game: addappid(1855660)

-- MAIN APPLICATION
addappid(1855660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855661, 1, "5306e95f34f91c84c446fb6bbf319d799e517e58fa7415dd7d6412c641e5df43")
