-- Lua provided by RyzenAPI
-- Game: EQI

-- MAIN APPLICATION
addappid(1455920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1455921, 1, "532d5950edde40d1248022fdaf5e5be966e01ee19e1f106187a14f94ca1a5edf")
