-- Lua provided by RyzenAPI
-- Game: AppID 1455920

-- MAIN APPLICATION
addappid(1455920)
-- Game: addappid(1455920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455921, 1, "532d5950edde40d1248022fdaf5e5be966e01ee19e1f106187a14f94ca1a5edf")
