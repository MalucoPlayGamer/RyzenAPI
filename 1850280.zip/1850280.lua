-- Lua provided by RyzenAPI
-- Game: GwenBlade

-- MAIN APPLICATION
addappid(1850280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1850281, 1, "a3143f49b2c9bd9b163eb14291c6bcb065469d1cbe60de400df52067271b7dc5")

