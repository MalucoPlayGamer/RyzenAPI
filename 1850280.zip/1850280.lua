-- Lua provided by RyzenAPI
-- Game: GwenBlade

-- MAIN APPLICATION
addappid(1850280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850281, 1, "a3143f49b2c9bd9b163eb14291c6bcb065469d1cbe60de400df52067271b7dc5")

