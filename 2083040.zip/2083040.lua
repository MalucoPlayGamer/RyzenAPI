-- Lua provided by RyzenAPI 
-- Game: Nova Lands: Emilia's Mission
addappid(2083040)
addappid(2083041, 1, "f4d2ff62b4ff425a62829965a19580fd9c8ec7946846cd37b6e11bf08c4b48d2")
