-- Lua provided by RyzenAPI
-- Game: 2083040

-- MAIN APPLICATION
addappid(2083040)
-- Game: addappid(2083040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083041, 1, "f4d2ff62b4ff425a62829965a19580fd9c8ec7946846cd37b6e11bf08c4b48d2")
