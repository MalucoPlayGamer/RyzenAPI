-- Lua provided by RyzenAPI
-- Game: 383710

-- MAIN APPLICATION
addappid(383710)
-- Game: addappid(383710)

-- MAIN APP DEPOTS / PACKAGES
addappid(383711, 1, "c2b05465f73c07a47920fdcdfc778821a33340f47ac34569524f9d8ae00012ff")
