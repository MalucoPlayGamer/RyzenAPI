-- Lua provided by RyzenAPI 
-- Game: Kosmonavtes: Escape Reality
addappid(1542440)
addappid(1542441, 1, "db1c5a33569a032c98150d38236a7138be6786339b43c05dc03020dd1b3fa2a7")
