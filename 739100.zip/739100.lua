-- Lua provided by RyzenAPI
-- Game: Blink: Rogues

-- MAIN APPLICATION
addappid(739100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(739101, 1, "adb250c358bf802814475837ad9bb95a737e83af194830f383a441be5d4b7ecd")
