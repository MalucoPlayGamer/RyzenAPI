-- Lua provided by RyzenAPI 
-- Game: AppID 739100
addappid(739100)
addappid(739101, 1, "adb250c358bf802814475837ad9bb95a737e83af194830f383a441be5d4b7ecd")
