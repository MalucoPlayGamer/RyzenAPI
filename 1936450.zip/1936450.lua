-- Lua provided by RyzenAPI 
-- Game: Criminal Cage
addappid(1936450)
addappid(1936451, 1, "94e1de9ed3addf6a9f2012bf86599da6242ea0ebd42f8d44a9bbe0d212207240")
