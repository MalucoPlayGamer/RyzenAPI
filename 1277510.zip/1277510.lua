-- Lua provided by RyzenAPI
-- Game: Re:ZERO -Starting Life in Another World- The Prophecy of the Throne

-- MAIN APPLICATION
addappid(1277510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1277511, 1, "a3826fb2cf5d5c825385c4e78b77830346044d093357070435f68d58a93061eb")
addappid(1277513, 1, "56028ad9d1271c155d2ffdf4e454f5fd575b790e878199f62f640dfa5a8a051b")

