-- Lua provided by RyzenAPI 
-- Game: Space Debris
addappid(1410300)
addappid(1410301, 1, "b6b4455bca986064c258ab855444d090e48ed668edb88cf0d0e87924f587cac6")
