-- Lua provided by RyzenAPI
-- Game: Space Debris

-- MAIN APPLICATION
addappid(1410300)
-- Game: addappid(1410300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410301, 1, "b6b4455bca986064c258ab855444d090e48ed668edb88cf0d0e87924f587cac6")
