-- Lua provided by RyzenAPI
-- Game: Rainbow Step

-- MAIN APPLICATION
addappid(690400)
-- Game: addappid(690400)

-- MAIN APP DEPOTS / PACKAGES
addappid(690401, 1, "a3827cbf6c0ae967df3024d397767a7897f205f73cdb697a509c85ca2fd74c0a")
