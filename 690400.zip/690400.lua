-- Lua provided by RyzenAPI
-- Game: Rainbow Step

-- MAIN APPLICATION
addappid(690400)

-- MAIN APP DEPOTS / PACKAGES
addappid(690401, 1, "a3827cbf6c0ae967df3024d397767a7897f205f73cdb697a509c85ca2fd74c0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
