-- Lua provided by RyzenAPI
-- Game: 墨心：波云诡船

-- MAIN APPLICATION
addappid(1424720)
addappid(1496920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424722,0,"cca31a753d1e8222b138a1b453588e58c1aada008742d9e6bc1e0b8422b69de8")

