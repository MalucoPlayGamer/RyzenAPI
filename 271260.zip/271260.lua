-- 271260's Lua and Manifest Created by Hubcap Manifest
-- Star Control: Origins
-- Created: June 26, 2026 at 17:38:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 27
-- Total DLCs: 3 (3 excluded)
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(271260, 1, "526b16be08b866604ffdf5c1235532ce57cf99546386f0f182c18dcc2ce0e185") -- Star Control: Origins
-- MAIN APP DEPOTS
addappid(271261, 1, "41b992af58914c41d8ff54f9761a97638a973b6a43cecb11cc67d5127e91dc27") -- Star Control Content
setManifestid(271261, "7216379325516306288", 13177464520)
addappid(271266, 1, "d263017ecc0b8a8cba236a4a768de059c14c9298d91a3ace0412b8abe98d2155") -- Star Control: Origins French Depot
setManifestid(271266, "7108069561699794116", 67539089)
addappid(271263, 1, "dae992ddd1f2978da2e3ada1e2089260bc7e64810ada8200cc0c3d2b709df951") -- Star Control Origins - German Content
setManifestid(271263, "7671085452778602244", 529838184)
addappid(271271, 1, "cafd1a5753206e3dbe236bbbb1d339688c88f3e49e38f3127761c22c11d3ea2c") -- Star Control: Origins Spanish Depot
setManifestid(271271, "6950894386045515855", 60064854)
addappid(271265, 1, "2f68affc23b509cedf8ec4727f70b5f563913f1ac98c56d3e385a493b67b88ad") -- Star Control: Origins Finnish Depot
setManifestid(271265, "4881868979491391477", 60037423)
addappid(271267, 1, "b786008c4b8f05747e3440e330557e0cc69a36df4a9258afc15e8aec13a9b551") -- Star Control: Origins Norwegian Depot
setManifestid(271267, "1506864042721759115", 67092628)
addappid(271270, 1, "c5409d9e8e2cf60b5137fbcf73b89917f34a35a79019af8a59417772b7a80ad1") -- Star Control: Origins pt-BR Depot
setManifestid(271270, "2335571071063711459", 67188517)
addappid(271264, 1, "3a6a232a652c68932497d299fd70a3547727d9f0b7469a229635eb08a56dd676") -- Star Control: Origins Russian Depot
setManifestid(271264, "2808470915793826756", 558370893)
addappid(271268, 1, "6ef98434224899d3c4b4f9fde21338beb0a863707027499682e8c6c290da6b5a") -- Star Control: Origins Simp. Chinese Depot
setManifestid(271268, "881569343879847895", 714414678)
addappid(271269, 1, "7989eec39588c49cd995cf8e26f43a32bf05fba53148eaa53ebe3b43a55428ee") -- Star Control: Origins Italian Lang Depot
setManifestid(271269, "4305444797608817049", 60278189)
addappid(271262, 1, "722123abb2ac29b146cd451cb2ac3834cd17d2a58d02a914e1f8f3694ec74c25") -- Stardock Launcher
setManifestid(271262, "4050658150302144029", 94347097)
addappid(874584, 1, "4e0bb00ab83e8e06a2992fcd1fd956a7ffedc7ba91f3b12c9bb8c8e2d0f1f57b") -- Depot 874584
setManifestid(874584, "3539765936919040017", 0)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Star Control Origins - Reinforcements DLC (AppID: 956460)
addappid(956460)
addappid(956460, 1, "dd660f0bd15e7532dc647111e1cb37d3f1a31c87413293d2e1beb4cd83e68cbd") -- Star Control Origins - Reinforcements DLC - Star Control: Origins - Reinforcements DLC (956460) Depot
setManifestid(956460, "4525836515602882928", 2596475)
-- Star Control Origins - Earth Rising Expansion (AppID: 961150)
addappid(961150)
addappid(961150, 1, "b53d41b59ffa1feed26b944bebc2cb4aca50fcc5ed8a740e8ca1746f849eb117") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins - Earth Rising Season Pass (961150) Depot
setManifestid(961150, "1874686040941646505", 11606834)
addappid(271272, 1, "b747b9f4892e67b610cda16866434ce6c37aa2ed40d9b0745c8b419839b3c50a") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins - Earth Rising French Depot
setManifestid(271272, "6976574171796933251", 629143)
addappid(271273, 1, "1ae24609186c63aa1842fb0fef4749ff856e996b6af2b3a775baa6c8eaf48c93") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins - Earth Rising Italian Depot
setManifestid(271273, "832986325299456726", 576591)
addappid(271274, 1, "79de74a00436742999e4246545184f5de24bfa9aba25c0e61e70f0dbc07854d1") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising Finnish Depot
setManifestid(271274, "280804849896789331", 589221)
addappid(271275, 1, "a87e569e37f245cff09111f29f9a4dbae1d08ad17e3e1a6b1ef37114aef15f32") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising German Depot
setManifestid(271275, "3492451949428020798", 655142)
addappid(271276, 1, "7da0e6283b7930ebb3d8bdc110e22a12f55431b35fd01313cbe267699a909cf2") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising Norwegian Depot
setManifestid(271276, "3880276569342328983", 555204)
addappid(271277, 1, "f2118ff4fc33a870c7b5a517075043af7b7a5453d29d072d63f67c206f5450b5") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising pt-BR Depot
setManifestid(271277, "8088876542079748256", 582589)
addappid(271278, 1, "af767f4a0b9599fb60587ef2a2f509fa27a51fc14bbb88bf5ae7d6df88f052f6") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising Russian Depot
setManifestid(271278, "5913742251516057869", 870474)
addappid(271279, 1, "edf97e5208a720ba18c3c0542cb920c525046ba43d43fdb87232024e01981248") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising S Chinese Depot
setManifestid(271279, "8343135316940700819", 540096)
addappid(874581, 1, "3e34d375dac0eed8ec5c51dabcbe2038c019add77a5bb3c0f03e312ef0cfc3b7") -- Star Control Origins - Earth Rising Expansion - Star Control: Origins Earth Rising Spanish Depot
setManifestid(874581, "3985450164684007194", 585370)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(959250) -- Star Control Origins - Multiverse DLC
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(874580) -- DLC 874580 (unreleased)
-- addappid(899550) -- Star Control: Origins ™ Content Pack (unreleased)
-- addappid(899551) -- Star Control: Origins – Mowlings™ Content Pack (unreleased)