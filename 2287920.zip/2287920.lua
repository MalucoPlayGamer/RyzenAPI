-- Lua provided by RyzenAPI 
-- Game: BATTLE CRUSH
addappid(2287920)
addappid(2287921, 1, "7c796ea7a75557a2a2263bfb52825c2f2707917a8c49163f82dd58e75270ad12")
