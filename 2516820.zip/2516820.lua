-- Lua provided by RyzenAPI
-- Game: LuckLand

-- MAIN APPLICATION
addappid(2516820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516821, 1, "a839e4be0006698b006dde5b4acc6183519a3df6b6507abf0102e249c99016d3")
