-- Lua provided by RyzenAPI
-- Game: 骰出生路 Demo

-- MAIN APPLICATION
addappid(2817650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817651, 1, "b2f4c9ea225585ac5d104f5e100cea2bc7bbfb0e0d742191da8243d53e0fbb8b")

