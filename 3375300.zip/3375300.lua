-- Lua provided by RyzenAPI
-- Game: addappid(3375300)

-- MAIN APPLICATION
addappid(3375300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3375301, 1, "afb60d422c63ca0bb2b6aaa3c500599a0224fd6642afdacd92c63441ade1735d")
