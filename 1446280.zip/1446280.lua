-- Lua provided by RyzenAPI
-- Game: Alice in Wonderland - a jigsaw puzzle tale

-- MAIN APPLICATION
addappid(1446280)
-- Game: addappid(1446280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446281, 1, "4ab756ec2fc9cb130b4cde56f6bda60fc843450e3ae380164e233bf4fa9800a8")
addappid(1446282, 1, "4f226d87c394150e57af8c36c9cc56d3e9c5dc243263ea13a609435f37dc837f")
