-- Lua provided by RyzenAPI 
-- Game: AppID 1750630
addappid(1750630)
addappid(1750631, 1, "2b23190206012c30d8941499de312aca6d8956f290a78986f8447151d7077f20")
