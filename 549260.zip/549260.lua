-- Lua provided by RyzenAPI
-- Game: Game: Alwa's Awakening

-- MAIN APPLICATION
addappid(549260)
-- Game: addappid(549260)

-- MAIN APP DEPOTS / PACKAGES
addappid(549261, 1, "99f0b4233558c86da42f820c0a224713ef79fc9fbf0dbb03264f1210e1c40a1d")
addappid(549262, 1, "ee8d322ea4ed138c7479169fcd577e5a013a9f18b427d29f4f44b0ed65f0b3d4")
addappid(549263, 1, "8976a66051fdd2062af1b2e3254c30777cf4918992cf960af8ec7252189539b9")
addappid(2001510, 0, "60f19b45ae85f0035f9eda766cc00d03df217f0573988ca1399f7a600f1ed1c1")
