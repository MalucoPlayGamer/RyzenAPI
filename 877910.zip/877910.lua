-- Lua provided by SkyAPI 
-- Game: Time Drifter
addappid(877910)
addappid(877911, 1, "689b17e890fa72dd430e73905b1f6f6e8ba1966031c72638c3763f58867aaeeb")
