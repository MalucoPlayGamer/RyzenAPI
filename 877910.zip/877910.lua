-- Lua provided by RyzenAPI
-- Game: Game: Time Drifter

-- MAIN APPLICATION
addappid(877910)
-- Game: addappid(877910)

-- MAIN APP DEPOTS / PACKAGES
addappid(877911, 1, "689b17e890fa72dd430e73905b1f6f6e8ba1966031c72638c3763f58867aaeeb")
