-- Lua provided by RyzenAPI 
-- Game: AppID 929410
addappid(929410)
addappid(929411, 1, "0d87c9e8a78237f7c57188e83b55fdab035f268614d4d2c365241f49ced1ba56")
addappid(929414, 1, "b74819ecbb303933e30bf4372c07a0fd113caf19dc3a2d3395d82b9e5f8f2eef")
