-- Lua provided by RyzenAPI
-- Game: Selective Jump: Once Again With Feeling

-- MAIN APPLICATION
addappid(363920)
addappid(363921)
-- Game: addappid(363920)

-- MAIN APP DEPOTS / PACKAGES
addappid(363922,0,"88578d869f0994000b66dc72d7d5077ecaf813567b5b7230003c235c1364518d")
