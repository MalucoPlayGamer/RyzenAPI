-- Lua provided by RyzenAPI
-- Game: GUNBARICH

-- MAIN APPLICATION
addappid(1342240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342241, 1, "82ee8dc42f570a99adb15c275d0f51ebdfc47b49298af93086e8a2f62aacaa92")
