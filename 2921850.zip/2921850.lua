-- Lua provided by RyzenAPI
-- Game: AppID 2921850

-- MAIN APPLICATION
addappid(2921850)
-- Game: addappid(2921850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921851, 1, "98c3478e12b176d7eefe6603ab07acf9bb9b6eba1226fa7bb2633a0509e318ee")
