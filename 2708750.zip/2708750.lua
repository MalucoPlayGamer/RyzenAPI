-- Lua provided by RyzenAPI
-- Game: ONE. Demo

-- MAIN APPLICATION
addappid(2708750)
-- Game: addappid(2708750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708751, 1, "0d0a066c899287dc9eb83e7c14e83984a8f70491609ecf21b121c5128ce78699")
