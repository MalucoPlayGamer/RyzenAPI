-- Lua provided by RyzenAPI
-- Game: DORAEMON STORY OF SEASONS: Friends of the Great Kingdom

-- MAIN APPLICATION
addappid(1492730)
addappid(2019410)
addappid(2062250)
addappid(2062251)
addappid(2062252)
addappid(2062253)
addappid(2062254)
addappid(2062255)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492731, 1, "7a2c277cce45042f0a1d145eaf9c1d726882d47f61669b5f72ad56d991156276")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
