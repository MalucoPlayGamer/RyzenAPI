-- Lua provided by RyzenAPI
-- Game: Spy Drops

-- MAIN APPLICATION
addappid(3034070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034071,0,"fd436e74dfa1022d194a8485828e13981bd681db3f0abe4cd9f298ca4154e66b")

