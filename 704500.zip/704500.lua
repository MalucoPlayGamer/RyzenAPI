-- Lua provided by RyzenAPI
-- Game: AppID 704500

-- MAIN APPLICATION
addappid(704500)
-- Game: addappid(704500)

-- MAIN APP DEPOTS / PACKAGES
addappid(704501, 1, "c835cf31e04552cd4feb57825c998cb64aa70f7d005d4a1dc46d7b2f39a16fc7")
