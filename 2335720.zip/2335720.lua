-- Lua provided by RyzenAPI
-- Game: 2335720

-- MAIN APPLICATION
addappid(2335720)
-- Game: addappid(2335720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335721, 1, "c9f213b86f582056035e7a3ab08b5fdf005d444e4ad8fcda06b34e8ef5955766")
