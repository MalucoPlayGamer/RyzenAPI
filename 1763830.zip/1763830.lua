-- Lua provided by RyzenAPI
-- Game: My Truck Game

-- MAIN APPLICATION
addappid(1763830)
-- Game: addappid(1763830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763831, 1, "3726c21072efbb4c782f69a5878872ea6c4702f6910b74f40042b1c78347ace2")
