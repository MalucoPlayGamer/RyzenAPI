-- Lua provided by RyzenAPI
-- Game: AppID 599750

-- MAIN APPLICATION
addappid(599750)

-- MAIN APP DEPOTS / PACKAGES
addappid(599751, 1, "76dbb4285bcfd8076fb5295603ab9b173a9d7130136d683ed38491695021731a")
addappid(698240, 0, "f601d6efa38105336282de197139c09f9318a355616b458f59cf259e89fd9a59")
addappid(1255950, 0, "7284e29b9723940a41fffd51382f7d2e0f4c7b7e8d2bcba21f1dff315f195cf3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
