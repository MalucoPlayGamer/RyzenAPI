-- Lua provided by RyzenAPI
-- Game: AppID 845480

-- MAIN APPLICATION
addappid(845480)

-- MAIN APP DEPOTS / PACKAGES
addappid(845481, 1, "f3543e374648a01549dcad21deeae0f00a33a7d4ca96cde82efbb8578f09605e")

