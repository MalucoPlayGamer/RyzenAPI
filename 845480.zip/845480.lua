-- Lua provided by RyzenAPI
-- Game: Kinaman vs Gray Elephant

-- MAIN APPLICATION
addappid(845480)
addappid(874410)

-- MAIN APP DEPOTS / PACKAGES
addappid(845481,0,"f3543e374648a01549dcad21deeae0f00a33a7d4ca96cde82efbb8578f09605e")

