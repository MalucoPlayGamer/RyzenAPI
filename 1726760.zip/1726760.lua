-- Lua provided by RyzenAPI
-- Game: addappid(1726760)

-- MAIN APPLICATION
addappid(1726760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726761, 1, "7032de95dc3c39caf86e27efc7e9c115e6ef1d5252910bcdd7c9620481dd67a6")
