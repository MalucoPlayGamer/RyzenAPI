-- Lua provided by RyzenAPI
-- Game: addappid(2063530)

-- MAIN APPLICATION
addappid(2063530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063531, 1, "9bacc99a7f73fd27446afddf22374e4e8d8da712dcd154e6eef1c003751cd579")
