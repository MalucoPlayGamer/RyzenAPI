-- Lua provided by RyzenAPI
-- Game: 1177980

-- MAIN APPLICATION
addappid(1177980)
-- Game: addappid(1177980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177981, 1, "954a7042a9ac7ba33b492e012910f34f34ce59c40c2f9ed44016a4ccbab55ae8")
