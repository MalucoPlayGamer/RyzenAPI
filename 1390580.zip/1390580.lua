-- Lua provided by RyzenAPI
-- Game: Game: Curse Lsland

-- MAIN APPLICATION
addappid(1390580)
-- Game: addappid(1390580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390581, 1, "18b0910ac4c030cd72f52e0be92b7873b0e0741a8d71181c059920f7bd6e4a45")
