-- Lua provided by RyzenAPI 
-- Game: Nebulock
addappid(3444480)
addappid(3444481, 1, "c44c4c6a4f9db4b092a5d69c21c8729baab585f3cca3e11d9fa0b79f3836f1a1")
