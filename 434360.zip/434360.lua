-- Lua provided by RyzenAPI
-- Game: Kitten Rampage

-- MAIN APPLICATION
addappid(434360)

-- MAIN APP DEPOTS / PACKAGES
addappid(434361, 1, "2f37275c4b2f3e74bbdd7cbd0ad0f744248cbb22b35e8ea024980becee5ed294")
addappid(434362, 1, "acdceca727fec20567d7f9918b4a52e4a8d19b59b42a5c29a823319a8acaa0ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
