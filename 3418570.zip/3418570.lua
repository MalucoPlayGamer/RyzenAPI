-- Lua provided by RyzenAPI
-- Game: Game: Summer Pockets REFLECTION BLUE

-- MAIN APPLICATION
addappid(3418570)
-- Game: addappid(3418570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418571, 1, "0fe7eee45873a590cf444770688f17832220077587c731b4145cbc4e2364f3d7")
