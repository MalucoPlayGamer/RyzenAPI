-- Lua provided by RyzenAPI
-- Game: Makeover Desire - HENSHIN GANBO

-- MAIN APPLICATION
addappid(1053270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053271, 1, "faba87ec2d7ef411362447451d4530df929cae10958d2c55a7692a69c6312a86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
