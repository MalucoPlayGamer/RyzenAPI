-- Lua provided by RyzenAPI
-- Game: Game: Makeover Desire - HENSHIN GANBO

-- MAIN APPLICATION
addappid(1053270)
-- Game: addappid(1053270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053271, 1, "faba87ec2d7ef411362447451d4530df929cae10958d2c55a7692a69c6312a86")
