-- Lua provided by SkyAPI 
-- Game: Makeover Desire - HENSHIN GANBO
addappid(1053270)
addappid(1053271, 1, "faba87ec2d7ef411362447451d4530df929cae10958d2c55a7692a69c6312a86")
