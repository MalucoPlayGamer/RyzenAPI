-- Lua provided by RyzenAPI
-- Game: Game: Anno 117: Pax Romana

-- MAIN APPLICATION
addappid(3274580)
addappid(3749050)
addappid(3749060)
addappid(3749080)
addappid(3749090)
addappid(3875910)
addappid(4168120)
addappid(4168130)
-- Game: addappid(3274580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274581, 1, "29f1b2f2b84b5981fe5e3ebadc14b925e747eea87b6556a95001d576acb9beb9")
addappid(3274582, 1, "f04b6ff10311fb1d95b43528e4681da8a1b615a31d69275af308d77f93602a4f")
addappid(3274583, 1, "dc97a69d99aeaea85bf8ec545b63e9a140606870c2f17f9fec7967c463060618")
addappid(3274584, 1, "e8679d4318f2f44fc44ff183048c09321b4b84000680a1675fe1dd5463d2f24e")
addappid(3274585, 1, "b08a4e3e71782afe4166e047a91bed2a236df33c2b0d0fe02a7ca3dba1a15912")
