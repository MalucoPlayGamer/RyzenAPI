-- Lua provided by RyzenAPI
-- Game: Elysian Inferno

-- MAIN APPLICATION
addappid(3738260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3738261, 1, "637a768a147e06d31c276fedc48d21709221da41ecb47ae190dae16d409bdd30")
