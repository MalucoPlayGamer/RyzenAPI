-- Lua provided by RyzenAPI
-- Game: Shadow Burglar

-- MAIN APPLICATION
addappid(1881340)
-- Game: addappid(1881340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881341, 1, "9bd731b181bf204e2d6090ec0ca1bd4ec6049d5ddce640f7a72d40584deec0f5")
