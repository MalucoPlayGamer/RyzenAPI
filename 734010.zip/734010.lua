-- Lua provided by RyzenAPI
-- Game: AppID 734010

-- MAIN APPLICATION
addappid(734010)

-- MAIN APP DEPOTS / PACKAGES
addappid(734011, 1, "a44f6e178555acba36b2a99db68fd6522a1e4e401f313fb2a277e173a3c2205c")

