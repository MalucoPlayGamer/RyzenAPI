-- Lua provided by RyzenAPI
-- Game: Mega Man Legacy Collection 2

-- MAIN APPLICATION
addappid(495050)
-- Game: addappid(495050)

-- MAIN APP DEPOTS / PACKAGES
addappid(495051, 1, "9d0486a0c0f575c083cc3e416de7a0074cafa01889208f14118ede19b7d22ff7")
