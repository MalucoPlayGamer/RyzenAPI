-- Lua provided by RyzenAPI
-- Game: Crusaders Quest : Hero Town

-- MAIN APPLICATION
addappid(4126220)
addappid(4732460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4126221,0,"bbee22e7cd268244d481f200c8fd2ae401eaa3deb6b323bb5afca5eea1827635")
addappid(4126222,0,"29b13602d2bcb788ec71b4871c281d82ca3989b5950cb8722bb72611be030725")

