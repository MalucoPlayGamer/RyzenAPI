-- Lua provided by RyzenAPI
-- Game: 715690

-- MAIN APPLICATION
addappid(715690)
-- Game: addappid(715690)

-- MAIN APP DEPOTS / PACKAGES
addappid(715691, 1, "2e855b6e464e3883b48b6dc38ccb1ef46344234c4f2e1a403a61722551ab17f7")
