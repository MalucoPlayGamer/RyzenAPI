-- 3182950's Lua and Manifest Created by Hubcap Manifest
-- Matchstick: Cosmic Flame
-- Created: August 09, 2026 at 09:46:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3182950) -- Matchstick: Cosmic Flame
-- MAIN APP DEPOTS
addappid(3182951, 1, "9253ef02c9c77462a9429b3a06b105805f260f36ed64ac9cbf4d2207c3982a5c") -- Depot 3182951
setManifestid(3182951, "9008111781376266125", 468384059)