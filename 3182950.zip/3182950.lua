-- Lua provided by RyzenAPI
-- Game: Matchstick: Cosmic Flame

-- MAIN APPLICATION
addappid(3182950) -- Matchstick: Cosmic Flame

-- MAIN APP DEPOTS / PACKAGES
addappid(3182951, 1, "9253ef02c9c77462a9429b3a06b105805f260f36ed64ac9cbf4d2207c3982a5c") -- Depot 3182951

