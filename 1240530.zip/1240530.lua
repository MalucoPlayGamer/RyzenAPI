-- Lua provided by RyzenAPI
-- Game: Dungeon Warriors

-- MAIN APPLICATION
addappid(1240530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240531, 1, "ff658b6d6365210427d69487494528cb0fa71864fab08b37957faced3eed8918")
