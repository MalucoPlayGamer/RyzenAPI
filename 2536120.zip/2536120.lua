-- Lua provided by RyzenAPI
-- Game: Mousey

-- MAIN APPLICATION
addappid(2536120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536121, 1, "9d2e0e266b16e7ee74c8219c409c2a0d4a8e9fcf57551bacba0366c6d7d24a3a")
