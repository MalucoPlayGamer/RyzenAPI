-- Lua provided by RyzenAPI
-- Game: Conqueror's Blade

-- MAIN APPLICATION
addappid(835570)
addappid(1747380)
addappid(1777450)
addappid(1809460)
addappid(1809461)
addappid(1809462)
addappid(1809463)
addappid(1835880)
addappid(1835881)
addappid(1872480)
addappid(1872481)
addappid(2654310)
addappid(2654320)
addappid(2654330)
addappid(2654340)
addappid(3063160)
addappid(3065510)
addappid(3065520)
addappid(3065530)
addappid(3065540)
addappid(3065550)
addappid(3065560)
addappid(3360640)
addappid(3379970)
addappid(3379980)
addappid(3379990)
addappid(3380000)
addappid(3642310)
addappid(3642320)
addappid(3642340)
addappid(4260890)

-- MAIN APP DEPOTS / PACKAGES
addappid(835571,0,"f2597d3fb3b84945af5479bcdc98ba0c2c5a4c3494c2c4ec31f43668ddcc62df")
addappid(835575,0,"163309d1d9632f744a233c83d6ffb874a4600dda326fc565682c7d3d9ced681c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
