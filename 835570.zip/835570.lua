-- Lua provided by RyzenAPI
-- Game: addappid(835570)

-- MAIN APPLICATION
addappid(835570)

-- MAIN APP DEPOTS / PACKAGES
addappid(835571, 1, "f2597d3fb3b84945af5479bcdc98ba0c2c5a4c3494c2c4ec31f43668ddcc62df")
