-- Lua provided by RyzenAPI
-- Game: THE GREAT GEOMETRIC MULTIVERSE TOUR

-- MAIN APPLICATION
addappid(887400)
-- Game: addappid(887400)

-- MAIN APP DEPOTS / PACKAGES
addappid(887401, 1, "722acc2ba09a4c9a4dece7e0c3693379d03585a1284f357ab621f3296eb9e16e")
addappid(887402, 1, "9c14ca6f840be7ffe7cbd7434636be0046fb30582b0c921ca9b6fc4e7663b0ba")
addappid(887403, 1, "a8bade432aa4a9a7ead32a07baad846ee8db1838be59b44e3c972db52c0cf6b0")
