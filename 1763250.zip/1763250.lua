-- Lua provided by RyzenAPI
-- Game: SWORN

-- MAIN APPLICATION
addappid(3160690)
addappid(3756800) -- SWORN - Vigilante Cosmetic Pack
addappid(3756810) -- SWORN - Rook Cosmetic Pack
addappid(3756820) -- SWORN - Monk Cosmetic Pack
addappid(3756830) -- SWORN - Spectre Cosmetic Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(1763250, 1, "18da1e8dec00d0de0206fbd8b4788c96fdba6e5cef71e8aa7d64d8c0c5e2e6f9") -- SWORN
addappid(1763251, 1, "32467278867521bb7848990057535c82d0e863ccdfabefffa0cd87c75a6d6b56") -- Depot 1763251
addappid(3160691, 1, "25255a9f1e317a0a785def9a194731c94857d6f91e365904f515cf2f27f66ad1") -- SWORN - Digital Artbook - Depot 3160691

