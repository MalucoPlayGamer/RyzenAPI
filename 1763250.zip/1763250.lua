-- Lua provided by RyzenAPI
-- Game: 1763250

-- MAIN APPLICATION
addappid(1763250)
-- Game: addappid(1763250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763251, 1, "32467278867521bb7848990057535c82d0e863ccdfabefffa0cd87c75a6d6b56")
