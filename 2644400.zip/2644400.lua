-- Lua provided by RyzenAPI
-- Game: addappid(2644400)

-- MAIN APPLICATION
addappid(2644400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644401, 1, "136354544f815a60ffad1a6d22a27b851b2a957cd61ea31a7cfe213295956eb6")
