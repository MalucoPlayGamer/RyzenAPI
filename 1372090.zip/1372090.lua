-- Lua provided by RyzenAPI 
-- Game: Hentai Cyberpunk
addappid(1372090)
addappid(1372091, 1, "4890f36b076f7dd4e9592a82124396f6770dbe98168592d42469df4e55d6972b")
