-- Lua provided by RyzenAPI
-- Game: addappid(1502490)

-- MAIN APPLICATION
addappid(1502490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502491, 1, "606f93ae8c6cc94ad1a9fa815fd6ed21b9849fc974d872095fd2b99224e33fa7")
