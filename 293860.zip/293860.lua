-- Lua provided by RyzenAPI
-- Game: White Noise Online

-- MAIN APPLICATION
addappid(293860)
-- Game: addappid(293860)

-- MAIN APP DEPOTS / PACKAGES
addappid(293861, 1, "986f83ab751e143d0d033b266ea9ec4ca7ab392897bd26feb665939757630560")
addappid(293862, 1, "cd0607ebde17a11ae4ac94cbcdde796d9cadecbf1af522a30e06de3e15103f64")
addappid(293863, 1, "a3f1011ef464641d3516e73ef7857dda044a88b635c756f153c4e072b6d49187")
