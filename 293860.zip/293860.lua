-- Lua provided by RyzenAPI
-- Game: White Noise Online

-- MAIN APPLICATION
addappid(293860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(293861, 1, "986f83ab751e143d0d033b266ea9ec4ca7ab392897bd26feb665939757630560")
addappid(293862, 1, "cd0607ebde17a11ae4ac94cbcdde796d9cadecbf1af522a30e06de3e15103f64")
addappid(293863, 1, "a3f1011ef464641d3516e73ef7857dda044a88b635c756f153c4e072b6d49187")

