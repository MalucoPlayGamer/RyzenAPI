-- Lua provided by RyzenAPI
-- Game: Dirge

-- MAIN APPLICATION
addappid(1374580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374581, 1, "bd92377ead73cd70916c4412f0a5307a8d618a8425b27db11a391145a86fee45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1828300)
addappid(1834770)
