-- Lua provided by RyzenAPI
-- Game: addappid(1374580)

-- MAIN APPLICATION
addappid(1374580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374581, 1, "bd92377ead73cd70916c4412f0a5307a8d618a8425b27db11a391145a86fee45")
