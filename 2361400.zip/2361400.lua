-- Lua provided by RyzenAPI
-- Game: addappid(2361400)

-- MAIN APPLICATION
addappid(2361400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361401, 1, "ab26171510d0c8df05e58e09c75d679730e83599292cc0be41ebf34fa85d8581")
