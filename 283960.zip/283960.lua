-- Lua provided by RyzenAPI
-- Game: Pajama Sam in No Need to Hide When It's Dark Outside

-- MAIN APPLICATION
addappid(283960)

-- MAIN APP DEPOTS / PACKAGES
addappid(283961, 1, "d67da980090b723a8eebcfe047240139d1fb8766341aac8a1fed75db969b936f")
addappid(283964, 1, "33128987cea126209d306deb83038cc596a94dcb403c32e74ceca4a556206ec2")
addappid(283965, 1, "6c864792d3759886e2be5087b5612376af2be265e80d9279c2b9865fc8b7229b")

