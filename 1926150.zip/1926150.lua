-- Lua provided by RyzenAPI
-- Game: AppID 1926150

-- MAIN APPLICATION
addappid(1926150)
-- Game: addappid(1926150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926151, 1, "d6ba8b9bd0c5ee1b6cff3c33be7d956eb948a3768116905713464062326e79e9")
