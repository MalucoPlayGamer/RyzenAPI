-- Lua provided by RyzenAPI
-- Game: Suzy Cube

-- MAIN APPLICATION
addappid(780500)
-- Game: addappid(780500)

-- MAIN APP DEPOTS / PACKAGES
addappid(780502,0,"6f6c485613449b4dc4a0ac317a7aa15e817165d77b64ceb840c9a713fbd22dfa")
