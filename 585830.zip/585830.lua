-- Lua provided by RyzenAPI
-- Game: Ninja Stealth 2

-- MAIN APPLICATION
addappid(585830)

-- MAIN APP DEPOTS / PACKAGES
addappid(585831, 1, "5710e04bc7764011a5784ac2d77f77c0569ecc7ac9b3c47f81faf7f70092d5a6")
addappid(585832, 1, "9ad389c375641b6d362addbf00bbd74573cf35088cfa71d68ef70bac9f54b7fb")
