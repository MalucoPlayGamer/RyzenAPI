-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Frontier Works: Futuristic Heroes and BGM

-- MAIN APPLICATION
addappid(1523960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523960,0,"92a50cc7674ea8108915ae78e5743b939f81724efb57e03aa9e19c53a43547d5")

