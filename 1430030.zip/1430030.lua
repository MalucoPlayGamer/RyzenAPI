-- Lua provided by RyzenAPI
-- Game: addappid(1430030)

-- MAIN APPLICATION
addappid(1430030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430031, 1, "be99c41f9c2272bd4fbcbd4b63779c222ad530a3e37420dcb473806252530fe3")
