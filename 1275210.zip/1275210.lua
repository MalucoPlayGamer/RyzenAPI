-- Lua provided by RyzenAPI
-- Game: Game: Cross Soul

-- MAIN APPLICATION
addappid(1275210)
-- Game: addappid(1275210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275211, 1, "0df314d01491b9420d94fae85c3a55472434d05b1454167d83156d667e46aa96")
