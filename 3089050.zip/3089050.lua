-- Lua provided by RyzenAPI
-- Game: 3089050

-- MAIN APPLICATION
addappid(3089050)
-- Game: addappid(3089050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089051, 1, "297184b7cf392eefb26d6c33f639c2f7cfb48336a67ee26f05762c6e612073f6")
