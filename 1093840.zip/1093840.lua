-- Lua provided by RyzenAPI
-- Game: NiGHT SIGNAL

-- MAIN APPLICATION
addappid(1093840)
-- Game: addappid(1093840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093841, 1, "acd43194dd421dfcf3d37090d1a0b32e32e0bc8f8db2e878bd1ba634ae24bcde")
