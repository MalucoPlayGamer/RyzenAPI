-- Lua provided by RyzenAPI
-- Game: 3575790

-- MAIN APPLICATION
addappid(3575790)
-- Game: addappid(3575790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575791, 1, "55b761262020f9ffb1f0be2857c62895f48448d2d824d087e35ca9aff2bfa718")
