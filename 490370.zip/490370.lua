-- Lua provided by RyzenAPI
-- Game: Imperium Galactica II

-- MAIN APPLICATION
addappid(490370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(490371, 1, "2beae616d64ba6e389f4d797157ef8ab650913257bdc7ec9434483ea63038352")
addappid(490372, 1, "b066b399e50c98496b06408c559abc090677e8960cfdd8591774c7184f9b8f1f")
addappid(490373, 1, "9a70f4e5bfd0228f7820b0e5ef10cb115647ba4c291e3c79ff047524afd9f6c4")
