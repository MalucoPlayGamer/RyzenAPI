-- Lua provided by RyzenAPI
-- Game: Gamer Girls: Futanari

-- MAIN APPLICATION
addappid(2091160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091161, 1, "b586307fce3b63fcfb8516529ad57b3fb3f44136057da03b80db97f1dbc67f8f")

