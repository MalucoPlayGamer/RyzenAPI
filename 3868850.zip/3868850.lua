-- Lua provided by RyzenAPI
-- Game: MISHA

-- MAIN APPLICATION
addappid(3868850)
addappid(5067890)

