-- Lua provided by RyzenAPI
-- Game: MISHA

-- MAIN APPLICATION
addappid(3868850)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5067890)
