-- Lua provided by RyzenAPI
-- Game: addappid(2245410)

-- MAIN APPLICATION
addappid(2245410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245411, 1, "dfaca8c5b716bbc33beea6ac4af7986a9e3d1b02250e793e3e1b8a06b3d91595")
