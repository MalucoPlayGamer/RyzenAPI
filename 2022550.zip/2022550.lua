-- Lua provided by RyzenAPI
-- Game: My Furry Protogen - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(2022550)
-- Game: addappid(2022550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022550,0,"653ed9f6ef6f4166a157637ab7ed6cc82a82279f2202f67d9affb5ab60e01a96")
