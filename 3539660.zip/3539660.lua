-- Lua provided by RyzenAPI
-- Game: 3539660

-- MAIN APPLICATION
addappid(3539660)
-- Game: addappid(3539660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3539660,0,"c64f6bece46133b9f8f24e0b12a1821dcbadd0403ab821468c227b9c99d46dee")
