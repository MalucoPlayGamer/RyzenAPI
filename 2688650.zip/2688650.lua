-- Lua provided by RyzenAPI
-- Game: PERFECT CELLS PROJECT

-- MAIN APPLICATION
addappid(2688650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688651, 1, "50646eec57cc75ca096b575348925251716c3510bc89bac343e019f21c83168e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
