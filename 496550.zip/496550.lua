-- Lua provided by RyzenAPI
-- Game: AppID 496550

-- MAIN APPLICATION
addappid(496550)

-- MAIN APP DEPOTS / PACKAGES
addappid(496551, 1, "c6b8038fabeec164d832b8fd5b47dd0b2ea7bf075c0b70f7b8e4f6492d4d4ee8")
