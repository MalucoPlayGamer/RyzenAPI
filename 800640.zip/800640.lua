-- Lua provided by RyzenAPI
-- Game: Xtreme Paddleball

-- MAIN APPLICATION
addappid(800640)

-- MAIN APP DEPOTS / PACKAGES
addappid(800641,0,"b1e39b3a7de9e66309eaa330f6adf5dd0a16b967df74d27e6259977547666563")

