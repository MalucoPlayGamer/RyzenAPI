-- Lua provided by RyzenAPI
-- Game: Game: AppID 298140

-- MAIN APPLICATION
addappid(298140)
-- Game: addappid(298140)

-- MAIN APP DEPOTS / PACKAGES
addappid(298141, 1, "79abbccb14e3ad7e87bc264576d10a9b6fb4c37a7a12bc015089cd9af85fcf6e")
