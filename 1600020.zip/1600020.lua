-- Lua provided by RyzenAPI
-- Game: Eddie Hill in the Curse of the Skull Medallion

-- MAIN APPLICATION
addappid(1600020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600021, 1, "c0f295235a4c40cc832300799cb53668e26c6711a26b486f7b378b9fd869b474")
addappid(1600022, 1, "849195f58348cbcc1bcbc4734384aa16f989a7480d3d4a1af5003518770d3bdb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
