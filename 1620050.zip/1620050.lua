-- Lua provided by RyzenAPI
-- Game: Sole Survivor: Stages of Death

-- MAIN APPLICATION
addappid(1620050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620052,0,"adfab58d5201e9ff5ef679dcee237eb230b601b39757684eee37bdfc9e35aad5")

