-- Lua provided by RyzenAPI
-- Game: addappid(1896800)

-- MAIN APPLICATION
addappid(1896800)
addappid(2641820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896801, 1, "8057a08edf6b867e4a51a13cbd19767a0886982f4b945b1f0b7865f1c7886299")
