-- Lua provided by RyzenAPI
-- Game: addappid(1713680)

-- MAIN APPLICATION
addappid(1713680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713681, 1, "ea8b557699439dac0978232e703a1bc22eae35e3b5bae7a4f9ee0522b12c93cb")
