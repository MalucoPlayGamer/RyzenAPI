-- Lua provided by RyzenAPI
-- Game: Driver4VR

-- MAIN APPLICATION
addappid(1366950)
addappid(1529611)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366951, 1, "80d8ed60372562417003680d8dead18e48da889f884e42df6a048b6aeb6baf56")
addappid(2928420, 0, "a9a3a29e85e0e9ab9adc64c7e1f9f298f485b992c0359d5e56393c084c4b0452")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
