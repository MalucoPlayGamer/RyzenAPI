-- Lua provided by RyzenAPI
-- Game: Driver4VR

-- MAIN APPLICATION
addappid(1366950)
addappid(1529611)
-- Game: addappid(1366950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366951, 1, "80d8ed60372562417003680d8dead18e48da889f884e42df6a048b6aeb6baf56")
addappid(2928420, 0, "a9a3a29e85e0e9ab9adc64c7e1f9f298f485b992c0359d5e56393c084c4b0452")
