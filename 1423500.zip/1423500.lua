-- Lua provided by RyzenAPI
-- Game: Darklands:Awakening

-- MAIN APPLICATION
addappid(1423500)
-- Game: addappid(1423500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423501, 1, "161eb0d7bec41e6244b9478ca07c3d88fa8159c9c69a98943edbe522766f298c")
