-- Lua provided by RyzenAPI
-- Game: Labyrinths of the World: Forbidden Muse Collector's Edition

-- MAIN APPLICATION
addappid(695980)

-- MAIN APP DEPOTS / PACKAGES
addappid(695981, 1, "8a2605947e63a1c235d5069646ba68ac19f3cbea4867147051aef12c65b13538")
addappid(695984, 1, "0321523775b09a0d61d83c059943be8094fc56c19ca91c67b77e5770a919d748")
addappid(695985, 1, "79718fbc77dc8adedde4c25df6a5db74f977b4b5e5002b243f03f226932fbf7f")
