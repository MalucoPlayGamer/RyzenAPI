-- Lua provided by RyzenAPI
-- Game: RATUZ Demo

-- MAIN APPLICATION
addappid(1669830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669831, 1, "caa582d364fb6c7218179cb3f82b44f6cbf43fbf57c6a10827c8eaf91aaf6b70")
