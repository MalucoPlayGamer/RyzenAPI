-- Lua provided by RyzenAPI
-- Game: Girls! Girls! Girls!?

-- MAIN APPLICATION
addappid(1412310)
addappid(4782080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412311, 1, "68892300961ed5f04a8b05c345fefefc14337090896cbec59785d19ee8bb3d92")

