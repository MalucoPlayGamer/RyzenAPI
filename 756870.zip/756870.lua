-- Lua provided by RyzenAPI
-- Game: Anubis Dungeon

-- MAIN APPLICATION
addappid(756870)

-- MAIN APP DEPOTS / PACKAGES
addappid(756871, 1, "aca9de835d5c32240c988a571782ed26584208b3ead21affc94527b0950fa7e1")
