-- Lua provided by RyzenAPI
-- Game: Game: AppID 323470

-- MAIN APPLICATION
addappid(323470)
-- Game: addappid(323470)

-- MAIN APP DEPOTS / PACKAGES
addappid(323471, 1, "a92b27f33a671ba1ff67c80c0508d6f8d276ac2936d558fba95d8dc83e5b0765")
addappid(323473, 1, "a9fc74b57e30b5d14ca436ebad3a4136d68941ba504102597afbb6410ec4c983")
