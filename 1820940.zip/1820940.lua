-- Lua provided by RyzenAPI
-- Game: 1820940

-- MAIN APPLICATION
addappid(1820940)
-- Game: addappid(1820940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820941, 1, "ab03a6461de6f12d2ffed4b8c55b523cd5f2054e3857abd9dcfa465eb0bfd951")
