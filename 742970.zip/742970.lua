-- Lua provided by RyzenAPI
-- Game: Oraxum Trials

-- MAIN APPLICATION
addappid(742970)
-- Game: addappid(742970)

-- MAIN APP DEPOTS / PACKAGES
addappid(742972,0,"9935557ec682dfeddb75406eb0b90813871e8a51d3adacdb1d7fca3f92d49238")
