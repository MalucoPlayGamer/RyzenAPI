-- Lua provided by RyzenAPI
-- Game: Moon Watch

-- MAIN APPLICATION
addappid(2878030)
-- Game: addappid(2878030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878031, 1, "555a6d453705ccdcbccee970b4254ebe6dcb99adcc4b9697b091e872437c5707")
