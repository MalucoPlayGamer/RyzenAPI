-- Lua provided by RyzenAPI
-- Game: addappid(1236160)

-- MAIN APPLICATION
addappid(1236160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236161, 1, "590f363394c7a6ce0b5c65bf09a68988d4cfc063cfd1b778d5e23a31f6357082")
