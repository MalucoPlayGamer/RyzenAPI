-- Lua provided by RyzenAPI
-- Game: The Last Archwing

-- MAIN APPLICATION
addappid(1236160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1236161, 1, "590f363394c7a6ce0b5c65bf09a68988d4cfc063cfd1b778d5e23a31f6357082")
