-- Lua provided by RyzenAPI
-- Game: AppID 1136870

-- MAIN APPLICATION
addappid(1136870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136871, 1, "00c25f5411a3ceccc957fcc0f9d187c1a608fdcb47757908b49c2f57ab2dc25a")
