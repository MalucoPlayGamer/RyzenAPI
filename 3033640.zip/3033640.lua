-- Lua provided by RyzenAPI
-- Game: BloodLight Demo

-- MAIN APPLICATION
addappid(3033640)
-- Game: addappid(3033640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033641, 1, "2d424e86757c887fd389c70fcff61cd859cf322d2a195d088527ccf709be1e07")
