-- Lua provided by RyzenAPI 
-- Game: Hacker News Reader
addappid(834410)
addappid(834411, 1, "ee5a256972c51c53329c6a3f0eacb0e42f0bd0e29707c55732988e09c4885092")
