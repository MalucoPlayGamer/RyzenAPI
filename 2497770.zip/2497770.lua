-- Lua provided by RyzenAPI
-- Game: Captain Velvet Meteor: The Jump+ Dimensions Soundtrack

-- MAIN APPLICATION
addappid(2497770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497771, 1, "7fc2c086f42c9a38123bbdacb7c1e4f0cc7afa9a6629028491526c1ff3bd240f")
addappid(2497772, 1, "bed410966688ad538d542402616a073b6bdc084cb9651c210f527128ccc2c51f")

