-- Lua provided by RyzenAPI
-- Game: Gods vs Horrors Soundtrack

-- MAIN APPLICATION
addappid(3714650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714651, 1, "c1944a7a2742cba00ebacdb944cbecabc8f18d426b8dc868f1ca188d4f0145ce")
