-- Lua provided by RyzenAPI
-- Game: GRANDIA II HD Remaster

-- MAIN APPLICATION
addappid(330390)

-- MAIN APP DEPOTS / PACKAGES
addappid(330391, 1, "034c555822818a34680717ac4c3a45f72b03068ed428ba2d785af398065b51fd")
addappid(330392, 1, "af019e58e764adf7d378a04f3deaeaa27363490a16d996637915feb71d47d473")
addappid(330393, 1, "dace1bdf390c3c0645a1f908d09e00f301cc474dffe5550097b560ba9f6caaed")
addappid(330394, 1, "5d491a91d6e1f174d401e2ed00954f4b507c66305d014e9aeecb83772a05115e")
addappid(330395, 1, "daccd4698e1bc489e8a236a8bfb78eac3063040d86e98c0dbfb5685d5085d72d")
addappid(330396, 1, "801d5170237605c7e155a7f45d97aee1d1ba0df1baa5188b66c56bc2f964440d")
addappid(330397, 1, "60474ad589d96b197d99415b6f594c9edb65464489768204191883ea47151d94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
