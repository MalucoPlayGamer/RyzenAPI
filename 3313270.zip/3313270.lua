-- Lua provided by RyzenAPI
-- Game: Love, Money, Rock'n'Roll – Summer '94

-- MAIN APPLICATION
addappid(3313270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313271, 1, "b84eb4f7cb72255db05d693f7079a66559295e2782cbe4a7342e3b7014bfa437")
