-- Lua provided by RyzenAPI
-- Game: Game: The Color of the Roses

-- MAIN APPLICATION
addappid(1040720)
-- Game: addappid(1040720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040721, 1, "aad9f222b500132bc69bcc143b133212c3cc1d6d662de4ca1388ad67f8817cc2")
addappid(1040722, 1, "a4e05e4982a16c17d444725057a0e2ca9495023f7255b4676042d640f632bab5")
addappid(1040723, 1, "50119beb6f5edbb5e603fe4e8b50938a3d3c4ffe024d69aaf0d6387e86482603")
