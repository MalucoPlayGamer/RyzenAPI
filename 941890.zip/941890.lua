-- Lua provided by RyzenAPI
-- Game: addappid(941890)

-- MAIN APPLICATION
addappid(941890)

-- MAIN APP DEPOTS / PACKAGES
addappid(941892,0,"694bff5ba591d9fbeef66d29f3465717ad3f05ed09c03120b76f14c5ef12fb9a")
