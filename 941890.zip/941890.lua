-- Lua provided by RyzenAPI
-- Game: Mini Matches

-- MAIN APPLICATION
addappid(941890)

-- MAIN APP DEPOTS / PACKAGES
addappid(941892,0,"694bff5ba591d9fbeef66d29f3465717ad3f05ed09c03120b76f14c5ef12fb9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
