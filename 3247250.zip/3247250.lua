-- Lua provided by RyzenAPI
-- Game: addappid(3247250)

-- MAIN APPLICATION
addappid(3247250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247251, 1, "2e3718a515f9b4c89d416b8fcc3d34ba42a670cbb30b566fa581f98d19af434d")
