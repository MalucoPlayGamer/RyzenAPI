-- Lua provided by RyzenAPI
-- Game: The Cathedral: Allison's Diary

-- MAIN APPLICATION
addappid(793210)

-- MAIN APP DEPOTS / PACKAGES
addappid(793211, 1, "22b288127b23080c96f8c1f5806d6a8490852a2650819ea306989fe345cb8a4d")

