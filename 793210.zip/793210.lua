-- Lua provided by RyzenAPI
-- Game: The Cathedral: Allison's Diary

-- MAIN APPLICATION
addappid(793210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(793211, 1, "22b288127b23080c96f8c1f5806d6a8490852a2650819ea306989fe345cb8a4d")

