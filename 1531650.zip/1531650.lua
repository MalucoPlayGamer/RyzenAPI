-- Lua provided by RyzenAPI
-- Game: AppID 1531650

-- MAIN APPLICATION
addappid(1531650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531651, 1, "249c2c639f2a8c4ad261e9a938496ba030a7c97996664df2e59d479b2e3cf817")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
