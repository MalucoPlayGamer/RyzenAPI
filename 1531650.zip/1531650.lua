-- Lua provided by RyzenAPI
-- Game: AppID 1531650

-- MAIN APPLICATION
addappid(1531650)
-- Game: addappid(1531650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531651, 1, "249c2c639f2a8c4ad261e9a938496ba030a7c97996664df2e59d479b2e3cf817")
