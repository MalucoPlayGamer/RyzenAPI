-- Lua provided by SkyAPI 
-- Game: Dungeon Lord
addappid(1429670)
addappid(1429671, 1, "36769eb156c4487c57e8c9370e0f3cd8acc50acb3c4a1c4b50fb51393b116815")
