-- Lua provided by RyzenAPI
-- Game: Game: Train Operator 377 Free Version

-- MAIN APPLICATION
addappid(2458800)
-- Game: addappid(2458800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458801, 1, "9afc7fbadfdd462889770ec13660838f2eb8570d7bcfdb26162d178648c6ee47")
