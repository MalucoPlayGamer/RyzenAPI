-- Lua provided by RyzenAPI
-- Game: Killer in the cabin

-- MAIN APPLICATION
addappid(1382190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382191, 1, "4897c460c485d61eec15b09ce6c3b3f18a55e7f8dc5a5918d59e923552900a40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
