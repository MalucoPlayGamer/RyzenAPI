-- Lua provided by RyzenAPI
-- Game: 1382190

-- MAIN APPLICATION
addappid(1382190)
-- Game: addappid(1382190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382191, 1, "4897c460c485d61eec15b09ce6c3b3f18a55e7f8dc5a5918d59e923552900a40")
