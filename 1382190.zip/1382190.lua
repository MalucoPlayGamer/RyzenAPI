-- Lua provided by RyzenAPI 
-- Game: Killer in the cabin
addappid(1382190)
addappid(1382191, 1, "4897c460c485d61eec15b09ce6c3b3f18a55e7f8dc5a5918d59e923552900a40")
