-- Lua provided by RyzenAPI
-- Game: ISEKAI FRONTLINE : ASCENSION

-- MAIN APPLICATION
addappid(3134170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134170,0,"7f89d233a8bbc805a7a2769b232bab8351bf102eadfbc5db2ac5d631cefecdcd")

