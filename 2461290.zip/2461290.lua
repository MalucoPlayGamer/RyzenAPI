-- Lua provided by RyzenAPI
-- Game: Game: AppID 2461290

-- MAIN APPLICATION
addappid(2461290)
-- Game: addappid(2461290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461291, 1, "3c4891766dcbf5e1b2ef1765bbbdfb464aef14c27ccb801dc81dd334b329daff")
