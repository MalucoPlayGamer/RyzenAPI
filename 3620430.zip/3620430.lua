-- Lua provided by RyzenAPI 
-- Game: AppID 3620430
addappid(3620430)
addappid(3620431, 1, "8e7603716f55551551ee6230ecfeb973167a951a3db8fed8f1967d1351b8a8e2")
