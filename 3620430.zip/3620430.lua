-- Lua provided by RyzenAPI
-- Game: Game: AppID 3620430

-- MAIN APPLICATION
addappid(3620430)
-- Game: addappid(3620430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3620431, 1, "8e7603716f55551551ee6230ecfeb973167a951a3db8fed8f1967d1351b8a8e2")
