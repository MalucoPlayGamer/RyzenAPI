-- Lua provided by RyzenAPI
-- Game: 2864210

-- MAIN APPLICATION
addappid(2864210)
-- Game: addappid(2864210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864211, 1, "a4b84c3bc3ed75b92fb4e3dd31d37c9a8aeaae6ca2847441066159159242969f")
