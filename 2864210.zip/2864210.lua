-- Lua provided by RyzenAPI
-- Game: Tomboy: Sex in the Forest

-- MAIN APPLICATION
addappid(2864210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864211, 1, "a4b84c3bc3ed75b92fb4e3dd31d37c9a8aeaae6ca2847441066159159242969f")
