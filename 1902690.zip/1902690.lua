-- Lua provided by RyzenAPI
-- Game: Fate/Samurai Remnant

-- MAIN APPLICATION
addappid(1902690)
-- Game: addappid(1902690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902696,0,"2c161b45268703111406d401c4988a92b8b22736a9d11cc377ca3b3268f70917")
