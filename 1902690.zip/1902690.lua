-- Lua provided by RyzenAPI
-- Game: Fate/Samurai Remnant

-- MAIN APPLICATION
addappid(1902690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902696,0,"2c161b45268703111406d401c4988a92b8b22736a9d11cc377ca3b3268f70917")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2407210)
addappid(2426930)
addappid(2426931)
addappid(2473120)
addappid(2473121)
addappid(2494220)
addappid(2494230)
addappid(2494240)
addappid(2494250)
