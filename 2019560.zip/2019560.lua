-- Lua provided by RyzenAPI
-- Game: Pretty Girls Escape Demo

-- MAIN APPLICATION
addappid(2019560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019561, 1, "3c28b959d8e923a6b61f58f58c4f759a746d4fbd6a29aa26e7a302e0ff4af793")
