-- Lua provided by RyzenAPI
-- Game: A Quiet Place: The Road Ahead

-- MAIN APPLICATION
addappid(2233120)
addappid(3061600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2233121, 1, "908cc3ca235e2d744c3f800596e90f596fe3b9acd68a130ec56985fbdf262212")

