-- Lua provided by RyzenAPI
-- Game: 823670

-- MAIN APPLICATION
addappid(823670)
-- Game: addappid(823670)

-- MAIN APP DEPOTS / PACKAGES
addappid(823671, 1, "3b316bf5938b5d38d92db035433626aaf13aacfc6c99d2cfd00f4badbb3ee042")
