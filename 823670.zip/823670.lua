-- Lua provided by RyzenAPI
-- Game: HYKEE - Episode 1: Underwater

-- MAIN APPLICATION
addappid(823670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(823671, 1, "3b316bf5938b5d38d92db035433626aaf13aacfc6c99d2cfd00f4badbb3ee042")

