-- Lua provided by RyzenAPI
-- Game: HYKEE - Episode 1: Underwater

-- MAIN APPLICATION
addappid(823670)

-- MAIN APP DEPOTS / PACKAGES
addappid(823671, 1, "3b316bf5938b5d38d92db035433626aaf13aacfc6c99d2cfd00f4badbb3ee042")
