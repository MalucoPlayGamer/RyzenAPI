-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Jia Chong "Knight Costume" / 賈充「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019987)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019987,0,"df85bb74092dd648fabbd7be39fad2d952f1d01d60c9f3f83207449af7e800a5")
