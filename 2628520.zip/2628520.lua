-- Lua provided by RyzenAPI
-- Game: Retrowave World Demo

-- MAIN APPLICATION
addappid(2628520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628521, 1, "beb17147010379a87447d38126ea0580ab53d98c278d1a752493c297a4e49c41")
