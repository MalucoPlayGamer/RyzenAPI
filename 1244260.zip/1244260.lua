-- Lua provided by RyzenAPI
-- Game: 1244260

-- MAIN APPLICATION
addappid(1244260)
-- Game: addappid(1244260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244261, 1, "0a935a271c8de2e1a3ec9b9f0c3add880955648215b1a18c8ba442292e487b39")
