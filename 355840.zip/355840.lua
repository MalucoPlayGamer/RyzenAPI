-- Lua provided by RyzenAPI
-- Game: addappid(355840)

-- MAIN APPLICATION
addappid(355840)

-- MAIN APP DEPOTS / PACKAGES
addappid(355841, 1, "9c9c6a1f0490be9257d1b8f4641f76334c30aecaa26229501efb3cec631a7454")
