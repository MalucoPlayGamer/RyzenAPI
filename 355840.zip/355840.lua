-- Lua provided by RyzenAPI
-- Game: Survarium

-- MAIN APPLICATION
addappid(355840)
addappid(358820)
addappid(359520)
addappid(359521)
addappid(359522)
addappid(369490)
addappid(456800)
addappid(456801)
addappid(456802)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(355841, 1, "9c9c6a1f0490be9257d1b8f4641f76334c30aecaa26229501efb3cec631a7454")

