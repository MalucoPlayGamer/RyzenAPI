-- Lua provided by RyzenAPI
-- Game: Knight's Retreat

-- MAIN APPLICATION
addappid(1261700)
addappid(2007450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261701, 1, "0a610075fb8f115e37185a64c75e2cbb8892d94ebb8995519be8086de40a63bc")

