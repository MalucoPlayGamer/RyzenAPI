-- Lua provided by RyzenAPI
-- Game: Game: 执谕者：坠月之兆（Archenemy: Lunafall）

-- MAIN APPLICATION
addappid(1497250)
-- Game: addappid(1497250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497251, 1, "1202f807015a7b976b6dd1d3155a69cee8eda5b1f802a4c5248e3adf52412c7c")
