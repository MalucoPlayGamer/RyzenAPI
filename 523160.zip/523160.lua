-- Lua provided by RyzenAPI
-- Game: 523160

-- MAIN APPLICATION
addappid(523160)
-- Game: addappid(523160)

-- MAIN APP DEPOTS / PACKAGES
addappid(523161, 1, "8e1ece544428bb9afee4c467c1d01e2c60aa179f0dd50af065f39ba5291e7f53")
