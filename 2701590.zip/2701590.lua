-- Lua provided by RyzenAPI
-- Game: Cthulhu Mythos ADV The Isle Of Ubohoth

-- MAIN APPLICATION
addappid(2701590)
-- Game: addappid(2701590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701591, 1, "a75e49f9ab8a885f0a5a14bba249f8a1877bed55604769a8e6da5cb46b343370")
