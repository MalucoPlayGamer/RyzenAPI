-- Lua provided by RyzenAPI 
-- Game: AppID 904700
addappid(904700)
addappid(904701, 1, "72595e7c981ac8b1a909c63098f2bc0337dbd1b3e59b13c81f5962dd84cfc8cf")
addappid(904702, 1, "74c3334c88c7f3cb93700761e22d23029c0e495756d8180483200eac6473c0cc")
