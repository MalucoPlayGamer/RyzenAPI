-- Lua provided by RyzenAPI
-- Game: Game: Zen World

-- MAIN APPLICATION
addappid(1485650)
-- Game: addappid(1485650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485651, 1, "b0d286759ab173406ae1ab29ba8ef22d6e97aeb4dba0ee6c3006c90bce3c5cc2")
