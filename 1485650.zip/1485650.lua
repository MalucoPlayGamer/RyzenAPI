-- Lua provided by RyzenAPI
-- Game: Zen World

-- MAIN APPLICATION
addappid(1485650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485651, 1, "b0d286759ab173406ae1ab29ba8ef22d6e97aeb4dba0ee6c3006c90bce3c5cc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
