-- Lua provided by RyzenAPI
-- Game: AppID 263280

-- MAIN APPLICATION
addappid(263280)

-- MAIN APP DEPOTS / PACKAGES
addappid(263281, 1, "3585d18682ade52fa9221944b2d43b37a7455cad1c90773fe1b189516f1e71b0")
addappid(1148580, 0, "eac44f269942c8fbcc649241c5439a65ed1a32e2d66952679bf83a956dc39333")
addappid(1151110, 0, "97e8922f86cb6b53f91e61bb8d5506b49e12ffc17bea92dc213f6290f30f30ca")
addappid(1151111, 0, "6e0e1f2fdd66da732aa8997c21c3045ef857ae4eb3957f1fe6a507daa8debc93")
addappid(1346080, 0, "f544985a1aad2dadc773473f41ad348fdeaee887b3254a3e43832c3ac7d43832")
addappid(1472710, 0, "2084e10a970d4af996c8938a947ceeb3bf56a45617ae29c93606e580dd5d1ee7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1346090)
