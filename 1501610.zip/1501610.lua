-- Lua provided by SkyAPI 
-- Game: Nova Lands
addappid(1501610)
addappid(1501611, 1, "040144475f0922f22cb9b016955be1807da6921eae9a65fd28403a55c129c3ed")
addappid(1501612, 1, "927897f0face8534d1af67a7dd03b619d8da511bc57fd4a1f5a0d4fc295c9d1d")
addappid(2287120, 0, "5dde54665ac34acac651e13aefaee864f061e9e1fae04c201fa9a45b50c2c2c3")
