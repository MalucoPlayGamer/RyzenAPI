-- Lua provided by RyzenAPI
-- Game: Game: AppID 417890

-- MAIN APPLICATION
addappid(417890)
-- Game: addappid(417890)

-- MAIN APP DEPOTS / PACKAGES
addappid(417891, 1, "2045350ddd797464616bcbf4b2e9fc332b289383d134b0c1878fcd6a76b39ec7")
