-- Lua provided by RyzenAPI
-- Game: Apotheon Arena

-- MAIN APPLICATION
addappid(417890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(417891, 1, "2045350ddd797464616bcbf4b2e9fc332b289383d134b0c1878fcd6a76b39ec7")

