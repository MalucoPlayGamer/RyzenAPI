-- Lua provided by RyzenAPI 
-- Game: Spirit Mancer Demo
addappid(2187350)
addappid(2187351, 1, "8677a0dc9c12d4445ea6984c00067b38b9de6cdbef26c9e3a34542b823f6ad89")
