-- Lua provided by RyzenAPI
-- Game: Toilet Paper Unleashed

-- MAIN APPLICATION
addappid(1370580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370581, 1, "6d13f39ac7335f0c036fe66c4f94254625c97670e5e48891f4813f5dfde495e8")
