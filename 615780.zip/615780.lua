-- Lua provided by RyzenAPI
-- Game: AppID 615780

-- MAIN APPLICATION
addappid(615780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(615781, 1, "b412bde724778ff5ec72ebaaa35dfad1990646b10e90bfd44ecbbce450becdcf")

