-- Lua provided by RyzenAPI 
-- Game: AppID 615780
addappid(615780)
addappid(615781, 1, "b412bde724778ff5ec72ebaaa35dfad1990646b10e90bfd44ecbbce450becdcf")
