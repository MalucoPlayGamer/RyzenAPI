-- Lua provided by RyzenAPI
-- Game: 2635410

-- MAIN APPLICATION
addappid(2635410)
-- Game: addappid(2635410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635411, 1, "85f25cf9fce063cc563d5a014d870365cf60e0cb9d4dbac66663659ce78b1a28")
