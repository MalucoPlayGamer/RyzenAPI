-- Lua provided by RyzenAPI
-- Game: Holdfast: Nations At War Playtest

-- MAIN APPLICATION
addappid(2635410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635411, 1, "85f25cf9fce063cc563d5a014d870365cf60e0cb9d4dbac66663659ce78b1a28")
