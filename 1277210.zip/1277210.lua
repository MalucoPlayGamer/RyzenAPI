-- Lua provided by RyzenAPI
-- Game: addappid(1277210)

-- MAIN APPLICATION
addappid(1277210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277211, 1, "2dd80763e86e71e291b4f0fe164a910082fba17dddf56f624b12ef937e45d2b3")
