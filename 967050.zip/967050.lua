-- Lua provided by RyzenAPI 
-- Game: Pacify
addappid(967050)
addappid(967051, 1, "f96aef139156453d9d43b1bcf8871a2d27acaec7129cc3270b195cddb35654fb")
addappid(967052, 1, "a68832c81999178d3d4e7f79aae6866804866e68ec397a9cb74bb870e0083b60")
