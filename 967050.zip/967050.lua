-- Lua provided by RyzenAPI
-- Game: Pacify

-- MAIN APPLICATION
addappid(967050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(967051, 1, "f96aef139156453d9d43b1bcf8871a2d27acaec7129cc3270b195cddb35654fb")
addappid(967052, 1, "a68832c81999178d3d4e7f79aae6866804866e68ec397a9cb74bb870e0083b60")

