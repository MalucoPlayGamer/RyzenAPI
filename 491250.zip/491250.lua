-- Lua provided by RyzenAPI
-- Game: addappid(491250)

-- MAIN APPLICATION
addappid(491250)
addappid(491500)

-- MAIN APP DEPOTS / PACKAGES
addappid(491251, 1, "32227d8468f860ca312d8e9793d6e67bf71e00da516fd3a6235fffa8854db175")
