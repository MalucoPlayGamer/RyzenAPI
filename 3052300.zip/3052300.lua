-- Lua provided by RyzenAPI
-- Game: Game: AppID 3052300

-- MAIN APPLICATION
addappid(3052300)
-- Game: addappid(3052300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052301, 1, "0141c0a87a18ad1194e1eb31a42eaf407935beb66b1565ecef2039669f884ac3")
