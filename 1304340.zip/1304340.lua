-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame 4

-- MAIN APPLICATION
addappid(1304340)
addappid(1468140)
addappid(1472470)
addappid(1472480)
addappid(1472490)
addappid(1472500)
addappid(1472510)
addappid(1472520)
addappid(1472530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1304341, 1, "3d9a7c2ca1147c026143a07901924be8a2bc38a46a195518c5f48519f13abb25")

