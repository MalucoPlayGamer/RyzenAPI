-- Lua provided by RyzenAPI
-- Game: Runaway Train

-- MAIN APPLICATION
addappid(615080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(615081, 1, "1600b02419cdba9ec4433388fd1c5bc63c194549e75264e6a347b580862d477c")

