-- Lua provided by RyzenAPI
-- Game: Game: AppID 584640

-- MAIN APPLICATION
addappid(584640)
-- Game: addappid(584640)

-- MAIN APP DEPOTS / PACKAGES
addappid(584641, 1, "21b593c003dc1fa9d6fc01ee6011affa58ddf5a99d6f018a87a15eb27c8a5f1f")
