-- Lua provided by RyzenAPI
-- Game: 2427741

-- MAIN APPLICATION
addappid(2427741)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427741,0,"d2166f8c2e87ec7b0900a190c9cc19ee010fdd65fd616e23a0f5e7c86ab7f6b4")
