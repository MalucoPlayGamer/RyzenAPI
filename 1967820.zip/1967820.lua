-- Lua provided by SkyAPI 
-- Game: Border Town
addappid(1967820)
addappid(1967821, 1, "631e707a73378d4f77ae16909b3dfd15cae9c1edd074e78added4f63331fe912")
