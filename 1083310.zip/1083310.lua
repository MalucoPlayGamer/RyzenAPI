-- Lua provided by RyzenAPI 
-- Game: AppID 1083310
addappid(1083310)
addappid(1083311, 1, "e62a8b4f8f5f045d1a434a687f11c58dd40aff66fe905bd09dd9e155490db9cb")
