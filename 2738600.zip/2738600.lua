-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2738600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738602,0,"91db01b4469d8a0b8de09d636de48c9a811a7b062d74138949cade658055112e")

