-- Lua provided by RyzenAPI
-- Game: addappid(223220)

-- MAIN APPLICATION
addappid(223220)
addappid(228981)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229000)
addappid(229002)

-- MAIN APP DEPOTS / PACKAGES
addappid(223221, 1, "82cef6b718ca8aa6a23da2b22d5dfc50f1550d783fd8649255524fcfd23b6ebc")
addappid(326370, 0, "a5cb031ce9d09a584d9fb4ecf30189c5adf6e351c610e8b9d3176ea0d503b55b")
