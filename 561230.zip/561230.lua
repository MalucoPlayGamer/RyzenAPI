-- Lua provided by RyzenAPI
-- Game: Special Delivery

-- MAIN APPLICATION
addappid(561230)

-- MAIN APP DEPOTS / PACKAGES
addappid(561231,0,"08f9d33d56d4f491bf1039a02d51a99cb7c236f72e96e59f34e4bc7cbd52a85e")

