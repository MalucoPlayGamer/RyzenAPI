-- Lua provided by RyzenAPI
-- Game: Special Delivery

-- MAIN APPLICATION
addappid(561230)

-- MAIN APP DEPOTS / PACKAGES
addappid(561231,0,"08f9d33d56d4f491bf1039a02d51a99cb7c236f72e96e59f34e4bc7cbd52a85e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
