-- Lua provided by RyzenAPI
-- Game: 2565480

-- MAIN APPLICATION
addappid(2565480)
-- Game: addappid(2565480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565481, 1, "20c69c2d67cf82471638bf1cfc429aa37cbb36c7218d8d5d80a3bced312fcb14")
