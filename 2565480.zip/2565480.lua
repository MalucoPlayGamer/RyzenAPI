-- Lua provided by RyzenAPI
-- Game: Ego

-- MAIN APPLICATION
addappid(2565480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565481, 1, "20c69c2d67cf82471638bf1cfc429aa37cbb36c7218d8d5d80a3bced312fcb14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
