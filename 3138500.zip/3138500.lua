-- Lua provided by RyzenAPI
-- Game: Game: The Simp - 舔狗

-- MAIN APPLICATION
addappid(3138500)
-- Game: addappid(3138500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138501, 1, "094240c1df1a7ff2da3357699cc92f7ef3613ac5f7ca417f0a24b0fe754c4066")
