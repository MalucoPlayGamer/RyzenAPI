-- Lua provided by RyzenAPI
-- Game: Dragona: Fireborne

-- MAIN APPLICATION
addappid(2668250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668251, 1, "b16d045fdf7cb8c24345a9917cf3721549ca8742f1512ebf4c6c139005fee1a4")
