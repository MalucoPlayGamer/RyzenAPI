-- Lua provided by RyzenAPI
-- Game: addappid(2465880)

-- MAIN APPLICATION
addappid(2465880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465881, 1, "8d6dcdd860f588af79db97111bc185b7b25301d3b5553c8013e17841863d12db")
