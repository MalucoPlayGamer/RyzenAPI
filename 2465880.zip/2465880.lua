-- Lua provided by SkyAPI 
-- Game: Touch Force
addappid(2465880)
addappid(2465881, 1, "8d6dcdd860f588af79db97111bc185b7b25301d3b5553c8013e17841863d12db")
