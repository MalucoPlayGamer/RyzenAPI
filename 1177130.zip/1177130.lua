-- Lua provided by RyzenAPI
-- Game: addappid(1177130)

-- MAIN APPLICATION
addappid(1177130)
addappid(1177131)
addappid(1177133)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177132,0,"6fdbc1079750f9bbe8469def200430c0afe2ead3a4e8cad92f642c5e808f576a")
