-- Lua provided by RyzenAPI
-- Game: My Secret Pets!

-- MAIN APPLICATION
addappid(447180)
addappid(449910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(447181, 1, "23b1e07810e4c02fb97b6549315a6e5a18e313af62154cf7d12b62a3ebeb6bdb")

