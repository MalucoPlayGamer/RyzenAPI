-- Lua provided by RyzenAPI
-- Game: Game: My Secret Pets!

-- MAIN APPLICATION
addappid(447180)
addappid(449910)
-- Game: addappid(447180)

-- MAIN APP DEPOTS / PACKAGES
addappid(447181, 1, "23b1e07810e4c02fb97b6549315a6e5a18e313af62154cf7d12b62a3ebeb6bdb")
