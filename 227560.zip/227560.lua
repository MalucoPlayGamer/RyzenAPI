-- Lua provided by RyzenAPI
-- Game: Game: Scourge: Outbreak

-- MAIN APPLICATION
addappid(227560)
addappid(228981)
addappid(228983)
addappid(228990)
addappid(229031)
-- Game: addappid(227560)

-- MAIN APP DEPOTS / PACKAGES
addappid(227561, 1, "d47416319610e94d6a2ccfbb59dd93ef646cb4bef4a70300bbfb459984d40d64")
addappid(227562, 1, "454e79d13acdc3e7f86d33916304dc28b09fa05279bedb9cb6b1e6dd79addeef")
addappid(227563, 1, "ff6e6e9f94b0a7d97ede65d4e14bc57c9ae62ee132014021259dcb1d8d27ac4d")
addappid(227569, 1, "cc9b8cf61cc5be6c114d8a27b8d4dc51d271c7c9820456064dc03b2b71f37409")
addappid(270650, 0, "15c957be4ef85de96fce513f51cc541280611ec8216d1c39724143dd75e7b099")
