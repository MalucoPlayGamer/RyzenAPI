-- Lua provided by RyzenAPI
-- Game: Space Calibrator

-- MAIN APPLICATION
addappid(3368750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3368752,0,"0ec144a80c005f56f534de2ab9281c8fb21a5ef2ccd573d3a5a9ae7c9eae7632")
addappid(3368753,0,"7b4550bca0ee20e1c1b20f91443742d8d6932504e88ad0a84fbb5031f9844753")

