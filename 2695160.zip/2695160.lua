-- Lua provided by RyzenAPI
-- Game: addappid(2695160)

-- MAIN APPLICATION
addappid(2695160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695161, 1, "dd0635fcb252075f5faae978dcc499294e5440039662f95d89515ae8bf8b3c4b")
