-- Lua provided by RyzenAPI
-- Game: Game: Elder Legacy: Survival

-- MAIN APPLICATION
addappid(3122990)
-- Game: addappid(3122990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122991, 1, "e461ef16911a425dd4d5f514e2c9fdeedb720275f418e5830097ba6b10bc9166")
