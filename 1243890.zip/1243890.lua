-- Lua provided by RyzenAPI
-- Game: Sword of the Necromancer

-- MAIN APPLICATION
addappid(1243890)
addappid(1640870)
addappid(1674680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243891, 1, "6502ee7e2d8e7c608313ed7af6770698daa0305cb1be8a952a95af50fd00e08d")

