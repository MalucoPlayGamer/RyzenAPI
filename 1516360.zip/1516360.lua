-- Lua provided by RyzenAPI
-- Game: Red Galaxy

-- MAIN APPLICATION
addappid(1516360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516361, 1, "ab3cc70a67f32e76bab9dcbcb9806fc334216d75fe3c487f32d30f0d524f0a51")
