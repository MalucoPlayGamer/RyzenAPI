-- Lua provided by RyzenAPI
-- Game: Game: Medieval: Total War™ - Collection

-- MAIN APPLICATION
addappid(345260)
-- Game: addappid(345260)

-- MAIN APP DEPOTS / PACKAGES
addappid(345261, 1, "cbd743f4b792e1612fa1da2951c069a26ba192ebc449dd897238ca0b12f4a626")
addappid(345262, 1, "d0c259c2d1ced9f7680ac51d8acadb034b65ad4188084f454ffc99ef0f03bd9c")
addappid(345263, 1, "64b054228e75f3e649f70e02f827b64c848dccb677d9817eb869e6bd752b8225")
addappid(345264, 1, "6e05b4e8e27bcd6aa1879cae8e1c7bbeff74f61953b4f9e9d863d1e10c6e609d")
addappid(345265, 1, "4955e18d0c1a86b796eebf3d1508e2d10ff00aad9549390eb97dc96ae6858ca6")
addappid(345266, 1, "f1e413a476f127ff1220f3afb9ccac82d6131ad7509696c1c50f5999ca91b545")
addappid(372531, 0, "85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504")
