-- Lua provided by RyzenAPI
-- Game: ARK Park

-- MAIN APPLICATION
addappid(529910)

-- MAIN APP DEPOTS / PACKAGES
addappid(529911, 1, "814a4160dd46ab0be70d8220a9a97f69177a60ed80e0ad575aff65bdba24909d")
addappid(819750, 0, "2d6b8d5a1b9a0328a7cdb2b74f30175066bc7f77c3010faffea372a0e44208ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
