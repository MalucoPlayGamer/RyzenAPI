-- Lua provided by SkyAPI 
-- Game: ARK Park
addappid(529910)
addappid(529911, 1, "814a4160dd46ab0be70d8220a9a97f69177a60ed80e0ad575aff65bdba24909d")
addappid(819750, 0, "2d6b8d5a1b9a0328a7cdb2b74f30175066bc7f77c3010faffea372a0e44208ea")
