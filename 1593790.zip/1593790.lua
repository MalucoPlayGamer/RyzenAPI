-- Lua provided by RyzenAPI
-- Game: addappid(1593790)

-- MAIN APPLICATION
addappid(1593790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593791, 1, "bc7bd7e50a037e1030b94c08d21bb12e518013bfcb969a31f139c50554297c8c")
