-- Lua provided by RyzenAPI
-- Game: Computer Repair Shop

-- MAIN APPLICATION
addappid(2479290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479291, 1, "095a82061c01fc7fa9bab9893c4fcfbd713c17efc79f16dbfee254c0bb1f9bcd")

