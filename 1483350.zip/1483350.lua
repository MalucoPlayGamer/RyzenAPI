-- Lua provided by RyzenAPI
-- Game: addappid(1483350)

-- MAIN APPLICATION
addappid(1483350)
addappid(1483351)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483352,0,"d7dd41c53c8f0bbc655157f7d65d04efcec8578b4aeb81e2f9c3e055138c2153")
