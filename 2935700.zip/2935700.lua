-- Lua provided by RyzenAPI
-- Game: addappid(2935700)

-- MAIN APPLICATION
addappid(2935700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935701, 1, "5dbd7021e3687dd34f292f0b229999b7d48b49d4de647f2a143e6464acc2075f")
