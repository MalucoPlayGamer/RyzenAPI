-- Lua provided by SkyAPI 
-- Game: Cowgirl's Café
addappid(2935700)
addappid(2935701, 1, "5dbd7021e3687dd34f292f0b229999b7d48b49d4de647f2a143e6464acc2075f")
