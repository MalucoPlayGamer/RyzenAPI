-- Lua provided by SkyAPI 
-- Game: AppID 3498260
addappid(3498260)
addappid(3498261, 1, "611872f5f9e60d9582428082e2db13e4615578f21bfb43b350dd3b0e800dce28")
