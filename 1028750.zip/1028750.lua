-- Lua provided by RyzenAPI
-- Game: Ultimate Logic Puzzle Collection

-- MAIN APPLICATION
addappid(1028750)
