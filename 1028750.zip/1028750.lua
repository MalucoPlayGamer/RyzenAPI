-- Lua provided by RyzenAPI
-- Game: Ultimate Logic Puzzle Collection

-- MAIN APPLICATION
addappid(1028750)
addappid(1030400)
addappid(1030401)
addappid(1030402)

