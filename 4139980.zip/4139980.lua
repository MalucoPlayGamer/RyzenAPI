-- Generated with Luie @ https://lua.tools/
-- 4139980 - Magical Hellhound Lust
-- Generated 2026-08-12 20:19:57 UTC
-- # Depots (Total/DLC/Shared): 3/1/0

-- Main AppID
addappid(4139980)

-- Main Depots
addappid(4139981, 1, "366af75cfe9e0caaf359c7cbd933b78b8ad2cc9ce0770a8487e6098463f2b39b") -- (windows)
setManifestid(4139981, "3349824311174542097", 276438654)
addappid(4139982, 1, "e3d09c88a06966eebdc9b22ddd3c2f9c762e934b847e615111e273ee5378b4df") -- (linux)
setManifestid(4139982, "4676171374558563529", 279837271)

-- DLC's (with depot keys)
-- Magical Hellhound Lust: In Heat edition (AppID: 4565310)
addappid(4565310)
addappid(4565310, 1, "04417c31b541150aa9c65cc4429091082401769d208a3aeed0b7af8f92ce3ded")
setManifestid(4565310, "536474785677328532", 467105721)
