-- 4139980's Lua and Manifest Created by Hubcap Manifest
-- Magical Hellhound Lust
-- Created: August 01, 2026 at 00:00:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(4139980) -- Magical Hellhound Lust
-- MAIN APP DEPOTS
addappid(4139981, 1, "366af75cfe9e0caaf359c7cbd933b78b8ad2cc9ce0770a8487e6098463f2b39b") -- Depot 4139981
setManifestid(4139981, "4793079345264105998", 276426198)
addappid(4139982, 1, "e3d09c88a06966eebdc9b22ddd3c2f9c762e934b847e615111e273ee5378b4df") -- Depot 4139982
setManifestid(4139982, "2843886080287176682", 279824943)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Magical Hellhound Lust In Heat edition (AppID: 4565310) - missing depot keys
-- addappid(4565310)