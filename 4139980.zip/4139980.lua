-- Lua provided by RyzenAPI
-- Game: Magical Hellhound Lust

-- MAIN APPLICATION
addappid(4139980)
addappid(4565310)

-- MAIN APP DEPOTS / PACKAGES
addappid(4139981, 1, "366af75cfe9e0caaf359c7cbd933b78b8ad2cc9ce0770a8487e6098463f2b39b") -- (windows)
addappid(4139982, 1, "e3d09c88a06966eebdc9b22ddd3c2f9c762e934b847e615111e273ee5378b4df") -- (linux)
addappid(4565310, 1, "04417c31b541150aa9c65cc4429091082401769d208a3aeed0b7af8f92ce3ded")

