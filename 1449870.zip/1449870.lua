-- Lua provided by RyzenAPI
-- Game: addappid(1449870)

-- MAIN APPLICATION
addappid(1449870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449871, 1, "1607e2c50b494f8145cf89e0586739f7cb76439485d658fb5f32e549cced9ffa")
