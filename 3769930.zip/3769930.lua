-- Lua provided by RyzenAPI
-- Game: 3769930

-- MAIN APPLICATION
addappid(3769930)
-- Game: addappid(3769930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3769931, 1, "7c7c99c7a112ad1106cf2bc3a5ff042d4d562cfbe75f481d61ef70be75cddbfd")
