-- Lua provided by RyzenAPI
-- Game: addappid(1309440)

-- MAIN APPLICATION
addappid(1309440)
addappid(1376770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309441, 1, "bcbec7c6d7bc490c58af242d3ebe1e00d9c9869cf82266868e3ed7044069fd7c")
