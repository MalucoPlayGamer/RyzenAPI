-- Lua provided by RyzenAPI 
-- Game: Sweet House Love
addappid(1309440)
addappid(1309441, 1, "bcbec7c6d7bc490c58af242d3ebe1e00d9c9869cf82266868e3ed7044069fd7c")
addappid(1376770)
