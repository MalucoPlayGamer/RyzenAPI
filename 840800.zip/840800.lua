-- Lua provided by SkyAPI 
-- Game: AppID 840800
addappid(840800)
addappid(840801, 1, "3c90b799f0f5a5fa371138ed6fe7bb1e565d6d156a567ed5ec61e958eb3ce8ee")
