-- Lua provided by RyzenAPI
-- Game: The Day Before You Gone

-- MAIN APPLICATION
addappid(2234690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234691, 1, "7ef239e0f593955f217f9668bfce506c819222d1f866c2d10a5140b317a5aebf")
