-- Lua provided by RyzenAPI
-- Game: addappid(1592640)

-- MAIN APPLICATION
addappid(1592640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592641, 1, "de4fb7467e4a57f7f3836b8050b10cf6eabeb0261e408de45492608e66306df5")
