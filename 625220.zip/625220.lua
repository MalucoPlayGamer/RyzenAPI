-- Lua provided by SkyAPI 
-- Game: AppID 625220
addappid(625220)
addappid(625221, 1, "52f23a7ee8290b5e7544211836cc06d8d7b049517a09a984e909876842580414")
