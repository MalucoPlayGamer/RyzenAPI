-- Lua provided by RyzenAPI
-- Game: Building Blocks / Master Builder of Egypt

-- MAIN APPLICATION
addappid(625220)

-- MAIN APP DEPOTS / PACKAGES
addappid(625221, 1, "52f23a7ee8290b5e7544211836cc06d8d7b049517a09a984e909876842580414")
