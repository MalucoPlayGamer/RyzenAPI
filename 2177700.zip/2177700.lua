-- Lua provided by RyzenAPI
-- Game: Game: Missing Pictures : Abel Ferrara

-- MAIN APPLICATION
addappid(2177700)
-- Game: addappid(2177700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177701, 1, "1f466cca4ac7a7b9c0089e628ad7225fac108076054ff2f71c061e6bb626f9f0")
