-- Lua provided by SkyAPI 
-- Game: SPACE DANCE
addappid(1683580)
addappid(1683581, 1, "2513c11012363d56ded1f9da26b725589c8ee355ce9e487a6efff98649681303")
