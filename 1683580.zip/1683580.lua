-- Lua provided by RyzenAPI
-- Game: Game: SPACE DANCE

-- MAIN APPLICATION
addappid(1683580)
-- Game: addappid(1683580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683581, 1, "2513c11012363d56ded1f9da26b725589c8ee355ce9e487a6efff98649681303")
