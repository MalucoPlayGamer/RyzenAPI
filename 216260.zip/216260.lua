-- Lua provided by RyzenAPI
-- Game: Don Bradman Cricket 14

-- MAIN APPLICATION
addappid(216260)
addappid(228983)
addappid(228984)
addappid(228990)
-- Game: addappid(216260)

-- MAIN APP DEPOTS / PACKAGES
addappid(216261, 1, "7afc06c18d29b2796fd79333c6df86ce919c2b44a8d1da57aa9fb437446e87fa")
