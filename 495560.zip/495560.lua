-- Lua provided by RyzenAPI
-- Game: 495560

-- MAIN APPLICATION
addappid(495560)
-- Game: addappid(495560)

-- MAIN APP DEPOTS / PACKAGES
addappid(495561, 1, "6a86db5e15e3c3a3d84658f5944d3c0a324b410e0a3a86cf447db4b0b9731d67")
