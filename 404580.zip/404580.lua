-- Lua provided by RyzenAPI
-- Game: AppID 404580

-- MAIN APPLICATION
addappid(404580)

-- MAIN APP DEPOTS / PACKAGES
addappid(404581, 1, "9e229251aef676f216ecd8d789b42c14c3c226f173cb850705d6324d6e76141a")
addappid(404582, 1, "1fb523efff2793487fddcabb2616a3c0c867c1cf808a46bde93db968c7928040")
addappid(404583, 1, "39ec4ff543594637052314c4e48f90210d92e9260d090ebb80a95d5ebf50f00a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
