-- Lua provided by RyzenAPI
-- Game: addappid(1720540)

-- MAIN APPLICATION
addappid(1720540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720542,0,"7ba39238d1d2e6c3969e316dd612e3d3d8aeea81437ad6124fe63f7ae6fd420e")
