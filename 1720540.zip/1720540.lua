-- Lua provided by RyzenAPI
-- Game: Unlock Kimono Cuties

-- MAIN APPLICATION
addappid(1720540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1720542,0,"7ba39238d1d2e6c3969e316dd612e3d3d8aeea81437ad6124fe63f7ae6fd420e")

