-- Lua provided by RyzenAPI
-- Game: Gallery Manager

-- MAIN APPLICATION
addappid(2302240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302241, 1, "ad07a552f94fa838910af0f3a61e2a13a8a465bfd78fbd850f4dbfc839a40cb8")

