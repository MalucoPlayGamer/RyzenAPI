-- Lua provided by RyzenAPI
-- Game: AppID 2264080

-- MAIN APPLICATION
addappid(2264080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264081, 1, "3718930f7a0ff242be4e0bd38a93df6e3b815b7eb0ffeca2ed04f1282ff42cbc")
