-- Lua provided by RyzenAPI
-- Game: Caprice: Domina Noctis

-- MAIN APPLICATION
addappid(3473960)
-- Game: addappid(3473960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473961, 1, "b70107bbd7074c2eff1b514c72c32520274c72e7e27557405fa243b2471e5363")
