-- Lua provided by RyzenAPI
-- Game: Snakes - N - Ladders : Origins - Episode 1

-- MAIN APPLICATION
addappid(552940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552941, 1, "c4b31c65a3d85c3c6185fa53e6587929220f5009952c270c8549cdf71fa2d1af")

