-- Lua provided by RyzenAPI
-- Game: Snakes - N - Ladders : Origins - Episode 1

-- MAIN APPLICATION
addappid(552940)

-- MAIN APP DEPOTS / PACKAGES
addappid(552941, 1, "c4b31c65a3d85c3c6185fa53e6587929220f5009952c270c8549cdf71fa2d1af")

