-- Lua provided by RyzenAPI
-- Game: addappid(3000120)

-- MAIN APPLICATION
addappid(3000120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000121, 1, "1067bd1dd9fb252ee43bbd3e52ec5310ddd58d06c064999c99ff960d37ca5d55")
