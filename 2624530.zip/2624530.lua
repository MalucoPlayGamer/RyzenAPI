-- Lua provided by RyzenAPI
-- Game: Escape Simulator VR Demo

-- MAIN APPLICATION
addappid(2624530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624531, 1, "aa458a928e34e2133c82b568fce48ba0ad8425b2d062fdbeadba08cb65420036")

