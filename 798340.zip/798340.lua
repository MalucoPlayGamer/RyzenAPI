-- Lua provided by RyzenAPI
-- Game: AppID 798340

-- MAIN APPLICATION
addappid(798340)
-- Game: addappid(798340)

-- MAIN APP DEPOTS / PACKAGES
addappid(798341, 1, "8182f424b074ddfd03ddc73894549d0947dd33b190d4d73cb5a63ac4d3048d36")
