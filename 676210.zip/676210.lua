-- Lua provided by RyzenAPI
-- Game: AppID 676210

-- MAIN APPLICATION
addappid(676210)

-- MAIN APP DEPOTS / PACKAGES
addappid(676211, 1, "85441d67953e320b89a902cf719f9016fe5548c77496992eb3d63318f65f3e40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
