-- Lua provided by RyzenAPI
-- Game: Tower Unite

-- MAIN APPLICATION
addappid(394690)

-- MAIN APP DEPOTS / PACKAGES
addappid(394691, 1, "77565668760b81bec885715428a57f31c3f5e1a131ddcb8c105a83fec6401d97")
addappid(394692, 1, "be1149768a298865cf712fe8c1bb9ca533b6a528f7fb6c7fca4a3bd92b835223")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2792910)
addappid(3490630)
