-- Lua provided by RyzenAPI 
-- Game: Tower Unite
addappid(394690)
addappid(394691, 1, "77565668760b81bec885715428a57f31c3f5e1a131ddcb8c105a83fec6401d97")
addappid(394692, 1, "be1149768a298865cf712fe8c1bb9ca533b6a528f7fb6c7fca4a3bd92b835223")
