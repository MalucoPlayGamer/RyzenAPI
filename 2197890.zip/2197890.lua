-- Lua provided by RyzenAPI
-- Game: Paranormal Cleanup

-- MAIN APPLICATION
addappid(2197890)
-- Game: addappid(2197890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197891, 1, "c4edc51ed5989640f604dab4ab2066669ea1ad25684d39142e6df692b201b729")
