-- Lua provided by RyzenAPI
-- Game: MEs

-- MAIN APPLICATION
addappid(2361710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2361711, 1, "85fa534b2e9bfc6442d9021dd09378190c9f66f4f7065f83c24f3f2b54b2ce38")
addappid(2361712, 1, "c4c575b0f98cf3f7a2107a47bc0f2fed34b35068f808f1aa425ffe00a3bd937d")

