-- Lua provided by RyzenAPI
-- Game: HEROES TRIALS

-- MAIN APPLICATION
addappid(854670)

-- MAIN APP DEPOTS / PACKAGES
addappid(854671, 1, "b79d6cea70e4849cf88e4e27edb3e80db51f4ebd7ace1329c50a8fd206990476")

