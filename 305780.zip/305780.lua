-- Lua provided by RyzenAPI
-- Game: Echo of the Wilds

-- MAIN APPLICATION
addappid(305780)

-- MAIN APP DEPOTS / PACKAGES
addappid(305781, 1, "4918f85f034fbfe5fc8b3505a64141b4c2b561639f30f021d7ea19edc2d0bdad")
