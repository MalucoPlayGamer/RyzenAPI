-- Lua provided by RyzenAPI
-- Game: Dinodrifters

-- MAIN APPLICATION
addappid(1179190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179191, 1, "6c05fde67cb8db300f5dc2a68eee8be3bd45e7ee6191f29435102d5015dcb6ac")

