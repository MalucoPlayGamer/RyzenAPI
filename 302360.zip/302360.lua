-- Lua provided by RyzenAPI
-- Game: Game: Tex Murphy: The Pandora Directive

-- MAIN APPLICATION
addappid(302360)
-- Game: addappid(302360)

-- MAIN APP DEPOTS / PACKAGES
addappid(302361, 1, "2f55b027eab980cb80a22389041d5c1a309f41879ad30645e41b18279330d03c")
addappid(302362, 1, "36de0f2b4b920c23ba6e178639bb9aa1a12d4731da30cb1f112dc30b05fdb4cc")
addappid(302363, 1, "e47b26f0bee968f4eb9310238879138ccb87b7fbaa4647193eb1755d321e7639")
addappid(302364, 1, "d7d8343c0536283d817b32728d03eb9ee45e3237f9aa87a77788625bdffb42f8")
