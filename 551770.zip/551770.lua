-- Lua provided by RyzenAPI
-- Game: AppID 551770

-- MAIN APPLICATION
addappid(551770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(551771, 1, "70030706a7eca3ac1971b1e75711a7c7987601e4a8f0feb4fa415d4f86d7e478")

