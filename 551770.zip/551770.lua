-- Lua provided by RyzenAPI
-- Game: Game: AppID 551770

-- MAIN APPLICATION
addappid(551770)
-- Game: addappid(551770)

-- MAIN APP DEPOTS / PACKAGES
addappid(551771, 1, "70030706a7eca3ac1971b1e75711a7c7987601e4a8f0feb4fa415d4f86d7e478")
