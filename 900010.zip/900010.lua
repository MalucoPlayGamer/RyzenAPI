-- Lua provided by RyzenAPI
-- Game: Meeple Station

-- MAIN APPLICATION
addappid(900010)

-- MAIN APP DEPOTS / PACKAGES
addappid(900011, 1, "98e39b9c86d2f391b02f38b311f05fd13cb5d4d79401fc4ecd482c429ded53ec")
addappid(900012, 1, "d84d466068ee270945302331110d54abc4ca7b632a5f56e548f99104783fdce3")
addappid(900013, 1, "08fa2d374c2bc5ccc1e892dece2a28c61e550787c86f99d5ba7ac05ab2b86ff8")

