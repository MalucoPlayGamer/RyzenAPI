-- Lua provided by RyzenAPI
-- Game: Final Approach: Pilot Edition

-- MAIN APPLICATION
addappid(481420)

-- MAIN APP DEPOTS / PACKAGES
addappid(481421, 1, "2e04686e6b0e42bf3c46a32b0319e58376ec6d52722a453ae5c7491ef8817cc9")
