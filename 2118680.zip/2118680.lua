-- Lua provided by RyzenAPI
-- Game: Game: Kingdom of Lust

-- MAIN APPLICATION
addappid(2118680)
-- Game: addappid(2118680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118681, 1, "50720a2eecd17627680d712039dff7b97852e8442319725c727137012c1c4151")
