-- Lua provided by RyzenAPI
-- Game: Astrumis - Survive Together Friend's Pass

-- MAIN APPLICATION
addappid(3178840)
-- Game: addappid(3178840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3178841, 1, "2fe42266dc5954a1d7787141d2df64cf042ba9421d943c56062852518a528cee")
