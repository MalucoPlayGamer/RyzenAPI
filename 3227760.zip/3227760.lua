-- Lua provided by RyzenAPI
-- Game: Game: Paper Bride 6 Nightmare

-- MAIN APPLICATION
addappid(3227760)
-- Game: addappid(3227760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227761, 1, "aea5ec3b5d98a199b1648d8e8ecf86e1c81701ddca706e7d0fc97f8415a6f46f")
addappid(3227762, 1, "2552bf98b66adcedb6153e4d4294ee95bb124281a667843fbc66f5397bb1ec3d")
addappid(3227763, 1, "fcd90f845c8f9207cc7a6dff64b174c3d1c987eeccf67ff4d83d18bfbaaa1bf0")
addappid(3283000, 0, "7067bd44fff2bb3a55e9223dabc1d1a00a6336ec747fb3859a8f5d27a0693fc6")
addappid(3284820, 0, "f56b357bf5eca79547a270eb8b527e97905dd22aa14a5c03ea293eb545bcff90")
