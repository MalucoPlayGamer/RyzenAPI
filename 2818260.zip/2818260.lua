-- Lua provided by RyzenAPI
-- Game: Game: Vigor

-- MAIN APPLICATION
addappid(2818260)
-- Game: addappid(2818260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818261, 1, "cc818e478a8aa275de89d956c189f975e5395fd16342854e14fcde177fb4ee1f")
