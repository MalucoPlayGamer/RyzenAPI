-- Lua provided by RyzenAPI
-- Game: 4853960

-- 4853960's Lua and Manifest Created by Hubcap Manifest
-- Thirteen: Risk & Rogue
-- Created: July 07, 2026 at 23:29:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1

-- MAIN APPLICATION
addappid(4853960) -- Thirteen: Risk & Rogue
-- MAIN APP DEPOTS
addappid(4853961, 1, "957d0d7552a2a910979df1201c9d04d6e10e821ca87a191f9c01c88c9723049d") -- Depot 4853961
setManifestid(4853961, "5308215046858826485", 19519700)