-- Lua provided by RyzenAPI
-- Game: 1454500

-- MAIN APPLICATION
addappid(1454500)
-- Game: addappid(1454500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454501, 1, "82b0b5700c768cf8961108f4b89e571cf548f58397b5a03c52cce69f7e51c3bb")
