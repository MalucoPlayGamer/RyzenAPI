-- Lua provided by RyzenAPI
-- Game: 1383550

-- MAIN APPLICATION
addappid(1383550)
-- Game: addappid(1383550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383551, 1, "eeb1805a1eccba775b1927e27ae4a50173836c226a1366da197713c18833ac50")
