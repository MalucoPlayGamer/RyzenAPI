-- Lua provided by RyzenAPI
-- Game: Lost: Find

-- MAIN APPLICATION
addappid(1801650)
-- Game: addappid(1801650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801651, 1, "79683aeafed869ddd22a8ad50c3c89f7de615cf55184f9e75cee3113b8415dc9")
addappid(1811650, 0, "fac8466a0702947d894e7a522e2c8adecac1ad30645b98b4dc40c096221cb0d5")
