-- Lua provided by RyzenAPI
-- Game: 2414690

-- MAIN APPLICATION
addappid(2414690)
-- Game: addappid(2414690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414691, 1, "1e8a9240c368e2f0bec3178e566dfaa8c51de97df96aa9f716961b71504cab45")
