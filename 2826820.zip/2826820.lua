-- Lua provided by RyzenAPI
-- Game: Game: Turbo Play

-- MAIN APPLICATION
addappid(2826820)
-- Game: addappid(2826820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826821, 1, "ff181746799dc92be6284d9496fc765d4901ecca2b2ae62d5c6b1a4a3eb7ae1c")
