-- Lua provided by RyzenAPI
-- Game: Game: AppID 3245820

-- MAIN APPLICATION
addappid(3245820)
-- Game: addappid(3245820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245821, 1, "b4c3eb21c15268ab8f54f1d97d6f6117d1c677a87b493c466e07b61942164012")
