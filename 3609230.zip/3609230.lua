-- Lua provided by RyzenAPI
-- Game: ZDSimulator - ED9m Electric Train

-- MAIN APPLICATION
addappid(3609230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609230,0,"cf2067651a8e9a7df64f900c679eac97f1406605d82adc27484628289d070dd0")

