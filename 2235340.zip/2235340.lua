-- Lua provided by SkyAPI 
-- Game: Urban Flow
addappid(2235340)
addappid(2235341, 1, "ac24c1ef265e0eb85156dae750b25b2d4fe9f0105a8eeb7629716c355d91be55")
