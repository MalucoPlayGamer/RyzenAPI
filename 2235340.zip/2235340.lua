-- Lua provided by RyzenAPI
-- Game: Urban Flow

-- MAIN APPLICATION
addappid(2235340)
-- Game: addappid(2235340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235341, 1, "ac24c1ef265e0eb85156dae750b25b2d4fe9f0105a8eeb7629716c355d91be55")
