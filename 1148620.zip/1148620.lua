-- Lua provided by SkyAPI 
-- Game: AppID 1148620
addappid(1148620)
addappid(1148621, 1, "0c692468930db4e8fd6b589d0896800f7c1f001c204bcc891a604fd748047601")
