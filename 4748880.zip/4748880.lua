-- Lua provided by RyzenAPI
-- Game: Hunt Asylum Together

-- MAIN APPLICATION
addappid(4748880)

-- MAIN APP DEPOTS / PACKAGES
addappid(4748881,0,"52093240622d19fb6e387def48084c2c761aa9b047a5d234f377593f457f61a9")

