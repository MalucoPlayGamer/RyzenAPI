-- Lua provided by RyzenAPI
-- Game: 610680

-- MAIN APPLICATION
addappid(610680)
-- Game: addappid(610680)

-- MAIN APP DEPOTS / PACKAGES
addappid(610681, 1, "737ff3ed8468b93bf143ea798f2d0cee1141605e0acef7a4373f94e5d4228167")
