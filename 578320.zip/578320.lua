-- Lua provided by RyzenAPI
-- Game: Dark Parables: Jack and the Sky Kingdom Collector's Edition

-- MAIN APPLICATION
addappid(578320)

-- MAIN APP DEPOTS / PACKAGES
addappid(578321, 1, "8e0f1df6dfeddf857a476105dd2511a2bae1325c621eb09fdc9774715a1dde89")

