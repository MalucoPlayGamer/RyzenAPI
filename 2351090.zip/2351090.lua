-- Lua provided by SkyAPI 
-- Game: Sex Standing
addappid(2351090)
addappid(2351091, 1, "ea9e67ab07678268a39ab7ed2f369f0115a08645ff4db1d19cfdfb7524dc8832")
