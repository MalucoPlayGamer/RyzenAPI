-- Lua provided by RyzenAPI
-- Game: Game: Sex Standing

-- MAIN APPLICATION
addappid(2351090)
-- Game: addappid(2351090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351091, 1, "ea9e67ab07678268a39ab7ed2f369f0115a08645ff4db1d19cfdfb7524dc8832")
