-- Lua provided by RyzenAPI
-- Game: Strike Buster Prototype

-- MAIN APPLICATION
addappid(1399590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399591, 1, "191474eab6223d483920d39cc11646bb8800dacdf5833ad67f336dd077fb7af9")

