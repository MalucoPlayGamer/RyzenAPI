-- Lua provided by RyzenAPI
-- Game: addappid(1414470)

-- MAIN APPLICATION
addappid(1414470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414471, 1, "24423aa80c77a4c51272e26c57faddff81c7529b3b88e026034f189a28d3a4fa")
