-- Lua provided by RyzenAPI 
-- Game: Yeomna : The Legend of Dongbaek
addappid(1414470)
addappid(1414471, 1, "24423aa80c77a4c51272e26c57faddff81c7529b3b88e026034f189a28d3a4fa")
