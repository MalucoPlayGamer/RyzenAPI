-- Lua provided by SkyAPI 
-- Game: AppID 477270
addappid(477270)
addappid(477271, 1, "931daca36b6dd0a63fbe7bed813763bde09c70e33cedb9353f63793b8b98bcb9")
