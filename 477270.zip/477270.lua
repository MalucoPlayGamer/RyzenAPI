-- Lua provided by RyzenAPI
-- Game: AppID 477270

-- MAIN APPLICATION
addappid(477270)
-- Game: addappid(477270)

-- MAIN APP DEPOTS / PACKAGES
addappid(477271, 1, "931daca36b6dd0a63fbe7bed813763bde09c70e33cedb9353f63793b8b98bcb9")
