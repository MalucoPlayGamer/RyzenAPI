-- Lua provided by RyzenAPI
-- Game: Sex With Friends

-- MAIN APPLICATION
addappid(3407070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3407071, 1, "624ef68205bc8a50f5b7008d4478abb7a56723ece293adc96f4760e6a59915ce")

