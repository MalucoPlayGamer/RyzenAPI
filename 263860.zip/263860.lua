-- Lua provided by RyzenAPI
-- Game: AppID 263860

-- MAIN APPLICATION
addappid(263860)

-- MAIN APP DEPOTS / PACKAGES
addappid(263861, 1, "b67910baba0825aa8f2ca54a7663b2bea4ca53ca9c427333b66e6657fe89607c")
addappid(263862, 1, "dc781305679353870f3ce02ceee73aa5618bcec1ceb2acacdccc42831535e990")
addappid(263865, 1, "703ca1671bda30294d0ee795771aaf483b12fcccee3e2b46fa8a42b45eae0b2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
