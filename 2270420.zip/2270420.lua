-- Lua provided by RyzenAPI
-- Game: Speedway Ringer

-- MAIN APPLICATION
addappid(2270420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270421, 1, "df0d690ce659c107bf81ec23f46ffef63a48793e975ff4935b5c5856930df87f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
