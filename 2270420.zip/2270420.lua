-- Lua provided by RyzenAPI
-- Game: Speedway Ringer

-- MAIN APPLICATION
addappid(2270420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270421, 1, "df0d690ce659c107bf81ec23f46ffef63a48793e975ff4935b5c5856930df87f")

