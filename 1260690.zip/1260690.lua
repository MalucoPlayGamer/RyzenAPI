-- Lua provided by RyzenAPI
-- Game: addappid(1260690)

-- MAIN APPLICATION
addappid(1260690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260691, 1, "4fe6556cd3738c6057bde6122d2ee41bbcbd26740da49e81e3222cec0a293119")
