-- Lua provided by RyzenAPI
-- Game: Game: Fruit Tower Defense

-- MAIN APPLICATION
addappid(911760)
-- Game: addappid(911760)

-- MAIN APP DEPOTS / PACKAGES
addappid(911761, 1, "4d97a8f292d413110536ea11e9b24461931c357188e4b6e517d3616e8177082b")
addappid(911762, 1, "1f1c9003b1a773f54efd222d123af27d46135c7b6bc2a18c55b0dc2bfaf0c756")
