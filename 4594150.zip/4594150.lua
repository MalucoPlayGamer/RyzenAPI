-- Lua provided by RyzenAPI
-- Game: Sir, We Have an Orc Problem

-- MAIN APPLICATION
addappid(4594150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4594151,0,"c74b45ac41a8b5814d4d694ded55996d3c4f6b501588b45aad45423a14d9310b")
addappid(4594152,0,"fff07e1f430224e7b5d87d982ce52757ab3709c786566131d71e6a0daa915e0e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4981840)
