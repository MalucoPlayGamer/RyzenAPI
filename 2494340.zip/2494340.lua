-- Lua provided by RyzenAPI
-- Game: Tour de France 2024

-- MAIN APPLICATION
addappid(2494340)
addappid(2736670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494341, 1, "0d7367b6dedec0431cc9746b18af66de106c5d7d96eb2025350e8baca903f299")

