-- Lua provided by RyzenAPI
-- Game: Rift Wizard

-- MAIN APPLICATION
addappid(1271280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1271281, 1, "8bc0e554ad3bbd8c96a82187e47b17d283d3ddeeb9b3e5728ef45b08bbd40117")

