-- Lua provided by SkyAPI 
-- Game: Rift Wizard
addappid(1271280)
addappid(1271281, 1, "8bc0e554ad3bbd8c96a82187e47b17d283d3ddeeb9b3e5728ef45b08bbd40117")
