-- Lua provided by RyzenAPI
-- Game: Rift Wizard

-- MAIN APPLICATION
addappid(1271280)
-- Game: addappid(1271280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271281, 1, "8bc0e554ad3bbd8c96a82187e47b17d283d3ddeeb9b3e5728ef45b08bbd40117")
