-- Lua provided by RyzenAPI
-- Game: Ale & Tale Tavern: First Pints

-- MAIN APPLICATION
addappid(2870840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870841, 1, "b541621a1e073286f31a54f23f74be7f7281e8f9a84940a832d8e18418310166")
addappid(2870842, 1, "250367c98a75dffb4d9766313017e7845cb950bb387ed583d4c7dbb17df03148")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
