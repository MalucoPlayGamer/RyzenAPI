-- Lua provided by RyzenAPI
-- Game: Created: August 20, 2026 at 13:23:32 EDT

-- MAIN APPLICATION
addappid(4376090) -- 被击垮而堕落的强气人妻

-- MAIN APP DEPOTS / PACKAGES
addappid(4376091, 1, "eb78dc2fa1b550c02caeeea8f4922869f4c0082b1411ab15f022325b84f12d28") -- Depot 4376091

