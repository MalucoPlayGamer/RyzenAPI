-- 4376090's Lua and Manifest Created by Hubcap Manifest
-- 被击垮而堕落的强气人妻
-- Created: August 20, 2026 at 13:23:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4376090) -- 被击垮而堕落的强气人妻
-- MAIN APP DEPOTS
addappid(4376091, 1, "eb78dc2fa1b550c02caeeea8f4922869f4c0082b1411ab15f022325b84f12d28") -- Depot 4376091
setManifestid(4376091, "4791828129097732264", 306199737)