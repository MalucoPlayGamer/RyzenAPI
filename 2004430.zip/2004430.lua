-- Lua provided by RyzenAPI
-- Game: Game: The Search for Fran 2

-- MAIN APPLICATION
addappid(2004430)
-- Game: addappid(2004430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004431, 1, "6da45bf288cf5f1f3589fed30dd0464b3c96abfd04203be72ced9adadba20d00")
