-- Lua provided by RyzenAPI
-- Game: The Search for Fran 2

-- MAIN APPLICATION
addappid(2004430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2004431, 1, "6da45bf288cf5f1f3589fed30dd0464b3c96abfd04203be72ced9adadba20d00")

