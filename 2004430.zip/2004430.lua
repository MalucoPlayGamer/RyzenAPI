-- Lua provided by SkyAPI 
-- Game: The Search for Fran 2
addappid(2004430)
addappid(2004431, 1, "6da45bf288cf5f1f3589fed30dd0464b3c96abfd04203be72ced9adadba20d00")
