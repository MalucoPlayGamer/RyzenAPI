-- Lua provided by RyzenAPI
-- Game: Game: AppID 1361540

-- MAIN APPLICATION
addappid(1361540)
-- Game: addappid(1361540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361541, 1, "be8846ef3a456615243d0162bd769621b6b3baf628231d1ef727dd7599727e89")
