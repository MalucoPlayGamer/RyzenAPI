-- Lua provided by RyzenAPI 
-- Game: AppID 1361540
addappid(1361540)
addappid(1361541, 1, "be8846ef3a456615243d0162bd769621b6b3baf628231d1ef727dd7599727e89")
