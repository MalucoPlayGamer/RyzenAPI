-- Lua provided by RyzenAPI
-- Game: Asian Truck Simulator

-- MAIN APPLICATION
addappid(2117080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117081, 1, "3b273388445d62f9c540e5b2500bc9cdc091a9115a0e1307e876227784b71e29")
