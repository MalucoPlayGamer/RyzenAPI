-- Lua provided by RyzenAPI
-- Game: AppID 854540

-- MAIN APPLICATION
addappid(854540)
addappid(884580)
addappid(884581)
addappid(884582)

-- MAIN APP DEPOTS / PACKAGES
addappid(854541, 1, "5025b4679142c6fe272f228b74d7e40864ab02e8d78a5b328e23f5aaa345a304")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
