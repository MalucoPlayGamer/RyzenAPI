-- Lua provided by RyzenAPI
-- Game: 854540

-- MAIN APPLICATION
addappid(854540)
addappid(884580)
addappid(884581)
addappid(884582)
-- Game: addappid(854540)

-- MAIN APP DEPOTS / PACKAGES
addappid(854541, 1, "5025b4679142c6fe272f228b74d7e40864ab02e8d78a5b328e23f5aaa345a304")
