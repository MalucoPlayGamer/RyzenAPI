-- Lua provided by RyzenAPI
-- Game: 2859140

-- MAIN APPLICATION
addappid(2859140)
-- Game: addappid(2859140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859141, 1, "e105aac407fe66b781435f27a1e32389f3af80b4302a6c1519ad99d21b08446e")
