-- Lua provided by RyzenAPI
-- Game: Created: October 01, 2025 at 13:11:22 EDT

-- MAIN APPLICATION
addappid(998940) -- 隐形守护者 The Invisible Guardian
addappid(1047770)

-- MAIN APP DEPOTS / PACKAGES
addappid(998941, 1, "65b852c8a0539417616a69e8449ad13c0812868d1f613795b0436c213d37ab3a") -- 隐形守护者 The Invisible Guardian 64bit
addappid(998942, 1, "cb8a0ef46706e08d433abde0e0f40de31ae5e00279d90e5aea9c4a7c137194c2") -- 隐形守护者 The Invisible Guardian 32bit
addappid(998943, 1, "de660b4835bce54f9c0953c17d126baba526a56ad18fb0528f0a9d78323d0553") -- 隐形守护者 The Invisible Guardian Mac
addappid(1012220) --  The Invisible Guardian - 6-10,
addappid(1047770, 1, "532b18379182f6a333c5ec4a4c44032a19adfcb5a05e7a59a36cab8da89b678c") --  The Invisible Guardian - OST - 隐形守护者 The Invisible Guardian - OST (1047770) 个 Depot

