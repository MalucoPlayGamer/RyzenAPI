-- 998940's Lua and Manifest Created by Hubcap Manifest
-- 隐形守护者 The Invisible Guardian
-- Created: October 01, 2025 at 13:11:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(998940) -- 隐形守护者 The Invisible Guardian
-- MAIN APP DEPOTS
addappid(998941, 1, "65b852c8a0539417616a69e8449ad13c0812868d1f613795b0436c213d37ab3a") -- 隐形守护者 The Invisible Guardian 64bit
setManifestid(998941, "2113401051174688844", 168545939)
addappid(998942, 1, "cb8a0ef46706e08d433abde0e0f40de31ae5e00279d90e5aea9c4a7c137194c2") -- 隐形守护者 The Invisible Guardian 32bit
setManifestid(998942, "2372345644132413495", 144190907)
addappid(998943, 1, "de660b4835bce54f9c0953c17d126baba526a56ad18fb0528f0a9d78323d0553") -- 隐形守护者 The Invisible Guardian Mac
setManifestid(998943, "2887341020092351712", 244064224)
-- DLCS WITH DEDICATED DEPOTS
--  The Invisible Guardian - OST (AppID: 1047770)
addappid(1047770)
addappid(1047770, 1, "532b18379182f6a333c5ec4a4c44032a19adfcb5a05e7a59a36cab8da89b678c") --  The Invisible Guardian - OST - 隐形守护者 The Invisible Guardian - OST (1047770) 个 Depot
setManifestid(1047770, "1909121831595233221", 964107599)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1012220) --  The Invisible Guardian - 6-10,