-- Lua provided by RyzenAPI
-- Game: 2218690

-- MAIN APPLICATION
addappid(2218690)
-- Game: addappid(2218690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218691, 1, "2d167273098375cc53fc16efa1ee1048d91799117cb6b9dfb1e73585fa33a5a6")
