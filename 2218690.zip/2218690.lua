-- Lua provided by RyzenAPI
-- Game: AppID 2218690

-- MAIN APPLICATION
addappid(2218690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218691, 1, "2d167273098375cc53fc16efa1ee1048d91799117cb6b9dfb1e73585fa33a5a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2312590)
addappid(2533200)
addappid(2533450)
addappid(2538660)
addappid(2541790)
addappid(2680710)
addappid(2684350)
addappid(2693520)
