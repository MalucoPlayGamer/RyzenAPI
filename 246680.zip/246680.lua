-- Lua provided by RyzenAPI
-- Game: Game: AppID 246680

-- MAIN APPLICATION
addappid(246680)
-- Game: addappid(246680)

-- MAIN APP DEPOTS / PACKAGES
addappid(246681, 1, "3aa9e63dd2d6bbb6991e1ec9a027938e2990073c79bc3b9fba9e726bd282936c")
addappid(246682, 1, "ccc5fb527295ae460125b2f620c84a5a45a520500db55e8d370425a7f3d4ba74")
addappid(246683, 1, "4d246e0edc1afd3dc4a3c131d7e6b91e7e4a2853100cf0ca2876048e7bf11e43")
