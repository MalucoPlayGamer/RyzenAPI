-- Lua provided by RyzenAPI
-- Game: Game: AppID 913590

-- MAIN APPLICATION
addappid(913590)
-- Game: addappid(913590)

-- MAIN APP DEPOTS / PACKAGES
addappid(913591, 1, "2d1ca999ddb3767a16f6cfc6be35813081d460060178a4de5a6db298bfe393f6")
