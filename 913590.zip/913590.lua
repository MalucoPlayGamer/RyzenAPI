-- Lua provided by RyzenAPI
-- Game: AppID 913590

-- MAIN APPLICATION
addappid(913590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(913591, 1, "2d1ca999ddb3767a16f6cfc6be35813081d460060178a4de5a6db298bfe393f6")

