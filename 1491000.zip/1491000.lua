-- Lua provided by RyzenAPI
-- Game: War Robots: Frontiers

-- MAIN APPLICATION
addappid(1491000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491005,0,"2be9488b3154af861533f4c4e8257f5ceaa80f32d7244bc091d10daa6927b51a")

