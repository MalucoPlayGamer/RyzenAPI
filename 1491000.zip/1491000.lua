-- Lua provided by RyzenAPI
-- Game: War Robots: Frontiers

-- MAIN APPLICATION
addappid(1491000)
addappid(2186150)
addappid(2186170)
addappid(2186180)
addappid(2186190)
addappid(3556520)
addappid(3556530)
addappid(3556540)
addappid(3556550)
addappid(3768870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491005,0,"2be9488b3154af861533f4c4e8257f5ceaa80f32d7244bc091d10daa6927b51a")

