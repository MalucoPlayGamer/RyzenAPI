-- Lua provided by RyzenAPI
-- Game: Let's Play! Oink Games

-- MAIN APPLICATION
addappid(1933490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933491, 1, "c9585fd63e83c035e240df83f62e282c4568b4770802932f7fceec83c4d632c8")
