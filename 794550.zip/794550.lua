-- Lua provided by RyzenAPI
-- Game: Grapple Force Rena

-- MAIN APPLICATION
addappid(794550)
addappid(794551)
addappid(794554)
addappid(794555)

-- MAIN APP DEPOTS / PACKAGES
addappid(794552,0,"f8d757dbf842f78ee5141ac7c2f034e9ee1fc6fc1d219b7dfed6be04bc5c844e")
addappid(794556,0,"57af957e098794f42ba34690bbc8b2e59597183e0732fae62dc81f6a4da2f883")

