-- Lua provided by RyzenAPI
-- Game: Endless Furry Killer Infinity

-- MAIN APPLICATION
addappid(1597170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597171, 1, "181f9624a549da480ab4b2c4baa0ddd03a24c7d31ce80e934cd7531a253c1a07")

