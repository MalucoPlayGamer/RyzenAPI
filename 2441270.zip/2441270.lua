-- Lua provided by RyzenAPI
-- Game: Kill The Crows

-- MAIN APPLICATION
addappid(2441270)
-- Game: addappid(2441270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441271, 1, "30030b0018f2e8952c734aed1819cd43acffb26c0b4eb27c344d6fdfa16686ae")
addappid(2441272, 1, "69027dcd90b2c714656caaf1d7949843699bcc2f714b2c337eb22ab38c8955c8")
addappid(2441273, 1, "ccbc0241ee281920c731c2a0d92adedd34ec6ff7ce0cbaaf9688de9e1135061f")
