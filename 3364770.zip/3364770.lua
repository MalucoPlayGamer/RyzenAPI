-- Lua provided by RyzenAPI
-- Game: Misty Judgment

-- MAIN APPLICATION
addappid(3364770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364771, 1, "b061675a65d705d308cee26aa86a742f9e8953a35ae2495bca9ca6196f7c7ef3")

