-- Lua provided by RyzenAPI
-- Game: Adam's Venture: Origins

-- MAIN APPLICATION
addappid(400360)

-- MAIN APP DEPOTS / PACKAGES
addappid(400361, 1, "0c86945ae6f397a4ebccbaa47d4b3554e4830d0292319114071228e776a80790")
addappid(455250, 0, "34746858c587b084f7cde9c57a66c6a72159dae065fab622f1c9d56027d14f67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
