-- Lua provided by RyzenAPI
-- Game: addappid(1035560)

-- MAIN APPLICATION
addappid(1035560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035561, 1, "c3e3de7fb0133459978503ac002be02473fc482845b20a26f5f63c5be06cb64f")
