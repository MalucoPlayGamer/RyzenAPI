-- Lua provided by RyzenAPI
-- Game: 黎明为歌 - Melody before the Dawn

-- MAIN APPLICATION
addappid(1875140)
addappid(1936060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875141, 1, "ef7512c445e8793ff32f216254249aad6bfd53d625000d676aad97d80a20bf7c")

