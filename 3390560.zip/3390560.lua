-- Lua provided by RyzenAPI
-- Game: Game: AppID 3390560

-- MAIN APPLICATION
addappid(3390560)
-- Game: addappid(3390560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3390561, 1, "a41ea0aab840681f5d9e254196fcebdd45f04af6a16dd5a939b9bddea718fb78")
