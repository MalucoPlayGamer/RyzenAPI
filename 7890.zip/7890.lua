-- Lua provided by RyzenAPI
-- Game: addappid(7890)

-- MAIN APPLICATION
addappid(7890)

-- MAIN APP DEPOTS / PACKAGES
addappid(7891, 1, "3aa2c8544fb40797813a1528a5183c3ee54b99a18fc8b3b65ddd2baaa60b0284")
