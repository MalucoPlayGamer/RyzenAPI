-- Lua provided by RyzenAPI
-- Game: Game: The Lost City Of Malathedra

-- MAIN APPLICATION
addappid(354690)
-- Game: addappid(354690)

-- MAIN APP DEPOTS / PACKAGES
addappid(354691, 1, "6e115ee6060a8f34cc0b3a8ab386a0cb99d04edb91549e6505dd3aa8feebf70b")
