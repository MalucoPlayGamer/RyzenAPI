-- Lua provided by RyzenAPI
-- Game: Rune Factory 3 Special - Swimsuit Mode

-- MAIN APPLICATION
addappid(2244790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244790,0,"aae1464271aa7b23177b1d45b222ed3819e40a66ef38554b6b715054d3999eba")

