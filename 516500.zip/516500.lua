-- Lua provided by RyzenAPI
-- Game: addappid(516500)

-- MAIN APPLICATION
addappid(516500)

-- MAIN APP DEPOTS / PACKAGES
addappid(516501, 1, "98c555cbca56ee2b5ba6ba318f44be8cd9074238ae4b65513239e0deb9d2b63f")
