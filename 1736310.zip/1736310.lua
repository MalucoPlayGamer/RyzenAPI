-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Jigsaw Puzzle 3

-- MAIN APPLICATION
addappid(1736310)
-- Game: addappid(1736310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736311, 1, "05025ca2707e1d9b93c2330dcd6201c1cfa90ae8bc3f6cc4ce7107bf24bb93aa")
addappid(1737930, 0, "bc4113ceb4c03b38305bfd8e7dbad292222057981ccbdbe6b3de7260f1bb34ba")
