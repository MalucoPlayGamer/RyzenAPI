-- Lua provided by RyzenAPI
-- Game: 595960

-- MAIN APPLICATION
addappid(595960)

-- MAIN APP DEPOTS / PACKAGES
addappid(595962,0,"a9773b482058a38e3025ad0aaba39cd5b40e39f5f134afd9fadb6e4d4338c9c1")
