-- Lua provided by RyzenAPI
-- Game: 398920

-- MAIN APPLICATION
addappid(398920)
-- Game: addappid(398920)

-- MAIN APP DEPOTS / PACKAGES
addappid(398921, 1, "379fd51adffff22a9dfc286c5f911ada76039fd11278c4de23fdcb478e2814e0")
