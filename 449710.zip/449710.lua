-- Lua provided by RyzenAPI
-- Game: addappid(449710)

-- MAIN APPLICATION
addappid(449710)

-- MAIN APP DEPOTS / PACKAGES
addappid(449711, 1, "90c0df3a9f04c92ec0f2e0554134eb5ae610ccd3c5c37cb928bd046765ba776d")
