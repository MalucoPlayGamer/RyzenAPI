-- Lua provided by RyzenAPI
-- Game: REDCON

-- MAIN APPLICATION
addappid(449710)

-- MAIN APP DEPOTS / PACKAGES
addappid(449711, 1, "90c0df3a9f04c92ec0f2e0554134eb5ae610ccd3c5c37cb928bd046765ba776d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
