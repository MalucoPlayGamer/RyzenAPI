-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(330710)
addappid(330711)
addappid(330712)
addappid(330713)
addappid(330715)

-- MAIN APP DEPOTS / PACKAGES
addappid(257516,0,"a383a8a0ea7ca2ab1c813417a6f41ba8d13922fb851083ae9e606a4850b171ca")
addappid(257517,0,"5c2c6a95629811ec26e49a6b5718bec55c93248beab888c2a3f0e43b177dca84")
addappid(257518,0,"fbce2f04093e29ade04937517ea00430c35e9b4dcf4a1258cb5594127d17c37b")

