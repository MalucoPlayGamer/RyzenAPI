-- Lua provided by RyzenAPI
-- Game: Deponia Demo

-- MAIN APPLICATION
addappid(217830)

-- MAIN APP DEPOTS / PACKAGES
addappid(217831, 1, "2c537fcac7c670fb841b72732ac5b61a3e98a3659807adb2a8f421c235d11995")
addappid(217832, 1, "297657f892bc2e878c2c2deaf2f091cb4db594ca78a6e80b2959f4e97b0a6022")
addappid(217834, 1, "09eb71f26bb3d5ec4dc48f90f9760922945ceef22306bb5ac9d533101a68bf5e")

