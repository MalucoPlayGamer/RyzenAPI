-- Lua provided by RyzenAPI
-- Game: addappid(1048871)

-- MAIN APPLICATION
addappid(1048871)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048871,0,"b19f825b81102d95de35829ee6460ab97531ab40d38744bfe7ee4455b20b98be")
