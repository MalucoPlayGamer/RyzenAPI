-- Lua provided by RyzenAPI
-- Game: PomoFarm

-- MAIN APPLICATION
addappid(2060480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060481, 1, "2ffa8d070c22bdf8e3b1ec3ed7f92208a6b3c4e51b5066b7f46a09b47bccafec")

