-- Lua provided by RyzenAPI
-- Game: Swordbreaker The Game

-- MAIN APPLICATION
addappid(411760)

-- MAIN APP DEPOTS / PACKAGES
addappid(411761, 1, "446a9c22f3fffcf373ffe38a80b92436e92e5d1255b54e0956b1bde151e45f9b")
addappid(411762, 1, "21c361d9cd33eb3a508af5ed3ecad0412724ba34f599143994617eb81018300d")
addappid(446890, 0, "e7db551311c5145b2d7408d2ee3884e40adae9afe50a4cedd66bf1ac39ae6c4b")

