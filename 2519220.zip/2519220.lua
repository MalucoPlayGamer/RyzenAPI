-- Lua provided by RyzenAPI
-- Game: God Within VR

-- MAIN APPLICATION
addappid(2519220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519221, 1, "931dbc50d815ca811ce79ee44a25e6fed856a345e82ee5f0dd2443bce3a50227")
