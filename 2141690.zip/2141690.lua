-- Lua provided by RyzenAPI
-- Game: Car Dealership Simulator

-- MAIN APPLICATION
addappid(2141690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141691, 1, "1587757928cd9adb80cc6d48e7a8010cf3a98862b1c097e78463ded371fe90cd")
