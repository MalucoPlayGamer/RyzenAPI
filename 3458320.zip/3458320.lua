-- Lua provided by RyzenAPI 
-- Game: Glow of Snowy Night
addappid(3458320)
addappid(3458321, 1, "278f15bbbb3ba2dca5e2eff0ad649225ecb85c66ec38935e95fbc3fcb2c3305a")
