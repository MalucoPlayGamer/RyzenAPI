-- Lua provided by RyzenAPI
-- Game: 1612420

-- MAIN APPLICATION
addappid(1612420)
-- Game: addappid(1612420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612421, 1, "94247ea5c273f90c20d1c1269b4a3591ef8b2bca05db931d4c5e42774cf2ab30")
