-- Lua provided by RyzenAPI
-- Game: Violett Remastered

-- MAIN APPLICATION
addappid(257830)

-- MAIN APP DEPOTS / PACKAGES
addappid(257831, 1, "b3bb099531b0086600b4e42e1645f2d58cbdcf103f4d62057dd26f5810a8b9b8")
addappid(257832, 1, "a9762e891f594f3997600f1339f922737006d805ee7f33589e4b0ae2360881e1")
addappid(257833, 1, "fa11f29412d87550a04b1cf946e1085b30b313c2350e7c37bebc4ce50b0f2f27")
addappid(257834, 1, "54549e6bbf66df499f558f7dc25d9764255e3de9291b2351c62b099f254e2231")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
