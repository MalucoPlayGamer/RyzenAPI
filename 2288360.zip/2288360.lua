-- Lua provided by RyzenAPI
-- Game: addappid(2288360)

-- MAIN APPLICATION
addappid(2288360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288361, 1, "0a56988332708a0dffd88f9af372eefe7517b41169f3ce6b32bcde55999d416f")
