-- Lua provided by RyzenAPI
-- Game: addappid(690670)

-- MAIN APPLICATION
addappid(690670)
addappid(748280)
addappid(749280)
addappid(749620)

-- MAIN APP DEPOTS / PACKAGES
addappid(690671, 1, "c94622f15122559a19895cb4b1420f746746593095d939f78e23217ec28646e8")
