-- Lua provided by RyzenAPI
-- Game: Game: NeverAwake

-- MAIN APPLICATION
addappid(1727180)
-- Game: addappid(1727180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727181, 1, "46cc59d6f296fa2e672a78e2a61e11e33c606bafd04ab26499b1ad56a9a36df6")
