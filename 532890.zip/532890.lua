-- Lua provided by RyzenAPI
-- Game: Civil War: 1862

-- MAIN APPLICATION
addappid(532890)

-- MAIN APP DEPOTS / PACKAGES
addappid(532891, 1, "6608e2c3125d06854fca56a702fe6105189474e8e8355741b3074afba3ce1e65")
addappid(532892, 1, "f6fe9819a711161612dd3872aa4503d678900302a6c63ed6735adb3ac50792ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
