-- Lua provided by RyzenAPI
-- Game: Game: Civil War: 1862

-- MAIN APPLICATION
addappid(532890)
-- Game: addappid(532890)

-- MAIN APP DEPOTS / PACKAGES
addappid(532891, 1, "6608e2c3125d06854fca56a702fe6105189474e8e8355741b3074afba3ce1e65")
addappid(532892, 1, "f6fe9819a711161612dd3872aa4503d678900302a6c63ed6735adb3ac50792ae")
