-- Lua provided by RyzenAPI
-- Game: Game: AppID 1092950

-- MAIN APPLICATION
addappid(1092950)
-- Game: addappid(1092950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092951, 1, "ebad66e48a94917a252d286a86b4a6cf95eb832ba1b5f847a0eb8d184f733bc4")
