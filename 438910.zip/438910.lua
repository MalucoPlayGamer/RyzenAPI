-- Lua provided by RyzenAPI
-- Game: Hack, Slash & Backstab

-- MAIN APPLICATION
addappid(438910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(438912,0,"315833b0c839406d065e23bce52a5d2a34443aa2925e9a01976565cd649239eb")
addappid(438915,0,"89860f542999f012721fc5cd6033a1fc49766f79fdaf943a2cbb326310c8486f")
addappid(458670,0,"09d4ea7786e22ed73cf24bb0725f468498cea5c63c3e41d8eb52a0b9ad757efc")

