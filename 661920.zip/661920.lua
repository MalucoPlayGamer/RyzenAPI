-- Lua provided by RyzenAPI
-- Game: Game: Claybook

-- MAIN APPLICATION
addappid(661920)
-- Game: addappid(661920)

-- MAIN APP DEPOTS / PACKAGES
addappid(661921, 1, "b7cf61a591436a9cf3622cb56f0bb7160990da65c892b92c4bfa33a750a5d364")
