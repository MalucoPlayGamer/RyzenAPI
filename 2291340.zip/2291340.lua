-- Lua provided by RyzenAPI
-- Game: The Baby In Yellow

-- MAIN APPLICATION
addappid(2291340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2291341, 1, "2b5d1d695b2eb44f8dfb6da030036555818151ae85c931c08266c4ae04d15c42")

