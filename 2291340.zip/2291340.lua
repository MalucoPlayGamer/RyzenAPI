-- Lua provided by RyzenAPI
-- Game: addappid(2291340)

-- MAIN APPLICATION
addappid(2291340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291341, 1, "2b5d1d695b2eb44f8dfb6da030036555818151ae85c931c08266c4ae04d15c42")
