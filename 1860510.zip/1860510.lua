-- Lua provided by RyzenAPI
-- Game: Total Conflict: Resistance

-- MAIN APPLICATION
addappid(1860510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860511, 1, "6da400d94115d37c6474b287e5f8e41e78ec2083d54ff7dffd6d1b3b2dc8dc0d")
