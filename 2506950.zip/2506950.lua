-- Lua provided by RyzenAPI
-- Game: The Karters 2: Turbo Charged - Prologue

-- MAIN APPLICATION
addappid(2506950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506951, 1, "73c95f4c2a6df71fd6ed6c14fe6f571c3af75368b7a030bd5b73200476f2196a")

