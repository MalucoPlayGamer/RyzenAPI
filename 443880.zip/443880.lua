-- Lua provided by RyzenAPI
-- Game: Loot Rascals

-- MAIN APPLICATION
addappid(443880)
-- Game: addappid(443880)

-- MAIN APP DEPOTS / PACKAGES
addappid(443881, 1, "3e9a9c71c59bf948ee049270b97cdf8c39ac1257c658bff4b5f368b2d650f3c8")
