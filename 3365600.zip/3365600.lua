-- Lua provided by RyzenAPI
-- Game: addappid(3365600)

-- MAIN APPLICATION
addappid(3365600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365601, 1, "27436bd1896fa8b3a31039f9adae4bc4a78820d1b5b4342b1a6234aca79e9f33")
