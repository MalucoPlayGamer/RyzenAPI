-- Lua provided by RyzenAPI
-- Game: Game: Garlic

-- MAIN APPLICATION
addappid(1250440)
-- Game: addappid(1250440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250441, 1, "36691ab9b54a1583cdb72655ddf3395c1cbf455105f9640a28f73e2ac98f54ce")
