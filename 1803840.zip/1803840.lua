-- Lua provided by RyzenAPI
-- Game: 1803840

-- MAIN APPLICATION
addappid(1803840)
-- Game: addappid(1803840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803841, 1, "f58519feab0e76bde96f040fcb8bc0ae9b1aac37be5596d74a2438764837e4d9")
