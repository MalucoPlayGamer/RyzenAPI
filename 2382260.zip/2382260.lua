-- Lua provided by RyzenAPI
-- Game: Puzzle GO!

-- MAIN APPLICATION
addappid(2382260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382261, 1, "3c66bdb53d9b3145f92c047399f119cd2ea132bb426ce9ef055760662dadf44d")

