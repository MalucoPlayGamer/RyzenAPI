-- Lua provided by RyzenAPI
-- Game: Game: Construction Simulator 2 US - Pocket Edition

-- MAIN APPLICATION
addappid(787740)
-- Game: addappid(787740)

-- MAIN APP DEPOTS / PACKAGES
addappid(787741, 1, "7303bd605a593e6f040e08e7a8912e6df636441d66babd1bc94a358ba32f0a27")
