-- Lua provided by RyzenAPI 
-- Game: AppID 3255060
addappid(3255060)
addappid(3255061, 1, "78439312a54d0f1a4a25d49100f76d3d207a8ecff18f68937a6cf4f280c80184")
