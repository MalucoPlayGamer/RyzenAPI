-- Lua provided by RyzenAPI
-- Game: addappid(1329810)

-- MAIN APPLICATION
addappid(1329810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329811, 1, "75ea8a79b67a9eea89ccad807589ed0ee64b7890cae20cd1d759bda91d7ee2ef")
