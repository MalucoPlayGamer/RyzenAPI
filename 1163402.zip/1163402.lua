-- Lua provided by RyzenAPI
-- Game: 1163402

-- MAIN APPLICATION
addappid(1163402)
-- Game: addappid(1163402)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163402,0,"607bfe074df97f5d7c8988edc82a203de4df5f584dfd00abb82f0e2a1f2f9c4f")
