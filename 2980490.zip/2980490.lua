-- Lua provided by RyzenAPI
-- Game: addappid(2980490)

-- MAIN APPLICATION
addappid(2980490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980491, 1, "6f7a9ab7198ca88321caa1cf3d19544e751f86c8d9dd1505f79528d492ff82c5")
