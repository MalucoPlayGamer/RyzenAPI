-- Lua provided by RyzenAPI
-- Game: Game: AppID 962970

-- MAIN APPLICATION
addappid(962970)
addappid(2226560)
-- Game: addappid(962970)

-- MAIN APP DEPOTS / PACKAGES
addappid(962971, 1, "dd631398c8faf0171823c20a2650ea02ccde48674676e2676bc72de1b089f609")
addappid(962972, 1, "af026073b6ed14eca09e8a5b74478e460913d2825759d649c072fe1643f1fdd2")
