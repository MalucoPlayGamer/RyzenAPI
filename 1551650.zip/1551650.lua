-- Lua provided by RyzenAPI
-- Game: Sword Princess Sistina

-- MAIN APPLICATION
addappid(1551650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551651, 1, "1f0ffe6e6a61fe3d02ebbe1f9d099d13fceb2a2654661590f9dd7aaa7504d664")
addappid(1551652, 1, "2376d1eefd39f186e7f6912a3a030d5b94842d8f34fdd59658ef303a62ab1699")
