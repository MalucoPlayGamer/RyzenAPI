-- 4650490's Lua and Manifest Created by Hubcap Manifest
-- Idle Immortal Sentinel
-- Created: August 04, 2026 at 14:14:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4650490) -- Idle Immortal Sentinel
-- MAIN APP DEPOTS
addappid(4650491, 1, "cc9ca52eb12caa088cb0673f44955676724552f3eb4a337b03a8d1777337db2f") -- Depot 4650491
setManifestid(4650491, "8741146747653097769", 862221110)