-- Lua provided by RyzenAPI
-- Game: Idle Immortal Sentinel

-- MAIN APPLICATION
addappid(4650490) -- Idle Immortal Sentinel

-- MAIN APP DEPOTS / PACKAGES
addappid(4650491, 1, "cc9ca52eb12caa088cb0673f44955676724552f3eb4a337b03a8d1777337db2f") -- Depot 4650491

