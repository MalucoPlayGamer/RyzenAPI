-- Lua provided by RyzenAPI
-- Game: AppID 545670

-- MAIN APPLICATION
addappid(545670)
-- Game: addappid(545670)

-- MAIN APP DEPOTS / PACKAGES
addappid(545671, 1, "4ef84afd1e5b51d97935381a4e4c27a17ba4dd5595573a43c861e964fd08a164")
