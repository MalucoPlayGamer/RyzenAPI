-- Lua provided by RyzenAPI
-- Game: Lords and Legions

-- MAIN APPLICATION
addappid(589050)

-- MAIN APP DEPOTS / PACKAGES
addappid(589051,0,"62cc4d6c532552e7e599489e6f3bac853aa54f29fdbc21b6e1678b59e6aac86e")

