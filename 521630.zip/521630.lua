-- Lua provided by RyzenAPI
-- Game: Toadled Classic

-- MAIN APPLICATION
addappid(521630)
-- Game: addappid(521630)

-- MAIN APP DEPOTS / PACKAGES
addappid(521631, 1, "95d44330d153affb5345bc2a59216c79453889021dbe18e6d10e9a3fb5c204e8")
addappid(521632, 1, "10ced55ae55601a094fb2911a66a0e4dca0246623031778640dcf870c1652661")
