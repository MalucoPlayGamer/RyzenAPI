-- Lua provided by SkyAPI 
-- Game: Purrfect Apawcalypse: Love at Furst Bite
addappid(1532510)
addappid(1532511, 1, "3d2a43010fa12dafeb2ddba26e6206721f72a18d7ac8130d13ed87260a74112a")
