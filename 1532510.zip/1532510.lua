-- Lua provided by RyzenAPI
-- Game: addappid(1532510)

-- MAIN APPLICATION
addappid(1532510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532511, 1, "3d2a43010fa12dafeb2ddba26e6206721f72a18d7ac8130d13ed87260a74112a")
