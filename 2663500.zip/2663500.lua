-- Lua provided by RyzenAPI
-- Game: Firework Simulator Demo

-- MAIN APPLICATION
addappid(2663500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663501, 1, "aa0d672cb72c74cf84787ebdc0aa45045a49f511eacd84c88c3bfecea4ae1655")

