-- Lua provided by SkyAPI 
-- Game: Nothing Together
addappid(2788630)
addappid(2788631, 1, "d6065ae36662f9f09cc8247bf78294f99a645bab2a080634a7555555a2516778")
