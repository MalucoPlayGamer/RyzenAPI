-- Lua provided by RyzenAPI
-- Game: Nothing Together

-- MAIN APPLICATION
addappid(2788630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788631, 1, "d6065ae36662f9f09cc8247bf78294f99a645bab2a080634a7555555a2516778")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2835170)
addappid(2835930)
addappid(2835940)
addappid(2842340)
addappid(2855260)
addappid(2855270)
addappid(2872530)
addappid(2872540)
