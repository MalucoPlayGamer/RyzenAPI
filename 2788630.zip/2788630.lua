-- Lua provided by RyzenAPI
-- Game: Nothing Together

-- MAIN APPLICATION
addappid(2788630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788631, 1, "d6065ae36662f9f09cc8247bf78294f99a645bab2a080634a7555555a2516778")

