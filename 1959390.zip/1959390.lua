-- Lua provided by RyzenAPI
-- Game: 1959390

-- MAIN APPLICATION
addappid(1959390)
-- Game: addappid(1959390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959391, 1, "cb1b5908d2dd9c0e028317665a30c81d16fae6eaa155dc2202cf51b47784c257")
