-- Lua provided by RyzenAPI
-- Game: 1660840

-- MAIN APPLICATION
addappid(1660840)
-- Game: addappid(1660840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660841, 1, "0408c5cf14dd89f80d031a9880eca5777d24d2b82d49c91b7569a34556eae74e")
