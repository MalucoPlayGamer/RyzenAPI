-- Lua provided by RyzenAPI
-- Game: SpaceWalker

-- MAIN APPLICATION
addappid(705860)

-- MAIN APP DEPOTS / PACKAGES
addappid(705861, 1, "ff069d510750062bf6a4fb6b8fd4255c4b98c3d401013064c83b128d5ab7261b")

