-- Lua provided by RyzenAPI
-- Game: Legendary Hoplite: Arachne’s Trial

-- MAIN APPLICATION
addappid(2738430)
-- Game: addappid(2738430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738431, 1, "bf44bf8e1b37d1120c56533134711b73499bfe13294880c169fdf39da511126b")
