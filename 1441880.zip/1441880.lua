-- Lua provided by RyzenAPI
-- Game: NEO 2045: Adventure MMO Game

-- MAIN APPLICATION
addappid(1441880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441881, 1, "218800faabe657d87a585b8c0d76c9a2bfb46a2a45ec64d83c7c955a02c2ef6f")
