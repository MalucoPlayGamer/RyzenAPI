-- Lua provided by RyzenAPI
-- Game: 2980670

-- MAIN APPLICATION
addappid(2980670)
-- Game: addappid(2980670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980671, 1, "7a1cc8fe30882c51f64467d3b7ed25b98b311e92e4dde0c89170754230fa81d5")
