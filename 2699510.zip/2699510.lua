-- Lua provided by RyzenAPI
-- Game: addappid(2699510)

-- MAIN APPLICATION
addappid(2699510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699511, 1, "c8d677a738132bbd30c84f075f53acab0f0973e22b9c9cde485904c807854441")
