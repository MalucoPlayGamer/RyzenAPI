-- Lua provided by RyzenAPI
-- Game: 826540

-- MAIN APPLICATION
addappid(826540)
-- Game: addappid(826540)

-- MAIN APP DEPOTS / PACKAGES
addappid(826541, 1, "10ba34629836372c9625e1ac7f90edde1aba5421e687a7235b6d5ea7aafb9e96")
addappid(2531400, 0, "e7056f3a807b0dca1c5310bc983d78d110d01ed41589ce8fa79c534547507d9b")
