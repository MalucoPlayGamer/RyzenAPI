-- Lua provided by RyzenAPI
-- Game: Steel Ocean: Wolves of Deep Sea

-- MAIN APPLICATION
addappid(1949220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949221, 1, "2665ee85219d26ec2112e488b3e52d5a5ded2442007dd0fdb790af72d42ea7f3")

