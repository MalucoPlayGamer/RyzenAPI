-- Lua provided by RyzenAPI
-- Game: Steel Ocean: Wolves of Deep Sea

-- MAIN APPLICATION
addappid(1949220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1949221, 1, "2665ee85219d26ec2112e488b3e52d5a5ded2442007dd0fdb790af72d42ea7f3")

