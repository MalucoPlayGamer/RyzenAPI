-- Lua provided by RyzenAPI
-- Game: AppID 2527500

-- MAIN APPLICATION
addappid(2527500)
-- Game: addappid(2527500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527501, 1, "ffef2d1f42cd2438f5b7d029d771a9f941fd224250c3184f595773fb4926e1cd")
