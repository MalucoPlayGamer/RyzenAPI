-- Lua provided by RyzenAPI
-- Game: Barro

-- MAIN APPLICATION
addappid(618140)

-- MAIN APP DEPOTS / PACKAGES
addappid(618141, 1, "4ba36a9bf0198f2725efc006145afad5374f225f2723bcfde4a0d2f348ee0717")
addappid(618142, 1, "3009b5a2d493da5cfedc1723c7d38c4701632c4d884cf9e76b8372f3c08a7cd1")
