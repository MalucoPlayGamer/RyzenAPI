-- Lua provided by RyzenAPI
-- Game: addappid(1713750)

-- MAIN APPLICATION
addappid(1713750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713751, 1, "1ee5ba0b23770e2836e3238acb9b4e406d9630beb30d7aa9102f49485d2009e6")
