-- Lua provided by RyzenAPI
-- Game: The Technician

-- MAIN APPLICATION
addappid(839960)

-- MAIN APP DEPOTS / PACKAGES
addappid(839961,0,"9cd49969b39debcb7140c37bc960d8a202653cf45b720d7d78d77d11a9eeba61")

