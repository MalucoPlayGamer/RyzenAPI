-- Lua provided by RyzenAPI
-- Game: addappid(2082410)

-- MAIN APPLICATION
addappid(2082410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082411, 1, "a6a8f8e8bfbb9bafb66382aeb438c6bb9e7a075236e4283ebfc7d510e4b0e8ad")
