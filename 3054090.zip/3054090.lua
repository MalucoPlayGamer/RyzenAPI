-- Lua provided by RyzenAPI
-- Game: 3054090

-- MAIN APPLICATION
addappid(3054090)
-- Game: addappid(3054090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054091, 1, "fd32efd0fb975126498e8da15b9bb0982a950ae09ddb13efe97ec653076c0cbf")
