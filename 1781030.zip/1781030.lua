-- Lua provided by RyzenAPI
-- Game: Game: Fishing Paradiso

-- MAIN APPLICATION
addappid(1781030)
-- Game: addappid(1781030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781031, 1, "f3e502ff799041f17a492db0447dd8e9d5852a6b546e211b7dd86ddca475ad13")
