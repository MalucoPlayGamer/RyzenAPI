-- Lua provided by RyzenAPI
-- Game: addappid(898120)

-- MAIN APPLICATION
addappid(898120)

-- MAIN APP DEPOTS / PACKAGES
addappid(898121, 1, "2f9def2d955a8f4341aab1c126419816d0788a3e036baa22d7af32c06c971121")
