-- Lua provided by RyzenAPI
-- Game: VoxFox

-- MAIN APPLICATION
addappid(1336950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336951, 1, "5f576be3705223c33a2e2c86bbd3032c024539427e7ce498edfbf263dece354e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
