-- Lua provided by RyzenAPI
-- Game: VoxFox

-- MAIN APPLICATION
addappid(1336950)
-- Game: addappid(1336950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336951, 1, "5f576be3705223c33a2e2c86bbd3032c024539427e7ce498edfbf263dece354e")
