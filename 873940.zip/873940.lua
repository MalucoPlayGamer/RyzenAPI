-- Lua provided by RyzenAPI
-- Game: Crying Suns

-- MAIN APPLICATION
addappid(873940)

-- MAIN APP DEPOTS / PACKAGES
addappid(873945,0,"6fdd2d670421a8be6cf95b0cbc021fa9288687c4ea46b91b1825a6898b6e3304")
addappid(873946,0,"81e2ed60c8fb92a2cb2e8a472178c8e7f6c5c499e8814ec6592e672a6a752b3b")
addappid(873947,0,"0cb4aa0549c3e773745871b5f98f0e444315ee196467c35b7ccc294882bd487a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1271330)
