-- Lua provided by RyzenAPI
-- Game: The 11th Hour

-- MAIN APPLICATION
addappid(255940)
-- Game: addappid(255940)

-- MAIN APP DEPOTS / PACKAGES
addappid(255941, 1, "558f8f5accbbf5d89d1a8099f1ef3ebb7b7ed89485d7fa887d362dbd851f7366")
addappid(255942, 1, "185c7ab5fce660f180b1f59588f7fd8c79770ae005772cfc0a0318f52965c787")
addappid(255943, 1, "b08dd6430c61c2e3b4a88c3239fe2f2c717a305d6666d597db2807c32cab91cc")
