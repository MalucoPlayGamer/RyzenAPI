-- Lua provided by RyzenAPI
-- Game: 1290770

-- MAIN APPLICATION
addappid(1290770)
-- Game: addappid(1290770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290771, 1, "c74e8fafc78932307ad9b7bad19ec88ec49eb82ca3d4bde14acb68d21041ed34")
