-- Lua provided by RyzenAPI
-- Game: AIPD - Artificial Intelligence Police Department

-- MAIN APPLICATION
addappid(390930)
-- Game: addappid(390930)

-- MAIN APP DEPOTS / PACKAGES
addappid(390931, 1, "93105163e24e2a6bece4a9fdbf435927630b96494309681747b76559606da116")
addappid(394040, 0, "4513a23a4e254d59f1ec027b1d5f1d27d472e7ea101c71f9ca462405da29ff1b")
