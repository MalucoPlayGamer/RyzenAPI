-- Lua provided by RyzenAPI
-- Game: Lu Bu - Officer Ticket / 呂布使用券

-- MAIN APPLICATION
addappid(956726)

-- MAIN APP DEPOTS / PACKAGES
addappid(956726,0,"78e7c479bd4234984e800008c428673d90d35ca5616773ec98ccebb6e209f0e3")
