-- Lua provided by RyzenAPI
-- Game: Tantal

-- MAIN APPLICATION
addappid(1425280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425281, 1, "5f7b81c86c19a99e86a0cd74ddb9ef44ae5d94b39b16bbe2f4888b0c603f41c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
