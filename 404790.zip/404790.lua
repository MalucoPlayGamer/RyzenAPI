-- Lua provided by RyzenAPI
-- Game: Godot Engine

-- MAIN APPLICATION
addappid(404790)

-- MAIN APP DEPOTS / PACKAGES
addappid(404791, 1, "aa9b152bf8b1a428e665ad578518f350836db5be419fe4d31de2ebdda99d53d2")
addappid(404792, 1, "a0536367757e0c205caa3119cc7c706fb3677d9ac140606b680eb2c87959b75b")
addappid(404793, 1, "6d80fe68f8c5acd74e8dabdaed9b29e7a740fb0617ed89b13d92874065ae0a08")
addappid(404794, 1, "8c00ecd84831a0f8e17ff8fe5e517a61615b9e5d8da506233954a62db48dab71")
addappid(404795, 1, "c2ed3a653e7da99f945a996f1c900636a7278331b7be9555d7864a1ce0056abe")
addappid(404796, 1, "04971deac92baf980d50e3746dbd1bdab97afaae335bb7c0460caf56222407c5")
addappid(404797, 1, "86da38f980b95f2ab8b2bcf1deea4dbfb4f276efaad717821546f75c9cd828b5")

