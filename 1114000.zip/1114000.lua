-- Lua provided by RyzenAPI
-- Game: AppID 1114000

-- MAIN APPLICATION
addappid(1114000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1114001, 1, "de62b5c5f84e8338dd2dc6c40477b5b7853186b60ec1d0739821f20f88aff1bf")

