-- Lua provided by RyzenAPI
-- Game: addappid(1114000)

-- MAIN APPLICATION
addappid(1114000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114001, 1, "de62b5c5f84e8338dd2dc6c40477b5b7853186b60ec1d0739821f20f88aff1bf")
