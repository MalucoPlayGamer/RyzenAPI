-- Lua provided by RyzenAPI
-- Game: AppID 3175730

-- MAIN APPLICATION
addappid(3175730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175731, 1, "bb3bb39fe699bd2d12160ccff4b36562b73bc25b78dbdbcc66ad1f0b8039e492")

