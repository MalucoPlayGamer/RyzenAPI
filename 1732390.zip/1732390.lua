-- Lua provided by RyzenAPI
-- Game: Nayuta no Kiseki: KAI

-- MAIN APPLICATION
addappid(1732390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732391, 1, "4d0b9fdb6b2518a92b11563182daf85685d3d827ecc7ca573745d057eccf494a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
