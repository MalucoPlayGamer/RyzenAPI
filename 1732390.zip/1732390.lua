-- Lua provided by RyzenAPI
-- Game: 1732390

-- MAIN APPLICATION
addappid(1732390)
-- Game: addappid(1732390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732391, 1, "4d0b9fdb6b2518a92b11563182daf85685d3d827ecc7ca573745d057eccf494a")
