-- Lua provided by RyzenAPI
-- Game: Dungeon Ascent

-- MAIN APPLICATION
addappid(3568400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568401, 1, "9220433d3a5a65d25aa87a6e1ae05aa4093ad32480ee93f86c214ddc56374246")

