-- Lua provided by RyzenAPI
-- Game: The Shadow Over Cyberspace

-- MAIN APPLICATION
addappid(2982530)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3318240)
