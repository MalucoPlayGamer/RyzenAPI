-- Lua provided by RyzenAPI
-- Game: The Shadow Over Cyberspace

-- MAIN APPLICATION
addappid(2982530)
addappid(3318240)

