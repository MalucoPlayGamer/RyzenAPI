-- Lua provided by RyzenAPI
-- Game: 足臭的女孩

-- MAIN APPLICATION
addappid(1889100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889101, 1, "71e0cc6020d86eb082e5e29d02d00712ae5e2e613d7c622a0e7958b7988e518e")
