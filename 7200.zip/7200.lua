-- Lua provided by RyzenAPI
-- Game: Trackmania United Forever

-- MAIN APPLICATION
addappid(7200)

-- MAIN APP DEPOTS / PACKAGES
addappid(7202,0,"2870451c173b53ff2de8767749874b39089f4697f2b70a97e91dc661cd3352e5")
