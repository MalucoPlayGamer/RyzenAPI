-- Lua provided by RyzenAPI
-- Game: Game: Hidden World 9 Top-Down 3D

-- MAIN APPLICATION
addappid(2682820)
-- Game: addappid(2682820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682821, 1, "27915ea47ade7d3fc2f1199b51dee10d154f0260fa7e5faeba697387518540eb")
