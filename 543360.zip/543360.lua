-- Lua provided by RyzenAPI
-- Game: 543360

-- MAIN APPLICATION
addappid(543360)
-- Game: addappid(543360)

-- MAIN APP DEPOTS / PACKAGES
addappid(543361, 1, "fa9ccacbc786f861ac5d016cdba2537eab9d00269e82d047e23c4b944ac91c00")
