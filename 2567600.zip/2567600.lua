-- Lua provided by RyzenAPI
-- Game: Game: Scare Girl 2

-- MAIN APPLICATION
addappid(2567600)
-- Game: addappid(2567600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567601, 1, "0f48c9d09c592ab75eb495e8fc6ba953dcdd6f15ab876d64907a6facf46a72ae")
