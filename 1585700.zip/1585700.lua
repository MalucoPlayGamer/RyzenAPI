-- Lua provided by RyzenAPI
-- Game: Game: Trap Genesis

-- MAIN APPLICATION
addappid(1585700)
-- Game: addappid(1585700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585701, 1, "9f199ea37f971ad3005d1348b3b27dc711bbc56ba8a464e1f819bc470e44934b")
