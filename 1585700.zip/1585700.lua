-- Lua provided by SkyAPI 
-- Game: Trap Genesis
addappid(1585700)
addappid(1585701, 1, "9f199ea37f971ad3005d1348b3b27dc711bbc56ba8a464e1f819bc470e44934b")
