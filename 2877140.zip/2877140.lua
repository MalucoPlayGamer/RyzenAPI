-- 2877140's Lua and Manifest Created by Hubcap Manifest
-- Solarpunk Tactics
-- Created: August 27, 2026 at 05:45:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2877140) -- Solarpunk Tactics
addtoken(2877140, "8480729269817094309")
-- MAIN APP DEPOTS
addappid(2877141, 1, "d042558ae8e7ea930f95ad76b0e0a6904dd2d55125ae67bbfc8ae33f73a62066") -- Depot 2877141
setManifestid(2877141, "7571286436865083516", 1871220478)