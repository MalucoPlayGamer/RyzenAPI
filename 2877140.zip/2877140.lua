-- Lua provided by RyzenAPI
-- Game: Solarpunk Tactics

-- MAIN APPLICATION
addappid(2877140) -- Solarpunk Tactics

-- MAIN APP DEPOTS / PACKAGES
addappid(2877141, 1, "d042558ae8e7ea930f95ad76b0e0a6904dd2d55125ae67bbfc8ae33f73a62066") -- Depot 2877141
addtoken(2877140, "8480729269817094309")

