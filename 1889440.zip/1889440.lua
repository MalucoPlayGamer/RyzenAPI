-- Lua provided by RyzenAPI
-- Game: Game: The Unfamiliar Story of Grandfather's Heritage

-- MAIN APPLICATION
addappid(1889440)
-- Game: addappid(1889440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889441, 1, "e76097c71f448fdb49c48ab886e547a9d8c302a100de2fa3393b1bcd77a964b9")
