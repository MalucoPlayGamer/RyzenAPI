-- Lua provided by RyzenAPI
-- Game: The Unfamiliar Story of Grandfather's Heritage

-- MAIN APPLICATION
addappid(1889440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889441, 1, "e76097c71f448fdb49c48ab886e547a9d8c302a100de2fa3393b1bcd77a964b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
