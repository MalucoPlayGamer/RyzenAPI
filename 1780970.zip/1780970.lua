-- Lua provided by RyzenAPI
-- Game: 1780970

-- MAIN APPLICATION
addappid(1780970)
-- Game: addappid(1780970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780970,0,"2bb1dcda67fd138471381a098a22cf43c0d351f242417fc86af215dd284b9c69")
