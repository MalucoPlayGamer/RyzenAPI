-- Lua provided by RyzenAPI
-- Game: Game: AppID 1134440

-- MAIN APPLICATION
addappid(1134440)
-- Game: addappid(1134440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134441, 1, "102e1d0f2faf2eba63cfd7a78f1ea9c75015fbfdde78be530003c6a3e3da1e7f")
