-- Lua provided by RyzenAPI
-- Game: Hentai Honeys Slider

-- MAIN APPLICATION
addappid(1134440)
addappid(1216680)
addappid(1216681)
addappid(1277860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134441, 1, "102e1d0f2faf2eba63cfd7a78f1ea9c75015fbfdde78be530003c6a3e3da1e7f")

