-- Lua provided by RyzenAPI
-- Game: Aplowcalypse

-- MAIN APPLICATION
addappid(465440)
-- Game: addappid(465440)

-- MAIN APP DEPOTS / PACKAGES
addappid(465441, 1, "596137c2f66f7f482ee43b0deb006101bb307968dcc09a55f050ece38664c44d")
addappid(465442, 1, "1a0287cb6e5d190c72e5f15fdeeff1d1c88ddf74e911d9c7e51909955201a2c2")
addappid(465443, 1, "39675ffa25bf420de0ac0483acba68c8802925388999639febacfa29e506b4ee")
addappid(465444, 1, "08f707a27d0f062cafda17c4120a0a8736bfaff472de6c6e94a23f99a7fcd341")
addappid(465445, 1, "7161b9599fe184f9de02ddca6804bb57b2f493c76b23662b81e371a5fe140c7e")
