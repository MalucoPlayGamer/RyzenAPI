-- Lua provided by RyzenAPI
-- Game: Jrago Disconnect

-- MAIN APPLICATION
addappid(2526340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526342,0,"7824fa3286258238eeef36513ddac5391f181c591a999cc4fdd5e20c47f8b5be")
