-- Lua provided by RyzenAPI
-- Game: Smoots Tennis Survival Zombie

-- MAIN APPLICATION
addappid(564920)

-- MAIN APP DEPOTS / PACKAGES
addappid(564921, 1, "132439fd9e22bd3576ef5a55f2c4a1f2d2825eb368ac7203381ffcac17c54e5d")
