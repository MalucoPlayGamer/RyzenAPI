-- Lua provided by RyzenAPI
-- Game: addappid(2868430)

-- MAIN APPLICATION
addappid(2868430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868431, 1, "bac6d629f1c2ffd9ba0846e64cb2a42ffccbfd156891e5b07b30647129472b82")
