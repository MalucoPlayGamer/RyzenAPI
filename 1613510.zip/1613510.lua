-- Lua provided by RyzenAPI
-- Game: addappid(1613510)

-- MAIN APPLICATION
addappid(1613510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613511, 1, "59dfc8cf7dcac3983580a19de7cd5d9819cecc6dfa2e3d55cefbb864a716d1fa")
