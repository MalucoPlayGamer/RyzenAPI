-- Lua provided by RyzenAPI
-- Game: addappid(949550)

-- MAIN APPLICATION
addappid(949550)

-- MAIN APP DEPOTS / PACKAGES
addappid(949551, 1, "b2b3f6c5647b99659178cf198250a35e3e0b7d2c30162699c0ca2b1d7bb647d9")
