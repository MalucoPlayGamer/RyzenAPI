-- Lua provided by RyzenAPI 
-- Game: DOOM TOMB
addappid(1893050)
addappid(1893051, 1, "7d0a00417db3f92d8fb4230a188440ebb906aa2ee8c40a3986ca4346c7a2500a")
