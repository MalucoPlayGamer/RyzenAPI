-- Lua provided by RyzenAPI
-- Game: DOOM TOMB

-- MAIN APPLICATION
addappid(1893050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893051, 1, "7d0a00417db3f92d8fb4230a188440ebb906aa2ee8c40a3986ca4346c7a2500a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
