-- Lua provided by RyzenAPI
-- Game: From Hell

-- MAIN APPLICATION
addappid(3098410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3098411, 1, "23ba6f8f52df4762464bef02e3f41071ef40d5ca4238c7dda1fad72a025c425f")

