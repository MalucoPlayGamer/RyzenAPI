-- Lua provided by RyzenAPI
-- Game: AppID 3098410

-- MAIN APPLICATION
addappid(3098410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098411, 1, "23ba6f8f52df4762464bef02e3f41071ef40d5ca4238c7dda1fad72a025c425f")
