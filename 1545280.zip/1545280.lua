-- Lua provided by RyzenAPI
-- Game: Game: Garetto

-- MAIN APPLICATION
addappid(1545280)
-- Game: addappid(1545280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545281, 1, "06a91c6346be8b0221ac9a2679aef83e020c7edca32eb19de1f69755bf5cc59f")
