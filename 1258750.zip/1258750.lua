-- Lua provided by RyzenAPI
-- Game: addappid(1258750)

-- MAIN APPLICATION
addappid(1258750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258752,0,"b94c8655c13fc827696e7dfdb1c3139a3b5f37ac2a35e545b43d55fbf4c896c9")
