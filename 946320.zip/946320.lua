-- Lua provided by RyzenAPI
-- Game: 946320

-- MAIN APPLICATION
addappid(946320)
-- Game: addappid(946320)

-- MAIN APP DEPOTS / PACKAGES
addappid(946321, 1, "51481b6920c83c8cf942220a4c7b03be7fc384ae2d80baad186f3ff0fd43a224")
