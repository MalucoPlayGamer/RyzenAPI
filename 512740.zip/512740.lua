-- Lua provided by RyzenAPI
-- Game: Flat Path

-- MAIN APPLICATION
addappid(512740)
-- Game: addappid(512740)

-- MAIN APP DEPOTS / PACKAGES
addappid(512741, 1, "6f2a795e2f9c18152b16b6c09ee5a1214475b6372dca0b83ddcd403a50f76d2c")
addappid(512742, 1, "5aae8086ecb0844107766886ac82a46d748ce370b3c612adb92055aa40502ea4")
addappid(512743, 1, "5776dd79f80221b97a0e94a768688ef7fd3c6ab9cbe8e0e4890bf5dc91596a3a")
addappid(512744, 1, "509f8d0286af7e895d10535ea57fad473c187b7cf9d6b713902255e25ffcbce8")
