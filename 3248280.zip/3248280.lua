-- Lua provided by RyzenAPI 
-- Game: AppID 3248280
addappid(3248280)
addappid(3248281, 1, "6009c16791f713197206919ddab997f28cc6a3e7c166da1a0bdd8470df7782a8")
