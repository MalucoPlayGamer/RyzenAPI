-- Lua provided by RyzenAPI
-- Game: Realms of Madness Demo

-- MAIN APPLICATION
addappid(3417770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417771, 1, "47986771b5b2a880cd887132212291f67bd2a126fb99052c34a59f249befa6c4")
