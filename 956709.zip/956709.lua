-- Lua provided by RyzenAPI
-- Game: Sun Jian - Officer Ticket / 孫堅使用券

-- MAIN APPLICATION
addappid(956709)

-- MAIN APP DEPOTS / PACKAGES
addappid(956709,0,"0debf4e31570d0e8b57e88a09d8b6e906903449d8bfbbcd67146627aed1718bc")

