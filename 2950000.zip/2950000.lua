-- Lua provided by RyzenAPI
-- Game: Ninja Stealth 5

-- MAIN APPLICATION
addappid(2950000)
-- Game: addappid(2950000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950001, 1, "20bc17eae67cb2e1e1418149cae69854e7a2ba2f32b152eed8873b18d16cf4b5")
addappid(2950002, 1, "0ed0db2772afbf26944059076d682a73f46a2a45d943f202718965ab603663dd")
