-- Lua provided by RyzenAPI
-- Game: Skinwalkers Valley

-- MAIN APPLICATION
addappid(4172680)

-- MAIN APP DEPOTS / PACKAGES
addappid(4172681, 1, "e4078146576dd1e312d31ffda375a8e1a948241b01ec7fd8e7815b086b9643a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
