-- Lua provided by RyzenAPI
-- Game: Game: Skinwalkers Valley

-- MAIN APPLICATION
addappid(4172680)
-- Game: addappid(4172680)

-- MAIN APP DEPOTS / PACKAGES
addappid(4172681, 1, "e4078146576dd1e312d31ffda375a8e1a948241b01ec7fd8e7815b086b9643a2")
