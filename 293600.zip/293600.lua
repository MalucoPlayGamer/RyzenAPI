-- Lua provided by RyzenAPI
-- Game: Arson and Plunder: Unleashed

-- MAIN APPLICATION
addappid(293600)
-- Game: addappid(293600)

-- MAIN APP DEPOTS / PACKAGES
addappid(293601, 1, "4d9ee9bde867b86ad207cd5377241da782c8534a8174e666a773354b6684a8f8")
