-- Lua provided by SkyAPI 
-- Game: PandaSG
addappid(1590680)
addappid(1590681, 1, "27b98a58b5f29cd5e12f9cfb53b77137e3d5a0cde459ab88c4e81de708f55919")
