-- Lua provided by RyzenAPI
-- Game: AppID 391780

-- MAIN APPLICATION
addappid(391780)

-- MAIN APP DEPOTS / PACKAGES
addappid(391781, 1, "55ffa28b8ed21dbaa7e54eb7ce6ac7c3264aab9bbec2b418d59315f51682e7d8")
