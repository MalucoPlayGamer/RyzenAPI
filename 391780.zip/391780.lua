-- Lua provided by RyzenAPI
-- Game: Uebergame

-- MAIN APPLICATION
addappid(391780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(391781, 1, "55ffa28b8ed21dbaa7e54eb7ce6ac7c3264aab9bbec2b418d59315f51682e7d8")

