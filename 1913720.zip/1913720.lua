-- Lua provided by RyzenAPI
-- Game: 69 Estera Hot

-- MAIN APPLICATION
addappid(1913720)
-- Game: addappid(1913720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913721, 1, "cf79ee2b4702e68eb9115eb9bf20deaf74071de5e47382f43ec02b6aa1025b6b")
