-- Lua provided by RyzenAPI
-- Game: Game: AppID 295750

-- MAIN APPLICATION
addappid(295750)
addappid(365830)
-- Game: addappid(295750)

-- MAIN APP DEPOTS / PACKAGES
addappid(295751, 1, "59fdd5470b3af1b41cb9fb53b2862866ecd7f575dccbd44b8a19e74fb14e54fe")
addappid(295753, 1, "02f6bb088114af1d116f02abdf66b1488ee8d4bee262e089a0029b25fc7a5c9a")
