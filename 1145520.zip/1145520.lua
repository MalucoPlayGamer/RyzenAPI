-- Lua provided by RyzenAPI
-- Game: addappid(1145520)

-- MAIN APPLICATION
addappid(1145520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145521, 1, "9196ebaaeb7184e6586591ed7c35af98ad59d517ea67dc0b2e3c7ad6c25a7e66")
