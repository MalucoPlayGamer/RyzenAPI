-- Lua provided by RyzenAPI
-- Game: Wall Force

-- MAIN APPLICATION
addappid(1145520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1145521, 1, "9196ebaaeb7184e6586591ed7c35af98ad59d517ea67dc0b2e3c7ad6c25a7e66")

