-- Lua provided by RyzenAPI
-- Game: Great Hunt: North America

-- MAIN APPLICATION
addappid(785670)
-- Game: addappid(785670)

-- MAIN APP DEPOTS / PACKAGES
addappid(785671, 1, "78701a0601ff384000d9af6117629716df8254634e322f5cd59d77b7b25fb760")
addappid(785672, 1, "b62aadad2bae6be73b9f7044ee88c54317ecfe2f251c30bf450817a1a4ef87cd")
