-- Lua provided by RyzenAPI
-- Game: Vegas Craps by Pokerist

-- MAIN APPLICATION
addappid(3601450)
