-- Lua provided by RyzenAPI
-- Game: Blade Ballet

-- MAIN APPLICATION
addappid(460750)

-- MAIN APP DEPOTS / PACKAGES
addappid(460751, 1, "7dcd73120f32638b94f7d32a93f04c6f083d1116ffe4f6ce609cce4132cc25e6")
addappid(460752, 1, "8729a83b295e347ac32c0b948e8a37eb4833e8c2a5caa5b231cbe434f3d0663b")
addappid(510600, 0, "b17bf5698fdc47e0029ef688ad99e5df5e3419e4b0d0a3ce43e09f0941a62f96")

