-- Lua provided by RyzenAPI
-- Game: Game: Neverending AI Storybook

-- MAIN APPLICATION
addappid(3554810)
addappid(3839070)
-- Game: addappid(3554810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554811, 1, "f764a67cc190de80290cea6d2a26c69b2d489d8c6867d48c842f7e13d7528100")
