-- Lua provided by SkyAPI 
-- Game: Dick Hook
addappid(1829490)
addappid(1829491, 1, "d14673f13de282810d470e57002f8145b221a4e1e872d3bd950503bbe9020407")
