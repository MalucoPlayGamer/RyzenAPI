-- Lua provided by RyzenAPI
-- Game: Dick Hook

-- MAIN APPLICATION
addappid(1829490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829491, 1, "d14673f13de282810d470e57002f8145b221a4e1e872d3bd950503bbe9020407")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
