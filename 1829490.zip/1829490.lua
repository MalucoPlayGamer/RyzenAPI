-- Lua provided by RyzenAPI
-- Game: Dick Hook

-- MAIN APPLICATION
addappid(1829490)
-- Game: addappid(1829490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829491, 1, "d14673f13de282810d470e57002f8145b221a4e1e872d3bd950503bbe9020407")
