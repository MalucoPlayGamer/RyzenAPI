-- Lua provided by RyzenAPI
-- Game: Forever to You! - Wallpapers

-- MAIN APPLICATION
addappid(2173560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173560,0,"d91e778667e3897364c4b99163ce5d4678b0aefa5955279cf4804404909a8aaf")

