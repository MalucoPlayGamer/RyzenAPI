-- Lua provided by RyzenAPI
-- Game: ЯР Demo

-- MAIN APPLICATION
addappid(3008090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008091, 1, "05b7ccaa23c38015e167ddca4e13584f2a115e4340a667887bc2d35143c15db8")
