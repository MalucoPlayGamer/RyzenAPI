-- Lua provided by RyzenAPI
-- Game: addappid(2666570)

-- MAIN APPLICATION
addappid(2666570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666572,0,"12bf83b3c42605b3ec95a7fac819c471563c3dcb328789c431f9b895db278f57")
