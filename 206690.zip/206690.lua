-- Lua provided by SkyAPI 
-- Game: iBomber Defense Pacific
addappid(206690)
addappid(206691, 1, "b5802b400e9785ce026233e98ca1f3727a8a642cfcee45541fcb1b445e8e44d4")
addappid(206692, 1, "a585bed170212cf3bf66f67b7396dff8a7d50e9199d1c6fea1532586f4e2db40")
addappid(206693, 1, "3271d47826e8375781a73ea323c8b7fb1b4e3038118e9c499d7db677f5b1aeeb")
addappid(228983)
addappid(228985)
addappid(229020)
