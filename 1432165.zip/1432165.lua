-- Lua provided by RyzenAPI
-- Game: addappid(1432165)

-- MAIN APPLICATION
addappid(1432165)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432165,0,"6de2b6165daec0be57751ce83f4643d466d5db49fa9bfa0ecdf645574dddefe5")
