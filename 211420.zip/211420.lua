-- Lua provided by SkyAPI 
-- Game: DARK SOULS™: Prepare To Die™ Edition
addappid(211420)
addappid(211421, 1, "f49080bced75e29fd2910bcd647816b25fb2240e476a5a72da281e8f1f5c0578")
addappid(211422, 1, "c468f053ed9820970515daf4a2c47b4d1c1e62ce0793061d974daf1bfa725b7a")
