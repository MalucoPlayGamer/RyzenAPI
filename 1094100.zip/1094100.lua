-- Lua provided by RyzenAPI
-- Game: 1094100

-- MAIN APPLICATION
addappid(1094100)
addappid(1094101)
addappid(1094105)
-- Game: addappid(1094100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094103,0,"a6758bd34dfa9a657c5f69ba3eac69452d3800c9d2b59f4d8b419a63e5c99ca0")
addappid(1094104,0,"b0e4160eea10aa6f977674950106d9af38c2be9bebac614eea677cc8d0eef537")
addappid(1094106,0,"36ed8fb700297dd2499dda5a3b023c94085daa5ea50b38803e8f3de7a3be9722")
addappid(1094107,0,"0b503055b7c4a686c940a33a46d2e8763fd2da2a12c4ce03de93c1c4da8d5448")
