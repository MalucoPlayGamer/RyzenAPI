-- Lua provided by RyzenAPI
-- Game: CARNAL

-- MAIN APPLICATION
addappid(1586290)
-- Game: addappid(1586290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586291, 1, "cf773e4ebd7a1ca1fbae3529c764f03fe3db6d27720f20d4eacd5a6278ca5de1")
