-- Lua provided by RyzenAPI
-- Game: Harold Halibut Demo

-- MAIN APPLICATION
addappid(2738590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738591, 1, "e944f24c689938affa3707d4975ba5faa7352aac4b161922c9701ef5d4583ec6")
