-- Lua provided by RyzenAPI
-- Game: 3106520

-- MAIN APPLICATION
addappid(3106520)
-- Game: addappid(3106520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106521, 1, "877067001585ecbdb6e188901f0661bee3d4210b1881dc1a940533dcbeb8f967")
