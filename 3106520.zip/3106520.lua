-- Lua provided by RyzenAPI
-- Game: EarthRoyale 3

-- MAIN APPLICATION
addappid(3106520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106521, 1, "877067001585ecbdb6e188901f0661bee3d4210b1881dc1a940533dcbeb8f967")

