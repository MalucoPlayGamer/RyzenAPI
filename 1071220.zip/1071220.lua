-- Lua provided by RyzenAPI
-- Game: After I met that catgirl, my questlist got too long!

-- MAIN APPLICATION
addappid(1071220)
addappid(1071221)
addappid(1071222)
addappid(1574810)
addappid(1913350)
addappid(1913351)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071223,0,"029690bc0b4a099e56e8f7a79effe963e7cd9818ea495f47567187968686c57d")
addappid(1537610,0,"d1800ed1611760b965a0dd1c742594eb1d72e883f55a0c7678864a5f2109c543")

