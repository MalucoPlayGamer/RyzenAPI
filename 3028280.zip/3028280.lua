-- Lua provided by RyzenAPI
-- Game: Drag and Drop Medieval

-- MAIN APPLICATION
addappid(3028280)
-- Game: addappid(3028280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028281, 1, "fb8aaa9c68f194aeec22d350bc42cc9a8c98be0e4f98b0efea5b105c2d49217d")
