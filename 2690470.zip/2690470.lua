-- Lua provided by RyzenAPI
-- Game: 2690470

-- MAIN APPLICATION
addappid(2690470)
-- Game: addappid(2690470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690470,0,"27abd38f896c7189e70bb89ae21214b76fcc95bf420e6268c964362bc022f6df")
