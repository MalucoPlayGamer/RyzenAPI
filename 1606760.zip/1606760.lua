-- Lua provided by RyzenAPI
-- Game: Game: Unlock the Block

-- MAIN APPLICATION
addappid(1606760)
-- Game: addappid(1606760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606761, 1, "301a224c91bc4148d858ed30f48afc2ef11e3b3fd9de0699479a6ac60424ec29")
