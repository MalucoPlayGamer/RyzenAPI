-- Lua provided by RyzenAPI
-- Game: 551190

-- MAIN APPLICATION
addappid(551190)
-- Game: addappid(551190)

-- MAIN APP DEPOTS / PACKAGES
addappid(551191, 1, "4b5790c2f791b319e32d31385a95205adbe5e8889363939babccccfb00c87407")
