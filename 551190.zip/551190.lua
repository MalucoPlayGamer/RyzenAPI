-- Lua provided by RyzenAPI
-- Game: 123 Slaughter Me Street 2

-- MAIN APPLICATION
addappid(551190)

-- MAIN APP DEPOTS / PACKAGES
addappid(551191, 1, "4b5790c2f791b319e32d31385a95205adbe5e8889363939babccccfb00c87407")
