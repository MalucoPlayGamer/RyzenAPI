-- Lua provided by SkyAPI 
-- Game: AppID 551190
addappid(551190)
addappid(551191, 1, "4b5790c2f791b319e32d31385a95205adbe5e8889363939babccccfb00c87407")
