-- Lua provided by SkyAPI 
-- Game: AppID 2597290
addappid(2597290)
addappid(2597291, 1, "036ee9c09a323d52334f395c0446538b8b0ed44d02fafb9010dbddb8cb1951d9")
addappid(2597293, 1, "555008a3e6e5a95223188dbf183870549ae641efd9170cae5ab5977e1e29dac0")
