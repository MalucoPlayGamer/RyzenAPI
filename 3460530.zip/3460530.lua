-- Lua provided by RyzenAPI
-- Game: Forsaken Island

-- MAIN APPLICATION
addappid(3460530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460531, 1, "1986ffbb83a1a0bf3d3ac623b50bda9df025bd9750a96bbc641278351042ac50")

