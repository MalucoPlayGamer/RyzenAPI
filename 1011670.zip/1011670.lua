-- Lua provided by RyzenAPI
-- Game: Totally Reliable Delivery Service

-- MAIN APPLICATION
addappid(1011670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011671, 1, "d23736dfc0877aa4088d86500401f1b65cc5d9467ecb33d9e5afba783b4eb5fc")
addappid(1011672, 1, "1f5d0b09fc2169c96ae4e2fb61f7486b9bb1266f5c83b79a8af5bc6b46dc12a1")
addappid(1011673, 1, "7c2fd0355b548710df053fa78871deb3801d2e3a0179a1f39efbedf3f461b495")

