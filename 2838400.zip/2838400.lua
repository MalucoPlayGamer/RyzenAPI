-- Lua provided by RyzenAPI
-- Game: Game: Squiggle Drop

-- MAIN APPLICATION
addappid(2838400)
-- Game: addappid(2838400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838401, 1, "dff95d0ee367e08f5817d2105a68fafac90f57b009ef89187683593cd0f3f6a1")
