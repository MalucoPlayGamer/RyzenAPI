-- Lua provided by RyzenAPI 
-- Game: Summer Sports Games
addappid(991760)
addappid(991761, 1, "b1093a3071e442fbae1497be01c490e50aed7d4a0858503a45a953ee15c72e6d")
addappid(991762, 1, "5d949de899238d47ba9f47ef654e6901b5d468f35c721ebd421f3ba865441e8d")
