-- Lua provided by RyzenAPI
-- Game: 1450940

-- MAIN APPLICATION
addappid(1450940)
-- Game: addappid(1450940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450940,0,"4d5f84cdca8447aee007042417155a5fa269dc371df14edf03402844ecb22805")
