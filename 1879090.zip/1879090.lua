-- Lua provided by RyzenAPI
-- Game: AppID 1879090

-- MAIN APPLICATION
addappid(1879090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879091, 1, "c0edcba11b3c8b87819b7c253ce780e4287e71c9b3528ead72eaecefe394cb1e")

