-- Lua provided by RyzenAPI 
-- Game: Celestial Project
addappid(1828700)
addappid(1828701, 1, "b652155322d527e2b72f84b2f8152c8bd7fb6d9dd0f4047379e320cb2c2a7c96")
addappid(1828702, 1, "a64b9d0ba967a1c0e67e75938985d11a67cf003e446a346e916138ca2bc2eb92")
