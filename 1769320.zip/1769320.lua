-- Lua provided by RyzenAPI
-- Game: Game: Athanasy

-- MAIN APPLICATION
addappid(1769320)
-- Game: addappid(1769320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769321, 1, "5ce81f58706146bf02be9a81be80c52c2460cab2d3493278ed89a5b609623ee5")
