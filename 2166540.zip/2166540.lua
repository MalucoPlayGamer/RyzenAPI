-- Lua provided by RyzenAPI
-- Game: Game: Candice DeBébé's Tantalising Tricks

-- MAIN APPLICATION
addappid(2166540)
-- Game: addappid(2166540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166541, 1, "ab4c51dd84e01c0c884c3ee3f5ba2d87135cc514bf884d88768b00cc01cfac8b")
addappid(2166542, 1, "955b07615d809e538177d70904c1350a91b28c9d922ccd483c2360d5da4c9160")
addappid(2166543, 1, "f1641cdf2d2dd3a52869887c36598de0752c330d87b2b11a4b3daf2fe7a3b749")
addappid(2166544, 1, "d02ae75fb6cda02e3bcef4bb18073e66e8578752dd437a40e017ce147d7bd922")
