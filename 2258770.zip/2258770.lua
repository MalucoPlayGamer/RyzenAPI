-- Lua provided by RyzenAPI
-- Game: The Shell Part I: Inferno

-- MAIN APPLICATION
addappid(2258770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258771, 1, "4a835a6c9b46f3df46b7bc1dc27df4e80c44190b8ea9316318db33dc6a69d9af")

