-- Lua provided by RyzenAPI
-- Game: Game: AppID 2259940

-- MAIN APPLICATION
addappid(2259940)
-- Game: addappid(2259940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259941, 1, "d28e9401dbe3d468a82842b0bcd6b980663533aaf6e82ab8b7b073cb898dd068")
