-- Lua provided by RyzenAPI
-- Game: addappid(1879340)

-- MAIN APPLICATION
addappid(1879340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879342,0,"96aa278fec11561ae7dc8d24b7d5e5b771171d9c92b020a118d5c1880d3b115f")
