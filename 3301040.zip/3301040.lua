-- Lua provided by RyzenAPI
-- Game: 3301040

-- MAIN APPLICATION
addappid(3301040)
-- Game: addappid(3301040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301041, 1, "84190082df56f693cafdd6436f3a8a7254b3293122ff320fbe559f6899c90d5d")
