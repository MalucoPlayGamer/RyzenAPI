-- Lua provided by RyzenAPI
-- Game: addappid(1433140)

-- MAIN APPLICATION
addappid(1433140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433141, 1, "333f806b286218fd908b89ab09f76d78ca28410ed7e235b95fbce1eddb1afa33")
