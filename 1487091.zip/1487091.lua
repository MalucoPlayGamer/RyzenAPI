-- Lua provided by RyzenAPI
-- Game: addappid(1487091)

-- MAIN APPLICATION
addappid(1487091)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487091,0,"9a0d02c15d614e076b94c212ba487834aeaee38533c7c21cf250ef7c57fb2ca4")
