-- Lua provided by RyzenAPI
-- Game: Neptunia Shooter

-- MAIN APPLICATION
addappid(1037590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037591, 1, "f9e9a18077b2e3ef615b6bf5a59d0a61c9cc29f9c836a1178c4319d5ff4f364e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
