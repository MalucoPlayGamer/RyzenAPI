-- Lua provided by RyzenAPI
-- Game: Pricia Defense

-- MAIN APPLICATION
addappid(2162790)
addappid(2367240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162792,0,"dfc2aadacc2b61785f560304c5bcd0c361732f6dc26ca77237f7b227e461fdbc")

