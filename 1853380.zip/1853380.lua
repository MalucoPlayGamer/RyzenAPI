-- Lua provided by RyzenAPI 
-- Game: FOONDA
addappid(1853380)
addappid(1853381, 1, "9644485056b2f4ea05bb6e2585383bb759f19d3318de1d4654ff7d220271a561")
