-- Lua provided by RyzenAPI
-- Game: Game: FOONDA

-- MAIN APPLICATION
addappid(1853380)
-- Game: addappid(1853380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853381, 1, "9644485056b2f4ea05bb6e2585383bb759f19d3318de1d4654ff7d220271a561")
