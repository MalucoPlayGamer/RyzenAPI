-- Lua provided by SkyAPI 
-- Game: AppID 1834540
addappid(1834540)
addappid(1834541, 1, "b25f0427f5b65396a1ebf8f2418735e4cefd86fbc83d23cf68ddf479c3301a7f")
