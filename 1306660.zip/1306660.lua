-- Lua provided by RyzenAPI 
-- Game: 迷雾之夏 Demo
addappid(1306660)
addappid(1306661, 1, "cb2a0fbe51de94fbe3c3443216696e8c7a452181ce48962111c4c66e89bcea43")
