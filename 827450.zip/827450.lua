-- Lua provided by SkyAPI 
-- Game: InkSplosion
addappid(827450)
addappid(827451, 1, "0f28f277638041c906e226f3ad4e6c6f4b36b384deb6c9c5c63d801bba5b628d")
