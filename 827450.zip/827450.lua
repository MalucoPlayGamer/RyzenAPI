-- Lua provided by RyzenAPI
-- Game: InkSplosion

-- MAIN APPLICATION
addappid(827450)

-- MAIN APP DEPOTS / PACKAGES
addappid(827451, 1, "0f28f277638041c906e226f3ad4e6c6f4b36b384deb6c9c5c63d801bba5b628d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
