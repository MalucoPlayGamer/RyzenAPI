-- Lua provided by RyzenAPI
-- Game: Game: InkSplosion

-- MAIN APPLICATION
addappid(827450)
-- Game: addappid(827450)

-- MAIN APP DEPOTS / PACKAGES
addappid(827451, 1, "0f28f277638041c906e226f3ad4e6c6f4b36b384deb6c9c5c63d801bba5b628d")
