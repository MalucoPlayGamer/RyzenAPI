-- Lua provided by RyzenAPI
-- Game: addappid(689900)

-- MAIN APPLICATION
addappid(689900)

-- MAIN APP DEPOTS / PACKAGES
addappid(689903,0,"bd61b547574d097c22b4e8d80a0ac72c9df7ab0615b4af4071b22622b2f7fd38")
