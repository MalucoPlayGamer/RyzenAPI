-- Lua provided by RyzenAPI
-- Game: AppID 434480

-- MAIN APPLICATION
addappid(434480)

-- MAIN APP DEPOTS / PACKAGES
addappid(434481, 1, "4618e03ec30ad6a11661337dc190eafaed2eb9eb9d80ea63fd055844e9e2a9b0")

