-- Lua provided by RyzenAPI
-- Game: Monuments Renovator

-- MAIN APPLICATION
addappid(1257280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257281, 1, "d9cf2f8bcf22b85050c58ba98aee10e43ab69ac29706423ffc12b6ed4ac72e07")
