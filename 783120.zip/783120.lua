-- Lua provided by RyzenAPI
-- Game: Hello Lady!

-- MAIN APPLICATION
addappid(783120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(783121, 1, "726e460738e68454f6761bcc92e53fc2b3eb817587c08e31e4f968fb6b2cc271")
addappid(783122, 1, "f8f2637b3fabc346861888a678509b167649e523f9214a5dc632b749cfa3cecb")
addappid(783123, 1, "094e79dab538761e8b6588bf3b2dbf9679ad95eae1d9d5082eec1a0ed834687e")

