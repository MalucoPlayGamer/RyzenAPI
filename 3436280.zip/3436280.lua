-- 3436280's Lua and Manifest Created by Hubcap Manifest
-- Glamour Kaleidoscope
-- Created: August 21, 2026 at 01:46:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3436280, 1, "bd5e2222ab32049aefc24141e9e5f04f320d80638a06a006e1461ca63740f9a6") -- Glamour Kaleidoscope
-- MAIN APP DEPOTS
addappid(3436281, 1, "37b98b0feb7c17c8dfec87b981d89b0684bcb529c7884bb96577603d218889d7") -- Depot 3436281
setManifestid(3436281, "8549383308992896193", 1804595499)