-- Lua provided by SkyAPI 
-- Game: AppID 1129210
addappid(1129210)
addappid(1129211, 1, "bf12bc9190c0cd00017e8a8bdede5cb8e1008c7f571dbc3f65b7bd0bf00527e4")
