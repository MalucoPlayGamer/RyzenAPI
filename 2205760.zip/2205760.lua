-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Black Friday Special All in Pack

-- MAIN APPLICATION
addappid(2205760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205761, 1, "841b9fb2bb7c15bee1d86ffd95de4c6bc8da9cf9ee406b949f88e64b1bb18fb9")
addappid(2205762, 1, "d14a8aa1777e2cdffc44edc5fe6895a5aa42c75380407cf37459b8e765652b58")
