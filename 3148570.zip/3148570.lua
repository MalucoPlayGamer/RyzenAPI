-- Lua provided by RyzenAPI
-- Game: Ninjam! Demo

-- MAIN APPLICATION
addappid(3148570)
-- Game: addappid(3148570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148571, 1, "b37ca1c8c4a1bac95a065106d50e9758c418afcbf3510118a83b409eaf2fec51")
