-- Lua provided by RyzenAPI
-- Game: New Gundam Breaker

-- MAIN APPLICATION
addappid(738530)

-- MAIN APP DEPOTS / PACKAGES
addappid(738531, 1, "280c135e5a7484d58e9ae159cd748af9e5d1e858346bf15a0b968d0a7a3b58a5")
addappid(874321, 0, "dcc4dce00d21f701c8a02b487c43d770473d0631e1a96294ce740d04a0f2b370")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(874320)
