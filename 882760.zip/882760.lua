-- Lua provided by RyzenAPI
-- Game: Nom Nom Apocalypse

-- MAIN APPLICATION
addappid(882760)

-- MAIN APP DEPOTS / PACKAGES
addappid(882761, 1, "521de09e50496e4e232879cde3ec7a064644a09d963ac1c85a01592631e8203c")
