-- Lua provided by RyzenAPI 
-- Game: High Strategy: Urukon Demo
addappid(1334990)
addappid(1334991, 1, "58c90cb65788122ad4f3181114a29d0474d8ee48cbd70dcd10754e0277e74f82")
