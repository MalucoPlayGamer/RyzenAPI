-- Lua provided by RyzenAPI 
-- Game: Crucible Trails : Initial Rupture
addappid(707560)
addappid(707561, 1, "77a330235de67291a719b9418f2f5123d79ad15573b09316dc1f435084804df9")
addappid(707562, 1, "17188fa71d61207fd87dd5647e2b478947d07630334825462c22aad6c76181b5")
addappid(707563, 1, "a69bc0e980663bca0494bb86794784cbc6f26ad01b95d3feff7f5271dba92d71")
