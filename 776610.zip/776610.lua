-- Lua provided by RyzenAPI
-- Game: AppID 776610

-- MAIN APPLICATION
addappid(776610)
-- Game: addappid(776610)

-- MAIN APP DEPOTS / PACKAGES
addappid(776611, 1, "c3b8d5c80be06396b9c90d8f3633e775864f3ac87623d66b33e056bb8529247e")
