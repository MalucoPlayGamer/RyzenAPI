-- Lua provided by RyzenAPI 
-- Game: AppID 1436900
addappid(1436900)
addappid(1436901, 1, "99a9d99a4b0c7aee3ff4fb9624bf45754a39e2e30c75f471ec3cec41a6abb499")
