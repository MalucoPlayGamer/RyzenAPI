-- Lua provided by RyzenAPI
-- Game: Witch's Garden

-- MAIN APPLICATION
addappid(2347380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347381, 1, "0ace6a68df6b2d06443c2c430e08ab6079f1b48d774df71490341d67cf368ce5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
