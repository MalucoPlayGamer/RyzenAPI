-- Lua provided by RyzenAPI
-- Game: addappid(2347380)

-- MAIN APPLICATION
addappid(2347380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347381, 1, "0ace6a68df6b2d06443c2c430e08ab6079f1b48d774df71490341d67cf368ce5")
