-- Lua provided by SkyAPI 
-- Game: Witch's Garden
addappid(2347380)
addappid(2347381, 1, "0ace6a68df6b2d06443c2c430e08ab6079f1b48d774df71490341d67cf368ce5")
