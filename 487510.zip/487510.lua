-- Lua provided by RyzenAPI
-- Game: Game: fault SILENCE THE PEDANT Demo

-- MAIN APPLICATION
addappid(487510)
-- Game: addappid(487510)

-- MAIN APP DEPOTS / PACKAGES
addappid(487511, 1, "d5f2fc5f678853461cbe74475f473395ea520c9a64436b2a5df8a5b2036cdbb3")
