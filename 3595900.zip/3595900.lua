-- Lua provided by RyzenAPI
-- Game: addappid(3595900)

-- MAIN APPLICATION
addappid(3595900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595901, 1, "317db518fe9c791f520500ff80a594bd5c5ae74c9cd31a30002c6a081360ed45")
