-- Lua provided by SkyAPI 
-- Game: AppID 2832070
addappid(2832070)
addappid(2832071, 1, "82f35d4b09de1f4f4244e4940a1672787917292a59890359ca7a85cf638ecd04")
