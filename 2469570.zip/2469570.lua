-- Lua provided by RyzenAPI
-- Game: 2469570

-- MAIN APPLICATION
addappid(2469570)
-- Game: addappid(2469570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469571, 1, "d8ae2a1c3ce15e679b1bb45afc0afdf4e9f986dc9b06ee0e03d9d46e16d2008b")
