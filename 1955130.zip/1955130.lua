-- Lua provided by RyzenAPI 
-- Game: Bugsnax Soundtrack
addappid(1955130)
addappid(1955131, 1, "5cb34de0e8ac617025a8478b7b046ca00686007b4914633d043432be43550333")
addappid(1955132, 1, "22fb5c973dae397cf93dfae45716526c7a787c4ced408d52ab72e48694cfb744")
