-- Lua provided by RyzenAPI
-- Game: Idle Town Billionaire

-- MAIN APPLICATION
addappid(3422900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422901, 1, "7ae9113774226eeaec8c7b9dce2731fd58fe68e6f6cc97e34b6c32155ff442e1")
addappid(3422902, 1, "5ab1aea6045cb6ab27fc457a87bf05d8b13576e1408b4dc4aa55f66bd674043d")

