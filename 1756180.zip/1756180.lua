-- Lua provided by RyzenAPI
-- Game: CARNAGE OFFERING

-- MAIN APPLICATION
addappid(1756180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1756181, 1, "f674ed4ec4df45a1601705d18a4c93fab7239a649223b82ad3853064e19c7189")

