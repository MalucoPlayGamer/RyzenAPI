-- Lua provided by RyzenAPI
-- Game: Ruiga Pirates

-- MAIN APPLICATION
addappid(2461580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461581, 1, "1d48c6a6d09e6796e56f6c0ba85fea83166ec83e426c9e4f97f9dc6ae2817e54")

