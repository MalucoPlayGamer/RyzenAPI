-- Lua provided by RyzenAPI
-- Game: Game: Mind Echoes: Remnants of the Past Collector's Edition

-- MAIN APPLICATION
addappid(3812230)
-- Game: addappid(3812230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3812231, 1, "75f45574fb0ae83a6a9a3974427bd4f43a4481a68d5adf83451e1dac53edd910")
addappid(3823230, 0, "c801316a9aba4634b514e0128bf519bd6afd6aace1dbfed3625ef1c0145938a5")
