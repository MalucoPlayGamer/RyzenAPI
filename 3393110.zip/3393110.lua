-- Lua provided by RyzenAPI
-- Game: AION 2

-- MAIN APPLICATION
addappid(3393110)
