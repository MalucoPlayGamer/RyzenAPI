-- Lua provided by RyzenAPI
-- Game: SYNDUALITY Echo of Ada

-- MAIN APPLICATION
addappid(1245480)
addappid(2963460)
addappid(2963470)
addappid(2963480)
addappid(4536490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1245481, 1, "c5e7a814d9d7df873a2dc41b6e1ec96bb1ce1d98ee7ab6b5c9dee96e6c6592c5")

