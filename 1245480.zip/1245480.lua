-- Lua provided by RyzenAPI
-- Game: addappid(1245480)

-- MAIN APPLICATION
addappid(1245480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245481, 1, "c5e7a814d9d7df873a2dc41b6e1ec96bb1ce1d98ee7ab6b5c9dee96e6c6592c5")
