-- Lua provided by RyzenAPI
-- Game: A Mass of Dead

-- MAIN APPLICATION
addappid(269630)

-- MAIN APP DEPOTS / PACKAGES
addappid(269631, 1, "ea332a5ee9b1152f952024bb01a7821a94ccb81975be396fb4d2884f0337c158")
addappid(269632, 1, "73b6f16fe74e1747b38e97ac6312d4e946c7abe521e0b5243e48298743b9e764")
addappid(269633, 1, "a9aa863d7302029a98cb7a664d356fa02862d7504cfa275e60bf8ce09b5d6eae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
