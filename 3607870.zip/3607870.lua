-- Lua provided by RyzenAPI
-- Game: Cassette Beasts Acoustic Sessions

-- MAIN APPLICATION
addappid(3607870)
-- Game: addappid(3607870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3607871, 1, "648864c8783b1e1adab412d9b0f2649d687eba978079365d5ec189a7f779a040")
addappid(3607872, 1, "b68593462715e46190fd1f1f3e2efd8ae0fc0cd8725877a0f3a4bc08b2e35aae")
