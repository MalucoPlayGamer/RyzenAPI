-- Lua provided by RyzenAPI
-- Game: NightClub Simulator

-- MAIN APPLICATION
addappid(2729480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729481, 1, "a888843dc7baaa68b8424ca0216fce2c36531da9f8266b9dbd656f37cf619746")
