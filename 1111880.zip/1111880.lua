-- Lua provided by RyzenAPI
-- Game: addappid(1111880)

-- MAIN APPLICATION
addappid(1111880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111881, 1, "daf9996dee634a52fdeebeecc27ef739eb2c5f7736bff87653df0183312a2ee1")
