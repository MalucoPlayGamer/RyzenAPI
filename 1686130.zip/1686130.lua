-- Lua provided by RyzenAPI
-- Game: Game: AppID 1686130

-- MAIN APPLICATION
addappid(1686130)
-- Game: addappid(1686130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686131, 1, "b8160440a994bd1ff58d19cd3406ff8d6c3985f287a78a288ce23564083d1287")
