-- Lua provided by SkyAPI 
-- Game: AppID 1686130
addappid(1686130)
addappid(1686131, 1, "b8160440a994bd1ff58d19cd3406ff8d6c3985f287a78a288ce23564083d1287")
