-- Lua provided by RyzenAPI
-- Game: Game: Metal Bringer

-- MAIN APPLICATION
addappid(2334170)
-- Game: addappid(2334170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334171, 1, "6b4aeb7d33b96812418e9faca0fbb58ecf40aba22bbb22d599c6136bb4e6422c")
