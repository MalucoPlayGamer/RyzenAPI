-- Lua provided by RyzenAPI
-- Game: Bilkins' Folly

-- MAIN APPLICATION
addappid(1526370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526371, 1, "5717c03b320246f5f629f2cd795fa5f311dfb366777dc3ce8a8ee98be8c99b18")
