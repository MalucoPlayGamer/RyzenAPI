-- Lua provided by RyzenAPI
-- Game: BeachRun

-- MAIN APPLICATION
addappid(1970730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970731, 1, "b37a2432136c4fda0b763ed2b0009874c73e049c15befa9d062cb4f4fc8dad47")

