-- Lua provided by SkyAPI 
-- Game: BeachRun
addappid(1970730)
addappid(1970731, 1, "b37a2432136c4fda0b763ed2b0009874c73e049c15befa9d062cb4f4fc8dad47")
