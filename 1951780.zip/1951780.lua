-- Lua provided by RyzenAPI
-- Game: Jumping Jazz Cats

-- MAIN APPLICATION
addappid(1951780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951781, 1, "1a2665d2ccc26b6fc849acae18c8932f9d802794a174a7eeaa8addb988e0c1f7")
addappid(3558441, 0, "067a0178f8171cdd5d9ebecf10273ea54bcc743e0fde33295b3bfc85b801e477")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3558440)
