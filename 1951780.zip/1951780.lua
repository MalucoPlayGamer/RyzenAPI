-- Lua provided by RyzenAPI 
-- Game: Jumping Jazz Cats
addappid(1951780)
addappid(1951781, 1, "1a2665d2ccc26b6fc849acae18c8932f9d802794a174a7eeaa8addb988e0c1f7")
addappid(3558441, 0, "067a0178f8171cdd5d9ebecf10273ea54bcc743e0fde33295b3bfc85b801e477")
