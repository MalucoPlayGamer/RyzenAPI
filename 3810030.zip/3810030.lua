-- Lua provided by RyzenAPI
-- Game: addappid(3810030)

-- MAIN APPLICATION
addappid(3810030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3810031, 1, "fdf18df527a55ea99eb8c19117f3b5612654e4cecebee14b552648b76ca18b97")
