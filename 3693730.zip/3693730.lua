-- Lua provided by RyzenAPI
-- Game: Equate 8

-- MAIN APPLICATION
addappid(3693730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3693731, 1, "e1f989a7983be64acd9b1e4d99e19f222ee3603361590c2b9dcda3ac103852ac")
