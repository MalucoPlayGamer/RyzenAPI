-- Lua provided by SkyAPI 
-- Game: Kortstrid
addappid(2406990)
addappid(2406991, 1, "f0cf9456b9bfd5476d829bd2f0eaf19c1e9cc662a4b2d5075b309186d1838732")
