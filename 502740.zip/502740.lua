-- Lua provided by RyzenAPI
-- Game: Game: 50 years

-- MAIN APPLICATION
addappid(502740)
-- Game: addappid(502740)

-- MAIN APP DEPOTS / PACKAGES
addappid(502741, 1, "a0000faee10587632d559e6b4e4cc759af50a7a3e73ddd3679fe0a5fc972b636")
