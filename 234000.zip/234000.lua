-- Lua provided by RyzenAPI
-- Game: Superfrog HD

-- MAIN APPLICATION
addappid(234000)

-- MAIN APP DEPOTS / PACKAGES
addappid(234001, 1, "129383c3e79ec8b06b4b06ec4abb760049f07f588d6eac8bd859c5a3f25f9150")
addappid(234002, 1, "976cd29e9a055ede5862cf9dea2394184b634d6bd882c116c4da3a794e05128c")
addappid(234003, 1, "17e5a65589e428d372fed0cb73c5e5a7199afe8c6d9e10e995726570b6ca51b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
