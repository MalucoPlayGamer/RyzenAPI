-- Lua provided by RyzenAPI
-- Game: Deckmate! Playtest

-- MAIN APPLICATION
addappid(2402430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402431, 1, "d753a4cb904a5b818312d7a9de3e8c2661d2405f5cd855809bf469ad6de69ff6")
