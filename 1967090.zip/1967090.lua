-- Lua provided by RyzenAPI
-- Game: Game: Mythos

-- MAIN APPLICATION
addappid(1967090)
-- Game: addappid(1967090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967091, 1, "0e3e0d87ab62a8534afc6fc309254e2074932c6fbbdacf189ee0aecd4138d2f0")
