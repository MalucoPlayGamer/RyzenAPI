-- Lua provided by RyzenAPI
-- Game: No King No Kingdom - King of Angels

-- MAIN APPLICATION
addappid(1679900)
-- Game: addappid(1679900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679900,0,"92769840dbb3f6b1c01b8a48b74540089646d41b789873c10b1b369f2dd17aec")
