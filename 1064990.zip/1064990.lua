-- Lua provided by RyzenAPI
-- Game: Game: Thunder Paw

-- MAIN APPLICATION
addappid(1064990)
-- Game: addappid(1064990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064991, 1, "f0abda383f079abcf3406f35fb6dd5b56d37cae6a38777e6d5f7d9d629b23aa3")
