-- Lua provided by RyzenAPI 
-- Game: Thunder Paw
addappid(1064990)
addappid(1064991, 1, "f0abda383f079abcf3406f35fb6dd5b56d37cae6a38777e6d5f7d9d629b23aa3")
