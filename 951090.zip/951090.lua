-- Lua provided by RyzenAPI
-- Game: addappid(951090)

-- MAIN APPLICATION
addappid(951090)

-- MAIN APP DEPOTS / PACKAGES
addappid(951091, 1, "594b8504df9f2e7fe94f7fa6d0b5ae3afdb11645bfa056ae7e07944e6366db3a")
