-- Lua provided by RyzenAPI
-- Game: Xu Zhu - Officer Ticket / 許褚使用券

-- MAIN APPLICATION
addappid(956727)

-- MAIN APP DEPOTS / PACKAGES
addappid(956727,0,"189278a8aa472f4f4b83f94f779f481e838e25b39127f67061885fbe08b82ce5")
