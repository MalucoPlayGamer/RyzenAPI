-- Lua provided by RyzenAPI
-- Game: Dead End Aegis

-- MAIN APPLICATION
addappid(1835830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1835831, 1, "0d5b0de2e017a17cc80f0f867ba0f0bd4de8c14ef7a89301150f57f55ceb1e80")
addappid(1835832, 1, "c116b1780c23fe76a2558baed077e8e3892cd8b757fafe31fbf312e49c5cddd8")

