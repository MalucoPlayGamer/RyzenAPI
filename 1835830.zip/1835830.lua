-- Lua provided by RyzenAPI 
-- Game: Dead End Aegis
addappid(1835830)
addappid(1835831, 1, "0d5b0de2e017a17cc80f0f867ba0f0bd4de8c14ef7a89301150f57f55ceb1e80")
addappid(1835832, 1, "c116b1780c23fe76a2558baed077e8e3892cd8b757fafe31fbf312e49c5cddd8")
