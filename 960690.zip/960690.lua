-- Lua provided by RyzenAPI
-- Game: Game: AppID 960690

-- MAIN APPLICATION
addappid(960690)
-- Game: addappid(960690)

-- MAIN APP DEPOTS / PACKAGES
addappid(960691, 1, "7bec208e6b593809db415224da56534ebb80bb9bdd5709fcb4ddf156b97ad5eb")
addappid(960692, 1, "7cdff2bdc3bc1bc390850cc64cc4dfbcfa18c6fda49d018cf8b6047e584f16fc")
addappid(960693, 1, "caff1b01242d8981a13feb820575e152abf45b41db57c7087a20b4d1c9483afd")
addappid(960694, 1, "24b4e40c6b2064c8b9e1062106d1a63c2d2461a282dbfa9774d3e3fb68ef5a59")
