-- Lua provided by RyzenAPI
-- Game: 442810

-- MAIN APPLICATION
addappid(442810)
-- Game: addappid(442810)

-- MAIN APP DEPOTS / PACKAGES
addappid(442811, 1, "ad0a7083d3721a52271e89c0b9edd936ff8d5cfe0e852453de108471f248b652")
