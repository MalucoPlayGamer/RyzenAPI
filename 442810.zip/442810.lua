-- Lua provided by RyzenAPI 
-- Game: AppID 442810
addappid(442810)
addappid(442811, 1, "ad0a7083d3721a52271e89c0b9edd936ff8d5cfe0e852453de108471f248b652")
