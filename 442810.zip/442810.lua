-- Lua provided by RyzenAPI
-- Game: AppID 442810

-- MAIN APPLICATION
addappid(442810)
addappid(486200)
addappid(486530)
addappid(486560)
addappid(561990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(442811, 1, "ad0a7083d3721a52271e89c0b9edd936ff8d5cfe0e852453de108471f248b652")

