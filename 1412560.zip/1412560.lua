-- Lua provided by RyzenAPI
-- Game: 1412560

-- MAIN APPLICATION
addappid(1412560)
-- Game: addappid(1412560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412561, 1, "5036e9d66825d129c929dca2b40c6be277cc2e7a0d43e8f4823d8657fe04b53c")
