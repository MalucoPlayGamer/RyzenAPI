-- Lua provided by RyzenAPI
-- Game: Game: GT Manager

-- MAIN APPLICATION
addappid(2457030)
-- Game: addappid(2457030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457031, 1, "3a54e14b6561231228eb443ed98e756f297d3783f89778e8e2800ee27bc83946")
