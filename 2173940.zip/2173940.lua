-- Lua provided by RyzenAPI
-- Game: AppID 2173940

-- MAIN APPLICATION
addappid(2173940)
-- Game: addappid(2173940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173941, 1, "14d7f5c639d7c9fa3d57fc2059bce9fb64e63d84431342a95ae8408367da8824")
