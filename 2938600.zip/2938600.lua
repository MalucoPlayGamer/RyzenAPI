-- Lua provided by RyzenAPI
-- Game: 2938600

-- MAIN APPLICATION
addappid(2938600)
-- Game: addappid(2938600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938601, 1, "a56059b4fbb1aced6192cfa40571078f1e47b2dd05791ad57bfceb5a8ac1a7e5")
