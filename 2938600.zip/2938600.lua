-- Lua provided by RyzenAPI
-- Game: Escape Room Collection C2 Psychological Horror

-- MAIN APPLICATION
addappid(2938600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938601, 1, "a56059b4fbb1aced6192cfa40571078f1e47b2dd05791ad57bfceb5a8ac1a7e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
