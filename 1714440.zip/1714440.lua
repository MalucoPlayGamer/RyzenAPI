-- Lua provided by RyzenAPI
-- Game: 1714440

-- MAIN APPLICATION
addappid(1714440)
-- Game: addappid(1714440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714441, 1, "3d83800ddfcb3abf88945c06d8e9d5ed27df883afba099f7f42409d5e04d243f")
