-- Lua provided by RyzenAPI
-- Game: Football Manager 2017

-- MAIN APPLICATION
addappid(482730)

-- MAIN APP DEPOTS / PACKAGES
addappid(482731, 1, "80d134028e015f69e578720f7af54e44fbbf69bbb9fcd4590a060c7933e433c3")
addappid(482732, 1, "df4f2e7cf457e900b45c58322c0fc32f6013b683200ef0ec0b67375c73ab0f94")
addappid(482733, 1, "8842e6fc5e094165b49370799efa174da2b3dd9291bc97fa8234d7c342ebee6d")
addappid(482734, 1, "cb232ff0e2472633624c8c32e5cb18060e8801f9c3177391aeb92386cba0cf0e")
addappid(482735, 1, "3a00ee560369bc77e2885f76acaa185fd482ab69d6c805973de14486ae6ed634")
addappid(482736, 1, "2eb43d4fcfeb65b983f54e04b01fd503b48cd797a990015145fba71758f349bd")
addappid(482737, 1, "c16ce2a1669f9a35f4c4851d127b87d37e3dbbef0f51866ece5009919724f775")
addappid(482738, 1, "765a1df6fa13f5ab992e83a3469c02635b7fd0b20c1329f226dfec52f6ffcffc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(489860)
