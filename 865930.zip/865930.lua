-- Lua provided by RyzenAPI
-- Game: 865930

-- MAIN APPLICATION
addappid(865930)
addappid(865931)

-- MAIN APP DEPOTS / PACKAGES
addappid(865932,0,"2d3fd322793c4e7092d2e5fcad80cbf641e611164dea63b55890437fae3a11a7")

