-- Lua provided by RyzenAPI
-- Game: AppID 395980

-- MAIN APPLICATION
addappid(395980)
-- Game: addappid(395980)

-- MAIN APP DEPOTS / PACKAGES
addappid(395981, 1, "1258fccaca166f36ecbab7d685d18692f966380b41cc396150f2553eb1073904")
