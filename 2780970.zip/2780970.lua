-- Lua provided by RyzenAPI
-- Game: Game: AppID 2780970

-- MAIN APPLICATION
addappid(2780970)
-- Game: addappid(2780970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780971, 1, "666bf071c92f192cec3a80cccf649e09dd188d73f7d94315e65717941b343c7e")
