-- Lua provided by RyzenAPI
-- Game: 774261

-- MAIN APPLICATION
addappid(774261)
-- Game: addappid(774261)

-- MAIN APP DEPOTS / PACKAGES
addappid(774262, 1, "3d2c7c99711e3b78096dea524f7a69a3c184890590ef0383f0e6cc4c3685487c")
