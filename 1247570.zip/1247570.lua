-- Lua provided by RyzenAPI
-- Game: Game: Expedition Zero

-- MAIN APPLICATION
addappid(1247570)
-- Game: addappid(1247570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247571, 1, "da9a3ba6bdaebf091290d65b73a0175e5aba7dc29155d9a6ebd05aa2a19c5bfa")
