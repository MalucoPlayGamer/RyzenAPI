-- Lua provided by RyzenAPI
-- Game: Expedition Zero

-- MAIN APPLICATION
addappid(1247570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247571, 1, "da9a3ba6bdaebf091290d65b73a0175e5aba7dc29155d9a6ebd05aa2a19c5bfa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
