-- Lua provided by RyzenAPI
-- Game: Anglerfish

-- MAIN APPLICATION
addappid(1613670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613671, 1, "ef5e07f4a10024500b7e9b856049db9bdab2289dca9ada6dc240973ce65255b2")

