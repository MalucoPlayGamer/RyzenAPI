-- Lua provided by RyzenAPI
-- Game: AppID 655140

-- MAIN APPLICATION
addappid(655140)
-- Game: addappid(655140)

-- MAIN APP DEPOTS / PACKAGES
addappid(655141, 1, "6f86d8e45515ced77186836c7d9990adebb1b3605239c86a82e51180ac10880b")
