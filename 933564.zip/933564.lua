-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933564)

-- MAIN APP DEPOTS / PACKAGES
addappid(933564,0,"62a21196bb78f96ae45dfec7efc927d780c5cfbd46dd22f85a1d8ec50de249ce")
addtoken(933564,4925623087674307623)

