-- Lua provided by RyzenAPI
-- Game: Game: 风起苍岚

-- MAIN APPLICATION
addappid(2441250)
-- Game: addappid(2441250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441251, 1, "c229f2bae341eab4ae99d55d96eff266c8af33471f6ff5035c7ebf0542d2f2cf")
