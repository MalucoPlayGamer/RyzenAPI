-- Lua provided by RyzenAPI
-- Game: Game: SAEKO: Giantess Dating Sim

-- MAIN APPLICATION
addappid(2492120)
-- Game: addappid(2492120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492121, 1, "849bcba9e2ea253c7a784a499840aad2878e95e283b90c3362272b3f330c5837")
