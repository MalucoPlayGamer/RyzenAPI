-- Lua provided by RyzenAPI
-- Game: Auto Immune Demo

-- MAIN APPLICATION
addappid(2471360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471361, 1, "e6bf19457e417262af6d021e42675b9d8d6e5d20849309ac458bb7757c8c2926")
