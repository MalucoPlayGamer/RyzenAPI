-- Lua provided by RyzenAPI
-- Game: Fallen / Brand New World

-- MAIN APPLICATION
addappid(3561400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561401, 1, "13e00693bccd0e61ec8883ae5d4eaa9dd55a9cefbc8e58d062ac7d6072106a5b")
