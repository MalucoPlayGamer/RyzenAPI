-- Lua provided by RyzenAPI
-- Game: TASMON: Taskbar Monsters

-- MAIN APPLICATION
addappid(4985540)
