-- Lua provided by RyzenAPI
-- Game: TASMON: Taskbar Monsters

-- MAIN APPLICATION
addappid(4985540)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5024690)
addappid(5024700)
addappid(5024710)
addappid(5024750)
