-- Lua provided by RyzenAPI
-- Game: Game: AppID 1669320

-- MAIN APPLICATION
addappid(1669320)
-- Game: addappid(1669320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669321, 1, "9f211165c83d14cd29e42a4e5caaac3b339a4a844d2ec8e7e601361fc938e261")
