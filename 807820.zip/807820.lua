-- Lua provided by RyzenAPI
-- Game: Mystery Village: Shards of the Past

-- MAIN APPLICATION
addappid(807820)

-- MAIN APP DEPOTS / PACKAGES
addappid(807821, 1, "2c22f5a2545607f12cfed7ee97ab1a4d9496355c0321df8cbdad56ebed2bd412")
