-- Lua provided by RyzenAPI
-- Game: Hydroactive

-- MAIN APPLICATION
addappid(741930)

-- MAIN APP DEPOTS / PACKAGES
addappid(741931, 1, "8ed497165f1fc1d1065aefa1edf1e3218bcaa5ca1e9fb807389afcc1c279323d")

