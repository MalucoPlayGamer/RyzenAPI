-- Lua provided by RyzenAPI
-- Game: AppID 1016860

-- MAIN APPLICATION
addappid(1016860)
-- Game: addappid(1016860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016861, 1, "de732dc3acef513c078a021811841850fa73f0cfffe605d4dd2e472f7e835e16")
