-- Lua provided by SkyAPI 
-- Game: The Dead End
addappid(1342060)
addappid(1342061, 1, "e927cd62c62423bb41a029aeeef6d9de619b1ad2b07ae00f333693fa3bf5fc62")
addappid(1342062, 1, "b1772b5c4d7ae860e029433f39ee6d3697d6bd453a4b82be3348e386a7f8e7ba")
addappid(1342063, 1, "33cee24561016eacae5a22f173f296556a50e44e54c6b40e9a0282f0598f001e")
