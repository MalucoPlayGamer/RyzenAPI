-- Lua provided by RyzenAPI
-- Game: addappid(1156380)

-- MAIN APPLICATION
addappid(1156380)
addappid(1156381)
addappid(1156382)
addappid(1156384)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156383,0,"6cfb00de1b272be671092138759c4430de6cb52207019293b0bc9f11029805bf")
