-- Lua provided by RyzenAPI
-- Game: Game: 你能活到第几集

-- MAIN APPLICATION
addappid(3581210)
-- Game: addappid(3581210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3581211, 1, "1e61ad14aa34237d96e02b1c8f67526e00d25fa5ec59870b5290f8162e698afd")
