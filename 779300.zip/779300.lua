-- Lua provided by RyzenAPI 
-- Game: AppID 779300
addappid(779300)
addappid(779301, 1, "0bb8fe32872533df397eb5792b756dc3690348249232e9207ac5dbc7e19ee462")
