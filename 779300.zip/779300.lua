-- Lua provided by RyzenAPI
-- Game: Game: AppID 779300

-- MAIN APPLICATION
addappid(779300)
-- Game: addappid(779300)

-- MAIN APP DEPOTS / PACKAGES
addappid(779301, 1, "0bb8fe32872533df397eb5792b756dc3690348249232e9207ac5dbc7e19ee462")
