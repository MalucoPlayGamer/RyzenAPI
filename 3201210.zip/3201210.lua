-- Lua provided by RyzenAPI
-- Game: Game: Chaos Entropy

-- MAIN APPLICATION
addappid(3201210)
-- Game: addappid(3201210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201211, 1, "e4a34de6cde492687b3c7040c7f7e2b7d8013efc1104785d6322373834ec1705")
