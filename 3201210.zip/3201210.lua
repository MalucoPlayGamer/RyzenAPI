-- Lua provided by RyzenAPI 
-- Game: Chaos Entropy
addappid(3201210)
addappid(3201211, 1, "e4a34de6cde492687b3c7040c7f7e2b7d8013efc1104785d6322373834ec1705")
