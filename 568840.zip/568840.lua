-- Lua provided by SkyAPI 
-- Game: GunHero
addappid(568840)
addappid(568841, 1, "bddf04d683187ab20e4717f00e143e56269701ecdeda31ab4a9531393d9219bc")
addappid(568842, 1, "e5ae59a34f1061365a635435c1f7f15e094c6580e64630f5477847bba6769da4")
