-- Lua provided by RyzenAPI
-- Game: Obama Maze

-- MAIN APPLICATION
addappid(1808060)
addappid(2107240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808061, 1, "e6e8c895c84a062d9a8ded59cd523f9a9af1554e429da4c197ee94d7e2e66d7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
