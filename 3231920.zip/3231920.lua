-- Lua provided by RyzenAPI
-- Game: Project SJHG

-- MAIN APPLICATION
addappid(3231920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231921, 1, "622b443f4b585d765c9d53d0ba8c9a4811af3d0828bf9654e5ec632bf33277cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
