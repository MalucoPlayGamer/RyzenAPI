-- Lua provided by SkyAPI 
-- Game: Project SJHG
addappid(3231920)
addappid(3231921, 1, "622b443f4b585d765c9d53d0ba8c9a4811af3d0828bf9654e5ec632bf33277cd")
