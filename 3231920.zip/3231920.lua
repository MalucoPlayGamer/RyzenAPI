-- Lua provided by RyzenAPI
-- Game: 3231920

-- MAIN APPLICATION
addappid(3231920)
-- Game: addappid(3231920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231921, 1, "622b443f4b585d765c9d53d0ba8c9a4811af3d0828bf9654e5ec632bf33277cd")
