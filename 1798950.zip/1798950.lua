-- Lua provided by RyzenAPI 
-- Game: Mojito the Cat
addappid(1798950)
addappid(1798951, 1, "6dde12aaa8f83dadd53008773caaf4c0a94ca98f32b522b0fca7dc7c162a997d")
