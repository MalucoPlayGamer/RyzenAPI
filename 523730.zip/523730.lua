-- Lua provided by RyzenAPI
-- Game: Sweet Volley High

-- MAIN APPLICATION
addappid(523730)

-- MAIN APP DEPOTS / PACKAGES
addappid(523731, 1, "edf4156f0fc4dc95f95a23e1e8d752cb5ead40d6ec20338cf0ceabbe9f1a0aae")
