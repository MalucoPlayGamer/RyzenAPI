-- Lua provided by RyzenAPI
-- Game: Game: Seirei

-- MAIN APPLICATION
addappid(857480)
-- Game: addappid(857480)

-- MAIN APP DEPOTS / PACKAGES
addappid(857481, 1, "bc38efcb7761fa470f05f516baa50498c69d1add29c78cfd727361369911bd3a")
