-- Lua provided by RyzenAPI
-- Game: Game: this morning I decided to die

-- MAIN APPLICATION
addappid(2456280)
-- Game: addappid(2456280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456281, 1, "7e9d10ff4c753f2dfe260a74df30aa699d807096936876d13d2d6dd37f198bab")
