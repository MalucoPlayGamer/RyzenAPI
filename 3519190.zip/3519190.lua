-- Lua provided by RyzenAPI
-- Game: FARLAND SAGA II Saturn Tribute

-- MAIN APPLICATION
addappid(3519190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519191, 1, "30d5bc49eff9a87adc409b26a0bd79145c875c7d44b86b827744dbdd2151c4c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3773700)
