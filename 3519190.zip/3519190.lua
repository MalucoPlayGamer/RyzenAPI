-- Lua provided by RyzenAPI
-- Game: FARLAND SAGA II Saturn Tribute

-- MAIN APPLICATION
addappid(3519190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519191, 1, "30d5bc49eff9a87adc409b26a0bd79145c875c7d44b86b827744dbdd2151c4c0")
