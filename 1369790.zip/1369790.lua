-- Lua provided by RyzenAPI
-- Game: Game: Marshmallow All the Way Home

-- MAIN APPLICATION
addappid(1369790)
-- Game: addappid(1369790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369791, 1, "5b55f191681a5d180ad1d19d09745311f45aa0182053aa3fb6acc70bebab39af")
