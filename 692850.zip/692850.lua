-- Lua provided by RyzenAPI
-- Game: Bloodstained: Ritual of the Night

-- MAIN APPLICATION
addappid(692850)

-- MAIN APP DEPOTS / PACKAGES
addappid(692852,0,"54869b8458af02610a6a5a992b8d846c785caebecb4022511caffab33ce69250")
addappid(1041460,0,"2c19abb45d89483fe9c472010021ec0c562d84d899c95ddec3c790be5b38a5dd")
addappid(2380800,0,"ea34e52a8ed5dd5224ebc4fc59b61ac0e039e99814be125d48ac84445301784a")
addappid(2380801,0,"53471e1a66ed778aec25e1d97bb5984842ceaea23e626815dea9a5e444db91fd")
addappid(2380802,0,"7edcfc402e1ec88ddfa6d6980e93b542bb1e44d25b7c91ede8a5bc2fdba6fe54")
addappid(2380803,0,"0eed91ff956f249361d9daa24928e52fec0a6f789680cb1a166b78482bb404b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
