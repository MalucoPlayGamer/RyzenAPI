-- Lua provided by RyzenAPI
-- Game: addappid(2014110)

-- MAIN APPLICATION
addappid(2014110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014111, 1, "53034519cbfa0f5592efa9af69c9a117e7a3a9caffcb611e5830ab66fa5e8cf2")
