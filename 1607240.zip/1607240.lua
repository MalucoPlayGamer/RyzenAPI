-- Lua provided by RyzenAPI
-- Game: Game: Mail Time

-- MAIN APPLICATION
addappid(1607240)
-- Game: addappid(1607240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607241, 1, "7f9aa00a2f41cbbdffa803b59b9045b62c5e9a0f7361534126d022483feb2ae8")
