-- Lua provided by RyzenAPI
-- Game: Mail Time

-- MAIN APPLICATION
addappid(1607240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607241, 1, "7f9aa00a2f41cbbdffa803b59b9045b62c5e9a0f7361534126d022483feb2ae8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
