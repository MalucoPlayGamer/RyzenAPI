-- Lua provided by RyzenAPI
-- Game: Game: DEATHGRIP Demo

-- MAIN APPLICATION
addappid(2461090)
-- Game: addappid(2461090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461091, 1, "869174042a81faee3c4ae33b5e780dfb10f1ee8ea9ef0f08113f63e4ecbfefb4")
