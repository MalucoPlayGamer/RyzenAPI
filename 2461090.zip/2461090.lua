-- Lua provided by SkyAPI 
-- Game: DEATHGRIP Demo
addappid(2461090)
addappid(2461091, 1, "869174042a81faee3c4ae33b5e780dfb10f1ee8ea9ef0f08113f63e4ecbfefb4")
