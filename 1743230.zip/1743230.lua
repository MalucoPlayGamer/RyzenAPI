-- Lua provided by RyzenAPI
-- Game: Game: Time of the Clones

-- MAIN APPLICATION
addappid(1743230)
-- Game: addappid(1743230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743231, 1, "c06a406b40947fc2d19bd4e83eb66f87ae6de2f30618fa04dea5c1d28e1c9754")
