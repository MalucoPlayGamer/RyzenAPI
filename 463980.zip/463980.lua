-- Lua provided by RyzenAPI
-- Game: Solitairica

-- MAIN APPLICATION
addappid(463980)

-- MAIN APP DEPOTS / PACKAGES
addappid(463981, 1, "3954e7a9a1ba1fd47cd583b901164192a859ce7dd63360791353b77afc44ab00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
