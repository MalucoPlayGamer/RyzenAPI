-- 4418770's Lua and Manifest Created by Hubcap Manifest
-- Snack Smasher
-- Created: July 22, 2026 at 15:50:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4418770, 1, "1cfcde9e0120fc6520a2c19dce0a4c2b8dde36eab6be97d365eecf11ccc2b1f0") -- Snack Smasher
-- MAIN APP DEPOTS
addappid(4418771, 1, "6993bd97730478d7d573d8b1cfe5384bf2601e0d57a0b0337fa4c9edf5eb3fe1") -- Depot 4418771
setManifestid(4418771, "3298970150105350501", 153184705)