-- Lua provided by RyzenAPI
-- Game: Dead Climb

-- MAIN APPLICATION
addappid(750080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(750081, 1, "9c5b61c3e0a63d84aede5a28623e9fb3edf0bb0f0d780a21d81312626346349d")
addappid(750082, 1, "61b29043388f0c73ab54b8cc39651c8812736b27b3aaf8f016335350fcef3457")

