-- Lua provided by RyzenAPI 
-- Game: Hidden Ghost Town
addappid(1810310)
addappid(1810311, 1, "ca702c63661a3b78e873dfa3174e2384fc22974ed1eb38413a7a726f38c40e95")
