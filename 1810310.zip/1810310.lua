-- Lua provided by RyzenAPI
-- Game: 1810310

-- MAIN APPLICATION
addappid(1810310)
-- Game: addappid(1810310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810311, 1, "ca702c63661a3b78e873dfa3174e2384fc22974ed1eb38413a7a726f38c40e95")
