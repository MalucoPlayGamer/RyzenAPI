-- Lua provided by RyzenAPI
-- Game: Worship Demon

-- MAIN APPLICATION
addappid(4172180) -- Worship Demon

-- MAIN APP DEPOTS / PACKAGES
addappid(4172181, 1, "991b83b2eec3103c75f4ec0b97a915ca0462a2b183e812410b645b14cd55b511") -- Depot 4172181

