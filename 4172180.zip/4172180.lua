-- 4172180's Lua and Manifest Created by Hubcap Manifest
-- Worship Demon
-- Created: August 07, 2026 at 10:47:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4172180) -- Worship Demon
-- MAIN APP DEPOTS
addappid(4172181, 1, "991b83b2eec3103c75f4ec0b97a915ca0462a2b183e812410b645b14cd55b511") -- Depot 4172181
setManifestid(4172181, "4249589370390154007", 1679153011)