-- Lua provided by RyzenAPI
-- Game: Adventure Rage Soundtrack

-- MAIN APPLICATION
addappid(650320)

-- MAIN APP DEPOTS / PACKAGES
addappid(650320,0,"f07bb46ae823897de6fd9ce67311cd3aca920f0a23f79512082e9c9a88789d29")
addtoken(650320,16918376213798247379)

