-- Lua provided by RyzenAPI
-- Game: 1500180

-- MAIN APPLICATION
addappid(1500180)
-- Game: addappid(1500180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500181, 1, "8676263f8f81119e5c225e4a75f8913a6cf307e7ffdb5f9541b919bc9416ffc6")
