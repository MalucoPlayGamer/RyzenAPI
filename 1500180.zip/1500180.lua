-- Lua provided by RyzenAPI 
-- Game: Decline's Drops
addappid(1500180)
addappid(1500181, 1, "8676263f8f81119e5c225e4a75f8913a6cf307e7ffdb5f9541b919bc9416ffc6")
