-- Lua provided by RyzenAPI
-- Game: This Grand Life 2 Demo

-- MAIN APPLICATION
addappid(2646680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646681, 1, "7b842225de958c9ce895939ea955015e3b7392ed59e1ffdbb48701942b01f0cb")
