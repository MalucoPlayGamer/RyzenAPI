-- Lua provided by RyzenAPI
-- Game: Riley Short: Analog Boy - Episode 1

-- MAIN APPLICATION
addappid(619000)
addappid(623490)
-- Game: addappid(619000)

-- MAIN APP DEPOTS / PACKAGES
addappid(619001, 1, "86226a7e4a688be65779e587909502b01028fc59c3fb31802587e2e354be64fa")
