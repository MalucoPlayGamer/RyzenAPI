-- Lua provided by RyzenAPI
-- Game: Renovation Simulator

-- MAIN APPLICATION
addappid(2726460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2726461, 1, "53165030a9aded3ff1c4d9e833cd7289ca4a3f54baa8dc47278a27c24000319f")

