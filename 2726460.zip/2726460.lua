-- Lua provided by RyzenAPI
-- Game: Renovation Simulator

-- MAIN APPLICATION
addappid(2726460)
-- Game: addappid(2726460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726461, 1, "53165030a9aded3ff1c4d9e833cd7289ca4a3f54baa8dc47278a27c24000319f")
