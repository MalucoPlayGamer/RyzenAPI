-- Lua provided by SkyAPI 
-- Game: Renovation Simulator
addappid(2726460)
addappid(2726461, 1, "53165030a9aded3ff1c4d9e833cd7289ca4a3f54baa8dc47278a27c24000319f")
