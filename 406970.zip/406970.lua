-- Lua provided by RyzenAPI
-- Game: AppID 406970

-- MAIN APPLICATION
addappid(406970)

-- MAIN APP DEPOTS / PACKAGES
addappid(406971, 1, "2b4f06ffde27ebd013fe0ae18746e619908eafe52d1c020769d81af0a0d30527")
addappid(406973, 1, "6523881786b4fb0115813682847aa24b14a14811c393e8d71c812c66402400e9")
addappid(564030, 0, "0f0b83c8aed959c1e5d410d75218ccbdae4d9025c88c1180d6e06b83ff291aa7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
