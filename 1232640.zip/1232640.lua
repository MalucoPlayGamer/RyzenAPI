-- Lua provided by RyzenAPI 
-- Game: AppID 1232640
addappid(1232640)
addappid(1232641, 1, "29b5af0e0318e396b74e38c45a7b35d1d019cf7cfc7739b9067bc9dc30a2622a")
