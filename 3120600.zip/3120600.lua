-- Lua provided by RyzenAPI
-- Game: 3120600

-- MAIN APPLICATION
addappid(3120600)
-- Game: addappid(3120600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120601, 1, "5a1b68da4b6dfeab16d272c11ed581ac1e939f68e75580b709ab9ef342ebd16c")
