-- Lua provided by RyzenAPI
-- Game: VR Harem Life ~ Your Room Became a Hang-Out for Girls!? ~

-- MAIN APPLICATION
addappid(3120600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120601, 1, "5a1b68da4b6dfeab16d272c11ed581ac1e939f68e75580b709ab9ef342ebd16c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3452420)
addappid(3452430)
addappid(3452460)
addappid(3452470)
addappid(3452480)
addappid(3452490)
addappid(3452500)
addappid(4209130)
addappid(4327810)
