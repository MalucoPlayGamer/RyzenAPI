-- Lua provided by RyzenAPI
-- Game: Game: AppID 390620

-- MAIN APPLICATION
addappid(390620)
-- Game: addappid(390620)

-- MAIN APP DEPOTS / PACKAGES
addappid(390621, 1, "16b4327bd2a08b441c2d97ab7d9c8ac3c0d8026dfaa778e4516662f26ec9a8f1")
addappid(390622, 1, "4e099351706e10dfe8fdf3143560b5bb8d0b7572163dcd3b17db986aa8842fbe")
addappid(390623, 1, "f4a8ddd46efb57c340e60281187bca6b15e78701b61fa447c31b2bc34ac9030e")
