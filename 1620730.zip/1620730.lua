-- Lua provided by RyzenAPI
-- Game: Hell is Us

-- MAIN APPLICATION
addappid(1620730)
addappid(2912150)
addappid(3494340)
addappid(3494350)
addappid(3494370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620731, 1, "b9fd543171e70e995805fd37a879ca35601536a3f52ce6d8f8c917169a88534a")
addappid(3494390, 0, "bea2e7ba38a31645bb88f40c59e3bd9b3fd7bd536262fcfe5157f89c467b56b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
