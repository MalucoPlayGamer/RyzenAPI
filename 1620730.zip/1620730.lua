-- Lua provided by RyzenAPI
-- Game: addappid(1620730)

-- MAIN APPLICATION
addappid(1620730)
addappid(2912150)
addappid(3494340)
addappid(3494350)
addappid(3494370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620731, 1, "b9fd543171e70e995805fd37a879ca35601536a3f52ce6d8f8c917169a88534a")
addappid(3494390, 0, "bea2e7ba38a31645bb88f40c59e3bd9b3fd7bd536262fcfe5157f89c467b56b9")
