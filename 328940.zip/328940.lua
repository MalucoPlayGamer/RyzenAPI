-- Lua provided by RyzenAPI
-- Game: Game: The Deer God

-- MAIN APPLICATION
addappid(328940)
-- Game: addappid(328940)

-- MAIN APP DEPOTS / PACKAGES
addappid(328941, 1, "c14c1fcdcaf81cfce300d7bc6b119048c8c72ca4a83499b53c79258715b13f07")
addappid(328942, 1, "8871cd78227eb97ef5eec33934ad29d38f43a0ee1c3ca50d6b6754527054c4e5")
addappid(328943, 1, "7e257bf801548f480dd3c44b1877c7839b46a8db616950a77599e6f34d6763b9")
