-- Lua provided by RyzenAPI
-- Game: Sonder

-- MAIN APPLICATION
addappid(2692570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2692571, 1, "e2a34ef8efad33655a3b51df61a0bda84e71c3cf7e3ac994184fc06bec61a9d1")

