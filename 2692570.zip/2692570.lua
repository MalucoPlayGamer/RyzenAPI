-- Lua provided by RyzenAPI
-- Game: Sonder

-- MAIN APPLICATION
addappid(2692570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692571, 1, "e2a34ef8efad33655a3b51df61a0bda84e71c3cf7e3ac994184fc06bec61a9d1")

