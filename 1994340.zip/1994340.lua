-- Lua provided by RyzenAPI
-- Game: addappid(1994340)

-- MAIN APPLICATION
addappid(1994340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994341, 1, "e8f430616805064222e878396ad50cc9dc5edede68414a2693fd674ddeff78dc")
