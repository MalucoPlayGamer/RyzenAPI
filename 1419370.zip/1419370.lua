-- Lua provided by RyzenAPI
-- Game: Cooking Companions: Appetizer Edition

-- MAIN APPLICATION
addappid(1419370)
addappid(1423070)
-- Game: addappid(1419370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419371, 1, "e12a35777ac0e7353973d3761e8edc64b3ff59f73fed1351341472f4438c04ac")
