-- Lua provided by RyzenAPI
-- Game: Karradash - The Lost Dungeons

-- MAIN APPLICATION
addappid(682020)

-- MAIN APP DEPOTS / PACKAGES
addappid(682021, 1, "89c0836d592417e43df152982882996a15a468fa14a9a618f1ca6db4d92198db")

