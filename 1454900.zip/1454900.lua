-- Lua provided by RyzenAPI
-- Game: 1454900

-- MAIN APPLICATION
addappid(228988)
addappid(1454900)
addappid(1454903)
addappid(1454904)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454902,0,"129f6d20ddc534a6a359ed09e2424cfdff93c2ab2401a75dc55e25970a8e813b")

