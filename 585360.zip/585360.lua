-- Lua provided by RyzenAPI
-- Game: AppID 585360

-- MAIN APPLICATION
addappid(585360)

-- MAIN APP DEPOTS / PACKAGES
addappid(585361, 1, "d6da62ca1d2585519ce8f09ccb3edd6a56d83ee2aa78868921c24c86f683fd07")

