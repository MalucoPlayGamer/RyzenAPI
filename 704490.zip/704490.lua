-- Lua provided by RyzenAPI
-- Game: addappid(704490)

-- MAIN APPLICATION
addappid(704490)

-- MAIN APP DEPOTS / PACKAGES
addappid(704491, 1, "fac6a2869c456a7d3accd03f4dcdc7732653e038c6b30eb3a56c75959b377747")
