-- Lua provided by RyzenAPI
-- Game: AppID 715380

-- MAIN APPLICATION
addappid(715380)
-- Game: addappid(715380)

-- MAIN APP DEPOTS / PACKAGES
addappid(715381, 1, "50b3c3a8ef2d121491e7056e4ac2fb034325b01b772d4ca42bca093f7802a3fa")
addappid(1459970, 0, "f4c864ee25e7d40c5edaa80b581ad59be773d2f9c7c67887c79f1da932be7e54")
