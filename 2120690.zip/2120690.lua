-- Lua provided by RyzenAPI
-- Game: 蓝色形态 Demo

-- MAIN APPLICATION
addappid(2120690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120691, 1, "d1790e5f871466066f3650cbd68eb6a49b9ba1ce512c30ce6962d995ee010465")

