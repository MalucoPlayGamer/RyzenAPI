-- Lua provided by RyzenAPI
-- Game: addappid(449120)

-- MAIN APPLICATION
addappid(449120)

-- MAIN APP DEPOTS / PACKAGES
addappid(449121, 1, "a4d4b838bc961c163c5cd7016a6e88eb9051892c24449abeac6f134e833c734b")
