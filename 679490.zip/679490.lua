-- Lua provided by RyzenAPI
-- Game: AppID 679490

-- MAIN APPLICATION
addappid(679490)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(679491, 1, "6679eed2c7a952efa4b92e86a710c3f2d6a06fda29ddfc8c90d3597ed6293b30")

