-- Lua provided by RyzenAPI
-- Game: AppID 3000350

-- MAIN APPLICATION
addappid(3000350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000351, 1, "ad28e076ea4e90fbdcf46c12fbac899eb29302007a72b2e7649399a81f068cde")
