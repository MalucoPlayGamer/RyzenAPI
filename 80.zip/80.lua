-- Lua provided by RyzenAPI 
-- Game: Counter-Strike: Condition Zero
addappid(80)
addappid(81, 1, "e3d6714bfa78ac765f446c4101a16b2383abafd4c84e0f6c993801fd46d54ef2")
addappid(82, 1, "d78e51dd1831ff5bc99cb794fed8c31aca71297a7ae7360f646cf5fe1728525f")
addappid(83, 1, "3910c4cc001ec0efe6624eece7045e6d78144a32fb21e8eaccabde6c3ac532fd")
addappid(84, 1, "59a8baacaa0b59cc397031179938f4f9b0fa8d9a9a6c828da6bf84588205dead")
addappid(85, 1, "b68e9593f5e743e331ebbbc141d87cabc73d967e87bdecebe2ebff612c3374ab")
addappid(87, 1, "0efbbd26f79a16cd7b6792eb9ada298ba2b35e6ceb9dae55f38de6edf1a2195e")
addappid(88, 1, "3855a57ff95d6b1e28417b00dbd1d6f5874cb6fe734edafef5fb96a2982f3d79")
addappid(89, 1, "5a3cc8417d106adb4051844e62e18317d69bc39ee9df52fa54e2b67e3261401b")
