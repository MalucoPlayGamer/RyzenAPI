-- Lua provided by RyzenAPI
-- Game: addappid(2935040)

-- MAIN APPLICATION
addappid(2935040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935041, 1, "cced0e54c9693cfd708caf9b92ee92c43816bd0885af396966b6479f1774c96d")
