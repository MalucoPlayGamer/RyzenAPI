-- Lua provided by RyzenAPI
-- Game: Game: Wer weiß denn sowas? - Das Spiel

-- MAIN APPLICATION
addappid(782130)
-- Game: addappid(782130)

-- MAIN APP DEPOTS / PACKAGES
addappid(782131, 1, "1bcd4c185953333b2d02cd45459fbf65e3b407b5d63ceacda5dbffd6e373ecea")
