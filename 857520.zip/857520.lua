-- Lua provided by RyzenAPI
-- Game: Degrees

-- MAIN APPLICATION
addappid(857520)
addappid(895790)
addappid(896290)
addappid(927920)

-- MAIN APP DEPOTS / PACKAGES
addappid(857521,0,"71fe7a6cd12cd80aea2eb24664ec18d6b9c7e225a08640af1009864bda792de4")

