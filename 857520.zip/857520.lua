-- Lua provided by RyzenAPI
-- Game: Degrees

-- MAIN APPLICATION
addappid(857520)

-- MAIN APP DEPOTS / PACKAGES
addappid(857521, 1, "71fe7a6cd12cd80aea2eb24664ec18d6b9c7e225a08640af1009864bda792de4")
