-- Lua provided by RyzenAPI
-- Game: Riftstorm

-- MAIN APPLICATION
addappid(2282790) -- Riftstorm

-- MAIN APP DEPOTS / PACKAGES
addappid(2282791, 1, "e35defb62084b0a567e2070a191c1110f93ef0956febc4d6dae863309ed4fecb") -- Depot 2282791

