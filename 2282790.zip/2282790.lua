-- 2282790's Lua and Manifest Created by Hubcap Manifest
-- Riftstorm
-- Created: August 11, 2026 at 14:01:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2282790) -- Riftstorm
-- MAIN APP DEPOTS
addappid(2282791, 1, "e35defb62084b0a567e2070a191c1110f93ef0956febc4d6dae863309ed4fecb") -- Depot 2282791
setManifestid(2282791, "2004259640673630449", 10741483353)