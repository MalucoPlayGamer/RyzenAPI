-- Lua provided by RyzenAPI
-- Game: AppID 110400

-- MAIN APPLICATION
addappid(110400)

-- MAIN APP DEPOTS / PACKAGES
addappid(110401, 1, "a5cefa5ed918041f411be49bc25c9bddbff282cec937c0ebdcc428af7a46af41")
