-- Lua provided by RyzenAPI
-- Game: HUNTERS FOR YOUR BRAIN

-- MAIN APPLICATION
addappid(1088070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088071, 1, "be81c909f7e5aabd8a2bc67271eca53b7c40ebecc7dd4dfc1ce664dfbd952217")
