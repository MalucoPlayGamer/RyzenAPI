-- Lua provided by RyzenAPI
-- Game: HUNTERS FOR YOUR BRAIN

-- MAIN APPLICATION
addappid(1088070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1088071, 1, "be81c909f7e5aabd8a2bc67271eca53b7c40ebecc7dd4dfc1ce664dfbd952217")

