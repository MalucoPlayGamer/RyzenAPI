-- Lua provided by RyzenAPI
-- Game: Lost in Limbo Demo

-- MAIN APPLICATION
addappid(3103010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103012,0,"cf2d1c1533f6c1c9a53ff9ec3cc7f5413b2d7bee1065ef3aedb93375304f2444")
