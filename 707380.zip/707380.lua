-- Lua provided by RyzenAPI
-- Game: addappid(707380)

-- MAIN APPLICATION
addappid(707380)

-- MAIN APP DEPOTS / PACKAGES
addappid(707381, 1, "1bcd17ec090a45eec234b42004476d32fd891e6ec16bf94fdf7821b7e1515fe2")
