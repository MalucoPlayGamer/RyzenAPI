-- Lua provided by RyzenAPI 
-- Game: Adventures of a snowboarder
addappid(2354310)
addappid(2354311, 1, "6d9feb6a80b41d0a66ae1fa97fdf2ebce1b8de14115d2678db974957a432c63f")
