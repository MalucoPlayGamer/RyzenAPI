-- Lua provided by RyzenAPI
-- Game: Game: Stream Racer

-- MAIN APPLICATION
addappid(1333410)
-- Game: addappid(1333410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333411, 1, "0bb9e7e70fbc2c651e744b0dca23100f15c064d52793144672694435c73e1862")
