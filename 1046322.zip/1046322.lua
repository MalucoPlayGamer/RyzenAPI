-- Lua provided by RyzenAPI
-- Game: 1046322

-- MAIN APPLICATION
addappid(1046322)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046322,0,"703b1a5749b01eb3ccb2144ffaf81a122f6fa35ccd44a86c12c82a2706e6cead")
