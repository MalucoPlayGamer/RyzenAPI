-- Lua provided by RyzenAPI
-- Game: addappid(319250)

-- MAIN APPLICATION
addappid(319250)
addappid(349370)

-- MAIN APP DEPOTS / PACKAGES
addappid(319251, 1, "b29aacf54a29d8edc10846ecea9b1cf90f31c327959a1491f29118254d0540e3")
