-- Lua provided by RyzenAPI
-- Game: Aviators

-- MAIN APPLICATION
addappid(2626910)
-- Game: addappid(2626910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626911, 1, "a14bacc8adc0035d383e4eb82fb03c9f3969c4947b1413b83db23da920ddba0c")
