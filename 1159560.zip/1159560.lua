-- Lua provided by RyzenAPI
-- Game: Ziggurat 2

-- MAIN APPLICATION
addappid(1159560)
addappid(1776850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159561,0,"92b09555aadea1758ef9ac6cf576f241c061d6cd2e5dada5f545c2d7e3f0948d")
addappid(1159562,0,"269327d534fbc44450010fbdc61249bb75a393ae5f68ec7292704dbd1917fbcb")
addappid(1159563,0,"132e7105de8362f6861b8910a5204c0e9a049bd6a9bc1060729c55fffb836388")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
