-- Lua provided by RyzenAPI
-- Game: 1078920

-- MAIN APPLICATION
addappid(1078920)
-- Game: addappid(1078920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078921, 1, "43b01b2f264f192ab28d897c399d92616a20aaf06bf13b8dab30e0931ef9836d")
