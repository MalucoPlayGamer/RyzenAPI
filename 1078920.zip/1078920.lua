-- Lua provided by RyzenAPI
-- Game: Main Assembly

-- MAIN APPLICATION
addappid(1078920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078921, 1, "43b01b2f264f192ab28d897c399d92616a20aaf06bf13b8dab30e0931ef9836d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
