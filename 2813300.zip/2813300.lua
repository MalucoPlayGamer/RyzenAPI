-- Lua provided by RyzenAPI
-- Game: addappid(2813300)

-- MAIN APPLICATION
addappid(2813300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813301, 1, "3eea9fd37457b73329035d4e32370cf8803ead5ff3fbb89d80eae3810ebc50ad")
