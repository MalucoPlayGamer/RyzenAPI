-- Lua provided by RyzenAPI
-- Game: Parfait Remake

-- MAIN APPLICATION
addappid(2947220)
-- Game: addappid(2947220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947221, 1, "5376cc46e644da99000eeb3b8daec374deb6a7fac2a9a8d74be14f05bc4a98b9")
