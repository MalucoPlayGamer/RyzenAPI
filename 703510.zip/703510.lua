-- Lua provided by RyzenAPI
-- Game: Game: AppID 703510

-- MAIN APPLICATION
addappid(703510)
-- Game: addappid(703510)

-- MAIN APP DEPOTS / PACKAGES
addappid(703511, 1, "6cdcd61dcfca713ff1ad3de61d84ec5e55492b8cd35f463a88f4a1d65479d563")
