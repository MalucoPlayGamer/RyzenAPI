-- Lua provided by RyzenAPI 
-- Game: AppID 703510
addappid(703510)
addappid(703511, 1, "6cdcd61dcfca713ff1ad3de61d84ec5e55492b8cd35f463a88f4a1d65479d563")
