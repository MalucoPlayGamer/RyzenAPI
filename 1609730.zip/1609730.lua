-- Lua provided by RyzenAPI
-- Game: Aliens vs. Ghosts

-- MAIN APPLICATION
addappid(1609730)
-- Game: addappid(1609730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609731, 1, "d29c3919b21127ccd196dd311774736af16b576cf04d28231f94193cb5453532")
