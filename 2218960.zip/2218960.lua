-- Lua provided by RyzenAPI
-- Game: AppID 2218960

-- MAIN APPLICATION
addappid(2218960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2218961, 1, "fc1e65089da2efdf8a8e42c0df5304ef0c9fad78dc5f91fb2e1e63f733f2f5e9")
addappid(2218962, 1, "9888ad71293bc8d375f7a3327c9d73cb668628b745cae073f80e88fa1cc4f673")

