-- Lua provided by RyzenAPI
-- Game: 2263401

-- MAIN APPLICATION
addappid(2263401)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263401,0,"5d4c57ce172abc80d07afa57dfc151822dcca431b4402befa907de93dfa4507f")
