-- Lua provided by RyzenAPI
-- Game: Space Theory

-- MAIN APPLICATION
addappid(2008240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008241, 1, "9630a90fde4db893874d9fdaa07123acf89f94be4230551081fb5132dc2981c6")
