-- Lua provided by RyzenAPI
-- Game: Game: Islets

-- MAIN APPLICATION
addappid(1669420)
-- Game: addappid(1669420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669421, 1, "365f1619f49503c6abd4c2ecb1d52f9710f72e15e746cac5f551c1ad13043ca9")
