-- Lua provided by SkyAPI 
-- Game: AppID 203300
addappid(203300)
addappid(203301, 1, "9172c5655843fa3862eccc58dd73eda905638fdbf403754dea6241b690126056")
addappid(203302, 1, "5bac834bde5c332beee242ec972c5ae8c17c03c24e87e3486ba6a9139868292a")
addappid(203303, 1, "8cdc7ac0e176c3011a1c273da76192b5fdf8b46254a6d1dd2fc28d3065ce81e3")
addappid(228983)
addappid(228984)
addappid(228990)
