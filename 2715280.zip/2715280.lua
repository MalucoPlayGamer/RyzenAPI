-- Lua provided by RyzenAPI
-- Game: addappid(2715280)

-- MAIN APPLICATION
addappid(2715280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715281, 1, "b39fb225fbe671c3d1f200d447156e553b91dc094cd6225080d6d7270cad1a12")
