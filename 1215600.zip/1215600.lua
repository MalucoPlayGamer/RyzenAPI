-- Lua provided by RyzenAPI
-- Game: The Legend of Eldridge Scrolls: Woop

-- MAIN APPLICATION
addappid(1215600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1215602,0,"b9e67116e32ff757548e5e587205a9f8893247c765fbfb65de1c5fd4b3b2fc39")

