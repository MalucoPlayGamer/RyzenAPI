-- Lua provided by RyzenAPI
-- Game: setManifestid(1215602,"8060110501596033132")

-- MAIN APPLICATION
addappid(1215600)
-- Game: addappid(1215600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215602,0,"b9e67116e32ff757548e5e587205a9f8893247c765fbfb65de1c5fd4b3b2fc39")
