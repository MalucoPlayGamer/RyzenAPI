-- Lua provided by RyzenAPI
-- Game: 2811530

-- MAIN APPLICATION
addappid(2811530)
-- Game: addappid(2811530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811531, 1, "17f88a81710c03591223461b03a59f5f6d935b90a8d67b2f5a8c984de3f0faa3")
