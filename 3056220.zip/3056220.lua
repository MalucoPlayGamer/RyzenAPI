-- Lua provided by RyzenAPI
-- Game: Game: 迪菲大陸戰記 III

-- MAIN APPLICATION
addappid(3056220)
-- Game: addappid(3056220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056221, 1, "f10d6f9c36f2eedcdbf34bc5a8d4e06b428f9f3ccecc404692ed61ceae40e7b2")
