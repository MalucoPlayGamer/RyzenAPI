-- Lua provided by RyzenAPI
-- Game: addappid(2862040)

-- MAIN APPLICATION
addappid(2862040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862041, 1, "5efa295c6d24bb6536d1c14fe8efe132b9f9be807a225a3c0aece1fb28b5c34a")
