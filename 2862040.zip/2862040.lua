-- Lua provided by SkyAPI 
-- Game: One Chance
addappid(2862040)
addappid(2862041, 1, "5efa295c6d24bb6536d1c14fe8efe132b9f9be807a225a3c0aece1fb28b5c34a")
