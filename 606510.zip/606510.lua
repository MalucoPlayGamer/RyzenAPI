-- Lua provided by RyzenAPI
-- Game: Grisaia Phantom Trigger Vol.1

-- MAIN APPLICATION
addappid(606510)

-- MAIN APP DEPOTS / PACKAGES
addappid(606511, 1, "8f4bfd5225b7704c251d41801ab159469ddd81eafca56c302b044fd71c23b037")
addappid(606512, 1, "282d79ed834cbf679e92aab21652e698e45566427b9a3f5ee7e3d3cb0b523e0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
