-- Lua provided by RyzenAPI
-- Game: Savage Age

-- MAIN APPLICATION
addappid(2080140)
-- Game: addappid(2080140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080141, 1, "b9bb2da97580c74a9a169b137af8dea9bd7874fa6ccd360b5ffc9577b2d666fc")
