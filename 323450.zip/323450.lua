-- Lua provided by RyzenAPI
-- Game: 323450

-- MAIN APPLICATION
addappid(323450)
-- Game: addappid(323450)

-- MAIN APP DEPOTS / PACKAGES
addappid(323452,0,"70b09d1991b39e3e28c5c9b9e1ae8341278d42138dc4b728b40d6e5321c00aa0")
