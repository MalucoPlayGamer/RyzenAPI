-- Lua provided by RyzenAPI
-- Game: 594820

-- MAIN APPLICATION
addappid(594820)
-- Game: addappid(594820)

-- MAIN APP DEPOTS / PACKAGES
addappid(594821, 1, "6bb26a03e02b58830f2ad7b7a8da1e7b3c9e5dea66125945b59e13965be43d7b")
addappid(594822, 1, "8a5b274783b5b7b38f4332bed37a89fa94a1228c37181b72fbe8dfd5cb2e4d47")
addappid(594823, 1, "fc670db7e6a648375b5413de049f9d765bdd824bc549985ed77030bbc9c1a6d4")
