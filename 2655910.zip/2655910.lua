-- Lua provided by RyzenAPI 
-- Game: Costume Fighter
addappid(2655910)
addappid(2655911, 1, "518433043e547e80aaee859615b0f81cdba08a23275b85e5d6842adeab523bd2")
addappid(2655912, 1, "3675e74e065333a3545abaec96a35ebd7a151c1dd247c939eebef8db9cd083e4")
