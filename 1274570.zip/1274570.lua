-- Lua provided by RyzenAPI
-- Game: AppID 1274570

-- MAIN APPLICATION
addappid(1274570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274571, 1, "b56991abb013052ba7ef6d1e0982f0ca99bbeeb631057347267102c6967c1537")
addappid(1274573, 1, "b67b5c5c44139818a0d7ddb9d1103a724ca404a87bde4d78fe257fc352f0f36d")
addappid(1966630, 0, "9b579f914a2ba495ad1e0b1e1a1fc21c8e578ee933fb6bfabd9f138124244587")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
