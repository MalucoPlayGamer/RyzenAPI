-- Lua provided by RyzenAPI
-- Game: Game: Deathwish Enforcers Special Edition

-- MAIN APPLICATION
addappid(2683030)
-- Game: addappid(2683030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683031, 1, "d1d5514378dcceace4cb76073359b5738c7c204b42eb9aeb8f44d5ada5394c03")
