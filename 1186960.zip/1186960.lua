-- Lua provided by RyzenAPI 
-- Game: Cowboys vs Hipsters
addappid(1186960)
addappid(1186961, 1, "68aaa335151fb7080055403e9bb0cd338abf8881ef30fe38d591e472a0eae0dc")
addappid(1186962, 1, "d0ccff4cd746a1f6616e5931701e1969be7b040116d1832bf7cbbb5d79f03bf8")
