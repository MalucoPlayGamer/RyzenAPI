-- Lua provided by RyzenAPI
-- Game: Fool's End

-- MAIN APPLICATION
addappid(2636260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636261, 1, "13025f154d6ec05981d539d7e180baa11396872c848ba32dd6fad8ec95944213")
