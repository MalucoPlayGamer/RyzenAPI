-- Lua provided by SkyAPI 
-- Game: Gobligeddon
addappid(1120090)
addappid(1120091, 1, "abb13b700fdad330492bb8a3609da84a436aa20afb915ba71f5492a34b88c3d9")
