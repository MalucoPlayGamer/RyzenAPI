-- Lua provided by RyzenAPI
-- Game: Gobligeddon

-- MAIN APPLICATION
addappid(1120090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120091, 1, "abb13b700fdad330492bb8a3609da84a436aa20afb915ba71f5492a34b88c3d9")
