-- Lua provided by RyzenAPI
-- Game: Darkness Under My Bed

-- MAIN APPLICATION
addappid(1527880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527881, 1, "7a9f27752cf930ba2224d0ed29ac87607feb50030f3274f3408674053e9bc0c4")

