-- Lua provided by RyzenAPI
-- Game: Darkness Under My Bed

-- MAIN APPLICATION
addappid(1527880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527881, 1, "7a9f27752cf930ba2224d0ed29ac87607feb50030f3274f3408674053e9bc0c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
