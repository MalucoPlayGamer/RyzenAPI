-- Lua provided by RyzenAPI
-- Game: Goose Goose Duck

-- MAIN APPLICATION
addappid(1568590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568591, 1, "5edbf6912532573057c61d53d6eb8020d948e54d0a6a90c90d696cdacf60d054")
