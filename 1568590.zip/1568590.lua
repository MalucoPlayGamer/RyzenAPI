-- Lua provided by RyzenAPI
-- Game: Goose Goose Duck

-- MAIN APPLICATION
addappid(1568590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1568591, 1, "5edbf6912532573057c61d53d6eb8020d948e54d0a6a90c90d696cdacf60d054")

