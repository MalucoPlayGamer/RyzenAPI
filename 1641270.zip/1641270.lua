-- Lua provided by RyzenAPI
-- Game: 枝江往事

-- MAIN APPLICATION
addappid(1641270)
