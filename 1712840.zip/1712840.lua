-- Lua provided by RyzenAPI
-- Game: Tiny Tina's Assault on Dragon Keep: A Wonderlands One-shot Adventure

-- MAIN APPLICATION
addappid(1712840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712841, 1, "dad684f848d851329295fc8c0f76dfb511663bd905a2d8034a696cfaae396703")
addappid(1712842, 1, "c4af5b8df243bf3c1186ecacfa2a53537869932b2562dcf0eb0eb6920d3f13c9")
addappid(1712844, 1, "1083695a701956ed352ac5b0b0b3a54cc6219164fa9e235ec2cd7767db7848cc")
addappid(1712845, 1, "500e41f03c59214da9909fa7bea8c376e16891ce85334630f722c0971abae687")
addappid(1712846, 1, "de858f012299f9f432959b6189899b1be6298b5c99cd90238fd1cffa9761922a")
addappid(1712847, 1, "52f06a00d9d96fcf23c9bd68634c1ea7ffaabb8c5e0b2eebe3bc35e93f50bfbc")
addappid(1712848, 1, "a899812ac0e2687d6aa6de3d67701413ed330bdbcb437a8fed54370448f68087")
addappid(1712849, 1, "7f314f352fd82da72af9a7b2de5e8f00c56999b88546ea15e1070e9d888be186")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
