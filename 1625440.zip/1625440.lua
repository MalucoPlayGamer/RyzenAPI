-- Lua provided by RyzenAPI
-- Game: Don't Byte Your Tongue

-- MAIN APPLICATION
addappid(228990)
addappid(1625440)
-- Game: addappid(1625440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625442,0,"8fb7497ef335389a705bd8b1c82f1f37f2b7238bd3bdfeb559e416f3afc43999")
addappid(1625443,0,"d6d18335f7558b482f6a2d1b600a90166b62e660cd75b64b67fd2f95665bef69")
addappid(1625444,0,"2a1fe76ed30f3111ab8d1cf278f4b7c92aa17703a4cae20f71ebde4fd069852a")
