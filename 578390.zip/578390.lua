-- Lua provided by RyzenAPI
-- Game: AppID 578390

-- MAIN APPLICATION
addappid(578390)
-- Game: addappid(578390)

-- MAIN APP DEPOTS / PACKAGES
addappid(578391, 1, "3f2c1dcc973db26d07097add9efe32de2a443202c27b9d0ecb59e7d5f56b4383")
