-- Lua provided by RyzenAPI
-- Game: Game: Deep Space Rush

-- MAIN APPLICATION
addappid(853040)
addappid(856530)
-- Game: addappid(853040)

-- MAIN APP DEPOTS / PACKAGES
addappid(853041, 1, "9f5ce1473d6024c3e519badb1d568cacb2df731f716bf9c061a3ad3b42c663ec")
