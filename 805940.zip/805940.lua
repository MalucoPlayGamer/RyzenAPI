-- Lua provided by RyzenAPI
-- Game: Game: AppID 805940

-- MAIN APPLICATION
addappid(805940)
-- Game: addappid(805940)

-- MAIN APP DEPOTS / PACKAGES
addappid(805941, 1, "ba37ad699ba8a39894b107e5e37094e423d9f9be8a372b05589f50ecabd4b13e")
