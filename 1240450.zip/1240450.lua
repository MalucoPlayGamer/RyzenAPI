-- Lua provided by RyzenAPI
-- Game: Game: Garden Witch Life

-- MAIN APPLICATION
addappid(1240450)
-- Game: addappid(1240450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240451, 1, "ed94e61e82583f6b4f584cf1879f2a895d5d2180de1f76b8474bb9c1b3f4984e")
