-- Lua provided by RyzenAPI
-- Game: Garden Witch Life

-- MAIN APPLICATION
addappid(1240450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240451, 1, "ed94e61e82583f6b4f584cf1879f2a895d5d2180de1f76b8474bb9c1b3f4984e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
