-- Lua provided by RyzenAPI
-- Game: Barcha

-- MAIN APPLICATION
addappid(3576700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3576701, 1, "8a84ed2cea66e9e2a3bd1bca37ca2f590f7e2310c463bc76eb8dd302702bc13d")

