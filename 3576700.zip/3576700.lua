-- Lua provided by RyzenAPI
-- Game: Barcha

-- MAIN APPLICATION
addappid(3576700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3576701, 1, "8a84ed2cea66e9e2a3bd1bca37ca2f590f7e2310c463bc76eb8dd302702bc13d")

