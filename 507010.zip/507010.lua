-- Lua provided by RyzenAPI
-- Game: Mr.President!

-- MAIN APPLICATION
addappid(507010)

-- MAIN APP DEPOTS / PACKAGES
addappid(507011, 1, "d5b573257833fb3463c54a6ee9fbcb641a20fb00c679f88f6a857941e8252778")

