-- Lua provided by RyzenAPI
-- Game: addappid(496460)

-- MAIN APPLICATION
addappid(496460)

-- MAIN APP DEPOTS / PACKAGES
addappid(496461, 1, "bd0895869cdbe1f99295b3d5be5206ae2aea6aee2b71acc5853466a747b7a9db")
