-- Lua provided by RyzenAPI
-- Game: Tavern Master Demo

-- MAIN APPLICATION
addappid(1703370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703371, 1, "547f0666d53781f27fc62c4c28acdb2fea589884f9c57146055eea513b708896")
