-- Lua provided by RyzenAPI
-- Game: Game: Love is...

-- MAIN APPLICATION
addappid(3034130)
-- Game: addappid(3034130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034131, 1, "eda1a412a1613c6fb1c8e76e809df24381c13f9244b5f6086d8a268e4b1f6d2d")
