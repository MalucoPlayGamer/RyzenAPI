-- Lua provided by SkyAPI 
-- Game: Love is...
addappid(3034130)
addappid(3034131, 1, "eda1a412a1613c6fb1c8e76e809df24381c13f9244b5f6086d8a268e4b1f6d2d")
