-- Lua provided by RyzenAPI
-- Game: addappid(2750210)

-- MAIN APPLICATION
addappid(2750210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750211, 1, "66d76d3459de843562bf6d03c33870a27f2f92b30fffa69a23cf64885f507c20")
