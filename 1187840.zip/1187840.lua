-- Lua provided by RyzenAPI
-- Game: Vesper: Zero Light Edition

-- MAIN APPLICATION
addappid(1187840)
addappid(1978340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187841, 1, "5a6350124cc6b547a4e87d4b0ac579bf90901532978e996b2891c8ef1d493d42")

