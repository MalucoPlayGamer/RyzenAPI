-- Lua provided by RyzenAPI
-- Game: League of Evil

-- MAIN APPLICATION
addappid(491060)

-- MAIN APP DEPOTS / PACKAGES
addappid(491061, 1, "4c2db8c1256058af7904001acc94b5d8dc77e39cb8b5037c1b662cbf88edb4b3")
addappid(618480, 0, "bf586990853083f4100122826c5dd13835c9d79f3af1356af37f18f04156e12e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
