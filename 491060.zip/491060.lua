-- Lua provided by RyzenAPI 
-- Game: League of Evil
addappid(491060)
addappid(491061, 1, "4c2db8c1256058af7904001acc94b5d8dc77e39cb8b5037c1b662cbf88edb4b3")
addappid(618480, 0, "bf586990853083f4100122826c5dd13835c9d79f3af1356af37f18f04156e12e")
