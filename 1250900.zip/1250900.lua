-- Lua provided by RyzenAPI
-- Game: AppID 1250900

-- MAIN APPLICATION
addappid(1250900)
addappid(2187720)
addappid(2247940)
addappid(2284400)
addappid(2457400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250901, 1, "faf47de47ad836b8501b49daaab3d4e8a3ea2f2ab1d25a4d3e4635665c37d031")

