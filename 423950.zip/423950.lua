-- Lua provided by RyzenAPI
-- Game: Deadlight: Director's Cut

-- MAIN APPLICATION
addappid(423950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(423951, 1, "d62af4e518f8dd6b6df6d91958cd1448c6cd5da171c661c6fdeadea226fb2081")
addappid(423952, 1, "5b8de7c424e59e4217c08e77c91f107cb32421f06d3f2c0603de2c33df442c33")

