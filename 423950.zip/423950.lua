-- Lua provided by RyzenAPI
-- Game: 423950

-- MAIN APPLICATION
addappid(423950)
-- Game: addappid(423950)

-- MAIN APP DEPOTS / PACKAGES
addappid(423951, 1, "d62af4e518f8dd6b6df6d91958cd1448c6cd5da171c661c6fdeadea226fb2081")
addappid(423952, 1, "5b8de7c424e59e4217c08e77c91f107cb32421f06d3f2c0603de2c33df442c33")
