-- Lua provided by RyzenAPI
-- Game: 2896220

-- MAIN APPLICATION
addappid(2896220)
-- Game: addappid(2896220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2896221, 1, "c2721cc2f815f9ebf73f4a306dfe77fc79dc5e202a94b82908c7bbce0376a39a")
