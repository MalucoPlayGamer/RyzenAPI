-- 4377950's Lua and Manifest Created by Hubcap Manifest
-- Void Salvage
-- Created: August 24, 2026 at 11:00:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4377950, 1, "46d41d51f6aa11159d895669dd7321c48a6ed503b9ff97aaa257572792a07477") -- Void Salvage
-- MAIN APP DEPOTS
addappid(4377951, 1, "62c0e0508194b5928b5562019c3707a5c36d39f2063099612d6dc702e703f75c") -- Depot 4377951
setManifestid(4377951, "7982216640962810006", 93280328)