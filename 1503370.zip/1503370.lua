-- Lua provided by SkyAPI 
-- Game: Francisca 2
addappid(1503370)
addappid(1503371, 1, "503461639cd22d6311a16e9d0d035038dce2180c248a09ff309aa9c156b44798")
