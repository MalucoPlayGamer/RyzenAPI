-- Lua provided by RyzenAPI
-- Game: Game: Francisca 2

-- MAIN APPLICATION
addappid(1503370)
-- Game: addappid(1503370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503371, 1, "503461639cd22d6311a16e9d0d035038dce2180c248a09ff309aa9c156b44798")
