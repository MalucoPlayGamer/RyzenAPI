-- Lua provided by RyzenAPI
-- Game: Heroes Never Lose: Professor Puzzler's Perplexing Ploy

-- MAIN APPLICATION
addappid(342530)
-- Game: addappid(342530)

-- MAIN APP DEPOTS / PACKAGES
addappid(342531, 1, "c365c5ff827bcaedf295f16bbf381dfc5202b55669cc27a18999974f6fee67c0")
