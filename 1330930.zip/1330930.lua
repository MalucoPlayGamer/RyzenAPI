-- Lua provided by RyzenAPI
-- Game: 1330930

-- MAIN APPLICATION
addappid(1330930)
-- Game: addappid(1330930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330931, 1, "09207e06cc5a85d95df38c69fd0d2f06c4ed8c51bbb38f8b428ea42f8cf07d05")
