-- Lua provided by RyzenAPI
-- Game: AWAKEN：Gunpowder Adventurer Day.Dream

-- MAIN APPLICATION
addappid(760000)

-- MAIN APP DEPOTS / PACKAGES
addappid(760001,0,"13f33b45007093607dc728736628c9637afac56befd9e3986bf115ec1356b38d")

