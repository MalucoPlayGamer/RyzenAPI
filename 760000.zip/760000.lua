-- Lua provided by RyzenAPI
-- Game: AWAKEN：Gunpowder Adventurer Day.Dream

-- MAIN APPLICATION
addappid(760000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(760001,0,"13f33b45007093607dc728736628c9637afac56befd9e3986bf115ec1356b38d")

