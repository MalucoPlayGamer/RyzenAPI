-- Lua provided by RyzenAPI
-- Game: addappid(1280950)

-- MAIN APPLICATION
addappid(1280950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280951, 1, "0dc62da9af0880ba6e326744397a22169742e3114d90853d4df5c786d1cef9a3")
