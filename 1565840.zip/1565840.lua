-- Lua provided by SkyAPI 
-- Game: PuppeTNetiK - Speedrun Challenge
addappid(1565840)
addappid(1565841, 1, "5f2d0f8cf76b25689f96b2c931cc8677eb8444c6a6aa641ea8aade9131094322")
