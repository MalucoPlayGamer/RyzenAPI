-- Lua provided by RyzenAPI
-- Game: addappid(1565840)

-- MAIN APPLICATION
addappid(1565840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565841, 1, "5f2d0f8cf76b25689f96b2c931cc8677eb8444c6a6aa641ea8aade9131094322")
