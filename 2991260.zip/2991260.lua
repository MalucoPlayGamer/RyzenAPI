-- Lua provided by RyzenAPI
-- Game: Game: AppID 2991260

-- MAIN APPLICATION
addappid(2991260)
-- Game: addappid(2991260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991261, 1, "2dde0e782515da833a1d7fbfd640dfb97670c5e1453a2d1977df7d34a8559eb1")
