-- Lua provided by RyzenAPI
-- Game: AppID 581620

-- MAIN APPLICATION
addappid(581620)
-- Game: addappid(581620)

-- MAIN APP DEPOTS / PACKAGES
addappid(581621, 1, "11e0a38eef81ab42030364ce0eb70d10b9117ca12b66642de3de7cfcf2bbc48e")
