-- Lua provided by RyzenAPI
-- Game: Game: Cafemart Simulator Demo

-- MAIN APPLICATION
addappid(3408620)
-- Game: addappid(3408620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408621, 1, "b9779ae1d1cf8f10545b37fe8f5c3399595ee0fb8295bc183922bc354b8f7b73")
