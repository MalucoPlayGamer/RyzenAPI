-- Lua provided by RyzenAPI 
-- Game: AppID 1934340
addappid(1934340)
addappid(1934341, 1, "a120407299875324d78263f6c00abd5d2553e67f677cfd0e5196076813fe1666")
