-- Lua provided by RyzenAPI
-- Game: Clutchtime™: Basketball Deckbuilder Demo

-- MAIN APPLICATION
addappid(3421020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421021, 1, "fa6458e9906e776d1b2dd8c62b06daf7a237a21db86a23742de44493759f09d7")

