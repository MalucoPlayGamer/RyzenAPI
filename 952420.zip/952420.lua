-- Lua provided by RyzenAPI
-- Game: Game: Shan Gui II: Sweet Osmanthus II

-- MAIN APPLICATION
addappid(952420)
-- Game: addappid(952420)

-- MAIN APP DEPOTS / PACKAGES
addappid(952421, 1, "6b73b6ef72e5909911dedf09e5d14801bd7c04631a4da7949d01b810db9892b4")
addappid(952422, 1, "71febf607436aa009925d1e521700edf8996b7119ca48fe162a4bcd51dc52fd5")
addappid(952423, 1, "b4279f9d9cd5801d03ad9f1a2a2e256a0358056bc1b1545a4b7e5c0fc7745523")
addappid(952424, 1, "0242744702c269085c1678b7407ecde1769f9bd3d01e6c8ad20b9b80915ebaf4")
