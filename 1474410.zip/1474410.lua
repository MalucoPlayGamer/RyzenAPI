-- Lua provided by RyzenAPI
-- Game: Game: Artillery Royale

-- MAIN APPLICATION
addappid(1474410)
-- Game: addappid(1474410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474411, 1, "5ff3aaa7de0b824afccf9971bed0edf12ad1db845296f7713fed620fc382d326")
