-- Lua provided by SkyAPI 
-- Game: Artillery Royale
addappid(1474410)
addappid(1474411, 1, "5ff3aaa7de0b824afccf9971bed0edf12ad1db845296f7713fed620fc382d326")
