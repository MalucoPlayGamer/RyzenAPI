-- Lua provided by RyzenAPI 
-- Game: Crossing Guard Joe
addappid(1701950)
addappid(1701951, 1, "c7fa987ddcefc5ea9650bc01cb1ea054d77e25cb87c87ad7ac2aa22c574b3da3")
