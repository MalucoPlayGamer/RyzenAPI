-- Lua provided by RyzenAPI
-- Game: Rock 'N Roll

-- MAIN APPLICATION
addappid(665930)
addappid(1035000)
-- Game: addappid(665930)

-- MAIN APP DEPOTS / PACKAGES
addappid(665931, 1, "7761315b8ffcdf71cdff59339bea8a4206975cc1da2d9e50f8386cd47921eda7")
