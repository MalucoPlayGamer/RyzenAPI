-- Lua provided by RyzenAPI
-- Game: Game: AppID 1876330

-- MAIN APPLICATION
addappid(1876330)
-- Game: addappid(1876330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876331, 1, "43404ca92b2abf1836434a8452e170f5271e421066ecef4a91b6acf865350d20")
