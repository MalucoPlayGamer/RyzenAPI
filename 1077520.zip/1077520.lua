-- Lua provided by RyzenAPI
-- Game: The Light Remake

-- MAIN APPLICATION
addappid(1077520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077521, 1, "ca25ee517c4526c396f04a78e42c7d51fded0bed90ec552fc6b9b2ba4ba67949")
