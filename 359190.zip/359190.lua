-- Lua provided by RyzenAPI
-- Game: addappid(359190)

-- MAIN APPLICATION
addappid(359190)

-- MAIN APP DEPOTS / PACKAGES
addappid(359191, 1, "aafe5e6be682d68b7eef6e8dd92a7ea71425a6abb43d98278eb4831c7db7c73f")
addappid(359192, 1, "37c2079f38c1bfc5dab5a0cb478570bb474f0c807f1c5e8a568160345d92366d")
addappid(359193, 1, "3ad3c08026e872587dec52c2adf3fd257525da9a3dcb24ee38311ae653c92c9a")
