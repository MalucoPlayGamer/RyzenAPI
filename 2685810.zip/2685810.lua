-- Lua provided by RyzenAPI
-- Game: Micro Macro Farm

-- MAIN APPLICATION
addappid(2685810)
-- Game: addappid(2685810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685811, 1, "c4def72b49df836f3f6b7b614806270fc19cf55f5e79b913e130ab615ad131f7")
