-- Lua provided by RyzenAPI
-- Game: Age of Darkness: Final Stand

-- MAIN APPLICATION
addappid(1426450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1426451, 1, "b09e3c9d0dffe091ddf8d16b5128f66f217374487676f92db0e2fc9c53ff6c6a")

