-- Lua provided by RyzenAPI
-- Game: 1426450

-- MAIN APPLICATION
addappid(1426450)
-- Game: addappid(1426450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426451, 1, "b09e3c9d0dffe091ddf8d16b5128f66f217374487676f92db0e2fc9c53ff6c6a")
