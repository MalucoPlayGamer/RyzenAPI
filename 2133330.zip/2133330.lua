-- Lua provided by RyzenAPI
-- Game: 2tinycowboys

-- MAIN APPLICATION
addappid(2133330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133331, 1, "1cb4865aa5211aafb3fd0c9d904f4ac954e3b6748f599e47948a72a40708eff6")
