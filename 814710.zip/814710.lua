-- Lua provided by RyzenAPI
-- Game: The Rhys510 Flash Back

-- MAIN APPLICATION
addappid(814710)

-- MAIN APP DEPOTS / PACKAGES
addappid(814711, 1, "220ebed2fcb4fd25dd7df3d8b1d9801d0e40c879a85b9823f4f3d686cd829553")

