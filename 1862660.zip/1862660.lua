-- Lua provided by RyzenAPI
-- Game: garage:VAMP

-- MAIN APPLICATION
addappid(1862660)
-- Game: addappid(1862660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862661, 1, "07d87c48f4349d8507efcde61bb47b2665ab7dca7b7232fc4ed424393707685a")
