-- Lua provided by RyzenAPI
-- Game: Furry Feet

-- MAIN APPLICATION
addappid(1694960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694961, 1, "ddabc1529488d01a1c8a6d509d594a463ca6c31ca0c0b771f6512b1877921f7b")
addappid(1719440, 0, "224a58989d3603ce4e33872b88794ac43a3d9cb71e7ef55dece1f6a4868d81e6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1740750)
addappid(2027100)
addappid(2100930)
addappid(2161290)
