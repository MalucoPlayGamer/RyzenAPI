-- Lua provided by RyzenAPI
-- Game: EQ - Countries

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1395060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395063,0,"7bde83e7295666097e7401f12151bc8f0737925d0b11d8f35af8c90b6d8346fb")
addtoken(1395060,2803863487441922714)

