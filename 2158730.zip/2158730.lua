-- Lua provided by RyzenAPI
-- Game: addappid(2158730)

-- MAIN APPLICATION
addappid(2158730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158732,0,"7d6de8c9818735d1522f0c713eeca3c24aafc9f37b3854465d954daa8f1d8f20")
