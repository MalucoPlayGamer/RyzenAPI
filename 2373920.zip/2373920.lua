-- Lua provided by RyzenAPI
-- Game: 2373920

-- MAIN APPLICATION
addappid(2373920)
-- Game: addappid(2373920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373921, 1, "f57009560daefdb4aa8949a0befc018a3494f0116db54c3ce9360e744f2bf951")
