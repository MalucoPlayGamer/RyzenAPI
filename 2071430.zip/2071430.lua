-- Lua provided by RyzenAPI
-- Game: Roots of Yggdrasil

-- MAIN APPLICATION
addappid(2071430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071431, 1, "a3cecd7bc7f8812e374379ac590aeba54403179de75170204fc5fe15f8054f2d")

