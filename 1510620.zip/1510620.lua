-- Lua provided by RyzenAPI
-- Game: Pocket Watch

-- MAIN APPLICATION
addappid(1510620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510621, 1, "e414c92c6f3c2acde81c436ead1f11e5611bdb27bc106e33ed125b46ea675f37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
