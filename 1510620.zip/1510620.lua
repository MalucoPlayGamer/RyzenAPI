-- Lua provided by RyzenAPI 
-- Game: Pocket Watch
addappid(1510620)
addappid(1510621, 1, "e414c92c6f3c2acde81c436ead1f11e5611bdb27bc106e33ed125b46ea675f37")
