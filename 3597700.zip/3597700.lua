-- Lua provided by SkyAPI 
-- Game: Obscula
addappid(3597700)
addappid(3597701, 1, "3b1c005254d14ec55e205e34aa7f8c9fd627eebbbb8349744859a159c52af6c3")
