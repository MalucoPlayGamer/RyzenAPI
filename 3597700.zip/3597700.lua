-- Lua provided by RyzenAPI
-- Game: Game: Obscula

-- MAIN APPLICATION
addappid(3597700)
-- Game: addappid(3597700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597701, 1, "3b1c005254d14ec55e205e34aa7f8c9fd627eebbbb8349744859a159c52af6c3")
