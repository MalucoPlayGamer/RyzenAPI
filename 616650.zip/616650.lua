-- Lua provided by RyzenAPI
-- Game: RetroFighter VR

-- MAIN APPLICATION
addappid(616650)

-- MAIN APP DEPOTS / PACKAGES
addappid(616651, 1, "0d75aef5752a3d282f20840dc10b0ae25b1da969ed402dc41eb43a754c27c7ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
