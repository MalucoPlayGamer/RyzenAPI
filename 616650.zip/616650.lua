-- Lua provided by RyzenAPI
-- Game: RetroFighter VR

-- MAIN APPLICATION
addappid(616650)

-- MAIN APP DEPOTS / PACKAGES
addappid(616651, 1, "0d75aef5752a3d282f20840dc10b0ae25b1da969ed402dc41eb43a754c27c7ae")

