-- Lua provided by RyzenAPI
-- Game: addappid(2330500)

-- MAIN APPLICATION
addappid(2330500)
addappid(2462780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330501, 1, "177c9f2585fe680cc52d1474d754d6b451f94f7eeff390d34cde3919f3de5e7e")
