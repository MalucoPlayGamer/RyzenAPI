-- Lua provided by RyzenAPI
-- Game: Shapelab

-- MAIN APPLICATION
addappid(571890)
addappid(3381020)
addappid(4199100)
-- Game: addappid(571890)

-- MAIN APP DEPOTS / PACKAGES
addappid(571891, 1, "5017f1a0787dfeedbc432513b04760372611eae377d5267077de9d7dea7f5a0a")
