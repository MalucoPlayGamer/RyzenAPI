-- Lua provided by RyzenAPI
-- Game: Game: Voids Vigil

-- MAIN APPLICATION
addappid(2738940)
-- Game: addappid(2738940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738941, 1, "3603dc361c00e237e30a3d9360b13727d8aba5d8957ba2918f5ecc79a2b233f7")
