-- Lua provided by RyzenAPI
-- Game: 2757450

-- MAIN APPLICATION
addappid(2757450)
-- Game: addappid(2757450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757451, 1, "b2c1a46262966cdef67c24e624286134cc34d826b565cf73b2245113af6b5b6b")
