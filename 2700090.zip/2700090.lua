-- Lua provided by RyzenAPI 
-- Game: Fox Game
addappid(2700090)
addappid(2700091, 1, "532f82418299efad726852b74c676b43b744e2d0fcb04c6392ba2ea29d6ce4f1")
