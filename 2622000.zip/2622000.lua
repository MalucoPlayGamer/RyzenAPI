-- Lua provided by RyzenAPI
-- Game: Astral Party

-- MAIN APPLICATION
addappid(2622000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622001, 1, "e349ff4cf458e371d7328d5f0d88575f8b0bcfc869cf31c4bf50ff6085999585")
