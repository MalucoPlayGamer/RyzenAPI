-- Lua provided by RyzenAPI
-- Game: Game: Is Simon There?

-- MAIN APPLICATION
addappid(1961300)
-- Game: addappid(1961300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961301, 1, "1760604af1b8f380bf0f73c43515840e142fb58230409e2b52104f4f56a8d854")
