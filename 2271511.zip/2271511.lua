-- Lua provided by RyzenAPI
-- Game: addappid(2271511)

-- MAIN APPLICATION
addappid(2271511)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271511,0,"0ad82031f0363d3e99fd03f770fbf2cd71302b8565f83cdd231b13d121e7d587")
