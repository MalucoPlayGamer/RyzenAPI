-- Lua provided by RyzenAPI
-- Game: Heart's Medicine - Doctor's Oath

-- MAIN APPLICATION
addappid(1262910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262919,0,"bcea8391f6e71fb3d81c7a9a696d1b03b7e4eb944f221b36ad1ce1a9858b5cd8")

