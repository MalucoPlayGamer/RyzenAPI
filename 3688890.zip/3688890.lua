-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization VII Development Tools

-- MAIN APPLICATION
addappid(3688890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688891, 1, "4ee7ab78ae88bf0e71ac0182ceb5c8893083b94fcb4c0d8ec7acec1f927f6d24")

