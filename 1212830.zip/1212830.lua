-- Lua provided by RyzenAPI
-- Game: Game: AppID 1212830

-- MAIN APPLICATION
addappid(1212830)
-- Game: addappid(1212830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212831, 1, "f9c6622fbf4ebb28b3c3f0edbc2387fa23c963e73b509f5a87f90ae5b6628c69")
addappid(1216160, 0, "f19a359bb3e510aab4cee92792ecef9cc17fad2886a8d167425423291fc1c096")
