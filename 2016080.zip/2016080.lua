-- Lua provided by RyzenAPI
-- Game: A Hero's Rest: An RPG Town Simulator

-- MAIN APPLICATION
addappid(2016080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016081, 1, "959e2adf82a5945cceb25dec696b59e798d2d3957ddbb553900c1203cdeb9d5d")
