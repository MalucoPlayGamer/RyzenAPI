-- Lua provided by RyzenAPI
-- Game: addappid(2841110)

-- MAIN APPLICATION
addappid(2841110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841112,0,"e38f75f5f278b7a77f41dc1b71edbe8febe44687a9c6c368cf5f73557ada866a")
