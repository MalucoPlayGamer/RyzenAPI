-- Lua provided by RyzenAPI
-- Game: Broken World

-- MAIN APPLICATION
addappid(2841110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2841112,0,"e38f75f5f278b7a77f41dc1b71edbe8febe44687a9c6c368cf5f73557ada866a")

