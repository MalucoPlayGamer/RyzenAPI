-- Lua provided by RyzenAPI
-- Game: Victorian Mysteries: Woman in White

-- MAIN APPLICATION
addappid(1101940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101941, 1, "b55268b0fb3b0a9ce2b33f3de90a201a7cbedbbeb5409d7aa5ac97311eceaf57")
addappid(1101942, 1, "aa65cb7463beee3783fe2fd99e586103b8c84eb20d311771711a4e797248294c")
