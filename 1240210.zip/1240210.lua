-- Lua provided by RyzenAPI
-- Game: There Is No Game: Wrong Dimension

-- MAIN APPLICATION
addappid(1240210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240211, 1, "3de7ca82e6f5ed632137a40a3633050d7391e2cb5a159413c08d6c651d5a53d4")
addappid(1240212, 1, "0319d81fd8d99a3ef1d5375ae235454cee90b22badbf100c22a95ad307051da0")
