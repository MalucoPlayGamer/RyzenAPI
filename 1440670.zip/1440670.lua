-- Lua provided by RyzenAPI
-- Game: Zeepkist

-- MAIN APPLICATION
addappid(1440670)
addappid(1699070)
addappid(1962260)
addappid(3316260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440671, 1, "155b8265af52ed31033c00e1caa583211219df22e5cddbe58ec6f271865349df")

