-- Lua provided by RyzenAPI
-- Game: Game: Zeepkist

-- MAIN APPLICATION
addappid(1440670)
-- Game: addappid(1440670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440671, 1, "155b8265af52ed31033c00e1caa583211219df22e5cddbe58ec6f271865349df")
