-- Lua provided by RyzenAPI
-- Game: addappid(960300)

-- MAIN APPLICATION
addappid(960300)

-- MAIN APP DEPOTS / PACKAGES
addappid(960301, 1, "4baf643e3015c5a2ec0f855f589ba46645aba541d8630de9084d195decfc21e4")
