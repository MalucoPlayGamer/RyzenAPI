-- Lua provided by RyzenAPI
-- Game: Where Are My Friends?

-- MAIN APPLICATION
addappid(721350)
addappid(737120)

-- MAIN APP DEPOTS / PACKAGES
addappid(721351, 1, "461c777b7ba1c9271980b160fcc111e57744582586024a8e1cae44913f951e81")
