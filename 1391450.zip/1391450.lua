-- Lua provided by RyzenAPI
-- Game: Case 00: The Cannibal Boy

-- MAIN APPLICATION
addappid(1391450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391451, 1, "583db9e76467ce67570b05dfa00a5da6995030e2131955cd24770f5a228e5614")

