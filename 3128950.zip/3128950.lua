-- Lua provided by RyzenAPI
-- Game: Borıng.

-- MAIN APPLICATION
addappid(3128950)

