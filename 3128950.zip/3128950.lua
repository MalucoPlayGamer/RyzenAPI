-- Lua provided by RyzenAPI
-- Game: Borıng.

-- MAIN APPLICATION
addappid(3128950)
addappid(3468050)
addappid(3584110)

