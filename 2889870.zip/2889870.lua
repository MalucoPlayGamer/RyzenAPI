-- Lua provided by RyzenAPI
-- Game: Rouge Tank

-- MAIN APPLICATION
addappid(2889870)
-- Game: addappid(2889870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889871, 1, "3c03dc5aa668555bb2a1d42814165f285d307af2421a7128361d652920abde97")
