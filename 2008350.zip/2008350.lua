-- Lua provided by RyzenAPI
-- Game: Crush Them！

-- MAIN APPLICATION
addappid(2008350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008351, 1, "31b1889184b0facc262860f5aa204799542c31fda0029867ca7e0eaa24713488")

