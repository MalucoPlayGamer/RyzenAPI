-- Lua provided by RyzenAPI
-- Game: Crankies Workshop: Whirlbot Assembly

-- MAIN APPLICATION
addappid(707370)

-- MAIN APP DEPOTS / PACKAGES
addappid(707371, 1, "3bcbbe58ee427719e8dc09e09fdd9e342e63c485b402b13e0eff662a24fec5c3")

