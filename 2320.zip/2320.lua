-- Lua provided by RyzenAPI
-- Game: Quake II

-- MAIN APPLICATION
addappid(2320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321, 1, "80fd8cab8082e032fd0702129b1a0e1d57ecedf155f5e6cfd3c8e1591bf18dc1")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

