-- Lua provided by RyzenAPI
-- Game: Sheltered 2

-- MAIN APPLICATION
addappid(1289380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1289381, 1, "5a80c7126088d70404c366225db68c0045251e228beda1ed4d025293952c878b")

