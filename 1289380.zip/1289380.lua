-- Lua provided by SkyAPI 
-- Game: AppID 1289380
addappid(1289380)
addappid(1289381, 1, "5a80c7126088d70404c366225db68c0045251e228beda1ed4d025293952c878b")
