-- Lua provided by RyzenAPI
-- Game: Game: AppID 1137460

-- MAIN APPLICATION
addappid(1137460)
-- Game: addappid(1137460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137461, 1, "595a0beb6eeb614cb9d3f2714adb31c9d0f5d045d5f362d6492e40c22ec0e61d")
