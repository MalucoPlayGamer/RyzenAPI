-- Lua provided by RyzenAPI
-- Game: addappid(434920)

-- MAIN APPLICATION
addappid(434920)

-- MAIN APP DEPOTS / PACKAGES
addappid(434921, 1, "b5c978446f1fe7ed1def146c94da615cdcafbe7e70f9fab1d70655714f5250b4")
