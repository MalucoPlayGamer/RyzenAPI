-- Lua provided by RyzenAPI
-- Game: addappid(2983840)

-- MAIN APPLICATION
addappid(2983840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983841, 1, "da2f17b69d97acf65b186313afbf19bf7c656d3f1bd90e335e736cd1e773dcca")
