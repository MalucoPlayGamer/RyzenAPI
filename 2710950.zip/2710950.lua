-- Lua provided by RyzenAPI
-- Game: Game: Revenge Of The Colon

-- MAIN APPLICATION
addappid(2710950)
-- Game: addappid(2710950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710951, 1, "ab16fc3484392735b11207b7c39ac95ea2a64db6c67768cfcf65676a3b6ec950")
