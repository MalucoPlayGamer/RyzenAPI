-- Lua provided by RyzenAPI
-- Game: Until the last

-- MAIN APPLICATION
addappid(709560)

-- MAIN APP DEPOTS / PACKAGES
addappid(709561, 1, "0a2381d9fdca03e3ea952ed067bd6ee3a622c72b2bc0a9033710cec102ab8c8f")
