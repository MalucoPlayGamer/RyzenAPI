-- Lua provided by RyzenAPI
-- Game: AppID 389700

-- MAIN APPLICATION
addappid(389700)

-- MAIN APP DEPOTS / PACKAGES
addappid(389701, 1, "89a1b5eb515c8cc0c074bd6cde8038a0fb15eb2ac46272093b07869d770732fe")

