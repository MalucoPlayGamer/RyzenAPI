-- Lua provided by RyzenAPI
-- Game: 1206410

-- MAIN APPLICATION
addappid(1206410)
-- Game: addappid(1206410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206411, 1, "cf2bd5df49a3f883f86249fe67c2df69341c652a568081cd0cf38f3932a89067")
