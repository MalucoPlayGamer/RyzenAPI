-- Lua provided by RyzenAPI
-- Game: Wave of Time

-- MAIN APPLICATION
addappid(1410580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410581, 1, "d721c50fa309c56f7fcfc827be01d8a5f485350b16fea71ce8d7f3871a590c74")
addappid(1410585, 1, "3784b04eed9eb006a93f559c91e3ea5a941e6132156e0575264c734a8cfb95f1")

