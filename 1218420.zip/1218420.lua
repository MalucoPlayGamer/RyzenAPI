-- Lua provided by RyzenAPI
-- Game: Game: rook

-- MAIN APPLICATION
addappid(1218420)
-- Game: addappid(1218420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218421, 1, "1d0377b60c29e35d8f8c487e1b0d3aa767607f7138fc5017c3109f0e92118a94")
