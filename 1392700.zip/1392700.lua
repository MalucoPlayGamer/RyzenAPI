-- Lua provided by RyzenAPI
-- Game: addappid(1392700)

-- MAIN APPLICATION
addappid(1392700)
addappid(1392701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
