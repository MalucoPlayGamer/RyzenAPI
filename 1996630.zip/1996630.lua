-- Lua provided by RyzenAPI
-- Game: Dungeon Keeper Gold™

-- MAIN APPLICATION
addappid(1996630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996631, 1, "5b25847576319e17eaf6894bf0c7a4134a6c7cbeab44c71b55fd26f91d5ccd73")
addappid(1996632, 1, "fc341f78d4eea657f10befee3ef9c5f71123f7474950fb4b1b3c55183f8f9d8a")
addappid(1996633, 1, "9c9fc6205bccd4836bc7cba17be8e3089080d307433448f9f4b0fcecc3dbd6e5")
addappid(1996634, 1, "aeb6e10dcf39f19329c66e02b2dedcf6457b361090dbd45eadfcb59a3060e3b3")
addappid(1996635, 1, "1dcc5e225b0c5bdab36129b1c2b9be403dbbda249a164e4034dfd31b22e2c6ec")
addappid(1996636, 1, "7c39e79ea4ec2fa3e1882d9559060eca24dfb59a2b178d5b8001ec2866ea0a03")
addappid(1996637, 1, "72f928e61f1284bc6820af20ca111ea03d3dbe8ce522048dc2afa2bfc4cadea1")
addappid(1996638, 1, "65f03ea84cbab83e360274694c604c7b5d0a8e97f7c6127b7d85569d8c0bb70b")
addappid(1996639, 1, "c95cd6d43ee6c0ae125ea0828b854a0cf076e97b7fdb062989c85fb40009d58c")
