-- Lua provided by RyzenAPI
-- Game: addappid(820860)

-- MAIN APPLICATION
addappid(820860)

-- MAIN APP DEPOTS / PACKAGES
addappid(820860,0,"fea4b8381cad3c59ba4a6aaae1eee9f48df7822ef15ce2f0b21e3fab485ca1bf")
