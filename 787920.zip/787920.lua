-- Lua provided by RyzenAPI
-- Game: Running Fable

-- MAIN APPLICATION
addappid(787920)

-- MAIN APP DEPOTS / PACKAGES
addappid(787922,0,"165cd3fe45fd79b6fc52d80437062486bd0fe1d5379bf11dee4845753a829d0d")
addappid(787923,0,"e1aeef4f75680fcade5695879812e71df1e9caa6eeb784371d36d312b6b96d3a")

