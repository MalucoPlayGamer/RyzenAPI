-- Lua provided by RyzenAPI
-- Game: Game: Squeakers II

-- MAIN APPLICATION
addappid(1631540)
-- Game: addappid(1631540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631541, 1, "8c631b9c864e2bb1478be803428638c2773e68239abf15f157a4e79d45a37d6d")
