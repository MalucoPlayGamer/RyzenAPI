-- Lua provided by RyzenAPI
-- Game: Tyler: Model 005

-- MAIN APPLICATION
addappid(573370)
-- Game: addappid(573370)

-- MAIN APP DEPOTS / PACKAGES
addappid(573371, 1, "353e9a873663e106122310d3d9ad15969fb286b94070e98091e128cbf0d61861")
