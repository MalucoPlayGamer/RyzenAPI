-- Lua provided by RyzenAPI
-- Game: addappid(946800)

-- MAIN APPLICATION
addappid(946800)

-- MAIN APP DEPOTS / PACKAGES
addappid(946801, 1, "37c766f66167ee36975b4106ba6a957505fa05409e8226ff2c2bf105cbbaab26")
