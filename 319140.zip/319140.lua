-- Lua provided by SkyAPI 
-- Game: Xeodrifter
addappid(319140)
addappid(319141, 1, "96b1339c225a811b0c385d5e4f59c2bd65835016c49b3a0e60d05715623d6d1f")
addappid(352490, 0, "75a78a41fb76c132838c3870373722ecb48b1df5742ce577227addd7a08ab805")
