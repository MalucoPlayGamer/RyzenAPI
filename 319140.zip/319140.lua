-- Lua provided by RyzenAPI
-- Game: Xeodrifter

-- MAIN APPLICATION
addappid(319140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(319141, 1, "96b1339c225a811b0c385d5e4f59c2bd65835016c49b3a0e60d05715623d6d1f")
addappid(352490, 0, "75a78a41fb76c132838c3870373722ecb48b1df5742ce577227addd7a08ab805")

