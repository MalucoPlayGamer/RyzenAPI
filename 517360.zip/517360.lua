-- Lua provided by RyzenAPI
-- Game: The Secret Order 4: Beyond Time

-- MAIN APPLICATION
addappid(517360)

-- MAIN APP DEPOTS / PACKAGES
addappid(517361, 1, "a2ac0b0c668cc10eb5b024ec112c4db5785f22f670ce4af6225aa9549ee1e25e")

