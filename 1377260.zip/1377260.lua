-- Lua provided by RyzenAPI 
-- Game: AppID 1377260
addappid(1377260)
addappid(1377261, 1, "6f6f1529653c4f15956c9849eb38361a7871f067fb166d2ebed168be32281c59")
addappid(1377263, 1, "372e34f30d2e7153f48d102f8a8ca709da6a0d3ed64cf1be21f81b3f17a9c2fb")
