-- Lua provided by RyzenAPI
-- Game: 2970600

-- MAIN APPLICATION
addappid(2970600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2970600,0,"bd805f35c8029fabdf9ee1255c1ec991b70145a052228a7dadc28ebbef18fcb5")
