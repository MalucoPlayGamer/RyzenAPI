-- Lua provided by RyzenAPI 
-- Game: AppID 803680
addappid(803680)
addappid(803681, 1, "26f0cc07eec49561b24c1f5c2a1287780eeafecbfd11fe0d1b97a5dd2d223c4a")
