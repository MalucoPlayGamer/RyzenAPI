-- Lua provided by RyzenAPI
-- Game: addappid(521750)

-- MAIN APPLICATION
addappid(521750)

-- MAIN APP DEPOTS / PACKAGES
addappid(521751, 1, "b47012396bac271b2f15eb2c630ccf9d1091d945954a3ae6c0c83bd2cdd961ed")
