-- 3795200's Lua and Manifest Created by Hubcap Manifest
-- Ultimate Pro Football Coach
-- Created: August 11, 2026 at 12:39:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3795200) -- Ultimate Pro Football Coach
-- MAIN APP DEPOTS
addappid(3795201, 1, "3cbd7736dfdee2ca3594bba77641426659733e01a59141de8f7d65092369d3da") -- Depot 3795201
setManifestid(3795201, "458656322406420401", 59598812)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)