-- Lua provided by RyzenAPI
-- Game: Ultimate Pro Football Coach

-- MAIN APPLICATION
addappid(3795200) -- Ultimate Pro Football Coach

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3795201, 1, "3cbd7736dfdee2ca3594bba77641426659733e01a59141de8f7d65092369d3da") -- Depot 3795201

