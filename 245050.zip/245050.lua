-- Lua provided by RyzenAPI 
-- Game: SpellForce 2 - Demons of the Past
addappid(245050)
addappid(245051, 1, "4581fc7e93628f2f1e04bf4a249860e63af6e06c5b1c29a98d387311115c9989")
addappid(245052, 1, "3f7a8803e6d7cf59e8a01667959a779e255e81494034dfdf05a65a161b972d02")
addappid(245053, 1, "87d23f5ba14023777d930b963b72d6de924f16deb1f63696f2ec2d21256d9e2a")
addappid(255410)
