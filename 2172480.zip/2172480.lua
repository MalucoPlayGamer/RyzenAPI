-- Lua provided by RyzenAPI
-- Game: 山门与幻境 Demo

-- MAIN APPLICATION
addappid(2172480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172481, 1, "986e3ccc9c92d70d2bbbd0bcdfe0e864113978a50b098e551cbd4431b3c039f2")
