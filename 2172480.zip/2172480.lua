-- Lua provided by RyzenAPI
-- Game: Game: AppID 2172480

-- MAIN APPLICATION
addappid(2172480)
-- Game: addappid(2172480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172481, 1, "986e3ccc9c92d70d2bbbd0bcdfe0e864113978a50b098e551cbd4431b3c039f2")
