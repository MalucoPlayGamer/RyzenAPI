-- Lua provided by RyzenAPI
-- Game: Ruthless Conquest

-- MAIN APPLICATION
addappid(1193550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193551, 1, "d0bc307e226407db36b89cf702b087594925ae4736cf434cfcc8fe292b441d68")
