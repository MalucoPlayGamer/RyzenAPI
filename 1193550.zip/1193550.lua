-- Lua provided by RyzenAPI
-- Game: Ruthless Conquest

-- MAIN APPLICATION
addappid(1193550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193551, 1, "d0bc307e226407db36b89cf702b087594925ae4736cf434cfcc8fe292b441d68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
