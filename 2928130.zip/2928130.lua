-- Lua provided by RyzenAPI
-- Game: Yixin

-- MAIN APPLICATION
addappid(2928130)
addappid(3735920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928131, 1, "dad5f54e73042084feb63f842b01d33d4d0909bd59c226054d12567546e0c063")

