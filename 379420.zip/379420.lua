-- Lua provided by RyzenAPI
-- Game: addappid(379420)

-- MAIN APPLICATION
addappid(379420)

-- MAIN APP DEPOTS / PACKAGES
addappid(379422,0,"5001799c8649f28421c852930bca017649eab868d8d9ea8bfe22ef9145ba1b13")
