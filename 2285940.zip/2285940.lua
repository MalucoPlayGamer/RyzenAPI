-- Lua provided by RyzenAPI
-- Game: addappid(2285940)

-- MAIN APPLICATION
addappid(2285940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285942,0,"ac0883ea64c687445fb1b7de9b83d174ed78d2542886907bd59362adba8c033a")
