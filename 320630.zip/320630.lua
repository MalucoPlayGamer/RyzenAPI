-- Lua provided by RyzenAPI
-- Game: Game: Season Match

-- MAIN APPLICATION
addappid(320630)
-- Game: addappid(320630)

-- MAIN APP DEPOTS / PACKAGES
addappid(320631, 1, "f8c14b6d55ee9c7088121824d91fbe8e1110bd809555f280bbe2cbef69a36da6")
addappid(320632, 1, "14e22aea2d60260a558b94369c3515b795fa5304760af54bdf4f397ffc8c430e")
addappid(320633, 1, "73ddea03a7b5b0b19319a3ac88b51f1aa3ec4145256b44433c7b7e1ce6380018")
addappid(320634, 1, "0a947fb8bf0ef8b43335e79e7b30b8b7c1d1d8913b9dde42ea29a2e50e52a6f2")
addappid(320635, 1, "c6fc436bf9591460ade1d09f79fa70e5a0b33e5a62625962f38324b8eb99e180")
addappid(320636, 1, "af0777ffbd04ef4dd781e56801b98a8c95d0fcbce1d128862c649f466f6dd2e9")
