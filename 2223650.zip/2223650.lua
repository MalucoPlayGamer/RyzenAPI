-- Lua provided by RyzenAPI
-- Game: AppID 2223650

-- MAIN APPLICATION
addappid(2223650)
-- Game: addappid(2223650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223651, 1, "28c7112365ad0d720c3c1f4905cc4a6be680093797cc06003bf8843debb3b0cc")
