-- Lua provided by RyzenAPI
-- Game: Game: AppID 633080

-- MAIN APPLICATION
addappid(633080)
-- Game: addappid(633080)

-- MAIN APP DEPOTS / PACKAGES
addappid(633081, 1, "021a43b634a029d8933d6ecdbe24136044a180bbcddc541b424ff8ade92610a4")
addappid(633082, 1, "10415203eebf6fafe49bbad9176592102832204dd4788609dcf68c9b09fa5540")
addappid(2575460, 0, "b0dde1c4d1c744cdf744fc056f92bb4834e9152c0df481a415d77c97a8f5bca0")
