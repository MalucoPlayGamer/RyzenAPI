-- Lua provided by RyzenAPI
-- Game: addappid(1022396)

-- MAIN APPLICATION
addappid(1022396)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022396,0,"732b3f6f6797eedbba71e01a5ce432ad947d9c7bb8b1d1a0305594d8c25e5874")
