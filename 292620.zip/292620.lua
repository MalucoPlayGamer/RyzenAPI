-- Lua provided by RyzenAPI
-- Game: Game: Pressured

-- MAIN APPLICATION
addappid(292620)
-- Game: addappid(292620)

-- MAIN APP DEPOTS / PACKAGES
addappid(292621, 1, "09bfee949f0f91256aaf4ced48337ad7d88b684cd033d240b891035653299df8")
