-- Lua provided by RyzenAPI
-- Game: Pressured

-- MAIN APPLICATION
addappid(292620)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(292621, 1, "09bfee949f0f91256aaf4ced48337ad7d88b684cd033d240b891035653299df8")

