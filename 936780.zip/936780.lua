-- Lua provided by RyzenAPI
-- Game: Warplanes: WW2 Dogfight

-- MAIN APPLICATION
addappid(936780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(936781, 1, "db99ed066ce7fe067e993e7e9ffda1b6f84d51f22773715ad458fc9c7144f597")
addappid(936782, 1, "bb813d21cacba7eda42288c3831a711659501100da8a7444a0bade98a1d8b5f3")
addappid(936783, 1, "68eaaf74212ddefaf4890375244621527b7c31e03783d0a3a938fd221c8f5a28")
