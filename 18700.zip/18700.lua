-- Lua provided by RyzenAPI
-- Game: AppID 18700

-- MAIN APPLICATION
addappid(18700)
-- Game: addappid(18700)

-- MAIN APP DEPOTS / PACKAGES
addappid(18701, 1, "f50b667fa96307d56e0f380893c33854c54696c886c15b47aaa15f6e915eea95")
addappid(18702, 1, "72d90006a67fefbe1170ceff4ba85ca1a857144d45a132e3a1912e75002fe272")
addappid(18703, 1, "737c8e91fcf00c93c6638a21c345a9741ff3b49ef3d0abbe991f1d25cdb8ba86")
