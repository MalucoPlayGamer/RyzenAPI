-- Lua provided by RyzenAPI 
-- Game: AppID 1239580
addappid(1239580)
addappid(1239581, 1, "286d09a8c1b17a1dce76ac5209ff0dcb14b92bceb4ab20a7bcb73174218e2216")
