-- Lua provided by RyzenAPI
-- Game: addappid(2888460)

-- MAIN APPLICATION
addappid(2888460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888460,0,"47f86a13809c32798e3c3c8906a9333eb3057caeaaa4d74104fce85b1e560bfc")
