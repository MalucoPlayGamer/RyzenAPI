-- Lua provided by RyzenAPI
-- Game: BPM: BULLETS PER MINUTE

-- MAIN APPLICATION
addappid(1286350)
-- Game: addappid(1286350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286351, 1, "2a7a7ad9c894a1677dc5b9841b915ffe4eeadbed7981da220993c6f463b077d4")
