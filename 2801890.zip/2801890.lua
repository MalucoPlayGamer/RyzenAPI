-- Lua provided by RyzenAPI
-- Game: 99 Waves Demo

-- MAIN APPLICATION
addappid(2801890)
-- Game: addappid(2801890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2801891, 1, "e0da9a437cf4c39536adb51b6da367d3f9debf4c883fbce74738cda977e64263")
