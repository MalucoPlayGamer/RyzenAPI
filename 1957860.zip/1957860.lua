-- Lua provided by RyzenAPI
-- Game: 1957860

-- MAIN APPLICATION
addappid(1957860)
-- Game: addappid(1957860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957861, 1, "00f1044240c86cb82b228f87efd91792df3bd6f96136645d1cbae73bc4a2b196")
