-- Lua provided by SkyAPI 
-- Game: Break Siege Demo
addappid(3249780)
addappid(3249781, 1, "b049a11f4121345aa0a07f81d5ff80d0651c67a885abfbd8be0a3ebe4ae97c6c")
