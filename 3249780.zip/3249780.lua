-- Lua provided by RyzenAPI
-- Game: Break Siege Demo

-- MAIN APPLICATION
addappid(3249780)
-- Game: addappid(3249780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249781, 1, "b049a11f4121345aa0a07f81d5ff80d0651c67a885abfbd8be0a3ebe4ae97c6c")
