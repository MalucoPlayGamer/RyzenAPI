-- Lua provided by RyzenAPI
-- Game: Ctrl CV

-- MAIN APPLICATION
addappid(502130)
addappid(866290)

-- MAIN APP DEPOTS / PACKAGES
addappid(502131, 1, "41f31b58d71e3f102af59565cc4b9d1a20f608cd2ba29dac7b19aa94dca96cd1")

