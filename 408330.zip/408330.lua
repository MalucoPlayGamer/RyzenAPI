-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Dark Nexus Arena

-- MAIN APPLICATION
addappid(408330)
addappid(408390)
addappid(425420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(408331, 1, "1b425d37d49b006c2c12d5646da36be6c0f9cb096bb9bf3d2207aca04e5ac5e9")

