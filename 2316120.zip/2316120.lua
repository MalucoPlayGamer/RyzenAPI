-- Lua provided by RyzenAPI
-- Game: Retrace the Light Demo

-- MAIN APPLICATION
addappid(2316120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316123,0,"24fc740b5ed7dd4adb4c39e6ddf7e116ff91356d20a66ab6142a6952dadc5788")
