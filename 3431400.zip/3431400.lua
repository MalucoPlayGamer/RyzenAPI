-- Lua provided by RyzenAPI
-- Game: Crimson Covenant

-- MAIN APP DEPOTS / PACKAGES
addappid(3431400, 1, "b1aaa55a699d99480619e2f51d79d224667763b2c80e53fccaea7d328b6c8fe8") -- Crimson Covenant
addappid(3431402, 1, "a7e9e2a79fbe8464a6dde724712a991babad22ced458aecfec2bfb4bab620308") -- Depot 3431402

