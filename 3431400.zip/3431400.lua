-- 3431400's Lua and Manifest Created by Hubcap Manifest
-- Crimson Covenant
-- Created: August 21, 2026 at 01:46:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3431400, 1, "b1aaa55a699d99480619e2f51d79d224667763b2c80e53fccaea7d328b6c8fe8") -- Crimson Covenant
-- MAIN APP DEPOTS
addappid(3431402, 1, "a7e9e2a79fbe8464a6dde724712a991babad22ced458aecfec2bfb4bab620308") -- Depot 3431402
setManifestid(3431402, "357336213063927136", 10277621085)