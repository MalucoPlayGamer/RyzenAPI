-- Lua provided by RyzenAPI
-- Game: The Tavern of Magic

-- MAIN APPLICATION
addappid(777250)

-- MAIN APP DEPOTS / PACKAGES
addappid(777259,0,"b9f9878f1279efd08c7a71a0a78320e69f708305203e67f74459579ae93fc2fd")

