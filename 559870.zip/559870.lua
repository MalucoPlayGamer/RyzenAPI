-- Lua provided by RyzenAPI
-- Game: Game: AppID 559870

-- MAIN APPLICATION
addappid(559870)
-- Game: addappid(559870)

-- MAIN APP DEPOTS / PACKAGES
addappid(559871, 1, "ec9d2d15d1d4a62c7077ab6a0be9d3610020cffdfed96372fb07fb0e5bd7daf4")
