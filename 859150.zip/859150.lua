-- Lua provided by RyzenAPI
-- Game: 幻想三國誌５/Fantasia Sango 5

-- MAIN APPLICATION
addappid(859150)
addappid(899070)
addappid(1860980)

-- MAIN APP DEPOTS / PACKAGES
addappid(859151,0,"9fad3139fbb628f7b53681e5b79407863f3d565099b1f321b95f0cfe2127cc65")

