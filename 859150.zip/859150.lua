-- Lua provided by RyzenAPI
-- Game: 859150

-- MAIN APPLICATION
addappid(859150)
-- Game: addappid(859150)

-- MAIN APP DEPOTS / PACKAGES
addappid(859151, 1, "9fad3139fbb628f7b53681e5b79407863f3d565099b1f321b95f0cfe2127cc65")
