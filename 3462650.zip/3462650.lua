-- Lua provided by RyzenAPI
-- Game: Creepshow

-- MAIN APP DEPOTS / PACKAGES
addappid(3462650, 1, "e2d2216b548e8c5dbc421775503051812927951dc604df8acf26213dcd76ca07") -- Creepshow
addappid(3462651, 1, "86b9ea9169538dcfad682eea55de799369124b63a89ff8f0160fab14ce06c82e") -- Depot 3462651

