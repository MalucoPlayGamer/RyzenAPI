-- 3462650's Lua and Manifest Created by Hubcap Manifest
-- Creepshow
-- Created: August 14, 2026 at 11:06:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3462650, 1, "e2d2216b548e8c5dbc421775503051812927951dc604df8acf26213dcd76ca07") -- Creepshow
-- MAIN APP DEPOTS
addappid(3462651, 1, "86b9ea9169538dcfad682eea55de799369124b63a89ff8f0160fab14ce06c82e") -- Depot 3462651
setManifestid(3462651, "3254145047207533536", 2796665478)