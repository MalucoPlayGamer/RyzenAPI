-- Lua provided by RyzenAPI
-- Game: Bug N Out

-- MAIN APPLICATION
addappid(463130)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(463131, 1, "18d5342943bf29e8c1f0b5299261a002072e61ca45d2c31cafd1072031b46beb")

