-- Lua provided by RyzenAPI
-- Game: Bug N Out

-- MAIN APPLICATION
addappid(463130)

-- MAIN APP DEPOTS / PACKAGES
addappid(463131, 1, "18d5342943bf29e8c1f0b5299261a002072e61ca45d2c31cafd1072031b46beb")
