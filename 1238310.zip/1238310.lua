-- Lua provided by SkyAPI 
-- Game: AppID 1238310
addappid(1238310)
addappid(1238311, 1, "c9ea15c54ca9a13eb373c9d734095d3e46fa2be3f0faf6977c44385d92899c15")
