-- Lua provided by RyzenAPI
-- Game: Pape Rangers Demo

-- MAIN APPLICATION
addappid(2865170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865171, 1, "a2a5828868952ac09dadf447e760a93297f6f581c537c35e17082a43c0e392ce")

