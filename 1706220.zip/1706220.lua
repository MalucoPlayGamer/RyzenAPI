-- Lua provided by RyzenAPI
-- Game: 1706220

-- MAIN APPLICATION
addappid(1706220)
-- Game: addappid(1706220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706221, 1, "a2a80cc41167596c943f76ea3b3f06d2188cad2ebcc6da2341221a87437af256")
