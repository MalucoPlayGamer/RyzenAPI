-- Lua provided by RyzenAPI 
-- Game: AppID 721510
addappid(721510)
addappid(721511, 1, "f050e31f742e9be4cb7a00782c754c55c809609f65c6359504d3ccaee16ccf86")
