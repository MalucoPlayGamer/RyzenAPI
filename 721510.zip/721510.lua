-- Lua provided by RyzenAPI
-- Game: AppID 721510

-- MAIN APPLICATION
addappid(721510)
-- Game: addappid(721510)

-- MAIN APP DEPOTS / PACKAGES
addappid(721511, 1, "f050e31f742e9be4cb7a00782c754c55c809609f65c6359504d3ccaee16ccf86")
