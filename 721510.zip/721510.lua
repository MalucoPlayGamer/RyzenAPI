-- Lua provided by RyzenAPI
-- Game: AppID 721510

-- MAIN APPLICATION
addappid(721510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(721511, 1, "f050e31f742e9be4cb7a00782c754c55c809609f65c6359504d3ccaee16ccf86")

