-- Lua provided by RyzenAPI
-- Game: Game: Ace of Protectors

-- MAIN APPLICATION
addappid(398150)
-- Game: addappid(398150)

-- MAIN APP DEPOTS / PACKAGES
addappid(398151, 1, "3dd4b93a6d8e75b9f8c6ee0f52d0bc21be5e32241c13c5814798225346c55b0a")
addappid(398152, 1, "535a1045c1cf23df02e5c3b66e4cd27942b95fedba4d1f5743cb891055de869f")
addappid(398153, 1, "50275fde80b72bf1544239e3c4b3abb599dc7386e11a06b6021fd12292101f58")
