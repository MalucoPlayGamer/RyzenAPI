-- Lua provided by RyzenAPI
-- Game: AppID 1191420

-- MAIN APPLICATION
addappid(1191420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191421, 1, "b2e1672ad4769647a296cd73992c3a382bd842ba345b80008caf1e7d0c03cd2b")
addappid(1191422, 1, "41f0de9e94a7b8066487e03b41ae85bb0435ee8e2e88bc6aa94a84c8b325acfe")
addappid(1191424, 1, "3e5d47f36b9ac2435cadee4d64aee4659d038a7be6eb44b7672ac1acc761c80e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
