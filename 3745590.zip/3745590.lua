-- Lua provided by RyzenAPI
-- Game: little game

-- MAIN APPLICATION
addappid(3745590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3745591, 1, "599925ae10c55312b39617047b38e6c88442c7d04b2d520d0dc4aaf29df5308e")
