-- Lua provided by RyzenAPI
-- Game: Temanava

-- MAIN APPLICATION
addappid(2226000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226001, 1, "084de1ab425b2e77b38d39fd690e35576c79916b7e0b32ca34643b511e8ec3a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
