-- Lua provided by RyzenAPI
-- Game: 2226000

-- MAIN APPLICATION
addappid(2226000)
-- Game: addappid(2226000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226001, 1, "084de1ab425b2e77b38d39fd690e35576c79916b7e0b32ca34643b511e8ec3a1")
