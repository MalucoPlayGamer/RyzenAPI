-- Lua provided by RyzenAPI 
-- Game: Bartender Hustle
addappid(1153210)
addappid(1153211, 1, "383492ab20d25c3a20bba2747bb96ca380c9be744957ea76d99f587c4ad2688e")
