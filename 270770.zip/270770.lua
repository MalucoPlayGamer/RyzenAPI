-- Lua provided by RyzenAPI
-- Game: Game: Etherlords

-- MAIN APPLICATION
addappid(270770)
-- Game: addappid(270770)

-- MAIN APP DEPOTS / PACKAGES
addappid(270771, 1, "93d68355b60d76307c44061c253a3aa0ffa10015aa25b64f8fc49a029886eff7")
addappid(270772, 1, "b9ee8d18aaaafaca7c57bdcd1fa9d65515ffb15aab1e4bdbd1a9c110b9aab328")
