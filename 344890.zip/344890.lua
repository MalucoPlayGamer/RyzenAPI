-- Lua provided by RyzenAPI
-- Game: Game: A.R.M. PLANETARY PROSPECTORS EP1 Asteroid Resource Mining

-- MAIN APPLICATION
addappid(344890)
-- Game: addappid(344890)

-- MAIN APP DEPOTS / PACKAGES
addappid(344891, 1, "7b865a22c39be1f254f72169735304bee1e6ee4c51dcb18dc7d66f83e15fa5ab")
