-- Lua provided by RyzenAPI
-- Game: 344890

-- MAIN APPLICATION
addappid(344890)
-- Game: addappid(344890)

-- MAIN APP DEPOTS / PACKAGES
addappid(344891, 1, "7b865a22c39be1f254f72169735304bee1e6ee4c51dcb18dc7d66f83e15fa5ab")
