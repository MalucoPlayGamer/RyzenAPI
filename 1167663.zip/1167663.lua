-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! at the Disco - "High Hopes"

-- MAIN APPLICATION
addappid(1167663)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167663,0,"cb0a1189e7401dd3ad3510c0067234e129f7614e4c67e4fcf7cd0e047685bb68")

