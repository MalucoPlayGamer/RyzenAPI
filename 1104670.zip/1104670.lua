-- Lua provided by RyzenAPI
-- Game: 1104670

-- MAIN APPLICATION
addappid(1104670)
-- Game: addappid(1104670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104671, 1, "8a223728710c2a89aea1264bb5d374a7701e4739854edd6ee74f44cf037ab1c9")
