-- Lua provided by RyzenAPI
-- Game: Game: AppID 891370

-- MAIN APPLICATION
addappid(891370)
-- Game: addappid(891370)

-- MAIN APP DEPOTS / PACKAGES
addappid(891371, 1, "3867a6a91ed55c9b97cd83df3e94637a66b18d8f01c62b8de86d64deb6591fb3")
