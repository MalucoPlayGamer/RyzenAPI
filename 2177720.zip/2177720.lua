-- Lua provided by RyzenAPI
-- Game: Missing Pictures : Lee Myung Se

-- MAIN APPLICATION
addappid(2177720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2177721, 1, "3a5fa75c750e64ed28e00f43dd0a16705e3504cb47dc9b128b059bd43f57dd9d")

