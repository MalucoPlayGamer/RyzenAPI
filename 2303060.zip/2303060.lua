-- Lua provided by RyzenAPI
-- Game: Film Studio Manager

-- MAIN APPLICATION
addappid(2303060)
-- Game: addappid(2303060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303061, 1, "5a7b3c69ddb1e330851425ba1f906356eb7fa2019a8b58e6e2624583566f1b63")
