-- Lua provided by RyzenAPI 
-- Game: Film Studio Manager
addappid(2303060)
addappid(2303061, 1, "5a7b3c69ddb1e330851425ba1f906356eb7fa2019a8b58e6e2624583566f1b63")
