-- Lua provided by RyzenAPI
-- Game: Game: Blazing Priestess Shizune

-- MAIN APPLICATION
addappid(2510830)
-- Game: addappid(2510830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510831, 1, "b21d09b98af16128b56ce28c28eda205f878648559e1b80bcfbf25c519e910ac")
addappid(2510832, 1, "c71fe87b0b6280b5763fcc3bbf1fb983db288f3acb8a4bbd07c86bc7539591da")
addappid(2510833, 1, "461df89e51a4fa6738654c0efe19239b0722d11a7729fa85e86bd0c897e5c052")
