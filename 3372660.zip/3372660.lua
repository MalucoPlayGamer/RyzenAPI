-- Lua provided by RyzenAPI
-- Game: addappid(3372660)

-- MAIN APPLICATION
addappid(3372660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372661, 1, "185b8804061e24b82cb680732da90ec790a56ac59ef0e9c3f7c0243ca9acf08e")
