-- Lua provided by RyzenAPI
-- Game: AppID 987570

-- MAIN APPLICATION
addappid(987570)

-- MAIN APP DEPOTS / PACKAGES
addappid(987571, 1, "cdec39f166528ec2d4a74045a3c52b2079ca5084d7c36e244394b56ec5b0b9cd")
addappid(987572, 1, "6c66555ad1541f5d6a171fafa660ac1a61f5bde5b07a024c1b9e563e3ffc1ed6")

