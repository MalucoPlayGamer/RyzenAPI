-- Lua provided by RyzenAPI
-- Game: Zombie Town Breakout

-- MAIN APPLICATION
addappid(3600670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3600671, 1, "5e601e6283a47b487e5969b0cc908223eb6a4ead2735eac08756499d8b6e1881")

