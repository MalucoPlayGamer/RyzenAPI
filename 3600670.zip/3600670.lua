-- Lua provided by RyzenAPI
-- Game: Zombie Town Breakout

-- MAIN APPLICATION
addappid(3600670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600671, 1, "5e601e6283a47b487e5969b0cc908223eb6a4ead2735eac08756499d8b6e1881")
