-- Lua provided by RyzenAPI
-- Game: Fear Effect Sedna Demo

-- MAIN APPLICATION
addappid(639010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(639011, 1, "46e6dd6db42b6fa9984bf66c16e03dcc6e75986bed959108d31c781a379b1203")
