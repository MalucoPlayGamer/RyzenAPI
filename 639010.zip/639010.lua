-- Lua provided by RyzenAPI
-- Game: AppID 639010

-- MAIN APPLICATION
addappid(639010)
-- Game: addappid(639010)

-- MAIN APP DEPOTS / PACKAGES
addappid(639011, 1, "46e6dd6db42b6fa9984bf66c16e03dcc6e75986bed959108d31c781a379b1203")
