-- Lua provided by SkyAPI 
-- Game: AppID 639010
addappid(639010)
addappid(639011, 1, "46e6dd6db42b6fa9984bf66c16e03dcc6e75986bed959108d31c781a379b1203")
