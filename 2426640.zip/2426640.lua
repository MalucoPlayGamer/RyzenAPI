-- Lua provided by RyzenAPI
-- Game: addappid(2426640)

-- MAIN APPLICATION
addappid(2426640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426641, 1, "60127bcc37f176810d7f709bc328b12d612e99fe3a4d251a2ab8c516522bbfec")
