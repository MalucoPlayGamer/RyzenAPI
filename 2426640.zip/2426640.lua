-- Lua provided by RyzenAPI
-- Game: Kobold Castle

-- MAIN APPLICATION
addappid(2426640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2426641, 1, "60127bcc37f176810d7f709bc328b12d612e99fe3a4d251a2ab8c516522bbfec")

