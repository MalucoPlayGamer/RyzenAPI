-- Lua provided by RyzenAPI
-- Game: 558440

-- MAIN APPLICATION
addappid(558440)
addappid(565070)
-- Game: addappid(558440)

-- MAIN APP DEPOTS / PACKAGES
addappid(558441, 1, "b047084c346259ae34e67a9adb3348124c2b779c91ed92c7ab353706f22ddf5a")
