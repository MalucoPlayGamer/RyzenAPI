-- Lua provided by RyzenAPI
-- Game: Blaster Multiplayer

-- MAIN APPLICATION
addappid(2731180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731181, 1, "c99b9fd20244f49acb1891e5b901ed6a3199ca41e66b3d6e0cda020fdf225d10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
