-- Lua provided by SkyAPI 
-- Game: EMMA The Story
addappid(831720)
addappid(831721, 1, "708004fb50d7c92d9697e09e8755e0a38b1b246e6aa74d9e7279ea204384e595")
addappid(854880, 0, "0dbbb2144f40bf08fa9a664291ee9a8570fcd3d7bd913546bfc728f7c466f982")
