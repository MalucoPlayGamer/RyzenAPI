-- Lua provided by RyzenAPI
-- Game: 1197570

-- MAIN APPLICATION
addappid(1197570)
-- Game: addappid(1197570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197571, 1, "211325882dfccb994264bdab23f45ae559560faf05c18b401f278baf528fc91c")
