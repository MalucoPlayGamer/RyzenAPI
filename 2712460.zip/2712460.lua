-- Lua provided by RyzenAPI
-- Game: DUNGEON SLASHER

-- MAIN APPLICATION
addappid(2712460)

