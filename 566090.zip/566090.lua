-- Lua provided by RyzenAPI
-- Game: The Bard's Tale IV: Barrows Deep

-- MAIN APPLICATION
addappid(566090)
addappid(948540)
addappid(948541)
addappid(948542)
addappid(948550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(566091, 1, "fe0557c9ba3ba5c0cabd9d01e7f924c34f5232a103ce380106cfa045d80783bc")
addappid(566092, 1, "2f365ec001f9033ac3174a60637807de98a145f6b5b226dccbf10601b98fe527")
addappid(566093, 1, "67e76d413e36461db77a21a9507e415f934d8657844e21f40c985e1497ee1fe0")
addappid(566102, 1, "282ebcb06b1b8f1456bc6fb28a091282dac5e2f0a92787de8acff2628c272188")

