-- Lua provided by RyzenAPI
-- Game: Memory Match Saga

-- MAIN APPLICATION
addappid(1190640)
addappid(1196220)
addappid(1196700)
addappid(1197040)
addappid(1197970)
addappid(1198010)
addappid(1198350)
addappid(1198560)
addappid(1199580)
addappid(1199670)
addappid(1199920)
addappid(1200470)
addappid(1200820)
addappid(1200830)
addappid(1200940)
addappid(1201010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190641, 1, "d04c9897cbe0e3f6c57fc82ca7abff338046f41d4d531d7cd456962d96fc07eb")
