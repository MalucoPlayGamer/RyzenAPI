-- Lua provided by RyzenAPI 
-- Game: Ninjin: Clash of Carrots
addappid(809870)
addappid(809871, 1, "e0327809f14b1d442411862f2796fba511c10fb13594910e4248b452c94c9f8d")
addappid(931960, 0, "9410c67e5bb70258da497825371b2abe652c283a625a26541ac4ef050cd61914")
