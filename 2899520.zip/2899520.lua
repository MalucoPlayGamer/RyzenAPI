-- Lua provided by RyzenAPI
-- Game: The Count Lucanor Soundtrack

-- MAIN APPLICATION
addappid(2899520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899521, 1, "a9834dac507086e47b2a0bc2452e033a121ad7bebbec87e3d6a28b9caf8dff75")

