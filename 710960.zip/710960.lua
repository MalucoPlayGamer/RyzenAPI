-- Lua provided by RyzenAPI
-- Game: Enceladus

-- MAIN APPLICATION
addappid(710960)
-- Game: addappid(710960)

-- MAIN APP DEPOTS / PACKAGES
addappid(710961, 1, "c72ba05f269f8af074611af3f247f1eb7f4437b59604064f7c955ba5e4c4bd63")
