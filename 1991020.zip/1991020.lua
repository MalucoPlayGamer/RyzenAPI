-- Lua provided by RyzenAPI
-- Game: Karagon: Prelude

-- MAIN APPLICATION
addappid(1991020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991021, 1, "db0f258cc17c498fe5b7fa60ac04d4c33c41638d01528802abb352e07e63e298")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
