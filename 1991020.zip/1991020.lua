-- Lua provided by RyzenAPI
-- Game: Karagon: Prelude

-- MAIN APPLICATION
addappid(1991020)
-- Game: addappid(1991020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991021, 1, "db0f258cc17c498fe5b7fa60ac04d4c33c41638d01528802abb352e07e63e298")
