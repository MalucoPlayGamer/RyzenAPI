-- Lua provided by RyzenAPI
-- Game: AppID 666180

-- MAIN APPLICATION
addappid(666180)
-- Game: addappid(666180)

-- MAIN APP DEPOTS / PACKAGES
addappid(666181, 1, "8248ae7280f3f96e63fdb170cb9a84ea6024c90d542e58c09d31557e49fd6289")
