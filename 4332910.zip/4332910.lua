-- 4332910's Lua and Manifest Created by Hubcap Manifest
-- Twisted Party
-- Created: August 25, 2026 at 13:14:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4332910) -- Twisted Party
-- MAIN APP DEPOTS
addappid(4332911, 1, "ae96627c80fd387fe7fa25b97acf62a2729ab16191a71bf61a221611c229847b") -- Depot 4332911
setManifestid(4332911, "9018700253703794495", 726514064)
addappid(4332912, 1, "37c97899c9a2106bcb56c0f92b961bde7e4b35c4604f766f6fea524fef34208b") -- Depot 4332912
setManifestid(4332912, "9200593367445027320", 713998732)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5020450) -- Twisted Party - Supporter Pack