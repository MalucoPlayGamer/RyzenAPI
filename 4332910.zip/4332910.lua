-- Lua provided by RyzenAPI
-- Game: Twisted Party

-- MAIN APPLICATION
addappid(4332910) -- Twisted Party
addappid(5020450) -- Twisted Party - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(4332911, 1, "ae96627c80fd387fe7fa25b97acf62a2729ab16191a71bf61a221611c229847b") -- Depot 4332911
addappid(4332912, 1, "37c97899c9a2106bcb56c0f92b961bde7e4b35c4604f766f6fea524fef34208b") -- Depot 4332912

