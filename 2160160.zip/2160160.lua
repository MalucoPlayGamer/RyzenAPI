-- Lua provided by SkyAPI 
-- Game: AppID 2160160
addappid(2160160)
addappid(2160161, 1, "ac15f817af9a8795caa67e0186727f4584d712ad22258475d12a68ff51f6af91")
addappid(2160162, 1, "2b2265aabeb2d9518f950234a9980f79b7edbe29b638ffa16d66b00d49b43c94")
