-- Lua provided by RyzenAPI
-- Game: 3344240

-- MAIN APPLICATION
addappid(3344240)
-- Game: addappid(3344240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344242,0,"48c23101edbd4b5a07651e70965890c84af542a092fff14d2cab756c3cbf0c59")
