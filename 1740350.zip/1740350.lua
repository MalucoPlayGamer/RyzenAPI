-- Lua provided by RyzenAPI
-- Game: SpiderHeck Demo

-- MAIN APPLICATION
addappid(1740350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740351, 1, "cb75ee8e4c60b4b1d6113cd2c2767062b300dcc943e6bf4b5fe5d71a2d30ba9f")
