-- Lua provided by RyzenAPI
-- Game: 斗笠江湖

-- MAIN APPLICATION
addappid(4654940)

