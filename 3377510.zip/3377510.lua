-- Lua provided by RyzenAPI
-- Game: addappid(3377510)

-- MAIN APPLICATION
addappid(3377510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3377512,0,"ca335082249893dba9c64557345b991eb218b16f52cbea3be23c80849426debd")
