-- Lua provided by RyzenAPI
-- Game: Ticket to Ride: First Journey

-- MAIN APPLICATION
addappid(600430)

-- MAIN APP DEPOTS / PACKAGES
addappid(600431, 1, "35e8b51bf8640d6bb90d4e6b78298b60de70110027fdb307f308c3acf8c16a3f")
addappid(600432, 1, "7039ace55e570e35a2a84a3ebf87f41c86a77a8b9834f0be16336b5e0d73e38b")
