-- Lua provided by RyzenAPI
-- Game: 1479310

-- MAIN APPLICATION
addappid(1479310)
addappid(1479314)
-- Game: addappid(1479310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479313,0,"bbc392210a55eb76ec29f2c0e11e1f913a8766381751a3359d684b694b2ff837")
