-- Lua provided by RyzenAPI
-- Game: 1182720

-- MAIN APPLICATION
addappid(1182720)
-- Game: addappid(1182720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182721, 1, "28560628cd45f04dc6ce0bfa64b28eb36735e25f4ad4830fd7bd90f049afd9fd")
