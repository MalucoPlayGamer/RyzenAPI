-- Lua provided by RyzenAPI
-- Game: Hope Trigger

-- MAIN APPLICATION
addappid(1727910)
-- Game: addappid(1727910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727911, 1, "d8cfcc26802afdb5b68287a1ccd622179063595cc285431dbe5f970c4beda5d0")
