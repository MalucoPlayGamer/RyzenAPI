-- Lua provided by RyzenAPI
-- Game: 2170990

-- MAIN APPLICATION
addappid(2170990)
-- Game: addappid(2170990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170991, 1, "98e4f0f2bb680b70253138eef583b4f0578e2b020af8d43c4c61a068dfd3e454")
