-- Lua provided by RyzenAPI
-- Game: Between Horizons – A Sci-Fi Detective Adventure

-- MAIN APPLICATION
addappid(1921980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921981, 1, "55a6baa9dd76ba059cb9661763d65bc2b772c37f41e47443c9e4f87b23ff30c2")

