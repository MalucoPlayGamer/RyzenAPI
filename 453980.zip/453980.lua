-- Lua provided by RyzenAPI
-- Game: Game: AppID 453980

-- MAIN APPLICATION
addappid(453980)
-- Game: addappid(453980)

-- MAIN APP DEPOTS / PACKAGES
addappid(453981, 1, "49ce92ad4ecf852a2abd42b685ac5309caa08fea56c0d3e75cf663d41d76244f")
