-- Lua provided by RyzenAPI
-- Game: 521230

-- MAIN APPLICATION
addappid(521230)
-- Game: addappid(521230)

-- MAIN APP DEPOTS / PACKAGES
addappid(521231, 1, "d1c2732d689870443ce80dca1dde54e1c87fcb56f8728a564ae72943a74820fd")
