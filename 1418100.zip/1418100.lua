-- Lua provided by RyzenAPI
-- Game: Swords of Legends Online

-- MAIN APPLICATION
addappid(1418100)
addappid(1524670)
addappid(1524671)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1418101, 1, "783333340cdb4500065a0b9b26a965f3584295653ce1285d4dc44f3d757709e5")

