-- Lua provided by SkyAPI 
-- Game: Swords of Legends Online
addappid(1418100)
addappid(1418101, 1, "783333340cdb4500065a0b9b26a965f3584295653ce1285d4dc44f3d757709e5")
