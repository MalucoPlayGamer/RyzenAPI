-- Lua provided by RyzenAPI
-- Game: Game: Swords of Legends Online

-- MAIN APPLICATION
addappid(1418100)
-- Game: addappid(1418100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418101, 1, "783333340cdb4500065a0b9b26a965f3584295653ce1285d4dc44f3d757709e5")
