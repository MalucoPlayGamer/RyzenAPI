-- Lua provided by RyzenAPI
-- Game: Warhammer® 40,000: Dawn of War® - Dark Crusade

-- MAIN APPLICATION
addappid(4580)
-- Game: addappid(4580)

-- MAIN APP DEPOTS / PACKAGES
addappid(4581, 1, "cb330b27f15585a4142660301748d7d150d021818f9189ecdeef6b2e9e83747d")
addappid(4582, 1, "ce9dcedb48d4cc270a13e2a3f075541010cfe5590bc014690faf421cb1b32c32")
addappid(4583, 1, "d17373b234a9a1a4d83ab33d307807582d6fd8ea7b760c54d96a8d5f9b8f8137")
addappid(4584, 1, "12ef97567a598701a865e7a85f2f12b1b395cc32c4eca4a14904c25ce783afdf")
addappid(4585, 1, "ecacf2e6d224de8ca2cc66cc3abcd4a92530a011be9e9c83760265b7b036adb7")
addappid(4586, 1, "1b6c46626f0ba0505e57d6f7e2e7633a65ac31d4f3d2651c7d07298bd77a0cb2")
addappid(4587, 1, "d99fbc7975deb865157c164976bb249c2e623863338d19400068e4346534e8bd")
addappid(4588, 1, "ad1ef4d1c0f1f41c51aaf483a82fc1f083334d9419461f4c31ae170e8a1fc7f6")
