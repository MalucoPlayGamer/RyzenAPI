-- Lua provided by RyzenAPI
-- Game: Politon: Prologue

-- MAIN APPLICATION
addappid(2701730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701733,0,"cff8bc2dfc9a175950db8e3599793ebc813aafb3308d544d365ee0efed3cf02a")
addappid(2701734,0,"1f8ef0717945302190c9df0ce7047009c82d906b20ff1abf57602cae5a94cc2d")

