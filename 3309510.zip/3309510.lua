-- Lua provided by RyzenAPI
-- Game: 3309510

-- MAIN APPLICATION
addappid(3309510)
-- Game: addappid(3309510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3309512,0,"87abdf8b03cdf3aab9abb62801bb01341fa495c74fda5d9253cfe2c238275fb2")
addappid(3309513,0,"1786714cc1bebda5a1ee227fad8362641fce6920f32647a61e59d72d2f9734e9")
