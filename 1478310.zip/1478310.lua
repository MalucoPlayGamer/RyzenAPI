-- Lua provided by RyzenAPI
-- Game: Alone in the Stars: Survivor

-- MAIN APPLICATION
addappid(1478310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478311, 1, "1b34de6c0646a42c4c8cf0b3f7529ba3e0aca19ae549479c03464bb25aaf4eef")
