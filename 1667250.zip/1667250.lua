-- Lua provided by SkyAPI 
-- Game: Lovely Composer
addappid(1667250)
addappid(1667251, 1, "e65c018313a4f8c96ce9fb0cdc7ffb3f238640ca769d8421db5e8f04291ddd5e")
