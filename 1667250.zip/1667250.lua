-- Lua provided by RyzenAPI
-- Game: Lovely Composer

-- MAIN APPLICATION
addappid(1667250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667251, 1, "e65c018313a4f8c96ce9fb0cdc7ffb3f238640ca769d8421db5e8f04291ddd5e")
