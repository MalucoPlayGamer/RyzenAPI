-- Lua provided by RyzenAPI
-- Game: Agefield High: Rock the School

-- MAIN APPLICATION
addappid(3562580) -- Agefield High: Rock the School

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3562581, 1, "8194b4452646b7f8521e411e735ba1ecddbd595e6d19664b04ce751e681dabaa") -- Depot 3562581

