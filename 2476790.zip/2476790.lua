-- Lua provided by RyzenAPI
-- Game: addappid(2476790)

-- MAIN APPLICATION
addappid(2476790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476791, 1, "b5432b8287a28992a7406dff9b9e9dcf92c5fca68537fa08c8e3ee2a48f78551")
