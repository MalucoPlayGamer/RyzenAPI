-- Lua provided by RyzenAPI
-- Game: 721300

-- MAIN APPLICATION
addappid(721300)
-- Game: addappid(721300)

-- MAIN APP DEPOTS / PACKAGES
addappid(721301, 1, "6db0932bb74e68649492c505a436220b4ee86c9f5172d9081f35c636e52bf7cd")
