-- Lua provided by RyzenAPI
-- Game: 小猫换装 Demo

-- MAIN APPLICATION
addappid(3032180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032181, 1, "74752929456fcd4fa95f3b0c96bf36847e0dad4f3af2eee3f15b1b304c581e09")
