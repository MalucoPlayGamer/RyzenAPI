-- Lua provided by RyzenAPI
-- Game: Safelight

-- MAIN APPLICATION
addappid(2828740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828741, 1, "52ce6e457d867dca63f3f1f6704c5589e2329c31ef546494461df163b50d7d20")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
