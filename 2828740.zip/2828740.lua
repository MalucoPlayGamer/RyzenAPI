-- Lua provided by RyzenAPI
-- Game: Safelight

-- MAIN APPLICATION
addappid(2828740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828741, 1, "52ce6e457d867dca63f3f1f6704c5589e2329c31ef546494461df163b50d7d20")

