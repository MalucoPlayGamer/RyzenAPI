-- Lua provided by SkyAPI 
-- Game: Lantern Forge
addappid(314380)
addappid(314381, 1, "6327b8c47fa949076ecee4cbec1a26ac3facffbb2115834a5a28993a4db02f18")
