-- Lua provided by RyzenAPI
-- Game: Lantern Forge

-- MAIN APPLICATION
addappid(314380)

-- MAIN APP DEPOTS / PACKAGES
addappid(314381, 1, "6327b8c47fa949076ecee4cbec1a26ac3facffbb2115834a5a28993a4db02f18")
