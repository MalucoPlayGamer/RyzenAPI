-- Lua provided by RyzenAPI
-- Game: Slash Abyss

-- MAIN APPLICATION
addappid(2816400)
-- Game: addappid(2816400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816401, 1, "ed1edc0898294ffd411a556723c9492312bb5e6802a5f03378157c9c62222733")
