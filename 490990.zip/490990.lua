-- Lua provided by RyzenAPI
-- Game: 490990

-- MAIN APPLICATION
addappid(490990)
-- Game: addappid(490990)

-- MAIN APP DEPOTS / PACKAGES
addappid(490991, 1, "097a012852a4e932e03cf6f4cabb5a1cf8314335a381248719770f134f32bf19")
