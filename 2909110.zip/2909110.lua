-- Lua provided by RyzenAPI
-- Game: Game: Nuclear Nightmare

-- MAIN APPLICATION
addappid(2909110)
-- Game: addappid(2909110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909111, 1, "d360a5f33e1e8286cb3d5db8ab33eac6204ad6bdc6c71e5411c6c951197ba09e")
