-- Lua provided by RyzenAPI
-- Game: AppID 531070

-- MAIN APPLICATION
addappid(531070)
-- Game: addappid(531070)

-- MAIN APP DEPOTS / PACKAGES
addappid(531071, 1, "734cb669c734ef06608239a9ac49b243f4e36717babd6b1e5b705a64b7eba81c")
