-- Lua provided by RyzenAPI
-- Game: Paper Perjury

-- MAIN APPLICATION
addappid(1919600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919601, 1, "e6dc7797df53cf9637e7c9188d6795c55dc0b54b3003440ae9c1a5d9480cafc8")
addappid(1919602, 1, "e863eca099b0881e6312b4fe4086ebaa4fbca69cfc3d73c0b9d1f47ef77f160e")
addappid(1919604, 1, "ff15e15a6f0adbd67c10e7496c114a650d4d48260fc54af4d0d8570e946c70e3")
