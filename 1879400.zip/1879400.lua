-- Lua provided by RyzenAPI
-- Game: 1879400

-- MAIN APPLICATION
addappid(1879400)
-- Game: addappid(1879400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879401, 1, "ec9abfcba67219eae9424558c46431fbc86ad01214a92c0891fd5ed977c96588")
