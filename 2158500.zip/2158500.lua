-- Lua provided by RyzenAPI
-- Game: Monster Girl2

-- MAIN APPLICATION
addappid(2158500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158501, 1, "593b41d55eec0443382200d92ad09460e5ff75cc7c0d61974018bf8104b05e4b")

