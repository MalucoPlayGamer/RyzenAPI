-- Lua provided by RyzenAPI
-- Game: Become a Gladiator VR : 1v1 PVP

-- MAIN APPLICATION
addappid(1459660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459661, 1, "5759ff36b5eb602e7e649f779810a820185fc7d007c1f90be329f8a6b7cffbcf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
