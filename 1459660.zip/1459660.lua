-- Lua provided by RyzenAPI
-- Game: 1459660

-- MAIN APPLICATION
addappid(1459660)
-- Game: addappid(1459660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459661, 1, "5759ff36b5eb602e7e649f779810a820185fc7d007c1f90be329f8a6b7cffbcf")
