-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - Panda Palace

-- MAIN APPLICATION
addappid(1684153)
-- Game: addappid(1684153)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684153,0,"ca639473be1b1181a6b31c44377fc3d71ea79b14de1af33a163729919d77923a")
