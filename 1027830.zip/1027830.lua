-- Lua provided by RyzenAPI
-- Game: Sin; Vengeance

-- MAIN APPLICATION
addappid(1027830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027831, 1, "71bab66b43bccae9e3c03df2efb1ce49d9e3b5877c7a43fd70889dd93e779377")

