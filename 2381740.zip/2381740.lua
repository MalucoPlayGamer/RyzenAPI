-- Lua provided by RyzenAPI
-- Game: Hexguardian

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2381740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381742,0,"e1caa651e279d878b8d43b74f3eeae99a362bd914e7054b59e50d5ae957f4b28")

