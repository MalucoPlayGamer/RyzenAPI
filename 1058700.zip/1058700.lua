-- Lua provided by RyzenAPI 
-- Game: LOVE³ -Love Cube- Demo
addappid(1058700)
addappid(1058701, 1, "fc85588def428298ff16c9637e2bf2dea1ff44331c0083271f491d753b5bcb1c")
