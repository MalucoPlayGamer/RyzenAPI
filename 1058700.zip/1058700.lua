-- Lua provided by RyzenAPI
-- Game: 1058700

-- MAIN APPLICATION
addappid(1058700)
-- Game: addappid(1058700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058701, 1, "fc85588def428298ff16c9637e2bf2dea1ff44331c0083271f491d753b5bcb1c")
