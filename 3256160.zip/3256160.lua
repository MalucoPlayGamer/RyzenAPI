-- Lua provided by RyzenAPI
-- Game: addappid(3256160)

-- MAIN APPLICATION
addappid(3256160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256161, 1, "f3d5b3e3202160b8a81eb166dec92eca2bda9390973022b26da348a3d7d910af")
