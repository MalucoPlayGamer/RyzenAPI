-- Lua provided by RyzenAPI
-- Game: AppID 215450

-- MAIN APPLICATION
addappid(215450)
-- Game: addappid(215450)

-- MAIN APP DEPOTS / PACKAGES
addappid(215451, 1, "a88741695c590018d613bd3b6e5db17c42cd34a954f3843199fb5c4ccb6ab580")
