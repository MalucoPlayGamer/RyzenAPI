-- Lua provided by RyzenAPI
-- Game: AppID 716680

-- MAIN APPLICATION
addappid(716680)

-- MAIN APP DEPOTS / PACKAGES
addappid(716681, 1, "7fc0c23c202e5a70aad18aa63790b4b2b8e3ad72f57bcc6bfefb2fe98f64fbc7")
