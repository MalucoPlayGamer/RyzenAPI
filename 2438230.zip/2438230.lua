-- Lua provided by RyzenAPI
-- Game: 2438230

-- MAIN APPLICATION
addappid(2438230)
-- Game: addappid(2438230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438231, 1, "27e841bbc6245dd0a26d9eaf8cb07c6417004adbf938d2656ea84e7e3eb536ef")
