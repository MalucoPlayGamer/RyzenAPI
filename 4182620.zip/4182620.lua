-- Lua provided by RyzenAPI
-- Game: UBAI Again

-- MAIN APPLICATION
addappid(4182620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4182621,0,"02eb8a01f773e551b15269e6d73ed3c0b31e918ee02eee56fac6008b2e31ba27")

