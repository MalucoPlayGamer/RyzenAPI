-- Lua provided by RyzenAPI
-- Game: Whack-a-Vote: Hammering the Polls

-- MAIN APPLICATION
addappid(544130)

-- MAIN APP DEPOTS / PACKAGES
addappid(544131, 1, "de4e229c0e67c84c23377138851bfc82f398130afdd6db970126bb94bf042e10")
