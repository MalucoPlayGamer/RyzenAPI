-- Lua provided by RyzenAPI
-- Game: I commissioned some bees 3

-- MAIN APPLICATION
addappid(2069110)
-- Game: addappid(2069110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069111, 1, "da7b5db65c83898b9a171005d0e6ab24d33e697724e7adbdbbdf642a28f7631d")
