-- Lua provided by RyzenAPI
-- Game: addappid(362150)

-- MAIN APPLICATION
addappid(362150)

-- MAIN APP DEPOTS / PACKAGES
addappid(362151, 1, "a4516662bf82f4f0d77eae4e3c25377c96abfc62b45a20c587e51b8843b481fe")
