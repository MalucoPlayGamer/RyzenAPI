-- Lua provided by RyzenAPI
-- Game: Ken Follett's The Pillars of the Earth

-- MAIN APPLICATION
addappid(234270)

-- MAIN APP DEPOTS / PACKAGES
addappid(234271, 1, "8fe88491a4a6c23bcbe1f1547bda40e76595379d43a6a3eea26414f0aa296ac6")
addappid(234272, 1, "83c37b9d73a37295d59d20d4a34f5a6bacc0fb5343aae4d8ea285f59b375d2ad")
addappid(234273, 1, "6c5a33eaffcdf5194cf37ac361ac688f8b9a404bca94747d6e46401403f969e4")
addappid(234274, 1, "7962a273fa7006c951ac67d4b7f6ade1b452935396237c78789924c0f14a9141")
addappid(234275, 1, "05f2d2b5546aba82cf08166acdc607d6868871e7c4ffece8f17c6b45eb4c9a24")
addappid(234276, 1, "5c69e1483c6782e9a50e4a67938bedd5267fafa6a5ff0e1324e688e343da0d43")

