-- Lua provided by RyzenAPI
-- Game: 3210610

-- MAIN APPLICATION
addappid(3210610)
-- Game: addappid(3210610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210611, 1, "8ef8c4b02011531656b8968b33fffe80aba1937afe89d220abdb5f6509b612e4")
