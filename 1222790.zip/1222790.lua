-- Lua provided by RyzenAPI
-- Game: Game: Crossing Frontier 盡界戰線 (DEMO)

-- MAIN APPLICATION
addappid(1222790)
-- Game: addappid(1222790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222791, 1, "5230f054fa638da18e5e3852e6a3546745115a8a2980a4005b13cab081a15b6d")
