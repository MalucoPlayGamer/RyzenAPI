-- Lua provided by RyzenAPI
-- Game: Limbus Company

-- MAIN APPLICATION
addappid(1973530)
-- Game: addappid(1973530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973531, 1, "b5b48790e4a9b5e1addac9fafe875d35ac0834bfe74548ec481407975ad1a0e6")
