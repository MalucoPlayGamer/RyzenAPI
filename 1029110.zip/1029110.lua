-- Lua provided by RyzenAPI
-- Game: Trash Time

-- MAIN APPLICATION
addappid(1029110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029111, 1, "2cfb0a04a7a45b80dce603d6754a8f37e6ceb3e347c55033ddef0aced06e5cbd")

