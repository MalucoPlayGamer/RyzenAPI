-- 3551370's Lua and Manifest Created by Hubcap Manifest
-- Book Shooter
-- Created: March 28, 2026 at 11:48:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3551370, 1, "8a9925bb9ecfae2b8785d4e3ecd6f0f075d86b16a086bb66937ad8e705470fc6") -- Book Shooter
-- MAIN APP DEPOTS
addappid(3551371, 1, "965bdbb399282cff2349b8b1a8fecc51010aae3448b2edd5d414ca7b571bdadc") -- Depot 3551371
-- setManifestid(3551371, "1043280391104332313", 602579547)