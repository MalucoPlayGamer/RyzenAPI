-- Lua provided by SkyAPI 
-- Game: Undead Horde
addappid(790850)
addappid(790851, 1, "7041502a9ae043b2e8a9b298a0e5564b07d7add75caa9d59830c3cf38327d3d1")
addappid(790852, 1, "ef13b9805c1b53796aa3156ab8a8b2b29d8ebeebf30fb20bd5f89ad8b87b6953")
addappid(790853, 1, "1d1c7843c860fda394a451796c5a960ad88c0c97d6a59eabda8a51e08af547a1")
