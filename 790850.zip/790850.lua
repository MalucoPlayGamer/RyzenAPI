-- Lua provided by RyzenAPI
-- Game: Undead Horde

-- MAIN APPLICATION
addappid(790850)

-- MAIN APP DEPOTS / PACKAGES
addappid(790851, 1, "7041502a9ae043b2e8a9b298a0e5564b07d7add75caa9d59830c3cf38327d3d1")
addappid(790852, 1, "ef13b9805c1b53796aa3156ab8a8b2b29d8ebeebf30fb20bd5f89ad8b87b6953")
addappid(790853, 1, "1d1c7843c860fda394a451796c5a960ad88c0c97d6a59eabda8a51e08af547a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
