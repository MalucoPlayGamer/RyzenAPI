-- Lua provided by RyzenAPI
-- Game: Game: Electrogene

-- MAIN APPLICATION
addappid(1614030)
-- Game: addappid(1614030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614031, 1, "fca207f7eee9dfbe26155ec914844c2084c88bad0f9abaee255299db282501d9")
