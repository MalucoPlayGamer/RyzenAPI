-- Lua provided by RyzenAPI
-- Game: Monster Hunter Stories

-- MAIN APPLICATION
addappid(2356560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356561, 1, "25a51c9b191133072944947dcbc0425baa8267da1034b8c652067297d0833386")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2620130)
