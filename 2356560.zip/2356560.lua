-- Lua provided by SkyAPI 
-- Game: Monster Hunter Stories
addappid(2356560)
addappid(2356561, 1, "25a51c9b191133072944947dcbc0425baa8267da1034b8c652067297d0833386")
