-- Lua provided by RyzenAPI
-- Game: Game: Monster Hunter Stories

-- MAIN APPLICATION
addappid(2356560)
-- Game: addappid(2356560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356561, 1, "25a51c9b191133072944947dcbc0425baa8267da1034b8c652067297d0833386")
