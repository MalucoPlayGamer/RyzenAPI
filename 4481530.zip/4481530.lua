-- 4481530's Lua and Manifest Created by Hubcap Manifest
-- BEACONFALL
-- Created: August 17, 2026 at 14:33:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4481530) -- BEACONFALL
-- MAIN APP DEPOTS
addappid(4481531, 1, "b57a8bb86f2da35eec56508351af3d1b66b4531f8df72a6be6d85889bc41727b") -- Depot 4481531
setManifestid(4481531, "1442610490264161212", 211020957)