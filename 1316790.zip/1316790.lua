-- Lua provided by RyzenAPI
-- Game: 1316790

-- MAIN APPLICATION
addappid(1316790)

-- MAIN APP DEPOTS / PACKAGES
addappid(744202,0,"5e5724e8c90760a56accd3402dfac2ae058adcdbad6d68be21b0c7d286747582")
addappid(744204,0,"a9aaf8e0c7449d9e4df8bae60be28b5cebcab9363b42a10ef4605c063ddd2ed9")
addappid(744205,0,"12039bf299d6f632a7392fe9621558bad8ccb825dd7f9641ee2db87736fbe633")
addappid(744207,0,"1cc58b2e2913ba248bece6dc4e94fdf29f65f426cafd9a9be00ec4a4d5f33b7f")
