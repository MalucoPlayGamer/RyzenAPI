-- Lua provided by RyzenAPI
-- Game: End Space

-- MAIN APPLICATION
addappid(753900)

-- MAIN APP DEPOTS / PACKAGES
addappid(753901, 1, "35a03f8cbf2311dce1d7d19d6904fc7f1249bbae3167a98f0e1dd9fb02a63a1f")

