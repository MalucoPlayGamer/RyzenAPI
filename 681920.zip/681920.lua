-- Lua provided by RyzenAPI 
-- Game: Slingshot Cowboy VR
addappid(681920)
addappid(681921, 1, "73bdf7e6c8789195c2ed8f9f4f3824900860513d27d917f375f80c8019caba31")
