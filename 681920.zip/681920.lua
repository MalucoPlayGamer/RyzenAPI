-- Lua provided by RyzenAPI
-- Game: Slingshot Cowboy VR

-- MAIN APPLICATION
addappid(681920)
-- Game: addappid(681920)

-- MAIN APP DEPOTS / PACKAGES
addappid(681921, 1, "73bdf7e6c8789195c2ed8f9f4f3824900860513d27d917f375f80c8019caba31")
