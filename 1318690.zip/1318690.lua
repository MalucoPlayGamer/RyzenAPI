-- Lua provided by RyzenAPI
-- Game: shapez

-- MAIN APPLICATION
addappid(1318690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318691, 1, "bbc560c7f6f3c1af44cdecdc8438e5f44003fa528617796bc5edf003a13bae4c")
addappid(1318692, 1, "ba9994b629f57212b5cc79d3fbc934773d9939c472d4f4f3eb201d09314c8e26")
addappid(1318693, 1, "123004ab13a68a17e48117722e42a2c74be37de81fc82381bd2fd29cd65e992a")
addappid(1318694, 1, "6ce266cb8d69a00d39b70114231313562e4e73a47c80d525c6c3bf0ceabb4dd1")
addappid(1318695, 1, "87c19501648e491964c450d84d753920cd9b8f3527cd95af09b4cd00f41edc82")
addappid(1318696, 1, "bc33c228d34db0946d022c96644657630a8e0ad2fa9f4b579f8e081cf2e38b74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1625400)
