-- Lua provided by RyzenAPI
-- Game: AppID 1457570

-- MAIN APPLICATION
addappid(1457570)
-- Game: addappid(1457570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457571, 1, "a7a4cfe7635701acfbc41aa37bee6166e26eeb457f08d75084a16eb6b79c80bd")
