-- Lua provided by RyzenAPI
-- Game: AppID 1457570

-- MAIN APPLICATION
addappid(1457570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457571, 1, "a7a4cfe7635701acfbc41aa37bee6166e26eeb457f08d75084a16eb6b79c80bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
