-- Lua provided by RyzenAPI
-- Game: FOX n FORESTS

-- MAIN APPLICATION
addappid(603400)

-- MAIN APP DEPOTS / PACKAGES
addappid(603401, 1, "8dbfbd1f2a6dfa41719209467839192ef426d835dcf3edf6c3e2e84370adb49b")
addappid(603402, 1, "1d842d03f27af0dd083231a6150d3ca817ae308aa305d8f33a9538bee9742486")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
