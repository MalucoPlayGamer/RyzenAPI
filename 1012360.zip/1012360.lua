-- Lua provided by RyzenAPI
-- Game: addappid(1012360)

-- MAIN APPLICATION
addappid(1012360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012361, 1, "84f549b664fef7735c95ce827ab1b9f29683b9f713c9e3702a8a6bbef1736e19")
