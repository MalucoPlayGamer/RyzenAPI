-- Lua provided by RyzenAPI
-- Game: 【救世计划】红衣/SalvationPlan:SpiritEvil

-- MAIN APPLICATION
addappid(1272900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272901, 1, "147da6a8caf97f5ca880e8ed1fa71fc6483a585d438b877d019926c5756dd0eb")
