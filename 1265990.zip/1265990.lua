-- Lua provided by RyzenAPI
-- Game: QUIZ PRO! - General Knowledge

-- MAIN APPLICATION
addappid(1265990)
addappid(1268620)
addappid(1270040)
-- Game: addappid(1265990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265991, 1, "e425088b81875fa01b76f005eb3660802d23995a9f844bdced26f026f72dd320")
