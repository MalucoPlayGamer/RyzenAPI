-- Lua provided by RyzenAPI
-- Game: Little LUMI Model

-- MAIN APP DEPOTS / PACKAGES
addappid(5075020, 1, "305f37461250baaf80e21c769727910a498bd84036afe16a5993f48b75a9673e") -- Little LUMI Model
addappid(5075021, 1, "5002e0074ca82d11d06151548c94e780a82802030dede03caaa5e85da35ecb60") -- Depot 5075021
