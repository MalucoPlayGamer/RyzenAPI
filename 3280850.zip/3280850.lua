-- Lua provided by RyzenAPI
-- Game: 3280850

-- MAIN APPLICATION
addappid(3280850)
-- Game: addappid(3280850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280851, 1, "bdee9b323a51a19e7866dc2139ed7ae145fd2ddeb9b59c1239aa08e973f9c0b3")
