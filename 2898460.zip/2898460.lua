-- Lua provided by RyzenAPI
-- Game: Liftlands Demo

-- MAIN APPLICATION
addappid(2898460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898461, 1, "21cb3a0bccac447d3605944cbf8cb6b536673ece88c644824f1121c25da67c38")
