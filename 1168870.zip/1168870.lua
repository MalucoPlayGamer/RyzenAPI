-- Lua provided by RyzenAPI
-- Game: Mists of Noyah

-- MAIN APPLICATION
addappid(1168870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168871, 1, "13c9251e7e5363eed0234e7be3dacced5e3316436808f384e347f91035777659")
