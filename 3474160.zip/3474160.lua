-- Lua provided by RyzenAPI
-- Game: Venomous

-- MAIN APPLICATION
addappid(3474160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3474161, 1, "5af16cee0eb12bcb5c50f83bba037b5667dd8abb8b1405949484ee81b238529d")

