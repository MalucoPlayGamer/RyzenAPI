-- Lua provided by RyzenAPI
-- Game: 1683620

-- MAIN APPLICATION
addappid(1683620)
-- Game: addappid(1683620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683621, 1, "ef2692c5dd6c6ece1be9914c63850f306eba4f7b259d8ad881f0dc2697eca199")
