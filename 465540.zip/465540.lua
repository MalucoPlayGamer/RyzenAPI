-- Lua provided by RyzenAPI
-- Game: Adventure World

-- MAIN APPLICATION
addappid(465540)

-- MAIN APP DEPOTS / PACKAGES
addappid(465541, 1, "3c637d065d02dd16ebe6b8e26e1a65e0e70f8e900e55c1afc777c3420990211c")

