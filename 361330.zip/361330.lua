-- Lua provided by RyzenAPI
-- Game: Game: AppID 361330

-- MAIN APPLICATION
addappid(361330)
-- Game: addappid(361330)

-- MAIN APP DEPOTS / PACKAGES
addappid(361331, 1, "791acd94fc92a6a3acd55b47d8d0cffeddb341c1da9484789a60f4e428d55662")
addappid(361333, 1, "7af386baaf93120726a6447c598343e59120e27daa152563be750f52e0e2d2e5")
