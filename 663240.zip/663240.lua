-- Lua provided by RyzenAPI
-- Game: All You Can Eat

-- MAIN APPLICATION
addappid(663240)

-- MAIN APP DEPOTS / PACKAGES
addappid(663241, 1, "41652ad5d56929dbcec49a565f0bd4063b331728a5384cc7706d14aadd157878")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
