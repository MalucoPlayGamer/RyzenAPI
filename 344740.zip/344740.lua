-- Lua provided by RyzenAPI
-- Game: CRYPTARK

-- MAIN APPLICATION
addappid(344740)
addappid(424120)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(344741, 1, "04ac4170ad4e4d6fdee1d3cce998602aac5d1d592b3d2e55de12d0d2c9793aac")
addappid(344742, 1, "a4bef9b28779b3fd52c0c974a367f37b90821f63fc5cfabb8cc72ced1b2e9ddf")
addappid(344743, 1, "557da2649da93bb5748d3ce5ecdd19652e18e1399930ffd2fe7fa294c882e0c2")

