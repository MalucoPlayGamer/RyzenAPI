-- Lua provided by RyzenAPI
-- Game: 344740

-- MAIN APPLICATION
addappid(344740)
addappid(424120)
-- Game: addappid(344740)

-- MAIN APP DEPOTS / PACKAGES
addappid(344741, 1, "04ac4170ad4e4d6fdee1d3cce998602aac5d1d592b3d2e55de12d0d2c9793aac")
addappid(344742, 1, "a4bef9b28779b3fd52c0c974a367f37b90821f63fc5cfabb8cc72ced1b2e9ddf")
addappid(344743, 1, "557da2649da93bb5748d3ce5ecdd19652e18e1399930ffd2fe7fa294c882e0c2")
