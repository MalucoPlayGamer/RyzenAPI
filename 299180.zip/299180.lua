-- Lua provided by RyzenAPI
-- Game: addappid(299180)

-- MAIN APPLICATION
addappid(299180)

-- MAIN APP DEPOTS / PACKAGES
addappid(299181, 1, "2d5d673b2b81a1cf797063f4d8a3c4eb1b82021136e1007b523d5730d81e4cb4")
