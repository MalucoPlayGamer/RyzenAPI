-- Lua provided by SkyAPI 
-- Game: AppID 299180
addappid(299180)
addappid(299181, 1, "2d5d673b2b81a1cf797063f4d8a3c4eb1b82021136e1007b523d5730d81e4cb4")
