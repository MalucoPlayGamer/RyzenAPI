-- Lua provided by RyzenAPI
-- Game: addappid(2187660)

-- MAIN APPLICATION
addappid(2187660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187661, 1, "4864d8e031bbebc22acba37af15bd7c3cc66ec843951a9f6b25fa903ffd2ea67")
