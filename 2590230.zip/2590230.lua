-- Lua provided by RyzenAPI
-- Game: Game: AppID 2590230

-- MAIN APPLICATION
addappid(2590230)
-- Game: addappid(2590230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590231, 1, "52bbf25c457e7d57eba3f948745922516ed32aa17b5e33c1987d1ca181ae0666")
