-- Lua provided by RyzenAPI
-- Game: Pure Hold'em

-- MAIN APPLICATION
addappid(322950)

-- MAIN APP DEPOTS / PACKAGES
addappid(322951, 1, "91b0447c028079f3440ac3b57b729ec395dda47e2d16292737f7bc2dc5508321")
addappid(322952, 1, "88b7206c32efe58499381bc71cc4fd0653fe1c854a67d4587eb1de63cb7f72f6")
addappid(322953, 1, "09a256434c792c4a0f1ee0c674d53380d7c5a6ead1883cfec67e3a5815173ecf")
addappid(342590, 0, "4c30d831526519b0470453d28105da6a8cd2346955c22a8e8c7bee1804ae939c")
addappid(438901, 0, "53472565136acced7ae00720735d14006a06b5a9b613cd54e25701ace659489a")
addappid(438905, 0, "1d319693c32716297a12fa3d0a7132141a1856fae0d074d5262087e5fdda963e")
addappid(438906, 0, "9d07331b174f28663386c4d64ce1560b3cae3303213a2a159abf64876b17d005")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(330280)
addappid(342600)
addappid(438900)
addappid(438902)
addappid(438903)
addappid(438904)
addappid(438950)
addappid(438951)
addappid(438960)
