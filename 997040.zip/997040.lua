-- Lua provided by RyzenAPI
-- Game: Renowned Explorers - Soundtrack

-- MAIN APPLICATION
addappid(997040)

-- MAIN APP DEPOTS / PACKAGES
addappid(997040,0,"26f9eb58ca45dba7b9182ed304739f479063445c782f9146b0d7e5f2bf5f1968")

