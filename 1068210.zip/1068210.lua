-- Lua provided by RyzenAPI
-- Game: addappid(1068210)

-- MAIN APPLICATION
addappid(1068210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068211, 1, "60283b72bc0d7a7ae2f296cb7245ada1080a43c73e5d2935d48b988e400d01fd")
