-- Lua provided by RyzenAPI
-- Game: 384930

-- MAIN APPLICATION
addappid(384930)
-- Game: addappid(384930)

-- MAIN APP DEPOTS / PACKAGES
addappid(384931, 1, "1817df05a26d1ad6e72f3ca0f8e639b609ddbeda1c0f9deda6004049f2815935")
