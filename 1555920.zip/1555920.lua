-- Lua provided by SkyAPI 
-- Game: CAN ANDROIDS SURVIVE
addappid(1555920)
addappid(1555921, 1, "55085287ae27adca5aabddf97649a8575a080c1ba79c2f0fe49d59c2360c902d")
