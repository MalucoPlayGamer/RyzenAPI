-- Lua provided by RyzenAPI
-- Game: My Friendly Neighborhood Demo

-- MAIN APPLICATION
addappid(1915720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915721, 1, "49e43522d16fed54b8355b379b0ebcdda55ee6cc8660217c2c78b638b7be308d")
