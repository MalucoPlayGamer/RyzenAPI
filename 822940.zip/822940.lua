-- Lua provided by RyzenAPI
-- Game: AppID 822940

-- MAIN APPLICATION
addappid(822940)

-- MAIN APP DEPOTS / PACKAGES
addappid(822941, 1, "46ec89a0eb5f16aa935e6bbd19e6244ccfeae091f73bfd2316ed8c3381d536bc")
addappid(822942, 1, "5b26a0def50da0b17a2468a1a50fbca39ef060b0b9e20019416e69f055f3cda1")

