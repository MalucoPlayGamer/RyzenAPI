-- Lua provided by RyzenAPI
-- Game: Add Astra

-- MAIN APPLICATION
addappid(2870750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870751, 1, "022709008ee8f8e6196bcb6fa782436e9152923ebfa74281631a3a74ea0d79bf")
