-- Lua provided by RyzenAPI
-- Game: Football Manager 2015 Editor

-- MAIN APPLICATION
addappid(295350)

-- MAIN APP DEPOTS / PACKAGES
addappid(295351, 1, "dd5e317b7292030778025640ef56c82a6793392f39b57e9b19fb440efe810948")

