-- Lua provided by RyzenAPI
-- Game: Game: Snakes on an Extradimensional Plane

-- MAIN APPLICATION
addappid(451540)
-- Game: addappid(451540)

-- MAIN APP DEPOTS / PACKAGES
addappid(451541, 1, "74d8de4a170f70504205ace5ce2dd8dcca75ddebcfe87a13bc821434cbae7da3")
