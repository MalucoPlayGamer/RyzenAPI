-- Lua provided by RyzenAPI
-- Game: 838540

-- MAIN APPLICATION
addappid(838540)
-- Game: addappid(838540)

-- MAIN APP DEPOTS / PACKAGES
addappid(838541, 1, "e2ffee59d10f944ff93381059017d24dac2a82dff181e75be76350369d1a2825")
