-- Lua provided by SkyAPI 
-- Game: AppID 1167140
addappid(1167140)
addappid(1167141, 1, "790224660577049d9a88c87eab48e892225b456ce869f76259c5c56016e04d1f")
