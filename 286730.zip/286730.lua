-- Lua provided by RyzenAPI
-- Game: Game: Gunship!

-- MAIN APPLICATION
addappid(286730)
-- Game: addappid(286730)

-- MAIN APP DEPOTS / PACKAGES
addappid(286731, 1, "130c8f69e382b3de459ff16af680505593f42368c6f5295f864574b5194043a5")
