-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Wei Pack 1

-- MAIN APPLICATION
addappid(933509)
-- Game: addappid(933509)

-- MAIN APP DEPOTS / PACKAGES
addappid(933509,0,"66142b8871e5ad978b24623ab5ae96306c6a23e10e20b963708075a140459c7d")
