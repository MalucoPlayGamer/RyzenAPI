-- Lua provided by RyzenAPI
-- Game: Game: Elewder

-- MAIN APPLICATION
addappid(1597710)
-- Game: addappid(1597710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597711, 1, "bdc969d37f2fd27055e89967ac23156b3e83c42306d881374851b77db09e5562")
