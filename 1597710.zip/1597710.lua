-- Lua provided by RyzenAPI 
-- Game: Elewder
addappid(1597710)
addappid(1597711, 1, "bdc969d37f2fd27055e89967ac23156b3e83c42306d881374851b77db09e5562")
