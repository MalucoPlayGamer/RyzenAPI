-- Lua provided by RyzenAPI
-- Game: 3156320

-- MAIN APPLICATION
addappid(3156320)
-- Game: addappid(3156320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156321, 1, "ee6b104eb879bbd67afe2210b349811c01499ef665ee9b1e0715c7e1b466d16a")
