-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1290422)
-- Game: addappid(1290422)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290422,0,"74db3b042dd5462c7d55f41f16a17171deeb3e98c3b87cc7ea5a1fc0f4f1d44e")
addappid(1290450,0,"70501dc2b66da06795618efbc40c87f6158b56a66ec4c1021c6b72ca65ce06d5")
addappid(1290451,0,"2d9e678a40c49b5dba7d0c1a1a9c132c72c1996324b7866709afa39f77037799")
addappid(1290452,0,"a000bda71d8fbdede491844ff881758503de76e28e11da024a37ef9b82360f99")
addappid(1290453,0,"1af0a6fd970e6e73b9f773ccbec8329037d4945d818c38e0ef0af5fa65695b7e")
addappid(1290454,0,"fc54687d51c275a6c013df141616c5ea12e42694ffcafe1572519d8384248895")
addappid(1290455,0,"fa573699a2e26c5519bf4efb65bff763bbad314ff36ef293095741bd45e835ad")
addappid(1290456,0,"88acf0e5a355da88aac07b6eb66de3c63636051ca11ec3538442d9b07a53ab18")
addappid(1290457,0,"a22b77c57e8c88a78c4c090c876cd54761330ac0a5d2bd9fb70835cee62125f0")
