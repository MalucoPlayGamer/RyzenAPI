-- Lua provided by RyzenAPI
-- Game: addappid(2984990)

-- MAIN APPLICATION
addappid(2984990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984991, 1, "2218896d984432fedf759ec338c92a2c586fad949972c1c9cd2f7b38c1db7669")
