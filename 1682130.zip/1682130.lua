-- Lua provided by RyzenAPI
-- Game: addappid(1682130)

-- MAIN APPLICATION
addappid(1682130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682131, 1, "2e284ca075153ebcc19dfc8a5c2a87328ba90ce893534247a043cbeb7c9d1046")
