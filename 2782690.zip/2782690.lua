-- Lua provided by RyzenAPI
-- Game: 2782690

-- MAIN APPLICATION
addappid(2782690)
-- Game: addappid(2782690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782690,0,"1580d113d38b34e65858b9b99af5d51d5bb7803dffec3c044ddf138f7e2fcce6")
