-- Lua provided by RyzenAPI
-- Game: Galactic Vanguard

-- MAIN APPLICATION
addappid(3308800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308801, 1, "ada1839dd44154254504fde8b013689f3617e605e4c15b110b4d2799a0aec528")
