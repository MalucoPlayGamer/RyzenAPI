-- Lua provided by RyzenAPI
-- Game: PLANETS OF WAR

-- MAIN APPLICATION
addappid(656140)

-- MAIN APP DEPOTS / PACKAGES
addappid(656141, 1, "cc0009d46f942a29d3f4be1febe480aa559979997e67d69f6854e0df1a0d3d5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
