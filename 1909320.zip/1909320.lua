-- Lua provided by RyzenAPI
-- Game: Game: Furry Futanari Jigsaw

-- MAIN APPLICATION
addappid(1909320)
-- Game: addappid(1909320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909321, 1, "2be4e8f03de51f15692b25c6c3184923de87020bc90eac0c18bc0392800cb66e")
