-- Lua provided by RyzenAPI
-- Game: Sakura Bunny Girls

-- MAIN APPLICATION
addappid(2375080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375081, 1, "2fde335bf401b9750e2881cd4b1ed89e54913fb1b0b45677d13a059d2bae1544")
