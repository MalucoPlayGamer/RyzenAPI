-- Lua provided by RyzenAPI
-- Game: Game: Torn Tales

-- MAIN APPLICATION
addappid(388960)
-- Game: addappid(388960)

-- MAIN APP DEPOTS / PACKAGES
addappid(388961, 1, "917ab26bb2b331f57b8978f0abfe126d41176d418b064065ee9d567e78899fa8")
addappid(388962, 1, "846b0066a8ae0ac9e2f96e4962dfd112f904003a0bc083dee74f29f0f2f34537")
addappid(388963, 1, "f8a3cd46a2f7d5502a78249f34c777df9258ad370cfeb2d4267a53337a51812d")
