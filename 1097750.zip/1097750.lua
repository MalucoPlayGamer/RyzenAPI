-- Lua provided by RyzenAPI
-- Game: Game: Ezaron Defense

-- MAIN APPLICATION
addappid(1097750)
-- Game: addappid(1097750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097751, 1, "bec3432f0a2085b18ac61e095728c870ef25714eb64dfeaa545cf66782baf781")
