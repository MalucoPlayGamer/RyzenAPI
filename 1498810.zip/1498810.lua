-- Lua provided by RyzenAPI
-- Game: City Guardian

-- MAIN APPLICATION
addappid(1498810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498811, 1, "b99bc9fc81462bd5b770120615c671153ef685125b4f7fff2601dc2f84c98fa1")
