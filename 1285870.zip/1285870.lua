-- Lua provided by RyzenAPI
-- Game: Little Bunny

-- MAIN APPLICATION
addappid(1285870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285871, 1, "30dae2f4d4b3616263f5f3fb2dffe6577e26bd27849c48d4edd61e182c21d05e")

