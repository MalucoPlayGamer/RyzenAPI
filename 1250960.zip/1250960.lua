-- Lua provided by SkyAPI 
-- Game: AppID 1250960
addappid(1250960)
addappid(1250961, 1, "e3db09b2aca8590c92f10c887bed935e1e1d332a355e7a698e0f2d706c95f045")
