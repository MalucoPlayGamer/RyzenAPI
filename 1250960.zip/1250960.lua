-- Lua provided by RyzenAPI
-- Game: Space Redemption

-- MAIN APPLICATION
addappid(1250960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250961, 1, "e3db09b2aca8590c92f10c887bed935e1e1d332a355e7a698e0f2d706c95f045")

