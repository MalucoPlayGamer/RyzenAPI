-- Lua provided by RyzenAPI
-- Game: Game: The Discrete Era

-- MAIN APPLICATION
addappid(2253650)
-- Game: addappid(2253650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253651, 1, "9b22300192dd8c0afd8d2142ae709767d7af5f6a0155d0cea58e4ab988f811a1")
