-- Lua provided by RyzenAPI
-- Game: Youtubers Life 2

-- MAIN APPLICATION
addappid(1493760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493761, 1, "7dacf7699064cc15ccfd1b982a0dd77e4f8c2ec9f87647267a4b98d9f2033b6b")
addappid(1493762, 1, "0153c94b5fc61c1b92bd9656e1e03dda00d4663112ce2e08a78fc3c0ed526d61")
addappid(1493763, 1, "12497d69966b45bf7d3c92b6b033c264194aa3ba23cb65c90eaacc10b8f5b51e")

