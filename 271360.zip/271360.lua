-- Lua provided by RyzenAPI
-- Game: Industry Giant 2

-- MAIN APPLICATION
addappid(271360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(271361, 1, "cd625cf1da13320399cd36257288c23f1920e91fa6d3aad46ba5fd49b5d237e5")
addappid(271362, 1, "555d14cc297ad30a179df0872172df9d9af3b8bcacc7138e825678ea32f8cf0a")
addappid(271363, 1, "9f492837d507a6c461287119eb095ac1493add340f55e543c9705e3bbbdd7113")
addappid(271364, 1, "966eabff349a88f24e842f4000dd7e8680fbe694fe06f60ad5c98164717e6faa")
addappid(271365, 1, "d7244da53ce970d3d8172d963d9148ac989e49a1805db785f21bcf3aeb2096aa")
addappid(271366, 1, "aa1732ec18af9198dd1fe701f4fbd8a416448c89d566569ca0615eab823ed49b")
addappid(271367, 1, "d6136da468981bf7ed5774d276c55141b984317004a5c2c0f8f760296831ba87")
