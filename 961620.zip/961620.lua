-- Lua provided by RyzenAPI
-- Game: Flashback

-- MAIN APPLICATION
addappid(961620)

-- MAIN APP DEPOTS / PACKAGES
addappid(961621, 1, "b6eaf4b22db3aecd3ea6864ab8d85bfbee75eb95d123e402521148ea743330e9")
addappid(961622, 1, "a2cad259462f857c20eab8325743473b998cde0b64d557a60bdb282adebbb296")

