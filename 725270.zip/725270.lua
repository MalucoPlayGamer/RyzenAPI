-- Lua provided by RyzenAPI
-- Game: AppID 725270

-- MAIN APPLICATION
addappid(725270)
-- Game: addappid(725270)

-- MAIN APP DEPOTS / PACKAGES
addappid(725271, 1, "801ba8dd45c0852db753f2aa42dda187974ff1539271838cc5a3cbda0c7b0a4d")
addappid(725272, 1, "be0a3aaef422c9224c362be7993a70b8ab8b25557a8081e2c9404ed903213e89")
