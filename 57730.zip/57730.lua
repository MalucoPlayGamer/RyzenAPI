-- Lua provided by RyzenAPI
-- Game: Patrician IV: Rise of a Dynasty

-- MAIN APPLICATION
addappid(57730)
-- Game: addappid(57730)

-- MAIN APP DEPOTS / PACKAGES
addappid(57731, 1, "9527005627697908d9386f0fe3fa964d087a196ac2869b6109ce78822d882368")
addappid(57732, 1, "aae6a828ceb88aad3d0123f9a2821de27bef6f3cf94f0176e690b24b07b3d3f4")
