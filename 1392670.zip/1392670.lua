-- Lua provided by RyzenAPI
-- Game: Unbeliever

-- MAIN APPLICATION
addappid(1392670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392671, 1, "30a511d0b1fe263982aa0508b725388a15fb75ee702e610ade11e12595aa9766")
