-- Lua provided by RyzenAPI
-- Game: Game: Nora: The Wannabe Alchemist

-- MAIN APPLICATION
addappid(1798720)
-- Game: addappid(1798720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798721, 1, "881e25e810b2309a8978cece8325118f4951d8423309a9217d226c3bb5781d45")
