-- 4154440's Lua and Manifest Created by Hubcap Manifest
-- Saved by the Coupon
-- Created: July 28, 2026 at 11:11:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4154440) -- Saved by the Coupon
-- MAIN APP DEPOTS
addappid(4154441, 1, "b22c1265b71f0e909cde7b337178a28a2c48773845746c2c25ad4fa1f467c36c") -- Depot 4154441
setManifestid(4154441, "4903379960021354863", 221654124)