-- Lua provided by RyzenAPI
-- Game: Midnight Ghost Hunt Playtest

-- MAIN APPLICATION
addappid(1875460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875461, 1, "b6d157f428746f741b8c10b0d951c0c13d9dd72fa5725a15d5b7e1e3f07ededc")
