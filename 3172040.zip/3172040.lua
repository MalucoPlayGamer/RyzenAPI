-- Lua provided by RyzenAPI
-- Game: Hidden Pass Skirmishes

-- MAIN APPLICATION
addappid(3172040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172041, 1, "428342f189556f03d6a43664591b6eaf97c3428a880b998ac827d004641d87fb")

