-- Lua provided by RyzenAPI
-- Game: My Exotic Farm

-- MAIN APPLICATION
addappid(965970)

-- MAIN APP DEPOTS / PACKAGES
addappid(965971, 1, "c2de54cacab4ba1c101688c796abfc2242b8522827d8b4b922264e68f951fa75")
