-- Lua provided by RyzenAPI
-- Game: Alchemia: Creatio Ex Nihilo Demo

-- MAIN APPLICATION
addappid(1960332)
addappid(1960333)
addappid(2051810)
-- Game: addappid(2051810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960331,0,"a8345c66244514c6a08f35eab4e30b728ab258c914887e1dc8c9e1d256c2978b")
