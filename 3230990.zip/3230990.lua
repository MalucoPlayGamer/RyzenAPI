-- Lua provided by RyzenAPI
-- Game: Game: Lust Academy Final

-- MAIN APPLICATION
addappid(3230990)
-- Game: addappid(3230990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3230991, 1, "d1d5e360e6e5b5afa62ed0da2468da1f817a853154bbe5e502caf1846539504c")
addappid(3625630, 0, "46642d1567457ff9aa3f42b96262024fa77c6e60b7ddac850e7c7959c20d0f58")
addappid(3626060, 0, "234075db63c4153b7ae55622e9867591c85dae14d341f2fb5e50d6011d469727")
