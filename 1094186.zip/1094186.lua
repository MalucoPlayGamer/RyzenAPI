-- Lua provided by RyzenAPI
-- Game: addappid(1094186)

-- MAIN APPLICATION
addappid(1094186)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094186,0,"19157ca759c53a28572c0141cf1b2d151e552d7d749d22a40d1c961fe08afbc1")
