-- Lua provided by RyzenAPI 
-- Game: AppID 760750
addappid(760750)
addappid(760751, 1, "3fe55e64d1d1ec7009ea0fa209a25ef019da0e40d6d4da15ab500c7c0641831f")
