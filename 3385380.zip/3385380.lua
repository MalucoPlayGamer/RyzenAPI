-- Lua provided by RyzenAPI
-- Game: Game: Mars Survivor

-- MAIN APPLICATION
addappid(3385380)
-- Game: addappid(3385380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385381, 1, "f66005910a29260bbc408aa38a8193a042b591ac365b3902c11edcf1846cbba6")
addappid(3387480, 0, "0bfebb35066f3bb4001bec4836194f5f77ca050d13a3e78f46a9bf65b8de963e")
addappid(3387490, 0, "fde9e24bd62d868a60df61fcebb98ea86a4fa1db98a438b424d8d711ecec0538")
addappid(3387500, 0, "42288f130fab3b402caf65d1fe7dfb4079e7e5d97e308091302e172707e25497")
