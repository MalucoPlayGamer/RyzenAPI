-- Lua provided by RyzenAPI
-- Game: Night Forest

-- MAIN APPLICATION
addappid(528080)

-- MAIN APP DEPOTS / PACKAGES
addappid(528081, 1, "27de6995a129f536e2f812446945e587e52204874211ac5400e6cf4a7285cba7")

