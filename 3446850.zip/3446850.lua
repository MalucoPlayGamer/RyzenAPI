-- Lua provided by RyzenAPI
-- Game: Skufs VS Quadrobers

-- MAIN APPLICATION
addappid(3446850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3446851, 1, "9971739238be7f6f5a9d2fa1717819e11d4141c0c4053276656a3bf15721867d")

