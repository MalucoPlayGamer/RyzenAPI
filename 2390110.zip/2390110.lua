-- Lua provided by RyzenAPI
-- Game: 全裸徘徊的女子大學生~害羞的椎名酱 Demo

-- MAIN APPLICATION
addappid(2390110)
-- Game: addappid(2390110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390114,0,"53dca7c21b1a557af178f13eb40cafa7110adea91fe34969822336237d1d3af9")
addappid(2390118,0,"5590fe3338dde31e36c1133fd990300d1fda109be887ce42f530a2fcc9ac7d7a")
