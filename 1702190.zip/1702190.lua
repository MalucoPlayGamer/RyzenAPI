-- Lua provided by RyzenAPI
-- Game: addappid(1702190)

-- MAIN APPLICATION
addappid(1702190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702191, 1, "564165ca7f70d8b6df283abac3ef06b1ffeab934662d73f476c78c13deb76e23")
