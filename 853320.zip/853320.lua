-- Lua provided by RyzenAPI
-- Game: KURT - DER FUSSBALLMANAGER

-- MAIN APPLICATION
addappid(853320)

-- MAIN APP DEPOTS / PACKAGES
addappid(853321,0,"e75f1854029c4ecefb7215ab321bb592fd1f83d896daa4febdbbdbd76d3ad448")

