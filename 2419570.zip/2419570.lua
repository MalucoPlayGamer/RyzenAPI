-- Lua provided by RyzenAPI
-- Game: addappid(2419570)

-- MAIN APPLICATION
addappid(2419570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419571, 1, "4d1c712f337a4256e1691b5ac52767e0101c61d0eecaad35ebcc7eef011886e7")
