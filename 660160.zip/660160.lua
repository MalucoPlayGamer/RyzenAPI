-- Lua provided by RyzenAPI
-- Game: Field of Glory II

-- MAIN APPLICATION
addappid(660160)

-- MAIN APP DEPOTS / PACKAGES
addappid(660161, 1, "8e53a2dafa5479621f2fd5dcafa2fc77a57946667633dd66a64f4fe6d0c00709")

