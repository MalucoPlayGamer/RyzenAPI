-- Lua provided by RyzenAPI
-- Game: AppID 640820

-- MAIN APPLICATION
addappid(640820)
addappid(900440)
addappid(900441)
addappid(900443)
addappid(900446)
addappid(900447)
addappid(900448)
addappid(900449)
addappid(937800)
addappid(945270)
addappid(945271)
addappid(965950)
addappid(1041820)
-- Game: addappid(640820)

-- MAIN APP DEPOTS / PACKAGES
addappid(640821, 1, "5500cfb36237aee34c1e00dcafeaed66767a9d7bd26acb5cd26f6390357fed52")
addappid(640825, 1, "afff0889a5515404453fb8e318bee45e47f95597a522d34c7a11d947598b57c7")
addappid(640826, 1, "ef322b166044e1945811e88da539b6d093629d4e556cc2b8e86ba22eebbb32cf")
addappid(900442, 0, "aa3827b463190eff81708f095ded308f48d97617cadef7b12b562cf88052caa0")
addappid(900444, 0, "f0dde855452fbc82b6b6488ea0cbe6b31b9ad10bc29c9b17a0f2c0d2c599a044")
addappid(900445, 0, "9645783f51f1e9c79f3e043c3d86f69166d70e4d2152f5179e53ac94d2296678")
addappid(947090, 0, "ebbb7ce8555c374013fe56e260667da9fcf876e1784aeabd74f80206fe5e74a5")
addappid(951520, 0, "52222ef33623a9623461b64ed36ab6d25aeccff6d56953c593996ea889acaa4c")
