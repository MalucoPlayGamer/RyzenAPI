-- Lua provided by RyzenAPI
-- Game: 2505330

-- MAIN APPLICATION
addappid(2505330)
-- Game: addappid(2505330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505331, 1, "17ffc278b1986983fbecb4f02b742a7753ff585a69546e3cabd603214e5d3881")
