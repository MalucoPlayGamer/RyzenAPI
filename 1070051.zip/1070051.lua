-- Lua provided by RyzenAPI
-- Game: Crystar - Mephis’s Clothes

-- MAIN APPLICATION
addappid(1070051)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070051,0,"524d825961e87c6d384df417c169a7194c27407a4602ee443da1e13280137ace")

