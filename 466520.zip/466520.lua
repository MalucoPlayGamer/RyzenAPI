-- Lua provided by RyzenAPI 
-- Game: AppID 466520
addappid(466520)
addappid(466521, 1, "429d8bbb8db49db01cd767c89580c96f23d5c49445463a7018c82ad3aebc76e1")
