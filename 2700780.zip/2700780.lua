-- Lua provided by RyzenAPI
-- Game: 2700780

-- MAIN APPLICATION
addappid(2700780)
-- Game: addappid(2700780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700781, 1, "08f2019fe4e38500c4a66a05b0cb15e55999e3b0775e30f753973e6de1c272fa")
