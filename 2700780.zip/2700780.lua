-- Lua provided by SkyAPI 
-- Game: my eyes deceive
addappid(2700780)
addappid(2700781, 1, "08f2019fe4e38500c4a66a05b0cb15e55999e3b0775e30f753973e6de1c272fa")
