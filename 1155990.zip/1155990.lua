-- Lua provided by RyzenAPI
-- Game: AppID 1155990

-- MAIN APPLICATION
addappid(1155990)
-- Game: addappid(1155990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155991, 1, "9a9a2a16abd75390c4efd9de89c69d733cf328f4070d44585bb50f0125ec38a6")
