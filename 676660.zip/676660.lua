-- Lua provided by RyzenAPI
-- Game: 逮到你了!

-- MAIN APPLICATION
addappid(676660)

-- MAIN APP DEPOTS / PACKAGES
addappid(676661, 1, "811b87b23840d8d0ef8420b1fb2bdc7086fdf2e744010f5716e4d9401c49aaef")

