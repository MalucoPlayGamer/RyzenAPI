-- Lua provided by RyzenAPI
-- Game: 1432152

-- MAIN APPLICATION
addappid(1432152)
-- Game: addappid(1432152)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432152,0,"37bec2ecb8c663c78c6d2219174f4ff6a30d812a64c4267947279d5f2f05cb4b")
