-- Lua provided by RyzenAPI
-- Game: Crazy Soccer: Football Stars

-- MAIN APPLICATION
addappid(735550)
addappid(907480)

-- MAIN APP DEPOTS / PACKAGES
addappid(735551, 1, "33601c3757f23866ed4115e9cafec9e8ef48a96e656bc5de1461caa98c9969d5")
