-- Lua provided by RyzenAPI
-- Game: Sex Gym 3D

-- MAIN APPLICATION
addappid(2194700)
-- Game: addappid(2194700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194701, 1, "30a9e08f57939c4153c1ae29fa51b277a7451c2b3a0473900c49594562c96076")
