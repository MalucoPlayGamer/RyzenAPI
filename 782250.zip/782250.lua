-- Lua provided by RyzenAPI
-- Game: addappid(782250)

-- MAIN APPLICATION
addappid(782250)

-- MAIN APP DEPOTS / PACKAGES
addappid(782251, 1, "8815ff9e4102a2811d5fbe6142f03e9b13de0c9604afb102971db61349594e14")
