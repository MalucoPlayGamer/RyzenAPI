-- Lua provided by RyzenAPI
-- Game: Cyberpunk sex

-- MAIN APPLICATION
addappid(2681100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681101, 1, "407e1d9f9dc176f599baf0cb681393979b8b6c00cb527ff10fcfcbb6ae75cbf3")
