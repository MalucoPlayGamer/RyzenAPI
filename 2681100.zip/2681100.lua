-- Lua provided by RyzenAPI
-- Game: Cyberpunk sex

-- MAIN APPLICATION
addappid(2681100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681101, 1, "407e1d9f9dc176f599baf0cb681393979b8b6c00cb527ff10fcfcbb6ae75cbf3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2725880)
addappid(2725890)
addappid(2758430)
addappid(2758440)
addappid(2758450)
addappid(2758460)
addappid(2758470)
addappid(2758480)
addappid(2759150)
addappid(2761030)
addappid(2761040)
