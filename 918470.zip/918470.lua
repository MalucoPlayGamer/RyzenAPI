-- Lua provided by RyzenAPI
-- Game: Rage in Peace - Soundtrack

-- MAIN APPLICATION
addappid(918470)
-- Game: addappid(918470)

-- MAIN APP DEPOTS / PACKAGES
addappid(918470,0,"1b4f2a7175fc50c18b8e59533a27aba9b389e9a945b756a10bced083adecc859")
