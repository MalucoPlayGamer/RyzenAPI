-- Lua provided by RyzenAPI 
-- Game: Endustry
addappid(1646280)
addappid(1646281, 1, "901a9c895894bf520593aec99dce13ee6c70dc4c8e356c1b897c6feefe101bd7")
