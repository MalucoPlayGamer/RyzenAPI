-- Lua provided by RyzenAPI
-- Game: AI Roguelite

-- MAIN APPLICATION
addappid(1889620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889621, 1, "e2d9736a341777e7b0a4b59f907560a5af408413627f921d1ac8c02b9c3b2eb4")

