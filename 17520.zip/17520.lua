-- Lua provided by RyzenAPI
-- Game: Game: Synergy

-- MAIN APPLICATION
addappid(17520)
-- Game: addappid(17520)

-- MAIN APP DEPOTS / PACKAGES
addappid(17521, 1, "1e5c0916e4eaa9a1f394e8dcfdf3dceeb5f8692c14f6004684e055ad835028e2")
addappid(17522, 1, "79dec28a9ccea607779ffdd986dd6244ef741815c934b5b6d5f9e4e04531e179")
addappid(17523, 1, "e59ef6c6c547cd7bc480a3d02e88953d7133ba1d509ce684908f6ce36dd68f69")
addappid(17524, 1, "0a4067bfc0fed07ba12717cecb9b9dda88664e9a0696e13491559e7a79982bd6")
