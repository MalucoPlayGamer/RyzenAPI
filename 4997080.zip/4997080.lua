-- Lua provided by RyzenAPI
-- Game: Big Tiddy Goth Baddie🖤⛓️

-- MAIN APPLICATION
addappid(5076620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4997080, 1, "3ec7e9ceb343dfe7576cb9ab2f03f7d9bdaa88206782dbd8f13de035dfb72545") -- Big Tiddy Goth Baddie🖤⛓️
addappid(4997081, 1, "c0f70560e4775147ebc6cfd44ee63eb76877075f3019082a8c1a82aae827d296") -- Depot 4997081
addappid(4997082, 1, "d6d8fa76ae85d880999ea4c9d76acbedfb5c0a2ceb72f4cc86a594e09d67e128") -- Depot 4997082
addappid(4997083, 1, "d86c3271ae2ef883fab7fa9b42492e4f678fc5ece73c58cbd96f19ef7c674235") -- Depot 4997083
addappid(5076620, 1, "973603191684d30070265976b93be14413aea0647ea1bf2c899b3e9365470182") -- Big Tiddy Goth Baddie - Wallpapers 18 - Depot 5076620

