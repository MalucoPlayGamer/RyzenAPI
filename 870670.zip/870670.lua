-- Lua provided by RyzenAPI
-- Game: Game: Ink Cipher

-- MAIN APPLICATION
addappid(870670)
-- Game: addappid(870670)

-- MAIN APP DEPOTS / PACKAGES
addappid(870671, 1, "04156748783a2fdd36b6df250769a2a0219f192145db5069916050dd21653060")
