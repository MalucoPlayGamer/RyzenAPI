-- Lua provided by RyzenAPI
-- Game: Penis Hero - Adult Only

-- MAIN APPLICATION
addappid(2609120)
-- Game: addappid(2609120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609121, 1, "56a94c84bbcf45bb3bd80c457444293827d026514d3841d4d3d3e53e528e8243")
