-- Lua provided by RyzenAPI
-- Game: Chinese Frontiers

-- MAIN APPLICATION
addappid(1640820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1640821, 1, "2de4c341c69a5caece120eed798bbd441bada826bdf8b1ea784ad8d1964397b9")
addappid(1640822, 1, "523e44823dd5e6b046a2f63a9d4c6cdea4d21188c21f153da271138c00b1685e")

