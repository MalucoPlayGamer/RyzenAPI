-- Lua provided by RyzenAPI
-- Game: Star Trek™: Starfleet Academy

-- MAIN APPLICATION
addappid(364810)

-- MAIN APP DEPOTS / PACKAGES
addappid(364811, 1, "350eecda1c1cae3ff15f092b41c2560fd24c7e6f27350521f464fa07950a4721")
addappid(364812, 1, "0ff2bdde7202739794add90a5da013913c83dc9ed174bedf87db5aba0a4a3b06")
