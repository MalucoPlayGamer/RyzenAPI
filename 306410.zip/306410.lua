-- Lua provided by RyzenAPI
-- Game: Crystals of Time

-- MAIN APPLICATION
addappid(306410)

-- MAIN APP DEPOTS / PACKAGES
addappid(306411, 1, "b1761cc37f665e2e95dddd3f7e2d2715c3f6317d04dde24f21183831dc2eb98c")
