-- Lua provided by RyzenAPI
-- Game: Moss Destruction

-- MAIN APPLICATION
addappid(876220)
-- Game: addappid(876220)

-- MAIN APP DEPOTS / PACKAGES
addappid(876221, 1, "ecc40267579ed00a5ccff29fff0be88a30273b49d29c155c95099ed3417d3540")
addappid(876222, 1, "d7e230a2bad0ae4850b7afc80b858e24225cbe17bc7c49cc8a87028c7a85a3b3")
addappid(876223, 1, "687eba56d847c51154c83e590cd5626696f7d2326583f803d100dde2e43a3f28")
