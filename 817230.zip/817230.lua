-- Lua provided by RyzenAPI
-- Game: Acid Spy

-- MAIN APPLICATION
addappid(817230)

-- MAIN APP DEPOTS / PACKAGES
addappid(817231, 1, "7cc2f82e028b3670bcbbf9e60c93a9ec8a79c34f65a9246c3a594c5c1e2e1628")
