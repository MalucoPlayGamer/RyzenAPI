-- Lua provided by RyzenAPI
-- Game: Acid Spy

-- MAIN APPLICATION
addappid(817230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(817231, 1, "7cc2f82e028b3670bcbbf9e60c93a9ec8a79c34f65a9246c3a594c5c1e2e1628")

