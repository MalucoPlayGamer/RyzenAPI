-- Lua provided by RyzenAPI
-- Game: 1335150

-- MAIN APPLICATION
addappid(1335150)
-- Game: addappid(1335150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335151, 1, "e652a52c38b26af7915e82b354a9c772c338ab3873ace738c9906e20a2db1a33")
addappid(1335152, 1, "7fa6bb807f53a5fc236d5fbcd70f68dba86c5d3dad4ed45227832c0e2580a3a5")
addappid(1335153, 1, "eeb9d11fbcf8d3edd57167d13b3f28cdc408e0268260df6271db0cd656e11f53")
