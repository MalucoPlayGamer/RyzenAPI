-- Lua provided by SkyAPI 
-- Game: Tube Tussle
addappid(1501900)
addappid(1501901, 1, "290249e2ebd021c234f6fa22128c874d552b4d32a5c535a7121182c258929b30")
