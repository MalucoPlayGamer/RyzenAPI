-- Lua provided by RyzenAPI
-- Game: Game: Tube Tussle

-- MAIN APPLICATION
addappid(1501900)
-- Game: addappid(1501900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501901, 1, "290249e2ebd021c234f6fa22128c874d552b4d32a5c535a7121182c258929b30")
