-- Lua provided by RyzenAPI
-- Game: Tube Tussle

-- MAIN APPLICATION
addappid(1501900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1501901, 1, "290249e2ebd021c234f6fa22128c874d552b4d32a5c535a7121182c258929b30")

