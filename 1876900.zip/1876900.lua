-- Lua provided by RyzenAPI
-- Game: sniper

-- MAIN APPLICATION
addappid(1876900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876901, 1, "c09920bb86f29860795b68da3396cb170ded2d787bf664e2cd48e6872080c57c")
