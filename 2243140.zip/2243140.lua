-- Lua provided by RyzenAPI
-- Game: Guns & Fishes

-- MAIN APPLICATION
addappid(2243140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243141, 1, "497ec347af37bb7fdaed23a918d7fcbcf4a3d6326e9fc8a570e2edd3a96a1e02")

