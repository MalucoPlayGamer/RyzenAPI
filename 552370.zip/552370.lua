-- Lua provided by RyzenAPI
-- Game: 552370

-- MAIN APPLICATION
addappid(552370)
-- Game: addappid(552370)

-- MAIN APP DEPOTS / PACKAGES
addappid(552371, 1, "070b8ff3842dab7184d4bd66e3dbfb1f9ad91880ebb9758bbf5ab13794f29446")
