-- Lua provided by RyzenAPI
-- Game: Nine Sols Digital Art Book

-- MAIN APPLICATION
addappid(3362590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362591, 1, "0d84cc89dc3f66b203521c09e53075478305ba8702859948d892ba9c3bf0d9d0")

