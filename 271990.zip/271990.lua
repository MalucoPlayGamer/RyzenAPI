-- Lua provided by RyzenAPI
-- Game: Dreamscape

-- MAIN APPLICATION
addappid(271990)
addappid(366740)

-- MAIN APP DEPOTS / PACKAGES
addappid(271991, 1, "a949642d73ee373b73ebd960ee77e0a1ecb3fe626235364af1dfa9ff25deecd0")

