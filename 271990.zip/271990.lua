-- Lua provided by RyzenAPI
-- Game: Dreamscape

-- MAIN APPLICATION
addappid(271990)
addappid(366740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(271991, 1, "a949642d73ee373b73ebd960ee77e0a1ecb3fe626235364af1dfa9ff25deecd0")

