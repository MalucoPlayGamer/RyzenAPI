-- Lua provided by RyzenAPI
-- Game: Game: AppID 701420

-- MAIN APPLICATION
addappid(701420)
-- Game: addappid(701420)

-- MAIN APP DEPOTS / PACKAGES
addappid(701421, 1, "b145311a5a3bdd485d3ee149f9eadbdee9aacc0b8542b6e0cd4156666e320f7a")
addappid(701422, 1, "07eb1c3e0199b2f4e1aae5ef8ccffc440408c7346cfc94acf1e01cd0db0bdbcb")
