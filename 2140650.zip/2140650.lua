-- Lua provided by RyzenAPI
-- Game: AppID 2140650

-- MAIN APPLICATION
addappid(2140650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140651, 1, "0c18c740ee124a67894e324dd7cf67a1d21e654b5f4b7e5c544a93f43b3d7c53")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2362880)
addappid(2362881)
addappid(2362882)
addappid(2362883)
addappid(3178940)
