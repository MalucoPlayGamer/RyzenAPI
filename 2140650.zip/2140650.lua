-- Lua provided by RyzenAPI
-- Game: Game: AppID 2140650

-- MAIN APPLICATION
addappid(2140650)
-- Game: addappid(2140650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140651, 1, "0c18c740ee124a67894e324dd7cf67a1d21e654b5f4b7e5c544a93f43b3d7c53")
