-- Lua provided by RyzenAPI
-- Game: Ether Awakening

-- MAIN APPLICATION
addappid(664820)

-- MAIN APP DEPOTS / PACKAGES
addappid(664821, 1, "794dd6715022fc0ed5cb6d21129388c756a218e0c910f706c718ed982cef2be5")

