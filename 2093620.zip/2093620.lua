-- Lua provided by RyzenAPI
-- Game: addappid(2093620)

-- MAIN APPLICATION
addappid(2093620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093621, 1, "2123dae24ce5ea82cc71d07cc25e02ecf7d5086d29b6a05cbd2ab4bb9ec148db")
