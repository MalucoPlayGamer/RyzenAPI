-- Lua provided by SkyAPI 
-- Game: Cowboy's Adventure
addappid(666960)
addappid(666961, 1, "eefa2210df961a33ac766a9fb07bdad5759abe0ab1342bac29bad7bf2e503b25")
