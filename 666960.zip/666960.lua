-- Lua provided by RyzenAPI
-- Game: Cowboy's Adventure

-- MAIN APPLICATION
addappid(666960)
-- Game: addappid(666960)

-- MAIN APP DEPOTS / PACKAGES
addappid(666961, 1, "eefa2210df961a33ac766a9fb07bdad5759abe0ab1342bac29bad7bf2e503b25")
