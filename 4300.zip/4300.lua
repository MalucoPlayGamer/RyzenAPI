-- Lua provided by RyzenAPI
-- Game: Game: RoboBlitz

-- MAIN APPLICATION
addappid(4300)
-- Game: addappid(4300)

-- MAIN APP DEPOTS / PACKAGES
addappid(4301, 1, "ba38043912a703cd5a7c22fa414553ea2aafbccd789f1d2cae6cca2419df89ce")
