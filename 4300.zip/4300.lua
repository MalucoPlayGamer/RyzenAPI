-- Lua provided by SkyAPI 
-- Game: RoboBlitz
addappid(4300)
addappid(4301, 1, "ba38043912a703cd5a7c22fa414553ea2aafbccd789f1d2cae6cca2419df89ce")
