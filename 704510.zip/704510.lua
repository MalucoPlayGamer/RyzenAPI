-- Lua provided by RyzenAPI
-- Game: Mercury Fallen

-- MAIN APPLICATION
addappid(704510)

-- MAIN APP DEPOTS / PACKAGES
addappid(704513,0,"45356693043e52e78a339c22140d4b9eedac03f400de642100df13fa26c97c7f")
addappid(704514,0,"326f90cf9e0cc82b24b2325f8f1d1585dd2def5dda648d5a8714e6b8dd6e2ca1")
