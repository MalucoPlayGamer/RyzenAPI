-- Lua provided by SkyAPI 
-- Game: AppID 1873920
addappid(1873920)
addappid(1873921, 1, "2f8c4997cfe67289792a291ce78ff5aced77d0a5c60f01886f0ba329900adb59")
