-- Lua provided by RyzenAPI
-- Game: Game: AppID 1873920

-- MAIN APPLICATION
addappid(1873920)
-- Game: addappid(1873920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873921, 1, "2f8c4997cfe67289792a291ce78ff5aced77d0a5c60f01886f0ba329900adb59")
