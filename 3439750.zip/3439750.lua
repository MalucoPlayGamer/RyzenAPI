-- Lua provided by RyzenAPI
-- Game: KARMA: The Dark World - Artbook

-- MAIN APPLICATION
addappid(3439750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439750,0,"87d3dd47ec8a8d3adf83e1b1c2a5435bc9e88cf998ac95c4273c5bdaed488b91")
