-- Lua provided by RyzenAPI
-- Game: Journey of Life

-- MAIN APPLICATION
addappid(794490)

-- MAIN APP DEPOTS / PACKAGES
addappid(794491,0,"0a63e4349d7a0b79cf5e57057a6da9e6e62e13d89d8da186ab9a4d1028b8bb16")

