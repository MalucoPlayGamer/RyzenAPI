-- Lua provided by RyzenAPI
-- Game: Game: Projectile Dysfunction

-- MAIN APPLICATION
addappid(1351950)
-- Game: addappid(1351950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351951, 1, "67372e311f52157c0ad8f70b131801b8c535a35ed64f5d882d6cbc3ea62a5827")
