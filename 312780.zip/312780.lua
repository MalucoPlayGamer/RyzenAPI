-- Lua provided by RyzenAPI
-- Game: AppID 312780

-- MAIN APPLICATION
addappid(312780)
-- Game: addappid(312780)

-- MAIN APP DEPOTS / PACKAGES
addappid(312781, 1, "283af22c8e9dc9a74670197b5d11f643529eccb13deb029f6d087ca71bfbda23")
