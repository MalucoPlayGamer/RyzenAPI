-- Lua provided by RyzenAPI
-- Game: Way of the Samurai 4

-- MAIN APPLICATION
addappid(312780)
addappid(333810)
addappid(333811)
addappid(333812)
addappid(333813)
addappid(333814)
addappid(333815)
addappid(333816)
addappid(333817)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(312781, 1, "283af22c8e9dc9a74670197b5d11f643529eccb13deb029f6d087ca71bfbda23")

