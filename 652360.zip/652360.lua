-- Lua provided by RyzenAPI
-- Game: BFF or Die

-- MAIN APPLICATION
addappid(652360)
-- Game: addappid(652360)

-- MAIN APP DEPOTS / PACKAGES
addappid(652361, 1, "1eac76e4506b97dadc1f55403fc6861546268e087cdc9b0f250eef7a99fa17d5")
addappid(652362, 1, "369ca063cdedbd0145d665d0bcf0a0cab0008e4263877ecbc77fbb3f0f4e682e")
addappid(652363, 1, "da8aaf37873b85a90d2e246ef37a19beeb935472ddd74cbb528c8ad64ef68aac")
addappid(652364, 1, "2fe77174a8c567fc95e638d43600791b9390222db8a583583b30193b63676d6f")
