-- Lua provided by SkyAPI 
-- Game: My Femboy Maid
addappid(3521670)
addappid(3521671, 1, "bfe9149cc1e13d1791fd82deb86e3056d82555e3901674876cda4d1e10996081")
