-- Lua provided by RyzenAPI
-- Game: Game: Attack Of Insects

-- MAIN APPLICATION
addappid(707400)
-- Game: addappid(707400)

-- MAIN APP DEPOTS / PACKAGES
addappid(707401, 1, "12d71fcd1424b63e385b46d085e5040cc21fbfde5cb2f9c014859c04e636f720")
