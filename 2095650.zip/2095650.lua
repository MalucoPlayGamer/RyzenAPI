-- Lua provided by RyzenAPI
-- Game: Game: Sakamoto Dangerous Barrage

-- MAIN APPLICATION
addappid(2095650)
-- Game: addappid(2095650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095651, 1, "7e37e5aca6513848aa0ffc2f8df508ddaad9f678bcb12aa5b8f3168c0d6f0281")
