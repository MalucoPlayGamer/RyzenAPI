-- Lua provided by RyzenAPI 
-- Game: Sakamoto Dangerous Barrage
addappid(2095650)
addappid(2095651, 1, "7e37e5aca6513848aa0ffc2f8df508ddaad9f678bcb12aa5b8f3168c0d6f0281")
