-- Lua provided by RyzenAPI 
-- Game: Personal Study
addappid(2878000)
addappid(2878001, 1, "0bea8f1a793fa678e815c85c9c5fc07fb54eb2325124eabaea048bb2cf3dad50")
