-- Lua provided by RyzenAPI
-- Game: Heroine Anthem Zero -Sacrifice-

-- MAIN APPLICATION
addappid(537990)

-- MAIN APP DEPOTS / PACKAGES
addappid(537991, 1, "774ee05d0b1c40c22921b3766f49d1a171db712d92fb35379ce54d1394f4d406")
