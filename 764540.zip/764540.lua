-- Lua provided by RyzenAPI
-- Game: Tall Order

-- MAIN APPLICATION
addappid(764540)

-- MAIN APP DEPOTS / PACKAGES
addappid(764541,0,"0505c4ac6cfb7c2837317d68fd1ecbcae5fa4ccf58716a118c32cecf37ecc094")

