-- Lua provided by RyzenAPI
-- Game: Game: The Tower Of Babel

-- MAIN APPLICATION
addappid(2762390)
-- Game: addappid(2762390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762391, 1, "cdbb567aac0d3513c388aaf06ee56049c453704dce4c89f510e650f3c31d0ec2")
