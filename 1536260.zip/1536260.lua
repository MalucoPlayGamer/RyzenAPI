-- Lua provided by RyzenAPI
-- Game: Odenavirus: Zombie Invasion

-- MAIN APPLICATION
addappid(1536260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536261, 1, "3d07447cf583f439aa98e45b02bff42609664bb61b8425e2ba3d4605df6ba600")

