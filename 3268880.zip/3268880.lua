-- Lua provided by RyzenAPI
-- Game: addappid(3268880)

-- MAIN APPLICATION
addappid(3268880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268881, 1, "84801fc0b9a5ce26c39237dcf7e1b0a40c911eabb44dfbd46bf29394ac3788b2")
