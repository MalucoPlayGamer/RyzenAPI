-- 266310's Lua and Manifest Created by Hubcap Manifest
-- GameGuru Classic
-- Created: March 14, 2026 at 13:55:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 36
-- Total DLCs: 30
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(266310, 1, "8621c4f2478784feb016440433f4da4539c76fcb0e33022930ca58019f01a753") -- GameGuru Classic
-- MAIN APP DEPOTS
addappid(266311, 1, "c7c5a17cf2167455b6e5dcc635910ae5271171445f4456caf294d9f2ff5ec665") -- GameGuru Depot
setManifestid(266311, "1883178605046777468", 9998231747)
addappid(266312, 1, "52d67fd169fb43de30e74117f60d5c1c94b7fdac0c9c12fac7ec6fed69f06d1e") -- GameGuru Free Depot
setManifestid(266312, "1665326620875035761", 9440504172)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- GameGuru - Mega Pack 1 (AppID: 321140)
addappid(321140)
addappid(321140, 1, "e68528d0ee1b4b7c8d46c5a83df84d1c4957a98eb5eeec5f75bf9253f033f4e8") -- GameGuru - Mega Pack 1 - GameGuru - Mega Pack 1 (321140) Depot
setManifestid(321140, "883603378483681200", 1387971967)
-- GameGuru - Mega Pack 2 (AppID: 321141)
addappid(321141)
addappid(321141, 1, "d657286975c9960912e6839fbe1aa16925e25415188c74f78954f648ca827aa3") -- GameGuru - Mega Pack 2 - GameGuru - Mega Pack 2 (321141) Depot
setManifestid(321141, "7613612883485684566", 1401795965)
-- GameGuru - Mega Pack 3 (AppID: 321142)
addappid(321142)
addappid(321142, 1, "27df1cb778dfea0601adcd690d6c9de1ae76d2c511017d19079bfa77ac5cb4e9") -- GameGuru - Mega Pack 3 - GameGuru - Mega Pack 3 (321142) Depot
setManifestid(321142, "8053152552503260126", 5285990103)
-- GameGuru - Buildings Pack (AppID: 365520)
addappid(365520)
addappid(365520, 1, "11ae2bbd7af4bba99131214cfad98b46d841313a608c3fee7a0d0afa59f96526") -- GameGuru - Buildings Pack - GameGuru - Buildings Pack (365520) Depot
setManifestid(365520, "7828855718254455429", 1549045569)
-- GameGuru - Fantasy Pack (AppID: 365530)
addappid(365530)
addappid(365530, 1, "fd16f02d86b7d2e848c4a13d778a264bf7959e153bb92f9f27fec67c9e127af4") -- GameGuru - Fantasy Pack - GameGuru - Fantasy Pack (365530) Depot
setManifestid(365530, "6987326408433425723", 369360997)
-- GameGuru - Death Valley Pack (AppID: 365540)
addappid(365540)
addappid(365540, 1, "066ca04b9aa35d7e46c88ec4bb74b62a3a730ea6a82ffe7cf63878fa2a8da1eb") -- GameGuru - Death Valley Pack - GameGuru - Death Valley Pack (365540) Depot
setManifestid(365540, "923308570436860670", 914890870)
-- GameGuru - Sci-Fi Mission to Mars Pack (AppID: 404570)
addappid(404570)
addappid(404570, 1, "b4e4ebab75572449ea2bffef12d358dac871ec6b9a5c57cf091e3f9995467a91") -- GameGuru - Sci-Fi Mission to Mars Pack - GameGuru - Sci Fi Mission to Mars Pack  (404570) Depot
setManifestid(404570, "2912778931375440243", 655593332)
-- GameGuru - Easter Game (AppID: 451370)
addappid(451370)
addappid(451370, 1, "c60bd200fdf6dbdaa3f294172905b8a3c282b2badba60b40b660922fa4b23cb4") -- GameGuru - Easter Game - GameGuru - Easter Game (451370) Depot
setManifestid(451370, "177175013964933120", 324271380)
-- GameGuru - Expansion Pack (AppID: 496580)
addappid(496580)
addappid(496580, 1, "d3ab96cacd64fea95eae66f1f397807ae87836a322597e72bd6458d20fee7a84") -- GameGuru - Expansion Pack - GameGuru - Expansion Pack (496580) Depot
setManifestid(496580, "1768123728023658715", 3013741599)
-- GameGuru - Melee Weapons Pack (AppID: 822010)
addappid(822010)
addappid(822010, 1, "4057261249da0db4adeb8512229a796dd4c1f22fb2fe0721dc77ad8a2cfe3df6") -- GameGuru - Melee Weapons Pack - GameGuru - Melee Weapons Pack (822010) Depot
setManifestid(822010, "3627934872153505080", 1009249655)
-- GameGuru - Construction Site Pack (AppID: 854050)
addappid(854050)
addappid(854050, 1, "c986f0c64ff00469fce45c235689601221959ac40c714e5761146790eebb3a12") -- GameGuru - Construction Site Pack - GameGuru - Construction Site Pack (854050) Depot
setManifestid(854050, "6226507105448457", 2498273769)
-- GameGuru - Enhanced Weapons Pack (AppID: 907510)
addappid(907510)
addappid(907510, 1, "8ea664ab14e0024c5f9a37d996373843c953ec3bb6acbedfc5ca3685dcfe000e") -- GameGuru - Enhanced Weapons Pack - GameGuru - Enhanced Weapons Pack (907510) Depot
setManifestid(907510, "487871512110438433", 852995776)
-- GameGuru - Antiques In The Attic Pack (AppID: 935590)
addappid(935590)
addappid(935590, 1, "d83d942fde31e1781d77d9b7ea90cbe2fa7322b1a303e935c9255d2d5dfe6eaa") -- GameGuru - Antiques In The Attic Pack - GameGuru - Antiques In The Attic Pack (935590) Depot
setManifestid(935590, "2815407287972315151", 1516862760)
-- GameGuru - Medical Pack (AppID: 964530)
addappid(964530)
addappid(964530, 1, "55ebf6c2c52c01472760203f5ac1a0703975242f06f366da08804c5fcdfb3e8f") -- GameGuru - Medical Pack - GameGuru - Medical Pack (964530) Depot
setManifestid(964530, "9117364205499052240", 583081375)
-- GameGuru - Abandoned Apartment Pack (AppID: 989810)
addappid(989810)
addappid(989810, 1, "674871967e1f260d723c77a160f906c6eaabbfdbe2a51625b51cc8612c2858a9") -- GameGuru - Abandoned Apartment Pack - GameGuru - Abandoned Apartment Pack (989810) Depot
setManifestid(989810, "7188474566422303036", 384739055)
-- GameGuru - Cold War Pack (AppID: 996910)
addappid(996910)
addappid(996910, 1, "a81b5539b060c2509a9b43e021f8abf774f263071ddda0d677b5236c04bf9bdf") -- GameGuru - Cold War Pack - GameGuru - Cold War Pack (996910) Depot
setManifestid(996910, "6385852909586614767", 4470556982)
-- GameGuru - Military Pack (AppID: 1150680)
addappid(1150680)
addappid(1150680, 1, "8cd3d3d487c8996a71042d269e764a5e04e427dd5c79dd30dbe276a76f3705b1") -- GameGuru - Military Pack - GameGuru - Military Pack (1150680) Depot
setManifestid(1150680, "3467701498507983538", 1084321565)
-- GameGuru - Walled Garden Pack (AppID: 1154060)
addappid(1154060)
addappid(1154060, 1, "83dd7f4374dc96640357c1cd53c74b40f0faee9c08af8f59cc46500ae424fd72") -- GameGuru - Walled Garden Pack - GameGuru - Walled Garden Pack (1154060) Depot
setManifestid(1154060, "2780679162413252990", 730005156)
-- GameGuru - Cemetery Pack (AppID: 1306830)
addappid(1306830)
addappid(1306830, 1, "4439b7cfbc6cd5f1f997c54f68a01fc627a57d9f3206079867304a3f44c5a907") -- GameGuru - Cemetery Pack - GameGuru - Cemetery Pack (1306830) Depot
setManifestid(1306830, "1879291150495140903", 1591533940)
-- GameGuru - Tool Shed Pack (AppID: 1315570)
addappid(1315570)
addappid(1315570, 1, "d649c4b3666ef86ca96b7f7d1285d891103038478cb9d3bfc144995786775363") -- GameGuru - Tool Shed Pack - GameGuru - Tool Shed Pack (1315570) Depot
setManifestid(1315570, "1465828156602096428", 1884323831)
-- GameGuru - Camping Pack (AppID: 1338070)
addappid(1338070)
addappid(1338070, 1, "743266de101924499bc72715ce669ca093992d97a6889bd698a11948ae234d3a") -- GameGuru - Camping Pack - GameGuru - Camping Pack (1338070) Depot
setManifestid(1338070, "8049576942872568764", 931899473)
-- GameGuru - Retro 80s Pack (AppID: 1343490)
addappid(1343490)
addappid(1343490, 1, "105318c5b44f11ca2585c4dae428a6b2442dc6b76c2d4b00037e0d4110bbee07") -- GameGuru - Retro 80s Pack - GameGuru - Retro 80s Pack (1343490) Depot
setManifestid(1343490, "1244362984484217768", 871775763)
-- GameGuru - Ancient Treasures Pack (AppID: 1361590)
addappid(1361590)
addappid(1361590, 1, "e6f70793c2318d4acb9a2164dd8465630cb209fbc91f48633f3bb905bd7757a6") -- GameGuru - Ancient Treasures Pack - GameGuru - Ancient Treasures Pack (1361590) Depot
setManifestid(1361590, "2540199703674231922", 918665458)
-- GameGuru - Trees, plants and rocks Pack (AppID: 1361591)
addappid(1361591)
addappid(1361591, 1, "0d73011b048e21d97f8784e2730848e3384ebab5bab5b08bd5d10a372674fee7") -- GameGuru - Trees, plants and rocks Pack - GameGuru - Trees, plants and rocks Pack (1361591) Depot
setManifestid(1361591, "4310881406636362104", 391569620)
-- GameGuru - Furniture Pack (AppID: 1436740)
addappid(1436740)
addappid(1436740, 1, "dfd2e58480bc59d3dfc141b585a39b6be63d7d2c23dd0e01eeb7b547b915fc86") -- GameGuru - Furniture Pack - GameGuru - Furniture Pack (1436740) Depot
setManifestid(1436740, "4117777000814164679", 3426322909)
-- GameGuru - Industrial Sewer Pack (AppID: 1717480)
addappid(1717480)
addappid(1717480, 1, "57e4c1d63f958ca270f81726e9d7d6c40f84d7160eedeff4a848d10f129eb29e") -- GameGuru - Industrial Sewer Pack - GameGuru - Industrial Sewer Pack (1717480) Depot
setManifestid(1717480, "3029828138163338126", 1621409217)
-- GameGuru - CineGuru (AppID: 2137140)
addappid(2137140)
addappid(2137140, 1, "56875c491d6ad5af8af096d85ee1aa432185827209a02771aea8aeac2ed4400b") -- GameGuru - CineGuru - Depot 2137140
setManifestid(2137140, "1700258518682379012", 29596796)
-- GameGuru - Audio Ambience Pack (AppID: 2280120)
addappid(2280120)
addappid(2280120, 1, "e4ca8f5d70328c1bc0e6857c3ba5f4f2f8daaa50bb145b0d722f262d87ddbd55") -- GameGuru - Audio Ambience Pack - Depot 2280120
setManifestid(2280120, "2113012093795227902", 864295778)
-- GameGuru - Easy Terrain Tool (AppID: 2473570)
addappid(2473570)
addappid(2473570, 1, "8d1554e6f484fc14575cee3653ae179ba4d0e79e49cf2d4fdaa50b32155f760b") -- GameGuru - Easy Terrain Tool - Depot 2473570
setManifestid(2473570, "6593191658705906644", 8034243)
-- GameGuru - Cyberpunk Audio Pack (AppID: 2564670)
addappid(2564670)
addappid(2564670, 1, "39f817b06e2e6aafe348bbe2157c0fa0fd5619c5e6ebcd0243bc8da335a0675e") -- GameGuru - Cyberpunk Audio Pack - Depot 2564670
setManifestid(2564670, "7192849515688017455", 153344042)