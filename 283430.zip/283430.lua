-- Lua provided by RyzenAPI 
-- Game: Litil Divil
addappid(283430)
addappid(283431, 1, "1bfd80e6ed8af35a528934693d28756d12dfb13aeaca0e025da0cde07e9cbee9")
