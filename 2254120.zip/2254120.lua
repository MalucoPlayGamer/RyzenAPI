-- Lua provided by RyzenAPI
-- Game: EX_Holics.exe Demo

-- MAIN APPLICATION
addappid(2254120)
-- Game: addappid(2254120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254121, 1, "2dbda05abe4b28040f415824253856a33bf6cee3935b293239c161c747d66764")
