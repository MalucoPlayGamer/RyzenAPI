-- Lua provided by RyzenAPI
-- Game: POWERCUT, Inc

-- MAIN APPLICATION
addappid(944440)

-- MAIN APP DEPOTS / PACKAGES
addappid(944441, 1, "6b0e30665e0c3ac8378e93467a20c3bc1efe6cf64e646595ffb1f9ed68d12ac3")

