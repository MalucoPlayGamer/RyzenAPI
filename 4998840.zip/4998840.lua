-- Lua provided by RyzenAPI
-- Game: Spellarium 14

-- MAIN APPLICATION
addappid(4998840) -- Spellarium 14

-- MAIN APP DEPOTS / PACKAGES
addappid(4998841, 1, "635d723b32c86251405061c51d16bfe249330cc1873ed46f4681cdd8ffedda16") -- Depot 4998841
