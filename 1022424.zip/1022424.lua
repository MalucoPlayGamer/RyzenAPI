-- Lua provided by RyzenAPI
-- Game: DFF NT: Orichalcum, Zidane Tribal's 4th Weapon

-- MAIN APPLICATION
addappid(1022424)
-- Game: addappid(1022424)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022424,0,"971e1076465934759cabfad7451f40708382e925b749d30294c6258b49e57713")
