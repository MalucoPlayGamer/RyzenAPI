-- Lua provided by RyzenAPI
-- Game: Vaultbreakers Playtest

-- MAIN APPLICATION
addappid(1851490)
-- Game: addappid(1851490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851491, 1, "a2947cf82d97f2227f5374859f4cf80214242920fd1ce6ab1ae348e006783a6e")
