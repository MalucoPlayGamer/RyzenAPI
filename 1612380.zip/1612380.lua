-- Lua provided by RyzenAPI
-- Game: Game: AppID 1612380

-- MAIN APPLICATION
addappid(1612380)
-- Game: addappid(1612380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612381, 1, "4f65c52b8b295af5894a683b5e703adcb590b379349ea6c03b2d28cb2c5b42e7")
