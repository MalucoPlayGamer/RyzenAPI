-- Lua provided by RyzenAPI
-- Game: Game: AppID 889270

-- MAIN APPLICATION
addappid(889270)
-- Game: addappid(889270)

-- MAIN APP DEPOTS / PACKAGES
addappid(889271, 1, "60d765819afd83670dd4338f849f2ac500b1060d7492fbc7f816a76166a71954")
