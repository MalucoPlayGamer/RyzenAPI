-- Lua provided by RyzenAPI
-- Game: One Day for Revenge

-- MAIN APPLICATION
addappid(878100)
-- Game: addappid(878100)

-- MAIN APP DEPOTS / PACKAGES
addappid(878101, 1, "cac3dcdfb3b483bdc51baf440515ab482203f51df6329fea991a612f4dced032")
