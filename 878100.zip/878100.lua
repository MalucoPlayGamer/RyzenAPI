-- Lua provided by RyzenAPI
-- Game: One Day for Revenge

-- MAIN APPLICATION
addappid(878100)

-- MAIN APP DEPOTS / PACKAGES
addappid(878101, 1, "cac3dcdfb3b483bdc51baf440515ab482203f51df6329fea991a612f4dced032")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
