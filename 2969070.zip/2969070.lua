-- Lua provided by RyzenAPI
-- Game: Steve's Warehouse: Physics. Roguelike. Chaos. Demo

-- MAIN APPLICATION
addappid(2969070)
-- Game: addappid(2969070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969071, 1, "171096f0912705c232f52ac702325e76f82065b3f1300cf7d3a662c1261a9e37")
