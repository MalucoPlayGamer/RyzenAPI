-- Lua provided by RyzenAPI
-- Game: Technobabylon

-- MAIN APPLICATION
addappid(307580)
-- Game: addappid(307580)

-- MAIN APP DEPOTS / PACKAGES
addappid(307581, 1, "0b0bfe784dce2f5709ed9d08c6d8b5441b779be61200f9cf86ab465b6437286c")
addappid(307582, 1, "fe6199135affe2627c62914aac3d7a85c62fb092ef3141c389350f8e77b92582")
addappid(307583, 1, "66bbbf7c8416ddd340dda038124f3030d90d1fb49ef56cea82b39dea63a2dafc")
addappid(307584, 1, "752fb0a001efe1c9c770da31bf84f558853e15d92af5c7c650d98d25667b8d42")
