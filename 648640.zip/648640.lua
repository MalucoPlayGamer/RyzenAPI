-- Lua provided by RyzenAPI
-- Game: Antiquia Lost

-- MAIN APPLICATION
addappid(648640)

-- MAIN APP DEPOTS / PACKAGES
addappid(648641,0,"7a875e3bd4635babe5fd559175da2d5199143c8ad40b29a4cbc942dda49cc28f")

