-- Lua provided by RyzenAPI
-- Game: Battle Chef Brigade Deluxe

-- MAIN APPLICATION
addappid(452570)
addappid(5028170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(452571, 1, "fef5acc7049c76f018081d7a899220d14161e15deb80b6dd14d0b3368cf27638")
addappid(452572, 1, "ead485e391816be949aa7e4c25354d1e0d75c2d0627a8dc6c645027bf80ccb4b")
addappid(452573, 1, "6e6c30498ed2cee45cbde4d63bebdf86eb3bec07ccca3e979831c53199f4721e")

