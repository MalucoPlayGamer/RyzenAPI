-- Lua provided by RyzenAPI
-- Game: Adore

-- MAIN APPLICATION
addappid(1074620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074621, 1, "06b91ae89d2ff648eb674e715415a9782cae0cc2325e17d0f70116da94564ce4")

