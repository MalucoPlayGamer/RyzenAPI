-- Lua provided by RyzenAPI
-- Game: Alien Breeding Program: First Contact Demo

-- MAIN APPLICATION
addappid(2496630)
-- Game: addappid(2496630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496631, 1, "b05fb50b20a0c754794778df31b815df14955ef5573661c82c9029033030f59c")
