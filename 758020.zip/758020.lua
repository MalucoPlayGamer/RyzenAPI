-- Lua provided by RyzenAPI
-- Game: DMD Mars Mission

-- MAIN APPLICATION
addappid(758020)

-- MAIN APP DEPOTS / PACKAGES
addappid(758021,0,"ec32c2cff75f59a712fd4f1788385db6fa87e74f65506c9c8f37a3fa136d6236")

