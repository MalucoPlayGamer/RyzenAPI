-- Lua provided by RyzenAPI
-- Game: Kalimba

-- MAIN APPLICATION
addappid(324140)
addappid(346070)
addappid(346071)
addappid(348900)

-- MAIN APP DEPOTS / PACKAGES
addappid(324141, 1, "6beb7d65f75651a0cdf04475e51d81916fa0547db17af495899f17723e10350a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
