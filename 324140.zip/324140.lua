-- Lua provided by RyzenAPI
-- Game: Kalimba

-- MAIN APPLICATION
addappid(324140)
addappid(346070)
addappid(346071)
addappid(348900)

-- MAIN APP DEPOTS / PACKAGES
addappid(324141, 1, "6beb7d65f75651a0cdf04475e51d81916fa0547db17af495899f17723e10350a")

