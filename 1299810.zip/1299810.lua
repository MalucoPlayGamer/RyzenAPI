-- Lua provided by SkyAPI 
-- Game: AppID 1299810
addappid(1299810)
addappid(1299811, 1, "61c8f2044eb80ece2a29b08ea68d158e7db54c66cdcedee6af0145032a0459ad")
