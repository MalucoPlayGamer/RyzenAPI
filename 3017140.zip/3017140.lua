-- Lua provided by SkyAPI 
-- Game: IRONHIVE Demo
addappid(3017140)
addappid(3017141, 1, "c866c766a1cb74bbec5202cacf5e36dc5f8dcd986ce0ae25fbf010b781335682")
