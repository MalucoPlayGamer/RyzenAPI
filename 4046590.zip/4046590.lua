-- Lua provided by SkyAPI 
-- Game: Better Days
addappid(4046590)
addappid(4046591, 1, "0340313a7ad8fc08a401861522527cc9cc722d83d568d5f13198a6e3c7d5db27")
