-- Lua provided by RyzenAPI
-- Game: Game: Fight with love - deckbuilder datingsim

-- MAIN APPLICATION
addappid(1273940)
-- Game: addappid(1273940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273941, 1, "49632735e7b977c7db8120cc35fc44c8c5d0a79a9959d27377d7492752119917")
