-- Lua provided by RyzenAPI
-- Game: addappid(99400)

-- MAIN APPLICATION
addappid(99400)

-- MAIN APP DEPOTS / PACKAGES
addappid(99401, 1, "b103385949025d0c0cda89dbcaa3cbbdf3a59db2977f193326c16d2cc4ce95b6")
