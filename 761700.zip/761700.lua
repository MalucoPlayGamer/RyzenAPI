-- Lua provided by SkyAPI 
-- Game: Your Diary +
addappid(761700)
addappid(761701, 1, "6b7a9d1c233959b4e4aa5dee6fa510d9ee9d8f2354f6c062d765c895fabcf0d8")
