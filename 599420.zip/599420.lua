-- Lua provided by RyzenAPI
-- Game: AppID 599420

-- MAIN APPLICATION
addappid(599420)

-- MAIN APP DEPOTS / PACKAGES
addappid(599421, 1, "9a72c0209154d3c53e8937aa00648cede93645619fdb90db0bc6ab6ce5441bde")
