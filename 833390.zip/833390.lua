-- Lua provided by RyzenAPI
-- Game: En Tactico

-- MAIN APPLICATION
addappid(833390)

-- MAIN APP DEPOTS / PACKAGES
addappid(833391, 1, "c6d04d19ce5059d3bb7cd5f6312bd9db6ff2e607a7c9d2059a9c6db1bda8449a")
