-- Lua provided by RyzenAPI
-- Game: Game: 年上お姉さんの恋愛トレーニング ～Elder Sister's Love Training～

-- MAIN APPLICATION
addappid(2484030)
-- Game: addappid(2484030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484031, 1, "a2d0243d782fd8da1bba9d91f889277beba7b7111159f1d6d471187233064e3c")
