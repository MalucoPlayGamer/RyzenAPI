-- Lua provided by RyzenAPI
-- Game: Game: AppID 1905650

-- MAIN APPLICATION
addappid(1905650)
-- Game: addappid(1905650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905651, 1, "7623a8561b8bae4b4f2211cb1e23933615b24d3dc7a64c62da1b132664b7a61b")
