-- Lua provided by RyzenAPI
-- Game: Game: FrogFlop

-- MAIN APPLICATION
addappid(2490140)
-- Game: addappid(2490140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490141, 1, "f4f0daaaa81dbc630df136b8a265a21b1d890ae3dfe6b1b9aadb4ab30dc7e53f")
