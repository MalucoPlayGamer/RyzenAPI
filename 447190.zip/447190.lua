-- Lua provided by RyzenAPI
-- Game: Pub Encounter

-- MAIN APPLICATION
addappid(447190)
addappid(449920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(447191, 1, "0c8803f5a96e775fe0597aa16411864b55d3d4ae787054928a100ebe8115ee26")
