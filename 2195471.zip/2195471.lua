-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Weeknd - "Can't Feel My Face"

-- MAIN APPLICATION
addappid(2195471)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195471,0,"588f91149d2644ca2142c511305707dec94e6b588454f221669fc2360fa042d7")
