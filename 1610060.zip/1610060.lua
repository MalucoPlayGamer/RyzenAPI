-- Lua provided by RyzenAPI
-- Game: 1610060

-- MAIN APPLICATION
addappid(1610060)
-- Game: addappid(1610060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610061, 1, "e30b0446407fe03e68aa5e82ace9d21e6c196d03b712eea4d4a26adaabb7edca")
