-- Lua provided by RyzenAPI 
-- Game: Echoes
addappid(1610060)
addappid(1610061, 1, "e30b0446407fe03e68aa5e82ace9d21e6c196d03b712eea4d4a26adaabb7edca")
