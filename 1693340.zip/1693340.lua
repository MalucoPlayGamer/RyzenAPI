-- Lua provided by RyzenAPI
-- Game: addappid(1693340)

-- MAIN APPLICATION
addappid(1693340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693342,0,"39679bdc53deb15ee52cf79c5a1d5173f5d55c6338b1d264131bae84c1d5c82b")
