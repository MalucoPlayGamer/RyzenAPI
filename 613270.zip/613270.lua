-- Lua provided by RyzenAPI
-- Game: Dinosis Survival

-- MAIN APPLICATION
addappid(613270)

-- MAIN APP DEPOTS / PACKAGES
addappid(613271,0,"a444d9e3e69fb42d9760aaed57fe7ad890e39b42114573dd8ca67bdde53f9783")

