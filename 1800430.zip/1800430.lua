-- Lua provided by RyzenAPI
-- Game: Femdom Waifu VR

-- MAIN APPLICATION
addappid(1800430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800431, 1, "878c3b8d0dc864e5172bbde08cd85112f6847335e624cb71c35bd1553ca51e49")
