-- Lua provided by RyzenAPI
-- Game: Game: Meowtopia: Expedition

-- MAIN APPLICATION
addappid(1923820)
-- Game: addappid(1923820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923821, 1, "7bec43d043873d52707279e3ddc8245e6d93fa5308440e870b449104a655edee")
addappid(1978140, 0, "df96452cbdcf73e32047f98381a3629eba0474cf2c4b60da52e8e4b686a97fe1")
