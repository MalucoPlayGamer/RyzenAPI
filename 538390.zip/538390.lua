-- Lua provided by RyzenAPI
-- Game: AppID 538390

-- MAIN APPLICATION
addappid(538390)

-- MAIN APP DEPOTS / PACKAGES
addappid(538391, 1, "1776421f2ea2a33dc5a7258a6a1c80c6e6c74ecf993fc7a1e95fb603c6821ef1")

