-- Lua provided by RyzenAPI
-- Game: AppID 3645780

-- MAIN APPLICATION
addappid(3645780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645781, 1, "0c31936417749b59d05309e53fc5a16ae1ca1ac6e5e86270e6df2474fb59c98e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
