-- Lua provided by RyzenAPI
-- Game: addappid(3645780)

-- MAIN APPLICATION
addappid(3645780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645781, 1, "0c31936417749b59d05309e53fc5a16ae1ca1ac6e5e86270e6df2474fb59c98e")
