-- Lua provided by RyzenAPI
-- Game: Game: Ballistic Zen

-- MAIN APPLICATION
addappid(1966930)
-- Game: addappid(1966930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966931, 1, "e23e7e6e52695a9adbeeb0ec566b64914a514030c14f1407065b348d01122428")
