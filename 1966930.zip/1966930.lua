-- Lua provided by SkyAPI 
-- Game: Ballistic Zen
addappid(1966930)
addappid(1966931, 1, "e23e7e6e52695a9adbeeb0ec566b64914a514030c14f1407065b348d01122428")
