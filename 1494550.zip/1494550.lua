-- Lua provided by RyzenAPI
-- Game: Cars vs Zombies

-- MAIN APPLICATION
addappid(1494550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494551, 1, "1ba88b451d1be2b1820eb29f540001fe4d1f333bc928b0ddbec96b4b8ce86451")
