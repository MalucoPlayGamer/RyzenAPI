-- Lua provided by SkyAPI 
-- Game: Rise & Muse Demo
addappid(3198810)
addappid(3198811, 1, "f6f331c3e71a79668c0c712cdc39592ca4f025a257db0e7b47e700e684dc55e8")
