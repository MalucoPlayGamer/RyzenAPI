-- Lua provided by RyzenAPI
-- Game: Game: Rise & Muse Demo

-- MAIN APPLICATION
addappid(3198810)
-- Game: addappid(3198810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198811, 1, "f6f331c3e71a79668c0c712cdc39592ca4f025a257db0e7b47e700e684dc55e8")
