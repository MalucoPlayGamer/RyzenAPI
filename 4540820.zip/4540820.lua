-- 4540820's Lua and Manifest Created by Hubcap Manifest
-- Kin and Conquest
-- Created: August 03, 2026 at 07:24:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4540820) -- Kin and Conquest
-- MAIN APP DEPOTS
addappid(4540821, 1, "eaaad65590522e8c055755f43c02db9041e786eefc36c040fc0f0c0248ca71d2") -- Depot 4540821
setManifestid(4540821, "7869094744667121153", 597689672)