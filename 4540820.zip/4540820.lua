-- Lua provided by RyzenAPI
-- Game: Kin and Conquest

-- MAIN APPLICATION
addappid(4540820) -- Kin and Conquest

-- MAIN APP DEPOTS / PACKAGES
addappid(4540821, 1, "eaaad65590522e8c055755f43c02db9041e786eefc36c040fc0f0c0248ca71d2") -- Depot 4540821

