-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: FSDG - Djerba

-- MAIN APPLICATION
addappid(2969880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969880,0,"fdf6a9190383204878c45767352104e646ba6421da0ce7caf29123396099a5be")

