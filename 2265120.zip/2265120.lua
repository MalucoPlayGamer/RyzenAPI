-- Lua provided by RyzenAPI
-- Game: 无限投影2

-- MAIN APPLICATION
addappid(2265120)
-- Game: addappid(2265120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265121, 1, "7a34e3ab5a77350c7b8118cf814df59d3b2b69fb6f9cbf2efd5fb19f42babfac")
