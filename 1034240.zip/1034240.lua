-- Lua provided by RyzenAPI
-- Game: The Far Kingdoms: Awakening Solitaire

-- MAIN APPLICATION
addappid(1034240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034241, 1, "a0f5d8e6d39b02b784d88d899ca89edb7a65185a9c288d82680fabf721b78f1f")
addappid(1034242, 1, "32a4d8e9104cfa9009a3f028f27c870ee645a822d8715666af47887275d3649a")
addappid(1034243, 1, "c280b6d9485599d331ffc7df9739b28abd1cd43de0bd50de3a9b631b3ea2ab83")
