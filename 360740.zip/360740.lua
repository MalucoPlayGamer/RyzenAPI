-- Lua provided by SkyAPI 
-- Game: Downwell
addappid(360740)
addappid(360741, 1, "29a79c360b5b68001dfdd16c80de9b9d4b4289f77bb9c5fb72bc9b7d028bb86a")
