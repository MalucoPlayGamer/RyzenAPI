-- Lua provided by RyzenAPI
-- Game: Downwell

-- MAIN APPLICATION
addappid(360740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(360741, 1, "29a79c360b5b68001dfdd16c80de9b9d4b4289f77bb9c5fb72bc9b7d028bb86a")

