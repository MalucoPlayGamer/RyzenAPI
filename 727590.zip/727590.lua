-- Lua provided by RyzenAPI
-- Game: Game: AppID 727590

-- MAIN APPLICATION
addappid(727590)
-- Game: addappid(727590)

-- MAIN APP DEPOTS / PACKAGES
addappid(727591, 1, "0238689a780e2af4350e5b14cebd26e2573f47c2738e33e16fc2534beb886cf5")
addappid(830610, 0, "ca2de02eca1be18f39308b8c59f42a4272711014f6862b0ba2e643432f20cf7d")
