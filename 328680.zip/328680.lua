-- Lua provided by RyzenAPI
-- Game: 328680

-- MAIN APPLICATION
addappid(328680)
addappid(328681)
addappid(328684)
-- Game: addappid(328680)

-- MAIN APP DEPOTS / PACKAGES
addappid(328682,0,"00a6140f28ca74fe95e37ead0a416a2f339ebe3567bbce216577c9f63668d1eb")
addappid(328683,0,"16783cb7416bb19ec50c33e3663c8d15019510c46ee126e152c64649a5bb4b50")
