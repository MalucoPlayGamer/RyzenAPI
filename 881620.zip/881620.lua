-- Lua provided by SkyAPI 
-- Game: Plumber: the Pipe Rush
addappid(881620)
addappid(881621, 1, "75456497c08b56bf9871f57da448f3256ea2b684e70e733a6d67b3c09cca91ee")
