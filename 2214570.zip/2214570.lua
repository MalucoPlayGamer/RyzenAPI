-- Lua provided by RyzenAPI 
-- Game: Adventures of Red
addappid(2214570)
addappid(2214571, 1, "0fb5c9026f63faa43f6e61b32f5d32752e28acd75c7de8f5348bdddac7c63a16")
