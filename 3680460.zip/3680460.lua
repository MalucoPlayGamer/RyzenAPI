-- Lua provided by RyzenAPI
-- Game: Velocity Rift

-- MAIN APPLICATION
addappid(3680460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680461, 1, "3b0d0c251d236d736281c875af71e5fd0c25196a07b594aed5bc0edc664e240d")

