-- Lua provided by RyzenAPI
-- Game: 806140

-- MAIN APPLICATION
addappid(806140)
-- Game: addappid(806140)

-- MAIN APP DEPOTS / PACKAGES
addappid(806141, 1, "dc9b244d2d168136cff20d12ed91d56e966b091996267014bb97b31d9b1a4a24")
