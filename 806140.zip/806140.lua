-- Lua provided by RyzenAPI 
-- Game: AppID 806140
addappid(806140)
addappid(806141, 1, "dc9b244d2d168136cff20d12ed91d56e966b091996267014bb97b31d9b1a4a24")
