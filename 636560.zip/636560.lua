-- Lua provided by RyzenAPI
-- Game: Runewards: Strategy Card Game

-- MAIN APPLICATION
addappid(636560)
-- Game: addappid(636560)

-- MAIN APP DEPOTS / PACKAGES
addappid(636561, 1, "205ad8d3d8658838efa7666efab1c541a55bb0d24321ae88e1f95d1ad9d3c770")
