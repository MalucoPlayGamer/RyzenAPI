-- Lua provided by RyzenAPI
-- Game: The Price Of Flesh

-- MAIN APPLICATION
addappid(1940040)
-- Game: addappid(1940040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940041, 1, "c58d9000e4ac17e9e3a79b25df88c48eca022d1a02b7bb8bacf31d152a76b9f8")
