-- Lua provided by RyzenAPI
-- Game: Game: AppID 1400080

-- MAIN APPLICATION
addappid(1400080)
-- Game: addappid(1400080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400081, 1, "ca5a6d99f2aa73e235808e652e17e9a24454ba9a0935019410343bb3d96428f9")
