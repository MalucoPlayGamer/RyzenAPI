-- Lua provided by RyzenAPI
-- Game: Moss Soundtrack

-- MAIN APPLICATION
addappid(925970)

-- MAIN APP DEPOTS / PACKAGES
addappid(925970,0,"aed4861d7f7874d1496f03847c131ccef4cf8154022b37d14355e541fb68831e")

