-- Lua provided by RyzenAPI
-- Game: Murder Diaries: Ankara

-- MAIN APPLICATION
addappid(795960)

-- MAIN APP DEPOTS / PACKAGES
addappid(795961,0,"6f317701b8c3a3d9ce4ff26089d51d0e0be800d3016c1f6d18dfb4e7b19aa137")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
