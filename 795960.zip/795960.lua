-- Lua provided by RyzenAPI
-- Game: Murder Diaries: Ankara

-- MAIN APPLICATION
addappid(795960)

-- MAIN APP DEPOTS / PACKAGES
addappid(795961,0,"6f317701b8c3a3d9ce4ff26089d51d0e0be800d3016c1f6d18dfb4e7b19aa137")

