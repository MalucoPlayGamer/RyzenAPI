-- Lua provided by RyzenAPI
-- Game: Game: AppID 1059230

-- MAIN APPLICATION
addappid(1059230)
-- Game: addappid(1059230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059231, 1, "d7c2c05ed5898548ecc634660e3e8e321d7e270da7c51eff07d34df5ffae5e48")
