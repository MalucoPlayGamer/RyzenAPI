-- Lua provided by RyzenAPI
-- Game: Kill the Superweapon

-- MAIN APPLICATION
addappid(758070)

-- MAIN APP DEPOTS / PACKAGES
addappid(758071,0,"5a794e3be9ba551e09364dae7eaee1681066560ff15b178aaa25d176ecdc6816")

