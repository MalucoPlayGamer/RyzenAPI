-- Lua provided by RyzenAPI 
-- Game: Soulstice Soundtrack
addappid(2052060)
addappid(2052061, 1, "0072a5c1622d1e45b34fa483b941cacd37f1e99b08f54c627acff1e6b6e5cab0")
addappid(2052062, 1, "cd3b2bd40aba7b2f807e9cbefcf472570ac8bb5e49746c8c2332ebb816d70445")
