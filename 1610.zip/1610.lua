-- Lua provided by RyzenAPI
-- Game: Game: Space Empires IV Deluxe

-- MAIN APPLICATION
addappid(1610)
-- Game: addappid(1610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611, 1, "0a53834cfd5b448aa56ebaf921f1716622c83fba2e9ecf053343f18417bb1b5b")
