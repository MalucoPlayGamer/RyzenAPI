-- Lua provided by SkyAPI 
-- Game: Space Empires IV Deluxe
addappid(1610)
addappid(1611, 1, "0a53834cfd5b448aa56ebaf921f1716622c83fba2e9ecf053343f18417bb1b5b")
