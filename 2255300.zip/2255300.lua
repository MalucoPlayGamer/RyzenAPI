-- Lua provided by RyzenAPI
-- Game: The Starving Tournament

-- MAIN APPLICATION
addappid(2255300)
-- Game: addappid(2255300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255301, 1, "cb93b8b563b0fdfda6f3550cef7ec4b056ae28c30d2d1db1f154ddce97fddde5")
