-- Lua provided by RyzenAPI
-- Game: Again and Again

-- MAIN APPLICATION
addappid(2135580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135581, 1, "8a28fcd33be258e386e9c292d855c700023ebb7f430ce1490bbb13edf9ff156d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
