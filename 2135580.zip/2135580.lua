-- Lua provided by RyzenAPI
-- Game: Again and Again

-- MAIN APPLICATION
addappid(2135580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135581, 1, "8a28fcd33be258e386e9c292d855c700023ebb7f430ce1490bbb13edf9ff156d")
