-- Lua provided by RyzenAPI
-- Game: Kiki & Ana - The Child

-- MAIN APPLICATION
addappid(1506820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506821, 1, "3841e7403e1e4e06fb0c28b1a46e4cdcc829e0801726a788bf30e28ca2efe1cc")

