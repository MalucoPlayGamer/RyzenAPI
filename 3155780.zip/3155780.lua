-- Lua provided by RyzenAPI
-- Game: Game: AppID 3155780

-- MAIN APPLICATION
addappid(3155780)
-- Game: addappid(3155780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155781, 1, "181f2126fa34dc0499db9329680a5faaa563766418f2602abc9bcebc2de49e33")
