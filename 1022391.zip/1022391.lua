-- Lua provided by RyzenAPI
-- Game: DFF NT: Divine Blade, Kam'lanaut's 4th Weapon

-- MAIN APPLICATION
addappid(1022391)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022391,0,"070a37fd322338c16f694912ea51b9ccf0fb849e27621d4e0145d32b513d265f")

