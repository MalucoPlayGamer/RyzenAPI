-- Lua provided by RyzenAPI
-- Game: Game: Hashihime of the Old Book Town append　fullscreen

-- MAIN APPLICATION
addappid(2779910)
-- Game: addappid(2779910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779911, 1, "883a0c1aa93823313638c4e1616d489a5431e57d735363316ce009d7b7c0004a")
