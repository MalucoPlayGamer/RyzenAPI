-- Lua provided by RyzenAPI
-- Game: AppID 1421160

-- MAIN APPLICATION
addappid(1421160)
-- Game: addappid(1421160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421161, 1, "778e4cb2d7ba0db151aa055c78a4e09c6a6ca788b7a028787d78b454d23249a6")
