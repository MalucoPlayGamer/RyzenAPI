-- Lua provided by RyzenAPI
-- Game: Arthurian Legends

-- MAIN APPLICATION
addappid(658890)

-- MAIN APP DEPOTS / PACKAGES
addappid(658891, 1, "45b7a4ec6e3f5f1c29ef2df53c8a237bf82936c27be11fbbb6077df69afed97b")

