-- Lua provided by RyzenAPI
-- Game: 273830

-- MAIN APPLICATION
addappid(273830)
-- Game: addappid(273830)

-- MAIN APP DEPOTS / PACKAGES
addappid(273831, 1, "f9a4c15626e09a380d8a236da4aa9062c6c491c1a66e44360a367fc547bc61c3")
