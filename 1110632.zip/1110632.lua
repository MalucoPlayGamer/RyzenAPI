-- Lua provided by RyzenAPI
-- Game: 1110632

-- MAIN APPLICATION
addappid(1110632)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110632,0,"668b9e038964ed687db112aa490b8d11b8a9cb2483dcc2bd75ab26be55fc02cf")

