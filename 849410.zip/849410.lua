-- Lua provided by RyzenAPI
-- Game: Poop Slinger

-- MAIN APPLICATION
addappid(849410)

-- MAIN APP DEPOTS / PACKAGES
addappid(849411,0,"8e3e3822bdb6b1e7723abf3f885cad211507e074c1c7eb2833da443318f9d718")

