-- Lua provided by RyzenAPI
-- Game: DarkRanger

-- MAIN APPLICATION
addappid(3424920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424921, 1, "b9b1aaa5eee5c676d6d36acb64c60bbb9cd5f941f33e73edbf81b800feb3d896")
