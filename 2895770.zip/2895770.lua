-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2895770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895772,0,"cfad4a6e5fc9f429726b7c454b40a8c813fc8f2aebc4ec4169235bbfaa613f05")
addappid(2895773,0,"48364747815f3755a210013cad0c81ba52082543c540e4bdc1273b510b1a4894")

