-- Lua provided by SkyAPI 
-- Game: AppID 1880380
addappid(1880380)
addappid(1880381, 1, "ed4bdc67cec16960a6658c1f6f82bbdf18b109c3b3fa8afb0930078c74a4a037")
