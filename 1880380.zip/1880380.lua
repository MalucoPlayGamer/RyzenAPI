-- Lua provided by RyzenAPI
-- Game: AppID 1880380

-- MAIN APPLICATION
addappid(1880380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880381, 1, "ed4bdc67cec16960a6658c1f6f82bbdf18b109c3b3fa8afb0930078c74a4a037")
