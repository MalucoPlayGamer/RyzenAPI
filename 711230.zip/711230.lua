-- Lua provided by RyzenAPI
-- Game: Titus the Fox

-- MAIN APPLICATION
addappid(711230)

-- MAIN APP DEPOTS / PACKAGES
addappid(711232,0,"08e0aaa9209429715069dfc455d3c78d1115be022c0d74e9b5770a6a8200193a")

