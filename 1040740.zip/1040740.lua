-- Lua provided by RyzenAPI
-- Game: Legend of the Tetrarchs

-- MAIN APPLICATION
addappid(1040740)
-- Game: addappid(1040740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040741, 1, "d8af371cf571715a3ba15d0c4de6e18ade0fb4f773fda1e08d19ec1a14066947")
