-- Lua provided by RyzenAPI
-- Game: Game: Meat Saw

-- MAIN APPLICATION
addappid(1897530)
-- Game: addappid(1897530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897531, 1, "544bcf4fd12ef9abd43cb4f3970e452bf23d08cdc020b5c971a55cec395e7ae7")
