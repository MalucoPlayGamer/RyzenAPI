-- Lua provided by RyzenAPI
-- Game: NeoBalls2

-- MAIN APPLICATION
addappid(786560)

-- MAIN APP DEPOTS / PACKAGES
addappid(786561, 1, "b86f08a1328c140de60210ec2bbfda9971c370d7afda916c2e5f8823a6f4a48f")
