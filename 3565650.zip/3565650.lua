-- Lua provided by RyzenAPI
-- Game: Drone Simulator VR

-- MAIN APPLICATION
addappid(3565650)
addappid(4481890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3565651, 1, "66642bd3473db5c4925c57c7c1d5abd71fcf11ad8f82ccfbb36c604a0c6394cc")
