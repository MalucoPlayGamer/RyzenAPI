-- Lua provided by RyzenAPI
-- Game: AppID 2719330

-- MAIN APPLICATION
addappid(2719330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719331, 1, "b9bf2a57832c5bfe26029696e86c1aaaf3ff57cdd0e2631afbea184b8c90a9f5")

