-- Lua provided by RyzenAPI
-- Game: 342230

-- MAIN APPLICATION
addappid(342230)
-- Game: addappid(342230)

-- MAIN APP DEPOTS / PACKAGES
addappid(342231, 1, "089f77a13f24a7d1e8643a2e1c4c64310b6eff797aa3cf99060fa0c2d8ab391c")
