-- Lua provided by RyzenAPI
-- Game: Game: Iron Lung

-- MAIN APPLICATION
addappid(1846170)
-- Game: addappid(1846170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846171, 1, "a10d56f8cdc392161aa30e72c504926acf7d13a579c64650e956c72bcf58d9eb")
