-- Lua provided by RyzenAPI
-- Game: Diplomacy is Not an Option

-- MAIN APPLICATION
addappid(1272320)
addappid(5075270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272321, 1, "679b29b2f179a1a412570aecff5f975e3722b084a18733f963832690fcfd6005")
addappid(2941670, 0, "bec3b6bade013e0df9876a4149398270a2ef588a15164b75a5c21fb2197029d0")

