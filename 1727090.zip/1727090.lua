-- Lua provided by SkyAPI 
-- Game: RX Racing 2021 Pro
addappid(1727090)
addappid(1727091, 1, "2cb62517f15c913a6dc890525d83b302c36eb547a1c74127ed666739cc80e4a2")
