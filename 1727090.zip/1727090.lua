-- Lua provided by RyzenAPI
-- Game: RX Racing 2021 Pro

-- MAIN APPLICATION
addappid(1727090)
-- Game: addappid(1727090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727091, 1, "2cb62517f15c913a6dc890525d83b302c36eb547a1c74127ed666739cc80e4a2")
