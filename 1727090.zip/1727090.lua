-- Lua provided by RyzenAPI
-- Game: RX Racing 2021 Pro

-- MAIN APPLICATION
addappid(1727090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1727091, 1, "2cb62517f15c913a6dc890525d83b302c36eb547a1c74127ed666739cc80e4a2")

