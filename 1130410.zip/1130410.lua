-- Lua provided by RyzenAPI
-- Game: AppID 1130410

-- MAIN APPLICATION
addappid(1130410)
-- Game: addappid(1130410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130411, 1, "7c1a77043ec95e653942ed3a6afd8282d91c50642e1bb53b14385c3a55fa11b9")
addappid(1726520, 0, "756e4eaf83fb6e70bead8976950d19a123e1ed4b2019636c8faf5cbe01d8ec71")
