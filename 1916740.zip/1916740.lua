-- Lua provided by SkyAPI 
-- Game: Hohenheim: Skywards
addappid(1916740)
addappid(1916741, 1, "55b7953ba7c79536fcc8818476e1edf1b1d82a200b61ad2af2a4097579d712b9")
