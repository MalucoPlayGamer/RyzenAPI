-- Lua provided by RyzenAPI
-- Game: Hohenheim: Skywards

-- MAIN APPLICATION
addappid(1916740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916741, 1, "55b7953ba7c79536fcc8818476e1edf1b1d82a200b61ad2af2a4097579d712b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
