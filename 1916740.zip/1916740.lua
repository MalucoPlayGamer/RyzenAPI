-- Lua provided by RyzenAPI
-- Game: Hohenheim: Skywards

-- MAIN APPLICATION
addappid(1916740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916741, 1, "55b7953ba7c79536fcc8818476e1edf1b1d82a200b61ad2af2a4097579d712b9")
