-- Lua provided by RyzenAPI
-- Game: Crowalt: Traces of the Lost Colony

-- MAIN APPLICATION
addappid(1269500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269501, 1, "fae186e7a8c0f1262865223cd45b1403ed76125341d2d077a3bdc84658532620")
