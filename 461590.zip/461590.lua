-- Lua provided by RyzenAPI
-- Game: The Way Of Love: Sub Zero

-- MAIN APPLICATION
addappid(461590)

-- MAIN APP DEPOTS / PACKAGES
addappid(461591, 1, "352c9ddc91a061820d0ffb011d2b7588857667411513694cb1f1d0efe4a06cdf")

