-- Lua provided by RyzenAPI
-- Game: Demon Lord

-- MAIN APPLICATION
addappid(578920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(578921, 1, "ab09cbb2a2a3b221501a68802e1a920904e95e6505ccf2f379fca00f42d29510")
addappid(578923, 1, "18aa351a55d479920dc7cee6a5e472a959801a63355f794200ec60a2664ee71b")

