-- Lua provided by SkyAPI 
-- Game: The Ultimate Shot
addappid(1917740)
addappid(1917741, 1, "e9f80c23c34c90ab057992498bad171b62427bfa29d68dcba425f33525abf0b0")
