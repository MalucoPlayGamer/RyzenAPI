-- Lua provided by RyzenAPI
-- Game: The Ultimate Shot

-- MAIN APPLICATION
addappid(1917740)
-- Game: addappid(1917740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917741, 1, "e9f80c23c34c90ab057992498bad171b62427bfa29d68dcba425f33525abf0b0")
