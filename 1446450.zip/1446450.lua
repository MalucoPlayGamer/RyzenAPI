-- Lua provided by RyzenAPI
-- Game: Pretty Girls Klondike Solitaire

-- MAIN APPLICATION
addappid(1446450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446451, 1, "0cc5bc2330594fab61cb7d644f2f723e2f18f277153b25e3aa6b7d044e7ce1ac")

