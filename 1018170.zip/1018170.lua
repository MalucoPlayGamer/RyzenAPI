-- Lua provided by SkyAPI 
-- Game: 光之迷城 / Dawn of the Lost Castle
addappid(1018170)
addappid(1018171, 1, "183bf11ba5e375dac9c1bae335954a11b95cdc006ec78a2ffcb825494c30abd4")
addappid(1018172, 1, "5e76268239585f333180fd5d6d47bf315b2f44dac772bff60ac2642954096499")
addappid(1106120, 0, "b47e5dbe0c8b8ef73c68a5be0717312144f066c38e801dff5641550e1ef26be3")
