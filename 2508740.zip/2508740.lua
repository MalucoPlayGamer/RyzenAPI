-- Lua provided by RyzenAPI
-- Game: Defendron TD

-- MAIN APPLICATION
addappid(2508740)
-- Game: addappid(2508740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508741, 1, "8e33306c179811a27233828b955c4eba050b5eaf960377731d8ef298bdd735ba")
