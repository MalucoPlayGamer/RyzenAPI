-- Lua provided by RyzenAPI
-- Game: Arkanoid - Eternal Battle

-- MAIN APPLICATION
addappid(1717270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717271, 1, "a15284b2821504a1c92affe48ba9aad0e51bac6c82b0f2e236274b374eb6330f")

