-- Lua provided by RyzenAPI
-- Game: S.O.V: Passenger 23

-- MAIN APPLICATION
addappid(2369810)
-- Game: addappid(2369810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369812,0,"5fe0a1a2b24a764b8b141ea12372b1a04a3254d5fbfc0caa1bb4e4390bb7f457")
