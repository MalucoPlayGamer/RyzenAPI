-- Lua provided by RyzenAPI
-- Game: Fish Lake

-- MAIN APPLICATION
addappid(529610)

-- MAIN APP DEPOTS / PACKAGES
addappid(529611,0,"4ed7e0ebc493e634dc77760cdece8dab94e24e2745c784cfb3f64f0d6514526f")

