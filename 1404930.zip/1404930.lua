-- Lua provided by RyzenAPI 
-- Game: AppID 1404930
addappid(1404930)
addappid(1404931, 1, "3f9c8e2dfd2e9811d134ec9b88c6c72107994d4e16b97985f1c37a0468b8dce2")
