-- Lua provided by RyzenAPI
-- Game: addappid(1372280)

-- MAIN APPLICATION
addappid(1372280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372281, 1, "b4c236fa366c4f51e04430146cbfa0fd857d6bcb046c27c2989c4663dbbcbccc")
