-- Lua provided by RyzenAPI
-- Game: MELTY BLOOD: TYPE LUMINA

-- MAIN APPLICATION
addappid(1372280)
addappid(1645450)
addappid(1645452)
addappid(1645460)
addappid(1645470)
addappid(1645480)
addappid(1645490)
addappid(1645500)
addappid(1645510)
addappid(1645520)
addappid(1645530)
addappid(1645540)
addappid(1645550)
addappid(1649930)
addappid(1656770)
addappid(1810560)
addappid(1810561)
addappid(1810562)
addappid(1810563)
addappid(1918660)
addappid(1918661)
addappid(1918662)
addappid(1918663)
addappid(2073610)
addappid(2111960)
addappid(2111970)
addappid(2172450)
addappid(2172460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372281,0,"b4c236fa366c4f51e04430146cbfa0fd857d6bcb046c27c2989c4663dbbcbccc")
addappid(1590581,0,"436fa82f9d7f9bffc15db902c75faa6562cbf24ba1bbc9b1125841e2e7f00826")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
