-- Lua provided by RyzenAPI
-- Game: OtherSoul

-- MAIN APPLICATION
addappid(1806570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806571, 1, "184fae54abc97e1535997743a70e1baeeb77b978aac090290bbb0aa09ea42593")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
