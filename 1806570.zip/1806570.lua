-- Lua provided by RyzenAPI
-- Game: 1806570

-- MAIN APPLICATION
addappid(1806570)
-- Game: addappid(1806570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806571, 1, "184fae54abc97e1535997743a70e1baeeb77b978aac090290bbb0aa09ea42593")
