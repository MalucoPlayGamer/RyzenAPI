-- Lua provided by RyzenAPI 
-- Game: OtherSoul
addappid(1806570)
addappid(1806571, 1, "184fae54abc97e1535997743a70e1baeeb77b978aac090290bbb0aa09ea42593")
