-- Lua provided by RyzenAPI
-- Game: Berries Challenge

-- MAIN APPLICATION
addappid(1391990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391991, 1, "aca582ed7699836be9801d23ddd1641458c5bb207db22b806d9078e21de45dcf")

