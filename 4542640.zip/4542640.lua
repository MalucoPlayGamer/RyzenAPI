-- Lua provided by RyzenAPI
-- Game: 三国：谋定天下

-- MAIN APPLICATION
addappid(4542640)

