-- Lua provided by RyzenAPI
-- Game: Cooktopia

-- MAIN APPLICATION
addappid(2398580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398581, 1, "8421f7e9c9c33fb3d3490bb051dfec6f4a48da631a2dbb31b1484b25e3e25758")

