-- Lua provided by RyzenAPI
-- Game: The Frost Rebirth

-- MAIN APPLICATION
addappid(1499750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499751, 1, "9878b413b565a8e9c6d896588dd5eb85b8a1ccf7504441b613d4f21ef43153b8")
