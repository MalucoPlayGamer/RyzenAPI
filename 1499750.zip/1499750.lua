-- Lua provided by RyzenAPI
-- Game: The Frost Rebirth

-- MAIN APPLICATION
addappid(1499750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1499751, 1, "9878b413b565a8e9c6d896588dd5eb85b8a1ccf7504441b613d4f21ef43153b8")

