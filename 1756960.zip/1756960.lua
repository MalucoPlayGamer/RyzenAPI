-- Lua provided by RyzenAPI
-- Game: setManifestid(1769540,"1791791627014885619")

-- MAIN APPLICATION
addappid(1756960)
-- Game: addappid(1756960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769540,0,"165308bc9fac0e1cdb37ec493b246a9c32461f3d725d1dc532a99cfc56afb154")
