-- Lua provided by RyzenAPI
-- Game: Minami Lane Demo

-- MAIN APPLICATION
addappid(2769560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769561, 1, "b7bf88b19d3a6c84e39924d3d58ab0d3f4648500ed073bb8ab69cd05671636c7")

