-- Lua provided by RyzenAPI
-- Game: 2225530

-- MAIN APPLICATION
addappid(2225530)
-- Game: addappid(2225530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225531, 1, "5e5087456c02c573eacc1aa07105e8b225719f3cdcb1610d674d470b9ae64c91")
