-- Lua provided by RyzenAPI 
-- Game: HYPERVIOLENT
addappid(1409200)
addappid(1409201, 1, "3a189a0abf8cef559cf5982e717cc4673bd2d4bdf07f74402852b1471c67f557")
addappid(1409202, 1, "9f3749f732752bc4237c250290faf698a1212aba3cca515e14a883ad0b3e985e")
