-- Lua provided by RyzenAPI
-- Game: The Silence Outside

-- MAIN APPLICATION
addappid(744720)

-- MAIN APP DEPOTS / PACKAGES
addappid(744721,0,"500bcb45e4b37bb65fbe7745ad6b8c93f23f447547c3f365c8da424f9f4c4ea3")

