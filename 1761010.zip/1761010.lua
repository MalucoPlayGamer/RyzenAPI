-- Lua provided by RyzenAPI
-- Game: Game: The Immaculate Drag

-- MAIN APPLICATION
addappid(1761010)
-- Game: addappid(1761010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761011, 1, "d7ba2e1e38589a2a9b95e74414ef6b36de06082be2ea259fd9d6684bd7975032")
