-- Lua provided by RyzenAPI
-- Game: Highborn

-- MAIN APPLICATION
addappid(209850)

-- MAIN APP DEPOTS / PACKAGES
addappid(209851, 1, "67efa36586b7094914530dd5826a6d14b5c600872d366e839f5764842575f0a4")
addappid(209852, 1, "0b4288491093650f9e409147969a322d54f46b30acd46823212690caa4f49623")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(236660)
addappid(256180)
