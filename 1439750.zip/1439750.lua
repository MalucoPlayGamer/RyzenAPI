-- Lua provided by RyzenAPI
-- Game: 9-Bit Armies: A Bit Too Far

-- MAIN APPLICATION
addappid(1439750)
addappid(3680670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1439751, 1, "3202b82a1f4a13018f158ed9dcfb8a5aa33dbc14ec52343a3bd460d393b6bdbe")
