-- Lua provided by RyzenAPI
-- Game: Game: 9-Bit Armies: A Bit Too Far

-- MAIN APPLICATION
addappid(1439750)
-- Game: addappid(1439750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439751, 1, "3202b82a1f4a13018f158ed9dcfb8a5aa33dbc14ec52343a3bd460d393b6bdbe")
