-- Lua provided by RyzenAPI
-- Game: Herald of Havoc

-- MAIN APPLICATION
addappid(1963510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963511, 1, "f42fb75d63dab5f2acc7f70cae64aa8d2bb01017534de58265797d602a37d27e")

