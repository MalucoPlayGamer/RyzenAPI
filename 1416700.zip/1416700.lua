-- Lua provided by RyzenAPI 
-- Game: Grimm Shuffle
addappid(1416700)
addappid(1416701, 1, "7914de8997403f2376e9a0c6118657ccc6a567535dab324182a524845bbe27f5")
