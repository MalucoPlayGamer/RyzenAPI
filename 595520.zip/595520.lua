-- Lua provided by RyzenAPI
-- Game: Game: AppID 595520

-- MAIN APPLICATION
addappid(595520)
-- Game: addappid(595520)

-- MAIN APP DEPOTS / PACKAGES
addappid(595521, 1, "66230aaedfd86a80f2746b83463f976f2cf15df3c15c6199a40cd4143d4b9d1b")
