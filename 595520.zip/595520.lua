-- Lua provided by RyzenAPI
-- Game: AppID 595520

-- MAIN APPLICATION
addappid(595520)
addappid(781070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(595521, 1, "66230aaedfd86a80f2746b83463f976f2cf15df3c15c6199a40cd4143d4b9d1b")

