-- Lua provided by RyzenAPI
-- Game: Game: AppID 412490

-- MAIN APPLICATION
addappid(412490)
-- Game: addappid(412490)

-- MAIN APP DEPOTS / PACKAGES
addappid(412491, 1, "6c5ef7c0b75078f3ad38b41b945e6ce725a82acbd11d2f677a3be36c7b0f5fef")
addappid(412492, 1, "f0fcb8b8e98a310d633825f6647b6ae1619c8646a3ed072878c4c34ffae70ac6")
addappid(412493, 1, "709e061f51c7b0bc28b44d7c945186163bf892d3aba9d1a2070a5a660a33512f")
addappid(412494, 1, "59c2bdc856bc2bc7bee0513bd7d771f78d6ae4c07e4c465361db982809bbecb2")
addappid(443470, 0, "a2197b62f7fa0ffb1718e737f97c465046303d1e28530fb8dfee0d465a5db0c8")
