-- Lua provided by RyzenAPI
-- Game: OXXO

-- MAIN APPLICATION
addappid(1105110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105111, 1, "140de29eb360574630aad49ff941bbab8f5fbccc0f2eba59c05791b8630404c2")

