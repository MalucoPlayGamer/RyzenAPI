-- Lua provided by RyzenAPI 
-- Game: Airship Asunder
addappid(474730)
addappid(474731, 1, "d9aa71a55040d75aedbb25c680ca6dcc37e467f7a71a7190f141ef6bcdbdfbc6")
