-- Lua provided by RyzenAPI
-- Game: Salvus Aries Demo

-- MAIN APPLICATION
addappid(3071850)
-- Game: addappid(3071850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071854,0,"13195e144e2561be402dbb059770e256ee2e1966f22ae8475cf4363fcdf3ca83")
