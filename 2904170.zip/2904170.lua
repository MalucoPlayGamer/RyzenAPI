-- Lua provided by RyzenAPI
-- Game: Game: Where Dragon Spirits 龙魂在哪里

-- MAIN APPLICATION
addappid(2904170)
-- Game: addappid(2904170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904171, 1, "86b34c866521df86a58d1c4cbebedbfa36c56ef8a2007f27d030d124a8b31a3b")
