-- Lua provided by RyzenAPI
-- Game: 444690

-- MAIN APPLICATION
addappid(444690)
-- Game: addappid(444690)

-- MAIN APP DEPOTS / PACKAGES
addappid(444691, 1, "b72c2d865d07b585e7f3b2506cc931784185311ee44ba834fdc5608a33e7589b")
