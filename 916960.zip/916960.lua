-- Lua provided by RyzenAPI
-- Game: Skelittle: A Giant Party!!

-- MAIN APPLICATION
addappid(916960)

-- MAIN APP DEPOTS / PACKAGES
addappid(916961, 1, "011bd600daa6ab8f73c398e68c1b0983aa600cb67adb41a396858041386f2589")
