-- Lua provided by RyzenAPI
-- Game: Aion<sup>®</sup>: Assault on Balaurea™

-- MAIN APPLICATION
addappid(29640)

-- MAIN APP DEPOTS / PACKAGES
addappid(29641, 1, "50b9fdffd7e9826b473b42aeeb373dfb1cee08304da47f6ca958253b4f7e1dc4")
