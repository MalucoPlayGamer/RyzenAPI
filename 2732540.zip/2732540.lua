-- Lua provided by RyzenAPI
-- Game: Game: Journey of Realm: Dawn Dew Demo

-- MAIN APPLICATION
addappid(2732540)
-- Game: addappid(2732540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732541, 1, "a5b20b351210e158ed197631912c08526f4ea4452978465191fbf3e16cb108be")
