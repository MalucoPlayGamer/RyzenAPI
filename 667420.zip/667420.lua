-- Lua provided by RyzenAPI
-- Game: Redium

-- MAIN APPLICATION
addappid(667420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(667421, 1, "8a30f0286d5bb4305142a57c46a15bc9e42a385676e6ba477c493180bea3a423")
