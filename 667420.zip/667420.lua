-- Lua provided by SkyAPI 
-- Game: AppID 667420
addappid(667420)
addappid(667421, 1, "8a30f0286d5bb4305142a57c46a15bc9e42a385676e6ba477c493180bea3a423")
