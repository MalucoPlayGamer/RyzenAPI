-- Lua provided by RyzenAPI
-- Game: addappid(667420)

-- MAIN APPLICATION
addappid(667420)

-- MAIN APP DEPOTS / PACKAGES
addappid(667421, 1, "8a30f0286d5bb4305142a57c46a15bc9e42a385676e6ba477c493180bea3a423")
