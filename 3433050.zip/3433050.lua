-- Lua provided by RyzenAPI
-- Game: addappid(3433050)

-- MAIN APPLICATION
addappid(3433050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3433051, 1, "a0c1d8b283dd3bedd102aa3a032aaecd20e31f5e959d5d7cd713194fb3429eff")
