-- Lua provided by RyzenAPI
-- Game: 785860

-- MAIN APPLICATION
addappid(785860)
-- Game: addappid(785860)

-- MAIN APP DEPOTS / PACKAGES
addappid(785861, 1, "9b3510ac29085975382596877ad6c1a2fb8e0b2de4401c49328f7d4b89c2181b")
