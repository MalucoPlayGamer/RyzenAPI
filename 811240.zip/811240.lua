-- Lua provided by RyzenAPI
-- Game: AppID 811240

-- MAIN APPLICATION
addappid(811240)
-- Game: addappid(811240)

-- MAIN APP DEPOTS / PACKAGES
addappid(811241, 1, "dac34b3b814df5cbba9fe3bc01c4b7c2e4331216bbd3b71cd87bf078e14a8165")
