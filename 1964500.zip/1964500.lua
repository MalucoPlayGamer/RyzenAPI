-- Lua provided by RyzenAPI
-- Game: Game: The Battle of Sacred Heart

-- MAIN APPLICATION
addappid(1964500)
-- Game: addappid(1964500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964501, 1, "3d02c389ac844a37dc18f943f34aeac12c27b0d1ef6353727bd43953504579b8")
