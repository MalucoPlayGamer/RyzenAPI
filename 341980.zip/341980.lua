-- Lua provided by RyzenAPI
-- Game: AppID 341980

-- MAIN APPLICATION
addappid(341980)
addappid(441240)
addappid(455330)
-- Game: addappid(341980)

-- MAIN APP DEPOTS / PACKAGES
addappid(341981, 1, "0775b9b2fb77c072cce768165ef4ed7358b46558d883fccb0ea3c7a3736e5bbd")
