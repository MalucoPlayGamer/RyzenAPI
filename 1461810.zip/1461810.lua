-- Lua provided by RyzenAPI
-- Game: 1461810

-- MAIN APPLICATION
addappid(1461810)
addappid(2203060)
-- Game: addappid(1461810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461811, 1, "1145131320661eeaa125471f71c1c4a686b2b0a1240f87779d635c8fcf4ce614")
