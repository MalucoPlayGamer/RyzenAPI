-- Lua provided by RyzenAPI
-- Game: Forgotten Lore

-- MAIN APPLICATION
addappid(391240)

-- MAIN APP DEPOTS / PACKAGES
addappid(391241, 1, "081805ec0a503410ed60e091ec227c570cdde38c98484863d35503d94d891d4b")
addappid(391242, 1, "3f377d89acc38f6f9ecb43a6a32ac3dc7330bcd56ab472ca4b0ec087ecf79e9a")
addappid(391243, 1, "e09ce31c5f41057e6d6a9aac0cf273cf28acf65f51960aa838ceefb410f6ca8b")
addappid(391244, 1, "9f89267cb8c58611f02362b961e8318204f364fcf9dda94cba614135e1bddbcb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
