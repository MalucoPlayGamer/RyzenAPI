-- Lua provided by SkyAPI 
-- Game: Forgotten Lore
addappid(391240)
addappid(391241, 1, "081805ec0a503410ed60e091ec227c570cdde38c98484863d35503d94d891d4b")
addappid(391242, 1, "3f377d89acc38f6f9ecb43a6a32ac3dc7330bcd56ab472ca4b0ec087ecf79e9a")
addappid(391243, 1, "e09ce31c5f41057e6d6a9aac0cf273cf28acf65f51960aa838ceefb410f6ca8b")
addappid(391244, 1, "9f89267cb8c58611f02362b961e8318204f364fcf9dda94cba614135e1bddbcb")
