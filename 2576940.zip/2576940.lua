-- Lua provided by RyzenAPI
-- Game: addappid(2576940)

-- MAIN APPLICATION
addappid(2576940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576941, 1, "ddf4be0bd8eba938b7197eeff574f3cb37945df03b721421a5da8dcedf4eb21b")
addappid(2576942, 1, "2f865bd5b3281eafef01c8239609ad39adfb40ba0f162057d8e08d470a4af835")
