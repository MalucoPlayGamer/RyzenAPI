-- Lua provided by RyzenAPI
-- Game: トラウマーメイド

-- MAIN APPLICATION
addappid(1388510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388511, 1, "b678ab356ec90386825c57741d12acf81f71b3972f1dfeb7478b34ac757d4bf6")

