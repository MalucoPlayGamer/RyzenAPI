-- Lua provided by SkyAPI 
-- Game: Forest Of Fear
addappid(2918480)
addappid(2918481, 1, "40a551a37ba60bbd7c8608eb3cafc170fa6db47739722fecd565c444a56bf68a")
