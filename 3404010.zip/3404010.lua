-- Lua provided by RyzenAPI 
-- Game: Fear deeps
addappid(3404010)
addappid(3404011, 1, "bb4e093de34be8b5132e6ddbd6b5d51783a2cbd96f0f595fe7e8537ab553ee95")
