-- Lua provided by RyzenAPI
-- Game: Fear deeps

-- MAIN APPLICATION
addappid(3404010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3404011, 1, "bb4e093de34be8b5132e6ddbd6b5d51783a2cbd96f0f595fe7e8537ab553ee95")

