-- Lua provided by RyzenAPI
-- Game: Dorke and Ymp

-- MAIN APPLICATION
addappid(474810)
-- Game: addappid(474810)

-- MAIN APP DEPOTS / PACKAGES
addappid(474811, 1, "88bbefa976d8bdff50376479b9385d3b7788263d04fb9cbb802d2168f197f0f7")
