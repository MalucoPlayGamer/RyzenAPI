-- Lua provided by RyzenAPI
-- Game: Krush Kill 'N Destroy 2: Krossfire

-- MAIN APPLICATION
addappid(1292180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1292181, 1, "757b35b278b932363d98fb9a856f09fed3acaa813850c11319757dd5f3550832")

