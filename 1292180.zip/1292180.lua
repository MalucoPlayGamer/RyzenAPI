-- Lua provided by RyzenAPI
-- Game: Game: AppID 1292180

-- MAIN APPLICATION
addappid(1292180)
-- Game: addappid(1292180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292181, 1, "757b35b278b932363d98fb9a856f09fed3acaa813850c11319757dd5f3550832")
