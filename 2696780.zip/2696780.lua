-- Lua provided by RyzenAPI
-- Game: Space Accident VR

-- MAIN APPLICATION
addappid(2696780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696781, 1, "6dbb3c0aaee6b5a04a1d5ed56264ed0a2de8e340e9606c4fa68adeaca7851b4a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
