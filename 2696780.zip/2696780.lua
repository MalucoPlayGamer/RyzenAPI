-- Lua provided by RyzenAPI
-- Game: addappid(2696780)

-- MAIN APPLICATION
addappid(2696780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696781, 1, "6dbb3c0aaee6b5a04a1d5ed56264ed0a2de8e340e9606c4fa68adeaca7851b4a")
