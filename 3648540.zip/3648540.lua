-- Lua provided by RyzenAPI
-- Game: 3648540

-- MAIN APPLICATION
addappid(3648540)
-- Game: addappid(3648540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648541, 1, "6fc10c0d6733f15bd35258e8e6462fe4273f5029ea4bb3221af6cf899517b5d8")
