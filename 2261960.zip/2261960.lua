-- Lua provided by RyzenAPI
-- Game: 2261960

-- MAIN APPLICATION
addappid(2261960)
-- Game: addappid(2261960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261961, 1, "eb76f6fdbc3997d5ca689189117a82cf7235994fd405ada6ffbb8627ae40a505")
addappid(2261962, 1, "70b1e8ad707efb43a80cc8d7edb3b951ade65e9074aa537425e3caeede5bf02d")
