-- Lua provided by RyzenAPI
-- Game: AppID 1811210

-- MAIN APPLICATION
addappid(1811210)
-- Game: addappid(1811210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811211, 1, "f36b9409346d0f68f8ec0d93bc79c0df14018fa5662f227d86e57c0c83291c71")
