-- 4409630's Lua and Manifest Created by Hubcap Manifest
-- Ninja Cat Remewstered
-- Created: June 24, 2026 at 14:45:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4409630, 1, "ee9eb7bfd1b160212674fceb7fc3eba7a9723ac6c3213b1cdadfef905515513c") -- Ninja Cat Remewstered
-- MAIN APP DEPOTS
addappid(4409631, 1, "5c9dce41c7419ebba74ace0305af030121b9f24678baff8eac6d14cb9728b5b9") -- Depot 4409631
-- setManifestid(4409631, "6838873424194973452", 137784043)
addappid(4409632, 1, "21983fa9434e071b02c344f6209cd10a0b91f144150f7bef85f7c7fef84a10ed") -- Depot 4409632
-- setManifestid(4409632, "8089266071442751588", 137071121)