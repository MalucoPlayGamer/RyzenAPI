-- Lua provided by RyzenAPI
-- Game: Etheria: Restart

-- MAIN APPLICATION
addappid(2084970)

