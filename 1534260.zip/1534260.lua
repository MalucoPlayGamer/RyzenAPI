-- Lua provided by RyzenAPI 
-- Game: TitTok
addappid(1534260)
addappid(1534261, 1, "d37adead3a78cb820250d646b58b1242bd6e6d87738b6e330b6f7d7697c94441")
