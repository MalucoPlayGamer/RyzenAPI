-- Lua provided by RyzenAPI
-- Game: 1970980

-- MAIN APPLICATION
addappid(1970980)
-- Game: addappid(1970980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970981, 1, "56acf109e51166faab4cfff43e1fb4400ac338e61adbaaa0ebb2c06968b198ad")
