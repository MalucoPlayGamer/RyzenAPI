-- Lua provided by RyzenAPI
-- Game: Valkyrie of Phantasm

-- MAIN APPLICATION
addappid(2015620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015621, 1, "363db614b65bb18d5e63b3fd853c1d2f7e139d4824d77ffd2142a57489e25781")
