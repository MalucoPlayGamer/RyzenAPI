-- Lua provided by SkyAPI 
-- Game: 憧れのガチムチおじさんがボクだけのドスケベママになっちゃった❤ Demo
addappid(2842080)
addappid(2842081, 1, "fe4c81949ccf06f093d6974d4d7b7f66026055ebfebcd1c9825d6edcaeb641af")
