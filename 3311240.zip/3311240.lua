-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy store items tile set

-- MAIN APPLICATION
addappid(3311240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311240,0,"a74835d50a5d5562ac74dd056153a50cfa04c2ce02e791f55598dc3bf0c02add")

