-- Lua provided by RyzenAPI
-- Game: Game: Candle Daemon

-- MAIN APPLICATION
addappid(2686060)
-- Game: addappid(2686060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686061, 1, "75ea1017a69f0d99128ce3c1ec39af8d5115a62867cb9c2997212627a15b7689")
addappid(2686062, 1, "109931317c729356e77e10b7cae7e7588cd013fba58e123da89d3248b3518c73")
addappid(2834270, 0, "0b2f1eeddf2b4306a56650fade4b4db29d2919daef769e5205cc7af1cdaa4986")
