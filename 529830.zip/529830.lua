-- Lua provided by RyzenAPI
-- Game: Game Character Hub: Portfolio Edition

-- MAIN APPLICATION
addappid(529830)
addappid(1785740)
addappid(1997970)

-- MAIN APP DEPOTS / PACKAGES
addappid(529831, 1, "1eb502369018f6132b5fe54f5427acf144607f576f65865555c9718b2e1c8ffc")
addappid(531600, 0, "26c4705492455d94ee6cb0f52f0017e36718e463f186c1c402947ef9aae51e3d")
addappid(531601, 0, "304adfe57029b6538d22a5d5728a26c620852313485d5ea6cc406a50af6188d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
