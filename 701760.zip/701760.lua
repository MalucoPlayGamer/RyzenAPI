-- Lua provided by RyzenAPI
-- Game: L.S.S

-- MAIN APPLICATION
addappid(701760)

-- MAIN APP DEPOTS / PACKAGES
addappid(701761, 1, "6b9161d664274500704a86129fbe2761528f434b1c502e2177566b421db16de1")
addappid(800950, 0, "903d757122de4a7c5423d49d59ffab2d6709229ca5667c6ebdbb8951b03d1afa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
