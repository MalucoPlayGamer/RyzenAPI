-- Lua provided by RyzenAPI 
-- Game: L.S.S
addappid(701760)
addappid(701761, 1, "6b9161d664274500704a86129fbe2761528f434b1c502e2177566b421db16de1")
addappid(800950, 0, "903d757122de4a7c5423d49d59ffab2d6709229ca5667c6ebdbb8951b03d1afa")
