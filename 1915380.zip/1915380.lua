-- Lua provided by RyzenAPI
-- Game: Game: Garden Life: A Cozy Simulator

-- MAIN APPLICATION
addappid(1915380)
-- Game: addappid(1915380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915381, 1, "7a8eb0ea6b14c163b1032bc4fd042146b492d7e9f44067fe78e291058b28a9ac")
