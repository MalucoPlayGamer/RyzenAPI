-- Lua provided by RyzenAPI
-- Game: Garden Life: A Cozy Simulator

-- MAIN APPLICATION
addappid(1915380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915381, 1, "7a8eb0ea6b14c163b1032bc4fd042146b492d7e9f44067fe78e291058b28a9ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2691100)
addappid(2691110)
