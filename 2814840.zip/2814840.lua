-- Lua provided by SkyAPI 
-- Game: Project ZETA Playtest
addappid(2814840)
addappid(2814841, 1, "b7c716cdb8cee962b0e88d10c9a03ed935d9f2c730173fa26d35634964da7d98")
