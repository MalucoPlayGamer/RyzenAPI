-- Lua provided by RyzenAPI
-- Game: Project ZETA Playtest

-- MAIN APPLICATION
addappid(2814840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814841, 1, "b7c716cdb8cee962b0e88d10c9a03ed935d9f2c730173fa26d35634964da7d98")
