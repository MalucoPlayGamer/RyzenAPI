-- Lua provided by RyzenAPI
-- Game: Permute

-- MAIN APPLICATION
addappid(575630)
-- Game: addappid(575630)

-- MAIN APP DEPOTS / PACKAGES
addappid(575631, 1, "35f1f852dc841f498fd8f024b81b8abc7bca62b8a1bd2f7d81d2477960f8d4f6")
addappid(575632, 1, "3d02c27f70cba6316646811fef6897bf1a6f76699be10110ff8de6f81d029957")
addappid(575633, 1, "5a218cc6726b834b71145437f2dcac32dc3e967f0c67969ad790a923b312789f")
