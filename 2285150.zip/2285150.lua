-- Lua provided by RyzenAPI
-- Game: The Front

-- MAIN APPLICATION
addappid(2285150)
addappid(4115980)
addappid(4115990)
addappid(4116000)
addappid(4116010)
addappid(4116030)
addappid(4116040)
addappid(4116050)
addappid(4116060)
addappid(4116070)
addappid(4116080)
addappid(4261270)
addappid(4261280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2285151, 1, "1e7de60c1cc825964d43eb37232a95b15b7638fcd507b51001fa869d0a6fc67f")

