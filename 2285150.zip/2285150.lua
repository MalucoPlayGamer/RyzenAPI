-- Lua provided by RyzenAPI
-- Game: The Front

-- MAIN APPLICATION
addappid(2285150)
-- Game: addappid(2285150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285151, 1, "1e7de60c1cc825964d43eb37232a95b15b7638fcd507b51001fa869d0a6fc67f")
