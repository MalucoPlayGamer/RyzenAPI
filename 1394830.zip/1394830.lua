-- Lua provided by SkyAPI 
-- Game: LOCIS
addappid(1394830)
addappid(1394831, 1, "b40a19cbf5bc81ed21278a8ec16dd3ea3d413ade1f3efbac60034173965d7127")
