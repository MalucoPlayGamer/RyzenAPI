-- Lua provided by RyzenAPI
-- Game: LOCIS

-- MAIN APPLICATION
addappid(1394830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394831, 1, "b40a19cbf5bc81ed21278a8ec16dd3ea3d413ade1f3efbac60034173965d7127")
