-- Lua provided by RyzenAPI
-- Game: League of Light: Dark Omens Collector's Edition

-- MAIN APPLICATION
addappid(533070)

-- MAIN APP DEPOTS / PACKAGES
addappid(533071,0,"a206496d14496b81504f39112f212d5055f452f2ef304273054d03ca96cf13a5")

