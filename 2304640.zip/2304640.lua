-- Lua provided by RyzenAPI
-- Game: Hidden Through Time 2: Myths & Magic

-- MAIN APPLICATION
addappid(2304640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304642,0,"012b47cd87a2f9a418d418be10f34824563c057c1672c54761ebd0a54ba5f4a0")

