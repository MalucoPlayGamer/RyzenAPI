-- Lua provided by RyzenAPI
-- Game: AppID 2151580

-- MAIN APPLICATION
addappid(2151580)
-- Game: addappid(2151580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151581, 1, "16787ad2dcf625b58f77222db96e7019da13d96235d1d7576f6b152b3ed2201b")
