-- Lua provided by RyzenAPI
-- Game: AppID 1445510

-- MAIN APPLICATION
addappid(1445510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445511, 1, "6f5f46fa7bf63ed2def57cdf9059fb946f5ef2efea6fa843ba767993690ba28f")
