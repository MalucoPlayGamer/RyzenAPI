-- Lua provided by RyzenAPI
-- Game: addappid(470040)

-- MAIN APPLICATION
addappid(470040)

-- MAIN APP DEPOTS / PACKAGES
addappid(470041, 1, "43ba9a2d0332c55b91e925c9fc99ea36aa4e35072cd24313efae44254b77cc7e")
