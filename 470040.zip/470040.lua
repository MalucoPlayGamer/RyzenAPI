-- Lua provided by SkyAPI 
-- Game: AppID 470040
addappid(470040)
addappid(470041, 1, "43ba9a2d0332c55b91e925c9fc99ea36aa4e35072cd24313efae44254b77cc7e")
