-- Lua provided by RyzenAPI
-- Game: AppID 470040

-- MAIN APPLICATION
addappid(470040)

-- MAIN APP DEPOTS / PACKAGES
addappid(470041, 1, "43ba9a2d0332c55b91e925c9fc99ea36aa4e35072cd24313efae44254b77cc7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
