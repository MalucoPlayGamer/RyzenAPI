-- Lua provided by RyzenAPI
-- Game: Marooners

-- MAIN APPLICATION
addappid(423810)
addappid(674000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(423811, 1, "fabcf56208646a3f0f4b80e6c6f0d4da53ea431f81a0bb6471f2f7f6cdb82276")
addappid(423812, 1, "073fc6212672d2fd3aeb8e50fd19ba946a213a87974c3dfaf1f580a75ce15f8f")
addappid(423813, 1, "e3d57b88f167e2f7763476717189767c7e7823bcc6369c48fdc0338a2b3af604")
addappid(423814, 1, "394845a90d95c330fb4be6bbaa8ba4480612e20ff82357e93af4bcbf7a544e8a")

