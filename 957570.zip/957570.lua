-- Lua provided by RyzenAPI
-- Game: addappid(957570)

-- MAIN APPLICATION
addappid(957570)

-- MAIN APP DEPOTS / PACKAGES
addappid(957571, 1, "c15c19e63f17abc2a52c2ecfd9991443c9097010bfa38c5492582c53a1e9bd9f")
