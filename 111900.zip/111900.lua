-- Lua provided by RyzenAPI
-- Game: addappid(111900)

-- MAIN APPLICATION
addappid(111900)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(111901, 1, "cc345babbf4a55e6553fe2adbdb6c80a9bca39e3aad8c8e343662191c745c6f0")
