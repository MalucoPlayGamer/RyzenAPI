-- Lua provided by RyzenAPI
-- Game: Guardians of Middle-earth

-- MAIN APPLICATION
addappid(111900)
addappid(111910)
addappid(111911)
addappid(111912)
addappid(111913)
addappid(111914)
addappid(111915)
addappid(111916)

-- MAIN APP DEPOTS / PACKAGES
addappid(111901,0,"cc345babbf4a55e6553fe2adbdb6c80a9bca39e3aad8c8e343662191c745c6f0")

