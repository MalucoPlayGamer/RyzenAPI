-- Lua provided by RyzenAPI
-- Game: Guardians of Middle-earth

-- MAIN APPLICATION
addappid(111900)
addappid(111910)
addappid(111911)
addappid(111912)
addappid(111913)
addappid(111914)
addappid(111915)
addappid(111916)

-- MAIN APP DEPOTS / PACKAGES
addappid(111901,0,"cc345babbf4a55e6553fe2adbdb6c80a9bca39e3aad8c8e343662191c745c6f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
