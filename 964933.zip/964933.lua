-- Lua provided by RyzenAPI
-- Game: 964933

-- MAIN APPLICATION
addappid(964933)

-- MAIN APP DEPOTS / PACKAGES
addappid(964933,0,"b880a1329de2b8053ebaf9cfbfbd849abc6f8a16a916ffe1f65ce65825df610c")
