-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Lianshi (Police Officer Costume) / 練師 「警官風コスチューム」

-- MAIN APPLICATION
addappid(964933)

-- MAIN APP DEPOTS / PACKAGES
addappid(964933,0,"b880a1329de2b8053ebaf9cfbfbd849abc6f8a16a916ffe1f65ce65825df610c")
