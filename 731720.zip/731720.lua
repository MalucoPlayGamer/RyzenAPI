-- Lua provided by RyzenAPI
-- Game: DOOMED

-- MAIN APPLICATION
addappid(731720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(731721, 1, "0f4aa8a276e9be56bd686d065d0a126d5d8053ea9927d7cf82c41dee1e37c822")

