-- Lua provided by RyzenAPI 
-- Game: AppID 731720
addappid(731720)
addappid(731721, 1, "0f4aa8a276e9be56bd686d065d0a126d5d8053ea9927d7cf82c41dee1e37c822")
