-- Lua provided by RyzenAPI
-- Game: 2931630

-- MAIN APPLICATION
addappid(2931630)
-- Game: addappid(2931630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931631, 1, "f9fcf4ac4feaef5f1c6708ca14a3dc3ab7c31da9ac97d6d4aa25f7ff363e97e2")
