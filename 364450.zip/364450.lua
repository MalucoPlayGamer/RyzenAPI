-- Lua provided by RyzenAPI
-- Game: AppID 364450

-- MAIN APPLICATION
addappid(364450)

-- MAIN APP DEPOTS / PACKAGES
addappid(364451, 1, "1b40ab9f9c3abcc82c172f0dfacfc4427ef2fef85add96ff952fff1f03a1b7a1")
addappid(364452, 1, "22764534df3ede9651b2469c2017ce12587eb2ac95dbd1916fc2f2a8c315180a")
