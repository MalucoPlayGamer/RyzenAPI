-- Lua provided by RyzenAPI
-- Game: Game: Succubers! Dark Covenant

-- MAIN APPLICATION
addappid(3216170)
-- Game: addappid(3216170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216171, 1, "67985d2f878aab60b3aac1295cf754ba77977d57688d8f197857060f6517b8e3")
