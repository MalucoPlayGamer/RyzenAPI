-- Lua provided by RyzenAPI
-- Game: Blocks by Google

-- MAIN APPLICATION
addappid(533970)

-- MAIN APP DEPOTS / PACKAGES
addappid(533971, 1, "b4958e80522de8fd5fa425e1473ab228cbd1e4495b1442a48cbcca3af07141b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
