-- Lua provided by RyzenAPI
-- Game: 302530

-- MAIN APPLICATION
addappid(302530)
-- Game: addappid(302530)

-- MAIN APP DEPOTS / PACKAGES
addappid(302531, 1, "eba3641ef24d73406530ccc30d5fa95b7856acd5e3369ec4433ea86d8ad7f6e1")
