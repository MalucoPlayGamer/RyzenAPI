-- Lua provided by RyzenAPI
-- Game: VR Paradise

-- MAIN APPLICATION
addappid(896890)
addappid(1012270)
addappid(1112590)
addappid(1112591)
addappid(1266860)
addappid(1518230)
addappid(1561840)
addappid(1796140)
addappid(1921290)
addappid(2459770)

-- MAIN APP DEPOTS / PACKAGES
addappid(896891,0,"df8a32ffda7ff3ce6078fb9b634613899660cd336757b09da29a7eb111bdf171")
addappid(896892,0,"90fb110b8c1bb34df86ccce23fbc3baafa11aac655798c79e7fb59b0cd5f2a53")

