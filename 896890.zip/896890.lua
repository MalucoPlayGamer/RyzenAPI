-- Lua provided by RyzenAPI
-- Game: Game: AppID 896890

-- MAIN APPLICATION
addappid(896890)
-- Game: addappid(896890)

-- MAIN APP DEPOTS / PACKAGES
addappid(896891, 1, "df8a32ffda7ff3ce6078fb9b634613899660cd336757b09da29a7eb111bdf171")
addappid(896892, 1, "90fb110b8c1bb34df86ccce23fbc3baafa11aac655798c79e7fb59b0cd5f2a53")
