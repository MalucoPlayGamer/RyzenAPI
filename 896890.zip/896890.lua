-- Lua provided by RyzenAPI
-- Game: VR Paradise

-- MAIN APPLICATION
addappid(896890)
addappid(1012270)
addappid(1112590)
addappid(1112591)
addappid(1266860)
addappid(1518230)
addappid(1561840)
addappid(1796140)
addappid(1921290)
addappid(2459770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(896891,0,"df8a32ffda7ff3ce6078fb9b634613899660cd336757b09da29a7eb111bdf171")
addappid(896892,0,"90fb110b8c1bb34df86ccce23fbc3baafa11aac655798c79e7fb59b0cd5f2a53")

