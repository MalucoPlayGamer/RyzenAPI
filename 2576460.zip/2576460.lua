-- Lua provided by RyzenAPI
-- Game: Angelstruck

-- MAIN APPLICATION
addappid(2576460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576461, 1, "d6fde851f8919b4662afa057725a6a0798a73b2ee51fc8889e073c8f91ed27ad")
