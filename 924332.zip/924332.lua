-- Lua provided by RyzenAPI
-- Game: The Messenger EP by Keiji Yamagishi

-- MAIN APPLICATION
addappid(924332)

-- MAIN APP DEPOTS / PACKAGES
addappid(924332,0,"b32dcf8b76d2fec487079c0c32ebd175983c35d07453a14f6e59d038063cf4f0")
addappid(1228780,0,"6085861ec7e6a6c05a5bb3372e6d5e48862be5a13db42aeb5376ba646ccd0475")
