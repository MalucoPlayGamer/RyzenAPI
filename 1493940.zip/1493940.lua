-- Lua provided by RyzenAPI
-- Game: Airoheart

-- MAIN APPLICATION
addappid(1493940)
addappid(2109080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493941, 1, "98f571290c566a8daaefa8b71c77a8c03435cca71ac0a1dda5906d7f99d8189b")

