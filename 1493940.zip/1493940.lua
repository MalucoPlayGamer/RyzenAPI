-- Lua provided by RyzenAPI
-- Game: Airoheart

-- MAIN APPLICATION
addappid(1493940)
addappid(2109080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493941, 1, "98f571290c566a8daaefa8b71c77a8c03435cca71ac0a1dda5906d7f99d8189b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
