-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2021 Effects - VHS Intro Pack

-- MAIN APPLICATION
addappid(1441876)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441876,0,"7d3fd9033058b408355cc1b730ff5b55c892f34e43b27991280bd6bafbcad37e")

