-- Lua provided by RyzenAPI
-- Game: 445870

-- MAIN APPLICATION
addappid(445870)

-- MAIN APP DEPOTS / PACKAGES
addappid(445872,0,"dabdae505cd9e4e586b15377866befe3bac17e6e86716103afb756056ab421bd")

