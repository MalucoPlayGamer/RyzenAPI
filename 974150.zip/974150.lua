-- Lua provided by RyzenAPI
-- Game: WellTown

-- MAIN APPLICATION
addappid(974150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(974151, 1, "57497dced7a30ecde25a07679855b9127a785c663cb6a67f2144aa872b8983e1")
