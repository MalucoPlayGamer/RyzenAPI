-- Lua provided by RyzenAPI
-- Game: 974150

-- MAIN APPLICATION
addappid(974150)
-- Game: addappid(974150)

-- MAIN APP DEPOTS / PACKAGES
addappid(974151, 1, "57497dced7a30ecde25a07679855b9127a785c663cb6a67f2144aa872b8983e1")
