-- Lua provided by RyzenAPI
-- Game: The Last Shot

-- MAIN APPLICATION
addappid(1295000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295001, 1, "4e07e8554a428ceef9f6c3cc127a6563e0abe51be0aa89622b94032387c83eba")

