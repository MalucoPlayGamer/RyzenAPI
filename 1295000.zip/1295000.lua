-- Lua provided by RyzenAPI 
-- Game: The Last Shot
addappid(1295000)
addappid(1295001, 1, "4e07e8554a428ceef9f6c3cc127a6563e0abe51be0aa89622b94032387c83eba")
