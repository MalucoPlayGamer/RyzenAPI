-- Lua provided by RyzenAPI 
-- Game: Beacon Pines Original Soundtrack
addappid(2140860)
addappid(2140861, 1, "b60a5ab03aa05aceaf6cb21d918e3fc88259f8ce9e571addd7df4e59141fb1d8")
addappid(2140862, 1, "0c6e8c3ca0c117a2ee8af2ba0c81921bff81722eae239b5b5d89b1a4231f7729")
