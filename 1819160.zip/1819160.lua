-- Lua provided by RyzenAPI
-- Game: Meteor World Actor: Badge & Dagger

-- MAIN APPLICATION
addappid(1819160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819161, 1, "0119b254cb8416eb6f166043cd9aefb85711b41f959d0c273afb59d7e8a36e1d")

