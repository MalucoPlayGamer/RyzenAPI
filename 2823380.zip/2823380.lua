-- Lua provided by RyzenAPI
-- Game: Death Valley

-- MAIN APPLICATION
addappid(2823380)
-- Game: addappid(2823380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823381, 1, "c26215d8248afc3e19437820a84497f892b5e75c2eb65f32b438051a32812210")
