-- Lua provided by SkyAPI 
-- Game: Death Valley
addappid(2823380)
addappid(2823381, 1, "c26215d8248afc3e19437820a84497f892b5e75c2eb65f32b438051a32812210")
