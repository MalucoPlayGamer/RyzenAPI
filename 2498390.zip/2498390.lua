-- Lua provided by SkyAPI 
-- Game: 过阴 Soundtrack
addappid(2498390)
addappid(2498391, 1, "ede0f14d2d7d4b048d5358b30f5ba9dd62c4b2b0822b92f131f4f81a8a97ca57")
