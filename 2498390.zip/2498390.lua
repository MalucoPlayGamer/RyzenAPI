-- Lua provided by RyzenAPI
-- Game: 过阴 Soundtrack

-- MAIN APPLICATION
addappid(2498390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498391, 1, "ede0f14d2d7d4b048d5358b30f5ba9dd62c4b2b0822b92f131f4f81a8a97ca57")

