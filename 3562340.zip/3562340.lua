-- Lua provided by RyzenAPI
-- Game: Game: Castle Crumble

-- MAIN APPLICATION
addappid(3562340)
-- Game: addappid(3562340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3562341, 1, "034daa3c1ffb1007c688900dd216736bcdc27ef896380ebb6adbb5a18c2231eb")
