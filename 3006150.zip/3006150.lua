-- Lua provided by SkyAPI 
-- Game: Wet Slits
addappid(3006150)
addappid(3006151, 1, "926be047332178d275b307ee2a95395972f1cc828c36a90fd24d1a04999229a6")
