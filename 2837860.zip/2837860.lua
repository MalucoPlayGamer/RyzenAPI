-- Lua provided by RyzenAPI
-- Game: 2837860

-- MAIN APPLICATION
addappid(2837860)
-- Game: addappid(2837860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837861, 1, "d6b7b2eaff0604eaa793ab873093d4c39f0f0a1925db9b34e3bf68cb4865e18b")
