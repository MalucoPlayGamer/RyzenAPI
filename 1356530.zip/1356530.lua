-- Lua provided by RyzenAPI
-- Game: Mystery Hotel: Hidden Objects

-- MAIN APPLICATION
addappid(1356530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356531, 1, "c98aa70c3532f772bba153280467b43d5251ec3aa2e76684e67a73b33ee55173")
addappid(1356532, 1, "aaa1e057abfddbf3001905288ce704685415a42f6bec7387b32af838a70c77e3")

