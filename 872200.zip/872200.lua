-- Lua provided by RyzenAPI
-- Game: Rogue Company

-- MAIN APPLICATION
addappid(1643260) -- Rogue Company - Year 1 Pass
addappid(1643380) -- Rogue Company - Rogue Edition
addappid(1643390) -- Rogue Company - Ultimate Edition
addappid(1643420) -- DLC 1643420
addappid(1661710) -- DLC 1661710
addappid(1722720) -- DLC 1722720
addappid(1736640) -- Rogue Company - Radioactive Revenant Pack
addappid(1758970) -- DLC 1758970
addappid(1795660) -- DLC 1795660
addappid(1870600) -- DLC 1870600
addappid(1928060) -- DLC 1928060
addappid(1984330) -- Rogue Company - Juke Starter Pack
addappid(1984340) -- DLC 1984340
addappid(2061610) -- Rogue Company - Scarlet Contract Starter Pack
addappid(2148150) -- Rogue Company - Living Doll Pack
addappid(2299170) -- Rogue Company - Mainframe Overload Starter Pack
addappid(2484390) -- Rogue Company - ViVi Starter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(872200, 1, "949bdb74a48fce1429185b293f302a9d5899c971b8f492dd213bf8a505a0e010")
addappid(872201, 1, "aa860bcd49087443dde4ef9acb7579f6d112805f1205e9a327896979013fce9b") -- (windows)

