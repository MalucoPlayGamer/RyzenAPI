-- Lua provided by RyzenAPI
-- Game: addappid(872200)

-- MAIN APPLICATION
addappid(872200)

-- MAIN APP DEPOTS / PACKAGES
addappid(872201, 1, "aa860bcd49087443dde4ef9acb7579f6d112805f1205e9a327896979013fce9b")
