-- Lua provided by RyzenAPI
-- Game: AppID 1913480

-- MAIN APPLICATION
addappid(1913480)
-- Game: addappid(1913480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913481, 1, "e068b1b6da249f3f8c45d6018d0f7c259fda05076e8536d10be84051838f2d46")
