-- Lua provided by RyzenAPI
-- Game: AppID 1480870

-- MAIN APPLICATION
addappid(1480870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480871, 1, "79d1bb6dfdaf06bef3114b3a044162aadce2d84b4f170bea5a3f1b773fa22474")

