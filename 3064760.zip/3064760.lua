-- Lua provided by RyzenAPI
-- Game: Game: AppID 3064760

-- MAIN APPLICATION
addappid(3064760)
-- Game: addappid(3064760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064761, 1, "c62a66c60f7a8ee8962479420f1aecc65245507e34a62d1be76882e693c93fd8")
