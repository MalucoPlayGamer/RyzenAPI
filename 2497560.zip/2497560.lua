-- Lua provided by RyzenAPI
-- Game: Game: AppID 2497560

-- MAIN APPLICATION
addappid(2497560)
-- Game: addappid(2497560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497561, 1, "723680bda1a61d1a3197811c4ddb66563ed6801c280d99e6886b73323e3b9eb4")
