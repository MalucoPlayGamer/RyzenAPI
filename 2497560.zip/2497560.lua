-- Lua provided by RyzenAPI
-- Game: AppID 2497560

-- MAIN APPLICATION
addappid(2497560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497561, 1, "723680bda1a61d1a3197811c4ddb66563ed6801c280d99e6886b73323e3b9eb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
