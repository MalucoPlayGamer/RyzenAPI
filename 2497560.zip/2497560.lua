-- Lua provided by RyzenAPI 
-- Game: AppID 2497560
addappid(2497560)
addappid(2497561, 1, "723680bda1a61d1a3197811c4ddb66563ed6801c280d99e6886b73323e3b9eb4")
