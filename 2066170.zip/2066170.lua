-- Lua provided by RyzenAPI
-- Game: Furry Pet Dog Yiff Hentai

-- MAIN APPLICATION
addappid(2066170)
-- Game: addappid(2066170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066171, 1, "bceb90d64ffe57820a1c9af1bc0beee2ac9354ff6c5adc1f46072979320b92f5")
