-- Lua provided by RyzenAPI
-- Game: Game: AppID 1708190

-- MAIN APPLICATION
addappid(1708190)
-- Game: addappid(1708190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708191, 1, "487bc3534bb0f420faa075192b7b75144074d2ae02d49f5eace4384d22ac714d")
