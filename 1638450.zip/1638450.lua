-- Lua provided by RyzenAPI
-- Game: Shipwreck Escape

-- MAIN APPLICATION
addappid(1638450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638451, 1, "f9532aaea45b46c7f66509c8929f162401ce49655aa1cad3bb5ef185dd0cea69")
