-- Lua provided by RyzenAPI
-- Game: Breed Laboratory

-- MAIN APPLICATION
addappid(3207250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207251, 1, "d8511bc1f5a887331888de69ce00c761e53ab1b3faa6eef92b07719a4ca55ee1")

