-- Lua provided by RyzenAPI
-- Game: AppID 1254130

-- MAIN APPLICATION
addappid(1254130)
-- Game: addappid(1254130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254131, 1, "23dfb41b21335633dbd6d137d15993200de1853027ca77f639b102add2246fde")
