-- Lua provided by RyzenAPI
-- Game: AppID 1254130

-- MAIN APPLICATION
addappid(1254130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254131, 1, "23dfb41b21335633dbd6d137d15993200de1853027ca77f639b102add2246fde")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
