-- Lua provided by RyzenAPI
-- Game: Bella Wants Blood

-- MAIN APPLICATION
addappid(3007660)
-- Game: addappid(3007660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007661, 1, "8e414f8849b089d2327e7ab437efb8b2ba3eeefe7717f147f12c6648caf26fc0")
