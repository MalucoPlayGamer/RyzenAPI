-- Lua provided by SkyAPI 
-- Game: Bella Wants Blood
addappid(3007660)
addappid(3007661, 1, "8e414f8849b089d2327e7ab437efb8b2ba3eeefe7717f147f12c6648caf26fc0")
