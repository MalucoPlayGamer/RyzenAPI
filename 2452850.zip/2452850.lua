-- Lua provided by RyzenAPI
-- Game: Game: Land Above Sea Below Prologue

-- MAIN APPLICATION
addappid(2452850)
-- Game: addappid(2452850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452851, 1, "d42d7f7a594cb260635ebac397c1265fa6c3ade53936ca482b2361fff9a44a11")
