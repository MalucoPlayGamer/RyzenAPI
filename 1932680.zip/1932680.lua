-- Lua provided by RyzenAPI
-- Game: addappid(1932680)

-- MAIN APPLICATION
addappid(1932680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932681, 1, "bb3937bdfffb79a122423635bce33ad406213e0ec2f47e76bbdf586594b8c16c")
