-- Lua provided by RyzenAPI
-- Game: 1162380

-- MAIN APPLICATION
addappid(1162380)
-- Game: addappid(1162380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162380,0,"35ec85be012d69a14fb151b5e2a418fc1c6d06ee4a4aba6e39e43b3291dd42d7")
