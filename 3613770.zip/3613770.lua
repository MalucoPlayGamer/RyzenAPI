-- Lua provided by RyzenAPI 
-- Game: ShaderGlass
addappid(3613770)
addappid(3613771, 1, "3699055a93324d794ceb89d92fa43a50b4426507b8fb2620e8480d7d680224f5")
