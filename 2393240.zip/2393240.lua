-- Lua provided by RyzenAPI
-- Game: Darkest Dungeon® II: The Soundtrack

-- MAIN APPLICATION
addappid(2393240)
-- Game: addappid(2393240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393241, 1, "096f839bb412d7cb15f1006ef0c7f1dd23bcc58a2ae060d56d1afb57e15d61b1")
addappid(2393242, 1, "24fc7e085f8d2bdf7b116aa88604e728eb3e15d29c38008885a5aa311d7f978a")
