-- Lua provided by RyzenAPI
-- Game: 1952423

-- MAIN APPLICATION
addappid(1952423)
-- Game: addappid(1952423)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952423,0,"f79edd5fccb7690faec4e3fd24d1376815a98c4fad69efb2c7006f8d9fcf6a6f")
