-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Furnitures & Ornaments Pack Vol.1

-- MAIN APPLICATION
addappid(1952423)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952423,0,"f79edd5fccb7690faec4e3fd24d1376815a98c4fad69efb2c7006f8d9fcf6a6f")
