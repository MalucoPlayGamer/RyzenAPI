-- Lua provided by SkyAPI 
-- Game: AppID 1111030
addappid(1111030)
addappid(1111031, 1, "677fa378fc8592eb0e5da8cc265900e8751c03d6e161e9c34101a616d32759bd")
