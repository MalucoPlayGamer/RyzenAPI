-- Lua provided by RyzenAPI
-- Game: AppID 1111030

-- MAIN APPLICATION
addappid(1111030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111031, 1, "677fa378fc8592eb0e5da8cc265900e8751c03d6e161e9c34101a616d32759bd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1111170)
