-- Lua provided by RyzenAPI
-- Game: addappid(1528260)

-- MAIN APPLICATION
addappid(1528260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528261, 1, "4edc9856a928bd7c54393fc4d292eb3cbad55037322796892f9d8ce8c0ec6bdb")
