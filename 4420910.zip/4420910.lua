-- Generated with Luie @ https://lua.tools/
-- 4420910 - Clicksmith
-- Generated 2026-07-30 21:39:37 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4420910)

-- Main Depots
addappid(4420911, 1, "dbd0adf43c0887d5b5590dc0d4e68eab1a61a224522fbcfc52c322135d5e4f58")
setManifestid(4420911, "6774622844446679213", 157865389)
