-- Lua provided by RyzenAPI
-- Game: 3220780

-- MAIN APPLICATION
addappid(3220780)
-- Game: addappid(3220780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220781, 1, "d9b0537cae6dab09d5b5afc9d3e38c4723cb4c8864fc7802675b0e158d6d2bdb")
