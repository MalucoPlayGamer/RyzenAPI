-- Lua provided by RyzenAPI
-- Game: Red's Kingdom

-- MAIN APPLICATION
addappid(541240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(541241,0,"b910fd05582e6232c68ce56629256e0a81a2458cdb0e55c8d1fa5fed051de430")
addappid(541242,0,"f77daccbdb75b89117d3ff2b22d7d984c3b83e3728fceb29849bb76fe5ad0b8d")

