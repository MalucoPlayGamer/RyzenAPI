-- Lua provided by RyzenAPI
-- Game: Red's Kingdom

-- MAIN APPLICATION
addappid(541240)

-- MAIN APP DEPOTS / PACKAGES
addappid(541241,0,"b910fd05582e6232c68ce56629256e0a81a2458cdb0e55c8d1fa5fed051de430")
addappid(541242,0,"f77daccbdb75b89117d3ff2b22d7d984c3b83e3728fceb29849bb76fe5ad0b8d")

