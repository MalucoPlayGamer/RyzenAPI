-- Lua provided by RyzenAPI
-- Game: HOT WHEELS UNLEASHED™ 2 - Turbocharged

-- MAIN APPLICATION
addappid(2051120)
addappid(2370240)
addappid(2370241)
addappid(2370242)
addappid(2370243)
addappid(2370244)
addappid(2370245)
addappid(2370246)
addappid(2370247)
addappid(2370248)
addappid(2370249)
addappid(2370250)
addappid(2370251)
addappid(2370252)
addappid(2370253)
addappid(2370254)
addappid(2370255)
addappid(2370256)
addappid(2370257)
addappid(2475560)
addappid(2475570)
addappid(2492920)
addappid(2524800)
addappid(2524810)
addappid(2524820)
addappid(2524830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2051121, 1, "a3a1a2c67616cb63b8fe7830719af6ce7ff2ee70aeb15f6723f08c2a71d64d9e")

