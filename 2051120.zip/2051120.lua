-- Lua provided by RyzenAPI
-- Game: HOT WHEELS UNLEASHED™ 2 - Turbocharged

-- MAIN APPLICATION
addappid(2051120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051121, 1, "a3a1a2c67616cb63b8fe7830719af6ce7ff2ee70aeb15f6723f08c2a71d64d9e")
