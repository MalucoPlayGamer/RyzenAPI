-- Lua provided by RyzenAPI
-- Game: Cloning Clyde

-- MAIN APPLICATION
addappid(91800)

-- MAIN APP DEPOTS / PACKAGES
addappid(91801, 1, "d5500bcbf999b4c217a6ed29022e97fe8c1d1aee965410a61dd37b6529e1ea87")
