-- Lua provided by RyzenAPI
-- Game: Catto Pew Pew!

-- MAIN APPLICATION
addappid(3665520)
