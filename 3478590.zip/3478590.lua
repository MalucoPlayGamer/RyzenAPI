-- Lua provided by RyzenAPI
-- Game: Twelves:Shadow

-- MAIN APPLICATION
addappid(3478590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478591, 1, "7ded711ce22dd617ac754f83c09f4338bee15d234ce52afcb287048cf66ed20e")

