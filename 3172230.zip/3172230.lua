-- Lua provided by RyzenAPI
-- Game: AppID 3172230

-- MAIN APPLICATION
addappid(3172230)
-- Game: addappid(3172230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172231, 1, "9b10f7bd51dcaab20ddf76a4c2d3259714228fb09a2509d7fd0a66d303ca0ced")
