-- Lua provided by RyzenAPI
-- Game: addappid(1754701)

-- MAIN APPLICATION
addappid(1754701)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754701,0,"9e0bc7fa0aa1c6657e3cbf6f6aff4d065ceaab93b8c57d5165988610255d9046")
