-- Lua provided by RyzenAPI
-- Game: addappid(3163540)

-- MAIN APPLICATION
addappid(3163540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163541, 1, "d3a309aadfdec494bf819d04c6189719cf7fb7d38aed1ad19e972b881fe44c30")
