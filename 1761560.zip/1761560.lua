-- Lua provided by RyzenAPI
-- Game: 69 Lisa Love

-- MAIN APPLICATION
addappid(1761560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761561, 1, "7c413a16065e96937a201dae9ba1c7b91ec7e5118695f987fdf12e4919f79325")

