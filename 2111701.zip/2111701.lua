-- Lua provided by RyzenAPI
-- Game: 2111701

-- MAIN APPLICATION
addappid(2111701)
-- Game: addappid(2111701)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111701,0,"6c0db8c3b09acc1cd521e6022fe8d0c60887974209e8e181dd7cee71b5c4c180")
