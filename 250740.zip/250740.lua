-- Lua provided by RyzenAPI
-- Game: Ragnarok Online - Free to Play - European Version

-- MAIN APPLICATION
addappid(250740)
addappid(250741)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983,0,"77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b")
addappid(228984,0,"df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")

