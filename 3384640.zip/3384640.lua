-- Lua provided by RyzenAPI 
-- Game: Castle of Shikigami 3 Soundtrack
addappid(3384640)
addappid(3384641, 1, "d577001fe93731e8d5c75086edd21ae91fa86b2b9bcc459b98547bd73db88d05")
