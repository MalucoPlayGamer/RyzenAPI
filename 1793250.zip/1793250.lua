-- Lua provided by RyzenAPI 
-- Game: Take Me To The Dungeon!!
addappid(1793250)
addappid(1793251, 1, "6244e3fb605c1830a37e6e6429cad51f5fca42e3562976c02fd0d45f944dbef9")
