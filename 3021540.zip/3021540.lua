-- Lua provided by RyzenAPI
-- Game: Starborne: Frontiers

-- MAIN APPLICATION
addappid(3021540)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3113210)
addappid(3229920)
addappid(3229930)
addappid(3718830)
