-- Lua provided by RyzenAPI
-- Game: Starborne: Frontiers

-- MAIN APPLICATION
addappid(3021540)

