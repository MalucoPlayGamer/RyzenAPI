-- Lua provided by RyzenAPI
-- Game: AppID 3599510

-- MAIN APPLICATION
addappid(3599510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599511, 1, "707e0c30f60df7b463dd2a022c3ddc9e16e7ec39a187ee3e6f646e7f4f9af67f")

