-- Lua provided by RyzenAPI
-- Game: 1911360

-- MAIN APPLICATION
addappid(1911360)
-- Game: addappid(1911360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911361, 1, "fa900c4f33bd2e31721d22c1101734e31f3403394dc4e56cdf9e5c522befe5ab")
