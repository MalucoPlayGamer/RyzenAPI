-- Lua provided by SkyAPI 
-- Game: Trinity Fusion
addappid(1911360)
addappid(1911361, 1, "fa900c4f33bd2e31721d22c1101734e31f3403394dc4e56cdf9e5c522befe5ab")
