-- Lua provided by SkyAPI 
-- Game: Proxy Air Force
addappid(1303000)
addappid(1303001, 1, "890d33e06510f3b3761590c0d33467f3a1b9493ab1d229e667b37fb0d3aaad2a")
