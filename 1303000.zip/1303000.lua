-- Lua provided by RyzenAPI
-- Game: addappid(1303000)

-- MAIN APPLICATION
addappid(1303000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303001, 1, "890d33e06510f3b3761590c0d33467f3a1b9493ab1d229e667b37fb0d3aaad2a")
