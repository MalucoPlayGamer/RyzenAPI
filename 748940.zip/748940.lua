-- Lua provided by RyzenAPI
-- Game: AppID 748940

-- MAIN APPLICATION
addappid(748940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(748941, 1, "676dfecc3c3851d0639b066e7956e8c2161fae341f3afbe8d25bb4a48ba26daf")

