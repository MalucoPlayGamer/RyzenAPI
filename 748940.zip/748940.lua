-- Lua provided by SkyAPI 
-- Game: AppID 748940
addappid(748940)
addappid(748941, 1, "676dfecc3c3851d0639b066e7956e8c2161fae341f3afbe8d25bb4a48ba26daf")
