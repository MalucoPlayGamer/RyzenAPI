-- Lua provided by RyzenAPI
-- Game: The Advisor - Episode 1: Royal Pain

-- MAIN APPLICATION
addappid(1601680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1601681, 1, "7e2ed2df27f54489c275b4769ecb5b998952fd904b2f7f3181f629f8554e17c0")

