-- Lua provided by RyzenAPI
-- Game: Game: The Advisor - Episode 1: Royal Pain

-- MAIN APPLICATION
addappid(1601680)
-- Game: addappid(1601680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601681, 1, "7e2ed2df27f54489c275b4769ecb5b998952fd904b2f7f3181f629f8554e17c0")
