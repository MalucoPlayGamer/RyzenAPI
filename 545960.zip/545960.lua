-- Lua provided by RyzenAPI
-- Game: AppID 545960

-- MAIN APPLICATION
addappid(545960)

-- MAIN APP DEPOTS / PACKAGES
addappid(545961, 1, "8010a865fb2d86b8adc4a21623dafaeabcc136041bba6e80bd1ec9a3668b112e")
addappid(545963, 1, "a9ca27a9ad0fc36d51f38428c465d0e916a2c3d9c4db918fb8ecaa7532674769")

