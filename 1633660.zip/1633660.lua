-- Lua provided by SkyAPI 
-- Game: Girl Jigsaw 2
addappid(1633660)
addappid(1633661, 1, "ffa867aa9c7bdca8d0e9f1cb6e15936091a1f8d54fd2c510d12947b2fe05aebf")
addappid(1679580, 0, "96e0b307475cea300c90c31f744e03c76b6d6f4e9958235da0d1026a7bb26c53")
