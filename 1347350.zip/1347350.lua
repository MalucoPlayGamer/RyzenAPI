-- Lua provided by RyzenAPI
-- Game: Killing Sun / 抗日大刀队：日军总部

-- MAIN APPLICATION
addappid(1347350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347351, 1, "0f394dfb77fa9554799847ed902e1a0c2115a77cb51b01d29a0a010e0d3240af")

