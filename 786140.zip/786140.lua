-- Lua provided by RyzenAPI
-- Game: Plat4mer

-- MAIN APPLICATION
addappid(786140)

-- MAIN APP DEPOTS / PACKAGES
addappid(786141, 1, "e8907c6f5544dbe14a4a818e8429e30e9fbaf50c45510b7039a651ad1b47207e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
