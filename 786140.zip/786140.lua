-- Lua provided by RyzenAPI
-- Game: addappid(786140)

-- MAIN APPLICATION
addappid(786140)

-- MAIN APP DEPOTS / PACKAGES
addappid(786141, 1, "e8907c6f5544dbe14a4a818e8429e30e9fbaf50c45510b7039a651ad1b47207e")
