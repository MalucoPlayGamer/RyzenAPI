-- Lua provided by RyzenAPI
-- Game: Eon Fleet

-- MAIN APPLICATION
addappid(838980)

-- MAIN APP DEPOTS / PACKAGES
addappid(838981, 1, "0b4db7d240637d1af0d9a79af3e3171f51f3b6b029267f1a43cdaf35df50f741")
