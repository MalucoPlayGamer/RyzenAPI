-- Lua provided by RyzenAPI
-- Game: MISTOVER Demo

-- MAIN APPLICATION
addappid(1140010)
-- Game: addappid(1140010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140011, 1, "a196ecc35c239894aaa831acfc492cb0ee4ccc078ffcf15844a23e19d4f47d1c")
