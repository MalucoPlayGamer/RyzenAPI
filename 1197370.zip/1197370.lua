-- Lua provided by RyzenAPI
-- Game: addappid(1197370)

-- MAIN APPLICATION
addappid(1197370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197371, 1, "bd64d34239cc262d6ac7b0a8cb521198cdcfda827bdeea2f452e51f42d037d9f")
