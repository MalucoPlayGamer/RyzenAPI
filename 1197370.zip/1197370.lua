-- Lua provided by SkyAPI 
-- Game: Suite 776
addappid(1197370)
addappid(1197371, 1, "bd64d34239cc262d6ac7b0a8cb521198cdcfda827bdeea2f452e51f42d037d9f")
