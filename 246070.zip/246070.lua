-- Lua provided by RyzenAPI
-- Game: AppID 246070

-- MAIN APPLICATION
addappid(246070)

-- MAIN APP DEPOTS / PACKAGES
addappid(246071, 1, "43352e33659d5e22e696c9674563e6c2195b4c9e3be40a90b567fc3d25e05f44")
addappid(246072, 1, "595c76261ee1e26a3f9175b1b8fa98e19a4e11fc86e360f0aeb1824e08c54afc")
addappid(246073, 1, "77a9c57d84f18770b1823449c241ba2fa6dd49166120d306bb091a96277ab491")
addappid(296320, 0, "fe119b22e9da30d4f86a6da9d8aeb7f3d1f6595b432df52847afe5af1355154e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
