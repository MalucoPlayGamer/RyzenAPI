-- Lua provided by RyzenAPI
-- Game: AppID 654980

-- MAIN APPLICATION
addappid(654980)
-- Game: addappid(654980)

-- MAIN APP DEPOTS / PACKAGES
addappid(654981, 1, "9d9966bd6384fbea5c91e84686668c0279eacb8dbe0f818587bca5bf24c61dd2")
