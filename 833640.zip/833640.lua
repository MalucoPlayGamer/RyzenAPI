-- Lua provided by RyzenAPI
-- Game: addappid(833640)

-- MAIN APPLICATION
addappid(833640)

-- MAIN APP DEPOTS / PACKAGES
addappid(833641, 1, "21e81db6e21201bfc6e82e1bed227f54506c193d2ec33a63e6250f6496e7d34f")
