-- Lua provided by RyzenAPI 
-- Game: AppID 833640
addappid(833640)
addappid(833641, 1, "21e81db6e21201bfc6e82e1bed227f54506c193d2ec33a63e6250f6496e7d34f")
