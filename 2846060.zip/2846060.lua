-- Lua provided by RyzenAPI
-- Game: Subterror

-- MAIN APPLICATION
addappid(2846060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846061, 1, "b1d80f1d8515cb63bcd37272a489b6177c858c718d7b5a1d2e5d55d6a8fcdcdc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
