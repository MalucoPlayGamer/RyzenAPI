-- Lua provided by RyzenAPI
-- Game: Game: Subterror

-- MAIN APPLICATION
addappid(2846060)
-- Game: addappid(2846060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846061, 1, "b1d80f1d8515cb63bcd37272a489b6177c858c718d7b5a1d2e5d55d6a8fcdcdc")
