-- Lua provided by RyzenAPI
-- Game: 807140

-- MAIN APPLICATION
addappid(807140)
-- Game: addappid(807140)

-- MAIN APP DEPOTS / PACKAGES
addappid(807141, 1, "47d4117f67e3e35f4a896599e1a559e573ecac6120bc6989c9b015ecd7541480")
