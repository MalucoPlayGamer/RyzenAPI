-- Lua provided by RyzenAPI 
-- Game: AppID 945280
addappid(945280)
addappid(945281, 1, "3d73c79cfd195940b3a873b0c65b8f682f565023b6043975998c5d081c42a7e5")
