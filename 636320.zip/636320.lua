-- Lua provided by RyzenAPI
-- Game: Depth of Extinction

-- MAIN APPLICATION
addappid(636320)

-- MAIN APP DEPOTS / PACKAGES
addappid(636321, 1, "8da5250cf2850b3f9a911ad7ce9c5cb9973fcc8da4d217dad1fa828212b8b879")
