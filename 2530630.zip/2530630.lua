-- Lua provided by RyzenAPI 
-- Game: Men of War II - Official Soundtrack
addappid(2530630)
addappid(2530631, 1, "8c84199880c09b26e8e34e34fc81f6b20a5a09d622615e7a2fa8eba2c18546b3")
addappid(2530632, 1, "593297ebd1e9a6b10e92395d499f46a7e2350b745ddf2e0d896ab226dee6db59")
