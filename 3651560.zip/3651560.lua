-- Lua provided by RyzenAPI
-- Game: AppID 3651560

-- MAIN APPLICATION
addappid(3651560)
-- Game: addappid(3651560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651561, 1, "0730c105d0684c892e9db9ad1c55ebd8b88c4bdae74a2972f0770e242e607ebd")
