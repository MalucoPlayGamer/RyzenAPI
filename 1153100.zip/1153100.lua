-- Lua provided by RyzenAPI
-- Game: Pixels can fight

-- MAIN APPLICATION
addappid(1153100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1153103,0,"b45aa14e15a360089bbf8930eaaa0160371cbe668cfcbcbb89528411105f7c39")

