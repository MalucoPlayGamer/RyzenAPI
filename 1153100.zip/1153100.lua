-- Lua provided by RyzenAPI
-- Game: addappid(1153100)

-- MAIN APPLICATION
addappid(1153100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153103,0,"b45aa14e15a360089bbf8930eaaa0160371cbe668cfcbcbb89528411105f7c39")
