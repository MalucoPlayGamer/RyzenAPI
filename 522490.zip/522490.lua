-- Lua provided by RyzenAPI 
-- Game: Carrie's Order Up!
addappid(522490)
addappid(522491, 1, "302adf0be4ae580a1147b9a9d394923650b0ea7a200cfd2d65a8eadf9d9b5d89")
