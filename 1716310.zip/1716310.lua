-- Lua provided by RyzenAPI
-- Game: Game: AWAKEN - Astral Blade

-- MAIN APPLICATION
addappid(1716310)
-- Game: addappid(1716310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716311, 1, "f121a134e311bea06f43ba40953f267a37a02c47a4dc5345197dbf5774142108")
addappid(3269010, 0, "db45d4a61d14041bc6a3cde8612ac241651cc28a498a3559de5ac0a2dab31f9a")
