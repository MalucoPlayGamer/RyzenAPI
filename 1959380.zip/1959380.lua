-- Lua provided by RyzenAPI
-- Game: addappid(1959380)

-- MAIN APPLICATION
addappid(1959380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959381, 1, "f97cebcbdd770fbe2dc8188dcfcd0aea2ac20fad1c46c4b871385c93446cecc4")
