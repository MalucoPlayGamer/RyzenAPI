-- Lua provided by RyzenAPI
-- Game: Truck Simulator in City

-- MAIN APPLICATION
addappid(2085550)
-- Game: addappid(2085550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085551, 1, "6862255005ff35cf0d06a152a56403f5c5f5fe8b3ec6b61b9ef3775633315cc4")
