-- Lua provided by RyzenAPI
-- Game: Idle Stellar

-- MAIN APPLICATION
addappid(2530570) -- Idle Stellar

-- MAIN APP DEPOTS / PACKAGES
addappid(2530571, 1, "1060f492d29e41482808aa56ef32d4388aac9f11c23d43930c55ec0de8100e17") -- Depot 2530571

