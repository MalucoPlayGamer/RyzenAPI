-- Lua provided by SkyAPI 
-- Game: Madhouse Madness Demo
addappid(2631770)
addappid(2631771, 1, "e9e862e37573b6303ee9ced33cb0e118d3094e2a8082387f7e01c5e928e2123c")
