-- Lua provided by RyzenAPI
-- Game: Hungry Wolf

-- MAIN APPLICATION
addappid(1788790)
-- Game: addappid(1788790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788791, 1, "c9e541af803546839b7bd10561fa97b780891fe27f1a48b6236e669e7863c02c")
