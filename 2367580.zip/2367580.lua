-- Lua provided by SkyAPI 
-- Game: Bingo Beavers - Design &  Board game
addappid(2367580)
addappid(2367581, 1, "f0a46e03062b5652e29aae858293791bda11ab3c78e1488659072c6da13c5348")
addappid(2367582, 1, "1347096952ff70ef24a220ade78fc471f20bde25cf35ecd0369c3c7b5003b6f6")
