-- Lua provided by RyzenAPI
-- Game: Mystery Stories: Mountains of Madness

-- MAIN APPLICATION
addappid(2701670)
-- Game: addappid(2701670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701671, 1, "33096bb74eb517be882eb7de2b995a0d7e531d0519cbfbb1b76090d4af36530d")
