-- Lua provided by RyzenAPI
-- Game: AvaKit

-- MAIN APPLICATION
addappid(2363370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363371, 1, "8463818496686081f808a4e8e3c9b50d5465cd31956a05919b863d9028fb4b8c")
addappid(2363372, 1, "76ff9f8510119f1ee9711459f715d46f7a759cbcf74c53952aa2d65513065e0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
