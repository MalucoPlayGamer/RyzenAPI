-- Lua provided by RyzenAPI
-- Game: Commandos 2 - HD Remaster

-- MAIN APPLICATION
addappid(1100410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100411, 1, "3223e27c4e72fbc7ae2a9b6a55899d94d4ce5c542282812b6df992fab1c7d0bf")
addappid(1100412, 1, "00a3843b0037e9b3ab380df1ba26c22c4c395769448ec38ea240d56ad3c596d9")
addappid(1100413, 1, "870d053f05428d92d58d0db3bbb448af2c2e9e41728f86cdf0791932dbe1c803")

