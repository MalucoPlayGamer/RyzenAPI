-- Lua provided by RyzenAPI
-- Game: Belle Automata Demo

-- MAIN APPLICATION
addappid(1921420)
-- Game: addappid(1921420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921421, 1, "1b3ceb953f7eb9f83a3f74d35261351849325ade0844f8e553049136ea93e9e4")
