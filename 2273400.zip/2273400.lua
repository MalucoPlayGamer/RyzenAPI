-- Lua provided by RyzenAPI
-- Game: 三国群英战略版

-- MAIN APPLICATION
addappid(2273400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273401, 1, "0a53195101ed72bc0d63ec93c1194aef83f90e9d58fdf72cc1bf72bda7fff964")

