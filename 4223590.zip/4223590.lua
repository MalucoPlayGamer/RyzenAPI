-- Lua provided by RyzenAPI
-- Game: Succubus Survivors

-- MAIN APPLICATION
addappid(4223590)

-- MAIN APP DEPOTS / PACKAGES
addappid(4223594,0,"cf0f50306f48daa0261ae55fed6e106ef07d899b7255ed534954342192ab357e")

