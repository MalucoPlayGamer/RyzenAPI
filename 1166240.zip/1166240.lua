-- Lua provided by RyzenAPI
-- Game: AppID 1166240

-- MAIN APPLICATION
addappid(1166240)
-- Game: addappid(1166240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166241, 1, "d26868fea30e543a4b0adc815ef8640a2f77ea258feb678546f6c7dd7148386c")
addappid(1166243, 1, "58f045434e6ac78d6c0d2eec3b1a51afb81224eeac5bf87772831cce67ca87fe")
