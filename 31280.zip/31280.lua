-- Lua provided by RyzenAPI
-- Game: Poker Night at the Inventory (2010 Original Version)

-- MAIN APPLICATION
addappid(31280)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(31281, 1, "b414bf09cabfe31911cdf64204a5568f6f92c0609198169b746b759a547f583b")
addappid(31282, 1, "14c523aebffa358469d9a64519061da5b329ce1621e00ce7c63f1404e85dd6d6")
