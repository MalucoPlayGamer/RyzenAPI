-- Lua provided by RyzenAPI
-- Game: Trepang2 - Soundtrack

-- MAIN APPLICATION
addappid(1842620)
-- Game: addappid(1842620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842621, 1, "e381094a9a17f36b1ce9e1040f5bb5ec19b56dc6a59b75473d932693480fbf31")
