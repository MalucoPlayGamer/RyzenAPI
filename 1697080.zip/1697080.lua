-- Lua provided by RyzenAPI
-- Game: Pill Puzzle: One Move

-- MAIN APPLICATION
addappid(1697080)
-- Game: addappid(1697080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697081, 1, "9913d71ad0c0502ccc1b005909344232ebf655e57bf487f42dab3ec4bf4ab3aa")
