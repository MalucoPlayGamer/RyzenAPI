-- Lua provided by RyzenAPI
-- Game: Zooma VR

-- MAIN APPLICATION
addappid(1214410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214411, 1, "247d00ff0aa5c9677fbcb9c69a7ee31b86f61d8ba39d57c0537f76f426ac0dfd")
