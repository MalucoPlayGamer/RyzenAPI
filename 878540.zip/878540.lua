-- Lua provided by RyzenAPI
-- Game: Game: Coach Bus Simulator Parking

-- MAIN APPLICATION
addappid(878540)
-- Game: addappid(878540)

-- MAIN APP DEPOTS / PACKAGES
addappid(878541, 1, "ac10b1dac138813555184c58f778df87406fbfc40da14bc239b8773012ffdb64")
