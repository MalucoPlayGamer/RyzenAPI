-- Lua provided by RyzenAPI
-- Game: Rytmik Studio

-- MAIN APPLICATION
addappid(657280)
addappid(699060)
addappid(741540)
addappid(928580)
addappid(1552100)

-- MAIN APP DEPOTS / PACKAGES
addappid(657281, 1, "8199202f8d7015b4d8402d7eb9ff0207e1eaaa2f52439234d64f80f93232470a")

