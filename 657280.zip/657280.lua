-- Lua provided by RyzenAPI
-- Game: 657280

-- MAIN APPLICATION
addappid(657280)
-- Game: addappid(657280)

-- MAIN APP DEPOTS / PACKAGES
addappid(657281, 1, "8199202f8d7015b4d8402d7eb9ff0207e1eaaa2f52439234d64f80f93232470a")
