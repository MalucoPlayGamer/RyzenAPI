-- Lua provided by RyzenAPI
-- Game: Game: KeeperRL

-- MAIN APPLICATION
addappid(329970)
addappid(635540)
-- Game: addappid(329970)

-- MAIN APP DEPOTS / PACKAGES
addappid(329971, 1, "20a07b370c8e3b6db89220eada5f4dc106f49dc2500f576a6a641c76bdd3308a")
addappid(329972, 1, "2a0a228aeb5c3ba2a7ef779493928ffc3b217e5486508a042d1207e109d12a09")
addappid(329973, 1, "54e12481f7864e90908d5bbbd24937ff6cbd1a97d24d5438efce44bb2935ff1f")
addappid(329974, 1, "8dc90e25fbfd5d08cfd495716fb3b11d62550a407464aec0f399891300c7d089")
addappid(329975, 1, "8a4f8b40f1019cf66aeafad700bf940fe8ccf3172261d84fb65d4fe7bf98171f")
addappid(329976, 1, "5b4b72bce17c0fd6070348c8ac783a85ffc75671d1d5467d4fe19bae6906d373")
