-- Lua provided by RyzenAPI
-- Game: addappid(1161670)

-- MAIN APPLICATION
addappid(1161670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161671, 1, "55de15f8c78a729fbb04525fd6bcb464caa6f7b8d562c264190f27bf827b9dc1")
