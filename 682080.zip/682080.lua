-- Lua provided by RyzenAPI
-- Game: Pato Box

-- MAIN APPLICATION
addappid(682080)
addappid(682081)
addappid(682082)
addappid(682084)
addappid(854370)
-- Game: addappid(682080)

-- MAIN APP DEPOTS / PACKAGES
addappid(682083,0,"8c853327e98358ca68c70ee385d444271db1ebcb487ecb62fb1346d8b808c41c")
