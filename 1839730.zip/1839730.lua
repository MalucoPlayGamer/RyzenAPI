-- Lua provided by RyzenAPI
-- Game: The Centennial Case : A Shijima Story (DEMO)

-- MAIN APPLICATION
addappid(1839730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839731, 1, "7898f3c90171b9a546bdb3f452ad11056f7b4a3c89392d5caf790e7675b8aef2")

