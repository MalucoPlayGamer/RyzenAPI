-- Lua provided by SkyAPI 
-- Game: The Centennial Case : A Shijima Story (DEMO)
addappid(1839730)
addappid(1839731, 1, "7898f3c90171b9a546bdb3f452ad11056f7b4a3c89392d5caf790e7675b8aef2")
