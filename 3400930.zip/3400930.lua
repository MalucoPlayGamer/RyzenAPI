-- Lua provided by RyzenAPI
-- Game: Guilty as Sock!

-- MAIN APPLICATION
addappid(3400930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400931, 1, "b4b077327c865e84c8ff3a5df3db9164977fc05a5fe3af164e0c3789a4f18ce0")
