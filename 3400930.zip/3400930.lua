-- Lua provided by RyzenAPI
-- Game: Guilty as Sock!

-- MAIN APPLICATION
addappid(3400930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3400931, 1, "b4b077327c865e84c8ff3a5df3db9164977fc05a5fe3af164e0c3789a4f18ce0")

