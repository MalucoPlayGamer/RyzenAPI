-- Lua provided by RyzenAPI
-- Game: addappid(881510)

-- MAIN APPLICATION
addappid(881510)

-- MAIN APP DEPOTS / PACKAGES
addappid(881511, 1, "4d15217ecebf136f6595a5cbbec74a8c8312d7ed360e04dc9b9bf4fda3b8212f")
