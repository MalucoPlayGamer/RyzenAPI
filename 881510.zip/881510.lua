-- Lua provided by RyzenAPI
-- Game: The Official GamingTaylor Game, Great Job!

-- MAIN APPLICATION
addappid(881510)

-- MAIN APP DEPOTS / PACKAGES
addappid(881511, 1, "4d15217ecebf136f6595a5cbbec74a8c8312d7ed360e04dc9b9bf4fda3b8212f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
