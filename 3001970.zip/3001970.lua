-- Lua provided by RyzenAPI
-- Game: Coloring Game 5

-- MAIN APPLICATION
addappid(3001970)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3227820)
addappid(3357180)
addappid(3357190)
addappid(3357200)
addappid(3357210)
addappid(4250740)
addappid(4701840)
addappid(5041120)
