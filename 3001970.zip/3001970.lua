-- Lua provided by RyzenAPI
-- Game: Coloring Game 5

-- MAIN APPLICATION
addappid(3001970)

