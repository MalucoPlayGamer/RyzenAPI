-- Lua provided by RyzenAPI
-- Game: Nazi Elimination

-- MAIN APPLICATION
addappid(778550)

-- MAIN APP DEPOTS / PACKAGES
addappid(778551,0,"f41c2a237b4312cf8f997665c72096916eb5b44f176edaef50d3717317a16b7a")

