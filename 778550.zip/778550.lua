-- Lua provided by RyzenAPI
-- Game: Nazi Elimination

-- MAIN APPLICATION
addappid(778550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(778551,0,"f41c2a237b4312cf8f997665c72096916eb5b44f176edaef50d3717317a16b7a")

