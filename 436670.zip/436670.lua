-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails in the Sky the 3rd

-- MAIN APPLICATION
addappid(436670)

-- MAIN APP DEPOTS / PACKAGES
addappid(436671, 1, "1798815c21d9266f1df4541b3bed1589c33fca4856490d0c4b10b76331b8a45e")
