-- Lua provided by RyzenAPI
-- Game: 566420

-- MAIN APPLICATION
addappid(566420)
-- Game: addappid(566420)

-- MAIN APP DEPOTS / PACKAGES
addappid(566421, 1, "ea03601a37c0d9f98468c825869f199e26a1edef8a270583b660ea720002e8c9")
