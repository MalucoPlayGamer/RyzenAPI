-- Lua provided by RyzenAPI
-- Game: Game: Teleglitch: Die More Edition

-- MAIN APPLICATION
addappid(234390)
-- Game: addappid(234390)

-- MAIN APP DEPOTS / PACKAGES
addappid(234391, 1, "5c65a74fab3656f61118ad27c6fc1838ba8ae3f99c8c8c05a1be70f006c29cec")
addappid(234392, 1, "20ec9b3ac8176e1e3acb11984d8a85e85e639ac11b43f3fea4849e88f05ffe3b")
addappid(234393, 1, "625ed7d99ccfe31f8bc98516bb5bb399383e8a1c00971043ac25964c4397f92b")
addappid(240820, 0, "b4c070e5235281ab7a5876189e5a83bcabbc9920982620753d060770481162e5")
