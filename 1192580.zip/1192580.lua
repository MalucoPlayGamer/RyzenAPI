-- Lua provided by RyzenAPI
-- Game: Nyanco Dream

-- MAIN APPLICATION
addappid(1192580)
addappid(1192581)
addappid(1192582)
addappid(1192583)
addappid(1192585)
addappid(1192586)
addappid(1193320)
-- Game: addappid(1192580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192584,0,"d290ecaad6ad103f18f3e52332aada3d46c5689d85b7a9b98aa59fd537cb7428")
