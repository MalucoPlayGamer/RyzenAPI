-- Lua provided by RyzenAPI
-- Game: addappid(2607870)

-- MAIN APPLICATION
addappid(2607870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607871, 1, "63effcccb63f3b94634026d5d8d42c22bc70882a2cbd5b60fc04bcb914228400")
