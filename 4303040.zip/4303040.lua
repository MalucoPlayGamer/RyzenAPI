-- Lua provided by RyzenAPI
-- Game: Pyromaniac

-- MAIN APPLICATION
addappid(4303040)

-- MAIN APP DEPOTS / PACKAGES
addappid(4303041,0,"fd435c11e92ddd443559f37a5dd0629cd94baba9768b335b490c7f8045155635")

