-- Lua provided by RyzenAPI
-- Game: Luminary Online: Rise of the GoonZu

-- MAIN APPLICATION
addappid(1685530)
-- Game: addappid(1685530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685531, 1, "e5620de2340c6d965498076442f7dc745f1bc84199853d8cc3c6c077b0c37131")
