-- Lua provided by SkyAPI 
-- Game: Luminary Online: Rise of the GoonZu
addappid(1685530)
addappid(1685531, 1, "e5620de2340c6d965498076442f7dc745f1bc84199853d8cc3c6c077b0c37131")
