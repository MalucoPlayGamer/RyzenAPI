-- Lua provided by RyzenAPI
-- Game: Game: AppID 265360

-- MAIN APPLICATION
addappid(265360)
-- Game: addappid(265360)

-- MAIN APP DEPOTS / PACKAGES
addappid(265361, 1, "5429a27f66aa3ebc6d7272f2484c6dcb3ffb56e41c0b4ce7f1609356269ce811")
