-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Space Marine Soundtrack

-- MAIN APPLICATION
addappid(1759110)
-- Game: addappid(1759110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759111, 1, "e13ef9da7eeb6e8c57c1b175a21af0282708b2e92e324c17c16e0fc430edc31b")
addappid(1759112, 1, "449655b5d5e972ae600a43e1c9b814902072edf44284ac6536c6340b23fa1eb0")
