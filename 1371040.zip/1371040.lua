-- Lua provided by RyzenAPI
-- Game: Game: Corridors of Their Memories

-- MAIN APPLICATION
addappid(1371040)
-- Game: addappid(1371040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371041, 1, "b8e3f43856e91d6b8123e16bb06c5c8b9a3412b6079b6f7694b4c595c8c9a328")
