-- Lua provided by RyzenAPI
-- Game: The Headliners

-- MAIN APPLICATION
addappid(3059070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059071, 1, "dc69975bdb4fe70b03c46dcb49e561b4b72524fb28d919a95faa8d1f5f987e5b")
