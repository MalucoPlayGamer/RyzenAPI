-- Lua provided by RyzenAPI
-- Game: True Nightmare - Roadside Сafe: Prologue

-- MAIN APPLICATION
addappid(3264210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264211, 1, "143054e50159214f9ae19f3fff51d5940017fc76e5b8fc720e5aa172378232c8")

