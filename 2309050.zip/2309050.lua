-- Lua provided by RyzenAPI
-- Game: Sea of Thieves - Wallpapers

-- MAIN APPLICATION
addappid(2309050)
-- Game: addappid(2309050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309050,0,"e496bd343a45a22ca0148b587298f7701885f32f944ce4217de1c0ba4fb0f786")
