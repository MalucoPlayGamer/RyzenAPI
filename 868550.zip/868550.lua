-- Lua provided by RyzenAPI
-- Game: What do you hear?? Yanny vs Laurel

-- MAIN APPLICATION
addappid(868550)

-- MAIN APP DEPOTS / PACKAGES
addappid(868551, 1, "fef1cea9ea0df0f5568616635fdd089e8dffce9cc740b49237592509e45172e8")

