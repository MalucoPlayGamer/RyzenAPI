-- Lua provided by RyzenAPI
-- Game: 3496950

-- MAIN APPLICATION
addappid(3496950)
-- Game: addappid(3496950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496951, 1, "6dc6b06ef3c33516d9660698e9537568ee7e4f613a4a4fc3b173bd5aba3e8cde")
