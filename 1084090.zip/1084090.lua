-- Lua provided by RyzenAPI 
-- Game: AppID 1084090
addappid(1084090)
addappid(1084091, 1, "317f4e538747d894e7e6761b7983a726a700cb9109d30a98d05e6bc957740f46")
