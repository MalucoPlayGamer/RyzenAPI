-- Lua provided by RyzenAPI
-- Game: AppID 1084090

-- MAIN APPLICATION
addappid(1084090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084091, 1, "317f4e538747d894e7e6761b7983a726a700cb9109d30a98d05e6bc957740f46")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
