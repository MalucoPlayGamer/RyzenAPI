-- Lua provided by SkyAPI 
-- Game: Enforcer: Police Crime Action
addappid(318220)
addappid(318221, 1, "c38ec98d40ffb585b46193997cfc3c6ff18f4235f1ba54c9ba5ed74f7f4b69b2")
addappid(318222, 1, "cfccd75452d6bb76f96bd50310da8ea38821f89660177b9a88d93137ae397874")
