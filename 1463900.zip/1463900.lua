-- Lua provided by RyzenAPI
-- Game: Pretty Girls and Dark Witch. A simple story

-- MAIN APPLICATION
addappid(1463900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463902,0,"eb8f575b786a9d9c6268d2c86d2a9a5493333a6a2138535c532b97c767963232")
addappid(1463903,0,"72823e19b60d66972fa638c505efd29779ef74a6f70c0c776abfc01fc6a1b6f3")
