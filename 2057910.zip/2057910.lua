-- Lua provided by RyzenAPI
-- Game: AppID 2057910

-- MAIN APPLICATION
addappid(2057910)
-- Game: addappid(2057910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057911, 1, "ffeb29e9bf79828de144079a88efdbe2f642438e72c1a58935ef7ba8317ddeb7")
