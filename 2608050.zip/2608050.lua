-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Jingle Jam

-- MAIN APPLICATION
addappid(2608050)
addappid(2723350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608051, 1, "1cc9b4d6b7c190feff53cee18a10fcd20513546707c16c4c8d6ba8e3636956cd")

