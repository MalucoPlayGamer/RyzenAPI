-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Jingle Jam

-- MAIN APPLICATION
addappid(2608050)
addappid(2723350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608051, 1, "1cc9b4d6b7c190feff53cee18a10fcd20513546707c16c4c8d6ba8e3636956cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
