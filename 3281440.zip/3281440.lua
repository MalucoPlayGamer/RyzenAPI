-- Lua provided by RyzenAPI
-- Game: addappid(3281440)

-- MAIN APPLICATION
addappid(3281440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012391,0,"40d7b1e51194f9f2f672d0ceb4c32e8eeb75cc17eef0cd813a651afcd04eccdf")
