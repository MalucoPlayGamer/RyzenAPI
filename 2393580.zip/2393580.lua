-- Lua provided by RyzenAPI
-- Game: The Dead Await

-- MAIN APPLICATION
addappid(2393580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2393581, 1, "1279db8cd7d23429b826afe7c414fd734273be90411336a848f46c1b419ed7b5")

