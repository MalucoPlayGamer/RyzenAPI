-- Lua provided by RyzenAPI
-- Game: The Dead Await

-- MAIN APPLICATION
addappid(2393580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393581, 1, "1279db8cd7d23429b826afe7c414fd734273be90411336a848f46c1b419ed7b5")
