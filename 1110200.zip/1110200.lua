-- Lua provided by RyzenAPI
-- Game: addappid(1110200)

-- MAIN APPLICATION
addappid(1110200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110201, 1, "545cf98fb768795b9eeab45373ac9b888a9f24b7b630e1fadeb632b8e4bf25f6")
