-- Lua provided by RyzenAPI 
-- Game: AppID 2623640
addappid(2623640)
addappid(2623641, 1, "49c405f8263d062cedf138239a6b823ffbe05f7fc3b7bd4f1169f74912fd9189")
