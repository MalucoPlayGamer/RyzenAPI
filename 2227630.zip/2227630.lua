-- Lua provided by RyzenAPI
-- Game: Furry Dream

-- MAIN APPLICATION
addappid(2227630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227631, 1, "dbd194f6b717a6f7ab42947346ab4612859d0339eae6f889bfc0948ae2535298")
