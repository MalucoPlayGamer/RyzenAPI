-- Lua provided by RyzenAPI
-- Game: Sanitarium

-- MAIN APPLICATION
addappid(284050)

-- MAIN APP DEPOTS / PACKAGES
addappid(284051, 1, "8a62eaa19b98dbf115a1940155f118935c2fe5d2485a6e64b8f23801f72bcf1a")
addappid(284052, 1, "20661a175dbb3e25456c0896de04afd0fe8dffcbe8c2795333bd75fc2b346c57")
addappid(284053, 1, "1b1813de97b551a976423bf59244d0c2bae31097e9b7dcce20e64788d4186cce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
