-- Lua provided by RyzenAPI
-- Game: Game: Sanitarium

-- MAIN APPLICATION
addappid(284050)
-- Game: addappid(284050)

-- MAIN APP DEPOTS / PACKAGES
addappid(284051, 1, "8a62eaa19b98dbf115a1940155f118935c2fe5d2485a6e64b8f23801f72bcf1a")
addappid(284052, 1, "20661a175dbb3e25456c0896de04afd0fe8dffcbe8c2795333bd75fc2b346c57")
addappid(284053, 1, "1b1813de97b551a976423bf59244d0c2bae31097e9b7dcce20e64788d4186cce")
