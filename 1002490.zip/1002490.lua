-- Lua provided by SkyAPI 
-- Game: Roulette Simulator 2
addappid(1002490)
addappid(1002491, 1, "81a88db650e0076645c5145385116609c93f9eae1cef3a6232768ca61a5a0c2a")
