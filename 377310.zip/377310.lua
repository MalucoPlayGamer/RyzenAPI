-- Lua provided by RyzenAPI 
-- Game: The Tower Of Elements
addappid(377310)
addappid(377311, 1, "65ed673b92210799ced3b9ac9591a946a435f59dd084edbe8a1ff8a60bad6dcf")
addappid(377312, 1, "94c4915671a29a9ab43454f2607da77d36bc1190538e28ef5641072e99fa63d7")
addappid(377313, 1, "e2d06912af63522d27a2909d4f682dec25e75a89f46d326321b8d8f1614ee0d2")
