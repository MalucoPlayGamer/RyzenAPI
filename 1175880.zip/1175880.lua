-- Lua provided by RyzenAPI
-- Game: Game: War Room

-- MAIN APPLICATION
addappid(1175880)
-- Game: addappid(1175880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175881, 1, "8467b9955444d205259f4cca9e077c1004ec0e01ff8897f0858454ca64cc294e")
