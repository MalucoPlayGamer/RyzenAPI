-- Lua provided by RyzenAPI
-- Game: Vlad Voievod Dracula: Dungeons of Edirne

-- MAIN APPLICATION
addappid(2651830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651832,0,"9b78784b436373ab04c300c2c369c776c6deda4b7d2343ce96499a49b9ab0857")

