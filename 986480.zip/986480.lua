-- Lua provided by RyzenAPI
-- Game: Sharknado VR (Arcade Edition)

-- MAIN APPLICATION
addappid(986480)
-- Game: addappid(986480)

-- MAIN APP DEPOTS / PACKAGES
addappid(986481, 1, "bd12f71d153966013a52542b72f7d5a75f8b70ba241635d86616d028d4fed9ee")
