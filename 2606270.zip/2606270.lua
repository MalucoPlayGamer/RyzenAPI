-- Lua provided by RyzenAPI
-- Game: Cyber Avenger

-- MAIN APPLICATION
addappid(2606270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2606271, 1, "26a9f0b56280cf0c526f5181d426911fa592cecc2b0e646e52047d2d1451812c")

