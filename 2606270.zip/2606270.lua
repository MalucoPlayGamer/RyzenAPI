-- Lua provided by RyzenAPI
-- Game: Cyber Avenger

-- MAIN APPLICATION
addappid(2606270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606271, 1, "26a9f0b56280cf0c526f5181d426911fa592cecc2b0e646e52047d2d1451812c")
