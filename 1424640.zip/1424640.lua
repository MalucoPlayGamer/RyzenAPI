-- Lua provided by RyzenAPI
-- Game: Game: 余烬

-- MAIN APPLICATION
addappid(1424640)
-- Game: addappid(1424640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424641, 1, "352916ca731eea7406797be9df29394c2a47e80d295c83b96b78ee8d258ca38b")
