-- Lua provided by SkyAPI 
-- Game: AppID 834440
addappid(834440)
addappid(834441, 1, "7b9c8597dcd9cd964d7d14d937d6ad8d2790cd78e79a56dcb80987d5d508c7bc")
