-- Lua provided by RyzenAPI
-- Game: AppID 834440

-- MAIN APPLICATION
addappid(834440)

-- MAIN APP DEPOTS / PACKAGES
addappid(834441, 1, "7b9c8597dcd9cd964d7d14d937d6ad8d2790cd78e79a56dcb80987d5d508c7bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
