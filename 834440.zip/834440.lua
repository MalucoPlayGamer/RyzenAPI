-- Lua provided by RyzenAPI
-- Game: AppID 834440

-- MAIN APPLICATION
addappid(834440)

-- MAIN APP DEPOTS / PACKAGES
addappid(834441, 1, "7b9c8597dcd9cd964d7d14d937d6ad8d2790cd78e79a56dcb80987d5d508c7bc")
