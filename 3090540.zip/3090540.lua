-- Lua provided by RyzenAPI
-- Game: RSSU - Retro Style Soviet Undies Demo

-- MAIN APPLICATION
addappid(3090540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090541, 1, "65a0ec9571759d5f6539f4d603f9696d7ae5ff561e8d8b2286c20c6e476f9087")
