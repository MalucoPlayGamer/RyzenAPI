-- Lua provided by RyzenAPI
-- Game: Gothic Girls

-- MAIN APPLICATION
addappid(1406270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406271, 1, "8e38c04f0d3fcc0f4d2118e105230d0ff34069d19fe4375c629073c18f461c70")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1416620)
