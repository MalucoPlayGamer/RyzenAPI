-- Lua provided by RyzenAPI 
-- Game: Delila's Gift
addappid(538110)
addappid(538111, 1, "8f412812d807cc5c63a3938b3665fb4d3853510db20aae806b75c302cb41456a")
