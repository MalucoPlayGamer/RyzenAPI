-- Lua provided by RyzenAPI
-- Game: Game: Delila's Gift

-- MAIN APPLICATION
addappid(538110)
-- Game: addappid(538110)

-- MAIN APP DEPOTS / PACKAGES
addappid(538111, 1, "8f412812d807cc5c63a3938b3665fb4d3853510db20aae806b75c302cb41456a")
