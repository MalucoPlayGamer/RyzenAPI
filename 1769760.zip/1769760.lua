-- Lua provided by RyzenAPI
-- Game: Meet PIP

-- MAIN APPLICATION
addappid(1769760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1769761, 1, "cc9d169156f2683cfa26c1b63055aa8ee8f02f54892c738427fbfacc5a7bbc9b")

