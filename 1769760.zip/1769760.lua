-- Lua provided by RyzenAPI
-- Game: Meet PIP

-- MAIN APPLICATION
addappid(1769760)
-- Game: addappid(1769760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769761, 1, "cc9d169156f2683cfa26c1b63055aa8ee8f02f54892c738427fbfacc5a7bbc9b")
