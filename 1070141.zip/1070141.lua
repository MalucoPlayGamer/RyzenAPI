-- Lua provided by RyzenAPI
-- Game: 1070141

-- MAIN APPLICATION
addappid(1070141)
-- Game: addappid(1070141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070141,0,"c7d6373aaa3a2846e19d19d1c87a7f3de5811c91116e08df3fa469adad9a7fa4")
