-- Lua provided by RyzenAPI
-- Game: DeltaBlade 2700

-- MAIN APPLICATION
addappid(1143450)
-- Game: addappid(1143450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143451, 1, "061fa43e48434eb5e2ee18242051e2c42bc220d27f8e48d993e4f10b78cb2898")
