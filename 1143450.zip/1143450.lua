-- Lua provided by RyzenAPI
-- Game: DeltaBlade 2700

-- MAIN APPLICATION
addappid(1143450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1143451, 1, "061fa43e48434eb5e2ee18242051e2c42bc220d27f8e48d993e4f10b78cb2898")

