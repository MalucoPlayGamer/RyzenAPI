-- Lua provided by RyzenAPI
-- Game: DragonStone

-- MAIN APPLICATION
addappid(434830)
-- Game: addappid(434830)

-- MAIN APP DEPOTS / PACKAGES
addappid(434831, 1, "9508bdb633abf6bc98e9f600509381216740dc55f30096beb7454819d996971b")
