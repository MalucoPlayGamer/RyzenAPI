-- Lua provided by RyzenAPI
-- Game: 2292750

-- MAIN APPLICATION
addappid(2292750)
-- Game: addappid(2292750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292751, 1, "bc69c490447d0a88edad7f8326fd88faac67b07b823d0b2389d1f1bece09007f")
