-- Lua provided by RyzenAPI
-- Game: Lab Rat

-- MAIN APPLICATION
addappid(1304610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304611, 1, "9a59d57bbb3386ba82b7d5136c5168cb53e058bb7b9d566a76f3e0e77c743417")
