-- Lua provided by RyzenAPI
-- Game: Lab Rat

-- MAIN APPLICATION
addappid(1304610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304611, 1, "9a59d57bbb3386ba82b7d5136c5168cb53e058bb7b9d566a76f3e0e77c743417")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
