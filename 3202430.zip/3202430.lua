-- Lua provided by RyzenAPI
-- Game: Tiny Devils

-- MAIN APPLICATION
addappid(3202430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202431, 1, "97be19030d0644dff6061fee3aa0f38c52ff7e829c8c62f0cd58e90f2a769001")
