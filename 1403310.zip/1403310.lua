-- Lua provided by RyzenAPI
-- Game: Garden Simulator

-- MAIN APPLICATION
addappid(1403310)
addappid(2304280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403311, 1, "21a51d2699f4399ab986e729bf47a2406a756ea5fce3fa65da47c46a157ded87")

