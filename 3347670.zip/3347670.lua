-- Lua provided by SkyAPI 
-- Game: BM General Hospital
addappid(3347670)
addappid(3347671, 1, "a3a95249de5708328ccb0fcdffde60c7eefc4125b5f28a6c8e1330a6caea1445")
