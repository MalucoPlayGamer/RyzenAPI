-- Lua provided by RyzenAPI
-- Game: BM General Hospital

-- MAIN APPLICATION
addappid(3347670)
-- Game: addappid(3347670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347671, 1, "a3a95249de5708328ccb0fcdffde60c7eefc4125b5f28a6c8e1330a6caea1445")
