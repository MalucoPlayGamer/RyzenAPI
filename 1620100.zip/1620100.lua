-- Lua provided by RyzenAPI
-- Game: FURRIFIGHTERS: PREQUEL I

-- MAIN APPLICATION
addappid(1620100)

