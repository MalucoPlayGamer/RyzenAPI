-- Lua provided by RyzenAPI
-- Game: FURRIFIGHTERS: PREQUEL I

-- MAIN APPLICATION
addappid(1620100)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2023110)
addappid(2140220)
addappid(2196880)
addappid(2196881)
addappid(2268920)
addappid(2309860)
