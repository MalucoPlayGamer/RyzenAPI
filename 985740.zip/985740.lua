-- Lua provided by RyzenAPI
-- Game: 同居指南 | Cohabitation Guide

-- MAIN APPLICATION
addappid(985740)

-- MAIN APP DEPOTS / PACKAGES
addappid(985741, 1, "79cae3e4317fe4c51739830511b69a5e96f77d6d8efb5da35fafe60e0af36815")
addappid(985743, 1, "72dc7e240e4cc1ba68fe34f4dc3069e921def92843e091e59804ba9df0abc78e")

