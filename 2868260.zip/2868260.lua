-- Lua provided by RyzenAPI
-- Game: Game: Urban Nightmare

-- MAIN APPLICATION
addappid(2868260)
-- Game: addappid(2868260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868261, 1, "c2a9f9a709d0485b84e63b29dee0c425f7a886569be55ce2b11903d648d19d96")
