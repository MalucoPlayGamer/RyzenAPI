-- Lua provided by RyzenAPI 
-- Game: Urban Nightmare
addappid(2868260)
addappid(2868261, 1, "c2a9f9a709d0485b84e63b29dee0c425f7a886569be55ce2b11903d648d19d96")
