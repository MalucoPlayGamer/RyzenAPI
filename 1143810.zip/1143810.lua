-- Lua provided by RyzenAPI
-- Game: Black Skylands

-- MAIN APPLICATION
addappid(1143810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143811, 1, "f1be9d8e6df2ff518fad12aaef496dd12e89500f6827193e9660bf84dbb53aee")
addappid(1799480, 0, "e81dffde37487dea48e17245e183fbc4687e9273a903391960be64b41f6204dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2464550)
