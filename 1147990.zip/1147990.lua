-- Lua provided by RyzenAPI 
-- Game: AppID 1147990
addappid(1147990)
addappid(1147991, 1, "ece532ad21efb4ef8b3c33d9a9ecf44359e71edfaa6444a51807914f197a2844")
