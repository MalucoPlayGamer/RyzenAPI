-- Lua provided by RyzenAPI
-- Game: Iesabel

-- MAIN APPLICATION
addappid(248710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(248711, 1, "04c51a085a666fffa9d60cc2cc767b391a6d56f4e56075d8beae8a7abda55c2a")
addappid(248712, 1, "b1b6a0b4cdd9b71a6308deef0f0d2ae6a75b021fd66bb6b8d1dc98d624b29374")
addappid(248713, 1, "0693da8b873fd62c7602f16690cde891bce2906e4d7a3d621ec3309ad4b06f7a")
addappid(248714, 1, "12bc252543e199025ca230c2659639e2667d53251b90b9e15b56092ac112938c")
