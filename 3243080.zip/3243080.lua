-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Heroine Generator 5 for MZ

-- MAIN APPLICATION
addappid(3243080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243080,0,"3321253528a03c9728d901f6632d9af131462e725fa79b986258e448c48d1eb4")
