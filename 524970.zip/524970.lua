-- Lua provided by RyzenAPI
-- Game: Game: AppID 524970

-- MAIN APPLICATION
addappid(524970)
-- Game: addappid(524970)

-- MAIN APP DEPOTS / PACKAGES
addappid(524971, 1, "1e6cf58282baae65807fa9db9166bd01d85dcc6937e1e4257e613988de30d3de")
