-- Lua provided by RyzenAPI
-- Game: Fly High

-- MAIN APPLICATION
addappid(945240)
-- Game: addappid(945240)

-- MAIN APP DEPOTS / PACKAGES
addappid(945241, 1, "0d980240156238623b23d04e21a492bb12d11e0158ecc916385a26ae6043d360")
