-- Lua provided by SkyAPI 
-- Game: Blood Moon
addappid(2249040)
addappid(2249041, 1, "fdcc01a0fadf67c4782a2e6593c3f6c1e26686dcf1dc5315fe34e6d8fc302a60")
