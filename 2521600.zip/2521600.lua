-- Lua provided by RyzenAPI
-- Game: addappid(2521600)

-- MAIN APPLICATION
addappid(2521600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521601, 1, "6161687dde07b03f65efd44c9c8e2155eb0b04048dcd270edc85d5881f61a3dd")
