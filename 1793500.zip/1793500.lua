-- Lua provided by RyzenAPI
-- Game: Christmas Live Wallpaper

-- MAIN APPLICATION
addappid(1793500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1793501, 1, "657d81d111726022fc4fe7d749e2e37f8b9b67595981232c949fd5f120964316")

