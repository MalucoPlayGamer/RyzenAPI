-- Lua provided by RyzenAPI
-- Game: AppID 908180

-- MAIN APPLICATION
addappid(908180)

-- MAIN APP DEPOTS / PACKAGES
addappid(908181, 1, "defb4fe7ecd7ba0cc0db2cc4dd4eb58c7f1ddab520cf2cc62e063608e6a925d3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1003740)
