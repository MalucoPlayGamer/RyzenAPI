-- Lua provided by RyzenAPI
-- Game: Game: AppID 2247820

-- MAIN APPLICATION
addappid(2247820)
-- Game: addappid(2247820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247821, 1, "551f02bbd669aeb311f6167481c3516b03025dd6e4bd5a25f832e9eec9ae5d4b")
