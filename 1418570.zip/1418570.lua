-- Lua provided by RyzenAPI
-- Game: Zen Trails

-- MAIN APPLICATION
addappid(1418570)
-- Game: addappid(1418570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418571, 1, "47fdc0b128a9c691665f0da4533f25dbeac3328025e1f64f81ec3290e457d2c6")
