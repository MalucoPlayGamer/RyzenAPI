-- Lua provided by RyzenAPI
-- Game: Little Garden

-- MAIN APPLICATION
addappid(2292030)
-- Game: addappid(2292030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292031, 1, "4252c5f3ecc91351a9f1ebd27f0146bc5c87beac51cd91a4cbeed48687e5ee93")
