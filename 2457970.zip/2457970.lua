-- Lua provided by RyzenAPI
-- Game: Game: Amicade

-- MAIN APPLICATION
addappid(2457970)
-- Game: addappid(2457970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457971, 1, "0f51f4b551d64325beea7a148f97b65e6fd32c3800ca3ce04d335718d83a6dc3")
