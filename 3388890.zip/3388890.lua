-- Lua provided by RyzenAPI
-- Game: Game: Magical Nut Ikuno

-- MAIN APPLICATION
addappid(3388890)
-- Game: addappid(3388890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388891, 1, "c8d05d587065531a087c3c943b98a89675c5a158565c1f9213fc3aee53ef39f9")
