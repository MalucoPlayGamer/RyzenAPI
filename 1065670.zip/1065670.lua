-- Lua provided by SkyAPI 
-- Game: 4004-022
addappid(1065670)
addappid(1065671, 1, "c40ce5bff607dd01152763e6491500b978ea0ca1d495a591023ec88cadbfd465")
addappid(1065672, 1, "e1951606762ba9a3ea02b9ba5bf67f5cd891e761d2a3713c75c834d44e1b10eb")
