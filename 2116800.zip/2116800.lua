-- Lua provided by RyzenAPI
-- Game: 2116800

-- MAIN APPLICATION
addappid(2116800)
-- Game: addappid(2116800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116801, 1, "b18e20797c587d15df6dffaf0cb79dcfe54a15553bc1398693c40f58a9478118")
