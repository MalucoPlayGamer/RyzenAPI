-- Lua provided by SkyAPI 
-- Game: The Soul Stone War 2
addappid(1775520)
addappid(1775521, 1, "038f01b12b7e79fc4dee6db5b69ec959d9ca4f4e4a0c3e6d9ad41c7826abdd2f")
