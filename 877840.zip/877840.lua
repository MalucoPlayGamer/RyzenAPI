-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(877840)
addappid(877843)
addappid(877844)

-- MAIN APP DEPOTS / PACKAGES
addappid(877842,0,"7ea9c4bace2df8cd3f7946066afebe6346eb6223df8b58ed9d3a92affc18d18b")
