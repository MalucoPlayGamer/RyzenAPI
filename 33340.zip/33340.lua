-- Lua provided by RyzenAPI
-- Game: Dawn of Discovery™: Venice

-- MAIN APPLICATION
addappid(33340)
-- Game: addappid(33340)

-- MAIN APP DEPOTS / PACKAGES
addappid(33212,0,"6458606a0d6ba86804db8738af33086c3c3733bf2cde9c1a5e401e7b9f195a31")
addappid(33213,0,"91f89c6bb71248195145ee87bb76d1901f89b4b686f5153b68a0e375eaf7fe51")
addappid(33214,0,"5b48ee28f51f9a6b5f9b5c209ea3e2ba7b4441b77e43435768924362ea8e27e4")
