-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Manchester

-- MAIN APPLICATION
addappid(2436901)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436901,0,"565f4f48fb8fb5b5a47b74c0743032928c4fd9b920645c331e53e76d770f6cfd")

