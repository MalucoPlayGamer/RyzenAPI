-- Lua provided by RyzenAPI
-- Game: Live Waifu Wallpaper

-- MAIN APPLICATION
addappid(1711480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711481, 1, "06106cead8312800b1ccd71a11def64b31cacce3a4aafd0e71d03fe94319d5bf")
