-- Lua provided by RyzenAPI
-- Game: Awaken: Hentai Dice - Digital Artbook

-- MAIN APPLICATION
addappid(3296930)
-- Game: addappid(3296930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296930,0,"1d318bfeee7b1871cf53b4f4487e95b9889962a166b6cc3d123815617cb4f850")
