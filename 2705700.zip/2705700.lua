-- Lua provided by RyzenAPI
-- Game: 2705700

-- MAIN APPLICATION
addappid(2705700)
-- Game: addappid(2705700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705701, 1, "614450e75e1f3e676db1ea72bbbce329d2aaac6d9599404583ead87835824a63")
