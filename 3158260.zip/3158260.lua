-- Lua provided by RyzenAPI
-- Game: HSS:Reload

-- MAIN APPLICATION
addappid(3158260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158261, 1, "efec6ecfe2df3b296f3c0c54c539366564d7bf4dd5c702acdf94334f590d259b")
