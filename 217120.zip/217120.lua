-- Lua provided by RyzenAPI
-- Game: 217120

-- MAIN APPLICATION
addappid(217120)
addappid(228986)
addappid(228990)
-- Game: addappid(217120)

-- MAIN APP DEPOTS / PACKAGES
addappid(217121, 1, "1432ac2110fc04650ac81655d2d1cc55d0ce09b1d99fa58ec0dc7de3a175d558")
addappid(217122, 1, "ce76d4b033a2a43573bbaf052e0549da04ec99128dedc919eabea0ba49e09d5f")
