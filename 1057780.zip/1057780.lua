-- Lua provided by RyzenAPI
-- Game: Game: AppID 1057780

-- MAIN APPLICATION
addappid(1057780)
-- Game: addappid(1057780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057781, 1, "554e34846a8f348a3aed104d5022257a543a878629caf9906ea39b7601a5d30a")
