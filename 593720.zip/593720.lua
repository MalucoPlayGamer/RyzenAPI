-- Lua provided by RyzenAPI
-- Game: Dangerous Games: Prisoners of Destiny Collector's Edition

-- MAIN APPLICATION
addappid(593720)

-- MAIN APP DEPOTS / PACKAGES
addappid(593721, 1, "e55bd104cafc2a96019d41466de41038a5e66963734a03403365a33c4e5fd4c5")
