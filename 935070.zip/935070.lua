-- Lua provided by RyzenAPI
-- Game: Sakura MMO

-- MAIN APPLICATION
addappid(935070)

-- MAIN APP DEPOTS / PACKAGES
addappid(935071, 1, "ae4806c9ff891086d9c69869920edbb154656e4f81000c4aad61bee412923df2")

