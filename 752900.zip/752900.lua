-- Lua provided by RyzenAPI
-- Game: Prehistoric Hunt

-- MAIN APPLICATION
addappid(752900)
-- Game: addappid(752900)

-- MAIN APP DEPOTS / PACKAGES
addappid(752901, 1, "816e38ce1ca4d94a51fc985b14be35b05bd69bcdc2f07006176fde83d30c4464")
