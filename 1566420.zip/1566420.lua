-- Lua provided by RyzenAPI
-- Game: addappid(1566420)

-- MAIN APPLICATION
addappid(1566420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566421, 1, "de505546a3e3f6107be9f0cc58161a988ec47364e0d01babe8298ffc5ef23fa6")
