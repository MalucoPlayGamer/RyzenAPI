-- Lua provided by RyzenAPI
-- Game: 99900

-- MAIN APPLICATION
addappid(99900)
-- Game: addappid(99900)

-- MAIN APP DEPOTS / PACKAGES
addappid(99901, 1, "b14dcd8cbe63efa6e4587684afbff6292f93e08447e4cbe26b9765edce0fce60")
addappid(99902, 1, "9e7606b3336cdea20861004454df26cf59b456c0ac925d1de14e7e6e67b2b8e4")
