-- Lua provided by RyzenAPI
-- Game: Spiral Knights

-- MAIN APPLICATION
addappid(99900)
addappid(99909)
addappid(206520)
addappid(206521)
addappid(206522)
addappid(206523)
addappid(206524)
addappid(206525)
addappid(206526)
addappid(268310)
addappid(268311)
addappid(268312)
addappid(268313)
addappid(268314)
addappid(268315)
addappid(306720)
addappid(306721)
addappid(306722)
addappid(306723)

-- MAIN APP DEPOTS / PACKAGES
addappid(99901,0,"b14dcd8cbe63efa6e4587684afbff6292f93e08447e4cbe26b9765edce0fce60")
addappid(99902,0,"9e7606b3336cdea20861004454df26cf59b456c0ac925d1de14e7e6e67b2b8e4")
addappid(99903,0,"89d408ae5f6dd7b7e407fbec1c9f872a6305274ec15e7140fcd4bee4783b625d")
addappid(99905,0,"2db1e2789f4afaa1e81be9c4e7b2ba2b4f8147721ef655d2e8bbcba304762dc6")

