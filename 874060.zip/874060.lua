-- Lua provided by RyzenAPI
-- Game: Bleeding Moons

-- MAIN APPLICATION
addappid(874060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(874061, 1, "aefd1a78f7c7a5840f9d224b910af9f1cd3830218ebb20d331fefa022cbfb0c7")

