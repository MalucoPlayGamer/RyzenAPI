-- Lua provided by RyzenAPI
-- Game: addappid(874060)

-- MAIN APPLICATION
addappid(874060)

-- MAIN APP DEPOTS / PACKAGES
addappid(874061, 1, "aefd1a78f7c7a5840f9d224b910af9f1cd3830218ebb20d331fefa022cbfb0c7")
