-- Lua provided by RyzenAPI
-- Game: addappid(7660)

-- MAIN APPLICATION
addappid(7660)

-- MAIN APP DEPOTS / PACKAGES
addappid(7661, 1, "c1189e3bf198af394cb9f03c25e00231ebee1943708e5d6bc80bac0aec9e0d60")
