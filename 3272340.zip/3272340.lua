-- Lua provided by RyzenAPI
-- Game: addappid(3272340)

-- MAIN APPLICATION
addappid(3272340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272341, 1, "db0a83e5af3121c6d70bb591725f36935f99582647d7bbe69e60b63db549fe31")
