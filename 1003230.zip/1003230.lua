-- Lua provided by SkyAPI 
-- Game: AIRA VR
addappid(1003230)
addappid(1003231, 1, "eb4ce29311d710dae71b163d5e497a3ca6a459001795e7bc694ed8b549f91a50")
