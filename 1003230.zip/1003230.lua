-- Lua provided by RyzenAPI
-- Game: AIRA VR

-- MAIN APPLICATION
addappid(1003230)
-- Game: addappid(1003230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003231, 1, "eb4ce29311d710dae71b163d5e497a3ca6a459001795e7bc694ed8b549f91a50")
