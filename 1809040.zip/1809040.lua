-- Lua provided by SkyAPI 
-- Game: Base Dune
addappid(1809040)
addappid(1809041, 1, "6127ee63e2be4fbb58d24cdef95d1bf79276698d7c986d359efe54c15e87defb")
