-- Lua provided by RyzenAPI
-- Game: Game: Base Dune

-- MAIN APPLICATION
addappid(1809040)
-- Game: addappid(1809040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809041, 1, "6127ee63e2be4fbb58d24cdef95d1bf79276698d7c986d359efe54c15e87defb")
