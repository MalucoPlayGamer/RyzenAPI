-- Lua provided by RyzenAPI
-- Game: Medieval Delivery

-- MAIN APPLICATION
addappid(2338200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2338201, 1, "3b5e23d2df38bc4eadcbdd38bdc23c95847f0ee58d56f6406196c94a305aab0b")

