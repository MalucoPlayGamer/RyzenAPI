-- Lua provided by RyzenAPI
-- Game: addappid(1957300)

-- MAIN APPLICATION
addappid(1957300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957301, 1, "6438445c87cb03ceb6dabf797e8810236d06c89728081875eae445cdae227f8f")
