-- Lua provided by SkyAPI 
-- Game: The Sirena Expedition
addappid(1957300)
addappid(1957301, 1, "6438445c87cb03ceb6dabf797e8810236d06c89728081875eae445cdae227f8f")
