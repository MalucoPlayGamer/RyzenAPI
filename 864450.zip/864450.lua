-- Lua provided by RyzenAPI
-- Game: AppID 864450

-- MAIN APPLICATION
addappid(864450)

-- MAIN APP DEPOTS / PACKAGES
addappid(864451, 1, "794d3c8fc4a0cec76b6d5301a682144540470e28912f1b626a6d2d5d8bf31077")
addappid(864452, 1, "c809b0bcd5f5c20e4ee487fa01810cf55a6b231b6c8bad990c410bc18dae3b5f")
addappid(864453, 1, "4afed603ac030be17a07ae8db1030e107b1102296f6cf7750856e97ac78da360")
addappid(864454, 1, "ff209cfd40a875cff87dae32b8dca4b0ad7b7c4824656e8f86997986b3dfadba")
addappid(864455, 1, "0618c69c01fda3f7499f15f263fbbcc80611034c3a963f064feaeab83c92aa7f")
addappid(864456, 1, "9d75bfada3e2c5e51f085090ba922c68e262372e475269ce3dfd84362b7e1789")
addappid(864457, 1, "1d539bcd407f90d20558ea865d11af3f0d30fbef644c1eba605f7654fc6ebbdf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
