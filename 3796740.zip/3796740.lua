-- Lua provided by RyzenAPI
-- Game: 77p egg: Cubicle 77

-- MAIN APPLICATION
addappid(3796740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3796741,0,"8ff242c317974f55ca871b7beac613fd9f78b5a23f506b53ea4525ea19525835")

