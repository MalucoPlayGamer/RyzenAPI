-- Lua provided by RyzenAPI
-- Game: 77p egg: Cubicle 77

-- MAIN APPLICATION
addappid(3796740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3796741,0,"8ff242c317974f55ca871b7beac613fd9f78b5a23f506b53ea4525ea19525835")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
