-- Lua provided by RyzenAPI
-- Game: Game: Void Invaders

-- MAIN APPLICATION
addappid(391170)
-- Game: addappid(391170)

-- MAIN APP DEPOTS / PACKAGES
addappid(391171, 1, "ce88f70c1e0f57032013ec226a11fcf0042d70e9f41a2593b097d057fb92f8d9")
addappid(416900, 0, "d887620057ad71313c0d0b297444deb551cfb6f2a6be60ea4c4e7365d52a8d45")
