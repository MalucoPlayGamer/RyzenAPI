-- Lua provided by RyzenAPI
-- Game: Split Personality Doctor: Prologue

-- MAIN APPLICATION
addappid(2858930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858931, 1, "1d5b72ff499626ed2165758bd9c634f42684c5b58427736828e0fa0fc1941b26")

