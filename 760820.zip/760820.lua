-- Lua provided by RyzenAPI
-- Game: addappid(760820)

-- MAIN APPLICATION
addappid(760820)

-- MAIN APP DEPOTS / PACKAGES
addappid(760821, 1, "b237e23dcecbf7622201a7b09c9a763229760ab24dac0d37090268a3c52f0235")
