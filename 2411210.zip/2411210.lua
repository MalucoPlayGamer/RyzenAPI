-- Lua provided by RyzenAPI
-- Game: Mop of the Dead

-- MAIN APPLICATION
addappid(2411210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411211, 1, "5ce11f2f03696787e896d950b75ebdcf7916e20645c583ffbba6f8934708b993")

