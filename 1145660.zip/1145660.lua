-- Lua provided by RyzenAPI
-- Game: AppID 1145660

-- MAIN APPLICATION
addappid(1145660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145661, 1, "c9e3827fbb0703deeecba01a35948a56c89ed09af912947f91b9dcbaa69b620c")
