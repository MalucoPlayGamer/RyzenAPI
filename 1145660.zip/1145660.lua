-- Lua provided by RyzenAPI
-- Game: AppID 1145660

-- MAIN APPLICATION
addappid(1145660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145661, 1, "c9e3827fbb0703deeecba01a35948a56c89ed09af912947f91b9dcbaa69b620c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
