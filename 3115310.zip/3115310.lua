-- Lua provided by RyzenAPI
-- Game: Bloodmoon Survivors

-- MAIN APPLICATION
addappid(3115310) -- Bloodmoon Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(3115311, 1, "a2374b6485b666a767feb8c155659c8f6b91d3675c397ae45e64e1e27f25389a") -- Depot 3115311
addappid(3115312, 1, "e331828aef26806b57367df9182cbafcad58c3def516660cea169ac9c602e1e8") -- Depot 3115312

