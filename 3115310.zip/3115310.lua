-- 3115310's Lua and Manifest Created by Hubcap Manifest
-- Bloodmoon Survivors
-- Created: August 05, 2026 at 13:25:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3115310) -- Bloodmoon Survivors
-- MAIN APP DEPOTS
addappid(3115311, 1, "a2374b6485b666a767feb8c155659c8f6b91d3675c397ae45e64e1e27f25389a") -- Depot 3115311
setManifestid(3115311, "4790077522649369658", 875093113)
addappid(3115312, 1, "e331828aef26806b57367df9182cbafcad58c3def516660cea169ac9c602e1e8") -- Depot 3115312
setManifestid(3115312, "1155358564984625727", 891318971)