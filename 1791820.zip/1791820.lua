-- Lua provided by RyzenAPI
-- Game: Game: Zeitgeist

-- MAIN APPLICATION
addappid(1791820)
-- Game: addappid(1791820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791821, 1, "edd63143b42c5a5d096e7791bb50e0c34e43104cd9f9850fc6255e7e5d825983")
