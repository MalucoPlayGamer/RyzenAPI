-- Lua provided by RyzenAPI
-- Game: Worms W.M.D Editor

-- MAIN APPLICATION
addappid(487710)

-- MAIN APP DEPOTS / PACKAGES
addappid(487711, 1, "aacaed9dcaa8e16d56221c6ccec466af54f44e427d3291e1e668ff17c1e5341f")

