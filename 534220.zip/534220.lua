-- Lua provided by RyzenAPI
-- Game: addappid(534220)

-- MAIN APPLICATION
addappid(534220)

-- MAIN APP DEPOTS / PACKAGES
addappid(534221, 1, "1065ce585521ebf5bb11d7afd6ff92cfc455f0ef372e305c6e0009b321eacf66")
