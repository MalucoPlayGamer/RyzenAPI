-- Lua provided by RyzenAPI
-- Game: Energy Engine PC Live Wallpaper

-- MAIN APPLICATION
addappid(1055010)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1055011, 1, "aef7233e1ab285cc41a6598a545691da244cd2181a01293b2c942ca6b392262d")

