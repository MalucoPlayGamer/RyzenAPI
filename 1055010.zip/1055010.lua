-- Lua provided by RyzenAPI
-- Game: Energy Engine PC Live Wallpaper

-- MAIN APPLICATION
addappid(1055010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055011, 1, "aef7233e1ab285cc41a6598a545691da244cd2181a01293b2c942ca6b392262d")
