-- Lua provided by RyzenAPI
-- Game: Game: Spindle Demo

-- MAIN APPLICATION
addappid(1698620)
-- Game: addappid(1698620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698621, 1, "98d0c8b64fa2896b1c7ed19d152b6ea1cdb56fb4737e99a39e1febc27637d0cb")
