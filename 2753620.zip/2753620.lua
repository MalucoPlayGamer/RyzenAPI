-- Lua provided by RyzenAPI
-- Game: Game: Fruit Mountain

-- MAIN APPLICATION
addappid(2753620)
-- Game: addappid(2753620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753621, 1, "911ea55f97dd7488af659c92740ef0bc2835ed24bda7c3f96d62972e2cda7fdc")
