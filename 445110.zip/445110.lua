-- Lua provided by RyzenAPI
-- Game: Tasty Planet: Back for Seconds

-- MAIN APPLICATION
addappid(445110)
-- Game: addappid(445110)

-- MAIN APP DEPOTS / PACKAGES
addappid(445111, 1, "16f942a6cdfdc936ba6b5f115cafe8a70cec2e802226373058cb44cf3fe8db07")
addappid(445112, 1, "a3fa3dd39eda87c92237d6e08ee2b80cc405063e4e68a415c34fb338cbc04829")
