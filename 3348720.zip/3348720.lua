-- Lua provided by RyzenAPI
-- Game: addappid(3348720)

-- MAIN APPLICATION
addappid(3348720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3348721, 1, "348462bee7f3cfecf2336524d683e5d42563a7ece6cd20cdc55535cb311dae71")
