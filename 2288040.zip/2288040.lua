-- Lua provided by RyzenAPI
-- Game: 2288040

-- MAIN APPLICATION
addappid(2288040)
-- Game: addappid(2288040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288041, 1, "d98026cb0071dee1fac571f71b4979ae3fb7fe8c6e3ea2ab656380a71a8c4beb")
