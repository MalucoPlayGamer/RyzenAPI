-- Lua provided by RyzenAPI
-- Game: BORE BLASTERS Demo

-- MAIN APPLICATION
addappid(2583390)
-- Game: addappid(2583390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583391, 1, "a4a93577ec438fdc9331da54fcd4e57256acd6d7e4221963459b1866e90ad8a3")
