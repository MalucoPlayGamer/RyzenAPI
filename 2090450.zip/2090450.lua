-- Lua provided by RyzenAPI
-- Game: LUMbA: REDUX

-- MAIN APPLICATION
addappid(2090450)
-- Game: addappid(2090450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090451, 1, "44209693204ddce3ac71b9dffbbcf660d712b0080ec6a644f00cf1c10c29d164")
