-- Lua provided by RyzenAPI
-- Game: AppID 224600

-- MAIN APPLICATION
addappid(224600)
addappid(224610)
addappid(224611)
addappid(224612)
addappid(224613)
addappid(224614)
addappid(224615)
addappid(224616)
addappid(240420)
addappid(249540)
addappid(268620)
addappid(272950)
addappid(272960)
addappid(272970)
addappid(304080)
addappid(304081)
addappid(304082)
addappid(369650)
addappid(369660)
addappid(369670)
addappid(542450)
addappid(560100)
addappid(560101)
addappid(560102)

-- MAIN APP DEPOTS / PACKAGES
addappid(224601, 1, "53363258db4ac6dea8e398663bc1612fac69215cfcacfc928e51d5207f413edb")
addappid(224602, 1, "09bdb5461a595cdf48e0ef03d92fd4549d10459314e8288b9dfe23d062408e83")
addappid(845241, 0, "9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")

