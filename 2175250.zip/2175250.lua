-- Lua provided by RyzenAPI
-- Game: Game: Volley Court

-- MAIN APPLICATION
addappid(2175250)
-- Game: addappid(2175250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175251, 1, "991dc0d8a63323d29955729a6581789c4d745791002a582dc1fc394cea2ffe56")
