-- Lua provided by RyzenAPI
-- Game: Game: Adventures at the North Pole

-- MAIN APPLICATION
addappid(2006530)
-- Game: addappid(2006530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006531, 1, "fc104fbe5f7499b7cda8cdb16a48752c4a8163ad2634fc70ac0240055c2d4e9f")
