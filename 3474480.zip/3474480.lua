-- Lua provided by RyzenAPI
-- Game: AppID 3474480

-- MAIN APPLICATION
addappid(3474480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3474481, 1, "6182dd3207afd02ef3c99526272eab47ba97814de1aabad7597d5d16cb9373ed")

