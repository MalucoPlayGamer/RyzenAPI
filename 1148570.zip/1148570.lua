-- Lua provided by RyzenAPI 
-- Game: AppID 1148570
addappid(1148570)
addappid(1148571, 1, "af20538334baac9eb9f8cad81eae94b00d533ecdb2c79080b221cd4c78d12250")
