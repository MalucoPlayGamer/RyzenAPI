-- Lua provided by RyzenAPI
-- Game: Total Annihilation

-- MAIN APPLICATION
addappid(298030)

-- MAIN APP DEPOTS / PACKAGES
addappid(298031, 1, "273bcc1a31060c5db1532b884df2f5790b0e759395646fbe6c668823fd77b7f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
