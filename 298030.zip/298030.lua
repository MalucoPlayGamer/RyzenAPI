-- Lua provided by SkyAPI 
-- Game: Total Annihilation
addappid(298030)
addappid(298031, 1, "273bcc1a31060c5db1532b884df2f5790b0e759395646fbe6c668823fd77b7f9")
