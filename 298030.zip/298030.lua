-- Lua provided by RyzenAPI
-- Game: Total Annihilation

-- MAIN APPLICATION
addappid(298030)

-- MAIN APP DEPOTS / PACKAGES
addappid(298031, 1, "273bcc1a31060c5db1532b884df2f5790b0e759395646fbe6c668823fd77b7f9")

