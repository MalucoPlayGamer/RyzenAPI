-- Lua provided by RyzenAPI
-- Game: Game: AppID 1311830

-- MAIN APPLICATION
addappid(1311830)
-- Game: addappid(1311830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311831, 1, "1e03238407c287d7a4fa545176f32d1d13fb0fa0caf64a250276e5c7ecf52d31")
