-- Lua provided by RyzenAPI
-- Game: AppID 1311830

-- MAIN APPLICATION
addappid(1311830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1311831, 1, "1e03238407c287d7a4fa545176f32d1d13fb0fa0caf64a250276e5c7ecf52d31")

