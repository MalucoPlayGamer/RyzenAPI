-- Lua provided by RyzenAPI
-- Game: 2294980

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2294980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294982,0,"9f764ee812ea36411aa1cdd33c3c3a2959e8edca571574707eedd9c674eb1e26")
