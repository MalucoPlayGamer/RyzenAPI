-- Lua provided by RyzenAPI 
-- Game: Assassin Girls
addappid(1914050)
addappid(1914051, 1, "5e2f9a01070d7150b542aad29f613f54de069052beb47ba9108586b738933ee8")
