-- Lua provided by RyzenAPI
-- Game: Government Simulator

-- MAIN APPLICATION
addappid(731920)

-- MAIN APP DEPOTS / PACKAGES
addappid(731921, 1, "6329568c8f9a52e57306a4a648d2641151998283cbe28e1c0cf7983bec95973a")

