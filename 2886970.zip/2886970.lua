-- Lua provided by RyzenAPI
-- Game: addappid(2886970)

-- MAIN APPLICATION
addappid(2886970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886971, 1, "05b4c0b6c3460a6d938d82e849af5fedf30966d0c426b26aec19cd70741457e1")
