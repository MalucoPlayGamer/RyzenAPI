-- Lua provided by RyzenAPI
-- Game: addappid(3239370)

-- MAIN APPLICATION
addappid(3239370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239371, 1, "0b0cb3bf69ffbf147d108848ee75ba9ab54b6b1da7125d7b73c3d59841f51b29")
