-- Lua provided by RyzenAPI
-- Game: たんぼ

-- MAIN APPLICATION
addappid(3239370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239371, 1, "0b0cb3bf69ffbf147d108848ee75ba9ab54b6b1da7125d7b73c3d59841f51b29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
