-- Lua provided by RyzenAPI
-- Game: AppID 274900

-- MAIN APPLICATION
addappid(274900)

-- MAIN APP DEPOTS / PACKAGES
addappid(274901, 1, "47c8c5de20728ea128cdeab1aa121023dff106b685758b185e46fcd7d1c269c3")
addappid(274902, 1, "031f83c3b63fdf937359c01d7f30c0aec97943e5582138cde41b688f4c423a07")
addappid(274903, 1, "01393a1f9722aa0693dfa21044ca3973ab8ddf9dc662e74be52249443d338caf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1021280)
