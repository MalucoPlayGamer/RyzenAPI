-- Lua provided by RyzenAPI
-- Game: Mahjong Match

-- MAIN APPLICATION
addappid(709610)
addappid(739460)
addappid(740700)

-- MAIN APP DEPOTS / PACKAGES
addappid(709611, 1, "b38db83e6b0cbd8870126414795ff50912711e0587257ff8e3977c6f01af752c")

