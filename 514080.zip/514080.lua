-- Lua provided by RyzenAPI
-- Game: 514080

-- MAIN APPLICATION
addappid(514080)
-- Game: addappid(514080)

-- MAIN APP DEPOTS / PACKAGES
addappid(514081, 1, "846dd332e98ec07c58b268b468ff7d0621d116790bda67ff6753e0d774bc1f12")
