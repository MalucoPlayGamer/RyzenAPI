-- Lua provided by RyzenAPI
-- Game: Deadly Dozen

-- MAIN APPLICATION
addappid(514080)

-- MAIN APP DEPOTS / PACKAGES
addappid(514081, 1, "846dd332e98ec07c58b268b468ff7d0621d116790bda67ff6753e0d774bc1f12")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
