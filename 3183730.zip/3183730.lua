-- Lua provided by RyzenAPI
-- Game: AppID 3183730

-- MAIN APPLICATION
addappid(3183730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3183731, 1, "7d199e7ef5e7ea1f9ae6d728a6d1525bb6a4f3a76bb4fa68113bf7ed5d5c9772")

