-- Lua provided by RyzenAPI
-- Game: Game: AppID 3183730

-- MAIN APPLICATION
addappid(3183730)
-- Game: addappid(3183730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183731, 1, "7d199e7ef5e7ea1f9ae6d728a6d1525bb6a4f3a76bb4fa68113bf7ed5d5c9772")
