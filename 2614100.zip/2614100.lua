-- Lua provided by RyzenAPI
-- Game: Demon's GunPlay 2

-- MAIN APPLICATION
addappid(2614100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614102,0,"f7ba0cd15f023873063928e9659bb277de991edc067238a1217dbc7eefd025a3")

