-- Lua provided by RyzenAPI
-- Game: Windward

-- MAIN APPLICATION
addappid(326410)

-- MAIN APP DEPOTS / PACKAGES
addappid(326411, 1, "e574308d6ff1d90a5adf0eaf57f11ea53411b2d1a1e9275b337045e5e7ce53ae")
addappid(326412, 1, "c2801ba071f327aa42e8fe030f839f51a536b53bdaeae6763b32b3c79d58f0e5")
addappid(326413, 1, "44e126b9a3e9ce339654a618aa066852012886059e099439f70ed3c951e92a0b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
