-- Lua provided by RyzenAPI
-- Game: AppID 376130

-- MAIN APPLICATION
addappid(376130)

-- MAIN APP DEPOTS / PACKAGES
addappid(376131, 1, "35878e30c2e012e3fd8ee014134fc0c4951c2e8fedef1140afb8b9a2b72694d4")

