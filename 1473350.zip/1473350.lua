-- Lua provided by RyzenAPI
-- Game: addappid(1473350)

-- MAIN APPLICATION
addappid(1473350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473352,0,"78b0dc40ddc455179463c1a0c16324a3c7cdea3a3ce1ebff37f012d1346cf632")
