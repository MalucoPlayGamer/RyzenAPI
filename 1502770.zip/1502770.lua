-- Lua provided by RyzenAPI
-- Game: Re;Lord 2 ~The witch of Cologne and black cat~

-- MAIN APPLICATION
addappid(1502770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502771, 1, "fa19732b9e56f67067eb6f880ed8cf1c1ebcc65ee1f2eae85cd886bf3bee4463")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
