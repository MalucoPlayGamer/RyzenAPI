-- Lua provided by RyzenAPI
-- Game: 1502770

-- MAIN APPLICATION
addappid(1502770)
-- Game: addappid(1502770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502771, 1, "fa19732b9e56f67067eb6f880ed8cf1c1ebcc65ee1f2eae85cd886bf3bee4463")
