-- Lua provided by RyzenAPI
-- Game: Hotel Ever After - Ella's Wish

-- MAIN APPLICATION
addappid(1014010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014011, 1, "ccd6309bbe475a4c66027778dac797ba6fe2c52c315ea29d58af158cd2ade640")
addappid(1014012, 1, "eeb37becd94341d1de969feb368a760ba5dc8adfe713c9e3eefc41c2f2384763")
