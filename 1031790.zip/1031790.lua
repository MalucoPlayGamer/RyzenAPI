-- Lua provided by RyzenAPI
-- Game: 1031790

-- MAIN APPLICATION
addappid(1031790)
-- Game: addappid(1031790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031791, 1, "205550fc993da46d70970619c97b1edf140503581b07e36f05fb1aeb0dddad70")
