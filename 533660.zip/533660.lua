-- Lua provided by RyzenAPI
-- Game: Ziggy's Chase

-- MAIN APPLICATION
addappid(533660)

-- MAIN APP DEPOTS / PACKAGES
addappid(533661, 1, "b7fa7ce7faa6091494e741dade45e4e7daf174e6212e3a71e2da2efab3f16592")
addappid(533662, 1, "a9f6ed804e12b3148a604de90c2ef7f7ab2c374c9316e34ccf8e80e7e36d98c4")
