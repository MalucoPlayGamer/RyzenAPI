-- Lua provided by RyzenAPI
-- Game: Olija Demo

-- MAIN APPLICATION
addappid(1357260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357261, 1, "f581cbd83d8f0d9f4830691244e2f7e3c17fd13c89b48a4c735252dd42c73680")
