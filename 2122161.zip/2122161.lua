-- Lua provided by RyzenAPI
-- Game: addappid(2122161)

-- MAIN APPLICATION
addappid(2122161)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122161,0,"df33b2933ad1bd5bc9c599606ce8bb823904b97efa68f4c095d8c56f10558235")
