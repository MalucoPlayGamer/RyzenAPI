-- Lua provided by RyzenAPI 
-- Game: AppID 976020
addappid(976020)
addappid(976021, 1, "7bb103c07928e0f1b09829d3e9a1b94d7c5ea0d243f476038b6c06fa4630341e")
addappid(976022, 1, "b08171beb436df76c77b0b540ce3e04f71c70f32f756e7afd5d2806d914f4293")
