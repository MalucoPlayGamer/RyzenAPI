-- Lua provided by RyzenAPI
-- Game: AppID 976020

-- MAIN APPLICATION
addappid(976020)

-- MAIN APP DEPOTS / PACKAGES
addappid(976021, 1, "7bb103c07928e0f1b09829d3e9a1b94d7c5ea0d243f476038b6c06fa4630341e")
addappid(976022, 1, "b08171beb436df76c77b0b540ce3e04f71c70f32f756e7afd5d2806d914f4293")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
