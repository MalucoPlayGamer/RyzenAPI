-- Lua provided by RyzenAPI 
-- Game: Smashing The Battle VR
addappid(625770)
addappid(625771, 1, "69fd9e1e0b141a2250b0607fb0e79557fed8859687390d47ff5506a1335be1f6")
