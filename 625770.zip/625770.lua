-- Lua provided by RyzenAPI
-- Game: Smashing The Battle VR

-- MAIN APPLICATION
addappid(625770)

-- MAIN APP DEPOTS / PACKAGES
addappid(625771, 1, "69fd9e1e0b141a2250b0607fb0e79557fed8859687390d47ff5506a1335be1f6")

