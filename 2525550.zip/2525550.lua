-- Lua provided by RyzenAPI
-- Game: They Linger

-- MAIN APPLICATION
addappid(2525550)
-- Game: addappid(2525550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525552,0,"3dcf95a08b5c3f15f41e2f56270270a4977d3f31a87ad7048e28602cd54b29d7")
addappid(2525553,0,"a3c910d11825176053ff655381f4ebbab41ac6f267f71b30c0ed8fcc3b18c109")
