-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1389660)
-- Game: addappid(1389660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389662,0,"35d02d254ca3ff734ce00ca68b521e1abe591451d800a88fb0bda362998237f6")
