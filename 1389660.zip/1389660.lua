-- Lua provided by RyzenAPI
-- Game: addappid(1389660)

-- MAIN APPLICATION
addappid(1389660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389662,0,"35d02d254ca3ff734ce00ca68b521e1abe591451d800a88fb0bda362998237f6")
