-- Lua provided by RyzenAPI
-- Game: World left Behind

-- MAIN APPLICATION
addappid(1139200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1139201, 1, "75373b7fbea2a50ffb6ed400617e64e3132c0c7f5376bb63bde3a980e0b5fa19")

