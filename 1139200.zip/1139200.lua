-- Lua provided by RyzenAPI 
-- Game: World left Behind
addappid(1139200)
addappid(1139201, 1, "75373b7fbea2a50ffb6ed400617e64e3132c0c7f5376bb63bde3a980e0b5fa19")
