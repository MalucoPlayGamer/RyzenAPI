-- Lua provided by RyzenAPI
-- Game: ZOOMnBOOM

-- MAIN APPLICATION
addappid(870580)

-- MAIN APP DEPOTS / PACKAGES
addappid(870581, 1, "5dbb7b83f315cf313fb76db2b6ad92a72dbbe2ae9a95e85ecd181f76980908fc")

