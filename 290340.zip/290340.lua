-- Lua provided by RyzenAPI
-- Game: Armello

-- MAIN APPLICATION
addappid(290340)
addappid(386790)
addappid(386791)
addappid(386792)
addappid(386793)
addappid(386794)
addappid(386795)
addappid(386796)
addappid(386797)
addappid(386798)
addappid(389600)
addappid(392980)
addappid(398910)
addappid(398912)
addappid(398913)
addappid(398915)
addappid(398916)
addappid(398917)
addappid(1130630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(290341, 1, "a1e7a0b11d26c74b6c24b9f9a55de12fe9530baa54fbf19dd618987f7e3bd603")
addappid(290342, 1, "aa9bbcf81c1c9a2894a0add20da0004fb55bd5eba24248eea1404ee1fb0d8e5c")
addappid(290343, 1, "72647fe1a4d05d3b53998b02b9ab1bd8aa70e602eca5abf0027a4bdf56b2d5f5")
addappid(290344, 1, "d6f4e3183139b1b418569f25c23e3f95cf91d2ec8630eb0f400c86955f8d106f")
addappid(290345, 1, "146349c137a78d57c3054fde301f08848b0d6e040b656e3dc7d27285a07bb585")
addappid(290346, 1, "7b3f1459a666d7ddede8455a93ceb4fff5d256de45c725eb2bbf08e4244628b3")

