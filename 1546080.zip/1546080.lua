-- Lua provided by RyzenAPI
-- Game: Every Day We Fight

-- MAIN APPLICATION
addappid(1546080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546081, 1, "a1deb6924446e24067ddd54182a17afd712d11b015038c0d9fff1195f5a68ddd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
