-- Lua provided by SkyAPI 
-- Game: Every Day We Fight
addappid(1546080)
addappid(1546081, 1, "a1deb6924446e24067ddd54182a17afd712d11b015038c0d9fff1195f5a68ddd")
