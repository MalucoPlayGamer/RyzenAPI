-- Lua provided by RyzenAPI
-- Game: 1546080

-- MAIN APPLICATION
addappid(1546080)
-- Game: addappid(1546080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546081, 1, "a1deb6924446e24067ddd54182a17afd712d11b015038c0d9fff1195f5a68ddd")
