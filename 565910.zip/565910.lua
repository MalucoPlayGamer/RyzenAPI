-- Lua provided by RyzenAPI
-- Game: Trainscape

-- MAIN APPLICATION
addappid(565910)

-- MAIN APP DEPOTS / PACKAGES
addappid(565911,0,"6a1f55fdbff4cc437372d089dd1ebeab9a847c3f80d631f2564711c3ea0157be")

