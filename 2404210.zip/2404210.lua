-- Lua provided by RyzenAPI
-- Game: Game: RedRaptor

-- MAIN APPLICATION
addappid(2404210)
-- Game: addappid(2404210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404211, 1, "59d02f48911a6ef05482ea3f4ebbef39897acb53ee808067605cc8f4d614ca8f")
