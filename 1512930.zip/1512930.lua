-- Lua provided by RyzenAPI
-- Game: A House of Thieves Demo

-- MAIN APPLICATION
addappid(1512930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512931, 1, "2737c2ab730942f374b6d2ef4f992ea6ac9f2f3448bcbe06c72e1fdbc62f482b")

