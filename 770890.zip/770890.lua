-- Lua provided by RyzenAPI
-- Game: Web of Deceit: Deadly Sands Collector's Edition

-- MAIN APPLICATION
addappid(770890)

-- MAIN APP DEPOTS / PACKAGES
addappid(770891,0,"e2d5ae89f1730c64845a24f0d077d79cf6bdc241514833ce37f89b4b256c7e78")

