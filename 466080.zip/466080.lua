-- Lua provided by RyzenAPI
-- Game: Surface: The Pantheon Collector's Edition

-- MAIN APPLICATION
addappid(466080)

-- MAIN APP DEPOTS / PACKAGES
addappid(466081, 1, "d0d7baa5252d19f4e6089bb05abd3ac8f0bde8bb7ab13111d0a4862ef7a32be6")

