-- Lua provided by RyzenAPI 
-- Game: AppID 466080
addappid(466080)
addappid(466081, 1, "d0d7baa5252d19f4e6089bb05abd3ac8f0bde8bb7ab13111d0a4862ef7a32be6")
