-- Lua provided by RyzenAPI
-- Game: addappid(625980)

-- MAIN APPLICATION
addappid(625980)

-- MAIN APP DEPOTS / PACKAGES
addappid(625981, 1, "a218a3ed8eaaec48863a9b1d92933a3e83cf6ce4ab9bee65022553f7c8ab2f38")
addappid(711860, 0, "ac4c68f5717ac741c29bd86da0a0bfc29cd313ba005e2169605b68f574d5d1a6")
