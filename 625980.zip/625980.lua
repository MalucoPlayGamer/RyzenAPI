-- Lua provided by RyzenAPI
-- Game: Yomawari: Midnight Shadows

-- MAIN APPLICATION
addappid(625980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(625981, 1, "a218a3ed8eaaec48863a9b1d92933a3e83cf6ce4ab9bee65022553f7c8ab2f38")
addappid(711860, 0, "ac4c68f5717ac741c29bd86da0a0bfc29cd313ba005e2169605b68f574d5d1a6")

