-- Lua provided by RyzenAPI
-- Game: AppID 570970

-- MAIN APPLICATION
addappid(570970)
-- Game: addappid(570970)

-- MAIN APP DEPOTS / PACKAGES
addappid(570971, 1, "c0f80c15d24ea0cb836fc7443de02cc438ddc0371b1e7db5b0d431a1ad081307")
addappid(697350, 0, "0795579af641585de663629bac5932ee7ce1052e7ba61f5f3b431947c08543cd")
addappid(747180, 0, "ffefaaaddc0a61f43b2ce2d8875f17c59bd5b44efdef1f489542f2aba4bf19a5")
addappid(868870, 0, "44db926f05507bef0ffd2ca2ac2192c9a1e2a67df476a33e22aa1d32673992c7")
