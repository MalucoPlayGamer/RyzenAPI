-- Lua provided by RyzenAPI
-- Game: 弥留 Demo

-- MAIN APPLICATION
addappid(2551130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551131, 1, "ac798a13e03342c58b4a82a00d5834b862288b3ede4b3c190500d6feb01edf24")

