-- Lua provided by SkyAPI 
-- Game: AppID 2551130
addappid(2551130)
addappid(2551131, 1, "ac798a13e03342c58b4a82a00d5834b862288b3ede4b3c190500d6feb01edf24")
