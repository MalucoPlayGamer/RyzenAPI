-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Card Audio Starter Pack

-- MAIN APPLICATION
addappid(3336480)
-- Game: addappid(3336480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336480,0,"197961bd3ac3bf68dd658ce5605b8ee30e08432d7d3f6c7fa06dd83a999ca482")
