-- Lua provided by RyzenAPI
-- Game: Game: RESEARCH and DESTROY

-- MAIN APPLICATION
addappid(1279310)
-- Game: addappid(1279310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279311, 1, "3069ad919e387f6c4f2f63c16649847bdf093e43bf777fe181cc7f0fe4302bce")
