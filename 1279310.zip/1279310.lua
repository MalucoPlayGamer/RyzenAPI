-- Lua provided by RyzenAPI
-- Game: RESEARCH and DESTROY

-- MAIN APPLICATION
addappid(1279310)
addappid(1479290)
addappid(1479291)
addappid(1555690)
addappid(1555691)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1279311, 1, "3069ad919e387f6c4f2f63c16649847bdf093e43bf777fe181cc7f0fe4302bce")

