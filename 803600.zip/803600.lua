-- Lua provided by RyzenAPI
-- Game: AppID 803600

-- MAIN APPLICATION
addappid(803600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(803601, 1, "43fe05a18369739b01155c0e077828682e79f87bdc198e9dc869b9383869956b")
addappid(803610, 1, "f85198db274ff5aa83b02f72492c4f6d119bf44323b19e76f98d174295e889e6")

