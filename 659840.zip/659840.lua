-- Lua provided by RyzenAPI
-- Game: AppID 659840

-- MAIN APPLICATION
addappid(659840)
-- Game: addappid(659840)

-- MAIN APP DEPOTS / PACKAGES
addappid(659841, 1, "e1b1561472dd7d3fa398c302b36f6fa58f8e0d99aeb5eb70beb3f2fbeb76b745")
addappid(659842, 1, "440e48f12b6a195bc972da63401485213cbe0b7f4d4a819f9ca59aec950f0a43")
addappid(659843, 1, "b4006eaeb445655ef24fd9131d3dc6a97d76440df3c9b35eef559da21aaadb62")
