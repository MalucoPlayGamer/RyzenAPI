-- Lua provided by RyzenAPI
-- Game: 1899280

-- MAIN APPLICATION
addappid(1899280)
-- Game: addappid(1899280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899281, 1, "b56a4a3d8bb774802fc07218429c0d678a09e9f90f4d777be8e1656dc8486a6e")
