-- Lua provided by RyzenAPI
-- Game: Cardboard Town Demo

-- MAIN APPLICATION
addappid(2301910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301911, 1, "71504bf18b7605c689f2a8c9384ef2b8934dc2d1fcfd4377bb8870e9ddabb71d")

