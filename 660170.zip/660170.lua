-- Lua provided by RyzenAPI
-- Game: Haunted Hotel: Stay in the Light

-- MAIN APPLICATION
addappid(660170)

-- MAIN APP DEPOTS / PACKAGES
addappid(660171,0,"bb0f710f264b920afb4bbe34d70b87701cdeae1f338fbd55c8f1ab67e6ae81ad")

