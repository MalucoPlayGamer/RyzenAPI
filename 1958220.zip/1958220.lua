-- Lua provided by SkyAPI 
-- Game: WitchSpring R
addappid(1958220)
addappid(1958221, 1, "f4ac13aa686b816d6d28b882d301090c4eb3b9aa14c6802a398402367dc1f612")
