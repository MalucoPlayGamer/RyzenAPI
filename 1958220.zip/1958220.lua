-- Lua provided by RyzenAPI
-- Game: WitchSpring R

-- MAIN APPLICATION
addappid(1958220)
-- Game: addappid(1958220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958221, 1, "f4ac13aa686b816d6d28b882d301090c4eb3b9aa14c6802a398402367dc1f612")
