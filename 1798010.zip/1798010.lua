-- Lua provided by RyzenAPI
-- Game: Game: Mega Man Battle Network Legacy Collection Vol. 1

-- MAIN APPLICATION
addappid(1798010)
-- Game: addappid(1798010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798011, 1, "f335202577fd5aab93465e55b2615c01d000af76e2c0abe8cbf3e332a5b7144f")
