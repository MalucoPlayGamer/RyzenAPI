-- Lua provided by RyzenAPI
-- Game: Mega Man Battle Network Legacy Collection Vol. 1

-- MAIN APPLICATION
addappid(1798010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798011, 1, "f335202577fd5aab93465e55b2615c01d000af76e2c0abe8cbf3e332a5b7144f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1981410)
