-- Lua provided by RyzenAPI
-- Game: Causal Loop

-- MAIN APPLICATION
addappid(3374460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374461,0,"0fb7b17d4aaa03da2a0b8a57fc7073f9f90fb3b7db43738a88addc8b9bc2fc9f")

