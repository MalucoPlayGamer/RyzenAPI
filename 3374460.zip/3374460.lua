-- Lua provided by RyzenAPI
-- Game: Causal Loop

-- MAIN APPLICATION
addappid(3374460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374461,0,"0fb7b17d4aaa03da2a0b8a57fc7073f9f90fb3b7db43738a88addc8b9bc2fc9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
