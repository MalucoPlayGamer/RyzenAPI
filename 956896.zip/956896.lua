-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956896)

-- MAIN APP DEPOTS / PACKAGES
addappid(956896,0,"2f6c110f0d7536791edc582315307bd16d078f0fea5b9b4c61d650216c82fcfd")

