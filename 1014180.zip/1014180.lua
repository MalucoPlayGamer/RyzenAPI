-- Lua provided by RyzenAPI
-- Game: Game: AppID 1014180

-- MAIN APPLICATION
addappid(1014180)
-- Game: addappid(1014180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014181, 1, "5b0bf52f786bd61a8437a692c3e45bc569576ff8b4ba590322901e81e9d78026")
