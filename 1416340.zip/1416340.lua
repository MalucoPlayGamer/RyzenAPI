-- Lua provided by RyzenAPI
-- Game: Game: Impostor Inside Us

-- MAIN APPLICATION
addappid(1416340)
-- Game: addappid(1416340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416341, 1, "9cb00e68469f4e1529a28e133d815fee2cb93ebd73b013f924ce76ead2b6e3e8")
