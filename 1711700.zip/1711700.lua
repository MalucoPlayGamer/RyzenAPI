-- Lua provided by RyzenAPI
-- Game: addappid(1711700)

-- MAIN APPLICATION
addappid(1711700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711701, 1, "7cff0aa7ddd7f6dd111ab144d932d6872f58d96793a24a0acf5ff8ba28482b5a")
