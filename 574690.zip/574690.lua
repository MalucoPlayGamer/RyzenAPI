-- Lua provided by RyzenAPI 
-- Game: Triangle
addappid(574690)
addappid(574691, 1, "70ea565bb45e07eea68ce8b4848211544b197bf03c6af51dfc6987e83a4817c6")
