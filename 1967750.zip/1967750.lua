-- Lua provided by SkyAPI 
-- Game: Iron Jaw
addappid(1967750)
addappid(1967751, 1, "c37120848660292850ed1737a63855e514a60a961237480ce0d8d65d253ce0a1")
