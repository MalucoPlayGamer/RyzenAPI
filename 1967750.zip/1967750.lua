-- Lua provided by RyzenAPI
-- Game: Iron Jaw

-- MAIN APPLICATION
addappid(1967750)
-- Game: addappid(1967750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967751, 1, "c37120848660292850ed1737a63855e514a60a961237480ce0d8d65d253ce0a1")
