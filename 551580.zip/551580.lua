-- Lua provided by RyzenAPI
-- Game: AppID 551580

-- MAIN APPLICATION
addappid(551580)

-- MAIN APP DEPOTS / PACKAGES
addappid(551581, 1, "02c0ff9ff31ec698de72c4ab23b88ee6ec08562b335a3823d4185f7203b8c32d")
addappid(551582, 1, "68a9f095adfaae79078d9c5b5ee86ba3c4592fd79b3b74717e0b9ce0617005fc")
addappid(551585, 1, "091a11f7397e039840fc0c037bf6d499ba894bfe0f2890ed9e9e5816f7d6260a")
addappid(551587, 1, "ce3bd75fb13188756f9da4f63794ecccb35c894144c82c9aad9275d6b87f7a40")
addappid(551588, 1, "e2d772446c9f8eb7d2ba2b4f032840525d63f5f8b3723256b584e8b82317221d")
addappid(1111900, 0, "99d180ae75ac6c0f45b9d27a0cbae18a1f7b7a0c20ce8cdf013801bbb5f72e78")
addappid(1111902, 0, "d2bb0309280e5ba6302e0111b7210627ae356ada77d5badefca7863359d66570")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
