-- Lua provided by RyzenAPI
-- Game: 2423530

-- MAIN APPLICATION
addappid(2423530)
-- Game: addappid(2423530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423532,0,"69cf49f0da4aaccdf315fa40acb21b08f198328b8b52477bf601bfdfb5bd99dc")
addappid(2423533,0,"b4ad3f1b0747bc4c9e4684999a994e4c04ce1960f0718afbd455f7559d696751")
