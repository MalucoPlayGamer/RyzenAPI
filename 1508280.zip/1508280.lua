-- Lua provided by RyzenAPI
-- Game: addappid(1508280)

-- MAIN APPLICATION
addappid(1508280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508281, 1, "d59618e52a67be17ed0019e3ee40b38b604844ca72e271bbacdc5fbfb03f603f")
