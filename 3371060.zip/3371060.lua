-- Lua provided by RyzenAPI
-- Game: Keyclash

-- MAIN APPLICATION
addappid(3371060)
-- Game: addappid(3371060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371061, 1, "f97ec6ce56e2dbfab81791fe8aa7e26d2ba18dcb2b53e670b0f4e1fdbfa4d4b4")
