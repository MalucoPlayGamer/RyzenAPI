-- Lua provided by RyzenAPI
-- Game: addappid(956706)

-- MAIN APPLICATION
addappid(956706)

-- MAIN APP DEPOTS / PACKAGES
addappid(956706,0,"7bf13137ec29cd68df774933b81828520eef4c7bdae11388973b392b5d2cac7f")
