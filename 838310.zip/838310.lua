-- Lua provided by RyzenAPI
-- Game: addappid(838310)

-- MAIN APPLICATION
addappid(838310)

-- MAIN APP DEPOTS / PACKAGES
addappid(838311, 1, "72aa46d79ba01711edd6facabfdc3181da46456897e9a51a04618cbdc04878d3")
