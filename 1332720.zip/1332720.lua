-- Lua provided by RyzenAPI
-- Game: Thief Simulator 2

-- MAIN APPLICATION
addappid(1332720)
addappid(3027860)
-- Game: addappid(1332720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332721, 1, "fa8baa603d576daf280269ec6d1581afea7eb9d1940f593ff8d3bbfb78339e14")
