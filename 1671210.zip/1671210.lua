-- Lua provided by RyzenAPI
-- Game: DELTARUNE

-- MAIN APP DEPOTS / PACKAGES
addappid(1671210, 1, "6629fad6c9567402765959ebaa51e3dbf2b29f1d250f1c8bc7a757d1afcc96fe") -- DELTARUNE
addappid(1671212, 1, "d3b68663ee177c37ee1d5cb49de06cbf9d0d81b2b72ffdde18665f6db6c6ed9f") -- Depot 1671212
addappid(1671213, 1, "06e8fc629b33851989bebbd53c9e8acde2444b4c75fbf43036e586cc4bc6b1a5") -- Depot 1671213
