-- Lua provided by RyzenAPI 
-- Game: Shadow Vault
addappid(2633490)
addappid(2633491, 1, "cb9170d4ca4bd047cc404fecf858a45f5c959253a7b146dc08c0b1de3b68b2e7")
addappid(2633492, 1, "6bc3c4c5447d2e480f961e8ea173f7962e87450ff49097737047990dbd49465a")
