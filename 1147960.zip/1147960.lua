-- Lua provided by RyzenAPI
-- Game: 1147960

-- MAIN APPLICATION
addappid(1147960)
-- Game: addappid(1147960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147961, 1, "90f9a006c81969fbee614d43b5624276a3d22b212cb0dcca2dab25ec6e109fab")
