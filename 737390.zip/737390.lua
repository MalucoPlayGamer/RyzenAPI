-- Lua provided by RyzenAPI
-- Game: Batch 17

-- MAIN APPLICATION
addappid(737390)

-- MAIN APP DEPOTS / PACKAGES
addappid(737391, 1, "89cf0188c5ac943263f02ce60ee9a2ef5f6aded17c70918d90eb2f226ed0e985")

