-- Lua provided by RyzenAPI
-- Game: addappid(1730240)

-- MAIN APPLICATION
addappid(1730240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730241, 1, "e408766189bdc33af4668feac12ff81c70483d4b1b33970ea39921aa49e613d2")
