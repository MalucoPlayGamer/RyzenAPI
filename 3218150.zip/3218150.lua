-- Lua provided by RyzenAPI 
-- Game: XENO WIPEOUT!
addappid(3218150)
addappid(3218151, 1, "7ff28dc8025a699a1295e23db5048650ec0227548f704748f5337adae18845a1")
