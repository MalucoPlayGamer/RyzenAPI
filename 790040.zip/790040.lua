-- Lua provided by RyzenAPI
-- Game: AppID 790040

-- MAIN APPLICATION
addappid(790040)

-- MAIN APP DEPOTS / PACKAGES
addappid(790041, 1, "665ceaaa29dc2cf699d9fc1e22d59ff1526e23d052f44982f5474d237cc492f7")

