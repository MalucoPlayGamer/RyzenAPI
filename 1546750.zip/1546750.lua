-- Lua provided by SkyAPI 
-- Game: Girl Next Door
addappid(1546750)
addappid(1546751, 1, "32e8852be203d1ec56fad92b225982abc6151dee42b87e7727b9d4378715f3c3")
addappid(1546752, 1, "db935389485008878f669df991174cc4ecc88384b86bf3802f47d8902a862f76")
