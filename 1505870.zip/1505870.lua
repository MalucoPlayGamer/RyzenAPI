-- Lua provided by RyzenAPI
-- Game: 1505870

-- MAIN APPLICATION
addappid(1505870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505870,0,"5a4463b46bff7f7e3437c5ec3f476a567d378bdddd47fdf08908bd92cee53c44")
