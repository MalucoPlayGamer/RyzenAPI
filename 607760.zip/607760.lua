-- Lua provided by RyzenAPI
-- Game: 607760

-- MAIN APPLICATION
addappid(607760)
-- Game: addappid(607760)

-- MAIN APP DEPOTS / PACKAGES
addappid(607761, 1, "b15a208ba0d14bbb6cbf3ff03a6fee720234f385d60e19407574a6f919f0ede4")
