-- Lua provided by RyzenAPI
-- Game: Conan Unconquered

-- MAIN APPLICATION
addappid(989690)
-- Game: addappid(989690)

-- MAIN APP DEPOTS / PACKAGES
addappid(989691, 1, "956c4557113dd14a719501a116a706462f4f803eb0a8582e64778d9064afd958")
addappid(1040880, 0, "45633e5d4790a11f81c368d60f9adcbef7416cb340112afec08a41a628340551")
