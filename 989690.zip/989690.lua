-- Lua provided by RyzenAPI
-- Game: Conan Unconquered

-- MAIN APPLICATION
addappid(989690)
addappid(989700)
addappid(1058250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(989691, 1, "956c4557113dd14a719501a116a706462f4f803eb0a8582e64778d9064afd958")
addappid(1040880, 0, "45633e5d4790a11f81c368d60f9adcbef7416cb340112afec08a41a628340551")

