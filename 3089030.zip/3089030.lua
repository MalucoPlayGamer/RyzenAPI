-- Lua provided by RyzenAPI
-- Game: Game: Penguin Panic!

-- MAIN APPLICATION
addappid(3089030)
-- Game: addappid(3089030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089031, 1, "26f7d729c657567f3ec0547ea45170d8d1f96c70bdeff4969e77e5df0d6809e4")
