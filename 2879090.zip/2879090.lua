-- Lua provided by RyzenAPI
-- Game: Game: NYO-NIN-JIMA -My New Life in Charge of a Tropical Island-

-- MAIN APPLICATION
addappid(2879090)
-- Game: addappid(2879090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879091, 1, "d43b9987c03ad4a344d3476ea753b623e25f821017b9c39e21c35bd42fe3a13f")
