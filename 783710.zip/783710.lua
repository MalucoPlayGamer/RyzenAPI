-- Lua provided by RyzenAPI
-- Game: Game: Virtual Desktop Dashboard

-- MAIN APPLICATION
addappid(783710)
-- Game: addappid(783710)

-- MAIN APP DEPOTS / PACKAGES
addappid(783711, 1, "033f19bf2c9ba42ce48dc01e8129ccf0527987b45719b229f4c1659d62ff62b1")
