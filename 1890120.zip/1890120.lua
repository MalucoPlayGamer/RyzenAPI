-- Lua provided by RyzenAPI
-- Game: 9-nine-:NewEpisode

-- MAIN APPLICATION
addappid(1890120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890121, 1, "70d81f6013bd328e1b95167e49b166cc529cc4310f03c7c8a7206c5d2fbc6790")