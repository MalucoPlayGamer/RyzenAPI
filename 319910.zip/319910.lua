-- Lua provided by RyzenAPI
-- Game: Trine 3: The Artifacts of Power

-- MAIN APPLICATION
addappid(319910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(319911, 1, "cca12574c309b85162a4ac9c0ebb1de487fd564dec12d29b5cac30f0cc9c0428")
addappid(319912, 1, "71ae9bf5ad57237b662930bdcb1753cc68e93bd59c5973448446a2b0392c6cd6")
addappid(319913, 1, "2bbdfdd8c7e9805276dcc2f721cf8cbf400da02dc8be7e666d6272c8fea6b3dc")

