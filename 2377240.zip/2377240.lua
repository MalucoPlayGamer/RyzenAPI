-- Lua provided by RyzenAPI
-- Game: SEX Room 2 [18+]

-- MAIN APPLICATION
addappid(2377240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377241, 1, "bc128c2a7f20a3a162e2c782269a34a6350edf2f71f72ad5a72c13b12ec9d169")
