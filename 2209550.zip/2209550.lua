-- Lua provided by RyzenAPI
-- Game: Disfigure: Prologue

-- MAIN APPLICATION
addappid(2209550)
-- Game: addappid(2209550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209551, 1, "a0b0d785dfc869da273c6b4a402609da1d3aaf1f2f7c6a85624a7f166a1771d1")
