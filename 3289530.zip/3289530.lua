-- Lua provided by RyzenAPI
-- Game: addappid(3289530)

-- MAIN APPLICATION
addappid(3289530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289531, 1, "8fb61cf6ba672f673cc3b1293fa6255fbc81f894ac04366b37b1af09fe6e77a1")
