-- Lua provided by RyzenAPI
-- Game: addappid(915653)

-- MAIN APPLICATION
addappid(915653)

-- MAIN APP DEPOTS / PACKAGES
addappid(915653,0,"f4d7ce28654d4eb027b54a4a5af96302e5d0fd54831610471f82d1e4976ac8d5")
