-- Lua provided by RyzenAPI
-- Game: addappid(3263900)

-- MAIN APPLICATION
addappid(3263900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263901, 1, "750855c906522bbd8e5f250d8ef3ca65be4925125d4b414c8e169547dd01fa33")
