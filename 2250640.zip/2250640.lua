-- Lua provided by RyzenAPI
-- Game: Pizza Tower Soundtrack

-- MAIN APPLICATION
addappid(2250640)
-- Game: addappid(2250640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250641, 1, "827084d8dbac504690f000cfa0620f41bf6e18bbe5c3b5818ca2c25a11d1864b")
