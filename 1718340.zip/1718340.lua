-- Lua provided by RyzenAPI
-- Game: 极简地牢 Simple Killer

-- MAIN APPLICATION
addappid(1718340)
addappid(1718343)
-- Game: addappid(1718340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718344,0,"00289852e2808c796afb8af74a69d79d4acf02a0d73c78483f611c727856192b")
