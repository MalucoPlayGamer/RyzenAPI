-- Lua provided by RyzenAPI
-- Game: Blades of Jianghu: Ballad of Wind and Dust - Digital Artbook-

-- MAIN APPLICATION
addappid(2401190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401190,0,"1bbf108ee4182858d51bbe8f1ad59e1ecfb5925db681399ce5138ff4a3861316")

