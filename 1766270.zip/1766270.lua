-- Lua provided by RyzenAPI
-- Game: Join Rush Attack / 加入突袭

-- MAIN APPLICATION
addappid(1766270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766271, 1, "32aba604dcebe3d8b5724a6f9d3ce53d7e99b896958a105ed24a3a754c08bcc0")

