-- Lua provided by RyzenAPI
-- Game: Snufkin: Melody of Moominvalley - Soundtrack

-- MAIN APPLICATION
addappid(2782670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782671, 1, "5ce1e48317e3ba991712e413fab68d8c5da23e3c9c706d5ec6c5e34c8ae8fb1e")
addappid(2782672, 1, "a7cbef427b2dd4286c163bfb8d5a2a6ab98894ec54a69499cf82d4f4d338da30")
