-- Lua provided by RyzenAPI
-- Game: AppID 1842810

-- MAIN APPLICATION
addappid(1842810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842811, 1, "45813a348477949c95bcc99acb76af79586f80853c6b91069277c1bd5e82f3e0")
addappid(1912160, 0, "b8db1256184134521d31218a1ed50c22938ca4f38113849332c687d7c43fc784")
addappid(1933920, 0, "8ae22f1e8d887984debd24bb0b384bab5d1ff1824e4f44dffb0b28a3520d8621")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
