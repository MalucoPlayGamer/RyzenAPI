-- Lua provided by RyzenAPI
-- Game: VEGAS Edit 20 Steam Edition

-- MAIN APPLICATION
addappid(2070990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070991, 1, "aaf1c41f588cb7336f830f5ea0edc3e2a6f34cb0cf57234598c8064392c335ec")

