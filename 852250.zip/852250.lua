-- Lua provided by RyzenAPI
-- Game: addappid(852250)

-- MAIN APPLICATION
addappid(852250)

-- MAIN APP DEPOTS / PACKAGES
addappid(852252,0,"2e0c2a46ecdb9ad5baf4b32804fc9bef8dbfc72ac0ce0c1523d9f06947813e50")
