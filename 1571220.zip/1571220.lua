-- Lua provided by RyzenAPI
-- Game: Chessplosion

-- MAIN APPLICATION
addappid(1571220)
-- Game: addappid(1571220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571221, 1, "29829824b211c320f4514103e164cedbdae7cea5ceddf86328da22acfe55d011")
