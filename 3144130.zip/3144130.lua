-- Lua provided by SkyAPI 
-- Game: Pitty Meaty
addappid(3144130)
addappid(3144131, 1, "b39d4c506255c3a6428a1a433d2c9e81d6f2ad057560328e659d096e69e485eb")
