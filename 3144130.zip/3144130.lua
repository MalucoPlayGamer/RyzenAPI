-- Lua provided by RyzenAPI
-- Game: Pitty Meaty

-- MAIN APPLICATION
addappid(3144130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144131, 1, "b39d4c506255c3a6428a1a433d2c9e81d6f2ad057560328e659d096e69e485eb")
