-- Lua provided by RyzenAPI
-- Game: addappid(1347430)

-- MAIN APPLICATION
addappid(1347430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347431, 1, "bfda7d558e3a0b47fc39152cf52af735b97213126d9449c716c86254e19e475f")
