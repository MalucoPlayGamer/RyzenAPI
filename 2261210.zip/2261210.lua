-- Lua provided by RyzenAPI
-- Game: addappid(2261210)

-- MAIN APPLICATION
addappid(2261210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261213,0,"ec9e4d08093a59c4398d07205d76922e0ba60a05a308b0b395ef38956fefcae9")
