-- Lua provided by SkyAPI 
-- Game: Disney Dreamlight Valley
addappid(1401590)
addappid(1401591, 1, "d99c609dc11544c08f0a832afd94357653d3f924cc683c27394cf548b1c3d161")
