-- Lua provided by RyzenAPI
-- Game: Disney Dreamlight Valley

-- MAIN APPLICATION
addappid(1401590)
addappid(2061640)
addappid(2061641)
addappid(2632050)
addappid(2632060)
addappid(3259120)
addappid(3311890)
addappid(3311900)
addappid(3311910)
addappid(3979520)
addappid(3979530)
addappid(4127920)
addappid(4127930)
addappid(4376930)
addappid(4941320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1401591, 1, "d99c609dc11544c08f0a832afd94357653d3f924cc683c27394cf548b1c3d161")

