-- Lua provided by RyzenAPI
-- Game: Game: Disney Dreamlight Valley

-- MAIN APPLICATION
addappid(1401590)
-- Game: addappid(1401590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401591, 1, "d99c609dc11544c08f0a832afd94357653d3f924cc683c27394cf548b1c3d161")
