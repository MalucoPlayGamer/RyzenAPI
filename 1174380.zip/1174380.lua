-- Lua provided by RyzenAPI
-- Game: AppID 1174380

-- MAIN APPLICATION
addappid(1174380)
addappid(1836370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174381, 1, "a48669d982f20af808acfde0734d4303bd5a5e169991ed3f8fc21642ef407f40")
addappid(1174382, 1, "55ad846c9e1792002d018fe5518236740eec9e0dfebe3bc0ff03300003d634af")
addappid(1174383, 1, "be5c133479ef4bc4f5f1206a9c71b6839f889d8ec8b7d7438b010d07c7beb6e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
