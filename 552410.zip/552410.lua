-- Lua provided by RyzenAPI
-- Game: Game: Project Abyss

-- MAIN APPLICATION
addappid(552410)
addappid(561130)
-- Game: addappid(552410)

-- MAIN APP DEPOTS / PACKAGES
addappid(552411, 1, "581a90f6e0b230afcd956629bc275a4a66e8ca21df314fdc0084f47d4a03a369")
addappid(552412, 1, "d51c368e3ced480f9a93d2eeebc085d63ae9d63ce7780f6cb0cea250a08a4e83")
