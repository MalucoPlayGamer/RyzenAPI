-- Lua provided by RyzenAPI 
-- Game: Night Janitor
addappid(1924710)
addappid(1924711, 1, "39c31f21561b22e1a73a33b0396b326f0cc588550fd98285a79fa19ea8f0bc84")
