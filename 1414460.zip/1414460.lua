-- Lua provided by RyzenAPI
-- Game: AppID 1414460

-- MAIN APPLICATION
addappid(1414460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414461, 1, "a1865e3e1dd1f9a5b6a6d5a03bc8577665c9ae398830d3f6a4cd5df87295d7af")
