-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Stalemate on Donets

-- MAIN APPLICATION
addappid(2349300)
-- Game: addappid(2349300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349300,0,"843117e804714b02cbd74381561512b01a2aae9aa981ec79f4e1b4a1c7a8fa3f")
