-- Lua provided by RyzenAPI
-- Game: CareUEyes - Blue Light Filter

-- MAIN APPLICATION
addappid(1796980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796981, 1, "5e90f6c35adb3752c858d3682414b9b124bc1cfbd9ed7499629068def850106b")

