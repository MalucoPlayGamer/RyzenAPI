-- Lua provided by RyzenAPI
-- Game: 4298510

-- MAIN APPLICATION
addappid(4298510)
-- Game: addappid(4298510)

-- MAIN APP DEPOTS / PACKAGES
addappid(4298511, 1, "a0efc29e5e729e52fe07f44b65d0f77e79e9ce1451cb4d7b9913c7aca162eeb0")
