-- Lua provided by RyzenAPI
-- Game: Game: Infuse VR

-- MAIN APPLICATION
addappid(2532240)
-- Game: addappid(2532240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532241, 1, "91f43232f40341d1efd5c76e1528d0709459184e046b4615b45fb7d3bfcaf830")
