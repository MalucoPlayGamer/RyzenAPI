-- Lua provided by RyzenAPI
-- Game: Game: Travellin Cats in Japan

-- MAIN APPLICATION
addappid(2700540)
-- Game: addappid(2700540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700541, 1, "c89565d035f219a8603727df1f68ba0e835799fce477d983264ce55227c0ba5d")
