-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Japan

-- MAIN APPLICATION
addappid(2700540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2700541, 1, "c89565d035f219a8603727df1f68ba0e835799fce477d983264ce55227c0ba5d")

