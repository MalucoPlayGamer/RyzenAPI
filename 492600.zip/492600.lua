-- Lua provided by RyzenAPI
-- Game: AppID 492600

-- MAIN APPLICATION
addappid(492600)

-- MAIN APP DEPOTS / PACKAGES
addappid(492601, 1, "c19e6b2dd9ffdd2db18fa2a04cdf7acc6a340e8a3b9df17fb95deb693035479d")
