-- Lua provided by RyzenAPI
-- Game: addappid(494230)

-- MAIN APPLICATION
addappid(494230)

-- MAIN APP DEPOTS / PACKAGES
addappid(494231, 1, "2b2146966b3eeb697d9d356dcde87d07fa85641d2d405618efaf9f452f7bb40f")
addappid(494232, 1, "6c848c2af2af6124550c234d5240c7e6c6b88bfe400be2bfab0c6cab4b357a1d")
addappid(498590, 0, "49ac2a97a7e36f3bf59ea6fb3fc1b4ad6d7425a41247a7fc8520ac523104ac3d")
