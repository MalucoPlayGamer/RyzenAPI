-- Lua provided by RyzenAPI
-- Game: Pink Explorer

-- MAIN APPLICATION
addappid(2092410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092411, 1, "86efa7e584e1c4c9d3055ca5512e98a4a2739a1ad7136148851f8bc666caacd6")

