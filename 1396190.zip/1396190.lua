-- Lua provided by RyzenAPI
-- Game: DE-EXIT - Eternal Matters

-- MAIN APPLICATION
addappid(1396190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396191, 1, "301eef8d8ff9399907515757dec6f053ea549c80edf06974e6a3b954714db276")

