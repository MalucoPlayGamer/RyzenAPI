-- Lua provided by RyzenAPI
-- Game: Game: Pampas & Selene: The Maze of Demons

-- MAIN APPLICATION
addappid(1966220)
-- Game: addappid(1966220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966221, 1, "ef568c960e90f1007e1251ae7d9e9448646e17ef3eb60f5782d881a5f07dcb6e")
