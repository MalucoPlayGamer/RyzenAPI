-- Lua provided by RyzenAPI 
-- Game: Pact with a witch
addappid(865570)
addappid(865571, 1, "aad46d3680de77cf52ac9b1dc6c46a5107dbfc35f8702df236808503ad58fec2")
