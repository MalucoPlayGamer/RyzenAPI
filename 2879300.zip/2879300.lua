-- Lua provided by RyzenAPI
-- Game: Game: Exosuit

-- MAIN APPLICATION
addappid(2879300)
-- Game: addappid(2879300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879301, 1, "7e50e9e775634fda3142a1d18f8c59b5cc47c40dd9aef18df597f49770e28eb9")
