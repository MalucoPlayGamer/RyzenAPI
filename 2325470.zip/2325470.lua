-- Lua provided by SkyAPI 
-- Game: Sorcerer's Choice: Angel or Demon?
addappid(2325470)
addappid(2325471, 1, "8d8adb1d05ed8a3db9d5baa442bc4be7b3b86238d715942295b568e403911b81")
addappid(2325472, 1, "f8df9b99eaa1c16b2365be7d59142fb4e1e9081a4815019e125bbcb348601a14")
