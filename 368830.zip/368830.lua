-- Lua provided by RyzenAPI
-- Game: 368830

-- MAIN APPLICATION
addappid(368830)
-- Game: addappid(368830)

-- MAIN APP DEPOTS / PACKAGES
addappid(368831, 1, "ba39c826ee90c40d4a908e56fcf90e2ad88621676317cbd9482be6d60cdce63d")
addappid(368832, 1, "602bca143bfa142f008beb6ee3ef55bac5f5a26c5a29f293cbf4b48622af42ec")
addappid(368833, 1, "c59da04abc1740868fa90371f27ff0f8f56e0da744204e7692803253624d8e9f")
addappid(430940, 0, "2950205743df5d4acbdb505fa0c88cd3dd161f0960fe5f4dce22ff21bdb63680")
