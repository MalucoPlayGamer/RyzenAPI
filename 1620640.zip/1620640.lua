-- Lua provided by SkyAPI 
-- Game: Noctambulant
addappid(1620640)
addappid(1620641, 1, "3c117fc3498ac25cee55c8513745e214ffd1abec73088584db56d0bf0290283b")
