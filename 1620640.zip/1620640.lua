-- Lua provided by RyzenAPI
-- Game: Noctambulant

-- MAIN APPLICATION
addappid(1620640)
-- Game: addappid(1620640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620641, 1, "3c117fc3498ac25cee55c8513745e214ffd1abec73088584db56d0bf0290283b")
