-- Lua provided by RyzenAPI
-- Game: 355680

-- MAIN APPLICATION
addappid(355680)
-- Game: addappid(355680)

-- MAIN APP DEPOTS / PACKAGES
addappid(355684,0,"57556fa2ec42229a6ea15fa1278452c5c1bc726c18579af0b5031cf0e0230c9d")
