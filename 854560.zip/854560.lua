-- Lua provided by RyzenAPI
-- Game: Game: AppID 854560

-- MAIN APPLICATION
addappid(854560)
-- Game: addappid(854560)

-- MAIN APP DEPOTS / PACKAGES
addappid(854561, 1, "6074f9b0fbd6b1d4c9fd9f8b6a5528ce9e4107f7479140b55de9de3c8ad2505f")
