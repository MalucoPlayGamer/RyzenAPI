-- Lua provided by RyzenAPI
-- Game: Frog story

-- MAIN APPLICATION
addappid(1555160)
-- Game: addappid(1555160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555161, 1, "4b19d78a599df846bfbd1dc487368d495876946e666e0218c89179354d91e4df")
