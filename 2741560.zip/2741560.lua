-- Lua provided by RyzenAPI
-- Game: SimCity™ 3000 Unlimited

-- MAIN APPLICATION
addappid(2741560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2741561, 1, "9d6b7b9c4e8115c01918ecfd6e9708f4c0819c81cab26a6574f453a68aa8e0dd")

