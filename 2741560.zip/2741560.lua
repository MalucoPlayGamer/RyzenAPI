-- Lua provided by RyzenAPI
-- Game: SimCity™ 3000 Unlimited

-- MAIN APPLICATION
addappid(2741560)
-- Game: addappid(2741560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741561, 1, "9d6b7b9c4e8115c01918ecfd6e9708f4c0819c81cab26a6574f453a68aa8e0dd")
