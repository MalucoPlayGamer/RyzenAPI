-- Lua provided by RyzenAPI
-- Game: Virtual Villagers: A New Home Demo

-- MAIN APPLICATION
addappid(16140)
-- Game: addappid(16140)

-- MAIN APP DEPOTS / PACKAGES
addappid(16141, 1, "efc3f8186f01e09a2a1e9a5d69e4a88680ddcc5145e85260cebaf1d0f5f9b5ba")
