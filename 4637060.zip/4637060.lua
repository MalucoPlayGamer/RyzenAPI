-- Lua provided by RyzenAPI
-- Game: The Underground Press

-- MAIN APPLICATION
addappid(4637060) -- The Underground Press
-- addappid(4637062) -- Depot 4637062 (empty depot)
-- addappid(4637063) -- Depot 4637063 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4637061, 1, "c1b55e2057166d4c4d44ec7877daf809d240d826e0ece4f3666dbf58ef8ce4ed") -- Depot 4637061

