-- Lua provided by RyzenAPI
-- Game: Game: AppID 3293550

-- MAIN APPLICATION
addappid(3293550)
-- Game: addappid(3293550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293551, 1, "cca5373dec7d2e739d961ddd0b010d502b2c049a191e5cea351e3db08fd49fa1")
