-- Lua provided by SkyAPI 
-- Game: AppID 3293550
addappid(3293550)
addappid(3293551, 1, "cca5373dec7d2e739d961ddd0b010d502b2c049a191e5cea351e3db08fd49fa1")
