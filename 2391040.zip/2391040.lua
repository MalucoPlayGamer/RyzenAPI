-- Lua provided by RyzenAPI
-- Game: 2391040

-- MAIN APPLICATION
addappid(2391040)
-- Game: addappid(2391040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391041, 1, "58b08be0c91aa690c6477090ac078de1b6c0679bbaff816d8a461fd694127b13")
