-- Lua provided by RyzenAPI
-- Game: addappid(972860)

-- MAIN APPLICATION
addappid(972860)

-- MAIN APP DEPOTS / PACKAGES
addappid(972860,0,"c580540adf1c5543b1c4391064c9df25687c8af499fb16ff9f92a1ee65660549")
