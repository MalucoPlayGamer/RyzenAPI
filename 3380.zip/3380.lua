-- Lua provided by RyzenAPI
-- Game: Dynomite Deluxe

-- MAIN APPLICATION
addappid(3380)
-- Game: addappid(3380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381, 1, "e86046dc6d1e1ed98b33dda786c2861a514c4e9cf0c8328a20938fb0f70a31ea")
