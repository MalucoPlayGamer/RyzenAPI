-- Lua provided by SkyAPI 
-- Game: AppID 3040760
addappid(3040760)
addappid(3040761, 1, "fc7431d730724e7a9b189c923a3683d555e23f6af2c6d302c158638d741358ff")
