-- Lua provided by SkyAPI 
-- Game: Neon Geometry Dash
addappid(2704460)
addappid(2704461, 1, "062a17ce1c50639c46f5836622735ee0a838fd1d811068c4fa0c8f87c9c63a14")
