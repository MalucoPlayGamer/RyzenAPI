-- Lua provided by RyzenAPI
-- Game: 2923130

-- MAIN APPLICATION
addappid(2923130)
addappid(2930000)
-- Game: addappid(2923130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923131, 1, "012305f5296d70552b81b1d4597e041c95ec90d9ac9b40b2a7fdb9ce3ea9f4d7")
