-- Lua provided by RyzenAPI
-- Game: 1598300

-- MAIN APPLICATION
addappid(1598300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598302,0,"ff7dfef00ddb2d3c64a6fe733baacde1b782b8f3db4ee0f832706af0824e381b")

