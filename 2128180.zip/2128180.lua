-- Lua provided by RyzenAPI
-- Game: 2128180

-- MAIN APPLICATION
addappid(2128180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128180,0,"81e49e6ffde01f30bed96aafefb35befa111b41a9e84c846f39b86b176105d24")

