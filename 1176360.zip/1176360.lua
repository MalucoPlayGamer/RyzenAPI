-- Lua provided by RyzenAPI
-- Game: AppID 1176360

-- MAIN APPLICATION
addappid(1176360)
-- Game: addappid(1176360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176361, 1, "4140802ce6d6c4ee0aea083b80cdacbd5c3e8179a021d26ddab4ae2776c64404")
