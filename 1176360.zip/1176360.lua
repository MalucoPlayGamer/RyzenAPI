-- Lua provided by SkyAPI 
-- Game: AppID 1176360
addappid(1176360)
addappid(1176361, 1, "4140802ce6d6c4ee0aea083b80cdacbd5c3e8179a021d26ddab4ae2776c64404")
