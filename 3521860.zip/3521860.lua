-- Lua provided by RyzenAPI
-- Game: 3521860

-- MAIN APPLICATION
addappid(3521860)
-- Game: addappid(3521860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3521861, 1, "ad72b1afd0ffbd442ab1437a9c0874efd5d6c08e1bf9c5920c79ee839f251af2")
