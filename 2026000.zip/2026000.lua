-- Lua provided by RyzenAPI
-- Game: 2026000

-- MAIN APPLICATION
addappid(2026000)
addappid(3983380)
-- Game: addappid(2026000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026001, 1, "84cc41d4a398837fe7ba525ebdccd5e5e3a671b5165418a1a88733b1dee4322c")
