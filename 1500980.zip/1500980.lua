-- Lua provided by RyzenAPI
-- Game: Doomsday Vault

-- MAIN APPLICATION
addappid(1500980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500981, 1, "b9ea9d745c2bb2e93310e6cad58457c3ae41bf5b1f078cdc498d0738085c8786")

