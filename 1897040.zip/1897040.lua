-- Lua provided by RyzenAPI
-- Game: SWAT Commander Demo

-- MAIN APPLICATION
addappid(1897040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897041, 1, "ab611d60c2973792456eb5ba507c3f8a2153567b7c308deb1edfb332c20d91f3")

