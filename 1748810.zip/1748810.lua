-- Lua provided by RyzenAPI
-- Game: Gamedec: The Official Guidebook

-- MAIN APPLICATION
addappid(1748810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748810,0,"de35bed7e8377b5a8e2688e0501008a066e04bf860e566c3ab802fdad0ab3a4e")

