-- Lua provided by RyzenAPI
-- Game: FlipWitch - Forbidden Sex Hex

-- MAIN APPLICATION
addappid(1748620)
-- Game: addappid(1748620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748621, 1, "576181678a4e491cb4a1e24e865c333a1299b03b6214413b78db4f51de0f1709")
