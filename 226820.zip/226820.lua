-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Ghost of Thornton Hall

-- MAIN APPLICATION
addappid(226820)
addappid(954090)

-- MAIN APP DEPOTS / PACKAGES
addappid(226821, 1, "c5a3f704a479259c9bf95fd0d32457cc30b226cda7c1bf06a791311838146c0f")

