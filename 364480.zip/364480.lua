-- Lua provided by SkyAPI 
-- Game: AppID 364480
addappid(364480)
addappid(364481, 1, "a969735b5ab5ead171baf122d14abda0f2d27b8eb2a6561d1e4303da3825645b")
