-- Lua provided by RyzenAPI
-- Game: 364480

-- MAIN APPLICATION
addappid(364480)
-- Game: addappid(364480)

-- MAIN APP DEPOTS / PACKAGES
addappid(364481, 1, "a969735b5ab5ead171baf122d14abda0f2d27b8eb2a6561d1e4303da3825645b")
