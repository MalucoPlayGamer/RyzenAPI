-- Lua provided by RyzenAPI
-- Game: Solenars Edge II: Champions

-- MAIN APPLICATION
addappid(1371350)
-- Game: addappid(1371350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371351, 1, "6c7a4b272c8fba7c5cbe4b7407d02d38e2473c7ade63cbcfae3d382da7b2418b")
