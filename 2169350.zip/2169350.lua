-- Lua provided by RyzenAPI 
-- Game: Strip n Play with Valerie
addappid(2169350)
addappid(2169351, 1, "460e41a01c6944197c22595186bdd82dedad4b3b4b5473f0b6bc5633fbd44a17")
