-- Lua provided by RyzenAPI
-- Game: Christmas Mansion

-- MAIN APPLICATION
addappid(1824170)
-- Game: addappid(1824170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824171, 1, "a62833e17cfa3c787b6c45ec577ae3ee9d5e5dfc83326e13159a4d5025a9f881")
addappid(1824172, 1, "adc1e0efff4427b276a6fb3f1032843fb90bbc6c579bffee4cc4df12c71bed7d")
