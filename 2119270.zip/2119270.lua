-- Lua provided by RyzenAPI
-- Game: Black Reliquary

-- MAIN APPLICATION
addappid(2119270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119271, 1, "7b30ef7ab8a2c269f056e00d523676a8325cc946a04ae262877060028e974c3f")

