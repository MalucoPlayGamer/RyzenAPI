-- Lua provided by RyzenAPI
-- Game: Game: My Sexy Waitress

-- MAIN APPLICATION
addappid(1656240)
-- Game: addappid(1656240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656241, 1, "4af18fa06be74b0e1f8950ba67332743a4991c26018a40d1870ed32f1ec34b21")
addappid(1670910, 0, "4db035d55931334aac726efb5ef1dc513857bcb8c6bff0619445a01128c5a193")
