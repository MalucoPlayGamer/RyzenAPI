-- Lua provided by RyzenAPI
-- Game: addappid(2513240)

-- MAIN APPLICATION
addappid(2513240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513241, 1, "091a6d1ae3e9592f7fa3e8bae5fc376cc9f055c19124d8a56dec7716403056c4")
