-- Lua provided by RyzenAPI
-- Game: Pricolage -IDOLIZED- Demo

-- MAIN APPLICATION
addappid(2713700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713701, 1, "39c395fb6e1dc4195b4674b4d31ca99c708120b859e13f7cbd42d40963158ff8")
