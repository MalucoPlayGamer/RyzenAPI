-- Lua provided by RyzenAPI
-- Game: Reloader: test_subject

-- MAIN APPLICATION
addappid(1706210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706211, 1, "a057783da4c8979f90a938ef2589596ea4fd63e5ef93da113bf7b1a948299531")
