-- Lua provided by RyzenAPI
-- Game: 魔塔三国之逆乱时空

-- MAIN APPLICATION
addappid(2141990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141991, 1, "8d6539cf47d402f082e38531af0f943e4dcc0d38ff4ed83d3f6fe58ab20f7865")

