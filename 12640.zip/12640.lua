-- Lua provided by RyzenAPI
-- Game: Game: Drakensang

-- MAIN APPLICATION
addappid(12640)
-- Game: addappid(12640)

-- MAIN APP DEPOTS / PACKAGES
addappid(12641, 1, "126708d442d3a81af2a396f038e6fcdbb0b580d2d7f58d06e604d919e9713da5")
addappid(12642, 1, "17084c727b3507bc695863ec558a75353491cc76f62fafefb26cace0441e69c1")
addappid(12643, 1, "8c84fc88b15e6cb4868e70c9c66f24594d5ec5a477e70a423fc43433284550dd")
addappid(12644, 1, "7b67ac4571cd6fe8d16940b98e05d851e694005f7bce452dac36798fea414c62")
