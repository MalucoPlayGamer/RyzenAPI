-- Lua provided by RyzenAPI
-- Game: VEGTERIA - Vegetable Shop Simulator

-- MAIN APPLICATION
addappid(1359870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1359871, 1, "13394891895cb5f7ae7516c8c3c0b7942f6163533bfadf36437ad00b427d1990")

