-- Lua provided by RyzenAPI
-- Game: VEGTERIA - Vegetable Shop Simulator

-- MAIN APPLICATION
addappid(1359870)
-- Game: addappid(1359870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359871, 1, "13394891895cb5f7ae7516c8c3c0b7942f6163533bfadf36437ad00b427d1990")
