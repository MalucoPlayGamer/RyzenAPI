-- Lua provided by RyzenAPI
-- Game: Game: AppID 1585540

-- MAIN APPLICATION
addappid(1585540)
-- Game: addappid(1585540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585541, 1, "2d3c74ecbbc6565e26782c277105dc7c295438a44fc675b65d884695d82e1268")
addappid(1585542, 1, "42a434452ab90c26ab89035b379c47de9d0c389da2284cfa06cd3ef4e3d261c8")
addappid(1585543, 1, "63fe4951aaf9036aee7dba743c37c6dcff6dc6d8c4cd4de1a3cb2a69f154ae68")
