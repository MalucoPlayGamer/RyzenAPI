-- Lua provided by RyzenAPI
-- Game: addappid(2714820)

-- MAIN APPLICATION
addappid(2714820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714820,0,"232e0645e594dbe740dbb0bf1557d765dd0444558df6d159de8734b3fb51e255")
