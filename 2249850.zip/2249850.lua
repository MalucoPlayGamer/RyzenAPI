-- Lua provided by RyzenAPI
-- Game: Cats Everywhere

-- MAIN APPLICATION
addappid(2249850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249851, 1, "897991c39f3396920b9d85e1e8276d2369b764a76f05576ce34dcdd81732a644")
