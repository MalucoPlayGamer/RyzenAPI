-- Lua provided by RyzenAPI
-- Game: Game: Garbage Crew!

-- MAIN APPLICATION
addappid(1592720)
-- Game: addappid(1592720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592721, 1, "2db000ec75cf57481d1c3557cfe3ae46406745d7c075ff1c997cdc84f62c5c9f")
