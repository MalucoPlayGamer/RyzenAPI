-- Lua provided by RyzenAPI
-- Game: Candle Knight - Digital Art Book

-- MAIN APPLICATION
addappid(2435580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435581, 1, "038ee57c627668f29db0193ed3d0feb50dfed3ae15e96ff506b188358005fd02")
