-- 2103140's Lua and Manifest Created by Hubcap Manifest
-- Magicraft
-- Created: August 05, 2026 at 07:04:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(2103140, 1, "75d08dedb57cc72b24a757b7bbf4333017efe35b1d5735ac5b5266532802661e") -- Magicraft
-- MAIN APP DEPOTS
addappid(2103141, 1, "f0ba119c48fc700dae769f7087e735d40dc7f3a1f379c01ff163a8386ae1b3ce") -- Depot 2103141
setManifestid(2103141, "6349747602700530007", 2001186504)
addappid(2103144, 1, "8c28f65b28131414846d93c38ddcec659512404bccd93c58163f4b62cdc5a6c4") -- Depot 2103144
setManifestid(2103144, "5383460820466663275", 1981727866)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4099830) --   Content Pack
addtoken(4099830, "17599615563912186545")
addappid(4100710) --  -  Halloween Costume
addtoken(4100710, "14941122213920764900")
addappid(4293030) --  -  Spring Festival Costume
addappid(4838370) --  -  Cool Summer Costume