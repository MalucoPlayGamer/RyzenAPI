-- Lua provided by RyzenAPI
-- Game: Magicraft

-- MAIN APPLICATION
addappid(2103140)
-- Game: addappid(2103140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103141, 1, "f0ba119c48fc700dae769f7087e735d40dc7f3a1f379c01ff163a8386ae1b3ce")
