-- Lua provided by RyzenAPI
-- Game: Magicraft

-- MAIN APPLICATION
addappid(4099830) --   Content Pack
addappid(4100710) --  -  Halloween Costume
addappid(4293030) --  -  Spring Festival Costume
addappid(4838370) --  -  Cool Summer Costume

-- MAIN APP DEPOTS / PACKAGES
addappid(2103140, 1, "75d08dedb57cc72b24a757b7bbf4333017efe35b1d5735ac5b5266532802661e") -- Magicraft
addappid(2103141, 1, "f0ba119c48fc700dae769f7087e735d40dc7f3a1f379c01ff163a8386ae1b3ce") -- Depot 2103141
addappid(2103144, 1, "8c28f65b28131414846d93c38ddcec659512404bccd93c58163f4b62cdc5a6c4") -- Depot 2103144
addtoken(4099830, "17599615563912186545")
addtoken(4100710, "14941122213920764900")

