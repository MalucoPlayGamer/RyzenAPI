-- Lua provided by RyzenAPI 
-- Game: Magicraft
addappid(2103140)
addappid(2103141, 1, "f0ba119c48fc700dae769f7087e735d40dc7f3a1f379c01ff163a8386ae1b3ce")
