-- Lua provided by RyzenAPI
-- Game: Curious Expedition 2 Demo

-- MAIN APPLICATION
addappid(1268170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268171, 1, "cd4544ed07431ee4750b6b0f7f0e6ffaeaf0a377c26ffb890f72ee1c1bae50f7")
