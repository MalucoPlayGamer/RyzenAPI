-- Lua provided by RyzenAPI
-- Game: Night Blights

-- MAIN APPLICATION
addappid(446910)

-- MAIN APP DEPOTS / PACKAGES
addappid(446911, 1, "929dae86ff91ceb3eddbac8c72b2a556a6a9157ff6e28c5c304cde3bfb5cbeee")
