-- Lua provided by RyzenAPI
-- Game: Vengeful Rites

-- MAIN APPLICATION
addappid(755410)
-- Game: addappid(755410)

-- MAIN APP DEPOTS / PACKAGES
addappid(755411, 1, "6ec7c0a0286edbc495c90d8cabf2a9795010224e74a4585ac0d4994bed970828")
