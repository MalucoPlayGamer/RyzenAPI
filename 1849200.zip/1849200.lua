-- Lua provided by SkyAPI 
-- Game: It's On You
addappid(1849200)
addappid(1849201, 1, "b4ddd2ff3229c27f419b93e994d498a626ffd1551db618c3372c04390077f28b")
