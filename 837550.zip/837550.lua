-- Lua provided by RyzenAPI
-- Game: Bouncy Butter Ball

-- MAIN APPLICATION
addappid(837550)

-- MAIN APP DEPOTS / PACKAGES
addappid(837551, 1, "63bf7e0f8bf93f81fadd9aa20e017f5573408d7b6df983f0b91bd8b876ea213a")
