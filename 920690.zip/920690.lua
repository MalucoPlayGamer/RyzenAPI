-- Lua provided by RyzenAPI
-- Game: CardLife

-- MAIN APPLICATION
addappid(920690)

-- MAIN APP DEPOTS / PACKAGES
addappid(920691, 1, "09a78bdb68521694a92b6dc27da16295548ca2f16c6f08cf7772d79cd74c54b6")
addappid(945690, 0, "e594dce909f4f5a8b1fd0b7cb4d9c3f2c41e8a8fda20c7913fb9c7d6e323fa82")
