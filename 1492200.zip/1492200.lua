-- Lua provided by SkyAPI 
-- Game: Soviet Hentai
addappid(1492200)
addappid(1492201, 1, "756094281394296e529c625213bc3c4d67fe5f1f52984832dd2c56f16db504bd")
