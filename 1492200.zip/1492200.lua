-- Lua provided by RyzenAPI
-- Game: Soviet Hentai

-- MAIN APPLICATION
addappid(1492200)
-- Game: addappid(1492200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492201, 1, "756094281394296e529c625213bc3c4d67fe5f1f52984832dd2c56f16db504bd")
