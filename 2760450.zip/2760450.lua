-- Lua provided by RyzenAPI
-- Game: 2760450

-- MAIN APPLICATION
addappid(2760450)
-- Game: addappid(2760450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760451, 1, "d051362e87084b9d967dbf5a225b7bebe87e369385e4b7827b4304ca95beee4c")
