-- Lua provided by RyzenAPI
-- Game: 特務少女未來 極限機械調教 Demo

-- MAIN APPLICATION
addappid(2760450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760451, 1, "d051362e87084b9d967dbf5a225b7bebe87e369385e4b7827b4304ca95beee4c")
