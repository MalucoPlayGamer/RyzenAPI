-- Lua provided by RyzenAPI 
-- Game: Idol Hands 2
addappid(2053940)
addappid(2053941, 1, "4613e6c044b956137ad48dbe58964a64be2bdfa368111d1874626a327972832e")
addappid(2053943, 1, "33c27c1a45e3ea6ba7a5772e783d363f59206bdd888edd6ead245be045818703")
