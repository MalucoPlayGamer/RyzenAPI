-- Lua provided by RyzenAPI
-- Game: addappid(2685360)

-- MAIN APPLICATION
addappid(2685360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685361, 1, "8fcf157184d53c0ec77a6f5803af6eed0e7f785b31b233dd6366c3c0b382b5d9")
