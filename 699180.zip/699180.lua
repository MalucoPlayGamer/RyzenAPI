-- Lua provided by RyzenAPI
-- Game: 699180

-- MAIN APPLICATION
addappid(699180)
-- Game: addappid(699180)

-- MAIN APP DEPOTS / PACKAGES
addappid(699181, 1, "a0d6e4377e27eb8a1c15b64ff057bdf2fac3cfe5bb4a804ac013d917dfabdc96")
