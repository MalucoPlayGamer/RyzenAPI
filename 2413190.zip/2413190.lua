-- Lua provided by SkyAPI 
-- Game: Emergency Cleanup Co.
addappid(2413190)
addappid(2413191, 1, "b58db783b26a131b405d6a0d36afda7a3034bf238e66dd27ecf0f38e8775c5f3")
