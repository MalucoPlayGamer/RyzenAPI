-- Lua provided by RyzenAPI
-- Game: Emergency Cleanup Co.

-- MAIN APPLICATION
addappid(2413190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413191, 1, "b58db783b26a131b405d6a0d36afda7a3034bf238e66dd27ecf0f38e8775c5f3")

