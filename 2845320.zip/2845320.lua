-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Kyoto

-- MAIN APPLICATION
addappid(2845320)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3009840)
