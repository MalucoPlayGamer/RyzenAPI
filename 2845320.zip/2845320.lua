-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Kyoto

-- MAIN APPLICATION
addappid(2845320)
addappid(3009840)

