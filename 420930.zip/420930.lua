-- Lua provided by RyzenAPI
-- Game: Game: CHKN

-- MAIN APPLICATION
addappid(420930)
-- Game: addappid(420930)

-- MAIN APP DEPOTS / PACKAGES
addappid(420931, 1, "6fe5882751e4de8e11b1fa999ccaa2011dbbc2e587c8cf2bea87efe2534363f3")
addappid(420932, 1, "65feff62a11c11b1cfb5e5b267e42d225f6bd9fd4565e42b3bc6ee7283aa6ae8")
addappid(420933, 1, "e81b051b137a6337f5f367e75263e1655c3409b647d2eec2fb98e7653f8a3b28")
addappid(420934, 1, "6ca65ff68c27650214ecaeac82515fe8df60057bc174b51b2eb88982f8e563b8")
