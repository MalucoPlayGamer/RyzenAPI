-- Lua provided by RyzenAPI
-- Game: CHKN

-- MAIN APPLICATION
addappid(420930)

-- MAIN APP DEPOTS / PACKAGES
addappid(420931, 1, "6fe5882751e4de8e11b1fa999ccaa2011dbbc2e587c8cf2bea87efe2534363f3")
addappid(420932, 1, "65feff62a11c11b1cfb5e5b267e42d225f6bd9fd4565e42b3bc6ee7283aa6ae8")
addappid(420933, 1, "e81b051b137a6337f5f367e75263e1655c3409b647d2eec2fb98e7653f8a3b28")
addappid(420934, 1, "6ca65ff68c27650214ecaeac82515fe8df60057bc174b51b2eb88982f8e563b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2360370)
