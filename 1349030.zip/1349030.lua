-- Lua provided by RyzenAPI
-- Game: Innocent Girl

-- MAIN APPLICATION
addappid(1349030)
-- Game: addappid(1349030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349031, 1, "a008152c9063bedcfb2e6a4cd2f0a1d1c98ec6db7e8dfa59b349c6f2cc9e9865")
addappid(1349032, 1, "70cf8dcf6994821e266cd2e0cb60cf56bbcff08180b0e9842225ec415c2d6e0a")
addappid(1349033, 1, "5ffdc200764f63c18d1a6cea4c2e9b97d30bc78598f28c259dc41044fa4750ab")
addappid(1349034, 1, "6ce8b17449935568c253e23a6c325503462008bcb9a765e9490373d34f2ade11")
