-- Lua provided by RyzenAPI
-- Game: Game: AppID 1954880

-- MAIN APPLICATION
addappid(1954880)
-- Game: addappid(1954880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954881, 1, "14097baa8857bd4bfd4c5209ebdaaa6572847918304c12535efc32329870e565")
