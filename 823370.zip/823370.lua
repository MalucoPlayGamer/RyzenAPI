-- Lua provided by RyzenAPI
-- Game: AppID 823370

-- MAIN APPLICATION
addappid(823370)
-- Game: addappid(823370)

-- MAIN APP DEPOTS / PACKAGES
addappid(823371, 1, "daf3af505f197fd0896809132d627aaf4ad9ade78091066707350fbdf5f3a28c")
