-- Lua provided by RyzenAPI
-- Game: Slider

-- MAIN APPLICATION
addappid(1916890)
