-- Lua provided by RyzenAPI
-- Game: 3342650

-- MAIN APPLICATION
addappid(3342650)
-- Game: addappid(3342650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342651, 1, "2e83d1a4526417dbb18c32a9ebda314ef2e22c55d49b5a71300aa0dd0d7611f8")
