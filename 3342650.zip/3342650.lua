-- Lua provided by RyzenAPI
-- Game: From The Past

-- MAIN APPLICATION
addappid(3342650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342651, 1, "2e83d1a4526417dbb18c32a9ebda314ef2e22c55d49b5a71300aa0dd0d7611f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
