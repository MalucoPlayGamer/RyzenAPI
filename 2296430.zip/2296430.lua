-- Lua provided by RyzenAPI
-- Game: Game: Paleo Pines Demo

-- MAIN APPLICATION
addappid(2296430)
-- Game: addappid(2296430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296431, 1, "931fdff964ef41c589a7529e45eb24626a1dbe41ea55f0bf8bc928fece21f3bd")
