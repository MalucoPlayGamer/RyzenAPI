-- Lua provided by RyzenAPI
-- Game: addappid(1220900)

-- MAIN APPLICATION
addappid(1220900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220901, 1, "5cdb0d7a9525f63b4b4418d09d11887788b8b4397c800b3883d29cfbcd5f90e4")
