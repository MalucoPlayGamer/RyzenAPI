-- Lua provided by RyzenAPI
-- Game: Astonia Remastered

-- MAIN APPLICATION
addappid(1220900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220901, 1, "5cdb0d7a9525f63b4b4418d09d11887788b8b4397c800b3883d29cfbcd5f90e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
