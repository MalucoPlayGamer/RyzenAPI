-- Lua provided by SkyAPI 
-- Game: Warbox Sandbox
addappid(2050680)
addappid(2050681, 1, "290d77a85af2fe398bc501f62cd1c472b4064d20a014f009f197d3630eb705d7")
