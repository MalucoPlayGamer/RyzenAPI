-- Lua provided by RyzenAPI
-- Game: Pepper Blast

-- MAIN APPLICATION
addappid(2478290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478292,0,"f3d8e8d583b813f6bde5d69db1ca2eb54d20bd43818893fa231f1589768c0589")

