-- Lua provided by RyzenAPI
-- Game: 29660

-- MAIN APPLICATION
addappid(29660)

-- MAIN APP DEPOTS / PACKAGES
addappid(29641,0,"50b9fdffd7e9826b473b42aeeb373dfb1cee08304da47f6ca958253b4f7e1dc4")

