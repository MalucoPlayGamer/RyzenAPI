-- Lua provided by RyzenAPI
-- Game: New Eromancer

-- MAIN APPLICATION
addappid(3248580)
-- Game: addappid(3248580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248583,0,"fd40c90d70dc493ca1c2088d3560ec6ff747a6457564c6ca9a04bf7082f14cc3")
addappid(3248584,0,"448c3fc32842e112a08372ce3d0770d65f23903feb67f88417e49a1b8031b57c")
