-- Lua provided by RyzenAPI
-- Game: AppID 2588130

-- MAIN APPLICATION
addappid(2588130)
-- Game: addappid(2588130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588131, 1, "7f38fa5b5aa064e26aaaf921f36047660b22eed81e0cbb0409b36fa991da0d5e")
