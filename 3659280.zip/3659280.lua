-- Lua provided by RyzenAPI
-- Game: Off The Grid

-- MAIN APPLICATION
addappid(3659280)
