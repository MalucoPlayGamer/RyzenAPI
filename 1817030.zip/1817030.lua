-- 1817030's Lua and Manifest Created by Hubcap Manifest
-- Swordcery
-- Created: August 12, 2026 at 09:13:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1817030) -- Swordcery
-- MAIN APP DEPOTS
addappid(1817031, 1, "d12c98f0693c51e83543c784ef59064c7462a78c3d0d228be37de9439f20bfee") -- Depot 1817031
setManifestid(1817031, "8329237747154273673", 5792768536)