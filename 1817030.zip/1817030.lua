-- Lua provided by RyzenAPI
-- Game: Swordcery

-- MAIN APPLICATION
addappid(1817030) -- Swordcery

-- MAIN APP DEPOTS / PACKAGES
addappid(1817031, 1, "d12c98f0693c51e83543c784ef59064c7462a78c3d0d228be37de9439f20bfee") -- Depot 1817031

