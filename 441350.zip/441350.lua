-- Lua provided by RyzenAPI
-- Game: AppID 441350

-- MAIN APPLICATION
addappid(441350)

-- MAIN APP DEPOTS / PACKAGES
addappid(441351, 1, "732a258d5279189f0da5ec266e5ed13338226508cc098f596803e33a10ac48b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
