-- Lua provided by SkyAPI 
-- Game: AppID 441350
addappid(441350)
addappid(441351, 1, "732a258d5279189f0da5ec266e5ed13338226508cc098f596803e33a10ac48b4")
