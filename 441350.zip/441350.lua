-- Lua provided by RyzenAPI
-- Game: Game: AppID 441350

-- MAIN APPLICATION
addappid(441350)
-- Game: addappid(441350)

-- MAIN APP DEPOTS / PACKAGES
addappid(441351, 1, "732a258d5279189f0da5ec266e5ed13338226508cc098f596803e33a10ac48b4")
