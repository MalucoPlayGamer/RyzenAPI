-- Lua provided by RyzenAPI
-- Game: Scribble It!

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1088150)
-- Game: addappid(1088150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088153,0,"97035e41bb59162e8e4f7e9e7a53af76c998883cbcf8850f0e0316a9f1c222d2")
addappid(1088155,0,"f91eb70086743b43d335376449c852380abb2bb8b4c11a299b0ce1c37baef410")
addappid(1088156,0,"5bdfaf8c5ce1ca96a1d034fc1b6c011d5cf4a97941f6cdf4da2f39e927cbf67a")
