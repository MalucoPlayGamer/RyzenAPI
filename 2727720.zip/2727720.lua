-- Lua provided by RyzenAPI
-- Game: Crown Wars - Soundtrack

-- MAIN APPLICATION
addappid(2727720)
-- Game: addappid(2727720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727721, 1, "6ce1c1f7b2d64864034c33c54b5e8bcd6e7f8e2205a56755fc8d5a260b5550c4")
addappid(2727722, 1, "09ed820b68165c06803a68943fb22857687ce5b774e839f771444cc2ffa04a4d")
