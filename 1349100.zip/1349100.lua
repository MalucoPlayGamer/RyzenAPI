-- Lua provided by RyzenAPI
-- Game: Game: GALAXY CRISIS

-- MAIN APPLICATION
addappid(1349100)
-- Game: addappid(1349100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349101, 1, "64d20aa325d4bb77dfb97f71b93e5ac76dcc9fc9458e991251ffbf2e0c4a0123")
