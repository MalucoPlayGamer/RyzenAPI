-- Lua provided by RyzenAPI 
-- Game: GALAXY CRISIS
addappid(1349100)
addappid(1349101, 1, "64d20aa325d4bb77dfb97f71b93e5ac76dcc9fc9458e991251ffbf2e0c4a0123")
