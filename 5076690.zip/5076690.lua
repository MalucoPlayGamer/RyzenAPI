-- Lua provided by RyzenAPI
-- Game: Incremedieval

-- MAIN APPLICATION
addappid(5076690) -- Incremedieval

-- MAIN APP DEPOTS / PACKAGES
addappid(5076691, 1, "e770888839655a87aec731d87fa00b671ad4c4225ff3480031b11d4840f47a5c") -- Depot 5076691
addappid(5076692, 1, "94f7a9dd855997ec275d7c0af126b751faff3c750034e8d6964b7e5bf4a272a4") -- Depot 5076692
addappid(5076693, 1, "117a4caabc68ecd4d9c7e29bf74c70dc44ad1c06f64c7bd98f5cfc8bfd922716") -- Depot 5076693

