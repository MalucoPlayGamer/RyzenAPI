-- Lua provided by RyzenAPI
-- Game: Game: Sonic Racing: CrossWorlds

-- MAIN APPLICATION
addappid(2486820)
addappid(3565190)
addappid(3592250)
addappid(3601430)
addappid(3601440)
addappid(3601500)
addappid(3601510)
addappid(3601530)
-- Game: addappid(2486820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486821, 1, "08e2539b55bc79fefa9447d3479c57b481c4256c12ebd50529fc3722fcc3727f")
