-- Lua provided by RyzenAPI
-- Game: Sonic Racing: CrossWorlds

-- MAIN APPLICATION
addappid(2486820)
addappid(3565190)
addappid(3592250)
addappid(3601430)
addappid(3601440)
addappid(3601500)
addappid(3601510)
addappid(3601530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486821, 1, "08e2539b55bc79fefa9447d3479c57b481c4256c12ebd50529fc3722fcc3727f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3601470)
addappid(3601480)
