-- Lua provided by RyzenAPI
-- Game: 2677940

-- MAIN APPLICATION
addappid(2677940)
-- Game: addappid(2677940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677941, 1, "5981d24209fb67728b11cb4333dab70fe28e1312f79624fd5bdbcd07ff863ce2")
