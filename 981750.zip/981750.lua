-- Lua provided by RyzenAPI
-- Game: Game: AppID 981750

-- MAIN APPLICATION
addappid(981750)
-- Game: addappid(981750)

-- MAIN APP DEPOTS / PACKAGES
addappid(981751, 1, "b5f84767c3819cf86493e80ae299514fd052a780441121db3eb8839e44d1784d")
