-- Lua provided by RyzenAPI
-- Game: 207730

-- MAIN APPLICATION
addappid(207730)
-- Game: addappid(207730)

-- MAIN APP DEPOTS / PACKAGES
addappid(207731, 1, "c07c0600cb1c818e7fed041542b926833a3a4df53a0a91d2ae0d1f34706c38cd")
addappid(207732, 1, "75cb9e8d2218065cd022f9f4d42fb1c76ca9b87a45f13aaffccf98aacc90cb81")
addappid(207733, 1, "e453df7fce635e77dc6308c6f4b5d512adc676d5c4f77383b6c2249323fadf8e")
