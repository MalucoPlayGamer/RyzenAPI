-- Lua provided by RyzenAPI
-- Game: Isle of Arrows

-- MAIN APPLICATION
addappid(1946970)
addappid(1946971)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946972,0,"c0b4ac6afa828ede1090412d7e19d3bef2addecfdc3f6e2d6d03dc7f5deff54e")
