-- Lua provided by RyzenAPI
-- Game: Spirit of Revenge: Cursed Castle Collector's Edition

-- MAIN APPLICATION
addappid(551160)

-- MAIN APP DEPOTS / PACKAGES
addappid(551161,0,"559554ecdcc50b349f9c0e5cda6b8915231d1c015669624996e3916ec9cd2aa0")

