-- Lua provided by RyzenAPI
-- Game: Game: AppID 2906960

-- MAIN APPLICATION
addappid(2906960)
-- Game: addappid(2906960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906961, 1, "a061b3200303313e50ddf2d27ec5a8d836f7cd443be99e526679046b176a0b75")
