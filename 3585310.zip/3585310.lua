-- Lua provided by RyzenAPI
-- Game: KUNKUN Defender 2

-- MAIN APPLICATION
addappid(3585310)
-- Game: addappid(3585310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3585311, 1, "e63391377a8b4ed2b810095a95514975f4ef29f1ad14e86c78005d5ad845dd11")
