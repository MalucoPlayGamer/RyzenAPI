-- Lua provided by RyzenAPI
-- Game: Casual Pro Wrestling

-- MAIN APPLICATION
addappid(1521100)
-- Game: addappid(1521100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521101, 1, "e5785362ab0d76d9693f1161bc6369e72dffa970be35e9d8c7d6392d8b0d1ab6")
