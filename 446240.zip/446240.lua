-- Lua provided by RyzenAPI
-- Game: 446240

-- MAIN APPLICATION
addappid(446240)
-- Game: addappid(446240)

-- MAIN APP DEPOTS / PACKAGES
addappid(446242,0,"27406eabce37c1c9962df30ba5fd53c5863d3878feebfe78d275455e49a84792")
