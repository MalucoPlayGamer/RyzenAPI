-- Lua provided by RyzenAPI
-- Game: BeatBlasters III

-- MAIN APPLICATION
addappid(246800)

-- MAIN APP DEPOTS / PACKAGES
addappid(246801, 1, "44cf50c00384f21a86f566233ab2c11e0cebb23a075e1031064909a21e015d75")
addappid(246802, 1, "949a64b50164f2ba6df7928d15ed6c955bae7dce24d923ecf0073aa7ea82fae3")
addappid(246803, 1, "ca342e5a63c350f912c52d445836972d8a23dc6fec5802909e39e3c3a6487f90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
