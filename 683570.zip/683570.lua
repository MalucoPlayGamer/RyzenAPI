-- Lua provided by RyzenAPI
-- Game: Cludbugz's Twisted Magic

-- MAIN APPLICATION
addappid(683570)

-- MAIN APP DEPOTS / PACKAGES
addappid(683571, 1, "54d97a9eeb07b8338f32b8ae6d9412e4c3e752e149b21c51e0d7a57323e3c613")

