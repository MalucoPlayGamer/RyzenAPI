-- Lua provided by RyzenAPI
-- Game: Dad Quest

-- MAIN APPLICATION
addappid(524250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(524251, 1, "9db4f2ea1301f409072ea35157438782929a89d81cd99bb4f3edc7466c699dd3")

