-- Lua provided by RyzenAPI
-- Game: addappid(524250)

-- MAIN APPLICATION
addappid(524250)

-- MAIN APP DEPOTS / PACKAGES
addappid(524251, 1, "9db4f2ea1301f409072ea35157438782929a89d81cd99bb4f3edc7466c699dd3")
