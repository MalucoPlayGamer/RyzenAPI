-- Lua provided by RyzenAPI
-- Game: Astro Looter: Survivor Demo

-- MAIN APPLICATION
addappid(3028960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028961, 1, "2d93033946d5053cadd1ed2cc8face5fbbf3d8a07d2fd980417859bb9013913c")
