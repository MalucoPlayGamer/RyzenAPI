-- Lua provided by RyzenAPI
-- Game: Ultimus bellum

-- MAIN APPLICATION
addappid(566430)

-- MAIN APP DEPOTS / PACKAGES
addappid(566431,0,"4acf6c8463655a1a52a6bee356d471fb95c4ff598f0f46be3848bab472df0ef7")
addappid(566432,0,"1bdf4f9d29154173797fbb95013ff08a48c46a1464a7d7537635938b9e30b635")

