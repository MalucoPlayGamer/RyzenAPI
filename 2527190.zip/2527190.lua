-- Lua provided by RyzenAPI
-- Game: InterNULL Demo

-- MAIN APPLICATION
addappid(2527190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527191, 1, "8bf8f9835e30b0e95fd2bdb72144054d621b70eb2613a81d2b91aec174c84c22")
