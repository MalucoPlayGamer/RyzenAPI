-- Lua provided by RyzenAPI
-- Game: addappid(757440)

-- MAIN APPLICATION
addappid(757440)

-- MAIN APP DEPOTS / PACKAGES
addappid(757441, 1, "a91fc82c0f8ad1d7a377be793207ccec09547fd6da3f11177e4020949537f454")
