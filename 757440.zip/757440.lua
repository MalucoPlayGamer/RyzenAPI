-- Lua provided by RyzenAPI
-- Game: Crafting Tycoon

-- MAIN APPLICATION
addappid(757440)

-- MAIN APP DEPOTS / PACKAGES
addappid(757441, 1, "a91fc82c0f8ad1d7a377be793207ccec09547fd6da3f11177e4020949537f454")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
