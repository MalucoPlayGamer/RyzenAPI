-- Lua provided by RyzenAPI
-- Game: Battle Map Studio Demo

-- MAIN APPLICATION
addappid(1755490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755492,0,"5230062eaf628cc7fb19dbbd3575dc175161040803e988437d33a9afc458e437")

