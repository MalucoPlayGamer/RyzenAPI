-- Lua provided by RyzenAPI
-- Game: Destinies

-- MAIN APPLICATION
addappid(1593930)
-- Game: addappid(1593930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593931, 1, "5f91dde4c8ca6a3971dd91bc01b0fff60d7b3503db58705ed41e33388d3ca243")
addappid(1593932, 1, "862c0ddda4e2f306eaf413c3fc9e2998e2405564b057b6418c513c77cd0a9eae")
addappid(1593933, 1, "afc93f51d5fd5af1eab78c9ffea44284c21d08b5f2387ee491eae8d9a6a97775")
