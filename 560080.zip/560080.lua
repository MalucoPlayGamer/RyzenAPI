-- Lua provided by RyzenAPI
-- Game: AppID 560080

-- MAIN APPLICATION
addappid(560080)
-- Game: addappid(560080)

-- MAIN APP DEPOTS / PACKAGES
addappid(560081, 1, "c56d7c2ed69840c020be831b3063cd3c5118adab8daee26a0663885470fed714")
