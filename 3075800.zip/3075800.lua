-- Lua provided by RyzenAPI
-- Game: Game: AppID 3075800

-- MAIN APPLICATION
addappid(3075800)
-- Game: addappid(3075800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075801, 1, "54ac8183ba1b10c5aa82dda72cf7a76863dcaac6404c9308b14859c6574e21bd")
