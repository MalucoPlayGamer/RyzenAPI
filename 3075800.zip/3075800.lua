-- Lua provided by SkyAPI 
-- Game: AppID 3075800
addappid(3075800)
addappid(3075801, 1, "54ac8183ba1b10c5aa82dda72cf7a76863dcaac6404c9308b14859c6574e21bd")
