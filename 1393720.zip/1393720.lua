-- Lua provided by RyzenAPI
-- Game: Hedon Demo

-- MAIN APPLICATION
addappid(1393720)
-- Game: addappid(1393720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393724,0,"0b00a76ab5946c906df84a738e68da4decbe6e6b676513333610409cb8b15d8b")
