-- Lua provided by RyzenAPI
-- Game: KANADE

-- MAIN APPLICATION
addappid(3104270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104271, 1, "5229df968966c46886e644d1e9cb99f87141e3187865c3592e1a406337ba1110")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
