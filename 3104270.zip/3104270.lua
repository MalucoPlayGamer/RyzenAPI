-- Lua provided by RyzenAPI 
-- Game: KANADE
addappid(3104270)
addappid(3104271, 1, "5229df968966c46886e644d1e9cb99f87141e3187865c3592e1a406337ba1110")
