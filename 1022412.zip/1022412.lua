-- Lua provided by RyzenAPI
-- Game: 1022412

-- MAIN APPLICATION
addappid(1022412)
-- Game: addappid(1022412)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022412,0,"4946e4b33ba539e3b01866ce3306481ae7150d2cc2e9af57772d0d46b1d450ed")
