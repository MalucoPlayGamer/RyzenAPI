-- Lua provided by RyzenAPI
-- Game: DFF NT: Destructive Tentacles, Cloud of Darkness's 4th Weapon Set

-- MAIN APPLICATION
addappid(1022412)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022412,0,"4946e4b33ba539e3b01866ce3306481ae7150d2cc2e9af57772d0d46b1d450ed")

