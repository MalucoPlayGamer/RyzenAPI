-- Lua provided by RyzenAPI
-- Game: addappid(958790)

-- MAIN APPLICATION
addappid(958790)

-- MAIN APP DEPOTS / PACKAGES
addappid(958791, 1, "c1ee9ff9677ac8cec00b947bad4e4e9f81a2ac147bfbad8c74b9ad17b9914a40")
