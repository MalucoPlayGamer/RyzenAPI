-- Lua provided by RyzenAPI
-- Game: 2795370

-- MAIN APPLICATION
addappid(2795370)
-- Game: addappid(2795370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795371, 1, "25a36f1535ca1ec8fef67f51a0b07496cc2399351b0e3bd6194076e27b91dbe4")
