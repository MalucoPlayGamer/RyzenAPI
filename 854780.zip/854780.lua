-- Lua provided by RyzenAPI
-- Game: 854780

-- MAIN APPLICATION
addappid(854780)
-- Game: addappid(854780)

-- MAIN APP DEPOTS / PACKAGES
addappid(854780,0,"5c31f0b14dbe3203d8861835d0edfa96cd9fa441136d03015ccda371d52ddcdd")
