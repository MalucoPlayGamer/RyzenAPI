-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Skyline Simulations - KCVG - Cincinnati/Northern Kentucky International XP

-- MAIN APPLICATION
addappid(854780)

-- MAIN APP DEPOTS / PACKAGES
addappid(854780,0,"5c31f0b14dbe3203d8861835d0edfa96cd9fa441136d03015ccda371d52ddcdd")
