-- Lua provided by RyzenAPI
-- Game: NITRO GEN OMEGA

-- MAIN APPLICATION
addappid(2525510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525511, 1, "763e3dc5df900a6f23d69d322f1b8caa123fe07552d48886e9dad50e4c870f6d")
addappid(3782960, 0, "bd10425035e3c651690a732e813e8b61d2d40fa1fb63545a0ada81700e3c6c5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
