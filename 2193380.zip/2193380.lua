-- Lua provided by RyzenAPI
-- Game: Image

-- MAIN APPLICATION
addappid(2193380)
-- Game: addappid(2193380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193381, 1, "b45b4893d2ab2d432221cd6782f86b76bbe08e616c21845926803b00b3036c58")
