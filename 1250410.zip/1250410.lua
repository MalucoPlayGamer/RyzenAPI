-- Lua provided by RyzenAPI
-- Game: 1250410

-- MAIN APPLICATION
addappid(1250410)
-- Game: addappid(1250410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250411, 1, "dbf9d5a5cae7eab44d452bfe53856e4b08b448ac7c224124316ca8cf3f91b3a8")
