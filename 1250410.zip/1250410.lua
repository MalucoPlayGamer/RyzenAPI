-- Lua provided by SkyAPI 
-- Game: Microsoft Flight Simulator (2020) 40th Anniversary Edition
addappid(1250410)
addappid(1250411, 1, "dbf9d5a5cae7eab44d452bfe53856e4b08b448ac7c224124316ca8cf3f91b3a8")
