-- Lua provided by RyzenAPI
-- Game: Microsoft Flight Simulator (2020) 40th Anniversary Edition

-- MAIN APPLICATION
addappid(1250410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250411, 1, "dbf9d5a5cae7eab44d452bfe53856e4b08b448ac7c224124316ca8cf3f91b3a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1265910)
addappid(1265911)
addappid(5068460)
addappid(5068470)
addappid(5068480)
