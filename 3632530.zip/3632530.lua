-- Lua provided by RyzenAPI 
-- Game: Violated Princess
addappid(3632530)
addappid(3632531, 1, "fed674fc3155a06656b120f555c177ac3cd3cc9b25965f741b5eddb39e15334b")
