-- Lua provided by RyzenAPI
-- Game: Farm Manager World

-- MAIN APPLICATION
addappid(2206350)
addappid(3924370)
addappid(4113390)
addappid(4420940)
addappid(4420950)
addappid(4420960)
addappid(4420970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2206351, 1, "b2f5cc6afb93e000b9757839e6b0e05ff910467ce361f0917ebad42e2107900a")

