-- Lua provided by RyzenAPI 
-- Game: Farm Manager World
addappid(2206350)
addappid(2206351, 1, "b2f5cc6afb93e000b9757839e6b0e05ff910467ce361f0917ebad42e2107900a")
