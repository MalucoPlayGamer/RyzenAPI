-- Lua provided by SkyAPI 
-- Game: Cluck Yegger in Escape From The Planet of The Poultroid
addappid(416800)
addappid(416801, 1, "36c3d29f6d7201a4f576db1728366ac63589d3e715f1b4d8a043ca5b8cd31a4f")
addappid(416802, 1, "461386e57b5c7d9c29e3bd0807c796be5654396490fed50e083429c5b2e6d8af")
addappid(416803, 1, "3e1870aa2f6dab0709460ae1281f91a71660a6c19d3da35724e08314821f7081")
addappid(416804, 1, "20402bf982f66680dcb4b05b102ce2d32c9700eb1b6245c095976ecd9f3c0e00")
