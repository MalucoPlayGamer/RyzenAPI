-- Lua provided by RyzenAPI
-- Game: Impossible Stunts

-- MAIN APPLICATION
addappid(2471600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471601, 1, "973fd2fe0df6ee031ef9087222510b44134d683c88f8aad3a0e01121432a4091")
