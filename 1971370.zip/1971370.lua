-- Lua provided by RyzenAPI
-- Game: Game: Assault Wing

-- MAIN APPLICATION
addappid(1971370)
-- Game: addappid(1971370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971371, 1, "8689d6e653ada59cbadb5a79481db897adbab80d0cab6b95ed91494f2d9bc5c4")
addappid(1971372, 1, "7920567e2df6f21a602db2f0a39be5eb14c925ffe61d168eb80b0cf9456d09b8")
addappid(1971373, 1, "fdb85db9182230da39c07c37854617229cc96db4be3915902174c6be9eb3365c")
addappid(1971374, 1, "f89094b0a31c6233562c940c2e73e497ec14e29c3206a4c70376ca836e51e910")
