-- Lua provided by RyzenAPI
-- Game: Game: Pocket Bravery

-- MAIN APPLICATION
addappid(1555150)
-- Game: addappid(1555150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555151, 1, "37d31394e432fa3ada0d373f6c218f586289479813fae0a0c5f0ba477a899496")
addappid(3079470, 0, "7b98aca96ff089b7b0b57515802dff573fe08641433dab9bf9a8b928749945fe")
addappid(3079490, 0, "4fff15819b1eabb1a7c6e026625b130a3398919024ccffcf33f711058e3c0b42")
addappid(3348110, 0, "60f734dbe9f4ea6ad3bcc983af452ade387b9b364b8012fa0e08bd526e74f210")
