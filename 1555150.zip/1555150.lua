-- Lua provided by RyzenAPI
-- Game: Pocket Bravery

-- MAIN APPLICATION
addappid(3079470)
addappid(3079490)
addappid(3348110)
addappid(3977210) -- Camille
addappid(4614520) -- Son
addappid(4614530) -- Arashi
addappid(4614540) -- Filippo
addappid(4614550) -- Moha

-- MAIN APP DEPOTS / PACKAGES
addappid(1555150, 1, "2fc3048da53c15d6e37902e687f0d0bbb1a26e23709c8d36672f188bc62f9efe") -- Pocket Bravery
addappid(1555151, 1, "37d31394e432fa3ada0d373f6c218f586289479813fae0a0c5f0ba477a899496") -- Depot 1555151
addappid(1555152, 1, "5bc1c83bc46124dfc5673f3916476bde56f59ab02eed9d4c2e37553c1c717bdd") -- Depot 1555152
addappid(1555153, 1, "e56144d96701d4abf76a0132510346a5857a6478366ea100d26f8f8969ad461d") -- Depot 1555153
addappid(3079470, 1, "7b98aca96ff089b7b0b57515802dff573fe08641433dab9bf9a8b928749945fe") -- Rick - Depot 3079470
addappid(3079490, 1, "4fff15819b1eabb1a7c6e026625b130a3398919024ccffcf33f711058e3c0b42") -- Brandon - Depot 3079490
addappid(3348110, 1, "60f734dbe9f4ea6ad3bcc983af452ade387b9b364b8012fa0e08bd526e74f210") -- Dvesha - Depot 3348110
