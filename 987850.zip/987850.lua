-- Lua provided by RyzenAPI
-- Game: 2084

-- MAIN APPLICATION
addappid(987850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(987851, 1, "63b7197fe828772fa3429e7e881e3539ece6f3e9b0a6660f5d565c8484fff7d2")

