-- Lua provided by RyzenAPI 
-- Game: 2084
addappid(987850)
addappid(987851, 1, "63b7197fe828772fa3429e7e881e3539ece6f3e9b0a6660f5d565c8484fff7d2")
