-- Lua provided by RyzenAPI
-- Game: addappid(987850)

-- MAIN APPLICATION
addappid(987850)

-- MAIN APP DEPOTS / PACKAGES
addappid(987851, 1, "63b7197fe828772fa3429e7e881e3539ece6f3e9b0a6660f5d565c8484fff7d2")
