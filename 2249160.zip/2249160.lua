-- Lua provided by RyzenAPI
-- Game: September 7th

-- MAIN APPLICATION
addappid(2249160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249161, 1, "754f9d1a682aa3fc3eda41dbd0c33a1bb60238755ffec33260ef8970e690e42e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
