-- Lua provided by RyzenAPI
-- Game: Game: September 7th

-- MAIN APPLICATION
addappid(2249160)
-- Game: addappid(2249160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249161, 1, "754f9d1a682aa3fc3eda41dbd0c33a1bb60238755ffec33260ef8970e690e42e")
