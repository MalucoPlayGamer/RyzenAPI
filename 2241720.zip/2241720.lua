-- Lua provided by RyzenAPI
-- Game: AppID 2241720

-- MAIN APPLICATION
addappid(2241720)
-- Game: addappid(2241720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241721, 1, "c384f897fc86abbc3dc71d1f522b85067077daf9bba217539be31f2a3932e51d")
