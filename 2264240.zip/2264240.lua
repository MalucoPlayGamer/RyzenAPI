-- Lua provided by RyzenAPI
-- Game: Game: Waiter

-- MAIN APPLICATION
addappid(2264240)
-- Game: addappid(2264240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264241, 1, "02d77e8a1c740db24595b29f25d83d323d3c929bfe7795ee0b74c6908662a9a7")
