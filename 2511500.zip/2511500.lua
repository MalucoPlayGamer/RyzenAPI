-- Lua provided by RyzenAPI
-- Game: Dominions 6 - Rise of the Pantokrator

-- MAIN APPLICATION
addappid(2511500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(2511501, 1, "6b58ad19cccc805f5adc2d5cface5a64b6490949e613e5355945ad000126266a")

