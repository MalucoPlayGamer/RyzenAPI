-- Lua provided by RyzenAPI
-- Game: 2511500

-- MAIN APPLICATION
addappid(2511500)
-- Game: addappid(2511500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511501, 1, "6b58ad19cccc805f5adc2d5cface5a64b6490949e613e5355945ad000126266a")
