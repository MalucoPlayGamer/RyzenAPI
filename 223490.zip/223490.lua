-- Lua provided by RyzenAPI
-- Game: Blockscape

-- MAIN APPLICATION
addappid(223490)

-- MAIN APP DEPOTS / PACKAGES
addappid(223491, 1, "2146b765ea8b58887265c132a9f134e467669c2c958e02e40f13c331709580fb")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

