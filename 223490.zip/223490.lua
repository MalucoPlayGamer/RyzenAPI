-- Lua provided by RyzenAPI
-- Game: Blockscape

-- MAIN APPLICATION
addappid(223490)
-- Game: addappid(223490)

-- MAIN APP DEPOTS / PACKAGES
addappid(223491, 1, "2146b765ea8b58887265c132a9f134e467669c2c958e02e40f13c331709580fb")
