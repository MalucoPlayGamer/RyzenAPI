-- Lua provided by RyzenAPI
-- Game: 中国战疫

-- MAIN APPLICATION
addappid(1731360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731361, 1, "8ac6f06e783f1f3b6d815e30cd72a7e4a4107e7d1bdcbdea56ab012f123f7c05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
