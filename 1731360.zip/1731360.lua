-- Lua provided by RyzenAPI
-- Game: 中国战疫

-- MAIN APPLICATION
addappid(1731360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731361, 1, "8ac6f06e783f1f3b6d815e30cd72a7e4a4107e7d1bdcbdea56ab012f123f7c05")

