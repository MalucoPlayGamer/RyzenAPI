-- Lua provided by RyzenAPI
-- Game: Tap Tap Loot

-- MAIN APPLICATION
addappid(3959890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3959891,0,"a0523a3673d8526c8c42a0daf53dbcb40ee7784ad18c12b3935cfa0b98de4aff")

