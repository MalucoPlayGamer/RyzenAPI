-- Lua provided by RyzenAPI
-- Game: 1122710

-- MAIN APPLICATION
addappid(1122710)
-- Game: addappid(1122710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122711, 1, "2d6f00529cc1e0b544dd0fdb0febb0074f760b855f6f2765507ca75ca8b4281f")
