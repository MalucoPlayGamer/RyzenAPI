-- Lua provided by RyzenAPI
-- Game: CATS!

-- MAIN APPLICATION
addappid(388840)

-- MAIN APP DEPOTS / PACKAGES
addappid(388841, 1, "a9c559f1a461d1e5508ea1e26ba744c7a72757bad9803721752cf855e30c5dae")

