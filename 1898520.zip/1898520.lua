-- Lua provided by RyzenAPI
-- Game: Antipaint Demo

-- MAIN APPLICATION
addappid(1898520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898521, 1, "885b0dfd3bf0ab2572f2c83826607fceb2857cd36d87efd12eb618911d09acd4")

