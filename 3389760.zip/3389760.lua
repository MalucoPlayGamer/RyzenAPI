-- Lua provided by RyzenAPI
-- Game: 3389760

-- MAIN APPLICATION
addappid(3389760)
-- Game: addappid(3389760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389761, 1, "6b1aca8f951780b377547eb8d52023ae8a22c823a8c146af57d915dd60359a34")
