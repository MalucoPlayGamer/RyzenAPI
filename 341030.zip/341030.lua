-- Lua provided by RyzenAPI
-- Game: Game: Colonial Conquest

-- MAIN APPLICATION
addappid(341030)
-- Game: addappid(341030)

-- MAIN APP DEPOTS / PACKAGES
addappid(341031, 1, "5861ef7bf75144d31b266b44314235b228c0744c048843a3513ea9631449dd81")
