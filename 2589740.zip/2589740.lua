-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2589740)
-- Game: addappid(2589740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589740,0,"c97fcd0cd658dd2e0e3ceff1bdc985282a18a16ae64afd946b3c19eed10d7664")
