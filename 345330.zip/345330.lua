-- Lua provided by RyzenAPI
-- Game: 345330

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(229005)
addappid(345330)

-- MAIN APP DEPOTS / PACKAGES
addappid(345333,0,"ba899c8b220af0576d9ba089c79d4c4b9e6f1ada004d7f9ec08badd5d7b958ec")

