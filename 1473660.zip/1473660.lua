-- Lua provided by RyzenAPI
-- Game: Mrs. Santa's Gift Hunt

-- MAIN APPLICATION
addappid(1473660)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1473720)
addappid(1474380)
addappid(1477800)
