-- Lua provided by RyzenAPI
-- Game: Mrs. Santa's Gift Hunt

-- MAIN APPLICATION
addappid(1473660)
