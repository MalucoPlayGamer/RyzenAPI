-- Lua provided by RyzenAPI 
-- Game: AppID 807790
addappid(807790)
addappid(807791, 1, "6eaf19efa54088729c3072e72344136e3be38e24fcad1d7d647977bf0f472830")
