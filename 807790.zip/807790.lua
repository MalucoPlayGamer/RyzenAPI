-- Lua provided by RyzenAPI
-- Game: Game: AppID 807790

-- MAIN APPLICATION
addappid(807790)
-- Game: addappid(807790)

-- MAIN APP DEPOTS / PACKAGES
addappid(807791, 1, "6eaf19efa54088729c3072e72344136e3be38e24fcad1d7d647977bf0f472830")
