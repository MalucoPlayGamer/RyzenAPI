-- Lua provided by RyzenAPI
-- Game: Beat Saber: Lady Gaga, Colby O’Donis - 'Just Dance (feat. Colby O’Donis)'

-- MAIN APPLICATION
addappid(1812883)
-- Game: addappid(1812883)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812883,0,"2b189a4edeb5c976465821670d461d4940ebb7e896637f4761e3911e5af70559")
