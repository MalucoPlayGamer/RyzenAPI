-- Lua provided by RyzenAPI
-- Game: AppID 258070

-- MAIN APPLICATION
addappid(258070)

-- MAIN APP DEPOTS / PACKAGES
addappid(258071, 1, "719feb6dfcffac273c821eb63b0041d8def927ee36f2e98dd8272b9e5d18304e")

