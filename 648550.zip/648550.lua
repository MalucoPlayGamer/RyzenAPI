-- Lua provided by RyzenAPI 
-- Game: Choice
addappid(648550)
addappid(648551, 1, "3cd58aa664c643216609e069f1968fc9d843f5972c80e613092c39d81875f31c")
