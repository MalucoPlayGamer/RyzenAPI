-- Lua provided by RyzenAPI
-- Game: Game: Luna Online: Reborn

-- MAIN APPLICATION
addappid(457590)
-- Game: addappid(457590)

-- MAIN APP DEPOTS / PACKAGES
addappid(457591, 1, "4995df90dde8b3ad63ad40b85d5ff57e34182789115c54585873df0ccc07579b")
