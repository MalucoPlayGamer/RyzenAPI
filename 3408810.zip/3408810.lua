-- Lua provided by RyzenAPI
-- Game: WonderLang Spanish

-- MAIN APPLICATION
addappid(3408810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408813,0,"d36d10603aad23b30ee9e1c6c528eac4acacc3229180917bb63b6dd3c88afdb9")
