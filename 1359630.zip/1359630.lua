-- Lua provided by RyzenAPI
-- Game: 1359630

-- MAIN APPLICATION
addappid(1359630)
-- Game: addappid(1359630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359631, 1, "7c33c98af924228a574a3c976dc3458316b7bb370d0de2ce7c5b3c441c5d20b7")
