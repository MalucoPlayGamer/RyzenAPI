-- Lua provided by RyzenAPI
-- Game: AppID 1359630

-- MAIN APPLICATION
addappid(1359630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359631, 1, "7c33c98af924228a574a3c976dc3458316b7bb370d0de2ce7c5b3c441c5d20b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
