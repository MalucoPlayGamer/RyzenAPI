-- Lua provided by RyzenAPI
-- Game: Shroom & Doom

-- MAIN APPLICATION
addappid(2491690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491691, 1, "c93b386f7f5d5adfe7fbb33e87e0c654cc14a52fb99117900108f7590c80cce4")

