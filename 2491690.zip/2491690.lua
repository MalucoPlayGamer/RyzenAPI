-- Lua provided by RyzenAPI
-- Game: Shroom & Doom

-- MAIN APPLICATION
addappid(2491690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491691, 1, "c93b386f7f5d5adfe7fbb33e87e0c654cc14a52fb99117900108f7590c80cce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
