-- Lua provided by RyzenAPI
-- Game: Clicker Heroes

-- MAIN APPLICATION
addappid(363970)
addappid(556650)
addappid(565261)
addappid(591620)
addappid(702750)
addappid(1282910)

-- MAIN APP DEPOTS / PACKAGES
addappid(363971, 1, "c6ab5a86c8608fb4c10769b87bc52da5a37d3eea36baa471c08477061018fbc7")
addappid(363972, 1, "993d3566c26eaeeef35ef591deb53f215a8b3af28e939af09b190e7b558072f7")

