-- Lua provided by RyzenAPI 
-- Game: TRAIN CREW Prologue Demo
addappid(1663310)
addappid(1663311, 1, "4d77a622c4d9bd12b27d7b9b8d70dcc54d9e2302c3ed7b5e3788b5236c02d3e7")
