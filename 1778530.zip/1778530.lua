-- Lua provided by RyzenAPI
-- Game: Ancient Warfare: The Han Dynasty Demo

-- MAIN APPLICATION
addappid(1778530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778531, 1, "a5356d9d78d19f2cd5f798c6fbf1c3a4610aa4087697d3fb2395c3fba6d301e1")
