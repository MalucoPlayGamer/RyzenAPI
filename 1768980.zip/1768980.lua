-- Lua provided by RyzenAPI
-- Game: Snowman Arena

-- MAIN APPLICATION
addappid(1768980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768981,0,"6af6435efbaad14b040030b3a9ae32cda509df29f475029411ba6d0addf4436a")

