-- Lua provided by RyzenAPI
-- Game: Game: Cave Brawlers

-- MAIN APPLICATION
addappid(731500)
-- Game: addappid(731500)

-- MAIN APP DEPOTS / PACKAGES
addappid(731501, 1, "590e68101ab35f8b77d2359b7c325ea522d5d030baf103325d3b7b9813caf72f")
