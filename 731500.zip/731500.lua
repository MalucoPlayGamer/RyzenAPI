-- Lua provided by RyzenAPI
-- Game: Cave Brawlers

-- MAIN APPLICATION
addappid(731500)

-- MAIN APP DEPOTS / PACKAGES
addappid(731501, 1, "590e68101ab35f8b77d2359b7c325ea522d5d030baf103325d3b7b9813caf72f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
