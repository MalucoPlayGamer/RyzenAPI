-- Lua provided by RyzenAPI
-- Game: AppID 2269330

-- MAIN APPLICATION
addappid(2269330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269331, 1, "5419b22b02c344b4b6f2a55de4ec1089260dbac9c58512d593132d9a08e18a18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
