-- Lua provided by RyzenAPI
-- Game: Megan Thee Stallion AmazeVR Concert

-- MAIN APPLICATION
addappid(2269330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2269331, 1, "5419b22b02c344b4b6f2a55de4ec1089260dbac9c58512d593132d9a08e18a18")

