-- Lua provided by RyzenAPI
-- Game: addappid(3099870)

-- MAIN APPLICATION
addappid(3099870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099871, 1, "e1073cc9ed17a8603dc21936f3628426be623f0555afd6398603db249d36fcf0")
