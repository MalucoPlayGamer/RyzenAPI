-- Lua provided by RyzenAPI
-- Game: addappid(1786670)

-- MAIN APPLICATION
addappid(1786670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786671, 1, "30eee66f16f42ae8fbf5cf96abbbbfe5e68d33e5022612dec483fae6d3a805cc")
