-- Lua provided by RyzenAPI
-- Game: addappid(3205850)

-- MAIN APPLICATION
addappid(3205850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205851, 1, "5240ae87aa6683c650b378526e9a9e2b15f22130edab95189fdcaae1925407ad")
