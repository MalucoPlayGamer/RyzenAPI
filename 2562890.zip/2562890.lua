-- Lua provided by RyzenAPI 
-- Game: AppID 2562890
addappid(2562890)
addappid(2562891, 1, "77c9f71561e94ad7f24242b56ea6a80f4e5e02743a2b0c4790df3fa68d467726")
