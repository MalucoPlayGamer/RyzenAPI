-- Lua provided by RyzenAPI
-- Game: 2562890

-- MAIN APPLICATION
addappid(2562890)
-- Game: addappid(2562890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562891, 1, "77c9f71561e94ad7f24242b56ea6a80f4e5e02743a2b0c4790df3fa68d467726")
