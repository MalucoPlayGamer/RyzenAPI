-- Lua provided by RyzenAPI
-- Game: Attacker-chan!

-- MAIN APPLICATION
addappid(1931510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931511, 1, "3baa51db5da3725102102ef882d2dcd4dda17d06e44d77a0e2013b79b921e285")
