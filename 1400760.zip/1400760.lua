-- Lua provided by RyzenAPI
-- Game: My Universe - My Baby

-- MAIN APPLICATION
addappid(1400760)
-- Game: addappid(1400760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400761, 1, "3f300bd243621467165c69fd4b67b038bf672f910a179a87e47b1e0d829ddb14")
addappid(1400762, 1, "089172043bba89c6b1b1597101dcca65be0c44cf5931fd4c8b0ed5a90ed73d03")
