-- Lua provided by RyzenAPI
-- Game: Game: Freakshow:Anniversary

-- MAIN APPLICATION
addappid(763610)
-- Game: addappid(763610)

-- MAIN APP DEPOTS / PACKAGES
addappid(763611, 1, "5742b578ab4467716514b5976a0c5fd2511f607bdb2a834a13e9ee77aaea6066")
