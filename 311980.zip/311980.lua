-- Lua provided by RyzenAPI
-- Game: 311980

-- MAIN APPLICATION
addappid(311980)
-- Game: addappid(311980)

-- MAIN APP DEPOTS / PACKAGES
addappid(311981, 1, "f4887ced81c645005dd8b4763c36c81d2908379b45a696475b132a29a1cf864d")
