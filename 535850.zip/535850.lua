-- Lua provided by RyzenAPI 
-- Game: Micro Machines World Series
addappid(535850)
addappid(535851, 1, "5a20e3a95a3f65ebfcde52103516932f778626fdf6a9c86525c701ca4212d987")
addappid(535853, 1, "6634a573f3b0a4418670a7e7f2b4fc22937789bb30af71a4faa1fade808c3934")
addappid(535854, 1, "312937e94235c7d5cba66cd325ac260f528dd9a68a083b2f38c11b3a8c4f101b")
addappid(535855, 1, "9d7b999b0326be92ba311ac3f7187c0d175ed1dfe0a3d559b82c303be4b7ed15")
