-- Lua provided by RyzenAPI
-- Game: Micro Machines World Series

-- MAIN APPLICATION
addappid(535850)

-- MAIN APP DEPOTS / PACKAGES
addappid(535851, 1, "5a20e3a95a3f65ebfcde52103516932f778626fdf6a9c86525c701ca4212d987")
addappid(535853, 1, "6634a573f3b0a4418670a7e7f2b4fc22937789bb30af71a4faa1fade808c3934")
addappid(535854, 1, "312937e94235c7d5cba66cd325ac260f528dd9a68a083b2f38c11b3a8c4f101b")
addappid(535855, 1, "9d7b999b0326be92ba311ac3f7187c0d175ed1dfe0a3d559b82c303be4b7ed15")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(612340)
