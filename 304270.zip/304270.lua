-- Lua provided by RyzenAPI
-- Game: AppID 304270

-- MAIN APPLICATION
addappid(304270)
addappid(313710)
addappid(313711)
addappid(313712)
addappid(313713)

-- MAIN APP DEPOTS / PACKAGES
addappid(304271, 1, "aad6f35cb15e7114945bf1201e2f911ae15268e58efae25ed502790566fbc2f4")

