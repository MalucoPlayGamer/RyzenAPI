-- Lua provided by RyzenAPI
-- Game: Anomaly Warzone Earth Mobile Campaign

-- MAIN APPLICATION
addappid(252170)

-- MAIN APP DEPOTS / PACKAGES
addappid(252171, 1, "bd4617b544162a86f9b1713a7ea0cf8b6f83a3859b8f6c347bc323edcb2e57de")
addappid(252172, 1, "2da140adbca3b91e5a13d1a932bad9a374daa0d877aa9c6b750538225caa9507")
addappid(252173, 1, "20b6efe48ae923f10460ae1983563f58028fa74b64252e376643a4b8b96dcbec")
