-- Lua provided by RyzenAPI
-- Game: White Wings ホワイトウィングス Theme ED Song 逢瀬アキラ.ver

-- MAIN APPLICATION
addappid(1235330)
-- Game: addappid(1235330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235333,0,"01fd0154571be5e11c5cf9676b049ff009668acee30bf992188ddbe11dcb1d56")
addappid(1235334,0,"a02cd9cbd154740e7ae79e00fb98cb777ffe142d1b392694d78a09e7b54b1e1f")
