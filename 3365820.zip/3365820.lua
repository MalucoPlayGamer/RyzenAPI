-- Lua provided by RyzenAPI
-- Game: Palette Cleanser

-- MAIN APPLICATION
addappid(3365820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365821, 1, "46703b5592dba31e636862e3f368c9a79a9fe6835979ca31d4347254d083a1ec")
