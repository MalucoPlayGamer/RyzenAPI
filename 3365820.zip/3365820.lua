-- Lua provided by RyzenAPI
-- Game: Palette Cleanser

-- MAIN APPLICATION
addappid(3365820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3365821, 1, "46703b5592dba31e636862e3f368c9a79a9fe6835979ca31d4347254d083a1ec")

