-- Lua provided by RyzenAPI
-- Game: Castle In The Darkness

-- MAIN APPLICATION
addappid(262960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(262961, 1, "e2be6d1d891a934adedb54203cbba93ce99b661057c703797eac776f6fb3c171")

