-- Lua provided by RyzenAPI
-- Game: Wedding Dash® 2: Rings Around the World

-- MAIN APPLICATION
addappid(37280)

-- MAIN APP DEPOTS / PACKAGES
addappid(37281, 1, "a7d16c5d3015ac835d51a9eba00bf9b77f6cba6d60990d2b5f72c8c10500eff8")
