-- Lua provided by RyzenAPI
-- Game: Munich Bus Simulator

-- MAIN APPLICATION
addappid(283560)
-- Game: addappid(283560)

-- MAIN APP DEPOTS / PACKAGES
addappid(283561, 1, "75dd59988ffc3c9446f49a1e5cd7ffb7173f5fe8c49ef8001694821c41acc5d8")
addappid(283562, 1, "8e727720a67cc98d967d7e13bae789703aac653b06a0bbb00af8e307890b2d01")
addappid(283563, 1, "0236ce074606f74da62f8b72492ae89dfb633e3f82db5787223fe853b810b179")
addappid(283564, 1, "bc8faec36644283483e8918feb5eb50e773d613fba9c8c851dcb45e09a37b0a5")
