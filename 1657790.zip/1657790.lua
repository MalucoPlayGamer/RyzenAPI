-- Lua provided by RyzenAPI
-- Game: addappid(1657790)

-- MAIN APPLICATION
addappid(1657790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657791, 1, "da9e72a71db8f4cfa1adeb44a75bc18c758ae7181ea7f40b983791c0025f1ca4")
