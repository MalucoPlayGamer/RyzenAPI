-- Lua provided by RyzenAPI
-- Game: 812550

-- MAIN APPLICATION
addappid(812550)
-- Game: addappid(812550)

-- MAIN APP DEPOTS / PACKAGES
addappid(812551, 1, "b49990300a09fd6f1d20a0d81cefc74ae89587bd17cce8df6acdc5cefc0aa81e")
