-- Lua provided by RyzenAPI
-- Game: The King's Bird

-- MAIN APPLICATION
addappid(812550)
addappid(929160)

-- MAIN APP DEPOTS / PACKAGES
addappid(812551,0,"b49990300a09fd6f1d20a0d81cefc74ae89587bd17cce8df6acdc5cefc0aa81e")
addappid(812553,0,"8b76f12dc1b72e15b3c8ce285ca00304e7d1dde986cc7d6185891ac76899af79")

