-- Lua provided by RyzenAPI
-- Game: addappid(2454690)

-- MAIN APPLICATION
addappid(2454690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454691, 1, "4661a467eba713d58c5424a5fcb2493ff9fc8c337901633863d2d659bd1b0f81")
