-- Lua provided by RyzenAPI
-- Game: Jerry and the mystery loot box

-- MAIN APPLICATION
addappid(782700)

-- MAIN APP DEPOTS / PACKAGES
addappid(782701, 1, "2b148eb1a7bdb94554037941ad61d1520071333082ee09ab7c50ea812593ddf9")
