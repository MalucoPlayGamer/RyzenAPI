-- Lua provided by RyzenAPI
-- Game: AppID 2986960

-- MAIN APPLICATION
addappid(2986960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986961, 1, "0f844065b238a093f7f3bbb36ff59de7a09a98fa3e2fa425a51ceaa627dba536")
