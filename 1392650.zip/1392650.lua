-- Lua provided by RyzenAPI
-- Game: BLASTRONAUT

-- MAIN APPLICATION
addappid(1392650)
-- Game: addappid(1392650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392651, 1, "e2e9dcd372c89ac2c7ee1ec58c0578a7f92c960354b16bbe8ae4d39b60b5ce92")
