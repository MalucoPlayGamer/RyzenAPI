-- Lua provided by RyzenAPI
-- Game: 2260330

-- MAIN APPLICATION
addappid(2260330)
-- Game: addappid(2260330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260331, 1, "358b399d7ceb15b269a4c9d58bfaa15483fbab8e947d413298715209c6e7b972")
