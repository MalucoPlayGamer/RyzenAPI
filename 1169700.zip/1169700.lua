-- Lua provided by RyzenAPI 
-- Game: Unknown Surge Demo
addappid(1169700)
addappid(1169701, 1, "6d447a36fb9ec25b7920ca53d6e176f2b1f49e0674525f25b6343c83309006c8")
