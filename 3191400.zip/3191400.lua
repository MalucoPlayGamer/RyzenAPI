-- Lua provided by RyzenAPI
-- Game: GwenBlade: Halloween

-- MAIN APPLICATION
addappid(3191400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191401, 1, "e52a1bdb22c887ea7761341a5922ce37f4215190c3c86c7b7a2861295bf22771")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
