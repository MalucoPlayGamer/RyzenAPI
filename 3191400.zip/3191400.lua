-- Lua provided by RyzenAPI
-- Game: GwenBlade: Halloween

-- MAIN APPLICATION
addappid(3191400)
-- Game: addappid(3191400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191401, 1, "e52a1bdb22c887ea7761341a5922ce37f4215190c3c86c7b7a2861295bf22771")
