-- Lua provided by RyzenAPI
-- Game: We Who Are About To Die

-- MAIN APPLICATION
addappid(973230)
-- Game: addappid(973230)

-- MAIN APP DEPOTS / PACKAGES
addappid(973231, 1, "271e9950bea175b078726d4129a7070f696d4984c6a51f54a427bf86fc24cd75")
