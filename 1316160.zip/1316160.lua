-- Lua provided by RyzenAPI
-- Game: MEAT RPG

-- MAIN APPLICATION
addappid(1316160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316161, 1, "dff0f16524025e515fef24e34d48804507f219e84bd4b47c6eb08363b185101f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
