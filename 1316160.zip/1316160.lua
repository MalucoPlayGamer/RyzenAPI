-- Lua provided by RyzenAPI
-- Game: Game: MEAT RPG

-- MAIN APPLICATION
addappid(1316160)
-- Game: addappid(1316160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316161, 1, "dff0f16524025e515fef24e34d48804507f219e84bd4b47c6eb08363b185101f")
