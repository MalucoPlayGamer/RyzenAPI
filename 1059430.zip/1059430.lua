-- Lua provided by RyzenAPI 
-- Game: PAGAN PEAK VR
addappid(1059430)
addappid(1059431, 1, "2bb84cd5d4459bec9bdf43d33f69f42f7ab9b04c47ac559ab78f796c3a476a60")
