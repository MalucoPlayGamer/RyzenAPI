-- Lua provided by RyzenAPI
-- Game: addappid(569420)

-- MAIN APPLICATION
addappid(569420)

-- MAIN APP DEPOTS / PACKAGES
addappid(569421, 1, "aed21d898e59b05400e30d2534a06afcb19fb2ed18609c54cf679b4f71309025")
