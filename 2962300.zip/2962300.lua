-- Lua provided by RyzenAPI 
-- Game: Royal Quest Online
addappid(2962300)
addappid(2962301, 1, "4cddcd607164d3fdbda5715f4e85f536501d87cd3a802af325b0dd068a766e2d")
