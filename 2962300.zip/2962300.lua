-- Lua provided by RyzenAPI
-- Game: Royal Quest Online

-- MAIN APPLICATION
addappid(2962300)
addappid(3161090)
addappid(3161100)
addappid(3161110)
addappid(3519710)
addappid(3519720)
addappid(3519790)
addappid(3519820)
addappid(3643110)
addappid(3643120)
addappid(3643130)
addappid(3643140)
addappid(3643150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962301, 1, "4cddcd607164d3fdbda5715f4e85f536501d87cd3a802af325b0dd068a766e2d")

