-- Lua provided by RyzenAPI
-- Game: Royal Quest Online

-- MAIN APPLICATION
addappid(2962300)
-- Game: addappid(2962300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962301, 1, "4cddcd607164d3fdbda5715f4e85f536501d87cd3a802af325b0dd068a766e2d")
