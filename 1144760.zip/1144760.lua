-- Lua provided by RyzenAPI 
-- Game: AppID 1144760
addappid(1144760)
addappid(1144761, 1, "889a79089845ea379baf4766ed5041aa98cdb29c26aa239644b1feea8912db0b")
