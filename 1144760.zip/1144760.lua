-- Lua provided by RyzenAPI
-- Game: 1144760

-- MAIN APPLICATION
addappid(1144760)
-- Game: addappid(1144760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144761, 1, "889a79089845ea379baf4766ed5041aa98cdb29c26aa239644b1feea8912db0b")
