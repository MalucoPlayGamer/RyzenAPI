-- Lua provided by RyzenAPI
-- Game: AppID 1144760

-- MAIN APPLICATION
addappid(1144760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1144761, 1, "889a79089845ea379baf4766ed5041aa98cdb29c26aa239644b1feea8912db0b")

