-- Lua provided by RyzenAPI
-- Game: Game: Hidden Post-Apocalyptic Top-Down 3D

-- MAIN APPLICATION
addappid(1912710)
-- Game: addappid(1912710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912711, 1, "ec626e4485d6cd53556bfe3a105be3a4666321117d1dd60a18023e8b1990f4be")
