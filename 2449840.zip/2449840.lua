-- Lua provided by RyzenAPI
-- Game: Royalevia

-- MAIN APPLICATION
addappid(2449840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449841, 1, "0f0a9b5ba16f4f1a0ba3db6e3fc860ee3cc1c540291162f9a9a3f317972e1ccc")

