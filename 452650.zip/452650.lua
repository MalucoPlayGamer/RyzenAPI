-- Lua provided by RyzenAPI
-- Game: Game: The Rebel

-- MAIN APPLICATION
addappid(452650)
-- Game: addappid(452650)

-- MAIN APP DEPOTS / PACKAGES
addappid(452651, 1, "892919fb751bc8826a79c0c7c271fc7a5ada264ac627896e7e4c1ab13940c7cc")
