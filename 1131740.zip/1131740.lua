-- Lua provided by RyzenAPI
-- Game: AppID 1131740

-- MAIN APPLICATION
addappid(1131740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131741, 1, "a3d6eeb3f04f277a082987ff2adaf0a12f22deb03ce9c7afa142ab1a930451e8")

