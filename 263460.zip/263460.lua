-- Lua provided by RyzenAPI 
-- Game: AppID 263460
addappid(263460)
addappid(263461, 1, "b2b562c0d8b9b0efc9aabc14fb9140e07c0e9d758dad848731c778dec97f2d55")
addappid(263462, 1, "2b14ccd9e909adcdb71853c710358cb76cad89be579b90724fc93f6bc87bd312")
addappid(263463, 1, "c8f96703acdb9ab81ebe2e6de205dfc913b451b97d99754b5d5594f467b8fbed")
