-- Lua provided by RyzenAPI
-- Game: Buriedbornes - Dungeon RPG

-- MAIN APPLICATION
addappid(2153310)
-- Game: addappid(2153310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153311, 1, "4f4318d43a2c57720fd2bb803188ead448d1b888599f77294df09c95820d4756")
