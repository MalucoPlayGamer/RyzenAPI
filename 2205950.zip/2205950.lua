-- Lua provided by RyzenAPI
-- Game: Game: Witchpunk

-- MAIN APPLICATION
addappid(2205950)
-- Game: addappid(2205950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205951, 1, "c3d501e75f51361311d13e2ce6b1a8893bfc09087321791aa607ca6916c2556e")
