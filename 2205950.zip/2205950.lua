-- Lua provided by SkyAPI 
-- Game: Witchpunk
addappid(2205950)
addappid(2205951, 1, "c3d501e75f51361311d13e2ce6b1a8893bfc09087321791aa607ca6916c2556e")
