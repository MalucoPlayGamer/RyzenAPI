-- Lua provided by RyzenAPI
-- Game: Witchpunk

-- MAIN APPLICATION
addappid(2205950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205951, 1, "c3d501e75f51361311d13e2ce6b1a8893bfc09087321791aa607ca6916c2556e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
