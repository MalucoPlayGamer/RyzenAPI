-- Lua provided by RyzenAPI
-- Game: Game: 4.1.60Co

-- MAIN APPLICATION
addappid(2894980)
-- Game: addappid(2894980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894981, 1, "18d9e75c172d9640eda5c12e455e5408041fcb8bd0571c72ead838a073d9d567")
