-- Lua provided by RyzenAPI
-- Game: 4.1.60Co

-- MAIN APPLICATION
addappid(2894980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2894981, 1, "18d9e75c172d9640eda5c12e455e5408041fcb8bd0571c72ead838a073d9d567")

