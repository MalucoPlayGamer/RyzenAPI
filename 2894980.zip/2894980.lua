-- Lua provided by SkyAPI 
-- Game: 4.1.60Co
addappid(2894980)
addappid(2894981, 1, "18d9e75c172d9640eda5c12e455e5408041fcb8bd0571c72ead838a073d9d567")
