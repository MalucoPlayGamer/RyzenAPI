-- Lua provided by RyzenAPI
-- Game: Riding Club Championships

-- MAIN APPLICATION
addappid(509420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(509421, 1, "fb1d038d8acfde34dfc500aebb7e72f9c6c910fc910a5a76c0c41637dc3931fd")
addappid(509422, 1, "b52d24a995d383c70502919465d302640cdde72ecbc95974361d173204b2652f")
