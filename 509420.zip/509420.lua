-- Lua provided by RyzenAPI
-- Game: 509420

-- MAIN APPLICATION
addappid(509420)
-- Game: addappid(509420)

-- MAIN APP DEPOTS / PACKAGES
addappid(509421, 1, "fb1d038d8acfde34dfc500aebb7e72f9c6c910fc910a5a76c0c41637dc3931fd")
addappid(509422, 1, "b52d24a995d383c70502919465d302640cdde72ecbc95974361d173204b2652f")
