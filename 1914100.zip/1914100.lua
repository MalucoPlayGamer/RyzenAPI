-- Lua provided by SkyAPI 
-- Game: Wet Cute Girls
addappid(1914100)
addappid(1914101, 1, "a17159acd91da0f1dd8d58979ecc1a0b0d7afffc1312f70365898e233e9871a1")
