-- Lua provided by RyzenAPI
-- Game: Game: AppID 594350

-- MAIN APPLICATION
addappid(594350)
-- Game: addappid(594350)

-- MAIN APP DEPOTS / PACKAGES
addappid(594351, 1, "fac8baec2d927185d939c1cbc636710980cc71f697dd22e91457c99b808061ab")
