-- Lua provided by RyzenAPI
-- Game: Cyber Complex

-- MAIN APPLICATION
addappid(600440)

-- MAIN APP DEPOTS / PACKAGES
addappid(600441, 1, "3ab890a2b45354482d7e48852c39809051ed3abe56b3364bcf611bd3fa0b8ed9")
