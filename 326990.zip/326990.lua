-- Lua provided by RyzenAPI
-- Game: AppID 326990

-- MAIN APPLICATION
addappid(326990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(326991, 1, "e4754df44010162883347eb614ea4db9fbfb729f87d40ab0cfb7eb9b9477a877")
addappid(326992, 1, "24a5947c51a4e8cde352f98b80caf616b164a6a884aa22997c3165da143daa50")
addappid(326993, 1, "932b9da02bb7a6ab673a00cdd6d1cdbc991e960f31378df54e499cee4427c1a8")

