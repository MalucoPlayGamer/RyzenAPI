-- Lua provided by RyzenAPI
-- Game: Game: AppID 326990

-- MAIN APPLICATION
addappid(326990)
-- Game: addappid(326990)

-- MAIN APP DEPOTS / PACKAGES
addappid(326991, 1, "e4754df44010162883347eb614ea4db9fbfb729f87d40ab0cfb7eb9b9477a877")
addappid(326992, 1, "24a5947c51a4e8cde352f98b80caf616b164a6a884aa22997c3165da143daa50")
addappid(326993, 1, "932b9da02bb7a6ab673a00cdd6d1cdbc991e960f31378df54e499cee4427c1a8")
