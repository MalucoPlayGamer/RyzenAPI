-- Lua provided by RyzenAPI
-- Game: Game: Shattering Obsidian

-- MAIN APPLICATION
addappid(1383920)
-- Game: addappid(1383920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383921, 1, "b6dcd6d41a8c452355d593951e39ba220821a2692a87c3256dd75736f1f915a9")
