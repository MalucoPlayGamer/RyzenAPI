-- Lua provided by RyzenAPI
-- Game: Football Nation VR Tournament 2018

-- MAIN APPLICATION
addappid(752520)
-- Game: addappid(752520)

-- MAIN APP DEPOTS / PACKAGES
addappid(752521, 1, "fecfb7d1fc01c26369732e963220b469e0007b7bb7c1bdff419e03209c8f20a6")
