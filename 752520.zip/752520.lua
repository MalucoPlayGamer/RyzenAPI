-- Lua provided by RyzenAPI
-- Game: AppID 752520

-- MAIN APPLICATION
addappid(752520)

-- MAIN APP DEPOTS / PACKAGES
addappid(752521, 1, "fecfb7d1fc01c26369732e963220b469e0007b7bb7c1bdff419e03209c8f20a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
