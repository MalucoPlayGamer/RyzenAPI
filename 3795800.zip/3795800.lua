-- Lua provided by RyzenAPI
-- Game: Motel Nightmares

-- MAIN APPLICATION
addappid(3795800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795801,0,"332669dd88477c55a26eef920793d169eafc29e80d4721027a2bbd299026d145")

