-- Lua provided by RyzenAPI
-- Game: AppID 253750

-- MAIN APPLICATION
addappid(253750)
-- Game: addappid(253750)

-- MAIN APP DEPOTS / PACKAGES
addappid(253751, 1, "894f2ed777db6a237327e7ae2c93c533899146228276db2d5b5f35f52f601c77")
