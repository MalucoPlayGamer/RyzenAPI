-- Lua provided by RyzenAPI
-- Game: Ikaruga

-- MAIN APPLICATION
addappid(253750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(253751, 1, "894f2ed777db6a237327e7ae2c93c533899146228276db2d5b5f35f52f601c77")

