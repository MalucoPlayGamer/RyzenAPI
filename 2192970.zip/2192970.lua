-- Lua provided by RyzenAPI
-- Game: All On Board!

-- MAIN APPLICATION
addappid(2192970)
addappid(3058460)
addappid(3058470)
addappid(3061340)
addappid(3078860)
addappid(3078880)
addappid(3400410)
addappid(3628130)
addappid(3653210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192971,0,"088acd44456face0e6152d2001f12298b928a3a3aead5c96ab19ce6f1b4795d0")

