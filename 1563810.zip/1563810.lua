-- Lua provided by RyzenAPI
-- Game: addappid(1563810)

-- MAIN APPLICATION
addappid(1563810)
addappid(1563811)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563810,0,"921c8b47ff05e2a9d12bc803314f49049fd280f9800eded9b73c2fd44703e65f")
