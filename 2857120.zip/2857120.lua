-- Lua provided by RyzenAPI
-- Game: Rain World: The Watcher

-- MAIN APPLICATION
addappid(2857120)
-- Game: addappid(2857120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857120,0,"f998f9f9862dc3cc8026d11be949bc4d7c17882f1240b6982766721fceaae0ad")
