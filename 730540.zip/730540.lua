-- Lua provided by RyzenAPI
-- Game: addappid(730540)

-- MAIN APPLICATION
addappid(730540)

-- MAIN APP DEPOTS / PACKAGES
addappid(730541, 1, "5c12350f7bd1725279afce81e8abe2ef9c6b43a9341fc31cb674075021959371")
