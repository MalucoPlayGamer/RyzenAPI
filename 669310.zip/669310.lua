-- Lua provided by RyzenAPI
-- Game: Brave Path

-- MAIN APPLICATION
addappid(669310)

-- MAIN APP DEPOTS / PACKAGES
addappid(669311, 1, "d237a3b892dd41ec98f60b1a5efb42223a2935c5b9ff5eebc7775d40452bd952")
addappid(669312, 1, "2b7893f5f7ac800b3394b9d1f1f8cbee3bbdd187fa4f93a19367aa324d956dac")
addappid(669313, 1, "9adde7d98076ff7d4179456578975e2a4fd2edafb58c9ad32ebcf98aacdf53bf")
addappid(669314, 1, "8f3a247d09fa59f59dfc30b443f3ae83af4a2e8ff6cec46881a4efb5f652900e")

