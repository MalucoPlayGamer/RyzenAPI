-- Lua provided by RyzenAPI
-- Game: addappid(930030)

-- MAIN APPLICATION
addappid(930030)
addappid(930033)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986,0,"51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
addappid(228987,0,"cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229020,0,"efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9")
