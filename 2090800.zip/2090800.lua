-- Lua provided by RyzenAPI
-- Game: addappid(2090800)

-- MAIN APPLICATION
addappid(2090800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090801, 1, "fcd8616f75830f86e40bd4a937e0f463465a8c46b26bf08707ac206ef1ccf47a")
