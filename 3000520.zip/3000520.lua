-- Lua provided by RyzenAPI
-- Game: 3000520

-- MAIN APPLICATION
addappid(3000520)
-- Game: addappid(3000520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000521, 1, "b1f57229d85ff05cce80b3e7080afa3931c1e851be1467fed2d0aefdc8e8c66d")
