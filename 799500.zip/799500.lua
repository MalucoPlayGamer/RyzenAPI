-- Lua provided by SkyAPI 
-- Game: SurvivalZ
addappid(799500)
addappid(799501, 1, "813bb42d946b03c1d44a1f97ff4cefc3a03b3087ee1b4cfa1116642c2e30cf9f")
