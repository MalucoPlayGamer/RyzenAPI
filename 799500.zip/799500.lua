-- Lua provided by RyzenAPI
-- Game: addappid(799500)

-- MAIN APPLICATION
addappid(799500)

-- MAIN APP DEPOTS / PACKAGES
addappid(799501, 1, "813bb42d946b03c1d44a1f97ff4cefc3a03b3087ee1b4cfa1116642c2e30cf9f")
