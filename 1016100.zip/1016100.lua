-- Lua provided by RyzenAPI
-- Game: 3rd Invasion - Zombies vs. Steel

-- MAIN APPLICATION
addappid(1016100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016101, 1, "a69dba9b01679efce86a77bff398e747c461a2f76d5c7d97a495bc0d46368352")