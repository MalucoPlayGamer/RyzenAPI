-- Lua provided by RyzenAPI
-- Game: AppID 1016100

-- MAIN APPLICATION
addappid(1016100)
-- Game: addappid(1016100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016101, 1, "a69dba9b01679efce86a77bff398e747c461a2f76d5c7d97a495bc0d46368352")
