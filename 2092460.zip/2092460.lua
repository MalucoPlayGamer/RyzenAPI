-- Lua provided by RyzenAPI
-- Game: Chill Corner - Relaxing Mini Games

-- MAIN APPLICATION
addappid(2092460)
-- Game: addappid(2092460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092460,0,"15a2bf68e6796d1e82d20b0cac137b094d55086ef26514fd8233690c8dd51142")
