-- Lua provided by RyzenAPI
-- Game: Beat Saber - Linkin Park - "Bleed It Out"

-- MAIN APPLICATION
addappid(1375360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375360,0,"65d6b7583041ab4e1d608f0dd242fdf338c6e35544543ad9dfe8b8a3499d51c9")

