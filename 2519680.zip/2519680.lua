-- Lua provided by RyzenAPI 
-- Game: AppID 2519680
addappid(2519680)
addappid(2519681, 1, "efc4b66208e733165c0633eb024bb7400a340df780ea8c600a4f57f8659bc38e")
