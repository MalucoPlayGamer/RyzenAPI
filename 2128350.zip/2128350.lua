-- Lua provided by RyzenAPI
-- Game: Mythic: Frost Trials

-- MAIN APPLICATION
addappid(2128350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128351, 1, "b3500cefce0a953cbf284d59a2b5c0b487ee0f8f1e020ee687e9fef02385cbd4")
addappid(2128352, 1, "a0226db4447e4543f6cbce8086d06f7e0595e7285acb3923130b0782e3cca924")
addappid(2128353, 1, "e68e332dea2dac83f96202cef6c224eed181272c3a1d6929d2c2bb36a1cf7e0f")
addappid(2128354, 1, "fc9b29326aa819c0bf4ddd34c34ce5d23c16cb92b77d87366afad8ab8c0d47ae")
addappid(2128355, 1, "6d380ed7bcc9f253d7380ef59457e198c4179565f73d005ff6be0e84a270d408")
