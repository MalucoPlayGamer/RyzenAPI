-- Lua provided by SkyAPI 
-- Game: Frigato: Shadows of the Caribbean
addappid(1667750)
addappid(1667751, 1, "e32cf276f5071167e274981f6a65bb7ce8a30490dc2de38e97a5554a41d8f1db")
