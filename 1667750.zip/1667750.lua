-- Lua provided by RyzenAPI
-- Game: Frigato: Shadows of the Caribbean

-- MAIN APPLICATION
addappid(1667750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667751, 1, "e32cf276f5071167e274981f6a65bb7ce8a30490dc2de38e97a5554a41d8f1db")
