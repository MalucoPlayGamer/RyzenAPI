-- Lua provided by RyzenAPI
-- Game: addappid(1425980)

-- MAIN APPLICATION
addappid(1425980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425981, 1, "dde5f80538f27db019e695ddb939adb8ef447676b275f36433e3e87a4aa88e2d")
