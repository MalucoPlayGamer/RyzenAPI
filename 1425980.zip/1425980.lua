-- Lua provided by RyzenAPI
-- Game: Stone Simulator – Just Be a Rock

-- MAIN APPLICATION
addappid(1425980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1425981, 1, "dde5f80538f27db019e695ddb939adb8ef447676b275f36433e3e87a4aa88e2d")

