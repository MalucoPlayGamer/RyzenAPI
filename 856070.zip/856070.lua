-- Lua provided by RyzenAPI
-- Game: AppID 856070

-- MAIN APPLICATION
addappid(856070)

-- MAIN APP DEPOTS / PACKAGES
addappid(856071, 1, "b9a4b80c2a2340ebbc78e195dd6bded41753e9f91cde3ebce47d9ec1a409b170")
