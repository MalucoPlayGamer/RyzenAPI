-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3136430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136433,0,"dd5c146c2b9515f1a1b9246b36881527f9826bef4fc377055c78abfa82905944")
