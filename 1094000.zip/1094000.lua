-- Lua provided by RyzenAPI
-- Game: Game: AppID 1094000

-- MAIN APPLICATION
addappid(1094000)
-- Game: addappid(1094000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094001, 1, "8f739b999d94d7d85e896be1b399137e00cda3d5b11ed9ad482e07291bdc2aee")
