-- Lua provided by RyzenAPI
-- Game: Get Lost In Nature With Luke

-- MAIN APPLICATION
addappid(1601810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601811, 1, "ae8d2a6e7e045d588ffa7cfca2dfbf4221c9f96d86a0d5992fce9dba210a2e44")

