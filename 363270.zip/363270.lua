-- Lua provided by RyzenAPI
-- Game: O3DX

-- MAIN APPLICATION
addappid(363270)
-- Game: addappid(363270)

-- MAIN APP DEPOTS / PACKAGES
addappid(363271, 1, "f61564ce048e5ee3cf35a97ff985ae63adc69325868c1db4f088734e67612ae3")
addappid(363272, 1, "76b03ed632ababeba193899f0ab742d1a4cec6624be4edeef9f895ad47a63db9")
