-- Lua provided by RyzenAPI 
-- Game: Dodge Dummy
addappid(1007990)
addappid(1007991, 1, "b508c3000512f81bb31205ceb82b71d33143622a7f8f5854dc809dbb3eb3e544")
