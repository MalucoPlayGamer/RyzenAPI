-- Lua provided by RyzenAPI
-- Game: 1913490

-- MAIN APPLICATION
addappid(1913490)
-- Game: addappid(1913490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913491, 1, "3337622400ec0cccf98fe7997c2ab8655d5680d2c8f8050a94a652c8739a5c6d")
addappid(1971390, 0, "f17f0253a8be1047a2a360e2210ce776d009b2d2ebdceda953ae5d4e26dd7a8a")
