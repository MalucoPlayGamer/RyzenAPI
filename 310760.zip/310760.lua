-- Lua provided by RyzenAPI
-- Game: 310760

-- MAIN APPLICATION
addappid(310760)
-- Game: addappid(310760)

-- MAIN APP DEPOTS / PACKAGES
addappid(310761, 1, "d9a87b31812acb18cf7a2311f6186dadf5887e1d9975185feadcde99311d7e6b")
