-- Lua provided by RyzenAPI
-- Game: 徹夜報告書 | Midnight Report

-- MAIN APPLICATION
addappid(2054060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054061, 1, "c27f24ac9482728cd91e86a8e427c5b2a5ea02be01dfb53cdc24ee9caccd15b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
