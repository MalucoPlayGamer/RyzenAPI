-- Lua provided by RyzenAPI
-- Game: AppID 914920

-- MAIN APPLICATION
addappid(914920)

-- MAIN APP DEPOTS / PACKAGES
addappid(914921, 1, "4cc5eb11a78067d629ae6e2ae946af3afaffb8e5d26b532caebd001c3476baed")
