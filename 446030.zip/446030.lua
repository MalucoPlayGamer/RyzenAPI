-- Lua provided by RyzenAPI 
-- Game: Corroded
addappid(446030)
addappid(446031, 1, "8800f196e3b63e7538e02b937ebef0fab26d99a555903b9a81914fdd21cf7f98")
addappid(551660)
