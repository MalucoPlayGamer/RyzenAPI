-- Lua provided by RyzenAPI
-- Game: DJMAX RESPECT V - V Original Soundtrack

-- MAIN APPLICATION
addappid(1238761)
-- Game: addappid(1238761)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263980,0,"40a86ee0288cbbaac968f9c6f4093496a82835fb59d7ecba6eb91856fbb06f44")
addappid(1263981,0,"a7806b7f98e4c6edb6ed583eb3c9053591d8e6993a41fefef468e1788bf14795")
