-- Lua provided by RyzenAPI
-- Game: Hentai Office

-- MAIN APPLICATION
addappid(3337670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337671, 1, "9c6694d9e9d64fb30b999bed3330f44b2280b7b648e59df6fe6ae4bf5d46aed7")
