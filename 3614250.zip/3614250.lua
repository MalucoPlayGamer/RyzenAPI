-- Lua provided by RyzenAPI
-- Game: Game: AppID 3614250

-- MAIN APPLICATION
addappid(3614250)
-- Game: addappid(3614250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614251, 1, "5b07411edb0af3cff71e4e639d694254e2afb4675e50791ab0665fee40e32a76")
