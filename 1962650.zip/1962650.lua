-- Lua provided by RyzenAPI
-- Game: 1962650

-- MAIN APPLICATION
addappid(1962650)
-- Game: addappid(1962650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962651, 1, "d0bbdeaee569567a1751b168d45af45f59b467e26af5fe2c6c6a0c550d7a5598")
