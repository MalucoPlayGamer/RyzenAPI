-- Lua provided by RyzenAPI
-- Game: Kolhii ChampionsAU

-- MAIN APPLICATION
addappid(1799950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1799951, 1, "6e8f91395a9446d26332f1138fc2b4f58029d882a0cfe9ec0235f3e615f299a4")

