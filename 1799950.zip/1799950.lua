-- Lua provided by SkyAPI 
-- Game: Kolhii ChampionsAU
addappid(1799950)
addappid(1799951, 1, "6e8f91395a9446d26332f1138fc2b4f58029d882a0cfe9ec0235f3e615f299a4")
