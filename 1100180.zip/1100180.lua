-- Lua provided by RyzenAPI
-- Game: addappid(1100180)

-- MAIN APPLICATION
addappid(1100180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100181, 1, "a96ff892cfac84b1fd23adfa9732f5a3ce8852f96058bceabb0ae6cfb6f31ac2")
