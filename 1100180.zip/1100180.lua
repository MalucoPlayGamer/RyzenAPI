-- Lua provided by RyzenAPI
-- Game: AppID 1100180

-- MAIN APPLICATION
addappid(1100180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100181, 1, "a96ff892cfac84b1fd23adfa9732f5a3ce8852f96058bceabb0ae6cfb6f31ac2")

