-- Lua provided by RyzenAPI
-- Game: AppID 341470

-- MAIN APPLICATION
addappid(341470)

-- MAIN APP DEPOTS / PACKAGES
addappid(341471, 1, "6a3521f772a24bc815fbacdccf679c71e820b3a53af19c97996e4f8dab336842")
