-- Lua provided by RyzenAPI
-- Game: 1952422

-- MAIN APPLICATION
addappid(1952422)
-- Game: addappid(1952422)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952422,0,"488cfcd5e539b861eb7eb4fce90856a0bb1fbd8c43d6d8793aef3bfca4e42fe8")
addtoken(1952422,"11137677242205882779")
