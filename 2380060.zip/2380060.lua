-- Lua provided by RyzenAPI
-- Game: addappid(2380060)

-- MAIN APPLICATION
addappid(2380060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380060,0,"de335e484f2ff4a903e9157badf57149cf17377b7080f1a124a1ce57afae3c90")
