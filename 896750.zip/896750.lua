-- Lua provided by RyzenAPI
-- Game: Koral

-- MAIN APPLICATION
addappid(896750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(896751, 1, "45dc0b16575eabda3bc0d87ee285b6fe6c8a933f8874113b2a696a3ed332ede3")

