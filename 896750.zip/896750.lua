-- Lua provided by RyzenAPI
-- Game: Koral

-- MAIN APPLICATION
addappid(896750)

-- MAIN APP DEPOTS / PACKAGES
addappid(896751, 1, "45dc0b16575eabda3bc0d87ee285b6fe6c8a933f8874113b2a696a3ed332ede3")

