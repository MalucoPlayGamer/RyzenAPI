-- Lua provided by RyzenAPI
-- Game: addappid(567250)

-- MAIN APPLICATION
addappid(567250)

-- MAIN APP DEPOTS / PACKAGES
addappid(567251, 1, "95be5e26b4a546ebe6227dfba9e9686d3483db13222308d229005fbfde475de0")
