-- Lua provided by RyzenAPI
-- Game: Dungeons And Cat

-- MAIN APPLICATION
addappid(4976560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526540, 1, "9286b25dfed5fdb048dc63c19d896a3ea4b6b353e6e006f41598d42708aaef23") -- Dungeons And Cat
addappid(1526541, 1, "5077549283abbbd1ced0cbe735ed8a17e35e8761c8f40698f13f38719182937f") -- Depot 1526541
addappid(4976561, 1, "047907f006b1a03713056f1772b8c162d5da40dd39333da6e5e88f4cb791d6bb") -- Dungeons And Cat - Artbook - Depot 4976561
addappid(4976562, 1, "5260ad6813eaa80e667fc28d65755c5b42fbf4259b5c972071c408841d42e9c8") -- Dungeons And Cat - Artbook - Depot 4976562
addappid(4976563, 1, "14c3a7edee83e2e911a7cd99c7e677be820039f5ce4cf646a87c3c724b5a3179") -- Dungeons And Cat - Artbook - Depot 4976563
addappid(4976564, 1, "d43dbfbf1177f14546d0e5c4f9c49e4664b0e411a9b7d27dad51d3ff01803734") -- Dungeons And Cat - Artbook - Depot 4976564
addappid(4976565, 1, "4b6a667f7e5cf7696f18104d7c82f94777bc09f58e204081caba5226aa0b40d7") -- Dungeons And Cat - Artbook - Depot 4976565

