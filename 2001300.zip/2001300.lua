-- Lua provided by RyzenAPI
-- Game: addappid(2001300)

-- MAIN APPLICATION
addappid(2001300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001301, 1, "05d92a2a2804156eaa828914c0f08cf7b4af15a5cf2936a5fd0727fcd41197b5")
