-- Lua provided by RyzenAPI
-- Game: Game: Richman 6

-- MAIN APPLICATION
addappid(2185840)
-- Game: addappid(2185840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185841, 1, "da35b7b85b3b4255120fc810e9a079b293a06a386c01cf686985514931d95bf1")
addappid(2185842, 1, "59d31ac59232f0a3014e1159b000bcbb72d1c1adecf9631efa1b556d3ff72207")
