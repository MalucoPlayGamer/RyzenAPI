-- Lua provided by RyzenAPI
-- Game: Ninja or Die: Shadow of the Sun

-- MAIN APPLICATION
addappid(2090980)
-- Game: addappid(2090980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090981, 1, "b539c20c6dcf7a93eef6e91497b68419d29f641b40d1ea7a62e929df606b51a1")
