-- Lua provided by RyzenAPI
-- Game: Journey to the West Survivor

-- MAIN APPLICATION
addappid(2450100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450101, 1, "aa0aed1317d52014a52702b97ecde6123c01dc39a27a6cd5ba5d58ef7c6a067b")
