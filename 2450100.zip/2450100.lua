-- Lua provided by RyzenAPI
-- Game: Journey to the West Survivor

-- MAIN APPLICATION
addappid(2450100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2450101, 1, "aa0aed1317d52014a52702b97ecde6123c01dc39a27a6cd5ba5d58ef7c6a067b")

