-- Lua provided by SkyAPI 
-- Game: Journey to the West Survivor
addappid(2450100)
addappid(2450101, 1, "aa0aed1317d52014a52702b97ecde6123c01dc39a27a6cd5ba5d58ef7c6a067b")
