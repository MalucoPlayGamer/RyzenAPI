-- Lua provided by RyzenAPI
-- Game: addappid(1441871)

-- MAIN APPLICATION
addappid(1441871)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441871,0,"e3bcaee32172aa42243492c02be9c834562ebe7c4159c02b94acc9c91d5add1b")
