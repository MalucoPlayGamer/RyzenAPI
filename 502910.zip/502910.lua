-- Lua provided by RyzenAPI
-- Game: The Return Home Remastered

-- MAIN APPLICATION
addappid(502910)

-- MAIN APP DEPOTS / PACKAGES
addappid(502911, 1, "aa0bc2fe517d93996ed37e962c136489fb12ea089dedc486684e710549419808")
