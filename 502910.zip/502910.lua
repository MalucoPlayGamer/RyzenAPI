-- Lua provided by RyzenAPI
-- Game: The Return Home Remastered

-- MAIN APPLICATION
addappid(502910)

-- MAIN APP DEPOTS / PACKAGES
addappid(502911, 1, "aa0bc2fe517d93996ed37e962c136489fb12ea089dedc486684e710549419808")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
