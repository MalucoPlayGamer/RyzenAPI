-- Lua provided by RyzenAPI
-- Game: 502910

-- MAIN APPLICATION
addappid(502910)
-- Game: addappid(502910)

-- MAIN APP DEPOTS / PACKAGES
addappid(502911, 1, "aa0bc2fe517d93996ed37e962c136489fb12ea089dedc486684e710549419808")
