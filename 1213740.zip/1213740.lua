-- Lua provided by RyzenAPI
-- Game: She Will Punish Them

-- MAIN APPLICATION
addappid(1213740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213741, 1, "5d89cf41d288683ea3ad182f112aaf1d9a7c7a81ad1a53fa0d5db7cea25c6d9c")
