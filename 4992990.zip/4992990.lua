-- Lua provided by RyzenAPI
-- Game: Horny Asylum

-- MAIN APPLICATION
addappid(4992990) -- Horny Asylum

-- MAIN APP DEPOTS / PACKAGES
addappid(4992991, 1, "41892aa04e3d8cc4324187634544e85295afa3fc0c2ee10a4a1153d360ba66dd") -- Depot 4992991
