-- Lua provided by RyzenAPI 
-- Game: Rune Teller
addappid(1944360)
addappid(1944361, 1, "1059d9a1e4540fdc3a27fb81f4d60182e34022c7ebfe0136b9f9850bd1fe722a")
