-- Lua provided by RyzenAPI
-- Game: Rune Teller

-- MAIN APPLICATION
addappid(1944360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944361, 1, "1059d9a1e4540fdc3a27fb81f4d60182e34022c7ebfe0136b9f9850bd1fe722a")

