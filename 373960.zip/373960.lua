-- Lua provided by RyzenAPI
-- Game: Audiosurf 2 Demo

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228990)
addappid(373960)
addappid(373961)

-- MAIN APP DEPOTS / PACKAGES
addappid(235801,0,"2d50d6aa3194baaf82029539e52dcba19be9cd784457740a156748749860ca8c")
addappid(235802,0,"3a5ff766dc1b47d716f2be150d7cb296a9c1cc74690cbb3b5d7b9044735e4485")
addappid(235803,0,"00df363c99c0bb0618d92340f5d43ecf733390ad15c0ddc82c1d9b453e553351")

