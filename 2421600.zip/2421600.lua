-- Lua provided by RyzenAPI
-- Game: Everafter Falls Demo

-- MAIN APPLICATION
addappid(2421600)
-- Game: addappid(2421600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421601, 1, "474578e6c434904355d354cdf67713d2eae93eb51b4db1bb9786c9a83768a83f")
