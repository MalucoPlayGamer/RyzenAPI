-- Lua provided by RyzenAPI
-- Game: 625230

-- MAIN APPLICATION
addappid(625230)
-- Game: addappid(625230)

-- MAIN APP DEPOTS / PACKAGES
addappid(625231, 1, "1d755c04ac83ae06138f743ea5e9ed666bda2f1c4fd51a517bfd30efa60db329")
