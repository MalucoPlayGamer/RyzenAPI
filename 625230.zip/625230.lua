-- Lua provided by RyzenAPI
-- Game: Kiln Prototype

-- MAIN APPLICATION
addappid(625230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(625231, 1, "1d755c04ac83ae06138f743ea5e9ed666bda2f1c4fd51a517bfd30efa60db329")

