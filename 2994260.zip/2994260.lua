-- Lua provided by RyzenAPI
-- Game: Game: The Assistant Season 2

-- MAIN APPLICATION
addappid(2994260)
-- Game: addappid(2994260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994261, 1, "57d6ee75cdd996bf4ce549b40bcb64948ac430f38d1a3f4c2ec9bd751c8d06b9")
