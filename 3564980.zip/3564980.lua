-- Lua provided by RyzenAPI
-- Game: Touhou Hero of Ice Fairy - Soundtrack1 - K.O.I OVERDOSE (feat. 本墨置子)

-- MAIN APPLICATION
addappid(3564980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564981, 1, "b2f86ebf5c98143c7d7bdf50b307dc0d37ae106406dce8e709360ffb2ef74398")
addappid(3564982, 1, "9394f54c951c13e1b25d87e39aad7810789bfe0e3203366cfe05a0b10a2dc480")
