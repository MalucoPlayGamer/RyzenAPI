-- Lua provided by RyzenAPI
-- Game: 294530

-- MAIN APPLICATION
addappid(294530)
addappid(302990)
addappid(302991)
addappid(302992)
addappid(302993)
addappid(302994)
addappid(302995)
addappid(302996)
addappid(302997)
addappid(302998)
addappid(302999)
addappid(303000)
addappid(303001)
addappid(303002)
addappid(303003)
-- Game: addappid(294530)

-- MAIN APP DEPOTS / PACKAGES
addappid(294531, 1, "6531615fedbab769d6048f2efc4943f938d81182bb40e1214fcec738abcbb87f")
addappid(294534, 1, "65743bf379f6b3a4fd6f0e7dc28bc4af8220b6258a8bd12ce11174123b02ed44")
addappid(294535, 1, "79d6f6a01cbcd998e57e2f3e2fc521f2608632127c25b502b8fc3695d62d97c9")
