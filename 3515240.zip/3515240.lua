-- Lua provided by RyzenAPI
-- Game: AppID 3515240

-- MAIN APPLICATION
addappid(3515240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515241, 1, "13a69c17405a11e599fb4de29b545f30e52ddc6daffec8c34e197a045c014e4d")
