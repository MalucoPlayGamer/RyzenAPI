-- Lua provided by RyzenAPI
-- Game: The Butterfly Sign: Human Error

-- MAIN APPLICATION
addappid(555260)
-- Game: addappid(555260)

-- MAIN APP DEPOTS / PACKAGES
addappid(555261, 1, "69d7c458196b6267f68b921077211e2d86f293e9002b235b6d03d4e3e3b4ebba")
