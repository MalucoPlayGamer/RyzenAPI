-- Lua provided by RyzenAPI
-- Game: The Butterfly Sign: Human Error

-- MAIN APPLICATION
addappid(555260)

-- MAIN APP DEPOTS / PACKAGES
addappid(555261, 1, "69d7c458196b6267f68b921077211e2d86f293e9002b235b6d03d4e3e3b4ebba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
