-- Lua provided by RyzenAPI
-- Game: Afterbeat (Project Arrhythmia)

-- MAIN APPLICATION
addappid(440310)

-- MAIN APP DEPOTS / PACKAGES
addappid(440312,0,"751393c24525029f71ff78d38785beb04b3206384961c2cb01a0223eb9519f43")

