-- Lua provided by RyzenAPI
-- Game: 326470

-- MAIN APPLICATION
addappid(326470)
-- Game: addappid(326470)

-- MAIN APP DEPOTS / PACKAGES
addappid(326471, 1, "f07e47b5f362fa321db57aa282c53168b8dd6dc4724f6555ead78240ac58f303")
