-- Lua provided by RyzenAPI
-- Game: Space Warp

-- MAIN APPLICATION
addappid(326470)

-- MAIN APP DEPOTS / PACKAGES
addappid(326471, 1, "f07e47b5f362fa321db57aa282c53168b8dd6dc4724f6555ead78240ac58f303")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
