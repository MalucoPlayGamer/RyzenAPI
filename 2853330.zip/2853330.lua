-- Lua provided by RyzenAPI 
-- Game: Cordbot Demo
addappid(2853330)
addappid(2853331, 1, "6a7382b2ecf313f0a7af5ce1ff0f3dadbda13017a67352cdf80b0618c8c27f68")
