-- Lua provided by RyzenAPI
-- Game: Game: AppID 1048920

-- MAIN APPLICATION
addappid(1048920)
-- Game: addappid(1048920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048921, 1, "83136bb843cfe9ebce8626d6a51b61297f1b2a8d7db0944e3b957545de6c78b1")
addappid(1048922, 1, "a322be2c6f33f975b8d2e2f4de25e508c89f94e9901500e177a63faa61628d9b")
