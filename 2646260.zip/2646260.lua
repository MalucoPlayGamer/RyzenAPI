-- Lua provided by RyzenAPI
-- Game: 2646260

-- MAIN APPLICATION
addappid(2646260)
-- Game: addappid(2646260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646261, 1, "11351cfeab68cc9efb81b9d156a30af4b70b2b5cc63f3be48e6ff00ba99833c1")
