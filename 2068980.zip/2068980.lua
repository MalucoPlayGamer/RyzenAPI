-- Lua provided by RyzenAPI
-- Game: 2068980

-- MAIN APPLICATION
addappid(2068980)
-- Game: addappid(2068980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068981, 1, "62d6c5b3379e55de4dfb75ca89247c5a7e2141dd179cb75f3bfebeb8110d1cf2")
