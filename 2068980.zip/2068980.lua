-- Lua provided by RyzenAPI
-- Game: Escape from Grustovia

-- MAIN APPLICATION
addappid(2068980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068981, 1, "62d6c5b3379e55de4dfb75ca89247c5a7e2141dd179cb75f3bfebeb8110d1cf2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
