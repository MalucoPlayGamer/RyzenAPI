-- Lua provided by RyzenAPI
-- Game: LEGO® Indiana Jones™ 2: The Adventure Continues

-- MAIN APPLICATION
addappid(32450)

-- MAIN APP DEPOTS / PACKAGES
addappid(32451, 1, "7667a7f344fae16bd27047db8178e686f87e4a6250e76148c69b56b417e8eca6")

