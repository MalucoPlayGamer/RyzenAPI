-- Lua provided by RyzenAPI
-- Game: Dungeon Keeper™ 2

-- MAIN APPLICATION
addappid(2616460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616461, 1, "1b8b17cce3ccca8a6ab96a6d936deea7a3a3bf94424371994154b6bbfe5f54f2")
addappid(2616462, 1, "6dc493bf0743d6729ff9302c5a0be428458c41654c0268af5f2e2d7898b5ff10")
addappid(2616463, 1, "3b6cbfe54f50f405b1e063cb61ff878d26f1f77672be00fd6fb4a794be574f17")
addappid(2616464, 1, "3eb9c3eca0689137e8d36df19fc673b8fc840247cfb8d8a6be45dc97d0160c30")
addappid(2616465, 1, "5ff1ef8930bf361cb57654059bf56785fb0d73758185e755aa66afbae74ec696")
addappid(2616466, 1, "2d53f89ecf304b09c85db24f2b2862a61aa8723f7192b876aafc13efc134f328")
addappid(2616467, 1, "8deba1e65d616ff470c1fb34d173c0a588f54633677f93c59948b0e48ab2019c")
addappid(2616468, 1, "dee483c5d812be153c84b283ca120508a2ba39da75e54e110b52d4ca4513d71c")
addappid(2616469, 1, "cb7b1c282bc532fbede90d3eae52ec42d93dbf0b1528d4428b92d17d1f3f0dd7")
addappid(2741530, 0, "c504becddb918101bc69e854418bc3491dfeb15760ed0ab00f4d73dc472ad2c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
