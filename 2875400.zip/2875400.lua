-- Lua provided by SkyAPI 
-- Game: Beach Bitch
addappid(2875400)
addappid(2875401, 1, "976ff641ce5014a78c8822dd16f0f8ebde9a124b910a50925384df43c7b99d53")
