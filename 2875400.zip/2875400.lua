-- Lua provided by RyzenAPI
-- Game: 2875400

-- MAIN APPLICATION
addappid(2875400)
-- Game: addappid(2875400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875401, 1, "976ff641ce5014a78c8822dd16f0f8ebde9a124b910a50925384df43c7b99d53")
