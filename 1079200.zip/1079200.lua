-- Lua provided by RyzenAPI
-- Game: Piko Piko

-- MAIN APPLICATION
addappid(1079200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079201, 1, "1732c5d1525cf7a7573d8640ccc774449042478b83ef620478cdac6e33a214ee")

