-- Lua provided by RyzenAPI
-- Game: Valhalla Hills

-- MAIN APPLICATION
addappid(351910)
addappid(394060)
addappid(394061)
addappid(394340)
addappid(425530)
addappid(437430)
addappid(456730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(351911, 1, "3de372a720e97028a00a03955f16bf02c00045cd71a5e56cd74b875b975e0cb9")
addappid(351913, 1, "778c103bebaf3192b1d4df1492ec2d6b49c5d608f7a0d771874b1b0da4a0542a")
addappid(351914, 1, "d6045bdd9c010bb1128593d5331fb256f734cc542e453c2a7d856384f43b37ad")
addappid(351915, 1, "aa1f306bc04868ae279b90117979b76f9fbb99643492e13d522b8bc7bf3049b8")
addappid(351916, 1, "dea3ef58b2c5597f1c2848fe009c840b573197c94cbe5506a4fe5813a226a8a4")

