-- 4394300's Lua and Manifest Created by Hubcap Manifest
-- Bounce On
-- Created: June 16, 2026 at 19:58:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4394300, 1, "899e82031819c689e6aea8e2ecdcdf80b0ad8c66bb7745fdff877dee497547ac") -- Bounce On
-- MAIN APP DEPOTS
addappid(4394301, 1, "a29af5face50d526b79a171c18e5def493bd8ed91c80f65d3bf2990ecf118019") -- Depot 4394301
setManifestid(4394301, "5762228116554133228", 62221271)
addappid(4394302, 1, "d277a2b45307bbd91f1b2763319d291bf868d2cb7d32ec17393c96b0d6cf9a4f") -- Depot 4394302
setManifestid(4394302, "694309413898814769", 90860265)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4394303) -- Depot 4394303 (empty depot)