-- Lua provided by RyzenAPI
-- Game: addappid(1962570)

-- MAIN APPLICATION
addappid(1962570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962571, 1, "1ca18b64122a45e77b46892511d9fa5afff3e63471fe4fdd832e4ccb16935f4d")
