-- Lua provided by RyzenAPI
-- Game: STOLEN CITY

-- MAIN APPLICATION
addappid(1962570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962571, 1, "1ca18b64122a45e77b46892511d9fa5afff3e63471fe4fdd832e4ccb16935f4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
