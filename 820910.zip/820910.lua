-- Lua provided by RyzenAPI
-- Game: AppID 820910

-- MAIN APPLICATION
addappid(820910)

-- MAIN APP DEPOTS / PACKAGES
addappid(820911, 1, "62107ee3ce057adeca04dfd2c927ced175500f28d529769e622c176c794f2fe3")

