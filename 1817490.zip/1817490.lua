-- Lua provided by RyzenAPI
-- Game: Poppy Playtime - Chapter 2

-- MAIN APPLICATION
addappid(1817490)
-- Game: addappid(1817490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817491, 1, "e8a0b69343b9b3297a7db08e084898fd14130435cf9b95a9e77b794a430e66a0")
