-- Lua provided by SkyAPI 
-- Game: Serious Fun Football Demo
addappid(1902000)
addappid(1902001, 1, "6b91de77cf1dc05984ef1b75adacd21ee3113e09476cc4c20ef31824613a83e1")
