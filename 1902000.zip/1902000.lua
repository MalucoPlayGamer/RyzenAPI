-- Lua provided by RyzenAPI
-- Game: 1902000

-- MAIN APPLICATION
addappid(1902000)
-- Game: addappid(1902000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902001, 1, "6b91de77cf1dc05984ef1b75adacd21ee3113e09476cc4c20ef31824613a83e1")
