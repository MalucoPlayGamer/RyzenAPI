-- Lua provided by RyzenAPI
-- Game: addappid(3314060)

-- MAIN APPLICATION
addappid(3314060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3314061, 1, "702f1538eec82128d56b61de25ef41583c24e6993df1245fee4174583cd6dda6")
