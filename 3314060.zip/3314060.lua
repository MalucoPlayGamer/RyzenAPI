-- Lua provided by RyzenAPI
-- Game: The Sims™ Legacy Collection

-- MAIN APPLICATION
addappid(3314060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3314061, 1, "702f1538eec82128d56b61de25ef41583c24e6993df1245fee4174583cd6dda6")
