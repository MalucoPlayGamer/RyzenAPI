-- Lua provided by RyzenAPI
-- Game: Beat Saber: Lady Gaga - 'Born This Way'

-- MAIN APPLICATION
addappid(1812882)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812882,0,"ad2ac82265f5d80aeed586c4c99b4f09868ef6410d4e4452e67c71384065093e")
