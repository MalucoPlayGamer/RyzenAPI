-- Lua provided by RyzenAPI 
-- Game: AppID 1739980
addappid(1739980)
addappid(1739981, 1, "c0424960e9afac829ec8c3dd227a8d6115bf3b256c9e7b80972d6bad1dfeab55")
