-- Lua provided by RyzenAPI 
-- Game: AppID 937090
addappid(937090)
addappid(937091, 1, "94f86977501761f368fcdd1a446e08cbfa99284d7243bd5ad958166c5e8a3cd5")
