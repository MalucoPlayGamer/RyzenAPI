-- Lua provided by RyzenAPI
-- Game: Game: AppID 937090

-- MAIN APPLICATION
addappid(937090)
-- Game: addappid(937090)

-- MAIN APP DEPOTS / PACKAGES
addappid(937091, 1, "94f86977501761f368fcdd1a446e08cbfa99284d7243bd5ad958166c5e8a3cd5")
