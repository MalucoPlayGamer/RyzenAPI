-- Lua provided by RyzenAPI
-- Game: Virtual Girlfriend

-- MAIN APPLICATION
addappid(3710450)
addappid(3712210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710451,0,"f0d2f8a9ad01161711adf8482779b2d5d8e7a84b2d8309113a221b1f0968455b")
addappid(3712211,0,"9e3d8db02749c7195a3cd1191e7eeb984e1290cb093e85c785ba405a151462fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4162200)
addappid(4162210)
addappid(4425110)
