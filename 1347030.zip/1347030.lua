-- Lua provided by RyzenAPI
-- Game: THE CORRIDOR

-- MAIN APPLICATION
addappid(1347030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347031, 1, "8ca7cbdedf485930a4e80a0ca31e08ba2e509a06df72baf8efa20d8b266668d6")
