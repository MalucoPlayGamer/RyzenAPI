-- Lua provided by RyzenAPI
-- Game: From Space

-- MAIN APPLICATION
addappid(1502190)
addappid(2235290)
addappid(2260110)
addappid(2260121)
addappid(2260122)
addappid(2496240)
addappid(2496250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502191, 1, "6e4a0ee6ad77c9068b0572218d8eb647f32e95f9f3ba4fc542db6760770788c5")
addappid(1502192, 1, "35b7f2dfe18b50d38bc1bc4ab3234fe63a9ec16dbaeffa7975f38408020998d9")
addappid(1502193, 1, "93a218f8334c65458719889c11a045a3b2e3d7492ea41edeb191a07073dce29a")

