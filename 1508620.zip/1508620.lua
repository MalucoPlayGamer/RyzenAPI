-- Lua provided by SkyAPI 
-- Game: AppID 1508620
addappid(1508620)
addappid(1508621, 1, "fea12357cf6cc9a0a757f19adc6ed805cd2222c3096286fad3208033b2429ebe")
