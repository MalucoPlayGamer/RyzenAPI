-- Lua provided by RyzenAPI
-- Game: 2511450

-- MAIN APPLICATION
addappid(2511450)
-- Game: addappid(2511450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511451, 1, "60933831edf670b2bb290ac8ae482961df81e6753e9aea018f3cd32dff88ceee")
