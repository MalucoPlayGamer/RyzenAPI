-- Lua provided by RyzenAPI
-- Game: Jewel Match Twilight

-- MAIN APPLICATION
addappid(2177540)
-- Game: addappid(2177540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177541, 1, "5b53ec225d8370f2c68e26329191958d48529e98330d464c28a0df038dc063df")
