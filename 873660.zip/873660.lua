-- Lua provided by RyzenAPI
-- Game: The Monsters' History Book - Classic

-- MAIN APPLICATION
addappid(873660)

-- MAIN APP DEPOTS / PACKAGES
addappid(873660,0,"365ef3927729f387843b4442b117ffe4cd392f32fac513bac6224fbd2f237786")

