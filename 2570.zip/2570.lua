-- Lua provided by RyzenAPI
-- Game: addappid(2570)

-- MAIN APPLICATION
addappid(2570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571, 1, "485b745fde25b64cfaad449d0c631c46b9a145f9adf1042e687506e8b34ecb77")
