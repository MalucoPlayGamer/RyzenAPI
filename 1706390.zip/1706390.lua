-- Lua provided by RyzenAPI
-- Game: renderB

-- MAIN APPLICATION
addappid(1706390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706391, 1, "6d7c5157297848b04de60d7bb3097dabe4a0d5f91d9e6039c0dcee733aaa5860")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
