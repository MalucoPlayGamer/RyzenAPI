-- Lua provided by RyzenAPI
-- Game: 1706390

-- MAIN APPLICATION
addappid(1706390)
-- Game: addappid(1706390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706391, 1, "6d7c5157297848b04de60d7bb3097dabe4a0d5f91d9e6039c0dcee733aaa5860")
