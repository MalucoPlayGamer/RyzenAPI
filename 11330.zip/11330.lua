-- Lua provided by RyzenAPI
-- Game: Game: Obulis

-- MAIN APPLICATION
addappid(11330)
-- Game: addappid(11330)

-- MAIN APP DEPOTS / PACKAGES
addappid(11331, 1, "0bb7439753564442428e805ed6bb551a5a1bd51a0e990d596811cecd14c09b45")
