-- Lua provided by RyzenAPI
-- Game: 2507600

-- MAIN APPLICATION
addappid(2507600)
-- Game: addappid(2507600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507601, 1, "441f4eb3d8c9d32f3df9843dd54a2073f0d01ec9b004e2b124f3d12bcd229fae")
