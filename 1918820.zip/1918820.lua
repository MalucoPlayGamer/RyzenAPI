-- Lua provided by RyzenAPI
-- Game: addappid(1918820)

-- MAIN APPLICATION
addappid(1918820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918821, 1, "24ae6f2ad712f2f8a3e9340692c4a4726e85451723e07ce8c37ee4b5f39fc852")
