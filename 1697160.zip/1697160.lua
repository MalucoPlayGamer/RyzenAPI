-- Lua provided by RyzenAPI 
-- Game: RAILGUN 500
addappid(1697160)
addappid(1697161, 1, "9aba9cb48307cd43025f7ac7f712d9ae6bebb8f254e32ec5bbd0ea44dbf897cc")
