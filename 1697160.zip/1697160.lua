-- Lua provided by RyzenAPI
-- Game: 1697160

-- MAIN APPLICATION
addappid(1697160)
-- Game: addappid(1697160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697161, 1, "9aba9cb48307cd43025f7ac7f712d9ae6bebb8f254e32ec5bbd0ea44dbf897cc")
