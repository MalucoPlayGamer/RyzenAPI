-- Lua provided by RyzenAPI
-- Game: Game: Dungeon of gain

-- MAIN APPLICATION
addappid(340030)
-- Game: addappid(340030)

-- MAIN APP DEPOTS / PACKAGES
addappid(340031, 1, "dd2f1ab8d03204a7bfa544f1a5b444f1bd8ddb5333838403e57044a241afa169")
addappid(340032, 1, "020829d1d348a5c04d8f4919d3896cc08857912c71704ed48386c68320aa56fd")
