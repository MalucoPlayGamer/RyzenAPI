-- Lua provided by RyzenAPI
-- Game: AppID 32660

-- MAIN APPLICATION
addappid(32660)

-- MAIN APP DEPOTS / PACKAGES
addappid(32661, 1, "cd3f4574eb02aa5b3a0181db8b8315b32a10c9184a5cd0366915b05a30fc81e8")

