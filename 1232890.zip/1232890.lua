-- Lua provided by RyzenAPI
-- Game: DumbBots

-- MAIN APPLICATION
addappid(1232890)
-- Game: addappid(1232890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232891, 1, "e3607029e0742ae758e6698f5eea3aef4637c7243d3d3bb19c3c801105e9e331")
