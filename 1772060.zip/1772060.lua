-- Lua provided by RyzenAPI
-- Game: Mirages

-- MAIN APPLICATION
addappid(1772060)
-- Game: addappid(1772060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772061, 1, "98ba7f024ea48db7245e62bab99d31863fa86545964ecdfde5f139b9951eb1ac")
