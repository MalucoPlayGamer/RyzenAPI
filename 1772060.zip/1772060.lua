-- Lua provided by RyzenAPI
-- Game: Mirages

-- MAIN APPLICATION
addappid(1772060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772061, 1, "98ba7f024ea48db7245e62bab99d31863fa86545964ecdfde5f139b9951eb1ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
