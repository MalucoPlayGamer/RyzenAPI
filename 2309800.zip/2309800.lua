-- Lua provided by RyzenAPI
-- Game: OVERWRITE

-- MAIN APPLICATION
addappid(2309800)
-- Game: addappid(2309800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309801, 1, "1816e0d8501ecfab6d3e468f15b068e904d24a547d16e3bb629e65ba78c05b69")
