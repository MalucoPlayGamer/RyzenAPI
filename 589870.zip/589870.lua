-- Lua provided by RyzenAPI
-- Game: Learn to Fly 3

-- MAIN APPLICATION
addappid(589870)
