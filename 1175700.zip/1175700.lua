-- Lua provided by RyzenAPI
-- Game: AppID 1175700

-- MAIN APPLICATION
addappid(1175700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1175701, 1, "e3065bd4a263a18c605660bb745c196e958a3369601e88ff189d16007f33a512")

