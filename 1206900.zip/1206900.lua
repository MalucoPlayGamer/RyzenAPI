-- Lua provided by RyzenAPI
-- Game: Physical Glitch

-- MAIN APPLICATION
addappid(1206900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206901, 1, "b5e5dd17c7c9deae4c103cb1bab9e2ce4efd3310c13db4d878341a2979b6a831")

