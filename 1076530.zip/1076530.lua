-- Lua provided by RyzenAPI
-- Game: Drop

-- MAIN APPLICATION
addappid(1076530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076531, 1, "b09cb88f781276aecf0666a27b5030c01cd91d19d9bb690be76cc8bf640bbb77")

