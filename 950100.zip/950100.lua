-- Lua provided by RyzenAPI
-- Game: PRO EVOLUTION SOCCER 2019 LITE

-- MAIN APPLICATION
addappid(950100)
addappid(951270)
addappid(951271)
addappid(951272)
addappid(951273)
addappid(951274)
addappid(951275)
addappid(951276)
addappid(951277)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(950101, 1, "1aad6216aa9c3ee3cbd7c6cb24b195d059c5fe43ed4a924deccd2e011f797b9b")
addappid(950102, 1, "5a4cc82d50191fe7aa29597f929a42fc0f68abf53157af5f01a2ea7c2f036a1f")
addappid(950105, 1, "0b1d791b7651c899b593e2bfd99d1f50c251bd776008af5b2799e20c0af6db14")

