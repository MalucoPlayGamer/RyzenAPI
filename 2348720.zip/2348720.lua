-- Lua provided by RyzenAPI
-- Game: The Dragons' Twilight III

-- MAIN APPLICATION
addappid(2348720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348721, 1, "33f89235526798e78d0e61af731baa422afa0d1dc5feedf0ee6eb925adcd6ae2")
