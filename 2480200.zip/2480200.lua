-- Lua provided by RyzenAPI
-- Game: addappid(2480200)

-- MAIN APPLICATION
addappid(2480200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480201, 1, "e5f013388d5b19d9a663c85df07d4c52d148453f22c9331adce9c45e56ded9bc")
