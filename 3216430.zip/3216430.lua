-- Lua provided by RyzenAPI
-- Game: Blue Light

-- MAIN APPLICATION
addappid(3216430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216431, 1, "1a19450ef09cab66e0a6f46a7e4dffdf58e93f1bc94b47e9a8a2d983936894a2")
