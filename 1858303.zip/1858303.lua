-- Lua provided by RyzenAPI
-- Game: 1858303

-- MAIN APPLICATION
addappid(1858303)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875570,0,"d7e899ab3ca05efed390038f0c9631d52b2342721bd6fddcee996ac41063ddba")
addappid(1875571,0,"5c476babb92b7f70ede593f5cbb5238ee98099d952c41cfb1e7d31f15895bdbb")

