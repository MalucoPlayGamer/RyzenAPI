-- Lua provided by RyzenAPI
-- Game: Star Trek Legends

-- MAIN APPLICATION
addappid(2765460) -- Star Trek Legends
addappid(2882190) -- Star Trek Legends - Enemies  Allies Content Pack
-- addappid(3307140) -- Depot 3307140 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765461, 1, "0c2486788226245b7d588974193c9a8da64c1fb9a1e3f5529a9c32166ac7b1f6") -- Depot 2765461

