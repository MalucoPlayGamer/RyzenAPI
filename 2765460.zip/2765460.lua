-- 2765460's Lua and Manifest Created by Hubcap Manifest
-- Star Trek Legends
-- Created: August 20, 2026 at 23:48:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2765460) -- Star Trek Legends
-- MAIN APP DEPOTS
addappid(2765461, 1, "0c2486788226245b7d588974193c9a8da64c1fb9a1e3f5529a9c32166ac7b1f6") -- Depot 2765461
setManifestid(2765461, "7661286344036980972", 1791347200)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2882190) -- Star Trek Legends - Enemies  Allies Content Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3307140) -- Depot 3307140 (empty depot)