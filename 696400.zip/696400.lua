-- Lua provided by RyzenAPI
-- Game: AppID 696400

-- MAIN APPLICATION
addappid(696400)

-- MAIN APP DEPOTS / PACKAGES
addappid(696401, 1, "9fb6bef9dd57af8be96d1cd94c86ebc4f67fb09429fae1233b33590d468c95c1")

