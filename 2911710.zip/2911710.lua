-- Lua provided by RyzenAPI
-- Game: Test Drive Unlimited Solar Crown Playtest

-- MAIN APPLICATION
addappid(2911710)
-- Game: addappid(2911710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911711, 1, "36ede6da4bad2ec65dda12975985265237008cef945a740151e2644d16ebb612")
