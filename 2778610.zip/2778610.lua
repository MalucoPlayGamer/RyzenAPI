-- Lua provided by RyzenAPI
-- Game: Over The Top: WWI


addappid(2778610, 1, "6e71039f7b4e48ec743d0e1d678ab832c7814d3024573b98dee49b5d2eaf7927") -- Over The Top: WWI
addappid(2778611, 1, "ffa4f7ec012fc2a39e3c7b3e800d80beba4be3ed6efb03015e5223379930c503") -- Depot 2778611
--setManifestid(2778611, "3874778553712147056", 8735022018)
addappid(4309530) -- Over the Top WWI - Supporter Pack