-- Lua provided by RyzenAPI
-- Game: // OVERDRIVE

-- MAIN APPLICATION
addappid(1784990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784991, 1, "d4ca89593ebbb9bdbc0d6cc6ffc13e18c604ccd795eaa6b3c1e6b371a7cb8014")
