-- Lua provided by RyzenAPI 
-- Game: AppID 709190
addappid(709190)
addappid(709191, 1, "fc8a77c11788f907db78dc118bd07730577e7dc2f5e722540d2695b343423de3")
