-- Lua provided by RyzenAPI
-- Game: Motesolo : No Girlfriend Since Birth

-- MAIN APPLICATION
addappid(1414180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414181, 1, "eb6604e1db93b83c18314db52dd2b6a287428f61fb146b9da2f2f972bad4840f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1635390)
