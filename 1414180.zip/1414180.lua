-- Lua provided by RyzenAPI
-- Game: Game: Motesolo : No Girlfriend Since Birth

-- MAIN APPLICATION
addappid(1414180)
-- Game: addappid(1414180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414181, 1, "eb6604e1db93b83c18314db52dd2b6a287428f61fb146b9da2f2f972bad4840f")
