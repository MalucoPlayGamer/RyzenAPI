-- Lua provided by RyzenAPI
-- Game: Astral Disorder

-- MAIN APPLICATION
addappid(2866580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866581, 1, "d12f44a2944ebcf7f17f3f55de149ff4b36b4fbef92f1a80f1a0f73087c36eea")
