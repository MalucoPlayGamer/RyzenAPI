-- Lua provided by RyzenAPI
-- Game: 3 GooCubelets Games Vol.3

-- MAIN APPLICATION
addappid(431270)

-- MAIN APP DEPOTS / PACKAGES
addappid(431271, 1, "6da24500c69522e87b806e86db6369d098ae26e6311cc62f40ba0ea1bfc42ef2")