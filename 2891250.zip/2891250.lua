-- Lua provided by RyzenAPI
-- Game: Game: Not an Aim Trainer

-- MAIN APPLICATION
addappid(2891250)
-- Game: addappid(2891250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891251, 1, "e1d2345e0d530498f53a6a520a411a468771fb2274584e4a889d51391cca3293")
