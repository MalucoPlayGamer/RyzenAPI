-- Lua provided by RyzenAPI
-- Game: Element Battle Royale

-- MAIN APPLICATION
addappid(1280100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1280101, 1, "659fb617f1ead9a475861cdd750097b049a9f951942960c9442b013404032a5d")

