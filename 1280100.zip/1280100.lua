-- Lua provided by RyzenAPI
-- Game: Element Battle Royale

-- MAIN APPLICATION
addappid(1280100)
-- Game: addappid(1280100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280101, 1, "659fb617f1ead9a475861cdd750097b049a9f951942960c9442b013404032a5d")
