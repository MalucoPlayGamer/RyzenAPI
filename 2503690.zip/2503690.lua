-- Lua provided by RyzenAPI
-- Game: Selene's Unbearable Night

-- MAIN APPLICATION
addappid(2503690)
-- Game: addappid(2503690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503691, 1, "9061ff7efd280d81ed079f63f2c25b9524722bde16a69107dcee2af770550431")
