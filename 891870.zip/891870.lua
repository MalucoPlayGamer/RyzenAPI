-- Lua provided by RyzenAPI
-- Game: King of Phoenix

-- MAIN APPLICATION
addappid(891870)

-- MAIN APP DEPOTS / PACKAGES
addappid(891872,0,"24d7914ac3ea4246f0be1e0e232f2ac173fc805b0d8f956a4110eb4f0130a65f")
addappid(891875,0,"b57ee29dfb7998af79023392b3085e896a7aa49b5601d23d11e07ffb2fea1a2c")
addappid(950640,0,"17490efbff9947896915ff717951ca10730318f1025f95c3b461949183639474")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(948970)
