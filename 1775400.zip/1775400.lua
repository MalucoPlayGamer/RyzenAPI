-- Lua provided by RyzenAPI
-- Game: Substance 3D Designer 2022

-- MAIN APPLICATION
addappid(1775400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775401, 1, "5b4f35528f01987cd8bc5f6679c1c02635a39b5f296d4e4a10457d5237cee191")

