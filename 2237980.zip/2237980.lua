-- Lua provided by RyzenAPI
-- Game: Outpath: First Journey

-- MAIN APPLICATION
addappid(2237980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237981, 1, "bc39d85d830e8b53ca3c009ce1d22ba3fbbfd718b94c845833a2f123d69018b0")
