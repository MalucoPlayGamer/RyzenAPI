-- Lua provided by RyzenAPI
-- Game: Potty Knight Saga

-- MAIN APPLICATION
addappid(2728950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728951, 1, "45fe6afb27703c7a27db3c18671adaaeab5208a6ce114f6e52eb18868a23950f")

