-- Lua provided by RyzenAPI
-- Game: 486880

-- MAIN APPLICATION
addappid(486880)
-- Game: addappid(486880)

-- MAIN APP DEPOTS / PACKAGES
addappid(486881, 1, "e6f2811cbc32221a67b47caf514e6823beaf7edf12a59b985331653b4cc11fb3")
