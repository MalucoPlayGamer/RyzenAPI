-- Lua provided by RyzenAPI
-- Game: Game: AppID 956310

-- MAIN APPLICATION
addappid(956310)
-- Game: addappid(956310)

-- MAIN APP DEPOTS / PACKAGES
addappid(956311, 1, "4d715bccb3bbc315a598157551d13e41dd947678ed7833929c3a28e2955d4476")
