-- Lua provided by RyzenAPI
-- Game: Musashi vs Cthulhu

-- MAIN APPLICATION
addappid(956310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(956311, 1, "4d715bccb3bbc315a598157551d13e41dd947678ed7833929c3a28e2955d4476")

