-- Lua provided by SkyAPI 
-- Game: AppID 956310
addappid(956310)
addappid(956311, 1, "4d715bccb3bbc315a598157551d13e41dd947678ed7833929c3a28e2955d4476")
