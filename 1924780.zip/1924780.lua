-- Lua provided by RyzenAPI
-- Game: Arzette: The Jewel of Faramore

-- MAIN APPLICATION
addappid(1924780)
addappid(3000390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924781, 1, "68446d16f80a97e620cb2de52cca0a4d82900887b615bf56572df0e66ce00469")

