-- Lua provided by RyzenAPI
-- Game: 1924780

-- MAIN APPLICATION
addappid(1924780)
addappid(3000390)
-- Game: addappid(1924780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924781, 1, "68446d16f80a97e620cb2de52cca0a4d82900887b615bf56572df0e66ce00469")
