-- Lua provided by RyzenAPI
-- Game: 3361810

-- MAIN APPLICATION
addappid(3361810)
-- Game: addappid(3361810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361811, 1, "74c9683b556ddaca5794d12d3f26666c3c6fef00562bcb2e39b1dde244c3a3b0")
