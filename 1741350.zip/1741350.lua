-- Lua provided by RyzenAPI
-- Game: Lamentum Artbook

-- MAIN APPLICATION
addappid(1741350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741351, 1, "58dfb6504ab7982f26895fff5cb700f137b5e797cf1fe965cd839e0c7052b260")
