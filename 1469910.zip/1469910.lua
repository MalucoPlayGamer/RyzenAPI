-- Lua provided by RyzenAPI
-- Game: addappid(1469910)

-- MAIN APPLICATION
addappid(1469910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469911, 1, "5ede1498ec442e31a6bcfc7cc14f07d3fd2d1e8b0a39567c0cc269ac99d668a8")
