-- Lua provided by RyzenAPI
-- Game: WATCH / 透视

-- MAIN APPLICATION
addappid(1228410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228411, 1, "48f6342cd0e8bbd3a972f527d46b14bca2f03d9116635405ceadbb003fe532bd")

