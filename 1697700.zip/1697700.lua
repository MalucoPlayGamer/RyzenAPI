-- Lua provided by RyzenAPI
-- Game: Who's Lila?

-- MAIN APPLICATION
addappid(1697700)
addappid(1731330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697703,0,"a52115e18f8142e6d7322d55ae3d6ef18c012b798d8f264d4b1f57a300a0fd7c")

