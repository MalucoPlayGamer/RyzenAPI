-- Lua provided by RyzenAPI
-- Game: 最后的修仙者

-- MAIN APPLICATION
addappid(3486240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486241, 1, "a164389c120eaec1ad988654e1865803b19b5e9c7b746a3abe9b4cedf6bbb143")
