-- Lua provided by SkyAPI 
-- Game: 最后的修仙者
addappid(3486240)
addappid(3486241, 1, "a164389c120eaec1ad988654e1865803b19b5e9c7b746a3abe9b4cedf6bbb143")
