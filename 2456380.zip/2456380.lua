-- Lua provided by RyzenAPI
-- Game: addappid(2456380)

-- MAIN APPLICATION
addappid(2456380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456382,0,"fdc75fa37fafbcbda7152756dda773f5328a158897da9b3f2ba9d74a685c0ff0")
