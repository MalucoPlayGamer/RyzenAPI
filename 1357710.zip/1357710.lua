-- Lua provided by RyzenAPI
-- Game: AppID 1357710

-- MAIN APPLICATION
addappid(1357710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357711, 1, "be7d447f414eb1dedcd680d2ce47c1a6eeaec335a393c62a808d12a1f96b5b62")
