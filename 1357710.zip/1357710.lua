-- Lua provided by RyzenAPI
-- Game: Excalibots

-- MAIN APPLICATION
addappid(1357710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1357711, 1, "be7d447f414eb1dedcd680d2ce47c1a6eeaec335a393c62a808d12a1f96b5b62")
