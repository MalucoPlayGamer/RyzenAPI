-- Lua provided by RyzenAPI
-- Game: Maze Art: Brown

-- MAIN APPLICATION
addappid(1816410)
-- Game: addappid(1816410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816411, 1, "1a3bd9ba222458adf3fbfb79b0e9c83e249141e71aae371dce28c79bdaec677c")
