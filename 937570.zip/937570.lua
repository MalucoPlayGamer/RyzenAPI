-- Lua provided by RyzenAPI
-- Game: 937570

-- MAIN APPLICATION
addappid(937570)
-- Game: addappid(937570)

-- MAIN APP DEPOTS / PACKAGES
addappid(937571, 1, "302f0c31b38b2dfeefd1e53f6ff551cf0f91ab5e4ec8f7d774cc63961751dc1c")
