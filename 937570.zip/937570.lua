-- Lua provided by RyzenAPI
-- Game: Danmaku Amanojaku ~ Impossible Spell Card.

-- MAIN APPLICATION
addappid(937570)

-- MAIN APP DEPOTS / PACKAGES
addappid(937571, 1, "302f0c31b38b2dfeefd1e53f6ff551cf0f91ab5e4ec8f7d774cc63961751dc1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
