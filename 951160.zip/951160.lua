-- Lua provided by RyzenAPI 
-- Game: JUMP UP
addappid(951160)
addappid(951161, 1, "af3b648d1825884760b52569aecec0a9ad6626697e52599a7ba57bb33f5b5942")
