-- Lua provided by RyzenAPI
-- Game: JUMP UP

-- MAIN APPLICATION
addappid(951160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(951161, 1, "af3b648d1825884760b52569aecec0a9ad6626697e52599a7ba57bb33f5b5942")

