-- Lua provided by RyzenAPI
-- Game: Yuzi Lims: anime runner

-- MAIN APPLICATION
addappid(776550)

-- MAIN APP DEPOTS / PACKAGES
addappid(776551, 1, "ea92c35e13872c1ded32a6ce9d6f814e016cc9597c5102253be37b76744e96c7")

