-- Lua provided by RyzenAPI
-- Game: 3054720

-- MAIN APPLICATION
addappid(3054720)
-- Game: addappid(3054720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054721, 1, "0e9c8835b46d507846a338368c00e552acdcd9ff4a51a0e8b6762d4b08befd3f")
