-- Lua provided by RyzenAPI
-- Game: Fishing for cats

-- MAIN APPLICATION
addappid(3054720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054721, 1, "0e9c8835b46d507846a338368c00e552acdcd9ff4a51a0e8b6762d4b08befd3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
