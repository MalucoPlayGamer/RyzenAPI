-- Lua provided by RyzenAPI
-- Game: Facteroids

-- MAIN APPLICATION
addappid(1626530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626531, 1, "882a14661268b08708d0084b5ac86292b639d84ac9026aaa6d899103dd18e77a")

