-- Lua provided by RyzenAPI
-- Game: 1425130

-- MAIN APPLICATION
addappid(1425130)
-- Game: addappid(1425130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425132,0,"617ab6edb9568ee12baabf67b17a91292866e3bd154fe5397ad410a650f6c8b1")
