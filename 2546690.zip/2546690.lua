-- Lua provided by RyzenAPI
-- Game: Tram Simulator Urban Transit

-- MAIN APPLICATION
addappid(2546690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2546691, 1, "3c1a0f11f287aa5e650e4ba6a09559d978698c143e8f8119238ac4f564bccc84")

