-- Lua provided by RyzenAPI
-- Game: AppID 627620

-- MAIN APPLICATION
addappid(627620)
-- Game: addappid(627620)

-- MAIN APP DEPOTS / PACKAGES
addappid(627621, 1, "59045552194baced9dc6f46284e2cda6bb33ac21eb5c12c1677c7173497892b3")
addappid(627622, 1, "426813d6458784276e125bbce65ef45134986ebf9c7864cd530d8cb22d3b330b")
addappid(627623, 1, "c10ca0c3f3c209c5c11b96bc9c6e9d4fa8a8508932e97e18effc7fdc50a3514b")
addappid(627624, 1, "3047b6b71cb21d3712dea06fda2bdb2a71ae8c6dcdeae0b08f6e769bcb1517ae")
