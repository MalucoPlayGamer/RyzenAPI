-- Lua provided by RyzenAPI
-- Game: Farming Simulator 2013 Titanium Edition

-- MAIN APPLICATION
addappid(220260)

-- MAIN APP DEPOTS / PACKAGES
addappid(220261, 1, "3965196d9a5c66a08205c27ce03ddc547e7cdacf2e75e4a69c12a49ad0c032a4")
addappid(220285, 0, "2798660956f4a694fa4b58833f223bba2536433bcb6238e6062c744632584df9")
addappid(245220, 0, "de851e0e25386c5d24ebe938a7d9d07de9187ed8049c2a0c091f8790c48aff9c")
addappid(246010, 0, "f32f420e62e39fb1259615775c341c3cae25c931fc5fe0cc0b058f36d34c330d")
addappid(246030, 0, "b6c18d4cc45b560e995094210f9c084e423ade41427c7914785f62326a5bb5c6")
addappid(246050, 0, "d67c4b89ef0518341b71445c948de37a451f49553dce4237b684e426f818bd29")
addappid(279090, 0, "f034f9b3b2f5e53820916ee30e4720883e6d5044afc3de3936791163f41566f0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(220280)
