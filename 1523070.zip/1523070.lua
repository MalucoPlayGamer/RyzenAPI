-- Lua provided by RyzenAPI
-- Game: 1523070

-- MAIN APPLICATION
addappid(1523070)
-- Game: addappid(1523070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523070,0,"68784f347bbf72ed702c5e42990eab385134d2fe6f7b001810b8c39ed213ef5c")
