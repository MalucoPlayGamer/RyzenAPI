-- Lua provided by RyzenAPI
-- Game: 727910

-- MAIN APPLICATION
addappid(727910)
-- Game: addappid(727910)

-- MAIN APP DEPOTS / PACKAGES
addappid(727911, 1, "7eccf67e49c0735977a21745ef89ada1cb13223906db6d4499825e978faf2366")
