-- Lua provided by SkyAPI 
-- Game: AppID 1023570
addappid(1023570)
addappid(1023571, 1, "836b29ca844931fb8f52a7278232ac1dad33938639d197f00f5a46cc2b93f6e9")
