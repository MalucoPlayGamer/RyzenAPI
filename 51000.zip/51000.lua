-- Lua provided by RyzenAPI
-- Game: 51000

-- MAIN APPLICATION
addappid(51000)
-- Game: addappid(51000)

-- MAIN APP DEPOTS / PACKAGES
addappid(51001, 1, "2ea737d8d71783532b4eab47f42613e86d5cb1698f55f6171d764c1fbf8f5984")
