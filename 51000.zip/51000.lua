-- Lua provided by RyzenAPI
-- Game: Game: Mystery Case Files: Return to Ravenhearst™

-- MAIN APPLICATION
addappid(51000)
-- Game: addappid(51000)

-- MAIN APP DEPOTS / PACKAGES
addappid(51001, 1, "2ea737d8d71783532b4eab47f42613e86d5cb1698f55f6171d764c1fbf8f5984")
