-- Lua provided by RyzenAPI
-- Game: Game: AppID 1709460

-- MAIN APPLICATION
addappid(1709460)
-- Game: addappid(1709460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709461, 1, "02a257a18570845f67dc9d6bf2ed1e0aae635c784c6f7143d87fd6bd4e7e28f2")
addappid(1724730, 0, "a4f5abe7928cea749e57621d7e7aa1469839f71466e10f9fbebf825983e9a43c")
