-- Lua provided by RyzenAPI
-- Game: Art of Murder - FBI Confidential

-- MAIN APPLICATION
addappid(809000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809002,0,"eff85ae96f849d127fb38e8bc5a293dc94c623c72b70aacf749ca6ca6a213ac2")
addappid(809003,0,"c9a42331878d1224d0e72f503c5ffd3e1ea92c8f30b720f7824f175cb924ce28")
addappid(809005,0,"8e2930a0ed1abbdf0b97808c2dff84fc8718dfc5938b72c3d502ba0c495c7814")
addappid(809006,0,"d6b4b3992d8df3accad67ec67e26774d4e8c4f54304dfc6e9e9c81fca2e56354")
addappid(809007,0,"2e77999098267ecf3918fc0a6670e977a36b9eceed3c60ad350ec7cf6dcd423f")

