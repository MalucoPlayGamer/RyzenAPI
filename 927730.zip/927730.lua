-- Lua provided by RyzenAPI
-- Game: 3D Earth Time Lapse PC Live Wallpaper

-- MAIN APPLICATION
addappid(927730)
-- Game: addappid(927730)

-- MAIN APP DEPOTS / PACKAGES
addappid(927731, 1, "7d9fc741c99a4b219185c79d85c4ece1f58e166bae8c9abf9f5bcc54dec4582b")
