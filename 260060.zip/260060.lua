-- Lua provided by RyzenAPI
-- Game: AppID 260060

-- MAIN APPLICATION
addappid(260060)

-- MAIN APP DEPOTS / PACKAGES
addappid(260061, 1, "d535c09c13aff95d87bc050ecb50f236918559b4dad7a0715ec765b3d8f54fbb")
