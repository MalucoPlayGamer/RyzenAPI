-- Lua provided by RyzenAPI
-- Game: Game: AppID 844750

-- MAIN APPLICATION
addappid(844750)
-- Game: addappid(844750)

-- MAIN APP DEPOTS / PACKAGES
addappid(844751, 1, "6da9edaede4b6bbaf9c786305d84c734a1f815ac44c91e77be4ef49b179f7159")
