-- Lua provided by RyzenAPI
-- Game: addappid(1805530)

-- MAIN APPLICATION
addappid(1805530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805530,0,"d0691ad9b75792a1d1784e035be251a05cd0acd6151b7ae5d98caaf43028eaf9")
