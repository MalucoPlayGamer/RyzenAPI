-- Lua provided by RyzenAPI 
-- Game: AppID 732230
addappid(732230)
addappid(732231, 1, "48b398369760eeffbd0236db5963639d818f2effd2d79c23993ed013bd6d347b")
