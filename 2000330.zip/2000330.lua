-- Lua provided by RyzenAPI
-- Game: 2000330

-- MAIN APPLICATION
addappid(2000330)
-- Game: addappid(2000330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000331, 1, "bbe76c520d5d450c79c9463ec8999c1a031377d016f8427c5cb67b34f889b3f5")
