-- Lua provided by RyzenAPI
-- Game: Tesla: The Weather Man

-- MAIN APPLICATION
addappid(544380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(544381,0,"e142321cbbeb0742b1ca9dabb573206b07792e38dc2296102452f41aa69761df")

