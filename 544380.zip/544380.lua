-- Lua provided by RyzenAPI
-- Game: Tesla: The Weather Man

-- MAIN APPLICATION
addappid(544380)

-- MAIN APP DEPOTS / PACKAGES
addappid(544381,0,"e142321cbbeb0742b1ca9dabb573206b07792e38dc2296102452f41aa69761df")

