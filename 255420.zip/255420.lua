-- Lua provided by RyzenAPI
-- Game: Magic 2015 - Duels of the Planeswalkers

-- MAIN APPLICATION
addappid(255420)
addappid(265140)
addappid(265141)
addappid(265142)
addappid(265143)
addappid(265144)
addappid(265145)
addappid(265146)
addappid(265150)
addappid(312580)
addappid(326210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(255421,0,"f88f7f3f6a2ed8b993065ada11ea8abc65fd13c565039c0ee849d2aa12140383")
addappid(312580,0,"a46a6019f6e25d0d6a5912e7363d1929743c361aac18c750f3fdc120fce96525")

