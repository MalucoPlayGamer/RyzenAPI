-- Lua provided by RyzenAPI
-- Game: Magic 2015 - Duels of the Planeswalkers

-- MAIN APPLICATION
addappid(255420)
addappid(265140)
addappid(265141)
addappid(265142)
addappid(265143)
addappid(265144)
addappid(265145)
addappid(265146)
addappid(265150)
addappid(312580)
addappid(326210)

-- MAIN APP DEPOTS / PACKAGES
addappid(255421,0,"f88f7f3f6a2ed8b993065ada11ea8abc65fd13c565039c0ee849d2aa12140383")
addappid(312580,0,"a46a6019f6e25d0d6a5912e7363d1929743c361aac18c750f3fdc120fce96525")

