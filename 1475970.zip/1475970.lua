-- Lua provided by RyzenAPI
-- Game: Defentron

-- MAIN APPLICATION
addappid(1475970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475971, 1, "697fe403c0fe499530fdd706bd9175ee7ed3399bd9866c23b8b4f6135eb0cbad")
