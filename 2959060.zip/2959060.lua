-- Lua provided by RyzenAPI
-- Game: Game: AppID 2959060

-- MAIN APPLICATION
addappid(2959060)
-- Game: addappid(2959060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959061, 1, "c85628a43a65283294f3db7de61bd0e846eafb9a2b95a7c518d85391f907c112")
