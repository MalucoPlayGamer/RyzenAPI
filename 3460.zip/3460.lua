-- Lua provided by RyzenAPI 
-- Game: Talismania Deluxe
addappid(3460)
addappid(3461, 1, "d0b332b94e91489cdea7e27b457cc310ad1c1da984526e96de9c835c49984c05")
