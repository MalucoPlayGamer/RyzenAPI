-- Lua provided by RyzenAPI
-- Game: Destroy The World

-- MAIN APPLICATION
addappid(991070)

-- MAIN APP DEPOTS / PACKAGES
addappid(991071, 1, "376e3cba6fa140f619b38c03fee1e07a8baf63548a458329aeb6d9fa3b64ddb8")

