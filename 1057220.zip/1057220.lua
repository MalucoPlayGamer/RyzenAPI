-- Lua provided by SkyAPI 
-- Game: MIDI RANGER
addappid(1057220)
addappid(1057221, 1, "02060abb54db3987502dce17d2d90d23c569af0a5c1089637bb0e92d5b45786e")
