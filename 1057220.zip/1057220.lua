-- Lua provided by RyzenAPI
-- Game: Game: MIDI RANGER

-- MAIN APPLICATION
addappid(1057220)
-- Game: addappid(1057220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057221, 1, "02060abb54db3987502dce17d2d90d23c569af0a5c1089637bb0e92d5b45786e")
