-- Lua provided by RyzenAPI
-- Game: ASTLIBRA Revision

-- MAIN APPLICATION
addappid(1718570)
addappid(2669360)
-- Game: addappid(1718570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718571, 1, "5340c7c9ef95f91f6e844d2e4f42b9b9a18b873a71a20516b0a1f23cb65c86db")
addappid(2669361, 1, "d0945427a75897ebf551e5d57660b66c67e276511b1e0bef90039bf01c0e3de9")
