-- Lua provided by RyzenAPI
-- Game: addappid(1679670)

-- MAIN APPLICATION
addappid(1679670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679671, 1, "2b420d8649b79d7811296efc832cd77d9322af6559a965def81a49e8ee819b98")
