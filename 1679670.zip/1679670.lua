-- Lua provided by SkyAPI 
-- Game: Prehistoric Marine Monsters
addappid(1679670)
addappid(1679671, 1, "2b420d8649b79d7811296efc832cd77d9322af6559a965def81a49e8ee819b98")
