-- Lua provided by RyzenAPI
-- Game: Injustice™ 2

-- MAIN APPLICATION
addappid(627270)
addappid(704810)
addappid(721260)
addappid(721270)
addappid(721280)
addappid(721290)
addappid(727980)
addappid(727990)
addappid(731150)
addappid(731160)
addappid(731170)
addappid(731171)
addappid(731172)
addappid(734280)
addappid(734281)
addappid(734282)
addappid(734283)
addappid(747800)
addappid(759580)
addappid(759581)
addappid(779400)
addappid(779401)
addappid(814250)
addappid(814251)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(627271, 1, "7fa0ea96f7de44df35ea69af2de65094bb167d849e116d01707e30bb8739fb5b")
