-- Lua provided by RyzenAPI
-- Game: Game: AppID 627270

-- MAIN APPLICATION
addappid(627270)
addappid(704810)
addappid(721260)
addappid(721270)
addappid(721280)
addappid(721290)
addappid(727980)
addappid(727990)
addappid(731150)
addappid(731160)
addappid(731170)
addappid(731171)
addappid(731172)
addappid(734280)
addappid(734281)
addappid(734282)
addappid(734283)
addappid(747800)
addappid(759580)
addappid(759581)
addappid(779400)
addappid(779401)
addappid(814250)
addappid(814251)
-- Game: addappid(627270)

-- MAIN APP DEPOTS / PACKAGES
addappid(627271, 1, "7fa0ea96f7de44df35ea69af2de65094bb167d849e116d01707e30bb8739fb5b")
