-- Lua provided by RyzenAPI
-- Game: PUMPKIN PANIC

-- MAIN APPLICATION
addappid(3177920)
