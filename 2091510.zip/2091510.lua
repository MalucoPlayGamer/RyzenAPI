-- Lua provided by RyzenAPI
-- Game: TRAFFIC

-- MAIN APPLICATION
addappid(2091510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2091511, 1, "a4f7908dba502980322976d3db19035e1b08e0f62ac7e2db94fbf54718900f8e")

