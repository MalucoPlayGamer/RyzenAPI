-- Lua provided by RyzenAPI
-- Game: addappid(2091510)

-- MAIN APPLICATION
addappid(2091510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091511, 1, "a4f7908dba502980322976d3db19035e1b08e0f62ac7e2db94fbf54718900f8e")
