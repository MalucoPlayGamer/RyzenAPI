-- Lua provided by RyzenAPI
-- Game: Game: The Lawyer - Episode 1: The White Bag Demo

-- MAIN APPLICATION
addappid(2052330)
-- Game: addappid(2052330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052331, 1, "9fc81d8d08bd2450578588a4c13f7d1e5088f06e878b3d703eb8edf159f021ce")
