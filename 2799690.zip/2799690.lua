-- Lua provided by RyzenAPI 
-- Game: The Secret Atelier
addappid(2799690)
addappid(2799691, 1, "c9a31c20b8e8fb95478ef9df03a4131c471da468ed8001b788d5ffd5e349ee3e")
addappid(2855720, 0, "88612944aa6426092b7946fcab7e87462a2746b4f8698b4fb59e6e7136b78d5c")
