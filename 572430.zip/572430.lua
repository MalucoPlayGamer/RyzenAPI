-- Lua provided by RyzenAPI
-- Game: Party Hard 2

-- MAIN APPLICATION
addappid(572430)
-- Game: addappid(572430)

-- MAIN APP DEPOTS / PACKAGES
addappid(572431, 1, "2b53e94392b8a981b79126750d499399cfc511beb5dffc9c74847ec1fd014869")
addappid(572432, 1, "57c72bccec8845acdcb611313a2bafa2fdbcd332e3ad332822447220c1e0ddc5")
addappid(1192600, 0, "0db70a4129ceb2ef457473b67a795b962488879fc517bd68eac24165ac73bd41")
