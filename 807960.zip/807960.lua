-- Lua provided by RyzenAPI
-- Game: addappid(807960)

-- MAIN APPLICATION
addappid(807960)
addappid(807961)
addappid(807963)

-- MAIN APP DEPOTS / PACKAGES
addappid(807962,0,"1cfb0840c898efa6e2c73720fb2e75856cea49fed86dda92f9c10992de4c3f29")
