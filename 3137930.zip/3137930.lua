-- Lua provided by RyzenAPI
-- Game: IMPETUM

-- MAIN APPLICATION
addappid(3137930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137931, 1, "eb873bd724040bd481267f32ebe26f5b1d03e6bc811dba91898fdf01c48da20d")
