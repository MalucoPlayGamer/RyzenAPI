-- Lua provided by RyzenAPI
-- Game: addappid(2959400)

-- MAIN APPLICATION
addappid(2959400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959401, 1, "2d84a3e217aac389df0354db338801755733850fddfa724af11404a4cc75e332")
