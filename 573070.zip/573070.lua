-- Lua provided by RyzenAPI
-- Game: BAFL - Brakes Are For Losers

-- MAIN APPLICATION
addappid(573070)

-- MAIN APP DEPOTS / PACKAGES
addappid(573071, 1, "8fbe03ffa08486412b36d0e6189fa43d1299bfe49a187ce4710c2eaec46a6e18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
