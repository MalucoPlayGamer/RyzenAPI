-- Lua provided by RyzenAPI
-- Game: BAFL - Brakes Are For Losers

-- MAIN APPLICATION
addappid(573070)
-- Game: addappid(573070)

-- MAIN APP DEPOTS / PACKAGES
addappid(573071, 1, "8fbe03ffa08486412b36d0e6189fa43d1299bfe49a187ce4710c2eaec46a6e18")
