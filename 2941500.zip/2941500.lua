-- Lua provided by RyzenAPI
-- Game: FULL BET - FIGHTING CASINO -

-- MAIN APPLICATION
addappid(2941500) -- FULL BET - FIGHTING CASINO -

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2941501, 1, "ed549c2ac8b4d17682390cd0f173b2f3f9385216dd77624cfa35bf286ed2c2b2") -- Depot 2941501

