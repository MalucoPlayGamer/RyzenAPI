-- Lua provided by RyzenAPI
-- Game: Moonless Moon BGM Soundtrack

-- MAIN APPLICATION
addappid(3125450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125451, 1, "f46d5391cb5d1f449f75fe97959142a85ec3c5fbb6683bce68acc74d2a748d5d")
addappid(3125452, 1, "264c76c1b4ca73b41c15dd52f32988f00c1694f69bc233c8bb53557ac60c9187")

