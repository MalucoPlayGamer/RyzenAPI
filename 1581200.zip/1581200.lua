-- Lua provided by RyzenAPI
-- Game: Enemy Engaged 2: Desert Operations

-- MAIN APPLICATION
addappid(1581200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581201, 1, "e325bd0dac6025ba270fcca1ee8233f7188a8775d14672a5882174164cd95134")

