-- Lua provided by RyzenAPI
-- Game: 2281460

-- MAIN APPLICATION
addappid(2281460)
-- Game: addappid(2281460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281461, 1, "4453c6d5c717037505db810ef1b0c2dfbc07e533944664469425f1fbf4a867bc")
