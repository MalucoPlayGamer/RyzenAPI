-- Lua provided by RyzenAPI
-- Game: Game: AppID 852050

-- MAIN APPLICATION
addappid(852050)
-- Game: addappid(852050)

-- MAIN APP DEPOTS / PACKAGES
addappid(852051, 1, "695df4c1623a27ab86648f1c4cd15b84b5c1ea7d1c1e68fa1882e69ad62422be")
