-- Lua provided by RyzenAPI
-- Game: addappid(2613870)

-- MAIN APPLICATION
addappid(2613870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613871, 1, "b454bcd390881d775e002c4d6f73c7868711813dcd444e6fb1f1cf534b97fd69")
