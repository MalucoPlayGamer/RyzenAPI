-- Lua provided by RyzenAPI
-- Game: Game: FAIRY TAIL 2

-- MAIN APPLICATION
addappid(3002850)
-- Game: addappid(3002850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002851, 1, "e948f2d613815929e41d2ea8914218fc1071df961d38a2f8e0336060c00fdb6c")
