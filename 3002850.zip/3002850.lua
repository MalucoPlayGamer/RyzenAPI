-- Lua provided by RyzenAPI
-- Game: FAIRY TAIL 2

-- MAIN APPLICATION
addappid(3002850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002851, 1, "e948f2d613815929e41d2ea8914218fc1071df961d38a2f8e0336060c00fdb6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3193120)
addappid(3193130)
addappid(3193140)
addappid(3193160)
addappid(3193170)
addappid(3193180)
addappid(3193190)
addappid(3193200)
addappid(3193210)
addappid(3193220)
addappid(3193230)
addappid(3193240)
addappid(3193250)
addappid(3260320)
addappid(3260330)
