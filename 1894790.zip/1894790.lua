-- Lua provided by RyzenAPI
-- Game: Stones Keeper: King Aurelius

-- MAIN APPLICATION
addappid(1894790)
-- Game: addappid(1894790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894791, 1, "4ea06fcfe04ec02855bbabb77adad45206680029fd2615139356ca6fb26dedd4")
