-- Lua provided by RyzenAPI
-- Game: addappid(356831)

-- MAIN APPLICATION
addappid(356831)

-- MAIN APP DEPOTS / PACKAGES
addappid(356831,0,"3a17095556bfa4f1a5c22d454f841cb424c10e7f9ec2b771625b7fb681696b2e")
