-- Lua provided by RyzenAPI
-- Game: One Night You're Crazy

-- MAIN APPLICATION
addappid(697800)

-- MAIN APP DEPOTS / PACKAGES
addappid(697801, 1, "5b1d2bd9bee4aad35372856876e66a524bbfa0912027e4309e9ad800c2fb9d5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
