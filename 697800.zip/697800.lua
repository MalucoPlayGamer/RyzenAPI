-- Lua provided by RyzenAPI
-- Game: One Night You're Crazy

-- MAIN APPLICATION
addappid(697800)
-- Game: addappid(697800)

-- MAIN APP DEPOTS / PACKAGES
addappid(697801, 1, "5b1d2bd9bee4aad35372856876e66a524bbfa0912027e4309e9ad800c2fb9d5c")
