-- Lua provided by RyzenAPI
-- Game: Game: AppID 2777270

-- MAIN APPLICATION
addappid(2777270)
-- Game: addappid(2777270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777271, 1, "fc81fa9113717b1663576ed61bd685915e0f2113885b4b84abcfc1a2e1b23901")
