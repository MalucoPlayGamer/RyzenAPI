-- Lua provided by RyzenAPI
-- Game: Crystar - Kokoro's Mascot Costume

-- MAIN APPLICATION
addappid(1070140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070140,0,"446883a0a38bdad72dd8f9cf9f237d570d4552c952fda4a022a38c595a11607a")

