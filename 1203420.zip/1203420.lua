-- Lua provided by RyzenAPI
-- Game: Miss Neko 2

-- MAIN APPLICATION
addappid(1203420)
addappid(1777410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203421, 1, "8e8f54970011647d931a85b239b084494dcddcc887d30af95ddd72244d5a6a81")

