-- Lua provided by RyzenAPI
-- Game: 1019989

-- MAIN APPLICATION
addappid(1019989)
-- Game: addappid(1019989)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019989,0,"45ac1e458deeb336095cad5f0362c3bd7aa07123cf26408fa4fa0e943c5e7d45")
