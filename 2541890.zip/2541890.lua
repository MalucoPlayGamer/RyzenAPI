-- Lua provided by RyzenAPI
-- Game: Abnormality

-- MAIN APPLICATION
addappid(2541890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(2541891, 1, "0eabedd8c6ec1d99ce99c56c005c647ee33a6bd06bdfd4712474ec5d05e66c06")

