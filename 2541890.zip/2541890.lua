-- Lua provided by SkyAPI 
-- Game: Abnormality
addappid(2541890)
addappid(2541891, 1, "0eabedd8c6ec1d99ce99c56c005c647ee33a6bd06bdfd4712474ec5d05e66c06")
