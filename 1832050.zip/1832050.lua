-- Lua provided by RyzenAPI
-- Game: All Quiet Roads

-- MAIN APPLICATION
addappid(1832050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832051, 1, "986c2d3162000dd9477b4f02788c5b3ed7f255b4cab1168fdbc621d4265bf72e")
