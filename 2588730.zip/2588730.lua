-- Lua provided by RyzenAPI
-- Game: Ares Fighter 3

-- MAIN APPLICATION
addappid(2588730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588731, 1, "e76094e45b796ffe4a7fa52f41eb29304c37bd8140564226bd19386e1ae02e44")

