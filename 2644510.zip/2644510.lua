-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Quiet and love to be pampered, Bookworm GP-01fb

-- MAIN APPLICATION
addappid(2644510)
-- Game: addappid(2644510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644511, 1, "7196175ba74315ecf40c322e6acfb4778a1848374d3a3c0150a0f55300e15f07")
