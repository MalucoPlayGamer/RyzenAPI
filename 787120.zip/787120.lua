-- Lua provided by RyzenAPI
-- Game: addappid(787120)

-- MAIN APPLICATION
addappid(787120)

-- MAIN APP DEPOTS / PACKAGES
addappid(787121, 1, "25168e43d352f8bae27e12b32d45a7101d8d0a65bdf9b1f84df9e121e01ce86f")
