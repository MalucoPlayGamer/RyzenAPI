-- Lua provided by RyzenAPI
-- Game: addappid(1413500)

-- MAIN APPLICATION
addappid(1413500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413501, 1, "fce225386105cbae45deb838a4f164595af960e9dfaacc81347551dca03e0ef9")
