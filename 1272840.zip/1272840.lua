-- Lua provided by RyzenAPI 
-- Game: AppID 1272840
addappid(1272840)
addappid(1272841, 1, "22f634cc9d74727e72ce93a475a329d90d2bea2a12872c4af44162593858d498")
