-- Lua provided by RyzenAPI
-- Game: Game: AppID 1076780

-- MAIN APPLICATION
addappid(1076780)
-- Game: addappid(1076780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076781, 1, "3d31117e44b33ed0892d19ed2e19e96dc88243f9e059a3eb59fcdbff33247b02")
