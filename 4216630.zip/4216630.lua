-- Lua provided by RyzenAPI
-- Game: NIGHTBELL

-- MAIN APPLICATION
addappid(4216630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4216631, 1, "37324bdb624c346a5b72a64d39817e7e3f884ab7035415b90ec177b0465e6a95")

