-- Lua provided by RyzenAPI
-- Game: Creature in the Well

-- MAIN APPLICATION
addappid(852300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(852301, 1, "58fd76abc2923513b72cb68c069ca2616d75dce7cb96df1f670ef6943fab4f3a")

