-- Lua provided by RyzenAPI
-- Game: addappid(852300)

-- MAIN APPLICATION
addappid(852300)

-- MAIN APP DEPOTS / PACKAGES
addappid(852301, 1, "58fd76abc2923513b72cb68c069ca2616d75dce7cb96df1f670ef6943fab4f3a")
