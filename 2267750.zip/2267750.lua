-- Lua provided by RyzenAPI
-- Game: 2267750

-- MAIN APPLICATION
addappid(2267750)
-- Game: addappid(2267750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267752,0,"fdb8d0a17e6bd2f92e0767adcce5e65e87944bed6151ba591989104ad7f8026c")
