-- Lua provided by SkyAPI 
-- Game: Polyfury
addappid(1804980)
addappid(1804981, 1, "af810d0e87270a7b2d4d3b2ff8b3ded91c8edfad7995549113dd4cf6c5b27c29")
