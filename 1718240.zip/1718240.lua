-- Lua provided by RyzenAPI
-- Game: addappid(1718240)

-- MAIN APPLICATION
addappid(1718240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718243,0,"a6ff7afdbc7e76ff20b0110f6e0e4ad903ab0d3a49b25b840b6708dbfe571c10")
