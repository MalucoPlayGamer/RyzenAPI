-- Lua provided by SkyAPI 
-- Game: AppID 2471010
addappid(2471010)
addappid(2471011, 1, "647d8fcc6d9915e98aaffc7f1bf8b2ed6cd577e93cda6c633cb5ed079fb6fa06")
