-- Lua provided by RyzenAPI
-- Game: Game: Crab Game

-- MAIN APPLICATION
addappid(1782210)
-- Game: addappid(1782210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782211, 1, "72f79d12aaf3b30c359742921f65b0cc6a11e5b73d4003eaaaf72deb34d4ad03")
addappid(1782212, 1, "e9e7a802a146d469373ea16f1cb6f5113f1b04efa648de8709132035a17500d1")
addappid(1782213, 1, "0f69ba98e73d9fd76ebc3fd502f052df762ec1154fee189682a99370d6e5885a")
