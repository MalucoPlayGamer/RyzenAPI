-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 2023

-- MAIN APPLICATION
addappid(2171280)
addappid(2171540)
addappid(2171541)
addappid(2171542)
addappid(2171543)
addappid(2171544)
addappid(2171545)
addappid(2171546)
addappid(2171547)
addappid(2171548)
addappid(2171549)
addappid(2317500)
addappid(2317720)
addappid(2317730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171281, 1, "4fb977afeb2e29cc15fa304ac7b2ad30052a748fb22bd5e137ad3ef0eec8c93c")

