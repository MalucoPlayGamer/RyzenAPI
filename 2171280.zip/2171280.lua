-- Lua provided by RyzenAPI
-- Game: 2171280

-- MAIN APPLICATION
addappid(2171280)
-- Game: addappid(2171280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171281, 1, "4fb977afeb2e29cc15fa304ac7b2ad30052a748fb22bd5e137ad3ef0eec8c93c")
