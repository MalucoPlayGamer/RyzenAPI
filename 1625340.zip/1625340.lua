-- Lua provided by RyzenAPI
-- Game: United Assault - Battle of the Bulge

-- MAIN APPLICATION
addappid(1625340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625341, 1, "49147f586721f9b3165bea15f1cde89aa6b9c56db666957285da0497b035e4a7")
