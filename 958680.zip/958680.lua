-- Lua provided by RyzenAPI
-- Game: Game: AppID 958680

-- MAIN APPLICATION
addappid(958680)
-- Game: addappid(958680)

-- MAIN APP DEPOTS / PACKAGES
addappid(958681, 1, "00526741dfa170fba14864af28ce51ccefc1dea59d820c915f764338bc826a20")
