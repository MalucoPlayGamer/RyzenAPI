-- Lua provided by RyzenAPI 
-- Game: Rugby 22
addappid(1475850)
addappid(1475851, 1, "6e4d7b4a9be6f1ee7a5df348687ced5cf88137677915403687fad7b2d1e285e2")
