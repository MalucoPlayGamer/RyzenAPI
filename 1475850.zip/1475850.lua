-- Lua provided by RyzenAPI
-- Game: Rugby 22

-- MAIN APPLICATION
addappid(1475850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1475851, 1, "6e4d7b4a9be6f1ee7a5df348687ced5cf88137677915403687fad7b2d1e285e2")

