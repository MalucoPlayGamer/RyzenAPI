-- Lua provided by RyzenAPI
-- Game: AppID 596590

-- MAIN APPLICATION
addappid(596590)

-- MAIN APP DEPOTS / PACKAGES
addappid(596591, 1, "6dbde7db4768a008e4178f32ad8d8757cefdab7f4d225732bf48e0cf2d7eac53")

