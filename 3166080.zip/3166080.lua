-- Lua provided by RyzenAPI
-- Game: 秘境探险者Mystic Explorer Demo

-- MAIN APPLICATION
addappid(3166080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166081, 1, "99c458d16ddb60ea735ecd72f9fd6bddc175f2cee37fb7beed0c8f9ddb40d645")
