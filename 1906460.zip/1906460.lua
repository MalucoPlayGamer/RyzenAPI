-- Lua provided by RyzenAPI
-- Game: Martha Is Dead Official Soundtrack

-- MAIN APPLICATION
addappid(1906460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906461, 1, "d96f013d39186a6b6ce6fd2a8f180f26fa523bca4698dd2e5b01285ff8352217")
addappid(1906462, 1, "842db4f5c15aa8766b0556ec8e2e8f14934e171d9b0cbb18ea8accb2a2d86107")

