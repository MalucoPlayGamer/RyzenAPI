-- Lua provided by RyzenAPI
-- Game: 東方聖戦影 ～ Forlorn Souls of Wicked Past Demo

-- MAIN APPLICATION
addappid(3138390)
-- Game: addappid(3138390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138391, 1, "dbee7253534474aca079e95d17c6a58a3149903cbe92ce0c991daef75e4716e3")
