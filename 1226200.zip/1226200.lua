-- Lua provided by RyzenAPI
-- Game: 1226200

-- MAIN APPLICATION
addappid(1226200)
-- Game: addappid(1226200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226201, 1, "caaa8109ec11b7ccf1c9c0f1f1beaf9779373c377ab61c5e031c2d9e0848c2ff")
