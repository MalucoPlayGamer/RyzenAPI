-- Lua provided by RyzenAPI
-- Game: 978160

-- MAIN APPLICATION
addappid(978160)
-- Game: addappid(978160)

-- MAIN APP DEPOTS / PACKAGES
addappid(978160,0,"d5fede863e40e924b566fe85dbf421a7be1d1f0e1977b4f7281596df5643e792")
