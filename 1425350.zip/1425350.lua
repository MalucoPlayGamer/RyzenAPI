-- Lua provided by RyzenAPI
-- Game: Game: Botany Manor

-- MAIN APPLICATION
addappid(1425350)
-- Game: addappid(1425350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425351, 1, "7dc78b2d4c0e25ee0a1b7f2dd2346482e5e031e39b8493c8c14d0867df73d0ac")
