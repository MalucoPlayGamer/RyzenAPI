-- Lua provided by SkyAPI 
-- Game: Botany Manor
addappid(1425350)
addappid(1425351, 1, "7dc78b2d4c0e25ee0a1b7f2dd2346482e5e031e39b8493c8c14d0867df73d0ac")
