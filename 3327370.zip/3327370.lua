-- Lua provided by RyzenAPI
-- Game: Apricity

-- MAIN APPLICATION
addappid(3327370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327371, 1, "c430d750d447f0cd56d754fa904f2593e3c671907174e3b297a25a25bdd64a41")
