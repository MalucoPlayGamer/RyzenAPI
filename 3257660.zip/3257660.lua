-- Lua provided by RyzenAPI
-- Game: 重燃星陨Reburning meteorite Demo

-- MAIN APPLICATION
addappid(3257660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257661, 1, "2699d22f011e8add3668c2cc52e4299888695d03564746be3fe03de271cf4f51")

