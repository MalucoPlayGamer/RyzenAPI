-- Lua provided by SkyAPI 
-- Game: AppID 628200
addappid(628200)
addappid(628201, 1, "498ff898bc4ef4e331b9cf9ec856d26616f7eb633711a3a6e016baf6a3764873")
addappid(628202, 1, "f1dc7b31c48445fa881a045c9a714c318be1bf475d421650e8dfdff41d38c9f7")
