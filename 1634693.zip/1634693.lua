-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - "SAMURAI WARRIORS" Costume - Mitsuhide Akechi

-- MAIN APPLICATION
addappid(1634693)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634693,0,"54da672d7ce08907b7669f95951a5006029b9b2f58bf63deb194ad4ba95cfdb4")

