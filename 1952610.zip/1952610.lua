-- Lua provided by RyzenAPI
-- Game: Game: AppID 1952610

-- MAIN APPLICATION
addappid(1952610)
-- Game: addappid(1952610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952611, 1, "197f86867093a0058fa6886a8f73cf31bf469ac7d291eacb4c978e1814cdc4e0")
