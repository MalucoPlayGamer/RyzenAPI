-- Lua provided by RyzenAPI
-- Game: 1995740

-- MAIN APPLICATION
addappid(1995740)
-- Game: addappid(1995740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995741, 1, "22758b418be14ac44eae6eed84ffba76186df73f8174322d6420266938c520ef")
