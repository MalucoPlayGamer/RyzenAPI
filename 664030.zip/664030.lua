-- Lua provided by RyzenAPI
-- Game: Time To Walk Alone

-- MAIN APPLICATION
addappid(664030)

-- MAIN APP DEPOTS / PACKAGES
addappid(664031,0,"4501878913ac97e3d33bded75cb4120521949fa24daf0d5dc6a52148a31f0613")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
