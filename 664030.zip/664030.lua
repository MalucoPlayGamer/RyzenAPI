-- Lua provided by RyzenAPI
-- Game: Time To Walk Alone

-- MAIN APPLICATION
addappid(664030)

-- MAIN APP DEPOTS / PACKAGES
addappid(664031,0,"4501878913ac97e3d33bded75cb4120521949fa24daf0d5dc6a52148a31f0613")

