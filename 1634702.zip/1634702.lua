-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Horse "Qilin"

-- MAIN APPLICATION
addappid(1634702)
-- Game: addappid(1634702)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634702,0,"321398799fb90a44de3241b42377f08379d10455aab53baa30a161c1601f946f")
