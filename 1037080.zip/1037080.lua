-- Lua provided by RyzenAPI 
-- Game: AppID 1037080
addappid(1037080)
addappid(1037081, 1, "ad74bda855315392606bf9df77182659f5255c04a7c121eb0406fa5c3c1ede60")
