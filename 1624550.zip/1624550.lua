-- Lua provided by RyzenAPI
-- Game: Betty & Earl

-- MAIN APPLICATION
addappid(1624550)
-- Game: addappid(1624550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624552,0,"ad890e3716c6b57b1279e708d4d92b722467a859e40727c9ea4a93b55d155d0f")
