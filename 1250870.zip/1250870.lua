-- Lua provided by RyzenAPI
-- Game: Cyrano Story

-- MAIN APPLICATION
addappid(1250870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250872,0,"4785d1b2702460e59ae08a8dc33dcc71e35361ec519c996916b4fdad47ffdff6")
addappid(1250873,0,"2506de4c6a58b5d28b7c4c37246166cf12ef1fd977cf45f4fa89984ea8e6434b")

