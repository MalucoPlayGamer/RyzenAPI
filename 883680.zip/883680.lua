-- Lua provided by RyzenAPI
-- Game: 883680

-- MAIN APPLICATION
addappid(883680)
addappid(932600)
-- Game: addappid(883680)

-- MAIN APP DEPOTS / PACKAGES
addappid(883681, 1, "6f269f6cb92e0fdccfdde7b24fc800d4e4aeb89b2159923751427d736aa860f2")
addappid(883682, 1, "b58e57c1271c67b3f2bba9c22c2dbaf3f46608c11533f48a92b9efccdd24ea59")
