-- Lua provided by RyzenAPI
-- Game: Survival Quiz CITY

-- MAIN APPLICATION
addappid(1466930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1466931, 1, "93dbb20b59ae6175f8861b9891b5e160f7334a5d012337595b720a465b000bb7")
