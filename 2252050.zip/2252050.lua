-- Lua provided by RyzenAPI
-- Game: 2252050

-- MAIN APPLICATION
addappid(2252050)
-- Game: addappid(2252050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252050,0,"5deda3cb796357d4ce7581f8e00b94ecdcfc6f0c3f20fad5017f31ebe3548341")
