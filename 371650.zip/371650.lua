-- Lua provided by RyzenAPI
-- Game: COLINA: Legacy

-- MAIN APPLICATION
addappid(371650)
addappid(371651)
addappid(371653)

-- MAIN APP DEPOTS / PACKAGES
addappid(371652,0,"b14e9224f8aac103f87e01af9e32ef904dade054a990ee208d24555f32d1b927")
