-- Lua provided by RyzenAPI 
-- Game: Shmadow
addappid(397570)
addappid(397571, 1, "5254f3816e1afc9232f9a3b9bb2ae3cffdb12704c86eb9606edf2967a3eecc24")
addappid(397572, 1, "896471d9405580ede2d4c94f5d4787b372d61fedffb481a4dff6fff32fe9785b")
addappid(397573, 1, "4e4a5977964f28a9a0b23ea72cae03f9b11bdbddb0cc2c2c195aa3591fabb523")
addappid(397574, 1, "6b5befc0b81e920be4ad0f55040a0c52ca64eae43e253bfc1db11e82f5158b14")
addappid(397575, 1, "7107064dcbb5e0516604d2a68484fb277f6cf47bc2225e434cc5a6b8ccbbd416")
addappid(397576, 1, "1b4bacd6bd497dd2e18efeddfd9de074366eea7f185d2b718f084109a385a88f")
