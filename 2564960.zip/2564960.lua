-- Lua provided by RyzenAPI
-- Game: I'm on Observation Duty 8

-- MAIN APPLICATION
addappid(2564960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564961, 1, "8619ed1f833ac61628161a34d05b81a83246600139a636ce027f3b5144b68543")
