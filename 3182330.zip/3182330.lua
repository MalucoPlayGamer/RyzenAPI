-- Lua provided by RyzenAPI
-- Game: Game: Catboy Aim Trainer

-- MAIN APPLICATION
addappid(3182330)
addappid(3333910)
-- Game: addappid(3182330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182331, 1, "9ab21fe350d2aed683963d68108e4217d1d2f960d502a9667e83c9391827b215")
