-- Lua provided by RyzenAPI
-- Game: Deep Dark Fight

-- MAIN APPLICATION
addappid(764500)
-- Game: addappid(764500)

-- MAIN APP DEPOTS / PACKAGES
addappid(764501, 1, "da3f1e1e7aaed90cda18b83cf11aaa27f2ebe99e158291988a31063699dc1234")
