-- Lua provided by RyzenAPI
-- Game: Deep Dark Fight

-- MAIN APPLICATION
addappid(764500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(764501, 1, "da3f1e1e7aaed90cda18b83cf11aaa27f2ebe99e158291988a31063699dc1234")

