-- Lua provided by RyzenAPI
-- Game: 3920

-- MAIN APPLICATION
addappid(3920)
-- Game: addappid(3920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3921, 1, "c95f1b33026db9911c58c5921acbdb0b09920b80d431f977e05e298772a944a6")
