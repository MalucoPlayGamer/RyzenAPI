-- Lua provided by RyzenAPI
-- Game: Game: AppID 961240

-- MAIN APPLICATION
addappid(961240)
-- Game: addappid(961240)

-- MAIN APP DEPOTS / PACKAGES
addappid(961241, 1, "a73c90e7d8fda2a59eaf93856fbc45a824f7287d4a62de0a13d3f98ea871369b")
