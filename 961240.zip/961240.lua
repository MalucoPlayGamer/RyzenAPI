-- Lua provided by RyzenAPI
-- Game: AppID 961240

-- MAIN APPLICATION
addappid(961240)

-- MAIN APP DEPOTS / PACKAGES
addappid(961241, 1, "a73c90e7d8fda2a59eaf93856fbc45a824f7287d4a62de0a13d3f98ea871369b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(976520)
addappid(976530)
addappid(976531)
