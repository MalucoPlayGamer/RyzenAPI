-- Lua provided by RyzenAPI
-- Game: Game: Unknown Host

-- MAIN APPLICATION
addappid(3647480)
-- Game: addappid(3647480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647481, 1, "2491cc94dbb31679962e4190538d8ed21496a1773bd0d2c8aacf70df3d79ff60")
