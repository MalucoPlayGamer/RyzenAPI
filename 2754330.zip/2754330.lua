-- Lua provided by RyzenAPI
-- Game: 白昼梦 心象病院 - 设定集&前传漫画

-- MAIN APPLICATION
addappid(2754330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754330,0,"16b0a0538e3160866fbcebacce37eb2371cc2030f90e4bd37a87f0524c89542c")

