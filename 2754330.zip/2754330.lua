-- Lua provided by RyzenAPI
-- Game: addappid(2754330)

-- MAIN APPLICATION
addappid(2754330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754330,0,"16b0a0538e3160866fbcebacce37eb2371cc2030f90e4bd37a87f0524c89542c")
