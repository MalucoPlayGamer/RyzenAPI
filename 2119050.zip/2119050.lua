-- Lua provided by RyzenAPI
-- Game: Idle Vikings Clicker

-- MAIN APPLICATION
addappid(2119050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119051, 1, "e25d0bdac7739809f372261ccd1da39aaf2237e9cd018e979996a4e522175edd")
