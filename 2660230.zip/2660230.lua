-- 2660230's Lua and Manifest Created by Hubcap Manifest
-- Kill The Shadow
-- Created: August 05, 2026 at 09:27:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2660230) -- Kill The Shadow
-- MAIN APP DEPOTS
addappid(2660233, 1, "2d7a0ded92c5e4d6341702c90709bdfd4f3a8837a09d2ae094d07fe132eca0b7") -- Depot 2660233
setManifestid(2660233, "2514381908288279184", 3466696905)