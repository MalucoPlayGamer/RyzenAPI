-- Lua provided by RyzenAPI
-- Game: Kill The Shadow

-- MAIN APPLICATION
addappid(2660230) -- Kill The Shadow

-- MAIN APP DEPOTS / PACKAGES
addappid(2660233, 1, "2d7a0ded92c5e4d6341702c90709bdfd4f3a8837a09d2ae094d07fe132eca0b7") -- Depot 2660233

