-- Lua provided by RyzenAPI
-- Game: Endoparasitic 2

-- MAIN APPLICATION
addappid(2990640)
-- Game: addappid(2990640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990641, 1, "9f0b5ddf7f9014543c381b0166c730c457ca0a17d3992c626f73d9b7e860949f")
