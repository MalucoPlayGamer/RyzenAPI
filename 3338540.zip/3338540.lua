-- Lua provided by RyzenAPI
-- Game: The Great Villainess: Strategy of Lily Demo

-- MAIN APPLICATION
addappid(3338540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338541, 1, "5d7d627382083b0122856f77b7d39ff3711969cfb19645646cd5d73a3ab418a4")
