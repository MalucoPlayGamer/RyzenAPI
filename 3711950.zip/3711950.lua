-- Lua provided by RyzenAPI
-- Game: Game: Little Kingdom RTS

-- MAIN APPLICATION
addappid(3711950)
-- Game: addappid(3711950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3711951, 1, "281a6428b253ee6de0eb508c4e241c5236ff6d1665b55a81d46ff80cdd852fb5")
