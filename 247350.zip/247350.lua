-- Lua provided by RyzenAPI
-- Game: Artemis Spaceship Bridge Simulator

-- MAIN APPLICATION
addappid(247350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(247351, 1, "0f2bdcd31f7c5d5c23f4d8a0e2506c55497db6837c90d5db0679f77d1433d773")

