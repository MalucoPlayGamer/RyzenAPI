-- Lua provided by RyzenAPI
-- Game: addappid(247350)

-- MAIN APPLICATION
addappid(247350)

-- MAIN APP DEPOTS / PACKAGES
addappid(247351, 1, "0f2bdcd31f7c5d5c23f4d8a0e2506c55497db6837c90d5db0679f77d1433d773")
