-- Lua provided by RyzenAPI
-- Game: AppID 1127360

-- MAIN APPLICATION
addappid(1127360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127361, 1, "6de457b27d579beb9419a8c995146ecdf1bdb9d8c046bca74cbaa21eed10b764")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
