-- Lua provided by RyzenAPI
-- Game: addappid(1127360)

-- MAIN APPLICATION
addappid(1127360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127361, 1, "6de457b27d579beb9419a8c995146ecdf1bdb9d8c046bca74cbaa21eed10b764")
