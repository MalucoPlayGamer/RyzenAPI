-- 4163000's Lua and Manifest Created by Hubcap Manifest
-- Crypto Trading Simulator
-- Created: August 12, 2026 at 09:16:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4163000) -- Crypto Trading Simulator
-- MAIN APP DEPOTS
addappid(4163001, 1, "d9dd508f82e8afe79ef86af9153cee361abe1224860b5966e54f1660e7850423") -- Depot 4163001
setManifestid(4163001, "8583483999534571203", 760782459)