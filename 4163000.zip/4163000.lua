-- Lua provided by RyzenAPI
-- Game: Crypto Trading Simulator

-- MAIN APPLICATION
addappid(4163000) -- Crypto Trading Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4163001, 1, "d9dd508f82e8afe79ef86af9153cee361abe1224860b5966e54f1660e7850423") -- Depot 4163001

