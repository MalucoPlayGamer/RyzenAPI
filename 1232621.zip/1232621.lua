-- Lua provided by RyzenAPI
-- Game: RetroArch - PocketCDG

-- MAIN APPLICATION
addappid(1232621)
-- Game: addappid(1232621)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232621,0,"6fe61b38eac9782e2b702a3a517cb9ca07ed9f1a4b91ea78c05f5d08b075565f")
addappid(1789750,0,"f389dd8514d7420cf66a8dd5763276d3ef6f132df705b7fa0e07ad222d08fc64")
addappid(1789751,0,"2a838125521c4190e01cfa44ec3a97eb489ef4f0b8853a6899e15cac87a2bed2")
