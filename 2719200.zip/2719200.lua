-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 4 DX

-- MAIN APPLICATION
addappid(2719200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719201, 1, "fc9bc29b7a3f568c45da0e49f09ac00bfd7f6c4048029d697469d85f756124ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
