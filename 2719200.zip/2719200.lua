-- Lua provided by RyzenAPI
-- Game: 2719200

-- MAIN APPLICATION
addappid(2719200)
-- Game: addappid(2719200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719201, 1, "fc9bc29b7a3f568c45da0e49f09ac00bfd7f6c4048029d697469d85f756124ab")
