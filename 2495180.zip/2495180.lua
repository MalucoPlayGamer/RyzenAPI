-- Lua provided by RyzenAPI
-- Game: 2495180

-- MAIN APPLICATION
addappid(2495180)
-- Game: addappid(2495180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495181, 1, "3f4101f0148fb3acecd7ef7a844ee311ff530dc433c5a33ccea3e3e818548e88")
addappid(2495182, 1, "093d6961f47418fc3d86a7d513394ba21ed0ad586a6b5e9988773b2da64f0d6b")
