-- Lua provided by RyzenAPI
-- Game: Backseat Drivers

-- MAIN APPLICATION
addappid(3558400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558401, 1, "99209e260c4664fddb750252e28e3ddbb84ffa4cded64191f9c52cfd74778a32")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
