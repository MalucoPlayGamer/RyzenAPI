-- Lua provided by RyzenAPI
-- Game: Backseat Drivers

-- MAIN APPLICATION
addappid(3558400)
-- Game: addappid(3558400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558401, 1, "99209e260c4664fddb750252e28e3ddbb84ffa4cded64191f9c52cfd74778a32")
