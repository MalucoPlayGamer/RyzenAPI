-- Lua provided by RyzenAPI
-- Game: Game: The Dark Pursuer

-- MAIN APPLICATION
addappid(2404990)
-- Game: addappid(2404990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404991, 1, "f204694709556dc90c267c177fa926b68f72ca99df40778bccefbc73bda1fe90")
addappid(2404992, 1, "37fd9176971dbfa08051ba2e03e4c715275f6aea2910e0d5ae03949ae9270fce")
addappid(2404993, 1, "dbeeb22c36d35e5f7cd22e8a2947936cb762dab14709a3ed4f0c2e19f8ad0576")
