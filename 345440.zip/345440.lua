-- Lua provided by RyzenAPI
-- Game: AppID 345440

-- MAIN APPLICATION
addappid(345440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(345441, 1, "6d0463c656384a3b71201141b827322c1e12e76f586314ec8942c4fd075a05fa")
addappid(345442, 1, "06e9c41c4cc4ee84ca86034fc95be123e6bfcd185456d05520a0ebf1e50fc639")
addappid(345443, 1, "ee4179cc4727aea17a4402bc233be245457858c8e3b344ae61f5afefd02832a2")

