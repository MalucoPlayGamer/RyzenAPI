-- Lua provided by RyzenAPI 
-- Game: Knight vs Giant: The Broken Excalibur Demo
addappid(1772150)
addappid(1772151, 1, "6299f0beb4d60905d6ce7fabf02ab676eaf8ed2177d99f6e70dab961f1dc7abd")
