-- Lua provided by RyzenAPI
-- Game: addappid(1772150)

-- MAIN APPLICATION
addappid(1772150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772151, 1, "6299f0beb4d60905d6ce7fabf02ab676eaf8ed2177d99f6e70dab961f1dc7abd")
