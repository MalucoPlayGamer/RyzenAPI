-- Lua provided by RyzenAPI
-- Game: Climber Animals: Together

-- MAIN APPLICATION
addappid(2744880)
addappid(4656990)
-- Game: addappid(2744880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744881, 1, "9fd7118ee51abbec444753ac08e8c7b7f6a304d646e13948d07333d6881aa58a")
