-- Lua provided by RyzenAPI
-- Game: Hot Mars 69

-- MAIN APPLICATION
addappid(815080)
-- Game: addappid(815080)

-- MAIN APP DEPOTS / PACKAGES
addappid(815081, 1, "4863ca5f3b50b4a78f88f88179eae6b93d895453c2fbe43820fa5026dd4dc212")
