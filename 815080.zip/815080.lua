-- Lua provided by RyzenAPI
-- Game: Hot Mars 69

-- MAIN APPLICATION
addappid(815080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(815081, 1, "4863ca5f3b50b4a78f88f88179eae6b93d895453c2fbe43820fa5026dd4dc212")

