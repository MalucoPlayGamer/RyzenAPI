-- Lua provided by RyzenAPI 
-- Game: Hot Mars 69
addappid(815080)
addappid(815081, 1, "4863ca5f3b50b4a78f88f88179eae6b93d895453c2fbe43820fa5026dd4dc212")
