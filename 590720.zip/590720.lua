-- Lua provided by RyzenAPI
-- Game: Cobalt WASD

-- MAIN APPLICATION
addappid(590720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(590721, 1, "ce130e093abca50f6b25a5e649d421db9c932d58240f082bfe0d0e30ab195589")
