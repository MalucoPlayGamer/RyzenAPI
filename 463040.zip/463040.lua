-- Lua provided by RyzenAPI
-- Game: 463040

-- MAIN APPLICATION
addappid(463040)
-- Game: addappid(463040)

-- MAIN APP DEPOTS / PACKAGES
addappid(463041, 1, "ad6989848ab39b6d5b404cf3b1e6fffee524b7823e4d8f00e5c23704915a3ac8")
