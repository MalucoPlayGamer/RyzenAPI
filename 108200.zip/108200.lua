-- Lua provided by RyzenAPI
-- Game: Ticket to Ride: Classic Edition

-- MAIN APPLICATION
addappid(108200)

-- MAIN APP DEPOTS / PACKAGES
addappid(108201, 1, "e9ba76995a9cae9c10c83b8bd5e7c331105af1ddf2e0383fea2d6001ed8ec9d8")
addappid(108202, 1, "7ec47a993b5f6452416ff7dd36da26de5b48f9ccb3a37247d4e6d0c13de9c5c1")
addappid(108203, 1, "a2e0160bed4a1773c7927a4ba368f1df00b9fa4607a82a29358ab87eaded89f2")

