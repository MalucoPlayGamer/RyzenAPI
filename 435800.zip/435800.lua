-- Lua provided by RyzenAPI
-- Game: Binaries

-- MAIN APPLICATION
addappid(435800)
addappid(455670)

-- MAIN APP DEPOTS / PACKAGES
addappid(435801, 1, "a6cbfcd78acf1c34c5d87b3778d33831f9b0098c785bf78633cb55305def9081")
addappid(435802, 1, "feba2d7fefa7b6fde68927414aeb82e45cabdcfd7b59fe5557a46a060a7ea063")
addappid(435803, 1, "7668c610c19dcc84ebd41e47647f1717e2ecaf9e2cd79146b824ec8e8c234678")
addappid(435804, 1, "c0da05361b2095803492c8212744f8357dbf8475ef6b6bbc4ac9287fbe283338")

