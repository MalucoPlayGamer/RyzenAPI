-- Lua provided by RyzenAPI
-- Game: AppID 429600

-- MAIN APPLICATION
addappid(429600)
-- Game: addappid(429600)

-- MAIN APP DEPOTS / PACKAGES
addappid(429601, 1, "c717a1e421acc22da4d16833043fe8a18ac1eaff7368981cc75506b5f1b1694d")
