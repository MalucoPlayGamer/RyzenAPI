-- Lua provided by RyzenAPI
-- Game: Game: Borderlands Game of the Year

-- MAIN APPLICATION
addappid(8980)
-- Game: addappid(8980)

-- MAIN APP DEPOTS / PACKAGES
addappid(8981, 1, "b813bb372a074de0a66e034d403e05e79165d0b16e467aa77e2157444ab49d92")
addappid(8982, 1, "16f51eda05af92ef426257cdaf0b22d351d2a2353c34fb897ab5abbc4314d3af")
addappid(8983, 1, "e642be0cabacebd5dd63fabf4e8c89cd64a0d2f35f7aa46fd5e98abf1cc33169")
addappid(8984, 1, "e8307f132a753a4f61c668cbc0d0bc76f4d0357594123a422f610f7d4e599b92")
addappid(8985, 1, "abe026b01af53a35b15d0ebd0539e5fc31f5b78235fbd264e4c746ddefdc3570")
addappid(8991, 1, "fb5fc9aa2607f09225e79d4ce75f788ec3b5e2ad14e6861f1b998c65296a16a7")
addappid(40941, 0, "b2b98d74b813b610f4aa3d6bb496a6555d493b10adc701bad6074f76ad92a010")
addappid(50111, 0, "e82241e83340673dffd6be64e2c1c5463d09bf6abb4dba31b6c294373de7f9b4")
addappid(65921, 0, "51ca609ed59842aa0f61862794e50644fc1e0e79cfea891d8b31f6f72d844c0f")
addappid(65959, 0, "dea70be04fade2bcd154f568d15fd0e9b3781c681f2f2fc29d83e3500d6207e0")
