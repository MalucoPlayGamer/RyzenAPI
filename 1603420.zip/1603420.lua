-- Lua provided by RyzenAPI
-- Game: Doomsday Paradise

-- MAIN APPLICATION
addappid(1603420)
-- Game: addappid(1603420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603421, 1, "4f1153a2b69a1855511ed8e8ecf160670b3bbe73efdd1848e907e74cf1271785")
