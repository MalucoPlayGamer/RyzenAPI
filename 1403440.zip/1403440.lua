-- Lua provided by RyzenAPI 
-- Game: AppID 1403440
addappid(1403440)
addappid(1403441, 1, "3c23cb1c33880bba9cadca7970a8aafed295fe21bed3d9a3c20fbd8911a914e1")
