-- Lua provided by RyzenAPI
-- Game: Hotel Business Simulator

-- MAIN APPLICATION
addappid(2738870)
-- Game: addappid(2738870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738871, 1, "664145979e274d395ffc16541eae1429a1b95a05f21965adecf1ae634c6b31b6")
