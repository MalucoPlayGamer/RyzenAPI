-- Lua provided by RyzenAPI
-- Game: Victory At Sea Pacific

-- MAIN APPLICATION
addappid(806950)
addappid(806951)
addappid(806952)
-- Game: addappid(806950)

-- MAIN APP DEPOTS / PACKAGES
addappid(806953,0,"fa28ea5276336bc602ae3455f63a9a45dfdfdd89705b676845e9f2f77d258cdb")
