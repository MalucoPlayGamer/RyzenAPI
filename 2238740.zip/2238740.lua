-- Lua provided by RyzenAPI
-- Game: addappid(2238740)

-- MAIN APPLICATION
addappid(2238740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238741, 1, "be5a528bad5e9c2e402451f60f344b1c374f846018f74e60485fa7b78d7cb7c7")
