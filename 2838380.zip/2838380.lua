-- Lua provided by RyzenAPI
-- Game: Battle Room

-- MAIN APPLICATION
addappid(2838380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838381, 1, "a47c2ecfdc8c784f4dafb078256fb460a0dbaabf33e40d2cda5fa860d7e97c84")

