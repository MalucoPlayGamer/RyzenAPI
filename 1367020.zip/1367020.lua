-- Lua provided by RyzenAPI
-- Game: addappid(1367020)

-- MAIN APPLICATION
addappid(1367020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367021, 1, "2da2881191bbc7df24232af2b351108a4615c61aab9ac98316b8707c75c07a6e")
