-- Lua provided by RyzenAPI
-- Game: The Witch In The Woods Demo

-- MAIN APPLICATION
addappid(2507530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507531, 1, "ed4a40231fdde9741b3744585c804f43df63bb4613f5c85850b3e888d5bfd18e")

