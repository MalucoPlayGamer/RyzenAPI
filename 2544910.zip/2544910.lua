-- Lua provided by RyzenAPI
-- Game: 2544910

-- MAIN APPLICATION
addappid(2544910)
-- Game: addappid(2544910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544910,0,"93b392c3ea70c794465f9b051e69db14b421062bc65bb03ebfdb25f7b70cf119")
