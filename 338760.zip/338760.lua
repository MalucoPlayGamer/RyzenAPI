-- Lua provided by RyzenAPI
-- Game: Game: Death Ray Manta SE

-- MAIN APPLICATION
addappid(338760)
-- Game: addappid(338760)

-- MAIN APP DEPOTS / PACKAGES
addappid(338761, 1, "5674b2d82f8d9f300f177b1cdbe29ecf9e96be7240889a47644dedceb4bf2fbb")
