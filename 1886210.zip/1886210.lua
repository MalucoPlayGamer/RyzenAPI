-- Lua provided by RyzenAPI
-- Game: Mirrored Soul

-- MAIN APPLICATION
addappid(1886210)
-- Game: addappid(1886210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886212,0,"e5c2e39a1d6e24f00918a0f27000d6963e301751899498b84a995a236e95ac73")
