-- Lua provided by RyzenAPI 
-- Game: Scanner Sombre
addappid(475190)
addappid(475191, 1, "94c188d9a814e7ec92ad8471b98d0359e89f13b5c942f29d5ff2f400bab30a2a")
addappid(475192, 1, "260dd08c3d0bb597f584c66a42607e6f0b1cb59054b4dee578b67a65363a913d")
addappid(475193, 1, "ffa60c37190c405fd4d08b1fd0368ec0bbb7004dbbfdb071b170857a7b46c665")
