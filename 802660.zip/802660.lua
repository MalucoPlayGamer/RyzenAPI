-- Lua provided by RyzenAPI
-- Game: addappid(802660)

-- MAIN APPLICATION
addappid(802660)

-- MAIN APP DEPOTS / PACKAGES
addappid(802661, 1, "f285ae9e4ba66b4e4d114b738a93b9df0c95b846e793a4783df3871c1b1691e9")
addappid(805730, 0, "ba49f190ba1cab975c0cc293cdcae5116b9b9cc87db83344b768a62646a5afed")
