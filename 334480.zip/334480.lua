-- Lua provided by RyzenAPI
-- Game: Robinson Crusoe and the Cursed Pirates

-- MAIN APPLICATION
addappid(334480)

-- MAIN APP DEPOTS / PACKAGES
addappid(334481, 1, "0b244fbba3d7bfd063c05e640b4d4c4e59c5e3dec1fc90878cc3be859e201882")
