-- Lua provided by RyzenAPI 
-- Game: Dinkum OST
addappid(2468700)
addappid(2468701, 1, "1cf9b49a1c0f002bc8adfa8f0c786ac1be5ac773c330dddf622d7e002a1a62f9")
