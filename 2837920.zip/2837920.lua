-- Lua provided by SkyAPI 
-- Game: Anime Girls: Sun of a Beach
addappid(2837920)
addappid(2837921, 1, "43a44cea751a3686665dede2716d6f7025ac2939665b3d5dcfd1891f4003f3e2")
