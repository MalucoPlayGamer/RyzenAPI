-- Lua provided by RyzenAPI
-- Game: addappid(2837920)

-- MAIN APPLICATION
addappid(2837920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837921, 1, "43a44cea751a3686665dede2716d6f7025ac2939665b3d5dcfd1891f4003f3e2")
