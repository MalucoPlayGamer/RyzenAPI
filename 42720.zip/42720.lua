-- Lua provided by RyzenAPI
-- Game: Call of Duty Black Ops - Remote Console

-- MAIN APPLICATION
addappid(42720)

-- MAIN APP DEPOTS / PACKAGES
addappid(42721, 1, "b1eb9b44b5388cd3d71339aecdffcd6884647524d6a886afef5d1a67d1ec2daa")

