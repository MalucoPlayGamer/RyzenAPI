-- Lua provided by RyzenAPI
-- Game: 458420

-- MAIN APPLICATION
addappid(458420)
-- Game: addappid(458420)

-- MAIN APP DEPOTS / PACKAGES
addappid(458421, 1, "bc233bd239113e5f82c4fc3e37b51477f37ce3c25d96eb7e807aa5c23c899564")
