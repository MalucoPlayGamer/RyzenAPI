-- Lua provided by RyzenAPI
-- Game: Teslagrad Remastered

-- MAIN APPLICATION
addappid(2168150)
-- Game: addappid(2168150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168151, 1, "dc9c2e8ccc529df4f80d2d190e612120d557536a9c5f93d7480f0524cd951725")
addappid(2168152, 1, "84a61835d5b64643c93b9599b418ac0c47a989e87bf3ed5eb0582e62b8d9eac3")
addappid(2168153, 1, "5c370b2236711cf0f470b66f0d7c25569bdc4ab1128d889f3e34b8287fe61565")
