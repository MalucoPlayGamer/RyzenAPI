-- Lua provided by RyzenAPI
-- Game: AppID 1246880

-- MAIN APPLICATION
addappid(1246880)
-- Game: addappid(1246880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246881, 1, "1d01ba79c90e77cf8d32743bfcb92221963df7696cff133aa522682145d5a008")
