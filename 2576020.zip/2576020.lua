-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2024 Steam Edition

-- MAIN APPLICATION
addappid(2576020)
addappid(2690340)
addappid(2690350)
addappid(2690360)
addappid(2690370)
addappid(2690380)
addappid(2690390)
addappid(2690400)
addappid(2690410)
addappid(2690420)
addappid(2690430)
addappid(2690440)
addappid(2690450)
addappid(2690460)
addappid(2690470)
addappid(2690480)
addappid(2690490)
addappid(2690500)
addappid(2690510)
addappid(2690520)
addappid(2690530)
addappid(2690550)
addappid(2690560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576021, 1, "224dc43ad0c89bc13b07205ed337d9423a8b4f62288a635239807868ac70015e")

