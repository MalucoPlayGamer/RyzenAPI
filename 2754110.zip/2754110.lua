-- Lua provided by RyzenAPI
-- Game: Game: Pocketing the ball-Billiards Simulator - 8 ball- 3D pool

-- MAIN APPLICATION
addappid(2754110)
-- Game: addappid(2754110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754111, 1, "54a925c63cf98b16110d02aace384b4cfdb42545407ac0d4408266363065f5b8")
