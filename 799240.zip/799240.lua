-- Lua provided by RyzenAPI
-- Game: My Free Farm 2

-- MAIN APPLICATION
addappid(799240)

-- MAIN APP DEPOTS / PACKAGES
addappid(799241, 1, "260dd0d19979e16e03eb8de7eb68562a7b4fd0443d5a810320a0ae4269536b75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
