-- Lua provided by RyzenAPI
-- Game: The Flame in the Flood

-- MAIN APPLICATION
addappid(318600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(318601, 1, "8d58615a00792854df1e862f86df22115978c49bc6747209d9227eb22fb87977")
addappid(318602, 1, "2accfce8cfea14ee3641267be9817746f565ea56c8ec71b8dbb3bb6c069274e4")
addappid(318605, 1, "6d2bbf17170835c1a3a51fe552ee9bf0bd4a82fbb9d60e5cfceb0b5b5cd63375")

