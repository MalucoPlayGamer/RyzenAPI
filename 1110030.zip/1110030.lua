-- Lua provided by SkyAPI 
-- Game: Heroes of Myth
addappid(1110030)
addappid(1110031, 1, "d6c6883eaa74ff77998336a9afaacbb67b34e2d4491cb5f3f2abed88b441fbf7")
