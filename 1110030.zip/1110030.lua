-- Lua provided by RyzenAPI
-- Game: Heroes of Myth

-- MAIN APPLICATION
addappid(1110030)
-- Game: addappid(1110030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110031, 1, "d6c6883eaa74ff77998336a9afaacbb67b34e2d4491cb5f3f2abed88b441fbf7")
