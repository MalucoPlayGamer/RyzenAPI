-- Lua provided by SkyAPI 
-- Game: AppID 3202190
addappid(3202190)
addappid(3202191, 1, "26276e5394edc76fab225e209403c27acf69c932f7de73bea2fa292a46f7dca6")
