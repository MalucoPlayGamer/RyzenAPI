-- Lua provided by RyzenAPI
-- Game: Being a DIK - Season 1

-- MAIN APPLICATION
addappid(1126320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126321, 1, "b487bb317f141b1ea8c7f43473ae7192dc9c3ddabf47e75c0b8ea091ea83f5dd")
addappid(1215820, 0, "0890c98fa0aa823afe57e4bfdbdbfa87a06f0532f447baa16117044c87eee172")
addappid(1223490, 0, "1d2d2ea68cb27690634e2ff82a64426f397f85aaf001bbf2c14cff8b4bd551a9")
addappid(1631620, 0, "11aa46b31524868c0f6390fba205305425c13bae710c8a44f309281fe43a88b7")
