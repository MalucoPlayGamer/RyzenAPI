-- Lua provided by SkyAPI 
-- Game: The Room Stalker
addappid(3639000)
addappid(3639001, 1, "fc7bf25ea3b9e83a29e7e01a9b127445181498ac944537d2a45a6611feb881b3")
addappid(3639002, 1, "deefef8e173aaa8fae5cf133b11fad8c13e9ac5db685bd66cec084b3f90f7283")
