-- Lua provided by RyzenAPI
-- Game: Torque Drift 2

-- MAIN APPLICATION
addappid(3116640)
-- Game: addappid(3116640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116641, 1, "76d9b96d0a9d422a6133e9cba82015446749380a2945965f89fb05b584a507c8")
