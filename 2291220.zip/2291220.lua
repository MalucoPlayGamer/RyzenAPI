-- Lua provided by RyzenAPI
-- Game: 2291220

-- MAIN APPLICATION
addappid(2291220)
-- Game: addappid(2291220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291221, 1, "f6f386d9273191a650c80d44bbcc41d90125eabbb056c8f14711fb3ae714efdc")
