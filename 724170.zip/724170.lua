-- Lua provided by RyzenAPI
-- Game: 724170

-- MAIN APPLICATION
addappid(724170)
-- Game: addappid(724170)

-- MAIN APP DEPOTS / PACKAGES
addappid(724172,0,"018d6dad2ad1217599f5c0acfafaeee7bc4ef7d170e3d8f00e6247f692f91c4f")
