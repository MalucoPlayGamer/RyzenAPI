-- Lua provided by RyzenAPI
-- Game: CTHON

-- MAIN APPLICATION
addappid(595100)

-- MAIN APP DEPOTS / PACKAGES
addappid(595101, 1, "9f467a6961f546def101fe775a4c38613f41a11b28b11de7cb1db142fb153c8d")
