-- Lua provided by RyzenAPI 
-- Game: Beauty Jigsaw - Music Pack
addappid(3163810)
addappid(3163811, 1, "097d81afa12e7088b365b662de418c92fa6af84b46a617b96abe0dd03a1fe828")
