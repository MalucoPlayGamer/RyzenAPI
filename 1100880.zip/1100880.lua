-- Lua provided by RyzenAPI 
-- Game: AppID 1100880
addappid(1100880)
addappid(1100881, 1, "1a88e42f20b53298e81afdb3207562cf2a34686b741554e035613cbcbf11817e")
