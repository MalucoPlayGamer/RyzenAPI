-- Lua provided by RyzenAPI
-- Game: Battle Siege Royale

-- MAIN APPLICATION
addappid(1100880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100881, 1, "1a88e42f20b53298e81afdb3207562cf2a34686b741554e035613cbcbf11817e")
