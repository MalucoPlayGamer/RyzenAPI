-- Lua provided by RyzenAPI
-- Game: Saintess Eruna and the Lustful Book of Corruption ~Busty Sister's H Services~

-- MAIN APPLICATION
addappid(3141900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141903,0,"074244f0a8e28327ff8281168ce84e96ab27cde591331e6cd76973c97279455d")
addappid(3141904,0,"96ef6885f9b0bc7a8289c3a7dc92788fa84d7bc218b4be5de6f5c1a4372336fc")

