-- Lua provided by RyzenAPI
-- Game: Game: Our Home

-- MAIN APPLICATION
addappid(3071950)
addappid(3791020)
-- Game: addappid(3071950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071951, 1, "2f5384b64b7ccf926123258d41bb2982eeb9725abe7ea4b4c4345bd2175d0999")
