-- Lua provided by RyzenAPI
-- Game: Delicious - Emily's Message in a Bottle

-- MAIN APPLICATION
addappid(540780)

-- MAIN APP DEPOTS / PACKAGES
addappid(540781, 1, "65b46d9316f095b1fa33310f36a99c268fb6e86d16ec8b60944140d235d90c57")
