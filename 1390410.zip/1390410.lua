-- Lua provided by SkyAPI 
-- Game: Midnight Fight Express
addappid(1390410)
addappid(1390411, 1, "5b50203d3a7725347707e61fc215b127dc8ad0e20171db61260b0a860df904f1")
