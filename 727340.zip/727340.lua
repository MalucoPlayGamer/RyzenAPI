-- Lua provided by SkyAPI 
-- Game: Stitched HD
addappid(727340)
addappid(727341, 1, "3cb1e113f644e40249f53c25a1487c43ead58e9debf8d2d477494197955fdbd2")
