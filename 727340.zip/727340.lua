-- Lua provided by RyzenAPI
-- Game: 727340

-- MAIN APPLICATION
addappid(727340)
-- Game: addappid(727340)

-- MAIN APP DEPOTS / PACKAGES
addappid(727341, 1, "3cb1e113f644e40249f53c25a1487c43ead58e9debf8d2d477494197955fdbd2")
