-- Lua provided by RyzenAPI
-- Game: Game: Voice of Cards: The Isle Dragon Roars Demo

-- MAIN APPLICATION
addappid(1457790)
-- Game: addappid(1457790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457791, 1, "11b4207c4ea4555943cee4b1d05662ab59fc950ef9379226ff6bc6897b95725e")
