-- Lua provided by RyzenAPI
-- Game: addappid(2050510)

-- MAIN APPLICATION
addappid(2050510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050511, 1, "1b990cb0e6257998e1894d1e03ff400eebcdf104edbbf2e28fe66dad79fd9539")
