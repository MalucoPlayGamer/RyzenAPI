-- Lua provided by RyzenAPI
-- Game: Rhapsody III: Memories of Marl Kingdom - Art Book

-- MAIN APPLICATION
addappid(2517660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517660,0,"61fde99861468198600fda2538ff30e8c4b2b49807bb080345348e7e3eb95b1c")

