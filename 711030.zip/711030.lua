-- Lua provided by RyzenAPI
-- Game: addappid(711030)

-- MAIN APPLICATION
addappid(711030)

-- MAIN APP DEPOTS / PACKAGES
addappid(711031, 1, "1f9f2fba3f3789ed2cfd5d6b6e06e03e5a53c8e5d93b6aaa2cc8669d4861eaf6")
