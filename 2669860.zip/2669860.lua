-- Lua provided by RyzenAPI
-- Game: YAR: Forgotten Throne

-- MAIN APPLICATION
addappid(2669860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669861, 1, "cb46bb79eb4c8079aa9c7602b15ec2feda04cc370a326a86a1b9682ea5fc2383")
