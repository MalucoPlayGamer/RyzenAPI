-- 2597470's Lua and Manifest Created by Hubcap Manifest
-- Tower of Dreams
-- Created: July 26, 2026 at 13:08:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2597470, 1, "8b68959a891454fcfeb8482805a0e7e50c4b878560e195d568fa11ff2c1cca60") -- Tower of Dreams
-- MAIN APP DEPOTS
addappid(2597471, 1, "0d08826f42dbbd802db0178eb71e939cb5c37bb347b781e2f6469efbafc9940b") -- Depot 2597471
setManifestid(2597471, "4378923679123281727", 331999795)