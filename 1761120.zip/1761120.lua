-- Lua provided by RyzenAPI
-- Game: Crimzon Clover World EXplosion Demo

-- MAIN APPLICATION
addappid(1761120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761121, 1, "82ca6562e02ac5bb7b9d158923465a2491d4a42747f3e92e787ff311889b7f78")

