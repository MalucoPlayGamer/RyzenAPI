-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1731641)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731641,0,"eb53b280baa5cd37a63429a6d4cb3fe9466fd0aef4805e608490d75b7ffc4160")

