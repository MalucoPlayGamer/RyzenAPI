-- Lua provided by RyzenAPI
-- Game: addappid(1731641)

-- MAIN APPLICATION
addappid(1731641)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731641,0,"eb53b280baa5cd37a63429a6d4cb3fe9466fd0aef4805e608490d75b7ffc4160")
