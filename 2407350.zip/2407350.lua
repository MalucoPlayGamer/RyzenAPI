-- Lua provided by RyzenAPI
-- Game: CyberCity: SEX Saga

-- MAIN APPLICATION
addappid(2407350)
-- Game: addappid(2407350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407351, 1, "36810414fcd44a8bc977fe94973578ec4ad900e7efc3c1eee3ed83ab94242bff")
