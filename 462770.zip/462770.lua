-- Lua provided by RyzenAPI
-- Game: AppID 462770

-- MAIN APPLICATION
addappid(462770)

-- MAIN APP DEPOTS / PACKAGES
addappid(462771, 1, "f9fd650d5d6865e0c938726ea43242c226c05b955f425f9d072cd9ac761ddb7b")
addappid(462772, 1, "54cac65556fc280e4d84d1c0c5840ca6d253325a2f83259ef444b2bf336dac19")
addappid(462773, 1, "0e195dd0e3fb2f1e3079a8672a6ea00a7ed1689f2672f38bb2e8e089bb672015")
addappid(462774, 1, "ff801db3b0cba4a721597d541b1349548cb37ac4d09c6f3b9d19a22810a74f39")
addappid(462775, 1, "f4bb7046ed8c45402550e9545c0b86c5fc78087a6001311f0cd2e7b8cfa7b583")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
