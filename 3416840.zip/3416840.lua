-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Isekai MonstersPACK  Fantasy Demi-Human

-- MAIN APPLICATION
addappid(3416840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416840,0,"75eedc1fcf6954186aa4aa9798fd35ede1245b3d6c560e04e34182100847857c")

