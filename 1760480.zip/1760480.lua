-- Lua provided by RyzenAPI
-- Game: 1760480

-- MAIN APPLICATION
addappid(1760480)
-- Game: addappid(1760480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760480,0,"82dca9e50950f252b389747c8f4e33a4754f34fd7d8e93b2d8a013532b6a4d0e")
