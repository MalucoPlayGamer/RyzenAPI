-- Lua provided by RyzenAPI
-- Game: Game: AppID 1082220

-- MAIN APPLICATION
addappid(1082220)
-- Game: addappid(1082220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082221, 1, "0794c80ba32ff999b3021f262f33c132690401c14acc03568fb5d30a46f4ee11")
