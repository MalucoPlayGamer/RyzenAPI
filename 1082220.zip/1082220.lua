-- Lua provided by RyzenAPI
-- Game: Outbreak: Epidemic

-- MAIN APPLICATION
addappid(1082220)
addappid(1104420)
addappid(1232170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082221, 1, "0794c80ba32ff999b3021f262f33c132690401c14acc03568fb5d30a46f4ee11")
