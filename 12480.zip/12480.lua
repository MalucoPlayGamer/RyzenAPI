-- Lua provided by RyzenAPI
-- Game: addappid(12480)

-- MAIN APPLICATION
addappid(12480)

-- MAIN APP DEPOTS / PACKAGES
addappid(12481, 1, "75c2701acd7caebf8651e5f60eb31a33fc4eb4eebb3bf312105f3da6adde8ab4")
addappid(12482, 1, "a80f2d8681b0f0f943fd5c19a565ebcea7b5c1e8e3f890bbd354a72af2ef5df4")
addappid(12483, 1, "b0c4f7c6b4724f3a9bdadf00ed245995d70f2e7ee74db08b59cb01c9c822da45")
addappid(12484, 1, "3118ddc0289d4c18231d43c333262a32dbd0532ca71e3766465aa78d26fb4b12")
addappid(12485, 1, "291baf38bb1a3ce28df51a166a4ed7026d4853b3a5dd1f08faada8dc020e6ded")
addappid(12486, 1, "0dc2b42e537bb176a68cd4575c62925cdc93d576d841efa1eb73e5741b59c52a")
addappid(12487, 1, "f559d79ddf50de66a4ef57828bbdcc90c1e83b7e4d4bee573796bb49d7fd3b23")
