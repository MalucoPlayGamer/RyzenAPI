-- Lua provided by SkyAPI 
-- Game: Dancing Cube
addappid(1738540)
addappid(1738541, 1, "b4b894df012b4c73c172122aab2f3860c109467107434ff39b1ffdf70f3e297d")
