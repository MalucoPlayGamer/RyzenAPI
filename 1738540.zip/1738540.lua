-- Lua provided by RyzenAPI
-- Game: 1738540

-- MAIN APPLICATION
addappid(1738540)
-- Game: addappid(1738540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738541, 1, "b4b894df012b4c73c172122aab2f3860c109467107434ff39b1ffdf70f3e297d")
