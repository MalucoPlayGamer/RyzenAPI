-- Lua provided by RyzenAPI
-- Game: Assassin's Creed® III Remastered

-- MAIN APPLICATION
addappid(911400)
addappid(985980)

-- MAIN APP DEPOTS / PACKAGES
addappid(911401, 1, "c04740de17320ddf2881d8e88424ccb3850b951c06acdf8de1da26decd287cd9")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

