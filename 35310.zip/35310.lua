-- Lua provided by RyzenAPI
-- Game: Game: Clutch

-- MAIN APPLICATION
addappid(35310)
-- Game: addappid(35310)

-- MAIN APP DEPOTS / PACKAGES
addappid(35311, 1, "4e87f34dbd4e16bf608195f5bc7b67d2204f007a42daac8747ef1a4ca00ce374")
