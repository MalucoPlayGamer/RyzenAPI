-- Lua provided by RyzenAPI
-- Game: Shao Song I

-- MAIN APPLICATION
addappid(4292950)

-- MAIN APP DEPOTS / PACKAGES
addappid(4292951,0,"d67ee3c314a005c060fc2616ff7d3787bd366d0b33bcc961bb42eab401a4bf8a")

