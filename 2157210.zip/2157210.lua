-- Lua provided by RyzenAPI
-- Game: 2157210

-- MAIN APPLICATION
addappid(2157210)
-- Game: addappid(2157210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157211, 1, "b2d5c8830212525850d0f3e635e0cb30eca15d09382db6dec3063ef4d69742ae")
