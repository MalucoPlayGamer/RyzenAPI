-- Lua provided by RyzenAPI
-- Game: Game: Super Clown 3: Revenge

-- MAIN APPLICATION
addappid(2192650)
-- Game: addappid(2192650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192651, 1, "b0fed34a6ba5207129e249d20fa7181ac1eb218abd6f4cd0a47c572b5210c4d7")
