-- Lua provided by RyzenAPI
-- Game: addappid(1966870)

-- MAIN APPLICATION
addappid(1966870)
addappid(1969110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966871, 1, "c03e287beab229d2401b3e055fa7120c86dd1c1ad9e9ef0465a8c95858eba7f6")
