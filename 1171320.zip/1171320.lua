-- Lua provided by RyzenAPI
-- Game: Frog Detective 3: Corruption at Cowboy County

-- MAIN APPLICATION
addappid(1171320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171321, 1, "6ac45405f24f2c6a5216e561fea9c8dc3fca9a69d28e176afc71bfcbaabbaf3b")

