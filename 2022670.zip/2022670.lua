-- Lua provided by RyzenAPI
-- Game: SONIC SUPERSTARS

-- MAIN APPLICATION
addappid(2022670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022671, 1, "f2c1f41d9127af994a3cd878921ff5b89db85334ee15711d98ecac202e0b2c54")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2376680)
addappid(2376681)
addappid(2376682)
addappid(2376683)
addappid(2376684)
addappid(2376685)
addappid(2376686)
addappid(2378680)
addappid(2504600)
addappid(2549530)
