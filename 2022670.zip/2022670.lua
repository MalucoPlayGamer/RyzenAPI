-- Lua provided by RyzenAPI
-- Game: addappid(2022670)

-- MAIN APPLICATION
addappid(2022670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022671, 1, "f2c1f41d9127af994a3cd878921ff5b89db85334ee15711d98ecac202e0b2c54")
