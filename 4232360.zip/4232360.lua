-- 4232360's Lua and Manifest Created by Hubcap Manifest
-- Buttons Up!
-- Created: August 05, 2026 at 22:44:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4232360, 1, "d678e52ae8da8c43bdd76fb270954822e80db4f0415578614294732aba777b55") -- Buttons Up!
-- MAIN APP DEPOTS
addappid(4232361, 1, "928cac5e2c72e3262581667e39135a65d82ef9d1811f8cf3eea0a62fb48834d6") -- Depot 4232361
setManifestid(4232361, "4531444106478625736", 14373769)
addappid(4232362, 1, "9e06dd227e719af4887d2c4012ee251aa6036d415c3b164bc0e8cc99e7216d0b") -- Depot 4232362
setManifestid(4232362, "7756761075663297998", 14252139)
addappid(4232363, 1, "be461b2c78bce2cea7366aaaea77bddfa56d3877f3c7372fc0feae29a5b6de3f") -- Depot 4232363
setManifestid(4232363, "104063677300918949", 306612513)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4271190) -- Buttons Up - Supporter DLC