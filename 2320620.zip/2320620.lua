-- Lua provided by RyzenAPI
-- Game: The Guard

-- MAIN APPLICATION
addappid(2320620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320621, 1, "78154f4491b862a2f7181bf4f0efc242dad537308dbee2acb5a1d78ef86a58f7")
