-- Lua provided by RyzenAPI
-- Game: 菲利斯的堕落日记

-- MAIN APPLICATION
addappid(2519890)
-- Game: addappid(2519890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519892,0,"f85ae561597e4b455830d22c02ac35253f82012244daf24d19e06107f74d2626")
