-- Lua provided by RyzenAPI
-- Game: addappid(762080)

-- MAIN APPLICATION
addappid(762080)

-- MAIN APP DEPOTS / PACKAGES
addappid(762081, 1, "cc156c8de75c1ba9021207829f6ddd7cf643d86e56cf13e6626399deeb63526d")
