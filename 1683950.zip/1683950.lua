-- Lua provided by RyzenAPI
-- Game: Game: The Witch's Sexual Prison

-- MAIN APPLICATION
addappid(1683950)
-- Game: addappid(1683950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683951, 1, "664a5b9c37d8b87b89370b1be1ea7396753738e0778532926ee2dd8388115fb1")
