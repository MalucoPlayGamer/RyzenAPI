-- Lua provided by SkyAPI 
-- Game: Citadel Stormer 2
addappid(2224160)
addappid(2224161, 1, "6de8b080a3c59987e473f561bc654d07f9aec517a95d89f090b264fcd6692b41")
