-- Lua provided by RyzenAPI
-- Game: Survive the Fall

-- MAIN APPLICATION
addappid(1579340)
addappid(3573200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1579341, 1, "39feebfcc1604f5e11b443382b327ba82cbd6bb5dea920007238e50c93843f17")
addappid(3573210, 0, "7d3abb0701b5d9c82d9121e3c590d62ecf614a542f7067b839784954395d1918")

