-- Lua provided by RyzenAPI
-- Game: Survive the Fall

-- MAIN APPLICATION
addappid(1579340)
-- Game: addappid(1579340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579341, 1, "39feebfcc1604f5e11b443382b327ba82cbd6bb5dea920007238e50c93843f17")
addappid(3573210, 0, "7d3abb0701b5d9c82d9121e3c590d62ecf614a542f7067b839784954395d1918")
