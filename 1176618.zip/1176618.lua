-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Legendary Weapons OROCHI Pack 4

-- MAIN APPLICATION
addappid(1176618)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176618,0,"13d8fa0b027824eee3e751c901b16827a041bcc9f5516e0c488af3f45eebde80")

