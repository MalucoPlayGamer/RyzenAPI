-- Lua provided by SkyAPI 
-- Game: Cubebam
addappid(2726110)
addappid(2726111, 1, "3e37ef276a7ca9989b522c2053373097c818b49a2be8960483719eabe4e61393")
