-- Lua provided by RyzenAPI
-- Game: Game: Cubebam

-- MAIN APPLICATION
addappid(2726110)
-- Game: addappid(2726110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726111, 1, "3e37ef276a7ca9989b522c2053373097c818b49a2be8960483719eabe4e61393")
