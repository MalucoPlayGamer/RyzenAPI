-- Lua provided by RyzenAPI
-- Game: 1042560

-- MAIN APPLICATION
addappid(1042560)
-- Game: addappid(1042560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042561, 1, "fc1cad3b87a29ac958c378671d4c02bc09615df129b291ed38201860de9c70a7")
