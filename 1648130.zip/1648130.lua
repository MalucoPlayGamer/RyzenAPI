-- Lua provided by RyzenAPI
-- Game: Babol the Walking Box Demo

-- MAIN APPLICATION
addappid(1648130)
-- Game: addappid(1648130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648131, 1, "0fdc09b16cfc6a5667743018c431a16b3b0ddf28e131df9f8471480f0af7f0a3")
