-- Lua provided by RyzenAPI
-- Game: World Basketball Manager 2

-- MAIN APPLICATION
addappid(591910)

-- MAIN APP DEPOTS / PACKAGES
addappid(591911,0,"f06c3208d768e9c2e96aea3e5073ae109c1ad0390a84c794d8c9a85169138af3")

