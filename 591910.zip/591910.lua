-- Lua provided by RyzenAPI
-- Game: World Basketball Manager 2

-- MAIN APPLICATION
addappid(591910)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(591911,0,"f06c3208d768e9c2e96aea3e5073ae109c1ad0390a84c794d8c9a85169138af3")

