-- Lua provided by RyzenAPI
-- Game: Tsundere Idol

-- MAIN APPLICATION
addappid(795160)

-- MAIN APP DEPOTS / PACKAGES
addappid(795161, 1, "0dd7b0d4abf36532f19cfd6098c7ede796aa0f590f46a61cba5fab3449e485b1")
addappid(795162, 1, "d59dd911b097d935daa8ced247eebeef32d3da48511d1cdd9ae2c156a083c506")
addappid(982130, 0, "00c100c2e30c702fdd3a25c95ef61bd5142ad0cf14ff82a0c7aa2bb7d74c37ae")
