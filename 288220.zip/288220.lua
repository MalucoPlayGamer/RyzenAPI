-- Lua provided by RyzenAPI 
-- Game: Backstage Pass
addappid(288220)
addappid(288221, 1, "4db63124c842ade11bdfb60b77c37f323dedc59bd8de95d58826b7d8b93f5e8d")
