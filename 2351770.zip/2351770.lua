-- Lua provided by RyzenAPI
-- Game: Era of Celestials

-- MAIN APPLICATION
addappid(2351770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351771, 1, "96a4b5e4ffbadcabe4518bb428647cf5e7f8bd555604adb365fe257d648db013")

