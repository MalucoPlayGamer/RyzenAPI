-- Lua provided by RyzenAPI
-- Game: Neon Marble Rust

-- MAIN APPLICATION
addappid(2587360)
addappid(3833880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587362,0,"1f2331b82d7eec2b7324f889a476af98b8d8f5903a5e7343185cb55359419b4a")
addappid(2587363,0,"d2fbab7f1d9eaaf31bebda4b511868db1a912e345635c54a7d24b0d0a6a19bb6")

