-- Lua provided by RyzenAPI
-- Game: Game: Mystery of Island

-- MAIN APPLICATION
addappid(1845840)
-- Game: addappid(1845840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845841, 1, "480d1b7ccdbf7ac3b3e7a7fab2fc71f38ff9f7b56853a9483e7aed157666f4fa")
