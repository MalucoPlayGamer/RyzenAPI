-- Lua provided by RyzenAPI
-- Game: Dungeon Town

-- MAIN APPLICATION
addappid(959880)

-- MAIN APP DEPOTS / PACKAGES
addappid(959881, 1, "1bf8f12e7bc0bb463f3f4d650556869cfd8b4cdaa5d6d45bd001647730a07078")
addappid(959882, 1, "8adf61b34cfc7688db06c8f9346a38829ed2e766ec68bb4a3cf0b2391531d564")
