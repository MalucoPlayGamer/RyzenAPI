-- Lua provided by RyzenAPI
-- Game: addappid(2794140)

-- MAIN APPLICATION
addappid(2794140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794141, 1, "6d11dae608357aa999ff0d5fb2e186289dc88a4fec3612c3d40fd3c2eb140a6e")
