-- Lua provided by RyzenAPI
-- Game: Game: AppID 654770

-- MAIN APPLICATION
addappid(654770)
-- Game: addappid(654770)

-- MAIN APP DEPOTS / PACKAGES
addappid(654771, 1, "d0b549153413bcd519c42389a37d833e8b66a0e1b0078ad1937e6123711d1803")
