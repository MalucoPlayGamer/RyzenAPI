-- Lua provided by RyzenAPI 
-- Game: AppID 654770
addappid(654770)
addappid(654771, 1, "d0b549153413bcd519c42389a37d833e8b66a0e1b0078ad1937e6123711d1803")
