-- Lua provided by RyzenAPI
-- Game: AppID 1124410

-- MAIN APPLICATION
addappid(1124410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124411, 1, "1bfb97a3bf0bb2be8970b45e3f9f74e8ff9dbb3db06b3cee00ff4d2a9f747e49")
