-- Lua provided by RyzenAPI
-- Game: addappid(305260)

-- MAIN APPLICATION
addappid(305260)

-- MAIN APP DEPOTS / PACKAGES
addappid(305261, 1, "299c2f96abae97ce119c05949a63f49f3dfd76546bc0f560b069451248bcdb9a")
