-- Lua provided by RyzenAPI
-- Game: addappid(1633210)

-- MAIN APPLICATION
addappid(1633210)
addappid(1639800)
addappid(1639810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633211, 1, "94e23aab098e51b586c58ff624a617f6eed7b49b45eb6d5f503e0532102a6dd8")
