-- Lua provided by RyzenAPI
-- Game: Order of Battle: World War II

-- MAIN APPLICATION
addappid(312450)
addappid(412580)
addappid(443620)
addappid(458860)
addappid(464590)
addappid(464591)
addappid(528620)
addappid(563210)
addappid(626790)
addappid(712340)
addappid(816780)
addappid(926650)
addappid(1102380)
addappid(1182190)
addappid(1379170)
addappid(1466340)
addappid(1688120)
addappid(1954950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(312451, 1, "5a496b539a6dde0d728b1097f4719335d0294d888a311c884a980752ac3a189a")
addappid(312452, 1, "c8725ef595e766f9374749dc94e2e34450303a263ba29b0ef96f66f2d99a3169")
