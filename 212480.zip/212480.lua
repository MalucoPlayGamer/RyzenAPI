-- Lua provided by SkyAPI 
-- Game: Sonic & All-Stars Racing Transformed Collection
addappid(212480)
addappid(212481, 1, "b8ac8993c7efb0a17d52f8b140c8d7be8d0332c6ec92c026c7d43ac5319fd071")
addappid(264600)
