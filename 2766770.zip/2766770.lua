-- Lua provided by RyzenAPI
-- Game: 这是一个正方形！（This Is A Square！）

-- MAIN APPLICATION
addappid(2766770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766771, 1, "c488ed690e90cf59a09cd696793c28e6ed214bbc225c0f0ffb7c03d8e14e2f4a")

