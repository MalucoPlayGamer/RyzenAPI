-- Lua provided by RyzenAPI
-- Game: Star Chef: Cooking & Restaurant Game

-- MAIN APPLICATION
addappid(1028860)

