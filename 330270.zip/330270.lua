-- Lua provided by RyzenAPI
-- Game: Game: Warlocks vs Shadows

-- MAIN APPLICATION
addappid(330270)
-- Game: addappid(330270)

-- MAIN APP DEPOTS / PACKAGES
addappid(330271, 1, "76ec63e65ee0ca9512b2cb1272c5740cf85abdaf81c475a3b848b8a0c5e3e773")
addappid(330272, 1, "5be97b8e6b50e08d20f281cfbe8e85cc08d203f47d43be04a139157e70158579")
addappid(330273, 1, "5e5d1e814b92f4b787e538866f470f121c64967f3f82da93560151b5b270642b")
