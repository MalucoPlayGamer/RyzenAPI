-- Lua provided by RyzenAPI
-- Game: Tower Accelerator

-- MAIN APPLICATION
addappid(758670)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(758671, 1, "c1ddd07c265851a8f24c878cd1dfbe7373bb29860e3ceaf107a9a48214eb57bc")

