-- Lua provided by RyzenAPI
-- Game: 2137740

-- MAIN APPLICATION
addappid(2137740)
-- Game: addappid(2137740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137741, 1, "c6af3ef8718ba11755145a8114fd97443a2b04a47bb19e0124be0033df89af09")
