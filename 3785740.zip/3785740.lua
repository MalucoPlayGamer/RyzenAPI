-- Lua provided by RyzenAPI
-- Game: Maltese's Fluffy Onsen - Soundtrack + Items

-- MAIN APPLICATION
addappid(3785740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3785741, 1, "33d55f781d1ad9f7a3bfb48bd77140c578016fec6e9da39166bde1c94bfd7379")

