-- Lua provided by RyzenAPI
-- Game: Sphera Turris

-- MAIN APPLICATION
addappid(805350)

-- MAIN APP DEPOTS / PACKAGES
addappid(805351, 1, "9ae35e2f136c4c97f4057c1ddadf76a7793f36efa422547372783b3580d4ab64")

