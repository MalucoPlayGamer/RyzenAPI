-- Lua provided by RyzenAPI
-- Game: 1659420

-- MAIN APPLICATION
addappid(1659420)
-- Game: addappid(1659420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659421, 1, "54f1e37db693643220de1240ebc50a0c00d4bc3a53ffdd91cf3f52cc71c91382")
addappid(1659422, 1, "513eb93ddc7de41caabd6dfc7f8b2f5da716cc75ca9df1df674e4e339fceada2")
