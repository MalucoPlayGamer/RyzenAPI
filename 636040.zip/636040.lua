-- Lua provided by RyzenAPI
-- Game: Pixel Worlds: MMO Sandbox

-- MAIN APPLICATION
addappid(636040)
