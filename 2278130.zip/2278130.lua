-- Lua provided by RyzenAPI
-- Game: Hidden Post-Apocalyptic 4 Top-Down 3D

-- MAIN APPLICATION
addappid(2278130)
-- Game: addappid(2278130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278131, 1, "7a66942c38cb1cbd3f8bf5adfcd8e836c7050ecb87ed119a9c629677e5b275a6")
