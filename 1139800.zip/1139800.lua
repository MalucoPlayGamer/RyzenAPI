-- Lua provided by RyzenAPI
-- Game: AppID 1139800

-- MAIN APPLICATION
addappid(1139800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139801, 1, "cad53f525bc278d290a4ca1df6077896caf02d4bdf4c189146a69a8c1b052f2d")
