-- Lua provided by RyzenAPI
-- Game: Fabulous Food Truck

-- MAIN APPLICATION
addappid(497260)

-- MAIN APP DEPOTS / PACKAGES
addappid(497261, 1, "4c18e8f660e402abfde90e8d7dde1ca0103b67ce95f259ad3f4e6071c43f3119")
