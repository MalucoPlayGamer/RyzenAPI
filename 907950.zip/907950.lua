-- Lua provided by RyzenAPI
-- Game: Bottle of truth

-- MAIN APPLICATION
addappid(907950)

-- MAIN APP DEPOTS / PACKAGES
addappid(907951, 1, "a799c344084ec2b3875a09280f8889b55e9e0519f1edff8d40a045f7e2639a49")
