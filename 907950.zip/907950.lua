-- Lua provided by SkyAPI 
-- Game: AppID 907950
addappid(907950)
addappid(907951, 1, "a799c344084ec2b3875a09280f8889b55e9e0519f1edff8d40a045f7e2639a49")
