-- Lua provided by RyzenAPI
-- Game: Game: AppID 782320

-- MAIN APPLICATION
addappid(782320)
-- Game: addappid(782320)

-- MAIN APP DEPOTS / PACKAGES
addappid(782321, 1, "b70d9648f8a917b631ea0a34985599a3f42487a2aa031d644278057e27333eed")
