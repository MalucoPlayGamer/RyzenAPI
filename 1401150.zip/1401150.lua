-- Lua provided by RyzenAPI
-- Game: Black Hole Simulator

-- MAIN APPLICATION
addappid(1401150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1401151, 1, "57d461a344ff5801205fecdc54bf325bc45a35ed44fd83d4812a67f69b5f5233")
addappid(1401152, 1, "4e6af6c457f18ea54b69284efa6b44a3e79229d16fe4fd0a112b06cba85fada7")

