-- Lua provided by RyzenAPI
-- Game: Game: Oblitus mortis

-- MAIN APPLICATION
addappid(3434340)
-- Game: addappid(3434340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434341, 1, "951d55fb1670c08c94e596f879320377f45817df1df0812ed5fa759ba8c38bb1")
