-- Lua provided by RyzenAPI
-- Game: Game: KunKunNight

-- MAIN APPLICATION
addappid(2642890)
-- Game: addappid(2642890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642891, 1, "881c160a66097cb250d1865decd4e275ac0917db682aa1497b725186e9567947")
