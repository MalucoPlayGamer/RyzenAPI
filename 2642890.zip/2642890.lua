-- Lua provided by RyzenAPI
-- Game: KunKunNight

-- MAIN APPLICATION
addappid(2642890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642891, 1, "881c160a66097cb250d1865decd4e275ac0917db682aa1497b725186e9567947")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
