-- Lua provided by RyzenAPI
-- Game: Legendary Hunter VR

-- MAIN APPLICATION
addappid(642170)

-- MAIN APP DEPOTS / PACKAGES
addappid(642171, 1, "6d34beb1d5c7ddbb082266a484ea1d27d44684cd54e43d5648687efc41e020af")
