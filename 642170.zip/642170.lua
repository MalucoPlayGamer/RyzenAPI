-- Lua provided by SkyAPI 
-- Game: Legendary Hunter VR
addappid(642170)
addappid(642171, 1, "6d34beb1d5c7ddbb082266a484ea1d27d44684cd54e43d5648687efc41e020af")
