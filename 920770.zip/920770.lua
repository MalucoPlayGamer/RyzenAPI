-- Lua provided by RyzenAPI
-- Game: Santa's Story of Christmas

-- MAIN APPLICATION
addappid(920770)
-- Game: addappid(920770)

-- MAIN APP DEPOTS / PACKAGES
addappid(920771, 1, "589d9b8d870995ce7b8ea362d56cc20c4a364e70606ded0cbce8a8523d5293f0")
