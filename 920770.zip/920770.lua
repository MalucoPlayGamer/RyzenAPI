-- Lua provided by RyzenAPI
-- Game: Santa's Story of Christmas

-- MAIN APPLICATION
addappid(920770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(920771, 1, "589d9b8d870995ce7b8ea362d56cc20c4a364e70606ded0cbce8a8523d5293f0")

