-- Lua provided by RyzenAPI 
-- Game: EmyLiveShow: Case of Four Hot Witnesses
addappid(3195400)
addappid(3195401, 1, "69b100e78cfac28b5d608e89ac1a5284ce0b1d882997c49afbac420509038c31")
