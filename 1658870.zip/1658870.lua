-- Lua provided by RyzenAPI
-- Game: New Home: Medieval Village

-- MAIN APPLICATION
addappid(1658870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658871, 1, "4229199dbf0789534f6e62c690d7ca9775be21796a38687907c990422131bdf5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
