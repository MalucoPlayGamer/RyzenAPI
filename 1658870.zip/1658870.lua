-- Lua provided by RyzenAPI
-- Game: New Home: Medieval Village

-- MAIN APPLICATION
addappid(1658870)
-- Game: addappid(1658870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658871, 1, "4229199dbf0789534f6e62c690d7ca9775be21796a38687907c990422131bdf5")
