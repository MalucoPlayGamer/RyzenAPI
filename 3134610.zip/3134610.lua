-- Lua provided by RyzenAPI
-- Game: Slave Of The Police Officer

-- MAIN APPLICATION
addappid(3134610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134611, 1, "f2034932d7360d65f2a38fd86b180a529fa1af2135fb0c3189832a147e5c79e3")
