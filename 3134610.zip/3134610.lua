-- Lua provided by RyzenAPI 
-- Game: AppID 3134610
addappid(3134610)
addappid(3134611, 1, "f2034932d7360d65f2a38fd86b180a529fa1af2135fb0c3189832a147e5c79e3")
