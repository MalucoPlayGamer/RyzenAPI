-- Lua provided by RyzenAPI
-- Game: Kissed by the Baddest Bidder

-- MAIN APPLICATION
addappid(2311350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311351, 1, "0903943089fd9bfa2def6510da2a446e77ed460b47df158965f9424281861f01")

