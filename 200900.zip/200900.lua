-- Lua provided by RyzenAPI
-- Game: Cave Story+

-- MAIN APPLICATION
addappid(200900)
addappid(228983)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(200903,0,"4f3a77562ad23e2f1efec7609a14cea6aa8ca699b1c23b29b4e68baf6ff2998c")
addappid(200905,0,"55328048c4a994b1db1536e0c976348548ece46b93948cc97685f5ffcd3d5207")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
