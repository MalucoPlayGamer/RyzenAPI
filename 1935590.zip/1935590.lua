-- Lua provided by RyzenAPI
-- Game: Queen of the flies 蝇后 Soundtrack

-- MAIN APPLICATION
addappid(1935590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935591, 1, "673ae0adbb746011cc20c519fd889b29a40b73a6b3083c6a357071a7d045ffae")
addappid(1935592, 1, "d5b83311a8f91cd47813e0cd08bd40940155038bae630c203497bf59e84e325b")

