-- Lua provided by RyzenAPI
-- Game: AppID 1656930

-- MAIN APPLICATION
addappid(1656930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656931, 1, "b376bdb0502d1e99844e5c84dd2cd9b178186f17f4ec21d2b4a4c7cc5fff47cf")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3283710)
addappid(3290720)
addappid(3290730)
addappid(3290740)
addappid(3290750)
addappid(3290760)
addappid(3290770)
addappid(3623610)
