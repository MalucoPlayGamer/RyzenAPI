-- Lua provided by RyzenAPI
-- Game: 1656930

-- MAIN APPLICATION
addappid(1656930)
-- Game: addappid(1656930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656931, 1, "b376bdb0502d1e99844e5c84dd2cd9b178186f17f4ec21d2b4a4c7cc5fff47cf")
