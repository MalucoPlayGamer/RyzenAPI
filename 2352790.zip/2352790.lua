-- Lua provided by RyzenAPI 
-- Game: Goblin Lord wants me to become a Virgin Wizard by Managing The Brothel!?
addappid(2352790)
addappid(2352791, 1, "c595d21810f6e0670e83a7b8411c4df90a312e4ed3694bc1d0dd17c72dcf0d1f")
