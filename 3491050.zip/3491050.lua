-- Lua provided by RyzenAPI
-- Game: 3491050

-- MAIN APPLICATION
addappid(3491050)
-- Game: addappid(3491050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491050,0,"f6b27a2df5bb33dc24ed21765493addb640aa702c74cacf977040d25d0e010a7")
