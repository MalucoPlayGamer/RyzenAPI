-- Lua provided by RyzenAPI
-- Game: AppID 524220

-- MAIN APPLICATION
addappid(524220)

-- MAIN APP DEPOTS / PACKAGES
addappid(524221, 1, "710eaf838fca522739fd6f0741fc539dbfb3e69df0bca4f0daed6d9789cac571")
addappid(580600, 0, "67169947379fca33e6a1fd52fd5d4c6f45234151a71bfd9f5e6cda8bdcfab349")
addappid(580610, 0, "b6542835e2fd44948c08a553cab57020dce3620f6677ff161f908160be1de0dd")
addappid(583990, 0, "cfe4dbbe0d5622ff101a177b2bd7e089e1fb1afd241cda936d0fc3ac7d4010d1")
addappid(583991, 0, "6d4ffe017d1c3b9a876f16684204feb1f303a3b6f8327a8cd5246c74799587f0")
addappid(583992, 0, "8f903ba92f0e6eb40ae27b57eb1a1ba3672599687013ec0a1685bffb8cf78a93")
addappid(583993, 0, "8feaf96bd01fb95f5a288544933692972ad398cf76355a6589a6c85475f7cc95")
addappid(583994, 0, "8b754108a01dcdb855841b04bdac5882b22d07844e6d364adbe5efd46d8ecdaa")
addappid(1017430, 0, "3f639279ce3e6f19d6e4093f0af4032334e31a0e1203288a5da6419f82d04720")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
