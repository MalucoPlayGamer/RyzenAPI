-- Lua provided by RyzenAPI 
-- Game: Cyber OutRun
addappid(1132410)
addappid(1132411, 1, "1537fdb6891e6d153acfe0f9f5dbba4268b62108f1cb0bd93fb1a747d0fbe30e")
