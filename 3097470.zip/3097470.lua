-- Lua provided by RyzenAPI
-- Game: Game: Choppy Cuts PlayTest

-- MAIN APPLICATION
addappid(3097470)
-- Game: addappid(3097470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097471, 1, "fc2811d2580558763f3dda122217d0b4483e207e83b70af72c38fb545e55b965")
