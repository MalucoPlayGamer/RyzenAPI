-- Lua provided by RyzenAPI
-- Game: Earth Overclocked

-- MAIN APPLICATION
addappid(387060)

-- MAIN APP DEPOTS / PACKAGES
addappid(387062,0,"d6ea6f81e82fcf61c3ca52e015fe39608f5063df22dd8015bc33a994ed3875d3")
addappid(387063,0,"304b80ecfb518c5e2d0c10f0ff84c4b13380a015412abc523a6f55f0e56e573f")
