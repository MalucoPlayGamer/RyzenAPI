-- Lua provided by RyzenAPI
-- Game: Game: Apocalypse Hotel - The Post-Apocalyptic Hotel Simulator!

-- MAIN APPLICATION
addappid(423700)
addappid(443710)
addappid(446900)
-- Game: addappid(423700)

-- MAIN APP DEPOTS / PACKAGES
addappid(423701, 1, "8bd91c27bc5ca9ee87ce3c74ce98f5873daf94d62d68b70daca92e24874b0044")
