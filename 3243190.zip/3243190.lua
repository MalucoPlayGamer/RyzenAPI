-- Lua provided by RyzenAPI 
-- Game: AppID 3243190
addappid(3243190)
addappid(3243191, 1, "1d824266375cee6f4a2a806d88eacb83417e0ceb562e70c4fc14c85ebe87394f")
