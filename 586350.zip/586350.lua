-- Lua provided by RyzenAPI
-- Game: Game: AppID 586350

-- MAIN APPLICATION
addappid(586350)
-- Game: addappid(586350)

-- MAIN APP DEPOTS / PACKAGES
addappid(586351, 1, "83da3f44facbea182172e91ca3c15e709702e5d3af6562b06ef3d460c94d7ad1")
addappid(586352, 1, "eff512fe80ac7e3d6454359d3b5caf0d300798e7bbdb281b39667bc4207a41aa")
