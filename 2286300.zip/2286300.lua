-- Lua provided by RyzenAPI 
-- Game: Hentai Casual Slider 2
addappid(2286300)
addappid(2286301, 1, "c5e3b1909ee082252d107feda03492cf4350285d1c6f56c250d0ab13a7070dfb")
