-- Lua provided by RyzenAPI
-- Game: Hentai Casual Slider 2

-- MAIN APPLICATION
addappid(2286300)
-- Game: addappid(2286300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286301, 1, "c5e3b1909ee082252d107feda03492cf4350285d1c6f56c250d0ab13a7070dfb")
