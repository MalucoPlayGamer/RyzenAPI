-- Lua provided by RyzenAPI
-- Game: Ad Astra: Sci-Fi Tower Defense

-- MAIN APPLICATION
addappid(3355750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3355751, 1, "d86837bfabfc74e46179dc1605d60b6d86e3c5e86c478cf11ec5ce492069c5ff")
