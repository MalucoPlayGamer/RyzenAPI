-- Lua provided by RyzenAPI
-- Game: Yakuza 3 Remastered

-- MAIN APPLICATION
addappid(1088710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1088711, 1, "c1b7e189e92f1444dccf6f8b7f8e0210e613a88b9d8de8c178044862d9c946f4")
addappid(1088712, 1, "cca872cb599f2e4755fe421841cf97f37a1664954eb4f96f09edd06b956da99e")
