-- Lua provided by RyzenAPI
-- Game: Game: AppID 1088710

-- MAIN APPLICATION
addappid(1088710)
-- Game: addappid(1088710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088711, 1, "c1b7e189e92f1444dccf6f8b7f8e0210e613a88b9d8de8c178044862d9c946f4")
addappid(1088712, 1, "cca872cb599f2e4755fe421841cf97f37a1664954eb4f96f09edd06b956da99e")
