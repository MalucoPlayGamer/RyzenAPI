-- Lua provided by RyzenAPI
-- Game: Dead Ground

-- MAIN APPLICATION
addappid(778410)

-- MAIN APP DEPOTS / PACKAGES
addappid(778411,0,"9cd4364d33cfc8b28eb71607224fda5348f09c6041e13dcdb028bc7f2c395eb2")
addappid(778412,0,"c0d93fb39a278196d2e8ce735a578918aac07e9a11f88c596c43dd7c8831a463")
addappid(786810,0,"6c477e47a2a4529ecd924c673a72373907c32f541525610ae35bf78b3b07fea9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
