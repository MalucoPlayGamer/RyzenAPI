-- Lua provided by RyzenAPI
-- Game: 2484990

-- MAIN APPLICATION
addappid(2484990)
-- Game: addappid(2484990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484991, 1, "387ce8e1ebb10e227a924105e788038869ddba18078a8b5d3a13dc6e3c62b4c2")
