-- Lua provided by RyzenAPI 
-- Game: Asgard's Fall: Origins
addappid(2484990)
addappid(2484991, 1, "387ce8e1ebb10e227a924105e788038869ddba18078a8b5d3a13dc6e3c62b4c2")
