-- 3211430's Lua and Manifest Created by Hubcap Manifest
-- BRIGANDINE ABYSS
-- Created: August 26, 2026 at 12:17:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3211430, 1, "17122ea21a52894e4742e41d2b1a70e260034a4ce66886e3273c54162b4fa93b") -- BRIGANDINE ABYSS
-- MAIN APP DEPOTS
addappid(3211431, 1, "70bd14e7fc417a528cc83f004c834f11ebd619432df3d2427bc5de5d995eaffa") -- Depot 3211431
setManifestid(3211431, "7803353672357476033", 7754897243)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- BRIGANDINE ABYSS Digital Artbook (AppID: 4884860)
addappid(4884860)
addappid(4884860, 1, "0f91df7bf70d36a9492b48742034ad212051126bb53af0134e8943d639d02607") -- BRIGANDINE ABYSS Digital Artbook - Depot 4884860
setManifestid(4884860, "2554402755870719282", 706273488)