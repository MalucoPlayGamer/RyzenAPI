-- Lua provided by RyzenAPI
-- Game: The Book of Outcasts Demo

-- MAIN APPLICATION
addappid(3232540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232541, 1, "62056450437db53a03f98f85b7dd0efae4983a765994ccbf42b4d4017b2107c8")
