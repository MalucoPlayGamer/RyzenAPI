-- Lua provided by SkyAPI 
-- Game: The Book of Outcasts Demo
addappid(3232540)
addappid(3232541, 1, "62056450437db53a03f98f85b7dd0efae4983a765994ccbf42b4d4017b2107c8")
