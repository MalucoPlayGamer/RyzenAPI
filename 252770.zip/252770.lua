-- Lua provided by RyzenAPI
-- Game: Vox

-- MAIN APPLICATION
addappid(252770)
-- Game: addappid(252770)

-- MAIN APP DEPOTS / PACKAGES
addappid(252771, 1, "dd60955a22b3af6da5a3c28e5d40ffcc9277572ec1cc0329adba3b37c2eca19f")
