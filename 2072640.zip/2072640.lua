-- Lua provided by RyzenAPI
-- Game: addappid(2072640)

-- MAIN APPLICATION
addappid(2072640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072641, 1, "b7290b03e4ad47dbcf3fd30925567e2a1fd73646b146a1e769779540ec145bb6")
