-- Lua provided by RyzenAPI
-- Game: Inout

-- MAIN APPLICATION
addappid(2072640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072641, 1, "b7290b03e4ad47dbcf3fd30925567e2a1fd73646b146a1e769779540ec145bb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
