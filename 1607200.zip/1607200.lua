-- Lua provided by RyzenAPI
-- Game: Cyanotype Daydream -The Girl Who Dreamed the World-

-- MAIN APPLICATION
addappid(1607200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1607201, 1, "dff95195adfa9384ba0c069a77c7447ce36d54e5b7e28b92621c806cab10a165")

