-- Lua provided by RyzenAPI
-- Game: addappid(1607200)

-- MAIN APPLICATION
addappid(1607200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607201, 1, "dff95195adfa9384ba0c069a77c7447ce36d54e5b7e28b92621c806cab10a165")
