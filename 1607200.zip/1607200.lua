-- Lua provided by RyzenAPI 
-- Game: Cyanotype Daydream -The Girl Who Dreamed the World-
addappid(1607200)
addappid(1607201, 1, "dff95195adfa9384ba0c069a77c7447ce36d54e5b7e28b92621c806cab10a165")
