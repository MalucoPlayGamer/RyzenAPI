-- Lua provided by RyzenAPI
-- Game: My Singing Monsters

-- MAIN APPLICATION
addappid(1419170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419171, 1, "037170f89e01e246d1dafb189488712ace2439afb5295c7d733d21be59d02216")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1889780)
addappid(1894500)
addappid(1896460)
addappid(1896470)
addappid(1896480)
addappid(2247650)
addappid(2247651)
addappid(2286120)
addappid(2295860)
addappid(2324820)
addappid(2339560)
addappid(2352700)
addappid(2393310)
addappid(2416950)
addappid(2447740)
addappid(2477510)
addappid(2533100)
addappid(2616110)
addappid(2616150)
