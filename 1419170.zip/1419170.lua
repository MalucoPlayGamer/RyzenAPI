-- Lua provided by SkyAPI 
-- Game: My Singing Monsters
addappid(1419170)
addappid(1419171, 1, "037170f89e01e246d1dafb189488712ace2439afb5295c7d733d21be59d02216")
