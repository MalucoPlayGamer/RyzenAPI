-- Lua provided by RyzenAPI
-- Game: AppID 315260

-- MAIN APPLICATION
addappid(315260)

-- MAIN APP DEPOTS / PACKAGES
addappid(315261, 1, "a536132fe9ac5ed0d2c468f573e6a0272471ad4fd61a7f90e7cfd4a6f78a504f")

