-- Lua provided by RyzenAPI
-- Game: Game: OVER‧DeviL 聖石少女篇 Soundtrack

-- MAIN APPLICATION
addappid(2595460)
-- Game: addappid(2595460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595461, 1, "ae1822ae2f2fc4216bdd20898a6b82f50f2d1fa2bf666f7f8b9c7bc277f618c2")
