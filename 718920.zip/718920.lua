-- Lua provided by RyzenAPI
-- Game: Dead Noir the Heart

-- MAIN APPLICATION
addappid(718920)

-- MAIN APP DEPOTS / PACKAGES
addappid(718921,0,"9e3de04a2e2541c535a9d46266d57d6e9ccbcfc7cff4ef7c3c7103aca00648d3")

