-- Lua provided by RyzenAPI
-- Game: addappid(436280)

-- MAIN APPLICATION
addappid(436280)

-- MAIN APP DEPOTS / PACKAGES
addappid(436281, 1, "279c2eb2b16cd372a66c194ff1ac4c85b1fb99f42d1b76b6a6ef85cc7eb054dd")
