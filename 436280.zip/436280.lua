-- Lua provided by RyzenAPI 
-- Game: AppID 436280
addappid(436280)
addappid(436281, 1, "279c2eb2b16cd372a66c194ff1ac4c85b1fb99f42d1b76b6a6ef85cc7eb054dd")
