-- Lua provided by RyzenAPI
-- Game: Game: AppID 800280

-- MAIN APPLICATION
addappid(800280)
-- Game: addappid(800280)

-- MAIN APP DEPOTS / PACKAGES
addappid(800281, 1, "ac52456229f33319b1cf71b62fc404f1fdf6c64fc4ec6c89e7256c3182d44db6")
