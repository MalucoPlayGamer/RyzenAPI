-- Lua provided by RyzenAPI
-- Game: Splash Dino 2

-- MAIN APPLICATION
addappid(3086010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086011, 1, "924f28cb3b20d7cd5ff331455ed6392e343e63e9a9b283331359459bd3a82df9")

