-- Lua provided by RyzenAPI
-- Game: Cubot

-- MAIN APPLICATION
addappid(340280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(340281, 1, "6a1d24d14ddc347edb96180403a4c121ebf6aec0ba4b9d896ec8c74975b9af02")
addappid(340282, 1, "4790a3a449cb563c8a0238b2a9aff204e06fbca8f313019c122842613325c019")
addappid(340283, 1, "4314ef25af3401305f29c3319f146cb3334773b92e8b5424427271b15dc2437d")
addappid(340284, 1, "dd196192f4ffffa67b50ba69f127c739e6183ef04ce57572a4863de1acb60731")
addappid(340285, 1, "c59bf8b76e704624ddf2e741da23dfb180b4d31b3599cc6aa0f72572ff7c2762")
addappid(340286, 1, "a89e2874a92303ed2cbbfe09b68de0856fab947ec5eddde7dca980fdd9586add")

