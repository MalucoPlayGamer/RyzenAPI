-- Lua provided by RyzenAPI
-- Game: addappid(1205020)

-- MAIN APPLICATION
addappid(1205020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205021, 1, "d729dfa22e02322156b60222893541cdaec9d802a639516bc7ad7dd8496489cc")
