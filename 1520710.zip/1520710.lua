-- Lua provided by RyzenAPI
-- Game: Entodrive

-- MAIN APPLICATION
addappid(1520710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520711, 1, "38667e98aafd2c19615cb8ef2cb08e4793c8dc2adb75dd937a07fa808940650b")
addappid(1520713, 1, "10bff2f3ed992b1b13db25b8bd81ee21e3c04436f6ef3076949e03948a2916a3")
