-- Lua provided by RyzenAPI
-- Game: 2705230

-- MAIN APPLICATION
addappid(2705230)
-- Game: addappid(2705230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705231, 1, "fc2754a8af4a2b49bf6a8e26adb39faa3ca13bf52dd6cdace8a125d5d9948518")
