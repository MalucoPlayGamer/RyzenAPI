-- Lua provided by RyzenAPI
-- Game: FALL

-- MAIN APPLICATION
addappid(2705230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2705231, 1, "fc2754a8af4a2b49bf6a8e26adb39faa3ca13bf52dd6cdace8a125d5d9948518")

