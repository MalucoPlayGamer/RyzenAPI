-- Lua provided by SkyAPI 
-- Game: Livelock
addappid(251230)
addappid(251231, 1, "73f1a2ee3798f1c940f21f0cbf6b68e2046e26070f0e3f7b65dd296208e0bcee")
addappid(251232, 1, "8018afe69e0cd3ac45e5dcce60cb3963df183b0ddbb07bab95fb9f10a14ec1f3")
addappid(518370, 0, "ae5c6a22e2173d0428edfd3e9b805c62f3ba289377890f60150c3419c34856f1")
