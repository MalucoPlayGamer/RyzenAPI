-- Lua provided by RyzenAPI
-- Game: Livelock

-- MAIN APPLICATION
addappid(251230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251231, 1, "73f1a2ee3798f1c940f21f0cbf6b68e2046e26070f0e3f7b65dd296208e0bcee")
addappid(251232, 1, "8018afe69e0cd3ac45e5dcce60cb3963df183b0ddbb07bab95fb9f10a14ec1f3")
addappid(518370, 0, "ae5c6a22e2173d0428edfd3e9b805c62f3ba289377890f60150c3419c34856f1")

