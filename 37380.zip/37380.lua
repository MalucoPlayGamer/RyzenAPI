-- Lua provided by RyzenAPI
-- Game: Game: Valerie Porter and the Scarlet Scandal™

-- MAIN APPLICATION
addappid(37380)
-- Game: addappid(37380)

-- MAIN APP DEPOTS / PACKAGES
addappid(37381, 1, "0085776622be97d73a0e1a1bd9e7a50f392aad0d021d104ded0c52acd83cf4a0")
