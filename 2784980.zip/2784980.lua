-- Lua provided by RyzenAPI
-- Game: Tangles - تشابك

-- MAIN APPLICATION
addappid(2784980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784981, 1, "f404513c1ad1a3e60ec354d1fb3667f344ad4a31c8d45daef6c100013559a412")

