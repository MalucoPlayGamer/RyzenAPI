-- Lua provided by RyzenAPI
-- Game: Tangles - تشابك

-- MAIN APPLICATION
addappid(2784980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784981, 1, "f404513c1ad1a3e60ec354d1fb3667f344ad4a31c8d45daef6c100013559a412")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
