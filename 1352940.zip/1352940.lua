-- Lua provided by RyzenAPI
-- Game: Game: Creaks Soundtrack + Art Book

-- MAIN APPLICATION
addappid(1352940)
-- Game: addappid(1352940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352941, 1, "1063828d86ffdb4cf46cb84ae05e307133f477dea5a4c6cc705d3349fc0816a2")
addappid(1352942, 1, "6deaa2456a35de8b9764482b4c1d0e0602365de10de573284496a150b7ae7a6a")
addappid(1352943, 1, "24776940f3538a0bc69312f1390859f28d506a3d9c10c8fecb05453cfa563454")
addappid(1352944, 1, "bf4110eb3a7330973633c55ca43a2f83111f6bde8384ef41c6c64db3c22afd9f")
