-- Lua provided by RyzenAPI
-- Game: exclusion| 間引き

-- MAIN APPLICATION
addappid(2392640)
-- Game: addappid(2392640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392641, 1, "7aa699e51c2f44432a11dfd6e701cf7fa7155002dff92a0a1931a529f27ab0dd")
