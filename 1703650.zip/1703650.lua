-- Lua provided by RyzenAPI
-- Game: 1703650

-- MAIN APPLICATION
addappid(1703650)
addappid(1703652)
-- Game: addappid(1703650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703653,0,"c20c4598c82f7d99649eb1795ea3a2658a5f6eb1a591a556e150d89fd347fba1")
