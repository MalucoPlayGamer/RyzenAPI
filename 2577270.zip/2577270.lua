-- Lua provided by RyzenAPI
-- Game: 神仙打架

-- MAIN APPLICATION
addappid(2577270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577271, 1, "473edbb08a7a76179d0c51a162f38c83f1937c9daa67924d433a90bd7bbb5f2b")

