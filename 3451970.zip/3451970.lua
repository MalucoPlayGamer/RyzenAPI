-- 3451970's Lua and Manifest Created by Hubcap Manifest
-- Backrooms Anomaly
-- Created: July 25, 2026 at 06:06:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3451970, 1, "fc56b141fa1fdec8b944df9947734b1fa0cf38a48c63dd70151d45645ffc4503") -- Backrooms Anomaly
-- MAIN APP DEPOTS
addappid(3451971, 1, "6ca4f623e9a908c820bbdda506cff3d4d885efc92a041548849ddc8637127a4f") -- Depot 3451971
setManifestid(3451971, "3444180923248339624", 1834847138)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4818320) -- Backrooms Anomaly - Supporter Pack