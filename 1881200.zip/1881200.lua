-- Lua provided by RyzenAPI
-- Game: TRYP FPV: Drone Racer Simulator

-- MAIN APPLICATION
addappid(1881200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881201, 1, "f0c72e73e6514305f518e6fbdee9ccf74bfe9ad8325ad36eaf5d204c76ebfda7")
addappid(1881202, 1, "e1f89aa4493b8fb4423cc580b54981e7f78de184b5f9274a4e856c479889754d")
addappid(1881203, 1, "ba9a331ba045d2c952f8941982c260c7144462375b666d6cf80b7604b7112355")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
