-- Lua provided by SkyAPI 
-- Game: TRYP FPV: Drone Racer Simulator
addappid(1881200)
addappid(1881201, 1, "f0c72e73e6514305f518e6fbdee9ccf74bfe9ad8325ad36eaf5d204c76ebfda7")
addappid(1881202, 1, "e1f89aa4493b8fb4423cc580b54981e7f78de184b5f9274a4e856c479889754d")
addappid(1881203, 1, "ba9a331ba045d2c952f8941982c260c7144462375b666d6cf80b7604b7112355")
