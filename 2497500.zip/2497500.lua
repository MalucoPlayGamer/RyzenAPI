-- Lua provided by RyzenAPI
-- Game: AppID 2497500

-- MAIN APPLICATION
addappid(2497500)
-- Game: addappid(2497500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497501, 1, "2b193ff0ebbef536005a68bb462c3eb1f012bca34b3bbbcc8001e212344092d1")
