-- Lua provided by RyzenAPI
-- Game: 1890860

-- MAIN APPLICATION
addappid(1890860)
-- Game: addappid(1890860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890861, 1, "959ca5bfaceadcf9f4a31c1c9a0f21878dde64894cb0868d1aeb55a59c892bfe")
