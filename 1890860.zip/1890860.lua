-- Lua provided by RyzenAPI
-- Game: AppID 1890860

-- MAIN APPLICATION
addappid(1890860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1890861, 1, "959ca5bfaceadcf9f4a31c1c9a0f21878dde64894cb0868d1aeb55a59c892bfe")

