-- Lua provided by RyzenAPI
-- Game: Robots.io

-- MAIN APPLICATION
addappid(704070)

-- MAIN APP DEPOTS / PACKAGES
addappid(704071, 1, "cce78259c7053e18c8f11ee499994693d578f88071396d2cf2ecc131645b8edf")

