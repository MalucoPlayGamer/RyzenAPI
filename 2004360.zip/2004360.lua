-- Lua provided by RyzenAPI
-- Game: Hell Division

-- MAIN APPLICATION
addappid(2004360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004361, 1, "a876ea660c77af4c1c55293d891286b177e099b708d92a7fc6c8317780bc6e70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
