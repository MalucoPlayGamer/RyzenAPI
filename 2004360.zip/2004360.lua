-- Lua provided by RyzenAPI
-- Game: Hell Division

-- MAIN APPLICATION
addappid(2004360)
-- Game: addappid(2004360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004361, 1, "a876ea660c77af4c1c55293d891286b177e099b708d92a7fc6c8317780bc6e70")
