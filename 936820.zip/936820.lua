-- Lua provided by RyzenAPI
-- Game: addappid(936820)

-- MAIN APPLICATION
addappid(936820)

-- MAIN APP DEPOTS / PACKAGES
addappid(936821, 1, "6fbde103aaf8d2d466f6c54c5c11e8944b965b276892cdfa1082bb613bdcc3b9")
