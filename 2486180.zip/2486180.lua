-- Lua provided by RyzenAPI
-- Game: SCP-479: Shadows of the Mind

-- MAIN APPLICATION
addappid(2486180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486181, 1, "1de42366f4374398c2b529c4801df928d41bda1de13106a2da7c1931042040e2")

