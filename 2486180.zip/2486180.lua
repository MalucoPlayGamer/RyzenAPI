-- Lua provided by RyzenAPI
-- Game: SCP-479: Shadows of the Mind

-- MAIN APPLICATION
addappid(2486180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486181, 1, "1de42366f4374398c2b529c4801df928d41bda1de13106a2da7c1931042040e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
