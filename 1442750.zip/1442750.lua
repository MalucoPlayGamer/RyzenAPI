-- Lua provided by RyzenAPI
-- Game: Invasion Vill

-- MAIN APPLICATION
addappid(1442750)
-- Game: addappid(1442750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442751, 1, "da3172dae1c5e29664856e56a81c677ba53b647075d443e9db5d7826b1a2ba00")
