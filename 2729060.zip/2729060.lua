-- Lua provided by RyzenAPI 
-- Game: BattleJuice Alchemist Demo
addappid(2729060)
addappid(2729061, 1, "12a958de9c42b4bffc026275808da6d8e6b74209dddaa59dd694d18e8d9ec68e")
