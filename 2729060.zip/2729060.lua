-- Lua provided by RyzenAPI
-- Game: BattleJuice Alchemist Demo

-- MAIN APPLICATION
addappid(2729060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729061, 1, "12a958de9c42b4bffc026275808da6d8e6b74209dddaa59dd694d18e8d9ec68e")
