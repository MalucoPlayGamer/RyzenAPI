-- Lua provided by RyzenAPI
-- Game: 流言侦探

-- MAIN APPLICATION
addappid(1559300)
-- Game: addappid(1559300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559301, 1, "f9957f3c2087c9892d08b3f05eb5c16bc054c922c9c92aa03fc4371b9457e1d2")
