-- Lua provided by RyzenAPI
-- Game: Moorhuhn Kart 4

-- MAIN APPLICATION
addappid(3012980)
-- Game: addappid(3012980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012981, 1, "6de9da0f259e02025625db07aa47344a2b2d65a0337cf28a5123cf8196bc1841")
