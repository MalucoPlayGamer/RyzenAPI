-- Lua provided by RyzenAPI
-- Game: 451830

-- MAIN APPLICATION
addappid(451830)
-- Game: addappid(451830)

-- MAIN APP DEPOTS / PACKAGES
addappid(451831, 1, "2d7a58fa3ad39e7c69c470c4ff33578f177ab8ef464e42f143898041fffd1127")
