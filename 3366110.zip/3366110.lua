-- Lua provided by SkyAPI 
-- Game: Sil and the Fading World Demo
addappid(3366110)
addappid(3366111, 1, "7b8e6f812c58f5a2a5ca609deface75d691eb222b2724369554d7f273c93e3c6")
