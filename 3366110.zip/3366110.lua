-- Lua provided by RyzenAPI
-- Game: Sil and the Fading World Demo

-- MAIN APPLICATION
addappid(3366110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3366111, 1, "7b8e6f812c58f5a2a5ca609deface75d691eb222b2724369554d7f273c93e3c6")

