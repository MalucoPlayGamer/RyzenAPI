-- Lua provided by RyzenAPI 
-- Game: AppID 1015650
addappid(1015650)
addappid(1015651, 1, "8ff41f01a64cac4c70551e292076732a0e9c8125c8d1956907000a40d1f64f1e")
