-- Lua provided by RyzenAPI
-- Game: addappid(1761380)

-- MAIN APPLICATION
addappid(1761380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761381, 1, "519cf38b3d934c5d95b676bd2ffc86297dc57ffbd4c050eb85007b57ba765794")
