-- Lua provided by RyzenAPI
-- Game: addappid(1547410)

-- MAIN APPLICATION
addappid(1547410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547411, 1, "569e3d0edacd0fe66850a2010e8b0690aafbaed0f807e04e7a639dd6d2382379")
