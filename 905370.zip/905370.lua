-- Lua provided by RyzenAPI
-- Game: 905370

-- MAIN APPLICATION
addappid(905370)
-- Game: addappid(905370)

-- MAIN APP DEPOTS / PACKAGES
addappid(905371, 1, "1dabe6de9e609499c97417707d6b45f073663e8905a98f67290fd7e6da9362a4")
