-- Generated with Luie @ https://lua.tools/
-- 905370 - Game Migrated to Another Steam Page
-- Generated 2026-07-25 23:13:49 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(905370)

-- Main Depots
addappid(905371, 1, "1dabe6de9e609499c97417707d6b45f073663e8905a98f67290fd7e6da9362a4")
setManifestid(905371, "2610860857680803864", 62232882774)

-- DLC's (no depot keys required)
addappid(1084100) -- Conqueror's Blade - Immortal Warlord Collector Pack
addappid(1084110) -- DLC 1084110
addappid(1092860) -- DLC 1092860
addappid(1133820) -- DLC 1133820
addappid(1133840) -- DLC 1133840
addappid(1133850) -- DLC 1133850
addappid(1158200) -- DLC 1158200
addappid(1158210) -- DLC 1158210
addappid(1210170) -- DLC 1210170
addappid(1210171) -- DLC 1210171
addappid(1211920) -- DLC 1211920
addappid(1297120) -- Conqueror's Blade - Season 3 - Soldiers of Fortune
addappid(1335450) -- DLC 1335450
addappid(1356920) -- DLC 1356920
addappid(1356930) -- DLC 1356930
addappid(1371870) -- DLC 1371870
addappid(1416640) -- Conqueror's Blade - Battle Born Bundle
addappid(1420110) -- DLC 1420110
addappid(1428110) -- DLC 1428110
addappid(1466380) -- DLC 1466380
addappid(1496410) -- DLC 1496410
addappid(1515110) -- Conqueror's Blade - Imperial Heir Collector’s Pack
addappid(1515250) -- DLC 1515250
addappid(1568300) -- DLC 1568300
addappid(1581230) -- DLC 1581230
addappid(1601720) -- DLC 1601720
addappid(1658980) -- DLC 1658980
addappid(1676190) -- DLC 1676190
addappid(1755200) -- DLC 1755200
addappid(1844530) -- DLC 1844530
addappid(1864170) -- DLC 1864170
addappid(1924250) -- DLC 1924250
addappid(2022810) -- Conqueror's Blade - Helheim - Battle Pass
addappid(2057940) -- DLC 2057940
addappid(2132000) -- DLC 2132000
addappid(2216630) -- DLC 2216630
addappid(2237180) -- DLC 2237180
addappid(2237181) -- DLC 2237181
addappid(2321680) -- DLC 2321680
addappid(2446100) -- DLC 2446100
addappid(2575210) -- DLC 2575210
addappid(2722190) -- DLC 2722190
addappid(2881680) -- DLC 2881680
addappid(3065610) -- DLC 3065610
addappid(3065620) -- DLC 3065620
addappid(3065640) -- DLC 3065640
addappid(3065660) -- DLC 3065660
addappid(3065670) -- DLC 3065670
addappid(3065680) -- DLC 3065680

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
