-- Lua provided by RyzenAPI
-- Game: 2370380

-- MAIN APPLICATION
addappid(2370380)
-- Game: addappid(2370380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370381, 1, "3637e7d86a790db1f71a7d5c498c4ca8789bdf3d27f48b5fdf02b26c7b3446e3")
