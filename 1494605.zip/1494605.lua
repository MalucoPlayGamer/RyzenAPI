-- Lua provided by RyzenAPI
-- Game: 1494605

-- MAIN APPLICATION
addappid(1494605)
-- Game: addappid(1494605)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494605,0,"152c3ac9fcfa4da8b6260401888da318493f90b91b37569f4f4c1482a62af31d")
