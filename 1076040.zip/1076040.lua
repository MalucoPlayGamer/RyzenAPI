-- Lua provided by SkyAPI 
-- Game: Welcome To... Chichester OVN 1 : The Beach
addappid(1076040)
addappid(1076041, 1, "819b8755183f7170acb45abec8f0de31c36e64100cf184b4de1ca51c26d8a901")
addappid(1076042, 1, "8feacfcc77fb9c99082820981c0c5ab445d8e3eaaa30c0be77d518cd6bb69907")
addappid(1076043, 1, "e638c8e6a29f88e3066f182f95d823eb08448cac9c8c3bb36db9cf3803345c3c")
addappid(1078190)
