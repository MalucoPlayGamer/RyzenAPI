-- Lua provided by RyzenAPI
-- Game: Game: PIXELMAN

-- MAIN APPLICATION
addappid(438000)
-- Game: addappid(438000)

-- MAIN APP DEPOTS / PACKAGES
addappid(438001, 1, "027ff27afb38d7eb919176708c950f9f73256abbd4b14bf26d3a2e98bc227f90")
