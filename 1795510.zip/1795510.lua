-- Lua provided by RyzenAPI
-- Game: addappid(1795510)

-- MAIN APPLICATION
addappid(1795510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795511, 1, "eabb35f6510cd9f78eec579a5e174d933cacc90ee775454aee30443d8e995c10")
