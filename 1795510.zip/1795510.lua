-- Lua provided by RyzenAPI
-- Game: Rise of Rebellion～地罰上らば竜の降る～

-- MAIN APPLICATION
addappid(1795510)
-- Game: addappid(1795510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795511, 1, "eabb35f6510cd9f78eec579a5e174d933cacc90ee775454aee30443d8e995c10")
