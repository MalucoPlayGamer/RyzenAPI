-- Lua provided by RyzenAPI
-- Game: subROV : Underwater Discoveries

-- MAIN APPLICATION
addappid(1648760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648761, 1, "2d558ae2ac3b5cd74107fd283fa2f1d8ead696257f1cd232eefd5d8e69107f0b")

