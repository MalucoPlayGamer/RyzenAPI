-- Lua provided by RyzenAPI
-- Game: GraFi Easter

-- MAIN APPLICATION
addappid(1282370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282371, 1, "5dfdb41b6347bb98c0d5c0193488f35eb09e35babbbd9d77e73db7bf37593c94")

