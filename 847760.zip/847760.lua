-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(847760)
-- Game: addappid(847760)

-- MAIN APP DEPOTS / PACKAGES
addappid(847760,0,"6da1fa1203f86e853aad6e74092a49f75d011a2d73f068c0f37903d378fe7008")
