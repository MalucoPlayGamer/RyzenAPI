-- Lua provided by RyzenAPI
-- Game: Game: AppID 575740

-- MAIN APPLICATION
addappid(575740)
-- Game: addappid(575740)

-- MAIN APP DEPOTS / PACKAGES
addappid(575741, 1, "2ec62ff9bfe4e6650c8c255fd5396d9d4b89286e9a31040d7f36eeaa89282575")
