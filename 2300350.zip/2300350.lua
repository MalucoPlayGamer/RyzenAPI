-- Lua provided by SkyAPI 
-- Game: AppID 2300350
addappid(2300350)
addappid(2300351, 1, "77e4687e5823565206bfa4484cc33e36d27805dccef3e87e3530aee8662a5e79")
