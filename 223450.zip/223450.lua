-- Lua provided by RyzenAPI
-- Game: Dyad

-- MAIN APPLICATION
addappid(223450)

-- MAIN APP DEPOTS / PACKAGES
addappid(223451, 1, "e0f738189eca53bb3ecfd221a95acb605220e6b36c5ba890c71e46a6a4500845")
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)

