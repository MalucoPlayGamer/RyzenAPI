-- Lua provided by RyzenAPI
-- Game: 223450

-- MAIN APPLICATION
addappid(223450)
-- Game: addappid(223450)

-- MAIN APP DEPOTS / PACKAGES
addappid(223451, 1, "e0f738189eca53bb3ecfd221a95acb605220e6b36c5ba890c71e46a6a4500845")
