-- Lua provided by RyzenAPI
-- Game: Asurya's Embers

-- MAIN APPLICATION
addappid(2491710)
addappid(2890490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491711, 1, "5eae25c420d25e10f01274c31bcd7ed866f3369b87864b50bada00cd42a46e8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
