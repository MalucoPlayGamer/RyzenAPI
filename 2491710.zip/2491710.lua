-- Lua provided by RyzenAPI
-- Game: 2491710

-- MAIN APPLICATION
addappid(2491710)
addappid(2890490)
-- Game: addappid(2491710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491711, 1, "5eae25c420d25e10f01274c31bcd7ed866f3369b87864b50bada00cd42a46e8c")
