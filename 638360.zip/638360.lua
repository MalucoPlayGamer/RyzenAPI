-- Lua provided by RyzenAPI
-- Game: AppID 638360

-- MAIN APPLICATION
addappid(638360)
-- Game: addappid(638360)

-- MAIN APP DEPOTS / PACKAGES
addappid(638361, 1, "da4c397800163d24d64a2edfb69dff8a77b62a05976d1bdb5280cf10e4555e53")
addappid(638362, 1, "9d1dfacbcf39ffde25601081bcff8c74f5e1b1f65bb3f5befe104f1d99a92286")
addappid(638363, 1, "234df12626ecad4dc6ac6e393eda86fd2e27f43f5b0aa7c3ec974bfcb71ccde5")
addappid(638364, 1, "e450b8ad2ef05d4b49ec2552c28a261e23a0ce9a808b09bd1281ce04cb76721c")
addappid(638365, 1, "d32c1361e3f8cef4acd5d7e4817e6b6d47fd5a3a6e5e851b595b10bd6a4203b4")
addappid(638366, 1, "9882379a2781d6e7eda826acc911e644b143ffd698c54f91f91c6b7f3c77f565")
