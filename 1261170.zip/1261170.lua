-- Lua provided by RyzenAPI
-- Game: 1261170

-- MAIN APPLICATION
addappid(1261170)
-- Game: addappid(1261170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261171, 1, "fcebd9556b5dc93e37f450c8960c2b68a5882fec7013ad5e1502746a64317ac0")
