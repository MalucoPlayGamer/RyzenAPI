-- Lua provided by RyzenAPI 
-- Game: AppID 1261170
addappid(1261170)
addappid(1261171, 1, "fcebd9556b5dc93e37f450c8960c2b68a5882fec7013ad5e1502746a64317ac0")
