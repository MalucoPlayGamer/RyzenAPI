-- Lua provided by RyzenAPI
-- Game: Game: Check Inn

-- MAIN APPLICATION
addappid(2741390)
-- Game: addappid(2741390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741391, 1, "d80dbd017b4f497d1a0e879de7840fbdd4694b20f0452033b41ad6ef1752bf32")
