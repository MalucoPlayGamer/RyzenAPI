-- Lua provided by RyzenAPI
-- Game: Mountain Taxi Driver

-- MAIN APPLICATION
addappid(1092980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092981, 1, "7d3475d0810dba422adc6ee5b6e6a9d6141a53c6d20b146c907637e0cd9f208f")

