-- Lua provided by RyzenAPI
-- Game: 8-Bit Adventures 2

-- MAIN APPLICATION
addappid(733110)

-- MAIN APP DEPOTS / PACKAGES
addappid(733111, 1, "a80a22eca7b1d266410417dc7e1bbf51ec311f2671592a1225e673bd3349a5ae")
