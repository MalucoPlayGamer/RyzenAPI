-- Lua provided by RyzenAPI
-- Game: addappid(1380420)

-- MAIN APPLICATION
addappid(1380420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380421, 1, "063de495d30f67af07725b9746e40ebfb3bde336231ac892615f66fd1dddf09b")
