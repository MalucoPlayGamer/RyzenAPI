-- Lua provided by RyzenAPI
-- Game: Grow: Song of the Evertree

-- MAIN APPLICATION
addappid(1380420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1380421, 1, "063de495d30f67af07725b9746e40ebfb3bde336231ac892615f66fd1dddf09b")
