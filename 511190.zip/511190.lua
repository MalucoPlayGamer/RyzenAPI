-- Lua provided by RyzenAPI
-- Game: AppID 511190

-- MAIN APPLICATION
addappid(511190)
-- Game: addappid(511190)

-- MAIN APP DEPOTS / PACKAGES
addappid(511191, 1, "b53268294d3e97a1b8eca03ef2e86072b67fd92a068c4b874ffa18dedd38e0a5")
