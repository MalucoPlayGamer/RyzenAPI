-- Lua provided by RyzenAPI 
-- Game: Diner Bros Inc
addappid(1733480)
addappid(1733481, 1, "154959c3ce4047f959af33b26883f4ebbed2e6b64a7f0bad061ff2c72ebdeecc")
