-- Lua provided by RyzenAPI
-- Game: Stellar Echoes

-- MAIN APPLICATION
addappid(2217450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217452,0,"70304056ea7292ece6b547298411007cee137e6b67f583af7072bd98e69d80b4")

