-- Lua provided by RyzenAPI
-- Game: Invisible Mind

-- MAIN APPLICATION
addappid(502090)

-- MAIN APP DEPOTS / PACKAGES
addappid(502091, 1, "45457cc41a67f831fe02bdb4d9986950abdff676e15ec5660f63b883fb615712")

