-- Lua provided by RyzenAPI
-- Game: Disgaea 2 PC

-- MAIN APPLICATION
addappid(495280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(495281, 1, "768e19e8e736fdb540c4bb1031d9953458d559611d4d4f8401279f92c5cd7f95")
addappid(495282, 1, "6d7ab38c1384d1ff20d999fcfcba379ce2868e989ffac388562cb5e77653d13d")
addappid(495283, 1, "e3d9e31d335200546f5ed98e27d53c43616f2a7f855bb654eb2827bbf9476610")
addappid(495284, 1, "3a5f712955d1fdbfa6e81f0cbeaf6a431f1b6c77b3b7b7d5d368d77e77b1e911")
addappid(495285, 1, "fdf5c92f78426b352d2a02fc90ae92c2e147d6968cf3998b62aee414b96ceb2a")
addappid(495286, 1, "ba7dae9391bb0449ef1e1e2ac239b7d315046f7b14603bcaf3d1761912b008ee")
addappid(506460, 0, "abe86f4cbddb9dbbb27ba84048180c3c69862d3d9d0e9bf4875bf5f857ff3e08")

