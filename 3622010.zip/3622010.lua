-- Lua provided by RyzenAPI
-- Game: Putt Down

-- MAIN APPLICATION
addappid(3622010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3622011,0,"05886e1ee12ab949c8b6c5f1e5055f358676fba94a9f3a658de522ed976afc12")

