-- Lua provided by RyzenAPI
-- Game: Putt Down

-- MAIN APPLICATION
addappid(3622010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3622011,0,"05886e1ee12ab949c8b6c5f1e5055f358676fba94a9f3a658de522ed976afc12")

