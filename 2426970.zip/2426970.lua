-- Lua provided by RyzenAPI
-- Game: 2426970

-- MAIN APPLICATION
addappid(2426970)
-- Game: addappid(2426970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426971, 1, "185e4c67811c1ca17fafbfadcfcc242d4836690c2edf633ee0ada4656a341265")
