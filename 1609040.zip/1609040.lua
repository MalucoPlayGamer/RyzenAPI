-- Lua provided by RyzenAPI
-- Game: addappid(1609040)

-- MAIN APPLICATION
addappid(1609040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609041, 1, "6e56cf41667a3bbeccafb210ad8cc07d649307778b87f380fc080b729907ef5a")
