-- Lua provided by RyzenAPI
-- Game: AppID 3107230

-- MAIN APPLICATION
addappid(3107230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107231, 1, "e01badbf7c87775d1e879fd200eefee17fbbf84a35fdfb298424804440496a99")
