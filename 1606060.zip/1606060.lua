-- Lua provided by RyzenAPI
-- Game: Game: ZeroSpace Demo

-- MAIN APPLICATION
addappid(1606060)
-- Game: addappid(1606060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606061, 1, "1aac9f1e3a17524e371ba9bf35744f69061ffbdd4a903740d2164d533d94764f")
