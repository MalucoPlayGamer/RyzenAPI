-- Lua provided by RyzenAPI 
-- Game: ZeroSpace Demo
addappid(1606060)
addappid(1606061, 1, "1aac9f1e3a17524e371ba9bf35744f69061ffbdd4a903740d2164d533d94764f")
