-- Lua provided by RyzenAPI
-- Game: Creeper

-- MAIN APPLICATION
addappid(2521140)
-- Game: addappid(2521140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521141, 1, "978c373699086482be14646150a6b492c3148b78c38338ec2df6e02bd2139e5f")
