-- Lua provided by SkyAPI 
-- Game: Creeper
addappid(2521140)
addappid(2521141, 1, "978c373699086482be14646150a6b492c3148b78c38338ec2df6e02bd2139e5f")
