-- Lua provided by RyzenAPI
-- Game: Refence

-- MAIN APPLICATION
addappid(3427090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427093,0,"9c0a3c590ba31a6b8a6c5969d0884db94617d9cd9044e6380ba591d7f00ddc3d")
