-- Lua provided by RyzenAPI
-- Game: Heart Chain Kitty

-- MAIN APPLICATION
addappid(933210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(933211, 1, "f84728029dfb473259324d6a472dd3bdffb0343c81ac540850c00ac2d1407f9d")

