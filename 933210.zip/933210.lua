-- Lua provided by RyzenAPI
-- Game: Heart Chain Kitty

-- MAIN APPLICATION
addappid(933210)

-- MAIN APP DEPOTS / PACKAGES
addappid(933211, 1, "f84728029dfb473259324d6a472dd3bdffb0343c81ac540850c00ac2d1407f9d")

