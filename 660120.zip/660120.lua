-- Lua provided by RyzenAPI
-- Game: 660120

-- MAIN APPLICATION
addappid(660120)
-- Game: addappid(660120)

-- MAIN APP DEPOTS / PACKAGES
addappid(660121, 1, "826be2f3efbc39448cbc88114e20a798d92f0a8051d16300c72257d7c76a0402")
