-- Lua provided by RyzenAPI
-- Game: AppID 1679010

-- MAIN APPLICATION
addappid(1679010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679011, 1, "c39d07cf3718bd76f33cf0c8e0286ef06ce680c44fd670abff85ecf345822f09")
