-- 4528220's Lua and Manifest Created by Hubcap Manifest
-- MEOWMI
-- Created: August 07, 2026 at 11:10:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4528220) -- MEOWMI
-- MAIN APP DEPOTS
addappid(4528221, 1, "1c00b312f2581b93aa4cd9f0eaa07544d35cedd1071a5a87f0dd8671416bf70f") -- Depot 4528221
setManifestid(4528221, "1836675719492034698", 8676573425)