-- Lua provided by RyzenAPI
-- Game: Theta and Paralldoxs on Worldlines

-- MAIN APPLICATION
addappid(3219580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219581,0,"f31a80dd133a36f57ea1b860951fb73f0d489156a190b81d36a3f5b650fca51d")

