-- Lua provided by RyzenAPI
-- Game: 3263960

-- MAIN APPLICATION
addappid(3263960)
-- Game: addappid(3263960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263961, 1, "d414b7ed134d838209411a3d67b9c15e899f3a90812c9c0bae3e46dbb0534682")
