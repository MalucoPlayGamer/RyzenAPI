-- Lua provided by RyzenAPI
-- Game: Arrogation: Unlight of Day

-- MAIN APPLICATION
addappid(2113530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113531, 1, "749bb5023ebdba682b64ecc9975f0932177d161f03ac5e9d451a0acc300ca8a5")

