-- Lua provided by RyzenAPI
-- Game: Arrogation: Unlight of Day

-- MAIN APPLICATION
addappid(2113530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113531, 1, "749bb5023ebdba682b64ecc9975f0932177d161f03ac5e9d451a0acc300ca8a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
