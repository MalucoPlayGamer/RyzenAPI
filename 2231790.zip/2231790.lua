-- Lua provided by RyzenAPI
-- Game: Pan'orama: Prologue

-- MAIN APPLICATION
addappid(2231790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231791, 1, "c356e791d8040147bef92f9745749668af1c3f06c49bffbe297b3fb039f37fd2")
