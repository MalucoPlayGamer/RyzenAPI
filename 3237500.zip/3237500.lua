-- Lua provided by RyzenAPI 
-- Game: The Alters: Original Soundtrack
addappid(3237500)
addappid(3237501, 1, "99dc484f856a609a3f1076fa075ce5c0cac9781f7ac4adca6c144fafa7b7c0b3")
addappid(3237502, 1, "568a73eae1d53cdd3cb99cf12db89bd8db144b9fbbfe9404dc80f17a7bd2f755")
