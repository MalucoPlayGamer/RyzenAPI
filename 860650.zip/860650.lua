-- Lua provided by RyzenAPI
-- Game: Drizzlepath: Deja Vu

-- MAIN APPLICATION
addappid(860650)
-- Game: addappid(860650)

-- MAIN APP DEPOTS / PACKAGES
addappid(860651, 1, "36e66035eb8c9711098bb0f8e11bb42d10f2e64a825d8adece8f4d7607ad0788")
