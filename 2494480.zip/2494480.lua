-- Lua provided by RyzenAPI
-- Game: Truth of Beauty Witch -Marine's treasure ship-

-- MAIN APPLICATION
addappid(2494480)
-- Game: addappid(2494480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494482,0,"17db1bf4cb214e1a87aef50b6923622d312165f15a40ad7be803f482d82410c4")
addappid(2494483,0,"f02da7ca3a87b5dbe07bc74ad8231d60942d65134e7960471d3b398442d69205")
