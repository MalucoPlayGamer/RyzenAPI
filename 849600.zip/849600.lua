-- Lua provided by RyzenAPI
-- Game: Sandbox Showdown

-- MAIN APPLICATION
addappid(849600)

-- MAIN APP DEPOTS / PACKAGES
addappid(849601, 1, "6fed6eec808b6ad87638b0384d8597ac86969ac369565ee3056269f62ad09142")
