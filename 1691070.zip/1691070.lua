-- Lua provided by RyzenAPI
-- Game: Lost Ruins Demo

-- MAIN APPLICATION
addappid(1691070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691071, 1, "4bd649fc99a175a0deb02b54c0f6c0ec72c0c5ebc37f48a5796007ad48186446")

