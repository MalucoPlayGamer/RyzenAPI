-- Lua provided by RyzenAPI
-- Game: addappid(342650)

-- MAIN APPLICATION
addappid(342650)

-- MAIN APP DEPOTS / PACKAGES
addappid(342651, 1, "863b15c02186e6237af81825060aa27393ee0f2fc812ad86a592a91a1c7dc618")
