-- Lua provided by RyzenAPI
-- Game: 416130

-- MAIN APPLICATION
addappid(416130)
-- Game: addappid(416130)

-- MAIN APP DEPOTS / PACKAGES
addappid(416131, 1, "998902a2f0a982b7e340ca587b2ae16f45e41f5007c01bd4cd163c312f1d9118")
