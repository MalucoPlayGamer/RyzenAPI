-- Lua provided by SkyAPI 
-- Game: AppID 416130
addappid(416130)
addappid(416131, 1, "998902a2f0a982b7e340ca587b2ae16f45e41f5007c01bd4cd163c312f1d9118")
