-- Lua provided by RyzenAPI
-- Game: setManifestid(1721872,"1252247492715061082")

-- MAIN APPLICATION
addappid(1721870)
-- Game: addappid(1721870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721872,0,"47ac08ce3b90626259b2d6e1dd2a9a0b0f77dbb1274bedb5ce7ea75ec160d091")
