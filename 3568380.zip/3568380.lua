-- Lua provided by RyzenAPI
-- Game: The Deep Creep

-- MAIN APPLICATION
addappid(3568380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568381, 1, "1ff9afedd05580def6d3126fe3854b8d8c747d11dfbf34312b87751b27a9ed92")
