-- Lua provided by RyzenAPI
-- Game: 492290

-- MAIN APPLICATION
addappid(492290)
-- Game: addappid(492290)

-- MAIN APP DEPOTS / PACKAGES
addappid(492291, 1, "1c0edde0ce428b5723e1110c8cfdd21a2ae0083a4bf3ef1086488e58137263d2")
