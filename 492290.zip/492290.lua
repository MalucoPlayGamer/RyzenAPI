-- Lua provided by RyzenAPI
-- Game: Has-Been Heroes

-- MAIN APPLICATION
addappid(492290)

-- MAIN APP DEPOTS / PACKAGES
addappid(492291, 1, "1c0edde0ce428b5723e1110c8cfdd21a2ae0083a4bf3ef1086488e58137263d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
