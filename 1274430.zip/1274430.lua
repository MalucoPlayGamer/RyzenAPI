-- Lua provided by RyzenAPI
-- Game: Human Origin

-- MAIN APPLICATION
addappid(1274430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274431, 1, "5c99da128710bec30e379025b17f316a5cff584fe71db41fd4132226716945fd")

