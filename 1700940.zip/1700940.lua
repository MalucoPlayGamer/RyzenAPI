-- Lua provided by RyzenAPI
-- Game: Anime Zodiac

-- MAIN APPLICATION
addappid(1700940)
addappid(1709200)
-- Game: addappid(1700940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700941, 1, "73cb6ac346b83d2b2bfda33f67ac6b222086615c60da94eee73dacc54d3cce46")
