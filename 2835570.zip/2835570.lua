addappid(2835570)
addappid(2835572, 1, "d62599196078743d30d665ddd351d433f153e6e3ed12cdc8a4021ee8b1fc8b30")
-- setManifestid(2835572, "7472777116297885824", 0)
addappid(2835573, 1, "9c48f34a0e831c56623c49c66403647f8c08682d26ee6bee1d56c470bb97f6cb")
-- setManifestid(2835573, "9007644155059772192", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]