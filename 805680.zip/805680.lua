-- Lua provided by RyzenAPI
-- Game: Star Shield Down

-- MAIN APPLICATION
addappid(805680)

-- MAIN APP DEPOTS / PACKAGES
addappid(805681, 1, "e3f8ddaeb99976d82d22f0f6c3af55b3eb4d86a9191d8389843ecfa7756c2a7f")

