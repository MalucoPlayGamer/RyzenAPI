-- Lua provided by RyzenAPI
-- Game: Anonymous ME

-- MAIN APPLICATION
addappid(658630)
addappid(2072530)

-- MAIN APP DEPOTS / PACKAGES
addappid(658631, 1, "54995911fc773b547acff8721c2bf41ada1d451138cbf81d44f5aea7a987ba74")

