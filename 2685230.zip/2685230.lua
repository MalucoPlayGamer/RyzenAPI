-- Lua provided by RyzenAPI
-- Game: AppID 2685230

-- MAIN APPLICATION
addappid(2685230)
-- Game: addappid(2685230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685231, 1, "d71605ec7e4cfab0063ceede96c35461bb41469034ce0b550dc269aace0ad3af")
