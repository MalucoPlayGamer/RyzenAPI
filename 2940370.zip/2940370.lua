-- Lua provided by RyzenAPI
-- Game: Game: Any way out

-- MAIN APPLICATION
addappid(2940370)
-- Game: addappid(2940370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940371, 1, "b59dac6feede178ca7ec1e535cb6862ca42468db76c558b9c03746a49d12245f")
