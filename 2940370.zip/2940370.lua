-- Lua provided by RyzenAPI
-- Game: Any way out

-- MAIN APPLICATION
addappid(2940370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2940371, 1, "b59dac6feede178ca7ec1e535cb6862ca42468db76c558b9c03746a49d12245f")

