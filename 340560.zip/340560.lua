-- Lua provided by RyzenAPI
-- Game: AppID 340560

-- MAIN APPLICATION
addappid(340560)
-- Game: addappid(340560)

-- MAIN APP DEPOTS / PACKAGES
addappid(340561, 1, "866f131942b558eccadb570661eac429518453d5848f1c3bcfea37268ee48c90")
