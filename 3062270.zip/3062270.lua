-- Lua provided by RyzenAPI
-- Game: Empire of the Ants - Demo

-- MAIN APPLICATION
addappid(3062270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062271, 1, "51788fffbf5b0c7db2ab47c0f9a2102a54766f15cc6dd15fad0fe66d257feafb")

