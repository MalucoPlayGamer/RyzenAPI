-- Lua provided by SkyAPI 
-- Game: Geometry Raid Demo
addappid(2797200)
addappid(2797201, 1, "77fd850561be847203393aababec040fc30000a28ddaa32d0d063c1785d8a4ec")
