-- Lua provided by RyzenAPI
-- Game: Geometry Raid Demo

-- MAIN APPLICATION
addappid(2797200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797201, 1, "77fd850561be847203393aababec040fc30000a28ddaa32d0d063c1785d8a4ec")

