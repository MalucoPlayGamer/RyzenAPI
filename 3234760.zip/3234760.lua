-- Lua provided by RyzenAPI
-- Game: Orange Roulette

-- MAIN APPLICATION
addappid(3234760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234761, 1, "29475705b2fe8497831bc768dcc95f0cf7007d651b9fbd3137d00a0ed8126259")
