-- Lua provided by RyzenAPI
-- Game: addappid(514750)

-- MAIN APPLICATION
addappid(514750)

-- MAIN APP DEPOTS / PACKAGES
addappid(514751, 1, "098217ec6d25e8e4f6123d3cb6cfa8c65e4056aa5aecdbe50861235beaf24b9c")
