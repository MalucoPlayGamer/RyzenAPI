-- Lua provided by RyzenAPI
-- Game: Love Chronicles: Salvation Collector's Edition

-- MAIN APPLICATION
addappid(805030)

-- MAIN APP DEPOTS / PACKAGES
addappid(805031,0,"85d4141f1888a14f6999112724721f0cd2fcd24c2331d19e507144d138e4019d")

