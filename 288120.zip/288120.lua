-- Lua provided by RyzenAPI
-- Game: Dungeonmans

-- MAIN APPLICATION
addappid(288120)
addappid(636410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(288121, 1, "005167c8351e3f0fd276ff01b7e1402a674fd031152a911b75ea8a2123d2fd4b")
addappid(306280, 0, "92b508561cd6c0130758b38b4b6a627c4bff2f63b65b716f258c6f37202b4b74")

