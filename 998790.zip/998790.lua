-- Lua provided by RyzenAPI
-- Game: Piczle Lines DX+α

-- MAIN APPLICATION
addappid(998790)

-- MAIN APP DEPOTS / PACKAGES
addappid(998791, 1, "544a5f57674904995cc065229c3b6f39199998648d8e1d9468c190b8e0a83d25")
addappid(998793, 1, "01fd07f725330cfc1b4a753fc5ff2b134ec51f2430385197cc674d5655233468")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
