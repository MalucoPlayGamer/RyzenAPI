-- Lua provided by RyzenAPI 
-- Game: Piczle Lines DX+α
addappid(998790)
addappid(998791, 1, "544a5f57674904995cc065229c3b6f39199998648d8e1d9468c190b8e0a83d25")
addappid(998793, 1, "01fd07f725330cfc1b4a753fc5ff2b134ec51f2430385197cc674d5655233468")
