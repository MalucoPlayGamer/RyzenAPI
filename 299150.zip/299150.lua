-- Lua provided by RyzenAPI
-- Game: 299150

-- MAIN APPLICATION
addappid(299150)
-- Game: addappid(299150)

-- MAIN APP DEPOTS / PACKAGES
addappid(299151, 1, "0f13f50d00189a1ee58abad838f8ec01bd4e244de72684d0794803321ae17fe2")
