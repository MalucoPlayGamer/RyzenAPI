-- Lua provided by RyzenAPI
-- Game: Me and my eldritch parasite

-- MAIN APPLICATION
addappid(1789670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789672,0,"9fd7564179f3cf08df3b2b38bef0f2a2265a61e2fc4d02f1b1a0b1afd3961a00")
