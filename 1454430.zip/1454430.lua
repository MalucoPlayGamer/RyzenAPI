-- Lua provided by RyzenAPI
-- Game: Arc Apellago

-- MAIN APPLICATION
addappid(1454430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454431, 1, "c363bce3fb8c2693af57f3428fa20cee274c2c5f0a57eb9a71efbc273301db55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
