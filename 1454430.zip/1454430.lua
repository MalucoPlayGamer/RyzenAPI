-- Lua provided by RyzenAPI
-- Game: Game: Arc Apellago

-- MAIN APPLICATION
addappid(1454430)
-- Game: addappid(1454430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454431, 1, "c363bce3fb8c2693af57f3428fa20cee274c2c5f0a57eb9a71efbc273301db55")
