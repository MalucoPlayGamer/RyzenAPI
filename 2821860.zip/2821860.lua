-- Lua provided by RyzenAPI
-- Game: 2821860

-- MAIN APPLICATION
addappid(2821860)
-- Game: addappid(2821860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821861, 1, "adb701dcde88ad53b64fa8f4bc06b6b16b449d3221924839ad6555626f6b272d")
