-- Lua provided by RyzenAPI
-- Game: Game: AppID 363600

-- MAIN APPLICATION
addappid(363600)
-- Game: addappid(363600)

-- MAIN APP DEPOTS / PACKAGES
addappid(363601, 1, "ddc01b4bfd2e71f3b9d42917e02ab2b873dc5fe1b9d50361b1746f4fab692b52")
addappid(363602, 1, "a3a0f6cecdbf665739602d5135d79272717442cd7b7cc3d7f9fbeb97b6898b33")
addappid(363603, 1, "bc4ddcc3c0e569145b7c3dd079990f38b754b6617c2c48f54bd963c1b2801b53")
addappid(391860, 0, "1f1bb61de7cff153d8bedab0a72211c5d2e105c05d8f34173a467e7825caa51c")
