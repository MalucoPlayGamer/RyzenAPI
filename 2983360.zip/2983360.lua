-- Lua provided by RyzenAPI
-- Game: 2983360

-- MAIN APPLICATION
addappid(2983360)
-- Game: addappid(2983360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983361, 1, "bcbc98d4b6d7642e7f9e426adcea4da9bb963a0367f7d19b4ea581edb9edbd99")
