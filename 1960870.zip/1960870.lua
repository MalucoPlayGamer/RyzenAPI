-- Lua provided by RyzenAPI
-- Game: Hypnosis Reveries

-- MAIN APPLICATION
addappid(1960870)
-- Game: addappid(1960870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960871, 1, "c558647468292b6f7d2d29f8893048c1af0f5dec4cdc0e4be09e1430ccd4489c")
