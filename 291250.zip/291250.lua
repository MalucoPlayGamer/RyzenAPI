-- Lua provided by RyzenAPI
-- Game: Jumpdrive

-- MAIN APPLICATION
addappid(291250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(291251, 1, "e0ad4d11bf949af8a1a77b630b5eac6d61917f3d7c8a15b243669f70f30fdfe2")
addappid(291252, 1, "5a0ccb712833981f1188ced8cc989cf5dbd1b0c55930b2990aae06543873648d")

