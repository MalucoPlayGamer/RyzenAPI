-- Lua provided by RyzenAPI
-- Game: Beneath Oresa

-- MAIN APPLICATION
addappid(1803400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803401, 1, "4a69ecb0c01577e952dbbd9ad5473326126136562ba368a5561c29c1ffbabb0e")
