-- Lua provided by RyzenAPI
-- Game: AppID 411970

-- MAIN APPLICATION
addappid(411970)
addappid(763590)
addappid(2467140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411971, 1, "b157f4cf8f6f978cca7d0f9e57a4970f8a7dc03273aa0fcead7cf6bab4dcf6f2")
addappid(411972, 1, "ae277e0b84046085547cf81784a51c456a28ce2530c40b71298b7f99d5dbd024")

