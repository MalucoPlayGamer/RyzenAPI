-- Lua provided by RyzenAPI
-- Game: 411970

-- MAIN APPLICATION
addappid(411970)
addappid(763590)
addappid(2467140)
-- Game: addappid(411970)

-- MAIN APP DEPOTS / PACKAGES
addappid(411971, 1, "b157f4cf8f6f978cca7d0f9e57a4970f8a7dc03273aa0fcead7cf6bab4dcf6f2")
addappid(411972, 1, "ae277e0b84046085547cf81784a51c456a28ce2530c40b71298b7f99d5dbd024")
