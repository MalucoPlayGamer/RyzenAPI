-- 1672810's Lua and Manifest Created by Hubcap Manifest
-- MIO: Memories in Orbit
-- Created: March 12, 2026 at 09:38:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1672810) -- MIO: Memories in Orbit
-- MAIN APP DEPOTS
addappid(1672811, 1, "cb73bead2ca7cc72a2ad3fb210203ba2e0732db40cf3700d95b3fc62b825e490") -- Depot 1672811
setManifestid(1672811, "4711570043897766739", 3775770142)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)