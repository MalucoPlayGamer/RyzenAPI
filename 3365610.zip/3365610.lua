-- Lua provided by RyzenAPI
-- Game: addappid(3365610)

-- MAIN APPLICATION
addappid(3365610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365611, 1, "c1579fd51573821725bb5b2a8b018b7a4cd5a349154a0b04e43cd0c0fc9b2158")
