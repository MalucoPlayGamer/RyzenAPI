-- Lua provided by RyzenAPI
-- Game: Horns of Fear

-- MAIN APPLICATION
addappid(720940)

-- MAIN APP DEPOTS / PACKAGES
addappid(720941,0,"39b6e0d476ca91fed934773ed1d5416b37e7ccb11dd46783255b71d7d875ba26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(877100)
