-- Lua provided by RyzenAPI
-- Game: Horns of Fear

-- MAIN APPLICATION
addappid(720940)

-- MAIN APP DEPOTS / PACKAGES
addappid(720941,0,"39b6e0d476ca91fed934773ed1d5416b37e7ccb11dd46783255b71d7d875ba26")

