-- Lua provided by RyzenAPI
-- Game: Game: Swordcery: Prologue

-- MAIN APPLICATION
addappid(1764050)
-- Game: addappid(1764050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764051, 1, "70241c3c6e62d39006a67b0c0e05594c34131d464119affd8c0b98acc2335e4b")
