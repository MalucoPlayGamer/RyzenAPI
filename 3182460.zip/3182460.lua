-- Lua provided by RyzenAPI
-- Game: 3182460

-- MAIN APPLICATION
addappid(3182460)
-- Game: addappid(3182460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182461, 1, "35cf7963b4285e73f40d29869a607744cf2c0430cdf8cc19a2addc9db94ce4b0")
