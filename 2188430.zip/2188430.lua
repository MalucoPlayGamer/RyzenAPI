-- Lua provided by RyzenAPI 
-- Game: Equinox
addappid(2188430)
addappid(2188431, 1, "8932cec7f5c7448d0c9919163b9531cf03c4e53c922fc158815e56f78a7249dc")
