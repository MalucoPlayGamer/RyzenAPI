-- Lua provided by RyzenAPI
-- Game: 3021850

-- MAIN APPLICATION
addappid(3021850)
-- Game: addappid(3021850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021851, 1, "4381ec1bbcf41ccb88191c420b9459300fa48fb86fcc0ce8f97828e336fd3d9e")
