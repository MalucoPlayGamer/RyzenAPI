-- Lua provided by RyzenAPI 
-- Game: Monster Meals
addappid(3021850)
addappid(3021851, 1, "4381ec1bbcf41ccb88191c420b9459300fa48fb86fcc0ce8f97828e336fd3d9e")
