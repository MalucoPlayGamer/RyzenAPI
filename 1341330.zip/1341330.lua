-- Lua provided by RyzenAPI
-- Game: addappid(1341330)

-- MAIN APPLICATION
addappid(1341330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341331, 1, "52231b22a5d019e2cfa56cdee335d13ebfb04c05552d2908374d1629e681228a")
