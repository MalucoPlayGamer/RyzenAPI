-- Lua provided by RyzenAPI
-- Game: Battlecruisers

-- MAIN APPLICATION
addappid(955870)

-- MAIN APP DEPOTS / PACKAGES
addappid(955872,0,"1d8b89134cbf25c6b400c05737c3c8219adec37dc1bc237b89c591821b758640")
