-- Lua provided by RyzenAPI
-- Game: addappid(2302870)

-- MAIN APPLICATION
addappid(2302870)
addappid(2551770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302871, 1, "fe9d97ef43a0a51b8236e0a4ced2ce3e05f8a76016511e418187c4cdc54bfc77")
