-- Lua provided by RyzenAPI
-- Game: XCOM®: Chimera Squad

-- MAIN APPLICATION
addappid(882100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(882101, 1, "24d07f7528211e739717056f1065164bf9c32ee582acf8e93e66080e48f804f6")
addappid(882102, 1, "11806b8afa0cfd5ae8523f4618495b636242efddd01f219600c6d0be0bcf3c2f")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")

