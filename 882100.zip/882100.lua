-- Lua provided by RyzenAPI 
-- Game: XCOM®: Chimera Squad
addappid(882100)
addappid(882101, 1, "24d07f7528211e739717056f1065164bf9c32ee582acf8e93e66080e48f804f6")
addappid(882102, 1, "11806b8afa0cfd5ae8523f4618495b636242efddd01f219600c6d0be0bcf3c2f")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
