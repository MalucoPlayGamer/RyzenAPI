-- Lua provided by RyzenAPI
-- Game: addappid(786670)

-- MAIN APPLICATION
addappid(786670)
addappid(787770)

-- MAIN APP DEPOTS / PACKAGES
addappid(786671, 1, "2524f8e42c8f5f79f5ec11a25f61f108f394f47b8251e4d8ce2cb8df18005183")
