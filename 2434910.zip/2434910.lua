-- Lua provided by RyzenAPI
-- Game: Antipsychotic

-- MAIN APPLICATION
addappid(2434910)
-- Game: addappid(2434910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434911, 1, "5069fffcdcfec0c66e4e9579bb4bcc118f7f779f2d22efcbabdf010b06b19907")
