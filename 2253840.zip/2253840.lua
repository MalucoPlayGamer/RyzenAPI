-- Lua provided by RyzenAPI
-- Game: 2253840

-- MAIN APPLICATION
addappid(2253840)
-- Game: addappid(2253840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253842,0,"55875a536cc5beb3d7e3438d67b9cc5f6b3099dfe240d729c4b0ea75bc7e6085")
