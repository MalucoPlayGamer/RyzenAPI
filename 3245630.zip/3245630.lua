-- Lua provided by RyzenAPI
-- Game: Vending Machine Business Simulator Demo

-- MAIN APPLICATION
addappid(3245630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245631, 1, "e94fe6724ed672562d175954eee8dfbc82b8fffaba49354a2a40db9faaa42e67")
