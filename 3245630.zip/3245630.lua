-- Lua provided by SkyAPI 
-- Game: AppID 3245630
addappid(3245630)
addappid(3245631, 1, "e94fe6724ed672562d175954eee8dfbc82b8fffaba49354a2a40db9faaa42e67")
