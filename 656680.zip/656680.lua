-- Lua provided by RyzenAPI
-- Game: Bomb Defense

-- MAIN APPLICATION
addappid(656680)

-- MAIN APP DEPOTS / PACKAGES
addappid(656681, 1, "ed53f7b77aef872ed73c5a9181c45b6770baf5c715127aa1fa16bf455378b4c0")
addappid(656682, 1, "42b2afe418453899d0b77119aec658d0bfcaaa257eaebe99085f5c722922c5d2")
addappid(656683, 1, "e938104fba19a8d5d87188b9fc508948dc4612cb232ad562dc4920c852645dcb")
