-- Lua provided by RyzenAPI
-- Game: BLOCKADE War Stories

-- MAIN APPLICATION
addappid(1051890)
-- Game: addappid(1051890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051891, 1, "caad634d73d218c289a7bac3f4e32262eea8c160a5a91f813eff2fc5e2288bf6")
