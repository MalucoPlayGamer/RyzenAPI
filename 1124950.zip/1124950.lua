-- Lua provided by RyzenAPI
-- Game: Hyperplex 3D

-- MAIN APPLICATION
addappid(1124950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124951, 1, "119a3bb3002b1b826159b5a6012ebbd3606ee1cefb36289d5a474dd3c778c922")
