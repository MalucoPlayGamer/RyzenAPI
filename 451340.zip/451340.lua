-- Lua provided by RyzenAPI
-- Game: Gold Mining Simulator

-- MAIN APPLICATION
addappid(451340)

-- MAIN APP DEPOTS / PACKAGES
addappid(451341, 1, "b066f0d640f9c9fbf1bc5f75f7299e5f826fa03a7c67c1f83a2779884af57c16")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(715070)
addappid(773500)
addappid(2900730)
addappid(3228240)
addappid(4056800)
