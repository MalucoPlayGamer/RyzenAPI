-- Lua provided by RyzenAPI
-- Game: Beardy the Digger

-- MAIN APPLICATION
addappid(1144630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144631, 1, "956021e452dfadf0d3b20dc6e3017cdb031dfe41ad5c94f78e4e031a64557156")
