-- Lua provided by RyzenAPI
-- Game: 292400

-- MAIN APPLICATION
addappid(292400)
addappid(301710)
addappid(301720)
-- Game: addappid(292400)

-- MAIN APP DEPOTS / PACKAGES
addappid(292401, 1, "6067a53343d14274359113bbc2cfd436e56efb47bf7822f1115fd4fcae44ed49")
addappid(292402, 1, "85a62ca4a5d361857fb54a6e491a411299ecbc9a89629390c0144b7b6bdd6ca6")
addappid(292403, 1, "859073a034c6a7110bb9eaec24838df6d7ffbb02fecb5c0259cda314f8f09ae6")
