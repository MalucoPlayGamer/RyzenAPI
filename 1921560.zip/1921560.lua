-- Lua provided by RyzenAPI
-- Game: Flowers -Le volume sur hiver-

-- MAIN APPLICATION
addappid(1921560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1921561, 1, "cc622d23529093fb72d9367762808f7ce9b04bc4227dfea38e274ecb8ebe26f9")
addappid(1921562, 1, "38e3844f075ba521ca1e734ecf061cc9307575dd581723a20296d8770eef80d8")

