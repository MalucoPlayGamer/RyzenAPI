-- Lua provided by RyzenAPI
-- Game: addappid(454320)

-- MAIN APPLICATION
addappid(454320)

-- MAIN APP DEPOTS / PACKAGES
addappid(454321, 1, "20ac82ae1e54807d8b85de0b1863c84685f21a2c478a6683aa8c6bdccff7f1a6")
