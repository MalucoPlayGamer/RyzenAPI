-- Lua provided by RyzenAPI 
-- Game: Hentai Neko
addappid(2180710)
addappid(2180711, 1, "e4162fba380ed5a1944471eb1169a9f678002b7a0d1f4ad152a7369ce710ad9f")
