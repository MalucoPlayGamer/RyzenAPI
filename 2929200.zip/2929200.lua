-- Lua provided by RyzenAPI
-- Game: 2929200

-- MAIN APPLICATION
addappid(2929200)
-- Game: addappid(2929200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929201, 1, "7a2a2524d508f10df0df821da904e0769add9cbdf805dbd074377f4be30b5286")
