-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3156260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156260,0,"02a17b607bfa00ef28725fd57189d964486d9a16385749216b59701a949b854e")

