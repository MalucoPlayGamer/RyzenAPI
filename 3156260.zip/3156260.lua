-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3156260)
addappid(3156260,0,"02a17b607bfa00ef28725fd57189d964486d9a16385749216b59701a949b854e")
-- setManifestid(3156260,"8763201521609926741")