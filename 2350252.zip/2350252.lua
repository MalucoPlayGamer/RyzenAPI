-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2350252)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350252,0,"7788c22c27341fb26e4185b41bafc6fd8f6aa290c2e3346c613910576142819c")

