-- Lua provided by RyzenAPI
-- Game: AppID 257770

-- MAIN APPLICATION
addappid(257770)

-- MAIN APP DEPOTS / PACKAGES
addappid(257771, 1, "f6850bfdc5ae679c4ca366b937cc56fde5613ab6a179ad6fa680f373397718f7")
addappid(257772, 1, "96c26983cfabe16ecf00d7221c7af2b5f0486e6814308f9a8fb948ce20f9e155")
addappid(257773, 1, "fc3d2ffbc108ea56fbcf436e17439afa2857338125b61fc1b52bea31e96eafb0")
addappid(257774, 1, "e4bffa2928793354c740f113fe2212d2d437ef927972de964bb71e5f462a67a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
