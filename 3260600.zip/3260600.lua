-- Lua provided by SkyAPI 
-- Game: AppID 3260600
addappid(3260600)
addappid(3260601, 1, "05ea186b571f316f27d281a38c39464886933552d7d69742640c7c2ee45706f1")
