-- Lua provided by RyzenAPI
-- Game: Game: DAEMON MASQUERADE Demo

-- MAIN APPLICATION
addappid(2277120)
-- Game: addappid(2277120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277121, 1, "ed21a1ed425ac7517a18c55fd7ccb7af2bd70daf53c02177c62636ea4d670d6d")
