-- Lua provided by RyzenAPI
-- Game: 3683040

-- MAIN APPLICATION
addappid(3683040)
-- Game: addappid(3683040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3683041, 1, "95454f081b771a7212f36b2c160adde0c9cfaef3387f7310a8eb0cd428c1fa1e")
