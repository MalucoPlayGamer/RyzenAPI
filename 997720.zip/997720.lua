-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Hiragana

-- MAIN APPLICATION
addappid(997720)

-- MAIN APP DEPOTS / PACKAGES
addappid(997721, 1, "240fb21a1f91e2ff7444ac8a72589ee9c37ce64073ec7c8f12f196743b532ced")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
