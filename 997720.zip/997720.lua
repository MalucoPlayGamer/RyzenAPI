-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Hiragana

-- MAIN APPLICATION
addappid(997720)
-- Game: addappid(997720)

-- MAIN APP DEPOTS / PACKAGES
addappid(997721, 1, "240fb21a1f91e2ff7444ac8a72589ee9c37ce64073ec7c8f12f196743b532ced")
