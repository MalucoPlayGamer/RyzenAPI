-- Lua provided by RyzenAPI
-- Game: Forest Golf Planner

-- MAIN APPLICATION
addappid(2119670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119671, 1, "d87b7b7b21ab508e6195d8eb6214f307da2afe4da3d360ab44d959bfb2720698")

