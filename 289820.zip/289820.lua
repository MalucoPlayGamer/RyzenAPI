-- Lua provided by RyzenAPI
-- Game: AppID 289820

-- MAIN APPLICATION
addappid(289820)

-- MAIN APP DEPOTS / PACKAGES
addappid(289821, 1, "dfe270ebb4a83684a10e99c3244ec2ebe8bc77cdf0e0c4ad32d351dc98f1f8bf")
addappid(289822, 1, "0953acb62cfafa3433cf231f4c60955cd7e680f101bb7060f2fd873b86feb0bf")
