-- Lua provided by RyzenAPI
-- Game: Game: Need For Scream

-- MAIN APPLICATION
addappid(3390000)
-- Game: addappid(3390000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3390001, 1, "5111e7dff46300ca2e0d27d1fb2b49d4ec353970e6796b0dc8628a857a24d7e3")
