-- Lua provided by RyzenAPI 
-- Game: Need For Scream
addappid(3390000)
addappid(3390001, 1, "5111e7dff46300ca2e0d27d1fb2b49d4ec353970e6796b0dc8628a857a24d7e3")
