-- Lua provided by RyzenAPI
-- Game: Exit From

-- MAIN APPLICATION
addappid(1092140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092142,0,"f8169647d404af83923eeb0cf3b0003d5ef741448eac96dbe43578ac00f58bef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
