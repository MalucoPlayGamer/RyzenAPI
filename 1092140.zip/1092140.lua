-- Lua provided by RyzenAPI
-- Game: 1092140

-- MAIN APPLICATION
addappid(1092140)
-- Game: addappid(1092140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092142,0,"f8169647d404af83923eeb0cf3b0003d5ef741448eac96dbe43578ac00f58bef")
