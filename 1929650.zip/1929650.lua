-- Lua provided by RyzenAPI
-- Game: Island Assault

-- MAIN APPLICATION
addappid(1929650)
addappid(2460650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1929651, 1, "e367cdf428548ee06853db959dcd74ce3451a33d7e6f202377c3f29369529a28")

