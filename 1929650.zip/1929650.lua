-- Lua provided by RyzenAPI
-- Game: Game: AppID 1929650

-- MAIN APPLICATION
addappid(1929650)
-- Game: addappid(1929650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929651, 1, "e367cdf428548ee06853db959dcd74ce3451a33d7e6f202377c3f29369529a28")
