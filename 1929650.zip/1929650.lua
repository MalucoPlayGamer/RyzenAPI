-- Lua provided by SkyAPI 
-- Game: AppID 1929650
addappid(1929650)
addappid(1929651, 1, "e367cdf428548ee06853db959dcd74ce3451a33d7e6f202377c3f29369529a28")
