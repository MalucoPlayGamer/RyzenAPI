-- Lua provided by RyzenAPI
-- Game: Theatre of War 2: Africa 1943

-- MAIN APPLICATION
addappid(46340)
-- Game: addappid(46340)

-- MAIN APP DEPOTS / PACKAGES
addappid(46341, 1, "789652d5a7e91647eed2592e17f0c10f66b405b47c0a4e2f3d88c72118f5ede7")
addappid(46342, 0, "f48f26ff41c8eaacf73465547a30192a32602f15541121ea594688cc823904a8")
addappid(46343, 1, "4942c71c480cea56199b842fa446200f7d15fb163afcb4ea0d0988aa952284dd")
addappid(46344, 1, "325b9cc04f49bc335b4da817cf090925bfc0b61cee2f7ff1a640a60dfdb62370")
