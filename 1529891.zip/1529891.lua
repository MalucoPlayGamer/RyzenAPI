-- Lua provided by RyzenAPI
-- Game: 1529891

-- MAIN APPLICATION
addappid(1529891)
-- Game: addappid(1529891)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529891,0,"8e0e752bd706bd2826080f934ec84269f8ace56c9505beeb081ba7339370a8ce")
