-- Lua provided by RyzenAPI 
-- Game: Digseum
addappid(3361470)
addappid(3361471, 1, "3218add7ef414cf4584104b1c1232f01f465b37d96ff596927432d1b5e154459")
