-- Lua provided by RyzenAPI
-- Game: Love Rhythm

-- MAIN APPLICATION
addappid(1185520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185521, 1, "009d40c71a1854e44104cdae6e526f0b13c06541a5862755b17fc065fefba3c5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1195130)
addappid(1359050)
