-- Lua provided by SkyAPI 
-- Game: Rebel Transmute
addappid(1191660)
addappid(1191661, 1, "8adb1a87f4d3a3696f781aa7d88f9bfdc533aa5e7aaf6355d3a160ddce5f3fe3")
