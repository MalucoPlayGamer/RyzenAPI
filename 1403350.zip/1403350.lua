-- Lua provided by RyzenAPI
-- Game: Supfly Delivery Simulator

-- MAIN APPLICATION
addappid(1403350)
-- Game: addappid(1403350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403351, 1, "a1e6dd89fb247871adfaa1b333abcdc256d5087c37542d406e0602df2faaee19")
