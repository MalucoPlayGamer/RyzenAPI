-- Lua provided by RyzenAPI
-- Game: AppID 1362540

-- MAIN APPLICATION
addappid(1362540)
-- Game: addappid(1362540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362541, 1, "8911686f8044c0d62bcfa42eedab7fa7ffb64a4dbb532ee5870a31ba7b2c431f")
