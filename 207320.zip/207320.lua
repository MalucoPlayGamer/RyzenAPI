-- Lua provided by RyzenAPI
-- Game: Ys: The Oath in Felghana

-- MAIN APPLICATION
addappid(207320)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(207321, 1, "debd8d5675f7e8478017cd8809ea239b5257f2b2b04ddbe4c732910bd6d7f096")

