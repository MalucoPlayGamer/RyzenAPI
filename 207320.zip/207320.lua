-- Lua provided by RyzenAPI
-- Game: Ys: The Oath in Felghana

-- MAIN APPLICATION
addappid(207320)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(207321, 1, "debd8d5675f7e8478017cd8809ea239b5257f2b2b04ddbe4c732910bd6d7f096")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

