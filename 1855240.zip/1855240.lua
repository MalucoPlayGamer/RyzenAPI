-- Lua provided by RyzenAPI 
-- Game: PRINCESS
addappid(1855240)
addappid(1855241, 1, "04e930e0697951bed011155039242b003324994f565b9002c5bdd8412225df90")
