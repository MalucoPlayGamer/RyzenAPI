-- Lua provided by RyzenAPI
-- Game: addappid(2743970)

-- MAIN APPLICATION
addappid(2743970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743971, 1, "17464577b6c8ca41a141065918ebc6e8bb76b2c176c7b447dd7f1f8f75dafaf7")
