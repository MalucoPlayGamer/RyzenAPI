-- Lua provided by RyzenAPI 
-- Game: AppID 1196630
addappid(1196630)
addappid(1196631, 1, "7813958b69234bd66128b80deb61a221ca4fadf86c5f57f1837cc9123596cb63")
addappid(1196632, 1, "89cc0edcc6daaab734b344811bc95c811e17ed1289e8dcc93a21a08d3d53cbfe")
addappid(1196633, 1, "5a7eb3fe0d9c2e288a03c97c903acb8dd2eb1268971dbb5447ee191e5d9b4df7")
