-- Lua provided by RyzenAPI
-- Game: Game: Comanche 4

-- MAIN APPLICATION
addappid(32750)
-- Game: addappid(32750)

-- MAIN APP DEPOTS / PACKAGES
addappid(32751, 1, "c1caa70d3925608e56cb72e954da6f3905cbe4e5f1235e7912bbaf5297ec3ecc")
