-- Lua provided by RyzenAPI
-- Game: Cemetery Mary

-- MAIN APPLICATION
addappid(1801230)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1847040)
