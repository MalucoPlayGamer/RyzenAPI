-- Lua provided by RyzenAPI
-- Game: Cemetery Mary

-- MAIN APPLICATION
addappid(1801230)
addappid(1847040)

