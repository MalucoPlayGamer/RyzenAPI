-- Lua provided by RyzenAPI
-- Game: AppID 239250

-- MAIN APPLICATION
addappid(239250)

-- MAIN APP DEPOTS / PACKAGES
addappid(239251, 1, "b635cb1d05c79eddc5134d263a5e1f5c7c1313164fcbd0719f9180b928e22fca")
addappid(239252, 1, "b612e999d88d9915da468c742090b3a97ecfcbc4ef45861e3c70ccab4e8a584e")
addappid(273150, 0, "5561c0bd3e7c780925757243f3245ae7fc8917ae0962e20442150155c2dc85d2")
addappid(273151, 0, "aec024688ab7fa7a993085c346cbfb0364da705ffb16cc18c832e6862ea3136a")
addappid(273152, 0, "553beea2707ee1c3c7dad6158290fa67187c7df8c1623bbf60338b904f65a5d7")
addappid(273153, 0, "aea29d83dddce9728db9b9e4414e50022099f63c1a7557afd29a4583742adeed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
