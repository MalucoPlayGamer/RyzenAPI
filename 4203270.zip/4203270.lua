-- 4203270's Lua and Manifest Created by Hubcap Manifest
-- Moon Crashers
-- Created: July 27, 2026 at 15:31:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4203270) -- Moon Crashers
-- MAIN APP DEPOTS
addappid(4203271, 1, "0d8a5ef943a9e7cfa54e1c1ce8dd2f6c6dcdb8852d6c899c144a61123f87c991") -- Depot 4203271
setManifestid(4203271, "4755575205598359817", 1377415268)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)