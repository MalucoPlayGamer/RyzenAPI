-- Lua provided by RyzenAPI 
-- Game: AppID 1834500
addappid(1834500)
addappid(1834501, 1, "9c395dbfd2c7a1d8e795e8bc0f7619a0184b5eaaee421a2e1579a8cf7b7dddf6")
