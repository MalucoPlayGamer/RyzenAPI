-- Lua provided by RyzenAPI
-- Game: 做了个魔塔

-- MAIN APPLICATION
addappid(1834500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1834501, 1, "9c395dbfd2c7a1d8e795e8bc0f7619a0184b5eaaee421a2e1579a8cf7b7dddf6")

