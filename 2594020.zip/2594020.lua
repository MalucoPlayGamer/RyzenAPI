-- Lua provided by RyzenAPI
-- Game: Oxytone

-- MAIN APPLICATION
addappid(2594020)
-- Game: addappid(2594020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594021, 1, "68930d3198cf60f0e4e1d0062cfcee2ed32449980c569fd30eb00d2ec9a8f868")
