-- Lua provided by RyzenAPI
-- Game: AppID 1408420

-- MAIN APPLICATION
addappid(1408420)
-- Game: addappid(1408420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408421, 1, "e95341262e660fc3993501234abc9b09ca1f174dccbda74c0515af8b1bea759f")
