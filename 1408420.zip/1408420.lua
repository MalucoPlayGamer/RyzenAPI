-- Lua provided by RyzenAPI
-- Game: Ancient Worlds: Egypt

-- MAIN APPLICATION
addappid(1408420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1408421, 1, "e95341262e660fc3993501234abc9b09ca1f174dccbda74c0515af8b1bea759f")

