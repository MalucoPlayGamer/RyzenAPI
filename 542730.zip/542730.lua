-- Lua provided by RyzenAPI
-- Game: addappid(542730)

-- MAIN APPLICATION
addappid(542730)

-- MAIN APP DEPOTS / PACKAGES
addappid(542731, 1, "6ebb31223fa2adfdadbffc5aac2cc65932dfd16edaaf8c5f1c79c24a972ec35f")
