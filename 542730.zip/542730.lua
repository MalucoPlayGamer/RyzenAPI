-- Lua provided by RyzenAPI 
-- Game: Block Blowout
addappid(542730)
addappid(542731, 1, "6ebb31223fa2adfdadbffc5aac2cc65932dfd16edaaf8c5f1c79c24a972ec35f")
