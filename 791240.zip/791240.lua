-- Lua provided by RyzenAPI
-- Game: Lumote: The Mastermote Chronicles

-- MAIN APPLICATION
addappid(791240)

-- MAIN APP DEPOTS / PACKAGES
addappid(791241,0,"d964938a9a3a4466948b26b37708286420fdbd805c39cb85a8b179a441bec472")
addappid(791243,0,"f88ec62065a91e69443c284dcf332f1e88e1c41b1046268414411fb43a0a2c58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
