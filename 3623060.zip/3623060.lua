-- Lua provided by RyzenAPI
-- Game: My Bimbo Dream - Walkthrough, Comics & Supporter Pack

-- MAIN APPLICATION
addappid(3623060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623061, 1, "9618512b4f46799b9f95f7e59735ed8ebdac85c6a3ad6be157608032942e1aa3")

