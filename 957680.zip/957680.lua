-- Lua provided by RyzenAPI
-- Game: Doughlings: Invasion

-- MAIN APPLICATION
addappid(957680)
addappid(957681)
addappid(957683)
-- Game: addappid(957680)

-- MAIN APP DEPOTS / PACKAGES
addappid(957682,0,"f2e66df91e29c5fb763f94e362f05494926ca70acdcd5e302a6c7a0cdcc035e2")
