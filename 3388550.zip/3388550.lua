-- Lua provided by RyzenAPI
-- Game: Game: Island of Sacrifice

-- MAIN APPLICATION
addappid(3388550)
-- Game: addappid(3388550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388551, 1, "309e8bcaddc2ae1681deabffb175125b03b7dec977b848e5d5da3a6f1adf08a0")
