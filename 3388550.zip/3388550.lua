-- Lua provided by SkyAPI 
-- Game: Island of Sacrifice
addappid(3388550)
addappid(3388551, 1, "309e8bcaddc2ae1681deabffb175125b03b7dec977b848e5d5da3a6f1adf08a0")
