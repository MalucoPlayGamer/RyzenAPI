-- Lua provided by RyzenAPI
-- Game: Island of Sacrifice

-- MAIN APPLICATION
addappid(3388550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3388551, 1, "309e8bcaddc2ae1681deabffb175125b03b7dec977b848e5d5da3a6f1adf08a0")

