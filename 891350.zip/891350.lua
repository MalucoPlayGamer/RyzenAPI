-- Lua provided by RyzenAPI
-- Game: addappid(891350)

-- MAIN APPLICATION
addappid(891350)

-- MAIN APP DEPOTS / PACKAGES
addappid(891351, 1, "a974202d7320564a994980a3a108a308dcda3aa8ca93503db5399e3f5dfd0aad")
