-- Lua provided by RyzenAPI
-- Game: AppID 891350

-- MAIN APPLICATION
addappid(891350)

-- MAIN APP DEPOTS / PACKAGES
addappid(891351, 1, "a974202d7320564a994980a3a108a308dcda3aa8ca93503db5399e3f5dfd0aad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
