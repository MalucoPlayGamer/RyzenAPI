-- Lua provided by RyzenAPI
-- Game: VEREDA - Mystery Escape Room Adventure

-- MAIN APPLICATION
addappid(1899430)
-- Game: addappid(1899430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899431, 1, "1704c78185aee118fb35649f54c552f9bc660e0b2aefe35c3a508ee442b97f13")
