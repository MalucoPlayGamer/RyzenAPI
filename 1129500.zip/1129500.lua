-- Lua provided by SkyAPI 
-- Game: AppID 1129500
addappid(1129500)
addappid(1129501, 1, "ce6fe0910fb5d6c99092121395895666aea130e7414c8ba5a5905bad2a151b44")
