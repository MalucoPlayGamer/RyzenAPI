-- Lua provided by RyzenAPI
-- Game: 初恋日记 Demo

-- MAIN APPLICATION
addappid(1129500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129501, 1, "ce6fe0910fb5d6c99092121395895666aea130e7414c8ba5a5905bad2a151b44")

