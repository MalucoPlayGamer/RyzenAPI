-- Lua provided by RyzenAPI
-- Game: Planet Unknown Runner

-- MAIN APPLICATION
addappid(851580)
-- Game: addappid(851580)

-- MAIN APP DEPOTS / PACKAGES
addappid(851581, 1, "f2070c26bf3f24a16a62c1f40818580cc3294b9a1a2687abfb05d6eaed4ae688")
