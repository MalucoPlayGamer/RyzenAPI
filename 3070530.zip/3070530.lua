-- Lua provided by RyzenAPI
-- Game: addappid(3070530)

-- MAIN APPLICATION
addappid(3070530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070532,0,"068b311d87ecd1cf3be153c99041a641a91665e8e9528025cf2a358babf5e544")
