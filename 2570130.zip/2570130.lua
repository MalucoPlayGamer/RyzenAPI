-- Lua provided by RyzenAPI
-- Game: addappid(2570130)

-- MAIN APPLICATION
addappid(2570130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570131, 1, "c48ebaaee1a11e2e376d2be05838872b051d479a50e76184c3e100ab2f70a3eb")
