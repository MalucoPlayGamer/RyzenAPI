-- Lua provided by SkyAPI 
-- Game: AppID 1291330
addappid(1291330)
addappid(1291331, 1, "66e90dbca126796b60017ef5c2e1ba20b15dbbf97baca607d16c5e5e2b48ca65")
