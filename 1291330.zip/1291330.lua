-- Lua provided by RyzenAPI
-- Game: AppID 1291330

-- MAIN APPLICATION
addappid(1291330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291331, 1, "66e90dbca126796b60017ef5c2e1ba20b15dbbf97baca607d16c5e5e2b48ca65")

