-- Lua provided by RyzenAPI
-- Game: 她毕业了 Demo

-- MAIN APPLICATION
addappid(2195620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195621, 1, "7912c91d15dccd6baec087a7134a46baeb11dbd8798854ee4f117cfa23b1dcd4")
