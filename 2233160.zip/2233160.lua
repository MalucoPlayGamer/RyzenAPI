-- Lua provided by RyzenAPI
-- Game: AirportSim Demo

-- MAIN APPLICATION
addappid(2233160)
-- Game: addappid(2233160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233161, 1, "b13cec64055fcde4eacfc1d783625c6d8deae003185e8d56609a10d84f39917e")
