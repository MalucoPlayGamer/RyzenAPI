-- Lua provided by RyzenAPI
-- Game: Game: AppID 1116800

-- MAIN APPLICATION
addappid(1116800)
-- Game: addappid(1116800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116801, 1, "58250a36e85563a3c694803d742cc7e20ebe59ccc201a25e5bcb84e2f6c62438")
