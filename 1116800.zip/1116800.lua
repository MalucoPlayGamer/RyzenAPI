-- Lua provided by SkyAPI 
-- Game: AppID 1116800
addappid(1116800)
addappid(1116801, 1, "58250a36e85563a3c694803d742cc7e20ebe59ccc201a25e5bcb84e2f6c62438")
