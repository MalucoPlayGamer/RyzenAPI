-- Lua provided by RyzenAPI
-- Game: Hell Pub

-- MAIN APPLICATION
addappid(1204970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204971, 1, "feedbe43d3c3fb38eac0bfd086473c256653e62b4963049ffdc28dbf3b9a23f9")
