-- Lua provided by RyzenAPI
-- Game: Game: The Smurfs – Dreams

-- MAIN APPLICATION
addappid(2602020)
-- Game: addappid(2602020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602021, 1, "9fc6cd24dd68b66041330f6bde93e5be11c7c64df8b83910ec170a7b465b4bc6")
addappid(2922830, 0, "a642f52a984088185949a566487a188c529954eda9571a8ae947fc8093c69ad8")
