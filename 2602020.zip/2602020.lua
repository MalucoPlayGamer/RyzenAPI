-- Lua provided by RyzenAPI
-- Game: The Smurfs – Dreams

-- MAIN APPLICATION
addappid(2602020)
addappid(2922820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2602021, 1, "9fc6cd24dd68b66041330f6bde93e5be11c7c64df8b83910ec170a7b465b4bc6")
addappid(2922830, 0, "a642f52a984088185949a566487a188c529954eda9571a8ae947fc8093c69ad8")

