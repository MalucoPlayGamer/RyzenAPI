-- Lua provided by RyzenAPI
-- Game: BIKI BIKI FLIP

-- MAIN APPLICATION
addappid(2382440)
-- Game: addappid(2382440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382441, 1, "5efdf3a60cc103f5940f0f9da73661ddcf400903313f13a4081563d1ca6de50c")
