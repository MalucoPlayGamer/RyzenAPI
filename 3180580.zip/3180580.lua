-- Lua provided by RyzenAPI
-- Game: 绝命游歌 Soundtrack

-- MAIN APPLICATION
addappid(3180580)
-- Game: addappid(3180580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180581, 1, "aef7b9d55087084281190062fcdc214d6ec5a78be26d7dbb879846943fded7ec")
addappid(3180582, 1, "30b3a1fa7b8efe55ac5983713892336df3d187fa6de3e537d2e4997a9a94b949")
