-- Lua provided by RyzenAPI
-- Game: SCP: Containment Breach Multiplayer

-- MAIN APPLICATION
addappid(1782380)
-- Game: addappid(1782380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782381, 1, "e40b49c173edf305fd77a62c62d2e8233939dadd7dfaf4368a3f25a5c889836b")
