-- Lua provided by RyzenAPI
-- Game: Drone Hero

-- MAIN APPLICATION
addappid(571430)

-- MAIN APP DEPOTS / PACKAGES
addappid(571431, 1, "55779aad3c21f44f0eafda085813504fb67cef51abace05e934fee1e6079c063")
