-- Lua provided by RyzenAPI
-- Game: AppID 596810

-- MAIN APPLICATION
addappid(596810)
-- Game: addappid(596810)

-- MAIN APP DEPOTS / PACKAGES
addappid(596811, 1, "7fd7a676ed79245e1177749fd365518f2d6f10df7da716b36bc534341629c145")
