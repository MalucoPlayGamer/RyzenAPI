-- Lua provided by RyzenAPI
-- Game: I Expect You To Die

-- MAIN APPLICATION
addappid(587430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(587431, 1, "eeda000e949e2a0be67b4c7e0fc40947a07bc2221b850d5bce357667ee8089e6")

