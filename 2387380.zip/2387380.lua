-- Lua provided by RyzenAPI 
-- Game: Bare Witness
addappid(2387380)
addappid(2387381, 1, "600c6a947be26a555b0c44bc4ef509ea2e63d69884bf1b6bbf75aab77836c446")
addappid(3932850)
