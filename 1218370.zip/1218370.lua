-- Lua provided by RyzenAPI
-- Game: Gravity Escape Demo

-- MAIN APPLICATION
addappid(1218370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218371, 1, "37b279515aeaa20f08f23620ec8c88710b38b04673f353a0a1aa17017ee9888f")
