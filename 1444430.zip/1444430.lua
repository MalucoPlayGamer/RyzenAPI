-- Lua provided by RyzenAPI
-- Game: 3D Hentai Puzzle

-- MAIN APPLICATION
addappid(1444430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444431, 1, "b9997fad591213da132b332b6522d8285032ab011c0f645ece2fcbf226ab6e3c")

