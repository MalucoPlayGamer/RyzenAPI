-- Lua provided by RyzenAPI
-- Game: Game: AppID 702430

-- MAIN APPLICATION
addappid(702430)
-- Game: addappid(702430)

-- MAIN APP DEPOTS / PACKAGES
addappid(702431, 1, "380cff5aa5dcb9054b999c7f5c96870a4167025b050b947589c80b8f9cdd9cff")
