-- Lua provided by RyzenAPI
-- Game: Game: AppID 2544570

-- MAIN APPLICATION
addappid(2544570)
-- Game: addappid(2544570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544571, 1, "1088b6f1da25954c522dffc5db8c3ffcaeafa861fa68628cc6e96b00dd07d554")
