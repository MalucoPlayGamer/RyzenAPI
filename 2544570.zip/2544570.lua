-- Lua provided by SkyAPI 
-- Game: AppID 2544570
addappid(2544570)
addappid(2544571, 1, "1088b6f1da25954c522dffc5db8c3ffcaeafa861fa68628cc6e96b00dd07d554")
