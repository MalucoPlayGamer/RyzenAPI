-- Lua provided by RyzenAPI
-- Game: Cossacks: European Wars

-- MAIN APPLICATION
addappid(4880)

-- MAIN APP DEPOTS / PACKAGES
addappid(4881, 1, "1425f9dfca066c5112ce9c9c5efca74e3478fd1a07a89dab79ea08078fbfe26b")
