-- Lua provided by RyzenAPI
-- Game: Game: AppID 931880

-- MAIN APPLICATION
addappid(931880)
-- Game: addappid(931880)

-- MAIN APP DEPOTS / PACKAGES
addappid(931881, 1, "9ef5d1e52e7bf4c70d03d16f19c7426274e5cb9fa041d8872ac631f75fea15f8")
