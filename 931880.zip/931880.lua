-- Lua provided by RyzenAPI 
-- Game: AppID 931880
addappid(931880)
addappid(931881, 1, "9ef5d1e52e7bf4c70d03d16f19c7426274e5cb9fa041d8872ac631f75fea15f8")
