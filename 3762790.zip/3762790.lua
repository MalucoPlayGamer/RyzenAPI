-- Lua provided by RyzenAPI
-- Game: Terraformental

-- MAIN APPLICATION
addappid(3762790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3762791,0,"7613e7bb41c30bae971f6f203860cda312f7f5dcc5b3c03dcb522e4fe34b69c2")

