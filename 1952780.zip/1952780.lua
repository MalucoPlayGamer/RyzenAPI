-- Lua provided by RyzenAPI
-- Game: Spider Slingers

-- MAIN APPLICATION
addappid(1952780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952781, 1, "31f3131d92cd197b08d499c07e1f30d7b6ef24bec8b6afcd50b598e449a671d9")
addappid(1952783, 1, "0b3c63934ceccfcf809626700a66ffab9f5fa15312e30ef8a199d24030e47013")
addappid(1952784, 1, "239084daa8ff7d8102f5e2527cf35bae252a7a7ac12288e74c7cc8cbcae3a1fd")

