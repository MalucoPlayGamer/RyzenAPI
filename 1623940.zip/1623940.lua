-- Lua provided by RyzenAPI
-- Game: Bramble: The Mountain King

-- MAIN APPLICATION
addappid(1623940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623941, 1, "ecbb0a11ee67b804985728a61d9c2271c604efcf6346f846bbc171060a71f0b8")
