-- Lua provided by RyzenAPI
-- Game: Imperial Knightess Wein's Irregular Life

-- MAIN APPLICATION
addappid(3250980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3250981, 1, "7968aca74ab3969bc91e55d2b03cbd8021c7a9a55cd8e420919b98a3435487e7")
addappid(3250982, 1, "48b2b3324381b556dc251697ad21b3e191f299351fae4dbd771013d951c23dcc")
addappid(3250983, 1, "80bc12509eae48bb1457ec0a8e87c120f8a8e94f53ff5268f5a2cdf06fe9cf9d")
