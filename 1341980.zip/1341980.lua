-- Lua provided by RyzenAPI
-- Game: Coronavirus - Nano Force

-- MAIN APPLICATION
addappid(1341980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341981, 1, "f88258fb042031d70915b913896936e50e0626b50c8ec47d6f61fd820822f2a9")
addappid(1341982, 1, "296f15c0dd9a7ae5864a9c68d1a30fe10c2c04ddedd8f27fe61d7a1f933ee539")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
