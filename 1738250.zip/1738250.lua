-- Lua provided by RyzenAPI
-- Game: DIY Your lady - DIY Your Nurse

-- MAIN APPLICATION
addappid(1738250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738250,0,"d42f1e17f0e1b2c9bd2f99d7de390e106a776401e7941f2c8a40f12d021753c3")
