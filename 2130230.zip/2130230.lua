-- Lua provided by RyzenAPI
-- Game: Gravity Box

-- MAIN APPLICATION
addappid(2130230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130231, 1, "6ec409b9b6965653cbd412c6986ed1a7fc5378bf8cfc791f3d6382948a33049c")
