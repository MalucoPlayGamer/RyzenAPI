-- Lua provided by RyzenAPI
-- Game: WWE 2K18

-- MAIN APPLICATION
addappid(664430)
addappid(704630)
addappid(706060)
addappid(706070)
addappid(706080)
addappid(706090)
addappid(706100)
addappid(706110)
addappid(706230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(664431, 1, "725c50910466da1312b62e843ea484b060e6659bc585aae656fdfa3f1ba7f4c5")

