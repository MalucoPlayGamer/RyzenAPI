-- Lua provided by RyzenAPI
-- Game: Game: WWE 2K18

-- MAIN APPLICATION
addappid(664430)
-- Game: addappid(664430)

-- MAIN APP DEPOTS / PACKAGES
addappid(664431, 1, "725c50910466da1312b62e843ea484b060e6659bc585aae656fdfa3f1ba7f4c5")
