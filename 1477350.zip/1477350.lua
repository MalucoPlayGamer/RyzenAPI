-- Lua provided by RyzenAPI
-- Game: Jigsaw Puzzle Tales Soundtrack

-- MAIN APPLICATION
addappid(1477350)
-- Game: addappid(1477350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477351, 1, "d16153f882a03f44519feb22527c553dcbd4b603790b0a18e8f8bde07695f850")
addappid(1477352, 1, "6059d97c6134461066e86d01a0c513e1e8942954c09be6d02032797bfe58bd9a")
