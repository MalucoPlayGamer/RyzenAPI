-- Lua provided by RyzenAPI
-- Game: 892650

-- MAIN APPLICATION
addappid(892650)
addappid(897230)
-- Game: addappid(892650)

-- MAIN APP DEPOTS / PACKAGES
addappid(892651, 1, "e662b434d9afa49a08eaa02a368c987d66bf9708ddf517c2ccf745cdf3736242")
addappid(897240, 0, "6e65686b9c2ebb2e9d85e7b4f477e4f7a85f5a7eec38a050fd6c79f56c191581")
addappid(897250, 0, "38453be64b9188be4949543a2e8a64ae35fc6bfd69e554b684ff51d19ad61955")
addappid(911990, 0, "100a32fcc1fca93a6c7657316a4b6ffc03346f68b09b6e20918ad1fe8d7a037a")
