-- Lua provided by RyzenAPI
-- Game: Game: Cosmodread

-- MAIN APPLICATION
addappid(1256060)
-- Game: addappid(1256060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256061, 1, "df0fd6eb06b2f762ce17c062e28131f4265b53d507544e64d65a000a39aa7c56")
