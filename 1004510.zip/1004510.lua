-- Lua provided by RyzenAPI
-- Game: DownStream : VR Whitewater Kayaking

-- MAIN APPLICATION
addappid(1004510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004511, 1, "417ebf0599ff4490235730815578e9710d8f065e35905c02dd51bceae5e71036")

