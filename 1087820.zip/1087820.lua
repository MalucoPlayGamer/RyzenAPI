-- Lua provided by RyzenAPI
-- Game: AppID 1087820

-- MAIN APPLICATION
addappid(1087820)
-- Game: addappid(1087820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087821, 1, "5d58bc654724f46f0da5eee35c92af7cb6f17f31758cd6dd7a82fde2c94f4f1f")
