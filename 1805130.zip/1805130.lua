-- Lua provided by RyzenAPI
-- Game: addappid(1805130)

-- MAIN APPLICATION
addappid(1805130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805131, 1, "c9f367ce816c4fd4382918a05a69feeeef5deaa75d03d45a424d05236f64e03d")
