-- 4451400's Lua and Manifest Created by Hubcap Manifest
-- Massage With Benefits
-- Created: August 29, 2026 at 00:30:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4451400) -- Massage With Benefits
-- MAIN APP DEPOTS
addappid(4451401, 1, "4b745825d1658296523d6885265d8aa3e17b87e951a270209924b47762bb50dc") -- Depot 4451401
setManifestid(4451401, "4034245093504893460", 3954089174)