-- Lua provided by RyzenAPI
-- Game: Massage With Benefits

-- MAIN APPLICATION
addappid(4451400) -- Massage With Benefits

-- MAIN APP DEPOTS / PACKAGES
addappid(4451401, 1, "4b745825d1658296523d6885265d8aa3e17b87e951a270209924b47762bb50dc") -- Depot 4451401

