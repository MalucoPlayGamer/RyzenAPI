-- Lua provided by RyzenAPI
-- Game: addappid(2396240)

-- MAIN APPLICATION
addappid(2396240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396241, 1, "a33fb80f640826dd29e8a225baf9156fc106564d7de50b8c786bb01ba5e3effb")
