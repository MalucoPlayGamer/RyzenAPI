-- Lua provided by RyzenAPI
-- Game: ORDER 13

-- MAIN APPLICATION
addappid(2259310)
-- Game: addappid(2259310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259312,0,"a3f0d162fd3d9861b0aaf0fac52beb7598655e86a6a919f048767d3d6832ab5d")
