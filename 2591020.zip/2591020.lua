-- 2591020's Lua and Manifest Created by Hubcap Manifest
-- DraconG
-- Created: August 11, 2026 at 14:37:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2591020) -- DraconG
-- MAIN APP DEPOTS
addappid(2591021, 1, "c812f7746c27f114050b3ea6de09c4a11c301e3cbe889466ad99b749443bac7f") -- Depot 2591021
setManifestid(2591021, "8715670532295383727", 7914785195)