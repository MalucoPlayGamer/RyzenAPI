-- Lua provided by RyzenAPI
-- Game: DraconG

-- MAIN APPLICATION
addappid(2591020) -- DraconG

-- MAIN APP DEPOTS / PACKAGES
addappid(2591021, 1, "c812f7746c27f114050b3ea6de09c4a11c301e3cbe889466ad99b749443bac7f") -- Depot 2591021

