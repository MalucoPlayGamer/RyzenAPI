-- Lua provided by RyzenAPI
-- Game: Call of the Wild: The Angler™

-- MAIN APPLICATION
addappid(228988)
addappid(1408610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408612,0,"0df254da7c6699200feea9dd9b69b97e7275867dbc594c76c55f4324cc0597e5")
addappid(1408613,0,"8b019c5dac3541d498213ef63801f591cb9b1fdf3cd28716f3d5ebd9e03bd03a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2125860)
addappid(2125861)
addappid(2165500)
addappid(2288430)
addappid(2388130)
addappid(2500360)
addappid(2500370)
addappid(2633140)
addappid(2659060)
addappid(2659070)
addappid(2659080)
addappid(2936210)
addappid(2997100)
addappid(3046830)
