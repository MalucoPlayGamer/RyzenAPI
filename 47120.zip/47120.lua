-- Lua provided by RyzenAPI
-- Game: Escape From Paradise 2

-- MAIN APPLICATION
addappid(47120)
-- Game: addappid(47120)

-- MAIN APP DEPOTS / PACKAGES
addappid(47121, 1, "c3a0212a1a022f824571264394511695757de1d9a4fbcbbaec468ea954b31d86")
