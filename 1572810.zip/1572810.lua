-- Lua provided by RyzenAPI
-- Game: МЕМОЛОГИЯ

-- MAIN APPLICATION
addappid(1572810)
-- Game: addappid(1572810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1572811, 1, "b152ff06fe3b75bac720724d0386d49c12f16e2954b8d1db106e364b967d9e0c")
