-- Lua provided by RyzenAPI
-- Game: Attack on Steel

-- MAIN APPLICATION
addappid(3227530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227531, 1, "c63e341852dd603c848ff91f7ad3b0c8d3d059b31e43816462c4b8c47ac5d0f0")

