-- Lua provided by RyzenAPI
-- Game: Lord of the Dark Castle

-- MAIN APPLICATION
addappid(349460)
-- Game: addappid(349460)

-- MAIN APP DEPOTS / PACKAGES
addappid(349461, 1, "9e256aad4c3b287c2b3365918d4321869bb6aa2430e829741251513dac03a58b")
addappid(349462, 1, "b78cb42edd681d8842f461d4adc445a8c038232c64f7c9eea76102f95e876e7d")
addappid(349463, 1, "7489ed76d09bfc46c50daef3ad7c1a5ef31718b2676065ef48345fe49e2f1747")
addappid(349464, 1, "83268757970bbdecae40d4f0fa3a5d8988ce083f3b3faf548f6e0f137ba94ffb")
addappid(349465, 1, "c9aac0fb17b6b4bc3856e3775d0a89de8dbcbc16fb746e1ead2e3296e2663e4b")
addappid(349466, 1, "f3f96b2b64b8934e12d842c165a6e060aeda9b429ad1487d72396c73d55cbee8")
