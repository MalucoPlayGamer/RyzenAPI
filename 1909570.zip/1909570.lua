-- Lua provided by RyzenAPI
-- Game: Game: His Journey Soundtrack

-- MAIN APPLICATION
addappid(1909570)
-- Game: addappid(1909570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909571, 1, "2127ef855f799d69600645737cf7be901c59c819daf737e7e483776ac2bb9685")
