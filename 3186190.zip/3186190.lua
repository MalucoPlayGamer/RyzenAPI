-- Lua provided by RyzenAPI
-- Game: 3186190

-- MAIN APPLICATION
addappid(3186190)
-- Game: addappid(3186190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186191, 1, "cc946626bd7ce571ce7b6e8935bb984caae7337acebe397dba464ba7f911bf45")
