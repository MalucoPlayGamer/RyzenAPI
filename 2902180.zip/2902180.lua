-- Lua provided by RyzenAPI
-- Game: SKALD: Against the Black Priory Soundtrack

-- MAIN APPLICATION
addappid(2902180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902181, 1, "38241e6b80493cb0f4cce4e996a33a342c9a543d12f1593247d2b96933e23d50")
addappid(2902182, 1, "a902da9660d2ba74a648fcc63c79288561808291b5351463ace0dd31b7ccd478")
