-- Lua provided by SkyAPI 
-- Game: AppID 1342350
addappid(1342350)
addappid(1342351, 1, "9b97113d527a95b705d2d7e152fc673ee310e33528d5aafc8bde351cd85b5925")
