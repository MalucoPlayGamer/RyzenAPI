-- Lua provided by RyzenAPI
-- Game: 1342350

-- MAIN APPLICATION
addappid(1342350)
-- Game: addappid(1342350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342351, 1, "9b97113d527a95b705d2d7e152fc673ee310e33528d5aafc8bde351cd85b5925")
