-- Lua provided by RyzenAPI 
-- Game: Super Puzzled Cat Demo
addappid(3045020)
addappid(3045021, 1, "2a9580193fe40e1a88b437e3fc4e22bcec9d584b49126de32eeb1d7908cb5ee9")
