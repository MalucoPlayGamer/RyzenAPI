-- Lua provided by RyzenAPI
-- Game: Crown of Greed Demo

-- MAIN APPLICATION
addappid(3307570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307571, 1, "cc9a08d21284d3854a7e92f85dc792d20de69a80726d50d4514f7c5d73d33209")

