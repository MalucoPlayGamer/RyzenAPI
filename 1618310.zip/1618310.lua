-- Lua provided by RyzenAPI
-- Game: Zombie Strike

-- MAIN APPLICATION
addappid(1618310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618314,0,"b109579fe068ac3d6adf8c3a2c391b132359b6825cc13b145f4679cc32df9f88")

