-- Lua provided by RyzenAPI
-- Game: Like a Dragon: Ishin! Combat Demo

-- MAIN APPLICATION
addappid(2277820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277821, 1, "8ff220d2a8f6ec3b6d985f675bf16a69520670389f5ce07242aa5e27b3437797")
