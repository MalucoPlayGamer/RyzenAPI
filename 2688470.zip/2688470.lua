-- Lua provided by RyzenAPI
-- Game: Lost in Dread Demo

-- MAIN APPLICATION
addappid(2688470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688471, 1, "997611192ac5aca330ede2603dae3cc04bee320926bf7170587bf30ea6d5af7d")

