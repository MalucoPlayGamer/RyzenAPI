-- Lua provided by RyzenAPI
-- Game: Homgard

-- MAIN APPLICATION
addappid(4287570)

-- MAIN APP DEPOTS / PACKAGES
addappid(4287571,0,"99302b017f1f129bbbfc1aaa7b691b6327e1aeb186ac12d7f02b49736f29b3ec")

