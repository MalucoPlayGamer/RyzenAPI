-- Lua provided by RyzenAPI
-- Game: 1566700

-- MAIN APPLICATION
addappid(1566700)
-- Game: addappid(1566700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566701, 1, "9051e9b32bc33942a760a326984de4b6e02839459bc0897a98bd8f61b28fbe1a")
