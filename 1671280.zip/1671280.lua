-- Lua provided by RyzenAPI
-- Game: Prognostic

-- MAIN APPLICATION
addappid(1671280)
-- Game: addappid(1671280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671281, 1, "b4c0a526085409dc6dc79ad1b959ba47f850d95df4914a955b9f27e835adf12e")
