-- Lua provided by RyzenAPI
-- Game: Prognostic

-- MAIN APPLICATION
addappid(1671280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671281, 1, "b4c0a526085409dc6dc79ad1b959ba47f850d95df4914a955b9f27e835adf12e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
