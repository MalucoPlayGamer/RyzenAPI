-- Lua provided by RyzenAPI 
-- Game: AppID 466740
addappid(466740)
addappid(466741, 1, "b698210d00f3d05ab97f7cdf7a21b1694f4de3339e551d184312004ba58845ef")
