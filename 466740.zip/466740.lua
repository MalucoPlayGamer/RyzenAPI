-- Lua provided by RyzenAPI
-- Game: 466740

-- MAIN APPLICATION
addappid(466740)
-- Game: addappid(466740)

-- MAIN APP DEPOTS / PACKAGES
addappid(466741, 1, "b698210d00f3d05ab97f7cdf7a21b1694f4de3339e551d184312004ba58845ef")
