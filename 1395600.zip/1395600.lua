-- Lua provided by RyzenAPI
-- Game: Party Parkade

-- MAIN APPLICATION
addappid(1395600)
-- Game: addappid(1395600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395602,0,"6d705d3171a75502b03e052242f53a538232ea6f5437c015d288be64e9b298be")
addappid(1395603,0,"5aeb5d62abad583d981438644b9896dc5c15e4d0115e8d7f0c1e9cbdfd19da94")
