-- Lua provided by RyzenAPI
-- Game: Hotel Magnate

-- MAIN APPLICATION
addappid(832360)

-- MAIN APP DEPOTS / PACKAGES
addappid(832361, 1, "2af7df4c274be9ac7bdec33394dd6206800f6c16b3e17a82cceef72c51ddcef0")
addappid(832362, 1, "482b026166021ba1db4fb543ff4c314b7e321381b5b078ed040adb8d54c3ae17")
addappid(832363, 1, "a6e22519c823972fe160199e99a282d714f025779b09c8e224b3187b67a1f4ea")
