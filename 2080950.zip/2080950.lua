-- Lua provided by RyzenAPI
-- Game: Rawbots

-- MAIN APPLICATION
addappid(2080950)
-- Game: addappid(2080950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080951, 1, "8e0679889fc54636ebcb1fd968fcf4ed631accc5b23ebf9298779529f6a67579")
