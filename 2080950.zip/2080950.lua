-- Lua provided by RyzenAPI
-- Game: Rawbots

-- MAIN APPLICATION
addappid(2080950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080951, 1, "8e0679889fc54636ebcb1fd968fcf4ed631accc5b23ebf9298779529f6a67579")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
