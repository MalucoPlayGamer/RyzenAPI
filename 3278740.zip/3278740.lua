-- Lua provided by RyzenAPI
-- Game: Game: AppID 3278740

-- MAIN APPLICATION
addappid(3278740)
-- Game: addappid(3278740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278741, 1, "82df7c5edfc24e79ee6775787e657d5d50baccb07122963e64ddec7ea90d267c")
addappid(3278742, 1, "bd68cfaa891463a412825ec4853a7697423ec4b65834cba3b4a3ceaae67ceb15")
