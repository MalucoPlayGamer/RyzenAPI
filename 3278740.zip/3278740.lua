-- Lua provided by RyzenAPI
-- Game: NEURO

-- MAIN APPLICATION
addappid(3278740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3278741, 1, "82df7c5edfc24e79ee6775787e657d5d50baccb07122963e64ddec7ea90d267c")
addappid(3278742, 1, "bd68cfaa891463a412825ec4853a7697423ec4b65834cba3b4a3ceaae67ceb15")
