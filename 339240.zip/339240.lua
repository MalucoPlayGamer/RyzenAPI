-- Lua provided by RyzenAPI
-- Game: AppID 339240

-- MAIN APPLICATION
addappid(339240)
-- Game: addappid(339240)

-- MAIN APP DEPOTS / PACKAGES
addappid(339241, 1, "770a7316607fdac4728a1311c60230e828dd3dda321ad15ccde223d91a828251")
