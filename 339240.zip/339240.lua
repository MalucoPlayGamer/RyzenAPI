-- Lua provided by RyzenAPI
-- Game: AppID 339240

-- MAIN APPLICATION
addappid(339240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(339241, 1, "770a7316607fdac4728a1311c60230e828dd3dda321ad15ccde223d91a828251")

