-- Lua provided by SkyAPI 
-- Game: AppID 385880
addappid(385880)
addappid(385881, 1, "79b1ba179e3b8c0a1282482e35cf37357bd32ea187a3e2558a1a249656f85469")
