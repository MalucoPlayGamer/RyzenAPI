-- Lua provided by RyzenAPI
-- Game: Lost Skies

-- MAIN APPLICATION
addappid(1931180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931181, 1, "e3b3d8902ae9814c4521fa2a3538b10d43c1fea4f712aa229f22d826ccd8ee6e")
