-- Lua provided by RyzenAPI
-- Game: 1116670

-- MAIN APPLICATION
addappid(1116670)
addappid(1116673)
addappid(1116674)
addappid(1116675)
addappid(1116676)
-- Game: addappid(1116670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116672,0,"7474edb19fca101a17645374f955109a3d772483a9e3373e07bdd1c302c15f37")
