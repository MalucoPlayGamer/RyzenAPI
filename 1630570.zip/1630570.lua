-- Lua provided by RyzenAPI
-- Game: EXS1～EthnologySister：Cultural functionalism

-- MAIN APPLICATION
addappid(1630570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630571, 1, "7b1e4c12f5d0d655623d803ae57104943072fd2f3a36c8713b9fd076fa1cdb7a")

