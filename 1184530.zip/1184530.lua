-- Lua provided by RyzenAPI
-- Game: 1184530

-- MAIN APPLICATION
addappid(1184530)
-- Game: addappid(1184530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184531, 1, "ae420278c77d8b40600b72956b22bca084345aa9b837bac13cb0b2a69d43b1c2")
