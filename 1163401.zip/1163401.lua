-- Lua provided by RyzenAPI
-- Game: DFF NT: The False General Appearance Set for Gabranth

-- MAIN APPLICATION
addappid(1163401)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163401,0,"1ad7a857d87841c9c677e3a5c6c6477c75f370f8213b7a3205961ac7712c1d25")
