-- Lua provided by RyzenAPI
-- Game: Mushroom Musume

-- MAIN APPLICATION
addappid(2484580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484581, 1, "136e42393be23d00d1eed7781023580ee8157cc056cce7c897fc581a0fbf5511")

