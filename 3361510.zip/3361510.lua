-- Lua provided by RyzenAPI
-- Game: Coal LLC

-- MAIN APPLICATION
addappid(3361510)
-- Game: addappid(3361510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361511, 1, "603aa781476bfd4d6e22387bf16d703ad2c49998204542539dc9f0b08ac89299")
