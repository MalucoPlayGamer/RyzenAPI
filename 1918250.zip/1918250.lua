-- Lua provided by RyzenAPI
-- Game: 1918250

-- MAIN APPLICATION
addappid(1918250)
-- Game: addappid(1918250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918251, 1, "50a7f37062c7452dbf242efc1baea14e3350a69c86e5184756a3f548ae1b837e")
