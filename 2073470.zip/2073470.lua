-- Lua provided by RyzenAPI
-- Game: Kanjozoku Game レーサー Online Street Racing & Drift

-- MAIN APPLICATION
addappid(2073470)
-- Game: addappid(2073470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073471, 1, "5837132012b157cbe91c71358e42472e03265a0adb500fce667b30a4d90c9849")
