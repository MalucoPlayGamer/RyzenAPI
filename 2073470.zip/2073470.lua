-- Lua provided by RyzenAPI 
-- Game: Kanjozoku Game レーサー Online Street Racing & Drift
addappid(2073470)
addappid(2073471, 1, "5837132012b157cbe91c71358e42472e03265a0adb500fce667b30a4d90c9849")
