-- Lua provided by RyzenAPI
-- Game: Game: AppID 1265960

-- MAIN APPLICATION
addappid(1265960)
-- Game: addappid(1265960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265961, 1, "8877f582d11013b575b5d3236f5a37a7249dc22c457bd05d0d208ea616a29f12")
