-- Lua provided by RyzenAPI
-- Game: WoMen in Science

-- MAIN APPLICATION
addappid(1097210)
-- Game: addappid(1097210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097211, 1, "a985432077a483b4a94ac9a5d7637ba58832759a15773bd620a5e6e885526746")
