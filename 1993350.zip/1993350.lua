-- Lua provided by RyzenAPI
-- Game: Game: Redout 2 - Original Soundtrack

-- MAIN APPLICATION
addappid(1993350)
-- Game: addappid(1993350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993351, 1, "72bb8694afac0787072d9b1f8367dd4627f29890218d27e878666d3d4662baf1")
addappid(1993352, 1, "12437d178e4a43a71efdbefd889aede912e0dcdab5400c680a33d18561c5e9c6")
