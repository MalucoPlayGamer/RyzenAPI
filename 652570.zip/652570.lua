-- Lua provided by RyzenAPI
-- Game: Mystika 3 : Awakening of the dragons

-- MAIN APPLICATION
addappid(652570)

-- MAIN APP DEPOTS / PACKAGES
addappid(652571,0,"af5be8028254f2bfa270aab1b921c1e30913236e1a456e7da0384f87d1cf99c6")

