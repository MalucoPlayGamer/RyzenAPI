-- Lua provided by RyzenAPI
-- Game: Fight Crab 2

-- MAIN APPLICATION
addappid(2457580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2457581, 1, "1682b6999e630f66c641d8d04a3693f90a6618dc6cfc1d52712bcc95a1c7ca25")

