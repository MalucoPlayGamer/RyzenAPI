-- Lua provided by RyzenAPI
-- Game: 2457580

-- MAIN APPLICATION
addappid(2457580)
-- Game: addappid(2457580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457581, 1, "1682b6999e630f66c641d8d04a3693f90a6618dc6cfc1d52712bcc95a1c7ca25")
