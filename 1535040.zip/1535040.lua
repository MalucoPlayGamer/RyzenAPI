-- Lua provided by RyzenAPI
-- Game: The Great Unborn

-- MAIN APPLICATION
addappid(1535040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535041, 1, "ea3f1ea14a9cbef08fd9daa64a94dea4af3c89fab266dc8906decd5911b2e913")
