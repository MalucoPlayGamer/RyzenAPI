-- Lua provided by RyzenAPI
-- Game: One Gun Guy

-- MAIN APPLICATION
addappid(1200580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1200581, 1, "37e4689f5fb3ad526fa823a372dabd04e540026eecc2979920625b4465bc9550")

