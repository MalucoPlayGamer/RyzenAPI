-- Lua provided by RyzenAPI
-- Game: 1200580

-- MAIN APPLICATION
addappid(1200580)
-- Game: addappid(1200580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200581, 1, "37e4689f5fb3ad526fa823a372dabd04e540026eecc2979920625b4465bc9550")
