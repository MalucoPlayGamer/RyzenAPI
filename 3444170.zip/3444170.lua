-- Lua provided by RyzenAPI 
-- Game: AppID 3444170
addappid(3444170)
addappid(3444171, 1, "9752c5d63b5ea4459797818a955eab07fa4fdfff326609727a66a0a34eede54b")
