-- Lua provided by RyzenAPI
-- Game: OhShape

-- MAIN APPLICATION
addappid(1098100)
addappid(1675930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098101, 1, "6da9536130756e4e4a34ee6a0858c0ed7c9fcb27b136bf504ca99ebaed3405d5")
