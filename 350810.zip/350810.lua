-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles 2: Anime

-- MAIN APPLICATION
addappid(350810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(350811, 1, "093ef6f3a554599a98f9ebce1adb358e06311e35a458472702cc1f97b6bcd9ba")

