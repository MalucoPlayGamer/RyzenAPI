-- Lua provided by RyzenAPI
-- Game: 1722850

-- MAIN APPLICATION
addappid(1722850)
-- Game: addappid(1722850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722851, 1, "5eac236d0bba1a8f009f8386390114746ac3ca646bb9d02f493b39ca142e86a1")
