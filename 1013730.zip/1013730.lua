-- Lua provided by RyzenAPI
-- Game: Hard Core Puzzle

-- MAIN APPLICATION
addappid(1013730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013731, 1, "9895ab245c3652b38c32ab37297fe6c82151415409f3542e4ed3c039260feed2")
addappid(1013732, 1, "e3b691cbda7dedb68ac88c4ead6aba879a2a33d826f1df6442653050156cc5f0")
