-- Lua provided by RyzenAPI
-- Game: Super president How to rule the country

-- MAIN APPLICATION
addappid(995480)

-- MAIN APP DEPOTS / PACKAGES
addappid(995481, 1, "384d8c76cba0077596274a98806d3fee1ed47b152ffddd9bfbd97bcc7ca4f72f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
