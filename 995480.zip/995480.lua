-- Lua provided by RyzenAPI
-- Game: Game: Super president How to rule the country

-- MAIN APPLICATION
addappid(995480)
-- Game: addappid(995480)

-- MAIN APP DEPOTS / PACKAGES
addappid(995481, 1, "384d8c76cba0077596274a98806d3fee1ed47b152ffddd9bfbd97bcc7ca4f72f")
