-- Lua provided by RyzenAPI
-- Game: Game: AppID 914000

-- MAIN APPLICATION
addappid(914000)
-- Game: addappid(914000)

-- MAIN APP DEPOTS / PACKAGES
addappid(914001, 1, "04477505f5ef161fe4bf9ed30d89455eba4bfcaeaedaf679e6c987de36a4a0a9")
