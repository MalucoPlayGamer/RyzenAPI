-- Lua provided by RyzenAPI
-- Game: AppID 2747030

-- MAIN APPLICATION
addappid(2747030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747031, 1, "f2619bb56613a015eb61cdaab71ba9d0b7b9fc22529eec5c6ead8176f4038752")

