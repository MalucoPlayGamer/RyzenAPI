-- Lua provided by RyzenAPI
-- Game: Upstairs

-- MAIN APPLICATION
addappid(4352920)

-- MAIN APP DEPOTS / PACKAGES
addappid(4352922,0,"34d1cbe4144f26edd4ba8c0016d597c2cdfcfe634ea5b310323db7d1441995d0")

