-- Lua provided by RyzenAPI
-- Game: addappid(2118300)

-- MAIN APPLICATION
addappid(2118300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118301, 1, "23b5514ed8bb9cf9ce41a0dee772e82f06b1687b2ec41c0b4d87d016cddb39b8")
