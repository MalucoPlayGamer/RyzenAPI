-- Lua provided by RyzenAPI 
-- Game: AppID 1373300
addappid(1373300)
addappid(1373301, 1, "52671b9aa571075d1f34574a7148ac0b84f1407e63afa9a1fc9c2e1302b34f39")
