-- Lua provided by RyzenAPI
-- Game: Game: AppID 641590

-- MAIN APPLICATION
addappid(641590)
-- Game: addappid(641590)

-- MAIN APP DEPOTS / PACKAGES
addappid(641591, 1, "f4788f93b43cc6755cebe969629dd208b5a0882ef4ae516fc33b8625f57d76bb")
