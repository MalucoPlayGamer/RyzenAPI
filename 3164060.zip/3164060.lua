-- Lua provided by RyzenAPI 
-- Game: 莎可莉与坠落之都
addappid(3164060)
addappid(3164061, 1, "d45b7885d06ed23508fd631804631dd8412cd6b17a41e9c7e1148ab2fd9e1376")
