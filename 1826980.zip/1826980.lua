-- Lua provided by RyzenAPI
-- Game: FreestyleFootball R

-- MAIN APPLICATION
addappid(1826980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826981, 1, "a671259d25610c370b20709bafa39defa2f0d63a7d8d4f2e7d3b7e44e6cb63ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
