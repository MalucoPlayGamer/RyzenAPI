-- Lua provided by RyzenAPI
-- Game: FreestyleFootball R

-- MAIN APPLICATION
addappid(1826980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826981, 1, "a671259d25610c370b20709bafa39defa2f0d63a7d8d4f2e7d3b7e44e6cb63ea")
