-- 5032810's Lua and Manifest Created by Hubcap Manifest
-- Cozy Home Designer
-- Created: August 20, 2026 at 06:18:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5032810) -- Cozy Home Designer
-- MAIN APP DEPOTS
addappid(5032811, 1, "41efe8b732d4cbf12c50988311ca1593f89e3e259ccbb168ca5401e987c5a707") -- Depot 5032811
setManifestid(5032811, "4744912339705262955", 1472545640)
addappid(5032812, 1, "f9e9a8a380119007161fcb044e3bfb8a90d72dd7a9102125ff228a3cb69383a4") -- Depot 5032812
setManifestid(5032812, "5652672779179082283", 1436850848)