-- Lua provided by RyzenAPI
-- Game: Cozy Home Designer

-- MAIN APPLICATION
addappid(5032810) -- Cozy Home Designer

-- MAIN APP DEPOTS / PACKAGES
addappid(5032811, 1, "41efe8b732d4cbf12c50988311ca1593f89e3e259ccbb168ca5401e987c5a707") -- Depot 5032811
addappid(5032812, 1, "f9e9a8a380119007161fcb044e3bfb8a90d72dd7a9102125ff228a3cb69383a4") -- Depot 5032812

