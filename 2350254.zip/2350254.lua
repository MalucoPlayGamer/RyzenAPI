-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! At The Disco - "Sugar Soaker"

-- MAIN APPLICATION
addappid(2350254)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350254,0,"0561c5c0decd13d82e987206c35bdc26257b1d2ef8837fd818ae7bf79209a74b")
