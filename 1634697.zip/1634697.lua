-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Horse "Ghost"

-- MAIN APPLICATION
addappid(1634697)
-- Game: addappid(1634697)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634697,0,"507dc55f1ea1bf948e0535d25409479484adabb7e523b577b4b13bf48b786289")
