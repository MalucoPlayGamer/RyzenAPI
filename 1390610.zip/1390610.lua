-- Lua provided by RyzenAPI
-- Game: Game: Drone Swarm - Soundtrack

-- MAIN APPLICATION
addappid(1390610)
-- Game: addappid(1390610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390611, 1, "2a4eeb70766c11d696dacdf02d5b9c32ec18a0489d2a3d070604d47c08a90bf5")
