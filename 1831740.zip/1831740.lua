-- Lua provided by RyzenAPI
-- Game: December 24th

-- MAIN APPLICATION
addappid(1831740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1831741, 1, "7536cd4bf0c0916892670a9a72b7268ad38a95454189bf97fc00b939eee07858")
addappid(1831742, 1, "ec53dfc7b4df4a708cee9916145fbfdb3c56e44ae926e6fa13020b5a3165eca6")

