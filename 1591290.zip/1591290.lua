-- Lua provided by RyzenAPI
-- Game: Tree Simulator 2022

-- MAIN APPLICATION
addappid(1591290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591291, 1, "d95d78afe39334be73fcb9bdd5ed214b92c18131d7457c6aa88ddb94d2512aa0")
