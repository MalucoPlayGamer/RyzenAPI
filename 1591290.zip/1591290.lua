-- Lua provided by SkyAPI 
-- Game: Tree Simulator 2022
addappid(1591290)
addappid(1591291, 1, "d95d78afe39334be73fcb9bdd5ed214b92c18131d7457c6aa88ddb94d2512aa0")
