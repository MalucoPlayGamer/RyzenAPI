-- Lua provided by RyzenAPI
-- Game: Noctropolis

-- MAIN APPLICATION
addappid(377070)

-- MAIN APP DEPOTS / PACKAGES
addappid(377071, 1, "5d57c02e929c45889dbf728dbe75adea4b8fea88c057a1945c28fa72c16afb3a")
addappid(377072, 1, "e591ab00f47ecadb5a35c6ef6bee2acbd41a8718f15598eb8fc0e6e7df0e62e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
