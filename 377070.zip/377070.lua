-- Lua provided by RyzenAPI
-- Game: Noctropolis

-- MAIN APPLICATION
addappid(377070)

-- MAIN APP DEPOTS / PACKAGES
addappid(377071, 1, "5d57c02e929c45889dbf728dbe75adea4b8fea88c057a1945c28fa72c16afb3a")
addappid(377072, 1, "e591ab00f47ecadb5a35c6ef6bee2acbd41a8718f15598eb8fc0e6e7df0e62e7")
