-- Lua provided by RyzenAPI
-- Game: Wetory

-- MAIN APPLICATION
addappid(2054220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054221, 1, "53c968ee0aca6850fa202b5efd26ebaad8422f785dcf624e84d7c89afb7d0062")
