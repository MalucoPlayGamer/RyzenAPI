-- Lua provided by RyzenAPI
-- Game: Game: 江湖百异图

-- MAIN APPLICATION
addappid(2015860)
-- Game: addappid(2015860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015861, 1, "5bfd6e18f1263c1fe8ca10179af2cdc6405f57bb94200f28ea433ef8dd3d7cc6")
