-- Lua provided by RyzenAPI
-- Game: AppID 388440

-- MAIN APPLICATION
addappid(388440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(388441, 1, "7d28d226693b76a5095c84fce8aefce06a9024d3c98b0c615d62db4c63d0d95a")
addappid(388442, 1, "d85fae110c09f0152392bf9091711410425e9cf1ba88fe1e7b5dcc5394fb4e8a")
addappid(388443, 1, "0363bce76e24ffe1dd90b472021193f679417aeddce3ca1dcd8c82559e4dd7cb")
addappid(439710, 0, "128fe6136724cdc0e4e2005826697a4dbd47912884b43e4de65ca035f1bb0138")

