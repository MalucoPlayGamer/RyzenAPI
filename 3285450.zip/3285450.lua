-- Lua provided by RyzenAPI
-- Game: 3285450

-- MAIN APPLICATION
addappid(3285450)
-- Game: addappid(3285450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285451, 1, "9274005a4e9e88596e949f5c677ed7c3932626a4d813ca3f63cfdf7bbcd6801f")
