-- Lua provided by RyzenAPI
-- Game: Game: Scuffy Game

-- MAIN APPLICATION
addappid(1893800)
-- Game: addappid(1893800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893801, 1, "d5b3ee26405888362d87950ab3016d34d1aeeafb21a1d5d1d2bfabf8798d56bd")
