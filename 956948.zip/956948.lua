-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956948)
-- Game: addappid(956948)

-- MAIN APP DEPOTS / PACKAGES
addappid(956948,0,"c20d3a5d08dcbfd20dd9a3ff7496fbe8b2acc753a8b10017edac36ad6e31cbaa")
