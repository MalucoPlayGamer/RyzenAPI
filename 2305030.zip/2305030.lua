-- Lua provided by RyzenAPI
-- Game: 2305030

-- MAIN APPLICATION
addappid(2305030)
-- Game: addappid(2305030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305031, 1, "b4d06a3e9fb994879bece1fd425083bcd00bb7e31f30fb0573aef16ffe1e2738")
