-- Lua provided by RyzenAPI
-- Game: Game: ENF Novels: Dress Code

-- MAIN APPLICATION
addappid(1732760)
-- Game: addappid(1732760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732761, 1, "55f7cbae5e3cbe351a94cdf8ae7c5ac44b9833cb0729232d76e89148a696687a")
