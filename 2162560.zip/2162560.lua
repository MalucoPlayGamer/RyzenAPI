-- Lua provided by RyzenAPI
-- Game: AppID 2162560

-- MAIN APPLICATION
addappid(2162560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162561, 1, "b4b751db38e266de87267e7f4d3a71d3ce78dcbe6e8ee30c72d7fb416479135c")

