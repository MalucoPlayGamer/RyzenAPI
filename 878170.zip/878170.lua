-- Lua provided by RyzenAPI
-- Game: AppID 878170

-- MAIN APPLICATION
addappid(878170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(878171, 1, "ca9851230de5721e51ec3c8dedb27066656197bb84c15127ba1ada6891a5a5ac")

