-- Lua provided by RyzenAPI
-- Game: AppID 878170

-- MAIN APPLICATION
addappid(878170)
-- Game: addappid(878170)

-- MAIN APP DEPOTS / PACKAGES
addappid(878171, 1, "ca9851230de5721e51ec3c8dedb27066656197bb84c15127ba1ada6891a5a5ac")
