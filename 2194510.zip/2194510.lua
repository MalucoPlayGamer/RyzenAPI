-- Lua provided by RyzenAPI
-- Game: Retired Hero Gets Slaves

-- MAIN APPLICATION
addappid(2194510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194511, 1, "9578838ba730b7b6c9262d42830f994ad552b7c18eb3c10b399d62f5ff2da053")

