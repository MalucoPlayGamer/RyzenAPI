-- Lua provided by RyzenAPI
-- Game: Dice Gambit: The First Act

-- MAIN APPLICATION
addappid(2753240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753241, 1, "31d89df822d4f868f54029762b1ff14592438ddcdc79020385aad5e7205541f0")

