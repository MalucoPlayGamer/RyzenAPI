-- Lua provided by RyzenAPI
-- Game: DERE. Some Answers Before I...

-- MAIN APPLICATION
addappid(2478310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478311, 1, "23eff3a477f0260a32571008f915be750059944637170a514c716ea8eb1e2a65")

