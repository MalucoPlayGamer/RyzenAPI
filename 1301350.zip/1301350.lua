-- Lua provided by RyzenAPI 
-- Game: AppID 1301350
addappid(1301350)
addappid(1301351, 1, "84cae062e52683bb3c3117f162c1ea0fdf4babd4ecba77c5c0044bdca9b587dd")
