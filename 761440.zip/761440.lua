-- Lua provided by RyzenAPI
-- Game: Game: Santa Run

-- MAIN APPLICATION
addappid(761440)
-- Game: addappid(761440)

-- MAIN APP DEPOTS / PACKAGES
addappid(761441, 1, "796e7043d3fca0e8f77b64a4f5fe0cab94a9e7ba72acc153f75500403b9db5be")
