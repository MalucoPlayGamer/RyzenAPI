-- Lua provided by RyzenAPI
-- Game: Game: AppID 2990730

-- MAIN APPLICATION
addappid(2990730)
-- Game: addappid(2990730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990731, 1, "cfa2c04589f0ed6dd7bf302444e2405e3b3ef0957a64e902f8400d67b5b96f43")
