-- 3417140's Lua and Manifest Created by Hubcap Manifest
-- IGS Classic Arcade Collection
-- Created: August 13, 2026 at 08:31:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3417140) -- IGS Classic Arcade Collection
-- MAIN APP DEPOTS
addappid(3417141, 1, "c7982f465deda40d2c4214a59d4ae91b352282a4a0d2e36c33e290e1927fbf3d") -- Depot 3417141
setManifestid(3417141, "1311589205166656429", 1192188813)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)