-- Lua provided by RyzenAPI
-- Game: IGS Classic Arcade Collection

-- MAIN APPLICATION
addappid(3417140) -- IGS Classic Arcade Collection

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(3417141, 1, "c7982f465deda40d2c4214a59d4ae91b352282a4a0d2e36c33e290e1927fbf3d") -- Depot 3417141

