-- Lua provided by RyzenAPI
-- Game: 2589200

-- MAIN APPLICATION
addappid(2589200)
-- Game: addappid(2589200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589201, 1, "72ad8979736e497c2e5d565ec3a7c262ee8ae15704ae9abecaf4378fcdadde2f")
