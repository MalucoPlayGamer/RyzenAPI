-- Lua provided by RyzenAPI
-- Game: Budget Backrooms

-- MAIN APPLICATION
addappid(2589200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2589201, 1, "72ad8979736e497c2e5d565ec3a7c262ee8ae15704ae9abecaf4378fcdadde2f")

