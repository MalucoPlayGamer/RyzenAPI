-- Lua provided by RyzenAPI 
-- Game: AppID 891180
addappid(891180)
addappid(891181, 1, "bee50308d0ae6eeebe5a08233951a6378ab31962fdc3f1435790016a14f128ed")
