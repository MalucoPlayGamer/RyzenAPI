-- Lua provided by RyzenAPI
-- Game: AppID 2561110

-- MAIN APPLICATION
addappid(2561110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561111, 1, "0f67ee8a0f4cf41cc15413628c6c4e2c7c3a53fdbad1afcac80ad0ecb070de0c")
