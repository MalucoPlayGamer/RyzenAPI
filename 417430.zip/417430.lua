-- Lua provided by RyzenAPI
-- Game: Moto Racer  4

-- MAIN APPLICATION
addappid(417430)
addappid(465290)
addappid(465291)
addappid(465292)
addappid(510940)
addappid(573820)
addappid(573821)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(417431, 1, "c939b14190d443b3e0324a106b59d3a9bc805c73502759f557df6a40e1cf80ab")
addappid(417432, 1, "97f4d47d7c0f3b7ffa8d07928f843b9d2b472f753a5e089d1f679bcac0c3d7b1")

