-- Lua provided by RyzenAPI
-- Game: AppID 417430

-- MAIN APPLICATION
addappid(417430)
-- Game: addappid(417430)

-- MAIN APP DEPOTS / PACKAGES
addappid(417431, 1, "c939b14190d443b3e0324a106b59d3a9bc805c73502759f557df6a40e1cf80ab")
addappid(417432, 1, "97f4d47d7c0f3b7ffa8d07928f843b9d2b472f753a5e089d1f679bcac0c3d7b1")
