-- Lua provided by RyzenAPI
-- Game: Game: Maitetsu

-- MAIN APPLICATION
addappid(714800)
-- Game: addappid(714800)

-- MAIN APP DEPOTS / PACKAGES
addappid(714801, 1, "cff4d3c85757cf01b9873d84e0d5fb383447102fbfb7f48e1b38e779f9792566")
