-- Lua provided by RyzenAPI
-- Game: Maitetsu

-- MAIN APPLICATION
addappid(714800)

-- MAIN APP DEPOTS / PACKAGES
addappid(714801, 1, "cff4d3c85757cf01b9873d84e0d5fb383447102fbfb7f48e1b38e779f9792566")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
