-- 4698960's Lua and Manifest Created by Hubcap Manifest
-- Hentai Police Girl
-- Created: August 17, 2026 at 14:42:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4698960) -- Hentai Police Girl
-- MAIN APP DEPOTS
addappid(4698961, 1, "cdc4e0c2a6d270fd3c7fd380336e0b1803f2ef7f00ef0f79092358b2e7956e3e") -- Depot 4698961
setManifestid(4698961, "8986880914523913813", 236767974)