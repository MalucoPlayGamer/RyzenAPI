-- Lua provided by RyzenAPI
-- Game: Hentai Police Girl

-- MAIN APPLICATION
addappid(4698960) -- Hentai Police Girl

-- MAIN APP DEPOTS / PACKAGES
addappid(4698961, 1, "cdc4e0c2a6d270fd3c7fd380336e0b1803f2ef7f00ef0f79092358b2e7956e3e") -- Depot 4698961

