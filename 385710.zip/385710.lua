-- Lua provided by RyzenAPI
-- Game: INK

-- MAIN APPLICATION
addappid(385710)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(385711, 1, "897c48d560ed60ef672ce5c050c0739361f701551d0bb71daad70bf1203a5a65")
addappid(385712, 1, "71556ad6dbb97f709ba60c832b00c137e83a0e77502e880bd8459b5f8dbfa433")
addappid(385713, 1, "6a448e87997f0251891cf6d83822566bcbe5c5047a6bb377d99c6b3477eb5a65")
addappid(392400, 0, "f5f1995bb4fc15f39a90bedfbd8bf606d637a2faf9a1570aeb5c994a96426301")

