-- Lua provided by RyzenAPI
-- Game: IN-VERT: Definitive Edition

-- MAIN APPLICATION
addappid(491010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(491011, 1, "ce21ff44dd5ec70574c70b196f6a37b89a3a2f6c6031ff4ffcb4b6644dcc1377")
addappid(491012, 1, "8556fd0106281b0911549db419cb984849571b3c3e58225932b29158ec1a1261")
addappid(495641, 0, "c0e2fea24ae729a8631633fa86a50d03a4186af64a4d07513feadf2d9110dce2")

