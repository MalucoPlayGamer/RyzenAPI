-- Lua provided by RyzenAPI
-- Game: Devil in my house

-- MAIN APPLICATION
addappid(3056480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3056481, 1, "92585bf56740e60d7370cbbcfdc75dd80fca45ee7be6381452e636ad9e757dc6")

