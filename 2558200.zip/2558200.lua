-- Lua provided by RyzenAPI 
-- Game: Call of Sentinels
addappid(2558200)
addappid(2558201, 1, "050834344443438fa34af968f8759dc14a4c18b1cc84452be19241716a91d653")
