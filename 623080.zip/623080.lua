-- Lua provided by RyzenAPI
-- Game: Game: planetarian HD

-- MAIN APPLICATION
addappid(623080)
-- Game: addappid(623080)

-- MAIN APP DEPOTS / PACKAGES
addappid(623081, 1, "f5885926b7ea18d76b263df68626df821f307a5a6e62bf80ac5e62605cce57dc")
addappid(623082, 1, "8c949c03410cd378b664276839a02bd1fcc477d492f068a84ff9fc1a483fdc6d")
addappid(623084, 1, "ffe83fe007d5f58c817914b2519653f71be1f545c9ebc6c50dd0f1a1b939d767")
addappid(623085, 1, "d51bcb269e62017cd2389d1495b1cb4e6506d4ed4f5c590deea6976ba561ab34")
addappid(623086, 1, "19a8e8d023f1542fe724f158740c80b07248d60e4b1679c0ec4e5e197ef582d5")
addappid(623087, 1, "ca3a392fd40a2c7ac3457e0c3a046c15d80773aaeedc87fc694c3c8e7ab7d4e8")
addappid(623088, 1, "19a56a0dbb1b9fd8b7a9d19b43bc249343a9c4e4d309d53fdbae5ecc318e45a8")
