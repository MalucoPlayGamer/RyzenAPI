-- Lua provided by RyzenAPI
-- Game: Zombie Parking

-- MAIN APPLICATION
addappid(449090)

-- MAIN APP DEPOTS / PACKAGES
addappid(449091, 1, "03d975c1a12fe0619d14eb797dfebe69a41a5cceffdcb03884b8bf70b2caff2a")
addappid(449092, 1, "80ff5abde5f5d117d3bfb5bff67acdcf6e2a7212065bc2084708cdc6e19bb031")
addappid(449093, 1, "3fd9d64d2d46801d3b1af0c2e5533604a684aa9185c54fdb55cb774da8d2bd39")
