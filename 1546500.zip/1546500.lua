-- Lua provided by RyzenAPI 
-- Game: Warplanes: WW1 Fighters
addappid(1546500)
addappid(1546501, 1, "a83dbc6a96e3ba99978c45fa00fa13a10a17062c75175074f4797bdba5649390")
