-- Lua provided by RyzenAPI
-- Game: addappid(1546500)

-- MAIN APPLICATION
addappid(1546500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546501, 1, "a83dbc6a96e3ba99978c45fa00fa13a10a17062c75175074f4797bdba5649390")
