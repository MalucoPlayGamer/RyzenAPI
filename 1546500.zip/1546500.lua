-- Lua provided by RyzenAPI
-- Game: Warplanes: WW1 Fighters

-- MAIN APPLICATION
addappid(1546500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1546501, 1, "a83dbc6a96e3ba99978c45fa00fa13a10a17062c75175074f4797bdba5649390")

