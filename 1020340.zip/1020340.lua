-- Lua provided by RyzenAPI
-- Game: AUDICA: Rhythm Shooter

-- MAIN APPLICATION
addappid(1183190)
addappid(1184650)
addappid(1184651)
addappid(1184660)
addappid(1184661)
addappid(1190210) -- AUDICA 2019 Season Pass
addappid(1194850)
addappid(1194851)
addappid(1194852)
addappid(1194853)
addappid(1194854)
addappid(1194855)
addappid(1194856)
addappid(1194857)
addappid(1194858)
addappid(1194859)
addappid(1215460)
addappid(1215461)
addappid(1215462)
addappid(1215463)
addappid(1221850)
addappid(1221851)
addappid(1221852)
addappid(1221853)
addappid(1240300)
addappid(1240301)
addappid(1249320)
addappid(1262300)
addappid(1262302)
addappid(1262303)
addappid(1262304)
addappid(1341530)
addappid(1341531)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020340, 1, "cfa5602664d9b113711ce70785d60b8f3b14351a8c884ce60029bf9af9860412") -- AUDICA: Rhythm Shooter
addappid(1020341, 1, "908406dfe7e3afb89cc412b9966987a09fb36c4969145921b20abaf829b240ae") -- Audica Content
addappid(1183190, 1, "c9f45c7dacdf2787bd68980e267ad0be837f7412eaa724412f49bd56fa86782c") -- AUDICA - 5 Seconds of Summer - Youngblood - Audica - Youngblood DLC Depot
addappid(1184650, 1, "f9a826234d6beca11e8ce2c2a6ca3ce01ec634b2ceb3c780555400bfa18a4035") -- AUDICA - Ariana Grande - Into You - Audica - Ariana Grande - &quot;Into You&quot; Depot
addappid(1184651, 1, "f9dcb1a82cf594a34e29f114a434fd7eb2eee761d43d97f3f32829738e1eb165") -- AUDICA - Billie Eilish - bad guy - Audica - Billie Eilish - &quot;bad guy&quot; Depot
addappid(1184660, 1, "724d334b67e2b32e726ce482308a0ea86ba54ea1c6aebb6e21c74d48bd7f7ffb") -- AUDICA - Imagine Dragons - Believer - Audica - Imagine Dragons - &quot;Believer&quot; Depot
addappid(1184661, 1, "9900504e0327840622655c73508234c55cdbdd4408fee9ecc6fe3d49298d22d7") -- AUDICA - Post Malone - Better Now - Audica - Post Malone - &quot;Better Now&quot; Depot
addappid(1194850, 1, "5e401589a285ead2a04d300a34bc307d909c380bbacea08845708bb182387a3e") -- AUDICA - Fall Out Boy - Centuries - AUDICA - Fall Out Boy - &quot;Centuries&quot; Depot
addappid(1194851, 1, "86864f75f97477a90aa2ca44ab558449515c2d940b830b0d733bd87cc92b98df") -- AUDICA - LMFAO - Sorry For Party Rocking - AUDICA - LMFAO - &quot;Sorry For Party Rocking&quot; Depot
addappid(1194852, 1, "17f41efee6777bf0496b5473fac8755429d0e02d9b72465fce8c76cefe77cf07") -- AUDICA - Maroon 5 ft. Christina Aguilera - Moves Like Jagger - AUDICA - Maroon 5 ft. Christina Aguilera - &quot;Moves Like Jagger&quot; Depot
addappid(1194853, 1, "976d107fb4bb6613ccbc1d8728cf94070a292b1dd864e409842e53781d352175") -- AUDICA - OneRepublic - Counting Stars - AUDICA - OneRepublic - &quot;Counting Stars&quot; Depot
addappid(1194854, 1, "f619443fff70374a8789db5e701fc31dbf513d746d807622e19b8003318001b3") -- AUDICA - Panic At The Disco - High Hopes - AUDICA - Panic! At The Disco - &quot;High Hopes&quot; Depot
addappid(1194855, 1, "c9058bfbad169bf3abf23be4e49e55c6266cb4206fcf2619b6c006d580af3da2") -- AUDICA - The Chainsmokers ft. Daya - Dont Let Me Down - AUDICA - The Chainsmokers ft. Daya - &quot;Don't Let Me Down&quot; Depot
addappid(1194856, 1, "c6d391e47292088193ff83503c656b79cf76149088958b80564024bed2740ea3") -- AUDICA - Dua Lipa - New Rules - AUDICA - Dua Lipa - &quot;New Rules&quot; Depot
addappid(1194857, 1, "b1c5dea6efd0352259c360239a202b1f8768b55d97a857c32bd236849c315d0f") -- AUDICA - Nicki Minaj - Starships - AUDICA - Nicki Minaj - &quot;Starships&quot; Depot
addappid(1194858, 1, "43beb48b39d6aa2c3078e700d6557f0f82bca558b4c6c1d0abca45546019bba6") -- AUDICA - Sia ft. Kendrick Lamar - The Greatest - AUDICA - Sia ft. Kendrick Lamar - &quot;The Greatest&quot; Depot
addappid(1194859, 1, "5244e605453fe1f32a592a72bbacbadf0373bb85ba9dc6d157da45918cb783a5") -- AUDICA - Zedd, Maren Morris  Grey - The Middle - AUDICA - Zedd, Maren Morris &amp; Grey - &quot;The Middle&quot; Depot
addappid(1215460, 1, "c7a497669c5fe492a18770f166fb0a0a142470ec0e47cda21a9a3d10fe83a230") -- AUDICA - CHVRCHES - The Mother We Share - AUDICA - CHVRCHES - &quot;The Mother We Share&quot; Depot
addappid(1215461, 1, "810ad6c03c0a8cdfe25befc57a9070dfdc095fb0b8b1ac87cf9d4b7a8529bfaf") -- AUDICA - Lizzo - Juice - AUDICA - Lizzo - &quot;Juice&quot; Depot
addappid(1215462, 1, "e632de0439c9503de7498cc828434c020c88841e25a72a19e459be752a51ca60") -- AUDICA - Flo Rida ft. Sage The Gemini and Lookas - GDFR - AUDICA - Flo Rida ft. Sage The Gemini and Lookas - &quot;GDFR&quot; Depot
addappid(1215463, 1, "4bdab76dc9608ec4c19cfb87505cfe9f462cd02f190e436f67d76ca469636f05") -- AUDICA - The Weeknd - Cant Feel My Face - AUDICA - The Weeknd - &quot;Can't Feel My Face&quot; Depot
addappid(1221850, 1, "465595f7eb366c77bf5f4b366de1c5f6a7296725230dd4499091499e5b323c70") -- AUDICA - Darren Korb ft. Ashley Barrett - We All Become - AUDICA - Darren Korb ft. Ashley Barrett - &quot;We All Become&quot; Depot
addappid(1221851, 1, "4d6d77aac1e20af3823452886833fdfb9bf457223342d3fa5978b78c45857215") -- AUDICA - James Landino - Funky Computer - AUDICA - James Landino - &quot;Funky Computer&quot; Depot
addappid(1221852, 1, "6ef8af5f6109dfa7f681cede4b9111e4ada39f06c8c76a749b39cba92f429a66") -- AUDICA - James Egbert ft. Nina Sung - Exit Wounds - AUDICA - James Egbert ft. Nina Sung - &quot;Exit Wounds&quot; Depot
addappid(1221853, 1, "90e436e263f9e11bfff2fb29a0359ecc12472c6fee2eb06155f2661c447165fa") -- AUDICA - asms - Reeds of Mitatrush - AUDICA - asms - &quot;Reeds of Mitatrush&quot; Depot
addappid(1240300, 1, "039b0fbf37c92d42276708c6310feca0d10e9b197a1eca76b2e4f37d3cbf27a3") -- AUDICA - M-Cue - U R Prey - default
addappid(1240301, 1, "8cb6a0990f09c8df81431e571c586099133fb93c7c09785413646b63c15698e2") -- AUDICA - asms - Methane Breather - default
addappid(1249320, 1, "d0e2df0b8533c94a988e1547e01b0688671f6cef5c8670e76d90dfa0561e0911") -- AUDICA - Simaniac - Stook (Audica Mix) - default
addappid(1262300, 1, "9595047f09775de350288469385a90bc7dcf69c1f1c5e13999ca5eaf2c410a53") -- AUDICA - Sleeping Lion  Cass Miller ft. Bugle Bot - How We Know (Bugle Bot Remix) - default
addappid(1262302, 1, "f80e47c042cbb3f9ed8045a8cf9b41cbfe92f755bb2afa9998316574f3e4d0db") -- AUDICA - Bex - Avalanche - default
addappid(1262303, 1, "5618ac0a92fb780d5122561f9e808091dfe183300ecb303070062cc63e199a83") -- AUDICA - Party Bois - Girls Be Dancing  - default
addappid(1262304, 1, "2f295ccfad30ace04159d4232c58962efccb2c7eb6c37373db2afccc4f94c4fc") -- AUDICA - Hausman  Jenni Rudolph ft. Lys - Long Run - default
addappid(1341530, 1, "7592fd3dbea283372e34a364ac37fefdca161c07425c0347085a8d0c782324cb") -- AUDICA - Radio Compass - All Stars - default
addappid(1341531, 1, "fdcc86c14d24619f24cff8bfba8ae84f57a357e4395e1a61d9e066664ba2a894") -- AUDICA - I Was Awake - Pre-Existing Condition - default

