-- Lua provided by RyzenAPI
-- Game: AUDICA: Rhythm Shooter

-- MAIN APPLICATION
addappid(1020340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020341, 1, "908406dfe7e3afb89cc412b9966987a09fb36c4969145921b20abaf829b240ae")
