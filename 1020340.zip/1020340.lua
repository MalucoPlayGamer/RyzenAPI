-- 1020340's Lua and Manifest Created by Hubcap Manifest
-- AUDICA: Rhythm Shooter
-- Created: March 16, 2026 at 13:48:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 33
-- Total DLCs: 33

-- MAIN APPLICATION
addappid(1020340, 1, "cfa5602664d9b113711ce70785d60b8f3b14351a8c884ce60029bf9af9860412") -- AUDICA: Rhythm Shooter
-- MAIN APP DEPOTS
addappid(1020341, 1, "908406dfe7e3afb89cc412b9966987a09fb36c4969145921b20abaf829b240ae") -- Audica Content
setManifestid(1020341, "7201530906446969035", 933647183)
-- DLCS WITH DEDICATED DEPOTS
-- AUDICA - 5 Seconds of Summer - Youngblood (AppID: 1183190)
addappid(1183190)
addappid(1183190, 1, "c9f45c7dacdf2787bd68980e267ad0be837f7412eaa724412f49bd56fa86782c") -- AUDICA - 5 Seconds of Summer - Youngblood - Audica - Youngblood DLC Depot
setManifestid(1183190, "3355213476554212716", 11169886)
-- AUDICA - Ariana Grande - Into You (AppID: 1184650)
addappid(1184650)
addappid(1184650, 1, "f9a826234d6beca11e8ce2c2a6ca3ce01ec634b2ceb3c780555400bfa18a4035") -- AUDICA - Ariana Grande - Into You - Audica - Ariana Grande - &quot;Into You&quot; Depot
setManifestid(1184650, "8246091463677038172", 9254094)
-- AUDICA - Billie Eilish - bad guy (AppID: 1184651)
addappid(1184651)
addappid(1184651, 1, "f9dcb1a82cf594a34e29f114a434fd7eb2eee761d43d97f3f32829738e1eb165") -- AUDICA - Billie Eilish - bad guy - Audica - Billie Eilish - &quot;bad guy&quot; Depot
setManifestid(1184651, "9209503794621131696", 10301196)
-- AUDICA - Imagine Dragons - Believer (AppID: 1184660)
addappid(1184660)
addappid(1184660, 1, "724d334b67e2b32e726ce482308a0ea86ba54ea1c6aebb6e21c74d48bd7f7ffb") -- AUDICA - Imagine Dragons - Believer - Audica - Imagine Dragons - &quot;Believer&quot; Depot
setManifestid(1184660, "4612245579814222845", 7852213)
-- AUDICA - Post Malone - Better Now (AppID: 1184661)
addappid(1184661)
addappid(1184661, 1, "9900504e0327840622655c73508234c55cdbdd4408fee9ecc6fe3d49298d22d7") -- AUDICA - Post Malone - Better Now - Audica - Post Malone - &quot;Better Now&quot; Depot
setManifestid(1184661, "1618397452323693144", 8667257)
-- AUDICA - Fall Out Boy - Centuries (AppID: 1194850)
addappid(1194850)
addappid(1194850, 1, "5e401589a285ead2a04d300a34bc307d909c380bbacea08845708bb182387a3e") -- AUDICA - Fall Out Boy - Centuries - AUDICA - Fall Out Boy - &quot;Centuries&quot; Depot
setManifestid(1194850, "1897065724729020836", 8838234)
-- AUDICA - LMFAO - Sorry For Party Rocking (AppID: 1194851)
addappid(1194851)
addappid(1194851, 1, "86864f75f97477a90aa2ca44ab558449515c2d940b830b0d733bd87cc92b98df") -- AUDICA - LMFAO - Sorry For Party Rocking - AUDICA - LMFAO - &quot;Sorry For Party Rocking&quot; Depot
setManifestid(1194851, "4156725524399145339", 10920918)
-- AUDICA - Maroon 5 ft. Christina Aguilera - Moves Like Jagger (AppID: 1194852)
addappid(1194852)
addappid(1194852, 1, "17f41efee6777bf0496b5473fac8755429d0e02d9b72465fce8c76cefe77cf07") -- AUDICA - Maroon 5 ft. Christina Aguilera - Moves Like Jagger - AUDICA - Maroon 5 ft. Christina Aguilera - &quot;Moves Like Jagger&quot; Depot
setManifestid(1194852, "2550800140026100552", 7275240)
-- AUDICA - OneRepublic - Counting Stars (AppID: 1194853)
addappid(1194853)
addappid(1194853, 1, "976d107fb4bb6613ccbc1d8728cf94070a292b1dd864e409842e53781d352175") -- AUDICA - OneRepublic - Counting Stars - AUDICA - OneRepublic - &quot;Counting Stars&quot; Depot
setManifestid(1194853, "7418951193093634007", 9511526)
-- AUDICA - Panic At The Disco - High Hopes (AppID: 1194854)
addappid(1194854)
addappid(1194854, 1, "f619443fff70374a8789db5e701fc31dbf513d746d807622e19b8003318001b3") -- AUDICA - Panic At The Disco - High Hopes - AUDICA - Panic! At The Disco - &quot;High Hopes&quot; Depot
setManifestid(1194854, "8436016907589275227", 9966225)
-- AUDICA - The Chainsmokers ft. Daya - Dont Let Me Down (AppID: 1194855)
addappid(1194855)
addappid(1194855, 1, "c9058bfbad169bf3abf23be4e49e55c6266cb4206fcf2619b6c006d580af3da2") -- AUDICA - The Chainsmokers ft. Daya - Dont Let Me Down - AUDICA - The Chainsmokers ft. Daya - &quot;Don't Let Me Down&quot; Depot
setManifestid(1194855, "5803598293347092429", 8079924)
-- AUDICA - Dua Lipa - New Rules (AppID: 1194856)
addappid(1194856)
addappid(1194856, 1, "c6d391e47292088193ff83503c656b79cf76149088958b80564024bed2740ea3") -- AUDICA - Dua Lipa - New Rules - AUDICA - Dua Lipa - &quot;New Rules&quot; Depot
setManifestid(1194856, "3594406176896480918", 7577190)
-- AUDICA - Nicki Minaj - Starships (AppID: 1194857)
addappid(1194857)
addappid(1194857, 1, "b1c5dea6efd0352259c360239a202b1f8768b55d97a857c32bd236849c315d0f") -- AUDICA - Nicki Minaj - Starships - AUDICA - Nicki Minaj - &quot;Starships&quot; Depot
setManifestid(1194857, "5067933839343334863", 7156512)
-- AUDICA - Sia ft. Kendrick Lamar - The Greatest (AppID: 1194858)
addappid(1194858)
addappid(1194858, 1, "43beb48b39d6aa2c3078e700d6557f0f82bca558b4c6c1d0abca45546019bba6") -- AUDICA - Sia ft. Kendrick Lamar - The Greatest - AUDICA - Sia ft. Kendrick Lamar - &quot;The Greatest&quot; Depot
setManifestid(1194858, "2116881714829392990", 7785355)
-- AUDICA - Zedd, Maren Morris  Grey - The Middle (AppID: 1194859)
addappid(1194859)
addappid(1194859, 1, "5244e605453fe1f32a592a72bbacbadf0373bb85ba9dc6d157da45918cb783a5") -- AUDICA - Zedd, Maren Morris  Grey - The Middle - AUDICA - Zedd, Maren Morris &amp; Grey - &quot;The Middle&quot; Depot
setManifestid(1194859, "7575060114588481057", 7123519)
-- AUDICA - CHVRCHES - The Mother We Share (AppID: 1215460)
addappid(1215460)
addappid(1215460, 1, "c7a497669c5fe492a18770f166fb0a0a142470ec0e47cda21a9a3d10fe83a230") -- AUDICA - CHVRCHES - The Mother We Share - AUDICA - CHVRCHES - &quot;The Mother We Share&quot; Depot
setManifestid(1215460, "7242768452014386175", 9291284)
-- AUDICA - Lizzo - Juice (AppID: 1215461)
addappid(1215461)
addappid(1215461, 1, "810ad6c03c0a8cdfe25befc57a9070dfdc095fb0b8b1ac87cf9d4b7a8529bfaf") -- AUDICA - Lizzo - Juice - AUDICA - Lizzo - &quot;Juice&quot; Depot
setManifestid(1215461, "6669546805831059124", 6311950)
-- AUDICA - Flo Rida ft. Sage The Gemini and Lookas - GDFR (AppID: 1215462)
addappid(1215462)
addappid(1215462, 1, "e632de0439c9503de7498cc828434c020c88841e25a72a19e459be752a51ca60") -- AUDICA - Flo Rida ft. Sage The Gemini and Lookas - GDFR - AUDICA - Flo Rida ft. Sage The Gemini and Lookas - &quot;GDFR&quot; Depot
setManifestid(1215462, "3238438666307977701", 7600855)
-- AUDICA - The Weeknd - Cant Feel My Face (AppID: 1215463)
addappid(1215463)
addappid(1215463, 1, "4bdab76dc9608ec4c19cfb87505cfe9f462cd02f190e436f67d76ca469636f05") -- AUDICA - The Weeknd - Cant Feel My Face - AUDICA - The Weeknd - &quot;Can't Feel My Face&quot; Depot
setManifestid(1215463, "597454444863579154", 6735057)
-- AUDICA - Darren Korb ft. Ashley Barrett - We All Become (AppID: 1221850)
addappid(1221850)
addappid(1221850, 1, "465595f7eb366c77bf5f4b366de1c5f6a7296725230dd4499091499e5b323c70") -- AUDICA - Darren Korb ft. Ashley Barrett - We All Become - AUDICA - Darren Korb ft. Ashley Barrett - &quot;We All Become&quot; Depot
setManifestid(1221850, "2579048640404752876", 8041467)
-- AUDICA - James Landino - Funky Computer (AppID: 1221851)
addappid(1221851)
addappid(1221851, 1, "4d6d77aac1e20af3823452886833fdfb9bf457223342d3fa5978b78c45857215") -- AUDICA - James Landino - Funky Computer - AUDICA - James Landino - &quot;Funky Computer&quot; Depot
setManifestid(1221851, "2469141623988522055", 7226069)
-- AUDICA - James Egbert ft. Nina Sung - Exit Wounds (AppID: 1221852)
addappid(1221852)
addappid(1221852, 1, "6ef8af5f6109dfa7f681cede4b9111e4ada39f06c8c76a749b39cba92f429a66") -- AUDICA - James Egbert ft. Nina Sung - Exit Wounds - AUDICA - James Egbert ft. Nina Sung - &quot;Exit Wounds&quot; Depot
setManifestid(1221852, "2748045280779363444", 10462761)
-- AUDICA - asms - Reeds of Mitatrush (AppID: 1221853)
addappid(1221853)
addappid(1221853, 1, "90e436e263f9e11bfff2fb29a0359ecc12472c6fee2eb06155f2661c447165fa") -- AUDICA - asms - Reeds of Mitatrush - AUDICA - asms - &quot;Reeds of Mitatrush&quot; Depot
setManifestid(1221853, "7416853071337738407", 8571843)
-- AUDICA - M-Cue - U R Prey (AppID: 1240300)
addappid(1240300)
addappid(1240300, 1, "039b0fbf37c92d42276708c6310feca0d10e9b197a1eca76b2e4f37d3cbf27a3") -- AUDICA - M-Cue - U R Prey - default
setManifestid(1240300, "2921822506181924140", 7880614)
-- AUDICA - asms - Methane Breather (AppID: 1240301)
addappid(1240301)
addappid(1240301, 1, "8cb6a0990f09c8df81431e571c586099133fb93c7c09785413646b63c15698e2") -- AUDICA - asms - Methane Breather - default
setManifestid(1240301, "1553914960470601311", 7970371)
-- AUDICA - Simaniac - Stook (Audica Mix) (AppID: 1249320)
addappid(1249320)
addappid(1249320, 1, "d0e2df0b8533c94a988e1547e01b0688671f6cef5c8670e76d90dfa0561e0911") -- AUDICA - Simaniac - Stook (Audica Mix) - default
setManifestid(1249320, "8521835949051048688", 9649012)
-- AUDICA - Sleeping Lion  Cass Miller ft. Bugle Bot - How We Know (Bugle Bot Remix) (AppID: 1262300)
addappid(1262300)
addappid(1262300, 1, "9595047f09775de350288469385a90bc7dcf69c1f1c5e13999ca5eaf2c410a53") -- AUDICA - Sleeping Lion  Cass Miller ft. Bugle Bot - How We Know (Bugle Bot Remix) - default
setManifestid(1262300, "2888197899801700137", 6918708)
-- AUDICA - Bex - Avalanche (AppID: 1262302)
addappid(1262302)
addappid(1262302, 1, "f80e47c042cbb3f9ed8045a8cf9b41cbfe92f755bb2afa9998316574f3e4d0db") -- AUDICA - Bex - Avalanche - default
setManifestid(1262302, "5551909803637662946", 9832587)
-- AUDICA - Party Bois - Girls Be Dancing  (AppID: 1262303)
addappid(1262303)
addappid(1262303, 1, "5618ac0a92fb780d5122561f9e808091dfe183300ecb303070062cc63e199a83") -- AUDICA - Party Bois - Girls Be Dancing  - default
setManifestid(1262303, "5563120243084638966", 9281900)
-- AUDICA - Hausman  Jenni Rudolph ft. Lys - Long Run (AppID: 1262304)
addappid(1262304)
addappid(1262304, 1, "2f295ccfad30ace04159d4232c58962efccb2c7eb6c37373db2afccc4f94c4fc") -- AUDICA - Hausman  Jenni Rudolph ft. Lys - Long Run - default
setManifestid(1262304, "5398933241873742314", 7494928)
-- AUDICA - Radio Compass - All Stars (AppID: 1341530)
addappid(1341530)
addappid(1341530, 1, "7592fd3dbea283372e34a364ac37fefdca161c07425c0347085a8d0c782324cb") -- AUDICA - Radio Compass - All Stars - default
setManifestid(1341530, "2122306149583521579", 6967052)
-- AUDICA - I Was Awake - Pre-Existing Condition (AppID: 1341531)
addappid(1341531)
addappid(1341531, 1, "fdcc86c14d24619f24cff8bfba8ae84f57a357e4395e1a61d9e066664ba2a894") -- AUDICA - I Was Awake - Pre-Existing Condition - default
setManifestid(1341531, "1316300317219192312", 9476957)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1190210) -- AUDICA 2019 Season Pass