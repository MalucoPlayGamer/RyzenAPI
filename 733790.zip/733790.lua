-- Lua provided by RyzenAPI
-- Game: Not Tonight

-- MAIN APPLICATION
addappid(733790)
-- Game: addappid(733790)

-- MAIN APP DEPOTS / PACKAGES
addappid(733791, 1, "31a543349bda5817aaebc166b5971164d24c302ccd03618ea1990fa999a839ad")
addappid(1036480, 0, "defb567c2559ae33566b0e8a8ac8691859926c56acbf5fd098da3c66cbb33a48")
