-- Lua provided by RyzenAPI
-- Game: Furry Femmes: Making an Obedient Bitch

-- MAIN APPLICATION
addappid(2083060)
-- Game: addappid(2083060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083061, 1, "57c1c4d6ada31eeab6a0efa7bcabbaabbb7608387c16d0cc09fd16ec42b2bf4d")
