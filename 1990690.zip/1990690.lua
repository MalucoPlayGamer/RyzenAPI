-- Lua provided by RyzenAPI
-- Game: Cooking Live - Italian Kitchen Simulator

-- MAIN APPLICATION
addappid(1990690)
addappid(2231760)
addappid(2236850)
addappid(2236851)
addappid(2236852)
addappid(2236853)
addappid(2236854)
addappid(2437970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990691, 1, "7a9bcb0a82d99259e568e0aa3f9b7aa64f9011beb45b650ac019da9b412a1046")
addappid(1990692, 1, "213405cd2232f0b2ecce468345b67a8f4b744d6fd2e8c524c3872c53a9124dd1")

