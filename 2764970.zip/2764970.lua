-- Lua provided by RyzenAPI
-- Game: The Feathered Serpent Demo

-- MAIN APPLICATION
addappid(2764970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764971, 1, "4bdc75fe5a0cb95e42fc2e2da385955c35ceb23bc027879d6d36651b8b3490ca")
