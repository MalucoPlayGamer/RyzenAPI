-- Lua provided by RyzenAPI
-- Game: Game: HeavensSea

-- MAIN APPLICATION
addappid(2983370)
-- Game: addappid(2983370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983371, 1, "c2090c98bc5d2dfee8e98613757bae6955120dc59c8e12eceecc02c58bb1a18e")
