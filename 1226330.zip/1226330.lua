-- Lua provided by SkyAPI 
-- Game: Rolling Bird (Free)
addappid(1226330)
addappid(1226331, 1, "f6edcdaa587ead27288c0d224c9f277b8d3ebcd300f21ded75c322764e8e0c4d")
