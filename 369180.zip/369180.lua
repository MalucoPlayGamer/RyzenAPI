-- Lua provided by RyzenAPI
-- Game: AppID 369180

-- MAIN APPLICATION
addappid(369180)

-- MAIN APP DEPOTS / PACKAGES
addappid(369181, 1, "8ead5c3035f60ee1b652b4a581cdda77f3cc3d21fb5eaef581cc89510bae9706")
