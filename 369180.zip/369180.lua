-- Lua provided by RyzenAPI
-- Game: AppID 369180

-- MAIN APPLICATION
addappid(369180)

-- MAIN APP DEPOTS / PACKAGES
addappid(369181, 1, "8ead5c3035f60ee1b652b4a581cdda77f3cc3d21fb5eaef581cc89510bae9706")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
