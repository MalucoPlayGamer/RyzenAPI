-- Lua provided by RyzenAPI
-- Game: Game: JR EAST Train Simulator: Rumoi Line (Fukagawa to Rumoi) Kiha 54-500 series

-- MAIN APPLICATION
addappid(2889350)
-- Game: addappid(2889350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889351, 1, "64c282fa7e73cbd9414dbcf667aea6e45f9a00829905c8adee68189a4fccc349")
addappid(2889352, 1, "4ce78d20955dda1c018603c1319dd340934d394a797a3136584a05182c72ac3b")
