-- Lua provided by SkyAPI 
-- Game: OVERLORD: ESCAPE FROM NAZARICK
addappid(1782150)
addappid(1782151, 1, "40fa3dbb5b2fd06ae51cd2f81b245f06c2a6b84715fd973c7c5297c588d72801")
