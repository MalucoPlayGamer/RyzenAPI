-- Lua provided by RyzenAPI
-- Game: OVERLORD: ESCAPE FROM NAZARICK

-- MAIN APPLICATION
addappid(1782150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782151, 1, "40fa3dbb5b2fd06ae51cd2f81b245f06c2a6b84715fd973c7c5297c588d72801")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
