-- Lua provided by RyzenAPI
-- Game: addappid(1782150)

-- MAIN APPLICATION
addappid(1782150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782151, 1, "40fa3dbb5b2fd06ae51cd2f81b245f06c2a6b84715fd973c7c5297c588d72801")
