-- Lua provided by RyzenAPI
-- Game: Drift: Space Survival

-- MAIN APPLICATION
addappid(2159650)
-- Game: addappid(2159650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159651, 1, "2f09a3562b150942d1df770d41324df7ab9fa137e76b9f6a4bcbfbde6aff3e1b")
addappid(2159652, 1, "51914a3ba0637ff4b0c65335c753a555706a29f17e3b8648c732fdfd8017e64b")
addappid(2159653, 1, "6b9397245f71cbcc5c960078228eacfd7b8597da5eabfe66df59e468d927be47")
