-- Lua provided by RyzenAPI
-- Game: Game: My Summer Adventure: Memories of Another Life

-- MAIN APPLICATION
addappid(1546060)
-- Game: addappid(1546060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546061, 1, "e99abdfeaaa6ff0c4c5f1b7edd96c136bd2e52e656faed7cf2d087c94da00a9b")
