-- Lua provided by RyzenAPI
-- Game: Rich everyone

-- MAIN APPLICATION
addappid(2615230)
addappid(2941300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2615231, 1, "813feaa187163b7f5f69c5f7eefc110e48daed5ce472430401907464569f7026")

