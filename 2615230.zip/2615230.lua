-- Lua provided by RyzenAPI
-- Game: Rich everyone

-- MAIN APPLICATION
addappid(2615230)
addappid(2941300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615231, 1, "813feaa187163b7f5f69c5f7eefc110e48daed5ce472430401907464569f7026")
