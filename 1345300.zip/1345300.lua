-- Lua provided by RyzenAPI
-- Game: addappid(1345300)

-- MAIN APPLICATION
addappid(1345300)
addappid(1347100)
addappid(1347980)
addappid(1349350)
addappid(1350400)
addappid(1351320)
addappid(1352320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345301, 1, "6e9f04776d119a5c8046f59d94c2cfc7a337c9cba9a9dd31aecef5980d91ea89")
