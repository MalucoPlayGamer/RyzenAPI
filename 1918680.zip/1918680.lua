-- Lua provided by RyzenAPI
-- Game: Sword and Fairy Inn 2

-- MAIN APPLICATION
addappid(1918680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918681, 1, "949d2cfa60781d9a5edc39479cf2e6383aece7ace954322c328d6f3808dcd9c0")
