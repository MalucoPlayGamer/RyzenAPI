-- Lua provided by SkyAPI 
-- Game: Sword and Fairy Inn 2
addappid(1918680)
addappid(1918681, 1, "949d2cfa60781d9a5edc39479cf2e6383aece7ace954322c328d6f3808dcd9c0")
