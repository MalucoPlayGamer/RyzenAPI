-- Lua provided by RyzenAPI
-- Game: FUSER™ - Kane Brown ft. Lauren Alaina - "What Ifs"

-- MAIN APPLICATION
addappid(1432155)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432155,0,"fb05ae0cca8fff65da801c7e6fb2b4b3ab02c672dfcd52f341d18f16633d26ed")

