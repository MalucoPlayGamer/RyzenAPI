-- Lua provided by RyzenAPI
-- Game: Rogue Trooper

-- MAIN APPLICATION
addappid(7020)
-- Game: addappid(7020)

-- MAIN APP DEPOTS / PACKAGES
addappid(7021, 1, "250eaa563ef4b58daca9c91d81e111642343f3b52edd7d8cb6dfba0d75251ca2")
addappid(7022, 1, "a4596c62f250f080ef9c5be3380529e19951461a18df1d6bb0bd8b60ba357ac8")
addappid(7023, 1, "2b3d201e4817c7ede9c41ebfc5d38cb546a3c5e0eddf1fea0f9f60208d69aa05")
addappid(7024, 1, "a9a6d09e22ba954b06c9cd3a2c69fe5f12305af22978e174e31d78a2df4b0779")
addappid(7025, 1, "07a949d9f20bfbf468b600968470a81767de3039df30a851b038205907293d8c")
addappid(7026, 1, "4d921be0cf7008ca50ba974732763646ebd16f1208493366188064e661ccbed2")
