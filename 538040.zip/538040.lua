-- Lua provided by RyzenAPI
-- Game: Dante's Forest

-- MAIN APPLICATION
addappid(538040)
-- Game: addappid(538040)

-- MAIN APP DEPOTS / PACKAGES
addappid(538041, 1, "03577e42e79951215a02241a4203b551ad00e2f38109bb5fe269843433f8c371")
