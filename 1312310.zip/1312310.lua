-- Lua provided by RyzenAPI
-- Game: Golden Moon

-- MAIN APPLICATION
addappid(1312310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312311, 1, "26effe82add3be86d7d6fd278e19241ba5d62fc9872b90505e66f580e0327c6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
