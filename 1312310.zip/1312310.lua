-- Lua provided by RyzenAPI
-- Game: Game: Golden Moon

-- MAIN APPLICATION
addappid(1312310)
-- Game: addappid(1312310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312311, 1, "26effe82add3be86d7d6fd278e19241ba5d62fc9872b90505e66f580e0327c6d")
