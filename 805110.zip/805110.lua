-- Lua provided by RyzenAPI
-- Game: P.A.S.

-- MAIN APPLICATION
addappid(805110)

-- MAIN APP DEPOTS / PACKAGES
addappid(805111, 1, "0d04794d175edee997fae955e099d28980dd443ea091ead215ff6bc12ad0bcd2")

