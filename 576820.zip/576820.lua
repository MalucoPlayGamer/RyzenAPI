-- Lua provided by RyzenAPI
-- Game: Colourise

-- MAIN APPLICATION
addappid(576820)

-- MAIN APP DEPOTS / PACKAGES
addappid(576822,0,"400e1bb42d3e13ba7b1f755105248e0fb8379cbe9eb132639be443bb60a878cd")

