-- Lua provided by RyzenAPI
-- Game: addappid(3242070)

-- MAIN APPLICATION
addappid(3242070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242071, 1, "6ef79bc6d88ead1bd775f8757829a030a5307ab350e36b5bc3e7dbc261460a84")
