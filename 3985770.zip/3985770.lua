-- Lua provided by RyzenAPI
-- Game: Arrow Spire: Tower Defense

-- MAIN APPLICATION
addappid(3985770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3985772,0,"d05f58cf2d0e27d7d0e01f1efbfa2ca88dea73950c8e39a72172b980b4e3d075")

