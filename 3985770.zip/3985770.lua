-- Lua provided by RyzenAPI
-- Game: Arrow Spire: Tower Defense

-- MAIN APPLICATION
addappid(3985770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3985772,0,"d05f58cf2d0e27d7d0e01f1efbfa2ca88dea73950c8e39a72172b980b4e3d075")

