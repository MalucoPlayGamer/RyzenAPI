-- Lua provided by RyzenAPI
-- Game: Game: Exowar

-- MAIN APPLICATION
addappid(358610)
-- Game: addappid(358610)

-- MAIN APP DEPOTS / PACKAGES
addappid(358611, 1, "61235e68a44567d3c8b10926b9af99eb9008f3e4ccc8654e3128660155eda138")
