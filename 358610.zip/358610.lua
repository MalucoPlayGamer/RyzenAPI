-- Lua provided by SkyAPI 
-- Game: Exowar
addappid(358610)
addappid(358611, 1, "61235e68a44567d3c8b10926b9af99eb9008f3e4ccc8654e3128660155eda138")
