-- Lua provided by RyzenAPI 
-- Game: Cats in Heat
addappid(2113000)
addappid(2113001, 1, "7fea456d69a6bc550e4dbc4ce343a6a3b96837ab2ae6f4e68d9daa70d1492baa")
