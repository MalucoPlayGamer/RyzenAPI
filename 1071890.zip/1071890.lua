-- Lua provided by RyzenAPI
-- Game: AppID 1071890

-- MAIN APPLICATION
addappid(1071890)
-- Game: addappid(1071890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071891, 1, "d7813fcd7500630c8ad3a615d7eab342b6b858b085fac163aca32b3134d23534")
addappid(1071898, 1, "a9dbda5d906c776f7ea63ae7d16f1dfd706df2ed1d200e616231168e5a1fa26a")
