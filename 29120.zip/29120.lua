-- Lua provided by RyzenAPI
-- Game: Yumsters 2: Around the World

-- MAIN APPLICATION
addappid(29120)

-- MAIN APP DEPOTS / PACKAGES
addappid(29121, 1, "27e5d0e2e9de80109dfeacf685d373441f8637a56a51fc4f5ec053781f7b116e")
