-- Lua provided by RyzenAPI
-- Game: Dear Esther: Landmark Edition

-- MAIN APPLICATION
addappid(520720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(520721, 1, "1721854517e7b4aeedf8d138c80fae97786ceff90543a463048ff9855e66e356")
addappid(520722, 1, "0dd476ee5e632d75e2285951bcba2735c2378fbcedcc2075f4fc615680c4013e")

