-- Lua provided by RyzenAPI
-- Game: 非凡仙途

-- MAIN APPLICATION
addappid(4511370)

