-- Lua provided by RyzenAPI
-- Game: Game: AppID 2239380

-- MAIN APPLICATION
addappid(2239380)
-- Game: addappid(2239380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239381, 1, "2a2637b26904009fabaeff0289e3faab17c9b7659061d4f457f3eccaec88009a")
