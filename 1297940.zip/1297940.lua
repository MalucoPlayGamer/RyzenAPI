-- Lua provided by RyzenAPI
-- Game: Game: Prehistoric Hunt Demo

-- MAIN APPLICATION
addappid(1297940)
-- Game: addappid(1297940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297941, 1, "8b58cc9d76d9113232cbc0ecd85e46018311fa5355407886a1f545d500dc789e")
