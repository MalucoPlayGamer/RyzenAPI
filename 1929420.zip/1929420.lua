-- Lua provided by SkyAPI 
-- Game: Hentai Mission Ukraine
addappid(1929420)
addappid(1929421, 1, "ecbaf39567f3d6536585d54d5a7728cee534c125869ddcbbcde98d07cb1c3454")
