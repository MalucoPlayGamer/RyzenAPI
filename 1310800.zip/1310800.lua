-- Lua provided by RyzenAPI
-- Game: Mine Dungeon2 ~Rurumu's trip~ Demo

-- MAIN APPLICATION
addappid(1310800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310801, 1, "19c2329f7ae2ca796368414bb04bb588ed8ef05b94fded43cfafe369adb06d50")

