-- Lua provided by RyzenAPI
-- Game: Elven Legend 2: The Bewitched Tree

-- MAIN APPLICATION
addappid(593540)

-- MAIN APP DEPOTS / PACKAGES
addappid(593541,0,"dc5af504532ebfd1b155e38608f6f459bdde83760a36ee14e087e59af262beb4")

