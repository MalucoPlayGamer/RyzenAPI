-- Lua provided by RyzenAPI
-- Game: Game: Pro Cycling Manager 25

-- MAIN APPLICATION
addappid(2511310)
-- Game: addappid(2511310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511311, 1, "56267938cdc192f9a25be2daf6f935095c5f0b95d42612ca156ff74076ee7f74")
