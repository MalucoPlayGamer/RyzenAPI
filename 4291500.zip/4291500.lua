-- Lua provided by RyzenAPI
-- Game: Secrets of the Heart

-- MAIN APPLICATION
addappid(4291500)

