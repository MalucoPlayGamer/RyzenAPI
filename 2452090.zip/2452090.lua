-- Lua provided by RyzenAPI
-- Game: Game: GREED IS GOOD

-- MAIN APPLICATION
addappid(2452090)
-- Game: addappid(2452090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452091, 1, "cc6ba02565057c63c6e22b8eedfceb7ab0b538229b76066bfac62687a01715a1")
