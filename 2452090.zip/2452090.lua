-- Lua provided by RyzenAPI
-- Game: GREED IS GOOD

-- MAIN APPLICATION
addappid(2452090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452091, 1, "cc6ba02565057c63c6e22b8eedfceb7ab0b538229b76066bfac62687a01715a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
