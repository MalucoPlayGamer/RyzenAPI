-- Lua provided by SkyAPI 
-- Game: Zasa - An AI Story
addappid(447240)
addappid(447241, 1, "bd67306a6de1718f9a9aef4a8fe234232b3d2fd1bdfe4abb660b1a248b1a6c39")
