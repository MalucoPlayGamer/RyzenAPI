-- Lua provided by RyzenAPI
-- Game: Math Rescue

-- MAIN APPLICATION
addappid(358200)

-- MAIN APP DEPOTS / PACKAGES
addappid(358201, 1, "7478fceb6b1b68ce17e2b64ed5e628ba6209ff223f124bbe76781a5a59f47920")
addappid(358202, 1, "791b1d6b288bf046ed06b775253dc24e5469aeb9d072ece6a3369229935ddce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
