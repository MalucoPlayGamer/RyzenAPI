-- Lua provided by RyzenAPI
-- Game: Without Within

-- MAIN APPLICATION
addappid(345650)
addappid(345670)

