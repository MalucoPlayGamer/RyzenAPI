-- Lua provided by RyzenAPI
-- Game: Without Within

-- MAIN APPLICATION
addappid(345650)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(345670)
