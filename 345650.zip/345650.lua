-- Lua provided by RyzenAPI
-- Game: Without Within

-- MAIN APPLICATION
addappid(345650)
