-- Lua provided by RyzenAPI
-- Game: Burn Me Alive

-- MAIN APPLICATION
addappid(1678030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678031, 1, "f3ff3b9b787bfa498deccfe35da4e901cb71853b841c3a42ef2ef4ccc175e89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
