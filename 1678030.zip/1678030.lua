-- Lua provided by RyzenAPI
-- Game: Burn Me Alive

-- MAIN APPLICATION
addappid(1678030)
-- Game: addappid(1678030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678031, 1, "f3ff3b9b787bfa498deccfe35da4e901cb71853b841c3a42ef2ef4ccc175e89f")
