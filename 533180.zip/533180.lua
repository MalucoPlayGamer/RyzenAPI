-- Lua provided by RyzenAPI
-- Game: 533180

-- MAIN APPLICATION
addappid(533180)
-- Game: addappid(533180)

-- MAIN APP DEPOTS / PACKAGES
addappid(533181, 1, "fe05c30a48ce26f57a89e7c38a07461b5f2a1e247de35dce353502aa044958a7")
