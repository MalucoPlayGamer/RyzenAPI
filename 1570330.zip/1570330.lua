-- Lua provided by RyzenAPI
-- Game: West Hunt

-- MAIN APPLICATION
addappid(1570330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1570331, 1, "5ac859676f89d9398ad7cdf2bc000881eb620df56012ebc9ace954e66a34dbc2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2004020)
addappid(2177400)
addappid(2643070)
