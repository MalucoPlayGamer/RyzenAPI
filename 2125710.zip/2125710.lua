-- Lua provided by RyzenAPI
-- Game: ALARA Prime Playtest

-- MAIN APPLICATION
addappid(2125710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125711, 1, "41a52dcb452b4daba9d09f728ff3d136f728c114be982b9b01accc44d5196473")
