-- Lua provided by RyzenAPI
-- Game: Alina of the Arena Soundtrack

-- MAIN APPLICATION
addappid(2060330)
-- Game: addappid(2060330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060331, 1, "f1e93cbe4e4a34f4f0506340b21e1c9b0848d3aa5466aa7e9541b7c945d529d0")
addappid(2060332, 1, "50dc9cd70c2bfec1693f63f52bd36c28680c8334cd9f8495101152750eb14ae3")
