-- Lua provided by SkyAPI 
-- Game: MENTAL
addappid(1227160)
addappid(1227161, 1, "da54d46053ec3c870841460249c9814fa1c1e953e93846cae284b99171c93e19")
