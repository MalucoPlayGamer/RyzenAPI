-- Lua provided by RyzenAPI
-- Game: Game: Unscripted Demo

-- MAIN APPLICATION
addappid(2259650)
-- Game: addappid(2259650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259651, 1, "8596472ffb36a6656d64347316109cb626bbc28b316d60fd442a744acff884c2")
