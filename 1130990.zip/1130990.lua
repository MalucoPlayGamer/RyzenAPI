-- Lua provided by RyzenAPI
-- Game: Roman Adventures - Britons. Season 2

-- MAIN APPLICATION
addappid(1130990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130991, 1, "3275f1368e5c3eac5b902c80d8e29293c423d6b9fccba9bcc968e7b5ef77973c")
addappid(1130992, 1, "9400b11e9095515c323382f68123c0d3023223b1911aaf12e08233e36706adc3")
