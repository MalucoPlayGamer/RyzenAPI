-- Lua provided by RyzenAPI
-- Game: Leisure Suit Larry 2 - Looking For Love (In Several Wrong Places)

-- MAIN APPLICATION
addappid(765840)

-- MAIN APP DEPOTS / PACKAGES
addappid(765841, 1, "71816ec513874f98fda7a2a4bf34f92fdb3c404d340ca2d09a933b2528789782")

