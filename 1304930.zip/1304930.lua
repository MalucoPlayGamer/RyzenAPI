-- Lua provided by RyzenAPI
-- Game: The Outlast Trials

-- MAIN APPLICATION
addappid(1304930)
addappid(2328320)
addappid(3030370)
addappid(3307910)
addappid(3518320)
addappid(3805230)
addappid(3805250)
addappid(3805260)
addappid(3805270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1304931, 1, "81611074b6fd0d2e108d34562aca73115d01d6bea3f08092b8d98aad42c2f0fb")

