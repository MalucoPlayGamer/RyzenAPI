-- Lua provided by RyzenAPI
-- Game: The Outlast Trials

-- MAIN APPLICATION
addappid(1304930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304931, 1, "81611074b6fd0d2e108d34562aca73115d01d6bea3f08092b8d98aad42c2f0fb")
