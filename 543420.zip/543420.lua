-- Lua provided by RyzenAPI
-- Game: Game: AppID 543420

-- MAIN APPLICATION
addappid(543420)
addappid(560560)
-- Game: addappid(543420)

-- MAIN APP DEPOTS / PACKAGES
addappid(543421, 1, "1ddfc221910d38320b60fdeb01f87efee6d1f88be4baa479542c7a428915236c")
