-- Lua provided by RyzenAPI
-- Game: addappid(3183860)

-- MAIN APPLICATION
addappid(3183860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183861, 1, "e0ee8c3e3dbde09ea0988798810ea5cfff4d4d67bf0614edad7d2ef679576907")
