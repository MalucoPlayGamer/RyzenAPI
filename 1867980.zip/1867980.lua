-- Lua provided by RyzenAPI
-- Game: Game: Disco Simulator Demo

-- MAIN APPLICATION
addappid(1867980)
-- Game: addappid(1867980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867981, 1, "6c5da22b6041794c0e7c0bcaa59edcf94869612c1eaa2133804601cfe52654e2")
