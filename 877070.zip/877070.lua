-- Lua provided by RyzenAPI
-- Game: Ticktock

-- MAIN APPLICATION
addappid(877070)

-- MAIN APP DEPOTS / PACKAGES
addappid(877071, 1, "9a6c9ffd506493bb54048efe07738ff7b50c31e98f7dd87a492f649ae3e12e67")
