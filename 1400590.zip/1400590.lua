-- Lua provided by RyzenAPI
-- Game: Summer in Mara - OST

-- MAIN APPLICATION
addappid(1400590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400591, 1, "70b3844814d6c748112225c47f66b053072d29aa86987aa4c74e978fbc278c0e")

