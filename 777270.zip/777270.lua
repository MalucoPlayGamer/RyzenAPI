-- Lua provided by RyzenAPI
-- Game: Thirsty Bubble

-- MAIN APPLICATION
addappid(777270)

-- MAIN APP DEPOTS / PACKAGES
addappid(777271, 1, "feba485d14c7a5def88e073abd50a1c17c64897a5310ba7b5e71b41398194a26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
