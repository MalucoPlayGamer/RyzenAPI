-- Lua provided by RyzenAPI
-- Game: Thirsty Bubble

-- MAIN APPLICATION
addappid(777270)

-- MAIN APP DEPOTS / PACKAGES
addappid(777271, 1, "feba485d14c7a5def88e073abd50a1c17c64897a5310ba7b5e71b41398194a26")
