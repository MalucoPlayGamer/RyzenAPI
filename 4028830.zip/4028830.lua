-- Lua provided by RyzenAPI
-- Game: WonderLang Mandarin Chinese

-- MAIN APPLICATION
addappid(4028830)

-- MAIN APP DEPOTS / PACKAGES
addappid(4028831,0,"99bbd4a2c7b43fd64185795b56447c78a6b6d2856f21f885ef58efb66ddda9f0")

