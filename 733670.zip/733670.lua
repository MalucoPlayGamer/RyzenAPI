-- Lua provided by RyzenAPI
-- Game: addappid(733670)

-- MAIN APPLICATION
addappid(733670)

-- MAIN APP DEPOTS / PACKAGES
addappid(733671, 1, "724cea7027820c754a034d83ca6c8ca25346e8b8bd71cb8b3ba0d363d1846cbe")
