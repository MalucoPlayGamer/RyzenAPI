-- Lua provided by RyzenAPI
-- Game: Award. Room of fear

-- MAIN APPLICATION
addappid(733670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(733671, 1, "724cea7027820c754a034d83ca6c8ca25346e8b8bd71cb8b3ba0d363d1846cbe")

