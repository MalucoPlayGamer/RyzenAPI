-- Lua provided by RyzenAPI
-- Game: Game: Howloween Hero

-- MAIN APPLICATION
addappid(1715160)
-- Game: addappid(1715160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715161, 1, "28cb87e97454b378614b36dac8795149083b69696361ddb82a6a99da01719c64")
