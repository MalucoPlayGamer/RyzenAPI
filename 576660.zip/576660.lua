-- Lua provided by RyzenAPI
-- Game: Snake Party

-- MAIN APPLICATION
addappid(576660)

-- MAIN APP DEPOTS / PACKAGES
addappid(576661, 1, "c1fefa3fa6fd8b161413f6cb67514a796ce76984498a83311244980ba56dd13a")
addappid(576662, 1, "a858255e31df9a93b3e133098f816b5ee619b9fac68b3322ffea6494909648dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
