-- Lua provided by RyzenAPI
-- Game: Timberborn Demo

-- MAIN APPLICATION
addappid(1237620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237622,0,"aa2122089e89b323d700283a236bc85ab2e6c282e212b537ca20763c4bed530b")

