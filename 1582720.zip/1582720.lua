-- Lua provided by RyzenAPI
-- Game: Recapture the Castle

-- MAIN APPLICATION
addappid(1582720)
-- Game: addappid(1582720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582721, 1, "8dafe1d3bdf8696977ce6387dcb5247f788bce0c87544d1c5e391c5234e40d0f")
