-- Lua provided by SkyAPI 
-- Game: GUNPYRE
addappid(3124380)
addappid(3124381, 1, "55b10f523b3b82bfeefd74d31661909b03044014d1046fef36d1b46244f77e71")
