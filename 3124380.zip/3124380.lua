-- Lua provided by RyzenAPI
-- Game: GUNPYRE

-- MAIN APPLICATION
addappid(3124380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3124381, 1, "55b10f523b3b82bfeefd74d31661909b03044014d1046fef36d1b46244f77e71")

