-- Lua provided by RyzenAPI
-- Game: Game: GUNPYRE

-- MAIN APPLICATION
addappid(3124380)
-- Game: addappid(3124380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124381, 1, "55b10f523b3b82bfeefd74d31661909b03044014d1046fef36d1b46244f77e71")
