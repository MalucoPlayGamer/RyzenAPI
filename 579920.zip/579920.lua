-- Lua provided by RyzenAPI
-- Game: addappid(579920)

-- MAIN APPLICATION
addappid(579920)

-- MAIN APP DEPOTS / PACKAGES
addappid(579921, 1, "66709a6b6c9a0f8f834daf690bac716f00326b15ed50c9c7b55688019787f7ba")
