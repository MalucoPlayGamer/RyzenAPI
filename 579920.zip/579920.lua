-- Lua provided by RyzenAPI
-- Game: Swatcher

-- MAIN APPLICATION
addappid(579920)

-- MAIN APP DEPOTS / PACKAGES
addappid(579921, 1, "66709a6b6c9a0f8f834daf690bac716f00326b15ed50c9c7b55688019787f7ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
