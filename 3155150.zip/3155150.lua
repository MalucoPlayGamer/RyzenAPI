-- Lua provided by RyzenAPI
-- Game: Miss Paint Demo

-- MAIN APPLICATION
addappid(3155150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155151, 1, "a10bc1c7813dd9985094a8166ac9ad4ea9093714026a1d8977037ffaeab5f4f1")
