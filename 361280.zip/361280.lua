-- Lua provided by RyzenAPI
-- Game: addappid(361280)

-- MAIN APPLICATION
addappid(361280)
addappid(804760)

-- MAIN APP DEPOTS / PACKAGES
addappid(361281, 1, "0f3e5d3968ab0559516621bee8349b5f5a8f651f091fa419d8aadee78cfeb67c")
addappid(361282, 1, "f2ff46e2f1b65bcab5960ce224a5fee831f290cee820939a636a13da0cc1fd8b")
addappid(361283, 1, "2dd5fdd35a66fd50be6adc97b07ffd9105cca964218b58a451def135037f5e8b")
addappid(361284, 1, "ddf67ba7f57b52bee876835cb5a9fd96148c0429b7415bad0b087319b9436076")
addappid(539310, 0, "6a3b326bbfcde6dba191a64dc93cbd994c7b7edd834d1cf3cbc314e985b1356b")
