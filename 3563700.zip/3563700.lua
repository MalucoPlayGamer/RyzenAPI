-- Lua provided by RyzenAPI
-- Game: Car Driving School Simulator

-- MAIN APPLICATION
addappid(3563700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3563701, 1, "d657b2be25db2c8bda1a6090710b920a57ca512ad18999c679bd14a036352edf")

