-- Lua provided by RyzenAPI
-- Game: AppID 588440

-- MAIN APPLICATION
addappid(588440)

-- MAIN APP DEPOTS / PACKAGES
addappid(588441, 1, "f5208428705539638252502cc34778647550807e2acdccf63c0bf58047763289")
addappid(1241870, 0, "2a73a5c2b8df2d5c5db47c6ad5416cf984eeae5ba77b4c69441f9b26b6ff6538")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
