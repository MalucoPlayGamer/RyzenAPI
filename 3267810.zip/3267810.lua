-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3267810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267810,0,"af9fcd2919324481817060a4e0ef16beff72d8f990827d28a72f3f855d9dcf5d")

