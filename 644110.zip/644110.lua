-- Lua provided by RyzenAPI 
-- Game: Lone Pirate VR
addappid(644110)
addappid(644111, 1, "2fd5a5267b5447e209a91a7820bf8f65242e9b4ea66ea86420a259a73a29dbdf")
