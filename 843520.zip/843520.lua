-- Lua provided by RyzenAPI
-- Game: addappid(843520)

-- MAIN APPLICATION
addappid(843520)

-- MAIN APP DEPOTS / PACKAGES
addappid(843521, 1, "3b5d7796d819b30e1e4de11f72459832abfbde7873aafc52f9770e33d6adf40e")
