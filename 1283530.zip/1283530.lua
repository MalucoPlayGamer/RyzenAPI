-- Lua provided by RyzenAPI 
-- Game: Oppai Muse Official Soundtrack
addappid(1283530)
addappid(1283531, 1, "164104f647f6e8f04c97b990eb9e3071becfe8d25cab15b8a3eacafc2d041930")
addappid(1283532, 1, "413ed2ee7121a16d4495a3f6449ce7eb92f89855a4b5d99a1fc6ae7bd887b489")
