-- Lua provided by RyzenAPI 
-- Game: Shooty Squad
addappid(681060)
addappid(681061, 1, "da4f40884d42ea111640892e32fc675a9cfa3d10a55d24386df70adb71997b40")
