-- Lua provided by RyzenAPI
-- Game: addappid(1351450)

-- MAIN APPLICATION
addappid(1351450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351451, 1, "48a968ea8623c5fd7c2dd4794e3df929982ef2b6779c25a933cdd7665070e81a")
