-- Lua provided by RyzenAPI
-- Game: AppID 1234040

-- MAIN APPLICATION
addappid(1234040)
-- Game: addappid(1234040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234041, 1, "dcb75b3516e5aa91095d78d7f2ba7a4ecba04ff86a77ff5f9c4b4555cef2155e")
