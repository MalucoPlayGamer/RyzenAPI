-- Lua provided by RyzenAPI
-- Game: addappid(883200)

-- MAIN APPLICATION
addappid(883200)

-- MAIN APP DEPOTS / PACKAGES
addappid(883201, 1, "4a281edee706f10eaecb56e7d4a347e02b1c049830b150ca449d59c84f00b0a9")
