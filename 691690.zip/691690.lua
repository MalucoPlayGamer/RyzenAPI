-- Lua provided by SkyAPI 
-- Game: Ash of Gods: Redemption
addappid(691690)
addappid(691691, 1, "adf23d350fe3a0088c7cc82a54b5ca9bb6aa3f9b8f8ee8abab0e0f27854a306c")
addappid(691692, 1, "7af110bb286973a579d7339edf3ba564bc8136d58fe39c1c7329762ef84a2206")
addappid(691693, 1, "13f45d316fd41868e4b143461b94d81f23b929d581c219e168ae39f3906438a9")
