-- Lua provided by RyzenAPI 
-- Game: AppID 463430
addappid(463430)
addappid(463431, 1, "4da0386ca08f48e460b0f90c1d7e0c869fc05730a6173a2cfef306e74c872b3a")
