-- Lua provided by SkyAPI 
-- Game: AppID 3410010
addappid(3410010)
addappid(3410011, 1, "4475be38537c0e25d78d8f7aca979c9e5b01cec5df3502e934eda4eba5c069e3")
