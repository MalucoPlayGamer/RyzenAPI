-- Lua provided by RyzenAPI
-- Game: 3410010

-- MAIN APPLICATION
addappid(3410010)
-- Game: addappid(3410010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410011, 1, "4475be38537c0e25d78d8f7aca979c9e5b01cec5df3502e934eda4eba5c069e3")
