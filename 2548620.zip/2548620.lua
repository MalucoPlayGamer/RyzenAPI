-- Lua provided by RyzenAPI
-- Game: addappid(2548620)

-- MAIN APPLICATION
addappid(2548620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548621, 1, "85a709a1d8671d706a149b8fab7dbf43e5920f421196a07cdaedb38ba3262421")
