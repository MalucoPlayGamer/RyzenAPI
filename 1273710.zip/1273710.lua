-- Lua provided by RyzenAPI
-- Game: King of Crabs

-- MAIN APPLICATION
addappid(1273710)
addappid(1716670)

