-- Lua provided by RyzenAPI
-- Game: King of Crabs

-- MAIN APPLICATION
addappid(1273710)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1716670)
