-- Lua provided by RyzenAPI
-- Game: Snake Charmer - TPS Snek

-- MAIN APPLICATION
addappid(667630)

-- MAIN APP DEPOTS / PACKAGES
addappid(667631, 1, "d4475000a4644ddc83563355e995d83a889ea4528d66cba11e0eb72388d26a99")

