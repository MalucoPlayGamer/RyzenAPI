-- Lua provided by RyzenAPI
-- Game: GEM's Hentai - Ultimate Puzzle

-- MAIN APPLICATION
addappid(2815370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815373,0,"9cb5aff29578be06fc67d2f9706f1d7e8afc348136e7d5b8e5c47e7a5bf93838")

