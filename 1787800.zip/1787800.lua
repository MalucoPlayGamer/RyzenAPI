-- Lua provided by RyzenAPI
-- Game: MotoX

-- MAIN APPLICATION
addappid(1787800)
-- Game: addappid(1787800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787801, 1, "5a1774e8791adcd840f7b70436c3562e76e4a541c4ba6023ab0edf45f2c9010f")
