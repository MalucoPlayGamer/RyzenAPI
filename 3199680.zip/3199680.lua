-- Lua provided by RyzenAPI
-- Game: Fairy Massage - Digital Artbook

-- MAIN APPLICATION
addappid(3199680)
-- Game: addappid(3199680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199680,0,"0541e97af6d7f4492be0b946745ef7e4eefb8ba31bb6c7f0e9c4582b37a2a456")
