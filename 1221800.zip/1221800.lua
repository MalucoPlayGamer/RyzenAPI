-- Lua provided by RyzenAPI
-- Game: 1221800

-- MAIN APPLICATION
addappid(1221800)
addappid(1246730)
addappid(1246750)
addappid(1329780)
-- Game: addappid(1221800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221801, 1, "c9a46252aa923908c0a163a5a8d1dbe6d8e9d5c359024c9cea0820dd1ab25027")
addappid(1246760, 0, "5e1bb2a35c58b4ddcbb8e93572d3f8a8d4c496973ea0802557f55d9c92cd1b9f")
