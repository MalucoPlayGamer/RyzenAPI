-- Lua provided by RyzenAPI
-- Game: BrahmaRakshas: Abandon Village Intro

-- MAIN APPLICATION
addappid(3331980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331981, 1, "a9b28a47a904a5716049dc70c53873870bca5e116705272f3d1afaf6e39f6206")
