-- Lua provided by RyzenAPI
-- Game: Tails of Iron 2: Whiskers of Winter

-- MAIN APPLICATION
addappid(2473480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473481, 1, "363154dca3195676d8f0f48c60b10690f47e439967d27162e4d18a5e6cbbcb83")
addappid(2473482, 1, "1e8929a53406c9c3c38ab507f124e2492d1f9d1a0ecfa993352f09466fd546a1")
addappid(2473483, 1, "43ad883ffa605f7c85a9fdc773be82ff190f8979de0f191a5503b3cac94564e9")
