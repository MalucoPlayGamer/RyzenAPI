-- Lua provided by RyzenAPI
-- Game: Trans Neuronica

-- MAIN APPLICATION
addappid(2390520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390521, 1, "cd17ea042eb42b9ecc33dd422bcb825312263f7d5485031128a314e590a88e57")
