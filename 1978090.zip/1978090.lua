-- Lua provided by RyzenAPI 
-- Game: GunBoxing
addappid(1978090)
addappid(1978091, 1, "000bb4f37bb633eea1fa9396262a2ac53b43d828913cf17750de273abf0280f0")
