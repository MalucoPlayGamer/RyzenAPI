-- Lua provided by RyzenAPI
-- Game: GunBoxing

-- MAIN APPLICATION
addappid(1978090)
-- Game: addappid(1978090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978091, 1, "000bb4f37bb633eea1fa9396262a2ac53b43d828913cf17750de273abf0280f0")
