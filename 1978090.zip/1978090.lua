-- Lua provided by RyzenAPI
-- Game: GunBoxing

-- MAIN APPLICATION
addappid(1978090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978091, 1, "000bb4f37bb633eea1fa9396262a2ac53b43d828913cf17750de273abf0280f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
