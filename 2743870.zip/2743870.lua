-- Lua provided by SkyAPI 
-- Game: AppID 2743870
addappid(2743870)
addappid(2743871, 1, "3f20324ae43c072ae2aab0e5b9b43f23bd9cc37131037d5c4c84e296978e7dda")
