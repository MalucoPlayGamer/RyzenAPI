-- Lua provided by RyzenAPI
-- Game: addappid(2743870)

-- MAIN APPLICATION
addappid(2743870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743871, 1, "3f20324ae43c072ae2aab0e5b9b43f23bd9cc37131037d5c4c84e296978e7dda")
