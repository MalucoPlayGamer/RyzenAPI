-- Lua provided by RyzenAPI
-- Game: AppID 1089320

-- MAIN APPLICATION
addappid(1089320)
-- Game: addappid(1089320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089321, 1, "5ac41e7231060ce75cf8ce7295feee871d4c80505d07190cd95276501b61a64f")
