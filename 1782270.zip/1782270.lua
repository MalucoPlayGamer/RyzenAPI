-- Lua provided by RyzenAPI
-- Game: addappid(1782270)

-- MAIN APPLICATION
addappid(1782270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782271, 1, "f852edad85280fdc301f2316909477b05ceea44f136ffc85637c3c58a58ce13d")
