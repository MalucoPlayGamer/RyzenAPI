-- Lua provided by RyzenAPI
-- Game: Farm and Girls

-- MAIN APPLICATION
addappid(1782270)
addappid(1798400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782271, 1, "f852edad85280fdc301f2316909477b05ceea44f136ffc85637c3c58a58ce13d")

