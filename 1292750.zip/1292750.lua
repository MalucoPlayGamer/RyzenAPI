-- Lua provided by RyzenAPI
-- Game: Hunting Moon - Depression & Succubus

-- MAIN APPLICATION
addappid(1292750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292751, 1, "9fadc7cf16f053a43e26c01f5719b3b302020eab8f856e1677fac94b8a8c7a2c")
addappid(1292753, 1, "4820a9feb51ecbc448935560989533130357e869f4dff5d466b7a42b995d5a4a")
addappid(1318430, 0, "60fcc1cf84696701be799a8f53353e000bc5d0a02bda7c0b844417fe8bcd642f")

