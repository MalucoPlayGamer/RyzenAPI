-- Lua provided by RyzenAPI
-- Game: Cheese Co-op Clicker Simulator

-- MAIN APPLICATION
addappid(3133580)
-- Game: addappid(3133580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133581, 1, "8cf8c040700ad496075342bc5acb5a159640ca7d4bf4d083c876e3b6206e3b99")
