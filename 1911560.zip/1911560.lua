-- Lua provided by RyzenAPI
-- Game: Class Escape

-- MAIN APPLICATION
addappid(1911560)
-- Game: addappid(1911560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911561, 1, "48d853e11ac4e33d4105de4933548ecc64508c2477c4c28026e402921351e6ea")
