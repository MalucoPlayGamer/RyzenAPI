-- Lua provided by SkyAPI 
-- Game: Class Escape
addappid(1911560)
addappid(1911561, 1, "48d853e11ac4e33d4105de4933548ecc64508c2477c4c28026e402921351e6ea")
