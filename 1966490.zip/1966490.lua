-- Lua provided by SkyAPI 
-- Game: Cat Cafe Manager Soundtrack
addappid(1966490)
addappid(1966491, 1, "e43a7d7f3530e5ea0bebfed0495645bba947b6c9540824f47cd97e7678effc7b")
