-- Lua provided by RyzenAPI
-- Game: Keatz: The Lonely Bird

-- MAIN APPLICATION
addappid(707320)

-- MAIN APP DEPOTS / PACKAGES
addappid(707321, 1, "73b14b93b282e8d53ba38d6ad1d76618359a0d167dfea7542351b4475cab0324")

