-- Lua provided by RyzenAPI
-- Game: Tomatenquark

-- MAIN APPLICATION
addappid(1274540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274541, 1, "aee3657fff82f348982e9cb1623821b10d138e456a852e5230b8b741faf73bd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
