-- Lua provided by RyzenAPI
-- Game: Tomatenquark

-- MAIN APPLICATION
addappid(1274540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274541, 1, "aee3657fff82f348982e9cb1623821b10d138e456a852e5230b8b741faf73bd2")

