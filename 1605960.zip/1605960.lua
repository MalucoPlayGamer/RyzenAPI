-- Lua provided by RyzenAPI
-- Game: Zombie Survival online

-- MAIN APPLICATION
addappid(1605960)
addappid(1610300)
-- Game: addappid(1605960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605961, 1, "bac010dfeb7fc6f2ca01dd5afb669a9325826793b689bba29759ea0e6cca1f70")
