-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 7

-- MAIN APPLICATION
addappid(1543030)
addappid(2223240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1543031, 1, "80c82f692c1dccb0e5de735f6b7513dc62421d6f9bfdf44af13992f5de4367cd")

