-- Lua provided by RyzenAPI
-- Game: Game: Sword and Fairy 7

-- MAIN APPLICATION
addappid(1543030)
-- Game: addappid(1543030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543031, 1, "80c82f692c1dccb0e5de735f6b7513dc62421d6f9bfdf44af13992f5de4367cd")
