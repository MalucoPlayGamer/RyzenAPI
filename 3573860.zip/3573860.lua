-- Lua provided by RyzenAPI
-- Game: addappid(3573860)

-- MAIN APPLICATION
addappid(3573860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573860,0,"daa9c7677c0363903f504ee940a4451f70777b4b28ffb5ccd0175fbc7bff3a34")
