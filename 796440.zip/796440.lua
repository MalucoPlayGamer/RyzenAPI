-- Lua provided by RyzenAPI 
-- Game: Spaceguy
addappid(796440)
addappid(796441, 1, "ea0a447924588973893405013b51f7498884b90e17436d2eccac0fd67fb868ab")
