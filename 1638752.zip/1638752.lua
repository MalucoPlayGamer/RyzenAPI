-- Lua provided by RyzenAPI
-- Game: FUSER™ - Dissentor - "Loop Pack 12"

-- MAIN APPLICATION
addappid(1638752)
-- Game: addappid(1638752)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638752,0,"9747ace5684e7c9e3d2108544f3dd5c9d3740605472b2c0e8b52403930ae39eb")
