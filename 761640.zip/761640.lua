-- Lua provided by RyzenAPI
-- Game: 761640

-- MAIN APPLICATION
addappid(761640)
-- Game: addappid(761640)

-- MAIN APP DEPOTS / PACKAGES
addappid(761641, 1, "50c491343eab246f5114f72107ae9b7867e3f1ef5dbdb5ba03a43ea5193ec52d")
addappid(761642, 1, "c01b91d31070e3451dd5b0dc7c2fe7f682a1650211d90c24aea1281ad79becfe")
