-- Lua provided by RyzenAPI 
-- Game: Ojiv
addappid(2205600)
addappid(2205601, 1, "91d72d130582f24624add4cb413bf17bb3433e8309f004595b7792d65eb47f1f")
