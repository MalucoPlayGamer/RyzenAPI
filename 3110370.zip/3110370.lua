-- Lua provided by RyzenAPI 
-- Game: Dustwind: Resistance
addappid(3110370)
addappid(3110371, 1, "e41ad2fc3fff9774779a0b115333f49cbf889ac11bbed56b4953bfcd9877d6bc")
