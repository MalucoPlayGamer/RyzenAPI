-- Lua provided by RyzenAPI
-- Game: Dustwind: Resistance

-- MAIN APPLICATION
addappid(3110370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110371, 1, "e41ad2fc3fff9774779a0b115333f49cbf889ac11bbed56b4953bfcd9877d6bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3948210)
addappid(4544150)
