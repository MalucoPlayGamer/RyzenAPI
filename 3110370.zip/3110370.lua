-- Lua provided by RyzenAPI
-- Game: Dustwind: Resistance

-- MAIN APPLICATION
addappid(3110370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110371, 1, "e41ad2fc3fff9774779a0b115333f49cbf889ac11bbed56b4953bfcd9877d6bc")
