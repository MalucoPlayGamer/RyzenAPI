-- Lua provided by RyzenAPI
-- Game: The Piano

-- MAIN APPLICATION
addappid(229000)
addappid(788610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(788613,0,"682efd03ca818fc81036feb9088d082d7eed5d36e4a41d310aeab4828e63c6a8")

