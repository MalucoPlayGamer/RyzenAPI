-- Lua provided by RyzenAPI
-- Game: The Piano

-- MAIN APPLICATION
addappid(229000)
addappid(788610)

-- MAIN APP DEPOTS / PACKAGES
addappid(788613,0,"682efd03ca818fc81036feb9088d082d7eed5d36e4a41d310aeab4828e63c6a8")
