-- Lua provided by RyzenAPI
-- Game: Dungeon Crawler Daniel

-- MAIN APPLICATION
addappid(1664010)
-- Game: addappid(1664010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664011, 1, "ed6974a0523747339ec2fd2bcf2e7efc8c454eb2162ed87c29efc1bf42dceecc")
