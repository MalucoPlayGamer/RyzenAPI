-- Lua provided by RyzenAPI
-- Game: 1048600

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229000)
addappid(1048600)
addappid(1048601)
-- Game: addappid(1048600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048602,0,"eb2f81bbfab040720ac4d18add97a2e6c35ca3ed52d06f0fa0538cee02d9261f")
