-- Lua provided by RyzenAPI
-- Game: Last Stop - Original Soundtrack

-- MAIN APPLICATION
addappid(1681750)
-- Game: addappid(1681750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681751, 1, "396d52216e8afd9b711547594e03d35239716e24a0d590c27af7aa27bef2ea96")
