-- Lua provided by RyzenAPI
-- Game: Clouzy!

-- MAIN APPLICATION
addappid(1493360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493361, 1, "268ea441078e3a4682d6e7c0350b42a335f4461322c94c253227ba0ad6e8ace2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
