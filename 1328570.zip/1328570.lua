-- Lua provided by RyzenAPI
-- Game: Game: Lighton

-- MAIN APPLICATION
addappid(1328570)
-- Game: addappid(1328570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328571, 1, "c169dcfe79d3f072ea9d7794759ae1947ae8917d70c4833838dd759f8db9101c")
