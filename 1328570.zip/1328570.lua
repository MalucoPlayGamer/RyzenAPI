-- Lua provided by SkyAPI 
-- Game: Lighton
addappid(1328570)
addappid(1328571, 1, "c169dcfe79d3f072ea9d7794759ae1947ae8917d70c4833838dd759f8db9101c")
