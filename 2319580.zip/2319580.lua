-- Lua provided by RyzenAPI
-- Game: Game: AppID 2319580

-- MAIN APPLICATION
addappid(2319580)
-- Game: addappid(2319580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319581, 1, "9e4bf8248cd6d565643c86057112a127accc9457bcf90a97589f5f49857115b0")
