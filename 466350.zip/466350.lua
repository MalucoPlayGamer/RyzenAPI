-- Lua provided by RyzenAPI
-- Game: Fossil Echo

-- MAIN APPLICATION
addappid(466350)
addappid(466360)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(466351, 1, "32548ca2f3b7a40e57674132fd6ebccc9c56c1f2215e6092ad824549094d2770")

