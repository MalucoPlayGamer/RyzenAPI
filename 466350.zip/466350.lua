-- Lua provided by RyzenAPI
-- Game: 466350

-- MAIN APPLICATION
addappid(466350)
-- Game: addappid(466350)

-- MAIN APP DEPOTS / PACKAGES
addappid(466351, 1, "32548ca2f3b7a40e57674132fd6ebccc9c56c1f2215e6092ad824549094d2770")
