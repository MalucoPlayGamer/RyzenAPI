-- Lua provided by RyzenAPI
-- Game: GyroSphere Trials

-- MAIN APPLICATION
addappid(673280)
-- Game: addappid(673280)

-- MAIN APP DEPOTS / PACKAGES
addappid(673282,0,"f8bb276edb130dab6c59c1228f2c67f42d2be8219fac4b8bc91ab724fbf59f7a")
