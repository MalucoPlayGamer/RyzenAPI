-- Lua provided by SkyAPI 
-- Game: Afterinfection
addappid(1341210)
addappid(1341211, 1, "9faa5b542e1d0e1e97c4b238ac21c0d7338ffacd44ced417ffab3e0a774e7961")
