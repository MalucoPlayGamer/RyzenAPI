-- Lua provided by RyzenAPI
-- Game: addappid(1341210)

-- MAIN APPLICATION
addappid(1341210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341211, 1, "9faa5b542e1d0e1e97c4b238ac21c0d7338ffacd44ced417ffab3e0a774e7961")
