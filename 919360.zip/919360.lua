-- Generated with Luie @ https://lua.tools/
-- 919360 - Alaloth: Champions of The Four Kingdoms
-- Generated 2026-08-21 04:42:45 UTC
-- # Depots (Total/DLC/Shared): 10/8/0

-- Main AppID
addappid(919360, 1, "645f83fc1150e577bdf7d3d1d248a8421c665daf099230b0528eb05c7de4ee31")

-- Main Depots
addappid(919361, 1, "58d9c2d65e5d967a7ce16b9e794a0a8b6e87aa144979e0d34b27fe259c768672")
setManifestid(919361, "539384425429303451", 14587174143)

-- DLC's (no depot keys required)
addappid(3320650) -- Alaloth - Champions of The Four Kingdoms - Ultimate Pack
addappid(3756420) -- Alaloth: Champions of The Four Kingdoms - Rimeward Set
addappid(3756430) -- Alaloth: Champions of The Four Kingdoms - Heartwood Set
addappid(3756440) -- Alaloth: Champions of The Four Kingdoms - Void Stalker Set
addappid(3756450) -- Alaloth: Champions of The Four Kingdoms - Luminous Redeemer Set

-- DLC's (with depot keys)
-- Alaloth: Champions of The Four Kingdoms Soundtrack (AppID: 2068920)
addappid(2068920)
addappid(2068921, 1, "1377810fab1841b950a8e282cfe9f72427a9305fc67037baf170bd79289bdaab")
setManifestid(2068921, "8773560417484261770", 345675971)
-- Alaloth: Champions of The Four Kingdoms - Supporter Pack (AppID: 2068930)
addappid(2068930)
addappid(2068930, 1, "f581679c56f68de7d1e62b8c7dc34a949747904ea8a4f695d64fba37a2e51425")
setManifestid(2068930, "6983843641291875533", 105986270)
-- Alaloth: Champions of The Four Kingdoms - Digital Artbook (AppID: 2069000)
addappid(2069000)
addappid(2069000, 1, "ae302e8ed3c4358ace72617d7f43b3a1af7494dff96d7e45e64fa92447dee14d")
setManifestid(2069000, "3317276015570110280", 417617951)
-- Alaloth: Champions of The Four Kingdoms - Black Sun (AppID: 3697680)
addappid(3697680)
addappid(3697680, 1, "f454559851b5b2e5e02cc1fc2bdbbc963f18f325e60b900afa4d9d1d2ea6906f")
setManifestid(3697680, "7115590758299740613", 32250479)
-- Alaloth: Champions of The Four Kingdoms - Tears of Heresy (AppID: 3697690)
addappid(3697690)
addappid(3697690, 1, "4e2c7b81bdc9d7ab2abfda82d1e516f558e22d7a0a4c666bb08b49256a6dd9ee")
setManifestid(3697690, "4554326912595740994", 28894326)
-- Alaloth: Champions of The Four Kingdoms - The Dragon's Bane (AppID: 3697700)
addappid(3697700)
addappid(3697700, 1, "bef4bd9227f58e6c6939efa6a483c9898300ceee517efe1ea234085d8648c7b2")
setManifestid(3697700, "8944762483567832505", 33403006)
-- Alaloth: Champions of The Four Kingdoms - Seas of Sand (AppID: 3697710)
addappid(3697710)
addappid(3697710, 1, "0622ea57f3a42684095ac3bdc1610b8f06896631405608ef60bbc20033f48dec")
setManifestid(3697710, "4440935810086855093", 32284870)

-- Missing Depots (We don't have the keys yet lol): 919362, 2068922
