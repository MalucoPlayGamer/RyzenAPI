-- Lua provided by RyzenAPI
-- Game: Alaloth: Champions of The Four Kingdoms

-- MAIN APPLICATION
addappid(2068920)
addappid(2068930)
addappid(2069000)
addappid(3320650) -- Alaloth - Champions of The Four Kingdoms - Ultimate Pack
addappid(3697680)
addappid(3697690)
addappid(3697700)
addappid(3697710)
addappid(3756420) -- Alaloth: Champions of The Four Kingdoms - Rimeward Set
addappid(3756430) -- Alaloth: Champions of The Four Kingdoms - Heartwood Set
addappid(3756440) -- Alaloth: Champions of The Four Kingdoms - Void Stalker Set
addappid(3756450) -- Alaloth: Champions of The Four Kingdoms - Luminous Redeemer Set

-- MAIN APP DEPOTS / PACKAGES
addappid(919360, 1, "645f83fc1150e577bdf7d3d1d248a8421c665daf099230b0528eb05c7de4ee31")
addappid(919361, 1, "58d9c2d65e5d967a7ce16b9e794a0a8b6e87aa144979e0d34b27fe259c768672")
addappid(2068921, 1, "1377810fab1841b950a8e282cfe9f72427a9305fc67037baf170bd79289bdaab")
addappid(2068930, 1, "f581679c56f68de7d1e62b8c7dc34a949747904ea8a4f695d64fba37a2e51425")
addappid(2069000, 1, "ae302e8ed3c4358ace72617d7f43b3a1af7494dff96d7e45e64fa92447dee14d")
addappid(3697680, 1, "f454559851b5b2e5e02cc1fc2bdbbc963f18f325e60b900afa4d9d1d2ea6906f")
addappid(3697690, 1, "4e2c7b81bdc9d7ab2abfda82d1e516f558e22d7a0a4c666bb08b49256a6dd9ee")
addappid(3697700, 1, "bef4bd9227f58e6c6939efa6a483c9898300ceee517efe1ea234085d8648c7b2")
addappid(3697710, 1, "0622ea57f3a42684095ac3bdc1610b8f06896631405608ef60bbc20033f48dec")

