-- Lua provided by RyzenAPI
-- Game: Pinup Ball

-- MAIN APPLICATION
addappid(904900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(904901, 1, "094d67b2e5dc7b5d5627e467a92000bd29327c7a6f432631f56019cc74dff657")

