-- Lua provided by SkyAPI 
-- Game: AppID 904900
addappid(904900)
addappid(904901, 1, "094d67b2e5dc7b5d5627e467a92000bd29327c7a6f432631f56019cc74dff657")
