-- Lua provided by RyzenAPI
-- Game: Game: Hollywood Animal

-- MAIN APPLICATION
addappid(2680550)
-- Game: addappid(2680550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680551, 1, "acee2ffb440b3d2df9f1939207db34e30f2ae56d123ef9d19f7d0d5889b23579")
