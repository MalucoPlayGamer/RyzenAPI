-- Lua provided by RyzenAPI
-- Game: Game: Knightess

-- MAIN APPLICATION
addappid(2551860)
-- Game: addappid(2551860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551861, 1, "881b717a31f34ad0a54370524db74da129f27d7d27422e9438985f98a86fb94e")
