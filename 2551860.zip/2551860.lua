-- Lua provided by SkyAPI 
-- Game: Knightess
addappid(2551860)
addappid(2551861, 1, "881b717a31f34ad0a54370524db74da129f27d7d27422e9438985f98a86fb94e")
