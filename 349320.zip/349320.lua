-- Lua provided by RyzenAPI 
-- Game: The Rainy Port Keelung 雨港基隆
addappid(349320)
addappid(349321, 1, "a02936e73740fb48022254f8457221852ca238168aaf8202cbfc68b79804600f")
addappid(349322, 1, "07c0d82ea6a52587fd6597dd05339fb56e339e58bd59ed1ac4ab03527f8b625f")
addappid(349327, 1, "6ddbd9a1e95df3cbe6197829220cf96c7da85c7b17272b06a7c7e92b5542be8f")
addappid(361051)
addappid(361060)
