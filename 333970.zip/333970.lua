-- Lua provided by RyzenAPI
-- Game: Game: A Druid's Duel

-- MAIN APPLICATION
addappid(333970)
-- Game: addappid(333970)

-- MAIN APP DEPOTS / PACKAGES
addappid(333971, 1, "922c4c876832694bc436d671e4de4248d2abd5f18b549d15378f384a32bfbfb3")
addappid(333972, 1, "c7e3b6ced296444fd7a3f1419f6354630ad9a3487defbf3e1db54c5a9347396d")
addappid(333973, 1, "009e78438411e72d917945913fe9cc34ae37568f54a42cca4996b503c0a16ad4")
