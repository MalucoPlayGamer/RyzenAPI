-- Lua provided by RyzenAPI 
-- Game: DeathStairwell99F
addappid(3104100)
addappid(3104101, 1, "aca51e354a498391985e8c7e83fc08f070a010a8a84e3a4af387d4a2facc2134")
