-- Lua provided by RyzenAPI
-- Game: Disgaea PC

-- MAIN APPLICATION
addappid(405900)
-- Game: addappid(405900)

-- MAIN APP DEPOTS / PACKAGES
addappid(405901, 1, "039ba814bc642ed741daf9897d622fc7639320b49d0c77292b814737dfafa564")
addappid(405902, 1, "1cb08ba4fb7bae5ae75da719d17385739627c0b44ddce822b801edca97008372")
addappid(405903, 1, "bf30826fd2020ade56329818014b75cb8b4b91a81538c8a6cb3416ffc04dd895")
addappid(405904, 1, "12c55f29b6bbd61fcd8dbf38077f4b91078d30c47b27acf5e70d17ea1a4eaeb6")
addappid(405905, 1, "1c33bc3f57be82d028a9fb13f6bc3cdd312aac361ac90d25621a8711e2992a84")
addappid(439540, 0, "ea4e8a8cf8f4e53ecfc32232f606b457e222eaf33ecddb66dac4d6a3a27e646d")
addappid(439541, 0, "aa02e96620ff50629dff8ff4608e3f5820be8f37e8117bb4b67ca3ed67866ba3")
