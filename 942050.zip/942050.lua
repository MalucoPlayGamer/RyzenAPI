-- Lua provided by RyzenAPI
-- Game: 942050

-- MAIN APPLICATION
addappid(942050)
-- Game: addappid(942050)

-- MAIN APP DEPOTS / PACKAGES
addappid(942051, 1, "3afb9e635b08906a7e4107af92969db5da6e9339efa2ca839ae6c9a3b4ed848b")
