-- Lua provided by RyzenAPI
-- Game: AppID 990940

-- MAIN APPLICATION
addappid(990940)
-- Game: addappid(990940)

-- MAIN APP DEPOTS / PACKAGES
addappid(990941, 1, "75c6f678a086e715e781879f3c38b742774db73b73ce1dbb0c31aaf65c183921")
