-- Lua provided by SkyAPI 
-- Game: AppID 990940
addappid(990940)
addappid(990941, 1, "75c6f678a086e715e781879f3c38b742774db73b73ce1dbb0c31aaf65c183921")
