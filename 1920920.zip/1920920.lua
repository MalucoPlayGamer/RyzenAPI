-- Lua provided by RyzenAPI
-- Game: TOS Illustration Collection 2022

-- MAIN APPLICATION
addappid(1920920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920920,0,"9dbcde80bdfd7f67903cd45902f814a717e44ed81057e364df2856d9128ab78a")
