-- Lua provided by RyzenAPI
-- Game: addappid(1087760)

-- MAIN APPLICATION
addappid(1087760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087761, 1, "6a138e7b33b8d0fddcc4efc5c3d9fc69a18b80529c80a1d2fb835656233d8530")
