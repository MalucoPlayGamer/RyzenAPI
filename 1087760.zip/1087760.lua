-- Lua provided by RyzenAPI
-- Game: AppID 1087760

-- MAIN APPLICATION
addappid(1087760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1087761, 1, "6a138e7b33b8d0fddcc4efc5c3d9fc69a18b80529c80a1d2fb835656233d8530")

