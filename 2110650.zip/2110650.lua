-- Lua provided by RyzenAPI
-- Game: 2110650

-- MAIN APPLICATION
addappid(2110650)
-- Game: addappid(2110650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110651, 1, "3907279e8504429bd512e9bdbbf0d514ff94ab3a2835efe6dc403480d5b51724")
