-- Lua provided by RyzenAPI
-- Game: Wendigo Blue

-- MAIN APPLICATION
addappid(3359390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359391, 1, "0c4865bbcf47d141888837fc70e1e185f0d58386aa18c75c327939c8db4693a2")

