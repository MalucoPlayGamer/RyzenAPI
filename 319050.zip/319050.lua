-- Lua provided by RyzenAPI
-- Game: Game: Chaos Reborn

-- MAIN APPLICATION
addappid(319050)
-- Game: addappid(319050)

-- MAIN APP DEPOTS / PACKAGES
addappid(319051, 1, "2505c513879ab44ced50620531f8d88627fd0e01926e08b3de665ee2297de80c")
addappid(319052, 1, "84e1a4d9d2b3a911349244c43abd2bf8f1667701abd32e5fa4fb230553bed062")
addappid(319053, 1, "4fba59ccbb811c49e5a2fc9d03ebe159a1ee5b2d33b9386d27e67510d6c14c62")
addappid(319054, 1, "e99e0a7d9f3396083ee5299807c7509b614bcb67daa31febf4f45c9b138cf0d9")
