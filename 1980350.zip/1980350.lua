-- Lua provided by RyzenAPI
-- Game: Run Build Pew!

-- MAIN APPLICATION
addappid(1980350)
-- Game: addappid(1980350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980351, 1, "ca0354a985f567e18f9fdf3f00361c169d7877680f7aca40bfe010b4d69d096f")
