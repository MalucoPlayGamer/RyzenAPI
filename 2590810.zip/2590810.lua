-- Lua provided by RyzenAPI
-- Game: 2590810

-- MAIN APPLICATION
addappid(2590810)
-- Game: addappid(2590810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590811, 1, "17bcf5adabf0fb3d2baacc4a1ea0759878a46736fc2e0e26ade5357cc2824165")
