-- Lua provided by RyzenAPI
-- Game: addappid(3737370)

-- MAIN APPLICATION
addappid(3737370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737371, 1, "449264891c40fd500d585ea85ac7d0acae9389e76bcbd707317940cbdd3ab708")
