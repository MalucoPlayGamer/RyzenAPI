-- Lua provided by RyzenAPI
-- Game: Game: AppID 773430

-- MAIN APPLICATION
addappid(773430)
-- Game: addappid(773430)

-- MAIN APP DEPOTS / PACKAGES
addappid(773431, 1, "513bfcc781901e2708633a84d904d4cd1c62438cc6ad4a9486258782685e5008")
