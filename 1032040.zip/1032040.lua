-- Lua provided by RyzenAPI
-- Game: 龍炎高校伝説２ The Legend of the Dragonflame High School 2

-- MAIN APPLICATION
addappid(1032040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032041, 1, "5b06342f80ad8e3caada83cc76e25cd63166d71af1168976c84c9a199d2190d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
