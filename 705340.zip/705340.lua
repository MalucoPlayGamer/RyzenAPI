-- Lua provided by RyzenAPI
-- Game: addappid(705340)

-- MAIN APPLICATION
addappid(705340)

-- MAIN APP DEPOTS / PACKAGES
addappid(705341, 1, "871e7fdf363ee3f960c911b0f98bca9a0c3fe2118f0d1994844df87546d9a6e5")
