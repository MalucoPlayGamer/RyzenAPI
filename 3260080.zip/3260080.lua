-- Lua provided by RyzenAPI
-- Game: Valkyrie Destruction

-- MAIN APP DEPOTS / PACKAGES
addappid(3260080, 1, "5d1d3258419351ebdaaabd15be8df3c136e2338784e9078a9ca101cfb4f3219e") -- Valkyrie Destruction
addappid(3260081, 1, "b60f3322efdeddd3af9d29c1eb0499525fdfff8e769e122c4a0c32e4df444045") -- Depot 3260081
addappid(3260082, 1, "d0c91cff477a189808b83d8fa36f7d9c9aff98374823ea302a58283699faa44b") -- Depot 3260082
addappid(3260083, 1, "b00d57df46bdb7cd7fdd6dcaf29a4df9327d10aa5b16a3afa2a214d3ab9fc0e5") -- Depot 3260083

