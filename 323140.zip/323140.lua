-- Lua provided by SkyAPI 
-- Game: Half-Life 2 Soundtrack
addappid(323140)
addappid(323141, 1, "7b4d21e83a4ea3912b79f1e3d5532201d6793b4599cd0a5bf242e3c12718d81c")
addappid(323142, 1, "dbac35e272fc86062acfcd3b2b67069880e51b5c269868565d8454dff66abe9e")
