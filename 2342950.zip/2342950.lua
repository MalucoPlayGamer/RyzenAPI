-- Lua provided by RyzenAPI
-- Game: God Of Weapons

-- MAIN APPLICATION
addappid(2342950)
addappid(3282270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342951, 1, "f18007f05de526f58cd0f02db0d25b1d6513980aecc85e94ed7c67b75a300266")

