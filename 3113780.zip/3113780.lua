-- Lua provided by SkyAPI 
-- Game: Grab and Guts
addappid(3113780)
addappid(3113781, 1, "5276e3a5ea7fe1ed96af5a01e93debd9165181d85a5dc1e6e9c559c4cb782355")
