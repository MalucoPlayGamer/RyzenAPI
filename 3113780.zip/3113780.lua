-- Lua provided by RyzenAPI
-- Game: Grab and Guts

-- MAIN APPLICATION
addappid(3113780)
-- Game: addappid(3113780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113781, 1, "5276e3a5ea7fe1ed96af5a01e93debd9165181d85a5dc1e6e9c559c4cb782355")
