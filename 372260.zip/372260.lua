-- Lua provided by RyzenAPI
-- Game: Weird Park Trilogy

-- MAIN APPLICATION
addappid(372260)

-- MAIN APP DEPOTS / PACKAGES
addappid(372261, 1, "a11d3e7342e5a1adb1764824047dbd45c768adba1a9eeaf5b171f77bea7a702b")
addappid(372262, 1, "6dab693d4415a55b36b606e55a0683dac5d259ee2486d25cdfd5c695dc2631dd")
addappid(372264, 1, "d024561d056912351699b4573363ac551527cd1905bd4bad75184893fddc42a3")
