-- Lua provided by RyzenAPI
-- Game: Apex

-- MAIN APPLICATION
addappid(630630)

-- MAIN APP DEPOTS / PACKAGES
addappid(630631, 1, "a397360deb822be38da2a8668d41c71a7b0674f70a50da45578ecb96d3c50803")

