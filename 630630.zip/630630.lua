-- Lua provided by RyzenAPI
-- Game: Apex

-- MAIN APPLICATION
addappid(630630)

-- MAIN APP DEPOTS / PACKAGES
addappid(630631, 1, "a397360deb822be38da2a8668d41c71a7b0674f70a50da45578ecb96d3c50803")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
