-- Lua provided by RyzenAPI
-- Game: EmojiShooter Demo

-- MAIN APPLICATION
addappid(3124110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124111, 1, "6bcee126c5b88a981b30e541de46d3a73d4c85b7f68c4ff36a87d235336afa01")

