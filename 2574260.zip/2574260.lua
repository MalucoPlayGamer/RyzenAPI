-- Lua provided by RyzenAPI
-- Game: Brain Overload: Calculate

-- MAIN APPLICATION
addappid(2574260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574261, 1, "f3613a96ccedf1f2895d50dade5b0f937ae97e56ea84d10ea39edc8d34bc64e6")

