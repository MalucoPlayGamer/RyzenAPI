-- Lua provided by RyzenAPI
-- Game: 585620

-- MAIN APPLICATION
addappid(585620)
-- Game: addappid(585620)

-- MAIN APP DEPOTS / PACKAGES
addappid(585621, 1, "bee80e74732352a103de4e15e2acfa99bf4b42eac1a0bf82cb658baef83478b7")
