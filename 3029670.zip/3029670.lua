-- Lua provided by RyzenAPI
-- Game: addappid(3029670)

-- MAIN APPLICATION
addappid(3029670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029671, 1, "210480ac2ccf69c18c12f4a0a6476193d9c4c278515d35a60a8b1a067c13ec96")
