-- Lua provided by RyzenAPI
-- Game: Succubus Crisis

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3606750, 1, "adc1ad76a7b978bf61f5e03af82c4a0ad5ec0027d980ab72ac27cc37694ba8e6") -- Succubus Crisis
addappid(3606751, 1, "d3cea02d65ae6594def43eeaa5e91ca8fe55d61824b5599ee25a91f180ec625e") -- Depot 3606751
addappid(3606752, 1, "357cf461ab3c4b3a0d9ae395a90a0dd48a2c08c8fa738dd4bb7c58041f20862a") -- Depot 3606752
addappid(3606753, 1, "0107a249b14422ced88e21b269eb83ae65f57165f0bfbb73b7403e2553460f46") -- Depot 3606753
addappid(3606754, 1, "ab67ad4bb453c6d1fffe028c4153f062666396bcf6235bf16cb3542b19877c6b") -- Depot 3606754

