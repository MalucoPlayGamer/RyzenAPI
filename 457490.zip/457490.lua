-- Lua provided by RyzenAPI
-- Game: 457490

-- MAIN APPLICATION
addappid(457490)
addappid(457491)
addappid(457493)
addappid(457494)
-- Game: addappid(457490)

-- MAIN APP DEPOTS / PACKAGES
addappid(457492,0,"09f86f3a18158027265715aa7d6ff05b5d07d551cb4c12dc285a5d1f6edfb004")
