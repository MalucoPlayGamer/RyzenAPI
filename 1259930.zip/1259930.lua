-- Lua provided by RyzenAPI
-- Game: 1259930

-- MAIN APPLICATION
addappid(1259930)
-- Game: addappid(1259930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259931, 1, "d26aab7e78ecbe803fe1dae2304a56bd7dc0cfcd84a15add58524825f6e2cd56")
addappid(1259932, 1, "a1516bb502b81ba2226936cea962bd10adb37d70056c86418aab6336314c33dd")
