-- Lua provided by RyzenAPI
-- Game: AppID 33440

-- MAIN APPLICATION
addappid(33440)

-- MAIN APP DEPOTS / PACKAGES
addappid(33441, 1, "1862f1b9723f9e38e7364b3823e5c615a6133b76e72f90b6107c25c39824cb7d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(33446)
addappid(33447)
addappid(33448)
addappid(33456)
addappid(33457)
