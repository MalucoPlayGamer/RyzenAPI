-- Lua provided by RyzenAPI
-- Game: Europa - "The Making Of" Digital Book

-- MAIN APPLICATION
addappid(3254410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3254410,0,"8fb609973d333082f9bf0dc7bd66680a756775f5d71e9f4fe7e763870f1cd2f8")
