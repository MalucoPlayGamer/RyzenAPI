-- Lua provided by RyzenAPI 
-- Game: AppID 1008060
addappid(1008060)
addappid(1008061, 1, "b52c4260f9f916831a0a8d3f7e470005e2cc8648445ab78f205a4c932d929412")
