-- Lua provided by RyzenAPI
-- Game: addappid(3637800)

-- MAIN APPLICATION
addappid(3637800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3637801, 1, "70dac7013a9b5db63fe2c92d4ba4af7293fb849dcce38f5451f940ebc7a2d6ff")
