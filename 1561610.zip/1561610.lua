-- Lua provided by RyzenAPI
-- Game: Sweep

-- MAIN APPLICATION
addappid(1561610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1561611, 1, "5d518d9323fe9278f8700e466a39551cd0eecb552d23e7102c006f420d192854")
