-- Lua provided by RyzenAPI
-- Game: Aonatsu Line

-- MAIN APPLICATION
addappid(2185770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185771, 1, "6b4e78ab58296115226ad2399677cc5563950e7fc28fed6b3924c441b578478d")

