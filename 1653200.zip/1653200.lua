-- Lua provided by RyzenAPI
-- Game: Vortex Rolling

-- MAIN APPLICATION
addappid(1653200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653201, 1, "aa90923833cb870710f76c26d772c7057d97cf5afd75ad218c519b567bffd95f")

