-- Lua provided by RyzenAPI
-- Game: addappid(2134010)

-- MAIN APPLICATION
addappid(2134010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134011, 1, "5212873b53bbdee77894bcca5c9bb2745c14b0773ec040af217872346b242b64")
