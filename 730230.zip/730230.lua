-- Lua provided by RyzenAPI
-- Game: Sniper Rust VR Demo

-- MAIN APPLICATION
addappid(730230)
-- Game: addappid(730230)

-- MAIN APP DEPOTS / PACKAGES
addappid(730231, 1, "6642231cea18369cee0444ab949317f9ee9249700977969a9c2feb450eb26826")
