-- Lua provided by SkyAPI 
-- Game: Sniper Rust VR Demo
addappid(730230)
addappid(730231, 1, "6642231cea18369cee0444ab949317f9ee9249700977969a9c2feb450eb26826")
