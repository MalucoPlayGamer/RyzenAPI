-- Lua provided by RyzenAPI
-- Game: AppID 731640

-- MAIN APPLICATION
addappid(731640)
-- Game: addappid(731640)

-- MAIN APP DEPOTS / PACKAGES
addappid(731641, 1, "8e4629eade8e42f040b474b12008046506b2251a59ad1dad80ce765d7257c0f6")
