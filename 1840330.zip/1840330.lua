-- Lua provided by RyzenAPI
-- Game: addappid(1840330)

-- MAIN APPLICATION
addappid(1840330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840331, 1, "c2c86cc19a6c1b6a83a696019b2feca034a398f5bce960d8025aa7eec2a32fc4")
