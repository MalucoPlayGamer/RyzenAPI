-- Lua provided by RyzenAPI
-- Game: Dummy Falls

-- MAIN APPLICATION
addappid(1840330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840331, 1, "c2c86cc19a6c1b6a83a696019b2feca034a398f5bce960d8025aa7eec2a32fc4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
