-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xingcai "Knight Costume" / 星彩「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019962)
-- Game: addappid(1019962)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019962,0,"8def513740f507b7a700f3921da1cb82d31c2a4753783c549f025788bf84491b")
