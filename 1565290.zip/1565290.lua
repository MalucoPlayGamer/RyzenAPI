-- Lua provided by RyzenAPI
-- Game: Survival Horror #8,436 (DISCONTINUED)

-- MAIN APPLICATION
addappid(1565290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565291, 1, "fb6d45926591ba66ccf403d0a091a4230968eac736b20c848aad466cf9a1b141")

