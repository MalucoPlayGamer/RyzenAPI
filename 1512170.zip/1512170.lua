-- Lua provided by RyzenAPI
-- Game: Infected Town

-- MAIN APPLICATION
addappid(1512170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512171, 1, "54b5fb9c2e14d0cf91430e429bef9f8e8ef8f8fe381e737ca52fee17e41ea7a8")
