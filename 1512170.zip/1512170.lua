-- Lua provided by SkyAPI 
-- Game: Infected Town
addappid(1512170)
addappid(1512171, 1, "54b5fb9c2e14d0cf91430e429bef9f8e8ef8f8fe381e737ca52fee17e41ea7a8")
