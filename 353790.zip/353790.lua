-- Lua provided by RyzenAPI
-- Game: 353790

-- MAIN APPLICATION
addappid(353790)
-- Game: addappid(353790)

-- MAIN APP DEPOTS / PACKAGES
addappid(353791, 1, "068eefb6837fffdb0445ecc521ac24f9d39c534ba703e54f4c3cda9d845298ad")
