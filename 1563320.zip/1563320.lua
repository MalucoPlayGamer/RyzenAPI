-- Lua provided by RyzenAPI
-- Game: Sleep Tight

-- MAIN APPLICATION
addappid(1563320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563321, 1, "588dbd16842b1a89c3953b0a99b0e2b80a3ebace92bd86c3fb8da26932d41775")
