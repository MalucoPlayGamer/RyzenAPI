-- Lua provided by RyzenAPI
-- Game: addappid(761920)

-- MAIN APPLICATION
addappid(761920)

-- MAIN APP DEPOTS / PACKAGES
addappid(761921, 1, "01b1b22c536ea8ac8788430a1229c1b25fee9c038adb20714a78d23b93ed68ae")
