-- Lua provided by RyzenAPI
-- Game: 737690

-- MAIN APPLICATION
addappid(737690)
-- Game: addappid(737690)

-- MAIN APP DEPOTS / PACKAGES
addappid(737691, 1, "da1d3bf19f19977469a8f6066c6ef05ad70a77c29c2999db854e6f09af863db9")
