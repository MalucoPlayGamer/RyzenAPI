-- Lua provided by RyzenAPI
-- Game: Bernackels' Shoggoth

-- MAIN APPLICATION
addappid(737690)

-- MAIN APP DEPOTS / PACKAGES
addappid(737691, 1, "da1d3bf19f19977469a8f6066c6ef05ad70a77c29c2999db854e6f09af863db9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
