-- Lua provided by RyzenAPI
-- Game: Fishing Online

-- MAIN APPLICATION
addappid(2131550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131551, 1, "ac5215176dbd57924eb5cd0b0fafe6205993dee9918c5bc8acaaba16140add87")
