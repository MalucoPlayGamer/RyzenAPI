-- Lua provided by RyzenAPI
-- Game: Just Act Natural

-- MAIN APPLICATION
addappid(1485080)
