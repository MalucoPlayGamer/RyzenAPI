-- Lua provided by RyzenAPI
-- Game: Just Act Natural

-- MAIN APPLICATION
addappid(1485080)
addappid(1740900)
addappid(2544070)

