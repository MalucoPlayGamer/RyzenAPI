-- Lua provided by RyzenAPI
-- Game: General War Memories

-- MAIN APPLICATION
addappid(1367720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1367721, 1, "873743bc229d8107216478d4d36ae049f5c0dad1033d58b51e119538e5a502f9")
addappid(1367722, 1, "14b2e37cbb97db4b9399d74874018c2ed4cfcdd08a5ac9149717316aef453eb8")

