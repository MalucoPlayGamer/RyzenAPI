-- Lua provided by RyzenAPI
-- Game: 1798690

-- MAIN APPLICATION
addappid(1798690)
-- Game: addappid(1798690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798691, 1, "53ea43069a249791cf798ad435f3c137bf16f41ddd3fc397f4c7c44ebbf68079")
