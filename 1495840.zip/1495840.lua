-- Lua provided by RyzenAPI
-- Game: 1495840

-- MAIN APPLICATION
addappid(1495840)
-- Game: addappid(1495840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495841, 1, "db719d29ff1d8be892d8d5da9e45379de5ba5340fabe8e69d7edbd1ca8e1988f")
