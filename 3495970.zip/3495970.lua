-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - We are burning tile and character set

-- MAIN APPLICATION
addappid(3495970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495970,0,"c044fc69266f3eb056b6916c535fe705f1b9fb13180f588b19222f951ce97354")

