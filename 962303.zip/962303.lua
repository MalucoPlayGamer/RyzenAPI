-- Lua provided by RyzenAPI
-- Game: Cheng Pu - Officer Ticket / 程普使用券

-- MAIN APPLICATION
addappid(962303)

-- MAIN APP DEPOTS / PACKAGES
addappid(962303,0,"b19a64b21f3168579d38871ba62158b621c6382900187f5707cf96ae7607f32f")

