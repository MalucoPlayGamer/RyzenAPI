-- Lua provided by RyzenAPI
-- Game: Game: 冒险日记  Adventure Diary Demo

-- MAIN APPLICATION
addappid(2462550)
-- Game: addappid(2462550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462551, 1, "53ffc15586a27a6e89f35c763d615e4e214ea8d0b0c60cf1a92e7732a152ee1d")
