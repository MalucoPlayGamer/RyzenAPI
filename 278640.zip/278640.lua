-- Lua provided by RyzenAPI
-- Game: Terrian Saga: KR-17

-- MAIN APPLICATION
addappid(278640)

-- MAIN APP DEPOTS / PACKAGES
addappid(278641, 1, "6dfdd8451b3af111a47e44a1080dc672cc12c2a99c7c541d30b74d9ad38fc7a3")
addappid(278643, 1, "9a312702df0b305778ec9e6618258e57192e600957557677584c683edc44f2c0")
addappid(278644, 1, "0fb3acd0457bea80dfe3086a1534383c54917291851d10188f5211ec0ae291f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
