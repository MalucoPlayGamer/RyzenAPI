-- Lua provided by RyzenAPI
-- Game: Elemental Rush

-- MAIN APPLICATION
addappid(3342900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342901, 1, "7727baee42003b03e55528ec2f1b38131674b5ef9f134815ec09825fbd38b5c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
