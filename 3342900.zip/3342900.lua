-- Lua provided by SkyAPI 
-- Game: Elemental Rush
addappid(3342900)
addappid(3342901, 1, "7727baee42003b03e55528ec2f1b38131674b5ef9f134815ec09825fbd38b5c7")
