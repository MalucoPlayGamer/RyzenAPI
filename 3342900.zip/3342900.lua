-- Lua provided by RyzenAPI
-- Game: Elemental Rush

-- MAIN APPLICATION
addappid(3342900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342901, 1, "7727baee42003b03e55528ec2f1b38131674b5ef9f134815ec09825fbd38b5c7")
