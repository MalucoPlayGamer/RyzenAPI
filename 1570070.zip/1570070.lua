-- Lua provided by RyzenAPI
-- Game: Beholder 3

-- MAIN APPLICATION
addappid(1570070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1570071, 1, "55da4977dabffd24c2a549b09ac258611a27eaaded8ec95c62861f1ec59b530e")

