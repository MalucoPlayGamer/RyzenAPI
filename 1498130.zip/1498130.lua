-- Lua provided by RyzenAPI
-- Game: Tank Squad

-- MAIN APPLICATION
addappid(1498130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498131, 1, "bb2fa96b40e0441aea32a605f09e313a1f83262896d6b14058cd2000d8e4fd7d")
