-- Lua provided by RyzenAPI
-- Game: Adam's Venture Episode 3: Revelations

-- MAIN APPLICATION
addappid(214310)
-- Game: addappid(214310)

-- MAIN APP DEPOTS / PACKAGES
addappid(214311, 1, "9c06b1393fe1aeeac3f2bec25573f23818525f2f778984a6419398d5271607f3")
