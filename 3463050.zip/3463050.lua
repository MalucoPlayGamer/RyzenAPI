-- Lua provided by RyzenAPI
-- Game: 3463050

-- MAIN APPLICATION
addappid(3463050)
-- Game: addappid(3463050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3463051, 1, "aa638e7f53885dab75ec8efa882ff7a86046d2ae4e53ff920b458269bc6a94fe")
