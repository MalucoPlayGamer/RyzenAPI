-- Lua provided by RyzenAPI
-- Game: Game: Rocky Mayhem

-- MAIN APPLICATION
addappid(1303350)
-- Game: addappid(1303350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303351, 1, "36aa84a239bdc5d2d1090ae7db234e68773b3cccff26b1d70eca4d000cd90dcf")
