-- Lua provided by RyzenAPI 
-- Game: Rocky Mayhem
addappid(1303350)
addappid(1303351, 1, "36aa84a239bdc5d2d1090ae7db234e68773b3cccff26b1d70eca4d000cd90dcf")
