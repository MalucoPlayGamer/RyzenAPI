-- Lua provided by RyzenAPI 
-- Game: Best Pearl
addappid(2303560)
addappid(2303561, 1, "7512e351df1904280e9016f26778475e09e5a357b331512550199dc2065cb0d9")
