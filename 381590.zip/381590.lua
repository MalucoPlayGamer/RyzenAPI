-- Lua provided by RyzenAPI
-- Game: Shred! Remastered

-- MAIN APPLICATION
addappid(381590)

-- MAIN APP DEPOTS / PACKAGES
addappid(381591, 1, "d8cdaac5d137736a2ae5a28188619ee7ce4600cb091d1773424ac0694e08212d")
