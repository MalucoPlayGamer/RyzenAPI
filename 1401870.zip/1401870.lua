-- Lua provided by RyzenAPI
-- Game: Game: Dark Dealings

-- MAIN APPLICATION
addappid(1401870)
-- Game: addappid(1401870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401871, 1, "1e5602c19d8265ed36774c06325783ac5d72101c503bcf1245b32c5b353bcbd7")
addappid(1401872, 1, "f1ac8a14e2caef94b0c74c2d98526e82666d2c21cafeff67ec7bc778c05f4d1b")
