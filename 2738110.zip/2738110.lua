-- Lua provided by RyzenAPI
-- Game: addappid(2738110)

-- MAIN APPLICATION
addappid(2738110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738111, 1, "3ec2193c403c973fcf4cfd2691d270b910ec37b0d89772af9f0389be457e8865")
