-- Lua provided by RyzenAPI
-- Game: Vengeance Hunters

-- MAIN APPLICATION
addappid(2738110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738111, 1, "3ec2193c403c973fcf4cfd2691d270b910ec37b0d89772af9f0389be457e8865")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
