-- Lua provided by RyzenAPI
-- Game: 2192680

-- MAIN APPLICATION
addappid(2192680)
-- Game: addappid(2192680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192681, 1, "2fb97e7f01eb6263f8f2fd4a1265b1523b9d2549cc6c6e7379061e85a61beb76")
