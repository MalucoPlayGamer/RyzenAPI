-- Lua provided by RyzenAPI
-- Game: AppID 655760

-- MAIN APPLICATION
addappid(655760)

-- MAIN APP DEPOTS / PACKAGES
addappid(655761, 1, "e52f3504e9c29aed94bdaea293bb5405c319fddf6dd1b6e4d43b8bdfc3c09d9f")

