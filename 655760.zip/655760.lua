-- Lua provided by RyzenAPI
-- Game: AppID 655760

-- MAIN APPLICATION
addappid(655760)

-- MAIN APP DEPOTS / PACKAGES
addappid(655761, 1, "e52f3504e9c29aed94bdaea293bb5405c319fddf6dd1b6e4d43b8bdfc3c09d9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
