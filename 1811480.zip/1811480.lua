-- Lua provided by RyzenAPI
-- Game: 頭痛

-- MAIN APPLICATION
addappid(1811480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1811481, 1, "7442a0a455df7b6aafc9e966fe3562ac6fd5245ca8e1a51d65387d9146758e62")

