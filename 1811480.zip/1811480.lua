-- Lua provided by RyzenAPI
-- Game: 頭痛

-- MAIN APPLICATION
addappid(1811480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811481, 1, "7442a0a455df7b6aafc9e966fe3562ac6fd5245ca8e1a51d65387d9146758e62")

