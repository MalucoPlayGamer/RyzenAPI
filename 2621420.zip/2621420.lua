-- Lua provided by RyzenAPI
-- Game: Game: The Elision Effect

-- MAIN APPLICATION
addappid(2621420)
-- Game: addappid(2621420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621421, 1, "4fa5dbf110ea93143e997f4c970a6b800ea17f4e9f6067750499b46dd41aed04")
