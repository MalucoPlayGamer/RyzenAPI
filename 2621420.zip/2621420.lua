-- Lua provided by RyzenAPI
-- Game: The Elision Effect

-- MAIN APPLICATION
addappid(2621420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2621421, 1, "4fa5dbf110ea93143e997f4c970a6b800ea17f4e9f6067750499b46dd41aed04")

