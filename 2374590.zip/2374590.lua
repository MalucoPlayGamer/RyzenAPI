-- Lua provided by RyzenAPI
-- Game: Sugar Sweet Temptation

-- MAIN APPLICATION
addappid(2374590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374591, 1, "0774fde3a0589ad5841ec261bcbe9bf1b3f80b3d2a0e6994fea69cfc1f47f5ec")
addappid(2374592, 1, "9f8da5a6b6a1ca61cd54c8e9f33a5da2f1ef9ccd32d21200c993dfb80ddd2148")

