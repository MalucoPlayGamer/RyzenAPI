-- Lua provided by RyzenAPI
-- Game: Now Open! Horror House

-- MAIN APPLICATION
addappid(2824160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2824161, 1, "1b8e5f841b3e4c55ff3e118ba1693a273565bc9968289e63ab0ac0094ec44112")

