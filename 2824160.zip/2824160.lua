-- Lua provided by RyzenAPI
-- Game: Now Open! Horror House

-- MAIN APPLICATION
addappid(2824160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824161, 1, "1b8e5f841b3e4c55ff3e118ba1693a273565bc9968289e63ab0ac0094ec44112")

