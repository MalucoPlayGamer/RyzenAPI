-- Lua provided by RyzenAPI
-- Game: Game: Letina's Odyssey

-- MAIN APPLICATION
addappid(1551620)
-- Game: addappid(1551620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551621, 1, "986da8d0dd09da374238166c2e18197d6cba027322129223334af45371e31368")
addappid(1551622, 1, "9b64d88e95e6aa8022322cde4e8d5c8c4b82e4cfbdea98a265a6797ddc0e7a9b")
addappid(1551623, 1, "6957f7457f97b2119f5ee3dc41164e7cafe356a23541f4c98b1a8c13e4bb8a7c")
