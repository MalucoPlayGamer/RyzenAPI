-- Lua provided by RyzenAPI
-- Game: The Defenders: The Second Wave

-- MAIN APPLICATION
addappid(351400)

-- MAIN APP DEPOTS / PACKAGES
addappid(351401, 1, "922abae4e28ad4ba773ff75d507a8cbb030cb57eb8e99751ec486778bc93c819")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
