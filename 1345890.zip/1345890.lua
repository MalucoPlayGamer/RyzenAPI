-- Lua provided by RyzenAPI
-- Game: Deliver Us Mars

-- MAIN APPLICATION
addappid(1345890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1345891, 1, "e8721d7cb8e56ca213f6a2a69837eeb828b32ef6774db196ad533cb1848f7664")
addappid(1345893, 1, "a5365410612b20b498fe2f99d9b957e677857771ac58d140853372dc59bb5a2c")

