-- Lua provided by RyzenAPI
-- Game: Game: Deliver Us Mars

-- MAIN APPLICATION
addappid(1345890)
-- Game: addappid(1345890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345891, 1, "e8721d7cb8e56ca213f6a2a69837eeb828b32ef6774db196ad533cb1848f7664")
addappid(1345893, 1, "a5365410612b20b498fe2f99d9b957e677857771ac58d140853372dc59bb5a2c")
