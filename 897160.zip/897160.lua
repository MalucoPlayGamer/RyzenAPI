-- Lua provided by RyzenAPI
-- Game: Snap & Grab

-- MAIN APPLICATION
addappid(897160)
addappid(4545600)
addappid(4545610)
addappid(4545620)
addappid(4545630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(897162,0,"a7c478959fab32453d6b112a9dbce2be026443450537050ba42cf8564a35c64e")
addappid(897163,0,"1114a2bf35b00d80e0e7f2cf5a828e568eb9de05fc3f91289575aa9090f94ddf")

