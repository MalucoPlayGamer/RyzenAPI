-- Lua provided by RyzenAPI
-- Game: AppID 1329500

-- MAIN APPLICATION
addappid(1329500)
addappid(2156362)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1329501, 1, "c75775f5cffb0c73f54a61025ebde9d44e50c644c5bd79d22e5a7069ccf3a8a5")

