-- Lua provided by RyzenAPI
-- Game: addappid(306290)

-- MAIN APPLICATION
addappid(306290)

-- MAIN APP DEPOTS / PACKAGES
addappid(306291, 1, "8d9f0ff86e83d48d504dc0ee2c725f48bd8abea5bd21541c4bd899ee535ef899")
