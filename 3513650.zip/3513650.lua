-- Lua provided by RyzenAPI
-- Game: 3513650

-- MAIN APPLICATION
addappid(3513650)
-- Game: addappid(3513650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513651, 1, "2ba5f05cb966e8eaed664d8ef0cb114481e7f6d9c7539bbc36e91c4db0a8056f")
