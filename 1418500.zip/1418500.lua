-- Lua provided by SkyAPI 
-- Game: You Suck at Parking Demo
addappid(1418500)
addappid(1418501, 1, "ca3dcd01844a81f9341ead34f6c5e1d5c5503b085959043e8c46e39e5ade3ab0")
