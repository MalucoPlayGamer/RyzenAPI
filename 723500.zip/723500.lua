-- Lua provided by RyzenAPI
-- Game: addappid(723500)

-- MAIN APPLICATION
addappid(723500)

-- MAIN APP DEPOTS / PACKAGES
addappid(723501, 1, "8add7706fdb3e6d1fc89ee723525cfc78db888e10616c0f9f9bd025db748828f")
