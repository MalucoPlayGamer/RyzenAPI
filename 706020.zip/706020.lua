-- Lua provided by RyzenAPI
-- Game: Fade to Silence

-- MAIN APPLICATION
addappid(706020)

-- MAIN APP DEPOTS / PACKAGES
addappid(706021, 1, "97d44e729bc2a30283cd9b6452e2ffdb712e3620cdd7a4a61b6e911431bf991f")
addappid(706025, 1, "72b92dcd60e4fe3d5a44fb9698fbb91623e04efbaf7b3488f7a7fe0967ad7eee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
