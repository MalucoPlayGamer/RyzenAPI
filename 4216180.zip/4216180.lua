-- 4216180's Lua and Manifest Created by Hubcap Manifest
-- IGNOBLE
-- Created: August 12, 2026 at 15:00:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4216180) -- IGNOBLE
-- MAIN APP DEPOTS
addappid(4216181, 1, "620cc46202752feafcbcd2056e914ef87c10f9672b66fcfd9b6f2d9839aa730e") -- Depot 4216181
setManifestid(4216181, "2766940506794076591", 193000964)