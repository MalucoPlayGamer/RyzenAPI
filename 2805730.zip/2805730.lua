-- Lua provided by RyzenAPI
-- Game: AppID 2805730

-- MAIN APPLICATION
addappid(2805730)
-- Game: addappid(2805730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805731, 1, "cba02030ed5c8f6bee173df1b7221d2cb3f296998fdb4a9b4de1fc65e9ee8c8a")
