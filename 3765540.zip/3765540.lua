-- Lua provided by RyzenAPI
-- Game: Game: DAY OF THE RISING DEAD

-- MAIN APPLICATION
addappid(3765540)
-- Game: addappid(3765540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765541, 1, "dfbe95363cc10579f166ae914942a50ed28065f7df85cac483f6d7680b532c50")
