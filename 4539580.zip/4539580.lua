-- 4539580's Lua and Manifest Created by Hubcap Manifest
-- Illvelo Swamp
-- Created: July 28, 2026 at 14:08:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4539580, 1, "257baad8bb1fed5a90529917f3c13d6810287efa7ad207a860f047946be18139") -- Illvelo Swamp
-- MAIN APP DEPOTS
addappid(4539581, 1, "119821de98dc74c795c206cba8d2020a5ea9e4789b751a918d3405f25b26b5fe") -- Depot 4539581
setManifestid(4539581, "5484528778619390515", 713168857)