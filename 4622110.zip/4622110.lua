-- Lua provided by RyzenAPI
-- Game: Created: August 12, 2026 at 09:12:45 EDT

-- MAIN APPLICATION
addappid(4622110) -- 我的傲娇妹妹 MY TSUNDERE SISTER

-- MAIN APP DEPOTS / PACKAGES
addappid(4622111, 1, "5654edef32b9dba8164fa8a69476d414dab331f3333a8ebc3569d841bf93ac1c") -- Depot 4622111

