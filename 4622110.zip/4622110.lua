-- 4622110's Lua and Manifest Created by Hubcap Manifest
-- 我的傲娇妹妹 MY TSUNDERE SISTER
-- Created: August 12, 2026 at 09:12:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4622110) -- 我的傲娇妹妹 MY TSUNDERE SISTER
-- MAIN APP DEPOTS
addappid(4622111, 1, "5654edef32b9dba8164fa8a69476d414dab331f3333a8ebc3569d841bf93ac1c") -- Depot 4622111
setManifestid(4622111, "7325455441805126294", 1092599479)