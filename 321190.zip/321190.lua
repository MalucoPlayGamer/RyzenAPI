-- Lua provided by RyzenAPI
-- Game: 321190

-- MAIN APPLICATION
addappid(321190)
-- Game: addappid(321190)

-- MAIN APP DEPOTS / PACKAGES
addappid(321191, 1, "9406a5dfe34ef74c84bd935c7cdb1c170cade0875bdd7821c298ef4d4447f395")
addappid(321192, 1, "37b31902c4bde32f8e879758ca73af32c3a4c3e944d0e7a2ba24ee4214577e61")
