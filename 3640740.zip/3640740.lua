-- Lua provided by RyzenAPI
-- Game: addappid(3640740)

-- MAIN APPLICATION
addappid(3640740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3640741, 1, "da7f9ad1a07b4ad48d488df1f2d8330418525edf80fa4bdd31d9ab882766741a")
