-- Lua provided by RyzenAPI
-- Game: Monochroma Demo

-- MAIN APPLICATION
addappid(304610)
-- Game: addappid(304610)

-- MAIN APP DEPOTS / PACKAGES
addappid(304611, 1, "35f2b15d0cbdc2f4d4a7b6c1c604f61e0cbfb5d46cb2d927088c97e0210e363c")
