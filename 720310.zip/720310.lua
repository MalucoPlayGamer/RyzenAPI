-- Lua provided by RyzenAPI
-- Game: 720310

-- MAIN APPLICATION
addappid(720310)
-- Game: addappid(720310)

-- MAIN APP DEPOTS / PACKAGES
addappid(720311, 1, "83838ccfb8c94972d6bede2bb4cb89b78ab0ceef6a9d29f62903209eefc455c6")
