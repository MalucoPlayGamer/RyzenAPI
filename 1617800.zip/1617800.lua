-- Lua provided by RyzenAPI
-- Game: Kin's Chronicle

-- MAIN APPLICATION
addappid(1617800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617801, 1, "5550898b8b0640c2e62bcf4b0a0d8cffcf122ea40bbfb04fb83971138bc11106")
addappid(1617802, 1, "e99de20a09d766c2eafa0845379b34e3f1408506a6afe5d8ad3bf70861e0c96b")
addappid(1617803, 1, "9164fb9689bd64abf32b67e35bce586708292aef22fc9f5798b1da274a407822")
addappid(1617804, 1, "a662e0770c3913ddaf2b5dd27c3ab99ee216dae9ac64f3f2fa2f25b30bf2231f")
