-- Lua provided by RyzenAPI
-- Game: Elementium

-- MAIN APPLICATION
addappid(783420)
-- Game: addappid(783420)

-- MAIN APP DEPOTS / PACKAGES
addappid(783421, 1, "62aaf713be2ddbc01714ae457e0d361ac31b9fce36777beae3a3f422450fef22")
