-- Lua provided by RyzenAPI
-- Game: Hidden Cats: City

-- MAIN APPLICATION
addappid(3460800)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3460850)
