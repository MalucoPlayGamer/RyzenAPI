-- Lua provided by RyzenAPI
-- Game: Hidden Cats: City

-- MAIN APPLICATION
addappid(3460800)
