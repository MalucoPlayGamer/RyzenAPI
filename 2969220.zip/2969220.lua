-- Lua provided by SkyAPI 
-- Game: Dark Destruction
addappid(2969220)
addappid(2969221, 1, "36697b1089f0ef683eb823c882721819aee6e5e9cf310576f2e71ff33f9be2e2")
