-- Lua provided by RyzenAPI
-- Game: Dark Destruction

-- MAIN APPLICATION
addappid(2969220)
-- Game: addappid(2969220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969221, 1, "36697b1089f0ef683eb823c882721819aee6e5e9cf310576f2e71ff33f9be2e2")
