-- Lua provided by RyzenAPI
-- Game: 3077470

-- MAIN APPLICATION
addappid(3077470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077470,0,"4e9bb8fadd0c69419eaa512af507a2f00b5e698d7d09b149cceb37abfe62e29a")

