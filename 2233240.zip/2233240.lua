-- Lua provided by RyzenAPI
-- Game: CyberHeroes Arena DX

-- MAIN APPLICATION
addappid(2233240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233241, 1, "660c2356dce52c3f5bb55ecf0e7aa9e7c3ac63fcd39b15cca4a2ae730ee8a4e4")

