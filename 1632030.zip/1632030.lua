-- Lua provided by RyzenAPI
-- Game: Soran

-- MAIN APPLICATION
addappid(1632030)
addappid(1890090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1632031, 1, "171b034407430d37375ca1a3b35ebd4069230b5e64f70a0a1cb042c3ec98e045")

