-- Lua provided by RyzenAPI
-- Game: Game: Soran

-- MAIN APPLICATION
addappid(1632030)
-- Game: addappid(1632030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632031, 1, "171b034407430d37375ca1a3b35ebd4069230b5e64f70a0a1cb042c3ec98e045")
