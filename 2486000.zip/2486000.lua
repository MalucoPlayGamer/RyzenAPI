-- Lua provided by RyzenAPI
-- Game: 2486000

-- MAIN APPLICATION
addappid(2486000)
-- Game: addappid(2486000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486001, 1, "7a73ca68ae99d9b409e0eff17e12e1d804f0e7b89da88719b9e46416dce702c9")
