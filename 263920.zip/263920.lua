-- Lua provided by RyzenAPI
-- Game: AppID 263920

-- MAIN APPLICATION
addappid(263920)

-- MAIN APP DEPOTS / PACKAGES
addappid(263921, 1, "853f9882a8defdc6c8ce622ed5f026509f361456b0e42d0b560ffadbbebd5c4f")
addappid(263922, 1, "8980e4a3dadfa0e5e5d885eccd0b4ac36d2fd3ae04039f868e53d3859d5b346b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
