-- Lua provided by RyzenAPI
-- Game: Game: Russian Life Simulator

-- MAIN APPLICATION
addappid(1070330)
-- Game: addappid(1070330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070331, 1, "f79d81c4493fd53d935c70cbea895589c69d2cd08051f8922014090df1a36374")
addappid(1070332, 1, "08a937596eddb260423d328ca3c059b53f37ef65806279bff9db9525c004d239")
addappid(1070333, 1, "21b8e09ef6c64d6dc2b7fb4e2dd1a1702f83950f5b628ebf51c78ddf622fbc1d")
addappid(1070334, 1, "a3e2a8e871b44f18b8457aeb31835bad5bd62b3d042ceacd107da8bde9692437")
