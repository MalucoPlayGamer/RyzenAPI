-- Lua provided by RyzenAPI
-- Game: Apocalypse Island

-- MAIN APPLICATION
addappid(3274800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274802,0,"723d1ca63bc7c59cef5f3fde129086521c146b1628746adbf4d6c54216a543e5")
