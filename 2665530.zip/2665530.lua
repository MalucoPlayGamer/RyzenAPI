-- Lua provided by SkyAPI 
-- Game: Dystofarm
addappid(2665530)
addappid(2665531, 1, "000bb0e4fe98ef7b16bf6e6a8cf3244523c2e0721c39b4543e8e27a4e13c1201")
