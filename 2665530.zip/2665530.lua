-- Lua provided by RyzenAPI
-- Game: Dystofarm

-- MAIN APPLICATION
addappid(2665530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665531, 1, "000bb0e4fe98ef7b16bf6e6a8cf3244523c2e0721c39b4543e8e27a4e13c1201")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
