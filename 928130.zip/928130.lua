-- Lua provided by RyzenAPI
-- Game: Master of Rogues - The Seven Artifacts

-- MAIN APPLICATION
addappid(928130)

-- MAIN APP DEPOTS / PACKAGES
addappid(928131, 1, "77a454aed8629f7aae135c416a15e6ee53d6243e0ddf3ca716c36bb9738bba79")

