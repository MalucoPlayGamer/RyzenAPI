-- Lua provided by RyzenAPI
-- Game: The ScreaMaze

-- MAIN APPLICATION
addappid(1000600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000601, 1, "f0d327088b86e1e02ca66aba370959b42cc260dc2a5a4bfdc49601f65d86719e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
