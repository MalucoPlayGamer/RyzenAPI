-- Lua provided by RyzenAPI
-- Game: The ScreaMaze

-- MAIN APPLICATION
addappid(1000600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000601, 1, "f0d327088b86e1e02ca66aba370959b42cc260dc2a5a4bfdc49601f65d86719e")
