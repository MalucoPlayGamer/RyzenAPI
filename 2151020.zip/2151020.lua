-- Lua provided by RyzenAPI
-- Game: AppID 2151020

-- MAIN APPLICATION
addappid(2151020)
-- Game: addappid(2151020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151021, 1, "58f68f06f64dac3b8ab3ef6fd60b52f97745983a818d719e1376e7fa9dc440c2")
