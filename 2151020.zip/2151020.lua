-- Lua provided by SkyAPI 
-- Game: AppID 2151020
addappid(2151020)
addappid(2151021, 1, "58f68f06f64dac3b8ab3ef6fd60b52f97745983a818d719e1376e7fa9dc440c2")
