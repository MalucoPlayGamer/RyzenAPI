-- Lua provided by RyzenAPI
-- Game: Citywars Tower Defense

-- MAIN APPLICATION
addappid(1890650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890651, 1, "e5694849baba47be17ec735172469af8744ce62835e0a929737e088546d61d12")
addappid(1890652, 1, "3d7860c2538f39424df0edebf60c530e7c27a5db100dc7d2c7aa2aa230b49790")
addappid(1890653, 1, "e099688bdea81bd11d0a5b74aa6d7f026917e653d12891603401343256a8e3f2")
addappid(1890654, 1, "4fe28eb229b8cff6527822a865633a1fb2cd0ff9a1fd0e0ad145451a7706c297")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
