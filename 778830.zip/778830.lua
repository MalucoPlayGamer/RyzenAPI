-- Lua provided by RyzenAPI
-- Game: Knights of Hearts

-- MAIN APPLICATION
addappid(778830)

-- MAIN APP DEPOTS / PACKAGES
addappid(778831, 1, "eda21446a489b86232141422d865c7989e1a1583be2842093b641aabccc3f994")

