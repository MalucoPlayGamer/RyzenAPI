-- Lua provided by RyzenAPI
-- Game: 模拟足球 Demo

-- MAIN APPLICATION
addappid(2240020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240021, 1, "0c9af6d80b456d18aafb8355b72005f0b7c68ed42ab32f691e0558882b77e8ae")
