-- Lua provided by RyzenAPI
-- Game: Living with my Little Sister

-- MAIN APPLICATION
addappid(3478020)
-- Game: addappid(3478020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478021, 1, "d50a230a39d4320b9c2e5629fc6d802bfc0bfadb498e9ed5797f3425801e9e60")
addappid(3478023, 1, "73d93ee282976fc790061cffd555413125a15c1b40ef29614b9b9826b992e5f7")
addappid(3478024, 1, "881bed4824eaa496297c33bc8f25062634fef22b228673e0426426ed8165a21c")
