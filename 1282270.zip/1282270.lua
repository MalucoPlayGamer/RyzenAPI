-- Lua provided by RyzenAPI
-- Game: Strinova

-- MAIN APPLICATION
addappid(1282270)
