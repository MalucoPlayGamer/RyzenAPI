-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Shogatsu Gifts ALL in PACK

-- MAIN APPLICATION
addappid(2752640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752641, 1, "4145d6cb9aca92a3706be3ea871001130814269e917828547f886b44ffc1e3d4")
