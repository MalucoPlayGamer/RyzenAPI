-- Lua provided by RyzenAPI
-- Game: Flag N Frag

-- MAIN APPLICATION
addappid(456160)

-- MAIN APP DEPOTS / PACKAGES
addappid(456162,0,"800f104ff55b28822cd5d2d9fe82e6a382e6f81a356b000fb9a95fc464264716")

