-- Lua provided by RyzenAPI
-- Game: AppID 612620

-- MAIN APPLICATION
addappid(612620)
addappid(1110930)

-- MAIN APP DEPOTS / PACKAGES
addappid(612621, 1, "087c8c2adf37e5fce8c20200155379d8a5da0f16e2332702c489a977c67d7be9")
addappid(612622, 1, "71f978830641c6edaf1313f6b3043a05dfff360ad9860555aefddd19317240d6")
addappid(612623, 1, "021b72acbb82752f92ffc386e1916c27aaada0773a7a16a1e43ada06e0e6f486")
addappid(614870, 0, "933349bb4377c84bc945f83a28bdeb86d6b439320b346092909dabe7aa48dfa4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
