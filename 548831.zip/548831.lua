-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(548831)

-- MAIN APP DEPOTS / PACKAGES
addappid(548831,0,"3fd10f9a79bb8d35bd482b7cf94fa1c4ba51709e7a23e9d18713d670450786fc")
