-- Lua provided by RyzenAPI
-- Game: AppID 779050

-- MAIN APPLICATION
addappid(779050)

-- MAIN APP DEPOTS / PACKAGES
addappid(779051, 1, "b2a5aadfdf5ea2b1d6d717a57634ead59094ba29a33ea4384ab14369fad75d8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
