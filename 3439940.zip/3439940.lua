-- Lua provided by RyzenAPI
-- Game: addappid(3439940)

-- MAIN APPLICATION
addappid(3439940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439941, 1, "23ef8e624e4f4d7cb1376494b4758e51180f6ca4f603d32935a8bf88f39b70d5")
