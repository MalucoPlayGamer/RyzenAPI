-- Lua provided by RyzenAPI
-- Game: Driftwatch VR

-- MAIN APPLICATION
addappid(544800)

-- MAIN APP DEPOTS / PACKAGES
addappid(544801, 1, "98527092b130f23d786ccf4fbb3d478772707f1c67011ae47862dd13d0e509b8")

