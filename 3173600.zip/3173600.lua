-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel 3 - Deluxe Edition Upgrade Pack

-- MAIN APPLICATION
addappid(3173600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173601, 1, "b0deff0d3c2afe06ff2792382f0ec1199a3dc6e0be5c25225651494e6f02b442")

