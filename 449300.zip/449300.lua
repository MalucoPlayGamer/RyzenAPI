-- Lua provided by RyzenAPI 
-- Game: Planar Conquest
addappid(449300)
addappid(449301, 1, "faca669d8c2339ba1bf7179c7618a07171deefe7cd762a43b7086b0153f07873")
addappid(449302, 1, "4867c1c582f0845d57ee74382a0acb4b9b8177b8de68d5d9b22eda4d7c264ccf")
addappid(449303, 1, "927b923532f963fcdbfd739f7c300367a1dc8c9a291b8721e9f7be7a73bdb96a")
