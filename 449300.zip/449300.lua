-- Lua provided by RyzenAPI
-- Game: Planar Conquest

-- MAIN APPLICATION
addappid(449300)

-- MAIN APP DEPOTS / PACKAGES
addappid(449301, 1, "faca669d8c2339ba1bf7179c7618a07171deefe7cd762a43b7086b0153f07873")
addappid(449302, 1, "4867c1c582f0845d57ee74382a0acb4b9b8177b8de68d5d9b22eda4d7c264ccf")
addappid(449303, 1, "927b923532f963fcdbfd739f7c300367a1dc8c9a291b8721e9f7be7a73bdb96a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
