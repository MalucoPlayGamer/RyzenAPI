-- Lua provided by RyzenAPI
-- Game: Amanda the Adventurer

-- MAIN APPLICATION
addappid(2166060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166061, 1, "814ece087ba954ca208b3a2aafded05134d3cd5854a6677001596c37b55e1f5e")
