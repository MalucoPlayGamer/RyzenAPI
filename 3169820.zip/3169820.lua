-- Lua provided by RyzenAPI
-- Game: 3169820

-- MAIN APPLICATION
addappid(3169820)
-- Game: addappid(3169820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169821, 1, "a126e24e872fc456b31ee5e236803d3585fd44ace7b9c82efeaed70325afde2a")
