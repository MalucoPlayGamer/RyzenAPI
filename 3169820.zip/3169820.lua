-- Lua provided by SkyAPI 
-- Game: AppID 3169820
addappid(3169820)
addappid(3169821, 1, "a126e24e872fc456b31ee5e236803d3585fd44ace7b9c82efeaed70325afde2a")
