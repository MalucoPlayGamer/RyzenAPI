-- Lua provided by RyzenAPI
-- Game: BanHammer

-- MAIN APPLICATION
addappid(423840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(423841, 1, "3693f00e3a83de66532555f4d63d825296738144b7b40735627878f66ea2d3ad")
addappid(423842, 1, "01e9248325e50b53cd749cc1103970924e12a6a1eb5197a4d0fbf0dc0a21da68")
addappid(430330, 0, "ccddcbc7ebfb7679f2eee8e04fdfcce55b8cc911060c66936cbdf0cfa6cdd3b8")

