-- Lua provided by RyzenAPI
-- Game: Game: AppID 423840

-- MAIN APPLICATION
addappid(423840)
-- Game: addappid(423840)

-- MAIN APP DEPOTS / PACKAGES
addappid(423841, 1, "3693f00e3a83de66532555f4d63d825296738144b7b40735627878f66ea2d3ad")
addappid(423842, 1, "01e9248325e50b53cd749cc1103970924e12a6a1eb5197a4d0fbf0dc0a21da68")
addappid(430330, 0, "ccddcbc7ebfb7679f2eee8e04fdfcce55b8cc911060c66936cbdf0cfa6cdd3b8")
