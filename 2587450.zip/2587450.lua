-- Lua provided by RyzenAPI
-- Game: Tank Team

-- MAIN APPLICATION
addappid(2587450)
-- Game: addappid(2587450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587452,0,"48a1ae821269ffaa82c7c6f5e9b18a907053d7cb3417fec8273625cecf3bc8da")
addappid(2587453,0,"0de402bc28b31ffbf714ee96321ae20d2a2474975ae6f4c3efa84cf4abc2ab88")
addappid(2587454,0,"906c789fe6aa6479cf75d879d1fce415c1d1e97d5745a1e9fb023ac98fb6795a")
