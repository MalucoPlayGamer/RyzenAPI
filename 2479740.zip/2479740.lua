-- Lua provided by RyzenAPI 
-- Game: Pieces of me
addappid(2479740)
addappid(2479741, 1, "55f6aca9343b0bba81246be597d56b1c834e857f7c78dcf3cc0f1b0de01ad21c")
