-- Lua provided by RyzenAPI
-- Game: Game: AppID 1045580

-- MAIN APPLICATION
addappid(1045580)
-- Game: addappid(1045580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045581, 1, "243b40c7739651de28a182990cae46076287ddd11c92b90488e2fed54d60f833")
addappid(1045582, 1, "a87cd7ee2a611f3047cdf98225172c254f76cdf2847bf1fbe0dc83dd6db086bf")
addappid(1045583, 1, "076460a852827e27f7bfc4ff9958eeca2dfb5aa9959f4e51bfc9a1d12da360b3")
