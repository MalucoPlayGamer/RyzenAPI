-- Lua provided by RyzenAPI
-- Game: Apex Armor Swap Trainer

-- MAIN APPLICATION
addappid(2334340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334341, 1, "d10c3721de098962f860a659cabfd15bbfe08b013643dca9b97e3db7d1e1e09f")
