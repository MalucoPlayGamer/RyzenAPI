-- Lua provided by RyzenAPI
-- Game: 542780

-- MAIN APPLICATION
addappid(542780)
-- Game: addappid(542780)

-- MAIN APP DEPOTS / PACKAGES
addappid(542781, 1, "a90e3bd423dd87ac25657bbaa825659876706cd103bbc353baf6fa60b03d0811")
