-- Lua provided by RyzenAPI
-- Game: Nurse Love Addiction

-- MAIN APPLICATION
addappid(485040)

-- MAIN APP DEPOTS / PACKAGES
addappid(485041, 1, "464615e4744c9f6fda39eae3c5f1b0bb0e7229dd3234192f2b892526c12ce7c5")
addappid(485042, 1, "b171ac451a7f631a8e65b99c0bd5120c379563ed326a6abf50c52bd629449f78")
addappid(485043, 1, "f357bf094b1063c79b285929c541752de40409fd07f5f55a4666f0539576f50c")
addappid(485044, 1, "e7adcfe2ef29ed8fb953b2c733432eff15c1bffc8c7e77e1998ef29b435c702e")
addappid(485045, 1, "3a40901e2d19944901ac8165720f16da33a9f831eac75a6d9daab4167996d594")
addappid(485046, 1, "4c05f4a078b155511ff49ae7371d1473b9967240c0f01ee15cc97f34f8865aa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
