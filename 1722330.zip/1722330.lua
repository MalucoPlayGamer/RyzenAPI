-- Lua provided by SkyAPI 
-- Game: AIDA Demo
addappid(1722330)
addappid(1722331, 1, "339907073330f6bf75e6a9a49b768960d979bf9e100be01c5357da0dcb6f94c6")
