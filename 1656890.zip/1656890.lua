-- Lua provided by RyzenAPI
-- Game: Hoverboard Chase

-- MAIN APPLICATION
addappid(1656890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656891, 1, "5df9b2303ce277625f4c91f035153446020a1c205cd204da56026dd43307c780")

