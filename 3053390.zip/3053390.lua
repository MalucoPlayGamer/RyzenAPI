-- Lua provided by RyzenAPI
-- Game: 家屋探索 -Japanese House Exploration-

-- MAIN APPLICATION
addappid(3053390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3053391, 1, "2bc9a8015a4854e6ed289e46a698ef96a3e54c2ea5f7601399e932278e881f43")

