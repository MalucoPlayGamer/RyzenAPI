-- Lua provided by RyzenAPI
-- Game: 家屋探索 -Japanese House Exploration-

-- MAIN APPLICATION
addappid(3053390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053391, 1, "2bc9a8015a4854e6ed289e46a698ef96a3e54c2ea5f7601399e932278e881f43")

