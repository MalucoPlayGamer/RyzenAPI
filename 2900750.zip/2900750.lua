-- Lua provided by RyzenAPI 
-- Game: AppID 2900750
addappid(2900750)
addappid(2900751, 1, "4438c379406611605091f9224093622c4dba3a8f259fe3f090d272193a206f13")
