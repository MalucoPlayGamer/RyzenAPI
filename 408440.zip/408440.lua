-- Lua provided by RyzenAPI
-- Game: Dream Factory

-- MAIN APPLICATION
addappid(408440)

-- MAIN APP DEPOTS / PACKAGES
addappid(408441, 1, "451ed584e0b1ac3f537fca5fbd8bc9f7d3369d4804e6e33b1123086c80dad972")

