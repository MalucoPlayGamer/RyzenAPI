-- Lua provided by RyzenAPI
-- Game: Ceramic Soul

-- MAIN APPLICATION
addappid(1967100)
-- Game: addappid(1967100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967101, 1, "1de645ce59f564c47185d31ace025ec9384e0cbc0a884c567809d54234a3e03f")
