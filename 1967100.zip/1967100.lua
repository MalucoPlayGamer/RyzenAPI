-- Lua provided by RyzenAPI
-- Game: Ceramic Soul

-- MAIN APPLICATION
addappid(1967100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1967101, 1, "1de645ce59f564c47185d31ace025ec9384e0cbc0a884c567809d54234a3e03f")

