-- Lua provided by RyzenAPI
-- Game: 353560

-- MAIN APPLICATION
addappid(353560)
-- Game: addappid(353560)

-- MAIN APP DEPOTS / PACKAGES
addappid(353561, 1, "14fd6268f2f59e2c03496a4ec246bb43e78e98f7f8c908291fd52bab1bc84ca5")
