-- Lua provided by RyzenAPI
-- Game: Flying Shark

-- MAIN APPLICATION
addappid(2022990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022991, 1, "87ec99a97af99b3efa2270fd8ba6089c64a8c09882004677e1e756c16a5a7ab6")
