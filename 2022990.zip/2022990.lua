-- Lua provided by RyzenAPI
-- Game: Flying Shark

-- MAIN APPLICATION
addappid(2022990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022991, 1, "87ec99a97af99b3efa2270fd8ba6089c64a8c09882004677e1e756c16a5a7ab6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
