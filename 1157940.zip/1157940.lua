-- Lua provided by SkyAPI 
-- Game: AppID 1157940
addappid(1157940)
addappid(1157941, 1, "3d6cc057441e70795edda889d44ae5075b3423835df7712583e9f567a360304d")
