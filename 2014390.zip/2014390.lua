-- Lua provided by RyzenAPI
-- Game: addappid(2014390)

-- MAIN APPLICATION
addappid(2014390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014391, 1, "0fd3c9a3f6fce6af47dbc8349c31f33f993e97d0fba4d3efedf136e5d2e1edda")
addappid(2014392, 1, "ddc1a77d33e03a28a05fcd2c0da7facb3cc5ea8d0bc2bdd6a26bd2ababefb72a")
