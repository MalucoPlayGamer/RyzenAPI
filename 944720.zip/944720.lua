-- Lua provided by RyzenAPI
-- Game: Hellbanger

-- MAIN APPLICATION
addappid(944720)
-- Game: addappid(944720)

-- MAIN APP DEPOTS / PACKAGES
addappid(944721, 1, "f9b7f1e405a3ae08b7d2840adb200d462f1b8feaea11bd47a5c8dd0960b31c72")
