-- Lua provided by RyzenAPI
-- Game: The Dark Queen of Mortholme

-- MAIN APPLICATION
addappid(3587610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587611,0,"9f4086779aebd132bebd7d39a5b6d294e2b31219df6d5df5dab4d06e44c03389")

