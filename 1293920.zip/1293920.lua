-- Lua provided by RyzenAPI
-- Game: 3D Hentai Checkers

-- MAIN APPLICATION
addappid(1293920)
addappid(1349700)
addappid(1450430)
addappid(1704280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293921, 1, "295a71c77c79f9e2014023e865fa01b4c3dbf576823a4f53bedbfa6920b51c11")