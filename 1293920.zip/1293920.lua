-- Lua provided by SkyAPI 
-- Game: AppID 1293920
addappid(1293920)
addappid(1293921, 1, "295a71c77c79f9e2014023e865fa01b4c3dbf576823a4f53bedbfa6920b51c11")
