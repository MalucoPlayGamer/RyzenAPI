-- Lua provided by RyzenAPI
-- Game: 1293920

-- MAIN APPLICATION
addappid(1293920)
-- Game: addappid(1293920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293921, 1, "295a71c77c79f9e2014023e865fa01b4c3dbf576823a4f53bedbfa6920b51c11")
