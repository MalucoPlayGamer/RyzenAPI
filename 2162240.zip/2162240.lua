-- Lua provided by RyzenAPI 
-- Game: AppID 2162240
addappid(2162240)
addappid(2162241, 1, "0f7dcee6a79e2b99e1d15e99f6bd375f3e063b6d42c479116ff548f2dbbdf88a")
addappid(2162242, 1, "89e2a94f49385f67f98880712865ace508fb12228913248c3402df753f61fe94")
