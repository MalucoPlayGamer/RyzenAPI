-- Lua provided by RyzenAPI
-- Game: Game: AppID 675870

-- MAIN APPLICATION
addappid(675870)
-- Game: addappid(675870)

-- MAIN APP DEPOTS / PACKAGES
addappid(675871, 1, "5114ebceae14b3c3e6a7a41a2cba2b4187ec0daa6b5673e688b0fcd6f41513b5")
addappid(675872, 1, "ff55e69d764ef00de040826fbcd301a58784aab44e0226239756e6fb991c1521")
addappid(675874, 1, "92d33973c57596963bdf6c4ecb6794ba8e64a889e90b0e56e05dde353392942f")
