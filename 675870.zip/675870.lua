-- Lua provided by RyzenAPI
-- Game: AppID 675870

-- MAIN APPLICATION
addappid(675870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(675871, 1, "5114ebceae14b3c3e6a7a41a2cba2b4187ec0daa6b5673e688b0fcd6f41513b5")
addappid(675872, 1, "ff55e69d764ef00de040826fbcd301a58784aab44e0226239756e6fb991c1521")
addappid(675874, 1, "92d33973c57596963bdf6c4ecb6794ba8e64a889e90b0e56e05dde353392942f")

