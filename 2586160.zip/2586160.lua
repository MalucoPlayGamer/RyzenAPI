-- Lua provided by RyzenAPI
-- Game: addappid(2586160)

-- MAIN APPLICATION
addappid(2586160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586161, 1, "c5710c3cb0ff2c4791c1e84feae6e02591107fca0d6a45847581cafd85aacdf9")
