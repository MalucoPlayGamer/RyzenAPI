-- Lua provided by SkyAPI 
-- Game: Paper Planes
addappid(2586160)
addappid(2586161, 1, "c5710c3cb0ff2c4791c1e84feae6e02591107fca0d6a45847581cafd85aacdf9")
