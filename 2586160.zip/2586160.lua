-- Lua provided by RyzenAPI
-- Game: Paper Planes

-- MAIN APPLICATION
addappid(2586160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586161, 1, "c5710c3cb0ff2c4791c1e84feae6e02591107fca0d6a45847581cafd85aacdf9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
