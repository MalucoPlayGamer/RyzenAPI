-- Lua provided by RyzenAPI
-- Game: Axan Ships - Low Poly

-- MAIN APPLICATION
addappid(1080060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1080061, 1, "8478df9e60936ab752185e9d1d71684ce7cf1e5a22fd857bf03382b02de6458d")
