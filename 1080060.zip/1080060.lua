-- Lua provided by RyzenAPI
-- Game: AppID 1080060

-- MAIN APPLICATION
addappid(1080060)
-- Game: addappid(1080060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080061, 1, "8478df9e60936ab752185e9d1d71684ce7cf1e5a22fd857bf03382b02de6458d")
