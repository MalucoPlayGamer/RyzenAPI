-- Lua provided by RyzenAPI 
-- Game: Alien Duel Elements
addappid(1450620)
addappid(1450621, 1, "3f000771f2d597abbda02200af917342e78faa5a287f5c401e786584fbf3d3d4")
