-- Lua provided by RyzenAPI
-- Game: 255480

-- MAIN APPLICATION
addappid(255480)
-- Game: addappid(255480)

-- MAIN APP DEPOTS / PACKAGES
addappid(255481, 1, "280addab6a3a224d1b4c245b3778ac8658b447284c8d41ed73e4bc027d7e6327")
