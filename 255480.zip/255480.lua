-- Lua provided by RyzenAPI
-- Game: AppID 255480

-- MAIN APPLICATION
addappid(255480)

-- MAIN APP DEPOTS / PACKAGES
addappid(255481, 1, "280addab6a3a224d1b4c245b3778ac8658b447284c8d41ed73e4bc027d7e6327")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
