-- Lua provided by SkyAPI 
-- Game: They Always Run
addappid(1585440)
addappid(1585441, 1, "135558803d754d29c9752c424adef6d087ffbda659d9a285711e15267dcd8329")
