-- Lua provided by RyzenAPI
-- Game: Game: They Always Run

-- MAIN APPLICATION
addappid(1585440)
-- Game: addappid(1585440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585441, 1, "135558803d754d29c9752c424adef6d087ffbda659d9a285711e15267dcd8329")
