-- Lua provided by SkyAPI 
-- Game: Border Bots VR
addappid(874440)
addappid(874441, 1, "3fd4a6a445c203afb7d529cd0aa0e3b85c9e1e8ebe4dd568a8793269e002587d")
