-- Lua provided by RyzenAPI
-- Game: Border Bots VR

-- MAIN APPLICATION
addappid(874440)
-- Game: addappid(874440)

-- MAIN APP DEPOTS / PACKAGES
addappid(874441, 1, "3fd4a6a445c203afb7d529cd0aa0e3b85c9e1e8ebe4dd568a8793269e002587d")
