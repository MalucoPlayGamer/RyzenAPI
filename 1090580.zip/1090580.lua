-- Lua provided by RyzenAPI
-- Game: AppID 1090580

-- MAIN APPLICATION
addappid(1090580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090581, 1, "388e6d688c55881ef3ca0d5972fddb6e80de892bef9a21b3dd71fdd81d938dc6")

