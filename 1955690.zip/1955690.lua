-- Lua provided by RyzenAPI
-- Game: 1955690

-- MAIN APPLICATION
addappid(1955690)
-- Game: addappid(1955690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955691, 1, "df4a0c9f503701496cbba6bb1850788d3a5e7d8a4fa0798d3951cf226c37fabf")
