-- Lua provided by RyzenAPI
-- Game: addappid(2717570)

-- MAIN APPLICATION
addappid(2717570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717571, 1, "273f0b1373cc4c2af5ae8fe2e5d92e8bc63a412f8a24c8c39421d0e4f8817781")
