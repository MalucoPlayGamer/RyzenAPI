-- Lua provided by RyzenAPI
-- Game: Find the Demon 恶魔鉴定守则

-- MAIN APPLICATION
addappid(2717570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717571, 1, "273f0b1373cc4c2af5ae8fe2e5d92e8bc63a412f8a24c8c39421d0e4f8817781")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
