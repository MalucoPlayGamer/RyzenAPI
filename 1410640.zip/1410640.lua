-- Lua provided by RyzenAPI
-- Game: Game: Syberia: The World Before

-- MAIN APPLICATION
addappid(1410640)
addappid(1724920)
-- Game: addappid(1410640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410641, 1, "b0484403336404a568c289234bdcc12b055e42f8d0a10764f947281a11ac67b0")
