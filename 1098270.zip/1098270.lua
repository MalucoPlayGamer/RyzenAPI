-- Lua provided by RyzenAPI
-- Game: ColdSide

-- MAIN APPLICATION
addappid(1098270)
addappid(1566000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1098271, 1, "06ae06196c4ec91cc0936330a0f5886b021e6aa369710192a32b90cfec015654")
addappid(1098272, 1, "30d8ca74c9d2efcba2b59c0974da1cf9b75332bf7c66da15dfc5e9f4af6c504c")
addappid(1098273, 1, "40bd7794b26af8be24c13990119a3628c64f2bfe120652daae1005ac253dbefa")
addappid(1538000, 0, "3aad4d4867ea0c9a74aa2f6da68830309a170e592716bf22a2bb62f8acb63212")

