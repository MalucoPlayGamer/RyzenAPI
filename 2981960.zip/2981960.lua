-- Lua provided by RyzenAPI
-- Game: addappid(2981960)

-- MAIN APPLICATION
addappid(2981960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981961, 1, "a354f0bacf1a92c4d62d95e4e3d216b4e3a7b3b46fb51846a3ec82043823ab40")
