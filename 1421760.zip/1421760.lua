-- Lua provided by RyzenAPI
-- Game: What Comes After

-- MAIN APPLICATION
addappid(1421760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421761, 1, "2baced43a486c86641dcc7b1eec77189a5595f68bdbc1f23a78a04076f7e1749")
addappid(1421762, 1, "d0e9cafa5b66d12404b2dea749a460d86a4e94f921cccde09d4fc54ab006d3de")

