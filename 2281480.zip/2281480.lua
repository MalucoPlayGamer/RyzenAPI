-- Lua provided by RyzenAPI
-- Game: addappid(2281480)

-- MAIN APPLICATION
addappid(2281480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281481, 1, "31de3d902f0c66ed8844ae62b4448ca1e061b3e047dc7518fc5f44bcc0a5044c")
