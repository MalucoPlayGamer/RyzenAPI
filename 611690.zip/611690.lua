-- Lua provided by RyzenAPI
-- Game: Game: AppID 611690

-- MAIN APPLICATION
addappid(611690)
-- Game: addappid(611690)

-- MAIN APP DEPOTS / PACKAGES
addappid(611691, 1, "14df1957ad573bee034391ab26eac7ce41e58a5d7b5dccb701e85959b5713c8b")
