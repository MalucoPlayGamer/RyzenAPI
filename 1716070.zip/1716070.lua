-- Lua provided by RyzenAPI
-- Game: Smart Home Design

-- MAIN APPLICATION
addappid(1716070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716072,0,"797c82a29be84f346f00b71b18c46618cee21c5ad8c4196169b4da27db0f3055")

