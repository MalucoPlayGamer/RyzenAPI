-- Lua provided by RyzenAPI
-- Game: Evil Pumpkin: The Lost Halloween

-- MAIN APPLICATION
addappid(300360)

-- MAIN APP DEPOTS / PACKAGES
addappid(300361, 1, "5302d696499d1669d7717801dad809d95dfd095f14347d19a5d3a91e8084efa2")
addappid(300366, 1, "d2bae8c0070e9f1a360e2e98f63d7a640e79c4ef5940e1dd0e0c05288662f6d1")
addappid(328770, 0, "6fcfa37a1b0e880ed40a259df2dc3c95e9c00a4e96ee50966508b270f603f1f9")

