-- Lua provided by RyzenAPI 
-- Game: AppID 944080
addappid(944080)
addappid(944081, 1, "1d33e995c102ac6d11b6f2407479abe948a4241acd8e1bbb999c2a4cdbe656fe")
