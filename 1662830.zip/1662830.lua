-- Lua provided by RyzenAPI
-- Game: 1662830

-- MAIN APPLICATION
addappid(1662830)
-- Game: addappid(1662830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662831, 1, "bb9c9568d6ba24ebdf5785fd9ddbdac272c5eec4315db928d8f5074c7f7a2b01")
