-- Lua provided by RyzenAPI
-- Game: Adventure with the Goddess

-- MAIN APPLICATION
addappid(2258960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258961, 1, "3423c8883ae60580ee152d8f9fab00629c4061ecaa9a1571e44a2af1dbefd05f")
addappid(2258980, 0, "7db4a08a53a228250e7094c0354045aa6b029d239ff68cb266947eff3712a7ca")
