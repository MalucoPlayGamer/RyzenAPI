-- Lua provided by RyzenAPI
-- Game: Backrooms: Exploration

-- MAIN APPLICATION
addappid(3423660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423661, 1, "8da956d075b2876ae788d40f7ae3d006aa22d46252759ada79533fd023c7680b")

