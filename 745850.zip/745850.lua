-- Lua provided by RyzenAPI
-- Game: AppID 745850

-- MAIN APPLICATION
addappid(745850)

-- MAIN APP DEPOTS / PACKAGES
addappid(745851, 1, "c875f9d87930aab4d4a28fe8d5eb23245523016f986988b0f3ac76d0de91c756")
addappid(947690, 0, "94bc61923ee8170f61d47f1a3a1ba108e0c22648b93c4f4724fdc0cb207cb490")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
