-- Lua provided by RyzenAPI
-- Game: 3097930

-- MAIN APPLICATION
addappid(3097930)
-- Game: addappid(3097930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097931, 1, "e6cef6fa3e9ea119c6be4b9da1144c557296512cd738b49d125e3e596abc6cf1")
