-- Lua provided by RyzenAPI
-- Game: Paddle Battle

-- MAIN APPLICATION
addappid(655630)
-- Game: addappid(655630)

-- MAIN APP DEPOTS / PACKAGES
addappid(655631, 1, "7429f27b7a19dcf4c72af58a3222282093f84a292c5ef6cfcab6cb57795a72a3")
