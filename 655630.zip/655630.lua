-- Lua provided by RyzenAPI
-- Game: Paddle Battle

-- MAIN APPLICATION
addappid(655630)

-- MAIN APP DEPOTS / PACKAGES
addappid(655631, 1, "7429f27b7a19dcf4c72af58a3222282093f84a292c5ef6cfcab6cb57795a72a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
