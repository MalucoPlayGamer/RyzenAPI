-- Lua provided by RyzenAPI
-- Game: Gemstone Keeper

-- MAIN APPLICATION
addappid(522080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(522081,0,"bf3378b62cfbe0a8a327bbf4f8c492a69d692958558e750d6fb54a3b8cc34a77")

