-- Lua provided by RyzenAPI
-- Game: Gemstone Keeper

-- MAIN APPLICATION
addappid(522080)

-- MAIN APP DEPOTS / PACKAGES
addappid(522081,0,"bf3378b62cfbe0a8a327bbf4f8c492a69d692958558e750d6fb54a3b8cc34a77")

