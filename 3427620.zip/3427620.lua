-- Lua provided by RyzenAPI
-- Game: Locked in Temptation

-- MAIN APPLICATION
addappid(3427620)
addappid(3456430)
addappid(3456670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427621, 1, "80c213b42de11f37c994633ad9882cd7f2d37ae3bfd332d851c4dda7cc034283")
