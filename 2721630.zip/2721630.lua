-- Lua provided by RyzenAPI
-- Game: The Symbiant Re:Union Demo

-- MAIN APPLICATION
addappid(2721630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721631, 1, "2f6b5f79300c709ae7cd600256914f2d09c2c69188ae255672e8b2e9654649ec")

