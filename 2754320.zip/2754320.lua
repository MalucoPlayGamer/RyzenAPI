-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2754320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754320,0,"4834c2ef9007ee1281446d2c33ea439122e9876a82dc6619651ee15571801ffb")
