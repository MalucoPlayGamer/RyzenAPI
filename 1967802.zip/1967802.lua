-- Lua provided by RyzenAPI
-- Game: Beat Saber - Bomfunk MC's - Freestyler

-- MAIN APPLICATION
addappid(1967802)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967802,0,"7a0573ab2a742f4d80b4eb038c3c71e53606ec6ac1edec6aea66f859849a11e6")
