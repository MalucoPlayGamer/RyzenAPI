-- Lua provided by RyzenAPI
-- Game: Game: SNOW BROS. SPECIAL: ANNIVERSARY EDITION

-- MAIN APPLICATION
addappid(3107890)
-- Game: addappid(3107890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107891, 1, "159cce2b4c32e927f294bb9d4b339f1b112acf522ed28dbd81bcf15aa964ff3d")
