-- Lua provided by RyzenAPI
-- Game: Stop Sign VR Tools

-- MAIN APPLICATION
addappid(1196450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196451, 1, "7d4e3e375f97176e1f7c69e9c5d545972d3f21862cd162b48c223802382fe9cd")
