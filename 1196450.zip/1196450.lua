-- Lua provided by RyzenAPI
-- Game: Stop Sign VR Tools

-- MAIN APPLICATION
addappid(1196450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196451, 1, "7d4e3e375f97176e1f7c69e9c5d545972d3f21862cd162b48c223802382fe9cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
