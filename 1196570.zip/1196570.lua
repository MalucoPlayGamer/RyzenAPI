-- Lua provided by RyzenAPI
-- Game: Suzunaan on Fire

-- MAIN APPLICATION
addappid(1196570)
addappid(2151680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196571, 1, "ecfd7a3947f2d65ba5cb96d618f6851a229d28be7befba0f4c0ff8722d08357b")
