-- Lua provided by RyzenAPI
-- Game: 巨龙猎手

-- MAIN APPLICATION
addappid(2214370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214371, 1, "bf2d328835760073b2bb34b00851c05bf212acac91ac735beab63151f17f1276")

