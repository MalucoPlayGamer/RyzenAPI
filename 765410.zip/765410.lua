-- Lua provided by RyzenAPI
-- Game: Game: Bean Battles

-- MAIN APPLICATION
addappid(765410)
-- Game: addappid(765410)

-- MAIN APP DEPOTS / PACKAGES
addappid(765411, 1, "34f46b60e1d363714a7ca131730300636daa171b92978307ba8821dbddf9eafc")
