-- Lua provided by RyzenAPI
-- Game: 2126620

-- MAIN APPLICATION
addappid(2126620)
-- Game: addappid(2126620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126621, 1, "c1528706fa9f9a0ce8ddbe18ecbc01ff83f92e92175e767ef4005c38ac6d9b9c")
