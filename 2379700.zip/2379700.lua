-- Lua provided by RyzenAPI
-- Game: 2379700

-- MAIN APPLICATION
addappid(2379700)
-- Game: addappid(2379700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379701, 1, "3c1b3df58987fd5aeafdecdb18c585f7a3be902f41e310d9df64776828a609b6")
