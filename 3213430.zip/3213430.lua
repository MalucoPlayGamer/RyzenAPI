-- Lua provided by RyzenAPI
-- Game: 3213430

-- MAIN APPLICATION
addappid(3213430)
-- Game: addappid(3213430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213432,0,"021f9f1ff66828a848df7b7ca94480c5223b90eba0cd9050ccda398751330ee5")
