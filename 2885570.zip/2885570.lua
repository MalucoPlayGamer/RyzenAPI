-- Lua provided by RyzenAPI
-- Game: Game: 单词涂图乐

-- MAIN APPLICATION
addappid(2885570)
-- Game: addappid(2885570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885571, 1, "755a34eb2dc38176510f3f82049093b5e042d114fa50994e88864b7df18de967")
