-- Lua provided by RyzenAPI
-- Game: AppID 1098510

-- MAIN APPLICATION
addappid(1098510)
-- Game: addappid(1098510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098511, 1, "a8f16d1037ed078c7db5548c82e64b7e5b72fe958f7f1dda6d1b43550711b5e5")
