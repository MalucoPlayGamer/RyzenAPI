-- Lua provided by RyzenAPI
-- Game: addappid(942910)

-- MAIN APPLICATION
addappid(942910)

-- MAIN APP DEPOTS / PACKAGES
addappid(942911, 1, "475ca0125d3f962716661bb3cfbed507602ccd16ccf1509b66bd6620b6b016f0")
