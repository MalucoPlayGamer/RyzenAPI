-- Lua provided by RyzenAPI
-- Game: addappid(3275010)

-- MAIN APPLICATION
addappid(3275010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3275011, 1, "a65ad5083ef65cb6ed7a3aa2b234ead29b4d0068c22a229791d9ce890801bde7")
