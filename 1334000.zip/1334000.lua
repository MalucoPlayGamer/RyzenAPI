-- Lua provided by RyzenAPI
-- Game: Wordle

-- MAIN APPLICATION
addappid(1334000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334001, 1, "3edbcc88cb31549eee0530cea827d19408fdeaa8344d223ce52c79269b37d4d7")
addappid(1334002, 1, "e876b1ab19486bea26a1af43165ab1060ef15f6ebd838a9a47a37486b8b1fa6f")
addappid(1334003, 1, "9fa2b6cf2ec9f32f8820aa3e157c35b9281c2b9e215303e5be73129577336517")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1532570)
addappid(1532580)
addappid(1532610)
addappid(1532630)
