-- Lua provided by RyzenAPI
-- Game: addappid(1315630)

-- MAIN APPLICATION
addappid(1315630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315631, 1, "44f5a819e70fa73bf452c0daf83803e10eeff1f0018266b26e745ed708ec58e6")
