-- Lua provided by RyzenAPI
-- Game: Biped 2

-- MAIN APPLICATION
addappid(3801980) -- Biped 2 - Full Entitlement

-- MAIN APP DEPOTS / PACKAGES
addappid(2560240, 1, "0fef022272438eb1ccfa5c245f74175a6af37003860a2e249a32d008f715d4ec") -- Biped 2
addappid(2560241, 1, "e2316d00922f6f267842f1e95fe47ce413cf57346e675fde73f7e10f5616f5cf") -- Depot 2560241
addtoken(3801980, "2598310342756208508")

