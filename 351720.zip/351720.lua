-- Lua provided by SkyAPI 
-- Game: Zotrix - Solar Division
addappid(351720)
addappid(351721, 1, "e3d2a3f33dda3bb86238c2368957292156d0d0084cc819dd72dd45530f34af34")
addappid(351722, 1, "033c101f5fbe87c67e83b7180f62a84ba06a2dd891f59a6da1756773e4d46760")
addappid(351723, 1, "ed7567f58339412ee817049236a371f320cf4caf4b2aba1b120d1b7e2587894f")
