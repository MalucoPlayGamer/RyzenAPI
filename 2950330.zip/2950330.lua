-- Lua provided by RyzenAPI
-- Game: Game: Journey to Foundation

-- MAIN APPLICATION
addappid(2950330)
-- Game: addappid(2950330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950331, 1, "d7b06dbcd017996f101c7e28fee389684009b4b867621ad36e9b3c84fa904bf1")
