-- Lua provided by RyzenAPI
-- Game: AppID 718030

-- MAIN APPLICATION
addappid(718030)
addappid(772010)

-- MAIN APP DEPOTS / PACKAGES
addappid(718031, 1, "75da3ca542585d4af56087449b2e4f8fe38dbd3fe0946a20dc401e5e697d67c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
