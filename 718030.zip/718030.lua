-- Lua provided by RyzenAPI
-- Game: addappid(718030)

-- MAIN APPLICATION
addappid(718030)
addappid(772010)

-- MAIN APP DEPOTS / PACKAGES
addappid(718031, 1, "75da3ca542585d4af56087449b2e4f8fe38dbd3fe0946a20dc401e5e697d67c4")
