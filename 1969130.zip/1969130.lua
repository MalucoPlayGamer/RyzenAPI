-- Lua provided by RyzenAPI
-- Game: Trash Patrol - Academic Version

-- MAIN APPLICATION
addappid(1969130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1969131, 1, "6c5ba7cd3cb1cdaf1339116b0239367dbc1754f764079c6a0b1b3476a8163e34")

