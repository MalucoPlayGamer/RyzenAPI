-- Lua provided by RyzenAPI
-- Game: Trash Patrol - Academic Version

-- MAIN APPLICATION
addappid(1969130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969131, 1, "6c5ba7cd3cb1cdaf1339116b0239367dbc1754f764079c6a0b1b3476a8163e34")
