-- Lua provided by RyzenAPI
-- Game: Spoils of Plunder

-- MAIN APPLICATION
addappid(982250)

-- MAIN APP DEPOTS / PACKAGES
addappid(982251, 1, "544be916d2a7b9e6544172d8dc1cdd3576eda31e6a884e0bdcc704e5cdd5ec26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
