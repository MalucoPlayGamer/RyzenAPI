-- Lua provided by RyzenAPI
-- Game: Spoils of Plunder

-- MAIN APPLICATION
addappid(982250)

-- MAIN APP DEPOTS / PACKAGES
addappid(982251, 1, "544be916d2a7b9e6544172d8dc1cdd3576eda31e6a884e0bdcc704e5cdd5ec26")
