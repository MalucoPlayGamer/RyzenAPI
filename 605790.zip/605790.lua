-- Lua provided by RyzenAPI
-- Game: Game: Queen's Tales: The Beast and the Nightingale Collector's Edition

-- MAIN APPLICATION
addappid(605790)
-- Game: addappid(605790)

-- MAIN APP DEPOTS / PACKAGES
addappid(605791, 1, "93b65d832361565c765cbab70e55a29726aef95d2e64d9965ebe158f9e9566d9")
