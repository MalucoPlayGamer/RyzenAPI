-- Lua provided by RyzenAPI
-- Game: Game: Coin Treasures

-- MAIN APPLICATION
addappid(1773320)
-- Game: addappid(1773320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773321, 1, "72e3886ed7cafd4143843c5e849e14dc11fbbc73fcb38e23fcb01b16ef3fd7c5")
