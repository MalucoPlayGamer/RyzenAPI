-- Lua provided by RyzenAPI
-- Game: 1455070

-- MAIN APPLICATION
addappid(1455070)
-- Game: addappid(1455070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455071, 1, "859051ddbff2bdd55f81b830d8a1a8e5c689f8bae2a0ec1d121e2aa1a2759a18")
addappid(2718880, 0, "445b6759599ab33ea309b566582932fd0dc2d59f88bbc5f657a89277163de3fb")
