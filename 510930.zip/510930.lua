-- Lua provided by RyzenAPI
-- Game: Game: AppID 510930

-- MAIN APPLICATION
addappid(510930)
-- Game: addappid(510930)

-- MAIN APP DEPOTS / PACKAGES
addappid(510931, 1, "f4f30865e48e0b411759e9f6a28196b51811534c4c4beec306872f6998aa3463")
