-- Lua provided by SkyAPI 
-- Game: Poker Superstars II
addappid(4100)
addappid(4101, 1, "768dee220be9e6c4b0f22d6ec708bdeff657d011fb5cba04ce0eec618170a585")
