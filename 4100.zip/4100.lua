-- Lua provided by RyzenAPI
-- Game: Game: Poker Superstars II

-- MAIN APPLICATION
addappid(4100)
-- Game: addappid(4100)

-- MAIN APP DEPOTS / PACKAGES
addappid(4101, 1, "768dee220be9e6c4b0f22d6ec708bdeff657d011fb5cba04ce0eec618170a585")
