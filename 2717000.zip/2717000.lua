-- Lua provided by RyzenAPI
-- Game: Operation Save the Girl: Code X

-- MAIN APPLICATION
addappid(2717000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717001, 1, "57b112bbbbdd2f82cb941a14e7afef41efcc1c7aecf5dd8f6e5e35698b895d28")
