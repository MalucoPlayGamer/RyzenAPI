-- Lua provided by SkyAPI 
-- Game: Colony
addappid(3194950)
addappid(3194951, 1, "f1a5bf7e9494ce3236ad0cda7e402458d168dd0e4ddb76c49cdf44b87e1fe253")
