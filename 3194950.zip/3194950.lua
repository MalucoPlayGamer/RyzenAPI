-- Lua provided by RyzenAPI
-- Game: Colony

-- MAIN APPLICATION
addappid(3194950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194951, 1, "f1a5bf7e9494ce3236ad0cda7e402458d168dd0e4ddb76c49cdf44b87e1fe253")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
