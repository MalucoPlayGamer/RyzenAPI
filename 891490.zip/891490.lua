-- Lua provided by RyzenAPI
-- Game: 891490

-- MAIN APPLICATION
addappid(891490)
-- Game: addappid(891490)

-- MAIN APP DEPOTS / PACKAGES
addappid(891491, 1, "794618e527a8549fdeb3778d9a5185317ea67ee9b4f45ae10c330667919fa16f")
