-- Lua provided by RyzenAPI
-- Game: Capsule

-- MAIN APPLICATION
addappid(891490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(891491, 1, "794618e527a8549fdeb3778d9a5185317ea67ee9b4f45ae10c330667919fa16f")

