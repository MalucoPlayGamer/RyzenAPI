-- Lua provided by RyzenAPI
-- Game: 1679210

-- MAIN APPLICATION
addappid(1679210)
-- Game: addappid(1679210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679211, 1, "2dd830e6c1b2e9267e86eccd1af31de31c4bc92c2b0a6e5c3535354221168775")
