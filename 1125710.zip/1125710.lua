-- Lua provided by RyzenAPI
-- Game: 1125710

-- MAIN APPLICATION
addappid(1125710)
-- Game: addappid(1125710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125711, 1, "524bd41a31647f0bd1a4bfa9204ea59fb7657be623ca3ebf4d65d43d64ef36ee")
