-- Lua provided by RyzenAPI
-- Game: Game: Quantum Rail

-- MAIN APPLICATION
addappid(2481340)
-- Game: addappid(2481340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481341, 1, "98969f6e08fcf6f4481e3a9fcbeb3f085d3bdab1d6e8126be5eeb84adcbc7e82")
