-- Lua provided by RyzenAPI
-- Game: Quantum Rail

-- MAIN APPLICATION
addappid(2481340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481341, 1, "98969f6e08fcf6f4481e3a9fcbeb3f085d3bdab1d6e8126be5eeb84adcbc7e82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
