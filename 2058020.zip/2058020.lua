-- Lua provided by RyzenAPI
-- Game: addappid(2058020)

-- MAIN APPLICATION
addappid(2058020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058021, 1, "4526a4871c127f7b00b69ef927efa04357020a437ca137dc74a7c568789add7b")
