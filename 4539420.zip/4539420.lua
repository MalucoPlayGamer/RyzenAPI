-- Lua provided by RyzenAPI
-- Game: Yamasen-Chan's Hermit Home Designer+

-- MAIN APPLICATION
addappid(4539420) -- Yamasen-Chan's Hermit Home Designer+

-- MAIN APP DEPOTS / PACKAGES
addappid(4539425, 1, "2b54530ab0bbad61b1303f8a775ceb19e1508085bb78b17cde17c87ab8fb4990") -- Depot 4539425
addappid(4539426, 1, "f3f4da35db33ceba33429e2283912591ef10c8ed3f8c02bab714d82817bc146a") -- Depot 4539426

