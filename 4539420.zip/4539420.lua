-- 4539420's Lua and Manifest Created by Hubcap Manifest
-- Yamasen-Chan's Hermit Home Designer+
-- Created: August 04, 2026 at 09:25:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4539420) -- Yamasen-Chan's Hermit Home Designer+
-- MAIN APP DEPOTS
addappid(4539425, 1, "2b54530ab0bbad61b1303f8a775ceb19e1508085bb78b17cde17c87ab8fb4990") -- Depot 4539425
setManifestid(4539425, "3930568160481376169", 856326619)
addappid(4539426, 1, "f3f4da35db33ceba33429e2283912591ef10c8ed3f8c02bab714d82817bc146a") -- Depot 4539426
setManifestid(4539426, "996570936524913059", 891951184)