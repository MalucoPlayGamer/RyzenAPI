-- Lua provided by RyzenAPI
-- Game: 1822910

-- MAIN APPLICATION
addappid(1822910)
-- Game: addappid(1822910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822911, 1, "f3c079c91227b9258b1c619ad8db571fcdaa8933d9cd100b9789939c7c59714b")
