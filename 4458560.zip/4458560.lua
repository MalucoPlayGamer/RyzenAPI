-- Lua provided by RyzenAPI
-- Game: addappid(4458560)

-- MAIN APPLICATION
addappid(4458560)

-- MAIN APP DEPOTS / PACKAGES
addappid(4458561, 1, "daa06c73a9acece6f6cf2b10577b396153969234ad900cd9b7ca1f79afda3775")
