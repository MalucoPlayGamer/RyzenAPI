-- Lua provided by RyzenAPI
-- Game: The Repair House Demo

-- MAIN APPLICATION
addappid(2247740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247741, 1, "9b52a8be7034d90365bc6633f2b5cda5ce6ffcf49672e410216d7c4da9385a51")

