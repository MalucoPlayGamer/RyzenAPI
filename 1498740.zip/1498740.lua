-- Lua provided by RyzenAPI
-- Game: Troublemaker

-- MAIN APPLICATION
addappid(1498740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498741, 1, "1b731d335112e8f7b31426874e3e46006774f269f46557d79346e7230babfadc")

