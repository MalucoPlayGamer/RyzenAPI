-- Lua provided by RyzenAPI
-- Game: Volgarr the Viking II

-- MAIN APPLICATION
addappid(2195140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195141, 1, "2cf19e87508aef9a19ef3b19276b8d5a69cfa7376ad6f358eb31856228fdca8d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
