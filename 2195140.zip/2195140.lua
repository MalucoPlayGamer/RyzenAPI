-- Lua provided by RyzenAPI
-- Game: 2195140

-- MAIN APPLICATION
addappid(2195140)
-- Game: addappid(2195140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195141, 1, "2cf19e87508aef9a19ef3b19276b8d5a69cfa7376ad6f358eb31856228fdca8d")
