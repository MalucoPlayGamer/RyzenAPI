-- Lua provided by RyzenAPI
-- Game: From Earth To Heaven

-- MAIN APPLICATION
addappid(1623090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623091, 1, "c940ab2e86379020e49573ab9c90f776c50bb4a61d764faa39d91be25fbb35d3")

