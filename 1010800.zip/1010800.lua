-- Lua provided by RyzenAPI
-- Game: Wallpaper Maker （造物主视频桌面）

-- MAIN APPLICATION
addappid(1010800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010801, 1, "0db2fbe8820e5e607759b4b89fd60ad57486231bf88e4d7782557aff037fafc4")

