-- Lua provided by RyzenAPI 
-- Game: AppID 2154730
addappid(2154730)
addappid(2154731, 1, "6812d00f66a5b39bae27820c297f74d8fc5c118e08445f074330ce0698c77ffc")
