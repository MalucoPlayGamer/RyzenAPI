-- Lua provided by RyzenAPI
-- Game: addappid(1705760)

-- MAIN APPLICATION
addappid(1705760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705761, 1, "01aaa34eb0caf82edd2676b5fbfb0bd3a8c07c314b4772bfc3d20be23671d135")
