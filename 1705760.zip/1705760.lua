-- Lua provided by RyzenAPI
-- Game: Payload

-- MAIN APPLICATION
addappid(1705760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705761, 1, "01aaa34eb0caf82edd2676b5fbfb0bd3a8c07c314b4772bfc3d20be23671d135")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
