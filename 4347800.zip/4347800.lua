-- Lua provided by RyzenAPI
-- Game: 勇者传承

-- MAIN APPLICATION
addappid(4347800)

