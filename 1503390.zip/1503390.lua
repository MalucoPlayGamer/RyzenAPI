-- Lua provided by RyzenAPI
-- Game: Drunk Soccer is the Best Soccer

-- MAIN APPLICATION
addappid(1503390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503391, 1, "8ba629a4bf945edd67f364fcf6c124252db89ce6afb5ae41b58ca1ddcb890d86")
