-- Lua provided by RyzenAPI
-- Game: Game: Viking Heroes

-- MAIN APPLICATION
addappid(1275330)
-- Game: addappid(1275330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275331, 1, "a41084a11aaa1bbf69dea5dfc8351eaa56f47170deb2be3002dc21db71672e24")
