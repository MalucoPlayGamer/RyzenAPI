-- Lua provided by RyzenAPI
-- Game: addappid(2669380)

-- MAIN APPLICATION
addappid(2669380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669381, 1, "090e1bcded479bdd950b9884d5966cfa9ee95438a9857d823c3d288f80a7ac70")
