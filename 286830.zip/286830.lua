-- Lua provided by RyzenAPI
-- Game: Game: Hard Truck Apocalypse: Arcade / Ex Machina: Arcade

-- MAIN APPLICATION
addappid(286830)
-- Game: addappid(286830)

-- MAIN APP DEPOTS / PACKAGES
addappid(286831, 1, "a14412302ff82e8dc35d78156c77450543b83529926c16200279d4e88865deac")
addappid(286832, 1, "34f48240baf35cffce6f6f336ea2d2fcaafcf90c6f9e6865c56a9cbefb9b5ddc")
addappid(286833, 1, "4470c11648032641ab90daf2d797fa0874f7ece4b03e3625525ca1c35ab8b98b")
