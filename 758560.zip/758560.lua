-- Lua provided by RyzenAPI
-- Game: Versus World

-- MAIN APPLICATION
addappid(758560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(758561, 1, "89f4f882018e53a4647701dd1a7808e4c0ce5aab93bc4b651b66d86c5273fd01")

