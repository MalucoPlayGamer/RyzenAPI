-- Lua provided by RyzenAPI
-- Game: AppID 758560

-- MAIN APPLICATION
addappid(758560)
-- Game: addappid(758560)

-- MAIN APP DEPOTS / PACKAGES
addappid(758561, 1, "89f4f882018e53a4647701dd1a7808e4c0ce5aab93bc4b651b66d86c5273fd01")
