-- Lua provided by RyzenAPI
-- Game: 919850

-- MAIN APPLICATION
addappid(919850)
-- Game: addappid(919850)

-- MAIN APP DEPOTS / PACKAGES
addappid(919851, 1, "7374126a1e1a4755a6c11436463a5e305c7fd9585afc92a0b9ade6f9619b1337")
