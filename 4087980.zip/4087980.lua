-- Lua provided by RyzenAPI
-- Game: Fickle Card Legend

-- MAIN APPLICATION
addappid(4087980)
-- Game: addappid(4087980)

-- MAIN APP DEPOTS / PACKAGES
addappid(4087981, 1, "27bb07dcccbf9439f1089605160d670d870b306e14aee47c9db12f5a90ad08f7")
