-- Lua provided by RyzenAPI
-- Game: AppID 975620

-- MAIN APPLICATION
addappid(975620)
addappid(1466980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(975621, 1, "b1eb3b74567b0e96516fe1ae6b39379aef6a161eaeba9796578909f0e383a2e9")

