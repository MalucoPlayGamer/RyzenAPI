-- Lua provided by RyzenAPI
-- Game: AppID 975620

-- MAIN APPLICATION
addappid(975620)

-- MAIN APP DEPOTS / PACKAGES
addappid(975621, 1, "b1eb3b74567b0e96516fe1ae6b39379aef6a161eaeba9796578909f0e383a2e9")

