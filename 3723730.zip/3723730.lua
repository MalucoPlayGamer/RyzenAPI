-- Lua provided by RyzenAPI
-- Game: addappid(3723730)

-- MAIN APPLICATION
addappid(3723730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723731, 1, "411918f6000169c0c29a43bbe35d93fbed1a1c93cda09f5e7fccfb648889f129")
