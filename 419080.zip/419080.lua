-- Lua provided by RyzenAPI
-- Game: Bridge Constructor Stunts

-- MAIN APPLICATION
addappid(419080)
-- Game: addappid(419080)

-- MAIN APP DEPOTS / PACKAGES
addappid(419081, 1, "cda8d2fd4130b89693d5aa7018177a3ff663ccf2dc4fb657fdec5b52ef6ed433")
addappid(419082, 1, "777a1cb9e4faea09c9e23bdfd1bbf7d4f8aef8bdce06dbb562d180eee0dbda83")
addappid(419083, 1, "1bef48a1855b02ae4c6be2691efac9a69d13f04cbdf5ed31b495e494e24f6264")
