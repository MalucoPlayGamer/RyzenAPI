-- Lua provided by RyzenAPI
-- Game: Bridge Constructor Stunts

-- MAIN APPLICATION
addappid(419080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(419081, 1, "cda8d2fd4130b89693d5aa7018177a3ff663ccf2dc4fb657fdec5b52ef6ed433")
addappid(419082, 1, "777a1cb9e4faea09c9e23bdfd1bbf7d4f8aef8bdce06dbb562d180eee0dbda83")
addappid(419083, 1, "1bef48a1855b02ae4c6be2691efac9a69d13f04cbdf5ed31b495e494e24f6264")

