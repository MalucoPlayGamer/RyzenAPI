-- Lua provided by RyzenAPI
-- Game: Shadows of Forbidden Gods

-- MAIN APPLICATION
addappid(1741640)
addappid(2855250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741641, 1, "37375cfe796e7fcb91c3cff89c4a3f46249b9e1e111f1c6292dd75650f225cb8")

