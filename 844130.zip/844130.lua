-- Lua provided by RyzenAPI
-- Game: Game: Future Proof

-- MAIN APPLICATION
addappid(844130)
-- Game: addappid(844130)

-- MAIN APP DEPOTS / PACKAGES
addappid(844131, 1, "139b74598a035652f739b7d30635bd0146107ee11112a3148b27997304169940")
