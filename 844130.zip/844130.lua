-- Lua provided by RyzenAPI 
-- Game: Future Proof
addappid(844130)
addappid(844131, 1, "139b74598a035652f739b7d30635bd0146107ee11112a3148b27997304169940")
