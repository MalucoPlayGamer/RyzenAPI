-- Lua provided by RyzenAPI
-- Game: Alien Shooter 2 - New Era

-- MAIN APPLICATION
addappid(2013300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2013301, 1, "dbded50c13027f0be0903f34687277f18c543cedeb319ffca534712173c01d0a")
addappid(2013302, 1, "937842847b205d9fd4ebf995a8dccb24db6be80aa94ec123684342f8b2553e5a")

