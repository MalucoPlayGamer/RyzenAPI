-- Lua provided by RyzenAPI 
-- Game: Alien Shooter 2 - New Era
addappid(2013300)
addappid(2013301, 1, "dbded50c13027f0be0903f34687277f18c543cedeb319ffca534712173c01d0a")
addappid(2013302, 1, "937842847b205d9fd4ebf995a8dccb24db6be80aa94ec123684342f8b2553e5a")
