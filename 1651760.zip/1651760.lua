-- Lua provided by RyzenAPI
-- Game: Japanese Puzzle

-- MAIN APPLICATION
addappid(1651760)
-- Game: addappid(1651760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651761, 1, "570d3c817ba54cdeb614e26b51a6ab917c68bb2cd5dfae56a723d7eae23caef9")
