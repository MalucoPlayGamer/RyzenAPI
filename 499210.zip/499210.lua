-- Lua provided by RyzenAPI
-- Game: Road Rage

-- MAIN APPLICATION
addappid(499210)

-- MAIN APP DEPOTS / PACKAGES
addappid(499211, 1, "39921ace9fdacf652caf29d0560a7f7ae739601ff7b29ebec6061afa5b7715d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
