-- Lua provided by RyzenAPI
-- Game: Road Rage

-- MAIN APPLICATION
addappid(499210)
-- Game: addappid(499210)

-- MAIN APP DEPOTS / PACKAGES
addappid(499211, 1, "39921ace9fdacf652caf29d0560a7f7ae739601ff7b29ebec6061afa5b7715d3")
