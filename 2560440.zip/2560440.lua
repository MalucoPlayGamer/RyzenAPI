-- Lua provided by RyzenAPI
-- Game: Noreya: The Gold Project Demo

-- MAIN APPLICATION
addappid(2560440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560441, 1, "576b50cdc5e6b97425ae4d98b8265068258e79eaa1ac4007022a4ae806912f59")
