-- Lua provided by RyzenAPI
-- Game: KAISERPUNK - Supporter Pack

-- MAIN APPLICATION
addappid(3587380)
-- Game: addappid(3587380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587381, 1, "36fce335c938e7a5d6dc60d0da4c77e28dc145b3c7975a05e88390f1c9eede33")
