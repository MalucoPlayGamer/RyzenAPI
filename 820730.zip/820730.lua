-- Lua provided by RyzenAPI 
-- Game: Adventure of a Lifetime
addappid(820730)
addappid(820731, 1, "98ff1b4cc682fe6aba9dbe943c8a1fa08ff8530354fe78a2b513fd0196d350d5")
addappid(820732, 1, "2c4c2b6358d731e369cc9b505fc82e1b04b5542a85d4e0e8a3e75503624350d6")
addappid(880240)
addappid(892300, 0, "8ea1952a3c6936c240176f3e8035ae322b5f7459eec1612a88400dac707c2a0a")
