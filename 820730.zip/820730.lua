-- Lua provided by RyzenAPI
-- Game: Adventure of a Lifetime

-- MAIN APPLICATION
addappid(820730)
addappid(880240)

-- MAIN APP DEPOTS / PACKAGES
addappid(820731, 1, "98ff1b4cc682fe6aba9dbe943c8a1fa08ff8530354fe78a2b513fd0196d350d5")
addappid(820732, 1, "2c4c2b6358d731e369cc9b505fc82e1b04b5542a85d4e0e8a3e75503624350d6")
addappid(892300, 0, "8ea1952a3c6936c240176f3e8035ae322b5f7459eec1612a88400dac707c2a0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
