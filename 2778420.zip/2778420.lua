-- Lua provided by RyzenAPI
-- Game: Pet Shop Simulator: Prologue

-- MAIN APPLICATION
addappid(2778420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778421, 1, "e97871929792e24af8e89c4c3d5612cf96524929291b8752a47d6ccd27ce56b7")
