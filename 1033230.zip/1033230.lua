-- Lua provided by SkyAPI 
-- Game: Sheep Collision
addappid(1033230)
addappid(1033231, 1, "5458d0f358cf4d7ad369fee7b5b649aa01be44cb43048f7c35c6aa972034e0de")
