-- Lua provided by RyzenAPI
-- Game: Game: AppID 1930640

-- MAIN APPLICATION
addappid(1930640)
-- Game: addappid(1930640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930641, 1, "34f2dbe198f377a668be963d6f33f0b8302368cdd4c052e1fd66a7934369845e")
addappid(2104360, 0, "f7da9d575a1f5096eccb03a231a1fb12710fe9ce7c2a0d809da42e6228acdbfe")
