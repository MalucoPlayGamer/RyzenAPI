-- Lua provided by RyzenAPI
-- Game: FlatOut 4: Total Insanity

-- MAIN APPLICATION
addappid(402130)

-- MAIN APP DEPOTS / PACKAGES
addappid(402131, 1, "680d7192d80a30c1d5451e530a424ad7e48856e62494f640e8091a9febfde1fe")
addappid(600590, 0, "6c17e869a165679532f82ff237d8abf19709ce2be903a36076c066bb2217b749")
addappid(600591, 0, "3c6a686ee4c5f44d5fe880dc0d56e0f0f82ad22571483fab4b60030235b8f3f4")
addappid(600592, 0, "29470ed66e032d13b57695e51371ad1d94552a6b91f0550971ca0617f29d8e62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
