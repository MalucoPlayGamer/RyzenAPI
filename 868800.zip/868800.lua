-- Lua provided by RyzenAPI
-- Game: addappid(868800)

-- MAIN APPLICATION
addappid(868800)

-- MAIN APP DEPOTS / PACKAGES
addappid(568572,0,"93fa27ad12519b92f4bc01d5aba57704e133d99aa81ad6055977d05e45ed38a5")
