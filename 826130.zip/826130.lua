-- Lua provided by RyzenAPI
-- Game: Pilferer

-- MAIN APPLICATION
addappid(826130)

-- MAIN APP DEPOTS / PACKAGES
addappid(826131, 1, "956da030d726c2c5f866d7b94816daadcd48838bbbcdd9860986523a2cfc2a88")
