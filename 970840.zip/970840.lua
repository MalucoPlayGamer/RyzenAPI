-- Lua provided by RyzenAPI
-- Game: Overpass™

-- MAIN APPLICATION
addappid(970840)
addappid(1115750)
addappid(1115751)
addappid(1115752)
addappid(1115753)

-- MAIN APP DEPOTS / PACKAGES
addappid(970842,0,"6b370ec605c8a28f476d6b473a5ef6e55fda09179648a87ab60fe27ae218f6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
