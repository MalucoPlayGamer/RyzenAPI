-- Lua provided by RyzenAPI
-- Game: 970840

-- MAIN APPLICATION
addappid(970840)
-- Game: addappid(970840)

-- MAIN APP DEPOTS / PACKAGES
addappid(970842,0,"6b370ec605c8a28f476d6b473a5ef6e55fda09179648a87ab60fe27ae218f6f5")
