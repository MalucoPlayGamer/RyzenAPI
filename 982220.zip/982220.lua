-- Lua provided by RyzenAPI
-- Game: AppID 982220

-- MAIN APPLICATION
addappid(982220)

-- MAIN APP DEPOTS / PACKAGES
addappid(982221, 1, "aa727fc64a33a2cb339ef2dcd08f2bba3bdb94e66a2ef042158fbc1000658dea")
