-- Lua provided by RyzenAPI 
-- Game: Miniparty
addappid(2971870)
addappid(2971871, 1, "03fb61ce64f34bd239d95e5c43ad5a22ae7bdabfb4453139c5830ad9d60c1ab7")
addappid(2971872, 1, "11d483172d90495c80f813103ed4d6e1181f49b490c6744fe01a43978baf8a53")
