-- Lua provided by RyzenAPI
-- Game: Kritika Global

-- MAIN APPLICATION
addappid(2088180)
-- Game: addappid(2088180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088181, 1, "a3d992ecffa172c22ba47acd35c375701a55a1aabcb8a0e6f31d84b69cd4f9b0")
