-- Lua provided by RyzenAPI 
-- Game: The Testing Chamber
addappid(1921900)
addappid(1921901, 1, "fc328a4e6186a5c62bd9614cf0e36d785b4b2f36f7d337085c90d87fa187290f")
