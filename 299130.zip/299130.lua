-- Lua provided by RyzenAPI
-- Game: Game: AppID 299130

-- MAIN APPLICATION
addappid(299130)
-- Game: addappid(299130)

-- MAIN APP DEPOTS / PACKAGES
addappid(299131, 1, "83325881e815451f8eeacef9a74ad89f7560442918e017be0596a094411e27e2")
