-- Lua provided by RyzenAPI
-- Game: Age of Fear: The Undead King GOLD

-- MAIN APPLICATION
addappid(832770)

-- MAIN APP DEPOTS / PACKAGES
addappid(972300,0,"a07c36f55d9f2919495f2d8ce2162915553c056e49b7af9cac905f249eafff37")
addappid(1087340,0,"796822b11f4ac57b933a2f8473969f32fe9285f36efec7bb638e5d1ae9fcb357")

