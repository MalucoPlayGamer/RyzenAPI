-- Lua provided by RyzenAPI
-- Game: 1709880

-- MAIN APPLICATION
addappid(1709880)
-- Game: addappid(1709880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709881, 1, "b43e55a4be57a87ddebc6885791528fec27b4941e0d0c6bd2b33cc7a07b329b6")
