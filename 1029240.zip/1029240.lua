-- Lua provided by RyzenAPI
-- Game: Hentai Survive Island

-- MAIN APPLICATION
addappid(1029240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029241, 1, "6e6819435e16aa9bf3b77dd57ca4c717775ab8838759b3cb3485e9b87dcc9dc9")
