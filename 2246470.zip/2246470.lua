-- Lua provided by RyzenAPI
-- Game: AppID 2246470

-- MAIN APPLICATION
addappid(2246470)
-- Game: addappid(2246470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246471, 1, "e33663120dbd54db9c7835c81acc62c106f45d41ea42938e08127ea14dfc25dc")
