-- Lua provided by RyzenAPI
-- Game: AppID 2631970

-- MAIN APPLICATION
addappid(2631970)
-- Game: addappid(2631970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631971, 1, "d182deedf7415d43e7389a9278cc034ebd119916237c1c3ffda3e30c1aaf6a98")
addappid(2631972, 1, "0fd52d9b16e4fb40ff63c82512feb91e95049d58aa0de0565f51710b7e82cbe1")
