-- Lua provided by RyzenAPI 
-- Game: MentalHellacious Demo
addappid(3197740)
addappid(3197741, 1, "dab3d8aa13610fb5ce26a82d749cbec30398831344d77e54b5b5f5587641a5bc")
