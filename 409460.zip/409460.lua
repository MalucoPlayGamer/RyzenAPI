-- Lua provided by RyzenAPI
-- Game: Blackfaun

-- MAIN APPLICATION
addappid(409460)

-- MAIN APP DEPOTS / PACKAGES
addappid(409461, 1, "0989fa72982252fb25bb3c660ee3f77b3658181ae45b3b455e0c8d411bec9193")
