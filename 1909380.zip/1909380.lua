-- Lua provided by RyzenAPI
-- Game: Furry Sex

-- MAIN APPLICATION
addappid(1909380)
-- Game: addappid(1909380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909381, 1, "effbfae4e392d118187019bb60daedc8e971bb199578c9a7a3d3e1a4ef571c3c")
