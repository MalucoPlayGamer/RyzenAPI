-- Lua provided by RyzenAPI
-- Game: Water Physics Simulation

-- MAIN APPLICATION
addappid(1692620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692621, 1, "7a2c6751adbf17da781ce4d873c249cff23c8510756cfbe01ba7bd8bd3cacc92")
