-- Lua provided by RyzenAPI
-- Game: Game: AppID 94400

-- MAIN APPLICATION
addappid(94400)
addappid(228990)
-- Game: addappid(94400)

-- MAIN APP DEPOTS / PACKAGES
addappid(94401, 1, "5974f0058e882cf21018bdcbfe4661dee1ba31553b03bdc53e4b51e56a8077e7")
addappid(94402, 1, "b8d1bf655ed4d7027cb38e669e39249786c23a8e657d6fd547eabd93f5c026d9")
addappid(94403, 1, "5c321cd798489c4b6667645f8e2d70fc0f7a585e63ed13f37c3f55206636271e")
