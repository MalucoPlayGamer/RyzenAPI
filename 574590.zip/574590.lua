-- Lua provided by RyzenAPI
-- Game: Koloro

-- MAIN APPLICATION
addappid(574590)

-- MAIN APP DEPOTS / PACKAGES
addappid(574591, 1, "7e581c87152800baae7bfa2a63f8172ff7735675a3fac88ef0f0834a4d5ff6e0")
addappid(574592, 1, "20a6de9b8a006f92c4630f75531a0f69b0ccf0c99c8a82ec8d1bb07978f0c923")
addappid(574593, 1, "c0cf39cc68080a12509c2b6d59e376c5f1e362d97739112a7537a0d92e77a9df")
addappid(574594, 1, "c8f1cd34f173f2873dd1277ec17887083dee35ca7efcfce98e63e0ab51247d04")
addappid(574595, 1, "73be7542dea0884962af6ef1379b485e04591024b1e24533e6f67c6833721991")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(865700)
