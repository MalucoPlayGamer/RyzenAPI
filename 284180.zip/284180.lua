-- Lua provided by RyzenAPI
-- Game: Magicians & Looters

-- MAIN APPLICATION
addappid(284180)

-- MAIN APP DEPOTS / PACKAGES
addappid(284181, 1, "73660c124452556603cdc3a94e16667849b612b9d0d2d847c96533ee14e39052")
