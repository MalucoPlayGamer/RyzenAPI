-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - "Ultimate Teacher" Costume for Nina

-- MAIN APPLICATION
addappid(3742590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742590,0,"f1073d098d84e91cbf83ad2802a4df6099935bcf1226ef800a567a5f8beb9c70")

