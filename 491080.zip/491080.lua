-- Lua provided by SkyAPI 
-- Game: AppID 491080
addappid(491080)
addappid(491081, 1, "89cb62361f4a3ce887a07e15026c8c8beb7c682c42f4f4caeea90a736f7892a8")
addappid(491082, 1, "604be6c0bf5ec3ec66da2fe51e26a2e88cd6e0281fe95a0e4e0fe071e2dea15b")
addappid(491083, 1, "dbf10287a6e31c0445755e37f1e145dd878472e851fc29e4693a46bb003cb4bc")
