-- Lua provided by RyzenAPI
-- Game: Dragon Spirits : Prologue

-- MAIN APPLICATION
addappid(1363490)
-- Game: addappid(1363490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363491, 1, "36dca689fbb9b6784ddd9ca471c806e515d80c61c74afd4b70546c9967605ef1")
