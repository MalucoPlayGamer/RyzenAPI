-- Lua provided by RyzenAPI
-- Game: Dragon Spirits : Prologue

-- MAIN APPLICATION
addappid(1363490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1363491, 1, "36dca689fbb9b6784ddd9ca471c806e515d80c61c74afd4b70546c9967605ef1")

