-- Lua provided by RyzenAPI
-- Game: Repentant

-- MAIN APPLICATION
addappid(874370)
-- Game: addappid(874370)

-- MAIN APP DEPOTS / PACKAGES
addappid(874371, 1, "93099accbefa8af67d40419ab52dc6c70f44280aaffa021c711602ad1e9fde0a")
addappid(874372, 1, "d8d4690630a1ff58d95009fcd45393b129fcd69f73f436e9b993b5e51fd62a6b")
addappid(874373, 1, "f0e91b0eae7b12c79e098df5b90c758f0402e796284f17a2627ee212ade395d8")
addappid(927800, 0, "c8739244239ce059bb523822ddf8b64d8fbdc0d1772be83aa7295723bb134058")
