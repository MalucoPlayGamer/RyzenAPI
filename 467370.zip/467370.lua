-- Lua provided by RyzenAPI
-- Game: Escape This

-- MAIN APPLICATION
addappid(467370)
-- Game: addappid(467370)

-- MAIN APP DEPOTS / PACKAGES
addappid(467372,0,"e8e3eff70f263e0022924b81f5a2fdc9f88cacc8d7e4ba29402628f4f652c765")
addappid(467373,0,"920a23936df7461eab7d3c1423eb2f8cc7d6955f940b7bf2925f62606b12727c")
