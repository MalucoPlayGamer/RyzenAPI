-- Lua provided by RyzenAPI
-- Game: Zombie Kill

-- MAIN APPLICATION
addappid(636430)

-- MAIN APP DEPOTS / PACKAGES
addappid(636431, 1, "ae3c0612801cc81925747a7d2fb35e5c3d67aae3ed3627ea882da5d74489eec6")
