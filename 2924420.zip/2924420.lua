-- Lua provided by RyzenAPI
-- Game: 2924420

-- MAIN APPLICATION
addappid(2924420)
-- Game: addappid(2924420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924420,0,"8d03e6189c0de6ad5de6aef6856b1e737e34fbbc88de72dc4b65ac0dde275909")
