-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Gekkoukan High School Uniform (7), Battle BGM & Battle Jingle Set

-- MAIN APPLICATION
addappid(2924420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924420,0,"8d03e6189c0de6ad5de6aef6856b1e737e34fbbc88de72dc4b65ac0dde275909")

