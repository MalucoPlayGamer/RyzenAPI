-- Lua provided by SkyAPI 
-- Game: Slitterhead Demo
addappid(3324600)
addappid(3324601, 1, "e34300405ffd6ec4f1df8ea37336c2a23478c9a54c8b32ee01ea75afb30ca7ed")
