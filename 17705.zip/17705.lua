-- Lua provided by RyzenAPI
-- Game: addappid(17705)

-- MAIN APPLICATION
addappid(205)
addappid(206)
addappid(207)
addappid(208)
addappid(1004)
addappid(17705)

-- MAIN APP DEPOTS / PACKAGES
addappid(17701,0,"96b7316ea1201847d0aefc1a4f7d44300c1c8d1cba8669d48fcf32b9564c5c97")
addappid(17702,0,"4ed4d107ad2e1cba1aaf74b237d776e89f6a7b5cae57db5ad95209fa0385dd5b")
