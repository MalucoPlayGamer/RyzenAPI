-- Lua provided by RyzenAPI
-- Game: Isekai Eternal Alpha

-- MAIN APPLICATION
addappid(1467410)
-- Game: addappid(1467410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467411, 1, "d6859377a747dff4d091d2ee90bffb45d0d072e7cc66a804b333d214031e9ab0")
