-- Lua provided by RyzenAPI
-- Game: Game: AppID 572180

-- MAIN APPLICATION
addappid(572180)
-- Game: addappid(572180)

-- MAIN APP DEPOTS / PACKAGES
addappid(572181, 1, "95307ea184e315a9e3e3d99aef6d05d201065d3ee39ff8695ec45e3d9da06f44")
