-- Lua provided by SkyAPI 
-- Game: Cafe Owner Simulator
addappid(1498140)
addappid(1498141, 1, "979db9dd83435cb793d471e4854cc129d0fa6cf7b5b9d0d8a071471c733c6aa0")
addappid(2742990)
