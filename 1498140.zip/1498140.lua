-- Lua provided by RyzenAPI
-- Game: 1498140

-- MAIN APPLICATION
addappid(1498140)
addappid(2742990)
-- Game: addappid(1498140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498141, 1, "979db9dd83435cb793d471e4854cc129d0fa6cf7b5b9d0d8a071471c733c6aa0")
