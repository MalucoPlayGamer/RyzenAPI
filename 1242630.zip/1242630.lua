-- Lua provided by RyzenAPI
-- Game: Game: Skid Cities

-- MAIN APPLICATION
addappid(1242630)
-- Game: addappid(1242630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242631, 1, "7cffd409eb16220ca463707547bfdf9c534464c0ca255ba2e31a56fa0f825391")
