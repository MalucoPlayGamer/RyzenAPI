-- Lua provided by RyzenAPI
-- Game: Game: AppID 928460

-- MAIN APPLICATION
addappid(928460)
-- Game: addappid(928460)

-- MAIN APP DEPOTS / PACKAGES
addappid(928461, 1, "1441d293f5d2a2037bf9235432b35eb3d527c471dad285f30e994c34e8a8fccc")
