-- Lua provided by RyzenAPI
-- Game: Duder

-- MAIN APPLICATION
addappid(814770)

-- MAIN APP DEPOTS / PACKAGES
addappid(814771, 1, "b42b02afdaeab62d363348469a789ec60ed9cf43d8268f917159b7daa1083782")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
