-- Lua provided by RyzenAPI
-- Game: Duder

-- MAIN APPLICATION
addappid(814770)

-- MAIN APP DEPOTS / PACKAGES
addappid(814771, 1, "b42b02afdaeab62d363348469a789ec60ed9cf43d8268f917159b7daa1083782")

