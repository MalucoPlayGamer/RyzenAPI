-- Lua provided by RyzenAPI 
-- Game: Gnomdom
addappid(2150490)
addappid(2150491, 1, "383e472c3c89198e7d2eb15f7544c4d8959d74bc2807bbbb122806f550183d8c")
