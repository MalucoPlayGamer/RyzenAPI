-- Lua provided by RyzenAPI
-- Game: 2306160

-- MAIN APPLICATION
addappid(2306160)
-- Game: addappid(2306160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306161, 1, "cc93c3173cdf0bf30d061cb7e48d9f59806a635cb934090e9304daf62dee9624")
