-- Lua provided by RyzenAPI
-- Game: AppID 2696400

-- MAIN APPLICATION
addappid(2696400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696401, 1, "14430b1b2e9b7d9f625e7218cd05369df409a356768868e0dd7c87c5cc62ce2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
