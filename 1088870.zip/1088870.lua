-- Lua provided by RyzenAPI
-- Game: AppID 1088870

-- MAIN APPLICATION
addappid(1088870)
-- Game: addappid(1088870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088871, 1, "15b04ae90395ce0a55d7e5ad3f6c75d0a2106fcc43686623503a0696be474bdf")
