-- Lua provided by RyzenAPI
-- Game: 奇幻与砍杀 Fantasy & Blade

-- MAIN APPLICATION
addappid(1088870)
addappid(1091420)
addappid(1091430)
addappid(1091450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088871,0,"15b04ae90395ce0a55d7e5ad3f6c75d0a2106fcc43686623503a0696be474bdf")

