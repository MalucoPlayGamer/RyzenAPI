-- Lua provided by RyzenAPI
-- Game: Game: WWE 2K20

-- MAIN APPLICATION
addappid(1015500)
-- Game: addappid(1015500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015501, 1, "2032c14e73518f2ce857dc8ae1cdf69282222545a381378ca0e24e38334846f2")
