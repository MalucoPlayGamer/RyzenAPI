-- Lua provided by RyzenAPI
-- Game: 4PM

-- MAIN APPLICATION
addappid(281840)

-- MAIN APP DEPOTS / PACKAGES
addappid(281841, 1, "6e294877137ff885e758bccbd1628ef0292523ffc0e3ef25b80f3e87e766de5c")

