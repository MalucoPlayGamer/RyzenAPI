-- Lua provided by RyzenAPI
-- Game: Slimes are the Strongest

-- MAIN APPLICATION
addappid(2816530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816531, 1, "0a87b3a18ae4fced692c3cef4e472a7ca6f5fe3b4552830f498eb75f11dde60a")
