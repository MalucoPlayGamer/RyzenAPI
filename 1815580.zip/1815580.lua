-- Lua provided by SkyAPI 
-- Game: Gunner Deadly Expedition
addappid(1815580)
addappid(1815581, 1, "67041c1ee151c16b747bc1921586e75d6f288be1e68c3558f9e9ad87cf4a3857")
