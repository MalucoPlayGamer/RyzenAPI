-- Lua provided by RyzenAPI
-- Game: addappid(1815580)

-- MAIN APPLICATION
addappid(1815580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815581, 1, "67041c1ee151c16b747bc1921586e75d6f288be1e68c3558f9e9ad87cf4a3857")
