-- Lua provided by RyzenAPI
-- Game: Valdis Story: Abyssal City

-- MAIN APPLICATION
addappid(252030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(252031, 1, "68a69eae1e2b5e510836415db3917d386db459464f57625387d2220b44f340f9")
addappid(252032, 1, "27c7bc1dcdc2fc24f2c44a72c95c17e5acc18346c0151c573358f37a9ea581d9")

