-- Lua provided by RyzenAPI
-- Game: addappid(827860)

-- MAIN APPLICATION
addappid(827860)

-- MAIN APP DEPOTS / PACKAGES
addappid(827861, 1, "efa85a4a5a1ab735965fc1237c40a63346006d3693a1bc99fd75df435cb1427d")
