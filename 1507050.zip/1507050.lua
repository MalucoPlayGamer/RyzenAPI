-- Lua provided by RyzenAPI
-- Game: シチズンズ・ユナイト！：アース×スペース Demo

-- MAIN APPLICATION
addappid(228988)
addappid(229007)
addappid(229020)
addappid(1507050)
addappid(1507051)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369731,0,"8c33b015e6ee368a3720f52d854134429a86ea3d4aeb291be5fa6fe5954f308d")

