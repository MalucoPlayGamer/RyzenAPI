-- Lua provided by RyzenAPI
-- Game: Lilith Rising - Season 1

-- MAIN APPLICATION
addappid(2424440)
-- Game: addappid(2424440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424443,0,"21fc114e470601486fec2e2016af9dc63dd0b61a7b63506e3079754e92728af9")
