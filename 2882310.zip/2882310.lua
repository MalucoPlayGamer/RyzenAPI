-- Lua provided by RyzenAPI
-- Game: Roomballs

-- MAIN APPLICATION
addappid(2882310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2882311, 1, "f883c2f5f116018950b5b74686af8f4277cd2f6f29d6b9790be445b531e3eba5")
addtoken(2882310, "11887392600861207480")

