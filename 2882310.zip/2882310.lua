-- Generated with Luie @ https://lua.tools/
-- 2882310 - Roomballs
-- Generated 2026-08-20 23:59:11 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(2882310)
addtoken(2882310, "11887392600861207480")

-- Main Depots
addappid(2882311, 1, "f883c2f5f116018950b5b74686af8f4277cd2f6f29d6b9790be445b531e3eba5")
setManifestid(2882311, "4953358569846446085", 6082883712)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
