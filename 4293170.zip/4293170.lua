-- 4293170's Lua and Manifest Created by Hubcap Manifest
-- CoinDecker ~Deck Building Pusher~
-- Created: July 30, 2026 at 14:12:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4293170) -- CoinDecker ~Deck Building Pusher~
-- MAIN APP DEPOTS
addappid(4293171, 1, "f23ebbba54610b3b8b5bc7ba2c77f2963cddad48f855b0fe344dce1c9fe713d0") -- Depot 4293171
setManifestid(4293171, "2264085643121536932", 271618092)