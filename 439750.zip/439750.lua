-- Lua provided by RyzenAPI
-- Game: The Lost Heir 2: Forging a Kingdom

-- MAIN APPLICATION
addappid(439750)

-- MAIN APP DEPOTS / PACKAGES
addappid(439751, 1, "5ebd2e7d2a052c2e3be541c9793efe073a4bae50dd21c23b22a8f520c591fc7c")

