-- Lua provided by RyzenAPI
-- Game: Hollywood Hero: Comeback

-- MAIN APPLICATION
addappid(1482730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482731, 1, "ef0bb68864c586f0f185a368dd019f537401ba145de180968327c4aed89106ea")

