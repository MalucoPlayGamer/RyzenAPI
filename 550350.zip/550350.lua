-- Lua provided by RyzenAPI
-- Game: addappid(550350)

-- MAIN APPLICATION
addappid(550350)

-- MAIN APP DEPOTS / PACKAGES
addappid(550351, 1, "61b2fa572853b8d0b85ecccb54f20abd0efd6b75b2af9d5d9e6ef9ab25f99596")
