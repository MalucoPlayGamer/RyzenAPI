-- Lua provided by RyzenAPI
-- Game: addappid(1212710)

-- MAIN APPLICATION
addappid(1212710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212711, 1, "a6efa11252ab2114e617a8badaa05d80e4b8f8272594a181802dcdc0b0f9b3e7")
