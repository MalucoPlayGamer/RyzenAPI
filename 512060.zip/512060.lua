-- Lua provided by RyzenAPI
-- Game: Stay! Stay! Democratic People's Republic of Korea!

-- MAIN APPLICATION
addappid(512060)

-- MAIN APP DEPOTS / PACKAGES
addappid(512061, 1, "4594bcb5d6f4c8adc2c0a2417182d67b8d33cecc4f92d4240158a9ada52b80d5")
addappid(659710, 0, "49474e48f95b5b55fc2d454f9937117087a7d845ce9091113297683b0f4e40bd")

