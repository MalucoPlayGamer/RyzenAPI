-- Lua provided by RyzenAPI 
-- Game: Duck Life: Retro Pack
addappid(1433950)
addappid(1433951, 1, "1e1a8e40e44cff0ae99d5ea4f43e260b020ecf91f1e9f764a66f02c07a660d39")
