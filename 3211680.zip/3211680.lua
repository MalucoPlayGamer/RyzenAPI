-- Lua provided by RyzenAPI
-- Game: addappid(3211680)

-- MAIN APPLICATION
addappid(3211680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211681, 1, "aed98fb60883c779d208088e726974a236a005845a4d7f3b0bee908a0226ac1d")
