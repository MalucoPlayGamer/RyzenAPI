-- Lua provided by RyzenAPI
-- Game: addappid(2943090)

-- MAIN APPLICATION
addappid(2943090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943091, 1, "8dfcd44e9bb08bc72167725cd491cc3c2b3e9f173ec126490a11a9168865a9f7")
