-- Lua provided by RyzenAPI
-- Game: 3120320

-- MAIN APPLICATION
addappid(3120320)
-- Game: addappid(3120320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120321, 1, "a55256db3660180a15fccea8b18283b13faf8804f09b7297b41565cb1709e3f5")
