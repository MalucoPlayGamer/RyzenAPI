-- Lua provided by RyzenAPI
-- Game: Game: 與魔共舞 我的頌歌

-- MAIN APPLICATION
addappid(2593680)
-- Game: addappid(2593680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593681, 1, "314f91b709e78040724fd273ed7891a58d33bf5cb8f695c73c8f9326226d6788")
