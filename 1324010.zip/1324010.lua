-- Lua provided by RyzenAPI
-- Game: Game: Disease -Hidden Object-

-- MAIN APPLICATION
addappid(1324010)
-- Game: addappid(1324010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324011, 1, "47c55ed707dd5ad0248a022398f8895c419403184c46a20246b3089e14325054")
