-- Lua provided by RyzenAPI
-- Game: Black Swan

-- MAIN APPLICATION
addappid(560230)

-- MAIN APP DEPOTS / PACKAGES
addappid(560231, 1, "af0da0dd19de5c119bab6bf2d0a99f045e502fc33f1bde5862bd0cb6d66d41b7")
