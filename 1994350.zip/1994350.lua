-- Lua provided by RyzenAPI
-- Game: addappid(1994350)

-- MAIN APPLICATION
addappid(1994350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994351, 1, "a4b62ebb2b904d56d0784ed73a026e3a15dca0a90570284fe6274a4a15d7752c")
