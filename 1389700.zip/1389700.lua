-- Lua provided by RyzenAPI
-- Game: Game: Sweet and Hot

-- MAIN APPLICATION
addappid(1389700)
-- Game: addappid(1389700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389701, 1, "87e6ec0ff48cb77106205595d5b72a55e6ab0b3e2118713fe4b58765eecca4bf")
