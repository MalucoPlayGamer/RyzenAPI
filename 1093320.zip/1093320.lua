-- Lua provided by RyzenAPI
-- Game: Devil's Deck 恶魔秘境

-- MAIN APPLICATION
addappid(1093320)
addappid(2064300)
addappid(2404600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093321, 1, "432ea3bd482933158aa6e3e70b4ef2e16c24f0db72c065efb1a93bbf33d43e3d")
