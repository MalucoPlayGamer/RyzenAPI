-- Lua provided by RyzenAPI
-- Game: The Search Soundtrack

-- MAIN APPLICATION
addappid(720110)

-- MAIN APP DEPOTS / PACKAGES
addappid(720110,0,"b77ac1bd5ad118d7dcc39af498927f90dceee9b6e965f75de2f519fd85fe7b93")

