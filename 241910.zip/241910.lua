-- Lua provided by RyzenAPI
-- Game: Goodbye Deponia

-- MAIN APPLICATION
addappid(241910)
addappid(476940)

-- MAIN APP DEPOTS / PACKAGES
addappid(241911, 1, "da8b62649585d95b7cd9050fcbadd8b7f25ae1b6e91e241dcc87906696865d40")
addappid(241912, 1, "8d4ae52db23046d9ed7edb1e863acb9550cf98a95d9633778d2c0db0b7403b8b")
addappid(241913, 1, "e3c14177478e5839f7eeb185d0425223c6e5ee3d77dcc9773435c9e2e411ef08")
addappid(241914, 1, "bc8d6fce09d4a45ac714d298442b43acae92526ff96aa1adaf39012692f2a8a0")
addappid(241915, 1, "dc8eeed86e2ebd429d51b8a2d31cf4a92c0252f407df7f97e92758d43e41e632")
addappid(241916, 1, "52eccc58c1de780a6144e8d92039688dd0938f3b06381d0709f508a7c86e41b6")
addappid(257210, 1, "8243ede0eea7727592d86fa3c0326855bfe1fe7d8f0be75c4e99641ff098ae79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(566470)
