-- Lua provided by RyzenAPI
-- Game: Underground Blossom Soundtrack

-- MAIN APPLICATION
addappid(2658760)
-- Game: addappid(2658760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658761, 1, "26568cb5743e13ffd10d53c241e438db95e27ee6788bb7018a6580878e6a0931")
