-- Lua provided by RyzenAPI
-- Game: PAPAO: The Legend of the Bogeyman

-- MAIN APPLICATION
addappid(3651710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651711, 1, "847ccbf24a8688681197a08ff73c405951b061ae3577d688380902077f72ccad")

