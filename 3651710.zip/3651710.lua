-- Lua provided by RyzenAPI
-- Game: PAPAO: The Legend of the Bogeyman

-- MAIN APPLICATION
addappid(3651710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3651711, 1, "847ccbf24a8688681197a08ff73c405951b061ae3577d688380902077f72ccad")

