-- Lua provided by RyzenAPI
-- Game: AppID 531890

-- MAIN APPLICATION
addappid(531890)

-- MAIN APP DEPOTS / PACKAGES
addappid(531891, 1, "87804ec6a2a40a6ae33b470ab8eac7edc03dcebc0f3eb662d94a25b7eab4a39e")
