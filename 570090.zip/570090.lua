-- Lua provided by RyzenAPI
-- Game: articy:draft 3

-- MAIN APPLICATION
addappid(570090)

-- MAIN APP DEPOTS / PACKAGES
addappid(570091, 1, "829b154056f761d8f4ff66ded72266e71a5b873214f36f412f7192d938a7feac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
