-- Lua provided by RyzenAPI
-- Game: addappid(570090)

-- MAIN APPLICATION
addappid(570090)

-- MAIN APP DEPOTS / PACKAGES
addappid(570091, 1, "829b154056f761d8f4ff66ded72266e71a5b873214f36f412f7192d938a7feac")
