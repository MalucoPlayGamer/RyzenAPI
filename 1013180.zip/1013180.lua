-- Lua provided by RyzenAPI
-- Game: Game: Funbag Fantasy

-- MAIN APPLICATION
addappid(1013180)
-- Game: addappid(1013180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013181, 1, "2d252f0f2cdb95fd5c029b63930f361c7f7785130492645cb51af8ea21c6242b")
