-- Lua provided by RyzenAPI
-- Game: Funbag Fantasy

-- MAIN APPLICATION
addappid(1013180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013181, 1, "2d252f0f2cdb95fd5c029b63930f361c7f7785130492645cb51af8ea21c6242b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
