-- Lua provided by RyzenAPI
-- Game: Hold the Line: The American Revolution

-- MAIN APPLICATION
addappid(657500)

-- MAIN APP DEPOTS / PACKAGES
addappid(657501,0,"1717510575fe0c0cb09d5b990ccefbd92bf599a48be17a00fba329c91febdbe2")
addappid(657502,0,"46e1455096a5c8a165c774ef52004b8a5184ecc48558ae7d1febf92cb6354cd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
