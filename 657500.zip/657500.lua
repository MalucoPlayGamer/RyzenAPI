-- Lua provided by RyzenAPI
-- Game: Hold the Line: The American Revolution

-- MAIN APPLICATION
addappid(657500)

-- MAIN APP DEPOTS / PACKAGES
addappid(657501,0,"1717510575fe0c0cb09d5b990ccefbd92bf599a48be17a00fba329c91febdbe2")
addappid(657502,0,"46e1455096a5c8a165c774ef52004b8a5184ecc48558ae7d1febf92cb6354cd3")

