-- Lua provided by RyzenAPI
-- Game: 563340

-- MAIN APPLICATION
addappid(563340)
-- Game: addappid(563340)

-- MAIN APP DEPOTS / PACKAGES
addappid(563341, 1, "ec8a1741b03c2bb4e8b446f4d1edc3e0353bf0a438cb6422c94a68067afcc869")
addappid(563342, 1, "b7de625e1cff99a0307b1e2c4b35ddc7ce993fc68a4272be9870b33c1eaa0fcf")
addappid(563343, 1, "ad425459e2d5c94c1f7ca9e32db1f03f02f422556f6af1eb8138f4e20f011efa")
addappid(563344, 1, "d1a54fc07f92471c98e72b20a0e8bde1db51b041b8f12cca3b0aad2084eae386")
