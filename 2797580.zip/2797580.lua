-- Lua provided by RyzenAPI
-- Game: Game: AppID 2797580

-- MAIN APPLICATION
addappid(2797580)
-- Game: addappid(2797580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797581, 1, "a1f463468520bcfbeb1faafd4fd63abccce9efce1252020403460b384a2c36ef")
