-- Lua provided by RyzenAPI
-- Game: Game: Magic Kingdom

-- MAIN APPLICATION
addappid(2115060)
-- Game: addappid(2115060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115061, 1, "53bc08c9aa817d9dc1e341d671e57e7ec5350fb05ac4ea63dbf02347e066cea9")
