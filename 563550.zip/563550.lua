-- Lua provided by RyzenAPI 
-- Game: AppID 563550
addappid(563550)
addappid(563551, 1, "fca6a7ba079a1d1527e03149642751632eaa6dc7b8c538a11038f9d61d7d0dd9")
