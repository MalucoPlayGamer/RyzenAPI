-- Lua provided by RyzenAPI
-- Game: Corrupted Universe Cries Quietly

-- MAIN APPLICATION
addappid(2607150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607151, 1, "7ffdb127729f5a2ef13636badde24019767ee6e0db42e8a4846a8169aa3a4cc8")
