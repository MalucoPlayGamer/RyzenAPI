-- Lua provided by RyzenAPI
-- Game: Inquisitor’s Heart and Soul

-- MAIN APPLICATION
addappid(1780940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780941, 1, "7ccdde5232656882a4a5be80c90565288194f7ebbbf117cd355617920917fbb7")
