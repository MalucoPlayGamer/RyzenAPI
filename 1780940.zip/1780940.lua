-- Lua provided by RyzenAPI
-- Game: Inquisitor’s Heart and Soul

-- MAIN APPLICATION
addappid(1780940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780941, 1, "7ccdde5232656882a4a5be80c90565288194f7ebbbf117cd355617920917fbb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
