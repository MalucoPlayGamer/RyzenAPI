-- Lua provided by RyzenAPI
-- Game: Legends of Aria - Legacy Client

-- MAIN APPLICATION
addappid(1008810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008810,0,"1922397a46fac980f724a2bb0f49b0594293eb8decaeda45be4a6c46333c7762")
