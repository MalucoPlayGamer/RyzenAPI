-- Lua provided by RyzenAPI
-- Game: addappid(2954460)

-- MAIN APPLICATION
addappid(2954460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954461, 1, "d5f0e46eadd4f615718eccbc07a037bec6f9ab34b304997f4c5b88013d665ebb")
