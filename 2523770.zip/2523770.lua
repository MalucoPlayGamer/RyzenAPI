-- Lua provided by RyzenAPI
-- Game: The Lord of the Rings: War in the North™ - Legacy Edition

-- MAIN APPLICATION
addappid(2523770)
addappid(2523770) -- The Lord of the Rings: War in the North™ - Legacy Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2523771, 1, "14e7dc6ba004a317cfc4a7095f543092c91234f59c895b096aec1b7fe8111cdd")
addappid(2523771, 1, "14e7dc6ba004a317cfc4a7095f543092c91234f59c895b096aec1b7fe8111cdd") -- Depot 2523771

