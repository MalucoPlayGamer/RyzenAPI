-- Lua provided by RyzenAPI
-- Game: Super Lee World

-- MAIN APPLICATION
addappid(1118730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1118731, 1, "360563c4d37f2a9fcb69b1516a318efca13351642f0110e838fb39d831d57a75")

