-- Lua provided by RyzenAPI
-- Game: Game: AppID 1118730

-- MAIN APPLICATION
addappid(1118730)
-- Game: addappid(1118730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118731, 1, "360563c4d37f2a9fcb69b1516a318efca13351642f0110e838fb39d831d57a75")
