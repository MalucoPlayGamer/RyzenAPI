-- Lua provided by RyzenAPI
-- Game: addappid(319760)

-- MAIN APPLICATION
addappid(319760)

-- MAIN APP DEPOTS / PACKAGES
addappid(319761, 1, "9c4d880969b25d527ff254a10891b25c590bc7f9c897105ed41249341a0bee7b")
