-- Lua provided by RyzenAPI
-- Game: Game: Army of Numbers

-- MAIN APPLICATION
addappid(1454090)
-- Game: addappid(1454090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454091, 1, "f74b396672530f0e3e15361ee1e3749186a26170513e512b566f6e22d223c39f")
