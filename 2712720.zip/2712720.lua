-- Lua provided by RyzenAPI
-- Game: Depths of Darkness

-- MAIN APPLICATION
addappid(2712720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712721, 1, "ec38d301891568260ed2e1779a849f653339376879265cdb16e5cf8d59bfbb39")

