-- Lua provided by RyzenAPI
-- Game: addappid(1022466)

-- MAIN APPLICATION
addappid(1022466)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022466,0,"09b593c18c3ef5d7649c46353fc91e4e22c85bf53b724a0d0f4a210ec688b8ac")
