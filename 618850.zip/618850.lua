-- Lua provided by RyzenAPI
-- Game: Pumpkin Days

-- MAIN APPLICATION
addappid(618850)
-- Game: addappid(618850)

-- MAIN APP DEPOTS / PACKAGES
addappid(618851, 1, "8b3264699c7dd33a7f7dcc8d27e3d370de5174f97f877899bd8ca7722f7acb2f")
