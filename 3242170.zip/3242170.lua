-- Lua provided by RyzenAPI
-- Game: 3242170

-- MAIN APPLICATION
addappid(3242170)
-- Game: addappid(3242170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242171, 1, "f87f1da158d7d6b42727b48a2337d37a0524e0faa29094168b9c050cde4b49bb")
