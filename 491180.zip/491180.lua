-- Lua provided by RyzenAPI
-- Game: addappid(491180)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(491180)

-- MAIN APP DEPOTS / PACKAGES
addappid(491182,0,"9d2f68be25d3b7bfcab92cc15f06a50e1a870372a82df52a0269eb937465ddcb")
