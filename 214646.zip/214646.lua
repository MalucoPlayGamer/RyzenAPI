-- Lua provided by RyzenAPI
-- Game: 214646

-- MAIN APPLICATION
addappid(214646)

-- MAIN APP DEPOTS / PACKAGES
addappid(214646,0,"ee8525fdbe70362e66f42974cce4b72d5a3adb9fb15fc3f2384d6f086685ab1a")
