-- Lua provided by RyzenAPI
-- Game: Survivor's End

-- MAIN APPLICATION
addappid(2424160)
-- Game: addappid(2424160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424161, 1, "5a55ac02075136a56a09389706eb9a0030417a1c874871cbc09c56af35db6db2")
