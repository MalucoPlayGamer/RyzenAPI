-- Lua provided by SkyAPI 
-- Game: Asterogues
addappid(2083240)
addappid(2083241, 1, "6b6c23b73793bc8247e9d33d3e61ef48230a585c78831ef915271e1d8d688070")
