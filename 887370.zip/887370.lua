-- Lua provided by RyzenAPI 
-- Game: Element Space
addappid(887370)
addappid(887371, 1, "f7dfc1201f7760141f8da642e3a16984e0e7ad65da938d02c5b0e7f516e9099f")
