-- Lua provided by RyzenAPI
-- Game: Soccer Online: Ball 3D

-- MAIN APPLICATION
addappid(485610)

-- MAIN APP DEPOTS / PACKAGES
addappid(485611, 1, "a1e322eb978fc9a481ca0425ceca7f00e1e06e06ffdded1399de05e45509a6db")
addappid(485612, 1, "9926b184ff83767201a0773a2d1f1d4bf85bf04df8efa816ffabb7ba5b613c71")

