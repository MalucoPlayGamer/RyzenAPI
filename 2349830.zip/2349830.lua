-- Lua provided by RyzenAPI 
-- Game: Touhou: Gensokyo Survivors
addappid(2349830)
addappid(2349831, 1, "9bb45e3f4c57f959c72b5bf815399644cb59bfd9d97535bdfcefcd3acb53d05d")
