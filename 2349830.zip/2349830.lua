-- Lua provided by RyzenAPI
-- Game: Touhou: Gensokyo Survivors

-- MAIN APPLICATION
addappid(2349830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349831, 1, "9bb45e3f4c57f959c72b5bf815399644cb59bfd9d97535bdfcefcd3acb53d05d")
