-- Lua provided by RyzenAPI
-- Game: 1506680

-- MAIN APPLICATION
addappid(1506680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506682,0,"e68763af63ce481d8d43ce3c7e1bc094f286b1d8d741d3fc592e0bb4d9bad5ad")

