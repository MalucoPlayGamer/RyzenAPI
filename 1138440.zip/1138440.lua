-- Lua provided by RyzenAPI
-- Game: Galactic Ruler

-- MAIN APPLICATION
addappid(1138440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138441, 1, "a3908d4e0a337ab43ebc5cd6e7cce7d0daec04e1acb91b939c9c5723f753ba4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
