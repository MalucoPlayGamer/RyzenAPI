-- Lua provided by RyzenAPI
-- Game: Dullpain

-- MAIN APPLICATION
addappid(1954520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954521, 1, "15cda46e2b100be63ec195d3fd25b1a9d3ccf04679c1b0e78e089a2d7222ce56")
