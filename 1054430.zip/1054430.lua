-- Lua provided by RyzenAPI
-- Game: Fling to the Finish

-- MAIN APPLICATION
addappid(1054430)
addappid(1670570)
addappid(1711730)
addappid(1711731)
addappid(1711732)
addappid(1711733)
addappid(1711734)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1054431,0,"16e03e6c2b071b3f5ee0a1891c13c1992d612ce859f4cfcf6339957f5271fda5")
addappid(1054432,0,"67ab7beacf303a5a5311525d2451028da0ebeec3a36760613f2c86066c1c98c3")
addappid(1054433,0,"096437dc426e5af8f8f9eab2805ba3d64d889806e7f5a8946e1c1b5999684c38")
addappid(1670570,0,"952f8d8b78dab127697bd7280b9b78c996c590e28957b36b81a43d4e95eefd15")

