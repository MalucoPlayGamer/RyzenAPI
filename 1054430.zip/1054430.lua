-- Lua provided by RyzenAPI
-- Game: Fling to the Finish

-- MAIN APPLICATION
addappid(1054430)
addappid(1670570)
addappid(1711730)
addappid(1711731)
addappid(1711732)
addappid(1711733)
addappid(1711734)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054431,0,"16e03e6c2b071b3f5ee0a1891c13c1992d612ce859f4cfcf6339957f5271fda5")
addappid(1054432,0,"67ab7beacf303a5a5311525d2451028da0ebeec3a36760613f2c86066c1c98c3")
addappid(1054433,0,"096437dc426e5af8f8f9eab2805ba3d64d889806e7f5a8946e1c1b5999684c38")
addappid(1670570,0,"952f8d8b78dab127697bd7280b9b78c996c590e28957b36b81a43d4e95eefd15")

