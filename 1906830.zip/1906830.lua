-- Lua provided by RyzenAPI
-- Game: addappid(1906830)

-- MAIN APPLICATION
addappid(1906830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906831, 1, "c8934bb3b68a195ca62d3fe5a0c55c367f0a5071672903e737a6021f78e147fe")
