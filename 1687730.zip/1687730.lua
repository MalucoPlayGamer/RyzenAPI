-- Lua provided by RyzenAPI
-- Game: AppID 1687730

-- MAIN APPLICATION
addappid(1687730)
-- Game: addappid(1687730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687731, 1, "2c8966de9ceea4cfbb59784b58321d7778c42a9dfb4c38555b20690f516b1cd3")
