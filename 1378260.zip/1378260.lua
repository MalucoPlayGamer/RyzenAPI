-- Lua provided by RyzenAPI
-- Game: Game: Voodoo Kid

-- MAIN APPLICATION
addappid(1378260)
-- Game: addappid(1378260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378261, 1, "b25b72c85e3e95b27d64c4686549ee6499258faf5c98670b7bc8fc94c71db7e1")
