-- Lua provided by SkyAPI 
-- Game: Voodoo Kid
addappid(1378260)
addappid(1378261, 1, "b25b72c85e3e95b27d64c4686549ee6499258faf5c98670b7bc8fc94c71db7e1")
