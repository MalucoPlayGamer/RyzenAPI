-- Lua provided by SkyAPI 
-- Game: Nova Hearts: The Spark
addappid(2747740)
addappid(2747741, 1, "9e55c808d724b07cbcbb3a3563126538a42446545feaf19097b298ca07c39fc2")
