-- Lua provided by RyzenAPI
-- Game: Game: Nova Hearts: The Spark

-- MAIN APPLICATION
addappid(2747740)
-- Game: addappid(2747740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747741, 1, "9e55c808d724b07cbcbb3a3563126538a42446545feaf19097b298ca07c39fc2")
