-- Lua provided by RyzenAPI
-- Game: addappid(2777340)

-- MAIN APPLICATION
addappid(2777340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777340,0,"b67b82ed17215576f99db7b9f6f65cb954c264060b483eaf58b5a3c72767a8c7")
