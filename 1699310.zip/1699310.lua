-- Lua provided by RyzenAPI
-- Game: 1699310

-- MAIN APPLICATION
addappid(1699310)
-- Game: addappid(1699310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699311, 1, "0e65be0ca3877dfd7cbad3cebcdcbe0883bc383a484398c58db5b3c1805ba730")
