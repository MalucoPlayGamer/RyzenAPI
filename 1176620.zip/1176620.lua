-- Lua provided by RyzenAPI
-- Game: addappid(1176620)

-- MAIN APPLICATION
addappid(1176620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176620,0,"b33402a6867a3232a2ee80e8959142af706fc8321dc11da3e08860b5037ceadc")
