-- Lua provided by RyzenAPI
-- Game: AppID 1237760

-- MAIN APPLICATION
addappid(1237760)
-- Game: addappid(1237760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237761, 1, "32f2b7e665a9b411f856ceb9fc0625c9e72f43815a47912ea891c38e4608b22c")
