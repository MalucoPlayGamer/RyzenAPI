-- Lua provided by RyzenAPI
-- Game: Chosen War

-- MAIN APPLICATION
addappid(3169180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169181, 1, "98c1be5a33b21ee10adff7fc1462794cef0260d422a6a9153b9f9d4085806a02")

