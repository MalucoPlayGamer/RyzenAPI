-- Lua provided by RyzenAPI
-- Game: The Elomont Raider

-- MAIN APPLICATION
addappid(3825690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3825691, 1, "12015a04e2d907a365f322310eb6b2f950b62f42a049313f60176120dceef533")
