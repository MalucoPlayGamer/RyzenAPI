-- Lua provided by RyzenAPI
-- Game: LuckLand Demo

-- MAIN APPLICATION
addappid(2524620)
-- Game: addappid(2524620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524621, 1, "49430be1d70ce03c5d3020fc8b40548917a3299430fe3b796f6073399c322fc9")
