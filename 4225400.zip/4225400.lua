-- 4225400's Lua and Manifest Created by Hubcap Manifest
-- I.T. Never Ends
-- Created: August 15, 2026 at 00:10:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4225400) -- I.T. Never Ends
-- MAIN APP DEPOTS
addappid(4225401, 1, "f06441994a718a8224b2aa6d923164b6e736cb015acc4cac16a9fbed0454e7af") -- Depot 4225401
setManifestid(4225401, "8486598495771606004", 520000758)
addappid(4225402, 1, "26a7d347b71b0ce0f99e4d98f90f13d2d45d7bffdcf2ac45e44155e9749df83d") -- Depot 4225402
setManifestid(4225402, "8600787913070473542", 888337773)