-- Lua provided by RyzenAPI
-- Game: I.T. Never Ends

-- MAIN APPLICATION
addappid(4225400) -- I.T. Never Ends

-- MAIN APP DEPOTS / PACKAGES
addappid(4225401, 1, "f06441994a718a8224b2aa6d923164b6e736cb015acc4cac16a9fbed0454e7af") -- Depot 4225401
addappid(4225402, 1, "26a7d347b71b0ce0f99e4d98f90f13d2d45d7bffdcf2ac45e44155e9749df83d") -- Depot 4225402

