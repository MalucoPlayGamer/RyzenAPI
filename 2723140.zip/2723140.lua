-- Lua provided by RyzenAPI 
-- Game: Divine Twins
addappid(2723140)
addappid(2723141, 1, "53d230902035dade72af1cca967ab0885a9c9742800638b9c4e32540a9b40c19")
