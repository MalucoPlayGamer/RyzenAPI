-- Lua provided by SkyAPI 
-- Game: Mirror Maker
addappid(1007350)
addappid(1007351, 1, "34b63e50e78350fd742ec62ff5933b0b2920263d5d936dc7de4577d575f56804")
