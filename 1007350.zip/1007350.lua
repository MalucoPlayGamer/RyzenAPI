-- Lua provided by RyzenAPI
-- Game: Mirror Maker

-- MAIN APPLICATION
addappid(1007350)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1007351, 1, "34b63e50e78350fd742ec62ff5933b0b2920263d5d936dc7de4577d575f56804")

