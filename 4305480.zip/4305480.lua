-- 4305480's Lua and Manifest Created by Hubcap Manifest
-- IncreKnight
-- Created: June 11, 2026 at 17:26:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4305480) -- IncreKnight
-- MAIN APP DEPOTS
addappid(4305481, 1, "a03cf32d828a7326274da5e5ce4bd6fd2b26bfd0263cda3979bd8a9cded35137") -- Depot 4305481
setManifestid(4305481, "8674408274685076968", 310389701)