-- Lua provided by RyzenAPI 
-- Game: Soulmask original game soundtrack
addappid(3575860)
addappid(3575861, 1, "7fe18a4c679cbad19cb1cc7ed1ed3e6414f8ee6b0f4f07c3af1d6770fc06c4e2")
addappid(3575862, 1, "38b94442be439d1407665360e024400bd01020f15c0179193d5da6866a6d4dda")
