-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 真・女神転生-20XX

-- MAIN APPLICATION
addappid(3652460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652461, 1, "5d9a6bd36f6c83e675af214a44ca3446c61b4e25eff240f840e3efbfa905947a")
