-- Lua provided by RyzenAPI
-- Game: Defense Technica

-- MAIN APPLICATION
addappid(233110)

-- MAIN APP DEPOTS / PACKAGES
addappid(233111, 1, "d38d561357c4c11317c71f96962485d2ed7048a444f7df8e04dbae1325d9ca4f")
addappid(233112, 1, "4faf49c38482f86c1a6e277b8eb568408a4f61d9add08ee1be17a466e48071f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
