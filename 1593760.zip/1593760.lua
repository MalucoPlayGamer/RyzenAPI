-- Lua provided by RyzenAPI
-- Game: Chubby Bear Smash

-- MAIN APPLICATION
addappid(1593760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1593761, 1, "8e220e7d0b6e849719885f25b0abfe5d65133fa6662216b48fb37736db3143fe")

