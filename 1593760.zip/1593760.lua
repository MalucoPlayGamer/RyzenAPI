-- Lua provided by RyzenAPI
-- Game: Game: Chubby Bear Smash

-- MAIN APPLICATION
addappid(1593760)
-- Game: addappid(1593760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593761, 1, "8e220e7d0b6e849719885f25b0abfe5d65133fa6662216b48fb37736db3143fe")
