-- Lua provided by RyzenAPI
-- Game: Game: AppID 1042780

-- MAIN APPLICATION
addappid(1042780)
-- Game: addappid(1042780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042781, 1, "5bd8dccaed5e3a40bb1ed9e768d23c689703177970e520cd9230fe9706d8a514")
addappid(1042782, 1, "e09190a354b53eccade84ffbfe143ebca443b9a444dcba59b68a4f97014f95eb")
addappid(1042783, 1, "496eac5d731ba388462cf1b021f2701761409f4d761e6b7220ee1620429ffef8")
