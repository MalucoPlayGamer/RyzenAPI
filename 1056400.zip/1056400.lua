-- Lua provided by RyzenAPI
-- Game: 1056400

-- MAIN APPLICATION
addappid(1056400)
-- Game: addappid(1056400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056400,0,"8d38abdf1909ef64dcb35080cf81821f3cb99c274e883f0dc5e2b5470858bd1f")
