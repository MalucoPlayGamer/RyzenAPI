-- Lua provided by RyzenAPI
-- Game: Dreamscaper Original Game Soundtrack

-- MAIN APPLICATION
addappid(1316600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316601, 1, "6d746e8c5057f6f8ec8b735da048a7d6b0e7be6d5507bb13a92db04f08e7f3f1")
addappid(1316602, 1, "a5425113e9d5f9e7e9c806118466cef3b61cf2ef966938b7d0081d51cb1ab9fd")
