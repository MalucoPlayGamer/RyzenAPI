-- Lua provided by RyzenAPI
-- Game: Charging Out Dead Zone

-- MAIN APPLICATION
addappid(2061820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061821, 1, "687fcdb06edc2ca48dd201b45251308fa720af0c8f72a07141ba8f2b34d61339")

