-- Lua provided by RyzenAPI
-- Game: 1789650

-- MAIN APPLICATION
addappid(1789650)
-- Game: addappid(1789650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789651, 1, "6249634800459f14eee880ed8d8caf55100e4d83e91c6ca9232189aede8910a1")
