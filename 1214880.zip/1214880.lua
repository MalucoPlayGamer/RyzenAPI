-- Lua provided by RyzenAPI
-- Game: 1214880

-- MAIN APPLICATION
addappid(1214880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214880,0,"ee7beab843701e494b4e5207aed2e9bc71ec1dff8fd6a427b1d5e54642e5fba8")

