-- Lua provided by RyzenAPI
-- Game: 4019420

-- MAIN APPLICATION
addappid(4019420)
-- Game: addappid(4019420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4019421, 1, "6cb3d156b7966276988b1955c675ff435579b6ba510deb11a0d01c46dcd6edb3")
