-- Lua provided by RyzenAPI
-- Game: MOVEIT

-- MAIN APPLICATION
addappid(1850390)
-- Game: addappid(1850390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850391, 1, "e6bb6d43763ea18d43071d3e91d314c8d3ed88fc0dbde7f69b562c93dd626527")
