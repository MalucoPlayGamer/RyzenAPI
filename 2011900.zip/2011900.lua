-- Lua provided by RyzenAPI
-- Game: Game: Zero Wing

-- MAIN APPLICATION
addappid(2011900)
-- Game: addappid(2011900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011901, 1, "525e96f6aaa771df607fd5cbfdd485ff94bfe695b2b548386921de41c1ca27d9")
addappid(2011902, 1, "40c043bb6207401f68e18ffd61f52305fff48e3b5c410f9d4691f053860b9202")
addappid(2011903, 1, "81150859c926ab9a8e9d43d9f3c31e0edc0e54b424aeb2817ad532d999de0db6")
