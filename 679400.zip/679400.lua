-- Lua provided by RyzenAPI
-- Game: Game: AppID 679400

-- MAIN APPLICATION
addappid(679400)
-- Game: addappid(679400)

-- MAIN APP DEPOTS / PACKAGES
addappid(679401, 1, "ff9f0a619247f4bc575263e22b224736ad7f50a2805fffaf382b2a918c009d5f")
addappid(679403, 1, "e238e0e5c28c9079a1ba734f9b06da3ea5e8f473232e1d188bee9c4da57db2b2")
