-- Lua provided by RyzenAPI
-- Game: Dungeon Crusher: Soul Hunters

-- MAIN APPLICATION
addappid(842980)

-- MAIN APP DEPOTS / PACKAGES
addappid(842982,0,"06e70e508ecb330cc9dd11b53609d2f11b8d98da9541f21e5c4f92dd936dc2be")
addappid(842983,0,"cd6f00c971b9bb7541015e71611a7be52c275b7545db8563090c3c2055547415")
