-- Lua provided by RyzenAPI 
-- Game: Monster Meals Demo
addappid(3145210)
addappid(3145211, 1, "39bf0bb0cd51df65e0a94c462a99c6f10ce90a06ebc088af8674d0293ce90620")
