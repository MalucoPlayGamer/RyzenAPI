-- Lua provided by RyzenAPI
-- Game: Game: Monster Meals Demo

-- MAIN APPLICATION
addappid(3145210)
-- Game: addappid(3145210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145211, 1, "39bf0bb0cd51df65e0a94c462a99c6f10ce90a06ebc088af8674d0293ce90620")
