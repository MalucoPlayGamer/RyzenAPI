-- Lua provided by RyzenAPI
-- Game: addappid(1432140)

-- MAIN APPLICATION
addappid(1432140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432140,0,"d7507feeac94eab8383492b30ab7b5eefff268efe7c114a05ebf629eced5f272")
