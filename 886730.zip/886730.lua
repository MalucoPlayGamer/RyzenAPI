-- Lua provided by RyzenAPI
-- Game: addappid(886730)

-- MAIN APPLICATION
addappid(886730)

-- MAIN APP DEPOTS / PACKAGES
addappid(886731, 1, "2ef057c773b68233a6c75c578346fea66fb156af4f2b705532eba7979353a148")
