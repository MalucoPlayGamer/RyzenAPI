-- Lua provided by RyzenAPI
-- Game: Loco Road

-- MAIN APPLICATION
addappid(1310350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310351, 1, "3fa6299f94010c53f45bc6c763633c26d0be23f4d7ea2eae999da0056b0f6b13")
