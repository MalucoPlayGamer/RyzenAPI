-- Lua provided by RyzenAPI
-- Game: addappid(620190)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(620190)

-- MAIN APP DEPOTS / PACKAGES
addappid(620192,0,"d5686a82f15ef5a3346b350ed8ecc44846668969fc4c868fc64fae7253d23f50")
