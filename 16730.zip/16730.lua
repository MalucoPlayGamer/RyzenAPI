-- Lua provided by RyzenAPI 
-- Game: Legendary
addappid(16730)
addappid(16731, 1, "a445c49aae89eb1d17f17b9cd334b3a09661a4a15a6450ca8586ef471ea68e68")
