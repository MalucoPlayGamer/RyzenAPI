-- Lua provided by RyzenAPI
-- Game: 1450460

-- MAIN APPLICATION
addappid(1450460)
-- Game: addappid(1450460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450461, 1, "c3f80850b1776fe0666d7573d725e5903ddf0d71e1e2ac8dd37a6d916828dc95")
