-- Lua provided by RyzenAPI
-- Game: 1416520

-- MAIN APPLICATION
addappid(1416520)
-- Game: addappid(1416520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416521, 1, "ea2be561702766c9d6decdc695fcc5e29a84502ef58334d85fb49774371e415a")
