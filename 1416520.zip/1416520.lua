-- Lua provided by RyzenAPI
-- Game: Drive 21

-- MAIN APPLICATION
addappid(1416520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416521, 1, "ea2be561702766c9d6decdc695fcc5e29a84502ef58334d85fb49774371e415a")

