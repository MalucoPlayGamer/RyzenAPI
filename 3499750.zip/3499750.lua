-- Lua provided by RyzenAPI
-- Game: Game: Gassal Simulator

-- MAIN APPLICATION
addappid(3499750)
-- Game: addappid(3499750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499751, 1, "408a4ad0951d7e95b8248681afb2c27e10911ccfcbe1cf2dfc07783f779dd765")
