-- Lua provided by RyzenAPI
-- Game: Fantasia of the Wind Guide Book

-- MAIN APPLICATION
addappid(755260)

-- MAIN APP DEPOTS / PACKAGES
addappid(755260,0,"4dfa61937b297f2966900079612ab01056f96f803f67dc6ef5035a86e9df4708")

