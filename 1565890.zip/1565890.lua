-- Lua provided by RyzenAPI
-- Game: RaceLeague

-- MAIN APPLICATION
addappid(1565890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565891, 1, "dda3a6181cfbb6fcf9da47fcd13ffd1d6119ce7aa205678ae4b02a7050d146f9")
