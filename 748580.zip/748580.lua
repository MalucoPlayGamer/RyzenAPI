-- Lua provided by RyzenAPI
-- Game: Bridge to Another World: The Others Collector's Edition

-- MAIN APPLICATION
addappid(748580)

-- MAIN APP DEPOTS / PACKAGES
addappid(748581,0,"ceaa1ea07b6b2b27ff487cf0bff3cddcfa38cb4b542bda846eaf97366529bc99")

