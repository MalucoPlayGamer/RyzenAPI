-- Lua provided by RyzenAPI
-- Game: Go! Go! Nippon! ~My First Trip to Japan~

-- MAIN APPLICATION
addappid(251870)

-- MAIN APP DEPOTS / PACKAGES
addappid(251871, 1, "4e40d60aaa1a9d674256647afaf13eb38293ee8bb58c9ab4472e6416c0a5b013")
addappid(397030, 0, "904236b024cf656685515d6f539cb0067511d8c6212cf7945c2af980d426d4e3")
addappid(534840, 0, "2fe242a4925a8594cd0c405886e171c66959cb2cb24f1cb06acc1255488fbddf")

