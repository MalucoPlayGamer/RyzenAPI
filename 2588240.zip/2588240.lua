-- Lua provided by RyzenAPI
-- Game: 2588240

-- MAIN APPLICATION
addappid(2588240)
-- Game: addappid(2588240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588241, 1, "a0035e361da7e09ebf4701bda3f69f758d40a4bad8e1bda70cecf4cf2642148a")
