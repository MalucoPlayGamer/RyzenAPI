-- Lua provided by RyzenAPI
-- Game: AppID 1112790

-- MAIN APPLICATION
addappid(1112790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112791, 1, "d4893fe292083aeeebfddad84079cda04b8f930399016fd49d5fd8217ef37bf5")
