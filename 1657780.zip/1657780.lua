-- Lua provided by RyzenAPI 
-- Game: Ultimechs
addappid(1657780)
addappid(1657781, 1, "cf42d7beb265ffdfc356a8af97d8554c62aa327104f73b0a9199857a039fe1ac")
