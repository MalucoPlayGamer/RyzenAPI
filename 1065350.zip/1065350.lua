-- Lua provided by RyzenAPI
-- Game: AppID 1065350

-- MAIN APPLICATION
addappid(1065350)
addappid(1065620)
addappid(1065621)
addappid(1065622)
addappid(1065623)
addappid(1065624)
addappid(1065625)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065351, 1, "9a524b62dd2abf6fbdaccc73f40b2662b07e2696675546b51cefe6ed84303e4d")

