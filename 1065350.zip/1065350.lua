-- Lua provided by SkyAPI 
-- Game: AppID 1065350
addappid(1065350)
addappid(1065351, 1, "9a524b62dd2abf6fbdaccc73f40b2662b07e2696675546b51cefe6ed84303e4d")
