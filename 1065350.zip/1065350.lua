-- Lua provided by RyzenAPI
-- Game: 1065350

-- MAIN APPLICATION
addappid(1065350)
-- Game: addappid(1065350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065351, 1, "9a524b62dd2abf6fbdaccc73f40b2662b07e2696675546b51cefe6ed84303e4d")
