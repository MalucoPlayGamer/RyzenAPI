-- Lua provided by RyzenAPI
-- Game: 1408390

-- MAIN APPLICATION
addappid(1408390)
-- Game: addappid(1408390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408390,0,"30f495faf8482a92d1ec6e2338de1579fa4ee5d2b49f793de32254466c169aa6")
