-- Lua provided by RyzenAPI
-- Game: 1028250

-- MAIN APPLICATION
addappid(1028250)
-- Game: addappid(1028250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028251, 1, "12ab8bb9669001ad900071bdae9d59af309efa2b141060e8da88ecfcbce9b74a")
