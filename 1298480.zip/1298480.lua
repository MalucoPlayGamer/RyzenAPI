-- Lua provided by RyzenAPI
-- Game: Kardboard Kings: Card Shop Simulator

-- MAIN APPLICATION
addappid(1298480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298481, 1, "972acacc2725311c2d9bd6c08b5ac3fc314deb1f77f0e87d2cf0555a436eb3be")

