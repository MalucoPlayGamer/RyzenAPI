-- Lua provided by RyzenAPI
-- Game: Ashen - Original Soundtrack

-- MAIN APPLICATION
addappid(1202450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202450,0,"dbbda4838c357b7c93631581c3951fd49552941e9e844289e95cb8a69b99b589")

