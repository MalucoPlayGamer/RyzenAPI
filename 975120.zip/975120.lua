-- Lua provided by RyzenAPI
-- Game: ~necromancy~Emily's Escape

-- MAIN APPLICATION
addappid(975120)

-- MAIN APP DEPOTS / PACKAGES
addappid(975121, 1, "e3eacf8ac4e002a00357d1ff0d4a916dc7de5738b2abdb93da20710099ae0a31")
addappid(2224180, 0, "19b7cee8f66c1aff6e4bd3d2e363fcaa7489ee0ef57bd90abb40b93622d89112")

