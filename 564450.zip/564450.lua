-- Lua provided by RyzenAPI
-- Game: Whispered Secrets: The Story of Tideville Collector's Edition

-- MAIN APPLICATION
addappid(564450)

-- MAIN APP DEPOTS / PACKAGES
addappid(564451,0,"8f8d250aed26896f1a414a8076af005dc34857d75703a6799a440a56d1f82622")

