-- Lua provided by SkyAPI 
-- Game: The Faceless Killer
addappid(3082890)
addappid(3082891, 1, "1c2f59f5f1b3942770999e1841a68826020625b3367816eea98da322be2c5ed5")
