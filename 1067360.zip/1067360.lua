-- 1067360's Lua and Manifest Created by Hubcap Manifest
-- Pax Autocratica
-- Created: August 10, 2026 at 11:02:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1067360) -- Pax Autocratica
addtoken(1067360, "18077378792152236908")
-- MAIN APP DEPOTS
addappid(1067361, 1, "23f1500469c517a7c93decc37b90c10f898209b03d691861820093164f4a1db7") -- Depot 1067361
setManifestid(1067361, "8454921553401375778", 33505495228)