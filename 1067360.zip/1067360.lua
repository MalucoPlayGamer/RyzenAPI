-- Lua provided by RyzenAPI
-- Game: Pax Autocratica

-- MAIN APPLICATION
addappid(1067360) -- Pax Autocratica

-- MAIN APP DEPOTS / PACKAGES
addappid(1067361, 1, "23f1500469c517a7c93decc37b90c10f898209b03d691861820093164f4a1db7") -- Depot 1067361
addtoken(1067360, "18077378792152236908")

