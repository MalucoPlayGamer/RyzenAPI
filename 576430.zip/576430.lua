-- Lua provided by RyzenAPI
-- Game: World Of Robots

-- MAIN APPLICATION
addappid(576430)

-- MAIN APP DEPOTS / PACKAGES
addappid(576431, 1, "dcc2c39e6a13fb6e6da57af53efc5471eaac32cf65eb9e21ada113eb7a78cfdf")
