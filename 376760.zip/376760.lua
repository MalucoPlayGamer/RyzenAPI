-- Lua provided by RyzenAPI
-- Game: Big Thinkers Kindergarten

-- MAIN APPLICATION
addappid(376760)
-- Game: addappid(376760)

-- MAIN APP DEPOTS / PACKAGES
addappid(376761, 1, "686b98b405c9dcf36511d8caf854bd920d6eb95e36ac1de58f45e4f60e24022a")
addappid(376762, 1, "6cc78a34bc6120b07a1447ee82fa461eb03a10ab9373267322c3f515e21e7ce5")
addappid(376765, 1, "ad7b780c213303fe8f6533066a02ede4fe2f301345aafcd711fb9785c0aa93f8")
addappid(376766, 1, "592a80ded599d49b9d71195401c3164e8c024e6685caadc6d71137b8847a94d0")
