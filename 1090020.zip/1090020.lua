-- Lua provided by RyzenAPI
-- Game: JETBOY

-- MAIN APPLICATION
addappid(1090020)
addappid(1090021)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090022,0,"eeadd2c394d9d72f8d3184a81c6e531bfe683026b9d3a21e8a5d0b7af0fe5d13")

