-- Lua provided by SkyAPI 
-- Game: Dead end Exit 8
addappid(2780270)
addappid(2780271, 1, "e515564835d5ed1c041cd7803e05a6c2d58a7007d351927f9b9d650b6d2e25f7")
