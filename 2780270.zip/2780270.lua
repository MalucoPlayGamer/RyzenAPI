-- Lua provided by RyzenAPI
-- Game: Dead end Exit 8

-- MAIN APPLICATION
addappid(2780270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780271, 1, "e515564835d5ed1c041cd7803e05a6c2d58a7007d351927f9b9d650b6d2e25f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
