-- Lua provided by RyzenAPI
-- Game: Yargis - Space Melee - Level Editor

-- MAIN APPLICATION
addappid(382010)

-- MAIN APP DEPOTS / PACKAGES
addappid(382011, 1, "7bae975352b02e9c0be81ab2f2eaefd9fb39113ac78111250ba9349d837af7c9")

