-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 3

-- MAIN APPLICATION
addappid(1433670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433670,0,"be3d6c3ee55ad3710fa660344aa44698637a6ef5144d83a97bd2e769324aec4a")
