-- Lua provided by RyzenAPI
-- Game: Chinese Expeditionary Force - Assault Team

-- MAIN APPLICATION
addappid(2266910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266911, 1, "6e78f113b30d1e259296b39b83c54e8c58beaa3b0ca86b0c1fbe54e4ec328c1a")

