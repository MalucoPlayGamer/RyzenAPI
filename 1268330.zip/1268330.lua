-- Lua provided by RyzenAPI
-- Game: addappid(1268330)

-- MAIN APPLICATION
addappid(1268330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268331, 1, "873bb276621fd5987d8461172d987dfd2e7ffd55f08afa771ae15dfafdd7f3d7")
