-- Lua provided by SkyAPI 
-- Game: Enhance VR
addappid(1268330)
addappid(1268331, 1, "873bb276621fd5987d8461172d987dfd2e7ffd55f08afa771ae15dfafdd7f3d7")
