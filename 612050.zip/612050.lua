-- Lua provided by RyzenAPI
-- Game: addappid(612050)

-- MAIN APPLICATION
addappid(612050)

-- MAIN APP DEPOTS / PACKAGES
addappid(612051, 1, "adb94bbd35ef1bf5e17d94f9db1522b378153b5169f81e726eb22023c526d414")
