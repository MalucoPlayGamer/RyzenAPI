-- Lua provided by RyzenAPI
-- Game: DreamWorld Playtest

-- MAIN APPLICATION
addappid(3231280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231281, 1, "5dd2b0230616c985f91f46d6b63137ce8ea2f15d1e5447892068e3f6aab4fcb5")

