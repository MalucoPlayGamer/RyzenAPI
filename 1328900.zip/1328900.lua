-- Lua provided by RyzenAPI
-- Game: Explorer of Yggdrasil

-- MAIN APPLICATION
addappid(1328900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328901, 1, "a3250aa5798c7131ea858cc429d3c20dbc09f097d43aa30053895aa1ff8d3dee")
addappid(1328902, 1, "c887e68c72f9f55e45545275cfb7cccba82756427797d6176874b01403eb5c58")
addappid(1328903, 1, "6c25a477e11d88c19dbe2aa893c687f1d6db25d3d9115b507e9b299a6c00bef9")
