-- Lua provided by RyzenAPI
-- Game: Mortal Shell II

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(2584270, 1, "2b9f4a2124d5757f3d4f46c81c6d4082f3b1d1ac9b3233acf41ddc6b5c15810a")
addappid(2584271, 1, "bb59e6dc30df8728a4bfcc3129ca9b8284ed3808d42a9a272e65d4904b4bc445")

