-- Lua provided by SkyAPI 
-- Game: Grass Cutter - Mutated Lawns
addappid(589420)
addappid(589421, 1, "24091c04572d7bf57f301c6bb0c9507ed94a30bba3441a424af51cd253248884")
addappid(589422, 1, "e3522926abd62aff0de4622d4f79c3d08d3293c931c5fd781e0a5ecf78542ec9")
addappid(589424, 1, "2dcbcd3e717e5532b2ff837665c80144c47d88ec08c4fbd8fe0cdb4481462097")
