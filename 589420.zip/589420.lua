-- Lua provided by RyzenAPI
-- Game: Grass Cutter - Mutated Lawns

-- MAIN APPLICATION
addappid(589420)

-- MAIN APP DEPOTS / PACKAGES
addappid(589421, 1, "24091c04572d7bf57f301c6bb0c9507ed94a30bba3441a424af51cd253248884")
addappid(589422, 1, "e3522926abd62aff0de4622d4f79c3d08d3293c931c5fd781e0a5ecf78542ec9")
addappid(589424, 1, "2dcbcd3e717e5532b2ff837665c80144c47d88ec08c4fbd8fe0cdb4481462097")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(864180)
addappid(864181)
addappid(864182)
addappid(864183)
addappid(864184)
addappid(864185)
addappid(864186)
addappid(864187)
addappid(864188)
addappid(864189)
addappid(882350)
addappid(886660)
addappid(886661)
addappid(993240)
addappid(993241)
