-- Lua provided by RyzenAPI
-- Game: Game: World War 2 Winter Gun Range VR Simulator

-- MAIN APPLICATION
addappid(1161440)
-- Game: addappid(1161440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161441, 1, "99906a95859eda6c1e983d1543cce86e23d9499586fead4d612f23662979b70a")
