-- Lua provided by RyzenAPI
-- Game: Dodgy Deliveries

-- MAIN APPLICATION
addappid(2231300)
addappid(3424440)

