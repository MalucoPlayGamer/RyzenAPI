-- Lua provided by RyzenAPI
-- Game: Dodgy Deliveries

-- MAIN APPLICATION
addappid(2231300)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3424440)
