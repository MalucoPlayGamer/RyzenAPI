-- Lua provided by RyzenAPI
-- Game: Rag Doll Joe

-- MAIN APPLICATION
addappid(802050)
-- Game: addappid(802050)

-- MAIN APP DEPOTS / PACKAGES
addappid(802052,0,"32c0f5f72069c4094de9452607cb5c0b71fc306d40497373f6b32675a224512d")
