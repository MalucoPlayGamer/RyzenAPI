-- Lua provided by RyzenAPI
-- Game: addappid(1562910)

-- MAIN APPLICATION
addappid(1562910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562911, 1, "ff396e6adba85eb22f9999bcbfbbd133d945ad6ea50a98112f4c0d71c13535af")
