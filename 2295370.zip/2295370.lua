-- Lua provided by RyzenAPI
-- Game: AppID 2295370

-- MAIN APPLICATION
addappid(2295370)
-- Game: addappid(2295370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295371, 1, "2bed6614bcc89a7a3131410ec933948c146262d473b9d2b0f7d8a3b9f109369b")
