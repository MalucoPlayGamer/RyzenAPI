-- Generated with Luie @ https://lua.tools/
-- 1934680 - Age of Mythology: Retold
-- Generated 2026-08-09 02:26:48 UTC
-- # Depots (Total/DLC/Shared): 15/2/1

-- Main AppID
addappid(1934680, 1, "0684e548cc90b1cc08ffdd2d7047e567724a7d90833cf75e168d5f218bbd6818")

-- Main Depots
addappid(1934681, 1, "802af330b3164b4c3b78d2f3b015e1017979ec6738f5d952aeb72eb14a138f19") -- (windows, 64-bit)
setManifestid(1934681, "7738296516183117957", 36621798599)
addappid(2991161, 1, "fae9ece6176586c7ad4c1d4d07e75e8a242d36d65d0402f3d20b5e86a58a6235") -- German
setManifestid(2991161, "4811674272864004489", 146742372)
addappid(2991162, 1, "bb3cd97225c4980fef59f25e876b5532339ff29dbceb7d4fc12190fde94bd372") -- Spanish
setManifestid(2991162, "3421898728506047574", 144349021)
addappid(2991163, 1, "c47645f8442a72793113ab28d3206eb7841e9eed83e1817307859ac900a973f3") -- Latam
setManifestid(2991163, "8142827570320120352", 134974552)
addappid(2991164, 1, "8e17cff7c72b2eb5c1f2a5c16e5088810e0b5a33678f0d62455aabdab9ba2b1e") -- French
setManifestid(2991164, "3436823808828691476", 137569342)
addappid(2991165, 1, "27aacd4bd5627dd1a4743bba1773d24b4a05993f10bff71faeb3f492d619366f") -- Italian
setManifestid(2991165, "7805241958788664900", 139203187)
addappid(2991166, 1, "3a5ba82ffea3a7063fe196e3bb0af72a423c2dc227c4d80b7798161fe655c684") -- Japanese
setManifestid(2991166, "6037174168956083578", 134685661)
addappid(2991167, 1, "cbac32577b886bb30bfeb6c606edb883e882c3fc1105f56f3a3fc0d4c8e2ed90") -- Koreana
setManifestid(2991167, "8229049143664449236", 146053006)
addappid(2991168, 1, "71854c8d94abca5cbeebd6ac1eb8edad6fd674437d935f99b70cff19034bbaec") -- Brazilian
setManifestid(2991168, "622057314649327021", 139277791)
addappid(2991169, 1, "c2504a8202da8fed8ef95c22f3528335c285257173876e4ff0ad1f351f4dd1a9") -- Schinese
setManifestid(2991169, "2993841547426732093", 132582340)
addappid(2991171, 1, "495e93c32f00d9f9ca59ada943e22fd8a423448c4e512b0903b92ae40730f01b") -- Tchinese
setManifestid(2991171, "2577266917868286635", 135044584)

-- DLC's (no depot keys required)
addappid(2991160) -- Age of Mythology: Retold - Legacy Deity Portrait Pack
addappid(2991170) -- Age of Mythology: Retold - Immortal Pillars
addappid(2991180) -- Age of Mythology: Retold - Heavenly Spear
addappid(2991190) -- Age Of Mythology: Retold - New Gods Pack: Freyr
addappid(3398380) -- Age of Mythology: Retold - New Gods Pack: Demeter
addappid(4140570) -- Age of Mythology: Retold - Ultimate Fan Pack
addappid(4180380) -- Age of Mythology: Retold - Expansion Pass
addappid(4197930) -- Age of Mythology: Retold - Blood & Bones Pack
addappid(4197940) -- Age of Mythology: Retold - Obsidian Mirror

-- DLC's (with depot keys)
-- Age of Mythology: Retold Soundtrack (AppID: 3076160)
addappid(3076160)
addappid(3076161, 1, "332bc0bb9f61297e37a4f41bd6ae645b9572f527337f421429989228d86377fb")
setManifestid(3076161, "9067044646339092762", 37311258)
addappid(3076162, 1, "9ec22e5e7c6db1454a651e961e7de31cc280033a7faa3d4f6c19cf87ce998e91")
setManifestid(3076162, "2624300731339673526", 672666534)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 2991172
