-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel - Back to School Costume Pack

-- MAIN APPLICATION
addappid(1804140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804141, 1, "297d8da63c51fccefc3a5ec5bafd2b7da4f71ab43e99df86ab75d6c895415f80")
