-- Lua provided by RyzenAPI
-- Game: her tears were my light

-- MAIN APPLICATION
addappid(2112520)
-- Game: addappid(2112520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112521, 1, "20f648d46dcf9a87a49cf665fbedd4c4bbe7496fa1d149d1142ec636eafe3425")
