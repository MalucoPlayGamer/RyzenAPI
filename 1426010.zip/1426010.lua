-- Lua provided by RyzenAPI
-- Game: STASIS: BONE TOTEM

-- MAIN APPLICATION
addappid(1426010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426012,0,"5971cb24c794d6d81a35f3c24668c6f1e77a5d29597c44103a5571649d9e8e94")
addappid(1426013,0,"db206a58dd2d8ed963e046cbbf9e37e7abb724154104d0d4779e5598cd2c7058")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2415780)
