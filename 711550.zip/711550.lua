-- Lua provided by RyzenAPI
-- Game: 711550

-- MAIN APPLICATION
addappid(711550)
-- Game: addappid(711550)

-- MAIN APP DEPOTS / PACKAGES
addappid(711551, 1, "b7859b791751ae421edc0dd8d2a34deba470031f4b6c6e740673b0a363e4a876")
