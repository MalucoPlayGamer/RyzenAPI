-- Lua provided by RyzenAPI
-- Game: addappid(550820)

-- MAIN APPLICATION
addappid(550820)

-- MAIN APP DEPOTS / PACKAGES
addappid(550821, 1, "af674b5253b833c4d73ac16cc4affc15a1a5898a04d13d42e78419eae90f1466")
