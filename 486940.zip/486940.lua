-- Lua provided by RyzenAPI
-- Game: Handball Action Total

-- MAIN APPLICATION
addappid(486940)

-- MAIN APP DEPOTS / PACKAGES
addappid(486941, 1, "a3d4af1403c909964d46a110f7f264c2130d91e87076515b88d677e4bda0f3f7")
addappid(486942, 1, "d74a3c44ef874d2e4ae20a218376f10f208010c027d7f64577ad14e1bb11be73")
