-- Lua provided by RyzenAPI
-- Game: 1925550

-- MAIN APPLICATION
addappid(1925550)
-- Game: addappid(1925550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925553,0,"2670fad6db4ba6f9c313a78e708aa3827688c2e727211ae1553f8c7fbe049fc0")
