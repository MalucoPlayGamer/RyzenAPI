-- Lua provided by RyzenAPI
-- Game: addappid(1131270)

-- MAIN APPLICATION
addappid(1131270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131271, 1, "720872b6e2bfa38c7d44b62ea5ff9d78092ad48c228a81b0674bda6d0390025a")
