-- Lua provided by RyzenAPI 
-- Game: CIPHER ZERO soundtrack
addappid(2878660)
addappid(2878661, 1, "434f32e0f52e05b0e7ea9b5570ee6fb435c384b082f1c07943c762d83a42efda")
addappid(2878662, 1, "198e54da516dfad422e443aab3ab4d24ad690dc52829555f07216a8b834a409c")
