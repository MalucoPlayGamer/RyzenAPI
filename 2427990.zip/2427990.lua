-- Lua provided by RyzenAPI
-- Game: addappid(2427990)

-- MAIN APPLICATION
addappid(228989)
addappid(229007)
addappid(2427990)
addappid(2427991)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427992,0,"d72cbf34a3bb72a13125d4e0c3d2cebd5c1ab878fde577f37aa1d4832b50ccf6")
