-- Lua provided by RyzenAPI
-- Game: Roadwarden

-- MAIN APPLICATION
addappid(1155970)
-- Game: addappid(1155970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155971, 1, "893bfbcfcc103935964f4903fd190cfa06466e465bbdfaf9d874c0326c5fe334")
addappid(1155972, 1, "9e26b4278c37743d58448fc5b4a1d3204e64626ff051e1af98b82ad13acd8f7c")
addappid(1155973, 1, "6c1da5eb629f6235a11614baf396a0ff943132785336d2e9071098629fccabf3")
