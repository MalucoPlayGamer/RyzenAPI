-- Lua provided by RyzenAPI
-- Game: Nickelodeon All-Star Brawl - Jenny Brawler Pack

-- MAIN APPLICATION
addappid(1944980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944980,0,"f6628ee429cdf1918d0025901b2e6ed14d2342611bfc754faa1ff26bff58d36b")
