-- Lua provided by RyzenAPI
-- Game: Game: AppID 2963880

-- MAIN APPLICATION
addappid(2963880)
-- Game: addappid(2963880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963881, 1, "c3a31b0c3db48e0ad7f0245194d068209eb66d50106821e8b64ab67d3c29a2fa")
