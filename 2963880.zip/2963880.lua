-- Lua provided by RyzenAPI
-- Game: AppID 2963880

-- MAIN APPLICATION
addappid(2963880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963881, 1, "c3a31b0c3db48e0ad7f0245194d068209eb66d50106821e8b64ab67d3c29a2fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
