-- Lua provided by RyzenAPI
-- Game: The Deletion

-- MAIN APPLICATION
addappid(391160)

-- MAIN APP DEPOTS / PACKAGES
addappid(391161, 1, "c609266495c7c43315a12ecd16aa598d59bacb38b1a3af80bc4db074d7d6f34b")
addappid(391162, 1, "7927d1a6450e812d7b097f51e563ada0ccec8317ba45507784380ed8b2866f4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
