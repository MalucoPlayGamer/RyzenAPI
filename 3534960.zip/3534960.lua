-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel (Manga) Vol. 4

-- MAIN APPLICATION
addappid(3534960)
-- Game: addappid(3534960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3534961, 1, "b3633c4af84fb66818f51ad19d1c2a7716b06f554ab001d9f5f94943f9496ad2")
