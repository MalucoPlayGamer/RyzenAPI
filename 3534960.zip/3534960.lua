-- Lua provided by RyzenAPI 
-- Game: Fuga: Melodies of Steel (Manga) Vol. 4
addappid(3534960)
addappid(3534961, 1, "b3633c4af84fb66818f51ad19d1c2a7716b06f554ab001d9f5f94943f9496ad2")
