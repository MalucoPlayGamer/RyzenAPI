-- Lua provided by RyzenAPI
-- Game: War Tanks

-- MAIN APPLICATION
addappid(2018320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018321, 1, "ee80ce1f975af40114dba1745e7787612d9fc90e0a05ce1ece2e3e304a8165f8")

