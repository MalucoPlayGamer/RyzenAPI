-- Lua provided by RyzenAPI
-- Game: Battle Of Europe

-- MAIN APPLICATION
addappid(321710)

-- MAIN APP DEPOTS / PACKAGES
addappid(321711, 1, "ce4be423020cfa3000994b3bcb73681871a3dfa442ab76cced0a0b2bd9af1469")

