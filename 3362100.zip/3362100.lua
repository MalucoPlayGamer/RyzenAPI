-- Lua provided by RyzenAPI
-- Game: 3362100

-- MAIN APPLICATION
addappid(3362100)
-- Game: addappid(3362100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362101, 1, "ff677859dc25b1fc214acef532fb28b64a5326ceed07679bd7ef6da18abc3e96")
