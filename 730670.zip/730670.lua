-- Lua provided by RyzenAPI
-- Game: EXIT 3 - Painter

-- MAIN APPLICATION
addappid(730670)

-- MAIN APP DEPOTS / PACKAGES
addappid(730671,0,"4eceb627fe5b76445b303cc45f01154164466f4c60aff7a336f2a0ded991c6e4")

