-- Lua provided by RyzenAPI 
-- Game: NEKO-NIN exHeart Demo
addappid(616730)
addappid(616731, 1, "d585d3a356fd635ce2c44fc1d13749ed9f87a0d37a2a1a8bf005a75891be9548")
