-- Lua provided by RyzenAPI
-- Game: AppID 929460

-- MAIN APPLICATION
addappid(929460)

-- MAIN APP DEPOTS / PACKAGES
addappid(929461, 1, "f41ba216306754991032d4d244cf0800006cf5eb0821d73e0b550594593b0511")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
