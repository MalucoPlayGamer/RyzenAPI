-- Lua provided by RyzenAPI
-- Game: Yooka-Laylee Soundtrack

-- MAIN APPLICATION
addappid(564250)

-- MAIN APP DEPOTS / PACKAGES
addappid(564250,0,"d1d7ec1bf13f0540c2d9a64d0522f48d65b97e6a5c2003bca65b72ff0c0eafbc")

