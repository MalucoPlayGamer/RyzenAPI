-- Lua provided by RyzenAPI
-- Game: Kill Yourself

-- MAIN APPLICATION
addappid(1251910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251911, 1, "b1f37f7e90a7328990aec50b682ce34099d4c4ef07edc30a1b155e8a0e107750")

