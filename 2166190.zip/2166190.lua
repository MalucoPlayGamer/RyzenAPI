-- Lua provided by SkyAPI 
-- Game: Juan Sin Miedo
addappid(2166190)
addappid(2166191, 1, "39712c24d100dd17d5ee1f6520cc825d80254f5ea5f4d826dfd0f542efcd084c")
