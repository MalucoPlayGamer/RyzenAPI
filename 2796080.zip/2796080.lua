-- Lua provided by RyzenAPI
-- Game: VAGUE Playtest

-- MAIN APPLICATION
addappid(2796080)
-- Game: addappid(2796080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796081, 1, "ad8d5f7a192997742ee1fa82968250145e57cba39b50fe3f85110146a448d4e8")
