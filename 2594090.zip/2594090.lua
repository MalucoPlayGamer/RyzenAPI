-- Lua provided by RyzenAPI
-- Game: Beat Saber - JAY-Z, Linkin Park - Numb/Encore

-- MAIN APPLICATION
addappid(2594090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594090,0,"7ee824a6a48935379cea0b3b6d46c75aed1060b95d731c08cbe509cd20da293d")
