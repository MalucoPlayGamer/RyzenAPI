-- Lua provided by RyzenAPI
-- Game: Divided We Fall: Play For Free

-- MAIN APPLICATION
addappid(495580)
addappid(862760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(495581, 1, "d05072a13b52baba974b70a3c51d6bfdc19482b36bd9abd82392ea21722ac6bd")
addappid(495582, 1, "89916a28ab2161446227ea778f93883dd4eb5391d59040a4a2ae991ee0e6ac8e")
addappid(495583, 1, "b8b1a0d9f335eb6499c11ab85c4e7ca24c56c70fc29109cc89ba47214d3c5c48")

