-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Boys

-- MAIN APPLICATION
addappid(2494410)
-- Game: addappid(2494410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494411, 1, "0ad1f6f4871cee26378098640c69e41dc66ed125aa51d02bbd1125dfaf389d5f")
