-- Lua provided by RyzenAPI
-- Game: AppID 411130

-- MAIN APPLICATION
addappid(411130)

-- MAIN APP DEPOTS / PACKAGES
addappid(411131, 1, "8cbffbe0dcec14a94f4eecaec416a90e6ac3aebf3ff8b19dcb265345ea166cd5")
addappid(411132, 1, "6d8247c72682df7590869d9ea802dced447a3782f1c440a2a86e8cfc0c5018c2")
addappid(411133, 1, "7980bc202b38ef9e170b3ddf7237f8c62116d049d55ab955fd773ae0e57a14aa")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(500970)
