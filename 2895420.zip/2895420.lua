-- Lua provided by RyzenAPI
-- Game: AppID 2895420

-- MAIN APPLICATION
addappid(2895420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895421, 1, "127f30b81fd3ae4d1edf8b3abd66d2b22838fb7962fe9011fbdba89da8c74c5e")
