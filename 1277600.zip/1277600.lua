-- Lua provided by RyzenAPI
-- Game: X4: Split Vendetta Soundtrack

-- MAIN APPLICATION
addappid(1277600)
-- Game: addappid(1277600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277602,0,"597f38f2ff1e339ed6509e92bd11146fc1a6fc790c516128da0d1d78ce13bce2")
addappid(1277603,0,"8a9e1dcefa49ea15844d0ae71aaf47e89040d20677f5b70e098b8065137d9add")
