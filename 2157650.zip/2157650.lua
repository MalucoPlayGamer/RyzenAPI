-- Lua provided by RyzenAPI
-- Game: Dead City

-- MAIN APPLICATION
addappid(2157650)
addappid(2458630)
addappid(2475180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157651, 1, "f0b08a5724aed13278c3ca69d6e9c06a497cbb4ecf85681e89def40bb2408174")

