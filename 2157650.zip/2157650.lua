-- Lua provided by RyzenAPI
-- Game: Dead City

-- MAIN APPLICATION
addappid(2157650)
addappid(2458630)
addappid(2475180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2157651, 1, "f0b08a5724aed13278c3ca69d6e9c06a497cbb4ecf85681e89def40bb2408174")

