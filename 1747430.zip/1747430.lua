-- Lua provided by RyzenAPI
-- Game: Bomberpet

-- MAIN APPLICATION
addappid(1747430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1747431, 1, "733ce4f1479b85489e84b52c57d5ff9094dbf3171709648a114726b34c18c9dd")

