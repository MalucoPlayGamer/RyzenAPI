-- Lua provided by RyzenAPI
-- Game: STRIKERS 1945 II

-- MAIN APPLICATION
addappid(1279380)
-- Game: addappid(1279380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279381, 1, "c6788c745ef58dc8ab8cdcd744c44310b9c7ff3c44f4945fee1a8022f92e8267")
