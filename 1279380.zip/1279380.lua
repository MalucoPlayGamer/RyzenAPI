-- Lua provided by RyzenAPI 
-- Game: AppID 1279380
addappid(1279380)
addappid(1279381, 1, "c6788c745ef58dc8ab8cdcd744c44310b9c7ff3c44f4945fee1a8022f92e8267")
