-- Lua provided by RyzenAPI
-- Game: 1628610

-- MAIN APPLICATION
addappid(1628610)
-- Game: addappid(1628610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628611, 1, "3841bd6682378b0850ebd555fd0a481b8dcda235ae96ba2c0031fa080a76b56e")
