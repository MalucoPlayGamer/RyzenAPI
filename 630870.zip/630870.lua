-- Lua provided by RyzenAPI
-- Game: 630870

-- MAIN APPLICATION
addappid(630870)
-- Game: addappid(630870)

-- MAIN APP DEPOTS / PACKAGES
addappid(630871, 1, "9596dab0557df1d713163a6b722efc9953b2b4927ecd291660e56b76be4a92b3")
addappid(823301, 0, "9a71f649d468b6b85886ab682e7b016f07a884adf8f9b38fc60aad7b5cb36003")
