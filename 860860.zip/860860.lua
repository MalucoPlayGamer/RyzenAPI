-- Lua provided by SkyAPI 
-- Game: AppID 860860
addappid(860860)
addappid(860861, 1, "089b8c64ff170fb43924fb130111de950f5479fcfa21d17b672cac8d570e56fa")
addappid(860862, 1, "10d5c1710c834a7534f0ffdc5026fec354a9c2dc9cd2f7e5e07ff40d864ef6af")
addappid(860863, 1, "eb1ab805aef27581575b4c19c48ed0ced7297a6b8d4a241c1c8472e1aec84306")
