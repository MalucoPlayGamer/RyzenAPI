-- Lua provided by RyzenAPI
-- Game: AppID 3403320

-- MAIN APPLICATION
addappid(3403320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403321, 1, "fefb4d097f88be12a092942c84a33663bc64cd2845c80f6007f68fba4fee9c8c")
