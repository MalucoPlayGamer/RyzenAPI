-- Lua provided by RyzenAPI
-- Game: addappid(491130)

-- MAIN APPLICATION
addappid(491130)
addappid(491131)

-- MAIN APP DEPOTS / PACKAGES
addappid(491133,0,"06d3dfc70df3d50c4228656f264494efc7c4d9dc54e0a4c927f4c7971dbb8d02")
