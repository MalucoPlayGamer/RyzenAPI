-- Lua provided by RyzenAPI
-- Game: Endless Crusade

-- MAIN APPLICATION
addappid(782020)

-- MAIN APP DEPOTS / PACKAGES
addappid(782021,0,"f70511c66a2f9936e01c5f7d4a10b171615b54385761e252c084352f40e13db5")

