-- Lua provided by RyzenAPI
-- Game: 「奇天烈相談ダイヤル」HEARD未回収怪異のみ出現

-- MAIN APPLICATION
addappid(2918380)
-- Game: addappid(2918380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918381, 1, "5a242a9a42366164d310a636b16d855f761937b74068b16c9b3900786bb10f46")
addappid(2918383, 1, "93da686b997318c9cf6a8223b4a2974a3347f01a8a11ae516a08cdf97f97a5cb")
