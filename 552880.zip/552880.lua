-- Lua provided by RyzenAPI 
-- Game: AppID 552880
addappid(552880)
addappid(552881, 1, "f3b53be8b7c55de24d785f2abc575d85e4bc6bf4d4fa275cbb9c355f9791f432")
