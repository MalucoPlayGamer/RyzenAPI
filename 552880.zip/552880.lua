-- Lua provided by RyzenAPI
-- Game: STARDROP

-- MAIN APPLICATION
addappid(552880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552881, 1, "f3b53be8b7c55de24d785f2abc575d85e4bc6bf4d4fa275cbb9c355f9791f432")
