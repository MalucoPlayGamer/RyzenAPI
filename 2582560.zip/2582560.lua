-- Lua provided by RyzenAPI
-- Game: EA SPORTS™ Madden NFL 25

-- MAIN APPLICATION
addappid(2582560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582561, 1, "ac359dbd4e38d078bab3b059797599a3c7f41423406c468825b27386afce46c4")
addappid(2582562, 1, "833e8a4e1f351c4d37259578665fe7384c32bc36569fb9b7febd77aa7772735d")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2582590)
addappid(2898480)
addappid(2898490)
addappid(2898500)
addappid(2898510)
addappid(2898530)
