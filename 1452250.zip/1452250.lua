-- Lua provided by RyzenAPI
-- Game: Game: Underground Garage

-- MAIN APPLICATION
addappid(1452250)
-- Game: addappid(1452250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452251, 1, "ce6083023fe1c79bd239730313703f8074978705a075f13dd6234c45b8d79156")
