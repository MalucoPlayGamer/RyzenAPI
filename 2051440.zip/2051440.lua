-- Lua provided by RyzenAPI
-- Game: Guardener

-- MAIN APPLICATION
addappid(2051440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2051441, 1, "f957318ef6e36855c2104b7536cf28b24b3dd0499cfbfdceb9d76ca53a85c44c")
addappid(2051442, 1, "5af279d5b0e6d86d9808788dbc246e6a00d87cd6115c1454e438bb1e7d30de10")
