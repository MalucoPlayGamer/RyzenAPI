-- Lua provided by RyzenAPI
-- Game: 601550

-- MAIN APPLICATION
addappid(601550)
-- Game: addappid(601550)

-- MAIN APP DEPOTS / PACKAGES
addappid(601551, 1, "38934a646646eccce7268a04d2127e7b2dd63dd7fca715942c0847406ce659af")
