-- Lua provided by RyzenAPI
-- Game: AppID 601550

-- MAIN APPLICATION
addappid(601550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(601551, 1, "38934a646646eccce7268a04d2127e7b2dd63dd7fca715942c0847406ce659af")

