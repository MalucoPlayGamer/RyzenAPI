-- Lua provided by SkyAPI 
-- Game: AppID 601550
addappid(601550)
addappid(601551, 1, "38934a646646eccce7268a04d2127e7b2dd63dd7fca715942c0847406ce659af")
