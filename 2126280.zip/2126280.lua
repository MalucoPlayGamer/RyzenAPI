-- Lua provided by RyzenAPI
-- Game: AppID 2126280

-- MAIN APPLICATION
addappid(2126280)
-- Game: addappid(2126280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126281, 1, "fec4f397993b3fc2bd5e264acd1b7bd5b5efb69946d2505924d5e57dcea115a9")
