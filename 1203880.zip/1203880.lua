-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1203880)
addappid(1203881)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052442,0,"7313cebb9915470b539bc2d8170d472208af7476e72689107aa0c4ae259d30db")
