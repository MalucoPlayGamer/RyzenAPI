-- Lua provided by RyzenAPI
-- Game: Warhammer Age of Sigmar: Realms of Ruin

-- MAIN APPLICATION
addappid(1844380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844381, 1, "34ab542f6d7b2eb7aa9e7623c37b81259208343c7989509c7dc2e559405fa22d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2531100)
addappid(2531110)
addappid(2531120)
addappid(2531130)
addappid(2744270)
addappid(2744280)
