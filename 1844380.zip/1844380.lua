-- Lua provided by RyzenAPI
-- Game: Warhammer Age of Sigmar: Realms of Ruin

-- MAIN APPLICATION
addappid(1844380)
-- Game: addappid(1844380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844381, 1, "34ab542f6d7b2eb7aa9e7623c37b81259208343c7989509c7dc2e559405fa22d")
