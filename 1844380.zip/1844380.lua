-- Lua provided by SkyAPI 
-- Game: Warhammer Age of Sigmar: Realms of Ruin
addappid(1844380)
addappid(1844381, 1, "34ab542f6d7b2eb7aa9e7623c37b81259208343c7989509c7dc2e559405fa22d")
