-- Lua provided by RyzenAPI
-- Game: Warhounds

-- MAIN APPLICATION
addappid(3929470) -- Warhounds
-- addappid(4961470) -- Depot 4961470 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3929471, 1, "52f4a1effcf7e1f1c151b4134820bc29a4cd95f614a5bca7e369d33595d5ab59") -- Depot 3929471

