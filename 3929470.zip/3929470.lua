-- 3929470's Lua and Manifest Created by Hubcap Manifest
-- Warhounds
-- Created: August 11, 2026 at 12:17:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3929470) -- Warhounds
-- MAIN APP DEPOTS
addappid(3929471, 1, "52f4a1effcf7e1f1c151b4134820bc29a4cd95f614a5bca7e369d33595d5ab59") -- Depot 3929471
setManifestid(3929471, "4695896505416093277", 79745946907)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4961470) -- Depot 4961470 (empty depot)