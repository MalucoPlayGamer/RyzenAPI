-- Lua provided by RyzenAPI
-- Game: Warhounds

-- MAIN APPLICATION
addappid(3929470)
addappid(4961470)
addappid(4962080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3929471,0,"52f4a1effcf7e1f1c151b4134820bc29a4cd95f614a5bca7e369d33595d5ab59")

