-- Lua provided by RyzenAPI
-- Game: That Level Again 3D

-- MAIN APPLICATION
addappid(2978600)
-- Game: addappid(2978600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978601, 1, "34e0e5dbebfcf251362bfd7cba966627cb16dfebea9fcf53ef9648779a535709")
