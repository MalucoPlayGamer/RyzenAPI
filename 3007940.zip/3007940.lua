-- Lua provided by RyzenAPI
-- Game: addappid(3007940)

-- MAIN APPLICATION
addappid(3007940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007941, 1, "28b2c85481b121f45639b8e897baf539f6ff3b1af81622602f89a8b7af88f1ee")
