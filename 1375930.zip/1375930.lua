-- Lua provided by RyzenAPI
-- Game: 1375930

-- MAIN APPLICATION
addappid(1375930)
-- Game: addappid(1375930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375931, 1, "28ac70974ff7b7d7d5e0774406f3cd681790a7dfb7ac3dfde53ac09572f9dff8")
