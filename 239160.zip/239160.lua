-- 239160's Lua and Manifest Created by Hubcap Manifest
-- Thief
-- Created: January 18, 2026 at 11:00:55 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 26
-- Total DLCs: 10
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(239160, 1, "32a1caddb0ef3e1729babaf30fb9ccc6653b74ca2aa195ad4aeb7cca256dcca0") -- Thief
-- MAIN APP DEPOTS
addappid(239161, 1, "d0a8ff5714ffe9e46ccb7108ad525346fd83ea3df8d0f6722e00e38be96095ac") -- Game Content
setManifestid(239161, "6819396610781968336", 24289090580)
addappid(239163, 1, "f5c3a8eb04f2cfb72afb63371ca681dcba46406327454248e48a1b59295be3b4") -- Executable
setManifestid(239163, "5944136652086045363", 67007488)
addappid(239165, 1, "909d01d709c11a1957591fb44a3b4e3baee47fa6876715724281e34d3d8b5e92") -- English
setManifestid(239165, "7251358258080750182", 686913272)
addappid(239166, 1, "69f5f414655421c9f8f17442685d8a3643bbf89255d79531d4ffb48a0826058e") -- French
setManifestid(239166, "4339077836390544406", 600595232)
addappid(239167, 1, "0012b705c770aaae272cc38f3ee291b5ac585ff290ba5f0d0a7bc32cc072adb6") -- German
setManifestid(239167, "5463413516341896133", 648282399)
addappid(239168, 1, "f519cf7bc744c61f1ed52a4264128374cb33c651bbf60f5389d959ce28e168a2") -- Italian
setManifestid(239168, "7739922370787495047", 652163547)
addappid(239169, 1, "69a4b3aeed0c45c4b53c4bc32ad2358bb98ec52e233e758e7dbb143aa66c6bbe") -- Japanese
setManifestid(239169, "6860708224847381821", 7271087849)
addappid(239170, 1, "1ca64af4b764fd44325bfa22807c7d4a881e3e9d11e6f2312e0828ba652ea6f6") -- Russian
setManifestid(239170, "5129612181890395672", 1425833228)
addappid(239171, 1, "87c85df2bea8c2c49f68663c2cee79efeda9348e6e0818960c5cf02d1369efa7") -- Spanish
setManifestid(239171, "4455148598899732626", 650848018)
addappid(239164, 1, "fbd4018fc0378c6b684e57df6ef3ba56fa3d17c652a334122218431b538eb413") -- Debug
setManifestid(239164, "7487479735804883672", 1924057725)
addappid(239172, 1, "92b9671bc0c021314c775431a84aac44bf0d81b46737bf8117e70fcb825edd58") -- Extras
setManifestid(239172, "5577159069007369752", 196050140)
addappid(239173, 1, "47a6215790e51780f069babf23221590fc553498a67688b55e3d3e7ef89edeac") -- JapaneseText
setManifestid(239173, "7971232348719069127", 0)
addappid(239175, 1, "6c2fe6186e439269fbdfadf259cca8789ed1ff2b29a1b89952d000c86792f40d") -- Mac - Game Content
setManifestid(239175, "5838736400677140093", 29689380403)
addappid(239176, 1, "47c6ec9b4a5c642fc41c64e0bebd784ab81751e5c472dbf14aead281d083f987") -- Mac - Executable
setManifestid(239176, "8964420164700227817", 91930458)
addappid(239178, 1, "6afbf2386caed21b95f88acd2bac02ccfb4ab6ffb3b0b054d7340686d5f3dba3") -- Mac - French
setManifestid(239178, "263062031792714705", 600595232)
addappid(239179, 1, "cf55893f3e4b56f268cd45dfe18fc998007e63f9fb99f560e5e39323ae60f082") -- Mac - German
setManifestid(239179, "695619774406280456", 648282399)
addappid(259901, 1, "1edc875d9a7d3d02883aaef0486c81d76b562d8fa51227a307c37f0ed3390fa1") -- Mac - Italian
setManifestid(259901, "37210961370072519", 652163547)
addappid(259902, 1, "c2083d828053cec83179c834b0d6f136c9ea50c0da721936ddbb8881d9508997") -- Mac - Russian
setManifestid(259902, "1379925817822372282", 639786508)
addappid(259903, 1, "465886fe3d386b750351adaea9e9dff66da32a6393e8fd2ebe87ba4f42d1e43f") -- Mac - Spanish
setManifestid(259903, "149652068009241938", 650848018)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Thief - The Bank Heist (AppID: 259900)
addappid(259900)
addappid(259900, 1, "1f3584a28be2b5b964e2ef9e558c14276ab33e1dd40017228731e6ffcf5c65ae") -- Thief - The Bank Heist - The Bank Heist
setManifestid(259900, "805560299975892374", 271490072)
addappid(239174, 1, "89f8169b1dbd75b986c9025f9305fc84f6d14f23cef6b749c38b4fbd33af7ec4") -- Thief - The Bank Heist - Mac - Bank Heist
setManifestid(239174, "70457189102395097", 271490072)
-- Thief - Challenge Map (AppID: 265190)
addappid(265190)
addtoken(265190, "9092767304558155735")
addappid(265190, 1, "31e57bc840312fbed6fefda25441ba9ef681e6bab559efc62b28562c2ac2af7d") -- Thief - Challenge Map - Challenge Map
setManifestid(265190, "124750978867241498", 247405624)
addappid(239162, 1, "394fe149369925d85b58a03424b15dc2d35cff4de26d40bc11d8926190a26bac") -- Thief - Challenge Map - Mac - Challenge Map
setManifestid(239162, "325376681659719892", 247405624)
-- Thief OST (AppID: 1046550)
addappid(1046550)
addappid(1046550, 1, "abaf1c0568171b566e99d06ca41173b085f0f3ac41e52fcdb233fbf4f89f6a23") -- Thief OST - Thief OST (1046550) Depot
setManifestid(1046550, "694363328207955297", 66112827)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(265191) -- Thief - Opportunist
addappid(265192) -- Thief - Predator
addappid(265193) -- Thief - Ghost
addappid(279130) -- French Comic Book
addtoken(279130, "15726900120382901740")
addappid(279131) -- English Comic Book
addtoken(279131, "11997520905457021802")
addappid(279132) -- Soundtrack
addtoken(279132, "6209041936193256191")
addappid(306190) -- Thief Japanese Language Pack