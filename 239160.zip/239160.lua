-- Lua provided by RyzenAPI
-- Game: Thief

-- MAIN APPLICATION
addappid(259900)
addappid(265190)
addappid(265191) -- Thief - Opportunist
addappid(265192) -- Thief - Predator
addappid(265193) -- Thief - Ghost
addappid(279130) -- French Comic Book
addappid(279131) -- English Comic Book
addappid(279132) -- Soundtrack
addappid(306190) -- Thief Japanese Language Pack
addappid(1046550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(239160, 1, "32a1caddb0ef3e1729babaf30fb9ccc6653b74ca2aa195ad4aeb7cca256dcca0") -- Thief
addappid(239161, 1, "d0a8ff5714ffe9e46ccb7108ad525346fd83ea3df8d0f6722e00e38be96095ac") -- Game Content
addappid(239162, 1, "394fe149369925d85b58a03424b15dc2d35cff4de26d40bc11d8926190a26bac") -- Thief - Challenge Map - Mac - Challenge Map
addappid(239163, 1, "f5c3a8eb04f2cfb72afb63371ca681dcba46406327454248e48a1b59295be3b4") -- Executable
addappid(239164, 1, "fbd4018fc0378c6b684e57df6ef3ba56fa3d17c652a334122218431b538eb413") -- Debug
addappid(239165, 1, "909d01d709c11a1957591fb44a3b4e3baee47fa6876715724281e34d3d8b5e92") -- English
addappid(239166, 1, "69f5f414655421c9f8f17442685d8a3643bbf89255d79531d4ffb48a0826058e") -- French
addappid(239167, 1, "0012b705c770aaae272cc38f3ee291b5ac585ff290ba5f0d0a7bc32cc072adb6") -- German
addappid(239168, 1, "f519cf7bc744c61f1ed52a4264128374cb33c651bbf60f5389d959ce28e168a2") -- Italian
addappid(239169, 1, "69a4b3aeed0c45c4b53c4bc32ad2358bb98ec52e233e758e7dbb143aa66c6bbe") -- Japanese
addappid(239170, 1, "1ca64af4b764fd44325bfa22807c7d4a881e3e9d11e6f2312e0828ba652ea6f6") -- Russian
addappid(239171, 1, "87c85df2bea8c2c49f68663c2cee79efeda9348e6e0818960c5cf02d1369efa7") -- Spanish
addappid(239172, 1, "92b9671bc0c021314c775431a84aac44bf0d81b46737bf8117e70fcb825edd58") -- Extras
addappid(239173, 1, "47a6215790e51780f069babf23221590fc553498a67688b55e3d3e7ef89edeac") -- JapaneseText
addappid(239174, 1, "89f8169b1dbd75b986c9025f9305fc84f6d14f23cef6b749c38b4fbd33af7ec4") -- Thief - The Bank Heist - Mac - Bank Heist
addappid(239175, 1, "6c2fe6186e439269fbdfadf259cca8789ed1ff2b29a1b89952d000c86792f40d") -- Mac - Game Content
addappid(239176, 1, "47c6ec9b4a5c642fc41c64e0bebd784ab81751e5c472dbf14aead281d083f987") -- Mac - Executable
addappid(239178, 1, "6afbf2386caed21b95f88acd2bac02ccfb4ab6ffb3b0b054d7340686d5f3dba3") -- Mac - French
addappid(239179, 1, "cf55893f3e4b56f268cd45dfe18fc998007e63f9fb99f560e5e39323ae60f082") -- Mac - German
addappid(259900, 1, "1f3584a28be2b5b964e2ef9e558c14276ab33e1dd40017228731e6ffcf5c65ae") -- Thief - The Bank Heist - The Bank Heist
addappid(259901, 1, "1edc875d9a7d3d02883aaef0486c81d76b562d8fa51227a307c37f0ed3390fa1") -- Mac - Italian
addappid(259902, 1, "c2083d828053cec83179c834b0d6f136c9ea50c0da721936ddbb8881d9508997") -- Mac - Russian
addappid(259903, 1, "465886fe3d386b750351adaea9e9dff66da32a6393e8fd2ebe87ba4f42d1e43f") -- Mac - Spanish
addappid(265190, 1, "31e57bc840312fbed6fefda25441ba9ef681e6bab559efc62b28562c2ac2af7d") -- Thief - Challenge Map - Challenge Map
addappid(1046550, 1, "abaf1c0568171b566e99d06ca41173b085f0f3ac41e52fcdb233fbf4f89f6a23") -- Thief OST - Thief OST (1046550) Depot
addtoken(265190, "9092767304558155735")
addtoken(279130, "15726900120382901740")
addtoken(279131, "11997520905457021802")
addtoken(279132, "6209041936193256191")

