-- Lua provided by RyzenAPI
-- Game: Grave Prosperity - part 1

-- MAIN APPLICATION
addappid(833660)

-- MAIN APP DEPOTS / PACKAGES
addappid(833661, 1, "26b6565e0fcc755aee192b34efe0314a043b6656234f8dfd136d33c71a89fb24")
addappid(846620, 0, "d52176ac4ed305a1c300d711ec8562fb9a0180c87b159ee4aefb9309758eb906")
addappid(846621, 0, "1532bc046cbb2bcadd5c44505e7fcb1e24a6be8e2c37a6cc2784513f9a6e6285")
addappid(955970, 0, "c849b0beccbfe4f5d688fb44789d4770c14874ba4e4191cb367909822cf2638a")
addappid(1515050, 0, "a6ffb058495f721171207963dcae558a16e5b4fbe6a4edecc5692e77b8dc4c0f")
