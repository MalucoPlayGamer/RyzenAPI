-- Lua provided by RyzenAPI
-- Game: Star Girls

-- MAIN APPLICATION
addappid(842430)

-- MAIN APP DEPOTS / PACKAGES
addappid(842432,0,"dcfb71e84b090c6bdf009b3e8097404dc199c3e34d0213d00262b29f049b18eb")

