-- Lua provided by RyzenAPI
-- Game: AppID 820510

-- MAIN APPLICATION
addappid(820510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(820511, 1, "d472dcb7e3c3df000a8925af02529d3d973bc3447ecface84ee7e2bf2947a741")
addappid(820512, 1, "36a171e2d9d5790b4ef7191c11c0a3c378d6dd143cd495a2583724b813839f82")
addappid(820513, 1, "7e53734e58897b378a187ebe3ab77426415df811f1ef2d591eb248b7938facdd")

