-- Lua provided by RyzenAPI
-- Game: addappid(1558310)

-- MAIN APPLICATION
addappid(1558310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558310,0,"1d335895fb77b9c1a44a0df46bb6dcf1b4b00127a8db656d6e998460746badd1")
