-- Lua provided by RyzenAPI
-- Game: Post Trauma

-- MAIN APPLICATION
addappid(1750030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1750031, 1, "2b6598b14efb3914446eaecaad3e80306cac96bb460cc17b1ffdcc955a4baa42")

