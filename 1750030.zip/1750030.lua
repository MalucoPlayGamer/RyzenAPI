-- Lua provided by RyzenAPI
-- Game: addappid(1750030)

-- MAIN APPLICATION
addappid(1750030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750031, 1, "2b6598b14efb3914446eaecaad3e80306cac96bb460cc17b1ffdcc955a4baa42")
