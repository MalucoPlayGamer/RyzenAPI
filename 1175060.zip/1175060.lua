-- Lua provided by RyzenAPI
-- Game: 1175060

-- MAIN APPLICATION
addappid(1175060)
-- Game: addappid(1175060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175061, 1, "5c56a1d726e25f7f69f55061196e99fbfec24f7e9b76da3a3c097aa363490327")
