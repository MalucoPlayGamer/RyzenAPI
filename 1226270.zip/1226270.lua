-- Lua provided by RyzenAPI 
-- Game: Ctrl CV (Free)
addappid(1226270)
addappid(1226271, 1, "969854bccb3d16248c6fe91d2f28d9e1f944c99be646fa4876ffc236d3b15130")
