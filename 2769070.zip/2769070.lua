-- Lua provided by RyzenAPI
-- Game: Ultimate Hero

-- MAIN APPLICATION
addappid(2769070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769071, 1, "db3b1bc89e7fa02dd540b91fa670bf2c274362de407f47af1b0f7ac4c71c4f01")
