-- Lua provided by RyzenAPI
-- Game: addappid(2459310)

-- MAIN APPLICATION
addappid(2459310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459311, 1, "5e9f55ec3b2b02763db3d6314a4a186c9358cb38b12959fde8bb43a20e377ab6")
