-- Lua provided by RyzenAPI 
-- Game: ZhaoyunC
addappid(2794080)
addappid(2794081, 1, "c203f5f12a34958770cb294f19fdd01f3c05258bfd332c50a86d4c6ba0262f51")
