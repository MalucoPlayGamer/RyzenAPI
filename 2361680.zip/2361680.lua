-- Lua provided by RyzenAPI
-- Game: Path of Kung Fu

-- MAIN APPLICATION
addappid(2361680)
-- Game: addappid(2361680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361688,0,"07a52ef0c4000ac45e3da0a62c446d7b48ca61f9cc84b39b7f27b2fa3a8350ef")
