-- Lua provided by RyzenAPI
-- Game: Path of Kung Fu

-- MAIN APPLICATION
addappid(2361680)
addappid(3686660)
addappid(4967090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361680,0,"2a4b729e6af8835c4895a641bcd108277f517579fa0b96c63cd21d65ddb60f0f")
addappid(2361688,0,"07a52ef0c4000ac45e3da0a62c446d7b48ca61f9cc84b39b7f27b2fa3a8350ef")

