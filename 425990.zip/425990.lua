-- Lua provided by RyzenAPI
-- Game: addappid(425990)

-- MAIN APPLICATION
addappid(425990)

-- MAIN APP DEPOTS / PACKAGES
addappid(425991, 1, "f6dbc2d59021f0948881001742fbf91abac7ef6b65f89d6d7b06a04f9853b31d")
