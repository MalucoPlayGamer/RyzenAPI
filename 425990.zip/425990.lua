-- Lua provided by SkyAPI 
-- Game: Space Junk Patrol
addappid(425990)
addappid(425991, 1, "f6dbc2d59021f0948881001742fbf91abac7ef6b65f89d6d7b06a04f9853b31d")
