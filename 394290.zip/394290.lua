-- Lua provided by RyzenAPI
-- Game: Tennis in the Face

-- MAIN APPLICATION
addappid(394290)

-- MAIN APP DEPOTS / PACKAGES
addappid(394291, 1, "611794b13360e31f888ec829275d20d5b48c8fd69548235a3f8ff0244b4cff9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
