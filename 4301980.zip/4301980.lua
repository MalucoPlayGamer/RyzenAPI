-- Lua provided by RyzenAPI
-- Game: Created: August 10, 2026 at 09:49:30 EDT

-- MAIN APPLICATION
addappid(4301980) -- 方块 Block

-- MAIN APP DEPOTS / PACKAGES
addappid(4301981, 1, "644934eb7ec1ef0008b09a04d31317bcec9577052f26a11e8844a29bd0df1d05") -- Depot 4301981

