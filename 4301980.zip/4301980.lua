-- 4301980's Lua and Manifest Created by Hubcap Manifest
-- 方块 Block
-- Created: August 10, 2026 at 09:49:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4301980) -- 方块 Block
-- MAIN APP DEPOTS
addappid(4301981, 1, "644934eb7ec1ef0008b09a04d31317bcec9577052f26a11e8844a29bd0df1d05") -- Depot 4301981
setManifestid(4301981, "7339527595303316222", 194482745)