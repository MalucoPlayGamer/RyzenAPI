-- Lua provided by SkyAPI 
-- Game: Love Too Easily Soundtrack
addappid(2695990)
addappid(2695991, 1, "bc2a171f23b86683883772d9ff9dadebaa99bbe12bf04f9b4740974eceada60f")
