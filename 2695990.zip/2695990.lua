-- Lua provided by RyzenAPI
-- Game: Love Too Easily Soundtrack

-- MAIN APPLICATION
addappid(2695990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695991, 1, "bc2a171f23b86683883772d9ff9dadebaa99bbe12bf04f9b4740974eceada60f")
