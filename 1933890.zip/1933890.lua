-- Lua provided by RyzenAPI
-- Game: Manor of Shadows

-- MAIN APPLICATION
addappid(1933890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933891, 1, "34de4ed7f653f710bdd78fcc233fd4df21fde1e8bfb8ea6100a406d92ec91253")

