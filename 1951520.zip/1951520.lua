-- Lua provided by RyzenAPI
-- Game: Game: Romp of Dump

-- MAIN APPLICATION
addappid(1951520)
-- Game: addappid(1951520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951521, 1, "567b26fda19eaa626cfc940a8916979928617ac48db31cdb399aedb5465c1059")
addappid(1951522, 1, "bba82fbcdb312cf6803a2515692c7f57691bea2c1015ada298c168650471d767")
