-- Lua provided by RyzenAPI
-- Game: Strip Fighter 5: Chimpocon Edition

-- MAIN APPLICATION
addappid(1524470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(1524471, 1, "c4b605094dc0604b37618d56b6e210eb725c7747e40345f4f79007e00df79f01")
addappid(1524473, 1, "997333b115c07c700b4d719a50b6f0b990e5e872ead1dc11bcae6726ead0217e")
addappid(1524474, 1, "42e88f503381d204fc0b0e2ba01eb1c4fb184e2eee3ee7dfa49e63830ddddfc3")

