-- Lua provided by RyzenAPI 
-- Game: Strip Fighter 5: Chimpocon Edition
addappid(1524470)
addappid(1524471, 1, "c4b605094dc0604b37618d56b6e210eb725c7747e40345f4f79007e00df79f01")
addappid(1524473, 1, "997333b115c07c700b4d719a50b6f0b990e5e872ead1dc11bcae6726ead0217e")
addappid(1524474, 1, "42e88f503381d204fc0b0e2ba01eb1c4fb184e2eee3ee7dfa49e63830ddddfc3")
