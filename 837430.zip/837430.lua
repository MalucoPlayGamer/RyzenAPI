-- Lua provided by RyzenAPI
-- Game: 837430

-- MAIN APPLICATION
addappid(837430)
-- Game: addappid(837430)

-- MAIN APP DEPOTS / PACKAGES
addappid(837431, 1, "05a6cd054e764f787a5461c9fa11ba4dbd2a9f687bee6c467697592532c6f4e8")
