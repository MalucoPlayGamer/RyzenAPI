-- Lua provided by RyzenAPI
-- Game: 2141200

-- MAIN APPLICATION
addappid(2141200)
-- Game: addappid(2141200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141200,0,"f71ffe76f304fa190f4833f98fe81c313c4580a681d4c5c442d262fd5f8852cf")
