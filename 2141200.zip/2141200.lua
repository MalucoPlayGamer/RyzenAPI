-- Lua provided by RyzenAPI
-- Game: College Kings 2 - Episode 2 "The Pool Party" Deluxe Upgrade

-- MAIN APPLICATION
addappid(2141200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141200,0,"f71ffe76f304fa190f4833f98fe81c313c4580a681d4c5c442d262fd5f8852cf")

