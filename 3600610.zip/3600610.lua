-- Lua provided by RyzenAPI
-- Game: Together with Oneesan~Yuina's Sweet Encouragement~ DLC

-- MAIN APPLICATION
addappid(3600610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600613,0,"0cfa1da6e24b2c3052858aa76cd81ecfb43d99425483a1ac656bb78e863bf1b6")
addappid(3600614,0,"395d004a3731b2fdbad2ddcc8c729bf89f242363227f9754f7c5053854712220")

