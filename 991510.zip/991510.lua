-- Lua provided by RyzenAPI
-- Game: Epic Food Fight

-- MAIN APPLICATION
addappid(991510)
-- Game: addappid(991510)

-- MAIN APP DEPOTS / PACKAGES
addappid(991511, 1, "827424167231461402e3bafc042fc38d6ca91651febd49bc40940182ffc62484")
