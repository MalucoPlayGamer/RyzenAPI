-- Lua provided by RyzenAPI
-- Game: addappid(2056830)

-- MAIN APPLICATION
addappid(2056830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056831, 1, "3a60b40c6c768a7c925eddb32fb5ce570f4ff933c5b54a3cacd7a3eb947bca6b")
