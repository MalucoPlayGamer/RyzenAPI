-- Lua provided by RyzenAPI
-- Game: Capcom Fighting Collection 2

-- MAIN APPLICATION
addappid(2400430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2400431, 1, "083a6c5306f29b4ff5f381758c386891bb87d1ecdbba64ada7cf0dfe44132e65")
addappid(3052240, 0, "f5aca40f3726c287a4404658814fadf3c0ae4630d850f7e1801ff688369c83fc")

