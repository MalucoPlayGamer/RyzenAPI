-- Lua provided by RyzenAPI
-- Game: Capcom Fighting Collection 2

-- MAIN APPLICATION
addappid(2400430)
-- Game: addappid(2400430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400431, 1, "083a6c5306f29b4ff5f381758c386891bb87d1ecdbba64ada7cf0dfe44132e65")
addappid(3052240, 0, "f5aca40f3726c287a4404658814fadf3c0ae4630d850f7e1801ff688369c83fc")
