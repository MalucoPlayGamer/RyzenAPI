-- Lua provided by RyzenAPI
-- Game: Civil War: Gettysburg

-- MAIN APPLICATION
addappid(665440)

-- MAIN APP DEPOTS / PACKAGES
addappid(665441, 1, "f8705bc82bb5730b534c9a8df42a37726a20a36c7f549bd8adaf6200304cfd26")
addappid(665442, 1, "b3b7dc093093d07fec04f7f0316a6e47c39f27e60a8a9dca2c3eba517500d002")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
