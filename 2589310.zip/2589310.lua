-- Lua provided by RyzenAPI
-- Game: Hollow Survivors Demo

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2589310)
addappid(2589311)
addappid(2589313)
addappid(2589314)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589312,0,"cc9e9e77de4a5cf31714a258cc5d8cb82c6acbfe21adbe8a213473834faae409")

