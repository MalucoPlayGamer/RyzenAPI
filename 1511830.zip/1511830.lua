-- Lua provided by RyzenAPI
-- Game: addappid(1511830)

-- MAIN APPLICATION
addappid(1511830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511831, 1, "41179f327983f1a83dc2ba785b174a81aec810ec2e9029426c9862ea26a3c5b0")
