-- Lua provided by SkyAPI 
-- Game: Hit Zero: Chronos
addappid(1292880)
addappid(1292881, 1, "6785ed21f377177fc8e76e436065c47bd3bcd8453d8d8f63c3f4b1d1452ebeaf")
addappid(1292882, 1, "aaf1eb643fda940ec799535b23d75e9a82b3e3cf6d70cc495bf9263e1c9bf6fe")
addappid(1292883, 1, "7c41d4a7a85e8bf1a1452cadfec02db10c666a5a3d0f670f337552cc030001eb")
