-- Lua provided by RyzenAPI
-- Game: The OmniGallery

-- MAIN APPLICATION
addappid(1587200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587201, 1, "e411d996a8c12f45034c75c4c1e7d66775dcd26f80b2d3286e744902c3451eb2")

