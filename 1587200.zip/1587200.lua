-- Lua provided by RyzenAPI
-- Game: The OmniGallery

-- MAIN APPLICATION
addappid(1587200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1587201, 1, "e411d996a8c12f45034c75c4c1e7d66775dcd26f80b2d3286e744902c3451eb2")

