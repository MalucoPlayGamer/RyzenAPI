-- Lua provided by RyzenAPI
-- Game: Kinoko

-- MAIN APPLICATION
addappid(1059120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1059121, 1, "0fd8e3bae4ace5396daca99b81bc200cbb730662a311769037d4d781bc7a2daa")

