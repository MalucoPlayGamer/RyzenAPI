-- Lua provided by RyzenAPI
-- Game: 1059120

-- MAIN APPLICATION
addappid(1059120)
-- Game: addappid(1059120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059121, 1, "0fd8e3bae4ace5396daca99b81bc200cbb730662a311769037d4d781bc7a2daa")
