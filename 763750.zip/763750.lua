-- Lua provided by RyzenAPI
-- Game: Minaurs

-- MAIN APPLICATION
addappid(763750)

-- MAIN APP DEPOTS / PACKAGES
addappid(763751, 1, "50f582493e436effff24cac6de94ace029c9dc4c31d663b05579b58458bf6bb5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
