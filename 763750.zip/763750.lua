-- Lua provided by RyzenAPI
-- Game: Game: Minaurs

-- MAIN APPLICATION
addappid(763750)
-- Game: addappid(763750)

-- MAIN APP DEPOTS / PACKAGES
addappid(763751, 1, "50f582493e436effff24cac6de94ace029c9dc4c31d663b05579b58458bf6bb5")
