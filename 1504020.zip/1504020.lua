-- Lua provided by RyzenAPI 
-- Game: Mosaique Neko Waifus 4
addappid(1504020)
addappid(1504021, 1, "09f7e7d47491c82363b08f9ab5ecdc6e279d4ee5c273c9facfe465c35353e8c7")
addappid(1504022, 1, "0a70bb433bdaff9656ffb6c44da52f764479fe7dea86270440bed533ac2975e4")
addappid(1504023, 1, "c7ffe6d75e335a3c936574f5b3223e3b4e99a9a8ebea03aa29a13dbe7600eafd")
addappid(1542500, 0, "b2a58dbbea725a77d894c1f3d8a552f45cba08245cb200407ea38dfae204d579")
addappid(1542501, 0, "316a8f4aa1e773d23676ca1a323faf044dde7d98f7c5bb47832318714f254cb5")
