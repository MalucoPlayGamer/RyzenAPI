-- Lua provided by RyzenAPI
-- Game: 2430380

-- MAIN APPLICATION
addappid(2430380)
-- Game: addappid(2430380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430381, 1, "9dd002809ad9d10bf48b8d246287d118e048ae7279efa0b6bd24e1ee2d1fa997")
