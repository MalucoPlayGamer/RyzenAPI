-- Lua provided by RyzenAPI
-- Game: addappid(1118350)

-- MAIN APPLICATION
addappid(1118350)
addappid(1141310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118351, 1, "a438d075b4d6b8893e187c3b2a3b263d6b0c98e786d136694b17dd1127158b4b")
