-- Lua provided by RyzenAPI
-- Game: Meegah Mem 2

-- MAIN APPLICATION
addappid(1118350)
addappid(1141310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118351, 1, "a438d075b4d6b8893e187c3b2a3b263d6b0c98e786d136694b17dd1127158b4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
