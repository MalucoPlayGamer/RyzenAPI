-- Lua provided by RyzenAPI
-- Game: SCP-087-B UE Remake

-- MAIN APPLICATION
addappid(2676580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676581, 1, "a7b801ac06e70f1da7bfac0e27f3efac7e01bb304bc1a0493248f0645e7219a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
