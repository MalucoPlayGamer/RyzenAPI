-- Lua provided by RyzenAPI
-- Game: SCP-087-B UE Remake

-- MAIN APPLICATION
addappid(2676580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676581, 1, "a7b801ac06e70f1da7bfac0e27f3efac7e01bb304bc1a0493248f0645e7219a4")
