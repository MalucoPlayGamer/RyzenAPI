-- Lua provided by SkyAPI 
-- Game: Hitmen Havoc
addappid(2137300)
addappid(2137301, 1, "93be67b6b32e6cf15370f287e8527dc2c52d8b9f9e29dc78cb8c8e2357d21053")
