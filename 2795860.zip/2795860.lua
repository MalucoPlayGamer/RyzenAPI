-- Lua provided by RyzenAPI
-- Game: Looking For Cats In a Badly Drawn Forest

-- MAIN APPLICATION
addappid(2795860)
