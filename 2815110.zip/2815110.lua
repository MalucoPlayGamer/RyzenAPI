-- Lua provided by RyzenAPI
-- Game: addappid(2815110)

-- MAIN APPLICATION
addappid(2815110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815111, 1, "905c434f80eabb26df43d1c4c50cf8a719fd1998730dba08cf80f7974bcdb85a")
