-- Lua provided by SkyAPI 
-- Game: Fight For It
addappid(1987810)
addappid(1987811, 1, "32fbfa28684a9bc112987fd9b2a19955d690b884a7cb5ca381cb04779d0c3ef3")
