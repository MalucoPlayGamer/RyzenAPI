-- Lua provided by RyzenAPI
-- Game: 1987810

-- MAIN APPLICATION
addappid(1987810)
-- Game: addappid(1987810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987811, 1, "32fbfa28684a9bc112987fd9b2a19955d690b884a7cb5ca381cb04779d0c3ef3")
