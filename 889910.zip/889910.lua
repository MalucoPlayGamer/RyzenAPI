-- Lua provided by RyzenAPI 
-- Game: AppID 889910
addappid(889910)
addappid(889911, 1, "8e33ed3129020d1836457f9ecc5c9dbfc734422a01976147c92955549be6026a")
