-- Lua provided by RyzenAPI
-- Game: Game: AppID 889910

-- MAIN APPLICATION
addappid(889910)
-- Game: addappid(889910)

-- MAIN APP DEPOTS / PACKAGES
addappid(889911, 1, "8e33ed3129020d1836457f9ecc5c9dbfc734422a01976147c92955549be6026a")
