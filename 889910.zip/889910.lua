-- Lua provided by RyzenAPI
-- Game: Hell Pie

-- MAIN APPLICATION
addappid(889910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(889911, 1, "8e33ed3129020d1836457f9ecc5c9dbfc734422a01976147c92955549be6026a")
