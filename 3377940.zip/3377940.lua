-- Lua provided by SkyAPI 
-- Game: You reincarnated into the game world and fucked the NPCs!-Animation-
addappid(3377940)
addappid(3377941, 1, "06877a792507572e245eacfb70650eb1b28f91386958c94fe3bfe49d9929bacf")
