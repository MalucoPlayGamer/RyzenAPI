-- Lua provided by RyzenAPI
-- Game: You reincarnated into the game world and fucked the NPCs!-Animation-

-- MAIN APPLICATION
addappid(3377940)
-- Game: addappid(3377940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3377941, 1, "06877a792507572e245eacfb70650eb1b28f91386958c94fe3bfe49d9929bacf")
