-- Lua provided by RyzenAPI
-- Game: Game: White Dove 白雀

-- MAIN APPLICATION
addappid(953570)
-- Game: addappid(953570)

-- MAIN APP DEPOTS / PACKAGES
addappid(953571, 1, "b0aa93a98a5dfc431d7f6ff00b0b0aa1f07cdaf426d2af17707da5e8393b7342")
