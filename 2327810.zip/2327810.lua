-- Lua provided by RyzenAPI
-- Game: Game: Girls Love Toys

-- MAIN APPLICATION
addappid(2327810)
-- Game: addappid(2327810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327811, 1, "2bdfc738b4b6c1a9a14436b895f476fa5454ff739993cb5ea5be474b902b680d")
