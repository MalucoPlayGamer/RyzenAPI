-- Lua provided by RyzenAPI
-- Game: Tomb Raider IV-VI Remastered

-- MAIN APPLICATION
addappid(2525380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525381, 1, "8349c35cc7c661ae125165df281e9fb6f1eb7b22d82ecb59a948fcef1a70a01c")

