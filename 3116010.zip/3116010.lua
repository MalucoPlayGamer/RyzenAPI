-- 3116010's Lua and Manifest Created by Hubcap Manifest
-- Twitch Integrated Throwing System
-- Created: August 25, 2026 at 19:46:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3116010) -- Twitch Integrated Throwing System
-- MAIN APP DEPOTS
addappid(3116011, 1, "cb28a600ddfa6f365f8cb1bedd54e54a37e10185462f8beb22b010b881baaac5") -- Depot 3116011
setManifestid(3116011, "2207775631253629969", 155305309)