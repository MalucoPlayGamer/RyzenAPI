-- Lua provided by RyzenAPI
-- Game: Twitch Integrated Throwing System

-- MAIN APPLICATION
addappid(3116010) -- Twitch Integrated Throwing System

-- MAIN APP DEPOTS / PACKAGES
addappid(3116011, 1, "cb28a600ddfa6f365f8cb1bedd54e54a37e10185462f8beb22b010b881baaac5") -- Depot 3116011

