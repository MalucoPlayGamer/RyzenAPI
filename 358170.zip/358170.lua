-- Lua provided by RyzenAPI
-- Game: Arctic Adventure

-- MAIN APPLICATION
addappid(358170)
addappid(358282)

-- MAIN APP DEPOTS / PACKAGES
addappid(358171, 1, "22c2cadd30a53a729bc6626c368bfe857d6007b5dacd696538cf77afba28b3f7")

