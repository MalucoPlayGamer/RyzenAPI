-- 4525690's Lua and Manifest Created by Hubcap Manifest
-- Tessera
-- Created: August 11, 2026 at 00:21:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4525690) -- Tessera
-- MAIN APP DEPOTS
addappid(4525691, 1, "11d74ebcd62886f3a7afb1dc1971baf63f716b0bd860ac592cd60729e10d5f8f") -- Depot 4525691
setManifestid(4525691, "1389300394502308062", 508832880)