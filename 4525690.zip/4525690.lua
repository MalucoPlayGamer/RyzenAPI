-- Lua provided by RyzenAPI
-- Game: Tessera

-- MAIN APPLICATION
addappid(4525690) -- Tessera

-- MAIN APP DEPOTS / PACKAGES
addappid(4525691, 1, "11d74ebcd62886f3a7afb1dc1971baf63f716b0bd860ac592cd60729e10d5f8f") -- Depot 4525691

