-- Lua provided by RyzenAPI
-- Game: I'm the Policeman

-- MAIN APPLICATION
addappid(2715630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715631, 1, "e0b9f7221d6f6084cc2e35d2510a9f2b33949aa381568e27086b8957cc2b2159")

