-- Lua provided by RyzenAPI
-- Game: Cube Shifter

-- MAIN APPLICATION
addappid(1372010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372011, 1, "228c242fbbbc3f070b266b7fe7221d03c4385325efc976258853b891a3fd2152")
