-- Lua provided by RyzenAPI
-- Game: Gopnik Simulator - Soundtrack

-- MAIN APPLICATION
addappid(863410)

-- MAIN APP DEPOTS / PACKAGES
addappid(863410,0,"70fa67f50d54320905f075a16bd4560f45a127ac4c8024561eb8433a00a72ac8")
