-- Lua provided by RyzenAPI 
-- Game: Neko Girls
addappid(2114670)
addappid(2114671, 1, "73f15565578f81be732ff710033f7aeb51d3a80cd60e8eb9e9f7af2b1156ec4c")
