-- Lua provided by RyzenAPI
-- Game: Game: AppID 1123770

-- MAIN APPLICATION
addappid(1123770)
-- Game: addappid(1123770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123771, 1, "1a98ebf1f0691fe81c354b0a0d89224f4652aa3696853b7040d5492e272bb48a")
