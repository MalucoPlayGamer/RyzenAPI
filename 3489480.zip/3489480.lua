-- Lua provided by RyzenAPI
-- Game: Hentai Phoebe

-- MAIN APPLICATION
addappid(3489480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489481, 1, "ddd7400836a5ef2ac4285df29d1c15a22d68d3468434b79a551e51d248a4efaa")

