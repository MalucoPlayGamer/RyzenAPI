-- Lua provided by RyzenAPI
-- Game: Heroes Rise: The Prodigy

-- MAIN APPLICATION
addappid(299540)
addappid(305200)

-- MAIN APP DEPOTS / PACKAGES
addappid(299541, 1, "a80f2d9fd887cd8811b080636646b8ccf151ff0aab74060037eb81fe6e96d3e2")

