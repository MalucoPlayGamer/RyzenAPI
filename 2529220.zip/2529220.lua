-- Lua provided by RyzenAPI
-- Game: Anarchy Park

-- MAIN APPLICATION
addappid(2529220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2529221, 1, "0b2321591f2195cae6fc30b54e72b4cf51be14f2fcddeca747fff44b0c364874")

