-- Lua provided by RyzenAPI
-- Game: addappid(2529220)

-- MAIN APPLICATION
addappid(2529220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529221, 1, "0b2321591f2195cae6fc30b54e72b4cf51be14f2fcddeca747fff44b0c364874")
