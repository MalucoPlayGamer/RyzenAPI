-- Lua provided by RyzenAPI
-- Game: Towaga: Among Shadows

-- MAIN APPLICATION
addappid(907600)

-- MAIN APP DEPOTS / PACKAGES
addappid(907601, 1, "d3d8301b9606d1db09a2be5c357f9abb120a44e6b232f1a3791f6c699fac67c4")

