-- Lua provided by RyzenAPI
-- Game: Game: Back from the other world, I missed love.

-- MAIN APPLICATION
addappid(2998600)
-- Game: addappid(2998600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998601, 1, "c7476c7ce2f864843409c407b3eb1442e85227db356042d2fb903915e4acbc1d")
