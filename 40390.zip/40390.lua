-- Lua provided by RyzenAPI
-- Game: Game: Risen 2: Dark Waters

-- MAIN APPLICATION
addappid(40390)
-- Game: addappid(40390)

-- MAIN APP DEPOTS / PACKAGES
addappid(40391, 1, "b50c7549da36c30b89c20288cb632542e3c3a9eae52ebe47b08b8ad1b397cc57")
addappid(40392, 1, "92eded7a673cca6665d85bbc923b3526eb94bdf2ee9c930e278954cd04fa4457")
addappid(40393, 1, "45a08d419deb2a6c1bf7e4ee1d667551fce553e14cc5a962083ab25e638e4cc6")
addappid(40394, 1, "4ca485594d39126346c71c5c4c0d62ae8484e0f734d8741ebf7e3cae7d3f2bfb")
addappid(40395, 1, "f60cf479ceea1e27f519b2d57c2fb8a76f2f1a29a0e97acf60c6f53104fc418c")
addappid(40396, 1, "6b8b13e802cc4dd6175b4251133d9cec25cb6853b54c01b1c71e6844980c5d2f")
addappid(40397, 1, "29fa1153e6c31c51a6813aeccc872ea255a3b0c9a13f3c821f3ca0fe67118cc3")
addappid(40398, 1, "dddc1af30cf7c55a354c1e2c4779cbaaeb129af2c0065ad8cea35d6375b93952")
addappid(40399, 1, "af8f876dc1ccaa101ae53e8eb6146763e2c66e4e1cd184a62c3cc56e554c7335")
addappid(203230, 0, "9bcaf3668e90e2a083d1cc0e731ca657b61eff6bf12a41dfc106be47803dc097")
addappid(203231, 0, "7dd87bfee04f542048dfef5136e08b089a08238fadda7ecb7e17e86f7f78a0f0")
addappid(203232, 0, "7a2b788f6465eb5e389c43a43ea7027b7444e44cd2e340cabaf4adabcff47317")
addappid(203233, 0, "bf25d1c920ce5185324cd42d6de7e20ffff913d90aeea1b6cffbfcef02265924")
