-- Lua provided by RyzenAPI
-- Game: Zombie Arena

-- MAIN APPLICATION
addappid(2151820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151821, 1, "cb9c2684b6384e540361f3ee5d97a4e0072bf2156004b67019c66d15c0dc6277")

