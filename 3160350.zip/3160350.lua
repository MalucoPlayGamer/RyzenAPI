-- Lua provided by RyzenAPI
-- Game: 芙兰杂感记录 Demo

-- MAIN APPLICATION
addappid(3160350)
-- Game: addappid(3160350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160351, 1, "6bd6233fef82372605bbf1acf1f46d5573a9dc293cb17a463c04459bdf3a9e52")
