-- Lua provided by RyzenAPI
-- Game: Alien invasion

-- MAIN APPLICATION
addappid(1087040)
-- Game: addappid(1087040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087041, 1, "b9d8629657e69fd10b27d98a824913ef8a44e3ffef90baa3e02cd7470e71f9e9")
