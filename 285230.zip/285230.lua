-- Lua provided by RyzenAPI
-- Game: Mnemonic Prototype

-- MAIN APPLICATION
addappid(285230)

-- MAIN APP DEPOTS / PACKAGES
addappid(285231, 1, "832d6ea54a9c28e950e66e8d277c8a95d7c43cfbd1cc93302f7e6bbacb04e106")
addappid(285232, 1, "93f1092125ddeb564cb95a4384558d8521cc4f85ad5930686349549e799d82ee")

