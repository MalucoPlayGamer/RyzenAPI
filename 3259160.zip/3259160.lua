-- Lua provided by RyzenAPI 
-- Game: FREE DUROV - DEMO
addappid(3259160)
addappid(3259161, 1, "f0860a34ee23e6e6790d82a373163a784e5f2ab009d1e81804ab7e816b737659")
