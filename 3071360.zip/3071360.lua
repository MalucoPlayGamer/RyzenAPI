-- Lua provided by SkyAPI 
-- Game: AppID 3071360
addappid(3071360)
addappid(3071361, 1, "7e5c985249e2318f2038b14dc3da0e2bd240cb436f482d6e82401be6a0be3a6a")
