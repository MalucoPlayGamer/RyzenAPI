-- Lua provided by RyzenAPI
-- Game: addappid(3071360)

-- MAIN APPLICATION
addappid(3071360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071361, 1, "7e5c985249e2318f2038b14dc3da0e2bd240cb436f482d6e82401be6a0be3a6a")
