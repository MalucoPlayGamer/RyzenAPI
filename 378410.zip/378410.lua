-- Lua provided by RyzenAPI
-- Game: Patchman vs. Red Circles

-- MAIN APPLICATION
addappid(378410)

-- MAIN APP DEPOTS / PACKAGES
addappid(378414,0,"c21628fb0e66562e69111d4cdd35cf6e29b9d15d610f507c3b4bf33dc95b2725")

