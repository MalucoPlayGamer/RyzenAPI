-- Lua provided by RyzenAPI 
-- Game: AppID 2027920
addappid(2027920)
addappid(2027921, 1, "07c4eafee71d2e6f671b8470c5c4bff933bae57253d33cc6de7c8d0fca390c86")
