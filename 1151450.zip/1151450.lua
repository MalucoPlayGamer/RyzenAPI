-- Lua provided by RyzenAPI
-- Game: Game: Utawarerumono: Prelude to the Fallen

-- MAIN APPLICATION
addappid(1151450)
addappid(1186230)
addappid(1186231)
addappid(1186232)
addappid(1186233)
addappid(1186234)
addappid(1186235)
addappid(1186236)
addappid(1186237)
addappid(1186238)
addappid(1186239)
addappid(1186240)
addappid(1186241)
addappid(1186242)
addappid(1186243)
addappid(1186244)
addappid(1186245)
-- Game: addappid(1151450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151451, 1, "21b0fd809c98f211e669fc3bc51088b92c07bb5015927f80a64ff63b7893b9f8")
addappid(1151452, 1, "6afb44ff3655a31a8ffc1e1403824e2b3020ef4725df273c976f6ae838570300")
addappid(1151453, 1, "17c90e12aa48288bba8f095a320ce73f6a08d85b8a7135d9383db3eb27adf15a")
addappid(1151454, 1, "6224c45aad76ee9473eb24c8addf37c204770cd8eeaf02d2bbbd9c96a7bf801e")
