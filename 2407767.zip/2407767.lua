-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2407767)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407767,0,"b15549622067b27bb3c2d990e7512a0ab9f7712ee302e040ee886324c7aee263")
