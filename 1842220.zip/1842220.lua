-- Lua provided by RyzenAPI
-- Game: 3D  Lover

-- MAIN APPLICATION
addappid(1842220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842221, 1, "80f12108b41925c6b4e4a84264e0baf1f162c06d2f1915a0679b24c88a0687cd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2082550)
addappid(2383070)
addappid(2413540)
addappid(2413550)
addappid(2413560)
addappid(2456790)
addappid(2456800)
addappid(2456810)
addappid(2501800)
addappid(2501810)
addappid(2501870)
addappid(2501900)
addappid(2501940)
addappid(2501950)
addappid(2501960)
addappid(2501970)
addappid(2502250)
addappid(2502270)
addappid(2502280)
addappid(2502290)
addappid(2502300)
addappid(2502320)
addappid(2502330)
addappid(2502340)
addappid(2502530)
addappid(2502540)
addappid(2505680)
