-- Lua provided by RyzenAPI
-- Game: 3D  Lover

-- MAIN APPLICATION
addappid(1842220)
-- Game: addappid(1842220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842221, 1, "80f12108b41925c6b4e4a84264e0baf1f162c06d2f1915a0679b24c88a0687cd")
