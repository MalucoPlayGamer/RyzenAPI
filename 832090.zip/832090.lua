-- Lua provided by RyzenAPI
-- Game: 832090

-- MAIN APPLICATION
addappid(832090)
-- Game: addappid(832090)

-- MAIN APP DEPOTS / PACKAGES
addappid(832092,0,"a57c5d8a1bd85e878e426e9683bbf34f56917e31743cb8977b36e1faa6d644eb")
