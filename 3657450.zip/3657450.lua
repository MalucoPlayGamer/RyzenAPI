-- Lua provided by RyzenAPI
-- Game: Gorilla Vs 100 Men

-- MAIN APPLICATION
addappid(3657450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3657452,0,"b2e80d33ce5907571980cfb911527bdbe7b72636fc28c365d0489f455e65cadd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
