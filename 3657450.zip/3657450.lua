-- Lua provided by RyzenAPI
-- Game: Gorilla Vs 100 Men

-- MAIN APPLICATION
addappid(3657450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3657452,0,"b2e80d33ce5907571980cfb911527bdbe7b72636fc28c365d0489f455e65cadd")
