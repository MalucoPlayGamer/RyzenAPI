-- Lua provided by RyzenAPI
-- Game: Game: AppID 939870

-- MAIN APPLICATION
addappid(939870)
-- Game: addappid(939870)

-- MAIN APP DEPOTS / PACKAGES
addappid(939871, 1, "35cd2b360e7e12e530be18ef4e7c3097f5f28ce10669524557d6f892ecb147dd")
