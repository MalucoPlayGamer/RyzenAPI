-- Lua provided by RyzenAPI 
-- Game: I Wanna Fuck my Mom's Best Friend
addappid(3067200)
addappid(3067201, 1, "af1b4380c9259b939315c7c6b35333788108a0385c930dd9451cf64f907ef6d0")
addappid(3067202, 1, "9d9d99c46a76fb7045365947b000afb68239957b417a1e6ddd0bbdc5a6e7c1a5")
