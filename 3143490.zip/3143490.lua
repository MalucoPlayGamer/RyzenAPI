-- Lua provided by RyzenAPI
-- Game: My Sleeper

-- MAIN APPLICATION
addappid(3143490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143490,0,"65d73db33255699ea282d0844d0ef88792a349c1e8cef34015ffccae9f7207f0")
addappid(3143492,0,"14f06e6543de2e2bf9eae0ec8b0794f92808e54f5f353f26dabad66d9e8e9fcb")

