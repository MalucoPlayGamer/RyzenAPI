-- Lua provided by RyzenAPI 
-- Game: AppID 3148850
addappid(3148850)
addappid(3148851, 1, "5e9ac1329965b5aa0d03e6fe3856ac28ba3ff880070ae9cb7d7df622c90dc030")
