-- Lua provided by SkyAPI 
-- Game: AppID 1529910
addappid(1529910)
addappid(1529911, 1, "6efb06f80b1be21718b4ff28b23c360f773b9e7e41a99383ee22f09fb78eadc5")
