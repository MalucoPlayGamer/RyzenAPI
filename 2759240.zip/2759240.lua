-- Lua provided by SkyAPI 
-- Game: Rubber Hose Rampage
addappid(2759240)
addappid(2759241, 1, "9b21261d7ce9efb626ab9e108f36e8bb14590da9787181049296ba4c419c57b6")
