-- Lua provided by RyzenAPI
-- Game: Rubber Hose Rampage

-- MAIN APPLICATION
addappid(2759240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759241, 1, "9b21261d7ce9efb626ab9e108f36e8bb14590da9787181049296ba4c419c57b6")
