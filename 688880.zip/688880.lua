-- Lua provided by RyzenAPI
-- Game: Cynoclept: The Game

-- MAIN APPLICATION
addappid(688880)
-- Game: addappid(688880)

-- MAIN APP DEPOTS / PACKAGES
addappid(688881, 1, "19b39a21bf4b7a5fb36354db84797e46562c65953c1769f0e888a486fedbff20")
