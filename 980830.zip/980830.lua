-- Lua provided by RyzenAPI
-- Game: Spirit Hunter: Death Mark

-- MAIN APPLICATION
addappid(980830)
-- Game: addappid(980830)

-- MAIN APP DEPOTS / PACKAGES
addappid(980831, 1, "86625c4735320c1478399358707da1bff3588efb53e8c75de2c4433e27b105fd")
