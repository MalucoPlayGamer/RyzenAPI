-- Lua provided by RyzenAPI
-- Game: Grisaia Chronos Rebellion

-- MAIN APPLICATION
addappid(2348360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2348361, 1, "bf4b12207bc8773c920abe49c2b1d2ac0ee53dcf02e6a72deb7981d80517164d")

