-- Lua provided by RyzenAPI
-- Game: Super Weapon Master 超级武器大师

-- MAIN APPLICATION
addappid(2106170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106171, 1, "7258ba1f3639e0e11bbd950a8c61651c1b77ebcb1c423c003bb7024535f8cb46")

