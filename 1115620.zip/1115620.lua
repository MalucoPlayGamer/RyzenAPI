-- Lua provided by RyzenAPI
-- Game: Super Pig

-- MAIN APPLICATION
addappid(1115620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115621, 1, "512892100fe62b5f131a5dcf31389247ff14fd3b50f1587939ad0ed78066d2e6")

