-- Lua provided by RyzenAPI
-- Game: 1543430

-- MAIN APPLICATION
addappid(1543430)
-- Game: addappid(1543430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543431, 1, "1c90df9853f457ada556bc79de4726622dccc83cde48c0c113a3c0dc82318bc3")
