-- Lua provided by RyzenAPI
-- Game: addappid(2533170)

-- MAIN APPLICATION
addappid(2533170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533171, 1, "f8887e650c4ad9dc9c1c50f64a0a10cef1453405f01d158f9dc2376870f23ab3")
