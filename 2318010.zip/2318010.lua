-- Lua provided by RyzenAPI
-- Game: addappid(2318010)

-- MAIN APPLICATION
addappid(2318010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318010,0,"cf1dd9e47013bf7b05eb3d638a59a651e3f8e54fef1e837c94bc550a43a9e08f")
