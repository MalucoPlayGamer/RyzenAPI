-- Lua provided by RyzenAPI
-- Game: addappid(1509210)

-- MAIN APPLICATION
addappid(1509210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509211, 1, "be7c0e494f9c3ebe170b71baa6edb6d4569193b52a759aec222212fc0fc99c7f")
