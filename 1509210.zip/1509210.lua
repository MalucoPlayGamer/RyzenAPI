-- Lua provided by RyzenAPI 
-- Game: AppID 1509210
addappid(1509210)
addappid(1509211, 1, "be7c0e494f9c3ebe170b71baa6edb6d4569193b52a759aec222212fc0fc99c7f")
