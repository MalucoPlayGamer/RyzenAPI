-- Lua provided by RyzenAPI
-- Game: Source SDK Base 2013 Dedicated Server

-- MAIN APPLICATION
addappid(244310)

-- MAIN APP DEPOTS / PACKAGES
addappid(244311, 1, "3359f3b9ff799870224f4de9d450e3408dfc86f1df649ae48b585872bb21c54e")
addappid(244312, 1, "39600e9c43b00ca2ecd1b7af7bac608ffc96f2732c10f3b55519fb596b26d797")
addappid(244313, 1, "f1e984fc7af68657868d7a7216d41041d2e78794c2191c408a9cbffa861def92")

