-- Lua provided by RyzenAPI
-- Game: 修仙：但系统让我种田

-- MAIN APPLICATION
addappid(3060630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060632,0,"18866e1f46a0203087f2f9d7841a1246cd4d918b127c6e8b1cd8803da6a9341f")

