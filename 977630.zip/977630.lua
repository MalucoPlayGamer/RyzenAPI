-- Lua provided by RyzenAPI
-- Game: addappid(977630)

-- MAIN APPLICATION
addappid(977630)

-- MAIN APP DEPOTS / PACKAGES
addappid(977631, 1, "1876808ab99e5500bf41c6aac375689cc7ee16e170d55f807ea0b5e10947c56c")
