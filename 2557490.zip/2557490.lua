-- Lua provided by RyzenAPI
-- Game: Dirt Bike Racer Simulator

-- MAIN APPLICATION
addappid(2557490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557491, 1, "1d8beb8cfee99f516a3c24d36efd921d9ad6d43c63f13d95bb6af77ea248b53e")
