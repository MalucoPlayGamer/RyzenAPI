-- Lua provided by RyzenAPI
-- Game: Uncanny Valley: Machine

-- MAIN APPLICATION
addappid(2796140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796142,0,"90dc470fed0345fe4e9b7e5296438ad8248b5c0378afdf0592a04211f8091ec0")
addappid(2796144,0,"faadf5cae138af8c77580918b904ce78ad8ecfbbdcf7ee2c0d14e8ccaf9e5199")
