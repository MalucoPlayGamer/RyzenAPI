-- Lua provided by RyzenAPI
-- Game: addappid(848680)

-- MAIN APPLICATION
addappid(848680)

-- MAIN APP DEPOTS / PACKAGES
addappid(848681, 1, "99879a374bd0c912a711d8f88198ea27aa6f36626a0bc06ba532bb20cd41c825")
