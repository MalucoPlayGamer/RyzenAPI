-- Lua provided by RyzenAPI
-- Game: 2724550

-- MAIN APPLICATION
addappid(2724550)
-- Game: addappid(2724550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724551, 1, "c01301bfd9400d2cfb08c500f9177504f6568dce3e02e217a96a272dcb583d4e")
