-- Lua provided by RyzenAPI
-- Game: 榜一大哥幻想曲

-- MAIN APPLICATION
addappid(2724550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2724551, 1, "c01301bfd9400d2cfb08c500f9177504f6568dce3e02e217a96a272dcb583d4e")

