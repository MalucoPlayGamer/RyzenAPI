-- Lua provided by RyzenAPI
-- Game: 1321220

-- MAIN APPLICATION
addappid(1321220)
-- Game: addappid(1321220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321221, 1, "f296fa222af88698f4a9c015eea68d394cf6fe9460abf06805ba37795155cab2")
