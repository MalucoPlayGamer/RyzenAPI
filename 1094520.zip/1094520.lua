-- Lua provided by RyzenAPI
-- Game: Sands of Salzaar

-- MAIN APPLICATION
addappid(1094520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094521, 1, "cb7d27fa034dd4ca3605268b595f4be39ad9bfca4507c09a112e598482063f5b")
addappid(1094522, 1, "51344cc830b25b1b671640bcfd6be378933afe01c3318e7df0662cdc4eb95eba")
addappid(1094523, 1, "62afdba92a585f465ac07375ed353517412db0ba7aae759283c77ceee002a76d")
addappid(1849490, 0, "c9644e8918992c3dd8b84aa2dd014154c4c9353c1d389b8478d88bd9d22378d2")
addappid(2265790, 0, "12d63cab832963e1211f7837814726347f2f331498d180fbc3af0ce0b1c5b847")
addappid(2406290, 0, "108a134d52eb41f70f319ad7af628a29907b5f71c0f16f8436f52e210a9a1070")
addappid(2621910, 0, "e232b362aa8b79ad21592a6ce15282ce0ef5994974a0ee875b52c1f2b1c86310")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
