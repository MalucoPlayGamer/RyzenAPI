-- Lua provided by RyzenAPI
-- Game: Game: Visite virtuelle de l'Assemblée nationale

-- MAIN APPLICATION
addappid(1753400)
-- Game: addappid(1753400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753401, 1, "866d8258c64b309d48e59bad4b049c3fa72fc222d4ca6f7b0aebd6b25c980b40")
