-- Lua provided by RyzenAPI
-- Game: 1490980

-- MAIN APPLICATION
addappid(1490980)
-- Game: addappid(1490980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490981, 1, "32b53a43983b624a868cd9df2a98e1d74e0b8d1404bfc7a38cf03412c0d7155f")
