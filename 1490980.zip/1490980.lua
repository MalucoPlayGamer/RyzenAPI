-- Lua provided by SkyAPI 
-- Game: Mirror Layers
addappid(1490980)
addappid(1490981, 1, "32b53a43983b624a868cd9df2a98e1d74e0b8d1404bfc7a38cf03412c0d7155f")
