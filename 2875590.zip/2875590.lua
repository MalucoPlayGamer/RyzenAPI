-- Lua provided by RyzenAPI
-- Game: 2875590

-- MAIN APPLICATION
addappid(2875590)
-- Game: addappid(2875590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875591, 1, "00b34e35fc3282bed584fef48418c2d00556aacf15af0d0eb0fabc927f93444b")
