-- Lua provided by SkyAPI 
-- Game: AppID 436490
addappid(436490)
addappid(436491, 1, "68287b611870e088f0100ec763701289f0f3081916518d5dd2d4ef6bf716ba67")
