-- Lua provided by RyzenAPI
-- Game: Game: AppID 436490

-- MAIN APPLICATION
addappid(436490)
-- Game: addappid(436490)

-- MAIN APP DEPOTS / PACKAGES
addappid(436491, 1, "68287b611870e088f0100ec763701289f0f3081916518d5dd2d4ef6bf716ba67")
