-- Lua provided by SkyAPI 
-- Game: AppID 721420
addappid(721420)
addappid(721421, 1, "1796a010b9a15cb7028d9e230e0da74bbdb6b2fe70a6026a54257f7d99943102")
