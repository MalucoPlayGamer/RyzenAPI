-- Lua provided by RyzenAPI
-- Game: addappid(721420)

-- MAIN APPLICATION
addappid(721420)

-- MAIN APP DEPOTS / PACKAGES
addappid(721421, 1, "1796a010b9a15cb7028d9e230e0da74bbdb6b2fe70a6026a54257f7d99943102")
