-- Lua provided by RyzenAPI
-- Game: 不屈者传说 No Give up

-- MAIN APPLICATION
addappid(2333710)
-- Game: addappid(2333710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333711, 1, "9c6c6c21010906234e5336051010a697b969c356c4676b6fc2a6865f7039060a")
