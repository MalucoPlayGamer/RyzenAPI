-- Lua provided by RyzenAPI
-- Game: Greedland Demo

-- MAIN APPLICATION
addappid(2371540)
-- Game: addappid(2371540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371541, 1, "0c617493929bdd7f2cadd142324b39a27b28dbe2501a356bdade335e652fc209")
