-- Lua provided by RyzenAPI
-- Game: addappid(2921360)

-- MAIN APPLICATION
addappid(2921360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921361, 1, "b469983be9a29fff72aad6db057eed2755735546d86f4cc4fcf82460408228fd")
