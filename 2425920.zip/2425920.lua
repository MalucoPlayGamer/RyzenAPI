-- Lua provided by RyzenAPI
-- Game: GanaBlade

-- MAIN APPLICATION
addappid(2425920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425921, 1, "fcea8a77b9f48f5d0d8477164591d86333dc8dada020a5e9e6cbc28cfbc61240")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
