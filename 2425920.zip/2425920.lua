-- Lua provided by RyzenAPI
-- Game: addappid(2425920)

-- MAIN APPLICATION
addappid(2425920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425921, 1, "fcea8a77b9f48f5d0d8477164591d86333dc8dada020a5e9e6cbc28cfbc61240")
