-- Lua provided by RyzenAPI 
-- Game: GanaBlade
addappid(2425920)
addappid(2425921, 1, "fcea8a77b9f48f5d0d8477164591d86333dc8dada020a5e9e6cbc28cfbc61240")
