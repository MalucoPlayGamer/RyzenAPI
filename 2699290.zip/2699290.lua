-- Lua provided by RyzenAPI
-- Game: 2699290

-- MAIN APPLICATION
addappid(2699290)
-- Game: addappid(2699290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699291, 1, "4ad1b629c411562df8985b30b2b19368e46135cb25ad12dbe72c09dcbf4c4a78")
