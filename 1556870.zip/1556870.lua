-- Lua provided by RyzenAPI
-- Game: Golf Club Nostalgia

-- MAIN APPLICATION
addappid(1556870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556871, 1, "acbabcc6e158ff823fbbbdd6a3b524fd62ad288b15f89b72bd0470a180fae598")
