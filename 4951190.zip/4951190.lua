-- Lua provided by RyzenAPI
-- Game: Konbini Cleanup

-- MAIN APPLICATION
addappid(4951190) -- Konbini Cleanup

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4951191, 1, "87dd9b754c592a929b284876378d6510276a00defcc991edb3a6df314c1016c7") -- Depot 4951191

