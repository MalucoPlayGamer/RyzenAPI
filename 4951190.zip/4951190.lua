-- 4951190's Lua and Manifest Created by Hubcap Manifest
-- Konbini Cleanup
-- Created: August 15, 2026 at 04:11:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4951190) -- Konbini Cleanup
-- MAIN APP DEPOTS
addappid(4951191, 1, "87dd9b754c592a929b284876378d6510276a00defcc991edb3a6df314c1016c7") -- Depot 4951191
setManifestid(4951191, "3180492090276083777", 2337550136)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)