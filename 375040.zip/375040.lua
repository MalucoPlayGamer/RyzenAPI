-- Lua provided by RyzenAPI
-- Game: Death Tractor

-- MAIN APPLICATION
addappid(375040)
-- Game: addappid(375040)

-- MAIN APP DEPOTS / PACKAGES
addappid(375041, 1, "218aa11c72b9e976056b37b66fa879ea719a1fb6f62b4c4abcccb5893b8393e3")
