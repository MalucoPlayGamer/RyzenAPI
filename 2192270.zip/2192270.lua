-- Lua provided by SkyAPI 
-- Game: PumPum 2
addappid(2192270)
addappid(2192271, 1, "7b66529851c546d1ac7922c3382131dd97d2e0607553685c4c8ee36448e9ead7")
