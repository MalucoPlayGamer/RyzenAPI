-- Lua provided by RyzenAPI
-- Game: PumPum 2

-- MAIN APPLICATION
addappid(2192270)
-- Game: addappid(2192270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192271, 1, "7b66529851c546d1ac7922c3382131dd97d2e0607553685c4c8ee36448e9ead7")
