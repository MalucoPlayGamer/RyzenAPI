-- Lua provided by RyzenAPI
-- Game: P.I.

-- MAIN APPLICATION
addappid(3374280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3374281, 1, "d0b40d2ec2c28597d7ec9410860c466e4e988f6a55c713bb7ab03bcf7a069a9e")

