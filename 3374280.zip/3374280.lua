-- Lua provided by RyzenAPI
-- Game: P.I.

-- MAIN APPLICATION
addappid(3374280)
-- Game: addappid(3374280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374281, 1, "d0b40d2ec2c28597d7ec9410860c466e4e988f6a55c713bb7ab03bcf7a069a9e")
