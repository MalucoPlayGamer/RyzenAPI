-- Lua provided by RyzenAPI
-- Game: Diaochan - Officer Ticket / 貂蝉使用券

-- MAIN APPLICATION
addappid(956725)
-- Game: addappid(956725)

-- MAIN APP DEPOTS / PACKAGES
addappid(956725,0,"9f09c4d4e323e5f909a5b9f2816ffbb9f0417f40bff8efc8b4e6afe9c8f7ddd7")
