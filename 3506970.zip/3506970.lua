-- Lua provided by RyzenAPI
-- Game: Game: Chess Hunt

-- MAIN APPLICATION
addappid(3506970)
-- Game: addappid(3506970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3506971, 1, "e7dc9e81a0b98577da083e0d12367072a6c1b0eda39ebbbc5a5a2e4db3ac137a")
