-- Lua provided by RyzenAPI
-- Game: Game: Richman 11

-- MAIN APPLICATION
addappid(2074800)
-- Game: addappid(2074800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074801, 1, "1c60b83f26af04b13f22f7ba49b20d81e388536c3a589207af9dd2f02dd5b0a6")
addappid(2074802, 1, "b567884ad3b5b31ae469d224aaa710a68ddcdcafb189becce36f65f44ba3533a")
addappid(2074803, 1, "55392481a32eb1b72981655861f57107a3552212bdeb686bcfa9970c8edc4a90")
addappid(2074804, 1, "3701a04d898b85b754e84a1bfc620f472df8a7ebe6a51be214d985b815d99a86")
