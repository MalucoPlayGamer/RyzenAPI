-- Lua provided by RyzenAPI
-- Game: Novivors Demo

-- MAIN APPLICATION
addappid(3003090)
-- Game: addappid(3003090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003091, 1, "001e529fac6d282a790f5b3210fc84c4ae8b2b7fc91101c7a568a7b1754943fb")
