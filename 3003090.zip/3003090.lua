-- Lua provided by RyzenAPI 
-- Game: Novivors Demo
addappid(3003090)
addappid(3003091, 1, "001e529fac6d282a790f5b3210fc84c4ae8b2b7fc91101c7a568a7b1754943fb")
