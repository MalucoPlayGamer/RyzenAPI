-- Lua provided by RyzenAPI
-- Game: ДЕДУШКА

-- MAIN APPLICATION
addappid(4012710)

-- MAIN APP DEPOTS / PACKAGES
addappid(4012711,0,"ded503b5d031b7e3789305a85eef234aade3a768cb37ee533af4f4d73fd3f1b3")

