-- Lua provided by RyzenAPI
-- Game: addappid(2593130)

-- MAIN APPLICATION
addappid(2593130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593131, 1, "b86cf5232fb313ac6da9967b6cb7fd9e312a7b5e64dcd61eb58cafe7ad21e952")
