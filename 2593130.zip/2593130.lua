-- Lua provided by RyzenAPI
-- Game: Stress testing

-- MAIN APPLICATION
addappid(2593130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593131, 1, "b86cf5232fb313ac6da9967b6cb7fd9e312a7b5e64dcd61eb58cafe7ad21e952")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
