-- Lua provided by RyzenAPI
-- Game: addappid(3001560)

-- MAIN APPLICATION
addappid(3001560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001561, 1, "c9d8ebc9f17694690d406e2cba154ef6cfef0913258c98ca7214568bf3db0796")
addappid(3001562, 1, "b069130f1d9de53d708ccfd2780a23ddb6135e4397cfc4e02698c4b59ae79df0")
