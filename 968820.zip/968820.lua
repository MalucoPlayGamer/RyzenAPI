-- Lua provided by RyzenAPI
-- Game: 968820

-- MAIN APPLICATION
addappid(968820)
-- Game: addappid(968820)

-- MAIN APP DEPOTS / PACKAGES
addappid(968821, 1, "d37b44d7dfdfc673b92e78d75d775b1809cdb793cc05a66aacb56702dfa716e5")
