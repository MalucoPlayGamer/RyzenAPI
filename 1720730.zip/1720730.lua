-- Lua provided by RyzenAPI
-- Game: The Last Campfire Demo

-- MAIN APPLICATION
addappid(1720730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720731, 1, "0f8baa40db063f2106fce0e559b2e557d094870c6aeb37074450c914f296533d")
