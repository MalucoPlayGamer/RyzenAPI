-- Lua provided by RyzenAPI
-- Game: Rain of Reflections: Set Free

-- MAIN APPLICATION
addappid(695050)

-- MAIN APP DEPOTS / PACKAGES
addappid(695053,0,"872d75f09fc3a9326e25c596460817abeddb60ad0985de92127e858336867826")

