-- Lua provided by RyzenAPI
-- Game: Dungeon Tells

-- MAIN APPLICATION
addappid(2708230) -- Dungeon Tells

-- MAIN APP DEPOTS / PACKAGES
addappid(2708231, 1, "90ba886cebb77d0618013b5caac86cde9c2f2edb4a3270a9efffd877b1a39cbe") -- Depot 2708231

