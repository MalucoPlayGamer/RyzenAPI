-- 2708230's Lua and Manifest Created by Hubcap Manifest
-- Dungeon Tells
-- Created: August 22, 2026 at 02:03:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2708230) -- Dungeon Tells
-- MAIN APP DEPOTS
addappid(2708231, 1, "90ba886cebb77d0618013b5caac86cde9c2f2edb4a3270a9efffd877b1a39cbe") -- Depot 2708231
setManifestid(2708231, "4904579019713714280", 477841107)