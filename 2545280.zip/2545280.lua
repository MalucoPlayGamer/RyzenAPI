-- Lua provided by RyzenAPI
-- Game: addappid(2545280)

-- MAIN APPLICATION
addappid(2545280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545281, 1, "9b8eab823299ea73d2050de96fb1975bb8d60a8d3ecaa2b5d682d7dcebc555f9")
