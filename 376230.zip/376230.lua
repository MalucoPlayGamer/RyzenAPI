-- Lua provided by RyzenAPI
-- Game: 376230

-- MAIN APPLICATION
addappid(376230)
-- Game: addappid(376230)

-- MAIN APP DEPOTS / PACKAGES
addappid(376230,0,"e093b496cdd2d2a9dfcd6af2605a083d3d40153cd473ddbea970fb13489b1652")
