-- Lua provided by RyzenAPI
-- Game: Sea Fantasy

-- MAIN APPLICATION
addappid(2835110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835111, 1, "70ea9659a5036233e7b75a4083c0763068021bf6f54bda809e64ca206c40b98b")
