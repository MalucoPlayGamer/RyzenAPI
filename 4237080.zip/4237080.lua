-- Lua provided by RyzenAPI
-- Game: Animic : Attack with your voice !

-- MAIN APPLICATION
addappid(4237080)
addappid(4275650)

-- MAIN APP DEPOTS / PACKAGES
addappid(4237081, 1, "9e369bce80501f47fb69caed7a211b86456eeaaf9956d372786a7f45fbd12452")

