-- Lua provided by RyzenAPI
-- Game: addappid(2224660)

-- MAIN APPLICATION
addappid(2224660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224661, 1, "ed0bc54412ad1c264b9b47e0b1ae5a5e40b651031fc6560e2a30243946a1244d")
