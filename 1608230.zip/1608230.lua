-- Lua provided by RyzenAPI
-- Game: Planet of Lana

-- MAIN APPLICATION
addappid(1608230)
-- Game: addappid(1608230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608231, 1, "111bd9a2a83debc63dae7c527c541ebaa1192ccce92e1ce0f44f41dea9bc75f7")
