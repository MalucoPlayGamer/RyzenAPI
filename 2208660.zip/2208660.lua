-- Lua provided by RyzenAPI
-- Game: Lunistice Soundtrack

-- MAIN APPLICATION
addappid(2208660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208661, 1, "754c156f137c60d18e954c3010ed57daf93a87584406cf93777637273eeffbd6")
addappid(2208662, 1, "54d17e9be40e31d5462052778c438ce0bd9b289cecb84bf3af1b439666a330b2")
