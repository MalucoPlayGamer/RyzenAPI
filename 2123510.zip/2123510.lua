-- Lua provided by RyzenAPI
-- Game: LocoMotion

-- MAIN APPLICATION
addappid(2123510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123511, 1, "76b110102e36d45a0d5b10611062c36226644959148bdacd2394da447b02dd36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
