-- Lua provided by RyzenAPI
-- Game: Game: LocoMotion

-- MAIN APPLICATION
addappid(2123510)
-- Game: addappid(2123510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123511, 1, "76b110102e36d45a0d5b10611062c36226644959148bdacd2394da447b02dd36")
