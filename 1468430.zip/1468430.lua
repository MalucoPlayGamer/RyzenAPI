-- Lua provided by RyzenAPI
-- Game: Freezer Pops

-- MAIN APPLICATION
addappid(1468430)
addappid(1468450)
addappid(1768770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468431, 1, "22da4dc64f5e5c1318aeb18660759b35500ce988db9525e94ccef7f72b7c926b")
addappid(1468432, 1, "2abc09c388d386ec8765eda2aadc5374b9b09841d1fc25b39fc79d7103e87546")
addappid(1768771, 0, "c1412815bbd3074667794554dad05cd0e986863c68362c9cf5a1b2bc0cb04817")
addappid(1768772, 0, "652ab2f7474e28f7b9dfc6cc01c0d5ffcc03558fdea4424ecfff2aeda2505cc6")
addappid(1768773, 0, "a04a93d3da2837f5f6c1b1dbc1f2aa909a39494343deadb6a986752090a79a0d")
