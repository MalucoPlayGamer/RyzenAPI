-- Lua provided by RyzenAPI
-- Game: Game: Democracy 4

-- MAIN APPLICATION
addappid(1410710)
-- Game: addappid(1410710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410711, 1, "6dfa5cbefb753cc9c8da8fe6bd9507cdb37d341a6666af53988df4eb0a3e203b")
addappid(2004030, 0, "f904fc3b5a91a034104ac9386e139828c002c604028016fdf3666749e7f9f62d")
addappid(2137220, 0, "098420968d1aedc7efbf178c12c292485979ddc264a1ad63f0eaf9fc239c6f0e")
addappid(2291560, 0, "564aba38ddb49be6645dff175e3a87ed43330a7a13da8ea7a3362454393f8175")
