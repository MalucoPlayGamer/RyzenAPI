-- Lua provided by RyzenAPI
-- Game: AppID 597720

-- MAIN APPLICATION
addappid(597720)

-- MAIN APP DEPOTS / PACKAGES
addappid(597721, 1, "cb725f4e91e16a4372736aff5016b526779ea8acb96c82748fa48efc2378a9f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
