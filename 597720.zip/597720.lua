-- Lua provided by RyzenAPI
-- Game: addappid(597720)

-- MAIN APPLICATION
addappid(597720)

-- MAIN APP DEPOTS / PACKAGES
addappid(597721, 1, "cb725f4e91e16a4372736aff5016b526779ea8acb96c82748fa48efc2378a9f6")
