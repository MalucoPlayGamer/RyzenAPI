-- Lua provided by RyzenAPI
-- Game: Crowns & Chaos

-- MAIN APPLICATION
addappid(4864360) -- Crowns & Chaos

-- MAIN APP DEPOTS / PACKAGES
addappid(4864362, 1, "9a68d0a958916cc41f744ba105526cdb1f7c528aa2ad1465afebba33c8b9c301") -- Depot 4864362
addappid(4864363, 1, "85de784ebd810de299e4c0e3498a2ee7e09cccdb09829088f416566aeaf1e961") -- Depot 4864363

