-- Lua provided by RyzenAPI
-- Game: Princess.Loot.Pixel.Again

-- MAIN APPLICATION
addappid(414290)
addappid(456040)

-- MAIN APP DEPOTS / PACKAGES
addappid(414291, 1, "e71773b8254cbf446e9ebf988df8eafdb9d217bed1b26f29f505d19b51fffbc4")

