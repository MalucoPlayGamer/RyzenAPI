-- Lua provided by RyzenAPI
-- Game: Succubus Sessions: Mami Mamiya's Sweet Slice of Hell

-- MAIN APPLICATION
addappid(2361690)
-- Game: addappid(2361690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361691, 1, "e60924b78d03e78e2fa7af27c61784de23211adb6a7124a490a627e313cde904")
addappid(2361692, 1, "f7be5515de5b73fd49e955364751e4d84a831db4c4c08377ea5a2a7eb187f850")
addappid(2361693, 1, "90557486e804e61896b3723da83ff47a3fa60d58f5eb69eb4f42ffe59b1ccfa8")
