-- Lua provided by RyzenAPI
-- Game: Game: Marmoset Hexels 3

-- MAIN APPLICATION
addappid(428340)
-- Game: addappid(428340)

-- MAIN APP DEPOTS / PACKAGES
addappid(428341, 1, "93d5159bd580de85c485c6899a24cbbf63fb5faf8510a758819bdd6b7d65c446")
addappid(428343, 1, "46a68c4f914b8a093d8a376e486de5f22dd274d209c7250af020aae979e055d0")
