-- Lua provided by RyzenAPI 
-- Game: Bughouse
addappid(2066240)
addappid(2066241, 1, "ff2b746cbe723a0c63c99546da9c2aa1fc74aa9e3978c05878c1b93f4baa27d1")
