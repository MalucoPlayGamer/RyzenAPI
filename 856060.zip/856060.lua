-- Lua provided by RyzenAPI
-- Game: 蝶生梦影-Butterfly dream shadow

-- MAIN APPLICATION
addappid(856060)

-- MAIN APP DEPOTS / PACKAGES
addappid(856061, 1, "a7fc9ebd604b025f3c79f995af39bf97312dbf980aaac881c555a4a231cd058f")
addappid(1014700, 0, "e8100bd4c3657479558a093d6c44a4d8a095126f8d715ec7b6240b694e937b98")
