-- Lua provided by RyzenAPI
-- Game: Mare Nostrum Dedicated Server

-- MAIN APPLICATION
addappid(1240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241, 1, "42f61ea223df9582e16642d56ed2a1404c6de9436eefe69cec43824cf0023699")
