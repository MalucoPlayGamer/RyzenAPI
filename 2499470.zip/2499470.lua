-- Lua provided by RyzenAPI
-- Game: AppID 2499470

-- MAIN APPLICATION
addappid(2499470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2499471, 1, "ce51bb1be6fb214a9e0607240e38f892a836c472795de236e298e82261dc9f35")

