-- Lua provided by RyzenAPI
-- Game: Game: AppID 2499470

-- MAIN APPLICATION
addappid(2499470)
-- Game: addappid(2499470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499471, 1, "ce51bb1be6fb214a9e0607240e38f892a836c472795de236e298e82261dc9f35")
