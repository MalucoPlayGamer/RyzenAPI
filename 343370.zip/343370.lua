-- Lua provided by RyzenAPI
-- Game: Game: SLAMMED!

-- MAIN APPLICATION
addappid(343370)
-- Game: addappid(343370)

-- MAIN APP DEPOTS / PACKAGES
addappid(343371, 1, "41458fa9708278cda91af077a198730dfa2a82fbce20bec081d6617a9e26c4b2")
