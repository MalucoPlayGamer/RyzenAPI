-- Lua provided by RyzenAPI
-- Game: Game: Steel Salvo

-- MAIN APPLICATION
addappid(1584280)
-- Game: addappid(1584280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584281, 1, "292fe7384af2b469f54667307f92889e58ab8fee6e922db51c423255b1b4c1a8")
