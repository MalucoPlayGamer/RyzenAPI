-- Lua provided by RyzenAPI 
-- Game: Mental Hospital VR
addappid(1530860)
addappid(1530861, 1, "92e3bbca54f71b67bae15a505f80563effe5b1fa6d386d5a7d35edf6054949cf")
