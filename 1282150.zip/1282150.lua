-- Lua provided by SkyAPI 
-- Game: AppID 1282150
addappid(1282150)
addappid(1282151, 1, "7d88622df1d9b4da1a8b1a2374d17457b75ed7ade1db6e2190ee93e49e741746")
