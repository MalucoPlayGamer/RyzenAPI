-- Lua provided by RyzenAPI
-- Game: SpongeBob SquarePants: The Cosmic Shake

-- MAIN APPLICATION
addappid(1282150)
addappid(2152880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1282151, 1, "7d88622df1d9b4da1a8b1a2374d17457b75ed7ade1db6e2190ee93e49e741746")
