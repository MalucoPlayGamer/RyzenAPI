-- Lua provided by RyzenAPI
-- Game: addappid(868130)

-- MAIN APPLICATION
addappid(868130)

-- MAIN APP DEPOTS / PACKAGES
addappid(868131, 1, "3fcd1ba59873ceca74c395cc6178e9225fbf1193ba944060a3893117281c2017")
