-- Lua provided by RyzenAPI
-- Game: Kitchen Crisis

-- MAIN APPLICATION
addappid(2118250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118251, 1, "79c941cb151b42630e085922176a1fa981ba1eda17ec406b4813f077c93facb5")
addappid(2118252, 1, "4874caf056e2c27792bac4ee19df6b07688e70f67334ea199d868a213759df46")
addappid(2118253, 1, "d6007249711acb65783e16ccd30b5124ecc10b1cca7250624c1973872168f131")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2795430)
addappid(2795440)
addappid(2795450)
