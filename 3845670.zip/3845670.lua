-- Lua provided by RyzenAPI
-- Game: Game: Bare Knuckle Sandwich Soundtrack

-- MAIN APPLICATION
addappid(3845670)
-- Game: addappid(3845670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3845671, 1, "48c86c909248611d3635a2c4171ae664c5feee11206d1d76d00f3428d2db897b")
