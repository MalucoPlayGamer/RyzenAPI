-- Lua provided by RyzenAPI
-- Game: 1700310

-- MAIN APPLICATION
addappid(1700310)
-- Game: addappid(1700310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700310,0,"156f2e271e7aeb39d4eb330b039f999ca64fc5d4f8abc2d5c41d7ed69f955cb8")
