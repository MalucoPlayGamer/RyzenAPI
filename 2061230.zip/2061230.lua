-- Lua provided by RyzenAPI
-- Game: Game: Chasm: The Rift

-- MAIN APPLICATION
addappid(2061230)
-- Game: addappid(2061230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061231, 1, "136b156c5087f51e98bd42ac67d64251305b6b6aa3879f99df33c57437770571")
addappid(2061232, 1, "9e1c3474b394d52ae28315c0caf4da6112984fd86bc67a214e91947096ec69c3")
