-- Lua provided by RyzenAPI
-- Game: Game: BrainBread 2

-- MAIN APPLICATION
addappid(346330)
-- Game: addappid(346330)

-- MAIN APP DEPOTS / PACKAGES
addappid(346331, 1, "10b8e67f7412a12d624125b6575b8f2d93ffabe15aa1114d61da56b5c69e4d32")
addappid(346332, 1, "63bf8dc767c739a42bc23b248f348a48ebbaba9ccaca4b2cce00b1e5aad928e8")
addappid(346333, 1, "56afb83729cb596e25b84c7034717a9d3da8b062cd6544ec6d573514bd757822")
addappid(346334, 1, "5cdc97ee11d12262b57b33371c27d4d417c0302dae6a19af06888ab53b1d2ad2")
addappid(346335, 1, "56de96bf852aba7dfdd5ec3b2e7819ddc231cf7335851e9f11441284e914cd2f")
addappid(346336, 1, "c98ac9011e7f4d7a64354ae5519fd65a3599bc706953f327da6fe94412eb25b7")
