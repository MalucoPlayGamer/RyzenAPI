-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Magic Shop Animated Interior Pack

-- MAIN APPLICATION
addappid(1784520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784520,0,"4b462ed61a0ac042b843b148736a058c5007d246b9743f013bc9ab6d28898c6e")

