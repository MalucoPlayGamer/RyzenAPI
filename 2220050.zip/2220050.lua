-- Lua provided by RyzenAPI
-- Game: 我在终点线等你 Demo

-- MAIN APPLICATION
addappid(2220050)
-- Game: addappid(2220050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220051, 1, "f91ec35af04a87567c3c2a80b076631adf68800830d616cb6030d22d8ae2901e")
