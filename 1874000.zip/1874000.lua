-- Lua provided by RyzenAPI
-- Game: Life is Strange: Double Exposure

-- MAIN APPLICATION
addappid(1874000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874001, 1, "34de6dc6df22af7fc7df7fda8a5799f8793ae860ac574864e18896fecf02aeb2")
addappid(3012890, 0, "8538cdc8423137fdd53890d96f7395b141dd635ad6ccc37092464d57e5f35ce1")
addappid(3012900, 0, "c50fa338cf0d3a6411b58603d71ffd4209f1e48f95bd13e0a97954dd5a44b12a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
