-- Lua provided by RyzenAPI
-- Game: Lockdown: Stand Alone

-- MAIN APPLICATION
addappid(513270)
-- Game: addappid(513270)

-- MAIN APP DEPOTS / PACKAGES
addappid(513271, 1, "85056c05e0e7a2e7d592028bf78e743cd9765dbd0d38810db22017e0d9773371")
