-- Lua provided by RyzenAPI
-- Game: Mythic Kart Maker

-- MAIN APPLICATION
addappid(4020010)

-- MAIN APP DEPOTS / PACKAGES
addappid(4020010,0,"184851f6c01c87561f94eeb0658ef511dd1e1db0c0f6b132c7c0a68594b233f9")
addappid(4020011,0,"6b2f602ea331355cc11bb9e3a80987abd8aa1138ba7d52f6c507fb47ba42dcbf")

