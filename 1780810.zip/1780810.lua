-- Lua provided by RyzenAPI
-- Game: 1780810

-- MAIN APPLICATION
addappid(1780810)
-- Game: addappid(1780810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780810,0,"3dce10832a4444af61ff0eda802b4ecbf214904b91d6d8aca9d8088caebc3e75")
