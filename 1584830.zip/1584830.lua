-- Lua provided by RyzenAPI
-- Game: Duck Creator

-- MAIN APPLICATION
addappid(1584830)
-- Game: addappid(1584830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584831, 1, "866bceeec216b37287f30c61e60350bb721677610a79f28a2faa7065303515fe")
