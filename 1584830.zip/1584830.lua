-- Lua provided by RyzenAPI 
-- Game: Duck Creator
addappid(1584830)
addappid(1584831, 1, "866bceeec216b37287f30c61e60350bb721677610a79f28a2faa7065303515fe")
