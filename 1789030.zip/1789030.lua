-- Lua provided by SkyAPI 
-- Game: Maid Cafe on Electric Street
addappid(1789030)
addappid(1789031, 1, "652d3731f300de48a072b2a4da23fdf757189dda1bbd9c96bb1e1b5241534733")
