-- Lua provided by RyzenAPI
-- Game: Maid Cafe on Electric Street

-- MAIN APPLICATION
addappid(1789030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789031, 1, "652d3731f300de48a072b2a4da23fdf757189dda1bbd9c96bb1e1b5241534733")

