-- Lua provided by RyzenAPI
-- Game: Game: AppID 684530

-- MAIN APPLICATION
addappid(684530)
-- Game: addappid(684530)

-- MAIN APP DEPOTS / PACKAGES
addappid(684531, 1, "4b3a01f5664970c884a68075d2e3b58738c9fac16d3a5edc038b09760ea1bf20")
