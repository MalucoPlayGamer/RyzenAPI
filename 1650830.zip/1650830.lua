-- Lua provided by RyzenAPI
-- Game: No!Ah!'s Ark

-- MAIN APPLICATION
addappid(1650830)
-- Game: addappid(1650830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650831, 1, "b0ec827a7e8f3f813692eb2132a93b0e753611835ba5bac1ff1f150712acaa4c")
addappid(1696880, 0, "b9e2b1e0467b387f7e5524512d1b9cab52c6244c334645b1fa2e538d8f1c2e37")
