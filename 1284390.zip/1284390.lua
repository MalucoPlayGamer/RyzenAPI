-- Lua provided by RyzenAPI
-- Game: The Elven Educator ~another ver~

-- MAIN APPLICATION
addappid(1284390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284391, 1, "411d8cf2001b5c5ed3b606ab792377fa5a7140f7203e871274d0e9f2584729dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
