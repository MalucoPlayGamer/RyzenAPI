-- Lua provided by RyzenAPI
-- Game: The Elven Educator ~another ver~

-- MAIN APPLICATION
addappid(1284390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284391, 1, "411d8cf2001b5c5ed3b606ab792377fa5a7140f7203e871274d0e9f2584729dc")
