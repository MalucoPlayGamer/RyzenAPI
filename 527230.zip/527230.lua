-- Lua provided by RyzenAPI
-- Game: Game: For The King

-- MAIN APPLICATION
addappid(527230)
addappid(1433560)
addappid(1630170)
addappid(1709620)
addappid(1768601)
addappid(1768602)
-- Game: addappid(527230)

-- MAIN APP DEPOTS / PACKAGES
addappid(527231, 1, "9e764a4df30f6e0ca2280e0ed0684e027a085170d13892c888817937ba447d08")
addappid(527232, 1, "a541b76197cadde01e2e02c877b5da8bda6528b017ca51243a5df43e17cf3971")
addappid(527233, 1, "19d190d035f3e081fde14434c1db713f843889496a9a77451724fb20b2e52273")
addappid(527234, 1, "18935d38deb6341c324e9c4cd0ccf42e80963ec796d448cd71348e248b4d9fdf")
addappid(844340, 0, "93e6cc194dfdb196c78e9a70e0205b12ca39cd81f931c969f5b6c6f824d703de")
