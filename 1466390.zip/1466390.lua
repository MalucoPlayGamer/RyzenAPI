-- Lua provided by RyzenAPI
-- Game: Kathy Rain 2: Soothsayer

-- MAIN APPLICATION
addappid(1466390)
-- Game: addappid(1466390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466391, 1, "0841982e471c67dfb711963a190794bc72094844ed98a58ab3e97158b4c495ab")
