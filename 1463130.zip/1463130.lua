-- Lua provided by RyzenAPI
-- Game: 1463130

-- MAIN APPLICATION
addappid(1463130)
-- Game: addappid(1463130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463131, 1, "694d31c84d5aa702df1b4fdcf8ba54c1a857d88c8fa93b849675f046f04f5889")
