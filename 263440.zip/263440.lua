-- Lua provided by RyzenAPI
-- Game: Stomping Land

-- MAIN APPLICATION
addappid(263440)

-- MAIN APP DEPOTS / PACKAGES
addappid(263441, 1, "4e34747c3048e1e85a39a4b230399515f0d7c942681a7b8af2a610dcbf1ac17a")

