-- Lua provided by SkyAPI 
-- Game: AppID 263440
addappid(263440)
addappid(263441, 1, "4e34747c3048e1e85a39a4b230399515f0d7c942681a7b8af2a610dcbf1ac17a")
