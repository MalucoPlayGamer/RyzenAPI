-- Lua provided by RyzenAPI
-- Game: Scrap and Battery

-- MAIN APPLICATION
addappid(2654590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654591, 1, "25a44be35b6204f93a9c86dbdbd1b9207b034964afc02c5e7b9b4ce48489f3e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
