-- Lua provided by SkyAPI 
-- Game: Scrap and Battery
addappid(2654590)
addappid(2654591, 1, "25a44be35b6204f93a9c86dbdbd1b9207b034964afc02c5e7b9b4ce48489f3e6")
