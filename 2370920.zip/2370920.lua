-- Lua provided by RyzenAPI
-- Game: 2370920

-- MAIN APPLICATION
addappid(2370920)
-- Game: addappid(2370920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370921, 1, "96381f1618efb9a4bb376cc3b562638bd728c945f9133a21310dfa106ba3a547")
