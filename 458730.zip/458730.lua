-- Lua provided by RyzenAPI
-- Game: Conception II: Children of the Seven Stars

-- MAIN APPLICATION
addappid(458730)

-- MAIN APP DEPOTS / PACKAGES
addappid(458731, 1, "4374568a21fa2aab1051cb7b8d566d03211845548ff197d958fd5c2d24fd8fd5")
addappid(458732, 1, "4eb1e647dae59f7ae109b0aa4b9526e27436da9f7fadcb629cd35cb12e424900")
addappid(504270, 0, "55a1e3ac437e57896bff2cc9e443efdefead3ef81944612e3a18a831f4ebc46a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
