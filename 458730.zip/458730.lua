-- Lua provided by RyzenAPI
-- Game: 458730

-- MAIN APPLICATION
addappid(458730)
-- Game: addappid(458730)

-- MAIN APP DEPOTS / PACKAGES
addappid(458731, 1, "4374568a21fa2aab1051cb7b8d566d03211845548ff197d958fd5c2d24fd8fd5")
addappid(458732, 1, "4eb1e647dae59f7ae109b0aa4b9526e27436da9f7fadcb629cd35cb12e424900")
addappid(504270, 0, "55a1e3ac437e57896bff2cc9e443efdefead3ef81944612e3a18a831f4ebc46a")
