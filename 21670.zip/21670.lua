-- Lua provided by RyzenAPI
-- Game: addappid(21670)

-- MAIN APPLICATION
addappid(21670)

-- MAIN APP DEPOTS / PACKAGES
addappid(21671, 1, "9a3ae97fbe9635eb5c7fb9808ea6988ae886810b130453a0c09f50e32744a228")
