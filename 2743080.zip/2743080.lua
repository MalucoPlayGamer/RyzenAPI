-- Lua provided by RyzenAPI
-- Game: 2743080

-- MAIN APPLICATION
addappid(2743080)
-- Game: addappid(2743080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743081, 1, "d5244216a790c4a6d223f0defbd1dc87406872a8b952571ad940cd8b54bf1823")
