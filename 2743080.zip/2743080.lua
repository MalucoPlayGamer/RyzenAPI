-- Lua provided by RyzenAPI
-- Game: 100 Capitalist Cats

-- MAIN APPLICATION
addappid(2743080)
addappid(2779640)
addappid(2779650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743081, 1, "d5244216a790c4a6d223f0defbd1dc87406872a8b952571ad940cd8b54bf1823")
