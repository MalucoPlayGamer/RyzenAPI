-- Lua provided by RyzenAPI
-- Game: addappid(2168450)

-- MAIN APPLICATION
addappid(2168450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168451, 1, "12b2a701d1da7657ef2067c597eb0438f9b5239980a261cb0ff3cea9f6014872")
