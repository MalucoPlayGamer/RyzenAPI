-- Lua provided by RyzenAPI
-- Game: AppID 1203370

-- MAIN APPLICATION
addappid(1203370)
-- Game: addappid(1203370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203371, 1, "fa900edc7ac9f327bf7af5fd8dce34a761f4e6d8208fbaf25fd8c9df24443f91")
