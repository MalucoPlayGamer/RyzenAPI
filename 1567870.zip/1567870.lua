-- Lua provided by RyzenAPI
-- Game: 1567870

-- MAIN APPLICATION
addappid(1567870)
-- Game: addappid(1567870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567871, 1, "aeb561195783b87976a1524305f653cd1bb756ae767b344ff5d2c1fbc6ae4617")
