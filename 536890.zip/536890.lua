-- Lua provided by RyzenAPI 
-- Game: Glittermitten Grove
addappid(536890)
addappid(536891, 1, "3ed3ef26bb4f0af0220d2c4acacbf4abae9a84a61f9e2c8d37b44ef7b2246c3a")
addappid(536892, 1, "8df5bb40e40f93831ce1151b42878a5e8a771bc123ee89f53098081dd4bb6b09")
addappid(536893, 1, "a3a4c8e5320c652714579b232ecfbb24d7b6f1b2f5a7adfa21afaab48a9dc824")
addappid(1237100)
