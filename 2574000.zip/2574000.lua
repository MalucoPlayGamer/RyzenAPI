-- Lua provided by RyzenAPI
-- Game: addappid(2574000)

-- MAIN APPLICATION
addappid(2574000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574001, 1, "fdb59b5c62be97543a4189b9aabda7bf23a548b852b8afbe643dcf33f051aa30")
