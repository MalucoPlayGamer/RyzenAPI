-- Lua provided by RyzenAPI
-- Game: 767030

-- MAIN APPLICATION
addappid(767030)
-- Game: addappid(767030)

-- MAIN APP DEPOTS / PACKAGES
addappid(767031, 1, "ac0ee163a69f135ce3711e8cd8af08bb3f6fe7b59c2078757661687365fce311")
