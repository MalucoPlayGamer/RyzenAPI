-- Lua provided by RyzenAPI
-- Game: Blacksmith

-- MAIN APPLICATION
addappid(787840)
addappid(787843)
addappid(787844)

-- MAIN APP DEPOTS / PACKAGES
addappid(787842,0,"ca3166334299d0c842282aac0045485ed1275dbaf0b60bab7e020ef412dd3d90")
