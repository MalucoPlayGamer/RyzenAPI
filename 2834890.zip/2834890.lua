-- Lua provided by SkyAPI 
-- Game: Christmas Stories: The Legend of Toymakers Collector's Edition
addappid(2834890)
addappid(2834891, 1, "197f13acef4cbe911104b3257841e9d23f21de58688e9e04bb877e17c9874d0b")
