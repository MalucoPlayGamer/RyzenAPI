-- Lua provided by RyzenAPI
-- Game: addappid(402310)

-- MAIN APPLICATION
addappid(402310)

-- MAIN APP DEPOTS / PACKAGES
addappid(402311, 1, "8b332c2223d0dbdbdf63eb6bd067241411870b9f17b32abe572693ecb9e9c2a4")
