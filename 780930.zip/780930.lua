-- Lua provided by RyzenAPI
-- Game: Cute War：Zero 萌系战争：零

-- MAIN APPLICATION
addappid(780930)

-- MAIN APP DEPOTS / PACKAGES
addappid(780931,0,"3d0b0df3d8668571e0b9008c804060850da9d4c0005e42774750ef2715f91861")

