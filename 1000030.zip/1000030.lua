-- Lua provided by RyzenAPI
-- Game: Cook, Serve, Delicious! 3?!

-- MAIN APPLICATION
addappid(1000030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000031, 1, "b3168631ed68f079a4f8387a3cada0af96fd440ad9d3761f73ff1dd945254484")
addappid(1000032, 1, "270510d613e91deab852b14f372431ddda63fb935c720243b809bb7a91463a64")

