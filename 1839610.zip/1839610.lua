-- Lua provided by RyzenAPI
-- Game: addappid(1839610)

-- MAIN APPLICATION
addappid(1839610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839611, 1, "c6b2995e22ab75b6f7147d9bfb41639d85bf05d8938aa4b0a63faa7de611b755")
