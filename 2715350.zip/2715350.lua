-- Lua provided by RyzenAPI 
-- Game: Survisland Demo
addappid(2715350)
addappid(2715351, 1, "6db4084e80324fbf5ba6e31c586f44b7df2f0dcf1d33749429e96ba5d5e447ef")
