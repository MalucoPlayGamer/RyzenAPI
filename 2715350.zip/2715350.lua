-- Lua provided by RyzenAPI
-- Game: Game: Survisland Demo

-- MAIN APPLICATION
addappid(2715350)
-- Game: addappid(2715350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715351, 1, "6db4084e80324fbf5ba6e31c586f44b7df2f0dcf1d33749429e96ba5d5e447ef")
