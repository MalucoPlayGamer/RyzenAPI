-- Lua provided by RyzenAPI
-- Game: AppID 3318180

-- MAIN APPLICATION
addappid(3318180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318181, 1, "e5edfd12b3eac23e21279a0647cb4c5fd1080e1900cdb4f3f2a93d5db1f145e5")

