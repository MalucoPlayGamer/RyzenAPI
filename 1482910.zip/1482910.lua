-- Lua provided by RyzenAPI
-- Game: Idle Monster TD

-- MAIN APPLICATION
addappid(1482910)
