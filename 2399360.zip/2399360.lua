-- Lua provided by RyzenAPI
-- Game: King of Fate

-- MAIN APPLICATION
addappid(2399360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399361, 1, "44a5bd8159edfd57a7f1a268631bc58f54e43529e1cfab4e9e740fee0ba2e2b9")
