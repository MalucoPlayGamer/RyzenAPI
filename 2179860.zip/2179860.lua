-- Lua provided by RyzenAPI
-- Game: 2179860

-- MAIN APPLICATION
addappid(2179860)
-- Game: addappid(2179860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179861, 1, "0bfb20f547237618f1aedb1d07259e8f33e9d95c2761eca5faf6b1301f3fa0b9")
