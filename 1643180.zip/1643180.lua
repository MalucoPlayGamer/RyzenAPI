-- Lua provided by RyzenAPI
-- Game: Artist Life Simulator

-- MAIN APPLICATION
addappid(1643180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643181, 1, "8b25816dad947330e965111923dcaff941c73016cdbeb9ea45de209fa126b444")
addappid(2358550, 0, "13d756543e7b641e32ef27a9e33eaf9b5b4915469d7ab57aa8bb51bf2d25db52")
