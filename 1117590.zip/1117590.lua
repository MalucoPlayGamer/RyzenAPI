-- Lua provided by RyzenAPI
-- Game: AppID 1117590

-- MAIN APPLICATION
addappid(1117590)
-- Game: addappid(1117590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117591, 1, "239e6dbbd45f75d9f8ab8a06879678948ecfb1d2bc6ee5095e9249ed11da28d2")
