-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Essentials Set Z

-- MAIN APPLICATION
addappid(1366640)
-- Game: addappid(1366640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366640,0,"9942bb6e0c73d66a4cafe6b5bd9ac757879e9b83bd77c9e5260aaf23a61b3937")
