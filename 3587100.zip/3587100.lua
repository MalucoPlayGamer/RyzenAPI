-- Lua provided by RyzenAPI
-- Game: Game: Haste Soundtrack

-- MAIN APPLICATION
addappid(3587100)
-- Game: addappid(3587100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587101, 1, "2c0b7404519eef3fad96505eee8ef9dfd335c1c26ede4ca40ffa3ab7d0f0617e")
addappid(3587102, 1, "3480d60cd7ed2b25daa568920bcea90ab3b655070f8d80eae64afd9a66abb8a0")
