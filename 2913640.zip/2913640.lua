-- Lua provided by RyzenAPI
-- Game: Night Slashers: Remake Demo

-- MAIN APPLICATION
addappid(2913640)
-- Game: addappid(2913640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913641, 1, "5a327882dc1196c681805a473406c5700d6adb1c4936db8300634e9f9b0ef7a2")
