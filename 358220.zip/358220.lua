-- Lua provided by RyzenAPI
-- Game: Mystic Towers

-- MAIN APPLICATION
addappid(358220)

-- MAIN APP DEPOTS / PACKAGES
addappid(358221, 1, "68f0c13e34ba54f3a237f9318d1b9bfa48d2a98060097fdbba5d1c8267ac4977")
addappid(358222, 1, "d610777c4607b768992a2a28ce5a28c4bcc6689bdc5874e85bb74d456344e871")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
