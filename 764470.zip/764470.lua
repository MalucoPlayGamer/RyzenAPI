-- Lua provided by RyzenAPI
-- Game: 764470

-- MAIN APPLICATION
addappid(764470)
-- Game: addappid(764470)

-- MAIN APP DEPOTS / PACKAGES
addappid(764471, 1, "90d957f9c75ae80917f8becbc6f0a0f2db33eb02c0489b2a6dc5b53ecacfc3a4")
