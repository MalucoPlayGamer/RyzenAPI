-- Lua provided by RyzenAPI
-- Game: Gear Path

-- MAIN APPLICATION
addappid(764470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(764471, 1, "90d957f9c75ae80917f8becbc6f0a0f2db33eb02c0489b2a6dc5b53ecacfc3a4")

