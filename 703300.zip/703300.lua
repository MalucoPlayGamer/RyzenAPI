-- Lua provided by RyzenAPI
-- Game: addappid(703300)

-- MAIN APPLICATION
addappid(703300)

-- MAIN APP DEPOTS / PACKAGES
addappid(703301, 1, "806c15a51cf0ecb76d6d58d67972468e634a6dc7f04237922be191d8ac046c5a")
