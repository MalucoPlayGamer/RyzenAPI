-- Lua provided by RyzenAPI
-- Game: AppID 703300

-- MAIN APPLICATION
addappid(703300)

-- MAIN APP DEPOTS / PACKAGES
addappid(703301, 1, "806c15a51cf0ecb76d6d58d67972468e634a6dc7f04237922be191d8ac046c5a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1545310)
