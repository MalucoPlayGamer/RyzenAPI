-- Lua provided by RyzenAPI
-- Game: 1387300

-- MAIN APPLICATION
addappid(1387300)
-- Game: addappid(1387300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387301, 1, "927cfdf8bb0c4c0c65dfed3864bd1dc4270fa58b8e5ffd33bb95f456acfc6cff")
