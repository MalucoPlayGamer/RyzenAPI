-- Lua provided by RyzenAPI
-- Game: Typing with Jester

-- MAIN APPLICATION
addappid(496520)
-- Game: addappid(496520)

-- MAIN APP DEPOTS / PACKAGES
addappid(496521, 1, "9ec31b7273baa9851ba719c0d6a2808ed0a64257671b9c9a0a0d9158f83348df")
