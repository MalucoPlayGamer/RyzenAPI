-- Lua provided by RyzenAPI
-- Game: Trivia About You

-- MAIN APPLICATION
addappid(3196180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196181,0,"a0b3316d3e438dd6daf34d92b9f5658b3be233d7a55ee6cfdd703c8717384597")

