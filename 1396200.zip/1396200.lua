-- Lua provided by RyzenAPI
-- Game: Game: Touhou MONEY STOCKS SHOPS Demo

-- MAIN APPLICATION
addappid(1396200)
-- Game: addappid(1396200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396201, 1, "00fcec8cd5934443f0c3c5898d3d40831f19015f35d19039b23433fd579f6587")
