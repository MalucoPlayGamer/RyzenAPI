-- Lua provided by RyzenAPI
-- Game: 小林正雪復仇之密室重制版 Cheney Wood The Ultimate Revenge

-- MAIN APPLICATION
addappid(899160)

-- MAIN APP DEPOTS / PACKAGES
addappid(899161, 1, "7d62f640649834328f0766e1814e8b9822420e47c51f2f7f29679a4cd631c441")

