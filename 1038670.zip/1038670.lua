-- Lua provided by RyzenAPI
-- Game: addappid(1038670)

-- MAIN APPLICATION
addappid(1038670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038671, 1, "e9c44d115e78580875537810b4791fc4a4c761dcabfb87d6aed72c043d43d9e5")
