-- Lua provided by RyzenAPI
-- Game: AppID 38410

-- MAIN APPLICATION
addappid(38410)
addappid(229002)

-- MAIN APP DEPOTS / PACKAGES
addappid(38411, 1, "aff49414c4988ff4442db9a3c83457bf7bb4f359a8273da808dabaa0da38d7f2")
addappid(38412, 1, "248ad047e5040b910c8209c65c51264d3c8ae11619c8bef85d88717a9c2a9128")
addappid(38413, 1, "cf40d566acc333b23b0c7df962ce5884d4aee236c8d8594e5797be0dfb81d776")
addappid(38414, 1, "8a50c6c647ca445d18d455421511a37d090420d715a3ef85e768256f0ff50a01")
addappid(38415, 1, "2e96205233faf6d6277afa08afb17363506de014af1e8c450d925480564fbcc7")
addappid(38416, 1, "b6b272151daf3af00be57df71c61003c2341c25a1d09eeaa16b579b697dcc15f")
addappid(38417, 1, "02ad04f9e2f3bd4b4db301555f5049e8d0a02123894814a9aec6e47439f57eb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
