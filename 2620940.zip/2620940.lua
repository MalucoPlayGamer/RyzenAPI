-- Lua provided by RyzenAPI
-- Game: Fallen Seeds

-- MAIN APPLICATION
addappid(2620940)
-- Game: addappid(2620940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620941, 1, "4c74f0fff3808a7daa1013db8d6188ad0402939b8685f028a1f2f5fed7a665ea")
