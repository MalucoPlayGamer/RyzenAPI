-- Lua provided by RyzenAPI
-- Game: Ether Loop

-- MAIN APPLICATION
addappid(1188970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1188972,0,"5b64c0b4ba3374520e2043e4cb2d3a103b2243f8308fc28073ad734052932ed6")

