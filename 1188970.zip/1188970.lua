-- Lua provided by RyzenAPI
-- Game: Ether Loop

-- MAIN APPLICATION
addappid(1188970)
-- Game: addappid(1188970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188972,0,"5b64c0b4ba3374520e2043e4cb2d3a103b2243f8308fc28073ad734052932ed6")
