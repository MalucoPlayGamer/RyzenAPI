-- Lua provided by RyzenAPI
-- Game: addappid(2317540)

-- MAIN APPLICATION
addappid(2317540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317541, 1, "580f35dd6acfa6326674dec524168136d4e13814166dc4802fbf0239fad683ed")
