-- Lua provided by SkyAPI 
-- Game: Ocean Man
addappid(2317540)
addappid(2317541, 1, "580f35dd6acfa6326674dec524168136d4e13814166dc4802fbf0239fad683ed")
