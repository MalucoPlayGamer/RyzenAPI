-- Lua provided by RyzenAPI
-- Game: addappid(1679290)

-- MAIN APPLICATION
addappid(1679290)
addappid(2020070)
addappid(2020071)
addappid(2020170)
addappid(2315550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679291, 1, "ea1fce43fd867b5060ed1f20536c095389f4ca2678e88eecd0df9469ea1bf0fe")
