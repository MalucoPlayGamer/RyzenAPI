-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.13「黄昏は瑠璃の追憶」

-- MAIN APPLICATION
addappid(2686780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686781, 1, "72e336767272337764ecaead846b5f00de59754f8400e2c37e2c46b44201dea6")
