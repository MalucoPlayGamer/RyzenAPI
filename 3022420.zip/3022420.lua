-- Lua provided by RyzenAPI
-- Game: AppID 3022420

-- MAIN APPLICATION
addappid(3022420)
-- Game: addappid(3022420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022421, 1, "28aee641f3f573c5379e0ee5d7b6ed23d712f74bbcf9f40e1af5716b24674370")
