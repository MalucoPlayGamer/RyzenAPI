-- Lua provided by RyzenAPI
-- Game: 1952890

-- MAIN APPLICATION
addappid(1952890)
-- Game: addappid(1952890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952891, 1, "cfb578e436f58b19e5eee99964c6f41e8fea9583230c8f4fe83d7629bfff0ae9")
addappid(1952892, 1, "dfa9099bd49d4da4d48eef63dd3fd7096812877e7eaa1382250ad81945cc98ea")
addappid(1952893, 1, "61cb516fb183b7c09aa0ff5a875f455a8f7313b7eddd8da81228a6a577c0e3f0")
