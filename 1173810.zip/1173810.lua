-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY V

-- MAIN APPLICATION
addappid(1173810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1173811, 1, "5dee0fcdeaae9b85696d06c22f4adc054f1c6384f62e0bf2b3081bb1bb57cad9")
addappid(1638400, 0, "04759f0d604e673e9bf564bc2572bdacb3ad61e7a887f7f629953aa88bbeca4c")
