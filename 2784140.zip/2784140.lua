-- Lua provided by RyzenAPI
-- Game: 100 Cats London

-- MAIN APPLICATION
addappid(2784140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784141, 1, "fa8f4ceae3ced31d3106f3ffe559ad97641004e617bf168c5e0b0afd2d886b2e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3106250)
