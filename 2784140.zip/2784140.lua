-- Lua provided by RyzenAPI 
-- Game: 100 Cats London
addappid(2784140)
addappid(2784141, 1, "fa8f4ceae3ced31d3106f3ffe559ad97641004e617bf168c5e0b0afd2d886b2e")
