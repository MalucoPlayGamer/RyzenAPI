-- Lua provided by RyzenAPI
-- Game: Dawn of Anarchy

-- MAIN APPLICATION
addappid(2664880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664881, 1, "df51bd80b571422f09cd025d6e8b2ef9e61fa4c6194ea50e666e071c677ee132")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
