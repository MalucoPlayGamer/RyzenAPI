-- Lua provided by RyzenAPI
-- Game: Game: Dawn of Anarchy

-- MAIN APPLICATION
addappid(2664880)
-- Game: addappid(2664880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664881, 1, "df51bd80b571422f09cd025d6e8b2ef9e61fa4c6194ea50e666e071c677ee132")
