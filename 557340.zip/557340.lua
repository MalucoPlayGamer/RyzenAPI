-- Lua provided by RyzenAPI
-- Game: Game: My Friend Pedro

-- MAIN APPLICATION
addappid(557340)
-- Game: addappid(557340)

-- MAIN APP DEPOTS / PACKAGES
addappid(557341, 1, "9eee4b0c466a471d00fd0c84defb6fbb2f755d43af81eae4cf08f1f33a0bbf2a")
addappid(1107290, 0, "49cf136c4db566eb5f0123e0c6c152cc7be8b5ccd1e492056cfe436575f0caa6")
