-- Lua provided by RyzenAPI
-- Game: Jusant

-- MAIN APPLICATION
addappid(1977170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1977171, 1, "499a8c9d6e61ef12de56cfc87af782e9e635a83119608889231331bd8d244655")

