-- Lua provided by RyzenAPI
-- Game: Jusant

-- MAIN APPLICATION
addappid(1977170)
-- Game: addappid(1977170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977171, 1, "499a8c9d6e61ef12de56cfc87af782e9e635a83119608889231331bd8d244655")
