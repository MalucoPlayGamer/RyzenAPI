-- Lua provided by RyzenAPI 
-- Game: Find Yourself
addappid(1504740)
addappid(1504741, 1, "cbefeebc157ed50a96eee1c2d4c2221911fd79254367e8c7063481c4fee5ffb1")
