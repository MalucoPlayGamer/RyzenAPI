-- Lua provided by RyzenAPI
-- Game: Find Yourself

-- MAIN APPLICATION
addappid(1504740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504741, 1, "cbefeebc157ed50a96eee1c2d4c2221911fd79254367e8c7063481c4fee5ffb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
