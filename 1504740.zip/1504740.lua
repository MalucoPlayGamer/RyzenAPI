-- Lua provided by RyzenAPI
-- Game: Find Yourself

-- MAIN APPLICATION
addappid(1504740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504741, 1, "cbefeebc157ed50a96eee1c2d4c2221911fd79254367e8c7063481c4fee5ffb1")
