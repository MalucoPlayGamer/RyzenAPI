-- Lua provided by RyzenAPI
-- Game: addappid(322110)

-- MAIN APPLICATION
addappid(322110)

-- MAIN APP DEPOTS / PACKAGES
addappid(322111, 1, "b4022475ec1beae0d8c52f80d38b62433930db6c70561db41a15db914b7f86d1")
