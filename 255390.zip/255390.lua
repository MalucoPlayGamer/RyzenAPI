-- Lua provided by RyzenAPI 
-- Game: Max: The Curse of Brotherhood
addappid(255390)
addappid(255391, 1, "71122b41f37b2f865c5c70d4094168fba3a80ee42823efeb0cbc1969b9cda904")
addappid(255392, 1, "d533ab39bd94087c303d846792163ede4180160afd0cf7df076a95c41c5c99ce")
