-- Lua provided by RyzenAPI
-- Game: Max: The Curse of Brotherhood

-- MAIN APPLICATION
addappid(255390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(255391, 1, "71122b41f37b2f865c5c70d4094168fba3a80ee42823efeb0cbc1969b9cda904")
addappid(255392, 1, "d533ab39bd94087c303d846792163ede4180160afd0cf7df076a95c41c5c99ce")

