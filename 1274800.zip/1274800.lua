-- Lua provided by RyzenAPI
-- Game: Game: AppID 1274800

-- MAIN APPLICATION
addappid(1274800)
-- Game: addappid(1274800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274801, 1, "a5ffdee14e20dbd64fb65772597f211472b18260eacf3a82d1de4e09a3a3c68f")
addappid(1274802, 1, "c328507f6bb06cebc1f9cb174a86ad23ed57701ad0b917ded0f7324992dc6efb")
