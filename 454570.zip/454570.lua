-- Lua provided by RyzenAPI
-- Game: AppID 454570

-- MAIN APPLICATION
addappid(454570)
-- Game: addappid(454570)

-- MAIN APP DEPOTS / PACKAGES
addappid(454571, 1, "cba12f24bfc8ae79c86bf4aa9c954be3ca5e10d964f2a0ea9bdab96f04f3c604")
