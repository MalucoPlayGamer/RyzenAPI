-- Lua provided by RyzenAPI
-- Game: There is a Thief in my House

-- MAIN APPLICATION
addappid(1160050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1160051, 1, "a02f620a070e7e7825b3db834cb330eb29f686416400b787b05e480becfb9337")

