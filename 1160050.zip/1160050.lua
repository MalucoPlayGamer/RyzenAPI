-- Lua provided by RyzenAPI
-- Game: Game: AppID 1160050

-- MAIN APPLICATION
addappid(1160050)
-- Game: addappid(1160050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160051, 1, "a02f620a070e7e7825b3db834cb330eb29f686416400b787b05e480becfb9337")
