-- Lua provided by RyzenAPI
-- Game: Gunslinger

-- MAIN APPLICATION
addappid(2322510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322511, 1, "60e973648749b13fed72ab40b8dd6e2c00751fea9a5f9bfa9d3e13a242f13cde")

