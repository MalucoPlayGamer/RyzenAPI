-- Lua provided by RyzenAPI
-- Game: Happy Mask

-- MAIN APPLICATION
addappid(2525570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525571, 1, "896c95b52973ca70bced1666e5d1b6822b47116c079fdf4c787b9ac80585ab5d")
