-- Lua provided by RyzenAPI
-- Game: AppID 1086470

-- MAIN APPLICATION
addappid(1086470)
-- Game: addappid(1086470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086471, 1, "667cf5a8137e09357d4725bfb3f0906b32d11cee3b94835a3f8f57eda5ae57e3")
