-- Lua provided by RyzenAPI
-- Game: Himno - Original Soundtrack

-- MAIN APPLICATION
addappid(1050450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050450,0,"ccd25414948c4763b096f14579d7df414e49f34d5c3f5c633d158e829519c3f0")

