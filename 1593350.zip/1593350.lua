-- Lua provided by RyzenAPI
-- Game: 1593350

-- MAIN APPLICATION
addappid(1593350)
-- Game: addappid(1593350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593351, 1, "5f9e57cecca224d0b058c6aceda71144921be24df6943260b60e3d11c1369cb1")
