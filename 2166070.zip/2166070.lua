-- Lua provided by RyzenAPI
-- Game: addappid(2166070)

-- MAIN APPLICATION
addappid(2166070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166071, 1, "e051549c95acc9e5066e18682b01b6a87429d72168ab258e102a9d87ece8bfd1")
