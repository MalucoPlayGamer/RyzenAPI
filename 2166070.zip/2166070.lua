-- Lua provided by RyzenAPI
-- Game: Spy Girl-01

-- MAIN APPLICATION
addappid(2166070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2166071, 1, "e051549c95acc9e5066e18682b01b6a87429d72168ab258e102a9d87ece8bfd1")

