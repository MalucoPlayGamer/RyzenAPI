-- Lua provided by RyzenAPI
-- Game: 618260

-- MAIN APPLICATION
addappid(618260)
-- Game: addappid(618260)

-- MAIN APP DEPOTS / PACKAGES
addappid(618261, 1, "05532eb9eaa45282a485697b6494710ab313a9d42f5fac7e28cdda81b9296941")
