-- Lua provided by SkyAPI 
-- Game: journey of reincarnation
addappid(3001440)
addappid(3001441, 1, "adb09a749fbb84c559e5ab785fce5574cf9429be80d3d4854942fee87734a633")
