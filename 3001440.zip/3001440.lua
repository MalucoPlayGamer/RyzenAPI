-- Lua provided by RyzenAPI
-- Game: journey of reincarnation

-- MAIN APPLICATION
addappid(3001440)
-- Game: addappid(3001440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001441, 1, "adb09a749fbb84c559e5ab785fce5574cf9429be80d3d4854942fee87734a633")
