-- Lua provided by RyzenAPI
-- Game: Dungeon Village

-- MAIN APPLICATION
addappid(1859360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859361, 1, "2270d5a86ecd5f6f94a750b2e021e2fa860701209f0836a35b4520f4d083cb6e")
