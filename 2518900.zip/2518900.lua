-- Lua provided by RyzenAPI
-- Game: Manny's

-- MAIN APPLICATION
addappid(2518900)
-- Game: addappid(2518900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518901, 1, "828f96ef64926d3815299d144b15b6589b981135ff2a669b0d53124bacb62c7a")
