-- Lua provided by RyzenAPI
-- Game: 1101351

-- MAIN APPLICATION
addappid(1101351)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101351,0,"c64a0aa9c3b8df9e9f1a7affadd3873dc074dedd35223ef1a922e439383207d3")

