-- Lua provided by RyzenAPI
-- Game: addappid(2971850)

-- MAIN APPLICATION
addappid(2971850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971851, 1, "dc9b5a405dc9ff67e3a2a22781bff20fe1c626e8c36e3030ed6cdc65e8e9521c")
