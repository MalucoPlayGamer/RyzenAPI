-- Lua provided by SkyAPI 
-- Game: Vector Strain
addappid(419090)
addappid(419091, 1, "b7a43a4165406ccec438f28184c946c8066ac00f4ebc079d1896e8a98bcb54ff")
addappid(426220, 0, "560afe5ed436ded2d68c58a2cc06a032c46254100b25ffe8e9ae8545108ba5f8")
