-- Lua provided by RyzenAPI
-- Game: Vector Strain

-- MAIN APPLICATION
addappid(419090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(419091, 1, "b7a43a4165406ccec438f28184c946c8066ac00f4ebc079d1896e8a98bcb54ff")
addappid(426220, 0, "560afe5ed436ded2d68c58a2cc06a032c46254100b25ffe8e9ae8545108ba5f8")

