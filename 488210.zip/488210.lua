-- Lua provided by RyzenAPI
-- Game: 488210

-- MAIN APPLICATION
addappid(488210)
-- Game: addappid(488210)

-- MAIN APP DEPOTS / PACKAGES
addappid(488211, 1, "ba8554b5cebdd6c6f5f42e03abbe0a9bc31b2ab706d21a820f1624f6304600ec")
