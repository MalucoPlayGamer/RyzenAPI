-- Lua provided by RyzenAPI
-- Game: Drive Me Broke

-- MAIN APPLICATION
addappid(3958820) -- Drive Me Broke

-- MAIN APP DEPOTS / PACKAGES
addappid(3958821, 1, "120a83f410f4dc3b7c7fa658db74773d375db561e9b66494dfaf7e58cbc2b6eb") -- Depot 3958821

