-- 3958820's Lua and Manifest Created by Hubcap Manifest
-- Drive Me Broke
-- Created: August 21, 2026 at 15:59:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3958820) -- Drive Me Broke
-- MAIN APP DEPOTS
addappid(3958821, 1, "120a83f410f4dc3b7c7fa658db74773d375db561e9b66494dfaf7e58cbc2b6eb") -- Depot 3958821
setManifestid(3958821, "2904175509294118918", 6691863870)