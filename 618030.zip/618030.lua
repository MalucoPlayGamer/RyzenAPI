-- Lua provided by RyzenAPI
-- Game: Game: AppID 618030

-- MAIN APPLICATION
addappid(618030)
-- Game: addappid(618030)

-- MAIN APP DEPOTS / PACKAGES
addappid(618031, 1, "18018b4d93749ea29c2d4ee969107d90d15244049358e97cf9b0a87573c3ba80")
