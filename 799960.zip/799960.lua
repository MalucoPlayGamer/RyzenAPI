-- Lua provided by RyzenAPI
-- Game: Game: Wizard101

-- MAIN APPLICATION
addappid(799960)
-- Game: addappid(799960)

-- MAIN APP DEPOTS / PACKAGES
addappid(799961, 1, "93413f2290547916282f0371457d5d5e7ec49a446bc419efe75b9ec28558756a")
