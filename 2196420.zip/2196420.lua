-- Lua provided by RyzenAPI
-- Game: Game: OnlyFap Simulator  4 💦

-- MAIN APPLICATION
addappid(2196420)
-- Game: addappid(2196420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196421, 1, "e1ae95cd550c7f0786dfdd96787dbc3cfeec20c990f4bfbaa55b089abc29108f")
