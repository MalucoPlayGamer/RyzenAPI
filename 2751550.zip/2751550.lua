-- Lua provided by RyzenAPI
-- Game: Game: Beat the Beats VR Demo

-- MAIN APPLICATION
addappid(2751550)
-- Game: addappid(2751550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751551, 1, "0f710e4d2f30bcb783b828681d66816dc18d5758fc14048919157304b8e23d3e")
