-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Danger on Deception Island

-- MAIN APPLICATION
addappid(31840)

-- MAIN APP DEPOTS / PACKAGES
addappid(31841, 1, "7aad008b201eb24adcaf51e96518fa1b6ddf487dc1ec857070ce34962d450e55")
