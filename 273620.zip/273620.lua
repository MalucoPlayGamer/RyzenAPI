-- Lua provided by RyzenAPI
-- Game: AppID 273620

-- MAIN APPLICATION
addappid(273620)

-- MAIN APP DEPOTS / PACKAGES
addappid(273621, 1, "2c655766985ffab7115ed08a374b9e33a5fce4afc6fd8b042101b213a0b29ecd")
