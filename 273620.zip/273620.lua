-- Lua provided by RyzenAPI
-- Game: AppID 273620

-- MAIN APPLICATION
addappid(273620)

-- MAIN APP DEPOTS / PACKAGES
addappid(273621, 1, "2c655766985ffab7115ed08a374b9e33a5fce4afc6fd8b042101b213a0b29ecd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
