-- Lua provided by RyzenAPI
-- Game: 1179010

-- MAIN APPLICATION
addappid(1179010)
-- Game: addappid(1179010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179011, 1, "e767701660e25d3968fa14ab9e5ff6da8d546fedadf34295071692e6cd355c2c")
