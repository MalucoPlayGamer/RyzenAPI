-- Lua provided by RyzenAPI
-- Game: The Guild 3 Soundtrack

-- MAIN APPLICATION
addappid(2022710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022711, 1, "0f42d35264a5c6dc0ff4316835d3ee1de36ed7d82f79da39dd5bba8caddbdb11")
addappid(2022712, 1, "eb0b8887d330c991182bf949b3bbc2a848aeccdb72024953222e06e149d449fc")
