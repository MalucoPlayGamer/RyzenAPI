-- Lua provided by RyzenAPI
-- Game: addappid(2156070)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2156070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156072,0,"706e43893c326767aadc2ae2954f896bb06442e45214f69bbba4a1d611f5a6fc")
addappid(2156074,0,"62fb4b426294a29e905c427a67aad529c18340b8b45dcbf2e9ea917615294acf")
