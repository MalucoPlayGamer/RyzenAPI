-- Lua provided by RyzenAPI
-- Game: 1686430

-- MAIN APPLICATION
addappid(1686430)
-- Game: addappid(1686430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686431, 1, "632774f34a8e9a1fe25aa948a9eb033e121fec74ce56ee5efd70cd1292d7a491")
