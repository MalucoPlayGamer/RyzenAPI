-- Lua provided by RyzenAPI
-- Game: addappid(1031920)

-- MAIN APPLICATION
addappid(228986)
addappid(228987)
addappid(228990)
addappid(1031920)
addappid(1031923)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031922,0,"c16876cab1f67d21b00f0ef5221c9be44e7232725008c185f3715a1a12dd53fd")
addappid(1216640,0,"e33f0c68a04c922d487470fc31e9941bb5e7b40a8b34796ae8aa6e8786f3a283")
