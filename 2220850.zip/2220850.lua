-- Lua provided by RyzenAPI
-- Game: Factor Y

-- MAIN APPLICATION
addappid(2220850)
-- Game: addappid(2220850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220851, 1, "acb39ef1cd7e8b47661d06aa130f01fa3077ad26e8bf530d69cf07a3bce6a86c")
