-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2

-- MAIN APPLICATION
addappid(2928600)
addappid(3371870)
addappid(3371880)
addappid(3371890)
addappid(3371900)
addappid(3371910)
addappid(3900330)
addappid(4010480)
addappid(4010490)
addappid(4010500)
addappid(4010510)
addappid(4010530)
addappid(4010540)
addappid(4010560)
-- Game: addappid(2928600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928601, 1, "486448df6cd95d0d663ae6dbc0dc5cb7ed590875a2a7481fee25ffe7572b60fc")
addappid(2928602, 1, "76573f4e73223ad90162699e12cab632fe18a64d6ff74dfd5fefee3383a8f20b")
addappid(3653840, 0, "98e43fa413cbb9b5ae52de2d277b986fa7456efd3d26154adf627954cd6f2fca")
