-- Lua provided by RyzenAPI 
-- Game: Data Hacker: Initiation
addappid(311860)
addappid(311861, 1, "fc76e4660fbac88fa2baa81ee53bf4c3f4a6f2bbea74bd42cdbc1f0b2a850afb")
addappid(340661, 0, "17ea499d61ed126e8495c0d7f0011cd523e6399b7cc549dcfe04039db929447a")
