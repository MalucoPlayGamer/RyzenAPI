-- Lua provided by RyzenAPI
-- Game: Casino Slot Machines

-- MAIN APPLICATION
addappid(769150)

-- MAIN APP DEPOTS / PACKAGES
addappid(769151, 1, "f5360ac2bf447f35327393878868d409a61f50e3cb56e6d796aeb7509308f07d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(770030)
addappid(773280)
addappid(774431)
addappid(776420)
