-- Lua provided by SkyAPI 
-- Game: Casino Slot Machines
addappid(769150)
addappid(769151, 1, "f5360ac2bf447f35327393878868d409a61f50e3cb56e6d796aeb7509308f07d")
