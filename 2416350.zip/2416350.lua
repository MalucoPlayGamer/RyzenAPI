-- Lua provided by RyzenAPI 
-- Game: Yard Sale Simulator
addappid(2416350)
addappid(2416351, 1, "b8d7213d8e8911e8aade4c08851047c07ca5b9c1b99bba29555f5ea241c29a1f")
