-- Lua provided by RyzenAPI
-- Game: Yard Sale Simulator

-- MAIN APPLICATION
addappid(2416350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416351, 1, "b8d7213d8e8911e8aade4c08851047c07ca5b9c1b99bba29555f5ea241c29a1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
