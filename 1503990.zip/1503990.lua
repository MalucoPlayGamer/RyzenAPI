-- Lua provided by RyzenAPI
-- Game: Tomorrow

-- MAIN APPLICATION
addappid(1503990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503991, 1, "a5568c1f1fad3e5bf03260f224bbcdcf6373a004556095b5984518d79b90940e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
