-- Lua provided by RyzenAPI
-- Game: Tomorrow

-- MAIN APPLICATION
addappid(1503990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503991, 1, "a5568c1f1fad3e5bf03260f224bbcdcf6373a004556095b5984518d79b90940e")

