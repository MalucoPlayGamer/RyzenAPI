-- Lua provided by RyzenAPI
-- Game: Lonely Trip

-- MAIN APPLICATION
addappid(781490)
-- Game: addappid(781490)

-- MAIN APP DEPOTS / PACKAGES
addappid(781491, 1, "a60af32467e7f732f2d05a194317af35248065984d77c720f020e1ff0a812361")
