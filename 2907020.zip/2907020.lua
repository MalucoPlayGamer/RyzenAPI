-- Lua provided by SkyAPI 
-- Game: AppID 2907020
addappid(2907020)
addappid(2907021, 1, "56c574c60e2f0b4d4408e0c443d83cf055844d4c8ea6503b9750db337793f435")
