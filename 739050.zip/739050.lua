-- Lua provided by RyzenAPI
-- Game: Deck Casters

-- MAIN APPLICATION
addappid(739050)

-- MAIN APP DEPOTS / PACKAGES
addappid(739051,0,"dc4952b7c7b21cb1c5828b0ba26c5120398567d4639937ff36407a362abc6aca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
