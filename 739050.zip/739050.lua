-- Lua provided by RyzenAPI
-- Game: Deck Casters

-- MAIN APPLICATION
addappid(739050)

-- MAIN APP DEPOTS / PACKAGES
addappid(739051,0,"dc4952b7c7b21cb1c5828b0ba26c5120398567d4639937ff36407a362abc6aca")

