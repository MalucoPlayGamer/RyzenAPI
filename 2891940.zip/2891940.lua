-- Lua provided by RyzenAPI
-- Game: Who's Next?

-- MAIN APPLICATION
addappid(2891940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891941, 1, "48bfe4096541a7d81a219e3bf86ef8c79478d368044cae9513896eccfb747ded")
