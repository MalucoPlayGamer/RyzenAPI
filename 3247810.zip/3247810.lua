-- Lua provided by RyzenAPI
-- Game: Game: AppID 3247810

-- MAIN APPLICATION
addappid(3247810)
-- Game: addappid(3247810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247811, 1, "b2b601b94ab5659531183238f1ac82ce243bbf670aa8ced08c941f92b5fb8919")
