-- Lua provided by RyzenAPI
-- Game: Construction Machines 2014

-- MAIN APPLICATION
addappid(252050)
-- Game: addappid(252050)

-- MAIN APP DEPOTS / PACKAGES
addappid(252051, 1, "a2c2b2a9db36caf37415fa16e7310bd24de64ca68afcef18710778ad3cb72a71")
