-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2500440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500442,0,"1a4790b180b1f2bdb850d9963c0d356de074e43fdc4443a7f97c8bf8521eefc9")
addappid(2500443,0,"f90f024e6d09a579e0454fef032ddcda495bd40305c1a368d4ab6a11e712c06f")
