-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2500440)
addappid(2500442,0,"1a4790b180b1f2bdb850d9963c0d356de074e43fdc4443a7f97c8bf8521eefc9")
-- setManifestid(2500442,"4763232738926203757")
addappid(2500443,0,"f90f024e6d09a579e0454fef032ddcda495bd40305c1a368d4ab6a11e712c06f")
-- setManifestid(2500443,"5751783119779533621")