-- Lua provided by RyzenAPI
-- Game: Game: Mars Vice

-- MAIN APPLICATION
addappid(1886910)
-- Game: addappid(1886910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886911, 1, "dd7327291b283d214db5b8ce4e69d190bd8b32d5408d078a3ec6325381141a03")
