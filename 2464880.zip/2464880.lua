-- Lua provided by RyzenAPI
-- Game: Game: Terracards

-- MAIN APPLICATION
addappid(2464880)
-- Game: addappid(2464880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464881, 1, "91424f13adfba8b074c0b01236fa944ec741e7db7536b891216f731e23496d78")
addappid(2464882, 1, "8f73dd0cbf52ed8380b57d6c67f1a1bd9034836dfaaab303901a74e5f7d2d750")
