-- Lua provided by RyzenAPI
-- Game: Meng Huo - Officer Ticket / 孟獲使用券

-- MAIN APPLICATION
addappid(956767)
-- Game: addappid(956767)

-- MAIN APP DEPOTS / PACKAGES
addappid(956767,0,"a7deea0f66bc85053f33fd4d0d3b72de79bf02cc0bc169eb388f8edcdbcc7c51")
