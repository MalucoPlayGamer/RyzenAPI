-- Lua provided by RyzenAPI
-- Game: B1

-- MAIN APPLICATION
addappid(2806940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806941, 1, "d9321af1c9d91fd671e66554d30d9d9db0db8a6470b2d4a0689a6424ffeaa5d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
