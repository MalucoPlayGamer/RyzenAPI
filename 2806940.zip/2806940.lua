-- Lua provided by RyzenAPI
-- Game: B1

-- MAIN APPLICATION
addappid(2806940)
-- Game: addappid(2806940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806941, 1, "d9321af1c9d91fd671e66554d30d9d9db0db8a6470b2d4a0689a6424ffeaa5d6")
