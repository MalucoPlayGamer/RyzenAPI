-- Lua provided by RyzenAPI
-- Game: Game: Tower Factory Demo

-- MAIN APPLICATION
addappid(2954120)
-- Game: addappid(2954120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954121, 1, "b7751e623740c2f3145f65fbd114d53cc6189ccec19da126d77a965c4b69c800")
