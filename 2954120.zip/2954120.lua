-- Lua provided by RyzenAPI 
-- Game: Tower Factory Demo
addappid(2954120)
addappid(2954121, 1, "b7751e623740c2f3145f65fbd114d53cc6189ccec19da126d77a965c4b69c800")
