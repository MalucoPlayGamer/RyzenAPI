-- Lua provided by RyzenAPI
-- Game: AppID 989060

-- MAIN APPLICATION
addappid(989060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(989061, 1, "8c7cf9cd1361e2facafba2f2e7a0d7bb73c5dc781ac43f8b3802c1b2ccccbb1a")

