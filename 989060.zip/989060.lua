-- Lua provided by RyzenAPI
-- Game: Virtual Home Theater VR Video Player

-- MAIN APPLICATION
addappid(989060)
-- Game: addappid(989060)

-- MAIN APP DEPOTS / PACKAGES
addappid(989061, 1, "8c7cf9cd1361e2facafba2f2e7a0d7bb73c5dc781ac43f8b3802c1b2ccccbb1a")
