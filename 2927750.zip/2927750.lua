-- Lua provided by RyzenAPI
-- Game: Vector Bias Playtest

-- MAIN APPLICATION
addappid(2927750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927751, 1, "5992aa677de63632774dc6c1cd6b5b5f580371d49b414c18f9a4442a6a294c5e")

