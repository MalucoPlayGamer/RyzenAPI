-- Lua provided by RyzenAPI
-- Game: Malware

-- MAIN APPLICATION
addappid(3019370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(3019371, 1, "bd2da71d2e560a74afbc6465486249437f3649c9ba83f7cf03844fd47d88ea6b")

