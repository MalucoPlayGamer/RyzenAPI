-- Lua provided by RyzenAPI
-- Game: Game: Malware

-- MAIN APPLICATION
addappid(3019370)
-- Game: addappid(3019370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019371, 1, "bd2da71d2e560a74afbc6465486249437f3649c9ba83f7cf03844fd47d88ea6b")
