-- 4347620's Lua and Manifest Created by Hubcap Manifest
-- Risen Blade
-- Created: July 20, 2026 at 12:43:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4347620) -- Risen Blade
-- MAIN APP DEPOTS
addappid(4347621, 1, "e94fa9dfa37098c86fdc42e5107fc0917abb5d5605ef286bd784c911a065d3e6") -- Depot 4347621
setManifestid(4347621, "6989861026307082112", 551735654)