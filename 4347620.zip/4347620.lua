-- Lua provided by RyzenAPI
-- Game: Risen Blade

-- MAIN APPLICATION
addappid(4347620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4347621,0,"e94fa9dfa37098c86fdc42e5107fc0917abb5d5605ef286bd784c911a065d3e6")

