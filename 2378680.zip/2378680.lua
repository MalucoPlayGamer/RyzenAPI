-- Lua provided by RyzenAPI
-- Game: Sonic Superstars - Comic Book Skin Pack

-- MAIN APPLICATION
addappid(2378680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378680,0,"ceb1ec12c9e4865ad35f179ba80e76726cac61d5b9b47c7aa40c2209575e76e3")

