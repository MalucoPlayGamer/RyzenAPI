-- Lua provided by RyzenAPI
-- Game: 8030

-- MAIN APPLICATION
addappid(8030)
-- Game: addappid(8030)

-- MAIN APP DEPOTS / PACKAGES
addappid(8031, 1, "8b233799de90a7d620bb0441bad2bc20427fd7f752403e83da34c947df3bf2c9")
