-- Lua provided by RyzenAPI
-- Game: Auto Dealership Tycoon

-- MAIN APPLICATION
addappid(393920)

-- MAIN APP DEPOTS / PACKAGES
addappid(393921, 1, "6e6df16950e616e4a22684f6ad5869653300a11d3d4b8a2e5235a099adba9032")
