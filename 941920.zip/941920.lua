-- Lua provided by RyzenAPI
-- Game: Classic Card Games 3D

-- MAIN APPLICATION
addappid(941920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(941921, 1, "7fb6165afa92b9076dbbc341db50dfb96af3a5169992c4dc77652a284ade0bcc")

