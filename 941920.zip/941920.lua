-- Lua provided by RyzenAPI
-- Game: Game: Classic Card Games 3D

-- MAIN APPLICATION
addappid(941920)
-- Game: addappid(941920)

-- MAIN APP DEPOTS / PACKAGES
addappid(941921, 1, "7fb6165afa92b9076dbbc341db50dfb96af3a5169992c4dc77652a284ade0bcc")
