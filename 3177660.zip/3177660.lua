-- Lua provided by RyzenAPI
-- Game: Victim 10 PM

-- MAIN APPLICATION
addappid(3177660)
-- Game: addappid(3177660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177661, 1, "fdc9a689de30fee799272910bf3da489b7478095483a04bda34b3933487422dc")
