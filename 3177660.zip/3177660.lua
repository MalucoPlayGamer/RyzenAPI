-- Lua provided by RyzenAPI
-- Game: Victim 10 PM

-- MAIN APPLICATION
addappid(3177660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3177661, 1, "fdc9a689de30fee799272910bf3da489b7478095483a04bda34b3933487422dc")

