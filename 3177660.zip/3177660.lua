-- Lua provided by RyzenAPI
-- Game: addappid(3177660)

-- MAIN APPLICATION
addappid(3177660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177661, 1, "fdc9a689de30fee799272910bf3da489b7478095483a04bda34b3933487422dc")
