-- Lua provided by RyzenAPI 
-- Game: AppID 1509950
addappid(1509950)
addappid(1509951, 1, "693d9ef9070a6f9c4652b81e357034230e4e73ba4188d975157252c38994f22f")
