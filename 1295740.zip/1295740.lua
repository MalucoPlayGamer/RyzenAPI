-- Lua provided by RyzenAPI
-- Game: Mine Dungeon2 ~Rurumu's trip~

-- MAIN APPLICATION
addappid(1295740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295741, 1, "5926c8bd1c27aa544481c9cfd5eaab297d98a0e1f9226cfaade27ece146ae28c")

