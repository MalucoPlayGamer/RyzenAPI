-- Lua provided by RyzenAPI
-- Game: 1295740

-- MAIN APPLICATION
addappid(1295740)
-- Game: addappid(1295740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295741, 1, "5926c8bd1c27aa544481c9cfd5eaab297d98a0e1f9226cfaade27ece146ae28c")
