-- Lua provided by RyzenAPI
-- Game: AppID 1189250

-- MAIN APPLICATION
addappid(1189250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1189251, 1, "bde9e219909ba91b55e56a0b58288f965eaf422367ad0b29c88e5760055aa02e")

