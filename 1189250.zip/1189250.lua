-- Lua provided by RyzenAPI
-- Game: 1189250

-- MAIN APPLICATION
addappid(1189250)
-- Game: addappid(1189250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189251, 1, "bde9e219909ba91b55e56a0b58288f965eaf422367ad0b29c88e5760055aa02e")
