-- Lua provided by RyzenAPI
-- Game: 2339980

-- MAIN APPLICATION
addappid(2339980)
-- Game: addappid(2339980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339981, 1, "fc35a26b6033f8d1a9af825d3337db1bf3b88aa7585e585347c64385daac4eda")
