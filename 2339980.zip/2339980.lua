-- Lua provided by SkyAPI 
-- Game: EPOCHRYPHA
addappid(2339980)
addappid(2339981, 1, "fc35a26b6033f8d1a9af825d3337db1bf3b88aa7585e585347c64385daac4eda")
