-- Lua provided by RyzenAPI
-- Game: addappid(2337940)

-- MAIN APPLICATION
addappid(2337940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337941, 1, "7fdda7b338460979351e2fcfa746bd8fa6be9848ab210188ca4b6b0e66a1bf4d")
