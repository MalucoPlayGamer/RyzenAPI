-- Lua provided by SkyAPI 
-- Game: War of Wheels
addappid(2337940)
addappid(2337941, 1, "7fdda7b338460979351e2fcfa746bd8fa6be9848ab210188ca4b6b0e66a1bf4d")
