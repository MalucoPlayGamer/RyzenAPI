-- Lua provided by RyzenAPI
-- Game: Luxury Hotel Emporium

-- MAIN APPLICATION
addappid(389680)

-- MAIN APP DEPOTS / PACKAGES
addappid(389681, 1, "3c930bd63d1013d99c2b114f842e4938b6a6a4be718a403384c57e69ec1f407e")
addappid(389682, 1, "288ec0bea8934303c28d91a64872ae0603d0f9a42cf661342e607fc1afcca742")
addappid(389683, 1, "39d943b057b1d3c4e4af076b28a7662bf11155a4c785003b315c232ee9dcedeb")
addappid(389684, 1, "a9783aba64f06a6113c3b5662c415efd65522e5d59d0645e5a63503f37d863a2")
addappid(389685, 1, "b76262b427d86d7cca4149a32176e61872a72c2d2273fc935ff7d924ba1d56af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
