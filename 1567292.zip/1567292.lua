-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Pioneers of Olive Town - Fox Costume

-- MAIN APPLICATION
addappid(1567292)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567292,0,"883865e1f6436d2e6c7d7961ca1f63d5cb36e9209e3026781236d55f18961216")
