-- Lua provided by RyzenAPI
-- Game: Bonus Costumes for Xu Shu and Mitsunari Ishida and Da Ji

-- MAIN APPLICATION
addappid(933471)

-- MAIN APP DEPOTS / PACKAGES
addappid(933471,0,"3f81a963655b415c0d1293437157d1b9203bfe6621af74599b0aa2bce3b74300")
addtoken(933471,16837142266219510621)
