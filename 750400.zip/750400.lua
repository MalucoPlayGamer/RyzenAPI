-- Lua provided by RyzenAPI
-- Game: Two Inns at Miller's Hollow

-- MAIN APPLICATION
addappid(750400)

-- MAIN APP DEPOTS / PACKAGES
addappid(750401, 1, "bfae0bcbd6120e43059527c820fe58c493a8f83dff8b10f00c06504141b8f47d")
addappid(750402, 1, "7ea699b9d767afee1c7c40f70704e77b401da7f898910d0b1d3463ddd0a8eabf")
addappid(750403, 1, "f3be6af15e8f9174b7f192dd1ddab78bd8c73b49d97cd789684f6c80d7ee2b7a")
