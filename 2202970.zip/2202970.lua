-- Lua provided by RyzenAPI
-- Game: Soulstone Survivors Soundtrack

-- MAIN APPLICATION
addappid(2202970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202971, 1, "24dfa913ef98f7a717ab6d92810425568b7d3276c92dc8a44b5b536d113870c8")
addappid(2202972, 1, "ca1803ea4dd9dca3fd1365bb07a33e3feb0f69088c2b9c7b7b0913d636e4d7c1")
