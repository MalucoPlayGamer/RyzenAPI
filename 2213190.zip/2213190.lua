-- Lua provided by SkyAPI 
-- Game: DEATH NOTE Killer Within
addappid(2213190)
addappid(2213191, 1, "3b495753bf48e7803ff65df07e33617fafd8b3c45399248e31402c428eb5bd51")
addappid(2213193, 1, "c5e9e769e3787b9327bff56ba92f034ea16b02a1e16ed00279fe5958bb5776f9")
