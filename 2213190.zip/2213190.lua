-- Lua provided by RyzenAPI
-- Game: DEATH NOTE Killer Within

-- MAIN APPLICATION
addappid(2213190)
addappid(2950900)
addappid(2950910)
addappid(2950920)
addappid(2950930)
addappid(2950940)
addappid(2950950)
addappid(2950960)
addappid(2950970)
addappid(2950980)
addappid(2950990)
addappid(2951000)
addappid(2951010)
addappid(2951020)
addappid(2951030)
addappid(2951040)
addappid(2951050)
addappid(2951060)
addappid(2951070)
addappid(2951080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213191, 1, "3b495753bf48e7803ff65df07e33617fafd8b3c45399248e31402c428eb5bd51")
addappid(2213193, 1, "c5e9e769e3787b9327bff56ba92f034ea16b02a1e16ed00279fe5958bb5776f9")

