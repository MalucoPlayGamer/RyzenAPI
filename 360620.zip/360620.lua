-- Lua provided by RyzenAPI
-- Game: AppID 360620

-- MAIN APPLICATION
addappid(360620)
addappid(821710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(360621, 1, "07fe9417d1ec3621e9ca241bf9faefbd0dce70c65ef32cdb70921b4c420f6b15")
addappid(360622, 1, "aeb26bc69164d5402c6074e1b596aaa3c2442558c117970d3b32058c81ed4687")

