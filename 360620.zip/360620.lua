-- Lua provided by RyzenAPI
-- Game: 360620

-- MAIN APPLICATION
addappid(360620)
addappid(821710)
-- Game: addappid(360620)

-- MAIN APP DEPOTS / PACKAGES
addappid(360621, 1, "07fe9417d1ec3621e9ca241bf9faefbd0dce70c65ef32cdb70921b4c420f6b15")
addappid(360622, 1, "aeb26bc69164d5402c6074e1b596aaa3c2442558c117970d3b32058c81ed4687")
