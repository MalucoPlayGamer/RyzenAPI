-- Lua provided by RyzenAPI
-- Game: Jones On Fire

-- MAIN APPLICATION
addappid(270810)

-- MAIN APP DEPOTS / PACKAGES
addappid(270811, 1, "69842a2e639341305383934fa50f5be5115ed4ea110216624d09f30043b39a26")
addappid(270812, 1, "a8f8119f3b78a4eebdc7c9e131cd7a77d255cb07d0d1657430a9a4e37c469e4f")
addappid(350260, 0, "4ebc08f87a74186163291389230216f0b2d48fcdc9017e9af6fc23defea61e1b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
