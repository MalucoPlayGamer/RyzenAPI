-- Lua provided by RyzenAPI
-- Game: Tornuffalo

-- MAIN APPLICATION
addappid(534720)
-- Game: addappid(534720)

-- MAIN APP DEPOTS / PACKAGES
addappid(534721, 1, "032635a47bf4373636b8031ff19fd80147496d3165f13487b19ad2c1149c99f2")
