-- Lua provided by RyzenAPI
-- Game: Game: The Last Hearth Defense

-- MAIN APPLICATION
addappid(3765800)
-- Game: addappid(3765800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765801, 1, "252220e534e20779ff0d454ac87ecb8fc64dd15800bce548e41b9a1977d93fc3")
