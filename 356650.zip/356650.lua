-- Lua provided by RyzenAPI
-- Game: Death's Gambit: Afterlife

-- MAIN APPLICATION
addappid(356650)

-- MAIN APP DEPOTS / PACKAGES
addappid(356651, 1, "afb4667b94de2a5fd4536832eb46e832fa05c3c63c9711e242473e930a07505b")

