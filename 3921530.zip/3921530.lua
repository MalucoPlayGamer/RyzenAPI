-- Lua provided by RyzenAPI
-- Game: addappid(3921530)

-- MAIN APPLICATION
addappid(3921530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3921531, 1, "920d806b182801b15deb3c76ca1153c2ad06781366220f6a0cdbddc422f9def4")
