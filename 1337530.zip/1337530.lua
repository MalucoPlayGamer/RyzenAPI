-- Lua provided by RyzenAPI
-- Game: Maskmaker

-- MAIN APPLICATION
addappid(1337530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337531, 1, "90516b0097b0df0df5c1dd034a491bb2d31d2565e60acb3dc32380242ab45c98")
