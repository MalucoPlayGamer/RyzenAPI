-- Lua provided by RyzenAPI
-- Game: Maskmaker

-- MAIN APPLICATION
addappid(1337530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1337531, 1, "90516b0097b0df0df5c1dd034a491bb2d31d2565e60acb3dc32380242ab45c98")

