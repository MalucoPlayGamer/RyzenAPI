-- Lua provided by SkyAPI 
-- Game: Maskmaker
addappid(1337530)
addappid(1337531, 1, "90516b0097b0df0df5c1dd034a491bb2d31d2565e60acb3dc32380242ab45c98")
