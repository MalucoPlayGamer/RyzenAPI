-- Lua provided by RyzenAPI
-- Game: Blasphemous 2

-- MAIN APPLICATION
addappid(2114740)
addappid(2879370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114741, 1, "bfa23044329db73bff7359d046baad4e5d546333e7c34042a0065de17eb5350e")
addappid(2114742, 1, "a0950a724a09a3bc1a126e4543d910aafa0e83727704db0fd11745547ea0bd66")
addappid(2500160, 0, "503b5732abefe07001d4c001350558da4747a61c52562da4882858a9e2be2235")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
