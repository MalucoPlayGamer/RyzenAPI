-- Lua provided by RyzenAPI
-- Game: Tokyo Twilight Ghost Hunters Daybreak: Special Gigs

-- MAIN APPLICATION
addappid(425460)

-- MAIN APP DEPOTS / PACKAGES
addappid(425461, 1, "9f2078685e69873889c47bd0c6b2583ebc3e5a965a78a548cb4f7be3b1e5f135")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
