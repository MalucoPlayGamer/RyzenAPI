-- Lua provided by RyzenAPI
-- Game: addappid(425460)

-- MAIN APPLICATION
addappid(425460)

-- MAIN APP DEPOTS / PACKAGES
addappid(425461, 1, "9f2078685e69873889c47bd0c6b2583ebc3e5a965a78a548cb4f7be3b1e5f135")
