-- Lua provided by RyzenAPI
-- Game: AppID 406150

-- MAIN APPLICATION
addappid(406150)

-- MAIN APP DEPOTS / PACKAGES
addappid(406151, 1, "8e171d9013708d30c9f7dd79e637cb8901e091b14d0e7873f0c04312e3ecc5c9")
addappid(406152, 1, "a5628228419f7a726e1120951f995c48d76cfbb5796f7161afbbf1af646e7f6b")
addappid(406153, 1, "a68164d805573cf502d02421e0068884e4730fd1950c995ca362f7bd8a1538a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
