-- Lua provided by RyzenAPI
-- Game: AppID 907250

-- MAIN APPLICATION
addappid(907250)

-- MAIN APP DEPOTS / PACKAGES
addappid(907251, 1, "672309d259dd4c36392779fccf46f281045ce3fc962d6cd9d2face1f24e26d69")

