-- Lua provided by RyzenAPI
-- Game: Magika Land of Fantasy

-- MAIN APPLICATION
addappid(822110)

-- MAIN APP DEPOTS / PACKAGES
addappid(822111, 1, "5a477993d0828797bf2456c2628072cf19e927aa0bf49a7f3c7f472d8af7c569")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
