-- Lua provided by RyzenAPI
-- Game: AppID 250340

-- MAIN APPLICATION
addappid(250340)
-- Game: addappid(250340)

-- MAIN APP DEPOTS / PACKAGES
addappid(250341, 1, "23efc780450afddf72933fbc028fd382408bdc2e3af0e6f15e4addbe73aa2ec0")
addappid(250342, 1, "ec787074459cb0a9e328f99420d5ae1cc5399a40ff7e560bd1b988089fa1943c")
