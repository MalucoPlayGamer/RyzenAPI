-- Lua provided by RyzenAPI
-- Game: Blockland

-- MAIN APPLICATION
addappid(250340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(250341, 1, "23efc780450afddf72933fbc028fd382408bdc2e3af0e6f15e4addbe73aa2ec0")
addappid(250342, 1, "ec787074459cb0a9e328f99420d5ae1cc5399a40ff7e560bd1b988089fa1943c")

