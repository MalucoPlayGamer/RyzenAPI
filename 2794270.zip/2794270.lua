-- Lua provided by RyzenAPI
-- Game: Evercore Heroes: Ascension Demo

-- MAIN APPLICATION
addappid(2794270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794272,0,"510bb3c302721ed0803b4d671e5b8a51671b3275f33616368f28e1f53e440a11")

