-- Lua provided by RyzenAPI
-- Game: Game: AppID 827670

-- MAIN APPLICATION
addappid(827670)
-- Game: addappid(827670)

-- MAIN APP DEPOTS / PACKAGES
addappid(827671, 1, "5fb7c61f5aeab0758aece154ac6809c16c980a8fec49623aa70ab1aa799586e5")
addappid(827672, 1, "19520fc92ab9f9a5e1e8cc45eb22551f61e0ffc2ee0994a515c4defe684da543")
addappid(827673, 1, "941174b10ec0d4171f70a1a8a1a54de267f0ce76a15f0e0a673b5b9426d31fd7")
addappid(827674, 1, "68c6c7a9d005d38da340a2dc52585e607e23b3cc88414e0cb0f2759d07720f45")
