-- Lua provided by RyzenAPI
-- Game: Game: Psychomachia

-- MAIN APPLICATION
addappid(2879800)
addappid(3215550)
-- Game: addappid(2879800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879801, 1, "818fd620ee1766018d61fcc278977a3a211f59b593d6a616e551577f93417673")
