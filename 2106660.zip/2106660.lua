-- Lua provided by RyzenAPI
-- Game: Game: AppID 2106660

-- MAIN APPLICATION
addappid(2106660)
-- Game: addappid(2106660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106661, 1, "74c7c9e7528d8fe24cd54b08dbfe4d5dc7452a2efca81741d2317763c7f72734")
