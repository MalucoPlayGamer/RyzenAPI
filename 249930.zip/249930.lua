-- Lua provided by RyzenAPI
-- Game: A-Train 8

-- MAIN APPLICATION
addappid(249930)

-- MAIN APP DEPOTS / PACKAGES
addappid(249931, 1, "e6fe5dba9f31eb95867f3b17b53b063a82c476c32f700e6f8d11ae9c0d2eec1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
