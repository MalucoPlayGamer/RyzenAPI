-- Lua provided by RyzenAPI
-- Game: A-Train 8

-- MAIN APPLICATION
addappid(249930)

-- MAIN APP DEPOTS / PACKAGES
addappid(249931, 1, "e6fe5dba9f31eb95867f3b17b53b063a82c476c32f700e6f8d11ae9c0d2eec1d")
