-- Lua provided by RyzenAPI
-- Game: addappid(611950)

-- MAIN APPLICATION
addappid(611950)

-- MAIN APP DEPOTS / PACKAGES
addappid(611951, 1, "2e370d896d4223ecb3971655421b8fd106e4863a2d3db9ce9620e1ae80917daa")
