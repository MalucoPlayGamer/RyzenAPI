-- Lua provided by SkyAPI 
-- Game: AppID 453390
addappid(453390)
addappid(453391, 1, "af937cf12305470a671cf86fb6f7cec09c26d1121003683b0a24f93fae81dd04")
