-- Lua provided by RyzenAPI
-- Game: AppID 1240230

-- MAIN APPLICATION
addappid(1240230)
addappid(1241850)
addappid(1241851)
addappid(1241852)
addappid(1255490)
addappid(1286960)
-- Game: addappid(1240230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240231, 1, "686727eeb3e6829bad491ae6285fadff109d3f7ff034e4b2f2760a0b69c798a1")
