-- Lua provided by RyzenAPI
-- Game: AppID 1706160

-- MAIN APPLICATION
addappid(1706160)
-- Game: addappid(1706160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706161, 1, "75912e54935f4d73ac24f5f168c96ff4ac0c04e807ae79caa2563185a44d818c")
