-- Lua provided by RyzenAPI 
-- Game: Mafia: Definitive Edition
addappid(1030840)
addappid(1030841, 1, "d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64")
addappid(1316300, 0, "724c017202bf35f19f8cdbbec2e6a859a2d88b805b1abe089d4d8a329b318471")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
