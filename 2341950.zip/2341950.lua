-- Lua provided by RyzenAPI
-- Game: 神灵石之劫 Tales of Spark Playtest

-- MAIN APPLICATION
addappid(2341950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341951, 1, "a4752a6b5c73942c3f0204ab8e6453c128ad70c049a20a17d86e4222b9d41617")
