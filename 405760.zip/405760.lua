-- Lua provided by SkyAPI 
-- Game: AppID 405760
addappid(405760)
addappid(405761, 1, "b4a677a36bd10498ece405c4e5406c1c64894036acb1ff572339bbac881abc89")
