-- Lua provided by RyzenAPI
-- Game: Robot Squad Simulator 2017

-- MAIN APPLICATION
addappid(405760)

-- MAIN APP DEPOTS / PACKAGES
addappid(405761, 1, "b4a677a36bd10498ece405c4e5406c1c64894036acb1ff572339bbac881abc89")
