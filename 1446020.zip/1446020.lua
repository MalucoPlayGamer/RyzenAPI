-- Lua provided by RyzenAPI
-- Game: MADNESS: Project Nexus Demo

-- MAIN APPLICATION
addappid(1446020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446021, 1, "a3537024a8bcc1bf0b7269533df6bc2b2b0a793c405337a2ba0a8e002765f242")

