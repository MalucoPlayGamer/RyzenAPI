-- Lua provided by RyzenAPI
-- Game: AppID 2514640

-- MAIN APPLICATION
addappid(2514640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514641, 1, "db6c56ca9e0b51b7268a366ffe118404c0adede207436b8e144d12cd212545c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3405060)
addappid(3596270)
