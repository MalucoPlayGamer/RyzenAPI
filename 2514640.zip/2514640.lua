-- Lua provided by SkyAPI 
-- Game: AppID 2514640
addappid(2514640)
addappid(2514641, 1, "db6c56ca9e0b51b7268a366ffe118404c0adede207436b8e144d12cd212545c0")
