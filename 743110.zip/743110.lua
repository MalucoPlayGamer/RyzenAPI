-- Lua provided by RyzenAPI
-- Game: Shit Storm

-- MAIN APPLICATION
addappid(743110)

-- MAIN APP DEPOTS / PACKAGES
addappid(743111, 1, "a548dc4d32b257b6680258037a20a5113a2e0c0fb9d090508b7b444eac35cfcf")

