-- Lua provided by RyzenAPI
-- Game: AI CG Generation Engine

-- MAIN APPLICATION
addappid(1881520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881521, 1, "15ca0e38c4c41a2fbebbbfa5015201228bbc1ccbf75dfe2741e053887ed75302")

