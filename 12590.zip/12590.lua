-- Lua provided by RyzenAPI
-- Game: 12590

-- MAIN APPLICATION
addappid(12590)
-- Game: addappid(12590)

-- MAIN APP DEPOTS / PACKAGES
addappid(12591, 1, "0ad31b8e17597ff2be36eb1331c00fdab96da6adf6536ba3cd66b87daf3346c8")
