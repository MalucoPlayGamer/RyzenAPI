-- Lua provided by SkyAPI 
-- Game: AppID 648780
addappid(648780)
addappid(648781, 1, "759ab0dd626ca31925d0af4de00026e80ade9ee4aef073e0dd71a9277eb8b91c")
