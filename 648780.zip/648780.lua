-- Lua provided by RyzenAPI
-- Game: addappid(648780)

-- MAIN APPLICATION
addappid(648780)

-- MAIN APP DEPOTS / PACKAGES
addappid(648781, 1, "759ab0dd626ca31925d0af4de00026e80ade9ee4aef073e0dd71a9277eb8b91c")
