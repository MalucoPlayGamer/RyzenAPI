-- Lua provided by RyzenAPI
-- Game: It's Quiz Time

-- MAIN APPLICATION
addappid(648780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(648781, 1, "759ab0dd626ca31925d0af4de00026e80ade9ee4aef073e0dd71a9277eb8b91c")
