-- Lua provided by RyzenAPI
-- Game: Spectrum

-- MAIN APPLICATION
addappid(420360)
addappid(525580)

-- MAIN APP DEPOTS / PACKAGES
addappid(420361, 1, "0d18835fdab460905a447ecc8b5b0246ea934ed1f88e0b0071719aa33c0ebdf5")
