-- Lua provided by RyzenAPI
-- Game: AppID 789270

-- MAIN APPLICATION
addappid(789270)

-- MAIN APP DEPOTS / PACKAGES
addappid(789271, 1, "3fe511e49f99e1847b6fde4ece1cb881921c594698fa86ad1a08a133548d72bd")

