-- Lua provided by SkyAPI 
-- Game: Detective Story: Reporter
addappid(1660590)
addappid(1660591, 1, "2227f4cd228a75e1ed4a3a6ea8cab5feab606b1a5afe77937e825aedb0f70364")
