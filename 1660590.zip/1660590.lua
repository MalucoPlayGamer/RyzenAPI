-- Lua provided by RyzenAPI
-- Game: Detective Story: Reporter

-- MAIN APPLICATION
addappid(1660590)
-- Game: addappid(1660590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660591, 1, "2227f4cd228a75e1ed4a3a6ea8cab5feab606b1a5afe77937e825aedb0f70364")
