-- Lua provided by RyzenAPI
-- Game: addappid(3364880)

-- MAIN APPLICATION
addappid(3364880)
addappid(3387780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364881, 1, "bfad1026670f68e060fc7ffb4789e6fd5386d5174670f70e5d4f3553ddcdd29c")
