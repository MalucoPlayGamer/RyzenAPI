-- Lua provided by RyzenAPI 
-- Game: AppID 2621900
addappid(2621900)
addappid(2621901, 1, "d2997554b8bcc142debb2783c4563e7c171d5607581834401c095f05829ac92a")
