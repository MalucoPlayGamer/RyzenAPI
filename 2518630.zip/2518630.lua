-- Lua provided by RyzenAPI
-- Game: 2518630

-- MAIN APPLICATION
addappid(2518630)
-- Game: addappid(2518630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518631, 1, "68a9f666ac92ff0487c6382f0c4b1b0cb344b44c790e268c9cd8b2a4867177dd")
