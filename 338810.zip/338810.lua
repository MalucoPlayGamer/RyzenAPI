-- Lua provided by RyzenAPI
-- Game: Demise of Nations

-- MAIN APPLICATION
addappid(338810)

-- MAIN APP DEPOTS / PACKAGES
addappid(338812,0,"8da608b5c1edf0220cf5eb8dfd62156218fe9c6d0f6a320f15c1f0e829e2dd4f")
addappid(338813,0,"bf05d556f946dee477572e056993b75dd8f1dbdad04651a1a6ff0253644dbef7")
addappid(338815,0,"4c476a9698e51311c7ab81491b88cb688da0af6099a3150edbb269612ab5abf2")
