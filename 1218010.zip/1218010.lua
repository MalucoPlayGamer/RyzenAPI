-- Lua provided by RyzenAPI
-- Game: HGFaceDD

-- MAIN APPLICATION
addappid(1218010)
-- Game: addappid(1218010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218011, 1, "e883900aee7965cf7593a5d02a1281cb6ddd1df49552fed3c47dfa6a45572fb4")
