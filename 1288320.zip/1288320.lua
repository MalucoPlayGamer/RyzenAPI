-- Lua provided by RyzenAPI
-- Game: Way of the Hunter

-- MAIN APPLICATION
addappid(1288320)
addappid(2012180)
addappid(2014490)
addappid(2054470)
addappid(2054471)
addappid(2211610)
addappid(2584760)
addappid(2698430)
addappid(2793490)
addappid(2922200)
addappid(2922210)
addappid(2922220)
addappid(2922230)
addappid(3091570)
addappid(3091580)
addappid(3760210)
addappid(4071720)
addappid(4071730)
addappid(4234310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1288321, 1, "708ac4e2fd466252d4859b1e41672d67d6ae8d17be1285cc01f0e3517dbc1dac")

