-- Lua provided by RyzenAPI
-- Game: Way of the Hunter

-- MAIN APPLICATION
addappid(1288320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288321, 1, "708ac4e2fd466252d4859b1e41672d67d6ae8d17be1285cc01f0e3517dbc1dac")
