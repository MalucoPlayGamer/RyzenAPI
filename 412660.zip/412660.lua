-- Lua provided by RyzenAPI
-- Game: Game: Klang

-- MAIN APPLICATION
addappid(412660)
-- Game: addappid(412660)

-- MAIN APP DEPOTS / PACKAGES
addappid(412661, 1, "447c41534ab78ecb96e927b977289543dc7ba22d4d85e00baa275048cad9d291")
addappid(529750, 0, "a02a5ff2396a567cdc5364f6957025470c37756474d394d6ecad4d8b8223e9d1")
