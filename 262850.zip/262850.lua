-- Lua provided by RyzenAPI
-- Game: The Journey Down: Chapter Two

-- MAIN APPLICATION
addappid(262850)

-- MAIN APP DEPOTS / PACKAGES
addappid(262851, 1, "775b8eb81546c24c2a38203de8610684ed0bb80a124642eb05b11940d295425f")
addappid(262852, 1, "4482ebfbbe563b044fa2f18c7086ac9e683169b8acfb8f755ed768b6445ce58d")
addappid(262853, 1, "56a2dac55bfe7a537fc9daad350e229f467e4bf0be362bd14c262cae16e9c513")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
