-- Lua provided by RyzenAPI
-- Game: The Good Life Demo

-- MAIN APPLICATION
addappid(1741410)
-- Game: addappid(1741410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741411, 1, "7d35e3ccf0334129e0a5f413f8b02b689b0fe413836f4f661288c39e06534552")
