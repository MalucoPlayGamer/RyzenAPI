-- Lua provided by RyzenAPI
-- Game: addappid(662990)

-- MAIN APPLICATION
addappid(662990)
addappid(707360)

-- MAIN APP DEPOTS / PACKAGES
addappid(662991, 1, "55eccb4191fb84fa8722b2434bb735cb6ee0610f46963ad41d558fa619935383")
