-- Lua provided by RyzenAPI
-- Game: 303590

-- MAIN APPLICATION
addappid(303590)
-- Game: addappid(303590)

-- MAIN APP DEPOTS / PACKAGES
addappid(303591, 1, "19530ed04a2ad099f939a504963db28646dec201cf6ec8f28e5eece84d09705a")
