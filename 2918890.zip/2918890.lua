-- Lua provided by RyzenAPI
-- Game: Spirit Harem

-- MAIN APPLICATION
addappid(2918890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918891, 1, "e87604cf32714736ad96f2ef9f78a9464dafd04b10d825e415e92367881d7178")

