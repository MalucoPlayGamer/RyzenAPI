-- Lua provided by RyzenAPI
-- Game: ChanceBall

-- MAIN APPLICATION
addappid(3128780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128781,0,"640092d5639bcf8d90e75ea16a33709725b68eb5e099e6c1aaf9471a808bc174")

