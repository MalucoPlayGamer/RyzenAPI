-- Lua provided by RyzenAPI
-- Game: 2192400

-- MAIN APPLICATION
addappid(2192400)
-- Game: addappid(2192400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192401, 1, "e31f343a40b6f4304a101b23aa486d86ae397e3aab869aed0fbc9e0d4b125f34")
