-- Lua provided by RyzenAPI
-- Game: Game: Murder In Tehran's Alleys 1933

-- MAIN APPLICATION
addappid(630170)
-- Game: addappid(630170)

-- MAIN APP DEPOTS / PACKAGES
addappid(630171, 1, "c5317e3b162311d037391935e968166398ba9a2563d47caddb592036f620bb27")
