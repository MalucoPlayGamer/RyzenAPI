-- Lua provided by RyzenAPI
-- Game: addappid(3190610)

-- MAIN APPLICATION
addappid(3190610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190611, 1, "ca8b06c8486ea7b958197c0694856a21fe6f3ca72a4bdbaca8be07f5e454cbfe")
