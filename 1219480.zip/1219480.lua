-- Lua provided by RyzenAPI
-- Game: Poly Squad

-- MAIN APPLICATION
addappid(1219480)
-- Game: addappid(1219480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219481, 1, "659a98b51cb8363af647c7f1d1ff3018cab53f6c923a4290d58209cb94825928")
