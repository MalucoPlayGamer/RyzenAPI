-- Lua provided by RyzenAPI
-- Game: The Treasures of Montezuma 4

-- MAIN APPLICATION
addappid(301150)
addappid(301151)
addappid(301152)
addappid(301153)
addappid(301154)
addappid(301156)
addappid(301157)
addappid(301158)
addappid(301159)
addappid(301160)
addappid(301161)
addappid(301162)
addappid(301163)
addappid(301164)
addappid(301165)
addappid(301166)
addappid(301167)
addappid(301168)

-- MAIN APP DEPOTS / PACKAGES
addappid(301155,0,"831731c9cc1bf608dc5d5a0f56b41a9c532dd5075c5d0274553cf38a348294a0")
