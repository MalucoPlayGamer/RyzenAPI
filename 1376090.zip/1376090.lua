-- Lua provided by RyzenAPI
-- Game: Darkness Eternal

-- MAIN APPLICATION
addappid(1376090)
-- Game: addappid(1376090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376091, 1, "024c4be2e43c6cc1ebe3f46c5eed9d67aba8f7ef1861b9b7a4d8fbd5934c25d8")
