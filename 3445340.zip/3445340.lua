-- Lua provided by RyzenAPI
-- Game: Sandwich Simulator

-- MAIN APPLICATION
addappid(3445340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445341, 1, "49eabae66757ebb18c0dfe8c483639c10c8419593d01eea04d5c49a7db86d0d4")

