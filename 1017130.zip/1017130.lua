-- Lua provided by RyzenAPI 
-- Game: Ikao The Lost Souls
addappid(1017130)
addappid(1017131, 1, "93ec0a192a3538ec3d5d2f96be647feeb618b7fb3cad5cc118d23b3fa93696b9")
