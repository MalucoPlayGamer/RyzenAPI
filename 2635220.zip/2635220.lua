-- Lua provided by RyzenAPI
-- Game: Who Wants To Be A Millionaire? - US Presidents DLC Pack

-- MAIN APPLICATION
addappid(2635220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635220,0,"370d716452acda3b961246207bf03efa5d33eff5de5854fc0735f71793536823")
