-- Lua provided by RyzenAPI
-- Game: Pandemic Pandemonium

-- MAIN APPLICATION
addappid(1572170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1572171, 1, "292c0b0e809daef40de80d10d2160feb26508600d1edf07cf579591d84a781a0")

