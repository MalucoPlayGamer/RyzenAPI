-- Lua provided by RyzenAPI
-- Game: addappid(1015800)

-- MAIN APPLICATION
addappid(1015800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015801, 1, "ffc94a35403d38734ad9270a96e1dcc4c9f3dfeabe67931e71949aefef4501d5")
addappid(1015802, 1, "cb69ea9448f2d6937df817724b2c615c11f4ae242eaed150aead1511965c75fb")
