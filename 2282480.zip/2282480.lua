-- Lua provided by RyzenAPI
-- Game: Game: Cave Crawler

-- MAIN APPLICATION
addappid(2282480)
-- Game: addappid(2282480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282481, 1, "f4539792973bf72912e507bff6a8591bc17611c02d39b977628583a29ece0206")
