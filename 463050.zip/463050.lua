-- Lua provided by RyzenAPI
-- Game: The Pit And The Pendulum

-- MAIN APPLICATION
addappid(463050)

-- MAIN APP DEPOTS / PACKAGES
addappid(463051, 1, "9a856a9c40754831552bd1d86d9b556619b6d40bbdffe0510845306f41f10e75")

