-- 3935270's Lua and Manifest Created by Hubcap Manifest
-- Minsgon Simulator
-- Created: August 21, 2026 at 19:31:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3935270, 1, "7399d591d9cf398beb0009d9f9f2065c0735d11e94431010717983c293ebdaf3") -- Minsgon Simulator
-- MAIN APP DEPOTS
addappid(3935271, 1, "89ae729e45d64009d8d117c2d0355a13fe2774bd459c21101e55b7a3aa235b3d") -- Depot 3935271
setManifestid(3935271, "148238609423488242", 4941978987)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)