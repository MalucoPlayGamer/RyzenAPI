-- Lua provided by RyzenAPI
-- Game: Minsgon Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3935270, 1, "7399d591d9cf398beb0009d9f9f2065c0735d11e94431010717983c293ebdaf3") -- Minsgon Simulator
addappid(3935271, 1, "89ae729e45d64009d8d117c2d0355a13fe2774bd459c21101e55b7a3aa235b3d") -- Depot 3935271

