-- Lua provided by RyzenAPI
-- Game: Game: AppID 3034360

-- MAIN APPLICATION
addappid(3034360)
-- Game: addappid(3034360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034361, 1, "928c8be08dcd47dd4d4d1500e96e595e8e22b558e8c65e3a4431bb2085651d9a")
