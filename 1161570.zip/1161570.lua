-- Lua provided by RyzenAPI
-- Game: addappid(1161570)

-- MAIN APPLICATION
addappid(1161570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161571, 1, "3033441c3e7ad815d0d9e90b36b5e2da3e86eecb48b6927a2859e9f43b8d4934")
