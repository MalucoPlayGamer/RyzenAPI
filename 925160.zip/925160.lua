-- Lua provided by RyzenAPI
-- Game: Sky Residences at Ice District

-- MAIN APPLICATION
addappid(925160)

-- MAIN APP DEPOTS / PACKAGES
addappid(925161, 1, "d3ca645b04d1eb4a88a5c147503a56ab807fb847020f0956aa83ce9e7f459a7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
