-- Lua provided by SkyAPI 
-- Game: Sky Residences at Ice District
addappid(925160)
addappid(925161, 1, "d3ca645b04d1eb4a88a5c147503a56ab807fb847020f0956aa83ce9e7f459a7e")
