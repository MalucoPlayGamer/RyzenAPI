-- Lua provided by RyzenAPI
-- Game: addappid(2415020)

-- MAIN APPLICATION
addappid(2415020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415021, 1, "0a68835b49f5b1ce0fcc140d03b84aa86094433b21ea0dfbd12f8130cd521be9")
