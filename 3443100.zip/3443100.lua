-- Lua provided by RyzenAPI
-- Game: Screaming In The Basement (2025) Demo

-- MAIN APPLICATION
addappid(3443100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443101, 1, "40bb7a4df1bc6c109166ee08d4cc56392e593b307c6fd26ae2afa7b2a912cbd6")
