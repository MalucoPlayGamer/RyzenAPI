-- Lua provided by RyzenAPI
-- Game: Gardener: Master of Trees and Flowers

-- MAIN APPLICATION
addappid(2052790)
-- Game: addappid(2052790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052792,0,"4f45427e3baf9813a50d4a5f9a2524038ac062443f9c40c5c36369c642f62268")
