-- Lua provided by RyzenAPI
-- Game: 2664730

-- MAIN APPLICATION
addappid(2664730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664732,0,"b8a4514971aa16e5c9fd8adb88eac051a51fbf29da44e9f8f46aa5bd9f521be9")
