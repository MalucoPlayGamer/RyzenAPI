-- Lua provided by RyzenAPI
-- Game: 洞石火 Soundtrack

-- MAIN APPLICATION
addappid(3032570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032571, 1, "4885187b3ea0072db1ef03792f7135a53f5ac0e16c540a2169076da59001e769")

