-- Lua provided by RyzenAPI
-- Game: The Void Project

-- MAIN APPLICATION
addappid(2681270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681273,0,"76225d137661aeab6bcbb1966b1d824f8186a764e3515d84b5ac9893e47c27d8")

