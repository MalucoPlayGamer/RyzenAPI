-- Lua provided by RyzenAPI
-- Game: The Void Project

-- MAIN APPLICATION
addappid(2681270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681273,0,"76225d137661aeab6bcbb1966b1d824f8186a764e3515d84b5ac9893e47c27d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
