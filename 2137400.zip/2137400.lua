-- Lua provided by RyzenAPI
-- Game: EmyLiveShow: S&M story

-- MAIN APPLICATION
addappid(2137400)
-- Game: addappid(2137400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137401, 1, "31253f015988afab492e2baade05cf851470ad444867963e77164b4dfd3f9fcc")
