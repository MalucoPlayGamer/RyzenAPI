-- Lua provided by RyzenAPI
-- Game: 1032430

-- MAIN APPLICATION
addappid(1032430)
-- Game: addappid(1032430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032431, 1, "e533393d2895e4516e079d4b23cd2d771cbf53adbe1954e629fdc0ae0689f62d")
