-- Lua provided by RyzenAPI
-- Game: AppID 1032430

-- MAIN APPLICATION
addappid(1032430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1032431, 1, "e533393d2895e4516e079d4b23cd2d771cbf53adbe1954e629fdc0ae0689f62d")

