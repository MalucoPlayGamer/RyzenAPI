-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Space Marine 2 - Original Soundtrack

-- MAIN APPLICATION
addappid(3212020)
-- Game: addappid(3212020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3212021, 1, "01e7d7bd4abcb8946df7226afc08075b26c702659cf81018580d5f8e597b6c93")
addappid(3212022, 1, "924f67387bb12cfc2988a7decd11c8ace7b5b38ae9d07397e246b36d01c1e5c5")
addappid(3212023, 1, "ad43f8052145e7fad816f6b2299a1ae217fc78bd8e1c769cb0ad3e0272d843d0")
