-- Lua provided by RyzenAPI
-- Game: Realities - Death Valley

-- MAIN APPLICATION
addappid(708621)

-- MAIN APP DEPOTS / PACKAGES
addappid(737940,0,"3449be9a9d9e5f4f493963210338b3d4bf7f3de2b9d7166cb3dbb069dad6e665")

