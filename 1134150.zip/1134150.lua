-- Lua provided by RyzenAPI
-- Game: X Wars Deluxe

-- MAIN APPLICATION
addappid(1134150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134151, 1, "9b6b589250776d96ec086f19a41f4cb543ecdcd1c5e16f684d9f0988130dbb88")

