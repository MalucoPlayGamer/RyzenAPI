-- Lua provided by RyzenAPI
-- Game: Game: Re:Fresh

-- MAIN APPLICATION
addappid(2297650)
-- Game: addappid(2297650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297651, 1, "233403bcb6cc9aa588bf9ddacf065a6ca45691925bc63bfae448709d5f9e0376")
addappid(2297652, 1, "9d79019a23ad49822e088b6c222711245ada856252f60f16f2c243c28354af79")
