-- Lua provided by RyzenAPI 
-- Game: Deck of Haunts Demo
addappid(3313700)
addappid(3313701, 1, "d5479199291993c6237d1de4eff8a2f85b75391b2e926778d7aa5ddb88ded175")
