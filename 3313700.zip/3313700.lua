-- Lua provided by RyzenAPI
-- Game: 3313700

-- MAIN APPLICATION
addappid(3313700)
-- Game: addappid(3313700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313701, 1, "d5479199291993c6237d1de4eff8a2f85b75391b2e926778d7aa5ddb88ded175")
