-- Lua provided by RyzenAPI
-- Game: addappid(2410980)

-- MAIN APPLICATION
addappid(2410980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410981, 1, "2237b6af6ed3ee48b3dd7df2b9db8c8711c656e118db4d349d5f073dab415484")
