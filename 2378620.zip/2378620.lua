-- Lua provided by RyzenAPI
-- Game: addappid(2378620)

-- MAIN APPLICATION
addappid(2378620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378621, 1, "603820674e8e8be5c370e2f4d5a4b70714c44bce4ba4ffdc55f9a3cd69f8b75d")
addappid(2378622, 1, "4b8409dc21d351051d4c4ea166c641fd55de5c3dfce490a7aeba213ebea6e417")
addappid(2378623, 1, "b41d7da3b4eafe2c49ea483b1ce6e6a1084635234705f10e92a505c878248fe5")
