-- Lua provided by RyzenAPI 
-- Game: Wedding Day
addappid(3078650)
addappid(3078651, 1, "e7275b0fde4538b85418e6939d54ce2d62efed6688b54a7c3569e41fe367ee71")
