-- Lua provided by RyzenAPI
-- Game: Game: Wedding Day

-- MAIN APPLICATION
addappid(3078650)
-- Game: addappid(3078650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078651, 1, "e7275b0fde4538b85418e6939d54ce2d62efed6688b54a7c3569e41fe367ee71")
