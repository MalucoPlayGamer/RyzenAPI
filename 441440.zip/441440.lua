-- Lua provided by RyzenAPI
-- Game: addappid(441440)

-- MAIN APPLICATION
addappid(441440)

-- MAIN APP DEPOTS / PACKAGES
addappid(441441, 1, "604c1a849eeb48d8b586350e57494bdebcae2588b0b0b8a0a7242e0cda0af739")
