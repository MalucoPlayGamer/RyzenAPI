-- Lua provided by RyzenAPI
-- Game: Sometimes Always Monsters

-- MAIN APPLICATION
addappid(441440)

-- MAIN APP DEPOTS / PACKAGES
addappid(441441, 1, "604c1a849eeb48d8b586350e57494bdebcae2588b0b0b8a0a7242e0cda0af739")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1292640)
addappid(1341860)
