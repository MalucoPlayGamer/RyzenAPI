-- Lua provided by RyzenAPI
-- Game: Magic Mess: Restore Order to the Wizard's Tower

-- MAIN APPLICATION
addappid(5012990) -- Magic Mess: Restore Order to the Wizard's Tower

-- MAIN APP DEPOTS / PACKAGES
addappid(5012991, 1, "89908e234a7f7e5f2e3e92a50ce03f97e8d73dd48531093e06d8b0b965452c4b") -- Depot 5012991

