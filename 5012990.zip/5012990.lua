-- 5012990's Lua and Manifest Created by Hubcap Manifest
-- Magic Mess: Restore Order to the Wizard's Tower
-- Created: August 25, 2026 at 09:16:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5012990) -- Magic Mess: Restore Order to the Wizard's Tower
-- MAIN APP DEPOTS
addappid(5012991, 1, "89908e234a7f7e5f2e3e92a50ce03f97e8d73dd48531093e06d8b0b965452c4b") -- Depot 5012991
setManifestid(5012991, "4371500505940822214", 721411664)