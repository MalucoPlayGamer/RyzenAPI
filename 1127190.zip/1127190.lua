-- Lua provided by RyzenAPI
-- Game: AppID 1127190

-- MAIN APPLICATION
addappid(1127190)
-- Game: addappid(1127190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127191, 1, "45620db5a272a4c4b776e7e627ec5816eb915a406313fef6d040bfc774ace7c8")
