-- Lua provided by RyzenAPI
-- Game: 978290

-- MAIN APPLICATION
addappid(978290)
-- Game: addappid(978290)

-- MAIN APP DEPOTS / PACKAGES
addappid(978291, 1, "8f02ffad4994d8efd32433050da706848d20ec72050bd0e699a16b3d8461343a")
