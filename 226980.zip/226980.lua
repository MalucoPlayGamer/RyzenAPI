-- Lua provided by RyzenAPI
-- Game: Pinball FX2

-- MAIN APPLICATION
addappid(226980) -- Pinball FX2
addappid(226990) -- Pinball FX2 - Core pack
addappid(226991) -- Pinball FX2 - Marvel Pinball Original Pack
addappid(226992) -- Pinball FX2 - Zen Classics Pack
addappid(226993) -- Pinball FX2 - Marvel Pinball Avengers Chronicles pack
addappid(226994) -- Pinball FX2 - Marvel Pinball Vengeance and Virtue Pack
addappid(226995) -- Pinball FX2 - Star Wars Pack
addappid(226996) -- Pinball FX2 - Epic Quest Table
addappid(226997) -- Pinball FX2 - Paranormal Table
addappid(226998) -- Pinball FX2 - Fantastic Four Table
addappid(226999) -- Pinball FX2 - Civil War Table
addappid(245190) -- Pinball FX2 - Captain America Table
addappid(245191) -- Pinball FX2 - Mars Table
addappid(245192) -- Pinball FX2 - Excalibur Table
addappid(245193) -- Pinball FX2 - Earth Defense Table
addappid(249120) -- Pinball FX2 - Ms. Splosion Man Table
addappid(249121) -- Pinball FX2 - Plants VS. Zombies Table
addappid(249122) -- Pinball FX2 - Star Wars Pinball Balance of the Force Pack
addappid(265200) -- Pinball FX2 - Doctor Strange Table
addappid(273520) -- Pinball FX2 - Super League - A.C. Milan Table
addappid(273521) -- Pinball FX2 - Super League - Real Madrid C.F. Table
addappid(273522) -- Pinball FX2 - Super League - A.S. Roma Table
addappid(273523) -- Pinball FX2 - Super League - Liverpool F.C. Table
addappid(273524) -- Pinball FX2 - Super League - Juventus Table
addappid(273525) -- Pinball FX2 - Super League - Arsenal F.C.  Table
addappid(273526) -- Pinball FX2 - Super League - FC Barcelona Table
addappid(273527) -- Pinball FX2 - Super League - Zen Studios F.C. Table
addappid(293110) -- Pinball FX2 - Star Wars Pinball Heroes Within Pack
addappid(306880) -- Pinball FX2 - Deadpool Table
addappid(315720) -- Pinball FX2 - Guardians of the Galaxy Table
addappid(317740) -- Pinball FX2 - The Walking Dead Table
addappid(322960) -- Pinball FX2 - South Park Pinball
addappid(335060) -- Pinball FX2 - Venom Table
addappid(350060) -- Pinball FX2 - Iron  Steel Pack
addappid(363030) -- Pinball FX2 - Marvels Avengers Age of Ultron
addappid(363031) -- Pinball FX2 - Star Wars Pinball Star Wars Rebels
addappid(368840) -- Pinball FX2 - Portal  Pinball
addappid(384370) -- Pinball FX2 - Marvels Ant-Man
addappid(404990) -- Pinball FX2 - C bundle
addappid(410420) -- Pinball FX2 - Balls of Glory Pinball
addappid(433040) -- Pinball FX2 - Star Wars Pinball The Force Awakens Pack
addappid(459450) -- Pinball FX2 - Aliens vs. Pinball
addappid(529350) -- Pinball FX2 - Marvels Women of Power
addappid(559840) -- Pinball FX2 - Bethesda Pinball
addappid(585540) -- Pinball FX2 - Star Wars Pinball Rogue One

-- MAIN APP DEPOTS / PACKAGES
addappid(226981, 1, "62a803f8d7becbab83d842e09e8cc49f0628b7e3f428551982413557bf45286a") -- Pinball FX2
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)

