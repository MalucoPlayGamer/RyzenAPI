-- Lua provided by RyzenAPI
-- Game: AppID 226980

-- MAIN APPLICATION
addappid(226980)
addappid(228990)
addappid(228999)
addappid(245190)
addappid(245191)
addappid(245192)
addappid(245193)
addappid(249120)
addappid(249121)
addappid(249122)
addappid(265200)
addappid(306880)
addappid(317740)
addappid(322960)
addappid(335060)
addappid(350060)
addappid(363030)
addappid(363031)
addappid(368840)
addappid(404990)
addappid(410420)
addappid(433040)
addappid(459450)
addappid(585540)

-- MAIN APP DEPOTS / PACKAGES
addappid(226981, 1, "62a803f8d7becbab83d842e09e8cc49f0628b7e3f428551982413557bf45286a")

