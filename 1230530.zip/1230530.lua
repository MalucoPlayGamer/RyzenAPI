-- Lua provided by RyzenAPI
-- Game: AppID 1230530

-- MAIN APPLICATION
addappid(1230530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230531, 1, "25f3af482734dc6c7e43a9a45c3c959c4c9988a764396d7dace988ef9622b312")
addappid(1230532, 1, "063151f238f826db2cc0391307ffd1970c31dcba8bdea7d34043f17023d27725")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1933030)
addappid(2863890)
