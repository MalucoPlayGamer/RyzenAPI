-- Lua provided by RyzenAPI
-- Game: FatSheep Crisis

-- MAIN APPLICATION
addappid(2352040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352041, 1, "7fe799b2d708f8b47524e4827d6af00a125a0ebc1d233e41a16ff5556b646b3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
