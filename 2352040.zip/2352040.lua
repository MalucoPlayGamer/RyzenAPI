-- Lua provided by RyzenAPI
-- Game: FatSheep Crisis

-- MAIN APPLICATION
addappid(2352040)
-- Game: addappid(2352040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352041, 1, "7fe799b2d708f8b47524e4827d6af00a125a0ebc1d233e41a16ff5556b646b3f")
