-- Lua provided by RyzenAPI
-- Game: 1121910

-- MAIN APPLICATION
addappid(1121910)
-- Game: addappid(1121910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121911, 1, "de60934305706c0198ed9fd1e10ba218e3f5088be72b9191a3aa6df0ca226249")
addappid(1121912, 1, "c8edefc4fda31747fcaf67f6fac36c8088c70b0038852be7ccece530c242c477")
addappid(1121913, 1, "a3fe5675bcb6fe8546af3b813c8bb7af9285db68b6fc37410543b74afe0fcd0d")
