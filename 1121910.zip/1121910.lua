-- Lua provided by RyzenAPI
-- Game: I Love You, Colonel Sanders! A Finger Lickin’ Good Dating Simulator

-- MAIN APPLICATION
addappid(1121910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1121911, 1, "de60934305706c0198ed9fd1e10ba218e3f5088be72b9191a3aa6df0ca226249")
addappid(1121912, 1, "c8edefc4fda31747fcaf67f6fac36c8088c70b0038852be7ccece530c242c477")
addappid(1121913, 1, "a3fe5675bcb6fe8546af3b813c8bb7af9285db68b6fc37410543b74afe0fcd0d")

