-- Lua provided by SkyAPI 
-- Game: Sunless Skies: Sovereign Edition
addappid(596970)
addappid(596971, 1, "02a368602bd78c701e2e46808060e99f57a7e4ee87e1df0d47e54170c98b6aac")
addappid(596972, 1, "3114bb240f904bb2ca32533b7d872b9e7616ad583e325f738011be1ea29e2d37")
addappid(596973, 1, "bb4ff34b278ef97cec38591f1570397582d834f2f3d01b8df21b98d0d30538cd")
addappid(598920)
addappid(598921)
