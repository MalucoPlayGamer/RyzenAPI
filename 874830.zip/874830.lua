-- Lua provided by RyzenAPI
-- Game: School of Horror

-- MAIN APPLICATION
addappid(874830)

-- MAIN APP DEPOTS / PACKAGES
addappid(874831, 1, "940406fedcc2cf375061866b0c18465667e35e0075705d1e0a1fc4b087453611")

