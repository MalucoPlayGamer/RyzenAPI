-- Lua provided by SkyAPI 
-- Game: Odyssey: The Deep Space Expedition
addappid(738600)
addappid(738601, 1, "de7544bd5199cd0f9a2f2134a0a03a0679dd0cb23ba569459423d6b759e2a513")
addappid(992770, 0, "e772ee5b12d573bf361428eeb3ee4f9a84fa614b86afdd1bce95810102ee17ec")
