-- Lua provided by RyzenAPI
-- Game: Flatshot

-- MAIN APPLICATION
addappid(517510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(517512,0,"d9ebb3c02c81bdac854de95456f093bcfdf277ff0b9b7f26a71bb1052d4dd0e9")

