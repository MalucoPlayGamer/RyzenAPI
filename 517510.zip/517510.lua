-- Lua provided by RyzenAPI
-- Game: setManifestid(517512,"5510602322748079794")

-- MAIN APPLICATION
addappid(517510)

-- MAIN APP DEPOTS / PACKAGES
addappid(517512,0,"d9ebb3c02c81bdac854de95456f093bcfdf277ff0b9b7f26a71bb1052d4dd0e9")

