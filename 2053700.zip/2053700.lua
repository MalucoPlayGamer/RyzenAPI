-- Lua provided by RyzenAPI
-- Game: 满庭芳：宋上繁华 Demo

-- MAIN APPLICATION
addappid(2053700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053701, 1, "8ec3d79f25cc6805daa6a9c25890465f5a9b7e141ae29116c1998d7e87602a9d")
