-- Lua provided by RyzenAPI
-- Game: FUSER™ - SAINt JHN - "Roses (Imanbek Remix)"

-- MAIN APPLICATION
addappid(1460350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460350,0,"3128219f39dec26c656d4f9810d13ff6a86458685cd7cb843df503c506e08506")
