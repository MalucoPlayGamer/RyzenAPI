-- Lua provided by RyzenAPI
-- Game: Game: AppID 716020

-- MAIN APPLICATION
addappid(716020)
-- Game: addappid(716020)

-- MAIN APP DEPOTS / PACKAGES
addappid(716021, 1, "9d3482cb866706b6685e8ccff9b4219249c8e773048def30c71c15faf5984f6e")
