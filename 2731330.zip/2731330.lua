-- Lua provided by RyzenAPI
-- Game: Game: TROLEU

-- MAIN APPLICATION
addappid(2731330)
-- Game: addappid(2731330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731331, 1, "d159019a5ac4faef584aeb4ec0e482e87ab565ddbb3440d1437854b3492d09c5")
