-- Lua provided by RyzenAPI
-- Game: Pilfered Liberty

-- MAIN APPLICATION
addappid(1510900)
-- Game: addappid(1510900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510901, 1, "506cbaf8b88687603cf3e50c7953d41adac057311078d6987b5788661c2d67b1")
