-- Lua provided by RyzenAPI
-- Game: 581650

-- MAIN APPLICATION
addappid(581650)
-- Game: addappid(581650)

-- MAIN APP DEPOTS / PACKAGES
addappid(581651, 1, "be5b7e255c3b254917c17d47b35e41318d773dc52bf913e4f5fc5e8bc766975c")
