-- Lua provided by RyzenAPI
-- Game: Little Misfortune Original Soundtrack

-- MAIN APPLICATION
addappid(1124140)
addappid(1124141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124140,0,"911f25d4aa1d30ea8e2ef118c48ce4df561026c0104548943876f6054f5e0eab")
