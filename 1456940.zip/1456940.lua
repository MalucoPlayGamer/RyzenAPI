-- Lua provided by RyzenAPI
-- Game: Level Zero: Extraction

-- MAIN APPLICATION
addappid(1456940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456941, 1, "b27ec4f913bc6089773b4bed8aa18bd1103bed28d9c304cf957aba343f09ee08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3110340)
addappid(3126940)
addappid(3142390)
