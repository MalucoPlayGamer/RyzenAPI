-- Lua provided by RyzenAPI
-- Game: addappid(1456940)

-- MAIN APPLICATION
addappid(1456940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456941, 1, "b27ec4f913bc6089773b4bed8aa18bd1103bed28d9c304cf957aba343f09ee08")
