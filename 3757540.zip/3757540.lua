-- Lua provided by RyzenAPI
-- Game: HELLLLLCAFEEEEE

-- MAIN APPLICATION
addappid(3757540)
-- Game: addappid(3757540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3757541, 1, "c3ce7a81bbdaa4c38cc66f813a89bd098e0562151274ff156c05270c4c2357a4")
addappid(3757542, 1, "04d42c4c27c74b9d8474861a709def9aabb71b97ee70dfac4bc5cbae5a3941cb")
