-- Lua provided by RyzenAPI
-- Game: AppID 1377920

-- MAIN APPLICATION
addappid(1377920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377921, 1, "41f2a29fb17e100ded6092800c9e19fa919df8ff1408df0f4c575318d6a37cce")
addappid(1377922, 1, "f78d24cc8a2b5bf58a01e059c6b46c7edf7f526086fab180b078c79fd30f6c38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
