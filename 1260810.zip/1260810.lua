-- Lua provided by RyzenAPI
-- Game: Touhou Blooming Chaos 2

-- MAIN APPLICATION
addappid(1260810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260811, 1, "796684235fc827b4adc323e242f17b48188d165c8d9cc352582aa47011b7a4a7")
addappid(1525860, 0, "044411238fd65200c1cf74993e156690c55660182f815ae2b06a36054a88e908")
addappid(1526620, 0, "a42fbb624022a3a48ce2a0593d51df95b7d45a423190b452ac4186c30e0eb400")
addappid(1526710, 0, "f5bf46f690b31c59a26868232538cc3fcb82e9fe1d6b348b3e7f5c7f93be1369")
addappid(1526720, 0, "9d405a575872ff04969aee74c4b6f09d0eff2f8acb31e002f3d17d14e07b55ec")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1663300)
