-- Lua provided by RyzenAPI
-- Game: AppID 756590

-- MAIN APPLICATION
addappid(756590)

-- MAIN APP DEPOTS / PACKAGES
addappid(756591, 1, "28dad6812b211bfcecb75d4573c544d3ce177d47ddf2f33973d84562dd4aa0cf")
addappid(776840, 0, "ecf7de5ca910bb1fb4ce95252047fea940304aa2627d86e4cf7281f1f3ca87e5")
addappid(810820, 0, "f73b085efb0a3a815ad847cc2183c0dc7db4c9ac3d823b8c709f519a1c5edb6a")
addappid(810830, 0, "4fdf4d96ee6cd4ba10360c3abf3a299b9a1a0173fb84104bc454c55bb817d5e3")
addappid(810860, 0, "a9ddbff16603475046635c151638746803482c7b0eba289b10a66e7de8e6c45f")
addappid(810910, 0, "d6450ba13934e714d06b865b7a439069e80906858202fb761af48c763b4c1993")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(776850)
addappid(810840)
addappid(810850)
addappid(810870)
addappid(810880)
addappid(810890)
addappid(810900)
addappid(810920)
addappid(810930)
addappid(810940)
addappid(810950)
addappid(810960)
addappid(810970)
addappid(810980)
addappid(810990)
addappid(811000)
addappid(811010)
addappid(811020)
