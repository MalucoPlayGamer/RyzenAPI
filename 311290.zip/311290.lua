-- Lua provided by RyzenAPI
-- Game: SpellForce 3 Reforced

-- MAIN APPLICATION
addappid(311290)
addappid(1416261)
addappid(1416262)
addappid(1416264)
-- Game: addappid(311290)

-- MAIN APP DEPOTS / PACKAGES
addappid(311291, 1, "db4563c89b2cccf19f28cb164a623a2a43833ccf314a1e84e00e8c7c3400ef8d")
addappid(311292, 1, "cf711c4c270674cfee6e73345a491d12697ed081f02476390f64a91521b37ebe")
addappid(732890, 0, "1769d82a964f61512c3227f7c54dbcb4068c709a0e184f902651a1d1f864b78a")
addappid(795000, 0, "b48d5a83772382fd0073001bc6c66638c318182186c80d8af81f56dfdde6a7ea")
