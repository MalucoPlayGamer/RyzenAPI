-- Lua provided by RyzenAPI
-- Game: SpellForce 3 Reforced

-- MAIN APPLICATION
addappid(311290)
addappid(1416261)
addappid(1416262)
addappid(1416264)

-- MAIN APP DEPOTS / PACKAGES
addappid(311291, 1, "db4563c89b2cccf19f28cb164a623a2a43833ccf314a1e84e00e8c7c3400ef8d")
addappid(311292, 1, "cf711c4c270674cfee6e73345a491d12697ed081f02476390f64a91521b37ebe")
addappid(732890, 0, "1769d82a964f61512c3227f7c54dbcb4068c709a0e184f902651a1d1f864b78a")
addappid(795000, 0, "b48d5a83772382fd0073001bc6c66638c318182186c80d8af81f56dfdde6a7ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(649140)
