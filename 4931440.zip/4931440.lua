-- Lua provided by RyzenAPI
-- Game: miniko

-- MAIN APPLICATION
addappid(4931440) -- miniko

-- MAIN APP DEPOTS / PACKAGES
addappid(4931441, 1, "242317d0be76757977cfeec311d55dd45b24a36ac01df0fdaca85bbc86985ef3") -- Depot 4931441
addappid(4931442, 1, "92650920b23c9cdbe75ac3c4c68de9e6d25b10ba85980977a0af84529c39fd28") -- Depot 4931442

