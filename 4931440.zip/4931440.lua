-- 4931440's Lua and Manifest Created by Hubcap Manifest
-- miniko
-- Created: August 05, 2026 at 22:36:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4931440) -- miniko
-- MAIN APP DEPOTS
addappid(4931441, 1, "242317d0be76757977cfeec311d55dd45b24a36ac01df0fdaca85bbc86985ef3") -- Depot 4931441
setManifestid(4931441, "4749532987122322299", 29167596)
addappid(4931442, 1, "92650920b23c9cdbe75ac3c4c68de9e6d25b10ba85980977a0af84529c39fd28") -- Depot 4931442
setManifestid(4931442, "3154684097282015787", 58114980)