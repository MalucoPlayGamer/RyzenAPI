-- Lua provided by RyzenAPI
-- Game: Ultimus

-- MAIN APPLICATION
addappid(2598070)
-- Game: addappid(2598070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598071, 1, "7577140fd03390f59d93b9ecac9074e2e2be4c0a2de81a4e2b98e1b13263e97b")
