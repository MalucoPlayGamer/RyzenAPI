-- Lua provided by RyzenAPI
-- Game: Ultimus

-- MAIN APPLICATION
addappid(2598070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598071, 1, "7577140fd03390f59d93b9ecac9074e2e2be4c0a2de81a4e2b98e1b13263e97b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
