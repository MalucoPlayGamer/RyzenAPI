-- Lua provided by RyzenAPI
-- Game: Shoot Covid-19 | 消灭新冠肺炎

-- MAIN APPLICATION
addappid(1274150)
-- Game: addappid(1274150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274151, 1, "3a9c1243a826fdd07eaa092f7c19b04c37e1e3c66f21fec31ecc1d01364054f3")
