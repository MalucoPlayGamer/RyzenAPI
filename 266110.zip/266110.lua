-- Lua provided by RyzenAPI
-- Game: Tower of Guns

-- MAIN APPLICATION
addappid(266110)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(266111, 1, "afa0c91967d7305b8105f8e77207c58d6e2bd1ebf12562840e9611f44c5687ed")
addappid(266112, 1, "fb92ddc36e5efd6d5f51a3f3db555ca5589a21e7479a2b5df46ae8b8a074817e")
addappid(266113, 1, "82b1926f091b8604998f07f5aa6bb0370e78c8b2e6d781c0636cce240d62a353")

