-- Lua provided by RyzenAPI
-- Game: Melting World Online

-- MAIN APPLICATION
addappid(863420)

-- MAIN APP DEPOTS / PACKAGES
addappid(863421, 1, "4fdf80aa04884705d06129bef623304bc1b9a6982ab08485d3d81599af610259")
addappid(863422, 1, "c8d27eb6ca512b8cf332ed1b6935cde9b2d3a78cd9b4909b18b45de7571b3a89")
addappid(863423, 1, "3f133be19b55bb1a4c7736111bf8179f801ecd5d9b602cfff92512d876da575e")
