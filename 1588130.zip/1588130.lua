-- Lua provided by RyzenAPI
-- Game: MAZE: A VR Adventure

-- MAIN APPLICATION
addappid(1588130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588131, 1, "0772946f547ec859d9974ca76e10395709228ffb7f61e81ad035f666d848689f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
