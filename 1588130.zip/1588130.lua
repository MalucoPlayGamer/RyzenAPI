-- Lua provided by SkyAPI 
-- Game: MAZE: A VR Adventure
addappid(1588130)
addappid(1588131, 1, "0772946f547ec859d9974ca76e10395709228ffb7f61e81ad035f666d848689f")
