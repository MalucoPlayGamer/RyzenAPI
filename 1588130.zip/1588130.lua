-- Lua provided by RyzenAPI
-- Game: MAZE: A VR Adventure

-- MAIN APPLICATION
addappid(1588130)
-- Game: addappid(1588130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588131, 1, "0772946f547ec859d9974ca76e10395709228ffb7f61e81ad035f666d848689f")
