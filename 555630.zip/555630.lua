-- Lua provided by RyzenAPI
-- Game: A Magical High School Girl / 魔法の女子高生

-- MAIN APPLICATION
addappid(555630)
-- Game: addappid(555630)

-- MAIN APP DEPOTS / PACKAGES
addappid(555631, 1, "335ec1d7232098134fcbd5b4d78596e1406a2cbc7e13c916d93705b3e28d4920")
