-- Lua provided by RyzenAPI
-- Game: A Magical High School Girl / 魔法の女子高生

-- MAIN APPLICATION
addappid(555630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(555631, 1, "335ec1d7232098134fcbd5b4d78596e1406a2cbc7e13c916d93705b3e28d4920")

