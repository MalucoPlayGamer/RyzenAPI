-- Lua provided by SkyAPI 
-- Game: AppID 3227430
addappid(3227430)
addappid(3227431, 1, "a82f86245c0d4ffdfdeaf15663f8ee4354046735893c0f15c5d4efeb3ae01c16")
