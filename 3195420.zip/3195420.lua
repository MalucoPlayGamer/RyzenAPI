-- Lua provided by RyzenAPI
-- Game: Game: AppID 3195420

-- MAIN APPLICATION
addappid(3195420)
-- Game: addappid(3195420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195421, 1, "c8ff4103133273731fbd58925b8e307154d41f34dbbfb6223161141d11eff7fe")
