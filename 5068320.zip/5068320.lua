-- Lua provided by RyzenAPI
-- Game: EscortMission

-- MAIN APPLICATION
addappid(5068320) -- EscortMission

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(5068321, 1, "34d496f25ac62e508d0df62cfa42cf461d8fecc66dc550a0f880c0556fe52bea") -- Depot 5068321

