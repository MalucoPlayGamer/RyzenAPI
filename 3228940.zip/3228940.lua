-- Lua provided by RyzenAPI
-- Game: Blight Night

-- MAIN APPLICATION
addappid(3228940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228941, 1, "ded19399f04127b28746b17c560f2bccf77406edc0351464ebf320051534fe43")
