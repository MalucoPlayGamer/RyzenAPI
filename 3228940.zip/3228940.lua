-- Lua provided by SkyAPI 
-- Game: Blight Night
addappid(3228940)
addappid(3228941, 1, "ded19399f04127b28746b17c560f2bccf77406edc0351464ebf320051534fe43")
