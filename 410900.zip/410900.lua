-- Lua provided by RyzenAPI
-- Game: addappid(410900)

-- MAIN APPLICATION
addappid(228988)
addappid(410900)

-- MAIN APP DEPOTS / PACKAGES
addappid(410903,0,"16227c56c58eb563a48d09c05b6d2a9c376704b33232f8c3e4f32128c0085fdb")
addappid(1033530,0,"b24fed30fdcebe68a6ad251af83d393618b01faabc2ca19f473a8cd7a2d92845")
addappid(1811550,0,"faadbb556f49083eb3ebb13d9f820e3285ef228680181d57fec04ce7353ffe00")
