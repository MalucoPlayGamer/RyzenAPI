-- Lua provided by RyzenAPI
-- Game: Space Giraffe

-- MAIN APPLICATION
addappid(27800)

-- MAIN APP DEPOTS / PACKAGES
addappid(27801, 1, "7ba8b385c337dd13791888d5fb91ee21a2de8bee83d20187a484d2683816f00b")

