-- Lua provided by RyzenAPI
-- Game: 2872730

-- MAIN APPLICATION
addappid(2872730)
-- Game: addappid(2872730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872731, 1, "ca86abcd2e1c7a3fdcca6e0eb2b051383b437a344ad43dc95f4261de2acbdbe7")
