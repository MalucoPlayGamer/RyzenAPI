-- Lua provided by RyzenAPI
-- Game: addappid(1896750)

-- MAIN APPLICATION
addappid(1896750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896751, 1, "eab1c0a800752c5adbac21b939308c6ce053e5916984c9f1c351eeb08ab55680")
