-- Lua provided by RyzenAPI
-- Game: DreadOut

-- MAIN APPLICATION
addappid(269790)

-- MAIN APP DEPOTS / PACKAGES
addappid(269791, 1, "e1f7b20aeefcd252268e5725c669ecc3fb071ddeda8affa5e2f78114a1ce5486")
addappid(269792, 1, "fdda844ac33d04960454fba5109cd81d70ebbd2b1e2867f0a952c887ffc7af23")
addappid(269793, 1, "5895909c0e9267688c3a164ae7135e6b06b7c182a6708e9bbb9860e9c262aa60")
addappid(269794, 1, "054ed333e3ce70e72fe361befb4b474cd31d5b78869021b67e19307db8e84228")
addappid(298680, 0, "b45a1437ca09a77081e202b01ef75baa430e7384315874fbd19c4a137109eb1b")
addappid(298681, 1, "790e4f25b9dd20d5434a9efa63bf661e78dfb3818f16858f6482e8230efd4b0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
