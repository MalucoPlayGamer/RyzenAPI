-- Lua provided by RyzenAPI
-- Game: Mushihimesama

-- MAIN APPLICATION
addappid(377860)

-- MAIN APP DEPOTS / PACKAGES
addappid(377861, 1, "5d112679f39bbcfd8c7947140b7cfc755c718e9eb6d273da45828070da681b55")
addappid(377862, 1, "6b2504434d5b1294b8cb467147ba59755d47c7b4cbb3e6fe1c1766ab89c65f28")
addappid(377863, 1, "9382d2b64b6481f30e0d9179672e1e870c5a2463a3f51d1aa3c5281504289fad")
addappid(377864, 1, "480429090f27caa4487c1e08605ecfbad3de42768371a5f5c4c5fe31d30df3eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(387920)
