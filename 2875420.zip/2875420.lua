-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2875420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875420,0,"0c7b929679f7f6fbc397fdcd847d372019ed5d8d60ef614009fbe52694d9ce7b")

