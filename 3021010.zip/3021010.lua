-- Lua provided by RyzenAPI
-- Game: 3021010

-- MAIN APPLICATION
addappid(3021010)
-- Game: addappid(3021010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021011, 1, "20545db64e3a034931e0fb2fae54bb5e2a52f29c9e6b94fd81133441debf75ad")
