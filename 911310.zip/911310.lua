-- Lua provided by RyzenAPI
-- Game: Kz NTools : Fix Your Network

-- MAIN APPLICATION
addappid(911310)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(911311, 1, "3379c517110ef7d00ef3640f1dabd6f7e4c8ec3af96964e8adb0162e06d2eed3")

