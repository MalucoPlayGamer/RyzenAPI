-- Lua provided by RyzenAPI
-- Game: Kz NTools : Fix Your Network

-- MAIN APPLICATION
addappid(911310)

-- MAIN APP DEPOTS / PACKAGES
addappid(911311, 1, "3379c517110ef7d00ef3640f1dabd6f7e4c8ec3af96964e8adb0162e06d2eed3")

