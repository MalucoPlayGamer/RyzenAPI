-- Lua provided by RyzenAPI
-- Game: Weapons Party

-- MAIN APPLICATION
addappid(2421290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421291, 1, "f29fc84a0025a963d154ba591267dc3b8354bd716dc71c72992145f67a7c3e9c")
