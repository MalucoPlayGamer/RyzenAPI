-- Lua provided by RyzenAPI
-- Game: AppID 398120

-- MAIN APPLICATION
addappid(398120)

-- MAIN APP DEPOTS / PACKAGES
addappid(398121, 1, "acb07a4778df14837c9e2990cbc3e809f296008b79c2aeb8e6a65e96bc3591e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
