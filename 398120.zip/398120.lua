-- Lua provided by RyzenAPI
-- Game: AppID 398120

-- MAIN APPLICATION
addappid(398120)

-- MAIN APP DEPOTS / PACKAGES
addappid(398121, 1, "acb07a4778df14837c9e2990cbc3e809f296008b79c2aeb8e6a65e96bc3591e1")

