-- Lua provided by RyzenAPI
-- Game: addappid(939850)

-- MAIN APPLICATION
addappid(939850)

-- MAIN APP DEPOTS / PACKAGES
addappid(939851, 1, "52870eaa88e4dc0373d6136c84ca9cabfc5e45c197916e1f1a777d3aabe53e66")
addappid(939852, 1, "2daad047203d2dc13cb81e42a049520aca137a4309b78eb78b029182d5cfd1d2")
addappid(939855, 1, "939fae16bccf377c3682c43e18059e7c887bd39106cec6f5fcb10228adfe4683")
