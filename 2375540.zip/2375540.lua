-- Lua provided by RyzenAPI
-- Game: Hentai Casual Jigsaw - Witches

-- MAIN APPLICATION
addappid(2375540)
-- Game: addappid(2375540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375541, 1, "8cbcf7fa739780b247fd54b62dc4cd65e712777ee3402206ab1805560cfd640f")
