-- Lua provided by RyzenAPI
-- Game: 光明之战

-- MAIN APPLICATION
addappid(2483110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483111, 1, "52d3d00dcd6378d9bc072b8d24c3440b7a6fa02478a026a3ddfd9a0511660776")

