-- Lua provided by RyzenAPI
-- Game: Game: AppID 1036400

-- MAIN APPLICATION
addappid(1036400)
-- Game: addappid(1036400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036401, 1, "784fc38aeefdd1ca050f9cd1b8b9d6f8ae59294c6423ab7715a9427d77453d13")
