-- Lua provided by RyzenAPI
-- Game: Game: AppID 1102940

-- MAIN APPLICATION
addappid(1102940)
-- Game: addappid(1102940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102941, 1, "eca63a2601cfbf307edbc631d3978ccf0ab2fb85af080bf1f9ccccaecf8b7f02")
