-- Lua provided by RyzenAPI
-- Game: addappid(707030)

-- MAIN APPLICATION
addappid(707030)

-- MAIN APP DEPOTS / PACKAGES
addappid(707031, 1, "38ee1fb59b81a7d21d1c9f20eefc9553df6be37e46d44e7e7418a4fad814eb27")
