-- Lua provided by RyzenAPI
-- Game: addappid(2516150)

-- MAIN APPLICATION
addappid(2516150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516151, 1, "cc959c48da314f372fca05948f61c0922015aa109d86e8eefd42350cb75d43dd")
