-- Lua provided by RyzenAPI
-- Game: Gulman 4: Still alive

-- MAIN APPLICATION
addappid(559900)

-- MAIN APP DEPOTS / PACKAGES
addappid(559901, 1, "aa6974f9a33bd30381836c91ed56c05834571b2b29e9bd541f10ab21e7e9a101")
addappid(559902, 1, "1c2daffdbf1d64b765d27355cadf82beef480fd16b5fbb3d15e64124022d2e02")
addappid(559903, 1, "2c9635a49dbc6f318069fa1b616440155bb72c4795ea666689b399d8902f0c13")
addappid(559904, 1, "d5087b9e1ff50c004c2b7af067d7c42f929ef8e2cf3615032f7a6242c4eb03a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
