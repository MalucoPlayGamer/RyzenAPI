-- Lua provided by RyzenAPI
-- Game: Dear RED - Extended

-- MAIN APPLICATION
addappid(453850)
-- Game: addappid(453850)

-- MAIN APP DEPOTS / PACKAGES
addappid(453851, 1, "ada97d42206d23d5b5f99c2057ece81cd9442b1724c789ebd303b6c47705b335")
