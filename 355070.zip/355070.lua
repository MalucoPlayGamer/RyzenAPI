-- Lua provided by RyzenAPI
-- Game: TDP5 Arena 3D

-- MAIN APPLICATION
addappid(355070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(355071, 1, "c2e0d4216c51fd52b0d90bf160798476d33422ff96629e76e1f97595cbed2d6a")

