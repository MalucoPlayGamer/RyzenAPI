-- Lua provided by RyzenAPI
-- Game: 355070

-- MAIN APPLICATION
addappid(355070)
-- Game: addappid(355070)

-- MAIN APP DEPOTS / PACKAGES
addappid(355071, 1, "c2e0d4216c51fd52b0d90bf160798476d33422ff96629e76e1f97595cbed2d6a")
