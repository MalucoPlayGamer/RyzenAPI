-- Lua provided by RyzenAPI
-- Game: Abo Khashem

-- MAIN APPLICATION
addappid(662840)

-- MAIN APP DEPOTS / PACKAGES
addappid(662843,0,"beea98b0f9a3c37974e63261ab59231727a3875f578e09d50a117bb5561cc489")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(803580)
