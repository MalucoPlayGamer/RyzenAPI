-- Lua provided by RyzenAPI
-- Game: Last Anime boy: Saving loli

-- MAIN APPLICATION
addappid(750210)
addappid(759490)
-- Game: addappid(750210)

-- MAIN APP DEPOTS / PACKAGES
addappid(750211, 1, "a3ca74c2f55811b23a4aec0f0bc5f401ae268a1fb4a58cb115c75e60f1403828")
