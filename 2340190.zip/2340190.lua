-- Lua provided by RyzenAPI
-- Game: Beyond Polaris Guardian

-- MAIN APPLICATION
addappid(2340190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340191, 1, "6d108bf0ecff023075bc73a668276c6853666490066c5a17ca3d909f7019037b")
