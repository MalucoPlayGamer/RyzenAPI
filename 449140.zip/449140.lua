-- Lua provided by RyzenAPI
-- Game: AppID 449140

-- MAIN APPLICATION
addappid(449140)
addappid(472490)
addappid(614180)

-- MAIN APP DEPOTS / PACKAGES
addappid(449141, 1, "eb70a3198bab0a27d7b422590ea115d37515e5f03f042c2801fa1f7621d72504")
addappid(449142, 1, "9be301ffcbc5c1a0cdd183645035870dd2b628cbfed16657b1cf94ebbf7b79a1")
addappid(449143, 1, "121dcf7383eca1255e017a7bd3ac1b7c008ef1d67a2a5b990da9e05db32fb4ba")
addappid(449144, 1, "36c63b6c15d3902b04b8a3567f7d0f9ca0d6ad0857ab13096b30798a8a44b5e1")

