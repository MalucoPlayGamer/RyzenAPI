-- Lua provided by RyzenAPI
-- Game: AppID 837600

-- MAIN APPLICATION
addappid(837600)
-- Game: addappid(837600)

-- MAIN APP DEPOTS / PACKAGES
addappid(837601, 1, "b2379ea2f441580132a8d7208c47376ad380f52279cebd05f3a55ee4edf29909")
addappid(837602, 1, "a0ce0a1c7f59cf7223c5e79fe45255d31d383ac457cd52f18653c9c8a8e93fab")
addappid(837603, 1, "c113b8ed9048a0d620f282582324c23e1f2dfade58b891cda57aaf903e502bdc")
addappid(837604, 1, "1799ff32ea9987da1970a7047bf2b2a0cc6d6dbc923e11976b727a987f037ae3")
addappid(837605, 1, "8c81ca6277b1a259e92efd11ce8ed5bd66a2264b65694116b37bd222b617f67a")
addappid(837606, 1, "f062c88d60db9dffc388418fdb211fc7a248a27205f3af1d5b57877f4a3e5a3a")
addappid(837607, 1, "b3c0d9bbf0172f1b6a6001ced20bba5e25d2df6e3c35dec0e4795dd30801ef89")
addappid(837608, 1, "dcc76b8fed7dcd07b3c2c5af9844adbc07eccc24b7a5dbecf56319003ca4cd1f")
addappid(837609, 1, "ff06d7f2a29720fd29a6c08002e2acd4f2d8e57a024c1aa806ec8e898c5a9f9d")
