-- Lua provided by RyzenAPI
-- Game: 2526880

-- MAIN APPLICATION
addappid(2526880)
-- Game: addappid(2526880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526881, 1, "1f39eb63ae8a26a7859238cee8858ce6c13aedc85053a87135b3e87c126576ee")
