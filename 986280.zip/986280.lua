-- Lua provided by RyzenAPI
-- Game: Lingua Fleur: Lily

-- MAIN APPLICATION
addappid(986280)
addappid(1058960)
addappid(1970490)

-- MAIN APP DEPOTS / PACKAGES
addappid(986281,0,"cc8c735bdc58a98e634e090d7eea50f3e07211f5857846031915fe411bb8feaf")
addappid(1058960,0,"db05eefadd21a13d91a99d6144cbf37751dc30bed27a948a76e2407b4c5138bd")

