-- Lua provided by RyzenAPI
-- Game: Lingua Fleur: Lily

-- MAIN APPLICATION
addappid(986280)
-- Game: addappid(986280)

-- MAIN APP DEPOTS / PACKAGES
addappid(986281, 1, "cc8c735bdc58a98e634e090d7eea50f3e07211f5857846031915fe411bb8feaf")
