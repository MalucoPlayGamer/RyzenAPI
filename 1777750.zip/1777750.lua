-- Lua provided by RyzenAPI 
-- Game: Ninki Seiyuu: How to Make a Pop Voice Actress
addappid(1777750)
addappid(1777751, 1, "6afc47148e46c5022f38b7c5551f9630c56dfaea671ba28b13d972958ef4195f")
