-- Lua provided by RyzenAPI
-- Game: Game: Ninki Seiyuu: How to Make a Pop Voice Actress

-- MAIN APPLICATION
addappid(1777750)
-- Game: addappid(1777750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777751, 1, "6afc47148e46c5022f38b7c5551f9630c56dfaea671ba28b13d972958ef4195f")
