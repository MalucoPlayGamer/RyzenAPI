-- Lua provided by RyzenAPI
-- Game: I wanna go home

-- MAIN APPLICATION
addappid(1728430)
-- Game: addappid(1728430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728431, 1, "a42b1558af5ea91e2cff23732593b2d9bb1ff21ae1ec1e5ba9b1ac7a2779fc01")
