-- Lua provided by RyzenAPI
-- Game: Game: AppID 432620

-- MAIN APPLICATION
addappid(432620)
-- Game: addappid(432620)

-- MAIN APP DEPOTS / PACKAGES
addappid(432621, 1, "b6d0b53f772b999b7ffb1ff85d79592bdb0212aaae65b7e7f7f0a3289d167e95")
