-- Lua provided by RyzenAPI
-- Game: Game: In Next Life

-- MAIN APPLICATION
addappid(1702760)
-- Game: addappid(1702760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702761, 1, "da3f18c94a0278becc3ef80644e590464e61c4f043479f657479953ef6f07da1")
