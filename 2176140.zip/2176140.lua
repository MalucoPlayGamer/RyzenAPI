-- Lua provided by RyzenAPI 
-- Game: 云城异闻录
addappid(2176140)
addappid(2176141, 1, "4a0f64f3f4e73ba6cb225de6dded3a2f561221c4e91c4e047c797c58dbb74b6e")
