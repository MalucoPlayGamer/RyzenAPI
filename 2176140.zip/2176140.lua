-- Lua provided by RyzenAPI
-- Game: 云城异闻录

-- MAIN APPLICATION
addappid(2176140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2176141, 1, "4a0f64f3f4e73ba6cb225de6dded3a2f561221c4e91c4e047c797c58dbb74b6e")

