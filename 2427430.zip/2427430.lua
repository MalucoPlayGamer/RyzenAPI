-- Lua provided by RyzenAPI
-- Game: S.T.A.L.K.E.R.: Call of Prypiat - Enhanced Edition

-- MAIN APPLICATION
addappid(2427430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427431, 1, "9ca4bb728191e9525903590850212d58c659c9b99a7afc2c378ced66b987a610")

