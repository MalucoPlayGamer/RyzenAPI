-- Lua provided by RyzenAPI
-- Game: Wolfenstein: The New Order German Edition

-- MAIN APPLICATION
addappid(288570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(288571, 1, "9c56b3362fc2ee8a506601bbdcd61436e1546c4620e36913ab2dd6f822ac0897")
addappid(288572, 1, "5ab91fcc88222e91cbf8bdbfaebb3b17e6d065b63f577f24888070b9ff292381")
addappid(288573, 1, "a2b1c5bcb9dc79468f375613e86d2b699abce94fec175809fc7561a6b906ca4f")
addappid(288574, 1, "6f7d1fbc6fab406df9ba5e8bd1795a2adaa7801aeab14c7f59fe685bd4c98521")
addappid(288575, 1, "f7e0a38fffbf11ee17e4b7f7a6b2cc42850c2213bf9d76f7d940a10108f71cf8")
addappid(288576, 1, "657e8a78cdd4e3647e07f4a7b5497a55629982bd680172f95859ce8a886ced48")
addappid(288577, 1, "9e12d7b22a996f94876009135c6cc03c58d5ce3688f35fc5852e81832334d1bb")

