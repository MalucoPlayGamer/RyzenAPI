-- Lua provided by SkyAPI 
-- Game: Turtle Riders
addappid(2671010)
addappid(2671011, 1, "a1c59b922457dfe3a5f4f5b59e59706336cf2b9fe9350d5f8aacd412e81e118c")
