-- Lua provided by RyzenAPI
-- Game: TopplePOP: Bungee Blockbusters

-- MAIN APPLICATION
addappid(1175770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175771,0,"2a14d9a9f8391dfb09a239124c0fe01bd4d3fe548ea62a2d57d4ae46575be9ef")

