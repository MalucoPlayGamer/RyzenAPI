-- Lua provided by RyzenAPI
-- Game: 2000360

-- MAIN APPLICATION
addappid(2000360)
-- Game: addappid(2000360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000361, 1, "f76d6d80ca7b66ecc0da4718d9210eaabc0b17ddb1015f65437f459d6dd7b786")
