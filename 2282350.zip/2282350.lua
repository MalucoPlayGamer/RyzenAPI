-- Lua provided by RyzenAPI
-- Game: La Quimera

-- MAIN APPLICATION
addappid(2282350)
-- Game: addappid(2282350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282351, 1, "6d30b906df3f94271959b620e26ffa9c21aced6a540a1fd659b8af7adae0ede2")
