-- Lua provided by RyzenAPI
-- Game: Twizzle Puzzle: Animals

-- MAIN APPLICATION
addappid(2729040)
-- Game: addappid(2729040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729041, 1, "86e65e2eb3f1102b0f93d3c1136b6bfe678e8b87b735d62bbd02f40ef9a828fb")
