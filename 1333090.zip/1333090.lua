-- Lua provided by SkyAPI 
-- Game: Gravity
addappid(1333090)
addappid(1333091, 1, "dd4b8e2cb8936ce7176fdc6907fc38b09a68521ffed1ad31658c94e8edf8c4bd")
addappid(1333092, 1, "f47e7f79426b4e225dee8720217887feae8bfe88b67b4fe4382e49e8ed44447d")
addappid(1333093, 1, "7c25870e8c9e3223406e6cb2272fe144f2a46e826ddce212b41febd72328d87d")
addappid(1346580)
