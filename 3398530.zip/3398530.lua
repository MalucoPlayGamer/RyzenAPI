-- Lua provided by RyzenAPI
-- Game: Game: AppID 3398530

-- MAIN APPLICATION
addappid(3398530)
-- Game: addappid(3398530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398531, 1, "d1fa83cf6f454435c4a4a6e9d6f45f3f1c02cadce4eed069772121e037c2740e")
