-- Lua provided by RyzenAPI
-- Game: addappid(844030)

-- MAIN APPLICATION
addappid(844030)

-- MAIN APP DEPOTS / PACKAGES
addappid(844031, 1, "360d228f469be0bf37b368ccbd3735d5bd947726c05c1b0ae6aa34c7ebcafe09")
