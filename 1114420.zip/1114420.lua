-- Lua provided by RyzenAPI
-- Game: AppID 1114420

-- MAIN APPLICATION
addappid(1114420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1114421, 1, "ca88c51abd2abd06e9b238af6e68f6bcbc4d4f5a190b8e2e1f22bf416ba50559")
addappid(1114422, 1, "6d83c5b1bcb635eb1f94304b829cdcf3f929450bf1b98141eac018ebd745aa79")

