-- Lua provided by RyzenAPI
-- Game: addappid(1432200)

-- MAIN APPLICATION
addappid(1432200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432201, 1, "f5acd717d5df4af27a841ca8bac5c452b3e5a966b6abf978dda7265db9f0aebc")
