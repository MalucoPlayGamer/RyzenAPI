-- Lua provided by RyzenAPI
-- Game: Codename: Panzers - Cold War

-- MAIN APPLICATION
addappid(9850)

-- MAIN APP DEPOTS / PACKAGES
addappid(9851, 1, "78a20670dc4d01ca081da7872728e62deb4ff23d4da708bf0888cdc917fa3508")
addappid(9852, 1, "15a858886f4f93429a5128028ac9802ed2dab930b7252eb847a1e320d69c1fe9")
addappid(9853, 1, "5bb588a56a335427dca246b8d2177ad7843dc75f2b29a76468ea29c8b6892154")
addappid(9854, 1, "b44d0b8a3a18865ca5f5edea9e1ffee06bac5afa08da53f1d516bd2c46763251")
addappid(9855, 1, "f1359b2fdbb65d58241bd609fe7e17963dafe06c3b3ca154fb1c201bf80f290b")
addappid(9856, 1, "497dc73af77bddd5713e1eea4bdaf3a916bd98dbfc5daaee8481cbb6014036d6")
addappid(443670, 0, "d1ad823eaa0e0a107ccce62a458531ae5e0c5f9aeb7d61a59955b827c7b9d064")
