-- Lua provided by RyzenAPI
-- Game: 484930

-- MAIN APPLICATION
addappid(484930)
-- Game: addappid(484930)

-- MAIN APP DEPOTS / PACKAGES
addappid(484931, 1, "2feb6baa43f24c3e3843f31fff01034caf2817d7320e66e1672895a5393ba689")
