-- Lua provided by RyzenAPI
-- Game: 1131720

-- MAIN APPLICATION
addappid(1131720)
-- Game: addappid(1131720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131721, 1, "4395ae5fc256a39e5125343f6826e18deb21b7da417753a75a744bc0cd674a73")
