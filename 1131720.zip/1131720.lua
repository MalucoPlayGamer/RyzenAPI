-- Lua provided by RyzenAPI
-- Game: Prop and Seek

-- MAIN APPLICATION
addappid(1131720)
addappid(1339430)
addappid(1339431)
addappid(1339432)
addappid(1344620)
addappid(1345070)
addappid(1512430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131721,0,"4395ae5fc256a39e5125343f6826e18deb21b7da417753a75a744bc0cd674a73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
