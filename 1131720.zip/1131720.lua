-- Lua provided by RyzenAPI
-- Game: Prop and Seek

-- MAIN APPLICATION
addappid(1131720)
addappid(1339430)
addappid(1339431)
addappid(1339432)
addappid(1344620)
addappid(1345070)
addappid(1512430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131721,0,"4395ae5fc256a39e5125343f6826e18deb21b7da417753a75a744bc0cd674a73")

