-- Lua provided by RyzenAPI
-- Game: PixelJunk™ Shooter

-- MAIN APPLICATION
addappid(255870)
-- Game: addappid(255870)

-- MAIN APP DEPOTS / PACKAGES
addappid(255871, 1, "e82302702ad0056d47bc67e8efdef49d9658ec6928e7bfdcee0edbf82fd80d93")
addappid(255872, 1, "4b63294024a0007cd0444f1eb9aff882bc1b3f41f57603be62a9e908525f9341")
addappid(255873, 1, "6f6a66a547b045e13d964a03f0e228c88804b17599c6c862810976aeddda75ff")
