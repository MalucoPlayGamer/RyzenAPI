-- Lua provided by RyzenAPI
-- Game: Trigon: Space Story

-- MAIN APPLICATION
addappid(1226510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1226511, 1, "02b4eb817d2ab5c81bd3bfd7ffbb24842abbe4edebada37621bfa3e8484e6795")
addappid(1226512, 1, "2237a0ab33888b8fdec4cb20acc2c6e0f2a1032fe9b3758390294a63b688f3d5")
addappid(1226513, 1, "0d40bb3fd58ea5656ba49087e0b48ed0896a2ab3908e1a284ef8120aa4813722")
addappid(1925020, 0, "0fb91d29273f4a1f0238848e932e5ff532e950072956003b750fa11740c09b3d")

