-- Lua provided by RyzenAPI
-- Game: Star Trek: Resurgence Art Book

-- MAIN APPLICATION
addappid(2979360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2979360,0,"368e47d769416e72b53423d0de81a70ff00d6008a23d4e3071307ac70b0b2ddb")

