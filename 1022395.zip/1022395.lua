-- Lua provided by RyzenAPI
-- Game: DFF NT: Snow Villiers Starter Pack

-- MAIN APPLICATION
addappid(1022395)
-- Game: addappid(1022395)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022395,0,"d55dbb5b886b288cb777e4aa7bd3abb4956acfc66cbac34bb773fbcb22f26f18")
