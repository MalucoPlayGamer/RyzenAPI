-- Lua provided by RyzenAPI 
-- Game: AppID 1025140
addappid(1025140)
addappid(1025141, 1, "5098c1b7c97effa982ec61b1da8ba484d0e8d6e72caa9148d5e95e7d68e6cf98")
addappid(1047150, 0, "d588512096c7f18b0ca5f3f92d63c751a0fda939cc491975a5cf5fbabf75fa75")
