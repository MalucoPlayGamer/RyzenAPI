-- Lua provided by RyzenAPI
-- Game: addappid(1022496)

-- MAIN APPLICATION
addappid(1022496)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022496,0,"3f1a9c44a822fc583cf807541a2f1b5ea1108a98887ec8fb2261434a478ed0a6")
