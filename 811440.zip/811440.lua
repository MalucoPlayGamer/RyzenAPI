-- Lua provided by RyzenAPI
-- Game: Gripper's Adventure

-- MAIN APPLICATION
addappid(811440)

-- MAIN APP DEPOTS / PACKAGES
addappid(811441,0,"1b85a9c8324e66d96610026c6c68b0feed6195f393d043c2a9be42109b13ba54")

