-- Lua provided by RyzenAPI
-- Game: addappid(2981540)

-- MAIN APPLICATION
addappid(2981540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981540,0,"9ccfc15aa1a5e2cadfbf80f7cad47232df810b4ecd7b5e5f3ae709cc36aca605")
