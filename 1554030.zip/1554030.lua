-- Lua provided by RyzenAPI
-- Game: 我要成为铸剑师

-- MAIN APPLICATION
addappid(1554030)
-- Game: addappid(1554030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554031, 1, "e107b71344710d389c5fc92f9c7263fb7386c4742ce75fe3d84c453ffc07e7b0")
