-- Lua provided by RyzenAPI
-- Game: Sausage Wars

-- MAIN APPLICATION
addappid(2290210)
addappid(2852720)
addappid(2852730)
addappid(2852740)
-- Game: addappid(2290210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290211, 1, "95773b56ceaac38fe0c4ac4e3ed529d445c6e4e995c55717626c46f7416de9bf")
