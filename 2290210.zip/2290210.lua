-- Lua provided by RyzenAPI
-- Game: Sausage Wars

-- MAIN APPLICATION
addappid(2290210)
addappid(2852720)
addappid(2852730)
addappid(2852740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290211, 1, "95773b56ceaac38fe0c4ac4e3ed529d445c6e4e995c55717626c46f7416de9bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
