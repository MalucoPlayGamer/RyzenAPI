-- Lua provided by RyzenAPI
-- Game: addappid(655500)

-- MAIN APPLICATION
addappid(655500)

-- MAIN APP DEPOTS / PACKAGES
addappid(655501, 1, "96ac0578416aaa4357ba79df34030dda52225e35475c7106ef2edd8aeccf345b")
