-- Lua provided by RyzenAPI
-- Game: Super adventure

-- MAIN APPLICATION
addappid(2919240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919241, 1, "eb93616372928274033eb51fb9137ffdab394821c6d6499a998ecd6cd8788fbe")

