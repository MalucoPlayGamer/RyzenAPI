-- Lua provided by RyzenAPI
-- Game: Game: AppID 710860

-- MAIN APPLICATION
addappid(710860)
-- Game: addappid(710860)

-- MAIN APP DEPOTS / PACKAGES
addappid(710861, 1, "5a92d80a65ef674067224a75dd4d40ef47f102f267bc2716cbf5ac8a13700371")
