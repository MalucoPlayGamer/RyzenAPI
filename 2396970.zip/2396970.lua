-- Lua provided by RyzenAPI
-- Game: Game: AppID 2396970

-- MAIN APPLICATION
addappid(2396970)
-- Game: addappid(2396970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396971, 1, "6056569bbeff70dcbd5923e21d506ca3afb7243eaf22216f8f216de69b3ddf70")
