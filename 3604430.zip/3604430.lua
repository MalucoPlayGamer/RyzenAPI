-- Lua provided by RyzenAPI 
-- Game: Digger: Galactic Treasures
addappid(3604430)
addappid(3604431, 1, "2aec2c8b845f49a982e017a21014a1c5f2b9c1e82395febbc18a678c7e667a28")
