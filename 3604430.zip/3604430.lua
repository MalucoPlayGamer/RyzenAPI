-- Lua provided by RyzenAPI
-- Game: Digger: Galactic Treasures

-- MAIN APPLICATION
addappid(3604430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604431, 1, "2aec2c8b845f49a982e017a21014a1c5f2b9c1e82395febbc18a678c7e667a28")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
