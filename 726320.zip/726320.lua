-- Lua provided by RyzenAPI
-- Game: Girl Blonde

-- MAIN APPLICATION
addappid(726320)

-- MAIN APP DEPOTS / PACKAGES
addappid(726321, 1, "c1219c6dee4ae90efb2ce0123ccc638ddd5c20612a8c274ad97feff870861428")

