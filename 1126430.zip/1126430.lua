-- Lua provided by RyzenAPI
-- Game: Game: 香江之龙，Dragon of Hongkong

-- MAIN APPLICATION
addappid(1126430)
-- Game: addappid(1126430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126431, 1, "8a646bfa9e1315bf6f615b8de8a7e5343f37f291578bb8389ba099c61abae330")
