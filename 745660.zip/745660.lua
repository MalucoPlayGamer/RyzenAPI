-- Lua provided by RyzenAPI
-- Game: Sockman

-- MAIN APPLICATION
addappid(745660)
-- Game: addappid(745660)

-- MAIN APP DEPOTS / PACKAGES
addappid(745661, 1, "eb1845393b6e56b1c75835362ba6454edfd391d93e2f5ee7c97b81bacc24a46e")
