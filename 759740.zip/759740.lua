-- Lua provided by RyzenAPI
-- Game: RIDE 3

-- MAIN APPLICATION
addappid(759740)
addappid(900470)
addappid(900480)
addappid(900510)
addappid(900530)
addappid(900540)
addappid(900550)
addappid(900560)
addappid(900570)
addappid(900580)
addappid(900610)
addappid(900700)
addappid(900710)
addappid(903240)
addappid(903241)
addappid(903242)
addappid(903243)
addappid(903244)
addappid(903245)
addappid(903246)
addappid(903247)
addappid(903248)
addappid(903249)
addappid(903250)
addappid(903251)
addappid(903252)
addappid(903253)

-- MAIN APP DEPOTS / PACKAGES
addappid(759741, 1, "e06ec40da1fbf8f26e269f23a32882a12a62e48380a958738a741ffff4ada044")
