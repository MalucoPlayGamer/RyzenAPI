-- Lua provided by SkyAPI 
-- Game: AppID 275080
addappid(275080)
addappid(275081, 1, "441c4a7f0fcdca91a12ee2ad31407563d96ac9d20ac5017891fdb8dab200a26b")
addappid(275082, 1, "3858f0598c25e28b58dfefffda0dec6d1867b3b4e1804a820a7ab07680035334")
