-- Lua provided by RyzenAPI
-- Game: Terra Ventura

-- MAIN APPLICATION
addappid(1664580)
-- Game: addappid(1664580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664581, 1, "5406b3544c5e7546c4df32a71f186454a5ce4189b261309492bc5588d2f17c34")
