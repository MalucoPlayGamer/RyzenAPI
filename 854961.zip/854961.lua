-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(854961)
-- Game: addappid(854961)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238600,0,"038747379b6ecdc80d6c56c0f99c2fc989fe604ceafaabe42b9eaffa2bf6b964")
addappid(1238601,0,"14a4a2aa3f46a8505ab1e9dd3a4482971317c8ac731bfa11c3eec44b2976b1e4")
