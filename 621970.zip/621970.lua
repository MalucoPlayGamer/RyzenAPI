-- Lua provided by RyzenAPI
-- Game: Trailblazers

-- MAIN APPLICATION
addappid(621970)

-- MAIN APP DEPOTS / PACKAGES
addappid(621972,0,"634d2c1444682a751c5efab0971c26401752fdd3789ed60ead56b46fd8186a1d")
