-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Germany

-- MAIN APPLICATION
addappid(2776570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2776571, 1, "16728007fe7fce693e7767f1588c4f9721586f5e4f8ea2525e0f7cb825a380bc")

