-- Lua provided by RyzenAPI 
-- Game: Travellin Cats in Germany
addappid(2776570)
addappid(2776571, 1, "16728007fe7fce693e7767f1588c4f9721586f5e4f8ea2525e0f7cb825a380bc")
