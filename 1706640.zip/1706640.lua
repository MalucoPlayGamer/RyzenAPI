-- Lua provided by RyzenAPI
-- Game: addappid(1706640)

-- MAIN APPLICATION
addappid(1706640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706641, 1, "64a459f72e19ce69374af1712b3a938dce80d5181a75dd725a7f8d7853c1b22f")
