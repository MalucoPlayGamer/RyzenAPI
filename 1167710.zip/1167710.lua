-- Lua provided by RyzenAPI
-- Game: Sokpop S04: clutchball

-- MAIN APPLICATION
addappid(1167710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167711, 1, "b69e40c65b875de93c0585e704895a3cf4cb5a5013f6f1216b8cd1b73aa164ae")
addappid(1167712, 1, "0d91ff6de8d0b409c3601455c459c8d02bfe2506c523c6aea8cb885439144f51")

