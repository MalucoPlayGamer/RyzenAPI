-- Lua provided by RyzenAPI
-- Game: 2009920

-- MAIN APPLICATION
addappid(2009920)
-- Game: addappid(2009920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009921, 1, "4889957a3884b2de1309dc99f8e71881d60ca566df317ffbf325bdaea37e703a")
