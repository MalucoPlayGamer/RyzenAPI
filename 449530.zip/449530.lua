-- Lua provided by SkyAPI 
-- Game: Grand Pigeon's Duty
addappid(449530)
addappid(449531, 1, "f80a34858beb546ede8ab41fe721e2d04491ce16651b0780f7ccd64331791d5c")
addappid(449532, 1, "ffe5ff7b0077716a214ea2918eab8dadbd6938534c1a03692e48d6bd4d07b7d9")
addappid(449533, 1, "43cf04ac68b37d444543723579a4621f5c11a6b46720fa5724726b224feb7dba")
