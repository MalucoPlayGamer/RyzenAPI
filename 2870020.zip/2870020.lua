-- Lua provided by RyzenAPI
-- Game: Test Drive Unlimited Solar Crown Demo

-- MAIN APPLICATION
addappid(2870020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870021, 1, "71e217bfc630fc7895a4962aa58210149c4e6313a354c65801468b14de970651")

