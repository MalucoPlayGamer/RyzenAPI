-- Lua provided by RyzenAPI
-- Game: AppID 1146950

-- MAIN APPLICATION
addappid(1146950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146951, 1, "18a9144867c66adf53d8b383ac4681d34ece5487e2d67475c13204ecae9dbd7d")
addappid(1146952, 1, "6607c00f91ecca949d5f564dec740ffa80ba42adabdb5cbabce30060181d81bd")
