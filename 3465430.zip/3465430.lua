-- Lua provided by SkyAPI 
-- Game: AppID 3465430
addappid(3465430)
addappid(3465431, 1, "b13da3642509d99856348c6d87b4f094480ca4b8b7b81cd294b37fd938cfc7dc")
