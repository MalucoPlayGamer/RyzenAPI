-- Lua provided by RyzenAPI
-- Game: 3465430

-- MAIN APPLICATION
addappid(3465430)
-- Game: addappid(3465430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3465431, 1, "b13da3642509d99856348c6d87b4f094480ca4b8b7b81cd294b37fd938cfc7dc")
