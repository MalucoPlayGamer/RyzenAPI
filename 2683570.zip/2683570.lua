-- Lua provided by RyzenAPI
-- Game: Push The Cat with WASD

-- MAIN APPLICATION
addappid(2683570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683571, 1, "029fe78608929e703eaae1966626c06276a47f146f407a8961efc57e73c361be")

