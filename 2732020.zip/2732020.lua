-- Lua provided by RyzenAPI
-- Game: TV Studio Story

-- MAIN APPLICATION
addappid(2732020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732021, 1, "c070f79f4f6dfddf6b771383f60c70e30a6379ac4c1a47819b78627b07fa60a4")
