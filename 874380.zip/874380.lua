-- Lua provided by SkyAPI 
-- Game: AppID 874380
addappid(874380)
addappid(874381, 1, "de18d88c50b33958eed1822015643798e1d09cff071867ba6b52e005cd915f14")
