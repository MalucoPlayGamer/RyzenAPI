-- Lua provided by RyzenAPI
-- Game: 874380

-- MAIN APPLICATION
addappid(874380)
-- Game: addappid(874380)

-- MAIN APP DEPOTS / PACKAGES
addappid(874381, 1, "de18d88c50b33958eed1822015643798e1d09cff071867ba6b52e005cd915f14")
