-- Lua provided by RyzenAPI
-- Game: Urbex Murder

-- MAIN APPLICATION
addappid(3282980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3282981,0,"917a514ec698c1e3b07521e8e7ce2cf26baeeb419f32f7037c16efd5fd797182")

