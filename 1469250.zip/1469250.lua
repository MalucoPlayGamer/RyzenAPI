-- Lua provided by RyzenAPI
-- Game: 1469250

-- MAIN APPLICATION
addappid(1469250)
-- Game: addappid(1469250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469251, 1, "6e3a9c44a29f68beb9565a77cd97b06d0812ea8fcf07915cbeda965030f5f5b8")
