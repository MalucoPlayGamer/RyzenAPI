-- Lua provided by RyzenAPI
-- Game: Game: Fallen ~Makina and the City of Ruins~

-- MAIN APPLICATION
addappid(791330)
-- Game: addappid(791330)

-- MAIN APP DEPOTS / PACKAGES
addappid(791331, 1, "7b8bf6618f88974f48a18edfc3ed0b4779e9abc0a28887c9daeaf9c3f2aa30fe")
addappid(791332, 1, "ac70c31ba1a007f181507dda85639776e0f0ee77cdbd9e3a4cc59e09933e2909")
addappid(791333, 1, "76145786bca1ffc9c14d42321d40a33ba8467bf9bd5a843cc49316ea807d67b5")
addappid(791339, 1, "1585d3673740e4828ec5430fcfa0347d550fd468d37d465d633a16a63d5806e6")
addappid(1381600, 0, "2dab5dc97383ea54500b44ecaeb63450801e48001a7eba875bf4a5d545ac2f22")
