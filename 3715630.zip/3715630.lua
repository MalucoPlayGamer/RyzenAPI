-- Lua provided by RyzenAPI
-- Game: 3715630

-- MAIN APPLICATION
addappid(3715630)
-- Game: addappid(3715630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3715631, 1, "d32358f0a5b94387b05f6e34c1fbecbfa5e3b39ea7b10c42e29f21aafdd73c63")
