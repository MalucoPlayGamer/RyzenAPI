-- Lua provided by RyzenAPI
-- Game: Adohiinage

-- MAIN APPLICATION
addappid(3715630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3715631, 1, "d32358f0a5b94387b05f6e34c1fbecbfa5e3b39ea7b10c42e29f21aafdd73c63")

