-- Lua provided by SkyAPI 
-- Game: Blazing Strike
addappid(1999500)
addappid(1999501, 1, "a97888e7a1f8639bff57bae45974448902ab76e4c561c98290704ac737d4349f")
