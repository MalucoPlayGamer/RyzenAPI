-- Lua provided by RyzenAPI
-- Game: Blazing Strike

-- MAIN APPLICATION
addappid(1999500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999501, 1, "a97888e7a1f8639bff57bae45974448902ab76e4c561c98290704ac737d4349f")
