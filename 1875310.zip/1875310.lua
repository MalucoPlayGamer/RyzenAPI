-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2023

-- MAIN APPLICATION
addappid(1875310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1875311, 1, "a4fa397817fd35fc2d8975a2c1db8a528dc68750b4cc1391e2fb5e4f47f7410f")
addappid(1875312, 1, "1a4ea584710c275d06c1a980e70c610492cb0b82de19994aceab6b30716f4fec")

