-- Lua provided by RyzenAPI
-- Game: addappid(1300860)

-- MAIN APPLICATION
addappid(1300860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300861, 1, "0da5ee5840141150d5f9d01aaf375669a7bedaa9a1bb68888e1e2ea83856725c")
