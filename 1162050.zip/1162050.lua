-- Lua provided by RyzenAPI
-- Game: 1162050

-- MAIN APPLICATION
addappid(1162050)
-- Game: addappid(1162050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162051, 1, "da44dec781fc47152face1a6dedf387db10fc3ddb80c997526dc25647b824341")
