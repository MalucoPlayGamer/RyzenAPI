-- Lua provided by RyzenAPI
-- Game: setManifestid(788333,"6563166094848857844")

-- MAIN APPLICATION
addappid(788330)
-- Game: addappid(788330)

-- MAIN APP DEPOTS / PACKAGES
addappid(788333,0,"5117589e94107bc546fe91999bfe4be2d8a96f4bbbc106138e288ca1737db660")
