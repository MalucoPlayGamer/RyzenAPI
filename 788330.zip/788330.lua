-- Lua provided by RyzenAPI
-- Game: Varion

-- MAIN APPLICATION
addappid(788330)

-- MAIN APP DEPOTS / PACKAGES
addappid(788333,0,"5117589e94107bc546fe91999bfe4be2d8a96f4bbbc106138e288ca1737db660")

