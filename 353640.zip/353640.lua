-- Lua provided by RyzenAPI
-- Game: Train Valley

-- MAIN APPLICATION
addappid(353640)
addappid(459120)
addappid(459121)
addappid(459123)
addappid(459124)

-- MAIN APP DEPOTS / PACKAGES
addappid(353641, 1, "a0ee340e7940a0ad73abf9ca5d69629d2ec7974143aae8e636ccdf9c9ec0201d")
addappid(353642, 1, "bbd5eb0df5bc2036f35c34d5859bd4229d71af685622c83ce14b654c7ca0de19")
addappid(353643, 1, "b84cbf3b4528626b15bc7c620e06d5111ffde3ea099ac2383cf5f67d2061a8f1")
addappid(353644, 1, "2dcb7308673f702d5d78ca613433f2c944a0ef566ce331b4ea748ed02d7a98aa")
addappid(459122, 0, "563f9a488b44c0d515c66098ca0535cd141bf4090364107b97d643c21dd2ccb8")
