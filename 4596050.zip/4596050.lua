-- Lua provided by RyzenAPI
-- Game: Eros Memories: The Lewd Way to Save the World

-- MAIN APP DEPOTS / PACKAGES
addappid(4596050, 1, "2cbe561aa5151fc14053f5b3fb4b0aaf56032115d7d948443b1fc1f88cb5f392") -- Eros Memories: The Lewd Way to Save the World
addappid(4596051, 1, "4308912aacd484570c19373f5aaf0770723724c115eb13fbd3c3490fec850ce7") -- Depot 4596051
addappid(4596052, 1, "38251e446ab420eca94212e8218f55c64f3be1f6e9a1f0d7245093b6c58b4bec") -- Depot 4596052
addappid(4596053, 1, "47c7cf52b13d1f7d9ddd3f1f6f9ee412c04faefb70de44fdb3179e252cb532fd") -- Depot 4596053
addappid(4596054, 1, "bcfd50c651fe4d3d9fe9c361cd7eabe42b2dab8c54afa312e15ca55088d91f2e") -- Depot 4596054
