-- Lua provided by RyzenAPI
-- Game: 1445240

-- MAIN APPLICATION
addappid(1445240)
-- Game: addappid(1445240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445243,0,"ff8f0894e1a43b2ca30661caee8d6c970e991015f1acb659caf25232b8f1e8dd")
