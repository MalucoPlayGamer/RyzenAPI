-- Lua provided by RyzenAPI
-- Game: Witch and Council : The Card

-- MAIN APPLICATION
addappid(1775360)
-- Game: addappid(1775360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775361, 1, "a052dd5b288c0ccdf29906a15737eb3c7eed78829bf63c4cdd078951111871ca")
