-- Lua provided by RyzenAPI
-- Game: Kappa Quest

-- MAIN APPLICATION
addappid(2977060)
-- Game: addappid(2977060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977061, 1, "76d254e808dcc24d60a91651221e4fbd3443d3ab84f29e29dfbea5f460291cfc")
