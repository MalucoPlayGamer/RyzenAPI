-- Lua provided by RyzenAPI
-- Game: EFO: Escape From Outerworld

-- MAIN APPLICATION
addappid(1718070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1718071, 1, "3729be12efbd20975fd70b00a62d077986eadbb23b6c0b6d55d091d76ee7728b")

