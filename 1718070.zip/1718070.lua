-- Lua provided by RyzenAPI 
-- Game: EFO: Escape From Outerworld
addappid(1718070)
addappid(1718071, 1, "3729be12efbd20975fd70b00a62d077986eadbb23b6c0b6d55d091d76ee7728b")
