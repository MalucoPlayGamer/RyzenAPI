-- Lua provided by RyzenAPI
-- Game: Chompies!

-- MAIN APPLICATION
addappid(2061540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061541, 1, "cf192425cab874b955b78da8f244af438a970e69e979acb61cb1eb123b6aa299")

