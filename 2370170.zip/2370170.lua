-- Lua provided by RyzenAPI
-- Game: EARTH DEFENSE FORCE: WORLD BROTHERS 2

-- MAIN APPLICATION
addappid(2370170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370171, 1, "d3b5139d0a0c53b1fd1deb6e4ddf1f94e6e320c7796340757a02ebac7cb52399")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2821710)
addappid(2831380)
addappid(2831390)
addappid(2831400)
addappid(2831410)
addappid(2831420)
addappid(2831430)
addappid(2831440)
addappid(2831450)
addappid(2831460)
addappid(2831470)
addappid(2831480)
addappid(2831490)
addappid(2831500)
addappid(2831510)
addappid(2831520)
addappid(2831530)
addappid(3150850)
addappid(3150860)
addappid(3150870)
addappid(3150880)
addappid(3150890)
addappid(3150900)
addappid(3150910)
addappid(3150920)
addappid(3150930)
addappid(3150940)
