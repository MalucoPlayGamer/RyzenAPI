-- Lua provided by SkyAPI 
-- Game: AppID 1505410
addappid(1505410)
addappid(1505411, 1, "0e7f30df6e0a2ea8a5fec1ff1d91d8fff09373e2ea2372e02fd39b9d85376521")
