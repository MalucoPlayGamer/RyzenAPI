-- Lua provided by RyzenAPI
-- Game: Game: AppID 1505410

-- MAIN APPLICATION
addappid(1505410)
-- Game: addappid(1505410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505411, 1, "0e7f30df6e0a2ea8a5fec1ff1d91d8fff09373e2ea2372e02fd39b9d85376521")
