-- Lua provided by RyzenAPI
-- Game: SoleSalvation Playtest

-- MAIN APPLICATION
addappid(3002490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002491, 1, "463b6734a908cce0e1b79281e8dc82e219657f43d69f7fe2f20e2808fc37be2b")

