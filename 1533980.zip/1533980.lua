-- Lua provided by RyzenAPI
-- Game: Swiss Alps Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1533980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533981, 1, "22a4940bde433552deb63da7d07290b5d276271041b37a2dd3ebad50b47b814c")

