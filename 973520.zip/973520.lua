-- Lua provided by RyzenAPI
-- Game: Truth: Disorder II - Wallpapers

-- MAIN APPLICATION
addappid(973520)
-- Game: addappid(973520)

-- MAIN APP DEPOTS / PACKAGES
addappid(973520,0,"e39dcf74dd671617f996ed4671f22918d825d9417f16c10fe443a785fb9cf40d")
