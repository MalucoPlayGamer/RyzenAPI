-- Lua provided by RyzenAPI
-- Game: addappid(2779230)

-- MAIN APPLICATION
addappid(2779230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779231, 1, "2d009ead5460f95291c97aa7f9618ee2d20e3ad36a9e846e884afe41664d83ef")
