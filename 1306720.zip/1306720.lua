-- Lua provided by RyzenAPI
-- Game: Game: Mayhem Brawler

-- MAIN APPLICATION
addappid(1306720)
-- Game: addappid(1306720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306721, 1, "2cfdba9ed68a6231b0c40ccb9a4c9ef9a514ec8d20d27f9dd8d2ff3f393ce9dc")
