-- Lua provided by RyzenAPI
-- Game: Aeternum Vale

-- MAIN APPLICATION
addappid(1688080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688081, 1, "69a23aa9093c82259c201b40f07dd7b8b9ac3268b048eef44017487d8f41f1e5")
