-- Lua provided by RyzenAPI
-- Game: 1067440

-- MAIN APPLICATION
addappid(1067440)
-- Game: addappid(1067440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067441, 1, "f57a28fcc075a1ade7c145fff7924d83bda2a94ad9f6f2b24302b21dfb15b79a")
