-- Lua provided by RyzenAPI
-- Game: VEGAS Movie Studio 17 Steam Edition

-- MAIN APPLICATION
addappid(1253550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253551, 1, "a3c7dfc8f93f067ddee8e21192253d7a49913a315f9d4c6daf90ad015f7fac2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
