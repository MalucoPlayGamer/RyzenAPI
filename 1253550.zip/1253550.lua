-- Lua provided by RyzenAPI
-- Game: addappid(1253550)

-- MAIN APPLICATION
addappid(1253550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253551, 1, "a3c7dfc8f93f067ddee8e21192253d7a49913a315f9d4c6daf90ad015f7fac2a")
