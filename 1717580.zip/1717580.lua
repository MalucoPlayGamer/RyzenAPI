-- Lua provided by RyzenAPI
-- Game: Remorse

-- MAIN APPLICATION
addappid(1717580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1717581, 1, "e9906efafae024a51b753ab073793127e4e362ede059829a80a6f833db0019da")

