-- Lua provided by RyzenAPI
-- Game: 1717580

-- MAIN APPLICATION
addappid(1717580)
-- Game: addappid(1717580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717581, 1, "e9906efafae024a51b753ab073793127e4e362ede059829a80a6f833db0019da")
