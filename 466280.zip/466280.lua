-- Lua provided by RyzenAPI
-- Game: Super Cube Smash

-- MAIN APPLICATION
addappid(466280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(466281, 1, "824eb9f216b7ed7af1490aed37bce667ed417078c86a883dc14ded6bfb03db4c")

