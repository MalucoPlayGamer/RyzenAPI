-- Lua provided by RyzenAPI
-- Game: 466280

-- MAIN APPLICATION
addappid(466280)
-- Game: addappid(466280)

-- MAIN APP DEPOTS / PACKAGES
addappid(466281, 1, "824eb9f216b7ed7af1490aed37bce667ed417078c86a883dc14ded6bfb03db4c")
