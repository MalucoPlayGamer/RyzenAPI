-- Lua provided by RyzenAPI
-- Game: Lunacid - Tears of the Moon

-- MAIN APPLICATION
addappid(3506110)
