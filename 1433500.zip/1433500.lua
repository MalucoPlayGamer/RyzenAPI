-- Lua provided by RyzenAPI
-- Game: Hotel Transylvania: Scary-Tale Adventures

-- MAIN APPLICATION
addappid(1433500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433501, 1, "46c4e6f29ea70beb9dea54357b402f84387cc5f04489286c06209d36af5529e1")

