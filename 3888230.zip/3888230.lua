-- Lua provided by RyzenAPI
-- Game: Telenet Shooting Collection Launcher

-- MAIN APPLICATION
addappid(3888230)
