-- Lua provided by RyzenAPI
-- Game: Telenet Shooting Collection Launcher

-- MAIN APPLICATION
addappid(3888230)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3907140)
addappid(3907150)
addappid(3907160)
addappid(3907170)
