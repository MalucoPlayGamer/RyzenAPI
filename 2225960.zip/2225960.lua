-- Lua provided by RyzenAPI
-- Game: Noobs Are Coming

-- MAIN APPLICATION
addappid(2225960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225961, 1, "b35dd338e7aa221d314ac1f95cfa3fe531cb6c5d8bd668be47c7a8bbb1485ad9")

