-- Lua provided by SkyAPI 
-- Game: Noobs Are Coming
addappid(2225960)
addappid(2225961, 1, "b35dd338e7aa221d314ac1f95cfa3fe531cb6c5d8bd668be47c7a8bbb1485ad9")
