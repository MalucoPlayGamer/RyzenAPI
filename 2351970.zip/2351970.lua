-- Lua provided by RyzenAPI 
-- Game: Monster Girl 1,000
addappid(2351970)
addappid(2351971, 1, "907187e3cfac71b03a20f3720ac2fd86ca5ea68c3bed39f40928131e3307ce13")
