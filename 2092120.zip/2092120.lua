-- Lua provided by SkyAPI 
-- Game: Waifu Fighter Soundtrack
addappid(2092120)
addappid(2092121, 1, "30a459496e4ea8b9a77a7d5f4535b5ea830be719a341bb39afcdb7b8dae814a5")
addappid(2092122, 1, "2ad54e57d1cec22abd51c9cb474c99b4eeb52043c2e2900ff3395d22c9efa7f0")
