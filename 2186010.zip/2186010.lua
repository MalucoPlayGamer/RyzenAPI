-- Lua provided by RyzenAPI
-- Game: Shapebreaker - Prologue

-- MAIN APPLICATION
addappid(2186010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186011, 1, "2b7f80f32c84109eb98f95a26c2077e650fe13b3508f0def013bbc32100b978a")
