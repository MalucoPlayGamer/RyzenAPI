-- Lua provided by RyzenAPI
-- Game: AppID 2362150

-- MAIN APPLICATION
addappid(2362150)
-- Game: addappid(2362150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362151, 1, "9cf48bd9986f0cee18c8807ecb4d04b0efa5181cd6f1eadbd295bbbf776968a2")
