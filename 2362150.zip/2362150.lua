-- Lua provided by RyzenAPI
-- Game: 13iew

-- MAIN APPLICATION
addappid(2362150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2362151, 1, "9cf48bd9986f0cee18c8807ecb4d04b0efa5181cd6f1eadbd295bbbf776968a2")

