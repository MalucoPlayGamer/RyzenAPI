-- Lua provided by RyzenAPI
-- Game: Deadly Trick

-- MAIN APPLICATION
addappid(3088400) -- Deadly Trick

-- MAIN APP DEPOTS / PACKAGES
addappid(3088401, 1, "4f880c20e96498b632b317c70168316a31436b77a9df867cb61c305aefa2efcb") -- Depot 3088401
addtoken(3088400, "11328311114004228908")

