-- 3088400's Lua and Manifest Created by Hubcap Manifest
-- Deadly Trick
-- Created: July 31, 2026 at 07:24:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3088400) -- Deadly Trick
addtoken(3088400, "11328311114004228908")
-- MAIN APP DEPOTS
addappid(3088401, 1, "4f880c20e96498b632b317c70168316a31436b77a9df867cb61c305aefa2efcb") -- Depot 3088401
setManifestid(3088401, "5997370875380995634", 899854505)