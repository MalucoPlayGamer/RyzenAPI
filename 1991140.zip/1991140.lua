-- Lua provided by RyzenAPI
-- Game: Robocraft 2

-- MAIN APPLICATION
addappid(1991140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991141, 1, "d5d122cb454fd2f1ebc748294c3d49d205ab1978ce4a3b3d98096df74d2712a5")

