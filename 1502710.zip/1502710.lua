-- Lua provided by RyzenAPI
-- Game: Agent Intercept

-- MAIN APPLICATION
addappid(1502710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1502711, 1, "639d11a977b712d765bb0b3a91fcbcefa738cceb2a099be5d6b823ece02ff457")

