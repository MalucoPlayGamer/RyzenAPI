-- Lua provided by RyzenAPI
-- Game: Agent Intercept

-- MAIN APPLICATION
addappid(1502710)
-- Game: addappid(1502710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502711, 1, "639d11a977b712d765bb0b3a91fcbcefa738cceb2a099be5d6b823ece02ff457")
