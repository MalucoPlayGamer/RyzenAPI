-- Lua provided by RyzenAPI
-- Game: Menace from the Deep Soundtrack

-- MAIN APPLICATION
addappid(3278670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278671, 1, "48177b0cc988e6f58b7170edb6c2794552f4993871563250f40d54853b11b430")

