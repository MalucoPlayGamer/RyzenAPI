-- Lua provided by RyzenAPI
-- Game: addappid(455340)

-- MAIN APPLICATION
addappid(455340)

-- MAIN APP DEPOTS / PACKAGES
addappid(455341, 1, "ad4de072d9852b82a31f5058894615ae7a9aa8b73c5a30a18a946259c0c50d93")
