-- Lua provided by RyzenAPI
-- Game: Pan-Pan

-- MAIN APPLICATION
addappid(471920)
addappid(471921)
addappid(471923)
addappid(471924)
addappid(471925)
addappid(471926)

-- MAIN APP DEPOTS / PACKAGES
addappid(471922,0,"2c96b1c8b0c7a03fe6d9779a0325ccec79b5e8a841c2ea4afde77de5228197ab")
addappid(508271,0,"d591e61977f7f27bbbfc3a98b02e96a4efaa0426d9235b523142040a2b4d6684")

