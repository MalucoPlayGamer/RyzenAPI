-- Lua provided by RyzenAPI
-- Game: Game: The Shadow of the Warring States Period

-- MAIN APPLICATION
addappid(3480200)
-- Game: addappid(3480200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3480201, 1, "9df0046528b7ed2ef9a9ea06af3c749b6aeef4760b369ec6f5d8ec7afb911603")
