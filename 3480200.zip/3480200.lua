-- Lua provided by RyzenAPI 
-- Game: The Shadow of the Warring States Period
addappid(3480200)
addappid(3480201, 1, "9df0046528b7ed2ef9a9ea06af3c749b6aeef4760b369ec6f5d8ec7afb911603")
