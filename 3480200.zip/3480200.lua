-- Lua provided by RyzenAPI
-- Game: The Shadow of the Warring States Period

-- MAIN APPLICATION
addappid(3480200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3480201, 1, "9df0046528b7ed2ef9a9ea06af3c749b6aeef4760b369ec6f5d8ec7afb911603")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
