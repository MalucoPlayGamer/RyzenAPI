-- Lua provided by RyzenAPI
-- Game: Heroes of the Three Kingdoms 5

-- MAIN APPLICATION
addappid(1437860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437861, 1, "95be79ced8149dbb2fcd2145ebb9cccb3e8f21af3d2a0fc486e65828c38dce68")
addappid(1437862, 1, "a3c81c37f68dae29d764e984109d7abbb7fb65b5ef23279a023cb4a2b1b4cefe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
