-- Lua provided by RyzenAPI
-- Game: Game: ALAA-MOGUS MUST DIE

-- MAIN APPLICATION
addappid(2777230)
-- Game: addappid(2777230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777231, 1, "86f73296af8f539bc354098fd06400ffddaed92de23dd5c856748d11e2bb9c70")
