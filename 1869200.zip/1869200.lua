-- Lua provided by RyzenAPI
-- Game: The Adventures of Mr. Hat

-- MAIN APPLICATION
addappid(1869200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869201, 1, "404b691f8d2879321b75a23a7824f679b860f042bbc4942bc331f5cb10d73d65")
