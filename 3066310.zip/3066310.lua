-- Lua provided by RyzenAPI
-- Game: 3066310

-- MAIN APPLICATION
addappid(3066310)
-- Game: addappid(3066310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3066311, 1, "b13227c3b248ddf64d6fe196fc436fb336a8a76adcabea15ca5617c56fac68b3")
