-- Lua provided by RyzenAPI
-- Game: Zemblanity

-- MAIN APPLICATION
addappid(1897380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897381, 1, "1119b820081389e013e0b1faef58ebe840c16223e55d20ca87b1735e00a7ede3")

