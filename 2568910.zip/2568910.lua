-- Lua provided by RyzenAPI
-- Game: After University: Doner Simulator

-- MAIN APPLICATION
addappid(2568910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568911, 1, "d6053833904db4acce7b4886be161c77be27358c5f020f455672e2836f45d929")
