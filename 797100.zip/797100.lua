-- Lua provided by RyzenAPI
-- Game: Lock Parsing 2

-- MAIN APPLICATION
addappid(797100)

-- MAIN APP DEPOTS / PACKAGES
addappid(797101, 1, "38d320e56c8626f9b7857924bb41e6c0e4646595261a83a913f97d351928cced")
