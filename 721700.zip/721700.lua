-- Lua provided by RyzenAPI
-- Game: Holomento

-- MAIN APPLICATION
addappid(228988)
addappid(721700)
-- Game: addappid(721700)

-- MAIN APP DEPOTS / PACKAGES
addappid(721702,0,"bb84dbea0c3eeb823f86ad1e119977cc150eb4e3a461f3c1758e7e0adc8bbe9f")
