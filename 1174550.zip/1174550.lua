-- Lua provided by RyzenAPI
-- Game: 1174550

-- MAIN APPLICATION
addappid(1174550)
-- Game: addappid(1174550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174551, 1, "e4bbe7fb0360ff047bb83c27cebb3830984c1b06c80e78864978435ef39e9594")
