-- Lua provided by SkyAPI 
-- Game: AppID 1174550
addappid(1174550)
addappid(1174551, 1, "e4bbe7fb0360ff047bb83c27cebb3830984c1b06c80e78864978435ef39e9594")
