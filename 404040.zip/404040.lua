-- Lua provided by RyzenAPI
-- Game: Lords of Magic: Special Edition

-- MAIN APPLICATION
addappid(404040)

-- MAIN APP DEPOTS / PACKAGES
addappid(404041, 1, "d10626055a7d955001852c074f07076aae008bc62e38d272f99dad5009d5f3db")

