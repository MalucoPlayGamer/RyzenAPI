-- Lua provided by RyzenAPI
-- Game: addappid(2613240)

-- MAIN APPLICATION
addappid(2613240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613241, 1, "842e5ef283b5db6e95c82f7daf77c5d3132404f0526518a63596038cba3bb281")
