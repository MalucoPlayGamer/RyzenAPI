-- Lua provided by RyzenAPI
-- Game: LEGO® Jurassic World

-- MAIN APPLICATION
addappid(352400)
-- Game: addappid(352400)

-- MAIN APP DEPOTS / PACKAGES
addappid(352401, 1, "8f90accf2ae69d17b8af3f20d03010a81298e10cabe5a506afeacf7a96f6464e")
addappid(352403, 1, "b3b24883707929a4da82c6b6dc282a57534a47e9f9fc56dd97a0d598950f799b")
addappid(352404, 1, "efd7d38d4a828eee2c55efd6a1608ab3e2c3ee4c25ade7103fb384dbf0fad79b")
addappid(352405, 1, "cb4dd41fd600de9e5886cfe9a3e325a15868be91d519c98edc160e975535821b")
addappid(352406, 1, "8ccd42c2a5fff96b939af993ee839bdd1ddb28f4f8d92fc5aa4e29dac042f3f7")
addappid(367870, 0, "2dbcde1124451c5ceb31876a703e4d8ff4eae855a849c257e61e236005cd609e")
addappid(367871, 0, "be5df76c98427f835656cdde0dea25d59e180145be23095ddc73105019f46efe")
addappid(367872, 0, "6a07538a35eb9272b45a3ad970382c79b139b8cc084baa4cca7918c2ebca3184")
