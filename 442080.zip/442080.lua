-- Lua provided by RyzenAPI
-- Game: Riders of Icarus

-- MAIN APPLICATION
addappid(442080)
-- Game: addappid(442080)

-- MAIN APP DEPOTS / PACKAGES
addappid(442081, 1, "8d0be803a903fb4bba25fed43e30e589b618a3bc7f8a1239bedac75f2ba72bb9")
