-- Lua provided by RyzenAPI
-- Game: Riders of Icarus

-- MAIN APPLICATION
addappid(442080)
addappid(444030)
addappid(444031)
addappid(444032)
addappid(505410)
addappid(505420)
addappid(533600)
addappid(533601)
addappid(533602)
addappid(565000)
addappid(565001)
addappid(565002)
addappid(565090)
addappid(606320)
addappid(606321)
addappid(668040)
addappid(668050)
addappid(668060)

-- MAIN APP DEPOTS / PACKAGES
addappid(442081, 1, "8d0be803a903fb4bba25fed43e30e589b618a3bc7f8a1239bedac75f2ba72bb9")

