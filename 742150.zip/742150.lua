-- Lua provided by RyzenAPI
-- Game: Game: AppID 742150

-- MAIN APPLICATION
addappid(742150)
-- Game: addappid(742150)

-- MAIN APP DEPOTS / PACKAGES
addappid(742151, 1, "84ee5b2c0aa17ef8cb287d46a665a42a0e297c08af5294ce39e20ec2a6867629")
