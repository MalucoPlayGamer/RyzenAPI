-- Lua provided by RyzenAPI
-- Game: The Impossible Game

-- MAIN APPLICATION
addappid(251630)

-- MAIN APP DEPOTS / PACKAGES
addappid(251631, 1, "956b5a3533d992b0498d88a08036d56fdf0bba6767ba56700f1692d1e660183f")
