-- Lua provided by RyzenAPI
-- Game: The Impossible Game

-- MAIN APPLICATION
addappid(251630)

-- MAIN APP DEPOTS / PACKAGES
addappid(251631, 1, "956b5a3533d992b0498d88a08036d56fdf0bba6767ba56700f1692d1e660183f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
