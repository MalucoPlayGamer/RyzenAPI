-- Lua provided by RyzenAPI
-- Game: DFF NT: Onion Knight Starter Pack

-- MAIN APPLICATION
addappid(1022439)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022439,0,"dc92aaadcea5b4f7ab1e5786b4435fd49e85a776087128bc43328bfd3f125b78")
