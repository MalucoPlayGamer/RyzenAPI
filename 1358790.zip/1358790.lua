-- Lua provided by RyzenAPI
-- Game: Tipston Salvage

-- MAIN APPLICATION
addappid(1358790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358791, 1, "92d1523827d7780135a13690ea95869cb589567a33bd96b00e649f7a2bc4c735")

