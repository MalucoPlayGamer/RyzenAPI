-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - KTNP - Airport Twentynine Palms

-- MAIN APPLICATION
addappid(623620)

-- MAIN APP DEPOTS / PACKAGES
addappid(623620,0,"638c36494339e0c58d6ca54a2c4e4cf79d7abd44c6eb2761a96e7d79a731746f")

