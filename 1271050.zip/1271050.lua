-- Lua provided by RyzenAPI
-- Game: Shrine

-- MAIN APPLICATION
addappid(1271050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271051, 1, "2d785649f81735074f81c86b4a171a5c3d4c06d2db657076f07bfa46156c7ccd")
addappid(1271052, 1, "9ac616daa07bc2dfa2f3eb0ba73c05dfa2996b4f341bcc77ddb266f47eb4e680")

