-- Lua provided by RyzenAPI
-- Game: Game: Cannon Fodder 3

-- MAIN APPLICATION
addappid(209750)
-- Game: addappid(209750)

-- MAIN APP DEPOTS / PACKAGES
addappid(209751, 1, "27d217756896c02c43c9d212befea2762371553e0e9e5ab6755c06c5f98a6b34")
