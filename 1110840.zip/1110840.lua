-- Lua provided by RyzenAPI
-- Game: Game: KEIKA - A Puzzle Adventure

-- MAIN APPLICATION
addappid(1110840)
-- Game: addappid(1110840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110841, 1, "b3fd130922b9556589e2eab844561929f67965fa51d189bfa90899b49e084b1b")
