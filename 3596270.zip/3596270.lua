-- Lua provided by RyzenAPI
-- Game: All in Abyss: Judge the Fake - OFFICIAL DESIGN WORKS

-- MAIN APPLICATION
addappid(3596270)
-- Game: addappid(3596270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596270,0,"5071da911f985110ad193604c0038bed600a240e2797c60021b8d6a8238e68db")
