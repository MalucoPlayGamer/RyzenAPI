-- Lua provided by RyzenAPI
-- Game: Disgaea 7: Vows of the Virtueless - Soundtrack

-- MAIN APPLICATION
addappid(2540750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580360,0,"b6e754b1b0edb5588a92a7a0d12d0b33a27b5c85487b57922425f28e499ae17e")
addappid(2580361,0,"096b35d9056662e89185776e9147dbbb5fb3f1f909ff96656fe1adea29ec259f")
