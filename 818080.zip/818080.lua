-- Lua provided by RyzenAPI
-- Game: Crazy Road

-- MAIN APPLICATION
addappid(818080)

-- MAIN APP DEPOTS / PACKAGES
addappid(818081, 1, "4d648f800f9ba50f0a41e8cf44669cc62d3139ea128d9f9bbaefeedc0f7b1b85")
addappid(818082, 1, "27660a75331b68f1eb1958258a1386fc80a4095dc9f3b2a48bd0027cc95c4791")
addappid(818083, 1, "7bf868571316a67dead3b91dca1f85d17637563a3ddf38c74a903fe77a10ec4d")

