-- Lua provided by RyzenAPI 
-- Game: Tree Bonsai
addappid(875240)
addappid(875241, 1, "1f9ea8e383c6499c3e1f8afc3c8bdedcc51102479d954e91d734ff19e9e9d4cf")
addappid(875242, 1, "df723b49438b5818c2bde1aa920ff3c14a5f70d6be0578d66f0bbba9abdffba4")
addappid(875243, 1, "49d3291f252de43283904060a5cc1b10830696b2554fd91a9960ff917a57544a")
addappid(875244, 1, "975f6c425bb833c83a3c0c8c66135b348fbb06344f0aabc00442e57ebe41d435")
