-- Lua provided by RyzenAPI
-- Game: Game: World Basketball Tycoon

-- MAIN APPLICATION
addappid(260510)
-- Game: addappid(260510)

-- MAIN APP DEPOTS / PACKAGES
addappid(260511, 1, "9d05f2293a39b35d59e67db2b2f07d7dccdfc89ed697f3b847f72b390274373e")
