-- Lua provided by RyzenAPI
-- Game: Scavenger of Dunomini

-- MAIN APPLICATION
addappid(2320410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320411,0,"a186ec881ea44951cb11364aac294c64043bd21080e559098ea55d98037f87e3")

