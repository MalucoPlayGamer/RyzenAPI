-- Lua provided by RyzenAPI
-- Game: Pawnbarian

-- MAIN APPLICATION
addappid(1142080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142082,0,"de620277c4a1ada7872cec710760e51e282d53e8181422142b7858f278a482ab")
addappid(1142083,0,"836e08bcc888ed4f7758f1a7ff3a4a1e8f6dcf15dbb911d1a92d02bc460a7994")
addappid(1142084,0,"fb18eed20dfbb38990ca58586833e070bd5db3627161f9fee7d50a410af8a787")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1938870)
