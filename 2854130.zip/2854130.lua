-- Lua provided by RyzenAPI
-- Game: Left Behind

-- MAIN APPLICATION
addappid(2854130)
-- Game: addappid(2854130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854131, 1, "482fb0c565957165eaadbfc6c9ccb9160ad58e0405a9b347824c0ed8f9fd0500")
