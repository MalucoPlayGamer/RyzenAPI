-- Lua provided by RyzenAPI
-- Game: addappid(2311530)

-- MAIN APPLICATION
addappid(2311530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311531, 1, "d4d529fc561c97512b5991aeca1d3d67da87a256259b6fe382bca368ffb5aa7e")
