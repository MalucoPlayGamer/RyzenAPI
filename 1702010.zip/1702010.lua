-- Lua provided by RyzenAPI 
-- Game: Sengoku Dynasty
addappid(1702010)
addappid(1702011, 1, "f2e8eeb7cc1689a1ea8d6629b4508f6e7fecbce67e6f357edf333595eb339b5c")
addappid(2513030, 0, "18ec3a5505eba0fcd5921c7b689e7e8c9e1a0ff493714a27b24b3a7956a4e5bc")
addappid(3325090, 0, "9673fa9fb2c44fc342de6241970c6daff349558022f1267890bc136c73831a31")
