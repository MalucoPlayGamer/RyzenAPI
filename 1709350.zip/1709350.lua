-- Lua provided by RyzenAPI
-- Game: Bat Boy

-- MAIN APPLICATION
addappid(1709350)
-- Game: addappid(1709350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709351, 1, "7115326cb63863c813e26dd304c93bcfbe9a31bb8212453b38abe64dfb5b5051")
