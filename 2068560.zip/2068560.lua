-- Lua provided by RyzenAPI
-- Game: Cooper's Cleanup

-- MAIN APPLICATION
addappid(2068560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2068561, 1, "62de2d3f9d4a7441f14c19e221358be6bd523c427b96a728b994c5f525aae7be")

