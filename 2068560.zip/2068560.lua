-- Lua provided by RyzenAPI
-- Game: Cooper's Cleanup

-- MAIN APPLICATION
addappid(2068560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068561, 1, "62de2d3f9d4a7441f14c19e221358be6bd523c427b96a728b994c5f525aae7be")

