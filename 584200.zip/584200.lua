-- Lua provided by RyzenAPI
-- Game: MultiVR.se

-- MAIN APPLICATION
addappid(584200)
addappid(660250)
-- Game: addappid(584200)

-- MAIN APP DEPOTS / PACKAGES
addappid(584201, 1, "482d8ac6f3170826358f5cf1f2508f0646c18d69124c3bd832147de757a3e597")
