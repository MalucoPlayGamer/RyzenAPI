-- Lua provided by RyzenAPI
-- Game: Axiom of Maria: Prologue

-- MAIN APPLICATION
addappid(1885250)
-- Game: addappid(1885250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885251, 1, "e38f7b9fe7af4bc66b1be5237ada446735f1e5b13ed72b014ca124bcbcba1758")
