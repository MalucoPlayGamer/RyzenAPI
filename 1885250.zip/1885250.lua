-- Lua provided by RyzenAPI
-- Game: Axiom of Maria: Prologue

-- MAIN APPLICATION
addappid(1885250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885251, 1, "e38f7b9fe7af4bc66b1be5237ada446735f1e5b13ed72b014ca124bcbcba1758")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
