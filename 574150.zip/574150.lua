-- Lua provided by RyzenAPI 
-- Game: Samurai Sword VR
addappid(574150)
addappid(574151, 1, "0d2c479ed7c050c05c1514648f92d77f9753d8f39cd349e26294aa5e00786b73")
addappid(574152, 1, "1d1347a30eda757d283309988b843f2b4e2bd18a7c4ef488f35bfcd6ca79c954")
addappid(574153, 1, "e93ed93d07a5b13a3259ddfa665f78ddec8c167d46450b633865e37990d1558a")
