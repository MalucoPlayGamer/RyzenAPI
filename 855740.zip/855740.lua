-- Lua provided by RyzenAPI
-- Game: Bum Simulator

-- MAIN APPLICATION
addappid(855740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(855741, 1, "c222ca48e9d91a8eb57730fe857aea866bc41a79efa320b2130b903b9c22d45d")

