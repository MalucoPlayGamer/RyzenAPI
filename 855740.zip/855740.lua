-- Lua provided by RyzenAPI
-- Game: Bum Simulator

-- MAIN APPLICATION
addappid(855740)
-- Game: addappid(855740)

-- MAIN APP DEPOTS / PACKAGES
addappid(855741, 1, "c222ca48e9d91a8eb57730fe857aea866bc41a79efa320b2130b903b9c22d45d")
