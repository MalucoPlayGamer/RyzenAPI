-- Lua provided by RyzenAPI
-- Game: Corn Kidz 64

-- MAIN APPLICATION
addappid(2575900)
-- Game: addappid(2575900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575901, 1, "15884df84c919c4554604a6d17cb3d14b771fed343cfc55f641492064e5d1024")
