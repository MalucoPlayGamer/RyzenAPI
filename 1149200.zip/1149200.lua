-- Lua provided by RyzenAPI
-- Game: Spirit Fighters

-- MAIN APPLICATION
addappid(1149200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1149201, 1, "82ffc7a1c75181fc76101964893b15ed6aaf82c7d00c649f1cd222cee0bf6ce9")

