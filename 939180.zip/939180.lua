-- Lua provided by RyzenAPI
-- Game: addappid(939180)

-- MAIN APPLICATION
addappid(939180)
addappid(1056530)
addappid(1056540)

-- MAIN APP DEPOTS / PACKAGES
addappid(939181, 1, "2bb0d48c80d7885f965738b28cab4aac126587e3c2b1a1452460d97887f18fa8")
