-- Lua provided by RyzenAPI
-- Game: Abandoned drive-in | 廃ドライブイン

-- MAIN APPLICATION
addappid(2271420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271421, 1, "2944c7cd6c8e57442e3bdc9e19d0edbd03b6a1e5d76c5d1e2376d3fafa48f1f3")
