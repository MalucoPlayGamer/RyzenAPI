-- Lua provided by RyzenAPI
-- Game: Abandoned drive-in | 廃ドライブイン

-- MAIN APPLICATION
addappid(2271420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2271421, 1, "2944c7cd6c8e57442e3bdc9e19d0edbd03b6a1e5d76c5d1e2376d3fafa48f1f3")

