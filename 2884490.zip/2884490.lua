-- Lua provided by RyzenAPI
-- Game: 2884490

-- MAIN APPLICATION
addappid(2884490)
-- Game: addappid(2884490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884491, 1, "af8d4ece9790e33d30a0cbecba6901785883949af2e495ee52de0dc2b9ebb748")
