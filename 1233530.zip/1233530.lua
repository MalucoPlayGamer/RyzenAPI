-- Lua provided by RyzenAPI
-- Game: Knights of the Chalice 2

-- MAIN APPLICATION
addappid(1233530)
addappid(1916550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233531, 1, "4edfbc52d70fe67319128877c14b216ba3b437ba154f002ee2f58e7b33dce19f")

