-- Lua provided by RyzenAPI
-- Game: AppID 566290

-- MAIN APPLICATION
addappid(566290)
-- Game: addappid(566290)

-- MAIN APP DEPOTS / PACKAGES
addappid(566291, 1, "4c3ef4de59db5a42dccbe8e74f389ab29ae0c092e1571330015fd2c844de28d7")
