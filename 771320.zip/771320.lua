-- Lua provided by RyzenAPI
-- Game: 771320

-- MAIN APPLICATION
addappid(771320)
-- Game: addappid(771320)

-- MAIN APP DEPOTS / PACKAGES
addappid(771321, 1, "c6514dd2c2d2a61dcfc3d376e03cc90aa59f9e17e04953c8ed2aa1e992f42787")
