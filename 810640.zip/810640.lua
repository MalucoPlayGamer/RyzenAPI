-- Lua provided by RyzenAPI
-- Game: Radiis

-- MAIN APPLICATION
addappid(810640)

-- MAIN APP DEPOTS / PACKAGES
addappid(810641,0,"11a809390eefe404edfda2768f9fdbb4777d02af1c6c7122be14c8d16d9e9073")
addappid(810644,0,"e2b402b564f2c2fe338ad198126aef4504fded5423372c1feaa38d2219108d29")

