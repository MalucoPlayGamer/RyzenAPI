-- Lua provided by RyzenAPI
-- Game: 3196490

-- MAIN APPLICATION
addappid(3196490)
-- Game: addappid(3196490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196491, 1, "22491067056b321fcc93daeb1f841f2a30f465a882471e697fc4de87a43007e3")
addappid(3196492, 1, "35c80012d9c275b08ed57a052b2dcf14fcf44d37e04161c3e20ebd8ecbd8a2af")
