-- Lua provided by RyzenAPI
-- Game: Pixel Sand

-- MAIN APPLICATION
addappid(584880)

-- MAIN APP DEPOTS / PACKAGES
addappid(584881, 1, "f37e9c5f7d2ecab4ee6b2fb3e882eabe42b55a21aa6910608af246974a0f8195")
