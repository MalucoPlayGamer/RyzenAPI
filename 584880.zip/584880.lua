-- Lua provided by RyzenAPI
-- Game: Pixel Sand

-- MAIN APPLICATION
addappid(584880)

-- MAIN APP DEPOTS / PACKAGES
addappid(584881, 1, "f37e9c5f7d2ecab4ee6b2fb3e882eabe42b55a21aa6910608af246974a0f8195")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
