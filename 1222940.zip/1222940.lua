-- Lua provided by RyzenAPI
-- Game: Cragls

-- MAIN APPLICATION
addappid(1222940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222941, 1, "0859d8c335c88b078a2407cf9cc230fb1a91ab804ececed1ee20aec88158b52d")
