-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Labyrinths around the World

-- MAIN APPLICATION
addappid(3180900)
-- Game: addappid(3180900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180900,0,"d81fe3359c973d3496d36b880bc499e1d4ac3b71f895d4cb96707ab23092e535")
