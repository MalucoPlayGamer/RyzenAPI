-- Lua provided by RyzenAPI
-- Game: Game: Lucid Trips

-- MAIN APPLICATION
addappid(389260)
-- Game: addappid(389260)

-- MAIN APP DEPOTS / PACKAGES
addappid(389261, 1, "3423f61757c9f1637884086fd062e2a41dad7ff3477c0bf7c7505e5f506c6ff8")
