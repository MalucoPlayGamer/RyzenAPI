-- Lua provided by RyzenAPI
-- Game: 3689550

-- MAIN APPLICATION
addappid(3689550)
-- Game: addappid(3689550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689551, 1, "fc3576b32b88deeea46b9f4fa1d3358bb3d45581803ae96fa5fde60df30be275")
