-- Lua provided by RyzenAPI
-- Game: My Safe House

-- MAIN APPLICATION
addappid(805980)

-- MAIN APP DEPOTS / PACKAGES
addappid(805981,0,"4251b2221f3db3d26d055c1b3f1d370b62c439228213f64380b2feb8fadefe3a")

