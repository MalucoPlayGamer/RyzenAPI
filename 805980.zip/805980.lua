-- Lua provided by RyzenAPI
-- Game: My Safe House

-- MAIN APPLICATION
addappid(805980)

-- MAIN APP DEPOTS / PACKAGES
addappid(805981,0,"4251b2221f3db3d26d055c1b3f1d370b62c439228213f64380b2feb8fadefe3a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
