-- Lua provided by RyzenAPI 
-- Game: Psychoballs
addappid(801840)
addappid(801841, 1, "c31e111f95c4e9e9f1c28a04668ec01016d9d9f3b2cd08c133f177dbc52baccc")
