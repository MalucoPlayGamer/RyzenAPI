-- Lua provided by RyzenAPI
-- Game: Psychoballs

-- MAIN APPLICATION
addappid(801840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(801841, 1, "c31e111f95c4e9e9f1c28a04668ec01016d9d9f3b2cd08c133f177dbc52baccc")

