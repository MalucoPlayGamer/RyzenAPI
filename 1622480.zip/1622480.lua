-- Lua provided by RyzenAPI
-- Game: Game: Content (Free)

-- MAIN APPLICATION
addappid(1622480)
-- Game: addappid(1622480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622481, 1, "c752e9e3f575a869aeec06cc918135096f75a3e8f4689546a43af5a5717a8a64")
