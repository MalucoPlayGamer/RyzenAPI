-- Lua provided by SkyAPI 
-- Game: Content (Free)
addappid(1622480)
addappid(1622481, 1, "c752e9e3f575a869aeec06cc918135096f75a3e8f4689546a43af5a5717a8a64")
