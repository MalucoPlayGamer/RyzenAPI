-- Lua provided by RyzenAPI
-- Game: Blind Touch VR

-- MAIN APPLICATION
addappid(4507690) -- Blind Touch VR

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4507691, 1, "fb034f6563ca11c4f0253f618b319902a8c43fa5f65ff8f7cba1a2774a315e2b") -- Depot 4507691

