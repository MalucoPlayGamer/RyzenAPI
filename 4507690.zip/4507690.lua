-- 4507690's Lua and Manifest Created by Hubcap Manifest
-- Blind Touch VR
-- Created: August 12, 2026 at 09:20:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4507690) -- Blind Touch VR
-- MAIN APP DEPOTS
addappid(4507691, 1, "fb034f6563ca11c4f0253f618b319902a8c43fa5f65ff8f7cba1a2774a315e2b") -- Depot 4507691
setManifestid(4507691, "5136082047308846822", 773301287)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)