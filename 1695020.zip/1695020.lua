-- Lua provided by RyzenAPI
-- Game: addappid(1695020)

-- MAIN APPLICATION
addappid(1695020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695023,0,"0ebba168c1e786e456ed7313d989c622e1e4dd73d33fb476b05933f0c4be05cc")
