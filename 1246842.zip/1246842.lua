-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1246842)
-- Game: addappid(1246842)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246842,0,"a74459777bc177766533934b67b33a02ee6314469e83d91e82e932a013fa2cd1")
