-- Lua provided by RyzenAPI
-- Game: Life in the Dorms

-- MAIN APPLICATION
addappid(385850)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(385851, 1, "32b9088dd0cf0efde24aaf1a80524fc8d6a7303b52e316d5571974515d976206")

