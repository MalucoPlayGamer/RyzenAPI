-- Lua provided by SkyAPI 
-- Game: Life in the Dorms
addappid(385850)
addappid(385851, 1, "32b9088dd0cf0efde24aaf1a80524fc8d6a7303b52e316d5571974515d976206")
