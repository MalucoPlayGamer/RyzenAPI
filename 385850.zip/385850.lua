-- Lua provided by RyzenAPI
-- Game: Game: Life in the Dorms

-- MAIN APPLICATION
addappid(385850)
-- Game: addappid(385850)

-- MAIN APP DEPOTS / PACKAGES
addappid(385851, 1, "32b9088dd0cf0efde24aaf1a80524fc8d6a7303b52e316d5571974515d976206")
