-- Lua provided by RyzenAPI
-- Game: Bastion: Original Soundtrack

-- MAIN APPLICATION
addappid(107104)

-- MAIN APP DEPOTS / PACKAGES
addappid(107104,0,"4164c741f7d0d107048fdbb27f1d3389c3e399a38c70018672b68b6875da832b")

