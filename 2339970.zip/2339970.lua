-- Lua provided by RyzenAPI
-- Game: 2339970

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2339970)
-- Game: addappid(2339970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339972,0,"3025f7ab29053c321571d1e7839519de6cb24c1735f3dfc77d7864a74978342f")
