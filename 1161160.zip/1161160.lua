-- Lua provided by RyzenAPI
-- Game: Talesshop Puzzle

-- MAIN APPLICATION
addappid(1161160)
addappid(1175220)
addappid(1175221)
addappid(1175222)
addappid(1175223)
addappid(1247320)
addappid(4296530)
addappid(4296540)
addappid(4296550)
addappid(4296560)

