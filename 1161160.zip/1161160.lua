-- Lua provided by RyzenAPI
-- Game: Talesshop Puzzle

-- MAIN APPLICATION
addappid(1161160)

