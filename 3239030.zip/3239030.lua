-- Lua provided by RyzenAPI
-- Game: Dungeon Flowy Demo

-- MAIN APPLICATION
addappid(3239030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239031, 1, "85449f57661fbeef58bca1c15a628de62f3dc480053f5679a29e7ff376c04d22")
