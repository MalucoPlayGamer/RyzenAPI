-- Lua provided by RyzenAPI
-- Game: addappid(2743210)

-- MAIN APPLICATION
addappid(2743210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743210,0,"819f7439e1df472cde3e317ab88d765a014b49bfaab9fd3f4c98d3e627b8169b")
