-- Lua provided by RyzenAPI
-- Game: TROUBLESHOOTER: Abandoned Children - Soundtrack

-- MAIN APPLICATION
addappid(1284900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284902,0,"4d1eb31e6e06b8b6d9206c0aab00a1ca7e06b18bf3c05d948d98614647807e66")
addappid(1284903,0,"c18e2a5c80946f75c8e80fae9af1b091e903c8d1f3d2156488ad5566fb631ecc")
