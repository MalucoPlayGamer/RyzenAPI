-- Lua provided by RyzenAPI
-- Game: Game: AppID 3018560

-- MAIN APPLICATION
addappid(3018560)
-- Game: addappid(3018560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018561, 1, "5f2deadc43b0755c93690128691e6ba84fbecd08a30f1f8b3300cacb50efa58d")
