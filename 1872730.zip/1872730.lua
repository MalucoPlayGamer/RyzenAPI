-- Lua provided by RyzenAPI 
-- Game: Math Game
addappid(1872730)
addappid(1872731, 1, "3bc8121eec0e3a26198c097d879dc0c71e9c4ae877c8992640c901265a233d98")
