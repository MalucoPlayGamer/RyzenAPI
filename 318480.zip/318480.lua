-- Lua provided by RyzenAPI
-- Game: Burnstar

-- MAIN APPLICATION
addappid(318480)
addappid(378890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(318481, 1, "64fdf8171a65780cec486186794fd1009fa99a0d40e288ac873b8599c5a55191")
addappid(318482, 1, "95d7ce87e58087cebcf3b8c79ebaa4cef291ed96ef3100528b2ba7d42db66290")

