-- Lua provided by RyzenAPI
-- Game: 318480

-- MAIN APPLICATION
addappid(318480)
addappid(378890)
-- Game: addappid(318480)

-- MAIN APP DEPOTS / PACKAGES
addappid(318481, 1, "64fdf8171a65780cec486186794fd1009fa99a0d40e288ac873b8599c5a55191")
addappid(318482, 1, "95d7ce87e58087cebcf3b8c79ebaa4cef291ed96ef3100528b2ba7d42db66290")
