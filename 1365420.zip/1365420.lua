-- Lua provided by RyzenAPI
-- Game: Game: Magic Fluids

-- MAIN APPLICATION
addappid(1365420)
-- Game: addappid(1365420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365421, 1, "dc284bc044596f9f26211b334cc868b7a073ae90bb89e28690b8440855b6b424")
