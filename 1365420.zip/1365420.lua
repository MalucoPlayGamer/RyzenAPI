-- Lua provided by RyzenAPI
-- Game: Magic Fluids

-- MAIN APPLICATION
addappid(1365420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365421, 1, "dc284bc044596f9f26211b334cc868b7a073ae90bb89e28690b8440855b6b424")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
