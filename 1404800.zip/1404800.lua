-- Lua provided by RyzenAPI
-- Game: addappid(1404800)

-- MAIN APPLICATION
addappid(1404800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404801, 1, "6c1420b3a4e62029ab39803020fd6e215f80ef59e42ba28da0c7bd5be6066a20")
