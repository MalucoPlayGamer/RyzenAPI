-- Lua provided by RyzenAPI
-- Game: Game: Rogue Souls Demo

-- MAIN APPLICATION
addappid(2584410)
-- Game: addappid(2584410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584411, 1, "e2a4b766034861fb36f72d60d4b4b951ca31f150a405e67884d4aa0dfcf89281")
