-- Lua provided by RyzenAPI 
-- Game: Farlands
addappid(2252680)
addappid(2252681, 1, "73dbb18df72b601184646e91f441676cbac196f1540ba71c5b16a639e4bae4c0")
