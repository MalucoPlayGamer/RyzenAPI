-- Lua provided by RyzenAPI
-- Game: Bingo Machine

-- MAIN APPLICATION
addappid(3658620)
addappid(3659360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3658621, 1, "ac9df0655d654a2466ca477f94c349566927a8f9c50307252c4ee1d24bba4d76")

