-- Lua provided by RyzenAPI
-- Game: ghostpia Season One Demo

-- MAIN APPLICATION
addappid(2386020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386021, 1, "d41e795fd67fad1b1400eab72cdf41101b3e2a3c1e49b0f0595836b6b881271f")

