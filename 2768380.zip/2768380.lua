-- Lua provided by RyzenAPI
-- Game: Repterra

-- MAIN APPLICATION
addappid(2768380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768381,0,"a11ef14574c7c7c231f5cd190cef4fa1bb611eef644ae385265748b5a3fab152")

