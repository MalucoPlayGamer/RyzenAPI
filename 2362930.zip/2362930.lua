-- Lua provided by RyzenAPI
-- Game: 异界旅客：序章

-- MAIN APPLICATION
addappid(2362930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362931, 1, "2bfe5b1311d1df5d823ef5184d1e28c0567b0cb64d49a8fc1513e482382806c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
