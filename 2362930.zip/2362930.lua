-- Lua provided by RyzenAPI 
-- Game: 异界旅客：序章
addappid(2362930)
addappid(2362931, 1, "2bfe5b1311d1df5d823ef5184d1e28c0567b0cb64d49a8fc1513e482382806c4")
