-- Lua provided by RyzenAPI
-- Game: Biotoxin: The Dark Days

-- MAIN APPLICATION
addappid(601870)

-- MAIN APP DEPOTS / PACKAGES
addappid(601871,0,"e31be4a0c51a7b8690817d2d2f1daa03a37ceda234ad13f2db4210d34fe553a6")

