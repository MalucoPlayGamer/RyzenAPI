-- Lua provided by RyzenAPI
-- Game: AppID 1154040

-- MAIN APPLICATION
addappid(1154040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154041, 1, "d137eddc9b749d6358656f40c88e70cc449697344b9497bd51ff6597dd843a2c")
addappid(1154044, 1, "0de9c8da10a6f210ac0b201fdd3f0b2aada9cc09feb4df4d811fc040bd3a39d4")
addappid(1453890, 0, "39d1a922854652907b737ebf4ca093e1f4c1aa0898a953c8ceca655984ea5754")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
