-- Lua provided by RyzenAPI
-- Game: Game: AppID 1154040

-- MAIN APPLICATION
addappid(1154040)
-- Game: addappid(1154040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154041, 1, "d137eddc9b749d6358656f40c88e70cc449697344b9497bd51ff6597dd843a2c")
addappid(1154044, 1, "0de9c8da10a6f210ac0b201fdd3f0b2aada9cc09feb4df4d811fc040bd3a39d4")
addappid(1453890, 0, "39d1a922854652907b737ebf4ca093e1f4c1aa0898a953c8ceca655984ea5754")
