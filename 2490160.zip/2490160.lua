-- Lua provided by RyzenAPI
-- Game: addappid(2490160)

-- MAIN APPLICATION
addappid(2490160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490161, 1, "fad30fe04583b7d9a9aa55ecb695e368ed26fb145d0a440c26c1bebd55914ad2")
