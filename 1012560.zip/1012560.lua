-- Lua provided by RyzenAPI
-- Game: Snakeybus

-- MAIN APPLICATION
addappid(1012560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012562,0,"8689a68e4f882ca4b0be3657a07230bd669395891aa57e46789bdb298e2144fb")
addappid(1012563,0,"34f9f1c309cdafaf598bdcdc2bb8a1fe2c9f55a4bb773634f69c375a989c5379")

