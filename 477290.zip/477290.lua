-- Lua provided by RyzenAPI
-- Game: Magma Tsunami

-- MAIN APPLICATION
addappid(477290)
-- Game: addappid(477290)

-- MAIN APP DEPOTS / PACKAGES
addappid(477291, 1, "377020e5ecce67dbe3c9c6c96df6f7c0819be4af101e850cf4c3dec6a4473671")
addappid(477292, 1, "d8e84467b0672a93a1fcfb573b7e3f09f26e323588812a4e029615a239aaf872")
addappid(477293, 1, "60d5806c59961d66febca41f75779793bef2d853c536e1a6ad009d94dbabab4d")
addappid(477294, 1, "49b941927a4aa6b1771941acec029ea04231ed699aa93fd3be9a779c41db9b43")
