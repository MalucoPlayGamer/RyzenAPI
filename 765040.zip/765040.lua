-- Lua provided by RyzenAPI
-- Game: Defense of the Fantasy Robots

-- MAIN APPLICATION
addappid(765040)

-- MAIN APP DEPOTS / PACKAGES
addappid(765041,0,"74ca999c5b65d3aa9c0b581b1055edf59be69253dbb605fc24fe0aa9978100a1")

