-- Lua provided by RyzenAPI
-- Game: Defense of the Fantasy Robots

-- MAIN APPLICATION
addappid(765040)

-- MAIN APP DEPOTS / PACKAGES
addappid(765041,0,"74ca999c5b65d3aa9c0b581b1055edf59be69253dbb605fc24fe0aa9978100a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
