-- Lua provided by RyzenAPI
-- Game: 1911130

-- MAIN APPLICATION
addappid(1911130)
-- Game: addappid(1911130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911131, 1, "be016bd23543060b393f7ededac8e2d827cc9a2c94e4c867c76817feacc34c56")
