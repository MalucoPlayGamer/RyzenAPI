-- Lua provided by RyzenAPI
-- Game: AppID 348700

-- MAIN APPLICATION
addappid(348700)

-- MAIN APP DEPOTS / PACKAGES
addappid(348701, 1, "89a777f14d3faf1b055209c21db8ad35c6ac556268954870aa41918af7832cd9")
addappid(348702, 1, "6eefa07f01a4e1dd6b2502cd60d757caa8ad1dd415f32e49c855c0acd477dfe8")
addappid(348703, 1, "e66d5c3ad9f9510cd13e58eaf5471328c9621ccbf92bb2b51809878120284526")
addappid(348704, 1, "2f48716981da3d6c3a5c25e0f38624c8e5b58c1556c0fe3e27d3fa484c29385e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
