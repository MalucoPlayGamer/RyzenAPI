-- Lua provided by RyzenAPI
-- Game: Game: 镜地 Demo

-- MAIN APPLICATION
addappid(1688820)
-- Game: addappid(1688820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688821, 1, "d588b76c47fe457dea6aae9c8da44ed3366f062a18dc4b9fec65eabcff224785")
