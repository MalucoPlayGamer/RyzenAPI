-- Lua provided by RyzenAPI
-- Game: 358080

-- MAIN APPLICATION
addappid(358080)
-- Game: addappid(358080)

-- MAIN APP DEPOTS / PACKAGES
addappid(358081, 1, "4c69c249c9bafaaf74bbe6387c510a5cd5b16eb30884bb748da596054cb9605a")
