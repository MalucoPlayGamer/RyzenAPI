-- Lua provided by RyzenAPI
-- Game: No Turning Back: The Pixel Art Action-Adventure Roguelike

-- MAIN APPLICATION
addappid(358080)

-- MAIN APP DEPOTS / PACKAGES
addappid(358081, 1, "4c69c249c9bafaaf74bbe6387c510a5cd5b16eb30884bb748da596054cb9605a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1339010)
addappid(1339011)
addappid(1339012)
addappid(1339400)
addappid(1339770)
addappid(1339771)
addappid(1342870)
addappid(1342880)
addappid(1342881)
addappid(1342882)
addappid(1342883)
addappid(1355280)
addappid(1355281)
addappid(1355282)
addappid(1355283)
addappid(1359780)
addappid(1368980)
addappid(1368981)
addappid(1368982)
addappid(1368983)
addappid(1368984)
addappid(1370900)
addappid(1370901)
addappid(1370902)
addappid(1372020)
addappid(1372021)
