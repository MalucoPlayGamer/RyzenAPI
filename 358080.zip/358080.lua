-- Lua provided by RyzenAPI
-- Game: No Turning Back: The Pixel Art Action-Adventure Roguelike

-- MAIN APPLICATION
addappid(358080)

-- MAIN APP DEPOTS / PACKAGES
addappid(358081, 1, "4c69c249c9bafaaf74bbe6387c510a5cd5b16eb30884bb748da596054cb9605a")

