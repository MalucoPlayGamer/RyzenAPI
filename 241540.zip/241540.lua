-- Lua provided by RyzenAPI
-- Game: State of Decay

-- MAIN APPLICATION
addappid(241540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(241541, 1, "0920be735ac293e7239fd59281947688658aca80975371b55bb0f9731860f642")
addappid(259040, 0, "aa233e11a648c9a6265c6de6622fd80cac25a2818fce0747ffeeb9290bfd8702")
addappid(259041, 0, "d2b4149580106f83ac63ca91e6debdb7f6c9486cf33912d182cdcee13fc7f09f")

