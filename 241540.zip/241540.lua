-- Lua provided by RyzenAPI
-- Game: Game: State of Decay

-- MAIN APPLICATION
addappid(241540)
-- Game: addappid(241540)

-- MAIN APP DEPOTS / PACKAGES
addappid(241541, 1, "0920be735ac293e7239fd59281947688658aca80975371b55bb0f9731860f642")
addappid(259040, 0, "aa233e11a648c9a6265c6de6622fd80cac25a2818fce0747ffeeb9290bfd8702")
addappid(259041, 0, "d2b4149580106f83ac63ca91e6debdb7f6c9486cf33912d182cdcee13fc7f09f")
