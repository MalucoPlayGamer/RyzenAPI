-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Deluxe Costume - Mitsuhide Akechi

-- MAIN APPLICATION
addappid(1649711)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649711,0,"e533486a21be97055c1a063b7d9a2cdef238c4a1803afb9ef4eff8e741d6877f")

