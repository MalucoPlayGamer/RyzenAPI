-- Lua provided by SkyAPI 
-- Game: AppID 3125900
addappid(3125900)
addappid(3125901, 1, "2cc97be869a6e7cb6f5c19ff1160cc96a7f2632c393b3b9e569f66b210cd4ed1")
