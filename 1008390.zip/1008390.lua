-- Lua provided by SkyAPI 
-- Game: Crazy Mosquito Simulator
addappid(1008390)
addappid(1008391, 1, "effc26a58199119f1d1d56b31402d222f2962c01e57c4e546fad21761c7c97d9")
