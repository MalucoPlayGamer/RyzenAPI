-- Lua provided by RyzenAPI
-- Game: Crazy Mosquito Simulator

-- MAIN APPLICATION
addappid(1008390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008391, 1, "effc26a58199119f1d1d56b31402d222f2962c01e57c4e546fad21761c7c97d9")

