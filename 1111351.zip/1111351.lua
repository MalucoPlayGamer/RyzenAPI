-- Lua provided by RyzenAPI
-- Game: addappid(1111351)

-- MAIN APPLICATION
addappid(1111351)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111351,0,"15eaf913a8fb8f1d5db04c7c24246974c7f3b07f473fe4616381e75b0560f93e")
