-- Lua provided by RyzenAPI
-- Game: Smurfs Kart

-- MAIN APPLICATION
addappid(1911220)
-- Game: addappid(1911220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911221, 1, "19c4d57bb6753c0ad30671358db4e91a51874e12a60f90266d8576cbe4847864")
