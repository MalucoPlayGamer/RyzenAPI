-- Lua provided by RyzenAPI
-- Game: Counterpact

-- MAIN APPLICATION
addappid(2061750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2061751, 1, "bcda959476628afca89ef788a20699914040c626e960cb8343242204148de5ab")
addappid(2061752, 1, "f19ec1efe8022d7d46a8dd5572d847559ff76bff69865467bab4312d7184a8eb")

