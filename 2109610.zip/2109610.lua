-- Lua provided by RyzenAPI
-- Game: addappid(2109610)

-- MAIN APPLICATION
addappid(2109610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109611, 1, "cda522e2ff76405b521426de166aaeb049689810999aebb47800b881b5e7950c")
