-- Lua provided by RyzenAPI
-- Game: Strange Place

-- MAIN APPLICATION
addappid(3813280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3813281, 1, "0632ac26cb66477c5f9bfee6d844de698fadfaa6ea05128b68618a75ad73cc4a")
