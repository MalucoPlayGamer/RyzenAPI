-- Lua provided by RyzenAPI
-- Game: Ace of Seafood - Original Soundtrack

-- MAIN APPLICATION
addappid(532730)

-- MAIN APP DEPOTS / PACKAGES
addappid(532730,0,"0daec95f073e125baec0ef69c08877c1d30705cc422d6d7a565e43a5a29b7601")
