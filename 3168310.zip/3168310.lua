-- Lua provided by RyzenAPI
-- Game: True Fear: Forsaken Souls Part 3

-- MAIN APPLICATION
addappid(3168310)
-- Game: addappid(3168310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168311, 1, "24e26784c021d8a9d38a4208acc47e5ed7c413279c362de32643c5a7d8129c64")
addappid(3168312, 1, "0b46386d35b68514cd6ff6ecb748cd75423ba568725f7f0b1e809cad7875cd6d")
