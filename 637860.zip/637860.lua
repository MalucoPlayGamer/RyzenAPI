-- Lua provided by RyzenAPI
-- Game: AppID 637860

-- MAIN APPLICATION
addappid(637860)
-- Game: addappid(637860)

-- MAIN APP DEPOTS / PACKAGES
addappid(637861, 1, "f0ffd484e5be9284e7a2e2ddddf89a8090d5349e9f637580758311694ef76742")
