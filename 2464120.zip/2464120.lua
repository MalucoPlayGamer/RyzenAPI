-- Lua provided by SkyAPI 
-- Game: AppID 2464120
addappid(2464120)
addappid(2464121, 1, "89709ae7a89f718443b762ee2d8dca90d9c7ddf98e7cda5e40ad016dfbacf375")
addappid(2543530, 0, "e22e537b380b4c63aa9a159fb0610f865ce3e9b8e8c332c1945133c96abafca4")
