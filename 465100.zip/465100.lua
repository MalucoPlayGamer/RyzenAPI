-- Lua provided by RyzenAPI 
-- Game: LUNA The Shadow Dust
addappid(465100)
addappid(465101, 1, "83fa5fe2722d8e8d110d015adeeccb6abf44d046f5d3eb60acd07a48a5c93be7")
addappid(465102, 1, "e02c4e7d8385d4b15e2276950c204b72b34bfe14657bfe6ecb14d87e945ad4d5")
addappid(465103, 1, "6ab32fc2dc3fadb26f8287e9a63ab814b49ed4cfd299a0bcc836d553ca048403")
addappid(465104, 1, "8f1e5d60487bbe15c7fadb471cb7e945ba5e59d1dc48ab017845a9d2e08b9a6c")
addappid(465105, 1, "c183bd471eac7f80ef522cda5d274151e17fe1efb484c80b3dd0a38ffb9529bd")
addappid(465106, 1, "789a75ab26ecaf7d01f25ec93a62307a90ddcba8ad5bb2c2e14b3b1a3290ee60")
addappid(465107, 1, "5e14e38e92ed241ed51569c5ace2b0acad64be6f180f65ea97ccf99beb6d6458")
addappid(465108, 1, "247198efa9caca7437ea859bcaf9e71c087d3128c2a39fbdc43630eda124a22a")
addappid(465109, 1, "193cbae82cdec120ddbe321379567acd6cf35b8605aee0560fef2d4c71b46146")
