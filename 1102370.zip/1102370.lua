-- Lua provided by RyzenAPI
-- Game: Dr. Derk's Mutant Battlegrounds

-- MAIN APPLICATION
addappid(1102370)
addappid(1102371)
addappid(1102373)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102372,0,"c91808681bbba11b1dac00687152ac60cc6b65f15fd2c3e21f54ae98cec79d3c")

