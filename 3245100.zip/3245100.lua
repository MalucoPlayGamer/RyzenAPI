-- Lua provided by RyzenAPI
-- Game: Critter Café Demo

-- MAIN APPLICATION
addappid(3245100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245101, 1, "8b70dad4e754bd5df89a93cc69929bf91ddc9fc1a9783368b087e7144beaa21c")
