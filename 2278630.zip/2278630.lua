-- Lua provided by RyzenAPI
-- Game: Game: Livestream 2: Escape from Togaezuka Happy Place

-- MAIN APPLICATION
addappid(2278630)
-- Game: addappid(2278630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278631, 1, "2d3cc7c848a0f385bdfc55d67835bfcf08cd5627b52d40fbeb613cbd4d22de91")
