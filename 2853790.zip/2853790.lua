-- Lua provided by RyzenAPI
-- Game: Wyvern Studios Solitaire: 30th Aniversary Edition

-- MAIN APPLICATION
addappid(2853790)
-- Game: addappid(2853790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853791, 1, "e197a442c192b1f78bde4350bdb72c020433f06339ff49ca9d1e452b73170cc2")
