-- Lua provided by RyzenAPI
-- Game: Space Raiders in Space

-- MAIN APPLICATION
addappid(1278210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278211, 1, "a60876864015a3d7751ab30509157c66cdfbdd23cebe5304c7002c6378f21077")
