-- Lua provided by RyzenAPI
-- Game: Steel Judgment

-- MAIN APPLICATION
addappid(3394690) -- Steel Judgment

-- MAIN APP DEPOTS / PACKAGES
addappid(3394691, 1, "85af2a54abf894e2d09ea21db26e228202018ab4330ff78bb5ffbfe52c9a8737") -- Depot 3394691

