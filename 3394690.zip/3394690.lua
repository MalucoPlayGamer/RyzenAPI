-- 3394690's Lua and Manifest Created by Hubcap Manifest
-- Steel Judgment
-- Created: August 01, 2026 at 13:54:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3394690) -- Steel Judgment
-- MAIN APP DEPOTS
addappid(3394691, 1, "85af2a54abf894e2d09ea21db26e228202018ab4330ff78bb5ffbfe52c9a8737") -- Depot 3394691
setManifestid(3394691, "1412141075394608024", 1134649398)