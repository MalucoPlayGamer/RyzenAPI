-- Lua provided by RyzenAPI
-- Game: 1706480

-- MAIN APPLICATION
addappid(1706480)
-- Game: addappid(1706480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706481, 1, "55272f7bf788d6e611194d60237af00de00b91ece6c87aef51d093fcf0a81db3")
