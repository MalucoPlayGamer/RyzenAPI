-- Lua provided by SkyAPI 
-- Game: Alive Paint
addappid(1706480)
addappid(1706481, 1, "55272f7bf788d6e611194d60237af00de00b91ece6c87aef51d093fcf0a81db3")
