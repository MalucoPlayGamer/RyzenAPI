-- Lua provided by RyzenAPI
-- Game: addappid(844420)

-- MAIN APPLICATION
addappid(844420)

-- MAIN APP DEPOTS / PACKAGES
addappid(844421, 1, "83b3d5f507097a5bbd5deae765a466ceae0161034b89e7be855688884998c769")
