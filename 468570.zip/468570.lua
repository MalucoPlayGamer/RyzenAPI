-- Lua provided by RyzenAPI
-- Game: De-Void

-- MAIN APPLICATION
addappid(468570)
-- Game: addappid(468570)

-- MAIN APP DEPOTS / PACKAGES
addappid(468571, 1, "f55232c71718ef3415ddf6ad35fd2e20bbeb84c4d01603c188d0e78b987d6718")
