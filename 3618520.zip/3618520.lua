-- Lua provided by RyzenAPI
-- Game: Twin Shot Deluxe

-- MAIN APPLICATION
addappid(3618520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618521,0,"1adef6722035f86e193a7a1ffa56186f76bf6c3303a90bf8e07f33ea99f992a9")
addappid(3618522,0,"7fe1f24ac7817e9a58a8958fcd5717db646cb22da478fcbb6db19df5bb17551a")

