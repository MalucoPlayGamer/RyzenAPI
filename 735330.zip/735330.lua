-- Lua provided by RyzenAPI
-- Game: Figment - Soundtrack

-- MAIN APPLICATION
addappid(735330)

-- MAIN APP DEPOTS / PACKAGES
addappid(735331, 1, "de2adf49dedf76ef8b7d85ecc424eeddd71b06cff964501e9aa476ae4eaa7888")

