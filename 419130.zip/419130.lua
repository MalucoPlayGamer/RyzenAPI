-- Lua provided by RyzenAPI
-- Game: 419130

-- MAIN APPLICATION
addappid(419130)
addappid(471620)
addappid(471621)
addappid(471622)
addappid(471623)
-- Game: addappid(419130)

-- MAIN APP DEPOTS / PACKAGES
addappid(419131, 1, "727b5ebe091d03748120a52debd29957ca28f5049367d2a8f0b91153cbb6ce09")
