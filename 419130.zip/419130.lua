-- Lua provided by RyzenAPI
-- Game: Strength of the Sword ULTIMATE

-- MAIN APPLICATION
addappid(419130)
addappid(471620)
addappid(471621)
addappid(471622)
addappid(471623)
addappid(914770)
addappid(914780)
addappid(914790)
addappid(914810)
addappid(914820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(419131, 1, "727b5ebe091d03748120a52debd29957ca28f5049367d2a8f0b91153cbb6ce09")

