-- Lua provided by RyzenAPI 
-- Game: AppID 662940
addappid(662940)
addappid(662941, 1, "95897191825413a99bf098f50e44ff7d49301a408f46136abf45535b0fd1f2b1")
