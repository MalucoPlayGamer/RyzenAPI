-- Lua provided by RyzenAPI
-- Game: Game: AppID 662940

-- MAIN APPLICATION
addappid(662940)
-- Game: addappid(662940)

-- MAIN APP DEPOTS / PACKAGES
addappid(662941, 1, "95897191825413a99bf098f50e44ff7d49301a408f46136abf45535b0fd1f2b1")
