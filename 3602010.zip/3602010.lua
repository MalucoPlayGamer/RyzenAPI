-- Lua provided by RyzenAPI
-- Game: 3602010

-- MAIN APPLICATION
addappid(3602010)
-- Game: addappid(3602010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602011, 1, "4665d78b757442c11623e1cb4c0cae38b90ea0b611e2f32b2e25969d73bed764")
