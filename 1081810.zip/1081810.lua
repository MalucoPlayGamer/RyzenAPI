-- Lua provided by RyzenAPI
-- Game: 时之扉

-- MAIN APPLICATION
addappid(1081810)
-- Game: addappid(1081810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081811, 1, "c5374520377569e6740f261f5d4d5a9a77d368b6544ecbb2dfbe9d8024d33012")
