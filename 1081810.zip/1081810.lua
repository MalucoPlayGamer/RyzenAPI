-- Lua provided by RyzenAPI
-- Game: 时之扉

-- MAIN APPLICATION
addappid(1081810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081811, 1, "c5374520377569e6740f261f5d4d5a9a77d368b6544ecbb2dfbe9d8024d33012")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
