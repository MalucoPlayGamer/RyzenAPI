-- Lua provided by RyzenAPI
-- Game: Rogue Soulstone Demo

-- MAIN APPLICATION
addappid(2002640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002641, 1, "3a62178f32d8afd1ab2a8275d3cd0d3a9c22429974c20a84033deb9f64b8570e")
