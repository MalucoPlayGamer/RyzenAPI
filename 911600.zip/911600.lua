-- Lua provided by RyzenAPI
-- Game: AppID 911600

-- MAIN APPLICATION
addappid(911600)
-- Game: addappid(911600)

-- MAIN APP DEPOTS / PACKAGES
addappid(911601, 1, "58d4eca92acd2e9d299408c50189776830be7d6f804190de7a0a2433c9be2e38")
