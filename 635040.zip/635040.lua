-- Lua provided by RyzenAPI
-- Game: AppID 635040

-- MAIN APPLICATION
addappid(635040)
-- Game: addappid(635040)

-- MAIN APP DEPOTS / PACKAGES
addappid(635041, 1, "118b31271e9e73c40a1ee9b0dd784e16f3685edf1c8e66ad180b67deeb404c67")
