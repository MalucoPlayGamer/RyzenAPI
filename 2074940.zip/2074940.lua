-- Lua provided by RyzenAPI
-- Game: addappid(2074940)

-- MAIN APPLICATION
addappid(2074940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074942,0,"de06357da75fab13c84ececb8dc921af1aabe546baec8e33b650b0bb61a08de9")
