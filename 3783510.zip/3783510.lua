-- Lua provided by RyzenAPI
-- Game: addappid(3783510)

-- MAIN APPLICATION
addappid(3783510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3783511, 1, "f4195fba89b7dc085b67cf9aad9fd44c50cf14f65b2801cf7ecd93c6e1b35932")
