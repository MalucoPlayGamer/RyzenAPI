-- Lua provided by RyzenAPI
-- Game: Game: 约会模拟器：原型

-- MAIN APPLICATION
addappid(1486430)
-- Game: addappid(1486430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486431, 1, "6eeaf99945efffe0c7184354eb12357ece5af2d58b252678e5797b274e53bb68")
