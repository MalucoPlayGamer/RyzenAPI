-- Lua provided by RyzenAPI
-- Game: Akihabara - Feel the Rhythm

-- MAIN APPLICATION
addappid(565660)

-- MAIN APP DEPOTS / PACKAGES
addappid(565661, 1, "597b07f42dea001de3368e94f7e790e1c140a64d8c24bc3adb2385fdff46f0c7")
addappid(571580, 0, "9a303817cd26ca62cac03ad1a4780a11856997a9ca62d38d3ce004af459fda28")
addappid(587980, 0, "187165961bc3f20320645dd972386b6fc4e56ee455a7b2bf65f07e510a1927dd")

