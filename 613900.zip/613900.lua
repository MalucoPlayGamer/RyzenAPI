-- Lua provided by RyzenAPI
-- Game: AppID 613900

-- MAIN APPLICATION
addappid(613900)

-- MAIN APP DEPOTS / PACKAGES
addappid(613901, 1, "53cd0c4bfc97eab6b81e3ad8cc2b87f02befdcfee5593170ed6064fe770a8710")

