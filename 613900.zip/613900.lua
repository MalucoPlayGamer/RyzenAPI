-- Lua provided by RyzenAPI
-- Game: AppID 613900

-- MAIN APPLICATION
addappid(613900)

-- MAIN APP DEPOTS / PACKAGES
addappid(613901, 1, "53cd0c4bfc97eab6b81e3ad8cc2b87f02befdcfee5593170ed6064fe770a8710")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1348090)
addappid(1351570)
addappid(1351571)
addappid(1351572)
addappid(1424320)
addappid(1568390)
addappid(1641150)
addappid(1643620)
addappid(1643630)
addappid(1759370)
addappid(1837850)
addappid(1983500)
