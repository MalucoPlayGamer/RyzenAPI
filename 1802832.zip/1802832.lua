-- Lua provided by RyzenAPI
-- Game: 1802832

-- MAIN APPLICATION
addappid(1802832)
-- Game: addappid(1802832)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802832,0,"4867e77d3fce1d227817b5b575323f9d9af7dcebe21f9887a3c9b857dd992ee9")
