-- Lua provided by RyzenAPI
-- Game: 3505040

-- MAIN APPLICATION
addappid(3505040)
-- Game: addappid(3505040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505041, 1, "83d38f14aa424bba40f8ef772a7133d40978a75b6914d0bd565852853f4bb9e3")
