-- Lua provided by RyzenAPI
-- Game: Nightmare Of Melanie

-- MAIN APPLICATION
addappid(913910)
addappid(913911)

-- MAIN APP DEPOTS / PACKAGES
addappid(913912,0,"1315fccca28e5f5fcab0a100e5b501d38485cd281be1930632fa1234f05652ca")
addappid(913913,0,"7a4d62509cbf84054c6345e205488ef41e7f1b508264e808150d5619cedbfc43")

