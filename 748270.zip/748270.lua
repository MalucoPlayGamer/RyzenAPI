-- Lua provided by RyzenAPI
-- Game: addappid(748270)

-- MAIN APPLICATION
addappid(748270)

-- MAIN APP DEPOTS / PACKAGES
addappid(748271, 1, "10885ec9ed7207ad80ab59755f80f3fbb05c1bf45178406e14f306c5eaed1f21")
