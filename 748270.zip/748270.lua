-- Lua provided by SkyAPI 
-- Game: VR Roller Coaster - Cave Depths
addappid(748270)
addappid(748271, 1, "10885ec9ed7207ad80ab59755f80f3fbb05c1bf45178406e14f306c5eaed1f21")
