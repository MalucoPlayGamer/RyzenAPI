-- Lua provided by RyzenAPI
-- Game: AppID 1161930

-- MAIN APPLICATION
addappid(1161930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1161931, 1, "10f953a447e8d47f84c4bd911af5e920d5ff59275ca6cb0a826d967f9c6e6ccb")

