-- Lua provided by RyzenAPI
-- Game: 2180050

-- MAIN APPLICATION
addappid(2180050)
-- Game: addappid(2180050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180051, 1, "8e2b4b702d29825aa206be9fe3b525b29321b2e65f494f79a10b578a6da4cf3a")
