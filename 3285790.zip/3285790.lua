-- Lua provided by RyzenAPI
-- Game: SpyLens: Sex in focus

-- MAIN APPLICATION
addappid(3285790)
-- Game: addappid(3285790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285791, 1, "d93767a9761da55e87846fb29dd472a1d0b199fd447ce488f8d3364fdf2a5dd1")
