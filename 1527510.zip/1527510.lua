-- Lua provided by RyzenAPI
-- Game: Game: Romeow: in the cracked world

-- MAIN APPLICATION
addappid(1527510)
-- Game: addappid(1527510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527511, 1, "2f42e541e339693e930773983d2a1773ef8740d3326063eeb2269704e93c97e0")
