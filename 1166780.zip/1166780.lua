-- Lua provided by RyzenAPI
-- Game: AppID 1166780

-- MAIN APPLICATION
addappid(1166780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166781, 1, "8ef36cbaab9db038d5f7fd0a2ea7961d626c5ff4afca04df1c31df21be984e21")
