-- Lua provided by RyzenAPI 
-- Game: Spirittracker
addappid(1739560)
addappid(1739561, 1, "3e6fa3d97442194833917326ac5dabe510d725e10b5448bd236a60570b7eb5e8")
