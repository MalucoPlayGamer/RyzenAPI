-- Lua provided by RyzenAPI
-- Game: MiniCar Race - 极品飞车2019 Mini

-- MAIN APPLICATION
addappid(888970)

-- MAIN APP DEPOTS / PACKAGES
addappid(888971, 1, "46aae2545c09c204e6dd6328b7bbb91a86026a2ad31a148bedd1bc776146337d")

