-- Lua provided by RyzenAPI
-- Game: Backpack Battles

-- MAIN APPLICATION
addappid(2427700)
-- Game: addappid(2427700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427701, 1, "40bbfd9e7aaf1830bd55729aa2c13d2eed07e0ed92dd6f9d35ced2a7b7dde436")
addappid(2427702, 1, "392b31e91e8d666f24765d8ef4fed439f1e7d82cedd1a8fc17ed77f519ef4361")
