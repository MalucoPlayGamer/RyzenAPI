-- Lua provided by RyzenAPI
-- Game: Prison Simulator

-- MAIN APPLICATION
addappid(842180)

-- MAIN APP DEPOTS / PACKAGES
addappid(842181, 1, "613f14926c14907812b3dafc61eace8ecad7bea31eb7d101181b78dbfdca03fb")

