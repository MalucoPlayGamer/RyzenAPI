-- Lua provided by RyzenAPI
-- Game: The Chosen Warriors

-- MAIN APPLICATION
addappid(610730)

-- MAIN APP DEPOTS / PACKAGES
addappid(610731, 1, "c2b2d1915e0c2772a363e8ab3fa693b139a3ec1deb582cb80a251142096ea324")

