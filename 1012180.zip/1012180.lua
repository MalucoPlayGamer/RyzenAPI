-- Lua provided by RyzenAPI
-- Game: addappid(1012180)

-- MAIN APPLICATION
addappid(1012180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012181, 1, "491fa54aa6ebfd01177265e00422d21a74c1f9a2b36fa3469818b018fe8c8dae")
