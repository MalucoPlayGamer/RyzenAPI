-- Lua provided by RyzenAPI
-- Game: The Great C

-- MAIN APPLICATION
addappid(841460)
addappid(939441)

-- MAIN APP DEPOTS / PACKAGES
addappid(841461, 1, "290c12302b67c39707c4aa647cccc88c5fd98f17529c40b5791ed1b6c9d93077")
