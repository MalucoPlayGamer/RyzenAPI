-- Lua provided by RyzenAPI 
-- Game: Sutekina kanojo no tsukurikata  Demo
addappid(1479690)
addappid(1479691, 1, "790fd5935c1ce76cd69b280104c541d7c04bc0e487f235eb932a4afbcb6e3a15")
