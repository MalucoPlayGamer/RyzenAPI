-- Lua provided by RyzenAPI 
-- Game: Freon
addappid(1721520)
addappid(1721521, 1, "d5d4d07d461a2161aaf265f4ef20d872d9f13caa110e4c46eaa9a21067f59006")
