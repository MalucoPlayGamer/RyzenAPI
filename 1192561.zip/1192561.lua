-- Lua provided by RyzenAPI
-- Game: Yu Escape / Monday - Shi's SEXtra Supporter Pack

-- MAIN APPLICATION
addappid(1192561)
-- Game: addappid(1192561)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192561,0,"f87d03323f1cb69dc8c4248069783414e82b6fb9ed6c7c2199484282179db384")
