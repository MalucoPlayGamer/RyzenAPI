-- Lua provided by SkyAPI 
-- Game: AppID 3094130
addappid(3094130)
addappid(3094131, 1, "900d9788806da3381ae576e5caa4507d206934ee0ea152f3e3df247e19a245de")
