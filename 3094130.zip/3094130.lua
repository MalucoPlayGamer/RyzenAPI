-- Lua provided by RyzenAPI
-- Game: Tales of Wind: Radiant Rebirth

-- MAIN APPLICATION
addappid(3094130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094131, 1, "900d9788806da3381ae576e5caa4507d206934ee0ea152f3e3df247e19a245de")
