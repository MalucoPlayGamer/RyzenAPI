-- Lua provided by RyzenAPI
-- Game: 恋与未歇之雨

-- MAIN APPLICATION
addappid(3757560)
addappid(4226000)
addappid(4227670)

