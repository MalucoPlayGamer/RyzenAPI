-- Lua provided by RyzenAPI
-- Game: addappid(2805060)

-- MAIN APPLICATION
addappid(2805060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805061, 1, "58a8b7bf5c8f32cddebf3f8b254554051a08dc6b561fdada408f932afaee3ca9")
