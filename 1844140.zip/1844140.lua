-- Lua provided by RyzenAPI
-- Game: Game: Jester`s Theater Museum

-- MAIN APPLICATION
addappid(1844140)
-- Game: addappid(1844140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844141, 1, "fe9f590d479dcb23803c06c620c8d2139458329c2c100f9888218e6db7a98477")
addappid(2011810, 1, "2ed8685c5775093c59e19ee805bf9df7e34587e8b6b6d15838aa169dc9aeb187")
addappid(2057600, 0, "9efb125d2c9b1665dcbaf3f6d49cda2d2827949711ee98a9c1e8a47a1de5a3ff")
