-- Lua provided by RyzenAPI
-- Game: Jester`s Theater Museum

-- MAIN APPLICATION
addappid(1844140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844141, 1, "fe9f590d479dcb23803c06c620c8d2139458329c2c100f9888218e6db7a98477")
addappid(2011810, 1, "2ed8685c5775093c59e19ee805bf9df7e34587e8b6b6d15838aa169dc9aeb187")
addappid(2057600, 0, "9efb125d2c9b1665dcbaf3f6d49cda2d2827949711ee98a9c1e8a47a1de5a3ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
