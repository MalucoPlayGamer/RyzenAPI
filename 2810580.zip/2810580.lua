-- Lua provided by RyzenAPI
-- Game: AppID 2810580

-- MAIN APPLICATION
addappid(2810580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810581, 1, "0b9e12386d04cf3e94a03554ac6da5c6c016eb457bfac8a6cdfb4d56996e0115")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
