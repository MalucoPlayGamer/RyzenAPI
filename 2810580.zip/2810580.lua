-- Lua provided by RyzenAPI
-- Game: AppID 2810580

-- MAIN APPLICATION
addappid(2810580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810581, 1, "0b9e12386d04cf3e94a03554ac6da5c6c016eb457bfac8a6cdfb4d56996e0115")
