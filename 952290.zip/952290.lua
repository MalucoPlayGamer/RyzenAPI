-- Lua provided by RyzenAPI
-- Game: 952290

-- MAIN APPLICATION
addappid(952290)
-- Game: addappid(952290)

-- MAIN APP DEPOTS / PACKAGES
addappid(952291, 1, "050fd2730780f8941aea3bb502e0bd6c5f696a0e8d9e33225d8fdae033be879e")
addappid(952292, 1, "7b091fcbb0e467ed4cd6db3aec56fb5c338c4d018b634f09fcf9438cbabf101c")
addappid(952293, 1, "397dd95d085d1c423482d6ecc6f93af7fa5f2233c34684be6b4a2f29707acd81")
