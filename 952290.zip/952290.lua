-- Lua provided by RyzenAPI
-- Game: Zueirama

-- MAIN APPLICATION
addappid(952290)

-- MAIN APP DEPOTS / PACKAGES
addappid(952291, 1, "050fd2730780f8941aea3bb502e0bd6c5f696a0e8d9e33225d8fdae033be879e")
addappid(952292, 1, "7b091fcbb0e467ed4cd6db3aec56fb5c338c4d018b634f09fcf9438cbabf101c")
addappid(952293, 1, "397dd95d085d1c423482d6ecc6f93af7fa5f2233c34684be6b4a2f29707acd81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
