-- Lua provided by RyzenAPI
-- Game: Game: College Sex Party 🔞

-- MAIN APPLICATION
addappid(2560650)
-- Game: addappid(2560650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560651, 1, "60a605bace406ac5fea90f652b6085253d69415334fb2f9ff76311a644a00048")
