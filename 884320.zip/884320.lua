-- Lua provided by RyzenAPI
-- Game: Love Vibe: Aria

-- MAIN APPLICATION
addappid(884320)

-- MAIN APP DEPOTS / PACKAGES
addappid(884321, 1, "7776581e629aac5959d420d25dd8d391c6f291c44fb3f6814d4a8783e5124d6e")
addappid(1091300, 0, "0441d81c15b71d26d4264747f49caefaa9a4d278b3ec95a0ad19bab8a85af36b")
