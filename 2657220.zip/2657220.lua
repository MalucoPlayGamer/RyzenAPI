-- Lua provided by RyzenAPI
-- Game: Office Nightmare Chapter 1&2

-- MAIN APPLICATION
addappid(2657220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657221, 1, "ae0cebfbcd2292c0ecf417805ccf3de2dd79c229800ac2bb8dda97ca25a0fdc4")

