-- Lua provided by RyzenAPI
-- Game: Game: 最后的英雄

-- MAIN APPLICATION
addappid(2910900)
-- Game: addappid(2910900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910901, 1, "ab5579bcf5e0cb9e4034c8957e06fc45cccaba2fc4502cbfb66ebd49bea62820")
