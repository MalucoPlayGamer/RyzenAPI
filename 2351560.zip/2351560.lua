-- Lua provided by RyzenAPI
-- Game: Apocalypse Party

-- MAIN APPLICATION
addappid(2351560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351561, 1, "fcf2aa6dcce4ef090a8e800bb1088e3248c6d8567223a1df52a48362a519ba47")
addappid(2685140, 0, "4eb341023f2c1a4446d53fd53bb8f2f5833ee182cd410e501ffa346aeef853cc")

