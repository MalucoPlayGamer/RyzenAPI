-- Lua provided by RyzenAPI
-- Game: Apocalypse Party

-- MAIN APPLICATION
addappid(2351560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2351561, 1, "fcf2aa6dcce4ef090a8e800bb1088e3248c6d8567223a1df52a48362a519ba47")
addappid(2685140, 0, "4eb341023f2c1a4446d53fd53bb8f2f5833ee182cd410e501ffa346aeef853cc")

