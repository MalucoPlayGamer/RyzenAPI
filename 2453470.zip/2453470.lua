-- Lua provided by RyzenAPI
-- Game: Plunder Masters Demo

-- MAIN APPLICATION
addappid(2453470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453471, 1, "86a4c09206fa18ad87a6734add51697888abd47c54c0d74dd719fef09c8ed32b")

