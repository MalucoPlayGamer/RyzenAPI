-- Lua provided by RyzenAPI
-- Game: addappid(803040)

-- MAIN APPLICATION
addappid(803040)

-- MAIN APP DEPOTS / PACKAGES
addappid(803041, 1, "906b83b0a26511e67c67c030fad5307079a30ad9926a05dec11056d50aa3293b")
