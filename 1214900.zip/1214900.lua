-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1214900)
-- Game: addappid(1214900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214900,0,"e3e2aa08de48af152895feda85a8ad1dea2ec034d40f472eefa5c81fbe5a2f15")
