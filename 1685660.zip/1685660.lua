-- Lua provided by RyzenAPI
-- Game: Protect Eggs

-- MAIN APPLICATION
addappid(1685660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1685661, 1, "b45d303f18e5022c7b002bc25a35aadb5e2e32ba2afdd089bf66629ddeba2552")

