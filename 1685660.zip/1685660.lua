-- Lua provided by RyzenAPI
-- Game: Protect Eggs

-- MAIN APPLICATION
addappid(1685660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685661, 1, "b45d303f18e5022c7b002bc25a35aadb5e2e32ba2afdd089bf66629ddeba2552")

