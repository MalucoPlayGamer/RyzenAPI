-- Lua provided by RyzenAPI
-- Game: 1019986

-- MAIN APPLICATION
addappid(1019986)
-- Game: addappid(1019986)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019986,0,"2bc1ca8b55ccd70f3e3f0ee493d40baa477bed0d4c932f32ec1a1774a2d535fa")
