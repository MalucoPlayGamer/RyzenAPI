-- Lua provided by RyzenAPI
-- Game: 2545120

-- MAIN APPLICATION
addappid(2545120)
-- Game: addappid(2545120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545121, 1, "e26a28e1e9313265ecf07208d863e6c5be1d147171c7cfd745c71ded2a761ef5")
