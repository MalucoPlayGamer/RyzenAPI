-- Lua provided by RyzenAPI
-- Game: addappid(12690)

-- MAIN APPLICATION
addappid(12690)

-- MAIN APP DEPOTS / PACKAGES
addappid(12691, 1, "5eaef9f0b441cbd411e8939edf87b07569d3119d3e73db264105bae09961ac11")
