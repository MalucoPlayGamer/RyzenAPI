-- Lua provided by SkyAPI 
-- Game: Hunting Unlimited 2010
addappid(12690)
addappid(12691, 1, "5eaef9f0b441cbd411e8939edf87b07569d3119d3e73db264105bae09961ac11")
