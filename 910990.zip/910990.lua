-- Lua provided by RyzenAPI
-- Game: Urban Lockdown

-- MAIN APPLICATION
addappid(910990)

-- MAIN APP DEPOTS / PACKAGES
addappid(910991, 1, "773f2625440f3269768f0e343c33fa250a5b50577db5e8498dc3a7f01361ef91")

