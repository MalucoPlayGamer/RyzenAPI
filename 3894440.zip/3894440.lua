-- Lua provided by RyzenAPI
-- Game: NO BACKUP

-- MAIN APPLICATION
addappid(3894440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3894441, 1, "812227d6ad31b267422fab0cff44251155d85723ec3d365e4cafe422ae43848f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
