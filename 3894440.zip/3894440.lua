-- Lua provided by RyzenAPI
-- Game: addappid(3894440)

-- MAIN APPLICATION
addappid(3894440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3894441, 1, "812227d6ad31b267422fab0cff44251155d85723ec3d365e4cafe422ae43848f")
