-- Lua provided by RyzenAPI
-- Game: addappid(778390)

-- MAIN APPLICATION
addappid(778390)

-- MAIN APP DEPOTS / PACKAGES
addappid(778391, 1, "e11bbe7a8165e6d8ece754bf89663d68081bd1927e5b4d9cd7913373c050bd86")
