-- Lua provided by RyzenAPI
-- Game: Corpse Party: Book of Shadows

-- MAIN APPLICATION
addappid(778390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(778391, 1, "e11bbe7a8165e6d8ece754bf89663d68081bd1927e5b4d9cd7913373c050bd86")

