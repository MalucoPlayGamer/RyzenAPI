-- Lua provided by RyzenAPI
-- Game: Whiteboyz Wit Attitude: The Pursuit of Money

-- MAIN APPLICATION
addappid(1411670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411671, 1, "0429c3888903936a1c5dec474d43d341e49c628cf30552976332aa1b90e69553")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
