-- Lua provided by RyzenAPI
-- Game: Whiteboyz Wit Attitude: The Pursuit of Money

-- MAIN APPLICATION
addappid(1411670)
-- Game: addappid(1411670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411671, 1, "0429c3888903936a1c5dec474d43d341e49c628cf30552976332aa1b90e69553")
