-- Lua provided by RyzenAPI
-- Game: Gunspell - Steam Edition

-- MAIN APPLICATION
addappid(328100)
-- Game: addappid(328100)

-- MAIN APP DEPOTS / PACKAGES
addappid(328101, 1, "27d5284a08da901f5e4af41333a361c4fed8f3c172932426eb943618254eaab1")
addappid(328102, 1, "b576cbe5c37dfda3ea81f336954e5954ef32901693f153f397472407c88955ae")
addappid(328103, 1, "8785bb7e59f04e0129a3f4f6903e04eaaca06bf16b356b1b4af6e76438f465ae")
