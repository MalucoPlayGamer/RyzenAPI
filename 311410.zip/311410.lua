-- Lua provided by RyzenAPI
-- Game: Game: AppID 311410

-- MAIN APPLICATION
addappid(311410)
-- Game: addappid(311410)

-- MAIN APP DEPOTS / PACKAGES
addappid(311411, 1, "cfeda1ec68860d8bf68d7ba444a9bf6a7970935d8220cf7b6f0a5cf82ec16ff3")
