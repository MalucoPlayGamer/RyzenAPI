-- Lua provided by RyzenAPI 
-- Game: AppID 2457670
addappid(2457670)
addappid(2457671, 1, "218f6f9ff3edba08a45a9dcb06deef03793c2639351feacb109e4de2907051e9")
