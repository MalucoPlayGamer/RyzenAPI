-- Lua provided by RyzenAPI
-- Game: Revengeful Island

-- MAIN APPLICATION
addappid(4330590)

-- MAIN APP DEPOTS / PACKAGES
addappid(4330591,0,"d10b8b3d342deacffbd260f20ae087f60846a0f09c0af194a92cd89608199366")

