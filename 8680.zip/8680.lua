-- Lua provided by RyzenAPI
-- Game: RACE 07 Demo - Crowne Plaza Edition Dedicated Server

-- MAIN APPLICATION
addappid(4261)
addappid(8604)
addappid(8680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")

