-- Lua provided by RyzenAPI
-- Game: SteamDolls - Prologue Demo FREE

-- MAIN APPLICATION
addappid(1030760)
addappid(1150970)
addappid(1153820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030761, 1, "0d15efe82d227ec5edf49ee7e55891bb447bb2411cea8445d259a7b6a57f09f6")

