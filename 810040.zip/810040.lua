-- Lua provided by RyzenAPI
-- Game: Game: AppID 810040

-- MAIN APPLICATION
addappid(810040)
-- Game: addappid(810040)

-- MAIN APP DEPOTS / PACKAGES
addappid(810041, 1, "7a53a167401b7237d81b7dc580554a0421dfb6f6823fae627648b6c1afeac120")
