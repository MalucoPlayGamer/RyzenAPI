-- Lua provided by RyzenAPI
-- Game: Swords 'n Magic and Stuff

-- MAIN APPLICATION
addappid(810040)
addappid(1377630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(810041, 1, "7a53a167401b7237d81b7dc580554a0421dfb6f6823fae627648b6c1afeac120")

