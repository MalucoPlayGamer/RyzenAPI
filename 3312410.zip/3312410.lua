-- Lua provided by RyzenAPI
-- Game: I Touched Tips with a Femboy

-- MAIN APPLICATION
addappid(3312410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312411, 1, "6c35721a8fce3bab7b9fa96ae3ad0dfda1309433fd78abfb8375acaf15fbacc0")

