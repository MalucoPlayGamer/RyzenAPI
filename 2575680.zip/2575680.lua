-- Lua provided by RyzenAPI
-- Game: Game: AppID 2575680

-- MAIN APPLICATION
addappid(2575680)
-- Game: addappid(2575680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575681, 1, "d68e7c970f02f13ce18a0d7e53251b8e6291c06a5b632b49110a55aa76e27517")
