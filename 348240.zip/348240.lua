-- Lua provided by RyzenAPI
-- Game: Gun Wings

-- MAIN APPLICATION
addappid(348240)

-- MAIN APP DEPOTS / PACKAGES
addappid(348241, 1, "a86fdea187569752a77f3cf5dc0817bc7868af7e80006a28bb3e1c375dbc8ccb")

