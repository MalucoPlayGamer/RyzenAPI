-- Lua provided by RyzenAPI
-- Game: Welcome to Levy

-- MAIN APPLICATION
addappid(2189470)
addappid(2189560)
-- Game: addappid(2189470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189471, 1, "bdd58d1899776948e10113b35fef9a8cd4dc53faff7ed7a94846c93d37837ddb")
addappid(2189472, 1, "e4572d1e3a7446b3b11058938de39a47e4e505ae6be804b3213d7246cdeb7815")
