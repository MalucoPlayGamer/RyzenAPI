-- Lua provided by RyzenAPI
-- Game: 1206060

-- MAIN APPLICATION
addappid(1206060)
-- Game: addappid(1206060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206061, 1, "eb6485cbfb416d5094f82617fc7448c045d90a8a68f79bda7fff76a3ff4e4f0b")
