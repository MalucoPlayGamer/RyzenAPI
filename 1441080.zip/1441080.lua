-- Lua provided by RyzenAPI
-- Game: Lost Viking - Kingdom of Women Demo

-- MAIN APPLICATION
addappid(1441080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441081, 1, "3f9e42ef190135a4bb9c99bdf826b4b12a9bd7d20220a3248e439ab9be301a58")

