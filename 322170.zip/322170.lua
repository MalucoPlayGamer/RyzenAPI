-- Lua provided by RyzenAPI
-- Game: Geometry Dash

-- MAIN APPLICATION
addappid(322170)

-- MAIN APP DEPOTS / PACKAGES
addappid(322171, 1, "73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d")
addappid(322172, 1, "6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e")
