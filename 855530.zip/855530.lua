-- Lua provided by RyzenAPI
-- Game: New Ice York

-- MAIN APPLICATION
addappid(855530)
-- Game: addappid(855530)

-- MAIN APP DEPOTS / PACKAGES
addappid(855531, 1, "103efa1f466d2cb525748425a6df25e1c846ecd857f9c4ff123c2c72c8231883")
