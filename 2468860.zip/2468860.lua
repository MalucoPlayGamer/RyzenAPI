-- Lua provided by RyzenAPI
-- Game: 2468860

-- MAIN APPLICATION
addappid(2468860)
-- Game: addappid(2468860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468861, 1, "542a54a7f53ddbf72305ae2a29880389e85da61f0b1d02f7d8e33357430eea04")
