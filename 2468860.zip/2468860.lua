-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2&2.5+X1 Dark

-- MAIN APPLICATION
addappid(2468860)
-- Game: addappid(2468860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468861, 1, "542a54a7f53ddbf72305ae2a29880389e85da61f0b1d02f7d8e33357430eea04")
