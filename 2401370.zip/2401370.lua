-- Lua provided by RyzenAPI
-- Game: Game: Dogs Club

-- MAIN APPLICATION
addappid(2401370)
-- Game: addappid(2401370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401371, 1, "23bf9cb5bff143d1892be7594cd8a28d342b6d51966512c0af74d1f2aa1f4203")
