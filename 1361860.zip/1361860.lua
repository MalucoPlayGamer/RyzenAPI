-- Lua provided by RyzenAPI
-- Game: Toilet Management Simulator

-- MAIN APPLICATION
addappid(1361860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361861, 1, "30be40511722f267692143dc5f98fc06961d655b13ec23685aba8f1b2aef4219")

