-- Lua provided by RyzenAPI
-- Game: A Work of Art

-- MAIN APPLICATION
addappid(3027780)
