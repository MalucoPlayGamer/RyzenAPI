-- Lua provided by RyzenAPI
-- Game: A Work of Art

-- MAIN APPLICATION
addappid(3027780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

