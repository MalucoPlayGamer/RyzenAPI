-- Lua provided by RyzenAPI
-- Game: Virtual Viking

-- MAIN APPLICATION
addappid(1253160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253161, 1, "628e6dc7e014c00127cd005fb0d8c3c24c7c07eb9ad44e11c2ddcf28849ffa48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
