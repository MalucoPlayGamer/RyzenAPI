-- Lua provided by RyzenAPI
-- Game: Virtual Viking

-- MAIN APPLICATION
addappid(1253160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253161, 1, "628e6dc7e014c00127cd005fb0d8c3c24c7c07eb9ad44e11c2ddcf28849ffa48")

