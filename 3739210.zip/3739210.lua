-- Lua provided by RyzenAPI
-- Game: Game: Condo

-- MAIN APPLICATION
addappid(3739210)
-- Game: addappid(3739210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739211, 1, "85e0151786f3177bb6c810fdcca1ee74879912916fb8070e0b919a48bd32eb45")
