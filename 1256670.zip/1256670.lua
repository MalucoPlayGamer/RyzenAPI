-- Lua provided by RyzenAPI
-- Game: Library Of Ruina

-- MAIN APPLICATION
addappid(1256670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256671, 1, "00c735126632c6eadd65b68ea7eda8c5b53533b7667a651747c006bd102491fb")
addappid(1735680, 0, "7eec92553b09b2fd957f4be63eae32b05f0a496d42c8b311aea081606362b81c")
