-- Lua provided by RyzenAPI
-- Game: Get Over Blood

-- MAIN APPLICATION
addappid(1306160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306161, 1, "04df6b8087ada78a6e7a3725f3f3c05313dc645dccc87810a65a70874b00b0b4")
