-- Lua provided by RyzenAPI
-- Game: CROSS†CHANNEL: Steam Edition

-- MAIN APPLICATION
addappid(812560)

-- MAIN APP DEPOTS / PACKAGES
addappid(812561, 1, "d5ada08c37a6f887929e0d44d4a32eff3442cecae698230adf80865c1b4ddd71")
addappid(812562, 1, "234c6e346719e3d8ca26f7e65db7e71cdf09bfa669a4c0a12fd2c49b66ac8c0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
