-- Lua provided by RyzenAPI
-- Game: CROSS†CHANNEL: Steam Edition

-- MAIN APPLICATION
addappid(812560)

-- MAIN APP DEPOTS / PACKAGES
addappid(812561, 1, "d5ada08c37a6f887929e0d44d4a32eff3442cecae698230adf80865c1b4ddd71")
addappid(812562, 1, "234c6e346719e3d8ca26f7e65db7e71cdf09bfa669a4c0a12fd2c49b66ac8c0f")

