-- Lua provided by RyzenAPI
-- Game: Punch Club

-- MAIN APPLICATION
addappid(394310)
-- Game: addappid(394310)

-- MAIN APP DEPOTS / PACKAGES
addappid(394311, 1, "eb8e09ffae72cf2b7d9b19f3ec8b25acd9135c665c26017047a74a2998ba71c4")
addappid(394312, 1, "9ad8d57c8bdc9261fc109a718b857cacf454e9e9c6b8ce0876a08b31e6959881")
addappid(394313, 1, "1ed6ea9dc8351c85216c87cc0783ecb77c0217cf02599c5dbd588fa56d89fc2c")
addappid(431490, 0, "2254d8c81372e2923dd5979569eb313478009b44d236978b318adbb796feb9b8")
