-- Lua provided by RyzenAPI
-- Game: Lemonade Apocalypse

-- MAIN APPLICATION
addappid(2861560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2861561, 1, "d195548ea7e13af7e2a929a27e5517a9628427c3c43722e7e496e15254c640c5")
