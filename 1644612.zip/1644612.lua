-- Lua provided by RyzenAPI
-- Game: 1644612

-- MAIN APPLICATION
addappid(1644612)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644612,0,"c59f36c44b93b9da8efd9ff63870b8b600663fda54e72672f9ab2d4fdfd216e1")

