-- Lua provided by RyzenAPI
-- Game: 3764530

-- MAIN APPLICATION
addappid(3764530)
-- Game: addappid(3764530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3764532,0,"23cee28a5854dc782f46592eb288c313ec87d4cfc6c0365392cea20f21a224c0")
