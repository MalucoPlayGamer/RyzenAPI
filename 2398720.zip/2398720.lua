-- Lua provided by RyzenAPI
-- Game: Rune in the Three Kingdoms

-- MAIN APPLICATION
addappid(2398720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398721, 1, "c9916ac6a54a2565ac2a10d9703b5f0f440834a39db82ad5fe06a85838c5923f")

