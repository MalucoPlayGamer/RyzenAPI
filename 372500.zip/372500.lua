-- Lua provided by RyzenAPI 
-- Game: Secrets of Grindea Demo
addappid(372500)
addappid(372501, 1, "6bdddada96e60814c876bb12ba468e0978b2bf88eac2323a838bb19737ae6e8c")
