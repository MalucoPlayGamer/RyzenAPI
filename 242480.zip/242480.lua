-- Lua provided by RyzenAPI
-- Game: Game: AppID 242480

-- MAIN APPLICATION
addappid(242480)
-- Game: addappid(242480)

-- MAIN APP DEPOTS / PACKAGES
addappid(242481, 1, "1a584a4ba529c963a155a149949084336ffe64d963c19416f6c9a9cf9c9449b2")
