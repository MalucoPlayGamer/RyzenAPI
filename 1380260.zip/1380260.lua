-- Lua provided by RyzenAPI 
-- Game: Space Empires: Starfury
addappid(1380260)
addappid(1380261, 1, "76e56f26a1b3cf251617d5c317895af9700bfd34964a8a179753602a2d9f63ac")
