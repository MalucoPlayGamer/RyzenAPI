-- Lua provided by RyzenAPI
-- Game: addappid(772750)

-- MAIN APPLICATION
addappid(772750)

-- MAIN APP DEPOTS / PACKAGES
addappid(772751, 1, "5e11a7f7b196ee3ed9b4ff2a0a3196a70197eb2090385ab89b601f98b2be705e")
