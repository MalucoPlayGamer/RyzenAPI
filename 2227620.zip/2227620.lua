-- Lua provided by RyzenAPI
-- Game: AppID 2227620

-- MAIN APPLICATION
addappid(2227620)
-- Game: addappid(2227620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227621, 1, "117202db2b423180ec9ea6e577e076b84e62eb0765988aeefc8aa9bbd0b825f6")
