-- Lua provided by SkyAPI 
-- Game: AppID 389270
addappid(389270)
addappid(389271, 1, "efdb17e0e0c87bb50c966c47b11ea761fb3f8af61793bc73a9493c1ccd5ca89c")
