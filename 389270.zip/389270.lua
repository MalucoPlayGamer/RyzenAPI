-- Lua provided by RyzenAPI
-- Game: Game: AppID 389270

-- MAIN APPLICATION
addappid(389270)
-- Game: addappid(389270)

-- MAIN APP DEPOTS / PACKAGES
addappid(389271, 1, "efdb17e0e0c87bb50c966c47b11ea761fb3f8af61793bc73a9493c1ccd5ca89c")
