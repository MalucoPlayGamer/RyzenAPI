-- Lua provided by RyzenAPI
-- Game: AppID 3163040

-- MAIN APPLICATION
addappid(3163040)
-- Game: addappid(3163040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163041, 1, "e73061e6273f410408bdeee586d8400729bd85cd3cf206b40cba8d8733966b86")
