-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(675354)

-- MAIN APP DEPOTS / PACKAGES
addappid(734630,0,"97bf167903ada9659ed59f90c990d3a438f7743d633c3785e116f02139cc763b")

