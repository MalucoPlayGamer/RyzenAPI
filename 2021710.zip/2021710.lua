-- Lua provided by RyzenAPI
-- Game: Sakura Succubus 7

-- MAIN APPLICATION
addappid(2021710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021711, 1, "0bf1786c91a524e3b5e99ecf6996797554d143e20e70ac8f4ca10dd908370d91")

