-- Lua provided by RyzenAPI
-- Game: Spark & Kling

-- MAIN APPLICATION
addappid(2712910)
-- Game: addappid(2712910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712911, 1, "79c275ee81f3ef49dc4a57d64fcb685a7f0b9bf26f527c4f559e16a5a0ac4a6f")
