-- Lua provided by RyzenAPI
-- Game: addappid(1215320)

-- MAIN APPLICATION
addappid(1215320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215321, 1, "e0694c0daae63fad11b147bea63e39dac21655cf54b067c509daef5419b87926")
