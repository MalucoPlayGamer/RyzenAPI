-- Lua provided by RyzenAPI
-- Game: Piczle Cross Adventure

-- MAIN APPLICATION
addappid(1215320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215321, 1, "e0694c0daae63fad11b147bea63e39dac21655cf54b067c509daef5419b87926")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
