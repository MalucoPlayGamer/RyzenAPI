-- Lua provided by RyzenAPI
-- Game: Secrets Of Soil

-- MAIN APPLICATION
addappid(1610820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610821, 1, "fe0bd6b5b4d3ba0f611d1832e161ad50eb22eaf3b31021a06118b6185e433600")
