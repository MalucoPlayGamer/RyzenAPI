-- Lua provided by RyzenAPI
-- Game: Fury's Sky

-- MAIN APPLICATION
addappid(1118550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118551, 1, "29aebf7a697d06d3fddd5c2652da9d70f6c77561aa5ab2bb74e605052d4aee0c")
addappid(1118552, 1, "3b275d3a214a33a3283e8f29b8aec6ea62e1a2fdcf690ba7dd8f4d4612a83c6d")

