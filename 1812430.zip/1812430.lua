-- Lua provided by RyzenAPI
-- Game: 1812430

-- MAIN APPLICATION
addappid(1812430)
-- Game: addappid(1812430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812431, 1, "cb3127bd29d987fec668eb1a5bdc7bc43701e6a16c220e836734a0f6214dec8d")
