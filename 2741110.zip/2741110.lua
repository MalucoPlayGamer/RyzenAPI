-- Lua provided by RyzenAPI
-- Game: Idle Nine Heavens

-- MAIN APPLICATION
addappid(2741110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741111, 1, "1b5387e62a36af040deb52ad9f49c7896ab6216f3b28326e3a91b9a289432e3a")

