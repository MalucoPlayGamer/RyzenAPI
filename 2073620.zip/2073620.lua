-- Lua provided by RyzenAPI
-- Game: Arena Breakout: Infinite

-- MAIN APPLICATION
addappid(2073620)
-- Game: addappid(2073620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073622,0,"154ad2895e0508329860b5e2cdf50583b1708ce1a37767731393bf2f62bf5560")
addtoken(2073620,"10441616841966771533")
