-- Lua provided by RyzenAPI
-- Game: Game: Boba Simulator Demo

-- MAIN APPLICATION
addappid(2235170)
-- Game: addappid(2235170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235171, 1, "1a8a145543082a682717e2a09564894c112eec0628c434d2c4ca7ba47ec559bf")
