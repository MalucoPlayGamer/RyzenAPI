-- Lua provided by RyzenAPI
-- Game: Game: Napoleon: Total War Demo

-- MAIN APPLICATION
addappid(34050)
-- Game: addappid(34050)

-- MAIN APP DEPOTS / PACKAGES
addappid(34051, 1, "4f27fda2a7bb2ade876795666835d47608231597089822ea988441ab7a3c9c98")
addappid(34052, 1, "8b534d632fed84a61ebc08146f328bf1fa21c113ed74249c70d4bd21c8f62967")
addappid(34053, 1, "fd0f98ad1b9d2041a79f69c7d9721b2b870be11032feef688b8af52c901e49cf")
addappid(34055, 1, "935867c4fe8b130154ba99681705969ec492e8f053d4e64cf4bf0678e587975c")
