-- Lua provided by RyzenAPI 
-- Game: AppID 694930
addappid(694930)
addappid(694931, 1, "d7af51d3679237a34cf09ce709514a5dc12660549068784731fc7b0a25cef827")
