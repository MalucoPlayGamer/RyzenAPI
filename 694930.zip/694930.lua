-- Lua provided by RyzenAPI
-- Game: Lost God

-- MAIN APPLICATION
addappid(694930)

-- MAIN APP DEPOTS / PACKAGES
addappid(694931, 1, "d7af51d3679237a34cf09ce709514a5dc12660549068784731fc7b0a25cef827")

