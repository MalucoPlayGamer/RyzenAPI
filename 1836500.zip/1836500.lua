-- Lua provided by RyzenAPI
-- Game: addappid(1836500)

-- MAIN APPLICATION
addappid(1836500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836501, 1, "26ba9be4cd03eb5f5324d50467c0aa304e6fbf1ffa50855fcb875814c27f7d8b")
addappid(1837360, 0, "958b01f5ce413173f14fde2cb0e0ed69ade9e9695a24c801ac0c845bcba17dbd")
