-- Lua provided by RyzenAPI
-- Game: AppID 276160

-- MAIN APPLICATION
addappid(276160)

-- MAIN APP DEPOTS / PACKAGES
addappid(276161, 1, "d88658a71ef630fa174737c02cc6db3eb15d1037c71fef417bbd04407fcb2fd1")
