-- Lua provided by RyzenAPI
-- Game: Calvin Tucker's Farm Animal Racing

-- MAIN APPLICATION
addappid(809900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809901,0,"b8696360bab022367a7d65eb21c461b2d58dc8773368f316ab40485fb1ec1961")

