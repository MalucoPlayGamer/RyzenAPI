-- Lua provided by RyzenAPI
-- Game: Len's Island

-- MAIN APPLICATION
addappid(1335830)
addappid(3795980)
addappid(3809990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335831, 1, "f2232a3bfcb5c7612c95312dfd25d89e6f0795121c0554e12b911b6f8d982e65")
addappid(1335832, 1, "3415b4a91f32415894d413bde36a9241af420679c00e1b11fb96c0c8ad90dcbd")

