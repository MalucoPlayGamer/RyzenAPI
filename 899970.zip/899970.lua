-- Lua provided by RyzenAPI
-- Game: Game: NEKOPARA Extra

-- MAIN APPLICATION
addappid(899970)
-- Game: addappid(899970)

-- MAIN APP DEPOTS / PACKAGES
addappid(899971, 1, "a4d5d9b27ad9f7942a01fb69aa49a7864f74248ca2a03da836baf1a4824056eb")
addappid(1088310, 0, "ce6e3c20aa2d70971369417d89e84e133ea29f866b223d0417a60096df48a1ad")
