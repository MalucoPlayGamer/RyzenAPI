-- Lua provided by RyzenAPI
-- Game: Huenison

-- MAIN APPLICATION
addappid(410370)
-- Game: addappid(410370)

-- MAIN APP DEPOTS / PACKAGES
addappid(410371, 1, "b0a437ab76b8737435d0e9abf57807cb0951bb69c1bec96ed03f0ee8720f45ca")
addappid(410372, 1, "bb887c4d4e7f0b773595d13b0fef5ece48e7aea9dd5e0dd70eccbb7a56121d26")
addappid(434180, 0, "4f4b915599d2b46059891d139519046d05aa94cac2394744938cf29580c7f08b")
