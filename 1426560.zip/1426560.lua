-- Lua provided by SkyAPI 
-- Game: AppID 1426560
addappid(1426560)
addappid(1426561, 1, "6d118dea18d372f3f6c6758fe55e384b3e7e8db03aa96ff5cb52fa15528dd6a2")
