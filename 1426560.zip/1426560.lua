-- Lua provided by RyzenAPI
-- Game: The Ghost Soprano 夜半歌声

-- MAIN APPLICATION
addappid(1426560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426561, 1, "6d118dea18d372f3f6c6758fe55e384b3e7e8db03aa96ff5cb52fa15528dd6a2")
