-- Lua provided by RyzenAPI
-- Game: VHS

-- MAIN APPLICATION
addappid(3074340)
addappid(3124300)
addappid(3757710)

