-- Lua provided by RyzenAPI
-- Game: VHS

-- MAIN APPLICATION
addappid(3074340)

