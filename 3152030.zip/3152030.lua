-- Lua provided by RyzenAPI
-- Game: 3152030

-- MAIN APPLICATION
addappid(3152030)
-- Game: addappid(3152030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152031, 1, "4af05ad0f36ba1e22306e3408d594bf8243ca8e9116b15688ca5c8ff2b617e76")
