-- Lua provided by RyzenAPI 
-- Game: Scholar's Mate - First Move
addappid(2346810)
addappid(2346811, 1, "12a353153a49fae3b532e703f8fc635bd5bef93eedee20aaf380cd22300cb0e8")
