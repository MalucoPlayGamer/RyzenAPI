-- Lua provided by RyzenAPI
-- Game: Game: Scholar's Mate - First Move

-- MAIN APPLICATION
addappid(2346810)
-- Game: addappid(2346810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346811, 1, "12a353153a49fae3b532e703f8fc635bd5bef93eedee20aaf380cd22300cb0e8")
