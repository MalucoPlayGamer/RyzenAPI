-- Lua provided by RyzenAPI
-- Game: Scholar's Mate - First Move

-- MAIN APPLICATION
addappid(2346810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2346811, 1, "12a353153a49fae3b532e703f8fc635bd5bef93eedee20aaf380cd22300cb0e8")

