-- Lua provided by RyzenAPI
-- Game: Stickman Killing Zombie

-- MAIN APPLICATION
addappid(2792610)
-- Game: addappid(2792610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2792612,0,"3bc29bc897292968a239884c31d18a85156bece8dc52ae515f57f889b4f19a04")
