-- Lua provided by RyzenAPI
-- Game: AppID 1335240

-- MAIN APPLICATION
addappid(1335240)
-- Game: addappid(1335240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335241, 1, "700c0a3642ebd5db7f945a1902b03b01a509b528c3274760f3f4fc08f5742c9c")
