-- Lua provided by SkyAPI 
-- Game: AppID 1335240
addappid(1335240)
addappid(1335241, 1, "700c0a3642ebd5db7f945a1902b03b01a509b528c3274760f3f4fc08f5742c9c")
