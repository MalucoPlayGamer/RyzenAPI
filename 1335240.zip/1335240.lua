-- Lua provided by RyzenAPI
-- Game: 放置勇者：远征/idle Heroes: Odyssey

-- MAIN APPLICATION
addappid(1335240)
addappid(1409720)
addappid(1409721)
addappid(1610510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1335241, 1, "700c0a3642ebd5db7f945a1902b03b01a509b528c3274760f3f4fc08f5742c9c")

