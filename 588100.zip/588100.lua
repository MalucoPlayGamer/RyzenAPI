-- Lua provided by RyzenAPI
-- Game: AppID 588100

-- MAIN APPLICATION
addappid(588100)
-- Game: addappid(588100)

-- MAIN APP DEPOTS / PACKAGES
addappid(588101, 1, "cfffa0f211972329020ddbc517504a5f566e96d78d17ea557f955e202d177318")
