-- Lua provided by RyzenAPI
-- Game: 2687850

-- MAIN APPLICATION
addappid(2687850)
-- Game: addappid(2687850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687851, 1, "f6e7e207b53ed1f0ac9681b63671c75d18af1c4187622a3b112e9e845bac3ce4")
